
(function ($global, $, $spc, $sc, $sdt, $st, $scc, $sm, $spu, $sr, $sttp, $stc) {
    "use strict";
    let _;
    
    
    
	$.$asm(
    "NetJs.System.Runtime.InteropServices.JavaScript", 
    {"h":53484,"f":"System.Runtime.InteropServices.JavaScript","v":"1.0.35.0","a":[{"t":114950145,"c":4409917441,"a":[{"v":"browser","t":1310721}]},{"t":115146753,"c":13000048641,"a":[{"v":".NETCoreApp,Version=v10.0","t":1310721}],"n":[{"n":"FrameworkDisplayName","v":".NET 10.0","t":1310721}]},{"t":73596929,"c":4368564225,"a":[{"v":"SIT","t":1310721}]},{"t":73662465,"c":4368629761,"a":[{"v":"Debug","t":1310721}]},{"t":74121217,"c":4369088513,"a":[{"v":"1.0.35.0","t":1310721}]},{"t":74252289,"c":4369219585,"a":[{"v":"1.0.35\u002B99807a3edea449997cda60d38046fed69821a2f6","t":1310721}]},{"t":75104257,"c":4370071553,"a":[{"v":"NetJs.System.Runtime.InteropServices.JavaScript","t":1310721}]},{"t":75235329,"c":4370202625,"a":[{"v":"NetJs.System.Runtime.InteropServices.JavaScript","t":1310721}]},{"t":75366401,"c":4370333697,"a":[{"v":"1.0.35.0","t":1310721}]},{"t":115212289,"c":4410179585,"a":[{"v":"browser1.0","t":1310721}]},{"t":114950145,"c":4409917441,"a":[{"v":"browser1.0","t":1310721}]}],"m":[]},
    function($asm)
	{
        
        
        $asm.$cls("$srij.System.Runtime.InteropServices.JavaScript.JSType", ($self) => class JSType extends $.$spc.System.Object
        {
            $ctor$1()
            {
                super.$ctor();
                {
                }
                return this;
            }
            static $_Void;
            static get Void()
            {
                let $cls = $.$srij.System.Runtime.InteropServices.JavaScript.JSType;
                return $cls.$_Void ??= $asm.$ncls("$srij.System.Runtime.InteropServices.JavaScript.JSType.Void", ($self) => class Void extends $.$srij.System.Runtime.InteropServices.JavaScript.JSType
                {
                    $ctor$2()
                    {
                        super.$ctor$1();
                        {
                        }
                        return this;
                    }
                    static $h = 3657964;
                    static $f = 0b10000000010010001;
                    static $k = 1;
                    static $$md;
                    static get $md() { return this.$$md ??= {"b":2412780,"c":[{"n":".ctor","o":"$ctor$2","d":3657964,"h":4298625260,"f":8}],"d":2412780,"h":3657964}; }
                    static get $b() { return $.$srij.System.Runtime.InteropServices.JavaScript.JSType; }
                    static get $fullName() { return `System.Runtime.InteropServices.JavaScript.JSType.Void`; }
                }, $cls, ($v) => $cls.$_Void = $v);
            }
            static $_Discard;
            static get Discard()
            {
                let $cls = $.$srij.System.Runtime.InteropServices.JavaScript.JSType;
                return $cls.$_Discard ??= $asm.$ncls("$srij.System.Runtime.InteropServices.JavaScript.JSType.Discard", ($self) => class Discard extends $.$srij.System.Runtime.InteropServices.JavaScript.JSType
                {
                    $ctor$2()
                    {
                        super.$ctor$1();
                        {
                        }
                        return this;
                    }
                    static $h = 2805996;
                    static $f = 0b10000000010010001;
                    static $k = 1;
                    static $$md;
                    static get $md() { return this.$$md ??= {"b":2412780,"c":[{"n":".ctor","o":"$ctor$2","d":2805996,"h":4297773292,"f":8}],"d":2412780,"h":2805996}; }
                    static get $b() { return $.$srij.System.Runtime.InteropServices.JavaScript.JSType; }
                    static get $fullName() { return `System.Runtime.InteropServices.JavaScript.JSType.Discard`; }
                }, $cls, ($v) => $cls.$_Discard = $v);
            }
            static $_DiscardNoWait;
            static get DiscardNoWait()
            {
                let $cls = $.$srij.System.Runtime.InteropServices.JavaScript.JSType;
                return $cls.$_DiscardNoWait ??= $asm.$ncls("$srij.System.Runtime.InteropServices.JavaScript.JSType.DiscardNoWait", ($self) => class DiscardNoWait extends $.$srij.System.Runtime.InteropServices.JavaScript.JSType
                {
                    $ctor$2()
                    {
                        super.$ctor$1();
                        {
                        }
                        return this;
                    }
                    static $h = 2871532;
                    static $f = 0b10000000010010001;
                    static $k = 1;
                    static $$md;
                    static get $md() { return this.$$md ??= {"b":2412780,"c":[{"n":".ctor","o":"$ctor$2","d":2871532,"h":4297838828,"f":8}],"d":2412780,"h":2871532}; }
                    static get $b() { return $.$srij.System.Runtime.InteropServices.JavaScript.JSType; }
                    static get $fullName() { return `System.Runtime.InteropServices.JavaScript.JSType.DiscardNoWait`; }
                }, $cls, ($v) => $cls.$_DiscardNoWait = $v);
            }
            static $_Boolean;
            static get Boolean()
            {
                let $cls = $.$srij.System.Runtime.InteropServices.JavaScript.JSType;
                return $cls.$_Boolean ??= $asm.$ncls("$srij.System.Runtime.InteropServices.JavaScript.JSType.Boolean", ($self) => class Boolean extends $.$srij.System.Runtime.InteropServices.JavaScript.JSType
                {
                    $ctor$2()
                    {
                        super.$ctor$1();
                        {
                        }
                        return this;
                    }
                    static $h = 2674924;
                    static $f = 0b10000000010010001;
                    static $k = 1;
                    static $$md;
                    static get $md() { return this.$$md ??= {"b":2412780,"c":[{"n":".ctor","o":"$ctor$2","d":2674924,"h":4297642220,"f":8}],"d":2412780,"h":2674924}; }
                    static get $b() { return $.$srij.System.Runtime.InteropServices.JavaScript.JSType; }
                    static get $fullName() { return `System.Runtime.InteropServices.JavaScript.JSType.Boolean`; }
                }, $cls, ($v) => $cls.$_Boolean = $v);
            }
            static $_Number;
            static get Number()
            {
                let $cls = $.$srij.System.Runtime.InteropServices.JavaScript.JSType;
                return $cls.$_Number ??= $asm.$ncls("$srij.System.Runtime.InteropServices.JavaScript.JSType.Number", ($self) => class Number extends $.$srij.System.Runtime.InteropServices.JavaScript.JSType
                {
                    $ctor$2()
                    {
                        super.$ctor$1();
                        {
                        }
                        return this;
                    }
                    static $h = 3395820;
                    static $f = 0b10000000010010001;
                    static $k = 1;
                    static $$md;
                    static get $md() { return this.$$md ??= {"b":2412780,"c":[{"n":".ctor","o":"$ctor$2","d":3395820,"h":4298363116,"f":8}],"d":2412780,"h":3395820}; }
                    static get $b() { return $.$srij.System.Runtime.InteropServices.JavaScript.JSType; }
                    static get $fullName() { return `System.Runtime.InteropServices.JavaScript.JSType.Number`; }
                }, $cls, ($v) => $cls.$_Number = $v);
            }
            static $_BigInt;
            static get BigInt()
            {
                let $cls = $.$srij.System.Runtime.InteropServices.JavaScript.JSType;
                return $cls.$_BigInt ??= $asm.$ncls("$srij.System.Runtime.InteropServices.JavaScript.JSType.BigInt", ($self) => class BigInt extends $.$srij.System.Runtime.InteropServices.JavaScript.JSType
                {
                    $ctor$2()
                    {
                        super.$ctor$1();
                        {
                        }
                        return this;
                    }
                    static $h = 2609388;
                    static $f = 0b10000000010010001;
                    static $k = 1;
                    static $$md;
                    static get $md() { return this.$$md ??= {"b":2412780,"c":[{"n":".ctor","o":"$ctor$2","d":2609388,"h":4297576684,"f":8}],"d":2412780,"h":2609388}; }
                    static get $b() { return $.$srij.System.Runtime.InteropServices.JavaScript.JSType; }
                    static get $fullName() { return `System.Runtime.InteropServices.JavaScript.JSType.BigInt`; }
                }, $cls, ($v) => $cls.$_BigInt = $v);
            }
            static $_Date;
            static get Date()
            {
                let $cls = $.$srij.System.Runtime.InteropServices.JavaScript.JSType;
                return $cls.$_Date ??= $asm.$ncls("$srij.System.Runtime.InteropServices.JavaScript.JSType.Date", ($self) => class Date extends $.$srij.System.Runtime.InteropServices.JavaScript.JSType
                {
                    $ctor$2()
                    {
                        super.$ctor$1();
                        {
                        }
                        return this;
                    }
                    static $h = 2740460;
                    static $f = 0b10000000010010001;
                    static $k = 1;
                    static $$md;
                    static get $md() { return this.$$md ??= {"b":2412780,"c":[{"n":".ctor","o":"$ctor$2","d":2740460,"h":4297707756,"f":8}],"d":2412780,"h":2740460}; }
                    static get $b() { return $.$srij.System.Runtime.InteropServices.JavaScript.JSType; }
                    static get $fullName() { return `System.Runtime.InteropServices.JavaScript.JSType.Date`; }
                }, $cls, ($v) => $cls.$_Date = $v);
            }
            static $_String;
            static get String()
            {
                let $cls = $.$srij.System.Runtime.InteropServices.JavaScript.JSType;
                return $cls.$_String ??= $asm.$ncls("$srij.System.Runtime.InteropServices.JavaScript.JSType.String", ($self) => class String extends $.$srij.System.Runtime.InteropServices.JavaScript.JSType
                {
                    $ctor$2()
                    {
                        super.$ctor$1();
                        {
                        }
                        return this;
                    }
                    static $h = 3592428;
                    static $f = 0b10000000010010001;
                    static $k = 1;
                    static $$md;
                    static get $md() { return this.$$md ??= {"b":2412780,"c":[{"n":".ctor","o":"$ctor$2","d":3592428,"h":4298559724,"f":8}],"d":2412780,"h":3592428}; }
                    static get $b() { return $.$srij.System.Runtime.InteropServices.JavaScript.JSType; }
                    static get $fullName() { return `System.Runtime.InteropServices.JavaScript.JSType.String`; }
                }, $cls, ($v) => $cls.$_String = $v);
            }
            static $_Object;
            static get Object()
            {
                let $cls = $.$srij.System.Runtime.InteropServices.JavaScript.JSType;
                return $cls.$_Object ??= $asm.$ncls("$srij.System.Runtime.InteropServices.JavaScript.JSType.Object", ($self) => class Object extends $.$srij.System.Runtime.InteropServices.JavaScript.JSType
                {
                    $ctor$2()
                    {
                        super.$ctor$1();
                        {
                        }
                        return this;
                    }
                    static $h = 3461356;
                    static $f = 0b10000000010010001;
                    static $k = 1;
                    static $$md;
                    static get $md() { return this.$$md ??= {"b":2412780,"c":[{"n":".ctor","o":"$ctor$2","d":3461356,"h":4298428652,"f":8}],"d":2412780,"h":3461356}; }
                    static get $b() { return $.$srij.System.Runtime.InteropServices.JavaScript.JSType; }
                    static get $fullName() { return `System.Runtime.InteropServices.JavaScript.JSType.Object`; }
                }, $cls, ($v) => $cls.$_Object = $v);
            }
            static $_Error;
            static get Error()
            {
                let $cls = $.$srij.System.Runtime.InteropServices.JavaScript.JSType;
                return $cls.$_Error ??= $asm.$ncls("$srij.System.Runtime.InteropServices.JavaScript.JSType.Error", ($self) => class Error extends $.$srij.System.Runtime.InteropServices.JavaScript.JSType
                {
                    $ctor$2()
                    {
                        super.$ctor$1();
                        {
                        }
                        return this;
                    }
                    static $h = 2937068;
                    static $f = 0b10000000010010001;
                    static $k = 1;
                    static $$md;
                    static get $md() { return this.$$md ??= {"b":2412780,"c":[{"n":".ctor","o":"$ctor$2","d":2937068,"h":4297904364,"f":8}],"d":2412780,"h":2937068}; }
                    static get $b() { return $.$srij.System.Runtime.InteropServices.JavaScript.JSType; }
                    static get $fullName() { return `System.Runtime.InteropServices.JavaScript.JSType.Error`; }
                }, $cls, ($v) => $cls.$_Error = $v);
            }
            static $_MemoryView;
            static get MemoryView()
            {
                let $cls = $.$srij.System.Runtime.InteropServices.JavaScript.JSType;
                return $cls.$_MemoryView ??= $asm.$ncls("$srij.System.Runtime.InteropServices.JavaScript.JSType.MemoryView", ($self) => class MemoryView extends $.$srij.System.Runtime.InteropServices.JavaScript.JSType
                {
                    $ctor$2()
                    {
                        super.$ctor$1();
                        {
                        }
                        return this;
                    }
                    static $h = 3330284;
                    static $f = 0b10000000010010001;
                    static $k = 1;
                    static $$md;
                    static get $md() { return this.$$md ??= {"b":2412780,"c":[{"n":".ctor","o":"$ctor$2","d":3330284,"h":4298297580,"f":8}],"d":2412780,"h":3330284}; }
                    static get $b() { return $.$srij.System.Runtime.InteropServices.JavaScript.JSType; }
                    static get $fullName() { return `System.Runtime.InteropServices.JavaScript.JSType.MemoryView`; }
                }, $cls, ($v) => $cls.$_MemoryView = $v);
            }
            static $_Array$$;
            static Array$$(T)
            {
                let $cls = $.$srij.System.Runtime.InteropServices.JavaScript.JSType;
                return ($cls.$_Array$$ ??= $asm.$ncls("$srij.System.Runtime.InteropServices.JavaScript.JSType.Array<>", (T) => $asm.$gt("$srij.System.Runtime.InteropServices.JavaScript.JSType.Array<>", [T], ($self) => class Array$$ extends $.$srij.System.Runtime.InteropServices.JavaScript.JSType
                {
                    $ctor$2()
                    {
                        super.$ctor$1();
                        {
                        }
                        return this;
                    }
                    static $h = 2543852;
                    static $g = 1;
                    static $f = 0b10000000011010001;
                    static $k = 1;
                    static $$md;
                    static get $md() { return this.$$md ??= {"b":2412780,"c":[{"n":".ctor","o":"$ctor$2","d":this.$h,"h":Number(BigInt(this.$h)|0x100000000n),"f":8}],"g":[T?.$h??1507328],"r":1,"d":2412780,"h":this.$h}; }
                    static get $b() { return $.$srij.System.Runtime.InteropServices.JavaScript.JSType; }
                    static get $fullName() { return `System.Runtime.InteropServices.JavaScript.JSType.Array<${T?.$fullName}>`; }
                }), $cls, ($v) => $cls.$_Array$$ = $v))(T);
            }
            static $_Promise$$;
            static Promise$$(T)
            {
                let $cls = $.$srij.System.Runtime.InteropServices.JavaScript.JSType;
                return ($cls.$_Promise$$ ??= $asm.$ncls("$srij.System.Runtime.InteropServices.JavaScript.JSType.Promise<>", (T) => $asm.$gt("$srij.System.Runtime.InteropServices.JavaScript.JSType.Promise<>", [T], ($self) => class Promise$$ extends $.$srij.System.Runtime.InteropServices.JavaScript.JSType
                {
                    $ctor$2()
                    {
                        super.$ctor$1();
                        {
                        }
                        return this;
                    }
                    static $h = 3526892;
                    static $g = 1;
                    static $f = 0b10000000011010001;
                    static $k = 1;
                    static $$md;
                    static get $md() { return this.$$md ??= {"b":2412780,"c":[{"n":".ctor","o":"$ctor$2","d":this.$h,"h":Number(BigInt(this.$h)|0x100000000n),"f":8}],"g":[T?.$h??1507328],"r":1,"d":2412780,"h":this.$h}; }
                    static get $b() { return $.$srij.System.Runtime.InteropServices.JavaScript.JSType; }
                    static get $fullName() { return `System.Runtime.InteropServices.JavaScript.JSType.Promise<${T?.$fullName}>`; }
                }), $cls, ($v) => $cls.$_Promise$$ = $v))(T);
            }
            static $_Function;
            static get Function()
            {
                let $cls = $.$srij.System.Runtime.InteropServices.JavaScript.JSType;
                return $cls.$_Function ??= $asm.$ncls("$srij.System.Runtime.InteropServices.JavaScript.JSType.Function", ($self) => class Function extends $.$srij.System.Runtime.InteropServices.JavaScript.JSType
                {
                    $ctor$2()
                    {
                        super.$ctor$1();
                        {
                        }
                        return this;
                    }
                    static $h = 3002604;
                    static $f = 0b10000000010010001;
                    static $k = 1;
                    static $$md;
                    static get $md() { return this.$$md ??= {"b":2412780,"c":[{"n":".ctor","o":"$ctor$2","d":3002604,"h":4297969900,"f":8}],"d":2412780,"h":3002604}; }
                    static get $b() { return $.$srij.System.Runtime.InteropServices.JavaScript.JSType; }
                    static get $fullName() { return `System.Runtime.InteropServices.JavaScript.JSType.Function`; }
                }, $cls, ($v) => $cls.$_Function = $v);
            }
            static $_Function$$;
            static Function$$(T)
            {
                let $cls = $.$srij.System.Runtime.InteropServices.JavaScript.JSType;
                return ($cls.$_Function$$ ??= $asm.$ncls("$srij.System.Runtime.InteropServices.JavaScript.JSType.Function<>", (T) => $asm.$gt("$srij.System.Runtime.InteropServices.JavaScript.JSType.Function<>", [T], ($self) => class Function$$ extends $.$srij.System.Runtime.InteropServices.JavaScript.JSType
                {
                    $ctor$2()
                    {
                        super.$ctor$1();
                        {
                        }
                        return this;
                    }
                    static $h = 3264748;
                    static $g = 1;
                    static $f = 0b10000000011010001;
                    static $k = 1;
                    static $$md;
                    static get $md() { return this.$$md ??= {"b":2412780,"c":[{"n":".ctor","o":"$ctor$2","d":this.$h,"h":Number(BigInt(this.$h)|0x100000000n),"f":8}],"g":[T?.$h??1507328],"r":1,"d":2412780,"h":this.$h}; }
                    static get $b() { return $.$srij.System.Runtime.InteropServices.JavaScript.JSType; }
                    static get $fullName() { return `System.Runtime.InteropServices.JavaScript.JSType.Function<${T?.$fullName}>`; }
                }), $cls, ($v) => $cls.$_Function$$ = $v))(T);
            }
            static $_Function$$$;
            static Function$$$(T1, T2)
            {
                let $cls = $.$srij.System.Runtime.InteropServices.JavaScript.JSType;
                return ($cls.$_Function$$$ ??= $asm.$ncls("$srij.System.Runtime.InteropServices.JavaScript.JSType.Function<,>", (T1, T2) => $asm.$gt("$srij.System.Runtime.InteropServices.JavaScript.JSType.Function<,>", [T1, T2], ($self) => class Function$$$ extends $.$srij.System.Runtime.InteropServices.JavaScript.JSType
                {
                    $ctor$2()
                    {
                        super.$ctor$1();
                        {
                        }
                        return this;
                    }
                    static $h = 3199212;
                    static $g = 2;
                    static $f = 0b10000000011010001;
                    static $k = 1;
                    static $$md;
                    static get $md() { return this.$$md ??= {"b":2412780,"c":[{"n":".ctor","o":"$ctor$2","d":this.$h,"h":Number(BigInt(this.$h)|0x100000000n),"f":8}],"g":[T1?.$h??1507328,T2?.$h??1572864],"r":2,"d":2412780,"h":this.$h}; }
                    static get $b() { return $.$srij.System.Runtime.InteropServices.JavaScript.JSType; }
                    static get $fullName() { return `System.Runtime.InteropServices.JavaScript.JSType.Function<${T1?.$fullName},${T2?.$fullName}>`; }
                }), $cls, ($v) => $cls.$_Function$$$ = $v))(T1, T2);
            }
            static $_Function$$$$;
            static Function$$$$(T1, T2, T3)
            {
                let $cls = $.$srij.System.Runtime.InteropServices.JavaScript.JSType;
                return ($cls.$_Function$$$$ ??= $asm.$ncls("$srij.System.Runtime.InteropServices.JavaScript.JSType.Function<,,>", (T1, T2, T3) => $asm.$gt("$srij.System.Runtime.InteropServices.JavaScript.JSType.Function<,,>", [T1, T2, T3], ($self) => class Function$$$$ extends $.$srij.System.Runtime.InteropServices.JavaScript.JSType
                {
                    $ctor$2()
                    {
                        super.$ctor$1();
                        {
                        }
                        return this;
                    }
                    static $h = 3133676;
                    static $g = 3;
                    static $f = 0b10000000011010001;
                    static $k = 1;
                    static $$md;
                    static get $md() { return this.$$md ??= {"b":2412780,"c":[{"n":".ctor","o":"$ctor$2","d":this.$h,"h":Number(BigInt(this.$h)|0x100000000n),"f":8}],"g":[T1?.$h??1507328,T2?.$h??1572864,T3?.$h??1638400],"r":3,"d":2412780,"h":this.$h}; }
                    static get $b() { return $.$srij.System.Runtime.InteropServices.JavaScript.JSType; }
                    static get $fullName() { return `System.Runtime.InteropServices.JavaScript.JSType.Function<${T1?.$fullName},${T2?.$fullName},${T3?.$fullName}>`; }
                }), $cls, ($v) => $cls.$_Function$$$$ = $v))(T1, T2, T3);
            }
            static $_Function$$$$$;
            static Function$$$$$(T1, T2, T3, T4)
            {
                let $cls = $.$srij.System.Runtime.InteropServices.JavaScript.JSType;
                return ($cls.$_Function$$$$$ ??= $asm.$ncls("$srij.System.Runtime.InteropServices.JavaScript.JSType.Function<,,,>", (T1, T2, T3, T4) => $asm.$gt("$srij.System.Runtime.InteropServices.JavaScript.JSType.Function<,,,>", [T1, T2, T3, T4], ($self) => class Function$$$$$ extends $.$srij.System.Runtime.InteropServices.JavaScript.JSType
                {
                    $ctor$2()
                    {
                        super.$ctor$1();
                        {
                        }
                        return this;
                    }
                    static $h = 3068140;
                    static $g = 4;
                    static $f = 0b10000000011010001;
                    static $k = 1;
                    static $$md;
                    static get $md() { return this.$$md ??= {"b":2412780,"c":[{"n":".ctor","o":"$ctor$2","d":this.$h,"h":Number(BigInt(this.$h)|0x100000000n),"f":8}],"g":[T1?.$h??1507328,T2?.$h??1572864,T3?.$h??1638400,T4?.$h??1703936],"r":4,"d":2412780,"h":this.$h}; }
                    static get $b() { return $.$srij.System.Runtime.InteropServices.JavaScript.JSType; }
                    static get $fullName() { return `System.Runtime.InteropServices.JavaScript.JSType.Function<${T1?.$fullName},${T2?.$fullName},${T3?.$fullName},${T4?.$fullName}>`; }
                }), $cls, ($v) => $cls.$_Function$$$$$ = $v))(T1, T2, T3, T4);
            }
            static $_Any;
            static get Any()
            {
                let $cls = $.$srij.System.Runtime.InteropServices.JavaScript.JSType;
                return $cls.$_Any ??= $asm.$ncls("$srij.System.Runtime.InteropServices.JavaScript.JSType.Any", ($self) => class Any extends $.$srij.System.Runtime.InteropServices.JavaScript.JSType
                {
                    $ctor$2()
                    {
                        super.$ctor$1();
                        {
                        }
                        return this;
                    }
                    static $h = 2478316;
                    static $f = 0b10000000010010001;
                    static $k = 1;
                    static $$md;
                    static get $md() { return this.$$md ??= {"b":2412780,"c":[{"n":".ctor","o":"$ctor$2","d":2478316,"h":4297445612,"f":8}],"d":2412780,"h":2478316}; }
                    static get $b() { return $.$srij.System.Runtime.InteropServices.JavaScript.JSType; }
                    static get $fullName() { return `System.Runtime.InteropServices.JavaScript.JSType.Any`; }
                }, $cls, ($v) => $cls.$_Any = $v);
            }
            static $h = 2412780;
            static $f = 0b110001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"c":[{"n":".ctor","o":"$ctor$1","d":2412780,"h":4297380076,"f":8}],"j":[3657964,2805996,2871532,2674924,3395820,2609388,2740460,3592428,3461356,2937068,3330284,2543852,3526892,3002604,3264748,3199212,3133676,3068140,2478316],"h":2412780,"a":[{"t":114950145,"c":4409917441,"a":[{"v":"browser","t":1310721}]}]}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.Runtime.InteropServices.JavaScript.JSType`; }
        });
        
        $asm.$cls("$srij.Interop", ($self) => class Interop
        {
            static $_Runtime;
            static get Runtime()
            {
                let $cls = $.$srij.Interop;
                return $cls.$_Runtime ??= $asm.$ncls("$srij.Interop.Runtime", ($self) => class Runtime
                {
                    static $h = 184556;
                    static $f = 0b10000000000010000;
                    static $k = 1;
                    static $$md;
                    static get $md() { return this.$$md ??= {"b":131073,"d":119020,"h":184556}; }
                    static get $b() { return $.$spc.System.Object; }
                    static get $fullName() { return `Interop.Runtime`; }
                }, $cls, ($v) => $cls.$_Runtime = $v);
            }
            static $h = 119020;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"j":[184556],"h":119020}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `Interop`; }
        });
        
        $asm.$cls("$srij.System.Runtime.InteropServices.JavaScript.JavaScriptImports", ($self) => class JavaScriptImports
        {
            static /*bool */ HasProperty(/*global::System.Runtime.InteropServices.JavaScript.JSObject*/ self, /*string*/ propertyName)
            {
                if ($.$srij.System.Runtime.InteropServices.JavaScript.JavaScriptImports.__signature_HasProperty_393970128 === null)
                {
                    $.$srij.System.Runtime.InteropServices.JavaScript.JavaScriptImports.__signature_HasProperty_393970128 = $.$srij.System.Runtime.InteropServices.JavaScript.JSFunctionBinding.BindJSFunction("INTERNAL.has_property", null, $.$spc.System.ReadOnlySpan$$($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType).op_Implicit($.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType), [$.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType.Boolean, $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType.JSObject, $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType.String], null, null)));
                }
                {
                    /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ let ____arg_exception_native;
                    /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ let ____arg_return_native;
                    /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ let __self_native;
                    /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ let __propertyName_native;
                    /*bool*/ let __retVal;
                    /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ let __retVal_native;
                    $.$spc.System.Runtime.CompilerServices.Unsafe.SkipInit($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument, $.$ref(() => ____arg_return_native, ($v) => ____arg_return_native = $v, $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument));
                    ____arg_return_native.Initialize();
                    $.$spc.System.Runtime.CompilerServices.Unsafe.SkipInit($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument, $.$ref(() => ____arg_exception_native, ($v) => ____arg_exception_native = $v, $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument));
                    ____arg_exception_native.Initialize();
                    $.$spc.System.Runtime.CompilerServices.Unsafe.SkipInit($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument, $.$ref(() => __propertyName_native, ($v) => __propertyName_native = $v, $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument));
                    $.$spc.System.Runtime.CompilerServices.Unsafe.SkipInit($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument, $.$ref(() => __self_native, ($v) => __self_native = $v, $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument));
                    __propertyName_native.ToJS$29(propertyName);
                    __self_native.ToJS$27(self);
                    {
                        __retVal_native = __InvokeJSFunction.call(this, ____arg_exception_native.Clone(), ____arg_return_native.Clone(), __self_native.Clone(), __propertyName_native.Clone());
                    }
                    __retVal_native.ToManaged$17($.$ref(() => __retVal, ($v) => __retVal = $v, $.$spc.System.Boolean));
                    return __retVal;
                }
                /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/  function __InvokeJSFunction(/*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ ____arg_exception_native, /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ ____arg_return_native, /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ __self_native, /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ __propertyName_native)
                {
                    /*global::System.Span<global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument>*/ let __arguments_buffer = $.$spc.System.Span$$($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument).op_Implicit($.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument), [____arg_exception_native, ____arg_return_native, __self_native, __propertyName_native], null, null));
                    $.$srij.System.Runtime.InteropServices.JavaScript.JSFunctionBinding.InvokeJS($.$srij.System.Runtime.InteropServices.JavaScript.JavaScriptImports.__signature_HasProperty_393970128, __arguments_buffer);
                    return __arguments_buffer.get_Item(1).$v;
                }
            }
            /*global::System.Runtime.InteropServices.JavaScript.JSFunctionBinding*/ static __signature_HasProperty_393970128 = null;
            static /*string */ GetTypeOfProperty(/*global::System.Runtime.InteropServices.JavaScript.JSObject*/ self, /*string*/ propertyName)
            {
                if ($.$srij.System.Runtime.InteropServices.JavaScript.JavaScriptImports.__signature_GetTypeOfProperty_1139574135 === null)
                {
                    $.$srij.System.Runtime.InteropServices.JavaScript.JavaScriptImports.__signature_GetTypeOfProperty_1139574135 = $.$srij.System.Runtime.InteropServices.JavaScript.JSFunctionBinding.BindJSFunction("INTERNAL.get_typeof_property", null, $.$spc.System.ReadOnlySpan$$($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType).op_Implicit($.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType), [$.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType.String, $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType.JSObject, $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType.String], null, null)));
                }
                {
                    /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ let ____arg_exception_native;
                    /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ let ____arg_return_native;
                    /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ let __self_native;
                    /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ let __propertyName_native;
                    /*string*/ let __retVal;
                    /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ let __retVal_native;
                    $.$spc.System.Runtime.CompilerServices.Unsafe.SkipInit($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument, $.$ref(() => ____arg_return_native, ($v) => ____arg_return_native = $v, $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument));
                    ____arg_return_native.Initialize();
                    $.$spc.System.Runtime.CompilerServices.Unsafe.SkipInit($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument, $.$ref(() => ____arg_exception_native, ($v) => ____arg_exception_native = $v, $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument));
                    ____arg_exception_native.Initialize();
                    $.$spc.System.Runtime.CompilerServices.Unsafe.SkipInit($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument, $.$ref(() => __propertyName_native, ($v) => __propertyName_native = $v, $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument));
                    $.$spc.System.Runtime.CompilerServices.Unsafe.SkipInit($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument, $.$ref(() => __self_native, ($v) => __self_native = $v, $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument));
                    __propertyName_native.ToJS$29(propertyName);
                    __self_native.ToJS$27(self);
                    {
                        __retVal_native = __InvokeJSFunction.call(this, ____arg_exception_native.Clone(), ____arg_return_native.Clone(), __self_native.Clone(), __propertyName_native.Clone());
                    }
                    __retVal_native.ToManaged$29($.$ref(() => __retVal, ($v) => __retVal = $v, $.$spc.System.String));
                    return __retVal;
                }
                /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/  function __InvokeJSFunction(/*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ ____arg_exception_native, /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ ____arg_return_native, /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ __self_native, /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ __propertyName_native)
                {
                    /*global::System.Span<global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument>*/ let __arguments_buffer = $.$spc.System.Span$$($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument).op_Implicit($.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument), [____arg_exception_native, ____arg_return_native, __self_native, __propertyName_native], null, null));
                    $.$srij.System.Runtime.InteropServices.JavaScript.JSFunctionBinding.InvokeJS($.$srij.System.Runtime.InteropServices.JavaScript.JavaScriptImports.__signature_GetTypeOfProperty_1139574135, __arguments_buffer);
                    return __arguments_buffer.get_Item(1).$v;
                }
            }
            /*global::System.Runtime.InteropServices.JavaScript.JSFunctionBinding*/ static __signature_GetTypeOfProperty_1139574135 = null;
            static /*bool */ GetPropertyAsBoolean(/*global::System.Runtime.InteropServices.JavaScript.JSObject*/ self, /*string*/ propertyName)
            {
                if ($.$srij.System.Runtime.InteropServices.JavaScript.JavaScriptImports.__signature_GetPropertyAsBoolean_393970128 === null)
                {
                    $.$srij.System.Runtime.InteropServices.JavaScript.JavaScriptImports.__signature_GetPropertyAsBoolean_393970128 = $.$srij.System.Runtime.InteropServices.JavaScript.JSFunctionBinding.BindJSFunction("INTERNAL.get_property", null, $.$spc.System.ReadOnlySpan$$($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType).op_Implicit($.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType), [$.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType.Boolean, $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType.JSObject, $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType.String], null, null)));
                }
                {
                    /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ let ____arg_exception_native;
                    /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ let ____arg_return_native;
                    /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ let __self_native;
                    /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ let __propertyName_native;
                    /*bool*/ let __retVal;
                    /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ let __retVal_native;
                    $.$spc.System.Runtime.CompilerServices.Unsafe.SkipInit($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument, $.$ref(() => ____arg_return_native, ($v) => ____arg_return_native = $v, $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument));
                    ____arg_return_native.Initialize();
                    $.$spc.System.Runtime.CompilerServices.Unsafe.SkipInit($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument, $.$ref(() => ____arg_exception_native, ($v) => ____arg_exception_native = $v, $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument));
                    ____arg_exception_native.Initialize();
                    $.$spc.System.Runtime.CompilerServices.Unsafe.SkipInit($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument, $.$ref(() => __propertyName_native, ($v) => __propertyName_native = $v, $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument));
                    $.$spc.System.Runtime.CompilerServices.Unsafe.SkipInit($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument, $.$ref(() => __self_native, ($v) => __self_native = $v, $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument));
                    __propertyName_native.ToJS$29(propertyName);
                    __self_native.ToJS$27(self);
                    {
                        __retVal_native = __InvokeJSFunction.call(this, ____arg_exception_native.Clone(), ____arg_return_native.Clone(), __self_native.Clone(), __propertyName_native.Clone());
                    }
                    __retVal_native.ToManaged$17($.$ref(() => __retVal, ($v) => __retVal = $v, $.$spc.System.Boolean));
                    return __retVal;
                }
                /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/  function __InvokeJSFunction(/*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ ____arg_exception_native, /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ ____arg_return_native, /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ __self_native, /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ __propertyName_native)
                {
                    /*global::System.Span<global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument>*/ let __arguments_buffer = $.$spc.System.Span$$($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument).op_Implicit($.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument), [____arg_exception_native, ____arg_return_native, __self_native, __propertyName_native], null, null));
                    $.$srij.System.Runtime.InteropServices.JavaScript.JSFunctionBinding.InvokeJS($.$srij.System.Runtime.InteropServices.JavaScript.JavaScriptImports.__signature_GetPropertyAsBoolean_393970128, __arguments_buffer);
                    return __arguments_buffer.get_Item(1).$v;
                }
            }
            /*global::System.Runtime.InteropServices.JavaScript.JSFunctionBinding*/ static __signature_GetPropertyAsBoolean_393970128 = null;
            static /*int */ GetPropertyAsInt32(/*global::System.Runtime.InteropServices.JavaScript.JSObject*/ self, /*string*/ propertyName)
            {
                if ($.$srij.System.Runtime.InteropServices.JavaScript.JavaScriptImports.__signature_GetPropertyAsInt32_1813830729 === null)
                {
                    $.$srij.System.Runtime.InteropServices.JavaScript.JavaScriptImports.__signature_GetPropertyAsInt32_1813830729 = $.$srij.System.Runtime.InteropServices.JavaScript.JSFunctionBinding.BindJSFunction("INTERNAL.get_property", null, $.$spc.System.ReadOnlySpan$$($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType).op_Implicit($.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType), [$.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType.Int32, $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType.JSObject, $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType.String], null, null)));
                }
                {
                    /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ let ____arg_exception_native;
                    /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ let ____arg_return_native;
                    /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ let __self_native;
                    /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ let __propertyName_native;
                    /*int*/ let __retVal;
                    /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ let __retVal_native;
                    $.$spc.System.Runtime.CompilerServices.Unsafe.SkipInit($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument, $.$ref(() => ____arg_return_native, ($v) => ____arg_return_native = $v, $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument));
                    ____arg_return_native.Initialize();
                    $.$spc.System.Runtime.CompilerServices.Unsafe.SkipInit($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument, $.$ref(() => ____arg_exception_native, ($v) => ____arg_exception_native = $v, $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument));
                    ____arg_exception_native.Initialize();
                    $.$spc.System.Runtime.CompilerServices.Unsafe.SkipInit($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument, $.$ref(() => __propertyName_native, ($v) => __propertyName_native = $v, $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument));
                    $.$spc.System.Runtime.CompilerServices.Unsafe.SkipInit($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument, $.$ref(() => __self_native, ($v) => __self_native = $v, $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument));
                    __propertyName_native.ToJS$29(propertyName);
                    __self_native.ToJS$27(self);
                    {
                        __retVal_native = __InvokeJSFunction.call(this, ____arg_exception_native.Clone(), ____arg_return_native.Clone(), __self_native.Clone(), __propertyName_native.Clone());
                    }
                    __retVal_native.ToManaged$31($.$ref(() => __retVal, ($v) => __retVal = $v, $.$spc.System.Int32));
                    return __retVal;
                }
                /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/  function __InvokeJSFunction(/*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ ____arg_exception_native, /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ ____arg_return_native, /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ __self_native, /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ __propertyName_native)
                {
                    /*global::System.Span<global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument>*/ let __arguments_buffer = $.$spc.System.Span$$($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument).op_Implicit($.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument), [____arg_exception_native, ____arg_return_native, __self_native, __propertyName_native], null, null));
                    $.$srij.System.Runtime.InteropServices.JavaScript.JSFunctionBinding.InvokeJS($.$srij.System.Runtime.InteropServices.JavaScript.JavaScriptImports.__signature_GetPropertyAsInt32_1813830729, __arguments_buffer);
                    return __arguments_buffer.get_Item(1).$v;
                }
            }
            /*global::System.Runtime.InteropServices.JavaScript.JSFunctionBinding*/ static __signature_GetPropertyAsInt32_1813830729 = null;
            static /*double */ GetPropertyAsDouble(/*global::System.Runtime.InteropServices.JavaScript.JSObject*/ self, /*string*/ propertyName)
            {
                if ($.$srij.System.Runtime.InteropServices.JavaScript.JavaScriptImports.__signature_GetPropertyAsDouble_705601847 === null)
                {
                    $.$srij.System.Runtime.InteropServices.JavaScript.JavaScriptImports.__signature_GetPropertyAsDouble_705601847 = $.$srij.System.Runtime.InteropServices.JavaScript.JSFunctionBinding.BindJSFunction("INTERNAL.get_property", null, $.$spc.System.ReadOnlySpan$$($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType).op_Implicit($.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType), [$.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType.Double, $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType.JSObject, $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType.String], null, null)));
                }
                {
                    /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ let ____arg_exception_native;
                    /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ let ____arg_return_native;
                    /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ let __self_native;
                    /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ let __propertyName_native;
                    /*double*/ let __retVal;
                    /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ let __retVal_native;
                    $.$spc.System.Runtime.CompilerServices.Unsafe.SkipInit($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument, $.$ref(() => ____arg_return_native, ($v) => ____arg_return_native = $v, $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument));
                    ____arg_return_native.Initialize();
                    $.$spc.System.Runtime.CompilerServices.Unsafe.SkipInit($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument, $.$ref(() => ____arg_exception_native, ($v) => ____arg_exception_native = $v, $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument));
                    ____arg_exception_native.Initialize();
                    $.$spc.System.Runtime.CompilerServices.Unsafe.SkipInit($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument, $.$ref(() => __propertyName_native, ($v) => __propertyName_native = $v, $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument));
                    $.$spc.System.Runtime.CompilerServices.Unsafe.SkipInit($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument, $.$ref(() => __self_native, ($v) => __self_native = $v, $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument));
                    __propertyName_native.ToJS$29(propertyName);
                    __self_native.ToJS$27(self);
                    {
                        __retVal_native = __InvokeJSFunction.call(this, ____arg_exception_native.Clone(), ____arg_return_native.Clone(), __self_native.Clone(), __propertyName_native.Clone());
                    }
                    __retVal_native.ToManaged$4($.$ref(() => __retVal, ($v) => __retVal = $v, $.$spc.System.Double));
                    return __retVal;
                }
                /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/  function __InvokeJSFunction(/*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ ____arg_exception_native, /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ ____arg_return_native, /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ __self_native, /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ __propertyName_native)
                {
                    /*global::System.Span<global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument>*/ let __arguments_buffer = $.$spc.System.Span$$($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument).op_Implicit($.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument), [____arg_exception_native, ____arg_return_native, __self_native, __propertyName_native], null, null));
                    $.$srij.System.Runtime.InteropServices.JavaScript.JSFunctionBinding.InvokeJS($.$srij.System.Runtime.InteropServices.JavaScript.JavaScriptImports.__signature_GetPropertyAsDouble_705601847, __arguments_buffer);
                    return __arguments_buffer.get_Item(1).$v;
                }
            }
            /*global::System.Runtime.InteropServices.JavaScript.JSFunctionBinding*/ static __signature_GetPropertyAsDouble_705601847 = null;
            static /*string */ GetPropertyAsString(/*global::System.Runtime.InteropServices.JavaScript.JSObject*/ self, /*string*/ propertyName)
            {
                if ($.$srij.System.Runtime.InteropServices.JavaScript.JavaScriptImports.__signature_GetPropertyAsString_1139574135 === null)
                {
                    $.$srij.System.Runtime.InteropServices.JavaScript.JavaScriptImports.__signature_GetPropertyAsString_1139574135 = $.$srij.System.Runtime.InteropServices.JavaScript.JSFunctionBinding.BindJSFunction("INTERNAL.get_property", null, $.$spc.System.ReadOnlySpan$$($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType).op_Implicit($.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType), [$.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType.String, $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType.JSObject, $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType.String], null, null)));
                }
                {
                    /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ let ____arg_exception_native;
                    /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ let ____arg_return_native;
                    /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ let __self_native;
                    /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ let __propertyName_native;
                    /*string*/ let __retVal;
                    /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ let __retVal_native;
                    $.$spc.System.Runtime.CompilerServices.Unsafe.SkipInit($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument, $.$ref(() => ____arg_return_native, ($v) => ____arg_return_native = $v, $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument));
                    ____arg_return_native.Initialize();
                    $.$spc.System.Runtime.CompilerServices.Unsafe.SkipInit($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument, $.$ref(() => ____arg_exception_native, ($v) => ____arg_exception_native = $v, $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument));
                    ____arg_exception_native.Initialize();
                    $.$spc.System.Runtime.CompilerServices.Unsafe.SkipInit($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument, $.$ref(() => __propertyName_native, ($v) => __propertyName_native = $v, $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument));
                    $.$spc.System.Runtime.CompilerServices.Unsafe.SkipInit($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument, $.$ref(() => __self_native, ($v) => __self_native = $v, $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument));
                    __propertyName_native.ToJS$29(propertyName);
                    __self_native.ToJS$27(self);
                    {
                        __retVal_native = __InvokeJSFunction.call(this, ____arg_exception_native.Clone(), ____arg_return_native.Clone(), __self_native.Clone(), __propertyName_native.Clone());
                    }
                    __retVal_native.ToManaged$29($.$ref(() => __retVal, ($v) => __retVal = $v, $.$spc.System.String));
                    return __retVal;
                }
                /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/  function __InvokeJSFunction(/*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ ____arg_exception_native, /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ ____arg_return_native, /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ __self_native, /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ __propertyName_native)
                {
                    /*global::System.Span<global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument>*/ let __arguments_buffer = $.$spc.System.Span$$($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument).op_Implicit($.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument), [____arg_exception_native, ____arg_return_native, __self_native, __propertyName_native], null, null));
                    $.$srij.System.Runtime.InteropServices.JavaScript.JSFunctionBinding.InvokeJS($.$srij.System.Runtime.InteropServices.JavaScript.JavaScriptImports.__signature_GetPropertyAsString_1139574135, __arguments_buffer);
                    return __arguments_buffer.get_Item(1).$v;
                }
            }
            /*global::System.Runtime.InteropServices.JavaScript.JSFunctionBinding*/ static __signature_GetPropertyAsString_1139574135 = null;
            static /*global::System.Runtime.InteropServices.JavaScript.JSObject */ GetPropertyAsJSObject(/*global::System.Runtime.InteropServices.JavaScript.JSObject*/ self, /*string*/ propertyName)
            {
                if ($.$srij.System.Runtime.InteropServices.JavaScript.JavaScriptImports.__signature_GetPropertyAsJSObject_1480020778 === null)
                {
                    $.$srij.System.Runtime.InteropServices.JavaScript.JavaScriptImports.__signature_GetPropertyAsJSObject_1480020778 = $.$srij.System.Runtime.InteropServices.JavaScript.JSFunctionBinding.BindJSFunction("INTERNAL.get_property", null, $.$spc.System.ReadOnlySpan$$($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType).op_Implicit($.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType), [$.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType.JSObject, $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType.JSObject, $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType.String], null, null)));
                }
                {
                    /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ let ____arg_exception_native;
                    /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ let ____arg_return_native;
                    /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ let __self_native;
                    /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ let __propertyName_native;
                    /*global::System.Runtime.InteropServices.JavaScript.JSObject*/ let __retVal;
                    /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ let __retVal_native;
                    $.$spc.System.Runtime.CompilerServices.Unsafe.SkipInit($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument, $.$ref(() => ____arg_return_native, ($v) => ____arg_return_native = $v, $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument));
                    ____arg_return_native.Initialize();
                    $.$spc.System.Runtime.CompilerServices.Unsafe.SkipInit($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument, $.$ref(() => ____arg_exception_native, ($v) => ____arg_exception_native = $v, $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument));
                    ____arg_exception_native.Initialize();
                    $.$spc.System.Runtime.CompilerServices.Unsafe.SkipInit($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument, $.$ref(() => __propertyName_native, ($v) => __propertyName_native = $v, $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument));
                    $.$spc.System.Runtime.CompilerServices.Unsafe.SkipInit($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument, $.$ref(() => __self_native, ($v) => __self_native = $v, $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument));
                    __propertyName_native.ToJS$29(propertyName);
                    __self_native.ToJS$27(self);
                    {
                        __retVal_native = __InvokeJSFunction.call(this, ____arg_exception_native.Clone(), ____arg_return_native.Clone(), __self_native.Clone(), __propertyName_native.Clone());
                    }
                    __retVal_native.ToManaged$27($.$ref(() => __retVal, ($v) => __retVal = $v, $.$srij.System.Runtime.InteropServices.JavaScript.JSObject));
                    return __retVal;
                }
                /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/  function __InvokeJSFunction(/*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ ____arg_exception_native, /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ ____arg_return_native, /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ __self_native, /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ __propertyName_native)
                {
                    /*global::System.Span<global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument>*/ let __arguments_buffer = $.$spc.System.Span$$($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument).op_Implicit($.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument), [____arg_exception_native, ____arg_return_native, __self_native, __propertyName_native], null, null));
                    $.$srij.System.Runtime.InteropServices.JavaScript.JSFunctionBinding.InvokeJS($.$srij.System.Runtime.InteropServices.JavaScript.JavaScriptImports.__signature_GetPropertyAsJSObject_1480020778, __arguments_buffer);
                    return __arguments_buffer.get_Item(1).$v;
                }
            }
            /*global::System.Runtime.InteropServices.JavaScript.JSFunctionBinding*/ static __signature_GetPropertyAsJSObject_1480020778 = null;
            static /*byte[] */ GetPropertyAsByteArray(/*global::System.Runtime.InteropServices.JavaScript.JSObject*/ self, /*string*/ propertyName)
            {
                if ($.$srij.System.Runtime.InteropServices.JavaScript.JavaScriptImports.__signature_GetPropertyAsByteArray_657551312 === null)
                {
                    $.$srij.System.Runtime.InteropServices.JavaScript.JavaScriptImports.__signature_GetPropertyAsByteArray_657551312 = $.$srij.System.Runtime.InteropServices.JavaScript.JSFunctionBinding.BindJSFunction("INTERNAL.get_property", null, $.$spc.System.ReadOnlySpan$$($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType).op_Implicit($.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType), [$.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType.Array($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType.Byte), $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType.JSObject, $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType.String], null, null)));
                }
                {
                    /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ let ____arg_exception_native;
                    /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ let ____arg_return_native;
                    /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ let __self_native;
                    /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ let __propertyName_native;
                    /*byte[]*/ let __retVal;
                    /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ let __retVal_native;
                    $.$spc.System.Runtime.CompilerServices.Unsafe.SkipInit($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument, $.$ref(() => ____arg_return_native, ($v) => ____arg_return_native = $v, $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument));
                    ____arg_return_native.Initialize();
                    $.$spc.System.Runtime.CompilerServices.Unsafe.SkipInit($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument, $.$ref(() => ____arg_exception_native, ($v) => ____arg_exception_native = $v, $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument));
                    ____arg_exception_native.Initialize();
                    $.$spc.System.Runtime.CompilerServices.Unsafe.SkipInit($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument, $.$ref(() => __propertyName_native, ($v) => __propertyName_native = $v, $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument));
                    $.$spc.System.Runtime.CompilerServices.Unsafe.SkipInit($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument, $.$ref(() => __self_native, ($v) => __self_native = $v, $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument));
                    __propertyName_native.ToJS$29(propertyName);
                    __self_native.ToJS$27(self);
                    {
                        __retVal_native = __InvokeJSFunction.call(this, ____arg_exception_native.Clone(), ____arg_return_native.Clone(), __self_native.Clone(), __propertyName_native.Clone());
                    }
                    __retVal_native.ToManaged$21($.$ref(() => __retVal, ($v) => __retVal = $v, $.$typeArray($.$spc.System.Byte)));
                    return __retVal;
                }
                /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/  function __InvokeJSFunction(/*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ ____arg_exception_native, /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ ____arg_return_native, /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ __self_native, /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ __propertyName_native)
                {
                    /*global::System.Span<global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument>*/ let __arguments_buffer = $.$spc.System.Span$$($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument).op_Implicit($.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument), [____arg_exception_native, ____arg_return_native, __self_native, __propertyName_native], null, null));
                    $.$srij.System.Runtime.InteropServices.JavaScript.JSFunctionBinding.InvokeJS($.$srij.System.Runtime.InteropServices.JavaScript.JavaScriptImports.__signature_GetPropertyAsByteArray_657551312, __arguments_buffer);
                    return __arguments_buffer.get_Item(1).$v;
                }
            }
            /*global::System.Runtime.InteropServices.JavaScript.JSFunctionBinding*/ static __signature_GetPropertyAsByteArray_657551312 = null;
            static /*void */ SetPropertyBool(/*global::System.Runtime.InteropServices.JavaScript.JSObject*/ self, /*string*/ propertyName, /*bool*/ value)
            {
                if ($.$srij.System.Runtime.InteropServices.JavaScript.JavaScriptImports.__signature_SetPropertyBool_125660004 === null)
                {
                    $.$srij.System.Runtime.InteropServices.JavaScript.JavaScriptImports.__signature_SetPropertyBool_125660004 = $.$srij.System.Runtime.InteropServices.JavaScript.JSFunctionBinding.BindJSFunction("INTERNAL.set_property", null, $.$spc.System.ReadOnlySpan$$($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType).op_Implicit($.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType), [$.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType.Discard, $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType.JSObject, $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType.String, $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType.Boolean], null, null)));
                }
                {
                    /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ let ____arg_exception_native;
                    /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ let ____arg_return_native;
                    /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ let __self_native;
                    /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ let __propertyName_native;
                    /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ let __value_native;
                    $.$spc.System.Runtime.CompilerServices.Unsafe.SkipInit($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument, $.$ref(() => ____arg_return_native, ($v) => ____arg_return_native = $v, $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument));
                    ____arg_return_native.Initialize();
                    $.$spc.System.Runtime.CompilerServices.Unsafe.SkipInit($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument, $.$ref(() => ____arg_exception_native, ($v) => ____arg_exception_native = $v, $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument));
                    ____arg_exception_native.Initialize();
                    $.$spc.System.Runtime.CompilerServices.Unsafe.SkipInit($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument, $.$ref(() => __value_native, ($v) => __value_native = $v, $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument));
                    $.$spc.System.Runtime.CompilerServices.Unsafe.SkipInit($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument, $.$ref(() => __propertyName_native, ($v) => __propertyName_native = $v, $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument));
                    $.$spc.System.Runtime.CompilerServices.Unsafe.SkipInit($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument, $.$ref(() => __self_native, ($v) => __self_native = $v, $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument));
                    __value_native.ToJS$17(value);
                    __propertyName_native.ToJS$29(propertyName);
                    __self_native.ToJS$27(self);
                    {
                        __InvokeJSFunction.call(this, ____arg_exception_native.Clone(), ____arg_return_native.Clone(), __self_native.Clone(), __propertyName_native.Clone(), __value_native.Clone());
                    }
                }
                /*void*/  function __InvokeJSFunction(/*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ ____arg_exception_native, /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ ____arg_return_native, /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ __self_native, /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ __propertyName_native, /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ __value_native)
                {
                    $.$srij.System.Runtime.InteropServices.JavaScript.JSFunctionBinding.InvokeJS($.$srij.System.Runtime.InteropServices.JavaScript.JavaScriptImports.__signature_SetPropertyBool_125660004, $.$spc.System.Span$$($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument).op_Implicit($.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument), [____arg_exception_native, ____arg_return_native, __self_native, __propertyName_native, __value_native], null, null)));
                }
            }
            /*global::System.Runtime.InteropServices.JavaScript.JSFunctionBinding*/ static __signature_SetPropertyBool_125660004 = null;
            static /*void */ SetPropertyInt(/*global::System.Runtime.InteropServices.JavaScript.JSObject*/ self, /*string*/ propertyName, /*int*/ value)
            {
                if ($.$srij.System.Runtime.InteropServices.JavaScript.JavaScriptImports.__signature_SetPropertyInt_512418141 === null)
                {
                    $.$srij.System.Runtime.InteropServices.JavaScript.JavaScriptImports.__signature_SetPropertyInt_512418141 = $.$srij.System.Runtime.InteropServices.JavaScript.JSFunctionBinding.BindJSFunction("INTERNAL.set_property", null, $.$spc.System.ReadOnlySpan$$($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType).op_Implicit($.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType), [$.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType.Discard, $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType.JSObject, $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType.String, $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType.Int32], null, null)));
                }
                {
                    /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ let ____arg_exception_native;
                    /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ let ____arg_return_native;
                    /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ let __self_native;
                    /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ let __propertyName_native;
                    /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ let __value_native;
                    $.$spc.System.Runtime.CompilerServices.Unsafe.SkipInit($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument, $.$ref(() => ____arg_return_native, ($v) => ____arg_return_native = $v, $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument));
                    ____arg_return_native.Initialize();
                    $.$spc.System.Runtime.CompilerServices.Unsafe.SkipInit($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument, $.$ref(() => ____arg_exception_native, ($v) => ____arg_exception_native = $v, $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument));
                    ____arg_exception_native.Initialize();
                    $.$spc.System.Runtime.CompilerServices.Unsafe.SkipInit($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument, $.$ref(() => __value_native, ($v) => __value_native = $v, $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument));
                    $.$spc.System.Runtime.CompilerServices.Unsafe.SkipInit($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument, $.$ref(() => __propertyName_native, ($v) => __propertyName_native = $v, $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument));
                    $.$spc.System.Runtime.CompilerServices.Unsafe.SkipInit($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument, $.$ref(() => __self_native, ($v) => __self_native = $v, $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument));
                    __value_native.ToJS$31(value);
                    __propertyName_native.ToJS$29(propertyName);
                    __self_native.ToJS$27(self);
                    {
                        __InvokeJSFunction.call(this, ____arg_exception_native.Clone(), ____arg_return_native.Clone(), __self_native.Clone(), __propertyName_native.Clone(), __value_native.Clone());
                    }
                }
                /*void*/  function __InvokeJSFunction(/*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ ____arg_exception_native, /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ ____arg_return_native, /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ __self_native, /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ __propertyName_native, /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ __value_native)
                {
                    $.$srij.System.Runtime.InteropServices.JavaScript.JSFunctionBinding.InvokeJS($.$srij.System.Runtime.InteropServices.JavaScript.JavaScriptImports.__signature_SetPropertyInt_512418141, $.$spc.System.Span$$($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument).op_Implicit($.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument), [____arg_exception_native, ____arg_return_native, __self_native, __propertyName_native, __value_native], null, null)));
                }
            }
            /*global::System.Runtime.InteropServices.JavaScript.JSFunctionBinding*/ static __signature_SetPropertyInt_512418141 = null;
            static /*void */ SetPropertyDouble(/*global::System.Runtime.InteropServices.JavaScript.JSObject*/ self, /*string*/ propertyName, /*double*/ value)
            {
                if ($.$srij.System.Runtime.InteropServices.JavaScript.JavaScriptImports.__signature_SetPropertyDouble_1393852235 === null)
                {
                    $.$srij.System.Runtime.InteropServices.JavaScript.JavaScriptImports.__signature_SetPropertyDouble_1393852235 = $.$srij.System.Runtime.InteropServices.JavaScript.JSFunctionBinding.BindJSFunction("INTERNAL.set_property", null, $.$spc.System.ReadOnlySpan$$($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType).op_Implicit($.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType), [$.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType.Discard, $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType.JSObject, $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType.String, $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType.Double], null, null)));
                }
                {
                    /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ let ____arg_exception_native;
                    /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ let ____arg_return_native;
                    /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ let __self_native;
                    /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ let __propertyName_native;
                    /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ let __value_native;
                    $.$spc.System.Runtime.CompilerServices.Unsafe.SkipInit($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument, $.$ref(() => ____arg_return_native, ($v) => ____arg_return_native = $v, $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument));
                    ____arg_return_native.Initialize();
                    $.$spc.System.Runtime.CompilerServices.Unsafe.SkipInit($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument, $.$ref(() => ____arg_exception_native, ($v) => ____arg_exception_native = $v, $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument));
                    ____arg_exception_native.Initialize();
                    $.$spc.System.Runtime.CompilerServices.Unsafe.SkipInit($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument, $.$ref(() => __value_native, ($v) => __value_native = $v, $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument));
                    $.$spc.System.Runtime.CompilerServices.Unsafe.SkipInit($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument, $.$ref(() => __propertyName_native, ($v) => __propertyName_native = $v, $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument));
                    $.$spc.System.Runtime.CompilerServices.Unsafe.SkipInit($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument, $.$ref(() => __self_native, ($v) => __self_native = $v, $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument));
                    __value_native.ToJS$4(value);
                    __propertyName_native.ToJS$29(propertyName);
                    __self_native.ToJS$27(self);
                    {
                        __InvokeJSFunction.call(this, ____arg_exception_native.Clone(), ____arg_return_native.Clone(), __self_native.Clone(), __propertyName_native.Clone(), __value_native.Clone());
                    }
                }
                /*void*/  function __InvokeJSFunction(/*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ ____arg_exception_native, /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ ____arg_return_native, /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ __self_native, /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ __propertyName_native, /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ __value_native)
                {
                    $.$srij.System.Runtime.InteropServices.JavaScript.JSFunctionBinding.InvokeJS($.$srij.System.Runtime.InteropServices.JavaScript.JavaScriptImports.__signature_SetPropertyDouble_1393852235, $.$spc.System.Span$$($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument).op_Implicit($.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument), [____arg_exception_native, ____arg_return_native, __self_native, __propertyName_native, __value_native], null, null)));
                }
            }
            /*global::System.Runtime.InteropServices.JavaScript.JSFunctionBinding*/ static __signature_SetPropertyDouble_1393852235 = null;
            static /*void */ SetPropertyString(/*global::System.Runtime.InteropServices.JavaScript.JSObject*/ self, /*string*/ propertyName, /*string*/ value)
            {
                if ($.$srij.System.Runtime.InteropServices.JavaScript.JavaScriptImports.__signature_SetPropertyString_1189495691 === null)
                {
                    $.$srij.System.Runtime.InteropServices.JavaScript.JavaScriptImports.__signature_SetPropertyString_1189495691 = $.$srij.System.Runtime.InteropServices.JavaScript.JSFunctionBinding.BindJSFunction("INTERNAL.set_property", null, $.$spc.System.ReadOnlySpan$$($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType).op_Implicit($.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType), [$.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType.Discard, $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType.JSObject, $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType.String, $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType.String], null, null)));
                }
                {
                    /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ let ____arg_exception_native;
                    /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ let ____arg_return_native;
                    /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ let __self_native;
                    /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ let __propertyName_native;
                    /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ let __value_native;
                    $.$spc.System.Runtime.CompilerServices.Unsafe.SkipInit($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument, $.$ref(() => ____arg_return_native, ($v) => ____arg_return_native = $v, $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument));
                    ____arg_return_native.Initialize();
                    $.$spc.System.Runtime.CompilerServices.Unsafe.SkipInit($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument, $.$ref(() => ____arg_exception_native, ($v) => ____arg_exception_native = $v, $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument));
                    ____arg_exception_native.Initialize();
                    $.$spc.System.Runtime.CompilerServices.Unsafe.SkipInit($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument, $.$ref(() => __value_native, ($v) => __value_native = $v, $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument));
                    $.$spc.System.Runtime.CompilerServices.Unsafe.SkipInit($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument, $.$ref(() => __propertyName_native, ($v) => __propertyName_native = $v, $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument));
                    $.$spc.System.Runtime.CompilerServices.Unsafe.SkipInit($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument, $.$ref(() => __self_native, ($v) => __self_native = $v, $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument));
                    __value_native.ToJS$29(value);
                    __propertyName_native.ToJS$29(propertyName);
                    __self_native.ToJS$27(self);
                    {
                        __InvokeJSFunction.call(this, ____arg_exception_native.Clone(), ____arg_return_native.Clone(), __self_native.Clone(), __propertyName_native.Clone(), __value_native.Clone());
                    }
                }
                /*void*/  function __InvokeJSFunction(/*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ ____arg_exception_native, /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ ____arg_return_native, /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ __self_native, /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ __propertyName_native, /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ __value_native)
                {
                    $.$srij.System.Runtime.InteropServices.JavaScript.JSFunctionBinding.InvokeJS($.$srij.System.Runtime.InteropServices.JavaScript.JavaScriptImports.__signature_SetPropertyString_1189495691, $.$spc.System.Span$$($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument).op_Implicit($.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument), [____arg_exception_native, ____arg_return_native, __self_native, __propertyName_native, __value_native], null, null)));
                }
            }
            /*global::System.Runtime.InteropServices.JavaScript.JSFunctionBinding*/ static __signature_SetPropertyString_1189495691 = null;
            static /*void */ SetPropertyJSObject(/*global::System.Runtime.InteropServices.JavaScript.JSObject*/ self, /*string*/ propertyName, /*global::System.Runtime.InteropServices.JavaScript.JSObject*/ value)
            {
                if ($.$srij.System.Runtime.InteropServices.JavaScript.JavaScriptImports.__signature_SetPropertyJSObject_2027749310 === null)
                {
                    $.$srij.System.Runtime.InteropServices.JavaScript.JavaScriptImports.__signature_SetPropertyJSObject_2027749310 = $.$srij.System.Runtime.InteropServices.JavaScript.JSFunctionBinding.BindJSFunction("INTERNAL.set_property", null, $.$spc.System.ReadOnlySpan$$($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType).op_Implicit($.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType), [$.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType.Discard, $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType.JSObject, $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType.String, $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType.JSObject], null, null)));
                }
                {
                    /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ let ____arg_exception_native;
                    /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ let ____arg_return_native;
                    /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ let __self_native;
                    /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ let __propertyName_native;
                    /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ let __value_native;
                    $.$spc.System.Runtime.CompilerServices.Unsafe.SkipInit($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument, $.$ref(() => ____arg_return_native, ($v) => ____arg_return_native = $v, $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument));
                    ____arg_return_native.Initialize();
                    $.$spc.System.Runtime.CompilerServices.Unsafe.SkipInit($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument, $.$ref(() => ____arg_exception_native, ($v) => ____arg_exception_native = $v, $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument));
                    ____arg_exception_native.Initialize();
                    $.$spc.System.Runtime.CompilerServices.Unsafe.SkipInit($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument, $.$ref(() => __value_native, ($v) => __value_native = $v, $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument));
                    $.$spc.System.Runtime.CompilerServices.Unsafe.SkipInit($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument, $.$ref(() => __propertyName_native, ($v) => __propertyName_native = $v, $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument));
                    $.$spc.System.Runtime.CompilerServices.Unsafe.SkipInit($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument, $.$ref(() => __self_native, ($v) => __self_native = $v, $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument));
                    __value_native.ToJS$27(value);
                    __propertyName_native.ToJS$29(propertyName);
                    __self_native.ToJS$27(self);
                    {
                        __InvokeJSFunction.call(this, ____arg_exception_native.Clone(), ____arg_return_native.Clone(), __self_native.Clone(), __propertyName_native.Clone(), __value_native.Clone());
                    }
                }
                /*void*/  function __InvokeJSFunction(/*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ ____arg_exception_native, /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ ____arg_return_native, /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ __self_native, /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ __propertyName_native, /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ __value_native)
                {
                    $.$srij.System.Runtime.InteropServices.JavaScript.JSFunctionBinding.InvokeJS($.$srij.System.Runtime.InteropServices.JavaScript.JavaScriptImports.__signature_SetPropertyJSObject_2027749310, $.$spc.System.Span$$($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument).op_Implicit($.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument), [____arg_exception_native, ____arg_return_native, __self_native, __propertyName_native, __value_native], null, null)));
                }
            }
            /*global::System.Runtime.InteropServices.JavaScript.JSFunctionBinding*/ static __signature_SetPropertyJSObject_2027749310 = null;
            static /*void */ SetPropertyBytes(/*global::System.Runtime.InteropServices.JavaScript.JSObject*/ self, /*string*/ propertyName, /*byte[]*/ value)
            {
                if ($.$srij.System.Runtime.InteropServices.JavaScript.JavaScriptImports.__signature_SetPropertyBytes_1317820772 === null)
                {
                    $.$srij.System.Runtime.InteropServices.JavaScript.JavaScriptImports.__signature_SetPropertyBytes_1317820772 = $.$srij.System.Runtime.InteropServices.JavaScript.JSFunctionBinding.BindJSFunction("INTERNAL.set_property", null, $.$spc.System.ReadOnlySpan$$($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType).op_Implicit($.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType), [$.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType.Discard, $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType.JSObject, $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType.String, $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType.Array($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType.Byte)], null, null)));
                }
                {
                    /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ let ____arg_exception_native;
                    /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ let ____arg_return_native;
                    /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ let __self_native;
                    /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ let __propertyName_native;
                    /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ let __value_native;
                    $.$spc.System.Runtime.CompilerServices.Unsafe.SkipInit($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument, $.$ref(() => ____arg_return_native, ($v) => ____arg_return_native = $v, $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument));
                    ____arg_return_native.Initialize();
                    $.$spc.System.Runtime.CompilerServices.Unsafe.SkipInit($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument, $.$ref(() => ____arg_exception_native, ($v) => ____arg_exception_native = $v, $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument));
                    ____arg_exception_native.Initialize();
                    $.$spc.System.Runtime.CompilerServices.Unsafe.SkipInit($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument, $.$ref(() => __value_native, ($v) => __value_native = $v, $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument));
                    $.$spc.System.Runtime.CompilerServices.Unsafe.SkipInit($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument, $.$ref(() => __propertyName_native, ($v) => __propertyName_native = $v, $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument));
                    $.$spc.System.Runtime.CompilerServices.Unsafe.SkipInit($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument, $.$ref(() => __self_native, ($v) => __self_native = $v, $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument));
                    __value_native.ToJS$21(value);
                    __propertyName_native.ToJS$29(propertyName);
                    __self_native.ToJS$27(self);
                    {
                        __InvokeJSFunction.call(this, ____arg_exception_native.Clone(), ____arg_return_native.Clone(), __self_native.Clone(), __propertyName_native.Clone(), __value_native.Clone());
                    }
                }
                /*void*/  function __InvokeJSFunction(/*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ ____arg_exception_native, /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ ____arg_return_native, /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ __self_native, /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ __propertyName_native, /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ __value_native)
                {
                    $.$srij.System.Runtime.InteropServices.JavaScript.JSFunctionBinding.InvokeJS($.$srij.System.Runtime.InteropServices.JavaScript.JavaScriptImports.__signature_SetPropertyBytes_1317820772, $.$spc.System.Span$$($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument).op_Implicit($.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument), [____arg_exception_native, ____arg_return_native, __self_native, __propertyName_native, __value_native], null, null)));
                }
            }
            /*global::System.Runtime.InteropServices.JavaScript.JSFunctionBinding*/ static __signature_SetPropertyBytes_1317820772 = null;
            static /*global::System.Runtime.InteropServices.JavaScript.JSObject */ GetGlobalThis()
            {
                if ($.$srij.System.Runtime.InteropServices.JavaScript.JavaScriptImports.__signature_GetGlobalThis_1202228629 === null)
                {
                    $.$srij.System.Runtime.InteropServices.JavaScript.JavaScriptImports.__signature_GetGlobalThis_1202228629 = $.$srij.System.Runtime.InteropServices.JavaScript.JSFunctionBinding.BindJSFunction("INTERNAL.get_global_this", null, $.$spc.System.ReadOnlySpan$$($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType).op_Implicit($.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType), [$.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType.JSObject], null, null)));
                }
                {
                    /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ let ____arg_exception_native;
                    /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ let ____arg_return_native;
                    /*global::System.Runtime.InteropServices.JavaScript.JSObject*/ let __retVal;
                    /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ let __retVal_native;
                    $.$spc.System.Runtime.CompilerServices.Unsafe.SkipInit($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument, $.$ref(() => ____arg_return_native, ($v) => ____arg_return_native = $v, $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument));
                    ____arg_return_native.Initialize();
                    $.$spc.System.Runtime.CompilerServices.Unsafe.SkipInit($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument, $.$ref(() => ____arg_exception_native, ($v) => ____arg_exception_native = $v, $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument));
                    ____arg_exception_native.Initialize();
                    {
                        __retVal_native = __InvokeJSFunction.call(this, ____arg_exception_native.Clone(), ____arg_return_native.Clone());
                    }
                    __retVal_native.ToManaged$27($.$ref(() => __retVal, ($v) => __retVal = $v, $.$srij.System.Runtime.InteropServices.JavaScript.JSObject));
                    return __retVal;
                }
                /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/  function __InvokeJSFunction(/*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ ____arg_exception_native, /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ ____arg_return_native)
                {
                    /*global::System.Span<global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument>*/ let __arguments_buffer = $.$spc.System.Span$$($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument).op_Implicit($.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument), [____arg_exception_native, ____arg_return_native], null, null));
                    $.$srij.System.Runtime.InteropServices.JavaScript.JSFunctionBinding.InvokeJS($.$srij.System.Runtime.InteropServices.JavaScript.JavaScriptImports.__signature_GetGlobalThis_1202228629, __arguments_buffer);
                    return __arguments_buffer.get_Item(1).$v;
                }
            }
            /*global::System.Runtime.InteropServices.JavaScript.JSFunctionBinding*/ static __signature_GetGlobalThis_1202228629 = null;
            static /*global::System.Runtime.InteropServices.JavaScript.JSObject */ GetDotnetInstance()
            {
                if ($.$srij.System.Runtime.InteropServices.JavaScript.JavaScriptImports.__signature_GetDotnetInstance_1202228629 === null)
                {
                    $.$srij.System.Runtime.InteropServices.JavaScript.JavaScriptImports.__signature_GetDotnetInstance_1202228629 = $.$srij.System.Runtime.InteropServices.JavaScript.JSFunctionBinding.BindJSFunction("INTERNAL.get_dotnet_instance", null, $.$spc.System.ReadOnlySpan$$($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType).op_Implicit($.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType), [$.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType.JSObject], null, null)));
                }
                {
                    /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ let ____arg_exception_native;
                    /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ let ____arg_return_native;
                    /*global::System.Runtime.InteropServices.JavaScript.JSObject*/ let __retVal;
                    /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ let __retVal_native;
                    $.$spc.System.Runtime.CompilerServices.Unsafe.SkipInit($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument, $.$ref(() => ____arg_return_native, ($v) => ____arg_return_native = $v, $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument));
                    ____arg_return_native.Initialize();
                    $.$spc.System.Runtime.CompilerServices.Unsafe.SkipInit($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument, $.$ref(() => ____arg_exception_native, ($v) => ____arg_exception_native = $v, $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument));
                    ____arg_exception_native.Initialize();
                    {
                        __retVal_native = __InvokeJSFunction.call(this, ____arg_exception_native.Clone(), ____arg_return_native.Clone());
                    }
                    __retVal_native.ToManaged$27($.$ref(() => __retVal, ($v) => __retVal = $v, $.$srij.System.Runtime.InteropServices.JavaScript.JSObject));
                    return __retVal;
                }
                /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/  function __InvokeJSFunction(/*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ ____arg_exception_native, /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ ____arg_return_native)
                {
                    /*global::System.Span<global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument>*/ let __arguments_buffer = $.$spc.System.Span$$($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument).op_Implicit($.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument), [____arg_exception_native, ____arg_return_native], null, null));
                    $.$srij.System.Runtime.InteropServices.JavaScript.JSFunctionBinding.InvokeJS($.$srij.System.Runtime.InteropServices.JavaScript.JavaScriptImports.__signature_GetDotnetInstance_1202228629, __arguments_buffer);
                    return __arguments_buffer.get_Item(1).$v;
                }
            }
            /*global::System.Runtime.InteropServices.JavaScript.JSFunctionBinding*/ static __signature_GetDotnetInstance_1202228629 = null;
            static /*global::System.Threading.Tasks.Task<global::System.Runtime.InteropServices.JavaScript.JSObject> */ DynamicImport(/*string*/ moduleName, /*string*/ moduleUrl)
            {
                if ($.$srij.System.Runtime.InteropServices.JavaScript.JavaScriptImports.__signature_DynamicImport_119536130 === null)
                {
                    $.$srij.System.Runtime.InteropServices.JavaScript.JavaScriptImports.__signature_DynamicImport_119536130 = $.$srij.System.Runtime.InteropServices.JavaScript.JSFunctionBinding.BindJSFunction("INTERNAL.dynamic_import", null, $.$spc.System.ReadOnlySpan$$($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType).op_Implicit($.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType), [$.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType.Task$1($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType.JSObject), $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType.String, $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType.String], null, null)));
                }
                {
                    /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ let ____arg_exception_native;
                    /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ let ____arg_return_native;
                    /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ let __moduleName_native;
                    /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ let __moduleUrl_native;
                    /*global::System.Threading.Tasks.Task<global::System.Runtime.InteropServices.JavaScript.JSObject>*/ let __retVal;
                    /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ let __retVal_native;
                    $.$spc.System.Runtime.CompilerServices.Unsafe.SkipInit($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument, $.$ref(() => ____arg_return_native, ($v) => ____arg_return_native = $v, $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument));
                    ____arg_return_native.Initialize();
                    $.$spc.System.Runtime.CompilerServices.Unsafe.SkipInit($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument, $.$ref(() => ____arg_exception_native, ($v) => ____arg_exception_native = $v, $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument));
                    ____arg_exception_native.Initialize();
                    $.$spc.System.Runtime.CompilerServices.Unsafe.SkipInit($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument, $.$ref(() => __moduleUrl_native, ($v) => __moduleUrl_native = $v, $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument));
                    $.$spc.System.Runtime.CompilerServices.Unsafe.SkipInit($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument, $.$ref(() => __moduleName_native, ($v) => __moduleName_native = $v, $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument));
                    __moduleUrl_native.ToJS$29(moduleUrl);
                    __moduleName_native.ToJS$29(moduleName);
                    {
                        __retVal_native = __InvokeJSFunction.call(this, ____arg_exception_native.Clone(), ____arg_return_native.Clone(), __moduleName_native.Clone(), __moduleUrl_native.Clone());
                    }
                    __retVal_native.ToManaged$46($.$srij.System.Runtime.InteropServices.JavaScript.JSObject, $.$ref(() => __retVal, ($v) => __retVal = $v, $.$spc.System.Threading.Tasks.Task$$($.$srij.System.Runtime.InteropServices.JavaScript.JSObject)), new ($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument.ArgumentToManagedCallback$$($.$srij.System.Runtime.InteropServices.JavaScript.JSObject))().$ctor($.$srij.System.Runtime.InteropServices.JavaScript.JavaScriptImports, /*static*/ (/*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ __task_result_arg, /*global::System.Runtime.InteropServices.JavaScript.JSObject*/ __task_result) =>
                    {
                        __task_result_arg.$v.ToManaged$27(__task_result);
                    }, {"r":65537,"p":[{"n":"__task_result_arg","p":1364204,"f":4},{"n":"__task_result","p":2281708,"f":2}],"n":"","d":381164,"h":0,"f":1048610}));
                    return __retVal;
                }
                /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/  function __InvokeJSFunction(/*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ ____arg_exception_native, /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ ____arg_return_native, /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ __moduleName_native, /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ __moduleUrl_native)
                {
                    /*global::System.Span<global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument>*/ let __arguments_buffer = $.$spc.System.Span$$($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument).op_Implicit($.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument), [____arg_exception_native, ____arg_return_native, __moduleName_native, __moduleUrl_native], null, null));
                    $.$srij.System.Runtime.InteropServices.JavaScript.JSFunctionBinding.InvokeJS($.$srij.System.Runtime.InteropServices.JavaScript.JavaScriptImports.__signature_DynamicImport_119536130, __arguments_buffer);
                    return __arguments_buffer.get_Item(1).$v;
                }
            }
            /*global::System.Runtime.InteropServices.JavaScript.JSFunctionBinding*/ static __signature_DynamicImport_119536130 = null;
            static /*void */ BindCSFunction(/*nint*/ monoMethod, /*string*/ assemblyName, /*string*/ namespaceName, /*string*/ shortClassName, /*string*/ methodName, /*int*/ signatureHash, /*nint*/ signature)
            {
                if ($.$srij.System.Runtime.InteropServices.JavaScript.JavaScriptImports.__signature_BindCSFunction_1080107758 === null)
                {
                    $.$srij.System.Runtime.InteropServices.JavaScript.JavaScriptImports.__signature_BindCSFunction_1080107758 = $.$srij.System.Runtime.InteropServices.JavaScript.JSFunctionBinding.BindJSFunction("INTERNAL.mono_wasm_bind_cs_function", null, $.$spc.System.ReadOnlySpan$$($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType).op_Implicit($.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType), [$.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType.Discard, $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType.IntPtr, $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType.String, $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType.String, $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType.String, $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType.String, $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType.Int32, $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType.IntPtr], null, null)));
                }
                {
                    /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ let ____arg_exception_native;
                    /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ let ____arg_return_native;
                    /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ let __monoMethod_native;
                    /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ let __assemblyName_native;
                    /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ let __namespaceName_native;
                    /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ let __shortClassName_native;
                    /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ let __methodName_native;
                    /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ let __signatureHash_native;
                    /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ let __signature_native;
                    $.$spc.System.Runtime.CompilerServices.Unsafe.SkipInit($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument, $.$ref(() => ____arg_return_native, ($v) => ____arg_return_native = $v, $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument));
                    ____arg_return_native.Initialize();
                    $.$spc.System.Runtime.CompilerServices.Unsafe.SkipInit($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument, $.$ref(() => ____arg_exception_native, ($v) => ____arg_exception_native = $v, $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument));
                    ____arg_exception_native.Initialize();
                    $.$spc.System.Runtime.CompilerServices.Unsafe.SkipInit($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument, $.$ref(() => __signature_native, ($v) => __signature_native = $v, $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument));
                    $.$spc.System.Runtime.CompilerServices.Unsafe.SkipInit($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument, $.$ref(() => __signatureHash_native, ($v) => __signatureHash_native = $v, $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument));
                    $.$spc.System.Runtime.CompilerServices.Unsafe.SkipInit($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument, $.$ref(() => __methodName_native, ($v) => __methodName_native = $v, $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument));
                    $.$spc.System.Runtime.CompilerServices.Unsafe.SkipInit($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument, $.$ref(() => __shortClassName_native, ($v) => __shortClassName_native = $v, $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument));
                    $.$spc.System.Runtime.CompilerServices.Unsafe.SkipInit($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument, $.$ref(() => __namespaceName_native, ($v) => __namespaceName_native = $v, $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument));
                    $.$spc.System.Runtime.CompilerServices.Unsafe.SkipInit($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument, $.$ref(() => __assemblyName_native, ($v) => __assemblyName_native = $v, $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument));
                    $.$spc.System.Runtime.CompilerServices.Unsafe.SkipInit($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument, $.$ref(() => __monoMethod_native, ($v) => __monoMethod_native = $v, $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument));
                    __signature_native.ToJS$24(signature);
                    __signatureHash_native.ToJS$31(signatureHash);
                    __methodName_native.ToJS$29(methodName);
                    __shortClassName_native.ToJS$29(shortClassName);
                    __namespaceName_native.ToJS$29(namespaceName);
                    __assemblyName_native.ToJS$29(assemblyName);
                    __monoMethod_native.ToJS$24(monoMethod);
                    {
                        __InvokeJSFunction.call(this, ____arg_exception_native.Clone(), ____arg_return_native.Clone(), __monoMethod_native.Clone(), __assemblyName_native.Clone(), __namespaceName_native.Clone(), __shortClassName_native.Clone(), __methodName_native.Clone(), __signatureHash_native.Clone(), __signature_native.Clone());
                    }
                }
                /*void*/  function __InvokeJSFunction(/*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ ____arg_exception_native, /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ ____arg_return_native, /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ __monoMethod_native, /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ __assemblyName_native, /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ __namespaceName_native, /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ __shortClassName_native, /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ __methodName_native, /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ __signatureHash_native, /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ __signature_native)
                {
                    $.$srij.System.Runtime.InteropServices.JavaScript.JSFunctionBinding.InvokeJS($.$srij.System.Runtime.InteropServices.JavaScript.JavaScriptImports.__signature_BindCSFunction_1080107758, $.$spc.System.Span$$($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument).op_Implicit($.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument), [____arg_exception_native, ____arg_return_native, __monoMethod_native, __assemblyName_native, __namespaceName_native, __shortClassName_native, __methodName_native, __signatureHash_native, __signature_native], null, null)));
                }
            }
            /*global::System.Runtime.InteropServices.JavaScript.JSFunctionBinding*/ static __signature_BindCSFunction_1080107758 = null;
            static /*void */ Log(/*string*/ message)
            {
                if ($.$srij.System.Runtime.InteropServices.JavaScript.JavaScriptImports.__signature_Log_92020726 === null)
                {
                    $.$srij.System.Runtime.InteropServices.JavaScript.JavaScriptImports.__signature_Log_92020726 = $.$srij.System.Runtime.InteropServices.JavaScript.JSFunctionBinding.BindJSFunction("globalThis.console.log", null, $.$spc.System.ReadOnlySpan$$($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType).op_Implicit($.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType), [$.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType.DiscardNoWait, $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType.String], null, null)));
                }
                {
                    /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ let ____arg_exception_native;
                    /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ let ____arg_return_native;
                    /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ let __message_native;
                    $.$spc.System.Runtime.CompilerServices.Unsafe.SkipInit($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument, $.$ref(() => ____arg_return_native, ($v) => ____arg_return_native = $v, $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument));
                    ____arg_return_native.Initialize();
                    $.$spc.System.Runtime.CompilerServices.Unsafe.SkipInit($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument, $.$ref(() => ____arg_exception_native, ($v) => ____arg_exception_native = $v, $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument));
                    ____arg_exception_native.Initialize();
                    $.$spc.System.Runtime.CompilerServices.Unsafe.SkipInit($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument, $.$ref(() => __message_native, ($v) => __message_native = $v, $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument));
                    __message_native.ToJS$29(message);
                    {
                        __InvokeJSFunction.call(this, ____arg_exception_native.Clone(), ____arg_return_native.Clone(), __message_native.Clone());
                    }
                }
                /*void*/  function __InvokeJSFunction(/*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ ____arg_exception_native, /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ ____arg_return_native, /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ __message_native)
                {
                    $.$srij.System.Runtime.InteropServices.JavaScript.JSFunctionBinding.InvokeJS($.$srij.System.Runtime.InteropServices.JavaScript.JavaScriptImports.__signature_Log_92020726, $.$spc.System.Span$$($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument).op_Implicit($.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument), [____arg_exception_native, ____arg_return_native, __message_native], null, null)));
                }
            }
            /*global::System.Runtime.InteropServices.JavaScript.JSFunctionBinding*/ static __signature_Log_92020726 = null;
            static $h = 381164;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"m":[{"r":262145,"p":[{"n":"self","p":2281708},{"n":"propertyName","p":1310721}],"n":"HasProperty","d":381164,"h":4295348460,"f":33,"a":[{"t":1233132,"c":30066004204,"a":[{"v":"INTERNAL.has_property","t":1310721}]},{"t":37748737,"c":4332716033}]},{"r":1310721,"p":[{"n":"self","p":2281708},{"n":"propertyName","p":1310721}],"n":"GetTypeOfProperty","d":381164,"h":8590315756,"f":33,"a":[{"t":1233132,"c":30066004204,"a":[{"v":"INTERNAL.get_typeof_property","t":1310721}]},{"t":37748737,"c":4332716033}]},{"r":262145,"p":[{"n":"self","p":2281708},{"n":"propertyName","p":1310721}],"n":"GetPropertyAsBoolean","d":381164,"h":12885283052,"f":33,"a":[{"t":1233132,"c":30066004204,"a":[{"v":"INTERNAL.get_property","t":1310721}]},{"t":37748737,"c":4332716033}]},{"r":655361,"p":[{"n":"self","p":2281708},{"n":"propertyName","p":1310721}],"n":"GetPropertyAsInt32","d":381164,"h":17180250348,"f":33,"a":[{"t":1233132,"c":30066004204,"a":[{"v":"INTERNAL.get_property","t":1310721}]},{"t":37748737,"c":4332716033}]},{"r":1179649,"p":[{"n":"self","p":2281708},{"n":"propertyName","p":1310721}],"n":"GetPropertyAsDouble","d":381164,"h":21475217644,"f":33,"a":[{"t":1233132,"c":30066004204,"a":[{"v":"INTERNAL.get_property","t":1310721}]},{"t":37748737,"c":4332716033}]},{"r":1310721,"p":[{"n":"self","p":2281708},{"n":"propertyName","p":1310721}],"n":"GetPropertyAsString","d":381164,"h":25770184940,"f":33,"a":[{"t":1233132,"c":30066004204,"a":[{"v":"INTERNAL.get_property","t":1310721}]},{"t":37748737,"c":4332716033}]},{"r":2281708,"p":[{"n":"self","p":2281708},{"n":"propertyName","p":1310721}],"n":"GetPropertyAsJSObject","d":381164,"h":30065152236,"f":33,"a":[{"t":1233132,"c":30066004204,"a":[{"v":"INTERNAL.get_property","t":1310721}]},{"t":37748737,"c":4332716033}]},{"r":0,"p":[{"n":"self","p":2281708},{"n":"propertyName","p":1310721}],"n":"GetPropertyAsByteArray","d":381164,"h":34360119532,"f":33,"a":[{"t":1233132,"c":30066004204,"a":[{"v":"INTERNAL.get_property","t":1310721}]},{"t":37748737,"c":4332716033}]},{"r":65537,"p":[{"n":"self","p":2281708},{"n":"propertyName","p":1310721},{"n":"value","p":262145}],"n":"SetPropertyBool","d":381164,"h":38655086828,"f":33,"a":[{"t":1233132,"c":30066004204,"a":[{"v":"INTERNAL.set_property","t":1310721}]},{"t":37748737,"c":4332716033}]},{"r":65537,"p":[{"n":"self","p":2281708},{"n":"propertyName","p":1310721},{"n":"value","p":655361}],"n":"SetPropertyInt","d":381164,"h":42950054124,"f":33,"a":[{"t":1233132,"c":30066004204,"a":[{"v":"INTERNAL.set_property","t":1310721}]},{"t":37748737,"c":4332716033}]},{"r":65537,"p":[{"n":"self","p":2281708},{"n":"propertyName","p":1310721},{"n":"value","p":1179649}],"n":"SetPropertyDouble","d":381164,"h":47245021420,"f":33,"a":[{"t":1233132,"c":30066004204,"a":[{"v":"INTERNAL.set_property","t":1310721}]},{"t":37748737,"c":4332716033}]},{"r":65537,"p":[{"n":"self","p":2281708},{"n":"propertyName","p":1310721},{"n":"value","p":1310721}],"n":"SetPropertyString","d":381164,"h":51539988716,"f":33,"a":[{"t":1233132,"c":30066004204,"a":[{"v":"INTERNAL.set_property","t":1310721}]},{"t":37748737,"c":4332716033}]},{"r":65537,"p":[{"n":"self","p":2281708},{"n":"propertyName","p":1310721},{"n":"value","p":2281708}],"n":"SetPropertyJSObject","d":381164,"h":55834956012,"f":33,"a":[{"t":1233132,"c":30066004204,"a":[{"v":"INTERNAL.set_property","t":1310721}]},{"t":37748737,"c":4332716033}]},{"r":65537,"p":[{"n":"self","p":2281708},{"n":"propertyName","p":1310721},{"n":"value","p":0}],"n":"SetPropertyBytes","d":381164,"h":60129923308,"f":33,"a":[{"t":1233132,"c":30066004204,"a":[{"v":"INTERNAL.set_property","t":1310721}]},{"t":37748737,"c":4332716033}]},{"r":2281708,"n":"GetGlobalThis","d":381164,"h":64424890604,"f":33,"a":[{"t":1233132,"c":30066004204,"a":[{"v":"INTERNAL.get_global_this","t":1310721}]},{"t":37748737,"c":4332716033}]},{"r":2281708,"n":"GetDotnetInstance","d":381164,"h":68719857900,"f":33,"a":[{"t":1233132,"c":30066004204,"a":[{"v":"INTERNAL.get_dotnet_instance","t":1310721}]},{"t":37748737,"c":4332716033}]},{"r":$.$spc.System.Threading.Tasks.Task$$($.$srij.System.Runtime.InteropServices.JavaScript.JSObject).$h,"p":[{"n":"moduleName","p":1310721},{"n":"moduleUrl","p":1310721}],"n":"DynamicImport","d":381164,"h":73014825196,"f":33,"a":[{"t":1233132,"c":30066004204,"a":[{"v":"INTERNAL.dynamic_import","t":1310721}]},{"t":37748737,"c":4332716033}]},{"r":65537,"p":[{"n":"monoMethod","p":786433},{"n":"assemblyName","p":1310721},{"n":"namespaceName","p":1310721},{"n":"shortClassName","p":1310721},{"n":"methodName","p":1310721},{"n":"signatureHash","p":655361},{"n":"signature","p":786433}],"n":"BindCSFunction","d":381164,"h":77309792492,"f":33,"a":[{"t":1233132,"c":30066004204,"a":[{"v":"INTERNAL.mono_wasm_bind_cs_function","t":1310721}]},{"t":37748737,"c":4332716033}]},{"r":65537,"p":[{"n":"message","p":1310721,"a":[{"t":$.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalAsAttribute$$($.$srij.System.Runtime.InteropServices.JavaScript.JSType.String).$h,"c":Number(BigInt($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalAsAttribute$$($.$srij.System.Runtime.InteropServices.JavaScript.JSType.String).$h)|0x100000000n)}]}],"n":"Log","d":381164,"h":81604759788,"f":33,"a":[{"t":1233132,"c":30066004204,"a":[{"v":"globalThis.console.log","t":1310721}]},{"t":37748737,"c":4332716033}]}],"l":[{"t":577772,"n":"__signature_HasProperty_393970128","d":381164,"h":85899727084,"f":34},{"t":577772,"n":"__signature_GetTypeOfProperty_1139574135","d":381164,"h":90194694380,"f":34},{"t":577772,"n":"__signature_GetPropertyAsBoolean_393970128","d":381164,"h":94489661676,"f":34},{"t":577772,"n":"__signature_GetPropertyAsInt32_1813830729","d":381164,"h":98784628972,"f":34},{"t":577772,"n":"__signature_GetPropertyAsDouble_705601847","d":381164,"h":103079596268,"f":34},{"t":577772,"n":"__signature_GetPropertyAsString_1139574135","d":381164,"h":107374563564,"f":34},{"t":577772,"n":"__signature_GetPropertyAsJSObject_1480020778","d":381164,"h":111669530860,"f":34},{"t":577772,"n":"__signature_GetPropertyAsByteArray_657551312","d":381164,"h":115964498156,"f":34},{"t":577772,"n":"__signature_SetPropertyBool_125660004","d":381164,"h":120259465452,"f":34},{"t":577772,"n":"__signature_SetPropertyInt_512418141","d":381164,"h":124554432748,"f":34},{"t":577772,"n":"__signature_SetPropertyDouble_1393852235","d":381164,"h":128849400044,"f":34},{"t":577772,"n":"__signature_SetPropertyString_1189495691","d":381164,"h":133144367340,"f":34},{"t":577772,"n":"__signature_SetPropertyJSObject_2027749310","d":381164,"h":137439334636,"f":34},{"t":577772,"n":"__signature_SetPropertyBytes_1317820772","d":381164,"h":141734301932,"f":34},{"t":577772,"n":"__signature_GetGlobalThis_1202228629","d":381164,"h":146029269228,"f":34},{"t":577772,"n":"__signature_GetDotnetInstance_1202228629","d":381164,"h":150324236524,"f":34},{"t":577772,"n":"__signature_DynamicImport_119536130","d":381164,"h":154619203820,"f":34},{"t":577772,"n":"__signature_BindCSFunction_1080107758","d":381164,"h":158914171116,"f":34},{"t":577772,"n":"__signature_Log_92020726","d":381164,"h":163209138412,"f":34}],"h":381164}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.Runtime.InteropServices.JavaScript.JavaScriptImports`; }
        });
        
        $asm.$cls("$srij.System.Runtime.InteropServices.JavaScript.JSHostImplementation", ($self) => class JSHostImplementation
        {
            static $_ToManagedCallback;
            static get ToManagedCallback()
            {
                let $cls = $.$srij.System.Runtime.InteropServices.JavaScript.JSHostImplementation;
                return $cls.$_ToManagedCallback ??= $asm.$ncls("$srij.System.Runtime.InteropServices.JavaScript.JSHostImplementation.ToManagedCallback", ($self) => class ToManagedCallback extends $.$spc.System.MulticastDelegate
                {
                    $ctor(/*object*/ target, fn, anmodel)
                    {
                        this.$target = target;
                        this.$nativeFunction = fn;
                        if (anmodel) this.$nfmodel = anmodel;
                        if (typeof(target) === 'object') this._target = target;
                        return this;
                    }
                    /*void*/ Invoke(/**/ arguments_buffer)
                    {
                        return this.$nativeFunction.call(this.$target, arguments_buffer);
                    }
                    static $h = 1167596;
                    static $f = 0b10000000010000000;
                    static $k = 5;
                    static $$md;
                    static get $md() { return this.$$md ??= {"b":66191361,"m":[{"r":65537,"p":[{"n":"arguments_buffer","p":0}],"n":"Invoke","d":1167596,"h":8591102188,"f":129},{"r":57016321,"p":[{"n":"arguments_buffer","p":0},{"n":"callback","p":14483457},{"n":"object","p":131073}],"n":"BeginInvoke","d":1167596,"h":12886069484,"f":129},{"r":65537,"p":[{"n":"result","p":57016321}],"n":"EndInvoke","d":1167596,"h":17181036780,"f":129}],"c":[{"p":[{"n":"object","p":131073},{"n":"method","p":786433}],"n":".ctor","o":"$ctor$5","d":1167596,"h":4296134892,"f":1}],"i":[57212929,113377281],"d":839916,"h":1167596}; }
                    static get $b() { return $.$spc.System.MulticastDelegate; }
                    static $$i;
                    static get $i() { return this.$$i ??= [ $.$spc.System.ICloneable, $.$spc.System.Runtime.Serialization.ISerializable ]; }
                    static get $fullName() { return `System.Runtime.InteropServices.JavaScript.JSHostImplementation.ToManagedCallback`; }
                }, $cls, ($v) => $cls.$_ToManagedCallback = $v);
            }
            static $_PromiseHolder;
            static get PromiseHolder()
            {
                let $cls = $.$srij.System.Runtime.InteropServices.JavaScript.JSHostImplementation;
                return $cls.$_PromiseHolder ??= $asm.$ncls("$srij.System.Runtime.InteropServices.JavaScript.JSHostImplementation.PromiseHolder", ($self) => class PromiseHolder extends $.$spc.System.Object
                {
                    /*bool*/ IsDisposed = false;
                    /*nint*/ GCHandle = 0;
                    /*ToManagedCallback?*/ Callback = null;
                    /*JSProxyContext*/ ProxyContext = null;
                    $ctor$1(/*JSProxyContext*/ targetContext)
                    {
                        super.$ctor();
                        {
                            this.GCHandle = $.$spc.System.Runtime.InteropServices.GCHandle.op_Explicit$1($.$spc.System.Runtime.InteropServices.GCHandle.Alloc$1(this, 2/*GCHandleType.Normal*/));
                            this.ProxyContext = targetContext;
                        }
                        return this;
                    }
                    $ctor$2(/*JSProxyContext*/ targetContext, /*nint*/ gcvHandle)
                    {
                        super.$ctor();
                        {
                            this.GCHandle = gcvHandle;
                            this.ProxyContext = targetContext;
                        }
                        return this;
                    }
                    static $h = 1036524;
                    static $f = 0b10000000010010001;
                    static $k = 1;
                    static $$md;
                    static get $md() { return this.$$md ??= {"b":131073,"l":[{"t":262145,"n":"IsDisposed","d":1036524,"h":4296003820,"f":1},{"t":786433,"n":"GCHandle","d":1036524,"h":8590971116,"f":1},{"t":1167596,"n":"Callback","d":1036524,"h":12885938412,"f":1},{"t":2347244,"n":"ProxyContext","d":1036524,"h":17180905708,"f":1}],"c":[{"p":[{"n":"targetContext","p":2347244}],"n":".ctor","o":"$ctor$1","d":1036524,"h":21475873004,"f":1},{"p":[{"n":"targetContext","p":2347244},{"n":"gcvHandle","p":786433}],"n":".ctor","o":"$ctor$2","d":1036524,"h":25770840300,"f":1}],"d":839916,"h":1036524}; }
                    static get $b() { return $.$spc.System.Object; }
                    static get $fullName() { return `System.Runtime.InteropServices.JavaScript.JSHostImplementation.PromiseHolder`; }
                }, $cls, ($v) => $cls.$_PromiseHolder = $v);
            }
            static $_PromiseHolderState;
            static get PromiseHolderState()
            {
                let $cls = $.$srij.System.Runtime.InteropServices.JavaScript.JSHostImplementation;
                return $cls.$_PromiseHolderState ??= $asm.$nstr("$srij.System.Runtime.InteropServices.JavaScript.JSHostImplementation.PromiseHolderState", ($self) => class PromiseHolderState extends $.$spc.System.ValueType
                {
                    /*int*/  get IsResolving() { return this.$getField(0, $.$spc.System.Int32); }
                    /*int*/  set IsResolving(value) { this.$setField(0, $.$spc.System.Int32, value); }
                    //default value type constructor
                    $ctor$2()
                    {
                        return this;
                    }
                    Clone($copy)
                    {
                        let copy = $copy ?? new this.constructor();
                        copy.IsResolving = this.IsResolving;
                        return copy;
                    }
                    //default member initializer
                    constructor()
                    {
                        super();
                        this.IsResolving = 0;
                    }
                    static $h = 1102060;
                    static $z = 4;
                    static $f = 0b10100010000001010000001;
                    static $k = 2;
                    static $$md;
                    static get $md() { return this.$$md ??= {"b":196609,"l":[{"t":655361,"n":"IsResolving","d":1102060,"h":4296069356,"f":1,"a":[{"t":104071169,"c":4399038465,"a":[{"v":0,"t":655361}]}]}],"c":[{"n":".ctor","o":"$ctor$2","d":1102060,"h":8591036652,"f":1}],"d":839916,"h":1102060,"a":[{"t":109903873,"c":4404871169,"a":[{"v":2,"t":105381889}]}]}; }
                    static get $b() { return $.$spc.System.ValueType; }
                    static get $fullName() { return `System.Runtime.InteropServices.JavaScript.JSHostImplementation.PromiseHolderState`; }
                }, $cls, ($v) => $cls.$_PromiseHolderState = $v);
            }
            static $_IntPtrAndHandle;
            static get IntPtrAndHandle()
            {
                let $cls = $.$srij.System.Runtime.InteropServices.JavaScript.JSHostImplementation;
                return $cls.$_IntPtrAndHandle ??= $asm.$nstr("$srij.System.Runtime.InteropServices.JavaScript.JSHostImplementation.IntPtrAndHandle", ($self) => class IntPtrAndHandle extends $.$spc.System.ValueType
                {
                    /*IntPtr*/  get ptr() { return this.$getField(0, 4); }
                    /*IntPtr*/  set ptr(value) { this.$setField(0, 4, value); }
                    /*RuntimeMethodHandle*/  get methodHandle() { return this.$getField(0, 1); }
                    /*RuntimeMethodHandle*/  set methodHandle(value) { this.$setField(0, 1, value); }
                    /*RuntimeTypeHandle*/  get typeHandle() { return this.$getField(0, 1); }
                    /*RuntimeTypeHandle*/  set typeHandle(value) { this.$setField(0, 1, value); }
                    //default value type constructor
                    $ctor$2()
                    {
                        return this;
                    }
                    Clone($copy)
                    {
                        let copy = $copy ?? new this.constructor();
                        copy.ptr = this.ptr;
                        copy.methodHandle = this.methodHandle.Clone();
                        copy.typeHandle = this.typeHandle.Clone();
                        return copy;
                    }
                    //default member initializer
                    constructor()
                    {
                        super();
                        this.ptr = 0;
                        this.methodHandle = $.$default($.$spc.System.RuntimeMethodHandle);
                        this.typeHandle = $.$default($.$spc.System.RuntimeTypeHandle);
                    }
                    static $h = 905452;
                    static $z = 4;
                    static $f = 0b100010000001010000001;
                    static $k = 2;
                    static $$md;
                    static get $md() { return this.$$md ??= {"b":196609,"l":[{"t":786433,"n":"ptr","d":905452,"h":4295872748,"f":8,"a":[{"t":104071169,"c":4399038465,"a":[{"v":0,"t":655361}]}]},{"t":115605505,"n":"methodHandle","d":905452,"h":8590840044,"f":8,"a":[{"t":104071169,"c":4399038465,"a":[{"v":0,"t":655361}]}]},{"t":116064257,"n":"typeHandle","d":905452,"h":12885807340,"f":8,"a":[{"t":104071169,"c":4399038465,"a":[{"v":0,"t":655361}]}]}],"c":[{"n":".ctor","o":"$ctor$2","d":905452,"h":17180774636,"f":1}],"d":839916,"h":905452,"a":[{"t":109903873,"c":4404871169,"a":[{"v":2,"t":105381889}]}]}; }
                    static get $b() { return $.$spc.System.ValueType; }
                    static get $fullName() { return `System.Runtime.InteropServices.JavaScript.JSHostImplementation.IntPtrAndHandle`; }
                }, $cls, ($v) => $cls.$_IntPtrAndHandle = $v);
            }
            static $_JSThreadBlockingMode;
            static get JSThreadBlockingMode()
            {
                let $cls = $.$srij.System.Runtime.InteropServices.JavaScript.JSHostImplementation;
                return $cls.$_JSThreadBlockingMode ??= $asm.$nstr("$srij.System.Runtime.InteropServices.JavaScript.JSHostImplementation.JSThreadBlockingMode", ($self) => class JSThreadBlockingMode extends $.$spc.System.Enum
                {
                    static PreventSynchronousJSExport = 0;
                    static ThrowWhenBlockingWait = 1;
                    static WarnWhenBlockingWait = 2;
                    static DangerousAllowBlockingWait = 100;
                    static $map;
                    static get Map()
                    {
                        return this.$map ??= 
                        {
                            "PreventSynchronousJSExport": 0n,
                            "ThrowWhenBlockingWait": 1n,
                            "WarnWhenBlockingWait": 2n,
                            "DangerousAllowBlockingWait": 100n
                        };
                    }
                    static $h = 970988;
                    static $z = 4;
                    static $f = 0b110000011010001001;
                    static $k = 4;
                    static get $eut() { return $.$spc.System.Int32; }
                    static $$md;
                    static get $md() { return this.$$md ??= {"b":1048577,"u":655361,"l":[{"t":970988,"n":"PreventSynchronousJSExport","d":970988,"h":4295938284,"f":33},{"t":970988,"n":"ThrowWhenBlockingWait","d":970988,"h":8590905580,"f":33},{"t":970988,"n":"WarnWhenBlockingWait","d":970988,"h":12885872876,"f":33},{"t":970988,"n":"DangerousAllowBlockingWait","d":970988,"h":17180840172,"f":33}],"c":[{"n":".ctor","o":"$ctor$3","d":970988,"h":21475807468,"f":1}],"i":[57278465,63832065,57737217,57409537],"d":839916,"h":970988}; }
                    static get $b() { return $.$spc.System.Enum; }
                    static $$i;
                    static get $i() { return this.$$i ??= [ $.$spc.System.IComparable, $.$spc.System.ISpanFormattable, $.$spc.System.IFormattable, $.$spc.System.IConvertible ]; }
                    static get $fullName() { return `System.Runtime.InteropServices.JavaScript.JSHostImplementation.JSThreadBlockingMode`; }
                }, $cls, ($v) => $cls.$_JSThreadBlockingMode = $v);
            }
            /*string*/ static TaskGetResultName = null;
            /*MethodInfo?*/ static s_taskGetResultMethodInfo = null;
            static /*bool */ GetTaskResultDynamic(/*Task*/ task, /*out object?*/ value)
            {
                /*var*/ let type = $.$spc.System.Object.GetType.call(task);
                if ($.$spc.System.Type.op_Equality$1(type, $.$spc.System.Threading.Tasks.Task.$type))
                {
                    value.$v = null;
                    return false;
                }
                /*MethodInfo*/ let method = $.$srij.System.Runtime.InteropServices.JavaScript.JSHostImplementation.GetTaskResultMethodInfo(type);
                if ($.$spc.System.Reflection.MethodInfo.op_Inequality$2(method, null))
                {
                    value.$v = method.Invoke(task, null);
                    return true;
                }
                throw new $.$spc.System.InvalidOperationException().$ctor$9();
            }
            static /*MethodInfo */ GetTaskResultMethodInfo(/*Type*/ taskType)
            {
                if ($.$spc.System.Type.op_Inequality$1(taskType, null))
                {
                    if ($.$spc.System.Reflection.MethodInfo.op_Equality$2($.$srij.System.Runtime.InteropServices.JavaScript.JSHostImplementation.s_taskGetResultMethodInfo, null))
                    {
                        $.$srij.System.Runtime.InteropServices.JavaScript.JSHostImplementation.s_taskGetResultMethodInfo = $.$spc.System.Threading.Tasks.Task$$().$type.GetMethod$1("get_Result"/*TaskGetResultName*/);
                    }
                    /*MethodInfo?*/ let getter = taskType.GetMethod$1("get_Result"/*TaskGetResultName*/);
                    if ($.$spc.System.Reflection.MethodInfo.op_Inequality$2(getter, null) && getter.HasSameMetadataDefinitionAs($.$srij.System.Runtime.InteropServices.JavaScript.JSHostImplementation.s_taskGetResultMethodInfo))
                    {
                        return getter;
                    }
                }
                throw new $.$spc.System.InvalidOperationException().$ctor$9();
            }
            static /*void */ ThrowException(/*ref JSMarshalerArgument*/ arg)
            {
                /*Exception?*/ let ex;
                arg.$v.ToManaged$36($.$ref(() => ex, ($v) => ex = $v, $.$spc.System.Exception));
                if (ex !== null)
                {
                    throw ex;
                }
                throw new $.$spc.System.InvalidOperationException().$ctor$9();
            }
            static /*Task<JSObject> *//*async*/  ImportAsync(/*string*/ moduleName, /*string*/ moduleUrl, /*CancellationToken*/ cancellationToken)
            {
                return $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.Async($.$spc.System.Threading.Tasks.Task$$($.$srij.System.Runtime.InteropServices.JavaScript.JSObject), $.$srij.System.Runtime.InteropServices.JavaScript.JSObject, async () => 
                {
                    /*Task<JSObject>*/ let modulePromise = INTERNAL.dynamic_import(moduleName, moduleUrl);
                    /*var*/ let wrappedTask = $.$srij.System.Runtime.InteropServices.JavaScript.JSHostImplementation.CancellationHelper(modulePromise, cancellationToken);
                    return await wrappedTask.ConfigureAwait$3(1/*ConfigureAwaitOptions.ContinueOnCapturedContext*/ | 4/*ConfigureAwaitOptions.ForceYielding*/);
                });
            }
            static /*Task<JSObject> *//*async*/  CancellationHelper(/*Task<JSObject>*/ jsTask, /*CancellationToken*/ cancellationToken)
            {
                return $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.Async($.$spc.System.Threading.Tasks.Task$$($.$srij.System.Runtime.InteropServices.JavaScript.JSObject), $.$srij.System.Runtime.InteropServices.JavaScript.JSObject, async () => 
                {
                    if (jsTask.IsCompletedSuccessfully)
                    {
                        return jsTask.Result;
                    }
                    let receiveRegistration = null;
                    try
                    {
                        receiveRegistration = cancellationToken.Register$2(new ($.$spc.System.Action$$($.$spc.System.Object))().$ctor($.$srij.System.Runtime.InteropServices.JavaScript.JSHostImplementation, /*static*/ (/*s*/ s) =>
                        {
                            $.$srij.System.Runtime.InteropServices.JavaScript.CancelablePromise.CancelPromise($.$cast(s, $.$spc.System.Threading.Tasks.Task$$($.$srij.System.Runtime.InteropServices.JavaScript.JSObject)));
                        }, {"r":65537,"p":[{"n":"s","p":131073}],"n":"","d":839916,"h":0,"f":1048610}), jsTask);
                        return await jsTask.ConfigureAwait$2(false);
                    }
                    finally
                    {
                        receiveRegistration?.System$IDisposable$Dispose();
                    }
                });
            }
            static /*JSFunctionBinding */ GetMethodSignature(/*ReadOnlySpan<JSMarshalerType>*/ types, /*string?*/ functionName, /*string?*/ moduleName)
            {
                /*int*/ let argsCount = ((types.Length - 1) | 0);
                /*int*/ let size = ((32/*JSFunctionBinding.JSBindingHeader.JSMarshalerSignatureHeaderSize*/ + ((((((argsCount + 2) | 0)) * $.$srij.System.Runtime.InteropServices.JavaScript.JSFunctionBinding.JSBindingType.$z) | 0))) | 0);
                /*int*/ let functionNameBytes = 0;
                /*int*/ let functionNameOffset = 0;
                if ($.$spc.System.String.op_Inequality(functionName, null))
                {
                    functionNameOffset = size;
                    size += 4;
                    functionNameBytes = ((functionName.length * 2) | 0);
                    size += functionNameBytes;
                }
                /*int*/ let moduleNameBytes = 0;
                /*int*/ let moduleNameOffset = 0;
                if ($.$spc.System.String.op_Inequality(moduleName, null))
                {
                    moduleNameOffset = size;
                    size += 4;
                    moduleNameBytes = ((moduleName.length * 2) | 0);
                    size += moduleNameBytes;
                }
                /*IntPtr*/ let buffer = $.$spc.System.Runtime.InteropServices.Marshal.AllocHGlobal(size);
                /*var*/ let signature = (() =>
                {
                    //new $.$srij.System.Runtime.InteropServices.JavaScript.JSFunctionBinding()
                    const $t1 = $.$srij.System.Runtime.InteropServices.JavaScript.JSFunctionBinding;
                    const $i1 = new $t1();
                    $i1.$ctor$1();
                    $i1.Header = $.$cast(buffer, $.$typePointer($.$srij.System.Runtime.InteropServices.JavaScript.JSFunctionBinding.JSBindingHeader));
                    $i1.Sigs = $.$cast((buffer + 32/*JSFunctionBinding.JSBindingHeader.JSMarshalerSignatureHeaderSize*/ + (((2 * $.$srij.System.Runtime.InteropServices.JavaScript.JSFunctionBinding.JSBindingType.$z) | 0))), $.$typePointer($.$srij.System.Runtime.InteropServices.JavaScript.JSFunctionBinding.JSBindingType));
                    return $i1;
                })();
                signature.Version = 2;
                signature.ArgumentCount = argsCount;
                signature.Exception = $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType.Exception._signatureType;
                signature.Result = types.get_Item(0).$v._signatureType;
                signature.ImportHandle = ($.$srij.System.Runtime.InteropServices.JavaScript.JSFunctionBinding.nextImportHandle++ | 0);
                signature.FunctionName = functionName;
                for(/*int*/ let i = 0; i < argsCount; i++)
                {
                    /*var*/ let type = signature.Sigs.SetAt(types.get_Item(((i + 1) | 0)).$v._signatureType, i);
                }
                signature.IsAsync = types.get_Item(0).$v._signatureType.Type === 20/*MarshalerType.Task*/;
                signature.IsDiscardNoWait = types.get_Item(0).$v._signatureType.Type === 26/*MarshalerType.DiscardNoWait*/;
                signature.Header.GetAt(0).ImportHandle = signature.ImportHandle;
                signature.Header.GetAt(0).FunctionNameLength = functionNameBytes;
                signature.Header.GetAt(0).FunctionNameOffset = functionNameOffset;
                signature.Header.GetAt(0).ModuleNameLength = moduleNameBytes;
                signature.Header.GetAt(0).ModuleNameOffset = moduleNameOffset;
                if (functionNameBytes !== 0)
                {
                    /*fixed*/ 
                    {
                        /*void**/ let fn = $.$spc.System.String.GetPinnableReference.call(functionName);
                        $.$spc.System.Runtime.CompilerServices.Unsafe.CopyBlock($.$cast(buffer, $.$typePointer($.$spc.System.Byte)).Add(functionNameOffset), fn, (functionNameBytes >>> 0));
                    }
                }
                if (moduleNameBytes !== 0)
                {
                    /*fixed*/ 
                    {
                        /*void**/ let mn = $.$spc.System.String.GetPinnableReference.call(moduleName);
                        $.$spc.System.Runtime.CompilerServices.Unsafe.CopyBlock($.$cast(buffer, $.$typePointer($.$spc.System.Byte)).Add(moduleNameOffset), mn, (moduleNameBytes >>> 0));
                    }
                }
                return signature;
            }
            static /*void */ FreeMethodSignatureBuffer(/*JSFunctionBinding*/ signature)
            {
                $.$spc.System.Runtime.InteropServices.Marshal.FreeHGlobal($.$cast(signature.Header, $.$spc.System.IntPtr));
                signature.Header = null;
                signature.Sigs = null;
            }
            static /*void */ LoadLazyAssembly(/*byte[]*/ dllBytes, /*byte[]?*/ pdbBytes)
            {
                if (pdbBytes === null)
                {
                    $.$spc.System.Runtime.Loader.AssemblyLoadContext.Default.LoadFromStream(new $.$spc.System.IO.MemoryStream().$ctor$5(dllBytes));
                }
                else 
                {
                    $.$spc.System.Runtime.Loader.AssemblyLoadContext.Default.LoadFromStream$1(new $.$spc.System.IO.MemoryStream().$ctor$5(dllBytes), new $.$spc.System.IO.MemoryStream().$ctor$5(pdbBytes));
                }
            }
            static /*void */ LoadSatelliteAssembly(/*byte[]*/ dllBytes)
            {
                $.$spc.System.Runtime.Loader.AssemblyLoadContext.Default.LoadFromStream(new $.$spc.System.IO.MemoryStream().$ctor$5(dllBytes));
            }
            static /*Task<int>? */ CallEntrypoint(/*IntPtr*/ assemblyNamePtr, /*string?[]?*/ args, /*bool*/ waitForDebugger)
            {
                try
                {
                    /*void**/ let ptr;
                    $.$srij.Interop.Runtime.AssemblyGetEntryPoint(assemblyNamePtr, waitForDebugger ? 1 : 0, $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateObjectReferenceT($.$typePointer($.$spc.System.Void), () => ptr, ($v) => ptr = $v, null));
                    /*RuntimeMethodHandle*/ let methodHandle = $.$srij.System.Runtime.InteropServices.JavaScript.JSHostImplementation.GetMethodHandleFromIntPtr($.$spc.System.IntPtr.op_Explicit$2(ptr));
                    /*MethodInfo?*/ let method = $.$as($.$spc.System.Reflection.MethodBase.GetMethodFromHandle(methodHandle), $.$spc.System.Reflection.MethodInfo);
                    if ($.$spc.System.Reflection.MethodInfo.op_Equality$2(method, null))
                    {
                        throw new $.$spc.System.InvalidOperationException().$ctor$10($.$srij.System.SR.CannotResolveManagedEntrypointHandle);
                    }
                    /*object[]*/ let argsToPass = $.$spc.System.Array.Empty($.$spc.System.Object);
                    /*Task<int>?*/ let result = null;
                    /*var*/ let parameterInfos = method.GetParameters();
                    if (parameterInfos.length > 0 && $.$spc.System.Type.op_Equality$1($.$spc.System.Array.$ReadT1.call(parameterInfos, 0).ParameterType, $.$typeArray($.$spc.System.String).$type))
                    {
                        argsToPass = $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$spc.System.Object), [args ?? $.$spc.System.Array.Empty($.$spc.System.String)], [-1], null);
                    }
                    if ($.$spc.System.Type.op_Equality$1(method.ReturnType, $.$spc.System.Void.$type))
                    {
                        method.Invoke(null, argsToPass);
                    }
                    else if ($.$spc.System.Type.op_Equality$1(method.ReturnType, $.$spc.System.Int32.$type))
                    {
                        /*int*/ let intResult = $.$cast(method.Invoke(null, argsToPass), $.$spc.System.Int32);
                        result = $.$spc.System.Threading.Tasks.Task.FromResult($.$spc.System.Int32, intResult);
                    }
                    else if ($.$spc.System.Type.op_Equality$1(method.ReturnType, $.$spc.System.Threading.Tasks.Task.$type))
                    {
                        /*Task*/ let methodResult = $.$cast(method.Invoke(null, argsToPass), $.$spc.System.Threading.Tasks.Task);
                        /*TaskCompletionSource<int>*/ let tcs = new ($.$spc.System.Threading.Tasks.TaskCompletionSource$$($.$spc.System.Int32))().$ctor$1();
                        result = tcs.Task;
                        methodResult.ContinueWith$2(new ($.$spc.System.Action$$($.$spc.System.Threading.Tasks.Task))().$ctor(this,  (/*t*/ t) =>
                        {
                            if (t.IsFaulted)
                            {
                                tcs.SetException(t.Exception);
                            }
                            else 
                            {
                                tcs.SetResult(0);
                            }
                        }, {"r":65537,"p":[{"n":"t","p":133300225}],"n":"","d":839916,"h":0,"f":1048578}), $.$spc.System.Threading.Tasks.TaskScheduler.Default);
                    }
                    else if ($.$spc.System.Type.op_Equality$1(method.ReturnType, $.$spc.System.Threading.Tasks.Task$$($.$spc.System.Int32).$type))
                    {
                        result = $.$cast(method.Invoke(null, argsToPass), $.$spc.System.Threading.Tasks.Task$$($.$spc.System.Int32));
                    }
                    else 
                    {
                        throw new $.$spc.System.InvalidOperationException().$ctor$10($.$srij.System.SR.Format($.$srij.System.SR.ReturnTypeNotSupportedForMain, method.ReturnType.FullName));
                    }
                    return result;
                }
                catch(ex)
                {
                    let refEx;
                    if ($.$is(ex, $.$spc.System.Reflection.TargetInvocationException, { set $v(v){ refEx = v; } }) && refEx.InnerException !== null)
                    {
                        ex = refEx.InnerException;
                    }
                    return $.$spc.System.Threading.Tasks.Task.FromException$1($.$spc.System.Int32, ex);
                }
            }
            static /*Task */ BindAssemblyExports(/*string?*/ assemblyName)
            {
                $.$srij.Interop.Runtime.BindAssemblyExports($.$spc.System.Runtime.InteropServices.Marshal.StringToCoTaskMemUTF8(assemblyName));
                return $.$spc.System.Threading.Tasks.Task.CompletedTask;
            }
            static /*JSFunctionBinding */ BindManagedFunction(/*string*/ fullyQualifiedName, /*int*/ signatureHash, /*ReadOnlySpan<JSMarshalerType>*/ signatures)
            {
                /*var*/ let  [ assemblyName, nameSpace, shortClassName, methodName ] = $.$destructure($.$srij.System.Runtime.InteropServices.JavaScript.JSHostImplementation.ParseFQN(fullyQualifiedName));
                /*IntPtr*/ let monoMethod;
                $.$srij.Interop.Runtime.GetAssemblyExport($.$spc.System.Runtime.InteropServices.Marshal.StringToCoTaskMemUTF8(assemblyName), $.$spc.System.Runtime.InteropServices.Marshal.StringToCoTaskMemUTF8(nameSpace), $.$spc.System.Runtime.InteropServices.Marshal.StringToCoTaskMemUTF8(shortClassName), $.$spc.System.Runtime.InteropServices.Marshal.StringToCoTaskMemUTF8(methodName), signatureHash, $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateObjectReferenceT($.$spc.System.IntPtr, () => monoMethod, ($v) => monoMethod = $v, null));
                if (monoMethod === $.$spc.System.IntPtr.Zero)
                {
                    $.$spc.System.Environment.FailFast(`Can't find ${nameSpace}${shortClassName}${methodName} in ${assemblyName}.dll`);
                }
                /*var*/ let signature = $.$srij.System.Runtime.InteropServices.JavaScript.JSHostImplementation.GetMethodSignature(signatures, null, null);
                INTERNAL.mono_wasm_bind_cs_function(monoMethod, assemblyName, nameSpace, shortClassName, methodName, signatureHash, $.$cast(signature.Header, $.$spc.System.IntPtr));
                $.$srij.System.Runtime.InteropServices.JavaScript.JSHostImplementation.FreeMethodSignatureBuffer(signature);
                return signature;
            }
            static /*RuntimeMethodHandle */ GetMethodHandleFromIntPtr(/*IntPtr*/ ptr)
            {
                /*var*/ let temp = (() =>
                {
                    //new $.$srij.System.Runtime.InteropServices.JavaScript.JSHostImplementation.IntPtrAndHandle()
                    const $t1 = $.$srij.System.Runtime.InteropServices.JavaScript.JSHostImplementation.IntPtrAndHandle;
                    const $i1 = new $t1();
                    $i1.ptr = ptr;
                    return $i1;
                })();
                return temp.methodHandle;
            }
            static /*int */ SmallIndexOf(/*string*/ s, /*char*/ ch, /*int*/ direction)
            {
                if (s.length < 1)
                {
                    return -1;
                }
                /*int*/ let start_index = (direction > 0) ? 0 : ((s.length - 1) | 0), end_index = (direction > 0) ? ((s.length - 1) | 0) : 0;
                for(/*int*/ let i = start_index; i !== end_index; i += direction)
                {
                    if ($.$spc.System.String.get_Chars.call(s, i) === ch)
                    {
                        return i;
                    }
                }
                return -1;
            }
            static /*string */ SmallTrim(/*string*/ s)
            {
                if (s.length < 1)
                {
                    return s;
                }
                /*int*/ let head = 0, tail = ((s.length - 1) | 0);
                while(head < s.length)
                {
                    if ($.$spc.System.String.get_Chars.call(s, head) === /* */ 32)
                    {
                        head++;
                    }
                    else 
                    {
                        break;
                    }
                }
                while(tail >= 0)
                {
                    if ($.$spc.System.String.get_Chars.call(s, tail) === /* */ 32)
                    {
                        tail--;
                    }
                    else 
                    {
                        break;
                    }
                }
                if ((head > 0) || (tail < ((s.length - 1) | 0)))
                {
                    return $.$spc.System.String.Substring$1.call(s, head, ((((tail - head) | 0) + 1) | 0));
                }
                else 
                {
                    return s;
                }
            }
            static /*(string assemblyName, string nameSpace, string shortClassName, string methodName) */ ParseFQN(/*string*/ fqn)
            {
                /*var*/ let assembly = $.$spc.System.String.Substring$1.call(fqn, (($.$srij.System.Runtime.InteropServices.JavaScript.JSHostImplementation.SmallIndexOf(fqn, /*[*/ 91, 1) + 1) | 0), (($.$srij.System.Runtime.InteropServices.JavaScript.JSHostImplementation.SmallIndexOf(fqn, /*]*/ 93, 1) - 1) | 0));
                fqn = $.$srij.System.Runtime.InteropServices.JavaScript.JSHostImplementation.SmallTrim(fqn);
                fqn = $.$spc.System.String.Substring.call(fqn, (($.$srij.System.Runtime.InteropServices.JavaScript.JSHostImplementation.SmallIndexOf(fqn, /*]*/ 93, 1) + 1) | 0));
                fqn = $.$srij.System.Runtime.InteropServices.JavaScript.JSHostImplementation.SmallTrim(fqn);
                /*var*/ let methodName = $.$spc.System.String.Substring.call(fqn, (($.$srij.System.Runtime.InteropServices.JavaScript.JSHostImplementation.SmallIndexOf(fqn, /*:*/ 58, 1) + 1) | 0));
                /*var*/ let className = $.$spc.System.String.Substring$1.call(fqn, 0, $.$srij.System.Runtime.InteropServices.JavaScript.JSHostImplementation.SmallIndexOf(fqn, /*:*/ 58, 1));
                className = $.$srij.System.Runtime.InteropServices.JavaScript.JSHostImplementation.SmallTrim(className);
                /*var*/ let nameSpace = "";
                /*var*/ let shortClassName = className;
                /*var*/ let idx = $.$srij.System.Runtime.InteropServices.JavaScript.JSHostImplementation.SmallIndexOf(fqn, /*.*/ 46, -1);
                if (idx !== -1)
                {
                    nameSpace = $.$spc.System.String.Substring$1.call(fqn, 0, idx);
                    shortClassName = $.$spc.System.String.Substring.call(className, ((idx + 1) | 0));
                }
                if ($.$spc.System.String.IsNullOrEmpty(assembly))
                {
                    throw new $.$spc.System.InvalidOperationException().$ctor$10("No assembly name specified " + fqn);
                }
                if ($.$spc.System.String.IsNullOrEmpty(className))
                {
                    throw new $.$spc.System.InvalidOperationException().$ctor$10("No class name specified " + fqn);
                }
                if ($.$spc.System.String.IsNullOrEmpty(methodName))
                {
                    throw new $.$spc.System.InvalidOperationException().$ctor$10("No method name specified " + fqn);
                }
                return new ($.$spc.System.ValueTuple$$$$$($.$spc.System.String, $.$spc.System.String, $.$spc.System.String, $.$spc.System.String))().$ctor$2(assembly, nameSpace, shortClassName, methodName);
            }
            //Static Initializer
            static $sinit()
            {
                {
                    this.TaskGetResultName = "get_Result";
                }
            }
            static $h = 839916;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"m":[{"r":262145,"p":[{"n":"task","p":133300225},{"n":"value","p":131073,"f":2}],"n":"GetTaskResultDynamic","d":839916,"h":34360578284,"f":33},{"r":79626241,"p":[{"n":"taskType","p":142606337}],"n":"GetTaskResultMethodInfo","d":839916,"h":38655545580,"f":33},{"r":65537,"p":[{"n":"arg","p":1364204,"f":4}],"n":"ThrowException","d":839916,"h":42950512876,"f":33},{"r":$.$spc.System.Threading.Tasks.Task$$($.$srij.System.Runtime.InteropServices.JavaScript.JSObject).$h,"p":[{"n":"moduleName","p":1310721},{"n":"moduleUrl","p":1310721},{"n":"cancellationToken","p":125960193}],"n":"ImportAsync","d":839916,"h":47245480172,"f":4129},{"r":$.$spc.System.Threading.Tasks.Task$$($.$srij.System.Runtime.InteropServices.JavaScript.JSObject).$h,"p":[{"n":"jsTask","p":$.$spc.System.Threading.Tasks.Task$$($.$srij.System.Runtime.InteropServices.JavaScript.JSObject).$h},{"n":"cancellationToken","p":125960193}],"n":"CancellationHelper","d":839916,"h":51540447468,"f":4129},{"r":577772,"p":[{"n":"types","p":$.$spc.System.ReadOnlySpan$$($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType).$h},{"n":"functionName","p":1310721},{"n":"moduleName","p":1310721}],"n":"GetMethodSignature","d":839916,"h":55835414764,"f":33},{"r":65537,"p":[{"n":"signature","p":577772}],"n":"FreeMethodSignatureBuffer","d":839916,"h":60130382060,"f":33},{"r":65537,"p":[{"n":"dllBytes","p":0},{"n":"pdbBytes","p":0}],"n":"LoadLazyAssembly","d":839916,"h":64425349356,"f":33},{"r":65537,"p":[{"n":"dllBytes","p":0}],"n":"LoadSatelliteAssembly","d":839916,"h":68720316652,"f":33},{"r":$.$spc.System.Threading.Tasks.Task$$($.$spc.System.Int32).$h,"p":[{"n":"assemblyNamePtr","p":786433},{"n":"args","p":0},{"n":"waitForDebugger","p":262145}],"n":"CallEntrypoint","d":839916,"h":73015283948,"f":33},{"r":133300225,"p":[{"n":"assemblyName","p":1310721}],"n":"BindAssemblyExports","d":839916,"h":77310251244,"f":33},{"r":577772,"p":[{"n":"fullyQualifiedName","p":1310721},{"n":"signatureHash","p":655361},{"n":"signatures","p":$.$spc.System.ReadOnlySpan$$($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType).$h}],"n":"BindManagedFunction","d":839916,"h":81605218540,"f":33},{"r":115605505,"p":[{"n":"ptr","p":786433}],"n":"GetMethodHandleFromIntPtr","d":839916,"h":85900185836,"f":33},{"r":655361,"p":[{"n":"s","p":1310721},{"n":"ch","p":458753},{"n":"direction","p":655361,"f":65,"v":1}],"n":"SmallIndexOf","d":839916,"h":90195153132,"f":34},{"r":1310721,"p":[{"n":"s","p":1310721}],"n":"SmallTrim","d":839916,"h":94490120428,"f":34},{"r":$.$spc.System.ValueTuple$$$$$($.$spc.System.String, $.$spc.System.String, $.$spc.System.String, $.$spc.System.String).$h,"p":[{"n":"fqn","p":1310721}],"n":"ParseFQN","d":839916,"h":98785087724,"f":33}],"l":[{"t":1310721,"n":"TaskGetResultName","d":839916,"h":25770643692,"f":34},{"t":79626241,"n":"s_taskGetResultMethodInfo","d":839916,"h":30065610988,"f":34}],"j":[1167596,1036524,1102060,905452,970988],"h":839916}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.Runtime.InteropServices.JavaScript.JSHostImplementation`; }
        });
        
        $asm.$cls("$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType", ($self) => class JSMarshalerType extends $.$spc.System.Object
        {
            /*JSFunctionBinding.JSBindingType*/ _signatureType;
            $ctor$1()
            {
                super.$ctor();
                {
                    this._signatureType = $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType.Void._signatureType;
                }
                return this;
            }
            $ctor$2(/*JSFunctionBinding.JSBindingType*/ signatureType)
            {
                super.$ctor();
                {
                    this._signatureType = signatureType.Clone();
                }
                return this;
            }
            /*JSMarshalerType*/ static Void = null;
            /*JSMarshalerType*/ static Discard = null;
            /*JSMarshalerType*/ static DiscardNoWait = null;
            /*JSMarshalerType*/ static Boolean = null;
            /*JSMarshalerType*/ static Byte = null;
            /*JSMarshalerType*/ static Char = null;
            /*JSMarshalerType*/ static Int16 = null;
            /*JSMarshalerType*/ static Int32 = null;
            /*JSMarshalerType*/ static Int52 = null;
            /*JSMarshalerType*/ static BigInt64 = null;
            /*JSMarshalerType*/ static Double = null;
            /*JSMarshalerType*/ static Single = null;
            /*JSMarshalerType*/ static IntPtr = null;
            /*JSMarshalerType*/ static JSObject = null;
            /*JSMarshalerType*/ static Object = null;
            /*JSMarshalerType*/ static String = null;
            /*JSMarshalerType*/ static Exception = null;
            /*JSMarshalerType*/ static DateTime = null;
            /*JSMarshalerType*/ static DateTimeOffset = null;
            static /*JSMarshalerType */ Nullable(/*JSMarshalerType*/ primitive)
            {
                $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType.CheckNullable(primitive);
                return new $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType().$ctor$2((() =>
                {
                    //new $.$srij.System.Runtime.InteropServices.JavaScript.JSFunctionBinding.JSBindingType()
                    const $t1 = $.$srij.System.Runtime.InteropServices.JavaScript.JSFunctionBinding.JSBindingType;
                    const $i1 = new $t1();
                    $i1.Type = 19/*MarshalerType.Nullable*/;
                    $i1.ResultMarshalerType = primitive._signatureType.Type;
                    return $i1;
                })());
            }
            /*JSMarshalerType*/ static _task = null;
            static /*JSMarshalerType */ Task()
            {
                return $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType._task;
            }
            static /*JSMarshalerType */ Task$1(/*JSMarshalerType*/ result)
            {
                $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType.CheckTask(result);
                return new $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType().$ctor$2((() =>
                {
                    //new $.$srij.System.Runtime.InteropServices.JavaScript.JSFunctionBinding.JSBindingType()
                    const $t1 = $.$srij.System.Runtime.InteropServices.JavaScript.JSFunctionBinding.JSBindingType;
                    const $i1 = new $t1();
                    $i1.Type = 20/*MarshalerType.Task*/;
                    $i1.ResultMarshalerType = result._signatureType.Type;
                    return $i1;
                })());
            }
            static /*JSMarshalerType */ Array(/*JSMarshalerType*/ element)
            {
                $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType.CheckArray(element);
                return new $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType().$ctor$2((() =>
                {
                    //new $.$srij.System.Runtime.InteropServices.JavaScript.JSFunctionBinding.JSBindingType()
                    const $t1 = $.$srij.System.Runtime.InteropServices.JavaScript.JSFunctionBinding.JSBindingType;
                    const $i1 = new $t1();
                    $i1.Type = 21/*MarshalerType.Array*/;
                    $i1.Arg1MarshalerType = element._signatureType.Type;
                    return $i1;
                })());
            }
            static /*JSMarshalerType */ ArraySegment(/*JSMarshalerType*/ element)
            {
                $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType.CheckArraySegment(element);
                return new $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType().$ctor$2((() =>
                {
                    //new $.$srij.System.Runtime.InteropServices.JavaScript.JSFunctionBinding.JSBindingType()
                    const $t1 = $.$srij.System.Runtime.InteropServices.JavaScript.JSFunctionBinding.JSBindingType;
                    const $i1 = new $t1();
                    $i1.Type = 22/*MarshalerType.ArraySegment*/;
                    $i1.Arg1MarshalerType = element._signatureType.Type;
                    return $i1;
                })());
            }
            static /*JSMarshalerType */ Span(/*JSMarshalerType*/ element)
            {
                $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType.CheckArraySegment(element);
                return new $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType().$ctor$2((() =>
                {
                    //new $.$srij.System.Runtime.InteropServices.JavaScript.JSFunctionBinding.JSBindingType()
                    const $t1 = $.$srij.System.Runtime.InteropServices.JavaScript.JSFunctionBinding.JSBindingType;
                    const $i1 = new $t1();
                    $i1.Type = 23/*MarshalerType.Span*/;
                    $i1.Arg1MarshalerType = element._signatureType.Type;
                    return $i1;
                })());
            }
            /*JSMarshalerType*/ static _action = null;
            static /*JSMarshalerType */ Action()
            {
                return $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType._action;
            }
            static /*JSMarshalerType */ Action$1(/*JSMarshalerType*/ arg1)
            {
                $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType.CheckTask(arg1);
                return new $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType().$ctor$2((() =>
                {
                    //new $.$srij.System.Runtime.InteropServices.JavaScript.JSFunctionBinding.JSBindingType()
                    const $t1 = $.$srij.System.Runtime.InteropServices.JavaScript.JSFunctionBinding.JSBindingType;
                    const $i1 = new $t1();
                    $i1.Type = 24/*MarshalerType.Action*/;
                    $i1.Arg1MarshalerType = arg1._signatureType.Type;
                    return $i1;
                })());
            }
            static /*JSMarshalerType */ Action$2(/*JSMarshalerType*/ arg1, /*JSMarshalerType*/ arg2)
            {
                $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType.CheckTask(arg1);
                $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType.CheckTask(arg2);
                return new $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType().$ctor$2((() =>
                {
                    //new $.$srij.System.Runtime.InteropServices.JavaScript.JSFunctionBinding.JSBindingType()
                    const $t1 = $.$srij.System.Runtime.InteropServices.JavaScript.JSFunctionBinding.JSBindingType;
                    const $i1 = new $t1();
                    $i1.Type = 24/*MarshalerType.Action*/;
                    $i1.Arg1MarshalerType = arg1._signatureType.Type;
                    $i1.Arg2MarshalerType = arg2._signatureType.Type;
                    return $i1;
                })());
            }
            static /*JSMarshalerType */ Action$3(/*JSMarshalerType*/ arg1, /*JSMarshalerType*/ arg2, /*JSMarshalerType*/ arg3)
            {
                $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType.CheckTask(arg1);
                $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType.CheckTask(arg2);
                $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType.CheckTask(arg3);
                return new $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType().$ctor$2((() =>
                {
                    //new $.$srij.System.Runtime.InteropServices.JavaScript.JSFunctionBinding.JSBindingType()
                    const $t1 = $.$srij.System.Runtime.InteropServices.JavaScript.JSFunctionBinding.JSBindingType;
                    const $i1 = new $t1();
                    $i1.Type = 24/*MarshalerType.Action*/;
                    $i1.Arg1MarshalerType = arg1._signatureType.Type;
                    $i1.Arg2MarshalerType = arg2._signatureType.Type;
                    $i1.Arg3MarshalerType = arg3._signatureType.Type;
                    return $i1;
                })());
            }
            static /*JSMarshalerType */ Function(/*JSMarshalerType*/ result)
            {
                $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType.CheckTask(result);
                return new $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType().$ctor$2((() =>
                {
                    //new $.$srij.System.Runtime.InteropServices.JavaScript.JSFunctionBinding.JSBindingType()
                    const $t1 = $.$srij.System.Runtime.InteropServices.JavaScript.JSFunctionBinding.JSBindingType;
                    const $i1 = new $t1();
                    $i1.Type = 25/*MarshalerType.Function*/;
                    $i1.ResultMarshalerType = result._signatureType.Type;
                    return $i1;
                })());
            }
            static /*JSMarshalerType */ Function$1(/*JSMarshalerType*/ arg1, /*JSMarshalerType*/ result)
            {
                $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType.CheckTask(arg1);
                $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType.CheckTask(result);
                return new $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType().$ctor$2((() =>
                {
                    //new $.$srij.System.Runtime.InteropServices.JavaScript.JSFunctionBinding.JSBindingType()
                    const $t1 = $.$srij.System.Runtime.InteropServices.JavaScript.JSFunctionBinding.JSBindingType;
                    const $i1 = new $t1();
                    $i1.Type = 25/*MarshalerType.Function*/;
                    $i1.Arg1MarshalerType = arg1._signatureType.Type;
                    $i1.ResultMarshalerType = result._signatureType.Type;
                    return $i1;
                })());
            }
            static /*JSMarshalerType */ Function$2(/*JSMarshalerType*/ arg1, /*JSMarshalerType*/ arg2, /*JSMarshalerType*/ result)
            {
                $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType.CheckTask(arg1);
                $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType.CheckTask(arg2);
                $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType.CheckTask(result);
                return new $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType().$ctor$2((() =>
                {
                    //new $.$srij.System.Runtime.InteropServices.JavaScript.JSFunctionBinding.JSBindingType()
                    const $t1 = $.$srij.System.Runtime.InteropServices.JavaScript.JSFunctionBinding.JSBindingType;
                    const $i1 = new $t1();
                    $i1.Type = 25/*MarshalerType.Function*/;
                    $i1.Arg1MarshalerType = arg1._signatureType.Type;
                    $i1.Arg2MarshalerType = arg2._signatureType.Type;
                    $i1.ResultMarshalerType = result._signatureType.Type;
                    return $i1;
                })());
            }
            static /*JSMarshalerType */ Function$3(/*JSMarshalerType*/ arg1, /*JSMarshalerType*/ arg2, /*JSMarshalerType*/ arg3, /*JSMarshalerType*/ result)
            {
                $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType.CheckTask(arg1);
                $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType.CheckTask(arg2);
                $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType.CheckTask(arg3);
                $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType.CheckTask(result);
                return new $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType().$ctor$2((() =>
                {
                    //new $.$srij.System.Runtime.InteropServices.JavaScript.JSFunctionBinding.JSBindingType()
                    const $t1 = $.$srij.System.Runtime.InteropServices.JavaScript.JSFunctionBinding.JSBindingType;
                    const $i1 = new $t1();
                    $i1.Type = 25/*MarshalerType.Function*/;
                    $i1.Arg1MarshalerType = arg1._signatureType.Type;
                    $i1.Arg2MarshalerType = arg2._signatureType.Type;
                    $i1.Arg3MarshalerType = arg3._signatureType.Type;
                    $i1.ResultMarshalerType = result._signatureType.Type;
                    return $i1;
                })());
            }
            static /*void */ CheckNullable(/*JSMarshalerType*/ underlyingType)
            {
                /*MarshalerType*/ let underlying = underlyingType._signatureType.Type;
                if (underlying === 3/*MarshalerType.Boolean*/ || underlying === 4/*MarshalerType.Byte*/ || underlying === 6/*MarshalerType.Int16*/ || underlying === 7/*MarshalerType.Int32*/ || underlying === 9/*MarshalerType.BigInt64*/ || underlying === 8/*MarshalerType.Int52*/ || underlying === 12/*MarshalerType.IntPtr*/ || underlying === 10/*MarshalerType.Double*/ || underlying === 11/*MarshalerType.Single*/ || underlying === 5/*MarshalerType.Char*/ || underlying === 17/*MarshalerType.DateTime*/ || underlying === 18/*MarshalerType.DateTimeOffset*/)
                {
                    return;
                }
                throw new $.$spc.System.ArgumentException().$ctor$13($.$srij.System.SR.Format($.$srij.System.SR.UnsupportedNullableType, $.$box(underlying, $.$srij.System.Runtime.InteropServices.JavaScript.MarshalerType)), "underlyingType");
            }
            static /*void */ CheckArray(/*JSMarshalerType*/ underlyingType)
            {
                /*MarshalerType*/ let underlying = underlyingType._signatureType.Type;
                if (underlying === 4/*MarshalerType.Byte*/ || underlying === 7/*MarshalerType.Int32*/ || underlying === 10/*MarshalerType.Double*/ || underlying === 15/*MarshalerType.String*/ || underlying === 14/*MarshalerType.Object*/ || underlying === 13/*MarshalerType.JSObject*/)
                {
                    return;
                }
                throw new $.$spc.System.ArgumentException().$ctor$13($.$srij.System.SR.Format($.$srij.System.SR.UnsupportedElementType, $.$box(underlying, $.$srij.System.Runtime.InteropServices.JavaScript.MarshalerType)), "underlyingType");
            }
            static /*void */ CheckArraySegment(/*JSMarshalerType*/ underlyingType)
            {
                /*MarshalerType*/ let underlying = underlyingType._signatureType.Type;
                if (underlying === 4/*MarshalerType.Byte*/ || underlying === 7/*MarshalerType.Int32*/ || underlying === 10/*MarshalerType.Double*/)
                {
                    return;
                }
                throw new $.$spc.System.ArgumentException().$ctor$13($.$srij.System.SR.Format($.$srij.System.SR.UnsupportedElementType, $.$box(underlying, $.$srij.System.Runtime.InteropServices.JavaScript.MarshalerType)), "underlyingType");
            }
            static /*void */ CheckTask(/*JSMarshalerType*/ underlyingType)
            {
                /*MarshalerType*/ let underlying = underlyingType._signatureType.Type;
                if (underlying === 21/*MarshalerType.Array*/ || underlying === 22/*MarshalerType.ArraySegment*/ || underlying === 23/*MarshalerType.Span*/ || underlying === 20/*MarshalerType.Task*/ || underlying === 24/*MarshalerType.Action*/ || underlying === 25/*MarshalerType.Function*/)
                {
                    throw new $.$spc.System.ArgumentException().$ctor$13($.$srij.System.SR.Format($.$srij.System.SR.UnsupportedTaskResultType, $.$box(underlying, $.$srij.System.Runtime.InteropServices.JavaScript.MarshalerType)), "underlyingType");
                }
            }
            //default member initializer
            constructor()
            {
                super();
                this._signatureType = $.$default($.$srij.System.Runtime.InteropServices.JavaScript.JSFunctionBinding.JSBindingType);
            }
            //Static Initializer
            static $sinit()
            {
                {
                    this.Void = new $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType().$ctor$2((() =>
                    {
                        //new $.$srij.System.Runtime.InteropServices.JavaScript.JSFunctionBinding.JSBindingType()
                        const $t1 = $.$srij.System.Runtime.InteropServices.JavaScript.JSFunctionBinding.JSBindingType;
                        const $i1 = new $t1();
                        $i1.Type = 1/*MarshalerType.Void*/;
                        return $i1;
                    })());
                }
                {
                    this.Discard = new $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType().$ctor$2((() =>
                    {
                        //new $.$srij.System.Runtime.InteropServices.JavaScript.JSFunctionBinding.JSBindingType()
                        const $t1 = $.$srij.System.Runtime.InteropServices.JavaScript.JSFunctionBinding.JSBindingType;
                        const $i1 = new $t1();
                        $i1.Type = 2/*MarshalerType.Discard*/;
                        return $i1;
                    })());
                }
                {
                    this.DiscardNoWait = new $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType().$ctor$2((() =>
                    {
                        //new $.$srij.System.Runtime.InteropServices.JavaScript.JSFunctionBinding.JSBindingType()
                        const $t1 = $.$srij.System.Runtime.InteropServices.JavaScript.JSFunctionBinding.JSBindingType;
                        const $i1 = new $t1();
                        $i1.Type = 26/*MarshalerType.DiscardNoWait*/;
                        return $i1;
                    })());
                }
                {
                    this.Boolean = new $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType().$ctor$2((() =>
                    {
                        //new $.$srij.System.Runtime.InteropServices.JavaScript.JSFunctionBinding.JSBindingType()
                        const $t1 = $.$srij.System.Runtime.InteropServices.JavaScript.JSFunctionBinding.JSBindingType;
                        const $i1 = new $t1();
                        $i1.Type = 3/*MarshalerType.Boolean*/;
                        return $i1;
                    })());
                }
                {
                    this.Byte = new $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType().$ctor$2((() =>
                    {
                        //new $.$srij.System.Runtime.InteropServices.JavaScript.JSFunctionBinding.JSBindingType()
                        const $t1 = $.$srij.System.Runtime.InteropServices.JavaScript.JSFunctionBinding.JSBindingType;
                        const $i1 = new $t1();
                        $i1.Type = 4/*MarshalerType.Byte*/;
                        return $i1;
                    })());
                }
                {
                    this.Char = new $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType().$ctor$2((() =>
                    {
                        //new $.$srij.System.Runtime.InteropServices.JavaScript.JSFunctionBinding.JSBindingType()
                        const $t1 = $.$srij.System.Runtime.InteropServices.JavaScript.JSFunctionBinding.JSBindingType;
                        const $i1 = new $t1();
                        $i1.Type = 5/*MarshalerType.Char*/;
                        return $i1;
                    })());
                }
                {
                    this.Int16 = new $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType().$ctor$2((() =>
                    {
                        //new $.$srij.System.Runtime.InteropServices.JavaScript.JSFunctionBinding.JSBindingType()
                        const $t1 = $.$srij.System.Runtime.InteropServices.JavaScript.JSFunctionBinding.JSBindingType;
                        const $i1 = new $t1();
                        $i1.Type = 6/*MarshalerType.Int16*/;
                        return $i1;
                    })());
                }
                {
                    this.Int32 = new $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType().$ctor$2((() =>
                    {
                        //new $.$srij.System.Runtime.InteropServices.JavaScript.JSFunctionBinding.JSBindingType()
                        const $t1 = $.$srij.System.Runtime.InteropServices.JavaScript.JSFunctionBinding.JSBindingType;
                        const $i1 = new $t1();
                        $i1.Type = 7/*MarshalerType.Int32*/;
                        return $i1;
                    })());
                }
                {
                    this.Int52 = new $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType().$ctor$2((() =>
                    {
                        //new $.$srij.System.Runtime.InteropServices.JavaScript.JSFunctionBinding.JSBindingType()
                        const $t1 = $.$srij.System.Runtime.InteropServices.JavaScript.JSFunctionBinding.JSBindingType;
                        const $i1 = new $t1();
                        $i1.Type = 8/*MarshalerType.Int52*/;
                        return $i1;
                    })());
                }
                {
                    this.BigInt64 = new $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType().$ctor$2((() =>
                    {
                        //new $.$srij.System.Runtime.InteropServices.JavaScript.JSFunctionBinding.JSBindingType()
                        const $t1 = $.$srij.System.Runtime.InteropServices.JavaScript.JSFunctionBinding.JSBindingType;
                        const $i1 = new $t1();
                        $i1.Type = 9/*MarshalerType.BigInt64*/;
                        return $i1;
                    })());
                }
                {
                    this.Double = new $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType().$ctor$2((() =>
                    {
                        //new $.$srij.System.Runtime.InteropServices.JavaScript.JSFunctionBinding.JSBindingType()
                        const $t1 = $.$srij.System.Runtime.InteropServices.JavaScript.JSFunctionBinding.JSBindingType;
                        const $i1 = new $t1();
                        $i1.Type = 10/*MarshalerType.Double*/;
                        return $i1;
                    })());
                }
                {
                    this.Single = new $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType().$ctor$2((() =>
                    {
                        //new $.$srij.System.Runtime.InteropServices.JavaScript.JSFunctionBinding.JSBindingType()
                        const $t1 = $.$srij.System.Runtime.InteropServices.JavaScript.JSFunctionBinding.JSBindingType;
                        const $i1 = new $t1();
                        $i1.Type = 11/*MarshalerType.Single*/;
                        return $i1;
                    })());
                }
                {
                    this.IntPtr = new $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType().$ctor$2((() =>
                    {
                        //new $.$srij.System.Runtime.InteropServices.JavaScript.JSFunctionBinding.JSBindingType()
                        const $t1 = $.$srij.System.Runtime.InteropServices.JavaScript.JSFunctionBinding.JSBindingType;
                        const $i1 = new $t1();
                        $i1.Type = 12/*MarshalerType.IntPtr*/;
                        return $i1;
                    })());
                }
                {
                    this.JSObject = new $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType().$ctor$2((() =>
                    {
                        //new $.$srij.System.Runtime.InteropServices.JavaScript.JSFunctionBinding.JSBindingType()
                        const $t1 = $.$srij.System.Runtime.InteropServices.JavaScript.JSFunctionBinding.JSBindingType;
                        const $i1 = new $t1();
                        $i1.Type = 13/*MarshalerType.JSObject*/;
                        return $i1;
                    })());
                }
                {
                    this.Object = new $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType().$ctor$2((() =>
                    {
                        //new $.$srij.System.Runtime.InteropServices.JavaScript.JSFunctionBinding.JSBindingType()
                        const $t1 = $.$srij.System.Runtime.InteropServices.JavaScript.JSFunctionBinding.JSBindingType;
                        const $i1 = new $t1();
                        $i1.Type = 14/*MarshalerType.Object*/;
                        return $i1;
                    })());
                }
                {
                    this.String = new $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType().$ctor$2((() =>
                    {
                        //new $.$srij.System.Runtime.InteropServices.JavaScript.JSFunctionBinding.JSBindingType()
                        const $t1 = $.$srij.System.Runtime.InteropServices.JavaScript.JSFunctionBinding.JSBindingType;
                        const $i1 = new $t1();
                        $i1.Type = 15/*MarshalerType.String*/;
                        return $i1;
                    })());
                }
                {
                    this.Exception = new $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType().$ctor$2((() =>
                    {
                        //new $.$srij.System.Runtime.InteropServices.JavaScript.JSFunctionBinding.JSBindingType()
                        const $t1 = $.$srij.System.Runtime.InteropServices.JavaScript.JSFunctionBinding.JSBindingType;
                        const $i1 = new $t1();
                        $i1.Type = 16/*MarshalerType.Exception*/;
                        return $i1;
                    })());
                }
                {
                    this.DateTime = new $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType().$ctor$2((() =>
                    {
                        //new $.$srij.System.Runtime.InteropServices.JavaScript.JSFunctionBinding.JSBindingType()
                        const $t1 = $.$srij.System.Runtime.InteropServices.JavaScript.JSFunctionBinding.JSBindingType;
                        const $i1 = new $t1();
                        $i1.Type = 17/*MarshalerType.DateTime*/;
                        return $i1;
                    })());
                }
                {
                    this.DateTimeOffset = new $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType().$ctor$2((() =>
                    {
                        //new $.$srij.System.Runtime.InteropServices.JavaScript.JSFunctionBinding.JSBindingType()
                        const $t1 = $.$srij.System.Runtime.InteropServices.JavaScript.JSFunctionBinding.JSBindingType;
                        const $i1 = new $t1();
                        $i1.Type = 18/*MarshalerType.DateTimeOffset*/;
                        return $i1;
                    })());
                }
                {
                    this._task = new $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType().$ctor$2((() =>
                    {
                        //new $.$srij.System.Runtime.InteropServices.JavaScript.JSFunctionBinding.JSBindingType()
                        const $t1 = $.$srij.System.Runtime.InteropServices.JavaScript.JSFunctionBinding.JSBindingType;
                        const $i1 = new $t1();
                        $i1.Type = 20/*MarshalerType.Task*/;
                        return $i1;
                    })());
                }
                {
                    this._action = new $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType().$ctor$2((() =>
                    {
                        //new $.$srij.System.Runtime.InteropServices.JavaScript.JSFunctionBinding.JSBindingType()
                        const $t1 = $.$srij.System.Runtime.InteropServices.JavaScript.JSFunctionBinding.JSBindingType;
                        const $i1 = new $t1();
                        $i1.Type = 24/*MarshalerType.Action*/;
                        return $i1;
                    })());
                }
            }
            static $h = 2216172;
            static $f = 0b10010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":2216172,"g":{"r":0,"d":0,"h":25772019948,"f":33},"n":"Void","d":2216172,"h":21477052652,"f":33},{"p":2216172,"g":{"r":0,"d":0,"h":38656921836,"f":33},"n":"Discard","d":2216172,"h":34361954540,"f":33},{"p":2216172,"g":{"r":0,"d":0,"h":51541823724,"f":33},"n":"DiscardNoWait","d":2216172,"h":47246856428,"f":33},{"p":2216172,"g":{"r":0,"d":0,"h":64426725612,"f":33},"n":"Boolean","d":2216172,"h":60131758316,"f":33},{"p":2216172,"g":{"r":0,"d":0,"h":77311627500,"f":33},"n":"Byte","d":2216172,"h":73016660204,"f":33},{"p":2216172,"g":{"r":0,"d":0,"h":90196529388,"f":33},"n":"Char","d":2216172,"h":85901562092,"f":33},{"p":2216172,"g":{"r":0,"d":0,"h":103081431276,"f":33},"n":"Int16","d":2216172,"h":98786463980,"f":33},{"p":2216172,"g":{"r":0,"d":0,"h":115966333164,"f":33},"n":"Int32","d":2216172,"h":111671365868,"f":33},{"p":2216172,"g":{"r":0,"d":0,"h":128851235052,"f":33},"n":"Int52","d":2216172,"h":124556267756,"f":33},{"p":2216172,"g":{"r":0,"d":0,"h":141736136940,"f":33},"n":"BigInt64","d":2216172,"h":137441169644,"f":33},{"p":2216172,"g":{"r":0,"d":0,"h":154621038828,"f":33},"n":"Double","d":2216172,"h":150326071532,"f":33},{"p":2216172,"g":{"r":0,"d":0,"h":167505940716,"f":33},"n":"Single","d":2216172,"h":163210973420,"f":33},{"p":2216172,"g":{"r":0,"d":0,"h":180390842604,"f":33},"n":"IntPtr","d":2216172,"h":176095875308,"f":33},{"p":2216172,"g":{"r":0,"d":0,"h":193275744492,"f":33},"n":"JSObject","d":2216172,"h":188980777196,"f":33},{"p":2216172,"g":{"r":0,"d":0,"h":206160646380,"f":33},"n":"Object","d":2216172,"h":201865679084,"f":33},{"p":2216172,"g":{"r":0,"d":0,"h":219045548268,"f":33},"n":"String","d":2216172,"h":214750580972,"f":33},{"p":2216172,"g":{"r":0,"d":0,"h":244815352044,"f":33},"n":"DateTime","d":2216172,"h":240520384748,"f":33},{"p":2216172,"g":{"r":0,"d":0,"h":257700253932,"f":33},"n":"DateTimeOffset","d":2216172,"h":253405286636,"f":33},{"p":2216172,"g":{"r":0,"d":0,"h":274880123116,"f":34},"n":"_task","d":2216172,"h":270585155820,"f":34},{"p":2216172,"g":{"r":0,"d":0,"h":309239861484,"f":34},"n":"_action","d":2216172,"h":304944894188,"f":34}],"m":[{"r":2216172,"p":[{"n":"primitive","p":2216172}],"n":"Nullable","d":2216172,"h":261995221228,"f":33},{"r":2216172,"n":"Task","d":2216172,"h":279175090412,"f":33},{"r":2216172,"p":[{"n":"result","p":2216172}],"n":"Task","o":"@$1","d":2216172,"h":283470057708,"f":33},{"r":2216172,"p":[{"n":"element","p":2216172}],"n":"Array","d":2216172,"h":287765025004,"f":33},{"r":2216172,"p":[{"n":"element","p":2216172}],"n":"ArraySegment","d":2216172,"h":292059992300,"f":33},{"r":2216172,"p":[{"n":"element","p":2216172}],"n":"Span","d":2216172,"h":296354959596,"f":33},{"r":2216172,"n":"Action","d":2216172,"h":313534828780,"f":33},{"r":2216172,"p":[{"n":"arg1","p":2216172}],"n":"Action","o":"@$1","d":2216172,"h":317829796076,"f":33},{"r":2216172,"p":[{"n":"arg1","p":2216172},{"n":"arg2","p":2216172}],"n":"Action","o":"@$2","d":2216172,"h":322124763372,"f":33},{"r":2216172,"p":[{"n":"arg1","p":2216172},{"n":"arg2","p":2216172},{"n":"arg3","p":2216172}],"n":"Action","o":"@$3","d":2216172,"h":326419730668,"f":33},{"r":2216172,"p":[{"n":"result","p":2216172}],"n":"Function","d":2216172,"h":330714697964,"f":33},{"r":2216172,"p":[{"n":"arg1","p":2216172},{"n":"result","p":2216172}],"n":"Function","o":"@$1","d":2216172,"h":335009665260,"f":33},{"r":2216172,"p":[{"n":"arg1","p":2216172},{"n":"arg2","p":2216172},{"n":"result","p":2216172}],"n":"Function","o":"@$2","d":2216172,"h":339304632556,"f":33},{"r":2216172,"p":[{"n":"arg1","p":2216172},{"n":"arg2","p":2216172},{"n":"arg3","p":2216172},{"n":"result","p":2216172}],"n":"Function","o":"@$3","d":2216172,"h":343599599852,"f":33},{"r":65537,"p":[{"n":"underlyingType","p":2216172}],"n":"CheckNullable","d":2216172,"h":347894567148,"f":40},{"r":65537,"p":[{"n":"underlyingType","p":2216172}],"n":"CheckArray","d":2216172,"h":352189534444,"f":40},{"r":65537,"p":[{"n":"underlyingType","p":2216172}],"n":"CheckArraySegment","d":2216172,"h":356484501740,"f":40},{"r":65537,"p":[{"n":"underlyingType","p":2216172}],"n":"CheckTask","d":2216172,"h":360779469036,"f":40}],"l":[{"t":708844,"n":"_signatureType","d":2216172,"h":4297183468,"f":8}],"c":[{"n":".ctor","o":"$ctor$1","d":2216172,"h":8592150764,"f":2},{"p":[{"n":"signatureType","p":708844}],"n":".ctor","o":"$ctor$2","d":2216172,"h":12887118060,"f":2}],"h":2216172,"a":[{"t":114950145,"c":4409917441,"a":[{"v":"browser","t":1310721}]},{"t":33226753,"c":4328194049,"a":[{"v":1,"t":33292289}]}]}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.Runtime.InteropServices.JavaScript.JSMarshalerType`; }
        });
        
        $asm.$cls("$srij.System.SR", ($self) => class SR
        {
            /*global::System.Resources.ResourceManager*/ static s_resourceManager = null;
            /*global::System.Globalization.CultureInfo*/ static resourceCulture = null;
            static /*global::System.Resources.ResourceManager */ get ResourceManager()
            {
                if ($.$spc.System.Object.ReferenceEquals($.$srij.System.SR.s_resourceManager, null))
                {
                    /*global::System.Resources.ResourceManager*/ let temp = new $.$spc.System.Resources.ResourceManager().$ctor$3("System.Runtime.InteropServices.JavaScript", $.$srij.System.SR.$type.Assembly);
                    $.$srij.System.SR.s_resourceManager = temp;
                }
                return $.$srij.System.SR.s_resourceManager;
            }
            static /*global::System.Globalization.CultureInfo */ get Culture()
            {
                return $.$srij.System.SR.resourceCulture;
            }
            static /*global::System.Globalization.CultureInfo */ set Culture(value)
            {
                $.$srij.System.SR.resourceCulture = value;
            }
            static /*string */ get ArgumentCannotBeNull()
            {
                return "Invalid argument: {0} can not be null.";
            }
            static /*string */ FormatArgumentCannotBeNull(/*object*/ arg1)
            {
                return $.$spc.System.String.Format("Invalid argument: {0} can not be null.", arg1);
            }
            static /*string */ get ArgumentCannotBeNullWithLength()
            {
                return "Invalid argument: {0} can not be null and must have a length.";
            }
            static /*string */ FormatArgumentCannotBeNullWithLength(/*object*/ arg1)
            {
                return $.$spc.System.String.Format("Invalid argument: {0} can not be null and must have a length.", arg1);
            }
            static /*string */ get SystemRuntimeInteropServicesJavaScript_PlatformNotSupported()
            {
                return "System.Runtime.InteropServices.JavaScript is not supported on this platform.";
            }
            static /*string */ get TypedArrayNotCorrectType()
            {
                return "TypedArray is not of correct type.";
            }
            static /*string */ get UnableCastNullToType()
            {
                return "Unable to cast null to type {0}.";
            }
            static /*string */ FormatUnableCastNullToType(/*object*/ arg1)
            {
                return $.$spc.System.String.Format("Unable to cast null to type {0}.", arg1);
            }
            static /*string */ get UnableCastObjectToType()
            {
                return "Unable to cast object of type {0} to type {1}.";
            }
            static /*string */ FormatUnableCastObjectToType(/*object*/ arg1, /*object*/ arg2)
            {
                return $.$spc.System.String.Format$1("Unable to cast object of type {0} to type {1}.", arg1, arg2);
            }
            static /*string */ get MissingManagedEntrypointHandle()
            {
                return "Managed entrypoint handle is not set.";
            }
            static /*string */ get CannotResolveManagedEntrypointHandle()
            {
                return "Cannot resolve managed entrypoint handle.";
            }
            static /*string */ get ReturnTypeNotSupportedForMain()
            {
                return "Return type '{0}' from main method in not supported.";
            }
            static /*string */ FormatReturnTypeNotSupportedForMain(/*object*/ arg1)
            {
                return $.$spc.System.String.Format("Return type '{0}' from main method in not supported.", arg1);
            }
            static /*string */ get NullToManagedCallback()
            {
                return "ToManagedCallback is null.";
            }
            static /*string */ get NullPromiseHolder()
            {
                return "PromiseHolder is null.";
            }
            static /*string */ get EmptyProfileData()
            {
                return "Empty profile data.";
            }
            static /*string */ get ErrorLegacySettingProperty()
            {
                return "Error setting {0} on (js-obj js '{1}'): {2}.";
            }
            static /*string */ FormatErrorLegacySettingProperty(/*object*/ arg1, /*object*/ arg2, /*object*/ arg3)
            {
                return $.$spc.System.String.Format$2("Error setting {0} on (js-obj js '{1}'): {2}.", arg1, arg2, arg3);
            }
            static /*string */ get ErrorResolvingFromGlobalThis()
            {
                return "Error resolving property {0} from globalThis.";
            }
            static /*string */ FormatErrorResolvingFromGlobalThis(/*object*/ arg1)
            {
                return $.$spc.System.String.Format("Error resolving property {0} from globalThis.", arg1);
            }
            static /*string */ get FailedToMarshalException()
            {
                return "Failed to marshal exception.";
            }
            static /*string */ get FailedToMarshalPromiseHolder()
            {
                return "Failed to marshal Promise callback.";
            }
            static /*string */ get InvalidInFlightCounter()
            {
                return "Invalid InFlightCounter for JSObject {0}, expected: {1}, actual: {2}.";
            }
            static /*string */ FormatInvalidInFlightCounter(/*object*/ arg1, /*object*/ arg2, /*object*/ arg3)
            {
                return $.$spc.System.String.Format$2("Invalid InFlightCounter for JSObject {0}, expected: {1}, actual: {2}.", arg1, arg2, arg3);
            }
            static /*string */ get ToJSNotImplemented()
            {
                return "ToJS for {0} is not implemented.";
            }
            static /*string */ FormatToJSNotImplemented(/*object*/ arg1)
            {
                return $.$spc.System.String.Format("ToJS for {0} is not implemented.", arg1);
            }
            static /*string */ get ToManagedNotImplemented()
            {
                return "ToManaged for {0} is not implemented.";
            }
            static /*string */ FormatToManagedNotImplemented(/*object*/ arg1)
            {
                return $.$spc.System.String.Format("ToManaged for {0} is not implemented.", arg1);
            }
            static /*string */ get UnableToResolveHandleAsException()
            {
                return "Unable to resolve the handle as an Exception.";
            }
            static /*string */ get UnsupportedArrayType()
            {
                return "Unsupported array type {0}. Only single-dimensional arrays with a zero lower bound can be marshaled to JS.";
            }
            static /*string */ FormatUnsupportedArrayType(/*object*/ arg1)
            {
                return $.$spc.System.String.Format("Unsupported array type {0}. Only single-dimensional arrays with a zero lower bound can be marshaled to JS.", arg1);
            }
            static /*string */ get UnsupportedElementType()
            {
                return "Unsupported element type {0}.";
            }
            static /*string */ FormatUnsupportedElementType(/*object*/ arg1)
            {
                return $.$spc.System.String.Format("Unsupported element type {0}.", arg1);
            }
            static /*string */ get UnsupportedEnumType()
            {
                return "Unsupported enum type {0}.";
            }
            static /*string */ FormatUnsupportedEnumType(/*object*/ arg1)
            {
                return $.$spc.System.String.Format("Unsupported enum type {0}.", arg1);
            }
            static /*string */ get UnsupportedLegacyMarshlerType()
            {
                return "Unsupported marshal type {0}.";
            }
            static /*string */ FormatUnsupportedLegacyMarshlerType(/*object*/ arg1)
            {
                return $.$spc.System.String.Format("Unsupported marshal type {0}.", arg1);
            }
            static /*string */ get UnsupportedNullableType()
            {
                return "Unsupported nullable type {0}.";
            }
            static /*string */ FormatUnsupportedNullableType(/*object*/ arg1)
            {
                return $.$spc.System.String.Format("Unsupported nullable type {0}.", arg1);
            }
            static /*string */ get UnsupportedTaskResultType()
            {
                return "Unsupported task result type {0}.";
            }
            static /*string */ FormatUnsupportedTaskResultType(/*object*/ arg1)
            {
                return $.$spc.System.String.Format("Unsupported task result type {0}.", arg1);
            }
            static /*string */ get UriConstructorMissing()
            {
                return "Constructor on type 'System.Uri' not found. Please consider to protect it's constructor from trimming.";
            }
            static /*string */ get UriTypeMissing()
            {
                return "The type System.Uri could not be found. Please consider to protect the class and it's constructor from trimming.";
            }
            static /*string */ get ValueOutOf52BitRange()
            {
                return "Overflow: value {0} is out of {1} {2} range.";
            }
            static /*string */ FormatValueOutOf52BitRange(/*object*/ arg1, /*object*/ arg2, /*object*/ arg3)
            {
                return $.$spc.System.String.Format$2("Overflow: value {0} is out of {1} {2} range.", arg1, arg2, arg3);
            }
            /*bool*/ static s_usingResourceKeys = false;
            static /*bool */ GetUsingResourceKeysSwitchValue()
            {
                /*bool*/ let usingResourceKeys;
                return $.$spc.System.AppContext.TryGetSwitch("System.Resources.UseSystemResourceKeys", $.$ref(() => usingResourceKeys, ($v) => usingResourceKeys = $v, $.$spc.System.Boolean)) ? usingResourceKeys : false;
            }
            static /*bool */ UsingResourceKeys()
            {
                return $.$srij.System.SR.s_usingResourceKeys;
            }
            static /*string */ GetResourceString(/*string*/ resourceKey)
            {
                if ($.$srij.System.SR.UsingResourceKeys())
                {
                    return resourceKey;
                }
                /*string?*/ let resourceString = null;
                try
                {
                    resourceString = $.$srij.System.SR.ResourceManager.GetString(resourceKey);
                }
                catch($e)
                {
                }
                return resourceString;
            }
            static /*string */ GetResourceString$1(/*string*/ resourceKey, /*string*/ defaultString)
            {
                /*string*/ let resourceString = $.$srij.System.SR.GetResourceString(resourceKey);
                return $.$spc.System.String.op_Equality(resourceKey, resourceString) || $.$spc.System.String.op_Equality(resourceString, null) ? defaultString : resourceString;
            }
            static /*string */ Format(/*string*/ resourceFormat, /*object?*/ p1)
            {
                if ($.$srij.System.SR.UsingResourceKeys())
                {
                    return $.$spc.System.String.Join$10(", ", $.$spc.System.ReadOnlySpan$$($.$spc.System.Object).op_Implicit([ resourceFormat, p1 ]));
                }
                return $.$spc.System.String.Format(resourceFormat, p1);
            }
            static /*string */ Format$1(/*string*/ resourceFormat, /*object?*/ p1, /*object?*/ p2)
            {
                if ($.$srij.System.SR.UsingResourceKeys())
                {
                    return $.$spc.System.String.Join$10(", ", $.$spc.System.ReadOnlySpan$$($.$spc.System.Object).op_Implicit([ resourceFormat, p1, p2 ]));
                }
                return $.$spc.System.String.Format$1(resourceFormat, p1, p2);
            }
            static /*string */ Format$2(/*string*/ resourceFormat, /*object?*/ p1, /*object?*/ p2, /*object?*/ p3)
            {
                if ($.$srij.System.SR.UsingResourceKeys())
                {
                    return $.$spc.System.String.Join$10(", ", $.$spc.System.ReadOnlySpan$$($.$spc.System.Object).op_Implicit([ resourceFormat, p1, p2, p3 ]));
                }
                return $.$spc.System.String.Format$2(resourceFormat, p1, p2, p3);
            }
            static /*string */ Format$3(/*string*/ resourceFormat, /*params object?[]?*/ args)
            {
                if (args !== null)
                {
                    if ($.$srij.System.SR.UsingResourceKeys())
                    {
                        return resourceFormat + ", " + $.$spc.System.String.Join$9(", ", args);
                    }
                    return $.$spc.System.String.Format$3(resourceFormat, args);
                }
                return resourceFormat;
            }
            static /*string */ Format$4(/*IFormatProvider?*/ provider, /*string*/ resourceFormat, /*object?*/ p1)
            {
                if ($.$srij.System.SR.UsingResourceKeys())
                {
                    return $.$spc.System.String.Join$10(", ", $.$spc.System.ReadOnlySpan$$($.$spc.System.Object).op_Implicit([ resourceFormat, p1 ]));
                }
                return $.$spc.System.String.Format$5(provider, resourceFormat, p1);
            }
            static /*string */ Format$5(/*IFormatProvider?*/ provider, /*string*/ resourceFormat, /*object?*/ p1, /*object?*/ p2)
            {
                if ($.$srij.System.SR.UsingResourceKeys())
                {
                    return $.$spc.System.String.Join$10(", ", $.$spc.System.ReadOnlySpan$$($.$spc.System.Object).op_Implicit([ resourceFormat, p1, p2 ]));
                }
                return $.$spc.System.String.Format$6(provider, resourceFormat, p1, p2);
            }
            static /*string */ Format$6(/*IFormatProvider?*/ provider, /*string*/ resourceFormat, /*object?*/ p1, /*object?*/ p2, /*object?*/ p3)
            {
                if ($.$srij.System.SR.UsingResourceKeys())
                {
                    return $.$spc.System.String.Join$10(", ", $.$spc.System.ReadOnlySpan$$($.$spc.System.Object).op_Implicit([ resourceFormat, p1, p2, p3 ]));
                }
                return $.$spc.System.String.Format$7(provider, resourceFormat, p1, p2, p3);
            }
            static /*string */ Format$7(/*IFormatProvider?*/ provider, /*string*/ resourceFormat, /*params object?[]?*/ args)
            {
                if (args !== null)
                {
                    if ($.$srij.System.SR.UsingResourceKeys())
                    {
                        return resourceFormat + ", " + $.$spc.System.String.Join$9(", ", args);
                    }
                    return $.$spc.System.String.Format$8(provider, resourceFormat, args);
                }
                return resourceFormat;
            }
            //Static Initializer
            static $sinit()
            {
                {
                    this.s_usingResourceKeys = $.$srij.System.SR.GetUsingResourceKeysSwitchValue();
                }
            }
            static $h = 3789036;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"h":3789036}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.SR`; }
        });
        
        $asm.$cls("$srij.System.Runtime.InteropServices.JavaScript.CancelablePromise", ($self) => class CancelablePromise
        {
            static /*void */ CancelPromise(/*Task*/ promise)
            {
                if (promise.IsCompleted)
                {
                    return;
                }
                /*JSHostImplementation.PromiseHolder?*/ let holder = $.$as(promise.AsyncState, $.$srij.System.Runtime.InteropServices.JavaScript.JSHostImplementation.$.$srij.System.Runtime.InteropServices.JavaScript.JSHostImplementation.PromiseHolder);
                if (holder === null)
                {
                    throw new $.$spc.System.InvalidOperationException().$ctor$10("Expected Task converted from JS Promise");
                }
                if (holder.IsDisposed)
                {
                    return;
                }
                $.$srij.Interop.Runtime.CancelPromise(holder.GCHandle);
            }
            static $h = 250092;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"m":[{"r":65537,"p":[{"n":"promise","p":133300225}],"n":"CancelPromise","d":250092,"h":4295217388,"f":33}],"h":250092}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.Runtime.InteropServices.JavaScript.CancelablePromise`; }
        });
        
        $asm.$cls("$srij.System.Runtime.InteropServices.JavaScript.JSFunctionBinding", ($self) => class JSFunctionBinding extends $.$spc.System.Object
        {
            $ctor$1()
            {
                super.$ctor();
                {
                }
                return this;
            }
            /*JSBindingHeader**/ Header;
            /*JSBindingType**/ Sigs;
            /*uint*/ static nextImportHandle = 1;
            /*int*/ ImportHandle = 0;
            /*bool*/ IsAsync = false;
            /*bool*/ IsDiscardNoWait = false;
            /*string?*/ FunctionName = null;
            static $_JSBindingHeader;
            static get JSBindingHeader()
            {
                let $cls = $.$srij.System.Runtime.InteropServices.JavaScript.JSFunctionBinding;
                return $cls.$_JSBindingHeader ??= $asm.$nstr("$srij.System.Runtime.InteropServices.JavaScript.JSFunctionBinding.JSBindingHeader", ($self) => class JSBindingHeader extends $.$spc.System.ValueType
                {
                    /*int*/ static JSMarshalerSignatureHeaderSize = 32;
                    /*int*/  get Version() { return this.$getField(0, $.$spc.System.Int32); }
                    /*int*/  set Version(value) { this.$setField(0, $.$spc.System.Int32, value); }
                    /*int*/  get ArgumentCount() { return this.$getField(4, $.$spc.System.Int32); }
                    /*int*/  set ArgumentCount(value) { this.$setField(4, $.$spc.System.Int32, value); }
                    /*int*/  get ImportHandle() { return this.$getField(8, $.$spc.System.Int32); }
                    /*int*/  set ImportHandle(value) { this.$setField(8, $.$spc.System.Int32, value); }
                    /*int*/  get FunctionNameOffset() { return this.$getField(16, $.$spc.System.Int32); }
                    /*int*/  set FunctionNameOffset(value) { this.$setField(16, $.$spc.System.Int32, value); }
                    /*int*/  get FunctionNameLength() { return this.$getField(20, $.$spc.System.Int32); }
                    /*int*/  set FunctionNameLength(value) { this.$setField(20, $.$spc.System.Int32, value); }
                    /*int*/  get ModuleNameOffset() { return this.$getField(24, $.$spc.System.Int32); }
                    /*int*/  set ModuleNameOffset(value) { this.$setField(24, $.$spc.System.Int32, value); }
                    /*int*/  get ModuleNameLength() { return this.$getField(28, $.$spc.System.Int32); }
                    /*int*/  set ModuleNameLength(value) { this.$setField(28, $.$spc.System.Int32, value); }
                    /*JSBindingType*/  get Exception() { return this.$getField(32, $.$srij.System.Runtime.InteropServices.JavaScript.JSFunctionBinding.JSBindingType); }
                    /*JSBindingType*/  set Exception(value) { this.$setField(32, $.$srij.System.Runtime.InteropServices.JavaScript.JSFunctionBinding.JSBindingType, value); }
                    /*JSBindingType*/  get Result() { return this.$getField(64, $.$srij.System.Runtime.InteropServices.JavaScript.JSFunctionBinding.JSBindingType); }
                    /*JSBindingType*/  set Result(value) { this.$setField(64, $.$srij.System.Runtime.InteropServices.JavaScript.JSFunctionBinding.JSBindingType, value); }
                    //default value type constructor
                    $ctor$2()
                    {
                        return this;
                    }
                    Clone($copy)
                    {
                        let copy = $copy ?? new this.constructor();
                        copy.Version = this.Version;
                        copy.ArgumentCount = this.ArgumentCount;
                        copy.ImportHandle = this.ImportHandle;
                        copy.FunctionNameOffset = this.FunctionNameOffset;
                        copy.FunctionNameLength = this.FunctionNameLength;
                        copy.ModuleNameOffset = this.ModuleNameOffset;
                        copy.ModuleNameLength = this.ModuleNameLength;
                        copy.Exception = this.Exception.Clone();
                        copy.Result = this.Result.Clone();
                        return copy;
                    }
                    //default member initializer
                    constructor()
                    {
                        super();
                        this.Version = 0;
                        this.ArgumentCount = 0;
                        this.ImportHandle = 0;
                        this.FunctionNameOffset = 0;
                        this.FunctionNameLength = 0;
                        this.ModuleNameOffset = 0;
                        this.ModuleNameLength = 0;
                        this.Exception = $.$default($.$srij.System.Runtime.InteropServices.JavaScript.JSFunctionBinding.JSBindingType);
                        this.Result = $.$default($.$srij.System.Runtime.InteropServices.JavaScript.JSFunctionBinding.JSBindingType);
                    }
                    //Static Initializer
                    static $sinit()
                    {
                        {
                            this.JSMarshalerSignatureHeaderSize = 32;
                        }
                    }
                    static $h = 643308;
                    static $z = 96;
                    static $f = 0b10100010000001010000000;
                    static $k = 2;
                    static $$md;
                    static get $md() { return this.$$md ??= {"b":196609,"l":[{"t":655361,"n":"JSMarshalerSignatureHeaderSize","d":643308,"h":4295610604,"f":40},{"t":655361,"n":"Version","d":643308,"h":8590577900,"f":1,"a":[{"t":104071169,"c":4399038465,"a":[{"v":0,"t":655361}]}]},{"t":655361,"n":"ArgumentCount","d":643308,"h":12885545196,"f":1,"a":[{"t":104071169,"c":4399038465,"a":[{"v":4,"t":655361}]}]},{"t":655361,"n":"ImportHandle","d":643308,"h":17180512492,"f":1,"a":[{"t":104071169,"c":4399038465,"a":[{"v":8,"t":655361}]}]},{"t":655361,"n":"FunctionNameOffset","d":643308,"h":21475479788,"f":1,"a":[{"t":104071169,"c":4399038465,"a":[{"v":16,"t":655361}]}]},{"t":655361,"n":"FunctionNameLength","d":643308,"h":25770447084,"f":1,"a":[{"t":104071169,"c":4399038465,"a":[{"v":20,"t":655361}]}]},{"t":655361,"n":"ModuleNameOffset","d":643308,"h":30065414380,"f":1,"a":[{"t":104071169,"c":4399038465,"a":[{"v":24,"t":655361}]}]},{"t":655361,"n":"ModuleNameLength","d":643308,"h":34360381676,"f":1,"a":[{"t":104071169,"c":4399038465,"a":[{"v":28,"t":655361}]}]},{"t":708844,"n":"Result","d":643308,"h":42950316268,"f":1,"a":[{"t":104071169,"c":4399038465,"a":[{"v":64,"t":655361}]}]}],"c":[{"n":".ctor","o":"$ctor$2","d":643308,"h":47245283564,"f":1}],"d":577772,"h":643308,"a":[{"t":109903873,"c":4404871169,"a":[{"v":2,"t":105381889}],"n":[{"n":"Pack","v":4,"t":655361}]}]}; }
                    static get $b() { return $.$spc.System.ValueType; }
                    static get $fullName() { return `System.Runtime.InteropServices.JavaScript.JSFunctionBinding.JSBindingHeader`; }
                }, $cls, ($v) => $cls.$_JSBindingHeader = $v);
            }
            static $_JSBindingType;
            static get JSBindingType()
            {
                let $cls = $.$srij.System.Runtime.InteropServices.JavaScript.JSFunctionBinding;
                return $cls.$_JSBindingType ??= $asm.$nstr("$srij.System.Runtime.InteropServices.JavaScript.JSFunctionBinding.JSBindingType", ($self) => class JSBindingType extends $.$spc.System.ValueType
                {
                    /*MarshalerType*/  get Type() { return this.$getField(0, $.$srij.System.Runtime.InteropServices.JavaScript.MarshalerType); }
                    /*MarshalerType*/  set Type(value) { this.$setField(0, $.$srij.System.Runtime.InteropServices.JavaScript.MarshalerType, value); }
                    /*MarshalerType*/  get ResultMarshalerType() { return this.$getField(16, $.$srij.System.Runtime.InteropServices.JavaScript.MarshalerType); }
                    /*MarshalerType*/  set ResultMarshalerType(value) { this.$setField(16, $.$srij.System.Runtime.InteropServices.JavaScript.MarshalerType, value); }
                    /*MarshalerType*/  get Arg1MarshalerType() { return this.$getField(20, $.$srij.System.Runtime.InteropServices.JavaScript.MarshalerType); }
                    /*MarshalerType*/  set Arg1MarshalerType(value) { this.$setField(20, $.$srij.System.Runtime.InteropServices.JavaScript.MarshalerType, value); }
                    /*MarshalerType*/  get Arg2MarshalerType() { return this.$getField(24, $.$srij.System.Runtime.InteropServices.JavaScript.MarshalerType); }
                    /*MarshalerType*/  set Arg2MarshalerType(value) { this.$setField(24, $.$srij.System.Runtime.InteropServices.JavaScript.MarshalerType, value); }
                    /*MarshalerType*/  get Arg3MarshalerType() { return this.$getField(28, $.$srij.System.Runtime.InteropServices.JavaScript.MarshalerType); }
                    /*MarshalerType*/  set Arg3MarshalerType(value) { this.$setField(28, $.$srij.System.Runtime.InteropServices.JavaScript.MarshalerType, value); }
                    //default value type constructor
                    $ctor$2()
                    {
                        return this;
                    }
                    Clone($copy)
                    {
                        let copy = $copy ?? new this.constructor();
                        copy.Type = this.Type;
                        copy.ResultMarshalerType = this.ResultMarshalerType;
                        copy.Arg1MarshalerType = this.Arg1MarshalerType;
                        copy.Arg2MarshalerType = this.Arg2MarshalerType;
                        copy.Arg3MarshalerType = this.Arg3MarshalerType;
                        return copy;
                    }
                    //default member initializer
                    constructor()
                    {
                        super();
                        this.Type = 0;
                        this.ResultMarshalerType = 0;
                        this.Arg1MarshalerType = 0;
                        this.Arg2MarshalerType = 0;
                        this.Arg3MarshalerType = 0;
                    }
                    static $h = 708844;
                    static $z = 32;
                    static $f = 0b10100010000001010000000;
                    static $k = 2;
                    static $$md;
                    static get $md() { return this.$$md ??= {"b":196609,"l":[{"t":3723500,"n":"Type","d":708844,"h":4295676140,"f":8,"a":[{"t":104071169,"c":4399038465,"a":[{"v":0,"t":655361}]}]},{"t":3723500,"n":"ResultMarshalerType","d":708844,"h":8590643436,"f":8,"a":[{"t":104071169,"c":4399038465,"a":[{"v":16,"t":655361}]}]},{"t":3723500,"n":"Arg1MarshalerType","d":708844,"h":12885610732,"f":8,"a":[{"t":104071169,"c":4399038465,"a":[{"v":20,"t":655361}]}]},{"t":3723500,"n":"Arg2MarshalerType","d":708844,"h":17180578028,"f":8,"a":[{"t":104071169,"c":4399038465,"a":[{"v":24,"t":655361}]}]},{"t":3723500,"n":"Arg3MarshalerType","d":708844,"h":21475545324,"f":8,"a":[{"t":104071169,"c":4399038465,"a":[{"v":28,"t":655361}]}]}],"c":[{"n":".ctor","o":"$ctor$2","d":708844,"h":25770512620,"f":1}],"d":577772,"h":708844,"a":[{"t":109903873,"c":4404871169,"a":[{"v":2,"t":105381889}],"n":[{"n":"Pack","v":4,"t":655361},{"n":"Size","v":32,"t":655361}]}]}; }
                    static get $b() { return $.$spc.System.ValueType; }
                    static get $fullName() { return `System.Runtime.InteropServices.JavaScript.JSFunctionBinding.JSBindingType`; }
                }, $cls, ($v) => $cls.$_JSBindingType = $v);
            }
            /*int */ get ArgumentCount()
            {
                return this.Header.GetAt(0).ArgumentCount;
            }
            /*int */ set ArgumentCount(value)
            {
                this.Header.GetAt(0).ArgumentCount = value;
            }
            /*int */ get Version()
            {
                return this.Header.GetAt(0).Version;
            }
            /*int */ set Version(value)
            {
                this.Header.GetAt(0).Version = value;
            }
            /*JSBindingType */ get Result()
            {
                return this.Header.GetAt(0).Result;
            }
            /*JSBindingType */ set Result(value)
            {
                this.Header.GetAt(0).Result = value.Clone();
            }
            /*JSBindingType */ get Exception()
            {
                return this.Header.GetAt(0).Exception;
            }
            /*JSBindingType */ set Exception(value)
            {
                this.Header.GetAt(0).Exception = value.Clone();
            }
            /*JSBindingType*/ get_Item(/*int*/ position)
            {
                return this.Sigs.GetAt(((position - 1) | 0));
            }
            static /*void */ InvokeJS(/*JSFunctionBinding*/ signature, /*Span<JSMarshalerArgument>*/ $arguments)
            {
                $.$srij.System.Runtime.InteropServices.JavaScript.JSFunctionBinding.InvokeJSImportImpl(signature, $arguments);
            }
            static /*JSFunctionBinding */ BindJSFunction(/*string*/ functionName, /*string*/ moduleName, /*ReadOnlySpan<JSMarshalerType>*/ signatures)
            {
                if ($.$spc.System.Runtime.InteropServices.RuntimeInformation.OSArchitecture !== 4/*Architecture.Wasm*/)
                {
                    throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
                }
                return $.$srij.System.Runtime.InteropServices.JavaScript.JSFunctionBinding.BindJSImportImpl(functionName, moduleName, signatures);
            }
            static /*JSFunctionBinding */ BindManagedFunction(/*string*/ fullyQualifiedName, /*int*/ signatureHash, /*ReadOnlySpan<JSMarshalerType>*/ signatures)
            {
                if ($.$spc.System.Runtime.InteropServices.RuntimeInformation.OSArchitecture !== 4/*Architecture.Wasm*/)
                {
                    throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
                }
                return $.$srij.System.Runtime.InteropServices.JavaScript.JSHostImplementation.BindManagedFunction(fullyQualifiedName, signatureHash, signatures);
            }
            static /*void */ InvokeJSFunction(/*JSObject*/ jsFunction, /*Span<JSMarshalerArgument>*/ $arguments)
            {
                jsFunction.AssertNotDisposed();
                $.$srij.System.Runtime.InteropServices.JavaScript.JSFunctionBinding.InvokeJSFunctionCurrent(jsFunction, $arguments);
            }
            static /*void */ InvokeJSFunctionCurrent(/*JSObject*/ jsFunction, /*Span<JSMarshalerArgument>*/ $arguments)
            {
                /*var*/ let functionHandle = jsFunction.JSHandle;
                /*fixed*/ 
                {
                    /*JSMarshalerArgument**/ let ptr = $arguments.GetPinnableReference();
                    $.$srij.Interop.Runtime.InvokeJSFunction(functionHandle, $.$cast(ptr, $.$spc.System.IntPtr));
                    /*ref JSMarshalerArgument*/ let exceptionArg = $arguments.get_Item(0);
                    if (exceptionArg.$v.slot.Type !== 0/*MarshalerType.None*/)
                    {
                        $.$srij.System.Runtime.InteropServices.JavaScript.JSHostImplementation.ThrowException(exceptionArg);
                    }
                }
            }
            static /*void */ InvokeJSImportImpl(/*JSFunctionBinding*/ signature, /*Span<JSMarshalerArgument>*/ $arguments)
            {
                /*ref JSMarshalerArgument*/ let exc = $arguments.get_Item(0);
                /*ref JSMarshalerArgument*/ let res = $arguments.get_Item(1);
                /*var*/ let targetContext = $.$srij.System.Runtime.InteropServices.JavaScript.JSProxyContext.MainThreadContext;
                if (signature.IsAsync)
                {
                    /*var*/ let holder = targetContext.CreatePromiseHolder();
                    res.$v.slot.Type = 30/*MarshalerType.TaskPreCreated*/;
                    res.$v.slot.GCHandle = holder.GCHandle;
                }
                if (signature.IsDiscardNoWait)
                {
                    $arguments.get_Item(1).$v.slot.Type = 26/*MarshalerType.DiscardNoWait*/;
                }
                $.$srij.System.Runtime.InteropServices.JavaScript.JSFunctionBinding.InvokeJSImportCurrent(signature, $arguments);
                if (signature.IsAsync)
                {
                    if ($arguments.get_Item(1).$v.slot.Type === 0/*MarshalerType.None*/)
                    {
                        /*var*/ let holderHandle = $.$spc.System.Runtime.InteropServices.GCHandle.op_Explicit($arguments.get_Item(1).$v.slot.GCHandle);
                        holderHandle.Free();
                    }
                }
            }
            static /*void */ InvokeJSImportCurrent(/*JSFunctionBinding*/ signature, /*Span<JSMarshalerArgument>*/ $arguments)
            {
                /*fixed*/ 
                {
                    /*JSMarshalerArgument**/ let args = $arguments.GetPinnableReference();
                    $.$srij.Interop.Runtime.InvokeJSImportST(signature.ImportHandle, $.$cast(args, $.$spc.System.IntPtr));
                }
                /*ref JSMarshalerArgument*/ let exceptionArg = $arguments.get_Item(0);
                if (exceptionArg.$v.slot.Type !== 0/*MarshalerType.None*/)
                {
                    $.$srij.System.Runtime.InteropServices.JavaScript.JSHostImplementation.ThrowException(exceptionArg);
                }
            }
            static /*JSFunctionBinding */ BindJSImportImpl(/*string*/ functionName, /*string*/ moduleName, /*ReadOnlySpan<JSMarshalerType>*/ signatures)
            {
                /*var*/ let signature = $.$srij.System.Runtime.InteropServices.JavaScript.JSHostImplementation.GetMethodSignature(signatures, functionName, moduleName);
                /*nint*/ let exceptionPtr = $.$srij.Interop.Runtime.BindJSImportST(signature.Header);
                if (exceptionPtr !== $.$spc.System.IntPtr.Zero)
                {
                    /*var*/ let message = $.$spc.System.Runtime.InteropServices.Marshal.PtrToStringUni(exceptionPtr);
                    $.$spc.System.Runtime.InteropServices.Marshal.FreeHGlobal(exceptionPtr);
                    throw new $.$srij.System.Runtime.InteropServices.JavaScript.JSException().$ctor$5(message);
                }
                $.$srij.System.Runtime.InteropServices.JavaScript.JSHostImplementation.FreeMethodSignatureBuffer(signature);
                return signature;
            }
            static /*void */ ResolveOrRejectPromise(/*JSProxyContext*/ targetContext, /*Span<JSMarshalerArgument>*/ $arguments)
            {
                /*ref JSMarshalerArgument*/ let exc = $arguments.get_Item(0);
                {
                    /*fixed*/ 
                    {
                        /*JSMarshalerArgument**/ let ptr = $arguments.GetPinnableReference();
                        $.$srij.Interop.Runtime.ResolveOrRejectPromise($.$cast(ptr, $.$spc.System.IntPtr));
                        if (exc.$v.slot.Type !== 0/*MarshalerType.None*/)
                        {
                            $.$srij.System.Runtime.InteropServices.JavaScript.JSHostImplementation.ThrowException(exc);
                        }
                    }
                }
            }
            //default member initializer
            constructor()
            {
                super();
                this.Header = $.$default($.$typePointer($.$srij.System.Runtime.InteropServices.JavaScript.JSFunctionBinding.JSBindingHeader));
                this.Sigs = $.$default($.$typePointer($.$srij.System.Runtime.InteropServices.JavaScript.JSFunctionBinding.JSBindingType));
            }
            static $h = 577772;
            static $f = 0b10010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":655361,"g":{"r":0,"d":0,"h":51540185324,"f":8},"s":{"r":0,"d":0,"h":55835152620,"f":8},"n":"ArgumentCount","d":577772,"h":47245218028,"f":8},{"p":655361,"g":{"r":0,"d":0,"h":64425087212,"f":8},"s":{"r":0,"d":0,"h":68720054508,"f":8},"n":"Version","d":577772,"h":60130119916,"f":8},{"p":708844,"g":{"r":0,"d":0,"h":77309989100,"f":8},"s":{"r":0,"d":0,"h":81604956396,"f":8},"n":"Result","d":577772,"h":73015021804,"f":8},{"p":708844,"i":[{"n":"position","p":655361}],"g":{"r":0,"d":0,"h":103079792876,"f":8},"n":"Item","o":"@$2","d":577772,"h":98784825580,"f":8}],"m":[{"r":65537,"p":[{"n":"signature","p":577772},{"n":"arguments","p":$.$spc.System.Span$$($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument).$h}],"n":"InvokeJS","d":577772,"h":107374760172,"f":33},{"r":577772,"p":[{"n":"functionName","p":1310721},{"n":"moduleName","p":1310721},{"n":"signatures","p":$.$spc.System.ReadOnlySpan$$($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType).$h}],"n":"BindJSFunction","d":577772,"h":111669727468,"f":33},{"r":577772,"p":[{"n":"fullyQualifiedName","p":1310721},{"n":"signatureHash","p":655361},{"n":"signatures","p":$.$spc.System.ReadOnlySpan$$($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType).$h}],"n":"BindManagedFunction","d":577772,"h":115964694764,"f":33},{"r":65537,"p":[{"n":"jsFunction","p":2281708},{"n":"arguments","p":$.$spc.System.Span$$($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument).$h}],"n":"InvokeJSFunction","d":577772,"h":120259662060,"f":40},{"r":65537,"p":[{"n":"jsFunction","p":2281708},{"n":"arguments","p":$.$spc.System.Span$$($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument).$h}],"n":"InvokeJSFunctionCurrent","d":577772,"h":124554629356,"f":40},{"r":65537,"p":[{"n":"signature","p":577772},{"n":"arguments","p":$.$spc.System.Span$$($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument).$h}],"n":"InvokeJSImportImpl","d":577772,"h":128849596652,"f":40},{"r":65537,"p":[{"n":"signature","p":577772},{"n":"arguments","p":$.$spc.System.Span$$($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument).$h}],"n":"InvokeJSImportCurrent","d":577772,"h":133144563948,"f":40},{"r":577772,"p":[{"n":"functionName","p":1310721},{"n":"moduleName","p":1310721},{"n":"signatures","p":$.$spc.System.ReadOnlySpan$$($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType).$h}],"n":"BindJSImportImpl","d":577772,"h":137439531244,"f":40},{"r":65537,"p":[{"n":"targetContext","p":2347244},{"n":"arguments","p":$.$spc.System.Span$$($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument).$h}],"n":"ResolveOrRejectPromise","d":577772,"h":141734498540,"f":40}],"l":[{"t":0,"n":"Header","d":577772,"h":8590512364,"f":8},{"t":0,"n":"Sigs","d":577772,"h":12885479660,"f":8},{"t":720897,"n":"nextImportHandle","d":577772,"h":17180446956,"f":40},{"t":655361,"n":"ImportHandle","d":577772,"h":21475414252,"f":8},{"t":262145,"n":"IsAsync","d":577772,"h":25770381548,"f":8},{"t":262145,"n":"IsDiscardNoWait","d":577772,"h":30065348844,"f":8},{"t":1310721,"n":"FunctionName","d":577772,"h":34360316140,"f":8}],"c":[{"n":".ctor","o":"$ctor$1","d":577772,"h":4295545068,"f":8}],"j":[643308,708844],"h":577772,"a":[{"t":23461889,"c":8613396481,"a":[{"v":false,"t":262145}]},{"t":114950145,"c":4409917441,"a":[{"v":"browser","t":1310721}]},{"t":33226753,"c":4328194049,"a":[{"v":1,"t":33292289}]}]}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.Runtime.InteropServices.JavaScript.JSFunctionBinding`; }
        });
        
        $asm.$cls("$srij.System.Runtime.InteropServices.JavaScript.JSHost", ($self) => class JSHost
        {
            static /*JSObject */ get GlobalThis()
            {
                return INTERNAL.get_global_this();
            }
            static /*JSObject */ get DotnetInstance()
            {
                return INTERNAL.get_dotnet_instance();
            }
            static /*Task<JSObject> */ ImportAsync(/*string*/ moduleName, /*string*/ moduleUrl, /*CancellationToken*/ cancellationToken)
            {
                return $.$srij.System.Runtime.InteropServices.JavaScript.JSHostImplementation.ImportAsync(moduleName, moduleUrl, cancellationToken);
            }
            static $h = 774380;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":2281708,"g":{"r":0,"d":0,"h":8590708972,"f":33},"n":"GlobalThis","d":774380,"h":4295741676,"f":33},{"p":2281708,"g":{"r":0,"d":0,"h":17180643564,"f":33},"n":"DotnetInstance","d":774380,"h":12885676268,"f":33}],"m":[{"r":$.$spc.System.Threading.Tasks.Task$$($.$srij.System.Runtime.InteropServices.JavaScript.JSObject).$h,"p":[{"n":"moduleName","p":1310721},{"n":"moduleUrl","p":1310721},{"n":"cancellationToken","p":125960193,"f":65}],"n":"ImportAsync","d":774380,"h":21475610860,"f":33}],"h":774380,"a":[{"t":114950145,"c":4409917441,"a":[{"v":"browser","t":1310721}]}]}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.Runtime.InteropServices.JavaScript.JSHost`; }
        });
        
        $asm.$cls("$srij.System.Runtime.InteropServices.JavaScript.JavaScriptExports", ($self) => class JavaScriptExports
        {
            static /*void */ CallEntrypoint(/*JSMarshalerArgument**/ arguments_buffer)
            {
                /*ref JSMarshalerArgument*/ let arg_exc = arguments_buffer.Add(0);
                /*ref JSMarshalerArgument*/ let arg_res = arguments_buffer.Add(1);
                /*ref JSMarshalerArgument*/ let arg_1 = arguments_buffer.Add(2);
                /*ref JSMarshalerArgument*/ let arg_2 = arguments_buffer.Add(3);
                /*ref JSMarshalerArgument*/ let arg_3 = arguments_buffer.Add(4);
                try
                {
                    /*IntPtr*/ let assemblyNamePtr;
                    arg_1.$v.ToManaged$24($.$ref(() => assemblyNamePtr, ($v) => assemblyNamePtr = $v, $.$spc.System.IntPtr));
                    /*string?[]?*/ let args;
                    arg_2.$v.ToManaged$30($.$ref(() => args, ($v) => args = $v, $.$typeArray($.$spc.System.String)));
                    /*bool*/ let waitForDebugger;
                    arg_3.$v.ToManaged$17($.$ref(() => waitForDebugger, ($v) => waitForDebugger = $v, $.$spc.System.Boolean));
                    /*Task<int>?*/ let result = $.$srij.System.Runtime.InteropServices.JavaScript.JSHostImplementation.CallEntrypoint(assemblyNamePtr, args, waitForDebugger);
                    arg_res.$v.ToJS$46($.$spc.System.Int32, result, new ($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument.ArgumentToJSCallback$$($.$spc.System.Int32))().$ctor(this,  (/*JSMarshalerArgument*/ arg, /*int*/ value) =>
                    {
                        arg.$v.ToJS$31(value);
                    }, {"r":65537,"p":[{"n":"arg","p":1364204,"f":4},{"n":"value","p":655361}],"n":"","d":315628,"h":0,"f":1048578}));
                }
                catch(ex)
                {
                    $.$spc.System.Environment.FailFast(`CallEntrypoint: Unexpected synchronous failure (ManagedThreadId ${$.$spc.System.Environment.CurrentManagedThreadId}): ` + $.$spc.System.Exception.ToString.call(ex));
                }
            }
            static /*void */ LoadLazyAssembly(/*JSMarshalerArgument**/ arguments_buffer)
            {
                /*ref JSMarshalerArgument*/ let arg_exc = arguments_buffer.Add(0);
                /*ref JSMarshalerArgument*/ let arg_1 = arguments_buffer.Add(2);
                /*ref JSMarshalerArgument*/ let arg_2 = arguments_buffer.Add(3);
                try
                {
                    /*byte[]?*/ let dllBytes;
                    arg_1.$v.ToManaged$21($.$ref(() => dllBytes, ($v) => dllBytes = $v, $.$typeArray($.$spc.System.Byte)));
                    /*byte[]?*/ let pdbBytes;
                    arg_2.$v.ToManaged$21($.$ref(() => pdbBytes, ($v) => pdbBytes = $v, $.$typeArray($.$spc.System.Byte)));
                    if (dllBytes !== null)
                    {
                        $.$srij.System.Runtime.InteropServices.JavaScript.JSHostImplementation.LoadLazyAssembly(dllBytes, pdbBytes);
                    }
                }
                catch(ex)
                {
                    arg_exc.$v.ToJS$36(ex);
                }
            }
            static /*void */ LoadSatelliteAssembly(/*JSMarshalerArgument**/ arguments_buffer)
            {
                /*ref JSMarshalerArgument*/ let arg_exc = arguments_buffer.Add(0);
                /*ref JSMarshalerArgument*/ let arg_1 = arguments_buffer.Add(2);
                try
                {
                    /*byte[]?*/ let dllBytes;
                    arg_1.$v.ToManaged$21($.$ref(() => dllBytes, ($v) => dllBytes = $v, $.$typeArray($.$spc.System.Byte)));
                    if (dllBytes !== null)
                    {
                        $.$srij.System.Runtime.InteropServices.JavaScript.JSHostImplementation.LoadSatelliteAssembly(dllBytes);
                    }
                }
                catch(ex)
                {
                    arg_exc.$v.ToJS$36(ex);
                }
            }
            static /*void */ ReleaseJSOwnedObjectByGCHandle(/*JSMarshalerArgument**/ arguments_buffer)
            {
                /*ref JSMarshalerArgument*/ let arg_exc = arguments_buffer.Add(0);
                /*ref JSMarshalerArgument*/ let arg_1 = arguments_buffer.Add(2);
                try
                {
                    /*var*/ let ctx = arg_exc.$v.ToManagedContext;
                    ctx.ReleaseJSOwnedObjectByGCHandle(arg_1.$v.slot.GCHandle);
                }
                catch(ex)
                {
                    $.$spc.System.Environment.FailFast(`ReleaseJSOwnedObjectByGCHandle: Unexpected synchronous failure (ManagedThreadId ${$.$spc.System.Environment.CurrentManagedThreadId}): ` + $.$spc.System.Exception.ToString.call(ex));
                }
            }
            static /*void */ CallDelegate(/*JSMarshalerArgument**/ arguments_buffer)
            {
                /*ref JSMarshalerArgument*/ let arg_exc = arguments_buffer.Add(0);
                /*ref JSMarshalerArgument*/ let arg_1 = arguments_buffer.Add(2);
                try
                {
                    /*GCHandle*/ let callback_gc_handle = $.$spc.System.Runtime.InteropServices.GCHandle.op_Explicit(arg_1.$v.slot.GCHandle);
                    let callback;
                    if ($.$is(callback_gc_handle.Target, $.$srij.System.Runtime.InteropServices.JavaScript.JSHostImplementation.ToManagedCallback, { set $v(v){ callback = v; } }))
                    {
                        callback.Invoke(arguments_buffer);
                    }
                    else 
                    {
                        throw new $.$spc.System.InvalidOperationException().$ctor$10($.$srij.System.SR.NullToManagedCallback);
                    }
                }
                catch(ex)
                {
                    arg_exc.$v.ToJS$36(ex);
                }
            }
            static /*void */ CompleteTask(/*JSMarshalerArgument**/ arguments_buffer)
            {
                /*ref JSMarshalerArgument*/ let arg_exc = arguments_buffer.Add(0);
                /*ref JSMarshalerArgument*/ let arg_res = arguments_buffer.Add(1);
                /*ref JSMarshalerArgument*/ let arg_1 = arguments_buffer.Add(2);
                try
                {
                    /*var*/ let ctx = arg_exc.$v.ToManagedContext;
                    /*var*/ let holder = ctx.GetPromiseHolder(arg_1.$v.slot.GCHandle);
                    /*JSHostImplementation.ToManagedCallback*/ let callback;
                    callback = holder.Callback;
                    ctx.ReleasePromiseHolder(arg_1.$v.slot.GCHandle);
                    callback.Invoke(arguments_buffer);
                }
                catch(ex)
                {
                    $.$spc.System.Environment.FailFast(`CompleteTask: Unexpected synchronous failure (ManagedThreadId ${$.$spc.System.Environment.CurrentManagedThreadId}): ` + $.$spc.System.Exception.ToString.call(ex));
                }
            }
            static /*void */ GetManagedStackTrace(/*JSMarshalerArgument**/ arguments_buffer)
            {
                /*ref JSMarshalerArgument*/ let arg_exc = arguments_buffer.Add(0);
                /*ref JSMarshalerArgument*/ let arg_res = arguments_buffer.Add(1);
                /*ref JSMarshalerArgument*/ let arg_1 = arguments_buffer.Add(2);
                try
                {
                    arg_exc.$v.AssertCurrentThreadContext();
                    /*GCHandle*/ let exception_gc_handle = $.$spc.System.Runtime.InteropServices.GCHandle.op_Explicit(arg_1.$v.slot.GCHandle);
                    let exception;
                    if ($.$is(exception_gc_handle.Target, $.$spc.System.Exception, { set $v(v){ exception = v; } }))
                    {
                        arg_res.$v.ToJS$29(exception.StackTrace);
                    }
                    else 
                    {
                        throw new $.$spc.System.InvalidOperationException().$ctor$10($.$srij.System.SR.UnableToResolveHandleAsException);
                    }
                }
                catch(ex)
                {
                    arg_exc.$v.ToJS$36(ex);
                }
            }
            static /*void */ BindAssemblyExports(/*JSMarshalerArgument**/ arguments_buffer)
            {
                /*ref JSMarshalerArgument*/ let arg_exc = arguments_buffer.Add(0);
                /*ref JSMarshalerArgument*/ let arg_res = arguments_buffer.Add(1);
                /*ref JSMarshalerArgument*/ let arg_1 = arguments_buffer.Add(2);
                try
                {
                    /*string?*/ let assemblyName;
                    arg_exc.$v.AssertCurrentThreadContext();
                    arg_1.$v.ToManaged$29($.$ref(() => assemblyName, ($v) => assemblyName = $v, $.$spc.System.String));
                    /*var*/ let result = $.$srij.System.Runtime.InteropServices.JavaScript.JSHostImplementation.BindAssemblyExports(assemblyName);
                    arg_res.$v.ToJS$45(result);
                }
                catch(ex)
                {
                    $.$spc.System.Environment.FailFast(`BindAssemblyExports: Unexpected synchronous failure (ManagedThreadId ${$.$spc.System.Environment.CurrentManagedThreadId}): ` + $.$spc.System.Exception.ToString.call(ex));
                }
            }
            static /*void */ StopProfile()
            {
            }
            static /*void */ DumpAotProfileData(/*ref byte*/ buf, /*int*/ len, /*string*/ extraArg)
            {
                if (len === 0)
                {
                    throw new $.$spc.System.InvalidOperationException().$ctor$10($.$srij.System.SR.EmptyProfileData);
                }
                /*fixed*/ 
                {
                    /*void**/ let p = buf;
                    /*var*/ let span = new ($.$spc.System.ReadOnlySpan$$($.$spc.System.Byte))().$ctor$4(p, len);
                    /*var*/ let module = $.$srij.System.Runtime.InteropServices.JavaScript.JSHost.DotnetInstance.GetPropertyAsJSObject("INTERNAL");
                    if (module === null)
                    {
                        throw new $.$spc.System.InvalidOperationException().$ctor$9();
                    }
                    module.SetProperty$5("aotProfileData", span.ToArray());
                }
            }
            static $h = 315628;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"m":[{"r":65537,"p":[{"n":"arguments_buffer","p":0}],"n":"CallEntrypoint","d":315628,"h":4295282924,"f":33},{"r":65537,"p":[{"n":"arguments_buffer","p":0}],"n":"LoadLazyAssembly","d":315628,"h":8590250220,"f":33},{"r":65537,"p":[{"n":"arguments_buffer","p":0}],"n":"LoadSatelliteAssembly","d":315628,"h":12885217516,"f":33},{"r":65537,"p":[{"n":"arguments_buffer","p":0}],"n":"ReleaseJSOwnedObjectByGCHandle","d":315628,"h":17180184812,"f":33},{"r":65537,"p":[{"n":"arguments_buffer","p":0}],"n":"CallDelegate","d":315628,"h":21475152108,"f":33},{"r":65537,"p":[{"n":"arguments_buffer","p":0}],"n":"CompleteTask","d":315628,"h":25770119404,"f":33},{"r":65537,"p":[{"n":"arguments_buffer","p":0}],"n":"GetManagedStackTrace","d":315628,"h":30065086700,"f":33},{"r":65537,"p":[{"n":"arguments_buffer","p":0}],"n":"BindAssemblyExports","d":315628,"h":34360053996,"f":33},{"r":65537,"n":"StopProfile","d":315628,"h":38655021292,"f":33},{"r":65537,"p":[{"n":"buf","p":393217,"f":4},{"n":"len","p":655361},{"n":"extraArg","p":1310721}],"n":"DumpAotProfileData","d":315628,"h":42949988588,"f":33}],"h":315628}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.Runtime.InteropServices.JavaScript.JavaScriptExports`; }
        });
        
        $asm.$cls("$srij.System.Runtime.InteropServices.JavaScript.JSObject", ($self) => class JSObject extends $.$spc.System.Object
        {
            /*bool */ get IsDisposed()
            {
                return this._isDisposed;
            }
            /*bool */ HasProperty(/*string*/ propertyName)
            {
                this.AssertNotDisposed();
                return INTERNAL.has_property(this, propertyName);
            }
            /*string */ GetTypeOfProperty(/*string*/ propertyName)
            {
                this.AssertNotDisposed();
                return INTERNAL.get_typeof_property(this, propertyName);
            }
            /*bool */ GetPropertyAsBoolean(/*string*/ propertyName)
            {
                this.AssertNotDisposed();
                return INTERNAL.get_property(this, propertyName);
            }
            /*int */ GetPropertyAsInt32(/*string*/ propertyName)
            {
                this.AssertNotDisposed();
                return INTERNAL.get_property(this, propertyName);
            }
            /*double */ GetPropertyAsDouble(/*string*/ propertyName)
            {
                this.AssertNotDisposed();
                return INTERNAL.get_property(this, propertyName);
            }
            /*string? */ GetPropertyAsString(/*string*/ propertyName)
            {
                this.AssertNotDisposed();
                return INTERNAL.get_property(this, propertyName);
            }
            /*JSObject? */ GetPropertyAsJSObject(/*string*/ propertyName)
            {
                this.AssertNotDisposed();
                return INTERNAL.get_property(this, propertyName);
            }
            /*byte[]? */ GetPropertyAsByteArray(/*string*/ propertyName)
            {
                this.AssertNotDisposed();
                return INTERNAL.get_property(this, propertyName);
            }
            /*void */ SetProperty(/*string*/ propertyName, /*bool*/ value)
            {
                this.AssertNotDisposed();
                INTERNAL.set_property(this, propertyName, value);
            }
            /*void */ SetProperty$1(/*string*/ propertyName, /*int*/ value)
            {
                this.AssertNotDisposed();
                INTERNAL.set_property(this, propertyName, value);
            }
            /*void */ SetProperty$2(/*string*/ propertyName, /*double*/ value)
            {
                this.AssertNotDisposed();
                INTERNAL.set_property(this, propertyName, value);
            }
            /*void */ SetProperty$3(/*string*/ propertyName, /*string?*/ value)
            {
                this.AssertNotDisposed();
                INTERNAL.set_property(this, propertyName, value);
            }
            /*void */ SetProperty$4(/*string*/ propertyName, /*JSObject?*/ value)
            {
                this.AssertNotDisposed();
                INTERNAL.set_property(this, propertyName, value);
            }
            /*void */ SetProperty$5(/*string*/ propertyName, /*byte[]?*/ value)
            {
                this.AssertNotDisposed();
                INTERNAL.set_property(this, propertyName, value);
            }
            /*nint*/ JSHandle = 0;
            /*JSProxyContext*/ ProxyContext = null;
            /*SynchronizationContext */ get SynchronizationContext()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool*/ _isDisposed = false;
            $ctor$1(/*IntPtr*/ jsHandle, /*JSProxyContext*/ ctx)
            {
                super.$ctor();
                {
                    this.ProxyContext = ctx;
                    this.JSHandle = jsHandle;
                }
                return this;
            }
            static/*conventional*/ /*bool */ Equals(/*object?*/ obj)
            {
                let other;
                return $.$is(obj, $.$srij.System.Runtime.InteropServices.JavaScript.JSObject, { set $v(v){ other = v; } }) && this.JSHandle === other.JSHandle;
            }
            //Static convention instance redirect
            /*bool */ Equals() { return $.$srij.System.Runtime.InteropServices.JavaScript.JSObject.Equals.apply(this, arguments); }
            static/*conventional*/ /*int */ GetHashCode()
            {
                return this.JSHandle;
            }
            //Static convention instance redirect
            /*int */ GetHashCode() { return $.$srij.System.Runtime.InteropServices.JavaScript.JSObject.GetHashCode.apply(this, arguments); }
            static/*conventional*/ /*string */ ToString()
            {
                return `(js-obj js '${this.JSHandle}')`;
            }
            //Static convention instance redirect
            /*string */ ToString() { return $.$srij.System.Runtime.InteropServices.JavaScript.JSObject.ToString.apply(this, arguments); }
            /*void */ AssertNotDisposed()
            {
                {
                    $.$spc.System.ObjectDisposedException.ThrowIf(this.IsDisposed, this);
                }
            }
            /*void */ DisposeImpl(/*bool*/ skipJsCleanup)
            {
                if (!this._isDisposed)
                {
                    $.$srij.System.Runtime.InteropServices.JavaScript.JSProxyContext.ReleaseCSOwnedObject(this, skipJsCleanup);
                }
            }
            $dtor()
            {
                this.DisposeImpl(false);
            }
            /*void */ Dispose()
            {
                this.DisposeImpl(false);
            }
            //Generated interface implemetation for System.IDisposable.Dispose()
            System$IDisposable$Dispose()
            {
                return this.Dispose(...arguments);
            }
            //default member initializer
            constructor()
            {
                super();
                $.$finalizer(this);
            }
            static $h = 2281708;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":262145,"g":{"r":0,"d":0,"h":8592216300,"f":1},"n":"IsDisposed","d":2281708,"h":4297249004,"f":1},{"p":131137537,"g":{"r":0,"d":0,"h":85901627628,"f":1},"n":"SynchronizationContext","d":2281708,"h":81606660332,"f":1}],"m":[{"r":262145,"p":[{"n":"propertyName","p":1310721}],"n":"HasProperty","d":2281708,"h":12887183596,"f":1},{"r":1310721,"p":[{"n":"propertyName","p":1310721}],"n":"GetTypeOfProperty","d":2281708,"h":17182150892,"f":1},{"r":262145,"p":[{"n":"propertyName","p":1310721}],"n":"GetPropertyAsBoolean","d":2281708,"h":21477118188,"f":1},{"r":655361,"p":[{"n":"propertyName","p":1310721}],"n":"GetPropertyAsInt32","d":2281708,"h":25772085484,"f":1},{"r":1179649,"p":[{"n":"propertyName","p":1310721}],"n":"GetPropertyAsDouble","d":2281708,"h":30067052780,"f":1},{"r":1310721,"p":[{"n":"propertyName","p":1310721}],"n":"GetPropertyAsString","d":2281708,"h":34362020076,"f":1},{"r":2281708,"p":[{"n":"propertyName","p":1310721}],"n":"GetPropertyAsJSObject","d":2281708,"h":38656987372,"f":1},{"r":0,"p":[{"n":"propertyName","p":1310721}],"n":"GetPropertyAsByteArray","d":2281708,"h":42951954668,"f":1},{"r":65537,"p":[{"n":"propertyName","p":1310721},{"n":"value","p":262145}],"n":"SetProperty","d":2281708,"h":47246921964,"f":1},{"r":65537,"p":[{"n":"propertyName","p":1310721},{"n":"value","p":655361}],"n":"SetProperty","o":"@$1","d":2281708,"h":51541889260,"f":1},{"r":65537,"p":[{"n":"propertyName","p":1310721},{"n":"value","p":1179649}],"n":"SetProperty","o":"@$2","d":2281708,"h":55836856556,"f":1},{"r":65537,"p":[{"n":"propertyName","p":1310721},{"n":"value","p":1310721}],"n":"SetProperty","o":"@$3","d":2281708,"h":60131823852,"f":1},{"r":65537,"p":[{"n":"propertyName","p":1310721},{"n":"value","p":2281708}],"n":"SetProperty","o":"@$4","d":2281708,"h":64426791148,"f":1},{"r":65537,"p":[{"n":"propertyName","p":1310721},{"n":"value","p":0}],"n":"SetProperty","o":"@$5","d":2281708,"h":68721758444,"f":1},{"r":262145,"p":[{"n":"obj","p":131073}],"n":"Equals","d":2281708,"h":98786529516,"f":32769},{"r":655361,"n":"GetHashCode","d":2281708,"h":103081496812,"f":32769},{"r":1310721,"n":"ToString","d":2281708,"h":107376464108,"f":32769},{"r":65537,"n":"AssertNotDisposed","d":2281708,"h":111671431404,"f":8},{"r":65537,"p":[{"n":"skipJsCleanup","p":262145,"f":65,"v":false}],"n":"DisposeImpl","d":2281708,"h":115966398700,"f":8},{"r":65537,"n":"Dispose","d":2281708,"h":124556333292,"f":1}],"l":[{"t":786433,"n":"JSHandle","d":2281708,"h":73016725740,"f":8},{"t":2347244,"n":"ProxyContext","d":2281708,"h":77311693036,"f":8},{"t":262145,"n":"_isDisposed","d":2281708,"h":90196594924,"f":8}],"c":[{"p":[{"n":"jsHandle","p":786433},{"n":"ctx","p":2347244}],"n":".ctor","o":"$ctor$1","d":2281708,"h":94491562220,"f":8}],"i":[57540609],"h":2281708,"a":[{"t":114950145,"c":4409917441,"a":[{"v":"browser","t":1310721}]}]}; }
            static get $b() { return $.$spc.System.Object; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IDisposable ]; }
            static get $fullName() { return `System.Runtime.InteropServices.JavaScript.JSObject`; }
        });
        
        $asm.$cls("$srij.System.Runtime.InteropServices.JavaScript.JSProxyContext", ($self) => class JSProxyContext extends $.$spc.System.Object
        {
            /*bool*/ _isDisposed = false;
            /*Dictionary<nint, WeakReference<JSObject>>*/ ThreadCsOwnedObjects = null;
            /*Dictionary<object, nint>*/ ThreadJsOwnedObjects = null;
            /*Dictionary<nint, PromiseHolder>*/ ThreadJsOwnedHolders = null;
            /*nint*/ NextJSVHandle = -2;
            /*List<nint>*/ JSVHandleFreeList = null;
            $ctor$1()
            {
                super.$ctor();
                {
                }
                return this;
            }
            /*bool */ IsCurrentThread()
            {
                return true;
            }
            /*JSProxyContext*/ static MainThreadContext = null;
            static /*JSProxyContext */ get CurrentThreadContext()
            {
                return $.$srij.System.Runtime.InteropServices.JavaScript.JSProxyContext.MainThreadContext;
            }
            static /*JSProxyContext */ get CurrentOperationContext()
            {
                return $.$srij.System.Runtime.InteropServices.JavaScript.JSProxyContext.MainThreadContext;
            }
            static /*JSProxyContext */ PushOperationWithCurrentThreadContext()
            {
                return $.$srij.System.Runtime.InteropServices.JavaScript.JSProxyContext.MainThreadContext;
            }
            static /*JSProxyContext */ AssertIsInteropThread()
            {
                return $.$srij.System.Runtime.InteropServices.JavaScript.JSProxyContext.MainThreadContext;
            }
            static /*bool */ IsJSVHandle(/*nint*/ jsHandle)
            {
                return jsHandle < -1;
            }
            static /*bool */ IsGCVHandle(/*nint*/ gcHandle)
            {
                return gcHandle < -1;
            }
            /*nint */ AllocJSVHandle()
            {
                {
                    $.$spc.System.ObjectDisposedException.ThrowIf(this._isDisposed, this);
                    if (this.JSVHandleFreeList.Count > 0)
                    {
                        /*var*/ let jsvHandle = this.JSVHandleFreeList.get_Item(((this.JSVHandleFreeList.Count - 1) | 0));
                        this.JSVHandleFreeList.RemoveAt(((this.JSVHandleFreeList.Count - 1) | 0));
                        return jsvHandle;
                    }
                    return this.NextJSVHandle--;
                }
            }
            /*void */ FreeJSVHandle(/*nint*/ jsvHandle)
            {
                {
                    this.JSVHandleFreeList.Add(jsvHandle);
                }
            }
            /*IntPtr */ GetJSOwnedObjectGCHandle(/*object*/ obj, /*GCHandleType*/ handleType)
            {
                if (obj === null)
                {
                    return $.$spc.System.IntPtr.Zero;
                }
                {
                    /*IntPtr*/ let gcHandle;
                    if (this.ThreadJsOwnedObjects.TryGetValue(obj, $.$ref(() => gcHandle, ($v) => gcHandle = $v, $.$spc.System.IntPtr)))
                    {
                        return gcHandle;
                    }
                    /*IntPtr*/ let result = $.$spc.System.Runtime.InteropServices.GCHandle.op_Explicit$1($.$spc.System.Runtime.InteropServices.GCHandle.Alloc$1(obj, handleType));
                    this.ThreadJsOwnedObjects.set_Item(obj, result);
                    return result;
                }
            }
            /*PromiseHolder */ CreatePromiseHolder()
            {
                {
                    return new $.$srij.System.Runtime.InteropServices.JavaScript.JSHostImplementation.PromiseHolder().$ctor$1(this);
                }
            }
            /*PromiseHolder */ GetPromiseHolder(/*nint*/ gcHandle)
            {
                {
                    /*PromiseHolder?*/ let holder;
                    if ($.$srij.System.Runtime.InteropServices.JavaScript.JSProxyContext.IsGCVHandle(gcHandle))
                    {
                        if (!this.ThreadJsOwnedHolders.TryGetValue(gcHandle, $.$ref(() => holder, ($v) => holder = $v, $.$srij.System.Runtime.InteropServices.JavaScript.JSHostImplementation.PromiseHolder)))
                        {
                            holder = new $.$srij.System.Runtime.InteropServices.JavaScript.JSHostImplementation.PromiseHolder().$ctor$2(this, gcHandle);
                            this.ThreadJsOwnedHolders.Add(gcHandle, holder);
                        }
                    }
                    else 
                    {
                        holder = $.$cast(($.$spc.System.Runtime.InteropServices.GCHandle.op_Explicit(gcHandle)).Target, $.$srij.System.Runtime.InteropServices.JavaScript.JSHostImplementation.PromiseHolder);
                    }
                    return holder;
                }
            }
            /*void */ ReleasePromiseHolder(/*nint*/ holderGCHandle)
            {
                {
                    /*PromiseHolder?*/ let holder;
                    if ($.$srij.System.Runtime.InteropServices.JavaScript.JSProxyContext.IsGCVHandle(holderGCHandle))
                    {
                        if (!this.ThreadJsOwnedHolders.Remove$1(holderGCHandle, $.$ref(() => holder, ($v) => holder = $v, $.$srij.System.Runtime.InteropServices.JavaScript.JSHostImplementation.PromiseHolder)))
                        {
                            throw new $.$spc.System.InvalidOperationException().$ctor$10("ReleasePromiseHolder expected PromiseHolder " + holderGCHandle);
                        }
                        holder.IsDisposed = true;
                    }
                    else 
                    {
                        /*GCHandle*/ let handle = $.$spc.System.Runtime.InteropServices.GCHandle.op_Explicit(holderGCHandle);
                        /*var*/ let target = handle.Target;
                        let holder2;
                        if ($.$is(target, $.$srij.System.Runtime.InteropServices.JavaScript.JSHostImplementation.PromiseHolder, { set $v(v){ holder2 = v; } }))
                        {
                            holder = holder2;
                        }
                        else 
                        {
                            throw new $.$spc.System.InvalidOperationException().$ctor$10("ReleasePromiseHolder expected PromiseHolder" + holderGCHandle);
                        }
                        holder.IsDisposed = true;
                        handle.Free();
                    }
                }
            }
            /*void */ ReleaseJSOwnedObjectByGCHandle(/*nint*/ gcHandle)
            {
                /*ToManagedCallback?*/ let holderCallback = null;
                {
                    /*PromiseHolder?*/ let holder = null;
                    if ($.$srij.System.Runtime.InteropServices.JavaScript.JSProxyContext.IsGCVHandle(gcHandle))
                    {
                        if (!this.ThreadJsOwnedHolders.Remove$1(gcHandle, $.$ref(() => holder, ($v) => holder = $v, $.$srij.System.Runtime.InteropServices.JavaScript.JSHostImplementation.PromiseHolder)))
                        {
                            throw new $.$spc.System.InvalidOperationException().$ctor$10("ReleaseJSOwnedObjectByGCHandle expected in ThreadJsOwnedHolders");
                        }
                    }
                    else 
                    {
                        /*GCHandle*/ let handle = $.$spc.System.Runtime.InteropServices.GCHandle.op_Explicit(gcHandle);
                        /*var*/ let target = handle.Target;
                        let holder2;
                        if ($.$is(target, $.$srij.System.Runtime.InteropServices.JavaScript.JSHostImplementation.PromiseHolder, { set $v(v){ holder2 = v; } }))
                        {
                            holder = holder2;
                        }
                        else 
                        {
                            if (!this.ThreadJsOwnedObjects.Remove(target))
                            {
                                throw new $.$spc.System.InvalidOperationException().$ctor$10("ReleaseJSOwnedObjectByGCHandle expected in ThreadJsOwnedObjects");
                            }
                        }
                        handle.Free();
                    }
                    if (holder !== null)
                    {
                        holderCallback = holder.Callback;
                        holder.IsDisposed = true;
                    }
                }
                holderCallback?.Invoke(null);
            }
            /*JSObject */ CreateCSOwnedProxy(/*nint*/ jsHandle)
            {
                {
                    /*JSObject?*/ let res;
                    /*WeakReference<JSObject>?*/ let reference;
                    if (!this.ThreadCsOwnedObjects.TryGetValue(jsHandle, $.$ref(() => reference, ($v) => reference = $v, $.$spc.System.WeakReference$$($.$srij.System.Runtime.InteropServices.JavaScript.JSObject))) || !reference.TryGetTarget($.$ref(() => res, ($v) => res = $v, $.$srij.System.Runtime.InteropServices.JavaScript.JSObject)) || res.IsDisposed)
                    {
                        res = new $.$srij.System.Runtime.InteropServices.JavaScript.JSObject().$ctor$1(jsHandle, this);
                        this.ThreadCsOwnedObjects.set_Item(jsHandle, new ($.$spc.System.WeakReference$$($.$srij.System.Runtime.InteropServices.JavaScript.JSObject))().$ctor$2(res, true));
                    }
                    return res;
                }
            }
            static /*void */ ReleaseCSOwnedObject(/*JSObject*/ jso, /*bool*/ skipJS)
            {
                if (jso.IsDisposed)
                {
                    return;
                }
                /*var*/ let ctx = jso.ProxyContext;
                {
                    if (jso.IsDisposed || ctx._isDisposed)
                    {
                        return;
                    }
                    /*var*/ let jsHandle = jso.JSHandle;
                    jso._isDisposed = true;
                    jso.JSHandle = $.$spc.System.IntPtr.Zero;
                    $.$spc.System.GC.SuppressFinalize(jso);
                    if (!ctx.ThreadCsOwnedObjects.Remove(jsHandle))
                    {
                        $.$spc.System.Environment.FailFast(`ReleaseCSOwnedObject expected to find registration for JSHandle: ${jsHandle}, ManagedThreadId: ${$.$spc.System.Environment.CurrentManagedThreadId}. ${$.$spc.System.Environment.NewLine} ${$.$spc.System.Environment.StackTrace}`);
                    }
                    if (!skipJS)
                    {
                        $.$srij.Interop.Runtime.ReleaseCSOwnedObject(jsHandle);
                    }
                    if ($.$srij.System.Runtime.InteropServices.JavaScript.JSProxyContext.IsJSVHandle(jsHandle))
                    {
                        ctx.FreeJSVHandle(jsHandle);
                    }
                }
            }
            /*void */ Dispose(/*bool*/ disposing)
            {
                {
                    if (!this._isDisposed)
                    {
                        /*List<WeakReference<JSObject>>*/ let copy = new ($.$spc.System.Collections.Generic.List$$($.$spc.System.WeakReference$$($.$srij.System.Runtime.InteropServices.JavaScript.JSObject)))().$ctor$3(this.ThreadCsOwnedObjects.Values);
                        var $en4 = copy.GetEnumerator();
                        while ($en4.MoveNext())
                        {
                            var jsObjectWeak = $en4.Current;
                            {
                                /*var*/ let jso;
                                if (jsObjectWeak.TryGetTarget($.$ref(() => jso, ($v) => jso = $v, $.$srij.System.Runtime.InteropServices.JavaScript.JSObject)))
                                {
                                    jso.Dispose();
                                }
                            }
                        }
                        var $en4 = this.ThreadJsOwnedObjects.Values.GetEnumerator();
                        while ($en4.MoveNext())
                        {
                            var gch = $en4.Current;
                            {
                                /*GCHandle*/ let gcHandle = $.$spc.System.Runtime.InteropServices.GCHandle.op_Explicit(gch);
                                gcHandle.Free();
                            }
                        }
                        var $en4 = this.ThreadJsOwnedHolders.Values.GetEnumerator();
                        while ($en4.MoveNext())
                        {
                            var holder = $en4.Current;
                            {
                                {
                                    holder.Callback.Invoke(null);
                                }
                                ($.$spc.System.Runtime.InteropServices.GCHandle.op_Explicit(holder.GCHandle)).Free();
                            }
                        }
                        this.ThreadCsOwnedObjects.Clear();
                        this.ThreadJsOwnedObjects.Clear();
                        this.JSVHandleFreeList.Clear();
                        this.NextJSVHandle = $.$spc.System.IntPtr.Zero;
                        if (disposing)
                        {
                        }
                        this._isDisposed = true;
                    }
                }
            }
            $dtor()
            {
                this.Dispose(false);
            }
            /*void */ Dispose$1()
            {
                this.Dispose(true);
                $.$spc.System.GC.SuppressFinalize(this);
            }
            //Generated interface implemetation for System.IDisposable.Dispose()
            System$IDisposable$Dispose()
            {
                return this.Dispose$1(...arguments);
            }
            //default member initializer
            constructor()
            {
                super();
                this.ThreadCsOwnedObjects = new ($.$spc.System.Collections.Generic.Dictionary$$$($.$spc.System.IntPtr, $.$spc.System.WeakReference$$($.$srij.System.Runtime.InteropServices.JavaScript.JSObject)))().$ctor$1();
                this.ThreadJsOwnedObjects = new ($.$spc.System.Collections.Generic.Dictionary$$$($.$spc.System.Object, $.$spc.System.IntPtr))().$ctor$3($.$spc.System.Collections.Generic.ReferenceEqualityComparer.Instance);
                this.ThreadJsOwnedHolders = new ($.$spc.System.Collections.Generic.Dictionary$$$($.$spc.System.IntPtr, $.$srij.System.Runtime.InteropServices.JavaScript.JSHostImplementation.PromiseHolder))().$ctor$1();
                this.JSVHandleFreeList = new ($.$spc.System.Collections.Generic.List$$($.$spc.System.IntPtr))().$ctor$1();
                $.$finalizer(this);
            }
            //Static Initializer
            static $sinit()
            {
                {
                    this.MainThreadContext = new $.$srij.System.Runtime.InteropServices.JavaScript.JSProxyContext().$ctor$1();
                }
            }
            static $h = 2347244;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":2347244,"g":{"r":0,"d":0,"h":47246987500,"f":33},"n":"CurrentThreadContext","d":2347244,"h":42952020204,"f":33},{"p":2347244,"g":{"r":0,"d":0,"h":55836922092,"f":33},"n":"CurrentOperationContext","d":2347244,"h":51541954796,"f":33}],"m":[{"r":262145,"n":"IsCurrentThread","d":2347244,"h":34362085612,"f":1},{"r":2347244,"n":"PushOperationWithCurrentThreadContext","d":2347244,"h":60131889388,"f":33},{"r":2347244,"n":"AssertIsInteropThread","d":2347244,"h":64426856684,"f":33},{"r":262145,"p":[{"n":"jsHandle","p":786433}],"n":"IsJSVHandle","d":2347244,"h":68721823980,"f":33},{"r":262145,"p":[{"n":"gcHandle","p":786433}],"n":"IsGCVHandle","d":2347244,"h":73016791276,"f":33},{"r":786433,"n":"AllocJSVHandle","d":2347244,"h":77311758572,"f":1},{"r":65537,"p":[{"n":"jsvHandle","p":786433}],"n":"FreeJSVHandle","d":2347244,"h":81606725868,"f":1},{"r":786433,"p":[{"n":"obj","p":131073},{"n":"handleType","p":104333313,"f":65,"v":2}],"n":"GetJSOwnedObjectGCHandle","d":2347244,"h":85901693164,"f":1},{"r":1036524,"n":"CreatePromiseHolder","d":2347244,"h":90196660460,"f":1},{"r":1036524,"p":[{"n":"gcHandle","p":786433}],"n":"GetPromiseHolder","d":2347244,"h":94491627756,"f":1},{"r":65537,"p":[{"n":"holderGCHandle","p":786433}],"n":"ReleasePromiseHolder","d":2347244,"h":98786595052,"f":1},{"r":65537,"p":[{"n":"gcHandle","p":786433}],"n":"ReleaseJSOwnedObjectByGCHandle","d":2347244,"h":103081562348,"f":1},{"r":2281708,"p":[{"n":"jsHandle","p":786433}],"n":"CreateCSOwnedProxy","d":2347244,"h":107376529644,"f":1},{"r":65537,"p":[{"n":"jso","p":2281708},{"n":"skipJS","p":262145}],"n":"ReleaseCSOwnedObject","d":2347244,"h":111671496940,"f":33},{"r":65537,"p":[{"n":"disposing","p":262145}],"n":"Dispose","d":2347244,"h":115966464236,"f":2},{"r":65537,"n":"Dispose","o":"@$1","d":2347244,"h":124556398828,"f":1}],"l":[{"t":262145,"n":"_isDisposed","d":2347244,"h":4297314540,"f":8},{"t":$.$spc.System.Collections.Generic.Dictionary$$$($.$spc.System.IntPtr, $.$spc.System.WeakReference$$($.$srij.System.Runtime.InteropServices.JavaScript.JSObject)).$h,"n":"ThreadCsOwnedObjects","d":2347244,"h":8592281836,"f":2},{"t":$.$spc.System.Collections.Generic.Dictionary$$$($.$spc.System.Object, $.$spc.System.IntPtr).$h,"n":"ThreadJsOwnedObjects","d":2347244,"h":12887249132,"f":2},{"t":$.$spc.System.Collections.Generic.Dictionary$$$($.$spc.System.IntPtr, $.$srij.System.Runtime.InteropServices.JavaScript.JSHostImplementation.PromiseHolder).$h,"n":"ThreadJsOwnedHolders","d":2347244,"h":17182216428,"f":2},{"t":786433,"n":"NextJSVHandle","d":2347244,"h":21477183724,"f":2},{"t":$.$spc.System.Collections.Generic.List$$($.$spc.System.IntPtr).$h,"n":"JSVHandleFreeList","d":2347244,"h":25772151020,"f":2},{"t":2347244,"n":"MainThreadContext","d":2347244,"h":38657052908,"f":33}],"c":[{"n":".ctor","o":"$ctor$1","d":2347244,"h":30067118316,"f":2}],"i":[57540609],"h":2347244}; }
            static get $b() { return $.$spc.System.Object; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IDisposable ]; }
            static get $fullName() { return `System.Runtime.InteropServices.JavaScript.JSProxyContext`; }
        });
        
        $asm.$cls("$srij.System.Runtime.InteropServices.JavaScript.JSMarshalAsAttribute<>", (T) => $asm.$gt("$srij.System.Runtime.InteropServices.JavaScript.JSMarshalAsAttribute<>", [T], ($self) => class JSMarshalAsAttribute$$ extends $.$spc.System.Attribute
        {
            $ctor$2()
            {
                super.$ctor$1();
                {
                }
                return this;
            }
            static $h = 1298668;
            static $g = 1;
            static $f = 0b11010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":14548993,"c":[{"n":".ctor","o":"$ctor$2","d":this.$h,"h":Number(BigInt(this.$h)|0x100000000n),"f":1}],"g":[T?.$h??1507328],"r":1,"h":this.$h,"a":[{"t":14680065,"c":21489516545,"a":[{"v":10240,"t":14614529}],"n":[{"n":"Inherited","v":false,"t":262145},{"n":"AllowMultiple","v":false,"t":262145}]},{"t":114950145,"c":4409917441,"a":[{"v":"browser","t":1310721}]}]}; }
            static get $b() { return $.$spc.System.Attribute; }
            static get $fullName() { return `System.Runtime.InteropServices.JavaScript.JSMarshalAsAttribute<${T?.$fullName}>`; }
        }));
        
        $asm.$str("$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument", ($self) => class JSMarshalerArgument extends $.$spc.System.ValueType
        {
            /*JSMarshalerArgumentImpl*/  get slot() { return this.$getField(0, 32); }
            /*JSMarshalerArgumentImpl*/  set slot(value) { this.$setField(0, 32, value); }
            static $_JSMarshalerArgumentImpl;
            static get JSMarshalerArgumentImpl()
            {
                let $cls = $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument;
                return $cls.$_JSMarshalerArgumentImpl ??= $asm.$nstr("$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument.JSMarshalerArgumentImpl", ($self) => class JSMarshalerArgumentImpl extends $.$spc.System.ValueType
                {
                    /*bool*/  get BooleanValue() { return this.$getField(0, 1); }
                    /*bool*/  set BooleanValue(value) { this.$setField(0, 1, value); }
                    /*byte*/  get ByteValue() { return this.$getField(0, 1); }
                    /*byte*/  set ByteValue(value) { this.$setField(0, 1, value); }
                    /*char*/  get CharValue() { return this.$getField(0, 2); }
                    /*char*/  set CharValue(value) { this.$setField(0, 2, value); }
                    /*short*/  get Int16Value() { return this.$getField(0, 2); }
                    /*short*/  set Int16Value(value) { this.$setField(0, 2, value); }
                    /*int*/  get Int32Value() { return this.$getField(0, 4); }
                    /*int*/  set Int32Value(value) { this.$setField(0, 4, value); }
                    /*long*/  get Int64Value() { return this.$getField(0, 8); }
                    /*long*/  set Int64Value(value) { this.$setField(0, 8, value); }
                    /*float*/  get SingleValue() { return this.$getField(0, 4); }
                    /*float*/  set SingleValue(value) { this.$setField(0, 4, value); }
                    /*double*/  get DoubleValue() { return this.$getField(0, 8); }
                    /*double*/  set DoubleValue(value) { this.$setField(0, 8, value); }
                    /*IntPtr*/  get IntPtrValue() { return this.$getField(0, 4); }
                    /*IntPtr*/  set IntPtrValue(value) { this.$setField(0, 4, value); }
                    /*IntPtr*/  get JSHandle() { return this.$getField(4, 4); }
                    /*IntPtr*/  set JSHandle(value) { this.$setField(4, 4, value); }
                    /*IntPtr*/  get GCHandle() { return this.$getField(4, 4); }
                    /*IntPtr*/  set GCHandle(value) { this.$setField(4, 4, value); }
                    /*int*/  get Length() { return this.$getField(8, 4); }
                    /*int*/  set Length(value) { this.$setField(8, 4, value); }
                    /*MarshalerType*/  get Type() { return this.$getField(12, 1); }
                    /*MarshalerType*/  set Type(value) { this.$setField(12, 1, value); }
                    /*MarshalerType*/  get ElementType() { return this.$getField(13, 1); }
                    /*MarshalerType*/  set ElementType(value) { this.$setField(13, 1, value); }
                    //default value type constructor
                    $ctor$2()
                    {
                        return this;
                    }
                    Clone($copy)
                    {
                        let copy = $copy ?? new this.constructor();
                        copy.BooleanValue = this.BooleanValue;
                        copy.ByteValue = this.ByteValue;
                        copy.CharValue = this.CharValue;
                        copy.Int16Value = this.Int16Value;
                        copy.Int32Value = this.Int32Value;
                        copy.Int64Value = this.Int64Value;
                        copy.SingleValue = this.SingleValue;
                        copy.DoubleValue = this.DoubleValue;
                        copy.IntPtrValue = this.IntPtrValue;
                        copy.JSHandle = this.JSHandle;
                        copy.GCHandle = this.GCHandle;
                        copy.Length = this.Length;
                        copy.Type = this.Type;
                        copy.ElementType = this.ElementType;
                        return copy;
                    }
                    //default member initializer
                    constructor()
                    {
                        super();
                        this.BooleanValue = false;
                        this.ByteValue = 0;
                        this.CharValue = 0;
                        this.Int16Value = 0;
                        this.Int32Value = 0;
                        this.Int64Value = 0n;
                        this.SingleValue = 0;
                        this.DoubleValue = 0;
                        this.IntPtrValue = 0;
                        this.JSHandle = 0;
                        this.GCHandle = 0;
                        this.Length = 0;
                        this.Type = 0;
                        this.ElementType = 0;
                    }
                    static $h = 2150636;
                    static $z = 32;
                    static $f = 0b100010000001010000000;
                    static $k = 2;
                    static $$md;
                    static get $md() { return this.$$md ??= {"b":196609,"l":[{"t":262145,"n":"BooleanValue","d":2150636,"h":4297117932,"f":8,"a":[{"t":104071169,"c":4399038465,"a":[{"v":0,"t":655361}]}]},{"t":393217,"n":"ByteValue","d":2150636,"h":8592085228,"f":8,"a":[{"t":104071169,"c":4399038465,"a":[{"v":0,"t":655361}]}]},{"t":458753,"n":"CharValue","d":2150636,"h":12887052524,"f":8,"a":[{"t":104071169,"c":4399038465,"a":[{"v":0,"t":655361}]}]},{"t":524289,"n":"Int16Value","d":2150636,"h":17182019820,"f":8,"a":[{"t":104071169,"c":4399038465,"a":[{"v":0,"t":655361}]}]},{"t":655361,"n":"Int32Value","d":2150636,"h":21476987116,"f":8,"a":[{"t":104071169,"c":4399038465,"a":[{"v":0,"t":655361}]}]},{"t":917505,"n":"Int64Value","d":2150636,"h":25771954412,"f":8,"a":[{"t":104071169,"c":4399038465,"a":[{"v":0,"t":655361}]}]},{"t":1114113,"n":"SingleValue","d":2150636,"h":30066921708,"f":8,"a":[{"t":104071169,"c":4399038465,"a":[{"v":0,"t":655361}]}]},{"t":1179649,"n":"DoubleValue","d":2150636,"h":34361889004,"f":8,"a":[{"t":104071169,"c":4399038465,"a":[{"v":0,"t":655361}]}]},{"t":786433,"n":"IntPtrValue","d":2150636,"h":38656856300,"f":8,"a":[{"t":104071169,"c":4399038465,"a":[{"v":0,"t":655361}]}]},{"t":786433,"n":"JSHandle","d":2150636,"h":42951823596,"f":8,"a":[{"t":104071169,"c":4399038465,"a":[{"v":4,"t":655361}]}]},{"t":786433,"n":"GCHandle","d":2150636,"h":47246790892,"f":8,"a":[{"t":104071169,"c":4399038465,"a":[{"v":4,"t":655361}]}]},{"t":655361,"n":"Length","d":2150636,"h":51541758188,"f":8,"a":[{"t":104071169,"c":4399038465,"a":[{"v":8,"t":655361}]}]},{"t":3723500,"n":"Type","d":2150636,"h":55836725484,"f":8,"a":[{"t":104071169,"c":4399038465,"a":[{"v":12,"t":655361}]}]},{"t":3723500,"n":"ElementType","d":2150636,"h":60131692780,"f":8,"a":[{"t":104071169,"c":4399038465,"a":[{"v":13,"t":655361}]}]}],"c":[{"n":".ctor","o":"$ctor$2","d":2150636,"h":64426660076,"f":1}],"d":1364204,"h":2150636,"a":[{"t":109903873,"c":4404871169,"a":[{"v":2,"t":105381889}],"n":[{"n":"Pack","v":32,"t":655361},{"n":"Size","v":32,"t":655361}]}]}; }
                    static get $b() { return $.$spc.System.ValueType; }
                    static get $fullName() { return `System.Runtime.InteropServices.JavaScript.JSMarshalerArgument.JSMarshalerArgumentImpl`; }
                }, $cls, ($v) => $cls.$_JSMarshalerArgumentImpl = $v);
            }
            /*void */ Initialize()
            {
                this.slot.Type = 0/*MarshalerType.None*/;
            }
            /*JSProxyContext */ get ToManagedContext()
            {
                return $.$srij.System.Runtime.InteropServices.JavaScript.JSProxyContext.MainThreadContext;
            }
            /*JSProxyContext */ get ToJSContext()
            {
                return $.$srij.System.Runtime.InteropServices.JavaScript.JSProxyContext.MainThreadContext;
            }
            /*JSProxyContext */ AssertCurrentThreadContext()
            {
                return $.$srij.System.Runtime.InteropServices.JavaScript.JSProxyContext.MainThreadContext;
            }
            /*void */ ToManagedBig(/*out long*/ value)
            {
                if (this.slot.Type === 0/*MarshalerType.None*/)
                {
                    value.$v = 0n;
                    return;
                }
                value.$v = this.slot.Int64Value;
            }
            /*void */ ToJSBig(/*long*/ value)
            {
                this.slot.Type = 9/*MarshalerType.BigInt64*/;
                this.slot.Int64Value = value;
            }
            /*void */ ToManagedBig$1(/*out long?*/ value)
            {
                if (this.slot.Type === 0/*MarshalerType.None*/)
                {
                    value.$v = null;
                    return;
                }
                value.$v = this.slot.Int64Value;
            }
            /*void */ ToJSBig$1(/*long?*/ value)
            {
                if ($.$spc.System.Nullable$$($.$spc.System.Int64).HasValue$get.call(value))
                {
                    this.slot.Type = 9/*MarshalerType.BigInt64*/;
                    this.slot.Int64Value = $.$spc.System.Nullable$$($.$spc.System.Int64).Value$get.call(value);
                }
                else 
                {
                    this.slot.Type = 0/*MarshalerType.None*/;
                }
            }
            /*void */ ToManaged(/*out float*/ value)
            {
                if (this.slot.Type === 0/*MarshalerType.None*/)
                {
                    value.$v = 0;
                    return;
                }
                value.$v = this.slot.SingleValue;
            }
            /*void */ ToJS(/*float*/ value)
            {
                this.slot.Type = 11/*MarshalerType.Single*/;
                this.slot.SingleValue = value;
            }
            /*void */ ToManaged$1(/*out float?*/ value)
            {
                if (this.slot.Type === 0/*MarshalerType.None*/)
                {
                    value.$v = null;
                    return;
                }
                value.$v = this.slot.SingleValue;
            }
            /*void */ ToJS$1(/*float?*/ value)
            {
                if ($.$spc.System.Nullable$$($.$spc.System.Single).HasValue$get.call(value))
                {
                    this.slot.Type = 11/*MarshalerType.Single*/;
                    this.slot.SingleValue = $.$spc.System.Nullable$$($.$spc.System.Single).Value$get.call(value);
                }
                else 
                {
                    this.slot.Type = 0/*MarshalerType.None*/;
                }
            }
            /*void */ ToManaged$2(/*out char*/ value)
            {
                if (this.slot.Type === 0/*MarshalerType.None*/)
                {
                    value.$v = 0;
                    return;
                }
                value.$v = this.slot.CharValue;
            }
            /*void */ ToJS$2(/*char*/ value)
            {
                this.slot.Type = 5/*MarshalerType.Char*/;
                this.slot.CharValue = value;
            }
            /*void */ ToManaged$3(/*out char?*/ value)
            {
                if (this.slot.Type === 0/*MarshalerType.None*/)
                {
                    value.$v = null;
                    return;
                }
                value.$v = this.slot.CharValue;
            }
            /*void */ ToJS$3(/*char?*/ value)
            {
                if ($.$spc.System.Nullable$$($.$spc.System.Char).HasValue$get.call(value))
                {
                    this.slot.Type = 5/*MarshalerType.Char*/;
                    this.slot.CharValue = $.$spc.System.Nullable$$($.$spc.System.Char).Value$get.call(value);
                }
                else 
                {
                    this.slot.Type = 0/*MarshalerType.None*/;
                }
            }
            /*void */ ToManaged$4(/*out double*/ value)
            {
                if (this.slot.Type === 0/*MarshalerType.None*/)
                {
                    value.$v = 0;
                    return;
                }
                value.$v = this.slot.DoubleValue;
            }
            /*void */ ToJS$4(/*double*/ value)
            {
                this.slot.Type = 10/*MarshalerType.Double*/;
                this.slot.DoubleValue = value;
            }
            /*void */ ToManaged$5(/*out double?*/ value)
            {
                if (this.slot.Type === 0/*MarshalerType.None*/)
                {
                    value.$v = null;
                    return;
                }
                value.$v = this.slot.DoubleValue;
            }
            /*void */ ToJS$5(/*double?*/ value)
            {
                if ($.$spc.System.Nullable$$($.$spc.System.Double).HasValue$get.call(value))
                {
                    this.slot.Type = 10/*MarshalerType.Double*/;
                    this.slot.DoubleValue = $.$spc.System.Nullable$$($.$spc.System.Double).Value$get.call(value);
                }
                else 
                {
                    this.slot.Type = 0/*MarshalerType.None*/;
                }
            }
            /*void */ ToManaged$6(/*out double[]?*/ value)
            {
                if (this.slot.Type === 0/*MarshalerType.None*/)
                {
                    value.$v = null;
                    return;
                }
                value.$v = $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$spc.System.Double), null, [this.slot.Length], null);
                $.$spc.System.Runtime.InteropServices.Marshal.Copy$13(this.slot.IntPtrValue, value.$v, 0, this.slot.Length);
                $.$spc.System.Runtime.InteropServices.Marshal.FreeHGlobal(this.slot.IntPtrValue);
            }
            /*void */ ToJS$6(/*double[]*/ value)
            {
                if (value === null)
                {
                    this.slot.Type = 0/*MarshalerType.None*/;
                    return;
                }
                this.slot.Type = 21/*MarshalerType.Array*/;
                this.slot.IntPtrValue = $.$spc.System.Runtime.InteropServices.Marshal.AllocHGlobal(((value.length * $.$spc.System.Double.$z) | 0));
                this.slot.Length = value.length;
                this.slot.ElementType = 10/*MarshalerType.Double*/;
                $.$spc.System.Runtime.InteropServices.Marshal.Copy$5(value, 0, this.slot.IntPtrValue, this.slot.Length);
            }
            /*void */ ToManaged$7(/*out ArraySegment<double>*/ value)
            {
                /*var*/ let array = $.$cast(($.$spc.System.Runtime.InteropServices.GCHandle.op_Explicit(this.slot.GCHandle)).Target, $.$typeArray($.$spc.System.Double));
                /*var*/ let refPtr = $.$spc.System.IntPtr.op_Explicit$2($.$spc.System.Runtime.CompilerServices.Unsafe.AsPointer($.$spc.System.Double, $.$spc.System.Runtime.InteropServices.MemoryMarshal.GetArrayDataReference($.$spc.System.Double, array)));
                /*int*/ let byteOffset = (this.slot.IntPtrValue - refPtr);
                value.$v = new ($.$spc.System.ArraySegment$$($.$spc.System.Double))().$ctor$3(array, $.trunc(byteOffset / $.$spc.System.Double.$z), this.slot.Length);
            }
            /*void */ ToJS$7(/*ArraySegment<double>*/ value)
            {
                if (value.Array === null)
                {
                    this.slot.Type = 0/*MarshalerType.None*/;
                    return;
                }
                this.slot.Type = 22/*MarshalerType.ArraySegment*/;
                /*var*/ let ctx = this.ToJSContext;
                this.slot.GCHandle = ctx.GetJSOwnedObjectGCHandle(value.Array, 3/*GCHandleType.Pinned*/);
                /*var*/ let refPtr = $.$spc.System.IntPtr.op_Explicit$2($.$spc.System.Runtime.CompilerServices.Unsafe.AsPointer($.$spc.System.Double, $.$spc.System.Runtime.InteropServices.MemoryMarshal.GetArrayDataReference($.$spc.System.Double, value.Array)));
                this.slot.IntPtrValue = refPtr + (((value.Offset * $.$spc.System.Double.$z) | 0));
                this.slot.Length = value.Count;
            }
            /*void */ ToManaged$8(/*out Span<double>*/ value)
            {
                value.$v = new ($.$spc.System.Span$$($.$spc.System.Double))().$ctor$4($.$spc.System.IntPtr.op_Explicit$3(this.slot.IntPtrValue), this.slot.Length);
            }
            /*void */ ToJS$8(/*Span<double>*/ value)
            {
                this.slot.Length = value.Length;
                this.slot.IntPtrValue = $.$spc.System.IntPtr.op_Explicit$2($.$spc.System.Runtime.CompilerServices.Unsafe.AsPointer($.$spc.System.Double, value.GetPinnableReference()));
                this.slot.Type = 23/*MarshalerType.Span*/;
            }
            /*long*/ static I52_MAX_VALUE = 9007199254740991n;
            /*long*/ static I52_MIN_VALUE = -9007199254740991n;
            /*void */ ToManaged$9(/*out long*/ value)
            {
                if (this.slot.Type === 0/*MarshalerType.None*/)
                {
                    value.$v = 0n;
                    return;
                }
                value.$v = $.$cast(this.slot.DoubleValue, $.$spc.System.Int64);
            }
            /*void */ ToJS$9(/*long*/ value)
            {
                if (value < -9007199254740991n || value > 9007199254740991n)
                {
                    throw new $.$spc.System.OverflowException().$ctor$14($.$srij.System.SR.Format$2($.$srij.System.SR.ValueOutOf52BitRange, $.$box(value, $.$spc.System.Int64), $.$box(-9007199254740991n, $.$spc.System.Int64), $.$box(9007199254740991n, $.$spc.System.Int64)));
                }
                this.slot.Type = 8/*MarshalerType.Int52*/;
                this.slot.DoubleValue = Number(value);
            }
            /*void */ ToManaged$10(/*out long?*/ value)
            {
                if (this.slot.Type === 0/*MarshalerType.None*/)
                {
                    value.$v = null;
                    return;
                }
                value.$v = $.$cast(this.slot.DoubleValue, $.$spc.System.Int64);
            }
            /*void */ ToJS$10(/*long?*/ value)
            {
                if ($.$spc.System.Nullable$$($.$spc.System.Int64).HasValue$get.call(value))
                {
                    if ($.$spc.System.Nullable$$($.$spc.System.Int64).Value$get.call(value) < -9007199254740991n || $.$spc.System.Nullable$$($.$spc.System.Int64).Value$get.call(value) > 9007199254740991n)
                    {
                        throw new $.$spc.System.OverflowException().$ctor$14($.$srij.System.SR.Format$2($.$srij.System.SR.ValueOutOf52BitRange, $.$box(value, $.$spc.System.Nullable$$($.$spc.System.Int64)), $.$box(-9007199254740991n, $.$spc.System.Int64), $.$box(9007199254740991n, $.$spc.System.Int64)));
                    }
                    this.slot.Type = 8/*MarshalerType.Int52*/;
                    this.slot.DoubleValue = Number($.$spc.System.Nullable$$($.$spc.System.Int64).Value$get.call(value));
                }
                else 
                {
                    this.slot.Type = 0/*MarshalerType.None*/;
                }
            }
            /*void */ ToManaged$11(/*out short*/ value)
            {
                if (this.slot.Type === 0/*MarshalerType.None*/)
                {
                    value.$v = 0;
                    return;
                }
                value.$v = this.slot.Int16Value;
            }
            /*void */ ToJS$11(/*short*/ value)
            {
                this.slot.Type = 6/*MarshalerType.Int16*/;
                this.slot.Int16Value = value;
            }
            /*void */ ToManaged$12(/*out short?*/ value)
            {
                if (this.slot.Type === 0/*MarshalerType.None*/)
                {
                    value.$v = null;
                    return;
                }
                value.$v = this.slot.Int16Value;
            }
            /*void */ ToJS$12(/*short?*/ value)
            {
                if ($.$spc.System.Nullable$$($.$spc.System.Int16).HasValue$get.call(value))
                {
                    this.slot.Type = 6/*MarshalerType.Int16*/;
                    this.slot.Int16Value = $.$spc.System.Nullable$$($.$spc.System.Int16).Value$get.call(value);
                }
                else 
                {
                    this.slot.Type = 0/*MarshalerType.None*/;
                }
            }
            /*void */ ToManaged$13(/*out DateTimeOffset*/ value)
            {
                if (this.slot.Type === 0/*MarshalerType.None*/)
                {
                    value.$v = new $.$spc.System.DateTimeOffset();
                    return;
                }
                value.$v = $.$spc.System.DateTimeOffset.FromUnixTimeMilliseconds($.$cast(this.slot.DoubleValue, $.$spc.System.Int64));
            }
            /*void */ ToJS$13(/*DateTimeOffset*/ value)
            {
                this.slot.Type = 18/*MarshalerType.DateTimeOffset*/;
                this.slot.DoubleValue = $.$cast(value.ToUnixTimeMilliseconds(), $.$spc.System.Double);
            }
            /*void */ ToManaged$14(/*out DateTimeOffset?*/ value)
            {
                if (this.slot.Type === 0/*MarshalerType.None*/)
                {
                    value.$v = null;
                    return;
                }
                value.$v = $.$spc.System.DateTimeOffset.FromUnixTimeMilliseconds($.$cast(this.slot.DoubleValue, $.$spc.System.Int64));
            }
            /*void */ ToJS$14(/*DateTimeOffset?*/ value)
            {
                if ($.$spc.System.Nullable$$($.$spc.System.DateTimeOffset).HasValue$get.call(value))
                {
                    this.slot.Type = 18/*MarshalerType.DateTimeOffset*/;
                    this.slot.DoubleValue = Number($.$spc.System.Nullable$$($.$spc.System.DateTimeOffset).Value$get.call(value).ToUnixTimeMilliseconds());
                }
                else 
                {
                    this.slot.Type = 0/*MarshalerType.None*/;
                }
            }
            /*void */ ToManaged$15(/*out DateTime*/ value)
            {
                if (this.slot.Type === 0/*MarshalerType.None*/)
                {
                    value.$v = new $.$spc.System.DateTime();
                    return;
                }
                value.$v = $.$spc.System.DateTimeOffset.FromUnixTimeMilliseconds($.$cast(this.slot.DoubleValue, $.$spc.System.Int64)).UtcDateTime;
            }
            /*void */ ToJS$15(/*DateTime*/ value)
            {
                this.slot.Type = 17/*MarshalerType.DateTime*/;
                this.slot.DoubleValue = Number(new $.$spc.System.DateTimeOffset().$ctor$4(value).ToUnixTimeMilliseconds());
            }
            /*void */ ToManaged$16(/*out DateTime?*/ value)
            {
                if (this.slot.Type === 0/*MarshalerType.None*/)
                {
                    value.$v = null;
                    return;
                }
                value.$v = $.$spc.System.DateTimeOffset.FromUnixTimeMilliseconds($.$cast(this.slot.DoubleValue, $.$spc.System.Int64)).UtcDateTime;
            }
            /*void */ ToJS$16(/*DateTime?*/ value)
            {
                if ($.$spc.System.Nullable$$($.$spc.System.DateTime).HasValue$get.call(value))
                {
                    this.slot.Type = 17/*MarshalerType.DateTime*/;
                    this.slot.DoubleValue = Number(new $.$spc.System.DateTimeOffset().$ctor$4($.$spc.System.Nullable$$($.$spc.System.DateTime).Value$get.call(value)).ToUnixTimeMilliseconds());
                }
                else 
                {
                    this.slot.Type = 0/*MarshalerType.None*/;
                }
            }
            /*void */ ToManaged$17(/*out bool*/ value)
            {
                if (this.slot.Type === 0/*MarshalerType.None*/)
                {
                    value.$v = false;
                    return;
                }
                value.$v = this.slot.BooleanValue;
            }
            /*void */ ToJS$17(/*bool*/ value)
            {
                this.slot.Type = 3/*MarshalerType.Boolean*/;
                this.slot.BooleanValue = value;
            }
            /*void */ ToManaged$18(/*out bool?*/ value)
            {
                if (this.slot.Type === 0/*MarshalerType.None*/)
                {
                    value.$v = null;
                    return;
                }
                value.$v = this.slot.BooleanValue;
            }
            /*void */ ToJS$18(/*bool?*/ value)
            {
                if ($.$spc.System.Nullable$$($.$spc.System.Boolean).HasValue$get.call(value))
                {
                    this.slot.Type = 3/*MarshalerType.Boolean*/;
                    this.slot.BooleanValue = $.$spc.System.Nullable$$($.$spc.System.Boolean).Value$get.call(value);
                }
                else 
                {
                    this.slot.Type = 0/*MarshalerType.None*/;
                }
            }
            /*void */ ToManaged$19(/*out byte*/ value)
            {
                if (this.slot.Type === 0/*MarshalerType.None*/)
                {
                    value.$v = 0;
                    return;
                }
                value.$v = this.slot.ByteValue;
            }
            /*void */ ToJS$19(/*byte*/ value)
            {
                this.slot.Type = 4/*MarshalerType.Byte*/;
                this.slot.ByteValue = value;
            }
            /*void */ ToManaged$20(/*out byte?*/ value)
            {
                if (this.slot.Type === 0/*MarshalerType.None*/)
                {
                    value.$v = null;
                    return;
                }
                value.$v = this.slot.ByteValue;
            }
            /*void */ ToJS$20(/*byte?*/ value)
            {
                if ($.$spc.System.Nullable$$($.$spc.System.Byte).HasValue$get.call(value))
                {
                    this.slot.Type = 4/*MarshalerType.Byte*/;
                    this.slot.ByteValue = $.$spc.System.Nullable$$($.$spc.System.Byte).Value$get.call(value);
                }
                else 
                {
                    this.slot.Type = 0/*MarshalerType.None*/;
                }
            }
            /*void */ ToManaged$21(/*out byte[]?*/ value)
            {
                if (this.slot.Type === 0/*MarshalerType.None*/)
                {
                    value.$v = null;
                    return;
                }
                value.$v = $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$spc.System.Byte), null, [this.slot.Length], null);
                $.$spc.System.Runtime.InteropServices.Marshal.Copy$14(this.slot.IntPtrValue, value.$v, 0, this.slot.Length);
                $.$spc.System.Runtime.InteropServices.Marshal.FreeHGlobal(this.slot.IntPtrValue);
            }
            /*void */ ToJS$21(/*byte[]?*/ value)
            {
                if (value === null)
                {
                    this.slot.Type = 0/*MarshalerType.None*/;
                    return;
                }
                this.slot.Length = value.length;
                this.slot.Type = 21/*MarshalerType.Array*/;
                this.slot.IntPtrValue = $.$spc.System.Runtime.InteropServices.Marshal.AllocHGlobal(((value.length * $.$spc.System.Byte.$z) | 0));
                this.slot.ElementType = 4/*MarshalerType.Byte*/;
                $.$spc.System.Runtime.InteropServices.Marshal.Copy$6(value, 0, this.slot.IntPtrValue, this.slot.Length);
            }
            /*void */ ToManaged$22(/*out ArraySegment<byte>*/ value)
            {
                /*var*/ let array = $.$cast(($.$spc.System.Runtime.InteropServices.GCHandle.op_Explicit(this.slot.GCHandle)).Target, $.$typeArray($.$spc.System.Byte));
                /*var*/ let refPtr = $.$spc.System.IntPtr.op_Explicit$2($.$spc.System.Runtime.CompilerServices.Unsafe.AsPointer($.$spc.System.Byte, $.$spc.System.Runtime.InteropServices.MemoryMarshal.GetArrayDataReference($.$spc.System.Byte, array)));
                /*int*/ let byteOffset = (this.slot.IntPtrValue - refPtr);
                value.$v = new ($.$spc.System.ArraySegment$$($.$spc.System.Byte))().$ctor$3(array, byteOffset, this.slot.Length);
            }
            /*void */ ToJS$22(/*ArraySegment<byte>*/ value)
            {
                if (value.Array === null)
                {
                    this.slot.Type = 0/*MarshalerType.None*/;
                    return;
                }
                this.slot.Type = 22/*MarshalerType.ArraySegment*/;
                /*var*/ let ctx = this.ToJSContext;
                this.slot.GCHandle = ctx.GetJSOwnedObjectGCHandle(value.Array, 3/*GCHandleType.Pinned*/);
                /*var*/ let refPtr = $.$spc.System.IntPtr.op_Explicit$2($.$spc.System.Runtime.CompilerServices.Unsafe.AsPointer($.$spc.System.Byte, $.$spc.System.Runtime.InteropServices.MemoryMarshal.GetArrayDataReference($.$spc.System.Byte, value.Array)));
                this.slot.IntPtrValue = refPtr + value.Offset;
                this.slot.Length = value.Count;
            }
            /*void */ ToManaged$23(/*out Span<byte>*/ value)
            {
                value.$v = new ($.$spc.System.Span$$($.$spc.System.Byte))().$ctor$4($.$spc.System.IntPtr.op_Explicit$3(this.slot.IntPtrValue), this.slot.Length);
            }
            /*void */ ToJS$23(/*Span<byte>*/ value)
            {
                this.slot.Length = value.Length;
                this.slot.IntPtrValue = $.$spc.System.IntPtr.op_Explicit$2($.$spc.System.Runtime.CompilerServices.Unsafe.AsPointer($.$spc.System.Byte, value.GetPinnableReference()));
                this.slot.Type = 23/*MarshalerType.Span*/;
            }
            /*void */ ToManaged$24(/*out IntPtr*/ value)
            {
                if (this.slot.Type === 0/*MarshalerType.None*/)
                {
                    value.$v = 0;
                    return;
                }
                value.$v = this.slot.IntPtrValue;
            }
            /*void */ ToJS$24(/*IntPtr*/ value)
            {
                this.slot.Type = 12/*MarshalerType.IntPtr*/;
                this.slot.IntPtrValue = value;
            }
            /*void */ ToManaged$25(/*out IntPtr?*/ value)
            {
                if (this.slot.Type === 0/*MarshalerType.None*/)
                {
                    value.$v = null;
                    return;
                }
                value.$v = this.slot.IntPtrValue;
            }
            /*void */ ToJS$25(/*IntPtr?*/ value)
            {
                if ($.$spc.System.Nullable$$($.$spc.System.IntPtr).HasValue$get.call(value))
                {
                    this.slot.Type = 12/*MarshalerType.IntPtr*/;
                    this.slot.IntPtrValue = $.$spc.System.Nullable$$($.$spc.System.IntPtr).Value$get.call(value);
                }
                else 
                {
                    this.slot.Type = 0/*MarshalerType.None*/;
                }
            }
            /*void */ ToManaged$26(/*out void**/ value)
            {
                if (this.slot.Type === 0/*MarshalerType.None*/)
                {
                    value.$v = new $.$typePointer($.$spc.System.Void)();
                    return;
                }
                value.$v = $.$cast(this.slot.IntPtrValue, $.$typePointer($.$spc.System.Byte));
            }
            /*void */ ToJS$26(/*void**/ value)
            {
                this.slot.Type = 12/*MarshalerType.IntPtr*/;
                this.slot.IntPtrValue = $.$spc.System.IntPtr.op_Explicit$2(value);
            }
            /*void */ ToManaged$27(/*out JSObject?*/ value)
            {
                if (this.slot.Type === 0/*MarshalerType.None*/)
                {
                    value.$v = null;
                    return;
                }
                /*var*/ let ctx = this.ToManagedContext;
                value.$v = ctx.CreateCSOwnedProxy(this.slot.JSHandle);
            }
            /*void */ ToJS$27(/*JSObject?*/ value)
            {
                if (value === null)
                {
                    this.slot.Type = 0/*MarshalerType.None*/;
                }
                else 
                {
                    value.AssertNotDisposed();
                    this.slot.Type = 13/*MarshalerType.JSObject*/;
                    this.slot.JSHandle = value.JSHandle;
                }
            }
            /*void */ ToManaged$28(/*out JSObject?[]?*/ value)
            {
                if (this.slot.Type === 0/*MarshalerType.None*/)
                {
                    value.$v = null;
                    return;
                }
                value.$v = $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$srij.System.Runtime.InteropServices.JavaScript.JSObject), null, [this.slot.Length], null);
                /*JSMarshalerArgument**/ let payload = $.$cast(this.slot.IntPtrValue, $.$typePointer($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument));
                for(/*int*/ let i = 0; i < this.slot.Length; i++)
                {
                    /*ref JSMarshalerArgument*/ let arg = payload.Add(i);
                    /*JSObject?*/ let val;
                    arg.$v.ToManaged$27($.$ref(() => val, ($v) => val = $v, $.$srij.System.Runtime.InteropServices.JavaScript.JSObject));
                    $.$spc.System.Array.$WriteT1.call(value.$v, val, i);
                }
                $.$spc.System.Runtime.InteropServices.Marshal.FreeHGlobal(this.slot.IntPtrValue);
            }
            /*void */ ToJS$28(/*JSObject?[]*/ value)
            {
                if (value === null)
                {
                    this.slot.Type = 0/*MarshalerType.None*/;
                    return;
                }
                this.slot.Length = value.length;
                /*int*/ let bytes = ((value.length * $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument.$z) | 0);
                this.slot.Type = 21/*MarshalerType.Array*/;
                this.slot.ElementType = 13/*MarshalerType.JSObject*/;
                /*JSMarshalerArgument**/ let payload = $.$cast($.$spc.System.Runtime.InteropServices.Marshal.AllocHGlobal(bytes), $.$typePointer($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument));
                $.$spc.System.Runtime.CompilerServices.Unsafe.InitBlock(payload, 0, (bytes >>> 0));
                for(/*int*/ let i = 0; i < this.slot.Length; i++)
                {
                    /*ref JSMarshalerArgument*/ let arg = payload.Add(i);
                    /*JSObject?*/ let val = $.$spc.System.Array.$ReadT1.call(value, i);
                    arg.$v.ToJS$27(val);
                    $.$spc.System.Array.$WriteT1.call(value, val, i);
                }
                this.slot.IntPtrValue = $.$cast(payload, $.$spc.System.IntPtr);
            }
            /*void */ ToManaged$29(/*out string?*/ value)
            {
                if (this.slot.Type === 0/*MarshalerType.None*/)
                {
                    value.$v = null;
                    return;
                }
                /*fixed*/ 
                {
                    /*void**/ let argAsRoot = $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateObjectReferenceT($.$spc.System.IntPtr, () => this.slot.IntPtrValue, ($v) => this.slot.IntPtrValue = $v, null);
                    value.$v = $.$spc.System.Runtime.CompilerServices.Unsafe.AsRef($.$spc.System.String, argAsRoot).$v;
                }
            }
            /*void */ ToJS$29(/*string?*/ value)
            {
                if ($.$spc.System.String.op_Equality(value, null))
                {
                    this.slot.Type = 0/*MarshalerType.None*/;
                }
                else 
                {
                    this.slot.Type = 15/*MarshalerType.String*/;
                    /*fixed*/ 
                    {
                        /*IntPtr**/ let argAsRoot = $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateObjectReferenceT($.$spc.System.IntPtr, () => this.slot.IntPtrValue, ($v) => this.slot.IntPtrValue = $v, null);
                        /*string*/ let cpy = value;
                        /*var*/ let currentRoot = $.$cast($.$spc.System.Runtime.CompilerServices.Unsafe.AsPointer($.$spc.System.String, $.$ref(() => cpy, ($v) => cpy = $v, $.$spc.System.String)), $.$typePointer($.$spc.System.IntPtr));
                        argAsRoot.SetAt(currentRoot.GetAt(0), 0);
                    }
                }
            }
            /*void */ ToManaged$30(/*out string?[]?*/ value)
            {
                if (this.slot.Type === 0/*MarshalerType.None*/)
                {
                    value.$v = null;
                    return;
                }
                value.$v = $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$spc.System.String), null, [this.slot.Length], null);
                /*JSMarshalerArgument**/ let payload = $.$cast(this.slot.IntPtrValue, $.$typePointer($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument));
                for(/*int*/ let i = 0; i < this.slot.Length; i++)
                {
                    /*ref JSMarshalerArgument*/ let arg = payload.Add(i);
                    /*string?*/ let val;
                    arg.$v.ToManaged$29($.$ref(() => val, ($v) => val = $v, $.$spc.System.String));
                    $.$spc.System.Array.$WriteT1.call(value.$v, val, i);
                }
                $.$srij.Interop.Runtime.DeregisterGCRoot(this.slot.IntPtrValue);
                $.$spc.System.Runtime.InteropServices.Marshal.FreeHGlobal(this.slot.IntPtrValue);
            }
            /*void */ ToJS$30(/*string?[]*/ value)
            {
                if (value === null)
                {
                    this.slot.Type = 0/*MarshalerType.None*/;
                    return;
                }
                this.slot.Length = value.length;
                /*int*/ let bytes = ((value.length * $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument.$z) | 0);
                this.slot.Type = 21/*MarshalerType.Array*/;
                /*JSMarshalerArgument**/ let payload = $.$cast($.$spc.System.Runtime.InteropServices.Marshal.AllocHGlobal(bytes), $.$typePointer($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument));
                $.$spc.System.Runtime.CompilerServices.Unsafe.InitBlock(payload, 0, (bytes >>> 0));
                $.$srij.Interop.Runtime.RegisterGCRoot(payload, bytes, $.$spc.System.IntPtr.Zero);
                for(/*int*/ let i = 0; i < this.slot.Length; i++)
                {
                    /*ref JSMarshalerArgument*/ let arg = payload.Add(i);
                    /*string?*/ let val = $.$spc.System.Array.$ReadT1.call(value, i);
                    arg.$v.ToJS$29(val);
                    $.$spc.System.Array.$WriteT1.call(value, val, i);
                }
                this.slot.IntPtrValue = $.$cast(payload, $.$spc.System.IntPtr);
                this.slot.ElementType = 15/*MarshalerType.String*/;
            }
            /*void */ ToManaged$31(/*out int*/ value)
            {
                if (this.slot.Type === 0/*MarshalerType.None*/)
                {
                    value.$v = 0;
                    return;
                }
                value.$v = this.slot.Int32Value;
            }
            /*void */ ToJS$31(/*int*/ value)
            {
                this.slot.Type = 7/*MarshalerType.Int32*/;
                this.slot.Int32Value = value;
            }
            /*void */ ToManaged$32(/*out int?*/ value)
            {
                if (this.slot.Type === 0/*MarshalerType.None*/)
                {
                    value.$v = null;
                    return;
                }
                value.$v = this.slot.Int32Value;
            }
            /*void */ ToJS$32(/*int?*/ value)
            {
                if ($.$spc.System.Nullable$$($.$spc.System.Int32).HasValue$get.call(value))
                {
                    this.slot.Type = 7/*MarshalerType.Int32*/;
                    this.slot.Int32Value = $.$spc.System.Nullable$$($.$spc.System.Int32).Value$get.call(value);
                }
                else 
                {
                    this.slot.Type = 0/*MarshalerType.None*/;
                }
            }
            /*void */ ToManaged$33(/*out int[]?*/ value)
            {
                if (this.slot.Type === 0/*MarshalerType.None*/)
                {
                    value.$v = null;
                    return;
                }
                value.$v = $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$spc.System.Int32), null, [this.slot.Length], null);
                $.$spc.System.Runtime.InteropServices.Marshal.Copy$8(this.slot.IntPtrValue, value.$v, 0, this.slot.Length);
                $.$spc.System.Runtime.InteropServices.Marshal.FreeHGlobal(this.slot.IntPtrValue);
            }
            /*void */ ToJS$33(/*int[]?*/ value)
            {
                if (value === null)
                {
                    this.slot.Type = 0/*MarshalerType.None*/;
                    return;
                }
                this.slot.Type = 21/*MarshalerType.Array*/;
                this.slot.IntPtrValue = $.$spc.System.Runtime.InteropServices.Marshal.AllocHGlobal(((value.length * $.$spc.System.Int32.$z) | 0));
                this.slot.Length = value.length;
                this.slot.ElementType = 7/*MarshalerType.Int32*/;
                $.$spc.System.Runtime.InteropServices.Marshal.Copy(value, 0, this.slot.IntPtrValue, this.slot.Length);
            }
            /*void */ ToManaged$34(/*out ArraySegment<int>*/ value)
            {
                /*var*/ let array = $.$cast(($.$spc.System.Runtime.InteropServices.GCHandle.op_Explicit(this.slot.GCHandle)).Target, $.$typeArray($.$spc.System.Int32));
                /*var*/ let refPtr = $.$spc.System.IntPtr.op_Explicit$2($.$spc.System.Runtime.CompilerServices.Unsafe.AsPointer($.$spc.System.Int32, $.$spc.System.Runtime.InteropServices.MemoryMarshal.GetArrayDataReference($.$spc.System.Int32, array)));
                /*int*/ let byteOffset = (this.slot.IntPtrValue - refPtr);
                value.$v = new ($.$spc.System.ArraySegment$$($.$spc.System.Int32))().$ctor$3(array, $.trunc(byteOffset / $.$spc.System.Int32.$z), this.slot.Length);
            }
            /*void */ ToJS$34(/*ArraySegment<int>*/ value)
            {
                if (value.Array === null)
                {
                    this.slot.Type = 0/*MarshalerType.None*/;
                    return;
                }
                /*var*/ let ctx = this.ToJSContext;
                this.slot.Type = 22/*MarshalerType.ArraySegment*/;
                this.slot.GCHandle = ctx.GetJSOwnedObjectGCHandle(value.Array, 3/*GCHandleType.Pinned*/);
                /*var*/ let refPtr = $.$spc.System.IntPtr.op_Explicit$2($.$spc.System.Runtime.CompilerServices.Unsafe.AsPointer($.$spc.System.Int32, $.$spc.System.Runtime.InteropServices.MemoryMarshal.GetArrayDataReference($.$spc.System.Int32, value.Array)));
                this.slot.IntPtrValue = refPtr + (((value.Offset * $.$spc.System.Int32.$z) | 0));
                this.slot.Length = value.Count;
            }
            /*void */ ToManaged$35(/*out Span<int>*/ value)
            {
                value.$v = new ($.$spc.System.Span$$($.$spc.System.Int32))().$ctor$4($.$spc.System.IntPtr.op_Explicit$3(this.slot.IntPtrValue), this.slot.Length);
            }
            /*void */ ToJS$35(/*Span<int>*/ value)
            {
                this.slot.Length = value.Length;
                this.slot.IntPtrValue = $.$spc.System.IntPtr.op_Explicit$2($.$spc.System.Runtime.CompilerServices.Unsafe.AsPointer($.$spc.System.Int32, value.GetPinnableReference()));
                this.slot.Type = 23/*MarshalerType.Span*/;
            }
            /*void */ ToManaged$36(/*out Exception?*/ value)
            {
                if (this.slot.Type === 0/*MarshalerType.None*/)
                {
                    value.$v = null;
                    return;
                }
                if (this.slot.Type === 16/*MarshalerType.Exception*/)
                {
                    value.$v = $.$cast(($.$spc.System.Runtime.InteropServices.GCHandle.op_Explicit(this.slot.GCHandle)).Target, $.$spc.System.Exception);
                    return;
                }
                /*JSObject?*/ let jsException = null;
                if (this.slot.JSHandle !== $.$spc.System.IntPtr.Zero)
                {
                    /*var*/ let ctx = this.ToManagedContext;
                    jsException = ctx.CreateCSOwnedProxy(this.slot.JSHandle);
                }
                /*string?*/ let message;
                this.ToManaged$29($.$ref(() => message, ($v) => message = $v, $.$spc.System.String));
                value.$v = new $.$srij.System.Runtime.InteropServices.JavaScript.JSException().$ctor$6(message, jsException);
            }
            /*void */ ToJS$36(/*Exception?*/ value)
            {
                if (value === null)
                {
                    this.slot.Type = 0/*MarshalerType.None*/;
                }
                else 
                {
                    /*Exception*/ let cpy = value;
                    let ae;
                    if ($.$is(cpy, $.$spc.System.AggregateException, { set $v(v){ ae = v; } }) && ae.InnerExceptions.Count === 1)
                    {
                        cpy = ae.InnerExceptions.get_Item(0);
                    }
                    /*var*/ let jse = $.$as(cpy, $.$srij.System.Runtime.InteropServices.JavaScript.JSException);
                    if (jse !== null && jse.jsException !== null)
                    {
                        /*var*/ let jsException = jse.jsException;
                        jsException.AssertNotDisposed();
                        this.slot.Type = 27/*MarshalerType.JSException*/;
                        this.slot.JSHandle = jsException.JSHandle;
                    }
                    else 
                    {
                        this.ToJS$29(cpy.Message);
                        this.slot.Type = 16/*MarshalerType.Exception*/;
                        /*var*/ let ctx = this.ToJSContext;
                        this.slot.GCHandle = ctx.GetJSOwnedObjectGCHandle(cpy, 2);
                    }
                }
            }
            static $_ActionJS;
            static get ActionJS()
            {
                let $cls = $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument;
                return $cls.$_ActionJS ??= $asm.$ncls("$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument.ActionJS", ($self) => class ActionJS extends $.$spc.System.Object
                {
                    /*JSObject*/ JSObject = null;
                    $ctor$1(/*JSObject*/ holder)
                    {
                        super.$ctor();
                        {
                            this.JSObject = holder;
                        }
                        return this;
                    }
                    /*void */ InvokeJS()
                    {
                        /*Span<JSMarshalerArgument>*/ let $arguments = $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.StackAllocSpan($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument, 2, null);
                        /*ref JSMarshalerArgument*/ let args_exception = $arguments.get_Item(0);
                        /*ref JSMarshalerArgument*/ let args_return = $arguments.get_Item(1);
                        args_exception.$v.Initialize();
                        args_return.$v.Initialize();
                        $.$srij.System.Runtime.InteropServices.JavaScript.JSFunctionBinding.InvokeJSFunction(this.JSObject, $arguments);
                    }
                    static $h = 1429740;
                    static $f = 0b10000000010010000;
                    static $k = 1;
                    static $$md;
                    static get $md() { return this.$$md ??= {"b":131073,"m":[{"r":65537,"n":"InvokeJS","d":1429740,"h":12886331628,"f":1}],"l":[{"t":2281708,"n":"JSObject","d":1429740,"h":4296397036,"f":2}],"c":[{"p":[{"n":"holder","p":2281708}],"n":".ctor","o":"$ctor$1","d":1429740,"h":8591364332,"f":1}],"d":1364204,"h":1429740}; }
                    static get $b() { return $.$spc.System.Object; }
                    static get $fullName() { return `System.Runtime.InteropServices.JavaScript.JSMarshalerArgument.ActionJS`; }
                }, $cls, ($v) => $cls.$_ActionJS = $v);
            }
            static $_ActionJS$$;
            static ActionJS$$(T)
            {
                let $cls = $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument;
                return ($cls.$_ActionJS$$ ??= $asm.$ncls("$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument.ActionJS<>", (T) => $asm.$gt("$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument.ActionJS<>", [T], ($self) => class ActionJS$$ extends $.$spc.System.Object
                {
                    /*ArgumentToJSCallback<T>*/ Arg1Marshaler = null;
                    /*JSObject*/ JSObject = null;
                    $ctor$1(/*JSObject*/ holder, /*ArgumentToJSCallback<T>*/ arg1Marshaler)
                    {
                        super.$ctor();
                        {
                            this.JSObject = holder;
                            this.Arg1Marshaler = arg1Marshaler;
                        }
                        return this;
                    }
                    /*void */ InvokeJS(/*T*/ arg1)
                    {
                        /*Span<JSMarshalerArgument>*/ let $arguments = $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.StackAllocSpan($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument, 3, null);
                        /*ref JSMarshalerArgument*/ let args_exception = $arguments.get_Item(0);
                        /*ref JSMarshalerArgument*/ let args_return = $arguments.get_Item(1);
                        /*ref JSMarshalerArgument*/ let args_arg1 = $arguments.get_Item(2);
                        args_exception.$v.Initialize();
                        args_return.$v.Initialize();
                        this.Arg1Marshaler.Invoke(args_arg1, arg1);
                        $.$srij.System.Runtime.InteropServices.JavaScript.JSFunctionBinding.InvokeJSFunction(this.JSObject, $arguments);
                    }
                    static $h = 1626348;
                    static $g = 1;
                    static $f = 0b10000000011010000;
                    static $k = 1;
                    static $$md;
                    static get $md() { return this.$$md ??= {"b":131073,"m":[{"r":65537,"p":[{"n":"arg1","p":T?.$h??1507328}],"n":"InvokeJS","d":this.$h,"h":Number(BigInt(this.$h)|0x400000000n),"f":1}],"l":[{"t":$.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument.ArgumentToJSCallback$$(T).$h,"n":"Arg1Marshaler","d":this.$h,"h":Number(BigInt(this.$h)|0x100000000n),"f":2},{"t":2281708,"n":"JSObject","d":this.$h,"h":Number(BigInt(this.$h)|0x200000000n),"f":2}],"c":[{"p":[{"n":"holder","p":2281708},{"n":"arg1Marshaler","p":$.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument.ArgumentToJSCallback$$(T).$h}],"n":".ctor","o":"$ctor$1","d":this.$h,"h":Number(BigInt(this.$h)|0x300000000n),"f":1}],"g":[T?.$h??1507328],"r":1,"d":1364204,"h":this.$h}; }
                    static get $b() { return $.$spc.System.Object; }
                    static get $fullName() { return `System.Runtime.InteropServices.JavaScript.JSMarshalerArgument.ActionJS<${T?.$fullName}>`; }
                }), $cls, ($v) => $cls.$_ActionJS$$ = $v))(T);
            }
            static $_ActionJS$$$;
            static ActionJS$$$(T1, T2)
            {
                let $cls = $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument;
                return ($cls.$_ActionJS$$$ ??= $asm.$ncls("$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument.ActionJS<,>", (T1, T2) => $asm.$gt("$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument.ActionJS<,>", [T1, T2], ($self) => class ActionJS$$$ extends $.$spc.System.Object
                {
                    /*ArgumentToJSCallback<T1>*/ Arg1Marshaler = null;
                    /*ArgumentToJSCallback<T2>*/ Arg2Marshaler = null;
                    /*JSObject*/ JSObject = null;
                    $ctor$1(/*JSObject*/ holder, /*ArgumentToJSCallback<T1>*/ arg1Marshaler, /*ArgumentToJSCallback<T2>*/ arg2Marshaler)
                    {
                        super.$ctor();
                        {
                            this.JSObject = holder;
                            this.Arg1Marshaler = arg1Marshaler;
                            this.Arg2Marshaler = arg2Marshaler;
                        }
                        return this;
                    }
                    /*void */ InvokeJS(/*T1*/ arg1, /*T2*/ arg2)
                    {
                        /*Span<JSMarshalerArgument>*/ let $arguments = $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.StackAllocSpan($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument, 4, null);
                        /*ref JSMarshalerArgument*/ let args_exception = $arguments.get_Item(0);
                        /*ref JSMarshalerArgument*/ let args_return = $arguments.get_Item(1);
                        /*ref JSMarshalerArgument*/ let args_arg1 = $arguments.get_Item(2);
                        /*ref JSMarshalerArgument*/ let args_arg2 = $arguments.get_Item(3);
                        args_exception.$v.Initialize();
                        args_return.$v.Initialize();
                        this.Arg1Marshaler.Invoke(args_arg1, arg1);
                        this.Arg2Marshaler.Invoke(args_arg2, arg2);
                        $.$srij.System.Runtime.InteropServices.JavaScript.JSFunctionBinding.InvokeJSFunction(this.JSObject, $arguments);
                    }
                    static $h = 1560812;
                    static $g = 2;
                    static $f = 0b10000000011010000;
                    static $k = 1;
                    static $$md;
                    static get $md() { return this.$$md ??= {"b":131073,"m":[{"r":65537,"p":[{"n":"arg1","p":T1?.$h??1507328},{"n":"arg2","p":T2?.$h??1572864}],"n":"InvokeJS","d":this.$h,"h":Number(BigInt(this.$h)|0x500000000n),"f":1}],"l":[{"t":$.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument.ArgumentToJSCallback$$(T1).$h,"n":"Arg1Marshaler","d":this.$h,"h":Number(BigInt(this.$h)|0x100000000n),"f":2},{"t":$.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument.ArgumentToJSCallback$$(T2).$h,"n":"Arg2Marshaler","d":this.$h,"h":Number(BigInt(this.$h)|0x200000000n),"f":2},{"t":2281708,"n":"JSObject","d":this.$h,"h":Number(BigInt(this.$h)|0x300000000n),"f":2}],"c":[{"p":[{"n":"holder","p":2281708},{"n":"arg1Marshaler","p":$.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument.ArgumentToJSCallback$$(T1).$h},{"n":"arg2Marshaler","p":$.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument.ArgumentToJSCallback$$(T2).$h}],"n":".ctor","o":"$ctor$1","d":this.$h,"h":Number(BigInt(this.$h)|0x400000000n),"f":1}],"g":[T1?.$h??1507328,T2?.$h??1572864],"r":2,"d":1364204,"h":this.$h}; }
                    static get $b() { return $.$spc.System.Object; }
                    static get $fullName() { return `System.Runtime.InteropServices.JavaScript.JSMarshalerArgument.ActionJS<${T1?.$fullName},${T2?.$fullName}>`; }
                }), $cls, ($v) => $cls.$_ActionJS$$$ = $v))(T1, T2);
            }
            static $_ActionJS$$$$;
            static ActionJS$$$$(T1, T2, T3)
            {
                let $cls = $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument;
                return ($cls.$_ActionJS$$$$ ??= $asm.$ncls("$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument.ActionJS<,,>", (T1, T2, T3) => $asm.$gt("$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument.ActionJS<,,>", [T1, T2, T3], ($self) => class ActionJS$$$$ extends $.$spc.System.Object
                {
                    /*ArgumentToJSCallback<T1>*/ Arg1Marshaler = null;
                    /*ArgumentToJSCallback<T2>*/ Arg2Marshaler = null;
                    /*ArgumentToJSCallback<T3>*/ Arg3Marshaler = null;
                    /*JSObject*/ JSObject = null;
                    $ctor$1(/*JSObject*/ holder, /*ArgumentToJSCallback<T1>*/ arg1Marshaler, /*ArgumentToJSCallback<T2>*/ arg2Marshaler, /*ArgumentToJSCallback<T3>*/ arg3Marshaler)
                    {
                        super.$ctor();
                        {
                            this.JSObject = holder;
                            this.Arg1Marshaler = arg1Marshaler;
                            this.Arg2Marshaler = arg2Marshaler;
                            this.Arg3Marshaler = arg3Marshaler;
                        }
                        return this;
                    }
                    /*void */ InvokeJS(/*T1*/ arg1, /*T2*/ arg2, /*T3*/ arg3)
                    {
                        /*Span<JSMarshalerArgument>*/ let $arguments = $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.StackAllocSpan($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument, 5, null);
                        /*ref JSMarshalerArgument*/ let args_exception = $arguments.get_Item(0);
                        /*ref JSMarshalerArgument*/ let args_return = $arguments.get_Item(1);
                        /*ref JSMarshalerArgument*/ let args_arg1 = $arguments.get_Item(2);
                        /*ref JSMarshalerArgument*/ let args_arg2 = $arguments.get_Item(3);
                        /*ref JSMarshalerArgument*/ let args_arg3 = $arguments.get_Item(4);
                        args_exception.$v.Initialize();
                        args_return.$v.Initialize();
                        this.Arg1Marshaler.Invoke(args_arg1, arg1);
                        this.Arg2Marshaler.Invoke(args_arg2, arg2);
                        this.Arg3Marshaler.Invoke(args_arg3, arg3);
                        $.$srij.System.Runtime.InteropServices.JavaScript.JSFunctionBinding.InvokeJSFunction(this.JSObject, $arguments);
                    }
                    static $h = 1495276;
                    static $g = 3;
                    static $f = 0b10000000011010000;
                    static $k = 1;
                    static $$md;
                    static get $md() { return this.$$md ??= {"b":131073,"m":[{"r":65537,"p":[{"n":"arg1","p":T1?.$h??1507328},{"n":"arg2","p":T2?.$h??1572864},{"n":"arg3","p":T3?.$h??1638400}],"n":"InvokeJS","d":this.$h,"h":Number(BigInt(this.$h)|0x600000000n),"f":1}],"l":[{"t":$.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument.ArgumentToJSCallback$$(T1).$h,"n":"Arg1Marshaler","d":this.$h,"h":Number(BigInt(this.$h)|0x100000000n),"f":2},{"t":$.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument.ArgumentToJSCallback$$(T2).$h,"n":"Arg2Marshaler","d":this.$h,"h":Number(BigInt(this.$h)|0x200000000n),"f":2},{"t":$.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument.ArgumentToJSCallback$$(T3).$h,"n":"Arg3Marshaler","d":this.$h,"h":Number(BigInt(this.$h)|0x300000000n),"f":2},{"t":2281708,"n":"JSObject","d":this.$h,"h":Number(BigInt(this.$h)|0x400000000n),"f":2}],"c":[{"p":[{"n":"holder","p":2281708},{"n":"arg1Marshaler","p":$.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument.ArgumentToJSCallback$$(T1).$h},{"n":"arg2Marshaler","p":$.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument.ArgumentToJSCallback$$(T2).$h},{"n":"arg3Marshaler","p":$.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument.ArgumentToJSCallback$$(T3).$h}],"n":".ctor","o":"$ctor$1","d":this.$h,"h":Number(BigInt(this.$h)|0x500000000n),"f":1}],"g":[T1?.$h??1507328,T2?.$h??1572864,T3?.$h??1638400],"r":3,"d":1364204,"h":this.$h}; }
                    static get $b() { return $.$spc.System.Object; }
                    static get $fullName() { return `System.Runtime.InteropServices.JavaScript.JSMarshalerArgument.ActionJS<${T1?.$fullName},${T2?.$fullName},${T3?.$fullName}>`; }
                }), $cls, ($v) => $cls.$_ActionJS$$$$ = $v))(T1, T2, T3);
            }
            /*void */ ToManaged$37(/*out Action?*/ value)
            {
                if (this.slot.Type === 0/*MarshalerType.None*/)
                {
                    value.$v = null;
                    return;
                }
                /*var*/ let ctx = this.ToManagedContext;
                /*var*/ let holder = ctx.CreateCSOwnedProxy(this.slot.JSHandle);
                value.$v = new $.$spc.System.Action().$ctor(new $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument.ActionJS().$ctor$1(holder), new $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument.ActionJS().$ctor$1(holder).InvokeJS);
            }
            /*void */ ToManaged$38(T, /*out Action<T>?*/ value, /*ArgumentToJSCallback<T>*/ arg1Marshaler)
            {
                if (this.slot.Type === 0/*MarshalerType.None*/)
                {
                    value.$v = null;
                    return;
                }
                /*var*/ let ctx = this.ToManagedContext;
                /*var*/ let holder = ctx.CreateCSOwnedProxy(this.slot.JSHandle);
                value.$v = new ($.$spc.System.Action$$(T))().$ctor(new ($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument.ActionJS$$(T))().$ctor$1(holder, arg1Marshaler), new ($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument.ActionJS$$(T))().$ctor$1(holder, arg1Marshaler).InvokeJS);
            }
            /*void */ ToManaged$39(T1, T2, /*out Action<T1, T2>?*/ value, /*ArgumentToJSCallback<T1>*/ arg1Marshaler, /*ArgumentToJSCallback<T2>*/ arg2Marshaler)
            {
                if (this.slot.Type === 0/*MarshalerType.None*/)
                {
                    value.$v = null;
                    return;
                }
                /*var*/ let ctx = this.ToManagedContext;
                /*var*/ let holder = ctx.CreateCSOwnedProxy(this.slot.JSHandle);
                value.$v = new ($.$spc.System.Action$$$(T1, T2))().$ctor(new ($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument.ActionJS$$$(T1, T2))().$ctor$1(holder, arg1Marshaler, arg2Marshaler), new ($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument.ActionJS$$$(T1, T2))().$ctor$1(holder, arg1Marshaler, arg2Marshaler).InvokeJS);
            }
            /*void */ ToManaged$40(T1, T2, T3, /*out Action<T1, T2, T3>?*/ value, /*ArgumentToJSCallback<T1>*/ arg1Marshaler, /*ArgumentToJSCallback<T2>*/ arg2Marshaler, /*ArgumentToJSCallback<T3>*/ arg3Marshaler)
            {
                if (this.slot.Type === 0/*MarshalerType.None*/)
                {
                    value.$v = null;
                    return;
                }
                /*var*/ let ctx = this.ToManagedContext;
                /*var*/ let holder = ctx.CreateCSOwnedProxy(this.slot.JSHandle);
                value.$v = new ($.$spc.System.Action$$$$(T1, T2, T3))().$ctor(new ($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument.ActionJS$$$$(T1, T2, T3))().$ctor$1(holder, arg1Marshaler, arg2Marshaler, arg3Marshaler), new ($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument.ActionJS$$$$(T1, T2, T3))().$ctor$1(holder, arg1Marshaler, arg2Marshaler, arg3Marshaler).InvokeJS);
            }
            static $_FuncJS$$;
            static FuncJS$$(TResult)
            {
                let $cls = $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument;
                return ($cls.$_FuncJS$$ ??= $asm.$ncls("$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument.FuncJS<>", (TResult) => $asm.$gt("$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument.FuncJS<>", [TResult], ($self) => class FuncJS$$ extends $.$spc.System.Object
                {
                    /*JSObject*/ JSObject = null;
                    /*ArgumentToManagedCallback<TResult>*/ ResMarshaler = null;
                    $ctor$1(/*JSObject*/ holder, /*ArgumentToManagedCallback<TResult>*/ resMarshaler)
                    {
                        super.$ctor();
                        {
                            this.JSObject = holder;
                            this.ResMarshaler = resMarshaler;
                        }
                        return this;
                    }
                    /*TResult */ InvokeJS()
                    {
                        /*Span<JSMarshalerArgument>*/ let $arguments = $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.StackAllocSpan($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument, 2, null);
                        /*ref JSMarshalerArgument*/ let args_exception = $arguments.get_Item(0);
                        /*ref JSMarshalerArgument*/ let args_return = $arguments.get_Item(1);
                        args_exception.$v.Initialize();
                        args_return.$v.Initialize();
                        $.$srij.System.Runtime.InteropServices.JavaScript.JSFunctionBinding.InvokeJSFunction(this.JSObject, $arguments);
                        /*TResult*/ let res;
                        this.ResMarshaler.Invoke(args_return, $.$ref(() => res, ($v) => res = $v, TResult));
                        return res;
                    }
                    static $h = 2019564;
                    static $g = 1;
                    static $f = 0b10000000011010000;
                    static $k = 1;
                    static $$md;
                    static get $md() { return this.$$md ??= {"b":131073,"m":[{"r":TResult?.$h??1507328,"n":"InvokeJS","d":this.$h,"h":Number(BigInt(this.$h)|0x400000000n),"f":1}],"l":[{"t":2281708,"n":"JSObject","d":this.$h,"h":Number(BigInt(this.$h)|0x100000000n),"f":2},{"t":$.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument.ArgumentToManagedCallback$$(TResult).$h,"n":"ResMarshaler","d":this.$h,"h":Number(BigInt(this.$h)|0x200000000n),"f":2}],"c":[{"p":[{"n":"holder","p":2281708},{"n":"resMarshaler","p":$.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument.ArgumentToManagedCallback$$(TResult).$h}],"n":".ctor","o":"$ctor$1","d":this.$h,"h":Number(BigInt(this.$h)|0x300000000n),"f":1}],"g":[TResult?.$h??1507328],"r":1,"d":1364204,"h":this.$h}; }
                    static get $b() { return $.$spc.System.Object; }
                    static get $fullName() { return `System.Runtime.InteropServices.JavaScript.JSMarshalerArgument.FuncJS<${TResult?.$fullName}>`; }
                }), $cls, ($v) => $cls.$_FuncJS$$ = $v))(TResult);
            }
            static $_FuncJS$$$;
            static FuncJS$$$(T, TResult)
            {
                let $cls = $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument;
                return ($cls.$_FuncJS$$$ ??= $asm.$ncls("$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument.FuncJS<,>", (T, TResult) => $asm.$gt("$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument.FuncJS<,>", [T, TResult], ($self) => class FuncJS$$$ extends $.$spc.System.Object
                {
                    /*ArgumentToJSCallback<T>*/ Arg1Marshaler = null;
                    /*ArgumentToManagedCallback<TResult>*/ ResMarshaler = null;
                    /*JSObject*/ JSObject = null;
                    $ctor$1(/*JSObject*/ holder, /*ArgumentToJSCallback<T>*/ arg1Marshaler, /*ArgumentToManagedCallback<TResult>*/ resMarshaler)
                    {
                        super.$ctor();
                        {
                            this.JSObject = holder;
                            this.Arg1Marshaler = arg1Marshaler;
                            this.ResMarshaler = resMarshaler;
                        }
                        return this;
                    }
                    /*TResult */ InvokeJS(/*T*/ arg1)
                    {
                        /*Span<JSMarshalerArgument>*/ let $arguments = $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.StackAllocSpan($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument, 3, null);
                        /*ref JSMarshalerArgument*/ let args_exception = $arguments.get_Item(0);
                        /*ref JSMarshalerArgument*/ let args_return = $arguments.get_Item(1);
                        /*ref JSMarshalerArgument*/ let args_arg1 = $arguments.get_Item(2);
                        args_exception.$v.Initialize();
                        args_return.$v.Initialize();
                        this.Arg1Marshaler.Invoke(args_arg1, arg1);
                        $.$srij.System.Runtime.InteropServices.JavaScript.JSFunctionBinding.InvokeJSFunction(this.JSObject, $arguments);
                        /*TResult*/ let res;
                        this.ResMarshaler.Invoke(args_return, $.$ref(() => res, ($v) => res = $v, TResult));
                        return res;
                    }
                    static $h = 1954028;
                    static $g = 2;
                    static $f = 0b10000000011010000;
                    static $k = 1;
                    static $$md;
                    static get $md() { return this.$$md ??= {"b":131073,"m":[{"r":TResult?.$h??1572864,"p":[{"n":"arg1","p":T?.$h??1507328}],"n":"InvokeJS","d":this.$h,"h":Number(BigInt(this.$h)|0x500000000n),"f":1}],"l":[{"t":$.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument.ArgumentToJSCallback$$(T).$h,"n":"Arg1Marshaler","d":this.$h,"h":Number(BigInt(this.$h)|0x100000000n),"f":2},{"t":$.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument.ArgumentToManagedCallback$$(TResult).$h,"n":"ResMarshaler","d":this.$h,"h":Number(BigInt(this.$h)|0x200000000n),"f":2},{"t":2281708,"n":"JSObject","d":this.$h,"h":Number(BigInt(this.$h)|0x300000000n),"f":2}],"c":[{"p":[{"n":"holder","p":2281708},{"n":"arg1Marshaler","p":$.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument.ArgumentToJSCallback$$(T).$h},{"n":"resMarshaler","p":$.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument.ArgumentToManagedCallback$$(TResult).$h}],"n":".ctor","o":"$ctor$1","d":this.$h,"h":Number(BigInt(this.$h)|0x400000000n),"f":1}],"g":[T?.$h??1507328,TResult?.$h??1572864],"r":2,"d":1364204,"h":this.$h}; }
                    static get $b() { return $.$spc.System.Object; }
                    static get $fullName() { return `System.Runtime.InteropServices.JavaScript.JSMarshalerArgument.FuncJS<${T?.$fullName},${TResult?.$fullName}>`; }
                }), $cls, ($v) => $cls.$_FuncJS$$$ = $v))(T, TResult);
            }
            static $_FuncJS$$$$;
            static FuncJS$$$$(T1, T2, TResult)
            {
                let $cls = $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument;
                return ($cls.$_FuncJS$$$$ ??= $asm.$ncls("$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument.FuncJS<,,>", (T1, T2, TResult) => $asm.$gt("$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument.FuncJS<,,>", [T1, T2, TResult], ($self) => class FuncJS$$$$ extends $.$spc.System.Object
                {
                    /*ArgumentToJSCallback<T1>*/ Arg1Marshaler = null;
                    /*ArgumentToJSCallback<T2>*/ Arg2Marshaler = null;
                    /*ArgumentToManagedCallback<TResult>*/ ResMarshaler = null;
                    /*JSObject*/ JSObject = null;
                    $ctor$1(/*JSObject*/ holder, /*ArgumentToJSCallback<T1>*/ arg1Marshaler, /*ArgumentToJSCallback<T2>*/ arg2Marshaler, /*ArgumentToManagedCallback<TResult>*/ resMarshaler)
                    {
                        super.$ctor();
                        {
                            this.JSObject = holder;
                            this.Arg1Marshaler = arg1Marshaler;
                            this.Arg2Marshaler = arg2Marshaler;
                            this.ResMarshaler = resMarshaler;
                        }
                        return this;
                    }
                    /*TResult */ InvokeJS(/*T1*/ arg1, /*T2*/ arg2)
                    {
                        /*Span<JSMarshalerArgument>*/ let $arguments = $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.StackAllocSpan($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument, 4, null);
                        /*ref JSMarshalerArgument*/ let args_exception = $arguments.get_Item(0);
                        /*ref JSMarshalerArgument*/ let args_return = $arguments.get_Item(1);
                        /*ref JSMarshalerArgument*/ let args_arg1 = $arguments.get_Item(2);
                        /*ref JSMarshalerArgument*/ let args_arg2 = $arguments.get_Item(3);
                        args_exception.$v.Initialize();
                        args_return.$v.Initialize();
                        this.Arg1Marshaler.Invoke(args_arg1, arg1);
                        this.Arg2Marshaler.Invoke(args_arg2, arg2);
                        $.$srij.System.Runtime.InteropServices.JavaScript.JSFunctionBinding.InvokeJSFunction(this.JSObject, $arguments);
                        /*TResult*/ let res;
                        this.ResMarshaler.Invoke(args_return, $.$ref(() => res, ($v) => res = $v, TResult));
                        return res;
                    }
                    static $h = 1888492;
                    static $g = 3;
                    static $f = 0b10000000011010000;
                    static $k = 1;
                    static $$md;
                    static get $md() { return this.$$md ??= {"b":131073,"m":[{"r":TResult?.$h??1638400,"p":[{"n":"arg1","p":T1?.$h??1507328},{"n":"arg2","p":T2?.$h??1572864}],"n":"InvokeJS","d":this.$h,"h":Number(BigInt(this.$h)|0x600000000n),"f":1}],"l":[{"t":$.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument.ArgumentToJSCallback$$(T1).$h,"n":"Arg1Marshaler","d":this.$h,"h":Number(BigInt(this.$h)|0x100000000n),"f":2},{"t":$.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument.ArgumentToJSCallback$$(T2).$h,"n":"Arg2Marshaler","d":this.$h,"h":Number(BigInt(this.$h)|0x200000000n),"f":2},{"t":$.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument.ArgumentToManagedCallback$$(TResult).$h,"n":"ResMarshaler","d":this.$h,"h":Number(BigInt(this.$h)|0x300000000n),"f":2},{"t":2281708,"n":"JSObject","d":this.$h,"h":Number(BigInt(this.$h)|0x400000000n),"f":2}],"c":[{"p":[{"n":"holder","p":2281708},{"n":"arg1Marshaler","p":$.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument.ArgumentToJSCallback$$(T1).$h},{"n":"arg2Marshaler","p":$.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument.ArgumentToJSCallback$$(T2).$h},{"n":"resMarshaler","p":$.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument.ArgumentToManagedCallback$$(TResult).$h}],"n":".ctor","o":"$ctor$1","d":this.$h,"h":Number(BigInt(this.$h)|0x500000000n),"f":1}],"g":[T1?.$h??1507328,T2?.$h??1572864,TResult?.$h??1638400],"r":3,"d":1364204,"h":this.$h}; }
                    static get $b() { return $.$spc.System.Object; }
                    static get $fullName() { return `System.Runtime.InteropServices.JavaScript.JSMarshalerArgument.FuncJS<${T1?.$fullName},${T2?.$fullName},${TResult?.$fullName}>`; }
                }), $cls, ($v) => $cls.$_FuncJS$$$$ = $v))(T1, T2, TResult);
            }
            static $_FuncJS$$$$$;
            static FuncJS$$$$$(T1, T2, T3, TResult)
            {
                let $cls = $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument;
                return ($cls.$_FuncJS$$$$$ ??= $asm.$ncls("$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument.FuncJS<,,,>", (T1, T2, T3, TResult) => $asm.$gt("$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument.FuncJS<,,,>", [T1, T2, T3, TResult], ($self) => class FuncJS$$$$$ extends $.$spc.System.Object
                {
                    /*ArgumentToJSCallback<T1>*/ Arg1Marshaler = null;
                    /*ArgumentToJSCallback<T2>*/ Arg2Marshaler = null;
                    /*ArgumentToJSCallback<T3>*/ Arg3Marshaler = null;
                    /*ArgumentToManagedCallback<TResult>*/ ResMarshaler = null;
                    /*JSObject*/ JSObject = null;
                    $ctor$1(/*JSObject*/ holder, /*ArgumentToJSCallback<T1>*/ arg1Marshaler, /*ArgumentToJSCallback<T2>*/ arg2Marshaler, /*ArgumentToJSCallback<T3>*/ arg3Marshaler, /*ArgumentToManagedCallback<TResult>*/ resMarshaler)
                    {
                        super.$ctor();
                        {
                            this.JSObject = holder;
                            this.Arg1Marshaler = arg1Marshaler;
                            this.Arg2Marshaler = arg2Marshaler;
                            this.Arg3Marshaler = arg3Marshaler;
                            this.ResMarshaler = resMarshaler;
                        }
                        return this;
                    }
                    /*TResult */ InvokeJS(/*T1*/ arg1, /*T2*/ arg2, /*T3*/ arg3)
                    {
                        /*Span<JSMarshalerArgument>*/ let $arguments = $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.StackAllocSpan($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument, 5, null);
                        /*ref JSMarshalerArgument*/ let args_exception = $arguments.get_Item(0);
                        /*ref JSMarshalerArgument*/ let args_return = $arguments.get_Item(1);
                        /*ref JSMarshalerArgument*/ let args_arg1 = $arguments.get_Item(2);
                        /*ref JSMarshalerArgument*/ let args_arg2 = $arguments.get_Item(3);
                        /*ref JSMarshalerArgument*/ let args_arg3 = $arguments.get_Item(4);
                        args_exception.$v.Initialize();
                        args_return.$v.Initialize();
                        this.Arg1Marshaler.Invoke(args_arg1, arg1);
                        this.Arg2Marshaler.Invoke(args_arg2, arg2);
                        this.Arg3Marshaler.Invoke(args_arg3, arg3);
                        $.$srij.System.Runtime.InteropServices.JavaScript.JSFunctionBinding.InvokeJSFunction(this.JSObject, $arguments);
                        /*TResult*/ let res;
                        this.ResMarshaler.Invoke(args_return, $.$ref(() => res, ($v) => res = $v, TResult));
                        return res;
                    }
                    static $h = 1822956;
                    static $g = 4;
                    static $f = 0b10000000011010000;
                    static $k = 1;
                    static $$md;
                    static get $md() { return this.$$md ??= {"b":131073,"m":[{"r":TResult?.$h??1703936,"p":[{"n":"arg1","p":T1?.$h??1507328},{"n":"arg2","p":T2?.$h??1572864},{"n":"arg3","p":T3?.$h??1638400}],"n":"InvokeJS","d":this.$h,"h":Number(BigInt(this.$h)|0x700000000n),"f":1}],"l":[{"t":$.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument.ArgumentToJSCallback$$(T1).$h,"n":"Arg1Marshaler","d":this.$h,"h":Number(BigInt(this.$h)|0x100000000n),"f":2},{"t":$.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument.ArgumentToJSCallback$$(T2).$h,"n":"Arg2Marshaler","d":this.$h,"h":Number(BigInt(this.$h)|0x200000000n),"f":2},{"t":$.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument.ArgumentToJSCallback$$(T3).$h,"n":"Arg3Marshaler","d":this.$h,"h":Number(BigInt(this.$h)|0x300000000n),"f":2},{"t":$.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument.ArgumentToManagedCallback$$(TResult).$h,"n":"ResMarshaler","d":this.$h,"h":Number(BigInt(this.$h)|0x400000000n),"f":2},{"t":2281708,"n":"JSObject","d":this.$h,"h":Number(BigInt(this.$h)|0x500000000n),"f":2}],"c":[{"p":[{"n":"holder","p":2281708},{"n":"arg1Marshaler","p":$.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument.ArgumentToJSCallback$$(T1).$h},{"n":"arg2Marshaler","p":$.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument.ArgumentToJSCallback$$(T2).$h},{"n":"arg3Marshaler","p":$.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument.ArgumentToJSCallback$$(T3).$h},{"n":"resMarshaler","p":$.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument.ArgumentToManagedCallback$$(TResult).$h}],"n":".ctor","o":"$ctor$1","d":this.$h,"h":Number(BigInt(this.$h)|0x600000000n),"f":1}],"g":[T1?.$h??1507328,T2?.$h??1572864,T3?.$h??1638400,TResult?.$h??1703936],"r":4,"d":1364204,"h":this.$h}; }
                    static get $b() { return $.$spc.System.Object; }
                    static get $fullName() { return `System.Runtime.InteropServices.JavaScript.JSMarshalerArgument.FuncJS<${T1?.$fullName},${T2?.$fullName},${T3?.$fullName},${TResult?.$fullName}>`; }
                }), $cls, ($v) => $cls.$_FuncJS$$$$$ = $v))(T1, T2, T3, TResult);
            }
            /*void */ ToManaged$41(TResult, /*out Func<TResult>?*/ value, /*ArgumentToManagedCallback<TResult>*/ resMarshaler)
            {
                if (this.slot.Type === 0/*MarshalerType.None*/)
                {
                    value.$v = null;
                    return;
                }
                /*var*/ let ctx = this.ToManagedContext;
                /*var*/ let holder = ctx.CreateCSOwnedProxy(this.slot.JSHandle);
                value.$v = new ($.$spc.System.Func$$(TResult))().$ctor(new ($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument.FuncJS$$(TResult))().$ctor$1(holder, resMarshaler), new ($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument.FuncJS$$(TResult))().$ctor$1(holder, resMarshaler).InvokeJS);
            }
            /*void */ ToManaged$42(T, TResult, /*out Func<T, TResult>?*/ value, /*ArgumentToJSCallback<T>*/ arg1Marshaler, /*ArgumentToManagedCallback<TResult>*/ resMarshaler)
            {
                if (this.slot.Type === 0/*MarshalerType.None*/)
                {
                    value.$v = null;
                    return;
                }
                /*var*/ let ctx = this.ToManagedContext;
                /*var*/ let holder = ctx.CreateCSOwnedProxy(this.slot.JSHandle);
                value.$v = new ($.$spc.System.Func$$$(T, TResult))().$ctor(new ($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument.FuncJS$$$(T, TResult))().$ctor$1(holder, arg1Marshaler, resMarshaler), new ($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument.FuncJS$$$(T, TResult))().$ctor$1(holder, arg1Marshaler, resMarshaler).InvokeJS);
            }
            /*void */ ToManaged$43(T1, T2, TResult, /*out Func<T1, T2, TResult>?*/ value, /*ArgumentToJSCallback<T1>*/ arg1Marshaler, /*ArgumentToJSCallback<T2>*/ arg2Marshaler, /*ArgumentToManagedCallback<TResult>*/ resMarshaler)
            {
                if (this.slot.Type === 0/*MarshalerType.None*/)
                {
                    value.$v = null;
                    return;
                }
                /*var*/ let ctx = this.ToManagedContext;
                /*var*/ let holder = ctx.CreateCSOwnedProxy(this.slot.JSHandle);
                value.$v = new ($.$spc.System.Func$$$$(T1, T2, TResult))().$ctor(new ($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument.FuncJS$$$$(T1, T2, TResult))().$ctor$1(holder, arg1Marshaler, arg2Marshaler, resMarshaler), new ($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument.FuncJS$$$$(T1, T2, TResult))().$ctor$1(holder, arg1Marshaler, arg2Marshaler, resMarshaler).InvokeJS);
            }
            /*void */ ToManaged$44(T1, T2, T3, TResult, /*out Func<T1, T2, T3, TResult>?*/ value, /*ArgumentToJSCallback<T1>*/ arg1Marshaler, /*ArgumentToJSCallback<T2>*/ arg2Marshaler, /*ArgumentToJSCallback<T3>*/ arg3Marshaler, /*ArgumentToManagedCallback<TResult>*/ resMarshaler)
            {
                if (this.slot.Type === 0/*MarshalerType.None*/)
                {
                    value.$v = null;
                    return;
                }
                /*var*/ let ctx = this.ToManagedContext;
                /*var*/ let holder = ctx.CreateCSOwnedProxy(this.slot.JSHandle);
                value.$v = new ($.$spc.System.Func$$$$$(T1, T2, T3, TResult))().$ctor(new ($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument.FuncJS$$$$$(T1, T2, T3, TResult))().$ctor$1(holder, arg1Marshaler, arg2Marshaler, arg3Marshaler, resMarshaler), new ($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument.FuncJS$$$$$(T1, T2, T3, TResult))().$ctor$1(holder, arg1Marshaler, arg2Marshaler, arg3Marshaler, resMarshaler).InvokeJS);
            }
            /*void */ ToJS$37(/*Action*/ value)
            {
                /*Action*/ let cpy = value;
                /*JSHostImplementation.ToManagedCallback*/ let cb = new $.$srij.System.Runtime.InteropServices.JavaScript.JSHostImplementation.ToManagedCallback().$ctor(this,  (/*JSMarshalerArgument**/ $arguments) =>
                {
                    cpy.Invoke();
                }, {"r":65537,"p":[{"n":"arguments","p":0}],"n":"","d":1364204,"h":0,"f":1048578});
                this.slot.Type = 25/*MarshalerType.Function*/;
                /*var*/ let ctx = this.ToJSContext;
                this.slot.GCHandle = ctx.GetJSOwnedObjectGCHandle(cb, 2);
            }
            /*void */ ToJS$38(T, /*Action<T>*/ value, /*ArgumentToManagedCallback<T>*/ arg1Marshaler)
            {
                /*Action<T>*/ let cpy = value;
                /*JSHostImplementation.ToManagedCallback*/ let cb = new $.$srij.System.Runtime.InteropServices.JavaScript.JSHostImplementation.ToManagedCallback().$ctor(this,  (/*JSMarshalerArgument**/ $arguments) =>
                {
                    /*ref JSMarshalerArgument*/ let arg2 = $arguments.Add(3);
                    /*T*/ let arg1cs;
                    arg1Marshaler.Invoke(arg2, $.$ref(() => arg1cs, ($v) => arg1cs = $v, T));
                    cpy.Invoke(arg1cs);
                }, {"r":65537,"p":[{"n":"arguments","p":0}],"n":"","d":1364204,"h":0,"f":1048578});
                this.slot.Type = 24/*MarshalerType.Action*/;
                /*var*/ let ctx = this.ToJSContext;
                this.slot.GCHandle = ctx.GetJSOwnedObjectGCHandle(cb, 2);
            }
            /*void */ ToJS$39(T1, T2, /*Action<T1, T2>*/ value, /*ArgumentToManagedCallback<T1>*/ arg1Marshaler, /*ArgumentToManagedCallback<T2>*/ arg2Marshaler)
            {
                /*Action<T1, T2>*/ let cpy = value;
                /*JSHostImplementation.ToManagedCallback*/ let cb = new $.$srij.System.Runtime.InteropServices.JavaScript.JSHostImplementation.ToManagedCallback().$ctor(this,  (/*JSMarshalerArgument**/ $arguments) =>
                {
                    /*ref JSMarshalerArgument*/ let arg2 = $arguments.Add(3);
                    /*ref JSMarshalerArgument*/ let arg3 = $arguments.Add(4);
                    /*T1*/ let arg1cs;
                    arg1Marshaler.Invoke(arg2, $.$ref(() => arg1cs, ($v) => arg1cs = $v, T1));
                    /*T2*/ let arg2cs;
                    arg2Marshaler.Invoke(arg3, $.$ref(() => arg2cs, ($v) => arg2cs = $v, T2));
                    cpy.Invoke(arg1cs, arg2cs);
                }, {"r":65537,"p":[{"n":"arguments","p":0}],"n":"","d":1364204,"h":0,"f":1048578});
                this.slot.Type = 24/*MarshalerType.Action*/;
                /*var*/ let ctx = this.ToJSContext;
                this.slot.GCHandle = ctx.GetJSOwnedObjectGCHandle(cb, 2);
            }
            /*void */ ToJS$40(T1, T2, T3, /*Action<T1, T2, T3>*/ value, /*ArgumentToManagedCallback<T1>*/ arg1Marshaler, /*ArgumentToManagedCallback<T2>*/ arg2Marshaler, /*ArgumentToManagedCallback<T3>*/ arg3Marshaler)
            {
                /*Action<T1, T2, T3>*/ let cpy = value;
                /*JSHostImplementation.ToManagedCallback*/ let cb = new $.$srij.System.Runtime.InteropServices.JavaScript.JSHostImplementation.ToManagedCallback().$ctor(this,  (/*JSMarshalerArgument**/ $arguments) =>
                {
                    /*ref JSMarshalerArgument*/ let arg2 = $arguments.Add(3);
                    /*ref JSMarshalerArgument*/ let arg3 = $arguments.Add(4);
                    /*ref JSMarshalerArgument*/ let arg4 = $arguments.Add(5);
                    /*T1*/ let arg1cs;
                    arg1Marshaler.Invoke(arg2, $.$ref(() => arg1cs, ($v) => arg1cs = $v, T1));
                    /*T2*/ let arg2cs;
                    arg2Marshaler.Invoke(arg3, $.$ref(() => arg2cs, ($v) => arg2cs = $v, T2));
                    /*T3*/ let arg3cs;
                    arg3Marshaler.Invoke(arg4, $.$ref(() => arg3cs, ($v) => arg3cs = $v, T3));
                    cpy.Invoke(arg1cs, arg2cs, arg3cs);
                }, {"r":65537,"p":[{"n":"arguments","p":0}],"n":"","d":1364204,"h":0,"f":1048578});
                this.slot.Type = 24/*MarshalerType.Action*/;
                /*var*/ let ctx = this.ToJSContext;
                this.slot.GCHandle = ctx.GetJSOwnedObjectGCHandle(cb, 2);
            }
            /*void */ ToJS$41(TResult, /*Func<TResult>*/ value, /*ArgumentToJSCallback<TResult>*/ resMarshaler)
            {
                /*Func<TResult>*/ let cpy = value;
                /*JSHostImplementation.ToManagedCallback*/ let cb = new $.$srij.System.Runtime.InteropServices.JavaScript.JSHostImplementation.ToManagedCallback().$ctor(this,  (/*JSMarshalerArgument**/ $arguments) =>
                {
                    /*ref JSMarshalerArgument*/ let res = $arguments.Add(1);
                    /*TResult*/ let resCs = cpy.Invoke();
                    resMarshaler.Invoke(res, resCs);
                }, {"r":65537,"p":[{"n":"arguments","p":0}],"n":"","d":1364204,"h":0,"f":1048578});
                this.slot.Type = 25/*MarshalerType.Function*/;
                /*var*/ let ctx = this.ToJSContext;
                this.slot.GCHandle = ctx.GetJSOwnedObjectGCHandle(cb, 2);
            }
            /*void */ ToJS$42(T, TResult, /*Func<T, TResult>*/ value, /*ArgumentToManagedCallback<T>*/ arg1Marshaler, /*ArgumentToJSCallback<TResult>*/ resMarshaler)
            {
                /*Func<T, TResult>*/ let cpy = value;
                /*JSHostImplementation.ToManagedCallback*/ let cb = new $.$srij.System.Runtime.InteropServices.JavaScript.JSHostImplementation.ToManagedCallback().$ctor(this,  (/*JSMarshalerArgument**/ $arguments) =>
                {
                    /*ref JSMarshalerArgument*/ let res = $arguments.Add(1);
                    /*ref JSMarshalerArgument*/ let arg2 = $arguments.Add(3);
                    /*T*/ let arg1cs;
                    arg1Marshaler.Invoke(arg2, $.$ref(() => arg1cs, ($v) => arg1cs = $v, T));
                    /*TResult*/ let resCs = cpy.Invoke(arg1cs);
                    resMarshaler.Invoke(res, resCs);
                }, {"r":65537,"p":[{"n":"arguments","p":0}],"n":"","d":1364204,"h":0,"f":1048578});
                this.slot.Type = 25/*MarshalerType.Function*/;
                /*var*/ let ctx = this.ToJSContext;
                this.slot.GCHandle = ctx.GetJSOwnedObjectGCHandle(cb, 2);
            }
            /*void */ ToJS$43(T1, T2, TResult, /*Func<T1, T2, TResult>*/ value, /*ArgumentToManagedCallback<T1>*/ arg1Marshaler, /*ArgumentToManagedCallback<T2>*/ arg2Marshaler, /*ArgumentToJSCallback<TResult>*/ resMarshaler)
            {
                /*Func<T1, T2, TResult>*/ let cpy = value;
                /*JSHostImplementation.ToManagedCallback*/ let cb = new $.$srij.System.Runtime.InteropServices.JavaScript.JSHostImplementation.ToManagedCallback().$ctor(this,  (/*JSMarshalerArgument**/ $arguments) =>
                {
                    /*ref JSMarshalerArgument*/ let res = $arguments.Add(1);
                    /*ref JSMarshalerArgument*/ let arg2 = $arguments.Add(3);
                    /*ref JSMarshalerArgument*/ let arg3 = $arguments.Add(4);
                    /*T1*/ let arg1cs;
                    arg1Marshaler.Invoke(arg2, $.$ref(() => arg1cs, ($v) => arg1cs = $v, T1));
                    /*T2*/ let arg2cs;
                    arg2Marshaler.Invoke(arg3, $.$ref(() => arg2cs, ($v) => arg2cs = $v, T2));
                    /*TResult*/ let resCs = cpy.Invoke(arg1cs, arg2cs);
                    resMarshaler.Invoke(res, resCs);
                }, {"r":65537,"p":[{"n":"arguments","p":0}],"n":"","d":1364204,"h":0,"f":1048578});
                this.slot.Type = 25/*MarshalerType.Function*/;
                /*var*/ let ctx = this.ToJSContext;
                this.slot.GCHandle = ctx.GetJSOwnedObjectGCHandle(cb, 2);
            }
            /*void */ ToJS$44(T1, T2, T3, TResult, /*Func<T1, T2, T3, TResult>*/ value, /*ArgumentToManagedCallback<T1>*/ arg1Marshaler, /*ArgumentToManagedCallback<T2>*/ arg2Marshaler, /*ArgumentToManagedCallback<T3>*/ arg3Marshaler, /*ArgumentToJSCallback<TResult>*/ resMarshaler)
            {
                /*Func<T1, T2, T3, TResult>*/ let cpy = value;
                /*JSHostImplementation.ToManagedCallback*/ let cb = new $.$srij.System.Runtime.InteropServices.JavaScript.JSHostImplementation.ToManagedCallback().$ctor(this,  (/*JSMarshalerArgument**/ $arguments) =>
                {
                    /*ref JSMarshalerArgument*/ let res = $arguments.Add(1);
                    /*ref JSMarshalerArgument*/ let arg2 = $arguments.Add(3);
                    /*ref JSMarshalerArgument*/ let arg3 = $arguments.Add(4);
                    /*ref JSMarshalerArgument*/ let arg4 = $arguments.Add(5);
                    /*T1*/ let arg1cs;
                    arg1Marshaler.Invoke(arg2, $.$ref(() => arg1cs, ($v) => arg1cs = $v, T1));
                    /*T2*/ let arg2cs;
                    arg2Marshaler.Invoke(arg3, $.$ref(() => arg2cs, ($v) => arg2cs = $v, T2));
                    /*T3*/ let arg3cs;
                    arg3Marshaler.Invoke(arg4, $.$ref(() => arg3cs, ($v) => arg3cs = $v, T3));
                    /*TResult*/ let resCs = cpy.Invoke(arg1cs, arg2cs, arg3cs);
                    resMarshaler.Invoke(res, resCs);
                }, {"r":65537,"p":[{"n":"arguments","p":0}],"n":"","d":1364204,"h":0,"f":1048578});
                this.slot.Type = 25/*MarshalerType.Function*/;
                /*var*/ let ctx = this.ToJSContext;
                this.slot.GCHandle = ctx.GetJSOwnedObjectGCHandle(cb, 2);
            }
            static $_ArgumentToManagedCallback$$;
            static ArgumentToManagedCallback$$(T)
            {
                let $cls = $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument;
                return ($cls.$_ArgumentToManagedCallback$$ ??= $asm.$ncls("$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument.ArgumentToManagedCallback<>", (T) => $asm.$gt("$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument.ArgumentToManagedCallback<>", [T], ($self) => class ArgumentToManagedCallback$$ extends $.$spc.System.MulticastDelegate
                {
                    $ctor(/*object*/ target, fn, anmodel)
                    {
                        this.$target = target;
                        this.$nativeFunction = fn;
                        if (anmodel) this.$nfmodel = anmodel;
                        if (typeof(target) === 'object') this._target = target;
                        return this;
                    }
                    /*void*/ Invoke(/**/ arg, /**/ value)
                    {
                        return this.$nativeFunction.call(this.$target, arg, value);
                    }
                    static $h = 1757420;
                    static $g = 1;
                    static $f = 0b10000000011000001;
                    static $k = 5;
                    static $$md;
                    static get $md() { return this.$$md ??= {"b":66191361,"m":[{"r":65537,"p":[{"n":"arg","p":1364204,"f":4},{"n":"value","p":T?.$h??1507328,"f":2}],"n":"Invoke","d":this.$h,"h":Number(BigInt(this.$h)|0x200000000n),"f":129},{"r":57016321,"p":[{"n":"arg","p":1364204,"f":4},{"n":"value","p":T?.$h??1507328,"f":2},{"n":"callback","p":14483457},{"n":"object","p":131073}],"n":"BeginInvoke","d":this.$h,"h":Number(BigInt(this.$h)|0x300000000n),"f":129},{"r":65537,"p":[{"n":"arg","p":1364204,"f":4},{"n":"value","p":T?.$h??1507328,"f":2},{"n":"result","p":57016321}],"n":"EndInvoke","d":this.$h,"h":Number(BigInt(this.$h)|0x400000000n),"f":129}],"c":[{"p":[{"n":"object","p":131073},{"n":"method","p":786433}],"n":".ctor","o":"$ctor$5","d":this.$h,"h":Number(BigInt(this.$h)|0x100000000n),"f":1}],"i":[57212929,113377281],"g":[T?.$h??1507328],"r":1,"d":1364204,"h":this.$h,"a":[{"t":33226753,"c":4328194049,"a":[{"v":1,"t":33292289}]}]}; }
                    static get $b() { return $.$spc.System.MulticastDelegate; }
                    static $$i;
                    static get $i() { return this.$$i ??= [ $.$spc.System.ICloneable, $.$spc.System.Runtime.Serialization.ISerializable ]; }
                    static get $fullName() { return `System.Runtime.InteropServices.JavaScript.JSMarshalerArgument.ArgumentToManagedCallback<${T?.$fullName}>`; }
                }), $cls, ($v) => $cls.$_ArgumentToManagedCallback$$ = $v))(T);
            }
            static $_ArgumentToJSCallback$$;
            static ArgumentToJSCallback$$(T)
            {
                let $cls = $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument;
                return ($cls.$_ArgumentToJSCallback$$ ??= $asm.$ncls("$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument.ArgumentToJSCallback<>", (T) => $asm.$gt("$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument.ArgumentToJSCallback<>", [T], ($self) => class ArgumentToJSCallback$$ extends $.$spc.System.MulticastDelegate
                {
                    $ctor(/*object*/ target, fn, anmodel)
                    {
                        this.$target = target;
                        this.$nativeFunction = fn;
                        if (anmodel) this.$nfmodel = anmodel;
                        if (typeof(target) === 'object') this._target = target;
                        return this;
                    }
                    /*void*/ Invoke(/**/ arg, /**/ value)
                    {
                        return this.$nativeFunction.call(this.$target, arg, value);
                    }
                    static $h = 1691884;
                    static $g = 1;
                    static $f = 0b10000000011000001;
                    static $k = 5;
                    static $$md;
                    static get $md() { return this.$$md ??= {"b":66191361,"m":[{"r":65537,"p":[{"n":"arg","p":1364204,"f":4},{"n":"value","p":T?.$h??1507328}],"n":"Invoke","d":this.$h,"h":Number(BigInt(this.$h)|0x200000000n),"f":129},{"r":57016321,"p":[{"n":"arg","p":1364204,"f":4},{"n":"value","p":T?.$h??1507328},{"n":"callback","p":14483457},{"n":"object","p":131073}],"n":"BeginInvoke","d":this.$h,"h":Number(BigInt(this.$h)|0x300000000n),"f":129},{"r":65537,"p":[{"n":"arg","p":1364204,"f":4},{"n":"result","p":57016321}],"n":"EndInvoke","d":this.$h,"h":Number(BigInt(this.$h)|0x400000000n),"f":129}],"c":[{"p":[{"n":"object","p":131073},{"n":"method","p":786433}],"n":".ctor","o":"$ctor$5","d":this.$h,"h":Number(BigInt(this.$h)|0x100000000n),"f":1}],"i":[57212929,113377281],"g":[T?.$h??1507328],"r":1,"d":1364204,"h":this.$h,"a":[{"t":33226753,"c":4328194049,"a":[{"v":1,"t":33292289}]}]}; }
                    static get $b() { return $.$spc.System.MulticastDelegate; }
                    static $$i;
                    static get $i() { return this.$$i ??= [ $.$spc.System.ICloneable, $.$spc.System.Runtime.Serialization.ISerializable ]; }
                    static get $fullName() { return `System.Runtime.InteropServices.JavaScript.JSMarshalerArgument.ArgumentToJSCallback<${T?.$fullName}>`; }
                }), $cls, ($v) => $cls.$_ArgumentToJSCallback$$ = $v))(T);
            }
            /*void */ ToManaged$45(/*out Task?*/ value)
            {
                if (this.slot.Type === 0/*MarshalerType.None*/)
                {
                    value.$v = null;
                    return;
                }
                /*var*/ let ctx = this.ToManagedContext;
                {
                    /*PromiseHolder*/ let holder = ctx.GetPromiseHolder(this.slot.GCHandle);
                    /*TaskCompletionSource*/ let tcs = new $.$spc.System.Threading.Tasks.TaskCompletionSource().$ctor$4(holder, 64/*TaskCreationOptions.RunContinuationsAsynchronously*/);
                    /*ToManagedCallback*/ let callback = new $.$srij.System.Runtime.InteropServices.JavaScript.JSHostImplementation.ToManagedCallback().$ctor(this,  (/*JSMarshalerArgument**/ arguments_buffer) =>
                    {
                        if (arguments_buffer === null)
                        {
                            if (!tcs.TrySetException(new $.$spc.System.Threading.Tasks.TaskCanceledException().$ctor$17("WebWorker which is origin of the Promise is being terminated.")))
                            {
                                $.$spc.System.Environment.FailFast("Failed to set exception to TaskCompletionSource (arguments buffer is null)");
                            }
                            return;
                        }
                        /*ref JSMarshalerArgument*/ let arg_2 = arguments_buffer.Add(3);
                        if (arg_2.$v.slot.Type !== 0/*MarshalerType.None*/)
                        {
                            /*Exception?*/ let fail;
                            arg_2.$v.ToManaged$36($.$ref(() => fail, ($v) => fail = $v, $.$spc.System.Exception));
                            if (!tcs.TrySetException(fail))
                            {
                                $.$spc.System.Environment.FailFast("Failed to set exception to TaskCompletionSource (exception raised)");
                            }
                        }
                        else 
                        {
                            if (!tcs.TrySetResult())
                            {
                                $.$spc.System.Environment.FailFast("Failed to set result to TaskCompletionSource (marshaler type is none)");
                            }
                        }
                    }, {"r":65537,"p":[{"n":"arguments_buffer","p":0}],"n":"","d":1364204,"h":0,"f":1048578});
                    holder.Callback = callback;
                    value.$v = tcs.Task;
                }
            }
            /*void */ ToManaged$46(T, /*out Task<T>?*/ value, /*ArgumentToManagedCallback<T>*/ marshaler)
            {
                if (this.slot.Type === 0/*MarshalerType.None*/)
                {
                    value.$v = null;
                    return;
                }
                /*var*/ let ctx = this.ToManagedContext;
                {
                    /*var*/ let holder = ctx.GetPromiseHolder(this.slot.GCHandle);
                    /*TaskCompletionSource<T>*/ let tcs = new ($.$spc.System.Threading.Tasks.TaskCompletionSource$$(T))().$ctor$4(holder, 64/*TaskCreationOptions.RunContinuationsAsynchronously*/);
                    /*ToManagedCallback*/ let callback = new $.$srij.System.Runtime.InteropServices.JavaScript.JSHostImplementation.ToManagedCallback().$ctor(this,  (/*JSMarshalerArgument**/ arguments_buffer) =>
                    {
                        if (arguments_buffer === null)
                        {
                            if (!tcs.TrySetException(new $.$spc.System.Threading.Tasks.TaskCanceledException().$ctor$17("WebWorker which is origin of the Promise is being terminated.")))
                            {
                                $.$spc.System.Environment.FailFast("Failed to set exception to TaskCompletionSource (arguments buffer is null)");
                            }
                            return;
                        }
                        /*ref JSMarshalerArgument*/ let arg_2 = arguments_buffer.Add(3);
                        /*ref JSMarshalerArgument*/ let arg_3 = arguments_buffer.Add(4);
                        if (arg_2.$v.slot.Type !== 0/*MarshalerType.None*/)
                        {
                            /*Exception?*/ let fail;
                            arg_2.$v.ToManaged$36($.$ref(() => fail, ($v) => fail = $v, $.$spc.System.Exception));
                            if (fail === null)
                            {
                                throw new $.$spc.System.InvalidOperationException().$ctor$10($.$srij.System.SR.FailedToMarshalException);
                            }
                            if (!tcs.TrySetException(fail))
                            {
                                $.$spc.System.Environment.FailFast("Failed to set exception to TaskCompletionSource (exception raised)");
                            }
                        }
                        else 
                        {
                            /*T*/ let result;
                            marshaler.Invoke(arg_3, $.$ref(() => result, ($v) => result = $v, T));
                            if (!tcs.TrySetResult(result))
                            {
                                $.$spc.System.Environment.FailFast("Failed to set result to TaskCompletionSource (marshaler type is none)");
                            }
                        }
                    }, {"r":65537,"p":[{"n":"arguments_buffer","p":0}],"n":"","d":1364204,"h":0,"f":1048578});
                    holder.Callback = callback;
                    value.$v = tcs.Task;
                }
            }
            /*void */ ToJSDynamic(/*Task?*/ value)
            {
                /*Task?*/ let task = value;
                /*var*/ let ctx = this.ToJSContext;
                /*var*/ let canMarshalTaskResultOnSameCall = this.CanMarshalTaskResultOnSameCall(ctx);
                if (task === null)
                {
                    if (!canMarshalTaskResultOnSameCall)
                    {
                        $.$spc.System.Environment.FailFast("Marshalling null return Task to JS is not supported in MT");
                    }
                    this.slot.Type = 0/*MarshalerType.None*/;
                    return;
                }
                if (canMarshalTaskResultOnSameCall && task.IsCompleted)
                {
                    if (task.Exception !== null)
                    {
                        /*Exception*/ let ex = task.Exception;
                        this.ToJS$36(ex);
                        this.slot.ElementType = this.slot.Type;
                        this.slot.Type = 29/*MarshalerType.TaskRejected*/;
                        return;
                    }
                    else 
                    {
                        /*object?*/ let result;
                        if ($.$srij.System.Runtime.InteropServices.JavaScript.JSHostImplementation.GetTaskResultDynamic(task, $.$ref(() => result, ($v) => result = $v, $.$spc.System.Object)))
                        {
                            this.ToJS$47(result);
                            this.slot.ElementType = this.slot.Type;
                        }
                        else 
                        {
                            this.slot.ElementType = 1/*MarshalerType.Void*/;
                        }
                        this.slot.Type = 28/*MarshalerType.TaskResolved*/;
                        return;
                    }
                }
                if (this.slot.Type !== 30/*MarshalerType.TaskPreCreated*/)
                {
                    this.slot.JSHandle = ctx.AllocJSVHandle();
                    this.slot.Type = 20/*MarshalerType.Task*/;
                }
                else 
                {
                }
                /*var*/ let taskHolder = ctx.CreateCSOwnedProxy(this.slot.JSHandle);
                task.ContinueWith$8(new ($.$spc.System.Action$$$($.$spc.System.Threading.Tasks.Task, $.$spc.System.Object))().$ctor($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument, Complete), taskHolder, $.$spc.System.Threading.Tasks.TaskScheduler.Current);
                /*static void*/  function Complete(/*Task*/ task, /*object?*/ th)
                {
                    /*var*/ let taskHolderArg = $.$cast(th, $.$srij.System.Runtime.InteropServices.JavaScript.JSObject);
                    if (task.Exception !== null)
                    {
                        $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument.RejectPromise(taskHolderArg, task.Exception);
                    }
                    else 
                    {
                        /*object?*/ let result;
                        if ($.$srij.System.Runtime.InteropServices.JavaScript.JSHostImplementation.GetTaskResultDynamic(task, $.$ref(() => result, ($v) => result = $v, $.$spc.System.Object)))
                        {
                            $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument.ResolvePromise($.$spc.System.Object, taskHolderArg, result, new ($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument.ArgumentToJSCallback$$($.$spc.System.Object))().$ctor($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument, MarshalResult));
                        }
                        else 
                        {
                            $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument.ResolveVoidPromise(taskHolderArg);
                        }
                    }
                }
                /*static void*/  function MarshalResult(/*ref JSMarshalerArgument*/ arg, /*object?*/ taskResult)
                {
                    arg.$v.ToJS$47(taskResult);
                }
            }
            /*void */ ToJS$45(/*Task?*/ value)
            {
                /*Task?*/ let task = value;
                /*var*/ let ctx = this.ToJSContext;
                /*var*/ let canMarshalTaskResultOnSameCall = this.CanMarshalTaskResultOnSameCall(ctx);
                if (task === null)
                {
                    if (!canMarshalTaskResultOnSameCall)
                    {
                        $.$spc.System.Environment.FailFast("Marshalling null return Task to JS is not supported in MT");
                    }
                    this.slot.Type = 0/*MarshalerType.None*/;
                    return;
                }
                if (canMarshalTaskResultOnSameCall && task.IsCompleted)
                {
                    if (task.Exception !== null)
                    {
                        /*Exception*/ let ex = task.Exception;
                        this.ToJS$36(ex);
                        this.slot.ElementType = this.slot.Type;
                        this.slot.Type = 29/*MarshalerType.TaskRejected*/;
                        return;
                    }
                    else 
                    {
                        this.slot.ElementType = 1/*MarshalerType.Void*/;
                        this.slot.Type = 28/*MarshalerType.TaskResolved*/;
                        return;
                    }
                }
                if (this.slot.Type !== 30/*MarshalerType.TaskPreCreated*/)
                {
                    this.slot.JSHandle = ctx.AllocJSVHandle();
                    this.slot.Type = 20/*MarshalerType.Task*/;
                }
                else 
                {
                }
                /*var*/ let taskHolder = ctx.CreateCSOwnedProxy(this.slot.JSHandle);
                task.ContinueWith$8(new ($.$spc.System.Action$$$($.$spc.System.Threading.Tasks.Task, $.$spc.System.Object))().$ctor($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument, Complete), taskHolder, $.$spc.System.Threading.Tasks.TaskScheduler.Current);
                /*static void*/  function Complete(/*Task*/ task, /*object?*/ th)
                {
                    /*JSObject*/ let taskHolderArg = $.$cast(th, $.$srij.System.Runtime.InteropServices.JavaScript.JSObject);
                    if (task.Exception !== null)
                    {
                        $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument.RejectPromise(taskHolderArg, task.Exception);
                    }
                    else 
                    {
                        $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument.ResolveVoidPromise(taskHolderArg);
                    }
                }
            }
            /*void */ ToJS$46(T, /*Task<T>?*/ value, /*ArgumentToJSCallback<T>*/ marshaler)
            {
                /*Task<T>?*/ let task = value;
                /*var*/ let ctx = this.ToJSContext;
                /*var*/ let canMarshalTaskResultOnSameCall = this.CanMarshalTaskResultOnSameCall(ctx);
                if (task === null)
                {
                    if (!canMarshalTaskResultOnSameCall)
                    {
                        $.$spc.System.Environment.FailFast("Marshalling null return Task to JS is not supported in MT");
                    }
                    this.slot.Type = 0/*MarshalerType.None*/;
                    return;
                }
                if (canMarshalTaskResultOnSameCall && task.IsCompleted)
                {
                    if (task.Exception !== null)
                    {
                        /*Exception*/ let ex = task.Exception;
                        this.ToJS$36(ex);
                        this.slot.ElementType = this.slot.Type;
                        this.slot.Type = 29/*MarshalerType.TaskRejected*/;
                        return;
                    }
                    else 
                    {
                        /*T*/ let result = task.Result;
                        this.ToJS$47($.$box(result, T));
                        this.slot.ElementType = this.slot.Type;
                        this.slot.Type = 28/*MarshalerType.TaskResolved*/;
                        return;
                    }
                }
                if (this.slot.Type !== 30/*MarshalerType.TaskPreCreated*/)
                {
                    this.slot.JSHandle = ctx.AllocJSVHandle();
                    this.slot.Type = 20/*MarshalerType.Task*/;
                }
                else 
                {
                }
                /*var*/ let taskHolder = ctx.CreateCSOwnedProxy(this.slot.JSHandle);
                task.ContinueWith$32(new ($.$spc.System.Action$$$($.$spc.System.Threading.Tasks.Task$$(T), $.$spc.System.Object))().$ctor($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument, Complete), new ($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument.HolderAndMarshaler$$(T))().$ctor$1(taskHolder, marshaler), $.$spc.System.Threading.Tasks.TaskScheduler.Current);
                /*static void*/  function Complete(/*Task<T>*/ task, /*object?*/ thm)
                {
                    /*var*/ let hm = $.$cast(thm, $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument.HolderAndMarshaler$$(T));
                    if (task.Exception !== null)
                    {
                        $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument.RejectPromise(hm.TaskHolder, task.Exception);
                    }
                    else 
                    {
                        /*T*/ let result = task.Result;
                        $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument.ResolvePromise(T, hm.TaskHolder, result, hm.Marshaler);
                    }
                }
            }
            /*bool */ CanMarshalTaskResultOnSameCall(/*JSProxyContext*/ _)
            {
                return true;
            }
            static $_HolderAndMarshaler$$;
            static HolderAndMarshaler$$(T)
            {
                let $cls = $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument;
                return ($cls.$_HolderAndMarshaler$$ ??= $asm.$ncls("$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument.HolderAndMarshaler<>", (T) => $asm.$gt("$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument.HolderAndMarshaler<>", [T], ($self) => class HolderAndMarshaler$$ extends $.$spc.System.Object
                {
                    //Generated interface implemetation for System.IEquatable<System.Runtime.InteropServices.JavaScript.JSMarshalerArgument.HolderAndMarshaler<T>>.Equals(System.Runtime.InteropServices.JavaScript.JSMarshalerArgument.HolderAndMarshaler<T>?)
                    System$IEquatable$$$Equals()
                    {
                        return this.Equals$2(...arguments);
                    }
                    Clone($copy)
                    {
                        let copy = $copy ?? new this.constructor();
                        copy.TaskHolder = this.TaskHolder;
                        copy.Marshaler = this.Marshaler;
                        return copy;
                    }
                    //Begin primary constructor
                    /*JSObject*/ TaskHolder = null;
                    /*ArgumentToJSCallback<T>*/ Marshaler = null;
                    $ctor$1(/*JSObject*/$TaskHolder, /*ArgumentToJSCallback<T>*/$Marshaler)
                    {
                        this.TaskHolder = $TaskHolder;
                        this.Marshaler = $Marshaler;
                        return this
                    }
                    //End primary constructor
                    //Begin generated record members
                    /*Type*/ get EqualityContract() { return $.$typeOf($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument.HolderAndMarshaler$$(T)); }
                    /*string*/ ToString()
                    {
                        let stringBuilder = new $.$spc.System.Text.StringBuilder().$ctor$1();
                        stringBuilder.Append$2("HolderAndMarshaler");
                        stringBuilder.Append$2("{");
                        if (this.PrintMembers(stringBuilder))
                        {
                            stringBuilder.Append$2(" ");
                        }
                        stringBuilder.Append$2("}");
                        return $.$spc.System.Text.StringBuilder.ToString.call(stringBuilder);
                    }
                    /*bool*/ PrintMembers(/*StringBuilder*/ stringBuilder)
                    {
                        stringBuilder.Append$2("TaskHolder = ");
                        stringBuilder.Append$2($.$srij.System.Runtime.InteropServices.JavaScript.JSObject.ToString.call(this.TaskHolder));
                        stringBuilder.Append$2(", ");
                        stringBuilder.Append$2("Marshaler = ");
                        stringBuilder.Append$2($.$spc.System.Object.ToString.call(this.Marshaler));
                        return true;
                    }
                    /*bool*/ Equals$2(/*HolderAndMarshaler*/ other)
                    {
                        return this === other || (other !== null && this.EqualityContract == other.EqualityContract && $.$spc.System.Collections.Generic.EqualityComparer$$($.$srij.System.Runtime.InteropServices.JavaScript.JSObject).Default.Equals$2(this.TaskHolder, other.TaskHolder) && $.$spc.System.Collections.Generic.EqualityComparer$$($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument.ArgumentToJSCallback$$(T)).Default.Equals$2(this.Marshaler, other.Marshaler));
                    }
                    /*int*/ GetHashCode()
                    {
                        return $.$spc.System.Collections.Generic.EqualityComparer$$($.$spc.System.Type).Default.GetHashCode$1(this.EqualityContract) * -1521134295 && $.$spc.System.Collections.Generic.EqualityComparer$$($.$srij.System.Runtime.InteropServices.JavaScript.JSObject).Default.GetHashCode$1(this.TaskHolder) * -1521134295 && $.$spc.System.Collections.Generic.EqualityComparer$$($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument.ArgumentToJSCallback$$(T)).Default.GetHashCode$1(this.Marshaler) * -1521134295;
                    }
                    static /*bool*/ op_InEquality(/*HolderAndMarshaler*/ left, /*HolderAndMarshaler*/ right)
                    {
                        return !(this.op_Equals(left, right));
                    }
                    static /*bool*/ op_Equality(/*HolderAndMarshaler*/ left, /*HolderAndMarshaler*/ right)
                    {
                        return left === right || (left !== null && left.Equals$2(right));
                    }
                    Deconstruct(/*out System.Runtime.InteropServices.JavaScript.JSObject*/ $TaskHolder, /*out System.Runtime.InteropServices.JavaScript.JSMarshalerArgument.ArgumentToJSCallback<T>*/ $Marshaler)
                    {
                        $TaskHolder.$v = this.TaskHolder;
                        $Marshaler.$v = this.Marshaler;
                    }
                    //End generated record member3s
                    static $h = 2085100;
                    static $g = 1;
                    static $f = 0b10000000011010000;
                    static $k = 1;
                    static $$md;
                    static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":142606337,"g":{"r":0,"d":0,"h":Number(BigInt(this.$h)|0x200000000n),"f":2},"n":"EqualityContract","d":this.$h,"h":Number(BigInt(this.$h)|0x300000000n),"f":2},{"p":2281708,"g":{"r":0,"d":0,"h":Number(BigInt(this.$h)|0x500000000n),"f":1},"s":{"r":0,"d":0,"h":Number(BigInt(this.$h)|0x600000000n),"f":1},"n":"TaskHolder","d":this.$h,"h":Number(BigInt(this.$h)|0x700000000n),"f":1},{"p":$.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument.ArgumentToJSCallback$$(T).$h,"g":{"r":0,"d":0,"h":Number(BigInt(this.$h)|0x900000000n),"f":1},"s":{"r":0,"d":0,"h":Number(BigInt(this.$h)|0xA00000000n),"f":1},"n":"Marshaler","d":this.$h,"h":Number(BigInt(this.$h)|0xB00000000n),"f":1}],"m":[{"r":1310721,"n":"ToString","d":this.$h,"h":Number(BigInt(this.$h)|0xC00000000n),"f":32769},{"r":262145,"p":[{"n":"builder","p":122945537}],"n":"PrintMembers","d":this.$h,"h":Number(BigInt(this.$h)|0xD00000000n),"f":2},{"r":655361,"n":"GetHashCode","d":this.$h,"h":Number(BigInt(this.$h)|0x1000000000n),"f":32769},{"r":262145,"p":[{"n":"obj","p":131073}],"n":"Equals","d":this.$h,"h":Number(BigInt(this.$h)|0x1100000000n),"f":32769},{"r":262145,"p":[{"n":"other","p":this.$h}],"n":"Equals","o":"@$2","d":this.$h,"h":Number(BigInt(this.$h)|0x1200000000n),"f":1},{"r":this.$h,"n":"\u003CClone\u003E$","o":"$$$","d":this.$h,"h":Number(BigInt(this.$h)|0x1300000000n),"f":1},{"r":65537,"p":[{"n":"TaskHolder","p":2281708,"f":2},{"n":"Marshaler","p":$.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument.ArgumentToJSCallback$$(T).$h,"f":2}],"n":"Deconstruct","d":this.$h,"h":Number(BigInt(this.$h)|0x1500000000n),"f":1}],"c":[{"p":[{"n":"TaskHolder","p":2281708},{"n":"Marshaler","p":$.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument.ArgumentToJSCallback$$(T).$h}],"n":".ctor","o":"$ctor$1","d":this.$h,"h":Number(BigInt(this.$h)|0x100000000n),"f":1},{"p":[{"n":"original","p":this.$h}],"n":".ctor","o":"$ctor$2","d":this.$h,"h":Number(BigInt(this.$h)|0x1400000000n),"f":2}],"i":[$.$spc.System.IEquatable$$($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument.HolderAndMarshaler$$(T)).$h],"g":[T?.$h??1507328],"r":1,"d":1364204,"h":this.$h}; }
                    static get $b() { return $.$spc.System.Object; }
                    static $$i;
                    static get $i() { return this.$$i ??= [ $.$spc.System.IEquatable$$($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument.HolderAndMarshaler$$(T)) ]; }
                    static get $fullName() { return `System.Runtime.InteropServices.JavaScript.JSMarshalerArgument.HolderAndMarshaler<${T?.$fullName}>`; }
                }), $cls, ($v) => $cls.$_HolderAndMarshaler$$ = $v))(T);
            }
            static /*void */ RejectPromise(/*JSObject*/ holder, /*Exception*/ ex)
            {
                holder.AssertNotDisposed();
                /*Span<JSMarshalerArgument>*/ let args = $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.StackAllocSpan($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument, 4, null);
                /*ref JSMarshalerArgument*/ let exc = args.get_Item(0);
                /*ref JSMarshalerArgument*/ let res = args.get_Item(1);
                /*ref JSMarshalerArgument*/ let arg_handle = args.get_Item(2);
                /*ref JSMarshalerArgument*/ let arg_value = args.get_Item(3);
                exc.$v.Initialize();
                res.$v.Initialize();
                arg_handle.$v.slot.Type = 29/*MarshalerType.TaskRejected*/;
                arg_handle.$v.slot.JSHandle = holder.JSHandle;
                arg_value.$v.ToJS$36(ex);
                holder.DisposeImpl(true);
                $.$srij.System.Runtime.InteropServices.JavaScript.JSFunctionBinding.ResolveOrRejectPromise(holder.ProxyContext, args);
            }
            static /*void */ ResolveVoidPromise(/*JSObject*/ holder)
            {
                holder.AssertNotDisposed();
                /*Span<JSMarshalerArgument>*/ let args = $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.StackAllocSpan($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument, 4, null);
                /*ref JSMarshalerArgument*/ let exc = args.get_Item(0);
                /*ref JSMarshalerArgument*/ let res = args.get_Item(1);
                /*ref JSMarshalerArgument*/ let arg_handle = args.get_Item(2);
                /*ref JSMarshalerArgument*/ let arg_value = args.get_Item(3);
                exc.$v.Initialize();
                res.$v.Initialize();
                arg_handle.$v.slot.Type = 28/*MarshalerType.TaskResolved*/;
                arg_handle.$v.slot.JSHandle = holder.JSHandle;
                arg_value.$v.slot.Type = 1/*MarshalerType.Void*/;
                holder.DisposeImpl(true);
                $.$srij.System.Runtime.InteropServices.JavaScript.JSFunctionBinding.ResolveOrRejectPromise(holder.ProxyContext, args);
            }
            static /*void */ ResolvePromise(T, /*JSObject*/ holder, /*T*/ value, /*ArgumentToJSCallback<T>*/ marshaler)
            {
                holder.AssertNotDisposed();
                /*Span<JSMarshalerArgument>*/ let args = $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.StackAllocSpan($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument, 4, null);
                /*ref JSMarshalerArgument*/ let exc = args.get_Item(0);
                /*ref JSMarshalerArgument*/ let res = args.get_Item(1);
                /*ref JSMarshalerArgument*/ let arg_handle = args.get_Item(2);
                /*ref JSMarshalerArgument*/ let arg_value = args.get_Item(3);
                exc.$v.Initialize();
                res.$v.Initialize();
                arg_handle.$v.slot.Type = 28/*MarshalerType.TaskResolved*/;
                arg_handle.$v.slot.JSHandle = holder.JSHandle;
                marshaler.Invoke(arg_value, value);
                holder.DisposeImpl(true);
                $.$srij.System.Runtime.InteropServices.JavaScript.JSFunctionBinding.ResolveOrRejectPromise(holder.ProxyContext, args);
            }
            /*void */ ToManaged$47(/*out object?*/ value)
            {
                if (this.slot.Type === 0/*MarshalerType.None*/)
                {
                    value.$v = null;
                }
                else if (this.slot.Type === 14/*MarshalerType.Object*/)
                {
                    value.$v = ($.$spc.System.Runtime.InteropServices.GCHandle.op_Explicit(this.slot.GCHandle)).Target;
                }
                else if (this.slot.Type === 3/*MarshalerType.Boolean*/)
                {
                    /*bool*/ let v;
                    this.ToManaged$17($.$ref(() => v, ($v) => v = $v, $.$spc.System.Boolean));
                    value.$v = $.$box(v, $.$spc.System.Boolean);
                }
                else if (this.slot.Type === 10/*MarshalerType.Double*/)
                {
                    /*double*/ let v;
                    this.ToManaged$4($.$ref(() => v, ($v) => v = $v, $.$spc.System.Double));
                    value.$v = $.$box(v, $.$spc.System.Double);
                }
                else if (this.slot.Type === 13/*MarshalerType.JSObject*/)
                {
                    /*JSObject?*/ let val;
                    this.ToManaged$27($.$ref(() => val, ($v) => val = $v, $.$srij.System.Runtime.InteropServices.JavaScript.JSObject));
                    value.$v = val;
                }
                else if (this.slot.Type === 15/*MarshalerType.String*/)
                {
                    /*string?*/ let val;
                    this.ToManaged$29($.$ref(() => val, ($v) => val = $v, $.$spc.System.String));
                    value.$v = val;
                }
                else if (this.slot.Type === 16/*MarshalerType.Exception*/)
                {
                    /*Exception?*/ let val;
                    this.ToManaged$36($.$ref(() => val, ($v) => val = $v, $.$spc.System.Exception));
                    value.$v = val;
                }
                else if (this.slot.Type === 17/*MarshalerType.DateTime*/)
                {
                    /*DateTime?*/ let val;
                    this.ToManaged$16($.$ref(() => val, ($v) => val = $v, $.$typeNullable($.$spc.System.DateTime)));
                    value.$v = val?.Clone() ?? null;
                }
                else if (this.slot.Type === 27/*MarshalerType.JSException*/)
                {
                    /*Exception?*/ let val;
                    this.ToManaged$36($.$ref(() => val, ($v) => val = $v, $.$spc.System.Exception));
                    value.$v = val;
                }
                else if (this.slot.Type === 21/*MarshalerType.Array*/)
                {
                    if (this.slot.ElementType === 4/*MarshalerType.Byte*/)
                    {
                        /*byte[]?*/ let val;
                        this.ToManaged$21($.$ref(() => val, ($v) => val = $v, $.$typeArray($.$spc.System.Byte)));
                        value.$v = val;
                    }
                    else if (this.slot.ElementType === 10/*MarshalerType.Double*/)
                    {
                        /*double[]?*/ let val;
                        this.ToManaged$6($.$ref(() => val, ($v) => val = $v, $.$typeArray($.$spc.System.Double)));
                        value.$v = val;
                    }
                    else if (this.slot.ElementType === 7/*MarshalerType.Int32*/)
                    {
                        /*int[]?*/ let val;
                        this.ToManaged$33($.$ref(() => val, ($v) => val = $v, $.$typeArray($.$spc.System.Int32)));
                        value.$v = val;
                    }
                    else if (this.slot.ElementType === 14/*MarshalerType.Object*/)
                    {
                        /*object?[]?*/ let val;
                        this.ToManaged$48($.$ref(() => val, ($v) => val = $v, $.$typeArray($.$spc.System.Object)));
                        value.$v = val;
                    }
                    else 
                    {
                        throw new $.$spc.System.NotSupportedException().$ctor$10($.$srij.System.SR.Format($.$srij.System.SR.ToManagedNotImplemented, $.$spc.System.Enum.ToString.call(this.slot.ElementType) + "[]"));
                    }
                }
                else if (this.slot.Type === 20/*MarshalerType.Task*/ || this.slot.Type === 28/*MarshalerType.TaskResolved*/ || this.slot.Type === 29/*MarshalerType.TaskRejected*/)
                {
                    /*Task<object?>?*/ let val;
                    this.ToManaged$46($.$spc.System.Object, $.$ref(() => val, ($v) => val = $v, $.$spc.System.Threading.Tasks.Task$$($.$spc.System.Object)), new ($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument.ArgumentToManagedCallback$$($.$spc.System.Object))().$ctor($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument, /*static*/ (/*JSMarshalerArgument*/ arg, /*object?*/ value) =>
                    {
                        arg.$v.ToManaged$47(value);
                    }, {"r":65537,"p":[{"n":"arg","p":1364204,"f":4},{"n":"value","p":131073,"f":2}],"n":"","d":1364204,"h":0,"f":1048610}));
                    value.$v = val;
                }
                else 
                {
                    throw new $.$spc.System.NotSupportedException().$ctor$10($.$srij.System.SR.Format($.$srij.System.SR.ToManagedNotImplemented, $.$box(this.slot.Type, $.$srij.System.Runtime.InteropServices.JavaScript.MarshalerType)));
                }
            }
            /*void */ ToJS$47(/*object?*/ value)
            {
                if (value === null)
                {
                    this.slot.Type = 0/*MarshalerType.None*/;
                    return;
                }
                /*Type*/ let type = $.$spc.System.Object.GetType.call(value);
                let ut;
                if (type.IsPrimitive)
                {
                    if ($.$spc.System.Type.op_Equality$1($.$spc.System.Int64.$type, type))
                    {
                        throw new $.$spc.System.NotSupportedException().$ctor$10($.$srij.System.SR.Format($.$srij.System.SR.ToJSNotImplemented, type.FullName));
                    }
                    else if ($.$spc.System.Type.op_Equality$1($.$spc.System.Int32.$type, type))
                    {
                        /*var*/ let v = $.$cast(value, $.$spc.System.Int32);
                        this.ToJS$31(v);
                    }
                    else if ($.$spc.System.Type.op_Equality$1($.$spc.System.Int16.$type, type))
                    {
                        /*var*/ let v = $.$cast(value, $.$spc.System.Int16);
                        this.ToJS$11(v);
                    }
                    else if ($.$spc.System.Type.op_Equality$1($.$spc.System.Byte.$type, type))
                    {
                        /*var*/ let v = $.$cast(value, $.$spc.System.Byte);
                        this.ToJS$19(v);
                    }
                    else if ($.$spc.System.Type.op_Equality$1($.$spc.System.Char.$type, type))
                    {
                        /*var*/ let v = $.$cast(value, $.$spc.System.Char);
                        this.ToJS$2(v);
                    }
                    else if ($.$spc.System.Type.op_Equality$1($.$spc.System.Boolean.$type, type))
                    {
                        /*var*/ let v = $.$cast(value, $.$spc.System.Boolean);
                        this.ToJS$17(v);
                    }
                    else if ($.$spc.System.Type.op_Equality$1($.$spc.System.Double.$type, type))
                    {
                        /*var*/ let v = $.$cast(value, $.$spc.System.Double);
                        this.ToJS$4(v);
                    }
                    else if ($.$spc.System.Type.op_Equality$1($.$spc.System.Single.$type, type))
                    {
                        /*var*/ let v = $.$cast(value, $.$spc.System.Single);
                        this.ToJS(v);
                    }
                    else if ($.$spc.System.Type.op_Equality$1($.$spc.System.IntPtr.$type, type))
                    {
                        /*var*/ let v = $.$cast(value, $.$spc.System.IntPtr);
                        this.ToJS$24(v);
                    }
                    else 
                    {
                        throw new $.$spc.System.NotSupportedException().$ctor$10($.$srij.System.SR.Format($.$srij.System.SR.ToJSNotImplemented, type.FullName));
                    }
                }
                else if ($.$spc.System.Type.op_Equality$1($.$spc.System.String.$type, type))
                {
                    /*string?*/ let str = $.$as(value, $.$spc.System.String);
                    this.ToJS$29(str);
                }
                else if ($.$spc.System.Type.op_Equality$1($.$spc.System.DateTimeOffset.$type, type))
                {
                    /*var*/ let v = $.$cast(value, $.$spc.System.DateTimeOffset);
                    this.ToJS$13(v);
                }
                else if ($.$spc.System.Type.op_Equality$1($.$spc.System.DateTime.$type, type))
                {
                    /*var*/ let v = $.$cast(value, $.$spc.System.DateTime);
                    this.ToJS$15(v);
                }
                else if ($.$is($.$spc.System.Nullable.GetUnderlyingType(type), $.$spc.System.Type, { set $v(v){ ut = v; } }) && $.$spc.System.Type.op_Inequality$1(ut, null))
                {
                    if ($.$spc.System.Type.op_Equality$1($.$spc.System.Int64.$type, ut))
                    {
                        throw new $.$spc.System.NotSupportedException().$ctor$10($.$srij.System.SR.Format($.$srij.System.SR.ToJSNotImplemented, type.FullName));
                    }
                    else if ($.$spc.System.Type.op_Equality$1($.$spc.System.Int32.$type, ut))
                    {
                        /*var*/ let nv = $.$as(value, $.$spc.System.Int32);
                        this.ToJS$32(nv);
                    }
                    else if ($.$spc.System.Type.op_Equality$1($.$spc.System.Int16.$type, ut))
                    {
                        /*var*/ let nv = $.$as(value, $.$spc.System.Int16);
                        this.ToJS$12(nv);
                    }
                    else if ($.$spc.System.Type.op_Equality$1($.$spc.System.Byte.$type, ut))
                    {
                        /*var*/ let nv = $.$as(value, $.$spc.System.Byte);
                        this.ToJS$20(nv);
                    }
                    else if ($.$spc.System.Type.op_Equality$1($.$spc.System.Char.$type, ut))
                    {
                        /*var*/ let nv = $.$as(value, $.$spc.System.Char);
                        this.ToJS$3(nv);
                    }
                    else if ($.$spc.System.Type.op_Equality$1($.$spc.System.Boolean.$type, ut))
                    {
                        /*var*/ let nv = $.$as(value, $.$spc.System.Boolean);
                        this.ToJS$18(nv);
                    }
                    else if ($.$spc.System.Type.op_Equality$1($.$spc.System.Double.$type, ut))
                    {
                        /*var*/ let nv = $.$as(value, $.$spc.System.Double);
                        this.ToJS$5(nv);
                    }
                    else if ($.$spc.System.Type.op_Equality$1($.$spc.System.Single.$type, ut))
                    {
                        /*var*/ let nv = $.$as(value, $.$spc.System.Single);
                        this.ToJS$1(nv);
                    }
                    else if ($.$spc.System.Type.op_Equality$1($.$spc.System.IntPtr.$type, ut))
                    {
                        /*var*/ let nv = $.$as(value, $.$spc.System.IntPtr);
                        this.ToJS$25(nv);
                    }
                    else if ($.$spc.System.Type.op_Equality$1($.$spc.System.DateTimeOffset.$type, ut))
                    {
                        /*var*/ let nv = $.$as(value, $.$spc.System.DateTimeOffset);
                        this.ToJS$14(nv?.Clone() ?? null);
                    }
                    else if ($.$spc.System.Type.op_Equality$1($.$spc.System.DateTime.$type, ut))
                    {
                        /*var*/ let nv = $.$as(value, $.$spc.System.DateTime);
                        this.ToJS$16(nv?.Clone() ?? null);
                    }
                    else 
                    {
                        throw new $.$spc.System.NotSupportedException().$ctor$10($.$srij.System.SR.Format($.$srij.System.SR.ToJSNotImplemented, type.FullName));
                    }
                }
                else if ($.$srij.System.Runtime.InteropServices.JavaScript.JSObject.$type.IsAssignableFrom(type))
                {
                    /*JSObject?*/ let val = $.$as(value, $.$srij.System.Runtime.InteropServices.JavaScript.JSObject);
                    this.ToJS$27(val);
                }
                else if ($.$spc.System.Exception.$type.IsAssignableFrom(type))
                {
                    /*Exception?*/ let val = $.$as(value, $.$spc.System.Exception);
                    this.ToJS$36(val);
                }
                else if ($.$spc.System.Type.op_Equality$1($.$spc.System.Threading.Tasks.Task$$($.$spc.System.Object).$type, type))
                {
                    /*Task<object>?*/ let val = $.$as(value, $.$spc.System.Threading.Tasks.Task$$($.$spc.System.Object));
                    this.ToJS$46($.$spc.System.Object, val, new ($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument.ArgumentToJSCallback$$($.$spc.System.Object))().$ctor(this,  (/*JSMarshalerArgument*/ arg, /*object*/ value) =>
                    {
                        /*object?*/ let valueRef = value;
                        arg.$v.ToJS$47(valueRef);
                    }, {"r":65537,"p":[{"n":"arg","p":1364204,"f":4},{"n":"value","p":131073}],"n":"","d":1364204,"h":0,"f":1048578}));
                }
                else if ($.$spc.System.Threading.Tasks.Task.$type.IsAssignableFrom(type))
                {
                    /*Task?*/ let val = $.$as(value, $.$spc.System.Threading.Tasks.Task);
                    this.ToJSDynamic(val);
                }
                else if ($.$spc.System.Type.op_Equality$1($.$typeArray($.$spc.System.Byte).$type, type))
                {
                    /*byte[]*/ let val = $.$cast(value, $.$typeArray($.$spc.System.Byte));
                    this.ToJS$21(val);
                }
                else if ($.$spc.System.Type.op_Equality$1($.$typeArray($.$spc.System.Int32).$type, type))
                {
                    /*int[]*/ let val = $.$cast(value, $.$typeArray($.$spc.System.Int32));
                    this.ToJS$33(val);
                }
                else if ($.$spc.System.Type.op_Equality$1($.$typeArray($.$spc.System.Double).$type, type))
                {
                    /*double[]*/ let val = $.$cast(value, $.$typeArray($.$spc.System.Double));
                    this.ToJS$6(val);
                }
                else if ($.$spc.System.Type.op_Equality$1($.$typeArray($.$spc.System.String).$type, type))
                {
                    /*string[]*/ let val = $.$cast(value, $.$typeArray($.$spc.System.String));
                    this.ToJS$30(val);
                }
                else if ($.$spc.System.Type.op_Equality$1($.$typeArray($.$spc.System.Object).$type, type))
                {
                    /*object[]*/ let val = $.$cast(value, $.$typeArray($.$spc.System.Object));
                    this.ToJS$48(val);
                }
                else if (type.IsArray)
                {
                    throw new $.$spc.System.NotSupportedException().$ctor$10($.$srij.System.SR.Format($.$srij.System.SR.ToJSNotImplemented, type.FullName));
                }
                else if ($.$spc.System.MulticastDelegate.$type.IsAssignableFrom(type.BaseType))
                {
                    throw new $.$spc.System.NotSupportedException().$ctor$10($.$srij.System.SR.Format($.$srij.System.SR.ToJSNotImplemented, type.FullName));
                }
                else if (type.IsGenericType && $.$spc.System.Type.op_Equality$1(type.GetGenericTypeDefinition(), $.$spc.System.ArraySegment$$().$type))
                {
                    throw new $.$spc.System.NotSupportedException().$ctor$10($.$srij.System.SR.Format($.$srij.System.SR.ToJSNotImplemented, type.FullName));
                }
                else if (type.IsGenericType && $.$spc.System.Type.op_Equality$1(type.GetGenericTypeDefinition(), $.$spc.System.Span$$().$type))
                {
                    throw new $.$spc.System.NotSupportedException().$ctor$10($.$srij.System.SR.Format($.$srij.System.SR.ToJSNotImplemented, type.FullName));
                }
                else 
                {
                    this.slot.Type = 14/*MarshalerType.Object*/;
                    /*var*/ let ctx = this.ToJSContext;
                    this.slot.GCHandle = ctx.GetJSOwnedObjectGCHandle(value, 2);
                }
            }
            /*void */ ToManaged$48(/*out object?[]?*/ value)
            {
                if (this.slot.Type === 0/*MarshalerType.None*/)
                {
                    value.$v = null;
                    return;
                }
                value.$v = $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$spc.System.Object), null, [this.slot.Length], null);
                /*JSMarshalerArgument**/ let payload = $.$cast(this.slot.IntPtrValue, $.$typePointer($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument));
                for(/*int*/ let i = 0; i < this.slot.Length; i++)
                {
                    /*ref JSMarshalerArgument*/ let arg = payload.Add(i);
                    /*object?*/ let val;
                    arg.$v.ToManaged$47($.$ref(() => val, ($v) => val = $v, $.$spc.System.Object));
                    $.$spc.System.Array.$WriteT1.call(value.$v, val, i);
                }
                $.$srij.Interop.Runtime.DeregisterGCRoot(this.slot.IntPtrValue);
                $.$spc.System.Runtime.InteropServices.Marshal.FreeHGlobal(this.slot.IntPtrValue);
            }
            /*void */ ToJS$48(/*object?[]*/ value)
            {
                if (value === null)
                {
                    this.slot.Type = 0/*MarshalerType.None*/;
                    return;
                }
                this.slot.Length = value.length;
                /*int*/ let bytes = ((value.length * $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument.$z) | 0);
                this.slot.Type = 21/*MarshalerType.Array*/;
                /*JSMarshalerArgument**/ let payload = $.$cast($.$spc.System.Runtime.InteropServices.Marshal.AllocHGlobal(bytes), $.$typePointer($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument));
                $.$spc.System.Runtime.CompilerServices.Unsafe.InitBlock(payload, 0, (bytes >>> 0));
                $.$srij.Interop.Runtime.RegisterGCRoot(payload, bytes, $.$spc.System.IntPtr.Zero);
                for(/*int*/ let i = 0; i < this.slot.Length; i++)
                {
                    /*ref JSMarshalerArgument*/ let arg = payload.Add(i);
                    /*object?*/ let val = $.$spc.System.Array.$ReadT1.call(value, i);
                    arg.$v.ToJS$47(val);
                    $.$spc.System.Array.$WriteT1.call(value, val, i);
                }
                this.slot.ElementType = 14/*MarshalerType.Object*/;
                this.slot.IntPtrValue = $.$cast(payload, $.$spc.System.IntPtr);
            }
            //default value type constructor
            $ctor$2()
            {
                return this;
            }
            Clone($copy)
            {
                let copy = $copy ?? new this.constructor();
                copy.slot = this.slot.Clone();
                return copy;
            }
            //default member initializer
            constructor()
            {
                super();
                this.slot = $.$default($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument.JSMarshalerArgumentImpl);
            }
            static $h = 1364204;
            static $z = 32;
            static $f = 0b1010000001;
            static $k = 2;
            static $$md;
            static get $md() { return this.$$md ??= {"b":196609,"p":[{"p":2347244,"g":{"r":0,"d":0,"h":21476200684,"f":8},"n":"ToManagedContext","d":1364204,"h":17181233388,"f":8},{"p":2347244,"g":{"r":0,"d":0,"h":30066135276,"f":8},"n":"ToJSContext","d":1364204,"h":25771167980,"f":8}],"m":[{"r":65537,"n":"Initialize","d":1364204,"h":12886266092,"f":1},{"r":2347244,"n":"AssertCurrentThreadContext","d":1364204,"h":34361102572,"f":8},{"r":65537,"p":[{"n":"value","p":917505,"f":2}],"n":"ToManagedBig","d":1364204,"h":38656069868,"f":1},{"r":65537,"p":[{"n":"value","p":917505}],"n":"ToJSBig","d":1364204,"h":42951037164,"f":1},{"r":65537,"p":[{"n":"value","p":$.$typeNullable($.$spc.System.Int64).$h,"f":2}],"n":"ToManagedBig","o":"@$1","d":1364204,"h":47246004460,"f":1},{"r":65537,"p":[{"n":"value","p":$.$typeNullable($.$spc.System.Int64).$h}],"n":"ToJSBig","o":"@$1","d":1364204,"h":51540971756,"f":1},{"r":65537,"p":[{"n":"value","p":1114113,"f":2}],"n":"ToManaged","d":1364204,"h":55835939052,"f":1},{"r":65537,"p":[{"n":"value","p":1114113}],"n":"ToJS","d":1364204,"h":60130906348,"f":1},{"r":65537,"p":[{"n":"value","p":$.$typeNullable($.$spc.System.Single).$h,"f":2}],"n":"ToManaged","o":"@$1","d":1364204,"h":64425873644,"f":1},{"r":65537,"p":[{"n":"value","p":$.$typeNullable($.$spc.System.Single).$h}],"n":"ToJS","o":"@$1","d":1364204,"h":68720840940,"f":1},{"r":65537,"p":[{"n":"value","p":458753,"f":2}],"n":"ToManaged","o":"@$2","d":1364204,"h":73015808236,"f":1},{"r":65537,"p":[{"n":"value","p":458753}],"n":"ToJS","o":"@$2","d":1364204,"h":77310775532,"f":1},{"r":65537,"p":[{"n":"value","p":$.$typeNullable($.$spc.System.Char).$h,"f":2}],"n":"ToManaged","o":"@$3","d":1364204,"h":81605742828,"f":1},{"r":65537,"p":[{"n":"value","p":$.$typeNullable($.$spc.System.Char).$h}],"n":"ToJS","o":"@$3","d":1364204,"h":85900710124,"f":1},{"r":65537,"p":[{"n":"value","p":1179649,"f":2}],"n":"ToManaged","o":"@$4","d":1364204,"h":90195677420,"f":1},{"r":65537,"p":[{"n":"value","p":1179649}],"n":"ToJS","o":"@$4","d":1364204,"h":94490644716,"f":1},{"r":65537,"p":[{"n":"value","p":$.$typeNullable($.$spc.System.Double).$h,"f":2}],"n":"ToManaged","o":"@$5","d":1364204,"h":98785612012,"f":1},{"r":65537,"p":[{"n":"value","p":$.$typeNullable($.$spc.System.Double).$h}],"n":"ToJS","o":"@$5","d":1364204,"h":103080579308,"f":1},{"r":65537,"p":[{"n":"value","p":0,"f":2}],"n":"ToManaged","o":"@$6","d":1364204,"h":107375546604,"f":1},{"r":65537,"p":[{"n":"value","p":0}],"n":"ToJS","o":"@$6","d":1364204,"h":111670513900,"f":1},{"r":65537,"p":[{"n":"value","p":$.$spc.System.ArraySegment$$($.$spc.System.Double).$h,"f":2}],"n":"ToManaged","o":"@$7","d":1364204,"h":115965481196,"f":1},{"r":65537,"p":[{"n":"value","p":$.$spc.System.ArraySegment$$($.$spc.System.Double).$h}],"n":"ToJS","o":"@$7","d":1364204,"h":120260448492,"f":1},{"r":65537,"p":[{"n":"value","p":$.$spc.System.Span$$($.$spc.System.Double).$h,"f":2}],"n":"ToManaged","o":"@$8","d":1364204,"h":124555415788,"f":1},{"r":65537,"p":[{"n":"value","p":$.$spc.System.Span$$($.$spc.System.Double).$h}],"n":"ToJS","o":"@$8","d":1364204,"h":128850383084,"f":1},{"r":65537,"p":[{"n":"value","p":917505,"f":2}],"n":"ToManaged","o":"@$9","d":1364204,"h":141735284972,"f":1},{"r":65537,"p":[{"n":"value","p":917505}],"n":"ToJS","o":"@$9","d":1364204,"h":146030252268,"f":1},{"r":65537,"p":[{"n":"value","p":$.$typeNullable($.$spc.System.Int64).$h,"f":2}],"n":"ToManaged","o":"@$10","d":1364204,"h":150325219564,"f":1},{"r":65537,"p":[{"n":"value","p":$.$typeNullable($.$spc.System.Int64).$h}],"n":"ToJS","o":"@$10","d":1364204,"h":154620186860,"f":1},{"r":65537,"p":[{"n":"value","p":524289,"f":2}],"n":"ToManaged","o":"@$11","d":1364204,"h":158915154156,"f":1},{"r":65537,"p":[{"n":"value","p":524289}],"n":"ToJS","o":"@$11","d":1364204,"h":163210121452,"f":1},{"r":65537,"p":[{"n":"value","p":$.$typeNullable($.$spc.System.Int16).$h,"f":2}],"n":"ToManaged","o":"@$12","d":1364204,"h":167505088748,"f":1},{"r":65537,"p":[{"n":"value","p":$.$typeNullable($.$spc.System.Int16).$h}],"n":"ToJS","o":"@$12","d":1364204,"h":171800056044,"f":1},{"r":65537,"p":[{"n":"value","p":34406401,"f":2}],"n":"ToManaged","o":"@$13","d":1364204,"h":176095023340,"f":1},{"r":65537,"p":[{"n":"value","p":34406401}],"n":"ToJS","o":"@$13","d":1364204,"h":180389990636,"f":1},{"r":65537,"p":[{"n":"value","p":$.$typeNullable($.$spc.System.DateTimeOffset).$h,"f":2}],"n":"ToManaged","o":"@$14","d":1364204,"h":184684957932,"f":1},{"r":65537,"p":[{"n":"value","p":$.$typeNullable($.$spc.System.DateTimeOffset).$h}],"n":"ToJS","o":"@$14","d":1364204,"h":188979925228,"f":1},{"r":65537,"p":[{"n":"value","p":34209793,"f":2}],"n":"ToManaged","o":"@$15","d":1364204,"h":193274892524,"f":1},{"r":65537,"p":[{"n":"value","p":34209793}],"n":"ToJS","o":"@$15","d":1364204,"h":197569859820,"f":1},{"r":65537,"p":[{"n":"value","p":$.$typeNullable($.$spc.System.DateTime).$h,"f":2}],"n":"ToManaged","o":"@$16","d":1364204,"h":201864827116,"f":1},{"r":65537,"p":[{"n":"value","p":$.$typeNullable($.$spc.System.DateTime).$h}],"n":"ToJS","o":"@$16","d":1364204,"h":206159794412,"f":1},{"r":65537,"p":[{"n":"value","p":262145,"f":2}],"n":"ToManaged","o":"@$17","d":1364204,"h":210454761708,"f":1},{"r":65537,"p":[{"n":"value","p":262145}],"n":"ToJS","o":"@$17","d":1364204,"h":214749729004,"f":1},{"r":65537,"p":[{"n":"value","p":$.$typeNullable($.$spc.System.Boolean).$h,"f":2}],"n":"ToManaged","o":"@$18","d":1364204,"h":219044696300,"f":1},{"r":65537,"p":[{"n":"value","p":$.$typeNullable($.$spc.System.Boolean).$h}],"n":"ToJS","o":"@$18","d":1364204,"h":223339663596,"f":1},{"r":65537,"p":[{"n":"value","p":393217,"f":2}],"n":"ToManaged","o":"@$19","d":1364204,"h":227634630892,"f":1},{"r":65537,"p":[{"n":"value","p":393217}],"n":"ToJS","o":"@$19","d":1364204,"h":231929598188,"f":1},{"r":65537,"p":[{"n":"value","p":$.$typeNullable($.$spc.System.Byte).$h,"f":2}],"n":"ToManaged","o":"@$20","d":1364204,"h":236224565484,"f":1},{"r":65537,"p":[{"n":"value","p":$.$typeNullable($.$spc.System.Byte).$h}],"n":"ToJS","o":"@$20","d":1364204,"h":240519532780,"f":1},{"r":65537,"p":[{"n":"value","p":0,"f":2}],"n":"ToManaged","o":"@$21","d":1364204,"h":244814500076,"f":1},{"r":65537,"p":[{"n":"value","p":0}],"n":"ToJS","o":"@$21","d":1364204,"h":249109467372,"f":1},{"r":65537,"p":[{"n":"value","p":$.$spc.System.ArraySegment$$($.$spc.System.Byte).$h,"f":2}],"n":"ToManaged","o":"@$22","d":1364204,"h":253404434668,"f":1},{"r":65537,"p":[{"n":"value","p":$.$spc.System.ArraySegment$$($.$spc.System.Byte).$h}],"n":"ToJS","o":"@$22","d":1364204,"h":257699401964,"f":1},{"r":65537,"p":[{"n":"value","p":$.$spc.System.Span$$($.$spc.System.Byte).$h,"f":2}],"n":"ToManaged","o":"@$23","d":1364204,"h":261994369260,"f":1},{"r":65537,"p":[{"n":"value","p":$.$spc.System.Span$$($.$spc.System.Byte).$h}],"n":"ToJS","o":"@$23","d":1364204,"h":266289336556,"f":1},{"r":65537,"p":[{"n":"value","p":786433,"f":2}],"n":"ToManaged","o":"@$24","d":1364204,"h":270584303852,"f":1},{"r":65537,"p":[{"n":"value","p":786433}],"n":"ToJS","o":"@$24","d":1364204,"h":274879271148,"f":1},{"r":65537,"p":[{"n":"value","p":$.$typeNullable($.$spc.System.IntPtr).$h,"f":2}],"n":"ToManaged","o":"@$25","d":1364204,"h":279174238444,"f":1},{"r":65537,"p":[{"n":"value","p":$.$typeNullable($.$spc.System.IntPtr).$h}],"n":"ToJS","o":"@$25","d":1364204,"h":283469205740,"f":1},{"r":65537,"p":[{"n":"value","p":0,"f":2}],"n":"ToManaged","o":"@$26","d":1364204,"h":287764173036,"f":1},{"r":65537,"p":[{"n":"value","p":0}],"n":"ToJS","o":"@$26","d":1364204,"h":292059140332,"f":1},{"r":65537,"p":[{"n":"value","p":2281708,"f":2}],"n":"ToManaged","o":"@$27","d":1364204,"h":296354107628,"f":1},{"r":65537,"p":[{"n":"value","p":2281708}],"n":"ToJS","o":"@$27","d":1364204,"h":300649074924,"f":1},{"r":65537,"p":[{"n":"value","p":0,"f":2}],"n":"ToManaged","o":"@$28","d":1364204,"h":304944042220,"f":1},{"r":65537,"p":[{"n":"value","p":0}],"n":"ToJS","o":"@$28","d":1364204,"h":309239009516,"f":1},{"r":65537,"p":[{"n":"value","p":1310721,"f":2}],"n":"ToManaged","o":"@$29","d":1364204,"h":313533976812,"f":1},{"r":65537,"p":[{"n":"value","p":1310721}],"n":"ToJS","o":"@$29","d":1364204,"h":317828944108,"f":1},{"r":65537,"p":[{"n":"value","p":0,"f":2}],"n":"ToManaged","o":"@$30","d":1364204,"h":322123911404,"f":1},{"r":65537,"p":[{"n":"value","p":0}],"n":"ToJS","o":"@$30","d":1364204,"h":326418878700,"f":1},{"r":65537,"p":[{"n":"value","p":655361,"f":2}],"n":"ToManaged","o":"@$31","d":1364204,"h":330713845996,"f":1},{"r":65537,"p":[{"n":"value","p":655361}],"n":"ToJS","o":"@$31","d":1364204,"h":335008813292,"f":1},{"r":65537,"p":[{"n":"value","p":$.$typeNullable($.$spc.System.Int32).$h,"f":2}],"n":"ToManaged","o":"@$32","d":1364204,"h":339303780588,"f":1},{"r":65537,"p":[{"n":"value","p":$.$typeNullable($.$spc.System.Int32).$h}],"n":"ToJS","o":"@$32","d":1364204,"h":343598747884,"f":1},{"r":65537,"p":[{"n":"value","p":0,"f":2}],"n":"ToManaged","o":"@$33","d":1364204,"h":347893715180,"f":1},{"r":65537,"p":[{"n":"value","p":0}],"n":"ToJS","o":"@$33","d":1364204,"h":352188682476,"f":1},{"r":65537,"p":[{"n":"value","p":$.$spc.System.ArraySegment$$($.$spc.System.Int32).$h,"f":2}],"n":"ToManaged","o":"@$34","d":1364204,"h":356483649772,"f":1},{"r":65537,"p":[{"n":"value","p":$.$spc.System.ArraySegment$$($.$spc.System.Int32).$h}],"n":"ToJS","o":"@$34","d":1364204,"h":360778617068,"f":1},{"r":65537,"p":[{"n":"value","p":$.$spc.System.Span$$($.$spc.System.Int32).$h,"f":2}],"n":"ToManaged","o":"@$35","d":1364204,"h":365073584364,"f":1},{"r":65537,"p":[{"n":"value","p":$.$spc.System.Span$$($.$spc.System.Int32).$h}],"n":"ToJS","o":"@$35","d":1364204,"h":369368551660,"f":1},{"r":65537,"p":[{"n":"value","p":47251457,"f":2}],"n":"ToManaged","o":"@$36","d":1364204,"h":373663518956,"f":1},{"r":65537,"p":[{"n":"value","p":47251457}],"n":"ToJS","o":"@$36","d":1364204,"h":377958486252,"f":1},{"r":65537,"p":[{"n":"value","p":11665409,"f":2}],"n":"ToManaged","o":"@$37","d":1364204,"h":399433322732,"f":1},{"r":65537,"p":[{"n":"value","p":(T) => $.$spc.System.Action$$(T).$h,"f":2},{"n":"arg1Marshaler","p":(T) => $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument.ArgumentToJSCallback$$(T).$h}],"g":["T"],"n":"ToManaged","o":"@$38","d":1364204,"h":403728290028,"f":131073},{"r":65537,"p":[{"n":"value","p":(T1, T2) => $.$spc.System.Action$$$(T1, T2).$h,"f":2},{"n":"arg1Marshaler","p":(T1, T2) => $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument.ArgumentToJSCallback$$(T1).$h},{"n":"arg2Marshaler","p":(T1, T2) => $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument.ArgumentToJSCallback$$(T2).$h}],"g":["T1","T2"],"n":"ToManaged","o":"@$39","d":1364204,"h":408023257324,"f":131073},{"r":65537,"p":[{"n":"value","p":(T1, T2, T3) => $.$spc.System.Action$$$$(T1, T2, T3).$h,"f":2},{"n":"arg1Marshaler","p":(T1, T2, T3) => $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument.ArgumentToJSCallback$$(T1).$h},{"n":"arg2Marshaler","p":(T1, T2, T3) => $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument.ArgumentToJSCallback$$(T2).$h},{"n":"arg3Marshaler","p":(T1, T2, T3) => $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument.ArgumentToJSCallback$$(T3).$h}],"g":["T1","T2","T3"],"n":"ToManaged","o":"@$40","d":1364204,"h":412318224620,"f":131073},{"r":65537,"p":[{"n":"value","p":(TResult) => $.$spc.System.Func$$(TResult).$h,"f":2},{"n":"resMarshaler","p":(TResult) => $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument.ArgumentToManagedCallback$$(TResult).$h}],"g":["TResult"],"n":"ToManaged","o":"@$41","d":1364204,"h":433793061100,"f":131073},{"r":65537,"p":[{"n":"value","p":(T, TResult) => $.$spc.System.Func$$$(T, TResult).$h,"f":2},{"n":"arg1Marshaler","p":(T, TResult) => $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument.ArgumentToJSCallback$$(T).$h},{"n":"resMarshaler","p":(T, TResult) => $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument.ArgumentToManagedCallback$$(TResult).$h}],"g":["T","TResult"],"n":"ToManaged","o":"@$42","d":1364204,"h":438088028396,"f":131073},{"r":65537,"p":[{"n":"value","p":(T1, T2, TResult) => $.$spc.System.Func$$$$(T1, T2, TResult).$h,"f":2},{"n":"arg1Marshaler","p":(T1, T2, TResult) => $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument.ArgumentToJSCallback$$(T1).$h},{"n":"arg2Marshaler","p":(T1, T2, TResult) => $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument.ArgumentToJSCallback$$(T2).$h},{"n":"resMarshaler","p":(T1, T2, TResult) => $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument.ArgumentToManagedCallback$$(TResult).$h}],"g":["T1","T2","TResult"],"n":"ToManaged","o":"@$43","d":1364204,"h":442382995692,"f":131073},{"r":65537,"p":[{"n":"value","p":(T1, T2, T3, TResult) => $.$spc.System.Func$$$$$(T1, T2, T3, TResult).$h,"f":2},{"n":"arg1Marshaler","p":(T1, T2, T3, TResult) => $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument.ArgumentToJSCallback$$(T1).$h},{"n":"arg2Marshaler","p":(T1, T2, T3, TResult) => $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument.ArgumentToJSCallback$$(T2).$h},{"n":"arg3Marshaler","p":(T1, T2, T3, TResult) => $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument.ArgumentToJSCallback$$(T3).$h},{"n":"resMarshaler","p":(T1, T2, T3, TResult) => $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument.ArgumentToManagedCallback$$(TResult).$h}],"g":["T1","T2","T3","TResult"],"n":"ToManaged","o":"@$44","d":1364204,"h":446677962988,"f":131073},{"r":65537,"p":[{"n":"value","p":11665409}],"n":"ToJS","o":"@$37","d":1364204,"h":450972930284,"f":1},{"r":65537,"p":[{"n":"value","p":(T) => $.$spc.System.Action$$(T).$h},{"n":"arg1Marshaler","p":(T) => $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument.ArgumentToManagedCallback$$(T).$h}],"g":["T"],"n":"ToJS","o":"@$38","d":1364204,"h":455267897580,"f":131073},{"r":65537,"p":[{"n":"value","p":(T1, T2) => $.$spc.System.Action$$$(T1, T2).$h},{"n":"arg1Marshaler","p":(T1, T2) => $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument.ArgumentToManagedCallback$$(T1).$h},{"n":"arg2Marshaler","p":(T1, T2) => $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument.ArgumentToManagedCallback$$(T2).$h}],"g":["T1","T2"],"n":"ToJS","o":"@$39","d":1364204,"h":459562864876,"f":131073},{"r":65537,"p":[{"n":"value","p":(T1, T2, T3) => $.$spc.System.Action$$$$(T1, T2, T3).$h},{"n":"arg1Marshaler","p":(T1, T2, T3) => $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument.ArgumentToManagedCallback$$(T1).$h},{"n":"arg2Marshaler","p":(T1, T2, T3) => $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument.ArgumentToManagedCallback$$(T2).$h},{"n":"arg3Marshaler","p":(T1, T2, T3) => $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument.ArgumentToManagedCallback$$(T3).$h}],"g":["T1","T2","T3"],"n":"ToJS","o":"@$40","d":1364204,"h":463857832172,"f":131073},{"r":65537,"p":[{"n":"value","p":(TResult) => $.$spc.System.Func$$(TResult).$h},{"n":"resMarshaler","p":(TResult) => $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument.ArgumentToJSCallback$$(TResult).$h}],"g":["TResult"],"n":"ToJS","o":"@$41","d":1364204,"h":468152799468,"f":131073},{"r":65537,"p":[{"n":"value","p":(T, TResult) => $.$spc.System.Func$$$(T, TResult).$h},{"n":"arg1Marshaler","p":(T, TResult) => $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument.ArgumentToManagedCallback$$(T).$h},{"n":"resMarshaler","p":(T, TResult) => $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument.ArgumentToJSCallback$$(TResult).$h}],"g":["T","TResult"],"n":"ToJS","o":"@$42","d":1364204,"h":472447766764,"f":131073},{"r":65537,"p":[{"n":"value","p":(T1, T2, TResult) => $.$spc.System.Func$$$$(T1, T2, TResult).$h},{"n":"arg1Marshaler","p":(T1, T2, TResult) => $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument.ArgumentToManagedCallback$$(T1).$h},{"n":"arg2Marshaler","p":(T1, T2, TResult) => $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument.ArgumentToManagedCallback$$(T2).$h},{"n":"resMarshaler","p":(T1, T2, TResult) => $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument.ArgumentToJSCallback$$(TResult).$h}],"g":["T1","T2","TResult"],"n":"ToJS","o":"@$43","d":1364204,"h":476742734060,"f":131073},{"r":65537,"p":[{"n":"value","p":(T1, T2, T3, TResult) => $.$spc.System.Func$$$$$(T1, T2, T3, TResult).$h},{"n":"arg1Marshaler","p":(T1, T2, T3, TResult) => $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument.ArgumentToManagedCallback$$(T1).$h},{"n":"arg2Marshaler","p":(T1, T2, T3, TResult) => $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument.ArgumentToManagedCallback$$(T2).$h},{"n":"arg3Marshaler","p":(T1, T2, T3, TResult) => $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument.ArgumentToManagedCallback$$(T3).$h},{"n":"resMarshaler","p":(T1, T2, T3, TResult) => $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument.ArgumentToJSCallback$$(TResult).$h}],"g":["T1","T2","T3","TResult"],"n":"ToJS","o":"@$44","d":1364204,"h":481037701356,"f":131073},{"r":65537,"p":[{"n":"value","p":133300225,"f":2}],"n":"ToManaged","o":"@$45","d":1364204,"h":493922603244,"f":1},{"r":65537,"p":[{"n":"value","p":(T) => $.$spc.System.Threading.Tasks.Task$$(T).$h,"f":2},{"n":"marshaler","p":(T) => $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument.ArgumentToManagedCallback$$(T).$h}],"g":["T"],"n":"ToManaged","o":"@$46","d":1364204,"h":498217570540,"f":131073},{"r":65537,"p":[{"n":"value","p":133300225}],"n":"ToJSDynamic","d":1364204,"h":502512537836,"f":8},{"r":65537,"p":[{"n":"value","p":133300225}],"n":"ToJS","o":"@$45","d":1364204,"h":506807505132,"f":1},{"r":65537,"p":[{"n":"value","p":(T) => $.$spc.System.Threading.Tasks.Task$$(T).$h},{"n":"marshaler","p":(T) => $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument.ArgumentToJSCallback$$(T).$h}],"g":["T"],"n":"ToJS","o":"@$46","d":1364204,"h":511102472428,"f":131073},{"r":262145,"p":[{"n":"_","p":2347244}],"n":"CanMarshalTaskResultOnSameCall","d":1364204,"h":515397439724,"f":2},{"r":65537,"p":[{"n":"holder","p":2281708},{"n":"ex","p":47251457}],"n":"RejectPromise","d":1364204,"h":523987374316,"f":34},{"r":65537,"p":[{"n":"holder","p":2281708}],"n":"ResolveVoidPromise","d":1364204,"h":528282341612,"f":34},{"r":65537,"p":[{"n":"holder","p":2281708},{"n":"value","p":(T) => T.$h},{"n":"marshaler","p":(T) => $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument.ArgumentToJSCallback$$(T).$h}],"g":["T"],"n":"ResolvePromise","d":1364204,"h":532577308908,"f":131106},{"r":65537,"p":[{"n":"value","p":131073,"f":2}],"n":"ToManaged","o":"@$47","d":1364204,"h":536872276204,"f":1},{"r":65537,"p":[{"n":"value","p":131073}],"n":"ToJS","o":"@$47","d":1364204,"h":541167243500,"f":1},{"r":65537,"p":[{"n":"value","p":0,"f":2}],"n":"ToManaged","o":"@$48","d":1364204,"h":545462210796,"f":1},{"r":65537,"p":[{"n":"value","p":0}],"n":"ToJS","o":"@$48","d":1364204,"h":549757178092,"f":1}],"l":[{"t":2150636,"n":"slot","d":1364204,"h":4296331500,"f":8},{"t":917505,"n":"I52_MAX_VALUE","d":1364204,"h":133145350380,"f":34},{"t":917505,"n":"I52_MIN_VALUE","d":1364204,"h":137440317676,"f":34}],"c":[{"n":".ctor","o":"$ctor$2","d":1364204,"h":554052145388,"f":1}],"j":[2150636,1429740,1626348,1560812,1495276,2019564,1954028,1888492,1822956,1757420,1691884,2085100],"h":1364204,"a":[{"t":114950145,"c":4409917441,"a":[{"v":"browser","t":1310721}]},{"t":23461889,"c":8613396481,"a":[{"v":false,"t":262145}]},{"t":33226753,"c":4328194049,"a":[{"v":1,"t":33292289}]}]}; }
            static get $b() { return $.$spc.System.ValueType; }
            static get $fullName() { return `System.Runtime.InteropServices.JavaScript.JSMarshalerArgument`; }
        });
        
        $asm.$cls("$srij.System.Runtime.InteropServices.JavaScript.JSImportAttribute", ($self) => class JSImportAttribute extends $.$spc.System.Attribute
        {
            /*string*/ FunctionName = null;
            /*string?*/ ModuleName = null;
            $ctor$2(/*string*/ functionName)
            {
                super.$ctor$1();
                {
                    this.FunctionName = functionName;
                }
                return this;
            }
            $ctor$3(/*string*/ functionName, /*string*/ moduleName)
            {
                super.$ctor$1();
                {
                    this.FunctionName = functionName;
                    this.ModuleName = moduleName;
                }
                return this;
            }
            static $h = 1233132;
            static $f = 0b10010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":14548993,"p":[{"p":1310721,"g":{"r":0,"d":0,"h":12886135020,"f":1},"n":"FunctionName","d":1233132,"h":8591167724,"f":1},{"p":1310721,"g":{"r":0,"d":0,"h":25771036908,"f":1},"n":"ModuleName","d":1233132,"h":21476069612,"f":1}],"c":[{"p":[{"n":"functionName","p":1310721}],"n":".ctor","o":"$ctor$2","d":1233132,"h":30066004204,"f":1},{"p":[{"n":"functionName","p":1310721},{"n":"moduleName","p":1310721}],"n":".ctor","o":"$ctor$3","d":1233132,"h":34360971500,"f":1}],"h":1233132,"a":[{"t":14680065,"c":21489516545,"a":[{"v":64,"t":14614529}],"n":[{"n":"Inherited","v":false,"t":262145},{"n":"AllowMultiple","v":false,"t":262145}]},{"t":114950145,"c":4409917441,"a":[{"v":"browser","t":1310721}]}]}; }
            static get $b() { return $.$spc.System.Attribute; }
            static get $fullName() { return `System.Runtime.InteropServices.JavaScript.JSImportAttribute`; }
        });
        
        $asm.$cls("$srij.System.Runtime.InteropServices.JavaScript.JSExportAttribute", ($self) => class JSExportAttribute extends $.$spc.System.Attribute
        {
            $ctor$2()
            {
                super.$ctor$1();
                {
                }
                return this;
            }
            static $h = 512236;
            static $f = 0b10010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":14548993,"c":[{"n":".ctor","o":"$ctor$2","d":512236,"h":4295479532,"f":1}],"h":512236,"a":[{"t":14680065,"c":21489516545,"a":[{"v":64,"t":14614529}],"n":[{"n":"Inherited","v":false,"t":262145},{"n":"AllowMultiple","v":false,"t":262145}]},{"t":114950145,"c":4409917441,"a":[{"v":"browser","t":1310721}]}]}; }
            static get $b() { return $.$spc.System.Attribute; }
            static get $fullName() { return `System.Runtime.InteropServices.JavaScript.JSExportAttribute`; }
        });
        
        $asm.$str("$srij.System.Runtime.InteropServices.JavaScript.MarshalerType", ($self) => class MarshalerType extends $.$spc.System.Enum
        {
            static None = 0;
            static Void = 1;
            static Discard = 2;
            static Boolean = 3;
            static Byte = 4;
            static Char = 5;
            static Int16 = 6;
            static Int32 = 7;
            static Int52 = 8;
            static BigInt64 = 9;
            static Double = 10;
            static Single = 11;
            static IntPtr = 12;
            static JSObject = 13;
            static Object = 14;
            static String = 15;
            static Exception = 16;
            static DateTime = 17;
            static DateTimeOffset = 18;
            static Nullable = 19;
            static Task = 20;
            static Array = 21;
            static ArraySegment = 22;
            static Span = 23;
            static Action = 24;
            static Function = 25;
            static DiscardNoWait = 26;
            static JSException = 27;
            static TaskResolved = 28;
            static TaskRejected = 29;
            static TaskPreCreated = 30;
            static $map;
            static get Map()
            {
                return this.$map ??= 
                {
                    "None": 0n,
                    "Void": 1n,
                    "Discard": 2n,
                    "Boolean": 3n,
                    "Byte": 4n,
                    "Char": 5n,
                    "Int16": 6n,
                    "Int32": 7n,
                    "Int52": 8n,
                    "BigInt64": 9n,
                    "Double": 10n,
                    "Single": 11n,
                    "IntPtr": 12n,
                    "JSObject": 13n,
                    "Object": 14n,
                    "String": 15n,
                    "Exception": 16n,
                    "DateTime": 17n,
                    "DateTimeOffset": 18n,
                    "Nullable": 19n,
                    "Task": 20n,
                    "Array": 21n,
                    "ArraySegment": 22n,
                    "Span": 23n,
                    "Action": 24n,
                    "Function": 25n,
                    "DiscardNoWait": 26n,
                    "JSException": 27n,
                    "TaskResolved": 28n,
                    "TaskRejected": 29n,
                    "TaskPreCreated": 30n
                };
            }
            static $h = 3723500;
            static $z = 1;
            static $f = 0b100000011010001000;
            static $k = 4;
            static get $eut() { return $.$spc.System.Byte; }
            static $$md;
            static get $md() { return this.$$md ??= {"b":1048577,"u":393217,"l":[{"t":3723500,"n":"None","d":3723500,"h":4298690796,"f":33},{"t":3723500,"n":"Void","d":3723500,"h":8593658092,"f":33},{"t":3723500,"n":"Discard","d":3723500,"h":12888625388,"f":33},{"t":3723500,"n":"Boolean","d":3723500,"h":17183592684,"f":33},{"t":3723500,"n":"Byte","d":3723500,"h":21478559980,"f":33},{"t":3723500,"n":"Char","d":3723500,"h":25773527276,"f":33},{"t":3723500,"n":"Int16","d":3723500,"h":30068494572,"f":33},{"t":3723500,"n":"Int32","d":3723500,"h":34363461868,"f":33},{"t":3723500,"n":"Int52","d":3723500,"h":38658429164,"f":33},{"t":3723500,"n":"BigInt64","d":3723500,"h":42953396460,"f":33},{"t":3723500,"n":"Double","d":3723500,"h":47248363756,"f":33},{"t":3723500,"n":"Single","d":3723500,"h":51543331052,"f":33},{"t":3723500,"n":"IntPtr","d":3723500,"h":55838298348,"f":33},{"t":3723500,"n":"JSObject","d":3723500,"h":60133265644,"f":33},{"t":3723500,"n":"Object","d":3723500,"h":64428232940,"f":33},{"t":3723500,"n":"String","d":3723500,"h":68723200236,"f":33},{"t":3723500,"n":"DateTime","d":3723500,"h":77313134828,"f":33},{"t":3723500,"n":"DateTimeOffset","d":3723500,"h":81608102124,"f":33},{"t":3723500,"n":"Nullable","d":3723500,"h":85903069420,"f":33},{"t":3723500,"n":"Task","d":3723500,"h":90198036716,"f":33},{"t":3723500,"n":"Array","d":3723500,"h":94493004012,"f":33},{"t":3723500,"n":"ArraySegment","d":3723500,"h":98787971308,"f":33},{"t":3723500,"n":"Span","d":3723500,"h":103082938604,"f":33},{"t":3723500,"n":"Action","d":3723500,"h":107377905900,"f":33},{"t":3723500,"n":"Function","d":3723500,"h":111672873196,"f":33},{"t":3723500,"n":"DiscardNoWait","d":3723500,"h":115967840492,"f":33},{"t":3723500,"n":"TaskResolved","d":3723500,"h":124557775084,"f":33},{"t":3723500,"n":"TaskRejected","d":3723500,"h":128852742380,"f":33},{"t":3723500,"n":"TaskPreCreated","d":3723500,"h":133147709676,"f":33}],"c":[{"n":".ctor","o":"$ctor$3","d":3723500,"h":137442676972,"f":1}],"i":[57278465,63832065,57737217,57409537],"h":3723500}; }
            static get $b() { return $.$spc.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IComparable, $.$spc.System.ISpanFormattable, $.$spc.System.IFormattable, $.$spc.System.IConvertible ]; }
            static get $fullName() { return `System.Runtime.InteropServices.JavaScript.MarshalerType`; }
        });
        
        $asm.$cls("$srij.System.Runtime.InteropServices.JavaScript.JSException", ($self) => class JSException extends $.$spc.System.Exception
        {
            /*JSObject?*/ jsException = null;
            /*string?*/ combinedStackTrace = null;
            $ctor$5(/*string*/ msg)
            {
                super.$ctor$2(msg);
                {
                    this.jsException = null;
                    this.combinedStackTrace = null;
                }
                return this;
            }
            $ctor$6(/*string*/ msg, /*JSObject?*/ jsException)
            {
                super.$ctor$2(msg);
                {
                    this.jsException = jsException;
                    this.combinedStackTrace = null;
                }
                return this;
            }
            /*string? */ get StackTrace()
            {
                if ($.$spc.System.String.op_Inequality(this.combinedStackTrace, null))
                {
                    return this.combinedStackTrace;
                }
                /*var*/ let bs = super.StackTrace;
                if (this.jsException === null)
                {
                    return bs;
                }
                /*string?*/ let jsStackTrace = this.jsException.GetPropertyAsString("stack");
                this.jsException.Dispose();
                this.jsException = null;
                if ($.$spc.System.String.op_Equality(jsStackTrace, null))
                {
                    this.combinedStackTrace = bs;
                    return this.combinedStackTrace;
                }
                else if ($.$spc.System.String.StartsWith.call(jsStackTrace, this.Message + "\n"))
                {
                    jsStackTrace = $.$spc.System.String.Substring.call(jsStackTrace, ((this.Message.length + 1) | 0));
                }
                if ($.$spc.System.String.op_Equality(bs, null))
                {
                    this.combinedStackTrace = jsStackTrace;
                }
                this.combinedStackTrace = $.$spc.System.String.op_Inequality(bs, null) ? bs + $.$spc.System.Environment.NewLine + jsStackTrace : jsStackTrace;
                return this.combinedStackTrace;
            }
            static/*conventional*/ /*bool */ Equals(/*object?*/ obj)
            {
                let other;
                return $.$is(obj, $.$srij.System.Runtime.InteropServices.JavaScript.JSException, { set $v(v){ other = v; } }) && other.jsException === this.jsException;
            }
            //Static convention instance redirect
            /*bool */ Equals() { return $.$srij.System.Runtime.InteropServices.JavaScript.JSException.Equals.apply(this, arguments); }
            static/*conventional*/ /*int */ GetHashCode()
            {
                return this.jsException === null ? $.$spc.System.Object.GetHashCode.call(this) : (($.$spc.System.Object.GetHashCode.call(this) * $.$srij.System.Runtime.InteropServices.JavaScript.JSObject.GetHashCode.call(this.jsException)) | 0);
            }
            //Static convention instance redirect
            /*int */ GetHashCode() { return $.$srij.System.Runtime.InteropServices.JavaScript.JSException.GetHashCode.apply(this, arguments); }
            static/*conventional*/ /*string */ ToString()
            {
                return this.Message;
            }
            //Static convention instance redirect
            /*string */ ToString() { return $.$srij.System.Runtime.InteropServices.JavaScript.JSException.ToString.apply(this, arguments); }
            static $h = 446700;
            static $f = 0b10010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":47251457,"h":446700}; }
            static get $b() { return $.$spc.System.Exception; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.Runtime.Serialization.ISerializable ]; }
            static get $fullName() { return `System.Runtime.InteropServices.JavaScript.JSException`; }
        });
	});
})(window, window.NetJs.$boot(), ...window.NetJs.$require("NetJs.System.Private.CoreLib", "NetJs.System.Collections", "NetJs.System.Diagnostics.Tracing", "NetJs.System.Threading", "NetJs.System.Collections.Concurrent", "NetJs.System.Memory", "NetJs.System.Private.Uri", "NetJs.System.Runtime", "NetJs.System.Threading.ThreadPool", "NetJs.System.Threading.Channels"))