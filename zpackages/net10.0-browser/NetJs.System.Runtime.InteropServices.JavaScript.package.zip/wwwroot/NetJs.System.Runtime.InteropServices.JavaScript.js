
(function ($global, $, $$, $sc, $sdt, $st, $scc, $sm, $spu, $sr, $sttp, $stc) {
    "use strict";
    let _;
    
    
    
	$.$asm(
    "NetJs.System.Runtime.InteropServices.JavaScript", 
    {"h":65142,"f":"System.Runtime.InteropServices.JavaScript","v":"1.0.35.0","a":[{"t":114819073,"c":4409786369,"a":[{"v":"browser","t":1310721}]},{"t":115015681,"c":12999917569,"a":[{"v":".NETCoreApp,Version=v10.0","t":1310721}],"n":[{"n":"FrameworkDisplayName","v":".NET 10.0","t":1310721}]},{"t":73596929,"c":4368564225,"a":[{"v":"SIT","t":1310721}]},{"t":73662465,"c":4368629761,"a":[{"v":"Debug","t":1310721}]},{"t":74121217,"c":4369088513,"a":[{"v":"1.0.35.0","t":1310721}]},{"t":74252289,"c":4369219585,"a":[{"v":"1.0.35\u002Beff628fa5ab8bd29ec37e9c13a50148694bea088","t":1310721}]},{"t":75104257,"c":4370071553,"a":[{"v":"NetJs.System.Runtime.InteropServices.JavaScript","t":1310721}]},{"t":75235329,"c":4370202625,"a":[{"v":"NetJs.System.Runtime.InteropServices.JavaScript","t":1310721}]},{"t":75366401,"c":4370333697,"a":[{"v":"1.0.35.0","t":1310721}]},{"t":115081217,"c":4410048513,"a":[{"v":"browser1.0","t":1310721}]},{"t":114819073,"c":4409786369,"a":[{"v":"browser1.0","t":1310721}]}],"m":[]},
    function($asm)
	{
        
        
        $asm.$cls("$srij.System.Runtime.InteropServices.JavaScript.JSType", ($self) => class JSType extends $.$$.System.Object
        {
            $ctor$1()
            {
                super.$ctor();
                {
                }
                return this;
            }
            static $_Void;
            static get Void()
            {
                let $cls = $.$srij.System.Runtime.InteropServices.JavaScript.JSType;
                return $cls.$_Void ??= $asm.$ncls("$srij.System.Runtime.InteropServices.JavaScript.JSType.Void", ($self) => class Void extends $.$srij.System.Runtime.InteropServices.JavaScript.JSType
                {
                    $ctor$2()
                    {
                        super.$ctor$1();
                        {
                        }
                        return this;
                    }
                    static $h = 3669622;
                    static $f = 0b10000000010010001;
                    static $k = 1;
                    static $$md;
                    static get $md() { return this.$$md ??= {"b":2424438,"c":[{"n":".ctor","o":"$ctor$2","d":3669622,"h":4298636918,"f":16777224}],"d":2424438,"h":3669622}; }
                    static get $b() { return $.$srij.System.Runtime.InteropServices.JavaScript.JSType; }
                    static get $fullName() { return `System.Runtime.InteropServices.JavaScript.JSType.Void`; }
                }, $cls, ($v) => $cls.$_Void = $v);
            }
            static $_Discard;
            static get Discard()
            {
                let $cls = $.$srij.System.Runtime.InteropServices.JavaScript.JSType;
                return $cls.$_Discard ??= $asm.$ncls("$srij.System.Runtime.InteropServices.JavaScript.JSType.Discard", ($self) => class Discard extends $.$srij.System.Runtime.InteropServices.JavaScript.JSType
                {
                    $ctor$2()
                    {
                        super.$ctor$1();
                        {
                        }
                        return this;
                    }
                    static $h = 2817654;
                    static $f = 0b10000000010010001;
                    static $k = 1;
                    static $$md;
                    static get $md() { return this.$$md ??= {"b":2424438,"c":[{"n":".ctor","o":"$ctor$2","d":2817654,"h":4297784950,"f":16777224}],"d":2424438,"h":2817654}; }
                    static get $b() { return $.$srij.System.Runtime.InteropServices.JavaScript.JSType; }
                    static get $fullName() { return `System.Runtime.InteropServices.JavaScript.JSType.Discard`; }
                }, $cls, ($v) => $cls.$_Discard = $v);
            }
            static $_DiscardNoWait;
            static get DiscardNoWait()
            {
                let $cls = $.$srij.System.Runtime.InteropServices.JavaScript.JSType;
                return $cls.$_DiscardNoWait ??= $asm.$ncls("$srij.System.Runtime.InteropServices.JavaScript.JSType.DiscardNoWait", ($self) => class DiscardNoWait extends $.$srij.System.Runtime.InteropServices.JavaScript.JSType
                {
                    $ctor$2()
                    {
                        super.$ctor$1();
                        {
                        }
                        return this;
                    }
                    static $h = 2883190;
                    static $f = 0b10000000010010001;
                    static $k = 1;
                    static $$md;
                    static get $md() { return this.$$md ??= {"b":2424438,"c":[{"n":".ctor","o":"$ctor$2","d":2883190,"h":4297850486,"f":16777224}],"d":2424438,"h":2883190}; }
                    static get $b() { return $.$srij.System.Runtime.InteropServices.JavaScript.JSType; }
                    static get $fullName() { return `System.Runtime.InteropServices.JavaScript.JSType.DiscardNoWait`; }
                }, $cls, ($v) => $cls.$_DiscardNoWait = $v);
            }
            static $_Boolean;
            static get Boolean()
            {
                let $cls = $.$srij.System.Runtime.InteropServices.JavaScript.JSType;
                return $cls.$_Boolean ??= $asm.$ncls("$srij.System.Runtime.InteropServices.JavaScript.JSType.Boolean", ($self) => class Boolean extends $.$srij.System.Runtime.InteropServices.JavaScript.JSType
                {
                    $ctor$2()
                    {
                        super.$ctor$1();
                        {
                        }
                        return this;
                    }
                    static $h = 2686582;
                    static $f = 0b10000000010010001;
                    static $k = 1;
                    static $$md;
                    static get $md() { return this.$$md ??= {"b":2424438,"c":[{"n":".ctor","o":"$ctor$2","d":2686582,"h":4297653878,"f":16777224}],"d":2424438,"h":2686582}; }
                    static get $b() { return $.$srij.System.Runtime.InteropServices.JavaScript.JSType; }
                    static get $fullName() { return `System.Runtime.InteropServices.JavaScript.JSType.Boolean`; }
                }, $cls, ($v) => $cls.$_Boolean = $v);
            }
            static $_Number;
            static get Number()
            {
                let $cls = $.$srij.System.Runtime.InteropServices.JavaScript.JSType;
                return $cls.$_Number ??= $asm.$ncls("$srij.System.Runtime.InteropServices.JavaScript.JSType.Number", ($self) => class Number extends $.$srij.System.Runtime.InteropServices.JavaScript.JSType
                {
                    $ctor$2()
                    {
                        super.$ctor$1();
                        {
                        }
                        return this;
                    }
                    static $h = 3407478;
                    static $f = 0b10000000010010001;
                    static $k = 1;
                    static $$md;
                    static get $md() { return this.$$md ??= {"b":2424438,"c":[{"n":".ctor","o":"$ctor$2","d":3407478,"h":4298374774,"f":16777224}],"d":2424438,"h":3407478}; }
                    static get $b() { return $.$srij.System.Runtime.InteropServices.JavaScript.JSType; }
                    static get $fullName() { return `System.Runtime.InteropServices.JavaScript.JSType.Number`; }
                }, $cls, ($v) => $cls.$_Number = $v);
            }
            static $_BigInt;
            static get BigInt()
            {
                let $cls = $.$srij.System.Runtime.InteropServices.JavaScript.JSType;
                return $cls.$_BigInt ??= $asm.$ncls("$srij.System.Runtime.InteropServices.JavaScript.JSType.BigInt", ($self) => class BigInt extends $.$srij.System.Runtime.InteropServices.JavaScript.JSType
                {
                    $ctor$2()
                    {
                        super.$ctor$1();
                        {
                        }
                        return this;
                    }
                    static $h = 2621046;
                    static $f = 0b10000000010010001;
                    static $k = 1;
                    static $$md;
                    static get $md() { return this.$$md ??= {"b":2424438,"c":[{"n":".ctor","o":"$ctor$2","d":2621046,"h":4297588342,"f":16777224}],"d":2424438,"h":2621046}; }
                    static get $b() { return $.$srij.System.Runtime.InteropServices.JavaScript.JSType; }
                    static get $fullName() { return `System.Runtime.InteropServices.JavaScript.JSType.BigInt`; }
                }, $cls, ($v) => $cls.$_BigInt = $v);
            }
            static $_Date;
            static get Date()
            {
                let $cls = $.$srij.System.Runtime.InteropServices.JavaScript.JSType;
                return $cls.$_Date ??= $asm.$ncls("$srij.System.Runtime.InteropServices.JavaScript.JSType.Date", ($self) => class Date extends $.$srij.System.Runtime.InteropServices.JavaScript.JSType
                {
                    $ctor$2()
                    {
                        super.$ctor$1();
                        {
                        }
                        return this;
                    }
                    static $h = 2752118;
                    static $f = 0b10000000010010001;
                    static $k = 1;
                    static $$md;
                    static get $md() { return this.$$md ??= {"b":2424438,"c":[{"n":".ctor","o":"$ctor$2","d":2752118,"h":4297719414,"f":16777224}],"d":2424438,"h":2752118}; }
                    static get $b() { return $.$srij.System.Runtime.InteropServices.JavaScript.JSType; }
                    static get $fullName() { return `System.Runtime.InteropServices.JavaScript.JSType.Date`; }
                }, $cls, ($v) => $cls.$_Date = $v);
            }
            static $_String;
            static get String()
            {
                let $cls = $.$srij.System.Runtime.InteropServices.JavaScript.JSType;
                return $cls.$_String ??= $asm.$ncls("$srij.System.Runtime.InteropServices.JavaScript.JSType.String", ($self) => class String extends $.$srij.System.Runtime.InteropServices.JavaScript.JSType
                {
                    $ctor$2()
                    {
                        super.$ctor$1();
                        {
                        }
                        return this;
                    }
                    static $h = 3604086;
                    static $f = 0b10000000010010001;
                    static $k = 1;
                    static $$md;
                    static get $md() { return this.$$md ??= {"b":2424438,"c":[{"n":".ctor","o":"$ctor$2","d":3604086,"h":4298571382,"f":16777224}],"d":2424438,"h":3604086}; }
                    static get $b() { return $.$srij.System.Runtime.InteropServices.JavaScript.JSType; }
                    static get $fullName() { return `System.Runtime.InteropServices.JavaScript.JSType.String`; }
                }, $cls, ($v) => $cls.$_String = $v);
            }
            static $_Object;
            static get Object()
            {
                let $cls = $.$srij.System.Runtime.InteropServices.JavaScript.JSType;
                return $cls.$_Object ??= $asm.$ncls("$srij.System.Runtime.InteropServices.JavaScript.JSType.Object", ($self) => class Object extends $.$srij.System.Runtime.InteropServices.JavaScript.JSType
                {
                    $ctor$2()
                    {
                        super.$ctor$1();
                        {
                        }
                        return this;
                    }
                    static $h = 3473014;
                    static $f = 0b10000000010010001;
                    static $k = 1;
                    static $$md;
                    static get $md() { return this.$$md ??= {"b":2424438,"c":[{"n":".ctor","o":"$ctor$2","d":3473014,"h":4298440310,"f":16777224}],"d":2424438,"h":3473014}; }
                    static get $b() { return $.$srij.System.Runtime.InteropServices.JavaScript.JSType; }
                    static get $fullName() { return `System.Runtime.InteropServices.JavaScript.JSType.Object`; }
                }, $cls, ($v) => $cls.$_Object = $v);
            }
            static $_Error;
            static get Error()
            {
                let $cls = $.$srij.System.Runtime.InteropServices.JavaScript.JSType;
                return $cls.$_Error ??= $asm.$ncls("$srij.System.Runtime.InteropServices.JavaScript.JSType.Error", ($self) => class Error extends $.$srij.System.Runtime.InteropServices.JavaScript.JSType
                {
                    $ctor$2()
                    {
                        super.$ctor$1();
                        {
                        }
                        return this;
                    }
                    static $h = 2948726;
                    static $f = 0b10000000010010001;
                    static $k = 1;
                    static $$md;
                    static get $md() { return this.$$md ??= {"b":2424438,"c":[{"n":".ctor","o":"$ctor$2","d":2948726,"h":4297916022,"f":16777224}],"d":2424438,"h":2948726}; }
                    static get $b() { return $.$srij.System.Runtime.InteropServices.JavaScript.JSType; }
                    static get $fullName() { return `System.Runtime.InteropServices.JavaScript.JSType.Error`; }
                }, $cls, ($v) => $cls.$_Error = $v);
            }
            static $_MemoryView;
            static get MemoryView()
            {
                let $cls = $.$srij.System.Runtime.InteropServices.JavaScript.JSType;
                return $cls.$_MemoryView ??= $asm.$ncls("$srij.System.Runtime.InteropServices.JavaScript.JSType.MemoryView", ($self) => class MemoryView extends $.$srij.System.Runtime.InteropServices.JavaScript.JSType
                {
                    $ctor$2()
                    {
                        super.$ctor$1();
                        {
                        }
                        return this;
                    }
                    static $h = 3341942;
                    static $f = 0b10000000010010001;
                    static $k = 1;
                    static $$md;
                    static get $md() { return this.$$md ??= {"b":2424438,"c":[{"n":".ctor","o":"$ctor$2","d":3341942,"h":4298309238,"f":16777224}],"d":2424438,"h":3341942}; }
                    static get $b() { return $.$srij.System.Runtime.InteropServices.JavaScript.JSType; }
                    static get $fullName() { return `System.Runtime.InteropServices.JavaScript.JSType.MemoryView`; }
                }, $cls, ($v) => $cls.$_MemoryView = $v);
            }
            static $_Array$$;
            static Array$$(T)
            {
                let $cls = $.$srij.System.Runtime.InteropServices.JavaScript.JSType;
                return ($cls.$_Array$$ ??= $asm.$ncls("$srij.System.Runtime.InteropServices.JavaScript.JSType.Array<>", (T) => $asm.$gt("$srij.System.Runtime.InteropServices.JavaScript.JSType.Array<>", [T], ($self) => class Array$$ extends $.$srij.System.Runtime.InteropServices.JavaScript.JSType
                {
                    $ctor$2()
                    {
                        super.$ctor$1();
                        {
                        }
                        return this;
                    }
                    static $h = 2555510;
                    static $g = 1;
                    static $f = 0b10000000011010001;
                    static $k = 1;
                    static $$md;
                    static get $md() { return this.$$md ??= {"b":2424438,"c":[{"n":".ctor","o":"$ctor$2","d":this.$h,"h":Number(BigInt(this.$h)|0x100000000n),"f":16777224}],"g":[T?.$h??1507328],"r":1,"d":2424438,"h":this.$h}; }
                    static get $b() { return $.$srij.System.Runtime.InteropServices.JavaScript.JSType; }
                    static get $fullName() { return `System.Runtime.InteropServices.JavaScript.JSType.Array<${T?.$fullName}>`; }
                }), $cls, ($v) => $cls.$_Array$$ = $v))(T);
            }
            static $_Promise$$;
            static Promise$$(T)
            {
                let $cls = $.$srij.System.Runtime.InteropServices.JavaScript.JSType;
                return ($cls.$_Promise$$ ??= $asm.$ncls("$srij.System.Runtime.InteropServices.JavaScript.JSType.Promise<>", (T) => $asm.$gt("$srij.System.Runtime.InteropServices.JavaScript.JSType.Promise<>", [T], ($self) => class Promise$$ extends $.$srij.System.Runtime.InteropServices.JavaScript.JSType
                {
                    $ctor$2()
                    {
                        super.$ctor$1();
                        {
                        }
                        return this;
                    }
                    static $h = 3538550;
                    static $g = 1;
                    static $f = 0b10000000011010001;
                    static $k = 1;
                    static $$md;
                    static get $md() { return this.$$md ??= {"b":2424438,"c":[{"n":".ctor","o":"$ctor$2","d":this.$h,"h":Number(BigInt(this.$h)|0x100000000n),"f":16777224}],"g":[T?.$h??1507328],"r":1,"d":2424438,"h":this.$h}; }
                    static get $b() { return $.$srij.System.Runtime.InteropServices.JavaScript.JSType; }
                    static get $fullName() { return `System.Runtime.InteropServices.JavaScript.JSType.Promise<${T?.$fullName}>`; }
                }), $cls, ($v) => $cls.$_Promise$$ = $v))(T);
            }
            static $_Function;
            static get Function()
            {
                let $cls = $.$srij.System.Runtime.InteropServices.JavaScript.JSType;
                return $cls.$_Function ??= $asm.$ncls("$srij.System.Runtime.InteropServices.JavaScript.JSType.Function", ($self) => class Function extends $.$srij.System.Runtime.InteropServices.JavaScript.JSType
                {
                    $ctor$2()
                    {
                        super.$ctor$1();
                        {
                        }
                        return this;
                    }
                    static $h = 3014262;
                    static $f = 0b10000000010010001;
                    static $k = 1;
                    static $$md;
                    static get $md() { return this.$$md ??= {"b":2424438,"c":[{"n":".ctor","o":"$ctor$2","d":3014262,"h":4297981558,"f":16777224}],"d":2424438,"h":3014262}; }
                    static get $b() { return $.$srij.System.Runtime.InteropServices.JavaScript.JSType; }
                    static get $fullName() { return `System.Runtime.InteropServices.JavaScript.JSType.Function`; }
                }, $cls, ($v) => $cls.$_Function = $v);
            }
            static $_Function$$;
            static Function$$(T)
            {
                let $cls = $.$srij.System.Runtime.InteropServices.JavaScript.JSType;
                return ($cls.$_Function$$ ??= $asm.$ncls("$srij.System.Runtime.InteropServices.JavaScript.JSType.Function<>", (T) => $asm.$gt("$srij.System.Runtime.InteropServices.JavaScript.JSType.Function<>", [T], ($self) => class Function$$ extends $.$srij.System.Runtime.InteropServices.JavaScript.JSType
                {
                    $ctor$2()
                    {
                        super.$ctor$1();
                        {
                        }
                        return this;
                    }
                    static $h = 3276406;
                    static $g = 1;
                    static $f = 0b10000000011010001;
                    static $k = 1;
                    static $$md;
                    static get $md() { return this.$$md ??= {"b":2424438,"c":[{"n":".ctor","o":"$ctor$2","d":this.$h,"h":Number(BigInt(this.$h)|0x100000000n),"f":16777224}],"g":[T?.$h??1507328],"r":1,"d":2424438,"h":this.$h}; }
                    static get $b() { return $.$srij.System.Runtime.InteropServices.JavaScript.JSType; }
                    static get $fullName() { return `System.Runtime.InteropServices.JavaScript.JSType.Function<${T?.$fullName}>`; }
                }), $cls, ($v) => $cls.$_Function$$ = $v))(T);
            }
            static $_Function$$$;
            static Function$$$(T1, T2)
            {
                let $cls = $.$srij.System.Runtime.InteropServices.JavaScript.JSType;
                return ($cls.$_Function$$$ ??= $asm.$ncls("$srij.System.Runtime.InteropServices.JavaScript.JSType.Function<,>", (T1, T2) => $asm.$gt("$srij.System.Runtime.InteropServices.JavaScript.JSType.Function<,>", [T1, T2], ($self) => class Function$$$ extends $.$srij.System.Runtime.InteropServices.JavaScript.JSType
                {
                    $ctor$2()
                    {
                        super.$ctor$1();
                        {
                        }
                        return this;
                    }
                    static $h = 3210870;
                    static $g = 2;
                    static $f = 0b10000000011010001;
                    static $k = 1;
                    static $$md;
                    static get $md() { return this.$$md ??= {"b":2424438,"c":[{"n":".ctor","o":"$ctor$2","d":this.$h,"h":Number(BigInt(this.$h)|0x100000000n),"f":16777224}],"g":[T1?.$h??1507328,T2?.$h??1572864],"r":2,"d":2424438,"h":this.$h}; }
                    static get $b() { return $.$srij.System.Runtime.InteropServices.JavaScript.JSType; }
                    static get $fullName() { return `System.Runtime.InteropServices.JavaScript.JSType.Function<${T1?.$fullName},${T2?.$fullName}>`; }
                }), $cls, ($v) => $cls.$_Function$$$ = $v))(T1, T2);
            }
            static $_Function$$$$;
            static Function$$$$(T1, T2, T3)
            {
                let $cls = $.$srij.System.Runtime.InteropServices.JavaScript.JSType;
                return ($cls.$_Function$$$$ ??= $asm.$ncls("$srij.System.Runtime.InteropServices.JavaScript.JSType.Function<,,>", (T1, T2, T3) => $asm.$gt("$srij.System.Runtime.InteropServices.JavaScript.JSType.Function<,,>", [T1, T2, T3], ($self) => class Function$$$$ extends $.$srij.System.Runtime.InteropServices.JavaScript.JSType
                {
                    $ctor$2()
                    {
                        super.$ctor$1();
                        {
                        }
                        return this;
                    }
                    static $h = 3145334;
                    static $g = 3;
                    static $f = 0b10000000011010001;
                    static $k = 1;
                    static $$md;
                    static get $md() { return this.$$md ??= {"b":2424438,"c":[{"n":".ctor","o":"$ctor$2","d":this.$h,"h":Number(BigInt(this.$h)|0x100000000n),"f":16777224}],"g":[T1?.$h??1507328,T2?.$h??1572864,T3?.$h??1638400],"r":3,"d":2424438,"h":this.$h}; }
                    static get $b() { return $.$srij.System.Runtime.InteropServices.JavaScript.JSType; }
                    static get $fullName() { return `System.Runtime.InteropServices.JavaScript.JSType.Function<${T1?.$fullName},${T2?.$fullName},${T3?.$fullName}>`; }
                }), $cls, ($v) => $cls.$_Function$$$$ = $v))(T1, T2, T3);
            }
            static $_Function$$$$$;
            static Function$$$$$(T1, T2, T3, T4)
            {
                let $cls = $.$srij.System.Runtime.InteropServices.JavaScript.JSType;
                return ($cls.$_Function$$$$$ ??= $asm.$ncls("$srij.System.Runtime.InteropServices.JavaScript.JSType.Function<,,,>", (T1, T2, T3, T4) => $asm.$gt("$srij.System.Runtime.InteropServices.JavaScript.JSType.Function<,,,>", [T1, T2, T3, T4], ($self) => class Function$$$$$ extends $.$srij.System.Runtime.InteropServices.JavaScript.JSType
                {
                    $ctor$2()
                    {
                        super.$ctor$1();
                        {
                        }
                        return this;
                    }
                    static $h = 3079798;
                    static $g = 4;
                    static $f = 0b10000000011010001;
                    static $k = 1;
                    static $$md;
                    static get $md() { return this.$$md ??= {"b":2424438,"c":[{"n":".ctor","o":"$ctor$2","d":this.$h,"h":Number(BigInt(this.$h)|0x100000000n),"f":16777224}],"g":[T1?.$h??1507328,T2?.$h??1572864,T3?.$h??1638400,T4?.$h??1703936],"r":4,"d":2424438,"h":this.$h}; }
                    static get $b() { return $.$srij.System.Runtime.InteropServices.JavaScript.JSType; }
                    static get $fullName() { return `System.Runtime.InteropServices.JavaScript.JSType.Function<${T1?.$fullName},${T2?.$fullName},${T3?.$fullName},${T4?.$fullName}>`; }
                }), $cls, ($v) => $cls.$_Function$$$$$ = $v))(T1, T2, T3, T4);
            }
            static $_Any;
            static get Any()
            {
                let $cls = $.$srij.System.Runtime.InteropServices.JavaScript.JSType;
                return $cls.$_Any ??= $asm.$ncls("$srij.System.Runtime.InteropServices.JavaScript.JSType.Any", ($self) => class Any extends $.$srij.System.Runtime.InteropServices.JavaScript.JSType
                {
                    $ctor$2()
                    {
                        super.$ctor$1();
                        {
                        }
                        return this;
                    }
                    static $h = 2489974;
                    static $f = 0b10000000010010001;
                    static $k = 1;
                    static $$md;
                    static get $md() { return this.$$md ??= {"b":2424438,"c":[{"n":".ctor","o":"$ctor$2","d":2489974,"h":4297457270,"f":16777224}],"d":2424438,"h":2489974}; }
                    static get $b() { return $.$srij.System.Runtime.InteropServices.JavaScript.JSType; }
                    static get $fullName() { return `System.Runtime.InteropServices.JavaScript.JSType.Any`; }
                }, $cls, ($v) => $cls.$_Any = $v);
            }
            static $h = 2424438;
            static $f = 0b110001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"c":[{"n":".ctor","o":"$ctor$1","d":2424438,"h":4297391734,"f":16777224}],"j":[3669622,2817654,2883190,2686582,3407478,2621046,2752118,3604086,3473014,2948726,3341942,2555510,3538550,3014262,3276406,3210870,3145334,3079798,2489974],"h":2424438,"a":[{"t":114819073,"c":4409786369,"a":[{"v":"browser","t":1310721}]}]}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `System.Runtime.InteropServices.JavaScript.JSType`; }
        });
        
        $asm.$cls("$srij.Interop", ($self) => class Interop
        {
            static $_Runtime;
            static get Runtime()
            {
                let $cls = $.$srij.Interop;
                return $cls.$_Runtime ??= $asm.$ncls("$srij.Interop.Runtime", ($self) => class Runtime
                {
                    static $h = 196214;
                    static $f = 0b10000000000010000;
                    static $k = 1;
                    static $$md;
                    static get $md() { return this.$$md ??= {"b":131073,"d":130678,"h":196214}; }
                    static get $b() { return $.$$.System.Object; }
                    static get $fullName() { return `Interop.Runtime`; }
                }, $cls, ($v) => $cls.$_Runtime = $v);
            }
            static $h = 130678;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"j":[196214],"h":130678}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `Interop`; }
        });
        
        $asm.$cls("$srij.System.Runtime.InteropServices.JavaScript.JSHost", ($self) => class JSHost
        {
            static /*JSObject */ get GlobalThis()
            {
                return INTERNAL.get_global_this();
            }
            static /*JSObject */ get DotnetInstance()
            {
                return INTERNAL.get_dotnet_instance();
            }
            static /*Task<JSObject> */ ImportAsync(/*string*/ moduleName, /*string*/ moduleUrl, /*CancellationToken*/ cancellationToken)
            {
                return $.$srij.System.Runtime.InteropServices.JavaScript.JSHostImplementation.ImportAsync(moduleName, moduleUrl, cancellationToken);
            }
            static $h = 786038;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":2293366,"g":{"r":0,"d":0,"h":8590720630,"f":50331681},"n":"GlobalThis","d":786038,"h":4295753334,"f":2097185},{"p":2293366,"g":{"r":0,"d":0,"h":17180655222,"f":50331681},"n":"DotnetInstance","d":786038,"h":12885687926,"f":2097185}],"m":[{"r":$.$$.System.Threading.Tasks.Task$$($.$srij.System.Runtime.InteropServices.JavaScript.JSObject).$h,"p":[{"n":"moduleName","p":1310721},{"n":"moduleUrl","p":1310721},{"n":"cancellationToken","p":125829121,"f":65}],"n":"ImportAsync","d":786038,"h":21475622518,"f":16777249}],"h":786038,"a":[{"t":114819073,"c":4409786369,"a":[{"v":"browser","t":1310721}]}]}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `System.Runtime.InteropServices.JavaScript.JSHost`; }
        });
        
        $asm.$cls("$srij.System.Runtime.InteropServices.JavaScript.JSHostImplementation", ($self) => class JSHostImplementation
        {
            static $_ToManagedCallback;
            static get ToManagedCallback()
            {
                let $cls = $.$srij.System.Runtime.InteropServices.JavaScript.JSHostImplementation;
                return $cls.$_ToManagedCallback ??= $asm.$ncls("$srij.System.Runtime.InteropServices.JavaScript.JSHostImplementation.ToManagedCallback", ($self) => class ToManagedCallback extends $.$$.System.MulticastDelegate
                {
                    $ctor(/*object*/ target, fn, anmodel)
                    {
                        this.$target = target;
                        this.$nativeFunction = fn;
                        if (anmodel) this.$nfmodel = anmodel;
                        if (typeof(target) === 'object') this._target = target;
                        return this;
                    }
                    /*void*/ Invoke(/**/ arguments_buffer)
                    {
                        return this.$nativeFunction.call(this.$target, arguments_buffer);
                    }
                    static $h = 1179254;
                    static $f = 0b10000000010000000;
                    static $k = 5;
                    static $$md;
                    static get $md() { return this.$$md ??= {"b":66191361,"m":[{"r":65537,"p":[{"n":"arguments_buffer","p":$.$typePointer($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument).$h}],"n":"Invoke","d":1179254,"h":8591113846,"f":16777345},{"r":57016321,"p":[{"n":"arguments_buffer","p":$.$typePointer($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument).$h},{"n":"callback","p":14548993},{"n":"object","p":131073}],"n":"BeginInvoke","d":1179254,"h":12886081142,"f":16777345},{"r":65537,"p":[{"n":"result","p":57016321}],"n":"EndInvoke","d":1179254,"h":17181048438,"f":16777345}],"c":[{"p":[{"n":"object","p":131073},{"n":"method","p":786433}],"n":".ctor","o":"$ctor$5","d":1179254,"h":4296146550,"f":16777217}],"i":[57212929,113246209],"d":851574,"h":1179254}; }
                    static get $b() { return $.$$.System.MulticastDelegate; }
                    static $$i;
                    static get $i() { return this.$$i ??= [ $.$$.System.ICloneable, $.$$.System.Runtime.Serialization.ISerializable ]; }
                    static get $fullName() { return `System.Runtime.InteropServices.JavaScript.JSHostImplementation.ToManagedCallback`; }
                }, $cls, ($v) => $cls.$_ToManagedCallback = $v);
            }
            static $_PromiseHolder;
            static get PromiseHolder()
            {
                let $cls = $.$srij.System.Runtime.InteropServices.JavaScript.JSHostImplementation;
                return $cls.$_PromiseHolder ??= $asm.$ncls("$srij.System.Runtime.InteropServices.JavaScript.JSHostImplementation.PromiseHolder", ($self) => class PromiseHolder extends $.$$.System.Object
                {
                    /*bool*/ IsDisposed = false;
                    /*nint*/ GCHandle = 0;
                    /*ToManagedCallback?*/ Callback = null;
                    /*JSProxyContext*/ ProxyContext = null;
                    $ctor$2(/*JSProxyContext*/ targetContext)
                    {
                        super.$ctor();
                        {
                            this.GCHandle = $.$$.System.Runtime.InteropServices.GCHandle.op_Explicit($.$$.System.Runtime.InteropServices.GCHandle.Alloc(this, 2/*GCHandleType.Normal*/));
                            this.ProxyContext = targetContext;
                        }
                        return this;
                    }
                    $ctor$1(/*JSProxyContext*/ targetContext, /*nint*/ gcvHandle)
                    {
                        super.$ctor();
                        {
                            this.GCHandle = gcvHandle;
                            this.ProxyContext = targetContext;
                        }
                        return this;
                    }
                    static $h = 1048182;
                    static $f = 0b10000000010010001;
                    static $k = 1;
                    static $$md;
                    static get $md() { return this.$$md ??= {"b":131073,"l":[{"t":262145,"n":"IsDisposed","d":1048182,"h":4296015478,"f":4194305},{"t":786433,"n":"GCHandle","d":1048182,"h":8590982774,"f":4194305},{"t":1179254,"n":"Callback","d":1048182,"h":12885950070,"f":4194305},{"t":2358902,"n":"ProxyContext","d":1048182,"h":17180917366,"f":4194305}],"c":[{"p":[{"n":"targetContext","p":2358902}],"n":".ctor","o":"$ctor$2","d":1048182,"h":21475884662,"f":16777217},{"p":[{"n":"targetContext","p":2358902},{"n":"gcvHandle","p":786433}],"n":".ctor","o":"$ctor$1","d":1048182,"h":25770851958,"f":16777217}],"d":851574,"h":1048182}; }
                    static get $b() { return $.$$.System.Object; }
                    static get $fullName() { return `System.Runtime.InteropServices.JavaScript.JSHostImplementation.PromiseHolder`; }
                }, $cls, ($v) => $cls.$_PromiseHolder = $v);
            }
            static $_PromiseHolderState;
            static get PromiseHolderState()
            {
                let $cls = $.$srij.System.Runtime.InteropServices.JavaScript.JSHostImplementation;
                return $cls.$_PromiseHolderState ??= $asm.$nstr("$srij.System.Runtime.InteropServices.JavaScript.JSHostImplementation.PromiseHolderState", ($self) => class PromiseHolderState extends $.$$.System.ValueType
                {
                    /*int*/  get IsResolving() { return this.$getField(0, $.$$.System.Int32); }
                    /*int*/  set IsResolving(value) { this.$setField(0, $.$$.System.Int32, value); }
                    //default value type constructor
                    $ctor$2()
                    {
                        return this;
                    }
                    Clone($copy)
                    {
                        let copy = $copy ?? new this.constructor();
                        copy.IsResolving = this.IsResolving;
                        return copy;
                    }
                    //default member initializer
                    constructor()
                    {
                        super();
                        this.IsResolving = 0;
                    }
                    static $h = 1113718;
                    static $z = 4;
                    static $f = 0b10100010000001010000001;
                    static $k = 2;
                    static $$md;
                    static get $md() { return this.$$md ??= {"b":196609,"l":[{"t":655361,"n":"IsResolving","d":1113718,"h":4296081014,"f":4194305,"a":[{"t":103940097,"c":4398907393,"a":[{"v":0,"t":655361}]}]}],"c":[{"n":".ctor","o":"$ctor$2","d":1113718,"h":8591048310,"f":16777217}],"d":851574,"h":1113718,"a":[{"t":109772801,"c":4404740097,"a":[{"v":2,"t":105250817}]}]}; }
                    static get $b() { return $.$$.System.ValueType; }
                    static get $fullName() { return `System.Runtime.InteropServices.JavaScript.JSHostImplementation.PromiseHolderState`; }
                }, $cls, ($v) => $cls.$_PromiseHolderState = $v);
            }
            static $_IntPtrAndHandle;
            static get IntPtrAndHandle()
            {
                let $cls = $.$srij.System.Runtime.InteropServices.JavaScript.JSHostImplementation;
                return $cls.$_IntPtrAndHandle ??= $asm.$nstr("$srij.System.Runtime.InteropServices.JavaScript.JSHostImplementation.IntPtrAndHandle", ($self) => class IntPtrAndHandle extends $.$$.System.ValueType
                {
                    /*IntPtr*/  get ptr() { return this.$getField(0, 4); }
                    /*IntPtr*/  set ptr(value) { this.$setField(0, 4, value); }
                    /*RuntimeMethodHandle*/  get methodHandle() { return this.$getField(0, 4); }
                    /*RuntimeMethodHandle*/  set methodHandle(value) { this.$setField(0, 4, value); }
                    /*RuntimeTypeHandle*/  get typeHandle() { return this.$getField(0, 4); }
                    /*RuntimeTypeHandle*/  set typeHandle(value) { this.$setField(0, 4, value); }
                    //default value type constructor
                    $ctor$2()
                    {
                        return this;
                    }
                    Clone($copy)
                    {
                        let copy = $copy ?? new this.constructor();
                        copy.ptr = this.ptr;
                        copy.methodHandle = this.methodHandle.Clone();
                        copy.typeHandle = this.typeHandle.Clone();
                        return copy;
                    }
                    //default member initializer
                    constructor()
                    {
                        super();
                        this.ptr = 0;
                        this.methodHandle = $.$default($.$$.System.RuntimeMethodHandle);
                        this.typeHandle = $.$default($.$$.System.RuntimeTypeHandle);
                    }
                    static $h = 917110;
                    static $z = 4;
                    static $f = 0b100010000001010000001;
                    static $k = 2;
                    static $$md;
                    static get $md() { return this.$$md ??= {"b":196609,"l":[{"t":786433,"n":"ptr","d":917110,"h":4295884406,"f":4194312,"a":[{"t":103940097,"c":4398907393,"a":[{"v":0,"t":655361}]}]},{"t":115474433,"n":"methodHandle","d":917110,"h":8590851702,"f":4194312,"a":[{"t":103940097,"c":4398907393,"a":[{"v":0,"t":655361}]}]},{"t":115933185,"n":"typeHandle","d":917110,"h":12885818998,"f":4194312,"a":[{"t":103940097,"c":4398907393,"a":[{"v":0,"t":655361}]}]}],"c":[{"n":".ctor","o":"$ctor$2","d":917110,"h":17180786294,"f":16777217}],"d":851574,"h":917110,"a":[{"t":109772801,"c":4404740097,"a":[{"v":2,"t":105250817}]}]}; }
                    static get $b() { return $.$$.System.ValueType; }
                    static get $fullName() { return `System.Runtime.InteropServices.JavaScript.JSHostImplementation.IntPtrAndHandle`; }
                }, $cls, ($v) => $cls.$_IntPtrAndHandle = $v);
            }
            static $_JSThreadBlockingMode;
            static get JSThreadBlockingMode()
            {
                let $cls = $.$srij.System.Runtime.InteropServices.JavaScript.JSHostImplementation;
                return $cls.$_JSThreadBlockingMode ??= $asm.$nstr("$srij.System.Runtime.InteropServices.JavaScript.JSHostImplementation.JSThreadBlockingMode", ($self) => class JSThreadBlockingMode extends $.$$.System.Enum
                {
                    static PreventSynchronousJSExport = 0;
                    static ThrowWhenBlockingWait = 1;
                    static WarnWhenBlockingWait = 2;
                    static DangerousAllowBlockingWait = 100;
                    static $map;
                    static get Map()
                    {
                        return this.$map ??= 
                        {
                            "PreventSynchronousJSExport": 0n,
                            "ThrowWhenBlockingWait": 1n,
                            "WarnWhenBlockingWait": 2n,
                            "DangerousAllowBlockingWait": 100n
                        };
                    }
                    static $h = 982646;
                    static $z = 4;
                    static $f = 0b110000011010001001;
                    static $k = 4;
                    static get $eut() { return $.$$.System.Int32; }
                    static $$md;
                    static get $md() { return this.$$md ??= {"b":1048577,"u":655361,"l":[{"t":982646,"n":"PreventSynchronousJSExport","d":982646,"h":4295949942,"f":4194337},{"t":982646,"n":"ThrowWhenBlockingWait","d":982646,"h":8590917238,"f":4194337},{"t":982646,"n":"WarnWhenBlockingWait","d":982646,"h":12885884534,"f":4194337},{"t":982646,"n":"DangerousAllowBlockingWait","d":982646,"h":17180851830,"f":4194337}],"c":[{"n":".ctor","o":"$ctor$3","d":982646,"h":21475819126,"f":16777217}],"i":[57278465,63832065,57737217,57409537],"d":851574,"h":982646}; }
                    static get $b() { return $.$$.System.Enum; }
                    static $$i;
                    static get $i() { return this.$$i ??= [ $.$$.System.IComparable, $.$$.System.ISpanFormattable, $.$$.System.IFormattable, $.$$.System.IConvertible ]; }
                    static get $fullName() { return `System.Runtime.InteropServices.JavaScript.JSHostImplementation.JSThreadBlockingMode`; }
                }, $cls, ($v) => $cls.$_JSThreadBlockingMode = $v);
            }
            /*string*/ static TaskGetResultName = null;
            /*MethodInfo?*/ static s_taskGetResultMethodInfo = null;
            static /*bool */ GetTaskResultDynamic(/*Task*/ task, /*out object?*/ value)
            {
                /*var*/ let type = $.$$.System.Object.GetType.call(task);
                if ($.$$.System.Type.op_Equality$1(type, $.$$.System.Threading.Tasks.Task.$type))
                {
                    value.$v = null;
                    return false;
                }
                /*MethodInfo*/ let method = $.$srij.System.Runtime.InteropServices.JavaScript.JSHostImplementation.GetTaskResultMethodInfo(type);
                if ($.$$.System.Reflection.MethodInfo.op_Inequality$2(method, null))
                {
                    value.$v = method.Invoke(task, null);
                    return true;
                }
                throw new $.$$.System.InvalidOperationException().$ctor$9();
            }
            static /*MethodInfo */ GetTaskResultMethodInfo(/*Type*/ taskType)
            {
                if ($.$$.System.Type.op_Inequality$1(taskType, null))
                {
                    if ($.$$.System.Reflection.MethodInfo.op_Equality$2($.$srij.System.Runtime.InteropServices.JavaScript.JSHostImplementation.s_taskGetResultMethodInfo, null))
                    {
                        $.$srij.System.Runtime.InteropServices.JavaScript.JSHostImplementation.s_taskGetResultMethodInfo = $.$$.System.Threading.Tasks.Task$$().$type.GetMethod$12("get_Result"/*TaskGetResultName*/);
                    }
                    /*MethodInfo?*/ let getter = taskType.GetMethod$12("get_Result"/*TaskGetResultName*/);
                    if ($.$$.System.Reflection.MethodInfo.op_Inequality$2(getter, null) && getter.HasSameMetadataDefinitionAs($.$srij.System.Runtime.InteropServices.JavaScript.JSHostImplementation.s_taskGetResultMethodInfo))
                    {
                        return getter;
                    }
                }
                throw new $.$$.System.InvalidOperationException().$ctor$9();
            }
            static /*void */ ThrowException(/*ref JSMarshalerArgument*/ arg)
            {
                /*Exception?*/ let ex;
                arg.$v.ToManaged$12($.$ref(() => ex, ($v) => ex = $v, $.$$.System.Exception));
                if (ex !== null)
                {
                    throw ex;
                }
                throw new $.$$.System.InvalidOperationException().$ctor$9();
            }
            static /*Task<JSObject> *//*async*/  ImportAsync(/*string*/ moduleName, /*string*/ moduleUrl, /*CancellationToken*/ cancellationToken)
            {
                return $.$$.NetJs.AsyncResolver.Async($.$$.System.Threading.Tasks.Task$$($.$srij.System.Runtime.InteropServices.JavaScript.JSObject), $.$srij.System.Runtime.InteropServices.JavaScript.JSObject, async () => 
                {
                    /*Task<JSObject>*/ let modulePromise = INTERNAL.dynamic_import(moduleName, moduleUrl);
                    /*var*/ let wrappedTask = $.$srij.System.Runtime.InteropServices.JavaScript.JSHostImplementation.CancellationHelper(modulePromise, cancellationToken);
                    return await wrappedTask.ConfigureAwait$3(1/*ConfigureAwaitOptions.ContinueOnCapturedContext*/ | 4/*ConfigureAwaitOptions.ForceYielding*/);
                });
            }
            static /*Task<JSObject> *//*async*/  CancellationHelper(/*Task<JSObject>*/ jsTask, /*CancellationToken*/ cancellationToken)
            {
                return $.$$.NetJs.AsyncResolver.Async($.$$.System.Threading.Tasks.Task$$($.$srij.System.Runtime.InteropServices.JavaScript.JSObject), $.$srij.System.Runtime.InteropServices.JavaScript.JSObject, async () => 
                {
                    if (jsTask.IsCompletedSuccessfully)
                    {
                        return jsTask.Result;
                    }
                    let receiveRegistration = null;
                    try
                    {
                        receiveRegistration = cancellationToken.Register$4(new ($.$$.System.Action$$($.$$.System.Object))().$ctor($.$srij.System.Runtime.InteropServices.JavaScript.JSHostImplementation, /*static*/ (/*s*/ s) =>
                        {
                            $.$srij.System.Runtime.InteropServices.JavaScript.CancelablePromise.CancelPromise($.$cast(s, $.$$.System.Threading.Tasks.Task$$($.$srij.System.Runtime.InteropServices.JavaScript.JSObject)));
                        }, {"r":65537,"p":[{"n":"s","p":131073}],"n":"","d":851574,"h":0,"f":17825826}), jsTask);
                        return await jsTask.ConfigureAwait$2(false);
                    }
                    finally
                    {
                        receiveRegistration?.System$IDisposable$Dispose();
                    }
                });
            }
            static /*JSFunctionBinding */ GetMethodSignature(/*ReadOnlySpan<JSMarshalerType>*/ types, /*string?*/ functionName, /*string?*/ moduleName)
            {
                /*int*/ let argsCount = ((types.Length - 1) | 0);
                /*int*/ let size = ((32/*JSFunctionBinding.JSBindingHeader.JSMarshalerSignatureHeaderSize*/ + ((((((argsCount + 2) | 0)) * $.$srij.System.Runtime.InteropServices.JavaScript.JSFunctionBinding.JSBindingType.$z) | 0))) | 0);
                /*int*/ let functionNameBytes = 0;
                /*int*/ let functionNameOffset = 0;
                if ($.$$.System.String.op_Inequality(functionName, null))
                {
                    functionNameOffset = size;
                    size += 4;
                    functionNameBytes = ((functionName.length * 2) | 0);
                    size += functionNameBytes;
                }
                /*int*/ let moduleNameBytes = 0;
                /*int*/ let moduleNameOffset = 0;
                if ($.$$.System.String.op_Inequality(moduleName, null))
                {
                    moduleNameOffset = size;
                    size += 4;
                    moduleNameBytes = ((moduleName.length * 2) | 0);
                    size += moduleNameBytes;
                }
                /*IntPtr*/ let buffer = $.$$.System.Runtime.InteropServices.Marshal.AllocHGlobal(size);
                /*var*/ let signature = (() =>
                {
                    //new $.$srij.System.Runtime.InteropServices.JavaScript.JSFunctionBinding()
                    const $t1 = $.$srij.System.Runtime.InteropServices.JavaScript.JSFunctionBinding;
                    const $i1 = new $t1();
                    $i1.$ctor$1();
                    $i1.Header = $.$cast(buffer, $.$typePointer($.$srij.System.Runtime.InteropServices.JavaScript.JSFunctionBinding.JSBindingHeader));
                    $i1.Sigs = $.$cast((buffer + 32/*JSFunctionBinding.JSBindingHeader.JSMarshalerSignatureHeaderSize*/ + (((2 * $.$srij.System.Runtime.InteropServices.JavaScript.JSFunctionBinding.JSBindingType.$z) | 0))), $.$typePointer($.$srij.System.Runtime.InteropServices.JavaScript.JSFunctionBinding.JSBindingType));
                    return $i1;
                })();
                signature.Version = 2;
                signature.ArgumentCount = argsCount;
                signature.Exception = $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType.Exception._signatureType;
                signature.Result = types.get_Item(0).$v._signatureType;
                signature.ImportHandle = ($.$srij.System.Runtime.InteropServices.JavaScript.JSFunctionBinding.nextImportHandle++ | 0);
                signature.FunctionName = functionName;
                for(/*int*/ let i = 0; i < argsCount; i++)
                {
                    /*var*/ let type = signature.Sigs.SetAt(types.get_Item(((i + 1) | 0)).$v._signatureType, i);
                }
                signature.IsAsync = types.get_Item(0).$v._signatureType.Type === 20/*MarshalerType.Task*/;
                signature.IsDiscardNoWait = types.get_Item(0).$v._signatureType.Type === 26/*MarshalerType.DiscardNoWait*/;
                signature.Header.GetAt(0).ImportHandle = signature.ImportHandle;
                signature.Header.GetAt(0).FunctionNameLength = functionNameBytes;
                signature.Header.GetAt(0).FunctionNameOffset = functionNameOffset;
                signature.Header.GetAt(0).ModuleNameLength = moduleNameBytes;
                signature.Header.GetAt(0).ModuleNameOffset = moduleNameOffset;
                if (functionNameBytes !== 0)
                {
                    /*fixed*/ 
                    {
                        /*void**/ let fn = $.$$.System.String.GetPinnableReference.call(functionName);
                        $.$$.System.Runtime.CompilerServices.Unsafe.CopyBlock($.$cast(buffer, $.$typePointer($.$$.System.Byte)).Add(functionNameOffset), fn, (functionNameBytes >>> 0));
                    }
                }
                if (moduleNameBytes !== 0)
                {
                    /*fixed*/ 
                    {
                        /*void**/ let mn = $.$$.System.String.GetPinnableReference.call(moduleName);
                        $.$$.System.Runtime.CompilerServices.Unsafe.CopyBlock($.$cast(buffer, $.$typePointer($.$$.System.Byte)).Add(moduleNameOffset), mn, (moduleNameBytes >>> 0));
                    }
                }
                return signature;
            }
            static /*void */ FreeMethodSignatureBuffer(/*JSFunctionBinding*/ signature)
            {
                $.$$.System.Runtime.InteropServices.Marshal.FreeHGlobal($.$cast(signature.Header, $.$$.System.IntPtr));
                signature.Header = null;
                signature.Sigs = null;
            }
            static /*void */ LoadLazyAssembly(/*byte[]*/ dllBytes, /*byte[]?*/ pdbBytes)
            {
                if (pdbBytes === null)
                {
                    $.$$.System.Runtime.Loader.AssemblyLoadContext.Default.LoadFromStream$1(new $.$$.System.IO.MemoryStream().$ctor$8(dllBytes));
                }
                else 
                {
                    $.$$.System.Runtime.Loader.AssemblyLoadContext.Default.LoadFromStream(new $.$$.System.IO.MemoryStream().$ctor$8(dllBytes), new $.$$.System.IO.MemoryStream().$ctor$8(pdbBytes));
                }
            }
            static /*void */ LoadSatelliteAssembly(/*byte[]*/ dllBytes)
            {
                $.$$.System.Runtime.Loader.AssemblyLoadContext.Default.LoadFromStream$1(new $.$$.System.IO.MemoryStream().$ctor$8(dllBytes));
            }
            static /*Task<int>? */ CallEntrypoint(/*IntPtr*/ assemblyNamePtr, /*string?[]?*/ args, /*bool*/ waitForDebugger)
            {
                try
                {
                    /*void**/ let ptr;
                    $.$srij.Interop.Runtime.AssemblyGetEntryPoint(assemblyNamePtr, waitForDebugger ? 1 : 0, $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateObjectReferenceT($.$typePointer($.$$.System.Void), () => ptr, ($v) => ptr = $v, null));
                    /*RuntimeMethodHandle*/ let methodHandle = $.$srij.System.Runtime.InteropServices.JavaScript.JSHostImplementation.GetMethodHandleFromIntPtr($.$$.System.IntPtr.op_Explicit$4(ptr));
                    /*MethodInfo?*/ let method = $.$as($.$$.System.Reflection.MethodBase.GetMethodFromHandle$1(methodHandle), $.$$.System.Reflection.MethodInfo);
                    if ($.$$.System.Reflection.MethodInfo.op_Equality$2(method, null))
                    {
                        throw new $.$$.System.InvalidOperationException().$ctor$12($.$srij.System.SR.CannotResolveManagedEntrypointHandle);
                    }
                    /*object[]*/ let argsToPass = $.$$.System.Array.Empty($.$$.System.Object);
                    /*Task<int>?*/ let result = null;
                    /*var*/ let parameterInfos = method.GetParameters();
                    if (parameterInfos.length > 0 && $.$$.System.Type.op_Equality$1($.$$.System.Array.$ReadT1.call(parameterInfos, 0).ParameterType, $.$typeArray($.$$.System.String).$type))
                    {
                        argsToPass = $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$$.System.Object), [args ?? $.$$.System.Array.Empty($.$$.System.String)], [-1], null);
                    }
                    if ($.$$.System.Type.op_Equality$1(method.ReturnType, $.$$.System.Void.$type))
                    {
                        method.Invoke(null, argsToPass);
                    }
                    else if ($.$$.System.Type.op_Equality$1(method.ReturnType, $.$$.System.Int32.$type))
                    {
                        /*int*/ let intResult = $.$cast(method.Invoke(null, argsToPass), $.$$.System.Int32);
                        result = $.$$.System.Threading.Tasks.Task.FromResult($.$$.System.Int32, intResult);
                    }
                    else if ($.$$.System.Type.op_Equality$1(method.ReturnType, $.$$.System.Threading.Tasks.Task.$type))
                    {
                        /*Task*/ let methodResult = $.$cast(method.Invoke(null, argsToPass), $.$$.System.Threading.Tasks.Task);
                        /*TaskCompletionSource<int>*/ let tcs = new ($.$$.System.Threading.Tasks.TaskCompletionSource$$($.$$.System.Int32))().$ctor$1();
                        result = tcs.Task;
                        methodResult.ContinueWith$10(new ($.$$.System.Action$$($.$$.System.Threading.Tasks.Task))().$ctor(this,  (/*t*/ t) =>
                        {
                            if (t.IsFaulted)
                            {
                                tcs.SetException$1(t.Exception);
                            }
                            else 
                            {
                                tcs.SetResult(0);
                            }
                        }, {"r":65537,"p":[{"n":"t","p":133169153}],"n":"","d":851574,"h":0,"f":17825794}), $.$$.System.Threading.Tasks.TaskScheduler.Default);
                    }
                    else if ($.$$.System.Type.op_Equality$1(method.ReturnType, $.$$.System.Threading.Tasks.Task$$($.$$.System.Int32).$type))
                    {
                        result = $.$cast(method.Invoke(null, argsToPass), $.$$.System.Threading.Tasks.Task$$($.$$.System.Int32));
                    }
                    else 
                    {
                        throw new $.$$.System.InvalidOperationException().$ctor$12($.$srij.System.SR.Format$6($.$srij.System.SR.ReturnTypeNotSupportedForMain, method.ReturnType.FullName));
                    }
                    return result;
                }
                catch(ex)
                {
                    let refEx;
                    if ($.$is(ex, $.$$.System.Reflection.TargetInvocationException, { set $v(v){ refEx = v; } }) && refEx.InnerException !== null)
                    {
                        ex = refEx.InnerException;
                    }
                    return $.$$.System.Threading.Tasks.Task.FromException$1($.$$.System.Int32, ex);
                }
            }
            static /*Task */ BindAssemblyExports(/*string?*/ assemblyName)
            {
                $.$srij.Interop.Runtime.BindAssemblyExports($.$$.System.Runtime.InteropServices.Marshal.StringToCoTaskMemUTF8(assemblyName));
                return $.$$.System.Threading.Tasks.Task.CompletedTask;
            }
            static /*JSFunctionBinding */ BindManagedFunction(/*string*/ fullyQualifiedName, /*int*/ signatureHash, /*ReadOnlySpan<JSMarshalerType>*/ signatures)
            {
                /*var*/ let  [ assemblyName, nameSpace, shortClassName, methodName ] = $.$destructure($.$srij.System.Runtime.InteropServices.JavaScript.JSHostImplementation.ParseFQN(fullyQualifiedName));
                /*IntPtr*/ let monoMethod;
                $.$srij.Interop.Runtime.GetAssemblyExport($.$$.System.Runtime.InteropServices.Marshal.StringToCoTaskMemUTF8(assemblyName), $.$$.System.Runtime.InteropServices.Marshal.StringToCoTaskMemUTF8(nameSpace), $.$$.System.Runtime.InteropServices.Marshal.StringToCoTaskMemUTF8(shortClassName), $.$$.System.Runtime.InteropServices.Marshal.StringToCoTaskMemUTF8(methodName), signatureHash, $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateObjectReferenceT($.$$.System.IntPtr, () => monoMethod, ($v) => monoMethod = $v, null));
                if (monoMethod === $.$$.System.IntPtr.Zero)
                {
                    $.$$.System.Environment.FailFast$2(`Can't find ${nameSpace}${shortClassName}${methodName} in ${assemblyName}.dll`);
                }
                /*var*/ let signature = $.$srij.System.Runtime.InteropServices.JavaScript.JSHostImplementation.GetMethodSignature(signatures, null, null);
                INTERNAL.mono_wasm_bind_cs_function(monoMethod, assemblyName, nameSpace, shortClassName, methodName, signatureHash, $.$cast(signature.Header, $.$$.System.IntPtr));
                $.$srij.System.Runtime.InteropServices.JavaScript.JSHostImplementation.FreeMethodSignatureBuffer(signature);
                return signature;
            }
            static /*RuntimeMethodHandle */ GetMethodHandleFromIntPtr(/*IntPtr*/ ptr)
            {
                /*var*/ let temp = (() =>
                {
                    //new $.$srij.System.Runtime.InteropServices.JavaScript.JSHostImplementation.IntPtrAndHandle()
                    const $t1 = $.$srij.System.Runtime.InteropServices.JavaScript.JSHostImplementation.IntPtrAndHandle;
                    const $i1 = new $t1();
                    $i1.ptr = ptr;
                    return $i1;
                })();
                return temp.methodHandle;
            }
            static /*int */ SmallIndexOf(/*string*/ s, /*char*/ ch, /*int*/ direction)
            {
                if (s.length < 1)
                {
                    return -1;
                }
                /*int*/ let start_index = (direction > 0) ? 0 : ((s.length - 1) | 0), end_index = (direction > 0) ? ((s.length - 1) | 0) : 0;
                for(/*int*/ let i = start_index; i !== end_index; i += direction)
                {
                    if ($.$$.System.String.get_Chars.call(s, i) === ch)
                    {
                        return i;
                    }
                }
                return -1;
            }
            static /*string */ SmallTrim(/*string*/ s)
            {
                if (s.length < 1)
                {
                    return s;
                }
                /*int*/ let head = 0, tail = ((s.length - 1) | 0);
                while(head < s.length)
                {
                    if ($.$$.System.String.get_Chars.call(s, head) === /* */ 32)
                    {
                        head++;
                    }
                    else 
                    {
                        break;
                    }
                }
                while(tail >= 0)
                {
                    if ($.$$.System.String.get_Chars.call(s, tail) === /* */ 32)
                    {
                        tail--;
                    }
                    else 
                    {
                        break;
                    }
                }
                if ((head > 0) || (tail < ((s.length - 1) | 0)))
                {
                    return $.$$.System.String.Substring.call(s, head, ((((tail - head) | 0) + 1) | 0));
                }
                else 
                {
                    return s;
                }
            }
            static /*(string assemblyName, string nameSpace, string shortClassName, string methodName) */ ParseFQN(/*string*/ fqn)
            {
                /*var*/ let assembly = $.$$.System.String.Substring.call(fqn, (($.$srij.System.Runtime.InteropServices.JavaScript.JSHostImplementation.SmallIndexOf(fqn, /*[*/ 91, 1) + 1) | 0), (($.$srij.System.Runtime.InteropServices.JavaScript.JSHostImplementation.SmallIndexOf(fqn, /*]*/ 93, 1) - 1) | 0));
                fqn = $.$srij.System.Runtime.InteropServices.JavaScript.JSHostImplementation.SmallTrim(fqn);
                fqn = $.$$.System.String.Substring$1.call(fqn, (($.$srij.System.Runtime.InteropServices.JavaScript.JSHostImplementation.SmallIndexOf(fqn, /*]*/ 93, 1) + 1) | 0));
                fqn = $.$srij.System.Runtime.InteropServices.JavaScript.JSHostImplementation.SmallTrim(fqn);
                /*var*/ let methodName = $.$$.System.String.Substring$1.call(fqn, (($.$srij.System.Runtime.InteropServices.JavaScript.JSHostImplementation.SmallIndexOf(fqn, /*:*/ 58, 1) + 1) | 0));
                /*var*/ let className = $.$$.System.String.Substring.call(fqn, 0, $.$srij.System.Runtime.InteropServices.JavaScript.JSHostImplementation.SmallIndexOf(fqn, /*:*/ 58, 1));
                className = $.$srij.System.Runtime.InteropServices.JavaScript.JSHostImplementation.SmallTrim(className);
                /*var*/ let nameSpace = "";
                /*var*/ let shortClassName = className;
                /*var*/ let idx = $.$srij.System.Runtime.InteropServices.JavaScript.JSHostImplementation.SmallIndexOf(fqn, /*.*/ 46, -1);
                if (idx !== -1)
                {
                    nameSpace = $.$$.System.String.Substring.call(fqn, 0, idx);
                    shortClassName = $.$$.System.String.Substring$1.call(className, ((idx + 1) | 0));
                }
                if ($.$$.System.String.IsNullOrEmpty(assembly))
                {
                    throw new $.$$.System.InvalidOperationException().$ctor$12("No assembly name specified " + fqn);
                }
                if ($.$$.System.String.IsNullOrEmpty(className))
                {
                    throw new $.$$.System.InvalidOperationException().$ctor$12("No class name specified " + fqn);
                }
                if ($.$$.System.String.IsNullOrEmpty(methodName))
                {
                    throw new $.$$.System.InvalidOperationException().$ctor$12("No method name specified " + fqn);
                }
                return new ($.$$.System.ValueTuple$$$$$($.$$.System.String, $.$$.System.String, $.$$.System.String, $.$$.System.String))().$ctor$3(assembly, nameSpace, shortClassName, methodName);
            }
            //Static Initializer
            static $sinit()
            {
                {
                    this.TaskGetResultName = "get_Result";
                }
            }
            static $h = 851574;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"m":[{"r":262145,"p":[{"n":"task","p":133169153},{"n":"value","p":131073,"f":2}],"n":"GetTaskResultDynamic","d":851574,"h":34360589942,"f":16777249},{"r":79626241,"p":[{"n":"taskType","p":142475265}],"n":"GetTaskResultMethodInfo","d":851574,"h":38655557238,"f":16777249},{"r":65537,"p":[{"n":"arg","p":1375862,"f":4}],"n":"ThrowException","d":851574,"h":42950524534,"f":16777249},{"r":$.$$.System.Threading.Tasks.Task$$($.$srij.System.Runtime.InteropServices.JavaScript.JSObject).$h,"p":[{"n":"moduleName","p":1310721},{"n":"moduleUrl","p":1310721},{"n":"cancellationToken","p":125829121}],"n":"ImportAsync","d":851574,"h":47245491830,"f":16781345},{"r":$.$$.System.Threading.Tasks.Task$$($.$srij.System.Runtime.InteropServices.JavaScript.JSObject).$h,"p":[{"n":"jsTask","p":$.$$.System.Threading.Tasks.Task$$($.$srij.System.Runtime.InteropServices.JavaScript.JSObject).$h},{"n":"cancellationToken","p":125829121}],"n":"CancellationHelper","d":851574,"h":51540459126,"f":16781345},{"r":589430,"p":[{"n":"types","p":$.$$.System.ReadOnlySpan$$($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType).$h},{"n":"functionName","p":1310721},{"n":"moduleName","p":1310721}],"n":"GetMethodSignature","d":851574,"h":55835426422,"f":16777249},{"r":65537,"p":[{"n":"signature","p":589430}],"n":"FreeMethodSignatureBuffer","d":851574,"h":60130393718,"f":16777249},{"r":65537,"p":[{"n":"dllBytes","p":$.$typeArray($.$$.System.Byte).$h},{"n":"pdbBytes","p":$.$typeArray($.$$.System.Byte).$h}],"n":"LoadLazyAssembly","d":851574,"h":64425361014,"f":16777249},{"r":65537,"p":[{"n":"dllBytes","p":$.$typeArray($.$$.System.Byte).$h}],"n":"LoadSatelliteAssembly","d":851574,"h":68720328310,"f":16777249},{"r":$.$$.System.Threading.Tasks.Task$$($.$$.System.Int32).$h,"p":[{"n":"assemblyNamePtr","p":786433},{"n":"args","p":$.$typeArray($.$$.System.String).$h},{"n":"waitForDebugger","p":262145}],"n":"CallEntrypoint","d":851574,"h":73015295606,"f":16777249},{"r":133169153,"p":[{"n":"assemblyName","p":1310721}],"n":"BindAssemblyExports","d":851574,"h":77310262902,"f":16777249},{"r":589430,"p":[{"n":"fullyQualifiedName","p":1310721},{"n":"signatureHash","p":655361},{"n":"signatures","p":$.$$.System.ReadOnlySpan$$($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType).$h}],"n":"BindManagedFunction","d":851574,"h":81605230198,"f":16777249},{"r":115474433,"p":[{"n":"ptr","p":786433}],"n":"GetMethodHandleFromIntPtr","d":851574,"h":85900197494,"f":16777249},{"r":655361,"p":[{"n":"s","p":1310721},{"n":"ch","p":458753},{"n":"direction","p":655361,"f":65,"v":1}],"n":"SmallIndexOf","d":851574,"h":90195164790,"f":16777250},{"r":1310721,"p":[{"n":"s","p":1310721}],"n":"SmallTrim","d":851574,"h":94490132086,"f":16777250},{"r":$.$$.System.ValueTuple$$$$$($.$$.System.String, $.$$.System.String, $.$$.System.String, $.$$.System.String).$h,"p":[{"n":"fqn","p":1310721}],"n":"ParseFQN","d":851574,"h":98785099382,"f":16777249}],"l":[{"t":1310721,"n":"TaskGetResultName","d":851574,"h":25770655350,"f":4194338},{"t":79626241,"n":"s_taskGetResultMethodInfo","d":851574,"h":30065622646,"f":4194338}],"j":[1179254,1048182,1113718,917110,982646],"h":851574}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `System.Runtime.InteropServices.JavaScript.JSHostImplementation`; }
        });
        
        $asm.$cls("$srij.System.Runtime.InteropServices.JavaScript.JavaScriptImports", ($self) => class JavaScriptImports
        {
            static /*bool */ HasProperty(/*global::System.Runtime.InteropServices.JavaScript.JSObject*/ self, /*string*/ propertyName)
            {
                if ($.$srij.System.Runtime.InteropServices.JavaScript.JavaScriptImports.__signature_HasProperty_393970128 === null)
                {
                    $.$srij.System.Runtime.InteropServices.JavaScript.JavaScriptImports.__signature_HasProperty_393970128 = $.$srij.System.Runtime.InteropServices.JavaScript.JSFunctionBinding.BindJSFunction("INTERNAL.has_property", null, $.$$.System.ReadOnlySpan$$($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType).op_Implicit$1($.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType), [$.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType.Boolean, $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType.JSObject, $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType.String], null, null)));
                }
                {
                    /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ let ____arg_exception_native;
                    /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ let ____arg_return_native;
                    /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ let __self_native;
                    /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ let __propertyName_native;
                    /*bool*/ let __retVal;
                    /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ let __retVal_native;
                    $.$$.System.Runtime.CompilerServices.Unsafe.SkipInit($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument, $.$ref(() => ____arg_return_native, ($v) => ____arg_return_native = $v, $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument));
                    ____arg_return_native.Initialize();
                    $.$$.System.Runtime.CompilerServices.Unsafe.SkipInit($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument, $.$ref(() => ____arg_exception_native, ($v) => ____arg_exception_native = $v, $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument));
                    ____arg_exception_native.Initialize();
                    $.$$.System.Runtime.CompilerServices.Unsafe.SkipInit($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument, $.$ref(() => __propertyName_native, ($v) => __propertyName_native = $v, $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument));
                    $.$$.System.Runtime.CompilerServices.Unsafe.SkipInit($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument, $.$ref(() => __self_native, ($v) => __self_native = $v, $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument));
                    __propertyName_native.ToJS$35(propertyName);
                    __self_native.ToJS$39(self);
                    {
                        __retVal_native = __InvokeJSFunction.call(this, ____arg_exception_native.Clone(), ____arg_return_native.Clone(), __self_native.Clone(), __propertyName_native.Clone());
                    }
                    __retVal_native.ToManaged$4($.$ref(() => __retVal, ($v) => __retVal = $v, $.$$.System.Boolean));
                    return __retVal;
                }
                /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/  function __InvokeJSFunction(/*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ ____arg_exception_native, /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ ____arg_return_native, /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ __self_native, /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ __propertyName_native)
                {
                    /*global::System.Span<global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument>*/ let __arguments_buffer = $.$$.System.Span$$($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument).op_Implicit$2($.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument), [____arg_exception_native, ____arg_return_native, __self_native, __propertyName_native], null, null));
                    $.$srij.System.Runtime.InteropServices.JavaScript.JSFunctionBinding.InvokeJS($.$srij.System.Runtime.InteropServices.JavaScript.JavaScriptImports.__signature_HasProperty_393970128, __arguments_buffer);
                    return __arguments_buffer.get_Item(1).$v;
                }
            }
            /*global::System.Runtime.InteropServices.JavaScript.JSFunctionBinding*/ static __signature_HasProperty_393970128 = null;
            static /*string */ GetTypeOfProperty(/*global::System.Runtime.InteropServices.JavaScript.JSObject*/ self, /*string*/ propertyName)
            {
                if ($.$srij.System.Runtime.InteropServices.JavaScript.JavaScriptImports.__signature_GetTypeOfProperty_1139574135 === null)
                {
                    $.$srij.System.Runtime.InteropServices.JavaScript.JavaScriptImports.__signature_GetTypeOfProperty_1139574135 = $.$srij.System.Runtime.InteropServices.JavaScript.JSFunctionBinding.BindJSFunction("INTERNAL.get_typeof_property", null, $.$$.System.ReadOnlySpan$$($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType).op_Implicit$1($.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType), [$.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType.String, $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType.JSObject, $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType.String], null, null)));
                }
                {
                    /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ let ____arg_exception_native;
                    /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ let ____arg_return_native;
                    /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ let __self_native;
                    /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ let __propertyName_native;
                    /*string*/ let __retVal;
                    /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ let __retVal_native;
                    $.$$.System.Runtime.CompilerServices.Unsafe.SkipInit($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument, $.$ref(() => ____arg_return_native, ($v) => ____arg_return_native = $v, $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument));
                    ____arg_return_native.Initialize();
                    $.$$.System.Runtime.CompilerServices.Unsafe.SkipInit($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument, $.$ref(() => ____arg_exception_native, ($v) => ____arg_exception_native = $v, $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument));
                    ____arg_exception_native.Initialize();
                    $.$$.System.Runtime.CompilerServices.Unsafe.SkipInit($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument, $.$ref(() => __propertyName_native, ($v) => __propertyName_native = $v, $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument));
                    $.$$.System.Runtime.CompilerServices.Unsafe.SkipInit($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument, $.$ref(() => __self_native, ($v) => __self_native = $v, $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument));
                    __propertyName_native.ToJS$35(propertyName);
                    __self_native.ToJS$39(self);
                    {
                        __retVal_native = __InvokeJSFunction.call(this, ____arg_exception_native.Clone(), ____arg_return_native.Clone(), __self_native.Clone(), __propertyName_native.Clone());
                    }
                    __retVal_native.ToManaged$35($.$ref(() => __retVal, ($v) => __retVal = $v, $.$$.System.String));
                    return __retVal;
                }
                /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/  function __InvokeJSFunction(/*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ ____arg_exception_native, /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ ____arg_return_native, /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ __self_native, /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ __propertyName_native)
                {
                    /*global::System.Span<global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument>*/ let __arguments_buffer = $.$$.System.Span$$($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument).op_Implicit$2($.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument), [____arg_exception_native, ____arg_return_native, __self_native, __propertyName_native], null, null));
                    $.$srij.System.Runtime.InteropServices.JavaScript.JSFunctionBinding.InvokeJS($.$srij.System.Runtime.InteropServices.JavaScript.JavaScriptImports.__signature_GetTypeOfProperty_1139574135, __arguments_buffer);
                    return __arguments_buffer.get_Item(1).$v;
                }
            }
            /*global::System.Runtime.InteropServices.JavaScript.JSFunctionBinding*/ static __signature_GetTypeOfProperty_1139574135 = null;
            static /*bool */ GetPropertyAsBoolean(/*global::System.Runtime.InteropServices.JavaScript.JSObject*/ self, /*string*/ propertyName)
            {
                if ($.$srij.System.Runtime.InteropServices.JavaScript.JavaScriptImports.__signature_GetPropertyAsBoolean_393970128 === null)
                {
                    $.$srij.System.Runtime.InteropServices.JavaScript.JavaScriptImports.__signature_GetPropertyAsBoolean_393970128 = $.$srij.System.Runtime.InteropServices.JavaScript.JSFunctionBinding.BindJSFunction("INTERNAL.get_property", null, $.$$.System.ReadOnlySpan$$($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType).op_Implicit$1($.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType), [$.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType.Boolean, $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType.JSObject, $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType.String], null, null)));
                }
                {
                    /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ let ____arg_exception_native;
                    /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ let ____arg_return_native;
                    /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ let __self_native;
                    /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ let __propertyName_native;
                    /*bool*/ let __retVal;
                    /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ let __retVal_native;
                    $.$$.System.Runtime.CompilerServices.Unsafe.SkipInit($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument, $.$ref(() => ____arg_return_native, ($v) => ____arg_return_native = $v, $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument));
                    ____arg_return_native.Initialize();
                    $.$$.System.Runtime.CompilerServices.Unsafe.SkipInit($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument, $.$ref(() => ____arg_exception_native, ($v) => ____arg_exception_native = $v, $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument));
                    ____arg_exception_native.Initialize();
                    $.$$.System.Runtime.CompilerServices.Unsafe.SkipInit($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument, $.$ref(() => __propertyName_native, ($v) => __propertyName_native = $v, $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument));
                    $.$$.System.Runtime.CompilerServices.Unsafe.SkipInit($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument, $.$ref(() => __self_native, ($v) => __self_native = $v, $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument));
                    __propertyName_native.ToJS$35(propertyName);
                    __self_native.ToJS$39(self);
                    {
                        __retVal_native = __InvokeJSFunction.call(this, ____arg_exception_native.Clone(), ____arg_return_native.Clone(), __self_native.Clone(), __propertyName_native.Clone());
                    }
                    __retVal_native.ToManaged$4($.$ref(() => __retVal, ($v) => __retVal = $v, $.$$.System.Boolean));
                    return __retVal;
                }
                /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/  function __InvokeJSFunction(/*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ ____arg_exception_native, /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ ____arg_return_native, /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ __self_native, /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ __propertyName_native)
                {
                    /*global::System.Span<global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument>*/ let __arguments_buffer = $.$$.System.Span$$($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument).op_Implicit$2($.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument), [____arg_exception_native, ____arg_return_native, __self_native, __propertyName_native], null, null));
                    $.$srij.System.Runtime.InteropServices.JavaScript.JSFunctionBinding.InvokeJS($.$srij.System.Runtime.InteropServices.JavaScript.JavaScriptImports.__signature_GetPropertyAsBoolean_393970128, __arguments_buffer);
                    return __arguments_buffer.get_Item(1).$v;
                }
            }
            /*global::System.Runtime.InteropServices.JavaScript.JSFunctionBinding*/ static __signature_GetPropertyAsBoolean_393970128 = null;
            static /*int */ GetPropertyAsInt32(/*global::System.Runtime.InteropServices.JavaScript.JSObject*/ self, /*string*/ propertyName)
            {
                if ($.$srij.System.Runtime.InteropServices.JavaScript.JavaScriptImports.__signature_GetPropertyAsInt32_1813830729 === null)
                {
                    $.$srij.System.Runtime.InteropServices.JavaScript.JavaScriptImports.__signature_GetPropertyAsInt32_1813830729 = $.$srij.System.Runtime.InteropServices.JavaScript.JSFunctionBinding.BindJSFunction("INTERNAL.get_property", null, $.$$.System.ReadOnlySpan$$($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType).op_Implicit$1($.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType), [$.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType.Int32, $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType.JSObject, $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType.String], null, null)));
                }
                {
                    /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ let ____arg_exception_native;
                    /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ let ____arg_return_native;
                    /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ let __self_native;
                    /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ let __propertyName_native;
                    /*int*/ let __retVal;
                    /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ let __retVal_native;
                    $.$$.System.Runtime.CompilerServices.Unsafe.SkipInit($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument, $.$ref(() => ____arg_return_native, ($v) => ____arg_return_native = $v, $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument));
                    ____arg_return_native.Initialize();
                    $.$$.System.Runtime.CompilerServices.Unsafe.SkipInit($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument, $.$ref(() => ____arg_exception_native, ($v) => ____arg_exception_native = $v, $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument));
                    ____arg_exception_native.Initialize();
                    $.$$.System.Runtime.CompilerServices.Unsafe.SkipInit($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument, $.$ref(() => __propertyName_native, ($v) => __propertyName_native = $v, $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument));
                    $.$$.System.Runtime.CompilerServices.Unsafe.SkipInit($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument, $.$ref(() => __self_native, ($v) => __self_native = $v, $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument));
                    __propertyName_native.ToJS$35(propertyName);
                    __self_native.ToJS$39(self);
                    {
                        __retVal_native = __InvokeJSFunction.call(this, ____arg_exception_native.Clone(), ____arg_return_native.Clone(), __self_native.Clone(), __propertyName_native.Clone());
                    }
                    __retVal_native.ToManaged$14($.$ref(() => __retVal, ($v) => __retVal = $v, $.$$.System.Int32));
                    return __retVal;
                }
                /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/  function __InvokeJSFunction(/*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ ____arg_exception_native, /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ ____arg_return_native, /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ __self_native, /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ __propertyName_native)
                {
                    /*global::System.Span<global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument>*/ let __arguments_buffer = $.$$.System.Span$$($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument).op_Implicit$2($.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument), [____arg_exception_native, ____arg_return_native, __self_native, __propertyName_native], null, null));
                    $.$srij.System.Runtime.InteropServices.JavaScript.JSFunctionBinding.InvokeJS($.$srij.System.Runtime.InteropServices.JavaScript.JavaScriptImports.__signature_GetPropertyAsInt32_1813830729, __arguments_buffer);
                    return __arguments_buffer.get_Item(1).$v;
                }
            }
            /*global::System.Runtime.InteropServices.JavaScript.JSFunctionBinding*/ static __signature_GetPropertyAsInt32_1813830729 = null;
            static /*double */ GetPropertyAsDouble(/*global::System.Runtime.InteropServices.JavaScript.JSObject*/ self, /*string*/ propertyName)
            {
                if ($.$srij.System.Runtime.InteropServices.JavaScript.JavaScriptImports.__signature_GetPropertyAsDouble_705601847 === null)
                {
                    $.$srij.System.Runtime.InteropServices.JavaScript.JavaScriptImports.__signature_GetPropertyAsDouble_705601847 = $.$srij.System.Runtime.InteropServices.JavaScript.JSFunctionBinding.BindJSFunction("INTERNAL.get_property", null, $.$$.System.ReadOnlySpan$$($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType).op_Implicit$1($.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType), [$.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType.Double, $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType.JSObject, $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType.String], null, null)));
                }
                {
                    /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ let ____arg_exception_native;
                    /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ let ____arg_return_native;
                    /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ let __self_native;
                    /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ let __propertyName_native;
                    /*double*/ let __retVal;
                    /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ let __retVal_native;
                    $.$$.System.Runtime.CompilerServices.Unsafe.SkipInit($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument, $.$ref(() => ____arg_return_native, ($v) => ____arg_return_native = $v, $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument));
                    ____arg_return_native.Initialize();
                    $.$$.System.Runtime.CompilerServices.Unsafe.SkipInit($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument, $.$ref(() => ____arg_exception_native, ($v) => ____arg_exception_native = $v, $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument));
                    ____arg_exception_native.Initialize();
                    $.$$.System.Runtime.CompilerServices.Unsafe.SkipInit($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument, $.$ref(() => __propertyName_native, ($v) => __propertyName_native = $v, $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument));
                    $.$$.System.Runtime.CompilerServices.Unsafe.SkipInit($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument, $.$ref(() => __self_native, ($v) => __self_native = $v, $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument));
                    __propertyName_native.ToJS$35(propertyName);
                    __self_native.ToJS$39(self);
                    {
                        __retVal_native = __InvokeJSFunction.call(this, ____arg_exception_native.Clone(), ____arg_return_native.Clone(), __self_native.Clone(), __propertyName_native.Clone());
                    }
                    __retVal_native.ToManaged$10($.$ref(() => __retVal, ($v) => __retVal = $v, $.$$.System.Double));
                    return __retVal;
                }
                /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/  function __InvokeJSFunction(/*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ ____arg_exception_native, /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ ____arg_return_native, /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ __self_native, /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ __propertyName_native)
                {
                    /*global::System.Span<global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument>*/ let __arguments_buffer = $.$$.System.Span$$($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument).op_Implicit$2($.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument), [____arg_exception_native, ____arg_return_native, __self_native, __propertyName_native], null, null));
                    $.$srij.System.Runtime.InteropServices.JavaScript.JSFunctionBinding.InvokeJS($.$srij.System.Runtime.InteropServices.JavaScript.JavaScriptImports.__signature_GetPropertyAsDouble_705601847, __arguments_buffer);
                    return __arguments_buffer.get_Item(1).$v;
                }
            }
            /*global::System.Runtime.InteropServices.JavaScript.JSFunctionBinding*/ static __signature_GetPropertyAsDouble_705601847 = null;
            static /*string */ GetPropertyAsString(/*global::System.Runtime.InteropServices.JavaScript.JSObject*/ self, /*string*/ propertyName)
            {
                if ($.$srij.System.Runtime.InteropServices.JavaScript.JavaScriptImports.__signature_GetPropertyAsString_1139574135 === null)
                {
                    $.$srij.System.Runtime.InteropServices.JavaScript.JavaScriptImports.__signature_GetPropertyAsString_1139574135 = $.$srij.System.Runtime.InteropServices.JavaScript.JSFunctionBinding.BindJSFunction("INTERNAL.get_property", null, $.$$.System.ReadOnlySpan$$($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType).op_Implicit$1($.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType), [$.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType.String, $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType.JSObject, $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType.String], null, null)));
                }
                {
                    /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ let ____arg_exception_native;
                    /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ let ____arg_return_native;
                    /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ let __self_native;
                    /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ let __propertyName_native;
                    /*string*/ let __retVal;
                    /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ let __retVal_native;
                    $.$$.System.Runtime.CompilerServices.Unsafe.SkipInit($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument, $.$ref(() => ____arg_return_native, ($v) => ____arg_return_native = $v, $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument));
                    ____arg_return_native.Initialize();
                    $.$$.System.Runtime.CompilerServices.Unsafe.SkipInit($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument, $.$ref(() => ____arg_exception_native, ($v) => ____arg_exception_native = $v, $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument));
                    ____arg_exception_native.Initialize();
                    $.$$.System.Runtime.CompilerServices.Unsafe.SkipInit($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument, $.$ref(() => __propertyName_native, ($v) => __propertyName_native = $v, $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument));
                    $.$$.System.Runtime.CompilerServices.Unsafe.SkipInit($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument, $.$ref(() => __self_native, ($v) => __self_native = $v, $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument));
                    __propertyName_native.ToJS$35(propertyName);
                    __self_native.ToJS$39(self);
                    {
                        __retVal_native = __InvokeJSFunction.call(this, ____arg_exception_native.Clone(), ____arg_return_native.Clone(), __self_native.Clone(), __propertyName_native.Clone());
                    }
                    __retVal_native.ToManaged$35($.$ref(() => __retVal, ($v) => __retVal = $v, $.$$.System.String));
                    return __retVal;
                }
                /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/  function __InvokeJSFunction(/*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ ____arg_exception_native, /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ ____arg_return_native, /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ __self_native, /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ __propertyName_native)
                {
                    /*global::System.Span<global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument>*/ let __arguments_buffer = $.$$.System.Span$$($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument).op_Implicit$2($.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument), [____arg_exception_native, ____arg_return_native, __self_native, __propertyName_native], null, null));
                    $.$srij.System.Runtime.InteropServices.JavaScript.JSFunctionBinding.InvokeJS($.$srij.System.Runtime.InteropServices.JavaScript.JavaScriptImports.__signature_GetPropertyAsString_1139574135, __arguments_buffer);
                    return __arguments_buffer.get_Item(1).$v;
                }
            }
            /*global::System.Runtime.InteropServices.JavaScript.JSFunctionBinding*/ static __signature_GetPropertyAsString_1139574135 = null;
            static /*global::System.Runtime.InteropServices.JavaScript.JSObject */ GetPropertyAsJSObject(/*global::System.Runtime.InteropServices.JavaScript.JSObject*/ self, /*string*/ propertyName)
            {
                if ($.$srij.System.Runtime.InteropServices.JavaScript.JavaScriptImports.__signature_GetPropertyAsJSObject_1480020778 === null)
                {
                    $.$srij.System.Runtime.InteropServices.JavaScript.JavaScriptImports.__signature_GetPropertyAsJSObject_1480020778 = $.$srij.System.Runtime.InteropServices.JavaScript.JSFunctionBinding.BindJSFunction("INTERNAL.get_property", null, $.$$.System.ReadOnlySpan$$($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType).op_Implicit$1($.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType), [$.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType.JSObject, $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType.JSObject, $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType.String], null, null)));
                }
                {
                    /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ let ____arg_exception_native;
                    /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ let ____arg_return_native;
                    /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ let __self_native;
                    /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ let __propertyName_native;
                    /*global::System.Runtime.InteropServices.JavaScript.JSObject*/ let __retVal;
                    /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ let __retVal_native;
                    $.$$.System.Runtime.CompilerServices.Unsafe.SkipInit($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument, $.$ref(() => ____arg_return_native, ($v) => ____arg_return_native = $v, $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument));
                    ____arg_return_native.Initialize();
                    $.$$.System.Runtime.CompilerServices.Unsafe.SkipInit($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument, $.$ref(() => ____arg_exception_native, ($v) => ____arg_exception_native = $v, $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument));
                    ____arg_exception_native.Initialize();
                    $.$$.System.Runtime.CompilerServices.Unsafe.SkipInit($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument, $.$ref(() => __propertyName_native, ($v) => __propertyName_native = $v, $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument));
                    $.$$.System.Runtime.CompilerServices.Unsafe.SkipInit($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument, $.$ref(() => __self_native, ($v) => __self_native = $v, $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument));
                    __propertyName_native.ToJS$35(propertyName);
                    __self_native.ToJS$39(self);
                    {
                        __retVal_native = __InvokeJSFunction.call(this, ____arg_exception_native.Clone(), ____arg_return_native.Clone(), __self_native.Clone(), __propertyName_native.Clone());
                    }
                    __retVal_native.ToManaged$39($.$ref(() => __retVal, ($v) => __retVal = $v, $.$srij.System.Runtime.InteropServices.JavaScript.JSObject));
                    return __retVal;
                }
                /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/  function __InvokeJSFunction(/*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ ____arg_exception_native, /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ ____arg_return_native, /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ __self_native, /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ __propertyName_native)
                {
                    /*global::System.Span<global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument>*/ let __arguments_buffer = $.$$.System.Span$$($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument).op_Implicit$2($.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument), [____arg_exception_native, ____arg_return_native, __self_native, __propertyName_native], null, null));
                    $.$srij.System.Runtime.InteropServices.JavaScript.JSFunctionBinding.InvokeJS($.$srij.System.Runtime.InteropServices.JavaScript.JavaScriptImports.__signature_GetPropertyAsJSObject_1480020778, __arguments_buffer);
                    return __arguments_buffer.get_Item(1).$v;
                }
            }
            /*global::System.Runtime.InteropServices.JavaScript.JSFunctionBinding*/ static __signature_GetPropertyAsJSObject_1480020778 = null;
            static /*byte[] */ GetPropertyAsByteArray(/*global::System.Runtime.InteropServices.JavaScript.JSObject*/ self, /*string*/ propertyName)
            {
                if ($.$srij.System.Runtime.InteropServices.JavaScript.JavaScriptImports.__signature_GetPropertyAsByteArray_657551312 === null)
                {
                    $.$srij.System.Runtime.InteropServices.JavaScript.JavaScriptImports.__signature_GetPropertyAsByteArray_657551312 = $.$srij.System.Runtime.InteropServices.JavaScript.JSFunctionBinding.BindJSFunction("INTERNAL.get_property", null, $.$$.System.ReadOnlySpan$$($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType).op_Implicit$1($.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType), [$.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType.Array($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType.Byte), $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType.JSObject, $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType.String], null, null)));
                }
                {
                    /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ let ____arg_exception_native;
                    /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ let ____arg_return_native;
                    /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ let __self_native;
                    /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ let __propertyName_native;
                    /*byte[]*/ let __retVal;
                    /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ let __retVal_native;
                    $.$$.System.Runtime.CompilerServices.Unsafe.SkipInit($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument, $.$ref(() => ____arg_return_native, ($v) => ____arg_return_native = $v, $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument));
                    ____arg_return_native.Initialize();
                    $.$$.System.Runtime.CompilerServices.Unsafe.SkipInit($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument, $.$ref(() => ____arg_exception_native, ($v) => ____arg_exception_native = $v, $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument));
                    ____arg_exception_native.Initialize();
                    $.$$.System.Runtime.CompilerServices.Unsafe.SkipInit($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument, $.$ref(() => __propertyName_native, ($v) => __propertyName_native = $v, $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument));
                    $.$$.System.Runtime.CompilerServices.Unsafe.SkipInit($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument, $.$ref(() => __self_native, ($v) => __self_native = $v, $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument));
                    __propertyName_native.ToJS$35(propertyName);
                    __self_native.ToJS$39(self);
                    {
                        __retVal_native = __InvokeJSFunction.call(this, ____arg_exception_native.Clone(), ____arg_return_native.Clone(), __self_native.Clone(), __propertyName_native.Clone());
                    }
                    __retVal_native.ToManaged$6($.$ref(() => __retVal, ($v) => __retVal = $v, $.$typeArray($.$$.System.Byte)));
                    return __retVal;
                }
                /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/  function __InvokeJSFunction(/*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ ____arg_exception_native, /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ ____arg_return_native, /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ __self_native, /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ __propertyName_native)
                {
                    /*global::System.Span<global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument>*/ let __arguments_buffer = $.$$.System.Span$$($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument).op_Implicit$2($.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument), [____arg_exception_native, ____arg_return_native, __self_native, __propertyName_native], null, null));
                    $.$srij.System.Runtime.InteropServices.JavaScript.JSFunctionBinding.InvokeJS($.$srij.System.Runtime.InteropServices.JavaScript.JavaScriptImports.__signature_GetPropertyAsByteArray_657551312, __arguments_buffer);
                    return __arguments_buffer.get_Item(1).$v;
                }
            }
            /*global::System.Runtime.InteropServices.JavaScript.JSFunctionBinding*/ static __signature_GetPropertyAsByteArray_657551312 = null;
            static /*void */ SetPropertyBool(/*global::System.Runtime.InteropServices.JavaScript.JSObject*/ self, /*string*/ propertyName, /*bool*/ value)
            {
                if ($.$srij.System.Runtime.InteropServices.JavaScript.JavaScriptImports.__signature_SetPropertyBool_125660004 === null)
                {
                    $.$srij.System.Runtime.InteropServices.JavaScript.JavaScriptImports.__signature_SetPropertyBool_125660004 = $.$srij.System.Runtime.InteropServices.JavaScript.JSFunctionBinding.BindJSFunction("INTERNAL.set_property", null, $.$$.System.ReadOnlySpan$$($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType).op_Implicit$1($.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType), [$.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType.Discard, $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType.JSObject, $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType.String, $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType.Boolean], null, null)));
                }
                {
                    /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ let ____arg_exception_native;
                    /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ let ____arg_return_native;
                    /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ let __self_native;
                    /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ let __propertyName_native;
                    /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ let __value_native;
                    $.$$.System.Runtime.CompilerServices.Unsafe.SkipInit($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument, $.$ref(() => ____arg_return_native, ($v) => ____arg_return_native = $v, $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument));
                    ____arg_return_native.Initialize();
                    $.$$.System.Runtime.CompilerServices.Unsafe.SkipInit($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument, $.$ref(() => ____arg_exception_native, ($v) => ____arg_exception_native = $v, $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument));
                    ____arg_exception_native.Initialize();
                    $.$$.System.Runtime.CompilerServices.Unsafe.SkipInit($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument, $.$ref(() => __value_native, ($v) => __value_native = $v, $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument));
                    $.$$.System.Runtime.CompilerServices.Unsafe.SkipInit($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument, $.$ref(() => __propertyName_native, ($v) => __propertyName_native = $v, $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument));
                    $.$$.System.Runtime.CompilerServices.Unsafe.SkipInit($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument, $.$ref(() => __self_native, ($v) => __self_native = $v, $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument));
                    __value_native.ToJS$4(value);
                    __propertyName_native.ToJS$35(propertyName);
                    __self_native.ToJS$39(self);
                    {
                        __InvokeJSFunction.call(this, ____arg_exception_native.Clone(), ____arg_return_native.Clone(), __self_native.Clone(), __propertyName_native.Clone(), __value_native.Clone());
                    }
                }
                /*void*/  function __InvokeJSFunction(/*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ ____arg_exception_native, /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ ____arg_return_native, /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ __self_native, /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ __propertyName_native, /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ __value_native)
                {
                    $.$srij.System.Runtime.InteropServices.JavaScript.JSFunctionBinding.InvokeJS($.$srij.System.Runtime.InteropServices.JavaScript.JavaScriptImports.__signature_SetPropertyBool_125660004, $.$$.System.Span$$($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument).op_Implicit$2($.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument), [____arg_exception_native, ____arg_return_native, __self_native, __propertyName_native, __value_native], null, null)));
                }
            }
            /*global::System.Runtime.InteropServices.JavaScript.JSFunctionBinding*/ static __signature_SetPropertyBool_125660004 = null;
            static /*void */ SetPropertyInt(/*global::System.Runtime.InteropServices.JavaScript.JSObject*/ self, /*string*/ propertyName, /*int*/ value)
            {
                if ($.$srij.System.Runtime.InteropServices.JavaScript.JavaScriptImports.__signature_SetPropertyInt_512418141 === null)
                {
                    $.$srij.System.Runtime.InteropServices.JavaScript.JavaScriptImports.__signature_SetPropertyInt_512418141 = $.$srij.System.Runtime.InteropServices.JavaScript.JSFunctionBinding.BindJSFunction("INTERNAL.set_property", null, $.$$.System.ReadOnlySpan$$($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType).op_Implicit$1($.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType), [$.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType.Discard, $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType.JSObject, $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType.String, $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType.Int32], null, null)));
                }
                {
                    /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ let ____arg_exception_native;
                    /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ let ____arg_return_native;
                    /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ let __self_native;
                    /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ let __propertyName_native;
                    /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ let __value_native;
                    $.$$.System.Runtime.CompilerServices.Unsafe.SkipInit($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument, $.$ref(() => ____arg_return_native, ($v) => ____arg_return_native = $v, $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument));
                    ____arg_return_native.Initialize();
                    $.$$.System.Runtime.CompilerServices.Unsafe.SkipInit($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument, $.$ref(() => ____arg_exception_native, ($v) => ____arg_exception_native = $v, $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument));
                    ____arg_exception_native.Initialize();
                    $.$$.System.Runtime.CompilerServices.Unsafe.SkipInit($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument, $.$ref(() => __value_native, ($v) => __value_native = $v, $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument));
                    $.$$.System.Runtime.CompilerServices.Unsafe.SkipInit($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument, $.$ref(() => __propertyName_native, ($v) => __propertyName_native = $v, $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument));
                    $.$$.System.Runtime.CompilerServices.Unsafe.SkipInit($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument, $.$ref(() => __self_native, ($v) => __self_native = $v, $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument));
                    __value_native.ToJS$14(value);
                    __propertyName_native.ToJS$35(propertyName);
                    __self_native.ToJS$39(self);
                    {
                        __InvokeJSFunction.call(this, ____arg_exception_native.Clone(), ____arg_return_native.Clone(), __self_native.Clone(), __propertyName_native.Clone(), __value_native.Clone());
                    }
                }
                /*void*/  function __InvokeJSFunction(/*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ ____arg_exception_native, /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ ____arg_return_native, /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ __self_native, /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ __propertyName_native, /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ __value_native)
                {
                    $.$srij.System.Runtime.InteropServices.JavaScript.JSFunctionBinding.InvokeJS($.$srij.System.Runtime.InteropServices.JavaScript.JavaScriptImports.__signature_SetPropertyInt_512418141, $.$$.System.Span$$($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument).op_Implicit$2($.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument), [____arg_exception_native, ____arg_return_native, __self_native, __propertyName_native, __value_native], null, null)));
                }
            }
            /*global::System.Runtime.InteropServices.JavaScript.JSFunctionBinding*/ static __signature_SetPropertyInt_512418141 = null;
            static /*void */ SetPropertyDouble(/*global::System.Runtime.InteropServices.JavaScript.JSObject*/ self, /*string*/ propertyName, /*double*/ value)
            {
                if ($.$srij.System.Runtime.InteropServices.JavaScript.JavaScriptImports.__signature_SetPropertyDouble_1393852235 === null)
                {
                    $.$srij.System.Runtime.InteropServices.JavaScript.JavaScriptImports.__signature_SetPropertyDouble_1393852235 = $.$srij.System.Runtime.InteropServices.JavaScript.JSFunctionBinding.BindJSFunction("INTERNAL.set_property", null, $.$$.System.ReadOnlySpan$$($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType).op_Implicit$1($.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType), [$.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType.Discard, $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType.JSObject, $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType.String, $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType.Double], null, null)));
                }
                {
                    /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ let ____arg_exception_native;
                    /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ let ____arg_return_native;
                    /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ let __self_native;
                    /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ let __propertyName_native;
                    /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ let __value_native;
                    $.$$.System.Runtime.CompilerServices.Unsafe.SkipInit($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument, $.$ref(() => ____arg_return_native, ($v) => ____arg_return_native = $v, $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument));
                    ____arg_return_native.Initialize();
                    $.$$.System.Runtime.CompilerServices.Unsafe.SkipInit($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument, $.$ref(() => ____arg_exception_native, ($v) => ____arg_exception_native = $v, $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument));
                    ____arg_exception_native.Initialize();
                    $.$$.System.Runtime.CompilerServices.Unsafe.SkipInit($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument, $.$ref(() => __value_native, ($v) => __value_native = $v, $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument));
                    $.$$.System.Runtime.CompilerServices.Unsafe.SkipInit($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument, $.$ref(() => __propertyName_native, ($v) => __propertyName_native = $v, $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument));
                    $.$$.System.Runtime.CompilerServices.Unsafe.SkipInit($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument, $.$ref(() => __self_native, ($v) => __self_native = $v, $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument));
                    __value_native.ToJS$10(value);
                    __propertyName_native.ToJS$35(propertyName);
                    __self_native.ToJS$39(self);
                    {
                        __InvokeJSFunction.call(this, ____arg_exception_native.Clone(), ____arg_return_native.Clone(), __self_native.Clone(), __propertyName_native.Clone(), __value_native.Clone());
                    }
                }
                /*void*/  function __InvokeJSFunction(/*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ ____arg_exception_native, /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ ____arg_return_native, /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ __self_native, /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ __propertyName_native, /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ __value_native)
                {
                    $.$srij.System.Runtime.InteropServices.JavaScript.JSFunctionBinding.InvokeJS($.$srij.System.Runtime.InteropServices.JavaScript.JavaScriptImports.__signature_SetPropertyDouble_1393852235, $.$$.System.Span$$($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument).op_Implicit$2($.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument), [____arg_exception_native, ____arg_return_native, __self_native, __propertyName_native, __value_native], null, null)));
                }
            }
            /*global::System.Runtime.InteropServices.JavaScript.JSFunctionBinding*/ static __signature_SetPropertyDouble_1393852235 = null;
            static /*void */ SetPropertyString(/*global::System.Runtime.InteropServices.JavaScript.JSObject*/ self, /*string*/ propertyName, /*string*/ value)
            {
                if ($.$srij.System.Runtime.InteropServices.JavaScript.JavaScriptImports.__signature_SetPropertyString_1189495691 === null)
                {
                    $.$srij.System.Runtime.InteropServices.JavaScript.JavaScriptImports.__signature_SetPropertyString_1189495691 = $.$srij.System.Runtime.InteropServices.JavaScript.JSFunctionBinding.BindJSFunction("INTERNAL.set_property", null, $.$$.System.ReadOnlySpan$$($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType).op_Implicit$1($.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType), [$.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType.Discard, $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType.JSObject, $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType.String, $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType.String], null, null)));
                }
                {
                    /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ let ____arg_exception_native;
                    /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ let ____arg_return_native;
                    /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ let __self_native;
                    /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ let __propertyName_native;
                    /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ let __value_native;
                    $.$$.System.Runtime.CompilerServices.Unsafe.SkipInit($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument, $.$ref(() => ____arg_return_native, ($v) => ____arg_return_native = $v, $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument));
                    ____arg_return_native.Initialize();
                    $.$$.System.Runtime.CompilerServices.Unsafe.SkipInit($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument, $.$ref(() => ____arg_exception_native, ($v) => ____arg_exception_native = $v, $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument));
                    ____arg_exception_native.Initialize();
                    $.$$.System.Runtime.CompilerServices.Unsafe.SkipInit($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument, $.$ref(() => __value_native, ($v) => __value_native = $v, $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument));
                    $.$$.System.Runtime.CompilerServices.Unsafe.SkipInit($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument, $.$ref(() => __propertyName_native, ($v) => __propertyName_native = $v, $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument));
                    $.$$.System.Runtime.CompilerServices.Unsafe.SkipInit($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument, $.$ref(() => __self_native, ($v) => __self_native = $v, $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument));
                    __value_native.ToJS$35(value);
                    __propertyName_native.ToJS$35(propertyName);
                    __self_native.ToJS$39(self);
                    {
                        __InvokeJSFunction.call(this, ____arg_exception_native.Clone(), ____arg_return_native.Clone(), __self_native.Clone(), __propertyName_native.Clone(), __value_native.Clone());
                    }
                }
                /*void*/  function __InvokeJSFunction(/*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ ____arg_exception_native, /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ ____arg_return_native, /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ __self_native, /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ __propertyName_native, /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ __value_native)
                {
                    $.$srij.System.Runtime.InteropServices.JavaScript.JSFunctionBinding.InvokeJS($.$srij.System.Runtime.InteropServices.JavaScript.JavaScriptImports.__signature_SetPropertyString_1189495691, $.$$.System.Span$$($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument).op_Implicit$2($.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument), [____arg_exception_native, ____arg_return_native, __self_native, __propertyName_native, __value_native], null, null)));
                }
            }
            /*global::System.Runtime.InteropServices.JavaScript.JSFunctionBinding*/ static __signature_SetPropertyString_1189495691 = null;
            static /*void */ SetPropertyJSObject(/*global::System.Runtime.InteropServices.JavaScript.JSObject*/ self, /*string*/ propertyName, /*global::System.Runtime.InteropServices.JavaScript.JSObject*/ value)
            {
                if ($.$srij.System.Runtime.InteropServices.JavaScript.JavaScriptImports.__signature_SetPropertyJSObject_2027749310 === null)
                {
                    $.$srij.System.Runtime.InteropServices.JavaScript.JavaScriptImports.__signature_SetPropertyJSObject_2027749310 = $.$srij.System.Runtime.InteropServices.JavaScript.JSFunctionBinding.BindJSFunction("INTERNAL.set_property", null, $.$$.System.ReadOnlySpan$$($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType).op_Implicit$1($.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType), [$.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType.Discard, $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType.JSObject, $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType.String, $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType.JSObject], null, null)));
                }
                {
                    /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ let ____arg_exception_native;
                    /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ let ____arg_return_native;
                    /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ let __self_native;
                    /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ let __propertyName_native;
                    /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ let __value_native;
                    $.$$.System.Runtime.CompilerServices.Unsafe.SkipInit($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument, $.$ref(() => ____arg_return_native, ($v) => ____arg_return_native = $v, $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument));
                    ____arg_return_native.Initialize();
                    $.$$.System.Runtime.CompilerServices.Unsafe.SkipInit($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument, $.$ref(() => ____arg_exception_native, ($v) => ____arg_exception_native = $v, $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument));
                    ____arg_exception_native.Initialize();
                    $.$$.System.Runtime.CompilerServices.Unsafe.SkipInit($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument, $.$ref(() => __value_native, ($v) => __value_native = $v, $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument));
                    $.$$.System.Runtime.CompilerServices.Unsafe.SkipInit($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument, $.$ref(() => __propertyName_native, ($v) => __propertyName_native = $v, $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument));
                    $.$$.System.Runtime.CompilerServices.Unsafe.SkipInit($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument, $.$ref(() => __self_native, ($v) => __self_native = $v, $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument));
                    __value_native.ToJS$39(value);
                    __propertyName_native.ToJS$35(propertyName);
                    __self_native.ToJS$39(self);
                    {
                        __InvokeJSFunction.call(this, ____arg_exception_native.Clone(), ____arg_return_native.Clone(), __self_native.Clone(), __propertyName_native.Clone(), __value_native.Clone());
                    }
                }
                /*void*/  function __InvokeJSFunction(/*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ ____arg_exception_native, /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ ____arg_return_native, /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ __self_native, /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ __propertyName_native, /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ __value_native)
                {
                    $.$srij.System.Runtime.InteropServices.JavaScript.JSFunctionBinding.InvokeJS($.$srij.System.Runtime.InteropServices.JavaScript.JavaScriptImports.__signature_SetPropertyJSObject_2027749310, $.$$.System.Span$$($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument).op_Implicit$2($.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument), [____arg_exception_native, ____arg_return_native, __self_native, __propertyName_native, __value_native], null, null)));
                }
            }
            /*global::System.Runtime.InteropServices.JavaScript.JSFunctionBinding*/ static __signature_SetPropertyJSObject_2027749310 = null;
            static /*void */ SetPropertyBytes(/*global::System.Runtime.InteropServices.JavaScript.JSObject*/ self, /*string*/ propertyName, /*byte[]*/ value)
            {
                if ($.$srij.System.Runtime.InteropServices.JavaScript.JavaScriptImports.__signature_SetPropertyBytes_1317820772 === null)
                {
                    $.$srij.System.Runtime.InteropServices.JavaScript.JavaScriptImports.__signature_SetPropertyBytes_1317820772 = $.$srij.System.Runtime.InteropServices.JavaScript.JSFunctionBinding.BindJSFunction("INTERNAL.set_property", null, $.$$.System.ReadOnlySpan$$($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType).op_Implicit$1($.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType), [$.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType.Discard, $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType.JSObject, $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType.String, $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType.Array($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType.Byte)], null, null)));
                }
                {
                    /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ let ____arg_exception_native;
                    /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ let ____arg_return_native;
                    /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ let __self_native;
                    /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ let __propertyName_native;
                    /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ let __value_native;
                    $.$$.System.Runtime.CompilerServices.Unsafe.SkipInit($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument, $.$ref(() => ____arg_return_native, ($v) => ____arg_return_native = $v, $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument));
                    ____arg_return_native.Initialize();
                    $.$$.System.Runtime.CompilerServices.Unsafe.SkipInit($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument, $.$ref(() => ____arg_exception_native, ($v) => ____arg_exception_native = $v, $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument));
                    ____arg_exception_native.Initialize();
                    $.$$.System.Runtime.CompilerServices.Unsafe.SkipInit($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument, $.$ref(() => __value_native, ($v) => __value_native = $v, $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument));
                    $.$$.System.Runtime.CompilerServices.Unsafe.SkipInit($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument, $.$ref(() => __propertyName_native, ($v) => __propertyName_native = $v, $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument));
                    $.$$.System.Runtime.CompilerServices.Unsafe.SkipInit($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument, $.$ref(() => __self_native, ($v) => __self_native = $v, $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument));
                    __value_native.ToJS$6(value);
                    __propertyName_native.ToJS$35(propertyName);
                    __self_native.ToJS$39(self);
                    {
                        __InvokeJSFunction.call(this, ____arg_exception_native.Clone(), ____arg_return_native.Clone(), __self_native.Clone(), __propertyName_native.Clone(), __value_native.Clone());
                    }
                }
                /*void*/  function __InvokeJSFunction(/*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ ____arg_exception_native, /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ ____arg_return_native, /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ __self_native, /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ __propertyName_native, /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ __value_native)
                {
                    $.$srij.System.Runtime.InteropServices.JavaScript.JSFunctionBinding.InvokeJS($.$srij.System.Runtime.InteropServices.JavaScript.JavaScriptImports.__signature_SetPropertyBytes_1317820772, $.$$.System.Span$$($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument).op_Implicit$2($.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument), [____arg_exception_native, ____arg_return_native, __self_native, __propertyName_native, __value_native], null, null)));
                }
            }
            /*global::System.Runtime.InteropServices.JavaScript.JSFunctionBinding*/ static __signature_SetPropertyBytes_1317820772 = null;
            static /*global::System.Runtime.InteropServices.JavaScript.JSObject */ GetGlobalThis()
            {
                if ($.$srij.System.Runtime.InteropServices.JavaScript.JavaScriptImports.__signature_GetGlobalThis_1202228629 === null)
                {
                    $.$srij.System.Runtime.InteropServices.JavaScript.JavaScriptImports.__signature_GetGlobalThis_1202228629 = $.$srij.System.Runtime.InteropServices.JavaScript.JSFunctionBinding.BindJSFunction("INTERNAL.get_global_this", null, $.$$.System.ReadOnlySpan$$($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType).op_Implicit$1($.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType), [$.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType.JSObject], null, null)));
                }
                {
                    /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ let ____arg_exception_native;
                    /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ let ____arg_return_native;
                    /*global::System.Runtime.InteropServices.JavaScript.JSObject*/ let __retVal;
                    /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ let __retVal_native;
                    $.$$.System.Runtime.CompilerServices.Unsafe.SkipInit($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument, $.$ref(() => ____arg_return_native, ($v) => ____arg_return_native = $v, $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument));
                    ____arg_return_native.Initialize();
                    $.$$.System.Runtime.CompilerServices.Unsafe.SkipInit($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument, $.$ref(() => ____arg_exception_native, ($v) => ____arg_exception_native = $v, $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument));
                    ____arg_exception_native.Initialize();
                    {
                        __retVal_native = __InvokeJSFunction.call(this, ____arg_exception_native.Clone(), ____arg_return_native.Clone());
                    }
                    __retVal_native.ToManaged$39($.$ref(() => __retVal, ($v) => __retVal = $v, $.$srij.System.Runtime.InteropServices.JavaScript.JSObject));
                    return __retVal;
                }
                /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/  function __InvokeJSFunction(/*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ ____arg_exception_native, /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ ____arg_return_native)
                {
                    /*global::System.Span<global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument>*/ let __arguments_buffer = $.$$.System.Span$$($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument).op_Implicit$2($.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument), [____arg_exception_native, ____arg_return_native], null, null));
                    $.$srij.System.Runtime.InteropServices.JavaScript.JSFunctionBinding.InvokeJS($.$srij.System.Runtime.InteropServices.JavaScript.JavaScriptImports.__signature_GetGlobalThis_1202228629, __arguments_buffer);
                    return __arguments_buffer.get_Item(1).$v;
                }
            }
            /*global::System.Runtime.InteropServices.JavaScript.JSFunctionBinding*/ static __signature_GetGlobalThis_1202228629 = null;
            static /*global::System.Runtime.InteropServices.JavaScript.JSObject */ GetDotnetInstance()
            {
                if ($.$srij.System.Runtime.InteropServices.JavaScript.JavaScriptImports.__signature_GetDotnetInstance_1202228629 === null)
                {
                    $.$srij.System.Runtime.InteropServices.JavaScript.JavaScriptImports.__signature_GetDotnetInstance_1202228629 = $.$srij.System.Runtime.InteropServices.JavaScript.JSFunctionBinding.BindJSFunction("INTERNAL.get_dotnet_instance", null, $.$$.System.ReadOnlySpan$$($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType).op_Implicit$1($.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType), [$.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType.JSObject], null, null)));
                }
                {
                    /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ let ____arg_exception_native;
                    /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ let ____arg_return_native;
                    /*global::System.Runtime.InteropServices.JavaScript.JSObject*/ let __retVal;
                    /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ let __retVal_native;
                    $.$$.System.Runtime.CompilerServices.Unsafe.SkipInit($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument, $.$ref(() => ____arg_return_native, ($v) => ____arg_return_native = $v, $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument));
                    ____arg_return_native.Initialize();
                    $.$$.System.Runtime.CompilerServices.Unsafe.SkipInit($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument, $.$ref(() => ____arg_exception_native, ($v) => ____arg_exception_native = $v, $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument));
                    ____arg_exception_native.Initialize();
                    {
                        __retVal_native = __InvokeJSFunction.call(this, ____arg_exception_native.Clone(), ____arg_return_native.Clone());
                    }
                    __retVal_native.ToManaged$39($.$ref(() => __retVal, ($v) => __retVal = $v, $.$srij.System.Runtime.InteropServices.JavaScript.JSObject));
                    return __retVal;
                }
                /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/  function __InvokeJSFunction(/*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ ____arg_exception_native, /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ ____arg_return_native)
                {
                    /*global::System.Span<global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument>*/ let __arguments_buffer = $.$$.System.Span$$($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument).op_Implicit$2($.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument), [____arg_exception_native, ____arg_return_native], null, null));
                    $.$srij.System.Runtime.InteropServices.JavaScript.JSFunctionBinding.InvokeJS($.$srij.System.Runtime.InteropServices.JavaScript.JavaScriptImports.__signature_GetDotnetInstance_1202228629, __arguments_buffer);
                    return __arguments_buffer.get_Item(1).$v;
                }
            }
            /*global::System.Runtime.InteropServices.JavaScript.JSFunctionBinding*/ static __signature_GetDotnetInstance_1202228629 = null;
            static /*global::System.Threading.Tasks.Task<global::System.Runtime.InteropServices.JavaScript.JSObject> */ DynamicImport(/*string*/ moduleName, /*string*/ moduleUrl)
            {
                if ($.$srij.System.Runtime.InteropServices.JavaScript.JavaScriptImports.__signature_DynamicImport_119536130 === null)
                {
                    $.$srij.System.Runtime.InteropServices.JavaScript.JavaScriptImports.__signature_DynamicImport_119536130 = $.$srij.System.Runtime.InteropServices.JavaScript.JSFunctionBinding.BindJSFunction("INTERNAL.dynamic_import", null, $.$$.System.ReadOnlySpan$$($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType).op_Implicit$1($.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType), [$.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType.Task$1($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType.JSObject), $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType.String, $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType.String], null, null)));
                }
                {
                    /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ let ____arg_exception_native;
                    /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ let ____arg_return_native;
                    /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ let __moduleName_native;
                    /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ let __moduleUrl_native;
                    /*global::System.Threading.Tasks.Task<global::System.Runtime.InteropServices.JavaScript.JSObject>*/ let __retVal;
                    /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ let __retVal_native;
                    $.$$.System.Runtime.CompilerServices.Unsafe.SkipInit($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument, $.$ref(() => ____arg_return_native, ($v) => ____arg_return_native = $v, $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument));
                    ____arg_return_native.Initialize();
                    $.$$.System.Runtime.CompilerServices.Unsafe.SkipInit($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument, $.$ref(() => ____arg_exception_native, ($v) => ____arg_exception_native = $v, $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument));
                    ____arg_exception_native.Initialize();
                    $.$$.System.Runtime.CompilerServices.Unsafe.SkipInit($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument, $.$ref(() => __moduleUrl_native, ($v) => __moduleUrl_native = $v, $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument));
                    $.$$.System.Runtime.CompilerServices.Unsafe.SkipInit($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument, $.$ref(() => __moduleName_native, ($v) => __moduleName_native = $v, $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument));
                    __moduleUrl_native.ToJS$35(moduleUrl);
                    __moduleName_native.ToJS$35(moduleName);
                    {
                        __retVal_native = __InvokeJSFunction.call(this, ____arg_exception_native.Clone(), ____arg_return_native.Clone(), __moduleName_native.Clone(), __moduleUrl_native.Clone());
                    }
                    __retVal_native.ToManaged$43($.$srij.System.Runtime.InteropServices.JavaScript.JSObject, $.$ref(() => __retVal, ($v) => __retVal = $v, $.$$.System.Threading.Tasks.Task$$($.$srij.System.Runtime.InteropServices.JavaScript.JSObject)), new ($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument.ArgumentToManagedCallback$$($.$srij.System.Runtime.InteropServices.JavaScript.JSObject))().$ctor($.$srij.System.Runtime.InteropServices.JavaScript.JavaScriptImports, /*static*/ (/*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ __task_result_arg, /*global::System.Runtime.InteropServices.JavaScript.JSObject*/ __task_result) =>
                    {
                        __task_result_arg.$v.ToManaged$39(__task_result);
                    }, {"r":65537,"p":[{"n":"__task_result_arg","p":1375862,"f":4},{"n":"__task_result","p":2293366,"f":2}],"n":"","d":392822,"h":0,"f":17825826}));
                    return __retVal;
                }
                /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/  function __InvokeJSFunction(/*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ ____arg_exception_native, /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ ____arg_return_native, /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ __moduleName_native, /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ __moduleUrl_native)
                {
                    /*global::System.Span<global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument>*/ let __arguments_buffer = $.$$.System.Span$$($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument).op_Implicit$2($.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument), [____arg_exception_native, ____arg_return_native, __moduleName_native, __moduleUrl_native], null, null));
                    $.$srij.System.Runtime.InteropServices.JavaScript.JSFunctionBinding.InvokeJS($.$srij.System.Runtime.InteropServices.JavaScript.JavaScriptImports.__signature_DynamicImport_119536130, __arguments_buffer);
                    return __arguments_buffer.get_Item(1).$v;
                }
            }
            /*global::System.Runtime.InteropServices.JavaScript.JSFunctionBinding*/ static __signature_DynamicImport_119536130 = null;
            static /*void */ BindCSFunction(/*nint*/ monoMethod, /*string*/ assemblyName, /*string*/ namespaceName, /*string*/ shortClassName, /*string*/ methodName, /*int*/ signatureHash, /*nint*/ signature)
            {
                if ($.$srij.System.Runtime.InteropServices.JavaScript.JavaScriptImports.__signature_BindCSFunction_1080107758 === null)
                {
                    $.$srij.System.Runtime.InteropServices.JavaScript.JavaScriptImports.__signature_BindCSFunction_1080107758 = $.$srij.System.Runtime.InteropServices.JavaScript.JSFunctionBinding.BindJSFunction("INTERNAL.mono_wasm_bind_cs_function", null, $.$$.System.ReadOnlySpan$$($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType).op_Implicit$1($.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType), [$.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType.Discard, $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType.IntPtr, $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType.String, $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType.String, $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType.String, $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType.String, $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType.Int32, $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType.IntPtr], null, null)));
                }
                {
                    /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ let ____arg_exception_native;
                    /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ let ____arg_return_native;
                    /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ let __monoMethod_native;
                    /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ let __assemblyName_native;
                    /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ let __namespaceName_native;
                    /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ let __shortClassName_native;
                    /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ let __methodName_native;
                    /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ let __signatureHash_native;
                    /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ let __signature_native;
                    $.$$.System.Runtime.CompilerServices.Unsafe.SkipInit($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument, $.$ref(() => ____arg_return_native, ($v) => ____arg_return_native = $v, $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument));
                    ____arg_return_native.Initialize();
                    $.$$.System.Runtime.CompilerServices.Unsafe.SkipInit($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument, $.$ref(() => ____arg_exception_native, ($v) => ____arg_exception_native = $v, $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument));
                    ____arg_exception_native.Initialize();
                    $.$$.System.Runtime.CompilerServices.Unsafe.SkipInit($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument, $.$ref(() => __signature_native, ($v) => __signature_native = $v, $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument));
                    $.$$.System.Runtime.CompilerServices.Unsafe.SkipInit($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument, $.$ref(() => __signatureHash_native, ($v) => __signatureHash_native = $v, $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument));
                    $.$$.System.Runtime.CompilerServices.Unsafe.SkipInit($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument, $.$ref(() => __methodName_native, ($v) => __methodName_native = $v, $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument));
                    $.$$.System.Runtime.CompilerServices.Unsafe.SkipInit($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument, $.$ref(() => __shortClassName_native, ($v) => __shortClassName_native = $v, $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument));
                    $.$$.System.Runtime.CompilerServices.Unsafe.SkipInit($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument, $.$ref(() => __namespaceName_native, ($v) => __namespaceName_native = $v, $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument));
                    $.$$.System.Runtime.CompilerServices.Unsafe.SkipInit($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument, $.$ref(() => __assemblyName_native, ($v) => __assemblyName_native = $v, $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument));
                    $.$$.System.Runtime.CompilerServices.Unsafe.SkipInit($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument, $.$ref(() => __monoMethod_native, ($v) => __monoMethod_native = $v, $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument));
                    __signature_native.ToJS$17(signature);
                    __signatureHash_native.ToJS$14(signatureHash);
                    __methodName_native.ToJS$35(methodName);
                    __shortClassName_native.ToJS$35(shortClassName);
                    __namespaceName_native.ToJS$35(namespaceName);
                    __assemblyName_native.ToJS$35(assemblyName);
                    __monoMethod_native.ToJS$17(monoMethod);
                    {
                        __InvokeJSFunction.call(this, ____arg_exception_native.Clone(), ____arg_return_native.Clone(), __monoMethod_native.Clone(), __assemblyName_native.Clone(), __namespaceName_native.Clone(), __shortClassName_native.Clone(), __methodName_native.Clone(), __signatureHash_native.Clone(), __signature_native.Clone());
                    }
                }
                /*void*/  function __InvokeJSFunction(/*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ ____arg_exception_native, /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ ____arg_return_native, /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ __monoMethod_native, /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ __assemblyName_native, /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ __namespaceName_native, /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ __shortClassName_native, /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ __methodName_native, /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ __signatureHash_native, /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ __signature_native)
                {
                    $.$srij.System.Runtime.InteropServices.JavaScript.JSFunctionBinding.InvokeJS($.$srij.System.Runtime.InteropServices.JavaScript.JavaScriptImports.__signature_BindCSFunction_1080107758, $.$$.System.Span$$($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument).op_Implicit$2($.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument), [____arg_exception_native, ____arg_return_native, __monoMethod_native, __assemblyName_native, __namespaceName_native, __shortClassName_native, __methodName_native, __signatureHash_native, __signature_native], null, null)));
                }
            }
            /*global::System.Runtime.InteropServices.JavaScript.JSFunctionBinding*/ static __signature_BindCSFunction_1080107758 = null;
            static /*void */ Log(/*string*/ message)
            {
                if ($.$srij.System.Runtime.InteropServices.JavaScript.JavaScriptImports.__signature_Log_92020726 === null)
                {
                    $.$srij.System.Runtime.InteropServices.JavaScript.JavaScriptImports.__signature_Log_92020726 = $.$srij.System.Runtime.InteropServices.JavaScript.JSFunctionBinding.BindJSFunction("globalThis.console.log", null, $.$$.System.ReadOnlySpan$$($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType).op_Implicit$1($.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType), [$.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType.DiscardNoWait, $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType.String], null, null)));
                }
                {
                    /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ let ____arg_exception_native;
                    /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ let ____arg_return_native;
                    /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ let __message_native;
                    $.$$.System.Runtime.CompilerServices.Unsafe.SkipInit($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument, $.$ref(() => ____arg_return_native, ($v) => ____arg_return_native = $v, $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument));
                    ____arg_return_native.Initialize();
                    $.$$.System.Runtime.CompilerServices.Unsafe.SkipInit($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument, $.$ref(() => ____arg_exception_native, ($v) => ____arg_exception_native = $v, $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument));
                    ____arg_exception_native.Initialize();
                    $.$$.System.Runtime.CompilerServices.Unsafe.SkipInit($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument, $.$ref(() => __message_native, ($v) => __message_native = $v, $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument));
                    __message_native.ToJS$35(message);
                    {
                        __InvokeJSFunction.call(this, ____arg_exception_native.Clone(), ____arg_return_native.Clone(), __message_native.Clone());
                    }
                }
                /*void*/  function __InvokeJSFunction(/*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ ____arg_exception_native, /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ ____arg_return_native, /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ __message_native)
                {
                    $.$srij.System.Runtime.InteropServices.JavaScript.JSFunctionBinding.InvokeJS($.$srij.System.Runtime.InteropServices.JavaScript.JavaScriptImports.__signature_Log_92020726, $.$$.System.Span$$($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument).op_Implicit$2($.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument), [____arg_exception_native, ____arg_return_native, __message_native], null, null)));
                }
            }
            /*global::System.Runtime.InteropServices.JavaScript.JSFunctionBinding*/ static __signature_Log_92020726 = null;
            static $h = 392822;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"m":[{"r":262145,"p":[{"n":"self","p":2293366},{"n":"propertyName","p":1310721}],"n":"HasProperty","d":392822,"h":4295360118,"f":16777249,"a":[{"t":1244790,"c":30066015862,"a":[{"v":"INTERNAL.has_property","t":1310721}]},{"t":37748737,"c":4332716033}]},{"r":1310721,"p":[{"n":"self","p":2293366},{"n":"propertyName","p":1310721}],"n":"GetTypeOfProperty","d":392822,"h":8590327414,"f":16777249,"a":[{"t":1244790,"c":30066015862,"a":[{"v":"INTERNAL.get_typeof_property","t":1310721}]},{"t":37748737,"c":4332716033}]},{"r":262145,"p":[{"n":"self","p":2293366},{"n":"propertyName","p":1310721}],"n":"GetPropertyAsBoolean","d":392822,"h":12885294710,"f":16777249,"a":[{"t":1244790,"c":30066015862,"a":[{"v":"INTERNAL.get_property","t":1310721}]},{"t":37748737,"c":4332716033}]},{"r":655361,"p":[{"n":"self","p":2293366},{"n":"propertyName","p":1310721}],"n":"GetPropertyAsInt32","d":392822,"h":17180262006,"f":16777249,"a":[{"t":1244790,"c":30066015862,"a":[{"v":"INTERNAL.get_property","t":1310721}]},{"t":37748737,"c":4332716033}]},{"r":1179649,"p":[{"n":"self","p":2293366},{"n":"propertyName","p":1310721}],"n":"GetPropertyAsDouble","d":392822,"h":21475229302,"f":16777249,"a":[{"t":1244790,"c":30066015862,"a":[{"v":"INTERNAL.get_property","t":1310721}]},{"t":37748737,"c":4332716033}]},{"r":1310721,"p":[{"n":"self","p":2293366},{"n":"propertyName","p":1310721}],"n":"GetPropertyAsString","d":392822,"h":25770196598,"f":16777249,"a":[{"t":1244790,"c":30066015862,"a":[{"v":"INTERNAL.get_property","t":1310721}]},{"t":37748737,"c":4332716033}]},{"r":2293366,"p":[{"n":"self","p":2293366},{"n":"propertyName","p":1310721}],"n":"GetPropertyAsJSObject","d":392822,"h":30065163894,"f":16777249,"a":[{"t":1244790,"c":30066015862,"a":[{"v":"INTERNAL.get_property","t":1310721}]},{"t":37748737,"c":4332716033}]},{"r":$.$typeArray($.$$.System.Byte).$h,"p":[{"n":"self","p":2293366},{"n":"propertyName","p":1310721}],"n":"GetPropertyAsByteArray","d":392822,"h":34360131190,"f":16777249,"a":[{"t":1244790,"c":30066015862,"a":[{"v":"INTERNAL.get_property","t":1310721}]},{"t":37748737,"c":4332716033}]},{"r":65537,"p":[{"n":"self","p":2293366},{"n":"propertyName","p":1310721},{"n":"value","p":262145}],"n":"SetPropertyBool","d":392822,"h":38655098486,"f":16777249,"a":[{"t":1244790,"c":30066015862,"a":[{"v":"INTERNAL.set_property","t":1310721}]},{"t":37748737,"c":4332716033}]},{"r":65537,"p":[{"n":"self","p":2293366},{"n":"propertyName","p":1310721},{"n":"value","p":655361}],"n":"SetPropertyInt","d":392822,"h":42950065782,"f":16777249,"a":[{"t":1244790,"c":30066015862,"a":[{"v":"INTERNAL.set_property","t":1310721}]},{"t":37748737,"c":4332716033}]},{"r":65537,"p":[{"n":"self","p":2293366},{"n":"propertyName","p":1310721},{"n":"value","p":1179649}],"n":"SetPropertyDouble","d":392822,"h":47245033078,"f":16777249,"a":[{"t":1244790,"c":30066015862,"a":[{"v":"INTERNAL.set_property","t":1310721}]},{"t":37748737,"c":4332716033}]},{"r":65537,"p":[{"n":"self","p":2293366},{"n":"propertyName","p":1310721},{"n":"value","p":1310721}],"n":"SetPropertyString","d":392822,"h":51540000374,"f":16777249,"a":[{"t":1244790,"c":30066015862,"a":[{"v":"INTERNAL.set_property","t":1310721}]},{"t":37748737,"c":4332716033}]},{"r":65537,"p":[{"n":"self","p":2293366},{"n":"propertyName","p":1310721},{"n":"value","p":2293366}],"n":"SetPropertyJSObject","d":392822,"h":55834967670,"f":16777249,"a":[{"t":1244790,"c":30066015862,"a":[{"v":"INTERNAL.set_property","t":1310721}]},{"t":37748737,"c":4332716033}]},{"r":65537,"p":[{"n":"self","p":2293366},{"n":"propertyName","p":1310721},{"n":"value","p":$.$typeArray($.$$.System.Byte).$h}],"n":"SetPropertyBytes","d":392822,"h":60129934966,"f":16777249,"a":[{"t":1244790,"c":30066015862,"a":[{"v":"INTERNAL.set_property","t":1310721}]},{"t":37748737,"c":4332716033}]},{"r":2293366,"n":"GetGlobalThis","d":392822,"h":64424902262,"f":16777249,"a":[{"t":1244790,"c":30066015862,"a":[{"v":"INTERNAL.get_global_this","t":1310721}]},{"t":37748737,"c":4332716033}]},{"r":2293366,"n":"GetDotnetInstance","d":392822,"h":68719869558,"f":16777249,"a":[{"t":1244790,"c":30066015862,"a":[{"v":"INTERNAL.get_dotnet_instance","t":1310721}]},{"t":37748737,"c":4332716033}]},{"r":$.$$.System.Threading.Tasks.Task$$($.$srij.System.Runtime.InteropServices.JavaScript.JSObject).$h,"p":[{"n":"moduleName","p":1310721},{"n":"moduleUrl","p":1310721}],"n":"DynamicImport","d":392822,"h":73014836854,"f":16777249,"a":[{"t":1244790,"c":30066015862,"a":[{"v":"INTERNAL.dynamic_import","t":1310721}]},{"t":37748737,"c":4332716033}]},{"r":65537,"p":[{"n":"monoMethod","p":786433},{"n":"assemblyName","p":1310721},{"n":"namespaceName","p":1310721},{"n":"shortClassName","p":1310721},{"n":"methodName","p":1310721},{"n":"signatureHash","p":655361},{"n":"signature","p":786433}],"n":"BindCSFunction","d":392822,"h":77309804150,"f":16777249,"a":[{"t":1244790,"c":30066015862,"a":[{"v":"INTERNAL.mono_wasm_bind_cs_function","t":1310721}]},{"t":37748737,"c":4332716033}]},{"r":65537,"p":[{"n":"message","p":1310721,"a":[{"t":$.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalAsAttribute$$($.$srij.System.Runtime.InteropServices.JavaScript.JSType.String).$h,"c":Number(BigInt($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalAsAttribute$$($.$srij.System.Runtime.InteropServices.JavaScript.JSType.String).$h)|0x100000000n)}]}],"n":"Log","d":392822,"h":81604771446,"f":16777249,"a":[{"t":1244790,"c":30066015862,"a":[{"v":"globalThis.console.log","t":1310721}]},{"t":37748737,"c":4332716033}]}],"l":[{"t":589430,"n":"__signature_HasProperty_393970128","d":392822,"h":85899738742,"f":4194338},{"t":589430,"n":"__signature_GetTypeOfProperty_1139574135","d":392822,"h":90194706038,"f":4194338},{"t":589430,"n":"__signature_GetPropertyAsBoolean_393970128","d":392822,"h":94489673334,"f":4194338},{"t":589430,"n":"__signature_GetPropertyAsInt32_1813830729","d":392822,"h":98784640630,"f":4194338},{"t":589430,"n":"__signature_GetPropertyAsDouble_705601847","d":392822,"h":103079607926,"f":4194338},{"t":589430,"n":"__signature_GetPropertyAsString_1139574135","d":392822,"h":107374575222,"f":4194338},{"t":589430,"n":"__signature_GetPropertyAsJSObject_1480020778","d":392822,"h":111669542518,"f":4194338},{"t":589430,"n":"__signature_GetPropertyAsByteArray_657551312","d":392822,"h":115964509814,"f":4194338},{"t":589430,"n":"__signature_SetPropertyBool_125660004","d":392822,"h":120259477110,"f":4194338},{"t":589430,"n":"__signature_SetPropertyInt_512418141","d":392822,"h":124554444406,"f":4194338},{"t":589430,"n":"__signature_SetPropertyDouble_1393852235","d":392822,"h":128849411702,"f":4194338},{"t":589430,"n":"__signature_SetPropertyString_1189495691","d":392822,"h":133144378998,"f":4194338},{"t":589430,"n":"__signature_SetPropertyJSObject_2027749310","d":392822,"h":137439346294,"f":4194338},{"t":589430,"n":"__signature_SetPropertyBytes_1317820772","d":392822,"h":141734313590,"f":4194338},{"t":589430,"n":"__signature_GetGlobalThis_1202228629","d":392822,"h":146029280886,"f":4194338},{"t":589430,"n":"__signature_GetDotnetInstance_1202228629","d":392822,"h":150324248182,"f":4194338},{"t":589430,"n":"__signature_DynamicImport_119536130","d":392822,"h":154619215478,"f":4194338},{"t":589430,"n":"__signature_BindCSFunction_1080107758","d":392822,"h":158914182774,"f":4194338},{"t":589430,"n":"__signature_Log_92020726","d":392822,"h":163209150070,"f":4194338}],"h":392822}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `System.Runtime.InteropServices.JavaScript.JavaScriptImports`; }
        });
        
        $asm.$cls("$srij.System.Runtime.InteropServices.JavaScript.JSFunctionBinding", ($self) => class JSFunctionBinding extends $.$$.System.Object
        {
            $ctor$1()
            {
                super.$ctor();
                {
                }
                return this;
            }
            /*JSBindingHeader**/ Header;
            /*JSBindingType**/ Sigs;
            /*uint*/ static nextImportHandle = 1;
            /*int*/ ImportHandle = 0;
            /*bool*/ IsAsync = false;
            /*bool*/ IsDiscardNoWait = false;
            /*string?*/ FunctionName = null;
            static $_JSBindingHeader;
            static get JSBindingHeader()
            {
                let $cls = $.$srij.System.Runtime.InteropServices.JavaScript.JSFunctionBinding;
                return $cls.$_JSBindingHeader ??= $asm.$nstr("$srij.System.Runtime.InteropServices.JavaScript.JSFunctionBinding.JSBindingHeader", ($self) => class JSBindingHeader extends $.$$.System.ValueType
                {
                    /*int*/ static JSMarshalerSignatureHeaderSize = 32;
                    /*int*/  get Version() { return this.$getField(0, $.$$.System.Int32); }
                    /*int*/  set Version(value) { this.$setField(0, $.$$.System.Int32, value); }
                    /*int*/  get ArgumentCount() { return this.$getField(4, $.$$.System.Int32); }
                    /*int*/  set ArgumentCount(value) { this.$setField(4, $.$$.System.Int32, value); }
                    /*int*/  get ImportHandle() { return this.$getField(8, $.$$.System.Int32); }
                    /*int*/  set ImportHandle(value) { this.$setField(8, $.$$.System.Int32, value); }
                    /*int*/  get FunctionNameOffset() { return this.$getField(16, $.$$.System.Int32); }
                    /*int*/  set FunctionNameOffset(value) { this.$setField(16, $.$$.System.Int32, value); }
                    /*int*/  get FunctionNameLength() { return this.$getField(20, $.$$.System.Int32); }
                    /*int*/  set FunctionNameLength(value) { this.$setField(20, $.$$.System.Int32, value); }
                    /*int*/  get ModuleNameOffset() { return this.$getField(24, $.$$.System.Int32); }
                    /*int*/  set ModuleNameOffset(value) { this.$setField(24, $.$$.System.Int32, value); }
                    /*int*/  get ModuleNameLength() { return this.$getField(28, $.$$.System.Int32); }
                    /*int*/  set ModuleNameLength(value) { this.$setField(28, $.$$.System.Int32, value); }
                    /*JSBindingType*/  get Exception() { return this.$getField(32, $.$srij.System.Runtime.InteropServices.JavaScript.JSFunctionBinding.JSBindingType); }
                    /*JSBindingType*/  set Exception(value) { this.$setField(32, $.$srij.System.Runtime.InteropServices.JavaScript.JSFunctionBinding.JSBindingType, value); }
                    /*JSBindingType*/  get Result() { return this.$getField(64, $.$srij.System.Runtime.InteropServices.JavaScript.JSFunctionBinding.JSBindingType); }
                    /*JSBindingType*/  set Result(value) { this.$setField(64, $.$srij.System.Runtime.InteropServices.JavaScript.JSFunctionBinding.JSBindingType, value); }
                    //default value type constructor
                    $ctor$2()
                    {
                        return this;
                    }
                    Clone($copy)
                    {
                        let copy = $copy ?? new this.constructor();
                        copy.Version = this.Version;
                        copy.ArgumentCount = this.ArgumentCount;
                        copy.ImportHandle = this.ImportHandle;
                        copy.FunctionNameOffset = this.FunctionNameOffset;
                        copy.FunctionNameLength = this.FunctionNameLength;
                        copy.ModuleNameOffset = this.ModuleNameOffset;
                        copy.ModuleNameLength = this.ModuleNameLength;
                        copy.Exception = this.Exception.Clone();
                        copy.Result = this.Result.Clone();
                        return copy;
                    }
                    //default member initializer
                    constructor()
                    {
                        super();
                        this.Version = 0;
                        this.ArgumentCount = 0;
                        this.ImportHandle = 0;
                        this.FunctionNameOffset = 0;
                        this.FunctionNameLength = 0;
                        this.ModuleNameOffset = 0;
                        this.ModuleNameLength = 0;
                        this.Exception = $.$default($.$srij.System.Runtime.InteropServices.JavaScript.JSFunctionBinding.JSBindingType);
                        this.Result = $.$default($.$srij.System.Runtime.InteropServices.JavaScript.JSFunctionBinding.JSBindingType);
                    }
                    //Static Initializer
                    static $sinit()
                    {
                        {
                            this.JSMarshalerSignatureHeaderSize = 32;
                        }
                    }
                    static $h = 654966;
                    static $z = 96;
                    static $f = 0b10100010000001010000000;
                    static $k = 2;
                    static $$md;
                    static get $md() { return this.$$md ??= {"b":196609,"l":[{"t":655361,"n":"JSMarshalerSignatureHeaderSize","d":654966,"h":4295622262,"f":4194344},{"t":655361,"n":"Version","d":654966,"h":8590589558,"f":4194305,"a":[{"t":103940097,"c":4398907393,"a":[{"v":0,"t":655361}]}]},{"t":655361,"n":"ArgumentCount","d":654966,"h":12885556854,"f":4194305,"a":[{"t":103940097,"c":4398907393,"a":[{"v":4,"t":655361}]}]},{"t":655361,"n":"ImportHandle","d":654966,"h":17180524150,"f":4194305,"a":[{"t":103940097,"c":4398907393,"a":[{"v":8,"t":655361}]}]},{"t":655361,"n":"FunctionNameOffset","d":654966,"h":21475491446,"f":4194305,"a":[{"t":103940097,"c":4398907393,"a":[{"v":16,"t":655361}]}]},{"t":655361,"n":"FunctionNameLength","d":654966,"h":25770458742,"f":4194305,"a":[{"t":103940097,"c":4398907393,"a":[{"v":20,"t":655361}]}]},{"t":655361,"n":"ModuleNameOffset","d":654966,"h":30065426038,"f":4194305,"a":[{"t":103940097,"c":4398907393,"a":[{"v":24,"t":655361}]}]},{"t":655361,"n":"ModuleNameLength","d":654966,"h":34360393334,"f":4194305,"a":[{"t":103940097,"c":4398907393,"a":[{"v":28,"t":655361}]}]},{"t":720502,"n":"Result","d":654966,"h":42950327926,"f":4194305,"a":[{"t":103940097,"c":4398907393,"a":[{"v":64,"t":655361}]}]}],"c":[{"n":".ctor","o":"$ctor$2","d":654966,"h":47245295222,"f":16777217}],"d":589430,"h":654966,"a":[{"t":109772801,"c":4404740097,"a":[{"v":2,"t":105250817}],"n":[{"n":"Pack","v":4,"t":655361}]}]}; }
                    static get $b() { return $.$$.System.ValueType; }
                    static get $fullName() { return `System.Runtime.InteropServices.JavaScript.JSFunctionBinding.JSBindingHeader`; }
                }, $cls, ($v) => $cls.$_JSBindingHeader = $v);
            }
            static $_JSBindingType;
            static get JSBindingType()
            {
                let $cls = $.$srij.System.Runtime.InteropServices.JavaScript.JSFunctionBinding;
                return $cls.$_JSBindingType ??= $asm.$nstr("$srij.System.Runtime.InteropServices.JavaScript.JSFunctionBinding.JSBindingType", ($self) => class JSBindingType extends $.$$.System.ValueType
                {
                    /*MarshalerType*/  get Type() { return this.$getField(0, $.$srij.System.Runtime.InteropServices.JavaScript.MarshalerType); }
                    /*MarshalerType*/  set Type(value) { this.$setField(0, $.$srij.System.Runtime.InteropServices.JavaScript.MarshalerType, value); }
                    /*MarshalerType*/  get ResultMarshalerType() { return this.$getField(16, $.$srij.System.Runtime.InteropServices.JavaScript.MarshalerType); }
                    /*MarshalerType*/  set ResultMarshalerType(value) { this.$setField(16, $.$srij.System.Runtime.InteropServices.JavaScript.MarshalerType, value); }
                    /*MarshalerType*/  get Arg1MarshalerType() { return this.$getField(20, $.$srij.System.Runtime.InteropServices.JavaScript.MarshalerType); }
                    /*MarshalerType*/  set Arg1MarshalerType(value) { this.$setField(20, $.$srij.System.Runtime.InteropServices.JavaScript.MarshalerType, value); }
                    /*MarshalerType*/  get Arg2MarshalerType() { return this.$getField(24, $.$srij.System.Runtime.InteropServices.JavaScript.MarshalerType); }
                    /*MarshalerType*/  set Arg2MarshalerType(value) { this.$setField(24, $.$srij.System.Runtime.InteropServices.JavaScript.MarshalerType, value); }
                    /*MarshalerType*/  get Arg3MarshalerType() { return this.$getField(28, $.$srij.System.Runtime.InteropServices.JavaScript.MarshalerType); }
                    /*MarshalerType*/  set Arg3MarshalerType(value) { this.$setField(28, $.$srij.System.Runtime.InteropServices.JavaScript.MarshalerType, value); }
                    //default value type constructor
                    $ctor$2()
                    {
                        return this;
                    }
                    Clone($copy)
                    {
                        let copy = $copy ?? new this.constructor();
                        copy.Type = this.Type;
                        copy.ResultMarshalerType = this.ResultMarshalerType;
                        copy.Arg1MarshalerType = this.Arg1MarshalerType;
                        copy.Arg2MarshalerType = this.Arg2MarshalerType;
                        copy.Arg3MarshalerType = this.Arg3MarshalerType;
                        return copy;
                    }
                    //default member initializer
                    constructor()
                    {
                        super();
                        this.Type = 0;
                        this.ResultMarshalerType = 0;
                        this.Arg1MarshalerType = 0;
                        this.Arg2MarshalerType = 0;
                        this.Arg3MarshalerType = 0;
                    }
                    static $h = 720502;
                    static $z = 32;
                    static $f = 0b10100010000001010000000;
                    static $k = 2;
                    static $$md;
                    static get $md() { return this.$$md ??= {"b":196609,"l":[{"t":3735158,"n":"Type","d":720502,"h":4295687798,"f":4194312,"a":[{"t":103940097,"c":4398907393,"a":[{"v":0,"t":655361}]}]},{"t":3735158,"n":"ResultMarshalerType","d":720502,"h":8590655094,"f":4194312,"a":[{"t":103940097,"c":4398907393,"a":[{"v":16,"t":655361}]}]},{"t":3735158,"n":"Arg1MarshalerType","d":720502,"h":12885622390,"f":4194312,"a":[{"t":103940097,"c":4398907393,"a":[{"v":20,"t":655361}]}]},{"t":3735158,"n":"Arg2MarshalerType","d":720502,"h":17180589686,"f":4194312,"a":[{"t":103940097,"c":4398907393,"a":[{"v":24,"t":655361}]}]},{"t":3735158,"n":"Arg3MarshalerType","d":720502,"h":21475556982,"f":4194312,"a":[{"t":103940097,"c":4398907393,"a":[{"v":28,"t":655361}]}]}],"c":[{"n":".ctor","o":"$ctor$2","d":720502,"h":25770524278,"f":16777217}],"d":589430,"h":720502,"a":[{"t":109772801,"c":4404740097,"a":[{"v":2,"t":105250817}],"n":[{"n":"Pack","v":4,"t":655361},{"n":"Size","v":32,"t":655361}]}]}; }
                    static get $b() { return $.$$.System.ValueType; }
                    static get $fullName() { return `System.Runtime.InteropServices.JavaScript.JSFunctionBinding.JSBindingType`; }
                }, $cls, ($v) => $cls.$_JSBindingType = $v);
            }
            /*int */ get ArgumentCount()
            {
                return this.Header.GetAt(0).ArgumentCount;
            }
            /*int */ set ArgumentCount(value)
            {
                this.Header.GetAt(0).ArgumentCount = value;
            }
            /*int */ get Version()
            {
                return this.Header.GetAt(0).Version;
            }
            /*int */ set Version(value)
            {
                this.Header.GetAt(0).Version = value;
            }
            /*JSBindingType */ get Result()
            {
                return this.Header.GetAt(0).Result;
            }
            /*JSBindingType */ set Result(value)
            {
                this.Header.GetAt(0).Result = value.Clone();
            }
            /*JSBindingType */ get Exception()
            {
                return this.Header.GetAt(0).Exception;
            }
            /*JSBindingType */ set Exception(value)
            {
                this.Header.GetAt(0).Exception = value.Clone();
            }
            /*JSBindingType*/ get_Item(/*int*/ position)
            {
                return this.Sigs.GetAt(((position - 1) | 0));
            }
            static /*void */ InvokeJS(/*JSFunctionBinding*/ signature, /*Span<JSMarshalerArgument>*/ $arguments)
            {
                $.$srij.System.Runtime.InteropServices.JavaScript.JSFunctionBinding.InvokeJSImportImpl(signature, $arguments);
            }
            static /*JSFunctionBinding */ BindJSFunction(/*string*/ functionName, /*string*/ moduleName, /*ReadOnlySpan<JSMarshalerType>*/ signatures)
            {
                if ($.$$.System.Runtime.InteropServices.RuntimeInformation.OSArchitecture !== 4/*Architecture.Wasm*/)
                {
                    throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
                }
                return $.$srij.System.Runtime.InteropServices.JavaScript.JSFunctionBinding.BindJSImportImpl(functionName, moduleName, signatures);
            }
            static /*JSFunctionBinding */ BindManagedFunction(/*string*/ fullyQualifiedName, /*int*/ signatureHash, /*ReadOnlySpan<JSMarshalerType>*/ signatures)
            {
                if ($.$$.System.Runtime.InteropServices.RuntimeInformation.OSArchitecture !== 4/*Architecture.Wasm*/)
                {
                    throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
                }
                return $.$srij.System.Runtime.InteropServices.JavaScript.JSHostImplementation.BindManagedFunction(fullyQualifiedName, signatureHash, signatures);
            }
            static /*void */ InvokeJSFunction(/*JSObject*/ jsFunction, /*Span<JSMarshalerArgument>*/ $arguments)
            {
                jsFunction.AssertNotDisposed();
                $.$srij.System.Runtime.InteropServices.JavaScript.JSFunctionBinding.InvokeJSFunctionCurrent(jsFunction, $arguments);
            }
            static /*void */ InvokeJSFunctionCurrent(/*JSObject*/ jsFunction, /*Span<JSMarshalerArgument>*/ $arguments)
            {
                /*var*/ let functionHandle = jsFunction.JSHandle;
                /*fixed*/ 
                {
                    /*JSMarshalerArgument**/ let ptr = $arguments.GetPinnableReference();
                    $.$srij.Interop.Runtime.InvokeJSFunction(functionHandle, $.$cast(ptr, $.$$.System.IntPtr));
                    /*ref JSMarshalerArgument*/ let exceptionArg = $arguments.get_Item(0);
                    if (exceptionArg.$v.slot.Type !== 0/*MarshalerType.None*/)
                    {
                        $.$srij.System.Runtime.InteropServices.JavaScript.JSHostImplementation.ThrowException(exceptionArg);
                    }
                }
            }
            static /*void */ InvokeJSImportImpl(/*JSFunctionBinding*/ signature, /*Span<JSMarshalerArgument>*/ $arguments)
            {
                /*ref JSMarshalerArgument*/ let exc = $arguments.get_Item(0);
                /*ref JSMarshalerArgument*/ let res = $arguments.get_Item(1);
                /*var*/ let targetContext = $.$srij.System.Runtime.InteropServices.JavaScript.JSProxyContext.MainThreadContext;
                if (signature.IsAsync)
                {
                    /*var*/ let holder = targetContext.CreatePromiseHolder();
                    res.$v.slot.Type = 30/*MarshalerType.TaskPreCreated*/;
                    res.$v.slot.GCHandle = holder.GCHandle;
                }
                if (signature.IsDiscardNoWait)
                {
                    $arguments.get_Item(1).$v.slot.Type = 26/*MarshalerType.DiscardNoWait*/;
                }
                $.$srij.System.Runtime.InteropServices.JavaScript.JSFunctionBinding.InvokeJSImportCurrent(signature, $arguments);
                if (signature.IsAsync)
                {
                    if ($arguments.get_Item(1).$v.slot.Type === 0/*MarshalerType.None*/)
                    {
                        /*var*/ let holderHandle = $.$$.System.Runtime.InteropServices.GCHandle.op_Explicit$1($arguments.get_Item(1).$v.slot.GCHandle);
                        holderHandle.Free();
                    }
                }
            }
            static /*void */ InvokeJSImportCurrent(/*JSFunctionBinding*/ signature, /*Span<JSMarshalerArgument>*/ $arguments)
            {
                /*fixed*/ 
                {
                    /*JSMarshalerArgument**/ let args = $arguments.GetPinnableReference();
                    $.$srij.Interop.Runtime.InvokeJSImportST(signature.ImportHandle, $.$cast(args, $.$$.System.IntPtr));
                }
                /*ref JSMarshalerArgument*/ let exceptionArg = $arguments.get_Item(0);
                if (exceptionArg.$v.slot.Type !== 0/*MarshalerType.None*/)
                {
                    $.$srij.System.Runtime.InteropServices.JavaScript.JSHostImplementation.ThrowException(exceptionArg);
                }
            }
            static /*JSFunctionBinding */ BindJSImportImpl(/*string*/ functionName, /*string*/ moduleName, /*ReadOnlySpan<JSMarshalerType>*/ signatures)
            {
                /*var*/ let signature = $.$srij.System.Runtime.InteropServices.JavaScript.JSHostImplementation.GetMethodSignature(signatures, functionName, moduleName);
                /*nint*/ let exceptionPtr = $.$srij.Interop.Runtime.BindJSImportST(signature.Header);
                if (exceptionPtr !== $.$$.System.IntPtr.Zero)
                {
                    /*var*/ let message = $.$$.System.Runtime.InteropServices.Marshal.PtrToStringUni$1(exceptionPtr);
                    $.$$.System.Runtime.InteropServices.Marshal.FreeHGlobal(exceptionPtr);
                    throw new $.$srij.System.Runtime.InteropServices.JavaScript.JSException().$ctor$6(message);
                }
                $.$srij.System.Runtime.InteropServices.JavaScript.JSHostImplementation.FreeMethodSignatureBuffer(signature);
                return signature;
            }
            static /*void */ ResolveOrRejectPromise(/*JSProxyContext*/ targetContext, /*Span<JSMarshalerArgument>*/ $arguments)
            {
                /*ref JSMarshalerArgument*/ let exc = $arguments.get_Item(0);
                {
                    /*fixed*/ 
                    {
                        /*JSMarshalerArgument**/ let ptr = $arguments.GetPinnableReference();
                        $.$srij.Interop.Runtime.ResolveOrRejectPromise($.$cast(ptr, $.$$.System.IntPtr));
                        if (exc.$v.slot.Type !== 0/*MarshalerType.None*/)
                        {
                            $.$srij.System.Runtime.InteropServices.JavaScript.JSHostImplementation.ThrowException(exc);
                        }
                    }
                }
            }
            //default member initializer
            constructor()
            {
                super();
                this.Header = $.$default($.$typePointer($.$srij.System.Runtime.InteropServices.JavaScript.JSFunctionBinding.JSBindingHeader));
                this.Sigs = $.$default($.$typePointer($.$srij.System.Runtime.InteropServices.JavaScript.JSFunctionBinding.JSBindingType));
            }
            static $h = 589430;
            static $f = 0b10010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":655361,"g":{"r":0,"d":0,"h":51540196982,"f":50331656},"s":{"r":0,"d":0,"h":55835164278,"f":83886088},"n":"ArgumentCount","d":589430,"h":47245229686,"f":2097160},{"p":655361,"g":{"r":0,"d":0,"h":64425098870,"f":50331656},"s":{"r":0,"d":0,"h":68720066166,"f":83886088},"n":"Version","d":589430,"h":60130131574,"f":2097160},{"p":720502,"g":{"r":0,"d":0,"h":77310000758,"f":50331656},"s":{"r":0,"d":0,"h":81604968054,"f":83886088},"n":"Result","d":589430,"h":73015033462,"f":2097160},{"p":720502,"i":[{"n":"position","p":655361}],"g":{"r":0,"d":0,"h":103079804534,"f":50331656},"n":"Item","o":"@$2","d":589430,"h":98784837238,"f":2097160}],"m":[{"r":65537,"p":[{"n":"signature","p":589430},{"n":"arguments","p":$.$$.System.Span$$($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument).$h}],"n":"InvokeJS","d":589430,"h":107374771830,"f":16777249},{"r":589430,"p":[{"n":"functionName","p":1310721},{"n":"moduleName","p":1310721},{"n":"signatures","p":$.$$.System.ReadOnlySpan$$($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType).$h}],"n":"BindJSFunction","d":589430,"h":111669739126,"f":16777249},{"r":589430,"p":[{"n":"fullyQualifiedName","p":1310721},{"n":"signatureHash","p":655361},{"n":"signatures","p":$.$$.System.ReadOnlySpan$$($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType).$h}],"n":"BindManagedFunction","d":589430,"h":115964706422,"f":16777249},{"r":65537,"p":[{"n":"jsFunction","p":2293366},{"n":"arguments","p":$.$$.System.Span$$($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument).$h}],"n":"InvokeJSFunction","d":589430,"h":120259673718,"f":16777256},{"r":65537,"p":[{"n":"jsFunction","p":2293366},{"n":"arguments","p":$.$$.System.Span$$($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument).$h}],"n":"InvokeJSFunctionCurrent","d":589430,"h":124554641014,"f":16777256},{"r":65537,"p":[{"n":"signature","p":589430},{"n":"arguments","p":$.$$.System.Span$$($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument).$h}],"n":"InvokeJSImportImpl","d":589430,"h":128849608310,"f":16777256},{"r":65537,"p":[{"n":"signature","p":589430},{"n":"arguments","p":$.$$.System.Span$$($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument).$h}],"n":"InvokeJSImportCurrent","d":589430,"h":133144575606,"f":16777256},{"r":589430,"p":[{"n":"functionName","p":1310721},{"n":"moduleName","p":1310721},{"n":"signatures","p":$.$$.System.ReadOnlySpan$$($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType).$h}],"n":"BindJSImportImpl","d":589430,"h":137439542902,"f":16777256},{"r":65537,"p":[{"n":"targetContext","p":2358902},{"n":"arguments","p":$.$$.System.Span$$($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument).$h}],"n":"ResolveOrRejectPromise","d":589430,"h":141734510198,"f":16777256}],"l":[{"t":$.$typePointer($.$srij.System.Runtime.InteropServices.JavaScript.JSFunctionBinding.JSBindingHeader).$h,"n":"Header","d":589430,"h":8590524022,"f":4194312},{"t":$.$typePointer($.$srij.System.Runtime.InteropServices.JavaScript.JSFunctionBinding.JSBindingType).$h,"n":"Sigs","d":589430,"h":12885491318,"f":4194312},{"t":720897,"n":"nextImportHandle","d":589430,"h":17180458614,"f":4194344},{"t":655361,"n":"ImportHandle","d":589430,"h":21475425910,"f":4194312},{"t":262145,"n":"IsAsync","d":589430,"h":25770393206,"f":4194312},{"t":262145,"n":"IsDiscardNoWait","d":589430,"h":30065360502,"f":4194312},{"t":1310721,"n":"FunctionName","d":589430,"h":34360327798,"f":4194312}],"c":[{"n":".ctor","o":"$ctor$1","d":589430,"h":4295556726,"f":16777224}],"j":[654966,720502],"h":589430,"a":[{"t":23527425,"c":8613462017,"a":[{"v":false,"t":262145}]},{"t":114819073,"c":4409786369,"a":[{"v":"browser","t":1310721}]},{"t":33292289,"c":4328259585,"a":[{"v":1,"t":33357825}]}]}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `System.Runtime.InteropServices.JavaScript.JSFunctionBinding`; }
        });
        
        $asm.$cls("$srij.System.Runtime.InteropServices.JavaScript.CancelablePromise", ($self) => class CancelablePromise
        {
            static /*void */ CancelPromise(/*Task*/ promise)
            {
                if (promise.IsCompleted)
                {
                    return;
                }
                /*JSHostImplementation.PromiseHolder?*/ let holder = $.$as(promise.AsyncState, $.$srij.System.Runtime.InteropServices.JavaScript.JSHostImplementation.PromiseHolder);
                if (holder === null)
                {
                    throw new $.$$.System.InvalidOperationException().$ctor$12("Expected Task converted from JS Promise");
                }
                if (holder.IsDisposed)
                {
                    return;
                }
                $.$srij.Interop.Runtime.CancelPromise(holder.GCHandle);
            }
            static $h = 261750;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"m":[{"r":65537,"p":[{"n":"promise","p":133169153}],"n":"CancelPromise","d":261750,"h":4295229046,"f":16777249}],"h":261750}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `System.Runtime.InteropServices.JavaScript.CancelablePromise`; }
        });
        
        $asm.$cls("$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType", ($self) => class JSMarshalerType extends $.$$.System.Object
        {
            /*JSFunctionBinding.JSBindingType*/ _signatureType;
            $ctor$1()
            {
                super.$ctor();
                {
                    this._signatureType = $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType.Void._signatureType;
                }
                return this;
            }
            $ctor$2(/*JSFunctionBinding.JSBindingType*/ signatureType)
            {
                super.$ctor();
                {
                    this._signatureType = signatureType.Clone();
                }
                return this;
            }
            /*JSMarshalerType*/ static Void = null;
            /*JSMarshalerType*/ static Discard = null;
            /*JSMarshalerType*/ static DiscardNoWait = null;
            /*JSMarshalerType*/ static Boolean = null;
            /*JSMarshalerType*/ static Byte = null;
            /*JSMarshalerType*/ static Char = null;
            /*JSMarshalerType*/ static Int16 = null;
            /*JSMarshalerType*/ static Int32 = null;
            /*JSMarshalerType*/ static Int52 = null;
            /*JSMarshalerType*/ static BigInt64 = null;
            /*JSMarshalerType*/ static Double = null;
            /*JSMarshalerType*/ static Single = null;
            /*JSMarshalerType*/ static IntPtr = null;
            /*JSMarshalerType*/ static JSObject = null;
            /*JSMarshalerType*/ static Object = null;
            /*JSMarshalerType*/ static String = null;
            /*JSMarshalerType*/ static Exception = null;
            /*JSMarshalerType*/ static DateTime = null;
            /*JSMarshalerType*/ static DateTimeOffset = null;
            static /*JSMarshalerType */ Nullable(/*JSMarshalerType*/ primitive)
            {
                $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType.CheckNullable(primitive);
                return new $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType().$ctor$2((() =>
                {
                    //new $.$srij.System.Runtime.InteropServices.JavaScript.JSFunctionBinding.JSBindingType()
                    const $t1 = $.$srij.System.Runtime.InteropServices.JavaScript.JSFunctionBinding.JSBindingType;
                    const $i1 = new $t1();
                    $i1.Type = 19/*MarshalerType.Nullable*/;
                    $i1.ResultMarshalerType = primitive._signatureType.Type;
                    return $i1;
                })());
            }
            /*JSMarshalerType*/ static _task = null;
            static /*JSMarshalerType */ Task()
            {
                return $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType._task;
            }
            static /*JSMarshalerType */ Task$1(/*JSMarshalerType*/ result)
            {
                $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType.CheckTask(result);
                return new $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType().$ctor$2((() =>
                {
                    //new $.$srij.System.Runtime.InteropServices.JavaScript.JSFunctionBinding.JSBindingType()
                    const $t1 = $.$srij.System.Runtime.InteropServices.JavaScript.JSFunctionBinding.JSBindingType;
                    const $i1 = new $t1();
                    $i1.Type = 20/*MarshalerType.Task*/;
                    $i1.ResultMarshalerType = result._signatureType.Type;
                    return $i1;
                })());
            }
            static /*JSMarshalerType */ Array(/*JSMarshalerType*/ element)
            {
                $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType.CheckArray(element);
                return new $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType().$ctor$2((() =>
                {
                    //new $.$srij.System.Runtime.InteropServices.JavaScript.JSFunctionBinding.JSBindingType()
                    const $t1 = $.$srij.System.Runtime.InteropServices.JavaScript.JSFunctionBinding.JSBindingType;
                    const $i1 = new $t1();
                    $i1.Type = 21/*MarshalerType.Array*/;
                    $i1.Arg1MarshalerType = element._signatureType.Type;
                    return $i1;
                })());
            }
            static /*JSMarshalerType */ ArraySegment(/*JSMarshalerType*/ element)
            {
                $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType.CheckArraySegment(element);
                return new $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType().$ctor$2((() =>
                {
                    //new $.$srij.System.Runtime.InteropServices.JavaScript.JSFunctionBinding.JSBindingType()
                    const $t1 = $.$srij.System.Runtime.InteropServices.JavaScript.JSFunctionBinding.JSBindingType;
                    const $i1 = new $t1();
                    $i1.Type = 22/*MarshalerType.ArraySegment*/;
                    $i1.Arg1MarshalerType = element._signatureType.Type;
                    return $i1;
                })());
            }
            static /*JSMarshalerType */ Span(/*JSMarshalerType*/ element)
            {
                $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType.CheckArraySegment(element);
                return new $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType().$ctor$2((() =>
                {
                    //new $.$srij.System.Runtime.InteropServices.JavaScript.JSFunctionBinding.JSBindingType()
                    const $t1 = $.$srij.System.Runtime.InteropServices.JavaScript.JSFunctionBinding.JSBindingType;
                    const $i1 = new $t1();
                    $i1.Type = 23/*MarshalerType.Span*/;
                    $i1.Arg1MarshalerType = element._signatureType.Type;
                    return $i1;
                })());
            }
            /*JSMarshalerType*/ static _action = null;
            static /*JSMarshalerType */ Action()
            {
                return $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType._action;
            }
            static /*JSMarshalerType */ Action$3(/*JSMarshalerType*/ arg1)
            {
                $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType.CheckTask(arg1);
                return new $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType().$ctor$2((() =>
                {
                    //new $.$srij.System.Runtime.InteropServices.JavaScript.JSFunctionBinding.JSBindingType()
                    const $t1 = $.$srij.System.Runtime.InteropServices.JavaScript.JSFunctionBinding.JSBindingType;
                    const $i1 = new $t1();
                    $i1.Type = 24/*MarshalerType.Action*/;
                    $i1.Arg1MarshalerType = arg1._signatureType.Type;
                    return $i1;
                })());
            }
            static /*JSMarshalerType */ Action$2(/*JSMarshalerType*/ arg1, /*JSMarshalerType*/ arg2)
            {
                $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType.CheckTask(arg1);
                $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType.CheckTask(arg2);
                return new $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType().$ctor$2((() =>
                {
                    //new $.$srij.System.Runtime.InteropServices.JavaScript.JSFunctionBinding.JSBindingType()
                    const $t1 = $.$srij.System.Runtime.InteropServices.JavaScript.JSFunctionBinding.JSBindingType;
                    const $i1 = new $t1();
                    $i1.Type = 24/*MarshalerType.Action*/;
                    $i1.Arg1MarshalerType = arg1._signatureType.Type;
                    $i1.Arg2MarshalerType = arg2._signatureType.Type;
                    return $i1;
                })());
            }
            static /*JSMarshalerType */ Action$1(/*JSMarshalerType*/ arg1, /*JSMarshalerType*/ arg2, /*JSMarshalerType*/ arg3)
            {
                $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType.CheckTask(arg1);
                $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType.CheckTask(arg2);
                $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType.CheckTask(arg3);
                return new $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType().$ctor$2((() =>
                {
                    //new $.$srij.System.Runtime.InteropServices.JavaScript.JSFunctionBinding.JSBindingType()
                    const $t1 = $.$srij.System.Runtime.InteropServices.JavaScript.JSFunctionBinding.JSBindingType;
                    const $i1 = new $t1();
                    $i1.Type = 24/*MarshalerType.Action*/;
                    $i1.Arg1MarshalerType = arg1._signatureType.Type;
                    $i1.Arg2MarshalerType = arg2._signatureType.Type;
                    $i1.Arg3MarshalerType = arg3._signatureType.Type;
                    return $i1;
                })());
            }
            static /*JSMarshalerType */ Function$3(/*JSMarshalerType*/ result)
            {
                $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType.CheckTask(result);
                return new $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType().$ctor$2((() =>
                {
                    //new $.$srij.System.Runtime.InteropServices.JavaScript.JSFunctionBinding.JSBindingType()
                    const $t1 = $.$srij.System.Runtime.InteropServices.JavaScript.JSFunctionBinding.JSBindingType;
                    const $i1 = new $t1();
                    $i1.Type = 25/*MarshalerType.Function*/;
                    $i1.ResultMarshalerType = result._signatureType.Type;
                    return $i1;
                })());
            }
            static /*JSMarshalerType */ Function$2(/*JSMarshalerType*/ arg1, /*JSMarshalerType*/ result)
            {
                $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType.CheckTask(arg1);
                $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType.CheckTask(result);
                return new $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType().$ctor$2((() =>
                {
                    //new $.$srij.System.Runtime.InteropServices.JavaScript.JSFunctionBinding.JSBindingType()
                    const $t1 = $.$srij.System.Runtime.InteropServices.JavaScript.JSFunctionBinding.JSBindingType;
                    const $i1 = new $t1();
                    $i1.Type = 25/*MarshalerType.Function*/;
                    $i1.Arg1MarshalerType = arg1._signatureType.Type;
                    $i1.ResultMarshalerType = result._signatureType.Type;
                    return $i1;
                })());
            }
            static /*JSMarshalerType */ Function$1(/*JSMarshalerType*/ arg1, /*JSMarshalerType*/ arg2, /*JSMarshalerType*/ result)
            {
                $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType.CheckTask(arg1);
                $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType.CheckTask(arg2);
                $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType.CheckTask(result);
                return new $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType().$ctor$2((() =>
                {
                    //new $.$srij.System.Runtime.InteropServices.JavaScript.JSFunctionBinding.JSBindingType()
                    const $t1 = $.$srij.System.Runtime.InteropServices.JavaScript.JSFunctionBinding.JSBindingType;
                    const $i1 = new $t1();
                    $i1.Type = 25/*MarshalerType.Function*/;
                    $i1.Arg1MarshalerType = arg1._signatureType.Type;
                    $i1.Arg2MarshalerType = arg2._signatureType.Type;
                    $i1.ResultMarshalerType = result._signatureType.Type;
                    return $i1;
                })());
            }
            static /*JSMarshalerType */ Function(/*JSMarshalerType*/ arg1, /*JSMarshalerType*/ arg2, /*JSMarshalerType*/ arg3, /*JSMarshalerType*/ result)
            {
                $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType.CheckTask(arg1);
                $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType.CheckTask(arg2);
                $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType.CheckTask(arg3);
                $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType.CheckTask(result);
                return new $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType().$ctor$2((() =>
                {
                    //new $.$srij.System.Runtime.InteropServices.JavaScript.JSFunctionBinding.JSBindingType()
                    const $t1 = $.$srij.System.Runtime.InteropServices.JavaScript.JSFunctionBinding.JSBindingType;
                    const $i1 = new $t1();
                    $i1.Type = 25/*MarshalerType.Function*/;
                    $i1.Arg1MarshalerType = arg1._signatureType.Type;
                    $i1.Arg2MarshalerType = arg2._signatureType.Type;
                    $i1.Arg3MarshalerType = arg3._signatureType.Type;
                    $i1.ResultMarshalerType = result._signatureType.Type;
                    return $i1;
                })());
            }
            static /*void */ CheckNullable(/*JSMarshalerType*/ underlyingType)
            {
                /*MarshalerType*/ let underlying = underlyingType._signatureType.Type;
                if (underlying === 3/*MarshalerType.Boolean*/ || underlying === 4/*MarshalerType.Byte*/ || underlying === 6/*MarshalerType.Int16*/ || underlying === 7/*MarshalerType.Int32*/ || underlying === 9/*MarshalerType.BigInt64*/ || underlying === 8/*MarshalerType.Int52*/ || underlying === 12/*MarshalerType.IntPtr*/ || underlying === 10/*MarshalerType.Double*/ || underlying === 11/*MarshalerType.Single*/ || underlying === 5/*MarshalerType.Char*/ || underlying === 17/*MarshalerType.DateTime*/ || underlying === 18/*MarshalerType.DateTimeOffset*/)
                {
                    return;
                }
                throw new $.$$.System.ArgumentException().$ctor$13($.$srij.System.SR.Format$6($.$srij.System.SR.UnsupportedNullableType, $.$box(underlying, $.$srij.System.Runtime.InteropServices.JavaScript.MarshalerType)), "underlyingType");
            }
            static /*void */ CheckArray(/*JSMarshalerType*/ underlyingType)
            {
                /*MarshalerType*/ let underlying = underlyingType._signatureType.Type;
                if (underlying === 4/*MarshalerType.Byte*/ || underlying === 7/*MarshalerType.Int32*/ || underlying === 10/*MarshalerType.Double*/ || underlying === 15/*MarshalerType.String*/ || underlying === 14/*MarshalerType.Object*/ || underlying === 13/*MarshalerType.JSObject*/)
                {
                    return;
                }
                throw new $.$$.System.ArgumentException().$ctor$13($.$srij.System.SR.Format$6($.$srij.System.SR.UnsupportedElementType, $.$box(underlying, $.$srij.System.Runtime.InteropServices.JavaScript.MarshalerType)), "underlyingType");
            }
            static /*void */ CheckArraySegment(/*JSMarshalerType*/ underlyingType)
            {
                /*MarshalerType*/ let underlying = underlyingType._signatureType.Type;
                if (underlying === 4/*MarshalerType.Byte*/ || underlying === 7/*MarshalerType.Int32*/ || underlying === 10/*MarshalerType.Double*/)
                {
                    return;
                }
                throw new $.$$.System.ArgumentException().$ctor$13($.$srij.System.SR.Format$6($.$srij.System.SR.UnsupportedElementType, $.$box(underlying, $.$srij.System.Runtime.InteropServices.JavaScript.MarshalerType)), "underlyingType");
            }
            static /*void */ CheckTask(/*JSMarshalerType*/ underlyingType)
            {
                /*MarshalerType*/ let underlying = underlyingType._signatureType.Type;
                if (underlying === 21/*MarshalerType.Array*/ || underlying === 22/*MarshalerType.ArraySegment*/ || underlying === 23/*MarshalerType.Span*/ || underlying === 20/*MarshalerType.Task*/ || underlying === 24/*MarshalerType.Action*/ || underlying === 25/*MarshalerType.Function*/)
                {
                    throw new $.$$.System.ArgumentException().$ctor$13($.$srij.System.SR.Format$6($.$srij.System.SR.UnsupportedTaskResultType, $.$box(underlying, $.$srij.System.Runtime.InteropServices.JavaScript.MarshalerType)), "underlyingType");
                }
            }
            //default member initializer
            constructor()
            {
                super();
                this._signatureType = $.$default($.$srij.System.Runtime.InteropServices.JavaScript.JSFunctionBinding.JSBindingType);
            }
            //Static Initializer
            static $sinit()
            {
                {
                    this.Void = new $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType().$ctor$2((() =>
                    {
                        //new $.$srij.System.Runtime.InteropServices.JavaScript.JSFunctionBinding.JSBindingType()
                        const $t1 = $.$srij.System.Runtime.InteropServices.JavaScript.JSFunctionBinding.JSBindingType;
                        const $i1 = new $t1();
                        $i1.Type = 1/*MarshalerType.Void*/;
                        return $i1;
                    })());
                }
                {
                    this.Discard = new $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType().$ctor$2((() =>
                    {
                        //new $.$srij.System.Runtime.InteropServices.JavaScript.JSFunctionBinding.JSBindingType()
                        const $t1 = $.$srij.System.Runtime.InteropServices.JavaScript.JSFunctionBinding.JSBindingType;
                        const $i1 = new $t1();
                        $i1.Type = 2/*MarshalerType.Discard*/;
                        return $i1;
                    })());
                }
                {
                    this.DiscardNoWait = new $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType().$ctor$2((() =>
                    {
                        //new $.$srij.System.Runtime.InteropServices.JavaScript.JSFunctionBinding.JSBindingType()
                        const $t1 = $.$srij.System.Runtime.InteropServices.JavaScript.JSFunctionBinding.JSBindingType;
                        const $i1 = new $t1();
                        $i1.Type = 26/*MarshalerType.DiscardNoWait*/;
                        return $i1;
                    })());
                }
                {
                    this.Boolean = new $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType().$ctor$2((() =>
                    {
                        //new $.$srij.System.Runtime.InteropServices.JavaScript.JSFunctionBinding.JSBindingType()
                        const $t1 = $.$srij.System.Runtime.InteropServices.JavaScript.JSFunctionBinding.JSBindingType;
                        const $i1 = new $t1();
                        $i1.Type = 3/*MarshalerType.Boolean*/;
                        return $i1;
                    })());
                }
                {
                    this.Byte = new $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType().$ctor$2((() =>
                    {
                        //new $.$srij.System.Runtime.InteropServices.JavaScript.JSFunctionBinding.JSBindingType()
                        const $t1 = $.$srij.System.Runtime.InteropServices.JavaScript.JSFunctionBinding.JSBindingType;
                        const $i1 = new $t1();
                        $i1.Type = 4/*MarshalerType.Byte*/;
                        return $i1;
                    })());
                }
                {
                    this.Char = new $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType().$ctor$2((() =>
                    {
                        //new $.$srij.System.Runtime.InteropServices.JavaScript.JSFunctionBinding.JSBindingType()
                        const $t1 = $.$srij.System.Runtime.InteropServices.JavaScript.JSFunctionBinding.JSBindingType;
                        const $i1 = new $t1();
                        $i1.Type = 5/*MarshalerType.Char*/;
                        return $i1;
                    })());
                }
                {
                    this.Int16 = new $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType().$ctor$2((() =>
                    {
                        //new $.$srij.System.Runtime.InteropServices.JavaScript.JSFunctionBinding.JSBindingType()
                        const $t1 = $.$srij.System.Runtime.InteropServices.JavaScript.JSFunctionBinding.JSBindingType;
                        const $i1 = new $t1();
                        $i1.Type = 6/*MarshalerType.Int16*/;
                        return $i1;
                    })());
                }
                {
                    this.Int32 = new $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType().$ctor$2((() =>
                    {
                        //new $.$srij.System.Runtime.InteropServices.JavaScript.JSFunctionBinding.JSBindingType()
                        const $t1 = $.$srij.System.Runtime.InteropServices.JavaScript.JSFunctionBinding.JSBindingType;
                        const $i1 = new $t1();
                        $i1.Type = 7/*MarshalerType.Int32*/;
                        return $i1;
                    })());
                }
                {
                    this.Int52 = new $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType().$ctor$2((() =>
                    {
                        //new $.$srij.System.Runtime.InteropServices.JavaScript.JSFunctionBinding.JSBindingType()
                        const $t1 = $.$srij.System.Runtime.InteropServices.JavaScript.JSFunctionBinding.JSBindingType;
                        const $i1 = new $t1();
                        $i1.Type = 8/*MarshalerType.Int52*/;
                        return $i1;
                    })());
                }
                {
                    this.BigInt64 = new $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType().$ctor$2((() =>
                    {
                        //new $.$srij.System.Runtime.InteropServices.JavaScript.JSFunctionBinding.JSBindingType()
                        const $t1 = $.$srij.System.Runtime.InteropServices.JavaScript.JSFunctionBinding.JSBindingType;
                        const $i1 = new $t1();
                        $i1.Type = 9/*MarshalerType.BigInt64*/;
                        return $i1;
                    })());
                }
                {
                    this.Double = new $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType().$ctor$2((() =>
                    {
                        //new $.$srij.System.Runtime.InteropServices.JavaScript.JSFunctionBinding.JSBindingType()
                        const $t1 = $.$srij.System.Runtime.InteropServices.JavaScript.JSFunctionBinding.JSBindingType;
                        const $i1 = new $t1();
                        $i1.Type = 10/*MarshalerType.Double*/;
                        return $i1;
                    })());
                }
                {
                    this.Single = new $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType().$ctor$2((() =>
                    {
                        //new $.$srij.System.Runtime.InteropServices.JavaScript.JSFunctionBinding.JSBindingType()
                        const $t1 = $.$srij.System.Runtime.InteropServices.JavaScript.JSFunctionBinding.JSBindingType;
                        const $i1 = new $t1();
                        $i1.Type = 11/*MarshalerType.Single*/;
                        return $i1;
                    })());
                }
                {
                    this.IntPtr = new $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType().$ctor$2((() =>
                    {
                        //new $.$srij.System.Runtime.InteropServices.JavaScript.JSFunctionBinding.JSBindingType()
                        const $t1 = $.$srij.System.Runtime.InteropServices.JavaScript.JSFunctionBinding.JSBindingType;
                        const $i1 = new $t1();
                        $i1.Type = 12/*MarshalerType.IntPtr*/;
                        return $i1;
                    })());
                }
                {
                    this.JSObject = new $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType().$ctor$2((() =>
                    {
                        //new $.$srij.System.Runtime.InteropServices.JavaScript.JSFunctionBinding.JSBindingType()
                        const $t1 = $.$srij.System.Runtime.InteropServices.JavaScript.JSFunctionBinding.JSBindingType;
                        const $i1 = new $t1();
                        $i1.Type = 13/*MarshalerType.JSObject*/;
                        return $i1;
                    })());
                }
                {
                    this.Object = new $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType().$ctor$2((() =>
                    {
                        //new $.$srij.System.Runtime.InteropServices.JavaScript.JSFunctionBinding.JSBindingType()
                        const $t1 = $.$srij.System.Runtime.InteropServices.JavaScript.JSFunctionBinding.JSBindingType;
                        const $i1 = new $t1();
                        $i1.Type = 14/*MarshalerType.Object*/;
                        return $i1;
                    })());
                }
                {
                    this.String = new $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType().$ctor$2((() =>
                    {
                        //new $.$srij.System.Runtime.InteropServices.JavaScript.JSFunctionBinding.JSBindingType()
                        const $t1 = $.$srij.System.Runtime.InteropServices.JavaScript.JSFunctionBinding.JSBindingType;
                        const $i1 = new $t1();
                        $i1.Type = 15/*MarshalerType.String*/;
                        return $i1;
                    })());
                }
                {
                    this.Exception = new $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType().$ctor$2((() =>
                    {
                        //new $.$srij.System.Runtime.InteropServices.JavaScript.JSFunctionBinding.JSBindingType()
                        const $t1 = $.$srij.System.Runtime.InteropServices.JavaScript.JSFunctionBinding.JSBindingType;
                        const $i1 = new $t1();
                        $i1.Type = 16/*MarshalerType.Exception*/;
                        return $i1;
                    })());
                }
                {
                    this.DateTime = new $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType().$ctor$2((() =>
                    {
                        //new $.$srij.System.Runtime.InteropServices.JavaScript.JSFunctionBinding.JSBindingType()
                        const $t1 = $.$srij.System.Runtime.InteropServices.JavaScript.JSFunctionBinding.JSBindingType;
                        const $i1 = new $t1();
                        $i1.Type = 17/*MarshalerType.DateTime*/;
                        return $i1;
                    })());
                }
                {
                    this.DateTimeOffset = new $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType().$ctor$2((() =>
                    {
                        //new $.$srij.System.Runtime.InteropServices.JavaScript.JSFunctionBinding.JSBindingType()
                        const $t1 = $.$srij.System.Runtime.InteropServices.JavaScript.JSFunctionBinding.JSBindingType;
                        const $i1 = new $t1();
                        $i1.Type = 18/*MarshalerType.DateTimeOffset*/;
                        return $i1;
                    })());
                }
                {
                    this._task = new $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType().$ctor$2((() =>
                    {
                        //new $.$srij.System.Runtime.InteropServices.JavaScript.JSFunctionBinding.JSBindingType()
                        const $t1 = $.$srij.System.Runtime.InteropServices.JavaScript.JSFunctionBinding.JSBindingType;
                        const $i1 = new $t1();
                        $i1.Type = 20/*MarshalerType.Task*/;
                        return $i1;
                    })());
                }
                {
                    this._action = new $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType().$ctor$2((() =>
                    {
                        //new $.$srij.System.Runtime.InteropServices.JavaScript.JSFunctionBinding.JSBindingType()
                        const $t1 = $.$srij.System.Runtime.InteropServices.JavaScript.JSFunctionBinding.JSBindingType;
                        const $i1 = new $t1();
                        $i1.Type = 24/*MarshalerType.Action*/;
                        return $i1;
                    })());
                }
            }
            static $h = 2227830;
            static $f = 0b10010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":2227830,"g":{"r":0,"d":0,"h":25772031606,"f":50331681},"n":"Void","d":2227830,"h":21477064310,"f":2097185},{"p":2227830,"g":{"r":0,"d":0,"h":38656933494,"f":50331681},"n":"Discard","d":2227830,"h":34361966198,"f":2097185},{"p":2227830,"g":{"r":0,"d":0,"h":51541835382,"f":50331681},"n":"DiscardNoWait","d":2227830,"h":47246868086,"f":2097185},{"p":2227830,"g":{"r":0,"d":0,"h":64426737270,"f":50331681},"n":"Boolean","d":2227830,"h":60131769974,"f":2097185},{"p":2227830,"g":{"r":0,"d":0,"h":77311639158,"f":50331681},"n":"Byte","d":2227830,"h":73016671862,"f":2097185},{"p":2227830,"g":{"r":0,"d":0,"h":90196541046,"f":50331681},"n":"Char","d":2227830,"h":85901573750,"f":2097185},{"p":2227830,"g":{"r":0,"d":0,"h":103081442934,"f":50331681},"n":"Int16","d":2227830,"h":98786475638,"f":2097185},{"p":2227830,"g":{"r":0,"d":0,"h":115966344822,"f":50331681},"n":"Int32","d":2227830,"h":111671377526,"f":2097185},{"p":2227830,"g":{"r":0,"d":0,"h":128851246710,"f":50331681},"n":"Int52","d":2227830,"h":124556279414,"f":2097185},{"p":2227830,"g":{"r":0,"d":0,"h":141736148598,"f":50331681},"n":"BigInt64","d":2227830,"h":137441181302,"f":2097185},{"p":2227830,"g":{"r":0,"d":0,"h":154621050486,"f":50331681},"n":"Double","d":2227830,"h":150326083190,"f":2097185},{"p":2227830,"g":{"r":0,"d":0,"h":167505952374,"f":50331681},"n":"Single","d":2227830,"h":163210985078,"f":2097185},{"p":2227830,"g":{"r":0,"d":0,"h":180390854262,"f":50331681},"n":"IntPtr","d":2227830,"h":176095886966,"f":2097185},{"p":2227830,"g":{"r":0,"d":0,"h":193275756150,"f":50331681},"n":"JSObject","d":2227830,"h":188980788854,"f":2097185},{"p":2227830,"g":{"r":0,"d":0,"h":206160658038,"f":50331681},"n":"Object","d":2227830,"h":201865690742,"f":2097185},{"p":2227830,"g":{"r":0,"d":0,"h":219045559926,"f":50331681},"n":"String","d":2227830,"h":214750592630,"f":2097185},{"p":2227830,"g":{"r":0,"d":0,"h":244815363702,"f":50331681},"n":"DateTime","d":2227830,"h":240520396406,"f":2097185},{"p":2227830,"g":{"r":0,"d":0,"h":257700265590,"f":50331681},"n":"DateTimeOffset","d":2227830,"h":253405298294,"f":2097185},{"p":2227830,"g":{"r":0,"d":0,"h":274880134774,"f":50331682},"n":"_task","d":2227830,"h":270585167478,"f":2097186},{"p":2227830,"g":{"r":0,"d":0,"h":309239873142,"f":50331682},"n":"_action","d":2227830,"h":304944905846,"f":2097186}],"m":[{"r":2227830,"p":[{"n":"primitive","p":2227830}],"n":"Nullable","d":2227830,"h":261995232886,"f":16777249},{"r":2227830,"n":"Task","d":2227830,"h":279175102070,"f":16777249},{"r":2227830,"p":[{"n":"result","p":2227830}],"n":"Task","o":"@$1","d":2227830,"h":283470069366,"f":16777249},{"r":2227830,"p":[{"n":"element","p":2227830}],"n":"Array","d":2227830,"h":287765036662,"f":16777249},{"r":2227830,"p":[{"n":"element","p":2227830}],"n":"ArraySegment","d":2227830,"h":292060003958,"f":16777249},{"r":2227830,"p":[{"n":"element","p":2227830}],"n":"Span","d":2227830,"h":296354971254,"f":16777249},{"r":2227830,"n":"Action","d":2227830,"h":313534840438,"f":16777249},{"r":2227830,"p":[{"n":"arg1","p":2227830}],"n":"Action","o":"@$3","d":2227830,"h":317829807734,"f":16777249},{"r":2227830,"p":[{"n":"arg1","p":2227830},{"n":"arg2","p":2227830}],"n":"Action","o":"@$2","d":2227830,"h":322124775030,"f":16777249},{"r":2227830,"p":[{"n":"arg1","p":2227830},{"n":"arg2","p":2227830},{"n":"arg3","p":2227830}],"n":"Action","o":"@$1","d":2227830,"h":326419742326,"f":16777249},{"r":2227830,"p":[{"n":"result","p":2227830}],"n":"Function","o":"@$3","d":2227830,"h":330714709622,"f":16777249},{"r":2227830,"p":[{"n":"arg1","p":2227830},{"n":"result","p":2227830}],"n":"Function","o":"@$2","d":2227830,"h":335009676918,"f":16777249},{"r":2227830,"p":[{"n":"arg1","p":2227830},{"n":"arg2","p":2227830},{"n":"result","p":2227830}],"n":"Function","o":"@$1","d":2227830,"h":339304644214,"f":16777249},{"r":2227830,"p":[{"n":"arg1","p":2227830},{"n":"arg2","p":2227830},{"n":"arg3","p":2227830},{"n":"result","p":2227830}],"n":"Function","d":2227830,"h":343599611510,"f":16777249},{"r":65537,"p":[{"n":"underlyingType","p":2227830}],"n":"CheckNullable","d":2227830,"h":347894578806,"f":16777256},{"r":65537,"p":[{"n":"underlyingType","p":2227830}],"n":"CheckArray","d":2227830,"h":352189546102,"f":16777256},{"r":65537,"p":[{"n":"underlyingType","p":2227830}],"n":"CheckArraySegment","d":2227830,"h":356484513398,"f":16777256},{"r":65537,"p":[{"n":"underlyingType","p":2227830}],"n":"CheckTask","d":2227830,"h":360779480694,"f":16777256}],"l":[{"t":720502,"n":"_signatureType","d":2227830,"h":4297195126,"f":4194312}],"c":[{"n":".ctor","o":"$ctor$1","d":2227830,"h":8592162422,"f":16777218},{"p":[{"n":"signatureType","p":720502}],"n":".ctor","o":"$ctor$2","d":2227830,"h":12887129718,"f":16777218}],"h":2227830,"a":[{"t":114819073,"c":4409786369,"a":[{"v":"browser","t":1310721}]},{"t":33292289,"c":4328259585,"a":[{"v":1,"t":33357825}]}]}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `System.Runtime.InteropServices.JavaScript.JSMarshalerType`; }
        });
        
        $asm.$cls("$srij.System.SR", ($self) => class SR
        {
            /*global::System.Resources.ResourceManager*/ static s_resourceManager = null;
            /*global::System.Globalization.CultureInfo*/ static resourceCulture = null;
            static /*global::System.Resources.ResourceManager */ get ResourceManager()
            {
                if ($.$$.System.Object.ReferenceEquals($.$srij.System.SR.s_resourceManager, null))
                {
                    /*global::System.Resources.ResourceManager*/ let temp = new $.$$.System.Resources.ResourceManager().$ctor$3("System.Runtime.InteropServices.JavaScript", $.$srij.System.SR.$type.Assembly);
                    $.$srij.System.SR.s_resourceManager = temp;
                }
                return $.$srij.System.SR.s_resourceManager;
            }
            static /*global::System.Globalization.CultureInfo */ get Culture()
            {
                return $.$srij.System.SR.resourceCulture;
            }
            static /*global::System.Globalization.CultureInfo */ set Culture(value)
            {
                $.$srij.System.SR.resourceCulture = value;
            }
            static /*string */ get ArgumentCannotBeNull()
            {
                return "Invalid argument: {0} can not be null.";
            }
            static /*string */ FormatArgumentCannotBeNull(/*object*/ arg1)
            {
                return $.$$.System.String.Format$9("Invalid argument: {0} can not be null.", arg1);
            }
            static /*string */ get ArgumentCannotBeNullWithLength()
            {
                return "Invalid argument: {0} can not be null and must have a length.";
            }
            static /*string */ FormatArgumentCannotBeNullWithLength(/*object*/ arg1)
            {
                return $.$$.System.String.Format$9("Invalid argument: {0} can not be null and must have a length.", arg1);
            }
            static /*string */ get SystemRuntimeInteropServicesJavaScript_PlatformNotSupported()
            {
                return "System.Runtime.InteropServices.JavaScript is not supported on this platform.";
            }
            static /*string */ get TypedArrayNotCorrectType()
            {
                return "TypedArray is not of correct type.";
            }
            static /*string */ get UnableCastNullToType()
            {
                return "Unable to cast null to type {0}.";
            }
            static /*string */ FormatUnableCastNullToType(/*object*/ arg1)
            {
                return $.$$.System.String.Format$9("Unable to cast null to type {0}.", arg1);
            }
            static /*string */ get UnableCastObjectToType()
            {
                return "Unable to cast object of type {0} to type {1}.";
            }
            static /*string */ FormatUnableCastObjectToType(/*object*/ arg1, /*object*/ arg2)
            {
                return $.$$.System.String.Format$8("Unable to cast object of type {0} to type {1}.", arg1, arg2);
            }
            static /*string */ get MissingManagedEntrypointHandle()
            {
                return "Managed entrypoint handle is not set.";
            }
            static /*string */ get CannotResolveManagedEntrypointHandle()
            {
                return "Cannot resolve managed entrypoint handle.";
            }
            static /*string */ get ReturnTypeNotSupportedForMain()
            {
                return "Return type '{0}' from main method in not supported.";
            }
            static /*string */ FormatReturnTypeNotSupportedForMain(/*object*/ arg1)
            {
                return $.$$.System.String.Format$9("Return type '{0}' from main method in not supported.", arg1);
            }
            static /*string */ get NullToManagedCallback()
            {
                return "ToManagedCallback is null.";
            }
            static /*string */ get NullPromiseHolder()
            {
                return "PromiseHolder is null.";
            }
            static /*string */ get EmptyProfileData()
            {
                return "Empty profile data.";
            }
            static /*string */ get ErrorLegacySettingProperty()
            {
                return "Error setting {0} on (js-obj js '{1}'): {2}.";
            }
            static /*string */ FormatErrorLegacySettingProperty(/*object*/ arg1, /*object*/ arg2, /*object*/ arg3)
            {
                return $.$$.System.String.Format$7("Error setting {0} on (js-obj js '{1}'): {2}.", arg1, arg2, arg3);
            }
            static /*string */ get ErrorResolvingFromGlobalThis()
            {
                return "Error resolving property {0} from globalThis.";
            }
            static /*string */ FormatErrorResolvingFromGlobalThis(/*object*/ arg1)
            {
                return $.$$.System.String.Format$9("Error resolving property {0} from globalThis.", arg1);
            }
            static /*string */ get FailedToMarshalException()
            {
                return "Failed to marshal exception.";
            }
            static /*string */ get FailedToMarshalPromiseHolder()
            {
                return "Failed to marshal Promise callback.";
            }
            static /*string */ get InvalidInFlightCounter()
            {
                return "Invalid InFlightCounter for JSObject {0}, expected: {1}, actual: {2}.";
            }
            static /*string */ FormatInvalidInFlightCounter(/*object*/ arg1, /*object*/ arg2, /*object*/ arg3)
            {
                return $.$$.System.String.Format$7("Invalid InFlightCounter for JSObject {0}, expected: {1}, actual: {2}.", arg1, arg2, arg3);
            }
            static /*string */ get ToJSNotImplemented()
            {
                return "ToJS for {0} is not implemented.";
            }
            static /*string */ FormatToJSNotImplemented(/*object*/ arg1)
            {
                return $.$$.System.String.Format$9("ToJS for {0} is not implemented.", arg1);
            }
            static /*string */ get ToManagedNotImplemented()
            {
                return "ToManaged for {0} is not implemented.";
            }
            static /*string */ FormatToManagedNotImplemented(/*object*/ arg1)
            {
                return $.$$.System.String.Format$9("ToManaged for {0} is not implemented.", arg1);
            }
            static /*string */ get UnableToResolveHandleAsException()
            {
                return "Unable to resolve the handle as an Exception.";
            }
            static /*string */ get UnsupportedArrayType()
            {
                return "Unsupported array type {0}. Only single-dimensional arrays with a zero lower bound can be marshaled to JS.";
            }
            static /*string */ FormatUnsupportedArrayType(/*object*/ arg1)
            {
                return $.$$.System.String.Format$9("Unsupported array type {0}. Only single-dimensional arrays with a zero lower bound can be marshaled to JS.", arg1);
            }
            static /*string */ get UnsupportedElementType()
            {
                return "Unsupported element type {0}.";
            }
            static /*string */ FormatUnsupportedElementType(/*object*/ arg1)
            {
                return $.$$.System.String.Format$9("Unsupported element type {0}.", arg1);
            }
            static /*string */ get UnsupportedEnumType()
            {
                return "Unsupported enum type {0}.";
            }
            static /*string */ FormatUnsupportedEnumType(/*object*/ arg1)
            {
                return $.$$.System.String.Format$9("Unsupported enum type {0}.", arg1);
            }
            static /*string */ get UnsupportedLegacyMarshlerType()
            {
                return "Unsupported marshal type {0}.";
            }
            static /*string */ FormatUnsupportedLegacyMarshlerType(/*object*/ arg1)
            {
                return $.$$.System.String.Format$9("Unsupported marshal type {0}.", arg1);
            }
            static /*string */ get UnsupportedNullableType()
            {
                return "Unsupported nullable type {0}.";
            }
            static /*string */ FormatUnsupportedNullableType(/*object*/ arg1)
            {
                return $.$$.System.String.Format$9("Unsupported nullable type {0}.", arg1);
            }
            static /*string */ get UnsupportedTaskResultType()
            {
                return "Unsupported task result type {0}.";
            }
            static /*string */ FormatUnsupportedTaskResultType(/*object*/ arg1)
            {
                return $.$$.System.String.Format$9("Unsupported task result type {0}.", arg1);
            }
            static /*string */ get UriConstructorMissing()
            {
                return "Constructor on type 'System.Uri' not found. Please consider to protect it's constructor from trimming.";
            }
            static /*string */ get UriTypeMissing()
            {
                return "The type System.Uri could not be found. Please consider to protect the class and it's constructor from trimming.";
            }
            static /*string */ get ValueOutOf52BitRange()
            {
                return "Overflow: value {0} is out of {1} {2} range.";
            }
            static /*string */ FormatValueOutOf52BitRange(/*object*/ arg1, /*object*/ arg2, /*object*/ arg3)
            {
                return $.$$.System.String.Format$7("Overflow: value {0} is out of {1} {2} range.", arg1, arg2, arg3);
            }
            /*bool*/ static s_usingResourceKeys = false;
            static /*bool */ GetUsingResourceKeysSwitchValue()
            {
                /*bool*/ let usingResourceKeys;
                return $.$$.System.AppContext.TryGetSwitch("System.Resources.UseSystemResourceKeys", $.$ref(() => usingResourceKeys, ($v) => usingResourceKeys = $v, $.$$.System.Boolean)) ? usingResourceKeys : false;
            }
            static /*bool */ UsingResourceKeys()
            {
                return $.$srij.System.SR.s_usingResourceKeys;
            }
            static /*string */ GetResourceString$1(/*string*/ resourceKey)
            {
                if ($.$srij.System.SR.UsingResourceKeys())
                {
                    return resourceKey;
                }
                /*string?*/ let resourceString = null;
                try
                {
                    resourceString = $.$srij.System.SR.ResourceManager.GetString$1(resourceKey);
                }
                catch($e)
                {
                }
                return resourceString;
            }
            static /*string */ GetResourceString(/*string*/ resourceKey, /*string*/ defaultString)
            {
                /*string*/ let resourceString = $.$srij.System.SR.GetResourceString$1(resourceKey);
                return $.$$.System.String.op_Equality(resourceKey, resourceString) || $.$$.System.String.op_Equality(resourceString, null) ? defaultString : resourceString;
            }
            static /*string */ Format$6(/*string*/ resourceFormat, /*object?*/ p1)
            {
                if ($.$srij.System.SR.UsingResourceKeys())
                {
                    return $.$$.System.String.Join$7(", ", $.$$.System.ReadOnlySpan$$($.$$.System.Object).op_Implicit$1([ resourceFormat, p1 ]));
                }
                return $.$$.System.String.Format$9(resourceFormat, p1);
            }
            static /*string */ Format$5(/*string*/ resourceFormat, /*object?*/ p1, /*object?*/ p2)
            {
                if ($.$srij.System.SR.UsingResourceKeys())
                {
                    return $.$$.System.String.Join$7(", ", $.$$.System.ReadOnlySpan$$($.$$.System.Object).op_Implicit$1([ resourceFormat, p1, p2 ]));
                }
                return $.$$.System.String.Format$8(resourceFormat, p1, p2);
            }
            static /*string */ Format$4(/*string*/ resourceFormat, /*object?*/ p1, /*object?*/ p2, /*object?*/ p3)
            {
                if ($.$srij.System.SR.UsingResourceKeys())
                {
                    return $.$$.System.String.Join$7(", ", $.$$.System.ReadOnlySpan$$($.$$.System.Object).op_Implicit$1([ resourceFormat, p1, p2, p3 ]));
                }
                return $.$$.System.String.Format$7(resourceFormat, p1, p2, p3);
            }
            static /*string */ Format$7(/*string*/ resourceFormat, /*params object?[]?*/ args)
            {
                if (args !== null)
                {
                    if ($.$srij.System.SR.UsingResourceKeys())
                    {
                        return resourceFormat + ", " + $.$$.System.String.Join$6(", ", args);
                    }
                    return $.$$.System.String.Format$10(resourceFormat, args);
                }
                return resourceFormat;
            }
            static /*string */ Format$2(/*IFormatProvider?*/ provider, /*string*/ resourceFormat, /*object?*/ p1)
            {
                if ($.$srij.System.SR.UsingResourceKeys())
                {
                    return $.$$.System.String.Join$7(", ", $.$$.System.ReadOnlySpan$$($.$$.System.Object).op_Implicit$1([ resourceFormat, p1 ]));
                }
                return $.$$.System.String.Format$2(provider, resourceFormat, p1);
            }
            static /*string */ Format$1(/*IFormatProvider?*/ provider, /*string*/ resourceFormat, /*object?*/ p1, /*object?*/ p2)
            {
                if ($.$srij.System.SR.UsingResourceKeys())
                {
                    return $.$$.System.String.Join$7(", ", $.$$.System.ReadOnlySpan$$($.$$.System.Object).op_Implicit$1([ resourceFormat, p1, p2 ]));
                }
                return $.$$.System.String.Format$1(provider, resourceFormat, p1, p2);
            }
            static /*string */ Format(/*IFormatProvider?*/ provider, /*string*/ resourceFormat, /*object?*/ p1, /*object?*/ p2, /*object?*/ p3)
            {
                if ($.$srij.System.SR.UsingResourceKeys())
                {
                    return $.$$.System.String.Join$7(", ", $.$$.System.ReadOnlySpan$$($.$$.System.Object).op_Implicit$1([ resourceFormat, p1, p2, p3 ]));
                }
                return $.$$.System.String.Format(provider, resourceFormat, p1, p2, p3);
            }
            static /*string */ Format$3(/*IFormatProvider?*/ provider, /*string*/ resourceFormat, /*params object?[]?*/ args)
            {
                if (args !== null)
                {
                    if ($.$srij.System.SR.UsingResourceKeys())
                    {
                        return resourceFormat + ", " + $.$$.System.String.Join$6(", ", args);
                    }
                    return $.$$.System.String.Format$3(provider, resourceFormat, args);
                }
                return resourceFormat;
            }
            //Static Initializer
            static $sinit()
            {
                {
                    this.s_usingResourceKeys = $.$srij.System.SR.GetUsingResourceKeysSwitchValue();
                }
            }
            static $h = 3800694;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"h":3800694}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `System.SR`; }
        });
        
        $asm.$cls("$srij.System.Runtime.InteropServices.JavaScript.JavaScriptExports", ($self) => class JavaScriptExports
        {
            static /*void */ CallEntrypoint(/*JSMarshalerArgument**/ arguments_buffer)
            {
                /*ref JSMarshalerArgument*/ let arg_exc = arguments_buffer.Add(0);
                /*ref JSMarshalerArgument*/ let arg_res = arguments_buffer.Add(1);
                /*ref JSMarshalerArgument*/ let arg_1 = arguments_buffer.Add(2);
                /*ref JSMarshalerArgument*/ let arg_2 = arguments_buffer.Add(3);
                /*ref JSMarshalerArgument*/ let arg_3 = arguments_buffer.Add(4);
                try
                {
                    /*IntPtr*/ let assemblyNamePtr;
                    arg_1.$v.ToManaged$17($.$ref(() => assemblyNamePtr, ($v) => assemblyNamePtr = $v, $.$$.System.IntPtr));
                    /*string?[]?*/ let args;
                    arg_2.$v.ToManaged$36($.$ref(() => args, ($v) => args = $v, $.$typeArray($.$$.System.String)));
                    /*bool*/ let waitForDebugger;
                    arg_3.$v.ToManaged$4($.$ref(() => waitForDebugger, ($v) => waitForDebugger = $v, $.$$.System.Boolean));
                    /*Task<int>?*/ let result = $.$srij.System.Runtime.InteropServices.JavaScript.JSHostImplementation.CallEntrypoint(assemblyNamePtr, args, waitForDebugger);
                    arg_res.$v.ToJS$43($.$$.System.Int32, result, new ($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument.ArgumentToJSCallback$$($.$$.System.Int32))().$ctor(this,  (/*JSMarshalerArgument*/ arg, /*int*/ value) =>
                    {
                        arg.$v.ToJS$14(value);
                    }, {"r":65537,"p":[{"n":"arg","p":1375862,"f":4},{"n":"value","p":655361}],"n":"","d":327286,"h":0,"f":17825794}));
                }
                catch(ex)
                {
                    $.$$.System.Environment.FailFast$2(`CallEntrypoint: Unexpected synchronous failure (ManagedThreadId ${$.$$.System.Environment.CurrentManagedThreadId}): ` + $.$$.System.Exception.ToString.call(ex));
                }
            }
            static /*void */ LoadLazyAssembly(/*JSMarshalerArgument**/ arguments_buffer)
            {
                /*ref JSMarshalerArgument*/ let arg_exc = arguments_buffer.Add(0);
                /*ref JSMarshalerArgument*/ let arg_1 = arguments_buffer.Add(2);
                /*ref JSMarshalerArgument*/ let arg_2 = arguments_buffer.Add(3);
                try
                {
                    /*byte[]?*/ let dllBytes;
                    arg_1.$v.ToManaged$6($.$ref(() => dllBytes, ($v) => dllBytes = $v, $.$typeArray($.$$.System.Byte)));
                    /*byte[]?*/ let pdbBytes;
                    arg_2.$v.ToManaged$6($.$ref(() => pdbBytes, ($v) => pdbBytes = $v, $.$typeArray($.$$.System.Byte)));
                    if (dllBytes !== null)
                    {
                        $.$srij.System.Runtime.InteropServices.JavaScript.JSHostImplementation.LoadLazyAssembly(dllBytes, pdbBytes);
                    }
                }
                catch(ex)
                {
                    arg_exc.$v.ToJS$12(ex);
                }
            }
            static /*void */ LoadSatelliteAssembly(/*JSMarshalerArgument**/ arguments_buffer)
            {
                /*ref JSMarshalerArgument*/ let arg_exc = arguments_buffer.Add(0);
                /*ref JSMarshalerArgument*/ let arg_1 = arguments_buffer.Add(2);
                try
                {
                    /*byte[]?*/ let dllBytes;
                    arg_1.$v.ToManaged$6($.$ref(() => dllBytes, ($v) => dllBytes = $v, $.$typeArray($.$$.System.Byte)));
                    if (dllBytes !== null)
                    {
                        $.$srij.System.Runtime.InteropServices.JavaScript.JSHostImplementation.LoadSatelliteAssembly(dllBytes);
                    }
                }
                catch(ex)
                {
                    arg_exc.$v.ToJS$12(ex);
                }
            }
            static /*void */ ReleaseJSOwnedObjectByGCHandle(/*JSMarshalerArgument**/ arguments_buffer)
            {
                /*ref JSMarshalerArgument*/ let arg_exc = arguments_buffer.Add(0);
                /*ref JSMarshalerArgument*/ let arg_1 = arguments_buffer.Add(2);
                try
                {
                    /*var*/ let ctx = arg_exc.$v.ToManagedContext;
                    ctx.ReleaseJSOwnedObjectByGCHandle(arg_1.$v.slot.GCHandle);
                }
                catch(ex)
                {
                    $.$$.System.Environment.FailFast$2(`ReleaseJSOwnedObjectByGCHandle: Unexpected synchronous failure (ManagedThreadId ${$.$$.System.Environment.CurrentManagedThreadId}): ` + $.$$.System.Exception.ToString.call(ex));
                }
            }
            static /*void */ CallDelegate(/*JSMarshalerArgument**/ arguments_buffer)
            {
                /*ref JSMarshalerArgument*/ let arg_exc = arguments_buffer.Add(0);
                /*ref JSMarshalerArgument*/ let arg_1 = arguments_buffer.Add(2);
                try
                {
                    /*GCHandle*/ let callback_gc_handle = $.$$.System.Runtime.InteropServices.GCHandle.op_Explicit$1(arg_1.$v.slot.GCHandle);
                    let callback;
                    if ($.$is(callback_gc_handle.Target, $.$srij.System.Runtime.InteropServices.JavaScript.JSHostImplementation.ToManagedCallback, { set $v(v){ callback = v; } }))
                    {
                        callback.Invoke(arguments_buffer);
                    }
                    else 
                    {
                        throw new $.$$.System.InvalidOperationException().$ctor$12($.$srij.System.SR.NullToManagedCallback);
                    }
                }
                catch(ex)
                {
                    arg_exc.$v.ToJS$12(ex);
                }
            }
            static /*void */ CompleteTask(/*JSMarshalerArgument**/ arguments_buffer)
            {
                /*ref JSMarshalerArgument*/ let arg_exc = arguments_buffer.Add(0);
                /*ref JSMarshalerArgument*/ let arg_res = arguments_buffer.Add(1);
                /*ref JSMarshalerArgument*/ let arg_1 = arguments_buffer.Add(2);
                try
                {
                    /*var*/ let ctx = arg_exc.$v.ToManagedContext;
                    /*var*/ let holder = ctx.GetPromiseHolder(arg_1.$v.slot.GCHandle);
                    /*JSHostImplementation.ToManagedCallback*/ let callback;
                    callback = holder.Callback;
                    ctx.ReleasePromiseHolder(arg_1.$v.slot.GCHandle);
                    callback.Invoke(arguments_buffer);
                }
                catch(ex)
                {
                    $.$$.System.Environment.FailFast$2(`CompleteTask: Unexpected synchronous failure (ManagedThreadId ${$.$$.System.Environment.CurrentManagedThreadId}): ` + $.$$.System.Exception.ToString.call(ex));
                }
            }
            static /*void */ GetManagedStackTrace(/*JSMarshalerArgument**/ arguments_buffer)
            {
                /*ref JSMarshalerArgument*/ let arg_exc = arguments_buffer.Add(0);
                /*ref JSMarshalerArgument*/ let arg_res = arguments_buffer.Add(1);
                /*ref JSMarshalerArgument*/ let arg_1 = arguments_buffer.Add(2);
                try
                {
                    arg_exc.$v.AssertCurrentThreadContext();
                    /*GCHandle*/ let exception_gc_handle = $.$$.System.Runtime.InteropServices.GCHandle.op_Explicit$1(arg_1.$v.slot.GCHandle);
                    let exception;
                    if ($.$is(exception_gc_handle.Target, $.$$.System.Exception, { set $v(v){ exception = v; } }))
                    {
                        arg_res.$v.ToJS$35(exception.StackTrace);
                    }
                    else 
                    {
                        throw new $.$$.System.InvalidOperationException().$ctor$12($.$srij.System.SR.UnableToResolveHandleAsException);
                    }
                }
                catch(ex)
                {
                    arg_exc.$v.ToJS$12(ex);
                }
            }
            static /*void */ BindAssemblyExports(/*JSMarshalerArgument**/ arguments_buffer)
            {
                /*ref JSMarshalerArgument*/ let arg_exc = arguments_buffer.Add(0);
                /*ref JSMarshalerArgument*/ let arg_res = arguments_buffer.Add(1);
                /*ref JSMarshalerArgument*/ let arg_1 = arguments_buffer.Add(2);
                try
                {
                    /*string?*/ let assemblyName;
                    arg_exc.$v.AssertCurrentThreadContext();
                    arg_1.$v.ToManaged$35($.$ref(() => assemblyName, ($v) => assemblyName = $v, $.$$.System.String));
                    /*var*/ let result = $.$srij.System.Runtime.InteropServices.JavaScript.JSHostImplementation.BindAssemblyExports(assemblyName);
                    arg_res.$v.ToJS$37(result);
                }
                catch(ex)
                {
                    $.$$.System.Environment.FailFast$2(`BindAssemblyExports: Unexpected synchronous failure (ManagedThreadId ${$.$$.System.Environment.CurrentManagedThreadId}): ` + $.$$.System.Exception.ToString.call(ex));
                }
            }
            static /*void */ StopProfile()
            {
            }
            static /*void */ DumpAotProfileData(/*ref byte*/ buf, /*int*/ len, /*string*/ extraArg)
            {
                if (len === 0)
                {
                    throw new $.$$.System.InvalidOperationException().$ctor$12($.$srij.System.SR.EmptyProfileData);
                }
                /*fixed*/ 
                {
                    /*void**/ let p = buf;
                    /*var*/ let span = new ($.$$.System.ReadOnlySpan$$($.$$.System.Byte))().$ctor$5(p, len);
                    /*var*/ let module = $.$srij.System.Runtime.InteropServices.JavaScript.JSHost.DotnetInstance.GetPropertyAsJSObject("INTERNAL");
                    if (module === null)
                    {
                        throw new $.$$.System.InvalidOperationException().$ctor$9();
                    }
                    module.SetProperty$1("aotProfileData", span.ToArray());
                }
            }
            static $h = 327286;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"m":[{"r":65537,"p":[{"n":"arguments_buffer","p":$.$typePointer($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument).$h}],"n":"CallEntrypoint","d":327286,"h":4295294582,"f":16777249},{"r":65537,"p":[{"n":"arguments_buffer","p":$.$typePointer($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument).$h}],"n":"LoadLazyAssembly","d":327286,"h":8590261878,"f":16777249},{"r":65537,"p":[{"n":"arguments_buffer","p":$.$typePointer($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument).$h}],"n":"LoadSatelliteAssembly","d":327286,"h":12885229174,"f":16777249},{"r":65537,"p":[{"n":"arguments_buffer","p":$.$typePointer($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument).$h}],"n":"ReleaseJSOwnedObjectByGCHandle","d":327286,"h":17180196470,"f":16777249},{"r":65537,"p":[{"n":"arguments_buffer","p":$.$typePointer($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument).$h}],"n":"CallDelegate","d":327286,"h":21475163766,"f":16777249},{"r":65537,"p":[{"n":"arguments_buffer","p":$.$typePointer($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument).$h}],"n":"CompleteTask","d":327286,"h":25770131062,"f":16777249},{"r":65537,"p":[{"n":"arguments_buffer","p":$.$typePointer($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument).$h}],"n":"GetManagedStackTrace","d":327286,"h":30065098358,"f":16777249},{"r":65537,"p":[{"n":"arguments_buffer","p":$.$typePointer($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument).$h}],"n":"BindAssemblyExports","d":327286,"h":34360065654,"f":16777249},{"r":65537,"n":"StopProfile","d":327286,"h":38655032950,"f":16777249},{"r":65537,"p":[{"n":"buf","p":393217,"f":4},{"n":"len","p":655361},{"n":"extraArg","p":1310721}],"n":"DumpAotProfileData","d":327286,"h":42950000246,"f":16777249}],"h":327286}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `System.Runtime.InteropServices.JavaScript.JavaScriptExports`; }
        });
        
        $asm.$cls("$srij.System.Runtime.InteropServices.JavaScript.JSObject", ($self) => class JSObject extends $.$$.System.Object
        {
            /*nint*/ JSHandle = 0;
            /*JSProxyContext*/ ProxyContext = null;
            /*SynchronizationContext */ get SynchronizationContext()
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool*/ _isDisposed = false;
            $ctor$1(/*IntPtr*/ jsHandle, /*JSProxyContext*/ ctx)
            {
                super.$ctor();
                {
                    this.ProxyContext = ctx;
                    this.JSHandle = jsHandle;
                }
                return this;
            }
            static/*conventional*/ /*bool */ Equals$1(/*object?*/ obj)
            {
                let other;
                return $.$is(obj, $.$srij.System.Runtime.InteropServices.JavaScript.JSObject, { set $v(v){ other = v; } }) && this.JSHandle === other.JSHandle;
            }
            //Static convention instance redirect
            /*bool */ Equals$1() { return $.$srij.System.Runtime.InteropServices.JavaScript.JSObject.Equals$1.apply(this, arguments); }
            static/*conventional*/ /*int */ GetHashCode()
            {
                return this.JSHandle;
            }
            //Static convention instance redirect
            /*int */ GetHashCode() { return $.$srij.System.Runtime.InteropServices.JavaScript.JSObject.GetHashCode.apply(this, arguments); }
            static/*conventional*/ /*string */ ToString()
            {
                return `(js-obj js '${this.JSHandle}')`;
            }
            //Static convention instance redirect
            /*string */ ToString() { return $.$srij.System.Runtime.InteropServices.JavaScript.JSObject.ToString.apply(this, arguments); }
            /*void */ AssertNotDisposed()
            {
                {
                    $.$$.System.ObjectDisposedException.ThrowIf(this.IsDisposed, this);
                }
            }
            /*void */ DisposeImpl(/*bool*/ skipJsCleanup)
            {
                if (!this._isDisposed)
                {
                    $.$srij.System.Runtime.InteropServices.JavaScript.JSProxyContext.ReleaseCSOwnedObject(this, skipJsCleanup);
                }
            }
            $dtor()
            {
                this.DisposeImpl(false);
            }
            /*void */ Dispose()
            {
                this.DisposeImpl(false);
            }
            /*bool */ get IsDisposed()
            {
                return this._isDisposed;
            }
            /*bool */ HasProperty(/*string*/ propertyName)
            {
                this.AssertNotDisposed();
                return INTERNAL.has_property(this, propertyName);
            }
            /*string */ GetTypeOfProperty(/*string*/ propertyName)
            {
                this.AssertNotDisposed();
                return INTERNAL.get_typeof_property(this, propertyName);
            }
            /*bool */ GetPropertyAsBoolean(/*string*/ propertyName)
            {
                this.AssertNotDisposed();
                return INTERNAL.get_property(this, propertyName);
            }
            /*int */ GetPropertyAsInt32(/*string*/ propertyName)
            {
                this.AssertNotDisposed();
                return INTERNAL.get_property(this, propertyName);
            }
            /*double */ GetPropertyAsDouble(/*string*/ propertyName)
            {
                this.AssertNotDisposed();
                return INTERNAL.get_property(this, propertyName);
            }
            /*string? */ GetPropertyAsString(/*string*/ propertyName)
            {
                this.AssertNotDisposed();
                return INTERNAL.get_property(this, propertyName);
            }
            /*JSObject? */ GetPropertyAsJSObject(/*string*/ propertyName)
            {
                this.AssertNotDisposed();
                return INTERNAL.get_property(this, propertyName);
            }
            /*byte[]? */ GetPropertyAsByteArray(/*string*/ propertyName)
            {
                this.AssertNotDisposed();
                return INTERNAL.get_property(this, propertyName);
            }
            /*void */ SetProperty(/*string*/ propertyName, /*bool*/ value)
            {
                this.AssertNotDisposed();
                INTERNAL.set_property(this, propertyName, value);
            }
            /*void */ SetProperty$3(/*string*/ propertyName, /*int*/ value)
            {
                this.AssertNotDisposed();
                INTERNAL.set_property(this, propertyName, value);
            }
            /*void */ SetProperty$2(/*string*/ propertyName, /*double*/ value)
            {
                this.AssertNotDisposed();
                INTERNAL.set_property(this, propertyName, value);
            }
            /*void */ SetProperty$4(/*string*/ propertyName, /*string?*/ value)
            {
                this.AssertNotDisposed();
                INTERNAL.set_property(this, propertyName, value);
            }
            /*void */ SetProperty$5(/*string*/ propertyName, /*JSObject?*/ value)
            {
                this.AssertNotDisposed();
                INTERNAL.set_property(this, propertyName, value);
            }
            /*void */ SetProperty$1(/*string*/ propertyName, /*byte[]?*/ value)
            {
                this.AssertNotDisposed();
                INTERNAL.set_property(this, propertyName, value);
            }
            //Generated interface implemetation for System.IDisposable.Dispose()
            System$IDisposable$Dispose()
            {
                return this.Dispose(...arguments);
            }
            //default member initializer
            constructor()
            {
                super();
                $.$finalizer(this);
            }
            static $h = 2293366;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":131006465,"g":{"r":0,"d":0,"h":17182162550,"f":50331649},"n":"SynchronizationContext","d":2293366,"h":12887195254,"f":2097153},{"p":262145,"g":{"r":0,"d":0,"h":64426802806,"f":50331649},"n":"IsDisposed","d":2293366,"h":60131835510,"f":2097153}],"m":[{"r":262145,"p":[{"n":"obj","p":131073}],"n":"Equals","o":"@$1","d":2293366,"h":30067064438,"f":16809985},{"r":655361,"n":"GetHashCode","d":2293366,"h":34362031734,"f":16809985},{"r":1310721,"n":"ToString","d":2293366,"h":38656999030,"f":16809985},{"r":65537,"n":"AssertNotDisposed","d":2293366,"h":42951966326,"f":16777224},{"r":65537,"p":[{"n":"skipJsCleanup","p":262145,"f":65,"v":false}],"n":"DisposeImpl","d":2293366,"h":47246933622,"f":16777224},{"r":65537,"n":"Dispose","d":2293366,"h":55836868214,"f":16777217},{"r":262145,"p":[{"n":"propertyName","p":1310721}],"n":"HasProperty","d":2293366,"h":68721770102,"f":16777217},{"r":1310721,"p":[{"n":"propertyName","p":1310721}],"n":"GetTypeOfProperty","d":2293366,"h":73016737398,"f":16777217},{"r":262145,"p":[{"n":"propertyName","p":1310721}],"n":"GetPropertyAsBoolean","d":2293366,"h":77311704694,"f":16777217},{"r":655361,"p":[{"n":"propertyName","p":1310721}],"n":"GetPropertyAsInt32","d":2293366,"h":81606671990,"f":16777217},{"r":1179649,"p":[{"n":"propertyName","p":1310721}],"n":"GetPropertyAsDouble","d":2293366,"h":85901639286,"f":16777217},{"r":1310721,"p":[{"n":"propertyName","p":1310721}],"n":"GetPropertyAsString","d":2293366,"h":90196606582,"f":16777217},{"r":2293366,"p":[{"n":"propertyName","p":1310721}],"n":"GetPropertyAsJSObject","d":2293366,"h":94491573878,"f":16777217},{"r":$.$typeArray($.$$.System.Byte).$h,"p":[{"n":"propertyName","p":1310721}],"n":"GetPropertyAsByteArray","d":2293366,"h":98786541174,"f":16777217},{"r":65537,"p":[{"n":"propertyName","p":1310721},{"n":"value","p":262145}],"n":"SetProperty","d":2293366,"h":103081508470,"f":16777217},{"r":65537,"p":[{"n":"propertyName","p":1310721},{"n":"value","p":655361}],"n":"SetProperty","o":"@$3","d":2293366,"h":107376475766,"f":16777217},{"r":65537,"p":[{"n":"propertyName","p":1310721},{"n":"value","p":1179649}],"n":"SetProperty","o":"@$2","d":2293366,"h":111671443062,"f":16777217},{"r":65537,"p":[{"n":"propertyName","p":1310721},{"n":"value","p":1310721}],"n":"SetProperty","o":"@$4","d":2293366,"h":115966410358,"f":16777217},{"r":65537,"p":[{"n":"propertyName","p":1310721},{"n":"value","p":2293366}],"n":"SetProperty","o":"@$5","d":2293366,"h":120261377654,"f":16777217},{"r":65537,"p":[{"n":"propertyName","p":1310721},{"n":"value","p":$.$typeArray($.$$.System.Byte).$h}],"n":"SetProperty","o":"@$1","d":2293366,"h":124556344950,"f":16777217}],"l":[{"t":786433,"n":"JSHandle","d":2293366,"h":4297260662,"f":4194312},{"t":2358902,"n":"ProxyContext","d":2293366,"h":8592227958,"f":4194312},{"t":262145,"n":"_isDisposed","d":2293366,"h":21477129846,"f":4194312}],"c":[{"p":[{"n":"jsHandle","p":786433},{"n":"ctx","p":2358902}],"n":".ctor","o":"$ctor$1","d":2293366,"h":25772097142,"f":16777224}],"i":[57540609],"h":2293366,"a":[{"t":114819073,"c":4409786369,"a":[{"v":"browser","t":1310721}]}]}; }
            static get $b() { return $.$$.System.Object; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.System.IDisposable ]; }
            static get $fullName() { return `System.Runtime.InteropServices.JavaScript.JSObject`; }
        });
        
        $asm.$cls("$srij.System.Runtime.InteropServices.JavaScript.JSProxyContext", ($self) => class JSProxyContext extends $.$$.System.Object
        {
            /*bool*/ _isDisposed = false;
            /*Dictionary<nint, WeakReference<JSObject>>*/ ThreadCsOwnedObjects = null;
            /*Dictionary<object, nint>*/ ThreadJsOwnedObjects = null;
            /*Dictionary<nint, PromiseHolder>*/ ThreadJsOwnedHolders = null;
            /*nint*/ NextJSVHandle = -2;
            /*List<nint>*/ JSVHandleFreeList = null;
            $ctor$1()
            {
                super.$ctor();
                {
                }
                return this;
            }
            /*bool */ IsCurrentThread()
            {
                return true;
            }
            /*JSProxyContext*/ static MainThreadContext = null;
            static /*JSProxyContext */ get CurrentThreadContext()
            {
                return $.$srij.System.Runtime.InteropServices.JavaScript.JSProxyContext.MainThreadContext;
            }
            static /*JSProxyContext */ get CurrentOperationContext()
            {
                return $.$srij.System.Runtime.InteropServices.JavaScript.JSProxyContext.MainThreadContext;
            }
            static /*JSProxyContext */ PushOperationWithCurrentThreadContext()
            {
                return $.$srij.System.Runtime.InteropServices.JavaScript.JSProxyContext.MainThreadContext;
            }
            static /*JSProxyContext */ AssertIsInteropThread()
            {
                return $.$srij.System.Runtime.InteropServices.JavaScript.JSProxyContext.MainThreadContext;
            }
            static /*bool */ IsJSVHandle(/*nint*/ jsHandle)
            {
                return jsHandle < -1;
            }
            static /*bool */ IsGCVHandle(/*nint*/ gcHandle)
            {
                return gcHandle < -1;
            }
            /*nint */ AllocJSVHandle()
            {
                {
                    $.$$.System.ObjectDisposedException.ThrowIf(this._isDisposed, this);
                    if (this.JSVHandleFreeList.Count > 0)
                    {
                        /*var*/ let jsvHandle = this.JSVHandleFreeList.get_Item(((this.JSVHandleFreeList.Count - 1) | 0));
                        this.JSVHandleFreeList.RemoveAt(((this.JSVHandleFreeList.Count - 1) | 0));
                        return jsvHandle;
                    }
                    return this.NextJSVHandle--;
                }
            }
            /*void */ FreeJSVHandle(/*nint*/ jsvHandle)
            {
                {
                    this.JSVHandleFreeList.Add(jsvHandle);
                }
            }
            /*IntPtr */ GetJSOwnedObjectGCHandle(/*object*/ obj, /*GCHandleType*/ handleType)
            {
                if (obj === null)
                {
                    return $.$$.System.IntPtr.Zero;
                }
                {
                    /*IntPtr*/ let gcHandle;
                    if (this.ThreadJsOwnedObjects.TryGetValue(obj, $.$ref(() => gcHandle, ($v) => gcHandle = $v, $.$$.System.IntPtr)))
                    {
                        return gcHandle;
                    }
                    /*IntPtr*/ let result = $.$$.System.Runtime.InteropServices.GCHandle.op_Explicit($.$$.System.Runtime.InteropServices.GCHandle.Alloc(obj, handleType));
                    this.ThreadJsOwnedObjects.set_Item(obj, result);
                    return result;
                }
            }
            /*PromiseHolder */ CreatePromiseHolder()
            {
                {
                    return new $.$srij.System.Runtime.InteropServices.JavaScript.JSHostImplementation.PromiseHolder().$ctor$2(this);
                }
            }
            /*PromiseHolder */ GetPromiseHolder(/*nint*/ gcHandle)
            {
                {
                    /*PromiseHolder?*/ let holder;
                    if ($.$srij.System.Runtime.InteropServices.JavaScript.JSProxyContext.IsGCVHandle(gcHandle))
                    {
                        if (!this.ThreadJsOwnedHolders.TryGetValue(gcHandle, $.$ref(() => holder, ($v) => holder = $v, $.$srij.System.Runtime.InteropServices.JavaScript.JSHostImplementation.PromiseHolder)))
                        {
                            holder = new $.$srij.System.Runtime.InteropServices.JavaScript.JSHostImplementation.PromiseHolder().$ctor$1(this, gcHandle);
                            this.ThreadJsOwnedHolders.Add(gcHandle, holder);
                        }
                    }
                    else 
                    {
                        holder = $.$cast(($.$$.System.Runtime.InteropServices.GCHandle.op_Explicit$1(gcHandle)).Target, $.$srij.System.Runtime.InteropServices.JavaScript.JSHostImplementation.PromiseHolder);
                    }
                    return holder;
                }
            }
            /*void */ ReleasePromiseHolder(/*nint*/ holderGCHandle)
            {
                {
                    /*PromiseHolder?*/ let holder;
                    if ($.$srij.System.Runtime.InteropServices.JavaScript.JSProxyContext.IsGCVHandle(holderGCHandle))
                    {
                        if (!this.ThreadJsOwnedHolders.Remove(holderGCHandle, $.$ref(() => holder, ($v) => holder = $v, $.$srij.System.Runtime.InteropServices.JavaScript.JSHostImplementation.PromiseHolder)))
                        {
                            throw new $.$$.System.InvalidOperationException().$ctor$12("ReleasePromiseHolder expected PromiseHolder " + holderGCHandle);
                        }
                        holder.IsDisposed = true;
                    }
                    else 
                    {
                        /*GCHandle*/ let handle = $.$$.System.Runtime.InteropServices.GCHandle.op_Explicit$1(holderGCHandle);
                        /*var*/ let target = handle.Target;
                        let holder2;
                        if ($.$is(target, $.$srij.System.Runtime.InteropServices.JavaScript.JSHostImplementation.PromiseHolder, { set $v(v){ holder2 = v; } }))
                        {
                            holder = holder2;
                        }
                        else 
                        {
                            throw new $.$$.System.InvalidOperationException().$ctor$12("ReleasePromiseHolder expected PromiseHolder" + holderGCHandle);
                        }
                        holder.IsDisposed = true;
                        handle.Free();
                    }
                }
            }
            /*void */ ReleaseJSOwnedObjectByGCHandle(/*nint*/ gcHandle)
            {
                /*ToManagedCallback?*/ let holderCallback = null;
                {
                    /*PromiseHolder?*/ let holder = null;
                    if ($.$srij.System.Runtime.InteropServices.JavaScript.JSProxyContext.IsGCVHandle(gcHandle))
                    {
                        if (!this.ThreadJsOwnedHolders.Remove(gcHandle, $.$ref(() => holder, ($v) => holder = $v, $.$srij.System.Runtime.InteropServices.JavaScript.JSHostImplementation.PromiseHolder)))
                        {
                            throw new $.$$.System.InvalidOperationException().$ctor$12("ReleaseJSOwnedObjectByGCHandle expected in ThreadJsOwnedHolders");
                        }
                    }
                    else 
                    {
                        /*GCHandle*/ let handle = $.$$.System.Runtime.InteropServices.GCHandle.op_Explicit$1(gcHandle);
                        /*var*/ let target = handle.Target;
                        let holder2;
                        if ($.$is(target, $.$srij.System.Runtime.InteropServices.JavaScript.JSHostImplementation.PromiseHolder, { set $v(v){ holder2 = v; } }))
                        {
                            holder = holder2;
                        }
                        else 
                        {
                            if (!this.ThreadJsOwnedObjects.Remove$1(target))
                            {
                                throw new $.$$.System.InvalidOperationException().$ctor$12("ReleaseJSOwnedObjectByGCHandle expected in ThreadJsOwnedObjects");
                            }
                        }
                        handle.Free();
                    }
                    if (holder !== null)
                    {
                        holderCallback = holder.Callback;
                        holder.IsDisposed = true;
                    }
                }
                holderCallback?.Invoke(null);
            }
            /*JSObject */ CreateCSOwnedProxy(/*nint*/ jsHandle)
            {
                {
                    /*JSObject?*/ let res;
                    /*WeakReference<JSObject>?*/ let reference;
                    if (!this.ThreadCsOwnedObjects.TryGetValue(jsHandle, $.$ref(() => reference, ($v) => reference = $v, $.$$.System.WeakReference$$($.$srij.System.Runtime.InteropServices.JavaScript.JSObject))) || !reference.TryGetTarget($.$ref(() => res, ($v) => res = $v, $.$srij.System.Runtime.InteropServices.JavaScript.JSObject)) || res.IsDisposed)
                    {
                        res = new $.$srij.System.Runtime.InteropServices.JavaScript.JSObject().$ctor$1(jsHandle, this);
                        this.ThreadCsOwnedObjects.set_Item(jsHandle, new ($.$$.System.WeakReference$$($.$srij.System.Runtime.InteropServices.JavaScript.JSObject))().$ctor$2(res, true));
                    }
                    return res;
                }
            }
            static /*void */ ReleaseCSOwnedObject(/*JSObject*/ jso, /*bool*/ skipJS)
            {
                if (jso.IsDisposed)
                {
                    return;
                }
                /*var*/ let ctx = jso.ProxyContext;
                {
                    if (jso.IsDisposed || ctx._isDisposed)
                    {
                        return;
                    }
                    /*var*/ let jsHandle = jso.JSHandle;
                    jso._isDisposed = true;
                    jso.JSHandle = $.$$.System.IntPtr.Zero;
                    $.$$.System.GC.SuppressFinalize(jso);
                    if (!ctx.ThreadCsOwnedObjects.Remove$1(jsHandle))
                    {
                        $.$$.System.Environment.FailFast$2(`ReleaseCSOwnedObject expected to find registration for JSHandle: ${jsHandle}, ManagedThreadId: ${$.$$.System.Environment.CurrentManagedThreadId}. ${$.$$.System.Environment.NewLine} ${$.$$.System.Environment.StackTrace}`);
                    }
                    if (!skipJS)
                    {
                        $.$srij.Interop.Runtime.ReleaseCSOwnedObject(jsHandle);
                    }
                    if ($.$srij.System.Runtime.InteropServices.JavaScript.JSProxyContext.IsJSVHandle(jsHandle))
                    {
                        ctx.FreeJSVHandle(jsHandle);
                    }
                }
            }
            /*void */ Dispose$1(/*bool*/ disposing)
            {
                {
                    if (!this._isDisposed)
                    {
                        /*List<WeakReference<JSObject>>*/ let copy = new ($.$$.System.Collections.Generic.List$$($.$$.System.WeakReference$$($.$srij.System.Runtime.InteropServices.JavaScript.JSObject)))().$ctor$2(this.ThreadCsOwnedObjects.Values);
                        var $en4 = copy.GetEnumerator();
                        while ($en4.MoveNext())
                        {
                            var jsObjectWeak = $en4.Current;
                            {
                                /*var*/ let jso;
                                if (jsObjectWeak.TryGetTarget($.$ref(() => jso, ($v) => jso = $v, $.$srij.System.Runtime.InteropServices.JavaScript.JSObject)))
                                {
                                    jso.Dispose();
                                }
                            }
                        }
                        var $en4 = this.ThreadJsOwnedObjects.Values.GetEnumerator();
                        while ($en4.MoveNext())
                        {
                            var gch = $en4.Current;
                            {
                                /*GCHandle*/ let gcHandle = $.$$.System.Runtime.InteropServices.GCHandle.op_Explicit$1(gch);
                                gcHandle.Free();
                            }
                        }
                        var $en4 = this.ThreadJsOwnedHolders.Values.GetEnumerator();
                        while ($en4.MoveNext())
                        {
                            var holder = $en4.Current;
                            {
                                {
                                    holder.Callback.Invoke(null);
                                }
                                ($.$$.System.Runtime.InteropServices.GCHandle.op_Explicit$1(holder.GCHandle)).Free();
                            }
                        }
                        this.ThreadCsOwnedObjects.Clear();
                        this.ThreadJsOwnedObjects.Clear();
                        this.JSVHandleFreeList.Clear();
                        this.NextJSVHandle = $.$$.System.IntPtr.Zero;
                        if (disposing)
                        {
                        }
                        this._isDisposed = true;
                    }
                }
            }
            $dtor()
            {
                this.Dispose$1(false);
            }
            /*void */ Dispose()
            {
                this.Dispose$1(true);
                $.$$.System.GC.SuppressFinalize(this);
            }
            //Generated interface implemetation for System.IDisposable.Dispose()
            System$IDisposable$Dispose()
            {
                return this.Dispose(...arguments);
            }
            //default member initializer
            constructor()
            {
                super();
                this.ThreadCsOwnedObjects = new ($.$$.System.Collections.Generic.Dictionary$$$($.$$.System.IntPtr, $.$$.System.WeakReference$$($.$srij.System.Runtime.InteropServices.JavaScript.JSObject)))().$ctor$1();
                this.ThreadJsOwnedObjects = new ($.$$.System.Collections.Generic.Dictionary$$$($.$$.System.Object, $.$$.System.IntPtr))().$ctor$6($.$$.System.Collections.Generic.ReferenceEqualityComparer.Instance);
                this.ThreadJsOwnedHolders = new ($.$$.System.Collections.Generic.Dictionary$$$($.$$.System.IntPtr, $.$srij.System.Runtime.InteropServices.JavaScript.JSHostImplementation.PromiseHolder))().$ctor$1();
                this.JSVHandleFreeList = new ($.$$.System.Collections.Generic.List$$($.$$.System.IntPtr))().$ctor$1();
                $.$finalizer(this);
            }
            //Static Initializer
            static $sinit()
            {
                {
                    this.MainThreadContext = new $.$srij.System.Runtime.InteropServices.JavaScript.JSProxyContext().$ctor$1();
                }
            }
            static $h = 2358902;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":2358902,"g":{"r":0,"d":0,"h":47246999158,"f":50331681},"n":"CurrentThreadContext","d":2358902,"h":42952031862,"f":2097185},{"p":2358902,"g":{"r":0,"d":0,"h":55836933750,"f":50331681},"n":"CurrentOperationContext","d":2358902,"h":51541966454,"f":2097185}],"m":[{"r":262145,"n":"IsCurrentThread","d":2358902,"h":34362097270,"f":16777217},{"r":2358902,"n":"PushOperationWithCurrentThreadContext","d":2358902,"h":60131901046,"f":16777249},{"r":2358902,"n":"AssertIsInteropThread","d":2358902,"h":64426868342,"f":16777249},{"r":262145,"p":[{"n":"jsHandle","p":786433}],"n":"IsJSVHandle","d":2358902,"h":68721835638,"f":16777249},{"r":262145,"p":[{"n":"gcHandle","p":786433}],"n":"IsGCVHandle","d":2358902,"h":73016802934,"f":16777249},{"r":786433,"n":"AllocJSVHandle","d":2358902,"h":77311770230,"f":16777217},{"r":65537,"p":[{"n":"jsvHandle","p":786433}],"n":"FreeJSVHandle","d":2358902,"h":81606737526,"f":16777217},{"r":786433,"p":[{"n":"obj","p":131073},{"n":"handleType","p":104202241,"f":65,"v":2}],"n":"GetJSOwnedObjectGCHandle","d":2358902,"h":85901704822,"f":16777217},{"r":1048182,"n":"CreatePromiseHolder","d":2358902,"h":90196672118,"f":16777217},{"r":1048182,"p":[{"n":"gcHandle","p":786433}],"n":"GetPromiseHolder","d":2358902,"h":94491639414,"f":16777217},{"r":65537,"p":[{"n":"holderGCHandle","p":786433}],"n":"ReleasePromiseHolder","d":2358902,"h":98786606710,"f":16777217},{"r":65537,"p":[{"n":"gcHandle","p":786433}],"n":"ReleaseJSOwnedObjectByGCHandle","d":2358902,"h":103081574006,"f":16777217},{"r":2293366,"p":[{"n":"jsHandle","p":786433}],"n":"CreateCSOwnedProxy","d":2358902,"h":107376541302,"f":16777217},{"r":65537,"p":[{"n":"jso","p":2293366},{"n":"skipJS","p":262145}],"n":"ReleaseCSOwnedObject","d":2358902,"h":111671508598,"f":16777249},{"r":65537,"p":[{"n":"disposing","p":262145}],"n":"Dispose","o":"@$1","d":2358902,"h":115966475894,"f":16777218},{"r":65537,"n":"Dispose","d":2358902,"h":124556410486,"f":16777217}],"l":[{"t":262145,"n":"_isDisposed","d":2358902,"h":4297326198,"f":4194312},{"t":$.$$.System.Collections.Generic.Dictionary$$$($.$$.System.IntPtr, $.$$.System.WeakReference$$($.$srij.System.Runtime.InteropServices.JavaScript.JSObject)).$h,"n":"ThreadCsOwnedObjects","d":2358902,"h":8592293494,"f":4194306},{"t":$.$$.System.Collections.Generic.Dictionary$$$($.$$.System.Object, $.$$.System.IntPtr).$h,"n":"ThreadJsOwnedObjects","d":2358902,"h":12887260790,"f":4194306},{"t":$.$$.System.Collections.Generic.Dictionary$$$($.$$.System.IntPtr, $.$srij.System.Runtime.InteropServices.JavaScript.JSHostImplementation.PromiseHolder).$h,"n":"ThreadJsOwnedHolders","d":2358902,"h":17182228086,"f":4194306},{"t":786433,"n":"NextJSVHandle","d":2358902,"h":21477195382,"f":4194306},{"t":$.$$.System.Collections.Generic.List$$($.$$.System.IntPtr).$h,"n":"JSVHandleFreeList","d":2358902,"h":25772162678,"f":4194306},{"t":2358902,"n":"MainThreadContext","d":2358902,"h":38657064566,"f":4194337}],"c":[{"n":".ctor","o":"$ctor$1","d":2358902,"h":30067129974,"f":16777218}],"i":[57540609],"h":2358902}; }
            static get $b() { return $.$$.System.Object; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.System.IDisposable ]; }
            static get $fullName() { return `System.Runtime.InteropServices.JavaScript.JSProxyContext`; }
        });
        
        $asm.$cls("$srij.System.Runtime.InteropServices.JavaScript.JSMarshalAsAttribute<>", (T) => $asm.$gt("$srij.System.Runtime.InteropServices.JavaScript.JSMarshalAsAttribute<>", [T], ($self) => class JSMarshalAsAttribute$$ extends $.$$.System.Attribute
        {
            $ctor$2()
            {
                super.$ctor$1();
                {
                }
                return this;
            }
            static $h = 1310326;
            static $g = 1;
            static $f = 0b11010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":14614529,"c":[{"n":".ctor","o":"$ctor$2","d":this.$h,"h":Number(BigInt(this.$h)|0x100000000n),"f":16777217}],"g":[T?.$h??1507328],"r":1,"h":this.$h,"a":[{"t":14745601,"c":21489582081,"a":[{"v":10240,"t":14680065}],"n":[{"n":"Inherited","v":false,"t":262145},{"n":"AllowMultiple","v":false,"t":262145}]},{"t":114819073,"c":4409786369,"a":[{"v":"browser","t":1310721}]}]}; }
            static get $b() { return $.$$.System.Attribute; }
            static get $fullName() { return `System.Runtime.InteropServices.JavaScript.JSMarshalAsAttribute<${T?.$fullName}>`; }
        }));
        
        $asm.$cls("$srij.System.Runtime.InteropServices.JavaScript.JSExportAttribute", ($self) => class JSExportAttribute extends $.$$.System.Attribute
        {
            $ctor$2()
            {
                super.$ctor$1();
                {
                }
                return this;
            }
            static $h = 523894;
            static $f = 0b10010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":14614529,"c":[{"n":".ctor","o":"$ctor$2","d":523894,"h":4295491190,"f":16777217}],"h":523894,"a":[{"t":14745601,"c":21489582081,"a":[{"v":64,"t":14680065}],"n":[{"n":"Inherited","v":false,"t":262145},{"n":"AllowMultiple","v":false,"t":262145}]},{"t":114819073,"c":4409786369,"a":[{"v":"browser","t":1310721}]}]}; }
            static get $b() { return $.$$.System.Attribute; }
            static get $fullName() { return `System.Runtime.InteropServices.JavaScript.JSExportAttribute`; }
        });
        
        $asm.$str("$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument", ($self) => class JSMarshalerArgument extends $.$$.System.ValueType
        {
            /*JSMarshalerArgumentImpl*/  get slot() { return this.$getField(0, 32); }
            /*JSMarshalerArgumentImpl*/  set slot(value) { this.$setField(0, 32, value); }
            static $_JSMarshalerArgumentImpl;
            static get JSMarshalerArgumentImpl()
            {
                let $cls = $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument;
                return $cls.$_JSMarshalerArgumentImpl ??= $asm.$nstr("$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument.JSMarshalerArgumentImpl", ($self) => class JSMarshalerArgumentImpl extends $.$$.System.ValueType
                {
                    /*bool*/  get BooleanValue() { return this.$getField(0, 1); }
                    /*bool*/  set BooleanValue(value) { this.$setField(0, 1, value); }
                    /*byte*/  get ByteValue() { return this.$getField(0, 1); }
                    /*byte*/  set ByteValue(value) { this.$setField(0, 1, value); }
                    /*char*/  get CharValue() { return this.$getField(0, 2); }
                    /*char*/  set CharValue(value) { this.$setField(0, 2, value); }
                    /*short*/  get Int16Value() { return this.$getField(0, 2); }
                    /*short*/  set Int16Value(value) { this.$setField(0, 2, value); }
                    /*int*/  get Int32Value() { return this.$getField(0, 4); }
                    /*int*/  set Int32Value(value) { this.$setField(0, 4, value); }
                    /*long*/  get Int64Value() { return this.$getField(0, 8); }
                    /*long*/  set Int64Value(value) { this.$setField(0, 8, value); }
                    /*float*/  get SingleValue() { return this.$getField(0, 4); }
                    /*float*/  set SingleValue(value) { this.$setField(0, 4, value); }
                    /*double*/  get DoubleValue() { return this.$getField(0, 8); }
                    /*double*/  set DoubleValue(value) { this.$setField(0, 8, value); }
                    /*IntPtr*/  get IntPtrValue() { return this.$getField(0, 4); }
                    /*IntPtr*/  set IntPtrValue(value) { this.$setField(0, 4, value); }
                    /*IntPtr*/  get JSHandle() { return this.$getField(4, 4); }
                    /*IntPtr*/  set JSHandle(value) { this.$setField(4, 4, value); }
                    /*IntPtr*/  get GCHandle() { return this.$getField(4, 4); }
                    /*IntPtr*/  set GCHandle(value) { this.$setField(4, 4, value); }
                    /*int*/  get Length() { return this.$getField(8, 4); }
                    /*int*/  set Length(value) { this.$setField(8, 4, value); }
                    /*MarshalerType*/  get Type() { return this.$getField(12, 1); }
                    /*MarshalerType*/  set Type(value) { this.$setField(12, 1, value); }
                    /*MarshalerType*/  get ElementType() { return this.$getField(13, 1); }
                    /*MarshalerType*/  set ElementType(value) { this.$setField(13, 1, value); }
                    //default value type constructor
                    $ctor$2()
                    {
                        return this;
                    }
                    Clone($copy)
                    {
                        let copy = $copy ?? new this.constructor();
                        copy.BooleanValue = this.BooleanValue;
                        copy.ByteValue = this.ByteValue;
                        copy.CharValue = this.CharValue;
                        copy.Int16Value = this.Int16Value;
                        copy.Int32Value = this.Int32Value;
                        copy.Int64Value = this.Int64Value;
                        copy.SingleValue = this.SingleValue;
                        copy.DoubleValue = this.DoubleValue;
                        copy.IntPtrValue = this.IntPtrValue;
                        copy.JSHandle = this.JSHandle;
                        copy.GCHandle = this.GCHandle;
                        copy.Length = this.Length;
                        copy.Type = this.Type;
                        copy.ElementType = this.ElementType;
                        return copy;
                    }
                    //default member initializer
                    constructor()
                    {
                        super();
                        this.BooleanValue = false;
                        this.ByteValue = 0;
                        this.CharValue = 0;
                        this.Int16Value = 0;
                        this.Int32Value = 0;
                        this.Int64Value = 0n;
                        this.SingleValue = 0;
                        this.DoubleValue = 0;
                        this.IntPtrValue = 0;
                        this.JSHandle = 0;
                        this.GCHandle = 0;
                        this.Length = 0;
                        this.Type = 0;
                        this.ElementType = 0;
                    }
                    static $h = 2162294;
                    static $z = 32;
                    static $f = 0b100010000001010000000;
                    static $k = 2;
                    static $$md;
                    static get $md() { return this.$$md ??= {"b":196609,"l":[{"t":262145,"n":"BooleanValue","d":2162294,"h":4297129590,"f":4194312,"a":[{"t":103940097,"c":4398907393,"a":[{"v":0,"t":655361}]}]},{"t":393217,"n":"ByteValue","d":2162294,"h":8592096886,"f":4194312,"a":[{"t":103940097,"c":4398907393,"a":[{"v":0,"t":655361}]}]},{"t":458753,"n":"CharValue","d":2162294,"h":12887064182,"f":4194312,"a":[{"t":103940097,"c":4398907393,"a":[{"v":0,"t":655361}]}]},{"t":524289,"n":"Int16Value","d":2162294,"h":17182031478,"f":4194312,"a":[{"t":103940097,"c":4398907393,"a":[{"v":0,"t":655361}]}]},{"t":655361,"n":"Int32Value","d":2162294,"h":21476998774,"f":4194312,"a":[{"t":103940097,"c":4398907393,"a":[{"v":0,"t":655361}]}]},{"t":917505,"n":"Int64Value","d":2162294,"h":25771966070,"f":4194312,"a":[{"t":103940097,"c":4398907393,"a":[{"v":0,"t":655361}]}]},{"t":1114113,"n":"SingleValue","d":2162294,"h":30066933366,"f":4194312,"a":[{"t":103940097,"c":4398907393,"a":[{"v":0,"t":655361}]}]},{"t":1179649,"n":"DoubleValue","d":2162294,"h":34361900662,"f":4194312,"a":[{"t":103940097,"c":4398907393,"a":[{"v":0,"t":655361}]}]},{"t":786433,"n":"IntPtrValue","d":2162294,"h":38656867958,"f":4194312,"a":[{"t":103940097,"c":4398907393,"a":[{"v":0,"t":655361}]}]},{"t":786433,"n":"JSHandle","d":2162294,"h":42951835254,"f":4194312,"a":[{"t":103940097,"c":4398907393,"a":[{"v":4,"t":655361}]}]},{"t":786433,"n":"GCHandle","d":2162294,"h":47246802550,"f":4194312,"a":[{"t":103940097,"c":4398907393,"a":[{"v":4,"t":655361}]}]},{"t":655361,"n":"Length","d":2162294,"h":51541769846,"f":4194312,"a":[{"t":103940097,"c":4398907393,"a":[{"v":8,"t":655361}]}]},{"t":3735158,"n":"Type","d":2162294,"h":55836737142,"f":4194312,"a":[{"t":103940097,"c":4398907393,"a":[{"v":12,"t":655361}]}]},{"t":3735158,"n":"ElementType","d":2162294,"h":60131704438,"f":4194312,"a":[{"t":103940097,"c":4398907393,"a":[{"v":13,"t":655361}]}]}],"c":[{"n":".ctor","o":"$ctor$2","d":2162294,"h":64426671734,"f":16777217}],"d":1375862,"h":2162294,"a":[{"t":109772801,"c":4404740097,"a":[{"v":2,"t":105250817}],"n":[{"n":"Pack","v":32,"t":655361},{"n":"Size","v":32,"t":655361}]}]}; }
                    static get $b() { return $.$$.System.ValueType; }
                    static get $fullName() { return `System.Runtime.InteropServices.JavaScript.JSMarshalerArgument.JSMarshalerArgumentImpl`; }
                }, $cls, ($v) => $cls.$_JSMarshalerArgumentImpl = $v);
            }
            /*void */ Initialize()
            {
                this.slot.Type = 0/*MarshalerType.None*/;
            }
            /*JSProxyContext */ get ToManagedContext()
            {
                return $.$srij.System.Runtime.InteropServices.JavaScript.JSProxyContext.MainThreadContext;
            }
            /*JSProxyContext */ get ToJSContext()
            {
                return $.$srij.System.Runtime.InteropServices.JavaScript.JSProxyContext.MainThreadContext;
            }
            /*JSProxyContext */ AssertCurrentThreadContext()
            {
                return $.$srij.System.Runtime.InteropServices.JavaScript.JSProxyContext.MainThreadContext;
            }
            /*void */ ToManagedBig(/*out long*/ value)
            {
                if (this.slot.Type === 0/*MarshalerType.None*/)
                {
                    value.$v = 0n;
                    return;
                }
                value.$v = this.slot.Int64Value;
            }
            /*void */ ToJSBig(/*long*/ value)
            {
                this.slot.Type = 9/*MarshalerType.BigInt64*/;
                this.slot.Int64Value = value;
            }
            /*void */ ToManagedBig$1(/*out long?*/ value)
            {
                if (this.slot.Type === 0/*MarshalerType.None*/)
                {
                    value.$v = null;
                    return;
                }
                value.$v = this.slot.Int64Value;
            }
            /*void */ ToJSBig$1(/*long?*/ value)
            {
                if ($.$$.System.Nullable$$($.$$.System.Int64).HasValue$get.call(value))
                {
                    this.slot.Type = 9/*MarshalerType.BigInt64*/;
                    this.slot.Int64Value = $.$$.System.Nullable$$($.$$.System.Int64).Value$get.call(value);
                }
                else 
                {
                    this.slot.Type = 0/*MarshalerType.None*/;
                }
            }
            /*void */ ToManaged$7(/*out char*/ value)
            {
                if (this.slot.Type === 0/*MarshalerType.None*/)
                {
                    value.$v = 0;
                    return;
                }
                value.$v = this.slot.CharValue;
            }
            /*void */ ToJS$7(/*char*/ value)
            {
                this.slot.Type = 5/*MarshalerType.Char*/;
                this.slot.CharValue = value;
            }
            /*void */ ToManaged$20(/*out char?*/ value)
            {
                if (this.slot.Type === 0/*MarshalerType.None*/)
                {
                    value.$v = null;
                    return;
                }
                value.$v = this.slot.CharValue;
            }
            /*void */ ToJS$20(/*char?*/ value)
            {
                if ($.$$.System.Nullable$$($.$$.System.Char).HasValue$get.call(value))
                {
                    this.slot.Type = 5/*MarshalerType.Char*/;
                    this.slot.CharValue = $.$$.System.Nullable$$($.$$.System.Char).Value$get.call(value);
                }
                else 
                {
                    this.slot.Type = 0/*MarshalerType.None*/;
                }
            }
            /*long*/ static I52_MAX_VALUE = 9007199254740991n;
            /*long*/ static I52_MIN_VALUE = -9007199254740991n;
            /*void */ ToManaged$16(/*out long*/ value)
            {
                if (this.slot.Type === 0/*MarshalerType.None*/)
                {
                    value.$v = 0n;
                    return;
                }
                value.$v = $.$cast(this.slot.DoubleValue, $.$$.System.Int64);
            }
            /*void */ ToJS$16(/*long*/ value)
            {
                if (value < -9007199254740991n || value > 9007199254740991n)
                {
                    throw new $.$$.System.OverflowException().$ctor$16($.$srij.System.SR.Format$4($.$srij.System.SR.ValueOutOf52BitRange, $.$box(value, $.$$.System.Int64), $.$box(-9007199254740991n, $.$$.System.Int64), $.$box(9007199254740991n, $.$$.System.Int64)));
                }
                this.slot.Type = 8/*MarshalerType.Int52*/;
                this.slot.DoubleValue = Number(value);
            }
            /*void */ ToManaged$26(/*out long?*/ value)
            {
                if (this.slot.Type === 0/*MarshalerType.None*/)
                {
                    value.$v = null;
                    return;
                }
                value.$v = $.$cast(this.slot.DoubleValue, $.$$.System.Int64);
            }
            /*void */ ToJS$26(/*long?*/ value)
            {
                if ($.$$.System.Nullable$$($.$$.System.Int64).HasValue$get.call(value))
                {
                    if ($.$$.System.Nullable$$($.$$.System.Int64).Value$get.call(value) < -9007199254740991n || $.$$.System.Nullable$$($.$$.System.Int64).Value$get.call(value) > 9007199254740991n)
                    {
                        throw new $.$$.System.OverflowException().$ctor$16($.$srij.System.SR.Format$4($.$srij.System.SR.ValueOutOf52BitRange, $.$box(value, $.$$.System.Nullable$$($.$$.System.Int64)), $.$box(-9007199254740991n, $.$$.System.Int64), $.$box(9007199254740991n, $.$$.System.Int64)));
                    }
                    this.slot.Type = 8/*MarshalerType.Int52*/;
                    this.slot.DoubleValue = Number($.$$.System.Nullable$$($.$$.System.Int64).Value$get.call(value));
                }
                else 
                {
                    this.slot.Type = 0/*MarshalerType.None*/;
                }
            }
            /*void */ ToManaged$13(/*out short*/ value)
            {
                if (this.slot.Type === 0/*MarshalerType.None*/)
                {
                    value.$v = 0;
                    return;
                }
                value.$v = this.slot.Int16Value;
            }
            /*void */ ToJS$13(/*short*/ value)
            {
                this.slot.Type = 6/*MarshalerType.Int16*/;
                this.slot.Int16Value = value;
            }
            /*void */ ToManaged$24(/*out short?*/ value)
            {
                if (this.slot.Type === 0/*MarshalerType.None*/)
                {
                    value.$v = null;
                    return;
                }
                value.$v = this.slot.Int16Value;
            }
            /*void */ ToJS$24(/*short?*/ value)
            {
                if ($.$$.System.Nullable$$($.$$.System.Int16).HasValue$get.call(value))
                {
                    this.slot.Type = 6/*MarshalerType.Int16*/;
                    this.slot.Int16Value = $.$$.System.Nullable$$($.$$.System.Int16).Value$get.call(value);
                }
                else 
                {
                    this.slot.Type = 0/*MarshalerType.None*/;
                }
            }
            /*void */ ToManaged$5(/*out byte*/ value)
            {
                if (this.slot.Type === 0/*MarshalerType.None*/)
                {
                    value.$v = 0;
                    return;
                }
                value.$v = this.slot.ByteValue;
            }
            /*void */ ToJS$5(/*byte*/ value)
            {
                this.slot.Type = 4/*MarshalerType.Byte*/;
                this.slot.ByteValue = value;
            }
            /*void */ ToManaged$19(/*out byte?*/ value)
            {
                if (this.slot.Type === 0/*MarshalerType.None*/)
                {
                    value.$v = null;
                    return;
                }
                value.$v = this.slot.ByteValue;
            }
            /*void */ ToJS$19(/*byte?*/ value)
            {
                if ($.$$.System.Nullable$$($.$$.System.Byte).HasValue$get.call(value))
                {
                    this.slot.Type = 4/*MarshalerType.Byte*/;
                    this.slot.ByteValue = $.$$.System.Nullable$$($.$$.System.Byte).Value$get.call(value);
                }
                else 
                {
                    this.slot.Type = 0/*MarshalerType.None*/;
                }
            }
            /*void */ ToManaged$6(/*out byte[]?*/ value)
            {
                if (this.slot.Type === 0/*MarshalerType.None*/)
                {
                    value.$v = null;
                    return;
                }
                value.$v = $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$$.System.Byte), null, [this.slot.Length], null);
                $.$$.System.Runtime.InteropServices.Marshal.Copy$6(this.slot.IntPtrValue, value.$v, 0, this.slot.Length);
                $.$$.System.Runtime.InteropServices.Marshal.FreeHGlobal(this.slot.IntPtrValue);
            }
            /*void */ ToJS$6(/*byte[]?*/ value)
            {
                if (value === null)
                {
                    this.slot.Type = 0/*MarshalerType.None*/;
                    return;
                }
                this.slot.Length = value.length;
                this.slot.Type = 21/*MarshalerType.Array*/;
                this.slot.IntPtrValue = $.$$.System.Runtime.InteropServices.Marshal.AllocHGlobal(((value.length * $.$$.System.Byte.$z) | 0));
                this.slot.ElementType = 4/*MarshalerType.Byte*/;
                $.$$.System.Runtime.InteropServices.Marshal.Copy(value, 0, this.slot.IntPtrValue, this.slot.Length);
            }
            /*void */ ToManaged$1(/*out ArraySegment<byte>*/ value)
            {
                /*var*/ let array = $.$cast(($.$$.System.Runtime.InteropServices.GCHandle.op_Explicit$1(this.slot.GCHandle)).Target, $.$typeArray($.$$.System.Byte));
                /*var*/ let refPtr = $.$$.System.IntPtr.op_Explicit$4($.$$.System.Runtime.CompilerServices.Unsafe.AsPointer($.$$.System.Byte, $.$$.System.Runtime.InteropServices.MemoryMarshal.GetArrayDataReference$1($.$$.System.Byte, array)));
                /*int*/ let byteOffset = (this.slot.IntPtrValue - refPtr);
                value.$v = new ($.$$.System.ArraySegment$$($.$$.System.Byte))().$ctor$3(array, byteOffset, this.slot.Length);
            }
            /*void */ ToJS$1(/*ArraySegment<byte>*/ value)
            {
                if (value.Array === null)
                {
                    this.slot.Type = 0/*MarshalerType.None*/;
                    return;
                }
                this.slot.Type = 22/*MarshalerType.ArraySegment*/;
                /*var*/ let ctx = this.ToJSContext;
                this.slot.GCHandle = ctx.GetJSOwnedObjectGCHandle(value.Array, 3/*GCHandleType.Pinned*/);
                /*var*/ let refPtr = $.$$.System.IntPtr.op_Explicit$4($.$$.System.Runtime.CompilerServices.Unsafe.AsPointer($.$$.System.Byte, $.$$.System.Runtime.InteropServices.MemoryMarshal.GetArrayDataReference$1($.$$.System.Byte, value.Array)));
                this.slot.IntPtrValue = refPtr + value.Offset;
                this.slot.Length = value.Count;
            }
            /*void */ ToManaged$32(/*out Span<byte>*/ value)
            {
                value.$v = new ($.$$.System.Span$$($.$$.System.Byte))().$ctor$5($.$$.System.IntPtr.op_Explicit$5(this.slot.IntPtrValue), this.slot.Length);
            }
            /*void */ ToJS$32(/*Span<byte>*/ value)
            {
                this.slot.Length = value.Length;
                this.slot.IntPtrValue = $.$$.System.IntPtr.op_Explicit$4($.$$.System.Runtime.CompilerServices.Unsafe.AsPointer($.$$.System.Byte, value.GetPinnableReference()));
                this.slot.Type = 23/*MarshalerType.Span*/;
            }
            /*void */ ToManaged$4(/*out bool*/ value)
            {
                if (this.slot.Type === 0/*MarshalerType.None*/)
                {
                    value.$v = false;
                    return;
                }
                value.$v = this.slot.BooleanValue;
            }
            /*void */ ToJS$4(/*bool*/ value)
            {
                this.slot.Type = 3/*MarshalerType.Boolean*/;
                this.slot.BooleanValue = value;
            }
            /*void */ ToManaged$18(/*out bool?*/ value)
            {
                if (this.slot.Type === 0/*MarshalerType.None*/)
                {
                    value.$v = null;
                    return;
                }
                value.$v = this.slot.BooleanValue;
            }
            /*void */ ToJS$18(/*bool?*/ value)
            {
                if ($.$$.System.Nullable$$($.$$.System.Boolean).HasValue$get.call(value))
                {
                    this.slot.Type = 3/*MarshalerType.Boolean*/;
                    this.slot.BooleanValue = $.$$.System.Nullable$$($.$$.System.Boolean).Value$get.call(value);
                }
                else 
                {
                    this.slot.Type = 0/*MarshalerType.None*/;
                }
            }
            /*void */ ToManaged$9(/*out DateTimeOffset*/ value)
            {
                if (this.slot.Type === 0/*MarshalerType.None*/)
                {
                    value.$v = new $.$$.System.DateTimeOffset();
                    return;
                }
                value.$v = $.$$.System.DateTimeOffset.FromUnixTimeMilliseconds($.$cast(this.slot.DoubleValue, $.$$.System.Int64));
            }
            /*void */ ToJS$9(/*DateTimeOffset*/ value)
            {
                this.slot.Type = 18/*MarshalerType.DateTimeOffset*/;
                this.slot.DoubleValue = $.$cast(value.ToUnixTimeMilliseconds(), $.$$.System.Double);
            }
            /*void */ ToManaged$22(/*out DateTimeOffset?*/ value)
            {
                if (this.slot.Type === 0/*MarshalerType.None*/)
                {
                    value.$v = null;
                    return;
                }
                value.$v = $.$$.System.DateTimeOffset.FromUnixTimeMilliseconds($.$cast(this.slot.DoubleValue, $.$$.System.Int64));
            }
            /*void */ ToJS$22(/*DateTimeOffset?*/ value)
            {
                if ($.$$.System.Nullable$$($.$$.System.DateTimeOffset).HasValue$get.call(value))
                {
                    this.slot.Type = 18/*MarshalerType.DateTimeOffset*/;
                    this.slot.DoubleValue = Number($.$$.System.Nullable$$($.$$.System.DateTimeOffset).Value$get.call(value).ToUnixTimeMilliseconds());
                }
                else 
                {
                    this.slot.Type = 0/*MarshalerType.None*/;
                }
            }
            /*void */ ToManaged$8(/*out DateTime*/ value)
            {
                if (this.slot.Type === 0/*MarshalerType.None*/)
                {
                    value.$v = new $.$$.System.DateTime();
                    return;
                }
                value.$v = $.$$.System.DateTimeOffset.FromUnixTimeMilliseconds($.$cast(this.slot.DoubleValue, $.$$.System.Int64)).UtcDateTime;
            }
            /*void */ ToJS$8(/*DateTime*/ value)
            {
                this.slot.Type = 17/*MarshalerType.DateTime*/;
                this.slot.DoubleValue = Number(new $.$$.System.DateTimeOffset().$ctor$5(value).ToUnixTimeMilliseconds());
            }
            /*void */ ToManaged$21(/*out DateTime?*/ value)
            {
                if (this.slot.Type === 0/*MarshalerType.None*/)
                {
                    value.$v = null;
                    return;
                }
                value.$v = $.$$.System.DateTimeOffset.FromUnixTimeMilliseconds($.$cast(this.slot.DoubleValue, $.$$.System.Int64)).UtcDateTime;
            }
            /*void */ ToJS$21(/*DateTime?*/ value)
            {
                if ($.$$.System.Nullable$$($.$$.System.DateTime).HasValue$get.call(value))
                {
                    this.slot.Type = 17/*MarshalerType.DateTime*/;
                    this.slot.DoubleValue = Number(new $.$$.System.DateTimeOffset().$ctor$5($.$$.System.Nullable$$($.$$.System.DateTime).Value$get.call(value)).ToUnixTimeMilliseconds());
                }
                else 
                {
                    this.slot.Type = 0/*MarshalerType.None*/;
                }
            }
            /*void */ ToManaged$17(/*out IntPtr*/ value)
            {
                if (this.slot.Type === 0/*MarshalerType.None*/)
                {
                    value.$v = 0;
                    return;
                }
                value.$v = this.slot.IntPtrValue;
            }
            /*void */ ToJS$17(/*IntPtr*/ value)
            {
                this.slot.Type = 12/*MarshalerType.IntPtr*/;
                this.slot.IntPtrValue = value;
            }
            /*void */ ToManaged$27(/*out IntPtr?*/ value)
            {
                if (this.slot.Type === 0/*MarshalerType.None*/)
                {
                    value.$v = null;
                    return;
                }
                value.$v = this.slot.IntPtrValue;
            }
            /*void */ ToJS$27(/*IntPtr?*/ value)
            {
                if ($.$$.System.Nullable$$($.$$.System.IntPtr).HasValue$get.call(value))
                {
                    this.slot.Type = 12/*MarshalerType.IntPtr*/;
                    this.slot.IntPtrValue = $.$$.System.Nullable$$($.$$.System.IntPtr).Value$get.call(value);
                }
                else 
                {
                    this.slot.Type = 0/*MarshalerType.None*/;
                }
            }
            /*void */ ToManaged$38(/*out void**/ value)
            {
                if (this.slot.Type === 0/*MarshalerType.None*/)
                {
                    value.$v = new $.$typePointer($.$$.System.Void)();
                    return;
                }
                value.$v = $.$cast(this.slot.IntPtrValue, $.$typePointer($.$$.System.Byte));
            }
            /*void */ ToJS$38(/*void**/ value)
            {
                this.slot.Type = 12/*MarshalerType.IntPtr*/;
                this.slot.IntPtrValue = $.$$.System.IntPtr.op_Explicit$4(value);
            }
            /*void */ ToManaged$14(/*out int*/ value)
            {
                if (this.slot.Type === 0/*MarshalerType.None*/)
                {
                    value.$v = 0;
                    return;
                }
                value.$v = this.slot.Int32Value;
            }
            /*void */ ToJS$14(/*int*/ value)
            {
                this.slot.Type = 7/*MarshalerType.Int32*/;
                this.slot.Int32Value = value;
            }
            /*void */ ToManaged$25(/*out int?*/ value)
            {
                if (this.slot.Type === 0/*MarshalerType.None*/)
                {
                    value.$v = null;
                    return;
                }
                value.$v = this.slot.Int32Value;
            }
            /*void */ ToJS$25(/*int?*/ value)
            {
                if ($.$$.System.Nullable$$($.$$.System.Int32).HasValue$get.call(value))
                {
                    this.slot.Type = 7/*MarshalerType.Int32*/;
                    this.slot.Int32Value = $.$$.System.Nullable$$($.$$.System.Int32).Value$get.call(value);
                }
                else 
                {
                    this.slot.Type = 0/*MarshalerType.None*/;
                }
            }
            /*void */ ToManaged$15(/*out int[]?*/ value)
            {
                if (this.slot.Type === 0/*MarshalerType.None*/)
                {
                    value.$v = null;
                    return;
                }
                value.$v = $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$$.System.Int32), null, [this.slot.Length], null);
                $.$$.System.Runtime.InteropServices.Marshal.Copy$10(this.slot.IntPtrValue, value.$v, 0, this.slot.Length);
                $.$$.System.Runtime.InteropServices.Marshal.FreeHGlobal(this.slot.IntPtrValue);
            }
            /*void */ ToJS$15(/*int[]?*/ value)
            {
                if (value === null)
                {
                    this.slot.Type = 0/*MarshalerType.None*/;
                    return;
                }
                this.slot.Type = 21/*MarshalerType.Array*/;
                this.slot.IntPtrValue = $.$$.System.Runtime.InteropServices.Marshal.AllocHGlobal(((value.length * $.$$.System.Int32.$z) | 0));
                this.slot.Length = value.length;
                this.slot.ElementType = 7/*MarshalerType.Int32*/;
                $.$$.System.Runtime.InteropServices.Marshal.Copy$4(value, 0, this.slot.IntPtrValue, this.slot.Length);
            }
            /*void */ ToManaged$3(/*out ArraySegment<int>*/ value)
            {
                /*var*/ let array = $.$cast(($.$$.System.Runtime.InteropServices.GCHandle.op_Explicit$1(this.slot.GCHandle)).Target, $.$typeArray($.$$.System.Int32));
                /*var*/ let refPtr = $.$$.System.IntPtr.op_Explicit$4($.$$.System.Runtime.CompilerServices.Unsafe.AsPointer($.$$.System.Int32, $.$$.System.Runtime.InteropServices.MemoryMarshal.GetArrayDataReference$1($.$$.System.Int32, array)));
                /*int*/ let byteOffset = (this.slot.IntPtrValue - refPtr);
                value.$v = new ($.$$.System.ArraySegment$$($.$$.System.Int32))().$ctor$3(array, $.trunc(byteOffset / $.$$.System.Int32.$z), this.slot.Length);
            }
            /*void */ ToJS$3(/*ArraySegment<int>*/ value)
            {
                if (value.Array === null)
                {
                    this.slot.Type = 0/*MarshalerType.None*/;
                    return;
                }
                /*var*/ let ctx = this.ToJSContext;
                this.slot.Type = 22/*MarshalerType.ArraySegment*/;
                this.slot.GCHandle = ctx.GetJSOwnedObjectGCHandle(value.Array, 3/*GCHandleType.Pinned*/);
                /*var*/ let refPtr = $.$$.System.IntPtr.op_Explicit$4($.$$.System.Runtime.CompilerServices.Unsafe.AsPointer($.$$.System.Int32, $.$$.System.Runtime.InteropServices.MemoryMarshal.GetArrayDataReference$1($.$$.System.Int32, value.Array)));
                this.slot.IntPtrValue = refPtr + (((value.Offset * $.$$.System.Int32.$z) | 0));
                this.slot.Length = value.Count;
            }
            /*void */ ToManaged$34(/*out Span<int>*/ value)
            {
                value.$v = new ($.$$.System.Span$$($.$$.System.Int32))().$ctor$5($.$$.System.IntPtr.op_Explicit$5(this.slot.IntPtrValue), this.slot.Length);
            }
            /*void */ ToJS$34(/*Span<int>*/ value)
            {
                this.slot.Length = value.Length;
                this.slot.IntPtrValue = $.$$.System.IntPtr.op_Explicit$4($.$$.System.Runtime.CompilerServices.Unsafe.AsPointer($.$$.System.Int32, value.GetPinnableReference()));
                this.slot.Type = 23/*MarshalerType.Span*/;
            }
            /*void */ ToManaged$10(/*out double*/ value)
            {
                if (this.slot.Type === 0/*MarshalerType.None*/)
                {
                    value.$v = 0;
                    return;
                }
                value.$v = this.slot.DoubleValue;
            }
            /*void */ ToJS$10(/*double*/ value)
            {
                this.slot.Type = 10/*MarshalerType.Double*/;
                this.slot.DoubleValue = value;
            }
            /*void */ ToManaged$23(/*out double?*/ value)
            {
                if (this.slot.Type === 0/*MarshalerType.None*/)
                {
                    value.$v = null;
                    return;
                }
                value.$v = this.slot.DoubleValue;
            }
            /*void */ ToJS$23(/*double?*/ value)
            {
                if ($.$$.System.Nullable$$($.$$.System.Double).HasValue$get.call(value))
                {
                    this.slot.Type = 10/*MarshalerType.Double*/;
                    this.slot.DoubleValue = $.$$.System.Nullable$$($.$$.System.Double).Value$get.call(value);
                }
                else 
                {
                    this.slot.Type = 0/*MarshalerType.None*/;
                }
            }
            /*void */ ToManaged$11(/*out double[]?*/ value)
            {
                if (this.slot.Type === 0/*MarshalerType.None*/)
                {
                    value.$v = null;
                    return;
                }
                value.$v = $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$$.System.Double), null, [this.slot.Length], null);
                $.$$.System.Runtime.InteropServices.Marshal.Copy$8(this.slot.IntPtrValue, value.$v, 0, this.slot.Length);
                $.$$.System.Runtime.InteropServices.Marshal.FreeHGlobal(this.slot.IntPtrValue);
            }
            /*void */ ToJS$11(/*double[]*/ value)
            {
                if (value === null)
                {
                    this.slot.Type = 0/*MarshalerType.None*/;
                    return;
                }
                this.slot.Type = 21/*MarshalerType.Array*/;
                this.slot.IntPtrValue = $.$$.System.Runtime.InteropServices.Marshal.AllocHGlobal(((value.length * $.$$.System.Double.$z) | 0));
                this.slot.Length = value.length;
                this.slot.ElementType = 10/*MarshalerType.Double*/;
                $.$$.System.Runtime.InteropServices.Marshal.Copy$2(value, 0, this.slot.IntPtrValue, this.slot.Length);
            }
            /*void */ ToManaged$2(/*out ArraySegment<double>*/ value)
            {
                /*var*/ let array = $.$cast(($.$$.System.Runtime.InteropServices.GCHandle.op_Explicit$1(this.slot.GCHandle)).Target, $.$typeArray($.$$.System.Double));
                /*var*/ let refPtr = $.$$.System.IntPtr.op_Explicit$4($.$$.System.Runtime.CompilerServices.Unsafe.AsPointer($.$$.System.Double, $.$$.System.Runtime.InteropServices.MemoryMarshal.GetArrayDataReference$1($.$$.System.Double, array)));
                /*int*/ let byteOffset = (this.slot.IntPtrValue - refPtr);
                value.$v = new ($.$$.System.ArraySegment$$($.$$.System.Double))().$ctor$3(array, $.trunc(byteOffset / $.$$.System.Double.$z), this.slot.Length);
            }
            /*void */ ToJS$2(/*ArraySegment<double>*/ value)
            {
                if (value.Array === null)
                {
                    this.slot.Type = 0/*MarshalerType.None*/;
                    return;
                }
                this.slot.Type = 22/*MarshalerType.ArraySegment*/;
                /*var*/ let ctx = this.ToJSContext;
                this.slot.GCHandle = ctx.GetJSOwnedObjectGCHandle(value.Array, 3/*GCHandleType.Pinned*/);
                /*var*/ let refPtr = $.$$.System.IntPtr.op_Explicit$4($.$$.System.Runtime.CompilerServices.Unsafe.AsPointer($.$$.System.Double, $.$$.System.Runtime.InteropServices.MemoryMarshal.GetArrayDataReference$1($.$$.System.Double, value.Array)));
                this.slot.IntPtrValue = refPtr + (((value.Offset * $.$$.System.Double.$z) | 0));
                this.slot.Length = value.Count;
            }
            /*void */ ToManaged$33(/*out Span<double>*/ value)
            {
                value.$v = new ($.$$.System.Span$$($.$$.System.Double))().$ctor$5($.$$.System.IntPtr.op_Explicit$5(this.slot.IntPtrValue), this.slot.Length);
            }
            /*void */ ToJS$33(/*Span<double>*/ value)
            {
                this.slot.Length = value.Length;
                this.slot.IntPtrValue = $.$$.System.IntPtr.op_Explicit$4($.$$.System.Runtime.CompilerServices.Unsafe.AsPointer($.$$.System.Double, value.GetPinnableReference()));
                this.slot.Type = 23/*MarshalerType.Span*/;
            }
            /*void */ ToManaged$35(/*out string?*/ value)
            {
                if (this.slot.Type === 0/*MarshalerType.None*/)
                {
                    value.$v = null;
                    return;
                }
                /*fixed*/ 
                {
                    /*void**/ let argAsRoot = $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateObjectReferenceT($.$$.System.IntPtr, () => this.slot.IntPtrValue, ($v) => this.slot.IntPtrValue = $v, null);
                    value.$v = $.$$.System.Runtime.CompilerServices.Unsafe.AsRef($.$$.System.String, argAsRoot).$v;
                }
            }
            /*void */ ToJS$35(/*string?*/ value)
            {
                if ($.$$.System.String.op_Equality(value, null))
                {
                    this.slot.Type = 0/*MarshalerType.None*/;
                }
                else 
                {
                    this.slot.Type = 15/*MarshalerType.String*/;
                    /*fixed*/ 
                    {
                        /*IntPtr**/ let argAsRoot = $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateObjectReferenceT($.$$.System.IntPtr, () => this.slot.IntPtrValue, ($v) => this.slot.IntPtrValue = $v, null);
                        /*string*/ let cpy = value;
                        /*var*/ let currentRoot = $.$cast($.$$.System.Runtime.CompilerServices.Unsafe.AsPointer($.$$.System.String, $.$ref(() => cpy, ($v) => cpy = $v, $.$$.System.String)), $.$typePointer($.$$.System.IntPtr));
                        argAsRoot.SetAt(currentRoot.GetAt(0), 0);
                    }
                }
            }
            /*void */ ToManaged$36(/*out string?[]?*/ value)
            {
                if (this.slot.Type === 0/*MarshalerType.None*/)
                {
                    value.$v = null;
                    return;
                }
                value.$v = $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$$.System.String), null, [this.slot.Length], null);
                /*JSMarshalerArgument**/ let payload = $.$cast(this.slot.IntPtrValue, $.$typePointer($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument));
                for(/*int*/ let i = 0; i < this.slot.Length; i++)
                {
                    /*ref JSMarshalerArgument*/ let arg = payload.Add(i);
                    /*string?*/ let val;
                    arg.$v.ToManaged$35($.$ref(() => val, ($v) => val = $v, $.$$.System.String));
                    $.$$.System.Array.$WriteT1.call(value.$v, val, i);
                }
                $.$srij.Interop.Runtime.DeregisterGCRoot(this.slot.IntPtrValue);
                $.$$.System.Runtime.InteropServices.Marshal.FreeHGlobal(this.slot.IntPtrValue);
            }
            /*void */ ToJS$36(/*string?[]*/ value)
            {
                if (value === null)
                {
                    this.slot.Type = 0/*MarshalerType.None*/;
                    return;
                }
                this.slot.Length = value.length;
                /*int*/ let bytes = ((value.length * $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument.$z) | 0);
                this.slot.Type = 21/*MarshalerType.Array*/;
                /*JSMarshalerArgument**/ let payload = $.$cast($.$$.System.Runtime.InteropServices.Marshal.AllocHGlobal(bytes), $.$typePointer($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument));
                $.$$.System.Runtime.CompilerServices.Unsafe.InitBlock(payload, 0, (bytes >>> 0));
                $.$srij.Interop.Runtime.RegisterGCRoot(payload, bytes, $.$$.System.IntPtr.Zero);
                for(/*int*/ let i = 0; i < this.slot.Length; i++)
                {
                    /*ref JSMarshalerArgument*/ let arg = payload.Add(i);
                    /*string?*/ let val = $.$$.System.Array.$ReadT1.call(value, i);
                    arg.$v.ToJS$35(val);
                    $.$$.System.Array.$WriteT1.call(value, val, i);
                }
                this.slot.IntPtrValue = $.$cast(payload, $.$$.System.IntPtr);
                this.slot.ElementType = 15/*MarshalerType.String*/;
            }
            /*void */ ToManaged$39(/*out JSObject?*/ value)
            {
                if (this.slot.Type === 0/*MarshalerType.None*/)
                {
                    value.$v = null;
                    return;
                }
                /*var*/ let ctx = this.ToManagedContext;
                value.$v = ctx.CreateCSOwnedProxy(this.slot.JSHandle);
            }
            /*void */ ToJS$39(/*JSObject?*/ value)
            {
                if (value === null)
                {
                    this.slot.Type = 0/*MarshalerType.None*/;
                }
                else 
                {
                    value.AssertNotDisposed();
                    this.slot.Type = 13/*MarshalerType.JSObject*/;
                    this.slot.JSHandle = value.JSHandle;
                }
            }
            /*void */ ToManaged$40(/*out JSObject?[]?*/ value)
            {
                if (this.slot.Type === 0/*MarshalerType.None*/)
                {
                    value.$v = null;
                    return;
                }
                value.$v = $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$srij.System.Runtime.InteropServices.JavaScript.JSObject), null, [this.slot.Length], null);
                /*JSMarshalerArgument**/ let payload = $.$cast(this.slot.IntPtrValue, $.$typePointer($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument));
                for(/*int*/ let i = 0; i < this.slot.Length; i++)
                {
                    /*ref JSMarshalerArgument*/ let arg = payload.Add(i);
                    /*JSObject?*/ let val;
                    arg.$v.ToManaged$39($.$ref(() => val, ($v) => val = $v, $.$srij.System.Runtime.InteropServices.JavaScript.JSObject));
                    $.$$.System.Array.$WriteT1.call(value.$v, val, i);
                }
                $.$$.System.Runtime.InteropServices.Marshal.FreeHGlobal(this.slot.IntPtrValue);
            }
            /*void */ ToJS$40(/*JSObject?[]*/ value)
            {
                if (value === null)
                {
                    this.slot.Type = 0/*MarshalerType.None*/;
                    return;
                }
                this.slot.Length = value.length;
                /*int*/ let bytes = ((value.length * $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument.$z) | 0);
                this.slot.Type = 21/*MarshalerType.Array*/;
                this.slot.ElementType = 13/*MarshalerType.JSObject*/;
                /*JSMarshalerArgument**/ let payload = $.$cast($.$$.System.Runtime.InteropServices.Marshal.AllocHGlobal(bytes), $.$typePointer($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument));
                $.$$.System.Runtime.CompilerServices.Unsafe.InitBlock(payload, 0, (bytes >>> 0));
                for(/*int*/ let i = 0; i < this.slot.Length; i++)
                {
                    /*ref JSMarshalerArgument*/ let arg = payload.Add(i);
                    /*JSObject?*/ let val = $.$$.System.Array.$ReadT1.call(value, i);
                    arg.$v.ToJS$39(val);
                    $.$$.System.Array.$WriteT1.call(value, val, i);
                }
                this.slot.IntPtrValue = $.$cast(payload, $.$$.System.IntPtr);
            }
            /*void */ ToManaged$12(/*out Exception?*/ value)
            {
                if (this.slot.Type === 0/*MarshalerType.None*/)
                {
                    value.$v = null;
                    return;
                }
                if (this.slot.Type === 16/*MarshalerType.Exception*/)
                {
                    value.$v = $.$cast(($.$$.System.Runtime.InteropServices.GCHandle.op_Explicit$1(this.slot.GCHandle)).Target, $.$$.System.Exception);
                    return;
                }
                /*JSObject?*/ let jsException = null;
                if (this.slot.JSHandle !== $.$$.System.IntPtr.Zero)
                {
                    /*var*/ let ctx = this.ToManagedContext;
                    jsException = ctx.CreateCSOwnedProxy(this.slot.JSHandle);
                }
                /*string?*/ let message;
                this.ToManaged$35($.$ref(() => message, ($v) => message = $v, $.$$.System.String));
                value.$v = new $.$srij.System.Runtime.InteropServices.JavaScript.JSException().$ctor$5(message, jsException);
            }
            /*void */ ToJS$12(/*Exception?*/ value)
            {
                if (value === null)
                {
                    this.slot.Type = 0/*MarshalerType.None*/;
                }
                else 
                {
                    /*Exception*/ let cpy = value;
                    let ae;
                    if ($.$is(cpy, $.$$.System.AggregateException, { set $v(v){ ae = v; } }) && ae.InnerExceptions.Count === 1)
                    {
                        cpy = ae.InnerExceptions.get_Item(0);
                    }
                    /*var*/ let jse = $.$as(cpy, $.$srij.System.Runtime.InteropServices.JavaScript.JSException);
                    if (jse !== null && jse.jsException !== null)
                    {
                        /*var*/ let jsException = jse.jsException;
                        jsException.AssertNotDisposed();
                        this.slot.Type = 27/*MarshalerType.JSException*/;
                        this.slot.JSHandle = jsException.JSHandle;
                    }
                    else 
                    {
                        this.ToJS$35(cpy.Message);
                        this.slot.Type = 16/*MarshalerType.Exception*/;
                        /*var*/ let ctx = this.ToJSContext;
                        this.slot.GCHandle = ctx.GetJSOwnedObjectGCHandle(cpy, 2);
                    }
                }
            }
            static $_ArgumentToManagedCallback$$;
            static ArgumentToManagedCallback$$(T)
            {
                let $cls = $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument;
                return ($cls.$_ArgumentToManagedCallback$$ ??= $asm.$ncls("$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument.ArgumentToManagedCallback<>", (T) => $asm.$gt("$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument.ArgumentToManagedCallback<>", [T], ($self) => class ArgumentToManagedCallback$$ extends $.$$.System.MulticastDelegate
                {
                    $ctor(/*object*/ target, fn, anmodel)
                    {
                        this.$target = target;
                        this.$nativeFunction = fn;
                        if (anmodel) this.$nfmodel = anmodel;
                        if (typeof(target) === 'object') this._target = target;
                        return this;
                    }
                    /*void*/ Invoke(/**/ arg, /**/ value)
                    {
                        return this.$nativeFunction.call(this.$target, arg, value);
                    }
                    static $h = 1769078;
                    static $g = 1;
                    static $f = 0b10000000011000001;
                    static $k = 5;
                    static $$md;
                    static get $md() { return this.$$md ??= {"b":66191361,"m":[{"r":65537,"p":[{"n":"arg","p":1375862,"f":4},{"n":"value","p":T?.$h??1507328,"f":2}],"n":"Invoke","d":this.$h,"h":Number(BigInt(this.$h)|0x200000000n),"f":16777345},{"r":57016321,"p":[{"n":"arg","p":1375862,"f":4},{"n":"value","p":T?.$h??1507328,"f":2},{"n":"callback","p":14548993},{"n":"object","p":131073}],"n":"BeginInvoke","d":this.$h,"h":Number(BigInt(this.$h)|0x300000000n),"f":16777345},{"r":65537,"p":[{"n":"arg","p":1375862,"f":4},{"n":"value","p":T?.$h??1507328,"f":2},{"n":"result","p":57016321}],"n":"EndInvoke","d":this.$h,"h":Number(BigInt(this.$h)|0x400000000n),"f":16777345}],"c":[{"p":[{"n":"object","p":131073},{"n":"method","p":786433}],"n":".ctor","o":"$ctor$5","d":this.$h,"h":Number(BigInt(this.$h)|0x100000000n),"f":16777217}],"i":[57212929,113246209],"g":[T?.$h??1507328],"r":1,"d":1375862,"h":this.$h,"a":[{"t":33292289,"c":4328259585,"a":[{"v":1,"t":33357825}]}]}; }
                    static get $b() { return $.$$.System.MulticastDelegate; }
                    static $$i;
                    static get $i() { return this.$$i ??= [ $.$$.System.ICloneable, $.$$.System.Runtime.Serialization.ISerializable ]; }
                    static get $fullName() { return `System.Runtime.InteropServices.JavaScript.JSMarshalerArgument.ArgumentToManagedCallback<${T?.$fullName}>`; }
                }), $cls, ($v) => $cls.$_ArgumentToManagedCallback$$ = $v))(T);
            }
            static $_ArgumentToJSCallback$$;
            static ArgumentToJSCallback$$(T)
            {
                let $cls = $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument;
                return ($cls.$_ArgumentToJSCallback$$ ??= $asm.$ncls("$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument.ArgumentToJSCallback<>", (T) => $asm.$gt("$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument.ArgumentToJSCallback<>", [T], ($self) => class ArgumentToJSCallback$$ extends $.$$.System.MulticastDelegate
                {
                    $ctor(/*object*/ target, fn, anmodel)
                    {
                        this.$target = target;
                        this.$nativeFunction = fn;
                        if (anmodel) this.$nfmodel = anmodel;
                        if (typeof(target) === 'object') this._target = target;
                        return this;
                    }
                    /*void*/ Invoke(/**/ arg, /**/ value)
                    {
                        return this.$nativeFunction.call(this.$target, arg, value);
                    }
                    static $h = 1703542;
                    static $g = 1;
                    static $f = 0b10000000011000001;
                    static $k = 5;
                    static $$md;
                    static get $md() { return this.$$md ??= {"b":66191361,"m":[{"r":65537,"p":[{"n":"arg","p":1375862,"f":4},{"n":"value","p":T?.$h??1507328}],"n":"Invoke","d":this.$h,"h":Number(BigInt(this.$h)|0x200000000n),"f":16777345},{"r":57016321,"p":[{"n":"arg","p":1375862,"f":4},{"n":"value","p":T?.$h??1507328},{"n":"callback","p":14548993},{"n":"object","p":131073}],"n":"BeginInvoke","d":this.$h,"h":Number(BigInt(this.$h)|0x300000000n),"f":16777345},{"r":65537,"p":[{"n":"arg","p":1375862,"f":4},{"n":"result","p":57016321}],"n":"EndInvoke","d":this.$h,"h":Number(BigInt(this.$h)|0x400000000n),"f":16777345}],"c":[{"p":[{"n":"object","p":131073},{"n":"method","p":786433}],"n":".ctor","o":"$ctor$5","d":this.$h,"h":Number(BigInt(this.$h)|0x100000000n),"f":16777217}],"i":[57212929,113246209],"g":[T?.$h??1507328],"r":1,"d":1375862,"h":this.$h,"a":[{"t":33292289,"c":4328259585,"a":[{"v":1,"t":33357825}]}]}; }
                    static get $b() { return $.$$.System.MulticastDelegate; }
                    static $$i;
                    static get $i() { return this.$$i ??= [ $.$$.System.ICloneable, $.$$.System.Runtime.Serialization.ISerializable ]; }
                    static get $fullName() { return `System.Runtime.InteropServices.JavaScript.JSMarshalerArgument.ArgumentToJSCallback<${T?.$fullName}>`; }
                }), $cls, ($v) => $cls.$_ArgumentToJSCallback$$ = $v))(T);
            }
            /*void */ ToManaged$37(/*out Task?*/ value)
            {
                if (this.slot.Type === 0/*MarshalerType.None*/)
                {
                    value.$v = null;
                    return;
                }
                /*var*/ let ctx = this.ToManagedContext;
                {
                    /*PromiseHolder*/ let holder = ctx.GetPromiseHolder(this.slot.GCHandle);
                    /*TaskCompletionSource*/ let tcs = new $.$$.System.Threading.Tasks.TaskCompletionSource().$ctor$2(holder, 64/*TaskCreationOptions.RunContinuationsAsynchronously*/);
                    /*ToManagedCallback*/ let callback = new $.$srij.System.Runtime.InteropServices.JavaScript.JSHostImplementation.ToManagedCallback().$ctor(this,  (/*JSMarshalerArgument**/ arguments_buffer) =>
                    {
                        if (arguments_buffer === null)
                        {
                            if (!tcs.TrySetException$1(new $.$$.System.Threading.Tasks.TaskCanceledException().$ctor$20("WebWorker which is origin of the Promise is being terminated.")))
                            {
                                $.$$.System.Environment.FailFast$2("Failed to set exception to TaskCompletionSource (arguments buffer is null)");
                            }
                            return;
                        }
                        /*ref JSMarshalerArgument*/ let arg_2 = arguments_buffer.Add(3);
                        if (arg_2.$v.slot.Type !== 0/*MarshalerType.None*/)
                        {
                            /*Exception?*/ let fail;
                            arg_2.$v.ToManaged$12($.$ref(() => fail, ($v) => fail = $v, $.$$.System.Exception));
                            if (!tcs.TrySetException$1(fail))
                            {
                                $.$$.System.Environment.FailFast$2("Failed to set exception to TaskCompletionSource (exception raised)");
                            }
                        }
                        else 
                        {
                            if (!tcs.TrySetResult())
                            {
                                $.$$.System.Environment.FailFast$2("Failed to set result to TaskCompletionSource (marshaler type is none)");
                            }
                        }
                    }, {"r":65537,"p":[{"n":"arguments_buffer","p":$.$typePointer($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument).$h}],"n":"","d":1375862,"h":0,"f":17825794});
                    holder.Callback = callback;
                    value.$v = tcs.Task;
                }
            }
            /*void */ ToManaged$43(T, /*out Task<T>?*/ value, /*ArgumentToManagedCallback<T>*/ marshaler)
            {
                if (this.slot.Type === 0/*MarshalerType.None*/)
                {
                    value.$v = null;
                    return;
                }
                /*var*/ let ctx = this.ToManagedContext;
                {
                    /*var*/ let holder = ctx.GetPromiseHolder(this.slot.GCHandle);
                    /*TaskCompletionSource<T>*/ let tcs = new ($.$$.System.Threading.Tasks.TaskCompletionSource$$(T))().$ctor$2(holder, 64/*TaskCreationOptions.RunContinuationsAsynchronously*/);
                    /*ToManagedCallback*/ let callback = new $.$srij.System.Runtime.InteropServices.JavaScript.JSHostImplementation.ToManagedCallback().$ctor(this,  (/*JSMarshalerArgument**/ arguments_buffer) =>
                    {
                        if (arguments_buffer === null)
                        {
                            if (!tcs.TrySetException$1(new $.$$.System.Threading.Tasks.TaskCanceledException().$ctor$20("WebWorker which is origin of the Promise is being terminated.")))
                            {
                                $.$$.System.Environment.FailFast$2("Failed to set exception to TaskCompletionSource (arguments buffer is null)");
                            }
                            return;
                        }
                        /*ref JSMarshalerArgument*/ let arg_2 = arguments_buffer.Add(3);
                        /*ref JSMarshalerArgument*/ let arg_3 = arguments_buffer.Add(4);
                        if (arg_2.$v.slot.Type !== 0/*MarshalerType.None*/)
                        {
                            /*Exception?*/ let fail;
                            arg_2.$v.ToManaged$12($.$ref(() => fail, ($v) => fail = $v, $.$$.System.Exception));
                            if (fail === null)
                            {
                                throw new $.$$.System.InvalidOperationException().$ctor$12($.$srij.System.SR.FailedToMarshalException);
                            }
                            if (!tcs.TrySetException$1(fail))
                            {
                                $.$$.System.Environment.FailFast$2("Failed to set exception to TaskCompletionSource (exception raised)");
                            }
                        }
                        else 
                        {
                            /*T*/ let result;
                            marshaler.Invoke(arg_3, $.$ref(() => result, ($v) => result = $v, T));
                            if (!tcs.TrySetResult(result))
                            {
                                $.$$.System.Environment.FailFast$2("Failed to set result to TaskCompletionSource (marshaler type is none)");
                            }
                        }
                    }, {"r":65537,"p":[{"n":"arguments_buffer","p":$.$typePointer($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument).$h}],"n":"","d":1375862,"h":0,"f":17825794});
                    holder.Callback = callback;
                    value.$v = tcs.Task;
                }
            }
            /*void */ ToJSDynamic(/*Task?*/ value)
            {
                /*Task?*/ let task = value;
                /*var*/ let ctx = this.ToJSContext;
                /*var*/ let canMarshalTaskResultOnSameCall = this.CanMarshalTaskResultOnSameCall(ctx);
                if (task === null)
                {
                    if (!canMarshalTaskResultOnSameCall)
                    {
                        $.$$.System.Environment.FailFast$2("Marshalling null return Task to JS is not supported in MT");
                    }
                    this.slot.Type = 0/*MarshalerType.None*/;
                    return;
                }
                if (canMarshalTaskResultOnSameCall && task.IsCompleted)
                {
                    if (task.Exception !== null)
                    {
                        /*Exception*/ let ex = task.Exception;
                        this.ToJS$12(ex);
                        this.slot.ElementType = this.slot.Type;
                        this.slot.Type = 29/*MarshalerType.TaskRejected*/;
                        return;
                    }
                    else 
                    {
                        /*object?*/ let result;
                        if ($.$srij.System.Runtime.InteropServices.JavaScript.JSHostImplementation.GetTaskResultDynamic(task, $.$ref(() => result, ($v) => result = $v, $.$$.System.Object)))
                        {
                            this.ToJS$29(result);
                            this.slot.ElementType = this.slot.Type;
                        }
                        else 
                        {
                            this.slot.ElementType = 1/*MarshalerType.Void*/;
                        }
                        this.slot.Type = 28/*MarshalerType.TaskResolved*/;
                        return;
                    }
                }
                if (this.slot.Type !== 30/*MarshalerType.TaskPreCreated*/)
                {
                    this.slot.JSHandle = ctx.AllocJSVHandle();
                    this.slot.Type = 20/*MarshalerType.Task*/;
                }
                else 
                {
                }
                /*var*/ let taskHolder = ctx.CreateCSOwnedProxy(this.slot.JSHandle);
                task.ContinueWith$4(new ($.$$.System.Action$$$($.$$.System.Threading.Tasks.Task, $.$$.System.Object))().$ctor($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument, Complete), taskHolder, $.$$.System.Threading.Tasks.TaskScheduler.Current);
                /*static void*/  function Complete(/*Task*/ task, /*object?*/ th)
                {
                    /*var*/ let taskHolderArg = $.$cast(th, $.$srij.System.Runtime.InteropServices.JavaScript.JSObject);
                    if (task.Exception !== null)
                    {
                        $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument.RejectPromise(taskHolderArg, task.Exception);
                    }
                    else 
                    {
                        /*object?*/ let result;
                        if ($.$srij.System.Runtime.InteropServices.JavaScript.JSHostImplementation.GetTaskResultDynamic(task, $.$ref(() => result, ($v) => result = $v, $.$$.System.Object)))
                        {
                            $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument.ResolvePromise($.$$.System.Object, taskHolderArg, result, new ($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument.ArgumentToJSCallback$$($.$$.System.Object))().$ctor($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument, MarshalResult));
                        }
                        else 
                        {
                            $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument.ResolveVoidPromise(taskHolderArg);
                        }
                    }
                }
                /*static void*/  function MarshalResult(/*ref JSMarshalerArgument*/ arg, /*object?*/ taskResult)
                {
                    arg.$v.ToJS$29(taskResult);
                }
            }
            /*void */ ToJS$37(/*Task?*/ value)
            {
                /*Task?*/ let task = value;
                /*var*/ let ctx = this.ToJSContext;
                /*var*/ let canMarshalTaskResultOnSameCall = this.CanMarshalTaskResultOnSameCall(ctx);
                if (task === null)
                {
                    if (!canMarshalTaskResultOnSameCall)
                    {
                        $.$$.System.Environment.FailFast$2("Marshalling null return Task to JS is not supported in MT");
                    }
                    this.slot.Type = 0/*MarshalerType.None*/;
                    return;
                }
                if (canMarshalTaskResultOnSameCall && task.IsCompleted)
                {
                    if (task.Exception !== null)
                    {
                        /*Exception*/ let ex = task.Exception;
                        this.ToJS$12(ex);
                        this.slot.ElementType = this.slot.Type;
                        this.slot.Type = 29/*MarshalerType.TaskRejected*/;
                        return;
                    }
                    else 
                    {
                        this.slot.ElementType = 1/*MarshalerType.Void*/;
                        this.slot.Type = 28/*MarshalerType.TaskResolved*/;
                        return;
                    }
                }
                if (this.slot.Type !== 30/*MarshalerType.TaskPreCreated*/)
                {
                    this.slot.JSHandle = ctx.AllocJSVHandle();
                    this.slot.Type = 20/*MarshalerType.Task*/;
                }
                else 
                {
                }
                /*var*/ let taskHolder = ctx.CreateCSOwnedProxy(this.slot.JSHandle);
                task.ContinueWith$4(new ($.$$.System.Action$$$($.$$.System.Threading.Tasks.Task, $.$$.System.Object))().$ctor($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument, Complete), taskHolder, $.$$.System.Threading.Tasks.TaskScheduler.Current);
                /*static void*/  function Complete(/*Task*/ task, /*object?*/ th)
                {
                    /*JSObject*/ let taskHolderArg = $.$cast(th, $.$srij.System.Runtime.InteropServices.JavaScript.JSObject);
                    if (task.Exception !== null)
                    {
                        $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument.RejectPromise(taskHolderArg, task.Exception);
                    }
                    else 
                    {
                        $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument.ResolveVoidPromise(taskHolderArg);
                    }
                }
            }
            /*void */ ToJS$43(T, /*Task<T>?*/ value, /*ArgumentToJSCallback<T>*/ marshaler)
            {
                /*Task<T>?*/ let task = value;
                /*var*/ let ctx = this.ToJSContext;
                /*var*/ let canMarshalTaskResultOnSameCall = this.CanMarshalTaskResultOnSameCall(ctx);
                if (task === null)
                {
                    if (!canMarshalTaskResultOnSameCall)
                    {
                        $.$$.System.Environment.FailFast$2("Marshalling null return Task to JS is not supported in MT");
                    }
                    this.slot.Type = 0/*MarshalerType.None*/;
                    return;
                }
                if (canMarshalTaskResultOnSameCall && task.IsCompleted)
                {
                    if (task.Exception !== null)
                    {
                        /*Exception*/ let ex = task.Exception;
                        this.ToJS$12(ex);
                        this.slot.ElementType = this.slot.Type;
                        this.slot.Type = 29/*MarshalerType.TaskRejected*/;
                        return;
                    }
                    else 
                    {
                        /*T*/ let result = task.Result;
                        this.ToJS$29($.$box(result, T));
                        this.slot.ElementType = this.slot.Type;
                        this.slot.Type = 28/*MarshalerType.TaskResolved*/;
                        return;
                    }
                }
                if (this.slot.Type !== 30/*MarshalerType.TaskPreCreated*/)
                {
                    this.slot.JSHandle = ctx.AllocJSVHandle();
                    this.slot.Type = 20/*MarshalerType.Task*/;
                }
                else 
                {
                }
                /*var*/ let taskHolder = ctx.CreateCSOwnedProxy(this.slot.JSHandle);
                task.ContinueWith$28(new ($.$$.System.Action$$$($.$$.System.Threading.Tasks.Task$$(T), $.$$.System.Object))().$ctor($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument, Complete), new ($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument.HolderAndMarshaler$$(T))().$ctor$2(taskHolder, marshaler), $.$$.System.Threading.Tasks.TaskScheduler.Current);
                /*static void*/  function Complete(/*Task<T>*/ task, /*object?*/ thm)
                {
                    /*var*/ let hm = $.$cast(thm, $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument.HolderAndMarshaler$$(T));
                    if (task.Exception !== null)
                    {
                        $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument.RejectPromise(hm.TaskHolder, task.Exception);
                    }
                    else 
                    {
                        /*T*/ let result = task.Result;
                        $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument.ResolvePromise(T, hm.TaskHolder, result, hm.Marshaler);
                    }
                }
            }
            /*bool */ CanMarshalTaskResultOnSameCall(/*JSProxyContext*/ _)
            {
                return true;
            }
            static $_HolderAndMarshaler$$;
            static HolderAndMarshaler$$(T)
            {
                let $cls = $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument;
                return ($cls.$_HolderAndMarshaler$$ ??= $asm.$ncls("$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument.HolderAndMarshaler<>", (T) => $asm.$gt("$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument.HolderAndMarshaler<>", [T], ($self) => class HolderAndMarshaler$$ extends $.$$.System.Object
                {
                    //Generated interface implemetation for System.IEquatable<System.Runtime.InteropServices.JavaScript.JSMarshalerArgument.HolderAndMarshaler<T>>.Equals(System.Runtime.InteropServices.JavaScript.JSMarshalerArgument.HolderAndMarshaler<T>?)
                    System$IEquatable$$$Equals()
                    {
                        return this.Equals$2(...arguments);
                    }
                    Clone($copy)
                    {
                        let copy = $copy ?? new this.constructor();
                        copy.TaskHolder = this.TaskHolder;
                        copy.Marshaler = this.Marshaler;
                        return copy;
                    }
                    //Begin primary constructor
                    /*JSObject*/ TaskHolder = null;
                    /*ArgumentToJSCallback<T>*/ Marshaler = null;
                    $ctor$2(/*JSObject*/$TaskHolder, /*ArgumentToJSCallback<T>*/$Marshaler)
                    {
                        this.TaskHolder = $TaskHolder;
                        this.Marshaler = $Marshaler;
                        return this
                    }
                    //End primary constructor
                    //Begin generated record members
                    /*Type*/ get EqualityContract() { return $.$typeOf($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument.HolderAndMarshaler$$(T)); }
                    /*string*/ ToString()
                    {
                        let stringBuilder = new $.$$.System.Text.StringBuilder().$ctor$1();
                        stringBuilder.Append$19("HolderAndMarshaler");
                        stringBuilder.Append$19("{");
                        if (this.PrintMembers(stringBuilder))
                        {
                            stringBuilder.Append$19(" ");
                        }
                        stringBuilder.Append$19("}");
                        return $.$$.System.Text.StringBuilder.ToString.call(stringBuilder);
                    }
                    /*bool*/ PrintMembers(/*StringBuilder*/ stringBuilder)
                    {
                        stringBuilder.Append$19("TaskHolder = ");
                        stringBuilder.Append$19($.$srij.System.Runtime.InteropServices.JavaScript.JSObject.ToString.call(this.TaskHolder));
                        stringBuilder.Append$19(", ");
                        stringBuilder.Append$19("Marshaler = ");
                        stringBuilder.Append$19($.$$.System.Object.ToString.call(this.Marshaler));
                        return true;
                    }
                    /*bool*/ Equals$2(/*HolderAndMarshaler*/ other)
                    {
                        return this === other || (other !== null && this.EqualityContract == other.EqualityContract && $.$$.System.Collections.Generic.EqualityComparer$$($.$srij.System.Runtime.InteropServices.JavaScript.JSObject).Default.Equals$2(this.TaskHolder, other.TaskHolder) && $.$$.System.Collections.Generic.EqualityComparer$$($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument.ArgumentToJSCallback$$(T)).Default.Equals$2(this.Marshaler, other.Marshaler));
                    }
                    /*int*/ GetHashCode()
                    {
                        return $.$$.System.Collections.Generic.EqualityComparer$$($.$$.System.Type).Default.GetHashCode$1(this.EqualityContract) * -1521134295 && $.$$.System.Collections.Generic.EqualityComparer$$($.$srij.System.Runtime.InteropServices.JavaScript.JSObject).Default.GetHashCode$1(this.TaskHolder) * -1521134295 && $.$$.System.Collections.Generic.EqualityComparer$$($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument.ArgumentToJSCallback$$(T)).Default.GetHashCode$1(this.Marshaler) * -1521134295;
                    }
                    static /*bool*/ op_InEquality(/*HolderAndMarshaler*/ left, /*HolderAndMarshaler*/ right)
                    {
                        return !(this.op_Equals(left, right));
                    }
                    static /*bool*/ op_Equality(/*HolderAndMarshaler*/ left, /*HolderAndMarshaler*/ right)
                    {
                        return left === right || (left !== null && left.Equals$2(right));
                    }
                    Deconstruct(/*out System.Runtime.InteropServices.JavaScript.JSObject*/ $TaskHolder, /*out System.Runtime.InteropServices.JavaScript.JSMarshalerArgument.ArgumentToJSCallback<T>*/ $Marshaler)
                    {
                        $TaskHolder.$v = this.TaskHolder;
                        $Marshaler.$v = this.Marshaler;
                    }
                    //End generated record member3s
                    static $h = 2096758;
                    static $g = 1;
                    static $f = 0b10000000011010000;
                    static $k = 1;
                    static $$md;
                    static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":142475265,"g":{"r":0,"d":0,"h":Number(BigInt(this.$h)|0x200000000n),"f":50331650},"n":"EqualityContract","d":this.$h,"h":Number(BigInt(this.$h)|0x300000000n),"f":2097154},{"p":2293366,"g":{"r":0,"d":0,"h":Number(BigInt(this.$h)|0x500000000n),"f":50331649},"s":{"r":0,"d":0,"h":Number(BigInt(this.$h)|0x600000000n),"f":83886081},"n":"TaskHolder","d":this.$h,"h":Number(BigInt(this.$h)|0x700000000n),"f":2097153},{"p":$.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument.ArgumentToJSCallback$$(T).$h,"g":{"r":0,"d":0,"h":Number(BigInt(this.$h)|0x900000000n),"f":50331649},"s":{"r":0,"d":0,"h":Number(BigInt(this.$h)|0xA00000000n),"f":83886081},"n":"Marshaler","d":this.$h,"h":Number(BigInt(this.$h)|0xB00000000n),"f":2097153}],"m":[{"r":1310721,"n":"ToString","d":this.$h,"h":Number(BigInt(this.$h)|0xC00000000n),"f":16809985},{"r":262145,"p":[{"n":"builder","p":122814465}],"n":"PrintMembers","d":this.$h,"h":Number(BigInt(this.$h)|0xD00000000n),"f":16777218},{"r":655361,"n":"GetHashCode","d":this.$h,"h":Number(BigInt(this.$h)|0x1000000000n),"f":16809985},{"r":262145,"p":[{"n":"obj","p":131073}],"n":"Equals","o":"@$1","d":this.$h,"h":Number(BigInt(this.$h)|0x1100000000n),"f":16809985},{"r":262145,"p":[{"n":"other","p":this.$h}],"n":"Equals","o":"@$2","d":this.$h,"h":Number(BigInt(this.$h)|0x1200000000n),"f":16777217},{"r":this.$h,"n":"\u003CClone\u003E$","o":"$$$","d":this.$h,"h":Number(BigInt(this.$h)|0x1300000000n),"f":16777217},{"r":65537,"p":[{"n":"TaskHolder","p":2293366,"f":2},{"n":"Marshaler","p":$.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument.ArgumentToJSCallback$$(T).$h,"f":2}],"n":"Deconstruct","d":this.$h,"h":Number(BigInt(this.$h)|0x1500000000n),"f":16777217}],"c":[{"p":[{"n":"TaskHolder","p":2293366},{"n":"Marshaler","p":$.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument.ArgumentToJSCallback$$(T).$h}],"n":".ctor","o":"$ctor$2","d":this.$h,"h":Number(BigInt(this.$h)|0x100000000n),"f":16777217},{"p":[{"n":"original","p":this.$h}],"n":".ctor","o":"$ctor$1","d":this.$h,"h":Number(BigInt(this.$h)|0x1400000000n),"f":16777218}],"i":[$.$$.System.IEquatable$$($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument.HolderAndMarshaler$$(T)).$h],"g":[T?.$h??1507328],"r":1,"d":1375862,"h":this.$h}; }
                    static get $b() { return $.$$.System.Object; }
                    static $$i;
                    static get $i() { return this.$$i ??= [ $.$$.System.IEquatable$$($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument.HolderAndMarshaler$$(T)) ]; }
                    static get $fullName() { return `System.Runtime.InteropServices.JavaScript.JSMarshalerArgument.HolderAndMarshaler<${T?.$fullName}>`; }
                }), $cls, ($v) => $cls.$_HolderAndMarshaler$$ = $v))(T);
            }
            static /*void */ RejectPromise(/*JSObject*/ holder, /*Exception*/ ex)
            {
                holder.AssertNotDisposed();
                /*Span<JSMarshalerArgument>*/ let args = $.$$.System.Runtime.CompilerServices.RuntimeHelpers.StackAllocSpan($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument, 4, null);
                /*ref JSMarshalerArgument*/ let exc = args.get_Item(0);
                /*ref JSMarshalerArgument*/ let res = args.get_Item(1);
                /*ref JSMarshalerArgument*/ let arg_handle = args.get_Item(2);
                /*ref JSMarshalerArgument*/ let arg_value = args.get_Item(3);
                exc.$v.Initialize();
                res.$v.Initialize();
                arg_handle.$v.slot.Type = 29/*MarshalerType.TaskRejected*/;
                arg_handle.$v.slot.JSHandle = holder.JSHandle;
                arg_value.$v.ToJS$12(ex);
                holder.DisposeImpl(true);
                $.$srij.System.Runtime.InteropServices.JavaScript.JSFunctionBinding.ResolveOrRejectPromise(holder.ProxyContext, args);
            }
            static /*void */ ResolveVoidPromise(/*JSObject*/ holder)
            {
                holder.AssertNotDisposed();
                /*Span<JSMarshalerArgument>*/ let args = $.$$.System.Runtime.CompilerServices.RuntimeHelpers.StackAllocSpan($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument, 4, null);
                /*ref JSMarshalerArgument*/ let exc = args.get_Item(0);
                /*ref JSMarshalerArgument*/ let res = args.get_Item(1);
                /*ref JSMarshalerArgument*/ let arg_handle = args.get_Item(2);
                /*ref JSMarshalerArgument*/ let arg_value = args.get_Item(3);
                exc.$v.Initialize();
                res.$v.Initialize();
                arg_handle.$v.slot.Type = 28/*MarshalerType.TaskResolved*/;
                arg_handle.$v.slot.JSHandle = holder.JSHandle;
                arg_value.$v.slot.Type = 1/*MarshalerType.Void*/;
                holder.DisposeImpl(true);
                $.$srij.System.Runtime.InteropServices.JavaScript.JSFunctionBinding.ResolveOrRejectPromise(holder.ProxyContext, args);
            }
            static /*void */ ResolvePromise(T, /*JSObject*/ holder, /*T*/ value, /*ArgumentToJSCallback<T>*/ marshaler)
            {
                holder.AssertNotDisposed();
                /*Span<JSMarshalerArgument>*/ let args = $.$$.System.Runtime.CompilerServices.RuntimeHelpers.StackAllocSpan($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument, 4, null);
                /*ref JSMarshalerArgument*/ let exc = args.get_Item(0);
                /*ref JSMarshalerArgument*/ let res = args.get_Item(1);
                /*ref JSMarshalerArgument*/ let arg_handle = args.get_Item(2);
                /*ref JSMarshalerArgument*/ let arg_value = args.get_Item(3);
                exc.$v.Initialize();
                res.$v.Initialize();
                arg_handle.$v.slot.Type = 28/*MarshalerType.TaskResolved*/;
                arg_handle.$v.slot.JSHandle = holder.JSHandle;
                marshaler.Invoke(arg_value, value);
                holder.DisposeImpl(true);
                $.$srij.System.Runtime.InteropServices.JavaScript.JSFunctionBinding.ResolveOrRejectPromise(holder.ProxyContext, args);
            }
            static $_ActionJS;
            static get ActionJS()
            {
                let $cls = $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument;
                return $cls.$_ActionJS ??= $asm.$ncls("$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument.ActionJS", ($self) => class ActionJS extends $.$$.System.Object
                {
                    /*JSObject*/ JSObject = null;
                    $ctor$1(/*JSObject*/ holder)
                    {
                        super.$ctor();
                        {
                            this.JSObject = holder;
                        }
                        return this;
                    }
                    /*void */ InvokeJS()
                    {
                        /*Span<JSMarshalerArgument>*/ let $arguments = $.$$.System.Runtime.CompilerServices.RuntimeHelpers.StackAllocSpan($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument, 2, null);
                        /*ref JSMarshalerArgument*/ let args_exception = $arguments.get_Item(0);
                        /*ref JSMarshalerArgument*/ let args_return = $arguments.get_Item(1);
                        args_exception.$v.Initialize();
                        args_return.$v.Initialize();
                        $.$srij.System.Runtime.InteropServices.JavaScript.JSFunctionBinding.InvokeJSFunction(this.JSObject, $arguments);
                    }
                    static $h = 1441398;
                    static $f = 0b10000000010010000;
                    static $k = 1;
                    static $$md;
                    static get $md() { return this.$$md ??= {"b":131073,"m":[{"r":65537,"n":"InvokeJS","d":1441398,"h":12886343286,"f":16777217}],"l":[{"t":2293366,"n":"JSObject","d":1441398,"h":4296408694,"f":4194306}],"c":[{"p":[{"n":"holder","p":2293366}],"n":".ctor","o":"$ctor$1","d":1441398,"h":8591375990,"f":16777217}],"d":1375862,"h":1441398}; }
                    static get $b() { return $.$$.System.Object; }
                    static get $fullName() { return `System.Runtime.InteropServices.JavaScript.JSMarshalerArgument.ActionJS`; }
                }, $cls, ($v) => $cls.$_ActionJS = $v);
            }
            static $_ActionJS$$;
            static ActionJS$$(T)
            {
                let $cls = $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument;
                return ($cls.$_ActionJS$$ ??= $asm.$ncls("$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument.ActionJS<>", (T) => $asm.$gt("$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument.ActionJS<>", [T], ($self) => class ActionJS$$ extends $.$$.System.Object
                {
                    /*ArgumentToJSCallback<T>*/ Arg1Marshaler = null;
                    /*JSObject*/ JSObject = null;
                    $ctor$1(/*JSObject*/ holder, /*ArgumentToJSCallback<T>*/ arg1Marshaler)
                    {
                        super.$ctor();
                        {
                            this.JSObject = holder;
                            this.Arg1Marshaler = arg1Marshaler;
                        }
                        return this;
                    }
                    /*void */ InvokeJS(/*T*/ arg1)
                    {
                        /*Span<JSMarshalerArgument>*/ let $arguments = $.$$.System.Runtime.CompilerServices.RuntimeHelpers.StackAllocSpan($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument, 3, null);
                        /*ref JSMarshalerArgument*/ let args_exception = $arguments.get_Item(0);
                        /*ref JSMarshalerArgument*/ let args_return = $arguments.get_Item(1);
                        /*ref JSMarshalerArgument*/ let args_arg1 = $arguments.get_Item(2);
                        args_exception.$v.Initialize();
                        args_return.$v.Initialize();
                        this.Arg1Marshaler.Invoke(args_arg1, arg1);
                        $.$srij.System.Runtime.InteropServices.JavaScript.JSFunctionBinding.InvokeJSFunction(this.JSObject, $arguments);
                    }
                    static $h = 1638006;
                    static $g = 1;
                    static $f = 0b10000000011010000;
                    static $k = 1;
                    static $$md;
                    static get $md() { return this.$$md ??= {"b":131073,"m":[{"r":65537,"p":[{"n":"arg1","p":T?.$h??1507328}],"n":"InvokeJS","d":this.$h,"h":Number(BigInt(this.$h)|0x400000000n),"f":16777217}],"l":[{"t":$.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument.ArgumentToJSCallback$$(T).$h,"n":"Arg1Marshaler","d":this.$h,"h":Number(BigInt(this.$h)|0x100000000n),"f":4194306},{"t":2293366,"n":"JSObject","d":this.$h,"h":Number(BigInt(this.$h)|0x200000000n),"f":4194306}],"c":[{"p":[{"n":"holder","p":2293366},{"n":"arg1Marshaler","p":$.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument.ArgumentToJSCallback$$(T).$h}],"n":".ctor","o":"$ctor$1","d":this.$h,"h":Number(BigInt(this.$h)|0x300000000n),"f":16777217}],"g":[T?.$h??1507328],"r":1,"d":1375862,"h":this.$h}; }
                    static get $b() { return $.$$.System.Object; }
                    static get $fullName() { return `System.Runtime.InteropServices.JavaScript.JSMarshalerArgument.ActionJS<${T?.$fullName}>`; }
                }), $cls, ($v) => $cls.$_ActionJS$$ = $v))(T);
            }
            static $_ActionJS$$$;
            static ActionJS$$$(T1, T2)
            {
                let $cls = $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument;
                return ($cls.$_ActionJS$$$ ??= $asm.$ncls("$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument.ActionJS<,>", (T1, T2) => $asm.$gt("$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument.ActionJS<,>", [T1, T2], ($self) => class ActionJS$$$ extends $.$$.System.Object
                {
                    /*ArgumentToJSCallback<T1>*/ Arg1Marshaler = null;
                    /*ArgumentToJSCallback<T2>*/ Arg2Marshaler = null;
                    /*JSObject*/ JSObject = null;
                    $ctor$1(/*JSObject*/ holder, /*ArgumentToJSCallback<T1>*/ arg1Marshaler, /*ArgumentToJSCallback<T2>*/ arg2Marshaler)
                    {
                        super.$ctor();
                        {
                            this.JSObject = holder;
                            this.Arg1Marshaler = arg1Marshaler;
                            this.Arg2Marshaler = arg2Marshaler;
                        }
                        return this;
                    }
                    /*void */ InvokeJS(/*T1*/ arg1, /*T2*/ arg2)
                    {
                        /*Span<JSMarshalerArgument>*/ let $arguments = $.$$.System.Runtime.CompilerServices.RuntimeHelpers.StackAllocSpan($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument, 4, null);
                        /*ref JSMarshalerArgument*/ let args_exception = $arguments.get_Item(0);
                        /*ref JSMarshalerArgument*/ let args_return = $arguments.get_Item(1);
                        /*ref JSMarshalerArgument*/ let args_arg1 = $arguments.get_Item(2);
                        /*ref JSMarshalerArgument*/ let args_arg2 = $arguments.get_Item(3);
                        args_exception.$v.Initialize();
                        args_return.$v.Initialize();
                        this.Arg1Marshaler.Invoke(args_arg1, arg1);
                        this.Arg2Marshaler.Invoke(args_arg2, arg2);
                        $.$srij.System.Runtime.InteropServices.JavaScript.JSFunctionBinding.InvokeJSFunction(this.JSObject, $arguments);
                    }
                    static $h = 1572470;
                    static $g = 2;
                    static $f = 0b10000000011010000;
                    static $k = 1;
                    static $$md;
                    static get $md() { return this.$$md ??= {"b":131073,"m":[{"r":65537,"p":[{"n":"arg1","p":T1?.$h??1507328},{"n":"arg2","p":T2?.$h??1572864}],"n":"InvokeJS","d":this.$h,"h":Number(BigInt(this.$h)|0x500000000n),"f":16777217}],"l":[{"t":$.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument.ArgumentToJSCallback$$(T1).$h,"n":"Arg1Marshaler","d":this.$h,"h":Number(BigInt(this.$h)|0x100000000n),"f":4194306},{"t":$.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument.ArgumentToJSCallback$$(T2).$h,"n":"Arg2Marshaler","d":this.$h,"h":Number(BigInt(this.$h)|0x200000000n),"f":4194306},{"t":2293366,"n":"JSObject","d":this.$h,"h":Number(BigInt(this.$h)|0x300000000n),"f":4194306}],"c":[{"p":[{"n":"holder","p":2293366},{"n":"arg1Marshaler","p":$.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument.ArgumentToJSCallback$$(T1).$h},{"n":"arg2Marshaler","p":$.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument.ArgumentToJSCallback$$(T2).$h}],"n":".ctor","o":"$ctor$1","d":this.$h,"h":Number(BigInt(this.$h)|0x400000000n),"f":16777217}],"g":[T1?.$h??1507328,T2?.$h??1572864],"r":2,"d":1375862,"h":this.$h}; }
                    static get $b() { return $.$$.System.Object; }
                    static get $fullName() { return `System.Runtime.InteropServices.JavaScript.JSMarshalerArgument.ActionJS<${T1?.$fullName},${T2?.$fullName}>`; }
                }), $cls, ($v) => $cls.$_ActionJS$$$ = $v))(T1, T2);
            }
            static $_ActionJS$$$$;
            static ActionJS$$$$(T1, T2, T3)
            {
                let $cls = $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument;
                return ($cls.$_ActionJS$$$$ ??= $asm.$ncls("$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument.ActionJS<,,>", (T1, T2, T3) => $asm.$gt("$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument.ActionJS<,,>", [T1, T2, T3], ($self) => class ActionJS$$$$ extends $.$$.System.Object
                {
                    /*ArgumentToJSCallback<T1>*/ Arg1Marshaler = null;
                    /*ArgumentToJSCallback<T2>*/ Arg2Marshaler = null;
                    /*ArgumentToJSCallback<T3>*/ Arg3Marshaler = null;
                    /*JSObject*/ JSObject = null;
                    $ctor$1(/*JSObject*/ holder, /*ArgumentToJSCallback<T1>*/ arg1Marshaler, /*ArgumentToJSCallback<T2>*/ arg2Marshaler, /*ArgumentToJSCallback<T3>*/ arg3Marshaler)
                    {
                        super.$ctor();
                        {
                            this.JSObject = holder;
                            this.Arg1Marshaler = arg1Marshaler;
                            this.Arg2Marshaler = arg2Marshaler;
                            this.Arg3Marshaler = arg3Marshaler;
                        }
                        return this;
                    }
                    /*void */ InvokeJS(/*T1*/ arg1, /*T2*/ arg2, /*T3*/ arg3)
                    {
                        /*Span<JSMarshalerArgument>*/ let $arguments = $.$$.System.Runtime.CompilerServices.RuntimeHelpers.StackAllocSpan($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument, 5, null);
                        /*ref JSMarshalerArgument*/ let args_exception = $arguments.get_Item(0);
                        /*ref JSMarshalerArgument*/ let args_return = $arguments.get_Item(1);
                        /*ref JSMarshalerArgument*/ let args_arg1 = $arguments.get_Item(2);
                        /*ref JSMarshalerArgument*/ let args_arg2 = $arguments.get_Item(3);
                        /*ref JSMarshalerArgument*/ let args_arg3 = $arguments.get_Item(4);
                        args_exception.$v.Initialize();
                        args_return.$v.Initialize();
                        this.Arg1Marshaler.Invoke(args_arg1, arg1);
                        this.Arg2Marshaler.Invoke(args_arg2, arg2);
                        this.Arg3Marshaler.Invoke(args_arg3, arg3);
                        $.$srij.System.Runtime.InteropServices.JavaScript.JSFunctionBinding.InvokeJSFunction(this.JSObject, $arguments);
                    }
                    static $h = 1506934;
                    static $g = 3;
                    static $f = 0b10000000011010000;
                    static $k = 1;
                    static $$md;
                    static get $md() { return this.$$md ??= {"b":131073,"m":[{"r":65537,"p":[{"n":"arg1","p":T1?.$h??1507328},{"n":"arg2","p":T2?.$h??1572864},{"n":"arg3","p":T3?.$h??1638400}],"n":"InvokeJS","d":this.$h,"h":Number(BigInt(this.$h)|0x600000000n),"f":16777217}],"l":[{"t":$.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument.ArgumentToJSCallback$$(T1).$h,"n":"Arg1Marshaler","d":this.$h,"h":Number(BigInt(this.$h)|0x100000000n),"f":4194306},{"t":$.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument.ArgumentToJSCallback$$(T2).$h,"n":"Arg2Marshaler","d":this.$h,"h":Number(BigInt(this.$h)|0x200000000n),"f":4194306},{"t":$.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument.ArgumentToJSCallback$$(T3).$h,"n":"Arg3Marshaler","d":this.$h,"h":Number(BigInt(this.$h)|0x300000000n),"f":4194306},{"t":2293366,"n":"JSObject","d":this.$h,"h":Number(BigInt(this.$h)|0x400000000n),"f":4194306}],"c":[{"p":[{"n":"holder","p":2293366},{"n":"arg1Marshaler","p":$.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument.ArgumentToJSCallback$$(T1).$h},{"n":"arg2Marshaler","p":$.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument.ArgumentToJSCallback$$(T2).$h},{"n":"arg3Marshaler","p":$.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument.ArgumentToJSCallback$$(T3).$h}],"n":".ctor","o":"$ctor$1","d":this.$h,"h":Number(BigInt(this.$h)|0x500000000n),"f":16777217}],"g":[T1?.$h??1507328,T2?.$h??1572864,T3?.$h??1638400],"r":3,"d":1375862,"h":this.$h}; }
                    static get $b() { return $.$$.System.Object; }
                    static get $fullName() { return `System.Runtime.InteropServices.JavaScript.JSMarshalerArgument.ActionJS<${T1?.$fullName},${T2?.$fullName},${T3?.$fullName}>`; }
                }), $cls, ($v) => $cls.$_ActionJS$$$$ = $v))(T1, T2, T3);
            }
            /*void */ ToManaged(/*out Action?*/ value)
            {
                if (this.slot.Type === 0/*MarshalerType.None*/)
                {
                    value.$v = null;
                    return;
                }
                /*var*/ let ctx = this.ToManagedContext;
                /*var*/ let holder = ctx.CreateCSOwnedProxy(this.slot.JSHandle);
                value.$v = new $.$$.System.Action().$ctor(new $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument.ActionJS().$ctor$1(holder), new $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument.ActionJS().$ctor$1(holder).InvokeJS);
            }
            /*void */ ToManaged$42(T, /*out Action<T>?*/ value, /*ArgumentToJSCallback<T>*/ arg1Marshaler)
            {
                if (this.slot.Type === 0/*MarshalerType.None*/)
                {
                    value.$v = null;
                    return;
                }
                /*var*/ let ctx = this.ToManagedContext;
                /*var*/ let holder = ctx.CreateCSOwnedProxy(this.slot.JSHandle);
                value.$v = new ($.$$.System.Action$$(T))().$ctor(new ($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument.ActionJS$$(T))().$ctor$1(holder, arg1Marshaler), new ($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument.ActionJS$$(T))().$ctor$1(holder, arg1Marshaler).InvokeJS);
            }
            /*void */ ToManaged$47(T1, T2, /*out Action<T1, T2>?*/ value, /*ArgumentToJSCallback<T1>*/ arg1Marshaler, /*ArgumentToJSCallback<T2>*/ arg2Marshaler)
            {
                if (this.slot.Type === 0/*MarshalerType.None*/)
                {
                    value.$v = null;
                    return;
                }
                /*var*/ let ctx = this.ToManagedContext;
                /*var*/ let holder = ctx.CreateCSOwnedProxy(this.slot.JSHandle);
                value.$v = new ($.$$.System.Action$$$(T1, T2))().$ctor(new ($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument.ActionJS$$$(T1, T2))().$ctor$1(holder, arg1Marshaler, arg2Marshaler), new ($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument.ActionJS$$$(T1, T2))().$ctor$1(holder, arg1Marshaler, arg2Marshaler).InvokeJS);
            }
            /*void */ ToManaged$45(T1, T2, T3, /*out Action<T1, T2, T3>?*/ value, /*ArgumentToJSCallback<T1>*/ arg1Marshaler, /*ArgumentToJSCallback<T2>*/ arg2Marshaler, /*ArgumentToJSCallback<T3>*/ arg3Marshaler)
            {
                if (this.slot.Type === 0/*MarshalerType.None*/)
                {
                    value.$v = null;
                    return;
                }
                /*var*/ let ctx = this.ToManagedContext;
                /*var*/ let holder = ctx.CreateCSOwnedProxy(this.slot.JSHandle);
                value.$v = new ($.$$.System.Action$$$$(T1, T2, T3))().$ctor(new ($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument.ActionJS$$$$(T1, T2, T3))().$ctor$1(holder, arg1Marshaler, arg2Marshaler, arg3Marshaler), new ($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument.ActionJS$$$$(T1, T2, T3))().$ctor$1(holder, arg1Marshaler, arg2Marshaler, arg3Marshaler).InvokeJS);
            }
            static $_FuncJS$$;
            static FuncJS$$(TResult)
            {
                let $cls = $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument;
                return ($cls.$_FuncJS$$ ??= $asm.$ncls("$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument.FuncJS<>", (TResult) => $asm.$gt("$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument.FuncJS<>", [TResult], ($self) => class FuncJS$$ extends $.$$.System.Object
                {
                    /*JSObject*/ JSObject = null;
                    /*ArgumentToManagedCallback<TResult>*/ ResMarshaler = null;
                    $ctor$1(/*JSObject*/ holder, /*ArgumentToManagedCallback<TResult>*/ resMarshaler)
                    {
                        super.$ctor();
                        {
                            this.JSObject = holder;
                            this.ResMarshaler = resMarshaler;
                        }
                        return this;
                    }
                    /*TResult */ InvokeJS()
                    {
                        /*Span<JSMarshalerArgument>*/ let $arguments = $.$$.System.Runtime.CompilerServices.RuntimeHelpers.StackAllocSpan($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument, 2, null);
                        /*ref JSMarshalerArgument*/ let args_exception = $arguments.get_Item(0);
                        /*ref JSMarshalerArgument*/ let args_return = $arguments.get_Item(1);
                        args_exception.$v.Initialize();
                        args_return.$v.Initialize();
                        $.$srij.System.Runtime.InteropServices.JavaScript.JSFunctionBinding.InvokeJSFunction(this.JSObject, $arguments);
                        /*TResult*/ let res;
                        this.ResMarshaler.Invoke(args_return, $.$ref(() => res, ($v) => res = $v, TResult));
                        return res;
                    }
                    static $h = 2031222;
                    static $g = 1;
                    static $f = 0b10000000011010000;
                    static $k = 1;
                    static $$md;
                    static get $md() { return this.$$md ??= {"b":131073,"m":[{"r":TResult?.$h??1507328,"n":"InvokeJS","d":this.$h,"h":Number(BigInt(this.$h)|0x400000000n),"f":16777217}],"l":[{"t":2293366,"n":"JSObject","d":this.$h,"h":Number(BigInt(this.$h)|0x100000000n),"f":4194306},{"t":$.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument.ArgumentToManagedCallback$$(TResult).$h,"n":"ResMarshaler","d":this.$h,"h":Number(BigInt(this.$h)|0x200000000n),"f":4194306}],"c":[{"p":[{"n":"holder","p":2293366},{"n":"resMarshaler","p":$.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument.ArgumentToManagedCallback$$(TResult).$h}],"n":".ctor","o":"$ctor$1","d":this.$h,"h":Number(BigInt(this.$h)|0x300000000n),"f":16777217}],"g":[TResult?.$h??1507328],"r":1,"d":1375862,"h":this.$h}; }
                    static get $b() { return $.$$.System.Object; }
                    static get $fullName() { return `System.Runtime.InteropServices.JavaScript.JSMarshalerArgument.FuncJS<${TResult?.$fullName}>`; }
                }), $cls, ($v) => $cls.$_FuncJS$$ = $v))(TResult);
            }
            static $_FuncJS$$$;
            static FuncJS$$$(T, TResult)
            {
                let $cls = $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument;
                return ($cls.$_FuncJS$$$ ??= $asm.$ncls("$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument.FuncJS<,>", (T, TResult) => $asm.$gt("$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument.FuncJS<,>", [T, TResult], ($self) => class FuncJS$$$ extends $.$$.System.Object
                {
                    /*ArgumentToJSCallback<T>*/ Arg1Marshaler = null;
                    /*ArgumentToManagedCallback<TResult>*/ ResMarshaler = null;
                    /*JSObject*/ JSObject = null;
                    $ctor$1(/*JSObject*/ holder, /*ArgumentToJSCallback<T>*/ arg1Marshaler, /*ArgumentToManagedCallback<TResult>*/ resMarshaler)
                    {
                        super.$ctor();
                        {
                            this.JSObject = holder;
                            this.Arg1Marshaler = arg1Marshaler;
                            this.ResMarshaler = resMarshaler;
                        }
                        return this;
                    }
                    /*TResult */ InvokeJS(/*T*/ arg1)
                    {
                        /*Span<JSMarshalerArgument>*/ let $arguments = $.$$.System.Runtime.CompilerServices.RuntimeHelpers.StackAllocSpan($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument, 3, null);
                        /*ref JSMarshalerArgument*/ let args_exception = $arguments.get_Item(0);
                        /*ref JSMarshalerArgument*/ let args_return = $arguments.get_Item(1);
                        /*ref JSMarshalerArgument*/ let args_arg1 = $arguments.get_Item(2);
                        args_exception.$v.Initialize();
                        args_return.$v.Initialize();
                        this.Arg1Marshaler.Invoke(args_arg1, arg1);
                        $.$srij.System.Runtime.InteropServices.JavaScript.JSFunctionBinding.InvokeJSFunction(this.JSObject, $arguments);
                        /*TResult*/ let res;
                        this.ResMarshaler.Invoke(args_return, $.$ref(() => res, ($v) => res = $v, TResult));
                        return res;
                    }
                    static $h = 1965686;
                    static $g = 2;
                    static $f = 0b10000000011010000;
                    static $k = 1;
                    static $$md;
                    static get $md() { return this.$$md ??= {"b":131073,"m":[{"r":TResult?.$h??1572864,"p":[{"n":"arg1","p":T?.$h??1507328}],"n":"InvokeJS","d":this.$h,"h":Number(BigInt(this.$h)|0x500000000n),"f":16777217}],"l":[{"t":$.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument.ArgumentToJSCallback$$(T).$h,"n":"Arg1Marshaler","d":this.$h,"h":Number(BigInt(this.$h)|0x100000000n),"f":4194306},{"t":$.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument.ArgumentToManagedCallback$$(TResult).$h,"n":"ResMarshaler","d":this.$h,"h":Number(BigInt(this.$h)|0x200000000n),"f":4194306},{"t":2293366,"n":"JSObject","d":this.$h,"h":Number(BigInt(this.$h)|0x300000000n),"f":4194306}],"c":[{"p":[{"n":"holder","p":2293366},{"n":"arg1Marshaler","p":$.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument.ArgumentToJSCallback$$(T).$h},{"n":"resMarshaler","p":$.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument.ArgumentToManagedCallback$$(TResult).$h}],"n":".ctor","o":"$ctor$1","d":this.$h,"h":Number(BigInt(this.$h)|0x400000000n),"f":16777217}],"g":[T?.$h??1507328,TResult?.$h??1572864],"r":2,"d":1375862,"h":this.$h}; }
                    static get $b() { return $.$$.System.Object; }
                    static get $fullName() { return `System.Runtime.InteropServices.JavaScript.JSMarshalerArgument.FuncJS<${T?.$fullName},${TResult?.$fullName}>`; }
                }), $cls, ($v) => $cls.$_FuncJS$$$ = $v))(T, TResult);
            }
            static $_FuncJS$$$$;
            static FuncJS$$$$(T1, T2, TResult)
            {
                let $cls = $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument;
                return ($cls.$_FuncJS$$$$ ??= $asm.$ncls("$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument.FuncJS<,,>", (T1, T2, TResult) => $asm.$gt("$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument.FuncJS<,,>", [T1, T2, TResult], ($self) => class FuncJS$$$$ extends $.$$.System.Object
                {
                    /*ArgumentToJSCallback<T1>*/ Arg1Marshaler = null;
                    /*ArgumentToJSCallback<T2>*/ Arg2Marshaler = null;
                    /*ArgumentToManagedCallback<TResult>*/ ResMarshaler = null;
                    /*JSObject*/ JSObject = null;
                    $ctor$1(/*JSObject*/ holder, /*ArgumentToJSCallback<T1>*/ arg1Marshaler, /*ArgumentToJSCallback<T2>*/ arg2Marshaler, /*ArgumentToManagedCallback<TResult>*/ resMarshaler)
                    {
                        super.$ctor();
                        {
                            this.JSObject = holder;
                            this.Arg1Marshaler = arg1Marshaler;
                            this.Arg2Marshaler = arg2Marshaler;
                            this.ResMarshaler = resMarshaler;
                        }
                        return this;
                    }
                    /*TResult */ InvokeJS(/*T1*/ arg1, /*T2*/ arg2)
                    {
                        /*Span<JSMarshalerArgument>*/ let $arguments = $.$$.System.Runtime.CompilerServices.RuntimeHelpers.StackAllocSpan($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument, 4, null);
                        /*ref JSMarshalerArgument*/ let args_exception = $arguments.get_Item(0);
                        /*ref JSMarshalerArgument*/ let args_return = $arguments.get_Item(1);
                        /*ref JSMarshalerArgument*/ let args_arg1 = $arguments.get_Item(2);
                        /*ref JSMarshalerArgument*/ let args_arg2 = $arguments.get_Item(3);
                        args_exception.$v.Initialize();
                        args_return.$v.Initialize();
                        this.Arg1Marshaler.Invoke(args_arg1, arg1);
                        this.Arg2Marshaler.Invoke(args_arg2, arg2);
                        $.$srij.System.Runtime.InteropServices.JavaScript.JSFunctionBinding.InvokeJSFunction(this.JSObject, $arguments);
                        /*TResult*/ let res;
                        this.ResMarshaler.Invoke(args_return, $.$ref(() => res, ($v) => res = $v, TResult));
                        return res;
                    }
                    static $h = 1900150;
                    static $g = 3;
                    static $f = 0b10000000011010000;
                    static $k = 1;
                    static $$md;
                    static get $md() { return this.$$md ??= {"b":131073,"m":[{"r":TResult?.$h??1638400,"p":[{"n":"arg1","p":T1?.$h??1507328},{"n":"arg2","p":T2?.$h??1572864}],"n":"InvokeJS","d":this.$h,"h":Number(BigInt(this.$h)|0x600000000n),"f":16777217}],"l":[{"t":$.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument.ArgumentToJSCallback$$(T1).$h,"n":"Arg1Marshaler","d":this.$h,"h":Number(BigInt(this.$h)|0x100000000n),"f":4194306},{"t":$.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument.ArgumentToJSCallback$$(T2).$h,"n":"Arg2Marshaler","d":this.$h,"h":Number(BigInt(this.$h)|0x200000000n),"f":4194306},{"t":$.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument.ArgumentToManagedCallback$$(TResult).$h,"n":"ResMarshaler","d":this.$h,"h":Number(BigInt(this.$h)|0x300000000n),"f":4194306},{"t":2293366,"n":"JSObject","d":this.$h,"h":Number(BigInt(this.$h)|0x400000000n),"f":4194306}],"c":[{"p":[{"n":"holder","p":2293366},{"n":"arg1Marshaler","p":$.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument.ArgumentToJSCallback$$(T1).$h},{"n":"arg2Marshaler","p":$.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument.ArgumentToJSCallback$$(T2).$h},{"n":"resMarshaler","p":$.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument.ArgumentToManagedCallback$$(TResult).$h}],"n":".ctor","o":"$ctor$1","d":this.$h,"h":Number(BigInt(this.$h)|0x500000000n),"f":16777217}],"g":[T1?.$h??1507328,T2?.$h??1572864,TResult?.$h??1638400],"r":3,"d":1375862,"h":this.$h}; }
                    static get $b() { return $.$$.System.Object; }
                    static get $fullName() { return `System.Runtime.InteropServices.JavaScript.JSMarshalerArgument.FuncJS<${T1?.$fullName},${T2?.$fullName},${TResult?.$fullName}>`; }
                }), $cls, ($v) => $cls.$_FuncJS$$$$ = $v))(T1, T2, TResult);
            }
            static $_FuncJS$$$$$;
            static FuncJS$$$$$(T1, T2, T3, TResult)
            {
                let $cls = $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument;
                return ($cls.$_FuncJS$$$$$ ??= $asm.$ncls("$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument.FuncJS<,,,>", (T1, T2, T3, TResult) => $asm.$gt("$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument.FuncJS<,,,>", [T1, T2, T3, TResult], ($self) => class FuncJS$$$$$ extends $.$$.System.Object
                {
                    /*ArgumentToJSCallback<T1>*/ Arg1Marshaler = null;
                    /*ArgumentToJSCallback<T2>*/ Arg2Marshaler = null;
                    /*ArgumentToJSCallback<T3>*/ Arg3Marshaler = null;
                    /*ArgumentToManagedCallback<TResult>*/ ResMarshaler = null;
                    /*JSObject*/ JSObject = null;
                    $ctor$1(/*JSObject*/ holder, /*ArgumentToJSCallback<T1>*/ arg1Marshaler, /*ArgumentToJSCallback<T2>*/ arg2Marshaler, /*ArgumentToJSCallback<T3>*/ arg3Marshaler, /*ArgumentToManagedCallback<TResult>*/ resMarshaler)
                    {
                        super.$ctor();
                        {
                            this.JSObject = holder;
                            this.Arg1Marshaler = arg1Marshaler;
                            this.Arg2Marshaler = arg2Marshaler;
                            this.Arg3Marshaler = arg3Marshaler;
                            this.ResMarshaler = resMarshaler;
                        }
                        return this;
                    }
                    /*TResult */ InvokeJS(/*T1*/ arg1, /*T2*/ arg2, /*T3*/ arg3)
                    {
                        /*Span<JSMarshalerArgument>*/ let $arguments = $.$$.System.Runtime.CompilerServices.RuntimeHelpers.StackAllocSpan($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument, 5, null);
                        /*ref JSMarshalerArgument*/ let args_exception = $arguments.get_Item(0);
                        /*ref JSMarshalerArgument*/ let args_return = $arguments.get_Item(1);
                        /*ref JSMarshalerArgument*/ let args_arg1 = $arguments.get_Item(2);
                        /*ref JSMarshalerArgument*/ let args_arg2 = $arguments.get_Item(3);
                        /*ref JSMarshalerArgument*/ let args_arg3 = $arguments.get_Item(4);
                        args_exception.$v.Initialize();
                        args_return.$v.Initialize();
                        this.Arg1Marshaler.Invoke(args_arg1, arg1);
                        this.Arg2Marshaler.Invoke(args_arg2, arg2);
                        this.Arg3Marshaler.Invoke(args_arg3, arg3);
                        $.$srij.System.Runtime.InteropServices.JavaScript.JSFunctionBinding.InvokeJSFunction(this.JSObject, $arguments);
                        /*TResult*/ let res;
                        this.ResMarshaler.Invoke(args_return, $.$ref(() => res, ($v) => res = $v, TResult));
                        return res;
                    }
                    static $h = 1834614;
                    static $g = 4;
                    static $f = 0b10000000011010000;
                    static $k = 1;
                    static $$md;
                    static get $md() { return this.$$md ??= {"b":131073,"m":[{"r":TResult?.$h??1703936,"p":[{"n":"arg1","p":T1?.$h??1507328},{"n":"arg2","p":T2?.$h??1572864},{"n":"arg3","p":T3?.$h??1638400}],"n":"InvokeJS","d":this.$h,"h":Number(BigInt(this.$h)|0x700000000n),"f":16777217}],"l":[{"t":$.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument.ArgumentToJSCallback$$(T1).$h,"n":"Arg1Marshaler","d":this.$h,"h":Number(BigInt(this.$h)|0x100000000n),"f":4194306},{"t":$.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument.ArgumentToJSCallback$$(T2).$h,"n":"Arg2Marshaler","d":this.$h,"h":Number(BigInt(this.$h)|0x200000000n),"f":4194306},{"t":$.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument.ArgumentToJSCallback$$(T3).$h,"n":"Arg3Marshaler","d":this.$h,"h":Number(BigInt(this.$h)|0x300000000n),"f":4194306},{"t":$.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument.ArgumentToManagedCallback$$(TResult).$h,"n":"ResMarshaler","d":this.$h,"h":Number(BigInt(this.$h)|0x400000000n),"f":4194306},{"t":2293366,"n":"JSObject","d":this.$h,"h":Number(BigInt(this.$h)|0x500000000n),"f":4194306}],"c":[{"p":[{"n":"holder","p":2293366},{"n":"arg1Marshaler","p":$.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument.ArgumentToJSCallback$$(T1).$h},{"n":"arg2Marshaler","p":$.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument.ArgumentToJSCallback$$(T2).$h},{"n":"arg3Marshaler","p":$.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument.ArgumentToJSCallback$$(T3).$h},{"n":"resMarshaler","p":$.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument.ArgumentToManagedCallback$$(TResult).$h}],"n":".ctor","o":"$ctor$1","d":this.$h,"h":Number(BigInt(this.$h)|0x600000000n),"f":16777217}],"g":[T1?.$h??1507328,T2?.$h??1572864,T3?.$h??1638400,TResult?.$h??1703936],"r":4,"d":1375862,"h":this.$h}; }
                    static get $b() { return $.$$.System.Object; }
                    static get $fullName() { return `System.Runtime.InteropServices.JavaScript.JSMarshalerArgument.FuncJS<${T1?.$fullName},${T2?.$fullName},${T3?.$fullName},${TResult?.$fullName}>`; }
                }), $cls, ($v) => $cls.$_FuncJS$$$$$ = $v))(T1, T2, T3, TResult);
            }
            /*void */ ToManaged$48(TResult, /*out Func<TResult>?*/ value, /*ArgumentToManagedCallback<TResult>*/ resMarshaler)
            {
                if (this.slot.Type === 0/*MarshalerType.None*/)
                {
                    value.$v = null;
                    return;
                }
                /*var*/ let ctx = this.ToManagedContext;
                /*var*/ let holder = ctx.CreateCSOwnedProxy(this.slot.JSHandle);
                value.$v = new ($.$$.System.Func$$(TResult))().$ctor(new ($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument.FuncJS$$(TResult))().$ctor$1(holder, resMarshaler), new ($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument.FuncJS$$(TResult))().$ctor$1(holder, resMarshaler).InvokeJS);
            }
            /*void */ ToManaged$41(T, TResult, /*out Func<T, TResult>?*/ value, /*ArgumentToJSCallback<T>*/ arg1Marshaler, /*ArgumentToManagedCallback<TResult>*/ resMarshaler)
            {
                if (this.slot.Type === 0/*MarshalerType.None*/)
                {
                    value.$v = null;
                    return;
                }
                /*var*/ let ctx = this.ToManagedContext;
                /*var*/ let holder = ctx.CreateCSOwnedProxy(this.slot.JSHandle);
                value.$v = new ($.$$.System.Func$$$(T, TResult))().$ctor(new ($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument.FuncJS$$$(T, TResult))().$ctor$1(holder, arg1Marshaler, resMarshaler), new ($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument.FuncJS$$$(T, TResult))().$ctor$1(holder, arg1Marshaler, resMarshaler).InvokeJS);
            }
            /*void */ ToManaged$46(T1, T2, TResult, /*out Func<T1, T2, TResult>?*/ value, /*ArgumentToJSCallback<T1>*/ arg1Marshaler, /*ArgumentToJSCallback<T2>*/ arg2Marshaler, /*ArgumentToManagedCallback<TResult>*/ resMarshaler)
            {
                if (this.slot.Type === 0/*MarshalerType.None*/)
                {
                    value.$v = null;
                    return;
                }
                /*var*/ let ctx = this.ToManagedContext;
                /*var*/ let holder = ctx.CreateCSOwnedProxy(this.slot.JSHandle);
                value.$v = new ($.$$.System.Func$$$$(T1, T2, TResult))().$ctor(new ($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument.FuncJS$$$$(T1, T2, TResult))().$ctor$1(holder, arg1Marshaler, arg2Marshaler, resMarshaler), new ($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument.FuncJS$$$$(T1, T2, TResult))().$ctor$1(holder, arg1Marshaler, arg2Marshaler, resMarshaler).InvokeJS);
            }
            /*void */ ToManaged$44(T1, T2, T3, TResult, /*out Func<T1, T2, T3, TResult>?*/ value, /*ArgumentToJSCallback<T1>*/ arg1Marshaler, /*ArgumentToJSCallback<T2>*/ arg2Marshaler, /*ArgumentToJSCallback<T3>*/ arg3Marshaler, /*ArgumentToManagedCallback<TResult>*/ resMarshaler)
            {
                if (this.slot.Type === 0/*MarshalerType.None*/)
                {
                    value.$v = null;
                    return;
                }
                /*var*/ let ctx = this.ToManagedContext;
                /*var*/ let holder = ctx.CreateCSOwnedProxy(this.slot.JSHandle);
                value.$v = new ($.$$.System.Func$$$$$(T1, T2, T3, TResult))().$ctor(new ($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument.FuncJS$$$$$(T1, T2, T3, TResult))().$ctor$1(holder, arg1Marshaler, arg2Marshaler, arg3Marshaler, resMarshaler), new ($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument.FuncJS$$$$$(T1, T2, T3, TResult))().$ctor$1(holder, arg1Marshaler, arg2Marshaler, arg3Marshaler, resMarshaler).InvokeJS);
            }
            /*void */ ToJS(/*Action*/ value)
            {
                /*Action*/ let cpy = value;
                /*JSHostImplementation.ToManagedCallback*/ let cb = new $.$srij.System.Runtime.InteropServices.JavaScript.JSHostImplementation.ToManagedCallback().$ctor(this,  (/*JSMarshalerArgument**/ $arguments) =>
                {
                    cpy.Invoke();
                }, {"r":65537,"p":[{"n":"arguments","p":$.$typePointer($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument).$h}],"n":"","d":1375862,"h":0,"f":17825794});
                this.slot.Type = 25/*MarshalerType.Function*/;
                /*var*/ let ctx = this.ToJSContext;
                this.slot.GCHandle = ctx.GetJSOwnedObjectGCHandle(cb, 2);
            }
            /*void */ ToJS$42(T, /*Action<T>*/ value, /*ArgumentToManagedCallback<T>*/ arg1Marshaler)
            {
                /*Action<T>*/ let cpy = value;
                /*JSHostImplementation.ToManagedCallback*/ let cb = new $.$srij.System.Runtime.InteropServices.JavaScript.JSHostImplementation.ToManagedCallback().$ctor(this,  (/*JSMarshalerArgument**/ $arguments) =>
                {
                    /*ref JSMarshalerArgument*/ let arg2 = $arguments.Add(3);
                    /*T*/ let arg1cs;
                    arg1Marshaler.Invoke(arg2, $.$ref(() => arg1cs, ($v) => arg1cs = $v, T));
                    cpy.Invoke(arg1cs);
                }, {"r":65537,"p":[{"n":"arguments","p":$.$typePointer($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument).$h}],"n":"","d":1375862,"h":0,"f":17825794});
                this.slot.Type = 24/*MarshalerType.Action*/;
                /*var*/ let ctx = this.ToJSContext;
                this.slot.GCHandle = ctx.GetJSOwnedObjectGCHandle(cb, 2);
            }
            /*void */ ToJS$47(T1, T2, /*Action<T1, T2>*/ value, /*ArgumentToManagedCallback<T1>*/ arg1Marshaler, /*ArgumentToManagedCallback<T2>*/ arg2Marshaler)
            {
                /*Action<T1, T2>*/ let cpy = value;
                /*JSHostImplementation.ToManagedCallback*/ let cb = new $.$srij.System.Runtime.InteropServices.JavaScript.JSHostImplementation.ToManagedCallback().$ctor(this,  (/*JSMarshalerArgument**/ $arguments) =>
                {
                    /*ref JSMarshalerArgument*/ let arg2 = $arguments.Add(3);
                    /*ref JSMarshalerArgument*/ let arg3 = $arguments.Add(4);
                    /*T1*/ let arg1cs;
                    arg1Marshaler.Invoke(arg2, $.$ref(() => arg1cs, ($v) => arg1cs = $v, T1));
                    /*T2*/ let arg2cs;
                    arg2Marshaler.Invoke(arg3, $.$ref(() => arg2cs, ($v) => arg2cs = $v, T2));
                    cpy.Invoke(arg1cs, arg2cs);
                }, {"r":65537,"p":[{"n":"arguments","p":$.$typePointer($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument).$h}],"n":"","d":1375862,"h":0,"f":17825794});
                this.slot.Type = 24/*MarshalerType.Action*/;
                /*var*/ let ctx = this.ToJSContext;
                this.slot.GCHandle = ctx.GetJSOwnedObjectGCHandle(cb, 2);
            }
            /*void */ ToJS$45(T1, T2, T3, /*Action<T1, T2, T3>*/ value, /*ArgumentToManagedCallback<T1>*/ arg1Marshaler, /*ArgumentToManagedCallback<T2>*/ arg2Marshaler, /*ArgumentToManagedCallback<T3>*/ arg3Marshaler)
            {
                /*Action<T1, T2, T3>*/ let cpy = value;
                /*JSHostImplementation.ToManagedCallback*/ let cb = new $.$srij.System.Runtime.InteropServices.JavaScript.JSHostImplementation.ToManagedCallback().$ctor(this,  (/*JSMarshalerArgument**/ $arguments) =>
                {
                    /*ref JSMarshalerArgument*/ let arg2 = $arguments.Add(3);
                    /*ref JSMarshalerArgument*/ let arg3 = $arguments.Add(4);
                    /*ref JSMarshalerArgument*/ let arg4 = $arguments.Add(5);
                    /*T1*/ let arg1cs;
                    arg1Marshaler.Invoke(arg2, $.$ref(() => arg1cs, ($v) => arg1cs = $v, T1));
                    /*T2*/ let arg2cs;
                    arg2Marshaler.Invoke(arg3, $.$ref(() => arg2cs, ($v) => arg2cs = $v, T2));
                    /*T3*/ let arg3cs;
                    arg3Marshaler.Invoke(arg4, $.$ref(() => arg3cs, ($v) => arg3cs = $v, T3));
                    cpy.Invoke(arg1cs, arg2cs, arg3cs);
                }, {"r":65537,"p":[{"n":"arguments","p":$.$typePointer($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument).$h}],"n":"","d":1375862,"h":0,"f":17825794});
                this.slot.Type = 24/*MarshalerType.Action*/;
                /*var*/ let ctx = this.ToJSContext;
                this.slot.GCHandle = ctx.GetJSOwnedObjectGCHandle(cb, 2);
            }
            /*void */ ToJS$48(TResult, /*Func<TResult>*/ value, /*ArgumentToJSCallback<TResult>*/ resMarshaler)
            {
                /*Func<TResult>*/ let cpy = value;
                /*JSHostImplementation.ToManagedCallback*/ let cb = new $.$srij.System.Runtime.InteropServices.JavaScript.JSHostImplementation.ToManagedCallback().$ctor(this,  (/*JSMarshalerArgument**/ $arguments) =>
                {
                    /*ref JSMarshalerArgument*/ let res = $arguments.Add(1);
                    /*TResult*/ let resCs = cpy.Invoke();
                    resMarshaler.Invoke(res, resCs);
                }, {"r":65537,"p":[{"n":"arguments","p":$.$typePointer($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument).$h}],"n":"","d":1375862,"h":0,"f":17825794});
                this.slot.Type = 25/*MarshalerType.Function*/;
                /*var*/ let ctx = this.ToJSContext;
                this.slot.GCHandle = ctx.GetJSOwnedObjectGCHandle(cb, 2);
            }
            /*void */ ToJS$41(T, TResult, /*Func<T, TResult>*/ value, /*ArgumentToManagedCallback<T>*/ arg1Marshaler, /*ArgumentToJSCallback<TResult>*/ resMarshaler)
            {
                /*Func<T, TResult>*/ let cpy = value;
                /*JSHostImplementation.ToManagedCallback*/ let cb = new $.$srij.System.Runtime.InteropServices.JavaScript.JSHostImplementation.ToManagedCallback().$ctor(this,  (/*JSMarshalerArgument**/ $arguments) =>
                {
                    /*ref JSMarshalerArgument*/ let res = $arguments.Add(1);
                    /*ref JSMarshalerArgument*/ let arg2 = $arguments.Add(3);
                    /*T*/ let arg1cs;
                    arg1Marshaler.Invoke(arg2, $.$ref(() => arg1cs, ($v) => arg1cs = $v, T));
                    /*TResult*/ let resCs = cpy.Invoke(arg1cs);
                    resMarshaler.Invoke(res, resCs);
                }, {"r":65537,"p":[{"n":"arguments","p":$.$typePointer($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument).$h}],"n":"","d":1375862,"h":0,"f":17825794});
                this.slot.Type = 25/*MarshalerType.Function*/;
                /*var*/ let ctx = this.ToJSContext;
                this.slot.GCHandle = ctx.GetJSOwnedObjectGCHandle(cb, 2);
            }
            /*void */ ToJS$46(T1, T2, TResult, /*Func<T1, T2, TResult>*/ value, /*ArgumentToManagedCallback<T1>*/ arg1Marshaler, /*ArgumentToManagedCallback<T2>*/ arg2Marshaler, /*ArgumentToJSCallback<TResult>*/ resMarshaler)
            {
                /*Func<T1, T2, TResult>*/ let cpy = value;
                /*JSHostImplementation.ToManagedCallback*/ let cb = new $.$srij.System.Runtime.InteropServices.JavaScript.JSHostImplementation.ToManagedCallback().$ctor(this,  (/*JSMarshalerArgument**/ $arguments) =>
                {
                    /*ref JSMarshalerArgument*/ let res = $arguments.Add(1);
                    /*ref JSMarshalerArgument*/ let arg2 = $arguments.Add(3);
                    /*ref JSMarshalerArgument*/ let arg3 = $arguments.Add(4);
                    /*T1*/ let arg1cs;
                    arg1Marshaler.Invoke(arg2, $.$ref(() => arg1cs, ($v) => arg1cs = $v, T1));
                    /*T2*/ let arg2cs;
                    arg2Marshaler.Invoke(arg3, $.$ref(() => arg2cs, ($v) => arg2cs = $v, T2));
                    /*TResult*/ let resCs = cpy.Invoke(arg1cs, arg2cs);
                    resMarshaler.Invoke(res, resCs);
                }, {"r":65537,"p":[{"n":"arguments","p":$.$typePointer($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument).$h}],"n":"","d":1375862,"h":0,"f":17825794});
                this.slot.Type = 25/*MarshalerType.Function*/;
                /*var*/ let ctx = this.ToJSContext;
                this.slot.GCHandle = ctx.GetJSOwnedObjectGCHandle(cb, 2);
            }
            /*void */ ToJS$44(T1, T2, T3, TResult, /*Func<T1, T2, T3, TResult>*/ value, /*ArgumentToManagedCallback<T1>*/ arg1Marshaler, /*ArgumentToManagedCallback<T2>*/ arg2Marshaler, /*ArgumentToManagedCallback<T3>*/ arg3Marshaler, /*ArgumentToJSCallback<TResult>*/ resMarshaler)
            {
                /*Func<T1, T2, T3, TResult>*/ let cpy = value;
                /*JSHostImplementation.ToManagedCallback*/ let cb = new $.$srij.System.Runtime.InteropServices.JavaScript.JSHostImplementation.ToManagedCallback().$ctor(this,  (/*JSMarshalerArgument**/ $arguments) =>
                {
                    /*ref JSMarshalerArgument*/ let res = $arguments.Add(1);
                    /*ref JSMarshalerArgument*/ let arg2 = $arguments.Add(3);
                    /*ref JSMarshalerArgument*/ let arg3 = $arguments.Add(4);
                    /*ref JSMarshalerArgument*/ let arg4 = $arguments.Add(5);
                    /*T1*/ let arg1cs;
                    arg1Marshaler.Invoke(arg2, $.$ref(() => arg1cs, ($v) => arg1cs = $v, T1));
                    /*T2*/ let arg2cs;
                    arg2Marshaler.Invoke(arg3, $.$ref(() => arg2cs, ($v) => arg2cs = $v, T2));
                    /*T3*/ let arg3cs;
                    arg3Marshaler.Invoke(arg4, $.$ref(() => arg3cs, ($v) => arg3cs = $v, T3));
                    /*TResult*/ let resCs = cpy.Invoke(arg1cs, arg2cs, arg3cs);
                    resMarshaler.Invoke(res, resCs);
                }, {"r":65537,"p":[{"n":"arguments","p":$.$typePointer($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument).$h}],"n":"","d":1375862,"h":0,"f":17825794});
                this.slot.Type = 25/*MarshalerType.Function*/;
                /*var*/ let ctx = this.ToJSContext;
                this.slot.GCHandle = ctx.GetJSOwnedObjectGCHandle(cb, 2);
            }
            /*void */ ToManaged$31(/*out float*/ value)
            {
                if (this.slot.Type === 0/*MarshalerType.None*/)
                {
                    value.$v = 0;
                    return;
                }
                value.$v = this.slot.SingleValue;
            }
            /*void */ ToJS$31(/*float*/ value)
            {
                this.slot.Type = 11/*MarshalerType.Single*/;
                this.slot.SingleValue = value;
            }
            /*void */ ToManaged$28(/*out float?*/ value)
            {
                if (this.slot.Type === 0/*MarshalerType.None*/)
                {
                    value.$v = null;
                    return;
                }
                value.$v = this.slot.SingleValue;
            }
            /*void */ ToJS$28(/*float?*/ value)
            {
                if ($.$$.System.Nullable$$($.$$.System.Single).HasValue$get.call(value))
                {
                    this.slot.Type = 11/*MarshalerType.Single*/;
                    this.slot.SingleValue = $.$$.System.Nullable$$($.$$.System.Single).Value$get.call(value);
                }
                else 
                {
                    this.slot.Type = 0/*MarshalerType.None*/;
                }
            }
            /*void */ ToManaged$29(/*out object?*/ value)
            {
                if (this.slot.Type === 0/*MarshalerType.None*/)
                {
                    value.$v = null;
                }
                else if (this.slot.Type === 14/*MarshalerType.Object*/)
                {
                    value.$v = ($.$$.System.Runtime.InteropServices.GCHandle.op_Explicit$1(this.slot.GCHandle)).Target;
                }
                else if (this.slot.Type === 3/*MarshalerType.Boolean*/)
                {
                    /*bool*/ let v;
                    this.ToManaged$4($.$ref(() => v, ($v) => v = $v, $.$$.System.Boolean));
                    value.$v = $.$box(v, $.$$.System.Boolean);
                }
                else if (this.slot.Type === 10/*MarshalerType.Double*/)
                {
                    /*double*/ let v;
                    this.ToManaged$10($.$ref(() => v, ($v) => v = $v, $.$$.System.Double));
                    value.$v = $.$box(v, $.$$.System.Double);
                }
                else if (this.slot.Type === 13/*MarshalerType.JSObject*/)
                {
                    /*JSObject?*/ let val;
                    this.ToManaged$39($.$ref(() => val, ($v) => val = $v, $.$srij.System.Runtime.InteropServices.JavaScript.JSObject));
                    value.$v = val;
                }
                else if (this.slot.Type === 15/*MarshalerType.String*/)
                {
                    /*string?*/ let val;
                    this.ToManaged$35($.$ref(() => val, ($v) => val = $v, $.$$.System.String));
                    value.$v = val;
                }
                else if (this.slot.Type === 16/*MarshalerType.Exception*/)
                {
                    /*Exception?*/ let val;
                    this.ToManaged$12($.$ref(() => val, ($v) => val = $v, $.$$.System.Exception));
                    value.$v = val;
                }
                else if (this.slot.Type === 17/*MarshalerType.DateTime*/)
                {
                    /*DateTime?*/ let val;
                    this.ToManaged$21($.$ref(() => val, ($v) => val = $v, $.$typeNullable($.$$.System.DateTime)));
                    value.$v = val?.Clone() ?? null;
                }
                else if (this.slot.Type === 27/*MarshalerType.JSException*/)
                {
                    /*Exception?*/ let val;
                    this.ToManaged$12($.$ref(() => val, ($v) => val = $v, $.$$.System.Exception));
                    value.$v = val;
                }
                else if (this.slot.Type === 21/*MarshalerType.Array*/)
                {
                    if (this.slot.ElementType === 4/*MarshalerType.Byte*/)
                    {
                        /*byte[]?*/ let val;
                        this.ToManaged$6($.$ref(() => val, ($v) => val = $v, $.$typeArray($.$$.System.Byte)));
                        value.$v = val;
                    }
                    else if (this.slot.ElementType === 10/*MarshalerType.Double*/)
                    {
                        /*double[]?*/ let val;
                        this.ToManaged$11($.$ref(() => val, ($v) => val = $v, $.$typeArray($.$$.System.Double)));
                        value.$v = val;
                    }
                    else if (this.slot.ElementType === 7/*MarshalerType.Int32*/)
                    {
                        /*int[]?*/ let val;
                        this.ToManaged$15($.$ref(() => val, ($v) => val = $v, $.$typeArray($.$$.System.Int32)));
                        value.$v = val;
                    }
                    else if (this.slot.ElementType === 14/*MarshalerType.Object*/)
                    {
                        /*object?[]?*/ let val;
                        this.ToManaged$30($.$ref(() => val, ($v) => val = $v, $.$typeArray($.$$.System.Object)));
                        value.$v = val;
                    }
                    else 
                    {
                        throw new $.$$.System.NotSupportedException().$ctor$12($.$srij.System.SR.Format$6($.$srij.System.SR.ToManagedNotImplemented, $.$$.System.Enum.ToString.call(this.slot.ElementType) + "[]"));
                    }
                }
                else if (this.slot.Type === 20/*MarshalerType.Task*/ || this.slot.Type === 28/*MarshalerType.TaskResolved*/ || this.slot.Type === 29/*MarshalerType.TaskRejected*/)
                {
                    /*Task<object?>?*/ let val;
                    this.ToManaged$43($.$$.System.Object, $.$ref(() => val, ($v) => val = $v, $.$$.System.Threading.Tasks.Task$$($.$$.System.Object)), new ($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument.ArgumentToManagedCallback$$($.$$.System.Object))().$ctor($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument, /*static*/ (/*JSMarshalerArgument*/ arg, /*object?*/ value) =>
                    {
                        arg.$v.ToManaged$29(value);
                    }, {"r":65537,"p":[{"n":"arg","p":1375862,"f":4},{"n":"value","p":131073,"f":2}],"n":"","d":1375862,"h":0,"f":17825826}));
                    value.$v = val;
                }
                else 
                {
                    throw new $.$$.System.NotSupportedException().$ctor$12($.$srij.System.SR.Format$6($.$srij.System.SR.ToManagedNotImplemented, $.$box(this.slot.Type, $.$srij.System.Runtime.InteropServices.JavaScript.MarshalerType)));
                }
            }
            /*void */ ToJS$29(/*object?*/ value)
            {
                if (value === null)
                {
                    this.slot.Type = 0/*MarshalerType.None*/;
                    return;
                }
                /*Type*/ let type = $.$$.System.Object.GetType.call(value);
                let ut;
                if (type.IsPrimitive)
                {
                    if ($.$$.System.Type.op_Equality$1($.$$.System.Int64.$type, type))
                    {
                        throw new $.$$.System.NotSupportedException().$ctor$12($.$srij.System.SR.Format$6($.$srij.System.SR.ToJSNotImplemented, type.FullName));
                    }
                    else if ($.$$.System.Type.op_Equality$1($.$$.System.Int32.$type, type))
                    {
                        /*var*/ let v = $.$cast(value, $.$$.System.Int32);
                        this.ToJS$14(v);
                    }
                    else if ($.$$.System.Type.op_Equality$1($.$$.System.Int16.$type, type))
                    {
                        /*var*/ let v = $.$cast(value, $.$$.System.Int16);
                        this.ToJS$13(v);
                    }
                    else if ($.$$.System.Type.op_Equality$1($.$$.System.Byte.$type, type))
                    {
                        /*var*/ let v = $.$cast(value, $.$$.System.Byte);
                        this.ToJS$5(v);
                    }
                    else if ($.$$.System.Type.op_Equality$1($.$$.System.Char.$type, type))
                    {
                        /*var*/ let v = $.$cast(value, $.$$.System.Char);
                        this.ToJS$7(v);
                    }
                    else if ($.$$.System.Type.op_Equality$1($.$$.System.Boolean.$type, type))
                    {
                        /*var*/ let v = $.$cast(value, $.$$.System.Boolean);
                        this.ToJS$4(v);
                    }
                    else if ($.$$.System.Type.op_Equality$1($.$$.System.Double.$type, type))
                    {
                        /*var*/ let v = $.$cast(value, $.$$.System.Double);
                        this.ToJS$10(v);
                    }
                    else if ($.$$.System.Type.op_Equality$1($.$$.System.Single.$type, type))
                    {
                        /*var*/ let v = $.$cast(value, $.$$.System.Single);
                        this.ToJS$31(v);
                    }
                    else if ($.$$.System.Type.op_Equality$1($.$$.System.IntPtr.$type, type))
                    {
                        /*var*/ let v = $.$cast(value, $.$$.System.IntPtr);
                        this.ToJS$17(v);
                    }
                    else 
                    {
                        throw new $.$$.System.NotSupportedException().$ctor$12($.$srij.System.SR.Format$6($.$srij.System.SR.ToJSNotImplemented, type.FullName));
                    }
                }
                else if ($.$$.System.Type.op_Equality$1($.$$.System.String.$type, type))
                {
                    /*string?*/ let str = $.$as(value, $.$$.System.String);
                    this.ToJS$35(str);
                }
                else if ($.$$.System.Type.op_Equality$1($.$$.System.DateTimeOffset.$type, type))
                {
                    /*var*/ let v = $.$cast(value, $.$$.System.DateTimeOffset);
                    this.ToJS$9(v);
                }
                else if ($.$$.System.Type.op_Equality$1($.$$.System.DateTime.$type, type))
                {
                    /*var*/ let v = $.$cast(value, $.$$.System.DateTime);
                    this.ToJS$8(v);
                }
                else if ($.$is($.$$.System.Nullable.GetUnderlyingType(type), $.$$.System.Type, { set $v(v){ ut = v; } }) && $.$$.System.Type.op_Inequality$1(ut, null))
                {
                    if ($.$$.System.Type.op_Equality$1($.$$.System.Int64.$type, ut))
                    {
                        throw new $.$$.System.NotSupportedException().$ctor$12($.$srij.System.SR.Format$6($.$srij.System.SR.ToJSNotImplemented, type.FullName));
                    }
                    else if ($.$$.System.Type.op_Equality$1($.$$.System.Int32.$type, ut))
                    {
                        /*var*/ let nv = $.$as(value, $.$typeNullable($.$$.System.Int32));
                        this.ToJS$25(nv);
                    }
                    else if ($.$$.System.Type.op_Equality$1($.$$.System.Int16.$type, ut))
                    {
                        /*var*/ let nv = $.$as(value, $.$typeNullable($.$$.System.Int16));
                        this.ToJS$24(nv);
                    }
                    else if ($.$$.System.Type.op_Equality$1($.$$.System.Byte.$type, ut))
                    {
                        /*var*/ let nv = $.$as(value, $.$typeNullable($.$$.System.Byte));
                        this.ToJS$19(nv);
                    }
                    else if ($.$$.System.Type.op_Equality$1($.$$.System.Char.$type, ut))
                    {
                        /*var*/ let nv = $.$as(value, $.$typeNullable($.$$.System.Char));
                        this.ToJS$20(nv);
                    }
                    else if ($.$$.System.Type.op_Equality$1($.$$.System.Boolean.$type, ut))
                    {
                        /*var*/ let nv = $.$as(value, $.$typeNullable($.$$.System.Boolean));
                        this.ToJS$18(nv);
                    }
                    else if ($.$$.System.Type.op_Equality$1($.$$.System.Double.$type, ut))
                    {
                        /*var*/ let nv = $.$as(value, $.$typeNullable($.$$.System.Double));
                        this.ToJS$23(nv);
                    }
                    else if ($.$$.System.Type.op_Equality$1($.$$.System.Single.$type, ut))
                    {
                        /*var*/ let nv = $.$as(value, $.$typeNullable($.$$.System.Single));
                        this.ToJS$28(nv);
                    }
                    else if ($.$$.System.Type.op_Equality$1($.$$.System.IntPtr.$type, ut))
                    {
                        /*var*/ let nv = $.$as(value, $.$typeNullable($.$$.System.IntPtr));
                        this.ToJS$27(nv);
                    }
                    else if ($.$$.System.Type.op_Equality$1($.$$.System.DateTimeOffset.$type, ut))
                    {
                        /*var*/ let nv = $.$as(value, $.$typeNullable($.$$.System.DateTimeOffset));
                        this.ToJS$22(nv?.Clone() ?? null);
                    }
                    else if ($.$$.System.Type.op_Equality$1($.$$.System.DateTime.$type, ut))
                    {
                        /*var*/ let nv = $.$as(value, $.$typeNullable($.$$.System.DateTime));
                        this.ToJS$21(nv?.Clone() ?? null);
                    }
                    else 
                    {
                        throw new $.$$.System.NotSupportedException().$ctor$12($.$srij.System.SR.Format$6($.$srij.System.SR.ToJSNotImplemented, type.FullName));
                    }
                }
                else if ($.$srij.System.Runtime.InteropServices.JavaScript.JSObject.$type.IsAssignableFrom(type))
                {
                    /*JSObject?*/ let val = $.$as(value, $.$srij.System.Runtime.InteropServices.JavaScript.JSObject);
                    this.ToJS$39(val);
                }
                else if ($.$$.System.Exception.$type.IsAssignableFrom(type))
                {
                    /*Exception?*/ let val = $.$as(value, $.$$.System.Exception);
                    this.ToJS$12(val);
                }
                else if ($.$$.System.Type.op_Equality$1($.$$.System.Threading.Tasks.Task$$($.$$.System.Object).$type, type))
                {
                    /*Task<object>?*/ let val = $.$as(value, $.$$.System.Threading.Tasks.Task$$($.$$.System.Object));
                    this.ToJS$43($.$$.System.Object, val, new ($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument.ArgumentToJSCallback$$($.$$.System.Object))().$ctor(this,  (/*JSMarshalerArgument*/ arg, /*object*/ value) =>
                    {
                        /*object?*/ let valueRef = value;
                        arg.$v.ToJS$29(valueRef);
                    }, {"r":65537,"p":[{"n":"arg","p":1375862,"f":4},{"n":"value","p":131073}],"n":"","d":1375862,"h":0,"f":17825794}));
                }
                else if ($.$$.System.Threading.Tasks.Task.$type.IsAssignableFrom(type))
                {
                    /*Task?*/ let val = $.$as(value, $.$$.System.Threading.Tasks.Task);
                    this.ToJSDynamic(val);
                }
                else if ($.$$.System.Type.op_Equality$1($.$typeArray($.$$.System.Byte).$type, type))
                {
                    /*byte[]*/ let val = $.$cast(value, $.$typeArray($.$$.System.Byte));
                    this.ToJS$6(val);
                }
                else if ($.$$.System.Type.op_Equality$1($.$typeArray($.$$.System.Int32).$type, type))
                {
                    /*int[]*/ let val = $.$cast(value, $.$typeArray($.$$.System.Int32));
                    this.ToJS$15(val);
                }
                else if ($.$$.System.Type.op_Equality$1($.$typeArray($.$$.System.Double).$type, type))
                {
                    /*double[]*/ let val = $.$cast(value, $.$typeArray($.$$.System.Double));
                    this.ToJS$11(val);
                }
                else if ($.$$.System.Type.op_Equality$1($.$typeArray($.$$.System.String).$type, type))
                {
                    /*string[]*/ let val = $.$cast(value, $.$typeArray($.$$.System.String));
                    this.ToJS$36(val);
                }
                else if ($.$$.System.Type.op_Equality$1($.$typeArray($.$$.System.Object).$type, type))
                {
                    /*object[]*/ let val = $.$cast(value, $.$typeArray($.$$.System.Object));
                    this.ToJS$30(val);
                }
                else if (type.IsArray)
                {
                    throw new $.$$.System.NotSupportedException().$ctor$12($.$srij.System.SR.Format$6($.$srij.System.SR.ToJSNotImplemented, type.FullName));
                }
                else if ($.$$.System.MulticastDelegate.$type.IsAssignableFrom(type.BaseType))
                {
                    throw new $.$$.System.NotSupportedException().$ctor$12($.$srij.System.SR.Format$6($.$srij.System.SR.ToJSNotImplemented, type.FullName));
                }
                else if (type.IsGenericType && $.$$.System.Type.op_Equality$1(type.GetGenericTypeDefinition(), $.$$.System.ArraySegment$$().$type))
                {
                    throw new $.$$.System.NotSupportedException().$ctor$12($.$srij.System.SR.Format$6($.$srij.System.SR.ToJSNotImplemented, type.FullName));
                }
                else if (type.IsGenericType && $.$$.System.Type.op_Equality$1(type.GetGenericTypeDefinition(), $.$$.System.Span$$().$type))
                {
                    throw new $.$$.System.NotSupportedException().$ctor$12($.$srij.System.SR.Format$6($.$srij.System.SR.ToJSNotImplemented, type.FullName));
                }
                else 
                {
                    this.slot.Type = 14/*MarshalerType.Object*/;
                    /*var*/ let ctx = this.ToJSContext;
                    this.slot.GCHandle = ctx.GetJSOwnedObjectGCHandle(value, 2);
                }
            }
            /*void */ ToManaged$30(/*out object?[]?*/ value)
            {
                if (this.slot.Type === 0/*MarshalerType.None*/)
                {
                    value.$v = null;
                    return;
                }
                value.$v = $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$$.System.Object), null, [this.slot.Length], null);
                /*JSMarshalerArgument**/ let payload = $.$cast(this.slot.IntPtrValue, $.$typePointer($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument));
                for(/*int*/ let i = 0; i < this.slot.Length; i++)
                {
                    /*ref JSMarshalerArgument*/ let arg = payload.Add(i);
                    /*object?*/ let val;
                    arg.$v.ToManaged$29($.$ref(() => val, ($v) => val = $v, $.$$.System.Object));
                    $.$$.System.Array.$WriteT1.call(value.$v, val, i);
                }
                $.$srij.Interop.Runtime.DeregisterGCRoot(this.slot.IntPtrValue);
                $.$$.System.Runtime.InteropServices.Marshal.FreeHGlobal(this.slot.IntPtrValue);
            }
            /*void */ ToJS$30(/*object?[]*/ value)
            {
                if (value === null)
                {
                    this.slot.Type = 0/*MarshalerType.None*/;
                    return;
                }
                this.slot.Length = value.length;
                /*int*/ let bytes = ((value.length * $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument.$z) | 0);
                this.slot.Type = 21/*MarshalerType.Array*/;
                /*JSMarshalerArgument**/ let payload = $.$cast($.$$.System.Runtime.InteropServices.Marshal.AllocHGlobal(bytes), $.$typePointer($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument));
                $.$$.System.Runtime.CompilerServices.Unsafe.InitBlock(payload, 0, (bytes >>> 0));
                $.$srij.Interop.Runtime.RegisterGCRoot(payload, bytes, $.$$.System.IntPtr.Zero);
                for(/*int*/ let i = 0; i < this.slot.Length; i++)
                {
                    /*ref JSMarshalerArgument*/ let arg = payload.Add(i);
                    /*object?*/ let val = $.$$.System.Array.$ReadT1.call(value, i);
                    arg.$v.ToJS$29(val);
                    $.$$.System.Array.$WriteT1.call(value, val, i);
                }
                this.slot.ElementType = 14/*MarshalerType.Object*/;
                this.slot.IntPtrValue = $.$cast(payload, $.$$.System.IntPtr);
            }
            //default value type constructor
            $ctor$2()
            {
                return this;
            }
            Clone($copy)
            {
                let copy = $copy ?? new this.constructor();
                copy.slot = this.slot.Clone();
                return copy;
            }
            //default member initializer
            constructor()
            {
                super();
                this.slot = $.$default($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument.JSMarshalerArgumentImpl);
            }
            static $h = 1375862;
            static $z = 32;
            static $f = 0b1010000001;
            static $k = 2;
            static $$md;
            static get $md() { return this.$$md ??= {"b":196609,"p":[{"p":2358902,"g":{"r":0,"d":0,"h":21476212342,"f":50331656},"n":"ToManagedContext","d":1375862,"h":17181245046,"f":2097160},{"p":2358902,"g":{"r":0,"d":0,"h":30066146934,"f":50331656},"n":"ToJSContext","d":1375862,"h":25771179638,"f":2097160}],"m":[{"r":65537,"n":"Initialize","d":1375862,"h":12886277750,"f":16777217},{"r":2358902,"n":"AssertCurrentThreadContext","d":1375862,"h":34361114230,"f":16777224},{"r":65537,"p":[{"n":"value","p":917505,"f":2}],"n":"ToManagedBig","d":1375862,"h":38656081526,"f":16777217},{"r":65537,"p":[{"n":"value","p":917505}],"n":"ToJSBig","d":1375862,"h":42951048822,"f":16777217},{"r":65537,"p":[{"n":"value","p":$.$typeNullable($.$$.System.Int64).$h,"f":2}],"n":"ToManagedBig","o":"@$1","d":1375862,"h":47246016118,"f":16777217},{"r":65537,"p":[{"n":"value","p":$.$typeNullable($.$$.System.Int64).$h}],"n":"ToJSBig","o":"@$1","d":1375862,"h":51540983414,"f":16777217},{"r":65537,"p":[{"n":"value","p":458753,"f":2}],"n":"ToManaged","o":"@$7","d":1375862,"h":55835950710,"f":16777217},{"r":65537,"p":[{"n":"value","p":458753}],"n":"ToJS","o":"@$7","d":1375862,"h":60130918006,"f":16777217},{"r":65537,"p":[{"n":"value","p":$.$typeNullable($.$$.System.Char).$h,"f":2}],"n":"ToManaged","o":"@$20","d":1375862,"h":64425885302,"f":16777217},{"r":65537,"p":[{"n":"value","p":$.$typeNullable($.$$.System.Char).$h}],"n":"ToJS","o":"@$20","d":1375862,"h":68720852598,"f":16777217},{"r":65537,"p":[{"n":"value","p":917505,"f":2}],"n":"ToManaged","o":"@$16","d":1375862,"h":81605754486,"f":16777217},{"r":65537,"p":[{"n":"value","p":917505}],"n":"ToJS","o":"@$16","d":1375862,"h":85900721782,"f":16777217},{"r":65537,"p":[{"n":"value","p":$.$typeNullable($.$$.System.Int64).$h,"f":2}],"n":"ToManaged","o":"@$26","d":1375862,"h":90195689078,"f":16777217},{"r":65537,"p":[{"n":"value","p":$.$typeNullable($.$$.System.Int64).$h}],"n":"ToJS","o":"@$26","d":1375862,"h":94490656374,"f":16777217},{"r":65537,"p":[{"n":"value","p":524289,"f":2}],"n":"ToManaged","o":"@$13","d":1375862,"h":98785623670,"f":16777217},{"r":65537,"p":[{"n":"value","p":524289}],"n":"ToJS","o":"@$13","d":1375862,"h":103080590966,"f":16777217},{"r":65537,"p":[{"n":"value","p":$.$typeNullable($.$$.System.Int16).$h,"f":2}],"n":"ToManaged","o":"@$24","d":1375862,"h":107375558262,"f":16777217},{"r":65537,"p":[{"n":"value","p":$.$typeNullable($.$$.System.Int16).$h}],"n":"ToJS","o":"@$24","d":1375862,"h":111670525558,"f":16777217},{"r":65537,"p":[{"n":"value","p":393217,"f":2}],"n":"ToManaged","o":"@$5","d":1375862,"h":115965492854,"f":16777217},{"r":65537,"p":[{"n":"value","p":393217}],"n":"ToJS","o":"@$5","d":1375862,"h":120260460150,"f":16777217},{"r":65537,"p":[{"n":"value","p":$.$typeNullable($.$$.System.Byte).$h,"f":2}],"n":"ToManaged","o":"@$19","d":1375862,"h":124555427446,"f":16777217},{"r":65537,"p":[{"n":"value","p":$.$typeNullable($.$$.System.Byte).$h}],"n":"ToJS","o":"@$19","d":1375862,"h":128850394742,"f":16777217},{"r":65537,"p":[{"n":"value","p":$.$typeArray($.$$.System.Byte).$h,"f":2}],"n":"ToManaged","o":"@$6","d":1375862,"h":133145362038,"f":16777217},{"r":65537,"p":[{"n":"value","p":$.$typeArray($.$$.System.Byte).$h}],"n":"ToJS","o":"@$6","d":1375862,"h":137440329334,"f":16777217},{"r":65537,"p":[{"n":"value","p":$.$$.System.ArraySegment$$($.$$.System.Byte).$h,"f":2}],"n":"ToManaged","o":"@$1","d":1375862,"h":141735296630,"f":16777217},{"r":65537,"p":[{"n":"value","p":$.$$.System.ArraySegment$$($.$$.System.Byte).$h}],"n":"ToJS","o":"@$1","d":1375862,"h":146030263926,"f":16777217},{"r":65537,"p":[{"n":"value","p":$.$$.System.Span$$($.$$.System.Byte).$h,"f":2}],"n":"ToManaged","o":"@$32","d":1375862,"h":150325231222,"f":16777217},{"r":65537,"p":[{"n":"value","p":$.$$.System.Span$$($.$$.System.Byte).$h}],"n":"ToJS","o":"@$32","d":1375862,"h":154620198518,"f":16777217},{"r":65537,"p":[{"n":"value","p":262145,"f":2}],"n":"ToManaged","o":"@$4","d":1375862,"h":158915165814,"f":16777217},{"r":65537,"p":[{"n":"value","p":262145}],"n":"ToJS","o":"@$4","d":1375862,"h":163210133110,"f":16777217},{"r":65537,"p":[{"n":"value","p":$.$typeNullable($.$$.System.Boolean).$h,"f":2}],"n":"ToManaged","o":"@$18","d":1375862,"h":167505100406,"f":16777217},{"r":65537,"p":[{"n":"value","p":$.$typeNullable($.$$.System.Boolean).$h}],"n":"ToJS","o":"@$18","d":1375862,"h":171800067702,"f":16777217},{"r":65537,"p":[{"n":"value","p":34471937,"f":2}],"n":"ToManaged","o":"@$9","d":1375862,"h":176095034998,"f":16777217},{"r":65537,"p":[{"n":"value","p":34471937}],"n":"ToJS","o":"@$9","d":1375862,"h":180390002294,"f":16777217},{"r":65537,"p":[{"n":"value","p":$.$typeNullable($.$$.System.DateTimeOffset).$h,"f":2}],"n":"ToManaged","o":"@$22","d":1375862,"h":184684969590,"f":16777217},{"r":65537,"p":[{"n":"value","p":$.$typeNullable($.$$.System.DateTimeOffset).$h}],"n":"ToJS","o":"@$22","d":1375862,"h":188979936886,"f":16777217},{"r":65537,"p":[{"n":"value","p":34275329,"f":2}],"n":"ToManaged","o":"@$8","d":1375862,"h":193274904182,"f":16777217},{"r":65537,"p":[{"n":"value","p":34275329}],"n":"ToJS","o":"@$8","d":1375862,"h":197569871478,"f":16777217},{"r":65537,"p":[{"n":"value","p":$.$typeNullable($.$$.System.DateTime).$h,"f":2}],"n":"ToManaged","o":"@$21","d":1375862,"h":201864838774,"f":16777217},{"r":65537,"p":[{"n":"value","p":$.$typeNullable($.$$.System.DateTime).$h}],"n":"ToJS","o":"@$21","d":1375862,"h":206159806070,"f":16777217},{"r":65537,"p":[{"n":"value","p":786433,"f":2}],"n":"ToManaged","o":"@$17","d":1375862,"h":210454773366,"f":16777217},{"r":65537,"p":[{"n":"value","p":786433}],"n":"ToJS","o":"@$17","d":1375862,"h":214749740662,"f":16777217},{"r":65537,"p":[{"n":"value","p":$.$typeNullable($.$$.System.IntPtr).$h,"f":2}],"n":"ToManaged","o":"@$27","d":1375862,"h":219044707958,"f":16777217},{"r":65537,"p":[{"n":"value","p":$.$typeNullable($.$$.System.IntPtr).$h}],"n":"ToJS","o":"@$27","d":1375862,"h":223339675254,"f":16777217},{"r":65537,"p":[{"n":"value","p":$.$typePointer($.$$.System.Void).$h,"f":2}],"n":"ToManaged","o":"@$38","d":1375862,"h":227634642550,"f":16777217},{"r":65537,"p":[{"n":"value","p":$.$typePointer($.$$.System.Void).$h}],"n":"ToJS","o":"@$38","d":1375862,"h":231929609846,"f":16777217},{"r":65537,"p":[{"n":"value","p":655361,"f":2}],"n":"ToManaged","o":"@$14","d":1375862,"h":236224577142,"f":16777217},{"r":65537,"p":[{"n":"value","p":655361}],"n":"ToJS","o":"@$14","d":1375862,"h":240519544438,"f":16777217},{"r":65537,"p":[{"n":"value","p":$.$typeNullable($.$$.System.Int32).$h,"f":2}],"n":"ToManaged","o":"@$25","d":1375862,"h":244814511734,"f":16777217},{"r":65537,"p":[{"n":"value","p":$.$typeNullable($.$$.System.Int32).$h}],"n":"ToJS","o":"@$25","d":1375862,"h":249109479030,"f":16777217},{"r":65537,"p":[{"n":"value","p":$.$typeArray($.$$.System.Int32).$h,"f":2}],"n":"ToManaged","o":"@$15","d":1375862,"h":253404446326,"f":16777217},{"r":65537,"p":[{"n":"value","p":$.$typeArray($.$$.System.Int32).$h}],"n":"ToJS","o":"@$15","d":1375862,"h":257699413622,"f":16777217},{"r":65537,"p":[{"n":"value","p":$.$$.System.ArraySegment$$($.$$.System.Int32).$h,"f":2}],"n":"ToManaged","o":"@$3","d":1375862,"h":261994380918,"f":16777217},{"r":65537,"p":[{"n":"value","p":$.$$.System.ArraySegment$$($.$$.System.Int32).$h}],"n":"ToJS","o":"@$3","d":1375862,"h":266289348214,"f":16777217},{"r":65537,"p":[{"n":"value","p":$.$$.System.Span$$($.$$.System.Int32).$h,"f":2}],"n":"ToManaged","o":"@$34","d":1375862,"h":270584315510,"f":16777217},{"r":65537,"p":[{"n":"value","p":$.$$.System.Span$$($.$$.System.Int32).$h}],"n":"ToJS","o":"@$34","d":1375862,"h":274879282806,"f":16777217},{"r":65537,"p":[{"n":"value","p":1179649,"f":2}],"n":"ToManaged","o":"@$10","d":1375862,"h":279174250102,"f":16777217},{"r":65537,"p":[{"n":"value","p":1179649}],"n":"ToJS","o":"@$10","d":1375862,"h":283469217398,"f":16777217},{"r":65537,"p":[{"n":"value","p":$.$typeNullable($.$$.System.Double).$h,"f":2}],"n":"ToManaged","o":"@$23","d":1375862,"h":287764184694,"f":16777217},{"r":65537,"p":[{"n":"value","p":$.$typeNullable($.$$.System.Double).$h}],"n":"ToJS","o":"@$23","d":1375862,"h":292059151990,"f":16777217},{"r":65537,"p":[{"n":"value","p":$.$typeArray($.$$.System.Double).$h,"f":2}],"n":"ToManaged","o":"@$11","d":1375862,"h":296354119286,"f":16777217},{"r":65537,"p":[{"n":"value","p":$.$typeArray($.$$.System.Double).$h}],"n":"ToJS","o":"@$11","d":1375862,"h":300649086582,"f":16777217},{"r":65537,"p":[{"n":"value","p":$.$$.System.ArraySegment$$($.$$.System.Double).$h,"f":2}],"n":"ToManaged","o":"@$2","d":1375862,"h":304944053878,"f":16777217},{"r":65537,"p":[{"n":"value","p":$.$$.System.ArraySegment$$($.$$.System.Double).$h}],"n":"ToJS","o":"@$2","d":1375862,"h":309239021174,"f":16777217},{"r":65537,"p":[{"n":"value","p":$.$$.System.Span$$($.$$.System.Double).$h,"f":2}],"n":"ToManaged","o":"@$33","d":1375862,"h":313533988470,"f":16777217},{"r":65537,"p":[{"n":"value","p":$.$$.System.Span$$($.$$.System.Double).$h}],"n":"ToJS","o":"@$33","d":1375862,"h":317828955766,"f":16777217},{"r":65537,"p":[{"n":"value","p":1310721,"f":2}],"n":"ToManaged","o":"@$35","d":1375862,"h":322123923062,"f":16777217},{"r":65537,"p":[{"n":"value","p":1310721}],"n":"ToJS","o":"@$35","d":1375862,"h":326418890358,"f":16777217},{"r":65537,"p":[{"n":"value","p":$.$typeArray($.$$.System.String).$h,"f":2}],"n":"ToManaged","o":"@$36","d":1375862,"h":330713857654,"f":16777217},{"r":65537,"p":[{"n":"value","p":$.$typeArray($.$$.System.String).$h}],"n":"ToJS","o":"@$36","d":1375862,"h":335008824950,"f":16777217},{"r":65537,"p":[{"n":"value","p":2293366,"f":2}],"n":"ToManaged","o":"@$39","d":1375862,"h":339303792246,"f":16777217},{"r":65537,"p":[{"n":"value","p":2293366}],"n":"ToJS","o":"@$39","d":1375862,"h":343598759542,"f":16777217},{"r":65537,"p":[{"n":"value","p":$.$typeArray($.$srij.System.Runtime.InteropServices.JavaScript.JSObject).$h,"f":2}],"n":"ToManaged","o":"@$40","d":1375862,"h":347893726838,"f":16777217},{"r":65537,"p":[{"n":"value","p":$.$typeArray($.$srij.System.Runtime.InteropServices.JavaScript.JSObject).$h}],"n":"ToJS","o":"@$40","d":1375862,"h":352188694134,"f":16777217},{"r":65537,"p":[{"n":"value","p":47251457,"f":2}],"n":"ToManaged","o":"@$12","d":1375862,"h":356483661430,"f":16777217},{"r":65537,"p":[{"n":"value","p":47251457}],"n":"ToJS","o":"@$12","d":1375862,"h":360778628726,"f":16777217},{"r":65537,"p":[{"n":"value","p":133169153,"f":2}],"n":"ToManaged","o":"@$37","d":1375862,"h":373663530614,"f":16777217},{"r":65537,"p":[{"n":"value","p":(T) => $.$$.System.Threading.Tasks.Task$$(T).$h,"f":2},{"n":"marshaler","p":(T) => $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument.ArgumentToManagedCallback$$(T).$h}],"g":["T"],"n":"ToManaged","o":"@$43","d":1375862,"h":377958497910,"f":16908289},{"r":65537,"p":[{"n":"value","p":133169153}],"n":"ToJSDynamic","d":1375862,"h":382253465206,"f":16777224},{"r":65537,"p":[{"n":"value","p":133169153}],"n":"ToJS","o":"@$37","d":1375862,"h":386548432502,"f":16777217},{"r":65537,"p":[{"n":"value","p":(T) => $.$$.System.Threading.Tasks.Task$$(T).$h},{"n":"marshaler","p":(T) => $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument.ArgumentToJSCallback$$(T).$h}],"g":["T"],"n":"ToJS","o":"@$43","d":1375862,"h":390843399798,"f":16908289},{"r":262145,"p":[{"n":"_","p":2358902}],"n":"CanMarshalTaskResultOnSameCall","d":1375862,"h":395138367094,"f":16777218},{"r":65537,"p":[{"n":"holder","p":2293366},{"n":"ex","p":47251457}],"n":"RejectPromise","d":1375862,"h":403728301686,"f":16777250},{"r":65537,"p":[{"n":"holder","p":2293366}],"n":"ResolveVoidPromise","d":1375862,"h":408023268982,"f":16777250},{"r":65537,"p":[{"n":"holder","p":2293366},{"n":"value","p":(T) => T.$h},{"n":"marshaler","p":(T) => $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument.ArgumentToJSCallback$$(T).$h}],"g":["T"],"n":"ResolvePromise","d":1375862,"h":412318236278,"f":16908322},{"r":65537,"p":[{"n":"value","p":11730945,"f":2}],"n":"ToManaged","d":1375862,"h":433793072758,"f":16777217},{"r":65537,"p":[{"n":"value","p":(T) => $.$$.System.Action$$(T).$h,"f":2},{"n":"arg1Marshaler","p":(T) => $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument.ArgumentToJSCallback$$(T).$h}],"g":["T"],"n":"ToManaged","o":"@$42","d":1375862,"h":438088040054,"f":16908289},{"r":65537,"p":[{"n":"value","p":(T1, T2) => $.$$.System.Action$$$(T1, T2).$h,"f":2},{"n":"arg1Marshaler","p":(T1, T2) => $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument.ArgumentToJSCallback$$(T1).$h},{"n":"arg2Marshaler","p":(T1, T2) => $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument.ArgumentToJSCallback$$(T2).$h}],"g":["T1","T2"],"n":"ToManaged","o":"@$47","d":1375862,"h":442383007350,"f":16908289},{"r":65537,"p":[{"n":"value","p":(T1, T2, T3) => $.$$.System.Action$$$$(T1, T2, T3).$h,"f":2},{"n":"arg1Marshaler","p":(T1, T2, T3) => $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument.ArgumentToJSCallback$$(T1).$h},{"n":"arg2Marshaler","p":(T1, T2, T3) => $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument.ArgumentToJSCallback$$(T2).$h},{"n":"arg3Marshaler","p":(T1, T2, T3) => $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument.ArgumentToJSCallback$$(T3).$h}],"g":["T1","T2","T3"],"n":"ToManaged","o":"@$45","d":1375862,"h":446677974646,"f":16908289},{"r":65537,"p":[{"n":"value","p":(TResult) => $.$$.System.Func$$(TResult).$h,"f":2},{"n":"resMarshaler","p":(TResult) => $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument.ArgumentToManagedCallback$$(TResult).$h}],"g":["TResult"],"n":"ToManaged","o":"@$48","d":1375862,"h":468152811126,"f":16908289},{"r":65537,"p":[{"n":"value","p":(T, TResult) => $.$$.System.Func$$$(T, TResult).$h,"f":2},{"n":"arg1Marshaler","p":(T, TResult) => $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument.ArgumentToJSCallback$$(T).$h},{"n":"resMarshaler","p":(T, TResult) => $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument.ArgumentToManagedCallback$$(TResult).$h}],"g":["T","TResult"],"n":"ToManaged","o":"@$41","d":1375862,"h":472447778422,"f":16908289},{"r":65537,"p":[{"n":"value","p":(T1, T2, TResult) => $.$$.System.Func$$$$(T1, T2, TResult).$h,"f":2},{"n":"arg1Marshaler","p":(T1, T2, TResult) => $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument.ArgumentToJSCallback$$(T1).$h},{"n":"arg2Marshaler","p":(T1, T2, TResult) => $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument.ArgumentToJSCallback$$(T2).$h},{"n":"resMarshaler","p":(T1, T2, TResult) => $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument.ArgumentToManagedCallback$$(TResult).$h}],"g":["T1","T2","TResult"],"n":"ToManaged","o":"@$46","d":1375862,"h":476742745718,"f":16908289},{"r":65537,"p":[{"n":"value","p":(T1, T2, T3, TResult) => $.$$.System.Func$$$$$(T1, T2, T3, TResult).$h,"f":2},{"n":"arg1Marshaler","p":(T1, T2, T3, TResult) => $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument.ArgumentToJSCallback$$(T1).$h},{"n":"arg2Marshaler","p":(T1, T2, T3, TResult) => $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument.ArgumentToJSCallback$$(T2).$h},{"n":"arg3Marshaler","p":(T1, T2, T3, TResult) => $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument.ArgumentToJSCallback$$(T3).$h},{"n":"resMarshaler","p":(T1, T2, T3, TResult) => $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument.ArgumentToManagedCallback$$(TResult).$h}],"g":["T1","T2","T3","TResult"],"n":"ToManaged","o":"@$44","d":1375862,"h":481037713014,"f":16908289},{"r":65537,"p":[{"n":"value","p":11730945}],"n":"ToJS","d":1375862,"h":485332680310,"f":16777217},{"r":65537,"p":[{"n":"value","p":(T) => $.$$.System.Action$$(T).$h},{"n":"arg1Marshaler","p":(T) => $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument.ArgumentToManagedCallback$$(T).$h}],"g":["T"],"n":"ToJS","o":"@$42","d":1375862,"h":489627647606,"f":16908289},{"r":65537,"p":[{"n":"value","p":(T1, T2) => $.$$.System.Action$$$(T1, T2).$h},{"n":"arg1Marshaler","p":(T1, T2) => $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument.ArgumentToManagedCallback$$(T1).$h},{"n":"arg2Marshaler","p":(T1, T2) => $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument.ArgumentToManagedCallback$$(T2).$h}],"g":["T1","T2"],"n":"ToJS","o":"@$47","d":1375862,"h":493922614902,"f":16908289},{"r":65537,"p":[{"n":"value","p":(T1, T2, T3) => $.$$.System.Action$$$$(T1, T2, T3).$h},{"n":"arg1Marshaler","p":(T1, T2, T3) => $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument.ArgumentToManagedCallback$$(T1).$h},{"n":"arg2Marshaler","p":(T1, T2, T3) => $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument.ArgumentToManagedCallback$$(T2).$h},{"n":"arg3Marshaler","p":(T1, T2, T3) => $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument.ArgumentToManagedCallback$$(T3).$h}],"g":["T1","T2","T3"],"n":"ToJS","o":"@$45","d":1375862,"h":498217582198,"f":16908289},{"r":65537,"p":[{"n":"value","p":(TResult) => $.$$.System.Func$$(TResult).$h},{"n":"resMarshaler","p":(TResult) => $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument.ArgumentToJSCallback$$(TResult).$h}],"g":["TResult"],"n":"ToJS","o":"@$48","d":1375862,"h":502512549494,"f":16908289},{"r":65537,"p":[{"n":"value","p":(T, TResult) => $.$$.System.Func$$$(T, TResult).$h},{"n":"arg1Marshaler","p":(T, TResult) => $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument.ArgumentToManagedCallback$$(T).$h},{"n":"resMarshaler","p":(T, TResult) => $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument.ArgumentToJSCallback$$(TResult).$h}],"g":["T","TResult"],"n":"ToJS","o":"@$41","d":1375862,"h":506807516790,"f":16908289},{"r":65537,"p":[{"n":"value","p":(T1, T2, TResult) => $.$$.System.Func$$$$(T1, T2, TResult).$h},{"n":"arg1Marshaler","p":(T1, T2, TResult) => $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument.ArgumentToManagedCallback$$(T1).$h},{"n":"arg2Marshaler","p":(T1, T2, TResult) => $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument.ArgumentToManagedCallback$$(T2).$h},{"n":"resMarshaler","p":(T1, T2, TResult) => $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument.ArgumentToJSCallback$$(TResult).$h}],"g":["T1","T2","TResult"],"n":"ToJS","o":"@$46","d":1375862,"h":511102484086,"f":16908289},{"r":65537,"p":[{"n":"value","p":(T1, T2, T3, TResult) => $.$$.System.Func$$$$$(T1, T2, T3, TResult).$h},{"n":"arg1Marshaler","p":(T1, T2, T3, TResult) => $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument.ArgumentToManagedCallback$$(T1).$h},{"n":"arg2Marshaler","p":(T1, T2, T3, TResult) => $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument.ArgumentToManagedCallback$$(T2).$h},{"n":"arg3Marshaler","p":(T1, T2, T3, TResult) => $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument.ArgumentToManagedCallback$$(T3).$h},{"n":"resMarshaler","p":(T1, T2, T3, TResult) => $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument.ArgumentToJSCallback$$(TResult).$h}],"g":["T1","T2","T3","TResult"],"n":"ToJS","o":"@$44","d":1375862,"h":515397451382,"f":16908289},{"r":65537,"p":[{"n":"value","p":1114113,"f":2}],"n":"ToManaged","o":"@$31","d":1375862,"h":519692418678,"f":16777217},{"r":65537,"p":[{"n":"value","p":1114113}],"n":"ToJS","o":"@$31","d":1375862,"h":523987385974,"f":16777217},{"r":65537,"p":[{"n":"value","p":$.$typeNullable($.$$.System.Single).$h,"f":2}],"n":"ToManaged","o":"@$28","d":1375862,"h":528282353270,"f":16777217},{"r":65537,"p":[{"n":"value","p":$.$typeNullable($.$$.System.Single).$h}],"n":"ToJS","o":"@$28","d":1375862,"h":532577320566,"f":16777217},{"r":65537,"p":[{"n":"value","p":131073,"f":2}],"n":"ToManaged","o":"@$29","d":1375862,"h":536872287862,"f":16777217},{"r":65537,"p":[{"n":"value","p":131073}],"n":"ToJS","o":"@$29","d":1375862,"h":541167255158,"f":16777217},{"r":65537,"p":[{"n":"value","p":$.$typeArray($.$$.System.Object).$h,"f":2}],"n":"ToManaged","o":"@$30","d":1375862,"h":545462222454,"f":16777217},{"r":65537,"p":[{"n":"value","p":$.$typeArray($.$$.System.Object).$h}],"n":"ToJS","o":"@$30","d":1375862,"h":549757189750,"f":16777217}],"l":[{"t":2162294,"n":"slot","d":1375862,"h":4296343158,"f":4194312},{"t":917505,"n":"I52_MAX_VALUE","d":1375862,"h":73015819894,"f":4194338},{"t":917505,"n":"I52_MIN_VALUE","d":1375862,"h":77310787190,"f":4194338}],"c":[{"n":".ctor","o":"$ctor$2","d":1375862,"h":554052157046,"f":16777217}],"j":[2162294,1769078,1703542,2096758,1441398,1638006,1572470,1506934,2031222,1965686,1900150,1834614],"h":1375862,"a":[{"t":114819073,"c":4409786369,"a":[{"v":"browser","t":1310721}]},{"t":23527425,"c":8613462017,"a":[{"v":false,"t":262145}]},{"t":33292289,"c":4328259585,"a":[{"v":1,"t":33357825}]}]}; }
            static get $b() { return $.$$.System.ValueType; }
            static get $fullName() { return `System.Runtime.InteropServices.JavaScript.JSMarshalerArgument`; }
        });
        
        $asm.$cls("$srij.System.Runtime.InteropServices.JavaScript.JSImportAttribute", ($self) => class JSImportAttribute extends $.$$.System.Attribute
        {
            /*string*/ FunctionName = null;
            /*string?*/ ModuleName = null;
            $ctor$3(/*string*/ functionName)
            {
                super.$ctor$1();
                {
                    this.FunctionName = functionName;
                }
                return this;
            }
            $ctor$2(/*string*/ functionName, /*string*/ moduleName)
            {
                super.$ctor$1();
                {
                    this.FunctionName = functionName;
                    this.ModuleName = moduleName;
                }
                return this;
            }
            static $h = 1244790;
            static $f = 0b10010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":14614529,"p":[{"p":1310721,"g":{"r":0,"d":0,"h":12886146678,"f":50331649},"n":"FunctionName","d":1244790,"h":8591179382,"f":2097153},{"p":1310721,"g":{"r":0,"d":0,"h":25771048566,"f":50331649},"n":"ModuleName","d":1244790,"h":21476081270,"f":2097153}],"c":[{"p":[{"n":"functionName","p":1310721}],"n":".ctor","o":"$ctor$3","d":1244790,"h":30066015862,"f":16777217},{"p":[{"n":"functionName","p":1310721},{"n":"moduleName","p":1310721}],"n":".ctor","o":"$ctor$2","d":1244790,"h":34360983158,"f":16777217}],"h":1244790,"a":[{"t":14745601,"c":21489582081,"a":[{"v":64,"t":14680065}],"n":[{"n":"Inherited","v":false,"t":262145},{"n":"AllowMultiple","v":false,"t":262145}]},{"t":114819073,"c":4409786369,"a":[{"v":"browser","t":1310721}]}]}; }
            static get $b() { return $.$$.System.Attribute; }
            static get $fullName() { return `System.Runtime.InteropServices.JavaScript.JSImportAttribute`; }
        });
        
        $asm.$str("$srij.System.Runtime.InteropServices.JavaScript.MarshalerType", ($self) => class MarshalerType extends $.$$.System.Enum
        {
            static None = 0;
            static Void = 1;
            static Discard = 2;
            static Boolean = 3;
            static Byte = 4;
            static Char = 5;
            static Int16 = 6;
            static Int32 = 7;
            static Int52 = 8;
            static BigInt64 = 9;
            static Double = 10;
            static Single = 11;
            static IntPtr = 12;
            static JSObject = 13;
            static Object = 14;
            static String = 15;
            static Exception = 16;
            static DateTime = 17;
            static DateTimeOffset = 18;
            static Nullable = 19;
            static Task = 20;
            static Array = 21;
            static ArraySegment = 22;
            static Span = 23;
            static Action = 24;
            static Function = 25;
            static DiscardNoWait = 26;
            static JSException = 27;
            static TaskResolved = 28;
            static TaskRejected = 29;
            static TaskPreCreated = 30;
            static $map;
            static get Map()
            {
                return this.$map ??= 
                {
                    "None": 0n,
                    "Void": 1n,
                    "Discard": 2n,
                    "Boolean": 3n,
                    "Byte": 4n,
                    "Char": 5n,
                    "Int16": 6n,
                    "Int32": 7n,
                    "Int52": 8n,
                    "BigInt64": 9n,
                    "Double": 10n,
                    "Single": 11n,
                    "IntPtr": 12n,
                    "JSObject": 13n,
                    "Object": 14n,
                    "String": 15n,
                    "Exception": 16n,
                    "DateTime": 17n,
                    "DateTimeOffset": 18n,
                    "Nullable": 19n,
                    "Task": 20n,
                    "Array": 21n,
                    "ArraySegment": 22n,
                    "Span": 23n,
                    "Action": 24n,
                    "Function": 25n,
                    "DiscardNoWait": 26n,
                    "JSException": 27n,
                    "TaskResolved": 28n,
                    "TaskRejected": 29n,
                    "TaskPreCreated": 30n
                };
            }
            static $h = 3735158;
            static $z = 1;
            static $f = 0b100000011010001000;
            static $k = 4;
            static get $eut() { return $.$$.System.Byte; }
            static $$md;
            static get $md() { return this.$$md ??= {"b":1048577,"u":393217,"l":[{"t":3735158,"n":"None","d":3735158,"h":4298702454,"f":4194337},{"t":3735158,"n":"Void","d":3735158,"h":8593669750,"f":4194337},{"t":3735158,"n":"Discard","d":3735158,"h":12888637046,"f":4194337},{"t":3735158,"n":"Boolean","d":3735158,"h":17183604342,"f":4194337},{"t":3735158,"n":"Byte","d":3735158,"h":21478571638,"f":4194337},{"t":3735158,"n":"Char","d":3735158,"h":25773538934,"f":4194337},{"t":3735158,"n":"Int16","d":3735158,"h":30068506230,"f":4194337},{"t":3735158,"n":"Int32","d":3735158,"h":34363473526,"f":4194337},{"t":3735158,"n":"Int52","d":3735158,"h":38658440822,"f":4194337},{"t":3735158,"n":"BigInt64","d":3735158,"h":42953408118,"f":4194337},{"t":3735158,"n":"Double","d":3735158,"h":47248375414,"f":4194337},{"t":3735158,"n":"Single","d":3735158,"h":51543342710,"f":4194337},{"t":3735158,"n":"IntPtr","d":3735158,"h":55838310006,"f":4194337},{"t":3735158,"n":"JSObject","d":3735158,"h":60133277302,"f":4194337},{"t":3735158,"n":"Object","d":3735158,"h":64428244598,"f":4194337},{"t":3735158,"n":"String","d":3735158,"h":68723211894,"f":4194337},{"t":3735158,"n":"DateTime","d":3735158,"h":77313146486,"f":4194337},{"t":3735158,"n":"DateTimeOffset","d":3735158,"h":81608113782,"f":4194337},{"t":3735158,"n":"Nullable","d":3735158,"h":85903081078,"f":4194337},{"t":3735158,"n":"Task","d":3735158,"h":90198048374,"f":4194337},{"t":3735158,"n":"Array","d":3735158,"h":94493015670,"f":4194337},{"t":3735158,"n":"ArraySegment","d":3735158,"h":98787982966,"f":4194337},{"t":3735158,"n":"Span","d":3735158,"h":103082950262,"f":4194337},{"t":3735158,"n":"Action","d":3735158,"h":107377917558,"f":4194337},{"t":3735158,"n":"Function","d":3735158,"h":111672884854,"f":4194337},{"t":3735158,"n":"DiscardNoWait","d":3735158,"h":115967852150,"f":4194337},{"t":3735158,"n":"TaskResolved","d":3735158,"h":124557786742,"f":4194337},{"t":3735158,"n":"TaskRejected","d":3735158,"h":128852754038,"f":4194337},{"t":3735158,"n":"TaskPreCreated","d":3735158,"h":133147721334,"f":4194337}],"c":[{"n":".ctor","o":"$ctor$3","d":3735158,"h":137442688630,"f":16777217}],"i":[57278465,63832065,57737217,57409537],"h":3735158}; }
            static get $b() { return $.$$.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.System.IComparable, $.$$.System.ISpanFormattable, $.$$.System.IFormattable, $.$$.System.IConvertible ]; }
            static get $fullName() { return `System.Runtime.InteropServices.JavaScript.MarshalerType`; }
        });
        
        $asm.$cls("$srij.System.Runtime.InteropServices.JavaScript.JSException", ($self) => class JSException extends $.$$.System.Exception
        {
            /*JSObject?*/ jsException = null;
            /*string?*/ combinedStackTrace = null;
            $ctor$6(/*string*/ msg)
            {
                super.$ctor$4(msg);
                {
                    this.jsException = null;
                    this.combinedStackTrace = null;
                }
                return this;
            }
            $ctor$5(/*string*/ msg, /*JSObject?*/ jsException)
            {
                super.$ctor$4(msg);
                {
                    this.jsException = jsException;
                    this.combinedStackTrace = null;
                }
                return this;
            }
            /*string? */ get StackTrace()
            {
                if ($.$$.System.String.op_Inequality(this.combinedStackTrace, null))
                {
                    return this.combinedStackTrace;
                }
                /*var*/ let bs = super.StackTrace;
                if (this.jsException === null)
                {
                    return bs;
                }
                /*string?*/ let jsStackTrace = this.jsException.GetPropertyAsString("stack");
                this.jsException.Dispose();
                this.jsException = null;
                if ($.$$.System.String.op_Equality(jsStackTrace, null))
                {
                    this.combinedStackTrace = bs;
                    return this.combinedStackTrace;
                }
                else if ($.$$.System.String.StartsWith$3.call(jsStackTrace, this.Message + "\n"))
                {
                    jsStackTrace = $.$$.System.String.Substring$1.call(jsStackTrace, ((this.Message.length + 1) | 0));
                }
                if ($.$$.System.String.op_Equality(bs, null))
                {
                    this.combinedStackTrace = jsStackTrace;
                }
                this.combinedStackTrace = $.$$.System.String.op_Inequality(bs, null) ? bs + $.$$.System.Environment.NewLine + jsStackTrace : jsStackTrace;
                return this.combinedStackTrace;
            }
            static/*conventional*/ /*bool */ Equals$1(/*object?*/ obj)
            {
                let other;
                return $.$is(obj, $.$srij.System.Runtime.InteropServices.JavaScript.JSException, { set $v(v){ other = v; } }) && other.jsException === this.jsException;
            }
            //Static convention instance redirect
            /*bool */ Equals$1() { return $.$srij.System.Runtime.InteropServices.JavaScript.JSException.Equals$1.apply(this, arguments); }
            static/*conventional*/ /*int */ GetHashCode()
            {
                return this.jsException === null ? $.$$.System.Object.GetHashCode.call(this) : (($.$$.System.Object.GetHashCode.call(this) * $.$srij.System.Runtime.InteropServices.JavaScript.JSObject.GetHashCode.call(this.jsException)) | 0);
            }
            //Static convention instance redirect
            /*int */ GetHashCode() { return $.$srij.System.Runtime.InteropServices.JavaScript.JSException.GetHashCode.apply(this, arguments); }
            static/*conventional*/ /*string */ ToString()
            {
                return this.Message;
            }
            //Static convention instance redirect
            /*string */ ToString() { return $.$srij.System.Runtime.InteropServices.JavaScript.JSException.ToString.apply(this, arguments); }
            static $h = 458358;
            static $f = 0b10010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":47251457,"h":458358}; }
            static get $b() { return $.$$.System.Exception; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.System.Runtime.Serialization.ISerializable ]; }
            static get $fullName() { return `System.Runtime.InteropServices.JavaScript.JSException`; }
        });
	});
})(window, window.NetJs.$boot(), ...window.NetJs.$require("NetJs.System.Private.CoreLib", "NetJs.System.Collections", "NetJs.System.Diagnostics.Tracing", "NetJs.System.Threading", "NetJs.System.Collections.Concurrent", "NetJs.System.Memory", "NetJs.System.Private.Uri", "NetJs.System.Runtime", "NetJs.System.Threading.ThreadPool", "NetJs.System.Threading.Channels"))