
//--TRIMMABLE-BOUNDARY-START(11)
(function ($global, $, $$, $sc, $sdt, $st, $scc, $sm, $spu, $sr, $sttp, $stc) {
    "use strict";
    let _;
    
    
    
	$.$asm(
    "NetJs.System.Runtime.InteropServices.JavaScript", 
    {
  "h": 11,
  "f": "System.Runtime.InteropServices.JavaScript",
  "v": "1.0.35.0",
  "a": [
    {
      "t": 159055873,
      "c": 4454023169,
      "a": [
        {
          "v": "browser",
          "t": 1310721
        }
      ]
    },
    {
      "t": 159252481,
      "c": 13044154369,
      "a": [
        {
          "v": ".NETCoreApp,Version=v10.0",
          "t": 1310721
        }
      ],
      "n": [
        {
          "n": "FrameworkDisplayName",
          "v": ".NET 10.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 106430465,
      "c": 8696365057,
      "a": [
        {
          "v": "SIT",
          "t": 1310721
        }
      ]
    },
    {
      "t": 106496001,
      "c": 8696430593,
      "a": [
        {
          "v": "Debug",
          "t": 1310721
        }
      ]
    },
    {
      "t": 106954753,
      "c": 8696889345,
      "a": [
        {
          "v": "1.0.35.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107085825,
      "c": 8697020417,
      "a": [
        {
          "v": "1.0.35\u002Bdf6f45b09d58f65c84d384efc8772929a0c6464b",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107937793,
      "c": 8697872385,
      "a": [
        {
          "v": "NetJs.System.Runtime.InteropServices.JavaScript",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108068865,
      "c": 8698003457,
      "a": [
        {
          "v": "NetJs.System.Runtime.InteropServices.JavaScript",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108199937,
      "c": 8698134529,
      "a": [
        {
          "v": "1.0.35.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 159318017,
      "c": 4454285313,
      "a": [
        {
          "v": "browser1.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 159055873,
      "c": 4454023169,
      "a": [
        {
          "v": "browser1.0",
          "t": 1310721
        }
      ]
    }
  ],
  "m": []
},
    function($asm)
	{
        
        
        //--TRIMMABLE-BOUNDARY-START(2359307)
        $asm.$cls("$srij.System.Runtime.InteropServices.JavaScript.JSType", ($self) => class JSType extends $.$$.System.Object
        {
            //--TRIMMABLE-BOUNDARY-START(85901705227)
            $ctor$1()
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(85901705227);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(85901705227)
            
            //--TRIMMABLE-BOUNDARY-START(3604491)
            static $_Void;
            static get Void()
            {
                let $cls = $.$srij.System.Runtime.InteropServices.JavaScript.JSType;
                return $cls.$_Void ??= $asm.$ncls("$srij.System.Runtime.InteropServices.JavaScript.JSType.Void", ($self) => class Void extends $.$srij.System.Runtime.InteropServices.JavaScript.JSType
                {
                    //--TRIMMABLE-BOUNDARY-START(4298571787)
                    $ctor$2()
                    {
                        super.$ctor$1();
                        {
                            //--TRIMMABLE-BOUNDARY-START(TRACE)
                            $.$trace(4298571787);
                            //--TRIMMABLE-BOUNDARY-END(TRACE)
                        }
                        return this;
                    }
                    //--TRIMMABLE-BOUNDARY-END(4298571787)
                    
                    static $h = 3604491;
                    static $f = 0b10000000010010001;
                    static $k = 1;
                    static $$md;
                    static get $md() { return this.$$md ??= {
  "b": 2359307,
  "c": [
//--TRIMMABLE-BOUNDARY-START(4298571787),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 3604491,
      "h": 4298571787,
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(4298571787)
  ],
  "d": 2359307,
  "h": 3604491
}; }
                    static get $b() { return $.$srij.System.Runtime.InteropServices.JavaScript.JSType; }
                    static get $fullName() { return `System.Runtime.InteropServices.JavaScript.JSType.Void`; }
                }, $cls, ($v) => $cls.$_Void = $v);
            }
            //--TRIMMABLE-BOUNDARY-END(3604491)
            
            //--TRIMMABLE-BOUNDARY-START(2752523)
            static $_Discard;
            static get Discard()
            {
                let $cls = $.$srij.System.Runtime.InteropServices.JavaScript.JSType;
                return $cls.$_Discard ??= $asm.$ncls("$srij.System.Runtime.InteropServices.JavaScript.JSType.Discard", ($self) => class Discard extends $.$srij.System.Runtime.InteropServices.JavaScript.JSType
                {
                    //--TRIMMABLE-BOUNDARY-START(4297719819)
                    $ctor$2()
                    {
                        super.$ctor$1();
                        {
                            //--TRIMMABLE-BOUNDARY-START(TRACE)
                            $.$trace(4297719819);
                            //--TRIMMABLE-BOUNDARY-END(TRACE)
                        }
                        return this;
                    }
                    //--TRIMMABLE-BOUNDARY-END(4297719819)
                    
                    static $h = 2752523;
                    static $f = 0b10000000010010001;
                    static $k = 1;
                    static $$md;
                    static get $md() { return this.$$md ??= {
  "b": 2359307,
  "c": [
//--TRIMMABLE-BOUNDARY-START(4297719819),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 2752523,
      "h": 4297719819,
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(4297719819)
  ],
  "d": 2359307,
  "h": 2752523
}; }
                    static get $b() { return $.$srij.System.Runtime.InteropServices.JavaScript.JSType; }
                    static get $fullName() { return `System.Runtime.InteropServices.JavaScript.JSType.Discard`; }
                }, $cls, ($v) => $cls.$_Discard = $v);
            }
            //--TRIMMABLE-BOUNDARY-END(2752523)
            
            //--TRIMMABLE-BOUNDARY-START(2818059)
            static $_DiscardNoWait;
            static get DiscardNoWait()
            {
                let $cls = $.$srij.System.Runtime.InteropServices.JavaScript.JSType;
                return $cls.$_DiscardNoWait ??= $asm.$ncls("$srij.System.Runtime.InteropServices.JavaScript.JSType.DiscardNoWait", ($self) => class DiscardNoWait extends $.$srij.System.Runtime.InteropServices.JavaScript.JSType
                {
                    //--TRIMMABLE-BOUNDARY-START(4297785355)
                    $ctor$2()
                    {
                        super.$ctor$1();
                        {
                            //--TRIMMABLE-BOUNDARY-START(TRACE)
                            $.$trace(4297785355);
                            //--TRIMMABLE-BOUNDARY-END(TRACE)
                        }
                        return this;
                    }
                    //--TRIMMABLE-BOUNDARY-END(4297785355)
                    
                    static $h = 2818059;
                    static $f = 0b10000000010010001;
                    static $k = 1;
                    static $$md;
                    static get $md() { return this.$$md ??= {
  "b": 2359307,
  "c": [
//--TRIMMABLE-BOUNDARY-START(4297785355),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 2818059,
      "h": 4297785355,
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(4297785355)
  ],
  "d": 2359307,
  "h": 2818059
}; }
                    static get $b() { return $.$srij.System.Runtime.InteropServices.JavaScript.JSType; }
                    static get $fullName() { return `System.Runtime.InteropServices.JavaScript.JSType.DiscardNoWait`; }
                }, $cls, ($v) => $cls.$_DiscardNoWait = $v);
            }
            //--TRIMMABLE-BOUNDARY-END(2818059)
            
            //--TRIMMABLE-BOUNDARY-START(2621451)
            static $_Boolean;
            static get Boolean()
            {
                let $cls = $.$srij.System.Runtime.InteropServices.JavaScript.JSType;
                return $cls.$_Boolean ??= $asm.$ncls("$srij.System.Runtime.InteropServices.JavaScript.JSType.Boolean", ($self) => class Boolean extends $.$srij.System.Runtime.InteropServices.JavaScript.JSType
                {
                    //--TRIMMABLE-BOUNDARY-START(4297588747)
                    $ctor$2()
                    {
                        super.$ctor$1();
                        {
                            //--TRIMMABLE-BOUNDARY-START(TRACE)
                            $.$trace(4297588747);
                            //--TRIMMABLE-BOUNDARY-END(TRACE)
                        }
                        return this;
                    }
                    //--TRIMMABLE-BOUNDARY-END(4297588747)
                    
                    static $h = 2621451;
                    static $f = 0b10000000010010001;
                    static $k = 1;
                    static $$md;
                    static get $md() { return this.$$md ??= {
  "b": 2359307,
  "c": [
//--TRIMMABLE-BOUNDARY-START(4297588747),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 2621451,
      "h": 4297588747,
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(4297588747)
  ],
  "d": 2359307,
  "h": 2621451
}; }
                    static get $b() { return $.$srij.System.Runtime.InteropServices.JavaScript.JSType; }
                    static get $fullName() { return `System.Runtime.InteropServices.JavaScript.JSType.Boolean`; }
                }, $cls, ($v) => $cls.$_Boolean = $v);
            }
            //--TRIMMABLE-BOUNDARY-END(2621451)
            
            //--TRIMMABLE-BOUNDARY-START(3342347)
            static $_Number;
            static get Number()
            {
                let $cls = $.$srij.System.Runtime.InteropServices.JavaScript.JSType;
                return $cls.$_Number ??= $asm.$ncls("$srij.System.Runtime.InteropServices.JavaScript.JSType.Number", ($self) => class Number extends $.$srij.System.Runtime.InteropServices.JavaScript.JSType
                {
                    //--TRIMMABLE-BOUNDARY-START(4298309643)
                    $ctor$2()
                    {
                        super.$ctor$1();
                        {
                            //--TRIMMABLE-BOUNDARY-START(TRACE)
                            $.$trace(4298309643);
                            //--TRIMMABLE-BOUNDARY-END(TRACE)
                        }
                        return this;
                    }
                    //--TRIMMABLE-BOUNDARY-END(4298309643)
                    
                    static $h = 3342347;
                    static $f = 0b10000000010010001;
                    static $k = 1;
                    static $$md;
                    static get $md() { return this.$$md ??= {
  "b": 2359307,
  "c": [
//--TRIMMABLE-BOUNDARY-START(4298309643),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 3342347,
      "h": 4298309643,
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(4298309643)
  ],
  "d": 2359307,
  "h": 3342347
}; }
                    static get $b() { return $.$srij.System.Runtime.InteropServices.JavaScript.JSType; }
                    static get $fullName() { return `System.Runtime.InteropServices.JavaScript.JSType.Number`; }
                }, $cls, ($v) => $cls.$_Number = $v);
            }
            //--TRIMMABLE-BOUNDARY-END(3342347)
            
            //--TRIMMABLE-BOUNDARY-START(2555915)
            static $_BigInt;
            static get BigInt()
            {
                let $cls = $.$srij.System.Runtime.InteropServices.JavaScript.JSType;
                return $cls.$_BigInt ??= $asm.$ncls("$srij.System.Runtime.InteropServices.JavaScript.JSType.BigInt", ($self) => class BigInt extends $.$srij.System.Runtime.InteropServices.JavaScript.JSType
                {
                    //--TRIMMABLE-BOUNDARY-START(4297523211)
                    $ctor$2()
                    {
                        super.$ctor$1();
                        {
                            //--TRIMMABLE-BOUNDARY-START(TRACE)
                            $.$trace(4297523211);
                            //--TRIMMABLE-BOUNDARY-END(TRACE)
                        }
                        return this;
                    }
                    //--TRIMMABLE-BOUNDARY-END(4297523211)
                    
                    static $h = 2555915;
                    static $f = 0b10000000010010001;
                    static $k = 1;
                    static $$md;
                    static get $md() { return this.$$md ??= {
  "b": 2359307,
  "c": [
//--TRIMMABLE-BOUNDARY-START(4297523211),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 2555915,
      "h": 4297523211,
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(4297523211)
  ],
  "d": 2359307,
  "h": 2555915
}; }
                    static get $b() { return $.$srij.System.Runtime.InteropServices.JavaScript.JSType; }
                    static get $fullName() { return `System.Runtime.InteropServices.JavaScript.JSType.BigInt`; }
                }, $cls, ($v) => $cls.$_BigInt = $v);
            }
            //--TRIMMABLE-BOUNDARY-END(2555915)
            
            //--TRIMMABLE-BOUNDARY-START(2686987)
            static $_Date;
            static get Date()
            {
                let $cls = $.$srij.System.Runtime.InteropServices.JavaScript.JSType;
                return $cls.$_Date ??= $asm.$ncls("$srij.System.Runtime.InteropServices.JavaScript.JSType.Date", ($self) => class Date extends $.$srij.System.Runtime.InteropServices.JavaScript.JSType
                {
                    //--TRIMMABLE-BOUNDARY-START(4297654283)
                    $ctor$2()
                    {
                        super.$ctor$1();
                        {
                            //--TRIMMABLE-BOUNDARY-START(TRACE)
                            $.$trace(4297654283);
                            //--TRIMMABLE-BOUNDARY-END(TRACE)
                        }
                        return this;
                    }
                    //--TRIMMABLE-BOUNDARY-END(4297654283)
                    
                    static $h = 2686987;
                    static $f = 0b10000000010010001;
                    static $k = 1;
                    static $$md;
                    static get $md() { return this.$$md ??= {
  "b": 2359307,
  "c": [
//--TRIMMABLE-BOUNDARY-START(4297654283),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 2686987,
      "h": 4297654283,
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(4297654283)
  ],
  "d": 2359307,
  "h": 2686987
}; }
                    static get $b() { return $.$srij.System.Runtime.InteropServices.JavaScript.JSType; }
                    static get $fullName() { return `System.Runtime.InteropServices.JavaScript.JSType.Date`; }
                }, $cls, ($v) => $cls.$_Date = $v);
            }
            //--TRIMMABLE-BOUNDARY-END(2686987)
            
            //--TRIMMABLE-BOUNDARY-START(3538955)
            static $_String;
            static get String()
            {
                let $cls = $.$srij.System.Runtime.InteropServices.JavaScript.JSType;
                return $cls.$_String ??= $asm.$ncls("$srij.System.Runtime.InteropServices.JavaScript.JSType.String", ($self) => class String extends $.$srij.System.Runtime.InteropServices.JavaScript.JSType
                {
                    //--TRIMMABLE-BOUNDARY-START(4298506251)
                    $ctor$2()
                    {
                        super.$ctor$1();
                        {
                            //--TRIMMABLE-BOUNDARY-START(TRACE)
                            $.$trace(4298506251);
                            //--TRIMMABLE-BOUNDARY-END(TRACE)
                        }
                        return this;
                    }
                    //--TRIMMABLE-BOUNDARY-END(4298506251)
                    
                    static $h = 3538955;
                    static $f = 0b10000000010010001;
                    static $k = 1;
                    static $$md;
                    static get $md() { return this.$$md ??= {
  "b": 2359307,
  "c": [
//--TRIMMABLE-BOUNDARY-START(4298506251),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 3538955,
      "h": 4298506251,
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(4298506251)
  ],
  "d": 2359307,
  "h": 3538955
}; }
                    static get $b() { return $.$srij.System.Runtime.InteropServices.JavaScript.JSType; }
                    static get $fullName() { return `System.Runtime.InteropServices.JavaScript.JSType.String`; }
                }, $cls, ($v) => $cls.$_String = $v);
            }
            //--TRIMMABLE-BOUNDARY-END(3538955)
            
            //--TRIMMABLE-BOUNDARY-START(3407883)
            static $_Object;
            static get Object()
            {
                let $cls = $.$srij.System.Runtime.InteropServices.JavaScript.JSType;
                return $cls.$_Object ??= $asm.$ncls("$srij.System.Runtime.InteropServices.JavaScript.JSType.Object", ($self) => class Object extends $.$srij.System.Runtime.InteropServices.JavaScript.JSType
                {
                    //--TRIMMABLE-BOUNDARY-START(4298375179)
                    $ctor$2()
                    {
                        super.$ctor$1();
                        {
                            //--TRIMMABLE-BOUNDARY-START(TRACE)
                            $.$trace(4298375179);
                            //--TRIMMABLE-BOUNDARY-END(TRACE)
                        }
                        return this;
                    }
                    //--TRIMMABLE-BOUNDARY-END(4298375179)
                    
                    static $h = 3407883;
                    static $f = 0b10000000010010001;
                    static $k = 1;
                    static $$md;
                    static get $md() { return this.$$md ??= {
  "b": 2359307,
  "c": [
//--TRIMMABLE-BOUNDARY-START(4298375179),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 3407883,
      "h": 4298375179,
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(4298375179)
  ],
  "d": 2359307,
  "h": 3407883
}; }
                    static get $b() { return $.$srij.System.Runtime.InteropServices.JavaScript.JSType; }
                    static get $fullName() { return `System.Runtime.InteropServices.JavaScript.JSType.Object`; }
                }, $cls, ($v) => $cls.$_Object = $v);
            }
            //--TRIMMABLE-BOUNDARY-END(3407883)
            
            //--TRIMMABLE-BOUNDARY-START(2883595)
            static $_Error;
            static get Error()
            {
                let $cls = $.$srij.System.Runtime.InteropServices.JavaScript.JSType;
                return $cls.$_Error ??= $asm.$ncls("$srij.System.Runtime.InteropServices.JavaScript.JSType.Error", ($self) => class Error extends $.$srij.System.Runtime.InteropServices.JavaScript.JSType
                {
                    //--TRIMMABLE-BOUNDARY-START(4297850891)
                    $ctor$2()
                    {
                        super.$ctor$1();
                        {
                            //--TRIMMABLE-BOUNDARY-START(TRACE)
                            $.$trace(4297850891);
                            //--TRIMMABLE-BOUNDARY-END(TRACE)
                        }
                        return this;
                    }
                    //--TRIMMABLE-BOUNDARY-END(4297850891)
                    
                    static $h = 2883595;
                    static $f = 0b10000000010010001;
                    static $k = 1;
                    static $$md;
                    static get $md() { return this.$$md ??= {
  "b": 2359307,
  "c": [
//--TRIMMABLE-BOUNDARY-START(4297850891),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 2883595,
      "h": 4297850891,
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(4297850891)
  ],
  "d": 2359307,
  "h": 2883595
}; }
                    static get $b() { return $.$srij.System.Runtime.InteropServices.JavaScript.JSType; }
                    static get $fullName() { return `System.Runtime.InteropServices.JavaScript.JSType.Error`; }
                }, $cls, ($v) => $cls.$_Error = $v);
            }
            //--TRIMMABLE-BOUNDARY-END(2883595)
            
            //--TRIMMABLE-BOUNDARY-START(3276811)
            static $_MemoryView;
            static get MemoryView()
            {
                let $cls = $.$srij.System.Runtime.InteropServices.JavaScript.JSType;
                return $cls.$_MemoryView ??= $asm.$ncls("$srij.System.Runtime.InteropServices.JavaScript.JSType.MemoryView", ($self) => class MemoryView extends $.$srij.System.Runtime.InteropServices.JavaScript.JSType
                {
                    //--TRIMMABLE-BOUNDARY-START(4298244107)
                    $ctor$2()
                    {
                        super.$ctor$1();
                        {
                            //--TRIMMABLE-BOUNDARY-START(TRACE)
                            $.$trace(4298244107);
                            //--TRIMMABLE-BOUNDARY-END(TRACE)
                        }
                        return this;
                    }
                    //--TRIMMABLE-BOUNDARY-END(4298244107)
                    
                    static $h = 3276811;
                    static $f = 0b10000000010010001;
                    static $k = 1;
                    static $$md;
                    static get $md() { return this.$$md ??= {
  "b": 2359307,
  "c": [
//--TRIMMABLE-BOUNDARY-START(4298244107),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 3276811,
      "h": 4298244107,
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(4298244107)
  ],
  "d": 2359307,
  "h": 3276811
}; }
                    static get $b() { return $.$srij.System.Runtime.InteropServices.JavaScript.JSType; }
                    static get $fullName() { return `System.Runtime.InteropServices.JavaScript.JSType.MemoryView`; }
                }, $cls, ($v) => $cls.$_MemoryView = $v);
            }
            //--TRIMMABLE-BOUNDARY-END(3276811)
            
            //--TRIMMABLE-BOUNDARY-START(2490379)
            static $_Array$$;
            static Array$$(T)
            {
                let $cls = $.$srij.System.Runtime.InteropServices.JavaScript.JSType;
                return ($cls.$_Array$$ ??= $asm.$ncls("$srij.System.Runtime.InteropServices.JavaScript.JSType.Array<>", (T) => $asm.$gt("$srij.System.Runtime.InteropServices.JavaScript.JSType.Array<>", [T], ($self) => class Array$$ extends $.$srij.System.Runtime.InteropServices.JavaScript.JSType
                {
                    //--TRIMMABLE-BOUNDARY-START(4297457675)
                    $ctor$2()
                    {
                        super.$ctor$1();
                        {
                            //--TRIMMABLE-BOUNDARY-START(TRACE)
                            $.$trace(4297457675);
                            //--TRIMMABLE-BOUNDARY-END(TRACE)
                        }
                        return this;
                    }
                    //--TRIMMABLE-BOUNDARY-END(4297457675)
                    
                    static $h = 2490379;
                    static $g = 1;
                    static $f = 0b10000000011010001;
                    static $k = 1;
                    static $$md;
                    static get $md() { return this.$$md ??= {
  "b": 2359307,
  "c": [
//--TRIMMABLE-BOUNDARY-START(4297457675),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x100000000n),
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(4297457675)
  ],
  "g": [T?.$h??1507328
  ],
  "r": 1,
  "d": 2359307,
  "h": this.$h
}; }
                    static get $b() { return $.$srij.System.Runtime.InteropServices.JavaScript.JSType; }
                    static get $fullName() { return `System.Runtime.InteropServices.JavaScript.JSType.Array<${T?.$fullName}>`; }
                }), $cls, ($v) => $cls.$_Array$$ = $v))(T);
            }
            //--TRIMMABLE-BOUNDARY-END(2490379)
            
            //--TRIMMABLE-BOUNDARY-START(3473419)
            static $_Promise$$;
            static Promise$$(T)
            {
                let $cls = $.$srij.System.Runtime.InteropServices.JavaScript.JSType;
                return ($cls.$_Promise$$ ??= $asm.$ncls("$srij.System.Runtime.InteropServices.JavaScript.JSType.Promise<>", (T) => $asm.$gt("$srij.System.Runtime.InteropServices.JavaScript.JSType.Promise<>", [T], ($self) => class Promise$$ extends $.$srij.System.Runtime.InteropServices.JavaScript.JSType
                {
                    //--TRIMMABLE-BOUNDARY-START(4298440715)
                    $ctor$2()
                    {
                        super.$ctor$1();
                        {
                            //--TRIMMABLE-BOUNDARY-START(TRACE)
                            $.$trace(4298440715);
                            //--TRIMMABLE-BOUNDARY-END(TRACE)
                        }
                        return this;
                    }
                    //--TRIMMABLE-BOUNDARY-END(4298440715)
                    
                    static $h = 3473419;
                    static $g = 1;
                    static $f = 0b10000000011010001;
                    static $k = 1;
                    static $$md;
                    static get $md() { return this.$$md ??= {
  "b": 2359307,
  "c": [
//--TRIMMABLE-BOUNDARY-START(4298440715),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x100000000n),
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(4298440715)
  ],
  "g": [T?.$h??1507328
  ],
  "r": 1,
  "d": 2359307,
  "h": this.$h
}; }
                    static get $b() { return $.$srij.System.Runtime.InteropServices.JavaScript.JSType; }
                    static get $fullName() { return `System.Runtime.InteropServices.JavaScript.JSType.Promise<${T?.$fullName}>`; }
                }), $cls, ($v) => $cls.$_Promise$$ = $v))(T);
            }
            //--TRIMMABLE-BOUNDARY-END(3473419)
            
            //--TRIMMABLE-BOUNDARY-START(2949131)
            static $_Function;
            static get Function()
            {
                let $cls = $.$srij.System.Runtime.InteropServices.JavaScript.JSType;
                return $cls.$_Function ??= $asm.$ncls("$srij.System.Runtime.InteropServices.JavaScript.JSType.Function", ($self) => class Function extends $.$srij.System.Runtime.InteropServices.JavaScript.JSType
                {
                    //--TRIMMABLE-BOUNDARY-START(4297916427)
                    $ctor$2()
                    {
                        super.$ctor$1();
                        {
                            //--TRIMMABLE-BOUNDARY-START(TRACE)
                            $.$trace(4297916427);
                            //--TRIMMABLE-BOUNDARY-END(TRACE)
                        }
                        return this;
                    }
                    //--TRIMMABLE-BOUNDARY-END(4297916427)
                    
                    static $h = 2949131;
                    static $f = 0b10000000010010001;
                    static $k = 1;
                    static $$md;
                    static get $md() { return this.$$md ??= {
  "b": 2359307,
  "c": [
//--TRIMMABLE-BOUNDARY-START(4297916427),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 2949131,
      "h": 4297916427,
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(4297916427)
  ],
  "d": 2359307,
  "h": 2949131
}; }
                    static get $b() { return $.$srij.System.Runtime.InteropServices.JavaScript.JSType; }
                    static get $fullName() { return `System.Runtime.InteropServices.JavaScript.JSType.Function`; }
                }, $cls, ($v) => $cls.$_Function = $v);
            }
            //--TRIMMABLE-BOUNDARY-END(2949131)
            
            //--TRIMMABLE-BOUNDARY-START(3211275)
            static $_Function$$;
            static Function$$(T)
            {
                let $cls = $.$srij.System.Runtime.InteropServices.JavaScript.JSType;
                return ($cls.$_Function$$ ??= $asm.$ncls("$srij.System.Runtime.InteropServices.JavaScript.JSType.Function<>", (T) => $asm.$gt("$srij.System.Runtime.InteropServices.JavaScript.JSType.Function<>", [T], ($self) => class Function$$ extends $.$srij.System.Runtime.InteropServices.JavaScript.JSType
                {
                    //--TRIMMABLE-BOUNDARY-START(4298178571)
                    $ctor$2()
                    {
                        super.$ctor$1();
                        {
                            //--TRIMMABLE-BOUNDARY-START(TRACE)
                            $.$trace(4298178571);
                            //--TRIMMABLE-BOUNDARY-END(TRACE)
                        }
                        return this;
                    }
                    //--TRIMMABLE-BOUNDARY-END(4298178571)
                    
                    static $h = 3211275;
                    static $g = 1;
                    static $f = 0b10000000011010001;
                    static $k = 1;
                    static $$md;
                    static get $md() { return this.$$md ??= {
  "b": 2359307,
  "c": [
//--TRIMMABLE-BOUNDARY-START(4298178571),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x100000000n),
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(4298178571)
  ],
  "g": [T?.$h??1507328
  ],
  "r": 1,
  "d": 2359307,
  "h": this.$h
}; }
                    static get $b() { return $.$srij.System.Runtime.InteropServices.JavaScript.JSType; }
                    static get $fullName() { return `System.Runtime.InteropServices.JavaScript.JSType.Function<${T?.$fullName}>`; }
                }), $cls, ($v) => $cls.$_Function$$ = $v))(T);
            }
            //--TRIMMABLE-BOUNDARY-END(3211275)
            
            //--TRIMMABLE-BOUNDARY-START(3145739)
            static $_Function$$$;
            static Function$$$(T1, T2)
            {
                let $cls = $.$srij.System.Runtime.InteropServices.JavaScript.JSType;
                return ($cls.$_Function$$$ ??= $asm.$ncls("$srij.System.Runtime.InteropServices.JavaScript.JSType.Function<,>", (T1, T2) => $asm.$gt("$srij.System.Runtime.InteropServices.JavaScript.JSType.Function<,>", [T1, T2], ($self) => class Function$$$ extends $.$srij.System.Runtime.InteropServices.JavaScript.JSType
                {
                    //--TRIMMABLE-BOUNDARY-START(4298113035)
                    $ctor$2()
                    {
                        super.$ctor$1();
                        {
                            //--TRIMMABLE-BOUNDARY-START(TRACE)
                            $.$trace(4298113035);
                            //--TRIMMABLE-BOUNDARY-END(TRACE)
                        }
                        return this;
                    }
                    //--TRIMMABLE-BOUNDARY-END(4298113035)
                    
                    static $h = 3145739;
                    static $g = 2;
                    static $f = 0b10000000011010001;
                    static $k = 1;
                    static $$md;
                    static get $md() { return this.$$md ??= {
  "b": 2359307,
  "c": [
//--TRIMMABLE-BOUNDARY-START(4298113035),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x100000000n),
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(4298113035)
  ],
  "g": [T1?.$h??1507328,T2?.$h??1572864
  ],
  "r": 2,
  "d": 2359307,
  "h": this.$h
}; }
                    static get $b() { return $.$srij.System.Runtime.InteropServices.JavaScript.JSType; }
                    static get $fullName() { return `System.Runtime.InteropServices.JavaScript.JSType.Function<${T1?.$fullName},${T2?.$fullName}>`; }
                }), $cls, ($v) => $cls.$_Function$$$ = $v))(T1, T2);
            }
            //--TRIMMABLE-BOUNDARY-END(3145739)
            
            //--TRIMMABLE-BOUNDARY-START(3080203)
            static $_Function$$$$;
            static Function$$$$(T1, T2, T3)
            {
                let $cls = $.$srij.System.Runtime.InteropServices.JavaScript.JSType;
                return ($cls.$_Function$$$$ ??= $asm.$ncls("$srij.System.Runtime.InteropServices.JavaScript.JSType.Function<,,>", (T1, T2, T3) => $asm.$gt("$srij.System.Runtime.InteropServices.JavaScript.JSType.Function<,,>", [T1, T2, T3], ($self) => class Function$$$$ extends $.$srij.System.Runtime.InteropServices.JavaScript.JSType
                {
                    //--TRIMMABLE-BOUNDARY-START(4298047499)
                    $ctor$2()
                    {
                        super.$ctor$1();
                        {
                            //--TRIMMABLE-BOUNDARY-START(TRACE)
                            $.$trace(4298047499);
                            //--TRIMMABLE-BOUNDARY-END(TRACE)
                        }
                        return this;
                    }
                    //--TRIMMABLE-BOUNDARY-END(4298047499)
                    
                    static $h = 3080203;
                    static $g = 3;
                    static $f = 0b10000000011010001;
                    static $k = 1;
                    static $$md;
                    static get $md() { return this.$$md ??= {
  "b": 2359307,
  "c": [
//--TRIMMABLE-BOUNDARY-START(4298047499),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x100000000n),
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(4298047499)
  ],
  "g": [T1?.$h??1507328,T2?.$h??1572864,T3?.$h??1638400
  ],
  "r": 3,
  "d": 2359307,
  "h": this.$h
}; }
                    static get $b() { return $.$srij.System.Runtime.InteropServices.JavaScript.JSType; }
                    static get $fullName() { return `System.Runtime.InteropServices.JavaScript.JSType.Function<${T1?.$fullName},${T2?.$fullName},${T3?.$fullName}>`; }
                }), $cls, ($v) => $cls.$_Function$$$$ = $v))(T1, T2, T3);
            }
            //--TRIMMABLE-BOUNDARY-END(3080203)
            
            //--TRIMMABLE-BOUNDARY-START(3014667)
            static $_Function$$$$$;
            static Function$$$$$(T1, T2, T3, T4)
            {
                let $cls = $.$srij.System.Runtime.InteropServices.JavaScript.JSType;
                return ($cls.$_Function$$$$$ ??= $asm.$ncls("$srij.System.Runtime.InteropServices.JavaScript.JSType.Function<,,,>", (T1, T2, T3, T4) => $asm.$gt("$srij.System.Runtime.InteropServices.JavaScript.JSType.Function<,,,>", [T1, T2, T3, T4], ($self) => class Function$$$$$ extends $.$srij.System.Runtime.InteropServices.JavaScript.JSType
                {
                    //--TRIMMABLE-BOUNDARY-START(4297981963)
                    $ctor$2()
                    {
                        super.$ctor$1();
                        {
                            //--TRIMMABLE-BOUNDARY-START(TRACE)
                            $.$trace(4297981963);
                            //--TRIMMABLE-BOUNDARY-END(TRACE)
                        }
                        return this;
                    }
                    //--TRIMMABLE-BOUNDARY-END(4297981963)
                    
                    static $h = 3014667;
                    static $g = 4;
                    static $f = 0b10000000011010001;
                    static $k = 1;
                    static $$md;
                    static get $md() { return this.$$md ??= {
  "b": 2359307,
  "c": [
//--TRIMMABLE-BOUNDARY-START(4297981963),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x100000000n),
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(4297981963)
  ],
  "g": [T1?.$h??1507328,T2?.$h??1572864,T3?.$h??1638400,T4?.$h??1703936
  ],
  "r": 4,
  "d": 2359307,
  "h": this.$h
}; }
                    static get $b() { return $.$srij.System.Runtime.InteropServices.JavaScript.JSType; }
                    static get $fullName() { return `System.Runtime.InteropServices.JavaScript.JSType.Function<${T1?.$fullName},${T2?.$fullName},${T3?.$fullName},${T4?.$fullName}>`; }
                }), $cls, ($v) => $cls.$_Function$$$$$ = $v))(T1, T2, T3, T4);
            }
            //--TRIMMABLE-BOUNDARY-END(3014667)
            
            //--TRIMMABLE-BOUNDARY-START(2424843)
            static $_Any;
            static get Any()
            {
                let $cls = $.$srij.System.Runtime.InteropServices.JavaScript.JSType;
                return $cls.$_Any ??= $asm.$ncls("$srij.System.Runtime.InteropServices.JavaScript.JSType.Any", ($self) => class Any extends $.$srij.System.Runtime.InteropServices.JavaScript.JSType
                {
                    //--TRIMMABLE-BOUNDARY-START(4297392139)
                    $ctor$2()
                    {
                        super.$ctor$1();
                        {
                            //--TRIMMABLE-BOUNDARY-START(TRACE)
                            $.$trace(4297392139);
                            //--TRIMMABLE-BOUNDARY-END(TRACE)
                        }
                        return this;
                    }
                    //--TRIMMABLE-BOUNDARY-END(4297392139)
                    
                    static $h = 2424843;
                    static $f = 0b10000000010010001;
                    static $k = 1;
                    static $$md;
                    static get $md() { return this.$$md ??= {
  "b": 2359307,
  "c": [
//--TRIMMABLE-BOUNDARY-START(4297392139),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 2424843,
      "h": 4297392139,
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(4297392139)
  ],
  "d": 2359307,
  "h": 2424843
}; }
                    static get $b() { return $.$srij.System.Runtime.InteropServices.JavaScript.JSType; }
                    static get $fullName() { return `System.Runtime.InteropServices.JavaScript.JSType.Any`; }
                }, $cls, ($v) => $cls.$_Any = $v);
            }
            //--TRIMMABLE-BOUNDARY-END(2424843)
            
            static $h = 2359307;
            static $f = 0b110001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 131073,
  "c": [
//--TRIMMABLE-BOUNDARY-START(85901705227),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 2359307,
      "h": 85901705227,
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(85901705227)
  ],
  "j": [3604491,2752523,2818059,2621451,3342347,2555915,2686987,3538955,3407883,2883595,3276811,2490379,3473419,2949131,3211275,3145739,3080203,3014667,2424843
  ],
  "h": 2359307,
  "a": [
    {
      "t": 159055873,
      "c": 4454023169,
      "a": [
        {
          "v": "browser",
          "t": 1310721
        }
      ]
    }
  ]
}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `System.Runtime.InteropServices.JavaScript.JSType`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2359307)
        
        
        //--TRIMMABLE-BOUNDARY-START(327691)
        $asm.$cls("$srij.System.Runtime.InteropServices.JavaScript.JavaScriptImports", ($self) => class JavaScriptImports
        {
            //--TRIMMABLE-BOUNDARY-START(133144313867)
            static /*bool */ HasProperty(/*global::System.Runtime.InteropServices.JavaScript.JSObject*/ self, /*string*/ propertyName)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(133144313867);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$srij.System.Runtime.InteropServices.JavaScript.JavaScriptImports.__signature_HasProperty_393970128 === null)
                {
                    $.$srij.System.Runtime.InteropServices.JavaScript.JavaScriptImports.__signature_HasProperty_393970128 = $.$srij.System.Runtime.InteropServices.JavaScript.JSFunctionBinding.BindJSFunction("INTERNAL.has_property", null, $.$$.System.ReadOnlySpan$$($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType).op_Implicit$1($.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType), [$.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType.Boolean, $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType.JSObject, $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType.String], null, null)));
                }
                {
                    /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ let ____arg_exception_native;
                    /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ let ____arg_return_native;
                    /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ let __self_native;
                    /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ let __propertyName_native;
                    /*bool*/ let __retVal;
                    /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ let __retVal_native;
                    $.$$.System.Runtime.CompilerServices.Unsafe.SkipInit($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument, $.$ref(() => ____arg_return_native, ($v) => ____arg_return_native = $v, $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument));
                    ____arg_return_native.Initialize();
                    $.$$.System.Runtime.CompilerServices.Unsafe.SkipInit($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument, $.$ref(() => ____arg_exception_native, ($v) => ____arg_exception_native = $v, $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument));
                    ____arg_exception_native.Initialize();
                    $.$$.System.Runtime.CompilerServices.Unsafe.SkipInit($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument, $.$ref(() => __propertyName_native, ($v) => __propertyName_native = $v, $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument));
                    $.$$.System.Runtime.CompilerServices.Unsafe.SkipInit($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument, $.$ref(() => __self_native, ($v) => __self_native = $v, $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument));
                    __propertyName_native.ToJS$35(propertyName);
                    __self_native.ToJS$39(self);
                    {
                        __retVal_native = __InvokeJSFunction.call(this, ____arg_exception_native.Clone(), ____arg_return_native.Clone(), __self_native.Clone(), __propertyName_native.Clone());
                    }
                    __retVal_native.ToManaged$4($.$ref(() => __retVal, ($v) => __retVal = $v, $.$$.System.Boolean));
                    return __retVal;
                }
                /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/  function __InvokeJSFunction(/*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ ____arg_exception_native, /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ ____arg_return_native, /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ __self_native, /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ __propertyName_native)
                {
                    /*global::System.Span<global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument>*/ let __arguments_buffer = $.$$.System.Span$$($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument).op_Implicit$2($.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument), [____arg_exception_native, ____arg_return_native, __self_native, __propertyName_native], null, null));
                    $.$srij.System.Runtime.InteropServices.JavaScript.JSFunctionBinding.InvokeJS($.$srij.System.Runtime.InteropServices.JavaScript.JavaScriptImports.__signature_HasProperty_393970128, __arguments_buffer);
                    return __arguments_buffer.get_Item(1).$v;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(133144313867)
            
            //--TRIMMABLE-BOUNDARY-START(51539935243)
            /*global::System.Runtime.InteropServices.JavaScript.JSFunctionBinding*/ static __signature_HasProperty_393970128 = null;
            //--TRIMMABLE-BOUNDARY-END(51539935243)
            
            //--TRIMMABLE-BOUNDARY-START(128849346571)
            static /*string */ GetTypeOfProperty(/*global::System.Runtime.InteropServices.JavaScript.JSObject*/ self, /*string*/ propertyName)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(128849346571);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$srij.System.Runtime.InteropServices.JavaScript.JavaScriptImports.__signature_GetTypeOfProperty_1139574135 === null)
                {
                    $.$srij.System.Runtime.InteropServices.JavaScript.JavaScriptImports.__signature_GetTypeOfProperty_1139574135 = $.$srij.System.Runtime.InteropServices.JavaScript.JSFunctionBinding.BindJSFunction("INTERNAL.get_typeof_property", null, $.$$.System.ReadOnlySpan$$($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType).op_Implicit$1($.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType), [$.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType.String, $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType.JSObject, $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType.String], null, null)));
                }
                {
                    /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ let ____arg_exception_native;
                    /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ let ____arg_return_native;
                    /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ let __self_native;
                    /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ let __propertyName_native;
                    /*string*/ let __retVal;
                    /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ let __retVal_native;
                    $.$$.System.Runtime.CompilerServices.Unsafe.SkipInit($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument, $.$ref(() => ____arg_return_native, ($v) => ____arg_return_native = $v, $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument));
                    ____arg_return_native.Initialize();
                    $.$$.System.Runtime.CompilerServices.Unsafe.SkipInit($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument, $.$ref(() => ____arg_exception_native, ($v) => ____arg_exception_native = $v, $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument));
                    ____arg_exception_native.Initialize();
                    $.$$.System.Runtime.CompilerServices.Unsafe.SkipInit($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument, $.$ref(() => __propertyName_native, ($v) => __propertyName_native = $v, $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument));
                    $.$$.System.Runtime.CompilerServices.Unsafe.SkipInit($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument, $.$ref(() => __self_native, ($v) => __self_native = $v, $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument));
                    __propertyName_native.ToJS$35(propertyName);
                    __self_native.ToJS$39(self);
                    {
                        __retVal_native = __InvokeJSFunction.call(this, ____arg_exception_native.Clone(), ____arg_return_native.Clone(), __self_native.Clone(), __propertyName_native.Clone());
                    }
                    __retVal_native.ToManaged$35($.$ref(() => __retVal, ($v) => __retVal = $v, $.$$.System.String));
                    return __retVal;
                }
                /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/  function __InvokeJSFunction(/*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ ____arg_exception_native, /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ ____arg_return_native, /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ __self_native, /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ __propertyName_native)
                {
                    /*global::System.Span<global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument>*/ let __arguments_buffer = $.$$.System.Span$$($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument).op_Implicit$2($.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument), [____arg_exception_native, ____arg_return_native, __self_native, __propertyName_native], null, null));
                    $.$srij.System.Runtime.InteropServices.JavaScript.JSFunctionBinding.InvokeJS($.$srij.System.Runtime.InteropServices.JavaScript.JavaScriptImports.__signature_GetTypeOfProperty_1139574135, __arguments_buffer);
                    return __arguments_buffer.get_Item(1).$v;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(128849346571)
            
            //--TRIMMABLE-BOUNDARY-START(47244967947)
            /*global::System.Runtime.InteropServices.JavaScript.JSFunctionBinding*/ static __signature_GetTypeOfProperty_1139574135 = null;
            //--TRIMMABLE-BOUNDARY-END(47244967947)
            
            //--TRIMMABLE-BOUNDARY-START(103079542795)
            static /*bool */ GetPropertyAsBoolean(/*global::System.Runtime.InteropServices.JavaScript.JSObject*/ self, /*string*/ propertyName)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(103079542795);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$srij.System.Runtime.InteropServices.JavaScript.JavaScriptImports.__signature_GetPropertyAsBoolean_393970128 === null)
                {
                    $.$srij.System.Runtime.InteropServices.JavaScript.JavaScriptImports.__signature_GetPropertyAsBoolean_393970128 = $.$srij.System.Runtime.InteropServices.JavaScript.JSFunctionBinding.BindJSFunction("INTERNAL.get_property", null, $.$$.System.ReadOnlySpan$$($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType).op_Implicit$1($.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType), [$.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType.Boolean, $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType.JSObject, $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType.String], null, null)));
                }
                {
                    /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ let ____arg_exception_native;
                    /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ let ____arg_return_native;
                    /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ let __self_native;
                    /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ let __propertyName_native;
                    /*bool*/ let __retVal;
                    /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ let __retVal_native;
                    $.$$.System.Runtime.CompilerServices.Unsafe.SkipInit($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument, $.$ref(() => ____arg_return_native, ($v) => ____arg_return_native = $v, $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument));
                    ____arg_return_native.Initialize();
                    $.$$.System.Runtime.CompilerServices.Unsafe.SkipInit($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument, $.$ref(() => ____arg_exception_native, ($v) => ____arg_exception_native = $v, $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument));
                    ____arg_exception_native.Initialize();
                    $.$$.System.Runtime.CompilerServices.Unsafe.SkipInit($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument, $.$ref(() => __propertyName_native, ($v) => __propertyName_native = $v, $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument));
                    $.$$.System.Runtime.CompilerServices.Unsafe.SkipInit($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument, $.$ref(() => __self_native, ($v) => __self_native = $v, $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument));
                    __propertyName_native.ToJS$35(propertyName);
                    __self_native.ToJS$39(self);
                    {
                        __retVal_native = __InvokeJSFunction.call(this, ____arg_exception_native.Clone(), ____arg_return_native.Clone(), __self_native.Clone(), __propertyName_native.Clone());
                    }
                    __retVal_native.ToManaged$4($.$ref(() => __retVal, ($v) => __retVal = $v, $.$$.System.Boolean));
                    return __retVal;
                }
                /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/  function __InvokeJSFunction(/*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ ____arg_exception_native, /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ ____arg_return_native, /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ __self_native, /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ __propertyName_native)
                {
                    /*global::System.Span<global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument>*/ let __arguments_buffer = $.$$.System.Span$$($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument).op_Implicit$2($.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument), [____arg_exception_native, ____arg_return_native, __self_native, __propertyName_native], null, null));
                    $.$srij.System.Runtime.InteropServices.JavaScript.JSFunctionBinding.InvokeJS($.$srij.System.Runtime.InteropServices.JavaScript.JavaScriptImports.__signature_GetPropertyAsBoolean_393970128, __arguments_buffer);
                    return __arguments_buffer.get_Item(1).$v;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(103079542795)
            
            //--TRIMMABLE-BOUNDARY-START(21475164171)
            /*global::System.Runtime.InteropServices.JavaScript.JSFunctionBinding*/ static __signature_GetPropertyAsBoolean_393970128 = null;
            //--TRIMMABLE-BOUNDARY-END(21475164171)
            
            //--TRIMMABLE-BOUNDARY-START(115964444683)
            static /*int */ GetPropertyAsInt32(/*global::System.Runtime.InteropServices.JavaScript.JSObject*/ self, /*string*/ propertyName)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(115964444683);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$srij.System.Runtime.InteropServices.JavaScript.JavaScriptImports.__signature_GetPropertyAsInt32_1813830729 === null)
                {
                    $.$srij.System.Runtime.InteropServices.JavaScript.JavaScriptImports.__signature_GetPropertyAsInt32_1813830729 = $.$srij.System.Runtime.InteropServices.JavaScript.JSFunctionBinding.BindJSFunction("INTERNAL.get_property", null, $.$$.System.ReadOnlySpan$$($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType).op_Implicit$1($.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType), [$.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType.Int32, $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType.JSObject, $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType.String], null, null)));
                }
                {
                    /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ let ____arg_exception_native;
                    /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ let ____arg_return_native;
                    /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ let __self_native;
                    /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ let __propertyName_native;
                    /*int*/ let __retVal;
                    /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ let __retVal_native;
                    $.$$.System.Runtime.CompilerServices.Unsafe.SkipInit($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument, $.$ref(() => ____arg_return_native, ($v) => ____arg_return_native = $v, $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument));
                    ____arg_return_native.Initialize();
                    $.$$.System.Runtime.CompilerServices.Unsafe.SkipInit($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument, $.$ref(() => ____arg_exception_native, ($v) => ____arg_exception_native = $v, $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument));
                    ____arg_exception_native.Initialize();
                    $.$$.System.Runtime.CompilerServices.Unsafe.SkipInit($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument, $.$ref(() => __propertyName_native, ($v) => __propertyName_native = $v, $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument));
                    $.$$.System.Runtime.CompilerServices.Unsafe.SkipInit($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument, $.$ref(() => __self_native, ($v) => __self_native = $v, $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument));
                    __propertyName_native.ToJS$35(propertyName);
                    __self_native.ToJS$39(self);
                    {
                        __retVal_native = __InvokeJSFunction.call(this, ____arg_exception_native.Clone(), ____arg_return_native.Clone(), __self_native.Clone(), __propertyName_native.Clone());
                    }
                    __retVal_native.ToManaged$14($.$ref(() => __retVal, ($v) => __retVal = $v, $.$$.System.Int32));
                    return __retVal;
                }
                /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/  function __InvokeJSFunction(/*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ ____arg_exception_native, /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ ____arg_return_native, /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ __self_native, /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ __propertyName_native)
                {
                    /*global::System.Span<global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument>*/ let __arguments_buffer = $.$$.System.Span$$($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument).op_Implicit$2($.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument), [____arg_exception_native, ____arg_return_native, __self_native, __propertyName_native], null, null));
                    $.$srij.System.Runtime.InteropServices.JavaScript.JSFunctionBinding.InvokeJS($.$srij.System.Runtime.InteropServices.JavaScript.JavaScriptImports.__signature_GetPropertyAsInt32_1813830729, __arguments_buffer);
                    return __arguments_buffer.get_Item(1).$v;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(115964444683)
            
            //--TRIMMABLE-BOUNDARY-START(34360066059)
            /*global::System.Runtime.InteropServices.JavaScript.JSFunctionBinding*/ static __signature_GetPropertyAsInt32_1813830729 = null;
            //--TRIMMABLE-BOUNDARY-END(34360066059)
            
            //--TRIMMABLE-BOUNDARY-START(111669477387)
            static /*double */ GetPropertyAsDouble(/*global::System.Runtime.InteropServices.JavaScript.JSObject*/ self, /*string*/ propertyName)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(111669477387);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$srij.System.Runtime.InteropServices.JavaScript.JavaScriptImports.__signature_GetPropertyAsDouble_705601847 === null)
                {
                    $.$srij.System.Runtime.InteropServices.JavaScript.JavaScriptImports.__signature_GetPropertyAsDouble_705601847 = $.$srij.System.Runtime.InteropServices.JavaScript.JSFunctionBinding.BindJSFunction("INTERNAL.get_property", null, $.$$.System.ReadOnlySpan$$($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType).op_Implicit$1($.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType), [$.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType.Double, $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType.JSObject, $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType.String], null, null)));
                }
                {
                    /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ let ____arg_exception_native;
                    /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ let ____arg_return_native;
                    /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ let __self_native;
                    /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ let __propertyName_native;
                    /*double*/ let __retVal;
                    /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ let __retVal_native;
                    $.$$.System.Runtime.CompilerServices.Unsafe.SkipInit($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument, $.$ref(() => ____arg_return_native, ($v) => ____arg_return_native = $v, $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument));
                    ____arg_return_native.Initialize();
                    $.$$.System.Runtime.CompilerServices.Unsafe.SkipInit($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument, $.$ref(() => ____arg_exception_native, ($v) => ____arg_exception_native = $v, $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument));
                    ____arg_exception_native.Initialize();
                    $.$$.System.Runtime.CompilerServices.Unsafe.SkipInit($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument, $.$ref(() => __propertyName_native, ($v) => __propertyName_native = $v, $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument));
                    $.$$.System.Runtime.CompilerServices.Unsafe.SkipInit($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument, $.$ref(() => __self_native, ($v) => __self_native = $v, $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument));
                    __propertyName_native.ToJS$35(propertyName);
                    __self_native.ToJS$39(self);
                    {
                        __retVal_native = __InvokeJSFunction.call(this, ____arg_exception_native.Clone(), ____arg_return_native.Clone(), __self_native.Clone(), __propertyName_native.Clone());
                    }
                    __retVal_native.ToManaged$10($.$ref(() => __retVal, ($v) => __retVal = $v, $.$$.System.Double));
                    return __retVal;
                }
                /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/  function __InvokeJSFunction(/*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ ____arg_exception_native, /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ ____arg_return_native, /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ __self_native, /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ __propertyName_native)
                {
                    /*global::System.Span<global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument>*/ let __arguments_buffer = $.$$.System.Span$$($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument).op_Implicit$2($.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument), [____arg_exception_native, ____arg_return_native, __self_native, __propertyName_native], null, null));
                    $.$srij.System.Runtime.InteropServices.JavaScript.JSFunctionBinding.InvokeJS($.$srij.System.Runtime.InteropServices.JavaScript.JavaScriptImports.__signature_GetPropertyAsDouble_705601847, __arguments_buffer);
                    return __arguments_buffer.get_Item(1).$v;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(111669477387)
            
            //--TRIMMABLE-BOUNDARY-START(30065098763)
            /*global::System.Runtime.InteropServices.JavaScript.JSFunctionBinding*/ static __signature_GetPropertyAsDouble_705601847 = null;
            //--TRIMMABLE-BOUNDARY-END(30065098763)
            
            //--TRIMMABLE-BOUNDARY-START(124554379275)
            static /*string */ GetPropertyAsString(/*global::System.Runtime.InteropServices.JavaScript.JSObject*/ self, /*string*/ propertyName)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(124554379275);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$srij.System.Runtime.InteropServices.JavaScript.JavaScriptImports.__signature_GetPropertyAsString_1139574135 === null)
                {
                    $.$srij.System.Runtime.InteropServices.JavaScript.JavaScriptImports.__signature_GetPropertyAsString_1139574135 = $.$srij.System.Runtime.InteropServices.JavaScript.JSFunctionBinding.BindJSFunction("INTERNAL.get_property", null, $.$$.System.ReadOnlySpan$$($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType).op_Implicit$1($.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType), [$.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType.String, $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType.JSObject, $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType.String], null, null)));
                }
                {
                    /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ let ____arg_exception_native;
                    /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ let ____arg_return_native;
                    /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ let __self_native;
                    /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ let __propertyName_native;
                    /*string*/ let __retVal;
                    /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ let __retVal_native;
                    $.$$.System.Runtime.CompilerServices.Unsafe.SkipInit($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument, $.$ref(() => ____arg_return_native, ($v) => ____arg_return_native = $v, $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument));
                    ____arg_return_native.Initialize();
                    $.$$.System.Runtime.CompilerServices.Unsafe.SkipInit($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument, $.$ref(() => ____arg_exception_native, ($v) => ____arg_exception_native = $v, $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument));
                    ____arg_exception_native.Initialize();
                    $.$$.System.Runtime.CompilerServices.Unsafe.SkipInit($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument, $.$ref(() => __propertyName_native, ($v) => __propertyName_native = $v, $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument));
                    $.$$.System.Runtime.CompilerServices.Unsafe.SkipInit($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument, $.$ref(() => __self_native, ($v) => __self_native = $v, $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument));
                    __propertyName_native.ToJS$35(propertyName);
                    __self_native.ToJS$39(self);
                    {
                        __retVal_native = __InvokeJSFunction.call(this, ____arg_exception_native.Clone(), ____arg_return_native.Clone(), __self_native.Clone(), __propertyName_native.Clone());
                    }
                    __retVal_native.ToManaged$35($.$ref(() => __retVal, ($v) => __retVal = $v, $.$$.System.String));
                    return __retVal;
                }
                /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/  function __InvokeJSFunction(/*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ ____arg_exception_native, /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ ____arg_return_native, /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ __self_native, /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ __propertyName_native)
                {
                    /*global::System.Span<global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument>*/ let __arguments_buffer = $.$$.System.Span$$($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument).op_Implicit$2($.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument), [____arg_exception_native, ____arg_return_native, __self_native, __propertyName_native], null, null));
                    $.$srij.System.Runtime.InteropServices.JavaScript.JSFunctionBinding.InvokeJS($.$srij.System.Runtime.InteropServices.JavaScript.JavaScriptImports.__signature_GetPropertyAsString_1139574135, __arguments_buffer);
                    return __arguments_buffer.get_Item(1).$v;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(124554379275)
            
            //--TRIMMABLE-BOUNDARY-START(42950000651)
            /*global::System.Runtime.InteropServices.JavaScript.JSFunctionBinding*/ static __signature_GetPropertyAsString_1139574135 = null;
            //--TRIMMABLE-BOUNDARY-END(42950000651)
            
            //--TRIMMABLE-BOUNDARY-START(120259411979)
            static /*global::System.Runtime.InteropServices.JavaScript.JSObject */ GetPropertyAsJSObject(/*global::System.Runtime.InteropServices.JavaScript.JSObject*/ self, /*string*/ propertyName)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(120259411979);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$srij.System.Runtime.InteropServices.JavaScript.JavaScriptImports.__signature_GetPropertyAsJSObject_1480020778 === null)
                {
                    $.$srij.System.Runtime.InteropServices.JavaScript.JavaScriptImports.__signature_GetPropertyAsJSObject_1480020778 = $.$srij.System.Runtime.InteropServices.JavaScript.JSFunctionBinding.BindJSFunction("INTERNAL.get_property", null, $.$$.System.ReadOnlySpan$$($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType).op_Implicit$1($.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType), [$.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType.JSObject, $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType.JSObject, $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType.String], null, null)));
                }
                {
                    /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ let ____arg_exception_native;
                    /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ let ____arg_return_native;
                    /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ let __self_native;
                    /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ let __propertyName_native;
                    /*global::System.Runtime.InteropServices.JavaScript.JSObject*/ let __retVal;
                    /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ let __retVal_native;
                    $.$$.System.Runtime.CompilerServices.Unsafe.SkipInit($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument, $.$ref(() => ____arg_return_native, ($v) => ____arg_return_native = $v, $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument));
                    ____arg_return_native.Initialize();
                    $.$$.System.Runtime.CompilerServices.Unsafe.SkipInit($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument, $.$ref(() => ____arg_exception_native, ($v) => ____arg_exception_native = $v, $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument));
                    ____arg_exception_native.Initialize();
                    $.$$.System.Runtime.CompilerServices.Unsafe.SkipInit($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument, $.$ref(() => __propertyName_native, ($v) => __propertyName_native = $v, $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument));
                    $.$$.System.Runtime.CompilerServices.Unsafe.SkipInit($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument, $.$ref(() => __self_native, ($v) => __self_native = $v, $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument));
                    __propertyName_native.ToJS$35(propertyName);
                    __self_native.ToJS$39(self);
                    {
                        __retVal_native = __InvokeJSFunction.call(this, ____arg_exception_native.Clone(), ____arg_return_native.Clone(), __self_native.Clone(), __propertyName_native.Clone());
                    }
                    __retVal_native.ToManaged$39($.$ref(() => __retVal, ($v) => __retVal = $v, $.$srij.System.Runtime.InteropServices.JavaScript.JSObject));
                    return __retVal;
                }
                /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/  function __InvokeJSFunction(/*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ ____arg_exception_native, /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ ____arg_return_native, /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ __self_native, /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ __propertyName_native)
                {
                    /*global::System.Span<global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument>*/ let __arguments_buffer = $.$$.System.Span$$($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument).op_Implicit$2($.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument), [____arg_exception_native, ____arg_return_native, __self_native, __propertyName_native], null, null));
                    $.$srij.System.Runtime.InteropServices.JavaScript.JSFunctionBinding.InvokeJS($.$srij.System.Runtime.InteropServices.JavaScript.JavaScriptImports.__signature_GetPropertyAsJSObject_1480020778, __arguments_buffer);
                    return __arguments_buffer.get_Item(1).$v;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(120259411979)
            
            //--TRIMMABLE-BOUNDARY-START(38655033355)
            /*global::System.Runtime.InteropServices.JavaScript.JSFunctionBinding*/ static __signature_GetPropertyAsJSObject_1480020778 = null;
            //--TRIMMABLE-BOUNDARY-END(38655033355)
            
            //--TRIMMABLE-BOUNDARY-START(107374510091)
            static /*byte[] */ GetPropertyAsByteArray(/*global::System.Runtime.InteropServices.JavaScript.JSObject*/ self, /*string*/ propertyName)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(107374510091);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$srij.System.Runtime.InteropServices.JavaScript.JavaScriptImports.__signature_GetPropertyAsByteArray_657551312 === null)
                {
                    $.$srij.System.Runtime.InteropServices.JavaScript.JavaScriptImports.__signature_GetPropertyAsByteArray_657551312 = $.$srij.System.Runtime.InteropServices.JavaScript.JSFunctionBinding.BindJSFunction("INTERNAL.get_property", null, $.$$.System.ReadOnlySpan$$($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType).op_Implicit$1($.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType), [$.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType.Array($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType.Byte), $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType.JSObject, $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType.String], null, null)));
                }
                {
                    /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ let ____arg_exception_native;
                    /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ let ____arg_return_native;
                    /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ let __self_native;
                    /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ let __propertyName_native;
                    /*byte[]*/ let __retVal;
                    /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ let __retVal_native;
                    $.$$.System.Runtime.CompilerServices.Unsafe.SkipInit($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument, $.$ref(() => ____arg_return_native, ($v) => ____arg_return_native = $v, $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument));
                    ____arg_return_native.Initialize();
                    $.$$.System.Runtime.CompilerServices.Unsafe.SkipInit($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument, $.$ref(() => ____arg_exception_native, ($v) => ____arg_exception_native = $v, $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument));
                    ____arg_exception_native.Initialize();
                    $.$$.System.Runtime.CompilerServices.Unsafe.SkipInit($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument, $.$ref(() => __propertyName_native, ($v) => __propertyName_native = $v, $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument));
                    $.$$.System.Runtime.CompilerServices.Unsafe.SkipInit($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument, $.$ref(() => __self_native, ($v) => __self_native = $v, $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument));
                    __propertyName_native.ToJS$35(propertyName);
                    __self_native.ToJS$39(self);
                    {
                        __retVal_native = __InvokeJSFunction.call(this, ____arg_exception_native.Clone(), ____arg_return_native.Clone(), __self_native.Clone(), __propertyName_native.Clone());
                    }
                    __retVal_native.ToManaged$6($.$ref(() => __retVal, ($v) => __retVal = $v, $.$typeArray($.$$.System.Byte)));
                    return __retVal;
                }
                /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/  function __InvokeJSFunction(/*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ ____arg_exception_native, /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ ____arg_return_native, /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ __self_native, /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ __propertyName_native)
                {
                    /*global::System.Span<global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument>*/ let __arguments_buffer = $.$$.System.Span$$($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument).op_Implicit$2($.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument), [____arg_exception_native, ____arg_return_native, __self_native, __propertyName_native], null, null));
                    $.$srij.System.Runtime.InteropServices.JavaScript.JSFunctionBinding.InvokeJS($.$srij.System.Runtime.InteropServices.JavaScript.JavaScriptImports.__signature_GetPropertyAsByteArray_657551312, __arguments_buffer);
                    return __arguments_buffer.get_Item(1).$v;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(107374510091)
            
            //--TRIMMABLE-BOUNDARY-START(25770131467)
            /*global::System.Runtime.InteropServices.JavaScript.JSFunctionBinding*/ static __signature_GetPropertyAsByteArray_657551312 = null;
            //--TRIMMABLE-BOUNDARY-END(25770131467)
            
            //--TRIMMABLE-BOUNDARY-START(141734248459)
            static /*void */ SetPropertyBool(/*global::System.Runtime.InteropServices.JavaScript.JSObject*/ self, /*string*/ propertyName, /*bool*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(141734248459);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$srij.System.Runtime.InteropServices.JavaScript.JavaScriptImports.__signature_SetPropertyBool_125660004 === null)
                {
                    $.$srij.System.Runtime.InteropServices.JavaScript.JavaScriptImports.__signature_SetPropertyBool_125660004 = $.$srij.System.Runtime.InteropServices.JavaScript.JSFunctionBinding.BindJSFunction("INTERNAL.set_property", null, $.$$.System.ReadOnlySpan$$($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType).op_Implicit$1($.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType), [$.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType.Discard, $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType.JSObject, $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType.String, $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType.Boolean], null, null)));
                }
                {
                    /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ let ____arg_exception_native;
                    /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ let ____arg_return_native;
                    /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ let __self_native;
                    /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ let __propertyName_native;
                    /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ let __value_native;
                    $.$$.System.Runtime.CompilerServices.Unsafe.SkipInit($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument, $.$ref(() => ____arg_return_native, ($v) => ____arg_return_native = $v, $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument));
                    ____arg_return_native.Initialize();
                    $.$$.System.Runtime.CompilerServices.Unsafe.SkipInit($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument, $.$ref(() => ____arg_exception_native, ($v) => ____arg_exception_native = $v, $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument));
                    ____arg_exception_native.Initialize();
                    $.$$.System.Runtime.CompilerServices.Unsafe.SkipInit($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument, $.$ref(() => __value_native, ($v) => __value_native = $v, $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument));
                    $.$$.System.Runtime.CompilerServices.Unsafe.SkipInit($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument, $.$ref(() => __propertyName_native, ($v) => __propertyName_native = $v, $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument));
                    $.$$.System.Runtime.CompilerServices.Unsafe.SkipInit($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument, $.$ref(() => __self_native, ($v) => __self_native = $v, $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument));
                    __value_native.ToJS$4(value);
                    __propertyName_native.ToJS$35(propertyName);
                    __self_native.ToJS$39(self);
                    {
                        __InvokeJSFunction.call(this, ____arg_exception_native.Clone(), ____arg_return_native.Clone(), __self_native.Clone(), __propertyName_native.Clone(), __value_native.Clone());
                    }
                }
                /*void*/  function __InvokeJSFunction(/*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ ____arg_exception_native, /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ ____arg_return_native, /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ __self_native, /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ __propertyName_native, /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ __value_native)
                {
                    $.$srij.System.Runtime.InteropServices.JavaScript.JSFunctionBinding.InvokeJS($.$srij.System.Runtime.InteropServices.JavaScript.JavaScriptImports.__signature_SetPropertyBool_125660004, $.$$.System.Span$$($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument).op_Implicit$2($.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument), [____arg_exception_native, ____arg_return_native, __self_native, __propertyName_native, __value_native], null, null)));
                }
            }
            //--TRIMMABLE-BOUNDARY-END(141734248459)
            
            //--TRIMMABLE-BOUNDARY-START(60129869835)
            /*global::System.Runtime.InteropServices.JavaScript.JSFunctionBinding*/ static __signature_SetPropertyBool_125660004 = null;
            //--TRIMMABLE-BOUNDARY-END(60129869835)
            
            //--TRIMMABLE-BOUNDARY-START(154619150347)
            static /*void */ SetPropertyInt(/*global::System.Runtime.InteropServices.JavaScript.JSObject*/ self, /*string*/ propertyName, /*int*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(154619150347);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$srij.System.Runtime.InteropServices.JavaScript.JavaScriptImports.__signature_SetPropertyInt_512418141 === null)
                {
                    $.$srij.System.Runtime.InteropServices.JavaScript.JavaScriptImports.__signature_SetPropertyInt_512418141 = $.$srij.System.Runtime.InteropServices.JavaScript.JSFunctionBinding.BindJSFunction("INTERNAL.set_property", null, $.$$.System.ReadOnlySpan$$($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType).op_Implicit$1($.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType), [$.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType.Discard, $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType.JSObject, $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType.String, $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType.Int32], null, null)));
                }
                {
                    /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ let ____arg_exception_native;
                    /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ let ____arg_return_native;
                    /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ let __self_native;
                    /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ let __propertyName_native;
                    /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ let __value_native;
                    $.$$.System.Runtime.CompilerServices.Unsafe.SkipInit($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument, $.$ref(() => ____arg_return_native, ($v) => ____arg_return_native = $v, $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument));
                    ____arg_return_native.Initialize();
                    $.$$.System.Runtime.CompilerServices.Unsafe.SkipInit($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument, $.$ref(() => ____arg_exception_native, ($v) => ____arg_exception_native = $v, $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument));
                    ____arg_exception_native.Initialize();
                    $.$$.System.Runtime.CompilerServices.Unsafe.SkipInit($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument, $.$ref(() => __value_native, ($v) => __value_native = $v, $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument));
                    $.$$.System.Runtime.CompilerServices.Unsafe.SkipInit($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument, $.$ref(() => __propertyName_native, ($v) => __propertyName_native = $v, $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument));
                    $.$$.System.Runtime.CompilerServices.Unsafe.SkipInit($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument, $.$ref(() => __self_native, ($v) => __self_native = $v, $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument));
                    __value_native.ToJS$14(value);
                    __propertyName_native.ToJS$35(propertyName);
                    __self_native.ToJS$39(self);
                    {
                        __InvokeJSFunction.call(this, ____arg_exception_native.Clone(), ____arg_return_native.Clone(), __self_native.Clone(), __propertyName_native.Clone(), __value_native.Clone());
                    }
                }
                /*void*/  function __InvokeJSFunction(/*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ ____arg_exception_native, /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ ____arg_return_native, /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ __self_native, /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ __propertyName_native, /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ __value_native)
                {
                    $.$srij.System.Runtime.InteropServices.JavaScript.JSFunctionBinding.InvokeJS($.$srij.System.Runtime.InteropServices.JavaScript.JavaScriptImports.__signature_SetPropertyInt_512418141, $.$$.System.Span$$($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument).op_Implicit$2($.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument), [____arg_exception_native, ____arg_return_native, __self_native, __propertyName_native, __value_native], null, null)));
                }
            }
            //--TRIMMABLE-BOUNDARY-END(154619150347)
            
            //--TRIMMABLE-BOUNDARY-START(73014771723)
            /*global::System.Runtime.InteropServices.JavaScript.JSFunctionBinding*/ static __signature_SetPropertyInt_512418141 = null;
            //--TRIMMABLE-BOUNDARY-END(73014771723)
            
            //--TRIMMABLE-BOUNDARY-START(150324183051)
            static /*void */ SetPropertyDouble(/*global::System.Runtime.InteropServices.JavaScript.JSObject*/ self, /*string*/ propertyName, /*double*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(150324183051);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$srij.System.Runtime.InteropServices.JavaScript.JavaScriptImports.__signature_SetPropertyDouble_1393852235 === null)
                {
                    $.$srij.System.Runtime.InteropServices.JavaScript.JavaScriptImports.__signature_SetPropertyDouble_1393852235 = $.$srij.System.Runtime.InteropServices.JavaScript.JSFunctionBinding.BindJSFunction("INTERNAL.set_property", null, $.$$.System.ReadOnlySpan$$($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType).op_Implicit$1($.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType), [$.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType.Discard, $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType.JSObject, $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType.String, $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType.Double], null, null)));
                }
                {
                    /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ let ____arg_exception_native;
                    /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ let ____arg_return_native;
                    /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ let __self_native;
                    /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ let __propertyName_native;
                    /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ let __value_native;
                    $.$$.System.Runtime.CompilerServices.Unsafe.SkipInit($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument, $.$ref(() => ____arg_return_native, ($v) => ____arg_return_native = $v, $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument));
                    ____arg_return_native.Initialize();
                    $.$$.System.Runtime.CompilerServices.Unsafe.SkipInit($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument, $.$ref(() => ____arg_exception_native, ($v) => ____arg_exception_native = $v, $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument));
                    ____arg_exception_native.Initialize();
                    $.$$.System.Runtime.CompilerServices.Unsafe.SkipInit($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument, $.$ref(() => __value_native, ($v) => __value_native = $v, $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument));
                    $.$$.System.Runtime.CompilerServices.Unsafe.SkipInit($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument, $.$ref(() => __propertyName_native, ($v) => __propertyName_native = $v, $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument));
                    $.$$.System.Runtime.CompilerServices.Unsafe.SkipInit($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument, $.$ref(() => __self_native, ($v) => __self_native = $v, $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument));
                    __value_native.ToJS$10(value);
                    __propertyName_native.ToJS$35(propertyName);
                    __self_native.ToJS$39(self);
                    {
                        __InvokeJSFunction.call(this, ____arg_exception_native.Clone(), ____arg_return_native.Clone(), __self_native.Clone(), __propertyName_native.Clone(), __value_native.Clone());
                    }
                }
                /*void*/  function __InvokeJSFunction(/*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ ____arg_exception_native, /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ ____arg_return_native, /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ __self_native, /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ __propertyName_native, /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ __value_native)
                {
                    $.$srij.System.Runtime.InteropServices.JavaScript.JSFunctionBinding.InvokeJS($.$srij.System.Runtime.InteropServices.JavaScript.JavaScriptImports.__signature_SetPropertyDouble_1393852235, $.$$.System.Span$$($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument).op_Implicit$2($.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument), [____arg_exception_native, ____arg_return_native, __self_native, __propertyName_native, __value_native], null, null)));
                }
            }
            //--TRIMMABLE-BOUNDARY-END(150324183051)
            
            //--TRIMMABLE-BOUNDARY-START(68719804427)
            /*global::System.Runtime.InteropServices.JavaScript.JSFunctionBinding*/ static __signature_SetPropertyDouble_1393852235 = null;
            //--TRIMMABLE-BOUNDARY-END(68719804427)
            
            //--TRIMMABLE-BOUNDARY-START(163209084939)
            static /*void */ SetPropertyString(/*global::System.Runtime.InteropServices.JavaScript.JSObject*/ self, /*string*/ propertyName, /*string*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(163209084939);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$srij.System.Runtime.InteropServices.JavaScript.JavaScriptImports.__signature_SetPropertyString_1189495691 === null)
                {
                    $.$srij.System.Runtime.InteropServices.JavaScript.JavaScriptImports.__signature_SetPropertyString_1189495691 = $.$srij.System.Runtime.InteropServices.JavaScript.JSFunctionBinding.BindJSFunction("INTERNAL.set_property", null, $.$$.System.ReadOnlySpan$$($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType).op_Implicit$1($.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType), [$.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType.Discard, $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType.JSObject, $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType.String, $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType.String], null, null)));
                }
                {
                    /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ let ____arg_exception_native;
                    /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ let ____arg_return_native;
                    /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ let __self_native;
                    /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ let __propertyName_native;
                    /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ let __value_native;
                    $.$$.System.Runtime.CompilerServices.Unsafe.SkipInit($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument, $.$ref(() => ____arg_return_native, ($v) => ____arg_return_native = $v, $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument));
                    ____arg_return_native.Initialize();
                    $.$$.System.Runtime.CompilerServices.Unsafe.SkipInit($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument, $.$ref(() => ____arg_exception_native, ($v) => ____arg_exception_native = $v, $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument));
                    ____arg_exception_native.Initialize();
                    $.$$.System.Runtime.CompilerServices.Unsafe.SkipInit($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument, $.$ref(() => __value_native, ($v) => __value_native = $v, $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument));
                    $.$$.System.Runtime.CompilerServices.Unsafe.SkipInit($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument, $.$ref(() => __propertyName_native, ($v) => __propertyName_native = $v, $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument));
                    $.$$.System.Runtime.CompilerServices.Unsafe.SkipInit($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument, $.$ref(() => __self_native, ($v) => __self_native = $v, $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument));
                    __value_native.ToJS$35(value);
                    __propertyName_native.ToJS$35(propertyName);
                    __self_native.ToJS$39(self);
                    {
                        __InvokeJSFunction.call(this, ____arg_exception_native.Clone(), ____arg_return_native.Clone(), __self_native.Clone(), __propertyName_native.Clone(), __value_native.Clone());
                    }
                }
                /*void*/  function __InvokeJSFunction(/*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ ____arg_exception_native, /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ ____arg_return_native, /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ __self_native, /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ __propertyName_native, /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ __value_native)
                {
                    $.$srij.System.Runtime.InteropServices.JavaScript.JSFunctionBinding.InvokeJS($.$srij.System.Runtime.InteropServices.JavaScript.JavaScriptImports.__signature_SetPropertyString_1189495691, $.$$.System.Span$$($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument).op_Implicit$2($.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument), [____arg_exception_native, ____arg_return_native, __self_native, __propertyName_native, __value_native], null, null)));
                }
            }
            //--TRIMMABLE-BOUNDARY-END(163209084939)
            
            //--TRIMMABLE-BOUNDARY-START(81604706315)
            /*global::System.Runtime.InteropServices.JavaScript.JSFunctionBinding*/ static __signature_SetPropertyString_1189495691 = null;
            //--TRIMMABLE-BOUNDARY-END(81604706315)
            
            //--TRIMMABLE-BOUNDARY-START(158914117643)
            static /*void */ SetPropertyJSObject(/*global::System.Runtime.InteropServices.JavaScript.JSObject*/ self, /*string*/ propertyName, /*global::System.Runtime.InteropServices.JavaScript.JSObject*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(158914117643);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$srij.System.Runtime.InteropServices.JavaScript.JavaScriptImports.__signature_SetPropertyJSObject_2027749310 === null)
                {
                    $.$srij.System.Runtime.InteropServices.JavaScript.JavaScriptImports.__signature_SetPropertyJSObject_2027749310 = $.$srij.System.Runtime.InteropServices.JavaScript.JSFunctionBinding.BindJSFunction("INTERNAL.set_property", null, $.$$.System.ReadOnlySpan$$($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType).op_Implicit$1($.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType), [$.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType.Discard, $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType.JSObject, $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType.String, $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType.JSObject], null, null)));
                }
                {
                    /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ let ____arg_exception_native;
                    /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ let ____arg_return_native;
                    /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ let __self_native;
                    /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ let __propertyName_native;
                    /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ let __value_native;
                    $.$$.System.Runtime.CompilerServices.Unsafe.SkipInit($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument, $.$ref(() => ____arg_return_native, ($v) => ____arg_return_native = $v, $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument));
                    ____arg_return_native.Initialize();
                    $.$$.System.Runtime.CompilerServices.Unsafe.SkipInit($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument, $.$ref(() => ____arg_exception_native, ($v) => ____arg_exception_native = $v, $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument));
                    ____arg_exception_native.Initialize();
                    $.$$.System.Runtime.CompilerServices.Unsafe.SkipInit($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument, $.$ref(() => __value_native, ($v) => __value_native = $v, $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument));
                    $.$$.System.Runtime.CompilerServices.Unsafe.SkipInit($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument, $.$ref(() => __propertyName_native, ($v) => __propertyName_native = $v, $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument));
                    $.$$.System.Runtime.CompilerServices.Unsafe.SkipInit($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument, $.$ref(() => __self_native, ($v) => __self_native = $v, $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument));
                    __value_native.ToJS$39(value);
                    __propertyName_native.ToJS$35(propertyName);
                    __self_native.ToJS$39(self);
                    {
                        __InvokeJSFunction.call(this, ____arg_exception_native.Clone(), ____arg_return_native.Clone(), __self_native.Clone(), __propertyName_native.Clone(), __value_native.Clone());
                    }
                }
                /*void*/  function __InvokeJSFunction(/*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ ____arg_exception_native, /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ ____arg_return_native, /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ __self_native, /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ __propertyName_native, /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ __value_native)
                {
                    $.$srij.System.Runtime.InteropServices.JavaScript.JSFunctionBinding.InvokeJS($.$srij.System.Runtime.InteropServices.JavaScript.JavaScriptImports.__signature_SetPropertyJSObject_2027749310, $.$$.System.Span$$($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument).op_Implicit$2($.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument), [____arg_exception_native, ____arg_return_native, __self_native, __propertyName_native, __value_native], null, null)));
                }
            }
            //--TRIMMABLE-BOUNDARY-END(158914117643)
            
            //--TRIMMABLE-BOUNDARY-START(77309739019)
            /*global::System.Runtime.InteropServices.JavaScript.JSFunctionBinding*/ static __signature_SetPropertyJSObject_2027749310 = null;
            //--TRIMMABLE-BOUNDARY-END(77309739019)
            
            //--TRIMMABLE-BOUNDARY-START(146029215755)
            static /*void */ SetPropertyBytes(/*global::System.Runtime.InteropServices.JavaScript.JSObject*/ self, /*string*/ propertyName, /*byte[]*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(146029215755);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$srij.System.Runtime.InteropServices.JavaScript.JavaScriptImports.__signature_SetPropertyBytes_1317820772 === null)
                {
                    $.$srij.System.Runtime.InteropServices.JavaScript.JavaScriptImports.__signature_SetPropertyBytes_1317820772 = $.$srij.System.Runtime.InteropServices.JavaScript.JSFunctionBinding.BindJSFunction("INTERNAL.set_property", null, $.$$.System.ReadOnlySpan$$($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType).op_Implicit$1($.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType), [$.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType.Discard, $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType.JSObject, $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType.String, $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType.Array($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType.Byte)], null, null)));
                }
                {
                    /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ let ____arg_exception_native;
                    /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ let ____arg_return_native;
                    /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ let __self_native;
                    /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ let __propertyName_native;
                    /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ let __value_native;
                    $.$$.System.Runtime.CompilerServices.Unsafe.SkipInit($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument, $.$ref(() => ____arg_return_native, ($v) => ____arg_return_native = $v, $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument));
                    ____arg_return_native.Initialize();
                    $.$$.System.Runtime.CompilerServices.Unsafe.SkipInit($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument, $.$ref(() => ____arg_exception_native, ($v) => ____arg_exception_native = $v, $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument));
                    ____arg_exception_native.Initialize();
                    $.$$.System.Runtime.CompilerServices.Unsafe.SkipInit($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument, $.$ref(() => __value_native, ($v) => __value_native = $v, $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument));
                    $.$$.System.Runtime.CompilerServices.Unsafe.SkipInit($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument, $.$ref(() => __propertyName_native, ($v) => __propertyName_native = $v, $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument));
                    $.$$.System.Runtime.CompilerServices.Unsafe.SkipInit($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument, $.$ref(() => __self_native, ($v) => __self_native = $v, $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument));
                    __value_native.ToJS$6(value);
                    __propertyName_native.ToJS$35(propertyName);
                    __self_native.ToJS$39(self);
                    {
                        __InvokeJSFunction.call(this, ____arg_exception_native.Clone(), ____arg_return_native.Clone(), __self_native.Clone(), __propertyName_native.Clone(), __value_native.Clone());
                    }
                }
                /*void*/  function __InvokeJSFunction(/*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ ____arg_exception_native, /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ ____arg_return_native, /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ __self_native, /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ __propertyName_native, /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ __value_native)
                {
                    $.$srij.System.Runtime.InteropServices.JavaScript.JSFunctionBinding.InvokeJS($.$srij.System.Runtime.InteropServices.JavaScript.JavaScriptImports.__signature_SetPropertyBytes_1317820772, $.$$.System.Span$$($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument).op_Implicit$2($.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument), [____arg_exception_native, ____arg_return_native, __self_native, __propertyName_native, __value_native], null, null)));
                }
            }
            //--TRIMMABLE-BOUNDARY-END(146029215755)
            
            //--TRIMMABLE-BOUNDARY-START(64424837131)
            /*global::System.Runtime.InteropServices.JavaScript.JSFunctionBinding*/ static __signature_SetPropertyBytes_1317820772 = null;
            //--TRIMMABLE-BOUNDARY-END(64424837131)
            
            //--TRIMMABLE-BOUNDARY-START(98784575499)
            static /*global::System.Runtime.InteropServices.JavaScript.JSObject */ GetGlobalThis()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(98784575499);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$srij.System.Runtime.InteropServices.JavaScript.JavaScriptImports.__signature_GetGlobalThis_1202228629 === null)
                {
                    $.$srij.System.Runtime.InteropServices.JavaScript.JavaScriptImports.__signature_GetGlobalThis_1202228629 = $.$srij.System.Runtime.InteropServices.JavaScript.JSFunctionBinding.BindJSFunction("INTERNAL.get_global_this", null, $.$$.System.ReadOnlySpan$$($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType).op_Implicit$1($.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType), [$.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType.JSObject], null, null)));
                }
                {
                    /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ let ____arg_exception_native;
                    /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ let ____arg_return_native;
                    /*global::System.Runtime.InteropServices.JavaScript.JSObject*/ let __retVal;
                    /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ let __retVal_native;
                    $.$$.System.Runtime.CompilerServices.Unsafe.SkipInit($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument, $.$ref(() => ____arg_return_native, ($v) => ____arg_return_native = $v, $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument));
                    ____arg_return_native.Initialize();
                    $.$$.System.Runtime.CompilerServices.Unsafe.SkipInit($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument, $.$ref(() => ____arg_exception_native, ($v) => ____arg_exception_native = $v, $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument));
                    ____arg_exception_native.Initialize();
                    {
                        __retVal_native = __InvokeJSFunction.call(this, ____arg_exception_native.Clone(), ____arg_return_native.Clone());
                    }
                    __retVal_native.ToManaged$39($.$ref(() => __retVal, ($v) => __retVal = $v, $.$srij.System.Runtime.InteropServices.JavaScript.JSObject));
                    return __retVal;
                }
                /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/  function __InvokeJSFunction(/*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ ____arg_exception_native, /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ ____arg_return_native)
                {
                    /*global::System.Span<global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument>*/ let __arguments_buffer = $.$$.System.Span$$($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument).op_Implicit$2($.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument), [____arg_exception_native, ____arg_return_native], null, null));
                    $.$srij.System.Runtime.InteropServices.JavaScript.JSFunctionBinding.InvokeJS($.$srij.System.Runtime.InteropServices.JavaScript.JavaScriptImports.__signature_GetGlobalThis_1202228629, __arguments_buffer);
                    return __arguments_buffer.get_Item(1).$v;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(98784575499)
            
            //--TRIMMABLE-BOUNDARY-START(17180196875)
            /*global::System.Runtime.InteropServices.JavaScript.JSFunctionBinding*/ static __signature_GetGlobalThis_1202228629 = null;
            //--TRIMMABLE-BOUNDARY-END(17180196875)
            
            //--TRIMMABLE-BOUNDARY-START(94489608203)
            static /*global::System.Runtime.InteropServices.JavaScript.JSObject */ GetDotnetInstance()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(94489608203);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$srij.System.Runtime.InteropServices.JavaScript.JavaScriptImports.__signature_GetDotnetInstance_1202228629 === null)
                {
                    $.$srij.System.Runtime.InteropServices.JavaScript.JavaScriptImports.__signature_GetDotnetInstance_1202228629 = $.$srij.System.Runtime.InteropServices.JavaScript.JSFunctionBinding.BindJSFunction("INTERNAL.get_dotnet_instance", null, $.$$.System.ReadOnlySpan$$($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType).op_Implicit$1($.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType), [$.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType.JSObject], null, null)));
                }
                {
                    /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ let ____arg_exception_native;
                    /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ let ____arg_return_native;
                    /*global::System.Runtime.InteropServices.JavaScript.JSObject*/ let __retVal;
                    /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ let __retVal_native;
                    $.$$.System.Runtime.CompilerServices.Unsafe.SkipInit($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument, $.$ref(() => ____arg_return_native, ($v) => ____arg_return_native = $v, $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument));
                    ____arg_return_native.Initialize();
                    $.$$.System.Runtime.CompilerServices.Unsafe.SkipInit($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument, $.$ref(() => ____arg_exception_native, ($v) => ____arg_exception_native = $v, $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument));
                    ____arg_exception_native.Initialize();
                    {
                        __retVal_native = __InvokeJSFunction.call(this, ____arg_exception_native.Clone(), ____arg_return_native.Clone());
                    }
                    __retVal_native.ToManaged$39($.$ref(() => __retVal, ($v) => __retVal = $v, $.$srij.System.Runtime.InteropServices.JavaScript.JSObject));
                    return __retVal;
                }
                /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/  function __InvokeJSFunction(/*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ ____arg_exception_native, /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ ____arg_return_native)
                {
                    /*global::System.Span<global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument>*/ let __arguments_buffer = $.$$.System.Span$$($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument).op_Implicit$2($.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument), [____arg_exception_native, ____arg_return_native], null, null));
                    $.$srij.System.Runtime.InteropServices.JavaScript.JSFunctionBinding.InvokeJS($.$srij.System.Runtime.InteropServices.JavaScript.JavaScriptImports.__signature_GetDotnetInstance_1202228629, __arguments_buffer);
                    return __arguments_buffer.get_Item(1).$v;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(94489608203)
            
            //--TRIMMABLE-BOUNDARY-START(12885229579)
            /*global::System.Runtime.InteropServices.JavaScript.JSFunctionBinding*/ static __signature_GetDotnetInstance_1202228629 = null;
            //--TRIMMABLE-BOUNDARY-END(12885229579)
            
            //--TRIMMABLE-BOUNDARY-START(90194640907)
            static /*global::System.Threading.Tasks.Task<global::System.Runtime.InteropServices.JavaScript.JSObject> */ DynamicImport(/*string*/ moduleName, /*string*/ moduleUrl)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(90194640907);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$srij.System.Runtime.InteropServices.JavaScript.JavaScriptImports.__signature_DynamicImport_119536130 === null)
                {
                    $.$srij.System.Runtime.InteropServices.JavaScript.JavaScriptImports.__signature_DynamicImport_119536130 = $.$srij.System.Runtime.InteropServices.JavaScript.JSFunctionBinding.BindJSFunction("INTERNAL.dynamic_import", null, $.$$.System.ReadOnlySpan$$($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType).op_Implicit$1($.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType), [$.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType.Task$1($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType.JSObject), $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType.String, $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType.String], null, null)));
                }
                {
                    /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ let ____arg_exception_native;
                    /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ let ____arg_return_native;
                    /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ let __moduleName_native;
                    /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ let __moduleUrl_native;
                    /*global::System.Threading.Tasks.Task<global::System.Runtime.InteropServices.JavaScript.JSObject>*/ let __retVal;
                    /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ let __retVal_native;
                    $.$$.System.Runtime.CompilerServices.Unsafe.SkipInit($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument, $.$ref(() => ____arg_return_native, ($v) => ____arg_return_native = $v, $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument));
                    ____arg_return_native.Initialize();
                    $.$$.System.Runtime.CompilerServices.Unsafe.SkipInit($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument, $.$ref(() => ____arg_exception_native, ($v) => ____arg_exception_native = $v, $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument));
                    ____arg_exception_native.Initialize();
                    $.$$.System.Runtime.CompilerServices.Unsafe.SkipInit($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument, $.$ref(() => __moduleUrl_native, ($v) => __moduleUrl_native = $v, $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument));
                    $.$$.System.Runtime.CompilerServices.Unsafe.SkipInit($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument, $.$ref(() => __moduleName_native, ($v) => __moduleName_native = $v, $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument));
                    __moduleUrl_native.ToJS$35(moduleUrl);
                    __moduleName_native.ToJS$35(moduleName);
                    {
                        __retVal_native = __InvokeJSFunction.call(this, ____arg_exception_native.Clone(), ____arg_return_native.Clone(), __moduleName_native.Clone(), __moduleUrl_native.Clone());
                    }
                    __retVal_native.ToManaged$43($.$srij.System.Runtime.InteropServices.JavaScript.JSObject, $.$ref(() => __retVal, ($v) => __retVal = $v, $.$$.System.Threading.Tasks.Task$$($.$srij.System.Runtime.InteropServices.JavaScript.JSObject)), new ($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument.ArgumentToManagedCallback$$($.$srij.System.Runtime.InteropServices.JavaScript.JSObject))().$ctor($.$srij.System.Runtime.InteropServices.JavaScript.JavaScriptImports, /*static*/ (/*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ __task_result_arg, /*global::System.Runtime.InteropServices.JavaScript.JSObject*/ __task_result) =>
                    {
                        __task_result_arg.$v.ToManaged$39(__task_result);
                    }, {
  "r": 65537,
  "p": [
    {
      "n": "__task_result_arg",
      "p": 1310731,
      "f": 4
    },
    {
      "n": "__task_result",
      "p": 2228235,
      "f": 2
    }
  ],
  "n": "",
  "d": 327691,
  "h": 0,
  "f": 17825826
}));
                    return __retVal;
                }
                /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/  function __InvokeJSFunction(/*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ ____arg_exception_native, /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ ____arg_return_native, /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ __moduleName_native, /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ __moduleUrl_native)
                {
                    /*global::System.Span<global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument>*/ let __arguments_buffer = $.$$.System.Span$$($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument).op_Implicit$2($.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument), [____arg_exception_native, ____arg_return_native, __moduleName_native, __moduleUrl_native], null, null));
                    $.$srij.System.Runtime.InteropServices.JavaScript.JSFunctionBinding.InvokeJS($.$srij.System.Runtime.InteropServices.JavaScript.JavaScriptImports.__signature_DynamicImport_119536130, __arguments_buffer);
                    return __arguments_buffer.get_Item(1).$v;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(90194640907)
            
            //--TRIMMABLE-BOUNDARY-START(8590262283)
            /*global::System.Runtime.InteropServices.JavaScript.JSFunctionBinding*/ static __signature_DynamicImport_119536130 = null;
            //--TRIMMABLE-BOUNDARY-END(8590262283)
            
            //--TRIMMABLE-BOUNDARY-START(85899673611)
            static /*void */ BindCSFunction(/*nint*/ monoMethod, /*string*/ assemblyName, /*string*/ namespaceName, /*string*/ shortClassName, /*string*/ methodName, /*int*/ signatureHash, /*nint*/ signature)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(85899673611);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$srij.System.Runtime.InteropServices.JavaScript.JavaScriptImports.__signature_BindCSFunction_1080107758 === null)
                {
                    $.$srij.System.Runtime.InteropServices.JavaScript.JavaScriptImports.__signature_BindCSFunction_1080107758 = $.$srij.System.Runtime.InteropServices.JavaScript.JSFunctionBinding.BindJSFunction("INTERNAL.mono_wasm_bind_cs_function", null, $.$$.System.ReadOnlySpan$$($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType).op_Implicit$1($.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType), [$.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType.Discard, $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType.IntPtr, $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType.String, $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType.String, $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType.String, $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType.String, $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType.Int32, $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType.IntPtr], null, null)));
                }
                {
                    /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ let ____arg_exception_native;
                    /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ let ____arg_return_native;
                    /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ let __monoMethod_native;
                    /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ let __assemblyName_native;
                    /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ let __namespaceName_native;
                    /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ let __shortClassName_native;
                    /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ let __methodName_native;
                    /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ let __signatureHash_native;
                    /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ let __signature_native;
                    $.$$.System.Runtime.CompilerServices.Unsafe.SkipInit($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument, $.$ref(() => ____arg_return_native, ($v) => ____arg_return_native = $v, $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument));
                    ____arg_return_native.Initialize();
                    $.$$.System.Runtime.CompilerServices.Unsafe.SkipInit($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument, $.$ref(() => ____arg_exception_native, ($v) => ____arg_exception_native = $v, $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument));
                    ____arg_exception_native.Initialize();
                    $.$$.System.Runtime.CompilerServices.Unsafe.SkipInit($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument, $.$ref(() => __signature_native, ($v) => __signature_native = $v, $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument));
                    $.$$.System.Runtime.CompilerServices.Unsafe.SkipInit($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument, $.$ref(() => __signatureHash_native, ($v) => __signatureHash_native = $v, $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument));
                    $.$$.System.Runtime.CompilerServices.Unsafe.SkipInit($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument, $.$ref(() => __methodName_native, ($v) => __methodName_native = $v, $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument));
                    $.$$.System.Runtime.CompilerServices.Unsafe.SkipInit($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument, $.$ref(() => __shortClassName_native, ($v) => __shortClassName_native = $v, $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument));
                    $.$$.System.Runtime.CompilerServices.Unsafe.SkipInit($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument, $.$ref(() => __namespaceName_native, ($v) => __namespaceName_native = $v, $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument));
                    $.$$.System.Runtime.CompilerServices.Unsafe.SkipInit($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument, $.$ref(() => __assemblyName_native, ($v) => __assemblyName_native = $v, $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument));
                    $.$$.System.Runtime.CompilerServices.Unsafe.SkipInit($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument, $.$ref(() => __monoMethod_native, ($v) => __monoMethod_native = $v, $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument));
                    __signature_native.ToJS$17(signature);
                    __signatureHash_native.ToJS$14(signatureHash);
                    __methodName_native.ToJS$35(methodName);
                    __shortClassName_native.ToJS$35(shortClassName);
                    __namespaceName_native.ToJS$35(namespaceName);
                    __assemblyName_native.ToJS$35(assemblyName);
                    __monoMethod_native.ToJS$17(monoMethod);
                    {
                        __InvokeJSFunction.call(this, ____arg_exception_native.Clone(), ____arg_return_native.Clone(), __monoMethod_native.Clone(), __assemblyName_native.Clone(), __namespaceName_native.Clone(), __shortClassName_native.Clone(), __methodName_native.Clone(), __signatureHash_native.Clone(), __signature_native.Clone());
                    }
                }
                /*void*/  function __InvokeJSFunction(/*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ ____arg_exception_native, /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ ____arg_return_native, /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ __monoMethod_native, /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ __assemblyName_native, /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ __namespaceName_native, /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ __shortClassName_native, /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ __methodName_native, /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ __signatureHash_native, /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ __signature_native)
                {
                    $.$srij.System.Runtime.InteropServices.JavaScript.JSFunctionBinding.InvokeJS($.$srij.System.Runtime.InteropServices.JavaScript.JavaScriptImports.__signature_BindCSFunction_1080107758, $.$$.System.Span$$($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument).op_Implicit$2($.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument), [____arg_exception_native, ____arg_return_native, __monoMethod_native, __assemblyName_native, __namespaceName_native, __shortClassName_native, __methodName_native, __signatureHash_native, __signature_native], null, null)));
                }
            }
            //--TRIMMABLE-BOUNDARY-END(85899673611)
            
            //--TRIMMABLE-BOUNDARY-START(4295294987)
            /*global::System.Runtime.InteropServices.JavaScript.JSFunctionBinding*/ static __signature_BindCSFunction_1080107758 = null;
            //--TRIMMABLE-BOUNDARY-END(4295294987)
            
            //--TRIMMABLE-BOUNDARY-START(137439281163)
            static /*void */ Log(/*string*/ message)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(137439281163);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$srij.System.Runtime.InteropServices.JavaScript.JavaScriptImports.__signature_Log_92020726 === null)
                {
                    $.$srij.System.Runtime.InteropServices.JavaScript.JavaScriptImports.__signature_Log_92020726 = $.$srij.System.Runtime.InteropServices.JavaScript.JSFunctionBinding.BindJSFunction("globalThis.console.log", null, $.$$.System.ReadOnlySpan$$($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType).op_Implicit$1($.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType), [$.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType.DiscardNoWait, $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType.String], null, null)));
                }
                {
                    /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ let ____arg_exception_native;
                    /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ let ____arg_return_native;
                    /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ let __message_native;
                    $.$$.System.Runtime.CompilerServices.Unsafe.SkipInit($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument, $.$ref(() => ____arg_return_native, ($v) => ____arg_return_native = $v, $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument));
                    ____arg_return_native.Initialize();
                    $.$$.System.Runtime.CompilerServices.Unsafe.SkipInit($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument, $.$ref(() => ____arg_exception_native, ($v) => ____arg_exception_native = $v, $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument));
                    ____arg_exception_native.Initialize();
                    $.$$.System.Runtime.CompilerServices.Unsafe.SkipInit($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument, $.$ref(() => __message_native, ($v) => __message_native = $v, $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument));
                    __message_native.ToJS$35(message);
                    {
                        __InvokeJSFunction.call(this, ____arg_exception_native.Clone(), ____arg_return_native.Clone(), __message_native.Clone());
                    }
                }
                /*void*/  function __InvokeJSFunction(/*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ ____arg_exception_native, /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ ____arg_return_native, /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ __message_native)
                {
                    $.$srij.System.Runtime.InteropServices.JavaScript.JSFunctionBinding.InvokeJS($.$srij.System.Runtime.InteropServices.JavaScript.JavaScriptImports.__signature_Log_92020726, $.$$.System.Span$$($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument).op_Implicit$2($.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument), [____arg_exception_native, ____arg_return_native, __message_native], null, null)));
                }
            }
            //--TRIMMABLE-BOUNDARY-END(137439281163)
            
            //--TRIMMABLE-BOUNDARY-START(55834902539)
            /*global::System.Runtime.InteropServices.JavaScript.JSFunctionBinding*/ static __signature_Log_92020726 = null;
            //--TRIMMABLE-BOUNDARY-END(55834902539)
            
            static $h = 327691;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 131073,
  "m": [
//--TRIMMABLE-BOUNDARY-START(133144313867),
    {
      "r": 262145,
      "p": [
        {
          "n": "self",
          "p": 2228235
        },
        {
          "n": "propertyName",
          "p": 1310721
        }
      ],
      "n": "HasProperty",
      "d": 327691,
      "h": 133144313867,
      "f": 16777249,
      "a": [
        {
          "t": 1179659,
          "c": 17181048843,
          "a": [
            {
              "v": "INTERNAL.has_property",
              "t": 1310721
            }
          ]
        },
        {
          "t": 70516737,
          "c": 4365484033
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(133144313867),
//--TRIMMABLE-BOUNDARY-START(128849346571),
    {
      "r": 1310721,
      "p": [
        {
          "n": "self",
          "p": 2228235
        },
        {
          "n": "propertyName",
          "p": 1310721
        }
      ],
      "n": "GetTypeOfProperty",
      "d": 327691,
      "h": 128849346571,
      "f": 16777249,
      "a": [
        {
          "t": 1179659,
          "c": 17181048843,
          "a": [
            {
              "v": "INTERNAL.get_typeof_property",
              "t": 1310721
            }
          ]
        },
        {
          "t": 70516737,
          "c": 4365484033
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(128849346571),
//--TRIMMABLE-BOUNDARY-START(103079542795),
    {
      "r": 262145,
      "p": [
        {
          "n": "self",
          "p": 2228235
        },
        {
          "n": "propertyName",
          "p": 1310721
        }
      ],
      "n": "GetPropertyAsBoolean",
      "d": 327691,
      "h": 103079542795,
      "f": 16777249,
      "a": [
        {
          "t": 1179659,
          "c": 17181048843,
          "a": [
            {
              "v": "INTERNAL.get_property",
              "t": 1310721
            }
          ]
        },
        {
          "t": 70516737,
          "c": 4365484033
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(103079542795),
//--TRIMMABLE-BOUNDARY-START(115964444683),
    {
      "r": 655361,
      "p": [
        {
          "n": "self",
          "p": 2228235
        },
        {
          "n": "propertyName",
          "p": 1310721
        }
      ],
      "n": "GetPropertyAsInt32",
      "d": 327691,
      "h": 115964444683,
      "f": 16777249,
      "a": [
        {
          "t": 1179659,
          "c": 17181048843,
          "a": [
            {
              "v": "INTERNAL.get_property",
              "t": 1310721
            }
          ]
        },
        {
          "t": 70516737,
          "c": 4365484033
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(115964444683),
//--TRIMMABLE-BOUNDARY-START(111669477387),
    {
      "r": 1179649,
      "p": [
        {
          "n": "self",
          "p": 2228235
        },
        {
          "n": "propertyName",
          "p": 1310721
        }
      ],
      "n": "GetPropertyAsDouble",
      "d": 327691,
      "h": 111669477387,
      "f": 16777249,
      "a": [
        {
          "t": 1179659,
          "c": 17181048843,
          "a": [
            {
              "v": "INTERNAL.get_property",
              "t": 1310721
            }
          ]
        },
        {
          "t": 70516737,
          "c": 4365484033
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(111669477387),
//--TRIMMABLE-BOUNDARY-START(124554379275),
    {
      "r": 1310721,
      "p": [
        {
          "n": "self",
          "p": 2228235
        },
        {
          "n": "propertyName",
          "p": 1310721
        }
      ],
      "n": "GetPropertyAsString",
      "d": 327691,
      "h": 124554379275,
      "f": 16777249,
      "a": [
        {
          "t": 1179659,
          "c": 17181048843,
          "a": [
            {
              "v": "INTERNAL.get_property",
              "t": 1310721
            }
          ]
        },
        {
          "t": 70516737,
          "c": 4365484033
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(124554379275),
//--TRIMMABLE-BOUNDARY-START(120259411979),
    {
      "r": 2228235,
      "p": [
        {
          "n": "self",
          "p": 2228235
        },
        {
          "n": "propertyName",
          "p": 1310721
        }
      ],
      "n": "GetPropertyAsJSObject",
      "d": 327691,
      "h": 120259411979,
      "f": 16777249,
      "a": [
        {
          "t": 1179659,
          "c": 17181048843,
          "a": [
            {
              "v": "INTERNAL.get_property",
              "t": 1310721
            }
          ]
        },
        {
          "t": 70516737,
          "c": 4365484033
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(120259411979),
//--TRIMMABLE-BOUNDARY-START(107374510091),
    {
      "r": $.$typeArray($.$$.System.Byte).$h,
      "p": [
        {
          "n": "self",
          "p": 2228235
        },
        {
          "n": "propertyName",
          "p": 1310721
        }
      ],
      "n": "GetPropertyAsByteArray",
      "d": 327691,
      "h": 107374510091,
      "f": 16777249,
      "a": [
        {
          "t": 1179659,
          "c": 17181048843,
          "a": [
            {
              "v": "INTERNAL.get_property",
              "t": 1310721
            }
          ]
        },
        {
          "t": 70516737,
          "c": 4365484033
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(107374510091),
//--TRIMMABLE-BOUNDARY-START(141734248459),
    {
      "r": 65537,
      "p": [
        {
          "n": "self",
          "p": 2228235
        },
        {
          "n": "propertyName",
          "p": 1310721
        },
        {
          "n": "value",
          "p": 262145
        }
      ],
      "n": "SetPropertyBool",
      "d": 327691,
      "h": 141734248459,
      "f": 16777249,
      "a": [
        {
          "t": 1179659,
          "c": 17181048843,
          "a": [
            {
              "v": "INTERNAL.set_property",
              "t": 1310721
            }
          ]
        },
        {
          "t": 70516737,
          "c": 4365484033
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(141734248459),
//--TRIMMABLE-BOUNDARY-START(154619150347),
    {
      "r": 65537,
      "p": [
        {
          "n": "self",
          "p": 2228235
        },
        {
          "n": "propertyName",
          "p": 1310721
        },
        {
          "n": "value",
          "p": 655361
        }
      ],
      "n": "SetPropertyInt",
      "d": 327691,
      "h": 154619150347,
      "f": 16777249,
      "a": [
        {
          "t": 1179659,
          "c": 17181048843,
          "a": [
            {
              "v": "INTERNAL.set_property",
              "t": 1310721
            }
          ]
        },
        {
          "t": 70516737,
          "c": 4365484033
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(154619150347),
//--TRIMMABLE-BOUNDARY-START(150324183051),
    {
      "r": 65537,
      "p": [
        {
          "n": "self",
          "p": 2228235
        },
        {
          "n": "propertyName",
          "p": 1310721
        },
        {
          "n": "value",
          "p": 1179649
        }
      ],
      "n": "SetPropertyDouble",
      "d": 327691,
      "h": 150324183051,
      "f": 16777249,
      "a": [
        {
          "t": 1179659,
          "c": 17181048843,
          "a": [
            {
              "v": "INTERNAL.set_property",
              "t": 1310721
            }
          ]
        },
        {
          "t": 70516737,
          "c": 4365484033
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(150324183051),
//--TRIMMABLE-BOUNDARY-START(163209084939),
    {
      "r": 65537,
      "p": [
        {
          "n": "self",
          "p": 2228235
        },
        {
          "n": "propertyName",
          "p": 1310721
        },
        {
          "n": "value",
          "p": 1310721
        }
      ],
      "n": "SetPropertyString",
      "d": 327691,
      "h": 163209084939,
      "f": 16777249,
      "a": [
        {
          "t": 1179659,
          "c": 17181048843,
          "a": [
            {
              "v": "INTERNAL.set_property",
              "t": 1310721
            }
          ]
        },
        {
          "t": 70516737,
          "c": 4365484033
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(163209084939),
//--TRIMMABLE-BOUNDARY-START(158914117643),
    {
      "r": 65537,
      "p": [
        {
          "n": "self",
          "p": 2228235
        },
        {
          "n": "propertyName",
          "p": 1310721
        },
        {
          "n": "value",
          "p": 2228235
        }
      ],
      "n": "SetPropertyJSObject",
      "d": 327691,
      "h": 158914117643,
      "f": 16777249,
      "a": [
        {
          "t": 1179659,
          "c": 17181048843,
          "a": [
            {
              "v": "INTERNAL.set_property",
              "t": 1310721
            }
          ]
        },
        {
          "t": 70516737,
          "c": 4365484033
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(158914117643),
//--TRIMMABLE-BOUNDARY-START(146029215755),
    {
      "r": 65537,
      "p": [
        {
          "n": "self",
          "p": 2228235
        },
        {
          "n": "propertyName",
          "p": 1310721
        },
        {
          "n": "value",
          "p": $.$typeArray($.$$.System.Byte).$h
        }
      ],
      "n": "SetPropertyBytes",
      "d": 327691,
      "h": 146029215755,
      "f": 16777249,
      "a": [
        {
          "t": 1179659,
          "c": 17181048843,
          "a": [
            {
              "v": "INTERNAL.set_property",
              "t": 1310721
            }
          ]
        },
        {
          "t": 70516737,
          "c": 4365484033
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(146029215755),
//--TRIMMABLE-BOUNDARY-START(98784575499),
    {
      "r": 2228235,
      "n": "GetGlobalThis",
      "d": 327691,
      "h": 98784575499,
      "f": 16777249,
      "a": [
        {
          "t": 1179659,
          "c": 17181048843,
          "a": [
            {
              "v": "INTERNAL.get_global_this",
              "t": 1310721
            }
          ]
        },
        {
          "t": 70516737,
          "c": 4365484033
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(98784575499),
//--TRIMMABLE-BOUNDARY-START(94489608203),
    {
      "r": 2228235,
      "n": "GetDotnetInstance",
      "d": 327691,
      "h": 94489608203,
      "f": 16777249,
      "a": [
        {
          "t": 1179659,
          "c": 17181048843,
          "a": [
            {
              "v": "INTERNAL.get_dotnet_instance",
              "t": 1310721
            }
          ]
        },
        {
          "t": 70516737,
          "c": 4365484033
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(94489608203),
//--TRIMMABLE-BOUNDARY-START(90194640907),
    {
      "r": $.$$.System.Threading.Tasks.Task$$($.$srij.System.Runtime.InteropServices.JavaScript.JSObject).$h,
      "p": [
        {
          "n": "moduleName",
          "p": 1310721
        },
        {
          "n": "moduleUrl",
          "p": 1310721
        }
      ],
      "n": "DynamicImport",
      "d": 327691,
      "h": 90194640907,
      "f": 16777249,
      "a": [
        {
          "t": 1179659,
          "c": 17181048843,
          "a": [
            {
              "v": "INTERNAL.dynamic_import",
              "t": 1310721
            }
          ]
        },
        {
          "t": 70516737,
          "c": 4365484033
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(90194640907),
//--TRIMMABLE-BOUNDARY-START(85899673611),
    {
      "r": 65537,
      "p": [
        {
          "n": "monoMethod",
          "p": 786433
        },
        {
          "n": "assemblyName",
          "p": 1310721
        },
        {
          "n": "namespaceName",
          "p": 1310721
        },
        {
          "n": "shortClassName",
          "p": 1310721
        },
        {
          "n": "methodName",
          "p": 1310721
        },
        {
          "n": "signatureHash",
          "p": 655361
        },
        {
          "n": "signature",
          "p": 786433
        }
      ],
      "n": "BindCSFunction",
      "d": 327691,
      "h": 85899673611,
      "f": 16777249,
      "a": [
        {
          "t": 1179659,
          "c": 17181048843,
          "a": [
            {
              "v": "INTERNAL.mono_wasm_bind_cs_function",
              "t": 1310721
            }
          ]
        },
        {
          "t": 70516737,
          "c": 4365484033
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(85899673611),
//--TRIMMABLE-BOUNDARY-START(137439281163),
    {
      "r": 65537,
      "p": [
        {
          "n": "message",
          "p": 1310721,
          "a": [
            {
              "t": $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalAsAttribute$$($.$srij.System.Runtime.InteropServices.JavaScript.JSType.String).$h,
              "c": Number(BigInt($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalAsAttribute$$($.$srij.System.Runtime.InteropServices.JavaScript.JSType.String).$h)|0x100000000n)
            }
          ]
        }
      ],
      "n": "Log",
      "d": 327691,
      "h": 137439281163,
      "f": 16777249,
      "a": [
        {
          "t": 1179659,
          "c": 17181048843,
          "a": [
            {
              "v": "globalThis.console.log",
              "t": 1310721
            }
          ]
        },
        {
          "t": 70516737,
          "c": 4365484033
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(137439281163)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(51539935243),
    {
      "t": 524299,
      "n": "__signature_HasProperty_393970128",
      "d": 327691,
      "h": 51539935243,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(51539935243),
//--TRIMMABLE-BOUNDARY-START(47244967947),
    {
      "t": 524299,
      "n": "__signature_GetTypeOfProperty_1139574135",
      "d": 327691,
      "h": 47244967947,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(47244967947),
//--TRIMMABLE-BOUNDARY-START(21475164171),
    {
      "t": 524299,
      "n": "__signature_GetPropertyAsBoolean_393970128",
      "d": 327691,
      "h": 21475164171,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(21475164171),
//--TRIMMABLE-BOUNDARY-START(34360066059),
    {
      "t": 524299,
      "n": "__signature_GetPropertyAsInt32_1813830729",
      "d": 327691,
      "h": 34360066059,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(34360066059),
//--TRIMMABLE-BOUNDARY-START(30065098763),
    {
      "t": 524299,
      "n": "__signature_GetPropertyAsDouble_705601847",
      "d": 327691,
      "h": 30065098763,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(30065098763),
//--TRIMMABLE-BOUNDARY-START(42950000651),
    {
      "t": 524299,
      "n": "__signature_GetPropertyAsString_1139574135",
      "d": 327691,
      "h": 42950000651,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(42950000651),
//--TRIMMABLE-BOUNDARY-START(38655033355),
    {
      "t": 524299,
      "n": "__signature_GetPropertyAsJSObject_1480020778",
      "d": 327691,
      "h": 38655033355,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(38655033355),
//--TRIMMABLE-BOUNDARY-START(25770131467),
    {
      "t": 524299,
      "n": "__signature_GetPropertyAsByteArray_657551312",
      "d": 327691,
      "h": 25770131467,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(25770131467),
//--TRIMMABLE-BOUNDARY-START(60129869835),
    {
      "t": 524299,
      "n": "__signature_SetPropertyBool_125660004",
      "d": 327691,
      "h": 60129869835,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(60129869835),
//--TRIMMABLE-BOUNDARY-START(73014771723),
    {
      "t": 524299,
      "n": "__signature_SetPropertyInt_512418141",
      "d": 327691,
      "h": 73014771723,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(73014771723),
//--TRIMMABLE-BOUNDARY-START(68719804427),
    {
      "t": 524299,
      "n": "__signature_SetPropertyDouble_1393852235",
      "d": 327691,
      "h": 68719804427,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(68719804427),
//--TRIMMABLE-BOUNDARY-START(81604706315),
    {
      "t": 524299,
      "n": "__signature_SetPropertyString_1189495691",
      "d": 327691,
      "h": 81604706315,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(81604706315),
//--TRIMMABLE-BOUNDARY-START(77309739019),
    {
      "t": 524299,
      "n": "__signature_SetPropertyJSObject_2027749310",
      "d": 327691,
      "h": 77309739019,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(77309739019),
//--TRIMMABLE-BOUNDARY-START(64424837131),
    {
      "t": 524299,
      "n": "__signature_SetPropertyBytes_1317820772",
      "d": 327691,
      "h": 64424837131,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(64424837131),
//--TRIMMABLE-BOUNDARY-START(17180196875),
    {
      "t": 524299,
      "n": "__signature_GetGlobalThis_1202228629",
      "d": 327691,
      "h": 17180196875,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(17180196875),
//--TRIMMABLE-BOUNDARY-START(12885229579),
    {
      "t": 524299,
      "n": "__signature_GetDotnetInstance_1202228629",
      "d": 327691,
      "h": 12885229579,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(12885229579),
//--TRIMMABLE-BOUNDARY-START(8590262283),
    {
      "t": 524299,
      "n": "__signature_DynamicImport_119536130",
      "d": 327691,
      "h": 8590262283,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(8590262283),
//--TRIMMABLE-BOUNDARY-START(4295294987),
    {
      "t": 524299,
      "n": "__signature_BindCSFunction_1080107758",
      "d": 327691,
      "h": 4295294987,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(4295294987),
//--TRIMMABLE-BOUNDARY-START(55834902539),
    {
      "t": 524299,
      "n": "__signature_Log_92020726",
      "d": 327691,
      "h": 55834902539,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(55834902539)
  ],
  "h": 327691
}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `System.Runtime.InteropServices.JavaScript.JavaScriptImports`; }
        });
        //--TRIMMABLE-BOUNDARY-END(327691)
        
        
        //--TRIMMABLE-BOUNDARY-START(720907)
        $asm.$cls("$srij.System.Runtime.InteropServices.JavaScript.JSHost", ($self) => class JSHost
        {
            //--TRIMMABLE-BOUNDARY-START(25770524683)
            static /*JSObject */ get GlobalThis()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21475557387);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return INTERNAL.get_global_this();
            }
            //--TRIMMABLE-BOUNDARY-END(25770524683)
            
            //--TRIMMABLE-BOUNDARY-START(4295688203)
            static /*JSObject */ get DotnetInstance()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12885622795);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return INTERNAL.get_dotnet_instance();
            }
            //--TRIMMABLE-BOUNDARY-END(4295688203)
            
            //--TRIMMABLE-BOUNDARY-START(30065491979)
            static /*Task<JSObject> */ ImportAsync(/*string*/ moduleName, /*string*/ moduleUrl, /*CancellationToken*/ cancellationToken)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(30065491979);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$srij.System.Runtime.InteropServices.JavaScript.JSHostImplementation.ImportAsync(moduleName, moduleUrl, cancellationToken);
            }
            //--TRIMMABLE-BOUNDARY-END(30065491979)
            
            static $h = 720907;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 131073,
  "p": [
//--TRIMMABLE-BOUNDARY-START(25770524683),
    {
      "p": 2228235,
      "g": {
        "r": 0,
        "d": 0,
        "h": 21475557387,
        "f": 50331681
      },
      "n": "GlobalThis",
      "d": 720907,
      "h": 25770524683,
      "f": 2097185
    },
//--TRIMMABLE-BOUNDARY-END(25770524683),
//--TRIMMABLE-BOUNDARY-START(4295688203),
    {
      "p": 2228235,
      "g": {
        "r": 0,
        "d": 0,
        "h": 12885622795,
        "f": 50331681
      },
      "n": "DotnetInstance",
      "d": 720907,
      "h": 4295688203,
      "f": 2097185
    },
//--TRIMMABLE-BOUNDARY-END(4295688203)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(30065491979),
    {
      "r": $.$$.System.Threading.Tasks.Task$$($.$srij.System.Runtime.InteropServices.JavaScript.JSObject).$h,
      "p": [
        {
          "n": "moduleName",
          "p": 1310721
        },
        {
          "n": "moduleUrl",
          "p": 1310721
        },
        {
          "n": "cancellationToken",
          "p": 170065921,
          "f": 65
        }
      ],
      "n": "ImportAsync",
      "d": 720907,
      "h": 30065491979,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(30065491979)
  ],
  "h": 720907,
  "a": [
    {
      "t": 159055873,
      "c": 4454023169,
      "a": [
        {
          "v": "browser",
          "t": 1310721
        }
      ]
    }
  ]
}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `System.Runtime.InteropServices.JavaScript.JSHost`; }
        });
        //--TRIMMABLE-BOUNDARY-END(720907)
        
        
        //--TRIMMABLE-BOUNDARY-START(786443)
        $asm.$cls("$srij.System.Runtime.InteropServices.JavaScript.JSHostImplementation", ($self) => class JSHostImplementation
        {
            //--TRIMMABLE-BOUNDARY-START(1114123)
            static $_ToManagedCallback;
            static get ToManagedCallback()
            {
                let $cls = $.$srij.System.Runtime.InteropServices.JavaScript.JSHostImplementation;
                return $cls.$_ToManagedCallback ??= $asm.$ncls("$srij.System.Runtime.InteropServices.JavaScript.JSHostImplementation.ToManagedCallback", ($self) => class ToManagedCallback extends $.$$.System.MulticastDelegate
                {
                    $ctor(/*object*/ target, fn, anmodel)
                    {
                        this.$target = target;
                        this.$nativeFunction = fn;
                        if (anmodel) this.$nfmodel = anmodel;
                        if (typeof(target) === 'object') this._target = target;
                        return this;
                    }
                    /*void*/ Invoke(/**/ arguments_buffer)
                    {
                        return this.$nativeFunction.call(this.$target, arguments_buffer);
                    }
                    static $h = 1114123;
                    static $f = 0b10000000010000000;
                    static $k = 5;
                    static $$md;
                    static get $md() { return this.$$md ??= {
  "b": 98959361,
  "m": [
//--TRIMMABLE-BOUNDARY-START(17180983307),
    {
      "r": 65537,
      "p": [
        {
          "n": "arguments_buffer",
          "p": $.$typePointer($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument).$h
        }
      ],
      "n": "Invoke",
      "d": 1114123,
      "h": 17180983307,
      "f": 16777345
    },
//--TRIMMABLE-BOUNDARY-END(17180983307),
//--TRIMMABLE-BOUNDARY-START(8591048715),
    {
      "r": 89784321,
      "p": [
        {
          "n": "arguments_buffer",
          "p": $.$typePointer($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument).$h
        },
        {
          "n": "callback",
          "p": 45285377
        },
        {
          "n": "object",
          "p": 131073
        }
      ],
      "n": "BeginInvoke",
      "d": 1114123,
      "h": 8591048715,
      "f": 16777345
    },
//--TRIMMABLE-BOUNDARY-END(8591048715),
//--TRIMMABLE-BOUNDARY-START(12886016011),
    {
      "r": 65537,
      "p": [
        {
          "n": "result",
          "p": 89784321
        }
      ],
      "n": "EndInvoke",
      "d": 1114123,
      "h": 12886016011,
      "f": 16777345
    },
//--TRIMMABLE-BOUNDARY-END(12886016011)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296081419),
    {
      "p": [
        {
          "n": "object",
          "p": 131073
        },
        {
          "n": "method",
          "p": 786433
        }
      ],
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 1114123,
      "h": 4296081419,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296081419)
  ],
  "i": [89980929,157483009
  ],
  "d": 786443,
  "h": 1114123
}; }
                    static get $b() { return $.$$.System.MulticastDelegate; }
                    static $$i;
                    static get $i() { return this.$$i ??= [ $.$$.System.ICloneable, $.$$.System.Runtime.Serialization.ISerializable ]; }
                    static get $fullName() { return `System.Runtime.InteropServices.JavaScript.JSHostImplementation.ToManagedCallback`; }
                }, $cls, ($v) => $cls.$_ToManagedCallback = $v);
            }
            //--TRIMMABLE-BOUNDARY-END(1114123)
            
            //--TRIMMABLE-BOUNDARY-START(983051)
            static $_PromiseHolder;
            static get PromiseHolder()
            {
                let $cls = $.$srij.System.Runtime.InteropServices.JavaScript.JSHostImplementation;
                return $cls.$_PromiseHolder ??= $asm.$ncls("$srij.System.Runtime.InteropServices.JavaScript.JSHostImplementation.PromiseHolder", ($self) => class PromiseHolder extends $.$$.System.Object
                {
                    //--TRIMMABLE-BOUNDARY-START(21475819531)
                    /*bool*/ IsDisposed = false;
                    //--TRIMMABLE-BOUNDARY-END(21475819531)
                    
                    //--TRIMMABLE-BOUNDARY-START(17180852235)
                    /*nint*/ GCHandle = 0;
                    //--TRIMMABLE-BOUNDARY-END(17180852235)
                    
                    //--TRIMMABLE-BOUNDARY-START(12885884939)
                    /*ToManagedCallback?*/ Callback = null;
                    //--TRIMMABLE-BOUNDARY-END(12885884939)
                    
                    //--TRIMMABLE-BOUNDARY-START(25770786827)
                    /*JSProxyContext*/ ProxyContext = null;
                    //--TRIMMABLE-BOUNDARY-END(25770786827)
                    
                    //--TRIMMABLE-BOUNDARY-START(8590917643)
                    $ctor$2(/*JSProxyContext*/ targetContext)
                    {
                        super.$ctor();
                        {
                            //--TRIMMABLE-BOUNDARY-START(TRACE)
                            $.$trace(8590917643);
                            //--TRIMMABLE-BOUNDARY-END(TRACE)
                            this.GCHandle = $.$$.System.Runtime.InteropServices.GCHandle.op_Explicit($.$$.System.Runtime.InteropServices.GCHandle.Alloc(this, 2/*GCHandleType.Normal*/));
                            this.ProxyContext = targetContext;
                        }
                        return this;
                    }
                    //--TRIMMABLE-BOUNDARY-END(8590917643)
                    
                    //--TRIMMABLE-BOUNDARY-START(4295950347)
                    $ctor$1(/*JSProxyContext*/ targetContext, /*nint*/ gcvHandle)
                    {
                        super.$ctor();
                        {
                            //--TRIMMABLE-BOUNDARY-START(TRACE)
                            $.$trace(4295950347);
                            //--TRIMMABLE-BOUNDARY-END(TRACE)
                            this.GCHandle = gcvHandle;
                            this.ProxyContext = targetContext;
                        }
                        return this;
                    }
                    //--TRIMMABLE-BOUNDARY-END(4295950347)
                    
                    static $h = 983051;
                    static $f = 0b10000000010010001;
                    static $k = 1;
                    static $$md;
                    static get $md() { return this.$$md ??= {
  "b": 131073,
  "l": [
//--TRIMMABLE-BOUNDARY-START(21475819531),
    {
      "t": 262145,
      "n": "IsDisposed",
      "d": 983051,
      "h": 21475819531,
      "f": 4194305
    },
//--TRIMMABLE-BOUNDARY-END(21475819531),
//--TRIMMABLE-BOUNDARY-START(17180852235),
    {
      "t": 786433,
      "n": "GCHandle",
      "d": 983051,
      "h": 17180852235,
      "f": 4194305
    },
//--TRIMMABLE-BOUNDARY-END(17180852235),
//--TRIMMABLE-BOUNDARY-START(12885884939),
    {
      "t": 1114123,
      "n": "Callback",
      "d": 983051,
      "h": 12885884939,
      "f": 4194305
    },
//--TRIMMABLE-BOUNDARY-END(12885884939),
//--TRIMMABLE-BOUNDARY-START(25770786827),
    {
      "t": 2293771,
      "n": "ProxyContext",
      "d": 983051,
      "h": 25770786827,
      "f": 4194305
    },
//--TRIMMABLE-BOUNDARY-END(25770786827)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(8590917643),
    {
      "p": [
        {
          "n": "targetContext",
          "p": 2293771
        }
      ],
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 983051,
      "h": 8590917643,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8590917643),
//--TRIMMABLE-BOUNDARY-START(4295950347),
    {
      "p": [
        {
          "n": "targetContext",
          "p": 2293771
        },
        {
          "n": "gcvHandle",
          "p": 786433
        }
      ],
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 983051,
      "h": 4295950347,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295950347)
  ],
  "d": 786443,
  "h": 983051
}; }
                    static get $b() { return $.$$.System.Object; }
                    static get $fullName() { return `System.Runtime.InteropServices.JavaScript.JSHostImplementation.PromiseHolder`; }
                }, $cls, ($v) => $cls.$_PromiseHolder = $v);
            }
            //--TRIMMABLE-BOUNDARY-END(983051)
            
            //--TRIMMABLE-BOUNDARY-START(1048587)
            static $_PromiseHolderState;
            static get PromiseHolderState()
            {
                let $cls = $.$srij.System.Runtime.InteropServices.JavaScript.JSHostImplementation;
                return $cls.$_PromiseHolderState ??= $asm.$nstr("$srij.System.Runtime.InteropServices.JavaScript.JSHostImplementation.PromiseHolderState", ($self) => class PromiseHolderState extends $.$$.System.ValueType
                {
                    //--TRIMMABLE-BOUNDARY-START(8590983179)
                    /*int*/  get IsResolving() { return this.$getField(0, $.$$.System.Int32); }
                    /*int*/  set IsResolving(value) { this.$setField(0, $.$$.System.Int32, value); }
                    //--TRIMMABLE-BOUNDARY-END(8590983179)
                    
                    //--TRIMMABLE-BOUNDARY-START(4296015883)
                    //default value type constructor
                    $ctor$2()
                    {
                        return this;
                    }
                    //--TRIMMABLE-BOUNDARY-END(4296015883)
                    
                    Clone($copy)
                    {
                        let copy = $copy ?? new this.constructor();
                        copy.IsResolving = this.IsResolving;
                        return copy;
                    }
                    //default member initializer
                    constructor()
                    {
                        super();
                        //--TRIMMABLE-BOUNDARY-START(8590983179)
                        this.IsResolving = 0;
                        //--TRIMMABLE-BOUNDARY-END(8590983179)
                        
                    }
                    static $h = 1048587;
                    static $z = 4;
                    static $f = 0b10100010000001010000001;
                    static $k = 2;
                    static $$md;
                    static get $md() { return this.$$md ??= {
  "b": 196609,
  "l": [
//--TRIMMABLE-BOUNDARY-START(8590983179),
    {
      "t": 655361,
      "n": "IsResolving",
      "d": 1048587,
      "h": 8590983179,
      "f": 4194305,
      "a": [
        {
          "t": 141557761,
          "c": 8731492353,
          "a": [
            {
              "v": 0,
              "t": 655361
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(8590983179)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296015883),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 1048587,
      "h": 4296015883,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296015883)
  ],
  "d": 786443,
  "h": 1048587,
  "a": [
    {
      "t": 147390465,
      "c": 13032292353,
      "a": [
        {
          "v": 2,
          "t": 142868481
        }
      ]
    }
  ]
}; }
                    static get $b() { return $.$$.System.ValueType; }
                    static get $fullName() { return `System.Runtime.InteropServices.JavaScript.JSHostImplementation.PromiseHolderState`; }
                }, $cls, ($v) => $cls.$_PromiseHolderState = $v);
            }
            //--TRIMMABLE-BOUNDARY-END(1048587)
            
            //--TRIMMABLE-BOUNDARY-START(851979)
            static $_IntPtrAndHandle;
            static get IntPtrAndHandle()
            {
                let $cls = $.$srij.System.Runtime.InteropServices.JavaScript.JSHostImplementation;
                return $cls.$_IntPtrAndHandle ??= $asm.$nstr("$srij.System.Runtime.InteropServices.JavaScript.JSHostImplementation.IntPtrAndHandle", ($self) => class IntPtrAndHandle extends $.$$.System.ValueType
                {
                    //--TRIMMABLE-BOUNDARY-START(12885753867)
                    /*IntPtr*/  get ptr() { return this.$getField(0, 4); }
                    /*IntPtr*/  set ptr(value) { this.$setField(0, 4, value); }
                    //--TRIMMABLE-BOUNDARY-END(12885753867)
                    
                    //--TRIMMABLE-BOUNDARY-START(8590786571)
                    /*RuntimeMethodHandle*/  get methodHandle() { return this.$getField(0, 4); }
                    /*RuntimeMethodHandle*/  set methodHandle(value) { this.$setField(0, 4, value); }
                    //--TRIMMABLE-BOUNDARY-END(8590786571)
                    
                    //--TRIMMABLE-BOUNDARY-START(17180721163)
                    /*RuntimeTypeHandle*/  get typeHandle() { return this.$getField(0, 4); }
                    /*RuntimeTypeHandle*/  set typeHandle(value) { this.$setField(0, 4, value); }
                    //--TRIMMABLE-BOUNDARY-END(17180721163)
                    
                    //--TRIMMABLE-BOUNDARY-START(4295819275)
                    //default value type constructor
                    $ctor$2()
                    {
                        return this;
                    }
                    //--TRIMMABLE-BOUNDARY-END(4295819275)
                    
                    Clone($copy)
                    {
                        let copy = $copy ?? new this.constructor();
                        copy.ptr = this.ptr;
                        copy.methodHandle = this.methodHandle.Clone();
                        copy.typeHandle = this.typeHandle.Clone();
                        return copy;
                    }
                    //default member initializer
                    constructor()
                    {
                        super();
                        //--TRIMMABLE-BOUNDARY-START(12885753867)
                        this.ptr = 0;
                        //--TRIMMABLE-BOUNDARY-END(12885753867)
                        
                        //--TRIMMABLE-BOUNDARY-START(8590786571)
                        this.methodHandle = $.$default($.$$.System.RuntimeMethodHandle);
                        //--TRIMMABLE-BOUNDARY-END(8590786571)
                        
                        //--TRIMMABLE-BOUNDARY-START(17180721163)
                        this.typeHandle = $.$default($.$$.System.RuntimeTypeHandle);
                        //--TRIMMABLE-BOUNDARY-END(17180721163)
                        
                    }
                    static $h = 851979;
                    static $z = 4;
                    static $f = 0b100010000001010000001;
                    static $k = 2;
                    static $$md;
                    static get $md() { return this.$$md ??= {
  "b": 196609,
  "l": [
//--TRIMMABLE-BOUNDARY-START(12885753867),
    {
      "t": 786433,
      "n": "ptr",
      "d": 851979,
      "h": 12885753867,
      "f": 4194312,
      "a": [
        {
          "t": 141557761,
          "c": 8731492353,
          "a": [
            {
              "v": 0,
              "t": 655361
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(12885753867),
//--TRIMMABLE-BOUNDARY-START(8590786571),
    {
      "t": 159711233,
      "n": "methodHandle",
      "d": 851979,
      "h": 8590786571,
      "f": 4194312,
      "a": [
        {
          "t": 141557761,
          "c": 8731492353,
          "a": [
            {
              "v": 0,
              "t": 655361
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(8590786571),
//--TRIMMABLE-BOUNDARY-START(17180721163),
    {
      "t": 160169985,
      "n": "typeHandle",
      "d": 851979,
      "h": 17180721163,
      "f": 4194312,
      "a": [
        {
          "t": 141557761,
          "c": 8731492353,
          "a": [
            {
              "v": 0,
              "t": 655361
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(17180721163)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295819275),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 851979,
      "h": 4295819275,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295819275)
  ],
  "d": 786443,
  "h": 851979,
  "a": [
    {
      "t": 147390465,
      "c": 13032292353,
      "a": [
        {
          "v": 2,
          "t": 142868481
        }
      ]
    }
  ]
}; }
                    static get $b() { return $.$$.System.ValueType; }
                    static get $fullName() { return `System.Runtime.InteropServices.JavaScript.JSHostImplementation.IntPtrAndHandle`; }
                }, $cls, ($v) => $cls.$_IntPtrAndHandle = $v);
            }
            //--TRIMMABLE-BOUNDARY-END(851979)
            
            //--TRIMMABLE-BOUNDARY-START(917515)
            static $_JSThreadBlockingMode;
            static get JSThreadBlockingMode()
            {
                let $cls = $.$srij.System.Runtime.InteropServices.JavaScript.JSHostImplementation;
                return $cls.$_JSThreadBlockingMode ??= $asm.$nstr("$srij.System.Runtime.InteropServices.JavaScript.JSHostImplementation.JSThreadBlockingMode", ($self) => class JSThreadBlockingMode extends $.$$.System.Enum
                {
                    static PreventSynchronousJSExport = 0;
                    static ThrowWhenBlockingWait = 1;
                    static WarnWhenBlockingWait = 2;
                    static DangerousAllowBlockingWait = 100;
                    static $map;
                    static get Map()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(917515);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return this.$map ??= 
                        {
                            "PreventSynchronousJSExport": 0n,
                            "ThrowWhenBlockingWait": 1n,
                            "WarnWhenBlockingWait": 2n,
                            "DangerousAllowBlockingWait": 100n
                        };
                    }
                    static $h = 917515;
                    static $z = 4;
                    static $f = 0b110000011010001001;
                    static $k = 4;
                    static get $eut() { return $.$$.System.Int32; }
                    static $$md;
                    static get $md() { return this.$$md ??= {
  "b": 1048577,
  "u": 655361,
  "l": [
//--TRIMMABLE-BOUNDARY-START(12885819403),
    {
      "t": 917515,
      "n": "PreventSynchronousJSExport",
      "d": 917515,
      "h": 12885819403,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(12885819403),
//--TRIMMABLE-BOUNDARY-START(17180786699),
    {
      "t": 917515,
      "n": "ThrowWhenBlockingWait",
      "d": 917515,
      "h": 17180786699,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(17180786699),
//--TRIMMABLE-BOUNDARY-START(21475753995),
    {
      "t": 917515,
      "n": "WarnWhenBlockingWait",
      "d": 917515,
      "h": 21475753995,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(21475753995),
//--TRIMMABLE-BOUNDARY-START(8590852107),
    {
      "t": 917515,
      "n": "DangerousAllowBlockingWait",
      "d": 917515,
      "h": 8590852107,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(8590852107)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295884811),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 917515,
      "h": 4295884811,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295884811)
  ],
  "i": [90046465,96600065,90505217,90177537
  ],
  "d": 786443,
  "h": 917515
}; }
                    static get $b() { return $.$$.System.Enum; }
                    static $$i;
                    static get $i() { return this.$$i ??= [ $.$$.System.IComparable, $.$$.System.ISpanFormattable, $.$$.System.IFormattable, $.$$.System.IConvertible ]; }
                    static get $fullName() { return `System.Runtime.InteropServices.JavaScript.JSHostImplementation.JSThreadBlockingMode`; }
                }, $cls, ($v) => $cls.$_JSThreadBlockingMode = $v);
            }
            //--TRIMMABLE-BOUNDARY-END(917515)
            
            //--TRIMMABLE-BOUNDARY-START(94490066955)
            /*string*/ static TaskGetResultName = null;
            //--TRIMMABLE-BOUNDARY-END(94490066955)
            
            //--TRIMMABLE-BOUNDARY-START(81605165067)
            /*MethodInfo?*/ static s_taskGetResultMethodInfo = null;
            //--TRIMMABLE-BOUNDARY-END(81605165067)
            
            //--TRIMMABLE-BOUNDARY-START(55835361291)
            static /*bool */ GetTaskResultDynamic(/*Task*/ task, /*out object?*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(55835361291);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let type = $.$$.System.Object.GetType.call(task);
                if ($.$$.System.Type.op_Equality$1(type, $.$$.System.Threading.Tasks.Task.$type))
                {
                    value.$v = null;
                    return false;
                }
                /*MethodInfo*/ let method = $.$srij.System.Runtime.InteropServices.JavaScript.JSHostImplementation.GetTaskResultMethodInfo(type);
                if ($.$$.System.Reflection.MethodInfo.op_Inequality$2(method, null))
                {
                    value.$v = method.Invoke(task, null);
                    return true;
                }
                throw new $.$$.System.InvalidOperationException().$ctor$9();
            }
            //--TRIMMABLE-BOUNDARY-END(55835361291)
            
            //--TRIMMABLE-BOUNDARY-START(60130328587)
            static /*MethodInfo */ GetTaskResultMethodInfo(/*Type*/ taskType)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(60130328587);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$$.System.Type.op_Inequality$1(taskType, null))
                {
                    if ($.$$.System.Reflection.MethodInfo.op_Equality$2($.$srij.System.Runtime.InteropServices.JavaScript.JSHostImplementation.s_taskGetResultMethodInfo, null))
                    {
                        $.$srij.System.Runtime.InteropServices.JavaScript.JSHostImplementation.s_taskGetResultMethodInfo = $.$$.System.Threading.Tasks.Task$$().$type.GetMethod$12("get_Result"/*TaskGetResultName*/);
                    }
                    /*MethodInfo?*/ let getter = taskType.GetMethod$12("get_Result"/*TaskGetResultName*/);
                    if ($.$$.System.Reflection.MethodInfo.op_Inequality$2(getter, null) && getter.HasSameMetadataDefinitionAs($.$srij.System.Runtime.InteropServices.JavaScript.JSHostImplementation.s_taskGetResultMethodInfo))
                    {
                        return getter;
                    }
                }
                throw new $.$$.System.InvalidOperationException().$ctor$9();
            }
            //--TRIMMABLE-BOUNDARY-END(60130328587)
            
            //--TRIMMABLE-BOUNDARY-START(98785034251)
            static /*void */ ThrowException(/*ref JSMarshalerArgument*/ arg)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(98785034251);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*Exception?*/ let ex;
                arg.$v.ToManaged$12($.$ref(() => ex, ($v) => ex = $v, $.$$.System.Exception));
                if (ex !== null)
                {
                    throw ex;
                }
                throw new $.$$.System.InvalidOperationException().$ctor$9();
            }
            //--TRIMMABLE-BOUNDARY-END(98785034251)
            
            //--TRIMMABLE-BOUNDARY-START(64425295883)
            static /*Task<JSObject> *//*async*/  ImportAsync(/*string*/ moduleName, /*string*/ moduleUrl, /*CancellationToken*/ cancellationToken)
            {
                return $.$$.NetJs.AsyncResolver.Async($.$$.System.Threading.Tasks.Task$$($.$srij.System.Runtime.InteropServices.JavaScript.JSObject), $.$srij.System.Runtime.InteropServices.JavaScript.JSObject, async () => 
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(64425295883);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    /*Task<JSObject>*/ let modulePromise = INTERNAL.dynamic_import(moduleName, moduleUrl);
                    /*var*/ let wrappedTask = $.$srij.System.Runtime.InteropServices.JavaScript.JSHostImplementation.CancellationHelper(modulePromise, cancellationToken);
                    return await wrappedTask.ConfigureAwait$3(1/*ConfigureAwaitOptions.ContinueOnCapturedContext*/ | 4/*ConfigureAwaitOptions.ForceYielding*/);
                });
            }
            //--TRIMMABLE-BOUNDARY-END(64425295883)
            
            //--TRIMMABLE-BOUNDARY-START(38655492107)
            static /*Task<JSObject> *//*async*/  CancellationHelper(/*Task<JSObject>*/ jsTask, /*CancellationToken*/ cancellationToken)
            {
                return $.$$.NetJs.AsyncResolver.Async($.$$.System.Threading.Tasks.Task$$($.$srij.System.Runtime.InteropServices.JavaScript.JSObject), $.$srij.System.Runtime.InteropServices.JavaScript.JSObject, async () => 
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(38655492107);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    if (jsTask.IsCompletedSuccessfully)
                    {
                        return jsTask.Result;
                    }
                    let receiveRegistration = null;
                    try
                    {
                        receiveRegistration = cancellationToken.Register$4(new ($.$$.System.Action$$($.$$.System.Object))().$ctor($.$srij.System.Runtime.InteropServices.JavaScript.JSHostImplementation, /*static*/ (/*s*/ s) =>
                        {
                            $.$srij.System.Runtime.InteropServices.JavaScript.CancelablePromise.CancelPromise($.$cast(s, $.$$.System.Threading.Tasks.Task$$($.$srij.System.Runtime.InteropServices.JavaScript.JSObject)));
                        }, {
  "r": 65537,
  "p": [
    {
      "n": "s",
      "p": 131073
    }
  ],
  "n": "",
  "d": 786443,
  "h": 0,
  "f": 17825826
}), jsTask);
                        return await jsTask.ConfigureAwait$2(false);
                    }
                    finally
                    {
                        receiveRegistration?.System$IDisposable$Dispose();
                    }
                });
            }
            //--TRIMMABLE-BOUNDARY-END(38655492107)
            
            //--TRIMMABLE-BOUNDARY-START(51540393995)
            static /*JSFunctionBinding */ GetMethodSignature(/*ReadOnlySpan<JSMarshalerType>*/ types, /*string?*/ functionName, /*string?*/ moduleName)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(51540393995);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*int*/ let argsCount = ((types.Length - 1) | 0);
                /*int*/ let size = ((32/*JSFunctionBinding.JSBindingHeader.JSMarshalerSignatureHeaderSize*/ + ((((((argsCount + 2) | 0)) * $.$srij.System.Runtime.InteropServices.JavaScript.JSFunctionBinding.JSBindingType.$z) | 0))) | 0);
                /*int*/ let functionNameBytes = 0;
                /*int*/ let functionNameOffset = 0;
                if ($.$$.System.String.op_Inequality(functionName, null))
                {
                    functionNameOffset = size;
                    size += 4;
                    functionNameBytes = ((functionName.length * 2) | 0);
                    size += functionNameBytes;
                }
                /*int*/ let moduleNameBytes = 0;
                /*int*/ let moduleNameOffset = 0;
                if ($.$$.System.String.op_Inequality(moduleName, null))
                {
                    moduleNameOffset = size;
                    size += 4;
                    moduleNameBytes = ((moduleName.length * 2) | 0);
                    size += moduleNameBytes;
                }
                /*IntPtr*/ let buffer = $.$$.System.Runtime.InteropServices.Marshal.AllocHGlobal(size);
                /*var*/ let signature = (() =>
                {
                    //new $.$srij.System.Runtime.InteropServices.JavaScript.JSFunctionBinding()
                    const $t1 = $.$srij.System.Runtime.InteropServices.JavaScript.JSFunctionBinding;
                    const $i1 = new $t1();
                    $i1.$ctor$1();
                    $i1.Header = $.$cast(buffer, $.$typePointer($.$srij.System.Runtime.InteropServices.JavaScript.JSFunctionBinding.JSBindingHeader));
                    $i1.Sigs = $.$cast((buffer + 32/*JSFunctionBinding.JSBindingHeader.JSMarshalerSignatureHeaderSize*/ + (((2 * $.$srij.System.Runtime.InteropServices.JavaScript.JSFunctionBinding.JSBindingType.$z) | 0))), $.$typePointer($.$srij.System.Runtime.InteropServices.JavaScript.JSFunctionBinding.JSBindingType));
                    return $i1;
                })();
                signature.Version = 2;
                signature.ArgumentCount = argsCount;
                signature.Exception = $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType.Exception._signatureType;
                signature.Result = types.get_Item(0).$v._signatureType;
                signature.ImportHandle = ($.$srij.System.Runtime.InteropServices.JavaScript.JSFunctionBinding.nextImportHandle++ | 0);
                signature.FunctionName = functionName;
                for(/*int*/ let i = 0; i < argsCount; i++)
                {
                    /*var*/ let type = signature.Sigs.SetAt(types.get_Item(((i + 1) | 0)).$v._signatureType, i);
                }
                signature.IsAsync = types.get_Item(0).$v._signatureType.Type === 20/*MarshalerType.Task*/;
                signature.IsDiscardNoWait = types.get_Item(0).$v._signatureType.Type === 26/*MarshalerType.DiscardNoWait*/;
                signature.Header.GetAt(0).ImportHandle = signature.ImportHandle;
                signature.Header.GetAt(0).FunctionNameLength = functionNameBytes;
                signature.Header.GetAt(0).FunctionNameOffset = functionNameOffset;
                signature.Header.GetAt(0).ModuleNameLength = moduleNameBytes;
                signature.Header.GetAt(0).ModuleNameOffset = moduleNameOffset;
                if (functionNameBytes !== 0)
                {
                    /*fixed*/ 
                    {
                        /*void**/ let fn = $.$$.System.String.GetPinnableReference.call(functionName);
                        $.$$.System.Runtime.CompilerServices.Unsafe.CopyBlock($.$cast(buffer, $.$typePointer($.$$.System.Byte)).Add(functionNameOffset), fn, (functionNameBytes >>> 0));
                    }
                }
                if (moduleNameBytes !== 0)
                {
                    /*fixed*/ 
                    {
                        /*void**/ let mn = $.$$.System.String.GetPinnableReference.call(moduleName);
                        $.$$.System.Runtime.CompilerServices.Unsafe.CopyBlock($.$cast(buffer, $.$typePointer($.$$.System.Byte)).Add(moduleNameOffset), mn, (moduleNameBytes >>> 0));
                    }
                }
                return signature;
            }
            //--TRIMMABLE-BOUNDARY-END(51540393995)
            
            //--TRIMMABLE-BOUNDARY-START(42950459403)
            static /*void */ FreeMethodSignatureBuffer(/*JSFunctionBinding*/ signature)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(42950459403);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.Runtime.InteropServices.Marshal.FreeHGlobal($.$cast(signature.Header, $.$$.System.IntPtr));
                signature.Header = null;
                signature.Sigs = null;
            }
            //--TRIMMABLE-BOUNDARY-END(42950459403)
            
            //--TRIMMABLE-BOUNDARY-START(68720263179)
            static /*void */ LoadLazyAssembly(/*byte[]*/ dllBytes, /*byte[]?*/ pdbBytes)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(68720263179);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (pdbBytes === null)
                {
                    $.$$.System.Runtime.Loader.AssemblyLoadContext.Default.LoadFromStream$1(new $.$$.System.IO.MemoryStream().$ctor$8(dllBytes));
                }
                else 
                {
                    $.$$.System.Runtime.Loader.AssemblyLoadContext.Default.LoadFromStream(new $.$$.System.IO.MemoryStream().$ctor$8(dllBytes), new $.$$.System.IO.MemoryStream().$ctor$8(pdbBytes));
                }
            }
            //--TRIMMABLE-BOUNDARY-END(68720263179)
            
            //--TRIMMABLE-BOUNDARY-START(73015230475)
            static /*void */ LoadSatelliteAssembly(/*byte[]*/ dllBytes)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(73015230475);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.Runtime.Loader.AssemblyLoadContext.Default.LoadFromStream$1(new $.$$.System.IO.MemoryStream().$ctor$8(dllBytes));
            }
            //--TRIMMABLE-BOUNDARY-END(73015230475)
            
            //--TRIMMABLE-BOUNDARY-START(34360524811)
            static /*Task<int>? */ CallEntrypoint(/*IntPtr*/ assemblyNamePtr, /*string?[]?*/ args, /*bool*/ waitForDebugger)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(34360524811);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                try
                {
                    /*void**/ let ptr;
                    $.$srij.Interop.Runtime.AssemblyGetEntryPoint(assemblyNamePtr, waitForDebugger ? 1 : 0, $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateObjectReferenceT($.$typePointer($.$$.System.Void), () => ptr, ($v) => ptr = $v, null));
                    /*RuntimeMethodHandle*/ let methodHandle = $.$srij.System.Runtime.InteropServices.JavaScript.JSHostImplementation.GetMethodHandleFromIntPtr($.$$.System.IntPtr.op_Explicit$4(ptr));
                    /*MethodInfo?*/ let method = $.$as($.$$.System.Reflection.MethodBase.GetMethodFromHandle$1(methodHandle), $.$$.System.Reflection.MethodInfo);
                    if ($.$$.System.Reflection.MethodInfo.op_Equality$2(method, null))
                    {
                        throw new $.$$.System.InvalidOperationException().$ctor$12($.$srij.System.SR.CannotResolveManagedEntrypointHandle);
                    }
                    /*object[]*/ let argsToPass = $.$$.System.Array.Empty($.$$.System.Object);
                    /*Task<int>?*/ let result = null;
                    /*var*/ let parameterInfos = method.GetParameters();
                    if (parameterInfos.length > 0 && $.$$.System.Type.op_Equality$1($.$$.System.Array.$ReadT1.call(parameterInfos, 0).ParameterType, $.$typeArray($.$$.System.String).$type))
                    {
                        argsToPass = $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$$.System.Object), [args ?? $.$$.System.Array.Empty($.$$.System.String)], [-1], null);
                    }
                    if ($.$$.System.Type.op_Equality$1(method.ReturnType, $.$$.System.Void.$type))
                    {
                        method.Invoke(null, argsToPass);
                    }
                    else if ($.$$.System.Type.op_Equality$1(method.ReturnType, $.$$.System.Int32.$type))
                    {
                        /*int*/ let intResult = $.$cast(method.Invoke(null, argsToPass), $.$$.System.Int32);
                        result = $.$$.System.Threading.Tasks.Task.FromResult($.$$.System.Int32, intResult);
                    }
                    else if ($.$$.System.Type.op_Equality$1(method.ReturnType, $.$$.System.Threading.Tasks.Task.$type))
                    {
                        /*Task*/ let methodResult = $.$cast(method.Invoke(null, argsToPass), $.$$.System.Threading.Tasks.Task);
                        /*TaskCompletionSource<int>*/ let tcs = new ($.$$.System.Threading.Tasks.TaskCompletionSource$$($.$$.System.Int32))().$ctor$1();
                        result = tcs.Task;
                        methodResult.ContinueWith$10(new ($.$$.System.Action$$($.$$.System.Threading.Tasks.Task))().$ctor(this,  (/*t*/ t) =>
                        {
                            if (t.IsFaulted)
                            {
                                tcs.SetException$1(t.Exception);
                            }
                            else 
                            {
                                tcs.SetResult(0);
                            }
                        }, {
  "r": 65537,
  "p": [
    {
      "n": "t",
      "p": 177668097
    }
  ],
  "n": "",
  "d": 786443,
  "h": 0,
  "f": 17825794
}), $.$$.System.Threading.Tasks.TaskScheduler.Default);
                    }
                    else if ($.$$.System.Type.op_Equality$1(method.ReturnType, $.$$.System.Threading.Tasks.Task$$($.$$.System.Int32).$type))
                    {
                        result = $.$cast(method.Invoke(null, argsToPass), $.$$.System.Threading.Tasks.Task$$($.$$.System.Int32));
                    }
                    else 
                    {
                        throw new $.$$.System.InvalidOperationException().$ctor$12($.$srij.System.SR.Format$6($.$srij.System.SR.ReturnTypeNotSupportedForMain, method.ReturnType.FullName));
                    }
                    return result;
                }
                catch(ex)
                {
                    let refEx;
                    if ($.$is(ex, $.$$.System.Reflection.TargetInvocationException, { set $v(v){ refEx = v; } }) && refEx.InnerException !== null)
                    {
                        ex = refEx.InnerException;
                    }
                    return $.$$.System.Threading.Tasks.Task.FromException$1($.$$.System.Int32, ex);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(34360524811)
            
            //--TRIMMABLE-BOUNDARY-START(25770590219)
            static /*Task */ BindAssemblyExports(/*string?*/ assemblyName)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25770590219);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$srij.Interop.Runtime.BindAssemblyExports($.$$.System.Runtime.InteropServices.Marshal.StringToCoTaskMemUTF8(assemblyName));
                return $.$$.System.Threading.Tasks.Task.CompletedTask;
            }
            //--TRIMMABLE-BOUNDARY-END(25770590219)
            
            //--TRIMMABLE-BOUNDARY-START(30065557515)
            static /*JSFunctionBinding */ BindManagedFunction(/*string*/ fullyQualifiedName, /*int*/ signatureHash, /*ReadOnlySpan<JSMarshalerType>*/ signatures)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(30065557515);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let  [ assemblyName, nameSpace, shortClassName, methodName ] = $.$destructure($.$srij.System.Runtime.InteropServices.JavaScript.JSHostImplementation.ParseFQN(fullyQualifiedName));
                /*IntPtr*/ let monoMethod;
                $.$srij.Interop.Runtime.GetAssemblyExport($.$$.System.Runtime.InteropServices.Marshal.StringToCoTaskMemUTF8(assemblyName), $.$$.System.Runtime.InteropServices.Marshal.StringToCoTaskMemUTF8(nameSpace), $.$$.System.Runtime.InteropServices.Marshal.StringToCoTaskMemUTF8(shortClassName), $.$$.System.Runtime.InteropServices.Marshal.StringToCoTaskMemUTF8(methodName), signatureHash, $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateObjectReferenceT($.$$.System.IntPtr, () => monoMethod, ($v) => monoMethod = $v, null));
                if (monoMethod === $.$$.System.IntPtr.Zero)
                {
                    $.$$.System.Environment.FailFast$2(`Can't find ${nameSpace}${shortClassName}${methodName} in ${assemblyName}.dll`);
                }
                /*var*/ let signature = $.$srij.System.Runtime.InteropServices.JavaScript.JSHostImplementation.GetMethodSignature(signatures, null, null);
                INTERNAL.mono_wasm_bind_cs_function(monoMethod, assemblyName, nameSpace, shortClassName, methodName, signatureHash, $.$cast(signature.Header, $.$$.System.IntPtr));
                $.$srij.System.Runtime.InteropServices.JavaScript.JSHostImplementation.FreeMethodSignatureBuffer(signature);
                return signature;
            }
            //--TRIMMABLE-BOUNDARY-END(30065557515)
            
            //--TRIMMABLE-BOUNDARY-START(47245426699)
            static /*RuntimeMethodHandle */ GetMethodHandleFromIntPtr(/*IntPtr*/ ptr)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(47245426699);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let temp = (() =>
                {
                    //new $.$srij.System.Runtime.InteropServices.JavaScript.JSHostImplementation.IntPtrAndHandle()
                    const $t1 = $.$srij.System.Runtime.InteropServices.JavaScript.JSHostImplementation.IntPtrAndHandle;
                    const $i1 = new $t1();
                    $i1.ptr = ptr;
                    return $i1;
                })();
                return temp.methodHandle;
            }
            //--TRIMMABLE-BOUNDARY-END(47245426699)
            
            //--TRIMMABLE-BOUNDARY-START(85900132363)
            static /*int */ SmallIndexOf(/*string*/ s, /*char*/ ch, /*int*/ direction)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(85900132363);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (s.length < 1)
                {
                    return -1;
                }
                /*int*/ let start_index = (direction > 0) ? 0 : ((s.length - 1) | 0), end_index = (direction > 0) ? ((s.length - 1) | 0) : 0;
                for(/*int*/ let i = start_index; i !== end_index; i += direction)
                {
                    if ($.$$.System.String.get_Chars.call(s, i) === ch)
                    {
                        return i;
                    }
                }
                return -1;
            }
            //--TRIMMABLE-BOUNDARY-END(85900132363)
            
            //--TRIMMABLE-BOUNDARY-START(90195099659)
            static /*string */ SmallTrim(/*string*/ s)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(90195099659);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (s.length < 1)
                {
                    return s;
                }
                /*int*/ let head = 0, tail = ((s.length - 1) | 0);
                while(head < s.length)
                {
                    if ($.$$.System.String.get_Chars.call(s, head) === /* */ 32)
                    {
                        head++;
                    }
                    else 
                    {
                        break;
                    }
                }
                while(tail >= 0)
                {
                    if ($.$$.System.String.get_Chars.call(s, tail) === /* */ 32)
                    {
                        tail--;
                    }
                    else 
                    {
                        break;
                    }
                }
                if ((head > 0) || (tail < ((s.length - 1) | 0)))
                {
                    return $.$$.System.String.Substring.call(s, head, ((((tail - head) | 0) + 1) | 0));
                }
                else 
                {
                    return s;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(90195099659)
            
            //--TRIMMABLE-BOUNDARY-START(77310197771)
            static /*(string assemblyName, string nameSpace, string shortClassName, string methodName) */ ParseFQN(/*string*/ fqn)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(77310197771);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let assembly = $.$$.System.String.Substring.call(fqn, (($.$srij.System.Runtime.InteropServices.JavaScript.JSHostImplementation.SmallIndexOf(fqn, /*[*/ 91, 1) + 1) | 0), (($.$srij.System.Runtime.InteropServices.JavaScript.JSHostImplementation.SmallIndexOf(fqn, /*]*/ 93, 1) - 1) | 0));
                fqn = $.$srij.System.Runtime.InteropServices.JavaScript.JSHostImplementation.SmallTrim(fqn);
                fqn = $.$$.System.String.Substring$1.call(fqn, (($.$srij.System.Runtime.InteropServices.JavaScript.JSHostImplementation.SmallIndexOf(fqn, /*]*/ 93, 1) + 1) | 0));
                fqn = $.$srij.System.Runtime.InteropServices.JavaScript.JSHostImplementation.SmallTrim(fqn);
                /*var*/ let methodName = $.$$.System.String.Substring$1.call(fqn, (($.$srij.System.Runtime.InteropServices.JavaScript.JSHostImplementation.SmallIndexOf(fqn, /*:*/ 58, 1) + 1) | 0));
                /*var*/ let className = $.$$.System.String.Substring.call(fqn, 0, $.$srij.System.Runtime.InteropServices.JavaScript.JSHostImplementation.SmallIndexOf(fqn, /*:*/ 58, 1));
                className = $.$srij.System.Runtime.InteropServices.JavaScript.JSHostImplementation.SmallTrim(className);
                /*var*/ let nameSpace = "";
                /*var*/ let shortClassName = className;
                /*var*/ let idx = $.$srij.System.Runtime.InteropServices.JavaScript.JSHostImplementation.SmallIndexOf(fqn, /*.*/ 46, -1);
                if (idx !== -1)
                {
                    nameSpace = $.$$.System.String.Substring.call(fqn, 0, idx);
                    shortClassName = $.$$.System.String.Substring$1.call(className, ((idx + 1) | 0));
                }
                if ($.$$.System.String.IsNullOrEmpty(assembly))
                {
                    throw new $.$$.System.InvalidOperationException().$ctor$12("No assembly name specified " + fqn);
                }
                if ($.$$.System.String.IsNullOrEmpty(className))
                {
                    throw new $.$$.System.InvalidOperationException().$ctor$12("No class name specified " + fqn);
                }
                if ($.$$.System.String.IsNullOrEmpty(methodName))
                {
                    throw new $.$$.System.InvalidOperationException().$ctor$12("No method name specified " + fqn);
                }
                return new ($.$$.System.ValueTuple$$$$$($.$$.System.String, $.$$.System.String, $.$$.System.String, $.$$.System.String))().$ctor$3(assembly, nameSpace, shortClassName, methodName);
            }
            //--TRIMMABLE-BOUNDARY-END(77310197771)
            
            //--TRIMMABLE-BOUNDARY-START(SINIT)
            //Static Initializer
            static $sinit()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(94490066955)
                    this.TaskGetResultName = "get_Result";
                    //--TRIMMABLE-BOUNDARY-END(94490066955)
                    
                }
            }
            //--TRIMMABLE-BOUNDARY-END(SINIT)
            
            static $h = 786443;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 131073,
  "m": [
//--TRIMMABLE-BOUNDARY-START(55835361291),
    {
      "r": 262145,
      "p": [
        {
          "n": "task",
          "p": 177668097
        },
        {
          "n": "value",
          "p": 131073,
          "f": 2
        }
      ],
      "n": "GetTaskResultDynamic",
      "d": 786443,
      "h": 55835361291,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(55835361291),
//--TRIMMABLE-BOUNDARY-START(60130328587),
    {
      "r": 116850689,
      "p": [
        {
          "n": "taskType",
          "p": 187760641
        }
      ],
      "n": "GetTaskResultMethodInfo",
      "d": 786443,
      "h": 60130328587,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(60130328587),
//--TRIMMABLE-BOUNDARY-START(98785034251),
    {
      "r": 65537,
      "p": [
        {
          "n": "arg",
          "p": 1310731,
          "f": 4
        }
      ],
      "n": "ThrowException",
      "d": 786443,
      "h": 98785034251,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(98785034251),
//--TRIMMABLE-BOUNDARY-START(64425295883),
    {
      "r": $.$$.System.Threading.Tasks.Task$$($.$srij.System.Runtime.InteropServices.JavaScript.JSObject).$h,
      "p": [
        {
          "n": "moduleName",
          "p": 1310721
        },
        {
          "n": "moduleUrl",
          "p": 1310721
        },
        {
          "n": "cancellationToken",
          "p": 170065921
        }
      ],
      "n": "ImportAsync",
      "d": 786443,
      "h": 64425295883,
      "f": 16781345
    },
//--TRIMMABLE-BOUNDARY-END(64425295883),
//--TRIMMABLE-BOUNDARY-START(38655492107),
    {
      "r": $.$$.System.Threading.Tasks.Task$$($.$srij.System.Runtime.InteropServices.JavaScript.JSObject).$h,
      "p": [
        {
          "n": "jsTask",
          "p": $.$$.System.Threading.Tasks.Task$$($.$srij.System.Runtime.InteropServices.JavaScript.JSObject).$h
        },
        {
          "n": "cancellationToken",
          "p": 170065921
        }
      ],
      "n": "CancellationHelper",
      "d": 786443,
      "h": 38655492107,
      "f": 16781345
    },
//--TRIMMABLE-BOUNDARY-END(38655492107),
//--TRIMMABLE-BOUNDARY-START(51540393995),
    {
      "r": 524299,
      "p": [
        {
          "n": "types",
          "p": $.$$.System.ReadOnlySpan$$($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType).$h
        },
        {
          "n": "functionName",
          "p": 1310721
        },
        {
          "n": "moduleName",
          "p": 1310721
        }
      ],
      "n": "GetMethodSignature",
      "d": 786443,
      "h": 51540393995,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(51540393995),
//--TRIMMABLE-BOUNDARY-START(42950459403),
    {
      "r": 65537,
      "p": [
        {
          "n": "signature",
          "p": 524299
        }
      ],
      "n": "FreeMethodSignatureBuffer",
      "d": 786443,
      "h": 42950459403,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(42950459403),
//--TRIMMABLE-BOUNDARY-START(68720263179),
    {
      "r": 65537,
      "p": [
        {
          "n": "dllBytes",
          "p": $.$typeArray($.$$.System.Byte).$h
        },
        {
          "n": "pdbBytes",
          "p": $.$typeArray($.$$.System.Byte).$h
        }
      ],
      "n": "LoadLazyAssembly",
      "d": 786443,
      "h": 68720263179,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(68720263179),
//--TRIMMABLE-BOUNDARY-START(73015230475),
    {
      "r": 65537,
      "p": [
        {
          "n": "dllBytes",
          "p": $.$typeArray($.$$.System.Byte).$h
        }
      ],
      "n": "LoadSatelliteAssembly",
      "d": 786443,
      "h": 73015230475,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(73015230475),
//--TRIMMABLE-BOUNDARY-START(34360524811),
    {
      "r": $.$$.System.Threading.Tasks.Task$$($.$$.System.Int32).$h,
      "p": [
        {
          "n": "assemblyNamePtr",
          "p": 786433
        },
        {
          "n": "args",
          "p": $.$typeArray($.$$.System.String).$h
        },
        {
          "n": "waitForDebugger",
          "p": 262145
        }
      ],
      "n": "CallEntrypoint",
      "d": 786443,
      "h": 34360524811,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(34360524811),
//--TRIMMABLE-BOUNDARY-START(25770590219),
    {
      "r": 177668097,
      "p": [
        {
          "n": "assemblyName",
          "p": 1310721
        }
      ],
      "n": "BindAssemblyExports",
      "d": 786443,
      "h": 25770590219,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(25770590219),
//--TRIMMABLE-BOUNDARY-START(30065557515),
    {
      "r": 524299,
      "p": [
        {
          "n": "fullyQualifiedName",
          "p": 1310721
        },
        {
          "n": "signatureHash",
          "p": 655361
        },
        {
          "n": "signatures",
          "p": $.$$.System.ReadOnlySpan$$($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType).$h
        }
      ],
      "n": "BindManagedFunction",
      "d": 786443,
      "h": 30065557515,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(30065557515),
//--TRIMMABLE-BOUNDARY-START(47245426699),
    {
      "r": 159711233,
      "p": [
        {
          "n": "ptr",
          "p": 786433
        }
      ],
      "n": "GetMethodHandleFromIntPtr",
      "d": 786443,
      "h": 47245426699,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(47245426699),
//--TRIMMABLE-BOUNDARY-START(85900132363),
    {
      "r": 655361,
      "p": [
        {
          "n": "s",
          "p": 1310721
        },
        {
          "n": "ch",
          "p": 458753
        },
        {
          "n": "direction",
          "p": 655361,
          "f": 65,
          "v": 1
        }
      ],
      "n": "SmallIndexOf",
      "d": 786443,
      "h": 85900132363,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(85900132363),
//--TRIMMABLE-BOUNDARY-START(90195099659),
    {
      "r": 1310721,
      "p": [
        {
          "n": "s",
          "p": 1310721
        }
      ],
      "n": "SmallTrim",
      "d": 786443,
      "h": 90195099659,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(90195099659),
//--TRIMMABLE-BOUNDARY-START(77310197771),
    {
      "r": $.$$.System.ValueTuple$$$$$($.$$.System.String, $.$$.System.String, $.$$.System.String, $.$$.System.String).$h,
      "p": [
        {
          "n": "fqn",
          "p": 1310721
        }
      ],
      "n": "ParseFQN",
      "d": 786443,
      "h": 77310197771,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(77310197771)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(94490066955),
    {
      "t": 1310721,
      "n": "TaskGetResultName",
      "d": 786443,
      "h": 94490066955,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(94490066955),
//--TRIMMABLE-BOUNDARY-START(81605165067),
    {
      "t": 116850689,
      "n": "s_taskGetResultMethodInfo",
      "d": 786443,
      "h": 81605165067,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(81605165067)
  ],
  "j": [1114123,983051,1048587,851979,917515
  ],
  "h": 786443
}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `System.Runtime.InteropServices.JavaScript.JSHostImplementation`; }
        });
        //--TRIMMABLE-BOUNDARY-END(786443)
        
        
        //--TRIMMABLE-BOUNDARY-START(65547)
        $asm.$cls("$srij.Interop", ($self) => class Interop
        {
            //--TRIMMABLE-BOUNDARY-START(131083)
            static $_Runtime;
            static get Runtime()
            {
                let $cls = $.$srij.Interop;
                return $cls.$_Runtime ??= $asm.$ncls("$srij.Interop.Runtime", ($self) => class Runtime
                {
                    static $h = 131083;
                    static $f = 0b10000000000010000;
                    static $k = 1;
                    static $$md;
                    static get $md() { return this.$$md ??= {
  "b": 131073,
  "d": 65547,
  "h": 131083
}; }
                    static get $b() { return $.$$.System.Object; }
                    static get $fullName() { return `Interop.Runtime`; }
                }, $cls, ($v) => $cls.$_Runtime = $v);
            }
            //--TRIMMABLE-BOUNDARY-END(131083)
            
            static $h = 65547;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 131073,
  "j": [131083
  ],
  "h": 65547
}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `Interop`; }
        });
        //--TRIMMABLE-BOUNDARY-END(65547)
        
        
        //--TRIMMABLE-BOUNDARY-START(196619)
        $asm.$cls("$srij.System.Runtime.InteropServices.JavaScript.CancelablePromise", ($self) => class CancelablePromise
        {
            //--TRIMMABLE-BOUNDARY-START(4295163915)
            static /*void */ CancelPromise(/*Task*/ promise)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295163915);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (promise.IsCompleted)
                {
                    return;
                }
                /*JSHostImplementation.PromiseHolder?*/ let holder = $.$as(promise.AsyncState, $.$srij.System.Runtime.InteropServices.JavaScript.JSHostImplementation.PromiseHolder);
                if (holder === null)
                {
                    throw new $.$$.System.InvalidOperationException().$ctor$12("Expected Task converted from JS Promise");
                }
                if (holder.IsDisposed)
                {
                    return;
                }
                $.$srij.Interop.Runtime.CancelPromise(holder.GCHandle);
            }
            //--TRIMMABLE-BOUNDARY-END(4295163915)
            
            static $h = 196619;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 131073,
  "m": [
//--TRIMMABLE-BOUNDARY-START(4295163915),
    {
      "r": 65537,
      "p": [
        {
          "n": "promise",
          "p": 177668097
        }
      ],
      "n": "CancelPromise",
      "d": 196619,
      "h": 4295163915,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(4295163915)
  ],
  "h": 196619
}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `System.Runtime.InteropServices.JavaScript.CancelablePromise`; }
        });
        //--TRIMMABLE-BOUNDARY-END(196619)
        
        
        //--TRIMMABLE-BOUNDARY-START(524299)
        $asm.$cls("$srij.System.Runtime.InteropServices.JavaScript.JSFunctionBinding", ($self) => class JSFunctionBinding extends $.$$.System.Object
        {
            //--TRIMMABLE-BOUNDARY-START(17180393483)
            $ctor$1()
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(17180393483);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(17180393483)
            
            //--TRIMMABLE-BOUNDARY-START(90194837515)
            /*JSBindingHeader**/ Header;
            //--TRIMMABLE-BOUNDARY-END(90194837515)
            
            //--TRIMMABLE-BOUNDARY-START(176094183435)
            /*JSBindingType**/ Sigs;
            //--TRIMMABLE-BOUNDARY-END(176094183435)
            
            //--TRIMMABLE-BOUNDARY-START(128849543179)
            /*uint*/ static nextImportHandle = 1;
            //--TRIMMABLE-BOUNDARY-END(128849543179)
            
            //--TRIMMABLE-BOUNDARY-START(94489804811)
            /*int*/ ImportHandle = 0;
            //--TRIMMABLE-BOUNDARY-END(94489804811)
            
            //--TRIMMABLE-BOUNDARY-START(120259608587)
            /*bool*/ IsAsync = false;
            //--TRIMMABLE-BOUNDARY-END(120259608587)
            
            //--TRIMMABLE-BOUNDARY-START(124554575883)
            /*bool*/ IsDiscardNoWait = false;
            //--TRIMMABLE-BOUNDARY-END(124554575883)
            
            //--TRIMMABLE-BOUNDARY-START(42950197259)
            /*string?*/ FunctionName = null;
            //--TRIMMABLE-BOUNDARY-END(42950197259)
            
            //--TRIMMABLE-BOUNDARY-START(589835)
            static $_JSBindingHeader;
            static get JSBindingHeader()
            {
                let $cls = $.$srij.System.Runtime.InteropServices.JavaScript.JSFunctionBinding;
                return $cls.$_JSBindingHeader ??= $asm.$nstr("$srij.System.Runtime.InteropServices.JavaScript.JSFunctionBinding.JSBindingHeader", ($self) => class JSBindingHeader extends $.$$.System.ValueType
                {
                    //--TRIMMABLE-BOUNDARY-START(30065360907)
                    /*int*/ static JSMarshalerSignatureHeaderSize = 32;
                    //--TRIMMABLE-BOUNDARY-END(30065360907)
                    
                    //--TRIMMABLE-BOUNDARY-START(47245230091)
                    /*int*/  get Version() { return this.$getField(0, $.$$.System.Int32); }
                    /*int*/  set Version(value) { this.$setField(0, $.$$.System.Int32, value); }
                    //--TRIMMABLE-BOUNDARY-END(47245230091)
                    
                    //--TRIMMABLE-BOUNDARY-START(8590524427)
                    /*int*/  get ArgumentCount() { return this.$getField(4, $.$$.System.Int32); }
                    /*int*/  set ArgumentCount(value) { this.$setField(4, $.$$.System.Int32, value); }
                    //--TRIMMABLE-BOUNDARY-END(8590524427)
                    
                    //--TRIMMABLE-BOUNDARY-START(25770393611)
                    /*int*/  get ImportHandle() { return this.$getField(8, $.$$.System.Int32); }
                    /*int*/  set ImportHandle(value) { this.$setField(8, $.$$.System.Int32, value); }
                    //--TRIMMABLE-BOUNDARY-END(25770393611)
                    
                    //--TRIMMABLE-BOUNDARY-START(21475426315)
                    /*int*/  get FunctionNameOffset() { return this.$getField(16, $.$$.System.Int32); }
                    /*int*/  set FunctionNameOffset(value) { this.$setField(16, $.$$.System.Int32, value); }
                    //--TRIMMABLE-BOUNDARY-END(21475426315)
                    
                    //--TRIMMABLE-BOUNDARY-START(17180459019)
                    /*int*/  get FunctionNameLength() { return this.$getField(20, $.$$.System.Int32); }
                    /*int*/  set FunctionNameLength(value) { this.$setField(20, $.$$.System.Int32, value); }
                    //--TRIMMABLE-BOUNDARY-END(17180459019)
                    
                    //--TRIMMABLE-BOUNDARY-START(38655295499)
                    /*int*/  get ModuleNameOffset() { return this.$getField(24, $.$$.System.Int32); }
                    /*int*/  set ModuleNameOffset(value) { this.$setField(24, $.$$.System.Int32, value); }
                    //--TRIMMABLE-BOUNDARY-END(38655295499)
                    
                    //--TRIMMABLE-BOUNDARY-START(34360328203)
                    /*int*/  get ModuleNameLength() { return this.$getField(28, $.$$.System.Int32); }
                    /*int*/  set ModuleNameLength(value) { this.$setField(28, $.$$.System.Int32, value); }
                    //--TRIMMABLE-BOUNDARY-END(34360328203)
                    
                    //--TRIMMABLE-BOUNDARY-START(12885491723)
                    /*JSBindingType*/  get Exception() { return this.$getField(32, $.$srij.System.Runtime.InteropServices.JavaScript.JSFunctionBinding.JSBindingType); }
                    /*JSBindingType*/  set Exception(value) { this.$setField(32, $.$srij.System.Runtime.InteropServices.JavaScript.JSFunctionBinding.JSBindingType, value); }
                    //--TRIMMABLE-BOUNDARY-END(12885491723)
                    
                    //--TRIMMABLE-BOUNDARY-START(42950262795)
                    /*JSBindingType*/  get Result() { return this.$getField(64, $.$srij.System.Runtime.InteropServices.JavaScript.JSFunctionBinding.JSBindingType); }
                    /*JSBindingType*/  set Result(value) { this.$setField(64, $.$srij.System.Runtime.InteropServices.JavaScript.JSFunctionBinding.JSBindingType, value); }
                    //--TRIMMABLE-BOUNDARY-END(42950262795)
                    
                    //--TRIMMABLE-BOUNDARY-START(4295557131)
                    //default value type constructor
                    $ctor$2()
                    {
                        return this;
                    }
                    //--TRIMMABLE-BOUNDARY-END(4295557131)
                    
                    Clone($copy)
                    {
                        let copy = $copy ?? new this.constructor();
                        copy.Version = this.Version;
                        copy.ArgumentCount = this.ArgumentCount;
                        copy.ImportHandle = this.ImportHandle;
                        copy.FunctionNameOffset = this.FunctionNameOffset;
                        copy.FunctionNameLength = this.FunctionNameLength;
                        copy.ModuleNameOffset = this.ModuleNameOffset;
                        copy.ModuleNameLength = this.ModuleNameLength;
                        copy.Exception = this.Exception.Clone();
                        copy.Result = this.Result.Clone();
                        return copy;
                    }
                    //default member initializer
                    constructor()
                    {
                        super();
                        //--TRIMMABLE-BOUNDARY-START(47245230091)
                        this.Version = 0;
                        //--TRIMMABLE-BOUNDARY-END(47245230091)
                        
                        //--TRIMMABLE-BOUNDARY-START(8590524427)
                        this.ArgumentCount = 0;
                        //--TRIMMABLE-BOUNDARY-END(8590524427)
                        
                        //--TRIMMABLE-BOUNDARY-START(25770393611)
                        this.ImportHandle = 0;
                        //--TRIMMABLE-BOUNDARY-END(25770393611)
                        
                        //--TRIMMABLE-BOUNDARY-START(21475426315)
                        this.FunctionNameOffset = 0;
                        //--TRIMMABLE-BOUNDARY-END(21475426315)
                        
                        //--TRIMMABLE-BOUNDARY-START(17180459019)
                        this.FunctionNameLength = 0;
                        //--TRIMMABLE-BOUNDARY-END(17180459019)
                        
                        //--TRIMMABLE-BOUNDARY-START(38655295499)
                        this.ModuleNameOffset = 0;
                        //--TRIMMABLE-BOUNDARY-END(38655295499)
                        
                        //--TRIMMABLE-BOUNDARY-START(34360328203)
                        this.ModuleNameLength = 0;
                        //--TRIMMABLE-BOUNDARY-END(34360328203)
                        
                        //--TRIMMABLE-BOUNDARY-START(12885491723)
                        this.Exception = $.$default($.$srij.System.Runtime.InteropServices.JavaScript.JSFunctionBinding.JSBindingType);
                        //--TRIMMABLE-BOUNDARY-END(12885491723)
                        
                        //--TRIMMABLE-BOUNDARY-START(42950262795)
                        this.Result = $.$default($.$srij.System.Runtime.InteropServices.JavaScript.JSFunctionBinding.JSBindingType);
                        //--TRIMMABLE-BOUNDARY-END(42950262795)
                        
                    }
                    //--TRIMMABLE-BOUNDARY-START(SINIT)
                    //Static Initializer
                    static $sinit()
                    {
                        {
                            //--TRIMMABLE-BOUNDARY-START(30065360907)
                            this.JSMarshalerSignatureHeaderSize = 32;
                            //--TRIMMABLE-BOUNDARY-END(30065360907)
                            
                        }
                    }
                    //--TRIMMABLE-BOUNDARY-END(SINIT)
                    
                    static $h = 589835;
                    static $z = 96;
                    static $f = 0b10100010000001010000000;
                    static $k = 2;
                    static $$md;
                    static get $md() { return this.$$md ??= {
  "b": 196609,
  "l": [
//--TRIMMABLE-BOUNDARY-START(30065360907),
    {
      "t": 655361,
      "n": "JSMarshalerSignatureHeaderSize",
      "d": 589835,
      "h": 30065360907,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(30065360907),
//--TRIMMABLE-BOUNDARY-START(47245230091),
    {
      "t": 655361,
      "n": "Version",
      "d": 589835,
      "h": 47245230091,
      "f": 4194305,
      "a": [
        {
          "t": 141557761,
          "c": 8731492353,
          "a": [
            {
              "v": 0,
              "t": 655361
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(47245230091),
//--TRIMMABLE-BOUNDARY-START(8590524427),
    {
      "t": 655361,
      "n": "ArgumentCount",
      "d": 589835,
      "h": 8590524427,
      "f": 4194305,
      "a": [
        {
          "t": 141557761,
          "c": 8731492353,
          "a": [
            {
              "v": 4,
              "t": 655361
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(8590524427),
//--TRIMMABLE-BOUNDARY-START(25770393611),
    {
      "t": 655361,
      "n": "ImportHandle",
      "d": 589835,
      "h": 25770393611,
      "f": 4194305,
      "a": [
        {
          "t": 141557761,
          "c": 8731492353,
          "a": [
            {
              "v": 8,
              "t": 655361
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(25770393611),
//--TRIMMABLE-BOUNDARY-START(21475426315),
    {
      "t": 655361,
      "n": "FunctionNameOffset",
      "d": 589835,
      "h": 21475426315,
      "f": 4194305,
      "a": [
        {
          "t": 141557761,
          "c": 8731492353,
          "a": [
            {
              "v": 16,
              "t": 655361
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(21475426315),
//--TRIMMABLE-BOUNDARY-START(17180459019),
    {
      "t": 655361,
      "n": "FunctionNameLength",
      "d": 589835,
      "h": 17180459019,
      "f": 4194305,
      "a": [
        {
          "t": 141557761,
          "c": 8731492353,
          "a": [
            {
              "v": 20,
              "t": 655361
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(17180459019),
//--TRIMMABLE-BOUNDARY-START(38655295499),
    {
      "t": 655361,
      "n": "ModuleNameOffset",
      "d": 589835,
      "h": 38655295499,
      "f": 4194305,
      "a": [
        {
          "t": 141557761,
          "c": 8731492353,
          "a": [
            {
              "v": 24,
              "t": 655361
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(38655295499),
//--TRIMMABLE-BOUNDARY-START(34360328203),
    {
      "t": 655361,
      "n": "ModuleNameLength",
      "d": 589835,
      "h": 34360328203,
      "f": 4194305,
      "a": [
        {
          "t": 141557761,
          "c": 8731492353,
          "a": [
            {
              "v": 28,
              "t": 655361
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(34360328203),
//--TRIMMABLE-BOUNDARY-START(42950262795),
    {
      "t": 655371,
      "n": "Result",
      "d": 589835,
      "h": 42950262795,
      "f": 4194305,
      "a": [
        {
          "t": 141557761,
          "c": 8731492353,
          "a": [
            {
              "v": 64,
              "t": 655361
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(42950262795)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295557131),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 589835,
      "h": 4295557131,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295557131)
  ],
  "d": 524299,
  "h": 589835,
  "a": [
    {
      "t": 147390465,
      "c": 13032292353,
      "a": [
        {
          "v": 2,
          "t": 142868481
        }
      ],
      "n": [
        {
          "n": "Pack",
          "v": 4,
          "t": 655361
        }
      ]
    }
  ]
}; }
                    static get $b() { return $.$$.System.ValueType; }
                    static get $fullName() { return `System.Runtime.InteropServices.JavaScript.JSFunctionBinding.JSBindingHeader`; }
                }, $cls, ($v) => $cls.$_JSBindingHeader = $v);
            }
            //--TRIMMABLE-BOUNDARY-END(589835)
            
            //--TRIMMABLE-BOUNDARY-START(655371)
            static $_JSBindingType;
            static get JSBindingType()
            {
                let $cls = $.$srij.System.Runtime.InteropServices.JavaScript.JSFunctionBinding;
                return $cls.$_JSBindingType ??= $asm.$nstr("$srij.System.Runtime.InteropServices.JavaScript.JSFunctionBinding.JSBindingType", ($self) => class JSBindingType extends $.$$.System.ValueType
                {
                    //--TRIMMABLE-BOUNDARY-START(25770459147)
                    /*MarshalerType*/  get Type() { return this.$getField(0, $.$srij.System.Runtime.InteropServices.JavaScript.MarshalerType); }
                    /*MarshalerType*/  set Type(value) { this.$setField(0, $.$srij.System.Runtime.InteropServices.JavaScript.MarshalerType, value); }
                    //--TRIMMABLE-BOUNDARY-END(25770459147)
                    
                    //--TRIMMABLE-BOUNDARY-START(21475491851)
                    /*MarshalerType*/  get ResultMarshalerType() { return this.$getField(16, $.$srij.System.Runtime.InteropServices.JavaScript.MarshalerType); }
                    /*MarshalerType*/  set ResultMarshalerType(value) { this.$setField(16, $.$srij.System.Runtime.InteropServices.JavaScript.MarshalerType, value); }
                    //--TRIMMABLE-BOUNDARY-END(21475491851)
                    
                    //--TRIMMABLE-BOUNDARY-START(8590589963)
                    /*MarshalerType*/  get Arg1MarshalerType() { return this.$getField(20, $.$srij.System.Runtime.InteropServices.JavaScript.MarshalerType); }
                    /*MarshalerType*/  set Arg1MarshalerType(value) { this.$setField(20, $.$srij.System.Runtime.InteropServices.JavaScript.MarshalerType, value); }
                    //--TRIMMABLE-BOUNDARY-END(8590589963)
                    
                    //--TRIMMABLE-BOUNDARY-START(12885557259)
                    /*MarshalerType*/  get Arg2MarshalerType() { return this.$getField(24, $.$srij.System.Runtime.InteropServices.JavaScript.MarshalerType); }
                    /*MarshalerType*/  set Arg2MarshalerType(value) { this.$setField(24, $.$srij.System.Runtime.InteropServices.JavaScript.MarshalerType, value); }
                    //--TRIMMABLE-BOUNDARY-END(12885557259)
                    
                    //--TRIMMABLE-BOUNDARY-START(17180524555)
                    /*MarshalerType*/  get Arg3MarshalerType() { return this.$getField(28, $.$srij.System.Runtime.InteropServices.JavaScript.MarshalerType); }
                    /*MarshalerType*/  set Arg3MarshalerType(value) { this.$setField(28, $.$srij.System.Runtime.InteropServices.JavaScript.MarshalerType, value); }
                    //--TRIMMABLE-BOUNDARY-END(17180524555)
                    
                    //--TRIMMABLE-BOUNDARY-START(4295622667)
                    //default value type constructor
                    $ctor$2()
                    {
                        return this;
                    }
                    //--TRIMMABLE-BOUNDARY-END(4295622667)
                    
                    Clone($copy)
                    {
                        let copy = $copy ?? new this.constructor();
                        copy.Type = this.Type;
                        copy.ResultMarshalerType = this.ResultMarshalerType;
                        copy.Arg1MarshalerType = this.Arg1MarshalerType;
                        copy.Arg2MarshalerType = this.Arg2MarshalerType;
                        copy.Arg3MarshalerType = this.Arg3MarshalerType;
                        return copy;
                    }
                    //default member initializer
                    constructor()
                    {
                        super();
                        //--TRIMMABLE-BOUNDARY-START(25770459147)
                        this.Type = 0;
                        //--TRIMMABLE-BOUNDARY-END(25770459147)
                        
                        //--TRIMMABLE-BOUNDARY-START(21475491851)
                        this.ResultMarshalerType = 0;
                        //--TRIMMABLE-BOUNDARY-END(21475491851)
                        
                        //--TRIMMABLE-BOUNDARY-START(8590589963)
                        this.Arg1MarshalerType = 0;
                        //--TRIMMABLE-BOUNDARY-END(8590589963)
                        
                        //--TRIMMABLE-BOUNDARY-START(12885557259)
                        this.Arg2MarshalerType = 0;
                        //--TRIMMABLE-BOUNDARY-END(12885557259)
                        
                        //--TRIMMABLE-BOUNDARY-START(17180524555)
                        this.Arg3MarshalerType = 0;
                        //--TRIMMABLE-BOUNDARY-END(17180524555)
                        
                    }
                    static $h = 655371;
                    static $z = 32;
                    static $f = 0b10100010000001010000000;
                    static $k = 2;
                    static $$md;
                    static get $md() { return this.$$md ??= {
  "b": 196609,
  "l": [
//--TRIMMABLE-BOUNDARY-START(25770459147),
    {
      "t": 3670027,
      "n": "Type",
      "d": 655371,
      "h": 25770459147,
      "f": 4194312,
      "a": [
        {
          "t": 141557761,
          "c": 8731492353,
          "a": [
            {
              "v": 0,
              "t": 655361
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(25770459147),
//--TRIMMABLE-BOUNDARY-START(21475491851),
    {
      "t": 3670027,
      "n": "ResultMarshalerType",
      "d": 655371,
      "h": 21475491851,
      "f": 4194312,
      "a": [
        {
          "t": 141557761,
          "c": 8731492353,
          "a": [
            {
              "v": 16,
              "t": 655361
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(21475491851),
//--TRIMMABLE-BOUNDARY-START(8590589963),
    {
      "t": 3670027,
      "n": "Arg1MarshalerType",
      "d": 655371,
      "h": 8590589963,
      "f": 4194312,
      "a": [
        {
          "t": 141557761,
          "c": 8731492353,
          "a": [
            {
              "v": 20,
              "t": 655361
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(8590589963),
//--TRIMMABLE-BOUNDARY-START(12885557259),
    {
      "t": 3670027,
      "n": "Arg2MarshalerType",
      "d": 655371,
      "h": 12885557259,
      "f": 4194312,
      "a": [
        {
          "t": 141557761,
          "c": 8731492353,
          "a": [
            {
              "v": 24,
              "t": 655361
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(12885557259),
//--TRIMMABLE-BOUNDARY-START(17180524555),
    {
      "t": 3670027,
      "n": "Arg3MarshalerType",
      "d": 655371,
      "h": 17180524555,
      "f": 4194312,
      "a": [
        {
          "t": 141557761,
          "c": 8731492353,
          "a": [
            {
              "v": 28,
              "t": 655361
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(17180524555)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295622667),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 655371,
      "h": 4295622667,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295622667)
  ],
  "d": 524299,
  "h": 655371,
  "a": [
    {
      "t": 147390465,
      "c": 13032292353,
      "a": [
        {
          "v": 2,
          "t": 142868481
        }
      ],
      "n": [
        {
          "n": "Pack",
          "v": 4,
          "t": 655361
        },
        {
          "n": "Size",
          "v": 32,
          "t": 655361
        }
      ]
    }
  ]
}; }
                    static get $b() { return $.$$.System.ValueType; }
                    static get $fullName() { return `System.Runtime.InteropServices.JavaScript.JSFunctionBinding.JSBindingType`; }
                }, $cls, ($v) => $cls.$_JSBindingType = $v);
            }
            //--TRIMMABLE-BOUNDARY-END(655371)
            
            //--TRIMMABLE-BOUNDARY-START(21475360779)
            /*int */ get ArgumentCount()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(51540131851);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Header.GetAt(0).ArgumentCount;
            }
            /*int */ set ArgumentCount(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(146029412363);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.Header.GetAt(0).ArgumentCount = value;
            }
            //--TRIMMABLE-BOUNDARY-END(21475360779)
            
            //--TRIMMABLE-BOUNDARY-START(184684118027)
            /*int */ get Version()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(85899870219);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Header.GetAt(0).Version;
            }
            /*int */ set Version(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(171799216139);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.Header.GetAt(0).Version = value;
            }
            //--TRIMMABLE-BOUNDARY-END(184684118027)
            
            //--TRIMMABLE-BOUNDARY-START(137439477771)
            /*JSBindingType */ get Result()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(77309935627);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Header.GetAt(0).Result;
            }
            /*JSBindingType */ set Result(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(163209281547);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.Header.GetAt(0).Result = value.Clone();
            }
            //--TRIMMABLE-BOUNDARY-END(137439477771)
            
            //--TRIMMABLE-BOUNDARY-START(38655229963)
            /*JSBindingType */ get Exception()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(60130066443);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Header.GetAt(0).Exception;
            }
            /*JSBindingType */ set Exception(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(154619346955);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.Header.GetAt(0).Exception = value.Clone();
            }
            //--TRIMMABLE-BOUNDARY-END(38655229963)
            
            //--TRIMMABLE-BOUNDARY-START(180389150731)
            /*JSBindingType*/ get_Item$1(/*int*/ position)
            {
                return this.Sigs.GetAt(((position - 1) | 0));
            }
            //--TRIMMABLE-BOUNDARY-END(180389150731)
            
            //--TRIMMABLE-BOUNDARY-START(98784772107)
            static /*void */ InvokeJS(/*JSFunctionBinding*/ signature, /*Span<JSMarshalerArgument>*/ $arguments)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(98784772107);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$srij.System.Runtime.InteropServices.JavaScript.JSFunctionBinding.InvokeJSImportImpl(signature, $arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(98784772107)
            
            //--TRIMMABLE-BOUNDARY-START(25770328075)
            static /*JSFunctionBinding */ BindJSFunction(/*string*/ functionName, /*string*/ moduleName, /*ReadOnlySpan<JSMarshalerType>*/ signatures)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25770328075);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$$.System.Runtime.InteropServices.RuntimeInformation.OSArchitecture !== 4/*Architecture.Wasm*/)
                {
                    throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
                }
                return $.$srij.System.Runtime.InteropServices.JavaScript.JSFunctionBinding.BindJSImportImpl(functionName, moduleName, signatures);
            }
            //--TRIMMABLE-BOUNDARY-END(25770328075)
            
            //--TRIMMABLE-BOUNDARY-START(34360262667)
            static /*JSFunctionBinding */ BindManagedFunction(/*string*/ fullyQualifiedName, /*int*/ signatureHash, /*ReadOnlySpan<JSMarshalerType>*/ signatures)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(34360262667);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$$.System.Runtime.InteropServices.RuntimeInformation.OSArchitecture !== 4/*Architecture.Wasm*/)
                {
                    throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
                }
                return $.$srij.System.Runtime.InteropServices.JavaScript.JSHostImplementation.BindManagedFunction(fullyQualifiedName, signatureHash, signatures);
            }
            //--TRIMMABLE-BOUNDARY-END(34360262667)
            
            //--TRIMMABLE-BOUNDARY-START(103079739403)
            static /*void */ InvokeJSFunction(/*JSObject*/ jsFunction, /*Span<JSMarshalerArgument>*/ $arguments)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(103079739403);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                jsFunction.AssertNotDisposed();
                $.$srij.System.Runtime.InteropServices.JavaScript.JSFunctionBinding.InvokeJSFunctionCurrent(jsFunction, $arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(103079739403)
            
            //--TRIMMABLE-BOUNDARY-START(107374706699)
            static /*void */ InvokeJSFunctionCurrent(/*JSObject*/ jsFunction, /*Span<JSMarshalerArgument>*/ $arguments)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(107374706699);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let functionHandle = jsFunction.JSHandle;
                /*fixed*/ 
                {
                    /*JSMarshalerArgument**/ let ptr = $arguments.GetPinnableReference();
                    $.$srij.Interop.Runtime.InvokeJSFunction(functionHandle, $.$cast(ptr, $.$$.System.IntPtr));
                    /*ref JSMarshalerArgument*/ let exceptionArg = $arguments.get_Item(0);
                    if (exceptionArg.$v.slot.Type !== 0/*MarshalerType.None*/)
                    {
                        $.$srij.System.Runtime.InteropServices.JavaScript.JSHostImplementation.ThrowException(exceptionArg);
                    }
                }
            }
            //--TRIMMABLE-BOUNDARY-END(107374706699)
            
            //--TRIMMABLE-BOUNDARY-START(115964641291)
            static /*void */ InvokeJSImportImpl(/*JSFunctionBinding*/ signature, /*Span<JSMarshalerArgument>*/ $arguments)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(115964641291);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*ref JSMarshalerArgument*/ let exc = $arguments.get_Item(0);
                /*ref JSMarshalerArgument*/ let res = $arguments.get_Item(1);
                /*var*/ let targetContext = $.$srij.System.Runtime.InteropServices.JavaScript.JSProxyContext.MainThreadContext;
                if (signature.IsAsync)
                {
                    /*var*/ let holder = targetContext.CreatePromiseHolder();
                    res.$v.slot.Type = 30/*MarshalerType.TaskPreCreated*/;
                    res.$v.slot.GCHandle = holder.GCHandle;
                }
                if (signature.IsDiscardNoWait)
                {
                    $arguments.get_Item(1).$v.slot.Type = 26/*MarshalerType.DiscardNoWait*/;
                }
                $.$srij.System.Runtime.InteropServices.JavaScript.JSFunctionBinding.InvokeJSImportCurrent(signature, $arguments);
                if (signature.IsAsync)
                {
                    if ($arguments.get_Item(1).$v.slot.Type === 0/*MarshalerType.None*/)
                    {
                        /*var*/ let holderHandle = $.$$.System.Runtime.InteropServices.GCHandle.op_Explicit$1($arguments.get_Item(1).$v.slot.GCHandle);
                        holderHandle.Free();
                    }
                }
            }
            //--TRIMMABLE-BOUNDARY-END(115964641291)
            
            //--TRIMMABLE-BOUNDARY-START(111669673995)
            static /*void */ InvokeJSImportCurrent(/*JSFunctionBinding*/ signature, /*Span<JSMarshalerArgument>*/ $arguments)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(111669673995);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*fixed*/ 
                {
                    /*JSMarshalerArgument**/ let args = $arguments.GetPinnableReference();
                    $.$srij.Interop.Runtime.InvokeJSImportST(signature.ImportHandle, $.$cast(args, $.$$.System.IntPtr));
                }
                /*ref JSMarshalerArgument*/ let exceptionArg = $arguments.get_Item(0);
                if (exceptionArg.$v.slot.Type !== 0/*MarshalerType.None*/)
                {
                    $.$srij.System.Runtime.InteropServices.JavaScript.JSHostImplementation.ThrowException(exceptionArg);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(111669673995)
            
            //--TRIMMABLE-BOUNDARY-START(30065295371)
            static /*JSFunctionBinding */ BindJSImportImpl(/*string*/ functionName, /*string*/ moduleName, /*ReadOnlySpan<JSMarshalerType>*/ signatures)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(30065295371);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let signature = $.$srij.System.Runtime.InteropServices.JavaScript.JSHostImplementation.GetMethodSignature(signatures, functionName, moduleName);
                /*nint*/ let exceptionPtr = $.$srij.Interop.Runtime.BindJSImportST(signature.Header);
                if (exceptionPtr !== $.$$.System.IntPtr.Zero)
                {
                    /*var*/ let message = $.$$.System.Runtime.InteropServices.Marshal.PtrToStringUni$1(exceptionPtr);
                    $.$$.System.Runtime.InteropServices.Marshal.FreeHGlobal(exceptionPtr);
                    throw new $.$srij.System.Runtime.InteropServices.JavaScript.JSException().$ctor$6(message);
                }
                $.$srij.System.Runtime.InteropServices.JavaScript.JSHostImplementation.FreeMethodSignatureBuffer(signature);
                return signature;
            }
            //--TRIMMABLE-BOUNDARY-END(30065295371)
            
            //--TRIMMABLE-BOUNDARY-START(133144510475)
            static /*void */ ResolveOrRejectPromise(/*JSProxyContext*/ targetContext, /*Span<JSMarshalerArgument>*/ $arguments)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(133144510475);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*ref JSMarshalerArgument*/ let exc = $arguments.get_Item(0);
                {
                    /*fixed*/ 
                    {
                        /*JSMarshalerArgument**/ let ptr = $arguments.GetPinnableReference();
                        $.$srij.Interop.Runtime.ResolveOrRejectPromise($.$cast(ptr, $.$$.System.IntPtr));
                        if (exc.$v.slot.Type !== 0/*MarshalerType.None*/)
                        {
                            $.$srij.System.Runtime.InteropServices.JavaScript.JSHostImplementation.ThrowException(exc);
                        }
                    }
                }
            }
            //--TRIMMABLE-BOUNDARY-END(133144510475)
            
            //default member initializer
            constructor()
            {
                super();
                //--TRIMMABLE-BOUNDARY-START(90194837515)
                this.Header = $.$default($.$typePointer($.$srij.System.Runtime.InteropServices.JavaScript.JSFunctionBinding.JSBindingHeader));
                //--TRIMMABLE-BOUNDARY-END(90194837515)
                
                //--TRIMMABLE-BOUNDARY-START(176094183435)
                this.Sigs = $.$default($.$typePointer($.$srij.System.Runtime.InteropServices.JavaScript.JSFunctionBinding.JSBindingType));
                //--TRIMMABLE-BOUNDARY-END(176094183435)
                
            }
            static $h = 524299;
            static $f = 0b10010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 131073,
  "p": [
//--TRIMMABLE-BOUNDARY-START(21475360779),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 51540131851,
        "f": 50331656
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 146029412363,
        "f": 83886088
      },
      "n": "ArgumentCount",
      "d": 524299,
      "h": 21475360779,
      "f": 2097160
    },
//--TRIMMABLE-BOUNDARY-END(21475360779),
//--TRIMMABLE-BOUNDARY-START(184684118027),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 85899870219,
        "f": 50331656
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 171799216139,
        "f": 83886088
      },
      "n": "Version",
      "d": 524299,
      "h": 184684118027,
      "f": 2097160
    },
//--TRIMMABLE-BOUNDARY-END(184684118027),
//--TRIMMABLE-BOUNDARY-START(137439477771),
    {
      "p": 655371,
      "g": {
        "r": 0,
        "d": 0,
        "h": 77309935627,
        "f": 50331656
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 163209281547,
        "f": 83886088
      },
      "n": "Result",
      "d": 524299,
      "h": 137439477771,
      "f": 2097160
    },
//--TRIMMABLE-BOUNDARY-END(137439477771),
//--TRIMMABLE-BOUNDARY-START(180389150731),
    {
      "p": 655371,
      "i": [
        {
          "n": "position",
          "p": 655361
        }
      ],
      "g": {
        "r": 0,
        "d": 0,
        "h": 68720001035,
        "f": 50331656
      },
      "n": "Item",
      "o": "@$1",
      "d": 524299,
      "h": 180389150731,
      "f": 2097160
    },
//--TRIMMABLE-BOUNDARY-END(180389150731)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(98784772107),
    {
      "r": 65537,
      "p": [
        {
          "n": "signature",
          "p": 524299
        },
        {
          "n": "arguments",
          "p": $.$$.System.Span$$($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument).$h
        }
      ],
      "n": "InvokeJS",
      "d": 524299,
      "h": 98784772107,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(98784772107),
//--TRIMMABLE-BOUNDARY-START(25770328075),
    {
      "r": 524299,
      "p": [
        {
          "n": "functionName",
          "p": 1310721
        },
        {
          "n": "moduleName",
          "p": 1310721
        },
        {
          "n": "signatures",
          "p": $.$$.System.ReadOnlySpan$$($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType).$h
        }
      ],
      "n": "BindJSFunction",
      "d": 524299,
      "h": 25770328075,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(25770328075),
//--TRIMMABLE-BOUNDARY-START(34360262667),
    {
      "r": 524299,
      "p": [
        {
          "n": "fullyQualifiedName",
          "p": 1310721
        },
        {
          "n": "signatureHash",
          "p": 655361
        },
        {
          "n": "signatures",
          "p": $.$$.System.ReadOnlySpan$$($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType).$h
        }
      ],
      "n": "BindManagedFunction",
      "d": 524299,
      "h": 34360262667,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(34360262667),
//--TRIMMABLE-BOUNDARY-START(103079739403),
    {
      "r": 65537,
      "p": [
        {
          "n": "jsFunction",
          "p": 2228235
        },
        {
          "n": "arguments",
          "p": $.$$.System.Span$$($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument).$h
        }
      ],
      "n": "InvokeJSFunction",
      "d": 524299,
      "h": 103079739403,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(103079739403),
//--TRIMMABLE-BOUNDARY-START(107374706699),
    {
      "r": 65537,
      "p": [
        {
          "n": "jsFunction",
          "p": 2228235
        },
        {
          "n": "arguments",
          "p": $.$$.System.Span$$($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument).$h
        }
      ],
      "n": "InvokeJSFunctionCurrent",
      "d": 524299,
      "h": 107374706699,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(107374706699),
//--TRIMMABLE-BOUNDARY-START(115964641291),
    {
      "r": 65537,
      "p": [
        {
          "n": "signature",
          "p": 524299
        },
        {
          "n": "arguments",
          "p": $.$$.System.Span$$($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument).$h
        }
      ],
      "n": "InvokeJSImportImpl",
      "d": 524299,
      "h": 115964641291,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(115964641291),
//--TRIMMABLE-BOUNDARY-START(111669673995),
    {
      "r": 65537,
      "p": [
        {
          "n": "signature",
          "p": 524299
        },
        {
          "n": "arguments",
          "p": $.$$.System.Span$$($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument).$h
        }
      ],
      "n": "InvokeJSImportCurrent",
      "d": 524299,
      "h": 111669673995,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(111669673995),
//--TRIMMABLE-BOUNDARY-START(30065295371),
    {
      "r": 524299,
      "p": [
        {
          "n": "functionName",
          "p": 1310721
        },
        {
          "n": "moduleName",
          "p": 1310721
        },
        {
          "n": "signatures",
          "p": $.$$.System.ReadOnlySpan$$($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType).$h
        }
      ],
      "n": "BindJSImportImpl",
      "d": 524299,
      "h": 30065295371,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(30065295371),
//--TRIMMABLE-BOUNDARY-START(133144510475),
    {
      "r": 65537,
      "p": [
        {
          "n": "targetContext",
          "p": 2293771
        },
        {
          "n": "arguments",
          "p": $.$$.System.Span$$($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument).$h
        }
      ],
      "n": "ResolveOrRejectPromise",
      "d": 524299,
      "h": 133144510475,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(133144510475)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(90194837515),
    {
      "t": $.$typePointer($.$srij.System.Runtime.InteropServices.JavaScript.JSFunctionBinding.JSBindingHeader).$h,
      "n": "Header",
      "d": 524299,
      "h": 90194837515,
      "f": 4194312
    },
//--TRIMMABLE-BOUNDARY-END(90194837515),
//--TRIMMABLE-BOUNDARY-START(176094183435),
    {
      "t": $.$typePointer($.$srij.System.Runtime.InteropServices.JavaScript.JSFunctionBinding.JSBindingType).$h,
      "n": "Sigs",
      "d": 524299,
      "h": 176094183435,
      "f": 4194312
    },
//--TRIMMABLE-BOUNDARY-END(176094183435),
//--TRIMMABLE-BOUNDARY-START(128849543179),
    {
      "t": 720897,
      "n": "nextImportHandle",
      "d": 524299,
      "h": 128849543179,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(128849543179),
//--TRIMMABLE-BOUNDARY-START(94489804811),
    {
      "t": 655361,
      "n": "ImportHandle",
      "d": 524299,
      "h": 94489804811,
      "f": 4194312
    },
//--TRIMMABLE-BOUNDARY-END(94489804811),
//--TRIMMABLE-BOUNDARY-START(120259608587),
    {
      "t": 262145,
      "n": "IsAsync",
      "d": 524299,
      "h": 120259608587,
      "f": 4194312
    },
//--TRIMMABLE-BOUNDARY-END(120259608587),
//--TRIMMABLE-BOUNDARY-START(124554575883),
    {
      "t": 262145,
      "n": "IsDiscardNoWait",
      "d": 524299,
      "h": 124554575883,
      "f": 4194312
    },
//--TRIMMABLE-BOUNDARY-END(124554575883),
//--TRIMMABLE-BOUNDARY-START(42950197259),
    {
      "t": 1310721,
      "n": "FunctionName",
      "d": 524299,
      "h": 42950197259,
      "f": 4194312
    },
//--TRIMMABLE-BOUNDARY-END(42950197259)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(17180393483),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 524299,
      "h": 17180393483,
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(17180393483)
  ],
  "j": [589835,655371
  ],
  "h": 524299,
  "a": [
    {
      "t": 54263809,
      "c": 8644198401,
      "a": [
        {
          "v": false,
          "t": 262145
        }
      ]
    },
    {
      "t": 159055873,
      "c": 4454023169,
      "a": [
        {
          "v": "browser",
          "t": 1310721
        }
      ]
    },
    {
      "t": 64290817,
      "c": 12949192705,
      "a": [
        {
          "v": 1,
          "t": 64356353
        }
      ]
    }
  ]
}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `System.Runtime.InteropServices.JavaScript.JSFunctionBinding`; }
        });
        //--TRIMMABLE-BOUNDARY-END(524299)
        
        
        //--TRIMMABLE-BOUNDARY-START(3735563)
        $asm.$cls("$srij.System.SR", ($self) => class SR
        {
            //--TRIMMABLE-BOUNDARY-START(463860203531)
            /*global::System.Resources.ResourceManager*/ static s_resourceManager = null;
            //--TRIMMABLE-BOUNDARY-END(463860203531)
            
            //--TRIMMABLE-BOUNDARY-START(450975301643)
            /*global::System.Globalization.CultureInfo*/ static resourceCulture = null;
            //--TRIMMABLE-BOUNDARY-END(450975301643)
            
            //--TRIMMABLE-BOUNDARY-START(455270268939)
            static /*global::System.Resources.ResourceManager */ get ResourceManager()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(270586675211);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$$.System.Object.ReferenceEquals($.$srij.System.SR.s_resourceManager, null))
                {
                    /*global::System.Resources.ResourceManager*/ let temp = new $.$$.System.Resources.ResourceManager().$ctor$3("System.Runtime.InteropServices.JavaScript", $.$srij.System.SR.$type.Assembly);
                    $.$srij.System.SR.s_resourceManager = temp;
                }
                return $.$srij.System.SR.s_resourceManager;
            }
            //--TRIMMABLE-BOUNDARY-END(455270268939)
            
            //--TRIMMABLE-BOUNDARY-START(21478572043)
            static /*global::System.Globalization.CultureInfo */ get Culture()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(184687329291);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$srij.System.SR.resourceCulture;
            }
            static /*global::System.Globalization.CultureInfo */ set Culture(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(476745105419);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$srij.System.SR.resourceCulture = value;
            }
            //--TRIMMABLE-BOUNDARY-END(21478572043)
            
            //--TRIMMABLE-BOUNDARY-START(8593670155)
            static /*string */ get ArgumentCannotBeNull()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(158917525515);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "Invalid argument: {0} can not be null.";
            }
            //--TRIMMABLE-BOUNDARY-END(8593670155)
            
            //--TRIMMABLE-BOUNDARY-START(81608114187)
            static /*string */ FormatArgumentCannotBeNull(/*object*/ arg1)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(81608114187);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$$.System.String.Format$9("Invalid argument: {0} can not be null.", arg1);
            }
            //--TRIMMABLE-BOUNDARY-END(81608114187)
            
            //--TRIMMABLE-BOUNDARY-START(12888637451)
            static /*string */ get ArgumentCannotBeNullWithLength()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(167507460107);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "Invalid argument: {0} can not be null and must have a length.";
            }
            //--TRIMMABLE-BOUNDARY-END(12888637451)
            
            //--TRIMMABLE-BOUNDARY-START(85903081483)
            static /*string */ FormatArgumentCannotBeNullWithLength(/*object*/ arg1)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(85903081483);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$$.System.String.Format$9("Invalid argument: {0} can not be null and must have a length.", arg1);
            }
            //--TRIMMABLE-BOUNDARY-END(85903081483)
            
            //--TRIMMABLE-BOUNDARY-START(481040072715)
            static /*string */ get SystemRuntimeInteropServicesJavaScript_PlatformNotSupported()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(287766544395);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "System.Runtime.InteropServices.JavaScript is not supported on this platform.";
            }
            //--TRIMMABLE-BOUNDARY-END(481040072715)
            
            //--TRIMMABLE-BOUNDARY-START(493924974603)
            static /*string */ get TypedArrayNotCorrectType()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(313536348171);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "TypedArray is not of correct type.";
            }
            //--TRIMMABLE-BOUNDARY-END(493924974603)
            
            //--TRIMMABLE-BOUNDARY-START(498219941899)
            static /*string */ get UnableCastNullToType()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(322126282763);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "Unable to cast null to type {0}.";
            }
            //--TRIMMABLE-BOUNDARY-END(498219941899)
            
            //--TRIMMABLE-BOUNDARY-START(115967852555)
            static /*string */ FormatUnableCastNullToType(/*object*/ arg1)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(115967852555);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$$.System.String.Format$9("Unable to cast null to type {0}.", arg1);
            }
            //--TRIMMABLE-BOUNDARY-END(115967852555)
            
            //--TRIMMABLE-BOUNDARY-START(502514909195)
            static /*string */ get UnableCastObjectToType()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(330716217355);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "Unable to cast object of type {0} to type {1}.";
            }
            //--TRIMMABLE-BOUNDARY-END(502514909195)
            
            //--TRIMMABLE-BOUNDARY-START(120262819851)
            static /*string */ FormatUnableCastObjectToType(/*object*/ arg1, /*object*/ arg2)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(120262819851);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$$.System.String.Format$8("Unable to cast object of type {0} to type {1}.", arg1, arg2);
            }
            //--TRIMMABLE-BOUNDARY-END(120262819851)
            
            //--TRIMMABLE-BOUNDARY-START(438090399755)
            static /*string */ get MissingManagedEntrypointHandle()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(244816871435);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "Managed entrypoint handle is not set.";
            }
            //--TRIMMABLE-BOUNDARY-END(438090399755)
            
            //--TRIMMABLE-BOUNDARY-START(17183604747)
            static /*string */ get CannotResolveManagedEntrypointHandle()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(176097394699);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "Cannot resolve managed entrypoint handle.";
            }
            //--TRIMMABLE-BOUNDARY-END(17183604747)
            
            //--TRIMMABLE-BOUNDARY-START(459565236235)
            static /*string */ get ReturnTypeNotSupportedForMain()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(279176609803);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "Return type '{0}' from main method in not supported.";
            }
            //--TRIMMABLE-BOUNDARY-END(459565236235)
            
            //--TRIMMABLE-BOUNDARY-START(103082950667)
            static /*string */ FormatReturnTypeNotSupportedForMain(/*object*/ arg1)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(103082950667);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$$.System.String.Format$9("Return type '{0}' from main method in not supported.", arg1);
            }
            //--TRIMMABLE-BOUNDARY-END(103082950667)
            
            //--TRIMMABLE-BOUNDARY-START(446680334347)
            static /*string */ get NullToManagedCallback()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(261996740619);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "ToManagedCallback is null.";
            }
            //--TRIMMABLE-BOUNDARY-END(446680334347)
            
            //--TRIMMABLE-BOUNDARY-START(442385367051)
            static /*string */ get NullPromiseHolder()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(253406806027);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "PromiseHolder is null.";
            }
            //--TRIMMABLE-BOUNDARY-END(442385367051)
            
            //--TRIMMABLE-BOUNDARY-START(25773539339)
            static /*string */ get EmptyProfileData()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(193277263883);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "Empty profile data.";
            }
            //--TRIMMABLE-BOUNDARY-END(25773539339)
            
            //--TRIMMABLE-BOUNDARY-START(30068506635)
            static /*string */ get ErrorLegacySettingProperty()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(201867198475);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "Error setting {0} on (js-obj js '{1}'): {2}.";
            }
            //--TRIMMABLE-BOUNDARY-END(30068506635)
            
            //--TRIMMABLE-BOUNDARY-START(90198048779)
            static /*string */ FormatErrorLegacySettingProperty(/*object*/ arg1, /*object*/ arg2, /*object*/ arg3)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(90198048779);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$$.System.String.Format$7("Error setting {0} on (js-obj js '{1}'): {2}.", arg1, arg2, arg3);
            }
            //--TRIMMABLE-BOUNDARY-END(90198048779)
            
            //--TRIMMABLE-BOUNDARY-START(34363473931)
            static /*string */ get ErrorResolvingFromGlobalThis()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(210457133067);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "Error resolving property {0} from globalThis.";
            }
            //--TRIMMABLE-BOUNDARY-END(34363473931)
            
            //--TRIMMABLE-BOUNDARY-START(94493016075)
            static /*string */ FormatErrorResolvingFromGlobalThis(/*object*/ arg1)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(94493016075);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$$.System.String.Format$9("Error resolving property {0} from globalThis.", arg1);
            }
            //--TRIMMABLE-BOUNDARY-END(94493016075)
            
            //--TRIMMABLE-BOUNDARY-START(38658441227)
            static /*string */ get FailedToMarshalException()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(219047067659);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "Failed to marshal exception.";
            }
            //--TRIMMABLE-BOUNDARY-END(38658441227)
            
            //--TRIMMABLE-BOUNDARY-START(42953408523)
            static /*string */ get FailedToMarshalPromiseHolder()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(227637002251);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "Failed to marshal Promise callback.";
            }
            //--TRIMMABLE-BOUNDARY-END(42953408523)
            
            //--TRIMMABLE-BOUNDARY-START(433795432459)
            static /*string */ get InvalidInFlightCounter()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(236226936843);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "Invalid InFlightCounter for JSObject {0}, expected: {1}, actual: {2}.";
            }
            //--TRIMMABLE-BOUNDARY-END(433795432459)
            
            //--TRIMMABLE-BOUNDARY-START(98787983371)
            static /*string */ FormatInvalidInFlightCounter(/*object*/ arg1, /*object*/ arg2, /*object*/ arg3)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(98787983371);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$$.System.String.Format$7("Invalid InFlightCounter for JSObject {0}, expected: {1}, actual: {2}.", arg1, arg2, arg3);
            }
            //--TRIMMABLE-BOUNDARY-END(98787983371)
            
            //--TRIMMABLE-BOUNDARY-START(485335040011)
            static /*string */ get ToJSNotImplemented()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(296356478987);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "ToJS for {0} is not implemented.";
            }
            //--TRIMMABLE-BOUNDARY-END(485335040011)
            
            //--TRIMMABLE-BOUNDARY-START(107377917963)
            static /*string */ FormatToJSNotImplemented(/*object*/ arg1)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(107377917963);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$$.System.String.Format$9("ToJS for {0} is not implemented.", arg1);
            }
            //--TRIMMABLE-BOUNDARY-END(107377917963)
            
            //--TRIMMABLE-BOUNDARY-START(489630007307)
            static /*string */ get ToManagedNotImplemented()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(304946413579);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "ToManaged for {0} is not implemented.";
            }
            //--TRIMMABLE-BOUNDARY-END(489630007307)
            
            //--TRIMMABLE-BOUNDARY-START(111672885259)
            static /*string */ FormatToManagedNotImplemented(/*object*/ arg1)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(111672885259);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$$.System.String.Format$9("ToManaged for {0} is not implemented.", arg1);
            }
            //--TRIMMABLE-BOUNDARY-END(111672885259)
            
            //--TRIMMABLE-BOUNDARY-START(506809876491)
            static /*string */ get UnableToResolveHandleAsException()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(339306151947);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "Unable to resolve the handle as an Exception.";
            }
            //--TRIMMABLE-BOUNDARY-END(506809876491)
            
            //--TRIMMABLE-BOUNDARY-START(511104843787)
            static /*string */ get UnsupportedArrayType()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(347896086539);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "Unsupported array type {0}. Only single-dimensional arrays with a zero lower bound can be marshaled to JS.";
            }
            //--TRIMMABLE-BOUNDARY-END(511104843787)
            
            //--TRIMMABLE-BOUNDARY-START(124557787147)
            static /*string */ FormatUnsupportedArrayType(/*object*/ arg1)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(124557787147);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$$.System.String.Format$9("Unsupported array type {0}. Only single-dimensional arrays with a zero lower bound can be marshaled to JS.", arg1);
            }
            //--TRIMMABLE-BOUNDARY-END(124557787147)
            
            //--TRIMMABLE-BOUNDARY-START(515399811083)
            static /*string */ get UnsupportedElementType()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(356486021131);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "Unsupported element type {0}.";
            }
            //--TRIMMABLE-BOUNDARY-END(515399811083)
            
            //--TRIMMABLE-BOUNDARY-START(128852754443)
            static /*string */ FormatUnsupportedElementType(/*object*/ arg1)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(128852754443);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$$.System.String.Format$9("Unsupported element type {0}.", arg1);
            }
            //--TRIMMABLE-BOUNDARY-END(128852754443)
            
            //--TRIMMABLE-BOUNDARY-START(519694778379)
            static /*string */ get UnsupportedEnumType()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(365075955723);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "Unsupported enum type {0}.";
            }
            //--TRIMMABLE-BOUNDARY-END(519694778379)
            
            //--TRIMMABLE-BOUNDARY-START(133147721739)
            static /*string */ FormatUnsupportedEnumType(/*object*/ arg1)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(133147721739);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$$.System.String.Format$9("Unsupported enum type {0}.", arg1);
            }
            //--TRIMMABLE-BOUNDARY-END(133147721739)
            
            //--TRIMMABLE-BOUNDARY-START(523989745675)
            static /*string */ get UnsupportedLegacyMarshlerType()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(373665890315);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "Unsupported marshal type {0}.";
            }
            //--TRIMMABLE-BOUNDARY-END(523989745675)
            
            //--TRIMMABLE-BOUNDARY-START(137442689035)
            static /*string */ FormatUnsupportedLegacyMarshlerType(/*object*/ arg1)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(137442689035);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$$.System.String.Format$9("Unsupported marshal type {0}.", arg1);
            }
            //--TRIMMABLE-BOUNDARY-END(137442689035)
            
            //--TRIMMABLE-BOUNDARY-START(528284712971)
            static /*string */ get UnsupportedNullableType()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(382255824907);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "Unsupported nullable type {0}.";
            }
            //--TRIMMABLE-BOUNDARY-END(528284712971)
            
            //--TRIMMABLE-BOUNDARY-START(141737656331)
            static /*string */ FormatUnsupportedNullableType(/*object*/ arg1)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(141737656331);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$$.System.String.Format$9("Unsupported nullable type {0}.", arg1);
            }
            //--TRIMMABLE-BOUNDARY-END(141737656331)
            
            //--TRIMMABLE-BOUNDARY-START(532579680267)
            static /*string */ get UnsupportedTaskResultType()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(390845759499);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "Unsupported task result type {0}.";
            }
            //--TRIMMABLE-BOUNDARY-END(532579680267)
            
            //--TRIMMABLE-BOUNDARY-START(146032623627)
            static /*string */ FormatUnsupportedTaskResultType(/*object*/ arg1)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(146032623627);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$$.System.String.Format$9("Unsupported task result type {0}.", arg1);
            }
            //--TRIMMABLE-BOUNDARY-END(146032623627)
            
            //--TRIMMABLE-BOUNDARY-START(536874647563)
            static /*string */ get UriConstructorMissing()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(399435694091);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "Constructor on type 'System.Uri' not found. Please consider to protect it's constructor from trimming.";
            }
            //--TRIMMABLE-BOUNDARY-END(536874647563)
            
            //--TRIMMABLE-BOUNDARY-START(541169614859)
            static /*string */ get UriTypeMissing()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(408025628683);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "The type System.Uri could not be found. Please consider to protect the class and it's constructor from trimming.";
            }
            //--TRIMMABLE-BOUNDARY-END(541169614859)
            
            //--TRIMMABLE-BOUNDARY-START(549759549451)
            static /*string */ get ValueOutOf52BitRange()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(416615563275);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "Overflow: value {0} is out of {1} {2} range.";
            }
            //--TRIMMABLE-BOUNDARY-END(549759549451)
            
            //--TRIMMABLE-BOUNDARY-START(150327590923)
            static /*string */ FormatValueOutOf52BitRange(/*object*/ arg1, /*object*/ arg2, /*object*/ arg3)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(150327590923);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$$.System.String.Format$7("Overflow: value {0} is out of {1} {2} range.", arg1, arg2, arg3);
            }
            //--TRIMMABLE-BOUNDARY-END(150327590923)
            
            //--TRIMMABLE-BOUNDARY-START(468155170827)
            /*bool*/ static s_usingResourceKeys = false;
            //--TRIMMABLE-BOUNDARY-END(468155170827)
            
            //--TRIMMABLE-BOUNDARY-START(429500465163)
            static /*bool */ GetUsingResourceKeysSwitchValue()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(429500465163);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    /*bool*/ let usingResourceKeys;
                    return $.$$.System.AppContext.TryGetSwitch("System.Resources.UseSystemResourceKeys", $.$ref(() => usingResourceKeys, ($v) => usingResourceKeys = $v, $.$$.System.Boolean)) ? usingResourceKeys : false;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(429500465163)
            
            //--TRIMMABLE-BOUNDARY-START(545464582155)
            static /*bool */ UsingResourceKeys()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(545464582155);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return $.$srij.System.SR.s_usingResourceKeys;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(545464582155)
            
            //--TRIMMABLE-BOUNDARY-START(425205497867)
            static /*string */ GetResourceString$1(/*string*/ resourceKey)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(425205497867);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$srij.System.SR.UsingResourceKeys())
                {
                    return resourceKey;
                }
                /*string?*/ let resourceString = null;
                try
                {
                    resourceString = $.$srij.System.SR.ResourceManager.GetString$1(resourceKey);
                }
                catch($e)
                {
                }
                return resourceString;
            }
            //--TRIMMABLE-BOUNDARY-END(425205497867)
            
            //--TRIMMABLE-BOUNDARY-START(420910530571)
            static /*string */ GetResourceString(/*string*/ resourceKey, /*string*/ defaultString)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(420910530571);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*string*/ let resourceString = $.$srij.System.SR.GetResourceString$1(resourceKey);
                return $.$$.System.String.op_Equality(resourceKey, resourceString) || $.$$.System.String.op_Equality(resourceString, null) ? defaultString : resourceString;
            }
            //--TRIMMABLE-BOUNDARY-END(420910530571)
            
            //--TRIMMABLE-BOUNDARY-START(73018179595)
            static /*string */ Format$6(/*string*/ resourceFormat, /*object?*/ p1)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(73018179595);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$srij.System.SR.UsingResourceKeys())
                {
                    return $.$$.System.String.Join$7(", ", $.$$.System.ReadOnlySpan$$($.$$.System.Object).op_Implicit$1([ resourceFormat, p1 ]));
                }
                return $.$$.System.String.Format$9(resourceFormat, p1);
            }
            //--TRIMMABLE-BOUNDARY-END(73018179595)
            
            //--TRIMMABLE-BOUNDARY-START(68723212299)
            static /*string */ Format$5(/*string*/ resourceFormat, /*object?*/ p1, /*object?*/ p2)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(68723212299);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$srij.System.SR.UsingResourceKeys())
                {
                    return $.$$.System.String.Join$7(", ", $.$$.System.ReadOnlySpan$$($.$$.System.Object).op_Implicit$1([ resourceFormat, p1, p2 ]));
                }
                return $.$$.System.String.Format$8(resourceFormat, p1, p2);
            }
            //--TRIMMABLE-BOUNDARY-END(68723212299)
            
            //--TRIMMABLE-BOUNDARY-START(64428245003)
            static /*string */ Format$4(/*string*/ resourceFormat, /*object?*/ p1, /*object?*/ p2, /*object?*/ p3)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(64428245003);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$srij.System.SR.UsingResourceKeys())
                {
                    return $.$$.System.String.Join$7(", ", $.$$.System.ReadOnlySpan$$($.$$.System.Object).op_Implicit$1([ resourceFormat, p1, p2, p3 ]));
                }
                return $.$$.System.String.Format$7(resourceFormat, p1, p2, p3);
            }
            //--TRIMMABLE-BOUNDARY-END(64428245003)
            
            //--TRIMMABLE-BOUNDARY-START(77313146891)
            static /*string */ Format$7(/*string*/ resourceFormat, /*params object?[]?*/ args)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(77313146891);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (args !== null)
                {
                    if ($.$srij.System.SR.UsingResourceKeys())
                    {
                        return resourceFormat + ", " + $.$$.System.String.Join$6(", ", args);
                    }
                    return $.$$.System.String.Format$10(resourceFormat, args);
                }
                return resourceFormat;
            }
            //--TRIMMABLE-BOUNDARY-END(77313146891)
            
            //--TRIMMABLE-BOUNDARY-START(55838310411)
            static /*string */ Format$2(/*IFormatProvider?*/ provider, /*string*/ resourceFormat, /*object?*/ p1)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(55838310411);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$srij.System.SR.UsingResourceKeys())
                {
                    return $.$$.System.String.Join$7(", ", $.$$.System.ReadOnlySpan$$($.$$.System.Object).op_Implicit$1([ resourceFormat, p1 ]));
                }
                return $.$$.System.String.Format$2(provider, resourceFormat, p1);
            }
            //--TRIMMABLE-BOUNDARY-END(55838310411)
            
            //--TRIMMABLE-BOUNDARY-START(51543343115)
            static /*string */ Format$1(/*IFormatProvider?*/ provider, /*string*/ resourceFormat, /*object?*/ p1, /*object?*/ p2)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(51543343115);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$srij.System.SR.UsingResourceKeys())
                {
                    return $.$$.System.String.Join$7(", ", $.$$.System.ReadOnlySpan$$($.$$.System.Object).op_Implicit$1([ resourceFormat, p1, p2 ]));
                }
                return $.$$.System.String.Format$1(provider, resourceFormat, p1, p2);
            }
            //--TRIMMABLE-BOUNDARY-END(51543343115)
            
            //--TRIMMABLE-BOUNDARY-START(47248375819)
            static /*string */ Format(/*IFormatProvider?*/ provider, /*string*/ resourceFormat, /*object?*/ p1, /*object?*/ p2, /*object?*/ p3)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(47248375819);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$srij.System.SR.UsingResourceKeys())
                {
                    return $.$$.System.String.Join$7(", ", $.$$.System.ReadOnlySpan$$($.$$.System.Object).op_Implicit$1([ resourceFormat, p1, p2, p3 ]));
                }
                return $.$$.System.String.Format(provider, resourceFormat, p1, p2, p3);
            }
            //--TRIMMABLE-BOUNDARY-END(47248375819)
            
            //--TRIMMABLE-BOUNDARY-START(60133277707)
            static /*string */ Format$3(/*IFormatProvider?*/ provider, /*string*/ resourceFormat, /*params object?[]?*/ args)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(60133277707);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (args !== null)
                {
                    if ($.$srij.System.SR.UsingResourceKeys())
                    {
                        return resourceFormat + ", " + $.$$.System.String.Join$6(", ", args);
                    }
                    return $.$$.System.String.Format$3(provider, resourceFormat, args);
                }
                return resourceFormat;
            }
            //--TRIMMABLE-BOUNDARY-END(60133277707)
            
            //--TRIMMABLE-BOUNDARY-START(4298702859)
            //Static Initializer
            static $sinit()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(468155170827)
                    this.s_usingResourceKeys = $.$srij.System.SR.GetUsingResourceKeysSwitchValue();
                    //--TRIMMABLE-BOUNDARY-END(468155170827)
                    
                }
            }
            //--TRIMMABLE-BOUNDARY-END(4298702859)
            
            static $h = 3735563;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 131073,
  "h": 3735563
}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `System.SR`; }
        });
        //--TRIMMABLE-BOUNDARY-END(3735563)
        
        
        //--TRIMMABLE-BOUNDARY-START(2162699)
        $asm.$cls("$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType", ($self) => class JSMarshalerType extends $.$$.System.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8592097291)
            /*JSFunctionBinding.JSBindingType*/ _signatureType;
            //--TRIMMABLE-BOUNDARY-END(8592097291)
            
            //--TRIMMABLE-BOUNDARY-START(111671312395)
            $ctor$1()
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(111671312395);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this._signatureType = $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType.Void._signatureType;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(111671312395)
            
            //--TRIMMABLE-BOUNDARY-START(115966279691)
            $ctor$2(/*JSFunctionBinding.JSBindingType*/ signatureType)
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(115966279691);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this._signatureType = signatureType.Clone();
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(115966279691)
            
            //--TRIMMABLE-BOUNDARY-START(455268696075)
            /*JSMarshalerType*/ static Void = null;
            //--TRIMMABLE-BOUNDARY-END(455268696075)
            
            //--TRIMMABLE-BOUNDARY-START(188980723723)
            /*JSMarshalerType*/ static Discard = null;
            //--TRIMMABLE-BOUNDARY-END(188980723723)
            
            //--TRIMMABLE-BOUNDARY-START(193275691019)
            /*JSMarshalerType*/ static DiscardNoWait = null;
            //--TRIMMABLE-BOUNDARY-END(193275691019)
            
            //--TRIMMABLE-BOUNDARY-START(150326018059)
            /*JSMarshalerType*/ static Boolean = null;
            //--TRIMMABLE-BOUNDARY-END(150326018059)
            
            //--TRIMMABLE-BOUNDARY-START(154620985355)
            /*JSMarshalerType*/ static Byte = null;
            //--TRIMMABLE-BOUNDARY-END(154620985355)
            
            //--TRIMMABLE-BOUNDARY-START(158915952651)
            /*JSMarshalerType*/ static Char = null;
            //--TRIMMABLE-BOUNDARY-END(158915952651)
            
            //--TRIMMABLE-BOUNDARY-START(403729088523)
            /*JSMarshalerType*/ static Int16 = null;
            //--TRIMMABLE-BOUNDARY-END(403729088523)
            
            //--TRIMMABLE-BOUNDARY-START(408024055819)
            /*JSMarshalerType*/ static Int32 = null;
            //--TRIMMABLE-BOUNDARY-END(408024055819)
            
            //--TRIMMABLE-BOUNDARY-START(412319023115)
            /*JSMarshalerType*/ static Int52 = null;
            //--TRIMMABLE-BOUNDARY-END(412319023115)
            
            //--TRIMMABLE-BOUNDARY-START(146031050763)
            /*JSMarshalerType*/ static BigInt64 = null;
            //--TRIMMABLE-BOUNDARY-END(146031050763)
            
            //--TRIMMABLE-BOUNDARY-START(197570658315)
            /*JSMarshalerType*/ static Double = null;
            //--TRIMMABLE-BOUNDARY-END(197570658315)
            
            //--TRIMMABLE-BOUNDARY-START(433793859595)
            /*JSMarshalerType*/ static Single = null;
            //--TRIMMABLE-BOUNDARY-END(433793859595)
            
            //--TRIMMABLE-BOUNDARY-START(416613990411)
            /*JSMarshalerType*/ static IntPtr = null;
            //--TRIMMABLE-BOUNDARY-END(416613990411)
            
            //--TRIMMABLE-BOUNDARY-START(420908957707)
            /*JSMarshalerType*/ static JSObject = null;
            //--TRIMMABLE-BOUNDARY-END(420908957707)
            
            //--TRIMMABLE-BOUNDARY-START(429498892299)
            /*JSMarshalerType*/ static Object = null;
            //--TRIMMABLE-BOUNDARY-END(429498892299)
            
            //--TRIMMABLE-BOUNDARY-START(442383794187)
            /*JSMarshalerType*/ static String = null;
            //--TRIMMABLE-BOUNDARY-END(442383794187)
            
            //--TRIMMABLE-BOUNDARY-START(201865625611)
            /*JSMarshalerType*/ static Exception = null;
            //--TRIMMABLE-BOUNDARY-END(201865625611)
            
            //--TRIMMABLE-BOUNDARY-START(180390789131)
            /*JSMarshalerType*/ static DateTime = null;
            //--TRIMMABLE-BOUNDARY-END(180390789131)
            
            //--TRIMMABLE-BOUNDARY-START(184685756427)
            /*JSMarshalerType*/ static DateTimeOffset = null;
            //--TRIMMABLE-BOUNDARY-END(184685756427)
            
            //--TRIMMABLE-BOUNDARY-START(425203925003)
            static /*JSMarshalerType */ Nullable(/*JSMarshalerType*/ primitive)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(425203925003);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType.CheckNullable(primitive);
                return new $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType().$ctor$2((() =>
                {
                    //new $.$srij.System.Runtime.InteropServices.JavaScript.JSFunctionBinding.JSBindingType()
                    const $t1 = $.$srij.System.Runtime.InteropServices.JavaScript.JSFunctionBinding.JSBindingType;
                    const $i1 = new $t1();
                    $i1.Type = 19/*MarshalerType.Nullable*/;
                    $i1.ResultMarshalerType = primitive._signatureType.Type;
                    return $i1;
                })());
            }
            //--TRIMMABLE-BOUNDARY-END(425203925003)
            
            //--TRIMMABLE-BOUNDARY-START(12887064587)
            /*JSMarshalerType*/ static _task = null;
            //--TRIMMABLE-BOUNDARY-END(12887064587)
            
            //--TRIMMABLE-BOUNDARY-START(446678761483)
            static /*JSMarshalerType */ Task()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(446678761483);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType._task;
            }
            //--TRIMMABLE-BOUNDARY-END(446678761483)
            
            //--TRIMMABLE-BOUNDARY-START(450973728779)
            static /*JSMarshalerType */ Task$1(/*JSMarshalerType*/ result)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(450973728779);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType.CheckTask(result);
                return new $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType().$ctor$2((() =>
                {
                    //new $.$srij.System.Runtime.InteropServices.JavaScript.JSFunctionBinding.JSBindingType()
                    const $t1 = $.$srij.System.Runtime.InteropServices.JavaScript.JSFunctionBinding.JSBindingType;
                    const $i1 = new $t1();
                    $i1.Type = 20/*MarshalerType.Task*/;
                    $i1.ResultMarshalerType = result._signatureType.Type;
                    return $i1;
                })());
            }
            //--TRIMMABLE-BOUNDARY-END(450973728779)
            
            //--TRIMMABLE-BOUNDARY-START(137441116171)
            static /*JSMarshalerType */ Array(/*JSMarshalerType*/ element)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(137441116171);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType.CheckArray(element);
                return new $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType().$ctor$2((() =>
                {
                    //new $.$srij.System.Runtime.InteropServices.JavaScript.JSFunctionBinding.JSBindingType()
                    const $t1 = $.$srij.System.Runtime.InteropServices.JavaScript.JSFunctionBinding.JSBindingType;
                    const $i1 = new $t1();
                    $i1.Type = 21/*MarshalerType.Array*/;
                    $i1.Arg1MarshalerType = element._signatureType.Type;
                    return $i1;
                })());
            }
            //--TRIMMABLE-BOUNDARY-END(137441116171)
            
            //--TRIMMABLE-BOUNDARY-START(141736083467)
            static /*JSMarshalerType */ ArraySegment(/*JSMarshalerType*/ element)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(141736083467);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType.CheckArraySegment(element);
                return new $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType().$ctor$2((() =>
                {
                    //new $.$srij.System.Runtime.InteropServices.JavaScript.JSFunctionBinding.JSBindingType()
                    const $t1 = $.$srij.System.Runtime.InteropServices.JavaScript.JSFunctionBinding.JSBindingType;
                    const $i1 = new $t1();
                    $i1.Type = 22/*MarshalerType.ArraySegment*/;
                    $i1.Arg1MarshalerType = element._signatureType.Type;
                    return $i1;
                })());
            }
            //--TRIMMABLE-BOUNDARY-END(141736083467)
            
            //--TRIMMABLE-BOUNDARY-START(438088826891)
            static /*JSMarshalerType */ Span(/*JSMarshalerType*/ element)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(438088826891);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType.CheckArraySegment(element);
                return new $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType().$ctor$2((() =>
                {
                    //new $.$srij.System.Runtime.InteropServices.JavaScript.JSFunctionBinding.JSBindingType()
                    const $t1 = $.$srij.System.Runtime.InteropServices.JavaScript.JSFunctionBinding.JSBindingType;
                    const $i1 = new $t1();
                    $i1.Type = 23/*MarshalerType.Span*/;
                    $i1.Arg1MarshalerType = element._signatureType.Type;
                    return $i1;
                })());
            }
            //--TRIMMABLE-BOUNDARY-END(438088826891)
            
            //--TRIMMABLE-BOUNDARY-START(4297129995)
            /*JSMarshalerType*/ static _action = null;
            //--TRIMMABLE-BOUNDARY-END(4297129995)
            
            //--TRIMMABLE-BOUNDARY-START(120261246987)
            static /*JSMarshalerType */ Action()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(120261246987);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType._action;
            }
            //--TRIMMABLE-BOUNDARY-END(120261246987)
            
            //--TRIMMABLE-BOUNDARY-START(133146148875)
            static /*JSMarshalerType */ Action$3(/*JSMarshalerType*/ arg1)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(133146148875);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType.CheckTask(arg1);
                return new $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType().$ctor$2((() =>
                {
                    //new $.$srij.System.Runtime.InteropServices.JavaScript.JSFunctionBinding.JSBindingType()
                    const $t1 = $.$srij.System.Runtime.InteropServices.JavaScript.JSFunctionBinding.JSBindingType;
                    const $i1 = new $t1();
                    $i1.Type = 24/*MarshalerType.Action*/;
                    $i1.Arg1MarshalerType = arg1._signatureType.Type;
                    return $i1;
                })());
            }
            //--TRIMMABLE-BOUNDARY-END(133146148875)
            
            //--TRIMMABLE-BOUNDARY-START(128851181579)
            static /*JSMarshalerType */ Action$2(/*JSMarshalerType*/ arg1, /*JSMarshalerType*/ arg2)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(128851181579);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType.CheckTask(arg1);
                $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType.CheckTask(arg2);
                return new $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType().$ctor$2((() =>
                {
                    //new $.$srij.System.Runtime.InteropServices.JavaScript.JSFunctionBinding.JSBindingType()
                    const $t1 = $.$srij.System.Runtime.InteropServices.JavaScript.JSFunctionBinding.JSBindingType;
                    const $i1 = new $t1();
                    $i1.Type = 24/*MarshalerType.Action*/;
                    $i1.Arg1MarshalerType = arg1._signatureType.Type;
                    $i1.Arg2MarshalerType = arg2._signatureType.Type;
                    return $i1;
                })());
            }
            //--TRIMMABLE-BOUNDARY-END(128851181579)
            
            //--TRIMMABLE-BOUNDARY-START(124556214283)
            static /*JSMarshalerType */ Action$1(/*JSMarshalerType*/ arg1, /*JSMarshalerType*/ arg2, /*JSMarshalerType*/ arg3)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(124556214283);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType.CheckTask(arg1);
                $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType.CheckTask(arg2);
                $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType.CheckTask(arg3);
                return new $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType().$ctor$2((() =>
                {
                    //new $.$srij.System.Runtime.InteropServices.JavaScript.JSFunctionBinding.JSBindingType()
                    const $t1 = $.$srij.System.Runtime.InteropServices.JavaScript.JSFunctionBinding.JSBindingType;
                    const $i1 = new $t1();
                    $i1.Type = 24/*MarshalerType.Action*/;
                    $i1.Arg1MarshalerType = arg1._signatureType.Type;
                    $i1.Arg2MarshalerType = arg2._signatureType.Type;
                    $i1.Arg3MarshalerType = arg3._signatureType.Type;
                    return $i1;
                })());
            }
            //--TRIMMABLE-BOUNDARY-END(124556214283)
            
            //--TRIMMABLE-BOUNDARY-START(219045494795)
            static /*JSMarshalerType */ Function$3(/*JSMarshalerType*/ result)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(219045494795);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType.CheckTask(result);
                return new $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType().$ctor$2((() =>
                {
                    //new $.$srij.System.Runtime.InteropServices.JavaScript.JSFunctionBinding.JSBindingType()
                    const $t1 = $.$srij.System.Runtime.InteropServices.JavaScript.JSFunctionBinding.JSBindingType;
                    const $i1 = new $t1();
                    $i1.Type = 25/*MarshalerType.Function*/;
                    $i1.ResultMarshalerType = result._signatureType.Type;
                    return $i1;
                })());
            }
            //--TRIMMABLE-BOUNDARY-END(219045494795)
            
            //--TRIMMABLE-BOUNDARY-START(214750527499)
            static /*JSMarshalerType */ Function$2(/*JSMarshalerType*/ arg1, /*JSMarshalerType*/ result)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(214750527499);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType.CheckTask(arg1);
                $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType.CheckTask(result);
                return new $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType().$ctor$2((() =>
                {
                    //new $.$srij.System.Runtime.InteropServices.JavaScript.JSFunctionBinding.JSBindingType()
                    const $t1 = $.$srij.System.Runtime.InteropServices.JavaScript.JSFunctionBinding.JSBindingType;
                    const $i1 = new $t1();
                    $i1.Type = 25/*MarshalerType.Function*/;
                    $i1.Arg1MarshalerType = arg1._signatureType.Type;
                    $i1.ResultMarshalerType = result._signatureType.Type;
                    return $i1;
                })());
            }
            //--TRIMMABLE-BOUNDARY-END(214750527499)
            
            //--TRIMMABLE-BOUNDARY-START(210455560203)
            static /*JSMarshalerType */ Function$1(/*JSMarshalerType*/ arg1, /*JSMarshalerType*/ arg2, /*JSMarshalerType*/ result)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(210455560203);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType.CheckTask(arg1);
                $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType.CheckTask(arg2);
                $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType.CheckTask(result);
                return new $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType().$ctor$2((() =>
                {
                    //new $.$srij.System.Runtime.InteropServices.JavaScript.JSFunctionBinding.JSBindingType()
                    const $t1 = $.$srij.System.Runtime.InteropServices.JavaScript.JSFunctionBinding.JSBindingType;
                    const $i1 = new $t1();
                    $i1.Type = 25/*MarshalerType.Function*/;
                    $i1.Arg1MarshalerType = arg1._signatureType.Type;
                    $i1.Arg2MarshalerType = arg2._signatureType.Type;
                    $i1.ResultMarshalerType = result._signatureType.Type;
                    return $i1;
                })());
            }
            //--TRIMMABLE-BOUNDARY-END(210455560203)
            
            //--TRIMMABLE-BOUNDARY-START(206160592907)
            static /*JSMarshalerType */ Function(/*JSMarshalerType*/ arg1, /*JSMarshalerType*/ arg2, /*JSMarshalerType*/ arg3, /*JSMarshalerType*/ result)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(206160592907);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType.CheckTask(arg1);
                $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType.CheckTask(arg2);
                $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType.CheckTask(arg3);
                $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType.CheckTask(result);
                return new $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType().$ctor$2((() =>
                {
                    //new $.$srij.System.Runtime.InteropServices.JavaScript.JSFunctionBinding.JSBindingType()
                    const $t1 = $.$srij.System.Runtime.InteropServices.JavaScript.JSFunctionBinding.JSBindingType;
                    const $i1 = new $t1();
                    $i1.Type = 25/*MarshalerType.Function*/;
                    $i1.Arg1MarshalerType = arg1._signatureType.Type;
                    $i1.Arg2MarshalerType = arg2._signatureType.Type;
                    $i1.Arg3MarshalerType = arg3._signatureType.Type;
                    $i1.ResultMarshalerType = result._signatureType.Type;
                    return $i1;
                })());
            }
            //--TRIMMABLE-BOUNDARY-END(206160592907)
            
            //--TRIMMABLE-BOUNDARY-START(171800854539)
            static /*void */ CheckNullable(/*JSMarshalerType*/ underlyingType)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(171800854539);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*MarshalerType*/ let underlying = underlyingType._signatureType.Type;
                if (underlying === 3/*MarshalerType.Boolean*/ || underlying === 4/*MarshalerType.Byte*/ || underlying === 6/*MarshalerType.Int16*/ || underlying === 7/*MarshalerType.Int32*/ || underlying === 9/*MarshalerType.BigInt64*/ || underlying === 8/*MarshalerType.Int52*/ || underlying === 12/*MarshalerType.IntPtr*/ || underlying === 10/*MarshalerType.Double*/ || underlying === 11/*MarshalerType.Single*/ || underlying === 5/*MarshalerType.Char*/ || underlying === 17/*MarshalerType.DateTime*/ || underlying === 18/*MarshalerType.DateTimeOffset*/)
                {
                    return;
                }
                throw new $.$$.System.ArgumentException().$ctor$13($.$srij.System.SR.Format$6($.$srij.System.SR.UnsupportedNullableType, $.$box(underlying, $.$srij.System.Runtime.InteropServices.JavaScript.MarshalerType)), "underlyingType");
            }
            //--TRIMMABLE-BOUNDARY-END(171800854539)
            
            //--TRIMMABLE-BOUNDARY-START(163210919947)
            static /*void */ CheckArray(/*JSMarshalerType*/ underlyingType)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(163210919947);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*MarshalerType*/ let underlying = underlyingType._signatureType.Type;
                if (underlying === 4/*MarshalerType.Byte*/ || underlying === 7/*MarshalerType.Int32*/ || underlying === 10/*MarshalerType.Double*/ || underlying === 15/*MarshalerType.String*/ || underlying === 14/*MarshalerType.Object*/ || underlying === 13/*MarshalerType.JSObject*/)
                {
                    return;
                }
                throw new $.$$.System.ArgumentException().$ctor$13($.$srij.System.SR.Format$6($.$srij.System.SR.UnsupportedElementType, $.$box(underlying, $.$srij.System.Runtime.InteropServices.JavaScript.MarshalerType)), "underlyingType");
            }
            //--TRIMMABLE-BOUNDARY-END(163210919947)
            
            //--TRIMMABLE-BOUNDARY-START(167505887243)
            static /*void */ CheckArraySegment(/*JSMarshalerType*/ underlyingType)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(167505887243);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*MarshalerType*/ let underlying = underlyingType._signatureType.Type;
                if (underlying === 4/*MarshalerType.Byte*/ || underlying === 7/*MarshalerType.Int32*/ || underlying === 10/*MarshalerType.Double*/)
                {
                    return;
                }
                throw new $.$$.System.ArgumentException().$ctor$13($.$srij.System.SR.Format$6($.$srij.System.SR.UnsupportedElementType, $.$box(underlying, $.$srij.System.Runtime.InteropServices.JavaScript.MarshalerType)), "underlyingType");
            }
            //--TRIMMABLE-BOUNDARY-END(167505887243)
            
            //--TRIMMABLE-BOUNDARY-START(176095821835)
            static /*void */ CheckTask(/*JSMarshalerType*/ underlyingType)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(176095821835);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*MarshalerType*/ let underlying = underlyingType._signatureType.Type;
                if (underlying === 21/*MarshalerType.Array*/ || underlying === 22/*MarshalerType.ArraySegment*/ || underlying === 23/*MarshalerType.Span*/ || underlying === 20/*MarshalerType.Task*/ || underlying === 24/*MarshalerType.Action*/ || underlying === 25/*MarshalerType.Function*/)
                {
                    throw new $.$$.System.ArgumentException().$ctor$13($.$srij.System.SR.Format$6($.$srij.System.SR.UnsupportedTaskResultType, $.$box(underlying, $.$srij.System.Runtime.InteropServices.JavaScript.MarshalerType)), "underlyingType");
                }
            }
            //--TRIMMABLE-BOUNDARY-END(176095821835)
            
            //default member initializer
            constructor()
            {
                super();
                //--TRIMMABLE-BOUNDARY-START(8592097291)
                this._signatureType = $.$default($.$srij.System.Runtime.InteropServices.JavaScript.JSFunctionBinding.JSBindingType);
                //--TRIMMABLE-BOUNDARY-END(8592097291)
                
            }
            //--TRIMMABLE-BOUNDARY-START(107376345099)
            //Static Initializer
            static $sinit()
            {
                {
                    this.Void = new $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType().$ctor$2((() =>
                    {
                        //new $.$srij.System.Runtime.InteropServices.JavaScript.JSFunctionBinding.JSBindingType()
                        const $t1 = $.$srij.System.Runtime.InteropServices.JavaScript.JSFunctionBinding.JSBindingType;
                        const $i1 = new $t1();
                        $i1.Type = 1/*MarshalerType.Void*/;
                        return $i1;
                    })());
                }
                {
                    this.Discard = new $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType().$ctor$2((() =>
                    {
                        //new $.$srij.System.Runtime.InteropServices.JavaScript.JSFunctionBinding.JSBindingType()
                        const $t1 = $.$srij.System.Runtime.InteropServices.JavaScript.JSFunctionBinding.JSBindingType;
                        const $i1 = new $t1();
                        $i1.Type = 2/*MarshalerType.Discard*/;
                        return $i1;
                    })());
                }
                {
                    this.DiscardNoWait = new $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType().$ctor$2((() =>
                    {
                        //new $.$srij.System.Runtime.InteropServices.JavaScript.JSFunctionBinding.JSBindingType()
                        const $t1 = $.$srij.System.Runtime.InteropServices.JavaScript.JSFunctionBinding.JSBindingType;
                        const $i1 = new $t1();
                        $i1.Type = 26/*MarshalerType.DiscardNoWait*/;
                        return $i1;
                    })());
                }
                {
                    this.Boolean = new $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType().$ctor$2((() =>
                    {
                        //new $.$srij.System.Runtime.InteropServices.JavaScript.JSFunctionBinding.JSBindingType()
                        const $t1 = $.$srij.System.Runtime.InteropServices.JavaScript.JSFunctionBinding.JSBindingType;
                        const $i1 = new $t1();
                        $i1.Type = 3/*MarshalerType.Boolean*/;
                        return $i1;
                    })());
                }
                {
                    this.Byte = new $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType().$ctor$2((() =>
                    {
                        //new $.$srij.System.Runtime.InteropServices.JavaScript.JSFunctionBinding.JSBindingType()
                        const $t1 = $.$srij.System.Runtime.InteropServices.JavaScript.JSFunctionBinding.JSBindingType;
                        const $i1 = new $t1();
                        $i1.Type = 4/*MarshalerType.Byte*/;
                        return $i1;
                    })());
                }
                {
                    this.Char = new $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType().$ctor$2((() =>
                    {
                        //new $.$srij.System.Runtime.InteropServices.JavaScript.JSFunctionBinding.JSBindingType()
                        const $t1 = $.$srij.System.Runtime.InteropServices.JavaScript.JSFunctionBinding.JSBindingType;
                        const $i1 = new $t1();
                        $i1.Type = 5/*MarshalerType.Char*/;
                        return $i1;
                    })());
                }
                {
                    this.Int16 = new $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType().$ctor$2((() =>
                    {
                        //new $.$srij.System.Runtime.InteropServices.JavaScript.JSFunctionBinding.JSBindingType()
                        const $t1 = $.$srij.System.Runtime.InteropServices.JavaScript.JSFunctionBinding.JSBindingType;
                        const $i1 = new $t1();
                        $i1.Type = 6/*MarshalerType.Int16*/;
                        return $i1;
                    })());
                }
                {
                    this.Int32 = new $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType().$ctor$2((() =>
                    {
                        //new $.$srij.System.Runtime.InteropServices.JavaScript.JSFunctionBinding.JSBindingType()
                        const $t1 = $.$srij.System.Runtime.InteropServices.JavaScript.JSFunctionBinding.JSBindingType;
                        const $i1 = new $t1();
                        $i1.Type = 7/*MarshalerType.Int32*/;
                        return $i1;
                    })());
                }
                {
                    this.Int52 = new $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType().$ctor$2((() =>
                    {
                        //new $.$srij.System.Runtime.InteropServices.JavaScript.JSFunctionBinding.JSBindingType()
                        const $t1 = $.$srij.System.Runtime.InteropServices.JavaScript.JSFunctionBinding.JSBindingType;
                        const $i1 = new $t1();
                        $i1.Type = 8/*MarshalerType.Int52*/;
                        return $i1;
                    })());
                }
                {
                    this.BigInt64 = new $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType().$ctor$2((() =>
                    {
                        //new $.$srij.System.Runtime.InteropServices.JavaScript.JSFunctionBinding.JSBindingType()
                        const $t1 = $.$srij.System.Runtime.InteropServices.JavaScript.JSFunctionBinding.JSBindingType;
                        const $i1 = new $t1();
                        $i1.Type = 9/*MarshalerType.BigInt64*/;
                        return $i1;
                    })());
                }
                {
                    this.Double = new $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType().$ctor$2((() =>
                    {
                        //new $.$srij.System.Runtime.InteropServices.JavaScript.JSFunctionBinding.JSBindingType()
                        const $t1 = $.$srij.System.Runtime.InteropServices.JavaScript.JSFunctionBinding.JSBindingType;
                        const $i1 = new $t1();
                        $i1.Type = 10/*MarshalerType.Double*/;
                        return $i1;
                    })());
                }
                {
                    this.Single = new $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType().$ctor$2((() =>
                    {
                        //new $.$srij.System.Runtime.InteropServices.JavaScript.JSFunctionBinding.JSBindingType()
                        const $t1 = $.$srij.System.Runtime.InteropServices.JavaScript.JSFunctionBinding.JSBindingType;
                        const $i1 = new $t1();
                        $i1.Type = 11/*MarshalerType.Single*/;
                        return $i1;
                    })());
                }
                {
                    this.IntPtr = new $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType().$ctor$2((() =>
                    {
                        //new $.$srij.System.Runtime.InteropServices.JavaScript.JSFunctionBinding.JSBindingType()
                        const $t1 = $.$srij.System.Runtime.InteropServices.JavaScript.JSFunctionBinding.JSBindingType;
                        const $i1 = new $t1();
                        $i1.Type = 12/*MarshalerType.IntPtr*/;
                        return $i1;
                    })());
                }
                {
                    this.JSObject = new $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType().$ctor$2((() =>
                    {
                        //new $.$srij.System.Runtime.InteropServices.JavaScript.JSFunctionBinding.JSBindingType()
                        const $t1 = $.$srij.System.Runtime.InteropServices.JavaScript.JSFunctionBinding.JSBindingType;
                        const $i1 = new $t1();
                        $i1.Type = 13/*MarshalerType.JSObject*/;
                        return $i1;
                    })());
                }
                {
                    this.Object = new $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType().$ctor$2((() =>
                    {
                        //new $.$srij.System.Runtime.InteropServices.JavaScript.JSFunctionBinding.JSBindingType()
                        const $t1 = $.$srij.System.Runtime.InteropServices.JavaScript.JSFunctionBinding.JSBindingType;
                        const $i1 = new $t1();
                        $i1.Type = 14/*MarshalerType.Object*/;
                        return $i1;
                    })());
                }
                {
                    this.String = new $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType().$ctor$2((() =>
                    {
                        //new $.$srij.System.Runtime.InteropServices.JavaScript.JSFunctionBinding.JSBindingType()
                        const $t1 = $.$srij.System.Runtime.InteropServices.JavaScript.JSFunctionBinding.JSBindingType;
                        const $i1 = new $t1();
                        $i1.Type = 15/*MarshalerType.String*/;
                        return $i1;
                    })());
                }
                {
                    this.Exception = new $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType().$ctor$2((() =>
                    {
                        //new $.$srij.System.Runtime.InteropServices.JavaScript.JSFunctionBinding.JSBindingType()
                        const $t1 = $.$srij.System.Runtime.InteropServices.JavaScript.JSFunctionBinding.JSBindingType;
                        const $i1 = new $t1();
                        $i1.Type = 16/*MarshalerType.Exception*/;
                        return $i1;
                    })());
                }
                {
                    this.DateTime = new $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType().$ctor$2((() =>
                    {
                        //new $.$srij.System.Runtime.InteropServices.JavaScript.JSFunctionBinding.JSBindingType()
                        const $t1 = $.$srij.System.Runtime.InteropServices.JavaScript.JSFunctionBinding.JSBindingType;
                        const $i1 = new $t1();
                        $i1.Type = 17/*MarshalerType.DateTime*/;
                        return $i1;
                    })());
                }
                {
                    this.DateTimeOffset = new $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType().$ctor$2((() =>
                    {
                        //new $.$srij.System.Runtime.InteropServices.JavaScript.JSFunctionBinding.JSBindingType()
                        const $t1 = $.$srij.System.Runtime.InteropServices.JavaScript.JSFunctionBinding.JSBindingType;
                        const $i1 = new $t1();
                        $i1.Type = 18/*MarshalerType.DateTimeOffset*/;
                        return $i1;
                    })());
                }
                {
                    this._task = new $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType().$ctor$2((() =>
                    {
                        //new $.$srij.System.Runtime.InteropServices.JavaScript.JSFunctionBinding.JSBindingType()
                        const $t1 = $.$srij.System.Runtime.InteropServices.JavaScript.JSFunctionBinding.JSBindingType;
                        const $i1 = new $t1();
                        $i1.Type = 20/*MarshalerType.Task*/;
                        return $i1;
                    })());
                }
                {
                    this._action = new $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType().$ctor$2((() =>
                    {
                        //new $.$srij.System.Runtime.InteropServices.JavaScript.JSFunctionBinding.JSBindingType()
                        const $t1 = $.$srij.System.Runtime.InteropServices.JavaScript.JSFunctionBinding.JSBindingType;
                        const $i1 = new $t1();
                        $i1.Type = 24/*MarshalerType.Action*/;
                        return $i1;
                    })());
                }
            }
            //--TRIMMABLE-BOUNDARY-END(107376345099)
            
            static $h = 2162699;
            static $f = 0b10010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 131073,
  "p": [
//--TRIMMABLE-BOUNDARY-START(455268696075),
    {
      "p": 2162699,
      "g": {
        "r": 0,
        "d": 0,
        "h": 399434121227,
        "f": 50331681
      },
      "n": "Void",
      "d": 2162699,
      "h": 455268696075,
      "f": 2097185
    },
//--TRIMMABLE-BOUNDARY-END(455268696075),
//--TRIMMABLE-BOUNDARY-START(188980723723),
    {
      "p": 2162699,
      "g": {
        "r": 0,
        "d": 0,
        "h": 296354906123,
        "f": 50331681
      },
      "n": "Discard",
      "d": 2162699,
      "h": 188980723723,
      "f": 2097185
    },
//--TRIMMABLE-BOUNDARY-END(188980723723),
//--TRIMMABLE-BOUNDARY-START(193275691019),
    {
      "p": 2162699,
      "g": {
        "r": 0,
        "d": 0,
        "h": 304944840715,
        "f": 50331681
      },
      "n": "DiscardNoWait",
      "d": 2162699,
      "h": 193275691019,
      "f": 2097185
    },
//--TRIMMABLE-BOUNDARY-END(193275691019),
//--TRIMMABLE-BOUNDARY-START(150326018059),
    {
      "p": 2162699,
      "g": {
        "r": 0,
        "d": 0,
        "h": 253405233163,
        "f": 50331681
      },
      "n": "Boolean",
      "d": 2162699,
      "h": 150326018059,
      "f": 2097185
    },
//--TRIMMABLE-BOUNDARY-END(150326018059),
//--TRIMMABLE-BOUNDARY-START(154620985355),
    {
      "p": 2162699,
      "g": {
        "r": 0,
        "d": 0,
        "h": 261995167755,
        "f": 50331681
      },
      "n": "Byte",
      "d": 2162699,
      "h": 154620985355,
      "f": 2097185
    },
//--TRIMMABLE-BOUNDARY-END(154620985355),
//--TRIMMABLE-BOUNDARY-START(158915952651),
    {
      "p": 2162699,
      "g": {
        "r": 0,
        "d": 0,
        "h": 270585102347,
        "f": 50331681
      },
      "n": "Char",
      "d": 2162699,
      "h": 158915952651,
      "f": 2097185
    },
//--TRIMMABLE-BOUNDARY-END(158915952651),
//--TRIMMABLE-BOUNDARY-START(403729088523),
    {
      "p": 2162699,
      "g": {
        "r": 0,
        "d": 0,
        "h": 330714644491,
        "f": 50331681
      },
      "n": "Int16",
      "d": 2162699,
      "h": 403729088523,
      "f": 2097185
    },
//--TRIMMABLE-BOUNDARY-END(403729088523),
//--TRIMMABLE-BOUNDARY-START(408024055819),
    {
      "p": 2162699,
      "g": {
        "r": 0,
        "d": 0,
        "h": 339304579083,
        "f": 50331681
      },
      "n": "Int32",
      "d": 2162699,
      "h": 408024055819,
      "f": 2097185
    },
//--TRIMMABLE-BOUNDARY-END(408024055819),
//--TRIMMABLE-BOUNDARY-START(412319023115),
    {
      "p": 2162699,
      "g": {
        "r": 0,
        "d": 0,
        "h": 347894513675,
        "f": 50331681
      },
      "n": "Int52",
      "d": 2162699,
      "h": 412319023115,
      "f": 2097185
    },
//--TRIMMABLE-BOUNDARY-END(412319023115),
//--TRIMMABLE-BOUNDARY-START(146031050763),
    {
      "p": 2162699,
      "g": {
        "r": 0,
        "d": 0,
        "h": 244815298571,
        "f": 50331681
      },
      "n": "BigInt64",
      "d": 2162699,
      "h": 146031050763,
      "f": 2097185
    },
//--TRIMMABLE-BOUNDARY-END(146031050763),
//--TRIMMABLE-BOUNDARY-START(197570658315),
    {
      "p": 2162699,
      "g": {
        "r": 0,
        "d": 0,
        "h": 313534775307,
        "f": 50331681
      },
      "n": "Double",
      "d": 2162699,
      "h": 197570658315,
      "f": 2097185
    },
//--TRIMMABLE-BOUNDARY-END(197570658315),
//--TRIMMABLE-BOUNDARY-START(433793859595),
    {
      "p": 2162699,
      "g": {
        "r": 0,
        "d": 0,
        "h": 382254252043,
        "f": 50331681
      },
      "n": "Single",
      "d": 2162699,
      "h": 433793859595,
      "f": 2097185
    },
//--TRIMMABLE-BOUNDARY-END(433793859595),
//--TRIMMABLE-BOUNDARY-START(416613990411),
    {
      "p": 2162699,
      "g": {
        "r": 0,
        "d": 0,
        "h": 356484448267,
        "f": 50331681
      },
      "n": "IntPtr",
      "d": 2162699,
      "h": 416613990411,
      "f": 2097185
    },
//--TRIMMABLE-BOUNDARY-END(416613990411),
//--TRIMMABLE-BOUNDARY-START(420908957707),
    {
      "p": 2162699,
      "g": {
        "r": 0,
        "d": 0,
        "h": 365074382859,
        "f": 50331681
      },
      "n": "JSObject",
      "d": 2162699,
      "h": 420908957707,
      "f": 2097185
    },
//--TRIMMABLE-BOUNDARY-END(420908957707),
//--TRIMMABLE-BOUNDARY-START(429498892299),
    {
      "p": 2162699,
      "g": {
        "r": 0,
        "d": 0,
        "h": 373664317451,
        "f": 50331681
      },
      "n": "Object",
      "d": 2162699,
      "h": 429498892299,
      "f": 2097185
    },
//--TRIMMABLE-BOUNDARY-END(429498892299),
//--TRIMMABLE-BOUNDARY-START(442383794187),
    {
      "p": 2162699,
      "g": {
        "r": 0,
        "d": 0,
        "h": 390844186635,
        "f": 50331681
      },
      "n": "String",
      "d": 2162699,
      "h": 442383794187,
      "f": 2097185
    },
//--TRIMMABLE-BOUNDARY-END(442383794187),
//--TRIMMABLE-BOUNDARY-START(180390789131),
    {
      "p": 2162699,
      "g": {
        "r": 0,
        "d": 0,
        "h": 279175036939,
        "f": 50331681
      },
      "n": "DateTime",
      "d": 2162699,
      "h": 180390789131,
      "f": 2097185
    },
//--TRIMMABLE-BOUNDARY-END(180390789131),
//--TRIMMABLE-BOUNDARY-START(184685756427),
    {
      "p": 2162699,
      "g": {
        "r": 0,
        "d": 0,
        "h": 287764971531,
        "f": 50331681
      },
      "n": "DateTimeOffset",
      "d": 2162699,
      "h": 184685756427,
      "f": 2097185
    },
//--TRIMMABLE-BOUNDARY-END(184685756427),
//--TRIMMABLE-BOUNDARY-START(12887064587),
    {
      "p": 2162699,
      "g": {
        "r": 0,
        "d": 0,
        "h": 236225363979,
        "f": 50331682
      },
      "n": "_task",
      "d": 2162699,
      "h": 12887064587,
      "f": 2097186
    },
//--TRIMMABLE-BOUNDARY-END(12887064587),
//--TRIMMABLE-BOUNDARY-START(4297129995),
    {
      "p": 2162699,
      "g": {
        "r": 0,
        "d": 0,
        "h": 227635429387,
        "f": 50331682
      },
      "n": "_action",
      "d": 2162699,
      "h": 4297129995,
      "f": 2097186
    },
//--TRIMMABLE-BOUNDARY-END(4297129995)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(425203925003),
    {
      "r": 2162699,
      "p": [
        {
          "n": "primitive",
          "p": 2162699
        }
      ],
      "n": "Nullable",
      "d": 2162699,
      "h": 425203925003,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(425203925003),
//--TRIMMABLE-BOUNDARY-START(446678761483),
    {
      "r": 2162699,
      "n": "Task",
      "d": 2162699,
      "h": 446678761483,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(446678761483),
//--TRIMMABLE-BOUNDARY-START(450973728779),
    {
      "r": 2162699,
      "p": [
        {
          "n": "result",
          "p": 2162699
        }
      ],
      "n": "Task",
      "o": "@$1",
      "d": 2162699,
      "h": 450973728779,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(450973728779),
//--TRIMMABLE-BOUNDARY-START(137441116171),
    {
      "r": 2162699,
      "p": [
        {
          "n": "element",
          "p": 2162699
        }
      ],
      "n": "Array",
      "d": 2162699,
      "h": 137441116171,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(137441116171),
//--TRIMMABLE-BOUNDARY-START(141736083467),
    {
      "r": 2162699,
      "p": [
        {
          "n": "element",
          "p": 2162699
        }
      ],
      "n": "ArraySegment",
      "d": 2162699,
      "h": 141736083467,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(141736083467),
//--TRIMMABLE-BOUNDARY-START(438088826891),
    {
      "r": 2162699,
      "p": [
        {
          "n": "element",
          "p": 2162699
        }
      ],
      "n": "Span",
      "d": 2162699,
      "h": 438088826891,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(438088826891),
//--TRIMMABLE-BOUNDARY-START(120261246987),
    {
      "r": 2162699,
      "n": "Action",
      "d": 2162699,
      "h": 120261246987,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(120261246987),
//--TRIMMABLE-BOUNDARY-START(133146148875),
    {
      "r": 2162699,
      "p": [
        {
          "n": "arg1",
          "p": 2162699
        }
      ],
      "n": "Action",
      "o": "@$3",
      "d": 2162699,
      "h": 133146148875,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(133146148875),
//--TRIMMABLE-BOUNDARY-START(128851181579),
    {
      "r": 2162699,
      "p": [
        {
          "n": "arg1",
          "p": 2162699
        },
        {
          "n": "arg2",
          "p": 2162699
        }
      ],
      "n": "Action",
      "o": "@$2",
      "d": 2162699,
      "h": 128851181579,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(128851181579),
//--TRIMMABLE-BOUNDARY-START(124556214283),
    {
      "r": 2162699,
      "p": [
        {
          "n": "arg1",
          "p": 2162699
        },
        {
          "n": "arg2",
          "p": 2162699
        },
        {
          "n": "arg3",
          "p": 2162699
        }
      ],
      "n": "Action",
      "o": "@$1",
      "d": 2162699,
      "h": 124556214283,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(124556214283),
//--TRIMMABLE-BOUNDARY-START(219045494795),
    {
      "r": 2162699,
      "p": [
        {
          "n": "result",
          "p": 2162699
        }
      ],
      "n": "Function",
      "o": "@$3",
      "d": 2162699,
      "h": 219045494795,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(219045494795),
//--TRIMMABLE-BOUNDARY-START(214750527499),
    {
      "r": 2162699,
      "p": [
        {
          "n": "arg1",
          "p": 2162699
        },
        {
          "n": "result",
          "p": 2162699
        }
      ],
      "n": "Function",
      "o": "@$2",
      "d": 2162699,
      "h": 214750527499,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(214750527499),
//--TRIMMABLE-BOUNDARY-START(210455560203),
    {
      "r": 2162699,
      "p": [
        {
          "n": "arg1",
          "p": 2162699
        },
        {
          "n": "arg2",
          "p": 2162699
        },
        {
          "n": "result",
          "p": 2162699
        }
      ],
      "n": "Function",
      "o": "@$1",
      "d": 2162699,
      "h": 210455560203,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(210455560203),
//--TRIMMABLE-BOUNDARY-START(206160592907),
    {
      "r": 2162699,
      "p": [
        {
          "n": "arg1",
          "p": 2162699
        },
        {
          "n": "arg2",
          "p": 2162699
        },
        {
          "n": "arg3",
          "p": 2162699
        },
        {
          "n": "result",
          "p": 2162699
        }
      ],
      "n": "Function",
      "d": 2162699,
      "h": 206160592907,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(206160592907),
//--TRIMMABLE-BOUNDARY-START(171800854539),
    {
      "r": 65537,
      "p": [
        {
          "n": "underlyingType",
          "p": 2162699
        }
      ],
      "n": "CheckNullable",
      "d": 2162699,
      "h": 171800854539,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(171800854539),
//--TRIMMABLE-BOUNDARY-START(163210919947),
    {
      "r": 65537,
      "p": [
        {
          "n": "underlyingType",
          "p": 2162699
        }
      ],
      "n": "CheckArray",
      "d": 2162699,
      "h": 163210919947,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(163210919947),
//--TRIMMABLE-BOUNDARY-START(167505887243),
    {
      "r": 65537,
      "p": [
        {
          "n": "underlyingType",
          "p": 2162699
        }
      ],
      "n": "CheckArraySegment",
      "d": 2162699,
      "h": 167505887243,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(167505887243),
//--TRIMMABLE-BOUNDARY-START(176095821835),
    {
      "r": 65537,
      "p": [
        {
          "n": "underlyingType",
          "p": 2162699
        }
      ],
      "n": "CheckTask",
      "d": 2162699,
      "h": 176095821835,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(176095821835)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(8592097291),
    {
      "t": 655371,
      "n": "_signatureType",
      "d": 2162699,
      "h": 8592097291,
      "f": 4194312
    },
//--TRIMMABLE-BOUNDARY-END(8592097291)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(111671312395),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 2162699,
      "h": 111671312395,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(111671312395),
//--TRIMMABLE-BOUNDARY-START(115966279691),
    {
      "p": [
        {
          "n": "signatureType",
          "p": 655371
        }
      ],
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 2162699,
      "h": 115966279691,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(115966279691)
  ],
  "h": 2162699,
  "a": [
    {
      "t": 159055873,
      "c": 4454023169,
      "a": [
        {
          "v": "browser",
          "t": 1310721
        }
      ]
    },
    {
      "t": 64290817,
      "c": 12949192705,
      "a": [
        {
          "v": 1,
          "t": 64356353
        }
      ]
    }
  ]
}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `System.Runtime.InteropServices.JavaScript.JSMarshalerType`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2162699)
        
        
        //--TRIMMABLE-BOUNDARY-START(262155)
        $asm.$cls("$srij.System.Runtime.InteropServices.JavaScript.JavaScriptExports", ($self) => class JavaScriptExports
        {
            //--TRIMMABLE-BOUNDARY-START(12885164043)
            static /*void */ CallEntrypoint(/*JSMarshalerArgument**/ arguments_buffer)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12885164043);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*ref JSMarshalerArgument*/ let arg_exc = arguments_buffer.Add(0);
                /*ref JSMarshalerArgument*/ let arg_res = arguments_buffer.Add(1);
                /*ref JSMarshalerArgument*/ let arg_1 = arguments_buffer.Add(2);
                /*ref JSMarshalerArgument*/ let arg_2 = arguments_buffer.Add(3);
                /*ref JSMarshalerArgument*/ let arg_3 = arguments_buffer.Add(4);
                try
                {
                    /*IntPtr*/ let assemblyNamePtr;
                    arg_1.$v.ToManaged$17($.$ref(() => assemblyNamePtr, ($v) => assemblyNamePtr = $v, $.$$.System.IntPtr));
                    /*string?[]?*/ let args;
                    arg_2.$v.ToManaged$36($.$ref(() => args, ($v) => args = $v, $.$typeArray($.$$.System.String)));
                    /*bool*/ let waitForDebugger;
                    arg_3.$v.ToManaged$4($.$ref(() => waitForDebugger, ($v) => waitForDebugger = $v, $.$$.System.Boolean));
                    /*Task<int>?*/ let result = $.$srij.System.Runtime.InteropServices.JavaScript.JSHostImplementation.CallEntrypoint(assemblyNamePtr, args, waitForDebugger);
                    arg_res.$v.ToJS$43($.$$.System.Int32, result, new ($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument.ArgumentToJSCallback$$($.$$.System.Int32))().$ctor(this,  (/*JSMarshalerArgument*/ arg, /*int*/ value) =>
                    {
                        arg.$v.ToJS$14(value);
                    }, {
  "r": 65537,
  "p": [
    {
      "n": "arg",
      "p": 1310731,
      "f": 4
    },
    {
      "n": "value",
      "p": 655361
    }
  ],
  "n": "",
  "d": 262155,
  "h": 0,
  "f": 17825794
}));
                }
                catch(ex)
                {
                    $.$$.System.Environment.FailFast$2(`CallEntrypoint: Unexpected synchronous failure (ManagedThreadId ${$.$$.System.Environment.CurrentManagedThreadId}): ` + $.$$.System.Exception.ToString.call(ex));
                }
            }
            //--TRIMMABLE-BOUNDARY-END(12885164043)
            
            //--TRIMMABLE-BOUNDARY-START(30065033227)
            static /*void */ LoadLazyAssembly(/*JSMarshalerArgument**/ arguments_buffer)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(30065033227);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*ref JSMarshalerArgument*/ let arg_exc = arguments_buffer.Add(0);
                /*ref JSMarshalerArgument*/ let arg_1 = arguments_buffer.Add(2);
                /*ref JSMarshalerArgument*/ let arg_2 = arguments_buffer.Add(3);
                try
                {
                    /*byte[]?*/ let dllBytes;
                    arg_1.$v.ToManaged$6($.$ref(() => dllBytes, ($v) => dllBytes = $v, $.$typeArray($.$$.System.Byte)));
                    /*byte[]?*/ let pdbBytes;
                    arg_2.$v.ToManaged$6($.$ref(() => pdbBytes, ($v) => pdbBytes = $v, $.$typeArray($.$$.System.Byte)));
                    if (dllBytes !== null)
                    {
                        $.$srij.System.Runtime.InteropServices.JavaScript.JSHostImplementation.LoadLazyAssembly(dllBytes, pdbBytes);
                    }
                }
                catch(ex)
                {
                    arg_exc.$v.ToJS$12(ex);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(30065033227)
            
            //--TRIMMABLE-BOUNDARY-START(34360000523)
            static /*void */ LoadSatelliteAssembly(/*JSMarshalerArgument**/ arguments_buffer)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(34360000523);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*ref JSMarshalerArgument*/ let arg_exc = arguments_buffer.Add(0);
                /*ref JSMarshalerArgument*/ let arg_1 = arguments_buffer.Add(2);
                try
                {
                    /*byte[]?*/ let dllBytes;
                    arg_1.$v.ToManaged$6($.$ref(() => dllBytes, ($v) => dllBytes = $v, $.$typeArray($.$$.System.Byte)));
                    if (dllBytes !== null)
                    {
                        $.$srij.System.Runtime.InteropServices.JavaScript.JSHostImplementation.LoadSatelliteAssembly(dllBytes);
                    }
                }
                catch(ex)
                {
                    arg_exc.$v.ToJS$12(ex);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(34360000523)
            
            //--TRIMMABLE-BOUNDARY-START(38654967819)
            static /*void */ ReleaseJSOwnedObjectByGCHandle(/*JSMarshalerArgument**/ arguments_buffer)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(38654967819);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*ref JSMarshalerArgument*/ let arg_exc = arguments_buffer.Add(0);
                /*ref JSMarshalerArgument*/ let arg_1 = arguments_buffer.Add(2);
                try
                {
                    /*var*/ let ctx = arg_exc.$v.ToManagedContext;
                    ctx.ReleaseJSOwnedObjectByGCHandle(arg_1.$v.slot.GCHandle);
                }
                catch(ex)
                {
                    $.$$.System.Environment.FailFast$2(`ReleaseJSOwnedObjectByGCHandle: Unexpected synchronous failure (ManagedThreadId ${$.$$.System.Environment.CurrentManagedThreadId}): ` + $.$$.System.Exception.ToString.call(ex));
                }
            }
            //--TRIMMABLE-BOUNDARY-END(38654967819)
            
            //--TRIMMABLE-BOUNDARY-START(8590196747)
            static /*void */ CallDelegate(/*JSMarshalerArgument**/ arguments_buffer)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590196747);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*ref JSMarshalerArgument*/ let arg_exc = arguments_buffer.Add(0);
                /*ref JSMarshalerArgument*/ let arg_1 = arguments_buffer.Add(2);
                try
                {
                    /*GCHandle*/ let callback_gc_handle = $.$$.System.Runtime.InteropServices.GCHandle.op_Explicit$1(arg_1.$v.slot.GCHandle);
                    let callback;
                    if ($.$is(callback_gc_handle.Target, $.$srij.System.Runtime.InteropServices.JavaScript.JSHostImplementation.ToManagedCallback, { set $v(v){ callback = v; } }))
                    {
                        callback.Invoke(arguments_buffer);
                    }
                    else 
                    {
                        throw new $.$$.System.InvalidOperationException().$ctor$12($.$srij.System.SR.NullToManagedCallback);
                    }
                }
                catch(ex)
                {
                    arg_exc.$v.ToJS$12(ex);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(8590196747)
            
            //--TRIMMABLE-BOUNDARY-START(17180131339)
            static /*void */ CompleteTask(/*JSMarshalerArgument**/ arguments_buffer)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17180131339);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*ref JSMarshalerArgument*/ let arg_exc = arguments_buffer.Add(0);
                /*ref JSMarshalerArgument*/ let arg_res = arguments_buffer.Add(1);
                /*ref JSMarshalerArgument*/ let arg_1 = arguments_buffer.Add(2);
                try
                {
                    /*var*/ let ctx = arg_exc.$v.ToManagedContext;
                    /*var*/ let holder = ctx.GetPromiseHolder(arg_1.$v.slot.GCHandle);
                    /*JSHostImplementation.ToManagedCallback*/ let callback;
                    callback = holder.Callback;
                    ctx.ReleasePromiseHolder(arg_1.$v.slot.GCHandle);
                    callback.Invoke(arguments_buffer);
                }
                catch(ex)
                {
                    $.$$.System.Environment.FailFast$2(`CompleteTask: Unexpected synchronous failure (ManagedThreadId ${$.$$.System.Environment.CurrentManagedThreadId}): ` + $.$$.System.Exception.ToString.call(ex));
                }
            }
            //--TRIMMABLE-BOUNDARY-END(17180131339)
            
            //--TRIMMABLE-BOUNDARY-START(25770065931)
            static /*void */ GetManagedStackTrace(/*JSMarshalerArgument**/ arguments_buffer)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25770065931);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*ref JSMarshalerArgument*/ let arg_exc = arguments_buffer.Add(0);
                /*ref JSMarshalerArgument*/ let arg_res = arguments_buffer.Add(1);
                /*ref JSMarshalerArgument*/ let arg_1 = arguments_buffer.Add(2);
                try
                {
                    arg_exc.$v.AssertCurrentThreadContext();
                    /*GCHandle*/ let exception_gc_handle = $.$$.System.Runtime.InteropServices.GCHandle.op_Explicit$1(arg_1.$v.slot.GCHandle);
                    let exception;
                    if ($.$is(exception_gc_handle.Target, $.$$.System.Exception, { set $v(v){ exception = v; } }))
                    {
                        arg_res.$v.ToJS$35(exception.StackTrace);
                    }
                    else 
                    {
                        throw new $.$$.System.InvalidOperationException().$ctor$12($.$srij.System.SR.UnableToResolveHandleAsException);
                    }
                }
                catch(ex)
                {
                    arg_exc.$v.ToJS$12(ex);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(25770065931)
            
            //--TRIMMABLE-BOUNDARY-START(4295229451)
            static /*void */ BindAssemblyExports(/*JSMarshalerArgument**/ arguments_buffer)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295229451);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*ref JSMarshalerArgument*/ let arg_exc = arguments_buffer.Add(0);
                /*ref JSMarshalerArgument*/ let arg_res = arguments_buffer.Add(1);
                /*ref JSMarshalerArgument*/ let arg_1 = arguments_buffer.Add(2);
                try
                {
                    /*string?*/ let assemblyName;
                    arg_exc.$v.AssertCurrentThreadContext();
                    arg_1.$v.ToManaged$35($.$ref(() => assemblyName, ($v) => assemblyName = $v, $.$$.System.String));
                    /*var*/ let result = $.$srij.System.Runtime.InteropServices.JavaScript.JSHostImplementation.BindAssemblyExports(assemblyName);
                    arg_res.$v.ToJS$37(result);
                }
                catch(ex)
                {
                    $.$$.System.Environment.FailFast$2(`BindAssemblyExports: Unexpected synchronous failure (ManagedThreadId ${$.$$.System.Environment.CurrentManagedThreadId}): ` + $.$$.System.Exception.ToString.call(ex));
                }
            }
            //--TRIMMABLE-BOUNDARY-END(4295229451)
            
            //--TRIMMABLE-BOUNDARY-START(42949935115)
            static /*void */ StopProfile()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(42949935115);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
            }
            //--TRIMMABLE-BOUNDARY-END(42949935115)
            
            //--TRIMMABLE-BOUNDARY-START(21475098635)
            static /*void */ DumpAotProfileData(/*ref byte*/ buf, /*int*/ len, /*string*/ extraArg)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21475098635);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (len === 0)
                {
                    throw new $.$$.System.InvalidOperationException().$ctor$12($.$srij.System.SR.EmptyProfileData);
                }
                /*fixed*/ 
                {
                    /*void**/ let p = buf;
                    /*var*/ let span = new ($.$$.System.ReadOnlySpan$$($.$$.System.Byte))().$ctor$5(p, len);
                    /*var*/ let module = $.$srij.System.Runtime.InteropServices.JavaScript.JSHost.DotnetInstance.GetPropertyAsJSObject("INTERNAL");
                    if (module === null)
                    {
                        throw new $.$$.System.InvalidOperationException().$ctor$9();
                    }
                    module.SetProperty$1("aotProfileData", span.ToArray());
                }
            }
            //--TRIMMABLE-BOUNDARY-END(21475098635)
            
            static $h = 262155;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 131073,
  "m": [
//--TRIMMABLE-BOUNDARY-START(12885164043),
    {
      "r": 65537,
      "p": [
        {
          "n": "arguments_buffer",
          "p": $.$typePointer($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument).$h
        }
      ],
      "n": "CallEntrypoint",
      "d": 262155,
      "h": 12885164043,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(12885164043),
//--TRIMMABLE-BOUNDARY-START(30065033227),
    {
      "r": 65537,
      "p": [
        {
          "n": "arguments_buffer",
          "p": $.$typePointer($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument).$h
        }
      ],
      "n": "LoadLazyAssembly",
      "d": 262155,
      "h": 30065033227,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(30065033227),
//--TRIMMABLE-BOUNDARY-START(34360000523),
    {
      "r": 65537,
      "p": [
        {
          "n": "arguments_buffer",
          "p": $.$typePointer($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument).$h
        }
      ],
      "n": "LoadSatelliteAssembly",
      "d": 262155,
      "h": 34360000523,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(34360000523),
//--TRIMMABLE-BOUNDARY-START(38654967819),
    {
      "r": 65537,
      "p": [
        {
          "n": "arguments_buffer",
          "p": $.$typePointer($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument).$h
        }
      ],
      "n": "ReleaseJSOwnedObjectByGCHandle",
      "d": 262155,
      "h": 38654967819,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(38654967819),
//--TRIMMABLE-BOUNDARY-START(8590196747),
    {
      "r": 65537,
      "p": [
        {
          "n": "arguments_buffer",
          "p": $.$typePointer($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument).$h
        }
      ],
      "n": "CallDelegate",
      "d": 262155,
      "h": 8590196747,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8590196747),
//--TRIMMABLE-BOUNDARY-START(17180131339),
    {
      "r": 65537,
      "p": [
        {
          "n": "arguments_buffer",
          "p": $.$typePointer($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument).$h
        }
      ],
      "n": "CompleteTask",
      "d": 262155,
      "h": 17180131339,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(17180131339),
//--TRIMMABLE-BOUNDARY-START(25770065931),
    {
      "r": 65537,
      "p": [
        {
          "n": "arguments_buffer",
          "p": $.$typePointer($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument).$h
        }
      ],
      "n": "GetManagedStackTrace",
      "d": 262155,
      "h": 25770065931,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(25770065931),
//--TRIMMABLE-BOUNDARY-START(4295229451),
    {
      "r": 65537,
      "p": [
        {
          "n": "arguments_buffer",
          "p": $.$typePointer($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument).$h
        }
      ],
      "n": "BindAssemblyExports",
      "d": 262155,
      "h": 4295229451,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(4295229451),
//--TRIMMABLE-BOUNDARY-START(42949935115),
    {
      "r": 65537,
      "n": "StopProfile",
      "d": 262155,
      "h": 42949935115,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(42949935115),
//--TRIMMABLE-BOUNDARY-START(21475098635),
    {
      "r": 65537,
      "p": [
        {
          "n": "buf",
          "p": 393217,
          "f": 4
        },
        {
          "n": "len",
          "p": 655361
        },
        {
          "n": "extraArg",
          "p": 1310721
        }
      ],
      "n": "DumpAotProfileData",
      "d": 262155,
      "h": 21475098635,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(21475098635)
  ],
  "h": 262155
}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `System.Runtime.InteropServices.JavaScript.JavaScriptExports`; }
        });
        //--TRIMMABLE-BOUNDARY-END(262155)
        
        
        //--TRIMMABLE-BOUNDARY-START(2228235)
        $asm.$cls("$srij.System.Runtime.InteropServices.JavaScript.JSObject", ($self) => class JSObject extends $.$$.System.Object
        {
            //--TRIMMABLE-BOUNDARY-START(94491508747)
            /*nint*/ JSHandle = 0;
            //--TRIMMABLE-BOUNDARY-END(94491508747)
            
            //--TRIMMABLE-BOUNDARY-START(98786476043)
            /*JSProxyContext*/ ProxyContext = null;
            //--TRIMMABLE-BOUNDARY-END(98786476043)
            
            //--TRIMMABLE-BOUNDARY-START(128851247115)
            /*SynchronizationContext */ get SynchronizationContext()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(47246868491);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(128851247115)
            
            //--TRIMMABLE-BOUNDARY-START(4297195531)
            /*bool*/ _isDisposed = false;
            //--TRIMMABLE-BOUNDARY-END(4297195531)
            
            //--TRIMMABLE-BOUNDARY-START(8592162827)
            $ctor$1(/*IntPtr*/ jsHandle, /*JSProxyContext*/ ctx)
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(8592162827);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this.ProxyContext = ctx;
                    this.JSHandle = jsHandle;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(8592162827)
            
            //--TRIMMABLE-BOUNDARY-START(25772032011)
            static/*conventional*/ /*bool */ Equals$1(/*object?*/ obj)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(25772032011);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    let other;
                    return $.$is(obj, $.$srij.System.Runtime.InteropServices.JavaScript.JSObject, { set $v(v){ other = v; } }) && this.JSHandle === other.JSHandle;
                }
            }
            //Static convention instance redirect
            /*bool */ Equals$1() { return $.$srij.System.Runtime.InteropServices.JavaScript.JSObject.Equals$1.apply(this, arguments); }
            //--TRIMMABLE-BOUNDARY-END(25772032011)
            
            //--TRIMMABLE-BOUNDARY-START(51541835787)
            static/*conventional*/ /*int */ GetHashCode()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(51541835787);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return this.JSHandle;
                }
            }
            //Static convention instance redirect
            /*int */ GetHashCode() { return $.$srij.System.Runtime.InteropServices.JavaScript.JSObject.GetHashCode.apply(this, arguments); }
            //--TRIMMABLE-BOUNDARY-END(51541835787)
            
            //--TRIMMABLE-BOUNDARY-START(133146214411)
            static/*conventional*/ /*string */ ToString()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(133146214411);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return `(js-obj js '${this.JSHandle}')`;
                }
            }
            //Static convention instance redirect
            /*string */ ToString() { return $.$srij.System.Runtime.InteropServices.JavaScript.JSObject.ToString.apply(this, arguments); }
            //--TRIMMABLE-BOUNDARY-END(133146214411)
            
            //--TRIMMABLE-BOUNDARY-START(12887130123)
            /*void */ AssertNotDisposed()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12887130123);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                {
                    $.$$.System.ObjectDisposedException.ThrowIf(this.IsDisposed, this);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(12887130123)
            
            //--TRIMMABLE-BOUNDARY-START(21477064715)
            /*void */ DisposeImpl(/*bool*/ skipJsCleanup)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21477064715);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (!this._isDisposed)
                {
                    $.$srij.System.Runtime.InteropServices.JavaScript.JSProxyContext.ReleaseCSOwnedObject(this, skipJsCleanup);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(21477064715)
            
            $dtor()
            {
                this.DisposeImpl(false);
            }
            //--TRIMMABLE-BOUNDARY-START(17182097419)
            /*void */ Dispose()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17182097419);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.DisposeImpl(false);
            }
            //--TRIMMABLE-BOUNDARY-END(17182097419)
            
            //--TRIMMABLE-BOUNDARY-START(90196541451)
            /*bool */ get IsDisposed()
            {
                return this._isDisposed;
            }
            //--TRIMMABLE-BOUNDARY-END(90196541451)
            
            //--TRIMMABLE-BOUNDARY-START(85901574155)
            /*bool */ HasProperty(/*string*/ propertyName)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(85901574155);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.AssertNotDisposed();
                return INTERNAL.has_property(this, propertyName);
            }
            //--TRIMMABLE-BOUNDARY-END(85901574155)
            
            //--TRIMMABLE-BOUNDARY-START(81606606859)
            /*string */ GetTypeOfProperty(/*string*/ propertyName)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(81606606859);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.AssertNotDisposed();
                return INTERNAL.get_typeof_property(this, propertyName);
            }
            //--TRIMMABLE-BOUNDARY-END(81606606859)
            
            //--TRIMMABLE-BOUNDARY-START(55836803083)
            /*bool */ GetPropertyAsBoolean(/*string*/ propertyName)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(55836803083);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.AssertNotDisposed();
                return INTERNAL.get_property(this, propertyName);
            }
            //--TRIMMABLE-BOUNDARY-END(55836803083)
            
            //--TRIMMABLE-BOUNDARY-START(68721704971)
            /*int */ GetPropertyAsInt32(/*string*/ propertyName)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(68721704971);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.AssertNotDisposed();
                return INTERNAL.get_property(this, propertyName);
            }
            //--TRIMMABLE-BOUNDARY-END(68721704971)
            
            //--TRIMMABLE-BOUNDARY-START(64426737675)
            /*double */ GetPropertyAsDouble(/*string*/ propertyName)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(64426737675);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.AssertNotDisposed();
                return INTERNAL.get_property(this, propertyName);
            }
            //--TRIMMABLE-BOUNDARY-END(64426737675)
            
            //--TRIMMABLE-BOUNDARY-START(77311639563)
            /*string? */ GetPropertyAsString(/*string*/ propertyName)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(77311639563);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.AssertNotDisposed();
                return INTERNAL.get_property(this, propertyName);
            }
            //--TRIMMABLE-BOUNDARY-END(77311639563)
            
            //--TRIMMABLE-BOUNDARY-START(73016672267)
            /*JSObject? */ GetPropertyAsJSObject(/*string*/ propertyName)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(73016672267);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.AssertNotDisposed();
                return INTERNAL.get_property(this, propertyName);
            }
            //--TRIMMABLE-BOUNDARY-END(73016672267)
            
            //--TRIMMABLE-BOUNDARY-START(60131770379)
            /*byte[]? */ GetPropertyAsByteArray(/*string*/ propertyName)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(60131770379);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.AssertNotDisposed();
                return INTERNAL.get_property(this, propertyName);
            }
            //--TRIMMABLE-BOUNDARY-END(60131770379)
            
            //--TRIMMABLE-BOUNDARY-START(103081443339)
            /*void */ SetProperty(/*string*/ propertyName, /*bool*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(103081443339);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.AssertNotDisposed();
                INTERNAL.set_property(this, propertyName, value);
            }
            //--TRIMMABLE-BOUNDARY-END(103081443339)
            
            //--TRIMMABLE-BOUNDARY-START(115966345227)
            /*void */ SetProperty$3(/*string*/ propertyName, /*int*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(115966345227);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.AssertNotDisposed();
                INTERNAL.set_property(this, propertyName, value);
            }
            //--TRIMMABLE-BOUNDARY-END(115966345227)
            
            //--TRIMMABLE-BOUNDARY-START(111671377931)
            /*void */ SetProperty$2(/*string*/ propertyName, /*double*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(111671377931);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.AssertNotDisposed();
                INTERNAL.set_property(this, propertyName, value);
            }
            //--TRIMMABLE-BOUNDARY-END(111671377931)
            
            //--TRIMMABLE-BOUNDARY-START(120261312523)
            /*void */ SetProperty$4(/*string*/ propertyName, /*string?*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(120261312523);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.AssertNotDisposed();
                INTERNAL.set_property(this, propertyName, value);
            }
            //--TRIMMABLE-BOUNDARY-END(120261312523)
            
            //--TRIMMABLE-BOUNDARY-START(124556279819)
            /*void */ SetProperty$5(/*string*/ propertyName, /*JSObject?*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(124556279819);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.AssertNotDisposed();
                INTERNAL.set_property(this, propertyName, value);
            }
            //--TRIMMABLE-BOUNDARY-END(124556279819)
            
            //--TRIMMABLE-BOUNDARY-START(107376410635)
            /*void */ SetProperty$1(/*string*/ propertyName, /*byte[]?*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(107376410635);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.AssertNotDisposed();
                INTERNAL.set_property(this, propertyName, value);
            }
            //--TRIMMABLE-BOUNDARY-END(107376410635)
            
            //--TRIMMABLE-BOUNDARY-START(4385275905)
            //Generated interface implemetation for System.IDisposable.Dispose()
            System$IDisposable$Dispose()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4385275905);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Dispose(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4385275905)
            
            //default member initializer
            constructor()
            {
                super();
                $.$finalizer(this);
            }
            static $h = 2228235;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 131073,
  "p": [
//--TRIMMABLE-BOUNDARY-START(128851247115),
    {
      "p": 175308801,
      "g": {
        "r": 0,
        "d": 0,
        "h": 47246868491,
        "f": 50331649
      },
      "n": "SynchronizationContext",
      "d": 2228235,
      "h": 128851247115,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(128851247115),
//--TRIMMABLE-BOUNDARY-START(90196541451),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 38656933899,
        "f": 50331649
      },
      "n": "IsDisposed",
      "d": 2228235,
      "h": 90196541451,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(90196541451)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(25772032011),
    {
      "r": 262145,
      "p": [
        {
          "n": "obj",
          "p": 131073
        }
      ],
      "n": "Equals",
      "o": "@$1",
      "d": 2228235,
      "h": 25772032011,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(25772032011),
//--TRIMMABLE-BOUNDARY-START(51541835787),
    {
      "r": 655361,
      "n": "GetHashCode",
      "d": 2228235,
      "h": 51541835787,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(51541835787),
//--TRIMMABLE-BOUNDARY-START(133146214411),
    {
      "r": 1310721,
      "n": "ToString",
      "d": 2228235,
      "h": 133146214411,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(133146214411),
//--TRIMMABLE-BOUNDARY-START(12887130123),
    {
      "r": 65537,
      "n": "AssertNotDisposed",
      "d": 2228235,
      "h": 12887130123,
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(12887130123),
//--TRIMMABLE-BOUNDARY-START(21477064715),
    {
      "r": 65537,
      "p": [
        {
          "n": "skipJsCleanup",
          "p": 262145,
          "f": 65,
          "v": false
        }
      ],
      "n": "DisposeImpl",
      "d": 2228235,
      "h": 21477064715,
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(21477064715),
//--TRIMMABLE-BOUNDARY-START(17182097419),
    {
      "r": 65537,
      "n": "Dispose",
      "d": 2228235,
      "h": 17182097419,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(17182097419),
//--TRIMMABLE-BOUNDARY-START(85901574155),
    {
      "r": 262145,
      "p": [
        {
          "n": "propertyName",
          "p": 1310721
        }
      ],
      "n": "HasProperty",
      "d": 2228235,
      "h": 85901574155,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(85901574155),
//--TRIMMABLE-BOUNDARY-START(81606606859),
    {
      "r": 1310721,
      "p": [
        {
          "n": "propertyName",
          "p": 1310721
        }
      ],
      "n": "GetTypeOfProperty",
      "d": 2228235,
      "h": 81606606859,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(81606606859),
//--TRIMMABLE-BOUNDARY-START(55836803083),
    {
      "r": 262145,
      "p": [
        {
          "n": "propertyName",
          "p": 1310721
        }
      ],
      "n": "GetPropertyAsBoolean",
      "d": 2228235,
      "h": 55836803083,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(55836803083),
//--TRIMMABLE-BOUNDARY-START(68721704971),
    {
      "r": 655361,
      "p": [
        {
          "n": "propertyName",
          "p": 1310721
        }
      ],
      "n": "GetPropertyAsInt32",
      "d": 2228235,
      "h": 68721704971,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(68721704971),
//--TRIMMABLE-BOUNDARY-START(64426737675),
    {
      "r": 1179649,
      "p": [
        {
          "n": "propertyName",
          "p": 1310721
        }
      ],
      "n": "GetPropertyAsDouble",
      "d": 2228235,
      "h": 64426737675,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(64426737675),
//--TRIMMABLE-BOUNDARY-START(77311639563),
    {
      "r": 1310721,
      "p": [
        {
          "n": "propertyName",
          "p": 1310721
        }
      ],
      "n": "GetPropertyAsString",
      "d": 2228235,
      "h": 77311639563,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(77311639563),
//--TRIMMABLE-BOUNDARY-START(73016672267),
    {
      "r": 2228235,
      "p": [
        {
          "n": "propertyName",
          "p": 1310721
        }
      ],
      "n": "GetPropertyAsJSObject",
      "d": 2228235,
      "h": 73016672267,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(73016672267),
//--TRIMMABLE-BOUNDARY-START(60131770379),
    {
      "r": $.$typeArray($.$$.System.Byte).$h,
      "p": [
        {
          "n": "propertyName",
          "p": 1310721
        }
      ],
      "n": "GetPropertyAsByteArray",
      "d": 2228235,
      "h": 60131770379,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(60131770379),
//--TRIMMABLE-BOUNDARY-START(103081443339),
    {
      "r": 65537,
      "p": [
        {
          "n": "propertyName",
          "p": 1310721
        },
        {
          "n": "value",
          "p": 262145
        }
      ],
      "n": "SetProperty",
      "d": 2228235,
      "h": 103081443339,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(103081443339),
//--TRIMMABLE-BOUNDARY-START(115966345227),
    {
      "r": 65537,
      "p": [
        {
          "n": "propertyName",
          "p": 1310721
        },
        {
          "n": "value",
          "p": 655361
        }
      ],
      "n": "SetProperty",
      "o": "@$3",
      "d": 2228235,
      "h": 115966345227,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(115966345227),
//--TRIMMABLE-BOUNDARY-START(111671377931),
    {
      "r": 65537,
      "p": [
        {
          "n": "propertyName",
          "p": 1310721
        },
        {
          "n": "value",
          "p": 1179649
        }
      ],
      "n": "SetProperty",
      "o": "@$2",
      "d": 2228235,
      "h": 111671377931,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(111671377931),
//--TRIMMABLE-BOUNDARY-START(120261312523),
    {
      "r": 65537,
      "p": [
        {
          "n": "propertyName",
          "p": 1310721
        },
        {
          "n": "value",
          "p": 1310721
        }
      ],
      "n": "SetProperty",
      "o": "@$4",
      "d": 2228235,
      "h": 120261312523,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(120261312523),
//--TRIMMABLE-BOUNDARY-START(124556279819),
    {
      "r": 65537,
      "p": [
        {
          "n": "propertyName",
          "p": 1310721
        },
        {
          "n": "value",
          "p": 2228235
        }
      ],
      "n": "SetProperty",
      "o": "@$5",
      "d": 2228235,
      "h": 124556279819,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(124556279819),
//--TRIMMABLE-BOUNDARY-START(107376410635),
    {
      "r": 65537,
      "p": [
        {
          "n": "propertyName",
          "p": 1310721
        },
        {
          "n": "value",
          "p": $.$typeArray($.$$.System.Byte).$h
        }
      ],
      "n": "SetProperty",
      "o": "@$1",
      "d": 2228235,
      "h": 107376410635,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(107376410635)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(94491508747),
    {
      "t": 786433,
      "n": "JSHandle",
      "d": 2228235,
      "h": 94491508747,
      "f": 4194312
    },
//--TRIMMABLE-BOUNDARY-END(94491508747),
//--TRIMMABLE-BOUNDARY-START(98786476043),
    {
      "t": 2293771,
      "n": "ProxyContext",
      "d": 2228235,
      "h": 98786476043,
      "f": 4194312
    },
//--TRIMMABLE-BOUNDARY-END(98786476043),
//--TRIMMABLE-BOUNDARY-START(4297195531),
    {
      "t": 262145,
      "n": "_isDisposed",
      "d": 2228235,
      "h": 4297195531,
      "f": 4194312
    },
//--TRIMMABLE-BOUNDARY-END(4297195531)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(8592162827),
    {
      "p": [
        {
          "n": "jsHandle",
          "p": 786433
        },
        {
          "n": "ctx",
          "p": 2293771
        }
      ],
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 2228235,
      "h": 8592162827,
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(8592162827)
  ],
  "i": [90308609
  ],
  "h": 2228235,
  "a": [
    {
      "t": 159055873,
      "c": 4454023169,
      "a": [
        {
          "v": "browser",
          "t": 1310721
        }
      ]
    }
  ]
}; }
            static get $b() { return $.$$.System.Object; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.System.IDisposable ]; }
            static get $fullName() { return `System.Runtime.InteropServices.JavaScript.JSObject`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2228235)
        
        
        //--TRIMMABLE-BOUNDARY-START(2293771)
        $asm.$cls("$srij.System.Runtime.InteropServices.JavaScript.JSProxyContext", ($self) => class JSProxyContext extends $.$$.System.Object
        {
            //--TRIMMABLE-BOUNDARY-START(4297261067)
            /*bool*/ _isDisposed = false;
            //--TRIMMABLE-BOUNDARY-END(4297261067)
            
            //--TRIMMABLE-BOUNDARY-START(128851312651)
            /*Dictionary<nint, WeakReference<JSObject>>*/ ThreadCsOwnedObjects = null;
            //--TRIMMABLE-BOUNDARY-END(128851312651)
            
            //--TRIMMABLE-BOUNDARY-START(137441247243)
            /*Dictionary<object, nint>*/ ThreadJsOwnedObjects = null;
            //--TRIMMABLE-BOUNDARY-END(137441247243)
            
            //--TRIMMABLE-BOUNDARY-START(133146279947)
            /*Dictionary<nint, PromiseHolder>*/ ThreadJsOwnedHolders = null;
            //--TRIMMABLE-BOUNDARY-END(133146279947)
            
            //--TRIMMABLE-BOUNDARY-START(107376476171)
            /*nint*/ NextJSVHandle = -2;
            //--TRIMMABLE-BOUNDARY-END(107376476171)
            
            //--TRIMMABLE-BOUNDARY-START(98786541579)
            /*List<nint>*/ JSVHandleFreeList = null;
            //--TRIMMABLE-BOUNDARY-END(98786541579)
            
            //--TRIMMABLE-BOUNDARY-START(12887195659)
            $ctor$1()
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(12887195659);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(12887195659)
            
            //--TRIMMABLE-BOUNDARY-START(85901639691)
            /*bool */ IsCurrentThread()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(85901639691);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return true;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(85901639691)
            
            //--TRIMMABLE-BOUNDARY-START(103081508875)
            /*JSProxyContext*/ static MainThreadContext = null;
            //--TRIMMABLE-BOUNDARY-END(103081508875)
            
            //--TRIMMABLE-BOUNDARY-START(38656999435)
            static /*JSProxyContext */ get CurrentThreadContext()
            {
                return $.$srij.System.Runtime.InteropServices.JavaScript.JSProxyContext.MainThreadContext;
            }
            //--TRIMMABLE-BOUNDARY-END(38656999435)
            
            //--TRIMMABLE-BOUNDARY-START(34362032139)
            static /*JSProxyContext */ get CurrentOperationContext()
            {
                return $.$srij.System.Runtime.InteropServices.JavaScript.JSProxyContext.MainThreadContext;
            }
            //--TRIMMABLE-BOUNDARY-END(34362032139)
            
            //--TRIMMABLE-BOUNDARY-START(111671443467)
            static /*JSProxyContext */ PushOperationWithCurrentThreadContext()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(111671443467);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$srij.System.Runtime.InteropServices.JavaScript.JSProxyContext.MainThreadContext;
            }
            //--TRIMMABLE-BOUNDARY-END(111671443467)
            
            //--TRIMMABLE-BOUNDARY-START(21477130251)
            static /*JSProxyContext */ AssertIsInteropThread()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21477130251);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$srij.System.Runtime.InteropServices.JavaScript.JSProxyContext.MainThreadContext;
            }
            //--TRIMMABLE-BOUNDARY-END(21477130251)
            
            //--TRIMMABLE-BOUNDARY-START(94491574283)
            static /*bool */ IsJSVHandle(/*nint*/ jsHandle)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(94491574283);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return jsHandle < -1;
            }
            //--TRIMMABLE-BOUNDARY-END(94491574283)
            
            //--TRIMMABLE-BOUNDARY-START(90196606987)
            static /*bool */ IsGCVHandle(/*nint*/ gcHandle)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(90196606987);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return gcHandle < -1;
            }
            //--TRIMMABLE-BOUNDARY-END(90196606987)
            
            //--TRIMMABLE-BOUNDARY-START(17182162955)
            /*nint */ AllocJSVHandle()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17182162955);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                {
                    $.$$.System.ObjectDisposedException.ThrowIf(this._isDisposed, this);
                    if (this.JSVHandleFreeList.Count > 0)
                    {
                        /*var*/ let jsvHandle = this.JSVHandleFreeList.get_Item(((this.JSVHandleFreeList.Count - 1) | 0));
                        this.JSVHandleFreeList.RemoveAt(((this.JSVHandleFreeList.Count - 1) | 0));
                        return jsvHandle;
                    }
                    return this.NextJSVHandle--;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(17182162955)
            
            //--TRIMMABLE-BOUNDARY-START(55836868619)
            /*void */ FreeJSVHandle(/*nint*/ jsvHandle)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(55836868619);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                {
                    this.JSVHandleFreeList.Add(jsvHandle);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(55836868619)
            
            //--TRIMMABLE-BOUNDARY-START(77311705099)
            /*IntPtr */ GetJSOwnedObjectGCHandle(/*object*/ obj, /*GCHandleType*/ handleType)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(77311705099);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (obj === null)
                {
                    return $.$$.System.IntPtr.Zero;
                }
                {
                    /*IntPtr*/ let gcHandle;
                    if (this.ThreadJsOwnedObjects.TryGetValue(obj, $.$ref(() => gcHandle, ($v) => gcHandle = $v, $.$$.System.IntPtr)))
                    {
                        return gcHandle;
                    }
                    /*IntPtr*/ let result = $.$$.System.Runtime.InteropServices.GCHandle.op_Explicit($.$$.System.Runtime.InteropServices.GCHandle.Alloc(obj, handleType));
                    this.ThreadJsOwnedObjects.set_Item(obj, result);
                    return result;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(77311705099)
            
            //--TRIMMABLE-BOUNDARY-START(30067064843)
            /*PromiseHolder */ CreatePromiseHolder()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(30067064843);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                {
                    return new $.$srij.System.Runtime.InteropServices.JavaScript.JSHostImplementation.PromiseHolder().$ctor$2(this);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(30067064843)
            
            //--TRIMMABLE-BOUNDARY-START(81606672395)
            /*PromiseHolder */ GetPromiseHolder(/*nint*/ gcHandle)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(81606672395);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                {
                    /*PromiseHolder?*/ let holder;
                    if ($.$srij.System.Runtime.InteropServices.JavaScript.JSProxyContext.IsGCVHandle(gcHandle))
                    {
                        if (!this.ThreadJsOwnedHolders.TryGetValue(gcHandle, $.$ref(() => holder, ($v) => holder = $v, $.$srij.System.Runtime.InteropServices.JavaScript.JSHostImplementation.PromiseHolder)))
                        {
                            holder = new $.$srij.System.Runtime.InteropServices.JavaScript.JSHostImplementation.PromiseHolder().$ctor$1(this, gcHandle);
                            this.ThreadJsOwnedHolders.Add(gcHandle, holder);
                        }
                    }
                    else 
                    {
                        holder = $.$cast(($.$$.System.Runtime.InteropServices.GCHandle.op_Explicit$1(gcHandle)).Target, $.$srij.System.Runtime.InteropServices.JavaScript.JSHostImplementation.PromiseHolder);
                    }
                    return holder;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(81606672395)
            
            //--TRIMMABLE-BOUNDARY-START(124556345355)
            /*void */ ReleasePromiseHolder(/*nint*/ holderGCHandle)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(124556345355);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                {
                    /*PromiseHolder?*/ let holder;
                    if ($.$srij.System.Runtime.InteropServices.JavaScript.JSProxyContext.IsGCVHandle(holderGCHandle))
                    {
                        if (!this.ThreadJsOwnedHolders.Remove(holderGCHandle, $.$ref(() => holder, ($v) => holder = $v, $.$srij.System.Runtime.InteropServices.JavaScript.JSHostImplementation.PromiseHolder)))
                        {
                            throw new $.$$.System.InvalidOperationException().$ctor$12("ReleasePromiseHolder expected PromiseHolder " + holderGCHandle);
                        }
                        holder.IsDisposed = true;
                    }
                    else 
                    {
                        /*GCHandle*/ let handle = $.$$.System.Runtime.InteropServices.GCHandle.op_Explicit$1(holderGCHandle);
                        /*var*/ let target = handle.Target;
                        let holder2;
                        if ($.$is(target, $.$srij.System.Runtime.InteropServices.JavaScript.JSHostImplementation.PromiseHolder, { set $v(v){ holder2 = v; } }))
                        {
                            holder = holder2;
                        }
                        else 
                        {
                            throw new $.$$.System.InvalidOperationException().$ctor$12("ReleasePromiseHolder expected PromiseHolder" + holderGCHandle);
                        }
                        holder.IsDisposed = true;
                        handle.Free();
                    }
                }
            }
            //--TRIMMABLE-BOUNDARY-END(124556345355)
            
            //--TRIMMABLE-BOUNDARY-START(120261378059)
            /*void */ ReleaseJSOwnedObjectByGCHandle(/*nint*/ gcHandle)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(120261378059);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*ToManagedCallback?*/ let holderCallback = null;
                {
                    /*PromiseHolder?*/ let holder = null;
                    if ($.$srij.System.Runtime.InteropServices.JavaScript.JSProxyContext.IsGCVHandle(gcHandle))
                    {
                        if (!this.ThreadJsOwnedHolders.Remove(gcHandle, $.$ref(() => holder, ($v) => holder = $v, $.$srij.System.Runtime.InteropServices.JavaScript.JSHostImplementation.PromiseHolder)))
                        {
                            throw new $.$$.System.InvalidOperationException().$ctor$12("ReleaseJSOwnedObjectByGCHandle expected in ThreadJsOwnedHolders");
                        }
                    }
                    else 
                    {
                        /*GCHandle*/ let handle = $.$$.System.Runtime.InteropServices.GCHandle.op_Explicit$1(gcHandle);
                        /*var*/ let target = handle.Target;
                        let holder2;
                        if ($.$is(target, $.$srij.System.Runtime.InteropServices.JavaScript.JSHostImplementation.PromiseHolder, { set $v(v){ holder2 = v; } }))
                        {
                            holder = holder2;
                        }
                        else 
                        {
                            if (!this.ThreadJsOwnedObjects.Remove$1(target))
                            {
                                throw new $.$$.System.InvalidOperationException().$ctor$12("ReleaseJSOwnedObjectByGCHandle expected in ThreadJsOwnedObjects");
                            }
                        }
                        handle.Free();
                    }
                    if (holder !== null)
                    {
                        holderCallback = holder.Callback;
                        holder.IsDisposed = true;
                    }
                }
                holderCallback?.Invoke(null);
            }
            //--TRIMMABLE-BOUNDARY-END(120261378059)
            
            //--TRIMMABLE-BOUNDARY-START(25772097547)
            /*JSObject */ CreateCSOwnedProxy(/*nint*/ jsHandle)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25772097547);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                {
                    /*JSObject?*/ let res;
                    /*WeakReference<JSObject>?*/ let reference;
                    if (!this.ThreadCsOwnedObjects.TryGetValue(jsHandle, $.$ref(() => reference, ($v) => reference = $v, $.$$.System.WeakReference$$($.$srij.System.Runtime.InteropServices.JavaScript.JSObject))) || !reference.TryGetTarget($.$ref(() => res, ($v) => res = $v, $.$srij.System.Runtime.InteropServices.JavaScript.JSObject)) || res.IsDisposed)
                    {
                        res = new $.$srij.System.Runtime.InteropServices.JavaScript.JSObject().$ctor$1(jsHandle, this);
                        this.ThreadCsOwnedObjects.set_Item(jsHandle, new ($.$$.System.WeakReference$$($.$srij.System.Runtime.InteropServices.JavaScript.JSObject))().$ctor$2(res, true));
                    }
                    return res;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(25772097547)
            
            //--TRIMMABLE-BOUNDARY-START(115966410763)
            static /*void */ ReleaseCSOwnedObject(/*JSObject*/ jso, /*bool*/ skipJS)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(115966410763);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (jso.IsDisposed)
                {
                    return;
                }
                /*var*/ let ctx = jso.ProxyContext;
                {
                    if (jso.IsDisposed || ctx._isDisposed)
                    {
                        return;
                    }
                    /*var*/ let jsHandle = jso.JSHandle;
                    jso._isDisposed = true;
                    jso.JSHandle = $.$$.System.IntPtr.Zero;
                    $.$$.System.GC.SuppressFinalize(jso);
                    if (!ctx.ThreadCsOwnedObjects.Remove$1(jsHandle))
                    {
                        $.$$.System.Environment.FailFast$2(`ReleaseCSOwnedObject expected to find registration for JSHandle: ${jsHandle}, ManagedThreadId: ${$.$$.System.Environment.CurrentManagedThreadId}. ${$.$$.System.Environment.NewLine} ${$.$$.System.Environment.StackTrace}`);
                    }
                    if (!skipJS)
                    {
                        $.$srij.Interop.Runtime.ReleaseCSOwnedObject(jsHandle);
                    }
                    if ($.$srij.System.Runtime.InteropServices.JavaScript.JSProxyContext.IsJSVHandle(jsHandle))
                    {
                        ctx.FreeJSVHandle(jsHandle);
                    }
                }
            }
            //--TRIMMABLE-BOUNDARY-END(115966410763)
            
            //--TRIMMABLE-BOUNDARY-START(47246934027)
            /*void */ Dispose$1(/*bool*/ disposing)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(47246934027);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                {
                    if (!this._isDisposed)
                    {
                        /*List<WeakReference<JSObject>>*/ let copy = new ($.$$.System.Collections.Generic.List$$($.$$.System.WeakReference$$($.$srij.System.Runtime.InteropServices.JavaScript.JSObject)))().$ctor$2(this.ThreadCsOwnedObjects.Values);
                        var $en4 = copy.GetEnumerator();
                        while ($en4.MoveNext())
                        {
                            var jsObjectWeak = $en4.Current;
                            {
                                /*var*/ let jso;
                                if (jsObjectWeak.TryGetTarget($.$ref(() => jso, ($v) => jso = $v, $.$srij.System.Runtime.InteropServices.JavaScript.JSObject)))
                                {
                                    jso.Dispose();
                                }
                            }
                        }
                        var $en4 = this.ThreadJsOwnedObjects.Values.GetEnumerator();
                        while ($en4.MoveNext())
                        {
                            var gch = $en4.Current;
                            {
                                /*GCHandle*/ let gcHandle = $.$$.System.Runtime.InteropServices.GCHandle.op_Explicit$1(gch);
                                gcHandle.Free();
                            }
                        }
                        var $en4 = this.ThreadJsOwnedHolders.Values.GetEnumerator();
                        while ($en4.MoveNext())
                        {
                            var holder = $en4.Current;
                            {
                                {
                                    holder.Callback.Invoke(null);
                                }
                                ($.$$.System.Runtime.InteropServices.GCHandle.op_Explicit$1(holder.GCHandle)).Free();
                            }
                        }
                        this.ThreadCsOwnedObjects.Clear();
                        this.ThreadJsOwnedObjects.Clear();
                        this.JSVHandleFreeList.Clear();
                        this.NextJSVHandle = $.$$.System.IntPtr.Zero;
                        if (disposing)
                        {
                        }
                        this._isDisposed = true;
                    }
                }
            }
            //--TRIMMABLE-BOUNDARY-END(47246934027)
            
            $dtor()
            {
                this.Dispose$1(false);
            }
            //--TRIMMABLE-BOUNDARY-START(42951966731)
            /*void */ Dispose()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(42951966731);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.Dispose$1(true);
                $.$$.System.GC.SuppressFinalize(this);
            }
            //--TRIMMABLE-BOUNDARY-END(42951966731)
            
            //--TRIMMABLE-BOUNDARY-START(4385275905)
            //Generated interface implemetation for System.IDisposable.Dispose()
            System$IDisposable$Dispose()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4385275905);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Dispose(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4385275905)
            
            //default member initializer
            constructor()
            {
                super();
                //--TRIMMABLE-BOUNDARY-START(128851312651)
                this.ThreadCsOwnedObjects = new ($.$$.System.Collections.Generic.Dictionary$$$($.$$.System.IntPtr, $.$$.System.WeakReference$$($.$srij.System.Runtime.InteropServices.JavaScript.JSObject)))().$ctor$1();
                //--TRIMMABLE-BOUNDARY-END(128851312651)
                
                //--TRIMMABLE-BOUNDARY-START(137441247243)
                this.ThreadJsOwnedObjects = new ($.$$.System.Collections.Generic.Dictionary$$$($.$$.System.Object, $.$$.System.IntPtr))().$ctor$6($.$$.System.Collections.Generic.ReferenceEqualityComparer.Instance);
                //--TRIMMABLE-BOUNDARY-END(137441247243)
                
                //--TRIMMABLE-BOUNDARY-START(133146279947)
                this.ThreadJsOwnedHolders = new ($.$$.System.Collections.Generic.Dictionary$$$($.$$.System.IntPtr, $.$srij.System.Runtime.InteropServices.JavaScript.JSHostImplementation.PromiseHolder))().$ctor$1();
                //--TRIMMABLE-BOUNDARY-END(133146279947)
                
                //--TRIMMABLE-BOUNDARY-START(98786541579)
                this.JSVHandleFreeList = new ($.$$.System.Collections.Generic.List$$($.$$.System.IntPtr))().$ctor$1();
                //--TRIMMABLE-BOUNDARY-END(98786541579)
                
                $.$finalizer(this);
            }
            //--TRIMMABLE-BOUNDARY-START(8592228363)
            //Static Initializer
            static $sinit()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(103081508875)
                    this.MainThreadContext = new $.$srij.System.Runtime.InteropServices.JavaScript.JSProxyContext().$ctor$1();
                    //--TRIMMABLE-BOUNDARY-END(103081508875)
                    
                }
            }
            //--TRIMMABLE-BOUNDARY-END(8592228363)
            
            static $h = 2293771;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 131073,
  "p": [
//--TRIMMABLE-BOUNDARY-START(38656999435),
    {
      "p": 2293771,
      "g": {
        "r": 0,
        "d": 0,
        "h": 73016737803,
        "f": 50331681
      },
      "n": "CurrentThreadContext",
      "d": 2293771,
      "h": 38656999435,
      "f": 2097185
    },
//--TRIMMABLE-BOUNDARY-END(38656999435),
//--TRIMMABLE-BOUNDARY-START(34362032139),
    {
      "p": 2293771,
      "g": {
        "r": 0,
        "d": 0,
        "h": 64426803211,
        "f": 50331681
      },
      "n": "CurrentOperationContext",
      "d": 2293771,
      "h": 34362032139,
      "f": 2097185
    },
//--TRIMMABLE-BOUNDARY-END(34362032139)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(85901639691),
    {
      "r": 262145,
      "n": "IsCurrentThread",
      "d": 2293771,
      "h": 85901639691,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(85901639691),
//--TRIMMABLE-BOUNDARY-START(111671443467),
    {
      "r": 2293771,
      "n": "PushOperationWithCurrentThreadContext",
      "d": 2293771,
      "h": 111671443467,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(111671443467),
//--TRIMMABLE-BOUNDARY-START(21477130251),
    {
      "r": 2293771,
      "n": "AssertIsInteropThread",
      "d": 2293771,
      "h": 21477130251,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(21477130251),
//--TRIMMABLE-BOUNDARY-START(94491574283),
    {
      "r": 262145,
      "p": [
        {
          "n": "jsHandle",
          "p": 786433
        }
      ],
      "n": "IsJSVHandle",
      "d": 2293771,
      "h": 94491574283,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(94491574283),
//--TRIMMABLE-BOUNDARY-START(90196606987),
    {
      "r": 262145,
      "p": [
        {
          "n": "gcHandle",
          "p": 786433
        }
      ],
      "n": "IsGCVHandle",
      "d": 2293771,
      "h": 90196606987,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(90196606987),
//--TRIMMABLE-BOUNDARY-START(17182162955),
    {
      "r": 786433,
      "n": "AllocJSVHandle",
      "d": 2293771,
      "h": 17182162955,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(17182162955),
//--TRIMMABLE-BOUNDARY-START(55836868619),
    {
      "r": 65537,
      "p": [
        {
          "n": "jsvHandle",
          "p": 786433
        }
      ],
      "n": "FreeJSVHandle",
      "d": 2293771,
      "h": 55836868619,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(55836868619),
//--TRIMMABLE-BOUNDARY-START(77311705099),
    {
      "r": 786433,
      "p": [
        {
          "n": "obj",
          "p": 131073
        },
        {
          "n": "handleType",
          "p": 141819905,
          "f": 65,
          "v": 2
        }
      ],
      "n": "GetJSOwnedObjectGCHandle",
      "d": 2293771,
      "h": 77311705099,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(77311705099),
//--TRIMMABLE-BOUNDARY-START(30067064843),
    {
      "r": 983051,
      "n": "CreatePromiseHolder",
      "d": 2293771,
      "h": 30067064843,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(30067064843),
//--TRIMMABLE-BOUNDARY-START(81606672395),
    {
      "r": 983051,
      "p": [
        {
          "n": "gcHandle",
          "p": 786433
        }
      ],
      "n": "GetPromiseHolder",
      "d": 2293771,
      "h": 81606672395,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(81606672395),
//--TRIMMABLE-BOUNDARY-START(124556345355),
    {
      "r": 65537,
      "p": [
        {
          "n": "holderGCHandle",
          "p": 786433
        }
      ],
      "n": "ReleasePromiseHolder",
      "d": 2293771,
      "h": 124556345355,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(124556345355),
//--TRIMMABLE-BOUNDARY-START(120261378059),
    {
      "r": 65537,
      "p": [
        {
          "n": "gcHandle",
          "p": 786433
        }
      ],
      "n": "ReleaseJSOwnedObjectByGCHandle",
      "d": 2293771,
      "h": 120261378059,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(120261378059),
//--TRIMMABLE-BOUNDARY-START(25772097547),
    {
      "r": 2228235,
      "p": [
        {
          "n": "jsHandle",
          "p": 786433
        }
      ],
      "n": "CreateCSOwnedProxy",
      "d": 2293771,
      "h": 25772097547,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(25772097547),
//--TRIMMABLE-BOUNDARY-START(115966410763),
    {
      "r": 65537,
      "p": [
        {
          "n": "jso",
          "p": 2228235
        },
        {
          "n": "skipJS",
          "p": 262145
        }
      ],
      "n": "ReleaseCSOwnedObject",
      "d": 2293771,
      "h": 115966410763,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(115966410763),
//--TRIMMABLE-BOUNDARY-START(47246934027),
    {
      "r": 65537,
      "p": [
        {
          "n": "disposing",
          "p": 262145
        }
      ],
      "n": "Dispose",
      "o": "@$1",
      "d": 2293771,
      "h": 47246934027,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(47246934027),
//--TRIMMABLE-BOUNDARY-START(42951966731),
    {
      "r": 65537,
      "n": "Dispose",
      "d": 2293771,
      "h": 42951966731,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(42951966731)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(4297261067),
    {
      "t": 262145,
      "n": "_isDisposed",
      "d": 2293771,
      "h": 4297261067,
      "f": 4194312
    },
//--TRIMMABLE-BOUNDARY-END(4297261067),
//--TRIMMABLE-BOUNDARY-START(128851312651),
    {
      "t": $.$$.System.Collections.Generic.Dictionary$$$($.$$.System.IntPtr, $.$$.System.WeakReference$$($.$srij.System.Runtime.InteropServices.JavaScript.JSObject)).$h,
      "n": "ThreadCsOwnedObjects",
      "d": 2293771,
      "h": 128851312651,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(128851312651),
//--TRIMMABLE-BOUNDARY-START(137441247243),
    {
      "t": $.$$.System.Collections.Generic.Dictionary$$$($.$$.System.Object, $.$$.System.IntPtr).$h,
      "n": "ThreadJsOwnedObjects",
      "d": 2293771,
      "h": 137441247243,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(137441247243),
//--TRIMMABLE-BOUNDARY-START(133146279947),
    {
      "t": $.$$.System.Collections.Generic.Dictionary$$$($.$$.System.IntPtr, $.$srij.System.Runtime.InteropServices.JavaScript.JSHostImplementation.PromiseHolder).$h,
      "n": "ThreadJsOwnedHolders",
      "d": 2293771,
      "h": 133146279947,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(133146279947),
//--TRIMMABLE-BOUNDARY-START(107376476171),
    {
      "t": 786433,
      "n": "NextJSVHandle",
      "d": 2293771,
      "h": 107376476171,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(107376476171),
//--TRIMMABLE-BOUNDARY-START(98786541579),
    {
      "t": $.$$.System.Collections.Generic.List$$($.$$.System.IntPtr).$h,
      "n": "JSVHandleFreeList",
      "d": 2293771,
      "h": 98786541579,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(98786541579),
//--TRIMMABLE-BOUNDARY-START(103081508875),
    {
      "t": 2293771,
      "n": "MainThreadContext",
      "d": 2293771,
      "h": 103081508875,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(103081508875)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(12887195659),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 2293771,
      "h": 12887195659,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(12887195659)
  ],
  "i": [90308609
  ],
  "h": 2293771
}; }
            static get $b() { return $.$$.System.Object; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.System.IDisposable ]; }
            static get $fullName() { return `System.Runtime.InteropServices.JavaScript.JSProxyContext`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2293771)
        
        
        //--TRIMMABLE-BOUNDARY-START(1245195)
        $asm.$cls("$srij.System.Runtime.InteropServices.JavaScript.JSMarshalAsAttribute<>", (T) => $asm.$gt("$srij.System.Runtime.InteropServices.JavaScript.JSMarshalAsAttribute<>", [T], ($self) => class JSMarshalAsAttribute$$ extends $.$$.System.Attribute
        {
            //--TRIMMABLE-BOUNDARY-START(4296212491)
            $ctor$2()
            {
                super.$ctor$1();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4296212491);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296212491)
            
            static $h = 1245195;
            static $g = 1;
            static $f = 0b11010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 45350913,
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296212491),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x100000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296212491)
  ],
  "g": [T?.$h??1507328
  ],
  "r": 1,
  "h": this.$h,
  "a": [
    {
      "t": 45481985,
      "c": 25815285761,
      "a": [
        {
          "v": 10240,
          "t": 45416449
        }
      ],
      "n": [
        {
          "n": "Inherited",
          "v": false,
          "t": 262145
        },
        {
          "n": "AllowMultiple",
          "v": false,
          "t": 262145
        }
      ]
    },
    {
      "t": 159055873,
      "c": 4454023169,
      "a": [
        {
          "v": "browser",
          "t": 1310721
        }
      ]
    }
  ]
}; }
            static get $b() { return $.$$.System.Attribute; }
            static get $fullName() { return `System.Runtime.InteropServices.JavaScript.JSMarshalAsAttribute<${T?.$fullName}>`; }
        }));
        //--TRIMMABLE-BOUNDARY-END(1245195)
        
        
        //--TRIMMABLE-BOUNDARY-START(1310731)
        $asm.$str("$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument", ($self) => class JSMarshalerArgument extends $.$$.System.ValueType
        {
            //--TRIMMABLE-BOUNDARY-START(554052091915)
            /*void */ ToManagedBig(/*out long*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(554052091915);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (this.slot.Type === 0/*MarshalerType.None*/)
                {
                    value.$v = 0n;
                    return;
                }
                value.$v = this.slot.Int64Value;
            }
            //--TRIMMABLE-BOUNDARY-END(554052091915)
            
            //--TRIMMABLE-BOUNDARY-START(326418825227)
            /*void */ ToJSBig(/*long*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(326418825227);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.slot.Type = 9/*MarshalerType.BigInt64*/;
                this.slot.Int64Value = value;
            }
            //--TRIMMABLE-BOUNDARY-END(326418825227)
            
            //--TRIMMABLE-BOUNDARY-START(558347059211)
            /*void */ ToManagedBig$1(/*out long?*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(558347059211);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (this.slot.Type === 0/*MarshalerType.None*/)
                {
                    value.$v = null;
                    return;
                }
                value.$v = this.slot.Int64Value;
            }
            //--TRIMMABLE-BOUNDARY-END(558347059211)
            
            //--TRIMMABLE-BOUNDARY-START(330713792523)
            /*void */ ToJSBig$1(/*long?*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(330713792523);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$$.System.Nullable$$($.$$.System.Int64).HasValue$get.call(value))
                {
                    this.slot.Type = 9/*MarshalerType.BigInt64*/;
                    this.slot.Int64Value = $.$$.System.Nullable$$($.$$.System.Int64).Value$get.call(value);
                }
                else 
                {
                    this.slot.Type = 0/*MarshalerType.None*/;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(330713792523)
            
            //--TRIMMABLE-BOUNDARY-START(373663465483)
            /*void */ ToManaged$7(/*out char*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(373663465483);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (this.slot.Type === 0/*MarshalerType.None*/)
                {
                    value.$v = 0;
                    return;
                }
                value.$v = this.slot.CharValue;
            }
            //--TRIMMABLE-BOUNDARY-END(373663465483)
            
            //--TRIMMABLE-BOUNDARY-START(146030198795)
            /*void */ ToJS$7(/*char*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(146030198795);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.slot.Type = 5/*MarshalerType.Char*/;
                this.slot.CharValue = value;
            }
            //--TRIMMABLE-BOUNDARY-END(146030198795)
            
            //--TRIMMABLE-BOUNDARY-START(429498040331)
            /*void */ ToManaged$20(/*out char?*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(429498040331);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (this.slot.Type === 0/*MarshalerType.None*/)
                {
                    value.$v = null;
                    return;
                }
                value.$v = this.slot.CharValue;
            }
            //--TRIMMABLE-BOUNDARY-END(429498040331)
            
            //--TRIMMABLE-BOUNDARY-START(201864773643)
            /*void */ ToJS$20(/*char?*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(201864773643);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$$.System.Nullable$$($.$$.System.Char).HasValue$get.call(value))
                {
                    this.slot.Type = 5/*MarshalerType.Char*/;
                    this.slot.CharValue = $.$$.System.Nullable$$($.$$.System.Char).Value$get.call(value);
                }
                else 
                {
                    this.slot.Type = 0/*MarshalerType.None*/;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(201864773643)
            
            //--TRIMMABLE-BOUNDARY-START(476742680587)
            /*void */ ToManaged$31(/*out float*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(476742680587);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (this.slot.Type === 0/*MarshalerType.None*/)
                {
                    value.$v = 0;
                    return;
                }
                value.$v = this.slot.SingleValue;
            }
            //--TRIMMABLE-BOUNDARY-END(476742680587)
            
            //--TRIMMABLE-BOUNDARY-START(249109413899)
            /*void */ ToJS$31(/*float*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(249109413899);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.slot.Type = 11/*MarshalerType.Single*/;
                this.slot.SingleValue = value;
            }
            //--TRIMMABLE-BOUNDARY-END(249109413899)
            
            //--TRIMMABLE-BOUNDARY-START(463857778699)
            /*void */ ToManaged$28(/*out float?*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(463857778699);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (this.slot.Type === 0/*MarshalerType.None*/)
                {
                    value.$v = null;
                    return;
                }
                value.$v = this.slot.SingleValue;
            }
            //--TRIMMABLE-BOUNDARY-END(463857778699)
            
            //--TRIMMABLE-BOUNDARY-START(236224512011)
            /*void */ ToJS$28(/*float?*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(236224512011);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$$.System.Nullable$$($.$$.System.Single).HasValue$get.call(value))
                {
                    this.slot.Type = 11/*MarshalerType.Single*/;
                    this.slot.SingleValue = $.$$.System.Nullable$$($.$$.System.Single).Value$get.call(value);
                }
                else 
                {
                    this.slot.Type = 0/*MarshalerType.None*/;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(236224512011)
            
            //--TRIMMABLE-BOUNDARY-START(85900656651)
            /*long*/ static I52_MAX_VALUE = 9007199254740991n;
            //--TRIMMABLE-BOUNDARY-END(85900656651)
            
            //--TRIMMABLE-BOUNDARY-START(90195623947)
            /*long*/ static I52_MIN_VALUE = -9007199254740991n;
            //--TRIMMABLE-BOUNDARY-END(90195623947)
            
            //--TRIMMABLE-BOUNDARY-START(412318171147)
            /*void */ ToManaged$16(/*out long*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(412318171147);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (this.slot.Type === 0/*MarshalerType.None*/)
                {
                    value.$v = 0n;
                    return;
                }
                value.$v = $.$cast(this.slot.DoubleValue, $.$$.System.Int64);
            }
            //--TRIMMABLE-BOUNDARY-END(412318171147)
            
            //--TRIMMABLE-BOUNDARY-START(184684904459)
            /*void */ ToJS$16(/*long*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(184684904459);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (value < -9007199254740991n || value > 9007199254740991n)
                {
                    throw new $.$$.System.OverflowException().$ctor$16($.$srij.System.SR.Format$4($.$srij.System.SR.ValueOutOf52BitRange, $.$box(value, $.$$.System.Int64), $.$box(-9007199254740991n, $.$$.System.Int64), $.$box(9007199254740991n, $.$$.System.Int64)));
                }
                this.slot.Type = 8/*MarshalerType.Int52*/;
                this.slot.DoubleValue = Number(value);
            }
            //--TRIMMABLE-BOUNDARY-END(184684904459)
            
            //--TRIMMABLE-BOUNDARY-START(455267844107)
            /*void */ ToManaged$26(/*out long?*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(455267844107);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (this.slot.Type === 0/*MarshalerType.None*/)
                {
                    value.$v = null;
                    return;
                }
                value.$v = $.$cast(this.slot.DoubleValue, $.$$.System.Int64);
            }
            //--TRIMMABLE-BOUNDARY-END(455267844107)
            
            //--TRIMMABLE-BOUNDARY-START(227634577419)
            /*void */ ToJS$26(/*long?*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(227634577419);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$$.System.Nullable$$($.$$.System.Int64).HasValue$get.call(value))
                {
                    if ($.$$.System.Nullable$$($.$$.System.Int64).Value$get.call(value) < -9007199254740991n || $.$$.System.Nullable$$($.$$.System.Int64).Value$get.call(value) > 9007199254740991n)
                    {
                        throw new $.$$.System.OverflowException().$ctor$16($.$srij.System.SR.Format$4($.$srij.System.SR.ValueOutOf52BitRange, $.$box(value, $.$$.System.Nullable$$($.$$.System.Int64)), $.$box(-9007199254740991n, $.$$.System.Int64), $.$box(9007199254740991n, $.$$.System.Int64)));
                    }
                    this.slot.Type = 8/*MarshalerType.Int52*/;
                    this.slot.DoubleValue = Number($.$$.System.Nullable$$($.$$.System.Int64).Value$get.call(value));
                }
                else 
                {
                    this.slot.Type = 0/*MarshalerType.None*/;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(227634577419)
            
            //--TRIMMABLE-BOUNDARY-START(111670460427)
            /*JSMarshalerArgumentImpl*/  get slot() { return this.$getField(0, 32); }
            /*JSMarshalerArgumentImpl*/  set slot(value) { this.$setField(0, 32, value); }
            //--TRIMMABLE-BOUNDARY-END(111670460427)
            
            //--TRIMMABLE-BOUNDARY-START(2097163)
            static $_JSMarshalerArgumentImpl;
            static get JSMarshalerArgumentImpl()
            {
                let $cls = $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument;
                return $cls.$_JSMarshalerArgumentImpl ??= $asm.$nstr("$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument.JSMarshalerArgumentImpl", ($self) => class JSMarshalerArgumentImpl extends $.$$.System.ValueType
                {
                    //--TRIMMABLE-BOUNDARY-START(8592031755)
                    /*bool*/  get BooleanValue() { return this.$getField(0, 1); }
                    /*bool*/  set BooleanValue(value) { this.$setField(0, 1, value); }
                    //--TRIMMABLE-BOUNDARY-END(8592031755)
                    
                    //--TRIMMABLE-BOUNDARY-START(12886999051)
                    /*byte*/  get ByteValue() { return this.$getField(0, 1); }
                    /*byte*/  set ByteValue(value) { this.$setField(0, 1, value); }
                    //--TRIMMABLE-BOUNDARY-END(12886999051)
                    
                    //--TRIMMABLE-BOUNDARY-START(17181966347)
                    /*char*/  get CharValue() { return this.$getField(0, 2); }
                    /*char*/  set CharValue(value) { this.$setField(0, 2, value); }
                    //--TRIMMABLE-BOUNDARY-END(17181966347)
                    
                    //--TRIMMABLE-BOUNDARY-START(34361835531)
                    /*short*/  get Int16Value() { return this.$getField(0, 2); }
                    /*short*/  set Int16Value(value) { this.$setField(0, 2, value); }
                    //--TRIMMABLE-BOUNDARY-END(34361835531)
                    
                    //--TRIMMABLE-BOUNDARY-START(38656802827)
                    /*int*/  get Int32Value() { return this.$getField(0, 4); }
                    /*int*/  set Int32Value(value) { this.$setField(0, 4, value); }
                    //--TRIMMABLE-BOUNDARY-END(38656802827)
                    
                    //--TRIMMABLE-BOUNDARY-START(42951770123)
                    /*long*/  get Int64Value() { return this.$getField(0, 8); }
                    /*long*/  set Int64Value(value) { this.$setField(0, 8, value); }
                    //--TRIMMABLE-BOUNDARY-END(42951770123)
                    
                    //--TRIMMABLE-BOUNDARY-START(60131639307)
                    /*float*/  get SingleValue() { return this.$getField(0, 4); }
                    /*float*/  set SingleValue(value) { this.$setField(0, 4, value); }
                    //--TRIMMABLE-BOUNDARY-END(60131639307)
                    
                    //--TRIMMABLE-BOUNDARY-START(21476933643)
                    /*double*/  get DoubleValue() { return this.$getField(0, 8); }
                    /*double*/  set DoubleValue(value) { this.$setField(0, 8, value); }
                    //--TRIMMABLE-BOUNDARY-END(21476933643)
                    
                    //--TRIMMABLE-BOUNDARY-START(47246737419)
                    /*IntPtr*/  get IntPtrValue() { return this.$getField(0, 4); }
                    /*IntPtr*/  set IntPtrValue(value) { this.$setField(0, 4, value); }
                    //--TRIMMABLE-BOUNDARY-END(47246737419)
                    
                    //--TRIMMABLE-BOUNDARY-START(51541704715)
                    /*IntPtr*/  get JSHandle() { return this.$getField(4, 4); }
                    /*IntPtr*/  set JSHandle(value) { this.$setField(4, 4, value); }
                    //--TRIMMABLE-BOUNDARY-END(51541704715)
                    
                    //--TRIMMABLE-BOUNDARY-START(30066868235)
                    /*IntPtr*/  get GCHandle() { return this.$getField(4, 4); }
                    /*IntPtr*/  set GCHandle(value) { this.$setField(4, 4, value); }
                    //--TRIMMABLE-BOUNDARY-END(30066868235)
                    
                    //--TRIMMABLE-BOUNDARY-START(55836672011)
                    /*int*/  get Length() { return this.$getField(8, 4); }
                    /*int*/  set Length(value) { this.$setField(8, 4, value); }
                    //--TRIMMABLE-BOUNDARY-END(55836672011)
                    
                    //--TRIMMABLE-BOUNDARY-START(64426606603)
                    /*MarshalerType*/  get Type() { return this.$getField(12, 1); }
                    /*MarshalerType*/  set Type(value) { this.$setField(12, 1, value); }
                    //--TRIMMABLE-BOUNDARY-END(64426606603)
                    
                    //--TRIMMABLE-BOUNDARY-START(25771900939)
                    /*MarshalerType*/  get ElementType() { return this.$getField(13, 1); }
                    /*MarshalerType*/  set ElementType(value) { this.$setField(13, 1, value); }
                    //--TRIMMABLE-BOUNDARY-END(25771900939)
                    
                    //--TRIMMABLE-BOUNDARY-START(4297064459)
                    //default value type constructor
                    $ctor$2()
                    {
                        return this;
                    }
                    //--TRIMMABLE-BOUNDARY-END(4297064459)
                    
                    Clone($copy)
                    {
                        let copy = $copy ?? new this.constructor();
                        copy.BooleanValue = this.BooleanValue;
                        copy.ByteValue = this.ByteValue;
                        copy.CharValue = this.CharValue;
                        copy.Int16Value = this.Int16Value;
                        copy.Int32Value = this.Int32Value;
                        copy.Int64Value = this.Int64Value;
                        copy.SingleValue = this.SingleValue;
                        copy.DoubleValue = this.DoubleValue;
                        copy.IntPtrValue = this.IntPtrValue;
                        copy.JSHandle = this.JSHandle;
                        copy.GCHandle = this.GCHandle;
                        copy.Length = this.Length;
                        copy.Type = this.Type;
                        copy.ElementType = this.ElementType;
                        return copy;
                    }
                    //default member initializer
                    constructor()
                    {
                        super();
                        //--TRIMMABLE-BOUNDARY-START(8592031755)
                        this.BooleanValue = false;
                        //--TRIMMABLE-BOUNDARY-END(8592031755)
                        
                        //--TRIMMABLE-BOUNDARY-START(12886999051)
                        this.ByteValue = 0;
                        //--TRIMMABLE-BOUNDARY-END(12886999051)
                        
                        //--TRIMMABLE-BOUNDARY-START(17181966347)
                        this.CharValue = 0;
                        //--TRIMMABLE-BOUNDARY-END(17181966347)
                        
                        //--TRIMMABLE-BOUNDARY-START(34361835531)
                        this.Int16Value = 0;
                        //--TRIMMABLE-BOUNDARY-END(34361835531)
                        
                        //--TRIMMABLE-BOUNDARY-START(38656802827)
                        this.Int32Value = 0;
                        //--TRIMMABLE-BOUNDARY-END(38656802827)
                        
                        //--TRIMMABLE-BOUNDARY-START(42951770123)
                        this.Int64Value = 0n;
                        //--TRIMMABLE-BOUNDARY-END(42951770123)
                        
                        //--TRIMMABLE-BOUNDARY-START(60131639307)
                        this.SingleValue = 0;
                        //--TRIMMABLE-BOUNDARY-END(60131639307)
                        
                        //--TRIMMABLE-BOUNDARY-START(21476933643)
                        this.DoubleValue = 0;
                        //--TRIMMABLE-BOUNDARY-END(21476933643)
                        
                        //--TRIMMABLE-BOUNDARY-START(47246737419)
                        this.IntPtrValue = 0;
                        //--TRIMMABLE-BOUNDARY-END(47246737419)
                        
                        //--TRIMMABLE-BOUNDARY-START(51541704715)
                        this.JSHandle = 0;
                        //--TRIMMABLE-BOUNDARY-END(51541704715)
                        
                        //--TRIMMABLE-BOUNDARY-START(30066868235)
                        this.GCHandle = 0;
                        //--TRIMMABLE-BOUNDARY-END(30066868235)
                        
                        //--TRIMMABLE-BOUNDARY-START(55836672011)
                        this.Length = 0;
                        //--TRIMMABLE-BOUNDARY-END(55836672011)
                        
                        //--TRIMMABLE-BOUNDARY-START(64426606603)
                        this.Type = 0;
                        //--TRIMMABLE-BOUNDARY-END(64426606603)
                        
                        //--TRIMMABLE-BOUNDARY-START(25771900939)
                        this.ElementType = 0;
                        //--TRIMMABLE-BOUNDARY-END(25771900939)
                        
                    }
                    static $h = 2097163;
                    static $z = 32;
                    static $f = 0b100010000001010000000;
                    static $k = 2;
                    static $$md;
                    static get $md() { return this.$$md ??= {
  "b": 196609,
  "l": [
//--TRIMMABLE-BOUNDARY-START(8592031755),
    {
      "t": 262145,
      "n": "BooleanValue",
      "d": 2097163,
      "h": 8592031755,
      "f": 4194312,
      "a": [
        {
          "t": 141557761,
          "c": 8731492353,
          "a": [
            {
              "v": 0,
              "t": 655361
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(8592031755),
//--TRIMMABLE-BOUNDARY-START(12886999051),
    {
      "t": 393217,
      "n": "ByteValue",
      "d": 2097163,
      "h": 12886999051,
      "f": 4194312,
      "a": [
        {
          "t": 141557761,
          "c": 8731492353,
          "a": [
            {
              "v": 0,
              "t": 655361
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(12886999051),
//--TRIMMABLE-BOUNDARY-START(17181966347),
    {
      "t": 458753,
      "n": "CharValue",
      "d": 2097163,
      "h": 17181966347,
      "f": 4194312,
      "a": [
        {
          "t": 141557761,
          "c": 8731492353,
          "a": [
            {
              "v": 0,
              "t": 655361
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(17181966347),
//--TRIMMABLE-BOUNDARY-START(34361835531),
    {
      "t": 524289,
      "n": "Int16Value",
      "d": 2097163,
      "h": 34361835531,
      "f": 4194312,
      "a": [
        {
          "t": 141557761,
          "c": 8731492353,
          "a": [
            {
              "v": 0,
              "t": 655361
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(34361835531),
//--TRIMMABLE-BOUNDARY-START(38656802827),
    {
      "t": 655361,
      "n": "Int32Value",
      "d": 2097163,
      "h": 38656802827,
      "f": 4194312,
      "a": [
        {
          "t": 141557761,
          "c": 8731492353,
          "a": [
            {
              "v": 0,
              "t": 655361
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(38656802827),
//--TRIMMABLE-BOUNDARY-START(42951770123),
    {
      "t": 917505,
      "n": "Int64Value",
      "d": 2097163,
      "h": 42951770123,
      "f": 4194312,
      "a": [
        {
          "t": 141557761,
          "c": 8731492353,
          "a": [
            {
              "v": 0,
              "t": 655361
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(42951770123),
//--TRIMMABLE-BOUNDARY-START(60131639307),
    {
      "t": 1114113,
      "n": "SingleValue",
      "d": 2097163,
      "h": 60131639307,
      "f": 4194312,
      "a": [
        {
          "t": 141557761,
          "c": 8731492353,
          "a": [
            {
              "v": 0,
              "t": 655361
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(60131639307),
//--TRIMMABLE-BOUNDARY-START(21476933643),
    {
      "t": 1179649,
      "n": "DoubleValue",
      "d": 2097163,
      "h": 21476933643,
      "f": 4194312,
      "a": [
        {
          "t": 141557761,
          "c": 8731492353,
          "a": [
            {
              "v": 0,
              "t": 655361
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(21476933643),
//--TRIMMABLE-BOUNDARY-START(47246737419),
    {
      "t": 786433,
      "n": "IntPtrValue",
      "d": 2097163,
      "h": 47246737419,
      "f": 4194312,
      "a": [
        {
          "t": 141557761,
          "c": 8731492353,
          "a": [
            {
              "v": 0,
              "t": 655361
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(47246737419),
//--TRIMMABLE-BOUNDARY-START(51541704715),
    {
      "t": 786433,
      "n": "JSHandle",
      "d": 2097163,
      "h": 51541704715,
      "f": 4194312,
      "a": [
        {
          "t": 141557761,
          "c": 8731492353,
          "a": [
            {
              "v": 4,
              "t": 655361
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(51541704715),
//--TRIMMABLE-BOUNDARY-START(30066868235),
    {
      "t": 786433,
      "n": "GCHandle",
      "d": 2097163,
      "h": 30066868235,
      "f": 4194312,
      "a": [
        {
          "t": 141557761,
          "c": 8731492353,
          "a": [
            {
              "v": 4,
              "t": 655361
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(30066868235),
//--TRIMMABLE-BOUNDARY-START(55836672011),
    {
      "t": 655361,
      "n": "Length",
      "d": 2097163,
      "h": 55836672011,
      "f": 4194312,
      "a": [
        {
          "t": 141557761,
          "c": 8731492353,
          "a": [
            {
              "v": 8,
              "t": 655361
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(55836672011),
//--TRIMMABLE-BOUNDARY-START(64426606603),
    {
      "t": 3670027,
      "n": "Type",
      "d": 2097163,
      "h": 64426606603,
      "f": 4194312,
      "a": [
        {
          "t": 141557761,
          "c": 8731492353,
          "a": [
            {
              "v": 12,
              "t": 655361
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(64426606603),
//--TRIMMABLE-BOUNDARY-START(25771900939),
    {
      "t": 3670027,
      "n": "ElementType",
      "d": 2097163,
      "h": 25771900939,
      "f": 4194312,
      "a": [
        {
          "t": 141557761,
          "c": 8731492353,
          "a": [
            {
              "v": 13,
              "t": 655361
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(25771900939)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4297064459),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 2097163,
      "h": 4297064459,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4297064459)
  ],
  "d": 1310731,
  "h": 2097163,
  "a": [
    {
      "t": 147390465,
      "c": 13032292353,
      "a": [
        {
          "v": 2,
          "t": 142868481
        }
      ],
      "n": [
        {
          "n": "Pack",
          "v": 32,
          "t": 655361
        },
        {
          "n": "Size",
          "v": 32,
          "t": 655361
        }
      ]
    }
  ]
}; }
                    static get $b() { return $.$$.System.ValueType; }
                    static get $fullName() { return `System.Runtime.InteropServices.JavaScript.JSMarshalerArgument.JSMarshalerArgumentImpl`; }
                }, $cls, ($v) => $cls.$_JSMarshalerArgumentImpl = $v);
            }
            //--TRIMMABLE-BOUNDARY-END(2097163)
            
            //--TRIMMABLE-BOUNDARY-START(94490591243)
            /*void */ Initialize()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(94490591243);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.slot.Type = 0/*MarshalerType.None*/;
            }
            //--TRIMMABLE-BOUNDARY-END(94490591243)
            
            //--TRIMMABLE-BOUNDARY-START(562642026507)
            /*JSProxyContext */ get ToManagedContext()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(81605689355);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$srij.System.Runtime.InteropServices.JavaScript.JSProxyContext.MainThreadContext;
            }
            //--TRIMMABLE-BOUNDARY-END(562642026507)
            
            //--TRIMMABLE-BOUNDARY-START(335008759819)
            /*JSProxyContext */ get ToJSContext()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(73015754763);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$srij.System.Runtime.InteropServices.JavaScript.JSProxyContext.MainThreadContext;
            }
            //--TRIMMABLE-BOUNDARY-END(335008759819)
            
            //--TRIMMABLE-BOUNDARY-START(60130852875)
            /*JSProxyContext */ AssertCurrentThreadContext()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(60130852875);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$srij.System.Runtime.InteropServices.JavaScript.JSProxyContext.MainThreadContext;
            }
            //--TRIMMABLE-BOUNDARY-END(60130852875)
            
            //--TRIMMABLE-BOUNDARY-START(399433269259)
            /*void */ ToManaged$13(/*out short*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(399433269259);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (this.slot.Type === 0/*MarshalerType.None*/)
                {
                    value.$v = 0;
                    return;
                }
                value.$v = this.slot.Int16Value;
            }
            //--TRIMMABLE-BOUNDARY-END(399433269259)
            
            //--TRIMMABLE-BOUNDARY-START(171800002571)
            /*void */ ToJS$13(/*short*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(171800002571);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.slot.Type = 6/*MarshalerType.Int16*/;
                this.slot.Int16Value = value;
            }
            //--TRIMMABLE-BOUNDARY-END(171800002571)
            
            //--TRIMMABLE-BOUNDARY-START(446677909515)
            /*void */ ToManaged$24(/*out short?*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(446677909515);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (this.slot.Type === 0/*MarshalerType.None*/)
                {
                    value.$v = null;
                    return;
                }
                value.$v = this.slot.Int16Value;
            }
            //--TRIMMABLE-BOUNDARY-END(446677909515)
            
            //--TRIMMABLE-BOUNDARY-START(219044642827)
            /*void */ ToJS$24(/*short?*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(219044642827);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$$.System.Nullable$$($.$$.System.Int16).HasValue$get.call(value))
                {
                    this.slot.Type = 6/*MarshalerType.Int16*/;
                    this.slot.Int16Value = $.$$.System.Nullable$$($.$$.System.Int16).Value$get.call(value);
                }
                else 
                {
                    this.slot.Type = 0/*MarshalerType.None*/;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(219044642827)
            
            //--TRIMMABLE-BOUNDARY-START(386548367371)
            /*void */ ToManaged$10(/*out double*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(386548367371);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (this.slot.Type === 0/*MarshalerType.None*/)
                {
                    value.$v = 0;
                    return;
                }
                value.$v = this.slot.DoubleValue;
            }
            //--TRIMMABLE-BOUNDARY-END(386548367371)
            
            //--TRIMMABLE-BOUNDARY-START(158915100683)
            /*void */ ToJS$10(/*double*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(158915100683);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.slot.Type = 10/*MarshalerType.Double*/;
                this.slot.DoubleValue = value;
            }
            //--TRIMMABLE-BOUNDARY-END(158915100683)
            
            //--TRIMMABLE-BOUNDARY-START(442382942219)
            /*void */ ToManaged$23(/*out double?*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(442382942219);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (this.slot.Type === 0/*MarshalerType.None*/)
                {
                    value.$v = null;
                    return;
                }
                value.$v = this.slot.DoubleValue;
            }
            //--TRIMMABLE-BOUNDARY-END(442382942219)
            
            //--TRIMMABLE-BOUNDARY-START(214749675531)
            /*void */ ToJS$23(/*double?*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(214749675531);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$$.System.Nullable$$($.$$.System.Double).HasValue$get.call(value))
                {
                    this.slot.Type = 10/*MarshalerType.Double*/;
                    this.slot.DoubleValue = $.$$.System.Nullable$$($.$$.System.Double).Value$get.call(value);
                }
                else 
                {
                    this.slot.Type = 0/*MarshalerType.None*/;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(214749675531)
            
            //--TRIMMABLE-BOUNDARY-START(390843334667)
            /*void */ ToManaged$11(/*out double[]?*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(390843334667);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (this.slot.Type === 0/*MarshalerType.None*/)
                {
                    value.$v = null;
                    return;
                }
                value.$v = $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$$.System.Double), null, [this.slot.Length], null);
                $.$$.System.Runtime.InteropServices.Marshal.Copy$8(this.slot.IntPtrValue, value.$v, 0, this.slot.Length);
                $.$$.System.Runtime.InteropServices.Marshal.FreeHGlobal(this.slot.IntPtrValue);
            }
            //--TRIMMABLE-BOUNDARY-END(390843334667)
            
            //--TRIMMABLE-BOUNDARY-START(163210067979)
            /*void */ ToJS$11(/*double[]*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(163210067979);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (value === null)
                {
                    this.slot.Type = 0/*MarshalerType.None*/;
                    return;
                }
                this.slot.Type = 21/*MarshalerType.Array*/;
                this.slot.IntPtrValue = $.$$.System.Runtime.InteropServices.Marshal.AllocHGlobal(((value.length * $.$$.System.Double.$z) | 0));
                this.slot.Length = value.length;
                this.slot.ElementType = 10/*MarshalerType.Double*/;
                $.$$.System.Runtime.InteropServices.Marshal.Copy$2(value, 0, this.slot.IntPtrValue, this.slot.Length);
            }
            //--TRIMMABLE-BOUNDARY-END(163210067979)
            
            //--TRIMMABLE-BOUNDARY-START(352188629003)
            /*void */ ToManaged$2(/*out ArraySegment<double>*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(352188629003);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let array = $.$cast(($.$$.System.Runtime.InteropServices.GCHandle.op_Explicit$1(this.slot.GCHandle)).Target, $.$typeArray($.$$.System.Double));
                /*var*/ let refPtr = $.$$.System.IntPtr.op_Explicit$4($.$$.System.Runtime.CompilerServices.Unsafe.AsPointer($.$$.System.Double, $.$$.System.Runtime.InteropServices.MemoryMarshal.GetArrayDataReference$1($.$$.System.Double, array)));
                /*int*/ let byteOffset = (this.slot.IntPtrValue - refPtr);
                value.$v = new ($.$$.System.ArraySegment$$($.$$.System.Double))().$ctor$3(array, $.trunc(byteOffset / $.$$.System.Double.$z), this.slot.Length);
            }
            //--TRIMMABLE-BOUNDARY-END(352188629003)
            
            //--TRIMMABLE-BOUNDARY-START(124555362315)
            /*void */ ToJS$2(/*ArraySegment<double>*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(124555362315);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (value.Array === null)
                {
                    this.slot.Type = 0/*MarshalerType.None*/;
                    return;
                }
                this.slot.Type = 22/*MarshalerType.ArraySegment*/;
                /*var*/ let ctx = this.ToJSContext;
                this.slot.GCHandle = ctx.GetJSOwnedObjectGCHandle(value.Array, 3/*GCHandleType.Pinned*/);
                /*var*/ let refPtr = $.$$.System.IntPtr.op_Explicit$4($.$$.System.Runtime.CompilerServices.Unsafe.AsPointer($.$$.System.Double, $.$$.System.Runtime.InteropServices.MemoryMarshal.GetArrayDataReference$1($.$$.System.Double, value.Array)));
                this.slot.IntPtrValue = refPtr + (((value.Offset * $.$$.System.Double.$z) | 0));
                this.slot.Length = value.Count;
            }
            //--TRIMMABLE-BOUNDARY-END(124555362315)
            
            //--TRIMMABLE-BOUNDARY-START(485332615179)
            /*void */ ToManaged$33(/*out Span<double>*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(485332615179);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                value.$v = new ($.$$.System.Span$$($.$$.System.Double))().$ctor$5($.$$.System.IntPtr.op_Explicit$5(this.slot.IntPtrValue), this.slot.Length);
            }
            //--TRIMMABLE-BOUNDARY-END(485332615179)
            
            //--TRIMMABLE-BOUNDARY-START(257699348491)
            /*void */ ToJS$33(/*Span<double>*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(257699348491);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.slot.Length = value.Length;
                this.slot.IntPtrValue = $.$$.System.IntPtr.op_Explicit$4($.$$.System.Runtime.CompilerServices.Unsafe.AsPointer($.$$.System.Double, value.GetPinnableReference()));
                this.slot.Type = 23/*MarshalerType.Span*/;
            }
            //--TRIMMABLE-BOUNDARY-END(257699348491)
            
            //--TRIMMABLE-BOUNDARY-START(360778563595)
            /*void */ ToManaged$4(/*out bool*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(360778563595);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (this.slot.Type === 0/*MarshalerType.None*/)
                {
                    value.$v = false;
                    return;
                }
                value.$v = this.slot.BooleanValue;
            }
            //--TRIMMABLE-BOUNDARY-END(360778563595)
            
            //--TRIMMABLE-BOUNDARY-START(133145296907)
            /*void */ ToJS$4(/*bool*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(133145296907);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.slot.Type = 3/*MarshalerType.Boolean*/;
                this.slot.BooleanValue = value;
            }
            //--TRIMMABLE-BOUNDARY-END(133145296907)
            
            //--TRIMMABLE-BOUNDARY-START(420908105739)
            /*void */ ToManaged$18(/*out bool?*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(420908105739);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (this.slot.Type === 0/*MarshalerType.None*/)
                {
                    value.$v = null;
                    return;
                }
                value.$v = this.slot.BooleanValue;
            }
            //--TRIMMABLE-BOUNDARY-END(420908105739)
            
            //--TRIMMABLE-BOUNDARY-START(193274839051)
            /*void */ ToJS$18(/*bool?*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(193274839051);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$$.System.Nullable$$($.$$.System.Boolean).HasValue$get.call(value))
                {
                    this.slot.Type = 3/*MarshalerType.Boolean*/;
                    this.slot.BooleanValue = $.$$.System.Nullable$$($.$$.System.Boolean).Value$get.call(value);
                }
                else 
                {
                    this.slot.Type = 0/*MarshalerType.None*/;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(193274839051)
            
            //--TRIMMABLE-BOUNDARY-START(416613138443)
            /*void */ ToManaged$17(/*out IntPtr*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(416613138443);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (this.slot.Type === 0/*MarshalerType.None*/)
                {
                    value.$v = 0;
                    return;
                }
                value.$v = this.slot.IntPtrValue;
            }
            //--TRIMMABLE-BOUNDARY-END(416613138443)
            
            //--TRIMMABLE-BOUNDARY-START(188979871755)
            /*void */ ToJS$17(/*IntPtr*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(188979871755);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.slot.Type = 12/*MarshalerType.IntPtr*/;
                this.slot.IntPtrValue = value;
            }
            //--TRIMMABLE-BOUNDARY-END(188979871755)
            
            //--TRIMMABLE-BOUNDARY-START(459562811403)
            /*void */ ToManaged$27(/*out IntPtr?*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(459562811403);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (this.slot.Type === 0/*MarshalerType.None*/)
                {
                    value.$v = null;
                    return;
                }
                value.$v = this.slot.IntPtrValue;
            }
            //--TRIMMABLE-BOUNDARY-END(459562811403)
            
            //--TRIMMABLE-BOUNDARY-START(231929544715)
            /*void */ ToJS$27(/*IntPtr?*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(231929544715);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$$.System.Nullable$$($.$$.System.IntPtr).HasValue$get.call(value))
                {
                    this.slot.Type = 12/*MarshalerType.IntPtr*/;
                    this.slot.IntPtrValue = $.$$.System.Nullable$$($.$$.System.IntPtr).Value$get.call(value);
                }
                else 
                {
                    this.slot.Type = 0/*MarshalerType.None*/;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(231929544715)
            
            //--TRIMMABLE-BOUNDARY-START(506807451659)
            /*void */ ToManaged$38(/*out void**/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(506807451659);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (this.slot.Type === 0/*MarshalerType.None*/)
                {
                    value.$v = new $.$typePointer($.$$.System.Void)();
                    return;
                }
                value.$v = $.$cast(this.slot.IntPtrValue, $.$typePointer($.$$.System.Byte));
            }
            //--TRIMMABLE-BOUNDARY-END(506807451659)
            
            //--TRIMMABLE-BOUNDARY-START(279174184971)
            /*void */ ToJS$38(/*void**/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(279174184971);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.slot.Type = 12/*MarshalerType.IntPtr*/;
                this.slot.IntPtrValue = $.$$.System.IntPtr.op_Explicit$4(value);
            }
            //--TRIMMABLE-BOUNDARY-END(279174184971)
            
            //--TRIMMABLE-BOUNDARY-START(493922549771)
            /*void */ ToManaged$35(/*out string?*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(493922549771);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (this.slot.Type === 0/*MarshalerType.None*/)
                {
                    value.$v = null;
                    return;
                }
                /*fixed*/ 
                {
                    /*void**/ let argAsRoot = $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateObjectReferenceT($.$$.System.IntPtr, () => this.slot.IntPtrValue, ($v) => this.slot.IntPtrValue = $v, null);
                    value.$v = $.$$.System.Runtime.CompilerServices.Unsafe.AsRef($.$$.System.String, argAsRoot).$v;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(493922549771)
            
            //--TRIMMABLE-BOUNDARY-START(266289283083)
            /*void */ ToJS$35(/*string?*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(266289283083);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$$.System.String.op_Equality(value, null))
                {
                    this.slot.Type = 0/*MarshalerType.None*/;
                }
                else 
                {
                    this.slot.Type = 15/*MarshalerType.String*/;
                    /*fixed*/ 
                    {
                        /*IntPtr**/ let argAsRoot = $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateObjectReferenceT($.$$.System.IntPtr, () => this.slot.IntPtrValue, ($v) => this.slot.IntPtrValue = $v, null);
                        /*string*/ let cpy = value;
                        /*var*/ let currentRoot = $.$cast($.$$.System.Runtime.CompilerServices.Unsafe.AsPointer($.$$.System.String, $.$ref(() => cpy, ($v) => cpy = $v, $.$$.System.String)), $.$typePointer($.$$.System.IntPtr));
                        argAsRoot.SetAt(currentRoot.GetAt(0), 0);
                    }
                }
            }
            //--TRIMMABLE-BOUNDARY-END(266289283083)
            
            //--TRIMMABLE-BOUNDARY-START(498217517067)
            /*void */ ToManaged$36(/*out string?[]?*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(498217517067);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (this.slot.Type === 0/*MarshalerType.None*/)
                {
                    value.$v = null;
                    return;
                }
                value.$v = $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$$.System.String), null, [this.slot.Length], null);
                /*JSMarshalerArgument**/ let payload = $.$cast(this.slot.IntPtrValue, $.$typePointer($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument));
                for(/*int*/ let i = 0; i < this.slot.Length; i++)
                {
                    /*ref JSMarshalerArgument*/ let arg = payload.Add(i);
                    /*string?*/ let val;
                    arg.$v.ToManaged$35($.$ref(() => val, ($v) => val = $v, $.$$.System.String));
                    $.$$.System.Array.$WriteT1.call(value.$v, val, i);
                }
                $.$srij.Interop.Runtime.DeregisterGCRoot(this.slot.IntPtrValue);
                $.$$.System.Runtime.InteropServices.Marshal.FreeHGlobal(this.slot.IntPtrValue);
            }
            //--TRIMMABLE-BOUNDARY-END(498217517067)
            
            //--TRIMMABLE-BOUNDARY-START(270584250379)
            /*void */ ToJS$36(/*string?[]*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(270584250379);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (value === null)
                {
                    this.slot.Type = 0/*MarshalerType.None*/;
                    return;
                }
                this.slot.Length = value.length;
                /*int*/ let bytes = ((value.length * $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument.$z) | 0);
                this.slot.Type = 21/*MarshalerType.Array*/;
                /*JSMarshalerArgument**/ let payload = $.$cast($.$$.System.Runtime.InteropServices.Marshal.AllocHGlobal(bytes), $.$typePointer($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument));
                $.$$.System.Runtime.CompilerServices.Unsafe.InitBlock(payload, 0, (bytes >>> 0));
                $.$srij.Interop.Runtime.RegisterGCRoot(payload, bytes, $.$$.System.IntPtr.Zero);
                for(/*int*/ let i = 0; i < this.slot.Length; i++)
                {
                    /*ref JSMarshalerArgument*/ let arg = payload.Add(i);
                    /*string?*/ let val = $.$$.System.Array.$ReadT1.call(value, i);
                    arg.$v.ToJS$35(val);
                    $.$$.System.Array.$WriteT1.call(value, val, i);
                }
                this.slot.IntPtrValue = $.$cast(payload, $.$$.System.IntPtr);
                this.slot.ElementType = 15/*MarshalerType.String*/;
            }
            //--TRIMMABLE-BOUNDARY-END(270584250379)
            
            //--TRIMMABLE-BOUNDARY-START(511102418955)
            /*void */ ToManaged$39(/*out JSObject?*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(511102418955);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (this.slot.Type === 0/*MarshalerType.None*/)
                {
                    value.$v = null;
                    return;
                }
                /*var*/ let ctx = this.ToManagedContext;
                value.$v = ctx.CreateCSOwnedProxy(this.slot.JSHandle);
            }
            //--TRIMMABLE-BOUNDARY-END(511102418955)
            
            //--TRIMMABLE-BOUNDARY-START(283469152267)
            /*void */ ToJS$39(/*JSObject?*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(283469152267);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (value === null)
                {
                    this.slot.Type = 0/*MarshalerType.None*/;
                }
                else 
                {
                    value.AssertNotDisposed();
                    this.slot.Type = 13/*MarshalerType.JSObject*/;
                    this.slot.JSHandle = value.JSHandle;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(283469152267)
            
            //--TRIMMABLE-BOUNDARY-START(515397386251)
            /*void */ ToManaged$40(/*out JSObject?[]?*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(515397386251);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (this.slot.Type === 0/*MarshalerType.None*/)
                {
                    value.$v = null;
                    return;
                }
                value.$v = $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$srij.System.Runtime.InteropServices.JavaScript.JSObject), null, [this.slot.Length], null);
                /*JSMarshalerArgument**/ let payload = $.$cast(this.slot.IntPtrValue, $.$typePointer($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument));
                for(/*int*/ let i = 0; i < this.slot.Length; i++)
                {
                    /*ref JSMarshalerArgument*/ let arg = payload.Add(i);
                    /*JSObject?*/ let val;
                    arg.$v.ToManaged$39($.$ref(() => val, ($v) => val = $v, $.$srij.System.Runtime.InteropServices.JavaScript.JSObject));
                    $.$$.System.Array.$WriteT1.call(value.$v, val, i);
                }
                $.$$.System.Runtime.InteropServices.Marshal.FreeHGlobal(this.slot.IntPtrValue);
            }
            //--TRIMMABLE-BOUNDARY-END(515397386251)
            
            //--TRIMMABLE-BOUNDARY-START(287764119563)
            /*void */ ToJS$40(/*JSObject?[]*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(287764119563);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (value === null)
                {
                    this.slot.Type = 0/*MarshalerType.None*/;
                    return;
                }
                this.slot.Length = value.length;
                /*int*/ let bytes = ((value.length * $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument.$z) | 0);
                this.slot.Type = 21/*MarshalerType.Array*/;
                this.slot.ElementType = 13/*MarshalerType.JSObject*/;
                /*JSMarshalerArgument**/ let payload = $.$cast($.$$.System.Runtime.InteropServices.Marshal.AllocHGlobal(bytes), $.$typePointer($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument));
                $.$$.System.Runtime.CompilerServices.Unsafe.InitBlock(payload, 0, (bytes >>> 0));
                for(/*int*/ let i = 0; i < this.slot.Length; i++)
                {
                    /*ref JSMarshalerArgument*/ let arg = payload.Add(i);
                    /*JSObject?*/ let val = $.$$.System.Array.$ReadT1.call(value, i);
                    arg.$v.ToJS$39(val);
                    $.$$.System.Array.$WriteT1.call(value, val, i);
                }
                this.slot.IntPtrValue = $.$cast(payload, $.$$.System.IntPtr);
            }
            //--TRIMMABLE-BOUNDARY-END(287764119563)
            
            //--TRIMMABLE-BOUNDARY-START(365073530891)
            /*void */ ToManaged$5(/*out byte*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(365073530891);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (this.slot.Type === 0/*MarshalerType.None*/)
                {
                    value.$v = 0;
                    return;
                }
                value.$v = this.slot.ByteValue;
            }
            //--TRIMMABLE-BOUNDARY-END(365073530891)
            
            //--TRIMMABLE-BOUNDARY-START(137440264203)
            /*void */ ToJS$5(/*byte*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(137440264203);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.slot.Type = 4/*MarshalerType.Byte*/;
                this.slot.ByteValue = value;
            }
            //--TRIMMABLE-BOUNDARY-END(137440264203)
            
            //--TRIMMABLE-BOUNDARY-START(425203073035)
            /*void */ ToManaged$19(/*out byte?*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(425203073035);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (this.slot.Type === 0/*MarshalerType.None*/)
                {
                    value.$v = null;
                    return;
                }
                value.$v = this.slot.ByteValue;
            }
            //--TRIMMABLE-BOUNDARY-END(425203073035)
            
            //--TRIMMABLE-BOUNDARY-START(197569806347)
            /*void */ ToJS$19(/*byte?*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(197569806347);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$$.System.Nullable$$($.$$.System.Byte).HasValue$get.call(value))
                {
                    this.slot.Type = 4/*MarshalerType.Byte*/;
                    this.slot.ByteValue = $.$$.System.Nullable$$($.$$.System.Byte).Value$get.call(value);
                }
                else 
                {
                    this.slot.Type = 0/*MarshalerType.None*/;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(197569806347)
            
            //--TRIMMABLE-BOUNDARY-START(369368498187)
            /*void */ ToManaged$6(/*out byte[]?*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(369368498187);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (this.slot.Type === 0/*MarshalerType.None*/)
                {
                    value.$v = null;
                    return;
                }
                value.$v = $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$$.System.Byte), null, [this.slot.Length], null);
                $.$$.System.Runtime.InteropServices.Marshal.Copy$6(this.slot.IntPtrValue, value.$v, 0, this.slot.Length);
                $.$$.System.Runtime.InteropServices.Marshal.FreeHGlobal(this.slot.IntPtrValue);
            }
            //--TRIMMABLE-BOUNDARY-END(369368498187)
            
            //--TRIMMABLE-BOUNDARY-START(141735231499)
            /*void */ ToJS$6(/*byte[]?*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(141735231499);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (value === null)
                {
                    this.slot.Type = 0/*MarshalerType.None*/;
                    return;
                }
                this.slot.Length = value.length;
                this.slot.Type = 21/*MarshalerType.Array*/;
                this.slot.IntPtrValue = $.$$.System.Runtime.InteropServices.Marshal.AllocHGlobal(((value.length * $.$$.System.Byte.$z) | 0));
                this.slot.ElementType = 4/*MarshalerType.Byte*/;
                $.$$.System.Runtime.InteropServices.Marshal.Copy(value, 0, this.slot.IntPtrValue, this.slot.Length);
            }
            //--TRIMMABLE-BOUNDARY-END(141735231499)
            
            //--TRIMMABLE-BOUNDARY-START(347893661707)
            /*void */ ToManaged$1(/*out ArraySegment<byte>*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(347893661707);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let array = $.$cast(($.$$.System.Runtime.InteropServices.GCHandle.op_Explicit$1(this.slot.GCHandle)).Target, $.$typeArray($.$$.System.Byte));
                /*var*/ let refPtr = $.$$.System.IntPtr.op_Explicit$4($.$$.System.Runtime.CompilerServices.Unsafe.AsPointer($.$$.System.Byte, $.$$.System.Runtime.InteropServices.MemoryMarshal.GetArrayDataReference$1($.$$.System.Byte, array)));
                /*int*/ let byteOffset = (this.slot.IntPtrValue - refPtr);
                value.$v = new ($.$$.System.ArraySegment$$($.$$.System.Byte))().$ctor$3(array, byteOffset, this.slot.Length);
            }
            //--TRIMMABLE-BOUNDARY-END(347893661707)
            
            //--TRIMMABLE-BOUNDARY-START(120260395019)
            /*void */ ToJS$1(/*ArraySegment<byte>*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(120260395019);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (value.Array === null)
                {
                    this.slot.Type = 0/*MarshalerType.None*/;
                    return;
                }
                this.slot.Type = 22/*MarshalerType.ArraySegment*/;
                /*var*/ let ctx = this.ToJSContext;
                this.slot.GCHandle = ctx.GetJSOwnedObjectGCHandle(value.Array, 3/*GCHandleType.Pinned*/);
                /*var*/ let refPtr = $.$$.System.IntPtr.op_Explicit$4($.$$.System.Runtime.CompilerServices.Unsafe.AsPointer($.$$.System.Byte, $.$$.System.Runtime.InteropServices.MemoryMarshal.GetArrayDataReference$1($.$$.System.Byte, value.Array)));
                this.slot.IntPtrValue = refPtr + value.Offset;
                this.slot.Length = value.Count;
            }
            //--TRIMMABLE-BOUNDARY-END(120260395019)
            
            //--TRIMMABLE-BOUNDARY-START(481037647883)
            /*void */ ToManaged$32(/*out Span<byte>*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(481037647883);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                value.$v = new ($.$$.System.Span$$($.$$.System.Byte))().$ctor$5($.$$.System.IntPtr.op_Explicit$5(this.slot.IntPtrValue), this.slot.Length);
            }
            //--TRIMMABLE-BOUNDARY-END(481037647883)
            
            //--TRIMMABLE-BOUNDARY-START(253404381195)
            /*void */ ToJS$32(/*Span<byte>*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(253404381195);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.slot.Length = value.Length;
                this.slot.IntPtrValue = $.$$.System.IntPtr.op_Explicit$4($.$$.System.Runtime.CompilerServices.Unsafe.AsPointer($.$$.System.Byte, value.GetPinnableReference()));
                this.slot.Type = 23/*MarshalerType.Span*/;
            }
            //--TRIMMABLE-BOUNDARY-END(253404381195)
            
            //--TRIMMABLE-BOUNDARY-START(395138301963)
            /*void */ ToManaged$12(/*out Exception?*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(395138301963);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (this.slot.Type === 0/*MarshalerType.None*/)
                {
                    value.$v = null;
                    return;
                }
                if (this.slot.Type === 16/*MarshalerType.Exception*/)
                {
                    value.$v = $.$cast(($.$$.System.Runtime.InteropServices.GCHandle.op_Explicit$1(this.slot.GCHandle)).Target, $.$$.System.Exception);
                    return;
                }
                /*JSObject?*/ let jsException = null;
                if (this.slot.JSHandle !== $.$$.System.IntPtr.Zero)
                {
                    /*var*/ let ctx = this.ToManagedContext;
                    jsException = ctx.CreateCSOwnedProxy(this.slot.JSHandle);
                }
                /*string?*/ let message;
                this.ToManaged$35($.$ref(() => message, ($v) => message = $v, $.$$.System.String));
                value.$v = new $.$srij.System.Runtime.InteropServices.JavaScript.JSException().$ctor$5(message, jsException);
            }
            //--TRIMMABLE-BOUNDARY-END(395138301963)
            
            //--TRIMMABLE-BOUNDARY-START(167505035275)
            /*void */ ToJS$12(/*Exception?*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(167505035275);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (value === null)
                {
                    this.slot.Type = 0/*MarshalerType.None*/;
                }
                else 
                {
                    /*Exception*/ let cpy = value;
                    let ae;
                    if ($.$is(cpy, $.$$.System.AggregateException, { set $v(v){ ae = v; } }) && ae.InnerExceptions.Count === 1)
                    {
                        cpy = ae.InnerExceptions.get_Item(0);
                    }
                    /*var*/ let jse = $.$as(cpy, $.$srij.System.Runtime.InteropServices.JavaScript.JSException);
                    if (jse !== null && jse.jsException !== null)
                    {
                        /*var*/ let jsException = jse.jsException;
                        jsException.AssertNotDisposed();
                        this.slot.Type = 27/*MarshalerType.JSException*/;
                        this.slot.JSHandle = jsException.JSHandle;
                    }
                    else 
                    {
                        this.ToJS$35(cpy.Message);
                        this.slot.Type = 16/*MarshalerType.Exception*/;
                        /*var*/ let ctx = this.ToJSContext;
                        this.slot.GCHandle = ctx.GetJSOwnedObjectGCHandle(cpy, 2);
                    }
                }
            }
            //--TRIMMABLE-BOUNDARY-END(167505035275)
            
            //--TRIMMABLE-BOUNDARY-START(403728236555)
            /*void */ ToManaged$14(/*out int*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(403728236555);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (this.slot.Type === 0/*MarshalerType.None*/)
                {
                    value.$v = 0;
                    return;
                }
                value.$v = this.slot.Int32Value;
            }
            //--TRIMMABLE-BOUNDARY-END(403728236555)
            
            //--TRIMMABLE-BOUNDARY-START(176094969867)
            /*void */ ToJS$14(/*int*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(176094969867);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.slot.Type = 7/*MarshalerType.Int32*/;
                this.slot.Int32Value = value;
            }
            //--TRIMMABLE-BOUNDARY-END(176094969867)
            
            //--TRIMMABLE-BOUNDARY-START(450972876811)
            /*void */ ToManaged$25(/*out int?*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(450972876811);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (this.slot.Type === 0/*MarshalerType.None*/)
                {
                    value.$v = null;
                    return;
                }
                value.$v = this.slot.Int32Value;
            }
            //--TRIMMABLE-BOUNDARY-END(450972876811)
            
            //--TRIMMABLE-BOUNDARY-START(223339610123)
            /*void */ ToJS$25(/*int?*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(223339610123);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$$.System.Nullable$$($.$$.System.Int32).HasValue$get.call(value))
                {
                    this.slot.Type = 7/*MarshalerType.Int32*/;
                    this.slot.Int32Value = $.$$.System.Nullable$$($.$$.System.Int32).Value$get.call(value);
                }
                else 
                {
                    this.slot.Type = 0/*MarshalerType.None*/;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(223339610123)
            
            //--TRIMMABLE-BOUNDARY-START(408023203851)
            /*void */ ToManaged$15(/*out int[]?*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(408023203851);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (this.slot.Type === 0/*MarshalerType.None*/)
                {
                    value.$v = null;
                    return;
                }
                value.$v = $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$$.System.Int32), null, [this.slot.Length], null);
                $.$$.System.Runtime.InteropServices.Marshal.Copy$10(this.slot.IntPtrValue, value.$v, 0, this.slot.Length);
                $.$$.System.Runtime.InteropServices.Marshal.FreeHGlobal(this.slot.IntPtrValue);
            }
            //--TRIMMABLE-BOUNDARY-END(408023203851)
            
            //--TRIMMABLE-BOUNDARY-START(180389937163)
            /*void */ ToJS$15(/*int[]?*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(180389937163);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (value === null)
                {
                    this.slot.Type = 0/*MarshalerType.None*/;
                    return;
                }
                this.slot.Type = 21/*MarshalerType.Array*/;
                this.slot.IntPtrValue = $.$$.System.Runtime.InteropServices.Marshal.AllocHGlobal(((value.length * $.$$.System.Int32.$z) | 0));
                this.slot.Length = value.length;
                this.slot.ElementType = 7/*MarshalerType.Int32*/;
                $.$$.System.Runtime.InteropServices.Marshal.Copy$4(value, 0, this.slot.IntPtrValue, this.slot.Length);
            }
            //--TRIMMABLE-BOUNDARY-END(180389937163)
            
            //--TRIMMABLE-BOUNDARY-START(356483596299)
            /*void */ ToManaged$3(/*out ArraySegment<int>*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(356483596299);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let array = $.$cast(($.$$.System.Runtime.InteropServices.GCHandle.op_Explicit$1(this.slot.GCHandle)).Target, $.$typeArray($.$$.System.Int32));
                /*var*/ let refPtr = $.$$.System.IntPtr.op_Explicit$4($.$$.System.Runtime.CompilerServices.Unsafe.AsPointer($.$$.System.Int32, $.$$.System.Runtime.InteropServices.MemoryMarshal.GetArrayDataReference$1($.$$.System.Int32, array)));
                /*int*/ let byteOffset = (this.slot.IntPtrValue - refPtr);
                value.$v = new ($.$$.System.ArraySegment$$($.$$.System.Int32))().$ctor$3(array, $.trunc(byteOffset / $.$$.System.Int32.$z), this.slot.Length);
            }
            //--TRIMMABLE-BOUNDARY-END(356483596299)
            
            //--TRIMMABLE-BOUNDARY-START(128850329611)
            /*void */ ToJS$3(/*ArraySegment<int>*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(128850329611);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (value.Array === null)
                {
                    this.slot.Type = 0/*MarshalerType.None*/;
                    return;
                }
                /*var*/ let ctx = this.ToJSContext;
                this.slot.Type = 22/*MarshalerType.ArraySegment*/;
                this.slot.GCHandle = ctx.GetJSOwnedObjectGCHandle(value.Array, 3/*GCHandleType.Pinned*/);
                /*var*/ let refPtr = $.$$.System.IntPtr.op_Explicit$4($.$$.System.Runtime.CompilerServices.Unsafe.AsPointer($.$$.System.Int32, $.$$.System.Runtime.InteropServices.MemoryMarshal.GetArrayDataReference$1($.$$.System.Int32, value.Array)));
                this.slot.IntPtrValue = refPtr + (((value.Offset * $.$$.System.Int32.$z) | 0));
                this.slot.Length = value.Count;
            }
            //--TRIMMABLE-BOUNDARY-END(128850329611)
            
            //--TRIMMABLE-BOUNDARY-START(489627582475)
            /*void */ ToManaged$34(/*out Span<int>*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(489627582475);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                value.$v = new ($.$$.System.Span$$($.$$.System.Int32))().$ctor$5($.$$.System.IntPtr.op_Explicit$5(this.slot.IntPtrValue), this.slot.Length);
            }
            //--TRIMMABLE-BOUNDARY-END(489627582475)
            
            //--TRIMMABLE-BOUNDARY-START(261994315787)
            /*void */ ToJS$34(/*Span<int>*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(261994315787);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.slot.Length = value.Length;
                this.slot.IntPtrValue = $.$$.System.IntPtr.op_Explicit$4($.$$.System.Runtime.CompilerServices.Unsafe.AsPointer($.$$.System.Int32, value.GetPinnableReference()));
                this.slot.Type = 23/*MarshalerType.Span*/;
            }
            //--TRIMMABLE-BOUNDARY-END(261994315787)
            
            //--TRIMMABLE-BOUNDARY-START(1703947)
            static $_ArgumentToManagedCallback$$;
            static ArgumentToManagedCallback$$(T)
            {
                let $cls = $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument;
                return ($cls.$_ArgumentToManagedCallback$$ ??= $asm.$ncls("$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument.ArgumentToManagedCallback<>", (T) => $asm.$gt("$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument.ArgumentToManagedCallback<>", [T], ($self) => class ArgumentToManagedCallback$$ extends $.$$.System.MulticastDelegate
                {
                    $ctor(/*object*/ target, fn, anmodel)
                    {
                        this.$target = target;
                        this.$nativeFunction = fn;
                        if (anmodel) this.$nfmodel = anmodel;
                        if (typeof(target) === 'object') this._target = target;
                        return this;
                    }
                    /*void*/ Invoke(/**/ arg, /**/ value)
                    {
                        return this.$nativeFunction.call(this.$target, arg, value);
                    }
                    static $h = 1703947;
                    static $g = 1;
                    static $f = 0b10000000011000001;
                    static $k = 5;
                    static $$md;
                    static get $md() { return this.$$md ??= {
  "b": 98959361,
  "m": [
//--TRIMMABLE-BOUNDARY-START(17181573131),
    {
      "r": 65537,
      "p": [
        {
          "n": "arg",
          "p": 1310731,
          "f": 4
        },
        {
          "n": "value",
          "p": T?.$h??1507328,
          "f": 2
        }
      ],
      "n": "Invoke",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x400000000n),
      "f": 16777345
    },
//--TRIMMABLE-BOUNDARY-END(17181573131),
//--TRIMMABLE-BOUNDARY-START(8591638539),
    {
      "r": 89784321,
      "p": [
        {
          "n": "arg",
          "p": 1310731,
          "f": 4
        },
        {
          "n": "value",
          "p": T?.$h??1507328,
          "f": 2
        },
        {
          "n": "callback",
          "p": 45285377
        },
        {
          "n": "object",
          "p": 131073
        }
      ],
      "n": "BeginInvoke",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x200000000n),
      "f": 16777345
    },
//--TRIMMABLE-BOUNDARY-END(8591638539),
//--TRIMMABLE-BOUNDARY-START(12886605835),
    {
      "r": 65537,
      "p": [
        {
          "n": "arg",
          "p": 1310731,
          "f": 4
        },
        {
          "n": "value",
          "p": T?.$h??1507328,
          "f": 2
        },
        {
          "n": "result",
          "p": 89784321
        }
      ],
      "n": "EndInvoke",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x300000000n),
      "f": 16777345
    },
//--TRIMMABLE-BOUNDARY-END(12886605835)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296671243),
    {
      "p": [
        {
          "n": "object",
          "p": 131073
        },
        {
          "n": "method",
          "p": 786433
        }
      ],
      "n": ".ctor",
      "o": "$ctor$5",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x100000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296671243)
  ],
  "i": [89980929,157483009
  ],
  "g": [T?.$h??1507328
  ],
  "r": 1,
  "d": 1310731,
  "h": this.$h,
  "a": [
    {
      "t": 64290817,
      "c": 12949192705,
      "a": [
        {
          "v": 1,
          "t": 64356353
        }
      ]
    }
  ]
}; }
                    static get $b() { return $.$$.System.MulticastDelegate; }
                    static $$i;
                    static get $i() { return this.$$i ??= [ $.$$.System.ICloneable, $.$$.System.Runtime.Serialization.ISerializable ]; }
                    static get $fullName() { return `System.Runtime.InteropServices.JavaScript.JSMarshalerArgument.ArgumentToManagedCallback<${T?.$fullName}>`; }
                }), $cls, ($v) => $cls.$_ArgumentToManagedCallback$$ = $v))(T);
            }
            //--TRIMMABLE-BOUNDARY-END(1703947)
            
            //--TRIMMABLE-BOUNDARY-START(1638411)
            static $_ArgumentToJSCallback$$;
            static ArgumentToJSCallback$$(T)
            {
                let $cls = $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument;
                return ($cls.$_ArgumentToJSCallback$$ ??= $asm.$ncls("$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument.ArgumentToJSCallback<>", (T) => $asm.$gt("$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument.ArgumentToJSCallback<>", [T], ($self) => class ArgumentToJSCallback$$ extends $.$$.System.MulticastDelegate
                {
                    $ctor(/*object*/ target, fn, anmodel)
                    {
                        this.$target = target;
                        this.$nativeFunction = fn;
                        if (anmodel) this.$nfmodel = anmodel;
                        if (typeof(target) === 'object') this._target = target;
                        return this;
                    }
                    /*void*/ Invoke(/**/ arg, /**/ value)
                    {
                        return this.$nativeFunction.call(this.$target, arg, value);
                    }
                    static $h = 1638411;
                    static $g = 1;
                    static $f = 0b10000000011000001;
                    static $k = 5;
                    static $$md;
                    static get $md() { return this.$$md ??= {
  "b": 98959361,
  "m": [
//--TRIMMABLE-BOUNDARY-START(17181507595),
    {
      "r": 65537,
      "p": [
        {
          "n": "arg",
          "p": 1310731,
          "f": 4
        },
        {
          "n": "value",
          "p": T?.$h??1507328
        }
      ],
      "n": "Invoke",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x400000000n),
      "f": 16777345
    },
//--TRIMMABLE-BOUNDARY-END(17181507595),
//--TRIMMABLE-BOUNDARY-START(8591573003),
    {
      "r": 89784321,
      "p": [
        {
          "n": "arg",
          "p": 1310731,
          "f": 4
        },
        {
          "n": "value",
          "p": T?.$h??1507328
        },
        {
          "n": "callback",
          "p": 45285377
        },
        {
          "n": "object",
          "p": 131073
        }
      ],
      "n": "BeginInvoke",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x200000000n),
      "f": 16777345
    },
//--TRIMMABLE-BOUNDARY-END(8591573003),
//--TRIMMABLE-BOUNDARY-START(12886540299),
    {
      "r": 65537,
      "p": [
        {
          "n": "arg",
          "p": 1310731,
          "f": 4
        },
        {
          "n": "result",
          "p": 89784321
        }
      ],
      "n": "EndInvoke",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x300000000n),
      "f": 16777345
    },
//--TRIMMABLE-BOUNDARY-END(12886540299)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296605707),
    {
      "p": [
        {
          "n": "object",
          "p": 131073
        },
        {
          "n": "method",
          "p": 786433
        }
      ],
      "n": ".ctor",
      "o": "$ctor$5",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x100000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296605707)
  ],
  "i": [89980929,157483009
  ],
  "g": [T?.$h??1507328
  ],
  "r": 1,
  "d": 1310731,
  "h": this.$h,
  "a": [
    {
      "t": 64290817,
      "c": 12949192705,
      "a": [
        {
          "v": 1,
          "t": 64356353
        }
      ]
    }
  ]
}; }
                    static get $b() { return $.$$.System.MulticastDelegate; }
                    static $$i;
                    static get $i() { return this.$$i ??= [ $.$$.System.ICloneable, $.$$.System.Runtime.Serialization.ISerializable ]; }
                    static get $fullName() { return `System.Runtime.InteropServices.JavaScript.JSMarshalerArgument.ArgumentToJSCallback<${T?.$fullName}>`; }
                }), $cls, ($v) => $cls.$_ArgumentToJSCallback$$ = $v))(T);
            }
            //--TRIMMABLE-BOUNDARY-END(1638411)
            
            //--TRIMMABLE-BOUNDARY-START(502512484363)
            /*void */ ToManaged$37(/*out Task?*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(502512484363);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (this.slot.Type === 0/*MarshalerType.None*/)
                {
                    value.$v = null;
                    return;
                }
                /*var*/ let ctx = this.ToManagedContext;
                {
                    /*PromiseHolder*/ let holder = ctx.GetPromiseHolder(this.slot.GCHandle);
                    /*TaskCompletionSource*/ let tcs = new $.$$.System.Threading.Tasks.TaskCompletionSource().$ctor$2(holder, 64/*TaskCreationOptions.RunContinuationsAsynchronously*/);
                    /*ToManagedCallback*/ let callback = new $.$srij.System.Runtime.InteropServices.JavaScript.JSHostImplementation.ToManagedCallback().$ctor(this,  (/*JSMarshalerArgument**/ arguments_buffer) =>
                    {
                        if (arguments_buffer === null)
                        {
                            if (!tcs.TrySetException$1(new $.$$.System.Threading.Tasks.TaskCanceledException().$ctor$20("WebWorker which is origin of the Promise is being terminated.")))
                            {
                                $.$$.System.Environment.FailFast$2("Failed to set exception to TaskCompletionSource (arguments buffer is null)");
                            }
                            return;
                        }
                        /*ref JSMarshalerArgument*/ let arg_2 = arguments_buffer.Add(3);
                        if (arg_2.$v.slot.Type !== 0/*MarshalerType.None*/)
                        {
                            /*Exception?*/ let fail;
                            arg_2.$v.ToManaged$12($.$ref(() => fail, ($v) => fail = $v, $.$$.System.Exception));
                            if (!tcs.TrySetException$1(fail))
                            {
                                $.$$.System.Environment.FailFast$2("Failed to set exception to TaskCompletionSource (exception raised)");
                            }
                        }
                        else 
                        {
                            if (!tcs.TrySetResult())
                            {
                                $.$$.System.Environment.FailFast$2("Failed to set result to TaskCompletionSource (marshaler type is none)");
                            }
                        }
                    }, {
  "r": 65537,
  "p": [
    {
      "n": "arguments_buffer",
      "p": $.$typePointer($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument).$h
    }
  ],
  "n": "",
  "d": 1310731,
  "h": 0,
  "f": 17825794
});
                    holder.Callback = callback;
                    value.$v = tcs.Task;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(502512484363)
            
            //--TRIMMABLE-BOUNDARY-START(528282288139)
            /*void */ ToManaged$43(T, /*out Task<T>?*/ value, /*ArgumentToManagedCallback<T>*/ marshaler)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(528282288139);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (this.slot.Type === 0/*MarshalerType.None*/)
                {
                    value.$v = null;
                    return;
                }
                /*var*/ let ctx = this.ToManagedContext;
                {
                    /*var*/ let holder = ctx.GetPromiseHolder(this.slot.GCHandle);
                    /*TaskCompletionSource<T>*/ let tcs = new ($.$$.System.Threading.Tasks.TaskCompletionSource$$(T))().$ctor$2(holder, 64/*TaskCreationOptions.RunContinuationsAsynchronously*/);
                    /*ToManagedCallback*/ let callback = new $.$srij.System.Runtime.InteropServices.JavaScript.JSHostImplementation.ToManagedCallback().$ctor(this,  (/*JSMarshalerArgument**/ arguments_buffer) =>
                    {
                        if (arguments_buffer === null)
                        {
                            if (!tcs.TrySetException$1(new $.$$.System.Threading.Tasks.TaskCanceledException().$ctor$20("WebWorker which is origin of the Promise is being terminated.")))
                            {
                                $.$$.System.Environment.FailFast$2("Failed to set exception to TaskCompletionSource (arguments buffer is null)");
                            }
                            return;
                        }
                        /*ref JSMarshalerArgument*/ let arg_2 = arguments_buffer.Add(3);
                        /*ref JSMarshalerArgument*/ let arg_3 = arguments_buffer.Add(4);
                        if (arg_2.$v.slot.Type !== 0/*MarshalerType.None*/)
                        {
                            /*Exception?*/ let fail;
                            arg_2.$v.ToManaged$12($.$ref(() => fail, ($v) => fail = $v, $.$$.System.Exception));
                            if (fail === null)
                            {
                                throw new $.$$.System.InvalidOperationException().$ctor$12($.$srij.System.SR.FailedToMarshalException);
                            }
                            if (!tcs.TrySetException$1(fail))
                            {
                                $.$$.System.Environment.FailFast$2("Failed to set exception to TaskCompletionSource (exception raised)");
                            }
                        }
                        else 
                        {
                            /*T*/ let result;
                            marshaler.Invoke(arg_3, $.$ref(() => result, ($v) => result = $v, T));
                            if (!tcs.TrySetResult(result))
                            {
                                $.$$.System.Environment.FailFast$2("Failed to set result to TaskCompletionSource (marshaler type is none)");
                            }
                        }
                    }, {
  "r": 65537,
  "p": [
    {
      "n": "arguments_buffer",
      "p": $.$typePointer($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument).$h
    }
  ],
  "n": "",
  "d": 1310731,
  "h": 0,
  "f": 17825794
});
                    holder.Callback = callback;
                    value.$v = tcs.Task;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(528282288139)
            
            //--TRIMMABLE-BOUNDARY-START(339303727115)
            /*void */ ToJSDynamic(/*Task?*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(339303727115);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*Task?*/ let task = value;
                /*var*/ let ctx = this.ToJSContext;
                /*var*/ let canMarshalTaskResultOnSameCall = this.CanMarshalTaskResultOnSameCall(ctx);
                if (task === null)
                {
                    if (!canMarshalTaskResultOnSameCall)
                    {
                        $.$$.System.Environment.FailFast$2("Marshalling null return Task to JS is not supported in MT");
                    }
                    this.slot.Type = 0/*MarshalerType.None*/;
                    return;
                }
                if (canMarshalTaskResultOnSameCall && task.IsCompleted)
                {
                    if (task.Exception !== null)
                    {
                        /*Exception*/ let ex = task.Exception;
                        this.ToJS$12(ex);
                        this.slot.ElementType = this.slot.Type;
                        this.slot.Type = 29/*MarshalerType.TaskRejected*/;
                        return;
                    }
                    else 
                    {
                        /*object?*/ let result;
                        if ($.$srij.System.Runtime.InteropServices.JavaScript.JSHostImplementation.GetTaskResultDynamic(task, $.$ref(() => result, ($v) => result = $v, $.$$.System.Object)))
                        {
                            this.ToJS$29(result);
                            this.slot.ElementType = this.slot.Type;
                        }
                        else 
                        {
                            this.slot.ElementType = 1/*MarshalerType.Void*/;
                        }
                        this.slot.Type = 28/*MarshalerType.TaskResolved*/;
                        return;
                    }
                }
                if (this.slot.Type !== 30/*MarshalerType.TaskPreCreated*/)
                {
                    this.slot.JSHandle = ctx.AllocJSVHandle();
                    this.slot.Type = 20/*MarshalerType.Task*/;
                }
                else 
                {
                }
                /*var*/ let taskHolder = ctx.CreateCSOwnedProxy(this.slot.JSHandle);
                task.ContinueWith$4(new ($.$$.System.Action$$$($.$$.System.Threading.Tasks.Task, $.$$.System.Object))().$ctor($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument, Complete), taskHolder, $.$$.System.Threading.Tasks.TaskScheduler.Current);
                /*static void*/  function Complete(/*Task*/ task, /*object?*/ th)
                {
                    /*var*/ let taskHolderArg = $.$cast(th, $.$srij.System.Runtime.InteropServices.JavaScript.JSObject);
                    if (task.Exception !== null)
                    {
                        $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument.RejectPromise(taskHolderArg, task.Exception);
                    }
                    else 
                    {
                        /*object?*/ let result;
                        if ($.$srij.System.Runtime.InteropServices.JavaScript.JSHostImplementation.GetTaskResultDynamic(task, $.$ref(() => result, ($v) => result = $v, $.$$.System.Object)))
                        {
                            $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument.ResolvePromise($.$$.System.Object, taskHolderArg, result, new ($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument.ArgumentToJSCallback$$($.$$.System.Object))().$ctor($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument, MarshalResult));
                        }
                        else 
                        {
                            $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument.ResolveVoidPromise(taskHolderArg);
                        }
                    }
                }
                /*static void*/  function MarshalResult(/*ref JSMarshalerArgument*/ arg, /*object?*/ taskResult)
                {
                    arg.$v.ToJS$29(taskResult);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(339303727115)
            
            //--TRIMMABLE-BOUNDARY-START(274879217675)
            /*void */ ToJS$37(/*Task?*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(274879217675);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*Task?*/ let task = value;
                /*var*/ let ctx = this.ToJSContext;
                /*var*/ let canMarshalTaskResultOnSameCall = this.CanMarshalTaskResultOnSameCall(ctx);
                if (task === null)
                {
                    if (!canMarshalTaskResultOnSameCall)
                    {
                        $.$$.System.Environment.FailFast$2("Marshalling null return Task to JS is not supported in MT");
                    }
                    this.slot.Type = 0/*MarshalerType.None*/;
                    return;
                }
                if (canMarshalTaskResultOnSameCall && task.IsCompleted)
                {
                    if (task.Exception !== null)
                    {
                        /*Exception*/ let ex = task.Exception;
                        this.ToJS$12(ex);
                        this.slot.ElementType = this.slot.Type;
                        this.slot.Type = 29/*MarshalerType.TaskRejected*/;
                        return;
                    }
                    else 
                    {
                        this.slot.ElementType = 1/*MarshalerType.Void*/;
                        this.slot.Type = 28/*MarshalerType.TaskResolved*/;
                        return;
                    }
                }
                if (this.slot.Type !== 30/*MarshalerType.TaskPreCreated*/)
                {
                    this.slot.JSHandle = ctx.AllocJSVHandle();
                    this.slot.Type = 20/*MarshalerType.Task*/;
                }
                else 
                {
                }
                /*var*/ let taskHolder = ctx.CreateCSOwnedProxy(this.slot.JSHandle);
                task.ContinueWith$4(new ($.$$.System.Action$$$($.$$.System.Threading.Tasks.Task, $.$$.System.Object))().$ctor($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument, Complete), taskHolder, $.$$.System.Threading.Tasks.TaskScheduler.Current);
                /*static void*/  function Complete(/*Task*/ task, /*object?*/ th)
                {
                    /*JSObject*/ let taskHolderArg = $.$cast(th, $.$srij.System.Runtime.InteropServices.JavaScript.JSObject);
                    if (task.Exception !== null)
                    {
                        $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument.RejectPromise(taskHolderArg, task.Exception);
                    }
                    else 
                    {
                        $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument.ResolveVoidPromise(taskHolderArg);
                    }
                }
            }
            //--TRIMMABLE-BOUNDARY-END(274879217675)
            
            //--TRIMMABLE-BOUNDARY-START(300649021451)
            /*void */ ToJS$43(T, /*Task<T>?*/ value, /*ArgumentToJSCallback<T>*/ marshaler)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(300649021451);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*Task<T>?*/ let task = value;
                /*var*/ let ctx = this.ToJSContext;
                /*var*/ let canMarshalTaskResultOnSameCall = this.CanMarshalTaskResultOnSameCall(ctx);
                if (task === null)
                {
                    if (!canMarshalTaskResultOnSameCall)
                    {
                        $.$$.System.Environment.FailFast$2("Marshalling null return Task to JS is not supported in MT");
                    }
                    this.slot.Type = 0/*MarshalerType.None*/;
                    return;
                }
                if (canMarshalTaskResultOnSameCall && task.IsCompleted)
                {
                    if (task.Exception !== null)
                    {
                        /*Exception*/ let ex = task.Exception;
                        this.ToJS$12(ex);
                        this.slot.ElementType = this.slot.Type;
                        this.slot.Type = 29/*MarshalerType.TaskRejected*/;
                        return;
                    }
                    else 
                    {
                        /*T*/ let result = task.Result;
                        this.ToJS$29($.$box(result, T));
                        this.slot.ElementType = this.slot.Type;
                        this.slot.Type = 28/*MarshalerType.TaskResolved*/;
                        return;
                    }
                }
                if (this.slot.Type !== 30/*MarshalerType.TaskPreCreated*/)
                {
                    this.slot.JSHandle = ctx.AllocJSVHandle();
                    this.slot.Type = 20/*MarshalerType.Task*/;
                }
                else 
                {
                }
                /*var*/ let taskHolder = ctx.CreateCSOwnedProxy(this.slot.JSHandle);
                task.ContinueWith$28(new ($.$$.System.Action$$$($.$$.System.Threading.Tasks.Task$$(T), $.$$.System.Object))().$ctor($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument, Complete), new ($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument.HolderAndMarshaler$$(T))().$ctor$2(taskHolder, marshaler), $.$$.System.Threading.Tasks.TaskScheduler.Current);
                /*static void*/  function Complete(/*Task<T>*/ task, /*object?*/ thm)
                {
                    /*var*/ let hm = $.$cast(thm, $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument.HolderAndMarshaler$$(T));
                    if (task.Exception !== null)
                    {
                        $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument.RejectPromise(hm.TaskHolder, task.Exception);
                    }
                    else 
                    {
                        /*T*/ let result = task.Result;
                        $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument.ResolvePromise(T, hm.TaskHolder, result, hm.Marshaler);
                    }
                }
            }
            //--TRIMMABLE-BOUNDARY-END(300649021451)
            
            //--TRIMMABLE-BOUNDARY-START(64425820171)
            /*bool */ CanMarshalTaskResultOnSameCall(/*JSProxyContext*/ _)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(64425820171);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(64425820171)
            
            //--TRIMMABLE-BOUNDARY-START(2031627)
            static $_HolderAndMarshaler$$;
            static HolderAndMarshaler$$(T)
            {
                let $cls = $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument;
                return ($cls.$_HolderAndMarshaler$$ ??= $asm.$ncls("$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument.HolderAndMarshaler<>", (T) => $asm.$gt("$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument.HolderAndMarshaler<>", [T], ($self) => class HolderAndMarshaler$$ extends $.$$.System.Object
                {
                    //--TRIMMABLE-BOUNDARY-START(4385341441)
                    //Generated interface implemetation for System.IEquatable<System.Runtime.InteropServices.JavaScript.JSMarshalerArgument.HolderAndMarshaler<T>>.Equals(System.Runtime.InteropServices.JavaScript.JSMarshalerArgument.HolderAndMarshaler<T>?)
                    System$IEquatable$$$Equals()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(4385341441);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return this.Equals$2(...arguments);
                    }
                    //--TRIMMABLE-BOUNDARY-END(4385341441)
                    
                    Clone($copy)
                    {
                        let copy = $copy ?? new this.constructor();
                        copy.TaskHolder = this.TaskHolder;
                        copy.Marshaler = this.Marshaler;
                        return copy;
                    }
                    //Begin primary constructor
                    /*JSObject*/ TaskHolder = null;
                    /*ArgumentToJSCallback<T>*/ Marshaler = null;
                    $ctor$2(/*JSObject*/TaskHolder, /*ArgumentToJSCallback<T>*/Marshaler)
                    {
                        this.TaskHolder = TaskHolder;
                        this.Marshaler = Marshaler;
                        return this
                    }
                    //End primary constructor
                    //Begin generated record members
                    /*Type*/ get EqualityContract() { return $.$typeOf($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument.HolderAndMarshaler$$(T)); }
                    /*string*/ ToString()
                    {
                        let stringBuilder = new $.$$.System.Text.StringBuilder().$ctor$1();
                        stringBuilder.Append$19("HolderAndMarshaler");
                        stringBuilder.Append$19("{");
                        if (this.PrintMembers(stringBuilder))
                        {
                            stringBuilder.Append$19(" ");
                        }
                        stringBuilder.Append$19("}");
                        return $.$$.System.Text.StringBuilder.ToString.call(stringBuilder);
                    }
                    /*bool*/ PrintMembers(/*StringBuilder*/ stringBuilder)
                    {
                        stringBuilder.Append$19("TaskHolder = ");
                        stringBuilder.Append$19($.$srij.System.Runtime.InteropServices.JavaScript.JSObject.ToString.call(this.TaskHolder));
                        stringBuilder.Append$19(", ");
                        stringBuilder.Append$19("Marshaler = ");
                        stringBuilder.Append$19($.$$.System.Object.ToString.call(this.Marshaler));
                        return true;
                    }
                    /*bool*/ Equals$2(/*HolderAndMarshaler*/ other)
                    {
                        return this === other || (other !== null && this.EqualityContract == other.EqualityContract && $.$$.System.Collections.Generic.EqualityComparer$$($.$srij.System.Runtime.InteropServices.JavaScript.JSObject).Default.Equals$2(this.TaskHolder, other.TaskHolder) && $.$$.System.Collections.Generic.EqualityComparer$$($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument.ArgumentToJSCallback$$(T)).Default.Equals$2(this.Marshaler, other.Marshaler));
                    }
                    /*int*/ GetHashCode()
                    {
                        return $.$$.System.Collections.Generic.EqualityComparer$$($.$$.System.Type).Default.GetHashCode$1(this.EqualityContract) * -1521134295 && $.$$.System.Collections.Generic.EqualityComparer$$($.$srij.System.Runtime.InteropServices.JavaScript.JSObject).Default.GetHashCode$1(this.TaskHolder) * -1521134295 && $.$$.System.Collections.Generic.EqualityComparer$$($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument.ArgumentToJSCallback$$(T)).Default.GetHashCode$1(this.Marshaler) * -1521134295;
                    }
                    static /*bool*/ op_InEquality(/*HolderAndMarshaler*/ left, /*HolderAndMarshaler*/ right)
                    {
                        return !(this.op_Equals(left, right));
                    }
                    static /*bool*/ op_Equality(/*HolderAndMarshaler*/ left, /*HolderAndMarshaler*/ right)
                    {
                        return left === right || (left !== null && left.Equals$2(right));
                    }
                    Deconstruct(/*out System.Runtime.InteropServices.JavaScript.JSObject*/ $TaskHolder, /*out System.Runtime.InteropServices.JavaScript.JSMarshalerArgument.ArgumentToJSCallback<T>*/ $Marshaler)
                    {
                        $TaskHolder.$v = this.TaskHolder;
                        $Marshaler.$v = this.Marshaler;
                    }
                    //End generated record member3s
                    static $h = 2031627;
                    static $g = 1;
                    static $f = 0b10000000011010000;
                    static $k = 1;
                    static $$md;
                    static get $md() { return this.$$md ??= {
  "b": 131073,
  "p": [
//--TRIMMABLE-BOUNDARY-START(30066802699),
    {
      "p": 187760641,
      "g": {
        "r": 0,
        "d": 0,
        "h": Number(BigInt(this.$h)|0xB00000000n),
        "f": 50331650
      },
      "n": "EqualityContract",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x700000000n),
      "f": 2097154
    },
//--TRIMMABLE-BOUNDARY-END(30066802699),
//--TRIMMABLE-BOUNDARY-START(107376214027),
    {
      "p": 2228235,
      "g": {
        "r": 0,
        "d": 0,
        "h": Number(BigInt(this.$h)|0xF00000000n),
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": Number(BigInt(this.$h)|0x1800000000n),
        "f": 83886081
      },
      "n": "TaskHolder",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x1900000000n),
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(107376214027),
//--TRIMMABLE-BOUNDARY-START(73016475659),
    {
      "p": $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument.ArgumentToJSCallback$$(T).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": Number(BigInt(this.$h)|0xD00000000n),
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": Number(BigInt(this.$h)|0x1600000000n),
        "f": 83886081
      },
      "n": "Marshaler",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x1100000000n),
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(73016475659)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(111671181323),
    {
      "r": 1310721,
      "n": "ToString",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x1A00000000n),
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(111671181323),
//--TRIMMABLE-BOUNDARY-START(85901377547),
    {
      "r": 262145,
      "p": [
        {
          "n": "builder",
          "p": 167051265
        }
      ],
      "n": "PrintMembers",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x1400000000n),
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(85901377547),
//--TRIMMABLE-BOUNDARY-START(68721508363),
    {
      "r": 655361,
      "n": "GetHashCode",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x1000000000n),
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(68721508363),
//--TRIMMABLE-BOUNDARY-START(34361769995),
    {
      "r": 262145,
      "p": [
        {
          "n": "obj",
          "p": 131073
        }
      ],
      "n": "Equals",
      "o": "@$1",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x800000000n),
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(34361769995),
//--TRIMMABLE-BOUNDARY-START(38656737291),
    {
      "r": 262145,
      "p": [
        {
          "n": "other",
          "p": this.$h
        }
      ],
      "n": "Equals",
      "o": "@$2",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x900000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(38656737291),
//--TRIMMABLE-BOUNDARY-START(4296998923),
    {
      "r": this.$h,
      "n": "\u003CClone\u003E$",
      "o": "$$$",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x100000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296998923),
//--TRIMMABLE-BOUNDARY-START(25771835403),
    {
      "r": 65537,
      "p": [
        {
          "n": "TaskHolder",
          "p": 2228235,
          "f": 2
        },
        {
          "n": "Marshaler",
          "p": $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument.ArgumentToJSCallback$$(T).$h,
          "f": 2
        }
      ],
      "n": "Deconstruct",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x600000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(25771835403)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(21476868107),
    {
      "p": [
        {
          "n": "TaskHolder",
          "p": 2228235
        },
        {
          "n": "Marshaler",
          "p": $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument.ArgumentToJSCallback$$(T).$h
        }
      ],
      "n": ".ctor",
      "o": "$ctor$2",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x500000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(21476868107),
//--TRIMMABLE-BOUNDARY-START(17181900811),
    {
      "p": [
        {
          "n": "original",
          "p": this.$h
        }
      ],
      "n": ".ctor",
      "o": "$ctor$1",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x400000000n),
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(17181900811)
  ],
  "i": [$.$$.System.IEquatable$$($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument.HolderAndMarshaler$$(T)).$h
  ],
  "g": [T?.$h??1507328
  ],
  "r": 1,
  "d": 1310731,
  "h": this.$h
}; }
                    static get $b() { return $.$$.System.Object; }
                    static $$i;
                    static get $i() { return this.$$i ??= [ $.$$.System.IEquatable$$($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument.HolderAndMarshaler$$(T)) ]; }
                    static get $fullName() { return `System.Runtime.InteropServices.JavaScript.JSMarshalerArgument.HolderAndMarshaler<${T?.$fullName}>`; }
                }), $cls, ($v) => $cls.$_HolderAndMarshaler$$ = $v))(T);
            }
            //--TRIMMABLE-BOUNDARY-END(2031627)
            
            //--TRIMMABLE-BOUNDARY-START(98785558539)
            static /*void */ RejectPromise(/*JSObject*/ holder, /*Exception*/ ex)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(98785558539);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                holder.AssertNotDisposed();
                /*Span<JSMarshalerArgument>*/ let args = $.$$.System.Runtime.CompilerServices.RuntimeHelpers.StackAllocSpan($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument, 4, null);
                /*ref JSMarshalerArgument*/ let exc = args.get_Item(0);
                /*ref JSMarshalerArgument*/ let res = args.get_Item(1);
                /*ref JSMarshalerArgument*/ let arg_handle = args.get_Item(2);
                /*ref JSMarshalerArgument*/ let arg_value = args.get_Item(3);
                exc.$v.Initialize();
                res.$v.Initialize();
                arg_handle.$v.slot.Type = 29/*MarshalerType.TaskRejected*/;
                arg_handle.$v.slot.JSHandle = holder.JSHandle;
                arg_value.$v.ToJS$12(ex);
                holder.DisposeImpl(true);
                $.$srij.System.Runtime.InteropServices.JavaScript.JSFunctionBinding.ResolveOrRejectPromise(holder.ProxyContext, args);
            }
            //--TRIMMABLE-BOUNDARY-END(98785558539)
            
            //--TRIMMABLE-BOUNDARY-START(107375493131)
            static /*void */ ResolveVoidPromise(/*JSObject*/ holder)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(107375493131);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                holder.AssertNotDisposed();
                /*Span<JSMarshalerArgument>*/ let args = $.$$.System.Runtime.CompilerServices.RuntimeHelpers.StackAllocSpan($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument, 4, null);
                /*ref JSMarshalerArgument*/ let exc = args.get_Item(0);
                /*ref JSMarshalerArgument*/ let res = args.get_Item(1);
                /*ref JSMarshalerArgument*/ let arg_handle = args.get_Item(2);
                /*ref JSMarshalerArgument*/ let arg_value = args.get_Item(3);
                exc.$v.Initialize();
                res.$v.Initialize();
                arg_handle.$v.slot.Type = 28/*MarshalerType.TaskResolved*/;
                arg_handle.$v.slot.JSHandle = holder.JSHandle;
                arg_value.$v.slot.Type = 1/*MarshalerType.Void*/;
                holder.DisposeImpl(true);
                $.$srij.System.Runtime.InteropServices.JavaScript.JSFunctionBinding.ResolveOrRejectPromise(holder.ProxyContext, args);
            }
            //--TRIMMABLE-BOUNDARY-END(107375493131)
            
            //--TRIMMABLE-BOUNDARY-START(103080525835)
            static /*void */ ResolvePromise(T, /*JSObject*/ holder, /*T*/ value, /*ArgumentToJSCallback<T>*/ marshaler)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(103080525835);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                holder.AssertNotDisposed();
                /*Span<JSMarshalerArgument>*/ let args = $.$$.System.Runtime.CompilerServices.RuntimeHelpers.StackAllocSpan($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument, 4, null);
                /*ref JSMarshalerArgument*/ let exc = args.get_Item(0);
                /*ref JSMarshalerArgument*/ let res = args.get_Item(1);
                /*ref JSMarshalerArgument*/ let arg_handle = args.get_Item(2);
                /*ref JSMarshalerArgument*/ let arg_value = args.get_Item(3);
                exc.$v.Initialize();
                res.$v.Initialize();
                arg_handle.$v.slot.Type = 28/*MarshalerType.TaskResolved*/;
                arg_handle.$v.slot.JSHandle = holder.JSHandle;
                marshaler.Invoke(arg_value, value);
                holder.DisposeImpl(true);
                $.$srij.System.Runtime.InteropServices.JavaScript.JSFunctionBinding.ResolveOrRejectPromise(holder.ProxyContext, args);
            }
            //--TRIMMABLE-BOUNDARY-END(103080525835)
            
            //--TRIMMABLE-BOUNDARY-START(382253400075)
            /*void */ ToManaged$9(/*out DateTimeOffset*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(382253400075);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (this.slot.Type === 0/*MarshalerType.None*/)
                {
                    value.$v = new $.$$.System.DateTimeOffset();
                    return;
                }
                value.$v = $.$$.System.DateTimeOffset.FromUnixTimeMilliseconds($.$cast(this.slot.DoubleValue, $.$$.System.Int64));
            }
            //--TRIMMABLE-BOUNDARY-END(382253400075)
            
            //--TRIMMABLE-BOUNDARY-START(154620133387)
            /*void */ ToJS$9(/*DateTimeOffset*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(154620133387);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.slot.Type = 18/*MarshalerType.DateTimeOffset*/;
                this.slot.DoubleValue = $.$cast(value.ToUnixTimeMilliseconds(), $.$$.System.Double);
            }
            //--TRIMMABLE-BOUNDARY-END(154620133387)
            
            //--TRIMMABLE-BOUNDARY-START(438087974923)
            /*void */ ToManaged$22(/*out DateTimeOffset?*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(438087974923);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (this.slot.Type === 0/*MarshalerType.None*/)
                {
                    value.$v = null;
                    return;
                }
                value.$v = $.$$.System.DateTimeOffset.FromUnixTimeMilliseconds($.$cast(this.slot.DoubleValue, $.$$.System.Int64));
            }
            //--TRIMMABLE-BOUNDARY-END(438087974923)
            
            //--TRIMMABLE-BOUNDARY-START(210454708235)
            /*void */ ToJS$22(/*DateTimeOffset?*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(210454708235);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$$.System.Nullable$$($.$$.System.DateTimeOffset).HasValue$get.call(value))
                {
                    this.slot.Type = 18/*MarshalerType.DateTimeOffset*/;
                    this.slot.DoubleValue = Number($.$$.System.Nullable$$($.$$.System.DateTimeOffset).Value$get.call(value).ToUnixTimeMilliseconds());
                }
                else 
                {
                    this.slot.Type = 0/*MarshalerType.None*/;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(210454708235)
            
            //--TRIMMABLE-BOUNDARY-START(377958432779)
            /*void */ ToManaged$8(/*out DateTime*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(377958432779);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (this.slot.Type === 0/*MarshalerType.None*/)
                {
                    value.$v = new $.$$.System.DateTime();
                    return;
                }
                value.$v = $.$$.System.DateTimeOffset.FromUnixTimeMilliseconds($.$cast(this.slot.DoubleValue, $.$$.System.Int64)).UtcDateTime;
            }
            //--TRIMMABLE-BOUNDARY-END(377958432779)
            
            //--TRIMMABLE-BOUNDARY-START(150325166091)
            /*void */ ToJS$8(/*DateTime*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(150325166091);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.slot.Type = 17/*MarshalerType.DateTime*/;
                this.slot.DoubleValue = Number(new $.$$.System.DateTimeOffset().$ctor$5(value).ToUnixTimeMilliseconds());
            }
            //--TRIMMABLE-BOUNDARY-END(150325166091)
            
            //--TRIMMABLE-BOUNDARY-START(433793007627)
            /*void */ ToManaged$21(/*out DateTime?*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(433793007627);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (this.slot.Type === 0/*MarshalerType.None*/)
                {
                    value.$v = null;
                    return;
                }
                value.$v = $.$$.System.DateTimeOffset.FromUnixTimeMilliseconds($.$cast(this.slot.DoubleValue, $.$$.System.Int64)).UtcDateTime;
            }
            //--TRIMMABLE-BOUNDARY-END(433793007627)
            
            //--TRIMMABLE-BOUNDARY-START(206159740939)
            /*void */ ToJS$21(/*DateTime?*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(206159740939);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$$.System.Nullable$$($.$$.System.DateTime).HasValue$get.call(value))
                {
                    this.slot.Type = 17/*MarshalerType.DateTime*/;
                    this.slot.DoubleValue = Number(new $.$$.System.DateTimeOffset().$ctor$5($.$$.System.Nullable$$($.$$.System.DateTime).Value$get.call(value)).ToUnixTimeMilliseconds());
                }
                else 
                {
                    this.slot.Type = 0/*MarshalerType.None*/;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(206159740939)
            
            //--TRIMMABLE-BOUNDARY-START(1376267)
            static $_ActionJS;
            static get ActionJS()
            {
                let $cls = $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument;
                return $cls.$_ActionJS ??= $asm.$ncls("$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument.ActionJS", ($self) => class ActionJS extends $.$$.System.Object
                {
                    //--TRIMMABLE-BOUNDARY-START(12886278155)
                    /*JSObject*/ JSObject = null;
                    //--TRIMMABLE-BOUNDARY-END(12886278155)
                    
                    //--TRIMMABLE-BOUNDARY-START(4296343563)
                    $ctor$1(/*JSObject*/ holder)
                    {
                        super.$ctor();
                        {
                            //--TRIMMABLE-BOUNDARY-START(TRACE)
                            $.$trace(4296343563);
                            //--TRIMMABLE-BOUNDARY-END(TRACE)
                            this.JSObject = holder;
                        }
                        return this;
                    }
                    //--TRIMMABLE-BOUNDARY-END(4296343563)
                    
                    //--TRIMMABLE-BOUNDARY-START(8591310859)
                    /*void */ InvokeJS()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(8591310859);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        /*Span<JSMarshalerArgument>*/ let $arguments = $.$$.System.Runtime.CompilerServices.RuntimeHelpers.StackAllocSpan($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument, 2, null);
                        /*ref JSMarshalerArgument*/ let args_exception = $arguments.get_Item(0);
                        /*ref JSMarshalerArgument*/ let args_return = $arguments.get_Item(1);
                        args_exception.$v.Initialize();
                        args_return.$v.Initialize();
                        $.$srij.System.Runtime.InteropServices.JavaScript.JSFunctionBinding.InvokeJSFunction(this.JSObject, $arguments);
                    }
                    //--TRIMMABLE-BOUNDARY-END(8591310859)
                    
                    static $h = 1376267;
                    static $f = 0b10000000010010000;
                    static $k = 1;
                    static $$md;
                    static get $md() { return this.$$md ??= {
  "b": 131073,
  "m": [
//--TRIMMABLE-BOUNDARY-START(8591310859),
    {
      "r": 65537,
      "n": "InvokeJS",
      "d": 1376267,
      "h": 8591310859,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8591310859)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(12886278155),
    {
      "t": 2228235,
      "n": "JSObject",
      "d": 1376267,
      "h": 12886278155,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(12886278155)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296343563),
    {
      "p": [
        {
          "n": "holder",
          "p": 2228235
        }
      ],
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 1376267,
      "h": 4296343563,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296343563)
  ],
  "d": 1310731,
  "h": 1376267
}; }
                    static get $b() { return $.$$.System.Object; }
                    static get $fullName() { return `System.Runtime.InteropServices.JavaScript.JSMarshalerArgument.ActionJS`; }
                }, $cls, ($v) => $cls.$_ActionJS = $v);
            }
            //--TRIMMABLE-BOUNDARY-END(1376267)
            
            //--TRIMMABLE-BOUNDARY-START(1572875)
            static $_ActionJS$$;
            static ActionJS$$(T)
            {
                let $cls = $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument;
                return ($cls.$_ActionJS$$ ??= $asm.$ncls("$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument.ActionJS<>", (T) => $asm.$gt("$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument.ActionJS<>", [T], ($self) => class ActionJS$$ extends $.$$.System.Object
                {
                    //--TRIMMABLE-BOUNDARY-START(8591507467)
                    /*ArgumentToJSCallback<T>*/ Arg1Marshaler = null;
                    //--TRIMMABLE-BOUNDARY-END(8591507467)
                    
                    //--TRIMMABLE-BOUNDARY-START(17181442059)
                    /*JSObject*/ JSObject = null;
                    //--TRIMMABLE-BOUNDARY-END(17181442059)
                    
                    //--TRIMMABLE-BOUNDARY-START(4296540171)
                    $ctor$1(/*JSObject*/ holder, /*ArgumentToJSCallback<T>*/ arg1Marshaler)
                    {
                        super.$ctor();
                        {
                            //--TRIMMABLE-BOUNDARY-START(TRACE)
                            $.$trace(4296540171);
                            //--TRIMMABLE-BOUNDARY-END(TRACE)
                            this.JSObject = holder;
                            this.Arg1Marshaler = arg1Marshaler;
                        }
                        return this;
                    }
                    //--TRIMMABLE-BOUNDARY-END(4296540171)
                    
                    //--TRIMMABLE-BOUNDARY-START(12886474763)
                    /*void */ InvokeJS(/*T*/ arg1)
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(12886474763);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        /*Span<JSMarshalerArgument>*/ let $arguments = $.$$.System.Runtime.CompilerServices.RuntimeHelpers.StackAllocSpan($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument, 3, null);
                        /*ref JSMarshalerArgument*/ let args_exception = $arguments.get_Item(0);
                        /*ref JSMarshalerArgument*/ let args_return = $arguments.get_Item(1);
                        /*ref JSMarshalerArgument*/ let args_arg1 = $arguments.get_Item(2);
                        args_exception.$v.Initialize();
                        args_return.$v.Initialize();
                        this.Arg1Marshaler.Invoke(args_arg1, arg1);
                        $.$srij.System.Runtime.InteropServices.JavaScript.JSFunctionBinding.InvokeJSFunction(this.JSObject, $arguments);
                    }
                    //--TRIMMABLE-BOUNDARY-END(12886474763)
                    
                    static $h = 1572875;
                    static $g = 1;
                    static $f = 0b10000000011010000;
                    static $k = 1;
                    static $$md;
                    static get $md() { return this.$$md ??= {
  "b": 131073,
  "m": [
//--TRIMMABLE-BOUNDARY-START(12886474763),
    {
      "r": 65537,
      "p": [
        {
          "n": "arg1",
          "p": T?.$h??1507328
        }
      ],
      "n": "InvokeJS",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x300000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(12886474763)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(8591507467),
    {
      "t": $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument.ArgumentToJSCallback$$(T).$h,
      "n": "Arg1Marshaler",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x200000000n),
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(8591507467),
//--TRIMMABLE-BOUNDARY-START(17181442059),
    {
      "t": 2228235,
      "n": "JSObject",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x400000000n),
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(17181442059)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296540171),
    {
      "p": [
        {
          "n": "holder",
          "p": 2228235
        },
        {
          "n": "arg1Marshaler",
          "p": $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument.ArgumentToJSCallback$$(T).$h
        }
      ],
      "n": ".ctor",
      "o": "$ctor$1",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x100000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296540171)
  ],
  "g": [T?.$h??1507328
  ],
  "r": 1,
  "d": 1310731,
  "h": this.$h
}; }
                    static get $b() { return $.$$.System.Object; }
                    static get $fullName() { return `System.Runtime.InteropServices.JavaScript.JSMarshalerArgument.ActionJS<${T?.$fullName}>`; }
                }), $cls, ($v) => $cls.$_ActionJS$$ = $v))(T);
            }
            //--TRIMMABLE-BOUNDARY-END(1572875)
            
            //--TRIMMABLE-BOUNDARY-START(1507339)
            static $_ActionJS$$$;
            static ActionJS$$$(T1, T2)
            {
                let $cls = $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument;
                return ($cls.$_ActionJS$$$ ??= $asm.$ncls("$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument.ActionJS<,>", (T1, T2) => $asm.$gt("$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument.ActionJS<,>", [T1, T2], ($self) => class ActionJS$$$ extends $.$$.System.Object
                {
                    //--TRIMMABLE-BOUNDARY-START(8591441931)
                    /*ArgumentToJSCallback<T1>*/ Arg1Marshaler = null;
                    //--TRIMMABLE-BOUNDARY-END(8591441931)
                    
                    //--TRIMMABLE-BOUNDARY-START(12886409227)
                    /*ArgumentToJSCallback<T2>*/ Arg2Marshaler = null;
                    //--TRIMMABLE-BOUNDARY-END(12886409227)
                    
                    //--TRIMMABLE-BOUNDARY-START(21476343819)
                    /*JSObject*/ JSObject = null;
                    //--TRIMMABLE-BOUNDARY-END(21476343819)
                    
                    //--TRIMMABLE-BOUNDARY-START(4296474635)
                    $ctor$1(/*JSObject*/ holder, /*ArgumentToJSCallback<T1>*/ arg1Marshaler, /*ArgumentToJSCallback<T2>*/ arg2Marshaler)
                    {
                        super.$ctor();
                        {
                            //--TRIMMABLE-BOUNDARY-START(TRACE)
                            $.$trace(4296474635);
                            //--TRIMMABLE-BOUNDARY-END(TRACE)
                            this.JSObject = holder;
                            this.Arg1Marshaler = arg1Marshaler;
                            this.Arg2Marshaler = arg2Marshaler;
                        }
                        return this;
                    }
                    //--TRIMMABLE-BOUNDARY-END(4296474635)
                    
                    //--TRIMMABLE-BOUNDARY-START(17181376523)
                    /*void */ InvokeJS(/*T1*/ arg1, /*T2*/ arg2)
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(17181376523);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        /*Span<JSMarshalerArgument>*/ let $arguments = $.$$.System.Runtime.CompilerServices.RuntimeHelpers.StackAllocSpan($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument, 4, null);
                        /*ref JSMarshalerArgument*/ let args_exception = $arguments.get_Item(0);
                        /*ref JSMarshalerArgument*/ let args_return = $arguments.get_Item(1);
                        /*ref JSMarshalerArgument*/ let args_arg1 = $arguments.get_Item(2);
                        /*ref JSMarshalerArgument*/ let args_arg2 = $arguments.get_Item(3);
                        args_exception.$v.Initialize();
                        args_return.$v.Initialize();
                        this.Arg1Marshaler.Invoke(args_arg1, arg1);
                        this.Arg2Marshaler.Invoke(args_arg2, arg2);
                        $.$srij.System.Runtime.InteropServices.JavaScript.JSFunctionBinding.InvokeJSFunction(this.JSObject, $arguments);
                    }
                    //--TRIMMABLE-BOUNDARY-END(17181376523)
                    
                    static $h = 1507339;
                    static $g = 2;
                    static $f = 0b10000000011010000;
                    static $k = 1;
                    static $$md;
                    static get $md() { return this.$$md ??= {
  "b": 131073,
  "m": [
//--TRIMMABLE-BOUNDARY-START(17181376523),
    {
      "r": 65537,
      "p": [
        {
          "n": "arg1",
          "p": T1?.$h??1507328
        },
        {
          "n": "arg2",
          "p": T2?.$h??1572864
        }
      ],
      "n": "InvokeJS",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x400000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(17181376523)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(8591441931),
    {
      "t": $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument.ArgumentToJSCallback$$(T1).$h,
      "n": "Arg1Marshaler",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x200000000n),
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(8591441931),
//--TRIMMABLE-BOUNDARY-START(12886409227),
    {
      "t": $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument.ArgumentToJSCallback$$(T2).$h,
      "n": "Arg2Marshaler",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x300000000n),
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(12886409227),
//--TRIMMABLE-BOUNDARY-START(21476343819),
    {
      "t": 2228235,
      "n": "JSObject",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x500000000n),
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(21476343819)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296474635),
    {
      "p": [
        {
          "n": "holder",
          "p": 2228235
        },
        {
          "n": "arg1Marshaler",
          "p": $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument.ArgumentToJSCallback$$(T1).$h
        },
        {
          "n": "arg2Marshaler",
          "p": $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument.ArgumentToJSCallback$$(T2).$h
        }
      ],
      "n": ".ctor",
      "o": "$ctor$1",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x100000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296474635)
  ],
  "g": [T1?.$h??1507328,T2?.$h??1572864
  ],
  "r": 2,
  "d": 1310731,
  "h": this.$h
}; }
                    static get $b() { return $.$$.System.Object; }
                    static get $fullName() { return `System.Runtime.InteropServices.JavaScript.JSMarshalerArgument.ActionJS<${T1?.$fullName},${T2?.$fullName}>`; }
                }), $cls, ($v) => $cls.$_ActionJS$$$ = $v))(T1, T2);
            }
            //--TRIMMABLE-BOUNDARY-END(1507339)
            
            //--TRIMMABLE-BOUNDARY-START(1441803)
            static $_ActionJS$$$$;
            static ActionJS$$$$(T1, T2, T3)
            {
                let $cls = $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument;
                return ($cls.$_ActionJS$$$$ ??= $asm.$ncls("$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument.ActionJS<,,>", (T1, T2, T3) => $asm.$gt("$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument.ActionJS<,,>", [T1, T2, T3], ($self) => class ActionJS$$$$ extends $.$$.System.Object
                {
                    //--TRIMMABLE-BOUNDARY-START(8591376395)
                    /*ArgumentToJSCallback<T1>*/ Arg1Marshaler = null;
                    //--TRIMMABLE-BOUNDARY-END(8591376395)
                    
                    //--TRIMMABLE-BOUNDARY-START(12886343691)
                    /*ArgumentToJSCallback<T2>*/ Arg2Marshaler = null;
                    //--TRIMMABLE-BOUNDARY-END(12886343691)
                    
                    //--TRIMMABLE-BOUNDARY-START(17181310987)
                    /*ArgumentToJSCallback<T3>*/ Arg3Marshaler = null;
                    //--TRIMMABLE-BOUNDARY-END(17181310987)
                    
                    //--TRIMMABLE-BOUNDARY-START(25771245579)
                    /*JSObject*/ JSObject = null;
                    //--TRIMMABLE-BOUNDARY-END(25771245579)
                    
                    //--TRIMMABLE-BOUNDARY-START(4296409099)
                    $ctor$1(/*JSObject*/ holder, /*ArgumentToJSCallback<T1>*/ arg1Marshaler, /*ArgumentToJSCallback<T2>*/ arg2Marshaler, /*ArgumentToJSCallback<T3>*/ arg3Marshaler)
                    {
                        super.$ctor();
                        {
                            //--TRIMMABLE-BOUNDARY-START(TRACE)
                            $.$trace(4296409099);
                            //--TRIMMABLE-BOUNDARY-END(TRACE)
                            this.JSObject = holder;
                            this.Arg1Marshaler = arg1Marshaler;
                            this.Arg2Marshaler = arg2Marshaler;
                            this.Arg3Marshaler = arg3Marshaler;
                        }
                        return this;
                    }
                    //--TRIMMABLE-BOUNDARY-END(4296409099)
                    
                    //--TRIMMABLE-BOUNDARY-START(21476278283)
                    /*void */ InvokeJS(/*T1*/ arg1, /*T2*/ arg2, /*T3*/ arg3)
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(21476278283);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        /*Span<JSMarshalerArgument>*/ let $arguments = $.$$.System.Runtime.CompilerServices.RuntimeHelpers.StackAllocSpan($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument, 5, null);
                        /*ref JSMarshalerArgument*/ let args_exception = $arguments.get_Item(0);
                        /*ref JSMarshalerArgument*/ let args_return = $arguments.get_Item(1);
                        /*ref JSMarshalerArgument*/ let args_arg1 = $arguments.get_Item(2);
                        /*ref JSMarshalerArgument*/ let args_arg2 = $arguments.get_Item(3);
                        /*ref JSMarshalerArgument*/ let args_arg3 = $arguments.get_Item(4);
                        args_exception.$v.Initialize();
                        args_return.$v.Initialize();
                        this.Arg1Marshaler.Invoke(args_arg1, arg1);
                        this.Arg2Marshaler.Invoke(args_arg2, arg2);
                        this.Arg3Marshaler.Invoke(args_arg3, arg3);
                        $.$srij.System.Runtime.InteropServices.JavaScript.JSFunctionBinding.InvokeJSFunction(this.JSObject, $arguments);
                    }
                    //--TRIMMABLE-BOUNDARY-END(21476278283)
                    
                    static $h = 1441803;
                    static $g = 3;
                    static $f = 0b10000000011010000;
                    static $k = 1;
                    static $$md;
                    static get $md() { return this.$$md ??= {
  "b": 131073,
  "m": [
//--TRIMMABLE-BOUNDARY-START(21476278283),
    {
      "r": 65537,
      "p": [
        {
          "n": "arg1",
          "p": T1?.$h??1507328
        },
        {
          "n": "arg2",
          "p": T2?.$h??1572864
        },
        {
          "n": "arg3",
          "p": T3?.$h??1638400
        }
      ],
      "n": "InvokeJS",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x500000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(21476278283)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(8591376395),
    {
      "t": $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument.ArgumentToJSCallback$$(T1).$h,
      "n": "Arg1Marshaler",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x200000000n),
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(8591376395),
//--TRIMMABLE-BOUNDARY-START(12886343691),
    {
      "t": $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument.ArgumentToJSCallback$$(T2).$h,
      "n": "Arg2Marshaler",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x300000000n),
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(12886343691),
//--TRIMMABLE-BOUNDARY-START(17181310987),
    {
      "t": $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument.ArgumentToJSCallback$$(T3).$h,
      "n": "Arg3Marshaler",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x400000000n),
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(17181310987),
//--TRIMMABLE-BOUNDARY-START(25771245579),
    {
      "t": 2228235,
      "n": "JSObject",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x600000000n),
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(25771245579)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296409099),
    {
      "p": [
        {
          "n": "holder",
          "p": 2228235
        },
        {
          "n": "arg1Marshaler",
          "p": $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument.ArgumentToJSCallback$$(T1).$h
        },
        {
          "n": "arg2Marshaler",
          "p": $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument.ArgumentToJSCallback$$(T2).$h
        },
        {
          "n": "arg3Marshaler",
          "p": $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument.ArgumentToJSCallback$$(T3).$h
        }
      ],
      "n": ".ctor",
      "o": "$ctor$1",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x100000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296409099)
  ],
  "g": [T1?.$h??1507328,T2?.$h??1572864,T3?.$h??1638400
  ],
  "r": 3,
  "d": 1310731,
  "h": this.$h
}; }
                    static get $b() { return $.$$.System.Object; }
                    static get $fullName() { return `System.Runtime.InteropServices.JavaScript.JSMarshalerArgument.ActionJS<${T1?.$fullName},${T2?.$fullName},${T3?.$fullName}>`; }
                }), $cls, ($v) => $cls.$_ActionJS$$$$ = $v))(T1, T2, T3);
            }
            //--TRIMMABLE-BOUNDARY-END(1441803)
            
            //--TRIMMABLE-BOUNDARY-START(343598694411)
            /*void */ ToManaged(/*out Action?*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(343598694411);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (this.slot.Type === 0/*MarshalerType.None*/)
                {
                    value.$v = null;
                    return;
                }
                /*var*/ let ctx = this.ToManagedContext;
                /*var*/ let holder = ctx.CreateCSOwnedProxy(this.slot.JSHandle);
                value.$v = new $.$$.System.Action().$ctor(new $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument.ActionJS().$ctor$1(holder), new $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument.ActionJS().$ctor$1(holder).InvokeJS);
            }
            //--TRIMMABLE-BOUNDARY-END(343598694411)
            
            //--TRIMMABLE-BOUNDARY-START(523987320843)
            /*void */ ToManaged$42(T, /*out Action<T>?*/ value, /*ArgumentToJSCallback<T>*/ arg1Marshaler)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(523987320843);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (this.slot.Type === 0/*MarshalerType.None*/)
                {
                    value.$v = null;
                    return;
                }
                /*var*/ let ctx = this.ToManagedContext;
                /*var*/ let holder = ctx.CreateCSOwnedProxy(this.slot.JSHandle);
                value.$v = new ($.$$.System.Action$$(T))().$ctor(new ($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument.ActionJS$$(T))().$ctor$1(holder, arg1Marshaler), new ($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument.ActionJS$$(T))().$ctor$1(holder, arg1Marshaler).InvokeJS);
            }
            //--TRIMMABLE-BOUNDARY-END(523987320843)
            
            //--TRIMMABLE-BOUNDARY-START(545462157323)
            /*void */ ToManaged$47(T1, T2, /*out Action<T1, T2>?*/ value, /*ArgumentToJSCallback<T1>*/ arg1Marshaler, /*ArgumentToJSCallback<T2>*/ arg2Marshaler)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(545462157323);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (this.slot.Type === 0/*MarshalerType.None*/)
                {
                    value.$v = null;
                    return;
                }
                /*var*/ let ctx = this.ToManagedContext;
                /*var*/ let holder = ctx.CreateCSOwnedProxy(this.slot.JSHandle);
                value.$v = new ($.$$.System.Action$$$(T1, T2))().$ctor(new ($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument.ActionJS$$$(T1, T2))().$ctor$1(holder, arg1Marshaler, arg2Marshaler), new ($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument.ActionJS$$$(T1, T2))().$ctor$1(holder, arg1Marshaler, arg2Marshaler).InvokeJS);
            }
            //--TRIMMABLE-BOUNDARY-END(545462157323)
            
            //--TRIMMABLE-BOUNDARY-START(536872222731)
            /*void */ ToManaged$45(T1, T2, T3, /*out Action<T1, T2, T3>?*/ value, /*ArgumentToJSCallback<T1>*/ arg1Marshaler, /*ArgumentToJSCallback<T2>*/ arg2Marshaler, /*ArgumentToJSCallback<T3>*/ arg3Marshaler)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(536872222731);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (this.slot.Type === 0/*MarshalerType.None*/)
                {
                    value.$v = null;
                    return;
                }
                /*var*/ let ctx = this.ToManagedContext;
                /*var*/ let holder = ctx.CreateCSOwnedProxy(this.slot.JSHandle);
                value.$v = new ($.$$.System.Action$$$$(T1, T2, T3))().$ctor(new ($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument.ActionJS$$$$(T1, T2, T3))().$ctor$1(holder, arg1Marshaler, arg2Marshaler, arg3Marshaler), new ($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument.ActionJS$$$$(T1, T2, T3))().$ctor$1(holder, arg1Marshaler, arg2Marshaler, arg3Marshaler).InvokeJS);
            }
            //--TRIMMABLE-BOUNDARY-END(536872222731)
            
            //--TRIMMABLE-BOUNDARY-START(1966091)
            static $_FuncJS$$;
            static FuncJS$$(TResult)
            {
                let $cls = $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument;
                return ($cls.$_FuncJS$$ ??= $asm.$ncls("$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument.FuncJS<>", (TResult) => $asm.$gt("$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument.FuncJS<>", [TResult], ($self) => class FuncJS$$ extends $.$$.System.Object
                {
                    //--TRIMMABLE-BOUNDARY-START(12886867979)
                    /*JSObject*/ JSObject = null;
                    //--TRIMMABLE-BOUNDARY-END(12886867979)
                    
                    //--TRIMMABLE-BOUNDARY-START(17181835275)
                    /*ArgumentToManagedCallback<TResult>*/ ResMarshaler = null;
                    //--TRIMMABLE-BOUNDARY-END(17181835275)
                    
                    //--TRIMMABLE-BOUNDARY-START(4296933387)
                    $ctor$1(/*JSObject*/ holder, /*ArgumentToManagedCallback<TResult>*/ resMarshaler)
                    {
                        super.$ctor();
                        {
                            //--TRIMMABLE-BOUNDARY-START(TRACE)
                            $.$trace(4296933387);
                            //--TRIMMABLE-BOUNDARY-END(TRACE)
                            this.JSObject = holder;
                            this.ResMarshaler = resMarshaler;
                        }
                        return this;
                    }
                    //--TRIMMABLE-BOUNDARY-END(4296933387)
                    
                    //--TRIMMABLE-BOUNDARY-START(8591900683)
                    /*TResult */ InvokeJS()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(8591900683);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        /*Span<JSMarshalerArgument>*/ let $arguments = $.$$.System.Runtime.CompilerServices.RuntimeHelpers.StackAllocSpan($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument, 2, null);
                        /*ref JSMarshalerArgument*/ let args_exception = $arguments.get_Item(0);
                        /*ref JSMarshalerArgument*/ let args_return = $arguments.get_Item(1);
                        args_exception.$v.Initialize();
                        args_return.$v.Initialize();
                        $.$srij.System.Runtime.InteropServices.JavaScript.JSFunctionBinding.InvokeJSFunction(this.JSObject, $arguments);
                        /*TResult*/ let res;
                        this.ResMarshaler.Invoke(args_return, $.$ref(() => res, ($v) => res = $v, TResult));
                        return res;
                    }
                    //--TRIMMABLE-BOUNDARY-END(8591900683)
                    
                    static $h = 1966091;
                    static $g = 1;
                    static $f = 0b10000000011010000;
                    static $k = 1;
                    static $$md;
                    static get $md() { return this.$$md ??= {
  "b": 131073,
  "m": [
//--TRIMMABLE-BOUNDARY-START(8591900683),
    {
      "r": TResult?.$h??1507328,
      "n": "InvokeJS",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x200000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8591900683)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(12886867979),
    {
      "t": 2228235,
      "n": "JSObject",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x300000000n),
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(12886867979),
//--TRIMMABLE-BOUNDARY-START(17181835275),
    {
      "t": $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument.ArgumentToManagedCallback$$(TResult).$h,
      "n": "ResMarshaler",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x400000000n),
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(17181835275)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296933387),
    {
      "p": [
        {
          "n": "holder",
          "p": 2228235
        },
        {
          "n": "resMarshaler",
          "p": $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument.ArgumentToManagedCallback$$(TResult).$h
        }
      ],
      "n": ".ctor",
      "o": "$ctor$1",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x100000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296933387)
  ],
  "g": [TResult?.$h??1507328
  ],
  "r": 1,
  "d": 1310731,
  "h": this.$h
}; }
                    static get $b() { return $.$$.System.Object; }
                    static get $fullName() { return `System.Runtime.InteropServices.JavaScript.JSMarshalerArgument.FuncJS<${TResult?.$fullName}>`; }
                }), $cls, ($v) => $cls.$_FuncJS$$ = $v))(TResult);
            }
            //--TRIMMABLE-BOUNDARY-END(1966091)
            
            //--TRIMMABLE-BOUNDARY-START(1900555)
            static $_FuncJS$$$;
            static FuncJS$$$(T, TResult)
            {
                let $cls = $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument;
                return ($cls.$_FuncJS$$$ ??= $asm.$ncls("$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument.FuncJS<,>", (T, TResult) => $asm.$gt("$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument.FuncJS<,>", [T, TResult], ($self) => class FuncJS$$$ extends $.$$.System.Object
                {
                    //--TRIMMABLE-BOUNDARY-START(8591835147)
                    /*ArgumentToJSCallback<T>*/ Arg1Marshaler = null;
                    //--TRIMMABLE-BOUNDARY-END(8591835147)
                    
                    //--TRIMMABLE-BOUNDARY-START(21476737035)
                    /*ArgumentToManagedCallback<TResult>*/ ResMarshaler = null;
                    //--TRIMMABLE-BOUNDARY-END(21476737035)
                    
                    //--TRIMMABLE-BOUNDARY-START(17181769739)
                    /*JSObject*/ JSObject = null;
                    //--TRIMMABLE-BOUNDARY-END(17181769739)
                    
                    //--TRIMMABLE-BOUNDARY-START(4296867851)
                    $ctor$1(/*JSObject*/ holder, /*ArgumentToJSCallback<T>*/ arg1Marshaler, /*ArgumentToManagedCallback<TResult>*/ resMarshaler)
                    {
                        super.$ctor();
                        {
                            //--TRIMMABLE-BOUNDARY-START(TRACE)
                            $.$trace(4296867851);
                            //--TRIMMABLE-BOUNDARY-END(TRACE)
                            this.JSObject = holder;
                            this.Arg1Marshaler = arg1Marshaler;
                            this.ResMarshaler = resMarshaler;
                        }
                        return this;
                    }
                    //--TRIMMABLE-BOUNDARY-END(4296867851)
                    
                    //--TRIMMABLE-BOUNDARY-START(12886802443)
                    /*TResult */ InvokeJS(/*T*/ arg1)
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(12886802443);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        /*Span<JSMarshalerArgument>*/ let $arguments = $.$$.System.Runtime.CompilerServices.RuntimeHelpers.StackAllocSpan($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument, 3, null);
                        /*ref JSMarshalerArgument*/ let args_exception = $arguments.get_Item(0);
                        /*ref JSMarshalerArgument*/ let args_return = $arguments.get_Item(1);
                        /*ref JSMarshalerArgument*/ let args_arg1 = $arguments.get_Item(2);
                        args_exception.$v.Initialize();
                        args_return.$v.Initialize();
                        this.Arg1Marshaler.Invoke(args_arg1, arg1);
                        $.$srij.System.Runtime.InteropServices.JavaScript.JSFunctionBinding.InvokeJSFunction(this.JSObject, $arguments);
                        /*TResult*/ let res;
                        this.ResMarshaler.Invoke(args_return, $.$ref(() => res, ($v) => res = $v, TResult));
                        return res;
                    }
                    //--TRIMMABLE-BOUNDARY-END(12886802443)
                    
                    static $h = 1900555;
                    static $g = 2;
                    static $f = 0b10000000011010000;
                    static $k = 1;
                    static $$md;
                    static get $md() { return this.$$md ??= {
  "b": 131073,
  "m": [
//--TRIMMABLE-BOUNDARY-START(12886802443),
    {
      "r": TResult?.$h??1572864,
      "p": [
        {
          "n": "arg1",
          "p": T?.$h??1507328
        }
      ],
      "n": "InvokeJS",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x300000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(12886802443)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(8591835147),
    {
      "t": $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument.ArgumentToJSCallback$$(T).$h,
      "n": "Arg1Marshaler",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x200000000n),
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(8591835147),
//--TRIMMABLE-BOUNDARY-START(21476737035),
    {
      "t": $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument.ArgumentToManagedCallback$$(TResult).$h,
      "n": "ResMarshaler",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x500000000n),
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(21476737035),
//--TRIMMABLE-BOUNDARY-START(17181769739),
    {
      "t": 2228235,
      "n": "JSObject",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x400000000n),
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(17181769739)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296867851),
    {
      "p": [
        {
          "n": "holder",
          "p": 2228235
        },
        {
          "n": "arg1Marshaler",
          "p": $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument.ArgumentToJSCallback$$(T).$h
        },
        {
          "n": "resMarshaler",
          "p": $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument.ArgumentToManagedCallback$$(TResult).$h
        }
      ],
      "n": ".ctor",
      "o": "$ctor$1",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x100000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296867851)
  ],
  "g": [T?.$h??1507328,TResult?.$h??1572864
  ],
  "r": 2,
  "d": 1310731,
  "h": this.$h
}; }
                    static get $b() { return $.$$.System.Object; }
                    static get $fullName() { return `System.Runtime.InteropServices.JavaScript.JSMarshalerArgument.FuncJS<${T?.$fullName},${TResult?.$fullName}>`; }
                }), $cls, ($v) => $cls.$_FuncJS$$$ = $v))(T, TResult);
            }
            //--TRIMMABLE-BOUNDARY-END(1900555)
            
            //--TRIMMABLE-BOUNDARY-START(1835019)
            static $_FuncJS$$$$;
            static FuncJS$$$$(T1, T2, TResult)
            {
                let $cls = $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument;
                return ($cls.$_FuncJS$$$$ ??= $asm.$ncls("$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument.FuncJS<,,>", (T1, T2, TResult) => $asm.$gt("$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument.FuncJS<,,>", [T1, T2, TResult], ($self) => class FuncJS$$$$ extends $.$$.System.Object
                {
                    //--TRIMMABLE-BOUNDARY-START(8591769611)
                    /*ArgumentToJSCallback<T1>*/ Arg1Marshaler = null;
                    //--TRIMMABLE-BOUNDARY-END(8591769611)
                    
                    //--TRIMMABLE-BOUNDARY-START(12886736907)
                    /*ArgumentToJSCallback<T2>*/ Arg2Marshaler = null;
                    //--TRIMMABLE-BOUNDARY-END(12886736907)
                    
                    //--TRIMMABLE-BOUNDARY-START(25771638795)
                    /*ArgumentToManagedCallback<TResult>*/ ResMarshaler = null;
                    //--TRIMMABLE-BOUNDARY-END(25771638795)
                    
                    //--TRIMMABLE-BOUNDARY-START(21476671499)
                    /*JSObject*/ JSObject = null;
                    //--TRIMMABLE-BOUNDARY-END(21476671499)
                    
                    //--TRIMMABLE-BOUNDARY-START(4296802315)
                    $ctor$1(/*JSObject*/ holder, /*ArgumentToJSCallback<T1>*/ arg1Marshaler, /*ArgumentToJSCallback<T2>*/ arg2Marshaler, /*ArgumentToManagedCallback<TResult>*/ resMarshaler)
                    {
                        super.$ctor();
                        {
                            //--TRIMMABLE-BOUNDARY-START(TRACE)
                            $.$trace(4296802315);
                            //--TRIMMABLE-BOUNDARY-END(TRACE)
                            this.JSObject = holder;
                            this.Arg1Marshaler = arg1Marshaler;
                            this.Arg2Marshaler = arg2Marshaler;
                            this.ResMarshaler = resMarshaler;
                        }
                        return this;
                    }
                    //--TRIMMABLE-BOUNDARY-END(4296802315)
                    
                    //--TRIMMABLE-BOUNDARY-START(17181704203)
                    /*TResult */ InvokeJS(/*T1*/ arg1, /*T2*/ arg2)
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(17181704203);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        /*Span<JSMarshalerArgument>*/ let $arguments = $.$$.System.Runtime.CompilerServices.RuntimeHelpers.StackAllocSpan($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument, 4, null);
                        /*ref JSMarshalerArgument*/ let args_exception = $arguments.get_Item(0);
                        /*ref JSMarshalerArgument*/ let args_return = $arguments.get_Item(1);
                        /*ref JSMarshalerArgument*/ let args_arg1 = $arguments.get_Item(2);
                        /*ref JSMarshalerArgument*/ let args_arg2 = $arguments.get_Item(3);
                        args_exception.$v.Initialize();
                        args_return.$v.Initialize();
                        this.Arg1Marshaler.Invoke(args_arg1, arg1);
                        this.Arg2Marshaler.Invoke(args_arg2, arg2);
                        $.$srij.System.Runtime.InteropServices.JavaScript.JSFunctionBinding.InvokeJSFunction(this.JSObject, $arguments);
                        /*TResult*/ let res;
                        this.ResMarshaler.Invoke(args_return, $.$ref(() => res, ($v) => res = $v, TResult));
                        return res;
                    }
                    //--TRIMMABLE-BOUNDARY-END(17181704203)
                    
                    static $h = 1835019;
                    static $g = 3;
                    static $f = 0b10000000011010000;
                    static $k = 1;
                    static $$md;
                    static get $md() { return this.$$md ??= {
  "b": 131073,
  "m": [
//--TRIMMABLE-BOUNDARY-START(17181704203),
    {
      "r": TResult?.$h??1638400,
      "p": [
        {
          "n": "arg1",
          "p": T1?.$h??1507328
        },
        {
          "n": "arg2",
          "p": T2?.$h??1572864
        }
      ],
      "n": "InvokeJS",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x400000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(17181704203)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(8591769611),
    {
      "t": $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument.ArgumentToJSCallback$$(T1).$h,
      "n": "Arg1Marshaler",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x200000000n),
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(8591769611),
//--TRIMMABLE-BOUNDARY-START(12886736907),
    {
      "t": $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument.ArgumentToJSCallback$$(T2).$h,
      "n": "Arg2Marshaler",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x300000000n),
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(12886736907),
//--TRIMMABLE-BOUNDARY-START(25771638795),
    {
      "t": $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument.ArgumentToManagedCallback$$(TResult).$h,
      "n": "ResMarshaler",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x600000000n),
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(25771638795),
//--TRIMMABLE-BOUNDARY-START(21476671499),
    {
      "t": 2228235,
      "n": "JSObject",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x500000000n),
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(21476671499)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296802315),
    {
      "p": [
        {
          "n": "holder",
          "p": 2228235
        },
        {
          "n": "arg1Marshaler",
          "p": $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument.ArgumentToJSCallback$$(T1).$h
        },
        {
          "n": "arg2Marshaler",
          "p": $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument.ArgumentToJSCallback$$(T2).$h
        },
        {
          "n": "resMarshaler",
          "p": $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument.ArgumentToManagedCallback$$(TResult).$h
        }
      ],
      "n": ".ctor",
      "o": "$ctor$1",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x100000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296802315)
  ],
  "g": [T1?.$h??1507328,T2?.$h??1572864,TResult?.$h??1638400
  ],
  "r": 3,
  "d": 1310731,
  "h": this.$h
}; }
                    static get $b() { return $.$$.System.Object; }
                    static get $fullName() { return `System.Runtime.InteropServices.JavaScript.JSMarshalerArgument.FuncJS<${T1?.$fullName},${T2?.$fullName},${TResult?.$fullName}>`; }
                }), $cls, ($v) => $cls.$_FuncJS$$$$ = $v))(T1, T2, TResult);
            }
            //--TRIMMABLE-BOUNDARY-END(1835019)
            
            //--TRIMMABLE-BOUNDARY-START(1769483)
            static $_FuncJS$$$$$;
            static FuncJS$$$$$(T1, T2, T3, TResult)
            {
                let $cls = $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument;
                return ($cls.$_FuncJS$$$$$ ??= $asm.$ncls("$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument.FuncJS<,,,>", (T1, T2, T3, TResult) => $asm.$gt("$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument.FuncJS<,,,>", [T1, T2, T3, TResult], ($self) => class FuncJS$$$$$ extends $.$$.System.Object
                {
                    //--TRIMMABLE-BOUNDARY-START(8591704075)
                    /*ArgumentToJSCallback<T1>*/ Arg1Marshaler = null;
                    //--TRIMMABLE-BOUNDARY-END(8591704075)
                    
                    //--TRIMMABLE-BOUNDARY-START(12886671371)
                    /*ArgumentToJSCallback<T2>*/ Arg2Marshaler = null;
                    //--TRIMMABLE-BOUNDARY-END(12886671371)
                    
                    //--TRIMMABLE-BOUNDARY-START(17181638667)
                    /*ArgumentToJSCallback<T3>*/ Arg3Marshaler = null;
                    //--TRIMMABLE-BOUNDARY-END(17181638667)
                    
                    //--TRIMMABLE-BOUNDARY-START(30066540555)
                    /*ArgumentToManagedCallback<TResult>*/ ResMarshaler = null;
                    //--TRIMMABLE-BOUNDARY-END(30066540555)
                    
                    //--TRIMMABLE-BOUNDARY-START(25771573259)
                    /*JSObject*/ JSObject = null;
                    //--TRIMMABLE-BOUNDARY-END(25771573259)
                    
                    //--TRIMMABLE-BOUNDARY-START(4296736779)
                    $ctor$1(/*JSObject*/ holder, /*ArgumentToJSCallback<T1>*/ arg1Marshaler, /*ArgumentToJSCallback<T2>*/ arg2Marshaler, /*ArgumentToJSCallback<T3>*/ arg3Marshaler, /*ArgumentToManagedCallback<TResult>*/ resMarshaler)
                    {
                        super.$ctor();
                        {
                            //--TRIMMABLE-BOUNDARY-START(TRACE)
                            $.$trace(4296736779);
                            //--TRIMMABLE-BOUNDARY-END(TRACE)
                            this.JSObject = holder;
                            this.Arg1Marshaler = arg1Marshaler;
                            this.Arg2Marshaler = arg2Marshaler;
                            this.Arg3Marshaler = arg3Marshaler;
                            this.ResMarshaler = resMarshaler;
                        }
                        return this;
                    }
                    //--TRIMMABLE-BOUNDARY-END(4296736779)
                    
                    //--TRIMMABLE-BOUNDARY-START(21476605963)
                    /*TResult */ InvokeJS(/*T1*/ arg1, /*T2*/ arg2, /*T3*/ arg3)
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(21476605963);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        /*Span<JSMarshalerArgument>*/ let $arguments = $.$$.System.Runtime.CompilerServices.RuntimeHelpers.StackAllocSpan($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument, 5, null);
                        /*ref JSMarshalerArgument*/ let args_exception = $arguments.get_Item(0);
                        /*ref JSMarshalerArgument*/ let args_return = $arguments.get_Item(1);
                        /*ref JSMarshalerArgument*/ let args_arg1 = $arguments.get_Item(2);
                        /*ref JSMarshalerArgument*/ let args_arg2 = $arguments.get_Item(3);
                        /*ref JSMarshalerArgument*/ let args_arg3 = $arguments.get_Item(4);
                        args_exception.$v.Initialize();
                        args_return.$v.Initialize();
                        this.Arg1Marshaler.Invoke(args_arg1, arg1);
                        this.Arg2Marshaler.Invoke(args_arg2, arg2);
                        this.Arg3Marshaler.Invoke(args_arg3, arg3);
                        $.$srij.System.Runtime.InteropServices.JavaScript.JSFunctionBinding.InvokeJSFunction(this.JSObject, $arguments);
                        /*TResult*/ let res;
                        this.ResMarshaler.Invoke(args_return, $.$ref(() => res, ($v) => res = $v, TResult));
                        return res;
                    }
                    //--TRIMMABLE-BOUNDARY-END(21476605963)
                    
                    static $h = 1769483;
                    static $g = 4;
                    static $f = 0b10000000011010000;
                    static $k = 1;
                    static $$md;
                    static get $md() { return this.$$md ??= {
  "b": 131073,
  "m": [
//--TRIMMABLE-BOUNDARY-START(21476605963),
    {
      "r": TResult?.$h??1703936,
      "p": [
        {
          "n": "arg1",
          "p": T1?.$h??1507328
        },
        {
          "n": "arg2",
          "p": T2?.$h??1572864
        },
        {
          "n": "arg3",
          "p": T3?.$h??1638400
        }
      ],
      "n": "InvokeJS",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x500000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(21476605963)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(8591704075),
    {
      "t": $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument.ArgumentToJSCallback$$(T1).$h,
      "n": "Arg1Marshaler",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x200000000n),
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(8591704075),
//--TRIMMABLE-BOUNDARY-START(12886671371),
    {
      "t": $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument.ArgumentToJSCallback$$(T2).$h,
      "n": "Arg2Marshaler",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x300000000n),
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(12886671371),
//--TRIMMABLE-BOUNDARY-START(17181638667),
    {
      "t": $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument.ArgumentToJSCallback$$(T3).$h,
      "n": "Arg3Marshaler",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x400000000n),
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(17181638667),
//--TRIMMABLE-BOUNDARY-START(30066540555),
    {
      "t": $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument.ArgumentToManagedCallback$$(TResult).$h,
      "n": "ResMarshaler",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x700000000n),
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(30066540555),
//--TRIMMABLE-BOUNDARY-START(25771573259),
    {
      "t": 2228235,
      "n": "JSObject",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x600000000n),
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(25771573259)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296736779),
    {
      "p": [
        {
          "n": "holder",
          "p": 2228235
        },
        {
          "n": "arg1Marshaler",
          "p": $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument.ArgumentToJSCallback$$(T1).$h
        },
        {
          "n": "arg2Marshaler",
          "p": $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument.ArgumentToJSCallback$$(T2).$h
        },
        {
          "n": "arg3Marshaler",
          "p": $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument.ArgumentToJSCallback$$(T3).$h
        },
        {
          "n": "resMarshaler",
          "p": $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument.ArgumentToManagedCallback$$(TResult).$h
        }
      ],
      "n": ".ctor",
      "o": "$ctor$1",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x100000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296736779)
  ],
  "g": [T1?.$h??1507328,T2?.$h??1572864,T3?.$h??1638400,TResult?.$h??1703936
  ],
  "r": 4,
  "d": 1310731,
  "h": this.$h
}; }
                    static get $b() { return $.$$.System.Object; }
                    static get $fullName() { return `System.Runtime.InteropServices.JavaScript.JSMarshalerArgument.FuncJS<${T1?.$fullName},${T2?.$fullName},${T3?.$fullName},${TResult?.$fullName}>`; }
                }), $cls, ($v) => $cls.$_FuncJS$$$$$ = $v))(T1, T2, T3, TResult);
            }
            //--TRIMMABLE-BOUNDARY-END(1769483)
            
            //--TRIMMABLE-BOUNDARY-START(549757124619)
            /*void */ ToManaged$48(TResult, /*out Func<TResult>?*/ value, /*ArgumentToManagedCallback<TResult>*/ resMarshaler)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(549757124619);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (this.slot.Type === 0/*MarshalerType.None*/)
                {
                    value.$v = null;
                    return;
                }
                /*var*/ let ctx = this.ToManagedContext;
                /*var*/ let holder = ctx.CreateCSOwnedProxy(this.slot.JSHandle);
                value.$v = new ($.$$.System.Func$$(TResult))().$ctor(new ($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument.FuncJS$$(TResult))().$ctor$1(holder, resMarshaler), new ($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument.FuncJS$$(TResult))().$ctor$1(holder, resMarshaler).InvokeJS);
            }
            //--TRIMMABLE-BOUNDARY-END(549757124619)
            
            //--TRIMMABLE-BOUNDARY-START(519692353547)
            /*void */ ToManaged$41(T, TResult, /*out Func<T, TResult>?*/ value, /*ArgumentToJSCallback<T>*/ arg1Marshaler, /*ArgumentToManagedCallback<TResult>*/ resMarshaler)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(519692353547);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (this.slot.Type === 0/*MarshalerType.None*/)
                {
                    value.$v = null;
                    return;
                }
                /*var*/ let ctx = this.ToManagedContext;
                /*var*/ let holder = ctx.CreateCSOwnedProxy(this.slot.JSHandle);
                value.$v = new ($.$$.System.Func$$$(T, TResult))().$ctor(new ($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument.FuncJS$$$(T, TResult))().$ctor$1(holder, arg1Marshaler, resMarshaler), new ($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument.FuncJS$$$(T, TResult))().$ctor$1(holder, arg1Marshaler, resMarshaler).InvokeJS);
            }
            //--TRIMMABLE-BOUNDARY-END(519692353547)
            
            //--TRIMMABLE-BOUNDARY-START(541167190027)
            /*void */ ToManaged$46(T1, T2, TResult, /*out Func<T1, T2, TResult>?*/ value, /*ArgumentToJSCallback<T1>*/ arg1Marshaler, /*ArgumentToJSCallback<T2>*/ arg2Marshaler, /*ArgumentToManagedCallback<TResult>*/ resMarshaler)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(541167190027);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (this.slot.Type === 0/*MarshalerType.None*/)
                {
                    value.$v = null;
                    return;
                }
                /*var*/ let ctx = this.ToManagedContext;
                /*var*/ let holder = ctx.CreateCSOwnedProxy(this.slot.JSHandle);
                value.$v = new ($.$$.System.Func$$$$(T1, T2, TResult))().$ctor(new ($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument.FuncJS$$$$(T1, T2, TResult))().$ctor$1(holder, arg1Marshaler, arg2Marshaler, resMarshaler), new ($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument.FuncJS$$$$(T1, T2, TResult))().$ctor$1(holder, arg1Marshaler, arg2Marshaler, resMarshaler).InvokeJS);
            }
            //--TRIMMABLE-BOUNDARY-END(541167190027)
            
            //--TRIMMABLE-BOUNDARY-START(532577255435)
            /*void */ ToManaged$44(T1, T2, T3, TResult, /*out Func<T1, T2, T3, TResult>?*/ value, /*ArgumentToJSCallback<T1>*/ arg1Marshaler, /*ArgumentToJSCallback<T2>*/ arg2Marshaler, /*ArgumentToJSCallback<T3>*/ arg3Marshaler, /*ArgumentToManagedCallback<TResult>*/ resMarshaler)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(532577255435);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (this.slot.Type === 0/*MarshalerType.None*/)
                {
                    value.$v = null;
                    return;
                }
                /*var*/ let ctx = this.ToManagedContext;
                /*var*/ let holder = ctx.CreateCSOwnedProxy(this.slot.JSHandle);
                value.$v = new ($.$$.System.Func$$$$$(T1, T2, T3, TResult))().$ctor(new ($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument.FuncJS$$$$$(T1, T2, T3, TResult))().$ctor$1(holder, arg1Marshaler, arg2Marshaler, arg3Marshaler, resMarshaler), new ($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument.FuncJS$$$$$(T1, T2, T3, TResult))().$ctor$1(holder, arg1Marshaler, arg2Marshaler, arg3Marshaler, resMarshaler).InvokeJS);
            }
            //--TRIMMABLE-BOUNDARY-END(532577255435)
            
            //--TRIMMABLE-BOUNDARY-START(115965427723)
            /*void */ ToJS(/*Action*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(115965427723);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*Action*/ let cpy = value;
                /*JSHostImplementation.ToManagedCallback*/ let cb = new $.$srij.System.Runtime.InteropServices.JavaScript.JSHostImplementation.ToManagedCallback().$ctor(this,  (/*JSMarshalerArgument**/ $arguments) =>
                {
                    cpy.Invoke();
                }, {
  "r": 65537,
  "p": [
    {
      "n": "arguments",
      "p": $.$typePointer($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument).$h
    }
  ],
  "n": "",
  "d": 1310731,
  "h": 0,
  "f": 17825794
});
                this.slot.Type = 25/*MarshalerType.Function*/;
                /*var*/ let ctx = this.ToJSContext;
                this.slot.GCHandle = ctx.GetJSOwnedObjectGCHandle(cb, 2);
            }
            //--TRIMMABLE-BOUNDARY-END(115965427723)
            
            //--TRIMMABLE-BOUNDARY-START(296354054155)
            /*void */ ToJS$42(T, /*Action<T>*/ value, /*ArgumentToManagedCallback<T>*/ arg1Marshaler)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(296354054155);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*Action<T>*/ let cpy = value;
                /*JSHostImplementation.ToManagedCallback*/ let cb = new $.$srij.System.Runtime.InteropServices.JavaScript.JSHostImplementation.ToManagedCallback().$ctor(this,  (/*JSMarshalerArgument**/ $arguments) =>
                {
                    /*ref JSMarshalerArgument*/ let arg2 = $arguments.Add(3);
                    /*T*/ let arg1cs;
                    arg1Marshaler.Invoke(arg2, $.$ref(() => arg1cs, ($v) => arg1cs = $v, T));
                    cpy.Invoke(arg1cs);
                }, {
  "r": 65537,
  "p": [
    {
      "n": "arguments",
      "p": $.$typePointer($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument).$h
    }
  ],
  "n": "",
  "d": 1310731,
  "h": 0,
  "f": 17825794
});
                this.slot.Type = 24/*MarshalerType.Action*/;
                /*var*/ let ctx = this.ToJSContext;
                this.slot.GCHandle = ctx.GetJSOwnedObjectGCHandle(cb, 2);
            }
            //--TRIMMABLE-BOUNDARY-END(296354054155)
            
            //--TRIMMABLE-BOUNDARY-START(317828890635)
            /*void */ ToJS$47(T1, T2, /*Action<T1, T2>*/ value, /*ArgumentToManagedCallback<T1>*/ arg1Marshaler, /*ArgumentToManagedCallback<T2>*/ arg2Marshaler)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(317828890635);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*Action<T1, T2>*/ let cpy = value;
                /*JSHostImplementation.ToManagedCallback*/ let cb = new $.$srij.System.Runtime.InteropServices.JavaScript.JSHostImplementation.ToManagedCallback().$ctor(this,  (/*JSMarshalerArgument**/ $arguments) =>
                {
                    /*ref JSMarshalerArgument*/ let arg2 = $arguments.Add(3);
                    /*ref JSMarshalerArgument*/ let arg3 = $arguments.Add(4);
                    /*T1*/ let arg1cs;
                    arg1Marshaler.Invoke(arg2, $.$ref(() => arg1cs, ($v) => arg1cs = $v, T1));
                    /*T2*/ let arg2cs;
                    arg2Marshaler.Invoke(arg3, $.$ref(() => arg2cs, ($v) => arg2cs = $v, T2));
                    cpy.Invoke(arg1cs, arg2cs);
                }, {
  "r": 65537,
  "p": [
    {
      "n": "arguments",
      "p": $.$typePointer($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument).$h
    }
  ],
  "n": "",
  "d": 1310731,
  "h": 0,
  "f": 17825794
});
                this.slot.Type = 24/*MarshalerType.Action*/;
                /*var*/ let ctx = this.ToJSContext;
                this.slot.GCHandle = ctx.GetJSOwnedObjectGCHandle(cb, 2);
            }
            //--TRIMMABLE-BOUNDARY-END(317828890635)
            
            //--TRIMMABLE-BOUNDARY-START(309238956043)
            /*void */ ToJS$45(T1, T2, T3, /*Action<T1, T2, T3>*/ value, /*ArgumentToManagedCallback<T1>*/ arg1Marshaler, /*ArgumentToManagedCallback<T2>*/ arg2Marshaler, /*ArgumentToManagedCallback<T3>*/ arg3Marshaler)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(309238956043);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*Action<T1, T2, T3>*/ let cpy = value;
                /*JSHostImplementation.ToManagedCallback*/ let cb = new $.$srij.System.Runtime.InteropServices.JavaScript.JSHostImplementation.ToManagedCallback().$ctor(this,  (/*JSMarshalerArgument**/ $arguments) =>
                {
                    /*ref JSMarshalerArgument*/ let arg2 = $arguments.Add(3);
                    /*ref JSMarshalerArgument*/ let arg3 = $arguments.Add(4);
                    /*ref JSMarshalerArgument*/ let arg4 = $arguments.Add(5);
                    /*T1*/ let arg1cs;
                    arg1Marshaler.Invoke(arg2, $.$ref(() => arg1cs, ($v) => arg1cs = $v, T1));
                    /*T2*/ let arg2cs;
                    arg2Marshaler.Invoke(arg3, $.$ref(() => arg2cs, ($v) => arg2cs = $v, T2));
                    /*T3*/ let arg3cs;
                    arg3Marshaler.Invoke(arg4, $.$ref(() => arg3cs, ($v) => arg3cs = $v, T3));
                    cpy.Invoke(arg1cs, arg2cs, arg3cs);
                }, {
  "r": 65537,
  "p": [
    {
      "n": "arguments",
      "p": $.$typePointer($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument).$h
    }
  ],
  "n": "",
  "d": 1310731,
  "h": 0,
  "f": 17825794
});
                this.slot.Type = 24/*MarshalerType.Action*/;
                /*var*/ let ctx = this.ToJSContext;
                this.slot.GCHandle = ctx.GetJSOwnedObjectGCHandle(cb, 2);
            }
            //--TRIMMABLE-BOUNDARY-END(309238956043)
            
            //--TRIMMABLE-BOUNDARY-START(322123857931)
            /*void */ ToJS$48(TResult, /*Func<TResult>*/ value, /*ArgumentToJSCallback<TResult>*/ resMarshaler)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(322123857931);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*Func<TResult>*/ let cpy = value;
                /*JSHostImplementation.ToManagedCallback*/ let cb = new $.$srij.System.Runtime.InteropServices.JavaScript.JSHostImplementation.ToManagedCallback().$ctor(this,  (/*JSMarshalerArgument**/ $arguments) =>
                {
                    /*ref JSMarshalerArgument*/ let res = $arguments.Add(1);
                    /*TResult*/ let resCs = cpy.Invoke();
                    resMarshaler.Invoke(res, resCs);
                }, {
  "r": 65537,
  "p": [
    {
      "n": "arguments",
      "p": $.$typePointer($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument).$h
    }
  ],
  "n": "",
  "d": 1310731,
  "h": 0,
  "f": 17825794
});
                this.slot.Type = 25/*MarshalerType.Function*/;
                /*var*/ let ctx = this.ToJSContext;
                this.slot.GCHandle = ctx.GetJSOwnedObjectGCHandle(cb, 2);
            }
            //--TRIMMABLE-BOUNDARY-END(322123857931)
            
            //--TRIMMABLE-BOUNDARY-START(292059086859)
            /*void */ ToJS$41(T, TResult, /*Func<T, TResult>*/ value, /*ArgumentToManagedCallback<T>*/ arg1Marshaler, /*ArgumentToJSCallback<TResult>*/ resMarshaler)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(292059086859);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*Func<T, TResult>*/ let cpy = value;
                /*JSHostImplementation.ToManagedCallback*/ let cb = new $.$srij.System.Runtime.InteropServices.JavaScript.JSHostImplementation.ToManagedCallback().$ctor(this,  (/*JSMarshalerArgument**/ $arguments) =>
                {
                    /*ref JSMarshalerArgument*/ let res = $arguments.Add(1);
                    /*ref JSMarshalerArgument*/ let arg2 = $arguments.Add(3);
                    /*T*/ let arg1cs;
                    arg1Marshaler.Invoke(arg2, $.$ref(() => arg1cs, ($v) => arg1cs = $v, T));
                    /*TResult*/ let resCs = cpy.Invoke(arg1cs);
                    resMarshaler.Invoke(res, resCs);
                }, {
  "r": 65537,
  "p": [
    {
      "n": "arguments",
      "p": $.$typePointer($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument).$h
    }
  ],
  "n": "",
  "d": 1310731,
  "h": 0,
  "f": 17825794
});
                this.slot.Type = 25/*MarshalerType.Function*/;
                /*var*/ let ctx = this.ToJSContext;
                this.slot.GCHandle = ctx.GetJSOwnedObjectGCHandle(cb, 2);
            }
            //--TRIMMABLE-BOUNDARY-END(292059086859)
            
            //--TRIMMABLE-BOUNDARY-START(313533923339)
            /*void */ ToJS$46(T1, T2, TResult, /*Func<T1, T2, TResult>*/ value, /*ArgumentToManagedCallback<T1>*/ arg1Marshaler, /*ArgumentToManagedCallback<T2>*/ arg2Marshaler, /*ArgumentToJSCallback<TResult>*/ resMarshaler)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(313533923339);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*Func<T1, T2, TResult>*/ let cpy = value;
                /*JSHostImplementation.ToManagedCallback*/ let cb = new $.$srij.System.Runtime.InteropServices.JavaScript.JSHostImplementation.ToManagedCallback().$ctor(this,  (/*JSMarshalerArgument**/ $arguments) =>
                {
                    /*ref JSMarshalerArgument*/ let res = $arguments.Add(1);
                    /*ref JSMarshalerArgument*/ let arg2 = $arguments.Add(3);
                    /*ref JSMarshalerArgument*/ let arg3 = $arguments.Add(4);
                    /*T1*/ let arg1cs;
                    arg1Marshaler.Invoke(arg2, $.$ref(() => arg1cs, ($v) => arg1cs = $v, T1));
                    /*T2*/ let arg2cs;
                    arg2Marshaler.Invoke(arg3, $.$ref(() => arg2cs, ($v) => arg2cs = $v, T2));
                    /*TResult*/ let resCs = cpy.Invoke(arg1cs, arg2cs);
                    resMarshaler.Invoke(res, resCs);
                }, {
  "r": 65537,
  "p": [
    {
      "n": "arguments",
      "p": $.$typePointer($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument).$h
    }
  ],
  "n": "",
  "d": 1310731,
  "h": 0,
  "f": 17825794
});
                this.slot.Type = 25/*MarshalerType.Function*/;
                /*var*/ let ctx = this.ToJSContext;
                this.slot.GCHandle = ctx.GetJSOwnedObjectGCHandle(cb, 2);
            }
            //--TRIMMABLE-BOUNDARY-END(313533923339)
            
            //--TRIMMABLE-BOUNDARY-START(304943988747)
            /*void */ ToJS$44(T1, T2, T3, TResult, /*Func<T1, T2, T3, TResult>*/ value, /*ArgumentToManagedCallback<T1>*/ arg1Marshaler, /*ArgumentToManagedCallback<T2>*/ arg2Marshaler, /*ArgumentToManagedCallback<T3>*/ arg3Marshaler, /*ArgumentToJSCallback<TResult>*/ resMarshaler)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(304943988747);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*Func<T1, T2, T3, TResult>*/ let cpy = value;
                /*JSHostImplementation.ToManagedCallback*/ let cb = new $.$srij.System.Runtime.InteropServices.JavaScript.JSHostImplementation.ToManagedCallback().$ctor(this,  (/*JSMarshalerArgument**/ $arguments) =>
                {
                    /*ref JSMarshalerArgument*/ let res = $arguments.Add(1);
                    /*ref JSMarshalerArgument*/ let arg2 = $arguments.Add(3);
                    /*ref JSMarshalerArgument*/ let arg3 = $arguments.Add(4);
                    /*ref JSMarshalerArgument*/ let arg4 = $arguments.Add(5);
                    /*T1*/ let arg1cs;
                    arg1Marshaler.Invoke(arg2, $.$ref(() => arg1cs, ($v) => arg1cs = $v, T1));
                    /*T2*/ let arg2cs;
                    arg2Marshaler.Invoke(arg3, $.$ref(() => arg2cs, ($v) => arg2cs = $v, T2));
                    /*T3*/ let arg3cs;
                    arg3Marshaler.Invoke(arg4, $.$ref(() => arg3cs, ($v) => arg3cs = $v, T3));
                    /*TResult*/ let resCs = cpy.Invoke(arg1cs, arg2cs, arg3cs);
                    resMarshaler.Invoke(res, resCs);
                }, {
  "r": 65537,
  "p": [
    {
      "n": "arguments",
      "p": $.$typePointer($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument).$h
    }
  ],
  "n": "",
  "d": 1310731,
  "h": 0,
  "f": 17825794
});
                this.slot.Type = 25/*MarshalerType.Function*/;
                /*var*/ let ctx = this.ToJSContext;
                this.slot.GCHandle = ctx.GetJSOwnedObjectGCHandle(cb, 2);
            }
            //--TRIMMABLE-BOUNDARY-END(304943988747)
            
            //--TRIMMABLE-BOUNDARY-START(468152745995)
            /*void */ ToManaged$29(/*out object?*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(468152745995);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (this.slot.Type === 0/*MarshalerType.None*/)
                {
                    value.$v = null;
                }
                else if (this.slot.Type === 14/*MarshalerType.Object*/)
                {
                    value.$v = ($.$$.System.Runtime.InteropServices.GCHandle.op_Explicit$1(this.slot.GCHandle)).Target;
                }
                else if (this.slot.Type === 3/*MarshalerType.Boolean*/)
                {
                    /*bool*/ let v;
                    this.ToManaged$4($.$ref(() => v, ($v) => v = $v, $.$$.System.Boolean));
                    value.$v = $.$box(v, $.$$.System.Boolean);
                }
                else if (this.slot.Type === 10/*MarshalerType.Double*/)
                {
                    /*double*/ let v;
                    this.ToManaged$10($.$ref(() => v, ($v) => v = $v, $.$$.System.Double));
                    value.$v = $.$box(v, $.$$.System.Double);
                }
                else if (this.slot.Type === 13/*MarshalerType.JSObject*/)
                {
                    /*JSObject?*/ let val;
                    this.ToManaged$39($.$ref(() => val, ($v) => val = $v, $.$srij.System.Runtime.InteropServices.JavaScript.JSObject));
                    value.$v = val;
                }
                else if (this.slot.Type === 15/*MarshalerType.String*/)
                {
                    /*string?*/ let val;
                    this.ToManaged$35($.$ref(() => val, ($v) => val = $v, $.$$.System.String));
                    value.$v = val;
                }
                else if (this.slot.Type === 16/*MarshalerType.Exception*/)
                {
                    /*Exception?*/ let val;
                    this.ToManaged$12($.$ref(() => val, ($v) => val = $v, $.$$.System.Exception));
                    value.$v = val;
                }
                else if (this.slot.Type === 17/*MarshalerType.DateTime*/)
                {
                    /*DateTime?*/ let val;
                    this.ToManaged$21($.$ref(() => val, ($v) => val = $v, $.$typeNullable($.$$.System.DateTime)));
                    value.$v = val?.Clone() ?? null;
                }
                else if (this.slot.Type === 27/*MarshalerType.JSException*/)
                {
                    /*Exception?*/ let val;
                    this.ToManaged$12($.$ref(() => val, ($v) => val = $v, $.$$.System.Exception));
                    value.$v = val;
                }
                else if (this.slot.Type === 21/*MarshalerType.Array*/)
                {
                    if (this.slot.ElementType === 4/*MarshalerType.Byte*/)
                    {
                        /*byte[]?*/ let val;
                        this.ToManaged$6($.$ref(() => val, ($v) => val = $v, $.$typeArray($.$$.System.Byte)));
                        value.$v = val;
                    }
                    else if (this.slot.ElementType === 10/*MarshalerType.Double*/)
                    {
                        /*double[]?*/ let val;
                        this.ToManaged$11($.$ref(() => val, ($v) => val = $v, $.$typeArray($.$$.System.Double)));
                        value.$v = val;
                    }
                    else if (this.slot.ElementType === 7/*MarshalerType.Int32*/)
                    {
                        /*int[]?*/ let val;
                        this.ToManaged$15($.$ref(() => val, ($v) => val = $v, $.$typeArray($.$$.System.Int32)));
                        value.$v = val;
                    }
                    else if (this.slot.ElementType === 14/*MarshalerType.Object*/)
                    {
                        /*object?[]?*/ let val;
                        this.ToManaged$30($.$ref(() => val, ($v) => val = $v, $.$typeArray($.$$.System.Object)));
                        value.$v = val;
                    }
                    else 
                    {
                        throw new $.$$.System.NotSupportedException().$ctor$12($.$srij.System.SR.Format$6($.$srij.System.SR.ToManagedNotImplemented, $.$$.System.Enum.ToString.call(this.slot.ElementType) + "[]"));
                    }
                }
                else if (this.slot.Type === 20/*MarshalerType.Task*/ || this.slot.Type === 28/*MarshalerType.TaskResolved*/ || this.slot.Type === 29/*MarshalerType.TaskRejected*/)
                {
                    /*Task<object?>?*/ let val;
                    this.ToManaged$43($.$$.System.Object, $.$ref(() => val, ($v) => val = $v, $.$$.System.Threading.Tasks.Task$$($.$$.System.Object)), new ($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument.ArgumentToManagedCallback$$($.$$.System.Object))().$ctor($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument, /*static*/ (/*JSMarshalerArgument*/ arg, /*object?*/ value) =>
                    {
                        arg.$v.ToManaged$29(value);
                    }, {
  "r": 65537,
  "p": [
    {
      "n": "arg",
      "p": 1310731,
      "f": 4
    },
    {
      "n": "value",
      "p": 131073,
      "f": 2
    }
  ],
  "n": "",
  "d": 1310731,
  "h": 0,
  "f": 17825826
}));
                    value.$v = val;
                }
                else 
                {
                    throw new $.$$.System.NotSupportedException().$ctor$12($.$srij.System.SR.Format$6($.$srij.System.SR.ToManagedNotImplemented, $.$box(this.slot.Type, $.$srij.System.Runtime.InteropServices.JavaScript.MarshalerType)));
                }
            }
            //--TRIMMABLE-BOUNDARY-END(468152745995)
            
            //--TRIMMABLE-BOUNDARY-START(240519479307)
            /*void */ ToJS$29(/*object?*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(240519479307);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (value === null)
                {
                    this.slot.Type = 0/*MarshalerType.None*/;
                    return;
                }
                /*Type*/ let type = $.$$.System.Object.GetType.call(value);
                let ut;
                if (type.IsPrimitive)
                {
                    if ($.$$.System.Type.op_Equality$1($.$$.System.Int64.$type, type))
                    {
                        throw new $.$$.System.NotSupportedException().$ctor$12($.$srij.System.SR.Format$6($.$srij.System.SR.ToJSNotImplemented, type.FullName));
                    }
                    else if ($.$$.System.Type.op_Equality$1($.$$.System.Int32.$type, type))
                    {
                        /*var*/ let v = $.$cast(value, $.$$.System.Int32);
                        this.ToJS$14(v);
                    }
                    else if ($.$$.System.Type.op_Equality$1($.$$.System.Int16.$type, type))
                    {
                        /*var*/ let v = $.$cast(value, $.$$.System.Int16);
                        this.ToJS$13(v);
                    }
                    else if ($.$$.System.Type.op_Equality$1($.$$.System.Byte.$type, type))
                    {
                        /*var*/ let v = $.$cast(value, $.$$.System.Byte);
                        this.ToJS$5(v);
                    }
                    else if ($.$$.System.Type.op_Equality$1($.$$.System.Char.$type, type))
                    {
                        /*var*/ let v = $.$cast(value, $.$$.System.Char);
                        this.ToJS$7(v);
                    }
                    else if ($.$$.System.Type.op_Equality$1($.$$.System.Boolean.$type, type))
                    {
                        /*var*/ let v = $.$cast(value, $.$$.System.Boolean);
                        this.ToJS$4(v);
                    }
                    else if ($.$$.System.Type.op_Equality$1($.$$.System.Double.$type, type))
                    {
                        /*var*/ let v = $.$cast(value, $.$$.System.Double);
                        this.ToJS$10(v);
                    }
                    else if ($.$$.System.Type.op_Equality$1($.$$.System.Single.$type, type))
                    {
                        /*var*/ let v = $.$cast(value, $.$$.System.Single);
                        this.ToJS$31(v);
                    }
                    else if ($.$$.System.Type.op_Equality$1($.$$.System.IntPtr.$type, type))
                    {
                        /*var*/ let v = $.$cast(value, $.$$.System.IntPtr);
                        this.ToJS$17(v);
                    }
                    else 
                    {
                        throw new $.$$.System.NotSupportedException().$ctor$12($.$srij.System.SR.Format$6($.$srij.System.SR.ToJSNotImplemented, type.FullName));
                    }
                }
                else if ($.$$.System.Type.op_Equality$1($.$$.System.String.$type, type))
                {
                    /*string?*/ let str = $.$as(value, $.$$.System.String);
                    this.ToJS$35(str);
                }
                else if ($.$$.System.Type.op_Equality$1($.$$.System.DateTimeOffset.$type, type))
                {
                    /*var*/ let v = $.$cast(value, $.$$.System.DateTimeOffset);
                    this.ToJS$9(v);
                }
                else if ($.$$.System.Type.op_Equality$1($.$$.System.DateTime.$type, type))
                {
                    /*var*/ let v = $.$cast(value, $.$$.System.DateTime);
                    this.ToJS$8(v);
                }
                else if ($.$is($.$$.System.Nullable.GetUnderlyingType(type), $.$$.System.Type, { set $v(v){ ut = v; } }) && $.$$.System.Type.op_Inequality$1(ut, null))
                {
                    if ($.$$.System.Type.op_Equality$1($.$$.System.Int64.$type, ut))
                    {
                        throw new $.$$.System.NotSupportedException().$ctor$12($.$srij.System.SR.Format$6($.$srij.System.SR.ToJSNotImplemented, type.FullName));
                    }
                    else if ($.$$.System.Type.op_Equality$1($.$$.System.Int32.$type, ut))
                    {
                        /*var*/ let nv = $.$as(value, $.$typeNullable($.$$.System.Int32));
                        this.ToJS$25(nv);
                    }
                    else if ($.$$.System.Type.op_Equality$1($.$$.System.Int16.$type, ut))
                    {
                        /*var*/ let nv = $.$as(value, $.$typeNullable($.$$.System.Int16));
                        this.ToJS$24(nv);
                    }
                    else if ($.$$.System.Type.op_Equality$1($.$$.System.Byte.$type, ut))
                    {
                        /*var*/ let nv = $.$as(value, $.$typeNullable($.$$.System.Byte));
                        this.ToJS$19(nv);
                    }
                    else if ($.$$.System.Type.op_Equality$1($.$$.System.Char.$type, ut))
                    {
                        /*var*/ let nv = $.$as(value, $.$typeNullable($.$$.System.Char));
                        this.ToJS$20(nv);
                    }
                    else if ($.$$.System.Type.op_Equality$1($.$$.System.Boolean.$type, ut))
                    {
                        /*var*/ let nv = $.$as(value, $.$typeNullable($.$$.System.Boolean));
                        this.ToJS$18(nv);
                    }
                    else if ($.$$.System.Type.op_Equality$1($.$$.System.Double.$type, ut))
                    {
                        /*var*/ let nv = $.$as(value, $.$typeNullable($.$$.System.Double));
                        this.ToJS$23(nv);
                    }
                    else if ($.$$.System.Type.op_Equality$1($.$$.System.Single.$type, ut))
                    {
                        /*var*/ let nv = $.$as(value, $.$typeNullable($.$$.System.Single));
                        this.ToJS$28(nv);
                    }
                    else if ($.$$.System.Type.op_Equality$1($.$$.System.IntPtr.$type, ut))
                    {
                        /*var*/ let nv = $.$as(value, $.$typeNullable($.$$.System.IntPtr));
                        this.ToJS$27(nv);
                    }
                    else if ($.$$.System.Type.op_Equality$1($.$$.System.DateTimeOffset.$type, ut))
                    {
                        /*var*/ let nv = $.$as(value, $.$typeNullable($.$$.System.DateTimeOffset));
                        this.ToJS$22(nv?.Clone() ?? null);
                    }
                    else if ($.$$.System.Type.op_Equality$1($.$$.System.DateTime.$type, ut))
                    {
                        /*var*/ let nv = $.$as(value, $.$typeNullable($.$$.System.DateTime));
                        this.ToJS$21(nv?.Clone() ?? null);
                    }
                    else 
                    {
                        throw new $.$$.System.NotSupportedException().$ctor$12($.$srij.System.SR.Format$6($.$srij.System.SR.ToJSNotImplemented, type.FullName));
                    }
                }
                else if ($.$srij.System.Runtime.InteropServices.JavaScript.JSObject.$type.IsAssignableFrom(type))
                {
                    /*JSObject?*/ let val = $.$as(value, $.$srij.System.Runtime.InteropServices.JavaScript.JSObject);
                    this.ToJS$39(val);
                }
                else if ($.$$.System.Exception.$type.IsAssignableFrom(type))
                {
                    /*Exception?*/ let val = $.$as(value, $.$$.System.Exception);
                    this.ToJS$12(val);
                }
                else if ($.$$.System.Type.op_Equality$1($.$$.System.Threading.Tasks.Task$$($.$$.System.Object).$type, type))
                {
                    /*Task<object>?*/ let val = $.$as(value, $.$$.System.Threading.Tasks.Task$$($.$$.System.Object));
                    this.ToJS$43($.$$.System.Object, val, new ($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument.ArgumentToJSCallback$$($.$$.System.Object))().$ctor(this,  (/*JSMarshalerArgument*/ arg, /*object*/ value) =>
                    {
                        /*object?*/ let valueRef = value;
                        arg.$v.ToJS$29(valueRef);
                    }, {
  "r": 65537,
  "p": [
    {
      "n": "arg",
      "p": 1310731,
      "f": 4
    },
    {
      "n": "value",
      "p": 131073
    }
  ],
  "n": "",
  "d": 1310731,
  "h": 0,
  "f": 17825794
}));
                }
                else if ($.$$.System.Threading.Tasks.Task.$type.IsAssignableFrom(type))
                {
                    /*Task?*/ let val = $.$as(value, $.$$.System.Threading.Tasks.Task);
                    this.ToJSDynamic(val);
                }
                else if ($.$$.System.Type.op_Equality$1($.$typeArray($.$$.System.Byte).$type, type))
                {
                    /*byte[]*/ let val = $.$cast(value, $.$typeArray($.$$.System.Byte));
                    this.ToJS$6(val);
                }
                else if ($.$$.System.Type.op_Equality$1($.$typeArray($.$$.System.Int32).$type, type))
                {
                    /*int[]*/ let val = $.$cast(value, $.$typeArray($.$$.System.Int32));
                    this.ToJS$15(val);
                }
                else if ($.$$.System.Type.op_Equality$1($.$typeArray($.$$.System.Double).$type, type))
                {
                    /*double[]*/ let val = $.$cast(value, $.$typeArray($.$$.System.Double));
                    this.ToJS$11(val);
                }
                else if ($.$$.System.Type.op_Equality$1($.$typeArray($.$$.System.String).$type, type))
                {
                    /*string[]*/ let val = $.$cast(value, $.$typeArray($.$$.System.String));
                    this.ToJS$36(val);
                }
                else if ($.$$.System.Type.op_Equality$1($.$typeArray($.$$.System.Object).$type, type))
                {
                    /*object[]*/ let val = $.$cast(value, $.$typeArray($.$$.System.Object));
                    this.ToJS$30(val);
                }
                else if (type.IsArray)
                {
                    throw new $.$$.System.NotSupportedException().$ctor$12($.$srij.System.SR.Format$6($.$srij.System.SR.ToJSNotImplemented, type.FullName));
                }
                else if ($.$$.System.MulticastDelegate.$type.IsAssignableFrom(type.BaseType))
                {
                    throw new $.$$.System.NotSupportedException().$ctor$12($.$srij.System.SR.Format$6($.$srij.System.SR.ToJSNotImplemented, type.FullName));
                }
                else if (type.IsGenericType && $.$$.System.Type.op_Equality$1(type.GetGenericTypeDefinition(), $.$$.System.ArraySegment$$().$type))
                {
                    throw new $.$$.System.NotSupportedException().$ctor$12($.$srij.System.SR.Format$6($.$srij.System.SR.ToJSNotImplemented, type.FullName));
                }
                else if (type.IsGenericType && $.$$.System.Type.op_Equality$1(type.GetGenericTypeDefinition(), $.$$.System.Span$$().$type))
                {
                    throw new $.$$.System.NotSupportedException().$ctor$12($.$srij.System.SR.Format$6($.$srij.System.SR.ToJSNotImplemented, type.FullName));
                }
                else 
                {
                    this.slot.Type = 14/*MarshalerType.Object*/;
                    /*var*/ let ctx = this.ToJSContext;
                    this.slot.GCHandle = ctx.GetJSOwnedObjectGCHandle(value, 2);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(240519479307)
            
            //--TRIMMABLE-BOUNDARY-START(472447713291)
            /*void */ ToManaged$30(/*out object?[]?*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(472447713291);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (this.slot.Type === 0/*MarshalerType.None*/)
                {
                    value.$v = null;
                    return;
                }
                value.$v = $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$$.System.Object), null, [this.slot.Length], null);
                /*JSMarshalerArgument**/ let payload = $.$cast(this.slot.IntPtrValue, $.$typePointer($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument));
                for(/*int*/ let i = 0; i < this.slot.Length; i++)
                {
                    /*ref JSMarshalerArgument*/ let arg = payload.Add(i);
                    /*object?*/ let val;
                    arg.$v.ToManaged$29($.$ref(() => val, ($v) => val = $v, $.$$.System.Object));
                    $.$$.System.Array.$WriteT1.call(value.$v, val, i);
                }
                $.$srij.Interop.Runtime.DeregisterGCRoot(this.slot.IntPtrValue);
                $.$$.System.Runtime.InteropServices.Marshal.FreeHGlobal(this.slot.IntPtrValue);
            }
            //--TRIMMABLE-BOUNDARY-END(472447713291)
            
            //--TRIMMABLE-BOUNDARY-START(244814446603)
            /*void */ ToJS$30(/*object?[]*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(244814446603);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (value === null)
                {
                    this.slot.Type = 0/*MarshalerType.None*/;
                    return;
                }
                this.slot.Length = value.length;
                /*int*/ let bytes = ((value.length * $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument.$z) | 0);
                this.slot.Type = 21/*MarshalerType.Array*/;
                /*JSMarshalerArgument**/ let payload = $.$cast($.$$.System.Runtime.InteropServices.Marshal.AllocHGlobal(bytes), $.$typePointer($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument));
                $.$$.System.Runtime.CompilerServices.Unsafe.InitBlock(payload, 0, (bytes >>> 0));
                $.$srij.Interop.Runtime.RegisterGCRoot(payload, bytes, $.$$.System.IntPtr.Zero);
                for(/*int*/ let i = 0; i < this.slot.Length; i++)
                {
                    /*ref JSMarshalerArgument*/ let arg = payload.Add(i);
                    /*object?*/ let val = $.$$.System.Array.$ReadT1.call(value, i);
                    arg.$v.ToJS$29(val);
                    $.$$.System.Array.$WriteT1.call(value, val, i);
                }
                this.slot.ElementType = 14/*MarshalerType.Object*/;
                this.slot.IntPtrValue = $.$cast(payload, $.$$.System.IntPtr);
            }
            //--TRIMMABLE-BOUNDARY-END(244814446603)
            
            //--TRIMMABLE-BOUNDARY-START(55835885579)
            //default value type constructor
            $ctor$2()
            {
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(55835885579)
            
            Clone($copy)
            {
                let copy = $copy ?? new this.constructor();
                copy.slot = this.slot.Clone();
                return copy;
            }
            //default member initializer
            constructor()
            {
                super();
                //--TRIMMABLE-BOUNDARY-START(111670460427)
                this.slot = $.$default($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument.JSMarshalerArgumentImpl);
                //--TRIMMABLE-BOUNDARY-END(111670460427)
                
            }
            static $h = 1310731;
            static $z = 32;
            static $f = 0b1010000001;
            static $k = 2;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 196609,
  "p": [
//--TRIMMABLE-BOUNDARY-START(562642026507),
    {
      "p": 2293771,
      "g": {
        "r": 0,
        "d": 0,
        "h": 81605689355,
        "f": 50331656
      },
      "n": "ToManagedContext",
      "d": 1310731,
      "h": 562642026507,
      "f": 2097160
    },
//--TRIMMABLE-BOUNDARY-END(562642026507),
//--TRIMMABLE-BOUNDARY-START(335008759819),
    {
      "p": 2293771,
      "g": {
        "r": 0,
        "d": 0,
        "h": 73015754763,
        "f": 50331656
      },
      "n": "ToJSContext",
      "d": 1310731,
      "h": 335008759819,
      "f": 2097160
    },
//--TRIMMABLE-BOUNDARY-END(335008759819)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(554052091915),
    {
      "r": 65537,
      "p": [
        {
          "n": "value",
          "p": 917505,
          "f": 2
        }
      ],
      "n": "ToManagedBig",
      "d": 1310731,
      "h": 554052091915,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(554052091915),
//--TRIMMABLE-BOUNDARY-START(326418825227),
    {
      "r": 65537,
      "p": [
        {
          "n": "value",
          "p": 917505
        }
      ],
      "n": "ToJSBig",
      "d": 1310731,
      "h": 326418825227,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(326418825227),
//--TRIMMABLE-BOUNDARY-START(558347059211),
    {
      "r": 65537,
      "p": [
        {
          "n": "value",
          "p": $.$typeNullable($.$$.System.Int64).$h,
          "f": 2
        }
      ],
      "n": "ToManagedBig",
      "o": "@$1",
      "d": 1310731,
      "h": 558347059211,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(558347059211),
//--TRIMMABLE-BOUNDARY-START(330713792523),
    {
      "r": 65537,
      "p": [
        {
          "n": "value",
          "p": $.$typeNullable($.$$.System.Int64).$h
        }
      ],
      "n": "ToJSBig",
      "o": "@$1",
      "d": 1310731,
      "h": 330713792523,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(330713792523),
//--TRIMMABLE-BOUNDARY-START(373663465483),
    {
      "r": 65537,
      "p": [
        {
          "n": "value",
          "p": 458753,
          "f": 2
        }
      ],
      "n": "ToManaged",
      "o": "@$7",
      "d": 1310731,
      "h": 373663465483,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(373663465483),
//--TRIMMABLE-BOUNDARY-START(146030198795),
    {
      "r": 65537,
      "p": [
        {
          "n": "value",
          "p": 458753
        }
      ],
      "n": "ToJS",
      "o": "@$7",
      "d": 1310731,
      "h": 146030198795,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(146030198795),
//--TRIMMABLE-BOUNDARY-START(429498040331),
    {
      "r": 65537,
      "p": [
        {
          "n": "value",
          "p": $.$typeNullable($.$$.System.Char).$h,
          "f": 2
        }
      ],
      "n": "ToManaged",
      "o": "@$20",
      "d": 1310731,
      "h": 429498040331,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(429498040331),
//--TRIMMABLE-BOUNDARY-START(201864773643),
    {
      "r": 65537,
      "p": [
        {
          "n": "value",
          "p": $.$typeNullable($.$$.System.Char).$h
        }
      ],
      "n": "ToJS",
      "o": "@$20",
      "d": 1310731,
      "h": 201864773643,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(201864773643),
//--TRIMMABLE-BOUNDARY-START(476742680587),
    {
      "r": 65537,
      "p": [
        {
          "n": "value",
          "p": 1114113,
          "f": 2
        }
      ],
      "n": "ToManaged",
      "o": "@$31",
      "d": 1310731,
      "h": 476742680587,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(476742680587),
//--TRIMMABLE-BOUNDARY-START(249109413899),
    {
      "r": 65537,
      "p": [
        {
          "n": "value",
          "p": 1114113
        }
      ],
      "n": "ToJS",
      "o": "@$31",
      "d": 1310731,
      "h": 249109413899,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(249109413899),
//--TRIMMABLE-BOUNDARY-START(463857778699),
    {
      "r": 65537,
      "p": [
        {
          "n": "value",
          "p": $.$typeNullable($.$$.System.Single).$h,
          "f": 2
        }
      ],
      "n": "ToManaged",
      "o": "@$28",
      "d": 1310731,
      "h": 463857778699,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(463857778699),
//--TRIMMABLE-BOUNDARY-START(236224512011),
    {
      "r": 65537,
      "p": [
        {
          "n": "value",
          "p": $.$typeNullable($.$$.System.Single).$h
        }
      ],
      "n": "ToJS",
      "o": "@$28",
      "d": 1310731,
      "h": 236224512011,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(236224512011),
//--TRIMMABLE-BOUNDARY-START(412318171147),
    {
      "r": 65537,
      "p": [
        {
          "n": "value",
          "p": 917505,
          "f": 2
        }
      ],
      "n": "ToManaged",
      "o": "@$16",
      "d": 1310731,
      "h": 412318171147,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(412318171147),
//--TRIMMABLE-BOUNDARY-START(184684904459),
    {
      "r": 65537,
      "p": [
        {
          "n": "value",
          "p": 917505
        }
      ],
      "n": "ToJS",
      "o": "@$16",
      "d": 1310731,
      "h": 184684904459,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(184684904459),
//--TRIMMABLE-BOUNDARY-START(455267844107),
    {
      "r": 65537,
      "p": [
        {
          "n": "value",
          "p": $.$typeNullable($.$$.System.Int64).$h,
          "f": 2
        }
      ],
      "n": "ToManaged",
      "o": "@$26",
      "d": 1310731,
      "h": 455267844107,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(455267844107),
//--TRIMMABLE-BOUNDARY-START(227634577419),
    {
      "r": 65537,
      "p": [
        {
          "n": "value",
          "p": $.$typeNullable($.$$.System.Int64).$h
        }
      ],
      "n": "ToJS",
      "o": "@$26",
      "d": 1310731,
      "h": 227634577419,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(227634577419),
//--TRIMMABLE-BOUNDARY-START(94490591243),
    {
      "r": 65537,
      "n": "Initialize",
      "d": 1310731,
      "h": 94490591243,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(94490591243),
//--TRIMMABLE-BOUNDARY-START(60130852875),
    {
      "r": 2293771,
      "n": "AssertCurrentThreadContext",
      "d": 1310731,
      "h": 60130852875,
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(60130852875),
//--TRIMMABLE-BOUNDARY-START(399433269259),
    {
      "r": 65537,
      "p": [
        {
          "n": "value",
          "p": 524289,
          "f": 2
        }
      ],
      "n": "ToManaged",
      "o": "@$13",
      "d": 1310731,
      "h": 399433269259,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(399433269259),
//--TRIMMABLE-BOUNDARY-START(171800002571),
    {
      "r": 65537,
      "p": [
        {
          "n": "value",
          "p": 524289
        }
      ],
      "n": "ToJS",
      "o": "@$13",
      "d": 1310731,
      "h": 171800002571,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(171800002571),
//--TRIMMABLE-BOUNDARY-START(446677909515),
    {
      "r": 65537,
      "p": [
        {
          "n": "value",
          "p": $.$typeNullable($.$$.System.Int16).$h,
          "f": 2
        }
      ],
      "n": "ToManaged",
      "o": "@$24",
      "d": 1310731,
      "h": 446677909515,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(446677909515),
//--TRIMMABLE-BOUNDARY-START(219044642827),
    {
      "r": 65537,
      "p": [
        {
          "n": "value",
          "p": $.$typeNullable($.$$.System.Int16).$h
        }
      ],
      "n": "ToJS",
      "o": "@$24",
      "d": 1310731,
      "h": 219044642827,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(219044642827),
//--TRIMMABLE-BOUNDARY-START(386548367371),
    {
      "r": 65537,
      "p": [
        {
          "n": "value",
          "p": 1179649,
          "f": 2
        }
      ],
      "n": "ToManaged",
      "o": "@$10",
      "d": 1310731,
      "h": 386548367371,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(386548367371),
//--TRIMMABLE-BOUNDARY-START(158915100683),
    {
      "r": 65537,
      "p": [
        {
          "n": "value",
          "p": 1179649
        }
      ],
      "n": "ToJS",
      "o": "@$10",
      "d": 1310731,
      "h": 158915100683,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(158915100683),
//--TRIMMABLE-BOUNDARY-START(442382942219),
    {
      "r": 65537,
      "p": [
        {
          "n": "value",
          "p": $.$typeNullable($.$$.System.Double).$h,
          "f": 2
        }
      ],
      "n": "ToManaged",
      "o": "@$23",
      "d": 1310731,
      "h": 442382942219,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(442382942219),
//--TRIMMABLE-BOUNDARY-START(214749675531),
    {
      "r": 65537,
      "p": [
        {
          "n": "value",
          "p": $.$typeNullable($.$$.System.Double).$h
        }
      ],
      "n": "ToJS",
      "o": "@$23",
      "d": 1310731,
      "h": 214749675531,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(214749675531),
//--TRIMMABLE-BOUNDARY-START(390843334667),
    {
      "r": 65537,
      "p": [
        {
          "n": "value",
          "p": $.$typeArray($.$$.System.Double).$h,
          "f": 2
        }
      ],
      "n": "ToManaged",
      "o": "@$11",
      "d": 1310731,
      "h": 390843334667,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(390843334667),
//--TRIMMABLE-BOUNDARY-START(163210067979),
    {
      "r": 65537,
      "p": [
        {
          "n": "value",
          "p": $.$typeArray($.$$.System.Double).$h
        }
      ],
      "n": "ToJS",
      "o": "@$11",
      "d": 1310731,
      "h": 163210067979,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(163210067979),
//--TRIMMABLE-BOUNDARY-START(352188629003),
    {
      "r": 65537,
      "p": [
        {
          "n": "value",
          "p": $.$$.System.ArraySegment$$($.$$.System.Double).$h,
          "f": 2
        }
      ],
      "n": "ToManaged",
      "o": "@$2",
      "d": 1310731,
      "h": 352188629003,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(352188629003),
//--TRIMMABLE-BOUNDARY-START(124555362315),
    {
      "r": 65537,
      "p": [
        {
          "n": "value",
          "p": $.$$.System.ArraySegment$$($.$$.System.Double).$h
        }
      ],
      "n": "ToJS",
      "o": "@$2",
      "d": 1310731,
      "h": 124555362315,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(124555362315),
//--TRIMMABLE-BOUNDARY-START(485332615179),
    {
      "r": 65537,
      "p": [
        {
          "n": "value",
          "p": $.$$.System.Span$$($.$$.System.Double).$h,
          "f": 2
        }
      ],
      "n": "ToManaged",
      "o": "@$33",
      "d": 1310731,
      "h": 485332615179,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(485332615179),
//--TRIMMABLE-BOUNDARY-START(257699348491),
    {
      "r": 65537,
      "p": [
        {
          "n": "value",
          "p": $.$$.System.Span$$($.$$.System.Double).$h
        }
      ],
      "n": "ToJS",
      "o": "@$33",
      "d": 1310731,
      "h": 257699348491,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(257699348491),
//--TRIMMABLE-BOUNDARY-START(360778563595),
    {
      "r": 65537,
      "p": [
        {
          "n": "value",
          "p": 262145,
          "f": 2
        }
      ],
      "n": "ToManaged",
      "o": "@$4",
      "d": 1310731,
      "h": 360778563595,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(360778563595),
//--TRIMMABLE-BOUNDARY-START(133145296907),
    {
      "r": 65537,
      "p": [
        {
          "n": "value",
          "p": 262145
        }
      ],
      "n": "ToJS",
      "o": "@$4",
      "d": 1310731,
      "h": 133145296907,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(133145296907),
//--TRIMMABLE-BOUNDARY-START(420908105739),
    {
      "r": 65537,
      "p": [
        {
          "n": "value",
          "p": $.$typeNullable($.$$.System.Boolean).$h,
          "f": 2
        }
      ],
      "n": "ToManaged",
      "o": "@$18",
      "d": 1310731,
      "h": 420908105739,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(420908105739),
//--TRIMMABLE-BOUNDARY-START(193274839051),
    {
      "r": 65537,
      "p": [
        {
          "n": "value",
          "p": $.$typeNullable($.$$.System.Boolean).$h
        }
      ],
      "n": "ToJS",
      "o": "@$18",
      "d": 1310731,
      "h": 193274839051,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(193274839051),
//--TRIMMABLE-BOUNDARY-START(416613138443),
    {
      "r": 65537,
      "p": [
        {
          "n": "value",
          "p": 786433,
          "f": 2
        }
      ],
      "n": "ToManaged",
      "o": "@$17",
      "d": 1310731,
      "h": 416613138443,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(416613138443),
//--TRIMMABLE-BOUNDARY-START(188979871755),
    {
      "r": 65537,
      "p": [
        {
          "n": "value",
          "p": 786433
        }
      ],
      "n": "ToJS",
      "o": "@$17",
      "d": 1310731,
      "h": 188979871755,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(188979871755),
//--TRIMMABLE-BOUNDARY-START(459562811403),
    {
      "r": 65537,
      "p": [
        {
          "n": "value",
          "p": $.$typeNullable($.$$.System.IntPtr).$h,
          "f": 2
        }
      ],
      "n": "ToManaged",
      "o": "@$27",
      "d": 1310731,
      "h": 459562811403,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(459562811403),
//--TRIMMABLE-BOUNDARY-START(231929544715),
    {
      "r": 65537,
      "p": [
        {
          "n": "value",
          "p": $.$typeNullable($.$$.System.IntPtr).$h
        }
      ],
      "n": "ToJS",
      "o": "@$27",
      "d": 1310731,
      "h": 231929544715,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(231929544715),
//--TRIMMABLE-BOUNDARY-START(506807451659),
    {
      "r": 65537,
      "p": [
        {
          "n": "value",
          "p": $.$typePointer($.$$.System.Void).$h,
          "f": 2
        }
      ],
      "n": "ToManaged",
      "o": "@$38",
      "d": 1310731,
      "h": 506807451659,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(506807451659),
//--TRIMMABLE-BOUNDARY-START(279174184971),
    {
      "r": 65537,
      "p": [
        {
          "n": "value",
          "p": $.$typePointer($.$$.System.Void).$h
        }
      ],
      "n": "ToJS",
      "o": "@$38",
      "d": 1310731,
      "h": 279174184971,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(279174184971),
//--TRIMMABLE-BOUNDARY-START(493922549771),
    {
      "r": 65537,
      "p": [
        {
          "n": "value",
          "p": 1310721,
          "f": 2
        }
      ],
      "n": "ToManaged",
      "o": "@$35",
      "d": 1310731,
      "h": 493922549771,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(493922549771),
//--TRIMMABLE-BOUNDARY-START(266289283083),
    {
      "r": 65537,
      "p": [
        {
          "n": "value",
          "p": 1310721
        }
      ],
      "n": "ToJS",
      "o": "@$35",
      "d": 1310731,
      "h": 266289283083,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(266289283083),
//--TRIMMABLE-BOUNDARY-START(498217517067),
    {
      "r": 65537,
      "p": [
        {
          "n": "value",
          "p": $.$typeArray($.$$.System.String).$h,
          "f": 2
        }
      ],
      "n": "ToManaged",
      "o": "@$36",
      "d": 1310731,
      "h": 498217517067,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(498217517067),
//--TRIMMABLE-BOUNDARY-START(270584250379),
    {
      "r": 65537,
      "p": [
        {
          "n": "value",
          "p": $.$typeArray($.$$.System.String).$h
        }
      ],
      "n": "ToJS",
      "o": "@$36",
      "d": 1310731,
      "h": 270584250379,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(270584250379),
//--TRIMMABLE-BOUNDARY-START(511102418955),
    {
      "r": 65537,
      "p": [
        {
          "n": "value",
          "p": 2228235,
          "f": 2
        }
      ],
      "n": "ToManaged",
      "o": "@$39",
      "d": 1310731,
      "h": 511102418955,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(511102418955),
//--TRIMMABLE-BOUNDARY-START(283469152267),
    {
      "r": 65537,
      "p": [
        {
          "n": "value",
          "p": 2228235
        }
      ],
      "n": "ToJS",
      "o": "@$39",
      "d": 1310731,
      "h": 283469152267,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(283469152267),
//--TRIMMABLE-BOUNDARY-START(515397386251),
    {
      "r": 65537,
      "p": [
        {
          "n": "value",
          "p": $.$typeArray($.$srij.System.Runtime.InteropServices.JavaScript.JSObject).$h,
          "f": 2
        }
      ],
      "n": "ToManaged",
      "o": "@$40",
      "d": 1310731,
      "h": 515397386251,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(515397386251),
//--TRIMMABLE-BOUNDARY-START(287764119563),
    {
      "r": 65537,
      "p": [
        {
          "n": "value",
          "p": $.$typeArray($.$srij.System.Runtime.InteropServices.JavaScript.JSObject).$h
        }
      ],
      "n": "ToJS",
      "o": "@$40",
      "d": 1310731,
      "h": 287764119563,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(287764119563),
//--TRIMMABLE-BOUNDARY-START(365073530891),
    {
      "r": 65537,
      "p": [
        {
          "n": "value",
          "p": 393217,
          "f": 2
        }
      ],
      "n": "ToManaged",
      "o": "@$5",
      "d": 1310731,
      "h": 365073530891,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(365073530891),
//--TRIMMABLE-BOUNDARY-START(137440264203),
    {
      "r": 65537,
      "p": [
        {
          "n": "value",
          "p": 393217
        }
      ],
      "n": "ToJS",
      "o": "@$5",
      "d": 1310731,
      "h": 137440264203,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(137440264203),
//--TRIMMABLE-BOUNDARY-START(425203073035),
    {
      "r": 65537,
      "p": [
        {
          "n": "value",
          "p": $.$typeNullable($.$$.System.Byte).$h,
          "f": 2
        }
      ],
      "n": "ToManaged",
      "o": "@$19",
      "d": 1310731,
      "h": 425203073035,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(425203073035),
//--TRIMMABLE-BOUNDARY-START(197569806347),
    {
      "r": 65537,
      "p": [
        {
          "n": "value",
          "p": $.$typeNullable($.$$.System.Byte).$h
        }
      ],
      "n": "ToJS",
      "o": "@$19",
      "d": 1310731,
      "h": 197569806347,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(197569806347),
//--TRIMMABLE-BOUNDARY-START(369368498187),
    {
      "r": 65537,
      "p": [
        {
          "n": "value",
          "p": $.$typeArray($.$$.System.Byte).$h,
          "f": 2
        }
      ],
      "n": "ToManaged",
      "o": "@$6",
      "d": 1310731,
      "h": 369368498187,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(369368498187),
//--TRIMMABLE-BOUNDARY-START(141735231499),
    {
      "r": 65537,
      "p": [
        {
          "n": "value",
          "p": $.$typeArray($.$$.System.Byte).$h
        }
      ],
      "n": "ToJS",
      "o": "@$6",
      "d": 1310731,
      "h": 141735231499,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(141735231499),
//--TRIMMABLE-BOUNDARY-START(347893661707),
    {
      "r": 65537,
      "p": [
        {
          "n": "value",
          "p": $.$$.System.ArraySegment$$($.$$.System.Byte).$h,
          "f": 2
        }
      ],
      "n": "ToManaged",
      "o": "@$1",
      "d": 1310731,
      "h": 347893661707,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(347893661707),
//--TRIMMABLE-BOUNDARY-START(120260395019),
    {
      "r": 65537,
      "p": [
        {
          "n": "value",
          "p": $.$$.System.ArraySegment$$($.$$.System.Byte).$h
        }
      ],
      "n": "ToJS",
      "o": "@$1",
      "d": 1310731,
      "h": 120260395019,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(120260395019),
//--TRIMMABLE-BOUNDARY-START(481037647883),
    {
      "r": 65537,
      "p": [
        {
          "n": "value",
          "p": $.$$.System.Span$$($.$$.System.Byte).$h,
          "f": 2
        }
      ],
      "n": "ToManaged",
      "o": "@$32",
      "d": 1310731,
      "h": 481037647883,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(481037647883),
//--TRIMMABLE-BOUNDARY-START(253404381195),
    {
      "r": 65537,
      "p": [
        {
          "n": "value",
          "p": $.$$.System.Span$$($.$$.System.Byte).$h
        }
      ],
      "n": "ToJS",
      "o": "@$32",
      "d": 1310731,
      "h": 253404381195,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(253404381195),
//--TRIMMABLE-BOUNDARY-START(395138301963),
    {
      "r": 65537,
      "p": [
        {
          "n": "value",
          "p": 80019457,
          "f": 2
        }
      ],
      "n": "ToManaged",
      "o": "@$12",
      "d": 1310731,
      "h": 395138301963,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(395138301963),
//--TRIMMABLE-BOUNDARY-START(167505035275),
    {
      "r": 65537,
      "p": [
        {
          "n": "value",
          "p": 80019457
        }
      ],
      "n": "ToJS",
      "o": "@$12",
      "d": 1310731,
      "h": 167505035275,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(167505035275),
//--TRIMMABLE-BOUNDARY-START(403728236555),
    {
      "r": 65537,
      "p": [
        {
          "n": "value",
          "p": 655361,
          "f": 2
        }
      ],
      "n": "ToManaged",
      "o": "@$14",
      "d": 1310731,
      "h": 403728236555,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(403728236555),
//--TRIMMABLE-BOUNDARY-START(176094969867),
    {
      "r": 65537,
      "p": [
        {
          "n": "value",
          "p": 655361
        }
      ],
      "n": "ToJS",
      "o": "@$14",
      "d": 1310731,
      "h": 176094969867,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(176094969867),
//--TRIMMABLE-BOUNDARY-START(450972876811),
    {
      "r": 65537,
      "p": [
        {
          "n": "value",
          "p": $.$typeNullable($.$$.System.Int32).$h,
          "f": 2
        }
      ],
      "n": "ToManaged",
      "o": "@$25",
      "d": 1310731,
      "h": 450972876811,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(450972876811),
//--TRIMMABLE-BOUNDARY-START(223339610123),
    {
      "r": 65537,
      "p": [
        {
          "n": "value",
          "p": $.$typeNullable($.$$.System.Int32).$h
        }
      ],
      "n": "ToJS",
      "o": "@$25",
      "d": 1310731,
      "h": 223339610123,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(223339610123),
//--TRIMMABLE-BOUNDARY-START(408023203851),
    {
      "r": 65537,
      "p": [
        {
          "n": "value",
          "p": $.$typeArray($.$$.System.Int32).$h,
          "f": 2
        }
      ],
      "n": "ToManaged",
      "o": "@$15",
      "d": 1310731,
      "h": 408023203851,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(408023203851),
//--TRIMMABLE-BOUNDARY-START(180389937163),
    {
      "r": 65537,
      "p": [
        {
          "n": "value",
          "p": $.$typeArray($.$$.System.Int32).$h
        }
      ],
      "n": "ToJS",
      "o": "@$15",
      "d": 1310731,
      "h": 180389937163,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(180389937163),
//--TRIMMABLE-BOUNDARY-START(356483596299),
    {
      "r": 65537,
      "p": [
        {
          "n": "value",
          "p": $.$$.System.ArraySegment$$($.$$.System.Int32).$h,
          "f": 2
        }
      ],
      "n": "ToManaged",
      "o": "@$3",
      "d": 1310731,
      "h": 356483596299,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(356483596299),
//--TRIMMABLE-BOUNDARY-START(128850329611),
    {
      "r": 65537,
      "p": [
        {
          "n": "value",
          "p": $.$$.System.ArraySegment$$($.$$.System.Int32).$h
        }
      ],
      "n": "ToJS",
      "o": "@$3",
      "d": 1310731,
      "h": 128850329611,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(128850329611),
//--TRIMMABLE-BOUNDARY-START(489627582475),
    {
      "r": 65537,
      "p": [
        {
          "n": "value",
          "p": $.$$.System.Span$$($.$$.System.Int32).$h,
          "f": 2
        }
      ],
      "n": "ToManaged",
      "o": "@$34",
      "d": 1310731,
      "h": 489627582475,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(489627582475),
//--TRIMMABLE-BOUNDARY-START(261994315787),
    {
      "r": 65537,
      "p": [
        {
          "n": "value",
          "p": $.$$.System.Span$$($.$$.System.Int32).$h
        }
      ],
      "n": "ToJS",
      "o": "@$34",
      "d": 1310731,
      "h": 261994315787,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(261994315787),
//--TRIMMABLE-BOUNDARY-START(502512484363),
    {
      "r": 65537,
      "p": [
        {
          "n": "value",
          "p": 177668097,
          "f": 2
        }
      ],
      "n": "ToManaged",
      "o": "@$37",
      "d": 1310731,
      "h": 502512484363,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(502512484363),
//--TRIMMABLE-BOUNDARY-START(528282288139),
    {
      "r": 65537,
      "p": [
        {
          "n": "value",
          "p": (T) => $.$$.System.Threading.Tasks.Task$$(T).$h,
          "f": 2
        },
        {
          "n": "marshaler",
          "p": (T) => $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument.ArgumentToManagedCallback$$(T).$h
        }
      ],
      "g": [
        "T"
      ],
      "n": "ToManaged",
      "o": "@$43",
      "d": 1310731,
      "h": 528282288139,
      "f": 16908289
    },
//--TRIMMABLE-BOUNDARY-END(528282288139),
//--TRIMMABLE-BOUNDARY-START(339303727115),
    {
      "r": 65537,
      "p": [
        {
          "n": "value",
          "p": 177668097
        }
      ],
      "n": "ToJSDynamic",
      "d": 1310731,
      "h": 339303727115,
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(339303727115),
//--TRIMMABLE-BOUNDARY-START(274879217675),
    {
      "r": 65537,
      "p": [
        {
          "n": "value",
          "p": 177668097
        }
      ],
      "n": "ToJS",
      "o": "@$37",
      "d": 1310731,
      "h": 274879217675,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(274879217675),
//--TRIMMABLE-BOUNDARY-START(300649021451),
    {
      "r": 65537,
      "p": [
        {
          "n": "value",
          "p": (T) => $.$$.System.Threading.Tasks.Task$$(T).$h
        },
        {
          "n": "marshaler",
          "p": (T) => $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument.ArgumentToJSCallback$$(T).$h
        }
      ],
      "g": [
        "T"
      ],
      "n": "ToJS",
      "o": "@$43",
      "d": 1310731,
      "h": 300649021451,
      "f": 16908289
    },
//--TRIMMABLE-BOUNDARY-END(300649021451),
//--TRIMMABLE-BOUNDARY-START(64425820171),
    {
      "r": 262145,
      "p": [
        {
          "n": "_",
          "p": 2293771
        }
      ],
      "n": "CanMarshalTaskResultOnSameCall",
      "d": 1310731,
      "h": 64425820171,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(64425820171),
//--TRIMMABLE-BOUNDARY-START(98785558539),
    {
      "r": 65537,
      "p": [
        {
          "n": "holder",
          "p": 2228235
        },
        {
          "n": "ex",
          "p": 80019457
        }
      ],
      "n": "RejectPromise",
      "d": 1310731,
      "h": 98785558539,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(98785558539),
//--TRIMMABLE-BOUNDARY-START(107375493131),
    {
      "r": 65537,
      "p": [
        {
          "n": "holder",
          "p": 2228235
        }
      ],
      "n": "ResolveVoidPromise",
      "d": 1310731,
      "h": 107375493131,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(107375493131),
//--TRIMMABLE-BOUNDARY-START(103080525835),
    {
      "r": 65537,
      "p": [
        {
          "n": "holder",
          "p": 2228235
        },
        {
          "n": "value",
          "p": (T) => T.$h
        },
        {
          "n": "marshaler",
          "p": (T) => $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument.ArgumentToJSCallback$$(T).$h
        }
      ],
      "g": [
        "T"
      ],
      "n": "ResolvePromise",
      "d": 1310731,
      "h": 103080525835,
      "f": 16908322
    },
//--TRIMMABLE-BOUNDARY-END(103080525835),
//--TRIMMABLE-BOUNDARY-START(382253400075),
    {
      "r": 65537,
      "p": [
        {
          "n": "value",
          "p": 65470465,
          "f": 2
        }
      ],
      "n": "ToManaged",
      "o": "@$9",
      "d": 1310731,
      "h": 382253400075,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(382253400075),
//--TRIMMABLE-BOUNDARY-START(154620133387),
    {
      "r": 65537,
      "p": [
        {
          "n": "value",
          "p": 65470465
        }
      ],
      "n": "ToJS",
      "o": "@$9",
      "d": 1310731,
      "h": 154620133387,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(154620133387),
//--TRIMMABLE-BOUNDARY-START(438087974923),
    {
      "r": 65537,
      "p": [
        {
          "n": "value",
          "p": $.$typeNullable($.$$.System.DateTimeOffset).$h,
          "f": 2
        }
      ],
      "n": "ToManaged",
      "o": "@$22",
      "d": 1310731,
      "h": 438087974923,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(438087974923),
//--TRIMMABLE-BOUNDARY-START(210454708235),
    {
      "r": 65537,
      "p": [
        {
          "n": "value",
          "p": $.$typeNullable($.$$.System.DateTimeOffset).$h
        }
      ],
      "n": "ToJS",
      "o": "@$22",
      "d": 1310731,
      "h": 210454708235,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(210454708235),
//--TRIMMABLE-BOUNDARY-START(377958432779),
    {
      "r": 65537,
      "p": [
        {
          "n": "value",
          "p": 65273857,
          "f": 2
        }
      ],
      "n": "ToManaged",
      "o": "@$8",
      "d": 1310731,
      "h": 377958432779,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(377958432779),
//--TRIMMABLE-BOUNDARY-START(150325166091),
    {
      "r": 65537,
      "p": [
        {
          "n": "value",
          "p": 65273857
        }
      ],
      "n": "ToJS",
      "o": "@$8",
      "d": 1310731,
      "h": 150325166091,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(150325166091),
//--TRIMMABLE-BOUNDARY-START(433793007627),
    {
      "r": 65537,
      "p": [
        {
          "n": "value",
          "p": $.$typeNullable($.$$.System.DateTime).$h,
          "f": 2
        }
      ],
      "n": "ToManaged",
      "o": "@$21",
      "d": 1310731,
      "h": 433793007627,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(433793007627),
//--TRIMMABLE-BOUNDARY-START(206159740939),
    {
      "r": 65537,
      "p": [
        {
          "n": "value",
          "p": $.$typeNullable($.$$.System.DateTime).$h
        }
      ],
      "n": "ToJS",
      "o": "@$21",
      "d": 1310731,
      "h": 206159740939,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(206159740939),
//--TRIMMABLE-BOUNDARY-START(343598694411),
    {
      "r": 65537,
      "p": [
        {
          "n": "value",
          "p": 42401793,
          "f": 2
        }
      ],
      "n": "ToManaged",
      "d": 1310731,
      "h": 343598694411,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(343598694411),
//--TRIMMABLE-BOUNDARY-START(523987320843),
    {
      "r": 65537,
      "p": [
        {
          "n": "value",
          "p": (T) => $.$$.System.Action$$(T).$h,
          "f": 2
        },
        {
          "n": "arg1Marshaler",
          "p": (T) => $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument.ArgumentToJSCallback$$(T).$h
        }
      ],
      "g": [
        "T"
      ],
      "n": "ToManaged",
      "o": "@$42",
      "d": 1310731,
      "h": 523987320843,
      "f": 16908289
    },
//--TRIMMABLE-BOUNDARY-END(523987320843),
//--TRIMMABLE-BOUNDARY-START(545462157323),
    {
      "r": 65537,
      "p": [
        {
          "n": "value",
          "p": (T1, T2) => $.$$.System.Action$$$(T1, T2).$h,
          "f": 2
        },
        {
          "n": "arg1Marshaler",
          "p": (T1, T2) => $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument.ArgumentToJSCallback$$(T1).$h
        },
        {
          "n": "arg2Marshaler",
          "p": (T1, T2) => $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument.ArgumentToJSCallback$$(T2).$h
        }
      ],
      "g": [
        "T1",
        "T2"
      ],
      "n": "ToManaged",
      "o": "@$47",
      "d": 1310731,
      "h": 545462157323,
      "f": 16908289
    },
//--TRIMMABLE-BOUNDARY-END(545462157323),
//--TRIMMABLE-BOUNDARY-START(536872222731),
    {
      "r": 65537,
      "p": [
        {
          "n": "value",
          "p": (T1, T2, T3) => $.$$.System.Action$$$$(T1, T2, T3).$h,
          "f": 2
        },
        {
          "n": "arg1Marshaler",
          "p": (T1, T2, T3) => $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument.ArgumentToJSCallback$$(T1).$h
        },
        {
          "n": "arg2Marshaler",
          "p": (T1, T2, T3) => $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument.ArgumentToJSCallback$$(T2).$h
        },
        {
          "n": "arg3Marshaler",
          "p": (T1, T2, T3) => $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument.ArgumentToJSCallback$$(T3).$h
        }
      ],
      "g": [
        "T1",
        "T2",
        "T3"
      ],
      "n": "ToManaged",
      "o": "@$45",
      "d": 1310731,
      "h": 536872222731,
      "f": 16908289
    },
//--TRIMMABLE-BOUNDARY-END(536872222731),
//--TRIMMABLE-BOUNDARY-START(549757124619),
    {
      "r": 65537,
      "p": [
        {
          "n": "value",
          "p": (TResult) => $.$$.System.Func$$(TResult).$h,
          "f": 2
        },
        {
          "n": "resMarshaler",
          "p": (TResult) => $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument.ArgumentToManagedCallback$$(TResult).$h
        }
      ],
      "g": [
        "TResult"
      ],
      "n": "ToManaged",
      "o": "@$48",
      "d": 1310731,
      "h": 549757124619,
      "f": 16908289
    },
//--TRIMMABLE-BOUNDARY-END(549757124619),
//--TRIMMABLE-BOUNDARY-START(519692353547),
    {
      "r": 65537,
      "p": [
        {
          "n": "value",
          "p": (T, TResult) => $.$$.System.Func$$$(T, TResult).$h,
          "f": 2
        },
        {
          "n": "arg1Marshaler",
          "p": (T, TResult) => $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument.ArgumentToJSCallback$$(T).$h
        },
        {
          "n": "resMarshaler",
          "p": (T, TResult) => $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument.ArgumentToManagedCallback$$(TResult).$h
        }
      ],
      "g": [
        "T",
        "TResult"
      ],
      "n": "ToManaged",
      "o": "@$41",
      "d": 1310731,
      "h": 519692353547,
      "f": 16908289
    },
//--TRIMMABLE-BOUNDARY-END(519692353547),
//--TRIMMABLE-BOUNDARY-START(541167190027),
    {
      "r": 65537,
      "p": [
        {
          "n": "value",
          "p": (T1, T2, TResult) => $.$$.System.Func$$$$(T1, T2, TResult).$h,
          "f": 2
        },
        {
          "n": "arg1Marshaler",
          "p": (T1, T2, TResult) => $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument.ArgumentToJSCallback$$(T1).$h
        },
        {
          "n": "arg2Marshaler",
          "p": (T1, T2, TResult) => $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument.ArgumentToJSCallback$$(T2).$h
        },
        {
          "n": "resMarshaler",
          "p": (T1, T2, TResult) => $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument.ArgumentToManagedCallback$$(TResult).$h
        }
      ],
      "g": [
        "T1",
        "T2",
        "TResult"
      ],
      "n": "ToManaged",
      "o": "@$46",
      "d": 1310731,
      "h": 541167190027,
      "f": 16908289
    },
//--TRIMMABLE-BOUNDARY-END(541167190027),
//--TRIMMABLE-BOUNDARY-START(532577255435),
    {
      "r": 65537,
      "p": [
        {
          "n": "value",
          "p": (T1, T2, T3, TResult) => $.$$.System.Func$$$$$(T1, T2, T3, TResult).$h,
          "f": 2
        },
        {
          "n": "arg1Marshaler",
          "p": (T1, T2, T3, TResult) => $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument.ArgumentToJSCallback$$(T1).$h
        },
        {
          "n": "arg2Marshaler",
          "p": (T1, T2, T3, TResult) => $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument.ArgumentToJSCallback$$(T2).$h
        },
        {
          "n": "arg3Marshaler",
          "p": (T1, T2, T3, TResult) => $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument.ArgumentToJSCallback$$(T3).$h
        },
        {
          "n": "resMarshaler",
          "p": (T1, T2, T3, TResult) => $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument.ArgumentToManagedCallback$$(TResult).$h
        }
      ],
      "g": [
        "T1",
        "T2",
        "T3",
        "TResult"
      ],
      "n": "ToManaged",
      "o": "@$44",
      "d": 1310731,
      "h": 532577255435,
      "f": 16908289
    },
//--TRIMMABLE-BOUNDARY-END(532577255435),
//--TRIMMABLE-BOUNDARY-START(115965427723),
    {
      "r": 65537,
      "p": [
        {
          "n": "value",
          "p": 42401793
        }
      ],
      "n": "ToJS",
      "d": 1310731,
      "h": 115965427723,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(115965427723),
//--TRIMMABLE-BOUNDARY-START(296354054155),
    {
      "r": 65537,
      "p": [
        {
          "n": "value",
          "p": (T) => $.$$.System.Action$$(T).$h
        },
        {
          "n": "arg1Marshaler",
          "p": (T) => $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument.ArgumentToManagedCallback$$(T).$h
        }
      ],
      "g": [
        "T"
      ],
      "n": "ToJS",
      "o": "@$42",
      "d": 1310731,
      "h": 296354054155,
      "f": 16908289
    },
//--TRIMMABLE-BOUNDARY-END(296354054155),
//--TRIMMABLE-BOUNDARY-START(317828890635),
    {
      "r": 65537,
      "p": [
        {
          "n": "value",
          "p": (T1, T2) => $.$$.System.Action$$$(T1, T2).$h
        },
        {
          "n": "arg1Marshaler",
          "p": (T1, T2) => $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument.ArgumentToManagedCallback$$(T1).$h
        },
        {
          "n": "arg2Marshaler",
          "p": (T1, T2) => $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument.ArgumentToManagedCallback$$(T2).$h
        }
      ],
      "g": [
        "T1",
        "T2"
      ],
      "n": "ToJS",
      "o": "@$47",
      "d": 1310731,
      "h": 317828890635,
      "f": 16908289
    },
//--TRIMMABLE-BOUNDARY-END(317828890635),
//--TRIMMABLE-BOUNDARY-START(309238956043),
    {
      "r": 65537,
      "p": [
        {
          "n": "value",
          "p": (T1, T2, T3) => $.$$.System.Action$$$$(T1, T2, T3).$h
        },
        {
          "n": "arg1Marshaler",
          "p": (T1, T2, T3) => $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument.ArgumentToManagedCallback$$(T1).$h
        },
        {
          "n": "arg2Marshaler",
          "p": (T1, T2, T3) => $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument.ArgumentToManagedCallback$$(T2).$h
        },
        {
          "n": "arg3Marshaler",
          "p": (T1, T2, T3) => $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument.ArgumentToManagedCallback$$(T3).$h
        }
      ],
      "g": [
        "T1",
        "T2",
        "T3"
      ],
      "n": "ToJS",
      "o": "@$45",
      "d": 1310731,
      "h": 309238956043,
      "f": 16908289
    },
//--TRIMMABLE-BOUNDARY-END(309238956043),
//--TRIMMABLE-BOUNDARY-START(322123857931),
    {
      "r": 65537,
      "p": [
        {
          "n": "value",
          "p": (TResult) => $.$$.System.Func$$(TResult).$h
        },
        {
          "n": "resMarshaler",
          "p": (TResult) => $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument.ArgumentToJSCallback$$(TResult).$h
        }
      ],
      "g": [
        "TResult"
      ],
      "n": "ToJS",
      "o": "@$48",
      "d": 1310731,
      "h": 322123857931,
      "f": 16908289
    },
//--TRIMMABLE-BOUNDARY-END(322123857931),
//--TRIMMABLE-BOUNDARY-START(292059086859),
    {
      "r": 65537,
      "p": [
        {
          "n": "value",
          "p": (T, TResult) => $.$$.System.Func$$$(T, TResult).$h
        },
        {
          "n": "arg1Marshaler",
          "p": (T, TResult) => $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument.ArgumentToManagedCallback$$(T).$h
        },
        {
          "n": "resMarshaler",
          "p": (T, TResult) => $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument.ArgumentToJSCallback$$(TResult).$h
        }
      ],
      "g": [
        "T",
        "TResult"
      ],
      "n": "ToJS",
      "o": "@$41",
      "d": 1310731,
      "h": 292059086859,
      "f": 16908289
    },
//--TRIMMABLE-BOUNDARY-END(292059086859),
//--TRIMMABLE-BOUNDARY-START(313533923339),
    {
      "r": 65537,
      "p": [
        {
          "n": "value",
          "p": (T1, T2, TResult) => $.$$.System.Func$$$$(T1, T2, TResult).$h
        },
        {
          "n": "arg1Marshaler",
          "p": (T1, T2, TResult) => $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument.ArgumentToManagedCallback$$(T1).$h
        },
        {
          "n": "arg2Marshaler",
          "p": (T1, T2, TResult) => $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument.ArgumentToManagedCallback$$(T2).$h
        },
        {
          "n": "resMarshaler",
          "p": (T1, T2, TResult) => $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument.ArgumentToJSCallback$$(TResult).$h
        }
      ],
      "g": [
        "T1",
        "T2",
        "TResult"
      ],
      "n": "ToJS",
      "o": "@$46",
      "d": 1310731,
      "h": 313533923339,
      "f": 16908289
    },
//--TRIMMABLE-BOUNDARY-END(313533923339),
//--TRIMMABLE-BOUNDARY-START(304943988747),
    {
      "r": 65537,
      "p": [
        {
          "n": "value",
          "p": (T1, T2, T3, TResult) => $.$$.System.Func$$$$$(T1, T2, T3, TResult).$h
        },
        {
          "n": "arg1Marshaler",
          "p": (T1, T2, T3, TResult) => $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument.ArgumentToManagedCallback$$(T1).$h
        },
        {
          "n": "arg2Marshaler",
          "p": (T1, T2, T3, TResult) => $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument.ArgumentToManagedCallback$$(T2).$h
        },
        {
          "n": "arg3Marshaler",
          "p": (T1, T2, T3, TResult) => $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument.ArgumentToManagedCallback$$(T3).$h
        },
        {
          "n": "resMarshaler",
          "p": (T1, T2, T3, TResult) => $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument.ArgumentToJSCallback$$(TResult).$h
        }
      ],
      "g": [
        "T1",
        "T2",
        "T3",
        "TResult"
      ],
      "n": "ToJS",
      "o": "@$44",
      "d": 1310731,
      "h": 304943988747,
      "f": 16908289
    },
//--TRIMMABLE-BOUNDARY-END(304943988747),
//--TRIMMABLE-BOUNDARY-START(468152745995),
    {
      "r": 65537,
      "p": [
        {
          "n": "value",
          "p": 131073,
          "f": 2
        }
      ],
      "n": "ToManaged",
      "o": "@$29",
      "d": 1310731,
      "h": 468152745995,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(468152745995),
//--TRIMMABLE-BOUNDARY-START(240519479307),
    {
      "r": 65537,
      "p": [
        {
          "n": "value",
          "p": 131073
        }
      ],
      "n": "ToJS",
      "o": "@$29",
      "d": 1310731,
      "h": 240519479307,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(240519479307),
//--TRIMMABLE-BOUNDARY-START(472447713291),
    {
      "r": 65537,
      "p": [
        {
          "n": "value",
          "p": $.$typeArray($.$$.System.Object).$h,
          "f": 2
        }
      ],
      "n": "ToManaged",
      "o": "@$30",
      "d": 1310731,
      "h": 472447713291,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(472447713291),
//--TRIMMABLE-BOUNDARY-START(244814446603),
    {
      "r": 65537,
      "p": [
        {
          "n": "value",
          "p": $.$typeArray($.$$.System.Object).$h
        }
      ],
      "n": "ToJS",
      "o": "@$30",
      "d": 1310731,
      "h": 244814446603,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(244814446603)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(85900656651),
    {
      "t": 917505,
      "n": "I52_MAX_VALUE",
      "d": 1310731,
      "h": 85900656651,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(85900656651),
//--TRIMMABLE-BOUNDARY-START(90195623947),
    {
      "t": 917505,
      "n": "I52_MIN_VALUE",
      "d": 1310731,
      "h": 90195623947,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(90195623947),
//--TRIMMABLE-BOUNDARY-START(111670460427),
    {
      "t": 2097163,
      "n": "slot",
      "d": 1310731,
      "h": 111670460427,
      "f": 4194312
    },
//--TRIMMABLE-BOUNDARY-END(111670460427)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(55835885579),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 1310731,
      "h": 55835885579,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(55835885579)
  ],
  "j": [2097163,1703947,1638411,2031627,1376267,1572875,1507339,1441803,1966091,1900555,1835019,1769483
  ],
  "h": 1310731,
  "a": [
    {
      "t": 159055873,
      "c": 4454023169,
      "a": [
        {
          "v": "browser",
          "t": 1310721
        }
      ]
    },
    {
      "t": 54263809,
      "c": 8644198401,
      "a": [
        {
          "v": false,
          "t": 262145
        }
      ]
    },
    {
      "t": 64290817,
      "c": 12949192705,
      "a": [
        {
          "v": 1,
          "t": 64356353
        }
      ]
    }
  ]
}; }
            static get $b() { return $.$$.System.ValueType; }
            static get $fullName() { return `System.Runtime.InteropServices.JavaScript.JSMarshalerArgument`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1310731)
        
        
        //--TRIMMABLE-BOUNDARY-START(1179659)
        $asm.$cls("$srij.System.Runtime.InteropServices.JavaScript.JSImportAttribute", ($self) => class JSImportAttribute extends $.$$.System.Attribute
        {
            //--TRIMMABLE-BOUNDARY-START(21476016139)
            /*string*/ FunctionName = null;
            //--TRIMMABLE-BOUNDARY-END(21476016139)
            
            //--TRIMMABLE-BOUNDARY-START(42950852619)
            /*string?*/ ModuleName = null;
            //--TRIMMABLE-BOUNDARY-END(42950852619)
            
            //--TRIMMABLE-BOUNDARY-START(17181048843)
            $ctor$3(/*string*/ functionName)
            {
                super.$ctor$1();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(17181048843);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this.FunctionName = functionName;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(17181048843)
            
            //--TRIMMABLE-BOUNDARY-START(12886081547)
            $ctor$2(/*string*/ functionName, /*string*/ moduleName)
            {
                super.$ctor$1();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(12886081547);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this.FunctionName = functionName;
                    this.ModuleName = moduleName;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(12886081547)
            
            static $h = 1179659;
            static $f = 0b10010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 45350913,
  "p": [
//--TRIMMABLE-BOUNDARY-START(21476016139),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 30065950731,
        "f": 50331649
      },
      "n": "FunctionName",
      "d": 1179659,
      "h": 21476016139,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(21476016139),
//--TRIMMABLE-BOUNDARY-START(42950852619),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 38655885323,
        "f": 50331649
      },
      "n": "ModuleName",
      "d": 1179659,
      "h": 42950852619,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(42950852619)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(17181048843),
    {
      "p": [
        {
          "n": "functionName",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 1179659,
      "h": 17181048843,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(17181048843),
//--TRIMMABLE-BOUNDARY-START(12886081547),
    {
      "p": [
        {
          "n": "functionName",
          "p": 1310721
        },
        {
          "n": "moduleName",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 1179659,
      "h": 12886081547,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(12886081547)
  ],
  "h": 1179659,
  "a": [
    {
      "t": 45481985,
      "c": 25815285761,
      "a": [
        {
          "v": 64,
          "t": 45416449
        }
      ],
      "n": [
        {
          "n": "Inherited",
          "v": false,
          "t": 262145
        },
        {
          "n": "AllowMultiple",
          "v": false,
          "t": 262145
        }
      ]
    },
    {
      "t": 159055873,
      "c": 4454023169,
      "a": [
        {
          "v": "browser",
          "t": 1310721
        }
      ]
    }
  ]
}; }
            static get $b() { return $.$$.System.Attribute; }
            static get $fullName() { return `System.Runtime.InteropServices.JavaScript.JSImportAttribute`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1179659)
        
        
        //--TRIMMABLE-BOUNDARY-START(458763)
        $asm.$cls("$srij.System.Runtime.InteropServices.JavaScript.JSExportAttribute", ($self) => class JSExportAttribute extends $.$$.System.Attribute
        {
            //--TRIMMABLE-BOUNDARY-START(4295426059)
            $ctor$2()
            {
                super.$ctor$1();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4295426059);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295426059)
            
            static $h = 458763;
            static $f = 0b10010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 45350913,
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295426059),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 458763,
      "h": 4295426059,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295426059)
  ],
  "h": 458763,
  "a": [
    {
      "t": 45481985,
      "c": 25815285761,
      "a": [
        {
          "v": 64,
          "t": 45416449
        }
      ],
      "n": [
        {
          "n": "Inherited",
          "v": false,
          "t": 262145
        },
        {
          "n": "AllowMultiple",
          "v": false,
          "t": 262145
        }
      ]
    },
    {
      "t": 159055873,
      "c": 4454023169,
      "a": [
        {
          "v": "browser",
          "t": 1310721
        }
      ]
    }
  ]
}; }
            static get $b() { return $.$$.System.Attribute; }
            static get $fullName() { return `System.Runtime.InteropServices.JavaScript.JSExportAttribute`; }
        });
        //--TRIMMABLE-BOUNDARY-END(458763)
        
        
        //--TRIMMABLE-BOUNDARY-START(3670027)
        $asm.$str("$srij.System.Runtime.InteropServices.JavaScript.MarshalerType", ($self) => class MarshalerType extends $.$$.System.Enum
        {
            static None = 0;
            static Void = 1;
            static Discard = 2;
            static Boolean = 3;
            static Byte = 4;
            static Char = 5;
            static Int16 = 6;
            static Int32 = 7;
            static Int52 = 8;
            static BigInt64 = 9;
            static Double = 10;
            static Single = 11;
            static IntPtr = 12;
            static JSObject = 13;
            static Object = 14;
            static String = 15;
            static Exception = 16;
            static DateTime = 17;
            static DateTimeOffset = 18;
            static Nullable = 19;
            static Task = 20;
            static Array = 21;
            static ArraySegment = 22;
            static Span = 23;
            static Action = 24;
            static Function = 25;
            static DiscardNoWait = 26;
            static JSException = 27;
            static TaskResolved = 28;
            static TaskRejected = 29;
            static TaskPreCreated = 30;
            static $map;
            static get Map()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(3670027);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.$map ??= 
                {
                    "None": 0n,
                    "Void": 1n,
                    "Discard": 2n,
                    "Boolean": 3n,
                    "Byte": 4n,
                    "Char": 5n,
                    "Int16": 6n,
                    "Int32": 7n,
                    "Int52": 8n,
                    "BigInt64": 9n,
                    "Double": 10n,
                    "Single": 11n,
                    "IntPtr": 12n,
                    "JSObject": 13n,
                    "Object": 14n,
                    "String": 15n,
                    "Exception": 16n,
                    "DateTime": 17n,
                    "DateTimeOffset": 18n,
                    "Nullable": 19n,
                    "Task": 20n,
                    "Array": 21n,
                    "ArraySegment": 22n,
                    "Span": 23n,
                    "Action": 24n,
                    "Function": 25n,
                    "DiscardNoWait": 26n,
                    "JSException": 27n,
                    "TaskResolved": 28n,
                    "TaskRejected": 29n,
                    "TaskPreCreated": 30n
                };
            }
            static $h = 3670027;
            static $z = 1;
            static $f = 0b100000011010001000;
            static $k = 4;
            static get $eut() { return $.$$.System.Byte; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 1048577,
  "u": 393217,
  "l": [
//--TRIMMABLE-BOUNDARY-START(94492950539),
    {
      "t": 3670027,
      "n": "None",
      "d": 3670027,
      "h": 94492950539,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(94492950539),
//--TRIMMABLE-BOUNDARY-START(137442623499),
    {
      "t": 3670027,
      "n": "Void",
      "d": 3670027,
      "h": 137442623499,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(137442623499),
//--TRIMMABLE-BOUNDARY-START(47248310283),
    {
      "t": 3670027,
      "n": "Discard",
      "d": 3670027,
      "h": 47248310283,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(47248310283),
//--TRIMMABLE-BOUNDARY-START(25773473803),
    {
      "t": 3670027,
      "n": "Boolean",
      "d": 3670027,
      "h": 25773473803,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(25773473803),
//--TRIMMABLE-BOUNDARY-START(30068441099),
    {
      "t": 3670027,
      "n": "Byte",
      "d": 3670027,
      "h": 30068441099,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(30068441099),
//--TRIMMABLE-BOUNDARY-START(34363408395),
    {
      "t": 3670027,
      "n": "Char",
      "d": 3670027,
      "h": 34363408395,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(34363408395),
//--TRIMMABLE-BOUNDARY-START(68723146763),
    {
      "t": 3670027,
      "n": "Int16",
      "d": 3670027,
      "h": 68723146763,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(68723146763),
//--TRIMMABLE-BOUNDARY-START(73018114059),
    {
      "t": 3670027,
      "n": "Int32",
      "d": 3670027,
      "h": 73018114059,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(73018114059),
//--TRIMMABLE-BOUNDARY-START(77313081355),
    {
      "t": 3670027,
      "n": "Int52",
      "d": 3670027,
      "h": 77313081355,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(77313081355),
//--TRIMMABLE-BOUNDARY-START(21478506507),
    {
      "t": 3670027,
      "n": "BigInt64",
      "d": 3670027,
      "h": 21478506507,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(21478506507),
//--TRIMMABLE-BOUNDARY-START(55838244875),
    {
      "t": 3670027,
      "n": "Double",
      "d": 3670027,
      "h": 55838244875,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(55838244875),
//--TRIMMABLE-BOUNDARY-START(107377852427),
    {
      "t": 3670027,
      "n": "Single",
      "d": 3670027,
      "h": 107377852427,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(107377852427),
//--TRIMMABLE-BOUNDARY-START(81608048651),
    {
      "t": 3670027,
      "n": "IntPtr",
      "d": 3670027,
      "h": 81608048651,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(81608048651),
//--TRIMMABLE-BOUNDARY-START(90197983243),
    {
      "t": 3670027,
      "n": "JSObject",
      "d": 3670027,
      "h": 90197983243,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(90197983243),
//--TRIMMABLE-BOUNDARY-START(103082885131),
    {
      "t": 3670027,
      "n": "Object",
      "d": 3670027,
      "h": 103082885131,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(103082885131),
//--TRIMMABLE-BOUNDARY-START(115967787019),
    {
      "t": 3670027,
      "n": "String",
      "d": 3670027,
      "h": 115967787019,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(115967787019),
//--TRIMMABLE-BOUNDARY-START(38658375691),
    {
      "t": 3670027,
      "n": "DateTime",
      "d": 3670027,
      "h": 38658375691,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(38658375691),
//--TRIMMABLE-BOUNDARY-START(42953342987),
    {
      "t": 3670027,
      "n": "DateTimeOffset",
      "d": 3670027,
      "h": 42953342987,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(42953342987),
//--TRIMMABLE-BOUNDARY-START(98787917835),
    {
      "t": 3670027,
      "n": "Nullable",
      "d": 3670027,
      "h": 98787917835,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(98787917835),
//--TRIMMABLE-BOUNDARY-START(120262754315),
    {
      "t": 3670027,
      "n": "Task",
      "d": 3670027,
      "h": 120262754315,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(120262754315),
//--TRIMMABLE-BOUNDARY-START(12888571915),
    {
      "t": 3670027,
      "n": "Array",
      "d": 3670027,
      "h": 12888571915,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(12888571915),
//--TRIMMABLE-BOUNDARY-START(17183539211),
    {
      "t": 3670027,
      "n": "ArraySegment",
      "d": 3670027,
      "h": 17183539211,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(17183539211),
//--TRIMMABLE-BOUNDARY-START(111672819723),
    {
      "t": 3670027,
      "n": "Span",
      "d": 3670027,
      "h": 111672819723,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(111672819723),
//--TRIMMABLE-BOUNDARY-START(8593604619),
    {
      "t": 3670027,
      "n": "Action",
      "d": 3670027,
      "h": 8593604619,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(8593604619),
//--TRIMMABLE-BOUNDARY-START(64428179467),
    {
      "t": 3670027,
      "n": "Function",
      "d": 3670027,
      "h": 64428179467,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(64428179467),
//--TRIMMABLE-BOUNDARY-START(51543277579),
    {
      "t": 3670027,
      "n": "DiscardNoWait",
      "d": 3670027,
      "h": 51543277579,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(51543277579),
//--TRIMMABLE-BOUNDARY-START(133147656203),
    {
      "t": 3670027,
      "n": "TaskResolved",
      "d": 3670027,
      "h": 133147656203,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(133147656203),
//--TRIMMABLE-BOUNDARY-START(128852688907),
    {
      "t": 3670027,
      "n": "TaskRejected",
      "d": 3670027,
      "h": 128852688907,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(128852688907),
//--TRIMMABLE-BOUNDARY-START(124557721611),
    {
      "t": 3670027,
      "n": "TaskPreCreated",
      "d": 3670027,
      "h": 124557721611,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(124557721611)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4298637323),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 3670027,
      "h": 4298637323,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4298637323)
  ],
  "i": [90046465,96600065,90505217,90177537
  ],
  "h": 3670027
}; }
            static get $b() { return $.$$.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.System.IComparable, $.$$.System.ISpanFormattable, $.$$.System.IFormattable, $.$$.System.IConvertible ]; }
            static get $fullName() { return `System.Runtime.InteropServices.JavaScript.MarshalerType`; }
        });
        //--TRIMMABLE-BOUNDARY-END(3670027)
        
        
        //--TRIMMABLE-BOUNDARY-START(393227)
        $asm.$cls("$srij.System.Runtime.InteropServices.JavaScript.JSException", ($self) => class JSException extends $.$$.System.Exception
        {
            //--TRIMMABLE-BOUNDARY-START(34360131595)
            /*JSObject?*/ jsException = null;
            //--TRIMMABLE-BOUNDARY-END(34360131595)
            
            //--TRIMMABLE-BOUNDARY-START(12885295115)
            /*string?*/ combinedStackTrace = null;
            //--TRIMMABLE-BOUNDARY-END(12885295115)
            
            //--TRIMMABLE-BOUNDARY-START(8590327819)
            $ctor$6(/*string*/ msg)
            {
                super.$ctor$4(msg);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(8590327819);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this.jsException = null;
                    this.combinedStackTrace = null;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(8590327819)
            
            //--TRIMMABLE-BOUNDARY-START(4295360523)
            $ctor$5(/*string*/ msg, /*JSObject?*/ jsException)
            {
                super.$ctor$4(msg);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4295360523);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this.jsException = jsException;
                    this.combinedStackTrace = null;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295360523)
            
            //--TRIMMABLE-BOUNDARY-START(38655098891)
            /*string? */ get StackTrace()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25770197003);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$$.System.String.op_Inequality(this.combinedStackTrace, null))
                {
                    return this.combinedStackTrace;
                }
                /*var*/ let bs = super.StackTrace;
                if (this.jsException === null)
                {
                    return bs;
                }
                /*string?*/ let jsStackTrace = this.jsException.GetPropertyAsString("stack");
                this.jsException.Dispose();
                this.jsException = null;
                if ($.$$.System.String.op_Equality(jsStackTrace, null))
                {
                    this.combinedStackTrace = bs;
                    return this.combinedStackTrace;
                }
                else if ($.$$.System.String.StartsWith$3.call(jsStackTrace, this.Message + "\n"))
                {
                    jsStackTrace = $.$$.System.String.Substring$1.call(jsStackTrace, ((this.Message.length + 1) | 0));
                }
                if ($.$$.System.String.op_Equality(bs, null))
                {
                    this.combinedStackTrace = jsStackTrace;
                }
                this.combinedStackTrace = $.$$.System.String.op_Inequality(bs, null) ? bs + $.$$.System.Environment.NewLine + jsStackTrace : jsStackTrace;
                return this.combinedStackTrace;
            }
            //--TRIMMABLE-BOUNDARY-END(38655098891)
            
            //--TRIMMABLE-BOUNDARY-START(17180262411)
            static/*conventional*/ /*bool */ Equals$1(/*object?*/ obj)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17180262411);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                let other;
                return $.$is(obj, $.$srij.System.Runtime.InteropServices.JavaScript.JSException, { set $v(v){ other = v; } }) && other.jsException === this.jsException;
            }
            //Static convention instance redirect
            /*bool */ Equals$1() { return $.$srij.System.Runtime.InteropServices.JavaScript.JSException.Equals$1.apply(this, arguments); }
            //--TRIMMABLE-BOUNDARY-END(17180262411)
            
            //--TRIMMABLE-BOUNDARY-START(30065164299)
            static/*conventional*/ /*int */ GetHashCode()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(30065164299);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.jsException === null ? $.$$.System.Object.GetHashCode.call(this) : (($.$$.System.Object.GetHashCode.call(this) * $.$srij.System.Runtime.InteropServices.JavaScript.JSObject.GetHashCode.call(this.jsException)) | 0);
            }
            //Static convention instance redirect
            /*int */ GetHashCode() { return $.$srij.System.Runtime.InteropServices.JavaScript.JSException.GetHashCode.apply(this, arguments); }
            //--TRIMMABLE-BOUNDARY-END(30065164299)
            
            //--TRIMMABLE-BOUNDARY-START(42950066187)
            static/*conventional*/ /*string */ ToString()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(42950066187);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Message;
            }
            //Static convention instance redirect
            /*string */ ToString() { return $.$srij.System.Runtime.InteropServices.JavaScript.JSException.ToString.apply(this, arguments); }
            //--TRIMMABLE-BOUNDARY-END(42950066187)
            
            static $h = 393227;
            static $f = 0b10010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 80019457,
  "h": 393227
}; }
            static get $b() { return $.$$.System.Exception; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.System.Runtime.Serialization.ISerializable ]; }
            static get $fullName() { return `System.Runtime.InteropServices.JavaScript.JSException`; }
        });
        //--TRIMMABLE-BOUNDARY-END(393227)
	});
})(window, window.NetJs.$boot(), ...window.NetJs.$require("NetJs.System.Private.CoreLib", "NetJs.System.Collections", "NetJs.System.Diagnostics.Tracing", "NetJs.System.Threading", "NetJs.System.Collections.Concurrent", "NetJs.System.Memory", "NetJs.System.Private.Uri", "NetJs.System.Runtime", "NetJs.System.Threading.ThreadPool", "NetJs.System.Threading.Channels"))
//--TRIMMABLE-BOUNDARY-END(11)
