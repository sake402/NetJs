
(function ($global, $, $spc, $sc, $sdt, $st, $scc, $sm, $spu, $sr, $sttp, $stc) {
    "use strict";
    let _;
    
    
    
	$.$asm(
    "NetJs.System.Runtime.InteropServices.JavaScript", 
    {"h":60809,"f":"System.Runtime.InteropServices.JavaScript","v":"1.0.35.0","a":[{"t":114950145,"c":4409917441,"a":[{"v":"browser","t":1310721}]},{"t":115146753,"c":13000048641,"a":[{"v":".NETCoreApp,Version=v10.0","t":1310721}],"n":[{"n":"FrameworkDisplayName","v":".NET 10.0","t":1310721}]},{"t":73596929,"c":4368564225,"a":[{"v":"SIT","t":1310721}]},{"t":73662465,"c":4368629761,"a":[{"v":"Debug","t":1310721}]},{"t":74121217,"c":4369088513,"a":[{"v":"1.0.35.0","t":1310721}]},{"t":74252289,"c":4369219585,"a":[{"v":"1.0.35\u002Bf7a34a6f78fee11131301a9f55ca16a968616013","t":1310721}]},{"t":75104257,"c":4370071553,"a":[{"v":"NetJs.System.Runtime.InteropServices.JavaScript","t":1310721}]},{"t":75235329,"c":4370202625,"a":[{"v":"NetJs.System.Runtime.InteropServices.JavaScript","t":1310721}]},{"t":75366401,"c":4370333697,"a":[{"v":"1.0.35.0","t":1310721}]},{"t":115212289,"c":4410179585,"a":[{"v":"browser1.0","t":1310721}]},{"t":114950145,"c":4409917441,"a":[{"v":"browser1.0","t":1310721}]}],"m":[]},
    function($asm)
	{
        
        
        $asm.$cls("$srij.System.Runtime.InteropServices.JavaScript.JSType", ($self) => class JSType extends $.$spc.System.Object
        {
            $ctor$1()
            {
                super.$ctor();
                {
                }
                return this;
            }
            static $_Void;
            static get Void()
            {
                let $cls = $.$srij.System.Runtime.InteropServices.JavaScript.JSType;
                return $cls.$_Void ??= $asm.$ncls("$srij.System.Runtime.InteropServices.JavaScript.JSType.Void", ($self) => class Void extends $.$srij.System.Runtime.InteropServices.JavaScript.JSType
                {
                    $ctor$2()
                    {
                        super.$ctor$1();
                        {
                        }
                        return this;
                    }
                    static $h = 3665289;
                    static $f = 0b10000000010010001;
                    static $k = 1;
                    static $$md;
                    static get $md() { return this.$$md ??= {"b":2420105,"c":[{"n":".ctor","o":"$ctor$2","d":3665289,"h":4298632585,"f":8}],"d":2420105,"h":3665289}; }
                    static get $b() { return $.$srij.System.Runtime.InteropServices.JavaScript.JSType; }
                    static get $fullName() { return `System.Runtime.InteropServices.JavaScript.JSType.Void`; }
                }, $cls, ($v) => $cls.$_Void = $v);
            }
            static $_Discard;
            static get Discard()
            {
                let $cls = $.$srij.System.Runtime.InteropServices.JavaScript.JSType;
                return $cls.$_Discard ??= $asm.$ncls("$srij.System.Runtime.InteropServices.JavaScript.JSType.Discard", ($self) => class Discard extends $.$srij.System.Runtime.InteropServices.JavaScript.JSType
                {
                    $ctor$2()
                    {
                        super.$ctor$1();
                        {
                        }
                        return this;
                    }
                    static $h = 2813321;
                    static $f = 0b10000000010010001;
                    static $k = 1;
                    static $$md;
                    static get $md() { return this.$$md ??= {"b":2420105,"c":[{"n":".ctor","o":"$ctor$2","d":2813321,"h":4297780617,"f":8}],"d":2420105,"h":2813321}; }
                    static get $b() { return $.$srij.System.Runtime.InteropServices.JavaScript.JSType; }
                    static get $fullName() { return `System.Runtime.InteropServices.JavaScript.JSType.Discard`; }
                }, $cls, ($v) => $cls.$_Discard = $v);
            }
            static $_DiscardNoWait;
            static get DiscardNoWait()
            {
                let $cls = $.$srij.System.Runtime.InteropServices.JavaScript.JSType;
                return $cls.$_DiscardNoWait ??= $asm.$ncls("$srij.System.Runtime.InteropServices.JavaScript.JSType.DiscardNoWait", ($self) => class DiscardNoWait extends $.$srij.System.Runtime.InteropServices.JavaScript.JSType
                {
                    $ctor$2()
                    {
                        super.$ctor$1();
                        {
                        }
                        return this;
                    }
                    static $h = 2878857;
                    static $f = 0b10000000010010001;
                    static $k = 1;
                    static $$md;
                    static get $md() { return this.$$md ??= {"b":2420105,"c":[{"n":".ctor","o":"$ctor$2","d":2878857,"h":4297846153,"f":8}],"d":2420105,"h":2878857}; }
                    static get $b() { return $.$srij.System.Runtime.InteropServices.JavaScript.JSType; }
                    static get $fullName() { return `System.Runtime.InteropServices.JavaScript.JSType.DiscardNoWait`; }
                }, $cls, ($v) => $cls.$_DiscardNoWait = $v);
            }
            static $_Boolean;
            static get Boolean()
            {
                let $cls = $.$srij.System.Runtime.InteropServices.JavaScript.JSType;
                return $cls.$_Boolean ??= $asm.$ncls("$srij.System.Runtime.InteropServices.JavaScript.JSType.Boolean", ($self) => class Boolean extends $.$srij.System.Runtime.InteropServices.JavaScript.JSType
                {
                    $ctor$2()
                    {
                        super.$ctor$1();
                        {
                        }
                        return this;
                    }
                    static $h = 2682249;
                    static $f = 0b10000000010010001;
                    static $k = 1;
                    static $$md;
                    static get $md() { return this.$$md ??= {"b":2420105,"c":[{"n":".ctor","o":"$ctor$2","d":2682249,"h":4297649545,"f":8}],"d":2420105,"h":2682249}; }
                    static get $b() { return $.$srij.System.Runtime.InteropServices.JavaScript.JSType; }
                    static get $fullName() { return `System.Runtime.InteropServices.JavaScript.JSType.Boolean`; }
                }, $cls, ($v) => $cls.$_Boolean = $v);
            }
            static $_Number;
            static get Number()
            {
                let $cls = $.$srij.System.Runtime.InteropServices.JavaScript.JSType;
                return $cls.$_Number ??= $asm.$ncls("$srij.System.Runtime.InteropServices.JavaScript.JSType.Number", ($self) => class Number extends $.$srij.System.Runtime.InteropServices.JavaScript.JSType
                {
                    $ctor$2()
                    {
                        super.$ctor$1();
                        {
                        }
                        return this;
                    }
                    static $h = 3403145;
                    static $f = 0b10000000010010001;
                    static $k = 1;
                    static $$md;
                    static get $md() { return this.$$md ??= {"b":2420105,"c":[{"n":".ctor","o":"$ctor$2","d":3403145,"h":4298370441,"f":8}],"d":2420105,"h":3403145}; }
                    static get $b() { return $.$srij.System.Runtime.InteropServices.JavaScript.JSType; }
                    static get $fullName() { return `System.Runtime.InteropServices.JavaScript.JSType.Number`; }
                }, $cls, ($v) => $cls.$_Number = $v);
            }
            static $_BigInt;
            static get BigInt()
            {
                let $cls = $.$srij.System.Runtime.InteropServices.JavaScript.JSType;
                return $cls.$_BigInt ??= $asm.$ncls("$srij.System.Runtime.InteropServices.JavaScript.JSType.BigInt", ($self) => class BigInt extends $.$srij.System.Runtime.InteropServices.JavaScript.JSType
                {
                    $ctor$2()
                    {
                        super.$ctor$1();
                        {
                        }
                        return this;
                    }
                    static $h = 2616713;
                    static $f = 0b10000000010010001;
                    static $k = 1;
                    static $$md;
                    static get $md() { return this.$$md ??= {"b":2420105,"c":[{"n":".ctor","o":"$ctor$2","d":2616713,"h":4297584009,"f":8}],"d":2420105,"h":2616713}; }
                    static get $b() { return $.$srij.System.Runtime.InteropServices.JavaScript.JSType; }
                    static get $fullName() { return `System.Runtime.InteropServices.JavaScript.JSType.BigInt`; }
                }, $cls, ($v) => $cls.$_BigInt = $v);
            }
            static $_Date;
            static get Date()
            {
                let $cls = $.$srij.System.Runtime.InteropServices.JavaScript.JSType;
                return $cls.$_Date ??= $asm.$ncls("$srij.System.Runtime.InteropServices.JavaScript.JSType.Date", ($self) => class Date extends $.$srij.System.Runtime.InteropServices.JavaScript.JSType
                {
                    $ctor$2()
                    {
                        super.$ctor$1();
                        {
                        }
                        return this;
                    }
                    static $h = 2747785;
                    static $f = 0b10000000010010001;
                    static $k = 1;
                    static $$md;
                    static get $md() { return this.$$md ??= {"b":2420105,"c":[{"n":".ctor","o":"$ctor$2","d":2747785,"h":4297715081,"f":8}],"d":2420105,"h":2747785}; }
                    static get $b() { return $.$srij.System.Runtime.InteropServices.JavaScript.JSType; }
                    static get $fullName() { return `System.Runtime.InteropServices.JavaScript.JSType.Date`; }
                }, $cls, ($v) => $cls.$_Date = $v);
            }
            static $_String;
            static get String()
            {
                let $cls = $.$srij.System.Runtime.InteropServices.JavaScript.JSType;
                return $cls.$_String ??= $asm.$ncls("$srij.System.Runtime.InteropServices.JavaScript.JSType.String", ($self) => class String extends $.$srij.System.Runtime.InteropServices.JavaScript.JSType
                {
                    $ctor$2()
                    {
                        super.$ctor$1();
                        {
                        }
                        return this;
                    }
                    static $h = 3599753;
                    static $f = 0b10000000010010001;
                    static $k = 1;
                    static $$md;
                    static get $md() { return this.$$md ??= {"b":2420105,"c":[{"n":".ctor","o":"$ctor$2","d":3599753,"h":4298567049,"f":8}],"d":2420105,"h":3599753}; }
                    static get $b() { return $.$srij.System.Runtime.InteropServices.JavaScript.JSType; }
                    static get $fullName() { return `System.Runtime.InteropServices.JavaScript.JSType.String`; }
                }, $cls, ($v) => $cls.$_String = $v);
            }
            static $_Object;
            static get Object()
            {
                let $cls = $.$srij.System.Runtime.InteropServices.JavaScript.JSType;
                return $cls.$_Object ??= $asm.$ncls("$srij.System.Runtime.InteropServices.JavaScript.JSType.Object", ($self) => class Object extends $.$srij.System.Runtime.InteropServices.JavaScript.JSType
                {
                    $ctor$2()
                    {
                        super.$ctor$1();
                        {
                        }
                        return this;
                    }
                    static $h = 3468681;
                    static $f = 0b10000000010010001;
                    static $k = 1;
                    static $$md;
                    static get $md() { return this.$$md ??= {"b":2420105,"c":[{"n":".ctor","o":"$ctor$2","d":3468681,"h":4298435977,"f":8}],"d":2420105,"h":3468681}; }
                    static get $b() { return $.$srij.System.Runtime.InteropServices.JavaScript.JSType; }
                    static get $fullName() { return `System.Runtime.InteropServices.JavaScript.JSType.Object`; }
                }, $cls, ($v) => $cls.$_Object = $v);
            }
            static $_Error;
            static get Error()
            {
                let $cls = $.$srij.System.Runtime.InteropServices.JavaScript.JSType;
                return $cls.$_Error ??= $asm.$ncls("$srij.System.Runtime.InteropServices.JavaScript.JSType.Error", ($self) => class Error extends $.$srij.System.Runtime.InteropServices.JavaScript.JSType
                {
                    $ctor$2()
                    {
                        super.$ctor$1();
                        {
                        }
                        return this;
                    }
                    static $h = 2944393;
                    static $f = 0b10000000010010001;
                    static $k = 1;
                    static $$md;
                    static get $md() { return this.$$md ??= {"b":2420105,"c":[{"n":".ctor","o":"$ctor$2","d":2944393,"h":4297911689,"f":8}],"d":2420105,"h":2944393}; }
                    static get $b() { return $.$srij.System.Runtime.InteropServices.JavaScript.JSType; }
                    static get $fullName() { return `System.Runtime.InteropServices.JavaScript.JSType.Error`; }
                }, $cls, ($v) => $cls.$_Error = $v);
            }
            static $_MemoryView;
            static get MemoryView()
            {
                let $cls = $.$srij.System.Runtime.InteropServices.JavaScript.JSType;
                return $cls.$_MemoryView ??= $asm.$ncls("$srij.System.Runtime.InteropServices.JavaScript.JSType.MemoryView", ($self) => class MemoryView extends $.$srij.System.Runtime.InteropServices.JavaScript.JSType
                {
                    $ctor$2()
                    {
                        super.$ctor$1();
                        {
                        }
                        return this;
                    }
                    static $h = 3337609;
                    static $f = 0b10000000010010001;
                    static $k = 1;
                    static $$md;
                    static get $md() { return this.$$md ??= {"b":2420105,"c":[{"n":".ctor","o":"$ctor$2","d":3337609,"h":4298304905,"f":8}],"d":2420105,"h":3337609}; }
                    static get $b() { return $.$srij.System.Runtime.InteropServices.JavaScript.JSType; }
                    static get $fullName() { return `System.Runtime.InteropServices.JavaScript.JSType.MemoryView`; }
                }, $cls, ($v) => $cls.$_MemoryView = $v);
            }
            static $_Array$$;
            static Array$$(T)
            {
                let $cls = $.$srij.System.Runtime.InteropServices.JavaScript.JSType;
                return ($cls.$_Array$$ ??= $asm.$ncls("$srij.System.Runtime.InteropServices.JavaScript.JSType.Array<>", (T) => $asm.$gt("$srij.System.Runtime.InteropServices.JavaScript.JSType.Array<>", [T], ($self) => class Array$$ extends $.$srij.System.Runtime.InteropServices.JavaScript.JSType
                {
                    $ctor$2()
                    {
                        super.$ctor$1();
                        {
                        }
                        return this;
                    }
                    static $h = 2551177;
                    static $g = 1;
                    static $f = 0b10000000011010001;
                    static $k = 1;
                    static $$md;
                    static get $md() { return this.$$md ??= {"b":2420105,"c":[{"n":".ctor","o":"$ctor$2","d":this.$h,"h":Number(BigInt(this.$h)|0x100000000n),"f":8}],"g":[T?.$h??1507328],"r":1,"d":2420105,"h":this.$h}; }
                    static get $b() { return $.$srij.System.Runtime.InteropServices.JavaScript.JSType; }
                    static get $fullName() { return `System.Runtime.InteropServices.JavaScript.JSType.Array<${T?.$fullName}>`; }
                }), $cls, ($v) => $cls.$_Array$$ = $v))(T);
            }
            static $_Promise$$;
            static Promise$$(T)
            {
                let $cls = $.$srij.System.Runtime.InteropServices.JavaScript.JSType;
                return ($cls.$_Promise$$ ??= $asm.$ncls("$srij.System.Runtime.InteropServices.JavaScript.JSType.Promise<>", (T) => $asm.$gt("$srij.System.Runtime.InteropServices.JavaScript.JSType.Promise<>", [T], ($self) => class Promise$$ extends $.$srij.System.Runtime.InteropServices.JavaScript.JSType
                {
                    $ctor$2()
                    {
                        super.$ctor$1();
                        {
                        }
                        return this;
                    }
                    static $h = 3534217;
                    static $g = 1;
                    static $f = 0b10000000011010001;
                    static $k = 1;
                    static $$md;
                    static get $md() { return this.$$md ??= {"b":2420105,"c":[{"n":".ctor","o":"$ctor$2","d":this.$h,"h":Number(BigInt(this.$h)|0x100000000n),"f":8}],"g":[T?.$h??1507328],"r":1,"d":2420105,"h":this.$h}; }
                    static get $b() { return $.$srij.System.Runtime.InteropServices.JavaScript.JSType; }
                    static get $fullName() { return `System.Runtime.InteropServices.JavaScript.JSType.Promise<${T?.$fullName}>`; }
                }), $cls, ($v) => $cls.$_Promise$$ = $v))(T);
            }
            static $_Function;
            static get Function()
            {
                let $cls = $.$srij.System.Runtime.InteropServices.JavaScript.JSType;
                return $cls.$_Function ??= $asm.$ncls("$srij.System.Runtime.InteropServices.JavaScript.JSType.Function", ($self) => class Function extends $.$srij.System.Runtime.InteropServices.JavaScript.JSType
                {
                    $ctor$2()
                    {
                        super.$ctor$1();
                        {
                        }
                        return this;
                    }
                    static $h = 3009929;
                    static $f = 0b10000000010010001;
                    static $k = 1;
                    static $$md;
                    static get $md() { return this.$$md ??= {"b":2420105,"c":[{"n":".ctor","o":"$ctor$2","d":3009929,"h":4297977225,"f":8}],"d":2420105,"h":3009929}; }
                    static get $b() { return $.$srij.System.Runtime.InteropServices.JavaScript.JSType; }
                    static get $fullName() { return `System.Runtime.InteropServices.JavaScript.JSType.Function`; }
                }, $cls, ($v) => $cls.$_Function = $v);
            }
            static $_Function$$;
            static Function$$(T)
            {
                let $cls = $.$srij.System.Runtime.InteropServices.JavaScript.JSType;
                return ($cls.$_Function$$ ??= $asm.$ncls("$srij.System.Runtime.InteropServices.JavaScript.JSType.Function<>", (T) => $asm.$gt("$srij.System.Runtime.InteropServices.JavaScript.JSType.Function<>", [T], ($self) => class Function$$ extends $.$srij.System.Runtime.InteropServices.JavaScript.JSType
                {
                    $ctor$2()
                    {
                        super.$ctor$1();
                        {
                        }
                        return this;
                    }
                    static $h = 3272073;
                    static $g = 1;
                    static $f = 0b10000000011010001;
                    static $k = 1;
                    static $$md;
                    static get $md() { return this.$$md ??= {"b":2420105,"c":[{"n":".ctor","o":"$ctor$2","d":this.$h,"h":Number(BigInt(this.$h)|0x100000000n),"f":8}],"g":[T?.$h??1507328],"r":1,"d":2420105,"h":this.$h}; }
                    static get $b() { return $.$srij.System.Runtime.InteropServices.JavaScript.JSType; }
                    static get $fullName() { return `System.Runtime.InteropServices.JavaScript.JSType.Function<${T?.$fullName}>`; }
                }), $cls, ($v) => $cls.$_Function$$ = $v))(T);
            }
            static $_Function$$$;
            static Function$$$(T1, T2)
            {
                let $cls = $.$srij.System.Runtime.InteropServices.JavaScript.JSType;
                return ($cls.$_Function$$$ ??= $asm.$ncls("$srij.System.Runtime.InteropServices.JavaScript.JSType.Function<,>", (T1, T2) => $asm.$gt("$srij.System.Runtime.InteropServices.JavaScript.JSType.Function<,>", [T1, T2], ($self) => class Function$$$ extends $.$srij.System.Runtime.InteropServices.JavaScript.JSType
                {
                    $ctor$2()
                    {
                        super.$ctor$1();
                        {
                        }
                        return this;
                    }
                    static $h = 3206537;
                    static $g = 2;
                    static $f = 0b10000000011010001;
                    static $k = 1;
                    static $$md;
                    static get $md() { return this.$$md ??= {"b":2420105,"c":[{"n":".ctor","o":"$ctor$2","d":this.$h,"h":Number(BigInt(this.$h)|0x100000000n),"f":8}],"g":[T1?.$h??1507328,T2?.$h??1572864],"r":2,"d":2420105,"h":this.$h}; }
                    static get $b() { return $.$srij.System.Runtime.InteropServices.JavaScript.JSType; }
                    static get $fullName() { return `System.Runtime.InteropServices.JavaScript.JSType.Function<${T1?.$fullName},${T2?.$fullName}>`; }
                }), $cls, ($v) => $cls.$_Function$$$ = $v))(T1, T2);
            }
            static $_Function$$$$;
            static Function$$$$(T1, T2, T3)
            {
                let $cls = $.$srij.System.Runtime.InteropServices.JavaScript.JSType;
                return ($cls.$_Function$$$$ ??= $asm.$ncls("$srij.System.Runtime.InteropServices.JavaScript.JSType.Function<,,>", (T1, T2, T3) => $asm.$gt("$srij.System.Runtime.InteropServices.JavaScript.JSType.Function<,,>", [T1, T2, T3], ($self) => class Function$$$$ extends $.$srij.System.Runtime.InteropServices.JavaScript.JSType
                {
                    $ctor$2()
                    {
                        super.$ctor$1();
                        {
                        }
                        return this;
                    }
                    static $h = 3141001;
                    static $g = 3;
                    static $f = 0b10000000011010001;
                    static $k = 1;
                    static $$md;
                    static get $md() { return this.$$md ??= {"b":2420105,"c":[{"n":".ctor","o":"$ctor$2","d":this.$h,"h":Number(BigInt(this.$h)|0x100000000n),"f":8}],"g":[T1?.$h??1507328,T2?.$h??1572864,T3?.$h??1638400],"r":3,"d":2420105,"h":this.$h}; }
                    static get $b() { return $.$srij.System.Runtime.InteropServices.JavaScript.JSType; }
                    static get $fullName() { return `System.Runtime.InteropServices.JavaScript.JSType.Function<${T1?.$fullName},${T2?.$fullName},${T3?.$fullName}>`; }
                }), $cls, ($v) => $cls.$_Function$$$$ = $v))(T1, T2, T3);
            }
            static $_Function$$$$$;
            static Function$$$$$(T1, T2, T3, T4)
            {
                let $cls = $.$srij.System.Runtime.InteropServices.JavaScript.JSType;
                return ($cls.$_Function$$$$$ ??= $asm.$ncls("$srij.System.Runtime.InteropServices.JavaScript.JSType.Function<,,,>", (T1, T2, T3, T4) => $asm.$gt("$srij.System.Runtime.InteropServices.JavaScript.JSType.Function<,,,>", [T1, T2, T3, T4], ($self) => class Function$$$$$ extends $.$srij.System.Runtime.InteropServices.JavaScript.JSType
                {
                    $ctor$2()
                    {
                        super.$ctor$1();
                        {
                        }
                        return this;
                    }
                    static $h = 3075465;
                    static $g = 4;
                    static $f = 0b10000000011010001;
                    static $k = 1;
                    static $$md;
                    static get $md() { return this.$$md ??= {"b":2420105,"c":[{"n":".ctor","o":"$ctor$2","d":this.$h,"h":Number(BigInt(this.$h)|0x100000000n),"f":8}],"g":[T1?.$h??1507328,T2?.$h??1572864,T3?.$h??1638400,T4?.$h??1703936],"r":4,"d":2420105,"h":this.$h}; }
                    static get $b() { return $.$srij.System.Runtime.InteropServices.JavaScript.JSType; }
                    static get $fullName() { return `System.Runtime.InteropServices.JavaScript.JSType.Function<${T1?.$fullName},${T2?.$fullName},${T3?.$fullName},${T4?.$fullName}>`; }
                }), $cls, ($v) => $cls.$_Function$$$$$ = $v))(T1, T2, T3, T4);
            }
            static $_Any;
            static get Any()
            {
                let $cls = $.$srij.System.Runtime.InteropServices.JavaScript.JSType;
                return $cls.$_Any ??= $asm.$ncls("$srij.System.Runtime.InteropServices.JavaScript.JSType.Any", ($self) => class Any extends $.$srij.System.Runtime.InteropServices.JavaScript.JSType
                {
                    $ctor$2()
                    {
                        super.$ctor$1();
                        {
                        }
                        return this;
                    }
                    static $h = 2485641;
                    static $f = 0b10000000010010001;
                    static $k = 1;
                    static $$md;
                    static get $md() { return this.$$md ??= {"b":2420105,"c":[{"n":".ctor","o":"$ctor$2","d":2485641,"h":4297452937,"f":8}],"d":2420105,"h":2485641}; }
                    static get $b() { return $.$srij.System.Runtime.InteropServices.JavaScript.JSType; }
                    static get $fullName() { return `System.Runtime.InteropServices.JavaScript.JSType.Any`; }
                }, $cls, ($v) => $cls.$_Any = $v);
            }
            static $h = 2420105;
            static $f = 0b110001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"c":[{"n":".ctor","o":"$ctor$1","d":2420105,"h":4297387401,"f":8}],"j":[3665289,2813321,2878857,2682249,3403145,2616713,2747785,3599753,3468681,2944393,3337609,2551177,3534217,3009929,3272073,3206537,3141001,3075465,2485641],"h":2420105,"a":[{"t":114950145,"c":4409917441,"a":[{"v":"browser","t":1310721}]}]}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.Runtime.InteropServices.JavaScript.JSType`; }
        });
        
        $asm.$cls("$srij.System.Runtime.InteropServices.JavaScript.JavaScriptImports", ($self) => class JavaScriptImports
        {
            static /*bool */ HasProperty(/*global::System.Runtime.InteropServices.JavaScript.JSObject*/ self, /*string*/ propertyName)
            {
                if ($.$srij.System.Runtime.InteropServices.JavaScript.JavaScriptImports.__signature_HasProperty_393970128 === null)
                {
                    $.$srij.System.Runtime.InteropServices.JavaScript.JavaScriptImports.__signature_HasProperty_393970128 = $.$srij.System.Runtime.InteropServices.JavaScript.JSFunctionBinding.BindJSFunction("INTERNAL.has_property", null, $.$spc.System.ReadOnlySpan$$($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType).op_Implicit($.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType), [$.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType.Boolean, $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType.JSObject, $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType.String], null, null)));
                }
                {
                    /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ let ____arg_exception_native;
                    /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ let ____arg_return_native;
                    /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ let __self_native;
                    /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ let __propertyName_native;
                    /*bool*/ let __retVal;
                    /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ let __retVal_native;
                    $.$spc.System.Runtime.CompilerServices.Unsafe.SkipInit($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument, $.$ref(() => ____arg_return_native, ($v) => ____arg_return_native = $v, $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument));
                    ____arg_return_native.Initialize();
                    $.$spc.System.Runtime.CompilerServices.Unsafe.SkipInit($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument, $.$ref(() => ____arg_exception_native, ($v) => ____arg_exception_native = $v, $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument));
                    ____arg_exception_native.Initialize();
                    $.$spc.System.Runtime.CompilerServices.Unsafe.SkipInit($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument, $.$ref(() => __propertyName_native, ($v) => __propertyName_native = $v, $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument));
                    $.$spc.System.Runtime.CompilerServices.Unsafe.SkipInit($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument, $.$ref(() => __self_native, ($v) => __self_native = $v, $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument));
                    __propertyName_native.ToJS$25(propertyName);
                    __self_native.ToJS$35(self);
                    {
                        __retVal_native = __InvokeJSFunction.call(this, ____arg_exception_native.Clone(), ____arg_return_native.Clone(), __self_native.Clone(), __propertyName_native.Clone());
                    }
                    __retVal_native.ToManaged$16($.$ref(() => __retVal, ($v) => __retVal = $v, $.$spc.System.Boolean));
                    return __retVal;
                }
                /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/  function __InvokeJSFunction(/*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ ____arg_exception_native, /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ ____arg_return_native, /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ __self_native, /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ __propertyName_native)
                {
                    /*global::System.Span<global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument>*/ let __arguments_buffer = $.$spc.System.Span$$($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument).op_Implicit($.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument), [____arg_exception_native, ____arg_return_native, __self_native, __propertyName_native], null, null));
                    $.$srij.System.Runtime.InteropServices.JavaScript.JSFunctionBinding.InvokeJS($.$srij.System.Runtime.InteropServices.JavaScript.JavaScriptImports.__signature_HasProperty_393970128, __arguments_buffer);
                    return __arguments_buffer.get_Item(1).$v;
                }
            }
            /*global::System.Runtime.InteropServices.JavaScript.JSFunctionBinding*/ static __signature_HasProperty_393970128 = null;
            static /*string */ GetTypeOfProperty(/*global::System.Runtime.InteropServices.JavaScript.JSObject*/ self, /*string*/ propertyName)
            {
                if ($.$srij.System.Runtime.InteropServices.JavaScript.JavaScriptImports.__signature_GetTypeOfProperty_1139574135 === null)
                {
                    $.$srij.System.Runtime.InteropServices.JavaScript.JavaScriptImports.__signature_GetTypeOfProperty_1139574135 = $.$srij.System.Runtime.InteropServices.JavaScript.JSFunctionBinding.BindJSFunction("INTERNAL.get_typeof_property", null, $.$spc.System.ReadOnlySpan$$($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType).op_Implicit($.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType), [$.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType.String, $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType.JSObject, $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType.String], null, null)));
                }
                {
                    /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ let ____arg_exception_native;
                    /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ let ____arg_return_native;
                    /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ let __self_native;
                    /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ let __propertyName_native;
                    /*string*/ let __retVal;
                    /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ let __retVal_native;
                    $.$spc.System.Runtime.CompilerServices.Unsafe.SkipInit($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument, $.$ref(() => ____arg_return_native, ($v) => ____arg_return_native = $v, $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument));
                    ____arg_return_native.Initialize();
                    $.$spc.System.Runtime.CompilerServices.Unsafe.SkipInit($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument, $.$ref(() => ____arg_exception_native, ($v) => ____arg_exception_native = $v, $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument));
                    ____arg_exception_native.Initialize();
                    $.$spc.System.Runtime.CompilerServices.Unsafe.SkipInit($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument, $.$ref(() => __propertyName_native, ($v) => __propertyName_native = $v, $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument));
                    $.$spc.System.Runtime.CompilerServices.Unsafe.SkipInit($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument, $.$ref(() => __self_native, ($v) => __self_native = $v, $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument));
                    __propertyName_native.ToJS$25(propertyName);
                    __self_native.ToJS$35(self);
                    {
                        __retVal_native = __InvokeJSFunction.call(this, ____arg_exception_native.Clone(), ____arg_return_native.Clone(), __self_native.Clone(), __propertyName_native.Clone());
                    }
                    __retVal_native.ToManaged$25($.$ref(() => __retVal, ($v) => __retVal = $v, $.$spc.System.String));
                    return __retVal;
                }
                /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/  function __InvokeJSFunction(/*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ ____arg_exception_native, /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ ____arg_return_native, /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ __self_native, /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ __propertyName_native)
                {
                    /*global::System.Span<global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument>*/ let __arguments_buffer = $.$spc.System.Span$$($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument).op_Implicit($.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument), [____arg_exception_native, ____arg_return_native, __self_native, __propertyName_native], null, null));
                    $.$srij.System.Runtime.InteropServices.JavaScript.JSFunctionBinding.InvokeJS($.$srij.System.Runtime.InteropServices.JavaScript.JavaScriptImports.__signature_GetTypeOfProperty_1139574135, __arguments_buffer);
                    return __arguments_buffer.get_Item(1).$v;
                }
            }
            /*global::System.Runtime.InteropServices.JavaScript.JSFunctionBinding*/ static __signature_GetTypeOfProperty_1139574135 = null;
            static /*bool */ GetPropertyAsBoolean(/*global::System.Runtime.InteropServices.JavaScript.JSObject*/ self, /*string*/ propertyName)
            {
                if ($.$srij.System.Runtime.InteropServices.JavaScript.JavaScriptImports.__signature_GetPropertyAsBoolean_393970128 === null)
                {
                    $.$srij.System.Runtime.InteropServices.JavaScript.JavaScriptImports.__signature_GetPropertyAsBoolean_393970128 = $.$srij.System.Runtime.InteropServices.JavaScript.JSFunctionBinding.BindJSFunction("INTERNAL.get_property", null, $.$spc.System.ReadOnlySpan$$($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType).op_Implicit($.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType), [$.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType.Boolean, $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType.JSObject, $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType.String], null, null)));
                }
                {
                    /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ let ____arg_exception_native;
                    /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ let ____arg_return_native;
                    /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ let __self_native;
                    /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ let __propertyName_native;
                    /*bool*/ let __retVal;
                    /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ let __retVal_native;
                    $.$spc.System.Runtime.CompilerServices.Unsafe.SkipInit($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument, $.$ref(() => ____arg_return_native, ($v) => ____arg_return_native = $v, $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument));
                    ____arg_return_native.Initialize();
                    $.$spc.System.Runtime.CompilerServices.Unsafe.SkipInit($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument, $.$ref(() => ____arg_exception_native, ($v) => ____arg_exception_native = $v, $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument));
                    ____arg_exception_native.Initialize();
                    $.$spc.System.Runtime.CompilerServices.Unsafe.SkipInit($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument, $.$ref(() => __propertyName_native, ($v) => __propertyName_native = $v, $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument));
                    $.$spc.System.Runtime.CompilerServices.Unsafe.SkipInit($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument, $.$ref(() => __self_native, ($v) => __self_native = $v, $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument));
                    __propertyName_native.ToJS$25(propertyName);
                    __self_native.ToJS$35(self);
                    {
                        __retVal_native = __InvokeJSFunction.call(this, ____arg_exception_native.Clone(), ____arg_return_native.Clone(), __self_native.Clone(), __propertyName_native.Clone());
                    }
                    __retVal_native.ToManaged$16($.$ref(() => __retVal, ($v) => __retVal = $v, $.$spc.System.Boolean));
                    return __retVal;
                }
                /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/  function __InvokeJSFunction(/*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ ____arg_exception_native, /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ ____arg_return_native, /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ __self_native, /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ __propertyName_native)
                {
                    /*global::System.Span<global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument>*/ let __arguments_buffer = $.$spc.System.Span$$($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument).op_Implicit($.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument), [____arg_exception_native, ____arg_return_native, __self_native, __propertyName_native], null, null));
                    $.$srij.System.Runtime.InteropServices.JavaScript.JSFunctionBinding.InvokeJS($.$srij.System.Runtime.InteropServices.JavaScript.JavaScriptImports.__signature_GetPropertyAsBoolean_393970128, __arguments_buffer);
                    return __arguments_buffer.get_Item(1).$v;
                }
            }
            /*global::System.Runtime.InteropServices.JavaScript.JSFunctionBinding*/ static __signature_GetPropertyAsBoolean_393970128 = null;
            static /*int */ GetPropertyAsInt32(/*global::System.Runtime.InteropServices.JavaScript.JSObject*/ self, /*string*/ propertyName)
            {
                if ($.$srij.System.Runtime.InteropServices.JavaScript.JavaScriptImports.__signature_GetPropertyAsInt32_1813830729 === null)
                {
                    $.$srij.System.Runtime.InteropServices.JavaScript.JavaScriptImports.__signature_GetPropertyAsInt32_1813830729 = $.$srij.System.Runtime.InteropServices.JavaScript.JSFunctionBinding.BindJSFunction("INTERNAL.get_property", null, $.$spc.System.ReadOnlySpan$$($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType).op_Implicit($.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType), [$.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType.Int32, $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType.JSObject, $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType.String], null, null)));
                }
                {
                    /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ let ____arg_exception_native;
                    /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ let ____arg_return_native;
                    /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ let __self_native;
                    /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ let __propertyName_native;
                    /*int*/ let __retVal;
                    /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ let __retVal_native;
                    $.$spc.System.Runtime.CompilerServices.Unsafe.SkipInit($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument, $.$ref(() => ____arg_return_native, ($v) => ____arg_return_native = $v, $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument));
                    ____arg_return_native.Initialize();
                    $.$spc.System.Runtime.CompilerServices.Unsafe.SkipInit($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument, $.$ref(() => ____arg_exception_native, ($v) => ____arg_exception_native = $v, $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument));
                    ____arg_exception_native.Initialize();
                    $.$spc.System.Runtime.CompilerServices.Unsafe.SkipInit($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument, $.$ref(() => __propertyName_native, ($v) => __propertyName_native = $v, $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument));
                    $.$spc.System.Runtime.CompilerServices.Unsafe.SkipInit($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument, $.$ref(() => __self_native, ($v) => __self_native = $v, $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument));
                    __propertyName_native.ToJS$25(propertyName);
                    __self_native.ToJS$35(self);
                    {
                        __retVal_native = __InvokeJSFunction.call(this, ____arg_exception_native.Clone(), ____arg_return_native.Clone(), __self_native.Clone(), __propertyName_native.Clone());
                    }
                    __retVal_native.ToManaged$30($.$ref(() => __retVal, ($v) => __retVal = $v, $.$spc.System.Int32));
                    return __retVal;
                }
                /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/  function __InvokeJSFunction(/*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ ____arg_exception_native, /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ ____arg_return_native, /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ __self_native, /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ __propertyName_native)
                {
                    /*global::System.Span<global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument>*/ let __arguments_buffer = $.$spc.System.Span$$($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument).op_Implicit($.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument), [____arg_exception_native, ____arg_return_native, __self_native, __propertyName_native], null, null));
                    $.$srij.System.Runtime.InteropServices.JavaScript.JSFunctionBinding.InvokeJS($.$srij.System.Runtime.InteropServices.JavaScript.JavaScriptImports.__signature_GetPropertyAsInt32_1813830729, __arguments_buffer);
                    return __arguments_buffer.get_Item(1).$v;
                }
            }
            /*global::System.Runtime.InteropServices.JavaScript.JSFunctionBinding*/ static __signature_GetPropertyAsInt32_1813830729 = null;
            static /*double */ GetPropertyAsDouble(/*global::System.Runtime.InteropServices.JavaScript.JSObject*/ self, /*string*/ propertyName)
            {
                if ($.$srij.System.Runtime.InteropServices.JavaScript.JavaScriptImports.__signature_GetPropertyAsDouble_705601847 === null)
                {
                    $.$srij.System.Runtime.InteropServices.JavaScript.JavaScriptImports.__signature_GetPropertyAsDouble_705601847 = $.$srij.System.Runtime.InteropServices.JavaScript.JSFunctionBinding.BindJSFunction("INTERNAL.get_property", null, $.$spc.System.ReadOnlySpan$$($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType).op_Implicit($.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType), [$.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType.Double, $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType.JSObject, $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType.String], null, null)));
                }
                {
                    /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ let ____arg_exception_native;
                    /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ let ____arg_return_native;
                    /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ let __self_native;
                    /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ let __propertyName_native;
                    /*double*/ let __retVal;
                    /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ let __retVal_native;
                    $.$spc.System.Runtime.CompilerServices.Unsafe.SkipInit($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument, $.$ref(() => ____arg_return_native, ($v) => ____arg_return_native = $v, $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument));
                    ____arg_return_native.Initialize();
                    $.$spc.System.Runtime.CompilerServices.Unsafe.SkipInit($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument, $.$ref(() => ____arg_exception_native, ($v) => ____arg_exception_native = $v, $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument));
                    ____arg_exception_native.Initialize();
                    $.$spc.System.Runtime.CompilerServices.Unsafe.SkipInit($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument, $.$ref(() => __propertyName_native, ($v) => __propertyName_native = $v, $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument));
                    $.$spc.System.Runtime.CompilerServices.Unsafe.SkipInit($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument, $.$ref(() => __self_native, ($v) => __self_native = $v, $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument));
                    __propertyName_native.ToJS$25(propertyName);
                    __self_native.ToJS$35(self);
                    {
                        __retVal_native = __InvokeJSFunction.call(this, ____arg_exception_native.Clone(), ____arg_return_native.Clone(), __self_native.Clone(), __propertyName_native.Clone());
                    }
                    __retVal_native.ToManaged$4($.$ref(() => __retVal, ($v) => __retVal = $v, $.$spc.System.Double));
                    return __retVal;
                }
                /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/  function __InvokeJSFunction(/*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ ____arg_exception_native, /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ ____arg_return_native, /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ __self_native, /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ __propertyName_native)
                {
                    /*global::System.Span<global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument>*/ let __arguments_buffer = $.$spc.System.Span$$($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument).op_Implicit($.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument), [____arg_exception_native, ____arg_return_native, __self_native, __propertyName_native], null, null));
                    $.$srij.System.Runtime.InteropServices.JavaScript.JSFunctionBinding.InvokeJS($.$srij.System.Runtime.InteropServices.JavaScript.JavaScriptImports.__signature_GetPropertyAsDouble_705601847, __arguments_buffer);
                    return __arguments_buffer.get_Item(1).$v;
                }
            }
            /*global::System.Runtime.InteropServices.JavaScript.JSFunctionBinding*/ static __signature_GetPropertyAsDouble_705601847 = null;
            static /*string */ GetPropertyAsString(/*global::System.Runtime.InteropServices.JavaScript.JSObject*/ self, /*string*/ propertyName)
            {
                if ($.$srij.System.Runtime.InteropServices.JavaScript.JavaScriptImports.__signature_GetPropertyAsString_1139574135 === null)
                {
                    $.$srij.System.Runtime.InteropServices.JavaScript.JavaScriptImports.__signature_GetPropertyAsString_1139574135 = $.$srij.System.Runtime.InteropServices.JavaScript.JSFunctionBinding.BindJSFunction("INTERNAL.get_property", null, $.$spc.System.ReadOnlySpan$$($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType).op_Implicit($.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType), [$.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType.String, $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType.JSObject, $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType.String], null, null)));
                }
                {
                    /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ let ____arg_exception_native;
                    /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ let ____arg_return_native;
                    /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ let __self_native;
                    /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ let __propertyName_native;
                    /*string*/ let __retVal;
                    /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ let __retVal_native;
                    $.$spc.System.Runtime.CompilerServices.Unsafe.SkipInit($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument, $.$ref(() => ____arg_return_native, ($v) => ____arg_return_native = $v, $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument));
                    ____arg_return_native.Initialize();
                    $.$spc.System.Runtime.CompilerServices.Unsafe.SkipInit($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument, $.$ref(() => ____arg_exception_native, ($v) => ____arg_exception_native = $v, $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument));
                    ____arg_exception_native.Initialize();
                    $.$spc.System.Runtime.CompilerServices.Unsafe.SkipInit($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument, $.$ref(() => __propertyName_native, ($v) => __propertyName_native = $v, $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument));
                    $.$spc.System.Runtime.CompilerServices.Unsafe.SkipInit($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument, $.$ref(() => __self_native, ($v) => __self_native = $v, $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument));
                    __propertyName_native.ToJS$25(propertyName);
                    __self_native.ToJS$35(self);
                    {
                        __retVal_native = __InvokeJSFunction.call(this, ____arg_exception_native.Clone(), ____arg_return_native.Clone(), __self_native.Clone(), __propertyName_native.Clone());
                    }
                    __retVal_native.ToManaged$25($.$ref(() => __retVal, ($v) => __retVal = $v, $.$spc.System.String));
                    return __retVal;
                }
                /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/  function __InvokeJSFunction(/*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ ____arg_exception_native, /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ ____arg_return_native, /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ __self_native, /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ __propertyName_native)
                {
                    /*global::System.Span<global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument>*/ let __arguments_buffer = $.$spc.System.Span$$($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument).op_Implicit($.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument), [____arg_exception_native, ____arg_return_native, __self_native, __propertyName_native], null, null));
                    $.$srij.System.Runtime.InteropServices.JavaScript.JSFunctionBinding.InvokeJS($.$srij.System.Runtime.InteropServices.JavaScript.JavaScriptImports.__signature_GetPropertyAsString_1139574135, __arguments_buffer);
                    return __arguments_buffer.get_Item(1).$v;
                }
            }
            /*global::System.Runtime.InteropServices.JavaScript.JSFunctionBinding*/ static __signature_GetPropertyAsString_1139574135 = null;
            static /*global::System.Runtime.InteropServices.JavaScript.JSObject */ GetPropertyAsJSObject(/*global::System.Runtime.InteropServices.JavaScript.JSObject*/ self, /*string*/ propertyName)
            {
                if ($.$srij.System.Runtime.InteropServices.JavaScript.JavaScriptImports.__signature_GetPropertyAsJSObject_1480020778 === null)
                {
                    $.$srij.System.Runtime.InteropServices.JavaScript.JavaScriptImports.__signature_GetPropertyAsJSObject_1480020778 = $.$srij.System.Runtime.InteropServices.JavaScript.JSFunctionBinding.BindJSFunction("INTERNAL.get_property", null, $.$spc.System.ReadOnlySpan$$($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType).op_Implicit($.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType), [$.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType.JSObject, $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType.JSObject, $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType.String], null, null)));
                }
                {
                    /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ let ____arg_exception_native;
                    /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ let ____arg_return_native;
                    /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ let __self_native;
                    /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ let __propertyName_native;
                    /*global::System.Runtime.InteropServices.JavaScript.JSObject*/ let __retVal;
                    /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ let __retVal_native;
                    $.$spc.System.Runtime.CompilerServices.Unsafe.SkipInit($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument, $.$ref(() => ____arg_return_native, ($v) => ____arg_return_native = $v, $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument));
                    ____arg_return_native.Initialize();
                    $.$spc.System.Runtime.CompilerServices.Unsafe.SkipInit($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument, $.$ref(() => ____arg_exception_native, ($v) => ____arg_exception_native = $v, $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument));
                    ____arg_exception_native.Initialize();
                    $.$spc.System.Runtime.CompilerServices.Unsafe.SkipInit($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument, $.$ref(() => __propertyName_native, ($v) => __propertyName_native = $v, $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument));
                    $.$spc.System.Runtime.CompilerServices.Unsafe.SkipInit($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument, $.$ref(() => __self_native, ($v) => __self_native = $v, $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument));
                    __propertyName_native.ToJS$25(propertyName);
                    __self_native.ToJS$35(self);
                    {
                        __retVal_native = __InvokeJSFunction.call(this, ____arg_exception_native.Clone(), ____arg_return_native.Clone(), __self_native.Clone(), __propertyName_native.Clone());
                    }
                    __retVal_native.ToManaged$35($.$ref(() => __retVal, ($v) => __retVal = $v, $.$srij.System.Runtime.InteropServices.JavaScript.JSObject));
                    return __retVal;
                }
                /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/  function __InvokeJSFunction(/*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ ____arg_exception_native, /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ ____arg_return_native, /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ __self_native, /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ __propertyName_native)
                {
                    /*global::System.Span<global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument>*/ let __arguments_buffer = $.$spc.System.Span$$($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument).op_Implicit($.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument), [____arg_exception_native, ____arg_return_native, __self_native, __propertyName_native], null, null));
                    $.$srij.System.Runtime.InteropServices.JavaScript.JSFunctionBinding.InvokeJS($.$srij.System.Runtime.InteropServices.JavaScript.JavaScriptImports.__signature_GetPropertyAsJSObject_1480020778, __arguments_buffer);
                    return __arguments_buffer.get_Item(1).$v;
                }
            }
            /*global::System.Runtime.InteropServices.JavaScript.JSFunctionBinding*/ static __signature_GetPropertyAsJSObject_1480020778 = null;
            static /*byte[] */ GetPropertyAsByteArray(/*global::System.Runtime.InteropServices.JavaScript.JSObject*/ self, /*string*/ propertyName)
            {
                if ($.$srij.System.Runtime.InteropServices.JavaScript.JavaScriptImports.__signature_GetPropertyAsByteArray_657551312 === null)
                {
                    $.$srij.System.Runtime.InteropServices.JavaScript.JavaScriptImports.__signature_GetPropertyAsByteArray_657551312 = $.$srij.System.Runtime.InteropServices.JavaScript.JSFunctionBinding.BindJSFunction("INTERNAL.get_property", null, $.$spc.System.ReadOnlySpan$$($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType).op_Implicit($.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType), [$.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType.Array($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType.Byte), $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType.JSObject, $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType.String], null, null)));
                }
                {
                    /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ let ____arg_exception_native;
                    /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ let ____arg_return_native;
                    /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ let __self_native;
                    /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ let __propertyName_native;
                    /*byte[]*/ let __retVal;
                    /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ let __retVal_native;
                    $.$spc.System.Runtime.CompilerServices.Unsafe.SkipInit($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument, $.$ref(() => ____arg_return_native, ($v) => ____arg_return_native = $v, $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument));
                    ____arg_return_native.Initialize();
                    $.$spc.System.Runtime.CompilerServices.Unsafe.SkipInit($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument, $.$ref(() => ____arg_exception_native, ($v) => ____arg_exception_native = $v, $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument));
                    ____arg_exception_native.Initialize();
                    $.$spc.System.Runtime.CompilerServices.Unsafe.SkipInit($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument, $.$ref(() => __propertyName_native, ($v) => __propertyName_native = $v, $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument));
                    $.$spc.System.Runtime.CompilerServices.Unsafe.SkipInit($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument, $.$ref(() => __self_native, ($v) => __self_native = $v, $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument));
                    __propertyName_native.ToJS$25(propertyName);
                    __self_native.ToJS$35(self);
                    {
                        __retVal_native = __InvokeJSFunction.call(this, ____arg_exception_native.Clone(), ____arg_return_native.Clone(), __self_native.Clone(), __propertyName_native.Clone());
                    }
                    __retVal_native.ToManaged$13($.$ref(() => __retVal, ($v) => __retVal = $v, $.$typeArray($.$spc.System.Byte)));
                    return __retVal;
                }
                /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/  function __InvokeJSFunction(/*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ ____arg_exception_native, /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ ____arg_return_native, /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ __self_native, /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ __propertyName_native)
                {
                    /*global::System.Span<global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument>*/ let __arguments_buffer = $.$spc.System.Span$$($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument).op_Implicit($.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument), [____arg_exception_native, ____arg_return_native, __self_native, __propertyName_native], null, null));
                    $.$srij.System.Runtime.InteropServices.JavaScript.JSFunctionBinding.InvokeJS($.$srij.System.Runtime.InteropServices.JavaScript.JavaScriptImports.__signature_GetPropertyAsByteArray_657551312, __arguments_buffer);
                    return __arguments_buffer.get_Item(1).$v;
                }
            }
            /*global::System.Runtime.InteropServices.JavaScript.JSFunctionBinding*/ static __signature_GetPropertyAsByteArray_657551312 = null;
            static /*void */ SetPropertyBool(/*global::System.Runtime.InteropServices.JavaScript.JSObject*/ self, /*string*/ propertyName, /*bool*/ value)
            {
                if ($.$srij.System.Runtime.InteropServices.JavaScript.JavaScriptImports.__signature_SetPropertyBool_125660004 === null)
                {
                    $.$srij.System.Runtime.InteropServices.JavaScript.JavaScriptImports.__signature_SetPropertyBool_125660004 = $.$srij.System.Runtime.InteropServices.JavaScript.JSFunctionBinding.BindJSFunction("INTERNAL.set_property", null, $.$spc.System.ReadOnlySpan$$($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType).op_Implicit($.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType), [$.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType.Discard, $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType.JSObject, $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType.String, $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType.Boolean], null, null)));
                }
                {
                    /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ let ____arg_exception_native;
                    /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ let ____arg_return_native;
                    /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ let __self_native;
                    /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ let __propertyName_native;
                    /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ let __value_native;
                    $.$spc.System.Runtime.CompilerServices.Unsafe.SkipInit($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument, $.$ref(() => ____arg_return_native, ($v) => ____arg_return_native = $v, $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument));
                    ____arg_return_native.Initialize();
                    $.$spc.System.Runtime.CompilerServices.Unsafe.SkipInit($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument, $.$ref(() => ____arg_exception_native, ($v) => ____arg_exception_native = $v, $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument));
                    ____arg_exception_native.Initialize();
                    $.$spc.System.Runtime.CompilerServices.Unsafe.SkipInit($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument, $.$ref(() => __value_native, ($v) => __value_native = $v, $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument));
                    $.$spc.System.Runtime.CompilerServices.Unsafe.SkipInit($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument, $.$ref(() => __propertyName_native, ($v) => __propertyName_native = $v, $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument));
                    $.$spc.System.Runtime.CompilerServices.Unsafe.SkipInit($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument, $.$ref(() => __self_native, ($v) => __self_native = $v, $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument));
                    __value_native.ToJS$16(value);
                    __propertyName_native.ToJS$25(propertyName);
                    __self_native.ToJS$35(self);
                    {
                        __InvokeJSFunction.call(this, ____arg_exception_native.Clone(), ____arg_return_native.Clone(), __self_native.Clone(), __propertyName_native.Clone(), __value_native.Clone());
                    }
                }
                /*void*/  function __InvokeJSFunction(/*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ ____arg_exception_native, /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ ____arg_return_native, /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ __self_native, /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ __propertyName_native, /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ __value_native)
                {
                    $.$srij.System.Runtime.InteropServices.JavaScript.JSFunctionBinding.InvokeJS($.$srij.System.Runtime.InteropServices.JavaScript.JavaScriptImports.__signature_SetPropertyBool_125660004, $.$spc.System.Span$$($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument).op_Implicit($.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument), [____arg_exception_native, ____arg_return_native, __self_native, __propertyName_native, __value_native], null, null)));
                }
            }
            /*global::System.Runtime.InteropServices.JavaScript.JSFunctionBinding*/ static __signature_SetPropertyBool_125660004 = null;
            static /*void */ SetPropertyInt(/*global::System.Runtime.InteropServices.JavaScript.JSObject*/ self, /*string*/ propertyName, /*int*/ value)
            {
                if ($.$srij.System.Runtime.InteropServices.JavaScript.JavaScriptImports.__signature_SetPropertyInt_512418141 === null)
                {
                    $.$srij.System.Runtime.InteropServices.JavaScript.JavaScriptImports.__signature_SetPropertyInt_512418141 = $.$srij.System.Runtime.InteropServices.JavaScript.JSFunctionBinding.BindJSFunction("INTERNAL.set_property", null, $.$spc.System.ReadOnlySpan$$($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType).op_Implicit($.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType), [$.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType.Discard, $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType.JSObject, $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType.String, $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType.Int32], null, null)));
                }
                {
                    /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ let ____arg_exception_native;
                    /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ let ____arg_return_native;
                    /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ let __self_native;
                    /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ let __propertyName_native;
                    /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ let __value_native;
                    $.$spc.System.Runtime.CompilerServices.Unsafe.SkipInit($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument, $.$ref(() => ____arg_return_native, ($v) => ____arg_return_native = $v, $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument));
                    ____arg_return_native.Initialize();
                    $.$spc.System.Runtime.CompilerServices.Unsafe.SkipInit($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument, $.$ref(() => ____arg_exception_native, ($v) => ____arg_exception_native = $v, $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument));
                    ____arg_exception_native.Initialize();
                    $.$spc.System.Runtime.CompilerServices.Unsafe.SkipInit($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument, $.$ref(() => __value_native, ($v) => __value_native = $v, $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument));
                    $.$spc.System.Runtime.CompilerServices.Unsafe.SkipInit($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument, $.$ref(() => __propertyName_native, ($v) => __propertyName_native = $v, $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument));
                    $.$spc.System.Runtime.CompilerServices.Unsafe.SkipInit($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument, $.$ref(() => __self_native, ($v) => __self_native = $v, $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument));
                    __value_native.ToJS$30(value);
                    __propertyName_native.ToJS$25(propertyName);
                    __self_native.ToJS$35(self);
                    {
                        __InvokeJSFunction.call(this, ____arg_exception_native.Clone(), ____arg_return_native.Clone(), __self_native.Clone(), __propertyName_native.Clone(), __value_native.Clone());
                    }
                }
                /*void*/  function __InvokeJSFunction(/*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ ____arg_exception_native, /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ ____arg_return_native, /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ __self_native, /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ __propertyName_native, /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ __value_native)
                {
                    $.$srij.System.Runtime.InteropServices.JavaScript.JSFunctionBinding.InvokeJS($.$srij.System.Runtime.InteropServices.JavaScript.JavaScriptImports.__signature_SetPropertyInt_512418141, $.$spc.System.Span$$($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument).op_Implicit($.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument), [____arg_exception_native, ____arg_return_native, __self_native, __propertyName_native, __value_native], null, null)));
                }
            }
            /*global::System.Runtime.InteropServices.JavaScript.JSFunctionBinding*/ static __signature_SetPropertyInt_512418141 = null;
            static /*void */ SetPropertyDouble(/*global::System.Runtime.InteropServices.JavaScript.JSObject*/ self, /*string*/ propertyName, /*double*/ value)
            {
                if ($.$srij.System.Runtime.InteropServices.JavaScript.JavaScriptImports.__signature_SetPropertyDouble_1393852235 === null)
                {
                    $.$srij.System.Runtime.InteropServices.JavaScript.JavaScriptImports.__signature_SetPropertyDouble_1393852235 = $.$srij.System.Runtime.InteropServices.JavaScript.JSFunctionBinding.BindJSFunction("INTERNAL.set_property", null, $.$spc.System.ReadOnlySpan$$($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType).op_Implicit($.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType), [$.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType.Discard, $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType.JSObject, $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType.String, $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType.Double], null, null)));
                }
                {
                    /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ let ____arg_exception_native;
                    /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ let ____arg_return_native;
                    /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ let __self_native;
                    /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ let __propertyName_native;
                    /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ let __value_native;
                    $.$spc.System.Runtime.CompilerServices.Unsafe.SkipInit($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument, $.$ref(() => ____arg_return_native, ($v) => ____arg_return_native = $v, $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument));
                    ____arg_return_native.Initialize();
                    $.$spc.System.Runtime.CompilerServices.Unsafe.SkipInit($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument, $.$ref(() => ____arg_exception_native, ($v) => ____arg_exception_native = $v, $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument));
                    ____arg_exception_native.Initialize();
                    $.$spc.System.Runtime.CompilerServices.Unsafe.SkipInit($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument, $.$ref(() => __value_native, ($v) => __value_native = $v, $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument));
                    $.$spc.System.Runtime.CompilerServices.Unsafe.SkipInit($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument, $.$ref(() => __propertyName_native, ($v) => __propertyName_native = $v, $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument));
                    $.$spc.System.Runtime.CompilerServices.Unsafe.SkipInit($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument, $.$ref(() => __self_native, ($v) => __self_native = $v, $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument));
                    __value_native.ToJS$4(value);
                    __propertyName_native.ToJS$25(propertyName);
                    __self_native.ToJS$35(self);
                    {
                        __InvokeJSFunction.call(this, ____arg_exception_native.Clone(), ____arg_return_native.Clone(), __self_native.Clone(), __propertyName_native.Clone(), __value_native.Clone());
                    }
                }
                /*void*/  function __InvokeJSFunction(/*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ ____arg_exception_native, /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ ____arg_return_native, /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ __self_native, /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ __propertyName_native, /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ __value_native)
                {
                    $.$srij.System.Runtime.InteropServices.JavaScript.JSFunctionBinding.InvokeJS($.$srij.System.Runtime.InteropServices.JavaScript.JavaScriptImports.__signature_SetPropertyDouble_1393852235, $.$spc.System.Span$$($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument).op_Implicit($.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument), [____arg_exception_native, ____arg_return_native, __self_native, __propertyName_native, __value_native], null, null)));
                }
            }
            /*global::System.Runtime.InteropServices.JavaScript.JSFunctionBinding*/ static __signature_SetPropertyDouble_1393852235 = null;
            static /*void */ SetPropertyString(/*global::System.Runtime.InteropServices.JavaScript.JSObject*/ self, /*string*/ propertyName, /*string*/ value)
            {
                if ($.$srij.System.Runtime.InteropServices.JavaScript.JavaScriptImports.__signature_SetPropertyString_1189495691 === null)
                {
                    $.$srij.System.Runtime.InteropServices.JavaScript.JavaScriptImports.__signature_SetPropertyString_1189495691 = $.$srij.System.Runtime.InteropServices.JavaScript.JSFunctionBinding.BindJSFunction("INTERNAL.set_property", null, $.$spc.System.ReadOnlySpan$$($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType).op_Implicit($.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType), [$.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType.Discard, $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType.JSObject, $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType.String, $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType.String], null, null)));
                }
                {
                    /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ let ____arg_exception_native;
                    /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ let ____arg_return_native;
                    /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ let __self_native;
                    /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ let __propertyName_native;
                    /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ let __value_native;
                    $.$spc.System.Runtime.CompilerServices.Unsafe.SkipInit($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument, $.$ref(() => ____arg_return_native, ($v) => ____arg_return_native = $v, $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument));
                    ____arg_return_native.Initialize();
                    $.$spc.System.Runtime.CompilerServices.Unsafe.SkipInit($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument, $.$ref(() => ____arg_exception_native, ($v) => ____arg_exception_native = $v, $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument));
                    ____arg_exception_native.Initialize();
                    $.$spc.System.Runtime.CompilerServices.Unsafe.SkipInit($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument, $.$ref(() => __value_native, ($v) => __value_native = $v, $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument));
                    $.$spc.System.Runtime.CompilerServices.Unsafe.SkipInit($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument, $.$ref(() => __propertyName_native, ($v) => __propertyName_native = $v, $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument));
                    $.$spc.System.Runtime.CompilerServices.Unsafe.SkipInit($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument, $.$ref(() => __self_native, ($v) => __self_native = $v, $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument));
                    __value_native.ToJS$25(value);
                    __propertyName_native.ToJS$25(propertyName);
                    __self_native.ToJS$35(self);
                    {
                        __InvokeJSFunction.call(this, ____arg_exception_native.Clone(), ____arg_return_native.Clone(), __self_native.Clone(), __propertyName_native.Clone(), __value_native.Clone());
                    }
                }
                /*void*/  function __InvokeJSFunction(/*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ ____arg_exception_native, /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ ____arg_return_native, /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ __self_native, /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ __propertyName_native, /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ __value_native)
                {
                    $.$srij.System.Runtime.InteropServices.JavaScript.JSFunctionBinding.InvokeJS($.$srij.System.Runtime.InteropServices.JavaScript.JavaScriptImports.__signature_SetPropertyString_1189495691, $.$spc.System.Span$$($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument).op_Implicit($.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument), [____arg_exception_native, ____arg_return_native, __self_native, __propertyName_native, __value_native], null, null)));
                }
            }
            /*global::System.Runtime.InteropServices.JavaScript.JSFunctionBinding*/ static __signature_SetPropertyString_1189495691 = null;
            static /*void */ SetPropertyJSObject(/*global::System.Runtime.InteropServices.JavaScript.JSObject*/ self, /*string*/ propertyName, /*global::System.Runtime.InteropServices.JavaScript.JSObject*/ value)
            {
                if ($.$srij.System.Runtime.InteropServices.JavaScript.JavaScriptImports.__signature_SetPropertyJSObject_2027749310 === null)
                {
                    $.$srij.System.Runtime.InteropServices.JavaScript.JavaScriptImports.__signature_SetPropertyJSObject_2027749310 = $.$srij.System.Runtime.InteropServices.JavaScript.JSFunctionBinding.BindJSFunction("INTERNAL.set_property", null, $.$spc.System.ReadOnlySpan$$($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType).op_Implicit($.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType), [$.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType.Discard, $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType.JSObject, $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType.String, $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType.JSObject], null, null)));
                }
                {
                    /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ let ____arg_exception_native;
                    /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ let ____arg_return_native;
                    /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ let __self_native;
                    /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ let __propertyName_native;
                    /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ let __value_native;
                    $.$spc.System.Runtime.CompilerServices.Unsafe.SkipInit($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument, $.$ref(() => ____arg_return_native, ($v) => ____arg_return_native = $v, $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument));
                    ____arg_return_native.Initialize();
                    $.$spc.System.Runtime.CompilerServices.Unsafe.SkipInit($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument, $.$ref(() => ____arg_exception_native, ($v) => ____arg_exception_native = $v, $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument));
                    ____arg_exception_native.Initialize();
                    $.$spc.System.Runtime.CompilerServices.Unsafe.SkipInit($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument, $.$ref(() => __value_native, ($v) => __value_native = $v, $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument));
                    $.$spc.System.Runtime.CompilerServices.Unsafe.SkipInit($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument, $.$ref(() => __propertyName_native, ($v) => __propertyName_native = $v, $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument));
                    $.$spc.System.Runtime.CompilerServices.Unsafe.SkipInit($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument, $.$ref(() => __self_native, ($v) => __self_native = $v, $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument));
                    __value_native.ToJS$35(value);
                    __propertyName_native.ToJS$25(propertyName);
                    __self_native.ToJS$35(self);
                    {
                        __InvokeJSFunction.call(this, ____arg_exception_native.Clone(), ____arg_return_native.Clone(), __self_native.Clone(), __propertyName_native.Clone(), __value_native.Clone());
                    }
                }
                /*void*/  function __InvokeJSFunction(/*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ ____arg_exception_native, /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ ____arg_return_native, /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ __self_native, /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ __propertyName_native, /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ __value_native)
                {
                    $.$srij.System.Runtime.InteropServices.JavaScript.JSFunctionBinding.InvokeJS($.$srij.System.Runtime.InteropServices.JavaScript.JavaScriptImports.__signature_SetPropertyJSObject_2027749310, $.$spc.System.Span$$($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument).op_Implicit($.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument), [____arg_exception_native, ____arg_return_native, __self_native, __propertyName_native, __value_native], null, null)));
                }
            }
            /*global::System.Runtime.InteropServices.JavaScript.JSFunctionBinding*/ static __signature_SetPropertyJSObject_2027749310 = null;
            static /*void */ SetPropertyBytes(/*global::System.Runtime.InteropServices.JavaScript.JSObject*/ self, /*string*/ propertyName, /*byte[]*/ value)
            {
                if ($.$srij.System.Runtime.InteropServices.JavaScript.JavaScriptImports.__signature_SetPropertyBytes_1317820772 === null)
                {
                    $.$srij.System.Runtime.InteropServices.JavaScript.JavaScriptImports.__signature_SetPropertyBytes_1317820772 = $.$srij.System.Runtime.InteropServices.JavaScript.JSFunctionBinding.BindJSFunction("INTERNAL.set_property", null, $.$spc.System.ReadOnlySpan$$($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType).op_Implicit($.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType), [$.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType.Discard, $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType.JSObject, $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType.String, $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType.Array($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType.Byte)], null, null)));
                }
                {
                    /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ let ____arg_exception_native;
                    /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ let ____arg_return_native;
                    /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ let __self_native;
                    /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ let __propertyName_native;
                    /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ let __value_native;
                    $.$spc.System.Runtime.CompilerServices.Unsafe.SkipInit($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument, $.$ref(() => ____arg_return_native, ($v) => ____arg_return_native = $v, $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument));
                    ____arg_return_native.Initialize();
                    $.$spc.System.Runtime.CompilerServices.Unsafe.SkipInit($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument, $.$ref(() => ____arg_exception_native, ($v) => ____arg_exception_native = $v, $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument));
                    ____arg_exception_native.Initialize();
                    $.$spc.System.Runtime.CompilerServices.Unsafe.SkipInit($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument, $.$ref(() => __value_native, ($v) => __value_native = $v, $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument));
                    $.$spc.System.Runtime.CompilerServices.Unsafe.SkipInit($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument, $.$ref(() => __propertyName_native, ($v) => __propertyName_native = $v, $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument));
                    $.$spc.System.Runtime.CompilerServices.Unsafe.SkipInit($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument, $.$ref(() => __self_native, ($v) => __self_native = $v, $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument));
                    __value_native.ToJS$13(value);
                    __propertyName_native.ToJS$25(propertyName);
                    __self_native.ToJS$35(self);
                    {
                        __InvokeJSFunction.call(this, ____arg_exception_native.Clone(), ____arg_return_native.Clone(), __self_native.Clone(), __propertyName_native.Clone(), __value_native.Clone());
                    }
                }
                /*void*/  function __InvokeJSFunction(/*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ ____arg_exception_native, /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ ____arg_return_native, /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ __self_native, /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ __propertyName_native, /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ __value_native)
                {
                    $.$srij.System.Runtime.InteropServices.JavaScript.JSFunctionBinding.InvokeJS($.$srij.System.Runtime.InteropServices.JavaScript.JavaScriptImports.__signature_SetPropertyBytes_1317820772, $.$spc.System.Span$$($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument).op_Implicit($.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument), [____arg_exception_native, ____arg_return_native, __self_native, __propertyName_native, __value_native], null, null)));
                }
            }
            /*global::System.Runtime.InteropServices.JavaScript.JSFunctionBinding*/ static __signature_SetPropertyBytes_1317820772 = null;
            static /*global::System.Runtime.InteropServices.JavaScript.JSObject */ GetGlobalThis()
            {
                if ($.$srij.System.Runtime.InteropServices.JavaScript.JavaScriptImports.__signature_GetGlobalThis_1202228629 === null)
                {
                    $.$srij.System.Runtime.InteropServices.JavaScript.JavaScriptImports.__signature_GetGlobalThis_1202228629 = $.$srij.System.Runtime.InteropServices.JavaScript.JSFunctionBinding.BindJSFunction("INTERNAL.get_global_this", null, $.$spc.System.ReadOnlySpan$$($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType).op_Implicit($.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType), [$.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType.JSObject], null, null)));
                }
                {
                    /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ let ____arg_exception_native;
                    /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ let ____arg_return_native;
                    /*global::System.Runtime.InteropServices.JavaScript.JSObject*/ let __retVal;
                    /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ let __retVal_native;
                    $.$spc.System.Runtime.CompilerServices.Unsafe.SkipInit($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument, $.$ref(() => ____arg_return_native, ($v) => ____arg_return_native = $v, $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument));
                    ____arg_return_native.Initialize();
                    $.$spc.System.Runtime.CompilerServices.Unsafe.SkipInit($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument, $.$ref(() => ____arg_exception_native, ($v) => ____arg_exception_native = $v, $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument));
                    ____arg_exception_native.Initialize();
                    {
                        __retVal_native = __InvokeJSFunction.call(this, ____arg_exception_native.Clone(), ____arg_return_native.Clone());
                    }
                    __retVal_native.ToManaged$35($.$ref(() => __retVal, ($v) => __retVal = $v, $.$srij.System.Runtime.InteropServices.JavaScript.JSObject));
                    return __retVal;
                }
                /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/  function __InvokeJSFunction(/*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ ____arg_exception_native, /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ ____arg_return_native)
                {
                    /*global::System.Span<global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument>*/ let __arguments_buffer = $.$spc.System.Span$$($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument).op_Implicit($.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument), [____arg_exception_native, ____arg_return_native], null, null));
                    $.$srij.System.Runtime.InteropServices.JavaScript.JSFunctionBinding.InvokeJS($.$srij.System.Runtime.InteropServices.JavaScript.JavaScriptImports.__signature_GetGlobalThis_1202228629, __arguments_buffer);
                    return __arguments_buffer.get_Item(1).$v;
                }
            }
            /*global::System.Runtime.InteropServices.JavaScript.JSFunctionBinding*/ static __signature_GetGlobalThis_1202228629 = null;
            static /*global::System.Runtime.InteropServices.JavaScript.JSObject */ GetDotnetInstance()
            {
                if ($.$srij.System.Runtime.InteropServices.JavaScript.JavaScriptImports.__signature_GetDotnetInstance_1202228629 === null)
                {
                    $.$srij.System.Runtime.InteropServices.JavaScript.JavaScriptImports.__signature_GetDotnetInstance_1202228629 = $.$srij.System.Runtime.InteropServices.JavaScript.JSFunctionBinding.BindJSFunction("INTERNAL.get_dotnet_instance", null, $.$spc.System.ReadOnlySpan$$($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType).op_Implicit($.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType), [$.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType.JSObject], null, null)));
                }
                {
                    /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ let ____arg_exception_native;
                    /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ let ____arg_return_native;
                    /*global::System.Runtime.InteropServices.JavaScript.JSObject*/ let __retVal;
                    /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ let __retVal_native;
                    $.$spc.System.Runtime.CompilerServices.Unsafe.SkipInit($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument, $.$ref(() => ____arg_return_native, ($v) => ____arg_return_native = $v, $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument));
                    ____arg_return_native.Initialize();
                    $.$spc.System.Runtime.CompilerServices.Unsafe.SkipInit($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument, $.$ref(() => ____arg_exception_native, ($v) => ____arg_exception_native = $v, $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument));
                    ____arg_exception_native.Initialize();
                    {
                        __retVal_native = __InvokeJSFunction.call(this, ____arg_exception_native.Clone(), ____arg_return_native.Clone());
                    }
                    __retVal_native.ToManaged$35($.$ref(() => __retVal, ($v) => __retVal = $v, $.$srij.System.Runtime.InteropServices.JavaScript.JSObject));
                    return __retVal;
                }
                /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/  function __InvokeJSFunction(/*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ ____arg_exception_native, /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ ____arg_return_native)
                {
                    /*global::System.Span<global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument>*/ let __arguments_buffer = $.$spc.System.Span$$($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument).op_Implicit($.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument), [____arg_exception_native, ____arg_return_native], null, null));
                    $.$srij.System.Runtime.InteropServices.JavaScript.JSFunctionBinding.InvokeJS($.$srij.System.Runtime.InteropServices.JavaScript.JavaScriptImports.__signature_GetDotnetInstance_1202228629, __arguments_buffer);
                    return __arguments_buffer.get_Item(1).$v;
                }
            }
            /*global::System.Runtime.InteropServices.JavaScript.JSFunctionBinding*/ static __signature_GetDotnetInstance_1202228629 = null;
            static /*global::System.Threading.Tasks.Task<global::System.Runtime.InteropServices.JavaScript.JSObject> */ DynamicImport(/*string*/ moduleName, /*string*/ moduleUrl)
            {
                if ($.$srij.System.Runtime.InteropServices.JavaScript.JavaScriptImports.__signature_DynamicImport_119536130 === null)
                {
                    $.$srij.System.Runtime.InteropServices.JavaScript.JavaScriptImports.__signature_DynamicImport_119536130 = $.$srij.System.Runtime.InteropServices.JavaScript.JSFunctionBinding.BindJSFunction("INTERNAL.dynamic_import", null, $.$spc.System.ReadOnlySpan$$($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType).op_Implicit($.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType), [$.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType.Task$1($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType.JSObject), $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType.String, $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType.String], null, null)));
                }
                {
                    /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ let ____arg_exception_native;
                    /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ let ____arg_return_native;
                    /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ let __moduleName_native;
                    /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ let __moduleUrl_native;
                    /*global::System.Threading.Tasks.Task<global::System.Runtime.InteropServices.JavaScript.JSObject>*/ let __retVal;
                    /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ let __retVal_native;
                    $.$spc.System.Runtime.CompilerServices.Unsafe.SkipInit($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument, $.$ref(() => ____arg_return_native, ($v) => ____arg_return_native = $v, $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument));
                    ____arg_return_native.Initialize();
                    $.$spc.System.Runtime.CompilerServices.Unsafe.SkipInit($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument, $.$ref(() => ____arg_exception_native, ($v) => ____arg_exception_native = $v, $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument));
                    ____arg_exception_native.Initialize();
                    $.$spc.System.Runtime.CompilerServices.Unsafe.SkipInit($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument, $.$ref(() => __moduleUrl_native, ($v) => __moduleUrl_native = $v, $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument));
                    $.$spc.System.Runtime.CompilerServices.Unsafe.SkipInit($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument, $.$ref(() => __moduleName_native, ($v) => __moduleName_native = $v, $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument));
                    __moduleUrl_native.ToJS$25(moduleUrl);
                    __moduleName_native.ToJS$25(moduleName);
                    {
                        __retVal_native = __InvokeJSFunction.call(this, ____arg_exception_native.Clone(), ____arg_return_native.Clone(), __moduleName_native.Clone(), __moduleUrl_native.Clone());
                    }
                    __retVal_native.ToManaged$38($.$srij.System.Runtime.InteropServices.JavaScript.JSObject, $.$ref(() => __retVal, ($v) => __retVal = $v, $.$spc.System.Threading.Tasks.Task$$($.$srij.System.Runtime.InteropServices.JavaScript.JSObject)), new ($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument.ArgumentToManagedCallback$$($.$srij.System.Runtime.InteropServices.JavaScript.JSObject))().$ctor($.$srij.System.Runtime.InteropServices.JavaScript.JavaScriptImports, /*static*/ (/*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ __task_result_arg, /*global::System.Runtime.InteropServices.JavaScript.JSObject*/ __task_result) =>
                    {
                        __task_result_arg.$v.ToManaged$35(__task_result);
                    }, {"r":65537,"p":[{"n":"__task_result_arg","p":1371529,"f":4},{"n":"__task_result","p":2289033,"f":2}],"n":"","d":388489,"h":0,"f":1048610}));
                    return __retVal;
                }
                /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/  function __InvokeJSFunction(/*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ ____arg_exception_native, /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ ____arg_return_native, /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ __moduleName_native, /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ __moduleUrl_native)
                {
                    /*global::System.Span<global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument>*/ let __arguments_buffer = $.$spc.System.Span$$($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument).op_Implicit($.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument), [____arg_exception_native, ____arg_return_native, __moduleName_native, __moduleUrl_native], null, null));
                    $.$srij.System.Runtime.InteropServices.JavaScript.JSFunctionBinding.InvokeJS($.$srij.System.Runtime.InteropServices.JavaScript.JavaScriptImports.__signature_DynamicImport_119536130, __arguments_buffer);
                    return __arguments_buffer.get_Item(1).$v;
                }
            }
            /*global::System.Runtime.InteropServices.JavaScript.JSFunctionBinding*/ static __signature_DynamicImport_119536130 = null;
            static /*void */ BindCSFunction(/*nint*/ monoMethod, /*string*/ assemblyName, /*string*/ namespaceName, /*string*/ shortClassName, /*string*/ methodName, /*int*/ signatureHash, /*nint*/ signature)
            {
                if ($.$srij.System.Runtime.InteropServices.JavaScript.JavaScriptImports.__signature_BindCSFunction_1080107758 === null)
                {
                    $.$srij.System.Runtime.InteropServices.JavaScript.JavaScriptImports.__signature_BindCSFunction_1080107758 = $.$srij.System.Runtime.InteropServices.JavaScript.JSFunctionBinding.BindJSFunction("INTERNAL.mono_wasm_bind_cs_function", null, $.$spc.System.ReadOnlySpan$$($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType).op_Implicit($.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType), [$.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType.Discard, $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType.IntPtr, $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType.String, $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType.String, $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType.String, $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType.String, $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType.Int32, $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType.IntPtr], null, null)));
                }
                {
                    /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ let ____arg_exception_native;
                    /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ let ____arg_return_native;
                    /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ let __monoMethod_native;
                    /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ let __assemblyName_native;
                    /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ let __namespaceName_native;
                    /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ let __shortClassName_native;
                    /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ let __methodName_native;
                    /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ let __signatureHash_native;
                    /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ let __signature_native;
                    $.$spc.System.Runtime.CompilerServices.Unsafe.SkipInit($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument, $.$ref(() => ____arg_return_native, ($v) => ____arg_return_native = $v, $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument));
                    ____arg_return_native.Initialize();
                    $.$spc.System.Runtime.CompilerServices.Unsafe.SkipInit($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument, $.$ref(() => ____arg_exception_native, ($v) => ____arg_exception_native = $v, $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument));
                    ____arg_exception_native.Initialize();
                    $.$spc.System.Runtime.CompilerServices.Unsafe.SkipInit($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument, $.$ref(() => __signature_native, ($v) => __signature_native = $v, $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument));
                    $.$spc.System.Runtime.CompilerServices.Unsafe.SkipInit($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument, $.$ref(() => __signatureHash_native, ($v) => __signatureHash_native = $v, $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument));
                    $.$spc.System.Runtime.CompilerServices.Unsafe.SkipInit($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument, $.$ref(() => __methodName_native, ($v) => __methodName_native = $v, $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument));
                    $.$spc.System.Runtime.CompilerServices.Unsafe.SkipInit($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument, $.$ref(() => __shortClassName_native, ($v) => __shortClassName_native = $v, $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument));
                    $.$spc.System.Runtime.CompilerServices.Unsafe.SkipInit($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument, $.$ref(() => __namespaceName_native, ($v) => __namespaceName_native = $v, $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument));
                    $.$spc.System.Runtime.CompilerServices.Unsafe.SkipInit($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument, $.$ref(() => __assemblyName_native, ($v) => __assemblyName_native = $v, $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument));
                    $.$spc.System.Runtime.CompilerServices.Unsafe.SkipInit($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument, $.$ref(() => __monoMethod_native, ($v) => __monoMethod_native = $v, $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument));
                    __signature_native.ToJS$27(signature);
                    __signatureHash_native.ToJS$30(signatureHash);
                    __methodName_native.ToJS$25(methodName);
                    __shortClassName_native.ToJS$25(shortClassName);
                    __namespaceName_native.ToJS$25(namespaceName);
                    __assemblyName_native.ToJS$25(assemblyName);
                    __monoMethod_native.ToJS$27(monoMethod);
                    {
                        __InvokeJSFunction.call(this, ____arg_exception_native.Clone(), ____arg_return_native.Clone(), __monoMethod_native.Clone(), __assemblyName_native.Clone(), __namespaceName_native.Clone(), __shortClassName_native.Clone(), __methodName_native.Clone(), __signatureHash_native.Clone(), __signature_native.Clone());
                    }
                }
                /*void*/  function __InvokeJSFunction(/*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ ____arg_exception_native, /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ ____arg_return_native, /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ __monoMethod_native, /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ __assemblyName_native, /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ __namespaceName_native, /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ __shortClassName_native, /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ __methodName_native, /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ __signatureHash_native, /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ __signature_native)
                {
                    $.$srij.System.Runtime.InteropServices.JavaScript.JSFunctionBinding.InvokeJS($.$srij.System.Runtime.InteropServices.JavaScript.JavaScriptImports.__signature_BindCSFunction_1080107758, $.$spc.System.Span$$($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument).op_Implicit($.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument), [____arg_exception_native, ____arg_return_native, __monoMethod_native, __assemblyName_native, __namespaceName_native, __shortClassName_native, __methodName_native, __signatureHash_native, __signature_native], null, null)));
                }
            }
            /*global::System.Runtime.InteropServices.JavaScript.JSFunctionBinding*/ static __signature_BindCSFunction_1080107758 = null;
            static /*void */ Log(/*string*/ message)
            {
                if ($.$srij.System.Runtime.InteropServices.JavaScript.JavaScriptImports.__signature_Log_92020726 === null)
                {
                    $.$srij.System.Runtime.InteropServices.JavaScript.JavaScriptImports.__signature_Log_92020726 = $.$srij.System.Runtime.InteropServices.JavaScript.JSFunctionBinding.BindJSFunction("globalThis.console.log", null, $.$spc.System.ReadOnlySpan$$($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType).op_Implicit($.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType), [$.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType.DiscardNoWait, $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType.String], null, null)));
                }
                {
                    /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ let ____arg_exception_native;
                    /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ let ____arg_return_native;
                    /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ let __message_native;
                    $.$spc.System.Runtime.CompilerServices.Unsafe.SkipInit($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument, $.$ref(() => ____arg_return_native, ($v) => ____arg_return_native = $v, $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument));
                    ____arg_return_native.Initialize();
                    $.$spc.System.Runtime.CompilerServices.Unsafe.SkipInit($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument, $.$ref(() => ____arg_exception_native, ($v) => ____arg_exception_native = $v, $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument));
                    ____arg_exception_native.Initialize();
                    $.$spc.System.Runtime.CompilerServices.Unsafe.SkipInit($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument, $.$ref(() => __message_native, ($v) => __message_native = $v, $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument));
                    __message_native.ToJS$25(message);
                    {
                        __InvokeJSFunction.call(this, ____arg_exception_native.Clone(), ____arg_return_native.Clone(), __message_native.Clone());
                    }
                }
                /*void*/  function __InvokeJSFunction(/*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ ____arg_exception_native, /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ ____arg_return_native, /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ __message_native)
                {
                    $.$srij.System.Runtime.InteropServices.JavaScript.JSFunctionBinding.InvokeJS($.$srij.System.Runtime.InteropServices.JavaScript.JavaScriptImports.__signature_Log_92020726, $.$spc.System.Span$$($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument).op_Implicit($.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument), [____arg_exception_native, ____arg_return_native, __message_native], null, null)));
                }
            }
            /*global::System.Runtime.InteropServices.JavaScript.JSFunctionBinding*/ static __signature_Log_92020726 = null;
            static $h = 388489;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"m":[{"r":262145,"p":[{"n":"self","p":2289033},{"n":"propertyName","p":1310721}],"n":"HasProperty","d":388489,"h":4295355785,"f":33,"a":[{"t":1240457,"c":30066011529,"a":[{"v":"INTERNAL.has_property","t":1310721}]},{"t":37748737,"c":4332716033}]},{"r":1310721,"p":[{"n":"self","p":2289033},{"n":"propertyName","p":1310721}],"n":"GetTypeOfProperty","d":388489,"h":8590323081,"f":33,"a":[{"t":1240457,"c":30066011529,"a":[{"v":"INTERNAL.get_typeof_property","t":1310721}]},{"t":37748737,"c":4332716033}]},{"r":262145,"p":[{"n":"self","p":2289033},{"n":"propertyName","p":1310721}],"n":"GetPropertyAsBoolean","d":388489,"h":12885290377,"f":33,"a":[{"t":1240457,"c":30066011529,"a":[{"v":"INTERNAL.get_property","t":1310721}]},{"t":37748737,"c":4332716033}]},{"r":655361,"p":[{"n":"self","p":2289033},{"n":"propertyName","p":1310721}],"n":"GetPropertyAsInt32","d":388489,"h":17180257673,"f":33,"a":[{"t":1240457,"c":30066011529,"a":[{"v":"INTERNAL.get_property","t":1310721}]},{"t":37748737,"c":4332716033}]},{"r":1179649,"p":[{"n":"self","p":2289033},{"n":"propertyName","p":1310721}],"n":"GetPropertyAsDouble","d":388489,"h":21475224969,"f":33,"a":[{"t":1240457,"c":30066011529,"a":[{"v":"INTERNAL.get_property","t":1310721}]},{"t":37748737,"c":4332716033}]},{"r":1310721,"p":[{"n":"self","p":2289033},{"n":"propertyName","p":1310721}],"n":"GetPropertyAsString","d":388489,"h":25770192265,"f":33,"a":[{"t":1240457,"c":30066011529,"a":[{"v":"INTERNAL.get_property","t":1310721}]},{"t":37748737,"c":4332716033}]},{"r":2289033,"p":[{"n":"self","p":2289033},{"n":"propertyName","p":1310721}],"n":"GetPropertyAsJSObject","d":388489,"h":30065159561,"f":33,"a":[{"t":1240457,"c":30066011529,"a":[{"v":"INTERNAL.get_property","t":1310721}]},{"t":37748737,"c":4332716033}]},{"r":0,"p":[{"n":"self","p":2289033},{"n":"propertyName","p":1310721}],"n":"GetPropertyAsByteArray","d":388489,"h":34360126857,"f":33,"a":[{"t":1240457,"c":30066011529,"a":[{"v":"INTERNAL.get_property","t":1310721}]},{"t":37748737,"c":4332716033}]},{"r":65537,"p":[{"n":"self","p":2289033},{"n":"propertyName","p":1310721},{"n":"value","p":262145}],"n":"SetPropertyBool","d":388489,"h":38655094153,"f":33,"a":[{"t":1240457,"c":30066011529,"a":[{"v":"INTERNAL.set_property","t":1310721}]},{"t":37748737,"c":4332716033}]},{"r":65537,"p":[{"n":"self","p":2289033},{"n":"propertyName","p":1310721},{"n":"value","p":655361}],"n":"SetPropertyInt","d":388489,"h":42950061449,"f":33,"a":[{"t":1240457,"c":30066011529,"a":[{"v":"INTERNAL.set_property","t":1310721}]},{"t":37748737,"c":4332716033}]},{"r":65537,"p":[{"n":"self","p":2289033},{"n":"propertyName","p":1310721},{"n":"value","p":1179649}],"n":"SetPropertyDouble","d":388489,"h":47245028745,"f":33,"a":[{"t":1240457,"c":30066011529,"a":[{"v":"INTERNAL.set_property","t":1310721}]},{"t":37748737,"c":4332716033}]},{"r":65537,"p":[{"n":"self","p":2289033},{"n":"propertyName","p":1310721},{"n":"value","p":1310721}],"n":"SetPropertyString","d":388489,"h":51539996041,"f":33,"a":[{"t":1240457,"c":30066011529,"a":[{"v":"INTERNAL.set_property","t":1310721}]},{"t":37748737,"c":4332716033}]},{"r":65537,"p":[{"n":"self","p":2289033},{"n":"propertyName","p":1310721},{"n":"value","p":2289033}],"n":"SetPropertyJSObject","d":388489,"h":55834963337,"f":33,"a":[{"t":1240457,"c":30066011529,"a":[{"v":"INTERNAL.set_property","t":1310721}]},{"t":37748737,"c":4332716033}]},{"r":65537,"p":[{"n":"self","p":2289033},{"n":"propertyName","p":1310721},{"n":"value","p":0}],"n":"SetPropertyBytes","d":388489,"h":60129930633,"f":33,"a":[{"t":1240457,"c":30066011529,"a":[{"v":"INTERNAL.set_property","t":1310721}]},{"t":37748737,"c":4332716033}]},{"r":2289033,"n":"GetGlobalThis","d":388489,"h":64424897929,"f":33,"a":[{"t":1240457,"c":30066011529,"a":[{"v":"INTERNAL.get_global_this","t":1310721}]},{"t":37748737,"c":4332716033}]},{"r":2289033,"n":"GetDotnetInstance","d":388489,"h":68719865225,"f":33,"a":[{"t":1240457,"c":30066011529,"a":[{"v":"INTERNAL.get_dotnet_instance","t":1310721}]},{"t":37748737,"c":4332716033}]},{"r":$.$spc.System.Threading.Tasks.Task$$($.$srij.System.Runtime.InteropServices.JavaScript.JSObject).$h,"p":[{"n":"moduleName","p":1310721},{"n":"moduleUrl","p":1310721}],"n":"DynamicImport","d":388489,"h":73014832521,"f":33,"a":[{"t":1240457,"c":30066011529,"a":[{"v":"INTERNAL.dynamic_import","t":1310721}]},{"t":37748737,"c":4332716033}]},{"r":65537,"p":[{"n":"monoMethod","p":786433},{"n":"assemblyName","p":1310721},{"n":"namespaceName","p":1310721},{"n":"shortClassName","p":1310721},{"n":"methodName","p":1310721},{"n":"signatureHash","p":655361},{"n":"signature","p":786433}],"n":"BindCSFunction","d":388489,"h":77309799817,"f":33,"a":[{"t":1240457,"c":30066011529,"a":[{"v":"INTERNAL.mono_wasm_bind_cs_function","t":1310721}]},{"t":37748737,"c":4332716033}]},{"r":65537,"p":[{"n":"message","p":1310721,"a":[{"t":$.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalAsAttribute$$($.$srij.System.Runtime.InteropServices.JavaScript.JSType.String).$h,"c":Number(BigInt($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalAsAttribute$$($.$srij.System.Runtime.InteropServices.JavaScript.JSType.String).$h)|0x100000000n)}]}],"n":"Log","d":388489,"h":81604767113,"f":33,"a":[{"t":1240457,"c":30066011529,"a":[{"v":"globalThis.console.log","t":1310721}]},{"t":37748737,"c":4332716033}]}],"l":[{"t":585097,"n":"__signature_HasProperty_393970128","d":388489,"h":85899734409,"f":34},{"t":585097,"n":"__signature_GetTypeOfProperty_1139574135","d":388489,"h":90194701705,"f":34},{"t":585097,"n":"__signature_GetPropertyAsBoolean_393970128","d":388489,"h":94489669001,"f":34},{"t":585097,"n":"__signature_GetPropertyAsInt32_1813830729","d":388489,"h":98784636297,"f":34},{"t":585097,"n":"__signature_GetPropertyAsDouble_705601847","d":388489,"h":103079603593,"f":34},{"t":585097,"n":"__signature_GetPropertyAsString_1139574135","d":388489,"h":107374570889,"f":34},{"t":585097,"n":"__signature_GetPropertyAsJSObject_1480020778","d":388489,"h":111669538185,"f":34},{"t":585097,"n":"__signature_GetPropertyAsByteArray_657551312","d":388489,"h":115964505481,"f":34},{"t":585097,"n":"__signature_SetPropertyBool_125660004","d":388489,"h":120259472777,"f":34},{"t":585097,"n":"__signature_SetPropertyInt_512418141","d":388489,"h":124554440073,"f":34},{"t":585097,"n":"__signature_SetPropertyDouble_1393852235","d":388489,"h":128849407369,"f":34},{"t":585097,"n":"__signature_SetPropertyString_1189495691","d":388489,"h":133144374665,"f":34},{"t":585097,"n":"__signature_SetPropertyJSObject_2027749310","d":388489,"h":137439341961,"f":34},{"t":585097,"n":"__signature_SetPropertyBytes_1317820772","d":388489,"h":141734309257,"f":34},{"t":585097,"n":"__signature_GetGlobalThis_1202228629","d":388489,"h":146029276553,"f":34},{"t":585097,"n":"__signature_GetDotnetInstance_1202228629","d":388489,"h":150324243849,"f":34},{"t":585097,"n":"__signature_DynamicImport_119536130","d":388489,"h":154619211145,"f":34},{"t":585097,"n":"__signature_BindCSFunction_1080107758","d":388489,"h":158914178441,"f":34},{"t":585097,"n":"__signature_Log_92020726","d":388489,"h":163209145737,"f":34}],"h":388489}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.Runtime.InteropServices.JavaScript.JavaScriptImports`; }
        });
        
        $asm.$cls("$srij.System.Runtime.InteropServices.JavaScript.JSHost", ($self) => class JSHost
        {
            static /*JSObject */ get GlobalThis()
            {
                return INTERNAL.get_global_this();
            }
            static /*JSObject */ get DotnetInstance()
            {
                return INTERNAL.get_dotnet_instance();
            }
            static /*Task<JSObject> */ ImportAsync(/*string*/ moduleName, /*string*/ moduleUrl, /*CancellationToken*/ cancellationToken)
            {
                return $.$srij.System.Runtime.InteropServices.JavaScript.JSHostImplementation.ImportAsync(moduleName, moduleUrl, cancellationToken);
            }
            static $h = 781705;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":2289033,"g":{"r":0,"d":0,"h":8590716297,"f":33},"n":"GlobalThis","d":781705,"h":4295749001,"f":33},{"p":2289033,"g":{"r":0,"d":0,"h":17180650889,"f":33},"n":"DotnetInstance","d":781705,"h":12885683593,"f":33}],"m":[{"r":$.$spc.System.Threading.Tasks.Task$$($.$srij.System.Runtime.InteropServices.JavaScript.JSObject).$h,"p":[{"n":"moduleName","p":1310721},{"n":"moduleUrl","p":1310721},{"n":"cancellationToken","p":125960193,"f":65}],"n":"ImportAsync","d":781705,"h":21475618185,"f":33}],"h":781705,"a":[{"t":114950145,"c":4409917441,"a":[{"v":"browser","t":1310721}]}]}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.Runtime.InteropServices.JavaScript.JSHost`; }
        });
        
        $asm.$cls("$srij.Interop", ($self) => class Interop
        {
            static $_Runtime;
            static get Runtime()
            {
                let $cls = $.$srij.Interop;
                return $cls.$_Runtime ??= $asm.$ncls("$srij.Interop.Runtime", ($self) => class Runtime
                {
                    static $h = 191881;
                    static $f = 0b10000000000010000;
                    static $k = 1;
                    static $$md;
                    static get $md() { return this.$$md ??= {"b":131073,"d":126345,"h":191881}; }
                    static get $b() { return $.$spc.System.Object; }
                    static get $fullName() { return `Interop.Runtime`; }
                }, $cls, ($v) => $cls.$_Runtime = $v);
            }
            static $h = 126345;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"j":[191881],"h":126345}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `Interop`; }
        });
        
        $asm.$cls("$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType", ($self) => class JSMarshalerType extends $.$spc.System.Object
        {
            /*JSFunctionBinding.JSBindingType*/ _signatureType;
            $ctor$1()
            {
                super.$ctor();
                {
                    this._signatureType = $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType.Void._signatureType;
                }
                return this;
            }
            $ctor$2(/*JSFunctionBinding.JSBindingType*/ signatureType)
            {
                super.$ctor();
                {
                    this._signatureType = signatureType.Clone();
                }
                return this;
            }
            /*JSMarshalerType*/ static Void = null;
            /*JSMarshalerType*/ static Discard = null;
            /*JSMarshalerType*/ static DiscardNoWait = null;
            /*JSMarshalerType*/ static Boolean = null;
            /*JSMarshalerType*/ static Byte = null;
            /*JSMarshalerType*/ static Char = null;
            /*JSMarshalerType*/ static Int16 = null;
            /*JSMarshalerType*/ static Int32 = null;
            /*JSMarshalerType*/ static Int52 = null;
            /*JSMarshalerType*/ static BigInt64 = null;
            /*JSMarshalerType*/ static Double = null;
            /*JSMarshalerType*/ static Single = null;
            /*JSMarshalerType*/ static IntPtr = null;
            /*JSMarshalerType*/ static JSObject = null;
            /*JSMarshalerType*/ static Object = null;
            /*JSMarshalerType*/ static String = null;
            /*JSMarshalerType*/ static Exception = null;
            /*JSMarshalerType*/ static DateTime = null;
            /*JSMarshalerType*/ static DateTimeOffset = null;
            static /*JSMarshalerType */ Nullable(/*JSMarshalerType*/ primitive)
            {
                $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType.CheckNullable(primitive);
                return new $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType().$ctor$2((() =>
                {
                    //new $.$srij.System.Runtime.InteropServices.JavaScript.JSFunctionBinding.JSBindingType()
                    const $t1 = $.$srij.System.Runtime.InteropServices.JavaScript.JSFunctionBinding.JSBindingType;
                    const $i1 = new $t1();
                    $i1.Type = 19/*MarshalerType.Nullable*/;
                    $i1.ResultMarshalerType = primitive._signatureType.Type;
                    return $i1;
                })());
            }
            /*JSMarshalerType*/ static _task = null;
            static /*JSMarshalerType */ Task()
            {
                return $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType._task;
            }
            static /*JSMarshalerType */ Task$1(/*JSMarshalerType*/ result)
            {
                $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType.CheckTask(result);
                return new $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType().$ctor$2((() =>
                {
                    //new $.$srij.System.Runtime.InteropServices.JavaScript.JSFunctionBinding.JSBindingType()
                    const $t1 = $.$srij.System.Runtime.InteropServices.JavaScript.JSFunctionBinding.JSBindingType;
                    const $i1 = new $t1();
                    $i1.Type = 20/*MarshalerType.Task*/;
                    $i1.ResultMarshalerType = result._signatureType.Type;
                    return $i1;
                })());
            }
            static /*JSMarshalerType */ Array(/*JSMarshalerType*/ element)
            {
                $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType.CheckArray(element);
                return new $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType().$ctor$2((() =>
                {
                    //new $.$srij.System.Runtime.InteropServices.JavaScript.JSFunctionBinding.JSBindingType()
                    const $t1 = $.$srij.System.Runtime.InteropServices.JavaScript.JSFunctionBinding.JSBindingType;
                    const $i1 = new $t1();
                    $i1.Type = 21/*MarshalerType.Array*/;
                    $i1.Arg1MarshalerType = element._signatureType.Type;
                    return $i1;
                })());
            }
            static /*JSMarshalerType */ ArraySegment(/*JSMarshalerType*/ element)
            {
                $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType.CheckArraySegment(element);
                return new $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType().$ctor$2((() =>
                {
                    //new $.$srij.System.Runtime.InteropServices.JavaScript.JSFunctionBinding.JSBindingType()
                    const $t1 = $.$srij.System.Runtime.InteropServices.JavaScript.JSFunctionBinding.JSBindingType;
                    const $i1 = new $t1();
                    $i1.Type = 22/*MarshalerType.ArraySegment*/;
                    $i1.Arg1MarshalerType = element._signatureType.Type;
                    return $i1;
                })());
            }
            static /*JSMarshalerType */ Span(/*JSMarshalerType*/ element)
            {
                $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType.CheckArraySegment(element);
                return new $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType().$ctor$2((() =>
                {
                    //new $.$srij.System.Runtime.InteropServices.JavaScript.JSFunctionBinding.JSBindingType()
                    const $t1 = $.$srij.System.Runtime.InteropServices.JavaScript.JSFunctionBinding.JSBindingType;
                    const $i1 = new $t1();
                    $i1.Type = 23/*MarshalerType.Span*/;
                    $i1.Arg1MarshalerType = element._signatureType.Type;
                    return $i1;
                })());
            }
            /*JSMarshalerType*/ static _action = null;
            static /*JSMarshalerType */ Action()
            {
                return $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType._action;
            }
            static /*JSMarshalerType */ Action$1(/*JSMarshalerType*/ arg1)
            {
                $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType.CheckTask(arg1);
                return new $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType().$ctor$2((() =>
                {
                    //new $.$srij.System.Runtime.InteropServices.JavaScript.JSFunctionBinding.JSBindingType()
                    const $t1 = $.$srij.System.Runtime.InteropServices.JavaScript.JSFunctionBinding.JSBindingType;
                    const $i1 = new $t1();
                    $i1.Type = 24/*MarshalerType.Action*/;
                    $i1.Arg1MarshalerType = arg1._signatureType.Type;
                    return $i1;
                })());
            }
            static /*JSMarshalerType */ Action$2(/*JSMarshalerType*/ arg1, /*JSMarshalerType*/ arg2)
            {
                $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType.CheckTask(arg1);
                $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType.CheckTask(arg2);
                return new $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType().$ctor$2((() =>
                {
                    //new $.$srij.System.Runtime.InteropServices.JavaScript.JSFunctionBinding.JSBindingType()
                    const $t1 = $.$srij.System.Runtime.InteropServices.JavaScript.JSFunctionBinding.JSBindingType;
                    const $i1 = new $t1();
                    $i1.Type = 24/*MarshalerType.Action*/;
                    $i1.Arg1MarshalerType = arg1._signatureType.Type;
                    $i1.Arg2MarshalerType = arg2._signatureType.Type;
                    return $i1;
                })());
            }
            static /*JSMarshalerType */ Action$3(/*JSMarshalerType*/ arg1, /*JSMarshalerType*/ arg2, /*JSMarshalerType*/ arg3)
            {
                $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType.CheckTask(arg1);
                $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType.CheckTask(arg2);
                $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType.CheckTask(arg3);
                return new $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType().$ctor$2((() =>
                {
                    //new $.$srij.System.Runtime.InteropServices.JavaScript.JSFunctionBinding.JSBindingType()
                    const $t1 = $.$srij.System.Runtime.InteropServices.JavaScript.JSFunctionBinding.JSBindingType;
                    const $i1 = new $t1();
                    $i1.Type = 24/*MarshalerType.Action*/;
                    $i1.Arg1MarshalerType = arg1._signatureType.Type;
                    $i1.Arg2MarshalerType = arg2._signatureType.Type;
                    $i1.Arg3MarshalerType = arg3._signatureType.Type;
                    return $i1;
                })());
            }
            static /*JSMarshalerType */ Function(/*JSMarshalerType*/ result)
            {
                $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType.CheckTask(result);
                return new $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType().$ctor$2((() =>
                {
                    //new $.$srij.System.Runtime.InteropServices.JavaScript.JSFunctionBinding.JSBindingType()
                    const $t1 = $.$srij.System.Runtime.InteropServices.JavaScript.JSFunctionBinding.JSBindingType;
                    const $i1 = new $t1();
                    $i1.Type = 25/*MarshalerType.Function*/;
                    $i1.ResultMarshalerType = result._signatureType.Type;
                    return $i1;
                })());
            }
            static /*JSMarshalerType */ Function$1(/*JSMarshalerType*/ arg1, /*JSMarshalerType*/ result)
            {
                $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType.CheckTask(arg1);
                $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType.CheckTask(result);
                return new $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType().$ctor$2((() =>
                {
                    //new $.$srij.System.Runtime.InteropServices.JavaScript.JSFunctionBinding.JSBindingType()
                    const $t1 = $.$srij.System.Runtime.InteropServices.JavaScript.JSFunctionBinding.JSBindingType;
                    const $i1 = new $t1();
                    $i1.Type = 25/*MarshalerType.Function*/;
                    $i1.Arg1MarshalerType = arg1._signatureType.Type;
                    $i1.ResultMarshalerType = result._signatureType.Type;
                    return $i1;
                })());
            }
            static /*JSMarshalerType */ Function$2(/*JSMarshalerType*/ arg1, /*JSMarshalerType*/ arg2, /*JSMarshalerType*/ result)
            {
                $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType.CheckTask(arg1);
                $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType.CheckTask(arg2);
                $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType.CheckTask(result);
                return new $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType().$ctor$2((() =>
                {
                    //new $.$srij.System.Runtime.InteropServices.JavaScript.JSFunctionBinding.JSBindingType()
                    const $t1 = $.$srij.System.Runtime.InteropServices.JavaScript.JSFunctionBinding.JSBindingType;
                    const $i1 = new $t1();
                    $i1.Type = 25/*MarshalerType.Function*/;
                    $i1.Arg1MarshalerType = arg1._signatureType.Type;
                    $i1.Arg2MarshalerType = arg2._signatureType.Type;
                    $i1.ResultMarshalerType = result._signatureType.Type;
                    return $i1;
                })());
            }
            static /*JSMarshalerType */ Function$3(/*JSMarshalerType*/ arg1, /*JSMarshalerType*/ arg2, /*JSMarshalerType*/ arg3, /*JSMarshalerType*/ result)
            {
                $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType.CheckTask(arg1);
                $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType.CheckTask(arg2);
                $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType.CheckTask(arg3);
                $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType.CheckTask(result);
                return new $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType().$ctor$2((() =>
                {
                    //new $.$srij.System.Runtime.InteropServices.JavaScript.JSFunctionBinding.JSBindingType()
                    const $t1 = $.$srij.System.Runtime.InteropServices.JavaScript.JSFunctionBinding.JSBindingType;
                    const $i1 = new $t1();
                    $i1.Type = 25/*MarshalerType.Function*/;
                    $i1.Arg1MarshalerType = arg1._signatureType.Type;
                    $i1.Arg2MarshalerType = arg2._signatureType.Type;
                    $i1.Arg3MarshalerType = arg3._signatureType.Type;
                    $i1.ResultMarshalerType = result._signatureType.Type;
                    return $i1;
                })());
            }
            static /*void */ CheckNullable(/*JSMarshalerType*/ underlyingType)
            {
                /*MarshalerType*/ let underlying = underlyingType._signatureType.Type;
                if (underlying === 3/*MarshalerType.Boolean*/ || underlying === 4/*MarshalerType.Byte*/ || underlying === 6/*MarshalerType.Int16*/ || underlying === 7/*MarshalerType.Int32*/ || underlying === 9/*MarshalerType.BigInt64*/ || underlying === 8/*MarshalerType.Int52*/ || underlying === 12/*MarshalerType.IntPtr*/ || underlying === 10/*MarshalerType.Double*/ || underlying === 11/*MarshalerType.Single*/ || underlying === 5/*MarshalerType.Char*/ || underlying === 17/*MarshalerType.DateTime*/ || underlying === 18/*MarshalerType.DateTimeOffset*/)
                {
                    return;
                }
                throw new $.$spc.System.ArgumentException().$ctor$13($.$srij.System.SR.Format($.$srij.System.SR.UnsupportedNullableType, $.$box(underlying, $.$srij.System.Runtime.InteropServices.JavaScript.MarshalerType)), "underlyingType");
            }
            static /*void */ CheckArray(/*JSMarshalerType*/ underlyingType)
            {
                /*MarshalerType*/ let underlying = underlyingType._signatureType.Type;
                if (underlying === 4/*MarshalerType.Byte*/ || underlying === 7/*MarshalerType.Int32*/ || underlying === 10/*MarshalerType.Double*/ || underlying === 15/*MarshalerType.String*/ || underlying === 14/*MarshalerType.Object*/ || underlying === 13/*MarshalerType.JSObject*/)
                {
                    return;
                }
                throw new $.$spc.System.ArgumentException().$ctor$13($.$srij.System.SR.Format($.$srij.System.SR.UnsupportedElementType, $.$box(underlying, $.$srij.System.Runtime.InteropServices.JavaScript.MarshalerType)), "underlyingType");
            }
            static /*void */ CheckArraySegment(/*JSMarshalerType*/ underlyingType)
            {
                /*MarshalerType*/ let underlying = underlyingType._signatureType.Type;
                if (underlying === 4/*MarshalerType.Byte*/ || underlying === 7/*MarshalerType.Int32*/ || underlying === 10/*MarshalerType.Double*/)
                {
                    return;
                }
                throw new $.$spc.System.ArgumentException().$ctor$13($.$srij.System.SR.Format($.$srij.System.SR.UnsupportedElementType, $.$box(underlying, $.$srij.System.Runtime.InteropServices.JavaScript.MarshalerType)), "underlyingType");
            }
            static /*void */ CheckTask(/*JSMarshalerType*/ underlyingType)
            {
                /*MarshalerType*/ let underlying = underlyingType._signatureType.Type;
                if (underlying === 21/*MarshalerType.Array*/ || underlying === 22/*MarshalerType.ArraySegment*/ || underlying === 23/*MarshalerType.Span*/ || underlying === 20/*MarshalerType.Task*/ || underlying === 24/*MarshalerType.Action*/ || underlying === 25/*MarshalerType.Function*/)
                {
                    throw new $.$spc.System.ArgumentException().$ctor$13($.$srij.System.SR.Format($.$srij.System.SR.UnsupportedTaskResultType, $.$box(underlying, $.$srij.System.Runtime.InteropServices.JavaScript.MarshalerType)), "underlyingType");
                }
            }
            //default member initializer
            constructor()
            {
                super();
                this._signatureType = $.$default($.$srij.System.Runtime.InteropServices.JavaScript.JSFunctionBinding.JSBindingType);
            }
            //Static Initializer
            static $sinit()
            {
                {
                    this.Void = new $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType().$ctor$2((() =>
                    {
                        //new $.$srij.System.Runtime.InteropServices.JavaScript.JSFunctionBinding.JSBindingType()
                        const $t1 = $.$srij.System.Runtime.InteropServices.JavaScript.JSFunctionBinding.JSBindingType;
                        const $i1 = new $t1();
                        $i1.Type = 1/*MarshalerType.Void*/;
                        return $i1;
                    })());
                }
                {
                    this.Discard = new $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType().$ctor$2((() =>
                    {
                        //new $.$srij.System.Runtime.InteropServices.JavaScript.JSFunctionBinding.JSBindingType()
                        const $t1 = $.$srij.System.Runtime.InteropServices.JavaScript.JSFunctionBinding.JSBindingType;
                        const $i1 = new $t1();
                        $i1.Type = 2/*MarshalerType.Discard*/;
                        return $i1;
                    })());
                }
                {
                    this.DiscardNoWait = new $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType().$ctor$2((() =>
                    {
                        //new $.$srij.System.Runtime.InteropServices.JavaScript.JSFunctionBinding.JSBindingType()
                        const $t1 = $.$srij.System.Runtime.InteropServices.JavaScript.JSFunctionBinding.JSBindingType;
                        const $i1 = new $t1();
                        $i1.Type = 26/*MarshalerType.DiscardNoWait*/;
                        return $i1;
                    })());
                }
                {
                    this.Boolean = new $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType().$ctor$2((() =>
                    {
                        //new $.$srij.System.Runtime.InteropServices.JavaScript.JSFunctionBinding.JSBindingType()
                        const $t1 = $.$srij.System.Runtime.InteropServices.JavaScript.JSFunctionBinding.JSBindingType;
                        const $i1 = new $t1();
                        $i1.Type = 3/*MarshalerType.Boolean*/;
                        return $i1;
                    })());
                }
                {
                    this.Byte = new $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType().$ctor$2((() =>
                    {
                        //new $.$srij.System.Runtime.InteropServices.JavaScript.JSFunctionBinding.JSBindingType()
                        const $t1 = $.$srij.System.Runtime.InteropServices.JavaScript.JSFunctionBinding.JSBindingType;
                        const $i1 = new $t1();
                        $i1.Type = 4/*MarshalerType.Byte*/;
                        return $i1;
                    })());
                }
                {
                    this.Char = new $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType().$ctor$2((() =>
                    {
                        //new $.$srij.System.Runtime.InteropServices.JavaScript.JSFunctionBinding.JSBindingType()
                        const $t1 = $.$srij.System.Runtime.InteropServices.JavaScript.JSFunctionBinding.JSBindingType;
                        const $i1 = new $t1();
                        $i1.Type = 5/*MarshalerType.Char*/;
                        return $i1;
                    })());
                }
                {
                    this.Int16 = new $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType().$ctor$2((() =>
                    {
                        //new $.$srij.System.Runtime.InteropServices.JavaScript.JSFunctionBinding.JSBindingType()
                        const $t1 = $.$srij.System.Runtime.InteropServices.JavaScript.JSFunctionBinding.JSBindingType;
                        const $i1 = new $t1();
                        $i1.Type = 6/*MarshalerType.Int16*/;
                        return $i1;
                    })());
                }
                {
                    this.Int32 = new $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType().$ctor$2((() =>
                    {
                        //new $.$srij.System.Runtime.InteropServices.JavaScript.JSFunctionBinding.JSBindingType()
                        const $t1 = $.$srij.System.Runtime.InteropServices.JavaScript.JSFunctionBinding.JSBindingType;
                        const $i1 = new $t1();
                        $i1.Type = 7/*MarshalerType.Int32*/;
                        return $i1;
                    })());
                }
                {
                    this.Int52 = new $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType().$ctor$2((() =>
                    {
                        //new $.$srij.System.Runtime.InteropServices.JavaScript.JSFunctionBinding.JSBindingType()
                        const $t1 = $.$srij.System.Runtime.InteropServices.JavaScript.JSFunctionBinding.JSBindingType;
                        const $i1 = new $t1();
                        $i1.Type = 8/*MarshalerType.Int52*/;
                        return $i1;
                    })());
                }
                {
                    this.BigInt64 = new $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType().$ctor$2((() =>
                    {
                        //new $.$srij.System.Runtime.InteropServices.JavaScript.JSFunctionBinding.JSBindingType()
                        const $t1 = $.$srij.System.Runtime.InteropServices.JavaScript.JSFunctionBinding.JSBindingType;
                        const $i1 = new $t1();
                        $i1.Type = 9/*MarshalerType.BigInt64*/;
                        return $i1;
                    })());
                }
                {
                    this.Double = new $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType().$ctor$2((() =>
                    {
                        //new $.$srij.System.Runtime.InteropServices.JavaScript.JSFunctionBinding.JSBindingType()
                        const $t1 = $.$srij.System.Runtime.InteropServices.JavaScript.JSFunctionBinding.JSBindingType;
                        const $i1 = new $t1();
                        $i1.Type = 10/*MarshalerType.Double*/;
                        return $i1;
                    })());
                }
                {
                    this.Single = new $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType().$ctor$2((() =>
                    {
                        //new $.$srij.System.Runtime.InteropServices.JavaScript.JSFunctionBinding.JSBindingType()
                        const $t1 = $.$srij.System.Runtime.InteropServices.JavaScript.JSFunctionBinding.JSBindingType;
                        const $i1 = new $t1();
                        $i1.Type = 11/*MarshalerType.Single*/;
                        return $i1;
                    })());
                }
                {
                    this.IntPtr = new $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType().$ctor$2((() =>
                    {
                        //new $.$srij.System.Runtime.InteropServices.JavaScript.JSFunctionBinding.JSBindingType()
                        const $t1 = $.$srij.System.Runtime.InteropServices.JavaScript.JSFunctionBinding.JSBindingType;
                        const $i1 = new $t1();
                        $i1.Type = 12/*MarshalerType.IntPtr*/;
                        return $i1;
                    })());
                }
                {
                    this.JSObject = new $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType().$ctor$2((() =>
                    {
                        //new $.$srij.System.Runtime.InteropServices.JavaScript.JSFunctionBinding.JSBindingType()
                        const $t1 = $.$srij.System.Runtime.InteropServices.JavaScript.JSFunctionBinding.JSBindingType;
                        const $i1 = new $t1();
                        $i1.Type = 13/*MarshalerType.JSObject*/;
                        return $i1;
                    })());
                }
                {
                    this.Object = new $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType().$ctor$2((() =>
                    {
                        //new $.$srij.System.Runtime.InteropServices.JavaScript.JSFunctionBinding.JSBindingType()
                        const $t1 = $.$srij.System.Runtime.InteropServices.JavaScript.JSFunctionBinding.JSBindingType;
                        const $i1 = new $t1();
                        $i1.Type = 14/*MarshalerType.Object*/;
                        return $i1;
                    })());
                }
                {
                    this.String = new $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType().$ctor$2((() =>
                    {
                        //new $.$srij.System.Runtime.InteropServices.JavaScript.JSFunctionBinding.JSBindingType()
                        const $t1 = $.$srij.System.Runtime.InteropServices.JavaScript.JSFunctionBinding.JSBindingType;
                        const $i1 = new $t1();
                        $i1.Type = 15/*MarshalerType.String*/;
                        return $i1;
                    })());
                }
                {
                    this.Exception = new $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType().$ctor$2((() =>
                    {
                        //new $.$srij.System.Runtime.InteropServices.JavaScript.JSFunctionBinding.JSBindingType()
                        const $t1 = $.$srij.System.Runtime.InteropServices.JavaScript.JSFunctionBinding.JSBindingType;
                        const $i1 = new $t1();
                        $i1.Type = 16/*MarshalerType.Exception*/;
                        return $i1;
                    })());
                }
                {
                    this.DateTime = new $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType().$ctor$2((() =>
                    {
                        //new $.$srij.System.Runtime.InteropServices.JavaScript.JSFunctionBinding.JSBindingType()
                        const $t1 = $.$srij.System.Runtime.InteropServices.JavaScript.JSFunctionBinding.JSBindingType;
                        const $i1 = new $t1();
                        $i1.Type = 17/*MarshalerType.DateTime*/;
                        return $i1;
                    })());
                }
                {
                    this.DateTimeOffset = new $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType().$ctor$2((() =>
                    {
                        //new $.$srij.System.Runtime.InteropServices.JavaScript.JSFunctionBinding.JSBindingType()
                        const $t1 = $.$srij.System.Runtime.InteropServices.JavaScript.JSFunctionBinding.JSBindingType;
                        const $i1 = new $t1();
                        $i1.Type = 18/*MarshalerType.DateTimeOffset*/;
                        return $i1;
                    })());
                }
                {
                    this._task = new $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType().$ctor$2((() =>
                    {
                        //new $.$srij.System.Runtime.InteropServices.JavaScript.JSFunctionBinding.JSBindingType()
                        const $t1 = $.$srij.System.Runtime.InteropServices.JavaScript.JSFunctionBinding.JSBindingType;
                        const $i1 = new $t1();
                        $i1.Type = 20/*MarshalerType.Task*/;
                        return $i1;
                    })());
                }
                {
                    this._action = new $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType().$ctor$2((() =>
                    {
                        //new $.$srij.System.Runtime.InteropServices.JavaScript.JSFunctionBinding.JSBindingType()
                        const $t1 = $.$srij.System.Runtime.InteropServices.JavaScript.JSFunctionBinding.JSBindingType;
                        const $i1 = new $t1();
                        $i1.Type = 24/*MarshalerType.Action*/;
                        return $i1;
                    })());
                }
            }
            static $h = 2223497;
            static $f = 0b10010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":2223497,"g":{"r":0,"d":0,"h":25772027273,"f":33},"n":"Void","d":2223497,"h":21477059977,"f":33},{"p":2223497,"g":{"r":0,"d":0,"h":38656929161,"f":33},"n":"Discard","d":2223497,"h":34361961865,"f":33},{"p":2223497,"g":{"r":0,"d":0,"h":51541831049,"f":33},"n":"DiscardNoWait","d":2223497,"h":47246863753,"f":33},{"p":2223497,"g":{"r":0,"d":0,"h":64426732937,"f":33},"n":"Boolean","d":2223497,"h":60131765641,"f":33},{"p":2223497,"g":{"r":0,"d":0,"h":77311634825,"f":33},"n":"Byte","d":2223497,"h":73016667529,"f":33},{"p":2223497,"g":{"r":0,"d":0,"h":90196536713,"f":33},"n":"Char","d":2223497,"h":85901569417,"f":33},{"p":2223497,"g":{"r":0,"d":0,"h":103081438601,"f":33},"n":"Int16","d":2223497,"h":98786471305,"f":33},{"p":2223497,"g":{"r":0,"d":0,"h":115966340489,"f":33},"n":"Int32","d":2223497,"h":111671373193,"f":33},{"p":2223497,"g":{"r":0,"d":0,"h":128851242377,"f":33},"n":"Int52","d":2223497,"h":124556275081,"f":33},{"p":2223497,"g":{"r":0,"d":0,"h":141736144265,"f":33},"n":"BigInt64","d":2223497,"h":137441176969,"f":33},{"p":2223497,"g":{"r":0,"d":0,"h":154621046153,"f":33},"n":"Double","d":2223497,"h":150326078857,"f":33},{"p":2223497,"g":{"r":0,"d":0,"h":167505948041,"f":33},"n":"Single","d":2223497,"h":163210980745,"f":33},{"p":2223497,"g":{"r":0,"d":0,"h":180390849929,"f":33},"n":"IntPtr","d":2223497,"h":176095882633,"f":33},{"p":2223497,"g":{"r":0,"d":0,"h":193275751817,"f":33},"n":"JSObject","d":2223497,"h":188980784521,"f":33},{"p":2223497,"g":{"r":0,"d":0,"h":206160653705,"f":33},"n":"Object","d":2223497,"h":201865686409,"f":33},{"p":2223497,"g":{"r":0,"d":0,"h":219045555593,"f":33},"n":"String","d":2223497,"h":214750588297,"f":33},{"p":2223497,"g":{"r":0,"d":0,"h":244815359369,"f":33},"n":"DateTime","d":2223497,"h":240520392073,"f":33},{"p":2223497,"g":{"r":0,"d":0,"h":257700261257,"f":33},"n":"DateTimeOffset","d":2223497,"h":253405293961,"f":33},{"p":2223497,"g":{"r":0,"d":0,"h":274880130441,"f":34},"n":"_task","d":2223497,"h":270585163145,"f":34},{"p":2223497,"g":{"r":0,"d":0,"h":309239868809,"f":34},"n":"_action","d":2223497,"h":304944901513,"f":34}],"m":[{"r":2223497,"p":[{"n":"primitive","p":2223497}],"n":"Nullable","d":2223497,"h":261995228553,"f":33},{"r":2223497,"n":"Task","d":2223497,"h":279175097737,"f":33},{"r":2223497,"p":[{"n":"result","p":2223497}],"n":"Task","o":"@$1","d":2223497,"h":283470065033,"f":33},{"r":2223497,"p":[{"n":"element","p":2223497}],"n":"Array","d":2223497,"h":287765032329,"f":33},{"r":2223497,"p":[{"n":"element","p":2223497}],"n":"ArraySegment","d":2223497,"h":292059999625,"f":33},{"r":2223497,"p":[{"n":"element","p":2223497}],"n":"Span","d":2223497,"h":296354966921,"f":33},{"r":2223497,"n":"Action","d":2223497,"h":313534836105,"f":33},{"r":2223497,"p":[{"n":"arg1","p":2223497}],"n":"Action","o":"@$1","d":2223497,"h":317829803401,"f":33},{"r":2223497,"p":[{"n":"arg1","p":2223497},{"n":"arg2","p":2223497}],"n":"Action","o":"@$2","d":2223497,"h":322124770697,"f":33},{"r":2223497,"p":[{"n":"arg1","p":2223497},{"n":"arg2","p":2223497},{"n":"arg3","p":2223497}],"n":"Action","o":"@$3","d":2223497,"h":326419737993,"f":33},{"r":2223497,"p":[{"n":"result","p":2223497}],"n":"Function","d":2223497,"h":330714705289,"f":33},{"r":2223497,"p":[{"n":"arg1","p":2223497},{"n":"result","p":2223497}],"n":"Function","o":"@$1","d":2223497,"h":335009672585,"f":33},{"r":2223497,"p":[{"n":"arg1","p":2223497},{"n":"arg2","p":2223497},{"n":"result","p":2223497}],"n":"Function","o":"@$2","d":2223497,"h":339304639881,"f":33},{"r":2223497,"p":[{"n":"arg1","p":2223497},{"n":"arg2","p":2223497},{"n":"arg3","p":2223497},{"n":"result","p":2223497}],"n":"Function","o":"@$3","d":2223497,"h":343599607177,"f":33},{"r":65537,"p":[{"n":"underlyingType","p":2223497}],"n":"CheckNullable","d":2223497,"h":347894574473,"f":40},{"r":65537,"p":[{"n":"underlyingType","p":2223497}],"n":"CheckArray","d":2223497,"h":352189541769,"f":40},{"r":65537,"p":[{"n":"underlyingType","p":2223497}],"n":"CheckArraySegment","d":2223497,"h":356484509065,"f":40},{"r":65537,"p":[{"n":"underlyingType","p":2223497}],"n":"CheckTask","d":2223497,"h":360779476361,"f":40}],"l":[{"t":716169,"n":"_signatureType","d":2223497,"h":4297190793,"f":8}],"c":[{"n":".ctor","o":"$ctor$1","d":2223497,"h":8592158089,"f":2},{"p":[{"n":"signatureType","p":716169}],"n":".ctor","o":"$ctor$2","d":2223497,"h":12887125385,"f":2}],"h":2223497,"a":[{"t":114950145,"c":4409917441,"a":[{"v":"browser","t":1310721}]},{"t":33226753,"c":4328194049,"a":[{"v":1,"t":33292289}]}]}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.Runtime.InteropServices.JavaScript.JSMarshalerType`; }
        });
        
        $asm.$cls("$srij.System.SR", ($self) => class SR
        {
            /*global::System.Resources.ResourceManager*/ static s_resourceManager = null;
            /*global::System.Globalization.CultureInfo*/ static resourceCulture = null;
            static /*global::System.Resources.ResourceManager */ get ResourceManager()
            {
                if ($.$spc.System.Object.ReferenceEquals($.$srij.System.SR.s_resourceManager, null))
                {
                    /*global::System.Resources.ResourceManager*/ let temp = new $.$spc.System.Resources.ResourceManager().$ctor$3("System.Runtime.InteropServices.JavaScript", $.$srij.System.SR.$type.Assembly);
                    $.$srij.System.SR.s_resourceManager = temp;
                }
                return $.$srij.System.SR.s_resourceManager;
            }
            static /*global::System.Globalization.CultureInfo */ get Culture()
            {
                return $.$srij.System.SR.resourceCulture;
            }
            static /*global::System.Globalization.CultureInfo */ set Culture(value)
            {
                $.$srij.System.SR.resourceCulture = value;
            }
            static /*string */ get ArgumentCannotBeNull()
            {
                return "Invalid argument: {0} can not be null.";
            }
            static /*string */ FormatArgumentCannotBeNull(/*object*/ arg1)
            {
                return $.$spc.System.String.Format("Invalid argument: {0} can not be null.", arg1);
            }
            static /*string */ get ArgumentCannotBeNullWithLength()
            {
                return "Invalid argument: {0} can not be null and must have a length.";
            }
            static /*string */ FormatArgumentCannotBeNullWithLength(/*object*/ arg1)
            {
                return $.$spc.System.String.Format("Invalid argument: {0} can not be null and must have a length.", arg1);
            }
            static /*string */ get SystemRuntimeInteropServicesJavaScript_PlatformNotSupported()
            {
                return "System.Runtime.InteropServices.JavaScript is not supported on this platform.";
            }
            static /*string */ get TypedArrayNotCorrectType()
            {
                return "TypedArray is not of correct type.";
            }
            static /*string */ get UnableCastNullToType()
            {
                return "Unable to cast null to type {0}.";
            }
            static /*string */ FormatUnableCastNullToType(/*object*/ arg1)
            {
                return $.$spc.System.String.Format("Unable to cast null to type {0}.", arg1);
            }
            static /*string */ get UnableCastObjectToType()
            {
                return "Unable to cast object of type {0} to type {1}.";
            }
            static /*string */ FormatUnableCastObjectToType(/*object*/ arg1, /*object*/ arg2)
            {
                return $.$spc.System.String.Format$1("Unable to cast object of type {0} to type {1}.", arg1, arg2);
            }
            static /*string */ get MissingManagedEntrypointHandle()
            {
                return "Managed entrypoint handle is not set.";
            }
            static /*string */ get CannotResolveManagedEntrypointHandle()
            {
                return "Cannot resolve managed entrypoint handle.";
            }
            static /*string */ get ReturnTypeNotSupportedForMain()
            {
                return "Return type '{0}' from main method in not supported.";
            }
            static /*string */ FormatReturnTypeNotSupportedForMain(/*object*/ arg1)
            {
                return $.$spc.System.String.Format("Return type '{0}' from main method in not supported.", arg1);
            }
            static /*string */ get NullToManagedCallback()
            {
                return "ToManagedCallback is null.";
            }
            static /*string */ get NullPromiseHolder()
            {
                return "PromiseHolder is null.";
            }
            static /*string */ get EmptyProfileData()
            {
                return "Empty profile data.";
            }
            static /*string */ get ErrorLegacySettingProperty()
            {
                return "Error setting {0} on (js-obj js '{1}'): {2}.";
            }
            static /*string */ FormatErrorLegacySettingProperty(/*object*/ arg1, /*object*/ arg2, /*object*/ arg3)
            {
                return $.$spc.System.String.Format$2("Error setting {0} on (js-obj js '{1}'): {2}.", arg1, arg2, arg3);
            }
            static /*string */ get ErrorResolvingFromGlobalThis()
            {
                return "Error resolving property {0} from globalThis.";
            }
            static /*string */ FormatErrorResolvingFromGlobalThis(/*object*/ arg1)
            {
                return $.$spc.System.String.Format("Error resolving property {0} from globalThis.", arg1);
            }
            static /*string */ get FailedToMarshalException()
            {
                return "Failed to marshal exception.";
            }
            static /*string */ get FailedToMarshalPromiseHolder()
            {
                return "Failed to marshal Promise callback.";
            }
            static /*string */ get InvalidInFlightCounter()
            {
                return "Invalid InFlightCounter for JSObject {0}, expected: {1}, actual: {2}.";
            }
            static /*string */ FormatInvalidInFlightCounter(/*object*/ arg1, /*object*/ arg2, /*object*/ arg3)
            {
                return $.$spc.System.String.Format$2("Invalid InFlightCounter for JSObject {0}, expected: {1}, actual: {2}.", arg1, arg2, arg3);
            }
            static /*string */ get ToJSNotImplemented()
            {
                return "ToJS for {0} is not implemented.";
            }
            static /*string */ FormatToJSNotImplemented(/*object*/ arg1)
            {
                return $.$spc.System.String.Format("ToJS for {0} is not implemented.", arg1);
            }
            static /*string */ get ToManagedNotImplemented()
            {
                return "ToManaged for {0} is not implemented.";
            }
            static /*string */ FormatToManagedNotImplemented(/*object*/ arg1)
            {
                return $.$spc.System.String.Format("ToManaged for {0} is not implemented.", arg1);
            }
            static /*string */ get UnableToResolveHandleAsException()
            {
                return "Unable to resolve the handle as an Exception.";
            }
            static /*string */ get UnsupportedArrayType()
            {
                return "Unsupported array type {0}. Only single-dimensional arrays with a zero lower bound can be marshaled to JS.";
            }
            static /*string */ FormatUnsupportedArrayType(/*object*/ arg1)
            {
                return $.$spc.System.String.Format("Unsupported array type {0}. Only single-dimensional arrays with a zero lower bound can be marshaled to JS.", arg1);
            }
            static /*string */ get UnsupportedElementType()
            {
                return "Unsupported element type {0}.";
            }
            static /*string */ FormatUnsupportedElementType(/*object*/ arg1)
            {
                return $.$spc.System.String.Format("Unsupported element type {0}.", arg1);
            }
            static /*string */ get UnsupportedEnumType()
            {
                return "Unsupported enum type {0}.";
            }
            static /*string */ FormatUnsupportedEnumType(/*object*/ arg1)
            {
                return $.$spc.System.String.Format("Unsupported enum type {0}.", arg1);
            }
            static /*string */ get UnsupportedLegacyMarshlerType()
            {
                return "Unsupported marshal type {0}.";
            }
            static /*string */ FormatUnsupportedLegacyMarshlerType(/*object*/ arg1)
            {
                return $.$spc.System.String.Format("Unsupported marshal type {0}.", arg1);
            }
            static /*string */ get UnsupportedNullableType()
            {
                return "Unsupported nullable type {0}.";
            }
            static /*string */ FormatUnsupportedNullableType(/*object*/ arg1)
            {
                return $.$spc.System.String.Format("Unsupported nullable type {0}.", arg1);
            }
            static /*string */ get UnsupportedTaskResultType()
            {
                return "Unsupported task result type {0}.";
            }
            static /*string */ FormatUnsupportedTaskResultType(/*object*/ arg1)
            {
                return $.$spc.System.String.Format("Unsupported task result type {0}.", arg1);
            }
            static /*string */ get UriConstructorMissing()
            {
                return "Constructor on type 'System.Uri' not found. Please consider to protect it's constructor from trimming.";
            }
            static /*string */ get UriTypeMissing()
            {
                return "The type System.Uri could not be found. Please consider to protect the class and it's constructor from trimming.";
            }
            static /*string */ get ValueOutOf52BitRange()
            {
                return "Overflow: value {0} is out of {1} {2} range.";
            }
            static /*string */ FormatValueOutOf52BitRange(/*object*/ arg1, /*object*/ arg2, /*object*/ arg3)
            {
                return $.$spc.System.String.Format$2("Overflow: value {0} is out of {1} {2} range.", arg1, arg2, arg3);
            }
            /*bool*/ static s_usingResourceKeys = false;
            static /*bool */ GetUsingResourceKeysSwitchValue()
            {
                /*bool*/ let usingResourceKeys;
                return $.$spc.System.AppContext.TryGetSwitch("System.Resources.UseSystemResourceKeys", $.$ref(() => usingResourceKeys, ($v) => usingResourceKeys = $v, $.$spc.System.Boolean)) ? usingResourceKeys : false;
            }
            static /*bool */ UsingResourceKeys()
            {
                return $.$srij.System.SR.s_usingResourceKeys;
            }
            static /*string */ GetResourceString(/*string*/ resourceKey)
            {
                if ($.$srij.System.SR.UsingResourceKeys())
                {
                    return resourceKey;
                }
                /*string?*/ let resourceString = null;
                try
                {
                    resourceString = $.$srij.System.SR.ResourceManager.GetString(resourceKey);
                }
                catch($e)
                {
                }
                return resourceString;
            }
            static /*string */ GetResourceString$1(/*string*/ resourceKey, /*string*/ defaultString)
            {
                /*string*/ let resourceString = $.$srij.System.SR.GetResourceString(resourceKey);
                return $.$spc.System.String.op_Equality(resourceKey, resourceString) || $.$spc.System.String.op_Equality(resourceString, null) ? defaultString : resourceString;
            }
            static /*string */ Format(/*string*/ resourceFormat, /*object?*/ p1)
            {
                if ($.$srij.System.SR.UsingResourceKeys())
                {
                    return $.$spc.System.String.Join$10(", ", $.$spc.System.ReadOnlySpan$$($.$spc.System.Object).op_Implicit([ resourceFormat, p1 ]));
                }
                return $.$spc.System.String.Format(resourceFormat, p1);
            }
            static /*string */ Format$1(/*string*/ resourceFormat, /*object?*/ p1, /*object?*/ p2)
            {
                if ($.$srij.System.SR.UsingResourceKeys())
                {
                    return $.$spc.System.String.Join$10(", ", $.$spc.System.ReadOnlySpan$$($.$spc.System.Object).op_Implicit([ resourceFormat, p1, p2 ]));
                }
                return $.$spc.System.String.Format$1(resourceFormat, p1, p2);
            }
            static /*string */ Format$2(/*string*/ resourceFormat, /*object?*/ p1, /*object?*/ p2, /*object?*/ p3)
            {
                if ($.$srij.System.SR.UsingResourceKeys())
                {
                    return $.$spc.System.String.Join$10(", ", $.$spc.System.ReadOnlySpan$$($.$spc.System.Object).op_Implicit([ resourceFormat, p1, p2, p3 ]));
                }
                return $.$spc.System.String.Format$2(resourceFormat, p1, p2, p3);
            }
            static /*string */ Format$3(/*string*/ resourceFormat, /*params object?[]?*/ args)
            {
                if (args !== null)
                {
                    if ($.$srij.System.SR.UsingResourceKeys())
                    {
                        return resourceFormat + ", " + $.$spc.System.String.Join$9(", ", args);
                    }
                    return $.$spc.System.String.Format$3(resourceFormat, args);
                }
                return resourceFormat;
            }
            static /*string */ Format$4(/*IFormatProvider?*/ provider, /*string*/ resourceFormat, /*object?*/ p1)
            {
                if ($.$srij.System.SR.UsingResourceKeys())
                {
                    return $.$spc.System.String.Join$10(", ", $.$spc.System.ReadOnlySpan$$($.$spc.System.Object).op_Implicit([ resourceFormat, p1 ]));
                }
                return $.$spc.System.String.Format$5(provider, resourceFormat, p1);
            }
            static /*string */ Format$5(/*IFormatProvider?*/ provider, /*string*/ resourceFormat, /*object?*/ p1, /*object?*/ p2)
            {
                if ($.$srij.System.SR.UsingResourceKeys())
                {
                    return $.$spc.System.String.Join$10(", ", $.$spc.System.ReadOnlySpan$$($.$spc.System.Object).op_Implicit([ resourceFormat, p1, p2 ]));
                }
                return $.$spc.System.String.Format$6(provider, resourceFormat, p1, p2);
            }
            static /*string */ Format$6(/*IFormatProvider?*/ provider, /*string*/ resourceFormat, /*object?*/ p1, /*object?*/ p2, /*object?*/ p3)
            {
                if ($.$srij.System.SR.UsingResourceKeys())
                {
                    return $.$spc.System.String.Join$10(", ", $.$spc.System.ReadOnlySpan$$($.$spc.System.Object).op_Implicit([ resourceFormat, p1, p2, p3 ]));
                }
                return $.$spc.System.String.Format$7(provider, resourceFormat, p1, p2, p3);
            }
            static /*string */ Format$7(/*IFormatProvider?*/ provider, /*string*/ resourceFormat, /*params object?[]?*/ args)
            {
                if (args !== null)
                {
                    if ($.$srij.System.SR.UsingResourceKeys())
                    {
                        return resourceFormat + ", " + $.$spc.System.String.Join$9(", ", args);
                    }
                    return $.$spc.System.String.Format$8(provider, resourceFormat, args);
                }
                return resourceFormat;
            }
            //Static Initializer
            static $sinit()
            {
                {
                    this.s_usingResourceKeys = $.$srij.System.SR.GetUsingResourceKeysSwitchValue();
                }
            }
            static $h = 3796361;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"h":3796361}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.SR`; }
        });
        
        $asm.$cls("$srij.System.Runtime.InteropServices.JavaScript.CancelablePromise", ($self) => class CancelablePromise
        {
            static /*void */ CancelPromise(/*Task*/ promise)
            {
                if (promise.IsCompleted)
                {
                    return;
                }
                /*JSHostImplementation.PromiseHolder?*/ let holder = $.$as(promise.AsyncState, $.$srij.System.Runtime.InteropServices.JavaScript.JSHostImplementation.$.$srij.System.Runtime.InteropServices.JavaScript.JSHostImplementation.PromiseHolder);
                if (holder === null)
                {
                    throw new $.$spc.System.InvalidOperationException().$ctor$10("Expected Task converted from JS Promise");
                }
                if (holder.IsDisposed)
                {
                    return;
                }
                $.$srij.Interop.Runtime.CancelPromise(holder.GCHandle);
            }
            static $h = 257417;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"m":[{"r":65537,"p":[{"n":"promise","p":133300225}],"n":"CancelPromise","d":257417,"h":4295224713,"f":33}],"h":257417}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.Runtime.InteropServices.JavaScript.CancelablePromise`; }
        });
        
        $asm.$cls("$srij.System.Runtime.InteropServices.JavaScript.JSHostImplementation", ($self) => class JSHostImplementation
        {
            static $_ToManagedCallback;
            static get ToManagedCallback()
            {
                let $cls = $.$srij.System.Runtime.InteropServices.JavaScript.JSHostImplementation;
                return $cls.$_ToManagedCallback ??= $asm.$ncls("$srij.System.Runtime.InteropServices.JavaScript.JSHostImplementation.ToManagedCallback", ($self) => class ToManagedCallback extends $.$spc.System.MulticastDelegate
                {
                    $ctor(/*object*/ target, fn, anmodel)
                    {
                        this.$target = target;
                        this.$nativeFunction = fn;
                        if (anmodel) this.$nfmodel = anmodel;
                        if (typeof(target) === 'object') this._target = target;
                        return this;
                    }
                    /*void*/ Invoke(/**/ arguments_buffer)
                    {
                        return this.$nativeFunction.call(this.$target, arguments_buffer);
                    }
                    static $h = 1174921;
                    static $f = 0b10000000010000000;
                    static $k = 5;
                    static $$md;
                    static get $md() { return this.$$md ??= {"b":66191361,"m":[{"r":65537,"p":[{"n":"arguments_buffer","p":0}],"n":"Invoke","d":1174921,"h":8591109513,"f":129},{"r":57016321,"p":[{"n":"arguments_buffer","p":0},{"n":"callback","p":14483457},{"n":"object","p":131073}],"n":"BeginInvoke","d":1174921,"h":12886076809,"f":129},{"r":65537,"p":[{"n":"result","p":57016321}],"n":"EndInvoke","d":1174921,"h":17181044105,"f":129}],"c":[{"p":[{"n":"object","p":131073},{"n":"method","p":786433}],"n":".ctor","o":"$ctor$5","d":1174921,"h":4296142217,"f":1}],"i":[57212929,113377281],"d":847241,"h":1174921}; }
                    static get $b() { return $.$spc.System.MulticastDelegate; }
                    static $$i;
                    static get $i() { return this.$$i ??= [ $.$spc.System.ICloneable, $.$spc.System.Runtime.Serialization.ISerializable ]; }
                    static get $fullName() { return `System.Runtime.InteropServices.JavaScript.JSHostImplementation.ToManagedCallback`; }
                }, $cls, ($v) => $cls.$_ToManagedCallback = $v);
            }
            static $_PromiseHolder;
            static get PromiseHolder()
            {
                let $cls = $.$srij.System.Runtime.InteropServices.JavaScript.JSHostImplementation;
                return $cls.$_PromiseHolder ??= $asm.$ncls("$srij.System.Runtime.InteropServices.JavaScript.JSHostImplementation.PromiseHolder", ($self) => class PromiseHolder extends $.$spc.System.Object
                {
                    /*bool*/ IsDisposed = false;
                    /*nint*/ GCHandle = 0;
                    /*ToManagedCallback?*/ Callback = null;
                    /*JSProxyContext*/ ProxyContext = null;
                    $ctor$1(/*JSProxyContext*/ targetContext)
                    {
                        super.$ctor();
                        {
                            this.GCHandle = $.$spc.System.Runtime.InteropServices.GCHandle.op_Explicit$1($.$spc.System.Runtime.InteropServices.GCHandle.Alloc$1(this, 2/*GCHandleType.Normal*/));
                            this.ProxyContext = targetContext;
                        }
                        return this;
                    }
                    $ctor$2(/*JSProxyContext*/ targetContext, /*nint*/ gcvHandle)
                    {
                        super.$ctor();
                        {
                            this.GCHandle = gcvHandle;
                            this.ProxyContext = targetContext;
                        }
                        return this;
                    }
                    static $h = 1043849;
                    static $f = 0b10000000010010001;
                    static $k = 1;
                    static $$md;
                    static get $md() { return this.$$md ??= {"b":131073,"l":[{"t":262145,"n":"IsDisposed","d":1043849,"h":4296011145,"f":1},{"t":786433,"n":"GCHandle","d":1043849,"h":8590978441,"f":1},{"t":1174921,"n":"Callback","d":1043849,"h":12885945737,"f":1},{"t":2354569,"n":"ProxyContext","d":1043849,"h":17180913033,"f":1}],"c":[{"p":[{"n":"targetContext","p":2354569}],"n":".ctor","o":"$ctor$1","d":1043849,"h":21475880329,"f":1},{"p":[{"n":"targetContext","p":2354569},{"n":"gcvHandle","p":786433}],"n":".ctor","o":"$ctor$2","d":1043849,"h":25770847625,"f":1}],"d":847241,"h":1043849}; }
                    static get $b() { return $.$spc.System.Object; }
                    static get $fullName() { return `System.Runtime.InteropServices.JavaScript.JSHostImplementation.PromiseHolder`; }
                }, $cls, ($v) => $cls.$_PromiseHolder = $v);
            }
            static $_PromiseHolderState;
            static get PromiseHolderState()
            {
                let $cls = $.$srij.System.Runtime.InteropServices.JavaScript.JSHostImplementation;
                return $cls.$_PromiseHolderState ??= $asm.$nstr("$srij.System.Runtime.InteropServices.JavaScript.JSHostImplementation.PromiseHolderState", ($self) => class PromiseHolderState extends $.$spc.System.ValueType
                {
                    /*int*/  get IsResolving() { return this.$getField(0, $.$spc.System.Int32); }
                    /*int*/  set IsResolving(value) { this.$setField(0, $.$spc.System.Int32, value); }
                    //default value type constructor
                    $ctor$2()
                    {
                        return this;
                    }
                    Clone($copy)
                    {
                        let copy = $copy ?? new this.constructor();
                        copy.IsResolving = this.IsResolving;
                        return copy;
                    }
                    //default member initializer
                    constructor()
                    {
                        super();
                        this.IsResolving = 0;
                    }
                    static $h = 1109385;
                    static $z = 4;
                    static $f = 0b10100010000001010000001;
                    static $k = 2;
                    static $$md;
                    static get $md() { return this.$$md ??= {"b":196609,"l":[{"t":655361,"n":"IsResolving","d":1109385,"h":4296076681,"f":1,"a":[{"t":104071169,"c":4399038465,"a":[{"v":0,"t":655361}]}]}],"c":[{"n":".ctor","o":"$ctor$2","d":1109385,"h":8591043977,"f":1}],"d":847241,"h":1109385,"a":[{"t":109903873,"c":4404871169,"a":[{"v":2,"t":105381889}]}]}; }
                    static get $b() { return $.$spc.System.ValueType; }
                    static get $fullName() { return `System.Runtime.InteropServices.JavaScript.JSHostImplementation.PromiseHolderState`; }
                }, $cls, ($v) => $cls.$_PromiseHolderState = $v);
            }
            static $_IntPtrAndHandle;
            static get IntPtrAndHandle()
            {
                let $cls = $.$srij.System.Runtime.InteropServices.JavaScript.JSHostImplementation;
                return $cls.$_IntPtrAndHandle ??= $asm.$nstr("$srij.System.Runtime.InteropServices.JavaScript.JSHostImplementation.IntPtrAndHandle", ($self) => class IntPtrAndHandle extends $.$spc.System.ValueType
                {
                    /*IntPtr*/  get ptr() { return this.$getField(0, 4); }
                    /*IntPtr*/  set ptr(value) { this.$setField(0, 4, value); }
                    /*RuntimeMethodHandle*/  get methodHandle() { return this.$getField(0, 1); }
                    /*RuntimeMethodHandle*/  set methodHandle(value) { this.$setField(0, 1, value); }
                    /*RuntimeTypeHandle*/  get typeHandle() { return this.$getField(0, 1); }
                    /*RuntimeTypeHandle*/  set typeHandle(value) { this.$setField(0, 1, value); }
                    //default value type constructor
                    $ctor$2()
                    {
                        return this;
                    }
                    Clone($copy)
                    {
                        let copy = $copy ?? new this.constructor();
                        copy.ptr = this.ptr;
                        copy.methodHandle = this.methodHandle.Clone();
                        copy.typeHandle = this.typeHandle.Clone();
                        return copy;
                    }
                    //default member initializer
                    constructor()
                    {
                        super();
                        this.ptr = 0;
                        this.methodHandle = $.$default($.$spc.System.RuntimeMethodHandle);
                        this.typeHandle = $.$default($.$spc.System.RuntimeTypeHandle);
                    }
                    static $h = 912777;
                    static $z = 4;
                    static $f = 0b100010000001010000001;
                    static $k = 2;
                    static $$md;
                    static get $md() { return this.$$md ??= {"b":196609,"l":[{"t":786433,"n":"ptr","d":912777,"h":4295880073,"f":8,"a":[{"t":104071169,"c":4399038465,"a":[{"v":0,"t":655361}]}]},{"t":115605505,"n":"methodHandle","d":912777,"h":8590847369,"f":8,"a":[{"t":104071169,"c":4399038465,"a":[{"v":0,"t":655361}]}]},{"t":116064257,"n":"typeHandle","d":912777,"h":12885814665,"f":8,"a":[{"t":104071169,"c":4399038465,"a":[{"v":0,"t":655361}]}]}],"c":[{"n":".ctor","o":"$ctor$2","d":912777,"h":17180781961,"f":1}],"d":847241,"h":912777,"a":[{"t":109903873,"c":4404871169,"a":[{"v":2,"t":105381889}]}]}; }
                    static get $b() { return $.$spc.System.ValueType; }
                    static get $fullName() { return `System.Runtime.InteropServices.JavaScript.JSHostImplementation.IntPtrAndHandle`; }
                }, $cls, ($v) => $cls.$_IntPtrAndHandle = $v);
            }
            static $_JSThreadBlockingMode;
            static get JSThreadBlockingMode()
            {
                let $cls = $.$srij.System.Runtime.InteropServices.JavaScript.JSHostImplementation;
                return $cls.$_JSThreadBlockingMode ??= $asm.$nstr("$srij.System.Runtime.InteropServices.JavaScript.JSHostImplementation.JSThreadBlockingMode", ($self) => class JSThreadBlockingMode extends $.$spc.System.Enum
                {
                    static PreventSynchronousJSExport = 0;
                    static ThrowWhenBlockingWait = 1;
                    static WarnWhenBlockingWait = 2;
                    static DangerousAllowBlockingWait = 100;
                    static $map;
                    static get Map()
                    {
                        return this.$map ??= 
                        {
                            "PreventSynchronousJSExport": 0n,
                            "ThrowWhenBlockingWait": 1n,
                            "WarnWhenBlockingWait": 2n,
                            "DangerousAllowBlockingWait": 100n
                        };
                    }
                    static $h = 978313;
                    static $z = 4;
                    static $f = 0b110000011010001001;
                    static $k = 4;
                    static get $eut() { return $.$spc.System.Int32; }
                    static $$md;
                    static get $md() { return this.$$md ??= {"b":1048577,"u":655361,"l":[{"t":978313,"n":"PreventSynchronousJSExport","d":978313,"h":4295945609,"f":33},{"t":978313,"n":"ThrowWhenBlockingWait","d":978313,"h":8590912905,"f":33},{"t":978313,"n":"WarnWhenBlockingWait","d":978313,"h":12885880201,"f":33},{"t":978313,"n":"DangerousAllowBlockingWait","d":978313,"h":17180847497,"f":33}],"c":[{"n":".ctor","o":"$ctor$3","d":978313,"h":21475814793,"f":1}],"i":[57278465,63832065,57737217,57409537],"d":847241,"h":978313}; }
                    static get $b() { return $.$spc.System.Enum; }
                    static $$i;
                    static get $i() { return this.$$i ??= [ $.$spc.System.IComparable, $.$spc.System.ISpanFormattable, $.$spc.System.IFormattable, $.$spc.System.IConvertible ]; }
                    static get $fullName() { return `System.Runtime.InteropServices.JavaScript.JSHostImplementation.JSThreadBlockingMode`; }
                }, $cls, ($v) => $cls.$_JSThreadBlockingMode = $v);
            }
            /*string*/ static TaskGetResultName = null;
            /*MethodInfo?*/ static s_taskGetResultMethodInfo = null;
            static /*bool */ GetTaskResultDynamic(/*Task*/ task, /*out object?*/ value)
            {
                /*var*/ let type = $.$spc.System.Object.GetType.call(task);
                if ($.$spc.System.Type.op_Equality$1(type, $.$spc.System.Threading.Tasks.Task.$type))
                {
                    value.$v = null;
                    return false;
                }
                /*MethodInfo*/ let method = $.$srij.System.Runtime.InteropServices.JavaScript.JSHostImplementation.GetTaskResultMethodInfo(type);
                if ($.$spc.System.Reflection.MethodInfo.op_Inequality$2(method, null))
                {
                    value.$v = method.Invoke(task, null);
                    return true;
                }
                throw new $.$spc.System.InvalidOperationException().$ctor$9();
            }
            static /*MethodInfo */ GetTaskResultMethodInfo(/*Type*/ taskType)
            {
                if ($.$spc.System.Type.op_Inequality$1(taskType, null))
                {
                    if ($.$spc.System.Reflection.MethodInfo.op_Equality$2($.$srij.System.Runtime.InteropServices.JavaScript.JSHostImplementation.s_taskGetResultMethodInfo, null))
                    {
                        $.$srij.System.Runtime.InteropServices.JavaScript.JSHostImplementation.s_taskGetResultMethodInfo = $.$spc.System.Threading.Tasks.Task$$().$type.GetMethod$1("get_Result"/*TaskGetResultName*/);
                    }
                    /*MethodInfo?*/ let getter = taskType.GetMethod$1("get_Result"/*TaskGetResultName*/);
                    if ($.$spc.System.Reflection.MethodInfo.op_Inequality$2(getter, null) && getter.HasSameMetadataDefinitionAs($.$srij.System.Runtime.InteropServices.JavaScript.JSHostImplementation.s_taskGetResultMethodInfo))
                    {
                        return getter;
                    }
                }
                throw new $.$spc.System.InvalidOperationException().$ctor$9();
            }
            static /*void */ ThrowException(/*ref JSMarshalerArgument*/ arg)
            {
                /*Exception?*/ let ex;
                arg.$v.ToManaged$24($.$ref(() => ex, ($v) => ex = $v, $.$spc.System.Exception));
                if (ex !== null)
                {
                    throw ex;
                }
                throw new $.$spc.System.InvalidOperationException().$ctor$9();
            }
            static /*Task<JSObject> *//*async*/  ImportAsync(/*string*/ moduleName, /*string*/ moduleUrl, /*CancellationToken*/ cancellationToken)
            {
                return $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.Async($.$spc.System.Threading.Tasks.Task$$($.$srij.System.Runtime.InteropServices.JavaScript.JSObject), $.$srij.System.Runtime.InteropServices.JavaScript.JSObject, async () => 
                {
                    /*Task<JSObject>*/ let modulePromise = INTERNAL.dynamic_import(moduleName, moduleUrl);
                    /*var*/ let wrappedTask = $.$srij.System.Runtime.InteropServices.JavaScript.JSHostImplementation.CancellationHelper(modulePromise, cancellationToken);
                    return await wrappedTask.ConfigureAwait$3(1/*ConfigureAwaitOptions.ContinueOnCapturedContext*/ | 4/*ConfigureAwaitOptions.ForceYielding*/);
                });
            }
            static /*Task<JSObject> *//*async*/  CancellationHelper(/*Task<JSObject>*/ jsTask, /*CancellationToken*/ cancellationToken)
            {
                return $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.Async($.$spc.System.Threading.Tasks.Task$$($.$srij.System.Runtime.InteropServices.JavaScript.JSObject), $.$srij.System.Runtime.InteropServices.JavaScript.JSObject, async () => 
                {
                    if (jsTask.IsCompletedSuccessfully)
                    {
                        return jsTask.Result;
                    }
                    let receiveRegistration = null;
                    try
                    {
                        receiveRegistration = cancellationToken.Register$2(new ($.$spc.System.Action$$($.$spc.System.Object))().$ctor($.$srij.System.Runtime.InteropServices.JavaScript.JSHostImplementation, /*static*/ (/*s*/ s) =>
                        {
                            $.$srij.System.Runtime.InteropServices.JavaScript.CancelablePromise.CancelPromise($.$cast(s, $.$spc.System.Threading.Tasks.Task$$($.$srij.System.Runtime.InteropServices.JavaScript.JSObject)));
                        }, {"r":65537,"p":[{"n":"s","p":131073}],"n":"","d":847241,"h":0,"f":1048610}), jsTask);
                        return await jsTask.ConfigureAwait$2(false);
                    }
                    finally
                    {
                        receiveRegistration?.System$IDisposable$Dispose();
                    }
                });
            }
            static /*JSFunctionBinding */ GetMethodSignature(/*ReadOnlySpan<JSMarshalerType>*/ types, /*string?*/ functionName, /*string?*/ moduleName)
            {
                /*int*/ let argsCount = ((types.Length - 1) | 0);
                /*int*/ let size = ((32/*JSFunctionBinding.JSBindingHeader.JSMarshalerSignatureHeaderSize*/ + ((((((argsCount + 2) | 0)) * $.$srij.System.Runtime.InteropServices.JavaScript.JSFunctionBinding.JSBindingType.$z) | 0))) | 0);
                /*int*/ let functionNameBytes = 0;
                /*int*/ let functionNameOffset = 0;
                if ($.$spc.System.String.op_Inequality(functionName, null))
                {
                    functionNameOffset = size;
                    size += 4;
                    functionNameBytes = ((functionName.length * 2) | 0);
                    size += functionNameBytes;
                }
                /*int*/ let moduleNameBytes = 0;
                /*int*/ let moduleNameOffset = 0;
                if ($.$spc.System.String.op_Inequality(moduleName, null))
                {
                    moduleNameOffset = size;
                    size += 4;
                    moduleNameBytes = ((moduleName.length * 2) | 0);
                    size += moduleNameBytes;
                }
                /*IntPtr*/ let buffer = $.$spc.System.Runtime.InteropServices.Marshal.AllocHGlobal(size);
                /*var*/ let signature = (() =>
                {
                    //new $.$srij.System.Runtime.InteropServices.JavaScript.JSFunctionBinding()
                    const $t1 = $.$srij.System.Runtime.InteropServices.JavaScript.JSFunctionBinding;
                    const $i1 = new $t1();
                    $i1.$ctor$1();
                    $i1.Header = $.$cast(buffer, $.$typePointer($.$srij.System.Runtime.InteropServices.JavaScript.JSFunctionBinding.JSBindingHeader));
                    $i1.Sigs = $.$cast((buffer + 32/*JSFunctionBinding.JSBindingHeader.JSMarshalerSignatureHeaderSize*/ + (((2 * $.$srij.System.Runtime.InteropServices.JavaScript.JSFunctionBinding.JSBindingType.$z) | 0))), $.$typePointer($.$srij.System.Runtime.InteropServices.JavaScript.JSFunctionBinding.JSBindingType));
                    return $i1;
                })();
                signature.Version = 2;
                signature.ArgumentCount = argsCount;
                signature.Exception = $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType.Exception._signatureType;
                signature.Result = types.get_Item(0).$v._signatureType;
                signature.ImportHandle = ($.$srij.System.Runtime.InteropServices.JavaScript.JSFunctionBinding.nextImportHandle++ | 0);
                signature.FunctionName = functionName;
                for(/*int*/ let i = 0; i < argsCount; i++)
                {
                    /*var*/ let type = signature.Sigs.SetAt(types.get_Item(((i + 1) | 0)).$v._signatureType, i);
                }
                signature.IsAsync = types.get_Item(0).$v._signatureType.Type === 20/*MarshalerType.Task*/;
                signature.IsDiscardNoWait = types.get_Item(0).$v._signatureType.Type === 26/*MarshalerType.DiscardNoWait*/;
                signature.Header.GetAt(0).ImportHandle = signature.ImportHandle;
                signature.Header.GetAt(0).FunctionNameLength = functionNameBytes;
                signature.Header.GetAt(0).FunctionNameOffset = functionNameOffset;
                signature.Header.GetAt(0).ModuleNameLength = moduleNameBytes;
                signature.Header.GetAt(0).ModuleNameOffset = moduleNameOffset;
                if (functionNameBytes !== 0)
                {
                    /*fixed*/ 
                    {
                        /*void**/ let fn = $.$spc.System.String.GetPinnableReference.call(functionName);
                        $.$spc.System.Runtime.CompilerServices.Unsafe.CopyBlock($.$cast(buffer, $.$typePointer($.$spc.System.Byte)).Add(functionNameOffset), fn, (functionNameBytes >>> 0));
                    }
                }
                if (moduleNameBytes !== 0)
                {
                    /*fixed*/ 
                    {
                        /*void**/ let mn = $.$spc.System.String.GetPinnableReference.call(moduleName);
                        $.$spc.System.Runtime.CompilerServices.Unsafe.CopyBlock($.$cast(buffer, $.$typePointer($.$spc.System.Byte)).Add(moduleNameOffset), mn, (moduleNameBytes >>> 0));
                    }
                }
                return signature;
            }
            static /*void */ FreeMethodSignatureBuffer(/*JSFunctionBinding*/ signature)
            {
                $.$spc.System.Runtime.InteropServices.Marshal.FreeHGlobal($.$cast(signature.Header, $.$spc.System.IntPtr));
                signature.Header = null;
                signature.Sigs = null;
            }
            static /*void */ LoadLazyAssembly(/*byte[]*/ dllBytes, /*byte[]?*/ pdbBytes)
            {
                if (pdbBytes === null)
                {
                    $.$spc.System.Runtime.Loader.AssemblyLoadContext.Default.LoadFromStream(new $.$spc.System.IO.MemoryStream().$ctor$5(dllBytes));
                }
                else 
                {
                    $.$spc.System.Runtime.Loader.AssemblyLoadContext.Default.LoadFromStream$1(new $.$spc.System.IO.MemoryStream().$ctor$5(dllBytes), new $.$spc.System.IO.MemoryStream().$ctor$5(pdbBytes));
                }
            }
            static /*void */ LoadSatelliteAssembly(/*byte[]*/ dllBytes)
            {
                $.$spc.System.Runtime.Loader.AssemblyLoadContext.Default.LoadFromStream(new $.$spc.System.IO.MemoryStream().$ctor$5(dllBytes));
            }
            static /*Task<int>? */ CallEntrypoint(/*IntPtr*/ assemblyNamePtr, /*string?[]?*/ args, /*bool*/ waitForDebugger)
            {
                try
                {
                    /*void**/ let ptr;
                    $.$srij.Interop.Runtime.AssemblyGetEntryPoint(assemblyNamePtr, waitForDebugger ? 1 : 0, $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateObjectReferenceT($.$typePointer($.$spc.System.Void), () => ptr, ($v) => ptr = $v, null));
                    /*RuntimeMethodHandle*/ let methodHandle = $.$srij.System.Runtime.InteropServices.JavaScript.JSHostImplementation.GetMethodHandleFromIntPtr($.$spc.System.IntPtr.op_Explicit$2(ptr));
                    /*MethodInfo?*/ let method = $.$as($.$spc.System.Reflection.MethodBase.GetMethodFromHandle(methodHandle), $.$spc.System.Reflection.MethodInfo);
                    if ($.$spc.System.Reflection.MethodInfo.op_Equality$2(method, null))
                    {
                        throw new $.$spc.System.InvalidOperationException().$ctor$10($.$srij.System.SR.CannotResolveManagedEntrypointHandle);
                    }
                    /*object[]*/ let argsToPass = $.$spc.System.Array.Empty($.$spc.System.Object);
                    /*Task<int>?*/ let result = null;
                    /*var*/ let parameterInfos = method.GetParameters();
                    if (parameterInfos.length > 0 && $.$spc.System.Type.op_Equality$1($.$spc.System.Array.$ReadT1.call(parameterInfos, 0).ParameterType, $.$typeArray($.$spc.System.String).$type))
                    {
                        argsToPass = $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$spc.System.Object), [args ?? $.$spc.System.Array.Empty($.$spc.System.String)], [-1], null);
                    }
                    if ($.$spc.System.Type.op_Equality$1(method.ReturnType, $.$spc.System.Void.$type))
                    {
                        method.Invoke(null, argsToPass);
                    }
                    else if ($.$spc.System.Type.op_Equality$1(method.ReturnType, $.$spc.System.Int32.$type))
                    {
                        /*int*/ let intResult = $.$cast(method.Invoke(null, argsToPass), $.$spc.System.Int32);
                        result = $.$spc.System.Threading.Tasks.Task.FromResult($.$spc.System.Int32, intResult);
                    }
                    else if ($.$spc.System.Type.op_Equality$1(method.ReturnType, $.$spc.System.Threading.Tasks.Task.$type))
                    {
                        /*Task*/ let methodResult = $.$cast(method.Invoke(null, argsToPass), $.$spc.System.Threading.Tasks.Task);
                        /*TaskCompletionSource<int>*/ let tcs = new ($.$spc.System.Threading.Tasks.TaskCompletionSource$$($.$spc.System.Int32))().$ctor$1();
                        result = tcs.Task;
                        methodResult.ContinueWith$2(new ($.$spc.System.Action$$($.$spc.System.Threading.Tasks.Task))().$ctor(this,  (/*t*/ t) =>
                        {
                            if (t.IsFaulted)
                            {
                                tcs.SetException(t.Exception);
                            }
                            else 
                            {
                                tcs.SetResult(0);
                            }
                        }, {"r":65537,"p":[{"n":"t","p":133300225}],"n":"","d":847241,"h":0,"f":1048578}), $.$spc.System.Threading.Tasks.TaskScheduler.Default);
                    }
                    else if ($.$spc.System.Type.op_Equality$1(method.ReturnType, $.$spc.System.Threading.Tasks.Task$$($.$spc.System.Int32).$type))
                    {
                        result = $.$cast(method.Invoke(null, argsToPass), $.$spc.System.Threading.Tasks.Task$$($.$spc.System.Int32));
                    }
                    else 
                    {
                        throw new $.$spc.System.InvalidOperationException().$ctor$10($.$srij.System.SR.Format($.$srij.System.SR.ReturnTypeNotSupportedForMain, method.ReturnType.FullName));
                    }
                    return result;
                }
                catch(ex)
                {
                    let refEx;
                    if ($.$is(ex, $.$spc.System.Reflection.TargetInvocationException, { set $v(v){ refEx = v; } }) && refEx.InnerException !== null)
                    {
                        ex = refEx.InnerException;
                    }
                    return $.$spc.System.Threading.Tasks.Task.FromException$1($.$spc.System.Int32, ex);
                }
            }
            static /*Task */ BindAssemblyExports(/*string?*/ assemblyName)
            {
                $.$srij.Interop.Runtime.BindAssemblyExports($.$spc.System.Runtime.InteropServices.Marshal.StringToCoTaskMemUTF8(assemblyName));
                return $.$spc.System.Threading.Tasks.Task.CompletedTask;
            }
            static /*JSFunctionBinding */ BindManagedFunction(/*string*/ fullyQualifiedName, /*int*/ signatureHash, /*ReadOnlySpan<JSMarshalerType>*/ signatures)
            {
                /*var*/ let  [ assemblyName, nameSpace, shortClassName, methodName ] = $.$destructure($.$srij.System.Runtime.InteropServices.JavaScript.JSHostImplementation.ParseFQN(fullyQualifiedName));
                /*IntPtr*/ let monoMethod;
                $.$srij.Interop.Runtime.GetAssemblyExport($.$spc.System.Runtime.InteropServices.Marshal.StringToCoTaskMemUTF8(assemblyName), $.$spc.System.Runtime.InteropServices.Marshal.StringToCoTaskMemUTF8(nameSpace), $.$spc.System.Runtime.InteropServices.Marshal.StringToCoTaskMemUTF8(shortClassName), $.$spc.System.Runtime.InteropServices.Marshal.StringToCoTaskMemUTF8(methodName), signatureHash, $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateObjectReferenceT($.$spc.System.IntPtr, () => monoMethod, ($v) => monoMethod = $v, null));
                if (monoMethod === $.$spc.System.IntPtr.Zero)
                {
                    $.$spc.System.Environment.FailFast(`Can't find ${nameSpace}${shortClassName}${methodName} in ${assemblyName}.dll`);
                }
                /*var*/ let signature = $.$srij.System.Runtime.InteropServices.JavaScript.JSHostImplementation.GetMethodSignature(signatures, null, null);
                INTERNAL.mono_wasm_bind_cs_function(monoMethod, assemblyName, nameSpace, shortClassName, methodName, signatureHash, $.$cast(signature.Header, $.$spc.System.IntPtr));
                $.$srij.System.Runtime.InteropServices.JavaScript.JSHostImplementation.FreeMethodSignatureBuffer(signature);
                return signature;
            }
            static /*RuntimeMethodHandle */ GetMethodHandleFromIntPtr(/*IntPtr*/ ptr)
            {
                /*var*/ let temp = (() =>
                {
                    //new $.$srij.System.Runtime.InteropServices.JavaScript.JSHostImplementation.IntPtrAndHandle()
                    const $t1 = $.$srij.System.Runtime.InteropServices.JavaScript.JSHostImplementation.IntPtrAndHandle;
                    const $i1 = new $t1();
                    $i1.ptr = ptr;
                    return $i1;
                })();
                return temp.methodHandle;
            }
            static /*int */ SmallIndexOf(/*string*/ s, /*char*/ ch, /*int*/ direction)
            {
                if (s.length < 1)
                {
                    return -1;
                }
                /*int*/ let start_index = (direction > 0) ? 0 : ((s.length - 1) | 0), end_index = (direction > 0) ? ((s.length - 1) | 0) : 0;
                for(/*int*/ let i = start_index; i !== end_index; i += direction)
                {
                    if ($.$spc.System.String.get_Chars.call(s, i) === ch)
                    {
                        return i;
                    }
                }
                return -1;
            }
            static /*string */ SmallTrim(/*string*/ s)
            {
                if (s.length < 1)
                {
                    return s;
                }
                /*int*/ let head = 0, tail = ((s.length - 1) | 0);
                while(head < s.length)
                {
                    if ($.$spc.System.String.get_Chars.call(s, head) === /* */ 32)
                    {
                        head++;
                    }
                    else 
                    {
                        break;
                    }
                }
                while(tail >= 0)
                {
                    if ($.$spc.System.String.get_Chars.call(s, tail) === /* */ 32)
                    {
                        tail--;
                    }
                    else 
                    {
                        break;
                    }
                }
                if ((head > 0) || (tail < ((s.length - 1) | 0)))
                {
                    return $.$spc.System.String.Substring$1.call(s, head, ((((tail - head) | 0) + 1) | 0));
                }
                else 
                {
                    return s;
                }
            }
            static /*(string assemblyName, string nameSpace, string shortClassName, string methodName) */ ParseFQN(/*string*/ fqn)
            {
                /*var*/ let assembly = $.$spc.System.String.Substring$1.call(fqn, (($.$srij.System.Runtime.InteropServices.JavaScript.JSHostImplementation.SmallIndexOf(fqn, /*[*/ 91, 1) + 1) | 0), (($.$srij.System.Runtime.InteropServices.JavaScript.JSHostImplementation.SmallIndexOf(fqn, /*]*/ 93, 1) - 1) | 0));
                fqn = $.$srij.System.Runtime.InteropServices.JavaScript.JSHostImplementation.SmallTrim(fqn);
                fqn = $.$spc.System.String.Substring.call(fqn, (($.$srij.System.Runtime.InteropServices.JavaScript.JSHostImplementation.SmallIndexOf(fqn, /*]*/ 93, 1) + 1) | 0));
                fqn = $.$srij.System.Runtime.InteropServices.JavaScript.JSHostImplementation.SmallTrim(fqn);
                /*var*/ let methodName = $.$spc.System.String.Substring.call(fqn, (($.$srij.System.Runtime.InteropServices.JavaScript.JSHostImplementation.SmallIndexOf(fqn, /*:*/ 58, 1) + 1) | 0));
                /*var*/ let className = $.$spc.System.String.Substring$1.call(fqn, 0, $.$srij.System.Runtime.InteropServices.JavaScript.JSHostImplementation.SmallIndexOf(fqn, /*:*/ 58, 1));
                className = $.$srij.System.Runtime.InteropServices.JavaScript.JSHostImplementation.SmallTrim(className);
                /*var*/ let nameSpace = "";
                /*var*/ let shortClassName = className;
                /*var*/ let idx = $.$srij.System.Runtime.InteropServices.JavaScript.JSHostImplementation.SmallIndexOf(fqn, /*.*/ 46, -1);
                if (idx !== -1)
                {
                    nameSpace = $.$spc.System.String.Substring$1.call(fqn, 0, idx);
                    shortClassName = $.$spc.System.String.Substring.call(className, ((idx + 1) | 0));
                }
                if ($.$spc.System.String.IsNullOrEmpty(assembly))
                {
                    throw new $.$spc.System.InvalidOperationException().$ctor$10("No assembly name specified " + fqn);
                }
                if ($.$spc.System.String.IsNullOrEmpty(className))
                {
                    throw new $.$spc.System.InvalidOperationException().$ctor$10("No class name specified " + fqn);
                }
                if ($.$spc.System.String.IsNullOrEmpty(methodName))
                {
                    throw new $.$spc.System.InvalidOperationException().$ctor$10("No method name specified " + fqn);
                }
                return new ($.$spc.System.ValueTuple$$$$$($.$spc.System.String, $.$spc.System.String, $.$spc.System.String, $.$spc.System.String))().$ctor$2(assembly, nameSpace, shortClassName, methodName);
            }
            //Static Initializer
            static $sinit()
            {
                {
                    this.TaskGetResultName = "get_Result";
                }
            }
            static $h = 847241;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"m":[{"r":262145,"p":[{"n":"task","p":133300225},{"n":"value","p":131073,"f":2}],"n":"GetTaskResultDynamic","d":847241,"h":34360585609,"f":33},{"r":79626241,"p":[{"n":"taskType","p":142606337}],"n":"GetTaskResultMethodInfo","d":847241,"h":38655552905,"f":33},{"r":65537,"p":[{"n":"arg","p":1371529,"f":4}],"n":"ThrowException","d":847241,"h":42950520201,"f":33},{"r":$.$spc.System.Threading.Tasks.Task$$($.$srij.System.Runtime.InteropServices.JavaScript.JSObject).$h,"p":[{"n":"moduleName","p":1310721},{"n":"moduleUrl","p":1310721},{"n":"cancellationToken","p":125960193}],"n":"ImportAsync","d":847241,"h":47245487497,"f":4129},{"r":$.$spc.System.Threading.Tasks.Task$$($.$srij.System.Runtime.InteropServices.JavaScript.JSObject).$h,"p":[{"n":"jsTask","p":$.$spc.System.Threading.Tasks.Task$$($.$srij.System.Runtime.InteropServices.JavaScript.JSObject).$h},{"n":"cancellationToken","p":125960193}],"n":"CancellationHelper","d":847241,"h":51540454793,"f":4129},{"r":585097,"p":[{"n":"types","p":$.$spc.System.ReadOnlySpan$$($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType).$h},{"n":"functionName","p":1310721},{"n":"moduleName","p":1310721}],"n":"GetMethodSignature","d":847241,"h":55835422089,"f":33},{"r":65537,"p":[{"n":"signature","p":585097}],"n":"FreeMethodSignatureBuffer","d":847241,"h":60130389385,"f":33},{"r":65537,"p":[{"n":"dllBytes","p":0},{"n":"pdbBytes","p":0}],"n":"LoadLazyAssembly","d":847241,"h":64425356681,"f":33},{"r":65537,"p":[{"n":"dllBytes","p":0}],"n":"LoadSatelliteAssembly","d":847241,"h":68720323977,"f":33},{"r":$.$spc.System.Threading.Tasks.Task$$($.$spc.System.Int32).$h,"p":[{"n":"assemblyNamePtr","p":786433},{"n":"args","p":0},{"n":"waitForDebugger","p":262145}],"n":"CallEntrypoint","d":847241,"h":73015291273,"f":33},{"r":133300225,"p":[{"n":"assemblyName","p":1310721}],"n":"BindAssemblyExports","d":847241,"h":77310258569,"f":33},{"r":585097,"p":[{"n":"fullyQualifiedName","p":1310721},{"n":"signatureHash","p":655361},{"n":"signatures","p":$.$spc.System.ReadOnlySpan$$($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType).$h}],"n":"BindManagedFunction","d":847241,"h":81605225865,"f":33},{"r":115605505,"p":[{"n":"ptr","p":786433}],"n":"GetMethodHandleFromIntPtr","d":847241,"h":85900193161,"f":33},{"r":655361,"p":[{"n":"s","p":1310721},{"n":"ch","p":458753},{"n":"direction","p":655361,"f":65,"v":1}],"n":"SmallIndexOf","d":847241,"h":90195160457,"f":34},{"r":1310721,"p":[{"n":"s","p":1310721}],"n":"SmallTrim","d":847241,"h":94490127753,"f":34},{"r":$.$spc.System.ValueTuple$$$$$($.$spc.System.String, $.$spc.System.String, $.$spc.System.String, $.$spc.System.String).$h,"p":[{"n":"fqn","p":1310721}],"n":"ParseFQN","d":847241,"h":98785095049,"f":33}],"l":[{"t":1310721,"n":"TaskGetResultName","d":847241,"h":25770651017,"f":34},{"t":79626241,"n":"s_taskGetResultMethodInfo","d":847241,"h":30065618313,"f":34}],"j":[1174921,1043849,1109385,912777,978313],"h":847241}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.Runtime.InteropServices.JavaScript.JSHostImplementation`; }
        });
        
        $asm.$cls("$srij.System.Runtime.InteropServices.JavaScript.JSFunctionBinding", ($self) => class JSFunctionBinding extends $.$spc.System.Object
        {
            $ctor$1()
            {
                super.$ctor();
                {
                }
                return this;
            }
            /*JSBindingHeader**/ Header;
            /*JSBindingType**/ Sigs;
            /*uint*/ static nextImportHandle = 1;
            /*int*/ ImportHandle = 0;
            /*bool*/ IsAsync = false;
            /*bool*/ IsDiscardNoWait = false;
            /*string?*/ FunctionName = null;
            static $_JSBindingHeader;
            static get JSBindingHeader()
            {
                let $cls = $.$srij.System.Runtime.InteropServices.JavaScript.JSFunctionBinding;
                return $cls.$_JSBindingHeader ??= $asm.$nstr("$srij.System.Runtime.InteropServices.JavaScript.JSFunctionBinding.JSBindingHeader", ($self) => class JSBindingHeader extends $.$spc.System.ValueType
                {
                    /*int*/ static JSMarshalerSignatureHeaderSize = 32;
                    /*int*/  get Version() { return this.$getField(0, $.$spc.System.Int32); }
                    /*int*/  set Version(value) { this.$setField(0, $.$spc.System.Int32, value); }
                    /*int*/  get ArgumentCount() { return this.$getField(4, $.$spc.System.Int32); }
                    /*int*/  set ArgumentCount(value) { this.$setField(4, $.$spc.System.Int32, value); }
                    /*int*/  get ImportHandle() { return this.$getField(8, $.$spc.System.Int32); }
                    /*int*/  set ImportHandle(value) { this.$setField(8, $.$spc.System.Int32, value); }
                    /*int*/  get FunctionNameOffset() { return this.$getField(16, $.$spc.System.Int32); }
                    /*int*/  set FunctionNameOffset(value) { this.$setField(16, $.$spc.System.Int32, value); }
                    /*int*/  get FunctionNameLength() { return this.$getField(20, $.$spc.System.Int32); }
                    /*int*/  set FunctionNameLength(value) { this.$setField(20, $.$spc.System.Int32, value); }
                    /*int*/  get ModuleNameOffset() { return this.$getField(24, $.$spc.System.Int32); }
                    /*int*/  set ModuleNameOffset(value) { this.$setField(24, $.$spc.System.Int32, value); }
                    /*int*/  get ModuleNameLength() { return this.$getField(28, $.$spc.System.Int32); }
                    /*int*/  set ModuleNameLength(value) { this.$setField(28, $.$spc.System.Int32, value); }
                    /*JSBindingType*/  get Exception() { return this.$getField(32, $.$srij.System.Runtime.InteropServices.JavaScript.JSFunctionBinding.JSBindingType); }
                    /*JSBindingType*/  set Exception(value) { this.$setField(32, $.$srij.System.Runtime.InteropServices.JavaScript.JSFunctionBinding.JSBindingType, value); }
                    /*JSBindingType*/  get Result() { return this.$getField(64, $.$srij.System.Runtime.InteropServices.JavaScript.JSFunctionBinding.JSBindingType); }
                    /*JSBindingType*/  set Result(value) { this.$setField(64, $.$srij.System.Runtime.InteropServices.JavaScript.JSFunctionBinding.JSBindingType, value); }
                    //default value type constructor
                    $ctor$2()
                    {
                        return this;
                    }
                    Clone($copy)
                    {
                        let copy = $copy ?? new this.constructor();
                        copy.Version = this.Version;
                        copy.ArgumentCount = this.ArgumentCount;
                        copy.ImportHandle = this.ImportHandle;
                        copy.FunctionNameOffset = this.FunctionNameOffset;
                        copy.FunctionNameLength = this.FunctionNameLength;
                        copy.ModuleNameOffset = this.ModuleNameOffset;
                        copy.ModuleNameLength = this.ModuleNameLength;
                        copy.Exception = this.Exception.Clone();
                        copy.Result = this.Result.Clone();
                        return copy;
                    }
                    //default member initializer
                    constructor()
                    {
                        super();
                        this.Version = 0;
                        this.ArgumentCount = 0;
                        this.ImportHandle = 0;
                        this.FunctionNameOffset = 0;
                        this.FunctionNameLength = 0;
                        this.ModuleNameOffset = 0;
                        this.ModuleNameLength = 0;
                        this.Exception = $.$default($.$srij.System.Runtime.InteropServices.JavaScript.JSFunctionBinding.JSBindingType);
                        this.Result = $.$default($.$srij.System.Runtime.InteropServices.JavaScript.JSFunctionBinding.JSBindingType);
                    }
                    //Static Initializer
                    static $sinit()
                    {
                        {
                            this.JSMarshalerSignatureHeaderSize = 32;
                        }
                    }
                    static $h = 650633;
                    static $z = 96;
                    static $f = 0b10100010000001010000000;
                    static $k = 2;
                    static $$md;
                    static get $md() { return this.$$md ??= {"b":196609,"l":[{"t":655361,"n":"JSMarshalerSignatureHeaderSize","d":650633,"h":4295617929,"f":40},{"t":655361,"n":"Version","d":650633,"h":8590585225,"f":1,"a":[{"t":104071169,"c":4399038465,"a":[{"v":0,"t":655361}]}]},{"t":655361,"n":"ArgumentCount","d":650633,"h":12885552521,"f":1,"a":[{"t":104071169,"c":4399038465,"a":[{"v":4,"t":655361}]}]},{"t":655361,"n":"ImportHandle","d":650633,"h":17180519817,"f":1,"a":[{"t":104071169,"c":4399038465,"a":[{"v":8,"t":655361}]}]},{"t":655361,"n":"FunctionNameOffset","d":650633,"h":21475487113,"f":1,"a":[{"t":104071169,"c":4399038465,"a":[{"v":16,"t":655361}]}]},{"t":655361,"n":"FunctionNameLength","d":650633,"h":25770454409,"f":1,"a":[{"t":104071169,"c":4399038465,"a":[{"v":20,"t":655361}]}]},{"t":655361,"n":"ModuleNameOffset","d":650633,"h":30065421705,"f":1,"a":[{"t":104071169,"c":4399038465,"a":[{"v":24,"t":655361}]}]},{"t":655361,"n":"ModuleNameLength","d":650633,"h":34360389001,"f":1,"a":[{"t":104071169,"c":4399038465,"a":[{"v":28,"t":655361}]}]},{"t":716169,"n":"Result","d":650633,"h":42950323593,"f":1,"a":[{"t":104071169,"c":4399038465,"a":[{"v":64,"t":655361}]}]}],"c":[{"n":".ctor","o":"$ctor$2","d":650633,"h":47245290889,"f":1}],"d":585097,"h":650633,"a":[{"t":109903873,"c":4404871169,"a":[{"v":2,"t":105381889}],"n":[{"n":"Pack","v":4,"t":655361}]}]}; }
                    static get $b() { return $.$spc.System.ValueType; }
                    static get $fullName() { return `System.Runtime.InteropServices.JavaScript.JSFunctionBinding.JSBindingHeader`; }
                }, $cls, ($v) => $cls.$_JSBindingHeader = $v);
            }
            static $_JSBindingType;
            static get JSBindingType()
            {
                let $cls = $.$srij.System.Runtime.InteropServices.JavaScript.JSFunctionBinding;
                return $cls.$_JSBindingType ??= $asm.$nstr("$srij.System.Runtime.InteropServices.JavaScript.JSFunctionBinding.JSBindingType", ($self) => class JSBindingType extends $.$spc.System.ValueType
                {
                    /*MarshalerType*/  get Type() { return this.$getField(0, $.$srij.System.Runtime.InteropServices.JavaScript.MarshalerType); }
                    /*MarshalerType*/  set Type(value) { this.$setField(0, $.$srij.System.Runtime.InteropServices.JavaScript.MarshalerType, value); }
                    /*MarshalerType*/  get ResultMarshalerType() { return this.$getField(16, $.$srij.System.Runtime.InteropServices.JavaScript.MarshalerType); }
                    /*MarshalerType*/  set ResultMarshalerType(value) { this.$setField(16, $.$srij.System.Runtime.InteropServices.JavaScript.MarshalerType, value); }
                    /*MarshalerType*/  get Arg1MarshalerType() { return this.$getField(20, $.$srij.System.Runtime.InteropServices.JavaScript.MarshalerType); }
                    /*MarshalerType*/  set Arg1MarshalerType(value) { this.$setField(20, $.$srij.System.Runtime.InteropServices.JavaScript.MarshalerType, value); }
                    /*MarshalerType*/  get Arg2MarshalerType() { return this.$getField(24, $.$srij.System.Runtime.InteropServices.JavaScript.MarshalerType); }
                    /*MarshalerType*/  set Arg2MarshalerType(value) { this.$setField(24, $.$srij.System.Runtime.InteropServices.JavaScript.MarshalerType, value); }
                    /*MarshalerType*/  get Arg3MarshalerType() { return this.$getField(28, $.$srij.System.Runtime.InteropServices.JavaScript.MarshalerType); }
                    /*MarshalerType*/  set Arg3MarshalerType(value) { this.$setField(28, $.$srij.System.Runtime.InteropServices.JavaScript.MarshalerType, value); }
                    //default value type constructor
                    $ctor$2()
                    {
                        return this;
                    }
                    Clone($copy)
                    {
                        let copy = $copy ?? new this.constructor();
                        copy.Type = this.Type;
                        copy.ResultMarshalerType = this.ResultMarshalerType;
                        copy.Arg1MarshalerType = this.Arg1MarshalerType;
                        copy.Arg2MarshalerType = this.Arg2MarshalerType;
                        copy.Arg3MarshalerType = this.Arg3MarshalerType;
                        return copy;
                    }
                    //default member initializer
                    constructor()
                    {
                        super();
                        this.Type = 0;
                        this.ResultMarshalerType = 0;
                        this.Arg1MarshalerType = 0;
                        this.Arg2MarshalerType = 0;
                        this.Arg3MarshalerType = 0;
                    }
                    static $h = 716169;
                    static $z = 32;
                    static $f = 0b10100010000001010000000;
                    static $k = 2;
                    static $$md;
                    static get $md() { return this.$$md ??= {"b":196609,"l":[{"t":3730825,"n":"Type","d":716169,"h":4295683465,"f":8,"a":[{"t":104071169,"c":4399038465,"a":[{"v":0,"t":655361}]}]},{"t":3730825,"n":"ResultMarshalerType","d":716169,"h":8590650761,"f":8,"a":[{"t":104071169,"c":4399038465,"a":[{"v":16,"t":655361}]}]},{"t":3730825,"n":"Arg1MarshalerType","d":716169,"h":12885618057,"f":8,"a":[{"t":104071169,"c":4399038465,"a":[{"v":20,"t":655361}]}]},{"t":3730825,"n":"Arg2MarshalerType","d":716169,"h":17180585353,"f":8,"a":[{"t":104071169,"c":4399038465,"a":[{"v":24,"t":655361}]}]},{"t":3730825,"n":"Arg3MarshalerType","d":716169,"h":21475552649,"f":8,"a":[{"t":104071169,"c":4399038465,"a":[{"v":28,"t":655361}]}]}],"c":[{"n":".ctor","o":"$ctor$2","d":716169,"h":25770519945,"f":1}],"d":585097,"h":716169,"a":[{"t":109903873,"c":4404871169,"a":[{"v":2,"t":105381889}],"n":[{"n":"Pack","v":4,"t":655361},{"n":"Size","v":32,"t":655361}]}]}; }
                    static get $b() { return $.$spc.System.ValueType; }
                    static get $fullName() { return `System.Runtime.InteropServices.JavaScript.JSFunctionBinding.JSBindingType`; }
                }, $cls, ($v) => $cls.$_JSBindingType = $v);
            }
            /*int */ get ArgumentCount()
            {
                return this.Header.GetAt(0).ArgumentCount;
            }
            /*int */ set ArgumentCount(value)
            {
                this.Header.GetAt(0).ArgumentCount = value;
            }
            /*int */ get Version()
            {
                return this.Header.GetAt(0).Version;
            }
            /*int */ set Version(value)
            {
                this.Header.GetAt(0).Version = value;
            }
            /*JSBindingType */ get Result()
            {
                return this.Header.GetAt(0).Result;
            }
            /*JSBindingType */ set Result(value)
            {
                this.Header.GetAt(0).Result = value.Clone();
            }
            /*JSBindingType */ get Exception()
            {
                return this.Header.GetAt(0).Exception;
            }
            /*JSBindingType */ set Exception(value)
            {
                this.Header.GetAt(0).Exception = value.Clone();
            }
            /*JSBindingType*/ get_Item(/*int*/ position)
            {
                return this.Sigs.GetAt(((position - 1) | 0));
            }
            static /*void */ InvokeJS(/*JSFunctionBinding*/ signature, /*Span<JSMarshalerArgument>*/ $arguments)
            {
                $.$srij.System.Runtime.InteropServices.JavaScript.JSFunctionBinding.InvokeJSImportImpl(signature, $arguments);
            }
            static /*JSFunctionBinding */ BindJSFunction(/*string*/ functionName, /*string*/ moduleName, /*ReadOnlySpan<JSMarshalerType>*/ signatures)
            {
                if ($.$spc.System.Runtime.InteropServices.RuntimeInformation.OSArchitecture !== 4/*Architecture.Wasm*/)
                {
                    throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
                }
                return $.$srij.System.Runtime.InteropServices.JavaScript.JSFunctionBinding.BindJSImportImpl(functionName, moduleName, signatures);
            }
            static /*JSFunctionBinding */ BindManagedFunction(/*string*/ fullyQualifiedName, /*int*/ signatureHash, /*ReadOnlySpan<JSMarshalerType>*/ signatures)
            {
                if ($.$spc.System.Runtime.InteropServices.RuntimeInformation.OSArchitecture !== 4/*Architecture.Wasm*/)
                {
                    throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
                }
                return $.$srij.System.Runtime.InteropServices.JavaScript.JSHostImplementation.BindManagedFunction(fullyQualifiedName, signatureHash, signatures);
            }
            static /*void */ InvokeJSFunction(/*JSObject*/ jsFunction, /*Span<JSMarshalerArgument>*/ $arguments)
            {
                jsFunction.AssertNotDisposed();
                $.$srij.System.Runtime.InteropServices.JavaScript.JSFunctionBinding.InvokeJSFunctionCurrent(jsFunction, $arguments);
            }
            static /*void */ InvokeJSFunctionCurrent(/*JSObject*/ jsFunction, /*Span<JSMarshalerArgument>*/ $arguments)
            {
                /*var*/ let functionHandle = jsFunction.JSHandle;
                /*fixed*/ 
                {
                    /*JSMarshalerArgument**/ let ptr = $arguments.GetPinnableReference();
                    $.$srij.Interop.Runtime.InvokeJSFunction(functionHandle, $.$cast(ptr, $.$spc.System.IntPtr));
                    /*ref JSMarshalerArgument*/ let exceptionArg = $arguments.get_Item(0);
                    if (exceptionArg.$v.slot.Type !== 0/*MarshalerType.None*/)
                    {
                        $.$srij.System.Runtime.InteropServices.JavaScript.JSHostImplementation.ThrowException(exceptionArg);
                    }
                }
            }
            static /*void */ InvokeJSImportImpl(/*JSFunctionBinding*/ signature, /*Span<JSMarshalerArgument>*/ $arguments)
            {
                /*ref JSMarshalerArgument*/ let exc = $arguments.get_Item(0);
                /*ref JSMarshalerArgument*/ let res = $arguments.get_Item(1);
                /*var*/ let targetContext = $.$srij.System.Runtime.InteropServices.JavaScript.JSProxyContext.MainThreadContext;
                if (signature.IsAsync)
                {
                    /*var*/ let holder = targetContext.CreatePromiseHolder();
                    res.$v.slot.Type = 30/*MarshalerType.TaskPreCreated*/;
                    res.$v.slot.GCHandle = holder.GCHandle;
                }
                if (signature.IsDiscardNoWait)
                {
                    $arguments.get_Item(1).$v.slot.Type = 26/*MarshalerType.DiscardNoWait*/;
                }
                $.$srij.System.Runtime.InteropServices.JavaScript.JSFunctionBinding.InvokeJSImportCurrent(signature, $arguments);
                if (signature.IsAsync)
                {
                    if ($arguments.get_Item(1).$v.slot.Type === 0/*MarshalerType.None*/)
                    {
                        /*var*/ let holderHandle = $.$spc.System.Runtime.InteropServices.GCHandle.op_Explicit($arguments.get_Item(1).$v.slot.GCHandle);
                        holderHandle.Free();
                    }
                }
            }
            static /*void */ InvokeJSImportCurrent(/*JSFunctionBinding*/ signature, /*Span<JSMarshalerArgument>*/ $arguments)
            {
                /*fixed*/ 
                {
                    /*JSMarshalerArgument**/ let args = $arguments.GetPinnableReference();
                    $.$srij.Interop.Runtime.InvokeJSImportST(signature.ImportHandle, $.$cast(args, $.$spc.System.IntPtr));
                }
                /*ref JSMarshalerArgument*/ let exceptionArg = $arguments.get_Item(0);
                if (exceptionArg.$v.slot.Type !== 0/*MarshalerType.None*/)
                {
                    $.$srij.System.Runtime.InteropServices.JavaScript.JSHostImplementation.ThrowException(exceptionArg);
                }
            }
            static /*JSFunctionBinding */ BindJSImportImpl(/*string*/ functionName, /*string*/ moduleName, /*ReadOnlySpan<JSMarshalerType>*/ signatures)
            {
                /*var*/ let signature = $.$srij.System.Runtime.InteropServices.JavaScript.JSHostImplementation.GetMethodSignature(signatures, functionName, moduleName);
                /*nint*/ let exceptionPtr = $.$srij.Interop.Runtime.BindJSImportST(signature.Header);
                if (exceptionPtr !== $.$spc.System.IntPtr.Zero)
                {
                    /*var*/ let message = $.$spc.System.Runtime.InteropServices.Marshal.PtrToStringUni(exceptionPtr);
                    $.$spc.System.Runtime.InteropServices.Marshal.FreeHGlobal(exceptionPtr);
                    throw new $.$srij.System.Runtime.InteropServices.JavaScript.JSException().$ctor$5(message);
                }
                $.$srij.System.Runtime.InteropServices.JavaScript.JSHostImplementation.FreeMethodSignatureBuffer(signature);
                return signature;
            }
            static /*void */ ResolveOrRejectPromise(/*JSProxyContext*/ targetContext, /*Span<JSMarshalerArgument>*/ $arguments)
            {
                /*ref JSMarshalerArgument*/ let exc = $arguments.get_Item(0);
                {
                    /*fixed*/ 
                    {
                        /*JSMarshalerArgument**/ let ptr = $arguments.GetPinnableReference();
                        $.$srij.Interop.Runtime.ResolveOrRejectPromise($.$cast(ptr, $.$spc.System.IntPtr));
                        if (exc.$v.slot.Type !== 0/*MarshalerType.None*/)
                        {
                            $.$srij.System.Runtime.InteropServices.JavaScript.JSHostImplementation.ThrowException(exc);
                        }
                    }
                }
            }
            //default member initializer
            constructor()
            {
                super();
                this.Header = $.$default($.$typePointer($.$srij.System.Runtime.InteropServices.JavaScript.JSFunctionBinding.JSBindingHeader));
                this.Sigs = $.$default($.$typePointer($.$srij.System.Runtime.InteropServices.JavaScript.JSFunctionBinding.JSBindingType));
            }
            static $h = 585097;
            static $f = 0b10010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":655361,"g":{"r":0,"d":0,"h":51540192649,"f":8},"s":{"r":0,"d":0,"h":55835159945,"f":8},"n":"ArgumentCount","d":585097,"h":47245225353,"f":8},{"p":655361,"g":{"r":0,"d":0,"h":64425094537,"f":8},"s":{"r":0,"d":0,"h":68720061833,"f":8},"n":"Version","d":585097,"h":60130127241,"f":8},{"p":716169,"g":{"r":0,"d":0,"h":77309996425,"f":8},"s":{"r":0,"d":0,"h":81604963721,"f":8},"n":"Result","d":585097,"h":73015029129,"f":8},{"p":716169,"i":[{"n":"position","p":655361}],"g":{"r":0,"d":0,"h":103079800201,"f":8},"n":"Item","o":"@$2","d":585097,"h":98784832905,"f":8}],"m":[{"r":65537,"p":[{"n":"signature","p":585097},{"n":"arguments","p":$.$spc.System.Span$$($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument).$h}],"n":"InvokeJS","d":585097,"h":107374767497,"f":33},{"r":585097,"p":[{"n":"functionName","p":1310721},{"n":"moduleName","p":1310721},{"n":"signatures","p":$.$spc.System.ReadOnlySpan$$($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType).$h}],"n":"BindJSFunction","d":585097,"h":111669734793,"f":33},{"r":585097,"p":[{"n":"fullyQualifiedName","p":1310721},{"n":"signatureHash","p":655361},{"n":"signatures","p":$.$spc.System.ReadOnlySpan$$($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType).$h}],"n":"BindManagedFunction","d":585097,"h":115964702089,"f":33},{"r":65537,"p":[{"n":"jsFunction","p":2289033},{"n":"arguments","p":$.$spc.System.Span$$($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument).$h}],"n":"InvokeJSFunction","d":585097,"h":120259669385,"f":40},{"r":65537,"p":[{"n":"jsFunction","p":2289033},{"n":"arguments","p":$.$spc.System.Span$$($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument).$h}],"n":"InvokeJSFunctionCurrent","d":585097,"h":124554636681,"f":40},{"r":65537,"p":[{"n":"signature","p":585097},{"n":"arguments","p":$.$spc.System.Span$$($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument).$h}],"n":"InvokeJSImportImpl","d":585097,"h":128849603977,"f":40},{"r":65537,"p":[{"n":"signature","p":585097},{"n":"arguments","p":$.$spc.System.Span$$($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument).$h}],"n":"InvokeJSImportCurrent","d":585097,"h":133144571273,"f":40},{"r":585097,"p":[{"n":"functionName","p":1310721},{"n":"moduleName","p":1310721},{"n":"signatures","p":$.$spc.System.ReadOnlySpan$$($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType).$h}],"n":"BindJSImportImpl","d":585097,"h":137439538569,"f":40},{"r":65537,"p":[{"n":"targetContext","p":2354569},{"n":"arguments","p":$.$spc.System.Span$$($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument).$h}],"n":"ResolveOrRejectPromise","d":585097,"h":141734505865,"f":40}],"l":[{"t":0,"n":"Header","d":585097,"h":8590519689,"f":8},{"t":0,"n":"Sigs","d":585097,"h":12885486985,"f":8},{"t":720897,"n":"nextImportHandle","d":585097,"h":17180454281,"f":40},{"t":655361,"n":"ImportHandle","d":585097,"h":21475421577,"f":8},{"t":262145,"n":"IsAsync","d":585097,"h":25770388873,"f":8},{"t":262145,"n":"IsDiscardNoWait","d":585097,"h":30065356169,"f":8},{"t":1310721,"n":"FunctionName","d":585097,"h":34360323465,"f":8}],"c":[{"n":".ctor","o":"$ctor$1","d":585097,"h":4295552393,"f":8}],"j":[650633,716169],"h":585097,"a":[{"t":23461889,"c":8613396481,"a":[{"v":false,"t":262145}]},{"t":114950145,"c":4409917441,"a":[{"v":"browser","t":1310721}]},{"t":33226753,"c":4328194049,"a":[{"v":1,"t":33292289}]}]}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.Runtime.InteropServices.JavaScript.JSFunctionBinding`; }
        });
        
        $asm.$cls("$srij.System.Runtime.InteropServices.JavaScript.JavaScriptExports", ($self) => class JavaScriptExports
        {
            static /*void */ CallEntrypoint(/*JSMarshalerArgument**/ arguments_buffer)
            {
                /*ref JSMarshalerArgument*/ let arg_exc = arguments_buffer.Add(0);
                /*ref JSMarshalerArgument*/ let arg_res = arguments_buffer.Add(1);
                /*ref JSMarshalerArgument*/ let arg_1 = arguments_buffer.Add(2);
                /*ref JSMarshalerArgument*/ let arg_2 = arguments_buffer.Add(3);
                /*ref JSMarshalerArgument*/ let arg_3 = arguments_buffer.Add(4);
                try
                {
                    /*IntPtr*/ let assemblyNamePtr;
                    arg_1.$v.ToManaged$27($.$ref(() => assemblyNamePtr, ($v) => assemblyNamePtr = $v, $.$spc.System.IntPtr));
                    /*string?[]?*/ let args;
                    arg_2.$v.ToManaged$26($.$ref(() => args, ($v) => args = $v, $.$typeArray($.$spc.System.String)));
                    /*bool*/ let waitForDebugger;
                    arg_3.$v.ToManaged$16($.$ref(() => waitForDebugger, ($v) => waitForDebugger = $v, $.$spc.System.Boolean));
                    /*Task<int>?*/ let result = $.$srij.System.Runtime.InteropServices.JavaScript.JSHostImplementation.CallEntrypoint(assemblyNamePtr, args, waitForDebugger);
                    arg_res.$v.ToJS$38($.$spc.System.Int32, result, new ($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument.ArgumentToJSCallback$$($.$spc.System.Int32))().$ctor(this,  (/*JSMarshalerArgument*/ arg, /*int*/ value) =>
                    {
                        arg.$v.ToJS$30(value);
                    }, {"r":65537,"p":[{"n":"arg","p":1371529,"f":4},{"n":"value","p":655361}],"n":"","d":322953,"h":0,"f":1048578}));
                }
                catch(ex)
                {
                    $.$spc.System.Environment.FailFast(`CallEntrypoint: Unexpected synchronous failure (ManagedThreadId ${$.$spc.System.Environment.CurrentManagedThreadId}): ` + $.$spc.System.Exception.ToString.call(ex));
                }
            }
            static /*void */ LoadLazyAssembly(/*JSMarshalerArgument**/ arguments_buffer)
            {
                /*ref JSMarshalerArgument*/ let arg_exc = arguments_buffer.Add(0);
                /*ref JSMarshalerArgument*/ let arg_1 = arguments_buffer.Add(2);
                /*ref JSMarshalerArgument*/ let arg_2 = arguments_buffer.Add(3);
                try
                {
                    /*byte[]?*/ let dllBytes;
                    arg_1.$v.ToManaged$13($.$ref(() => dllBytes, ($v) => dllBytes = $v, $.$typeArray($.$spc.System.Byte)));
                    /*byte[]?*/ let pdbBytes;
                    arg_2.$v.ToManaged$13($.$ref(() => pdbBytes, ($v) => pdbBytes = $v, $.$typeArray($.$spc.System.Byte)));
                    if (dllBytes !== null)
                    {
                        $.$srij.System.Runtime.InteropServices.JavaScript.JSHostImplementation.LoadLazyAssembly(dllBytes, pdbBytes);
                    }
                }
                catch(ex)
                {
                    arg_exc.$v.ToJS$24(ex);
                }
            }
            static /*void */ LoadSatelliteAssembly(/*JSMarshalerArgument**/ arguments_buffer)
            {
                /*ref JSMarshalerArgument*/ let arg_exc = arguments_buffer.Add(0);
                /*ref JSMarshalerArgument*/ let arg_1 = arguments_buffer.Add(2);
                try
                {
                    /*byte[]?*/ let dllBytes;
                    arg_1.$v.ToManaged$13($.$ref(() => dllBytes, ($v) => dllBytes = $v, $.$typeArray($.$spc.System.Byte)));
                    if (dllBytes !== null)
                    {
                        $.$srij.System.Runtime.InteropServices.JavaScript.JSHostImplementation.LoadSatelliteAssembly(dllBytes);
                    }
                }
                catch(ex)
                {
                    arg_exc.$v.ToJS$24(ex);
                }
            }
            static /*void */ ReleaseJSOwnedObjectByGCHandle(/*JSMarshalerArgument**/ arguments_buffer)
            {
                /*ref JSMarshalerArgument*/ let arg_exc = arguments_buffer.Add(0);
                /*ref JSMarshalerArgument*/ let arg_1 = arguments_buffer.Add(2);
                try
                {
                    /*var*/ let ctx = arg_exc.$v.ToManagedContext;
                    ctx.ReleaseJSOwnedObjectByGCHandle(arg_1.$v.slot.GCHandle);
                }
                catch(ex)
                {
                    $.$spc.System.Environment.FailFast(`ReleaseJSOwnedObjectByGCHandle: Unexpected synchronous failure (ManagedThreadId ${$.$spc.System.Environment.CurrentManagedThreadId}): ` + $.$spc.System.Exception.ToString.call(ex));
                }
            }
            static /*void */ CallDelegate(/*JSMarshalerArgument**/ arguments_buffer)
            {
                /*ref JSMarshalerArgument*/ let arg_exc = arguments_buffer.Add(0);
                /*ref JSMarshalerArgument*/ let arg_1 = arguments_buffer.Add(2);
                try
                {
                    /*GCHandle*/ let callback_gc_handle = $.$spc.System.Runtime.InteropServices.GCHandle.op_Explicit(arg_1.$v.slot.GCHandle);
                    let callback;
                    if ($.$is(callback_gc_handle.Target, $.$srij.System.Runtime.InteropServices.JavaScript.JSHostImplementation.ToManagedCallback, { set $v(v){ callback = v; } }))
                    {
                        callback.Invoke(arguments_buffer);
                    }
                    else 
                    {
                        throw new $.$spc.System.InvalidOperationException().$ctor$10($.$srij.System.SR.NullToManagedCallback);
                    }
                }
                catch(ex)
                {
                    arg_exc.$v.ToJS$24(ex);
                }
            }
            static /*void */ CompleteTask(/*JSMarshalerArgument**/ arguments_buffer)
            {
                /*ref JSMarshalerArgument*/ let arg_exc = arguments_buffer.Add(0);
                /*ref JSMarshalerArgument*/ let arg_res = arguments_buffer.Add(1);
                /*ref JSMarshalerArgument*/ let arg_1 = arguments_buffer.Add(2);
                try
                {
                    /*var*/ let ctx = arg_exc.$v.ToManagedContext;
                    /*var*/ let holder = ctx.GetPromiseHolder(arg_1.$v.slot.GCHandle);
                    /*JSHostImplementation.ToManagedCallback*/ let callback;
                    callback = holder.Callback;
                    ctx.ReleasePromiseHolder(arg_1.$v.slot.GCHandle);
                    callback.Invoke(arguments_buffer);
                }
                catch(ex)
                {
                    $.$spc.System.Environment.FailFast(`CompleteTask: Unexpected synchronous failure (ManagedThreadId ${$.$spc.System.Environment.CurrentManagedThreadId}): ` + $.$spc.System.Exception.ToString.call(ex));
                }
            }
            static /*void */ GetManagedStackTrace(/*JSMarshalerArgument**/ arguments_buffer)
            {
                /*ref JSMarshalerArgument*/ let arg_exc = arguments_buffer.Add(0);
                /*ref JSMarshalerArgument*/ let arg_res = arguments_buffer.Add(1);
                /*ref JSMarshalerArgument*/ let arg_1 = arguments_buffer.Add(2);
                try
                {
                    arg_exc.$v.AssertCurrentThreadContext();
                    /*GCHandle*/ let exception_gc_handle = $.$spc.System.Runtime.InteropServices.GCHandle.op_Explicit(arg_1.$v.slot.GCHandle);
                    let exception;
                    if ($.$is(exception_gc_handle.Target, $.$spc.System.Exception, { set $v(v){ exception = v; } }))
                    {
                        arg_res.$v.ToJS$25(exception.StackTrace);
                    }
                    else 
                    {
                        throw new $.$spc.System.InvalidOperationException().$ctor$10($.$srij.System.SR.UnableToResolveHandleAsException);
                    }
                }
                catch(ex)
                {
                    arg_exc.$v.ToJS$24(ex);
                }
            }
            static /*void */ BindAssemblyExports(/*JSMarshalerArgument**/ arguments_buffer)
            {
                /*ref JSMarshalerArgument*/ let arg_exc = arguments_buffer.Add(0);
                /*ref JSMarshalerArgument*/ let arg_res = arguments_buffer.Add(1);
                /*ref JSMarshalerArgument*/ let arg_1 = arguments_buffer.Add(2);
                try
                {
                    /*string?*/ let assemblyName;
                    arg_exc.$v.AssertCurrentThreadContext();
                    arg_1.$v.ToManaged$25($.$ref(() => assemblyName, ($v) => assemblyName = $v, $.$spc.System.String));
                    /*var*/ let result = $.$srij.System.Runtime.InteropServices.JavaScript.JSHostImplementation.BindAssemblyExports(assemblyName);
                    arg_res.$v.ToJS$37(result);
                }
                catch(ex)
                {
                    $.$spc.System.Environment.FailFast(`BindAssemblyExports: Unexpected synchronous failure (ManagedThreadId ${$.$spc.System.Environment.CurrentManagedThreadId}): ` + $.$spc.System.Exception.ToString.call(ex));
                }
            }
            static /*void */ StopProfile()
            {
            }
            static /*void */ DumpAotProfileData(/*ref byte*/ buf, /*int*/ len, /*string*/ extraArg)
            {
                if (len === 0)
                {
                    throw new $.$spc.System.InvalidOperationException().$ctor$10($.$srij.System.SR.EmptyProfileData);
                }
                /*fixed*/ 
                {
                    /*void**/ let p = buf;
                    /*var*/ let span = new ($.$spc.System.ReadOnlySpan$$($.$spc.System.Byte))().$ctor$4(p, len);
                    /*var*/ let module = $.$srij.System.Runtime.InteropServices.JavaScript.JSHost.DotnetInstance.GetPropertyAsJSObject("INTERNAL");
                    if (module === null)
                    {
                        throw new $.$spc.System.InvalidOperationException().$ctor$9();
                    }
                    module.SetProperty$5("aotProfileData", span.ToArray());
                }
            }
            static $h = 322953;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"m":[{"r":65537,"p":[{"n":"arguments_buffer","p":0}],"n":"CallEntrypoint","d":322953,"h":4295290249,"f":33},{"r":65537,"p":[{"n":"arguments_buffer","p":0}],"n":"LoadLazyAssembly","d":322953,"h":8590257545,"f":33},{"r":65537,"p":[{"n":"arguments_buffer","p":0}],"n":"LoadSatelliteAssembly","d":322953,"h":12885224841,"f":33},{"r":65537,"p":[{"n":"arguments_buffer","p":0}],"n":"ReleaseJSOwnedObjectByGCHandle","d":322953,"h":17180192137,"f":33},{"r":65537,"p":[{"n":"arguments_buffer","p":0}],"n":"CallDelegate","d":322953,"h":21475159433,"f":33},{"r":65537,"p":[{"n":"arguments_buffer","p":0}],"n":"CompleteTask","d":322953,"h":25770126729,"f":33},{"r":65537,"p":[{"n":"arguments_buffer","p":0}],"n":"GetManagedStackTrace","d":322953,"h":30065094025,"f":33},{"r":65537,"p":[{"n":"arguments_buffer","p":0}],"n":"BindAssemblyExports","d":322953,"h":34360061321,"f":33},{"r":65537,"n":"StopProfile","d":322953,"h":38655028617,"f":33},{"r":65537,"p":[{"n":"buf","p":393217,"f":4},{"n":"len","p":655361},{"n":"extraArg","p":1310721}],"n":"DumpAotProfileData","d":322953,"h":42949995913,"f":33}],"h":322953}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.Runtime.InteropServices.JavaScript.JavaScriptExports`; }
        });
        
        $asm.$cls("$srij.System.Runtime.InteropServices.JavaScript.JSObject", ($self) => class JSObject extends $.$spc.System.Object
        {
            /*nint*/ JSHandle = 0;
            /*JSProxyContext*/ ProxyContext = null;
            /*SynchronizationContext */ get SynchronizationContext()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool*/ _isDisposed = false;
            $ctor$1(/*IntPtr*/ jsHandle, /*JSProxyContext*/ ctx)
            {
                super.$ctor();
                {
                    this.ProxyContext = ctx;
                    this.JSHandle = jsHandle;
                }
                return this;
            }
            static/*conventional*/ /*bool */ Equals(/*object?*/ obj)
            {
                let other;
                return $.$is(obj, $.$srij.System.Runtime.InteropServices.JavaScript.JSObject, { set $v(v){ other = v; } }) && this.JSHandle === other.JSHandle;
            }
            //Static convention instance redirect
            /*bool */ Equals() { return $.$srij.System.Runtime.InteropServices.JavaScript.JSObject.Equals.apply(this, arguments); }
            static/*conventional*/ /*int */ GetHashCode()
            {
                return this.JSHandle;
            }
            //Static convention instance redirect
            /*int */ GetHashCode() { return $.$srij.System.Runtime.InteropServices.JavaScript.JSObject.GetHashCode.apply(this, arguments); }
            static/*conventional*/ /*string */ ToString()
            {
                return `(js-obj js '${this.JSHandle}')`;
            }
            //Static convention instance redirect
            /*string */ ToString() { return $.$srij.System.Runtime.InteropServices.JavaScript.JSObject.ToString.apply(this, arguments); }
            /*void */ AssertNotDisposed()
            {
                {
                    $.$spc.System.ObjectDisposedException.ThrowIf(this.IsDisposed, this);
                }
            }
            /*void */ DisposeImpl(/*bool*/ skipJsCleanup)
            {
                if (!this._isDisposed)
                {
                    $.$srij.System.Runtime.InteropServices.JavaScript.JSProxyContext.ReleaseCSOwnedObject(this, skipJsCleanup);
                }
            }
            $dtor()
            {
                this.DisposeImpl(false);
            }
            /*void */ Dispose()
            {
                this.DisposeImpl(false);
            }
            /*bool */ get IsDisposed()
            {
                return this._isDisposed;
            }
            /*bool */ HasProperty(/*string*/ propertyName)
            {
                this.AssertNotDisposed();
                return INTERNAL.has_property(this, propertyName);
            }
            /*string */ GetTypeOfProperty(/*string*/ propertyName)
            {
                this.AssertNotDisposed();
                return INTERNAL.get_typeof_property(this, propertyName);
            }
            /*bool */ GetPropertyAsBoolean(/*string*/ propertyName)
            {
                this.AssertNotDisposed();
                return INTERNAL.get_property(this, propertyName);
            }
            /*int */ GetPropertyAsInt32(/*string*/ propertyName)
            {
                this.AssertNotDisposed();
                return INTERNAL.get_property(this, propertyName);
            }
            /*double */ GetPropertyAsDouble(/*string*/ propertyName)
            {
                this.AssertNotDisposed();
                return INTERNAL.get_property(this, propertyName);
            }
            /*string? */ GetPropertyAsString(/*string*/ propertyName)
            {
                this.AssertNotDisposed();
                return INTERNAL.get_property(this, propertyName);
            }
            /*JSObject? */ GetPropertyAsJSObject(/*string*/ propertyName)
            {
                this.AssertNotDisposed();
                return INTERNAL.get_property(this, propertyName);
            }
            /*byte[]? */ GetPropertyAsByteArray(/*string*/ propertyName)
            {
                this.AssertNotDisposed();
                return INTERNAL.get_property(this, propertyName);
            }
            /*void */ SetProperty(/*string*/ propertyName, /*bool*/ value)
            {
                this.AssertNotDisposed();
                INTERNAL.set_property(this, propertyName, value);
            }
            /*void */ SetProperty$1(/*string*/ propertyName, /*int*/ value)
            {
                this.AssertNotDisposed();
                INTERNAL.set_property(this, propertyName, value);
            }
            /*void */ SetProperty$2(/*string*/ propertyName, /*double*/ value)
            {
                this.AssertNotDisposed();
                INTERNAL.set_property(this, propertyName, value);
            }
            /*void */ SetProperty$3(/*string*/ propertyName, /*string?*/ value)
            {
                this.AssertNotDisposed();
                INTERNAL.set_property(this, propertyName, value);
            }
            /*void */ SetProperty$4(/*string*/ propertyName, /*JSObject?*/ value)
            {
                this.AssertNotDisposed();
                INTERNAL.set_property(this, propertyName, value);
            }
            /*void */ SetProperty$5(/*string*/ propertyName, /*byte[]?*/ value)
            {
                this.AssertNotDisposed();
                INTERNAL.set_property(this, propertyName, value);
            }
            //Generated interface implemetation for System.IDisposable.Dispose()
            System$IDisposable$Dispose()
            {
                return this.Dispose(...arguments);
            }
            //default member initializer
            constructor()
            {
                super();
                $.$finalizer(this);
            }
            static $h = 2289033;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":131137537,"g":{"r":0,"d":0,"h":17182158217,"f":1},"n":"SynchronizationContext","d":2289033,"h":12887190921,"f":1},{"p":262145,"g":{"r":0,"d":0,"h":64426798473,"f":1},"n":"IsDisposed","d":2289033,"h":60131831177,"f":1}],"m":[{"r":262145,"p":[{"n":"obj","p":131073}],"n":"Equals","d":2289033,"h":30067060105,"f":32769},{"r":655361,"n":"GetHashCode","d":2289033,"h":34362027401,"f":32769},{"r":1310721,"n":"ToString","d":2289033,"h":38656994697,"f":32769},{"r":65537,"n":"AssertNotDisposed","d":2289033,"h":42951961993,"f":8},{"r":65537,"p":[{"n":"skipJsCleanup","p":262145,"f":65,"v":false}],"n":"DisposeImpl","d":2289033,"h":47246929289,"f":8},{"r":65537,"n":"Dispose","d":2289033,"h":55836863881,"f":1},{"r":262145,"p":[{"n":"propertyName","p":1310721}],"n":"HasProperty","d":2289033,"h":68721765769,"f":1},{"r":1310721,"p":[{"n":"propertyName","p":1310721}],"n":"GetTypeOfProperty","d":2289033,"h":73016733065,"f":1},{"r":262145,"p":[{"n":"propertyName","p":1310721}],"n":"GetPropertyAsBoolean","d":2289033,"h":77311700361,"f":1},{"r":655361,"p":[{"n":"propertyName","p":1310721}],"n":"GetPropertyAsInt32","d":2289033,"h":81606667657,"f":1},{"r":1179649,"p":[{"n":"propertyName","p":1310721}],"n":"GetPropertyAsDouble","d":2289033,"h":85901634953,"f":1},{"r":1310721,"p":[{"n":"propertyName","p":1310721}],"n":"GetPropertyAsString","d":2289033,"h":90196602249,"f":1},{"r":2289033,"p":[{"n":"propertyName","p":1310721}],"n":"GetPropertyAsJSObject","d":2289033,"h":94491569545,"f":1},{"r":0,"p":[{"n":"propertyName","p":1310721}],"n":"GetPropertyAsByteArray","d":2289033,"h":98786536841,"f":1},{"r":65537,"p":[{"n":"propertyName","p":1310721},{"n":"value","p":262145}],"n":"SetProperty","d":2289033,"h":103081504137,"f":1},{"r":65537,"p":[{"n":"propertyName","p":1310721},{"n":"value","p":655361}],"n":"SetProperty","o":"@$1","d":2289033,"h":107376471433,"f":1},{"r":65537,"p":[{"n":"propertyName","p":1310721},{"n":"value","p":1179649}],"n":"SetProperty","o":"@$2","d":2289033,"h":111671438729,"f":1},{"r":65537,"p":[{"n":"propertyName","p":1310721},{"n":"value","p":1310721}],"n":"SetProperty","o":"@$3","d":2289033,"h":115966406025,"f":1},{"r":65537,"p":[{"n":"propertyName","p":1310721},{"n":"value","p":2289033}],"n":"SetProperty","o":"@$4","d":2289033,"h":120261373321,"f":1},{"r":65537,"p":[{"n":"propertyName","p":1310721},{"n":"value","p":0}],"n":"SetProperty","o":"@$5","d":2289033,"h":124556340617,"f":1}],"l":[{"t":786433,"n":"JSHandle","d":2289033,"h":4297256329,"f":8},{"t":2354569,"n":"ProxyContext","d":2289033,"h":8592223625,"f":8},{"t":262145,"n":"_isDisposed","d":2289033,"h":21477125513,"f":8}],"c":[{"p":[{"n":"jsHandle","p":786433},{"n":"ctx","p":2354569}],"n":".ctor","o":"$ctor$1","d":2289033,"h":25772092809,"f":8}],"i":[57540609],"h":2289033,"a":[{"t":114950145,"c":4409917441,"a":[{"v":"browser","t":1310721}]}]}; }
            static get $b() { return $.$spc.System.Object; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IDisposable ]; }
            static get $fullName() { return `System.Runtime.InteropServices.JavaScript.JSObject`; }
        });
        
        $asm.$cls("$srij.System.Runtime.InteropServices.JavaScript.JSProxyContext", ($self) => class JSProxyContext extends $.$spc.System.Object
        {
            /*bool*/ _isDisposed = false;
            /*Dictionary<nint, WeakReference<JSObject>>*/ ThreadCsOwnedObjects = null;
            /*Dictionary<object, nint>*/ ThreadJsOwnedObjects = null;
            /*Dictionary<nint, PromiseHolder>*/ ThreadJsOwnedHolders = null;
            /*nint*/ NextJSVHandle = -2;
            /*List<nint>*/ JSVHandleFreeList = null;
            $ctor$1()
            {
                super.$ctor();
                {
                }
                return this;
            }
            /*bool */ IsCurrentThread()
            {
                return true;
            }
            /*JSProxyContext*/ static MainThreadContext = null;
            static /*JSProxyContext */ get CurrentThreadContext()
            {
                return $.$srij.System.Runtime.InteropServices.JavaScript.JSProxyContext.MainThreadContext;
            }
            static /*JSProxyContext */ get CurrentOperationContext()
            {
                return $.$srij.System.Runtime.InteropServices.JavaScript.JSProxyContext.MainThreadContext;
            }
            static /*JSProxyContext */ PushOperationWithCurrentThreadContext()
            {
                return $.$srij.System.Runtime.InteropServices.JavaScript.JSProxyContext.MainThreadContext;
            }
            static /*JSProxyContext */ AssertIsInteropThread()
            {
                return $.$srij.System.Runtime.InteropServices.JavaScript.JSProxyContext.MainThreadContext;
            }
            static /*bool */ IsJSVHandle(/*nint*/ jsHandle)
            {
                return jsHandle < -1;
            }
            static /*bool */ IsGCVHandle(/*nint*/ gcHandle)
            {
                return gcHandle < -1;
            }
            /*nint */ AllocJSVHandle()
            {
                {
                    $.$spc.System.ObjectDisposedException.ThrowIf(this._isDisposed, this);
                    if (this.JSVHandleFreeList.Count > 0)
                    {
                        /*var*/ let jsvHandle = this.JSVHandleFreeList.get_Item(((this.JSVHandleFreeList.Count - 1) | 0));
                        this.JSVHandleFreeList.RemoveAt(((this.JSVHandleFreeList.Count - 1) | 0));
                        return jsvHandle;
                    }
                    return this.NextJSVHandle--;
                }
            }
            /*void */ FreeJSVHandle(/*nint*/ jsvHandle)
            {
                {
                    this.JSVHandleFreeList.Add(jsvHandle);
                }
            }
            /*IntPtr */ GetJSOwnedObjectGCHandle(/*object*/ obj, /*GCHandleType*/ handleType)
            {
                if (obj === null)
                {
                    return $.$spc.System.IntPtr.Zero;
                }
                {
                    /*IntPtr*/ let gcHandle;
                    if (this.ThreadJsOwnedObjects.TryGetValue(obj, $.$ref(() => gcHandle, ($v) => gcHandle = $v, $.$spc.System.IntPtr)))
                    {
                        return gcHandle;
                    }
                    /*IntPtr*/ let result = $.$spc.System.Runtime.InteropServices.GCHandle.op_Explicit$1($.$spc.System.Runtime.InteropServices.GCHandle.Alloc$1(obj, handleType));
                    this.ThreadJsOwnedObjects.set_Item(obj, result);
                    return result;
                }
            }
            /*PromiseHolder */ CreatePromiseHolder()
            {
                {
                    return new $.$srij.System.Runtime.InteropServices.JavaScript.JSHostImplementation.PromiseHolder().$ctor$1(this);
                }
            }
            /*PromiseHolder */ GetPromiseHolder(/*nint*/ gcHandle)
            {
                {
                    /*PromiseHolder?*/ let holder;
                    if ($.$srij.System.Runtime.InteropServices.JavaScript.JSProxyContext.IsGCVHandle(gcHandle))
                    {
                        if (!this.ThreadJsOwnedHolders.TryGetValue(gcHandle, $.$ref(() => holder, ($v) => holder = $v, $.$srij.System.Runtime.InteropServices.JavaScript.JSHostImplementation.PromiseHolder)))
                        {
                            holder = new $.$srij.System.Runtime.InteropServices.JavaScript.JSHostImplementation.PromiseHolder().$ctor$2(this, gcHandle);
                            this.ThreadJsOwnedHolders.Add(gcHandle, holder);
                        }
                    }
                    else 
                    {
                        holder = $.$cast(($.$spc.System.Runtime.InteropServices.GCHandle.op_Explicit(gcHandle)).Target, $.$srij.System.Runtime.InteropServices.JavaScript.JSHostImplementation.PromiseHolder);
                    }
                    return holder;
                }
            }
            /*void */ ReleasePromiseHolder(/*nint*/ holderGCHandle)
            {
                {
                    /*PromiseHolder?*/ let holder;
                    if ($.$srij.System.Runtime.InteropServices.JavaScript.JSProxyContext.IsGCVHandle(holderGCHandle))
                    {
                        if (!this.ThreadJsOwnedHolders.Remove$1(holderGCHandle, $.$ref(() => holder, ($v) => holder = $v, $.$srij.System.Runtime.InteropServices.JavaScript.JSHostImplementation.PromiseHolder)))
                        {
                            throw new $.$spc.System.InvalidOperationException().$ctor$10("ReleasePromiseHolder expected PromiseHolder " + holderGCHandle);
                        }
                        holder.IsDisposed = true;
                    }
                    else 
                    {
                        /*GCHandle*/ let handle = $.$spc.System.Runtime.InteropServices.GCHandle.op_Explicit(holderGCHandle);
                        /*var*/ let target = handle.Target;
                        let holder2;
                        if ($.$is(target, $.$srij.System.Runtime.InteropServices.JavaScript.JSHostImplementation.PromiseHolder, { set $v(v){ holder2 = v; } }))
                        {
                            holder = holder2;
                        }
                        else 
                        {
                            throw new $.$spc.System.InvalidOperationException().$ctor$10("ReleasePromiseHolder expected PromiseHolder" + holderGCHandle);
                        }
                        holder.IsDisposed = true;
                        handle.Free();
                    }
                }
            }
            /*void */ ReleaseJSOwnedObjectByGCHandle(/*nint*/ gcHandle)
            {
                /*ToManagedCallback?*/ let holderCallback = null;
                {
                    /*PromiseHolder?*/ let holder = null;
                    if ($.$srij.System.Runtime.InteropServices.JavaScript.JSProxyContext.IsGCVHandle(gcHandle))
                    {
                        if (!this.ThreadJsOwnedHolders.Remove$1(gcHandle, $.$ref(() => holder, ($v) => holder = $v, $.$srij.System.Runtime.InteropServices.JavaScript.JSHostImplementation.PromiseHolder)))
                        {
                            throw new $.$spc.System.InvalidOperationException().$ctor$10("ReleaseJSOwnedObjectByGCHandle expected in ThreadJsOwnedHolders");
                        }
                    }
                    else 
                    {
                        /*GCHandle*/ let handle = $.$spc.System.Runtime.InteropServices.GCHandle.op_Explicit(gcHandle);
                        /*var*/ let target = handle.Target;
                        let holder2;
                        if ($.$is(target, $.$srij.System.Runtime.InteropServices.JavaScript.JSHostImplementation.PromiseHolder, { set $v(v){ holder2 = v; } }))
                        {
                            holder = holder2;
                        }
                        else 
                        {
                            if (!this.ThreadJsOwnedObjects.Remove(target))
                            {
                                throw new $.$spc.System.InvalidOperationException().$ctor$10("ReleaseJSOwnedObjectByGCHandle expected in ThreadJsOwnedObjects");
                            }
                        }
                        handle.Free();
                    }
                    if (holder !== null)
                    {
                        holderCallback = holder.Callback;
                        holder.IsDisposed = true;
                    }
                }
                holderCallback?.Invoke(null);
            }
            /*JSObject */ CreateCSOwnedProxy(/*nint*/ jsHandle)
            {
                {
                    /*JSObject?*/ let res;
                    /*WeakReference<JSObject>?*/ let reference;
                    if (!this.ThreadCsOwnedObjects.TryGetValue(jsHandle, $.$ref(() => reference, ($v) => reference = $v, $.$spc.System.WeakReference$$($.$srij.System.Runtime.InteropServices.JavaScript.JSObject))) || !reference.TryGetTarget($.$ref(() => res, ($v) => res = $v, $.$srij.System.Runtime.InteropServices.JavaScript.JSObject)) || res.IsDisposed)
                    {
                        res = new $.$srij.System.Runtime.InteropServices.JavaScript.JSObject().$ctor$1(jsHandle, this);
                        this.ThreadCsOwnedObjects.set_Item(jsHandle, new ($.$spc.System.WeakReference$$($.$srij.System.Runtime.InteropServices.JavaScript.JSObject))().$ctor$2(res, true));
                    }
                    return res;
                }
            }
            static /*void */ ReleaseCSOwnedObject(/*JSObject*/ jso, /*bool*/ skipJS)
            {
                if (jso.IsDisposed)
                {
                    return;
                }
                /*var*/ let ctx = jso.ProxyContext;
                {
                    if (jso.IsDisposed || ctx._isDisposed)
                    {
                        return;
                    }
                    /*var*/ let jsHandle = jso.JSHandle;
                    jso._isDisposed = true;
                    jso.JSHandle = $.$spc.System.IntPtr.Zero;
                    $.$spc.System.GC.SuppressFinalize(jso);
                    if (!ctx.ThreadCsOwnedObjects.Remove(jsHandle))
                    {
                        $.$spc.System.Environment.FailFast(`ReleaseCSOwnedObject expected to find registration for JSHandle: ${jsHandle}, ManagedThreadId: ${$.$spc.System.Environment.CurrentManagedThreadId}. ${$.$spc.System.Environment.NewLine} ${$.$spc.System.Environment.StackTrace}`);
                    }
                    if (!skipJS)
                    {
                        $.$srij.Interop.Runtime.ReleaseCSOwnedObject(jsHandle);
                    }
                    if ($.$srij.System.Runtime.InteropServices.JavaScript.JSProxyContext.IsJSVHandle(jsHandle))
                    {
                        ctx.FreeJSVHandle(jsHandle);
                    }
                }
            }
            /*void */ Dispose(/*bool*/ disposing)
            {
                {
                    if (!this._isDisposed)
                    {
                        /*List<WeakReference<JSObject>>*/ let copy = new ($.$spc.System.Collections.Generic.List$$($.$spc.System.WeakReference$$($.$srij.System.Runtime.InteropServices.JavaScript.JSObject)))().$ctor$3(this.ThreadCsOwnedObjects.Values);
                        var $en4 = copy.GetEnumerator();
                        while ($en4.MoveNext())
                        {
                            var jsObjectWeak = $en4.Current;
                            {
                                /*var*/ let jso;
                                if (jsObjectWeak.TryGetTarget($.$ref(() => jso, ($v) => jso = $v, $.$srij.System.Runtime.InteropServices.JavaScript.JSObject)))
                                {
                                    jso.Dispose();
                                }
                            }
                        }
                        var $en4 = this.ThreadJsOwnedObjects.Values.GetEnumerator();
                        while ($en4.MoveNext())
                        {
                            var gch = $en4.Current;
                            {
                                /*GCHandle*/ let gcHandle = $.$spc.System.Runtime.InteropServices.GCHandle.op_Explicit(gch);
                                gcHandle.Free();
                            }
                        }
                        var $en4 = this.ThreadJsOwnedHolders.Values.GetEnumerator();
                        while ($en4.MoveNext())
                        {
                            var holder = $en4.Current;
                            {
                                {
                                    holder.Callback.Invoke(null);
                                }
                                ($.$spc.System.Runtime.InteropServices.GCHandle.op_Explicit(holder.GCHandle)).Free();
                            }
                        }
                        this.ThreadCsOwnedObjects.Clear();
                        this.ThreadJsOwnedObjects.Clear();
                        this.JSVHandleFreeList.Clear();
                        this.NextJSVHandle = $.$spc.System.IntPtr.Zero;
                        if (disposing)
                        {
                        }
                        this._isDisposed = true;
                    }
                }
            }
            $dtor()
            {
                this.Dispose(false);
            }
            /*void */ Dispose$1()
            {
                this.Dispose(true);
                $.$spc.System.GC.SuppressFinalize(this);
            }
            //Generated interface implemetation for System.IDisposable.Dispose()
            System$IDisposable$Dispose()
            {
                return this.Dispose$1(...arguments);
            }
            //default member initializer
            constructor()
            {
                super();
                this.ThreadCsOwnedObjects = new ($.$spc.System.Collections.Generic.Dictionary$$$($.$spc.System.IntPtr, $.$spc.System.WeakReference$$($.$srij.System.Runtime.InteropServices.JavaScript.JSObject)))().$ctor$1();
                this.ThreadJsOwnedObjects = new ($.$spc.System.Collections.Generic.Dictionary$$$($.$spc.System.Object, $.$spc.System.IntPtr))().$ctor$3($.$spc.System.Collections.Generic.ReferenceEqualityComparer.Instance);
                this.ThreadJsOwnedHolders = new ($.$spc.System.Collections.Generic.Dictionary$$$($.$spc.System.IntPtr, $.$srij.System.Runtime.InteropServices.JavaScript.JSHostImplementation.PromiseHolder))().$ctor$1();
                this.JSVHandleFreeList = new ($.$spc.System.Collections.Generic.List$$($.$spc.System.IntPtr))().$ctor$1();
                $.$finalizer(this);
            }
            //Static Initializer
            static $sinit()
            {
                {
                    this.MainThreadContext = new $.$srij.System.Runtime.InteropServices.JavaScript.JSProxyContext().$ctor$1();
                }
            }
            static $h = 2354569;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":2354569,"g":{"r":0,"d":0,"h":47246994825,"f":33},"n":"CurrentThreadContext","d":2354569,"h":42952027529,"f":33},{"p":2354569,"g":{"r":0,"d":0,"h":55836929417,"f":33},"n":"CurrentOperationContext","d":2354569,"h":51541962121,"f":33}],"m":[{"r":262145,"n":"IsCurrentThread","d":2354569,"h":34362092937,"f":1},{"r":2354569,"n":"PushOperationWithCurrentThreadContext","d":2354569,"h":60131896713,"f":33},{"r":2354569,"n":"AssertIsInteropThread","d":2354569,"h":64426864009,"f":33},{"r":262145,"p":[{"n":"jsHandle","p":786433}],"n":"IsJSVHandle","d":2354569,"h":68721831305,"f":33},{"r":262145,"p":[{"n":"gcHandle","p":786433}],"n":"IsGCVHandle","d":2354569,"h":73016798601,"f":33},{"r":786433,"n":"AllocJSVHandle","d":2354569,"h":77311765897,"f":1},{"r":65537,"p":[{"n":"jsvHandle","p":786433}],"n":"FreeJSVHandle","d":2354569,"h":81606733193,"f":1},{"r":786433,"p":[{"n":"obj","p":131073},{"n":"handleType","p":104333313,"f":65,"v":2}],"n":"GetJSOwnedObjectGCHandle","d":2354569,"h":85901700489,"f":1},{"r":1043849,"n":"CreatePromiseHolder","d":2354569,"h":90196667785,"f":1},{"r":1043849,"p":[{"n":"gcHandle","p":786433}],"n":"GetPromiseHolder","d":2354569,"h":94491635081,"f":1},{"r":65537,"p":[{"n":"holderGCHandle","p":786433}],"n":"ReleasePromiseHolder","d":2354569,"h":98786602377,"f":1},{"r":65537,"p":[{"n":"gcHandle","p":786433}],"n":"ReleaseJSOwnedObjectByGCHandle","d":2354569,"h":103081569673,"f":1},{"r":2289033,"p":[{"n":"jsHandle","p":786433}],"n":"CreateCSOwnedProxy","d":2354569,"h":107376536969,"f":1},{"r":65537,"p":[{"n":"jso","p":2289033},{"n":"skipJS","p":262145}],"n":"ReleaseCSOwnedObject","d":2354569,"h":111671504265,"f":33},{"r":65537,"p":[{"n":"disposing","p":262145}],"n":"Dispose","d":2354569,"h":115966471561,"f":2},{"r":65537,"n":"Dispose","o":"@$1","d":2354569,"h":124556406153,"f":1}],"l":[{"t":262145,"n":"_isDisposed","d":2354569,"h":4297321865,"f":8},{"t":$.$spc.System.Collections.Generic.Dictionary$$$($.$spc.System.IntPtr, $.$spc.System.WeakReference$$($.$srij.System.Runtime.InteropServices.JavaScript.JSObject)).$h,"n":"ThreadCsOwnedObjects","d":2354569,"h":8592289161,"f":2},{"t":$.$spc.System.Collections.Generic.Dictionary$$$($.$spc.System.Object, $.$spc.System.IntPtr).$h,"n":"ThreadJsOwnedObjects","d":2354569,"h":12887256457,"f":2},{"t":$.$spc.System.Collections.Generic.Dictionary$$$($.$spc.System.IntPtr, $.$srij.System.Runtime.InteropServices.JavaScript.JSHostImplementation.PromiseHolder).$h,"n":"ThreadJsOwnedHolders","d":2354569,"h":17182223753,"f":2},{"t":786433,"n":"NextJSVHandle","d":2354569,"h":21477191049,"f":2},{"t":$.$spc.System.Collections.Generic.List$$($.$spc.System.IntPtr).$h,"n":"JSVHandleFreeList","d":2354569,"h":25772158345,"f":2},{"t":2354569,"n":"MainThreadContext","d":2354569,"h":38657060233,"f":33}],"c":[{"n":".ctor","o":"$ctor$1","d":2354569,"h":30067125641,"f":2}],"i":[57540609],"h":2354569}; }
            static get $b() { return $.$spc.System.Object; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IDisposable ]; }
            static get $fullName() { return `System.Runtime.InteropServices.JavaScript.JSProxyContext`; }
        });
        
        $asm.$cls("$srij.System.Runtime.InteropServices.JavaScript.JSMarshalAsAttribute<>", (T) => $asm.$gt("$srij.System.Runtime.InteropServices.JavaScript.JSMarshalAsAttribute<>", [T], ($self) => class JSMarshalAsAttribute$$ extends $.$spc.System.Attribute
        {
            $ctor$2()
            {
                super.$ctor$1();
                {
                }
                return this;
            }
            static $h = 1305993;
            static $g = 1;
            static $f = 0b11010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":14548993,"c":[{"n":".ctor","o":"$ctor$2","d":this.$h,"h":Number(BigInt(this.$h)|0x100000000n),"f":1}],"g":[T?.$h??1507328],"r":1,"h":this.$h,"a":[{"t":14680065,"c":21489516545,"a":[{"v":10240,"t":14614529}],"n":[{"n":"Inherited","v":false,"t":262145},{"n":"AllowMultiple","v":false,"t":262145}]},{"t":114950145,"c":4409917441,"a":[{"v":"browser","t":1310721}]}]}; }
            static get $b() { return $.$spc.System.Attribute; }
            static get $fullName() { return `System.Runtime.InteropServices.JavaScript.JSMarshalAsAttribute<${T?.$fullName}>`; }
        }));
        
        $asm.$cls("$srij.System.Runtime.InteropServices.JavaScript.JSExportAttribute", ($self) => class JSExportAttribute extends $.$spc.System.Attribute
        {
            $ctor$2()
            {
                super.$ctor$1();
                {
                }
                return this;
            }
            static $h = 519561;
            static $f = 0b10010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":14548993,"c":[{"n":".ctor","o":"$ctor$2","d":519561,"h":4295486857,"f":1}],"h":519561,"a":[{"t":14680065,"c":21489516545,"a":[{"v":64,"t":14614529}],"n":[{"n":"Inherited","v":false,"t":262145},{"n":"AllowMultiple","v":false,"t":262145}]},{"t":114950145,"c":4409917441,"a":[{"v":"browser","t":1310721}]}]}; }
            static get $b() { return $.$spc.System.Attribute; }
            static get $fullName() { return `System.Runtime.InteropServices.JavaScript.JSExportAttribute`; }
        });
        
        $asm.$cls("$srij.System.Runtime.InteropServices.JavaScript.JSImportAttribute", ($self) => class JSImportAttribute extends $.$spc.System.Attribute
        {
            /*string*/ FunctionName = null;
            /*string?*/ ModuleName = null;
            $ctor$2(/*string*/ functionName)
            {
                super.$ctor$1();
                {
                    this.FunctionName = functionName;
                }
                return this;
            }
            $ctor$3(/*string*/ functionName, /*string*/ moduleName)
            {
                super.$ctor$1();
                {
                    this.FunctionName = functionName;
                    this.ModuleName = moduleName;
                }
                return this;
            }
            static $h = 1240457;
            static $f = 0b10010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":14548993,"p":[{"p":1310721,"g":{"r":0,"d":0,"h":12886142345,"f":1},"n":"FunctionName","d":1240457,"h":8591175049,"f":1},{"p":1310721,"g":{"r":0,"d":0,"h":25771044233,"f":1},"n":"ModuleName","d":1240457,"h":21476076937,"f":1}],"c":[{"p":[{"n":"functionName","p":1310721}],"n":".ctor","o":"$ctor$2","d":1240457,"h":30066011529,"f":1},{"p":[{"n":"functionName","p":1310721},{"n":"moduleName","p":1310721}],"n":".ctor","o":"$ctor$3","d":1240457,"h":34360978825,"f":1}],"h":1240457,"a":[{"t":14680065,"c":21489516545,"a":[{"v":64,"t":14614529}],"n":[{"n":"Inherited","v":false,"t":262145},{"n":"AllowMultiple","v":false,"t":262145}]},{"t":114950145,"c":4409917441,"a":[{"v":"browser","t":1310721}]}]}; }
            static get $b() { return $.$spc.System.Attribute; }
            static get $fullName() { return `System.Runtime.InteropServices.JavaScript.JSImportAttribute`; }
        });
        
        $asm.$str("$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument", ($self) => class JSMarshalerArgument extends $.$spc.System.ValueType
        {
            /*JSMarshalerArgumentImpl*/  get slot() { return this.$getField(0, 32); }
            /*JSMarshalerArgumentImpl*/  set slot(value) { this.$setField(0, 32, value); }
            static $_JSMarshalerArgumentImpl;
            static get JSMarshalerArgumentImpl()
            {
                let $cls = $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument;
                return $cls.$_JSMarshalerArgumentImpl ??= $asm.$nstr("$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument.JSMarshalerArgumentImpl", ($self) => class JSMarshalerArgumentImpl extends $.$spc.System.ValueType
                {
                    /*bool*/  get BooleanValue() { return this.$getField(0, 1); }
                    /*bool*/  set BooleanValue(value) { this.$setField(0, 1, value); }
                    /*byte*/  get ByteValue() { return this.$getField(0, 1); }
                    /*byte*/  set ByteValue(value) { this.$setField(0, 1, value); }
                    /*char*/  get CharValue() { return this.$getField(0, 2); }
                    /*char*/  set CharValue(value) { this.$setField(0, 2, value); }
                    /*short*/  get Int16Value() { return this.$getField(0, 2); }
                    /*short*/  set Int16Value(value) { this.$setField(0, 2, value); }
                    /*int*/  get Int32Value() { return this.$getField(0, 4); }
                    /*int*/  set Int32Value(value) { this.$setField(0, 4, value); }
                    /*long*/  get Int64Value() { return this.$getField(0, 8); }
                    /*long*/  set Int64Value(value) { this.$setField(0, 8, value); }
                    /*float*/  get SingleValue() { return this.$getField(0, 4); }
                    /*float*/  set SingleValue(value) { this.$setField(0, 4, value); }
                    /*double*/  get DoubleValue() { return this.$getField(0, 8); }
                    /*double*/  set DoubleValue(value) { this.$setField(0, 8, value); }
                    /*IntPtr*/  get IntPtrValue() { return this.$getField(0, 4); }
                    /*IntPtr*/  set IntPtrValue(value) { this.$setField(0, 4, value); }
                    /*IntPtr*/  get JSHandle() { return this.$getField(4, 4); }
                    /*IntPtr*/  set JSHandle(value) { this.$setField(4, 4, value); }
                    /*IntPtr*/  get GCHandle() { return this.$getField(4, 4); }
                    /*IntPtr*/  set GCHandle(value) { this.$setField(4, 4, value); }
                    /*int*/  get Length() { return this.$getField(8, 4); }
                    /*int*/  set Length(value) { this.$setField(8, 4, value); }
                    /*MarshalerType*/  get Type() { return this.$getField(12, 1); }
                    /*MarshalerType*/  set Type(value) { this.$setField(12, 1, value); }
                    /*MarshalerType*/  get ElementType() { return this.$getField(13, 1); }
                    /*MarshalerType*/  set ElementType(value) { this.$setField(13, 1, value); }
                    //default value type constructor
                    $ctor$2()
                    {
                        return this;
                    }
                    Clone($copy)
                    {
                        let copy = $copy ?? new this.constructor();
                        copy.BooleanValue = this.BooleanValue;
                        copy.ByteValue = this.ByteValue;
                        copy.CharValue = this.CharValue;
                        copy.Int16Value = this.Int16Value;
                        copy.Int32Value = this.Int32Value;
                        copy.Int64Value = this.Int64Value;
                        copy.SingleValue = this.SingleValue;
                        copy.DoubleValue = this.DoubleValue;
                        copy.IntPtrValue = this.IntPtrValue;
                        copy.JSHandle = this.JSHandle;
                        copy.GCHandle = this.GCHandle;
                        copy.Length = this.Length;
                        copy.Type = this.Type;
                        copy.ElementType = this.ElementType;
                        return copy;
                    }
                    //default member initializer
                    constructor()
                    {
                        super();
                        this.BooleanValue = false;
                        this.ByteValue = 0;
                        this.CharValue = 0;
                        this.Int16Value = 0;
                        this.Int32Value = 0;
                        this.Int64Value = 0n;
                        this.SingleValue = 0;
                        this.DoubleValue = 0;
                        this.IntPtrValue = 0;
                        this.JSHandle = 0;
                        this.GCHandle = 0;
                        this.Length = 0;
                        this.Type = 0;
                        this.ElementType = 0;
                    }
                    static $h = 2157961;
                    static $z = 32;
                    static $f = 0b100010000001010000000;
                    static $k = 2;
                    static $$md;
                    static get $md() { return this.$$md ??= {"b":196609,"l":[{"t":262145,"n":"BooleanValue","d":2157961,"h":4297125257,"f":8,"a":[{"t":104071169,"c":4399038465,"a":[{"v":0,"t":655361}]}]},{"t":393217,"n":"ByteValue","d":2157961,"h":8592092553,"f":8,"a":[{"t":104071169,"c":4399038465,"a":[{"v":0,"t":655361}]}]},{"t":458753,"n":"CharValue","d":2157961,"h":12887059849,"f":8,"a":[{"t":104071169,"c":4399038465,"a":[{"v":0,"t":655361}]}]},{"t":524289,"n":"Int16Value","d":2157961,"h":17182027145,"f":8,"a":[{"t":104071169,"c":4399038465,"a":[{"v":0,"t":655361}]}]},{"t":655361,"n":"Int32Value","d":2157961,"h":21476994441,"f":8,"a":[{"t":104071169,"c":4399038465,"a":[{"v":0,"t":655361}]}]},{"t":917505,"n":"Int64Value","d":2157961,"h":25771961737,"f":8,"a":[{"t":104071169,"c":4399038465,"a":[{"v":0,"t":655361}]}]},{"t":1114113,"n":"SingleValue","d":2157961,"h":30066929033,"f":8,"a":[{"t":104071169,"c":4399038465,"a":[{"v":0,"t":655361}]}]},{"t":1179649,"n":"DoubleValue","d":2157961,"h":34361896329,"f":8,"a":[{"t":104071169,"c":4399038465,"a":[{"v":0,"t":655361}]}]},{"t":786433,"n":"IntPtrValue","d":2157961,"h":38656863625,"f":8,"a":[{"t":104071169,"c":4399038465,"a":[{"v":0,"t":655361}]}]},{"t":786433,"n":"JSHandle","d":2157961,"h":42951830921,"f":8,"a":[{"t":104071169,"c":4399038465,"a":[{"v":4,"t":655361}]}]},{"t":786433,"n":"GCHandle","d":2157961,"h":47246798217,"f":8,"a":[{"t":104071169,"c":4399038465,"a":[{"v":4,"t":655361}]}]},{"t":655361,"n":"Length","d":2157961,"h":51541765513,"f":8,"a":[{"t":104071169,"c":4399038465,"a":[{"v":8,"t":655361}]}]},{"t":3730825,"n":"Type","d":2157961,"h":55836732809,"f":8,"a":[{"t":104071169,"c":4399038465,"a":[{"v":12,"t":655361}]}]},{"t":3730825,"n":"ElementType","d":2157961,"h":60131700105,"f":8,"a":[{"t":104071169,"c":4399038465,"a":[{"v":13,"t":655361}]}]}],"c":[{"n":".ctor","o":"$ctor$2","d":2157961,"h":64426667401,"f":1}],"d":1371529,"h":2157961,"a":[{"t":109903873,"c":4404871169,"a":[{"v":2,"t":105381889}],"n":[{"n":"Pack","v":32,"t":655361},{"n":"Size","v":32,"t":655361}]}]}; }
                    static get $b() { return $.$spc.System.ValueType; }
                    static get $fullName() { return `System.Runtime.InteropServices.JavaScript.JSMarshalerArgument.JSMarshalerArgumentImpl`; }
                }, $cls, ($v) => $cls.$_JSMarshalerArgumentImpl = $v);
            }
            /*void */ Initialize()
            {
                this.slot.Type = 0/*MarshalerType.None*/;
            }
            /*JSProxyContext */ get ToManagedContext()
            {
                return $.$srij.System.Runtime.InteropServices.JavaScript.JSProxyContext.MainThreadContext;
            }
            /*JSProxyContext */ get ToJSContext()
            {
                return $.$srij.System.Runtime.InteropServices.JavaScript.JSProxyContext.MainThreadContext;
            }
            /*JSProxyContext */ AssertCurrentThreadContext()
            {
                return $.$srij.System.Runtime.InteropServices.JavaScript.JSProxyContext.MainThreadContext;
            }
            /*void */ ToManagedBig(/*out long*/ value)
            {
                if (this.slot.Type === 0/*MarshalerType.None*/)
                {
                    value.$v = 0n;
                    return;
                }
                value.$v = this.slot.Int64Value;
            }
            /*void */ ToJSBig(/*long*/ value)
            {
                this.slot.Type = 9/*MarshalerType.BigInt64*/;
                this.slot.Int64Value = value;
            }
            /*void */ ToManagedBig$1(/*out long?*/ value)
            {
                if (this.slot.Type === 0/*MarshalerType.None*/)
                {
                    value.$v = null;
                    return;
                }
                value.$v = this.slot.Int64Value;
            }
            /*void */ ToJSBig$1(/*long?*/ value)
            {
                if ($.$spc.System.Nullable$$($.$spc.System.Int64).HasValue$get.call(value))
                {
                    this.slot.Type = 9/*MarshalerType.BigInt64*/;
                    this.slot.Int64Value = $.$spc.System.Nullable$$($.$spc.System.Int64).Value$get.call(value);
                }
                else 
                {
                    this.slot.Type = 0/*MarshalerType.None*/;
                }
            }
            /*void */ ToManaged(/*out float*/ value)
            {
                if (this.slot.Type === 0/*MarshalerType.None*/)
                {
                    value.$v = 0;
                    return;
                }
                value.$v = this.slot.SingleValue;
            }
            /*void */ ToJS(/*float*/ value)
            {
                this.slot.Type = 11/*MarshalerType.Single*/;
                this.slot.SingleValue = value;
            }
            /*void */ ToManaged$1(/*out float?*/ value)
            {
                if (this.slot.Type === 0/*MarshalerType.None*/)
                {
                    value.$v = null;
                    return;
                }
                value.$v = this.slot.SingleValue;
            }
            /*void */ ToJS$1(/*float?*/ value)
            {
                if ($.$spc.System.Nullable$$($.$spc.System.Single).HasValue$get.call(value))
                {
                    this.slot.Type = 11/*MarshalerType.Single*/;
                    this.slot.SingleValue = $.$spc.System.Nullable$$($.$spc.System.Single).Value$get.call(value);
                }
                else 
                {
                    this.slot.Type = 0/*MarshalerType.None*/;
                }
            }
            /*long*/ static I52_MAX_VALUE = 9007199254740991n;
            /*long*/ static I52_MIN_VALUE = -9007199254740991n;
            /*void */ ToManaged$2(/*out long*/ value)
            {
                if (this.slot.Type === 0/*MarshalerType.None*/)
                {
                    value.$v = 0n;
                    return;
                }
                value.$v = $.$cast(this.slot.DoubleValue, $.$spc.System.Int64);
            }
            /*void */ ToJS$2(/*long*/ value)
            {
                if (value < -9007199254740991n || value > 9007199254740991n)
                {
                    throw new $.$spc.System.OverflowException().$ctor$14($.$srij.System.SR.Format$2($.$srij.System.SR.ValueOutOf52BitRange, $.$box(value, $.$spc.System.Int64), $.$box(-9007199254740991n, $.$spc.System.Int64), $.$box(9007199254740991n, $.$spc.System.Int64)));
                }
                this.slot.Type = 8/*MarshalerType.Int52*/;
                this.slot.DoubleValue = Number(value);
            }
            /*void */ ToManaged$3(/*out long?*/ value)
            {
                if (this.slot.Type === 0/*MarshalerType.None*/)
                {
                    value.$v = null;
                    return;
                }
                value.$v = $.$cast(this.slot.DoubleValue, $.$spc.System.Int64);
            }
            /*void */ ToJS$3(/*long?*/ value)
            {
                if ($.$spc.System.Nullable$$($.$spc.System.Int64).HasValue$get.call(value))
                {
                    if ($.$spc.System.Nullable$$($.$spc.System.Int64).Value$get.call(value) < -9007199254740991n || $.$spc.System.Nullable$$($.$spc.System.Int64).Value$get.call(value) > 9007199254740991n)
                    {
                        throw new $.$spc.System.OverflowException().$ctor$14($.$srij.System.SR.Format$2($.$srij.System.SR.ValueOutOf52BitRange, $.$box(value, $.$spc.System.Nullable$$($.$spc.System.Int64)), $.$box(-9007199254740991n, $.$spc.System.Int64), $.$box(9007199254740991n, $.$spc.System.Int64)));
                    }
                    this.slot.Type = 8/*MarshalerType.Int52*/;
                    this.slot.DoubleValue = Number($.$spc.System.Nullable$$($.$spc.System.Int64).Value$get.call(value));
                }
                else 
                {
                    this.slot.Type = 0/*MarshalerType.None*/;
                }
            }
            /*void */ ToManaged$4(/*out double*/ value)
            {
                if (this.slot.Type === 0/*MarshalerType.None*/)
                {
                    value.$v = 0;
                    return;
                }
                value.$v = this.slot.DoubleValue;
            }
            /*void */ ToJS$4(/*double*/ value)
            {
                this.slot.Type = 10/*MarshalerType.Double*/;
                this.slot.DoubleValue = value;
            }
            /*void */ ToManaged$5(/*out double?*/ value)
            {
                if (this.slot.Type === 0/*MarshalerType.None*/)
                {
                    value.$v = null;
                    return;
                }
                value.$v = this.slot.DoubleValue;
            }
            /*void */ ToJS$5(/*double?*/ value)
            {
                if ($.$spc.System.Nullable$$($.$spc.System.Double).HasValue$get.call(value))
                {
                    this.slot.Type = 10/*MarshalerType.Double*/;
                    this.slot.DoubleValue = $.$spc.System.Nullable$$($.$spc.System.Double).Value$get.call(value);
                }
                else 
                {
                    this.slot.Type = 0/*MarshalerType.None*/;
                }
            }
            /*void */ ToManaged$6(/*out double[]?*/ value)
            {
                if (this.slot.Type === 0/*MarshalerType.None*/)
                {
                    value.$v = null;
                    return;
                }
                value.$v = $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$spc.System.Double), null, [this.slot.Length], null);
                $.$spc.System.Runtime.InteropServices.Marshal.Copy$13(this.slot.IntPtrValue, value.$v, 0, this.slot.Length);
                $.$spc.System.Runtime.InteropServices.Marshal.FreeHGlobal(this.slot.IntPtrValue);
            }
            /*void */ ToJS$6(/*double[]*/ value)
            {
                if (value === null)
                {
                    this.slot.Type = 0/*MarshalerType.None*/;
                    return;
                }
                this.slot.Type = 21/*MarshalerType.Array*/;
                this.slot.IntPtrValue = $.$spc.System.Runtime.InteropServices.Marshal.AllocHGlobal(((value.length * $.$spc.System.Double.$z) | 0));
                this.slot.Length = value.length;
                this.slot.ElementType = 10/*MarshalerType.Double*/;
                $.$spc.System.Runtime.InteropServices.Marshal.Copy$5(value, 0, this.slot.IntPtrValue, this.slot.Length);
            }
            /*void */ ToManaged$7(/*out ArraySegment<double>*/ value)
            {
                /*var*/ let array = $.$cast(($.$spc.System.Runtime.InteropServices.GCHandle.op_Explicit(this.slot.GCHandle)).Target, $.$typeArray($.$spc.System.Double));
                /*var*/ let refPtr = $.$spc.System.IntPtr.op_Explicit$2($.$spc.System.Runtime.CompilerServices.Unsafe.AsPointer($.$spc.System.Double, $.$spc.System.Runtime.InteropServices.MemoryMarshal.GetArrayDataReference($.$spc.System.Double, array)));
                /*int*/ let byteOffset = (this.slot.IntPtrValue - refPtr);
                value.$v = new ($.$spc.System.ArraySegment$$($.$spc.System.Double))().$ctor$3(array, $.trunc(byteOffset / $.$spc.System.Double.$z), this.slot.Length);
            }
            /*void */ ToJS$7(/*ArraySegment<double>*/ value)
            {
                if (value.Array === null)
                {
                    this.slot.Type = 0/*MarshalerType.None*/;
                    return;
                }
                this.slot.Type = 22/*MarshalerType.ArraySegment*/;
                /*var*/ let ctx = this.ToJSContext;
                this.slot.GCHandle = ctx.GetJSOwnedObjectGCHandle(value.Array, 3/*GCHandleType.Pinned*/);
                /*var*/ let refPtr = $.$spc.System.IntPtr.op_Explicit$2($.$spc.System.Runtime.CompilerServices.Unsafe.AsPointer($.$spc.System.Double, $.$spc.System.Runtime.InteropServices.MemoryMarshal.GetArrayDataReference($.$spc.System.Double, value.Array)));
                this.slot.IntPtrValue = refPtr + (((value.Offset * $.$spc.System.Double.$z) | 0));
                this.slot.Length = value.Count;
            }
            /*void */ ToManaged$8(/*out Span<double>*/ value)
            {
                value.$v = new ($.$spc.System.Span$$($.$spc.System.Double))().$ctor$4($.$spc.System.IntPtr.op_Explicit$3(this.slot.IntPtrValue), this.slot.Length);
            }
            /*void */ ToJS$8(/*Span<double>*/ value)
            {
                this.slot.Length = value.Length;
                this.slot.IntPtrValue = $.$spc.System.IntPtr.op_Explicit$2($.$spc.System.Runtime.CompilerServices.Unsafe.AsPointer($.$spc.System.Double, value.GetPinnableReference()));
                this.slot.Type = 23/*MarshalerType.Span*/;
            }
            /*void */ ToManaged$9(/*out short*/ value)
            {
                if (this.slot.Type === 0/*MarshalerType.None*/)
                {
                    value.$v = 0;
                    return;
                }
                value.$v = this.slot.Int16Value;
            }
            /*void */ ToJS$9(/*short*/ value)
            {
                this.slot.Type = 6/*MarshalerType.Int16*/;
                this.slot.Int16Value = value;
            }
            /*void */ ToManaged$10(/*out short?*/ value)
            {
                if (this.slot.Type === 0/*MarshalerType.None*/)
                {
                    value.$v = null;
                    return;
                }
                value.$v = this.slot.Int16Value;
            }
            /*void */ ToJS$10(/*short?*/ value)
            {
                if ($.$spc.System.Nullable$$($.$spc.System.Int16).HasValue$get.call(value))
                {
                    this.slot.Type = 6/*MarshalerType.Int16*/;
                    this.slot.Int16Value = $.$spc.System.Nullable$$($.$spc.System.Int16).Value$get.call(value);
                }
                else 
                {
                    this.slot.Type = 0/*MarshalerType.None*/;
                }
            }
            /*void */ ToManaged$11(/*out byte*/ value)
            {
                if (this.slot.Type === 0/*MarshalerType.None*/)
                {
                    value.$v = 0;
                    return;
                }
                value.$v = this.slot.ByteValue;
            }
            /*void */ ToJS$11(/*byte*/ value)
            {
                this.slot.Type = 4/*MarshalerType.Byte*/;
                this.slot.ByteValue = value;
            }
            /*void */ ToManaged$12(/*out byte?*/ value)
            {
                if (this.slot.Type === 0/*MarshalerType.None*/)
                {
                    value.$v = null;
                    return;
                }
                value.$v = this.slot.ByteValue;
            }
            /*void */ ToJS$12(/*byte?*/ value)
            {
                if ($.$spc.System.Nullable$$($.$spc.System.Byte).HasValue$get.call(value))
                {
                    this.slot.Type = 4/*MarshalerType.Byte*/;
                    this.slot.ByteValue = $.$spc.System.Nullable$$($.$spc.System.Byte).Value$get.call(value);
                }
                else 
                {
                    this.slot.Type = 0/*MarshalerType.None*/;
                }
            }
            /*void */ ToManaged$13(/*out byte[]?*/ value)
            {
                if (this.slot.Type === 0/*MarshalerType.None*/)
                {
                    value.$v = null;
                    return;
                }
                value.$v = $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$spc.System.Byte), null, [this.slot.Length], null);
                $.$spc.System.Runtime.InteropServices.Marshal.Copy$14(this.slot.IntPtrValue, value.$v, 0, this.slot.Length);
                $.$spc.System.Runtime.InteropServices.Marshal.FreeHGlobal(this.slot.IntPtrValue);
            }
            /*void */ ToJS$13(/*byte[]?*/ value)
            {
                if (value === null)
                {
                    this.slot.Type = 0/*MarshalerType.None*/;
                    return;
                }
                this.slot.Length = value.length;
                this.slot.Type = 21/*MarshalerType.Array*/;
                this.slot.IntPtrValue = $.$spc.System.Runtime.InteropServices.Marshal.AllocHGlobal(((value.length * $.$spc.System.Byte.$z) | 0));
                this.slot.ElementType = 4/*MarshalerType.Byte*/;
                $.$spc.System.Runtime.InteropServices.Marshal.Copy$6(value, 0, this.slot.IntPtrValue, this.slot.Length);
            }
            /*void */ ToManaged$14(/*out ArraySegment<byte>*/ value)
            {
                /*var*/ let array = $.$cast(($.$spc.System.Runtime.InteropServices.GCHandle.op_Explicit(this.slot.GCHandle)).Target, $.$typeArray($.$spc.System.Byte));
                /*var*/ let refPtr = $.$spc.System.IntPtr.op_Explicit$2($.$spc.System.Runtime.CompilerServices.Unsafe.AsPointer($.$spc.System.Byte, $.$spc.System.Runtime.InteropServices.MemoryMarshal.GetArrayDataReference($.$spc.System.Byte, array)));
                /*int*/ let byteOffset = (this.slot.IntPtrValue - refPtr);
                value.$v = new ($.$spc.System.ArraySegment$$($.$spc.System.Byte))().$ctor$3(array, byteOffset, this.slot.Length);
            }
            /*void */ ToJS$14(/*ArraySegment<byte>*/ value)
            {
                if (value.Array === null)
                {
                    this.slot.Type = 0/*MarshalerType.None*/;
                    return;
                }
                this.slot.Type = 22/*MarshalerType.ArraySegment*/;
                /*var*/ let ctx = this.ToJSContext;
                this.slot.GCHandle = ctx.GetJSOwnedObjectGCHandle(value.Array, 3/*GCHandleType.Pinned*/);
                /*var*/ let refPtr = $.$spc.System.IntPtr.op_Explicit$2($.$spc.System.Runtime.CompilerServices.Unsafe.AsPointer($.$spc.System.Byte, $.$spc.System.Runtime.InteropServices.MemoryMarshal.GetArrayDataReference($.$spc.System.Byte, value.Array)));
                this.slot.IntPtrValue = refPtr + value.Offset;
                this.slot.Length = value.Count;
            }
            /*void */ ToManaged$15(/*out Span<byte>*/ value)
            {
                value.$v = new ($.$spc.System.Span$$($.$spc.System.Byte))().$ctor$4($.$spc.System.IntPtr.op_Explicit$3(this.slot.IntPtrValue), this.slot.Length);
            }
            /*void */ ToJS$15(/*Span<byte>*/ value)
            {
                this.slot.Length = value.Length;
                this.slot.IntPtrValue = $.$spc.System.IntPtr.op_Explicit$2($.$spc.System.Runtime.CompilerServices.Unsafe.AsPointer($.$spc.System.Byte, value.GetPinnableReference()));
                this.slot.Type = 23/*MarshalerType.Span*/;
            }
            /*void */ ToManaged$16(/*out bool*/ value)
            {
                if (this.slot.Type === 0/*MarshalerType.None*/)
                {
                    value.$v = false;
                    return;
                }
                value.$v = this.slot.BooleanValue;
            }
            /*void */ ToJS$16(/*bool*/ value)
            {
                this.slot.Type = 3/*MarshalerType.Boolean*/;
                this.slot.BooleanValue = value;
            }
            /*void */ ToManaged$17(/*out bool?*/ value)
            {
                if (this.slot.Type === 0/*MarshalerType.None*/)
                {
                    value.$v = null;
                    return;
                }
                value.$v = this.slot.BooleanValue;
            }
            /*void */ ToJS$17(/*bool?*/ value)
            {
                if ($.$spc.System.Nullable$$($.$spc.System.Boolean).HasValue$get.call(value))
                {
                    this.slot.Type = 3/*MarshalerType.Boolean*/;
                    this.slot.BooleanValue = $.$spc.System.Nullable$$($.$spc.System.Boolean).Value$get.call(value);
                }
                else 
                {
                    this.slot.Type = 0/*MarshalerType.None*/;
                }
            }
            /*void */ ToManaged$18(/*out DateTimeOffset*/ value)
            {
                if (this.slot.Type === 0/*MarshalerType.None*/)
                {
                    value.$v = new $.$spc.System.DateTimeOffset();
                    return;
                }
                value.$v = $.$spc.System.DateTimeOffset.FromUnixTimeMilliseconds($.$cast(this.slot.DoubleValue, $.$spc.System.Int64));
            }
            /*void */ ToJS$18(/*DateTimeOffset*/ value)
            {
                this.slot.Type = 18/*MarshalerType.DateTimeOffset*/;
                this.slot.DoubleValue = $.$cast(value.ToUnixTimeMilliseconds(), $.$spc.System.Double);
            }
            /*void */ ToManaged$19(/*out DateTimeOffset?*/ value)
            {
                if (this.slot.Type === 0/*MarshalerType.None*/)
                {
                    value.$v = null;
                    return;
                }
                value.$v = $.$spc.System.DateTimeOffset.FromUnixTimeMilliseconds($.$cast(this.slot.DoubleValue, $.$spc.System.Int64));
            }
            /*void */ ToJS$19(/*DateTimeOffset?*/ value)
            {
                if ($.$spc.System.Nullable$$($.$spc.System.DateTimeOffset).HasValue$get.call(value))
                {
                    this.slot.Type = 18/*MarshalerType.DateTimeOffset*/;
                    this.slot.DoubleValue = Number($.$spc.System.Nullable$$($.$spc.System.DateTimeOffset).Value$get.call(value).ToUnixTimeMilliseconds());
                }
                else 
                {
                    this.slot.Type = 0/*MarshalerType.None*/;
                }
            }
            /*void */ ToManaged$20(/*out DateTime*/ value)
            {
                if (this.slot.Type === 0/*MarshalerType.None*/)
                {
                    value.$v = new $.$spc.System.DateTime();
                    return;
                }
                value.$v = $.$spc.System.DateTimeOffset.FromUnixTimeMilliseconds($.$cast(this.slot.DoubleValue, $.$spc.System.Int64)).UtcDateTime;
            }
            /*void */ ToJS$20(/*DateTime*/ value)
            {
                this.slot.Type = 17/*MarshalerType.DateTime*/;
                this.slot.DoubleValue = Number(new $.$spc.System.DateTimeOffset().$ctor$4(value).ToUnixTimeMilliseconds());
            }
            /*void */ ToManaged$21(/*out DateTime?*/ value)
            {
                if (this.slot.Type === 0/*MarshalerType.None*/)
                {
                    value.$v = null;
                    return;
                }
                value.$v = $.$spc.System.DateTimeOffset.FromUnixTimeMilliseconds($.$cast(this.slot.DoubleValue, $.$spc.System.Int64)).UtcDateTime;
            }
            /*void */ ToJS$21(/*DateTime?*/ value)
            {
                if ($.$spc.System.Nullable$$($.$spc.System.DateTime).HasValue$get.call(value))
                {
                    this.slot.Type = 17/*MarshalerType.DateTime*/;
                    this.slot.DoubleValue = Number(new $.$spc.System.DateTimeOffset().$ctor$4($.$spc.System.Nullable$$($.$spc.System.DateTime).Value$get.call(value)).ToUnixTimeMilliseconds());
                }
                else 
                {
                    this.slot.Type = 0/*MarshalerType.None*/;
                }
            }
            /*void */ ToManaged$22(/*out char*/ value)
            {
                if (this.slot.Type === 0/*MarshalerType.None*/)
                {
                    value.$v = 0;
                    return;
                }
                value.$v = this.slot.CharValue;
            }
            /*void */ ToJS$22(/*char*/ value)
            {
                this.slot.Type = 5/*MarshalerType.Char*/;
                this.slot.CharValue = value;
            }
            /*void */ ToManaged$23(/*out char?*/ value)
            {
                if (this.slot.Type === 0/*MarshalerType.None*/)
                {
                    value.$v = null;
                    return;
                }
                value.$v = this.slot.CharValue;
            }
            /*void */ ToJS$23(/*char?*/ value)
            {
                if ($.$spc.System.Nullable$$($.$spc.System.Char).HasValue$get.call(value))
                {
                    this.slot.Type = 5/*MarshalerType.Char*/;
                    this.slot.CharValue = $.$spc.System.Nullable$$($.$spc.System.Char).Value$get.call(value);
                }
                else 
                {
                    this.slot.Type = 0/*MarshalerType.None*/;
                }
            }
            /*void */ ToManaged$24(/*out Exception?*/ value)
            {
                if (this.slot.Type === 0/*MarshalerType.None*/)
                {
                    value.$v = null;
                    return;
                }
                if (this.slot.Type === 16/*MarshalerType.Exception*/)
                {
                    value.$v = $.$cast(($.$spc.System.Runtime.InteropServices.GCHandle.op_Explicit(this.slot.GCHandle)).Target, $.$spc.System.Exception);
                    return;
                }
                /*JSObject?*/ let jsException = null;
                if (this.slot.JSHandle !== $.$spc.System.IntPtr.Zero)
                {
                    /*var*/ let ctx = this.ToManagedContext;
                    jsException = ctx.CreateCSOwnedProxy(this.slot.JSHandle);
                }
                /*string?*/ let message;
                this.ToManaged$25($.$ref(() => message, ($v) => message = $v, $.$spc.System.String));
                value.$v = new $.$srij.System.Runtime.InteropServices.JavaScript.JSException().$ctor$6(message, jsException);
            }
            /*void */ ToJS$24(/*Exception?*/ value)
            {
                if (value === null)
                {
                    this.slot.Type = 0/*MarshalerType.None*/;
                }
                else 
                {
                    /*Exception*/ let cpy = value;
                    let ae;
                    if ($.$is(cpy, $.$spc.System.AggregateException, { set $v(v){ ae = v; } }) && ae.InnerExceptions.Count === 1)
                    {
                        cpy = ae.InnerExceptions.get_Item(0);
                    }
                    /*var*/ let jse = $.$as(cpy, $.$srij.System.Runtime.InteropServices.JavaScript.JSException);
                    if (jse !== null && jse.jsException !== null)
                    {
                        /*var*/ let jsException = jse.jsException;
                        jsException.AssertNotDisposed();
                        this.slot.Type = 27/*MarshalerType.JSException*/;
                        this.slot.JSHandle = jsException.JSHandle;
                    }
                    else 
                    {
                        this.ToJS$25(cpy.Message);
                        this.slot.Type = 16/*MarshalerType.Exception*/;
                        /*var*/ let ctx = this.ToJSContext;
                        this.slot.GCHandle = ctx.GetJSOwnedObjectGCHandle(cpy, 2);
                    }
                }
            }
            /*void */ ToManaged$25(/*out string?*/ value)
            {
                if (this.slot.Type === 0/*MarshalerType.None*/)
                {
                    value.$v = null;
                    return;
                }
                /*fixed*/ 
                {
                    /*void**/ let argAsRoot = $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateObjectReferenceT($.$spc.System.IntPtr, () => this.slot.IntPtrValue, ($v) => this.slot.IntPtrValue = $v, null);
                    value.$v = $.$spc.System.Runtime.CompilerServices.Unsafe.AsRef($.$spc.System.String, argAsRoot).$v;
                }
            }
            /*void */ ToJS$25(/*string?*/ value)
            {
                if ($.$spc.System.String.op_Equality(value, null))
                {
                    this.slot.Type = 0/*MarshalerType.None*/;
                }
                else 
                {
                    this.slot.Type = 15/*MarshalerType.String*/;
                    /*fixed*/ 
                    {
                        /*IntPtr**/ let argAsRoot = $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateObjectReferenceT($.$spc.System.IntPtr, () => this.slot.IntPtrValue, ($v) => this.slot.IntPtrValue = $v, null);
                        /*string*/ let cpy = value;
                        /*var*/ let currentRoot = $.$cast($.$spc.System.Runtime.CompilerServices.Unsafe.AsPointer($.$spc.System.String, $.$ref(() => cpy, ($v) => cpy = $v, $.$spc.System.String)), $.$typePointer($.$spc.System.IntPtr));
                        argAsRoot.SetAt(currentRoot.GetAt(0), 0);
                    }
                }
            }
            /*void */ ToManaged$26(/*out string?[]?*/ value)
            {
                if (this.slot.Type === 0/*MarshalerType.None*/)
                {
                    value.$v = null;
                    return;
                }
                value.$v = $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$spc.System.String), null, [this.slot.Length], null);
                /*JSMarshalerArgument**/ let payload = $.$cast(this.slot.IntPtrValue, $.$typePointer($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument));
                for(/*int*/ let i = 0; i < this.slot.Length; i++)
                {
                    /*ref JSMarshalerArgument*/ let arg = payload.Add(i);
                    /*string?*/ let val;
                    arg.$v.ToManaged$25($.$ref(() => val, ($v) => val = $v, $.$spc.System.String));
                    $.$spc.System.Array.$WriteT1.call(value.$v, val, i);
                }
                $.$srij.Interop.Runtime.DeregisterGCRoot(this.slot.IntPtrValue);
                $.$spc.System.Runtime.InteropServices.Marshal.FreeHGlobal(this.slot.IntPtrValue);
            }
            /*void */ ToJS$26(/*string?[]*/ value)
            {
                if (value === null)
                {
                    this.slot.Type = 0/*MarshalerType.None*/;
                    return;
                }
                this.slot.Length = value.length;
                /*int*/ let bytes = ((value.length * $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument.$z) | 0);
                this.slot.Type = 21/*MarshalerType.Array*/;
                /*JSMarshalerArgument**/ let payload = $.$cast($.$spc.System.Runtime.InteropServices.Marshal.AllocHGlobal(bytes), $.$typePointer($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument));
                $.$spc.System.Runtime.CompilerServices.Unsafe.InitBlock(payload, 0, (bytes >>> 0));
                $.$srij.Interop.Runtime.RegisterGCRoot(payload, bytes, $.$spc.System.IntPtr.Zero);
                for(/*int*/ let i = 0; i < this.slot.Length; i++)
                {
                    /*ref JSMarshalerArgument*/ let arg = payload.Add(i);
                    /*string?*/ let val = $.$spc.System.Array.$ReadT1.call(value, i);
                    arg.$v.ToJS$25(val);
                    $.$spc.System.Array.$WriteT1.call(value, val, i);
                }
                this.slot.IntPtrValue = $.$cast(payload, $.$spc.System.IntPtr);
                this.slot.ElementType = 15/*MarshalerType.String*/;
            }
            /*void */ ToManaged$27(/*out IntPtr*/ value)
            {
                if (this.slot.Type === 0/*MarshalerType.None*/)
                {
                    value.$v = 0;
                    return;
                }
                value.$v = this.slot.IntPtrValue;
            }
            /*void */ ToJS$27(/*IntPtr*/ value)
            {
                this.slot.Type = 12/*MarshalerType.IntPtr*/;
                this.slot.IntPtrValue = value;
            }
            /*void */ ToManaged$28(/*out IntPtr?*/ value)
            {
                if (this.slot.Type === 0/*MarshalerType.None*/)
                {
                    value.$v = null;
                    return;
                }
                value.$v = this.slot.IntPtrValue;
            }
            /*void */ ToJS$28(/*IntPtr?*/ value)
            {
                if ($.$spc.System.Nullable$$($.$spc.System.IntPtr).HasValue$get.call(value))
                {
                    this.slot.Type = 12/*MarshalerType.IntPtr*/;
                    this.slot.IntPtrValue = $.$spc.System.Nullable$$($.$spc.System.IntPtr).Value$get.call(value);
                }
                else 
                {
                    this.slot.Type = 0/*MarshalerType.None*/;
                }
            }
            /*void */ ToManaged$29(/*out void**/ value)
            {
                if (this.slot.Type === 0/*MarshalerType.None*/)
                {
                    value.$v = new $.$typePointer($.$spc.System.Void)();
                    return;
                }
                value.$v = $.$cast(this.slot.IntPtrValue, $.$typePointer($.$spc.System.Byte));
            }
            /*void */ ToJS$29(/*void**/ value)
            {
                this.slot.Type = 12/*MarshalerType.IntPtr*/;
                this.slot.IntPtrValue = $.$spc.System.IntPtr.op_Explicit$2(value);
            }
            /*void */ ToManaged$30(/*out int*/ value)
            {
                if (this.slot.Type === 0/*MarshalerType.None*/)
                {
                    value.$v = 0;
                    return;
                }
                value.$v = this.slot.Int32Value;
            }
            /*void */ ToJS$30(/*int*/ value)
            {
                this.slot.Type = 7/*MarshalerType.Int32*/;
                this.slot.Int32Value = value;
            }
            /*void */ ToManaged$31(/*out int?*/ value)
            {
                if (this.slot.Type === 0/*MarshalerType.None*/)
                {
                    value.$v = null;
                    return;
                }
                value.$v = this.slot.Int32Value;
            }
            /*void */ ToJS$31(/*int?*/ value)
            {
                if ($.$spc.System.Nullable$$($.$spc.System.Int32).HasValue$get.call(value))
                {
                    this.slot.Type = 7/*MarshalerType.Int32*/;
                    this.slot.Int32Value = $.$spc.System.Nullable$$($.$spc.System.Int32).Value$get.call(value);
                }
                else 
                {
                    this.slot.Type = 0/*MarshalerType.None*/;
                }
            }
            /*void */ ToManaged$32(/*out int[]?*/ value)
            {
                if (this.slot.Type === 0/*MarshalerType.None*/)
                {
                    value.$v = null;
                    return;
                }
                value.$v = $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$spc.System.Int32), null, [this.slot.Length], null);
                $.$spc.System.Runtime.InteropServices.Marshal.Copy$8(this.slot.IntPtrValue, value.$v, 0, this.slot.Length);
                $.$spc.System.Runtime.InteropServices.Marshal.FreeHGlobal(this.slot.IntPtrValue);
            }
            /*void */ ToJS$32(/*int[]?*/ value)
            {
                if (value === null)
                {
                    this.slot.Type = 0/*MarshalerType.None*/;
                    return;
                }
                this.slot.Type = 21/*MarshalerType.Array*/;
                this.slot.IntPtrValue = $.$spc.System.Runtime.InteropServices.Marshal.AllocHGlobal(((value.length * $.$spc.System.Int32.$z) | 0));
                this.slot.Length = value.length;
                this.slot.ElementType = 7/*MarshalerType.Int32*/;
                $.$spc.System.Runtime.InteropServices.Marshal.Copy(value, 0, this.slot.IntPtrValue, this.slot.Length);
            }
            /*void */ ToManaged$33(/*out ArraySegment<int>*/ value)
            {
                /*var*/ let array = $.$cast(($.$spc.System.Runtime.InteropServices.GCHandle.op_Explicit(this.slot.GCHandle)).Target, $.$typeArray($.$spc.System.Int32));
                /*var*/ let refPtr = $.$spc.System.IntPtr.op_Explicit$2($.$spc.System.Runtime.CompilerServices.Unsafe.AsPointer($.$spc.System.Int32, $.$spc.System.Runtime.InteropServices.MemoryMarshal.GetArrayDataReference($.$spc.System.Int32, array)));
                /*int*/ let byteOffset = (this.slot.IntPtrValue - refPtr);
                value.$v = new ($.$spc.System.ArraySegment$$($.$spc.System.Int32))().$ctor$3(array, $.trunc(byteOffset / $.$spc.System.Int32.$z), this.slot.Length);
            }
            /*void */ ToJS$33(/*ArraySegment<int>*/ value)
            {
                if (value.Array === null)
                {
                    this.slot.Type = 0/*MarshalerType.None*/;
                    return;
                }
                /*var*/ let ctx = this.ToJSContext;
                this.slot.Type = 22/*MarshalerType.ArraySegment*/;
                this.slot.GCHandle = ctx.GetJSOwnedObjectGCHandle(value.Array, 3/*GCHandleType.Pinned*/);
                /*var*/ let refPtr = $.$spc.System.IntPtr.op_Explicit$2($.$spc.System.Runtime.CompilerServices.Unsafe.AsPointer($.$spc.System.Int32, $.$spc.System.Runtime.InteropServices.MemoryMarshal.GetArrayDataReference($.$spc.System.Int32, value.Array)));
                this.slot.IntPtrValue = refPtr + (((value.Offset * $.$spc.System.Int32.$z) | 0));
                this.slot.Length = value.Count;
            }
            /*void */ ToManaged$34(/*out Span<int>*/ value)
            {
                value.$v = new ($.$spc.System.Span$$($.$spc.System.Int32))().$ctor$4($.$spc.System.IntPtr.op_Explicit$3(this.slot.IntPtrValue), this.slot.Length);
            }
            /*void */ ToJS$34(/*Span<int>*/ value)
            {
                this.slot.Length = value.Length;
                this.slot.IntPtrValue = $.$spc.System.IntPtr.op_Explicit$2($.$spc.System.Runtime.CompilerServices.Unsafe.AsPointer($.$spc.System.Int32, value.GetPinnableReference()));
                this.slot.Type = 23/*MarshalerType.Span*/;
            }
            /*void */ ToManaged$35(/*out JSObject?*/ value)
            {
                if (this.slot.Type === 0/*MarshalerType.None*/)
                {
                    value.$v = null;
                    return;
                }
                /*var*/ let ctx = this.ToManagedContext;
                value.$v = ctx.CreateCSOwnedProxy(this.slot.JSHandle);
            }
            /*void */ ToJS$35(/*JSObject?*/ value)
            {
                if (value === null)
                {
                    this.slot.Type = 0/*MarshalerType.None*/;
                }
                else 
                {
                    value.AssertNotDisposed();
                    this.slot.Type = 13/*MarshalerType.JSObject*/;
                    this.slot.JSHandle = value.JSHandle;
                }
            }
            /*void */ ToManaged$36(/*out JSObject?[]?*/ value)
            {
                if (this.slot.Type === 0/*MarshalerType.None*/)
                {
                    value.$v = null;
                    return;
                }
                value.$v = $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$srij.System.Runtime.InteropServices.JavaScript.JSObject), null, [this.slot.Length], null);
                /*JSMarshalerArgument**/ let payload = $.$cast(this.slot.IntPtrValue, $.$typePointer($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument));
                for(/*int*/ let i = 0; i < this.slot.Length; i++)
                {
                    /*ref JSMarshalerArgument*/ let arg = payload.Add(i);
                    /*JSObject?*/ let val;
                    arg.$v.ToManaged$35($.$ref(() => val, ($v) => val = $v, $.$srij.System.Runtime.InteropServices.JavaScript.JSObject));
                    $.$spc.System.Array.$WriteT1.call(value.$v, val, i);
                }
                $.$spc.System.Runtime.InteropServices.Marshal.FreeHGlobal(this.slot.IntPtrValue);
            }
            /*void */ ToJS$36(/*JSObject?[]*/ value)
            {
                if (value === null)
                {
                    this.slot.Type = 0/*MarshalerType.None*/;
                    return;
                }
                this.slot.Length = value.length;
                /*int*/ let bytes = ((value.length * $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument.$z) | 0);
                this.slot.Type = 21/*MarshalerType.Array*/;
                this.slot.ElementType = 13/*MarshalerType.JSObject*/;
                /*JSMarshalerArgument**/ let payload = $.$cast($.$spc.System.Runtime.InteropServices.Marshal.AllocHGlobal(bytes), $.$typePointer($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument));
                $.$spc.System.Runtime.CompilerServices.Unsafe.InitBlock(payload, 0, (bytes >>> 0));
                for(/*int*/ let i = 0; i < this.slot.Length; i++)
                {
                    /*ref JSMarshalerArgument*/ let arg = payload.Add(i);
                    /*JSObject?*/ let val = $.$spc.System.Array.$ReadT1.call(value, i);
                    arg.$v.ToJS$35(val);
                    $.$spc.System.Array.$WriteT1.call(value, val, i);
                }
                this.slot.IntPtrValue = $.$cast(payload, $.$spc.System.IntPtr);
            }
            static $_ArgumentToManagedCallback$$;
            static ArgumentToManagedCallback$$(T)
            {
                let $cls = $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument;
                return ($cls.$_ArgumentToManagedCallback$$ ??= $asm.$ncls("$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument.ArgumentToManagedCallback<>", (T) => $asm.$gt("$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument.ArgumentToManagedCallback<>", [T], ($self) => class ArgumentToManagedCallback$$ extends $.$spc.System.MulticastDelegate
                {
                    $ctor(/*object*/ target, fn, anmodel)
                    {
                        this.$target = target;
                        this.$nativeFunction = fn;
                        if (anmodel) this.$nfmodel = anmodel;
                        if (typeof(target) === 'object') this._target = target;
                        return this;
                    }
                    /*void*/ Invoke(/**/ arg, /**/ value)
                    {
                        return this.$nativeFunction.call(this.$target, arg, value);
                    }
                    static $h = 1764745;
                    static $g = 1;
                    static $f = 0b10000000011000001;
                    static $k = 5;
                    static $$md;
                    static get $md() { return this.$$md ??= {"b":66191361,"m":[{"r":65537,"p":[{"n":"arg","p":1371529,"f":4},{"n":"value","p":T?.$h??1507328,"f":2}],"n":"Invoke","d":this.$h,"h":Number(BigInt(this.$h)|0x200000000n),"f":129},{"r":57016321,"p":[{"n":"arg","p":1371529,"f":4},{"n":"value","p":T?.$h??1507328,"f":2},{"n":"callback","p":14483457},{"n":"object","p":131073}],"n":"BeginInvoke","d":this.$h,"h":Number(BigInt(this.$h)|0x300000000n),"f":129},{"r":65537,"p":[{"n":"arg","p":1371529,"f":4},{"n":"value","p":T?.$h??1507328,"f":2},{"n":"result","p":57016321}],"n":"EndInvoke","d":this.$h,"h":Number(BigInt(this.$h)|0x400000000n),"f":129}],"c":[{"p":[{"n":"object","p":131073},{"n":"method","p":786433}],"n":".ctor","o":"$ctor$5","d":this.$h,"h":Number(BigInt(this.$h)|0x100000000n),"f":1}],"i":[57212929,113377281],"g":[T?.$h??1507328],"r":1,"d":1371529,"h":this.$h,"a":[{"t":33226753,"c":4328194049,"a":[{"v":1,"t":33292289}]}]}; }
                    static get $b() { return $.$spc.System.MulticastDelegate; }
                    static $$i;
                    static get $i() { return this.$$i ??= [ $.$spc.System.ICloneable, $.$spc.System.Runtime.Serialization.ISerializable ]; }
                    static get $fullName() { return `System.Runtime.InteropServices.JavaScript.JSMarshalerArgument.ArgumentToManagedCallback<${T?.$fullName}>`; }
                }), $cls, ($v) => $cls.$_ArgumentToManagedCallback$$ = $v))(T);
            }
            static $_ArgumentToJSCallback$$;
            static ArgumentToJSCallback$$(T)
            {
                let $cls = $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument;
                return ($cls.$_ArgumentToJSCallback$$ ??= $asm.$ncls("$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument.ArgumentToJSCallback<>", (T) => $asm.$gt("$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument.ArgumentToJSCallback<>", [T], ($self) => class ArgumentToJSCallback$$ extends $.$spc.System.MulticastDelegate
                {
                    $ctor(/*object*/ target, fn, anmodel)
                    {
                        this.$target = target;
                        this.$nativeFunction = fn;
                        if (anmodel) this.$nfmodel = anmodel;
                        if (typeof(target) === 'object') this._target = target;
                        return this;
                    }
                    /*void*/ Invoke(/**/ arg, /**/ value)
                    {
                        return this.$nativeFunction.call(this.$target, arg, value);
                    }
                    static $h = 1699209;
                    static $g = 1;
                    static $f = 0b10000000011000001;
                    static $k = 5;
                    static $$md;
                    static get $md() { return this.$$md ??= {"b":66191361,"m":[{"r":65537,"p":[{"n":"arg","p":1371529,"f":4},{"n":"value","p":T?.$h??1507328}],"n":"Invoke","d":this.$h,"h":Number(BigInt(this.$h)|0x200000000n),"f":129},{"r":57016321,"p":[{"n":"arg","p":1371529,"f":4},{"n":"value","p":T?.$h??1507328},{"n":"callback","p":14483457},{"n":"object","p":131073}],"n":"BeginInvoke","d":this.$h,"h":Number(BigInt(this.$h)|0x300000000n),"f":129},{"r":65537,"p":[{"n":"arg","p":1371529,"f":4},{"n":"result","p":57016321}],"n":"EndInvoke","d":this.$h,"h":Number(BigInt(this.$h)|0x400000000n),"f":129}],"c":[{"p":[{"n":"object","p":131073},{"n":"method","p":786433}],"n":".ctor","o":"$ctor$5","d":this.$h,"h":Number(BigInt(this.$h)|0x100000000n),"f":1}],"i":[57212929,113377281],"g":[T?.$h??1507328],"r":1,"d":1371529,"h":this.$h,"a":[{"t":33226753,"c":4328194049,"a":[{"v":1,"t":33292289}]}]}; }
                    static get $b() { return $.$spc.System.MulticastDelegate; }
                    static $$i;
                    static get $i() { return this.$$i ??= [ $.$spc.System.ICloneable, $.$spc.System.Runtime.Serialization.ISerializable ]; }
                    static get $fullName() { return `System.Runtime.InteropServices.JavaScript.JSMarshalerArgument.ArgumentToJSCallback<${T?.$fullName}>`; }
                }), $cls, ($v) => $cls.$_ArgumentToJSCallback$$ = $v))(T);
            }
            /*void */ ToManaged$37(/*out Task?*/ value)
            {
                if (this.slot.Type === 0/*MarshalerType.None*/)
                {
                    value.$v = null;
                    return;
                }
                /*var*/ let ctx = this.ToManagedContext;
                {
                    /*PromiseHolder*/ let holder = ctx.GetPromiseHolder(this.slot.GCHandle);
                    /*TaskCompletionSource*/ let tcs = new $.$spc.System.Threading.Tasks.TaskCompletionSource().$ctor$4(holder, 64/*TaskCreationOptions.RunContinuationsAsynchronously*/);
                    /*ToManagedCallback*/ let callback = new $.$srij.System.Runtime.InteropServices.JavaScript.JSHostImplementation.ToManagedCallback().$ctor(this,  (/*JSMarshalerArgument**/ arguments_buffer) =>
                    {
                        if (arguments_buffer === null)
                        {
                            if (!tcs.TrySetException(new $.$spc.System.Threading.Tasks.TaskCanceledException().$ctor$17("WebWorker which is origin of the Promise is being terminated.")))
                            {
                                $.$spc.System.Environment.FailFast("Failed to set exception to TaskCompletionSource (arguments buffer is null)");
                            }
                            return;
                        }
                        /*ref JSMarshalerArgument*/ let arg_2 = arguments_buffer.Add(3);
                        if (arg_2.$v.slot.Type !== 0/*MarshalerType.None*/)
                        {
                            /*Exception?*/ let fail;
                            arg_2.$v.ToManaged$24($.$ref(() => fail, ($v) => fail = $v, $.$spc.System.Exception));
                            if (!tcs.TrySetException(fail))
                            {
                                $.$spc.System.Environment.FailFast("Failed to set exception to TaskCompletionSource (exception raised)");
                            }
                        }
                        else 
                        {
                            if (!tcs.TrySetResult())
                            {
                                $.$spc.System.Environment.FailFast("Failed to set result to TaskCompletionSource (marshaler type is none)");
                            }
                        }
                    }, {"r":65537,"p":[{"n":"arguments_buffer","p":0}],"n":"","d":1371529,"h":0,"f":1048578});
                    holder.Callback = callback;
                    value.$v = tcs.Task;
                }
            }
            /*void */ ToManaged$38(T, /*out Task<T>?*/ value, /*ArgumentToManagedCallback<T>*/ marshaler)
            {
                if (this.slot.Type === 0/*MarshalerType.None*/)
                {
                    value.$v = null;
                    return;
                }
                /*var*/ let ctx = this.ToManagedContext;
                {
                    /*var*/ let holder = ctx.GetPromiseHolder(this.slot.GCHandle);
                    /*TaskCompletionSource<T>*/ let tcs = new ($.$spc.System.Threading.Tasks.TaskCompletionSource$$(T))().$ctor$4(holder, 64/*TaskCreationOptions.RunContinuationsAsynchronously*/);
                    /*ToManagedCallback*/ let callback = new $.$srij.System.Runtime.InteropServices.JavaScript.JSHostImplementation.ToManagedCallback().$ctor(this,  (/*JSMarshalerArgument**/ arguments_buffer) =>
                    {
                        if (arguments_buffer === null)
                        {
                            if (!tcs.TrySetException(new $.$spc.System.Threading.Tasks.TaskCanceledException().$ctor$17("WebWorker which is origin of the Promise is being terminated.")))
                            {
                                $.$spc.System.Environment.FailFast("Failed to set exception to TaskCompletionSource (arguments buffer is null)");
                            }
                            return;
                        }
                        /*ref JSMarshalerArgument*/ let arg_2 = arguments_buffer.Add(3);
                        /*ref JSMarshalerArgument*/ let arg_3 = arguments_buffer.Add(4);
                        if (arg_2.$v.slot.Type !== 0/*MarshalerType.None*/)
                        {
                            /*Exception?*/ let fail;
                            arg_2.$v.ToManaged$24($.$ref(() => fail, ($v) => fail = $v, $.$spc.System.Exception));
                            if (fail === null)
                            {
                                throw new $.$spc.System.InvalidOperationException().$ctor$10($.$srij.System.SR.FailedToMarshalException);
                            }
                            if (!tcs.TrySetException(fail))
                            {
                                $.$spc.System.Environment.FailFast("Failed to set exception to TaskCompletionSource (exception raised)");
                            }
                        }
                        else 
                        {
                            /*T*/ let result;
                            marshaler.Invoke(arg_3, $.$ref(() => result, ($v) => result = $v, T));
                            if (!tcs.TrySetResult(result))
                            {
                                $.$spc.System.Environment.FailFast("Failed to set result to TaskCompletionSource (marshaler type is none)");
                            }
                        }
                    }, {"r":65537,"p":[{"n":"arguments_buffer","p":0}],"n":"","d":1371529,"h":0,"f":1048578});
                    holder.Callback = callback;
                    value.$v = tcs.Task;
                }
            }
            /*void */ ToJSDynamic(/*Task?*/ value)
            {
                /*Task?*/ let task = value;
                /*var*/ let ctx = this.ToJSContext;
                /*var*/ let canMarshalTaskResultOnSameCall = this.CanMarshalTaskResultOnSameCall(ctx);
                if (task === null)
                {
                    if (!canMarshalTaskResultOnSameCall)
                    {
                        $.$spc.System.Environment.FailFast("Marshalling null return Task to JS is not supported in MT");
                    }
                    this.slot.Type = 0/*MarshalerType.None*/;
                    return;
                }
                if (canMarshalTaskResultOnSameCall && task.IsCompleted)
                {
                    if (task.Exception !== null)
                    {
                        /*Exception*/ let ex = task.Exception;
                        this.ToJS$24(ex);
                        this.slot.ElementType = this.slot.Type;
                        this.slot.Type = 29/*MarshalerType.TaskRejected*/;
                        return;
                    }
                    else 
                    {
                        /*object?*/ let result;
                        if ($.$srij.System.Runtime.InteropServices.JavaScript.JSHostImplementation.GetTaskResultDynamic(task, $.$ref(() => result, ($v) => result = $v, $.$spc.System.Object)))
                        {
                            this.ToJS$47(result);
                            this.slot.ElementType = this.slot.Type;
                        }
                        else 
                        {
                            this.slot.ElementType = 1/*MarshalerType.Void*/;
                        }
                        this.slot.Type = 28/*MarshalerType.TaskResolved*/;
                        return;
                    }
                }
                if (this.slot.Type !== 30/*MarshalerType.TaskPreCreated*/)
                {
                    this.slot.JSHandle = ctx.AllocJSVHandle();
                    this.slot.Type = 20/*MarshalerType.Task*/;
                }
                else 
                {
                }
                /*var*/ let taskHolder = ctx.CreateCSOwnedProxy(this.slot.JSHandle);
                task.ContinueWith$8(new ($.$spc.System.Action$$$($.$spc.System.Threading.Tasks.Task, $.$spc.System.Object))().$ctor($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument, Complete), taskHolder, $.$spc.System.Threading.Tasks.TaskScheduler.Current);
                /*static void*/  function Complete(/*Task*/ task, /*object?*/ th)
                {
                    /*var*/ let taskHolderArg = $.$cast(th, $.$srij.System.Runtime.InteropServices.JavaScript.JSObject);
                    if (task.Exception !== null)
                    {
                        $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument.RejectPromise(taskHolderArg, task.Exception);
                    }
                    else 
                    {
                        /*object?*/ let result;
                        if ($.$srij.System.Runtime.InteropServices.JavaScript.JSHostImplementation.GetTaskResultDynamic(task, $.$ref(() => result, ($v) => result = $v, $.$spc.System.Object)))
                        {
                            $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument.ResolvePromise($.$spc.System.Object, taskHolderArg, result, new ($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument.ArgumentToJSCallback$$($.$spc.System.Object))().$ctor($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument, MarshalResult));
                        }
                        else 
                        {
                            $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument.ResolveVoidPromise(taskHolderArg);
                        }
                    }
                }
                /*static void*/  function MarshalResult(/*ref JSMarshalerArgument*/ arg, /*object?*/ taskResult)
                {
                    arg.$v.ToJS$47(taskResult);
                }
            }
            /*void */ ToJS$37(/*Task?*/ value)
            {
                /*Task?*/ let task = value;
                /*var*/ let ctx = this.ToJSContext;
                /*var*/ let canMarshalTaskResultOnSameCall = this.CanMarshalTaskResultOnSameCall(ctx);
                if (task === null)
                {
                    if (!canMarshalTaskResultOnSameCall)
                    {
                        $.$spc.System.Environment.FailFast("Marshalling null return Task to JS is not supported in MT");
                    }
                    this.slot.Type = 0/*MarshalerType.None*/;
                    return;
                }
                if (canMarshalTaskResultOnSameCall && task.IsCompleted)
                {
                    if (task.Exception !== null)
                    {
                        /*Exception*/ let ex = task.Exception;
                        this.ToJS$24(ex);
                        this.slot.ElementType = this.slot.Type;
                        this.slot.Type = 29/*MarshalerType.TaskRejected*/;
                        return;
                    }
                    else 
                    {
                        this.slot.ElementType = 1/*MarshalerType.Void*/;
                        this.slot.Type = 28/*MarshalerType.TaskResolved*/;
                        return;
                    }
                }
                if (this.slot.Type !== 30/*MarshalerType.TaskPreCreated*/)
                {
                    this.slot.JSHandle = ctx.AllocJSVHandle();
                    this.slot.Type = 20/*MarshalerType.Task*/;
                }
                else 
                {
                }
                /*var*/ let taskHolder = ctx.CreateCSOwnedProxy(this.slot.JSHandle);
                task.ContinueWith$8(new ($.$spc.System.Action$$$($.$spc.System.Threading.Tasks.Task, $.$spc.System.Object))().$ctor($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument, Complete), taskHolder, $.$spc.System.Threading.Tasks.TaskScheduler.Current);
                /*static void*/  function Complete(/*Task*/ task, /*object?*/ th)
                {
                    /*JSObject*/ let taskHolderArg = $.$cast(th, $.$srij.System.Runtime.InteropServices.JavaScript.JSObject);
                    if (task.Exception !== null)
                    {
                        $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument.RejectPromise(taskHolderArg, task.Exception);
                    }
                    else 
                    {
                        $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument.ResolveVoidPromise(taskHolderArg);
                    }
                }
            }
            /*void */ ToJS$38(T, /*Task<T>?*/ value, /*ArgumentToJSCallback<T>*/ marshaler)
            {
                /*Task<T>?*/ let task = value;
                /*var*/ let ctx = this.ToJSContext;
                /*var*/ let canMarshalTaskResultOnSameCall = this.CanMarshalTaskResultOnSameCall(ctx);
                if (task === null)
                {
                    if (!canMarshalTaskResultOnSameCall)
                    {
                        $.$spc.System.Environment.FailFast("Marshalling null return Task to JS is not supported in MT");
                    }
                    this.slot.Type = 0/*MarshalerType.None*/;
                    return;
                }
                if (canMarshalTaskResultOnSameCall && task.IsCompleted)
                {
                    if (task.Exception !== null)
                    {
                        /*Exception*/ let ex = task.Exception;
                        this.ToJS$24(ex);
                        this.slot.ElementType = this.slot.Type;
                        this.slot.Type = 29/*MarshalerType.TaskRejected*/;
                        return;
                    }
                    else 
                    {
                        /*T*/ let result = task.Result;
                        this.ToJS$47($.$box(result, T));
                        this.slot.ElementType = this.slot.Type;
                        this.slot.Type = 28/*MarshalerType.TaskResolved*/;
                        return;
                    }
                }
                if (this.slot.Type !== 30/*MarshalerType.TaskPreCreated*/)
                {
                    this.slot.JSHandle = ctx.AllocJSVHandle();
                    this.slot.Type = 20/*MarshalerType.Task*/;
                }
                else 
                {
                }
                /*var*/ let taskHolder = ctx.CreateCSOwnedProxy(this.slot.JSHandle);
                task.ContinueWith$32(new ($.$spc.System.Action$$$($.$spc.System.Threading.Tasks.Task$$(T), $.$spc.System.Object))().$ctor($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument, Complete), new ($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument.HolderAndMarshaler$$(T))().$ctor$1(taskHolder, marshaler), $.$spc.System.Threading.Tasks.TaskScheduler.Current);
                /*static void*/  function Complete(/*Task<T>*/ task, /*object?*/ thm)
                {
                    /*var*/ let hm = $.$cast(thm, $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument.HolderAndMarshaler$$(T));
                    if (task.Exception !== null)
                    {
                        $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument.RejectPromise(hm.TaskHolder, task.Exception);
                    }
                    else 
                    {
                        /*T*/ let result = task.Result;
                        $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument.ResolvePromise(T, hm.TaskHolder, result, hm.Marshaler);
                    }
                }
            }
            /*bool */ CanMarshalTaskResultOnSameCall(/*JSProxyContext*/ _)
            {
                return true;
            }
            static $_HolderAndMarshaler$$;
            static HolderAndMarshaler$$(T)
            {
                let $cls = $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument;
                return ($cls.$_HolderAndMarshaler$$ ??= $asm.$ncls("$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument.HolderAndMarshaler<>", (T) => $asm.$gt("$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument.HolderAndMarshaler<>", [T], ($self) => class HolderAndMarshaler$$ extends $.$spc.System.Object
                {
                    //Generated interface implemetation for System.IEquatable<System.Runtime.InteropServices.JavaScript.JSMarshalerArgument.HolderAndMarshaler<T>>.Equals(System.Runtime.InteropServices.JavaScript.JSMarshalerArgument.HolderAndMarshaler<T>?)
                    System$IEquatable$$$Equals()
                    {
                        return this.Equals$2(...arguments);
                    }
                    Clone($copy)
                    {
                        let copy = $copy ?? new this.constructor();
                        copy.TaskHolder = this.TaskHolder;
                        copy.Marshaler = this.Marshaler;
                        return copy;
                    }
                    //Begin primary constructor
                    /*JSObject*/ TaskHolder = null;
                    /*ArgumentToJSCallback<T>*/ Marshaler = null;
                    $ctor$1(/*JSObject*/$TaskHolder, /*ArgumentToJSCallback<T>*/$Marshaler)
                    {
                        this.TaskHolder = $TaskHolder;
                        this.Marshaler = $Marshaler;
                        return this
                    }
                    //End primary constructor
                    //Begin generated record members
                    /*Type*/ get EqualityContract() { return $.$typeOf($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument.HolderAndMarshaler$$(T)); }
                    /*string*/ ToString()
                    {
                        let stringBuilder = new $.$spc.System.Text.StringBuilder().$ctor$1();
                        stringBuilder.Append$2("HolderAndMarshaler");
                        stringBuilder.Append$2("{");
                        if (this.PrintMembers(stringBuilder))
                        {
                            stringBuilder.Append$2(" ");
                        }
                        stringBuilder.Append$2("}");
                        return $.$spc.System.Text.StringBuilder.ToString.call(stringBuilder);
                    }
                    /*bool*/ PrintMembers(/*StringBuilder*/ stringBuilder)
                    {
                        stringBuilder.Append$2("TaskHolder = ");
                        stringBuilder.Append$2($.$srij.System.Runtime.InteropServices.JavaScript.JSObject.ToString.call(this.TaskHolder));
                        stringBuilder.Append$2(", ");
                        stringBuilder.Append$2("Marshaler = ");
                        stringBuilder.Append$2($.$spc.System.Object.ToString.call(this.Marshaler));
                        return true;
                    }
                    /*bool*/ Equals$2(/*HolderAndMarshaler*/ other)
                    {
                        return this === other || (other !== null && this.EqualityContract == other.EqualityContract && $.$spc.System.Collections.Generic.EqualityComparer$$($.$srij.System.Runtime.InteropServices.JavaScript.JSObject).Default.Equals$2(this.TaskHolder, other.TaskHolder) && $.$spc.System.Collections.Generic.EqualityComparer$$($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument.ArgumentToJSCallback$$(T)).Default.Equals$2(this.Marshaler, other.Marshaler));
                    }
                    /*int*/ GetHashCode()
                    {
                        return $.$spc.System.Collections.Generic.EqualityComparer$$($.$spc.System.Type).Default.GetHashCode$1(this.EqualityContract) * -1521134295 && $.$spc.System.Collections.Generic.EqualityComparer$$($.$srij.System.Runtime.InteropServices.JavaScript.JSObject).Default.GetHashCode$1(this.TaskHolder) * -1521134295 && $.$spc.System.Collections.Generic.EqualityComparer$$($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument.ArgumentToJSCallback$$(T)).Default.GetHashCode$1(this.Marshaler) * -1521134295;
                    }
                    static /*bool*/ op_InEquality(/*HolderAndMarshaler*/ left, /*HolderAndMarshaler*/ right)
                    {
                        return !(this.op_Equals(left, right));
                    }
                    static /*bool*/ op_Equality(/*HolderAndMarshaler*/ left, /*HolderAndMarshaler*/ right)
                    {
                        return left === right || (left !== null && left.Equals$2(right));
                    }
                    Deconstruct(/*out System.Runtime.InteropServices.JavaScript.JSObject*/ $TaskHolder, /*out System.Runtime.InteropServices.JavaScript.JSMarshalerArgument.ArgumentToJSCallback<T>*/ $Marshaler)
                    {
                        $TaskHolder.$v = this.TaskHolder;
                        $Marshaler.$v = this.Marshaler;
                    }
                    //End generated record member3s
                    static $h = 2092425;
                    static $g = 1;
                    static $f = 0b10000000011010000;
                    static $k = 1;
                    static $$md;
                    static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":142606337,"g":{"r":0,"d":0,"h":Number(BigInt(this.$h)|0x200000000n),"f":2},"n":"EqualityContract","d":this.$h,"h":Number(BigInt(this.$h)|0x300000000n),"f":2},{"p":2289033,"g":{"r":0,"d":0,"h":Number(BigInt(this.$h)|0x500000000n),"f":1},"s":{"r":0,"d":0,"h":Number(BigInt(this.$h)|0x600000000n),"f":1},"n":"TaskHolder","d":this.$h,"h":Number(BigInt(this.$h)|0x700000000n),"f":1},{"p":$.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument.ArgumentToJSCallback$$(T).$h,"g":{"r":0,"d":0,"h":Number(BigInt(this.$h)|0x900000000n),"f":1},"s":{"r":0,"d":0,"h":Number(BigInt(this.$h)|0xA00000000n),"f":1},"n":"Marshaler","d":this.$h,"h":Number(BigInt(this.$h)|0xB00000000n),"f":1}],"m":[{"r":1310721,"n":"ToString","d":this.$h,"h":Number(BigInt(this.$h)|0xC00000000n),"f":32769},{"r":262145,"p":[{"n":"builder","p":122945537}],"n":"PrintMembers","d":this.$h,"h":Number(BigInt(this.$h)|0xD00000000n),"f":2},{"r":655361,"n":"GetHashCode","d":this.$h,"h":Number(BigInt(this.$h)|0x1000000000n),"f":32769},{"r":262145,"p":[{"n":"obj","p":131073}],"n":"Equals","d":this.$h,"h":Number(BigInt(this.$h)|0x1100000000n),"f":32769},{"r":262145,"p":[{"n":"other","p":this.$h}],"n":"Equals","o":"@$2","d":this.$h,"h":Number(BigInt(this.$h)|0x1200000000n),"f":1},{"r":this.$h,"n":"\u003CClone\u003E$","o":"$$$","d":this.$h,"h":Number(BigInt(this.$h)|0x1300000000n),"f":1},{"r":65537,"p":[{"n":"TaskHolder","p":2289033,"f":2},{"n":"Marshaler","p":$.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument.ArgumentToJSCallback$$(T).$h,"f":2}],"n":"Deconstruct","d":this.$h,"h":Number(BigInt(this.$h)|0x1500000000n),"f":1}],"c":[{"p":[{"n":"TaskHolder","p":2289033},{"n":"Marshaler","p":$.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument.ArgumentToJSCallback$$(T).$h}],"n":".ctor","o":"$ctor$1","d":this.$h,"h":Number(BigInt(this.$h)|0x100000000n),"f":1},{"p":[{"n":"original","p":this.$h}],"n":".ctor","o":"$ctor$2","d":this.$h,"h":Number(BigInt(this.$h)|0x1400000000n),"f":2}],"i":[$.$spc.System.IEquatable$$($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument.HolderAndMarshaler$$(T)).$h],"g":[T?.$h??1507328],"r":1,"d":1371529,"h":this.$h}; }
                    static get $b() { return $.$spc.System.Object; }
                    static $$i;
                    static get $i() { return this.$$i ??= [ $.$spc.System.IEquatable$$($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument.HolderAndMarshaler$$(T)) ]; }
                    static get $fullName() { return `System.Runtime.InteropServices.JavaScript.JSMarshalerArgument.HolderAndMarshaler<${T?.$fullName}>`; }
                }), $cls, ($v) => $cls.$_HolderAndMarshaler$$ = $v))(T);
            }
            static /*void */ RejectPromise(/*JSObject*/ holder, /*Exception*/ ex)
            {
                holder.AssertNotDisposed();
                /*Span<JSMarshalerArgument>*/ let args = $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.StackAllocSpan($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument, 4, null);
                /*ref JSMarshalerArgument*/ let exc = args.get_Item(0);
                /*ref JSMarshalerArgument*/ let res = args.get_Item(1);
                /*ref JSMarshalerArgument*/ let arg_handle = args.get_Item(2);
                /*ref JSMarshalerArgument*/ let arg_value = args.get_Item(3);
                exc.$v.Initialize();
                res.$v.Initialize();
                arg_handle.$v.slot.Type = 29/*MarshalerType.TaskRejected*/;
                arg_handle.$v.slot.JSHandle = holder.JSHandle;
                arg_value.$v.ToJS$24(ex);
                holder.DisposeImpl(true);
                $.$srij.System.Runtime.InteropServices.JavaScript.JSFunctionBinding.ResolveOrRejectPromise(holder.ProxyContext, args);
            }
            static /*void */ ResolveVoidPromise(/*JSObject*/ holder)
            {
                holder.AssertNotDisposed();
                /*Span<JSMarshalerArgument>*/ let args = $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.StackAllocSpan($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument, 4, null);
                /*ref JSMarshalerArgument*/ let exc = args.get_Item(0);
                /*ref JSMarshalerArgument*/ let res = args.get_Item(1);
                /*ref JSMarshalerArgument*/ let arg_handle = args.get_Item(2);
                /*ref JSMarshalerArgument*/ let arg_value = args.get_Item(3);
                exc.$v.Initialize();
                res.$v.Initialize();
                arg_handle.$v.slot.Type = 28/*MarshalerType.TaskResolved*/;
                arg_handle.$v.slot.JSHandle = holder.JSHandle;
                arg_value.$v.slot.Type = 1/*MarshalerType.Void*/;
                holder.DisposeImpl(true);
                $.$srij.System.Runtime.InteropServices.JavaScript.JSFunctionBinding.ResolveOrRejectPromise(holder.ProxyContext, args);
            }
            static /*void */ ResolvePromise(T, /*JSObject*/ holder, /*T*/ value, /*ArgumentToJSCallback<T>*/ marshaler)
            {
                holder.AssertNotDisposed();
                /*Span<JSMarshalerArgument>*/ let args = $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.StackAllocSpan($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument, 4, null);
                /*ref JSMarshalerArgument*/ let exc = args.get_Item(0);
                /*ref JSMarshalerArgument*/ let res = args.get_Item(1);
                /*ref JSMarshalerArgument*/ let arg_handle = args.get_Item(2);
                /*ref JSMarshalerArgument*/ let arg_value = args.get_Item(3);
                exc.$v.Initialize();
                res.$v.Initialize();
                arg_handle.$v.slot.Type = 28/*MarshalerType.TaskResolved*/;
                arg_handle.$v.slot.JSHandle = holder.JSHandle;
                marshaler.Invoke(arg_value, value);
                holder.DisposeImpl(true);
                $.$srij.System.Runtime.InteropServices.JavaScript.JSFunctionBinding.ResolveOrRejectPromise(holder.ProxyContext, args);
            }
            static $_ActionJS;
            static get ActionJS()
            {
                let $cls = $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument;
                return $cls.$_ActionJS ??= $asm.$ncls("$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument.ActionJS", ($self) => class ActionJS extends $.$spc.System.Object
                {
                    /*JSObject*/ JSObject = null;
                    $ctor$1(/*JSObject*/ holder)
                    {
                        super.$ctor();
                        {
                            this.JSObject = holder;
                        }
                        return this;
                    }
                    /*void */ InvokeJS()
                    {
                        /*Span<JSMarshalerArgument>*/ let $arguments = $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.StackAllocSpan($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument, 2, null);
                        /*ref JSMarshalerArgument*/ let args_exception = $arguments.get_Item(0);
                        /*ref JSMarshalerArgument*/ let args_return = $arguments.get_Item(1);
                        args_exception.$v.Initialize();
                        args_return.$v.Initialize();
                        $.$srij.System.Runtime.InteropServices.JavaScript.JSFunctionBinding.InvokeJSFunction(this.JSObject, $arguments);
                    }
                    static $h = 1437065;
                    static $f = 0b10000000010010000;
                    static $k = 1;
                    static $$md;
                    static get $md() { return this.$$md ??= {"b":131073,"m":[{"r":65537,"n":"InvokeJS","d":1437065,"h":12886338953,"f":1}],"l":[{"t":2289033,"n":"JSObject","d":1437065,"h":4296404361,"f":2}],"c":[{"p":[{"n":"holder","p":2289033}],"n":".ctor","o":"$ctor$1","d":1437065,"h":8591371657,"f":1}],"d":1371529,"h":1437065}; }
                    static get $b() { return $.$spc.System.Object; }
                    static get $fullName() { return `System.Runtime.InteropServices.JavaScript.JSMarshalerArgument.ActionJS`; }
                }, $cls, ($v) => $cls.$_ActionJS = $v);
            }
            static $_ActionJS$$;
            static ActionJS$$(T)
            {
                let $cls = $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument;
                return ($cls.$_ActionJS$$ ??= $asm.$ncls("$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument.ActionJS<>", (T) => $asm.$gt("$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument.ActionJS<>", [T], ($self) => class ActionJS$$ extends $.$spc.System.Object
                {
                    /*ArgumentToJSCallback<T>*/ Arg1Marshaler = null;
                    /*JSObject*/ JSObject = null;
                    $ctor$1(/*JSObject*/ holder, /*ArgumentToJSCallback<T>*/ arg1Marshaler)
                    {
                        super.$ctor();
                        {
                            this.JSObject = holder;
                            this.Arg1Marshaler = arg1Marshaler;
                        }
                        return this;
                    }
                    /*void */ InvokeJS(/*T*/ arg1)
                    {
                        /*Span<JSMarshalerArgument>*/ let $arguments = $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.StackAllocSpan($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument, 3, null);
                        /*ref JSMarshalerArgument*/ let args_exception = $arguments.get_Item(0);
                        /*ref JSMarshalerArgument*/ let args_return = $arguments.get_Item(1);
                        /*ref JSMarshalerArgument*/ let args_arg1 = $arguments.get_Item(2);
                        args_exception.$v.Initialize();
                        args_return.$v.Initialize();
                        this.Arg1Marshaler.Invoke(args_arg1, arg1);
                        $.$srij.System.Runtime.InteropServices.JavaScript.JSFunctionBinding.InvokeJSFunction(this.JSObject, $arguments);
                    }
                    static $h = 1633673;
                    static $g = 1;
                    static $f = 0b10000000011010000;
                    static $k = 1;
                    static $$md;
                    static get $md() { return this.$$md ??= {"b":131073,"m":[{"r":65537,"p":[{"n":"arg1","p":T?.$h??1507328}],"n":"InvokeJS","d":this.$h,"h":Number(BigInt(this.$h)|0x400000000n),"f":1}],"l":[{"t":$.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument.ArgumentToJSCallback$$(T).$h,"n":"Arg1Marshaler","d":this.$h,"h":Number(BigInt(this.$h)|0x100000000n),"f":2},{"t":2289033,"n":"JSObject","d":this.$h,"h":Number(BigInt(this.$h)|0x200000000n),"f":2}],"c":[{"p":[{"n":"holder","p":2289033},{"n":"arg1Marshaler","p":$.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument.ArgumentToJSCallback$$(T).$h}],"n":".ctor","o":"$ctor$1","d":this.$h,"h":Number(BigInt(this.$h)|0x300000000n),"f":1}],"g":[T?.$h??1507328],"r":1,"d":1371529,"h":this.$h}; }
                    static get $b() { return $.$spc.System.Object; }
                    static get $fullName() { return `System.Runtime.InteropServices.JavaScript.JSMarshalerArgument.ActionJS<${T?.$fullName}>`; }
                }), $cls, ($v) => $cls.$_ActionJS$$ = $v))(T);
            }
            static $_ActionJS$$$;
            static ActionJS$$$(T1, T2)
            {
                let $cls = $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument;
                return ($cls.$_ActionJS$$$ ??= $asm.$ncls("$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument.ActionJS<,>", (T1, T2) => $asm.$gt("$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument.ActionJS<,>", [T1, T2], ($self) => class ActionJS$$$ extends $.$spc.System.Object
                {
                    /*ArgumentToJSCallback<T1>*/ Arg1Marshaler = null;
                    /*ArgumentToJSCallback<T2>*/ Arg2Marshaler = null;
                    /*JSObject*/ JSObject = null;
                    $ctor$1(/*JSObject*/ holder, /*ArgumentToJSCallback<T1>*/ arg1Marshaler, /*ArgumentToJSCallback<T2>*/ arg2Marshaler)
                    {
                        super.$ctor();
                        {
                            this.JSObject = holder;
                            this.Arg1Marshaler = arg1Marshaler;
                            this.Arg2Marshaler = arg2Marshaler;
                        }
                        return this;
                    }
                    /*void */ InvokeJS(/*T1*/ arg1, /*T2*/ arg2)
                    {
                        /*Span<JSMarshalerArgument>*/ let $arguments = $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.StackAllocSpan($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument, 4, null);
                        /*ref JSMarshalerArgument*/ let args_exception = $arguments.get_Item(0);
                        /*ref JSMarshalerArgument*/ let args_return = $arguments.get_Item(1);
                        /*ref JSMarshalerArgument*/ let args_arg1 = $arguments.get_Item(2);
                        /*ref JSMarshalerArgument*/ let args_arg2 = $arguments.get_Item(3);
                        args_exception.$v.Initialize();
                        args_return.$v.Initialize();
                        this.Arg1Marshaler.Invoke(args_arg1, arg1);
                        this.Arg2Marshaler.Invoke(args_arg2, arg2);
                        $.$srij.System.Runtime.InteropServices.JavaScript.JSFunctionBinding.InvokeJSFunction(this.JSObject, $arguments);
                    }
                    static $h = 1568137;
                    static $g = 2;
                    static $f = 0b10000000011010000;
                    static $k = 1;
                    static $$md;
                    static get $md() { return this.$$md ??= {"b":131073,"m":[{"r":65537,"p":[{"n":"arg1","p":T1?.$h??1507328},{"n":"arg2","p":T2?.$h??1572864}],"n":"InvokeJS","d":this.$h,"h":Number(BigInt(this.$h)|0x500000000n),"f":1}],"l":[{"t":$.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument.ArgumentToJSCallback$$(T1).$h,"n":"Arg1Marshaler","d":this.$h,"h":Number(BigInt(this.$h)|0x100000000n),"f":2},{"t":$.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument.ArgumentToJSCallback$$(T2).$h,"n":"Arg2Marshaler","d":this.$h,"h":Number(BigInt(this.$h)|0x200000000n),"f":2},{"t":2289033,"n":"JSObject","d":this.$h,"h":Number(BigInt(this.$h)|0x300000000n),"f":2}],"c":[{"p":[{"n":"holder","p":2289033},{"n":"arg1Marshaler","p":$.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument.ArgumentToJSCallback$$(T1).$h},{"n":"arg2Marshaler","p":$.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument.ArgumentToJSCallback$$(T2).$h}],"n":".ctor","o":"$ctor$1","d":this.$h,"h":Number(BigInt(this.$h)|0x400000000n),"f":1}],"g":[T1?.$h??1507328,T2?.$h??1572864],"r":2,"d":1371529,"h":this.$h}; }
                    static get $b() { return $.$spc.System.Object; }
                    static get $fullName() { return `System.Runtime.InteropServices.JavaScript.JSMarshalerArgument.ActionJS<${T1?.$fullName},${T2?.$fullName}>`; }
                }), $cls, ($v) => $cls.$_ActionJS$$$ = $v))(T1, T2);
            }
            static $_ActionJS$$$$;
            static ActionJS$$$$(T1, T2, T3)
            {
                let $cls = $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument;
                return ($cls.$_ActionJS$$$$ ??= $asm.$ncls("$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument.ActionJS<,,>", (T1, T2, T3) => $asm.$gt("$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument.ActionJS<,,>", [T1, T2, T3], ($self) => class ActionJS$$$$ extends $.$spc.System.Object
                {
                    /*ArgumentToJSCallback<T1>*/ Arg1Marshaler = null;
                    /*ArgumentToJSCallback<T2>*/ Arg2Marshaler = null;
                    /*ArgumentToJSCallback<T3>*/ Arg3Marshaler = null;
                    /*JSObject*/ JSObject = null;
                    $ctor$1(/*JSObject*/ holder, /*ArgumentToJSCallback<T1>*/ arg1Marshaler, /*ArgumentToJSCallback<T2>*/ arg2Marshaler, /*ArgumentToJSCallback<T3>*/ arg3Marshaler)
                    {
                        super.$ctor();
                        {
                            this.JSObject = holder;
                            this.Arg1Marshaler = arg1Marshaler;
                            this.Arg2Marshaler = arg2Marshaler;
                            this.Arg3Marshaler = arg3Marshaler;
                        }
                        return this;
                    }
                    /*void */ InvokeJS(/*T1*/ arg1, /*T2*/ arg2, /*T3*/ arg3)
                    {
                        /*Span<JSMarshalerArgument>*/ let $arguments = $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.StackAllocSpan($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument, 5, null);
                        /*ref JSMarshalerArgument*/ let args_exception = $arguments.get_Item(0);
                        /*ref JSMarshalerArgument*/ let args_return = $arguments.get_Item(1);
                        /*ref JSMarshalerArgument*/ let args_arg1 = $arguments.get_Item(2);
                        /*ref JSMarshalerArgument*/ let args_arg2 = $arguments.get_Item(3);
                        /*ref JSMarshalerArgument*/ let args_arg3 = $arguments.get_Item(4);
                        args_exception.$v.Initialize();
                        args_return.$v.Initialize();
                        this.Arg1Marshaler.Invoke(args_arg1, arg1);
                        this.Arg2Marshaler.Invoke(args_arg2, arg2);
                        this.Arg3Marshaler.Invoke(args_arg3, arg3);
                        $.$srij.System.Runtime.InteropServices.JavaScript.JSFunctionBinding.InvokeJSFunction(this.JSObject, $arguments);
                    }
                    static $h = 1502601;
                    static $g = 3;
                    static $f = 0b10000000011010000;
                    static $k = 1;
                    static $$md;
                    static get $md() { return this.$$md ??= {"b":131073,"m":[{"r":65537,"p":[{"n":"arg1","p":T1?.$h??1507328},{"n":"arg2","p":T2?.$h??1572864},{"n":"arg3","p":T3?.$h??1638400}],"n":"InvokeJS","d":this.$h,"h":Number(BigInt(this.$h)|0x600000000n),"f":1}],"l":[{"t":$.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument.ArgumentToJSCallback$$(T1).$h,"n":"Arg1Marshaler","d":this.$h,"h":Number(BigInt(this.$h)|0x100000000n),"f":2},{"t":$.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument.ArgumentToJSCallback$$(T2).$h,"n":"Arg2Marshaler","d":this.$h,"h":Number(BigInt(this.$h)|0x200000000n),"f":2},{"t":$.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument.ArgumentToJSCallback$$(T3).$h,"n":"Arg3Marshaler","d":this.$h,"h":Number(BigInt(this.$h)|0x300000000n),"f":2},{"t":2289033,"n":"JSObject","d":this.$h,"h":Number(BigInt(this.$h)|0x400000000n),"f":2}],"c":[{"p":[{"n":"holder","p":2289033},{"n":"arg1Marshaler","p":$.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument.ArgumentToJSCallback$$(T1).$h},{"n":"arg2Marshaler","p":$.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument.ArgumentToJSCallback$$(T2).$h},{"n":"arg3Marshaler","p":$.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument.ArgumentToJSCallback$$(T3).$h}],"n":".ctor","o":"$ctor$1","d":this.$h,"h":Number(BigInt(this.$h)|0x500000000n),"f":1}],"g":[T1?.$h??1507328,T2?.$h??1572864,T3?.$h??1638400],"r":3,"d":1371529,"h":this.$h}; }
                    static get $b() { return $.$spc.System.Object; }
                    static get $fullName() { return `System.Runtime.InteropServices.JavaScript.JSMarshalerArgument.ActionJS<${T1?.$fullName},${T2?.$fullName},${T3?.$fullName}>`; }
                }), $cls, ($v) => $cls.$_ActionJS$$$$ = $v))(T1, T2, T3);
            }
            /*void */ ToManaged$39(/*out Action?*/ value)
            {
                if (this.slot.Type === 0/*MarshalerType.None*/)
                {
                    value.$v = null;
                    return;
                }
                /*var*/ let ctx = this.ToManagedContext;
                /*var*/ let holder = ctx.CreateCSOwnedProxy(this.slot.JSHandle);
                value.$v = new $.$spc.System.Action().$ctor(new $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument.ActionJS().$ctor$1(holder), new $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument.ActionJS().$ctor$1(holder).InvokeJS);
            }
            /*void */ ToManaged$40(T, /*out Action<T>?*/ value, /*ArgumentToJSCallback<T>*/ arg1Marshaler)
            {
                if (this.slot.Type === 0/*MarshalerType.None*/)
                {
                    value.$v = null;
                    return;
                }
                /*var*/ let ctx = this.ToManagedContext;
                /*var*/ let holder = ctx.CreateCSOwnedProxy(this.slot.JSHandle);
                value.$v = new ($.$spc.System.Action$$(T))().$ctor(new ($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument.ActionJS$$(T))().$ctor$1(holder, arg1Marshaler), new ($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument.ActionJS$$(T))().$ctor$1(holder, arg1Marshaler).InvokeJS);
            }
            /*void */ ToManaged$41(T1, T2, /*out Action<T1, T2>?*/ value, /*ArgumentToJSCallback<T1>*/ arg1Marshaler, /*ArgumentToJSCallback<T2>*/ arg2Marshaler)
            {
                if (this.slot.Type === 0/*MarshalerType.None*/)
                {
                    value.$v = null;
                    return;
                }
                /*var*/ let ctx = this.ToManagedContext;
                /*var*/ let holder = ctx.CreateCSOwnedProxy(this.slot.JSHandle);
                value.$v = new ($.$spc.System.Action$$$(T1, T2))().$ctor(new ($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument.ActionJS$$$(T1, T2))().$ctor$1(holder, arg1Marshaler, arg2Marshaler), new ($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument.ActionJS$$$(T1, T2))().$ctor$1(holder, arg1Marshaler, arg2Marshaler).InvokeJS);
            }
            /*void */ ToManaged$42(T1, T2, T3, /*out Action<T1, T2, T3>?*/ value, /*ArgumentToJSCallback<T1>*/ arg1Marshaler, /*ArgumentToJSCallback<T2>*/ arg2Marshaler, /*ArgumentToJSCallback<T3>*/ arg3Marshaler)
            {
                if (this.slot.Type === 0/*MarshalerType.None*/)
                {
                    value.$v = null;
                    return;
                }
                /*var*/ let ctx = this.ToManagedContext;
                /*var*/ let holder = ctx.CreateCSOwnedProxy(this.slot.JSHandle);
                value.$v = new ($.$spc.System.Action$$$$(T1, T2, T3))().$ctor(new ($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument.ActionJS$$$$(T1, T2, T3))().$ctor$1(holder, arg1Marshaler, arg2Marshaler, arg3Marshaler), new ($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument.ActionJS$$$$(T1, T2, T3))().$ctor$1(holder, arg1Marshaler, arg2Marshaler, arg3Marshaler).InvokeJS);
            }
            static $_FuncJS$$;
            static FuncJS$$(TResult)
            {
                let $cls = $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument;
                return ($cls.$_FuncJS$$ ??= $asm.$ncls("$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument.FuncJS<>", (TResult) => $asm.$gt("$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument.FuncJS<>", [TResult], ($self) => class FuncJS$$ extends $.$spc.System.Object
                {
                    /*JSObject*/ JSObject = null;
                    /*ArgumentToManagedCallback<TResult>*/ ResMarshaler = null;
                    $ctor$1(/*JSObject*/ holder, /*ArgumentToManagedCallback<TResult>*/ resMarshaler)
                    {
                        super.$ctor();
                        {
                            this.JSObject = holder;
                            this.ResMarshaler = resMarshaler;
                        }
                        return this;
                    }
                    /*TResult */ InvokeJS()
                    {
                        /*Span<JSMarshalerArgument>*/ let $arguments = $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.StackAllocSpan($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument, 2, null);
                        /*ref JSMarshalerArgument*/ let args_exception = $arguments.get_Item(0);
                        /*ref JSMarshalerArgument*/ let args_return = $arguments.get_Item(1);
                        args_exception.$v.Initialize();
                        args_return.$v.Initialize();
                        $.$srij.System.Runtime.InteropServices.JavaScript.JSFunctionBinding.InvokeJSFunction(this.JSObject, $arguments);
                        /*TResult*/ let res;
                        this.ResMarshaler.Invoke(args_return, $.$ref(() => res, ($v) => res = $v, TResult));
                        return res;
                    }
                    static $h = 2026889;
                    static $g = 1;
                    static $f = 0b10000000011010000;
                    static $k = 1;
                    static $$md;
                    static get $md() { return this.$$md ??= {"b":131073,"m":[{"r":TResult?.$h??1507328,"n":"InvokeJS","d":this.$h,"h":Number(BigInt(this.$h)|0x400000000n),"f":1}],"l":[{"t":2289033,"n":"JSObject","d":this.$h,"h":Number(BigInt(this.$h)|0x100000000n),"f":2},{"t":$.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument.ArgumentToManagedCallback$$(TResult).$h,"n":"ResMarshaler","d":this.$h,"h":Number(BigInt(this.$h)|0x200000000n),"f":2}],"c":[{"p":[{"n":"holder","p":2289033},{"n":"resMarshaler","p":$.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument.ArgumentToManagedCallback$$(TResult).$h}],"n":".ctor","o":"$ctor$1","d":this.$h,"h":Number(BigInt(this.$h)|0x300000000n),"f":1}],"g":[TResult?.$h??1507328],"r":1,"d":1371529,"h":this.$h}; }
                    static get $b() { return $.$spc.System.Object; }
                    static get $fullName() { return `System.Runtime.InteropServices.JavaScript.JSMarshalerArgument.FuncJS<${TResult?.$fullName}>`; }
                }), $cls, ($v) => $cls.$_FuncJS$$ = $v))(TResult);
            }
            static $_FuncJS$$$;
            static FuncJS$$$(T, TResult)
            {
                let $cls = $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument;
                return ($cls.$_FuncJS$$$ ??= $asm.$ncls("$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument.FuncJS<,>", (T, TResult) => $asm.$gt("$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument.FuncJS<,>", [T, TResult], ($self) => class FuncJS$$$ extends $.$spc.System.Object
                {
                    /*ArgumentToJSCallback<T>*/ Arg1Marshaler = null;
                    /*ArgumentToManagedCallback<TResult>*/ ResMarshaler = null;
                    /*JSObject*/ JSObject = null;
                    $ctor$1(/*JSObject*/ holder, /*ArgumentToJSCallback<T>*/ arg1Marshaler, /*ArgumentToManagedCallback<TResult>*/ resMarshaler)
                    {
                        super.$ctor();
                        {
                            this.JSObject = holder;
                            this.Arg1Marshaler = arg1Marshaler;
                            this.ResMarshaler = resMarshaler;
                        }
                        return this;
                    }
                    /*TResult */ InvokeJS(/*T*/ arg1)
                    {
                        /*Span<JSMarshalerArgument>*/ let $arguments = $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.StackAllocSpan($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument, 3, null);
                        /*ref JSMarshalerArgument*/ let args_exception = $arguments.get_Item(0);
                        /*ref JSMarshalerArgument*/ let args_return = $arguments.get_Item(1);
                        /*ref JSMarshalerArgument*/ let args_arg1 = $arguments.get_Item(2);
                        args_exception.$v.Initialize();
                        args_return.$v.Initialize();
                        this.Arg1Marshaler.Invoke(args_arg1, arg1);
                        $.$srij.System.Runtime.InteropServices.JavaScript.JSFunctionBinding.InvokeJSFunction(this.JSObject, $arguments);
                        /*TResult*/ let res;
                        this.ResMarshaler.Invoke(args_return, $.$ref(() => res, ($v) => res = $v, TResult));
                        return res;
                    }
                    static $h = 1961353;
                    static $g = 2;
                    static $f = 0b10000000011010000;
                    static $k = 1;
                    static $$md;
                    static get $md() { return this.$$md ??= {"b":131073,"m":[{"r":TResult?.$h??1572864,"p":[{"n":"arg1","p":T?.$h??1507328}],"n":"InvokeJS","d":this.$h,"h":Number(BigInt(this.$h)|0x500000000n),"f":1}],"l":[{"t":$.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument.ArgumentToJSCallback$$(T).$h,"n":"Arg1Marshaler","d":this.$h,"h":Number(BigInt(this.$h)|0x100000000n),"f":2},{"t":$.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument.ArgumentToManagedCallback$$(TResult).$h,"n":"ResMarshaler","d":this.$h,"h":Number(BigInt(this.$h)|0x200000000n),"f":2},{"t":2289033,"n":"JSObject","d":this.$h,"h":Number(BigInt(this.$h)|0x300000000n),"f":2}],"c":[{"p":[{"n":"holder","p":2289033},{"n":"arg1Marshaler","p":$.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument.ArgumentToJSCallback$$(T).$h},{"n":"resMarshaler","p":$.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument.ArgumentToManagedCallback$$(TResult).$h}],"n":".ctor","o":"$ctor$1","d":this.$h,"h":Number(BigInt(this.$h)|0x400000000n),"f":1}],"g":[T?.$h??1507328,TResult?.$h??1572864],"r":2,"d":1371529,"h":this.$h}; }
                    static get $b() { return $.$spc.System.Object; }
                    static get $fullName() { return `System.Runtime.InteropServices.JavaScript.JSMarshalerArgument.FuncJS<${T?.$fullName},${TResult?.$fullName}>`; }
                }), $cls, ($v) => $cls.$_FuncJS$$$ = $v))(T, TResult);
            }
            static $_FuncJS$$$$;
            static FuncJS$$$$(T1, T2, TResult)
            {
                let $cls = $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument;
                return ($cls.$_FuncJS$$$$ ??= $asm.$ncls("$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument.FuncJS<,,>", (T1, T2, TResult) => $asm.$gt("$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument.FuncJS<,,>", [T1, T2, TResult], ($self) => class FuncJS$$$$ extends $.$spc.System.Object
                {
                    /*ArgumentToJSCallback<T1>*/ Arg1Marshaler = null;
                    /*ArgumentToJSCallback<T2>*/ Arg2Marshaler = null;
                    /*ArgumentToManagedCallback<TResult>*/ ResMarshaler = null;
                    /*JSObject*/ JSObject = null;
                    $ctor$1(/*JSObject*/ holder, /*ArgumentToJSCallback<T1>*/ arg1Marshaler, /*ArgumentToJSCallback<T2>*/ arg2Marshaler, /*ArgumentToManagedCallback<TResult>*/ resMarshaler)
                    {
                        super.$ctor();
                        {
                            this.JSObject = holder;
                            this.Arg1Marshaler = arg1Marshaler;
                            this.Arg2Marshaler = arg2Marshaler;
                            this.ResMarshaler = resMarshaler;
                        }
                        return this;
                    }
                    /*TResult */ InvokeJS(/*T1*/ arg1, /*T2*/ arg2)
                    {
                        /*Span<JSMarshalerArgument>*/ let $arguments = $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.StackAllocSpan($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument, 4, null);
                        /*ref JSMarshalerArgument*/ let args_exception = $arguments.get_Item(0);
                        /*ref JSMarshalerArgument*/ let args_return = $arguments.get_Item(1);
                        /*ref JSMarshalerArgument*/ let args_arg1 = $arguments.get_Item(2);
                        /*ref JSMarshalerArgument*/ let args_arg2 = $arguments.get_Item(3);
                        args_exception.$v.Initialize();
                        args_return.$v.Initialize();
                        this.Arg1Marshaler.Invoke(args_arg1, arg1);
                        this.Arg2Marshaler.Invoke(args_arg2, arg2);
                        $.$srij.System.Runtime.InteropServices.JavaScript.JSFunctionBinding.InvokeJSFunction(this.JSObject, $arguments);
                        /*TResult*/ let res;
                        this.ResMarshaler.Invoke(args_return, $.$ref(() => res, ($v) => res = $v, TResult));
                        return res;
                    }
                    static $h = 1895817;
                    static $g = 3;
                    static $f = 0b10000000011010000;
                    static $k = 1;
                    static $$md;
                    static get $md() { return this.$$md ??= {"b":131073,"m":[{"r":TResult?.$h??1638400,"p":[{"n":"arg1","p":T1?.$h??1507328},{"n":"arg2","p":T2?.$h??1572864}],"n":"InvokeJS","d":this.$h,"h":Number(BigInt(this.$h)|0x600000000n),"f":1}],"l":[{"t":$.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument.ArgumentToJSCallback$$(T1).$h,"n":"Arg1Marshaler","d":this.$h,"h":Number(BigInt(this.$h)|0x100000000n),"f":2},{"t":$.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument.ArgumentToJSCallback$$(T2).$h,"n":"Arg2Marshaler","d":this.$h,"h":Number(BigInt(this.$h)|0x200000000n),"f":2},{"t":$.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument.ArgumentToManagedCallback$$(TResult).$h,"n":"ResMarshaler","d":this.$h,"h":Number(BigInt(this.$h)|0x300000000n),"f":2},{"t":2289033,"n":"JSObject","d":this.$h,"h":Number(BigInt(this.$h)|0x400000000n),"f":2}],"c":[{"p":[{"n":"holder","p":2289033},{"n":"arg1Marshaler","p":$.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument.ArgumentToJSCallback$$(T1).$h},{"n":"arg2Marshaler","p":$.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument.ArgumentToJSCallback$$(T2).$h},{"n":"resMarshaler","p":$.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument.ArgumentToManagedCallback$$(TResult).$h}],"n":".ctor","o":"$ctor$1","d":this.$h,"h":Number(BigInt(this.$h)|0x500000000n),"f":1}],"g":[T1?.$h??1507328,T2?.$h??1572864,TResult?.$h??1638400],"r":3,"d":1371529,"h":this.$h}; }
                    static get $b() { return $.$spc.System.Object; }
                    static get $fullName() { return `System.Runtime.InteropServices.JavaScript.JSMarshalerArgument.FuncJS<${T1?.$fullName},${T2?.$fullName},${TResult?.$fullName}>`; }
                }), $cls, ($v) => $cls.$_FuncJS$$$$ = $v))(T1, T2, TResult);
            }
            static $_FuncJS$$$$$;
            static FuncJS$$$$$(T1, T2, T3, TResult)
            {
                let $cls = $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument;
                return ($cls.$_FuncJS$$$$$ ??= $asm.$ncls("$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument.FuncJS<,,,>", (T1, T2, T3, TResult) => $asm.$gt("$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument.FuncJS<,,,>", [T1, T2, T3, TResult], ($self) => class FuncJS$$$$$ extends $.$spc.System.Object
                {
                    /*ArgumentToJSCallback<T1>*/ Arg1Marshaler = null;
                    /*ArgumentToJSCallback<T2>*/ Arg2Marshaler = null;
                    /*ArgumentToJSCallback<T3>*/ Arg3Marshaler = null;
                    /*ArgumentToManagedCallback<TResult>*/ ResMarshaler = null;
                    /*JSObject*/ JSObject = null;
                    $ctor$1(/*JSObject*/ holder, /*ArgumentToJSCallback<T1>*/ arg1Marshaler, /*ArgumentToJSCallback<T2>*/ arg2Marshaler, /*ArgumentToJSCallback<T3>*/ arg3Marshaler, /*ArgumentToManagedCallback<TResult>*/ resMarshaler)
                    {
                        super.$ctor();
                        {
                            this.JSObject = holder;
                            this.Arg1Marshaler = arg1Marshaler;
                            this.Arg2Marshaler = arg2Marshaler;
                            this.Arg3Marshaler = arg3Marshaler;
                            this.ResMarshaler = resMarshaler;
                        }
                        return this;
                    }
                    /*TResult */ InvokeJS(/*T1*/ arg1, /*T2*/ arg2, /*T3*/ arg3)
                    {
                        /*Span<JSMarshalerArgument>*/ let $arguments = $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.StackAllocSpan($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument, 5, null);
                        /*ref JSMarshalerArgument*/ let args_exception = $arguments.get_Item(0);
                        /*ref JSMarshalerArgument*/ let args_return = $arguments.get_Item(1);
                        /*ref JSMarshalerArgument*/ let args_arg1 = $arguments.get_Item(2);
                        /*ref JSMarshalerArgument*/ let args_arg2 = $arguments.get_Item(3);
                        /*ref JSMarshalerArgument*/ let args_arg3 = $arguments.get_Item(4);
                        args_exception.$v.Initialize();
                        args_return.$v.Initialize();
                        this.Arg1Marshaler.Invoke(args_arg1, arg1);
                        this.Arg2Marshaler.Invoke(args_arg2, arg2);
                        this.Arg3Marshaler.Invoke(args_arg3, arg3);
                        $.$srij.System.Runtime.InteropServices.JavaScript.JSFunctionBinding.InvokeJSFunction(this.JSObject, $arguments);
                        /*TResult*/ let res;
                        this.ResMarshaler.Invoke(args_return, $.$ref(() => res, ($v) => res = $v, TResult));
                        return res;
                    }
                    static $h = 1830281;
                    static $g = 4;
                    static $f = 0b10000000011010000;
                    static $k = 1;
                    static $$md;
                    static get $md() { return this.$$md ??= {"b":131073,"m":[{"r":TResult?.$h??1703936,"p":[{"n":"arg1","p":T1?.$h??1507328},{"n":"arg2","p":T2?.$h??1572864},{"n":"arg3","p":T3?.$h??1638400}],"n":"InvokeJS","d":this.$h,"h":Number(BigInt(this.$h)|0x700000000n),"f":1}],"l":[{"t":$.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument.ArgumentToJSCallback$$(T1).$h,"n":"Arg1Marshaler","d":this.$h,"h":Number(BigInt(this.$h)|0x100000000n),"f":2},{"t":$.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument.ArgumentToJSCallback$$(T2).$h,"n":"Arg2Marshaler","d":this.$h,"h":Number(BigInt(this.$h)|0x200000000n),"f":2},{"t":$.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument.ArgumentToJSCallback$$(T3).$h,"n":"Arg3Marshaler","d":this.$h,"h":Number(BigInt(this.$h)|0x300000000n),"f":2},{"t":$.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument.ArgumentToManagedCallback$$(TResult).$h,"n":"ResMarshaler","d":this.$h,"h":Number(BigInt(this.$h)|0x400000000n),"f":2},{"t":2289033,"n":"JSObject","d":this.$h,"h":Number(BigInt(this.$h)|0x500000000n),"f":2}],"c":[{"p":[{"n":"holder","p":2289033},{"n":"arg1Marshaler","p":$.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument.ArgumentToJSCallback$$(T1).$h},{"n":"arg2Marshaler","p":$.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument.ArgumentToJSCallback$$(T2).$h},{"n":"arg3Marshaler","p":$.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument.ArgumentToJSCallback$$(T3).$h},{"n":"resMarshaler","p":$.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument.ArgumentToManagedCallback$$(TResult).$h}],"n":".ctor","o":"$ctor$1","d":this.$h,"h":Number(BigInt(this.$h)|0x600000000n),"f":1}],"g":[T1?.$h??1507328,T2?.$h??1572864,T3?.$h??1638400,TResult?.$h??1703936],"r":4,"d":1371529,"h":this.$h}; }
                    static get $b() { return $.$spc.System.Object; }
                    static get $fullName() { return `System.Runtime.InteropServices.JavaScript.JSMarshalerArgument.FuncJS<${T1?.$fullName},${T2?.$fullName},${T3?.$fullName},${TResult?.$fullName}>`; }
                }), $cls, ($v) => $cls.$_FuncJS$$$$$ = $v))(T1, T2, T3, TResult);
            }
            /*void */ ToManaged$43(TResult, /*out Func<TResult>?*/ value, /*ArgumentToManagedCallback<TResult>*/ resMarshaler)
            {
                if (this.slot.Type === 0/*MarshalerType.None*/)
                {
                    value.$v = null;
                    return;
                }
                /*var*/ let ctx = this.ToManagedContext;
                /*var*/ let holder = ctx.CreateCSOwnedProxy(this.slot.JSHandle);
                value.$v = new ($.$spc.System.Func$$(TResult))().$ctor(new ($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument.FuncJS$$(TResult))().$ctor$1(holder, resMarshaler), new ($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument.FuncJS$$(TResult))().$ctor$1(holder, resMarshaler).InvokeJS);
            }
            /*void */ ToManaged$44(T, TResult, /*out Func<T, TResult>?*/ value, /*ArgumentToJSCallback<T>*/ arg1Marshaler, /*ArgumentToManagedCallback<TResult>*/ resMarshaler)
            {
                if (this.slot.Type === 0/*MarshalerType.None*/)
                {
                    value.$v = null;
                    return;
                }
                /*var*/ let ctx = this.ToManagedContext;
                /*var*/ let holder = ctx.CreateCSOwnedProxy(this.slot.JSHandle);
                value.$v = new ($.$spc.System.Func$$$(T, TResult))().$ctor(new ($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument.FuncJS$$$(T, TResult))().$ctor$1(holder, arg1Marshaler, resMarshaler), new ($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument.FuncJS$$$(T, TResult))().$ctor$1(holder, arg1Marshaler, resMarshaler).InvokeJS);
            }
            /*void */ ToManaged$45(T1, T2, TResult, /*out Func<T1, T2, TResult>?*/ value, /*ArgumentToJSCallback<T1>*/ arg1Marshaler, /*ArgumentToJSCallback<T2>*/ arg2Marshaler, /*ArgumentToManagedCallback<TResult>*/ resMarshaler)
            {
                if (this.slot.Type === 0/*MarshalerType.None*/)
                {
                    value.$v = null;
                    return;
                }
                /*var*/ let ctx = this.ToManagedContext;
                /*var*/ let holder = ctx.CreateCSOwnedProxy(this.slot.JSHandle);
                value.$v = new ($.$spc.System.Func$$$$(T1, T2, TResult))().$ctor(new ($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument.FuncJS$$$$(T1, T2, TResult))().$ctor$1(holder, arg1Marshaler, arg2Marshaler, resMarshaler), new ($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument.FuncJS$$$$(T1, T2, TResult))().$ctor$1(holder, arg1Marshaler, arg2Marshaler, resMarshaler).InvokeJS);
            }
            /*void */ ToManaged$46(T1, T2, T3, TResult, /*out Func<T1, T2, T3, TResult>?*/ value, /*ArgumentToJSCallback<T1>*/ arg1Marshaler, /*ArgumentToJSCallback<T2>*/ arg2Marshaler, /*ArgumentToJSCallback<T3>*/ arg3Marshaler, /*ArgumentToManagedCallback<TResult>*/ resMarshaler)
            {
                if (this.slot.Type === 0/*MarshalerType.None*/)
                {
                    value.$v = null;
                    return;
                }
                /*var*/ let ctx = this.ToManagedContext;
                /*var*/ let holder = ctx.CreateCSOwnedProxy(this.slot.JSHandle);
                value.$v = new ($.$spc.System.Func$$$$$(T1, T2, T3, TResult))().$ctor(new ($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument.FuncJS$$$$$(T1, T2, T3, TResult))().$ctor$1(holder, arg1Marshaler, arg2Marshaler, arg3Marshaler, resMarshaler), new ($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument.FuncJS$$$$$(T1, T2, T3, TResult))().$ctor$1(holder, arg1Marshaler, arg2Marshaler, arg3Marshaler, resMarshaler).InvokeJS);
            }
            /*void */ ToJS$39(/*Action*/ value)
            {
                /*Action*/ let cpy = value;
                /*JSHostImplementation.ToManagedCallback*/ let cb = new $.$srij.System.Runtime.InteropServices.JavaScript.JSHostImplementation.ToManagedCallback().$ctor(this,  (/*JSMarshalerArgument**/ $arguments) =>
                {
                    cpy.Invoke();
                }, {"r":65537,"p":[{"n":"arguments","p":0}],"n":"","d":1371529,"h":0,"f":1048578});
                this.slot.Type = 25/*MarshalerType.Function*/;
                /*var*/ let ctx = this.ToJSContext;
                this.slot.GCHandle = ctx.GetJSOwnedObjectGCHandle(cb, 2);
            }
            /*void */ ToJS$40(T, /*Action<T>*/ value, /*ArgumentToManagedCallback<T>*/ arg1Marshaler)
            {
                /*Action<T>*/ let cpy = value;
                /*JSHostImplementation.ToManagedCallback*/ let cb = new $.$srij.System.Runtime.InteropServices.JavaScript.JSHostImplementation.ToManagedCallback().$ctor(this,  (/*JSMarshalerArgument**/ $arguments) =>
                {
                    /*ref JSMarshalerArgument*/ let arg2 = $arguments.Add(3);
                    /*T*/ let arg1cs;
                    arg1Marshaler.Invoke(arg2, $.$ref(() => arg1cs, ($v) => arg1cs = $v, T));
                    cpy.Invoke(arg1cs);
                }, {"r":65537,"p":[{"n":"arguments","p":0}],"n":"","d":1371529,"h":0,"f":1048578});
                this.slot.Type = 24/*MarshalerType.Action*/;
                /*var*/ let ctx = this.ToJSContext;
                this.slot.GCHandle = ctx.GetJSOwnedObjectGCHandle(cb, 2);
            }
            /*void */ ToJS$41(T1, T2, /*Action<T1, T2>*/ value, /*ArgumentToManagedCallback<T1>*/ arg1Marshaler, /*ArgumentToManagedCallback<T2>*/ arg2Marshaler)
            {
                /*Action<T1, T2>*/ let cpy = value;
                /*JSHostImplementation.ToManagedCallback*/ let cb = new $.$srij.System.Runtime.InteropServices.JavaScript.JSHostImplementation.ToManagedCallback().$ctor(this,  (/*JSMarshalerArgument**/ $arguments) =>
                {
                    /*ref JSMarshalerArgument*/ let arg2 = $arguments.Add(3);
                    /*ref JSMarshalerArgument*/ let arg3 = $arguments.Add(4);
                    /*T1*/ let arg1cs;
                    arg1Marshaler.Invoke(arg2, $.$ref(() => arg1cs, ($v) => arg1cs = $v, T1));
                    /*T2*/ let arg2cs;
                    arg2Marshaler.Invoke(arg3, $.$ref(() => arg2cs, ($v) => arg2cs = $v, T2));
                    cpy.Invoke(arg1cs, arg2cs);
                }, {"r":65537,"p":[{"n":"arguments","p":0}],"n":"","d":1371529,"h":0,"f":1048578});
                this.slot.Type = 24/*MarshalerType.Action*/;
                /*var*/ let ctx = this.ToJSContext;
                this.slot.GCHandle = ctx.GetJSOwnedObjectGCHandle(cb, 2);
            }
            /*void */ ToJS$42(T1, T2, T3, /*Action<T1, T2, T3>*/ value, /*ArgumentToManagedCallback<T1>*/ arg1Marshaler, /*ArgumentToManagedCallback<T2>*/ arg2Marshaler, /*ArgumentToManagedCallback<T3>*/ arg3Marshaler)
            {
                /*Action<T1, T2, T3>*/ let cpy = value;
                /*JSHostImplementation.ToManagedCallback*/ let cb = new $.$srij.System.Runtime.InteropServices.JavaScript.JSHostImplementation.ToManagedCallback().$ctor(this,  (/*JSMarshalerArgument**/ $arguments) =>
                {
                    /*ref JSMarshalerArgument*/ let arg2 = $arguments.Add(3);
                    /*ref JSMarshalerArgument*/ let arg3 = $arguments.Add(4);
                    /*ref JSMarshalerArgument*/ let arg4 = $arguments.Add(5);
                    /*T1*/ let arg1cs;
                    arg1Marshaler.Invoke(arg2, $.$ref(() => arg1cs, ($v) => arg1cs = $v, T1));
                    /*T2*/ let arg2cs;
                    arg2Marshaler.Invoke(arg3, $.$ref(() => arg2cs, ($v) => arg2cs = $v, T2));
                    /*T3*/ let arg3cs;
                    arg3Marshaler.Invoke(arg4, $.$ref(() => arg3cs, ($v) => arg3cs = $v, T3));
                    cpy.Invoke(arg1cs, arg2cs, arg3cs);
                }, {"r":65537,"p":[{"n":"arguments","p":0}],"n":"","d":1371529,"h":0,"f":1048578});
                this.slot.Type = 24/*MarshalerType.Action*/;
                /*var*/ let ctx = this.ToJSContext;
                this.slot.GCHandle = ctx.GetJSOwnedObjectGCHandle(cb, 2);
            }
            /*void */ ToJS$43(TResult, /*Func<TResult>*/ value, /*ArgumentToJSCallback<TResult>*/ resMarshaler)
            {
                /*Func<TResult>*/ let cpy = value;
                /*JSHostImplementation.ToManagedCallback*/ let cb = new $.$srij.System.Runtime.InteropServices.JavaScript.JSHostImplementation.ToManagedCallback().$ctor(this,  (/*JSMarshalerArgument**/ $arguments) =>
                {
                    /*ref JSMarshalerArgument*/ let res = $arguments.Add(1);
                    /*TResult*/ let resCs = cpy.Invoke();
                    resMarshaler.Invoke(res, resCs);
                }, {"r":65537,"p":[{"n":"arguments","p":0}],"n":"","d":1371529,"h":0,"f":1048578});
                this.slot.Type = 25/*MarshalerType.Function*/;
                /*var*/ let ctx = this.ToJSContext;
                this.slot.GCHandle = ctx.GetJSOwnedObjectGCHandle(cb, 2);
            }
            /*void */ ToJS$44(T, TResult, /*Func<T, TResult>*/ value, /*ArgumentToManagedCallback<T>*/ arg1Marshaler, /*ArgumentToJSCallback<TResult>*/ resMarshaler)
            {
                /*Func<T, TResult>*/ let cpy = value;
                /*JSHostImplementation.ToManagedCallback*/ let cb = new $.$srij.System.Runtime.InteropServices.JavaScript.JSHostImplementation.ToManagedCallback().$ctor(this,  (/*JSMarshalerArgument**/ $arguments) =>
                {
                    /*ref JSMarshalerArgument*/ let res = $arguments.Add(1);
                    /*ref JSMarshalerArgument*/ let arg2 = $arguments.Add(3);
                    /*T*/ let arg1cs;
                    arg1Marshaler.Invoke(arg2, $.$ref(() => arg1cs, ($v) => arg1cs = $v, T));
                    /*TResult*/ let resCs = cpy.Invoke(arg1cs);
                    resMarshaler.Invoke(res, resCs);
                }, {"r":65537,"p":[{"n":"arguments","p":0}],"n":"","d":1371529,"h":0,"f":1048578});
                this.slot.Type = 25/*MarshalerType.Function*/;
                /*var*/ let ctx = this.ToJSContext;
                this.slot.GCHandle = ctx.GetJSOwnedObjectGCHandle(cb, 2);
            }
            /*void */ ToJS$45(T1, T2, TResult, /*Func<T1, T2, TResult>*/ value, /*ArgumentToManagedCallback<T1>*/ arg1Marshaler, /*ArgumentToManagedCallback<T2>*/ arg2Marshaler, /*ArgumentToJSCallback<TResult>*/ resMarshaler)
            {
                /*Func<T1, T2, TResult>*/ let cpy = value;
                /*JSHostImplementation.ToManagedCallback*/ let cb = new $.$srij.System.Runtime.InteropServices.JavaScript.JSHostImplementation.ToManagedCallback().$ctor(this,  (/*JSMarshalerArgument**/ $arguments) =>
                {
                    /*ref JSMarshalerArgument*/ let res = $arguments.Add(1);
                    /*ref JSMarshalerArgument*/ let arg2 = $arguments.Add(3);
                    /*ref JSMarshalerArgument*/ let arg3 = $arguments.Add(4);
                    /*T1*/ let arg1cs;
                    arg1Marshaler.Invoke(arg2, $.$ref(() => arg1cs, ($v) => arg1cs = $v, T1));
                    /*T2*/ let arg2cs;
                    arg2Marshaler.Invoke(arg3, $.$ref(() => arg2cs, ($v) => arg2cs = $v, T2));
                    /*TResult*/ let resCs = cpy.Invoke(arg1cs, arg2cs);
                    resMarshaler.Invoke(res, resCs);
                }, {"r":65537,"p":[{"n":"arguments","p":0}],"n":"","d":1371529,"h":0,"f":1048578});
                this.slot.Type = 25/*MarshalerType.Function*/;
                /*var*/ let ctx = this.ToJSContext;
                this.slot.GCHandle = ctx.GetJSOwnedObjectGCHandle(cb, 2);
            }
            /*void */ ToJS$46(T1, T2, T3, TResult, /*Func<T1, T2, T3, TResult>*/ value, /*ArgumentToManagedCallback<T1>*/ arg1Marshaler, /*ArgumentToManagedCallback<T2>*/ arg2Marshaler, /*ArgumentToManagedCallback<T3>*/ arg3Marshaler, /*ArgumentToJSCallback<TResult>*/ resMarshaler)
            {
                /*Func<T1, T2, T3, TResult>*/ let cpy = value;
                /*JSHostImplementation.ToManagedCallback*/ let cb = new $.$srij.System.Runtime.InteropServices.JavaScript.JSHostImplementation.ToManagedCallback().$ctor(this,  (/*JSMarshalerArgument**/ $arguments) =>
                {
                    /*ref JSMarshalerArgument*/ let res = $arguments.Add(1);
                    /*ref JSMarshalerArgument*/ let arg2 = $arguments.Add(3);
                    /*ref JSMarshalerArgument*/ let arg3 = $arguments.Add(4);
                    /*ref JSMarshalerArgument*/ let arg4 = $arguments.Add(5);
                    /*T1*/ let arg1cs;
                    arg1Marshaler.Invoke(arg2, $.$ref(() => arg1cs, ($v) => arg1cs = $v, T1));
                    /*T2*/ let arg2cs;
                    arg2Marshaler.Invoke(arg3, $.$ref(() => arg2cs, ($v) => arg2cs = $v, T2));
                    /*T3*/ let arg3cs;
                    arg3Marshaler.Invoke(arg4, $.$ref(() => arg3cs, ($v) => arg3cs = $v, T3));
                    /*TResult*/ let resCs = cpy.Invoke(arg1cs, arg2cs, arg3cs);
                    resMarshaler.Invoke(res, resCs);
                }, {"r":65537,"p":[{"n":"arguments","p":0}],"n":"","d":1371529,"h":0,"f":1048578});
                this.slot.Type = 25/*MarshalerType.Function*/;
                /*var*/ let ctx = this.ToJSContext;
                this.slot.GCHandle = ctx.GetJSOwnedObjectGCHandle(cb, 2);
            }
            /*void */ ToManaged$47(/*out object?*/ value)
            {
                if (this.slot.Type === 0/*MarshalerType.None*/)
                {
                    value.$v = null;
                }
                else if (this.slot.Type === 14/*MarshalerType.Object*/)
                {
                    value.$v = ($.$spc.System.Runtime.InteropServices.GCHandle.op_Explicit(this.slot.GCHandle)).Target;
                }
                else if (this.slot.Type === 3/*MarshalerType.Boolean*/)
                {
                    /*bool*/ let v;
                    this.ToManaged$16($.$ref(() => v, ($v) => v = $v, $.$spc.System.Boolean));
                    value.$v = $.$box(v, $.$spc.System.Boolean);
                }
                else if (this.slot.Type === 10/*MarshalerType.Double*/)
                {
                    /*double*/ let v;
                    this.ToManaged$4($.$ref(() => v, ($v) => v = $v, $.$spc.System.Double));
                    value.$v = $.$box(v, $.$spc.System.Double);
                }
                else if (this.slot.Type === 13/*MarshalerType.JSObject*/)
                {
                    /*JSObject?*/ let val;
                    this.ToManaged$35($.$ref(() => val, ($v) => val = $v, $.$srij.System.Runtime.InteropServices.JavaScript.JSObject));
                    value.$v = val;
                }
                else if (this.slot.Type === 15/*MarshalerType.String*/)
                {
                    /*string?*/ let val;
                    this.ToManaged$25($.$ref(() => val, ($v) => val = $v, $.$spc.System.String));
                    value.$v = val;
                }
                else if (this.slot.Type === 16/*MarshalerType.Exception*/)
                {
                    /*Exception?*/ let val;
                    this.ToManaged$24($.$ref(() => val, ($v) => val = $v, $.$spc.System.Exception));
                    value.$v = val;
                }
                else if (this.slot.Type === 17/*MarshalerType.DateTime*/)
                {
                    /*DateTime?*/ let val;
                    this.ToManaged$21($.$ref(() => val, ($v) => val = $v, $.$typeNullable($.$spc.System.DateTime)));
                    value.$v = val?.Clone() ?? null;
                }
                else if (this.slot.Type === 27/*MarshalerType.JSException*/)
                {
                    /*Exception?*/ let val;
                    this.ToManaged$24($.$ref(() => val, ($v) => val = $v, $.$spc.System.Exception));
                    value.$v = val;
                }
                else if (this.slot.Type === 21/*MarshalerType.Array*/)
                {
                    if (this.slot.ElementType === 4/*MarshalerType.Byte*/)
                    {
                        /*byte[]?*/ let val;
                        this.ToManaged$13($.$ref(() => val, ($v) => val = $v, $.$typeArray($.$spc.System.Byte)));
                        value.$v = val;
                    }
                    else if (this.slot.ElementType === 10/*MarshalerType.Double*/)
                    {
                        /*double[]?*/ let val;
                        this.ToManaged$6($.$ref(() => val, ($v) => val = $v, $.$typeArray($.$spc.System.Double)));
                        value.$v = val;
                    }
                    else if (this.slot.ElementType === 7/*MarshalerType.Int32*/)
                    {
                        /*int[]?*/ let val;
                        this.ToManaged$32($.$ref(() => val, ($v) => val = $v, $.$typeArray($.$spc.System.Int32)));
                        value.$v = val;
                    }
                    else if (this.slot.ElementType === 14/*MarshalerType.Object*/)
                    {
                        /*object?[]?*/ let val;
                        this.ToManaged$48($.$ref(() => val, ($v) => val = $v, $.$typeArray($.$spc.System.Object)));
                        value.$v = val;
                    }
                    else 
                    {
                        throw new $.$spc.System.NotSupportedException().$ctor$10($.$srij.System.SR.Format($.$srij.System.SR.ToManagedNotImplemented, $.$spc.System.Enum.ToString.call(this.slot.ElementType) + "[]"));
                    }
                }
                else if (this.slot.Type === 20/*MarshalerType.Task*/ || this.slot.Type === 28/*MarshalerType.TaskResolved*/ || this.slot.Type === 29/*MarshalerType.TaskRejected*/)
                {
                    /*Task<object?>?*/ let val;
                    this.ToManaged$38($.$spc.System.Object, $.$ref(() => val, ($v) => val = $v, $.$spc.System.Threading.Tasks.Task$$($.$spc.System.Object)), new ($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument.ArgumentToManagedCallback$$($.$spc.System.Object))().$ctor($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument, /*static*/ (/*JSMarshalerArgument*/ arg, /*object?*/ value) =>
                    {
                        arg.$v.ToManaged$47(value);
                    }, {"r":65537,"p":[{"n":"arg","p":1371529,"f":4},{"n":"value","p":131073,"f":2}],"n":"","d":1371529,"h":0,"f":1048610}));
                    value.$v = val;
                }
                else 
                {
                    throw new $.$spc.System.NotSupportedException().$ctor$10($.$srij.System.SR.Format($.$srij.System.SR.ToManagedNotImplemented, $.$box(this.slot.Type, $.$srij.System.Runtime.InteropServices.JavaScript.MarshalerType)));
                }
            }
            /*void */ ToJS$47(/*object?*/ value)
            {
                if (value === null)
                {
                    this.slot.Type = 0/*MarshalerType.None*/;
                    return;
                }
                /*Type*/ let type = $.$spc.System.Object.GetType.call(value);
                let ut;
                if (type.IsPrimitive)
                {
                    if ($.$spc.System.Type.op_Equality$1($.$spc.System.Int64.$type, type))
                    {
                        throw new $.$spc.System.NotSupportedException().$ctor$10($.$srij.System.SR.Format($.$srij.System.SR.ToJSNotImplemented, type.FullName));
                    }
                    else if ($.$spc.System.Type.op_Equality$1($.$spc.System.Int32.$type, type))
                    {
                        /*var*/ let v = $.$cast(value, $.$spc.System.Int32);
                        this.ToJS$30(v);
                    }
                    else if ($.$spc.System.Type.op_Equality$1($.$spc.System.Int16.$type, type))
                    {
                        /*var*/ let v = $.$cast(value, $.$spc.System.Int16);
                        this.ToJS$9(v);
                    }
                    else if ($.$spc.System.Type.op_Equality$1($.$spc.System.Byte.$type, type))
                    {
                        /*var*/ let v = $.$cast(value, $.$spc.System.Byte);
                        this.ToJS$11(v);
                    }
                    else if ($.$spc.System.Type.op_Equality$1($.$spc.System.Char.$type, type))
                    {
                        /*var*/ let v = $.$cast(value, $.$spc.System.Char);
                        this.ToJS$22(v);
                    }
                    else if ($.$spc.System.Type.op_Equality$1($.$spc.System.Boolean.$type, type))
                    {
                        /*var*/ let v = $.$cast(value, $.$spc.System.Boolean);
                        this.ToJS$16(v);
                    }
                    else if ($.$spc.System.Type.op_Equality$1($.$spc.System.Double.$type, type))
                    {
                        /*var*/ let v = $.$cast(value, $.$spc.System.Double);
                        this.ToJS$4(v);
                    }
                    else if ($.$spc.System.Type.op_Equality$1($.$spc.System.Single.$type, type))
                    {
                        /*var*/ let v = $.$cast(value, $.$spc.System.Single);
                        this.ToJS(v);
                    }
                    else if ($.$spc.System.Type.op_Equality$1($.$spc.System.IntPtr.$type, type))
                    {
                        /*var*/ let v = $.$cast(value, $.$spc.System.IntPtr);
                        this.ToJS$27(v);
                    }
                    else 
                    {
                        throw new $.$spc.System.NotSupportedException().$ctor$10($.$srij.System.SR.Format($.$srij.System.SR.ToJSNotImplemented, type.FullName));
                    }
                }
                else if ($.$spc.System.Type.op_Equality$1($.$spc.System.String.$type, type))
                {
                    /*string?*/ let str = $.$as(value, $.$spc.System.String);
                    this.ToJS$25(str);
                }
                else if ($.$spc.System.Type.op_Equality$1($.$spc.System.DateTimeOffset.$type, type))
                {
                    /*var*/ let v = $.$cast(value, $.$spc.System.DateTimeOffset);
                    this.ToJS$18(v);
                }
                else if ($.$spc.System.Type.op_Equality$1($.$spc.System.DateTime.$type, type))
                {
                    /*var*/ let v = $.$cast(value, $.$spc.System.DateTime);
                    this.ToJS$20(v);
                }
                else if ($.$is($.$spc.System.Nullable.GetUnderlyingType(type), $.$spc.System.Type, { set $v(v){ ut = v; } }) && $.$spc.System.Type.op_Inequality$1(ut, null))
                {
                    if ($.$spc.System.Type.op_Equality$1($.$spc.System.Int64.$type, ut))
                    {
                        throw new $.$spc.System.NotSupportedException().$ctor$10($.$srij.System.SR.Format($.$srij.System.SR.ToJSNotImplemented, type.FullName));
                    }
                    else if ($.$spc.System.Type.op_Equality$1($.$spc.System.Int32.$type, ut))
                    {
                        /*var*/ let nv = $.$as(value, $.$spc.System.Int32);
                        this.ToJS$31(nv);
                    }
                    else if ($.$spc.System.Type.op_Equality$1($.$spc.System.Int16.$type, ut))
                    {
                        /*var*/ let nv = $.$as(value, $.$spc.System.Int16);
                        this.ToJS$10(nv);
                    }
                    else if ($.$spc.System.Type.op_Equality$1($.$spc.System.Byte.$type, ut))
                    {
                        /*var*/ let nv = $.$as(value, $.$spc.System.Byte);
                        this.ToJS$12(nv);
                    }
                    else if ($.$spc.System.Type.op_Equality$1($.$spc.System.Char.$type, ut))
                    {
                        /*var*/ let nv = $.$as(value, $.$spc.System.Char);
                        this.ToJS$23(nv);
                    }
                    else if ($.$spc.System.Type.op_Equality$1($.$spc.System.Boolean.$type, ut))
                    {
                        /*var*/ let nv = $.$as(value, $.$spc.System.Boolean);
                        this.ToJS$17(nv);
                    }
                    else if ($.$spc.System.Type.op_Equality$1($.$spc.System.Double.$type, ut))
                    {
                        /*var*/ let nv = $.$as(value, $.$spc.System.Double);
                        this.ToJS$5(nv);
                    }
                    else if ($.$spc.System.Type.op_Equality$1($.$spc.System.Single.$type, ut))
                    {
                        /*var*/ let nv = $.$as(value, $.$spc.System.Single);
                        this.ToJS$1(nv);
                    }
                    else if ($.$spc.System.Type.op_Equality$1($.$spc.System.IntPtr.$type, ut))
                    {
                        /*var*/ let nv = $.$as(value, $.$spc.System.IntPtr);
                        this.ToJS$28(nv);
                    }
                    else if ($.$spc.System.Type.op_Equality$1($.$spc.System.DateTimeOffset.$type, ut))
                    {
                        /*var*/ let nv = $.$as(value, $.$spc.System.DateTimeOffset);
                        this.ToJS$19(nv?.Clone() ?? null);
                    }
                    else if ($.$spc.System.Type.op_Equality$1($.$spc.System.DateTime.$type, ut))
                    {
                        /*var*/ let nv = $.$as(value, $.$spc.System.DateTime);
                        this.ToJS$21(nv?.Clone() ?? null);
                    }
                    else 
                    {
                        throw new $.$spc.System.NotSupportedException().$ctor$10($.$srij.System.SR.Format($.$srij.System.SR.ToJSNotImplemented, type.FullName));
                    }
                }
                else if ($.$srij.System.Runtime.InteropServices.JavaScript.JSObject.$type.IsAssignableFrom(type))
                {
                    /*JSObject?*/ let val = $.$as(value, $.$srij.System.Runtime.InteropServices.JavaScript.JSObject);
                    this.ToJS$35(val);
                }
                else if ($.$spc.System.Exception.$type.IsAssignableFrom(type))
                {
                    /*Exception?*/ let val = $.$as(value, $.$spc.System.Exception);
                    this.ToJS$24(val);
                }
                else if ($.$spc.System.Type.op_Equality$1($.$spc.System.Threading.Tasks.Task$$($.$spc.System.Object).$type, type))
                {
                    /*Task<object>?*/ let val = $.$as(value, $.$spc.System.Threading.Tasks.Task$$($.$spc.System.Object));
                    this.ToJS$38($.$spc.System.Object, val, new ($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument.ArgumentToJSCallback$$($.$spc.System.Object))().$ctor(this,  (/*JSMarshalerArgument*/ arg, /*object*/ value) =>
                    {
                        /*object?*/ let valueRef = value;
                        arg.$v.ToJS$47(valueRef);
                    }, {"r":65537,"p":[{"n":"arg","p":1371529,"f":4},{"n":"value","p":131073}],"n":"","d":1371529,"h":0,"f":1048578}));
                }
                else if ($.$spc.System.Threading.Tasks.Task.$type.IsAssignableFrom(type))
                {
                    /*Task?*/ let val = $.$as(value, $.$spc.System.Threading.Tasks.Task);
                    this.ToJSDynamic(val);
                }
                else if ($.$spc.System.Type.op_Equality$1($.$typeArray($.$spc.System.Byte).$type, type))
                {
                    /*byte[]*/ let val = $.$cast(value, $.$typeArray($.$spc.System.Byte));
                    this.ToJS$13(val);
                }
                else if ($.$spc.System.Type.op_Equality$1($.$typeArray($.$spc.System.Int32).$type, type))
                {
                    /*int[]*/ let val = $.$cast(value, $.$typeArray($.$spc.System.Int32));
                    this.ToJS$32(val);
                }
                else if ($.$spc.System.Type.op_Equality$1($.$typeArray($.$spc.System.Double).$type, type))
                {
                    /*double[]*/ let val = $.$cast(value, $.$typeArray($.$spc.System.Double));
                    this.ToJS$6(val);
                }
                else if ($.$spc.System.Type.op_Equality$1($.$typeArray($.$spc.System.String).$type, type))
                {
                    /*string[]*/ let val = $.$cast(value, $.$typeArray($.$spc.System.String));
                    this.ToJS$26(val);
                }
                else if ($.$spc.System.Type.op_Equality$1($.$typeArray($.$spc.System.Object).$type, type))
                {
                    /*object[]*/ let val = $.$cast(value, $.$typeArray($.$spc.System.Object));
                    this.ToJS$48(val);
                }
                else if (type.IsArray)
                {
                    throw new $.$spc.System.NotSupportedException().$ctor$10($.$srij.System.SR.Format($.$srij.System.SR.ToJSNotImplemented, type.FullName));
                }
                else if ($.$spc.System.MulticastDelegate.$type.IsAssignableFrom(type.BaseType))
                {
                    throw new $.$spc.System.NotSupportedException().$ctor$10($.$srij.System.SR.Format($.$srij.System.SR.ToJSNotImplemented, type.FullName));
                }
                else if (type.IsGenericType && $.$spc.System.Type.op_Equality$1(type.GetGenericTypeDefinition(), $.$spc.System.ArraySegment$$().$type))
                {
                    throw new $.$spc.System.NotSupportedException().$ctor$10($.$srij.System.SR.Format($.$srij.System.SR.ToJSNotImplemented, type.FullName));
                }
                else if (type.IsGenericType && $.$spc.System.Type.op_Equality$1(type.GetGenericTypeDefinition(), $.$spc.System.Span$$().$type))
                {
                    throw new $.$spc.System.NotSupportedException().$ctor$10($.$srij.System.SR.Format($.$srij.System.SR.ToJSNotImplemented, type.FullName));
                }
                else 
                {
                    this.slot.Type = 14/*MarshalerType.Object*/;
                    /*var*/ let ctx = this.ToJSContext;
                    this.slot.GCHandle = ctx.GetJSOwnedObjectGCHandle(value, 2);
                }
            }
            /*void */ ToManaged$48(/*out object?[]?*/ value)
            {
                if (this.slot.Type === 0/*MarshalerType.None*/)
                {
                    value.$v = null;
                    return;
                }
                value.$v = $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$spc.System.Object), null, [this.slot.Length], null);
                /*JSMarshalerArgument**/ let payload = $.$cast(this.slot.IntPtrValue, $.$typePointer($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument));
                for(/*int*/ let i = 0; i < this.slot.Length; i++)
                {
                    /*ref JSMarshalerArgument*/ let arg = payload.Add(i);
                    /*object?*/ let val;
                    arg.$v.ToManaged$47($.$ref(() => val, ($v) => val = $v, $.$spc.System.Object));
                    $.$spc.System.Array.$WriteT1.call(value.$v, val, i);
                }
                $.$srij.Interop.Runtime.DeregisterGCRoot(this.slot.IntPtrValue);
                $.$spc.System.Runtime.InteropServices.Marshal.FreeHGlobal(this.slot.IntPtrValue);
            }
            /*void */ ToJS$48(/*object?[]*/ value)
            {
                if (value === null)
                {
                    this.slot.Type = 0/*MarshalerType.None*/;
                    return;
                }
                this.slot.Length = value.length;
                /*int*/ let bytes = ((value.length * $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument.$z) | 0);
                this.slot.Type = 21/*MarshalerType.Array*/;
                /*JSMarshalerArgument**/ let payload = $.$cast($.$spc.System.Runtime.InteropServices.Marshal.AllocHGlobal(bytes), $.$typePointer($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument));
                $.$spc.System.Runtime.CompilerServices.Unsafe.InitBlock(payload, 0, (bytes >>> 0));
                $.$srij.Interop.Runtime.RegisterGCRoot(payload, bytes, $.$spc.System.IntPtr.Zero);
                for(/*int*/ let i = 0; i < this.slot.Length; i++)
                {
                    /*ref JSMarshalerArgument*/ let arg = payload.Add(i);
                    /*object?*/ let val = $.$spc.System.Array.$ReadT1.call(value, i);
                    arg.$v.ToJS$47(val);
                    $.$spc.System.Array.$WriteT1.call(value, val, i);
                }
                this.slot.ElementType = 14/*MarshalerType.Object*/;
                this.slot.IntPtrValue = $.$cast(payload, $.$spc.System.IntPtr);
            }
            //default value type constructor
            $ctor$2()
            {
                return this;
            }
            Clone($copy)
            {
                let copy = $copy ?? new this.constructor();
                copy.slot = this.slot.Clone();
                return copy;
            }
            //default member initializer
            constructor()
            {
                super();
                this.slot = $.$default($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument.JSMarshalerArgumentImpl);
            }
            static $h = 1371529;
            static $z = 32;
            static $f = 0b1010000001;
            static $k = 2;
            static $$md;
            static get $md() { return this.$$md ??= {"b":196609,"p":[{"p":2354569,"g":{"r":0,"d":0,"h":21476208009,"f":8},"n":"ToManagedContext","d":1371529,"h":17181240713,"f":8},{"p":2354569,"g":{"r":0,"d":0,"h":30066142601,"f":8},"n":"ToJSContext","d":1371529,"h":25771175305,"f":8}],"m":[{"r":65537,"n":"Initialize","d":1371529,"h":12886273417,"f":1},{"r":2354569,"n":"AssertCurrentThreadContext","d":1371529,"h":34361109897,"f":8},{"r":65537,"p":[{"n":"value","p":917505,"f":2}],"n":"ToManagedBig","d":1371529,"h":38656077193,"f":1},{"r":65537,"p":[{"n":"value","p":917505}],"n":"ToJSBig","d":1371529,"h":42951044489,"f":1},{"r":65537,"p":[{"n":"value","p":$.$typeNullable($.$spc.System.Int64).$h,"f":2}],"n":"ToManagedBig","o":"@$1","d":1371529,"h":47246011785,"f":1},{"r":65537,"p":[{"n":"value","p":$.$typeNullable($.$spc.System.Int64).$h}],"n":"ToJSBig","o":"@$1","d":1371529,"h":51540979081,"f":1},{"r":65537,"p":[{"n":"value","p":1114113,"f":2}],"n":"ToManaged","d":1371529,"h":55835946377,"f":1},{"r":65537,"p":[{"n":"value","p":1114113}],"n":"ToJS","d":1371529,"h":60130913673,"f":1},{"r":65537,"p":[{"n":"value","p":$.$typeNullable($.$spc.System.Single).$h,"f":2}],"n":"ToManaged","o":"@$1","d":1371529,"h":64425880969,"f":1},{"r":65537,"p":[{"n":"value","p":$.$typeNullable($.$spc.System.Single).$h}],"n":"ToJS","o":"@$1","d":1371529,"h":68720848265,"f":1},{"r":65537,"p":[{"n":"value","p":917505,"f":2}],"n":"ToManaged","o":"@$2","d":1371529,"h":81605750153,"f":1},{"r":65537,"p":[{"n":"value","p":917505}],"n":"ToJS","o":"@$2","d":1371529,"h":85900717449,"f":1},{"r":65537,"p":[{"n":"value","p":$.$typeNullable($.$spc.System.Int64).$h,"f":2}],"n":"ToManaged","o":"@$3","d":1371529,"h":90195684745,"f":1},{"r":65537,"p":[{"n":"value","p":$.$typeNullable($.$spc.System.Int64).$h}],"n":"ToJS","o":"@$3","d":1371529,"h":94490652041,"f":1},{"r":65537,"p":[{"n":"value","p":1179649,"f":2}],"n":"ToManaged","o":"@$4","d":1371529,"h":98785619337,"f":1},{"r":65537,"p":[{"n":"value","p":1179649}],"n":"ToJS","o":"@$4","d":1371529,"h":103080586633,"f":1},{"r":65537,"p":[{"n":"value","p":$.$typeNullable($.$spc.System.Double).$h,"f":2}],"n":"ToManaged","o":"@$5","d":1371529,"h":107375553929,"f":1},{"r":65537,"p":[{"n":"value","p":$.$typeNullable($.$spc.System.Double).$h}],"n":"ToJS","o":"@$5","d":1371529,"h":111670521225,"f":1},{"r":65537,"p":[{"n":"value","p":0,"f":2}],"n":"ToManaged","o":"@$6","d":1371529,"h":115965488521,"f":1},{"r":65537,"p":[{"n":"value","p":0}],"n":"ToJS","o":"@$6","d":1371529,"h":120260455817,"f":1},{"r":65537,"p":[{"n":"value","p":$.$spc.System.ArraySegment$$($.$spc.System.Double).$h,"f":2}],"n":"ToManaged","o":"@$7","d":1371529,"h":124555423113,"f":1},{"r":65537,"p":[{"n":"value","p":$.$spc.System.ArraySegment$$($.$spc.System.Double).$h}],"n":"ToJS","o":"@$7","d":1371529,"h":128850390409,"f":1},{"r":65537,"p":[{"n":"value","p":$.$spc.System.Span$$($.$spc.System.Double).$h,"f":2}],"n":"ToManaged","o":"@$8","d":1371529,"h":133145357705,"f":1},{"r":65537,"p":[{"n":"value","p":$.$spc.System.Span$$($.$spc.System.Double).$h}],"n":"ToJS","o":"@$8","d":1371529,"h":137440325001,"f":1},{"r":65537,"p":[{"n":"value","p":524289,"f":2}],"n":"ToManaged","o":"@$9","d":1371529,"h":141735292297,"f":1},{"r":65537,"p":[{"n":"value","p":524289}],"n":"ToJS","o":"@$9","d":1371529,"h":146030259593,"f":1},{"r":65537,"p":[{"n":"value","p":$.$typeNullable($.$spc.System.Int16).$h,"f":2}],"n":"ToManaged","o":"@$10","d":1371529,"h":150325226889,"f":1},{"r":65537,"p":[{"n":"value","p":$.$typeNullable($.$spc.System.Int16).$h}],"n":"ToJS","o":"@$10","d":1371529,"h":154620194185,"f":1},{"r":65537,"p":[{"n":"value","p":393217,"f":2}],"n":"ToManaged","o":"@$11","d":1371529,"h":158915161481,"f":1},{"r":65537,"p":[{"n":"value","p":393217}],"n":"ToJS","o":"@$11","d":1371529,"h":163210128777,"f":1},{"r":65537,"p":[{"n":"value","p":$.$typeNullable($.$spc.System.Byte).$h,"f":2}],"n":"ToManaged","o":"@$12","d":1371529,"h":167505096073,"f":1},{"r":65537,"p":[{"n":"value","p":$.$typeNullable($.$spc.System.Byte).$h}],"n":"ToJS","o":"@$12","d":1371529,"h":171800063369,"f":1},{"r":65537,"p":[{"n":"value","p":0,"f":2}],"n":"ToManaged","o":"@$13","d":1371529,"h":176095030665,"f":1},{"r":65537,"p":[{"n":"value","p":0}],"n":"ToJS","o":"@$13","d":1371529,"h":180389997961,"f":1},{"r":65537,"p":[{"n":"value","p":$.$spc.System.ArraySegment$$($.$spc.System.Byte).$h,"f":2}],"n":"ToManaged","o":"@$14","d":1371529,"h":184684965257,"f":1},{"r":65537,"p":[{"n":"value","p":$.$spc.System.ArraySegment$$($.$spc.System.Byte).$h}],"n":"ToJS","o":"@$14","d":1371529,"h":188979932553,"f":1},{"r":65537,"p":[{"n":"value","p":$.$spc.System.Span$$($.$spc.System.Byte).$h,"f":2}],"n":"ToManaged","o":"@$15","d":1371529,"h":193274899849,"f":1},{"r":65537,"p":[{"n":"value","p":$.$spc.System.Span$$($.$spc.System.Byte).$h}],"n":"ToJS","o":"@$15","d":1371529,"h":197569867145,"f":1},{"r":65537,"p":[{"n":"value","p":262145,"f":2}],"n":"ToManaged","o":"@$16","d":1371529,"h":201864834441,"f":1},{"r":65537,"p":[{"n":"value","p":262145}],"n":"ToJS","o":"@$16","d":1371529,"h":206159801737,"f":1},{"r":65537,"p":[{"n":"value","p":$.$typeNullable($.$spc.System.Boolean).$h,"f":2}],"n":"ToManaged","o":"@$17","d":1371529,"h":210454769033,"f":1},{"r":65537,"p":[{"n":"value","p":$.$typeNullable($.$spc.System.Boolean).$h}],"n":"ToJS","o":"@$17","d":1371529,"h":214749736329,"f":1},{"r":65537,"p":[{"n":"value","p":34406401,"f":2}],"n":"ToManaged","o":"@$18","d":1371529,"h":219044703625,"f":1},{"r":65537,"p":[{"n":"value","p":34406401}],"n":"ToJS","o":"@$18","d":1371529,"h":223339670921,"f":1},{"r":65537,"p":[{"n":"value","p":$.$typeNullable($.$spc.System.DateTimeOffset).$h,"f":2}],"n":"ToManaged","o":"@$19","d":1371529,"h":227634638217,"f":1},{"r":65537,"p":[{"n":"value","p":$.$typeNullable($.$spc.System.DateTimeOffset).$h}],"n":"ToJS","o":"@$19","d":1371529,"h":231929605513,"f":1},{"r":65537,"p":[{"n":"value","p":34209793,"f":2}],"n":"ToManaged","o":"@$20","d":1371529,"h":236224572809,"f":1},{"r":65537,"p":[{"n":"value","p":34209793}],"n":"ToJS","o":"@$20","d":1371529,"h":240519540105,"f":1},{"r":65537,"p":[{"n":"value","p":$.$typeNullable($.$spc.System.DateTime).$h,"f":2}],"n":"ToManaged","o":"@$21","d":1371529,"h":244814507401,"f":1},{"r":65537,"p":[{"n":"value","p":$.$typeNullable($.$spc.System.DateTime).$h}],"n":"ToJS","o":"@$21","d":1371529,"h":249109474697,"f":1},{"r":65537,"p":[{"n":"value","p":458753,"f":2}],"n":"ToManaged","o":"@$22","d":1371529,"h":253404441993,"f":1},{"r":65537,"p":[{"n":"value","p":458753}],"n":"ToJS","o":"@$22","d":1371529,"h":257699409289,"f":1},{"r":65537,"p":[{"n":"value","p":$.$typeNullable($.$spc.System.Char).$h,"f":2}],"n":"ToManaged","o":"@$23","d":1371529,"h":261994376585,"f":1},{"r":65537,"p":[{"n":"value","p":$.$typeNullable($.$spc.System.Char).$h}],"n":"ToJS","o":"@$23","d":1371529,"h":266289343881,"f":1},{"r":65537,"p":[{"n":"value","p":47251457,"f":2}],"n":"ToManaged","o":"@$24","d":1371529,"h":270584311177,"f":1},{"r":65537,"p":[{"n":"value","p":47251457}],"n":"ToJS","o":"@$24","d":1371529,"h":274879278473,"f":1},{"r":65537,"p":[{"n":"value","p":1310721,"f":2}],"n":"ToManaged","o":"@$25","d":1371529,"h":279174245769,"f":1},{"r":65537,"p":[{"n":"value","p":1310721}],"n":"ToJS","o":"@$25","d":1371529,"h":283469213065,"f":1},{"r":65537,"p":[{"n":"value","p":0,"f":2}],"n":"ToManaged","o":"@$26","d":1371529,"h":287764180361,"f":1},{"r":65537,"p":[{"n":"value","p":0}],"n":"ToJS","o":"@$26","d":1371529,"h":292059147657,"f":1},{"r":65537,"p":[{"n":"value","p":786433,"f":2}],"n":"ToManaged","o":"@$27","d":1371529,"h":296354114953,"f":1},{"r":65537,"p":[{"n":"value","p":786433}],"n":"ToJS","o":"@$27","d":1371529,"h":300649082249,"f":1},{"r":65537,"p":[{"n":"value","p":$.$typeNullable($.$spc.System.IntPtr).$h,"f":2}],"n":"ToManaged","o":"@$28","d":1371529,"h":304944049545,"f":1},{"r":65537,"p":[{"n":"value","p":$.$typeNullable($.$spc.System.IntPtr).$h}],"n":"ToJS","o":"@$28","d":1371529,"h":309239016841,"f":1},{"r":65537,"p":[{"n":"value","p":0,"f":2}],"n":"ToManaged","o":"@$29","d":1371529,"h":313533984137,"f":1},{"r":65537,"p":[{"n":"value","p":0}],"n":"ToJS","o":"@$29","d":1371529,"h":317828951433,"f":1},{"r":65537,"p":[{"n":"value","p":655361,"f":2}],"n":"ToManaged","o":"@$30","d":1371529,"h":322123918729,"f":1},{"r":65537,"p":[{"n":"value","p":655361}],"n":"ToJS","o":"@$30","d":1371529,"h":326418886025,"f":1},{"r":65537,"p":[{"n":"value","p":$.$typeNullable($.$spc.System.Int32).$h,"f":2}],"n":"ToManaged","o":"@$31","d":1371529,"h":330713853321,"f":1},{"r":65537,"p":[{"n":"value","p":$.$typeNullable($.$spc.System.Int32).$h}],"n":"ToJS","o":"@$31","d":1371529,"h":335008820617,"f":1},{"r":65537,"p":[{"n":"value","p":0,"f":2}],"n":"ToManaged","o":"@$32","d":1371529,"h":339303787913,"f":1},{"r":65537,"p":[{"n":"value","p":0}],"n":"ToJS","o":"@$32","d":1371529,"h":343598755209,"f":1},{"r":65537,"p":[{"n":"value","p":$.$spc.System.ArraySegment$$($.$spc.System.Int32).$h,"f":2}],"n":"ToManaged","o":"@$33","d":1371529,"h":347893722505,"f":1},{"r":65537,"p":[{"n":"value","p":$.$spc.System.ArraySegment$$($.$spc.System.Int32).$h}],"n":"ToJS","o":"@$33","d":1371529,"h":352188689801,"f":1},{"r":65537,"p":[{"n":"value","p":$.$spc.System.Span$$($.$spc.System.Int32).$h,"f":2}],"n":"ToManaged","o":"@$34","d":1371529,"h":356483657097,"f":1},{"r":65537,"p":[{"n":"value","p":$.$spc.System.Span$$($.$spc.System.Int32).$h}],"n":"ToJS","o":"@$34","d":1371529,"h":360778624393,"f":1},{"r":65537,"p":[{"n":"value","p":2289033,"f":2}],"n":"ToManaged","o":"@$35","d":1371529,"h":365073591689,"f":1},{"r":65537,"p":[{"n":"value","p":2289033}],"n":"ToJS","o":"@$35","d":1371529,"h":369368558985,"f":1},{"r":65537,"p":[{"n":"value","p":0,"f":2}],"n":"ToManaged","o":"@$36","d":1371529,"h":373663526281,"f":1},{"r":65537,"p":[{"n":"value","p":0}],"n":"ToJS","o":"@$36","d":1371529,"h":377958493577,"f":1},{"r":65537,"p":[{"n":"value","p":133300225,"f":2}],"n":"ToManaged","o":"@$37","d":1371529,"h":390843395465,"f":1},{"r":65537,"p":[{"n":"value","p":(T) => $.$spc.System.Threading.Tasks.Task$$(T).$h,"f":2},{"n":"marshaler","p":(T) => $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument.ArgumentToManagedCallback$$(T).$h}],"g":["T"],"n":"ToManaged","o":"@$38","d":1371529,"h":395138362761,"f":131073},{"r":65537,"p":[{"n":"value","p":133300225}],"n":"ToJSDynamic","d":1371529,"h":399433330057,"f":8},{"r":65537,"p":[{"n":"value","p":133300225}],"n":"ToJS","o":"@$37","d":1371529,"h":403728297353,"f":1},{"r":65537,"p":[{"n":"value","p":(T) => $.$spc.System.Threading.Tasks.Task$$(T).$h},{"n":"marshaler","p":(T) => $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument.ArgumentToJSCallback$$(T).$h}],"g":["T"],"n":"ToJS","o":"@$38","d":1371529,"h":408023264649,"f":131073},{"r":262145,"p":[{"n":"_","p":2354569}],"n":"CanMarshalTaskResultOnSameCall","d":1371529,"h":412318231945,"f":2},{"r":65537,"p":[{"n":"holder","p":2289033},{"n":"ex","p":47251457}],"n":"RejectPromise","d":1371529,"h":420908166537,"f":34},{"r":65537,"p":[{"n":"holder","p":2289033}],"n":"ResolveVoidPromise","d":1371529,"h":425203133833,"f":34},{"r":65537,"p":[{"n":"holder","p":2289033},{"n":"value","p":(T) => T.$h},{"n":"marshaler","p":(T) => $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument.ArgumentToJSCallback$$(T).$h}],"g":["T"],"n":"ResolvePromise","d":1371529,"h":429498101129,"f":131106},{"r":65537,"p":[{"n":"value","p":11665409,"f":2}],"n":"ToManaged","o":"@$39","d":1371529,"h":450972937609,"f":1},{"r":65537,"p":[{"n":"value","p":(T) => $.$spc.System.Action$$(T).$h,"f":2},{"n":"arg1Marshaler","p":(T) => $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument.ArgumentToJSCallback$$(T).$h}],"g":["T"],"n":"ToManaged","o":"@$40","d":1371529,"h":455267904905,"f":131073},{"r":65537,"p":[{"n":"value","p":(T1, T2) => $.$spc.System.Action$$$(T1, T2).$h,"f":2},{"n":"arg1Marshaler","p":(T1, T2) => $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument.ArgumentToJSCallback$$(T1).$h},{"n":"arg2Marshaler","p":(T1, T2) => $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument.ArgumentToJSCallback$$(T2).$h}],"g":["T1","T2"],"n":"ToManaged","o":"@$41","d":1371529,"h":459562872201,"f":131073},{"r":65537,"p":[{"n":"value","p":(T1, T2, T3) => $.$spc.System.Action$$$$(T1, T2, T3).$h,"f":2},{"n":"arg1Marshaler","p":(T1, T2, T3) => $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument.ArgumentToJSCallback$$(T1).$h},{"n":"arg2Marshaler","p":(T1, T2, T3) => $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument.ArgumentToJSCallback$$(T2).$h},{"n":"arg3Marshaler","p":(T1, T2, T3) => $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument.ArgumentToJSCallback$$(T3).$h}],"g":["T1","T2","T3"],"n":"ToManaged","o":"@$42","d":1371529,"h":463857839497,"f":131073},{"r":65537,"p":[{"n":"value","p":(TResult) => $.$spc.System.Func$$(TResult).$h,"f":2},{"n":"resMarshaler","p":(TResult) => $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument.ArgumentToManagedCallback$$(TResult).$h}],"g":["TResult"],"n":"ToManaged","o":"@$43","d":1371529,"h":485332675977,"f":131073},{"r":65537,"p":[{"n":"value","p":(T, TResult) => $.$spc.System.Func$$$(T, TResult).$h,"f":2},{"n":"arg1Marshaler","p":(T, TResult) => $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument.ArgumentToJSCallback$$(T).$h},{"n":"resMarshaler","p":(T, TResult) => $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument.ArgumentToManagedCallback$$(TResult).$h}],"g":["T","TResult"],"n":"ToManaged","o":"@$44","d":1371529,"h":489627643273,"f":131073},{"r":65537,"p":[{"n":"value","p":(T1, T2, TResult) => $.$spc.System.Func$$$$(T1, T2, TResult).$h,"f":2},{"n":"arg1Marshaler","p":(T1, T2, TResult) => $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument.ArgumentToJSCallback$$(T1).$h},{"n":"arg2Marshaler","p":(T1, T2, TResult) => $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument.ArgumentToJSCallback$$(T2).$h},{"n":"resMarshaler","p":(T1, T2, TResult) => $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument.ArgumentToManagedCallback$$(TResult).$h}],"g":["T1","T2","TResult"],"n":"ToManaged","o":"@$45","d":1371529,"h":493922610569,"f":131073},{"r":65537,"p":[{"n":"value","p":(T1, T2, T3, TResult) => $.$spc.System.Func$$$$$(T1, T2, T3, TResult).$h,"f":2},{"n":"arg1Marshaler","p":(T1, T2, T3, TResult) => $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument.ArgumentToJSCallback$$(T1).$h},{"n":"arg2Marshaler","p":(T1, T2, T3, TResult) => $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument.ArgumentToJSCallback$$(T2).$h},{"n":"arg3Marshaler","p":(T1, T2, T3, TResult) => $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument.ArgumentToJSCallback$$(T3).$h},{"n":"resMarshaler","p":(T1, T2, T3, TResult) => $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument.ArgumentToManagedCallback$$(TResult).$h}],"g":["T1","T2","T3","TResult"],"n":"ToManaged","o":"@$46","d":1371529,"h":498217577865,"f":131073},{"r":65537,"p":[{"n":"value","p":11665409}],"n":"ToJS","o":"@$39","d":1371529,"h":502512545161,"f":1},{"r":65537,"p":[{"n":"value","p":(T) => $.$spc.System.Action$$(T).$h},{"n":"arg1Marshaler","p":(T) => $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument.ArgumentToManagedCallback$$(T).$h}],"g":["T"],"n":"ToJS","o":"@$40","d":1371529,"h":506807512457,"f":131073},{"r":65537,"p":[{"n":"value","p":(T1, T2) => $.$spc.System.Action$$$(T1, T2).$h},{"n":"arg1Marshaler","p":(T1, T2) => $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument.ArgumentToManagedCallback$$(T1).$h},{"n":"arg2Marshaler","p":(T1, T2) => $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument.ArgumentToManagedCallback$$(T2).$h}],"g":["T1","T2"],"n":"ToJS","o":"@$41","d":1371529,"h":511102479753,"f":131073},{"r":65537,"p":[{"n":"value","p":(T1, T2, T3) => $.$spc.System.Action$$$$(T1, T2, T3).$h},{"n":"arg1Marshaler","p":(T1, T2, T3) => $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument.ArgumentToManagedCallback$$(T1).$h},{"n":"arg2Marshaler","p":(T1, T2, T3) => $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument.ArgumentToManagedCallback$$(T2).$h},{"n":"arg3Marshaler","p":(T1, T2, T3) => $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument.ArgumentToManagedCallback$$(T3).$h}],"g":["T1","T2","T3"],"n":"ToJS","o":"@$42","d":1371529,"h":515397447049,"f":131073},{"r":65537,"p":[{"n":"value","p":(TResult) => $.$spc.System.Func$$(TResult).$h},{"n":"resMarshaler","p":(TResult) => $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument.ArgumentToJSCallback$$(TResult).$h}],"g":["TResult"],"n":"ToJS","o":"@$43","d":1371529,"h":519692414345,"f":131073},{"r":65537,"p":[{"n":"value","p":(T, TResult) => $.$spc.System.Func$$$(T, TResult).$h},{"n":"arg1Marshaler","p":(T, TResult) => $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument.ArgumentToManagedCallback$$(T).$h},{"n":"resMarshaler","p":(T, TResult) => $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument.ArgumentToJSCallback$$(TResult).$h}],"g":["T","TResult"],"n":"ToJS","o":"@$44","d":1371529,"h":523987381641,"f":131073},{"r":65537,"p":[{"n":"value","p":(T1, T2, TResult) => $.$spc.System.Func$$$$(T1, T2, TResult).$h},{"n":"arg1Marshaler","p":(T1, T2, TResult) => $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument.ArgumentToManagedCallback$$(T1).$h},{"n":"arg2Marshaler","p":(T1, T2, TResult) => $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument.ArgumentToManagedCallback$$(T2).$h},{"n":"resMarshaler","p":(T1, T2, TResult) => $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument.ArgumentToJSCallback$$(TResult).$h}],"g":["T1","T2","TResult"],"n":"ToJS","o":"@$45","d":1371529,"h":528282348937,"f":131073},{"r":65537,"p":[{"n":"value","p":(T1, T2, T3, TResult) => $.$spc.System.Func$$$$$(T1, T2, T3, TResult).$h},{"n":"arg1Marshaler","p":(T1, T2, T3, TResult) => $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument.ArgumentToManagedCallback$$(T1).$h},{"n":"arg2Marshaler","p":(T1, T2, T3, TResult) => $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument.ArgumentToManagedCallback$$(T2).$h},{"n":"arg3Marshaler","p":(T1, T2, T3, TResult) => $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument.ArgumentToManagedCallback$$(T3).$h},{"n":"resMarshaler","p":(T1, T2, T3, TResult) => $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument.ArgumentToJSCallback$$(TResult).$h}],"g":["T1","T2","T3","TResult"],"n":"ToJS","o":"@$46","d":1371529,"h":532577316233,"f":131073},{"r":65537,"p":[{"n":"value","p":131073,"f":2}],"n":"ToManaged","o":"@$47","d":1371529,"h":536872283529,"f":1},{"r":65537,"p":[{"n":"value","p":131073}],"n":"ToJS","o":"@$47","d":1371529,"h":541167250825,"f":1},{"r":65537,"p":[{"n":"value","p":0,"f":2}],"n":"ToManaged","o":"@$48","d":1371529,"h":545462218121,"f":1},{"r":65537,"p":[{"n":"value","p":0}],"n":"ToJS","o":"@$48","d":1371529,"h":549757185417,"f":1}],"l":[{"t":2157961,"n":"slot","d":1371529,"h":4296338825,"f":8},{"t":917505,"n":"I52_MAX_VALUE","d":1371529,"h":73015815561,"f":34},{"t":917505,"n":"I52_MIN_VALUE","d":1371529,"h":77310782857,"f":34}],"c":[{"n":".ctor","o":"$ctor$2","d":1371529,"h":554052152713,"f":1}],"j":[2157961,1764745,1699209,2092425,1437065,1633673,1568137,1502601,2026889,1961353,1895817,1830281],"h":1371529,"a":[{"t":114950145,"c":4409917441,"a":[{"v":"browser","t":1310721}]},{"t":23461889,"c":8613396481,"a":[{"v":false,"t":262145}]},{"t":33226753,"c":4328194049,"a":[{"v":1,"t":33292289}]}]}; }
            static get $b() { return $.$spc.System.ValueType; }
            static get $fullName() { return `System.Runtime.InteropServices.JavaScript.JSMarshalerArgument`; }
        });
        
        $asm.$str("$srij.System.Runtime.InteropServices.JavaScript.MarshalerType", ($self) => class MarshalerType extends $.$spc.System.Enum
        {
            static None = 0;
            static Void = 1;
            static Discard = 2;
            static Boolean = 3;
            static Byte = 4;
            static Char = 5;
            static Int16 = 6;
            static Int32 = 7;
            static Int52 = 8;
            static BigInt64 = 9;
            static Double = 10;
            static Single = 11;
            static IntPtr = 12;
            static JSObject = 13;
            static Object = 14;
            static String = 15;
            static Exception = 16;
            static DateTime = 17;
            static DateTimeOffset = 18;
            static Nullable = 19;
            static Task = 20;
            static Array = 21;
            static ArraySegment = 22;
            static Span = 23;
            static Action = 24;
            static Function = 25;
            static DiscardNoWait = 26;
            static JSException = 27;
            static TaskResolved = 28;
            static TaskRejected = 29;
            static TaskPreCreated = 30;
            static $map;
            static get Map()
            {
                return this.$map ??= 
                {
                    "None": 0n,
                    "Void": 1n,
                    "Discard": 2n,
                    "Boolean": 3n,
                    "Byte": 4n,
                    "Char": 5n,
                    "Int16": 6n,
                    "Int32": 7n,
                    "Int52": 8n,
                    "BigInt64": 9n,
                    "Double": 10n,
                    "Single": 11n,
                    "IntPtr": 12n,
                    "JSObject": 13n,
                    "Object": 14n,
                    "String": 15n,
                    "Exception": 16n,
                    "DateTime": 17n,
                    "DateTimeOffset": 18n,
                    "Nullable": 19n,
                    "Task": 20n,
                    "Array": 21n,
                    "ArraySegment": 22n,
                    "Span": 23n,
                    "Action": 24n,
                    "Function": 25n,
                    "DiscardNoWait": 26n,
                    "JSException": 27n,
                    "TaskResolved": 28n,
                    "TaskRejected": 29n,
                    "TaskPreCreated": 30n
                };
            }
            static $h = 3730825;
            static $z = 1;
            static $f = 0b100000011010001000;
            static $k = 4;
            static get $eut() { return $.$spc.System.Byte; }
            static $$md;
            static get $md() { return this.$$md ??= {"b":1048577,"u":393217,"l":[{"t":3730825,"n":"None","d":3730825,"h":4298698121,"f":33},{"t":3730825,"n":"Void","d":3730825,"h":8593665417,"f":33},{"t":3730825,"n":"Discard","d":3730825,"h":12888632713,"f":33},{"t":3730825,"n":"Boolean","d":3730825,"h":17183600009,"f":33},{"t":3730825,"n":"Byte","d":3730825,"h":21478567305,"f":33},{"t":3730825,"n":"Char","d":3730825,"h":25773534601,"f":33},{"t":3730825,"n":"Int16","d":3730825,"h":30068501897,"f":33},{"t":3730825,"n":"Int32","d":3730825,"h":34363469193,"f":33},{"t":3730825,"n":"Int52","d":3730825,"h":38658436489,"f":33},{"t":3730825,"n":"BigInt64","d":3730825,"h":42953403785,"f":33},{"t":3730825,"n":"Double","d":3730825,"h":47248371081,"f":33},{"t":3730825,"n":"Single","d":3730825,"h":51543338377,"f":33},{"t":3730825,"n":"IntPtr","d":3730825,"h":55838305673,"f":33},{"t":3730825,"n":"JSObject","d":3730825,"h":60133272969,"f":33},{"t":3730825,"n":"Object","d":3730825,"h":64428240265,"f":33},{"t":3730825,"n":"String","d":3730825,"h":68723207561,"f":33},{"t":3730825,"n":"DateTime","d":3730825,"h":77313142153,"f":33},{"t":3730825,"n":"DateTimeOffset","d":3730825,"h":81608109449,"f":33},{"t":3730825,"n":"Nullable","d":3730825,"h":85903076745,"f":33},{"t":3730825,"n":"Task","d":3730825,"h":90198044041,"f":33},{"t":3730825,"n":"Array","d":3730825,"h":94493011337,"f":33},{"t":3730825,"n":"ArraySegment","d":3730825,"h":98787978633,"f":33},{"t":3730825,"n":"Span","d":3730825,"h":103082945929,"f":33},{"t":3730825,"n":"Action","d":3730825,"h":107377913225,"f":33},{"t":3730825,"n":"Function","d":3730825,"h":111672880521,"f":33},{"t":3730825,"n":"DiscardNoWait","d":3730825,"h":115967847817,"f":33},{"t":3730825,"n":"TaskResolved","d":3730825,"h":124557782409,"f":33},{"t":3730825,"n":"TaskRejected","d":3730825,"h":128852749705,"f":33},{"t":3730825,"n":"TaskPreCreated","d":3730825,"h":133147717001,"f":33}],"c":[{"n":".ctor","o":"$ctor$3","d":3730825,"h":137442684297,"f":1}],"i":[57278465,63832065,57737217,57409537],"h":3730825}; }
            static get $b() { return $.$spc.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IComparable, $.$spc.System.ISpanFormattable, $.$spc.System.IFormattable, $.$spc.System.IConvertible ]; }
            static get $fullName() { return `System.Runtime.InteropServices.JavaScript.MarshalerType`; }
        });
        
        $asm.$cls("$srij.System.Runtime.InteropServices.JavaScript.JSException", ($self) => class JSException extends $.$spc.System.Exception
        {
            /*JSObject?*/ jsException = null;
            /*string?*/ combinedStackTrace = null;
            $ctor$5(/*string*/ msg)
            {
                super.$ctor$2(msg);
                {
                    this.jsException = null;
                    this.combinedStackTrace = null;
                }
                return this;
            }
            $ctor$6(/*string*/ msg, /*JSObject?*/ jsException)
            {
                super.$ctor$2(msg);
                {
                    this.jsException = jsException;
                    this.combinedStackTrace = null;
                }
                return this;
            }
            /*string? */ get StackTrace()
            {
                if ($.$spc.System.String.op_Inequality(this.combinedStackTrace, null))
                {
                    return this.combinedStackTrace;
                }
                /*var*/ let bs = super.StackTrace;
                if (this.jsException === null)
                {
                    return bs;
                }
                /*string?*/ let jsStackTrace = this.jsException.GetPropertyAsString("stack");
                this.jsException.Dispose();
                this.jsException = null;
                if ($.$spc.System.String.op_Equality(jsStackTrace, null))
                {
                    this.combinedStackTrace = bs;
                    return this.combinedStackTrace;
                }
                else if ($.$spc.System.String.StartsWith.call(jsStackTrace, this.Message + "\n"))
                {
                    jsStackTrace = $.$spc.System.String.Substring.call(jsStackTrace, ((this.Message.length + 1) | 0));
                }
                if ($.$spc.System.String.op_Equality(bs, null))
                {
                    this.combinedStackTrace = jsStackTrace;
                }
                this.combinedStackTrace = $.$spc.System.String.op_Inequality(bs, null) ? bs + $.$spc.System.Environment.NewLine + jsStackTrace : jsStackTrace;
                return this.combinedStackTrace;
            }
            static/*conventional*/ /*bool */ Equals(/*object?*/ obj)
            {
                let other;
                return $.$is(obj, $.$srij.System.Runtime.InteropServices.JavaScript.JSException, { set $v(v){ other = v; } }) && other.jsException === this.jsException;
            }
            //Static convention instance redirect
            /*bool */ Equals() { return $.$srij.System.Runtime.InteropServices.JavaScript.JSException.Equals.apply(this, arguments); }
            static/*conventional*/ /*int */ GetHashCode()
            {
                return this.jsException === null ? $.$spc.System.Object.GetHashCode.call(this) : (($.$spc.System.Object.GetHashCode.call(this) * $.$srij.System.Runtime.InteropServices.JavaScript.JSObject.GetHashCode.call(this.jsException)) | 0);
            }
            //Static convention instance redirect
            /*int */ GetHashCode() { return $.$srij.System.Runtime.InteropServices.JavaScript.JSException.GetHashCode.apply(this, arguments); }
            static/*conventional*/ /*string */ ToString()
            {
                return this.Message;
            }
            //Static convention instance redirect
            /*string */ ToString() { return $.$srij.System.Runtime.InteropServices.JavaScript.JSException.ToString.apply(this, arguments); }
            static $h = 454025;
            static $f = 0b10010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":47251457,"h":454025}; }
            static get $b() { return $.$spc.System.Exception; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.Runtime.Serialization.ISerializable ]; }
            static get $fullName() { return `System.Runtime.InteropServices.JavaScript.JSException`; }
        });
	});
})(window, window.NetJs.$boot(), ...window.NetJs.$require("NetJs.System.Private.CoreLib", "NetJs.System.Collections", "NetJs.System.Diagnostics.Tracing", "NetJs.System.Threading", "NetJs.System.Collections.Concurrent", "NetJs.System.Memory", "NetJs.System.Private.Uri", "NetJs.System.Runtime", "NetJs.System.Threading.ThreadPool", "NetJs.System.Threading.Channels"))