
(function ($global, $, $spc, $sc, $sdt, $sm, $spu, $st, $sttp, $sr, $scc, $stc) {
    "use strict";
    let _;
    
    
    
	$.$asm(
    "NetJs.System.Runtime.InteropServices.JavaScript", 
    {"h":39677,"f":"System.Runtime.InteropServices.JavaScript","v":"1.0.35.0","a":[{"t":114950145,"c":4409917441,"a":[{"v":"browser","t":1310721}]},{"t":115146753,"c":13000048641,"a":[{"v":".NETCoreApp,Version=v10.0","t":1310721}],"n":[{"n":"FrameworkDisplayName","v":".NET 10.0","t":1310721}]},{"t":73596929,"c":4368564225,"a":[{"v":"SIT","t":1310721}]},{"t":73662465,"c":4368629761,"a":[{"v":"Debug","t":1310721}]},{"t":74121217,"c":4369088513,"a":[{"v":"1.0.35.0","t":1310721}]},{"t":74252289,"c":4369219585,"a":[{"v":"1.0.35\u002B5b8aaafb3aebad7fc7141c6e509af03c92d8b793","t":1310721}]},{"t":75104257,"c":4370071553,"a":[{"v":"NetJs.System.Runtime.InteropServices.JavaScript","t":1310721}]},{"t":75235329,"c":4370202625,"a":[{"v":"NetJs.System.Runtime.InteropServices.JavaScript","t":1310721}]},{"t":75366401,"c":4370333697,"a":[{"v":"1.0.35.0","t":1310721}]},{"t":115212289,"c":4410179585,"a":[{"v":"browser1.0","t":1310721}]},{"t":114950145,"c":4409917441,"a":[{"v":"browser1.0","t":1310721}]}],"m":[]},
    function($asm)
	{
        
        
        $asm.$cls("$srij.System.Runtime.InteropServices.JavaScript.JSType", ($self) => class JSType extends $.$spc.System.Object
        {
            $ctor$1()
            {
                super.$ctor();
                {
                }
                return this;
            }
            static $_Void;
            static get Void()
            {
                let $cls = $.$srij.System.Runtime.InteropServices.JavaScript.JSType;
                return $cls.$_Void ??= $asm.$ncls("$srij.System.Runtime.InteropServices.JavaScript.JSType.Void", ($self) => class Void extends $.$srij.System.Runtime.InteropServices.JavaScript.JSType
                {
                    $ctor$2()
                    {
                        super.$ctor$1();
                        {
                        }
                        return this;
                    }
                    static $h = 3644157;
                    static $f = 0b10000000010010001;
                    static $k = 1;
                    static $$md;
                    static get $md() { return this.$$md ??= {"b":2398973,"c":[{"n":".ctor","o":"$ctor$2","d":3644157,"h":4298611453,"f":8}],"d":2398973,"h":3644157}; }
                    static get $b() { return $.$srij.System.Runtime.InteropServices.JavaScript.JSType; }
                    static get $fullName() { return `System.Runtime.InteropServices.JavaScript.JSType.Void`; }
                }, $cls, ($v) => $cls.$_Void = $v);
            }
            static $_Discard;
            static get Discard()
            {
                let $cls = $.$srij.System.Runtime.InteropServices.JavaScript.JSType;
                return $cls.$_Discard ??= $asm.$ncls("$srij.System.Runtime.InteropServices.JavaScript.JSType.Discard", ($self) => class Discard extends $.$srij.System.Runtime.InteropServices.JavaScript.JSType
                {
                    $ctor$2()
                    {
                        super.$ctor$1();
                        {
                        }
                        return this;
                    }
                    static $h = 2792189;
                    static $f = 0b10000000010010001;
                    static $k = 1;
                    static $$md;
                    static get $md() { return this.$$md ??= {"b":2398973,"c":[{"n":".ctor","o":"$ctor$2","d":2792189,"h":4297759485,"f":8}],"d":2398973,"h":2792189}; }
                    static get $b() { return $.$srij.System.Runtime.InteropServices.JavaScript.JSType; }
                    static get $fullName() { return `System.Runtime.InteropServices.JavaScript.JSType.Discard`; }
                }, $cls, ($v) => $cls.$_Discard = $v);
            }
            static $_DiscardNoWait;
            static get DiscardNoWait()
            {
                let $cls = $.$srij.System.Runtime.InteropServices.JavaScript.JSType;
                return $cls.$_DiscardNoWait ??= $asm.$ncls("$srij.System.Runtime.InteropServices.JavaScript.JSType.DiscardNoWait", ($self) => class DiscardNoWait extends $.$srij.System.Runtime.InteropServices.JavaScript.JSType
                {
                    $ctor$2()
                    {
                        super.$ctor$1();
                        {
                        }
                        return this;
                    }
                    static $h = 2857725;
                    static $f = 0b10000000010010001;
                    static $k = 1;
                    static $$md;
                    static get $md() { return this.$$md ??= {"b":2398973,"c":[{"n":".ctor","o":"$ctor$2","d":2857725,"h":4297825021,"f":8}],"d":2398973,"h":2857725}; }
                    static get $b() { return $.$srij.System.Runtime.InteropServices.JavaScript.JSType; }
                    static get $fullName() { return `System.Runtime.InteropServices.JavaScript.JSType.DiscardNoWait`; }
                }, $cls, ($v) => $cls.$_DiscardNoWait = $v);
            }
            static $_Boolean;
            static get Boolean()
            {
                let $cls = $.$srij.System.Runtime.InteropServices.JavaScript.JSType;
                return $cls.$_Boolean ??= $asm.$ncls("$srij.System.Runtime.InteropServices.JavaScript.JSType.Boolean", ($self) => class Boolean extends $.$srij.System.Runtime.InteropServices.JavaScript.JSType
                {
                    $ctor$2()
                    {
                        super.$ctor$1();
                        {
                        }
                        return this;
                    }
                    static $h = 2661117;
                    static $f = 0b10000000010010001;
                    static $k = 1;
                    static $$md;
                    static get $md() { return this.$$md ??= {"b":2398973,"c":[{"n":".ctor","o":"$ctor$2","d":2661117,"h":4297628413,"f":8}],"d":2398973,"h":2661117}; }
                    static get $b() { return $.$srij.System.Runtime.InteropServices.JavaScript.JSType; }
                    static get $fullName() { return `System.Runtime.InteropServices.JavaScript.JSType.Boolean`; }
                }, $cls, ($v) => $cls.$_Boolean = $v);
            }
            static $_Number;
            static get Number()
            {
                let $cls = $.$srij.System.Runtime.InteropServices.JavaScript.JSType;
                return $cls.$_Number ??= $asm.$ncls("$srij.System.Runtime.InteropServices.JavaScript.JSType.Number", ($self) => class Number extends $.$srij.System.Runtime.InteropServices.JavaScript.JSType
                {
                    $ctor$2()
                    {
                        super.$ctor$1();
                        {
                        }
                        return this;
                    }
                    static $h = 3382013;
                    static $f = 0b10000000010010001;
                    static $k = 1;
                    static $$md;
                    static get $md() { return this.$$md ??= {"b":2398973,"c":[{"n":".ctor","o":"$ctor$2","d":3382013,"h":4298349309,"f":8}],"d":2398973,"h":3382013}; }
                    static get $b() { return $.$srij.System.Runtime.InteropServices.JavaScript.JSType; }
                    static get $fullName() { return `System.Runtime.InteropServices.JavaScript.JSType.Number`; }
                }, $cls, ($v) => $cls.$_Number = $v);
            }
            static $_BigInt;
            static get BigInt()
            {
                let $cls = $.$srij.System.Runtime.InteropServices.JavaScript.JSType;
                return $cls.$_BigInt ??= $asm.$ncls("$srij.System.Runtime.InteropServices.JavaScript.JSType.BigInt", ($self) => class BigInt extends $.$srij.System.Runtime.InteropServices.JavaScript.JSType
                {
                    $ctor$2()
                    {
                        super.$ctor$1();
                        {
                        }
                        return this;
                    }
                    static $h = 2595581;
                    static $f = 0b10000000010010001;
                    static $k = 1;
                    static $$md;
                    static get $md() { return this.$$md ??= {"b":2398973,"c":[{"n":".ctor","o":"$ctor$2","d":2595581,"h":4297562877,"f":8}],"d":2398973,"h":2595581}; }
                    static get $b() { return $.$srij.System.Runtime.InteropServices.JavaScript.JSType; }
                    static get $fullName() { return `System.Runtime.InteropServices.JavaScript.JSType.BigInt`; }
                }, $cls, ($v) => $cls.$_BigInt = $v);
            }
            static $_Date;
            static get Date()
            {
                let $cls = $.$srij.System.Runtime.InteropServices.JavaScript.JSType;
                return $cls.$_Date ??= $asm.$ncls("$srij.System.Runtime.InteropServices.JavaScript.JSType.Date", ($self) => class Date extends $.$srij.System.Runtime.InteropServices.JavaScript.JSType
                {
                    $ctor$2()
                    {
                        super.$ctor$1();
                        {
                        }
                        return this;
                    }
                    static $h = 2726653;
                    static $f = 0b10000000010010001;
                    static $k = 1;
                    static $$md;
                    static get $md() { return this.$$md ??= {"b":2398973,"c":[{"n":".ctor","o":"$ctor$2","d":2726653,"h":4297693949,"f":8}],"d":2398973,"h":2726653}; }
                    static get $b() { return $.$srij.System.Runtime.InteropServices.JavaScript.JSType; }
                    static get $fullName() { return `System.Runtime.InteropServices.JavaScript.JSType.Date`; }
                }, $cls, ($v) => $cls.$_Date = $v);
            }
            static $_String;
            static get String()
            {
                let $cls = $.$srij.System.Runtime.InteropServices.JavaScript.JSType;
                return $cls.$_String ??= $asm.$ncls("$srij.System.Runtime.InteropServices.JavaScript.JSType.String", ($self) => class String extends $.$srij.System.Runtime.InteropServices.JavaScript.JSType
                {
                    $ctor$2()
                    {
                        super.$ctor$1();
                        {
                        }
                        return this;
                    }
                    static $h = 3578621;
                    static $f = 0b10000000010010001;
                    static $k = 1;
                    static $$md;
                    static get $md() { return this.$$md ??= {"b":2398973,"c":[{"n":".ctor","o":"$ctor$2","d":3578621,"h":4298545917,"f":8}],"d":2398973,"h":3578621}; }
                    static get $b() { return $.$srij.System.Runtime.InteropServices.JavaScript.JSType; }
                    static get $fullName() { return `System.Runtime.InteropServices.JavaScript.JSType.String`; }
                }, $cls, ($v) => $cls.$_String = $v);
            }
            static $_Object;
            static get Object()
            {
                let $cls = $.$srij.System.Runtime.InteropServices.JavaScript.JSType;
                return $cls.$_Object ??= $asm.$ncls("$srij.System.Runtime.InteropServices.JavaScript.JSType.Object", ($self) => class Object extends $.$srij.System.Runtime.InteropServices.JavaScript.JSType
                {
                    $ctor$2()
                    {
                        super.$ctor$1();
                        {
                        }
                        return this;
                    }
                    static $h = 3447549;
                    static $f = 0b10000000010010001;
                    static $k = 1;
                    static $$md;
                    static get $md() { return this.$$md ??= {"b":2398973,"c":[{"n":".ctor","o":"$ctor$2","d":3447549,"h":4298414845,"f":8}],"d":2398973,"h":3447549}; }
                    static get $b() { return $.$srij.System.Runtime.InteropServices.JavaScript.JSType; }
                    static get $fullName() { return `System.Runtime.InteropServices.JavaScript.JSType.Object`; }
                }, $cls, ($v) => $cls.$_Object = $v);
            }
            static $_Error;
            static get Error()
            {
                let $cls = $.$srij.System.Runtime.InteropServices.JavaScript.JSType;
                return $cls.$_Error ??= $asm.$ncls("$srij.System.Runtime.InteropServices.JavaScript.JSType.Error", ($self) => class Error extends $.$srij.System.Runtime.InteropServices.JavaScript.JSType
                {
                    $ctor$2()
                    {
                        super.$ctor$1();
                        {
                        }
                        return this;
                    }
                    static $h = 2923261;
                    static $f = 0b10000000010010001;
                    static $k = 1;
                    static $$md;
                    static get $md() { return this.$$md ??= {"b":2398973,"c":[{"n":".ctor","o":"$ctor$2","d":2923261,"h":4297890557,"f":8}],"d":2398973,"h":2923261}; }
                    static get $b() { return $.$srij.System.Runtime.InteropServices.JavaScript.JSType; }
                    static get $fullName() { return `System.Runtime.InteropServices.JavaScript.JSType.Error`; }
                }, $cls, ($v) => $cls.$_Error = $v);
            }
            static $_MemoryView;
            static get MemoryView()
            {
                let $cls = $.$srij.System.Runtime.InteropServices.JavaScript.JSType;
                return $cls.$_MemoryView ??= $asm.$ncls("$srij.System.Runtime.InteropServices.JavaScript.JSType.MemoryView", ($self) => class MemoryView extends $.$srij.System.Runtime.InteropServices.JavaScript.JSType
                {
                    $ctor$2()
                    {
                        super.$ctor$1();
                        {
                        }
                        return this;
                    }
                    static $h = 3316477;
                    static $f = 0b10000000010010001;
                    static $k = 1;
                    static $$md;
                    static get $md() { return this.$$md ??= {"b":2398973,"c":[{"n":".ctor","o":"$ctor$2","d":3316477,"h":4298283773,"f":8}],"d":2398973,"h":3316477}; }
                    static get $b() { return $.$srij.System.Runtime.InteropServices.JavaScript.JSType; }
                    static get $fullName() { return `System.Runtime.InteropServices.JavaScript.JSType.MemoryView`; }
                }, $cls, ($v) => $cls.$_MemoryView = $v);
            }
            static $_Array$$;
            static Array$$(T)
            {
                let $cls = $.$srij.System.Runtime.InteropServices.JavaScript.JSType;
                return ($cls.$_Array$$ ??= $asm.$ncls("$srij.System.Runtime.InteropServices.JavaScript.JSType.Array<>", (T) => $asm.$gt("$srij.System.Runtime.InteropServices.JavaScript.JSType.Array<>", [T], ($self) => class Array$$ extends $.$srij.System.Runtime.InteropServices.JavaScript.JSType
                {
                    $ctor$2()
                    {
                        super.$ctor$1();
                        {
                        }
                        return this;
                    }
                    static $h = 2530045;
                    static $g = 1;
                    static $f = 0b10000000011010001;
                    static $k = 1;
                    static $$md;
                    static get $md() { return this.$$md ??= {"b":2398973,"c":[{"n":".ctor","o":"$ctor$2","d":this.$h,"h":Number(BigInt(this.$h)|0x100000000n),"f":8}],"g":[T?.$h??1507328],"r":1,"d":2398973,"h":this.$h}; }
                    static get $b() { return $.$srij.System.Runtime.InteropServices.JavaScript.JSType; }
                    static get $fullName() { return `System.Runtime.InteropServices.JavaScript.JSType.Array<${T?.$fullName}>`; }
                }), $cls, ($v) => $cls.$_Array$$ = $v))(T);
            }
            static $_Promise$$;
            static Promise$$(T)
            {
                let $cls = $.$srij.System.Runtime.InteropServices.JavaScript.JSType;
                return ($cls.$_Promise$$ ??= $asm.$ncls("$srij.System.Runtime.InteropServices.JavaScript.JSType.Promise<>", (T) => $asm.$gt("$srij.System.Runtime.InteropServices.JavaScript.JSType.Promise<>", [T], ($self) => class Promise$$ extends $.$srij.System.Runtime.InteropServices.JavaScript.JSType
                {
                    $ctor$2()
                    {
                        super.$ctor$1();
                        {
                        }
                        return this;
                    }
                    static $h = 3513085;
                    static $g = 1;
                    static $f = 0b10000000011010001;
                    static $k = 1;
                    static $$md;
                    static get $md() { return this.$$md ??= {"b":2398973,"c":[{"n":".ctor","o":"$ctor$2","d":this.$h,"h":Number(BigInt(this.$h)|0x100000000n),"f":8}],"g":[T?.$h??1507328],"r":1,"d":2398973,"h":this.$h}; }
                    static get $b() { return $.$srij.System.Runtime.InteropServices.JavaScript.JSType; }
                    static get $fullName() { return `System.Runtime.InteropServices.JavaScript.JSType.Promise<${T?.$fullName}>`; }
                }), $cls, ($v) => $cls.$_Promise$$ = $v))(T);
            }
            static $_Function;
            static get Function()
            {
                let $cls = $.$srij.System.Runtime.InteropServices.JavaScript.JSType;
                return $cls.$_Function ??= $asm.$ncls("$srij.System.Runtime.InteropServices.JavaScript.JSType.Function", ($self) => class Function extends $.$srij.System.Runtime.InteropServices.JavaScript.JSType
                {
                    $ctor$2()
                    {
                        super.$ctor$1();
                        {
                        }
                        return this;
                    }
                    static $h = 2988797;
                    static $f = 0b10000000010010001;
                    static $k = 1;
                    static $$md;
                    static get $md() { return this.$$md ??= {"b":2398973,"c":[{"n":".ctor","o":"$ctor$2","d":2988797,"h":4297956093,"f":8}],"d":2398973,"h":2988797}; }
                    static get $b() { return $.$srij.System.Runtime.InteropServices.JavaScript.JSType; }
                    static get $fullName() { return `System.Runtime.InteropServices.JavaScript.JSType.Function`; }
                }, $cls, ($v) => $cls.$_Function = $v);
            }
            static $_Function$$;
            static Function$$(T)
            {
                let $cls = $.$srij.System.Runtime.InteropServices.JavaScript.JSType;
                return ($cls.$_Function$$ ??= $asm.$ncls("$srij.System.Runtime.InteropServices.JavaScript.JSType.Function<>", (T) => $asm.$gt("$srij.System.Runtime.InteropServices.JavaScript.JSType.Function<>", [T], ($self) => class Function$$ extends $.$srij.System.Runtime.InteropServices.JavaScript.JSType
                {
                    $ctor$2()
                    {
                        super.$ctor$1();
                        {
                        }
                        return this;
                    }
                    static $h = 3250941;
                    static $g = 1;
                    static $f = 0b10000000011010001;
                    static $k = 1;
                    static $$md;
                    static get $md() { return this.$$md ??= {"b":2398973,"c":[{"n":".ctor","o":"$ctor$2","d":this.$h,"h":Number(BigInt(this.$h)|0x100000000n),"f":8}],"g":[T?.$h??1507328],"r":1,"d":2398973,"h":this.$h}; }
                    static get $b() { return $.$srij.System.Runtime.InteropServices.JavaScript.JSType; }
                    static get $fullName() { return `System.Runtime.InteropServices.JavaScript.JSType.Function<${T?.$fullName}>`; }
                }), $cls, ($v) => $cls.$_Function$$ = $v))(T);
            }
            static $_Function$$$;
            static Function$$$(T1, T2)
            {
                let $cls = $.$srij.System.Runtime.InteropServices.JavaScript.JSType;
                return ($cls.$_Function$$$ ??= $asm.$ncls("$srij.System.Runtime.InteropServices.JavaScript.JSType.Function<,>", (T1, T2) => $asm.$gt("$srij.System.Runtime.InteropServices.JavaScript.JSType.Function<,>", [T1, T2], ($self) => class Function$$$ extends $.$srij.System.Runtime.InteropServices.JavaScript.JSType
                {
                    $ctor$2()
                    {
                        super.$ctor$1();
                        {
                        }
                        return this;
                    }
                    static $h = 3185405;
                    static $g = 2;
                    static $f = 0b10000000011010001;
                    static $k = 1;
                    static $$md;
                    static get $md() { return this.$$md ??= {"b":2398973,"c":[{"n":".ctor","o":"$ctor$2","d":this.$h,"h":Number(BigInt(this.$h)|0x100000000n),"f":8}],"g":[T1?.$h??1507328,T2?.$h??1572864],"r":2,"d":2398973,"h":this.$h}; }
                    static get $b() { return $.$srij.System.Runtime.InteropServices.JavaScript.JSType; }
                    static get $fullName() { return `System.Runtime.InteropServices.JavaScript.JSType.Function<${T1?.$fullName},${T2?.$fullName}>`; }
                }), $cls, ($v) => $cls.$_Function$$$ = $v))(T1, T2);
            }
            static $_Function$$$$;
            static Function$$$$(T1, T2, T3)
            {
                let $cls = $.$srij.System.Runtime.InteropServices.JavaScript.JSType;
                return ($cls.$_Function$$$$ ??= $asm.$ncls("$srij.System.Runtime.InteropServices.JavaScript.JSType.Function<,,>", (T1, T2, T3) => $asm.$gt("$srij.System.Runtime.InteropServices.JavaScript.JSType.Function<,,>", [T1, T2, T3], ($self) => class Function$$$$ extends $.$srij.System.Runtime.InteropServices.JavaScript.JSType
                {
                    $ctor$2()
                    {
                        super.$ctor$1();
                        {
                        }
                        return this;
                    }
                    static $h = 3119869;
                    static $g = 3;
                    static $f = 0b10000000011010001;
                    static $k = 1;
                    static $$md;
                    static get $md() { return this.$$md ??= {"b":2398973,"c":[{"n":".ctor","o":"$ctor$2","d":this.$h,"h":Number(BigInt(this.$h)|0x100000000n),"f":8}],"g":[T1?.$h??1507328,T2?.$h??1572864,T3?.$h??1638400],"r":3,"d":2398973,"h":this.$h}; }
                    static get $b() { return $.$srij.System.Runtime.InteropServices.JavaScript.JSType; }
                    static get $fullName() { return `System.Runtime.InteropServices.JavaScript.JSType.Function<${T1?.$fullName},${T2?.$fullName},${T3?.$fullName}>`; }
                }), $cls, ($v) => $cls.$_Function$$$$ = $v))(T1, T2, T3);
            }
            static $_Function$$$$$;
            static Function$$$$$(T1, T2, T3, T4)
            {
                let $cls = $.$srij.System.Runtime.InteropServices.JavaScript.JSType;
                return ($cls.$_Function$$$$$ ??= $asm.$ncls("$srij.System.Runtime.InteropServices.JavaScript.JSType.Function<,,,>", (T1, T2, T3, T4) => $asm.$gt("$srij.System.Runtime.InteropServices.JavaScript.JSType.Function<,,,>", [T1, T2, T3, T4], ($self) => class Function$$$$$ extends $.$srij.System.Runtime.InteropServices.JavaScript.JSType
                {
                    $ctor$2()
                    {
                        super.$ctor$1();
                        {
                        }
                        return this;
                    }
                    static $h = 3054333;
                    static $g = 4;
                    static $f = 0b10000000011010001;
                    static $k = 1;
                    static $$md;
                    static get $md() { return this.$$md ??= {"b":2398973,"c":[{"n":".ctor","o":"$ctor$2","d":this.$h,"h":Number(BigInt(this.$h)|0x100000000n),"f":8}],"g":[T1?.$h??1507328,T2?.$h??1572864,T3?.$h??1638400,T4?.$h??1703936],"r":4,"d":2398973,"h":this.$h}; }
                    static get $b() { return $.$srij.System.Runtime.InteropServices.JavaScript.JSType; }
                    static get $fullName() { return `System.Runtime.InteropServices.JavaScript.JSType.Function<${T1?.$fullName},${T2?.$fullName},${T3?.$fullName},${T4?.$fullName}>`; }
                }), $cls, ($v) => $cls.$_Function$$$$$ = $v))(T1, T2, T3, T4);
            }
            static $_Any;
            static get Any()
            {
                let $cls = $.$srij.System.Runtime.InteropServices.JavaScript.JSType;
                return $cls.$_Any ??= $asm.$ncls("$srij.System.Runtime.InteropServices.JavaScript.JSType.Any", ($self) => class Any extends $.$srij.System.Runtime.InteropServices.JavaScript.JSType
                {
                    $ctor$2()
                    {
                        super.$ctor$1();
                        {
                        }
                        return this;
                    }
                    static $h = 2464509;
                    static $f = 0b10000000010010001;
                    static $k = 1;
                    static $$md;
                    static get $md() { return this.$$md ??= {"b":2398973,"c":[{"n":".ctor","o":"$ctor$2","d":2464509,"h":4297431805,"f":8}],"d":2398973,"h":2464509}; }
                    static get $b() { return $.$srij.System.Runtime.InteropServices.JavaScript.JSType; }
                    static get $fullName() { return `System.Runtime.InteropServices.JavaScript.JSType.Any`; }
                }, $cls, ($v) => $cls.$_Any = $v);
            }
            static $h = 2398973;
            static $f = 0b110001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"c":[{"n":".ctor","o":"$ctor$1","d":2398973,"h":4297366269,"f":8}],"j":[3644157,2792189,2857725,2661117,3382013,2595581,2726653,3578621,3447549,2923261,3316477,2530045,3513085,2988797,3250941,3185405,3119869,3054333,2464509],"h":2398973,"a":[{"t":114950145,"c":4409917441,"a":[{"v":"browser","t":1310721}]}]}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.Runtime.InteropServices.JavaScript.JSType`; }
        });
        
        $asm.$cls("$srij.System.Runtime.InteropServices.JavaScript.JavaScriptImports", ($self) => class JavaScriptImports
        {
            static /*bool */ HasProperty(/*global::System.Runtime.InteropServices.JavaScript.JSObject*/ self, /*string*/ propertyName)
            {
                if ($.$srij.System.Runtime.InteropServices.JavaScript.JavaScriptImports.__signature_HasProperty_393970128 === null)
                {
                    $.$srij.System.Runtime.InteropServices.JavaScript.JavaScriptImports.__signature_HasProperty_393970128 = $.$srij.System.Runtime.InteropServices.JavaScript.JSFunctionBinding.BindJSFunction("INTERNAL.has_property", null, $.$spc.System.ReadOnlySpan$$($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType).op_Implicit($.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType), [$.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType.Boolean, $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType.JSObject, $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType.String], null, null)));
                }
                {
                    /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ let ____arg_exception_native;
                    /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ let ____arg_return_native;
                    /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ let __self_native;
                    /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ let __propertyName_native;
                    /*bool*/ let __retVal;
                    /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ let __retVal_native;
                    $.$spc.System.Runtime.CompilerServices.Unsafe.SkipInit($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument, $.$ref(() => ____arg_return_native, ($v) => ____arg_return_native = $v, $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument));
                    ____arg_return_native.Initialize();
                    $.$spc.System.Runtime.CompilerServices.Unsafe.SkipInit($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument, $.$ref(() => ____arg_exception_native, ($v) => ____arg_exception_native = $v, $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument));
                    ____arg_exception_native.Initialize();
                    $.$spc.System.Runtime.CompilerServices.Unsafe.SkipInit($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument, $.$ref(() => __propertyName_native, ($v) => __propertyName_native = $v, $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument));
                    $.$spc.System.Runtime.CompilerServices.Unsafe.SkipInit($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument, $.$ref(() => __self_native, ($v) => __self_native = $v, $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument));
                    __propertyName_native.ToJS$46(propertyName);
                    __self_native.ToJS$44(self);
                    {
                        __retVal_native = __InvokeJSFunction.call(this, ____arg_exception_native.Clone(), ____arg_return_native.Clone(), __self_native.Clone(), __propertyName_native.Clone());
                    }
                    __retVal_native.ToManaged$26($.$ref(() => __retVal, ($v) => __retVal = $v, $.$spc.System.Boolean));
                    return __retVal;
                }
                /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/  function __InvokeJSFunction(/*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ ____arg_exception_native, /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ ____arg_return_native, /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ __self_native, /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ __propertyName_native)
                {
                    /*global::System.Span<global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument>*/ let __arguments_buffer = $.$spc.System.Span$$($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument).op_Implicit($.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument), [____arg_exception_native, ____arg_return_native, __self_native, __propertyName_native], null, null));
                    $.$srij.System.Runtime.InteropServices.JavaScript.JSFunctionBinding.InvokeJS($.$srij.System.Runtime.InteropServices.JavaScript.JavaScriptImports.__signature_HasProperty_393970128, __arguments_buffer);
                    return __arguments_buffer.get_Item(1).$v;
                }
            }
            /*global::System.Runtime.InteropServices.JavaScript.JSFunctionBinding*/ static __signature_HasProperty_393970128 = null;
            static /*string */ GetTypeOfProperty(/*global::System.Runtime.InteropServices.JavaScript.JSObject*/ self, /*string*/ propertyName)
            {
                if ($.$srij.System.Runtime.InteropServices.JavaScript.JavaScriptImports.__signature_GetTypeOfProperty_1139574135 === null)
                {
                    $.$srij.System.Runtime.InteropServices.JavaScript.JavaScriptImports.__signature_GetTypeOfProperty_1139574135 = $.$srij.System.Runtime.InteropServices.JavaScript.JSFunctionBinding.BindJSFunction("INTERNAL.get_typeof_property", null, $.$spc.System.ReadOnlySpan$$($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType).op_Implicit($.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType), [$.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType.String, $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType.JSObject, $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType.String], null, null)));
                }
                {
                    /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ let ____arg_exception_native;
                    /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ let ____arg_return_native;
                    /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ let __self_native;
                    /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ let __propertyName_native;
                    /*string*/ let __retVal;
                    /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ let __retVal_native;
                    $.$spc.System.Runtime.CompilerServices.Unsafe.SkipInit($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument, $.$ref(() => ____arg_return_native, ($v) => ____arg_return_native = $v, $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument));
                    ____arg_return_native.Initialize();
                    $.$spc.System.Runtime.CompilerServices.Unsafe.SkipInit($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument, $.$ref(() => ____arg_exception_native, ($v) => ____arg_exception_native = $v, $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument));
                    ____arg_exception_native.Initialize();
                    $.$spc.System.Runtime.CompilerServices.Unsafe.SkipInit($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument, $.$ref(() => __propertyName_native, ($v) => __propertyName_native = $v, $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument));
                    $.$spc.System.Runtime.CompilerServices.Unsafe.SkipInit($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument, $.$ref(() => __self_native, ($v) => __self_native = $v, $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument));
                    __propertyName_native.ToJS$46(propertyName);
                    __self_native.ToJS$44(self);
                    {
                        __retVal_native = __InvokeJSFunction.call(this, ____arg_exception_native.Clone(), ____arg_return_native.Clone(), __self_native.Clone(), __propertyName_native.Clone());
                    }
                    __retVal_native.ToManaged$46($.$ref(() => __retVal, ($v) => __retVal = $v, $.$spc.System.String));
                    return __retVal;
                }
                /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/  function __InvokeJSFunction(/*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ ____arg_exception_native, /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ ____arg_return_native, /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ __self_native, /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ __propertyName_native)
                {
                    /*global::System.Span<global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument>*/ let __arguments_buffer = $.$spc.System.Span$$($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument).op_Implicit($.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument), [____arg_exception_native, ____arg_return_native, __self_native, __propertyName_native], null, null));
                    $.$srij.System.Runtime.InteropServices.JavaScript.JSFunctionBinding.InvokeJS($.$srij.System.Runtime.InteropServices.JavaScript.JavaScriptImports.__signature_GetTypeOfProperty_1139574135, __arguments_buffer);
                    return __arguments_buffer.get_Item(1).$v;
                }
            }
            /*global::System.Runtime.InteropServices.JavaScript.JSFunctionBinding*/ static __signature_GetTypeOfProperty_1139574135 = null;
            static /*bool */ GetPropertyAsBoolean(/*global::System.Runtime.InteropServices.JavaScript.JSObject*/ self, /*string*/ propertyName)
            {
                if ($.$srij.System.Runtime.InteropServices.JavaScript.JavaScriptImports.__signature_GetPropertyAsBoolean_393970128 === null)
                {
                    $.$srij.System.Runtime.InteropServices.JavaScript.JavaScriptImports.__signature_GetPropertyAsBoolean_393970128 = $.$srij.System.Runtime.InteropServices.JavaScript.JSFunctionBinding.BindJSFunction("INTERNAL.get_property", null, $.$spc.System.ReadOnlySpan$$($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType).op_Implicit($.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType), [$.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType.Boolean, $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType.JSObject, $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType.String], null, null)));
                }
                {
                    /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ let ____arg_exception_native;
                    /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ let ____arg_return_native;
                    /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ let __self_native;
                    /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ let __propertyName_native;
                    /*bool*/ let __retVal;
                    /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ let __retVal_native;
                    $.$spc.System.Runtime.CompilerServices.Unsafe.SkipInit($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument, $.$ref(() => ____arg_return_native, ($v) => ____arg_return_native = $v, $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument));
                    ____arg_return_native.Initialize();
                    $.$spc.System.Runtime.CompilerServices.Unsafe.SkipInit($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument, $.$ref(() => ____arg_exception_native, ($v) => ____arg_exception_native = $v, $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument));
                    ____arg_exception_native.Initialize();
                    $.$spc.System.Runtime.CompilerServices.Unsafe.SkipInit($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument, $.$ref(() => __propertyName_native, ($v) => __propertyName_native = $v, $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument));
                    $.$spc.System.Runtime.CompilerServices.Unsafe.SkipInit($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument, $.$ref(() => __self_native, ($v) => __self_native = $v, $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument));
                    __propertyName_native.ToJS$46(propertyName);
                    __self_native.ToJS$44(self);
                    {
                        __retVal_native = __InvokeJSFunction.call(this, ____arg_exception_native.Clone(), ____arg_return_native.Clone(), __self_native.Clone(), __propertyName_native.Clone());
                    }
                    __retVal_native.ToManaged$26($.$ref(() => __retVal, ($v) => __retVal = $v, $.$spc.System.Boolean));
                    return __retVal;
                }
                /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/  function __InvokeJSFunction(/*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ ____arg_exception_native, /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ ____arg_return_native, /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ __self_native, /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ __propertyName_native)
                {
                    /*global::System.Span<global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument>*/ let __arguments_buffer = $.$spc.System.Span$$($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument).op_Implicit($.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument), [____arg_exception_native, ____arg_return_native, __self_native, __propertyName_native], null, null));
                    $.$srij.System.Runtime.InteropServices.JavaScript.JSFunctionBinding.InvokeJS($.$srij.System.Runtime.InteropServices.JavaScript.JavaScriptImports.__signature_GetPropertyAsBoolean_393970128, __arguments_buffer);
                    return __arguments_buffer.get_Item(1).$v;
                }
            }
            /*global::System.Runtime.InteropServices.JavaScript.JSFunctionBinding*/ static __signature_GetPropertyAsBoolean_393970128 = null;
            static /*int */ GetPropertyAsInt32(/*global::System.Runtime.InteropServices.JavaScript.JSObject*/ self, /*string*/ propertyName)
            {
                if ($.$srij.System.Runtime.InteropServices.JavaScript.JavaScriptImports.__signature_GetPropertyAsInt32_1813830729 === null)
                {
                    $.$srij.System.Runtime.InteropServices.JavaScript.JavaScriptImports.__signature_GetPropertyAsInt32_1813830729 = $.$srij.System.Runtime.InteropServices.JavaScript.JSFunctionBinding.BindJSFunction("INTERNAL.get_property", null, $.$spc.System.ReadOnlySpan$$($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType).op_Implicit($.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType), [$.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType.Int32, $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType.JSObject, $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType.String], null, null)));
                }
                {
                    /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ let ____arg_exception_native;
                    /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ let ____arg_return_native;
                    /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ let __self_native;
                    /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ let __propertyName_native;
                    /*int*/ let __retVal;
                    /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ let __retVal_native;
                    $.$spc.System.Runtime.CompilerServices.Unsafe.SkipInit($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument, $.$ref(() => ____arg_return_native, ($v) => ____arg_return_native = $v, $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument));
                    ____arg_return_native.Initialize();
                    $.$spc.System.Runtime.CompilerServices.Unsafe.SkipInit($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument, $.$ref(() => ____arg_exception_native, ($v) => ____arg_exception_native = $v, $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument));
                    ____arg_exception_native.Initialize();
                    $.$spc.System.Runtime.CompilerServices.Unsafe.SkipInit($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument, $.$ref(() => __propertyName_native, ($v) => __propertyName_native = $v, $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument));
                    $.$spc.System.Runtime.CompilerServices.Unsafe.SkipInit($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument, $.$ref(() => __self_native, ($v) => __self_native = $v, $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument));
                    __propertyName_native.ToJS$46(propertyName);
                    __self_native.ToJS$44(self);
                    {
                        __retVal_native = __InvokeJSFunction.call(this, ____arg_exception_native.Clone(), ____arg_return_native.Clone(), __self_native.Clone(), __propertyName_native.Clone());
                    }
                    __retVal_native.ToManaged$39($.$ref(() => __retVal, ($v) => __retVal = $v, $.$spc.System.Int32));
                    return __retVal;
                }
                /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/  function __InvokeJSFunction(/*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ ____arg_exception_native, /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ ____arg_return_native, /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ __self_native, /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ __propertyName_native)
                {
                    /*global::System.Span<global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument>*/ let __arguments_buffer = $.$spc.System.Span$$($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument).op_Implicit($.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument), [____arg_exception_native, ____arg_return_native, __self_native, __propertyName_native], null, null));
                    $.$srij.System.Runtime.InteropServices.JavaScript.JSFunctionBinding.InvokeJS($.$srij.System.Runtime.InteropServices.JavaScript.JavaScriptImports.__signature_GetPropertyAsInt32_1813830729, __arguments_buffer);
                    return __arguments_buffer.get_Item(1).$v;
                }
            }
            /*global::System.Runtime.InteropServices.JavaScript.JSFunctionBinding*/ static __signature_GetPropertyAsInt32_1813830729 = null;
            static /*double */ GetPropertyAsDouble(/*global::System.Runtime.InteropServices.JavaScript.JSObject*/ self, /*string*/ propertyName)
            {
                if ($.$srij.System.Runtime.InteropServices.JavaScript.JavaScriptImports.__signature_GetPropertyAsDouble_705601847 === null)
                {
                    $.$srij.System.Runtime.InteropServices.JavaScript.JavaScriptImports.__signature_GetPropertyAsDouble_705601847 = $.$srij.System.Runtime.InteropServices.JavaScript.JSFunctionBinding.BindJSFunction("INTERNAL.get_property", null, $.$spc.System.ReadOnlySpan$$($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType).op_Implicit($.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType), [$.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType.Double, $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType.JSObject, $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType.String], null, null)));
                }
                {
                    /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ let ____arg_exception_native;
                    /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ let ____arg_return_native;
                    /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ let __self_native;
                    /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ let __propertyName_native;
                    /*double*/ let __retVal;
                    /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ let __retVal_native;
                    $.$spc.System.Runtime.CompilerServices.Unsafe.SkipInit($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument, $.$ref(() => ____arg_return_native, ($v) => ____arg_return_native = $v, $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument));
                    ____arg_return_native.Initialize();
                    $.$spc.System.Runtime.CompilerServices.Unsafe.SkipInit($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument, $.$ref(() => ____arg_exception_native, ($v) => ____arg_exception_native = $v, $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument));
                    ____arg_exception_native.Initialize();
                    $.$spc.System.Runtime.CompilerServices.Unsafe.SkipInit($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument, $.$ref(() => __propertyName_native, ($v) => __propertyName_native = $v, $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument));
                    $.$spc.System.Runtime.CompilerServices.Unsafe.SkipInit($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument, $.$ref(() => __self_native, ($v) => __self_native = $v, $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument));
                    __propertyName_native.ToJS$46(propertyName);
                    __self_native.ToJS$44(self);
                    {
                        __retVal_native = __InvokeJSFunction.call(this, ____arg_exception_native.Clone(), ____arg_return_native.Clone(), __self_native.Clone(), __propertyName_native.Clone());
                    }
                    __retVal_native.ToManaged$2($.$ref(() => __retVal, ($v) => __retVal = $v, $.$spc.System.Double));
                    return __retVal;
                }
                /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/  function __InvokeJSFunction(/*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ ____arg_exception_native, /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ ____arg_return_native, /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ __self_native, /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ __propertyName_native)
                {
                    /*global::System.Span<global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument>*/ let __arguments_buffer = $.$spc.System.Span$$($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument).op_Implicit($.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument), [____arg_exception_native, ____arg_return_native, __self_native, __propertyName_native], null, null));
                    $.$srij.System.Runtime.InteropServices.JavaScript.JSFunctionBinding.InvokeJS($.$srij.System.Runtime.InteropServices.JavaScript.JavaScriptImports.__signature_GetPropertyAsDouble_705601847, __arguments_buffer);
                    return __arguments_buffer.get_Item(1).$v;
                }
            }
            /*global::System.Runtime.InteropServices.JavaScript.JSFunctionBinding*/ static __signature_GetPropertyAsDouble_705601847 = null;
            static /*string */ GetPropertyAsString(/*global::System.Runtime.InteropServices.JavaScript.JSObject*/ self, /*string*/ propertyName)
            {
                if ($.$srij.System.Runtime.InteropServices.JavaScript.JavaScriptImports.__signature_GetPropertyAsString_1139574135 === null)
                {
                    $.$srij.System.Runtime.InteropServices.JavaScript.JavaScriptImports.__signature_GetPropertyAsString_1139574135 = $.$srij.System.Runtime.InteropServices.JavaScript.JSFunctionBinding.BindJSFunction("INTERNAL.get_property", null, $.$spc.System.ReadOnlySpan$$($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType).op_Implicit($.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType), [$.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType.String, $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType.JSObject, $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType.String], null, null)));
                }
                {
                    /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ let ____arg_exception_native;
                    /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ let ____arg_return_native;
                    /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ let __self_native;
                    /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ let __propertyName_native;
                    /*string*/ let __retVal;
                    /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ let __retVal_native;
                    $.$spc.System.Runtime.CompilerServices.Unsafe.SkipInit($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument, $.$ref(() => ____arg_return_native, ($v) => ____arg_return_native = $v, $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument));
                    ____arg_return_native.Initialize();
                    $.$spc.System.Runtime.CompilerServices.Unsafe.SkipInit($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument, $.$ref(() => ____arg_exception_native, ($v) => ____arg_exception_native = $v, $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument));
                    ____arg_exception_native.Initialize();
                    $.$spc.System.Runtime.CompilerServices.Unsafe.SkipInit($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument, $.$ref(() => __propertyName_native, ($v) => __propertyName_native = $v, $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument));
                    $.$spc.System.Runtime.CompilerServices.Unsafe.SkipInit($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument, $.$ref(() => __self_native, ($v) => __self_native = $v, $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument));
                    __propertyName_native.ToJS$46(propertyName);
                    __self_native.ToJS$44(self);
                    {
                        __retVal_native = __InvokeJSFunction.call(this, ____arg_exception_native.Clone(), ____arg_return_native.Clone(), __self_native.Clone(), __propertyName_native.Clone());
                    }
                    __retVal_native.ToManaged$46($.$ref(() => __retVal, ($v) => __retVal = $v, $.$spc.System.String));
                    return __retVal;
                }
                /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/  function __InvokeJSFunction(/*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ ____arg_exception_native, /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ ____arg_return_native, /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ __self_native, /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ __propertyName_native)
                {
                    /*global::System.Span<global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument>*/ let __arguments_buffer = $.$spc.System.Span$$($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument).op_Implicit($.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument), [____arg_exception_native, ____arg_return_native, __self_native, __propertyName_native], null, null));
                    $.$srij.System.Runtime.InteropServices.JavaScript.JSFunctionBinding.InvokeJS($.$srij.System.Runtime.InteropServices.JavaScript.JavaScriptImports.__signature_GetPropertyAsString_1139574135, __arguments_buffer);
                    return __arguments_buffer.get_Item(1).$v;
                }
            }
            /*global::System.Runtime.InteropServices.JavaScript.JSFunctionBinding*/ static __signature_GetPropertyAsString_1139574135 = null;
            static /*global::System.Runtime.InteropServices.JavaScript.JSObject */ GetPropertyAsJSObject(/*global::System.Runtime.InteropServices.JavaScript.JSObject*/ self, /*string*/ propertyName)
            {
                if ($.$srij.System.Runtime.InteropServices.JavaScript.JavaScriptImports.__signature_GetPropertyAsJSObject_1480020778 === null)
                {
                    $.$srij.System.Runtime.InteropServices.JavaScript.JavaScriptImports.__signature_GetPropertyAsJSObject_1480020778 = $.$srij.System.Runtime.InteropServices.JavaScript.JSFunctionBinding.BindJSFunction("INTERNAL.get_property", null, $.$spc.System.ReadOnlySpan$$($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType).op_Implicit($.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType), [$.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType.JSObject, $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType.JSObject, $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType.String], null, null)));
                }
                {
                    /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ let ____arg_exception_native;
                    /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ let ____arg_return_native;
                    /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ let __self_native;
                    /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ let __propertyName_native;
                    /*global::System.Runtime.InteropServices.JavaScript.JSObject*/ let __retVal;
                    /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ let __retVal_native;
                    $.$spc.System.Runtime.CompilerServices.Unsafe.SkipInit($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument, $.$ref(() => ____arg_return_native, ($v) => ____arg_return_native = $v, $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument));
                    ____arg_return_native.Initialize();
                    $.$spc.System.Runtime.CompilerServices.Unsafe.SkipInit($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument, $.$ref(() => ____arg_exception_native, ($v) => ____arg_exception_native = $v, $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument));
                    ____arg_exception_native.Initialize();
                    $.$spc.System.Runtime.CompilerServices.Unsafe.SkipInit($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument, $.$ref(() => __propertyName_native, ($v) => __propertyName_native = $v, $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument));
                    $.$spc.System.Runtime.CompilerServices.Unsafe.SkipInit($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument, $.$ref(() => __self_native, ($v) => __self_native = $v, $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument));
                    __propertyName_native.ToJS$46(propertyName);
                    __self_native.ToJS$44(self);
                    {
                        __retVal_native = __InvokeJSFunction.call(this, ____arg_exception_native.Clone(), ____arg_return_native.Clone(), __self_native.Clone(), __propertyName_native.Clone());
                    }
                    __retVal_native.ToManaged$44($.$ref(() => __retVal, ($v) => __retVal = $v, $.$srij.System.Runtime.InteropServices.JavaScript.JSObject));
                    return __retVal;
                }
                /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/  function __InvokeJSFunction(/*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ ____arg_exception_native, /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ ____arg_return_native, /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ __self_native, /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ __propertyName_native)
                {
                    /*global::System.Span<global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument>*/ let __arguments_buffer = $.$spc.System.Span$$($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument).op_Implicit($.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument), [____arg_exception_native, ____arg_return_native, __self_native, __propertyName_native], null, null));
                    $.$srij.System.Runtime.InteropServices.JavaScript.JSFunctionBinding.InvokeJS($.$srij.System.Runtime.InteropServices.JavaScript.JavaScriptImports.__signature_GetPropertyAsJSObject_1480020778, __arguments_buffer);
                    return __arguments_buffer.get_Item(1).$v;
                }
            }
            /*global::System.Runtime.InteropServices.JavaScript.JSFunctionBinding*/ static __signature_GetPropertyAsJSObject_1480020778 = null;
            static /*byte[] */ GetPropertyAsByteArray(/*global::System.Runtime.InteropServices.JavaScript.JSObject*/ self, /*string*/ propertyName)
            {
                if ($.$srij.System.Runtime.InteropServices.JavaScript.JavaScriptImports.__signature_GetPropertyAsByteArray_657551312 === null)
                {
                    $.$srij.System.Runtime.InteropServices.JavaScript.JavaScriptImports.__signature_GetPropertyAsByteArray_657551312 = $.$srij.System.Runtime.InteropServices.JavaScript.JSFunctionBinding.BindJSFunction("INTERNAL.get_property", null, $.$spc.System.ReadOnlySpan$$($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType).op_Implicit($.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType), [$.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType.Array($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType.Byte), $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType.JSObject, $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType.String], null, null)));
                }
                {
                    /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ let ____arg_exception_native;
                    /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ let ____arg_return_native;
                    /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ let __self_native;
                    /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ let __propertyName_native;
                    /*byte[]*/ let __retVal;
                    /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ let __retVal_native;
                    $.$spc.System.Runtime.CompilerServices.Unsafe.SkipInit($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument, $.$ref(() => ____arg_return_native, ($v) => ____arg_return_native = $v, $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument));
                    ____arg_return_native.Initialize();
                    $.$spc.System.Runtime.CompilerServices.Unsafe.SkipInit($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument, $.$ref(() => ____arg_exception_native, ($v) => ____arg_exception_native = $v, $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument));
                    ____arg_exception_native.Initialize();
                    $.$spc.System.Runtime.CompilerServices.Unsafe.SkipInit($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument, $.$ref(() => __propertyName_native, ($v) => __propertyName_native = $v, $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument));
                    $.$spc.System.Runtime.CompilerServices.Unsafe.SkipInit($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument, $.$ref(() => __self_native, ($v) => __self_native = $v, $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument));
                    __propertyName_native.ToJS$46(propertyName);
                    __self_native.ToJS$44(self);
                    {
                        __retVal_native = __InvokeJSFunction.call(this, ____arg_exception_native.Clone(), ____arg_return_native.Clone(), __self_native.Clone(), __propertyName_native.Clone());
                    }
                    __retVal_native.ToManaged$23($.$ref(() => __retVal, ($v) => __retVal = $v, $.$typeArray($.$spc.System.Byte)));
                    return __retVal;
                }
                /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/  function __InvokeJSFunction(/*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ ____arg_exception_native, /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ ____arg_return_native, /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ __self_native, /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ __propertyName_native)
                {
                    /*global::System.Span<global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument>*/ let __arguments_buffer = $.$spc.System.Span$$($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument).op_Implicit($.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument), [____arg_exception_native, ____arg_return_native, __self_native, __propertyName_native], null, null));
                    $.$srij.System.Runtime.InteropServices.JavaScript.JSFunctionBinding.InvokeJS($.$srij.System.Runtime.InteropServices.JavaScript.JavaScriptImports.__signature_GetPropertyAsByteArray_657551312, __arguments_buffer);
                    return __arguments_buffer.get_Item(1).$v;
                }
            }
            /*global::System.Runtime.InteropServices.JavaScript.JSFunctionBinding*/ static __signature_GetPropertyAsByteArray_657551312 = null;
            static /*void */ SetPropertyBool(/*global::System.Runtime.InteropServices.JavaScript.JSObject*/ self, /*string*/ propertyName, /*bool*/ value)
            {
                if ($.$srij.System.Runtime.InteropServices.JavaScript.JavaScriptImports.__signature_SetPropertyBool_125660004 === null)
                {
                    $.$srij.System.Runtime.InteropServices.JavaScript.JavaScriptImports.__signature_SetPropertyBool_125660004 = $.$srij.System.Runtime.InteropServices.JavaScript.JSFunctionBinding.BindJSFunction("INTERNAL.set_property", null, $.$spc.System.ReadOnlySpan$$($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType).op_Implicit($.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType), [$.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType.Discard, $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType.JSObject, $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType.String, $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType.Boolean], null, null)));
                }
                {
                    /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ let ____arg_exception_native;
                    /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ let ____arg_return_native;
                    /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ let __self_native;
                    /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ let __propertyName_native;
                    /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ let __value_native;
                    $.$spc.System.Runtime.CompilerServices.Unsafe.SkipInit($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument, $.$ref(() => ____arg_return_native, ($v) => ____arg_return_native = $v, $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument));
                    ____arg_return_native.Initialize();
                    $.$spc.System.Runtime.CompilerServices.Unsafe.SkipInit($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument, $.$ref(() => ____arg_exception_native, ($v) => ____arg_exception_native = $v, $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument));
                    ____arg_exception_native.Initialize();
                    $.$spc.System.Runtime.CompilerServices.Unsafe.SkipInit($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument, $.$ref(() => __value_native, ($v) => __value_native = $v, $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument));
                    $.$spc.System.Runtime.CompilerServices.Unsafe.SkipInit($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument, $.$ref(() => __propertyName_native, ($v) => __propertyName_native = $v, $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument));
                    $.$spc.System.Runtime.CompilerServices.Unsafe.SkipInit($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument, $.$ref(() => __self_native, ($v) => __self_native = $v, $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument));
                    __value_native.ToJS$26(value);
                    __propertyName_native.ToJS$46(propertyName);
                    __self_native.ToJS$44(self);
                    {
                        __InvokeJSFunction.call(this, ____arg_exception_native.Clone(), ____arg_return_native.Clone(), __self_native.Clone(), __propertyName_native.Clone(), __value_native.Clone());
                    }
                }
                /*void*/  function __InvokeJSFunction(/*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ ____arg_exception_native, /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ ____arg_return_native, /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ __self_native, /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ __propertyName_native, /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ __value_native)
                {
                    $.$srij.System.Runtime.InteropServices.JavaScript.JSFunctionBinding.InvokeJS($.$srij.System.Runtime.InteropServices.JavaScript.JavaScriptImports.__signature_SetPropertyBool_125660004, $.$spc.System.Span$$($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument).op_Implicit($.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument), [____arg_exception_native, ____arg_return_native, __self_native, __propertyName_native, __value_native], null, null)));
                }
            }
            /*global::System.Runtime.InteropServices.JavaScript.JSFunctionBinding*/ static __signature_SetPropertyBool_125660004 = null;
            static /*void */ SetPropertyInt(/*global::System.Runtime.InteropServices.JavaScript.JSObject*/ self, /*string*/ propertyName, /*int*/ value)
            {
                if ($.$srij.System.Runtime.InteropServices.JavaScript.JavaScriptImports.__signature_SetPropertyInt_512418141 === null)
                {
                    $.$srij.System.Runtime.InteropServices.JavaScript.JavaScriptImports.__signature_SetPropertyInt_512418141 = $.$srij.System.Runtime.InteropServices.JavaScript.JSFunctionBinding.BindJSFunction("INTERNAL.set_property", null, $.$spc.System.ReadOnlySpan$$($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType).op_Implicit($.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType), [$.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType.Discard, $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType.JSObject, $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType.String, $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType.Int32], null, null)));
                }
                {
                    /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ let ____arg_exception_native;
                    /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ let ____arg_return_native;
                    /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ let __self_native;
                    /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ let __propertyName_native;
                    /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ let __value_native;
                    $.$spc.System.Runtime.CompilerServices.Unsafe.SkipInit($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument, $.$ref(() => ____arg_return_native, ($v) => ____arg_return_native = $v, $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument));
                    ____arg_return_native.Initialize();
                    $.$spc.System.Runtime.CompilerServices.Unsafe.SkipInit($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument, $.$ref(() => ____arg_exception_native, ($v) => ____arg_exception_native = $v, $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument));
                    ____arg_exception_native.Initialize();
                    $.$spc.System.Runtime.CompilerServices.Unsafe.SkipInit($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument, $.$ref(() => __value_native, ($v) => __value_native = $v, $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument));
                    $.$spc.System.Runtime.CompilerServices.Unsafe.SkipInit($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument, $.$ref(() => __propertyName_native, ($v) => __propertyName_native = $v, $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument));
                    $.$spc.System.Runtime.CompilerServices.Unsafe.SkipInit($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument, $.$ref(() => __self_native, ($v) => __self_native = $v, $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument));
                    __value_native.ToJS$39(value);
                    __propertyName_native.ToJS$46(propertyName);
                    __self_native.ToJS$44(self);
                    {
                        __InvokeJSFunction.call(this, ____arg_exception_native.Clone(), ____arg_return_native.Clone(), __self_native.Clone(), __propertyName_native.Clone(), __value_native.Clone());
                    }
                }
                /*void*/  function __InvokeJSFunction(/*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ ____arg_exception_native, /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ ____arg_return_native, /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ __self_native, /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ __propertyName_native, /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ __value_native)
                {
                    $.$srij.System.Runtime.InteropServices.JavaScript.JSFunctionBinding.InvokeJS($.$srij.System.Runtime.InteropServices.JavaScript.JavaScriptImports.__signature_SetPropertyInt_512418141, $.$spc.System.Span$$($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument).op_Implicit($.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument), [____arg_exception_native, ____arg_return_native, __self_native, __propertyName_native, __value_native], null, null)));
                }
            }
            /*global::System.Runtime.InteropServices.JavaScript.JSFunctionBinding*/ static __signature_SetPropertyInt_512418141 = null;
            static /*void */ SetPropertyDouble(/*global::System.Runtime.InteropServices.JavaScript.JSObject*/ self, /*string*/ propertyName, /*double*/ value)
            {
                if ($.$srij.System.Runtime.InteropServices.JavaScript.JavaScriptImports.__signature_SetPropertyDouble_1393852235 === null)
                {
                    $.$srij.System.Runtime.InteropServices.JavaScript.JavaScriptImports.__signature_SetPropertyDouble_1393852235 = $.$srij.System.Runtime.InteropServices.JavaScript.JSFunctionBinding.BindJSFunction("INTERNAL.set_property", null, $.$spc.System.ReadOnlySpan$$($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType).op_Implicit($.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType), [$.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType.Discard, $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType.JSObject, $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType.String, $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType.Double], null, null)));
                }
                {
                    /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ let ____arg_exception_native;
                    /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ let ____arg_return_native;
                    /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ let __self_native;
                    /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ let __propertyName_native;
                    /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ let __value_native;
                    $.$spc.System.Runtime.CompilerServices.Unsafe.SkipInit($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument, $.$ref(() => ____arg_return_native, ($v) => ____arg_return_native = $v, $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument));
                    ____arg_return_native.Initialize();
                    $.$spc.System.Runtime.CompilerServices.Unsafe.SkipInit($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument, $.$ref(() => ____arg_exception_native, ($v) => ____arg_exception_native = $v, $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument));
                    ____arg_exception_native.Initialize();
                    $.$spc.System.Runtime.CompilerServices.Unsafe.SkipInit($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument, $.$ref(() => __value_native, ($v) => __value_native = $v, $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument));
                    $.$spc.System.Runtime.CompilerServices.Unsafe.SkipInit($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument, $.$ref(() => __propertyName_native, ($v) => __propertyName_native = $v, $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument));
                    $.$spc.System.Runtime.CompilerServices.Unsafe.SkipInit($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument, $.$ref(() => __self_native, ($v) => __self_native = $v, $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument));
                    __value_native.ToJS$2(value);
                    __propertyName_native.ToJS$46(propertyName);
                    __self_native.ToJS$44(self);
                    {
                        __InvokeJSFunction.call(this, ____arg_exception_native.Clone(), ____arg_return_native.Clone(), __self_native.Clone(), __propertyName_native.Clone(), __value_native.Clone());
                    }
                }
                /*void*/  function __InvokeJSFunction(/*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ ____arg_exception_native, /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ ____arg_return_native, /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ __self_native, /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ __propertyName_native, /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ __value_native)
                {
                    $.$srij.System.Runtime.InteropServices.JavaScript.JSFunctionBinding.InvokeJS($.$srij.System.Runtime.InteropServices.JavaScript.JavaScriptImports.__signature_SetPropertyDouble_1393852235, $.$spc.System.Span$$($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument).op_Implicit($.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument), [____arg_exception_native, ____arg_return_native, __self_native, __propertyName_native, __value_native], null, null)));
                }
            }
            /*global::System.Runtime.InteropServices.JavaScript.JSFunctionBinding*/ static __signature_SetPropertyDouble_1393852235 = null;
            static /*void */ SetPropertyString(/*global::System.Runtime.InteropServices.JavaScript.JSObject*/ self, /*string*/ propertyName, /*string*/ value)
            {
                if ($.$srij.System.Runtime.InteropServices.JavaScript.JavaScriptImports.__signature_SetPropertyString_1189495691 === null)
                {
                    $.$srij.System.Runtime.InteropServices.JavaScript.JavaScriptImports.__signature_SetPropertyString_1189495691 = $.$srij.System.Runtime.InteropServices.JavaScript.JSFunctionBinding.BindJSFunction("INTERNAL.set_property", null, $.$spc.System.ReadOnlySpan$$($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType).op_Implicit($.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType), [$.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType.Discard, $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType.JSObject, $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType.String, $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType.String], null, null)));
                }
                {
                    /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ let ____arg_exception_native;
                    /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ let ____arg_return_native;
                    /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ let __self_native;
                    /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ let __propertyName_native;
                    /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ let __value_native;
                    $.$spc.System.Runtime.CompilerServices.Unsafe.SkipInit($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument, $.$ref(() => ____arg_return_native, ($v) => ____arg_return_native = $v, $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument));
                    ____arg_return_native.Initialize();
                    $.$spc.System.Runtime.CompilerServices.Unsafe.SkipInit($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument, $.$ref(() => ____arg_exception_native, ($v) => ____arg_exception_native = $v, $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument));
                    ____arg_exception_native.Initialize();
                    $.$spc.System.Runtime.CompilerServices.Unsafe.SkipInit($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument, $.$ref(() => __value_native, ($v) => __value_native = $v, $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument));
                    $.$spc.System.Runtime.CompilerServices.Unsafe.SkipInit($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument, $.$ref(() => __propertyName_native, ($v) => __propertyName_native = $v, $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument));
                    $.$spc.System.Runtime.CompilerServices.Unsafe.SkipInit($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument, $.$ref(() => __self_native, ($v) => __self_native = $v, $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument));
                    __value_native.ToJS$46(value);
                    __propertyName_native.ToJS$46(propertyName);
                    __self_native.ToJS$44(self);
                    {
                        __InvokeJSFunction.call(this, ____arg_exception_native.Clone(), ____arg_return_native.Clone(), __self_native.Clone(), __propertyName_native.Clone(), __value_native.Clone());
                    }
                }
                /*void*/  function __InvokeJSFunction(/*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ ____arg_exception_native, /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ ____arg_return_native, /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ __self_native, /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ __propertyName_native, /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ __value_native)
                {
                    $.$srij.System.Runtime.InteropServices.JavaScript.JSFunctionBinding.InvokeJS($.$srij.System.Runtime.InteropServices.JavaScript.JavaScriptImports.__signature_SetPropertyString_1189495691, $.$spc.System.Span$$($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument).op_Implicit($.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument), [____arg_exception_native, ____arg_return_native, __self_native, __propertyName_native, __value_native], null, null)));
                }
            }
            /*global::System.Runtime.InteropServices.JavaScript.JSFunctionBinding*/ static __signature_SetPropertyString_1189495691 = null;
            static /*void */ SetPropertyJSObject(/*global::System.Runtime.InteropServices.JavaScript.JSObject*/ self, /*string*/ propertyName, /*global::System.Runtime.InteropServices.JavaScript.JSObject*/ value)
            {
                if ($.$srij.System.Runtime.InteropServices.JavaScript.JavaScriptImports.__signature_SetPropertyJSObject_2027749310 === null)
                {
                    $.$srij.System.Runtime.InteropServices.JavaScript.JavaScriptImports.__signature_SetPropertyJSObject_2027749310 = $.$srij.System.Runtime.InteropServices.JavaScript.JSFunctionBinding.BindJSFunction("INTERNAL.set_property", null, $.$spc.System.ReadOnlySpan$$($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType).op_Implicit($.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType), [$.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType.Discard, $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType.JSObject, $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType.String, $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType.JSObject], null, null)));
                }
                {
                    /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ let ____arg_exception_native;
                    /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ let ____arg_return_native;
                    /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ let __self_native;
                    /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ let __propertyName_native;
                    /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ let __value_native;
                    $.$spc.System.Runtime.CompilerServices.Unsafe.SkipInit($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument, $.$ref(() => ____arg_return_native, ($v) => ____arg_return_native = $v, $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument));
                    ____arg_return_native.Initialize();
                    $.$spc.System.Runtime.CompilerServices.Unsafe.SkipInit($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument, $.$ref(() => ____arg_exception_native, ($v) => ____arg_exception_native = $v, $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument));
                    ____arg_exception_native.Initialize();
                    $.$spc.System.Runtime.CompilerServices.Unsafe.SkipInit($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument, $.$ref(() => __value_native, ($v) => __value_native = $v, $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument));
                    $.$spc.System.Runtime.CompilerServices.Unsafe.SkipInit($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument, $.$ref(() => __propertyName_native, ($v) => __propertyName_native = $v, $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument));
                    $.$spc.System.Runtime.CompilerServices.Unsafe.SkipInit($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument, $.$ref(() => __self_native, ($v) => __self_native = $v, $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument));
                    __value_native.ToJS$44(value);
                    __propertyName_native.ToJS$46(propertyName);
                    __self_native.ToJS$44(self);
                    {
                        __InvokeJSFunction.call(this, ____arg_exception_native.Clone(), ____arg_return_native.Clone(), __self_native.Clone(), __propertyName_native.Clone(), __value_native.Clone());
                    }
                }
                /*void*/  function __InvokeJSFunction(/*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ ____arg_exception_native, /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ ____arg_return_native, /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ __self_native, /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ __propertyName_native, /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ __value_native)
                {
                    $.$srij.System.Runtime.InteropServices.JavaScript.JSFunctionBinding.InvokeJS($.$srij.System.Runtime.InteropServices.JavaScript.JavaScriptImports.__signature_SetPropertyJSObject_2027749310, $.$spc.System.Span$$($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument).op_Implicit($.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument), [____arg_exception_native, ____arg_return_native, __self_native, __propertyName_native, __value_native], null, null)));
                }
            }
            /*global::System.Runtime.InteropServices.JavaScript.JSFunctionBinding*/ static __signature_SetPropertyJSObject_2027749310 = null;
            static /*void */ SetPropertyBytes(/*global::System.Runtime.InteropServices.JavaScript.JSObject*/ self, /*string*/ propertyName, /*byte[]*/ value)
            {
                if ($.$srij.System.Runtime.InteropServices.JavaScript.JavaScriptImports.__signature_SetPropertyBytes_1317820772 === null)
                {
                    $.$srij.System.Runtime.InteropServices.JavaScript.JavaScriptImports.__signature_SetPropertyBytes_1317820772 = $.$srij.System.Runtime.InteropServices.JavaScript.JSFunctionBinding.BindJSFunction("INTERNAL.set_property", null, $.$spc.System.ReadOnlySpan$$($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType).op_Implicit($.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType), [$.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType.Discard, $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType.JSObject, $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType.String, $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType.Array($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType.Byte)], null, null)));
                }
                {
                    /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ let ____arg_exception_native;
                    /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ let ____arg_return_native;
                    /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ let __self_native;
                    /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ let __propertyName_native;
                    /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ let __value_native;
                    $.$spc.System.Runtime.CompilerServices.Unsafe.SkipInit($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument, $.$ref(() => ____arg_return_native, ($v) => ____arg_return_native = $v, $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument));
                    ____arg_return_native.Initialize();
                    $.$spc.System.Runtime.CompilerServices.Unsafe.SkipInit($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument, $.$ref(() => ____arg_exception_native, ($v) => ____arg_exception_native = $v, $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument));
                    ____arg_exception_native.Initialize();
                    $.$spc.System.Runtime.CompilerServices.Unsafe.SkipInit($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument, $.$ref(() => __value_native, ($v) => __value_native = $v, $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument));
                    $.$spc.System.Runtime.CompilerServices.Unsafe.SkipInit($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument, $.$ref(() => __propertyName_native, ($v) => __propertyName_native = $v, $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument));
                    $.$spc.System.Runtime.CompilerServices.Unsafe.SkipInit($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument, $.$ref(() => __self_native, ($v) => __self_native = $v, $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument));
                    __value_native.ToJS$23(value);
                    __propertyName_native.ToJS$46(propertyName);
                    __self_native.ToJS$44(self);
                    {
                        __InvokeJSFunction.call(this, ____arg_exception_native.Clone(), ____arg_return_native.Clone(), __self_native.Clone(), __propertyName_native.Clone(), __value_native.Clone());
                    }
                }
                /*void*/  function __InvokeJSFunction(/*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ ____arg_exception_native, /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ ____arg_return_native, /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ __self_native, /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ __propertyName_native, /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ __value_native)
                {
                    $.$srij.System.Runtime.InteropServices.JavaScript.JSFunctionBinding.InvokeJS($.$srij.System.Runtime.InteropServices.JavaScript.JavaScriptImports.__signature_SetPropertyBytes_1317820772, $.$spc.System.Span$$($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument).op_Implicit($.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument), [____arg_exception_native, ____arg_return_native, __self_native, __propertyName_native, __value_native], null, null)));
                }
            }
            /*global::System.Runtime.InteropServices.JavaScript.JSFunctionBinding*/ static __signature_SetPropertyBytes_1317820772 = null;
            static /*global::System.Runtime.InteropServices.JavaScript.JSObject */ GetGlobalThis()
            {
                if ($.$srij.System.Runtime.InteropServices.JavaScript.JavaScriptImports.__signature_GetGlobalThis_1202228629 === null)
                {
                    $.$srij.System.Runtime.InteropServices.JavaScript.JavaScriptImports.__signature_GetGlobalThis_1202228629 = $.$srij.System.Runtime.InteropServices.JavaScript.JSFunctionBinding.BindJSFunction("INTERNAL.get_global_this", null, $.$spc.System.ReadOnlySpan$$($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType).op_Implicit($.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType), [$.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType.JSObject], null, null)));
                }
                {
                    /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ let ____arg_exception_native;
                    /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ let ____arg_return_native;
                    /*global::System.Runtime.InteropServices.JavaScript.JSObject*/ let __retVal;
                    /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ let __retVal_native;
                    $.$spc.System.Runtime.CompilerServices.Unsafe.SkipInit($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument, $.$ref(() => ____arg_return_native, ($v) => ____arg_return_native = $v, $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument));
                    ____arg_return_native.Initialize();
                    $.$spc.System.Runtime.CompilerServices.Unsafe.SkipInit($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument, $.$ref(() => ____arg_exception_native, ($v) => ____arg_exception_native = $v, $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument));
                    ____arg_exception_native.Initialize();
                    {
                        __retVal_native = __InvokeJSFunction.call(this, ____arg_exception_native.Clone(), ____arg_return_native.Clone());
                    }
                    __retVal_native.ToManaged$44($.$ref(() => __retVal, ($v) => __retVal = $v, $.$srij.System.Runtime.InteropServices.JavaScript.JSObject));
                    return __retVal;
                }
                /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/  function __InvokeJSFunction(/*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ ____arg_exception_native, /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ ____arg_return_native)
                {
                    /*global::System.Span<global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument>*/ let __arguments_buffer = $.$spc.System.Span$$($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument).op_Implicit($.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument), [____arg_exception_native, ____arg_return_native], null, null));
                    $.$srij.System.Runtime.InteropServices.JavaScript.JSFunctionBinding.InvokeJS($.$srij.System.Runtime.InteropServices.JavaScript.JavaScriptImports.__signature_GetGlobalThis_1202228629, __arguments_buffer);
                    return __arguments_buffer.get_Item(1).$v;
                }
            }
            /*global::System.Runtime.InteropServices.JavaScript.JSFunctionBinding*/ static __signature_GetGlobalThis_1202228629 = null;
            static /*global::System.Runtime.InteropServices.JavaScript.JSObject */ GetDotnetInstance()
            {
                if ($.$srij.System.Runtime.InteropServices.JavaScript.JavaScriptImports.__signature_GetDotnetInstance_1202228629 === null)
                {
                    $.$srij.System.Runtime.InteropServices.JavaScript.JavaScriptImports.__signature_GetDotnetInstance_1202228629 = $.$srij.System.Runtime.InteropServices.JavaScript.JSFunctionBinding.BindJSFunction("INTERNAL.get_dotnet_instance", null, $.$spc.System.ReadOnlySpan$$($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType).op_Implicit($.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType), [$.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType.JSObject], null, null)));
                }
                {
                    /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ let ____arg_exception_native;
                    /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ let ____arg_return_native;
                    /*global::System.Runtime.InteropServices.JavaScript.JSObject*/ let __retVal;
                    /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ let __retVal_native;
                    $.$spc.System.Runtime.CompilerServices.Unsafe.SkipInit($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument, $.$ref(() => ____arg_return_native, ($v) => ____arg_return_native = $v, $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument));
                    ____arg_return_native.Initialize();
                    $.$spc.System.Runtime.CompilerServices.Unsafe.SkipInit($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument, $.$ref(() => ____arg_exception_native, ($v) => ____arg_exception_native = $v, $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument));
                    ____arg_exception_native.Initialize();
                    {
                        __retVal_native = __InvokeJSFunction.call(this, ____arg_exception_native.Clone(), ____arg_return_native.Clone());
                    }
                    __retVal_native.ToManaged$44($.$ref(() => __retVal, ($v) => __retVal = $v, $.$srij.System.Runtime.InteropServices.JavaScript.JSObject));
                    return __retVal;
                }
                /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/  function __InvokeJSFunction(/*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ ____arg_exception_native, /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ ____arg_return_native)
                {
                    /*global::System.Span<global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument>*/ let __arguments_buffer = $.$spc.System.Span$$($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument).op_Implicit($.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument), [____arg_exception_native, ____arg_return_native], null, null));
                    $.$srij.System.Runtime.InteropServices.JavaScript.JSFunctionBinding.InvokeJS($.$srij.System.Runtime.InteropServices.JavaScript.JavaScriptImports.__signature_GetDotnetInstance_1202228629, __arguments_buffer);
                    return __arguments_buffer.get_Item(1).$v;
                }
            }
            /*global::System.Runtime.InteropServices.JavaScript.JSFunctionBinding*/ static __signature_GetDotnetInstance_1202228629 = null;
            static /*global::System.Threading.Tasks.Task<global::System.Runtime.InteropServices.JavaScript.JSObject> */ DynamicImport(/*string*/ moduleName, /*string*/ moduleUrl)
            {
                if ($.$srij.System.Runtime.InteropServices.JavaScript.JavaScriptImports.__signature_DynamicImport_119536130 === null)
                {
                    $.$srij.System.Runtime.InteropServices.JavaScript.JavaScriptImports.__signature_DynamicImport_119536130 = $.$srij.System.Runtime.InteropServices.JavaScript.JSFunctionBinding.BindJSFunction("INTERNAL.dynamic_import", null, $.$spc.System.ReadOnlySpan$$($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType).op_Implicit($.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType), [$.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType.Task$1($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType.JSObject), $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType.String, $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType.String], null, null)));
                }
                {
                    /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ let ____arg_exception_native;
                    /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ let ____arg_return_native;
                    /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ let __moduleName_native;
                    /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ let __moduleUrl_native;
                    /*global::System.Threading.Tasks.Task<global::System.Runtime.InteropServices.JavaScript.JSObject>*/ let __retVal;
                    /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ let __retVal_native;
                    $.$spc.System.Runtime.CompilerServices.Unsafe.SkipInit($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument, $.$ref(() => ____arg_return_native, ($v) => ____arg_return_native = $v, $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument));
                    ____arg_return_native.Initialize();
                    $.$spc.System.Runtime.CompilerServices.Unsafe.SkipInit($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument, $.$ref(() => ____arg_exception_native, ($v) => ____arg_exception_native = $v, $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument));
                    ____arg_exception_native.Initialize();
                    $.$spc.System.Runtime.CompilerServices.Unsafe.SkipInit($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument, $.$ref(() => __moduleUrl_native, ($v) => __moduleUrl_native = $v, $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument));
                    $.$spc.System.Runtime.CompilerServices.Unsafe.SkipInit($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument, $.$ref(() => __moduleName_native, ($v) => __moduleName_native = $v, $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument));
                    __moduleUrl_native.ToJS$46(moduleUrl);
                    __moduleName_native.ToJS$46(moduleName);
                    {
                        __retVal_native = __InvokeJSFunction.call(this, ____arg_exception_native.Clone(), ____arg_return_native.Clone(), __moduleName_native.Clone(), __moduleUrl_native.Clone());
                    }
                    __retVal_native.ToManaged$29($.$srij.System.Runtime.InteropServices.JavaScript.JSObject, $.$ref(() => __retVal, ($v) => __retVal = $v, $.$spc.System.Threading.Tasks.Task$$($.$srij.System.Runtime.InteropServices.JavaScript.JSObject)), new ($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument.ArgumentToManagedCallback$$($.$srij.System.Runtime.InteropServices.JavaScript.JSObject))().$ctor(null, /*static*/ (/*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ __task_result_arg, /*global::System.Runtime.InteropServices.JavaScript.JSObject*/ __task_result) =>
                    {
                        __task_result_arg.$v.ToManaged$44(__task_result);
                    }));
                    return __retVal;
                }
                /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/  function __InvokeJSFunction(/*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ ____arg_exception_native, /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ ____arg_return_native, /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ __moduleName_native, /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ __moduleUrl_native)
                {
                    /*global::System.Span<global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument>*/ let __arguments_buffer = $.$spc.System.Span$$($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument).op_Implicit($.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument), [____arg_exception_native, ____arg_return_native, __moduleName_native, __moduleUrl_native], null, null));
                    $.$srij.System.Runtime.InteropServices.JavaScript.JSFunctionBinding.InvokeJS($.$srij.System.Runtime.InteropServices.JavaScript.JavaScriptImports.__signature_DynamicImport_119536130, __arguments_buffer);
                    return __arguments_buffer.get_Item(1).$v;
                }
            }
            /*global::System.Runtime.InteropServices.JavaScript.JSFunctionBinding*/ static __signature_DynamicImport_119536130 = null;
            static /*void */ BindCSFunction(/*nint*/ monoMethod, /*string*/ assemblyName, /*string*/ namespaceName, /*string*/ shortClassName, /*string*/ methodName, /*int*/ signatureHash, /*nint*/ signature)
            {
                if ($.$srij.System.Runtime.InteropServices.JavaScript.JavaScriptImports.__signature_BindCSFunction_1080107758 === null)
                {
                    $.$srij.System.Runtime.InteropServices.JavaScript.JavaScriptImports.__signature_BindCSFunction_1080107758 = $.$srij.System.Runtime.InteropServices.JavaScript.JSFunctionBinding.BindJSFunction("INTERNAL.mono_wasm_bind_cs_function", null, $.$spc.System.ReadOnlySpan$$($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType).op_Implicit($.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType), [$.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType.Discard, $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType.IntPtr, $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType.String, $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType.String, $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType.String, $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType.String, $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType.Int32, $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType.IntPtr], null, null)));
                }
                {
                    /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ let ____arg_exception_native;
                    /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ let ____arg_return_native;
                    /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ let __monoMethod_native;
                    /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ let __assemblyName_native;
                    /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ let __namespaceName_native;
                    /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ let __shortClassName_native;
                    /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ let __methodName_native;
                    /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ let __signatureHash_native;
                    /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ let __signature_native;
                    $.$spc.System.Runtime.CompilerServices.Unsafe.SkipInit($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument, $.$ref(() => ____arg_return_native, ($v) => ____arg_return_native = $v, $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument));
                    ____arg_return_native.Initialize();
                    $.$spc.System.Runtime.CompilerServices.Unsafe.SkipInit($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument, $.$ref(() => ____arg_exception_native, ($v) => ____arg_exception_native = $v, $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument));
                    ____arg_exception_native.Initialize();
                    $.$spc.System.Runtime.CompilerServices.Unsafe.SkipInit($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument, $.$ref(() => __signature_native, ($v) => __signature_native = $v, $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument));
                    $.$spc.System.Runtime.CompilerServices.Unsafe.SkipInit($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument, $.$ref(() => __signatureHash_native, ($v) => __signatureHash_native = $v, $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument));
                    $.$spc.System.Runtime.CompilerServices.Unsafe.SkipInit($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument, $.$ref(() => __methodName_native, ($v) => __methodName_native = $v, $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument));
                    $.$spc.System.Runtime.CompilerServices.Unsafe.SkipInit($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument, $.$ref(() => __shortClassName_native, ($v) => __shortClassName_native = $v, $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument));
                    $.$spc.System.Runtime.CompilerServices.Unsafe.SkipInit($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument, $.$ref(() => __namespaceName_native, ($v) => __namespaceName_native = $v, $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument));
                    $.$spc.System.Runtime.CompilerServices.Unsafe.SkipInit($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument, $.$ref(() => __assemblyName_native, ($v) => __assemblyName_native = $v, $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument));
                    $.$spc.System.Runtime.CompilerServices.Unsafe.SkipInit($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument, $.$ref(() => __monoMethod_native, ($v) => __monoMethod_native = $v, $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument));
                    __signature_native.ToJS$34(signature);
                    __signatureHash_native.ToJS$39(signatureHash);
                    __methodName_native.ToJS$46(methodName);
                    __shortClassName_native.ToJS$46(shortClassName);
                    __namespaceName_native.ToJS$46(namespaceName);
                    __assemblyName_native.ToJS$46(assemblyName);
                    __monoMethod_native.ToJS$34(monoMethod);
                    {
                        __InvokeJSFunction.call(this, ____arg_exception_native.Clone(), ____arg_return_native.Clone(), __monoMethod_native.Clone(), __assemblyName_native.Clone(), __namespaceName_native.Clone(), __shortClassName_native.Clone(), __methodName_native.Clone(), __signatureHash_native.Clone(), __signature_native.Clone());
                    }
                }
                /*void*/  function __InvokeJSFunction(/*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ ____arg_exception_native, /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ ____arg_return_native, /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ __monoMethod_native, /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ __assemblyName_native, /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ __namespaceName_native, /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ __shortClassName_native, /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ __methodName_native, /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ __signatureHash_native, /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ __signature_native)
                {
                    $.$srij.System.Runtime.InteropServices.JavaScript.JSFunctionBinding.InvokeJS($.$srij.System.Runtime.InteropServices.JavaScript.JavaScriptImports.__signature_BindCSFunction_1080107758, $.$spc.System.Span$$($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument).op_Implicit($.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument), [____arg_exception_native, ____arg_return_native, __monoMethod_native, __assemblyName_native, __namespaceName_native, __shortClassName_native, __methodName_native, __signatureHash_native, __signature_native], null, null)));
                }
            }
            /*global::System.Runtime.InteropServices.JavaScript.JSFunctionBinding*/ static __signature_BindCSFunction_1080107758 = null;
            static /*void */ Log(/*string*/ message)
            {
                if ($.$srij.System.Runtime.InteropServices.JavaScript.JavaScriptImports.__signature_Log_92020726 === null)
                {
                    $.$srij.System.Runtime.InteropServices.JavaScript.JavaScriptImports.__signature_Log_92020726 = $.$srij.System.Runtime.InteropServices.JavaScript.JSFunctionBinding.BindJSFunction("globalThis.console.log", null, $.$spc.System.ReadOnlySpan$$($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType).op_Implicit($.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType), [$.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType.DiscardNoWait, $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType.String], null, null)));
                }
                {
                    /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ let ____arg_exception_native;
                    /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ let ____arg_return_native;
                    /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ let __message_native;
                    $.$spc.System.Runtime.CompilerServices.Unsafe.SkipInit($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument, $.$ref(() => ____arg_return_native, ($v) => ____arg_return_native = $v, $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument));
                    ____arg_return_native.Initialize();
                    $.$spc.System.Runtime.CompilerServices.Unsafe.SkipInit($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument, $.$ref(() => ____arg_exception_native, ($v) => ____arg_exception_native = $v, $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument));
                    ____arg_exception_native.Initialize();
                    $.$spc.System.Runtime.CompilerServices.Unsafe.SkipInit($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument, $.$ref(() => __message_native, ($v) => __message_native = $v, $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument));
                    __message_native.ToJS$46(message);
                    {
                        __InvokeJSFunction.call(this, ____arg_exception_native.Clone(), ____arg_return_native.Clone(), __message_native.Clone());
                    }
                }
                /*void*/  function __InvokeJSFunction(/*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ ____arg_exception_native, /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ ____arg_return_native, /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ __message_native)
                {
                    $.$srij.System.Runtime.InteropServices.JavaScript.JSFunctionBinding.InvokeJS($.$srij.System.Runtime.InteropServices.JavaScript.JavaScriptImports.__signature_Log_92020726, $.$spc.System.Span$$($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument).op_Implicit($.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument), [____arg_exception_native, ____arg_return_native, __message_native], null, null)));
                }
            }
            /*global::System.Runtime.InteropServices.JavaScript.JSFunctionBinding*/ static __signature_Log_92020726 = null;
            static $h = 367357;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"m":[{"r":262145,"p":[{"n":"self","p":2267901},{"n":"propertyName","p":1310721}],"n":"HasProperty","d":367357,"h":4295334653,"f":33,"a":[{"t":1219325,"c":30065990397,"a":[{"v":"INTERNAL.has_property","t":1310721}]},{"t":37683201,"c":4332650497}]},{"r":1310721,"p":[{"n":"self","p":2267901},{"n":"propertyName","p":1310721}],"n":"GetTypeOfProperty","d":367357,"h":8590301949,"f":33,"a":[{"t":1219325,"c":30065990397,"a":[{"v":"INTERNAL.get_typeof_property","t":1310721}]},{"t":37683201,"c":4332650497}]},{"r":262145,"p":[{"n":"self","p":2267901},{"n":"propertyName","p":1310721}],"n":"GetPropertyAsBoolean","d":367357,"h":12885269245,"f":33,"a":[{"t":1219325,"c":30065990397,"a":[{"v":"INTERNAL.get_property","t":1310721}]},{"t":37683201,"c":4332650497}]},{"r":655361,"p":[{"n":"self","p":2267901},{"n":"propertyName","p":1310721}],"n":"GetPropertyAsInt32","d":367357,"h":17180236541,"f":33,"a":[{"t":1219325,"c":30065990397,"a":[{"v":"INTERNAL.get_property","t":1310721}]},{"t":37683201,"c":4332650497}]},{"r":1179649,"p":[{"n":"self","p":2267901},{"n":"propertyName","p":1310721}],"n":"GetPropertyAsDouble","d":367357,"h":21475203837,"f":33,"a":[{"t":1219325,"c":30065990397,"a":[{"v":"INTERNAL.get_property","t":1310721}]},{"t":37683201,"c":4332650497}]},{"r":1310721,"p":[{"n":"self","p":2267901},{"n":"propertyName","p":1310721}],"n":"GetPropertyAsString","d":367357,"h":25770171133,"f":33,"a":[{"t":1219325,"c":30065990397,"a":[{"v":"INTERNAL.get_property","t":1310721}]},{"t":37683201,"c":4332650497}]},{"r":2267901,"p":[{"n":"self","p":2267901},{"n":"propertyName","p":1310721}],"n":"GetPropertyAsJSObject","d":367357,"h":30065138429,"f":33,"a":[{"t":1219325,"c":30065990397,"a":[{"v":"INTERNAL.get_property","t":1310721}]},{"t":37683201,"c":4332650497}]},{"r":0,"p":[{"n":"self","p":2267901},{"n":"propertyName","p":1310721}],"n":"GetPropertyAsByteArray","d":367357,"h":34360105725,"f":33,"a":[{"t":1219325,"c":30065990397,"a":[{"v":"INTERNAL.get_property","t":1310721}]},{"t":37683201,"c":4332650497}]},{"r":65537,"p":[{"n":"self","p":2267901},{"n":"propertyName","p":1310721},{"n":"value","p":262145}],"n":"SetPropertyBool","d":367357,"h":38655073021,"f":33,"a":[{"t":1219325,"c":30065990397,"a":[{"v":"INTERNAL.set_property","t":1310721}]},{"t":37683201,"c":4332650497}]},{"r":65537,"p":[{"n":"self","p":2267901},{"n":"propertyName","p":1310721},{"n":"value","p":655361}],"n":"SetPropertyInt","d":367357,"h":42950040317,"f":33,"a":[{"t":1219325,"c":30065990397,"a":[{"v":"INTERNAL.set_property","t":1310721}]},{"t":37683201,"c":4332650497}]},{"r":65537,"p":[{"n":"self","p":2267901},{"n":"propertyName","p":1310721},{"n":"value","p":1179649}],"n":"SetPropertyDouble","d":367357,"h":47245007613,"f":33,"a":[{"t":1219325,"c":30065990397,"a":[{"v":"INTERNAL.set_property","t":1310721}]},{"t":37683201,"c":4332650497}]},{"r":65537,"p":[{"n":"self","p":2267901},{"n":"propertyName","p":1310721},{"n":"value","p":1310721}],"n":"SetPropertyString","d":367357,"h":51539974909,"f":33,"a":[{"t":1219325,"c":30065990397,"a":[{"v":"INTERNAL.set_property","t":1310721}]},{"t":37683201,"c":4332650497}]},{"r":65537,"p":[{"n":"self","p":2267901},{"n":"propertyName","p":1310721},{"n":"value","p":2267901}],"n":"SetPropertyJSObject","d":367357,"h":55834942205,"f":33,"a":[{"t":1219325,"c":30065990397,"a":[{"v":"INTERNAL.set_property","t":1310721}]},{"t":37683201,"c":4332650497}]},{"r":65537,"p":[{"n":"self","p":2267901},{"n":"propertyName","p":1310721},{"n":"value","p":0}],"n":"SetPropertyBytes","d":367357,"h":60129909501,"f":33,"a":[{"t":1219325,"c":30065990397,"a":[{"v":"INTERNAL.set_property","t":1310721}]},{"t":37683201,"c":4332650497}]},{"r":2267901,"n":"GetGlobalThis","d":367357,"h":64424876797,"f":33,"a":[{"t":1219325,"c":30065990397,"a":[{"v":"INTERNAL.get_global_this","t":1310721}]},{"t":37683201,"c":4332650497}]},{"r":2267901,"n":"GetDotnetInstance","d":367357,"h":68719844093,"f":33,"a":[{"t":1219325,"c":30065990397,"a":[{"v":"INTERNAL.get_dotnet_instance","t":1310721}]},{"t":37683201,"c":4332650497}]},{"r":$.$spc.System.Threading.Tasks.Task$$($.$srij.System.Runtime.InteropServices.JavaScript.JSObject).$h,"p":[{"n":"moduleName","p":1310721},{"n":"moduleUrl","p":1310721}],"n":"DynamicImport","d":367357,"h":73014811389,"f":33,"a":[{"t":1219325,"c":30065990397,"a":[{"v":"INTERNAL.dynamic_import","t":1310721}]},{"t":37683201,"c":4332650497}]},{"r":65537,"p":[{"n":"monoMethod","p":786433},{"n":"assemblyName","p":1310721},{"n":"namespaceName","p":1310721},{"n":"shortClassName","p":1310721},{"n":"methodName","p":1310721},{"n":"signatureHash","p":655361},{"n":"signature","p":786433}],"n":"BindCSFunction","d":367357,"h":77309778685,"f":33,"a":[{"t":1219325,"c":30065990397,"a":[{"v":"INTERNAL.mono_wasm_bind_cs_function","t":1310721}]},{"t":37683201,"c":4332650497}]},{"r":65537,"p":[{"n":"message","p":1310721,"a":[{"t":$.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalAsAttribute$$($.$srij.System.Runtime.InteropServices.JavaScript.JSType.String).$h,"c":Number(BigInt($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalAsAttribute$$($.$srij.System.Runtime.InteropServices.JavaScript.JSType.String).$h)|0x100000000n)}]}],"n":"Log","d":367357,"h":81604745981,"f":33,"a":[{"t":1219325,"c":30065990397,"a":[{"v":"globalThis.console.log","t":1310721}]},{"t":37683201,"c":4332650497}]}],"l":[{"t":563965,"n":"__signature_HasProperty_393970128","d":367357,"h":85899713277,"f":34},{"t":563965,"n":"__signature_GetTypeOfProperty_1139574135","d":367357,"h":90194680573,"f":34},{"t":563965,"n":"__signature_GetPropertyAsBoolean_393970128","d":367357,"h":94489647869,"f":34},{"t":563965,"n":"__signature_GetPropertyAsInt32_1813830729","d":367357,"h":98784615165,"f":34},{"t":563965,"n":"__signature_GetPropertyAsDouble_705601847","d":367357,"h":103079582461,"f":34},{"t":563965,"n":"__signature_GetPropertyAsString_1139574135","d":367357,"h":107374549757,"f":34},{"t":563965,"n":"__signature_GetPropertyAsJSObject_1480020778","d":367357,"h":111669517053,"f":34},{"t":563965,"n":"__signature_GetPropertyAsByteArray_657551312","d":367357,"h":115964484349,"f":34},{"t":563965,"n":"__signature_SetPropertyBool_125660004","d":367357,"h":120259451645,"f":34},{"t":563965,"n":"__signature_SetPropertyInt_512418141","d":367357,"h":124554418941,"f":34},{"t":563965,"n":"__signature_SetPropertyDouble_1393852235","d":367357,"h":128849386237,"f":34},{"t":563965,"n":"__signature_SetPropertyString_1189495691","d":367357,"h":133144353533,"f":34},{"t":563965,"n":"__signature_SetPropertyJSObject_2027749310","d":367357,"h":137439320829,"f":34},{"t":563965,"n":"__signature_SetPropertyBytes_1317820772","d":367357,"h":141734288125,"f":34},{"t":563965,"n":"__signature_GetGlobalThis_1202228629","d":367357,"h":146029255421,"f":34},{"t":563965,"n":"__signature_GetDotnetInstance_1202228629","d":367357,"h":150324222717,"f":34},{"t":563965,"n":"__signature_DynamicImport_119536130","d":367357,"h":154619190013,"f":34},{"t":563965,"n":"__signature_BindCSFunction_1080107758","d":367357,"h":158914157309,"f":34},{"t":563965,"n":"__signature_Log_92020726","d":367357,"h":163209124605,"f":34}],"h":367357}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.Runtime.InteropServices.JavaScript.JavaScriptImports`; }
        });
        
        $asm.$cls("$srij.System.Runtime.InteropServices.JavaScript.JavaScriptExports", ($self) => class JavaScriptExports
        {
            static /*void */ CallEntrypoint(/*JSMarshalerArgument**/ arguments_buffer)
            {
                /*ref JSMarshalerArgument*/ let arg_exc = arguments_buffer.Add(0);
                /*ref JSMarshalerArgument*/ let arg_res = arguments_buffer.Add(1);
                /*ref JSMarshalerArgument*/ let arg_1 = arguments_buffer.Add(2);
                /*ref JSMarshalerArgument*/ let arg_2 = arguments_buffer.Add(3);
                /*ref JSMarshalerArgument*/ let arg_3 = arguments_buffer.Add(4);
                try
                {
                    /*IntPtr*/ let assemblyNamePtr;
                    arg_1.$v.ToManaged$34($.$ref(() => assemblyNamePtr, ($v) => assemblyNamePtr = $v, $.$spc.System.IntPtr));
                    /*string?[]?*/ let args;
                    arg_2.$v.ToManaged$47($.$ref(() => args, ($v) => args = $v, $.$typeArray($.$spc.System.String)));
                    /*bool*/ let waitForDebugger;
                    arg_3.$v.ToManaged$26($.$ref(() => waitForDebugger, ($v) => waitForDebugger = $v, $.$spc.System.Boolean));
                    /*Task<int>?*/ let result = $.$srij.System.Runtime.InteropServices.JavaScript.JSHostImplementation.CallEntrypoint(assemblyNamePtr, args, waitForDebugger);
                    arg_res.$v.ToJS$29($.$spc.System.Int32, result, new ($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument.ArgumentToJSCallback$$($.$spc.System.Int32))().$ctor(this,  (/*JSMarshalerArgument*/ arg, /*int*/ value) =>
                    {
                        arg.$v.ToJS$39(value);
                    }));
                }
                catch(ex)
                {
                    $.$spc.System.Environment.FailFast(`CallEntrypoint: Unexpected synchronous failure (ManagedThreadId ${$.$spc.System.Environment.CurrentManagedThreadId}): ` + $.$spc.System.Exception.ToString.call(ex));
                }
            }
            static /*void */ LoadLazyAssembly(/*JSMarshalerArgument**/ arguments_buffer)
            {
                /*ref JSMarshalerArgument*/ let arg_exc = arguments_buffer.Add(0);
                /*ref JSMarshalerArgument*/ let arg_1 = arguments_buffer.Add(2);
                /*ref JSMarshalerArgument*/ let arg_2 = arguments_buffer.Add(3);
                try
                {
                    /*byte[]?*/ let dllBytes;
                    arg_1.$v.ToManaged$23($.$ref(() => dllBytes, ($v) => dllBytes = $v, $.$typeArray($.$spc.System.Byte)));
                    /*byte[]?*/ let pdbBytes;
                    arg_2.$v.ToManaged$23($.$ref(() => pdbBytes, ($v) => pdbBytes = $v, $.$typeArray($.$spc.System.Byte)));
                    if (dllBytes !== null)
                    {
                        $.$srij.System.Runtime.InteropServices.JavaScript.JSHostImplementation.LoadLazyAssembly(dllBytes, pdbBytes);
                    }
                }
                catch(ex)
                {
                    arg_exc.$v.ToJS$48(ex);
                }
            }
            static /*void */ LoadSatelliteAssembly(/*JSMarshalerArgument**/ arguments_buffer)
            {
                /*ref JSMarshalerArgument*/ let arg_exc = arguments_buffer.Add(0);
                /*ref JSMarshalerArgument*/ let arg_1 = arguments_buffer.Add(2);
                try
                {
                    /*byte[]?*/ let dllBytes;
                    arg_1.$v.ToManaged$23($.$ref(() => dllBytes, ($v) => dllBytes = $v, $.$typeArray($.$spc.System.Byte)));
                    if (dllBytes !== null)
                    {
                        $.$srij.System.Runtime.InteropServices.JavaScript.JSHostImplementation.LoadSatelliteAssembly(dllBytes);
                    }
                }
                catch(ex)
                {
                    arg_exc.$v.ToJS$48(ex);
                }
            }
            static /*void */ ReleaseJSOwnedObjectByGCHandle(/*JSMarshalerArgument**/ arguments_buffer)
            {
                /*ref JSMarshalerArgument*/ let arg_exc = arguments_buffer.Add(0);
                /*ref JSMarshalerArgument*/ let arg_1 = arguments_buffer.Add(2);
                try
                {
                    /*var*/ let ctx = arg_exc.$v.ToManagedContext;
                    ctx.ReleaseJSOwnedObjectByGCHandle(arg_1.$v.slot.GCHandle);
                }
                catch(ex)
                {
                    $.$spc.System.Environment.FailFast(`ReleaseJSOwnedObjectByGCHandle: Unexpected synchronous failure (ManagedThreadId ${$.$spc.System.Environment.CurrentManagedThreadId}): ` + $.$spc.System.Exception.ToString.call(ex));
                }
            }
            static /*void */ CallDelegate(/*JSMarshalerArgument**/ arguments_buffer)
            {
                /*ref JSMarshalerArgument*/ let arg_exc = arguments_buffer.Add(0);
                /*ref JSMarshalerArgument*/ let arg_1 = arguments_buffer.Add(2);
                try
                {
                    /*GCHandle*/ let callback_gc_handle = $.$spc.System.Runtime.InteropServices.GCHandle.op_Explicit(arg_1.$v.slot.GCHandle);
                    let callback;
                    if ($.$is(callback_gc_handle.Target, $.$srij.System.Runtime.InteropServices.JavaScript.JSHostImplementation.ToManagedCallback, { set $v(v){ callback = v; } }))
                    {
                        callback.Invoke(arguments_buffer);
                    }
                    else 
                    {
                        throw new $.$spc.System.InvalidOperationException().$ctor$10($.$srij.System.SR.NullToManagedCallback);
                    }
                }
                catch(ex)
                {
                    arg_exc.$v.ToJS$48(ex);
                }
            }
            static /*void */ CompleteTask(/*JSMarshalerArgument**/ arguments_buffer)
            {
                /*ref JSMarshalerArgument*/ let arg_exc = arguments_buffer.Add(0);
                /*ref JSMarshalerArgument*/ let arg_res = arguments_buffer.Add(1);
                /*ref JSMarshalerArgument*/ let arg_1 = arguments_buffer.Add(2);
                try
                {
                    /*var*/ let ctx = arg_exc.$v.ToManagedContext;
                    /*var*/ let holder = ctx.GetPromiseHolder(arg_1.$v.slot.GCHandle);
                    /*JSHostImplementation.ToManagedCallback*/ let callback;
                    callback = holder.Callback;
                    ctx.ReleasePromiseHolder(arg_1.$v.slot.GCHandle);
                    callback.Invoke(arguments_buffer);
                }
                catch(ex)
                {
                    $.$spc.System.Environment.FailFast(`CompleteTask: Unexpected synchronous failure (ManagedThreadId ${$.$spc.System.Environment.CurrentManagedThreadId}): ` + $.$spc.System.Exception.ToString.call(ex));
                }
            }
            static /*void */ GetManagedStackTrace(/*JSMarshalerArgument**/ arguments_buffer)
            {
                /*ref JSMarshalerArgument*/ let arg_exc = arguments_buffer.Add(0);
                /*ref JSMarshalerArgument*/ let arg_res = arguments_buffer.Add(1);
                /*ref JSMarshalerArgument*/ let arg_1 = arguments_buffer.Add(2);
                try
                {
                    arg_exc.$v.AssertCurrentThreadContext();
                    /*GCHandle*/ let exception_gc_handle = $.$spc.System.Runtime.InteropServices.GCHandle.op_Explicit(arg_1.$v.slot.GCHandle);
                    let exception;
                    if ($.$is(exception_gc_handle.Target, $.$spc.System.Exception, { set $v(v){ exception = v; } }))
                    {
                        arg_res.$v.ToJS$46(exception.StackTrace);
                    }
                    else 
                    {
                        throw new $.$spc.System.InvalidOperationException().$ctor$10($.$srij.System.SR.UnableToResolveHandleAsException);
                    }
                }
                catch(ex)
                {
                    arg_exc.$v.ToJS$48(ex);
                }
            }
            static /*void */ BindAssemblyExports(/*JSMarshalerArgument**/ arguments_buffer)
            {
                /*ref JSMarshalerArgument*/ let arg_exc = arguments_buffer.Add(0);
                /*ref JSMarshalerArgument*/ let arg_res = arguments_buffer.Add(1);
                /*ref JSMarshalerArgument*/ let arg_1 = arguments_buffer.Add(2);
                try
                {
                    /*string?*/ let assemblyName;
                    arg_exc.$v.AssertCurrentThreadContext();
                    arg_1.$v.ToManaged$46($.$ref(() => assemblyName, ($v) => assemblyName = $v, $.$spc.System.String));
                    /*var*/ let result = $.$srij.System.Runtime.InteropServices.JavaScript.JSHostImplementation.BindAssemblyExports(assemblyName);
                    arg_res.$v.ToJS$28(result);
                }
                catch(ex)
                {
                    $.$spc.System.Environment.FailFast(`BindAssemblyExports: Unexpected synchronous failure (ManagedThreadId ${$.$spc.System.Environment.CurrentManagedThreadId}): ` + $.$spc.System.Exception.ToString.call(ex));
                }
            }
            static /*void */ StopProfile()
            {
            }
            static /*void */ DumpAotProfileData(/*ref byte*/ buf, /*int*/ len, /*string*/ extraArg)
            {
                if (len === 0)
                {
                    throw new $.$spc.System.InvalidOperationException().$ctor$10($.$srij.System.SR.EmptyProfileData);
                }
                /*fixed*/ 
                {
                    /*void**/ let p = buf;
                    /*var*/ let span = new ($.$spc.System.ReadOnlySpan$$($.$spc.System.Byte))().$ctor$4(p, len);
                    /*var*/ let module = $.$srij.System.Runtime.InteropServices.JavaScript.JSHost.DotnetInstance.GetPropertyAsJSObject("INTERNAL");
                    if (module === null)
                    {
                        throw new $.$spc.System.InvalidOperationException().$ctor$9();
                    }
                    module.SetProperty$5("aotProfileData", span.ToArray());
                }
            }
            static $h = 301821;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"m":[{"r":65537,"p":[{"n":"arguments_buffer","p":0}],"n":"CallEntrypoint","d":301821,"h":4295269117,"f":33},{"r":65537,"p":[{"n":"arguments_buffer","p":0}],"n":"LoadLazyAssembly","d":301821,"h":8590236413,"f":33},{"r":65537,"p":[{"n":"arguments_buffer","p":0}],"n":"LoadSatelliteAssembly","d":301821,"h":12885203709,"f":33},{"r":65537,"p":[{"n":"arguments_buffer","p":0}],"n":"ReleaseJSOwnedObjectByGCHandle","d":301821,"h":17180171005,"f":33},{"r":65537,"p":[{"n":"arguments_buffer","p":0}],"n":"CallDelegate","d":301821,"h":21475138301,"f":33},{"r":65537,"p":[{"n":"arguments_buffer","p":0}],"n":"CompleteTask","d":301821,"h":25770105597,"f":33},{"r":65537,"p":[{"n":"arguments_buffer","p":0}],"n":"GetManagedStackTrace","d":301821,"h":30065072893,"f":33},{"r":65537,"p":[{"n":"arguments_buffer","p":0}],"n":"BindAssemblyExports","d":301821,"h":34360040189,"f":33},{"r":65537,"n":"StopProfile","d":301821,"h":38655007485,"f":33},{"r":65537,"p":[{"n":"buf","p":393217,"f":4},{"n":"len","p":655361},{"n":"extraArg","p":1310721}],"n":"DumpAotProfileData","d":301821,"h":42949974781,"f":33}],"h":301821}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.Runtime.InteropServices.JavaScript.JavaScriptExports`; }
        });
        
        $asm.$cls("$srij.Interop", ($self) => class Interop
        {
            static $_Runtime;
            static get Runtime()
            {
                let $cls = $.$srij.Interop;
                return $cls.$_Runtime ??= $asm.$ncls("$srij.Interop.Runtime", ($self) => class Runtime
                {
                    static $h = 170749;
                    static $f = 0b10000000000010000;
                    static $k = 1;
                    static $$md;
                    static get $md() { return this.$$md ??= {"b":131073,"d":105213,"h":170749}; }
                    static get $b() { return $.$spc.System.Object; }
                    static get $fullName() { return `Interop.Runtime`; }
                }, $cls, ($v) => $cls.$_Runtime = $v);
            }
            static $h = 105213;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"j":[170749],"h":105213}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `Interop`; }
        });
        
        $asm.$cls("$srij.System.SR", ($self) => class SR
        {
            /*global::System.Resources.ResourceManager*/ static s_resourceManager = null;
            /*global::System.Globalization.CultureInfo*/ static resourceCulture = null;
            static /*global::System.Resources.ResourceManager */ get ResourceManager()
            {
                if ($.$spc.System.Object.ReferenceEquals($.$srij.System.SR.s_resourceManager, null))
                {
                    /*global::System.Resources.ResourceManager*/ let temp = new $.$spc.System.Resources.ResourceManager().$ctor$3("System.Runtime.InteropServices.JavaScript", $.$srij.System.SR.$type.Assembly);
                    $.$srij.System.SR.s_resourceManager = temp;
                }
                return $.$srij.System.SR.s_resourceManager;
            }
            static /*global::System.Globalization.CultureInfo */ get Culture()
            {
                return $.$srij.System.SR.resourceCulture;
            }
            static /*global::System.Globalization.CultureInfo */ set Culture(value)
            {
                $.$srij.System.SR.resourceCulture = value;
            }
            static /*string */ get ArgumentCannotBeNull()
            {
                return "Invalid argument: {0} can not be null.";
            }
            static /*string */ FormatArgumentCannotBeNull(/*object*/ arg1)
            {
                return $.$spc.System.String.Format("Invalid argument: {0} can not be null.", arg1);
            }
            static /*string */ get ArgumentCannotBeNullWithLength()
            {
                return "Invalid argument: {0} can not be null and must have a length.";
            }
            static /*string */ FormatArgumentCannotBeNullWithLength(/*object*/ arg1)
            {
                return $.$spc.System.String.Format("Invalid argument: {0} can not be null and must have a length.", arg1);
            }
            static /*string */ get SystemRuntimeInteropServicesJavaScript_PlatformNotSupported()
            {
                return "System.Runtime.InteropServices.JavaScript is not supported on this platform.";
            }
            static /*string */ get TypedArrayNotCorrectType()
            {
                return "TypedArray is not of correct type.";
            }
            static /*string */ get UnableCastNullToType()
            {
                return "Unable to cast null to type {0}.";
            }
            static /*string */ FormatUnableCastNullToType(/*object*/ arg1)
            {
                return $.$spc.System.String.Format("Unable to cast null to type {0}.", arg1);
            }
            static /*string */ get UnableCastObjectToType()
            {
                return "Unable to cast object of type {0} to type {1}.";
            }
            static /*string */ FormatUnableCastObjectToType(/*object*/ arg1, /*object*/ arg2)
            {
                return $.$spc.System.String.Format$1("Unable to cast object of type {0} to type {1}.", arg1, arg2);
            }
            static /*string */ get MissingManagedEntrypointHandle()
            {
                return "Managed entrypoint handle is not set.";
            }
            static /*string */ get CannotResolveManagedEntrypointHandle()
            {
                return "Cannot resolve managed entrypoint handle.";
            }
            static /*string */ get ReturnTypeNotSupportedForMain()
            {
                return "Return type '{0}' from main method in not supported.";
            }
            static /*string */ FormatReturnTypeNotSupportedForMain(/*object*/ arg1)
            {
                return $.$spc.System.String.Format("Return type '{0}' from main method in not supported.", arg1);
            }
            static /*string */ get NullToManagedCallback()
            {
                return "ToManagedCallback is null.";
            }
            static /*string */ get NullPromiseHolder()
            {
                return "PromiseHolder is null.";
            }
            static /*string */ get EmptyProfileData()
            {
                return "Empty profile data.";
            }
            static /*string */ get ErrorLegacySettingProperty()
            {
                return "Error setting {0} on (js-obj js '{1}'): {2}.";
            }
            static /*string */ FormatErrorLegacySettingProperty(/*object*/ arg1, /*object*/ arg2, /*object*/ arg3)
            {
                return $.$spc.System.String.Format$2("Error setting {0} on (js-obj js '{1}'): {2}.", arg1, arg2, arg3);
            }
            static /*string */ get ErrorResolvingFromGlobalThis()
            {
                return "Error resolving property {0} from globalThis.";
            }
            static /*string */ FormatErrorResolvingFromGlobalThis(/*object*/ arg1)
            {
                return $.$spc.System.String.Format("Error resolving property {0} from globalThis.", arg1);
            }
            static /*string */ get FailedToMarshalException()
            {
                return "Failed to marshal exception.";
            }
            static /*string */ get FailedToMarshalPromiseHolder()
            {
                return "Failed to marshal Promise callback.";
            }
            static /*string */ get InvalidInFlightCounter()
            {
                return "Invalid InFlightCounter for JSObject {0}, expected: {1}, actual: {2}.";
            }
            static /*string */ FormatInvalidInFlightCounter(/*object*/ arg1, /*object*/ arg2, /*object*/ arg3)
            {
                return $.$spc.System.String.Format$2("Invalid InFlightCounter for JSObject {0}, expected: {1}, actual: {2}.", arg1, arg2, arg3);
            }
            static /*string */ get ToJSNotImplemented()
            {
                return "ToJS for {0} is not implemented.";
            }
            static /*string */ FormatToJSNotImplemented(/*object*/ arg1)
            {
                return $.$spc.System.String.Format("ToJS for {0} is not implemented.", arg1);
            }
            static /*string */ get ToManagedNotImplemented()
            {
                return "ToManaged for {0} is not implemented.";
            }
            static /*string */ FormatToManagedNotImplemented(/*object*/ arg1)
            {
                return $.$spc.System.String.Format("ToManaged for {0} is not implemented.", arg1);
            }
            static /*string */ get UnableToResolveHandleAsException()
            {
                return "Unable to resolve the handle as an Exception.";
            }
            static /*string */ get UnsupportedArrayType()
            {
                return "Unsupported array type {0}. Only single-dimensional arrays with a zero lower bound can be marshaled to JS.";
            }
            static /*string */ FormatUnsupportedArrayType(/*object*/ arg1)
            {
                return $.$spc.System.String.Format("Unsupported array type {0}. Only single-dimensional arrays with a zero lower bound can be marshaled to JS.", arg1);
            }
            static /*string */ get UnsupportedElementType()
            {
                return "Unsupported element type {0}.";
            }
            static /*string */ FormatUnsupportedElementType(/*object*/ arg1)
            {
                return $.$spc.System.String.Format("Unsupported element type {0}.", arg1);
            }
            static /*string */ get UnsupportedEnumType()
            {
                return "Unsupported enum type {0}.";
            }
            static /*string */ FormatUnsupportedEnumType(/*object*/ arg1)
            {
                return $.$spc.System.String.Format("Unsupported enum type {0}.", arg1);
            }
            static /*string */ get UnsupportedLegacyMarshlerType()
            {
                return "Unsupported marshal type {0}.";
            }
            static /*string */ FormatUnsupportedLegacyMarshlerType(/*object*/ arg1)
            {
                return $.$spc.System.String.Format("Unsupported marshal type {0}.", arg1);
            }
            static /*string */ get UnsupportedNullableType()
            {
                return "Unsupported nullable type {0}.";
            }
            static /*string */ FormatUnsupportedNullableType(/*object*/ arg1)
            {
                return $.$spc.System.String.Format("Unsupported nullable type {0}.", arg1);
            }
            static /*string */ get UnsupportedTaskResultType()
            {
                return "Unsupported task result type {0}.";
            }
            static /*string */ FormatUnsupportedTaskResultType(/*object*/ arg1)
            {
                return $.$spc.System.String.Format("Unsupported task result type {0}.", arg1);
            }
            static /*string */ get UriConstructorMissing()
            {
                return "Constructor on type 'System.Uri' not found. Please consider to protect it's constructor from trimming.";
            }
            static /*string */ get UriTypeMissing()
            {
                return "The type System.Uri could not be found. Please consider to protect the class and it's constructor from trimming.";
            }
            static /*string */ get ValueOutOf52BitRange()
            {
                return "Overflow: value {0} is out of {1} {2} range.";
            }
            static /*string */ FormatValueOutOf52BitRange(/*object*/ arg1, /*object*/ arg2, /*object*/ arg3)
            {
                return $.$spc.System.String.Format$2("Overflow: value {0} is out of {1} {2} range.", arg1, arg2, arg3);
            }
            /*bool*/ static s_usingResourceKeys = false;
            static /*bool */ GetUsingResourceKeysSwitchValue()
            {
                /*bool*/ let usingResourceKeys;
                return $.$spc.System.AppContext.TryGetSwitch("System.Resources.UseSystemResourceKeys", $.$ref(() => usingResourceKeys, ($v) => usingResourceKeys = $v, $.$spc.System.Boolean)) ? usingResourceKeys : false;
            }
            static /*bool */ UsingResourceKeys()
            {
                return $.$srij.System.SR.s_usingResourceKeys;
            }
            static /*string */ GetResourceString(/*string*/ resourceKey)
            {
                if ($.$srij.System.SR.UsingResourceKeys())
                {
                    return resourceKey;
                }
                /*string?*/ let resourceString = null;
                try
                {
                    resourceString = $.$srij.System.SR.ResourceManager.GetString(resourceKey);
                }
                catch($e)
                {
                }
                return resourceString;
            }
            static /*string */ GetResourceString$1(/*string*/ resourceKey, /*string*/ defaultString)
            {
                /*string*/ let resourceString = $.$srij.System.SR.GetResourceString(resourceKey);
                return $.$spc.System.String.op_Equality(resourceKey, resourceString) || $.$spc.System.String.op_Equality(resourceString, null) ? defaultString : resourceString;
            }
            static /*string */ Format(/*string*/ resourceFormat, /*object?*/ p1)
            {
                if ($.$srij.System.SR.UsingResourceKeys())
                {
                    return $.$spc.System.String.Join$10(", ", $.$spc.System.ReadOnlySpan$$($.$spc.System.Object).op_Implicit([ resourceFormat, p1 ]));
                }
                return $.$spc.System.String.Format(resourceFormat, p1);
            }
            static /*string */ Format$1(/*string*/ resourceFormat, /*object?*/ p1, /*object?*/ p2)
            {
                if ($.$srij.System.SR.UsingResourceKeys())
                {
                    return $.$spc.System.String.Join$10(", ", $.$spc.System.ReadOnlySpan$$($.$spc.System.Object).op_Implicit([ resourceFormat, p1, p2 ]));
                }
                return $.$spc.System.String.Format$1(resourceFormat, p1, p2);
            }
            static /*string */ Format$2(/*string*/ resourceFormat, /*object?*/ p1, /*object?*/ p2, /*object?*/ p3)
            {
                if ($.$srij.System.SR.UsingResourceKeys())
                {
                    return $.$spc.System.String.Join$10(", ", $.$spc.System.ReadOnlySpan$$($.$spc.System.Object).op_Implicit([ resourceFormat, p1, p2, p3 ]));
                }
                return $.$spc.System.String.Format$2(resourceFormat, p1, p2, p3);
            }
            static /*string */ Format$3(/*string*/ resourceFormat, /*params object?[]?*/ args)
            {
                if (args !== null)
                {
                    if ($.$srij.System.SR.UsingResourceKeys())
                    {
                        return resourceFormat + ", " + $.$spc.System.String.Join$9(", ", args);
                    }
                    return $.$spc.System.String.Format$3(resourceFormat, args);
                }
                return resourceFormat;
            }
            static /*string */ Format$4(/*IFormatProvider?*/ provider, /*string*/ resourceFormat, /*object?*/ p1)
            {
                if ($.$srij.System.SR.UsingResourceKeys())
                {
                    return $.$spc.System.String.Join$10(", ", $.$spc.System.ReadOnlySpan$$($.$spc.System.Object).op_Implicit([ resourceFormat, p1 ]));
                }
                return $.$spc.System.String.Format$5(provider, resourceFormat, p1);
            }
            static /*string */ Format$5(/*IFormatProvider?*/ provider, /*string*/ resourceFormat, /*object?*/ p1, /*object?*/ p2)
            {
                if ($.$srij.System.SR.UsingResourceKeys())
                {
                    return $.$spc.System.String.Join$10(", ", $.$spc.System.ReadOnlySpan$$($.$spc.System.Object).op_Implicit([ resourceFormat, p1, p2 ]));
                }
                return $.$spc.System.String.Format$6(provider, resourceFormat, p1, p2);
            }
            static /*string */ Format$6(/*IFormatProvider?*/ provider, /*string*/ resourceFormat, /*object?*/ p1, /*object?*/ p2, /*object?*/ p3)
            {
                if ($.$srij.System.SR.UsingResourceKeys())
                {
                    return $.$spc.System.String.Join$10(", ", $.$spc.System.ReadOnlySpan$$($.$spc.System.Object).op_Implicit([ resourceFormat, p1, p2, p3 ]));
                }
                return $.$spc.System.String.Format$7(provider, resourceFormat, p1, p2, p3);
            }
            static /*string */ Format$7(/*IFormatProvider?*/ provider, /*string*/ resourceFormat, /*params object?[]?*/ args)
            {
                if (args !== null)
                {
                    if ($.$srij.System.SR.UsingResourceKeys())
                    {
                        return resourceFormat + ", " + $.$spc.System.String.Join$9(", ", args);
                    }
                    return $.$spc.System.String.Format$8(provider, resourceFormat, args);
                }
                return resourceFormat;
            }
            //Static Initializer
            static $sinit()
            {
                {
                    this.s_usingResourceKeys = $.$srij.System.SR.GetUsingResourceKeysSwitchValue();
                }
            }
            static $h = 3775229;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"h":3775229}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.SR`; }
        });
        
        $asm.$cls("$srij.System.Runtime.InteropServices.JavaScript.JSHost", ($self) => class JSHost
        {
            static /*JSObject */ get GlobalThis()
            {
                return INTERNAL.get_global_this();
            }
            static /*JSObject */ get DotnetInstance()
            {
                return INTERNAL.get_dotnet_instance();
            }
            static /*Task<JSObject> */ ImportAsync(/*string*/ moduleName, /*string*/ moduleUrl, /*CancellationToken*/ cancellationToken)
            {
                return $.$srij.System.Runtime.InteropServices.JavaScript.JSHostImplementation.ImportAsync(moduleName, moduleUrl, cancellationToken);
            }
            static $h = 760573;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":2267901,"g":{"r":0,"d":0,"h":8590695165,"f":33},"n":"GlobalThis","d":760573,"h":4295727869,"f":33},{"p":2267901,"g":{"r":0,"d":0,"h":17180629757,"f":33},"n":"DotnetInstance","d":760573,"h":12885662461,"f":33}],"m":[{"r":$.$spc.System.Threading.Tasks.Task$$($.$srij.System.Runtime.InteropServices.JavaScript.JSObject).$h,"p":[{"n":"moduleName","p":1310721},{"n":"moduleUrl","p":1310721},{"n":"cancellationToken","p":125960193,"f":65}],"n":"ImportAsync","d":760573,"h":21475597053,"f":33}],"h":760573,"a":[{"t":114950145,"c":4409917441,"a":[{"v":"browser","t":1310721}]}]}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.Runtime.InteropServices.JavaScript.JSHost`; }
        });
        
        $asm.$cls("$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType", ($self) => class JSMarshalerType extends $.$spc.System.Object
        {
            /*JSFunctionBinding.JSBindingType*/ _signatureType;
            $ctor$1()
            {
                super.$ctor();
                {
                    this._signatureType = $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType.Void._signatureType;
                }
                return this;
            }
            $ctor$2(/*JSFunctionBinding.JSBindingType*/ signatureType)
            {
                super.$ctor();
                {
                    this._signatureType = signatureType.Clone();
                }
                return this;
            }
            /*JSMarshalerType*/ static Void = null;
            /*JSMarshalerType*/ static Discard = null;
            /*JSMarshalerType*/ static DiscardNoWait = null;
            /*JSMarshalerType*/ static Boolean = null;
            /*JSMarshalerType*/ static Byte = null;
            /*JSMarshalerType*/ static Char = null;
            /*JSMarshalerType*/ static Int16 = null;
            /*JSMarshalerType*/ static Int32 = null;
            /*JSMarshalerType*/ static Int52 = null;
            /*JSMarshalerType*/ static BigInt64 = null;
            /*JSMarshalerType*/ static Double = null;
            /*JSMarshalerType*/ static Single = null;
            /*JSMarshalerType*/ static IntPtr = null;
            /*JSMarshalerType*/ static JSObject = null;
            /*JSMarshalerType*/ static Object = null;
            /*JSMarshalerType*/ static String = null;
            /*JSMarshalerType*/ static Exception = null;
            /*JSMarshalerType*/ static DateTime = null;
            /*JSMarshalerType*/ static DateTimeOffset = null;
            static /*JSMarshalerType */ Nullable(/*JSMarshalerType*/ primitive)
            {
                $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType.CheckNullable(primitive);
                return new $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType().$ctor$2((() =>
                {
                    //new $.$srij.System.Runtime.InteropServices.JavaScript.JSFunctionBinding.JSBindingType()
                    const $t1 = $.$srij.System.Runtime.InteropServices.JavaScript.JSFunctionBinding.JSBindingType;
                    const $i1 = new $t1();
                    $i1.Type = 19/*MarshalerType.Nullable*/;
                    $i1.ResultMarshalerType = primitive._signatureType.Type;
                    return $i1;
                })());
            }
            /*JSMarshalerType*/ static _task = null;
            static /*JSMarshalerType */ Task()
            {
                return $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType._task;
            }
            static /*JSMarshalerType */ Task$1(/*JSMarshalerType*/ result)
            {
                $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType.CheckTask(result);
                return new $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType().$ctor$2((() =>
                {
                    //new $.$srij.System.Runtime.InteropServices.JavaScript.JSFunctionBinding.JSBindingType()
                    const $t1 = $.$srij.System.Runtime.InteropServices.JavaScript.JSFunctionBinding.JSBindingType;
                    const $i1 = new $t1();
                    $i1.Type = 20/*MarshalerType.Task*/;
                    $i1.ResultMarshalerType = result._signatureType.Type;
                    return $i1;
                })());
            }
            static /*JSMarshalerType */ Array(/*JSMarshalerType*/ element)
            {
                $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType.CheckArray(element);
                return new $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType().$ctor$2((() =>
                {
                    //new $.$srij.System.Runtime.InteropServices.JavaScript.JSFunctionBinding.JSBindingType()
                    const $t1 = $.$srij.System.Runtime.InteropServices.JavaScript.JSFunctionBinding.JSBindingType;
                    const $i1 = new $t1();
                    $i1.Type = 21/*MarshalerType.Array*/;
                    $i1.Arg1MarshalerType = element._signatureType.Type;
                    return $i1;
                })());
            }
            static /*JSMarshalerType */ ArraySegment(/*JSMarshalerType*/ element)
            {
                $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType.CheckArraySegment(element);
                return new $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType().$ctor$2((() =>
                {
                    //new $.$srij.System.Runtime.InteropServices.JavaScript.JSFunctionBinding.JSBindingType()
                    const $t1 = $.$srij.System.Runtime.InteropServices.JavaScript.JSFunctionBinding.JSBindingType;
                    const $i1 = new $t1();
                    $i1.Type = 22/*MarshalerType.ArraySegment*/;
                    $i1.Arg1MarshalerType = element._signatureType.Type;
                    return $i1;
                })());
            }
            static /*JSMarshalerType */ Span(/*JSMarshalerType*/ element)
            {
                $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType.CheckArraySegment(element);
                return new $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType().$ctor$2((() =>
                {
                    //new $.$srij.System.Runtime.InteropServices.JavaScript.JSFunctionBinding.JSBindingType()
                    const $t1 = $.$srij.System.Runtime.InteropServices.JavaScript.JSFunctionBinding.JSBindingType;
                    const $i1 = new $t1();
                    $i1.Type = 23/*MarshalerType.Span*/;
                    $i1.Arg1MarshalerType = element._signatureType.Type;
                    return $i1;
                })());
            }
            /*JSMarshalerType*/ static _action = null;
            static /*JSMarshalerType */ Action()
            {
                return $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType._action;
            }
            static /*JSMarshalerType */ Action$1(/*JSMarshalerType*/ arg1)
            {
                $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType.CheckTask(arg1);
                return new $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType().$ctor$2((() =>
                {
                    //new $.$srij.System.Runtime.InteropServices.JavaScript.JSFunctionBinding.JSBindingType()
                    const $t1 = $.$srij.System.Runtime.InteropServices.JavaScript.JSFunctionBinding.JSBindingType;
                    const $i1 = new $t1();
                    $i1.Type = 24/*MarshalerType.Action*/;
                    $i1.Arg1MarshalerType = arg1._signatureType.Type;
                    return $i1;
                })());
            }
            static /*JSMarshalerType */ Action$2(/*JSMarshalerType*/ arg1, /*JSMarshalerType*/ arg2)
            {
                $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType.CheckTask(arg1);
                $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType.CheckTask(arg2);
                return new $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType().$ctor$2((() =>
                {
                    //new $.$srij.System.Runtime.InteropServices.JavaScript.JSFunctionBinding.JSBindingType()
                    const $t1 = $.$srij.System.Runtime.InteropServices.JavaScript.JSFunctionBinding.JSBindingType;
                    const $i1 = new $t1();
                    $i1.Type = 24/*MarshalerType.Action*/;
                    $i1.Arg1MarshalerType = arg1._signatureType.Type;
                    $i1.Arg2MarshalerType = arg2._signatureType.Type;
                    return $i1;
                })());
            }
            static /*JSMarshalerType */ Action$3(/*JSMarshalerType*/ arg1, /*JSMarshalerType*/ arg2, /*JSMarshalerType*/ arg3)
            {
                $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType.CheckTask(arg1);
                $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType.CheckTask(arg2);
                $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType.CheckTask(arg3);
                return new $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType().$ctor$2((() =>
                {
                    //new $.$srij.System.Runtime.InteropServices.JavaScript.JSFunctionBinding.JSBindingType()
                    const $t1 = $.$srij.System.Runtime.InteropServices.JavaScript.JSFunctionBinding.JSBindingType;
                    const $i1 = new $t1();
                    $i1.Type = 24/*MarshalerType.Action*/;
                    $i1.Arg1MarshalerType = arg1._signatureType.Type;
                    $i1.Arg2MarshalerType = arg2._signatureType.Type;
                    $i1.Arg3MarshalerType = arg3._signatureType.Type;
                    return $i1;
                })());
            }
            static /*JSMarshalerType */ Function(/*JSMarshalerType*/ result)
            {
                $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType.CheckTask(result);
                return new $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType().$ctor$2((() =>
                {
                    //new $.$srij.System.Runtime.InteropServices.JavaScript.JSFunctionBinding.JSBindingType()
                    const $t1 = $.$srij.System.Runtime.InteropServices.JavaScript.JSFunctionBinding.JSBindingType;
                    const $i1 = new $t1();
                    $i1.Type = 25/*MarshalerType.Function*/;
                    $i1.ResultMarshalerType = result._signatureType.Type;
                    return $i1;
                })());
            }
            static /*JSMarshalerType */ Function$1(/*JSMarshalerType*/ arg1, /*JSMarshalerType*/ result)
            {
                $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType.CheckTask(arg1);
                $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType.CheckTask(result);
                return new $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType().$ctor$2((() =>
                {
                    //new $.$srij.System.Runtime.InteropServices.JavaScript.JSFunctionBinding.JSBindingType()
                    const $t1 = $.$srij.System.Runtime.InteropServices.JavaScript.JSFunctionBinding.JSBindingType;
                    const $i1 = new $t1();
                    $i1.Type = 25/*MarshalerType.Function*/;
                    $i1.Arg1MarshalerType = arg1._signatureType.Type;
                    $i1.ResultMarshalerType = result._signatureType.Type;
                    return $i1;
                })());
            }
            static /*JSMarshalerType */ Function$2(/*JSMarshalerType*/ arg1, /*JSMarshalerType*/ arg2, /*JSMarshalerType*/ result)
            {
                $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType.CheckTask(arg1);
                $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType.CheckTask(arg2);
                $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType.CheckTask(result);
                return new $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType().$ctor$2((() =>
                {
                    //new $.$srij.System.Runtime.InteropServices.JavaScript.JSFunctionBinding.JSBindingType()
                    const $t1 = $.$srij.System.Runtime.InteropServices.JavaScript.JSFunctionBinding.JSBindingType;
                    const $i1 = new $t1();
                    $i1.Type = 25/*MarshalerType.Function*/;
                    $i1.Arg1MarshalerType = arg1._signatureType.Type;
                    $i1.Arg2MarshalerType = arg2._signatureType.Type;
                    $i1.ResultMarshalerType = result._signatureType.Type;
                    return $i1;
                })());
            }
            static /*JSMarshalerType */ Function$3(/*JSMarshalerType*/ arg1, /*JSMarshalerType*/ arg2, /*JSMarshalerType*/ arg3, /*JSMarshalerType*/ result)
            {
                $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType.CheckTask(arg1);
                $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType.CheckTask(arg2);
                $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType.CheckTask(arg3);
                $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType.CheckTask(result);
                return new $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType().$ctor$2((() =>
                {
                    //new $.$srij.System.Runtime.InteropServices.JavaScript.JSFunctionBinding.JSBindingType()
                    const $t1 = $.$srij.System.Runtime.InteropServices.JavaScript.JSFunctionBinding.JSBindingType;
                    const $i1 = new $t1();
                    $i1.Type = 25/*MarshalerType.Function*/;
                    $i1.Arg1MarshalerType = arg1._signatureType.Type;
                    $i1.Arg2MarshalerType = arg2._signatureType.Type;
                    $i1.Arg3MarshalerType = arg3._signatureType.Type;
                    $i1.ResultMarshalerType = result._signatureType.Type;
                    return $i1;
                })());
            }
            static /*void */ CheckNullable(/*JSMarshalerType*/ underlyingType)
            {
                /*MarshalerType*/ let underlying = underlyingType._signatureType.Type;
                if (underlying === 3/*MarshalerType.Boolean*/ || underlying === 4/*MarshalerType.Byte*/ || underlying === 6/*MarshalerType.Int16*/ || underlying === 7/*MarshalerType.Int32*/ || underlying === 9/*MarshalerType.BigInt64*/ || underlying === 8/*MarshalerType.Int52*/ || underlying === 12/*MarshalerType.IntPtr*/ || underlying === 10/*MarshalerType.Double*/ || underlying === 11/*MarshalerType.Single*/ || underlying === 5/*MarshalerType.Char*/ || underlying === 17/*MarshalerType.DateTime*/ || underlying === 18/*MarshalerType.DateTimeOffset*/)
                {
                    return;
                }
                throw new $.$spc.System.ArgumentException().$ctor$13($.$srij.System.SR.Format($.$srij.System.SR.UnsupportedNullableType, $.$box(underlying, $.$srij.System.Runtime.InteropServices.JavaScript.MarshalerType)), "underlyingType");
            }
            static /*void */ CheckArray(/*JSMarshalerType*/ underlyingType)
            {
                /*MarshalerType*/ let underlying = underlyingType._signatureType.Type;
                if (underlying === 4/*MarshalerType.Byte*/ || underlying === 7/*MarshalerType.Int32*/ || underlying === 10/*MarshalerType.Double*/ || underlying === 15/*MarshalerType.String*/ || underlying === 14/*MarshalerType.Object*/ || underlying === 13/*MarshalerType.JSObject*/)
                {
                    return;
                }
                throw new $.$spc.System.ArgumentException().$ctor$13($.$srij.System.SR.Format($.$srij.System.SR.UnsupportedElementType, $.$box(underlying, $.$srij.System.Runtime.InteropServices.JavaScript.MarshalerType)), "underlyingType");
            }
            static /*void */ CheckArraySegment(/*JSMarshalerType*/ underlyingType)
            {
                /*MarshalerType*/ let underlying = underlyingType._signatureType.Type;
                if (underlying === 4/*MarshalerType.Byte*/ || underlying === 7/*MarshalerType.Int32*/ || underlying === 10/*MarshalerType.Double*/)
                {
                    return;
                }
                throw new $.$spc.System.ArgumentException().$ctor$13($.$srij.System.SR.Format($.$srij.System.SR.UnsupportedElementType, $.$box(underlying, $.$srij.System.Runtime.InteropServices.JavaScript.MarshalerType)), "underlyingType");
            }
            static /*void */ CheckTask(/*JSMarshalerType*/ underlyingType)
            {
                /*MarshalerType*/ let underlying = underlyingType._signatureType.Type;
                if (underlying === 21/*MarshalerType.Array*/ || underlying === 22/*MarshalerType.ArraySegment*/ || underlying === 23/*MarshalerType.Span*/ || underlying === 20/*MarshalerType.Task*/ || underlying === 24/*MarshalerType.Action*/ || underlying === 25/*MarshalerType.Function*/)
                {
                    throw new $.$spc.System.ArgumentException().$ctor$13($.$srij.System.SR.Format($.$srij.System.SR.UnsupportedTaskResultType, $.$box(underlying, $.$srij.System.Runtime.InteropServices.JavaScript.MarshalerType)), "underlyingType");
                }
            }
            //default member initializer
            constructor()
            {
                super();
                this._signatureType = $.$default($.$srij.System.Runtime.InteropServices.JavaScript.JSFunctionBinding.JSBindingType);
            }
            //Static Initializer
            static $sinit()
            {
                {
                    this.Void = new $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType().$ctor$2((() =>
                    {
                        //new $.$srij.System.Runtime.InteropServices.JavaScript.JSFunctionBinding.JSBindingType()
                        const $t1 = $.$srij.System.Runtime.InteropServices.JavaScript.JSFunctionBinding.JSBindingType;
                        const $i1 = new $t1();
                        $i1.Type = 1/*MarshalerType.Void*/;
                        return $i1;
                    })());
                }
                {
                    this.Discard = new $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType().$ctor$2((() =>
                    {
                        //new $.$srij.System.Runtime.InteropServices.JavaScript.JSFunctionBinding.JSBindingType()
                        const $t1 = $.$srij.System.Runtime.InteropServices.JavaScript.JSFunctionBinding.JSBindingType;
                        const $i1 = new $t1();
                        $i1.Type = 2/*MarshalerType.Discard*/;
                        return $i1;
                    })());
                }
                {
                    this.DiscardNoWait = new $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType().$ctor$2((() =>
                    {
                        //new $.$srij.System.Runtime.InteropServices.JavaScript.JSFunctionBinding.JSBindingType()
                        const $t1 = $.$srij.System.Runtime.InteropServices.JavaScript.JSFunctionBinding.JSBindingType;
                        const $i1 = new $t1();
                        $i1.Type = 26/*MarshalerType.DiscardNoWait*/;
                        return $i1;
                    })());
                }
                {
                    this.Boolean = new $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType().$ctor$2((() =>
                    {
                        //new $.$srij.System.Runtime.InteropServices.JavaScript.JSFunctionBinding.JSBindingType()
                        const $t1 = $.$srij.System.Runtime.InteropServices.JavaScript.JSFunctionBinding.JSBindingType;
                        const $i1 = new $t1();
                        $i1.Type = 3/*MarshalerType.Boolean*/;
                        return $i1;
                    })());
                }
                {
                    this.Byte = new $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType().$ctor$2((() =>
                    {
                        //new $.$srij.System.Runtime.InteropServices.JavaScript.JSFunctionBinding.JSBindingType()
                        const $t1 = $.$srij.System.Runtime.InteropServices.JavaScript.JSFunctionBinding.JSBindingType;
                        const $i1 = new $t1();
                        $i1.Type = 4/*MarshalerType.Byte*/;
                        return $i1;
                    })());
                }
                {
                    this.Char = new $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType().$ctor$2((() =>
                    {
                        //new $.$srij.System.Runtime.InteropServices.JavaScript.JSFunctionBinding.JSBindingType()
                        const $t1 = $.$srij.System.Runtime.InteropServices.JavaScript.JSFunctionBinding.JSBindingType;
                        const $i1 = new $t1();
                        $i1.Type = 5/*MarshalerType.Char*/;
                        return $i1;
                    })());
                }
                {
                    this.Int16 = new $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType().$ctor$2((() =>
                    {
                        //new $.$srij.System.Runtime.InteropServices.JavaScript.JSFunctionBinding.JSBindingType()
                        const $t1 = $.$srij.System.Runtime.InteropServices.JavaScript.JSFunctionBinding.JSBindingType;
                        const $i1 = new $t1();
                        $i1.Type = 6/*MarshalerType.Int16*/;
                        return $i1;
                    })());
                }
                {
                    this.Int32 = new $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType().$ctor$2((() =>
                    {
                        //new $.$srij.System.Runtime.InteropServices.JavaScript.JSFunctionBinding.JSBindingType()
                        const $t1 = $.$srij.System.Runtime.InteropServices.JavaScript.JSFunctionBinding.JSBindingType;
                        const $i1 = new $t1();
                        $i1.Type = 7/*MarshalerType.Int32*/;
                        return $i1;
                    })());
                }
                {
                    this.Int52 = new $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType().$ctor$2((() =>
                    {
                        //new $.$srij.System.Runtime.InteropServices.JavaScript.JSFunctionBinding.JSBindingType()
                        const $t1 = $.$srij.System.Runtime.InteropServices.JavaScript.JSFunctionBinding.JSBindingType;
                        const $i1 = new $t1();
                        $i1.Type = 8/*MarshalerType.Int52*/;
                        return $i1;
                    })());
                }
                {
                    this.BigInt64 = new $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType().$ctor$2((() =>
                    {
                        //new $.$srij.System.Runtime.InteropServices.JavaScript.JSFunctionBinding.JSBindingType()
                        const $t1 = $.$srij.System.Runtime.InteropServices.JavaScript.JSFunctionBinding.JSBindingType;
                        const $i1 = new $t1();
                        $i1.Type = 9/*MarshalerType.BigInt64*/;
                        return $i1;
                    })());
                }
                {
                    this.Double = new $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType().$ctor$2((() =>
                    {
                        //new $.$srij.System.Runtime.InteropServices.JavaScript.JSFunctionBinding.JSBindingType()
                        const $t1 = $.$srij.System.Runtime.InteropServices.JavaScript.JSFunctionBinding.JSBindingType;
                        const $i1 = new $t1();
                        $i1.Type = 10/*MarshalerType.Double*/;
                        return $i1;
                    })());
                }
                {
                    this.Single = new $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType().$ctor$2((() =>
                    {
                        //new $.$srij.System.Runtime.InteropServices.JavaScript.JSFunctionBinding.JSBindingType()
                        const $t1 = $.$srij.System.Runtime.InteropServices.JavaScript.JSFunctionBinding.JSBindingType;
                        const $i1 = new $t1();
                        $i1.Type = 11/*MarshalerType.Single*/;
                        return $i1;
                    })());
                }
                {
                    this.IntPtr = new $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType().$ctor$2((() =>
                    {
                        //new $.$srij.System.Runtime.InteropServices.JavaScript.JSFunctionBinding.JSBindingType()
                        const $t1 = $.$srij.System.Runtime.InteropServices.JavaScript.JSFunctionBinding.JSBindingType;
                        const $i1 = new $t1();
                        $i1.Type = 12/*MarshalerType.IntPtr*/;
                        return $i1;
                    })());
                }
                {
                    this.JSObject = new $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType().$ctor$2((() =>
                    {
                        //new $.$srij.System.Runtime.InteropServices.JavaScript.JSFunctionBinding.JSBindingType()
                        const $t1 = $.$srij.System.Runtime.InteropServices.JavaScript.JSFunctionBinding.JSBindingType;
                        const $i1 = new $t1();
                        $i1.Type = 13/*MarshalerType.JSObject*/;
                        return $i1;
                    })());
                }
                {
                    this.Object = new $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType().$ctor$2((() =>
                    {
                        //new $.$srij.System.Runtime.InteropServices.JavaScript.JSFunctionBinding.JSBindingType()
                        const $t1 = $.$srij.System.Runtime.InteropServices.JavaScript.JSFunctionBinding.JSBindingType;
                        const $i1 = new $t1();
                        $i1.Type = 14/*MarshalerType.Object*/;
                        return $i1;
                    })());
                }
                {
                    this.String = new $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType().$ctor$2((() =>
                    {
                        //new $.$srij.System.Runtime.InteropServices.JavaScript.JSFunctionBinding.JSBindingType()
                        const $t1 = $.$srij.System.Runtime.InteropServices.JavaScript.JSFunctionBinding.JSBindingType;
                        const $i1 = new $t1();
                        $i1.Type = 15/*MarshalerType.String*/;
                        return $i1;
                    })());
                }
                {
                    this.Exception = new $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType().$ctor$2((() =>
                    {
                        //new $.$srij.System.Runtime.InteropServices.JavaScript.JSFunctionBinding.JSBindingType()
                        const $t1 = $.$srij.System.Runtime.InteropServices.JavaScript.JSFunctionBinding.JSBindingType;
                        const $i1 = new $t1();
                        $i1.Type = 16/*MarshalerType.Exception*/;
                        return $i1;
                    })());
                }
                {
                    this.DateTime = new $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType().$ctor$2((() =>
                    {
                        //new $.$srij.System.Runtime.InteropServices.JavaScript.JSFunctionBinding.JSBindingType()
                        const $t1 = $.$srij.System.Runtime.InteropServices.JavaScript.JSFunctionBinding.JSBindingType;
                        const $i1 = new $t1();
                        $i1.Type = 17/*MarshalerType.DateTime*/;
                        return $i1;
                    })());
                }
                {
                    this.DateTimeOffset = new $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType().$ctor$2((() =>
                    {
                        //new $.$srij.System.Runtime.InteropServices.JavaScript.JSFunctionBinding.JSBindingType()
                        const $t1 = $.$srij.System.Runtime.InteropServices.JavaScript.JSFunctionBinding.JSBindingType;
                        const $i1 = new $t1();
                        $i1.Type = 18/*MarshalerType.DateTimeOffset*/;
                        return $i1;
                    })());
                }
                {
                    this._task = new $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType().$ctor$2((() =>
                    {
                        //new $.$srij.System.Runtime.InteropServices.JavaScript.JSFunctionBinding.JSBindingType()
                        const $t1 = $.$srij.System.Runtime.InteropServices.JavaScript.JSFunctionBinding.JSBindingType;
                        const $i1 = new $t1();
                        $i1.Type = 20/*MarshalerType.Task*/;
                        return $i1;
                    })());
                }
                {
                    this._action = new $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType().$ctor$2((() =>
                    {
                        //new $.$srij.System.Runtime.InteropServices.JavaScript.JSFunctionBinding.JSBindingType()
                        const $t1 = $.$srij.System.Runtime.InteropServices.JavaScript.JSFunctionBinding.JSBindingType;
                        const $i1 = new $t1();
                        $i1.Type = 24/*MarshalerType.Action*/;
                        return $i1;
                    })());
                }
            }
            static $h = 2202365;
            static $f = 0b10010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":2202365,"g":{"r":0,"d":0,"h":25772006141,"f":33},"n":"Void","d":2202365,"h":21477038845,"f":33},{"p":2202365,"g":{"r":0,"d":0,"h":38656908029,"f":33},"n":"Discard","d":2202365,"h":34361940733,"f":33},{"p":2202365,"g":{"r":0,"d":0,"h":51541809917,"f":33},"n":"DiscardNoWait","d":2202365,"h":47246842621,"f":33},{"p":2202365,"g":{"r":0,"d":0,"h":64426711805,"f":33},"n":"Boolean","d":2202365,"h":60131744509,"f":33},{"p":2202365,"g":{"r":0,"d":0,"h":77311613693,"f":33},"n":"Byte","d":2202365,"h":73016646397,"f":33},{"p":2202365,"g":{"r":0,"d":0,"h":90196515581,"f":33},"n":"Char","d":2202365,"h":85901548285,"f":33},{"p":2202365,"g":{"r":0,"d":0,"h":103081417469,"f":33},"n":"Int16","d":2202365,"h":98786450173,"f":33},{"p":2202365,"g":{"r":0,"d":0,"h":115966319357,"f":33},"n":"Int32","d":2202365,"h":111671352061,"f":33},{"p":2202365,"g":{"r":0,"d":0,"h":128851221245,"f":33},"n":"Int52","d":2202365,"h":124556253949,"f":33},{"p":2202365,"g":{"r":0,"d":0,"h":141736123133,"f":33},"n":"BigInt64","d":2202365,"h":137441155837,"f":33},{"p":2202365,"g":{"r":0,"d":0,"h":154621025021,"f":33},"n":"Double","d":2202365,"h":150326057725,"f":33},{"p":2202365,"g":{"r":0,"d":0,"h":167505926909,"f":33},"n":"Single","d":2202365,"h":163210959613,"f":33},{"p":2202365,"g":{"r":0,"d":0,"h":180390828797,"f":33},"n":"IntPtr","d":2202365,"h":176095861501,"f":33},{"p":2202365,"g":{"r":0,"d":0,"h":193275730685,"f":33},"n":"JSObject","d":2202365,"h":188980763389,"f":33},{"p":2202365,"g":{"r":0,"d":0,"h":206160632573,"f":33},"n":"Object","d":2202365,"h":201865665277,"f":33},{"p":2202365,"g":{"r":0,"d":0,"h":219045534461,"f":33},"n":"String","d":2202365,"h":214750567165,"f":33},{"p":2202365,"g":{"r":0,"d":0,"h":244815338237,"f":33},"n":"DateTime","d":2202365,"h":240520370941,"f":33},{"p":2202365,"g":{"r":0,"d":0,"h":257700240125,"f":33},"n":"DateTimeOffset","d":2202365,"h":253405272829,"f":33},{"p":2202365,"g":{"r":0,"d":0,"h":274880109309,"f":34},"n":"_task","d":2202365,"h":270585142013,"f":34},{"p":2202365,"g":{"r":0,"d":0,"h":309239847677,"f":34},"n":"_action","d":2202365,"h":304944880381,"f":34}],"m":[{"r":2202365,"p":[{"n":"primitive","p":2202365}],"n":"Nullable","d":2202365,"h":261995207421,"f":33},{"r":2202365,"n":"Task","d":2202365,"h":279175076605,"f":33},{"r":2202365,"p":[{"n":"result","p":2202365}],"n":"Task","o":"@$1","d":2202365,"h":283470043901,"f":33},{"r":2202365,"p":[{"n":"element","p":2202365}],"n":"Array","d":2202365,"h":287765011197,"f":33},{"r":2202365,"p":[{"n":"element","p":2202365}],"n":"ArraySegment","d":2202365,"h":292059978493,"f":33},{"r":2202365,"p":[{"n":"element","p":2202365}],"n":"Span","d":2202365,"h":296354945789,"f":33},{"r":2202365,"n":"Action","d":2202365,"h":313534814973,"f":33},{"r":2202365,"p":[{"n":"arg1","p":2202365}],"n":"Action","o":"@$1","d":2202365,"h":317829782269,"f":33},{"r":2202365,"p":[{"n":"arg1","p":2202365},{"n":"arg2","p":2202365}],"n":"Action","o":"@$2","d":2202365,"h":322124749565,"f":33},{"r":2202365,"p":[{"n":"arg1","p":2202365},{"n":"arg2","p":2202365},{"n":"arg3","p":2202365}],"n":"Action","o":"@$3","d":2202365,"h":326419716861,"f":33},{"r":2202365,"p":[{"n":"result","p":2202365}],"n":"Function","d":2202365,"h":330714684157,"f":33},{"r":2202365,"p":[{"n":"arg1","p":2202365},{"n":"result","p":2202365}],"n":"Function","o":"@$1","d":2202365,"h":335009651453,"f":33},{"r":2202365,"p":[{"n":"arg1","p":2202365},{"n":"arg2","p":2202365},{"n":"result","p":2202365}],"n":"Function","o":"@$2","d":2202365,"h":339304618749,"f":33},{"r":2202365,"p":[{"n":"arg1","p":2202365},{"n":"arg2","p":2202365},{"n":"arg3","p":2202365},{"n":"result","p":2202365}],"n":"Function","o":"@$3","d":2202365,"h":343599586045,"f":33},{"r":65537,"p":[{"n":"underlyingType","p":2202365}],"n":"CheckNullable","d":2202365,"h":347894553341,"f":40},{"r":65537,"p":[{"n":"underlyingType","p":2202365}],"n":"CheckArray","d":2202365,"h":352189520637,"f":40},{"r":65537,"p":[{"n":"underlyingType","p":2202365}],"n":"CheckArraySegment","d":2202365,"h":356484487933,"f":40},{"r":65537,"p":[{"n":"underlyingType","p":2202365}],"n":"CheckTask","d":2202365,"h":360779455229,"f":40}],"l":[{"t":695037,"n":"_signatureType","d":2202365,"h":4297169661,"f":8}],"c":[{"n":".ctor","o":"$ctor$1","d":2202365,"h":8592136957,"f":2},{"p":[{"n":"signatureType","p":695037}],"n":".ctor","o":"$ctor$2","d":2202365,"h":12887104253,"f":2}],"h":2202365,"a":[{"t":114950145,"c":4409917441,"a":[{"v":"browser","t":1310721}]},{"t":33161217,"c":4328128513,"a":[{"v":1,"t":33226753}]}]}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.Runtime.InteropServices.JavaScript.JSMarshalerType`; }
        });
        
        $asm.$cls("$srij.System.Runtime.InteropServices.JavaScript.JSFunctionBinding", ($self) => class JSFunctionBinding extends $.$spc.System.Object
        {
            $ctor$1()
            {
                super.$ctor();
                {
                }
                return this;
            }
            /*JSBindingHeader**/ Header;
            /*JSBindingType**/ Sigs;
            /*uint*/ static nextImportHandle = 1;
            /*int*/ ImportHandle = 0;
            /*bool*/ IsAsync = false;
            /*bool*/ IsDiscardNoWait = false;
            /*string?*/ FunctionName = null;
            static $_JSBindingHeader;
            static get JSBindingHeader()
            {
                let $cls = $.$srij.System.Runtime.InteropServices.JavaScript.JSFunctionBinding;
                return $cls.$_JSBindingHeader ??= $asm.$nstr("$srij.System.Runtime.InteropServices.JavaScript.JSFunctionBinding.JSBindingHeader", ($self) => class JSBindingHeader extends $.$spc.System.ValueType
                {
                    /*int*/ static JSMarshalerSignatureHeaderSize = 32;
                    /*int*/  get Version() { return this.$getField(0, $.$spc.System.Int32); }
                    /*int*/  set Version(value) { this.$setField(0, $.$spc.System.Int32, value); }
                    /*int*/  get ArgumentCount() { return this.$getField(4, $.$spc.System.Int32); }
                    /*int*/  set ArgumentCount(value) { this.$setField(4, $.$spc.System.Int32, value); }
                    /*int*/  get ImportHandle() { return this.$getField(8, $.$spc.System.Int32); }
                    /*int*/  set ImportHandle(value) { this.$setField(8, $.$spc.System.Int32, value); }
                    /*int*/  get FunctionNameOffset() { return this.$getField(16, $.$spc.System.Int32); }
                    /*int*/  set FunctionNameOffset(value) { this.$setField(16, $.$spc.System.Int32, value); }
                    /*int*/  get FunctionNameLength() { return this.$getField(20, $.$spc.System.Int32); }
                    /*int*/  set FunctionNameLength(value) { this.$setField(20, $.$spc.System.Int32, value); }
                    /*int*/  get ModuleNameOffset() { return this.$getField(24, $.$spc.System.Int32); }
                    /*int*/  set ModuleNameOffset(value) { this.$setField(24, $.$spc.System.Int32, value); }
                    /*int*/  get ModuleNameLength() { return this.$getField(28, $.$spc.System.Int32); }
                    /*int*/  set ModuleNameLength(value) { this.$setField(28, $.$spc.System.Int32, value); }
                    /*JSBindingType*/  get Exception() { return this.$getField(32, $.$srij.System.Runtime.InteropServices.JavaScript.JSFunctionBinding.JSBindingType); }
                    /*JSBindingType*/  set Exception(value) { this.$setField(32, $.$srij.System.Runtime.InteropServices.JavaScript.JSFunctionBinding.JSBindingType, value); }
                    /*JSBindingType*/  get Result() { return this.$getField(64, $.$srij.System.Runtime.InteropServices.JavaScript.JSFunctionBinding.JSBindingType); }
                    /*JSBindingType*/  set Result(value) { this.$setField(64, $.$srij.System.Runtime.InteropServices.JavaScript.JSFunctionBinding.JSBindingType, value); }
                    //default value type constructor
                    $ctor$2()
                    {
                        return this;
                    }
                    Clone($copy)
                    {
                        let copy = $copy ?? new this.constructor();
                        copy.Version = this.Version;
                        copy.ArgumentCount = this.ArgumentCount;
                        copy.ImportHandle = this.ImportHandle;
                        copy.FunctionNameOffset = this.FunctionNameOffset;
                        copy.FunctionNameLength = this.FunctionNameLength;
                        copy.ModuleNameOffset = this.ModuleNameOffset;
                        copy.ModuleNameLength = this.ModuleNameLength;
                        copy.Exception = this.Exception.Clone();
                        copy.Result = this.Result.Clone();
                        return copy;
                    }
                    //default member initializer
                    constructor()
                    {
                        super();
                        this.Version = 0;
                        this.ArgumentCount = 0;
                        this.ImportHandle = 0;
                        this.FunctionNameOffset = 0;
                        this.FunctionNameLength = 0;
                        this.ModuleNameOffset = 0;
                        this.ModuleNameLength = 0;
                        this.Exception = $.$default($.$srij.System.Runtime.InteropServices.JavaScript.JSFunctionBinding.JSBindingType);
                        this.Result = $.$default($.$srij.System.Runtime.InteropServices.JavaScript.JSFunctionBinding.JSBindingType);
                    }
                    //Static Initializer
                    static $sinit()
                    {
                        {
                            this.JSMarshalerSignatureHeaderSize = 32;
                        }
                    }
                    static $h = 629501;
                    static $z = 96;
                    static $f = 0b10100010000001010000000;
                    static $k = 2;
                    static $$md;
                    static get $md() { return this.$$md ??= {"b":196609,"l":[{"t":655361,"n":"JSMarshalerSignatureHeaderSize","d":629501,"h":4295596797,"f":40},{"t":655361,"n":"Version","d":629501,"h":8590564093,"f":1,"a":[{"t":104071169,"c":4399038465,"a":[{"v":0,"t":655361}]}]},{"t":655361,"n":"ArgumentCount","d":629501,"h":12885531389,"f":1,"a":[{"t":104071169,"c":4399038465,"a":[{"v":4,"t":655361}]}]},{"t":655361,"n":"ImportHandle","d":629501,"h":17180498685,"f":1,"a":[{"t":104071169,"c":4399038465,"a":[{"v":8,"t":655361}]}]},{"t":655361,"n":"FunctionNameOffset","d":629501,"h":21475465981,"f":1,"a":[{"t":104071169,"c":4399038465,"a":[{"v":16,"t":655361}]}]},{"t":655361,"n":"FunctionNameLength","d":629501,"h":25770433277,"f":1,"a":[{"t":104071169,"c":4399038465,"a":[{"v":20,"t":655361}]}]},{"t":655361,"n":"ModuleNameOffset","d":629501,"h":30065400573,"f":1,"a":[{"t":104071169,"c":4399038465,"a":[{"v":24,"t":655361}]}]},{"t":655361,"n":"ModuleNameLength","d":629501,"h":34360367869,"f":1,"a":[{"t":104071169,"c":4399038465,"a":[{"v":28,"t":655361}]}]},{"t":695037,"n":"Result","d":629501,"h":42950302461,"f":1,"a":[{"t":104071169,"c":4399038465,"a":[{"v":64,"t":655361}]}]}],"c":[{"n":".ctor","o":"$ctor$2","d":629501,"h":47245269757,"f":1}],"d":563965,"h":629501,"a":[{"t":109903873,"c":4404871169,"a":[{"v":2,"t":105381889}],"n":[{"n":"Pack","v":4,"t":655361}]}]}; }
                    static get $b() { return $.$spc.System.ValueType; }
                    static get $fullName() { return `System.Runtime.InteropServices.JavaScript.JSFunctionBinding.JSBindingHeader`; }
                }, $cls, ($v) => $cls.$_JSBindingHeader = $v);
            }
            static $_JSBindingType;
            static get JSBindingType()
            {
                let $cls = $.$srij.System.Runtime.InteropServices.JavaScript.JSFunctionBinding;
                return $cls.$_JSBindingType ??= $asm.$nstr("$srij.System.Runtime.InteropServices.JavaScript.JSFunctionBinding.JSBindingType", ($self) => class JSBindingType extends $.$spc.System.ValueType
                {
                    /*MarshalerType*/  get Type() { return this.$getField(0, $.$srij.System.Runtime.InteropServices.JavaScript.MarshalerType); }
                    /*MarshalerType*/  set Type(value) { this.$setField(0, $.$srij.System.Runtime.InteropServices.JavaScript.MarshalerType, value); }
                    /*MarshalerType*/  get ResultMarshalerType() { return this.$getField(16, $.$srij.System.Runtime.InteropServices.JavaScript.MarshalerType); }
                    /*MarshalerType*/  set ResultMarshalerType(value) { this.$setField(16, $.$srij.System.Runtime.InteropServices.JavaScript.MarshalerType, value); }
                    /*MarshalerType*/  get Arg1MarshalerType() { return this.$getField(20, $.$srij.System.Runtime.InteropServices.JavaScript.MarshalerType); }
                    /*MarshalerType*/  set Arg1MarshalerType(value) { this.$setField(20, $.$srij.System.Runtime.InteropServices.JavaScript.MarshalerType, value); }
                    /*MarshalerType*/  get Arg2MarshalerType() { return this.$getField(24, $.$srij.System.Runtime.InteropServices.JavaScript.MarshalerType); }
                    /*MarshalerType*/  set Arg2MarshalerType(value) { this.$setField(24, $.$srij.System.Runtime.InteropServices.JavaScript.MarshalerType, value); }
                    /*MarshalerType*/  get Arg3MarshalerType() { return this.$getField(28, $.$srij.System.Runtime.InteropServices.JavaScript.MarshalerType); }
                    /*MarshalerType*/  set Arg3MarshalerType(value) { this.$setField(28, $.$srij.System.Runtime.InteropServices.JavaScript.MarshalerType, value); }
                    //default value type constructor
                    $ctor$2()
                    {
                        return this;
                    }
                    Clone($copy)
                    {
                        let copy = $copy ?? new this.constructor();
                        copy.Type = this.Type;
                        copy.ResultMarshalerType = this.ResultMarshalerType;
                        copy.Arg1MarshalerType = this.Arg1MarshalerType;
                        copy.Arg2MarshalerType = this.Arg2MarshalerType;
                        copy.Arg3MarshalerType = this.Arg3MarshalerType;
                        return copy;
                    }
                    //default member initializer
                    constructor()
                    {
                        super();
                        this.Type = 0;
                        this.ResultMarshalerType = 0;
                        this.Arg1MarshalerType = 0;
                        this.Arg2MarshalerType = 0;
                        this.Arg3MarshalerType = 0;
                    }
                    static $h = 695037;
                    static $z = 32;
                    static $f = 0b10100010000001010000000;
                    static $k = 2;
                    static $$md;
                    static get $md() { return this.$$md ??= {"b":196609,"l":[{"t":3709693,"n":"Type","d":695037,"h":4295662333,"f":8,"a":[{"t":104071169,"c":4399038465,"a":[{"v":0,"t":655361}]}]},{"t":3709693,"n":"ResultMarshalerType","d":695037,"h":8590629629,"f":8,"a":[{"t":104071169,"c":4399038465,"a":[{"v":16,"t":655361}]}]},{"t":3709693,"n":"Arg1MarshalerType","d":695037,"h":12885596925,"f":8,"a":[{"t":104071169,"c":4399038465,"a":[{"v":20,"t":655361}]}]},{"t":3709693,"n":"Arg2MarshalerType","d":695037,"h":17180564221,"f":8,"a":[{"t":104071169,"c":4399038465,"a":[{"v":24,"t":655361}]}]},{"t":3709693,"n":"Arg3MarshalerType","d":695037,"h":21475531517,"f":8,"a":[{"t":104071169,"c":4399038465,"a":[{"v":28,"t":655361}]}]}],"c":[{"n":".ctor","o":"$ctor$2","d":695037,"h":25770498813,"f":1}],"d":563965,"h":695037,"a":[{"t":109903873,"c":4404871169,"a":[{"v":2,"t":105381889}],"n":[{"n":"Pack","v":4,"t":655361},{"n":"Size","v":32,"t":655361}]}]}; }
                    static get $b() { return $.$spc.System.ValueType; }
                    static get $fullName() { return `System.Runtime.InteropServices.JavaScript.JSFunctionBinding.JSBindingType`; }
                }, $cls, ($v) => $cls.$_JSBindingType = $v);
            }
            /*int */ get ArgumentCount()
            {
                return this.Header.GetAt(0).ArgumentCount;
            }
            /*int */ set ArgumentCount(value)
            {
                this.Header.GetAt(0).ArgumentCount = value;
            }
            /*int */ get Version()
            {
                return this.Header.GetAt(0).Version;
            }
            /*int */ set Version(value)
            {
                this.Header.GetAt(0).Version = value;
            }
            /*JSBindingType */ get Result()
            {
                return this.Header.GetAt(0).Result;
            }
            /*JSBindingType */ set Result(value)
            {
                this.Header.GetAt(0).Result = value.Clone();
            }
            /*JSBindingType */ get Exception()
            {
                return this.Header.GetAt(0).Exception;
            }
            /*JSBindingType */ set Exception(value)
            {
                this.Header.GetAt(0).Exception = value.Clone();
            }
            /*JSBindingType*/ get_Item(/*int*/ position)
            {
                return this.Sigs.GetAt(((position - 1) | 0));
            }
            static /*void */ InvokeJS(/*JSFunctionBinding*/ signature, /*Span<JSMarshalerArgument>*/ $arguments)
            {
                $.$srij.System.Runtime.InteropServices.JavaScript.JSFunctionBinding.InvokeJSImportImpl(signature, $arguments);
            }
            static /*JSFunctionBinding */ BindJSFunction(/*string*/ functionName, /*string*/ moduleName, /*ReadOnlySpan<JSMarshalerType>*/ signatures)
            {
                if ($.$spc.System.Runtime.InteropServices.RuntimeInformation.OSArchitecture !== 4/*Architecture.Wasm*/)
                {
                    throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
                }
                return $.$srij.System.Runtime.InteropServices.JavaScript.JSFunctionBinding.BindJSImportImpl(functionName, moduleName, signatures);
            }
            static /*JSFunctionBinding */ BindManagedFunction(/*string*/ fullyQualifiedName, /*int*/ signatureHash, /*ReadOnlySpan<JSMarshalerType>*/ signatures)
            {
                if ($.$spc.System.Runtime.InteropServices.RuntimeInformation.OSArchitecture !== 4/*Architecture.Wasm*/)
                {
                    throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
                }
                return $.$srij.System.Runtime.InteropServices.JavaScript.JSHostImplementation.BindManagedFunction(fullyQualifiedName, signatureHash, signatures);
            }
            static /*void */ InvokeJSFunction(/*JSObject*/ jsFunction, /*Span<JSMarshalerArgument>*/ $arguments)
            {
                jsFunction.AssertNotDisposed();
                $.$srij.System.Runtime.InteropServices.JavaScript.JSFunctionBinding.InvokeJSFunctionCurrent(jsFunction, $arguments);
            }
            static /*void */ InvokeJSFunctionCurrent(/*JSObject*/ jsFunction, /*Span<JSMarshalerArgument>*/ $arguments)
            {
                /*var*/ let functionHandle = jsFunction.JSHandle;
                /*fixed*/ 
                {
                    /*JSMarshalerArgument**/ let ptr = $arguments.GetPinnableReference();
                    $.$srij.Interop.Runtime.InvokeJSFunction(functionHandle, $.$cast(ptr, $.$spc.System.IntPtr));
                    /*ref JSMarshalerArgument*/ let exceptionArg = $arguments.get_Item(0);
                    if (exceptionArg.$v.slot.Type !== 0/*MarshalerType.None*/)
                    {
                        $.$srij.System.Runtime.InteropServices.JavaScript.JSHostImplementation.ThrowException(exceptionArg);
                    }
                }
            }
            static /*void */ InvokeJSImportImpl(/*JSFunctionBinding*/ signature, /*Span<JSMarshalerArgument>*/ $arguments)
            {
                /*ref JSMarshalerArgument*/ let exc = $arguments.get_Item(0);
                /*ref JSMarshalerArgument*/ let res = $arguments.get_Item(1);
                /*var*/ let targetContext = $.$srij.System.Runtime.InteropServices.JavaScript.JSProxyContext.MainThreadContext;
                if (signature.IsAsync)
                {
                    /*var*/ let holder = targetContext.CreatePromiseHolder();
                    res.$v.slot.Type = 30/*MarshalerType.TaskPreCreated*/;
                    res.$v.slot.GCHandle = holder.GCHandle;
                }
                if (signature.IsDiscardNoWait)
                {
                    $arguments.get_Item(1).$v.slot.Type = 26/*MarshalerType.DiscardNoWait*/;
                }
                $.$srij.System.Runtime.InteropServices.JavaScript.JSFunctionBinding.InvokeJSImportCurrent(signature, $arguments);
                if (signature.IsAsync)
                {
                    if ($arguments.get_Item(1).$v.slot.Type === 0/*MarshalerType.None*/)
                    {
                        /*var*/ let holderHandle = $.$spc.System.Runtime.InteropServices.GCHandle.op_Explicit($arguments.get_Item(1).$v.slot.GCHandle);
                        holderHandle.Free();
                    }
                }
            }
            static /*void */ InvokeJSImportCurrent(/*JSFunctionBinding*/ signature, /*Span<JSMarshalerArgument>*/ $arguments)
            {
                /*fixed*/ 
                {
                    /*JSMarshalerArgument**/ let args = $arguments.GetPinnableReference();
                    $.$srij.Interop.Runtime.InvokeJSImportST(signature.ImportHandle, $.$cast(args, $.$spc.System.IntPtr));
                }
                /*ref JSMarshalerArgument*/ let exceptionArg = $arguments.get_Item(0);
                if (exceptionArg.$v.slot.Type !== 0/*MarshalerType.None*/)
                {
                    $.$srij.System.Runtime.InteropServices.JavaScript.JSHostImplementation.ThrowException(exceptionArg);
                }
            }
            static /*JSFunctionBinding */ BindJSImportImpl(/*string*/ functionName, /*string*/ moduleName, /*ReadOnlySpan<JSMarshalerType>*/ signatures)
            {
                /*var*/ let signature = $.$srij.System.Runtime.InteropServices.JavaScript.JSHostImplementation.GetMethodSignature(signatures, functionName, moduleName);
                /*nint*/ let exceptionPtr = $.$srij.Interop.Runtime.BindJSImportST(signature.Header);
                if (exceptionPtr !== $.$spc.System.IntPtr.Zero)
                {
                    /*var*/ let message = $.$spc.System.Runtime.InteropServices.Marshal.PtrToStringUni(exceptionPtr);
                    $.$spc.System.Runtime.InteropServices.Marshal.FreeHGlobal(exceptionPtr);
                    throw new $.$srij.System.Runtime.InteropServices.JavaScript.JSException().$ctor$5(message);
                }
                $.$srij.System.Runtime.InteropServices.JavaScript.JSHostImplementation.FreeMethodSignatureBuffer(signature);
                return signature;
            }
            static /*void */ ResolveOrRejectPromise(/*JSProxyContext*/ targetContext, /*Span<JSMarshalerArgument>*/ $arguments)
            {
                /*ref JSMarshalerArgument*/ let exc = $arguments.get_Item(0);
                {
                    /*fixed*/ 
                    {
                        /*JSMarshalerArgument**/ let ptr = $arguments.GetPinnableReference();
                        $.$srij.Interop.Runtime.ResolveOrRejectPromise($.$cast(ptr, $.$spc.System.IntPtr));
                        if (exc.$v.slot.Type !== 0/*MarshalerType.None*/)
                        {
                            $.$srij.System.Runtime.InteropServices.JavaScript.JSHostImplementation.ThrowException(exc);
                        }
                    }
                }
            }
            //default member initializer
            constructor()
            {
                super();
                this.Header = $.$default($.$typePointer($.$srij.System.Runtime.InteropServices.JavaScript.JSFunctionBinding.JSBindingHeader));
                this.Sigs = $.$default($.$typePointer($.$srij.System.Runtime.InteropServices.JavaScript.JSFunctionBinding.JSBindingType));
            }
            static $h = 563965;
            static $f = 0b10010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":655361,"g":{"r":0,"d":0,"h":51540171517,"f":8},"s":{"r":0,"d":0,"h":55835138813,"f":8},"n":"ArgumentCount","d":563965,"h":47245204221,"f":8},{"p":655361,"g":{"r":0,"d":0,"h":64425073405,"f":8},"s":{"r":0,"d":0,"h":68720040701,"f":8},"n":"Version","d":563965,"h":60130106109,"f":8},{"p":695037,"g":{"r":0,"d":0,"h":77309975293,"f":8},"s":{"r":0,"d":0,"h":81604942589,"f":8},"n":"Result","d":563965,"h":73015007997,"f":8},{"p":695037,"i":[{"n":"position","p":655361}],"g":{"r":0,"d":0,"h":103079779069,"f":8},"n":"Item","o":"@$2","d":563965,"h":98784811773,"f":8}],"m":[{"r":65537,"p":[{"n":"signature","p":563965},{"n":"arguments","p":$.$spc.System.Span$$($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument).$h}],"n":"InvokeJS","d":563965,"h":107374746365,"f":33},{"r":563965,"p":[{"n":"functionName","p":1310721},{"n":"moduleName","p":1310721},{"n":"signatures","p":$.$spc.System.ReadOnlySpan$$($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType).$h}],"n":"BindJSFunction","d":563965,"h":111669713661,"f":33},{"r":563965,"p":[{"n":"fullyQualifiedName","p":1310721},{"n":"signatureHash","p":655361},{"n":"signatures","p":$.$spc.System.ReadOnlySpan$$($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType).$h}],"n":"BindManagedFunction","d":563965,"h":115964680957,"f":33},{"r":65537,"p":[{"n":"jsFunction","p":2267901},{"n":"arguments","p":$.$spc.System.Span$$($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument).$h}],"n":"InvokeJSFunction","d":563965,"h":120259648253,"f":40},{"r":65537,"p":[{"n":"jsFunction","p":2267901},{"n":"arguments","p":$.$spc.System.Span$$($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument).$h}],"n":"InvokeJSFunctionCurrent","d":563965,"h":124554615549,"f":40},{"r":65537,"p":[{"n":"signature","p":563965},{"n":"arguments","p":$.$spc.System.Span$$($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument).$h}],"n":"InvokeJSImportImpl","d":563965,"h":128849582845,"f":40},{"r":65537,"p":[{"n":"signature","p":563965},{"n":"arguments","p":$.$spc.System.Span$$($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument).$h}],"n":"InvokeJSImportCurrent","d":563965,"h":133144550141,"f":40},{"r":563965,"p":[{"n":"functionName","p":1310721},{"n":"moduleName","p":1310721},{"n":"signatures","p":$.$spc.System.ReadOnlySpan$$($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType).$h}],"n":"BindJSImportImpl","d":563965,"h":137439517437,"f":40},{"r":65537,"p":[{"n":"targetContext","p":2333437},{"n":"arguments","p":$.$spc.System.Span$$($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument).$h}],"n":"ResolveOrRejectPromise","d":563965,"h":141734484733,"f":40}],"l":[{"t":0,"n":"Header","d":563965,"h":8590498557,"f":8},{"t":0,"n":"Sigs","d":563965,"h":12885465853,"f":8},{"t":720897,"n":"nextImportHandle","d":563965,"h":17180433149,"f":40},{"t":655361,"n":"ImportHandle","d":563965,"h":21475400445,"f":8},{"t":262145,"n":"IsAsync","d":563965,"h":25770367741,"f":8},{"t":262145,"n":"IsDiscardNoWait","d":563965,"h":30065335037,"f":8},{"t":1310721,"n":"FunctionName","d":563965,"h":34360302333,"f":8}],"c":[{"n":".ctor","o":"$ctor$1","d":563965,"h":4295531261,"f":8}],"j":[629501,695037],"h":563965,"a":[{"t":23396353,"c":8613330945,"a":[{"v":false,"t":262145}]},{"t":114950145,"c":4409917441,"a":[{"v":"browser","t":1310721}]},{"t":33161217,"c":4328128513,"a":[{"v":1,"t":33226753}]}]}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.Runtime.InteropServices.JavaScript.JSFunctionBinding`; }
        });
        
        $asm.$cls("$srij.System.Runtime.InteropServices.JavaScript.JSHostImplementation", ($self) => class JSHostImplementation
        {
            /*string*/ static TaskGetResultName = null;
            /*MethodInfo?*/ static s_taskGetResultMethodInfo = null;
            static /*bool */ GetTaskResultDynamic(/*Task*/ task, /*out object?*/ value)
            {
                /*var*/ let type = $.$spc.System.Object.GetType.call(task);
                if ($.$spc.System.Type.op_Equality$1(type, $.$spc.System.Threading.Tasks.Task.$type))
                {
                    value.$v = null;
                    return false;
                }
                /*MethodInfo*/ let method = $.$srij.System.Runtime.InteropServices.JavaScript.JSHostImplementation.GetTaskResultMethodInfo(type);
                if ($.$spc.System.Reflection.MethodInfo.op_Inequality$2(method, null))
                {
                    value.$v = method.Invoke(task, null);
                    return true;
                }
                throw new $.$spc.System.InvalidOperationException().$ctor$9();
            }
            static /*MethodInfo */ GetTaskResultMethodInfo(/*Type*/ taskType)
            {
                if ($.$spc.System.Type.op_Inequality$1(taskType, null))
                {
                    if ($.$spc.System.Reflection.MethodInfo.op_Equality$2($.$srij.System.Runtime.InteropServices.JavaScript.JSHostImplementation.s_taskGetResultMethodInfo, null))
                    {
                        $.$srij.System.Runtime.InteropServices.JavaScript.JSHostImplementation.s_taskGetResultMethodInfo = $.$spc.System.Threading.Tasks.Task$$().$type.GetMethod$1("get_Result"/*TaskGetResultName*/);
                    }
                    /*MethodInfo?*/ let getter = taskType.GetMethod$1("get_Result"/*TaskGetResultName*/);
                    if ($.$spc.System.Reflection.MethodInfo.op_Inequality$2(getter, null) && getter.HasSameMetadataDefinitionAs($.$srij.System.Runtime.InteropServices.JavaScript.JSHostImplementation.s_taskGetResultMethodInfo))
                    {
                        return getter;
                    }
                }
                throw new $.$spc.System.InvalidOperationException().$ctor$9();
            }
            static /*void */ ThrowException(/*ref JSMarshalerArgument*/ arg)
            {
                /*Exception?*/ let ex;
                arg.$v.ToManaged$48($.$ref(() => ex, ($v) => ex = $v, $.$spc.System.Exception));
                if (ex !== null)
                {
                    throw ex;
                }
                throw new $.$spc.System.InvalidOperationException().$ctor$9();
            }
            static /*Task<JSObject> *//*async*/  ImportAsync(/*string*/ moduleName, /*string*/ moduleUrl, /*CancellationToken*/ cancellationToken)
            {
                return $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.Async($.$spc.System.Threading.Tasks.Task$$($.$srij.System.Runtime.InteropServices.JavaScript.JSObject), $.$srij.System.Runtime.InteropServices.JavaScript.JSObject, async () => 
                {
                    /*Task<JSObject>*/ let modulePromise = INTERNAL.dynamic_import(moduleName, moduleUrl);
                    /*var*/ let wrappedTask = $.$srij.System.Runtime.InteropServices.JavaScript.JSHostImplementation.CancellationHelper(modulePromise, cancellationToken);
                    return await wrappedTask.ConfigureAwait$3(1/*ConfigureAwaitOptions.ContinueOnCapturedContext*/ | 4/*ConfigureAwaitOptions.ForceYielding*/);
                });
            }
            static /*Task<JSObject> *//*async*/  CancellationHelper(/*Task<JSObject>*/ jsTask, /*CancellationToken*/ cancellationToken)
            {
                return $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.Async($.$spc.System.Threading.Tasks.Task$$($.$srij.System.Runtime.InteropServices.JavaScript.JSObject), $.$srij.System.Runtime.InteropServices.JavaScript.JSObject, async () => 
                {
                    if (jsTask.IsCompletedSuccessfully)
                    {
                        return jsTask.Result;
                    }
                    let receiveRegistration = null;
                    try
                    {
                        receiveRegistration = cancellationToken.Register$2(new ($.$spc.System.Action$$($.$spc.System.Object))().$ctor(null, /*static*/ (/**/ s) =>
                        {
                            $.$srij.System.Runtime.InteropServices.JavaScript.CancelablePromise.CancelPromise($.$cast(s, $.$spc.System.Threading.Tasks.Task$$($.$srij.System.Runtime.InteropServices.JavaScript.JSObject)));
                        }), jsTask);
                        return await jsTask.ConfigureAwait$2(false);
                    }
                    finally
                    {
                        receiveRegistration?.System$IDisposable$Dispose();
                    }
                });
            }
            static /*JSFunctionBinding */ GetMethodSignature(/*ReadOnlySpan<JSMarshalerType>*/ types, /*string?*/ functionName, /*string?*/ moduleName)
            {
                /*int*/ let argsCount = ((types.Length - 1) | 0);
                /*int*/ let size = ((32/*JSFunctionBinding.JSBindingHeader.JSMarshalerSignatureHeaderSize*/ + ((((((argsCount + 2) | 0)) * $.$srij.System.Runtime.InteropServices.JavaScript.JSFunctionBinding.JSBindingType.$z) | 0))) | 0);
                /*int*/ let functionNameBytes = 0;
                /*int*/ let functionNameOffset = 0;
                if ($.$spc.System.String.op_Inequality(functionName, null))
                {
                    functionNameOffset = size;
                    size += 4;
                    functionNameBytes = ((functionName.length * 2) | 0);
                    size += functionNameBytes;
                }
                /*int*/ let moduleNameBytes = 0;
                /*int*/ let moduleNameOffset = 0;
                if ($.$spc.System.String.op_Inequality(moduleName, null))
                {
                    moduleNameOffset = size;
                    size += 4;
                    moduleNameBytes = ((moduleName.length * 2) | 0);
                    size += moduleNameBytes;
                }
                /*IntPtr*/ let buffer = $.$spc.System.Runtime.InteropServices.Marshal.AllocHGlobal(size);
                /*var*/ let signature = (() =>
                {
                    //new $.$srij.System.Runtime.InteropServices.JavaScript.JSFunctionBinding()
                    const $t1 = $.$srij.System.Runtime.InteropServices.JavaScript.JSFunctionBinding;
                    const $i1 = new $t1();
                    $i1.$ctor$1();
                    $i1.Header = $.$cast(buffer, $.$typePointer($.$srij.System.Runtime.InteropServices.JavaScript.JSFunctionBinding.JSBindingHeader));
                    $i1.Sigs = $.$cast((((((buffer + 32/*JSFunctionBinding.JSBindingHeader.JSMarshalerSignatureHeaderSize*/) | 0) + (((2 * $.$srij.System.Runtime.InteropServices.JavaScript.JSFunctionBinding.JSBindingType.$z) | 0))) | 0)), $.$typePointer($.$srij.System.Runtime.InteropServices.JavaScript.JSFunctionBinding.JSBindingType));
                    return $i1;
                })();
                signature.Version = 2;
                signature.ArgumentCount = argsCount;
                signature.Exception = $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType.Exception._signatureType;
                signature.Result = types.get_Item(0).$v._signatureType;
                signature.ImportHandle = ($.$srij.System.Runtime.InteropServices.JavaScript.JSFunctionBinding.nextImportHandle++ | 0);
                signature.FunctionName = functionName;
                for(/*int*/ let i = 0; i < argsCount; i++)
                {
                    /*var*/ let type = signature.Sigs.SetAt(types.get_Item(((i + 1) | 0)).$v._signatureType, i);
                }
                signature.IsAsync = types.get_Item(0).$v._signatureType.Type === 20/*MarshalerType.Task*/;
                signature.IsDiscardNoWait = types.get_Item(0).$v._signatureType.Type === 26/*MarshalerType.DiscardNoWait*/;
                signature.Header.GetAt(0).ImportHandle = signature.ImportHandle;
                signature.Header.GetAt(0).FunctionNameLength = functionNameBytes;
                signature.Header.GetAt(0).FunctionNameOffset = functionNameOffset;
                signature.Header.GetAt(0).ModuleNameLength = moduleNameBytes;
                signature.Header.GetAt(0).ModuleNameOffset = moduleNameOffset;
                if (functionNameBytes !== 0)
                {
                    /*fixed*/ 
                    {
                        /*void**/ let fn = $.$spc.System.String.GetPinnableReference.call(functionName);
                        $.$spc.System.Runtime.CompilerServices.Unsafe.CopyBlock($.$cast(buffer, $.$typePointer($.$spc.System.Byte)).Add(functionNameOffset), fn, (functionNameBytes >>> 0));
                    }
                }
                if (moduleNameBytes !== 0)
                {
                    /*fixed*/ 
                    {
                        /*void**/ let mn = $.$spc.System.String.GetPinnableReference.call(moduleName);
                        $.$spc.System.Runtime.CompilerServices.Unsafe.CopyBlock($.$cast(buffer, $.$typePointer($.$spc.System.Byte)).Add(moduleNameOffset), mn, (moduleNameBytes >>> 0));
                    }
                }
                return signature;
            }
            static /*void */ FreeMethodSignatureBuffer(/*JSFunctionBinding*/ signature)
            {
                $.$spc.System.Runtime.InteropServices.Marshal.FreeHGlobal($.$cast(signature.Header, $.$spc.System.IntPtr));
                signature.Header = null;
                signature.Sigs = null;
            }
            static /*void */ LoadLazyAssembly(/*byte[]*/ dllBytes, /*byte[]?*/ pdbBytes)
            {
                if (pdbBytes === null)
                {
                    $.$spc.System.Runtime.Loader.AssemblyLoadContext.Default.LoadFromStream(new $.$spc.System.IO.MemoryStream().$ctor$5(dllBytes));
                }
                else 
                {
                    $.$spc.System.Runtime.Loader.AssemblyLoadContext.Default.LoadFromStream$1(new $.$spc.System.IO.MemoryStream().$ctor$5(dllBytes), new $.$spc.System.IO.MemoryStream().$ctor$5(pdbBytes));
                }
            }
            static /*void */ LoadSatelliteAssembly(/*byte[]*/ dllBytes)
            {
                $.$spc.System.Runtime.Loader.AssemblyLoadContext.Default.LoadFromStream(new $.$spc.System.IO.MemoryStream().$ctor$5(dllBytes));
            }
            static /*Task<int>? */ CallEntrypoint(/*IntPtr*/ assemblyNamePtr, /*string?[]?*/ args, /*bool*/ waitForDebugger)
            {
                try
                {
                    /*void**/ let ptr;
                    $.$srij.Interop.Runtime.AssemblyGetEntryPoint(assemblyNamePtr, waitForDebugger ? 1 : 0, $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateObjectReferenceT($.$typePointer($.$spc.System.Void), () => ptr, ($v) => ptr = $v, null));
                    /*RuntimeMethodHandle*/ let methodHandle = $.$srij.System.Runtime.InteropServices.JavaScript.JSHostImplementation.GetMethodHandleFromIntPtr($.$spc.System.IntPtr.op_Explicit$2(ptr));
                    /*MethodInfo?*/ let method = $.$as($.$spc.System.Reflection.MethodBase.GetMethodFromHandle(methodHandle), $.$spc.System.Reflection.MethodInfo);
                    if ($.$spc.System.Reflection.MethodInfo.op_Equality$2(method, null))
                    {
                        throw new $.$spc.System.InvalidOperationException().$ctor$10($.$srij.System.SR.CannotResolveManagedEntrypointHandle);
                    }
                    /*object[]*/ let argsToPass = $.$spc.System.Array.Empty($.$spc.System.Object);
                    /*Task<int>?*/ let result = null;
                    /*var*/ let parameterInfos = method.GetParameters();
                    if (parameterInfos.length > 0 && $.$spc.System.Type.op_Equality$1($.$spc.System.Array.$ReadT1.call(parameterInfos, 0).ParameterType, $.$typeArray($.$spc.System.String).$type))
                    {
                        argsToPass = $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$spc.System.Object), [args ?? $.$spc.System.Array.Empty($.$spc.System.String)], [-1], null);
                    }
                    if ($.$spc.System.Type.op_Equality$1(method.ReturnType, $.$spc.System.Void.$type))
                    {
                        method.Invoke(null, argsToPass);
                    }
                    else if ($.$spc.System.Type.op_Equality$1(method.ReturnType, $.$spc.System.Int32.$type))
                    {
                        /*int*/ let intResult = $.$cast(method.Invoke(null, argsToPass), $.$spc.System.Int32);
                        result = $.$spc.System.Threading.Tasks.Task.FromResult($.$spc.System.Int32, intResult);
                    }
                    else if ($.$spc.System.Type.op_Equality$1(method.ReturnType, $.$spc.System.Threading.Tasks.Task.$type))
                    {
                        /*Task*/ let methodResult = $.$cast(method.Invoke(null, argsToPass), $.$spc.System.Threading.Tasks.Task);
                        /*TaskCompletionSource<int>*/ let tcs = new ($.$spc.System.Threading.Tasks.TaskCompletionSource$$($.$spc.System.Int32))().$ctor$1();
                        result = tcs.Task;
                        methodResult.ContinueWith$2(new ($.$spc.System.Action$$($.$spc.System.Threading.Tasks.Task))().$ctor(this,  (/*t*/ t) =>
                        {
                            if (t.IsFaulted)
                            {
                                tcs.SetException(t.Exception);
                            }
                            else 
                            {
                                tcs.SetResult(0);
                            }
                        }), $.$spc.System.Threading.Tasks.TaskScheduler.Default);
                    }
                    else if ($.$spc.System.Type.op_Equality$1(method.ReturnType, $.$spc.System.Threading.Tasks.Task$$($.$spc.System.Int32).$type))
                    {
                        result = $.$cast(method.Invoke(null, argsToPass), $.$spc.System.Threading.Tasks.Task$$($.$spc.System.Int32));
                    }
                    else 
                    {
                        throw new $.$spc.System.InvalidOperationException().$ctor$10($.$srij.System.SR.Format($.$srij.System.SR.ReturnTypeNotSupportedForMain, method.ReturnType.FullName));
                    }
                    return result;
                }
                catch(ex)
                {
                    let refEx;
                    if ($.$is(ex, $.$spc.System.Reflection.TargetInvocationException, { set $v(v){ refEx = v; } }) && refEx.InnerException !== null)
                    {
                        ex = refEx.InnerException;
                    }
                    return $.$spc.System.Threading.Tasks.Task.FromException$1($.$spc.System.Int32, ex);
                }
            }
            static /*Task */ BindAssemblyExports(/*string?*/ assemblyName)
            {
                $.$srij.Interop.Runtime.BindAssemblyExports($.$spc.System.Runtime.InteropServices.Marshal.StringToCoTaskMemUTF8(assemblyName));
                return $.$spc.System.Threading.Tasks.Task.CompletedTask;
            }
            static /*JSFunctionBinding */ BindManagedFunction(/*string*/ fullyQualifiedName, /*int*/ signatureHash, /*ReadOnlySpan<JSMarshalerType>*/ signatures)
            {
                /*var*/ let  [ assemblyName, nameSpace, shortClassName, methodName ] = $.$destructure($.$srij.System.Runtime.InteropServices.JavaScript.JSHostImplementation.ParseFQN(fullyQualifiedName));
                /*IntPtr*/ let monoMethod;
                $.$srij.Interop.Runtime.GetAssemblyExport($.$spc.System.Runtime.InteropServices.Marshal.StringToCoTaskMemUTF8(assemblyName), $.$spc.System.Runtime.InteropServices.Marshal.StringToCoTaskMemUTF8(nameSpace), $.$spc.System.Runtime.InteropServices.Marshal.StringToCoTaskMemUTF8(shortClassName), $.$spc.System.Runtime.InteropServices.Marshal.StringToCoTaskMemUTF8(methodName), signatureHash, $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateObjectReferenceT($.$spc.System.IntPtr, () => monoMethod, ($v) => monoMethod = $v, null));
                if (monoMethod === $.$spc.System.IntPtr.Zero)
                {
                    $.$spc.System.Environment.FailFast(`Can't find ${nameSpace}${shortClassName}${methodName} in ${assemblyName}.dll`);
                }
                /*var*/ let signature = $.$srij.System.Runtime.InteropServices.JavaScript.JSHostImplementation.GetMethodSignature(signatures, null, null);
                INTERNAL.mono_wasm_bind_cs_function(monoMethod, assemblyName, nameSpace, shortClassName, methodName, signatureHash, $.$cast(signature.Header, $.$spc.System.IntPtr));
                $.$srij.System.Runtime.InteropServices.JavaScript.JSHostImplementation.FreeMethodSignatureBuffer(signature);
                return signature;
            }
            static /*RuntimeMethodHandle */ GetMethodHandleFromIntPtr(/*IntPtr*/ ptr)
            {
                /*var*/ let temp = (() =>
                {
                    //new $.$srij.System.Runtime.InteropServices.JavaScript.JSHostImplementation.IntPtrAndHandle()
                    const $t1 = $.$srij.System.Runtime.InteropServices.JavaScript.JSHostImplementation.IntPtrAndHandle;
                    const $i1 = new $t1();
                    $i1.ptr = ptr;
                    return $i1;
                })();
                return temp.methodHandle;
            }
            static /*int */ SmallIndexOf(/*string*/ s, /*char*/ ch, /*int*/ direction)
            {
                if (s.length < 1)
                {
                    return -1;
                }
                /*int*/ let start_index = (direction > 0) ? 0 : ((s.length - 1) | 0), end_index = (direction > 0) ? ((s.length - 1) | 0) : 0;
                for(/*int*/ let i = start_index; i !== end_index; i += direction)
                {
                    if ($.$spc.System.String.get_Chars.call(s, i) === ch)
                    {
                        return i;
                    }
                }
                return -1;
            }
            static /*string */ SmallTrim(/*string*/ s)
            {
                if (s.length < 1)
                {
                    return s;
                }
                /*int*/ let head = 0, tail = ((s.length - 1) | 0);
                while(head < s.length)
                {
                    if ($.$spc.System.String.get_Chars.call(s, head) === /* */ 32)
                    {
                        head++;
                    }
                    else 
                    {
                        break;
                    }
                }
                while(tail >= 0)
                {
                    if ($.$spc.System.String.get_Chars.call(s, tail) === /* */ 32)
                    {
                        tail--;
                    }
                    else 
                    {
                        break;
                    }
                }
                if ((head > 0) || (tail < ((s.length - 1) | 0)))
                {
                    return $.$spc.System.String.Substring$1.call(s, head, ((((tail - head) | 0) + 1) | 0));
                }
                else 
                {
                    return s;
                }
            }
            static /*(string assemblyName, string nameSpace, string shortClassName, string methodName) */ ParseFQN(/*string*/ fqn)
            {
                /*var*/ let assembly = $.$spc.System.String.Substring$1.call(fqn, (($.$srij.System.Runtime.InteropServices.JavaScript.JSHostImplementation.SmallIndexOf(fqn, /*[*/ 91, 1) + 1) | 0), (($.$srij.System.Runtime.InteropServices.JavaScript.JSHostImplementation.SmallIndexOf(fqn, /*]*/ 93, 1) - 1) | 0));
                fqn = $.$srij.System.Runtime.InteropServices.JavaScript.JSHostImplementation.SmallTrim(fqn);
                fqn = $.$spc.System.String.Substring.call(fqn, (($.$srij.System.Runtime.InteropServices.JavaScript.JSHostImplementation.SmallIndexOf(fqn, /*]*/ 93, 1) + 1) | 0));
                fqn = $.$srij.System.Runtime.InteropServices.JavaScript.JSHostImplementation.SmallTrim(fqn);
                /*var*/ let methodName = $.$spc.System.String.Substring.call(fqn, (($.$srij.System.Runtime.InteropServices.JavaScript.JSHostImplementation.SmallIndexOf(fqn, /*:*/ 58, 1) + 1) | 0));
                /*var*/ let className = $.$spc.System.String.Substring$1.call(fqn, 0, $.$srij.System.Runtime.InteropServices.JavaScript.JSHostImplementation.SmallIndexOf(fqn, /*:*/ 58, 1));
                className = $.$srij.System.Runtime.InteropServices.JavaScript.JSHostImplementation.SmallTrim(className);
                /*var*/ let nameSpace = "";
                /*var*/ let shortClassName = className;
                /*var*/ let idx = $.$srij.System.Runtime.InteropServices.JavaScript.JSHostImplementation.SmallIndexOf(fqn, /*.*/ 46, -1);
                if (idx !== -1)
                {
                    nameSpace = $.$spc.System.String.Substring$1.call(fqn, 0, idx);
                    shortClassName = $.$spc.System.String.Substring.call(className, ((idx + 1) | 0));
                }
                if ($.$spc.System.String.IsNullOrEmpty(assembly))
                {
                    throw new $.$spc.System.InvalidOperationException().$ctor$10("No assembly name specified " + fqn);
                }
                if ($.$spc.System.String.IsNullOrEmpty(className))
                {
                    throw new $.$spc.System.InvalidOperationException().$ctor$10("No class name specified " + fqn);
                }
                if ($.$spc.System.String.IsNullOrEmpty(methodName))
                {
                    throw new $.$spc.System.InvalidOperationException().$ctor$10("No method name specified " + fqn);
                }
                return new ($.$spc.System.ValueTuple$$$$$($.$spc.System.String, $.$spc.System.String, $.$spc.System.String, $.$spc.System.String))().$ctor$2(assembly, nameSpace, shortClassName, methodName);
            }
            static $_ToManagedCallback;
            static get ToManagedCallback()
            {
                let $cls = $.$srij.System.Runtime.InteropServices.JavaScript.JSHostImplementation;
                return $cls.$_ToManagedCallback ??= $asm.$ncls("$srij.System.Runtime.InteropServices.JavaScript.JSHostImplementation.ToManagedCallback", ($self) => class ToManagedCallback extends $.$spc.System.MulticastDelegate
                {
                    $ctor(/*object*/ target, fn)
                    {
                        this._target = target;
                        this.$nativeFunction = fn;
                        return this;
                    }
                    /*void*/ Invoke(/**/ $arguments_buffer)
                    {
                        return this.$nativeFunction.apply(this._target, arguments);
                    }
                    static $h = 1153789;
                    static $f = 0b10000000010000000;
                    static $k = 5;
                    static $$md;
                    static get $md() { return this.$$md ??= {"b":66191361,"m":[{"r":65537,"p":[{"n":"arguments_buffer","p":0}],"n":"Invoke","d":1153789,"h":8591088381,"f":129},{"r":56950785,"p":[{"n":"arguments_buffer","p":0},{"n":"callback","p":14417921},{"n":"object","p":131073}],"n":"BeginInvoke","d":1153789,"h":12886055677,"f":129},{"r":65537,"p":[{"n":"result","p":56950785}],"n":"EndInvoke","d":1153789,"h":17181022973,"f":129}],"c":[{"p":[{"n":"object","p":131073},{"n":"method","p":786433}],"n":".ctor","o":"$ctor$5","d":1153789,"h":4296121085,"f":1}],"i":[57147393,113377281],"d":826109,"h":1153789}; }
                    static get $b() { return $.$spc.System.MulticastDelegate; }
                    static $$i;
                    static get $i() { return this.$$i ??= [ $.$spc.System.ICloneable, $.$spc.System.Runtime.Serialization.ISerializable ]; }
                    static get $fullName() { return `System.Runtime.InteropServices.JavaScript.JSHostImplementation.ToManagedCallback`; }
                }, $cls, ($v) => $cls.$_ToManagedCallback = $v);
            }
            static $_PromiseHolder;
            static get PromiseHolder()
            {
                let $cls = $.$srij.System.Runtime.InteropServices.JavaScript.JSHostImplementation;
                return $cls.$_PromiseHolder ??= $asm.$ncls("$srij.System.Runtime.InteropServices.JavaScript.JSHostImplementation.PromiseHolder", ($self) => class PromiseHolder extends $.$spc.System.Object
                {
                    /*bool*/ IsDisposed = false;
                    /*nint*/ GCHandle = 0;
                    /*ToManagedCallback?*/ Callback = null;
                    /*JSProxyContext*/ ProxyContext = null;
                    $ctor$1(/*JSProxyContext*/ targetContext)
                    {
                        super.$ctor();
                        {
                            this.GCHandle = $.$spc.System.Runtime.InteropServices.GCHandle.op_Explicit$1($.$spc.System.Runtime.InteropServices.GCHandle.Alloc$1(this, 2/*GCHandleType.Normal*/));
                            this.ProxyContext = targetContext;
                        }
                        return this;
                    }
                    $ctor$2(/*JSProxyContext*/ targetContext, /*nint*/ gcvHandle)
                    {
                        super.$ctor();
                        {
                            this.GCHandle = gcvHandle;
                            this.ProxyContext = targetContext;
                        }
                        return this;
                    }
                    static $h = 1022717;
                    static $f = 0b10000000010010001;
                    static $k = 1;
                    static $$md;
                    static get $md() { return this.$$md ??= {"b":131073,"l":[{"t":262145,"n":"IsDisposed","d":1022717,"h":4295990013,"f":1},{"t":786433,"n":"GCHandle","d":1022717,"h":8590957309,"f":1},{"t":1153789,"n":"Callback","d":1022717,"h":12885924605,"f":1},{"t":2333437,"n":"ProxyContext","d":1022717,"h":17180891901,"f":1}],"c":[{"p":[{"n":"targetContext","p":2333437}],"n":".ctor","o":"$ctor$1","d":1022717,"h":21475859197,"f":1},{"p":[{"n":"targetContext","p":2333437},{"n":"gcvHandle","p":786433}],"n":".ctor","o":"$ctor$2","d":1022717,"h":25770826493,"f":1}],"d":826109,"h":1022717}; }
                    static get $b() { return $.$spc.System.Object; }
                    static get $fullName() { return `System.Runtime.InteropServices.JavaScript.JSHostImplementation.PromiseHolder`; }
                }, $cls, ($v) => $cls.$_PromiseHolder = $v);
            }
            static $_PromiseHolderState;
            static get PromiseHolderState()
            {
                let $cls = $.$srij.System.Runtime.InteropServices.JavaScript.JSHostImplementation;
                return $cls.$_PromiseHolderState ??= $asm.$nstr("$srij.System.Runtime.InteropServices.JavaScript.JSHostImplementation.PromiseHolderState", ($self) => class PromiseHolderState extends $.$spc.System.ValueType
                {
                    /*int*/  get IsResolving() { return this.$getField(0, $.$spc.System.Int32); }
                    /*int*/  set IsResolving(value) { this.$setField(0, $.$spc.System.Int32, value); }
                    //default value type constructor
                    $ctor$2()
                    {
                        return this;
                    }
                    Clone($copy)
                    {
                        let copy = $copy ?? new this.constructor();
                        copy.IsResolving = this.IsResolving;
                        return copy;
                    }
                    //default member initializer
                    constructor()
                    {
                        super();
                        this.IsResolving = 0;
                    }
                    static $h = 1088253;
                    static $z = 4;
                    static $f = 0b10100010000001010000001;
                    static $k = 2;
                    static $$md;
                    static get $md() { return this.$$md ??= {"b":196609,"l":[{"t":655361,"n":"IsResolving","d":1088253,"h":4296055549,"f":1,"a":[{"t":104071169,"c":4399038465,"a":[{"v":0,"t":655361}]}]}],"c":[{"n":".ctor","o":"$ctor$2","d":1088253,"h":8591022845,"f":1}],"d":826109,"h":1088253,"a":[{"t":109903873,"c":4404871169,"a":[{"v":2,"t":105381889}]}]}; }
                    static get $b() { return $.$spc.System.ValueType; }
                    static get $fullName() { return `System.Runtime.InteropServices.JavaScript.JSHostImplementation.PromiseHolderState`; }
                }, $cls, ($v) => $cls.$_PromiseHolderState = $v);
            }
            static $_IntPtrAndHandle;
            static get IntPtrAndHandle()
            {
                let $cls = $.$srij.System.Runtime.InteropServices.JavaScript.JSHostImplementation;
                return $cls.$_IntPtrAndHandle ??= $asm.$nstr("$srij.System.Runtime.InteropServices.JavaScript.JSHostImplementation.IntPtrAndHandle", ($self) => class IntPtrAndHandle extends $.$spc.System.ValueType
                {
                    /*IntPtr*/  get ptr() { return this.$getField(0, 4); }
                    /*IntPtr*/  set ptr(value) { this.$setField(0, 4, value); }
                    /*RuntimeMethodHandle*/  get methodHandle() { return this.$getField(0, 1); }
                    /*RuntimeMethodHandle*/  set methodHandle(value) { this.$setField(0, 1, value); }
                    /*RuntimeTypeHandle*/  get typeHandle() { return this.$getField(0, 1); }
                    /*RuntimeTypeHandle*/  set typeHandle(value) { this.$setField(0, 1, value); }
                    //default value type constructor
                    $ctor$2()
                    {
                        return this;
                    }
                    Clone($copy)
                    {
                        let copy = $copy ?? new this.constructor();
                        copy.ptr = this.ptr;
                        copy.methodHandle = this.methodHandle.Clone();
                        copy.typeHandle = this.typeHandle.Clone();
                        return copy;
                    }
                    //default member initializer
                    constructor()
                    {
                        super();
                        this.ptr = 0;
                        this.methodHandle = $.$default($.$spc.System.RuntimeMethodHandle);
                        this.typeHandle = $.$default($.$spc.System.RuntimeTypeHandle);
                    }
                    static $h = 891645;
                    static $z = 4;
                    static $f = 0b100010000001010000001;
                    static $k = 2;
                    static $$md;
                    static get $md() { return this.$$md ??= {"b":196609,"l":[{"t":786433,"n":"ptr","d":891645,"h":4295858941,"f":8,"a":[{"t":104071169,"c":4399038465,"a":[{"v":0,"t":655361}]}]},{"t":115605505,"n":"methodHandle","d":891645,"h":8590826237,"f":8,"a":[{"t":104071169,"c":4399038465,"a":[{"v":0,"t":655361}]}]},{"t":116064257,"n":"typeHandle","d":891645,"h":12885793533,"f":8,"a":[{"t":104071169,"c":4399038465,"a":[{"v":0,"t":655361}]}]}],"c":[{"n":".ctor","o":"$ctor$2","d":891645,"h":17180760829,"f":1}],"d":826109,"h":891645,"a":[{"t":109903873,"c":4404871169,"a":[{"v":2,"t":105381889}]}]}; }
                    static get $b() { return $.$spc.System.ValueType; }
                    static get $fullName() { return `System.Runtime.InteropServices.JavaScript.JSHostImplementation.IntPtrAndHandle`; }
                }, $cls, ($v) => $cls.$_IntPtrAndHandle = $v);
            }
            static $_JSThreadBlockingMode;
            static get JSThreadBlockingMode()
            {
                let $cls = $.$srij.System.Runtime.InteropServices.JavaScript.JSHostImplementation;
                return $cls.$_JSThreadBlockingMode ??= $asm.$nstr("$srij.System.Runtime.InteropServices.JavaScript.JSHostImplementation.JSThreadBlockingMode", ($self) => class JSThreadBlockingMode extends $.$spc.System.Enum
                {
                    static PreventSynchronousJSExport = 0;
                    static ThrowWhenBlockingWait = 1;
                    static WarnWhenBlockingWait = 2;
                    static DangerousAllowBlockingWait = 100;
                    static $map;
                    static get Map()
                    {
                        return this.$map ??= 
                        {
                            "PreventSynchronousJSExport": 0n,
                            "ThrowWhenBlockingWait": 1n,
                            "WarnWhenBlockingWait": 2n,
                            "DangerousAllowBlockingWait": 100n
                        };
                    }
                    static $h = 957181;
                    static $z = 4;
                    static $f = 0b110000011010001001;
                    static $k = 4;
                    static get $eut() { return $.$spc.System.Int32; }
                    static $$md;
                    static get $md() { return this.$$md ??= {"b":1048577,"u":655361,"l":[{"t":957181,"n":"PreventSynchronousJSExport","d":957181,"h":4295924477,"f":33},{"t":957181,"n":"ThrowWhenBlockingWait","d":957181,"h":8590891773,"f":33},{"t":957181,"n":"WarnWhenBlockingWait","d":957181,"h":12885859069,"f":33},{"t":957181,"n":"DangerousAllowBlockingWait","d":957181,"h":17180826365,"f":33}],"c":[{"n":".ctor","o":"$ctor$3","d":957181,"h":21475793661,"f":1}],"i":[57212929,63766529,57671681,57344001],"d":826109,"h":957181}; }
                    static get $b() { return $.$spc.System.Enum; }
                    static $$i;
                    static get $i() { return this.$$i ??= [ $.$spc.System.IComparable, $.$spc.System.ISpanFormattable, $.$spc.System.IFormattable, $.$spc.System.IConvertible ]; }
                    static get $fullName() { return `System.Runtime.InteropServices.JavaScript.JSHostImplementation.JSThreadBlockingMode`; }
                }, $cls, ($v) => $cls.$_JSThreadBlockingMode = $v);
            }
            //Static Initializer
            static $sinit()
            {
                {
                    this.TaskGetResultName = "get_Result";
                }
            }
            static $h = 826109;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"m":[{"r":262145,"p":[{"n":"task","p":133300225},{"n":"value","p":131073,"f":2}],"n":"GetTaskResultDynamic","d":826109,"h":12885727997,"f":33},{"r":79626241,"p":[{"n":"taskType","p":142606337}],"n":"GetTaskResultMethodInfo","d":826109,"h":17180695293,"f":33},{"r":65537,"p":[{"n":"arg","p":1350397,"f":4}],"n":"ThrowException","d":826109,"h":21475662589,"f":33},{"r":$.$spc.System.Threading.Tasks.Task$$($.$srij.System.Runtime.InteropServices.JavaScript.JSObject).$h,"p":[{"n":"moduleName","p":1310721},{"n":"moduleUrl","p":1310721},{"n":"cancellationToken","p":125960193}],"n":"ImportAsync","d":826109,"h":25770629885,"f":4129},{"r":$.$spc.System.Threading.Tasks.Task$$($.$srij.System.Runtime.InteropServices.JavaScript.JSObject).$h,"p":[{"n":"jsTask","p":$.$spc.System.Threading.Tasks.Task$$($.$srij.System.Runtime.InteropServices.JavaScript.JSObject).$h},{"n":"cancellationToken","p":125960193}],"n":"CancellationHelper","d":826109,"h":30065597181,"f":4129},{"r":563965,"p":[{"n":"types","p":$.$spc.System.ReadOnlySpan$$($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType).$h},{"n":"functionName","p":1310721},{"n":"moduleName","p":1310721}],"n":"GetMethodSignature","d":826109,"h":34360564477,"f":33},{"r":65537,"p":[{"n":"signature","p":563965}],"n":"FreeMethodSignatureBuffer","d":826109,"h":38655531773,"f":33},{"r":65537,"p":[{"n":"dllBytes","p":0},{"n":"pdbBytes","p":0}],"n":"LoadLazyAssembly","d":826109,"h":42950499069,"f":33},{"r":65537,"p":[{"n":"dllBytes","p":0}],"n":"LoadSatelliteAssembly","d":826109,"h":47245466365,"f":33},{"r":$.$spc.System.Threading.Tasks.Task$$($.$spc.System.Int32).$h,"p":[{"n":"assemblyNamePtr","p":786433},{"n":"args","p":0},{"n":"waitForDebugger","p":262145}],"n":"CallEntrypoint","d":826109,"h":51540433661,"f":33},{"r":133300225,"p":[{"n":"assemblyName","p":1310721}],"n":"BindAssemblyExports","d":826109,"h":55835400957,"f":33},{"r":563965,"p":[{"n":"fullyQualifiedName","p":1310721},{"n":"signatureHash","p":655361},{"n":"signatures","p":$.$spc.System.ReadOnlySpan$$($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerType).$h}],"n":"BindManagedFunction","d":826109,"h":60130368253,"f":33},{"r":115605505,"p":[{"n":"ptr","p":786433}],"n":"GetMethodHandleFromIntPtr","d":826109,"h":64425335549,"f":33},{"r":655361,"p":[{"n":"s","p":1310721},{"n":"ch","p":458753},{"n":"direction","p":655361,"f":65,"v":1}],"n":"SmallIndexOf","d":826109,"h":68720302845,"f":34},{"r":1310721,"p":[{"n":"s","p":1310721}],"n":"SmallTrim","d":826109,"h":73015270141,"f":34},{"r":$.$spc.System.ValueTuple$$$$$($.$spc.System.String, $.$spc.System.String, $.$spc.System.String, $.$spc.System.String).$h,"p":[{"n":"fqn","p":1310721}],"n":"ParseFQN","d":826109,"h":77310237437,"f":33}],"l":[{"t":1310721,"n":"TaskGetResultName","d":826109,"h":4295793405,"f":34},{"t":79626241,"n":"s_taskGetResultMethodInfo","d":826109,"h":8590760701,"f":34}],"j":[1153789,1022717,1088253,891645,957181],"h":826109}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.Runtime.InteropServices.JavaScript.JSHostImplementation`; }
        });
        
        $asm.$cls("$srij.System.Runtime.InteropServices.JavaScript.CancelablePromise", ($self) => class CancelablePromise
        {
            static /*void */ CancelPromise(/*Task*/ promise)
            {
                if (promise.IsCompleted)
                {
                    return;
                }
                /*JSHostImplementation.PromiseHolder?*/ let holder = $.$as(promise.AsyncState, $.$srij.System.Runtime.InteropServices.JavaScript.JSHostImplementation.$.$srij.System.Runtime.InteropServices.JavaScript.JSHostImplementation.PromiseHolder);
                if (holder === null)
                {
                    throw new $.$spc.System.InvalidOperationException().$ctor$10("Expected Task converted from JS Promise");
                }
                if (holder.IsDisposed)
                {
                    return;
                }
                $.$srij.Interop.Runtime.CancelPromise(holder.GCHandle);
            }
            static $h = 236285;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"m":[{"r":65537,"p":[{"n":"promise","p":133300225}],"n":"CancelPromise","d":236285,"h":4295203581,"f":33}],"h":236285}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.Runtime.InteropServices.JavaScript.CancelablePromise`; }
        });
        
        $asm.$cls("$srij.System.Runtime.InteropServices.JavaScript.JSObject", ($self) => class JSObject extends $.$spc.System.Object
        {
            /*bool */ get IsDisposed()
            {
                return this._isDisposed;
            }
            /*bool */ HasProperty(/*string*/ propertyName)
            {
                this.AssertNotDisposed();
                return INTERNAL.has_property(this, propertyName);
            }
            /*string */ GetTypeOfProperty(/*string*/ propertyName)
            {
                this.AssertNotDisposed();
                return INTERNAL.get_typeof_property(this, propertyName);
            }
            /*bool */ GetPropertyAsBoolean(/*string*/ propertyName)
            {
                this.AssertNotDisposed();
                return INTERNAL.get_property(this, propertyName);
            }
            /*int */ GetPropertyAsInt32(/*string*/ propertyName)
            {
                this.AssertNotDisposed();
                return INTERNAL.get_property(this, propertyName);
            }
            /*double */ GetPropertyAsDouble(/*string*/ propertyName)
            {
                this.AssertNotDisposed();
                return INTERNAL.get_property(this, propertyName);
            }
            /*string? */ GetPropertyAsString(/*string*/ propertyName)
            {
                this.AssertNotDisposed();
                return INTERNAL.get_property(this, propertyName);
            }
            /*JSObject? */ GetPropertyAsJSObject(/*string*/ propertyName)
            {
                this.AssertNotDisposed();
                return INTERNAL.get_property(this, propertyName);
            }
            /*byte[]? */ GetPropertyAsByteArray(/*string*/ propertyName)
            {
                this.AssertNotDisposed();
                return INTERNAL.get_property(this, propertyName);
            }
            /*void */ SetProperty(/*string*/ propertyName, /*bool*/ value)
            {
                this.AssertNotDisposed();
                INTERNAL.set_property(this, propertyName, value);
            }
            /*void */ SetProperty$1(/*string*/ propertyName, /*int*/ value)
            {
                this.AssertNotDisposed();
                INTERNAL.set_property(this, propertyName, value);
            }
            /*void */ SetProperty$2(/*string*/ propertyName, /*double*/ value)
            {
                this.AssertNotDisposed();
                INTERNAL.set_property(this, propertyName, value);
            }
            /*void */ SetProperty$3(/*string*/ propertyName, /*string?*/ value)
            {
                this.AssertNotDisposed();
                INTERNAL.set_property(this, propertyName, value);
            }
            /*void */ SetProperty$4(/*string*/ propertyName, /*JSObject?*/ value)
            {
                this.AssertNotDisposed();
                INTERNAL.set_property(this, propertyName, value);
            }
            /*void */ SetProperty$5(/*string*/ propertyName, /*byte[]?*/ value)
            {
                this.AssertNotDisposed();
                INTERNAL.set_property(this, propertyName, value);
            }
            /*nint*/ JSHandle = 0;
            /*JSProxyContext*/ ProxyContext = null;
            /*SynchronizationContext */ get SynchronizationContext()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool*/ _isDisposed = false;
            $ctor$1(/*IntPtr*/ jsHandle, /*JSProxyContext*/ ctx)
            {
                super.$ctor();
                {
                    this.ProxyContext = ctx;
                    this.JSHandle = jsHandle;
                }
                return this;
            }
            static/*conventional*/ /*bool */ Equals(/*object?*/ obj)
            {
                let other;
                return $.$is(obj, $.$srij.System.Runtime.InteropServices.JavaScript.JSObject, { set $v(v){ other = v; } }) && this.JSHandle === other.JSHandle;
            }
            //Static convention instance redirect
            /*bool */ Equals() { return $.$srij.System.Runtime.InteropServices.JavaScript.JSObject.Equals.apply(this, arguments); }
            static/*conventional*/ /*int */ GetHashCode()
            {
                return this.JSHandle;
            }
            //Static convention instance redirect
            /*int */ GetHashCode() { return $.$srij.System.Runtime.InteropServices.JavaScript.JSObject.GetHashCode.apply(this, arguments); }
            static/*conventional*/ /*string */ ToString()
            {
                return `(js-obj js '${this.JSHandle}')`;
            }
            //Static convention instance redirect
            /*string */ ToString() { return $.$srij.System.Runtime.InteropServices.JavaScript.JSObject.ToString.apply(this, arguments); }
            /*void */ AssertNotDisposed()
            {
                {
                    $.$spc.System.ObjectDisposedException.ThrowIf(this.IsDisposed, this);
                }
            }
            /*void */ DisposeImpl(/*bool*/ skipJsCleanup)
            {
                if (!this._isDisposed)
                {
                    $.$srij.System.Runtime.InteropServices.JavaScript.JSProxyContext.ReleaseCSOwnedObject(this, skipJsCleanup);
                }
            }
            $dtor()
            {
                this.DisposeImpl(false);
            }
            /*void */ Dispose()
            {
                this.DisposeImpl(false);
            }
            //Generated interface implemetation for System.IDisposable.Dispose()
            System$IDisposable$Dispose()
            {
                return this.Dispose(...arguments);
            }
            //default member initializer
            constructor()
            {
                super();
                $.$finalizer(this);
            }
            static $h = 2267901;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":262145,"g":{"r":0,"d":0,"h":8592202493,"f":1},"n":"IsDisposed","d":2267901,"h":4297235197,"f":1},{"p":131137537,"g":{"r":0,"d":0,"h":85901613821,"f":1},"n":"SynchronizationContext","d":2267901,"h":81606646525,"f":1}],"m":[{"r":262145,"p":[{"n":"propertyName","p":1310721}],"n":"HasProperty","d":2267901,"h":12887169789,"f":1},{"r":1310721,"p":[{"n":"propertyName","p":1310721}],"n":"GetTypeOfProperty","d":2267901,"h":17182137085,"f":1},{"r":262145,"p":[{"n":"propertyName","p":1310721}],"n":"GetPropertyAsBoolean","d":2267901,"h":21477104381,"f":1},{"r":655361,"p":[{"n":"propertyName","p":1310721}],"n":"GetPropertyAsInt32","d":2267901,"h":25772071677,"f":1},{"r":1179649,"p":[{"n":"propertyName","p":1310721}],"n":"GetPropertyAsDouble","d":2267901,"h":30067038973,"f":1},{"r":1310721,"p":[{"n":"propertyName","p":1310721}],"n":"GetPropertyAsString","d":2267901,"h":34362006269,"f":1},{"r":2267901,"p":[{"n":"propertyName","p":1310721}],"n":"GetPropertyAsJSObject","d":2267901,"h":38656973565,"f":1},{"r":0,"p":[{"n":"propertyName","p":1310721}],"n":"GetPropertyAsByteArray","d":2267901,"h":42951940861,"f":1},{"r":65537,"p":[{"n":"propertyName","p":1310721},{"n":"value","p":262145}],"n":"SetProperty","d":2267901,"h":47246908157,"f":1},{"r":65537,"p":[{"n":"propertyName","p":1310721},{"n":"value","p":655361}],"n":"SetProperty","o":"@$1","d":2267901,"h":51541875453,"f":1},{"r":65537,"p":[{"n":"propertyName","p":1310721},{"n":"value","p":1179649}],"n":"SetProperty","o":"@$2","d":2267901,"h":55836842749,"f":1},{"r":65537,"p":[{"n":"propertyName","p":1310721},{"n":"value","p":1310721}],"n":"SetProperty","o":"@$3","d":2267901,"h":60131810045,"f":1},{"r":65537,"p":[{"n":"propertyName","p":1310721},{"n":"value","p":2267901}],"n":"SetProperty","o":"@$4","d":2267901,"h":64426777341,"f":1},{"r":65537,"p":[{"n":"propertyName","p":1310721},{"n":"value","p":0}],"n":"SetProperty","o":"@$5","d":2267901,"h":68721744637,"f":1},{"r":262145,"p":[{"n":"obj","p":131073}],"n":"Equals","d":2267901,"h":98786515709,"f":32769},{"r":655361,"n":"GetHashCode","d":2267901,"h":103081483005,"f":32769},{"r":1310721,"n":"ToString","d":2267901,"h":107376450301,"f":32769},{"r":65537,"n":"AssertNotDisposed","d":2267901,"h":111671417597,"f":8},{"r":65537,"p":[{"n":"skipJsCleanup","p":262145,"f":65,"v":false}],"n":"DisposeImpl","d":2267901,"h":115966384893,"f":8},{"r":65537,"n":"Dispose","d":2267901,"h":124556319485,"f":1}],"l":[{"t":786433,"n":"JSHandle","d":2267901,"h":73016711933,"f":8},{"t":2333437,"n":"ProxyContext","d":2267901,"h":77311679229,"f":8},{"t":262145,"n":"_isDisposed","d":2267901,"h":90196581117,"f":8}],"c":[{"p":[{"n":"jsHandle","p":786433},{"n":"ctx","p":2333437}],"n":".ctor","o":"$ctor$1","d":2267901,"h":94491548413,"f":8}],"i":[57475073],"h":2267901,"a":[{"t":114950145,"c":4409917441,"a":[{"v":"browser","t":1310721}]}]}; }
            static get $b() { return $.$spc.System.Object; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IDisposable ]; }
            static get $fullName() { return `System.Runtime.InteropServices.JavaScript.JSObject`; }
        });
        
        $asm.$cls("$srij.System.Runtime.InteropServices.JavaScript.JSProxyContext", ($self) => class JSProxyContext extends $.$spc.System.Object
        {
            /*bool*/ _isDisposed = false;
            /*Dictionary<nint, WeakReference<JSObject>>*/ ThreadCsOwnedObjects = null;
            /*Dictionary<object, nint>*/ ThreadJsOwnedObjects = null;
            /*Dictionary<nint, PromiseHolder>*/ ThreadJsOwnedHolders = null;
            /*nint*/ NextJSVHandle = -2;
            /*List<nint>*/ JSVHandleFreeList = null;
            $ctor$1()
            {
                super.$ctor();
                {
                }
                return this;
            }
            /*bool */ IsCurrentThread()
            {
                return true;
            }
            /*JSProxyContext*/ static MainThreadContext = null;
            static /*JSProxyContext */ get CurrentThreadContext()
            {
                return $.$srij.System.Runtime.InteropServices.JavaScript.JSProxyContext.MainThreadContext;
            }
            static /*JSProxyContext */ get CurrentOperationContext()
            {
                return $.$srij.System.Runtime.InteropServices.JavaScript.JSProxyContext.MainThreadContext;
            }
            static /*JSProxyContext */ PushOperationWithCurrentThreadContext()
            {
                return $.$srij.System.Runtime.InteropServices.JavaScript.JSProxyContext.MainThreadContext;
            }
            static /*JSProxyContext */ AssertIsInteropThread()
            {
                return $.$srij.System.Runtime.InteropServices.JavaScript.JSProxyContext.MainThreadContext;
            }
            static /*bool */ IsJSVHandle(/*nint*/ jsHandle)
            {
                return jsHandle < -1;
            }
            static /*bool */ IsGCVHandle(/*nint*/ gcHandle)
            {
                return gcHandle < -1;
            }
            /*nint */ AllocJSVHandle()
            {
                {
                    $.$spc.System.ObjectDisposedException.ThrowIf(this._isDisposed, this);
                    if (this.JSVHandleFreeList.Count > 0)
                    {
                        /*var*/ let jsvHandle = this.JSVHandleFreeList.get_Item(((this.JSVHandleFreeList.Count - 1) | 0));
                        this.JSVHandleFreeList.RemoveAt(((this.JSVHandleFreeList.Count - 1) | 0));
                        return jsvHandle;
                    }
                    return this.NextJSVHandle--;
                }
            }
            /*void */ FreeJSVHandle(/*nint*/ jsvHandle)
            {
                {
                    this.JSVHandleFreeList.Add(jsvHandle);
                }
            }
            /*IntPtr */ GetJSOwnedObjectGCHandle(/*object*/ obj, /*GCHandleType*/ handleType)
            {
                if (obj === null)
                {
                    return $.$spc.System.IntPtr.Zero;
                }
                {
                    /*IntPtr*/ let gcHandle;
                    if (this.ThreadJsOwnedObjects.TryGetValue(obj, $.$ref(() => gcHandle, ($v) => gcHandle = $v, $.$spc.System.IntPtr)))
                    {
                        return gcHandle;
                    }
                    /*IntPtr*/ let result = $.$spc.System.Runtime.InteropServices.GCHandle.op_Explicit$1($.$spc.System.Runtime.InteropServices.GCHandle.Alloc$1(obj, handleType));
                    this.ThreadJsOwnedObjects.set_Item(obj, result);
                    return result;
                }
            }
            /*PromiseHolder */ CreatePromiseHolder()
            {
                {
                    return new $.$srij.System.Runtime.InteropServices.JavaScript.JSHostImplementation.PromiseHolder().$ctor$1(this);
                }
            }
            /*PromiseHolder */ GetPromiseHolder(/*nint*/ gcHandle)
            {
                {
                    /*PromiseHolder?*/ let holder;
                    if ($.$srij.System.Runtime.InteropServices.JavaScript.JSProxyContext.IsGCVHandle(gcHandle))
                    {
                        if (!this.ThreadJsOwnedHolders.TryGetValue(gcHandle, $.$ref(() => holder, ($v) => holder = $v, $.$srij.System.Runtime.InteropServices.JavaScript.JSHostImplementation.PromiseHolder)))
                        {
                            holder = new $.$srij.System.Runtime.InteropServices.JavaScript.JSHostImplementation.PromiseHolder().$ctor$2(this, gcHandle);
                            this.ThreadJsOwnedHolders.Add(gcHandle, holder);
                        }
                    }
                    else 
                    {
                        holder = $.$cast(($.$spc.System.Runtime.InteropServices.GCHandle.op_Explicit(gcHandle)).Target, $.$srij.System.Runtime.InteropServices.JavaScript.JSHostImplementation.PromiseHolder);
                    }
                    return holder;
                }
            }
            /*void */ ReleasePromiseHolder(/*nint*/ holderGCHandle)
            {
                {
                    /*PromiseHolder?*/ let holder;
                    if ($.$srij.System.Runtime.InteropServices.JavaScript.JSProxyContext.IsGCVHandle(holderGCHandle))
                    {
                        if (!this.ThreadJsOwnedHolders.Remove$1(holderGCHandle, $.$ref(() => holder, ($v) => holder = $v, $.$srij.System.Runtime.InteropServices.JavaScript.JSHostImplementation.PromiseHolder)))
                        {
                            throw new $.$spc.System.InvalidOperationException().$ctor$10("ReleasePromiseHolder expected PromiseHolder " + holderGCHandle);
                        }
                        holder.IsDisposed = true;
                    }
                    else 
                    {
                        /*GCHandle*/ let handle = $.$spc.System.Runtime.InteropServices.GCHandle.op_Explicit(holderGCHandle);
                        /*var*/ let target = handle.Target;
                        let holder2;
                        if ($.$is(target, $.$srij.System.Runtime.InteropServices.JavaScript.JSHostImplementation.PromiseHolder, { set $v(v){ holder2 = v; } }))
                        {
                            holder = holder2;
                        }
                        else 
                        {
                            throw new $.$spc.System.InvalidOperationException().$ctor$10("ReleasePromiseHolder expected PromiseHolder" + holderGCHandle);
                        }
                        holder.IsDisposed = true;
                        handle.Free();
                    }
                }
            }
            /*void */ ReleaseJSOwnedObjectByGCHandle(/*nint*/ gcHandle)
            {
                /*ToManagedCallback?*/ let holderCallback = null;
                {
                    /*PromiseHolder?*/ let holder = null;
                    if ($.$srij.System.Runtime.InteropServices.JavaScript.JSProxyContext.IsGCVHandle(gcHandle))
                    {
                        if (!this.ThreadJsOwnedHolders.Remove$1(gcHandle, $.$ref(() => holder, ($v) => holder = $v, $.$srij.System.Runtime.InteropServices.JavaScript.JSHostImplementation.PromiseHolder)))
                        {
                            throw new $.$spc.System.InvalidOperationException().$ctor$10("ReleaseJSOwnedObjectByGCHandle expected in ThreadJsOwnedHolders");
                        }
                    }
                    else 
                    {
                        /*GCHandle*/ let handle = $.$spc.System.Runtime.InteropServices.GCHandle.op_Explicit(gcHandle);
                        /*var*/ let target = handle.Target;
                        let holder2;
                        if ($.$is(target, $.$srij.System.Runtime.InteropServices.JavaScript.JSHostImplementation.PromiseHolder, { set $v(v){ holder2 = v; } }))
                        {
                            holder = holder2;
                        }
                        else 
                        {
                            if (!this.ThreadJsOwnedObjects.Remove(target))
                            {
                                throw new $.$spc.System.InvalidOperationException().$ctor$10("ReleaseJSOwnedObjectByGCHandle expected in ThreadJsOwnedObjects");
                            }
                        }
                        handle.Free();
                    }
                    if (holder !== null)
                    {
                        holderCallback = holder.Callback;
                        holder.IsDisposed = true;
                    }
                }
                holderCallback?.Invoke(null);
            }
            /*JSObject */ CreateCSOwnedProxy(/*nint*/ jsHandle)
            {
                {
                    /*JSObject?*/ let res;
                    /*WeakReference<JSObject>?*/ let reference;
                    if (!this.ThreadCsOwnedObjects.TryGetValue(jsHandle, $.$ref(() => reference, ($v) => reference = $v, $.$spc.System.WeakReference$$($.$srij.System.Runtime.InteropServices.JavaScript.JSObject))) || !reference.TryGetTarget($.$ref(() => res, ($v) => res = $v, $.$srij.System.Runtime.InteropServices.JavaScript.JSObject)) || res.IsDisposed)
                    {
                        res = new $.$srij.System.Runtime.InteropServices.JavaScript.JSObject().$ctor$1(jsHandle, this);
                        this.ThreadCsOwnedObjects.set_Item(jsHandle, new ($.$spc.System.WeakReference$$($.$srij.System.Runtime.InteropServices.JavaScript.JSObject))().$ctor$2(res, true));
                    }
                    return res;
                }
            }
            static /*void */ ReleaseCSOwnedObject(/*JSObject*/ jso, /*bool*/ skipJS)
            {
                if (jso.IsDisposed)
                {
                    return;
                }
                /*var*/ let ctx = jso.ProxyContext;
                {
                    if (jso.IsDisposed || ctx._isDisposed)
                    {
                        return;
                    }
                    /*var*/ let jsHandle = jso.JSHandle;
                    jso._isDisposed = true;
                    jso.JSHandle = $.$spc.System.IntPtr.Zero;
                    $.$spc.System.GC.SuppressFinalize(jso);
                    if (!ctx.ThreadCsOwnedObjects.Remove(jsHandle))
                    {
                        $.$spc.System.Environment.FailFast(`ReleaseCSOwnedObject expected to find registration for JSHandle: ${jsHandle}, ManagedThreadId: ${$.$spc.System.Environment.CurrentManagedThreadId}. ${$.$spc.System.Environment.NewLine} ${$.$spc.System.Environment.StackTrace}`);
                    }
                    if (!skipJS)
                    {
                        $.$srij.Interop.Runtime.ReleaseCSOwnedObject(jsHandle);
                    }
                    if ($.$srij.System.Runtime.InteropServices.JavaScript.JSProxyContext.IsJSVHandle(jsHandle))
                    {
                        ctx.FreeJSVHandle(jsHandle);
                    }
                }
            }
            /*void */ Dispose(/*bool*/ disposing)
            {
                {
                    if (!this._isDisposed)
                    {
                        /*List<WeakReference<JSObject>>*/ let copy = new ($.$spc.System.Collections.Generic.List$$($.$spc.System.WeakReference$$($.$srij.System.Runtime.InteropServices.JavaScript.JSObject)))().$ctor$3(this.ThreadCsOwnedObjects.Values);
                        var $en4 = copy.GetEnumerator();
                        while ($en4.MoveNext())
                        {
                            var jsObjectWeak = $en4.Current;
                            {
                                /*var*/ let jso;
                                if (jsObjectWeak.TryGetTarget($.$ref(() => jso, ($v) => jso = $v, $.$srij.System.Runtime.InteropServices.JavaScript.JSObject)))
                                {
                                    jso.Dispose();
                                }
                            }
                        }
                        var $en4 = this.ThreadJsOwnedObjects.Values.GetEnumerator();
                        while ($en4.MoveNext())
                        {
                            var gch = $en4.Current;
                            {
                                /*GCHandle*/ let gcHandle = $.$spc.System.Runtime.InteropServices.GCHandle.op_Explicit(gch);
                                gcHandle.Free();
                            }
                        }
                        var $en4 = this.ThreadJsOwnedHolders.Values.GetEnumerator();
                        while ($en4.MoveNext())
                        {
                            var holder = $en4.Current;
                            {
                                {
                                    holder.Callback.Invoke(null);
                                }
                                ($.$spc.System.Runtime.InteropServices.GCHandle.op_Explicit(holder.GCHandle)).Free();
                            }
                        }
                        this.ThreadCsOwnedObjects.Clear();
                        this.ThreadJsOwnedObjects.Clear();
                        this.JSVHandleFreeList.Clear();
                        this.NextJSVHandle = $.$spc.System.IntPtr.Zero;
                        if (disposing)
                        {
                        }
                        this._isDisposed = true;
                    }
                }
            }
            $dtor()
            {
                this.Dispose(false);
            }
            /*void */ Dispose$1()
            {
                this.Dispose(true);
                $.$spc.System.GC.SuppressFinalize(this);
            }
            //Generated interface implemetation for System.IDisposable.Dispose()
            System$IDisposable$Dispose()
            {
                return this.Dispose$1(...arguments);
            }
            //default member initializer
            constructor()
            {
                super();
                this.ThreadCsOwnedObjects = new ($.$spc.System.Collections.Generic.Dictionary$$$($.$spc.System.IntPtr, $.$spc.System.WeakReference$$($.$srij.System.Runtime.InteropServices.JavaScript.JSObject)))().$ctor$1();
                this.ThreadJsOwnedObjects = new ($.$spc.System.Collections.Generic.Dictionary$$$($.$spc.System.Object, $.$spc.System.IntPtr))().$ctor$3($.$spc.System.Collections.Generic.ReferenceEqualityComparer.Instance);
                this.ThreadJsOwnedHolders = new ($.$spc.System.Collections.Generic.Dictionary$$$($.$spc.System.IntPtr, $.$srij.System.Runtime.InteropServices.JavaScript.JSHostImplementation.PromiseHolder))().$ctor$1();
                this.JSVHandleFreeList = new ($.$spc.System.Collections.Generic.List$$($.$spc.System.IntPtr))().$ctor$1();
                $.$finalizer(this);
            }
            //Static Initializer
            static $sinit()
            {
                {
                    this.MainThreadContext = new $.$srij.System.Runtime.InteropServices.JavaScript.JSProxyContext().$ctor$1();
                }
            }
            static $h = 2333437;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":2333437,"g":{"r":0,"d":0,"h":47246973693,"f":33},"n":"CurrentThreadContext","d":2333437,"h":42952006397,"f":33},{"p":2333437,"g":{"r":0,"d":0,"h":55836908285,"f":33},"n":"CurrentOperationContext","d":2333437,"h":51541940989,"f":33}],"m":[{"r":262145,"n":"IsCurrentThread","d":2333437,"h":34362071805,"f":1},{"r":2333437,"n":"PushOperationWithCurrentThreadContext","d":2333437,"h":60131875581,"f":33},{"r":2333437,"n":"AssertIsInteropThread","d":2333437,"h":64426842877,"f":33},{"r":262145,"p":[{"n":"jsHandle","p":786433}],"n":"IsJSVHandle","d":2333437,"h":68721810173,"f":33},{"r":262145,"p":[{"n":"gcHandle","p":786433}],"n":"IsGCVHandle","d":2333437,"h":73016777469,"f":33},{"r":786433,"n":"AllocJSVHandle","d":2333437,"h":77311744765,"f":1},{"r":65537,"p":[{"n":"jsvHandle","p":786433}],"n":"FreeJSVHandle","d":2333437,"h":81606712061,"f":1},{"r":786433,"p":[{"n":"obj","p":131073},{"n":"handleType","p":104333313,"f":65,"v":2}],"n":"GetJSOwnedObjectGCHandle","d":2333437,"h":85901679357,"f":1},{"r":1022717,"n":"CreatePromiseHolder","d":2333437,"h":90196646653,"f":1},{"r":1022717,"p":[{"n":"gcHandle","p":786433}],"n":"GetPromiseHolder","d":2333437,"h":94491613949,"f":1},{"r":65537,"p":[{"n":"holderGCHandle","p":786433}],"n":"ReleasePromiseHolder","d":2333437,"h":98786581245,"f":1},{"r":65537,"p":[{"n":"gcHandle","p":786433}],"n":"ReleaseJSOwnedObjectByGCHandle","d":2333437,"h":103081548541,"f":1},{"r":2267901,"p":[{"n":"jsHandle","p":786433}],"n":"CreateCSOwnedProxy","d":2333437,"h":107376515837,"f":1},{"r":65537,"p":[{"n":"jso","p":2267901},{"n":"skipJS","p":262145}],"n":"ReleaseCSOwnedObject","d":2333437,"h":111671483133,"f":33},{"r":65537,"p":[{"n":"disposing","p":262145}],"n":"Dispose","d":2333437,"h":115966450429,"f":2},{"r":65537,"n":"Dispose","o":"@$1","d":2333437,"h":124556385021,"f":1}],"l":[{"t":262145,"n":"_isDisposed","d":2333437,"h":4297300733,"f":8},{"t":$.$spc.System.Collections.Generic.Dictionary$$$($.$spc.System.IntPtr, $.$spc.System.WeakReference$$($.$srij.System.Runtime.InteropServices.JavaScript.JSObject)).$h,"n":"ThreadCsOwnedObjects","d":2333437,"h":8592268029,"f":2},{"t":$.$spc.System.Collections.Generic.Dictionary$$$($.$spc.System.Object, $.$spc.System.IntPtr).$h,"n":"ThreadJsOwnedObjects","d":2333437,"h":12887235325,"f":2},{"t":$.$spc.System.Collections.Generic.Dictionary$$$($.$spc.System.IntPtr, $.$srij.System.Runtime.InteropServices.JavaScript.JSHostImplementation.PromiseHolder).$h,"n":"ThreadJsOwnedHolders","d":2333437,"h":17182202621,"f":2},{"t":786433,"n":"NextJSVHandle","d":2333437,"h":21477169917,"f":2},{"t":$.$spc.System.Collections.Generic.List$$($.$spc.System.IntPtr).$h,"n":"JSVHandleFreeList","d":2333437,"h":25772137213,"f":2},{"t":2333437,"n":"MainThreadContext","d":2333437,"h":38657039101,"f":33}],"c":[{"n":".ctor","o":"$ctor$1","d":2333437,"h":30067104509,"f":2}],"i":[57475073],"h":2333437}; }
            static get $b() { return $.$spc.System.Object; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IDisposable ]; }
            static get $fullName() { return `System.Runtime.InteropServices.JavaScript.JSProxyContext`; }
        });
        
        $asm.$cls("$srij.System.Runtime.InteropServices.JavaScript.JSMarshalAsAttribute<>", (T) => $asm.$gt("$srij.System.Runtime.InteropServices.JavaScript.JSMarshalAsAttribute<>", [T], ($self) => class JSMarshalAsAttribute$$ extends $.$spc.System.Attribute
        {
            $ctor$2()
            {
                super.$ctor$1();
                {
                }
                return this;
            }
            static $h = 1284861;
            static $g = 1;
            static $f = 0b11010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":14483457,"c":[{"n":".ctor","o":"$ctor$2","d":this.$h,"h":Number(BigInt(this.$h)|0x100000000n),"f":1}],"g":[T?.$h??1507328],"r":1,"h":this.$h,"a":[{"t":14614529,"c":21489451009,"a":[{"v":10240,"t":14548993}],"n":[{"n":"Inherited","v":false,"t":262145},{"n":"AllowMultiple","v":false,"t":262145}]},{"t":114950145,"c":4409917441,"a":[{"v":"browser","t":1310721}]}]}; }
            static get $b() { return $.$spc.System.Attribute; }
            static get $fullName() { return `System.Runtime.InteropServices.JavaScript.JSMarshalAsAttribute<${T?.$fullName}>`; }
        }));
        
        $asm.$str("$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument", ($self) => class JSMarshalerArgument extends $.$spc.System.ValueType
        {
            /*JSMarshalerArgumentImpl*/  get slot() { return this.$getField(0, 32); }
            /*JSMarshalerArgumentImpl*/  set slot(value) { this.$setField(0, 32, value); }
            static $_JSMarshalerArgumentImpl;
            static get JSMarshalerArgumentImpl()
            {
                let $cls = $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument;
                return $cls.$_JSMarshalerArgumentImpl ??= $asm.$nstr("$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument.JSMarshalerArgumentImpl", ($self) => class JSMarshalerArgumentImpl extends $.$spc.System.ValueType
                {
                    /*bool*/  get BooleanValue() { return this.$getField(0, 1); }
                    /*bool*/  set BooleanValue(value) { this.$setField(0, 1, value); }
                    /*byte*/  get ByteValue() { return this.$getField(0, 1); }
                    /*byte*/  set ByteValue(value) { this.$setField(0, 1, value); }
                    /*char*/  get CharValue() { return this.$getField(0, 2); }
                    /*char*/  set CharValue(value) { this.$setField(0, 2, value); }
                    /*short*/  get Int16Value() { return this.$getField(0, 2); }
                    /*short*/  set Int16Value(value) { this.$setField(0, 2, value); }
                    /*int*/  get Int32Value() { return this.$getField(0, 4); }
                    /*int*/  set Int32Value(value) { this.$setField(0, 4, value); }
                    /*long*/  get Int64Value() { return this.$getField(0, 8); }
                    /*long*/  set Int64Value(value) { this.$setField(0, 8, value); }
                    /*float*/  get SingleValue() { return this.$getField(0, 4); }
                    /*float*/  set SingleValue(value) { this.$setField(0, 4, value); }
                    /*double*/  get DoubleValue() { return this.$getField(0, 8); }
                    /*double*/  set DoubleValue(value) { this.$setField(0, 8, value); }
                    /*IntPtr*/  get IntPtrValue() { return this.$getField(0, 4); }
                    /*IntPtr*/  set IntPtrValue(value) { this.$setField(0, 4, value); }
                    /*IntPtr*/  get JSHandle() { return this.$getField(4, 4); }
                    /*IntPtr*/  set JSHandle(value) { this.$setField(4, 4, value); }
                    /*IntPtr*/  get GCHandle() { return this.$getField(4, 4); }
                    /*IntPtr*/  set GCHandle(value) { this.$setField(4, 4, value); }
                    /*int*/  get Length() { return this.$getField(8, 4); }
                    /*int*/  set Length(value) { this.$setField(8, 4, value); }
                    /*MarshalerType*/  get Type() { return this.$getField(12, 1); }
                    /*MarshalerType*/  set Type(value) { this.$setField(12, 1, value); }
                    /*MarshalerType*/  get ElementType() { return this.$getField(13, 1); }
                    /*MarshalerType*/  set ElementType(value) { this.$setField(13, 1, value); }
                    //default value type constructor
                    $ctor$2()
                    {
                        return this;
                    }
                    Clone($copy)
                    {
                        let copy = $copy ?? new this.constructor();
                        copy.BooleanValue = this.BooleanValue;
                        copy.ByteValue = this.ByteValue;
                        copy.CharValue = this.CharValue;
                        copy.Int16Value = this.Int16Value;
                        copy.Int32Value = this.Int32Value;
                        copy.Int64Value = this.Int64Value;
                        copy.SingleValue = this.SingleValue;
                        copy.DoubleValue = this.DoubleValue;
                        copy.IntPtrValue = this.IntPtrValue;
                        copy.JSHandle = this.JSHandle;
                        copy.GCHandle = this.GCHandle;
                        copy.Length = this.Length;
                        copy.Type = this.Type;
                        copy.ElementType = this.ElementType;
                        return copy;
                    }
                    //default member initializer
                    constructor()
                    {
                        super();
                        this.BooleanValue = false;
                        this.ByteValue = 0;
                        this.CharValue = 0;
                        this.Int16Value = 0;
                        this.Int32Value = 0;
                        this.Int64Value = 0n;
                        this.SingleValue = 0;
                        this.DoubleValue = 0;
                        this.IntPtrValue = 0;
                        this.JSHandle = 0;
                        this.GCHandle = 0;
                        this.Length = 0;
                        this.Type = 0;
                        this.ElementType = 0;
                    }
                    static $h = 2136829;
                    static $z = 32;
                    static $f = 0b100010000001010000000;
                    static $k = 2;
                    static $$md;
                    static get $md() { return this.$$md ??= {"b":196609,"l":[{"t":262145,"n":"BooleanValue","d":2136829,"h":4297104125,"f":8,"a":[{"t":104071169,"c":4399038465,"a":[{"v":0,"t":655361}]}]},{"t":393217,"n":"ByteValue","d":2136829,"h":8592071421,"f":8,"a":[{"t":104071169,"c":4399038465,"a":[{"v":0,"t":655361}]}]},{"t":458753,"n":"CharValue","d":2136829,"h":12887038717,"f":8,"a":[{"t":104071169,"c":4399038465,"a":[{"v":0,"t":655361}]}]},{"t":524289,"n":"Int16Value","d":2136829,"h":17182006013,"f":8,"a":[{"t":104071169,"c":4399038465,"a":[{"v":0,"t":655361}]}]},{"t":655361,"n":"Int32Value","d":2136829,"h":21476973309,"f":8,"a":[{"t":104071169,"c":4399038465,"a":[{"v":0,"t":655361}]}]},{"t":917505,"n":"Int64Value","d":2136829,"h":25771940605,"f":8,"a":[{"t":104071169,"c":4399038465,"a":[{"v":0,"t":655361}]}]},{"t":1114113,"n":"SingleValue","d":2136829,"h":30066907901,"f":8,"a":[{"t":104071169,"c":4399038465,"a":[{"v":0,"t":655361}]}]},{"t":1179649,"n":"DoubleValue","d":2136829,"h":34361875197,"f":8,"a":[{"t":104071169,"c":4399038465,"a":[{"v":0,"t":655361}]}]},{"t":786433,"n":"IntPtrValue","d":2136829,"h":38656842493,"f":8,"a":[{"t":104071169,"c":4399038465,"a":[{"v":0,"t":655361}]}]},{"t":786433,"n":"JSHandle","d":2136829,"h":42951809789,"f":8,"a":[{"t":104071169,"c":4399038465,"a":[{"v":4,"t":655361}]}]},{"t":786433,"n":"GCHandle","d":2136829,"h":47246777085,"f":8,"a":[{"t":104071169,"c":4399038465,"a":[{"v":4,"t":655361}]}]},{"t":655361,"n":"Length","d":2136829,"h":51541744381,"f":8,"a":[{"t":104071169,"c":4399038465,"a":[{"v":8,"t":655361}]}]},{"t":3709693,"n":"Type","d":2136829,"h":55836711677,"f":8,"a":[{"t":104071169,"c":4399038465,"a":[{"v":12,"t":655361}]}]},{"t":3709693,"n":"ElementType","d":2136829,"h":60131678973,"f":8,"a":[{"t":104071169,"c":4399038465,"a":[{"v":13,"t":655361}]}]}],"c":[{"n":".ctor","o":"$ctor$2","d":2136829,"h":64426646269,"f":1}],"d":1350397,"h":2136829,"a":[{"t":109903873,"c":4404871169,"a":[{"v":2,"t":105381889}],"n":[{"n":"Pack","v":32,"t":655361},{"n":"Size","v":32,"t":655361}]}]}; }
                    static get $b() { return $.$spc.System.ValueType; }
                    static get $fullName() { return `System.Runtime.InteropServices.JavaScript.JSMarshalerArgument.JSMarshalerArgumentImpl`; }
                }, $cls, ($v) => $cls.$_JSMarshalerArgumentImpl = $v);
            }
            /*void */ Initialize()
            {
                this.slot.Type = 0/*MarshalerType.None*/;
            }
            /*JSProxyContext */ get ToManagedContext()
            {
                return $.$srij.System.Runtime.InteropServices.JavaScript.JSProxyContext.MainThreadContext;
            }
            /*JSProxyContext */ get ToJSContext()
            {
                return $.$srij.System.Runtime.InteropServices.JavaScript.JSProxyContext.MainThreadContext;
            }
            /*JSProxyContext */ AssertCurrentThreadContext()
            {
                return $.$srij.System.Runtime.InteropServices.JavaScript.JSProxyContext.MainThreadContext;
            }
            /*void */ ToManagedBig(/*out long*/ value)
            {
                if (this.slot.Type === 0/*MarshalerType.None*/)
                {
                    value.$v = 0n;
                    return;
                }
                value.$v = this.slot.Int64Value;
            }
            /*void */ ToJSBig(/*long*/ value)
            {
                this.slot.Type = 9/*MarshalerType.BigInt64*/;
                this.slot.Int64Value = value;
            }
            /*void */ ToManagedBig$1(/*out long?*/ value)
            {
                if (this.slot.Type === 0/*MarshalerType.None*/)
                {
                    value.$v = null;
                    return;
                }
                value.$v = this.slot.Int64Value;
            }
            /*void */ ToJSBig$1(/*long?*/ value)
            {
                if ($.$spc.System.Nullable$$($.$spc.System.Int64).HasValue$get.call(value))
                {
                    this.slot.Type = 9/*MarshalerType.BigInt64*/;
                    this.slot.Int64Value = $.$spc.System.Nullable$$($.$spc.System.Int64).Value$get.call(value);
                }
                else 
                {
                    this.slot.Type = 0/*MarshalerType.None*/;
                }
            }
            /*void */ ToManaged(/*out char*/ value)
            {
                if (this.slot.Type === 0/*MarshalerType.None*/)
                {
                    value.$v = 0;
                    return;
                }
                value.$v = this.slot.CharValue;
            }
            /*void */ ToJS(/*char*/ value)
            {
                this.slot.Type = 5/*MarshalerType.Char*/;
                this.slot.CharValue = value;
            }
            /*void */ ToManaged$1(/*out char?*/ value)
            {
                if (this.slot.Type === 0/*MarshalerType.None*/)
                {
                    value.$v = null;
                    return;
                }
                value.$v = this.slot.CharValue;
            }
            /*void */ ToJS$1(/*char?*/ value)
            {
                if ($.$spc.System.Nullable$$($.$spc.System.Char).HasValue$get.call(value))
                {
                    this.slot.Type = 5/*MarshalerType.Char*/;
                    this.slot.CharValue = $.$spc.System.Nullable$$($.$spc.System.Char).Value$get.call(value);
                }
                else 
                {
                    this.slot.Type = 0/*MarshalerType.None*/;
                }
            }
            /*void */ ToManaged$2(/*out double*/ value)
            {
                if (this.slot.Type === 0/*MarshalerType.None*/)
                {
                    value.$v = 0;
                    return;
                }
                value.$v = this.slot.DoubleValue;
            }
            /*void */ ToJS$2(/*double*/ value)
            {
                this.slot.Type = 10/*MarshalerType.Double*/;
                this.slot.DoubleValue = value;
            }
            /*void */ ToManaged$3(/*out double?*/ value)
            {
                if (this.slot.Type === 0/*MarshalerType.None*/)
                {
                    value.$v = null;
                    return;
                }
                value.$v = this.slot.DoubleValue;
            }
            /*void */ ToJS$3(/*double?*/ value)
            {
                if ($.$spc.System.Nullable$$($.$spc.System.Double).HasValue$get.call(value))
                {
                    this.slot.Type = 10/*MarshalerType.Double*/;
                    this.slot.DoubleValue = $.$spc.System.Nullable$$($.$spc.System.Double).Value$get.call(value);
                }
                else 
                {
                    this.slot.Type = 0/*MarshalerType.None*/;
                }
            }
            /*void */ ToManaged$4(/*out double[]?*/ value)
            {
                if (this.slot.Type === 0/*MarshalerType.None*/)
                {
                    value.$v = null;
                    return;
                }
                value.$v = $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$spc.System.Double), null, [this.slot.Length], null);
                $.$spc.System.Runtime.InteropServices.Marshal.Copy$13(this.slot.IntPtrValue, value.$v, 0, this.slot.Length);
                $.$spc.System.Runtime.InteropServices.Marshal.FreeHGlobal(this.slot.IntPtrValue);
            }
            /*void */ ToJS$4(/*double[]*/ value)
            {
                if (value === null)
                {
                    this.slot.Type = 0/*MarshalerType.None*/;
                    return;
                }
                this.slot.Type = 21/*MarshalerType.Array*/;
                this.slot.IntPtrValue = $.$spc.System.Runtime.InteropServices.Marshal.AllocHGlobal(((value.length * $.$spc.System.Double.$z) | 0));
                this.slot.Length = value.length;
                this.slot.ElementType = 10/*MarshalerType.Double*/;
                $.$spc.System.Runtime.InteropServices.Marshal.Copy$5(value, 0, this.slot.IntPtrValue, this.slot.Length);
            }
            /*void */ ToManaged$5(/*out ArraySegment<double>*/ value)
            {
                /*var*/ let array = $.$cast(($.$spc.System.Runtime.InteropServices.GCHandle.op_Explicit(this.slot.GCHandle)).Target, $.$typeArray($.$spc.System.Double));
                /*var*/ let refPtr = $.$spc.System.IntPtr.op_Explicit$2($.$spc.System.Runtime.CompilerServices.Unsafe.AsPointer($.$spc.System.Double, $.$spc.System.Runtime.InteropServices.MemoryMarshal.GetArrayDataReference($.$spc.System.Double, array)));
                /*int*/ let byteOffset = (((this.slot.IntPtrValue - refPtr) | 0));
                value.$v = new ($.$spc.System.ArraySegment$$($.$spc.System.Double))().$ctor$3(array, $.trunc(byteOffset / $.$spc.System.Double.$z), this.slot.Length);
            }
            /*void */ ToJS$5(/*ArraySegment<double>*/ value)
            {
                if (value.Array === null)
                {
                    this.slot.Type = 0/*MarshalerType.None*/;
                    return;
                }
                this.slot.Type = 22/*MarshalerType.ArraySegment*/;
                /*var*/ let ctx = this.ToJSContext;
                this.slot.GCHandle = ctx.GetJSOwnedObjectGCHandle(value.Array, 3/*GCHandleType.Pinned*/);
                /*var*/ let refPtr = $.$spc.System.IntPtr.op_Explicit$2($.$spc.System.Runtime.CompilerServices.Unsafe.AsPointer($.$spc.System.Double, $.$spc.System.Runtime.InteropServices.MemoryMarshal.GetArrayDataReference($.$spc.System.Double, value.Array)));
                this.slot.IntPtrValue = ((refPtr + (((value.Offset * $.$spc.System.Double.$z) | 0))) | 0);
                this.slot.Length = value.Count;
            }
            /*void */ ToManaged$6(/*out Span<double>*/ value)
            {
                value.$v = new ($.$spc.System.Span$$($.$spc.System.Double))().$ctor$4($.$spc.System.IntPtr.op_Explicit$3(this.slot.IntPtrValue), this.slot.Length);
            }
            /*void */ ToJS$6(/*Span<double>*/ value)
            {
                this.slot.Length = value.Length;
                this.slot.IntPtrValue = $.$spc.System.IntPtr.op_Explicit$2($.$spc.System.Runtime.CompilerServices.Unsafe.AsPointer($.$spc.System.Double, value.GetPinnableReference()));
                this.slot.Type = 23/*MarshalerType.Span*/;
            }
            static $_ActionJS;
            static get ActionJS()
            {
                let $cls = $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument;
                return $cls.$_ActionJS ??= $asm.$ncls("$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument.ActionJS", ($self) => class ActionJS extends $.$spc.System.Object
                {
                    /*JSObject*/ JSObject = null;
                    $ctor$1(/*JSObject*/ holder)
                    {
                        super.$ctor();
                        {
                            this.JSObject = holder;
                        }
                        return this;
                    }
                    /*void */ InvokeJS()
                    {
                        /*Span<JSMarshalerArgument>*/ let $arguments = $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.StackAllocSpan($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument, 2, null);
                        /*ref JSMarshalerArgument*/ let args_exception = $arguments.get_Item(0);
                        /*ref JSMarshalerArgument*/ let args_return = $arguments.get_Item(1);
                        args_exception.$v.Initialize();
                        args_return.$v.Initialize();
                        $.$srij.System.Runtime.InteropServices.JavaScript.JSFunctionBinding.InvokeJSFunction(this.JSObject, $arguments);
                    }
                    static $h = 1415933;
                    static $f = 0b10000000010010000;
                    static $k = 1;
                    static $$md;
                    static get $md() { return this.$$md ??= {"b":131073,"m":[{"r":65537,"n":"InvokeJS","d":1415933,"h":12886317821,"f":1}],"l":[{"t":2267901,"n":"JSObject","d":1415933,"h":4296383229,"f":2}],"c":[{"p":[{"n":"holder","p":2267901}],"n":".ctor","o":"$ctor$1","d":1415933,"h":8591350525,"f":1}],"d":1350397,"h":1415933}; }
                    static get $b() { return $.$spc.System.Object; }
                    static get $fullName() { return `System.Runtime.InteropServices.JavaScript.JSMarshalerArgument.ActionJS`; }
                }, $cls, ($v) => $cls.$_ActionJS = $v);
            }
            static $_ActionJS$$;
            static ActionJS$$(T)
            {
                let $cls = $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument;
                return ($cls.$_ActionJS$$ ??= $asm.$ncls("$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument.ActionJS<>", (T) => $asm.$gt("$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument.ActionJS<>", [T], ($self) => class ActionJS$$ extends $.$spc.System.Object
                {
                    /*ArgumentToJSCallback<T>*/ Arg1Marshaler = null;
                    /*JSObject*/ JSObject = null;
                    $ctor$1(/*JSObject*/ holder, /*ArgumentToJSCallback<T>*/ arg1Marshaler)
                    {
                        super.$ctor();
                        {
                            this.JSObject = holder;
                            this.Arg1Marshaler = arg1Marshaler;
                        }
                        return this;
                    }
                    /*void */ InvokeJS(/*T*/ arg1)
                    {
                        /*Span<JSMarshalerArgument>*/ let $arguments = $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.StackAllocSpan($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument, 3, null);
                        /*ref JSMarshalerArgument*/ let args_exception = $arguments.get_Item(0);
                        /*ref JSMarshalerArgument*/ let args_return = $arguments.get_Item(1);
                        /*ref JSMarshalerArgument*/ let args_arg1 = $arguments.get_Item(2);
                        args_exception.$v.Initialize();
                        args_return.$v.Initialize();
                        this.Arg1Marshaler.Invoke(args_arg1, arg1);
                        $.$srij.System.Runtime.InteropServices.JavaScript.JSFunctionBinding.InvokeJSFunction(this.JSObject, $arguments);
                    }
                    static $h = 1612541;
                    static $g = 1;
                    static $f = 0b10000000011010000;
                    static $k = 1;
                    static $$md;
                    static get $md() { return this.$$md ??= {"b":131073,"m":[{"r":65537,"p":[{"n":"arg1","p":T?.$h??1507328}],"n":"InvokeJS","d":this.$h,"h":Number(BigInt(this.$h)|0x400000000n),"f":1}],"l":[{"t":$.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument.ArgumentToJSCallback$$(T).$h,"n":"Arg1Marshaler","d":this.$h,"h":Number(BigInt(this.$h)|0x100000000n),"f":2},{"t":2267901,"n":"JSObject","d":this.$h,"h":Number(BigInt(this.$h)|0x200000000n),"f":2}],"c":[{"p":[{"n":"holder","p":2267901},{"n":"arg1Marshaler","p":$.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument.ArgumentToJSCallback$$(T).$h}],"n":".ctor","o":"$ctor$1","d":this.$h,"h":Number(BigInt(this.$h)|0x300000000n),"f":1}],"g":[T?.$h??1507328],"r":1,"d":1350397,"h":this.$h}; }
                    static get $b() { return $.$spc.System.Object; }
                    static get $fullName() { return `System.Runtime.InteropServices.JavaScript.JSMarshalerArgument.ActionJS<${T?.$fullName}>`; }
                }), $cls, ($v) => $cls.$_ActionJS$$ = $v))(T);
            }
            static $_ActionJS$$$;
            static ActionJS$$$(T1, T2)
            {
                let $cls = $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument;
                return ($cls.$_ActionJS$$$ ??= $asm.$ncls("$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument.ActionJS<,>", (T1, T2) => $asm.$gt("$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument.ActionJS<,>", [T1, T2], ($self) => class ActionJS$$$ extends $.$spc.System.Object
                {
                    /*ArgumentToJSCallback<T1>*/ Arg1Marshaler = null;
                    /*ArgumentToJSCallback<T2>*/ Arg2Marshaler = null;
                    /*JSObject*/ JSObject = null;
                    $ctor$1(/*JSObject*/ holder, /*ArgumentToJSCallback<T1>*/ arg1Marshaler, /*ArgumentToJSCallback<T2>*/ arg2Marshaler)
                    {
                        super.$ctor();
                        {
                            this.JSObject = holder;
                            this.Arg1Marshaler = arg1Marshaler;
                            this.Arg2Marshaler = arg2Marshaler;
                        }
                        return this;
                    }
                    /*void */ InvokeJS(/*T1*/ arg1, /*T2*/ arg2)
                    {
                        /*Span<JSMarshalerArgument>*/ let $arguments = $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.StackAllocSpan($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument, 4, null);
                        /*ref JSMarshalerArgument*/ let args_exception = $arguments.get_Item(0);
                        /*ref JSMarshalerArgument*/ let args_return = $arguments.get_Item(1);
                        /*ref JSMarshalerArgument*/ let args_arg1 = $arguments.get_Item(2);
                        /*ref JSMarshalerArgument*/ let args_arg2 = $arguments.get_Item(3);
                        args_exception.$v.Initialize();
                        args_return.$v.Initialize();
                        this.Arg1Marshaler.Invoke(args_arg1, arg1);
                        this.Arg2Marshaler.Invoke(args_arg2, arg2);
                        $.$srij.System.Runtime.InteropServices.JavaScript.JSFunctionBinding.InvokeJSFunction(this.JSObject, $arguments);
                    }
                    static $h = 1547005;
                    static $g = 2;
                    static $f = 0b10000000011010000;
                    static $k = 1;
                    static $$md;
                    static get $md() { return this.$$md ??= {"b":131073,"m":[{"r":65537,"p":[{"n":"arg1","p":T1?.$h??1507328},{"n":"arg2","p":T2?.$h??1572864}],"n":"InvokeJS","d":this.$h,"h":Number(BigInt(this.$h)|0x500000000n),"f":1}],"l":[{"t":$.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument.ArgumentToJSCallback$$(T1).$h,"n":"Arg1Marshaler","d":this.$h,"h":Number(BigInt(this.$h)|0x100000000n),"f":2},{"t":$.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument.ArgumentToJSCallback$$(T2).$h,"n":"Arg2Marshaler","d":this.$h,"h":Number(BigInt(this.$h)|0x200000000n),"f":2},{"t":2267901,"n":"JSObject","d":this.$h,"h":Number(BigInt(this.$h)|0x300000000n),"f":2}],"c":[{"p":[{"n":"holder","p":2267901},{"n":"arg1Marshaler","p":$.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument.ArgumentToJSCallback$$(T1).$h},{"n":"arg2Marshaler","p":$.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument.ArgumentToJSCallback$$(T2).$h}],"n":".ctor","o":"$ctor$1","d":this.$h,"h":Number(BigInt(this.$h)|0x400000000n),"f":1}],"g":[T1?.$h??1507328,T2?.$h??1572864],"r":2,"d":1350397,"h":this.$h}; }
                    static get $b() { return $.$spc.System.Object; }
                    static get $fullName() { return `System.Runtime.InteropServices.JavaScript.JSMarshalerArgument.ActionJS<${T1?.$fullName},${T2?.$fullName}>`; }
                }), $cls, ($v) => $cls.$_ActionJS$$$ = $v))(T1, T2);
            }
            static $_ActionJS$$$$;
            static ActionJS$$$$(T1, T2, T3)
            {
                let $cls = $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument;
                return ($cls.$_ActionJS$$$$ ??= $asm.$ncls("$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument.ActionJS<,,>", (T1, T2, T3) => $asm.$gt("$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument.ActionJS<,,>", [T1, T2, T3], ($self) => class ActionJS$$$$ extends $.$spc.System.Object
                {
                    /*ArgumentToJSCallback<T1>*/ Arg1Marshaler = null;
                    /*ArgumentToJSCallback<T2>*/ Arg2Marshaler = null;
                    /*ArgumentToJSCallback<T3>*/ Arg3Marshaler = null;
                    /*JSObject*/ JSObject = null;
                    $ctor$1(/*JSObject*/ holder, /*ArgumentToJSCallback<T1>*/ arg1Marshaler, /*ArgumentToJSCallback<T2>*/ arg2Marshaler, /*ArgumentToJSCallback<T3>*/ arg3Marshaler)
                    {
                        super.$ctor();
                        {
                            this.JSObject = holder;
                            this.Arg1Marshaler = arg1Marshaler;
                            this.Arg2Marshaler = arg2Marshaler;
                            this.Arg3Marshaler = arg3Marshaler;
                        }
                        return this;
                    }
                    /*void */ InvokeJS(/*T1*/ arg1, /*T2*/ arg2, /*T3*/ arg3)
                    {
                        /*Span<JSMarshalerArgument>*/ let $arguments = $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.StackAllocSpan($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument, 5, null);
                        /*ref JSMarshalerArgument*/ let args_exception = $arguments.get_Item(0);
                        /*ref JSMarshalerArgument*/ let args_return = $arguments.get_Item(1);
                        /*ref JSMarshalerArgument*/ let args_arg1 = $arguments.get_Item(2);
                        /*ref JSMarshalerArgument*/ let args_arg2 = $arguments.get_Item(3);
                        /*ref JSMarshalerArgument*/ let args_arg3 = $arguments.get_Item(4);
                        args_exception.$v.Initialize();
                        args_return.$v.Initialize();
                        this.Arg1Marshaler.Invoke(args_arg1, arg1);
                        this.Arg2Marshaler.Invoke(args_arg2, arg2);
                        this.Arg3Marshaler.Invoke(args_arg3, arg3);
                        $.$srij.System.Runtime.InteropServices.JavaScript.JSFunctionBinding.InvokeJSFunction(this.JSObject, $arguments);
                    }
                    static $h = 1481469;
                    static $g = 3;
                    static $f = 0b10000000011010000;
                    static $k = 1;
                    static $$md;
                    static get $md() { return this.$$md ??= {"b":131073,"m":[{"r":65537,"p":[{"n":"arg1","p":T1?.$h??1507328},{"n":"arg2","p":T2?.$h??1572864},{"n":"arg3","p":T3?.$h??1638400}],"n":"InvokeJS","d":this.$h,"h":Number(BigInt(this.$h)|0x600000000n),"f":1}],"l":[{"t":$.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument.ArgumentToJSCallback$$(T1).$h,"n":"Arg1Marshaler","d":this.$h,"h":Number(BigInt(this.$h)|0x100000000n),"f":2},{"t":$.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument.ArgumentToJSCallback$$(T2).$h,"n":"Arg2Marshaler","d":this.$h,"h":Number(BigInt(this.$h)|0x200000000n),"f":2},{"t":$.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument.ArgumentToJSCallback$$(T3).$h,"n":"Arg3Marshaler","d":this.$h,"h":Number(BigInt(this.$h)|0x300000000n),"f":2},{"t":2267901,"n":"JSObject","d":this.$h,"h":Number(BigInt(this.$h)|0x400000000n),"f":2}],"c":[{"p":[{"n":"holder","p":2267901},{"n":"arg1Marshaler","p":$.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument.ArgumentToJSCallback$$(T1).$h},{"n":"arg2Marshaler","p":$.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument.ArgumentToJSCallback$$(T2).$h},{"n":"arg3Marshaler","p":$.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument.ArgumentToJSCallback$$(T3).$h}],"n":".ctor","o":"$ctor$1","d":this.$h,"h":Number(BigInt(this.$h)|0x500000000n),"f":1}],"g":[T1?.$h??1507328,T2?.$h??1572864,T3?.$h??1638400],"r":3,"d":1350397,"h":this.$h}; }
                    static get $b() { return $.$spc.System.Object; }
                    static get $fullName() { return `System.Runtime.InteropServices.JavaScript.JSMarshalerArgument.ActionJS<${T1?.$fullName},${T2?.$fullName},${T3?.$fullName}>`; }
                }), $cls, ($v) => $cls.$_ActionJS$$$$ = $v))(T1, T2, T3);
            }
            /*void */ ToManaged$7(/*out Action?*/ value)
            {
                if (this.slot.Type === 0/*MarshalerType.None*/)
                {
                    value.$v = null;
                    return;
                }
                /*var*/ let ctx = this.ToManagedContext;
                /*var*/ let holder = ctx.CreateCSOwnedProxy(this.slot.JSHandle);
                value.$v = new $.$spc.System.Action().$ctor(new $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument.ActionJS().$ctor$1(holder), new $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument.ActionJS().$ctor$1(holder).InvokeJS);
            }
            /*void */ ToManaged$8(T, /*out Action<T>?*/ value, /*ArgumentToJSCallback<T>*/ arg1Marshaler)
            {
                if (this.slot.Type === 0/*MarshalerType.None*/)
                {
                    value.$v = null;
                    return;
                }
                /*var*/ let ctx = this.ToManagedContext;
                /*var*/ let holder = ctx.CreateCSOwnedProxy(this.slot.JSHandle);
                value.$v = new ($.$spc.System.Action$$(T))().$ctor(new ($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument.ActionJS$$(T))().$ctor$1(holder, arg1Marshaler), new ($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument.ActionJS$$(T))().$ctor$1(holder, arg1Marshaler).InvokeJS);
            }
            /*void */ ToManaged$9(T1, T2, /*out Action<T1, T2>?*/ value, /*ArgumentToJSCallback<T1>*/ arg1Marshaler, /*ArgumentToJSCallback<T2>*/ arg2Marshaler)
            {
                if (this.slot.Type === 0/*MarshalerType.None*/)
                {
                    value.$v = null;
                    return;
                }
                /*var*/ let ctx = this.ToManagedContext;
                /*var*/ let holder = ctx.CreateCSOwnedProxy(this.slot.JSHandle);
                value.$v = new ($.$spc.System.Action$$$(T1, T2))().$ctor(new ($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument.ActionJS$$$(T1, T2))().$ctor$1(holder, arg1Marshaler, arg2Marshaler), new ($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument.ActionJS$$$(T1, T2))().$ctor$1(holder, arg1Marshaler, arg2Marshaler).InvokeJS);
            }
            /*void */ ToManaged$10(T1, T2, T3, /*out Action<T1, T2, T3>?*/ value, /*ArgumentToJSCallback<T1>*/ arg1Marshaler, /*ArgumentToJSCallback<T2>*/ arg2Marshaler, /*ArgumentToJSCallback<T3>*/ arg3Marshaler)
            {
                if (this.slot.Type === 0/*MarshalerType.None*/)
                {
                    value.$v = null;
                    return;
                }
                /*var*/ let ctx = this.ToManagedContext;
                /*var*/ let holder = ctx.CreateCSOwnedProxy(this.slot.JSHandle);
                value.$v = new ($.$spc.System.Action$$$$(T1, T2, T3))().$ctor(new ($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument.ActionJS$$$$(T1, T2, T3))().$ctor$1(holder, arg1Marshaler, arg2Marshaler, arg3Marshaler), new ($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument.ActionJS$$$$(T1, T2, T3))().$ctor$1(holder, arg1Marshaler, arg2Marshaler, arg3Marshaler).InvokeJS);
            }
            static $_FuncJS$$;
            static FuncJS$$(TResult)
            {
                let $cls = $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument;
                return ($cls.$_FuncJS$$ ??= $asm.$ncls("$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument.FuncJS<>", (TResult) => $asm.$gt("$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument.FuncJS<>", [TResult], ($self) => class FuncJS$$ extends $.$spc.System.Object
                {
                    /*JSObject*/ JSObject = null;
                    /*ArgumentToManagedCallback<TResult>*/ ResMarshaler = null;
                    $ctor$1(/*JSObject*/ holder, /*ArgumentToManagedCallback<TResult>*/ resMarshaler)
                    {
                        super.$ctor();
                        {
                            this.JSObject = holder;
                            this.ResMarshaler = resMarshaler;
                        }
                        return this;
                    }
                    /*TResult */ InvokeJS()
                    {
                        /*Span<JSMarshalerArgument>*/ let $arguments = $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.StackAllocSpan($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument, 2, null);
                        /*ref JSMarshalerArgument*/ let args_exception = $arguments.get_Item(0);
                        /*ref JSMarshalerArgument*/ let args_return = $arguments.get_Item(1);
                        args_exception.$v.Initialize();
                        args_return.$v.Initialize();
                        $.$srij.System.Runtime.InteropServices.JavaScript.JSFunctionBinding.InvokeJSFunction(this.JSObject, $arguments);
                        /*TResult*/ let res;
                        this.ResMarshaler.Invoke(args_return, $.$ref(() => res, ($v) => res = $v, TResult));
                        return res;
                    }
                    static $h = 2005757;
                    static $g = 1;
                    static $f = 0b10000000011010000;
                    static $k = 1;
                    static $$md;
                    static get $md() { return this.$$md ??= {"b":131073,"m":[{"r":TResult?.$h??1507328,"n":"InvokeJS","d":this.$h,"h":Number(BigInt(this.$h)|0x400000000n),"f":1}],"l":[{"t":2267901,"n":"JSObject","d":this.$h,"h":Number(BigInt(this.$h)|0x100000000n),"f":2},{"t":$.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument.ArgumentToManagedCallback$$(TResult).$h,"n":"ResMarshaler","d":this.$h,"h":Number(BigInt(this.$h)|0x200000000n),"f":2}],"c":[{"p":[{"n":"holder","p":2267901},{"n":"resMarshaler","p":$.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument.ArgumentToManagedCallback$$(TResult).$h}],"n":".ctor","o":"$ctor$1","d":this.$h,"h":Number(BigInt(this.$h)|0x300000000n),"f":1}],"g":[TResult?.$h??1507328],"r":1,"d":1350397,"h":this.$h}; }
                    static get $b() { return $.$spc.System.Object; }
                    static get $fullName() { return `System.Runtime.InteropServices.JavaScript.JSMarshalerArgument.FuncJS<${TResult?.$fullName}>`; }
                }), $cls, ($v) => $cls.$_FuncJS$$ = $v))(TResult);
            }
            static $_FuncJS$$$;
            static FuncJS$$$(T, TResult)
            {
                let $cls = $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument;
                return ($cls.$_FuncJS$$$ ??= $asm.$ncls("$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument.FuncJS<,>", (T, TResult) => $asm.$gt("$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument.FuncJS<,>", [T, TResult], ($self) => class FuncJS$$$ extends $.$spc.System.Object
                {
                    /*ArgumentToJSCallback<T>*/ Arg1Marshaler = null;
                    /*ArgumentToManagedCallback<TResult>*/ ResMarshaler = null;
                    /*JSObject*/ JSObject = null;
                    $ctor$1(/*JSObject*/ holder, /*ArgumentToJSCallback<T>*/ arg1Marshaler, /*ArgumentToManagedCallback<TResult>*/ resMarshaler)
                    {
                        super.$ctor();
                        {
                            this.JSObject = holder;
                            this.Arg1Marshaler = arg1Marshaler;
                            this.ResMarshaler = resMarshaler;
                        }
                        return this;
                    }
                    /*TResult */ InvokeJS(/*T*/ arg1)
                    {
                        /*Span<JSMarshalerArgument>*/ let $arguments = $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.StackAllocSpan($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument, 3, null);
                        /*ref JSMarshalerArgument*/ let args_exception = $arguments.get_Item(0);
                        /*ref JSMarshalerArgument*/ let args_return = $arguments.get_Item(1);
                        /*ref JSMarshalerArgument*/ let args_arg1 = $arguments.get_Item(2);
                        args_exception.$v.Initialize();
                        args_return.$v.Initialize();
                        this.Arg1Marshaler.Invoke(args_arg1, arg1);
                        $.$srij.System.Runtime.InteropServices.JavaScript.JSFunctionBinding.InvokeJSFunction(this.JSObject, $arguments);
                        /*TResult*/ let res;
                        this.ResMarshaler.Invoke(args_return, $.$ref(() => res, ($v) => res = $v, TResult));
                        return res;
                    }
                    static $h = 1940221;
                    static $g = 2;
                    static $f = 0b10000000011010000;
                    static $k = 1;
                    static $$md;
                    static get $md() { return this.$$md ??= {"b":131073,"m":[{"r":TResult?.$h??1572864,"p":[{"n":"arg1","p":T?.$h??1507328}],"n":"InvokeJS","d":this.$h,"h":Number(BigInt(this.$h)|0x500000000n),"f":1}],"l":[{"t":$.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument.ArgumentToJSCallback$$(T).$h,"n":"Arg1Marshaler","d":this.$h,"h":Number(BigInt(this.$h)|0x100000000n),"f":2},{"t":$.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument.ArgumentToManagedCallback$$(TResult).$h,"n":"ResMarshaler","d":this.$h,"h":Number(BigInt(this.$h)|0x200000000n),"f":2},{"t":2267901,"n":"JSObject","d":this.$h,"h":Number(BigInt(this.$h)|0x300000000n),"f":2}],"c":[{"p":[{"n":"holder","p":2267901},{"n":"arg1Marshaler","p":$.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument.ArgumentToJSCallback$$(T).$h},{"n":"resMarshaler","p":$.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument.ArgumentToManagedCallback$$(TResult).$h}],"n":".ctor","o":"$ctor$1","d":this.$h,"h":Number(BigInt(this.$h)|0x400000000n),"f":1}],"g":[T?.$h??1507328,TResult?.$h??1572864],"r":2,"d":1350397,"h":this.$h}; }
                    static get $b() { return $.$spc.System.Object; }
                    static get $fullName() { return `System.Runtime.InteropServices.JavaScript.JSMarshalerArgument.FuncJS<${T?.$fullName},${TResult?.$fullName}>`; }
                }), $cls, ($v) => $cls.$_FuncJS$$$ = $v))(T, TResult);
            }
            static $_FuncJS$$$$;
            static FuncJS$$$$(T1, T2, TResult)
            {
                let $cls = $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument;
                return ($cls.$_FuncJS$$$$ ??= $asm.$ncls("$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument.FuncJS<,,>", (T1, T2, TResult) => $asm.$gt("$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument.FuncJS<,,>", [T1, T2, TResult], ($self) => class FuncJS$$$$ extends $.$spc.System.Object
                {
                    /*ArgumentToJSCallback<T1>*/ Arg1Marshaler = null;
                    /*ArgumentToJSCallback<T2>*/ Arg2Marshaler = null;
                    /*ArgumentToManagedCallback<TResult>*/ ResMarshaler = null;
                    /*JSObject*/ JSObject = null;
                    $ctor$1(/*JSObject*/ holder, /*ArgumentToJSCallback<T1>*/ arg1Marshaler, /*ArgumentToJSCallback<T2>*/ arg2Marshaler, /*ArgumentToManagedCallback<TResult>*/ resMarshaler)
                    {
                        super.$ctor();
                        {
                            this.JSObject = holder;
                            this.Arg1Marshaler = arg1Marshaler;
                            this.Arg2Marshaler = arg2Marshaler;
                            this.ResMarshaler = resMarshaler;
                        }
                        return this;
                    }
                    /*TResult */ InvokeJS(/*T1*/ arg1, /*T2*/ arg2)
                    {
                        /*Span<JSMarshalerArgument>*/ let $arguments = $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.StackAllocSpan($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument, 4, null);
                        /*ref JSMarshalerArgument*/ let args_exception = $arguments.get_Item(0);
                        /*ref JSMarshalerArgument*/ let args_return = $arguments.get_Item(1);
                        /*ref JSMarshalerArgument*/ let args_arg1 = $arguments.get_Item(2);
                        /*ref JSMarshalerArgument*/ let args_arg2 = $arguments.get_Item(3);
                        args_exception.$v.Initialize();
                        args_return.$v.Initialize();
                        this.Arg1Marshaler.Invoke(args_arg1, arg1);
                        this.Arg2Marshaler.Invoke(args_arg2, arg2);
                        $.$srij.System.Runtime.InteropServices.JavaScript.JSFunctionBinding.InvokeJSFunction(this.JSObject, $arguments);
                        /*TResult*/ let res;
                        this.ResMarshaler.Invoke(args_return, $.$ref(() => res, ($v) => res = $v, TResult));
                        return res;
                    }
                    static $h = 1874685;
                    static $g = 3;
                    static $f = 0b10000000011010000;
                    static $k = 1;
                    static $$md;
                    static get $md() { return this.$$md ??= {"b":131073,"m":[{"r":TResult?.$h??1638400,"p":[{"n":"arg1","p":T1?.$h??1507328},{"n":"arg2","p":T2?.$h??1572864}],"n":"InvokeJS","d":this.$h,"h":Number(BigInt(this.$h)|0x600000000n),"f":1}],"l":[{"t":$.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument.ArgumentToJSCallback$$(T1).$h,"n":"Arg1Marshaler","d":this.$h,"h":Number(BigInt(this.$h)|0x100000000n),"f":2},{"t":$.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument.ArgumentToJSCallback$$(T2).$h,"n":"Arg2Marshaler","d":this.$h,"h":Number(BigInt(this.$h)|0x200000000n),"f":2},{"t":$.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument.ArgumentToManagedCallback$$(TResult).$h,"n":"ResMarshaler","d":this.$h,"h":Number(BigInt(this.$h)|0x300000000n),"f":2},{"t":2267901,"n":"JSObject","d":this.$h,"h":Number(BigInt(this.$h)|0x400000000n),"f":2}],"c":[{"p":[{"n":"holder","p":2267901},{"n":"arg1Marshaler","p":$.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument.ArgumentToJSCallback$$(T1).$h},{"n":"arg2Marshaler","p":$.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument.ArgumentToJSCallback$$(T2).$h},{"n":"resMarshaler","p":$.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument.ArgumentToManagedCallback$$(TResult).$h}],"n":".ctor","o":"$ctor$1","d":this.$h,"h":Number(BigInt(this.$h)|0x500000000n),"f":1}],"g":[T1?.$h??1507328,T2?.$h??1572864,TResult?.$h??1638400],"r":3,"d":1350397,"h":this.$h}; }
                    static get $b() { return $.$spc.System.Object; }
                    static get $fullName() { return `System.Runtime.InteropServices.JavaScript.JSMarshalerArgument.FuncJS<${T1?.$fullName},${T2?.$fullName},${TResult?.$fullName}>`; }
                }), $cls, ($v) => $cls.$_FuncJS$$$$ = $v))(T1, T2, TResult);
            }
            static $_FuncJS$$$$$;
            static FuncJS$$$$$(T1, T2, T3, TResult)
            {
                let $cls = $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument;
                return ($cls.$_FuncJS$$$$$ ??= $asm.$ncls("$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument.FuncJS<,,,>", (T1, T2, T3, TResult) => $asm.$gt("$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument.FuncJS<,,,>", [T1, T2, T3, TResult], ($self) => class FuncJS$$$$$ extends $.$spc.System.Object
                {
                    /*ArgumentToJSCallback<T1>*/ Arg1Marshaler = null;
                    /*ArgumentToJSCallback<T2>*/ Arg2Marshaler = null;
                    /*ArgumentToJSCallback<T3>*/ Arg3Marshaler = null;
                    /*ArgumentToManagedCallback<TResult>*/ ResMarshaler = null;
                    /*JSObject*/ JSObject = null;
                    $ctor$1(/*JSObject*/ holder, /*ArgumentToJSCallback<T1>*/ arg1Marshaler, /*ArgumentToJSCallback<T2>*/ arg2Marshaler, /*ArgumentToJSCallback<T3>*/ arg3Marshaler, /*ArgumentToManagedCallback<TResult>*/ resMarshaler)
                    {
                        super.$ctor();
                        {
                            this.JSObject = holder;
                            this.Arg1Marshaler = arg1Marshaler;
                            this.Arg2Marshaler = arg2Marshaler;
                            this.Arg3Marshaler = arg3Marshaler;
                            this.ResMarshaler = resMarshaler;
                        }
                        return this;
                    }
                    /*TResult */ InvokeJS(/*T1*/ arg1, /*T2*/ arg2, /*T3*/ arg3)
                    {
                        /*Span<JSMarshalerArgument>*/ let $arguments = $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.StackAllocSpan($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument, 5, null);
                        /*ref JSMarshalerArgument*/ let args_exception = $arguments.get_Item(0);
                        /*ref JSMarshalerArgument*/ let args_return = $arguments.get_Item(1);
                        /*ref JSMarshalerArgument*/ let args_arg1 = $arguments.get_Item(2);
                        /*ref JSMarshalerArgument*/ let args_arg2 = $arguments.get_Item(3);
                        /*ref JSMarshalerArgument*/ let args_arg3 = $arguments.get_Item(4);
                        args_exception.$v.Initialize();
                        args_return.$v.Initialize();
                        this.Arg1Marshaler.Invoke(args_arg1, arg1);
                        this.Arg2Marshaler.Invoke(args_arg2, arg2);
                        this.Arg3Marshaler.Invoke(args_arg3, arg3);
                        $.$srij.System.Runtime.InteropServices.JavaScript.JSFunctionBinding.InvokeJSFunction(this.JSObject, $arguments);
                        /*TResult*/ let res;
                        this.ResMarshaler.Invoke(args_return, $.$ref(() => res, ($v) => res = $v, TResult));
                        return res;
                    }
                    static $h = 1809149;
                    static $g = 4;
                    static $f = 0b10000000011010000;
                    static $k = 1;
                    static $$md;
                    static get $md() { return this.$$md ??= {"b":131073,"m":[{"r":TResult?.$h??1703936,"p":[{"n":"arg1","p":T1?.$h??1507328},{"n":"arg2","p":T2?.$h??1572864},{"n":"arg3","p":T3?.$h??1638400}],"n":"InvokeJS","d":this.$h,"h":Number(BigInt(this.$h)|0x700000000n),"f":1}],"l":[{"t":$.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument.ArgumentToJSCallback$$(T1).$h,"n":"Arg1Marshaler","d":this.$h,"h":Number(BigInt(this.$h)|0x100000000n),"f":2},{"t":$.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument.ArgumentToJSCallback$$(T2).$h,"n":"Arg2Marshaler","d":this.$h,"h":Number(BigInt(this.$h)|0x200000000n),"f":2},{"t":$.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument.ArgumentToJSCallback$$(T3).$h,"n":"Arg3Marshaler","d":this.$h,"h":Number(BigInt(this.$h)|0x300000000n),"f":2},{"t":$.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument.ArgumentToManagedCallback$$(TResult).$h,"n":"ResMarshaler","d":this.$h,"h":Number(BigInt(this.$h)|0x400000000n),"f":2},{"t":2267901,"n":"JSObject","d":this.$h,"h":Number(BigInt(this.$h)|0x500000000n),"f":2}],"c":[{"p":[{"n":"holder","p":2267901},{"n":"arg1Marshaler","p":$.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument.ArgumentToJSCallback$$(T1).$h},{"n":"arg2Marshaler","p":$.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument.ArgumentToJSCallback$$(T2).$h},{"n":"arg3Marshaler","p":$.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument.ArgumentToJSCallback$$(T3).$h},{"n":"resMarshaler","p":$.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument.ArgumentToManagedCallback$$(TResult).$h}],"n":".ctor","o":"$ctor$1","d":this.$h,"h":Number(BigInt(this.$h)|0x600000000n),"f":1}],"g":[T1?.$h??1507328,T2?.$h??1572864,T3?.$h??1638400,TResult?.$h??1703936],"r":4,"d":1350397,"h":this.$h}; }
                    static get $b() { return $.$spc.System.Object; }
                    static get $fullName() { return `System.Runtime.InteropServices.JavaScript.JSMarshalerArgument.FuncJS<${T1?.$fullName},${T2?.$fullName},${T3?.$fullName},${TResult?.$fullName}>`; }
                }), $cls, ($v) => $cls.$_FuncJS$$$$$ = $v))(T1, T2, T3, TResult);
            }
            /*void */ ToManaged$11(TResult, /*out Func<TResult>?*/ value, /*ArgumentToManagedCallback<TResult>*/ resMarshaler)
            {
                if (this.slot.Type === 0/*MarshalerType.None*/)
                {
                    value.$v = null;
                    return;
                }
                /*var*/ let ctx = this.ToManagedContext;
                /*var*/ let holder = ctx.CreateCSOwnedProxy(this.slot.JSHandle);
                value.$v = new ($.$spc.System.Func$$(TResult))().$ctor(new ($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument.FuncJS$$(TResult))().$ctor$1(holder, resMarshaler), new ($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument.FuncJS$$(TResult))().$ctor$1(holder, resMarshaler).InvokeJS);
            }
            /*void */ ToManaged$12(T, TResult, /*out Func<T, TResult>?*/ value, /*ArgumentToJSCallback<T>*/ arg1Marshaler, /*ArgumentToManagedCallback<TResult>*/ resMarshaler)
            {
                if (this.slot.Type === 0/*MarshalerType.None*/)
                {
                    value.$v = null;
                    return;
                }
                /*var*/ let ctx = this.ToManagedContext;
                /*var*/ let holder = ctx.CreateCSOwnedProxy(this.slot.JSHandle);
                value.$v = new ($.$spc.System.Func$$$(T, TResult))().$ctor(new ($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument.FuncJS$$$(T, TResult))().$ctor$1(holder, arg1Marshaler, resMarshaler), new ($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument.FuncJS$$$(T, TResult))().$ctor$1(holder, arg1Marshaler, resMarshaler).InvokeJS);
            }
            /*void */ ToManaged$13(T1, T2, TResult, /*out Func<T1, T2, TResult>?*/ value, /*ArgumentToJSCallback<T1>*/ arg1Marshaler, /*ArgumentToJSCallback<T2>*/ arg2Marshaler, /*ArgumentToManagedCallback<TResult>*/ resMarshaler)
            {
                if (this.slot.Type === 0/*MarshalerType.None*/)
                {
                    value.$v = null;
                    return;
                }
                /*var*/ let ctx = this.ToManagedContext;
                /*var*/ let holder = ctx.CreateCSOwnedProxy(this.slot.JSHandle);
                value.$v = new ($.$spc.System.Func$$$$(T1, T2, TResult))().$ctor(new ($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument.FuncJS$$$$(T1, T2, TResult))().$ctor$1(holder, arg1Marshaler, arg2Marshaler, resMarshaler), new ($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument.FuncJS$$$$(T1, T2, TResult))().$ctor$1(holder, arg1Marshaler, arg2Marshaler, resMarshaler).InvokeJS);
            }
            /*void */ ToManaged$14(T1, T2, T3, TResult, /*out Func<T1, T2, T3, TResult>?*/ value, /*ArgumentToJSCallback<T1>*/ arg1Marshaler, /*ArgumentToJSCallback<T2>*/ arg2Marshaler, /*ArgumentToJSCallback<T3>*/ arg3Marshaler, /*ArgumentToManagedCallback<TResult>*/ resMarshaler)
            {
                if (this.slot.Type === 0/*MarshalerType.None*/)
                {
                    value.$v = null;
                    return;
                }
                /*var*/ let ctx = this.ToManagedContext;
                /*var*/ let holder = ctx.CreateCSOwnedProxy(this.slot.JSHandle);
                value.$v = new ($.$spc.System.Func$$$$$(T1, T2, T3, TResult))().$ctor(new ($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument.FuncJS$$$$$(T1, T2, T3, TResult))().$ctor$1(holder, arg1Marshaler, arg2Marshaler, arg3Marshaler, resMarshaler), new ($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument.FuncJS$$$$$(T1, T2, T3, TResult))().$ctor$1(holder, arg1Marshaler, arg2Marshaler, arg3Marshaler, resMarshaler).InvokeJS);
            }
            /*void */ ToJS$7(/*Action*/ value)
            {
                /*Action*/ let cpy = value;
                /*JSHostImplementation.ToManagedCallback*/ let cb = new $.$srij.System.Runtime.InteropServices.JavaScript.JSHostImplementation.ToManagedCallback().$ctor(this,  (/*JSMarshalerArgument**/ $arguments) =>
                {
                    cpy.Invoke();
                });
                this.slot.Type = 25/*MarshalerType.Function*/;
                /*var*/ let ctx = this.ToJSContext;
                this.slot.GCHandle = ctx.GetJSOwnedObjectGCHandle(cb, 2);
            }
            /*void */ ToJS$8(T, /*Action<T>*/ value, /*ArgumentToManagedCallback<T>*/ arg1Marshaler)
            {
                /*Action<T>*/ let cpy = value;
                /*JSHostImplementation.ToManagedCallback*/ let cb = new $.$srij.System.Runtime.InteropServices.JavaScript.JSHostImplementation.ToManagedCallback().$ctor(this,  (/*JSMarshalerArgument**/ $arguments) =>
                {
                    /*ref JSMarshalerArgument*/ let arg2 = $arguments.Add(3);
                    /*T*/ let arg1cs;
                    arg1Marshaler.Invoke(arg2, $.$ref(() => arg1cs, ($v) => arg1cs = $v, T));
                    cpy.Invoke(arg1cs);
                });
                this.slot.Type = 24/*MarshalerType.Action*/;
                /*var*/ let ctx = this.ToJSContext;
                this.slot.GCHandle = ctx.GetJSOwnedObjectGCHandle(cb, 2);
            }
            /*void */ ToJS$9(T1, T2, /*Action<T1, T2>*/ value, /*ArgumentToManagedCallback<T1>*/ arg1Marshaler, /*ArgumentToManagedCallback<T2>*/ arg2Marshaler)
            {
                /*Action<T1, T2>*/ let cpy = value;
                /*JSHostImplementation.ToManagedCallback*/ let cb = new $.$srij.System.Runtime.InteropServices.JavaScript.JSHostImplementation.ToManagedCallback().$ctor(this,  (/*JSMarshalerArgument**/ $arguments) =>
                {
                    /*ref JSMarshalerArgument*/ let arg2 = $arguments.Add(3);
                    /*ref JSMarshalerArgument*/ let arg3 = $arguments.Add(4);
                    /*T1*/ let arg1cs;
                    arg1Marshaler.Invoke(arg2, $.$ref(() => arg1cs, ($v) => arg1cs = $v, T1));
                    /*T2*/ let arg2cs;
                    arg2Marshaler.Invoke(arg3, $.$ref(() => arg2cs, ($v) => arg2cs = $v, T2));
                    cpy.Invoke(arg1cs, arg2cs);
                });
                this.slot.Type = 24/*MarshalerType.Action*/;
                /*var*/ let ctx = this.ToJSContext;
                this.slot.GCHandle = ctx.GetJSOwnedObjectGCHandle(cb, 2);
            }
            /*void */ ToJS$10(T1, T2, T3, /*Action<T1, T2, T3>*/ value, /*ArgumentToManagedCallback<T1>*/ arg1Marshaler, /*ArgumentToManagedCallback<T2>*/ arg2Marshaler, /*ArgumentToManagedCallback<T3>*/ arg3Marshaler)
            {
                /*Action<T1, T2, T3>*/ let cpy = value;
                /*JSHostImplementation.ToManagedCallback*/ let cb = new $.$srij.System.Runtime.InteropServices.JavaScript.JSHostImplementation.ToManagedCallback().$ctor(this,  (/*JSMarshalerArgument**/ $arguments) =>
                {
                    /*ref JSMarshalerArgument*/ let arg2 = $arguments.Add(3);
                    /*ref JSMarshalerArgument*/ let arg3 = $arguments.Add(4);
                    /*ref JSMarshalerArgument*/ let arg4 = $arguments.Add(5);
                    /*T1*/ let arg1cs;
                    arg1Marshaler.Invoke(arg2, $.$ref(() => arg1cs, ($v) => arg1cs = $v, T1));
                    /*T2*/ let arg2cs;
                    arg2Marshaler.Invoke(arg3, $.$ref(() => arg2cs, ($v) => arg2cs = $v, T2));
                    /*T3*/ let arg3cs;
                    arg3Marshaler.Invoke(arg4, $.$ref(() => arg3cs, ($v) => arg3cs = $v, T3));
                    cpy.Invoke(arg1cs, arg2cs, arg3cs);
                });
                this.slot.Type = 24/*MarshalerType.Action*/;
                /*var*/ let ctx = this.ToJSContext;
                this.slot.GCHandle = ctx.GetJSOwnedObjectGCHandle(cb, 2);
            }
            /*void */ ToJS$11(TResult, /*Func<TResult>*/ value, /*ArgumentToJSCallback<TResult>*/ resMarshaler)
            {
                /*Func<TResult>*/ let cpy = value;
                /*JSHostImplementation.ToManagedCallback*/ let cb = new $.$srij.System.Runtime.InteropServices.JavaScript.JSHostImplementation.ToManagedCallback().$ctor(this,  (/*JSMarshalerArgument**/ $arguments) =>
                {
                    /*ref JSMarshalerArgument*/ let res = $arguments.Add(1);
                    /*TResult*/ let resCs = cpy.Invoke();
                    resMarshaler.Invoke(res, resCs);
                });
                this.slot.Type = 25/*MarshalerType.Function*/;
                /*var*/ let ctx = this.ToJSContext;
                this.slot.GCHandle = ctx.GetJSOwnedObjectGCHandle(cb, 2);
            }
            /*void */ ToJS$12(T, TResult, /*Func<T, TResult>*/ value, /*ArgumentToManagedCallback<T>*/ arg1Marshaler, /*ArgumentToJSCallback<TResult>*/ resMarshaler)
            {
                /*Func<T, TResult>*/ let cpy = value;
                /*JSHostImplementation.ToManagedCallback*/ let cb = new $.$srij.System.Runtime.InteropServices.JavaScript.JSHostImplementation.ToManagedCallback().$ctor(this,  (/*JSMarshalerArgument**/ $arguments) =>
                {
                    /*ref JSMarshalerArgument*/ let res = $arguments.Add(1);
                    /*ref JSMarshalerArgument*/ let arg2 = $arguments.Add(3);
                    /*T*/ let arg1cs;
                    arg1Marshaler.Invoke(arg2, $.$ref(() => arg1cs, ($v) => arg1cs = $v, T));
                    /*TResult*/ let resCs = cpy.Invoke(arg1cs);
                    resMarshaler.Invoke(res, resCs);
                });
                this.slot.Type = 25/*MarshalerType.Function*/;
                /*var*/ let ctx = this.ToJSContext;
                this.slot.GCHandle = ctx.GetJSOwnedObjectGCHandle(cb, 2);
            }
            /*void */ ToJS$13(T1, T2, TResult, /*Func<T1, T2, TResult>*/ value, /*ArgumentToManagedCallback<T1>*/ arg1Marshaler, /*ArgumentToManagedCallback<T2>*/ arg2Marshaler, /*ArgumentToJSCallback<TResult>*/ resMarshaler)
            {
                /*Func<T1, T2, TResult>*/ let cpy = value;
                /*JSHostImplementation.ToManagedCallback*/ let cb = new $.$srij.System.Runtime.InteropServices.JavaScript.JSHostImplementation.ToManagedCallback().$ctor(this,  (/*JSMarshalerArgument**/ $arguments) =>
                {
                    /*ref JSMarshalerArgument*/ let res = $arguments.Add(1);
                    /*ref JSMarshalerArgument*/ let arg2 = $arguments.Add(3);
                    /*ref JSMarshalerArgument*/ let arg3 = $arguments.Add(4);
                    /*T1*/ let arg1cs;
                    arg1Marshaler.Invoke(arg2, $.$ref(() => arg1cs, ($v) => arg1cs = $v, T1));
                    /*T2*/ let arg2cs;
                    arg2Marshaler.Invoke(arg3, $.$ref(() => arg2cs, ($v) => arg2cs = $v, T2));
                    /*TResult*/ let resCs = cpy.Invoke(arg1cs, arg2cs);
                    resMarshaler.Invoke(res, resCs);
                });
                this.slot.Type = 25/*MarshalerType.Function*/;
                /*var*/ let ctx = this.ToJSContext;
                this.slot.GCHandle = ctx.GetJSOwnedObjectGCHandle(cb, 2);
            }
            /*void */ ToJS$14(T1, T2, T3, TResult, /*Func<T1, T2, T3, TResult>*/ value, /*ArgumentToManagedCallback<T1>*/ arg1Marshaler, /*ArgumentToManagedCallback<T2>*/ arg2Marshaler, /*ArgumentToManagedCallback<T3>*/ arg3Marshaler, /*ArgumentToJSCallback<TResult>*/ resMarshaler)
            {
                /*Func<T1, T2, T3, TResult>*/ let cpy = value;
                /*JSHostImplementation.ToManagedCallback*/ let cb = new $.$srij.System.Runtime.InteropServices.JavaScript.JSHostImplementation.ToManagedCallback().$ctor(this,  (/*JSMarshalerArgument**/ $arguments) =>
                {
                    /*ref JSMarshalerArgument*/ let res = $arguments.Add(1);
                    /*ref JSMarshalerArgument*/ let arg2 = $arguments.Add(3);
                    /*ref JSMarshalerArgument*/ let arg3 = $arguments.Add(4);
                    /*ref JSMarshalerArgument*/ let arg4 = $arguments.Add(5);
                    /*T1*/ let arg1cs;
                    arg1Marshaler.Invoke(arg2, $.$ref(() => arg1cs, ($v) => arg1cs = $v, T1));
                    /*T2*/ let arg2cs;
                    arg2Marshaler.Invoke(arg3, $.$ref(() => arg2cs, ($v) => arg2cs = $v, T2));
                    /*T3*/ let arg3cs;
                    arg3Marshaler.Invoke(arg4, $.$ref(() => arg3cs, ($v) => arg3cs = $v, T3));
                    /*TResult*/ let resCs = cpy.Invoke(arg1cs, arg2cs, arg3cs);
                    resMarshaler.Invoke(res, resCs);
                });
                this.slot.Type = 25/*MarshalerType.Function*/;
                /*var*/ let ctx = this.ToJSContext;
                this.slot.GCHandle = ctx.GetJSOwnedObjectGCHandle(cb, 2);
            }
            /*void */ ToManaged$15(/*out float*/ value)
            {
                if (this.slot.Type === 0/*MarshalerType.None*/)
                {
                    value.$v = 0;
                    return;
                }
                value.$v = this.slot.SingleValue;
            }
            /*void */ ToJS$15(/*float*/ value)
            {
                this.slot.Type = 11/*MarshalerType.Single*/;
                this.slot.SingleValue = value;
            }
            /*void */ ToManaged$16(/*out float?*/ value)
            {
                if (this.slot.Type === 0/*MarshalerType.None*/)
                {
                    value.$v = null;
                    return;
                }
                value.$v = this.slot.SingleValue;
            }
            /*void */ ToJS$16(/*float?*/ value)
            {
                if ($.$spc.System.Nullable$$($.$spc.System.Single).HasValue$get.call(value))
                {
                    this.slot.Type = 11/*MarshalerType.Single*/;
                    this.slot.SingleValue = $.$spc.System.Nullable$$($.$spc.System.Single).Value$get.call(value);
                }
                else 
                {
                    this.slot.Type = 0/*MarshalerType.None*/;
                }
            }
            /*long*/ static I52_MAX_VALUE = 9007199254740991n;
            /*long*/ static I52_MIN_VALUE = -9007199254740991n;
            /*void */ ToManaged$17(/*out long*/ value)
            {
                if (this.slot.Type === 0/*MarshalerType.None*/)
                {
                    value.$v = 0n;
                    return;
                }
                value.$v = $.$cast(this.slot.DoubleValue, $.$spc.System.Int64);
            }
            /*void */ ToJS$17(/*long*/ value)
            {
                if (value < -9007199254740991n || value > 9007199254740991n)
                {
                    throw new $.$spc.System.OverflowException().$ctor$14($.$srij.System.SR.Format$2($.$srij.System.SR.ValueOutOf52BitRange, $.$box(value, $.$spc.System.Int64), $.$box(-9007199254740991n, $.$spc.System.Int64), $.$box(9007199254740991n, $.$spc.System.Int64)));
                }
                this.slot.Type = 8/*MarshalerType.Int52*/;
                this.slot.DoubleValue = Number(value);
            }
            /*void */ ToManaged$18(/*out long?*/ value)
            {
                if (this.slot.Type === 0/*MarshalerType.None*/)
                {
                    value.$v = null;
                    return;
                }
                value.$v = $.$cast(this.slot.DoubleValue, $.$spc.System.Int64);
            }
            /*void */ ToJS$18(/*long?*/ value)
            {
                if ($.$spc.System.Nullable$$($.$spc.System.Int64).HasValue$get.call(value))
                {
                    if ($.$spc.System.Nullable$$($.$spc.System.Int64).Value$get.call(value) < -9007199254740991n || $.$spc.System.Nullable$$($.$spc.System.Int64).Value$get.call(value) > 9007199254740991n)
                    {
                        throw new $.$spc.System.OverflowException().$ctor$14($.$srij.System.SR.Format$2($.$srij.System.SR.ValueOutOf52BitRange, $.$box(value, $.$spc.System.Nullable$$($.$spc.System.Int64)), $.$box(-9007199254740991n, $.$spc.System.Int64), $.$box(9007199254740991n, $.$spc.System.Int64)));
                    }
                    this.slot.Type = 8/*MarshalerType.Int52*/;
                    this.slot.DoubleValue = Number($.$spc.System.Nullable$$($.$spc.System.Int64).Value$get.call(value));
                }
                else 
                {
                    this.slot.Type = 0/*MarshalerType.None*/;
                }
            }
            /*void */ ToManaged$19(/*out short*/ value)
            {
                if (this.slot.Type === 0/*MarshalerType.None*/)
                {
                    value.$v = 0;
                    return;
                }
                value.$v = this.slot.Int16Value;
            }
            /*void */ ToJS$19(/*short*/ value)
            {
                this.slot.Type = 6/*MarshalerType.Int16*/;
                this.slot.Int16Value = value;
            }
            /*void */ ToManaged$20(/*out short?*/ value)
            {
                if (this.slot.Type === 0/*MarshalerType.None*/)
                {
                    value.$v = null;
                    return;
                }
                value.$v = this.slot.Int16Value;
            }
            /*void */ ToJS$20(/*short?*/ value)
            {
                if ($.$spc.System.Nullable$$($.$spc.System.Int16).HasValue$get.call(value))
                {
                    this.slot.Type = 6/*MarshalerType.Int16*/;
                    this.slot.Int16Value = $.$spc.System.Nullable$$($.$spc.System.Int16).Value$get.call(value);
                }
                else 
                {
                    this.slot.Type = 0/*MarshalerType.None*/;
                }
            }
            /*void */ ToManaged$21(/*out byte*/ value)
            {
                if (this.slot.Type === 0/*MarshalerType.None*/)
                {
                    value.$v = 0;
                    return;
                }
                value.$v = this.slot.ByteValue;
            }
            /*void */ ToJS$21(/*byte*/ value)
            {
                this.slot.Type = 4/*MarshalerType.Byte*/;
                this.slot.ByteValue = value;
            }
            /*void */ ToManaged$22(/*out byte?*/ value)
            {
                if (this.slot.Type === 0/*MarshalerType.None*/)
                {
                    value.$v = null;
                    return;
                }
                value.$v = this.slot.ByteValue;
            }
            /*void */ ToJS$22(/*byte?*/ value)
            {
                if ($.$spc.System.Nullable$$($.$spc.System.Byte).HasValue$get.call(value))
                {
                    this.slot.Type = 4/*MarshalerType.Byte*/;
                    this.slot.ByteValue = $.$spc.System.Nullable$$($.$spc.System.Byte).Value$get.call(value);
                }
                else 
                {
                    this.slot.Type = 0/*MarshalerType.None*/;
                }
            }
            /*void */ ToManaged$23(/*out byte[]?*/ value)
            {
                if (this.slot.Type === 0/*MarshalerType.None*/)
                {
                    value.$v = null;
                    return;
                }
                value.$v = $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$spc.System.Byte), null, [this.slot.Length], null);
                $.$spc.System.Runtime.InteropServices.Marshal.Copy$14(this.slot.IntPtrValue, value.$v, 0, this.slot.Length);
                $.$spc.System.Runtime.InteropServices.Marshal.FreeHGlobal(this.slot.IntPtrValue);
            }
            /*void */ ToJS$23(/*byte[]?*/ value)
            {
                if (value === null)
                {
                    this.slot.Type = 0/*MarshalerType.None*/;
                    return;
                }
                this.slot.Length = value.length;
                this.slot.Type = 21/*MarshalerType.Array*/;
                this.slot.IntPtrValue = $.$spc.System.Runtime.InteropServices.Marshal.AllocHGlobal(((value.length * $.$spc.System.Byte.$z) | 0));
                this.slot.ElementType = 4/*MarshalerType.Byte*/;
                $.$spc.System.Runtime.InteropServices.Marshal.Copy$6(value, 0, this.slot.IntPtrValue, this.slot.Length);
            }
            /*void */ ToManaged$24(/*out ArraySegment<byte>*/ value)
            {
                /*var*/ let array = $.$cast(($.$spc.System.Runtime.InteropServices.GCHandle.op_Explicit(this.slot.GCHandle)).Target, $.$typeArray($.$spc.System.Byte));
                /*var*/ let refPtr = $.$spc.System.IntPtr.op_Explicit$2($.$spc.System.Runtime.CompilerServices.Unsafe.AsPointer($.$spc.System.Byte, $.$spc.System.Runtime.InteropServices.MemoryMarshal.GetArrayDataReference($.$spc.System.Byte, array)));
                /*int*/ let byteOffset = (((this.slot.IntPtrValue - refPtr) | 0));
                value.$v = new ($.$spc.System.ArraySegment$$($.$spc.System.Byte))().$ctor$3(array, byteOffset, this.slot.Length);
            }
            /*void */ ToJS$24(/*ArraySegment<byte>*/ value)
            {
                if (value.Array === null)
                {
                    this.slot.Type = 0/*MarshalerType.None*/;
                    return;
                }
                this.slot.Type = 22/*MarshalerType.ArraySegment*/;
                /*var*/ let ctx = this.ToJSContext;
                this.slot.GCHandle = ctx.GetJSOwnedObjectGCHandle(value.Array, 3/*GCHandleType.Pinned*/);
                /*var*/ let refPtr = $.$spc.System.IntPtr.op_Explicit$2($.$spc.System.Runtime.CompilerServices.Unsafe.AsPointer($.$spc.System.Byte, $.$spc.System.Runtime.InteropServices.MemoryMarshal.GetArrayDataReference($.$spc.System.Byte, value.Array)));
                this.slot.IntPtrValue = ((refPtr + value.Offset) | 0);
                this.slot.Length = value.Count;
            }
            /*void */ ToManaged$25(/*out Span<byte>*/ value)
            {
                value.$v = new ($.$spc.System.Span$$($.$spc.System.Byte))().$ctor$4($.$spc.System.IntPtr.op_Explicit$3(this.slot.IntPtrValue), this.slot.Length);
            }
            /*void */ ToJS$25(/*Span<byte>*/ value)
            {
                this.slot.Length = value.Length;
                this.slot.IntPtrValue = $.$spc.System.IntPtr.op_Explicit$2($.$spc.System.Runtime.CompilerServices.Unsafe.AsPointer($.$spc.System.Byte, value.GetPinnableReference()));
                this.slot.Type = 23/*MarshalerType.Span*/;
            }
            /*void */ ToManaged$26(/*out bool*/ value)
            {
                if (this.slot.Type === 0/*MarshalerType.None*/)
                {
                    value.$v = false;
                    return;
                }
                value.$v = this.slot.BooleanValue;
            }
            /*void */ ToJS$26(/*bool*/ value)
            {
                this.slot.Type = 3/*MarshalerType.Boolean*/;
                this.slot.BooleanValue = value;
            }
            /*void */ ToManaged$27(/*out bool?*/ value)
            {
                if (this.slot.Type === 0/*MarshalerType.None*/)
                {
                    value.$v = null;
                    return;
                }
                value.$v = this.slot.BooleanValue;
            }
            /*void */ ToJS$27(/*bool?*/ value)
            {
                if ($.$spc.System.Nullable$$($.$spc.System.Boolean).HasValue$get.call(value))
                {
                    this.slot.Type = 3/*MarshalerType.Boolean*/;
                    this.slot.BooleanValue = $.$spc.System.Nullable$$($.$spc.System.Boolean).Value$get.call(value);
                }
                else 
                {
                    this.slot.Type = 0/*MarshalerType.None*/;
                }
            }
            static $_ArgumentToManagedCallback$$;
            static ArgumentToManagedCallback$$(T)
            {
                let $cls = $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument;
                return ($cls.$_ArgumentToManagedCallback$$ ??= $asm.$ncls("$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument.ArgumentToManagedCallback<>", (T) => $asm.$gt("$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument.ArgumentToManagedCallback<>", [T], ($self) => class ArgumentToManagedCallback$$ extends $.$spc.System.MulticastDelegate
                {
                    $ctor(/*object*/ target, fn)
                    {
                        this._target = target;
                        this.$nativeFunction = fn;
                        return this;
                    }
                    /*void*/ Invoke(/**/ $arg, /**/ $value)
                    {
                        return this.$nativeFunction.apply(this._target, arguments);
                    }
                    static $h = 1743613;
                    static $g = 1;
                    static $f = 0b10000000011000001;
                    static $k = 5;
                    static $$md;
                    static get $md() { return this.$$md ??= {"b":66191361,"m":[{"r":65537,"p":[{"n":"arg","p":1350397,"f":4},{"n":"value","p":T?.$h??1507328,"f":2}],"n":"Invoke","d":this.$h,"h":Number(BigInt(this.$h)|0x200000000n),"f":129},{"r":56950785,"p":[{"n":"arg","p":1350397,"f":4},{"n":"value","p":T?.$h??1507328,"f":2},{"n":"callback","p":14417921},{"n":"object","p":131073}],"n":"BeginInvoke","d":this.$h,"h":Number(BigInt(this.$h)|0x300000000n),"f":129},{"r":65537,"p":[{"n":"arg","p":1350397,"f":4},{"n":"value","p":T?.$h??1507328,"f":2},{"n":"result","p":56950785}],"n":"EndInvoke","d":this.$h,"h":Number(BigInt(this.$h)|0x400000000n),"f":129}],"c":[{"p":[{"n":"object","p":131073},{"n":"method","p":786433}],"n":".ctor","o":"$ctor$5","d":this.$h,"h":Number(BigInt(this.$h)|0x100000000n),"f":1}],"i":[57147393,113377281],"g":[T?.$h??1507328],"r":1,"d":1350397,"h":this.$h,"a":[{"t":33161217,"c":4328128513,"a":[{"v":1,"t":33226753}]}]}; }
                    static get $b() { return $.$spc.System.MulticastDelegate; }
                    static $$i;
                    static get $i() { return this.$$i ??= [ $.$spc.System.ICloneable, $.$spc.System.Runtime.Serialization.ISerializable ]; }
                    static get $fullName() { return `System.Runtime.InteropServices.JavaScript.JSMarshalerArgument.ArgumentToManagedCallback<${T?.$fullName}>`; }
                }), $cls, ($v) => $cls.$_ArgumentToManagedCallback$$ = $v))(T);
            }
            static $_ArgumentToJSCallback$$;
            static ArgumentToJSCallback$$(T)
            {
                let $cls = $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument;
                return ($cls.$_ArgumentToJSCallback$$ ??= $asm.$ncls("$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument.ArgumentToJSCallback<>", (T) => $asm.$gt("$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument.ArgumentToJSCallback<>", [T], ($self) => class ArgumentToJSCallback$$ extends $.$spc.System.MulticastDelegate
                {
                    $ctor(/*object*/ target, fn)
                    {
                        this._target = target;
                        this.$nativeFunction = fn;
                        return this;
                    }
                    /*void*/ Invoke(/**/ $arg, /**/ $value)
                    {
                        return this.$nativeFunction.apply(this._target, arguments);
                    }
                    static $h = 1678077;
                    static $g = 1;
                    static $f = 0b10000000011000001;
                    static $k = 5;
                    static $$md;
                    static get $md() { return this.$$md ??= {"b":66191361,"m":[{"r":65537,"p":[{"n":"arg","p":1350397,"f":4},{"n":"value","p":T?.$h??1507328}],"n":"Invoke","d":this.$h,"h":Number(BigInt(this.$h)|0x200000000n),"f":129},{"r":56950785,"p":[{"n":"arg","p":1350397,"f":4},{"n":"value","p":T?.$h??1507328},{"n":"callback","p":14417921},{"n":"object","p":131073}],"n":"BeginInvoke","d":this.$h,"h":Number(BigInt(this.$h)|0x300000000n),"f":129},{"r":65537,"p":[{"n":"arg","p":1350397,"f":4},{"n":"result","p":56950785}],"n":"EndInvoke","d":this.$h,"h":Number(BigInt(this.$h)|0x400000000n),"f":129}],"c":[{"p":[{"n":"object","p":131073},{"n":"method","p":786433}],"n":".ctor","o":"$ctor$5","d":this.$h,"h":Number(BigInt(this.$h)|0x100000000n),"f":1}],"i":[57147393,113377281],"g":[T?.$h??1507328],"r":1,"d":1350397,"h":this.$h,"a":[{"t":33161217,"c":4328128513,"a":[{"v":1,"t":33226753}]}]}; }
                    static get $b() { return $.$spc.System.MulticastDelegate; }
                    static $$i;
                    static get $i() { return this.$$i ??= [ $.$spc.System.ICloneable, $.$spc.System.Runtime.Serialization.ISerializable ]; }
                    static get $fullName() { return `System.Runtime.InteropServices.JavaScript.JSMarshalerArgument.ArgumentToJSCallback<${T?.$fullName}>`; }
                }), $cls, ($v) => $cls.$_ArgumentToJSCallback$$ = $v))(T);
            }
            /*void */ ToManaged$28(/*out Task?*/ value)
            {
                if (this.slot.Type === 0/*MarshalerType.None*/)
                {
                    value.$v = null;
                    return;
                }
                /*var*/ let ctx = this.ToManagedContext;
                {
                    /*PromiseHolder*/ let holder = ctx.GetPromiseHolder(this.slot.GCHandle);
                    /*TaskCompletionSource*/ let tcs = new $.$spc.System.Threading.Tasks.TaskCompletionSource().$ctor$4(holder, 64/*TaskCreationOptions.RunContinuationsAsynchronously*/);
                    /*ToManagedCallback*/ let callback = new $.$srij.System.Runtime.InteropServices.JavaScript.JSHostImplementation.ToManagedCallback().$ctor(this,  (/*JSMarshalerArgument**/ arguments_buffer) =>
                    {
                        if (arguments_buffer === null)
                        {
                            if (!tcs.TrySetException(new $.$spc.System.Threading.Tasks.TaskCanceledException().$ctor$17("WebWorker which is origin of the Promise is being terminated.")))
                            {
                                $.$spc.System.Environment.FailFast("Failed to set exception to TaskCompletionSource (arguments buffer is null)");
                            }
                            return;
                        }
                        /*ref JSMarshalerArgument*/ let arg_2 = arguments_buffer.Add(3);
                        if (arg_2.$v.slot.Type !== 0/*MarshalerType.None*/)
                        {
                            /*Exception?*/ let fail;
                            arg_2.$v.ToManaged$48($.$ref(() => fail, ($v) => fail = $v, $.$spc.System.Exception));
                            if (!tcs.TrySetException(fail))
                            {
                                $.$spc.System.Environment.FailFast("Failed to set exception to TaskCompletionSource (exception raised)");
                            }
                        }
                        else 
                        {
                            if (!tcs.TrySetResult())
                            {
                                $.$spc.System.Environment.FailFast("Failed to set result to TaskCompletionSource (marshaler type is none)");
                            }
                        }
                    });
                    holder.Callback = callback;
                    value.$v = tcs.Task;
                }
            }
            /*void */ ToManaged$29(T, /*out Task<T>?*/ value, /*ArgumentToManagedCallback<T>*/ marshaler)
            {
                if (this.slot.Type === 0/*MarshalerType.None*/)
                {
                    value.$v = null;
                    return;
                }
                /*var*/ let ctx = this.ToManagedContext;
                {
                    /*var*/ let holder = ctx.GetPromiseHolder(this.slot.GCHandle);
                    /*TaskCompletionSource<T>*/ let tcs = new ($.$spc.System.Threading.Tasks.TaskCompletionSource$$(T))().$ctor$4(holder, 64/*TaskCreationOptions.RunContinuationsAsynchronously*/);
                    /*ToManagedCallback*/ let callback = new $.$srij.System.Runtime.InteropServices.JavaScript.JSHostImplementation.ToManagedCallback().$ctor(this,  (/*JSMarshalerArgument**/ arguments_buffer) =>
                    {
                        if (arguments_buffer === null)
                        {
                            if (!tcs.TrySetException(new $.$spc.System.Threading.Tasks.TaskCanceledException().$ctor$17("WebWorker which is origin of the Promise is being terminated.")))
                            {
                                $.$spc.System.Environment.FailFast("Failed to set exception to TaskCompletionSource (arguments buffer is null)");
                            }
                            return;
                        }
                        /*ref JSMarshalerArgument*/ let arg_2 = arguments_buffer.Add(3);
                        /*ref JSMarshalerArgument*/ let arg_3 = arguments_buffer.Add(4);
                        if (arg_2.$v.slot.Type !== 0/*MarshalerType.None*/)
                        {
                            /*Exception?*/ let fail;
                            arg_2.$v.ToManaged$48($.$ref(() => fail, ($v) => fail = $v, $.$spc.System.Exception));
                            if (fail === null)
                            {
                                throw new $.$spc.System.InvalidOperationException().$ctor$10($.$srij.System.SR.FailedToMarshalException);
                            }
                            if (!tcs.TrySetException(fail))
                            {
                                $.$spc.System.Environment.FailFast("Failed to set exception to TaskCompletionSource (exception raised)");
                            }
                        }
                        else 
                        {
                            /*T*/ let result;
                            marshaler.Invoke(arg_3, $.$ref(() => result, ($v) => result = $v, T));
                            if (!tcs.TrySetResult(result))
                            {
                                $.$spc.System.Environment.FailFast("Failed to set result to TaskCompletionSource (marshaler type is none)");
                            }
                        }
                    });
                    holder.Callback = callback;
                    value.$v = tcs.Task;
                }
            }
            /*void */ ToJSDynamic(/*Task?*/ value)
            {
                /*Task?*/ let task = value;
                /*var*/ let ctx = this.ToJSContext;
                /*var*/ let canMarshalTaskResultOnSameCall = this.CanMarshalTaskResultOnSameCall(ctx);
                if (task === null)
                {
                    if (!canMarshalTaskResultOnSameCall)
                    {
                        $.$spc.System.Environment.FailFast("Marshalling null return Task to JS is not supported in MT");
                    }
                    this.slot.Type = 0/*MarshalerType.None*/;
                    return;
                }
                if (canMarshalTaskResultOnSameCall && task.IsCompleted)
                {
                    if (task.Exception !== null)
                    {
                        /*Exception*/ let ex = task.Exception;
                        this.ToJS$48(ex);
                        this.slot.ElementType = this.slot.Type;
                        this.slot.Type = 29/*MarshalerType.TaskRejected*/;
                        return;
                    }
                    else 
                    {
                        /*object?*/ let result;
                        if ($.$srij.System.Runtime.InteropServices.JavaScript.JSHostImplementation.GetTaskResultDynamic(task, $.$ref(() => result, ($v) => result = $v, $.$spc.System.Object)))
                        {
                            this.ToJS$37(result);
                            this.slot.ElementType = this.slot.Type;
                        }
                        else 
                        {
                            this.slot.ElementType = 1/*MarshalerType.Void*/;
                        }
                        this.slot.Type = 28/*MarshalerType.TaskResolved*/;
                        return;
                    }
                }
                if (this.slot.Type !== 30/*MarshalerType.TaskPreCreated*/)
                {
                    this.slot.JSHandle = ctx.AllocJSVHandle();
                    this.slot.Type = 20/*MarshalerType.Task*/;
                }
                else 
                {
                }
                /*var*/ let taskHolder = ctx.CreateCSOwnedProxy(this.slot.JSHandle);
                task.ContinueWith$8(new ($.$spc.System.Action$$$($.$spc.System.Threading.Tasks.Task, $.$spc.System.Object))().$ctor(null, Complete), taskHolder, $.$spc.System.Threading.Tasks.TaskScheduler.Current);
                /*static void*/  function Complete(/*Task*/ task, /*object?*/ th)
                {
                    /*var*/ let taskHolderArg = $.$cast(th, $.$srij.System.Runtime.InteropServices.JavaScript.JSObject);
                    if (task.Exception !== null)
                    {
                        $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument.RejectPromise(taskHolderArg, task.Exception);
                    }
                    else 
                    {
                        /*object?*/ let result;
                        if ($.$srij.System.Runtime.InteropServices.JavaScript.JSHostImplementation.GetTaskResultDynamic(task, $.$ref(() => result, ($v) => result = $v, $.$spc.System.Object)))
                        {
                            $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument.ResolvePromise($.$spc.System.Object, taskHolderArg, result, new ($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument.ArgumentToJSCallback$$($.$spc.System.Object))().$ctor(null, MarshalResult));
                        }
                        else 
                        {
                            $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument.ResolveVoidPromise(taskHolderArg);
                        }
                    }
                }
                /*static void*/  function MarshalResult(/*ref JSMarshalerArgument*/ arg, /*object?*/ taskResult)
                {
                    arg.$v.ToJS$37(taskResult);
                }
            }
            /*void */ ToJS$28(/*Task?*/ value)
            {
                /*Task?*/ let task = value;
                /*var*/ let ctx = this.ToJSContext;
                /*var*/ let canMarshalTaskResultOnSameCall = this.CanMarshalTaskResultOnSameCall(ctx);
                if (task === null)
                {
                    if (!canMarshalTaskResultOnSameCall)
                    {
                        $.$spc.System.Environment.FailFast("Marshalling null return Task to JS is not supported in MT");
                    }
                    this.slot.Type = 0/*MarshalerType.None*/;
                    return;
                }
                if (canMarshalTaskResultOnSameCall && task.IsCompleted)
                {
                    if (task.Exception !== null)
                    {
                        /*Exception*/ let ex = task.Exception;
                        this.ToJS$48(ex);
                        this.slot.ElementType = this.slot.Type;
                        this.slot.Type = 29/*MarshalerType.TaskRejected*/;
                        return;
                    }
                    else 
                    {
                        this.slot.ElementType = 1/*MarshalerType.Void*/;
                        this.slot.Type = 28/*MarshalerType.TaskResolved*/;
                        return;
                    }
                }
                if (this.slot.Type !== 30/*MarshalerType.TaskPreCreated*/)
                {
                    this.slot.JSHandle = ctx.AllocJSVHandle();
                    this.slot.Type = 20/*MarshalerType.Task*/;
                }
                else 
                {
                }
                /*var*/ let taskHolder = ctx.CreateCSOwnedProxy(this.slot.JSHandle);
                task.ContinueWith$8(new ($.$spc.System.Action$$$($.$spc.System.Threading.Tasks.Task, $.$spc.System.Object))().$ctor(null, Complete), taskHolder, $.$spc.System.Threading.Tasks.TaskScheduler.Current);
                /*static void*/  function Complete(/*Task*/ task, /*object?*/ th)
                {
                    /*JSObject*/ let taskHolderArg = $.$cast(th, $.$srij.System.Runtime.InteropServices.JavaScript.JSObject);
                    if (task.Exception !== null)
                    {
                        $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument.RejectPromise(taskHolderArg, task.Exception);
                    }
                    else 
                    {
                        $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument.ResolveVoidPromise(taskHolderArg);
                    }
                }
            }
            /*void */ ToJS$29(T, /*Task<T>?*/ value, /*ArgumentToJSCallback<T>*/ marshaler)
            {
                /*Task<T>?*/ let task = value;
                /*var*/ let ctx = this.ToJSContext;
                /*var*/ let canMarshalTaskResultOnSameCall = this.CanMarshalTaskResultOnSameCall(ctx);
                if (task === null)
                {
                    if (!canMarshalTaskResultOnSameCall)
                    {
                        $.$spc.System.Environment.FailFast("Marshalling null return Task to JS is not supported in MT");
                    }
                    this.slot.Type = 0/*MarshalerType.None*/;
                    return;
                }
                if (canMarshalTaskResultOnSameCall && task.IsCompleted)
                {
                    if (task.Exception !== null)
                    {
                        /*Exception*/ let ex = task.Exception;
                        this.ToJS$48(ex);
                        this.slot.ElementType = this.slot.Type;
                        this.slot.Type = 29/*MarshalerType.TaskRejected*/;
                        return;
                    }
                    else 
                    {
                        /*T*/ let result = task.Result;
                        this.ToJS$37($.$box(result, T));
                        this.slot.ElementType = this.slot.Type;
                        this.slot.Type = 28/*MarshalerType.TaskResolved*/;
                        return;
                    }
                }
                if (this.slot.Type !== 30/*MarshalerType.TaskPreCreated*/)
                {
                    this.slot.JSHandle = ctx.AllocJSVHandle();
                    this.slot.Type = 20/*MarshalerType.Task*/;
                }
                else 
                {
                }
                /*var*/ let taskHolder = ctx.CreateCSOwnedProxy(this.slot.JSHandle);
                task.ContinueWith$32(new ($.$spc.System.Action$$$($.$spc.System.Threading.Tasks.Task$$(T), $.$spc.System.Object))().$ctor(null, Complete), new ($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument.HolderAndMarshaler$$(T))().$ctor$1(taskHolder, marshaler), $.$spc.System.Threading.Tasks.TaskScheduler.Current);
                /*static void*/  function Complete(/*Task<T>*/ task, /*object?*/ thm)
                {
                    /*var*/ let hm = $.$cast(thm, $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument.HolderAndMarshaler$$(T));
                    if (task.Exception !== null)
                    {
                        $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument.RejectPromise(hm.TaskHolder, task.Exception);
                    }
                    else 
                    {
                        /*T*/ let result = task.Result;
                        $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument.ResolvePromise(T, hm.TaskHolder, result, hm.Marshaler);
                    }
                }
            }
            /*bool */ CanMarshalTaskResultOnSameCall(/*JSProxyContext*/ _)
            {
                return true;
            }
            static $_HolderAndMarshaler$$;
            static HolderAndMarshaler$$(T)
            {
                let $cls = $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument;
                return ($cls.$_HolderAndMarshaler$$ ??= $asm.$ncls("$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument.HolderAndMarshaler<>", (T) => $asm.$gt("$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument.HolderAndMarshaler<>", [T], ($self) => class HolderAndMarshaler$$ extends $.$spc.System.Object
                {
                    //Generated interface implemetation for System.IEquatable<System.Runtime.InteropServices.JavaScript.JSMarshalerArgument.HolderAndMarshaler<T>>.Equals(System.Runtime.InteropServices.JavaScript.JSMarshalerArgument.HolderAndMarshaler<T>?)
                    System$IEquatable$$$Equals()
                    {
                        return this.Equals$2(...arguments);
                    }
                    Clone($copy)
                    {
                        let copy = $copy ?? new this.constructor();
                        copy.TaskHolder = this.TaskHolder;
                        copy.Marshaler = this.Marshaler;
                        return copy;
                    }
                    //Begin primary constructor
                    /*JSObject*/ TaskHolder = null;
                    /*ArgumentToJSCallback<T>*/ Marshaler = null;
                    $ctor$1(/*JSObject*/$TaskHolder, /*ArgumentToJSCallback<T>*/$Marshaler)
                    {
                        this.TaskHolder = $TaskHolder;
                        this.Marshaler = $Marshaler;
                        return this
                    }
                    //End primary constructor
                    //Begin generated record members
                    /*Type*/ get EqualityContract() { return $.$typeOf($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument.HolderAndMarshaler$$(T)); }
                    /*string*/ ToString()
                    {
                        let stringBuilder = new $.$spc.System.Text.StringBuilder().$ctor$1();
                        stringBuilder.Append$2("HolderAndMarshaler");
                        stringBuilder.Append$2("{");
                        if (this.PrintMembers(stringBuilder))
                        {
                            stringBuilder.Append$2(" ");
                        }
                        stringBuilder.Append$2("}");
                        return $.$spc.System.Text.StringBuilder.ToString.call(stringBuilder);
                    }
                    /*bool*/ PrintMembers(/*StringBuilder*/ stringBuilder)
                    {
                        stringBuilder.Append$2("TaskHolder = ");
                        stringBuilder.Append$2($.$srij.System.Runtime.InteropServices.JavaScript.JSObject.ToString.call(this.TaskHolder));
                        stringBuilder.Append$2(", ");
                        stringBuilder.Append$2("Marshaler = ");
                        stringBuilder.Append$2($.$spc.System.Object.ToString.call(this.Marshaler));
                        return true;
                    }
                    /*bool*/ Equals$2(/*HolderAndMarshaler*/ other)
                    {
                        return this === other || (other !== null && this.EqualityContract == other.EqualityContract && $.$spc.System.Collections.Generic.EqualityComparer$$($.$srij.System.Runtime.InteropServices.JavaScript.JSObject).Default.Equals$2(this.TaskHolder, other.TaskHolder) && $.$spc.System.Collections.Generic.EqualityComparer$$($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument.ArgumentToJSCallback$$(T)).Default.Equals$2(this.Marshaler, other.Marshaler));
                    }
                    /*int*/ GetHashCode()
                    {
                        return $.$spc.System.Collections.Generic.EqualityComparer$$($.$spc.System.Type).Default.GetHashCode$1(this.EqualityContract) * -1521134295 && $.$spc.System.Collections.Generic.EqualityComparer$$($.$srij.System.Runtime.InteropServices.JavaScript.JSObject).Default.GetHashCode$1(this.TaskHolder) * -1521134295 && $.$spc.System.Collections.Generic.EqualityComparer$$($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument.ArgumentToJSCallback$$(T)).Default.GetHashCode$1(this.Marshaler) * -1521134295;
                    }
                    static /*bool*/ op_InEquality(/*HolderAndMarshaler*/ left, /*HolderAndMarshaler*/ right)
                    {
                        return !(this.op_Equals(left, right));
                    }
                    static /*bool*/ op_Equality(/*HolderAndMarshaler*/ left, /*HolderAndMarshaler*/ right)
                    {
                        return left === right || (left !== null && left.Equals$2(right));
                    }
                    Deconstruct(/*out System.Runtime.InteropServices.JavaScript.JSObject*/ $TaskHolder, /*out System.Runtime.InteropServices.JavaScript.JSMarshalerArgument.ArgumentToJSCallback<T>*/ $Marshaler)
                    {
                        $TaskHolder.$v = this.TaskHolder;
                        $Marshaler.$v = this.Marshaler;
                    }
                    //End generated record member3s
                    static $h = 2071293;
                    static $g = 1;
                    static $f = 0b10000000011010000;
                    static $k = 1;
                    static $$md;
                    static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":142606337,"g":{"r":0,"d":0,"h":Number(BigInt(this.$h)|0x200000000n),"f":2},"n":"EqualityContract","d":this.$h,"h":Number(BigInt(this.$h)|0x300000000n),"f":2},{"p":2267901,"g":{"r":0,"d":0,"h":Number(BigInt(this.$h)|0x500000000n),"f":1},"s":{"r":0,"d":0,"h":Number(BigInt(this.$h)|0x600000000n),"f":1},"n":"TaskHolder","d":this.$h,"h":Number(BigInt(this.$h)|0x700000000n),"f":1},{"p":$.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument.ArgumentToJSCallback$$(T).$h,"g":{"r":0,"d":0,"h":Number(BigInt(this.$h)|0x900000000n),"f":1},"s":{"r":0,"d":0,"h":Number(BigInt(this.$h)|0xA00000000n),"f":1},"n":"Marshaler","d":this.$h,"h":Number(BigInt(this.$h)|0xB00000000n),"f":1}],"m":[{"r":1310721,"n":"ToString","d":this.$h,"h":Number(BigInt(this.$h)|0xC00000000n),"f":32769},{"r":262145,"p":[{"n":"builder","p":122945537}],"n":"PrintMembers","d":this.$h,"h":Number(BigInt(this.$h)|0xD00000000n),"f":2},{"r":655361,"n":"GetHashCode","d":this.$h,"h":Number(BigInt(this.$h)|0x1000000000n),"f":32769},{"r":262145,"p":[{"n":"obj","p":131073}],"n":"Equals","d":this.$h,"h":Number(BigInt(this.$h)|0x1100000000n),"f":32769},{"r":262145,"p":[{"n":"other","p":this.$h}],"n":"Equals","o":"@$2","d":this.$h,"h":Number(BigInt(this.$h)|0x1200000000n),"f":1},{"r":this.$h,"n":"\u003CClone\u003E$","o":"$$$","d":this.$h,"h":Number(BigInt(this.$h)|0x1300000000n),"f":1},{"r":65537,"p":[{"n":"TaskHolder","p":2267901,"f":2},{"n":"Marshaler","p":$.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument.ArgumentToJSCallback$$(T).$h,"f":2}],"n":"Deconstruct","d":this.$h,"h":Number(BigInt(this.$h)|0x1500000000n),"f":1}],"c":[{"p":[{"n":"TaskHolder","p":2267901},{"n":"Marshaler","p":$.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument.ArgumentToJSCallback$$(T).$h}],"n":".ctor","o":"$ctor$1","d":this.$h,"h":Number(BigInt(this.$h)|0x100000000n),"f":1},{"p":[{"n":"original","p":this.$h}],"n":".ctor","o":"$ctor$2","d":this.$h,"h":Number(BigInt(this.$h)|0x1400000000n),"f":2}],"i":[$.$spc.System.IEquatable$$($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument.HolderAndMarshaler$$(T)).$h],"g":[T?.$h??1507328],"r":1,"d":1350397,"h":this.$h}; }
                    static get $b() { return $.$spc.System.Object; }
                    static $$i;
                    static get $i() { return this.$$i ??= [ $.$spc.System.IEquatable$$($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument.HolderAndMarshaler$$(T)) ]; }
                    static get $fullName() { return `System.Runtime.InteropServices.JavaScript.JSMarshalerArgument.HolderAndMarshaler<${T?.$fullName}>`; }
                }), $cls, ($v) => $cls.$_HolderAndMarshaler$$ = $v))(T);
            }
            static /*void */ RejectPromise(/*JSObject*/ holder, /*Exception*/ ex)
            {
                holder.AssertNotDisposed();
                /*Span<JSMarshalerArgument>*/ let args = $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.StackAllocSpan($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument, 4, null);
                /*ref JSMarshalerArgument*/ let exc = args.get_Item(0);
                /*ref JSMarshalerArgument*/ let res = args.get_Item(1);
                /*ref JSMarshalerArgument*/ let arg_handle = args.get_Item(2);
                /*ref JSMarshalerArgument*/ let arg_value = args.get_Item(3);
                exc.$v.Initialize();
                res.$v.Initialize();
                arg_handle.$v.slot.Type = 29/*MarshalerType.TaskRejected*/;
                arg_handle.$v.slot.JSHandle = holder.JSHandle;
                arg_value.$v.ToJS$48(ex);
                holder.DisposeImpl(true);
                $.$srij.System.Runtime.InteropServices.JavaScript.JSFunctionBinding.ResolveOrRejectPromise(holder.ProxyContext, args);
            }
            static /*void */ ResolveVoidPromise(/*JSObject*/ holder)
            {
                holder.AssertNotDisposed();
                /*Span<JSMarshalerArgument>*/ let args = $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.StackAllocSpan($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument, 4, null);
                /*ref JSMarshalerArgument*/ let exc = args.get_Item(0);
                /*ref JSMarshalerArgument*/ let res = args.get_Item(1);
                /*ref JSMarshalerArgument*/ let arg_handle = args.get_Item(2);
                /*ref JSMarshalerArgument*/ let arg_value = args.get_Item(3);
                exc.$v.Initialize();
                res.$v.Initialize();
                arg_handle.$v.slot.Type = 28/*MarshalerType.TaskResolved*/;
                arg_handle.$v.slot.JSHandle = holder.JSHandle;
                arg_value.$v.slot.Type = 1/*MarshalerType.Void*/;
                holder.DisposeImpl(true);
                $.$srij.System.Runtime.InteropServices.JavaScript.JSFunctionBinding.ResolveOrRejectPromise(holder.ProxyContext, args);
            }
            static /*void */ ResolvePromise(T, /*JSObject*/ holder, /*T*/ value, /*ArgumentToJSCallback<T>*/ marshaler)
            {
                holder.AssertNotDisposed();
                /*Span<JSMarshalerArgument>*/ let args = $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.StackAllocSpan($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument, 4, null);
                /*ref JSMarshalerArgument*/ let exc = args.get_Item(0);
                /*ref JSMarshalerArgument*/ let res = args.get_Item(1);
                /*ref JSMarshalerArgument*/ let arg_handle = args.get_Item(2);
                /*ref JSMarshalerArgument*/ let arg_value = args.get_Item(3);
                exc.$v.Initialize();
                res.$v.Initialize();
                arg_handle.$v.slot.Type = 28/*MarshalerType.TaskResolved*/;
                arg_handle.$v.slot.JSHandle = holder.JSHandle;
                marshaler.Invoke(arg_value, value);
                holder.DisposeImpl(true);
                $.$srij.System.Runtime.InteropServices.JavaScript.JSFunctionBinding.ResolveOrRejectPromise(holder.ProxyContext, args);
            }
            /*void */ ToManaged$30(/*out DateTimeOffset*/ value)
            {
                if (this.slot.Type === 0/*MarshalerType.None*/)
                {
                    value.$v = new $.$spc.System.DateTimeOffset();
                    return;
                }
                value.$v = $.$spc.System.DateTimeOffset.FromUnixTimeMilliseconds($.$cast(this.slot.DoubleValue, $.$spc.System.Int64));
            }
            /*void */ ToJS$30(/*DateTimeOffset*/ value)
            {
                this.slot.Type = 18/*MarshalerType.DateTimeOffset*/;
                this.slot.DoubleValue = $.$cast(value.ToUnixTimeMilliseconds(), $.$spc.System.Double);
            }
            /*void */ ToManaged$31(/*out DateTimeOffset?*/ value)
            {
                if (this.slot.Type === 0/*MarshalerType.None*/)
                {
                    value.$v = null;
                    return;
                }
                value.$v = $.$spc.System.DateTimeOffset.FromUnixTimeMilliseconds($.$cast(this.slot.DoubleValue, $.$spc.System.Int64));
            }
            /*void */ ToJS$31(/*DateTimeOffset?*/ value)
            {
                if ($.$spc.System.Nullable$$($.$spc.System.DateTimeOffset).HasValue$get.call(value))
                {
                    this.slot.Type = 18/*MarshalerType.DateTimeOffset*/;
                    this.slot.DoubleValue = Number($.$spc.System.Nullable$$($.$spc.System.DateTimeOffset).Value$get.call(value).ToUnixTimeMilliseconds());
                }
                else 
                {
                    this.slot.Type = 0/*MarshalerType.None*/;
                }
            }
            /*void */ ToManaged$32(/*out DateTime*/ value)
            {
                if (this.slot.Type === 0/*MarshalerType.None*/)
                {
                    value.$v = new $.$spc.System.DateTime();
                    return;
                }
                value.$v = $.$spc.System.DateTimeOffset.FromUnixTimeMilliseconds($.$cast(this.slot.DoubleValue, $.$spc.System.Int64)).UtcDateTime;
            }
            /*void */ ToJS$32(/*DateTime*/ value)
            {
                this.slot.Type = 17/*MarshalerType.DateTime*/;
                this.slot.DoubleValue = Number(new $.$spc.System.DateTimeOffset().$ctor$4(value).ToUnixTimeMilliseconds());
            }
            /*void */ ToManaged$33(/*out DateTime?*/ value)
            {
                if (this.slot.Type === 0/*MarshalerType.None*/)
                {
                    value.$v = null;
                    return;
                }
                value.$v = $.$spc.System.DateTimeOffset.FromUnixTimeMilliseconds($.$cast(this.slot.DoubleValue, $.$spc.System.Int64)).UtcDateTime;
            }
            /*void */ ToJS$33(/*DateTime?*/ value)
            {
                if ($.$spc.System.Nullable$$($.$spc.System.DateTime).HasValue$get.call(value))
                {
                    this.slot.Type = 17/*MarshalerType.DateTime*/;
                    this.slot.DoubleValue = Number(new $.$spc.System.DateTimeOffset().$ctor$4($.$spc.System.Nullable$$($.$spc.System.DateTime).Value$get.call(value)).ToUnixTimeMilliseconds());
                }
                else 
                {
                    this.slot.Type = 0/*MarshalerType.None*/;
                }
            }
            /*void */ ToManaged$34(/*out IntPtr*/ value)
            {
                if (this.slot.Type === 0/*MarshalerType.None*/)
                {
                    value.$v = 0;
                    return;
                }
                value.$v = this.slot.IntPtrValue;
            }
            /*void */ ToJS$34(/*IntPtr*/ value)
            {
                this.slot.Type = 12/*MarshalerType.IntPtr*/;
                this.slot.IntPtrValue = value;
            }
            /*void */ ToManaged$35(/*out IntPtr?*/ value)
            {
                if (this.slot.Type === 0/*MarshalerType.None*/)
                {
                    value.$v = null;
                    return;
                }
                value.$v = this.slot.IntPtrValue;
            }
            /*void */ ToJS$35(/*IntPtr?*/ value)
            {
                if ($.$spc.System.Nullable$$($.$spc.System.IntPtr).HasValue$get.call(value))
                {
                    this.slot.Type = 12/*MarshalerType.IntPtr*/;
                    this.slot.IntPtrValue = $.$spc.System.Nullable$$($.$spc.System.IntPtr).Value$get.call(value);
                }
                else 
                {
                    this.slot.Type = 0/*MarshalerType.None*/;
                }
            }
            /*void */ ToManaged$36(/*out void**/ value)
            {
                if (this.slot.Type === 0/*MarshalerType.None*/)
                {
                    value.$v = new $.$typePointer($.$spc.System.Void)();
                    return;
                }
                value.$v = $.$cast(this.slot.IntPtrValue, $.$typePointer($.$spc.System.Byte));
            }
            /*void */ ToJS$36(/*void**/ value)
            {
                this.slot.Type = 12/*MarshalerType.IntPtr*/;
                this.slot.IntPtrValue = $.$spc.System.IntPtr.op_Explicit$2(value);
            }
            /*void */ ToManaged$37(/*out object?*/ value)
            {
                if (this.slot.Type === 0/*MarshalerType.None*/)
                {
                    value.$v = null;
                }
                else if (this.slot.Type === 14/*MarshalerType.Object*/)
                {
                    value.$v = ($.$spc.System.Runtime.InteropServices.GCHandle.op_Explicit(this.slot.GCHandle)).Target;
                }
                else if (this.slot.Type === 3/*MarshalerType.Boolean*/)
                {
                    /*bool*/ let v;
                    this.ToManaged$26($.$ref(() => v, ($v) => v = $v, $.$spc.System.Boolean));
                    value.$v = $.$box(v, $.$spc.System.Boolean);
                }
                else if (this.slot.Type === 10/*MarshalerType.Double*/)
                {
                    /*double*/ let v;
                    this.ToManaged$2($.$ref(() => v, ($v) => v = $v, $.$spc.System.Double));
                    value.$v = $.$box(v, $.$spc.System.Double);
                }
                else if (this.slot.Type === 13/*MarshalerType.JSObject*/)
                {
                    /*JSObject?*/ let val;
                    this.ToManaged$44($.$ref(() => val, ($v) => val = $v, $.$srij.System.Runtime.InteropServices.JavaScript.JSObject));
                    value.$v = val;
                }
                else if (this.slot.Type === 15/*MarshalerType.String*/)
                {
                    /*string?*/ let val;
                    this.ToManaged$46($.$ref(() => val, ($v) => val = $v, $.$spc.System.String));
                    value.$v = val;
                }
                else if (this.slot.Type === 16/*MarshalerType.Exception*/)
                {
                    /*Exception?*/ let val;
                    this.ToManaged$48($.$ref(() => val, ($v) => val = $v, $.$spc.System.Exception));
                    value.$v = val;
                }
                else if (this.slot.Type === 17/*MarshalerType.DateTime*/)
                {
                    /*DateTime?*/ let val;
                    this.ToManaged$33($.$ref(() => val, ($v) => val = $v, $.$typeNullable($.$spc.System.DateTime)));
                    value.$v = val?.Clone();
                }
                else if (this.slot.Type === 27/*MarshalerType.JSException*/)
                {
                    /*Exception?*/ let val;
                    this.ToManaged$48($.$ref(() => val, ($v) => val = $v, $.$spc.System.Exception));
                    value.$v = val;
                }
                else if (this.slot.Type === 21/*MarshalerType.Array*/)
                {
                    if (this.slot.ElementType === 4/*MarshalerType.Byte*/)
                    {
                        /*byte[]?*/ let val;
                        this.ToManaged$23($.$ref(() => val, ($v) => val = $v, $.$typeArray($.$spc.System.Byte)));
                        value.$v = val;
                    }
                    else if (this.slot.ElementType === 10/*MarshalerType.Double*/)
                    {
                        /*double[]?*/ let val;
                        this.ToManaged$4($.$ref(() => val, ($v) => val = $v, $.$typeArray($.$spc.System.Double)));
                        value.$v = val;
                    }
                    else if (this.slot.ElementType === 7/*MarshalerType.Int32*/)
                    {
                        /*int[]?*/ let val;
                        this.ToManaged$41($.$ref(() => val, ($v) => val = $v, $.$typeArray($.$spc.System.Int32)));
                        value.$v = val;
                    }
                    else if (this.slot.ElementType === 14/*MarshalerType.Object*/)
                    {
                        /*object?[]?*/ let val;
                        this.ToManaged$38($.$ref(() => val, ($v) => val = $v, $.$typeArray($.$spc.System.Object)));
                        value.$v = val;
                    }
                    else 
                    {
                        throw new $.$spc.System.NotSupportedException().$ctor$10($.$srij.System.SR.Format($.$srij.System.SR.ToManagedNotImplemented, $.$spc.System.Enum.ToString.call(this.slot.ElementType) + "[]"));
                    }
                }
                else if (this.slot.Type === 20/*MarshalerType.Task*/ || this.slot.Type === 28/*MarshalerType.TaskResolved*/ || this.slot.Type === 29/*MarshalerType.TaskRejected*/)
                {
                    /*Task<object?>?*/ let val;
                    this.ToManaged$29($.$spc.System.Object, $.$ref(() => val, ($v) => val = $v, $.$spc.System.Threading.Tasks.Task$$($.$spc.System.Object)), new ($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument.ArgumentToManagedCallback$$($.$spc.System.Object))().$ctor(null, /*static*/ (/*JSMarshalerArgument*/ arg, /*object?*/ value) =>
                    {
                        arg.$v.ToManaged$37(value);
                    }));
                    value.$v = val;
                }
                else 
                {
                    throw new $.$spc.System.NotSupportedException().$ctor$10($.$srij.System.SR.Format($.$srij.System.SR.ToManagedNotImplemented, $.$box(this.slot.Type, $.$srij.System.Runtime.InteropServices.JavaScript.MarshalerType)));
                }
            }
            /*void */ ToJS$37(/*object?*/ value)
            {
                if (value === null)
                {
                    this.slot.Type = 0/*MarshalerType.None*/;
                    return;
                }
                /*Type*/ let type = $.$spc.System.Object.GetType.call(value);
                let ut;
                if (type.IsPrimitive)
                {
                    if ($.$spc.System.Type.op_Equality$1($.$spc.System.Int64.$type, type))
                    {
                        throw new $.$spc.System.NotSupportedException().$ctor$10($.$srij.System.SR.Format($.$srij.System.SR.ToJSNotImplemented, type.FullName));
                    }
                    else if ($.$spc.System.Type.op_Equality$1($.$spc.System.Int32.$type, type))
                    {
                        /*var*/ let v = $.$cast(value, $.$spc.System.Int32);
                        this.ToJS$39(v);
                    }
                    else if ($.$spc.System.Type.op_Equality$1($.$spc.System.Int16.$type, type))
                    {
                        /*var*/ let v = $.$cast(value, $.$spc.System.Int16);
                        this.ToJS$19(v);
                    }
                    else if ($.$spc.System.Type.op_Equality$1($.$spc.System.Byte.$type, type))
                    {
                        /*var*/ let v = $.$cast(value, $.$spc.System.Byte);
                        this.ToJS$21(v);
                    }
                    else if ($.$spc.System.Type.op_Equality$1($.$spc.System.Char.$type, type))
                    {
                        /*var*/ let v = $.$cast(value, $.$spc.System.Char);
                        this.ToJS(v);
                    }
                    else if ($.$spc.System.Type.op_Equality$1($.$spc.System.Boolean.$type, type))
                    {
                        /*var*/ let v = $.$cast(value, $.$spc.System.Boolean);
                        this.ToJS$26(v);
                    }
                    else if ($.$spc.System.Type.op_Equality$1($.$spc.System.Double.$type, type))
                    {
                        /*var*/ let v = $.$cast(value, $.$spc.System.Double);
                        this.ToJS$2(v);
                    }
                    else if ($.$spc.System.Type.op_Equality$1($.$spc.System.Single.$type, type))
                    {
                        /*var*/ let v = $.$cast(value, $.$spc.System.Single);
                        this.ToJS$15(v);
                    }
                    else if ($.$spc.System.Type.op_Equality$1($.$spc.System.IntPtr.$type, type))
                    {
                        /*var*/ let v = $.$cast(value, $.$spc.System.IntPtr);
                        this.ToJS$34(v);
                    }
                    else 
                    {
                        throw new $.$spc.System.NotSupportedException().$ctor$10($.$srij.System.SR.Format($.$srij.System.SR.ToJSNotImplemented, type.FullName));
                    }
                }
                else if ($.$spc.System.Type.op_Equality$1($.$spc.System.String.$type, type))
                {
                    /*string?*/ let str = $.$as(value, $.$spc.System.String);
                    this.ToJS$46(str);
                }
                else if ($.$spc.System.Type.op_Equality$1($.$spc.System.DateTimeOffset.$type, type))
                {
                    /*var*/ let v = $.$cast(value, $.$spc.System.DateTimeOffset);
                    this.ToJS$30(v);
                }
                else if ($.$spc.System.Type.op_Equality$1($.$spc.System.DateTime.$type, type))
                {
                    /*var*/ let v = $.$cast(value, $.$spc.System.DateTime);
                    this.ToJS$32(v);
                }
                else if ($.$is($.$spc.System.Nullable.GetUnderlyingType(type), $.$spc.System.Type, { set $v(v){ ut = v; } }) && $.$spc.System.Type.op_Inequality$1(ut, null))
                {
                    if ($.$spc.System.Type.op_Equality$1($.$spc.System.Int64.$type, ut))
                    {
                        throw new $.$spc.System.NotSupportedException().$ctor$10($.$srij.System.SR.Format($.$srij.System.SR.ToJSNotImplemented, type.FullName));
                    }
                    else if ($.$spc.System.Type.op_Equality$1($.$spc.System.Int32.$type, ut))
                    {
                        /*var*/ let nv = $.$as(value, $.$spc.System.Int32);
                        this.ToJS$40(nv);
                    }
                    else if ($.$spc.System.Type.op_Equality$1($.$spc.System.Int16.$type, ut))
                    {
                        /*var*/ let nv = $.$as(value, $.$spc.System.Int16);
                        this.ToJS$20(nv);
                    }
                    else if ($.$spc.System.Type.op_Equality$1($.$spc.System.Byte.$type, ut))
                    {
                        /*var*/ let nv = $.$as(value, $.$spc.System.Byte);
                        this.ToJS$22(nv);
                    }
                    else if ($.$spc.System.Type.op_Equality$1($.$spc.System.Char.$type, ut))
                    {
                        /*var*/ let nv = $.$as(value, $.$spc.System.Char);
                        this.ToJS$1(nv);
                    }
                    else if ($.$spc.System.Type.op_Equality$1($.$spc.System.Boolean.$type, ut))
                    {
                        /*var*/ let nv = $.$as(value, $.$spc.System.Boolean);
                        this.ToJS$27(nv);
                    }
                    else if ($.$spc.System.Type.op_Equality$1($.$spc.System.Double.$type, ut))
                    {
                        /*var*/ let nv = $.$as(value, $.$spc.System.Double);
                        this.ToJS$3(nv);
                    }
                    else if ($.$spc.System.Type.op_Equality$1($.$spc.System.Single.$type, ut))
                    {
                        /*var*/ let nv = $.$as(value, $.$spc.System.Single);
                        this.ToJS$16(nv);
                    }
                    else if ($.$spc.System.Type.op_Equality$1($.$spc.System.IntPtr.$type, ut))
                    {
                        /*var*/ let nv = $.$as(value, $.$spc.System.IntPtr);
                        this.ToJS$35(nv);
                    }
                    else if ($.$spc.System.Type.op_Equality$1($.$spc.System.DateTimeOffset.$type, ut))
                    {
                        /*var*/ let nv = $.$as(value, $.$spc.System.DateTimeOffset);
                        this.ToJS$31(nv?.Clone());
                    }
                    else if ($.$spc.System.Type.op_Equality$1($.$spc.System.DateTime.$type, ut))
                    {
                        /*var*/ let nv = $.$as(value, $.$spc.System.DateTime);
                        this.ToJS$33(nv?.Clone());
                    }
                    else 
                    {
                        throw new $.$spc.System.NotSupportedException().$ctor$10($.$srij.System.SR.Format($.$srij.System.SR.ToJSNotImplemented, type.FullName));
                    }
                }
                else if ($.$srij.System.Runtime.InteropServices.JavaScript.JSObject.$type.IsAssignableFrom(type))
                {
                    /*JSObject?*/ let val = $.$as(value, $.$srij.System.Runtime.InteropServices.JavaScript.JSObject);
                    this.ToJS$44(val);
                }
                else if ($.$spc.System.Exception.$type.IsAssignableFrom(type))
                {
                    /*Exception?*/ let val = $.$as(value, $.$spc.System.Exception);
                    this.ToJS$48(val);
                }
                else if ($.$spc.System.Type.op_Equality$1($.$spc.System.Threading.Tasks.Task$$($.$spc.System.Object).$type, type))
                {
                    /*Task<object>?*/ let val = $.$as(value, $.$spc.System.Threading.Tasks.Task$$($.$spc.System.Object));
                    this.ToJS$29($.$spc.System.Object, val, new ($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument.ArgumentToJSCallback$$($.$spc.System.Object))().$ctor(this,  (/*JSMarshalerArgument*/ arg, /*object*/ value) =>
                    {
                        /*object?*/ let valueRef = value;
                        arg.$v.ToJS$37(valueRef);
                    }));
                }
                else if ($.$spc.System.Threading.Tasks.Task.$type.IsAssignableFrom(type))
                {
                    /*Task?*/ let val = $.$as(value, $.$spc.System.Threading.Tasks.Task);
                    this.ToJSDynamic(val);
                }
                else if ($.$spc.System.Type.op_Equality$1($.$typeArray($.$spc.System.Byte).$type, type))
                {
                    /*byte[]*/ let val = $.$cast(value, $.$typeArray($.$spc.System.Byte));
                    this.ToJS$23(val);
                }
                else if ($.$spc.System.Type.op_Equality$1($.$typeArray($.$spc.System.Int32).$type, type))
                {
                    /*int[]*/ let val = $.$cast(value, $.$typeArray($.$spc.System.Int32));
                    this.ToJS$41(val);
                }
                else if ($.$spc.System.Type.op_Equality$1($.$typeArray($.$spc.System.Double).$type, type))
                {
                    /*double[]*/ let val = $.$cast(value, $.$typeArray($.$spc.System.Double));
                    this.ToJS$4(val);
                }
                else if ($.$spc.System.Type.op_Equality$1($.$typeArray($.$spc.System.String).$type, type))
                {
                    /*string[]*/ let val = $.$cast(value, $.$typeArray($.$spc.System.String));
                    this.ToJS$47(val);
                }
                else if ($.$spc.System.Type.op_Equality$1($.$typeArray($.$spc.System.Object).$type, type))
                {
                    /*object[]*/ let val = $.$cast(value, $.$typeArray($.$spc.System.Object));
                    this.ToJS$38(val);
                }
                else if (type.IsArray)
                {
                    throw new $.$spc.System.NotSupportedException().$ctor$10($.$srij.System.SR.Format($.$srij.System.SR.ToJSNotImplemented, type.FullName));
                }
                else if ($.$spc.System.MulticastDelegate.$type.IsAssignableFrom(type.BaseType))
                {
                    throw new $.$spc.System.NotSupportedException().$ctor$10($.$srij.System.SR.Format($.$srij.System.SR.ToJSNotImplemented, type.FullName));
                }
                else if (type.IsGenericType && $.$spc.System.Type.op_Equality$1(type.GetGenericTypeDefinition(), $.$spc.System.ArraySegment$$().$type))
                {
                    throw new $.$spc.System.NotSupportedException().$ctor$10($.$srij.System.SR.Format($.$srij.System.SR.ToJSNotImplemented, type.FullName));
                }
                else if (type.IsGenericType && $.$spc.System.Type.op_Equality$1(type.GetGenericTypeDefinition(), $.$spc.System.Span$$().$type))
                {
                    throw new $.$spc.System.NotSupportedException().$ctor$10($.$srij.System.SR.Format($.$srij.System.SR.ToJSNotImplemented, type.FullName));
                }
                else 
                {
                    this.slot.Type = 14/*MarshalerType.Object*/;
                    /*var*/ let ctx = this.ToJSContext;
                    this.slot.GCHandle = ctx.GetJSOwnedObjectGCHandle(value, 2);
                }
            }
            /*void */ ToManaged$38(/*out object?[]?*/ value)
            {
                if (this.slot.Type === 0/*MarshalerType.None*/)
                {
                    value.$v = null;
                    return;
                }
                value.$v = $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$spc.System.Object), null, [this.slot.Length], null);
                /*JSMarshalerArgument**/ let payload = $.$cast(this.slot.IntPtrValue, $.$typePointer($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument));
                for(/*int*/ let i = 0; i < this.slot.Length; i++)
                {
                    /*ref JSMarshalerArgument*/ let arg = payload.Add(i);
                    /*object?*/ let val;
                    arg.$v.ToManaged$37($.$ref(() => val, ($v) => val = $v, $.$spc.System.Object));
                    $.$spc.System.Array.$WriteT1.call(value.$v, val, i);
                }
                $.$srij.Interop.Runtime.DeregisterGCRoot(this.slot.IntPtrValue);
                $.$spc.System.Runtime.InteropServices.Marshal.FreeHGlobal(this.slot.IntPtrValue);
            }
            /*void */ ToJS$38(/*object?[]*/ value)
            {
                if (value === null)
                {
                    this.slot.Type = 0/*MarshalerType.None*/;
                    return;
                }
                this.slot.Length = value.length;
                /*int*/ let bytes = ((value.length * $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument.$z) | 0);
                this.slot.Type = 21/*MarshalerType.Array*/;
                /*JSMarshalerArgument**/ let payload = $.$cast($.$spc.System.Runtime.InteropServices.Marshal.AllocHGlobal(bytes), $.$typePointer($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument));
                $.$spc.System.Runtime.CompilerServices.Unsafe.InitBlock(payload, 0, (bytes >>> 0));
                $.$srij.Interop.Runtime.RegisterGCRoot(payload, bytes, $.$spc.System.IntPtr.Zero);
                for(/*int*/ let i = 0; i < this.slot.Length; i++)
                {
                    /*ref JSMarshalerArgument*/ let arg = payload.Add(i);
                    /*object?*/ let val = $.$spc.System.Array.$ReadT1.call(value, i);
                    arg.$v.ToJS$37(val);
                    $.$spc.System.Array.$WriteT1.call(value, val, i);
                }
                this.slot.ElementType = 14/*MarshalerType.Object*/;
                this.slot.IntPtrValue = $.$cast(payload, $.$spc.System.IntPtr);
            }
            /*void */ ToManaged$39(/*out int*/ value)
            {
                if (this.slot.Type === 0/*MarshalerType.None*/)
                {
                    value.$v = 0;
                    return;
                }
                value.$v = this.slot.Int32Value;
            }
            /*void */ ToJS$39(/*int*/ value)
            {
                this.slot.Type = 7/*MarshalerType.Int32*/;
                this.slot.Int32Value = value;
            }
            /*void */ ToManaged$40(/*out int?*/ value)
            {
                if (this.slot.Type === 0/*MarshalerType.None*/)
                {
                    value.$v = null;
                    return;
                }
                value.$v = this.slot.Int32Value;
            }
            /*void */ ToJS$40(/*int?*/ value)
            {
                if ($.$spc.System.Nullable$$($.$spc.System.Int32).HasValue$get.call(value))
                {
                    this.slot.Type = 7/*MarshalerType.Int32*/;
                    this.slot.Int32Value = $.$spc.System.Nullable$$($.$spc.System.Int32).Value$get.call(value);
                }
                else 
                {
                    this.slot.Type = 0/*MarshalerType.None*/;
                }
            }
            /*void */ ToManaged$41(/*out int[]?*/ value)
            {
                if (this.slot.Type === 0/*MarshalerType.None*/)
                {
                    value.$v = null;
                    return;
                }
                value.$v = $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$spc.System.Int32), null, [this.slot.Length], null);
                $.$spc.System.Runtime.InteropServices.Marshal.Copy$8(this.slot.IntPtrValue, value.$v, 0, this.slot.Length);
                $.$spc.System.Runtime.InteropServices.Marshal.FreeHGlobal(this.slot.IntPtrValue);
            }
            /*void */ ToJS$41(/*int[]?*/ value)
            {
                if (value === null)
                {
                    this.slot.Type = 0/*MarshalerType.None*/;
                    return;
                }
                this.slot.Type = 21/*MarshalerType.Array*/;
                this.slot.IntPtrValue = $.$spc.System.Runtime.InteropServices.Marshal.AllocHGlobal(((value.length * $.$spc.System.Int32.$z) | 0));
                this.slot.Length = value.length;
                this.slot.ElementType = 7/*MarshalerType.Int32*/;
                $.$spc.System.Runtime.InteropServices.Marshal.Copy(value, 0, this.slot.IntPtrValue, this.slot.Length);
            }
            /*void */ ToManaged$42(/*out ArraySegment<int>*/ value)
            {
                /*var*/ let array = $.$cast(($.$spc.System.Runtime.InteropServices.GCHandle.op_Explicit(this.slot.GCHandle)).Target, $.$typeArray($.$spc.System.Int32));
                /*var*/ let refPtr = $.$spc.System.IntPtr.op_Explicit$2($.$spc.System.Runtime.CompilerServices.Unsafe.AsPointer($.$spc.System.Int32, $.$spc.System.Runtime.InteropServices.MemoryMarshal.GetArrayDataReference($.$spc.System.Int32, array)));
                /*int*/ let byteOffset = (((this.slot.IntPtrValue - refPtr) | 0));
                value.$v = new ($.$spc.System.ArraySegment$$($.$spc.System.Int32))().$ctor$3(array, $.trunc(byteOffset / $.$spc.System.Int32.$z), this.slot.Length);
            }
            /*void */ ToJS$42(/*ArraySegment<int>*/ value)
            {
                if (value.Array === null)
                {
                    this.slot.Type = 0/*MarshalerType.None*/;
                    return;
                }
                /*var*/ let ctx = this.ToJSContext;
                this.slot.Type = 22/*MarshalerType.ArraySegment*/;
                this.slot.GCHandle = ctx.GetJSOwnedObjectGCHandle(value.Array, 3/*GCHandleType.Pinned*/);
                /*var*/ let refPtr = $.$spc.System.IntPtr.op_Explicit$2($.$spc.System.Runtime.CompilerServices.Unsafe.AsPointer($.$spc.System.Int32, $.$spc.System.Runtime.InteropServices.MemoryMarshal.GetArrayDataReference($.$spc.System.Int32, value.Array)));
                this.slot.IntPtrValue = ((refPtr + (((value.Offset * $.$spc.System.Int32.$z) | 0))) | 0);
                this.slot.Length = value.Count;
            }
            /*void */ ToManaged$43(/*out Span<int>*/ value)
            {
                value.$v = new ($.$spc.System.Span$$($.$spc.System.Int32))().$ctor$4($.$spc.System.IntPtr.op_Explicit$3(this.slot.IntPtrValue), this.slot.Length);
            }
            /*void */ ToJS$43(/*Span<int>*/ value)
            {
                this.slot.Length = value.Length;
                this.slot.IntPtrValue = $.$spc.System.IntPtr.op_Explicit$2($.$spc.System.Runtime.CompilerServices.Unsafe.AsPointer($.$spc.System.Int32, value.GetPinnableReference()));
                this.slot.Type = 23/*MarshalerType.Span*/;
            }
            /*void */ ToManaged$44(/*out JSObject?*/ value)
            {
                if (this.slot.Type === 0/*MarshalerType.None*/)
                {
                    value.$v = null;
                    return;
                }
                /*var*/ let ctx = this.ToManagedContext;
                value.$v = ctx.CreateCSOwnedProxy(this.slot.JSHandle);
            }
            /*void */ ToJS$44(/*JSObject?*/ value)
            {
                if (value === null)
                {
                    this.slot.Type = 0/*MarshalerType.None*/;
                }
                else 
                {
                    value.AssertNotDisposed();
                    this.slot.Type = 13/*MarshalerType.JSObject*/;
                    this.slot.JSHandle = value.JSHandle;
                }
            }
            /*void */ ToManaged$45(/*out JSObject?[]?*/ value)
            {
                if (this.slot.Type === 0/*MarshalerType.None*/)
                {
                    value.$v = null;
                    return;
                }
                value.$v = $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$srij.System.Runtime.InteropServices.JavaScript.JSObject), null, [this.slot.Length], null);
                /*JSMarshalerArgument**/ let payload = $.$cast(this.slot.IntPtrValue, $.$typePointer($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument));
                for(/*int*/ let i = 0; i < this.slot.Length; i++)
                {
                    /*ref JSMarshalerArgument*/ let arg = payload.Add(i);
                    /*JSObject?*/ let val;
                    arg.$v.ToManaged$44($.$ref(() => val, ($v) => val = $v, $.$srij.System.Runtime.InteropServices.JavaScript.JSObject));
                    $.$spc.System.Array.$WriteT1.call(value.$v, val, i);
                }
                $.$spc.System.Runtime.InteropServices.Marshal.FreeHGlobal(this.slot.IntPtrValue);
            }
            /*void */ ToJS$45(/*JSObject?[]*/ value)
            {
                if (value === null)
                {
                    this.slot.Type = 0/*MarshalerType.None*/;
                    return;
                }
                this.slot.Length = value.length;
                /*int*/ let bytes = ((value.length * $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument.$z) | 0);
                this.slot.Type = 21/*MarshalerType.Array*/;
                this.slot.ElementType = 13/*MarshalerType.JSObject*/;
                /*JSMarshalerArgument**/ let payload = $.$cast($.$spc.System.Runtime.InteropServices.Marshal.AllocHGlobal(bytes), $.$typePointer($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument));
                $.$spc.System.Runtime.CompilerServices.Unsafe.InitBlock(payload, 0, (bytes >>> 0));
                for(/*int*/ let i = 0; i < this.slot.Length; i++)
                {
                    /*ref JSMarshalerArgument*/ let arg = payload.Add(i);
                    /*JSObject?*/ let val = $.$spc.System.Array.$ReadT1.call(value, i);
                    arg.$v.ToJS$44(val);
                    $.$spc.System.Array.$WriteT1.call(value, val, i);
                }
                this.slot.IntPtrValue = $.$cast(payload, $.$spc.System.IntPtr);
            }
            /*void */ ToManaged$46(/*out string?*/ value)
            {
                if (this.slot.Type === 0/*MarshalerType.None*/)
                {
                    value.$v = null;
                    return;
                }
                /*fixed*/ 
                {
                    /*void**/ let argAsRoot = $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateObjectReferenceT($.$spc.System.IntPtr, () => this.slot.IntPtrValue, ($v) => this.slot.IntPtrValue = $v, null);
                    value.$v = $.$spc.System.Runtime.CompilerServices.Unsafe.AsRef($.$spc.System.String, argAsRoot).$v;
                }
            }
            /*void */ ToJS$46(/*string?*/ value)
            {
                if ($.$spc.System.String.op_Equality(value, null))
                {
                    this.slot.Type = 0/*MarshalerType.None*/;
                }
                else 
                {
                    this.slot.Type = 15/*MarshalerType.String*/;
                    /*fixed*/ 
                    {
                        /*IntPtr**/ let argAsRoot = $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateObjectReferenceT($.$spc.System.IntPtr, () => this.slot.IntPtrValue, ($v) => this.slot.IntPtrValue = $v, null);
                        /*string*/ let cpy = value;
                        /*var*/ let currentRoot = $.$cast($.$spc.System.Runtime.CompilerServices.Unsafe.AsPointer($.$spc.System.String, $.$ref(() => cpy, ($v) => cpy = $v, $.$spc.System.String)), $.$typePointer($.$spc.System.IntPtr));
                        argAsRoot.SetAt(currentRoot.GetAt(0), 0);
                    }
                }
            }
            /*void */ ToManaged$47(/*out string?[]?*/ value)
            {
                if (this.slot.Type === 0/*MarshalerType.None*/)
                {
                    value.$v = null;
                    return;
                }
                value.$v = $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$spc.System.String), null, [this.slot.Length], null);
                /*JSMarshalerArgument**/ let payload = $.$cast(this.slot.IntPtrValue, $.$typePointer($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument));
                for(/*int*/ let i = 0; i < this.slot.Length; i++)
                {
                    /*ref JSMarshalerArgument*/ let arg = payload.Add(i);
                    /*string?*/ let val;
                    arg.$v.ToManaged$46($.$ref(() => val, ($v) => val = $v, $.$spc.System.String));
                    $.$spc.System.Array.$WriteT1.call(value.$v, val, i);
                }
                $.$srij.Interop.Runtime.DeregisterGCRoot(this.slot.IntPtrValue);
                $.$spc.System.Runtime.InteropServices.Marshal.FreeHGlobal(this.slot.IntPtrValue);
            }
            /*void */ ToJS$47(/*string?[]*/ value)
            {
                if (value === null)
                {
                    this.slot.Type = 0/*MarshalerType.None*/;
                    return;
                }
                this.slot.Length = value.length;
                /*int*/ let bytes = ((value.length * $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument.$z) | 0);
                this.slot.Type = 21/*MarshalerType.Array*/;
                /*JSMarshalerArgument**/ let payload = $.$cast($.$spc.System.Runtime.InteropServices.Marshal.AllocHGlobal(bytes), $.$typePointer($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument));
                $.$spc.System.Runtime.CompilerServices.Unsafe.InitBlock(payload, 0, (bytes >>> 0));
                $.$srij.Interop.Runtime.RegisterGCRoot(payload, bytes, $.$spc.System.IntPtr.Zero);
                for(/*int*/ let i = 0; i < this.slot.Length; i++)
                {
                    /*ref JSMarshalerArgument*/ let arg = payload.Add(i);
                    /*string?*/ let val = $.$spc.System.Array.$ReadT1.call(value, i);
                    arg.$v.ToJS$46(val);
                    $.$spc.System.Array.$WriteT1.call(value, val, i);
                }
                this.slot.IntPtrValue = $.$cast(payload, $.$spc.System.IntPtr);
                this.slot.ElementType = 15/*MarshalerType.String*/;
            }
            /*void */ ToManaged$48(/*out Exception?*/ value)
            {
                if (this.slot.Type === 0/*MarshalerType.None*/)
                {
                    value.$v = null;
                    return;
                }
                if (this.slot.Type === 16/*MarshalerType.Exception*/)
                {
                    value.$v = $.$cast(($.$spc.System.Runtime.InteropServices.GCHandle.op_Explicit(this.slot.GCHandle)).Target, $.$spc.System.Exception);
                    return;
                }
                /*JSObject?*/ let jsException = null;
                if (this.slot.JSHandle !== $.$spc.System.IntPtr.Zero)
                {
                    /*var*/ let ctx = this.ToManagedContext;
                    jsException = ctx.CreateCSOwnedProxy(this.slot.JSHandle);
                }
                /*string?*/ let message;
                this.ToManaged$46($.$ref(() => message, ($v) => message = $v, $.$spc.System.String));
                value.$v = new $.$srij.System.Runtime.InteropServices.JavaScript.JSException().$ctor$6(message, jsException);
            }
            /*void */ ToJS$48(/*Exception?*/ value)
            {
                if (value === null)
                {
                    this.slot.Type = 0/*MarshalerType.None*/;
                }
                else 
                {
                    /*Exception*/ let cpy = value;
                    let ae;
                    if ($.$is(cpy, $.$spc.System.AggregateException, { set $v(v){ ae = v; } }) && ae.InnerExceptions.Count === 1)
                    {
                        cpy = ae.InnerExceptions.get_Item(0);
                    }
                    /*var*/ let jse = $.$as(cpy, $.$srij.System.Runtime.InteropServices.JavaScript.JSException);
                    if (jse !== null && jse.jsException !== null)
                    {
                        /*var*/ let jsException = jse.jsException;
                        jsException.AssertNotDisposed();
                        this.slot.Type = 27/*MarshalerType.JSException*/;
                        this.slot.JSHandle = jsException.JSHandle;
                    }
                    else 
                    {
                        this.ToJS$46(cpy.Message);
                        this.slot.Type = 16/*MarshalerType.Exception*/;
                        /*var*/ let ctx = this.ToJSContext;
                        this.slot.GCHandle = ctx.GetJSOwnedObjectGCHandle(cpy, 2);
                    }
                }
            }
            //default value type constructor
            $ctor$2()
            {
                return this;
            }
            Clone($copy)
            {
                let copy = $copy ?? new this.constructor();
                copy.slot = this.slot.Clone();
                return copy;
            }
            //default member initializer
            constructor()
            {
                super();
                this.slot = $.$default($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument.JSMarshalerArgumentImpl);
            }
            static $h = 1350397;
            static $z = 32;
            static $f = 0b1010000001;
            static $k = 2;
            static $$md;
            static get $md() { return this.$$md ??= {"b":196609,"p":[{"p":2333437,"g":{"r":0,"d":0,"h":21476186877,"f":8},"n":"ToManagedContext","d":1350397,"h":17181219581,"f":8},{"p":2333437,"g":{"r":0,"d":0,"h":30066121469,"f":8},"n":"ToJSContext","d":1350397,"h":25771154173,"f":8}],"m":[{"r":65537,"n":"Initialize","d":1350397,"h":12886252285,"f":1},{"r":2333437,"n":"AssertCurrentThreadContext","d":1350397,"h":34361088765,"f":8},{"r":65537,"p":[{"n":"value","p":917505,"f":2}],"n":"ToManagedBig","d":1350397,"h":38656056061,"f":1},{"r":65537,"p":[{"n":"value","p":917505}],"n":"ToJSBig","d":1350397,"h":42951023357,"f":1},{"r":65537,"p":[{"n":"value","p":$.$typeNullable($.$spc.System.Int64).$h,"f":2}],"n":"ToManagedBig","o":"@$1","d":1350397,"h":47245990653,"f":1},{"r":65537,"p":[{"n":"value","p":$.$typeNullable($.$spc.System.Int64).$h}],"n":"ToJSBig","o":"@$1","d":1350397,"h":51540957949,"f":1},{"r":65537,"p":[{"n":"value","p":458753,"f":2}],"n":"ToManaged","d":1350397,"h":55835925245,"f":1},{"r":65537,"p":[{"n":"value","p":458753}],"n":"ToJS","d":1350397,"h":60130892541,"f":1},{"r":65537,"p":[{"n":"value","p":$.$typeNullable($.$spc.System.Char).$h,"f":2}],"n":"ToManaged","o":"@$1","d":1350397,"h":64425859837,"f":1},{"r":65537,"p":[{"n":"value","p":$.$typeNullable($.$spc.System.Char).$h}],"n":"ToJS","o":"@$1","d":1350397,"h":68720827133,"f":1},{"r":65537,"p":[{"n":"value","p":1179649,"f":2}],"n":"ToManaged","o":"@$2","d":1350397,"h":73015794429,"f":1},{"r":65537,"p":[{"n":"value","p":1179649}],"n":"ToJS","o":"@$2","d":1350397,"h":77310761725,"f":1},{"r":65537,"p":[{"n":"value","p":$.$typeNullable($.$spc.System.Double).$h,"f":2}],"n":"ToManaged","o":"@$3","d":1350397,"h":81605729021,"f":1},{"r":65537,"p":[{"n":"value","p":$.$typeNullable($.$spc.System.Double).$h}],"n":"ToJS","o":"@$3","d":1350397,"h":85900696317,"f":1},{"r":65537,"p":[{"n":"value","p":0,"f":2}],"n":"ToManaged","o":"@$4","d":1350397,"h":90195663613,"f":1},{"r":65537,"p":[{"n":"value","p":0}],"n":"ToJS","o":"@$4","d":1350397,"h":94490630909,"f":1},{"r":65537,"p":[{"n":"value","p":$.$spc.System.ArraySegment$$($.$spc.System.Double).$h,"f":2}],"n":"ToManaged","o":"@$5","d":1350397,"h":98785598205,"f":1},{"r":65537,"p":[{"n":"value","p":$.$spc.System.ArraySegment$$($.$spc.System.Double).$h}],"n":"ToJS","o":"@$5","d":1350397,"h":103080565501,"f":1},{"r":65537,"p":[{"n":"value","p":$.$spc.System.Span$$($.$spc.System.Double).$h,"f":2}],"n":"ToManaged","o":"@$6","d":1350397,"h":107375532797,"f":1},{"r":65537,"p":[{"n":"value","p":$.$spc.System.Span$$($.$spc.System.Double).$h}],"n":"ToJS","o":"@$6","d":1350397,"h":111670500093,"f":1},{"r":65537,"p":[{"n":"value","p":11665409,"f":2}],"n":"ToManaged","o":"@$7","d":1350397,"h":133145336573,"f":1},{"r":65537,"p":[{"n":"value","p":(T) => $.$spc.System.Action$$(T).$h,"f":2},{"n":"arg1Marshaler","p":(T) => $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument.ArgumentToJSCallback$$(T).$h}],"g":["T"],"n":"ToManaged","o":"@$8","d":1350397,"h":137440303869,"f":131073},{"r":65537,"p":[{"n":"value","p":(T1, T2) => $.$spc.System.Action$$$(T1, T2).$h,"f":2},{"n":"arg1Marshaler","p":(T1, T2) => $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument.ArgumentToJSCallback$$(T1).$h},{"n":"arg2Marshaler","p":(T1, T2) => $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument.ArgumentToJSCallback$$(T2).$h}],"g":["T1","T2"],"n":"ToManaged","o":"@$9","d":1350397,"h":141735271165,"f":131073},{"r":65537,"p":[{"n":"value","p":(T1, T2, T3) => $.$spc.System.Action$$$$(T1, T2, T3).$h,"f":2},{"n":"arg1Marshaler","p":(T1, T2, T3) => $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument.ArgumentToJSCallback$$(T1).$h},{"n":"arg2Marshaler","p":(T1, T2, T3) => $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument.ArgumentToJSCallback$$(T2).$h},{"n":"arg3Marshaler","p":(T1, T2, T3) => $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument.ArgumentToJSCallback$$(T3).$h}],"g":["T1","T2","T3"],"n":"ToManaged","o":"@$10","d":1350397,"h":146030238461,"f":131073},{"r":65537,"p":[{"n":"value","p":(TResult) => $.$spc.System.Func$$(TResult).$h,"f":2},{"n":"resMarshaler","p":(TResult) => $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument.ArgumentToManagedCallback$$(TResult).$h}],"g":["TResult"],"n":"ToManaged","o":"@$11","d":1350397,"h":167505074941,"f":131073},{"r":65537,"p":[{"n":"value","p":(T, TResult) => $.$spc.System.Func$$$(T, TResult).$h,"f":2},{"n":"arg1Marshaler","p":(T, TResult) => $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument.ArgumentToJSCallback$$(T).$h},{"n":"resMarshaler","p":(T, TResult) => $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument.ArgumentToManagedCallback$$(TResult).$h}],"g":["T","TResult"],"n":"ToManaged","o":"@$12","d":1350397,"h":171800042237,"f":131073},{"r":65537,"p":[{"n":"value","p":(T1, T2, TResult) => $.$spc.System.Func$$$$(T1, T2, TResult).$h,"f":2},{"n":"arg1Marshaler","p":(T1, T2, TResult) => $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument.ArgumentToJSCallback$$(T1).$h},{"n":"arg2Marshaler","p":(T1, T2, TResult) => $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument.ArgumentToJSCallback$$(T2).$h},{"n":"resMarshaler","p":(T1, T2, TResult) => $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument.ArgumentToManagedCallback$$(TResult).$h}],"g":["T1","T2","TResult"],"n":"ToManaged","o":"@$13","d":1350397,"h":176095009533,"f":131073},{"r":65537,"p":[{"n":"value","p":(T1, T2, T3, TResult) => $.$spc.System.Func$$$$$(T1, T2, T3, TResult).$h,"f":2},{"n":"arg1Marshaler","p":(T1, T2, T3, TResult) => $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument.ArgumentToJSCallback$$(T1).$h},{"n":"arg2Marshaler","p":(T1, T2, T3, TResult) => $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument.ArgumentToJSCallback$$(T2).$h},{"n":"arg3Marshaler","p":(T1, T2, T3, TResult) => $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument.ArgumentToJSCallback$$(T3).$h},{"n":"resMarshaler","p":(T1, T2, T3, TResult) => $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument.ArgumentToManagedCallback$$(TResult).$h}],"g":["T1","T2","T3","TResult"],"n":"ToManaged","o":"@$14","d":1350397,"h":180389976829,"f":131073},{"r":65537,"p":[{"n":"value","p":11665409}],"n":"ToJS","o":"@$7","d":1350397,"h":184684944125,"f":1},{"r":65537,"p":[{"n":"value","p":(T) => $.$spc.System.Action$$(T).$h},{"n":"arg1Marshaler","p":(T) => $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument.ArgumentToManagedCallback$$(T).$h}],"g":["T"],"n":"ToJS","o":"@$8","d":1350397,"h":188979911421,"f":131073},{"r":65537,"p":[{"n":"value","p":(T1, T2) => $.$spc.System.Action$$$(T1, T2).$h},{"n":"arg1Marshaler","p":(T1, T2) => $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument.ArgumentToManagedCallback$$(T1).$h},{"n":"arg2Marshaler","p":(T1, T2) => $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument.ArgumentToManagedCallback$$(T2).$h}],"g":["T1","T2"],"n":"ToJS","o":"@$9","d":1350397,"h":193274878717,"f":131073},{"r":65537,"p":[{"n":"value","p":(T1, T2, T3) => $.$spc.System.Action$$$$(T1, T2, T3).$h},{"n":"arg1Marshaler","p":(T1, T2, T3) => $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument.ArgumentToManagedCallback$$(T1).$h},{"n":"arg2Marshaler","p":(T1, T2, T3) => $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument.ArgumentToManagedCallback$$(T2).$h},{"n":"arg3Marshaler","p":(T1, T2, T3) => $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument.ArgumentToManagedCallback$$(T3).$h}],"g":["T1","T2","T3"],"n":"ToJS","o":"@$10","d":1350397,"h":197569846013,"f":131073},{"r":65537,"p":[{"n":"value","p":(TResult) => $.$spc.System.Func$$(TResult).$h},{"n":"resMarshaler","p":(TResult) => $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument.ArgumentToJSCallback$$(TResult).$h}],"g":["TResult"],"n":"ToJS","o":"@$11","d":1350397,"h":201864813309,"f":131073},{"r":65537,"p":[{"n":"value","p":(T, TResult) => $.$spc.System.Func$$$(T, TResult).$h},{"n":"arg1Marshaler","p":(T, TResult) => $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument.ArgumentToManagedCallback$$(T).$h},{"n":"resMarshaler","p":(T, TResult) => $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument.ArgumentToJSCallback$$(TResult).$h}],"g":["T","TResult"],"n":"ToJS","o":"@$12","d":1350397,"h":206159780605,"f":131073},{"r":65537,"p":[{"n":"value","p":(T1, T2, TResult) => $.$spc.System.Func$$$$(T1, T2, TResult).$h},{"n":"arg1Marshaler","p":(T1, T2, TResult) => $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument.ArgumentToManagedCallback$$(T1).$h},{"n":"arg2Marshaler","p":(T1, T2, TResult) => $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument.ArgumentToManagedCallback$$(T2).$h},{"n":"resMarshaler","p":(T1, T2, TResult) => $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument.ArgumentToJSCallback$$(TResult).$h}],"g":["T1","T2","TResult"],"n":"ToJS","o":"@$13","d":1350397,"h":210454747901,"f":131073},{"r":65537,"p":[{"n":"value","p":(T1, T2, T3, TResult) => $.$spc.System.Func$$$$$(T1, T2, T3, TResult).$h},{"n":"arg1Marshaler","p":(T1, T2, T3, TResult) => $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument.ArgumentToManagedCallback$$(T1).$h},{"n":"arg2Marshaler","p":(T1, T2, T3, TResult) => $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument.ArgumentToManagedCallback$$(T2).$h},{"n":"arg3Marshaler","p":(T1, T2, T3, TResult) => $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument.ArgumentToManagedCallback$$(T3).$h},{"n":"resMarshaler","p":(T1, T2, T3, TResult) => $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument.ArgumentToJSCallback$$(TResult).$h}],"g":["T1","T2","T3","TResult"],"n":"ToJS","o":"@$14","d":1350397,"h":214749715197,"f":131073},{"r":65537,"p":[{"n":"value","p":1114113,"f":2}],"n":"ToManaged","o":"@$15","d":1350397,"h":219044682493,"f":1},{"r":65537,"p":[{"n":"value","p":1114113}],"n":"ToJS","o":"@$15","d":1350397,"h":223339649789,"f":1},{"r":65537,"p":[{"n":"value","p":$.$typeNullable($.$spc.System.Single).$h,"f":2}],"n":"ToManaged","o":"@$16","d":1350397,"h":227634617085,"f":1},{"r":65537,"p":[{"n":"value","p":$.$typeNullable($.$spc.System.Single).$h}],"n":"ToJS","o":"@$16","d":1350397,"h":231929584381,"f":1},{"r":65537,"p":[{"n":"value","p":917505,"f":2}],"n":"ToManaged","o":"@$17","d":1350397,"h":244814486269,"f":1},{"r":65537,"p":[{"n":"value","p":917505}],"n":"ToJS","o":"@$17","d":1350397,"h":249109453565,"f":1},{"r":65537,"p":[{"n":"value","p":$.$typeNullable($.$spc.System.Int64).$h,"f":2}],"n":"ToManaged","o":"@$18","d":1350397,"h":253404420861,"f":1},{"r":65537,"p":[{"n":"value","p":$.$typeNullable($.$spc.System.Int64).$h}],"n":"ToJS","o":"@$18","d":1350397,"h":257699388157,"f":1},{"r":65537,"p":[{"n":"value","p":524289,"f":2}],"n":"ToManaged","o":"@$19","d":1350397,"h":261994355453,"f":1},{"r":65537,"p":[{"n":"value","p":524289}],"n":"ToJS","o":"@$19","d":1350397,"h":266289322749,"f":1},{"r":65537,"p":[{"n":"value","p":$.$typeNullable($.$spc.System.Int16).$h,"f":2}],"n":"ToManaged","o":"@$20","d":1350397,"h":270584290045,"f":1},{"r":65537,"p":[{"n":"value","p":$.$typeNullable($.$spc.System.Int16).$h}],"n":"ToJS","o":"@$20","d":1350397,"h":274879257341,"f":1},{"r":65537,"p":[{"n":"value","p":393217,"f":2}],"n":"ToManaged","o":"@$21","d":1350397,"h":279174224637,"f":1},{"r":65537,"p":[{"n":"value","p":393217}],"n":"ToJS","o":"@$21","d":1350397,"h":283469191933,"f":1},{"r":65537,"p":[{"n":"value","p":$.$typeNullable($.$spc.System.Byte).$h,"f":2}],"n":"ToManaged","o":"@$22","d":1350397,"h":287764159229,"f":1},{"r":65537,"p":[{"n":"value","p":$.$typeNullable($.$spc.System.Byte).$h}],"n":"ToJS","o":"@$22","d":1350397,"h":292059126525,"f":1},{"r":65537,"p":[{"n":"value","p":0,"f":2}],"n":"ToManaged","o":"@$23","d":1350397,"h":296354093821,"f":1},{"r":65537,"p":[{"n":"value","p":0}],"n":"ToJS","o":"@$23","d":1350397,"h":300649061117,"f":1},{"r":65537,"p":[{"n":"value","p":$.$spc.System.ArraySegment$$($.$spc.System.Byte).$h,"f":2}],"n":"ToManaged","o":"@$24","d":1350397,"h":304944028413,"f":1},{"r":65537,"p":[{"n":"value","p":$.$spc.System.ArraySegment$$($.$spc.System.Byte).$h}],"n":"ToJS","o":"@$24","d":1350397,"h":309238995709,"f":1},{"r":65537,"p":[{"n":"value","p":$.$spc.System.Span$$($.$spc.System.Byte).$h,"f":2}],"n":"ToManaged","o":"@$25","d":1350397,"h":313533963005,"f":1},{"r":65537,"p":[{"n":"value","p":$.$spc.System.Span$$($.$spc.System.Byte).$h}],"n":"ToJS","o":"@$25","d":1350397,"h":317828930301,"f":1},{"r":65537,"p":[{"n":"value","p":262145,"f":2}],"n":"ToManaged","o":"@$26","d":1350397,"h":322123897597,"f":1},{"r":65537,"p":[{"n":"value","p":262145}],"n":"ToJS","o":"@$26","d":1350397,"h":326418864893,"f":1},{"r":65537,"p":[{"n":"value","p":$.$typeNullable($.$spc.System.Boolean).$h,"f":2}],"n":"ToManaged","o":"@$27","d":1350397,"h":330713832189,"f":1},{"r":65537,"p":[{"n":"value","p":$.$typeNullable($.$spc.System.Boolean).$h}],"n":"ToJS","o":"@$27","d":1350397,"h":335008799485,"f":1},{"r":65537,"p":[{"n":"value","p":133300225,"f":2}],"n":"ToManaged","o":"@$28","d":1350397,"h":347893701373,"f":1},{"r":65537,"p":[{"n":"value","p":(T) => $.$spc.System.Threading.Tasks.Task$$(T).$h,"f":2},{"n":"marshaler","p":(T) => $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument.ArgumentToManagedCallback$$(T).$h}],"g":["T"],"n":"ToManaged","o":"@$29","d":1350397,"h":352188668669,"f":131073},{"r":65537,"p":[{"n":"value","p":133300225}],"n":"ToJSDynamic","d":1350397,"h":356483635965,"f":8},{"r":65537,"p":[{"n":"value","p":133300225}],"n":"ToJS","o":"@$28","d":1350397,"h":360778603261,"f":1},{"r":65537,"p":[{"n":"value","p":(T) => $.$spc.System.Threading.Tasks.Task$$(T).$h},{"n":"marshaler","p":(T) => $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument.ArgumentToJSCallback$$(T).$h}],"g":["T"],"n":"ToJS","o":"@$29","d":1350397,"h":365073570557,"f":131073},{"r":262145,"p":[{"n":"_","p":2333437}],"n":"CanMarshalTaskResultOnSameCall","d":1350397,"h":369368537853,"f":2},{"r":65537,"p":[{"n":"holder","p":2267901},{"n":"ex","p":47185921}],"n":"RejectPromise","d":1350397,"h":377958472445,"f":34},{"r":65537,"p":[{"n":"holder","p":2267901}],"n":"ResolveVoidPromise","d":1350397,"h":382253439741,"f":34},{"r":65537,"p":[{"n":"holder","p":2267901},{"n":"value","p":382255693824},{"n":"marshaler","p":(T) => $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalerArgument.ArgumentToJSCallback$$(T).$h}],"g":["T"],"n":"ResolvePromise","d":1350397,"h":386548407037,"f":131106},{"r":65537,"p":[{"n":"value","p":34340865,"f":2}],"n":"ToManaged","o":"@$30","d":1350397,"h":390843374333,"f":1},{"r":65537,"p":[{"n":"value","p":34340865}],"n":"ToJS","o":"@$30","d":1350397,"h":395138341629,"f":1},{"r":65537,"p":[{"n":"value","p":$.$typeNullable($.$spc.System.DateTimeOffset).$h,"f":2}],"n":"ToManaged","o":"@$31","d":1350397,"h":399433308925,"f":1},{"r":65537,"p":[{"n":"value","p":$.$typeNullable($.$spc.System.DateTimeOffset).$h}],"n":"ToJS","o":"@$31","d":1350397,"h":403728276221,"f":1},{"r":65537,"p":[{"n":"value","p":34144257,"f":2}],"n":"ToManaged","o":"@$32","d":1350397,"h":408023243517,"f":1},{"r":65537,"p":[{"n":"value","p":34144257}],"n":"ToJS","o":"@$32","d":1350397,"h":412318210813,"f":1},{"r":65537,"p":[{"n":"value","p":$.$typeNullable($.$spc.System.DateTime).$h,"f":2}],"n":"ToManaged","o":"@$33","d":1350397,"h":416613178109,"f":1},{"r":65537,"p":[{"n":"value","p":$.$typeNullable($.$spc.System.DateTime).$h}],"n":"ToJS","o":"@$33","d":1350397,"h":420908145405,"f":1},{"r":65537,"p":[{"n":"value","p":786433,"f":2}],"n":"ToManaged","o":"@$34","d":1350397,"h":425203112701,"f":1},{"r":65537,"p":[{"n":"value","p":786433}],"n":"ToJS","o":"@$34","d":1350397,"h":429498079997,"f":1},{"r":65537,"p":[{"n":"value","p":$.$typeNullable($.$spc.System.IntPtr).$h,"f":2}],"n":"ToManaged","o":"@$35","d":1350397,"h":433793047293,"f":1},{"r":65537,"p":[{"n":"value","p":$.$typeNullable($.$spc.System.IntPtr).$h}],"n":"ToJS","o":"@$35","d":1350397,"h":438088014589,"f":1},{"r":65537,"p":[{"n":"value","p":0,"f":2}],"n":"ToManaged","o":"@$36","d":1350397,"h":442382981885,"f":1},{"r":65537,"p":[{"n":"value","p":0}],"n":"ToJS","o":"@$36","d":1350397,"h":446677949181,"f":1},{"r":65537,"p":[{"n":"value","p":131073,"f":2}],"n":"ToManaged","o":"@$37","d":1350397,"h":450972916477,"f":1},{"r":65537,"p":[{"n":"value","p":131073}],"n":"ToJS","o":"@$37","d":1350397,"h":455267883773,"f":1},{"r":65537,"p":[{"n":"value","p":0,"f":2}],"n":"ToManaged","o":"@$38","d":1350397,"h":459562851069,"f":1},{"r":65537,"p":[{"n":"value","p":0}],"n":"ToJS","o":"@$38","d":1350397,"h":463857818365,"f":1},{"r":65537,"p":[{"n":"value","p":655361,"f":2}],"n":"ToManaged","o":"@$39","d":1350397,"h":468152785661,"f":1},{"r":65537,"p":[{"n":"value","p":655361}],"n":"ToJS","o":"@$39","d":1350397,"h":472447752957,"f":1},{"r":65537,"p":[{"n":"value","p":$.$typeNullable($.$spc.System.Int32).$h,"f":2}],"n":"ToManaged","o":"@$40","d":1350397,"h":476742720253,"f":1},{"r":65537,"p":[{"n":"value","p":$.$typeNullable($.$spc.System.Int32).$h}],"n":"ToJS","o":"@$40","d":1350397,"h":481037687549,"f":1},{"r":65537,"p":[{"n":"value","p":0,"f":2}],"n":"ToManaged","o":"@$41","d":1350397,"h":485332654845,"f":1},{"r":65537,"p":[{"n":"value","p":0}],"n":"ToJS","o":"@$41","d":1350397,"h":489627622141,"f":1},{"r":65537,"p":[{"n":"value","p":$.$spc.System.ArraySegment$$($.$spc.System.Int32).$h,"f":2}],"n":"ToManaged","o":"@$42","d":1350397,"h":493922589437,"f":1},{"r":65537,"p":[{"n":"value","p":$.$spc.System.ArraySegment$$($.$spc.System.Int32).$h}],"n":"ToJS","o":"@$42","d":1350397,"h":498217556733,"f":1},{"r":65537,"p":[{"n":"value","p":$.$spc.System.Span$$($.$spc.System.Int32).$h,"f":2}],"n":"ToManaged","o":"@$43","d":1350397,"h":502512524029,"f":1},{"r":65537,"p":[{"n":"value","p":$.$spc.System.Span$$($.$spc.System.Int32).$h}],"n":"ToJS","o":"@$43","d":1350397,"h":506807491325,"f":1},{"r":65537,"p":[{"n":"value","p":2267901,"f":2}],"n":"ToManaged","o":"@$44","d":1350397,"h":511102458621,"f":1},{"r":65537,"p":[{"n":"value","p":2267901}],"n":"ToJS","o":"@$44","d":1350397,"h":515397425917,"f":1},{"r":65537,"p":[{"n":"value","p":0,"f":2}],"n":"ToManaged","o":"@$45","d":1350397,"h":519692393213,"f":1},{"r":65537,"p":[{"n":"value","p":0}],"n":"ToJS","o":"@$45","d":1350397,"h":523987360509,"f":1},{"r":65537,"p":[{"n":"value","p":1310721,"f":2}],"n":"ToManaged","o":"@$46","d":1350397,"h":528282327805,"f":1},{"r":65537,"p":[{"n":"value","p":1310721}],"n":"ToJS","o":"@$46","d":1350397,"h":532577295101,"f":1},{"r":65537,"p":[{"n":"value","p":0,"f":2}],"n":"ToManaged","o":"@$47","d":1350397,"h":536872262397,"f":1},{"r":65537,"p":[{"n":"value","p":0}],"n":"ToJS","o":"@$47","d":1350397,"h":541167229693,"f":1},{"r":65537,"p":[{"n":"value","p":47185921,"f":2}],"n":"ToManaged","o":"@$48","d":1350397,"h":545462196989,"f":1},{"r":65537,"p":[{"n":"value","p":47185921}],"n":"ToJS","o":"@$48","d":1350397,"h":549757164285,"f":1}],"l":[{"t":2136829,"n":"slot","d":1350397,"h":4296317693,"f":8},{"t":917505,"n":"I52_MAX_VALUE","d":1350397,"h":236224551677,"f":34},{"t":917505,"n":"I52_MIN_VALUE","d":1350397,"h":240519518973,"f":34}],"c":[{"n":".ctor","o":"$ctor$2","d":1350397,"h":554052131581,"f":1}],"j":[2136829,1415933,1612541,1547005,1481469,2005757,1940221,1874685,1809149,1743613,1678077,2071293],"h":1350397,"a":[{"t":114950145,"c":4409917441,"a":[{"v":"browser","t":1310721}]},{"t":23396353,"c":8613330945,"a":[{"v":false,"t":262145}]},{"t":33161217,"c":4328128513,"a":[{"v":1,"t":33226753}]}]}; }
            static get $b() { return $.$spc.System.ValueType; }
            static get $fullName() { return `System.Runtime.InteropServices.JavaScript.JSMarshalerArgument`; }
        });
        
        $asm.$cls("$srij.System.Runtime.InteropServices.JavaScript.JSExportAttribute", ($self) => class JSExportAttribute extends $.$spc.System.Attribute
        {
            $ctor$2()
            {
                super.$ctor$1();
                {
                }
                return this;
            }
            static $h = 498429;
            static $f = 0b10010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":14483457,"c":[{"n":".ctor","o":"$ctor$2","d":498429,"h":4295465725,"f":1}],"h":498429,"a":[{"t":14614529,"c":21489451009,"a":[{"v":64,"t":14548993}],"n":[{"n":"Inherited","v":false,"t":262145},{"n":"AllowMultiple","v":false,"t":262145}]},{"t":114950145,"c":4409917441,"a":[{"v":"browser","t":1310721}]}]}; }
            static get $b() { return $.$spc.System.Attribute; }
            static get $fullName() { return `System.Runtime.InteropServices.JavaScript.JSExportAttribute`; }
        });
        
        $asm.$cls("$srij.System.Runtime.InteropServices.JavaScript.JSImportAttribute", ($self) => class JSImportAttribute extends $.$spc.System.Attribute
        {
            /*string*/ FunctionName = null;
            /*string?*/ ModuleName = null;
            $ctor$2(/*string*/ functionName)
            {
                super.$ctor$1();
                {
                    this.FunctionName = functionName;
                }
                return this;
            }
            $ctor$3(/*string*/ functionName, /*string*/ moduleName)
            {
                super.$ctor$1();
                {
                    this.FunctionName = functionName;
                    this.ModuleName = moduleName;
                }
                return this;
            }
            static $h = 1219325;
            static $f = 0b10010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":14483457,"p":[{"p":1310721,"g":{"r":0,"d":0,"h":12886121213,"f":1},"n":"FunctionName","d":1219325,"h":8591153917,"f":1},{"p":1310721,"g":{"r":0,"d":0,"h":25771023101,"f":1},"n":"ModuleName","d":1219325,"h":21476055805,"f":1}],"c":[{"p":[{"n":"functionName","p":1310721}],"n":".ctor","o":"$ctor$2","d":1219325,"h":30065990397,"f":1},{"p":[{"n":"functionName","p":1310721},{"n":"moduleName","p":1310721}],"n":".ctor","o":"$ctor$3","d":1219325,"h":34360957693,"f":1}],"h":1219325,"a":[{"t":14614529,"c":21489451009,"a":[{"v":64,"t":14548993}],"n":[{"n":"Inherited","v":false,"t":262145},{"n":"AllowMultiple","v":false,"t":262145}]},{"t":114950145,"c":4409917441,"a":[{"v":"browser","t":1310721}]}]}; }
            static get $b() { return $.$spc.System.Attribute; }
            static get $fullName() { return `System.Runtime.InteropServices.JavaScript.JSImportAttribute`; }
        });
        
        $asm.$str("$srij.System.Runtime.InteropServices.JavaScript.MarshalerType", ($self) => class MarshalerType extends $.$spc.System.Enum
        {
            static None = 0;
            static Void = 1;
            static Discard = 2;
            static Boolean = 3;
            static Byte = 4;
            static Char = 5;
            static Int16 = 6;
            static Int32 = 7;
            static Int52 = 8;
            static BigInt64 = 9;
            static Double = 10;
            static Single = 11;
            static IntPtr = 12;
            static JSObject = 13;
            static Object = 14;
            static String = 15;
            static Exception = 16;
            static DateTime = 17;
            static DateTimeOffset = 18;
            static Nullable = 19;
            static Task = 20;
            static Array = 21;
            static ArraySegment = 22;
            static Span = 23;
            static Action = 24;
            static Function = 25;
            static DiscardNoWait = 26;
            static JSException = 27;
            static TaskResolved = 28;
            static TaskRejected = 29;
            static TaskPreCreated = 30;
            static $map;
            static get Map()
            {
                return this.$map ??= 
                {
                    "None": 0n,
                    "Void": 1n,
                    "Discard": 2n,
                    "Boolean": 3n,
                    "Byte": 4n,
                    "Char": 5n,
                    "Int16": 6n,
                    "Int32": 7n,
                    "Int52": 8n,
                    "BigInt64": 9n,
                    "Double": 10n,
                    "Single": 11n,
                    "IntPtr": 12n,
                    "JSObject": 13n,
                    "Object": 14n,
                    "String": 15n,
                    "Exception": 16n,
                    "DateTime": 17n,
                    "DateTimeOffset": 18n,
                    "Nullable": 19n,
                    "Task": 20n,
                    "Array": 21n,
                    "ArraySegment": 22n,
                    "Span": 23n,
                    "Action": 24n,
                    "Function": 25n,
                    "DiscardNoWait": 26n,
                    "JSException": 27n,
                    "TaskResolved": 28n,
                    "TaskRejected": 29n,
                    "TaskPreCreated": 30n
                };
            }
            static $h = 3709693;
            static $z = 1;
            static $f = 0b100000011010001000;
            static $k = 4;
            static get $eut() { return $.$spc.System.Byte; }
            static $$md;
            static get $md() { return this.$$md ??= {"b":1048577,"u":393217,"l":[{"t":3709693,"n":"None","d":3709693,"h":4298676989,"f":33},{"t":3709693,"n":"Void","d":3709693,"h":8593644285,"f":33},{"t":3709693,"n":"Discard","d":3709693,"h":12888611581,"f":33},{"t":3709693,"n":"Boolean","d":3709693,"h":17183578877,"f":33},{"t":3709693,"n":"Byte","d":3709693,"h":21478546173,"f":33},{"t":3709693,"n":"Char","d":3709693,"h":25773513469,"f":33},{"t":3709693,"n":"Int16","d":3709693,"h":30068480765,"f":33},{"t":3709693,"n":"Int32","d":3709693,"h":34363448061,"f":33},{"t":3709693,"n":"Int52","d":3709693,"h":38658415357,"f":33},{"t":3709693,"n":"BigInt64","d":3709693,"h":42953382653,"f":33},{"t":3709693,"n":"Double","d":3709693,"h":47248349949,"f":33},{"t":3709693,"n":"Single","d":3709693,"h":51543317245,"f":33},{"t":3709693,"n":"IntPtr","d":3709693,"h":55838284541,"f":33},{"t":3709693,"n":"JSObject","d":3709693,"h":60133251837,"f":33},{"t":3709693,"n":"Object","d":3709693,"h":64428219133,"f":33},{"t":3709693,"n":"String","d":3709693,"h":68723186429,"f":33},{"t":3709693,"n":"DateTime","d":3709693,"h":77313121021,"f":33},{"t":3709693,"n":"DateTimeOffset","d":3709693,"h":81608088317,"f":33},{"t":3709693,"n":"Nullable","d":3709693,"h":85903055613,"f":33},{"t":3709693,"n":"Task","d":3709693,"h":90198022909,"f":33},{"t":3709693,"n":"Array","d":3709693,"h":94492990205,"f":33},{"t":3709693,"n":"ArraySegment","d":3709693,"h":98787957501,"f":33},{"t":3709693,"n":"Span","d":3709693,"h":103082924797,"f":33},{"t":3709693,"n":"Action","d":3709693,"h":107377892093,"f":33},{"t":3709693,"n":"Function","d":3709693,"h":111672859389,"f":33},{"t":3709693,"n":"DiscardNoWait","d":3709693,"h":115967826685,"f":33},{"t":3709693,"n":"TaskResolved","d":3709693,"h":124557761277,"f":33},{"t":3709693,"n":"TaskRejected","d":3709693,"h":128852728573,"f":33},{"t":3709693,"n":"TaskPreCreated","d":3709693,"h":133147695869,"f":33}],"c":[{"n":".ctor","o":"$ctor$3","d":3709693,"h":137442663165,"f":1}],"i":[57212929,63766529,57671681,57344001],"h":3709693}; }
            static get $b() { return $.$spc.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IComparable, $.$spc.System.ISpanFormattable, $.$spc.System.IFormattable, $.$spc.System.IConvertible ]; }
            static get $fullName() { return `System.Runtime.InteropServices.JavaScript.MarshalerType`; }
        });
        
        $asm.$cls("$srij.System.Runtime.InteropServices.JavaScript.JSException", ($self) => class JSException extends $.$spc.System.Exception
        {
            /*JSObject?*/ jsException = null;
            /*string?*/ combinedStackTrace = null;
            $ctor$5(/*string*/ msg)
            {
                super.$ctor$2(msg);
                {
                    this.jsException = null;
                    this.combinedStackTrace = null;
                }
                return this;
            }
            $ctor$6(/*string*/ msg, /*JSObject?*/ jsException)
            {
                super.$ctor$2(msg);
                {
                    this.jsException = jsException;
                    this.combinedStackTrace = null;
                }
                return this;
            }
            /*string? */ get StackTrace()
            {
                if ($.$spc.System.String.op_Inequality(this.combinedStackTrace, null))
                {
                    return this.combinedStackTrace;
                }
                /*var*/ let bs = super.StackTrace;
                if (this.jsException === null)
                {
                    return bs;
                }
                /*string?*/ let jsStackTrace = this.jsException.GetPropertyAsString("stack");
                this.jsException.Dispose();
                this.jsException = null;
                if ($.$spc.System.String.op_Equality(jsStackTrace, null))
                {
                    this.combinedStackTrace = bs;
                    return this.combinedStackTrace;
                }
                else if ($.$spc.System.String.StartsWith.call(jsStackTrace, this.Message + "\n"))
                {
                    jsStackTrace = $.$spc.System.String.Substring.call(jsStackTrace, ((this.Message.length + 1) | 0));
                }
                if ($.$spc.System.String.op_Equality(bs, null))
                {
                    this.combinedStackTrace = jsStackTrace;
                }
                this.combinedStackTrace = $.$spc.System.String.op_Inequality(bs, null) ? bs + $.$spc.System.Environment.NewLine + jsStackTrace : jsStackTrace;
                return this.combinedStackTrace;
            }
            static/*conventional*/ /*bool */ Equals(/*object?*/ obj)
            {
                let other;
                return $.$is(obj, $.$srij.System.Runtime.InteropServices.JavaScript.JSException, { set $v(v){ other = v; } }) && other.jsException === this.jsException;
            }
            //Static convention instance redirect
            /*bool */ Equals() { return $.$srij.System.Runtime.InteropServices.JavaScript.JSException.Equals.apply(this, arguments); }
            static/*conventional*/ /*int */ GetHashCode()
            {
                return this.jsException === null ? $.$spc.System.Object.GetHashCode.call(this) : (($.$spc.System.Object.GetHashCode.call(this) * $.$srij.System.Runtime.InteropServices.JavaScript.JSObject.GetHashCode.call(this.jsException)) | 0);
            }
            //Static convention instance redirect
            /*int */ GetHashCode() { return $.$srij.System.Runtime.InteropServices.JavaScript.JSException.GetHashCode.apply(this, arguments); }
            static/*conventional*/ /*string */ ToString()
            {
                return this.Message;
            }
            //Static convention instance redirect
            /*string */ ToString() { return $.$srij.System.Runtime.InteropServices.JavaScript.JSException.ToString.apply(this, arguments); }
            static $h = 432893;
            static $f = 0b10010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":47185921,"h":432893}; }
            static get $b() { return $.$spc.System.Exception; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.Runtime.Serialization.ISerializable ]; }
            static get $fullName() { return `System.Runtime.InteropServices.JavaScript.JSException`; }
        });
	});
})(window, window.NetJs.$boot(), ...window.NetJs.$require("NetJs.System.Private.CoreLib", "NetJs.System.Collections", "NetJs.System.Diagnostics.Tracing", "NetJs.System.Memory", "NetJs.System.Private.Uri", "NetJs.System.Threading", "NetJs.System.Threading.ThreadPool", "NetJs.System.Runtime", "NetJs.System.Collections.Concurrent", "NetJs.System.Threading.Channels"))