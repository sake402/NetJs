
//--TRIMMABLE-BOUNDARY-START(7)
(function ($global, $, $$, $sc, $sdt, $st, $scc) {
    "use strict";
    let _;
    
    
    
	$.$asm(
    "NetJs.System.Runtime.InteropServices", 
    {
  "h": 7,
  "f": "System.Runtime.InteropServices",
  "v": "1.0.35.0",
  "a": [
    {
      "t": 159121409,
      "c": 13044023297,
      "a": [
        {
          "v": ".NETCoreApp,Version=v10.0",
          "t": 1310721
        }
      ],
      "n": [
        {
          "n": "FrameworkDisplayName",
          "v": ".NET 10.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 106299393,
      "c": 4401266689,
      "a": [
        {
          "v": "SIT",
          "t": 1310721
        }
      ]
    },
    {
      "t": 106364929,
      "c": 4401332225,
      "a": [
        {
          "v": "Debug",
          "t": 1310721
        }
      ]
    },
    {
      "t": 106823681,
      "c": 4401790977,
      "a": [
        {
          "v": "1.0.35.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 106954753,
      "c": 4401922049,
      "a": [
        {
          "v": "1.0.35\u002B39e7ca3e4bf1d7d75afdb3a3db320b6c1a1b2fcf",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107806721,
      "c": 4402774017,
      "a": [
        {
          "v": "NetJs.System.Runtime.InteropServices",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107937793,
      "c": 4402905089,
      "a": [
        {
          "v": "NetJs.System.Runtime.InteropServices",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108068865,
      "c": 4403036161,
      "a": [
        {
          "v": "1.0.35.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 159186945,
      "c": 4454154241,
      "a": [
        {
          "v": "browser1.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 158924801,
      "c": 4453892097,
      "a": [
        {
          "v": "browser1.0",
          "t": 1310721
        }
      ]
    }
  ],
  "m": []
},
    function($asm)
	{
        
        
        //--TRIMMABLE-BOUNDARY-START(983047)
        $asm.$cls("$sris.System.Runtime.InteropServices.ComTypes.IAdviseSink", ($self) => class IAdviseSink
        {
            static $h = 983047;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8590917639),
    {
      "r": 65537,
      "p": [
        {
          "n": "format",
          "p": 917511,
          "f": 4,
          "a": [
            {
              "t": 142213121,
              "c": 4437180417
            }
          ]
        },
        {
          "n": "stgmedium",
          "p": 1310727,
          "f": 4,
          "a": [
            {
              "t": 142213121,
              "c": 4437180417
            }
          ]
        }
      ],
      "n": "OnDataChange",
      "o": "System$Runtime$InteropServices$ComTypes$IAdviseSink$OnDataChange",
      "d": 983047,
      "h": 8590917639,
      "f": 16777473,
      "a": [
        {
          "t": 146538497,
          "c": 4441505793
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(8590917639),
//--TRIMMABLE-BOUNDARY-START(21475819527),
    {
      "r": 65537,
      "p": [
        {
          "n": "aspect",
          "p": 655361
        },
        {
          "n": "index",
          "p": 655361
        }
      ],
      "n": "OnViewChange",
      "o": "System$Runtime$InteropServices$ComTypes$IAdviseSink$OnViewChange",
      "d": 983047,
      "h": 21475819527,
      "f": 16777473,
      "a": [
        {
          "t": 146538497,
          "c": 4441505793
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(21475819527),
//--TRIMMABLE-BOUNDARY-START(12885884935),
    {
      "r": 65537,
      "p": [
        {
          "n": "moniker",
          "p": 138280961
        }
      ],
      "n": "OnRename",
      "o": "System$Runtime$InteropServices$ComTypes$IAdviseSink$OnRename",
      "d": 983047,
      "h": 12885884935,
      "f": 16777473,
      "a": [
        {
          "t": 146538497,
          "c": 4441505793
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(12885884935),
//--TRIMMABLE-BOUNDARY-START(17180852231),
    {
      "r": 65537,
      "n": "OnSave",
      "o": "System$Runtime$InteropServices$ComTypes$IAdviseSink$OnSave",
      "d": 983047,
      "h": 17180852231,
      "f": 16777473,
      "a": [
        {
          "t": 146538497,
          "c": 4441505793
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(17180852231),
//--TRIMMABLE-BOUNDARY-START(4295950343),
    {
      "r": 65537,
      "n": "OnClose",
      "o": "System$Runtime$InteropServices$ComTypes$IAdviseSink$OnClose",
      "d": 983047,
      "h": 4295950343,
      "f": 16777473,
      "a": [
        {
          "t": 146538497,
          "c": 4441505793
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(4295950343)
  ],
  "h": 983047,
  "a": [
    {
      "t": 136511489,
      "c": 4431478785
    },
    {
      "t": 141754369,
      "c": 4436721665,
      "a": [
        {
          "v": "0000010F-0000-0000-C000-000000000046",
          "t": 1310721
        }
      ]
    },
    {
      "t": 64159745,
      "c": 4359127041,
      "a": [
        {
          "v": 1,
          "t": 64225281
        }
      ]
    },
    {
      "t": 142278657,
      "c": 4437245953,
      "a": [
        {
          "v": 1,
          "t": 136577025
        }
      ]
    }
  ]
}; }
            static get $fullName() { return `System.Runtime.InteropServices.ComTypes.IAdviseSink`; }
        });
        //--TRIMMABLE-BOUNDARY-END(983047)
        
        
        //--TRIMMABLE-BOUNDARY-START(1048583)
        $asm.$cls("$sris.System.Runtime.InteropServices.ComTypes.IDataObject", ($self) => class IDataObject
        {
            static $h = 1048583;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(25770852359),
    {
      "r": 65537,
      "p": [
        {
          "n": "format",
          "p": 917511,
          "f": 4,
          "a": [
            {
              "t": 142213121,
              "c": 4437180417
            }
          ]
        },
        {
          "n": "medium",
          "p": 1310727,
          "f": 2
        }
      ],
      "n": "GetData",
      "o": "System$Runtime$InteropServices$ComTypes$IDataObject$GetData",
      "d": 1048583,
      "h": 25770852359,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(25770852359),
//--TRIMMABLE-BOUNDARY-START(30065819655),
    {
      "r": 65537,
      "p": [
        {
          "n": "format",
          "p": 917511,
          "f": 4,
          "a": [
            {
              "t": 142213121,
              "c": 4437180417
            }
          ]
        },
        {
          "n": "medium",
          "p": 1310727,
          "f": 4
        }
      ],
      "n": "GetDataHere",
      "o": "System$Runtime$InteropServices$ComTypes$IDataObject$GetDataHere",
      "d": 1048583,
      "h": 30065819655,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(30065819655),
//--TRIMMABLE-BOUNDARY-START(34360786951),
    {
      "r": 655361,
      "p": [
        {
          "n": "format",
          "p": 917511,
          "f": 4,
          "a": [
            {
              "t": 142213121,
              "c": 4437180417
            }
          ]
        }
      ],
      "n": "QueryGetData",
      "o": "System$Runtime$InteropServices$ComTypes$IDataObject$QueryGetData",
      "d": 1048583,
      "h": 34360786951,
      "f": 16777473,
      "a": [
        {
          "t": 146538497,
          "c": 4441505793
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(34360786951),
//--TRIMMABLE-BOUNDARY-START(21475885063),
    {
      "r": 655361,
      "p": [
        {
          "n": "formatIn",
          "p": 917511,
          "f": 4,
          "a": [
            {
              "t": 142213121,
              "c": 4437180417
            }
          ]
        },
        {
          "n": "formatOut",
          "p": 917511,
          "f": 2
        }
      ],
      "n": "GetCanonicalFormatEtc",
      "o": "System$Runtime$InteropServices$ComTypes$IDataObject$GetCanonicalFormatEtc",
      "d": 1048583,
      "h": 21475885063,
      "f": 16777473,
      "a": [
        {
          "t": 146538497,
          "c": 4441505793
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(21475885063),
//--TRIMMABLE-BOUNDARY-START(38655754247),
    {
      "r": 65537,
      "p": [
        {
          "n": "formatIn",
          "p": 917511,
          "f": 4,
          "a": [
            {
              "t": 142213121,
              "c": 4437180417
            }
          ]
        },
        {
          "n": "medium",
          "p": 1310727,
          "f": 4,
          "a": [
            {
              "t": 142213121,
              "c": 4437180417
            }
          ]
        },
        {
          "n": "release",
          "p": 262145,
          "a": [
            {
              "t": 143065089,
              "c": 4438032385,
              "a": [
                {
                  "v": 2,
                  "t": 148242433
                }
              ]
            }
          ]
        }
      ],
      "n": "SetData",
      "o": "System$Runtime$InteropServices$ComTypes$IDataObject$SetData",
      "d": 1048583,
      "h": 38655754247,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(38655754247),
//--TRIMMABLE-BOUNDARY-START(17180917767),
    {
      "r": 1114119,
      "p": [
        {
          "n": "direction",
          "p": 786439
        }
      ],
      "n": "EnumFormatEtc",
      "o": "System$Runtime$InteropServices$ComTypes$IDataObject$EnumFormatEtc",
      "d": 1048583,
      "h": 17180917767,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(17180917767),
//--TRIMMABLE-BOUNDARY-START(4296015879),
    {
      "r": 655361,
      "p": [
        {
          "n": "pFormatetc",
          "p": 917511,
          "f": 4,
          "a": [
            {
              "t": 142213121,
              "c": 4437180417
            }
          ]
        },
        {
          "n": "advf",
          "p": 720903
        },
        {
          "n": "adviseSink",
          "p": 983047
        },
        {
          "n": "connection",
          "p": 655361,
          "f": 2
        }
      ],
      "n": "DAdvise",
      "o": "System$Runtime$InteropServices$ComTypes$IDataObject$DAdvise",
      "d": 1048583,
      "h": 4296015879,
      "f": 16777473,
      "a": [
        {
          "t": 146538497,
          "c": 4441505793
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(4296015879),
//--TRIMMABLE-BOUNDARY-START(8590983175),
    {
      "r": 65537,
      "p": [
        {
          "n": "connection",
          "p": 655361
        }
      ],
      "n": "DUnadvise",
      "o": "System$Runtime$InteropServices$ComTypes$IDataObject$DUnadvise",
      "d": 1048583,
      "h": 8590983175,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(8590983175),
//--TRIMMABLE-BOUNDARY-START(12885950471),
    {
      "r": 655361,
      "p": [
        {
          "n": "enumAdvise",
          "p": 1179655,
          "f": 2
        }
      ],
      "n": "EnumDAdvise",
      "o": "System$Runtime$InteropServices$ComTypes$IDataObject$EnumDAdvise",
      "d": 1048583,
      "h": 12885950471,
      "f": 16777473,
      "a": [
        {
          "t": 146538497,
          "c": 4441505793
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(12885950471)
  ],
  "h": 1048583,
  "a": [
    {
      "t": 54132737,
      "c": 8644067329,
      "a": [
        {
          "v": false,
          "t": 262145
        }
      ]
    },
    {
      "t": 136511489,
      "c": 4431478785
    },
    {
      "t": 141754369,
      "c": 4436721665,
      "a": [
        {
          "v": "0000010E-0000-0000-C000-000000000046",
          "t": 1310721
        }
      ]
    },
    {
      "t": 142278657,
      "c": 4437245953,
      "a": [
        {
          "v": 1,
          "t": 136577025
        }
      ]
    }
  ]
}; }
            static get $fullName() { return `System.Runtime.InteropServices.ComTypes.IDataObject`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1048583)
        
        
        //--TRIMMABLE-BOUNDARY-START(1179655)
        $asm.$cls("$sris.System.Runtime.InteropServices.ComTypes.IEnumSTATDATA", ($self) => class IEnumSTATDATA
        {
            static $h = 1179655;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8591114247),
    {
      "r": 655361,
      "p": [
        {
          "n": "celt",
          "p": 655361
        },
        {
          "n": "rgelt",
          "p": $.$typeArray($.$sris.System.Runtime.InteropServices.ComTypes.STATDATA).$h,
          "a": [
            {
              "t": 146145281,
              "c": 4441112577
            },
            {
              "t": 143065089,
              "c": 4438032385,
              "a": [
                {
                  "v": 42,
                  "t": 148242433
                }
              ],
              "n": [
                {
                  "n": "SizeParamIndex",
                  "v": 0,
                  "t": 524289
                }
              ]
            }
          ]
        },
        {
          "n": "pceltFetched",
          "p": $.$typeArray($.$$.System.Int32).$h,
          "a": [
            {
              "t": 146145281,
              "c": 4441112577
            },
            {
              "t": 143065089,
              "c": 4438032385,
              "a": [
                {
                  "v": 42,
                  "t": 148242433
                }
              ],
              "n": [
                {
                  "n": "SizeConst",
                  "v": 1,
                  "t": 655361
                }
              ]
            }
          ]
        }
      ],
      "n": "Next",
      "o": "System$Runtime$InteropServices$ComTypes$IEnumSTATDATA$Next",
      "d": 1179655,
      "h": 8591114247,
      "f": 16777473,
      "a": [
        {
          "t": 146538497,
          "c": 4441505793
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(8591114247),
//--TRIMMABLE-BOUNDARY-START(17181048839),
    {
      "r": 655361,
      "p": [
        {
          "n": "celt",
          "p": 655361
        }
      ],
      "n": "Skip",
      "o": "System$Runtime$InteropServices$ComTypes$IEnumSTATDATA$Skip",
      "d": 1179655,
      "h": 17181048839,
      "f": 16777473,
      "a": [
        {
          "t": 146538497,
          "c": 4441505793
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(17181048839),
//--TRIMMABLE-BOUNDARY-START(12886081543),
    {
      "r": 655361,
      "n": "Reset",
      "o": "System$Runtime$InteropServices$ComTypes$IEnumSTATDATA$Reset",
      "d": 1179655,
      "h": 12886081543,
      "f": 16777473,
      "a": [
        {
          "t": 146538497,
          "c": 4441505793
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(12886081543),
//--TRIMMABLE-BOUNDARY-START(4296146951),
    {
      "r": 65537,
      "p": [
        {
          "n": "newEnum",
          "p": 1179655,
          "f": 2
        }
      ],
      "n": "Clone",
      "o": "System$Runtime$InteropServices$ComTypes$IEnumSTATDATA$Clone",
      "d": 1179655,
      "h": 4296146951,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(4296146951)
  ],
  "h": 1179655,
  "a": [
    {
      "t": 136511489,
      "c": 4431478785
    },
    {
      "t": 141754369,
      "c": 4436721665,
      "a": [
        {
          "v": "00000105-0000-0000-C000-000000000046",
          "t": 1310721
        }
      ]
    },
    {
      "t": 142278657,
      "c": 4437245953,
      "a": [
        {
          "v": 1,
          "t": 136577025
        }
      ]
    }
  ]
}; }
            static get $fullName() { return `System.Runtime.InteropServices.ComTypes.IEnumSTATDATA`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1179655)
        
        
        //--TRIMMABLE-BOUNDARY-START(1114119)
        $asm.$cls("$sris.System.Runtime.InteropServices.ComTypes.IEnumFORMATETC", ($self) => class IEnumFORMATETC
        {
            static $h = 1114119;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8591048711),
    {
      "r": 655361,
      "p": [
        {
          "n": "celt",
          "p": 655361
        },
        {
          "n": "rgelt",
          "p": $.$typeArray($.$sris.System.Runtime.InteropServices.ComTypes.FORMATETC).$h,
          "a": [
            {
              "t": 146145281,
              "c": 4441112577
            },
            {
              "t": 143065089,
              "c": 4438032385,
              "a": [
                {
                  "v": 42,
                  "t": 148242433
                }
              ],
              "n": [
                {
                  "n": "SizeParamIndex",
                  "v": 0,
                  "t": 524289
                }
              ]
            }
          ]
        },
        {
          "n": "pceltFetched",
          "p": $.$typeArray($.$$.System.Int32).$h,
          "a": [
            {
              "t": 146145281,
              "c": 4441112577
            },
            {
              "t": 143065089,
              "c": 4438032385,
              "a": [
                {
                  "v": 42,
                  "t": 148242433
                }
              ]
            }
          ]
        }
      ],
      "n": "Next",
      "o": "System$Runtime$InteropServices$ComTypes$IEnumFORMATETC$Next",
      "d": 1114119,
      "h": 8591048711,
      "f": 16777473,
      "a": [
        {
          "t": 146538497,
          "c": 4441505793
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(8591048711),
//--TRIMMABLE-BOUNDARY-START(17180983303),
    {
      "r": 655361,
      "p": [
        {
          "n": "celt",
          "p": 655361
        }
      ],
      "n": "Skip",
      "o": "System$Runtime$InteropServices$ComTypes$IEnumFORMATETC$Skip",
      "d": 1114119,
      "h": 17180983303,
      "f": 16777473,
      "a": [
        {
          "t": 146538497,
          "c": 4441505793
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(17180983303),
//--TRIMMABLE-BOUNDARY-START(12886016007),
    {
      "r": 655361,
      "n": "Reset",
      "o": "System$Runtime$InteropServices$ComTypes$IEnumFORMATETC$Reset",
      "d": 1114119,
      "h": 12886016007,
      "f": 16777473,
      "a": [
        {
          "t": 146538497,
          "c": 4441505793
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(12886016007),
//--TRIMMABLE-BOUNDARY-START(4296081415),
    {
      "r": 65537,
      "p": [
        {
          "n": "newEnum",
          "p": 1114119,
          "f": 2
        }
      ],
      "n": "Clone",
      "o": "System$Runtime$InteropServices$ComTypes$IEnumFORMATETC$Clone",
      "d": 1114119,
      "h": 4296081415,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(4296081415)
  ],
  "h": 1114119,
  "a": [
    {
      "t": 136511489,
      "c": 4431478785
    },
    {
      "t": 141754369,
      "c": 4436721665,
      "a": [
        {
          "v": "00000103-0000-0000-C000-000000000046",
          "t": 1310721
        }
      ]
    },
    {
      "t": 64159745,
      "c": 4359127041,
      "a": [
        {
          "v": 1,
          "t": 64225281
        }
      ]
    },
    {
      "t": 142278657,
      "c": 4437245953,
      "a": [
        {
          "v": 1,
          "t": 136577025
        }
      ]
    }
  ]
}; }
            static get $fullName() { return `System.Runtime.InteropServices.ComTypes.IEnumFORMATETC`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1114119)
        
        
        //--TRIMMABLE-BOUNDARY-START(3342343)
        $asm.$cls("$sris.System.Runtime.InteropServices.Marshalling.IIUnknownInterfaceType", ($self) => class IIUnknownInterfaceType
        {
            static $h = 3342343;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(21478178823),
    {
      "p": 88866817,
      "g": {
        "r": 0,
        "d": 0,
        "h": 8593276935,
        "f": 50331937
      },
      "n": "Iid",
      "o": "System$Runtime$InteropServices$Marshalling$IIUnknownInterfaceType$Iid",
      "d": 3342343,
      "h": 21478178823,
      "f": 2097441
    },
//--TRIMMABLE-BOUNDARY-END(21478178823),
//--TRIMMABLE-BOUNDARY-START(25773146119),
    {
      "p": $.$typePointer($.$typePointer($.$$.System.Void)).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 17183211527,
        "f": 50331937
      },
      "n": "ManagedVirtualMethodTable",
      "o": "System$Runtime$InteropServices$Marshalling$IIUnknownInterfaceType$ManagedVirtualMethodTable",
      "d": 3342343,
      "h": 25773146119,
      "f": 2097441
    },
//--TRIMMABLE-BOUNDARY-END(25773146119)
  ],
  "h": 3342343,
  "a": [
    {
      "t": 54132737,
      "c": 8644067329,
      "a": [
        {
          "v": false,
          "t": 262145
        }
      ]
    }
  ]
}; }
            static get $fullName() { return `System.Runtime.InteropServices.Marshalling.IIUnknownInterfaceType`; }
        });
        //--TRIMMABLE-BOUNDARY-END(3342343)
        
        
        //--TRIMMABLE-BOUNDARY-START(3276807)
        $asm.$cls("$sris.System.Runtime.InteropServices.Marshalling.IIUnknownInterfaceDetailsStrategy", ($self) => class IIUnknownInterfaceDetailsStrategy
        {
            static $h = 3276807;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8593211399),
    {
      "r": 3211271,
      "p": [
        {
          "n": "type",
          "p": 160038913
        }
      ],
      "n": "GetIUnknownDerivedDetails",
      "o": "System$Runtime$InteropServices$Marshalling$IIUnknownInterfaceDetailsStrategy$GetIUnknownDerivedDetails",
      "d": 3276807,
      "h": 8593211399,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(8593211399),
//--TRIMMABLE-BOUNDARY-START(4298244103),
    {
      "r": 3014663,
      "p": [
        {
          "n": "type",
          "p": 160038913
        }
      ],
      "n": "GetComExposedTypeDetails",
      "o": "System$Runtime$InteropServices$Marshalling$IIUnknownInterfaceDetailsStrategy$GetComExposedTypeDetails",
      "d": 3276807,
      "h": 4298244103,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(4298244103)
  ],
  "h": 3276807,
  "a": [
    {
      "t": 54132737,
      "c": 8644067329,
      "a": [
        {
          "v": false,
          "t": 262145
        }
      ]
    }
  ]
}; }
            static get $fullName() { return `System.Runtime.InteropServices.Marshalling.IIUnknownInterfaceDetailsStrategy`; }
        });
        //--TRIMMABLE-BOUNDARY-END(3276807)
        
        
        //--TRIMMABLE-BOUNDARY-START(3407879)
        $asm.$cls("$sris.System.Runtime.InteropServices.Marshalling.IIUnknownStrategy", ($self) => class IIUnknownStrategy
        {
            static $h = 3407879;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4298375175),
    {
      "r": $.$typePointer($.$$.System.Void).$h,
      "p": [
        {
          "n": "unknown",
          "p": $.$typePointer($.$$.System.Void).$h
        }
      ],
      "n": "CreateInstancePointer",
      "o": "System$Runtime$InteropServices$Marshalling$IIUnknownStrategy$CreateInstancePointer",
      "d": 3407879,
      "h": 4298375175,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(4298375175),
//--TRIMMABLE-BOUNDARY-START(8593342471),
    {
      "r": 655361,
      "p": [
        {
          "n": "instancePtr",
          "p": $.$typePointer($.$$.System.Void).$h
        },
        {
          "n": "iid",
          "p": 88866817,
          "f": 8
        },
        {
          "n": "ppObj",
          "p": $.$typePointer($.$$.System.Void).$h,
          "f": 2
        }
      ],
      "n": "QueryInterface",
      "o": "System$Runtime$InteropServices$Marshalling$IIUnknownStrategy$QueryInterface",
      "d": 3407879,
      "h": 8593342471,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(8593342471),
//--TRIMMABLE-BOUNDARY-START(12888309767),
    {
      "r": 655361,
      "p": [
        {
          "n": "instancePtr",
          "p": $.$typePointer($.$$.System.Void).$h
        }
      ],
      "n": "Release",
      "o": "System$Runtime$InteropServices$Marshalling$IIUnknownStrategy$Release",
      "d": 3407879,
      "h": 12888309767,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(12888309767)
  ],
  "h": 3407879,
  "a": [
    {
      "t": 54132737,
      "c": 8644067329,
      "a": [
        {
          "v": false,
          "t": 262145
        }
      ]
    }
  ]
}; }
            static get $fullName() { return `System.Runtime.InteropServices.Marshalling.IIUnknownStrategy`; }
        });
        //--TRIMMABLE-BOUNDARY-END(3407879)
        
        
        //--TRIMMABLE-BOUNDARY-START(3538951)
        $asm.$cls("$sris.System.Runtime.InteropServices.Marshalling.IUnmanagedVirtualMethodTableProvider", ($self) => class IUnmanagedVirtualMethodTableProvider
        {
            static $h = 3538951;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4298506247),
    {
      "r": 3735559,
      "p": [
        {
          "n": "type",
          "p": 187629569
        }
      ],
      "n": "GetVirtualMethodTableInfoForKey",
      "o": "System$Runtime$InteropServices$Marshalling$IUnmanagedVirtualMethodTableProvider$GetVirtualMethodTableInfoForKey",
      "d": 3538951,
      "h": 4298506247,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(4298506247)
  ],
  "h": 3538951,
  "a": [
    {
      "t": 54132737,
      "c": 8644067329,
      "a": [
        {
          "v": false,
          "t": 262145
        }
      ]
    }
  ]
}; }
            static get $fullName() { return `System.Runtime.InteropServices.Marshalling.IUnmanagedVirtualMethodTableProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(3538951)
        
        
        //--TRIMMABLE-BOUNDARY-START(2949127)
        $asm.$cls("$sris.System.Runtime.InteropServices.Marshalling.IComExposedClass", ($self) => class IComExposedClass
        {
            static $h = 2949127;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4297916423),
    {
      "r": $.$typePointer($.$$.System.Runtime.InteropServices.ComWrappers.ComInterfaceEntry).$h,
      "p": [
        {
          "n": "count",
          "p": 655361,
          "f": 2
        }
      ],
      "n": "GetComInterfaceEntries",
      "o": "System$Runtime$InteropServices$Marshalling$IComExposedClass$GetComInterfaceEntries",
      "d": 2949127,
      "h": 4297916423,
      "f": 16777505
    },
//--TRIMMABLE-BOUNDARY-END(4297916423)
  ],
  "h": 2949127,
  "a": [
    {
      "t": 54132737,
      "c": 8644067329,
      "a": [
        {
          "v": false,
          "t": 262145
        }
      ]
    }
  ]
}; }
            static get $fullName() { return `System.Runtime.InteropServices.Marshalling.IComExposedClass`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2949127)
        
        
        //--TRIMMABLE-BOUNDARY-START(3080199)
        $asm.$cls("$sris.System.Runtime.InteropServices.Marshalling.IIUnknownCacheStrategy", ($self) => class IIUnknownCacheStrategy
        {
            //--TRIMMABLE-BOUNDARY-START(3145735)
            static $_TableInfo;
            static get TableInfo()
            {
                let $cls = $.$sris.System.Runtime.InteropServices.Marshalling.IIUnknownCacheStrategy;
                return $cls.$_TableInfo ??= $asm.$nstr("$sris.System.Runtime.InteropServices.Marshalling.IIUnknownCacheStrategy.TableInfo", ($self) => class TableInfo extends $.$$.System.ValueType
                {
                    //--TRIMMABLE-BOUNDARY-START(81607524359)
                    /*void**/ ThisPtr;
                    //--TRIMMABLE-BOUNDARY-END(81607524359)
                    
                    //--TRIMMABLE-BOUNDARY-START(77312557063)
                    /*void***/ Table;
                    //--TRIMMABLE-BOUNDARY-END(77312557063)
                    
                    //--TRIMMABLE-BOUNDARY-START(47247785991)
                    /*RuntimeTypeHandle*/ ManagedType;
                    //--TRIMMABLE-BOUNDARY-END(47247785991)
                    
                    //default value type constructor
                    $ctor$2()
                    {
                        return this;
                    }
                    Clone($copy)
                    {
                        let copy = $copy ?? new this.constructor();
                        copy.ThisPtr = this.ThisPtr.Clone();
                        copy.Table = this.Table.Clone();
                        copy.ManagedType = this.ManagedType.Clone();
                        return copy;
                    }
                    //default member initializer
                    constructor()
                    {
                        super();
                        this.ThisPtr = $.$default($.$typePointer($.$$.System.Void));
                        this.Table = $.$default($.$typePointer($.$typePointer($.$$.System.Void)));
                        this.ManagedType = $.$default($.$$.System.RuntimeTypeHandle);
                    }
                    static $h = 3145735;
                    static $z = 12;
                    static $f = 0b10000001010000001;
                    static $k = 2;
                    static $$md;
                    static get $md() { return this.$$md ??= {
  "b": 196609,
  "p": [
//--TRIMMABLE-BOUNDARY-START(81607524359),
    {
      "p": $.$typePointer($.$$.System.Void).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 42952818695,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 73017589767,
        "f": 83886081
      },
      "n": "ThisPtr",
      "d": 3145735,
      "h": 81607524359,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(81607524359),
//--TRIMMABLE-BOUNDARY-START(77312557063),
    {
      "p": $.$typePointer($.$typePointer($.$$.System.Void)).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 34362884103,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 64427655175,
        "f": 83886081
      },
      "n": "Table",
      "d": 3145735,
      "h": 77312557063,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(77312557063),
//--TRIMMABLE-BOUNDARY-START(47247785991),
    {
      "p": 160038913,
      "g": {
        "r": 0,
        "d": 0,
        "h": 25772949511,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 55837720583,
        "f": 83886081
      },
      "n": "ManagedType",
      "d": 3145735,
      "h": 47247785991,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(47247785991)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4298113031),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 3145735,
      "h": 4298113031,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4298113031)
  ],
  "d": 3080199,
  "h": 3145735
}; }
                    static get $b() { return $.$$.System.ValueType; }
                    static get $fullName() { return `System.Runtime.InteropServices.Marshalling.IIUnknownCacheStrategy.TableInfo`; }
                }, $cls, ($v) => $cls.$_TableInfo = $v);
            }
            //--TRIMMABLE-BOUNDARY-END(3145735)
            
            static $h = 3080199;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8593014791),
    {
      "r": 3145735,
      "p": [
        {
          "n": "handle",
          "p": 160038913
        },
        {
          "n": "interfaceDetails",
          "p": 3211271
        },
        {
          "n": "ptr",
          "p": $.$typePointer($.$$.System.Void).$h
        }
      ],
      "n": "ConstructTableInfo",
      "o": "System$Runtime$InteropServices$Marshalling$IIUnknownCacheStrategy$ConstructTableInfo",
      "d": 3080199,
      "h": 8593014791,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(8593014791),
//--TRIMMABLE-BOUNDARY-START(17182949383),
    {
      "r": 262145,
      "p": [
        {
          "n": "handle",
          "p": 160038913
        },
        {
          "n": "info",
          "p": 3145735,
          "f": 2
        }
      ],
      "n": "TryGetTableInfo",
      "o": "System$Runtime$InteropServices$Marshalling$IIUnknownCacheStrategy$TryGetTableInfo",
      "d": 3080199,
      "h": 17182949383,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(17182949383),
//--TRIMMABLE-BOUNDARY-START(21477916679),
    {
      "r": 262145,
      "p": [
        {
          "n": "handle",
          "p": 160038913
        },
        {
          "n": "info",
          "p": 3145735
        }
      ],
      "n": "TrySetTableInfo",
      "o": "System$Runtime$InteropServices$Marshalling$IIUnknownCacheStrategy$TrySetTableInfo",
      "d": 3080199,
      "h": 21477916679,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(21477916679),
//--TRIMMABLE-BOUNDARY-START(4298047495),
    {
      "r": 65537,
      "p": [
        {
          "n": "unknownStrategy",
          "p": 3407879
        }
      ],
      "n": "Clear",
      "o": "System$Runtime$InteropServices$Marshalling$IIUnknownCacheStrategy$Clear",
      "d": 3080199,
      "h": 4298047495,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(4298047495)
  ],
  "j": [3145735
  ],
  "h": 3080199,
  "a": [
    {
      "t": 54132737,
      "c": 8644067329,
      "a": [
        {
          "v": false,
          "t": 262145
        }
      ]
    }
  ]
}; }
            static get $fullName() { return `System.Runtime.InteropServices.Marshalling.IIUnknownCacheStrategy`; }
        });
        //--TRIMMABLE-BOUNDARY-END(3080199)
        
        
        //--TRIMMABLE-BOUNDARY-START(3014663)
        $asm.$cls("$sris.System.Runtime.InteropServices.Marshalling.IComExposedDetails", ($self) => class IComExposedDetails
        {
            //--TRIMMABLE-BOUNDARY-START(8592949255)
            static /*IComExposedDetails? */ System$Runtime$InteropServices$Marshalling$IComExposedDetails$GetFromAttribute(/*RuntimeTypeHandle*/ handle)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8592949255);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let type = $.$$.System.Type.GetTypeFromHandle(handle);
                if (type === null)
                {
                    return null;
                }
                return $.$cast($.$$.System.Reflection.CustomAttributeExtensions.GetCustomAttribute$2(type, $.$sris.System.Runtime.InteropServices.Marshalling.ComExposedClassAttribute$$().$type), $.$sris.System.Runtime.InteropServices.Marshalling.IComExposedDetails);
            }
            //--TRIMMABLE-BOUNDARY-END(8592949255)
            
            static $h = 3014663;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4297981959),
    {
      "r": $.$typePointer($.$$.System.Runtime.InteropServices.ComWrappers.ComInterfaceEntry).$h,
      "p": [
        {
          "n": "count",
          "p": 655361,
          "f": 2
        }
      ],
      "n": "GetComInterfaceEntries",
      "o": "System$Runtime$InteropServices$Marshalling$IComExposedDetails$GetComInterfaceEntries",
      "d": 3014663,
      "h": 4297981959,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(4297981959),
//--TRIMMABLE-BOUNDARY-START(8592949255),
    {
      "r": 3014663,
      "p": [
        {
          "n": "handle",
          "p": 160038913
        }
      ],
      "n": "GetFromAttribute",
      "o": "System$Runtime$InteropServices$Marshalling$IComExposedDetails$GetFromAttribute",
      "d": 3014663,
      "h": 8592949255,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(8592949255)
  ],
  "h": 3014663,
  "a": [
    {
      "t": 54132737,
      "c": 8644067329,
      "a": [
        {
          "v": false,
          "t": 262145
        }
      ]
    }
  ]
}; }
            static get $fullName() { return `System.Runtime.InteropServices.Marshalling.IComExposedDetails`; }
        });
        //--TRIMMABLE-BOUNDARY-END(3014663)
        
        
        //--TRIMMABLE-BOUNDARY-START(3211271)
        $asm.$cls("$sris.System.Runtime.InteropServices.Marshalling.IIUnknownDerivedDetails", ($self) => class IIUnknownDerivedDetails
        {
            //--TRIMMABLE-BOUNDARY-START(30067982343)
            static /*IIUnknownDerivedDetails? */ System$Runtime$InteropServices$Marshalling$IIUnknownDerivedDetails$GetFromAttribute(/*RuntimeTypeHandle*/ handle)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(30067982343);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let type = $.$$.System.Type.GetTypeFromHandle(handle);
                if (type === null)
                {
                    return null;
                }
                return $.$cast($.$$.System.Reflection.CustomAttributeExtensions.GetCustomAttribute$2(type, $.$sris.System.Runtime.InteropServices.Marshalling.IUnknownDerivedAttribute$$$().$type), $.$sris.System.Runtime.InteropServices.Marshalling.IIUnknownDerivedDetails);
            }
            //--TRIMMABLE-BOUNDARY-END(30067982343)
            
            static $h = 3211271;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(34362949639),
    {
      "p": 88866817,
      "g": {
        "r": 0,
        "d": 0,
        "h": 8593145863,
        "f": 50331905
      },
      "n": "Iid",
      "o": "System$Runtime$InteropServices$Marshalling$IIUnknownDerivedDetails$Iid",
      "d": 3211271,
      "h": 34362949639,
      "f": 2097409
    },
//--TRIMMABLE-BOUNDARY-END(34362949639),
//--TRIMMABLE-BOUNDARY-START(38657916935),
    {
      "p": 187629569,
      "g": {
        "r": 0,
        "d": 0,
        "h": 17183080455,
        "f": 50331905
      },
      "n": "Implementation",
      "o": "System$Runtime$InteropServices$Marshalling$IIUnknownDerivedDetails$Implementation",
      "d": 3211271,
      "h": 38657916935,
      "f": 2097409
    },
//--TRIMMABLE-BOUNDARY-END(38657916935),
//--TRIMMABLE-BOUNDARY-START(42952884231),
    {
      "p": $.$typePointer($.$typePointer($.$$.System.Void)).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 25773015047,
        "f": 50331905
      },
      "n": "ManagedVirtualMethodTable",
      "o": "System$Runtime$InteropServices$Marshalling$IIUnknownDerivedDetails$ManagedVirtualMethodTable",
      "d": 3211271,
      "h": 42952884231,
      "f": 2097409
    },
//--TRIMMABLE-BOUNDARY-END(42952884231)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(30067982343),
    {
      "r": 3211271,
      "p": [
        {
          "n": "handle",
          "p": 160038913
        }
      ],
      "n": "GetFromAttribute",
      "o": "System$Runtime$InteropServices$Marshalling$IIUnknownDerivedDetails$GetFromAttribute",
      "d": 3211271,
      "h": 30067982343,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(30067982343)
  ],
  "h": 3211271,
  "a": [
    {
      "t": 54132737,
      "c": 8644067329,
      "a": [
        {
          "v": false,
          "t": 262145
        }
      ]
    }
  ]
}; }
            static get $fullName() { return `System.Runtime.InteropServices.Marshalling.IIUnknownDerivedDetails`; }
        });
        //--TRIMMABLE-BOUNDARY-END(3211271)
        
        
        //--TRIMMABLE-BOUNDARY-START(2621447)
        $asm.$cls("$sris.System.Runtime.InteropServices.Marshalling.ExceptionAsNaNMarshaller<>", (T) => $asm.$gt("$sris.System.Runtime.InteropServices.Marshalling.ExceptionAsNaNMarshaller<>", [T], ($self) => class ExceptionAsNaNMarshaller$$
        {
            //--TRIMMABLE-BOUNDARY-START(4297588743)
            static /*T */ ConvertToUnmanaged(/*Exception*/ e)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4297588743);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                _ = $.$$.System.Runtime.InteropServices.Marshal.GetHRForException(e);
                return T.System$Numerics$IFloatingPointIeee754$$$NaN;
            }
            //--TRIMMABLE-BOUNDARY-END(4297588743)
            
            static $h = 2621447;
            static $g = 1;
            static $f = 0b1010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 131073,
  "m": [
//--TRIMMABLE-BOUNDARY-START(4297588743),
    {
      "r": T?.$h??1507328,
      "p": [
        {
          "n": "e",
          "p": 79888385
        }
      ],
      "n": "ConvertToUnmanaged",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x100000000n),
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(4297588743)
  ],
  "g": [T?.$h??1507328
  ],
  "s": [
    {
      "n": "T",
      "f": 10,
      "c": [$.$$.System.Numerics.IFloatingPointIeee754$$(T).$h
      ]
    }
  ],
  "r": 1,
  "h": this.$h,
  "a": [
    {
      "t": 144179201,
      "c": 4439146497,
      "a": [
        {
          "v": 79888385,
          "t": 187629569
        },
        {
          "v": 6,
          "t": 144310273
        },
        {
          "v": $.$sris.System.Runtime.InteropServices.Marshalling.ExceptionAsNaNMarshaller$$().$h,
          "t": 187629569
        }
      ]
    }
  ]
}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `System.Runtime.InteropServices.Marshalling.ExceptionAsNaNMarshaller<${T?.$fullName}>`; }
        }));
        //--TRIMMABLE-BOUNDARY-END(2621447)
        
        
        //--TRIMMABLE-BOUNDARY-START(2686983)
        $asm.$cls("$sris.System.Runtime.InteropServices.Marshalling.ExceptionAsVoidMarshaller", ($self) => class ExceptionAsVoidMarshaller
        {
            //--TRIMMABLE-BOUNDARY-START(4297654279)
            static /*void */ ConvertToUnmanaged(/*Exception*/ e)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4297654279);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                _ = $.$$.System.Runtime.InteropServices.Marshal.GetHRForException(e);
            }
            //--TRIMMABLE-BOUNDARY-END(4297654279)
            
            static $h = 2686983;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 131073,
  "m": [
//--TRIMMABLE-BOUNDARY-START(4297654279),
    {
      "r": 65537,
      "p": [
        {
          "n": "e",
          "p": 79888385
        }
      ],
      "n": "ConvertToUnmanaged",
      "d": 2686983,
      "h": 4297654279,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(4297654279)
  ],
  "h": 2686983,
  "a": [
    {
      "t": 144179201,
      "c": 4439146497,
      "a": [
        {
          "v": 79888385,
          "t": 187629569
        },
        {
          "v": 6,
          "t": 144310273
        },
        {
          "v": 2686983,
          "t": 187629569
        }
      ]
    }
  ]
}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `System.Runtime.InteropServices.Marshalling.ExceptionAsVoidMarshaller`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2686983)
        
        
        //--TRIMMABLE-BOUNDARY-START(2031623)
        $asm.$cls("$sris.System.Runtime.InteropServices.Marshalling.ComInterfaceMarshaller<>", (T) => $asm.$gt("$sris.System.Runtime.InteropServices.Marshalling.ComInterfaceMarshaller<>", [T], ($self) => class ComInterfaceMarshaller$$
        {
            //--TRIMMABLE-BOUNDARY-START(25771835399)
            /*Guid?*/ static TargetInterfaceIID = null;
            //--TRIMMABLE-BOUNDARY-END(25771835399)
            
            //--TRIMMABLE-BOUNDARY-START(17181900807)
            static /*void* */ ConvertToUnmanaged(/*T?*/ managed)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17181900807);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$box(managed, T) === null)
                {
                    return null;
                }
                /*nint*/ let unknown;
                if (!$.$$.System.Runtime.InteropServices.ComWrappers.TryGetComInstance($.$box(managed, T), $.$ref(() => unknown, ($v) => unknown = $v, $.$$.System.IntPtr)))
                {
                    unknown = $.$sris.System.Runtime.InteropServices.Marshalling.StrategyBasedComWrappers.DefaultMarshallingInstance.GetOrCreateComInterfaceForObject($.$box(managed, T), 0/*CreateComInterfaceFlags.None*/);
                }
                return $.$sris.System.Runtime.InteropServices.Marshalling.ComInterfaceMarshaller$$(T).CastIUnknownToInterfaceType(unknown);
            }
            //--TRIMMABLE-BOUNDARY-END(17181900807)
            
            //--TRIMMABLE-BOUNDARY-START(12886933511)
            static /*T? */ ConvertToManaged(/*void**/ unmanaged)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12886933511);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (unmanaged === null)
                {
                    return $.$default(T);
                }
                return $.$cast($.$sris.System.Runtime.InteropServices.Marshalling.StrategyBasedComWrappers.DefaultMarshallingInstance.GetOrCreateObjectForComInstance$1($.$$.System.IntPtr.op_Explicit$4(unmanaged), 8/*CreateObjectFlags.Unwrap*/), T);
            }
            //--TRIMMABLE-BOUNDARY-END(12886933511)
            
            //--TRIMMABLE-BOUNDARY-START(21476868103)
            static /*void */ Free(/*void**/ unmanaged)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21476868103);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (unmanaged !== null)
                {
                    $.$$.System.Runtime.InteropServices.Marshal.Release($.$$.System.IntPtr.op_Explicit$4(unmanaged));
                }
            }
            //--TRIMMABLE-BOUNDARY-END(21476868103)
            
            //--TRIMMABLE-BOUNDARY-START(8591966215)
            static /*void* */ CastIUnknownToInterfaceType(/*nint*/ unknown)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591966215);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$sris.System.Runtime.InteropServices.Marshalling.ComInterfaceMarshaller$$(T).TargetInterfaceIID === null)
                {
                    return $.$$.System.IntPtr.op_Explicit$5(unknown);
                }
                /*nint*/ let interfacePointer;
                if ($.$$.System.Runtime.InteropServices.Marshal.QueryInterface(unknown, $.$$.System.Nullable.GetValueRefOrDefaultRef($.$$.System.Guid, $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateObjectReferenceT($.$typeNullable($.$$.System.Guid), () => $.$sris.System.Runtime.InteropServices.Marshalling.ComInterfaceMarshaller$$(T).TargetInterfaceIID, ($v) => $.$sris.System.Runtime.InteropServices.Marshalling.ComInterfaceMarshaller$$(T).TargetInterfaceIID = $v, null)), $.$ref(() => interfacePointer, ($v) => interfacePointer = $v, $.$$.System.IntPtr)) !== 0)
                {
                    $.$$.System.Runtime.InteropServices.Marshal.Release(unknown);
                    throw new $.$$.System.InvalidCastException().$ctor$13((() =>
                    {
                        var $handler = new $.$$.System.Runtime.CompilerServices.DefaultInterpolatedStringHandler().$ctor$5(2, 1);
                        $handler.AppendLiteral("Unable to cast the provided managed object to a COM interface with ID '");
                        $handler.AppendFormatted($.$box($.$$.System.Nullable$$($.$$.System.Guid).GetValueOrDefault.call($.$sris.System.Runtime.InteropServices.Marshalling.ComInterfaceMarshaller$$(T).TargetInterfaceIID), $.$$.System.Guid), null, "B");
                        $handler.AppendLiteral("'");
                        return $handler.ToStringAndClear                ();
                    })());
                }
                $.$$.System.Runtime.InteropServices.Marshal.Release(unknown);
                return $.$$.System.IntPtr.op_Explicit$5(interfacePointer);
            }
            //--TRIMMABLE-BOUNDARY-END(8591966215)
            
            //--TRIMMABLE-BOUNDARY-START(4296998919)
            //Static Initializer
            static $sinit()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(25771835399)
                    this.TargetInterfaceIID = ($.$sris.System.Runtime.InteropServices.Marshalling.StrategyBasedComWrappers.DefaultIUnknownInterfaceDetailsStrategy.System$Runtime$InteropServices$Marshalling$IIUnknownInterfaceDetailsStrategy$GetIUnknownDerivedDetails(T.$type.TypeHandle)?.System$Runtime$InteropServices$Marshalling$IIUnknownDerivedDetails$Iid ?? null);
                    //--TRIMMABLE-BOUNDARY-END(25771835399)
                    
                }
            }
            //--TRIMMABLE-BOUNDARY-END(4296998919)
            
            static $h = 2031623;
            static $g = 1;
            static $f = 0b1010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 131073,
  "m": [
//--TRIMMABLE-BOUNDARY-START(17181900807),
    {
      "r": $.$typePointer($.$$.System.Void).$h,
      "p": [
        {
          "n": "managed",
          "p": T?.$h??1507328
        }
      ],
      "n": "ConvertToUnmanaged",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x400000000n),
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(17181900807),
//--TRIMMABLE-BOUNDARY-START(12886933511),
    {
      "r": T?.$h??1507328,
      "p": [
        {
          "n": "unmanaged",
          "p": $.$typePointer($.$$.System.Void).$h
        }
      ],
      "n": "ConvertToManaged",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x300000000n),
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(12886933511),
//--TRIMMABLE-BOUNDARY-START(21476868103),
    {
      "r": 65537,
      "p": [
        {
          "n": "unmanaged",
          "p": $.$typePointer($.$$.System.Void).$h
        }
      ],
      "n": "Free",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x500000000n),
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(21476868103),
//--TRIMMABLE-BOUNDARY-START(8591966215),
    {
      "r": $.$typePointer($.$$.System.Void).$h,
      "p": [
        {
          "n": "unknown",
          "p": 786433
        }
      ],
      "n": "CastIUnknownToInterfaceType",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x200000000n),
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(8591966215)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(25771835399),
    {
      "t": $.$typeNullable($.$$.System.Guid).$h,
      "n": "TargetInterfaceIID",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x600000000n),
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(25771835399)
  ],
  "g": [T?.$h??1507328
  ],
  "r": 1,
  "h": this.$h,
  "a": [
    {
      "t": 159252481,
      "c": 4454219777,
      "a": [
        {
          "v": "android",
          "t": 1310721
        }
      ]
    },
    {
      "t": 159252481,
      "c": 4454219777,
      "a": [
        {
          "v": "browser",
          "t": 1310721
        }
      ]
    },
    {
      "t": 159252481,
      "c": 4454219777,
      "a": [
        {
          "v": "ios",
          "t": 1310721
        }
      ]
    },
    {
      "t": 159252481,
      "c": 4454219777,
      "a": [
        {
          "v": "tvos",
          "t": 1310721
        }
      ]
    },
    {
      "t": 54132737,
      "c": 8644067329,
      "a": [
        {
          "v": false,
          "t": 262145
        }
      ]
    },
    {
      "t": 144179201,
      "c": 4439146497,
      "a": [
        {
          "v": 144244737,
          "t": 187629569
        },
        {
          "v": 0,
          "t": 144310273
        },
        {
          "v": $.$sris.System.Runtime.InteropServices.Marshalling.ComInterfaceMarshaller$$().$h,
          "t": 187629569
        }
      ]
    }
  ]
}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `System.Runtime.InteropServices.Marshalling.ComInterfaceMarshaller<${T?.$fullName}>`; }
        }));
        //--TRIMMABLE-BOUNDARY-END(2031623)
        
        
        //--TRIMMABLE-BOUNDARY-START(4653063)
        $asm.$cls("$sris.System.SR", ($self) => class SR
        {
            //--TRIMMABLE-BOUNDARY-START(365076873223)
            /*global::System.Resources.ResourceManager*/ static s_resourceManager = null;
            //--TRIMMABLE-BOUNDARY-END(365076873223)
            
            //--TRIMMABLE-BOUNDARY-START(356486938631)
            /*global::System.Globalization.CultureInfo*/ static resourceCulture = null;
            //--TRIMMABLE-BOUNDARY-END(356486938631)
            
            //--TRIMMABLE-BOUNDARY-START(360781905927)
            static /*global::System.Resources.ResourceManager */ get ResourceManager()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(270587592711);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$$.System.Object.ReferenceEquals($.$sris.System.SR.s_resourceManager, null))
                {
                    /*global::System.Resources.ResourceManager*/ let temp = new $.$$.System.Resources.ResourceManager().$ctor$3("System.Runtime.InteropServices", $.$sris.System.SR.$type.Assembly);
                    $.$sris.System.SR.s_resourceManager = temp;
                }
                return $.$sris.System.SR.s_resourceManager;
            }
            //--TRIMMABLE-BOUNDARY-END(360781905927)
            
            //--TRIMMABLE-BOUNDARY-START(34364391431)
            static /*global::System.Globalization.CultureInfo */ get Culture()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(158918443015);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$sris.System.SR.resourceCulture;
            }
            static /*global::System.Globalization.CultureInfo */ set Culture(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(377961775111);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$sris.System.SR.resourceCulture = value;
            }
            //--TRIMMABLE-BOUNDARY-END(34364391431)
            
            //--TRIMMABLE-BOUNDARY-START(304947331079)
            static /*string */ get InvalidOperation_HCCountOverflow()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(167508377607);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "Handle collector count overflows or underflows.";
            }
            //--TRIMMABLE-BOUNDARY-END(304947331079)
            
            //--TRIMMABLE-BOUNDARY-START(17184522247)
            static /*string */ get Arg_NeedNonNegNumRequired()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(124558704647);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "Non-negative number required.";
            }
            //--TRIMMABLE-BOUNDARY-END(17184522247)
            
            //--TRIMMABLE-BOUNDARY-START(12889554951)
            static /*string */ get Arg_InvalidThreshold()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(115968770055);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "maximumThreshold cannot be less than initialThreshold.";
            }
            //--TRIMMABLE-BOUNDARY-END(12889554951)
            
            //--TRIMMABLE-BOUNDARY-START(309242298375)
            static /*string */ get InvalidOperation_NoComEventInterfaceAttribute()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(176098312199);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "Event invocation for COM objects requires the declaring interface of the event to be attributed with ComEventInterfaceAttribute.";
            }
            //--TRIMMABLE-BOUNDARY-END(309242298375)
            
            //--TRIMMABLE-BOUNDARY-START(8594587655)
            static /*string */ get AmbiguousMatch_MultipleEventInterfaceAttributes()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(107378835463);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "More than one ComEventInterfaceAttribute found for '{0}' on the declaring interface of the event.";
            }
            //--TRIMMABLE-BOUNDARY-END(8594587655)
            
            //--TRIMMABLE-BOUNDARY-START(73019097095)
            static /*string */ FormatAmbiguousMatch_MultipleEventInterfaceAttributes(/*object*/ arg1)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(73019097095);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$$.System.String.Format$9("More than one ComEventInterfaceAttribute found for '{0}' on the declaring interface of the event.", arg1);
            }
            //--TRIMMABLE-BOUNDARY-END(73019097095)
            
            //--TRIMMABLE-BOUNDARY-START(313537265671)
            static /*string */ get InvalidOperation_NoDispIdAttribute()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(184688246791);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "Event invocation for COM objects requires event to be attributed with DispIdAttribute.";
            }
            //--TRIMMABLE-BOUNDARY-END(313537265671)
            
            //--TRIMMABLE-BOUNDARY-START(317832232967)
            static /*string */ get IO_FileExists_Name()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(193278181383);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "The file '{0}' already exists.";
            }
            //--TRIMMABLE-BOUNDARY-END(317832232967)
            
            //--TRIMMABLE-BOUNDARY-START(77314064391)
            static /*string */ FormatIO_FileExists_Name(/*object*/ arg1)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(77314064391);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$$.System.String.Format$9("The file '{0}' already exists.", arg1);
            }
            //--TRIMMABLE-BOUNDARY-END(77314064391)
            
            //--TRIMMABLE-BOUNDARY-START(322127200263)
            static /*string */ get IO_FileNotFound()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(201868115975);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "Unable to find the specified file.";
            }
            //--TRIMMABLE-BOUNDARY-END(322127200263)
            
            //--TRIMMABLE-BOUNDARY-START(326422167559)
            static /*string */ get IO_FileNotFound_FileName()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(210458050567);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "Could not find file '{0}'.";
            }
            //--TRIMMABLE-BOUNDARY-END(326422167559)
            
            //--TRIMMABLE-BOUNDARY-START(81609031687)
            static /*string */ FormatIO_FileNotFound_FileName(/*object*/ arg1)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(81609031687);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$$.System.String.Format$9("Could not find file '{0}'.", arg1);
            }
            //--TRIMMABLE-BOUNDARY-END(81609031687)
            
            //--TRIMMABLE-BOUNDARY-START(330717134855)
            static /*string */ get IO_PathNotFound_NoPathName()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(219047985159);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "Could not find a part of the path.";
            }
            //--TRIMMABLE-BOUNDARY-END(330717134855)
            
            //--TRIMMABLE-BOUNDARY-START(335012102151)
            static /*string */ get IO_PathNotFound_Path()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(227637919751);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "Could not find a part of the path '{0}'.";
            }
            //--TRIMMABLE-BOUNDARY-END(335012102151)
            
            //--TRIMMABLE-BOUNDARY-START(85903998983)
            static /*string */ FormatIO_PathNotFound_Path(/*object*/ arg1)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(85903998983);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$$.System.String.Format$9("Could not find a part of the path '{0}'.", arg1);
            }
            //--TRIMMABLE-BOUNDARY-END(85903998983)
            
            //--TRIMMABLE-BOUNDARY-START(339307069447)
            static /*string */ get IO_PathTooLong()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(236227854343);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "The specified file name or path is too long, or a component of the specified path is too long.";
            }
            //--TRIMMABLE-BOUNDARY-END(339307069447)
            
            //--TRIMMABLE-BOUNDARY-START(347897004039)
            static /*string */ get IO_SharingViolation_File()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(253407723527);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "The process cannot access the file '{0}' because it is being used by another process.";
            }
            //--TRIMMABLE-BOUNDARY-END(347897004039)
            
            //--TRIMMABLE-BOUNDARY-START(94493933575)
            static /*string */ FormatIO_SharingViolation_File(/*object*/ arg1)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(94493933575);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$$.System.String.Format$9("The process cannot access the file '{0}' because it is being used by another process.", arg1);
            }
            //--TRIMMABLE-BOUNDARY-END(94493933575)
            
            //--TRIMMABLE-BOUNDARY-START(352191971335)
            static /*string */ get IO_SharingViolation_NoFileName()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(261997658119);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "The process cannot access the file because it is being used by another process.";
            }
            //--TRIMMABLE-BOUNDARY-END(352191971335)
            
            //--TRIMMABLE-BOUNDARY-START(343602036743)
            static /*string */ get IO_PathTooLong_Path()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(244817788935);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "The path '{0}' is too long, or a component of the specified path is too long.";
            }
            //--TRIMMABLE-BOUNDARY-END(343602036743)
            
            //--TRIMMABLE-BOUNDARY-START(90198966279)
            static /*string */ FormatIO_PathTooLong_Path(/*object*/ arg1)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(90198966279);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$$.System.String.Format$9("The path '{0}' is too long, or a component of the specified path is too long.", arg1);
            }
            //--TRIMMABLE-BOUNDARY-END(90198966279)
            
            //--TRIMMABLE-BOUNDARY-START(386551709703)
            static /*string */ get UnauthorizedAccess_IODenied_Path()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(287767461895);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "Access to the path '{0}' is denied.";
            }
            //--TRIMMABLE-BOUNDARY-END(386551709703)
            
            //--TRIMMABLE-BOUNDARY-START(98788900871)
            static /*string */ FormatUnauthorizedAccess_IODenied_Path(/*object*/ arg1)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(98788900871);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$$.System.String.Format$9("Access to the path '{0}' is denied.", arg1);
            }
            //--TRIMMABLE-BOUNDARY-END(98788900871)
            
            //--TRIMMABLE-BOUNDARY-START(382256742407)
            static /*string */ get UnauthorizedAccess_IODenied_NoPathName()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(279177527303);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "Access to the path is denied.";
            }
            //--TRIMMABLE-BOUNDARY-END(382256742407)
            
            //--TRIMMABLE-BOUNDARY-START(21479489543)
            static /*string */ get ArgumentOutOfRange_FileLengthTooBig()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(133148639239);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "Specified file length was too large for the file system.";
            }
            //--TRIMMABLE-BOUNDARY-END(21479489543)
            
            //--TRIMMABLE-BOUNDARY-START(25774456839)
            static /*string */ get ComVariantMarshaller_ManagedTypeNotSupported()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(141738573831);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "Type of managed object is not supported for marshalling as ComVariant.";
            }
            //--TRIMMABLE-BOUNDARY-END(25774456839)
            
            //--TRIMMABLE-BOUNDARY-START(30069424135)
            static /*string */ get ComVariantMarshaller_UnmanagedTypeNotSupported()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(150328508423);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "Type of unmanaged variant is not supported for marshalling to a managed object.";
            }
            //--TRIMMABLE-BOUNDARY-END(30069424135)
            
            //--TRIMMABLE-BOUNDARY-START(369371840519)
            /*bool*/ static s_usingResourceKeys = false;
            //--TRIMMABLE-BOUNDARY-END(369371840519)
            
            //--TRIMMABLE-BOUNDARY-START(300652363783)
            static /*bool */ GetUsingResourceKeysSwitchValue()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(300652363783);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    /*bool*/ let usingResourceKeys;
                    return $.$$.System.AppContext.TryGetSwitch("System.Resources.UseSystemResourceKeys", $.$ref(() => usingResourceKeys, ($v) => usingResourceKeys = $v, $.$$.System.Boolean)) ? usingResourceKeys : false;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(300652363783)
            
            //--TRIMMABLE-BOUNDARY-START(390846676999)
            static /*bool */ UsingResourceKeys()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(390846676999);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return $.$sris.System.SR.s_usingResourceKeys;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(390846676999)
            
            //--TRIMMABLE-BOUNDARY-START(292062429191)
            static /*string */ GetResourceString$1(/*string*/ resourceKey)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(292062429191);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$sris.System.SR.UsingResourceKeys())
                {
                    return resourceKey;
                }
                /*string?*/ let resourceString = null;
                try
                {
                    resourceString = $.$sris.System.SR.ResourceManager.GetString$1(resourceKey);
                }
                catch($e)
                {
                }
                return resourceString;
            }
            //--TRIMMABLE-BOUNDARY-END(292062429191)
            
            //--TRIMMABLE-BOUNDARY-START(296357396487)
            static /*string */ GetResourceString(/*string*/ resourceKey, /*string*/ defaultString)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(296357396487);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*string*/ let resourceString = $.$sris.System.SR.GetResourceString$1(resourceKey);
                return $.$$.System.String.op_Equality(resourceKey, resourceString) || $.$$.System.String.op_Equality(resourceString, null) ? defaultString : resourceString;
            }
            //--TRIMMABLE-BOUNDARY-END(296357396487)
            
            //--TRIMMABLE-BOUNDARY-START(38659358727)
            static /*string */ Format$6(/*string*/ resourceFormat, /*object?*/ p1)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(38659358727);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$sris.System.SR.UsingResourceKeys())
                {
                    return $.$$.System.String.Join$7(", ", $.$$.System.ReadOnlySpan$$($.$$.System.Object).op_Implicit$1([ resourceFormat, p1 ]));
                }
                return $.$$.System.String.Format$9(resourceFormat, p1);
            }
            //--TRIMMABLE-BOUNDARY-END(38659358727)
            
            //--TRIMMABLE-BOUNDARY-START(42954326023)
            static /*string */ Format$5(/*string*/ resourceFormat, /*object?*/ p1, /*object?*/ p2)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(42954326023);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$sris.System.SR.UsingResourceKeys())
                {
                    return $.$$.System.String.Join$7(", ", $.$$.System.ReadOnlySpan$$($.$$.System.Object).op_Implicit$1([ resourceFormat, p1, p2 ]));
                }
                return $.$$.System.String.Format$8(resourceFormat, p1, p2);
            }
            //--TRIMMABLE-BOUNDARY-END(42954326023)
            
            //--TRIMMABLE-BOUNDARY-START(47249293319)
            static /*string */ Format$4(/*string*/ resourceFormat, /*object?*/ p1, /*object?*/ p2, /*object?*/ p3)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(47249293319);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$sris.System.SR.UsingResourceKeys())
                {
                    return $.$$.System.String.Join$7(", ", $.$$.System.ReadOnlySpan$$($.$$.System.Object).op_Implicit$1([ resourceFormat, p1, p2, p3 ]));
                }
                return $.$$.System.String.Format$7(resourceFormat, p1, p2, p3);
            }
            //--TRIMMABLE-BOUNDARY-END(47249293319)
            
            //--TRIMMABLE-BOUNDARY-START(51544260615)
            static /*string */ Format$7(/*string*/ resourceFormat, /*params object?[]?*/ args)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(51544260615);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (args !== null)
                {
                    if ($.$sris.System.SR.UsingResourceKeys())
                    {
                        return resourceFormat + ", " + $.$$.System.String.Join$6(", ", args);
                    }
                    return $.$$.System.String.Format$10(resourceFormat, args);
                }
                return resourceFormat;
            }
            //--TRIMMABLE-BOUNDARY-END(51544260615)
            
            //--TRIMMABLE-BOUNDARY-START(55839227911)
            static /*string */ Format$2(/*IFormatProvider?*/ provider, /*string*/ resourceFormat, /*object?*/ p1)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(55839227911);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$sris.System.SR.UsingResourceKeys())
                {
                    return $.$$.System.String.Join$7(", ", $.$$.System.ReadOnlySpan$$($.$$.System.Object).op_Implicit$1([ resourceFormat, p1 ]));
                }
                return $.$$.System.String.Format$2(provider, resourceFormat, p1);
            }
            //--TRIMMABLE-BOUNDARY-END(55839227911)
            
            //--TRIMMABLE-BOUNDARY-START(60134195207)
            static /*string */ Format$1(/*IFormatProvider?*/ provider, /*string*/ resourceFormat, /*object?*/ p1, /*object?*/ p2)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(60134195207);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$sris.System.SR.UsingResourceKeys())
                {
                    return $.$$.System.String.Join$7(", ", $.$$.System.ReadOnlySpan$$($.$$.System.Object).op_Implicit$1([ resourceFormat, p1, p2 ]));
                }
                return $.$$.System.String.Format$1(provider, resourceFormat, p1, p2);
            }
            //--TRIMMABLE-BOUNDARY-END(60134195207)
            
            //--TRIMMABLE-BOUNDARY-START(64429162503)
            static /*string */ Format(/*IFormatProvider?*/ provider, /*string*/ resourceFormat, /*object?*/ p1, /*object?*/ p2, /*object?*/ p3)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(64429162503);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$sris.System.SR.UsingResourceKeys())
                {
                    return $.$$.System.String.Join$7(", ", $.$$.System.ReadOnlySpan$$($.$$.System.Object).op_Implicit$1([ resourceFormat, p1, p2, p3 ]));
                }
                return $.$$.System.String.Format(provider, resourceFormat, p1, p2, p3);
            }
            //--TRIMMABLE-BOUNDARY-END(64429162503)
            
            //--TRIMMABLE-BOUNDARY-START(68724129799)
            static /*string */ Format$3(/*IFormatProvider?*/ provider, /*string*/ resourceFormat, /*params object?[]?*/ args)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(68724129799);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (args !== null)
                {
                    if ($.$sris.System.SR.UsingResourceKeys())
                    {
                        return resourceFormat + ", " + $.$$.System.String.Join$6(", ", args);
                    }
                    return $.$$.System.String.Format$3(provider, resourceFormat, args);
                }
                return resourceFormat;
            }
            //--TRIMMABLE-BOUNDARY-END(68724129799)
            
            //--TRIMMABLE-BOUNDARY-START(4299620359)
            //Static Initializer
            static $sinit()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(369371840519)
                    this.s_usingResourceKeys = $.$sris.System.SR.GetUsingResourceKeysSwitchValue();
                    //--TRIMMABLE-BOUNDARY-END(369371840519)
                    
                }
            }
            //--TRIMMABLE-BOUNDARY-END(4299620359)
            
            static $h = 4653063;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 131073,
  "h": 4653063
}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `System.SR`; }
        });
        //--TRIMMABLE-BOUNDARY-END(4653063)
        
        
        //--TRIMMABLE-BOUNDARY-START(2490375)
        $asm.$cls("$sris.System.Runtime.InteropServices.Marshalling.ExceptionAsDefaultMarshaller<>", (T) => $asm.$gt("$sris.System.Runtime.InteropServices.Marshalling.ExceptionAsDefaultMarshaller<>", [T], ($self) => class ExceptionAsDefaultMarshaller$$
        {
            //--TRIMMABLE-BOUNDARY-START(4297457671)
            static /*T */ ConvertToUnmanaged(/*Exception*/ e)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4297457671);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                _ = $.$$.System.Runtime.InteropServices.Marshal.GetHRForException(e);
                return $.$default(T);
            }
            //--TRIMMABLE-BOUNDARY-END(4297457671)
            
            static $h = 2490375;
            static $g = 1;
            static $f = 0b1010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 131073,
  "m": [
//--TRIMMABLE-BOUNDARY-START(4297457671),
    {
      "r": T?.$h??1507328,
      "p": [
        {
          "n": "e",
          "p": 79888385
        }
      ],
      "n": "ConvertToUnmanaged",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x100000000n),
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(4297457671)
  ],
  "g": [T?.$h??1507328
  ],
  "s": [
    {
      "n": "T",
      "f": 10
    }
  ],
  "r": 1,
  "h": this.$h,
  "a": [
    {
      "t": 144179201,
      "c": 4439146497,
      "a": [
        {
          "v": 79888385,
          "t": 187629569
        },
        {
          "v": 6,
          "t": 144310273
        },
        {
          "v": $.$sris.System.Runtime.InteropServices.Marshalling.ExceptionAsDefaultMarshaller$$().$h,
          "t": 187629569
        }
      ]
    }
  ]
}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `System.Runtime.InteropServices.Marshalling.ExceptionAsDefaultMarshaller<${T?.$fullName}>`; }
        }));
        //--TRIMMABLE-BOUNDARY-END(2490375)
        
        
        //--TRIMMABLE-BOUNDARY-START(3997703)
        $asm.$cls("$sris.System.Runtime.InteropServices.RuntimeEnvironment", ($self) => class RuntimeEnvironment
        {
            //--TRIMMABLE-BOUNDARY-START(34363736071)
            static /*string */ get SystemConfigurationFile()
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(34363736071)
            
            //--TRIMMABLE-BOUNDARY-START(4298964999)
            static /*bool */ FromGlobalAccessCache(/*Assembly*/ a)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4298964999);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return false;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(4298964999)
            
            //--TRIMMABLE-BOUNDARY-START(17183866887)
            static /*string */ GetRuntimeDirectory()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17183866887);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*string?*/ let runtimeDirectory = $.$$.System.Object.$type.Assembly.Location;
                if (!$.$$.System.IO.Path.IsPathRooted$1(runtimeDirectory))
                {
                    runtimeDirectory = $.$$.System.AppDomain.CurrentDomain.BaseDirectory;
                }
                /*char*/ let sep = $.$$.System.IO.Path.DirectorySeparatorChar;
                return $.$$.System.String.Concat$8($.$$.System.String.op_Implicit($.$$.System.IO.Path.GetDirectoryName$1(runtimeDirectory)), new ($.$$.System.ReadOnlySpan$$($.$$.System.Char))().$ctor$7($.$ref(() => sep, undefined, $.$$.System.Char)));
            }
            //--TRIMMABLE-BOUNDARY-END(17183866887)
            
            //--TRIMMABLE-BOUNDARY-START(21478834183)
            static /*IntPtr */ GetRuntimeInterfaceAsIntPtr(/*Guid*/ clsid, /*Guid*/ riid)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(21478834183);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
                }
            }
            //--TRIMMABLE-BOUNDARY-END(21478834183)
            
            //--TRIMMABLE-BOUNDARY-START(25773801479)
            static /*object */ GetRuntimeInterfaceAsObject(/*Guid*/ clsid, /*Guid*/ riid)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(25773801479);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
                }
            }
            //--TRIMMABLE-BOUNDARY-END(25773801479)
            
            //--TRIMMABLE-BOUNDARY-START(30068768775)
            static /*string */ GetSystemVersion()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(30068768775);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return `v${$.$$.System.Environment.Version}`;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(30068768775)
            
            static $h = 3997703;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 131073,
  "p": [
//--TRIMMABLE-BOUNDARY-START(34363736071),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 12888899591,
        "f": 50331681
      },
      "n": "SystemConfigurationFile",
      "d": 3997703,
      "h": 34363736071,
      "f": 2097185,
      "a": [
        {
          "t": 103612417,
          "c": 8693547009,
          "a": [
            {
              "v": "RuntimeEnvironment members SystemConfigurationFile, GetRuntimeInterfaceAsIntPtr, and GetRuntimeInterfaceAsObject are not supported and throw PlatformNotSupportedException.",
              "t": 1310721
            }
          ],
          "n": [
            {
              "n": "DiagnosticId",
              "v": "SYSLIB0019",
              "t": 1310721
            },
            {
              "n": "UrlFormat",
              "v": "https://aka.ms/dotnet-warnings/{0}",
              "t": 1310721
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(34363736071)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(4298964999),
    {
      "r": 262145,
      "p": [
        {
          "n": "a",
          "p": 106168321
        }
      ],
      "n": "FromGlobalAccessCache",
      "d": 3997703,
      "h": 4298964999,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(4298964999),
//--TRIMMABLE-BOUNDARY-START(17183866887),
    {
      "r": 1310721,
      "n": "GetRuntimeDirectory",
      "d": 3997703,
      "h": 17183866887,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(17183866887),
//--TRIMMABLE-BOUNDARY-START(21478834183),
    {
      "r": 786433,
      "p": [
        {
          "n": "clsid",
          "p": 88866817
        },
        {
          "n": "riid",
          "p": 88866817
        }
      ],
      "n": "GetRuntimeInterfaceAsIntPtr",
      "d": 3997703,
      "h": 21478834183,
      "f": 16777249,
      "a": [
        {
          "t": 103612417,
          "c": 8693547009,
          "a": [
            {
              "v": "RuntimeEnvironment members SystemConfigurationFile, GetRuntimeInterfaceAsIntPtr, and GetRuntimeInterfaceAsObject are not supported and throw PlatformNotSupportedException.",
              "t": 1310721
            }
          ],
          "n": [
            {
              "n": "DiagnosticId",
              "v": "SYSLIB0019",
              "t": 1310721
            },
            {
              "n": "UrlFormat",
              "v": "https://aka.ms/dotnet-warnings/{0}",
              "t": 1310721
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(21478834183),
//--TRIMMABLE-BOUNDARY-START(25773801479),
    {
      "r": 131073,
      "p": [
        {
          "n": "clsid",
          "p": 88866817
        },
        {
          "n": "riid",
          "p": 88866817
        }
      ],
      "n": "GetRuntimeInterfaceAsObject",
      "d": 3997703,
      "h": 25773801479,
      "f": 16777249,
      "a": [
        {
          "t": 103612417,
          "c": 8693547009,
          "a": [
            {
              "v": "RuntimeEnvironment members SystemConfigurationFile, GetRuntimeInterfaceAsIntPtr, and GetRuntimeInterfaceAsObject are not supported and throw PlatformNotSupportedException.",
              "t": 1310721
            }
          ],
          "n": [
            {
              "n": "DiagnosticId",
              "v": "SYSLIB0019",
              "t": 1310721
            },
            {
              "n": "UrlFormat",
              "v": "https://aka.ms/dotnet-warnings/{0}",
              "t": 1310721
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(25773801479),
//--TRIMMABLE-BOUNDARY-START(30068768775),
    {
      "r": 1310721,
      "n": "GetSystemVersion",
      "d": 3997703,
      "h": 30068768775,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(30068768775)
  ],
  "h": 3997703
}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `System.Runtime.InteropServices.RuntimeEnvironment`; }
        });
        //--TRIMMABLE-BOUNDARY-END(3997703)
        
        
        //--TRIMMABLE-BOUNDARY-START(1572871)
        $asm.$cls("$sris.System.Runtime.InteropServices.HandleCollector", ($self) => class HandleCollector extends $.$$.System.Object
        {
            //--TRIMMABLE-BOUNDARY-START(51541180423)
            /*int*/ static DeltaPercent = 10;
            //--TRIMMABLE-BOUNDARY-END(51541180423)
            
            //--TRIMMABLE-BOUNDARY-START(17181442055)
            /*int*/ _threshold = 0;
            //--TRIMMABLE-BOUNDARY-END(17181442055)
            
            //--TRIMMABLE-BOUNDARY-START(12886474759)
            /*int*/ _handleCount = 0;
            //--TRIMMABLE-BOUNDARY-END(12886474759)
            
            //--TRIMMABLE-BOUNDARY-START(4296540167)
            /*int[]*/ _gcCounts = null;
            //--TRIMMABLE-BOUNDARY-END(4296540167)
            
            //--TRIMMABLE-BOUNDARY-START(8591507463)
            /*int*/ _gcGeneration = 0;
            //--TRIMMABLE-BOUNDARY-END(8591507463)
            
            //--TRIMMABLE-BOUNDARY-START(21476409351)
            $ctor$2(/*string?*/ name, /*int*/ initialThreshold)
            {
                this.$ctor$1(name, initialThreshold, 2147483647/*int.MaxValue*/);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(21476409351);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(21476409351)
            
            //--TRIMMABLE-BOUNDARY-START(25771376647)
            $ctor$1(/*string?*/ name, /*int*/ initialThreshold, /*int*/ maximumThreshold)
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(25771376647);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    if (initialThreshold < 0)
                    {
                        throw new $.$$.System.ArgumentOutOfRangeException().$ctor$18("initialThreshold", $.$box(initialThreshold, $.$$.System.Int32), $.$sris.System.SR.Arg_NeedNonNegNumRequired);
                    }
                    if (maximumThreshold < 0)
                    {
                        throw new $.$$.System.ArgumentOutOfRangeException().$ctor$18("maximumThreshold", $.$box(maximumThreshold, $.$$.System.Int32), $.$sris.System.SR.Arg_NeedNonNegNumRequired);
                    }
                    if (initialThreshold > maximumThreshold)
                    {
                        throw new $.$$.System.ArgumentException().$ctor$13($.$sris.System.SR.Arg_InvalidThreshold, "initialThreshold");
                    }
                    this.Name = name ?? $.$$.System.String.Empty;
                    this.InitialThreshold = initialThreshold;
                    this.MaximumThreshold = maximumThreshold;
                    this._threshold = initialThreshold;
                    this._handleCount = 0;
                    this._gcGeneration = 0;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(25771376647)
            
            //--TRIMMABLE-BOUNDARY-START(47246213127)
            /*int */ get Count()
            {
                return this._handleCount;
            }
            //--TRIMMABLE-BOUNDARY-END(47246213127)
            
            //--TRIMMABLE-BOUNDARY-START(90195886087)
            /*int*/ InitialThreshold = 0;
            //--TRIMMABLE-BOUNDARY-END(90195886087)
            
            //--TRIMMABLE-BOUNDARY-START(94490853383)
            /*int*/ MaximumThreshold = 0;
            //--TRIMMABLE-BOUNDARY-END(94490853383)
            
            //--TRIMMABLE-BOUNDARY-START(98785820679)
            /*string*/ Name = null;
            //--TRIMMABLE-BOUNDARY-END(98785820679)
            
            //--TRIMMABLE-BOUNDARY-START(42951245831)
            /*void */ Add()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(42951245831);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*int*/ let collectionGeneration = -1;
                $.$$.System.Threading.Interlocked.Increment($.$ref(() => this._handleCount, ($v) => this._handleCount = $v, $.$$.System.Int32));
                if (this._handleCount < 0)
                {
                    throw new $.$$.System.InvalidOperationException().$ctor$12($.$sris.System.SR.InvalidOperation_HCCountOverflow);
                }
                if (this._handleCount > this._threshold)
                {
                    //lock
                    try
                    {
                        $.$$.System.Threading.Monitor.Enter$1(this)
                        {
                            this._threshold = ((this._handleCount + ($.trunc(this._handleCount / 10/*DeltaPercent*/))) | 0);
                            collectionGeneration = this._gcGeneration;
                            if (this._gcGeneration < 2)
                            {
                                this._gcGeneration++;
                            }
                        }
                    }
                    finally
                    {
                        $.$$.System.Threading.Monitor.Exit(this)
                    }
                }
                if ((collectionGeneration >= 0) && ((collectionGeneration === 0) || ($.$$.System.Array.$ReadT1.call(this._gcCounts, collectionGeneration) === $.$$.System.GC.CollectionCount(collectionGeneration))))
                {
                    $.$$.System.GC.Collect$4(collectionGeneration);
                    $.$$.System.Threading.Thread.Sleep(((10 * collectionGeneration) | 0));
                }
                for(/*int*/ let i = 1; i < 3; i++)
                {
                    $.$$.System.Array.$WriteT1.call(this._gcCounts, $.$$.System.GC.CollectionCount(i), i);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(42951245831)
            
            //--TRIMMABLE-BOUNDARY-START(103080787975)
            /*void */ Remove()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(103080787975);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.Threading.Interlocked.Decrement($.$ref(() => this._handleCount, ($v) => this._handleCount = $v, $.$$.System.Int32));
                if (this._handleCount < 0)
                {
                    throw new $.$$.System.InvalidOperationException().$ctor$12($.$sris.System.SR.InvalidOperation_HCCountOverflow);
                }
                /*int*/ let newThreshold = ((this._handleCount + $.trunc(this._handleCount / 10/*DeltaPercent*/)) | 0);
                if (newThreshold < (((this._threshold - $.trunc(this._threshold / 10/*DeltaPercent*/)) | 0)))
                {
                    //lock
                    try
                    {
                        $.$$.System.Threading.Monitor.Enter$1(this)
                        {
                            if (newThreshold > this.InitialThreshold)
                            {
                                this._threshold = newThreshold;
                            }
                            else 
                            {
                                this._threshold = this.InitialThreshold;
                            }
                            this._gcGeneration = 0;
                        }
                    }
                    finally
                    {
                        $.$$.System.Threading.Monitor.Exit(this)
                    }
                }
                for(/*int*/ let i = 1; i < 3; i++)
                {
                    $.$$.System.Array.$WriteT1.call(this._gcCounts, $.$$.System.GC.CollectionCount(i), i);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(103080787975)
            
            //default member initializer
            constructor()
            {
                super();
                //--TRIMMABLE-BOUNDARY-START(4296540167)
                this._gcCounts = $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$$.System.Int32), null, [3], null);
                //--TRIMMABLE-BOUNDARY-END(4296540167)
                
            }
            static $h = 1572871;
            static $f = 0b10010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 131073,
  "p": [
//--TRIMMABLE-BOUNDARY-START(47246213127),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 60131115015,
        "f": 50331649
      },
      "n": "Count",
      "d": 1572871,
      "h": 47246213127,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(47246213127),
//--TRIMMABLE-BOUNDARY-START(90195886087),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 68721049607,
        "f": 50331649
      },
      "n": "InitialThreshold",
      "d": 1572871,
      "h": 90195886087,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(90195886087),
//--TRIMMABLE-BOUNDARY-START(94490853383),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 77310984199,
        "f": 50331649
      },
      "n": "MaximumThreshold",
      "d": 1572871,
      "h": 94490853383,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(94490853383),
//--TRIMMABLE-BOUNDARY-START(98785820679),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 85900918791,
        "f": 50331649
      },
      "n": "Name",
      "d": 1572871,
      "h": 98785820679,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(98785820679)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(42951245831),
    {
      "r": 65537,
      "n": "Add",
      "d": 1572871,
      "h": 42951245831,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(42951245831),
//--TRIMMABLE-BOUNDARY-START(103080787975),
    {
      "r": 65537,
      "n": "Remove",
      "d": 1572871,
      "h": 103080787975,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(103080787975)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(51541180423),
    {
      "t": 655361,
      "n": "DeltaPercent",
      "d": 1572871,
      "h": 51541180423,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(51541180423),
//--TRIMMABLE-BOUNDARY-START(17181442055),
    {
      "t": 655361,
      "n": "_threshold",
      "d": 1572871,
      "h": 17181442055,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(17181442055),
//--TRIMMABLE-BOUNDARY-START(12886474759),
    {
      "t": 655361,
      "n": "_handleCount",
      "d": 1572871,
      "h": 12886474759,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(12886474759),
//--TRIMMABLE-BOUNDARY-START(4296540167),
    {
      "t": $.$typeArray($.$$.System.Int32).$h,
      "n": "_gcCounts",
      "d": 1572871,
      "h": 4296540167,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(4296540167),
//--TRIMMABLE-BOUNDARY-START(8591507463),
    {
      "t": 655361,
      "n": "_gcGeneration",
      "d": 1572871,
      "h": 8591507463,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(8591507463)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(21476409351),
    {
      "p": [
        {
          "n": "name",
          "p": 1310721
        },
        {
          "n": "initialThreshold",
          "p": 655361
        }
      ],
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 1572871,
      "h": 21476409351,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(21476409351),
//--TRIMMABLE-BOUNDARY-START(25771376647),
    {
      "p": [
        {
          "n": "name",
          "p": 1310721
        },
        {
          "n": "initialThreshold",
          "p": 655361
        },
        {
          "n": "maximumThreshold",
          "p": 655361
        }
      ],
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 1572871,
      "h": 25771376647,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(25771376647)
  ],
  "h": 1572871
}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `System.Runtime.InteropServices.HandleCollector`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1572871)
        
        
        //--TRIMMABLE-BOUNDARY-START(2228231)
        $asm.$cls("$sris.System.Runtime.InteropServices.Marshalling.ComVariantMarshaller", ($self) => class ComVariantMarshaller
        {
            //--TRIMMABLE-BOUNDARY-START(30066999303)
            /*short*/ static VARIANT_TRUE = -1;
            //--TRIMMABLE-BOUNDARY-END(30066999303)
            
            //--TRIMMABLE-BOUNDARY-START(25772032007)
            /*short*/ static VARIANT_FALSE = 0;
            //--TRIMMABLE-BOUNDARY-END(25772032007)
            
            //--TRIMMABLE-BOUNDARY-START(8592162823)
            static /*ComVariant */ ConvertToUnmanaged(/*object?*/ managed)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8592162823);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (managed === null)
                {
                    return new $.$$.System.Runtime.InteropServices.Marshalling.ComVariant();
                }
                //switch (managed)
                {
                    let s;
                    let b;
                    let i;
                    let l;
                    let f;
                    let d;
                    let dt;
                    let errorWrapper;
                    let currencyWrapper;
                    let bStrWrapper;
                    $switchJumpStart1: 
                    //case sbyte s:
                    if ($.$is(managed, $.$$.System.SByte, { set $v(v){ s = v; } }))
                    {
                        return $.$$.System.Runtime.InteropServices.Marshalling.ComVariant.Create($.$$.System.SByte, s);
                    }
                    //case byte b:
                    else if ($.$is(managed, $.$$.System.Byte, { set $v(v){ b = v; } }))
                    {
                        return $.$$.System.Runtime.InteropServices.Marshalling.ComVariant.Create($.$$.System.Byte, b);
                    }
                    //case short s:
                    else if ($.$is(managed, $.$$.System.Int16, { set $v(v){ s = v; } }))
                    {
                        return $.$$.System.Runtime.InteropServices.Marshalling.ComVariant.Create($.$$.System.Int16, s);
                    }
                    //case ushort s:
                    else if ($.$is(managed, $.$$.System.UInt16, { set $v(v){ s = v; } }))
                    {
                        return $.$$.System.Runtime.InteropServices.Marshalling.ComVariant.Create($.$$.System.UInt16, s);
                    }
                    //case int i:
                    else if ($.$is(managed, $.$$.System.Int32, { set $v(v){ i = v; } }))
                    {
                        return $.$$.System.Runtime.InteropServices.Marshalling.ComVariant.Create($.$$.System.Int32, i);
                    }
                    //case uint i:
                    else if ($.$is(managed, $.$$.System.UInt32, { set $v(v){ i = v; } }))
                    {
                        return $.$$.System.Runtime.InteropServices.Marshalling.ComVariant.Create($.$$.System.UInt32, i);
                    }
                    //case long l:
                    else if ($.$is(managed, $.$$.System.Int64, { set $v(v){ l = v; } }))
                    {
                        return $.$$.System.Runtime.InteropServices.Marshalling.ComVariant.Create($.$$.System.Int64, l);
                    }
                    //case ulong l:
                    else if ($.$is(managed, $.$$.System.UInt64, { set $v(v){ l = v; } }))
                    {
                        return $.$$.System.Runtime.InteropServices.Marshalling.ComVariant.Create($.$$.System.UInt64, l);
                    }
                    //case float f:
                    else if ($.$is(managed, $.$$.System.Single, { set $v(v){ f = v; } }))
                    {
                        return $.$$.System.Runtime.InteropServices.Marshalling.ComVariant.Create($.$$.System.Single, f);
                    }
                    //case double d:
                    else if ($.$is(managed, $.$$.System.Double, { set $v(v){ d = v; } }))
                    {
                        return $.$$.System.Runtime.InteropServices.Marshalling.ComVariant.Create($.$$.System.Double, d);
                    }
                    //case decimal d:
                    else if ($.$is(managed, $.$$.System.Decimal, { set $v(v){ d = v; } }))
                    {
                        return $.$$.System.Runtime.InteropServices.Marshalling.ComVariant.Create($.$$.System.Decimal, d);
                    }
                    //case bool b:
                    else if ($.$is(managed, $.$$.System.Boolean, { set $v(v){ b = v; } }))
                    {
                        return $.$$.System.Runtime.InteropServices.Marshalling.ComVariant.Create($.$$.System.Boolean, b);
                    }
                    //case string s:
                    else if ($.$is(managed, $.$$.System.String, { set $v(v){ s = v; } }))
                    {
                        return $.$$.System.Runtime.InteropServices.Marshalling.ComVariant.Create($.$$.System.String, s);
                    }
                    //case DateTime dt:
                    else if ($.$is(managed, $.$$.System.DateTime, { set $v(v){ dt = v; } }))
                    {
                        return $.$$.System.Runtime.InteropServices.Marshalling.ComVariant.Create($.$$.System.DateTime, dt);
                    }
                    //case ErrorWrapper errorWrapper:
                    else if ($.$is(managed, $.$$.System.Runtime.InteropServices.ErrorWrapper, { set $v(v){ errorWrapper = v; } }))
                    {
                        return $.$$.System.Runtime.InteropServices.Marshalling.ComVariant.Create($.$$.System.Runtime.InteropServices.ErrorWrapper, errorWrapper);
                    }
                    //case CurrencyWrapper currencyWrapper:
                    else if ($.$is(managed, $.$$.System.Runtime.InteropServices.CurrencyWrapper, { set $v(v){ currencyWrapper = v; } }))
                    {
                        return $.$$.System.Runtime.InteropServices.Marshalling.ComVariant.Create($.$$.System.Runtime.InteropServices.CurrencyWrapper, currencyWrapper);
                    }
                    //case BStrWrapper bStrWrapper:
                    else if ($.$is(managed, $.$$.System.Runtime.InteropServices.BStrWrapper, { set $v(v){ bStrWrapper = v; } }))
                    {
                        return $.$$.System.Runtime.InteropServices.Marshalling.ComVariant.Create($.$$.System.Runtime.InteropServices.BStrWrapper, bStrWrapper);
                    }
                    //case DBNull:
                    else if (managed == $.$$.System.DBNull)
                    {
                        return $.$$.System.Runtime.InteropServices.Marshalling.ComVariant.Null;
                    }
                }
                /*ComVariant*/ let variant;
                if ($.$sris.System.Runtime.InteropServices.Marshalling.ComVariantMarshaller.TryCreateOleVariantForInterfaceWrapper(managed, $.$ref(() => variant, ($v) => variant = $v, $.$$.System.Runtime.InteropServices.Marshalling.ComVariant)))
                {
                    return variant;
                }
                throw new $.$$.System.ArgumentException().$ctor$13($.$sris.System.SR.ComVariantMarshaller_ManagedTypeNotSupported, "managed");
            }
            //--TRIMMABLE-BOUNDARY-END(8592162823)
            
            //--TRIMMABLE-BOUNDARY-START(21477064711)
            static /*bool */ TryCreateOleVariantForInterfaceWrapper(/*object*/ managed, /*out ComVariant*/ variant)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21477064711);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                let uw;
                if ($.$is(managed, $.$$.System.Runtime.InteropServices.UnknownWrapper, { set $v(v){ uw = v; } }))
                {
                    /*object?*/ let wrapped = uw.WrappedObject;
                    if (wrapped === null)
                    {
                        variant.$v = new $.$$.System.Runtime.InteropServices.Marshalling.ComVariant();
                        return true;
                    }
                    variant.$v = $.$$.System.Runtime.InteropServices.Marshalling.ComVariant.CreateRaw($.$$.System.IntPtr, 13/*VarEnum.VT_UNKNOWN*/, $.$sris.System.Runtime.InteropServices.Marshalling.StrategyBasedComWrappers.DefaultMarshallingInstance.GetOrCreateComInterfaceForObject(wrapped, 0/*CreateComInterfaceFlags.None*/));
                    return true;
                }
                else if (!(managed === null) && !($.$sris.System.Runtime.InteropServices.Marshalling.StrategyBasedComWrappers.DefaultIUnknownInterfaceDetailsStrategy.System$Runtime$InteropServices$Marshalling$IIUnknownInterfaceDetailsStrategy$GetComExposedTypeDetails($.$$.System.Object.GetType.call(managed).TypeHandle) === null))
                {
                    variant.$v = $.$$.System.Runtime.InteropServices.Marshalling.ComVariant.CreateRaw($.$$.System.IntPtr, 13/*VarEnum.VT_UNKNOWN*/, $.$sris.System.Runtime.InteropServices.Marshalling.StrategyBasedComWrappers.DefaultMarshallingInstance.GetOrCreateComInterfaceForObject(managed, 0/*CreateComInterfaceFlags.None*/));
                    return true;
                }
                variant.$v = new $.$$.System.Runtime.InteropServices.Marshalling.ComVariant();
                return false;
            }
            //--TRIMMABLE-BOUNDARY-END(21477064711)
            
            //--TRIMMABLE-BOUNDARY-START(4297195527)
            static /*object? */ ConvertToManaged(/*ComVariant*/ unmanaged)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4297195527);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                let $switch1 = unmanaged.VarType;
                switch($switch1)
                {
                    case 0/*VarEnum.VT_EMPTY*/:
                    case 16384/*VarEnum.VT_BYREF*/ | 0/*VarEnum.VT_EMPTY*/:
                    return null;
                    case 1/*VarEnum.VT_NULL*/:
                    case 16384/*VarEnum.VT_BYREF*/ | 1/*VarEnum.VT_NULL*/:
                    return $.$$.System.DBNull.Value;
                    case 16/*VarEnum.VT_I1*/:
                    return $.$box(unmanaged.As($.$$.System.SByte), $.$$.System.SByte);
                    case 17/*VarEnum.VT_UI1*/:
                    return $.$box(unmanaged.As($.$$.System.Byte), $.$$.System.Byte);
                    case 2/*VarEnum.VT_I2*/:
                    return $.$box(unmanaged.As($.$$.System.Int16), $.$$.System.Int16);
                    case 18/*VarEnum.VT_UI2*/:
                    return $.$box(unmanaged.As($.$$.System.UInt16), $.$$.System.UInt16);
                    case 22/*VarEnum.VT_INT*/:
                    case 3/*VarEnum.VT_I4*/:
                    return $.$box(unmanaged.As($.$$.System.Int32), $.$$.System.Int32);
                    case 23/*VarEnum.VT_UINT*/:
                    case 19/*VarEnum.VT_UI4*/:
                    return $.$box(unmanaged.As($.$$.System.UInt32), $.$$.System.UInt32);
                    case 20/*VarEnum.VT_I8*/:
                    return $.$box(unmanaged.As($.$$.System.Int64), $.$$.System.Int64);
                    case 21/*VarEnum.VT_UI8*/:
                    return $.$box(unmanaged.As($.$$.System.UInt64), $.$$.System.UInt64);
                    case 4/*VarEnum.VT_R4*/:
                    return $.$box(unmanaged.As($.$$.System.Single), $.$$.System.Single);
                    case 5/*VarEnum.VT_R8*/:
                    return $.$box(unmanaged.As($.$$.System.Double), $.$$.System.Double);
                    case 14/*VarEnum.VT_DECIMAL*/:
                    return unmanaged.As($.$$.System.Decimal);
                    case 11/*VarEnum.VT_BOOL*/:
                    return $.$box(unmanaged.As($.$$.System.Boolean), $.$$.System.Boolean);
                    case 8/*VarEnum.VT_BSTR*/:
                    return unmanaged.As($.$$.System.String);
                    case 7/*VarEnum.VT_DATE*/:
                    return unmanaged.As($.$$.System.DateTime);
                    case 10/*VarEnum.VT_ERROR*/:
                    return $.$box(unmanaged.As($.$$.System.Int32), $.$$.System.Int32);
                    case 6/*VarEnum.VT_CY*/:
                    return unmanaged.As($.$$.System.Runtime.InteropServices.CurrencyWrapper).WrappedObject;
                    case 13/*VarEnum.VT_UNKNOWN*/:
                    case 9/*VarEnum.VT_DISPATCH*/:
                    return $.$sris.System.Runtime.InteropServices.Marshalling.StrategyBasedComWrappers.DefaultMarshallingInstance.GetOrCreateObjectForComInstance$1(unmanaged.GetRawDataRef($.$$.System.IntPtr).$v, 8/*CreateObjectFlags.Unwrap*/);
                    case 16384/*VarEnum.VT_BYREF*/ | 12/*VarEnum.VT_VARIANT*/:
                    return $.$sris.System.Runtime.InteropServices.Marshalling.ComVariantMarshaller.ConvertToManaged($.$$.$interop.castAddress2Object(unmanaged.GetRawDataRef($.$$.System.IntPtr).$v));
                    case 16384/*VarEnum.VT_BYREF*/ | 16/*VarEnum.VT_I1*/:
                    return $.$box($.$$.$interop.castAddress2Object(unmanaged.GetRawDataRef($.$$.System.IntPtr).$v), $.$$.System.SByte);
                    case 16384/*VarEnum.VT_BYREF*/ | 17/*VarEnum.VT_UI1*/:
                    return $.$box($.$$.$interop.castAddress2Object(unmanaged.GetRawDataRef($.$$.System.IntPtr).$v), $.$$.System.Byte);
                    case 16384/*VarEnum.VT_BYREF*/ | 2/*VarEnum.VT_I2*/:
                    return $.$box($.$$.$interop.castAddress2Object(unmanaged.GetRawDataRef($.$$.System.IntPtr).$v), $.$$.System.Int16);
                    case 16384/*VarEnum.VT_BYREF*/ | 18/*VarEnum.VT_UI2*/:
                    return $.$box($.$$.$interop.castAddress2Object(unmanaged.GetRawDataRef($.$$.System.IntPtr).$v), $.$$.System.UInt16);
                    case 16384/*VarEnum.VT_BYREF*/ | 3/*VarEnum.VT_I4*/:
                    return $.$box($.$$.$interop.castAddress2Object(unmanaged.GetRawDataRef($.$$.System.IntPtr).$v), $.$$.System.Int32);
                    case 16384/*VarEnum.VT_BYREF*/ | 19/*VarEnum.VT_UI4*/:
                    return $.$box($.$$.$interop.castAddress2Object(unmanaged.GetRawDataRef($.$$.System.IntPtr).$v), $.$$.System.UInt32);
                    case 16384/*VarEnum.VT_BYREF*/ | 20/*VarEnum.VT_I8*/:
                    return $.$box($.$$.$interop.castAddress2Object(unmanaged.GetRawDataRef($.$$.System.IntPtr).$v), $.$$.System.Int64);
                    case 16384/*VarEnum.VT_BYREF*/ | 21/*VarEnum.VT_UI8*/:
                    return $.$box($.$$.$interop.castAddress2Object(unmanaged.GetRawDataRef($.$$.System.IntPtr).$v), $.$$.System.UInt64);
                    case 16384/*VarEnum.VT_BYREF*/ | 4/*VarEnum.VT_R4*/:
                    return $.$box($.$$.$interop.castAddress2Object(unmanaged.GetRawDataRef($.$$.System.IntPtr).$v), $.$$.System.Single);
                    case 16384/*VarEnum.VT_BYREF*/ | 5/*VarEnum.VT_R8*/:
                    return $.$box($.$$.$interop.castAddress2Object(unmanaged.GetRawDataRef($.$$.System.IntPtr).$v), $.$$.System.Double);
                    case 16384/*VarEnum.VT_BYREF*/ | 14/*VarEnum.VT_DECIMAL*/:
                    return $.$$.$interop.castAddress2Object(unmanaged.GetRawDataRef($.$$.System.IntPtr).$v);
                    case 16384/*VarEnum.VT_BYREF*/ | 11/*VarEnum.VT_BOOL*/:
                    return $.$box($.$$.$interop.castAddress2Object(unmanaged.GetRawDataRef($.$$.System.IntPtr).$v) !== 0/*VARIANT_FALSE*/, $.$$.System.Boolean);
                    case 16384/*VarEnum.VT_BYREF*/ | 8/*VarEnum.VT_BSTR*/:
                    return $.$$.System.Runtime.InteropServices.Marshal.PtrToStringBSTR($.$$.$interop.castAddress2Object(unmanaged.GetRawDataRef($.$$.System.IntPtr).$v));
                    case 16384/*VarEnum.VT_BYREF*/ | 7/*VarEnum.VT_DATE*/:
                    return $.$$.System.DateTime.FromOADate($.$$.$interop.castAddress2Object(unmanaged.GetRawDataRef($.$$.System.IntPtr).$v));
                    case 16384/*VarEnum.VT_BYREF*/ | 10/*VarEnum.VT_ERROR*/:
                    return $.$box($.$$.$interop.castAddress2Object(unmanaged.GetRawDataRef($.$$.System.IntPtr).$v), $.$$.System.Int32);
                    case 16384/*VarEnum.VT_BYREF*/ | 6/*VarEnum.VT_CY*/:
                    return $.$$.System.Decimal.FromOACurrency($.$$.$interop.castAddress2Object(unmanaged.GetRawDataRef($.$$.System.IntPtr).$v));
                    case 16384/*VarEnum.VT_BYREF*/ | 13/*VarEnum.VT_UNKNOWN*/:
                    return $.$sris.System.Runtime.InteropServices.Marshalling.StrategyBasedComWrappers.DefaultMarshallingInstance.GetOrCreateObjectForComInstance$1($.$$.$interop.castAddress2Object(unmanaged.GetRawDataRef($.$$.System.IntPtr).$v), 8/*CreateObjectFlags.Unwrap*/);
                    default:
                    throw new $.$$.System.ArgumentException().$ctor$13($.$sris.System.SR.ComVariantMarshaller_UnmanagedTypeNotSupported, "unmanaged");
                }
            }
            //--TRIMMABLE-BOUNDARY-END(4297195527)
            
            //--TRIMMABLE-BOUNDARY-START(12887130119)
            static /*void */ Free(/*ComVariant*/ unmanaged)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(12887130119);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return unmanaged.Dispose();
                }
            }
            //--TRIMMABLE-BOUNDARY-END(12887130119)
            
            //--TRIMMABLE-BOUNDARY-START(2293767)
            static $_RefPropagate;
            static get RefPropagate()
            {
                let $cls = $.$sris.System.Runtime.InteropServices.Marshalling.ComVariantMarshaller;
                return $cls.$_RefPropagate ??= $asm.$nstr("$sris.System.Runtime.InteropServices.Marshalling.ComVariantMarshaller.RefPropagate", ($self) => class RefPropagate extends $.$$.System.ValueType
                {
                    //--TRIMMABLE-BOUNDARY-START(8592228359)
                    /*ComVariant*/  get _unmanaged() { return this.$getField(0, 140); }
                    /*ComVariant*/  set _unmanaged(value) { this.$setField(0, 140, value); }
                    //--TRIMMABLE-BOUNDARY-END(8592228359)
                    
                    //--TRIMMABLE-BOUNDARY-START(4297261063)
                    /*object?*/  get _managed() { return this.$getField(140, 4); }
                    /*object?*/  set _managed(value) { this.$setField(140, 4, value); }
                    //--TRIMMABLE-BOUNDARY-END(4297261063)
                    
                    //--TRIMMABLE-BOUNDARY-START(25772097543)
                    /*void */ FromUnmanaged(/*ComVariant*/ unmanaged)
                    {
                        {
                            //--TRIMMABLE-BOUNDARY-START(TRACE)
                            $.$trace(25772097543);
                            //--TRIMMABLE-BOUNDARY-END(TRACE)
                            return this._unmanaged = unmanaged.Clone();
                        }
                    }
                    //--TRIMMABLE-BOUNDARY-END(25772097543)
                    
                    //--TRIMMABLE-BOUNDARY-START(21477130247)
                    /*void */ FromManaged(/*object?*/ managed)
                    {
                        {
                            //--TRIMMABLE-BOUNDARY-START(TRACE)
                            $.$trace(21477130247);
                            //--TRIMMABLE-BOUNDARY-END(TRACE)
                            return this._managed = managed;
                        }
                    }
                    //--TRIMMABLE-BOUNDARY-END(21477130247)
                    
                    //--TRIMMABLE-BOUNDARY-START(34362032135)
                    /*ComVariant */ ToUnmanaged()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(34362032135);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        if (!((this._unmanaged.VarType & (16384/*VarEnum.VT_BYREF*/)) == (16384/*VarEnum.VT_BYREF*/)))
                        {
                            return $.$sris.System.Runtime.InteropServices.Marshalling.ComVariantMarshaller.ConvertToUnmanaged(this._managed);
                        }
                        if (this._managed === null && (((this._unmanaged.VarType & ~16384/*VarEnum.VT_BYREF*/) === 8/*VarEnum.VT_BSTR*/) || ((this._unmanaged.VarType & ~16384/*VarEnum.VT_BYREF*/) === 9/*VarEnum.VT_DISPATCH*/)) || ((this._unmanaged.VarType & ~16384/*VarEnum.VT_BYREF*/) === 13/*VarEnum.VT_UNKNOWN*/))
                        {
                            $.$$.$interop.castAddress2Object(this._unmanaged.GetRawDataRef($.$$.System.IntPtr).$v).$v = 0;
                            return this._unmanaged;
                        }
                        //switch ((_unmanaged.VarType & ~VarEnum.VT_BYREF, _managed))
                        let $switch2 = this._unmanaged.VarType & ~16384/*VarEnum.VT_BYREF*/;
                        let $switch3 = this._managed;
                        {
                            let s;
                            let b;
                            let u;
                            let i;
                            let l;
                            let ul;
                            let f;
                            let d;
                            let str;
                            let dt;
                            let error;
                            let cy;
                            let unkObj;
                            $switchJumpStart1: 
                            //case (VarEnum.VT_VARIANT, _):
                            if (($switch2 === 12/*VarEnum.VT_VARIANT*/))
                            {
                                $.$$.$interop.castAddress2Object(this._unmanaged.GetRawDataRef($.$$.System.IntPtr).$v).$v = $.$sris.System.Runtime.InteropServices.Marshalling.ComVariantMarshaller.ConvertToUnmanaged(this._managed);
                            }
                            //case (VarEnum.VT_I1 or VarEnum.VT_UI1, sbyte s):
                            else if ((($switch2 === 16/*VarEnum.VT_I1*/) || ($switch2 === 17/*VarEnum.VT_UI1*/)) && ($.$is($switch3, $.$$.System.SByte, { set $v(v){ s = v; } })))
                            {
                                $.$$.$interop.castAddress2Object(this._unmanaged.GetRawDataRef($.$$.System.IntPtr).$v).$v = s;
                            }
                            //case (VarEnum.VT_I1 or VarEnum.VT_UI1, byte b):
                            else if ((($switch2 === 16/*VarEnum.VT_I1*/) || ($switch2 === 17/*VarEnum.VT_UI1*/)) && ($.$is($switch3, $.$$.System.Byte, { set $v(v){ b = v; } })))
                            {
                                $.$$.$interop.castAddress2Object(this._unmanaged.GetRawDataRef($.$$.System.IntPtr).$v).$v = b;
                            }
                            //case (VarEnum.VT_I2 or VarEnum.VT_UI2, short s):
                            else if ((($switch2 === 2/*VarEnum.VT_I2*/) || ($switch2 === 18/*VarEnum.VT_UI2*/)) && ($.$is($switch3, $.$$.System.Int16, { set $v(v){ s = v; } })))
                            {
                                $.$$.$interop.castAddress2Object(this._unmanaged.GetRawDataRef($.$$.System.IntPtr).$v).$v = s;
                            }
                            //case (VarEnum.VT_I2 or VarEnum.VT_UI2, ushort u):
                            else if ((($switch2 === 2/*VarEnum.VT_I2*/) || ($switch2 === 18/*VarEnum.VT_UI2*/)) && ($.$is($switch3, $.$$.System.UInt16, { set $v(v){ u = v; } })))
                            {
                                $.$$.$interop.castAddress2Object(this._unmanaged.GetRawDataRef($.$$.System.IntPtr).$v).$v = u;
                            }
                            //case (VarEnum.VT_I4 or VarEnum.VT_INT or VarEnum.VT_UI4 or VarEnum.VT_UINT or VarEnum.VT_ERROR, int i):
                            else if (((((($switch2 === 3/*VarEnum.VT_I4*/) || ($switch2 === 22/*VarEnum.VT_INT*/)) || ($switch2 === 19/*VarEnum.VT_UI4*/)) || ($switch2 === 23/*VarEnum.VT_UINT*/)) || ($switch2 === 10/*VarEnum.VT_ERROR*/)) && ($.$is($switch3, $.$$.System.Int32, { set $v(v){ i = v; } })))
                            {
                                $.$$.$interop.castAddress2Object(this._unmanaged.GetRawDataRef($.$$.System.IntPtr).$v).$v = i;
                            }
                            //case (VarEnum.VT_I4 or VarEnum.VT_INT or VarEnum.VT_UI4 or VarEnum.VT_UINT or VarEnum.VT_ERROR, uint u):
                            else if (((((($switch2 === 3/*VarEnum.VT_I4*/) || ($switch2 === 22/*VarEnum.VT_INT*/)) || ($switch2 === 19/*VarEnum.VT_UI4*/)) || ($switch2 === 23/*VarEnum.VT_UINT*/)) || ($switch2 === 10/*VarEnum.VT_ERROR*/)) && ($.$is($switch3, $.$$.System.UInt32, { set $v(v){ u = v; } })))
                            {
                                $.$$.$interop.castAddress2Object(this._unmanaged.GetRawDataRef($.$$.System.IntPtr).$v).$v = u;
                            }
                            //case (VarEnum.VT_I8 or VarEnum.VT_UI8, long l):
                            else if ((($switch2 === 20/*VarEnum.VT_I8*/) || ($switch2 === 21/*VarEnum.VT_UI8*/)) && ($.$is($switch3, $.$$.System.Int64, { set $v(v){ l = v; } })))
                            {
                                $.$$.$interop.castAddress2Object(this._unmanaged.GetRawDataRef($.$$.System.IntPtr).$v).$v = l;
                            }
                            //case (VarEnum.VT_I8 or VarEnum.VT_UI8, ulong ul):
                            else if ((($switch2 === 20/*VarEnum.VT_I8*/) || ($switch2 === 21/*VarEnum.VT_UI8*/)) && ($.$is($switch3, $.$$.System.UInt64, { set $v(v){ ul = v; } })))
                            {
                                $.$$.$interop.castAddress2Object(this._unmanaged.GetRawDataRef($.$$.System.IntPtr).$v).$v = ul;
                            }
                            //case (VarEnum.VT_R4, float f):
                            else if (($switch2 === 4/*VarEnum.VT_R4*/) && ($.$is($switch3, $.$$.System.Single, { set $v(v){ f = v; } })))
                            {
                                $.$$.$interop.castAddress2Object(this._unmanaged.GetRawDataRef($.$$.System.IntPtr).$v).$v = f;
                            }
                            //case (VarEnum.VT_R8, double d):
                            else if (($switch2 === 5/*VarEnum.VT_R8*/) && ($.$is($switch3, $.$$.System.Double, { set $v(v){ d = v; } })))
                            {
                                $.$$.$interop.castAddress2Object(this._unmanaged.GetRawDataRef($.$$.System.IntPtr).$v).$v = d;
                            }
                            //case (VarEnum.VT_DECIMAL, decimal d):
                            else if (($switch2 === 14/*VarEnum.VT_DECIMAL*/) && ($.$is($switch3, $.$$.System.Decimal, { set $v(v){ d = v; } })))
                            {
                                $.$$.$interop.castAddress2Object(this._unmanaged.GetRawDataRef($.$$.System.IntPtr).$v).$v = d;
                            }
                            //case (VarEnum.VT_BOOL, bool b):
                            else if (($switch2 === 11/*VarEnum.VT_BOOL*/) && ($.$is($switch3, $.$$.System.Boolean, { set $v(v){ b = v; } })))
                            {
                                $.$$.$interop.castAddress2Object(this._unmanaged.GetRawDataRef($.$$.System.IntPtr).$v).$v = b ? -1/*VARIANT_TRUE*/ : 0/*VARIANT_FALSE*/;
                            }
                            //case (VarEnum.VT_BSTR, string str):
                            else if (($switch2 === 8/*VarEnum.VT_BSTR*/) && ($.$is($switch3, $.$$.System.String, { set $v(v){ str = v; } })))
                            {
                                {
                                    /*ref IntPtr*/ let bstrStorage = $.$cast(this._unmanaged.GetRawDataRef($.$$.System.IntPtr).$v, $.$typePointer($.$$.System.IntPtr));
                                    $.$$.System.Runtime.InteropServices.Marshal.FreeBSTR(bstrStorage.$v);
                                    bstrStorage.$v = $.$$.System.Runtime.InteropServices.Marshal.StringToBSTR(str);
                                    break $switchJumpStart1;
                                }
                            }
                            //case (VarEnum.VT_BSTR, BStrWrapper str):
                            else if (($switch2 === 8/*VarEnum.VT_BSTR*/) && ($.$is($switch3, $.$$.System.Runtime.InteropServices.BStrWrapper, { set $v(v){ str = v; } })))
                            {
                                {
                                    /*ref IntPtr*/ let bstrStorage = $.$cast(this._unmanaged.GetRawDataRef($.$$.System.IntPtr).$v, $.$typePointer($.$$.System.IntPtr));
                                    $.$$.System.Runtime.InteropServices.Marshal.FreeBSTR(bstrStorage.$v);
                                    bstrStorage.$v = $.$$.System.Runtime.InteropServices.Marshal.StringToBSTR(str.WrappedObject);
                                    break $switchJumpStart1;
                                }
                            }
                            //case (VarEnum.VT_DATE, DateTime dt):
                            else if (($switch2 === 7/*VarEnum.VT_DATE*/) && ($.$is($switch3, $.$$.System.DateTime, { set $v(v){ dt = v; } })))
                            {
                                $.$$.$interop.castAddress2Object(this._unmanaged.GetRawDataRef($.$$.System.IntPtr).$v).$v = dt.ToOADate();
                            }
                            //case (VarEnum.VT_ERROR, ErrorWrapper error):
                            else if (($switch2 === 10/*VarEnum.VT_ERROR*/) && ($.$is($switch3, $.$$.System.Runtime.InteropServices.ErrorWrapper, { set $v(v){ error = v; } })))
                            {
                                $.$$.$interop.castAddress2Object(this._unmanaged.GetRawDataRef($.$$.System.IntPtr).$v).$v = error.ErrorCode;
                            }
                            //case (VarEnum.VT_CY, CurrencyWrapper cy):
                            else if (($switch2 === 6/*VarEnum.VT_CY*/) && ($.$is($switch3, $.$$.System.Runtime.InteropServices.CurrencyWrapper, { set $v(v){ cy = v; } })))
                            {
                                $.$$.$interop.castAddress2Object(this._unmanaged.GetRawDataRef($.$$.System.IntPtr).$v).$v = $.$$.System.Decimal.ToOACurrency(cy.WrappedObject);
                            }
                            //case (VarEnum.VT_UNKNOWN, object unkObj):
                            else if (($switch2 === 13/*VarEnum.VT_UNKNOWN*/) && ($.$is($switch3, $.$$.System.Object, { set $v(v){ unkObj = v; } })))
                            {
                                $.$$.$interop.castAddress2Object(this._unmanaged.GetRawDataRef($.$$.System.IntPtr).$v).$v = $.$sris.System.Runtime.InteropServices.Marshalling.StrategyBasedComWrappers.DefaultMarshallingInstance.GetOrCreateComInterfaceForObject(unkObj, 0/*CreateComInterfaceFlags.None*/);
                            }
                            //default
                            else
                            {
                                throw new $.$$.System.ArgumentException().$ctor$13("Invalid combination of unmanaged variant type and managed object type.", "_managed");
                            }
                        }
                        return this._unmanaged;
                    }
                    //--TRIMMABLE-BOUNDARY-END(34362032135)
                    
                    //--TRIMMABLE-BOUNDARY-START(30067064839)
                    /*object? */ ToManaged()
                    {
                        {
                            //--TRIMMABLE-BOUNDARY-START(TRACE)
                            $.$trace(30067064839);
                            //--TRIMMABLE-BOUNDARY-END(TRACE)
                            return $.$sris.System.Runtime.InteropServices.Marshalling.ComVariantMarshaller.ConvertToManaged(this._unmanaged.Clone());
                        }
                    }
                    //--TRIMMABLE-BOUNDARY-END(30067064839)
                    
                    //--TRIMMABLE-BOUNDARY-START(17182162951)
                    /*void */ Free()
                    {
                        {
                            //--TRIMMABLE-BOUNDARY-START(TRACE)
                            $.$trace(17182162951);
                            //--TRIMMABLE-BOUNDARY-END(TRACE)
                            return this._unmanaged.Dispose();
                        }
                    }
                    //--TRIMMABLE-BOUNDARY-END(17182162951)
                    
                    //default value type constructor
                    $ctor$2()
                    {
                        return this;
                    }
                    Clone($copy)
                    {
                        let copy = $copy ?? new this.constructor();
                        copy._unmanaged = this._unmanaged.Clone();
                        copy._managed = this._managed;
                        return copy;
                    }
                    //default member initializer
                    constructor()
                    {
                        super();
                        //--TRIMMABLE-BOUNDARY-START(8592228359)
                        this._unmanaged = $.$default($.$$.System.Runtime.InteropServices.Marshalling.ComVariant);
                        //--TRIMMABLE-BOUNDARY-END(8592228359)
                        
                        //--TRIMMABLE-BOUNDARY-START(4297261063)
                        this._managed = null;
                        //--TRIMMABLE-BOUNDARY-END(4297261063)
                        
                    }
                    static $h = 2293767;
                    static $z = 144;
                    static $f = 0b10000001010000001;
                    static $k = 2;
                    static $$md;
                    static get $md() { return this.$$md ??= {
  "b": 196609,
  "m": [
//--TRIMMABLE-BOUNDARY-START(25772097543),
    {
      "r": 65537,
      "p": [
        {
          "n": "unmanaged",
          "p": 143589377
        }
      ],
      "n": "FromUnmanaged",
      "d": 2293767,
      "h": 25772097543,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(25772097543),
//--TRIMMABLE-BOUNDARY-START(21477130247),
    {
      "r": 65537,
      "p": [
        {
          "n": "managed",
          "p": 131073
        }
      ],
      "n": "FromManaged",
      "d": 2293767,
      "h": 21477130247,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(21477130247),
//--TRIMMABLE-BOUNDARY-START(34362032135),
    {
      "r": 143589377,
      "n": "ToUnmanaged",
      "d": 2293767,
      "h": 34362032135,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(34362032135),
//--TRIMMABLE-BOUNDARY-START(30067064839),
    {
      "r": 131073,
      "n": "ToManaged",
      "d": 2293767,
      "h": 30067064839,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(30067064839),
//--TRIMMABLE-BOUNDARY-START(17182162951),
    {
      "r": 65537,
      "n": "Free",
      "d": 2293767,
      "h": 17182162951,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(17182162951)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(8592228359),
    {
      "t": 143589377,
      "n": "_unmanaged",
      "d": 2293767,
      "h": 8592228359,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(8592228359),
//--TRIMMABLE-BOUNDARY-START(4297261063),
    {
      "t": 131073,
      "n": "_managed",
      "d": 2293767,
      "h": 4297261063,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(4297261063)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(12887195655),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 2293767,
      "h": 12887195655,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(12887195655)
  ],
  "d": 2228231,
  "h": 2293767
}; }
                    static get $b() { return $.$$.System.ValueType; }
                    static get $fullName() { return `System.Runtime.InteropServices.Marshalling.ComVariantMarshaller.RefPropagate`; }
                }, $cls, ($v) => $cls.$_RefPropagate = $v);
            }
            //--TRIMMABLE-BOUNDARY-END(2293767)
            
            static $h = 2228231;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 131073,
  "m": [
//--TRIMMABLE-BOUNDARY-START(8592162823),
    {
      "r": 143589377,
      "p": [
        {
          "n": "managed",
          "p": 131073
        }
      ],
      "n": "ConvertToUnmanaged",
      "d": 2228231,
      "h": 8592162823,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8592162823),
//--TRIMMABLE-BOUNDARY-START(21477064711),
    {
      "r": 262145,
      "p": [
        {
          "n": "managed",
          "p": 131073
        },
        {
          "n": "variant",
          "p": 143589377,
          "f": 2
        }
      ],
      "n": "TryCreateOleVariantForInterfaceWrapper",
      "d": 2228231,
      "h": 21477064711,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(21477064711),
//--TRIMMABLE-BOUNDARY-START(4297195527),
    {
      "r": 131073,
      "p": [
        {
          "n": "unmanaged",
          "p": 143589377
        }
      ],
      "n": "ConvertToManaged",
      "d": 2228231,
      "h": 4297195527,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(4297195527),
//--TRIMMABLE-BOUNDARY-START(12887130119),
    {
      "r": 65537,
      "p": [
        {
          "n": "unmanaged",
          "p": 143589377
        }
      ],
      "n": "Free",
      "d": 2228231,
      "h": 12887130119,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(12887130119)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(30066999303),
    {
      "t": 524289,
      "n": "VARIANT_TRUE",
      "d": 2228231,
      "h": 30066999303,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(30066999303),
//--TRIMMABLE-BOUNDARY-START(25772032007),
    {
      "t": 524289,
      "n": "VARIANT_FALSE",
      "d": 2228231,
      "h": 25772032007,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(25772032007)
  ],
  "j": [2293767
  ],
  "h": 2228231,
  "a": [
    {
      "t": 144179201,
      "c": 4439146497,
      "a": [
        {
          "v": 131073,
          "t": 187629569
        },
        {
          "v": 0,
          "t": 144310273
        },
        {
          "v": 2228231,
          "t": 187629569
        }
      ]
    },
    {
      "t": 144179201,
      "c": 4439146497,
      "a": [
        {
          "v": 131073,
          "t": 187629569
        },
        {
          "v": 5,
          "t": 144310273
        },
        {
          "v": 2293767,
          "t": 187629569
        }
      ]
    }
  ]
}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `System.Runtime.InteropServices.Marshalling.ComVariantMarshaller`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2228231)
        
        
        //--TRIMMABLE-BOUNDARY-START(2555911)
        $asm.$cls("$sris.System.Runtime.InteropServices.Marshalling.ExceptionAsHResultMarshaller<>", (T) => $asm.$gt("$sris.System.Runtime.InteropServices.Marshalling.ExceptionAsHResultMarshaller<>", [T], ($self) => class ExceptionAsHResultMarshaller$$
        {
            //--TRIMMABLE-BOUNDARY-START(4297523207)
            static /*T */ ConvertToUnmanaged(/*Exception*/ e)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4297523207);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return T.System$Numerics$INumberBase$$$CreateTruncating($.$$.System.Int32, $.$$.System.Runtime.InteropServices.Marshal.GetHRForException(e));
            }
            //--TRIMMABLE-BOUNDARY-END(4297523207)
            
            static $h = 2555911;
            static $g = 1;
            static $f = 0b1010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 131073,
  "m": [
//--TRIMMABLE-BOUNDARY-START(4297523207),
    {
      "r": T?.$h??1507328,
      "p": [
        {
          "n": "e",
          "p": 79888385
        }
      ],
      "n": "ConvertToUnmanaged",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x100000000n),
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(4297523207)
  ],
  "g": [T?.$h??1507328
  ],
  "s": [
    {
      "n": "T",
      "f": 10,
      "c": [$.$$.System.Numerics.INumber$$(T).$h
      ]
    }
  ],
  "r": 1,
  "h": this.$h,
  "a": [
    {
      "t": 144179201,
      "c": 4439146497,
      "a": [
        {
          "v": 79888385,
          "t": 187629569
        },
        {
          "v": 6,
          "t": 144310273
        },
        {
          "v": $.$sris.System.Runtime.InteropServices.Marshalling.ExceptionAsHResultMarshaller$$().$h,
          "t": 187629569
        }
      ]
    }
  ]
}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `System.Runtime.InteropServices.Marshalling.ExceptionAsHResultMarshaller<${T?.$fullName}>`; }
        }));
        //--TRIMMABLE-BOUNDARY-END(2555911)
        
        
        //--TRIMMABLE-BOUNDARY-START(65543)
        $asm.$cls("$sris.System.Obsoletions", ($self) => class Obsoletions
        {
            //--TRIMMABLE-BOUNDARY-START(382252154887)
            /*string*/ static SharedUrlFormat = null;
            //--TRIMMABLE-BOUNDARY-END(382252154887)
            
            //--TRIMMABLE-BOUNDARY-START(433791762439)
            /*string*/ static SystemTextEncodingUTF7Message = null;
            //--TRIMMABLE-BOUNDARY-END(433791762439)
            
            //--TRIMMABLE-BOUNDARY-START(429496795143)
            /*string*/ static SystemTextEncodingUTF7DiagId = null;
            //--TRIMMABLE-BOUNDARY-END(429496795143)
            
            //--TRIMMABLE-BOUNDARY-START(266288037895)
            /*string*/ static PrincipalPermissionAttributeMessage = null;
            //--TRIMMABLE-BOUNDARY-END(266288037895)
            
            //--TRIMMABLE-BOUNDARY-START(261993070599)
            /*string*/ static PrincipalPermissionAttributeDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(261993070599)
            
            //--TRIMMABLE-BOUNDARY-START(77309476871)
            /*string*/ static CodeAccessSecurityMessage = null;
            //--TRIMMABLE-BOUNDARY-END(77309476871)
            
            //--TRIMMABLE-BOUNDARY-START(73014509575)
            /*string*/ static CodeAccessSecurityDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(73014509575)
            
            //--TRIMMABLE-BOUNDARY-START(94489346055)
            /*string*/ static ConstrainedExecutionRegionMessage = null;
            //--TRIMMABLE-BOUNDARY-END(94489346055)
            
            //--TRIMMABLE-BOUNDARY-START(90194378759)
            /*string*/ static ConstrainedExecutionRegionDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(90194378759)
            
            //--TRIMMABLE-BOUNDARY-START(214748430343)
            /*string*/ static GlobalAssemblyCacheMessage = null;
            //--TRIMMABLE-BOUNDARY-END(214748430343)
            
            //--TRIMMABLE-BOUNDARY-START(210453463047)
            /*string*/ static GlobalAssemblyCacheDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(210453463047)
            
            //--TRIMMABLE-BOUNDARY-START(442381697031)
            /*string*/ static ThreadAbortMessage = null;
            //--TRIMMABLE-BOUNDARY-END(442381697031)
            
            //--TRIMMABLE-BOUNDARY-START(446676664327)
            /*string*/ static ThreadResetAbortMessage = null;
            //--TRIMMABLE-BOUNDARY-END(446676664327)
            
            //--TRIMMABLE-BOUNDARY-START(438086729735)
            /*string*/ static ThreadAbortDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(438086729735)
            
            //--TRIMMABLE-BOUNDARY-START(146028953607)
            /*string*/ static DefaultCryptoAlgorithmsMessage = null;
            //--TRIMMABLE-BOUNDARY-END(146028953607)
            
            //--TRIMMABLE-BOUNDARY-START(141733986311)
            /*string*/ static DefaultCryptoAlgorithmsDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(141733986311)
            
            //--TRIMMABLE-BOUNDARY-START(120259149831)
            /*string*/ static CreatePdbGeneratorMessage = null;
            //--TRIMMABLE-BOUNDARY-END(120259149831)
            
            //--TRIMMABLE-BOUNDARY-START(115964182535)
            /*string*/ static CreatePdbGeneratorDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(115964182535)
            
            //--TRIMMABLE-BOUNDARY-START(51539673095)
            /*string*/ static AuthenticationManagerMessage = null;
            //--TRIMMABLE-BOUNDARY-END(51539673095)
            
            //--TRIMMABLE-BOUNDARY-START(47244705799)
            /*string*/ static AuthenticationManagerDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(47244705799)
            
            //--TRIMMABLE-BOUNDARY-START(326417580039)
            /*string*/ static RemotingApisMessage = null;
            //--TRIMMABLE-BOUNDARY-END(326417580039)
            
            //--TRIMMABLE-BOUNDARY-START(322122612743)
            /*string*/ static RemotingApisDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(322122612743)
            
            //--TRIMMABLE-BOUNDARY-START(60129607687)
            /*string*/ static BinaryFormatterMessage = null;
            //--TRIMMABLE-BOUNDARY-END(60129607687)
            
            //--TRIMMABLE-BOUNDARY-START(55834640391)
            /*string*/ static BinaryFormatterDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(55834640391)
            
            //--TRIMMABLE-BOUNDARY-START(85899411463)
            /*string*/ static CodeBaseMessage = null;
            //--TRIMMABLE-BOUNDARY-END(85899411463)
            
            //--TRIMMABLE-BOUNDARY-START(81604444167)
            /*string*/ static CodeBaseDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(81604444167)
            
            //--TRIMMABLE-BOUNDARY-START(197568561159)
            /*string*/ static EscapeUriStringMessage = null;
            //--TRIMMABLE-BOUNDARY-END(197568561159)
            
            //--TRIMMABLE-BOUNDARY-START(193273593863)
            /*string*/ static EscapeUriStringDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(193273593863)
            
            //--TRIMMABLE-BOUNDARY-START(489626337287)
            /*string*/ static WebRequestMessage = null;
            //--TRIMMABLE-BOUNDARY-END(489626337287)
            
            //--TRIMMABLE-BOUNDARY-START(485331369991)
            /*string*/ static WebRequestDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(485331369991)
            
            //--TRIMMABLE-BOUNDARY-START(163208822791)
            /*string*/ static DisablePrivateReflectionAttributeMessage = null;
            //--TRIMMABLE-BOUNDARY-END(163208822791)
            
            //--TRIMMABLE-BOUNDARY-START(158913855495)
            /*string*/ static DisablePrivateReflectionAttributeDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(158913855495)
            
            //--TRIMMABLE-BOUNDARY-START(206158495751)
            /*string*/ static GetContextInfoMessage = null;
            //--TRIMMABLE-BOUNDARY-END(206158495751)
            
            //--TRIMMABLE-BOUNDARY-START(201863528455)
            /*string*/ static GetContextInfoDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(201863528455)
            
            //--TRIMMABLE-BOUNDARY-START(399432024071)
            /*string*/ static StrongNameKeyPairMessage = null;
            //--TRIMMABLE-BOUNDARY-END(399432024071)
            
            //--TRIMMABLE-BOUNDARY-START(395137056775)
            /*string*/ static StrongNameKeyPairDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(395137056775)
            
            //--TRIMMABLE-BOUNDARY-START(300647776263)
            /*string*/ static ReflectionOnlyLoadingMessage = null;
            //--TRIMMABLE-BOUNDARY-END(300647776263)
            
            //--TRIMMABLE-BOUNDARY-START(296352808967)
            /*string*/ static ReflectionOnlyLoadingDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(296352808967)
            
            //--TRIMMABLE-BOUNDARY-START(377957187591)
            /*string*/ static RuntimeEnvironmentMessage = null;
            //--TRIMMABLE-BOUNDARY-END(377957187591)
            
            //--TRIMMABLE-BOUNDARY-START(373662220295)
            /*string*/ static RuntimeEnvironmentDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(373662220295)
            
            //--TRIMMABLE-BOUNDARY-START(231928299527)
            /*string*/ static JsonSerializerOptionsIgnoreNullValuesMessage = null;
            //--TRIMMABLE-BOUNDARY-END(231928299527)
            
            //--TRIMMABLE-BOUNDARY-START(227633332231)
            /*string*/ static JsonSerializerOptionsIgnoreNullValuesDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(227633332231)
            
            //--TRIMMABLE-BOUNDARY-START(154618888199)
            /*string*/ static DerivedCryptographicTypesMessage = null;
            //--TRIMMABLE-BOUNDARY-END(154618888199)
            
            //--TRIMMABLE-BOUNDARY-START(150323920903)
            /*string*/ static DerivedCryptographicTypesDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(150323920903)
            
            //--TRIMMABLE-BOUNDARY-START(352187383815)
            /*string*/ static RijndaelMessage = null;
            //--TRIMMABLE-BOUNDARY-END(352187383815)
            
            //--TRIMMABLE-BOUNDARY-START(347892416519)
            /*string*/ static RijndaelDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(347892416519)
            
            //--TRIMMABLE-BOUNDARY-START(360777318407)
            /*string*/ static RNGCryptoServiceProviderMessage = null;
            //--TRIMMABLE-BOUNDARY-END(360777318407)
            
            //--TRIMMABLE-BOUNDARY-START(356482351111)
            /*string*/ static RNGCryptoServiceProviderDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(356482351111)
            
            //--TRIMMABLE-BOUNDARY-START(17179934727)
            /*string*/ static AppDomainCreateUnloadMessage = null;
            //--TRIMMABLE-BOUNDARY-END(17179934727)
            
            //--TRIMMABLE-BOUNDARY-START(12884967431)
            /*string*/ static AppDomainCreateUnloadDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(12884967431)
            
            //--TRIMMABLE-BOUNDARY-START(408021958663)
            /*string*/ static SuppressIldasmAttributeMessage = null;
            //--TRIMMABLE-BOUNDARY-END(408021958663)
            
            //--TRIMMABLE-BOUNDARY-START(403726991367)
            /*string*/ static SuppressIldasmAttributeDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(403726991367)
            
            //--TRIMMABLE-BOUNDARY-START(498216271879)
            /*string*/ static X509CertificateImmutableMessage = null;
            //--TRIMMABLE-BOUNDARY-END(498216271879)
            
            //--TRIMMABLE-BOUNDARY-START(493921304583)
            /*string*/ static X509CertificateImmutableDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(493921304583)
            
            //--TRIMMABLE-BOUNDARY-START(283467907079)
            /*string*/ static PublicKeyPropertyMessage = null;
            //--TRIMMABLE-BOUNDARY-END(283467907079)
            
            //--TRIMMABLE-BOUNDARY-START(279172939783)
            /*string*/ static PublicKeyPropertyDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(279172939783)
            
            //--TRIMMABLE-BOUNDARY-START(506806206471)
            /*string*/ static X509CertificatePrivateKeyMessage = null;
            //--TRIMMABLE-BOUNDARY-END(506806206471)
            
            //--TRIMMABLE-BOUNDARY-START(502511239175)
            /*string*/ static X509CertificatePrivateKeyDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(502511239175)
            
            //--TRIMMABLE-BOUNDARY-START(274877972487)
            /*string*/ static ProduceLegacyHmacValuesMessage = null;
            //--TRIMMABLE-BOUNDARY-END(274877972487)
            
            //--TRIMMABLE-BOUNDARY-START(270583005191)
            /*string*/ static ProduceLegacyHmacValuesDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(270583005191)
            
            //--TRIMMABLE-BOUNDARY-START(481036402695)
            /*string*/ static UseManagedSha1Message = null;
            //--TRIMMABLE-BOUNDARY-END(481036402695)
            
            //--TRIMMABLE-BOUNDARY-START(476741435399)
            /*string*/ static UseManagedSha1DiagId = null;
            //--TRIMMABLE-BOUNDARY-END(476741435399)
            
            //--TRIMMABLE-BOUNDARY-START(128849084423)
            /*string*/ static CryptoConfigEncodeOIDMessage = null;
            //--TRIMMABLE-BOUNDARY-END(128849084423)
            
            //--TRIMMABLE-BOUNDARY-START(124554117127)
            /*string*/ static CryptoConfigEncodeOIDDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(124554117127)
            
            //--TRIMMABLE-BOUNDARY-START(111669215239)
            /*string*/ static CorruptedStateRecoveryMessage = null;
            //--TRIMMABLE-BOUNDARY-END(111669215239)
            
            //--TRIMMABLE-BOUNDARY-START(107374247943)
            /*string*/ static CorruptedStateRecoveryDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(107374247943)
            
            //--TRIMMABLE-BOUNDARY-START(335007514631)
            /*string*/ static Rfc2898CryptDeriveKeyMessage = null;
            //--TRIMMABLE-BOUNDARY-END(335007514631)
            
            //--TRIMMABLE-BOUNDARY-START(330712547335)
            /*string*/ static Rfc2898CryptDeriveKeyDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(330712547335)
            
            //--TRIMMABLE-BOUNDARY-START(68719542279)
            /*string*/ static CmsSignerCspParamsCtorMessage = null;
            //--TRIMMABLE-BOUNDARY-END(68719542279)
            
            //--TRIMMABLE-BOUNDARY-START(64424574983)
            /*string*/ static CmsSignerCspParamsCtorDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(64424574983)
            
            //--TRIMMABLE-BOUNDARY-START(390842089479)
            /*string*/ static SignerInfoCounterSigMessage = null;
            //--TRIMMABLE-BOUNDARY-END(390842089479)
            
            //--TRIMMABLE-BOUNDARY-START(386547122183)
            /*string*/ static SignerInfoCounterSigDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(386547122183)
            
            //--TRIMMABLE-BOUNDARY-START(309237710855)
            /*string*/ static RegexCompileToAssemblyMessage = null;
            //--TRIMMABLE-BOUNDARY-END(309237710855)
            
            //--TRIMMABLE-BOUNDARY-START(304942743559)
            /*string*/ static RegexCompileToAssemblyDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(304942743559)
            
            //--TRIMMABLE-BOUNDARY-START(42949738503)
            /*string*/ static AssemblyNameMembersMessage = null;
            //--TRIMMABLE-BOUNDARY-END(42949738503)
            
            //--TRIMMABLE-BOUNDARY-START(38654771207)
            /*string*/ static AssemblyNameMembersDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(38654771207)
            
            //--TRIMMABLE-BOUNDARY-START(416611893255)
            /*string*/ static SystemDataSerializationFormatBinaryMessage = null;
            //--TRIMMABLE-BOUNDARY-END(416611893255)
            
            //--TRIMMABLE-BOUNDARY-START(412316925959)
            /*string*/ static SystemDataSerializationFormatBinaryDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(412316925959)
            
            //--TRIMMABLE-BOUNDARY-START(472446468103)
            /*string*/ static TlsVersion10and11Message = null;
            //--TRIMMABLE-BOUNDARY-END(472446468103)
            
            //--TRIMMABLE-BOUNDARY-START(468151500807)
            /*string*/ static TlsVersion10and11DiagId = null;
            //--TRIMMABLE-BOUNDARY-END(468151500807)
            
            //--TRIMMABLE-BOUNDARY-START(188978626567)
            /*string*/ static EncryptionPolicyMessage = null;
            //--TRIMMABLE-BOUNDARY-END(188978626567)
            
            //--TRIMMABLE-BOUNDARY-START(184683659271)
            /*string*/ static EncryptionPolicyDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(184683659271)
            
            //--TRIMMABLE-BOUNDARY-START(171798757383)
            /*string*/ static EccXmlExportImportMessage = null;
            //--TRIMMABLE-BOUNDARY-END(171798757383)
            
            //--TRIMMABLE-BOUNDARY-START(167503790087)
            /*string*/ static EccXmlExportImportDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(167503790087)
            
            //--TRIMMABLE-BOUNDARY-START(180388691975)
            /*string*/ static EcDhPublicKeyBlobMessage = null;
            //--TRIMMABLE-BOUNDARY-END(180388691975)
            
            //--TRIMMABLE-BOUNDARY-START(176093724679)
            /*string*/ static EcDhPublicKeyBlobDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(176093724679)
            
            //--TRIMMABLE-BOUNDARY-START(34359803911)
            /*string*/ static AssemblyNameCodeBaseMessage = null;
            //--TRIMMABLE-BOUNDARY-END(34359803911)
            
            //--TRIMMABLE-BOUNDARY-START(30064836615)
            /*string*/ static AssemblyNameCodeBaseDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(30064836615)
            
            //--TRIMMABLE-BOUNDARY-START(137439019015)
            /*string*/ static CryptoStringFactoryMessage = null;
            //--TRIMMABLE-BOUNDARY-END(137439019015)
            
            //--TRIMMABLE-BOUNDARY-START(133144051719)
            /*string*/ static CryptoStringFactoryDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(133144051719)
            
            //--TRIMMABLE-BOUNDARY-START(103079280647)
            /*string*/ static ControlledExecutionRunMessage = null;
            //--TRIMMABLE-BOUNDARY-END(103079280647)
            
            //--TRIMMABLE-BOUNDARY-START(98784313351)
            /*string*/ static ControlledExecutionRunDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(98784313351)
            
            //--TRIMMABLE-BOUNDARY-START(523986075655)
            /*string*/ static XmlSecureResolverMessage = null;
            //--TRIMMABLE-BOUNDARY-END(523986075655)
            
            //--TRIMMABLE-BOUNDARY-START(519691108359)
            /*string*/ static XmlSecureResolverDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(519691108359)
            
            //--TRIMMABLE-BOUNDARY-START(369367252999)
            /*string*/ static RsaEncryptDecryptValueMessage = null;
            //--TRIMMABLE-BOUNDARY-END(369367252999)
            
            //--TRIMMABLE-BOUNDARY-START(365072285703)
            /*string*/ static RsaEncryptDecryptDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(365072285703)
            
            //--TRIMMABLE-BOUNDARY-START(223338364935)
            /*string*/ static JsonSerializerOptionsAddContextMessage = null;
            //--TRIMMABLE-BOUNDARY-END(223338364935)
            
            //--TRIMMABLE-BOUNDARY-START(219043397639)
            /*string*/ static JsonSerializerOptionsAddContextDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(219043397639)
            
            //--TRIMMABLE-BOUNDARY-START(249108168711)
            /*string*/ static LegacyFormatterMessage = null;
            //--TRIMMABLE-BOUNDARY-END(249108168711)
            
            //--TRIMMABLE-BOUNDARY-START(236223266823)
            /*string*/ static LegacyFormatterDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(236223266823)
            
            //--TRIMMABLE-BOUNDARY-START(244813201415)
            /*string*/ static LegacyFormatterImplMessage = null;
            //--TRIMMABLE-BOUNDARY-END(244813201415)
            
            //--TRIMMABLE-BOUNDARY-START(240518234119)
            /*string*/ static LegacyFormatterImplDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(240518234119)
            
            //--TRIMMABLE-BOUNDARY-START(317827645447)
            /*string*/ static RegexExtensibilityImplMessage = null;
            //--TRIMMABLE-BOUNDARY-END(317827645447)
            
            //--TRIMMABLE-BOUNDARY-START(313532678151)
            /*string*/ static RegexExtensibilityDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(313532678151)
            
            //--TRIMMABLE-BOUNDARY-START(8590000135)
            /*string*/ static AesGcmTagConstructorMessage = null;
            //--TRIMMABLE-BOUNDARY-END(8590000135)
            
            //--TRIMMABLE-BOUNDARY-START(4295032839)
            /*string*/ static AesGcmTagConstructorDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(4295032839)
            
            //--TRIMMABLE-BOUNDARY-START(455266598919)
            /*string*/ static ThreadVolatileReadWriteMessage = null;
            //--TRIMMABLE-BOUNDARY-END(455266598919)
            
            //--TRIMMABLE-BOUNDARY-START(450971631623)
            /*string*/ static ThreadVolatileReadWriteDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(450971631623)
            
            //--TRIMMABLE-BOUNDARY-START(25769869319)
            /*string*/ static ArmIntrinsicPerformsUnsignedOperationMessage = null;
            //--TRIMMABLE-BOUNDARY-END(25769869319)
            
            //--TRIMMABLE-BOUNDARY-START(21474902023)
            /*string*/ static ArmIntrinsicPerformsUnsignedOperationDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(21474902023)
            
            //--TRIMMABLE-BOUNDARY-START(257698103303)
            /*string*/ static LoadFromHashAlgorithmMessage = null;
            //--TRIMMABLE-BOUNDARY-END(257698103303)
            
            //--TRIMMABLE-BOUNDARY-START(253403136007)
            /*string*/ static LoadFromHashAlgorithmDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(253403136007)
            
            //--TRIMMABLE-BOUNDARY-START(515396141063)
            /*string*/ static X509CtorCertDataObsoleteMessage = null;
            //--TRIMMABLE-BOUNDARY-END(515396141063)
            
            //--TRIMMABLE-BOUNDARY-START(511101173767)
            /*string*/ static X509CtorCertDataObsoleteDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(511101173767)
            
            //--TRIMMABLE-BOUNDARY-START(463856533511)
            /*string*/ static TlsCipherAlgorithmEnumsMessage = null;
            //--TRIMMABLE-BOUNDARY-END(463856533511)
            
            //--TRIMMABLE-BOUNDARY-START(459561566215)
            /*string*/ static TlsCipherAlgorithmEnumsDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(459561566215)
            
            //--TRIMMABLE-BOUNDARY-START(425201827847)
            /*string*/ static SystemEventsEventsThreadShutdownMessage = null;
            //--TRIMMABLE-BOUNDARY-END(425201827847)
            
            //--TRIMMABLE-BOUNDARY-START(420906860551)
            /*string*/ static SystemEventsEventsThreadShutdownDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(420906860551)
            
            //--TRIMMABLE-BOUNDARY-START(343597449223)
            /*string*/ static Rfc2898DeriveBytesCtorMessage = null;
            //--TRIMMABLE-BOUNDARY-END(343597449223)
            
            //--TRIMMABLE-BOUNDARY-START(339302481927)
            /*string*/ static Rfc2898DeriveBytesCtorDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(339302481927)
            
            //--TRIMMABLE-BOUNDARY-START(292057841671)
            /*string*/ static QueryableMinByMaxByTSourceObsoleteMessage = null;
            //--TRIMMABLE-BOUNDARY-END(292057841671)
            
            //--TRIMMABLE-BOUNDARY-START(287762874375)
            /*string*/ static QueryableMinByMaxByTSourceObsoleteDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(287762874375)
            
            //--TRIMMABLE-BOUNDARY-START(532576010247)
            /*string*/ static XsltSettingsEnableScriptMessage = null;
            //--TRIMMABLE-BOUNDARY-END(532576010247)
            
            //--TRIMMABLE-BOUNDARY-START(528281042951)
            /*string*/ static XsltSettingsEnableScriptDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(528281042951)
            
            //Static Initializer
            static $sinit()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(382252154887)
                    this.SharedUrlFormat = "https://aka.ms/dotnet-warnings/{0}";
                    //--TRIMMABLE-BOUNDARY-END(382252154887)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(433791762439)
                    this.SystemTextEncodingUTF7Message = "The UTF-7 encoding is insecure and should not be used. Consider using UTF-8 instead.";
                    //--TRIMMABLE-BOUNDARY-END(433791762439)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(429496795143)
                    this.SystemTextEncodingUTF7DiagId = "SYSLIB0001";
                    //--TRIMMABLE-BOUNDARY-END(429496795143)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(266288037895)
                    this.PrincipalPermissionAttributeMessage = "PrincipalPermissionAttribute is not honored by the runtime and must not be used.";
                    //--TRIMMABLE-BOUNDARY-END(266288037895)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(261993070599)
                    this.PrincipalPermissionAttributeDiagId = "SYSLIB0002";
                    //--TRIMMABLE-BOUNDARY-END(261993070599)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(77309476871)
                    this.CodeAccessSecurityMessage = "Code Access Security is not supported or honored by the runtime.";
                    //--TRIMMABLE-BOUNDARY-END(77309476871)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(73014509575)
                    this.CodeAccessSecurityDiagId = "SYSLIB0003";
                    //--TRIMMABLE-BOUNDARY-END(73014509575)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(94489346055)
                    this.ConstrainedExecutionRegionMessage = "The Constrained Execution Region (CER) feature is not supported.";
                    //--TRIMMABLE-BOUNDARY-END(94489346055)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(90194378759)
                    this.ConstrainedExecutionRegionDiagId = "SYSLIB0004";
                    //--TRIMMABLE-BOUNDARY-END(90194378759)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(214748430343)
                    this.GlobalAssemblyCacheMessage = "The Global Assembly Cache is not supported.";
                    //--TRIMMABLE-BOUNDARY-END(214748430343)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(210453463047)
                    this.GlobalAssemblyCacheDiagId = "SYSLIB0005";
                    //--TRIMMABLE-BOUNDARY-END(210453463047)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(442381697031)
                    this.ThreadAbortMessage = "Thread.Abort is not supported and throws PlatformNotSupportedException.";
                    //--TRIMMABLE-BOUNDARY-END(442381697031)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(446676664327)
                    this.ThreadResetAbortMessage = "Thread.ResetAbort is not supported and throws PlatformNotSupportedException.";
                    //--TRIMMABLE-BOUNDARY-END(446676664327)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(438086729735)
                    this.ThreadAbortDiagId = "SYSLIB0006";
                    //--TRIMMABLE-BOUNDARY-END(438086729735)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(146028953607)
                    this.DefaultCryptoAlgorithmsMessage = "The default implementation of this cryptography algorithm is not supported.";
                    //--TRIMMABLE-BOUNDARY-END(146028953607)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(141733986311)
                    this.DefaultCryptoAlgorithmsDiagId = "SYSLIB0007";
                    //--TRIMMABLE-BOUNDARY-END(141733986311)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(120259149831)
                    this.CreatePdbGeneratorMessage = "The CreatePdbGenerator API is not supported and throws PlatformNotSupportedException.";
                    //--TRIMMABLE-BOUNDARY-END(120259149831)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(115964182535)
                    this.CreatePdbGeneratorDiagId = "SYSLIB0008";
                    //--TRIMMABLE-BOUNDARY-END(115964182535)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(51539673095)
                    this.AuthenticationManagerMessage = "AuthenticationManager is not supported. Methods will no-op or throw PlatformNotSupportedException.";
                    //--TRIMMABLE-BOUNDARY-END(51539673095)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(47244705799)
                    this.AuthenticationManagerDiagId = "SYSLIB0009";
                    //--TRIMMABLE-BOUNDARY-END(47244705799)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(326417580039)
                    this.RemotingApisMessage = "This Remoting API is not supported and throws PlatformNotSupportedException.";
                    //--TRIMMABLE-BOUNDARY-END(326417580039)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(322122612743)
                    this.RemotingApisDiagId = "SYSLIB0010";
                    //--TRIMMABLE-BOUNDARY-END(322122612743)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(60129607687)
                    this.BinaryFormatterMessage = "BinaryFormatter serialization is obsolete and should not be used. See https://aka.ms/binaryformatter for more information.";
                    //--TRIMMABLE-BOUNDARY-END(60129607687)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(55834640391)
                    this.BinaryFormatterDiagId = "SYSLIB0011";
                    //--TRIMMABLE-BOUNDARY-END(55834640391)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(85899411463)
                    this.CodeBaseMessage = "Assembly.CodeBase and Assembly.EscapedCodeBase are only included for .NET Framework compatibility. Use Assembly.Location instead.";
                    //--TRIMMABLE-BOUNDARY-END(85899411463)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(81604444167)
                    this.CodeBaseDiagId = "SYSLIB0012";
                    //--TRIMMABLE-BOUNDARY-END(81604444167)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(197568561159)
                    this.EscapeUriStringMessage = "Uri.EscapeUriString can corrupt the Uri string in some cases. Consider using Uri.EscapeDataString for query string components instead.";
                    //--TRIMMABLE-BOUNDARY-END(197568561159)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(193273593863)
                    this.EscapeUriStringDiagId = "SYSLIB0013";
                    //--TRIMMABLE-BOUNDARY-END(193273593863)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(489626337287)
                    this.WebRequestMessage = "WebRequest, HttpWebRequest, ServicePoint, and WebClient are obsolete. Use HttpClient instead.";
                    //--TRIMMABLE-BOUNDARY-END(489626337287)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(485331369991)
                    this.WebRequestDiagId = "SYSLIB0014";
                    //--TRIMMABLE-BOUNDARY-END(485331369991)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(163208822791)
                    this.DisablePrivateReflectionAttributeMessage = "DisablePrivateReflectionAttribute has no effect in .NET 6.0+.";
                    //--TRIMMABLE-BOUNDARY-END(163208822791)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(158913855495)
                    this.DisablePrivateReflectionAttributeDiagId = "SYSLIB0015";
                    //--TRIMMABLE-BOUNDARY-END(158913855495)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(206158495751)
                    this.GetContextInfoMessage = "Use the Graphics.GetContextInfo overloads that accept arguments for better performance and fewer allocations.";
                    //--TRIMMABLE-BOUNDARY-END(206158495751)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(201863528455)
                    this.GetContextInfoDiagId = "SYSLIB0016";
                    //--TRIMMABLE-BOUNDARY-END(201863528455)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(399432024071)
                    this.StrongNameKeyPairMessage = "Strong name signing is not supported and throws PlatformNotSupportedException.";
                    //--TRIMMABLE-BOUNDARY-END(399432024071)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(395137056775)
                    this.StrongNameKeyPairDiagId = "SYSLIB0017";
                    //--TRIMMABLE-BOUNDARY-END(395137056775)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(300647776263)
                    this.ReflectionOnlyLoadingMessage = "ReflectionOnly loading is not supported and throws PlatformNotSupportedException.";
                    //--TRIMMABLE-BOUNDARY-END(300647776263)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(296352808967)
                    this.ReflectionOnlyLoadingDiagId = "SYSLIB0018";
                    //--TRIMMABLE-BOUNDARY-END(296352808967)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(377957187591)
                    this.RuntimeEnvironmentMessage = "RuntimeEnvironment members SystemConfigurationFile, GetRuntimeInterfaceAsIntPtr, and GetRuntimeInterfaceAsObject are not supported and throw PlatformNotSupportedException.";
                    //--TRIMMABLE-BOUNDARY-END(377957187591)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(373662220295)
                    this.RuntimeEnvironmentDiagId = "SYSLIB0019";
                    //--TRIMMABLE-BOUNDARY-END(373662220295)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(231928299527)
                    this.JsonSerializerOptionsIgnoreNullValuesMessage = "JsonSerializerOptions.IgnoreNullValues is obsolete. To ignore null values when serializing, set DefaultIgnoreCondition to JsonIgnoreCondition.WhenWritingNull.";
                    //--TRIMMABLE-BOUNDARY-END(231928299527)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(227633332231)
                    this.JsonSerializerOptionsIgnoreNullValuesDiagId = "SYSLIB0020";
                    //--TRIMMABLE-BOUNDARY-END(227633332231)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(154618888199)
                    this.DerivedCryptographicTypesMessage = "Derived cryptographic types are obsolete. Use the Create method on the base type instead.";
                    //--TRIMMABLE-BOUNDARY-END(154618888199)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(150323920903)
                    this.DerivedCryptographicTypesDiagId = "SYSLIB0021";
                    //--TRIMMABLE-BOUNDARY-END(150323920903)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(352187383815)
                    this.RijndaelMessage = "The Rijndael and RijndaelManaged types are obsolete. Use Aes instead.";
                    //--TRIMMABLE-BOUNDARY-END(352187383815)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(347892416519)
                    this.RijndaelDiagId = "SYSLIB0022";
                    //--TRIMMABLE-BOUNDARY-END(347892416519)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(360777318407)
                    this.RNGCryptoServiceProviderMessage = "RNGCryptoServiceProvider is obsolete. To generate a random number, use one of the RandomNumberGenerator static methods instead.";
                    //--TRIMMABLE-BOUNDARY-END(360777318407)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(356482351111)
                    this.RNGCryptoServiceProviderDiagId = "SYSLIB0023";
                    //--TRIMMABLE-BOUNDARY-END(356482351111)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(17179934727)
                    this.AppDomainCreateUnloadMessage = "Creating and unloading AppDomains is not supported and throws an exception.";
                    //--TRIMMABLE-BOUNDARY-END(17179934727)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(12884967431)
                    this.AppDomainCreateUnloadDiagId = "SYSLIB0024";
                    //--TRIMMABLE-BOUNDARY-END(12884967431)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(408021958663)
                    this.SuppressIldasmAttributeMessage = "SuppressIldasmAttribute has no effect in .NET 6.0+.";
                    //--TRIMMABLE-BOUNDARY-END(408021958663)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(403726991367)
                    this.SuppressIldasmAttributeDiagId = "SYSLIB0025";
                    //--TRIMMABLE-BOUNDARY-END(403726991367)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(498216271879)
                    this.X509CertificateImmutableMessage = "X509Certificate and X509Certificate2 are immutable. Use X509CertificateLoader to create a new certificate.";
                    //--TRIMMABLE-BOUNDARY-END(498216271879)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(493921304583)
                    this.X509CertificateImmutableDiagId = "SYSLIB0026";
                    //--TRIMMABLE-BOUNDARY-END(493921304583)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(283467907079)
                    this.PublicKeyPropertyMessage = "PublicKey.Key is obsolete. Use the appropriate method to get the public key, such as GetRSAPublicKey.";
                    //--TRIMMABLE-BOUNDARY-END(283467907079)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(279172939783)
                    this.PublicKeyPropertyDiagId = "SYSLIB0027";
                    //--TRIMMABLE-BOUNDARY-END(279172939783)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(506806206471)
                    this.X509CertificatePrivateKeyMessage = "X509Certificate2.PrivateKey is obsolete. Use the appropriate method to get the private key, such as GetRSAPrivateKey, or use the CopyWithPrivateKey method to create a new instance with a private key.";
                    //--TRIMMABLE-BOUNDARY-END(506806206471)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(502511239175)
                    this.X509CertificatePrivateKeyDiagId = "SYSLIB0028";
                    //--TRIMMABLE-BOUNDARY-END(502511239175)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(274877972487)
                    this.ProduceLegacyHmacValuesMessage = "ProduceLegacyHmacValues is obsolete. Producing legacy HMAC values is not supported.";
                    //--TRIMMABLE-BOUNDARY-END(274877972487)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(270583005191)
                    this.ProduceLegacyHmacValuesDiagId = "SYSLIB0029";
                    //--TRIMMABLE-BOUNDARY-END(270583005191)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(481036402695)
                    this.UseManagedSha1Message = "HMACSHA1 always uses the algorithm implementation provided by the platform. Use a constructor without the useManagedSha1 parameter.";
                    //--TRIMMABLE-BOUNDARY-END(481036402695)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(476741435399)
                    this.UseManagedSha1DiagId = "SYSLIB0030";
                    //--TRIMMABLE-BOUNDARY-END(476741435399)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(128849084423)
                    this.CryptoConfigEncodeOIDMessage = "EncodeOID is obsolete. Use the ASN.1 functionality provided in System.Formats.Asn1.";
                    //--TRIMMABLE-BOUNDARY-END(128849084423)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(124554117127)
                    this.CryptoConfigEncodeOIDDiagId = "SYSLIB0031";
                    //--TRIMMABLE-BOUNDARY-END(124554117127)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(111669215239)
                    this.CorruptedStateRecoveryMessage = "Recovery from corrupted process state exceptions is not supported; HandleProcessCorruptedStateExceptionsAttribute is ignored.";
                    //--TRIMMABLE-BOUNDARY-END(111669215239)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(107374247943)
                    this.CorruptedStateRecoveryDiagId = "SYSLIB0032";
                    //--TRIMMABLE-BOUNDARY-END(107374247943)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(335007514631)
                    this.Rfc2898CryptDeriveKeyMessage = "Rfc2898DeriveBytes.CryptDeriveKey is obsolete and is not supported. Use PasswordDeriveBytes.CryptDeriveKey instead.";
                    //--TRIMMABLE-BOUNDARY-END(335007514631)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(330712547335)
                    this.Rfc2898CryptDeriveKeyDiagId = "SYSLIB0033";
                    //--TRIMMABLE-BOUNDARY-END(330712547335)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(68719542279)
                    this.CmsSignerCspParamsCtorMessage = "CmsSigner(CspParameters) is obsolete and is not supported. Use an alternative constructor instead.";
                    //--TRIMMABLE-BOUNDARY-END(68719542279)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(64424574983)
                    this.CmsSignerCspParamsCtorDiagId = "SYSLIB0034";
                    //--TRIMMABLE-BOUNDARY-END(64424574983)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(390842089479)
                    this.SignerInfoCounterSigMessage = "ComputeCounterSignature without specifying a CmsSigner is obsolete and is not supported. Use the overload that accepts a CmsSigner.";
                    //--TRIMMABLE-BOUNDARY-END(390842089479)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(386547122183)
                    this.SignerInfoCounterSigDiagId = "SYSLIB0035";
                    //--TRIMMABLE-BOUNDARY-END(386547122183)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(309237710855)
                    this.RegexCompileToAssemblyMessage = "Regex.CompileToAssembly is obsolete and not supported. Use the GeneratedRegexAttribute with the regular expression source generator instead.";
                    //--TRIMMABLE-BOUNDARY-END(309237710855)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(304942743559)
                    this.RegexCompileToAssemblyDiagId = "SYSLIB0036";
                    //--TRIMMABLE-BOUNDARY-END(304942743559)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(42949738503)
                    this.AssemblyNameMembersMessage = "AssemblyName members HashAlgorithm, ProcessorArchitecture, and VersionCompatibility are obsolete and not supported.";
                    //--TRIMMABLE-BOUNDARY-END(42949738503)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(38654771207)
                    this.AssemblyNameMembersDiagId = "SYSLIB0037";
                    //--TRIMMABLE-BOUNDARY-END(38654771207)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(416611893255)
                    this.SystemDataSerializationFormatBinaryMessage = "SerializationFormat.Binary is obsolete and should not be used. See https://aka.ms/serializationformat-binary-obsolete for more information.";
                    //--TRIMMABLE-BOUNDARY-END(416611893255)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(412316925959)
                    this.SystemDataSerializationFormatBinaryDiagId = "SYSLIB0038";
                    //--TRIMMABLE-BOUNDARY-END(412316925959)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(472446468103)
                    this.TlsVersion10and11Message = "TLS versions 1.0 and 1.1 have known vulnerabilities and are not recommended. Use a newer TLS version instead, or use SslProtocols.None to defer to OS defaults.";
                    //--TRIMMABLE-BOUNDARY-END(472446468103)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(468151500807)
                    this.TlsVersion10and11DiagId = "SYSLIB0039";
                    //--TRIMMABLE-BOUNDARY-END(468151500807)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(188978626567)
                    this.EncryptionPolicyMessage = "EncryptionPolicy.NoEncryption and AllowEncryption significantly reduce security and should not be used in production code.";
                    //--TRIMMABLE-BOUNDARY-END(188978626567)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(184683659271)
                    this.EncryptionPolicyDiagId = "SYSLIB0040";
                    //--TRIMMABLE-BOUNDARY-END(184683659271)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(171798757383)
                    this.EccXmlExportImportMessage = "ToXmlString and FromXmlString have no implementation for ECC types, and are obsolete. Use a standard import and export format such as ExportSubjectPublicKeyInfo or ImportSubjectPublicKeyInfo for public keys and ExportPkcs8PrivateKey or ImportPkcs8PrivateKey for private keys.";
                    //--TRIMMABLE-BOUNDARY-END(171798757383)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(167503790087)
                    this.EccXmlExportImportDiagId = "SYSLIB0042";
                    //--TRIMMABLE-BOUNDARY-END(167503790087)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(180388691975)
                    this.EcDhPublicKeyBlobMessage = "ECDiffieHellmanPublicKey.ToByteArray() and the associated constructor do not have a consistent and interoperable implementation on all platforms. Use ECDiffieHellmanPublicKey.ExportSubjectPublicKeyInfo() instead.";
                    //--TRIMMABLE-BOUNDARY-END(180388691975)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(176093724679)
                    this.EcDhPublicKeyBlobDiagId = "SYSLIB0043";
                    //--TRIMMABLE-BOUNDARY-END(176093724679)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(34359803911)
                    this.AssemblyNameCodeBaseMessage = "AssemblyName.CodeBase and AssemblyName.EscapedCodeBase are obsolete. Using them for loading an assembly is not supported.";
                    //--TRIMMABLE-BOUNDARY-END(34359803911)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(30064836615)
                    this.AssemblyNameCodeBaseDiagId = "SYSLIB0044";
                    //--TRIMMABLE-BOUNDARY-END(30064836615)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(137439019015)
                    this.CryptoStringFactoryMessage = "Cryptographic factory methods accepting an algorithm name are obsolete. Use the parameterless Create factory method on the algorithm type instead.";
                    //--TRIMMABLE-BOUNDARY-END(137439019015)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(133144051719)
                    this.CryptoStringFactoryDiagId = "SYSLIB0045";
                    //--TRIMMABLE-BOUNDARY-END(133144051719)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(103079280647)
                    this.ControlledExecutionRunMessage = "ControlledExecution.Run method may corrupt the process and should not be used in production code.";
                    //--TRIMMABLE-BOUNDARY-END(103079280647)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(98784313351)
                    this.ControlledExecutionRunDiagId = "SYSLIB0046";
                    //--TRIMMABLE-BOUNDARY-END(98784313351)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(523986075655)
                    this.XmlSecureResolverMessage = "XmlSecureResolver is obsolete. Use XmlResolver.ThrowingResolver instead when attempting to forbid XML external entity resolution.";
                    //--TRIMMABLE-BOUNDARY-END(523986075655)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(519691108359)
                    this.XmlSecureResolverDiagId = "SYSLIB0047";
                    //--TRIMMABLE-BOUNDARY-END(519691108359)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(369367252999)
                    this.RsaEncryptDecryptValueMessage = "RSA.EncryptValue and DecryptValue are not supported and throw NotSupportedException. Use RSA.Encrypt and RSA.Decrypt instead.";
                    //--TRIMMABLE-BOUNDARY-END(369367252999)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(365072285703)
                    this.RsaEncryptDecryptDiagId = "SYSLIB0048";
                    //--TRIMMABLE-BOUNDARY-END(365072285703)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(223338364935)
                    this.JsonSerializerOptionsAddContextMessage = "JsonSerializerOptions.AddContext is obsolete. To register a JsonSerializerContext, use either the TypeInfoResolver or TypeInfoResolverChain properties.";
                    //--TRIMMABLE-BOUNDARY-END(223338364935)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(219043397639)
                    this.JsonSerializerOptionsAddContextDiagId = "SYSLIB0049";
                    //--TRIMMABLE-BOUNDARY-END(219043397639)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(249108168711)
                    this.LegacyFormatterMessage = "Formatter-based serialization is obsolete and should not be used.";
                    //--TRIMMABLE-BOUNDARY-END(249108168711)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(236223266823)
                    this.LegacyFormatterDiagId = "SYSLIB0050";
                    //--TRIMMABLE-BOUNDARY-END(236223266823)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(244813201415)
                    this.LegacyFormatterImplMessage = "This API supports obsolete formatter-based serialization. It should not be called or extended by application code.";
                    //--TRIMMABLE-BOUNDARY-END(244813201415)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(240518234119)
                    this.LegacyFormatterImplDiagId = "SYSLIB0051";
                    //--TRIMMABLE-BOUNDARY-END(240518234119)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(317827645447)
                    this.RegexExtensibilityImplMessage = "This API supports obsolete mechanisms for Regex extensibility. It is not supported.";
                    //--TRIMMABLE-BOUNDARY-END(317827645447)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(313532678151)
                    this.RegexExtensibilityDiagId = "SYSLIB0052";
                    //--TRIMMABLE-BOUNDARY-END(313532678151)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(8590000135)
                    this.AesGcmTagConstructorMessage = "AesGcm should indicate the required tag size for encryption and decryption. Use a constructor that accepts the tag size.";
                    //--TRIMMABLE-BOUNDARY-END(8590000135)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(4295032839)
                    this.AesGcmTagConstructorDiagId = "SYSLIB0053";
                    //--TRIMMABLE-BOUNDARY-END(4295032839)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(455266598919)
                    this.ThreadVolatileReadWriteMessage = "Thread.VolatileRead and Thread.VolatileWrite are obsolete. Use Volatile.Read or Volatile.Write respectively instead.";
                    //--TRIMMABLE-BOUNDARY-END(455266598919)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(450971631623)
                    this.ThreadVolatileReadWriteDiagId = "SYSLIB0054";
                    //--TRIMMABLE-BOUNDARY-END(450971631623)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(25769869319)
                    this.ArmIntrinsicPerformsUnsignedOperationMessage = "The underlying hardware instruction does not perform a signed saturate narrowing operation, and it always returns an unsigned result. Use the unsigned overload instead.";
                    //--TRIMMABLE-BOUNDARY-END(25769869319)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(21474902023)
                    this.ArmIntrinsicPerformsUnsignedOperationDiagId = "SYSLIB0055";
                    //--TRIMMABLE-BOUNDARY-END(21474902023)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(257698103303)
                    this.LoadFromHashAlgorithmMessage = "LoadFrom with a custom AssemblyHashAlgorithm is obsolete. Use overloads without an AssemblyHashAlgorithm.";
                    //--TRIMMABLE-BOUNDARY-END(257698103303)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(253403136007)
                    this.LoadFromHashAlgorithmDiagId = "SYSLIB0056";
                    //--TRIMMABLE-BOUNDARY-END(253403136007)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(515396141063)
                    this.X509CtorCertDataObsoleteMessage = "Loading certificate data through the constructor or Import is obsolete. Use X509CertificateLoader instead to load certificates.";
                    //--TRIMMABLE-BOUNDARY-END(515396141063)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(511101173767)
                    this.X509CtorCertDataObsoleteDiagId = "SYSLIB0057";
                    //--TRIMMABLE-BOUNDARY-END(511101173767)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(463856533511)
                    this.TlsCipherAlgorithmEnumsMessage = "KeyExchangeAlgorithm, KeyExchangeStrength, CipherAlgorithm, CipherStrength, HashAlgorithm and HashStrength properties of SslStream are obsolete. Use NegotiatedCipherSuite instead.";
                    //--TRIMMABLE-BOUNDARY-END(463856533511)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(459561566215)
                    this.TlsCipherAlgorithmEnumsDiagId = "SYSLIB0058";
                    //--TRIMMABLE-BOUNDARY-END(459561566215)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(425201827847)
                    this.SystemEventsEventsThreadShutdownMessage = "SystemEvents.EventsThreadShutdown callbacks are not run before the process exits. Use AppDomain.ProcessExit instead.";
                    //--TRIMMABLE-BOUNDARY-END(425201827847)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(420906860551)
                    this.SystemEventsEventsThreadShutdownDiagId = "SYSLIB0059";
                    //--TRIMMABLE-BOUNDARY-END(420906860551)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(343597449223)
                    this.Rfc2898DeriveBytesCtorMessage = "The constructors on Rfc2898DeriveBytes are obsolete. Use the static Pbkdf2 method instead.";
                    //--TRIMMABLE-BOUNDARY-END(343597449223)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(339302481927)
                    this.Rfc2898DeriveBytesCtorDiagId = "SYSLIB0060";
                    //--TRIMMABLE-BOUNDARY-END(339302481927)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(292057841671)
                    this.QueryableMinByMaxByTSourceObsoleteMessage = "The Queryable MinBy and MaxBy taking an IComparer<TSource> are obsolete. Use the new ones that take an IComparer<TKey>.";
                    //--TRIMMABLE-BOUNDARY-END(292057841671)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(287762874375)
                    this.QueryableMinByMaxByTSourceObsoleteDiagId = "SYSLIB0061";
                    //--TRIMMABLE-BOUNDARY-END(287762874375)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(532576010247)
                    this.XsltSettingsEnableScriptMessage = "XSLT Script blocks are not supported.";
                    //--TRIMMABLE-BOUNDARY-END(532576010247)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(528281042951)
                    this.XsltSettingsEnableScriptDiagId = "SYSLIB0062";
                    //--TRIMMABLE-BOUNDARY-END(528281042951)
                    
                }
            }
            static $h = 65543;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 131073,
  "l": [
//--TRIMMABLE-BOUNDARY-START(382252154887),
    {
      "t": 1310721,
      "n": "SharedUrlFormat",
      "d": 65543,
      "h": 382252154887,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(382252154887),
//--TRIMMABLE-BOUNDARY-START(433791762439),
    {
      "t": 1310721,
      "n": "SystemTextEncodingUTF7Message",
      "d": 65543,
      "h": 433791762439,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(433791762439),
//--TRIMMABLE-BOUNDARY-START(429496795143),
    {
      "t": 1310721,
      "n": "SystemTextEncodingUTF7DiagId",
      "d": 65543,
      "h": 429496795143,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(429496795143),
//--TRIMMABLE-BOUNDARY-START(266288037895),
    {
      "t": 1310721,
      "n": "PrincipalPermissionAttributeMessage",
      "d": 65543,
      "h": 266288037895,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(266288037895),
//--TRIMMABLE-BOUNDARY-START(261993070599),
    {
      "t": 1310721,
      "n": "PrincipalPermissionAttributeDiagId",
      "d": 65543,
      "h": 261993070599,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(261993070599),
//--TRIMMABLE-BOUNDARY-START(77309476871),
    {
      "t": 1310721,
      "n": "CodeAccessSecurityMessage",
      "d": 65543,
      "h": 77309476871,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(77309476871),
//--TRIMMABLE-BOUNDARY-START(73014509575),
    {
      "t": 1310721,
      "n": "CodeAccessSecurityDiagId",
      "d": 65543,
      "h": 73014509575,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(73014509575),
//--TRIMMABLE-BOUNDARY-START(94489346055),
    {
      "t": 1310721,
      "n": "ConstrainedExecutionRegionMessage",
      "d": 65543,
      "h": 94489346055,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(94489346055),
//--TRIMMABLE-BOUNDARY-START(90194378759),
    {
      "t": 1310721,
      "n": "ConstrainedExecutionRegionDiagId",
      "d": 65543,
      "h": 90194378759,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(90194378759),
//--TRIMMABLE-BOUNDARY-START(214748430343),
    {
      "t": 1310721,
      "n": "GlobalAssemblyCacheMessage",
      "d": 65543,
      "h": 214748430343,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(214748430343),
//--TRIMMABLE-BOUNDARY-START(210453463047),
    {
      "t": 1310721,
      "n": "GlobalAssemblyCacheDiagId",
      "d": 65543,
      "h": 210453463047,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(210453463047),
//--TRIMMABLE-BOUNDARY-START(442381697031),
    {
      "t": 1310721,
      "n": "ThreadAbortMessage",
      "d": 65543,
      "h": 442381697031,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(442381697031),
//--TRIMMABLE-BOUNDARY-START(446676664327),
    {
      "t": 1310721,
      "n": "ThreadResetAbortMessage",
      "d": 65543,
      "h": 446676664327,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(446676664327),
//--TRIMMABLE-BOUNDARY-START(438086729735),
    {
      "t": 1310721,
      "n": "ThreadAbortDiagId",
      "d": 65543,
      "h": 438086729735,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(438086729735),
//--TRIMMABLE-BOUNDARY-START(146028953607),
    {
      "t": 1310721,
      "n": "DefaultCryptoAlgorithmsMessage",
      "d": 65543,
      "h": 146028953607,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(146028953607),
//--TRIMMABLE-BOUNDARY-START(141733986311),
    {
      "t": 1310721,
      "n": "DefaultCryptoAlgorithmsDiagId",
      "d": 65543,
      "h": 141733986311,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(141733986311),
//--TRIMMABLE-BOUNDARY-START(120259149831),
    {
      "t": 1310721,
      "n": "CreatePdbGeneratorMessage",
      "d": 65543,
      "h": 120259149831,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(120259149831),
//--TRIMMABLE-BOUNDARY-START(115964182535),
    {
      "t": 1310721,
      "n": "CreatePdbGeneratorDiagId",
      "d": 65543,
      "h": 115964182535,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(115964182535),
//--TRIMMABLE-BOUNDARY-START(51539673095),
    {
      "t": 1310721,
      "n": "AuthenticationManagerMessage",
      "d": 65543,
      "h": 51539673095,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(51539673095),
//--TRIMMABLE-BOUNDARY-START(47244705799),
    {
      "t": 1310721,
      "n": "AuthenticationManagerDiagId",
      "d": 65543,
      "h": 47244705799,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(47244705799),
//--TRIMMABLE-BOUNDARY-START(326417580039),
    {
      "t": 1310721,
      "n": "RemotingApisMessage",
      "d": 65543,
      "h": 326417580039,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(326417580039),
//--TRIMMABLE-BOUNDARY-START(322122612743),
    {
      "t": 1310721,
      "n": "RemotingApisDiagId",
      "d": 65543,
      "h": 322122612743,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(322122612743),
//--TRIMMABLE-BOUNDARY-START(60129607687),
    {
      "t": 1310721,
      "n": "BinaryFormatterMessage",
      "d": 65543,
      "h": 60129607687,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(60129607687),
//--TRIMMABLE-BOUNDARY-START(55834640391),
    {
      "t": 1310721,
      "n": "BinaryFormatterDiagId",
      "d": 65543,
      "h": 55834640391,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(55834640391),
//--TRIMMABLE-BOUNDARY-START(85899411463),
    {
      "t": 1310721,
      "n": "CodeBaseMessage",
      "d": 65543,
      "h": 85899411463,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(85899411463),
//--TRIMMABLE-BOUNDARY-START(81604444167),
    {
      "t": 1310721,
      "n": "CodeBaseDiagId",
      "d": 65543,
      "h": 81604444167,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(81604444167),
//--TRIMMABLE-BOUNDARY-START(197568561159),
    {
      "t": 1310721,
      "n": "EscapeUriStringMessage",
      "d": 65543,
      "h": 197568561159,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(197568561159),
//--TRIMMABLE-BOUNDARY-START(193273593863),
    {
      "t": 1310721,
      "n": "EscapeUriStringDiagId",
      "d": 65543,
      "h": 193273593863,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(193273593863),
//--TRIMMABLE-BOUNDARY-START(489626337287),
    {
      "t": 1310721,
      "n": "WebRequestMessage",
      "d": 65543,
      "h": 489626337287,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(489626337287),
//--TRIMMABLE-BOUNDARY-START(485331369991),
    {
      "t": 1310721,
      "n": "WebRequestDiagId",
      "d": 65543,
      "h": 485331369991,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(485331369991),
//--TRIMMABLE-BOUNDARY-START(163208822791),
    {
      "t": 1310721,
      "n": "DisablePrivateReflectionAttributeMessage",
      "d": 65543,
      "h": 163208822791,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(163208822791),
//--TRIMMABLE-BOUNDARY-START(158913855495),
    {
      "t": 1310721,
      "n": "DisablePrivateReflectionAttributeDiagId",
      "d": 65543,
      "h": 158913855495,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(158913855495),
//--TRIMMABLE-BOUNDARY-START(206158495751),
    {
      "t": 1310721,
      "n": "GetContextInfoMessage",
      "d": 65543,
      "h": 206158495751,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(206158495751),
//--TRIMMABLE-BOUNDARY-START(201863528455),
    {
      "t": 1310721,
      "n": "GetContextInfoDiagId",
      "d": 65543,
      "h": 201863528455,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(201863528455),
//--TRIMMABLE-BOUNDARY-START(399432024071),
    {
      "t": 1310721,
      "n": "StrongNameKeyPairMessage",
      "d": 65543,
      "h": 399432024071,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(399432024071),
//--TRIMMABLE-BOUNDARY-START(395137056775),
    {
      "t": 1310721,
      "n": "StrongNameKeyPairDiagId",
      "d": 65543,
      "h": 395137056775,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(395137056775),
//--TRIMMABLE-BOUNDARY-START(300647776263),
    {
      "t": 1310721,
      "n": "ReflectionOnlyLoadingMessage",
      "d": 65543,
      "h": 300647776263,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(300647776263),
//--TRIMMABLE-BOUNDARY-START(296352808967),
    {
      "t": 1310721,
      "n": "ReflectionOnlyLoadingDiagId",
      "d": 65543,
      "h": 296352808967,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(296352808967),
//--TRIMMABLE-BOUNDARY-START(377957187591),
    {
      "t": 1310721,
      "n": "RuntimeEnvironmentMessage",
      "d": 65543,
      "h": 377957187591,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(377957187591),
//--TRIMMABLE-BOUNDARY-START(373662220295),
    {
      "t": 1310721,
      "n": "RuntimeEnvironmentDiagId",
      "d": 65543,
      "h": 373662220295,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(373662220295),
//--TRIMMABLE-BOUNDARY-START(231928299527),
    {
      "t": 1310721,
      "n": "JsonSerializerOptionsIgnoreNullValuesMessage",
      "d": 65543,
      "h": 231928299527,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(231928299527),
//--TRIMMABLE-BOUNDARY-START(227633332231),
    {
      "t": 1310721,
      "n": "JsonSerializerOptionsIgnoreNullValuesDiagId",
      "d": 65543,
      "h": 227633332231,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(227633332231),
//--TRIMMABLE-BOUNDARY-START(154618888199),
    {
      "t": 1310721,
      "n": "DerivedCryptographicTypesMessage",
      "d": 65543,
      "h": 154618888199,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(154618888199),
//--TRIMMABLE-BOUNDARY-START(150323920903),
    {
      "t": 1310721,
      "n": "DerivedCryptographicTypesDiagId",
      "d": 65543,
      "h": 150323920903,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(150323920903),
//--TRIMMABLE-BOUNDARY-START(352187383815),
    {
      "t": 1310721,
      "n": "RijndaelMessage",
      "d": 65543,
      "h": 352187383815,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(352187383815),
//--TRIMMABLE-BOUNDARY-START(347892416519),
    {
      "t": 1310721,
      "n": "RijndaelDiagId",
      "d": 65543,
      "h": 347892416519,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(347892416519),
//--TRIMMABLE-BOUNDARY-START(360777318407),
    {
      "t": 1310721,
      "n": "RNGCryptoServiceProviderMessage",
      "d": 65543,
      "h": 360777318407,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(360777318407),
//--TRIMMABLE-BOUNDARY-START(356482351111),
    {
      "t": 1310721,
      "n": "RNGCryptoServiceProviderDiagId",
      "d": 65543,
      "h": 356482351111,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(356482351111),
//--TRIMMABLE-BOUNDARY-START(17179934727),
    {
      "t": 1310721,
      "n": "AppDomainCreateUnloadMessage",
      "d": 65543,
      "h": 17179934727,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(17179934727),
//--TRIMMABLE-BOUNDARY-START(12884967431),
    {
      "t": 1310721,
      "n": "AppDomainCreateUnloadDiagId",
      "d": 65543,
      "h": 12884967431,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(12884967431),
//--TRIMMABLE-BOUNDARY-START(408021958663),
    {
      "t": 1310721,
      "n": "SuppressIldasmAttributeMessage",
      "d": 65543,
      "h": 408021958663,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(408021958663),
//--TRIMMABLE-BOUNDARY-START(403726991367),
    {
      "t": 1310721,
      "n": "SuppressIldasmAttributeDiagId",
      "d": 65543,
      "h": 403726991367,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(403726991367),
//--TRIMMABLE-BOUNDARY-START(498216271879),
    {
      "t": 1310721,
      "n": "X509CertificateImmutableMessage",
      "d": 65543,
      "h": 498216271879,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(498216271879),
//--TRIMMABLE-BOUNDARY-START(493921304583),
    {
      "t": 1310721,
      "n": "X509CertificateImmutableDiagId",
      "d": 65543,
      "h": 493921304583,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(493921304583),
//--TRIMMABLE-BOUNDARY-START(283467907079),
    {
      "t": 1310721,
      "n": "PublicKeyPropertyMessage",
      "d": 65543,
      "h": 283467907079,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(283467907079),
//--TRIMMABLE-BOUNDARY-START(279172939783),
    {
      "t": 1310721,
      "n": "PublicKeyPropertyDiagId",
      "d": 65543,
      "h": 279172939783,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(279172939783),
//--TRIMMABLE-BOUNDARY-START(506806206471),
    {
      "t": 1310721,
      "n": "X509CertificatePrivateKeyMessage",
      "d": 65543,
      "h": 506806206471,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(506806206471),
//--TRIMMABLE-BOUNDARY-START(502511239175),
    {
      "t": 1310721,
      "n": "X509CertificatePrivateKeyDiagId",
      "d": 65543,
      "h": 502511239175,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(502511239175),
//--TRIMMABLE-BOUNDARY-START(274877972487),
    {
      "t": 1310721,
      "n": "ProduceLegacyHmacValuesMessage",
      "d": 65543,
      "h": 274877972487,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(274877972487),
//--TRIMMABLE-BOUNDARY-START(270583005191),
    {
      "t": 1310721,
      "n": "ProduceLegacyHmacValuesDiagId",
      "d": 65543,
      "h": 270583005191,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(270583005191),
//--TRIMMABLE-BOUNDARY-START(481036402695),
    {
      "t": 1310721,
      "n": "UseManagedSha1Message",
      "d": 65543,
      "h": 481036402695,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(481036402695),
//--TRIMMABLE-BOUNDARY-START(476741435399),
    {
      "t": 1310721,
      "n": "UseManagedSha1DiagId",
      "d": 65543,
      "h": 476741435399,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(476741435399),
//--TRIMMABLE-BOUNDARY-START(128849084423),
    {
      "t": 1310721,
      "n": "CryptoConfigEncodeOIDMessage",
      "d": 65543,
      "h": 128849084423,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(128849084423),
//--TRIMMABLE-BOUNDARY-START(124554117127),
    {
      "t": 1310721,
      "n": "CryptoConfigEncodeOIDDiagId",
      "d": 65543,
      "h": 124554117127,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(124554117127),
//--TRIMMABLE-BOUNDARY-START(111669215239),
    {
      "t": 1310721,
      "n": "CorruptedStateRecoveryMessage",
      "d": 65543,
      "h": 111669215239,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(111669215239),
//--TRIMMABLE-BOUNDARY-START(107374247943),
    {
      "t": 1310721,
      "n": "CorruptedStateRecoveryDiagId",
      "d": 65543,
      "h": 107374247943,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(107374247943),
//--TRIMMABLE-BOUNDARY-START(335007514631),
    {
      "t": 1310721,
      "n": "Rfc2898CryptDeriveKeyMessage",
      "d": 65543,
      "h": 335007514631,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(335007514631),
//--TRIMMABLE-BOUNDARY-START(330712547335),
    {
      "t": 1310721,
      "n": "Rfc2898CryptDeriveKeyDiagId",
      "d": 65543,
      "h": 330712547335,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(330712547335),
//--TRIMMABLE-BOUNDARY-START(68719542279),
    {
      "t": 1310721,
      "n": "CmsSignerCspParamsCtorMessage",
      "d": 65543,
      "h": 68719542279,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(68719542279),
//--TRIMMABLE-BOUNDARY-START(64424574983),
    {
      "t": 1310721,
      "n": "CmsSignerCspParamsCtorDiagId",
      "d": 65543,
      "h": 64424574983,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(64424574983),
//--TRIMMABLE-BOUNDARY-START(390842089479),
    {
      "t": 1310721,
      "n": "SignerInfoCounterSigMessage",
      "d": 65543,
      "h": 390842089479,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(390842089479),
//--TRIMMABLE-BOUNDARY-START(386547122183),
    {
      "t": 1310721,
      "n": "SignerInfoCounterSigDiagId",
      "d": 65543,
      "h": 386547122183,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(386547122183),
//--TRIMMABLE-BOUNDARY-START(309237710855),
    {
      "t": 1310721,
      "n": "RegexCompileToAssemblyMessage",
      "d": 65543,
      "h": 309237710855,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(309237710855),
//--TRIMMABLE-BOUNDARY-START(304942743559),
    {
      "t": 1310721,
      "n": "RegexCompileToAssemblyDiagId",
      "d": 65543,
      "h": 304942743559,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(304942743559),
//--TRIMMABLE-BOUNDARY-START(42949738503),
    {
      "t": 1310721,
      "n": "AssemblyNameMembersMessage",
      "d": 65543,
      "h": 42949738503,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(42949738503),
//--TRIMMABLE-BOUNDARY-START(38654771207),
    {
      "t": 1310721,
      "n": "AssemblyNameMembersDiagId",
      "d": 65543,
      "h": 38654771207,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(38654771207),
//--TRIMMABLE-BOUNDARY-START(416611893255),
    {
      "t": 1310721,
      "n": "SystemDataSerializationFormatBinaryMessage",
      "d": 65543,
      "h": 416611893255,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(416611893255),
//--TRIMMABLE-BOUNDARY-START(412316925959),
    {
      "t": 1310721,
      "n": "SystemDataSerializationFormatBinaryDiagId",
      "d": 65543,
      "h": 412316925959,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(412316925959),
//--TRIMMABLE-BOUNDARY-START(472446468103),
    {
      "t": 1310721,
      "n": "TlsVersion10and11Message",
      "d": 65543,
      "h": 472446468103,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(472446468103),
//--TRIMMABLE-BOUNDARY-START(468151500807),
    {
      "t": 1310721,
      "n": "TlsVersion10and11DiagId",
      "d": 65543,
      "h": 468151500807,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(468151500807),
//--TRIMMABLE-BOUNDARY-START(188978626567),
    {
      "t": 1310721,
      "n": "EncryptionPolicyMessage",
      "d": 65543,
      "h": 188978626567,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(188978626567),
//--TRIMMABLE-BOUNDARY-START(184683659271),
    {
      "t": 1310721,
      "n": "EncryptionPolicyDiagId",
      "d": 65543,
      "h": 184683659271,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(184683659271),
//--TRIMMABLE-BOUNDARY-START(171798757383),
    {
      "t": 1310721,
      "n": "EccXmlExportImportMessage",
      "d": 65543,
      "h": 171798757383,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(171798757383),
//--TRIMMABLE-BOUNDARY-START(167503790087),
    {
      "t": 1310721,
      "n": "EccXmlExportImportDiagId",
      "d": 65543,
      "h": 167503790087,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(167503790087),
//--TRIMMABLE-BOUNDARY-START(180388691975),
    {
      "t": 1310721,
      "n": "EcDhPublicKeyBlobMessage",
      "d": 65543,
      "h": 180388691975,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(180388691975),
//--TRIMMABLE-BOUNDARY-START(176093724679),
    {
      "t": 1310721,
      "n": "EcDhPublicKeyBlobDiagId",
      "d": 65543,
      "h": 176093724679,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(176093724679),
//--TRIMMABLE-BOUNDARY-START(34359803911),
    {
      "t": 1310721,
      "n": "AssemblyNameCodeBaseMessage",
      "d": 65543,
      "h": 34359803911,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(34359803911),
//--TRIMMABLE-BOUNDARY-START(30064836615),
    {
      "t": 1310721,
      "n": "AssemblyNameCodeBaseDiagId",
      "d": 65543,
      "h": 30064836615,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(30064836615),
//--TRIMMABLE-BOUNDARY-START(137439019015),
    {
      "t": 1310721,
      "n": "CryptoStringFactoryMessage",
      "d": 65543,
      "h": 137439019015,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(137439019015),
//--TRIMMABLE-BOUNDARY-START(133144051719),
    {
      "t": 1310721,
      "n": "CryptoStringFactoryDiagId",
      "d": 65543,
      "h": 133144051719,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(133144051719),
//--TRIMMABLE-BOUNDARY-START(103079280647),
    {
      "t": 1310721,
      "n": "ControlledExecutionRunMessage",
      "d": 65543,
      "h": 103079280647,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(103079280647),
//--TRIMMABLE-BOUNDARY-START(98784313351),
    {
      "t": 1310721,
      "n": "ControlledExecutionRunDiagId",
      "d": 65543,
      "h": 98784313351,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(98784313351),
//--TRIMMABLE-BOUNDARY-START(523986075655),
    {
      "t": 1310721,
      "n": "XmlSecureResolverMessage",
      "d": 65543,
      "h": 523986075655,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(523986075655),
//--TRIMMABLE-BOUNDARY-START(519691108359),
    {
      "t": 1310721,
      "n": "XmlSecureResolverDiagId",
      "d": 65543,
      "h": 519691108359,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(519691108359),
//--TRIMMABLE-BOUNDARY-START(369367252999),
    {
      "t": 1310721,
      "n": "RsaEncryptDecryptValueMessage",
      "d": 65543,
      "h": 369367252999,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(369367252999),
//--TRIMMABLE-BOUNDARY-START(365072285703),
    {
      "t": 1310721,
      "n": "RsaEncryptDecryptDiagId",
      "d": 65543,
      "h": 365072285703,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(365072285703),
//--TRIMMABLE-BOUNDARY-START(223338364935),
    {
      "t": 1310721,
      "n": "JsonSerializerOptionsAddContextMessage",
      "d": 65543,
      "h": 223338364935,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(223338364935),
//--TRIMMABLE-BOUNDARY-START(219043397639),
    {
      "t": 1310721,
      "n": "JsonSerializerOptionsAddContextDiagId",
      "d": 65543,
      "h": 219043397639,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(219043397639),
//--TRIMMABLE-BOUNDARY-START(249108168711),
    {
      "t": 1310721,
      "n": "LegacyFormatterMessage",
      "d": 65543,
      "h": 249108168711,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(249108168711),
//--TRIMMABLE-BOUNDARY-START(236223266823),
    {
      "t": 1310721,
      "n": "LegacyFormatterDiagId",
      "d": 65543,
      "h": 236223266823,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(236223266823),
//--TRIMMABLE-BOUNDARY-START(244813201415),
    {
      "t": 1310721,
      "n": "LegacyFormatterImplMessage",
      "d": 65543,
      "h": 244813201415,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(244813201415),
//--TRIMMABLE-BOUNDARY-START(240518234119),
    {
      "t": 1310721,
      "n": "LegacyFormatterImplDiagId",
      "d": 65543,
      "h": 240518234119,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(240518234119),
//--TRIMMABLE-BOUNDARY-START(317827645447),
    {
      "t": 1310721,
      "n": "RegexExtensibilityImplMessage",
      "d": 65543,
      "h": 317827645447,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(317827645447),
//--TRIMMABLE-BOUNDARY-START(313532678151),
    {
      "t": 1310721,
      "n": "RegexExtensibilityDiagId",
      "d": 65543,
      "h": 313532678151,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(313532678151),
//--TRIMMABLE-BOUNDARY-START(8590000135),
    {
      "t": 1310721,
      "n": "AesGcmTagConstructorMessage",
      "d": 65543,
      "h": 8590000135,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(8590000135),
//--TRIMMABLE-BOUNDARY-START(4295032839),
    {
      "t": 1310721,
      "n": "AesGcmTagConstructorDiagId",
      "d": 65543,
      "h": 4295032839,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(4295032839),
//--TRIMMABLE-BOUNDARY-START(455266598919),
    {
      "t": 1310721,
      "n": "ThreadVolatileReadWriteMessage",
      "d": 65543,
      "h": 455266598919,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(455266598919),
//--TRIMMABLE-BOUNDARY-START(450971631623),
    {
      "t": 1310721,
      "n": "ThreadVolatileReadWriteDiagId",
      "d": 65543,
      "h": 450971631623,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(450971631623),
//--TRIMMABLE-BOUNDARY-START(25769869319),
    {
      "t": 1310721,
      "n": "ArmIntrinsicPerformsUnsignedOperationMessage",
      "d": 65543,
      "h": 25769869319,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(25769869319),
//--TRIMMABLE-BOUNDARY-START(21474902023),
    {
      "t": 1310721,
      "n": "ArmIntrinsicPerformsUnsignedOperationDiagId",
      "d": 65543,
      "h": 21474902023,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(21474902023),
//--TRIMMABLE-BOUNDARY-START(257698103303),
    {
      "t": 1310721,
      "n": "LoadFromHashAlgorithmMessage",
      "d": 65543,
      "h": 257698103303,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(257698103303),
//--TRIMMABLE-BOUNDARY-START(253403136007),
    {
      "t": 1310721,
      "n": "LoadFromHashAlgorithmDiagId",
      "d": 65543,
      "h": 253403136007,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(253403136007),
//--TRIMMABLE-BOUNDARY-START(515396141063),
    {
      "t": 1310721,
      "n": "X509CtorCertDataObsoleteMessage",
      "d": 65543,
      "h": 515396141063,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(515396141063),
//--TRIMMABLE-BOUNDARY-START(511101173767),
    {
      "t": 1310721,
      "n": "X509CtorCertDataObsoleteDiagId",
      "d": 65543,
      "h": 511101173767,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(511101173767),
//--TRIMMABLE-BOUNDARY-START(463856533511),
    {
      "t": 1310721,
      "n": "TlsCipherAlgorithmEnumsMessage",
      "d": 65543,
      "h": 463856533511,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(463856533511),
//--TRIMMABLE-BOUNDARY-START(459561566215),
    {
      "t": 1310721,
      "n": "TlsCipherAlgorithmEnumsDiagId",
      "d": 65543,
      "h": 459561566215,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(459561566215),
//--TRIMMABLE-BOUNDARY-START(425201827847),
    {
      "t": 1310721,
      "n": "SystemEventsEventsThreadShutdownMessage",
      "d": 65543,
      "h": 425201827847,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(425201827847),
//--TRIMMABLE-BOUNDARY-START(420906860551),
    {
      "t": 1310721,
      "n": "SystemEventsEventsThreadShutdownDiagId",
      "d": 65543,
      "h": 420906860551,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(420906860551),
//--TRIMMABLE-BOUNDARY-START(343597449223),
    {
      "t": 1310721,
      "n": "Rfc2898DeriveBytesCtorMessage",
      "d": 65543,
      "h": 343597449223,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(343597449223),
//--TRIMMABLE-BOUNDARY-START(339302481927),
    {
      "t": 1310721,
      "n": "Rfc2898DeriveBytesCtorDiagId",
      "d": 65543,
      "h": 339302481927,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(339302481927),
//--TRIMMABLE-BOUNDARY-START(292057841671),
    {
      "t": 1310721,
      "n": "QueryableMinByMaxByTSourceObsoleteMessage",
      "d": 65543,
      "h": 292057841671,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(292057841671),
//--TRIMMABLE-BOUNDARY-START(287762874375),
    {
      "t": 1310721,
      "n": "QueryableMinByMaxByTSourceObsoleteDiagId",
      "d": 65543,
      "h": 287762874375,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(287762874375),
//--TRIMMABLE-BOUNDARY-START(532576010247),
    {
      "t": 1310721,
      "n": "XsltSettingsEnableScriptMessage",
      "d": 65543,
      "h": 532576010247,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(532576010247),
//--TRIMMABLE-BOUNDARY-START(528281042951),
    {
      "t": 1310721,
      "n": "XsltSettingsEnableScriptDiagId",
      "d": 65543,
      "h": 528281042951,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(528281042951)
  ],
  "h": 65543
}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `System.Obsoletions`; }
        });
        //--TRIMMABLE-BOUNDARY-END(65543)
        
        
        //--TRIMMABLE-BOUNDARY-START(3670023)
        $asm.$cls("$sris.System.Runtime.InteropServices.Marshalling.UniqueComInterfaceMarshaller<>", (T) => $asm.$gt("$sris.System.Runtime.InteropServices.Marshalling.UniqueComInterfaceMarshaller<>", [T], ($self) => class UniqueComInterfaceMarshaller$$
        {
            //--TRIMMABLE-BOUNDARY-START(8593604615)
            static /*void* */ ConvertToUnmanaged(/*T?*/ managed)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8593604615);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$box(managed, T) === null)
                {
                    return null;
                }
                /*nint*/ let unknown;
                if (!$.$$.System.Runtime.InteropServices.ComWrappers.TryGetComInstance($.$box(managed, T), $.$ref(() => unknown, ($v) => unknown = $v, $.$$.System.IntPtr)))
                {
                    unknown = $.$sris.System.Runtime.InteropServices.Marshalling.StrategyBasedComWrappers.DefaultMarshallingInstance.GetOrCreateComInterfaceForObject($.$box(managed, T), 0/*CreateComInterfaceFlags.None*/);
                }
                return $.$sris.System.Runtime.InteropServices.Marshalling.ComInterfaceMarshaller$$(T).CastIUnknownToInterfaceType(unknown);
            }
            //--TRIMMABLE-BOUNDARY-END(8593604615)
            
            //--TRIMMABLE-BOUNDARY-START(4298637319)
            static /*T? */ ConvertToManaged(/*void**/ unmanaged)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4298637319);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (unmanaged === null)
                {
                    return $.$default(T);
                }
                return $.$cast($.$sris.System.Runtime.InteropServices.Marshalling.StrategyBasedComWrappers.DefaultMarshallingInstance.GetOrCreateObjectForComInstance$1($.$$.System.IntPtr.op_Explicit$4(unmanaged), 2/*CreateObjectFlags.UniqueInstance*/), T);
            }
            //--TRIMMABLE-BOUNDARY-END(4298637319)
            
            //--TRIMMABLE-BOUNDARY-START(12888571911)
            static /*void */ Free(/*void**/ unmanaged)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12888571911);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (unmanaged !== null)
                {
                    $.$$.System.Runtime.InteropServices.Marshal.Release($.$$.System.IntPtr.op_Explicit$4(unmanaged));
                }
            }
            //--TRIMMABLE-BOUNDARY-END(12888571911)
            
            static $h = 3670023;
            static $g = 1;
            static $f = 0b1010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 131073,
  "m": [
//--TRIMMABLE-BOUNDARY-START(8593604615),
    {
      "r": $.$typePointer($.$$.System.Void).$h,
      "p": [
        {
          "n": "managed",
          "p": T?.$h??1507328
        }
      ],
      "n": "ConvertToUnmanaged",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x200000000n),
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8593604615),
//--TRIMMABLE-BOUNDARY-START(4298637319),
    {
      "r": T?.$h??1507328,
      "p": [
        {
          "n": "unmanaged",
          "p": $.$typePointer($.$$.System.Void).$h
        }
      ],
      "n": "ConvertToManaged",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x100000000n),
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(4298637319),
//--TRIMMABLE-BOUNDARY-START(12888571911),
    {
      "r": 65537,
      "p": [
        {
          "n": "unmanaged",
          "p": $.$typePointer($.$$.System.Void).$h
        }
      ],
      "n": "Free",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x300000000n),
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(12888571911)
  ],
  "g": [T?.$h??1507328
  ],
  "r": 1,
  "h": this.$h,
  "a": [
    {
      "t": 159252481,
      "c": 4454219777,
      "a": [
        {
          "v": "android",
          "t": 1310721
        }
      ]
    },
    {
      "t": 159252481,
      "c": 4454219777,
      "a": [
        {
          "v": "browser",
          "t": 1310721
        }
      ]
    },
    {
      "t": 159252481,
      "c": 4454219777,
      "a": [
        {
          "v": "ios",
          "t": 1310721
        }
      ]
    },
    {
      "t": 159252481,
      "c": 4454219777,
      "a": [
        {
          "v": "tvos",
          "t": 1310721
        }
      ]
    },
    {
      "t": 54132737,
      "c": 8644067329,
      "a": [
        {
          "v": false,
          "t": 262145
        }
      ]
    },
    {
      "t": 144179201,
      "c": 4439146497,
      "a": [
        {
          "v": 144244737,
          "t": 187629569
        },
        {
          "v": 0,
          "t": 144310273
        },
        {
          "v": $.$sris.System.Runtime.InteropServices.Marshalling.UniqueComInterfaceMarshaller$$().$h,
          "t": 187629569
        }
      ]
    }
  ]
}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `System.Runtime.InteropServices.Marshalling.UniqueComInterfaceMarshaller<${T?.$fullName}>`; }
        }));
        //--TRIMMABLE-BOUNDARY-END(3670023)
        
        
        //--TRIMMABLE-BOUNDARY-START(4587527)
        $asm.$cls("$sris.System.Security.SecureStringMarshal", ($self) => class SecureStringMarshal
        {
            //--TRIMMABLE-BOUNDARY-START(4299554823)
            static /*IntPtr */ SecureStringToCoTaskMemAnsi(/*SecureString*/ s)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4299554823);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return $.$$.System.Runtime.InteropServices.Marshal.SecureStringToCoTaskMemAnsi(s);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(4299554823)
            
            //--TRIMMABLE-BOUNDARY-START(12889489415)
            static /*IntPtr */ SecureStringToGlobalAllocAnsi(/*SecureString*/ s)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(12889489415);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return $.$$.System.Runtime.InteropServices.Marshal.SecureStringToGlobalAllocAnsi(s);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(12889489415)
            
            //--TRIMMABLE-BOUNDARY-START(8594522119)
            static /*IntPtr */ SecureStringToCoTaskMemUnicode(/*SecureString*/ s)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(8594522119);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return $.$$.System.Runtime.InteropServices.Marshal.SecureStringToCoTaskMemUnicode(s);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(8594522119)
            
            //--TRIMMABLE-BOUNDARY-START(17184456711)
            static /*IntPtr */ SecureStringToGlobalAllocUnicode(/*SecureString*/ s)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(17184456711);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return $.$$.System.Runtime.InteropServices.Marshal.SecureStringToGlobalAllocUnicode(s);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(17184456711)
            
            static $h = 4587527;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 131073,
  "m": [
//--TRIMMABLE-BOUNDARY-START(4299554823),
    {
      "r": 786433,
      "p": [
        {
          "n": "s",
          "p": 161284097
        }
      ],
      "n": "SecureStringToCoTaskMemAnsi",
      "d": 4587527,
      "h": 4299554823,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(4299554823),
//--TRIMMABLE-BOUNDARY-START(12889489415),
    {
      "r": 786433,
      "p": [
        {
          "n": "s",
          "p": 161284097
        }
      ],
      "n": "SecureStringToGlobalAllocAnsi",
      "d": 4587527,
      "h": 12889489415,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(12889489415),
//--TRIMMABLE-BOUNDARY-START(8594522119),
    {
      "r": 786433,
      "p": [
        {
          "n": "s",
          "p": 161284097
        }
      ],
      "n": "SecureStringToCoTaskMemUnicode",
      "d": 4587527,
      "h": 8594522119,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8594522119),
//--TRIMMABLE-BOUNDARY-START(17184456711),
    {
      "r": 786433,
      "p": [
        {
          "n": "s",
          "p": 161284097
        }
      ],
      "n": "SecureStringToGlobalAllocUnicode",
      "d": 4587527,
      "h": 17184456711,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(17184456711)
  ],
  "h": 4587527
}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `System.Security.SecureStringMarshal`; }
        });
        //--TRIMMABLE-BOUNDARY-END(4587527)
        
        
        //--TRIMMABLE-BOUNDARY-START(2752519)
        $asm.$cls("$sris.System.Runtime.InteropServices.Marshalling.FreeThreadedStrategy", ($self) => class FreeThreadedStrategy extends $.$$.System.Object
        {
            //--TRIMMABLE-BOUNDARY-START(12887654407)
            /*IIUnknownStrategy*/ static Instance = null;
            //--TRIMMABLE-BOUNDARY-END(12887654407)
            
            //--TRIMMABLE-BOUNDARY-START(ALL, 17182621703, 4298375175)
            /*void* */ System$Runtime$InteropServices$Marshalling$IIUnknownStrategy$CreateInstancePointer(/*void**/ unknown)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17182621703);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.Runtime.InteropServices.Marshal.AddRef($.$$.System.IntPtr.op_Explicit$4(unknown));
                return unknown;
            }
            //--TRIMMABLE-BOUNDARY-END(ALL, 17182621703, 4298375175)
            
            //--TRIMMABLE-BOUNDARY-START(ALL, 21477588999, 8593342471)
            /*int */ System$Runtime$InteropServices$Marshalling$IIUnknownStrategy$QueryInterface(/*void**/ thisPtr, /*in Guid*/ handle, /*out void**/ ppObj)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21477588999);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*nint*/ let ppv;
                /*int*/ let hr = $.$$.System.Runtime.InteropServices.Marshal.QueryInterface($.$$.System.IntPtr.op_Explicit$4(thisPtr), handle, $.$ref(() => ppv, ($v) => ppv = $v, $.$$.System.IntPtr));
                if (hr < 0)
                {
                    ppObj.$v = null;
                }
                else 
                {
                    ppObj.$v = $.$$.System.IntPtr.op_Explicit$5(ppv);
                }
                return hr;
            }
            //--TRIMMABLE-BOUNDARY-END(ALL, 21477588999, 8593342471)
            
            //--TRIMMABLE-BOUNDARY-START(ALL, 25772556295, 12888309767)
            /*int */ System$Runtime$InteropServices$Marshalling$IIUnknownStrategy$Release(/*void**/ thisPtr)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(25772556295);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return $.$$.System.Runtime.InteropServices.Marshal.Release($.$$.System.IntPtr.op_Explicit$4(thisPtr));
                }
            }
            //--TRIMMABLE-BOUNDARY-END(ALL, 25772556295, 12888309767)
            
            //default reference type constructor overload
            $ctor$1()
            {
                super.$ctor();
                return this;
            }
            //--TRIMMABLE-BOUNDARY-START(4297719815)
            //Static Initializer
            static $sinit()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(12887654407)
                    this.Instance = new $.$sris.System.Runtime.InteropServices.Marshalling.FreeThreadedStrategy().$ctor$1();
                    //--TRIMMABLE-BOUNDARY-END(12887654407)
                    
                }
            }
            //--TRIMMABLE-BOUNDARY-END(4297719815)
            
            static $h = 2752519;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 131073,
  "l": [
//--TRIMMABLE-BOUNDARY-START(12887654407),
    {
      "t": 3407879,
      "n": "Instance",
      "d": 2752519,
      "h": 12887654407,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(12887654407)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(8592687111),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 2752519,
      "h": 8592687111,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8592687111)
  ],
  "i": [3407879
  ],
  "h": 2752519
}; }
            static get $b() { return $.$$.System.Object; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$sris.System.Runtime.InteropServices.Marshalling.IIUnknownStrategy ]; }
            static get $fullName() { return `System.Runtime.InteropServices.Marshalling.FreeThreadedStrategy`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2752519)
        
        
        //--TRIMMABLE-BOUNDARY-START(2359303)
        $asm.$cls("$sris.System.Runtime.InteropServices.Marshalling.DefaultCaching", ($self) => class DefaultCaching extends $.$$.System.Object
        {
            //--TRIMMABLE-BOUNDARY-START(4297326599)
            /*ConcurrentDictionary<RuntimeTypeHandle, IIUnknownCacheStrategy.TableInfo>*/ _cache = null;
            //--TRIMMABLE-BOUNDARY-END(4297326599)
            
            //--TRIMMABLE-BOUNDARY-START(ALL, 17182228487, 8593014791)
            /*IIUnknownCacheStrategy.TableInfo */ System$Runtime$InteropServices$Marshalling$IIUnknownCacheStrategy$ConstructTableInfo(/*RuntimeTypeHandle*/ handle, /*IIUnknownDerivedDetails*/ details, /*void**/ ptr)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17182228487);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let obj = $.$cast(ptr, $.$typePointer($.$typePointer($.$typePointer($.$$.System.Void))));
                return (() =>
                {
                    //new $.$sris.System.Runtime.InteropServices.Marshalling.IIUnknownCacheStrategy.TableInfo()
                    const $t1 = $.$sris.System.Runtime.InteropServices.Marshalling.IIUnknownCacheStrategy.TableInfo;
                    const $i1 = new $t1();
                    $i1.ThisPtr = obj;
                    $i1.Table = obj.$v;
                    $i1.ManagedType = details.System$Runtime$InteropServices$Marshalling$IIUnknownDerivedDetails$Implementation.TypeHandle;
                    return $i1;
                })();
            }
            //--TRIMMABLE-BOUNDARY-END(ALL, 17182228487, 8593014791)
            
            //--TRIMMABLE-BOUNDARY-START(ALL, 21477195783, 17182949383)
            /*bool */ System$Runtime$InteropServices$Marshalling$IIUnknownCacheStrategy$TryGetTableInfo(/*RuntimeTypeHandle*/ handle, /*out IIUnknownCacheStrategy.TableInfo*/ info)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21477195783);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this._cache.TryGetValue(handle, info);
            }
            //--TRIMMABLE-BOUNDARY-END(ALL, 21477195783, 17182949383)
            
            //--TRIMMABLE-BOUNDARY-START(ALL, 25772163079, 21477916679)
            /*bool */ System$Runtime$InteropServices$Marshalling$IIUnknownCacheStrategy$TrySetTableInfo(/*RuntimeTypeHandle*/ handle, /*IIUnknownCacheStrategy.TableInfo*/ info)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25772163079);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this._cache.TryAdd(handle, info);
            }
            //--TRIMMABLE-BOUNDARY-END(ALL, 25772163079, 21477916679)
            
            //--TRIMMABLE-BOUNDARY-START(ALL, 12887261191, 4298047495)
            /*void */ System$Runtime$InteropServices$Marshalling$IIUnknownCacheStrategy$Clear(/*IIUnknownStrategy*/ unknownStrategy)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12887261191);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                var $en2 = this._cache.Values.System$Collections$Generic$IEnumerable$$$GetEnumerator();
                while ($en2.System$Collections$IEnumerator$MoveNext())
                {
                    var info = $en2.System$Collections$Generic$IEnumerator$$$Current;
                    {
                        _ = unknownStrategy.System$Runtime$InteropServices$Marshalling$IIUnknownStrategy$Release(info.ThisPtr);
                    }
                }
                this._cache.Clear();
            }
            //--TRIMMABLE-BOUNDARY-END(ALL, 12887261191, 4298047495)
            
            //default reference type constructor overload
            $ctor$1()
            {
                super.$ctor();
                return this;
            }
            //default member initializer
            constructor()
            {
                super();
                //--TRIMMABLE-BOUNDARY-START(4297326599)
                this._cache = new ($.$scc.System.Collections.Concurrent.ConcurrentDictionary$$$($.$$.System.RuntimeTypeHandle, $.$sris.System.Runtime.InteropServices.Marshalling.IIUnknownCacheStrategy.TableInfo))().$ctor$8(1, 16);
                //--TRIMMABLE-BOUNDARY-END(4297326599)
                
            }
            static $h = 2359303;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 131073,
  "l": [
//--TRIMMABLE-BOUNDARY-START(4297326599),
    {
      "t": $.$scc.System.Collections.Concurrent.ConcurrentDictionary$$$($.$$.System.RuntimeTypeHandle, $.$sris.System.Runtime.InteropServices.Marshalling.IIUnknownCacheStrategy.TableInfo).$h,
      "n": "_cache",
      "d": 2359303,
      "h": 4297326599,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(4297326599)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(8592293895),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 2359303,
      "h": 8592293895,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8592293895)
  ],
  "i": [3080199
  ],
  "h": 2359303
}; }
            static get $b() { return $.$$.System.Object; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$sris.System.Runtime.InteropServices.Marshalling.IIUnknownCacheStrategy ]; }
            static get $fullName() { return `System.Runtime.InteropServices.Marshalling.DefaultCaching`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2359303)
        
        
        //--TRIMMABLE-BOUNDARY-START(2424839)
        $asm.$cls("$sris.System.Runtime.InteropServices.Marshalling.DefaultIUnknownInterfaceDetailsStrategy", ($self) => class DefaultIUnknownInterfaceDetailsStrategy extends $.$$.System.Object
        {
            //--TRIMMABLE-BOUNDARY-START(21477261319)
            /*IIUnknownInterfaceDetailsStrategy*/ static Instance = null;
            //--TRIMMABLE-BOUNDARY-END(21477261319)
            
            //--TRIMMABLE-BOUNDARY-START(12887326727)
            /*IComExposedDetails? */ GetComExposedTypeDetails(/*RuntimeTypeHandle*/ type)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12887326727);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$sris.System.Runtime.InteropServices.Marshalling.IComExposedDetails.System$Runtime$InteropServices$Marshalling$IComExposedDetails$GetFromAttribute(type);
            }
            //--TRIMMABLE-BOUNDARY-END(12887326727)
            
            //--TRIMMABLE-BOUNDARY-START(17182294023)
            /*IIUnknownDerivedDetails? */ GetIUnknownDerivedDetails(/*RuntimeTypeHandle*/ type)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17182294023);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$sris.System.Runtime.InteropServices.Marshalling.IIUnknownDerivedDetails.System$Runtime$InteropServices$Marshalling$IIUnknownDerivedDetails$GetFromAttribute(type);
            }
            //--TRIMMABLE-BOUNDARY-END(17182294023)
            
            //--TRIMMABLE-BOUNDARY-START(8593211399)
            //Generated interface implemetation for System.Runtime.InteropServices.Marshalling.IIUnknownInterfaceDetailsStrategy.GetIUnknownDerivedDetails(System.RuntimeTypeHandle)
            System$Runtime$InteropServices$Marshalling$IIUnknownInterfaceDetailsStrategy$GetIUnknownDerivedDetails()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8593211399);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.GetIUnknownDerivedDetails(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(8593211399)
            
            //--TRIMMABLE-BOUNDARY-START(4298244103)
            //Generated interface implemetation for System.Runtime.InteropServices.Marshalling.IIUnknownInterfaceDetailsStrategy.GetComExposedTypeDetails(System.RuntimeTypeHandle)
            System$Runtime$InteropServices$Marshalling$IIUnknownInterfaceDetailsStrategy$GetComExposedTypeDetails()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4298244103);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.GetComExposedTypeDetails(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4298244103)
            
            //default reference type constructor overload
            $ctor$1()
            {
                super.$ctor();
                return this;
            }
            //--TRIMMABLE-BOUNDARY-START(4297392135)
            //Static Initializer
            static $sinit()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(21477261319)
                    this.Instance = new $.$sris.System.Runtime.InteropServices.Marshalling.DefaultIUnknownInterfaceDetailsStrategy().$ctor$1();
                    //--TRIMMABLE-BOUNDARY-END(21477261319)
                    
                }
            }
            //--TRIMMABLE-BOUNDARY-END(4297392135)
            
            static $h = 2424839;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 131073,
  "m": [
//--TRIMMABLE-BOUNDARY-START(12887326727),
    {
      "r": 3014663,
      "p": [
        {
          "n": "type",
          "p": 160038913
        }
      ],
      "n": "GetComExposedTypeDetails",
      "d": 2424839,
      "h": 12887326727,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(12887326727),
//--TRIMMABLE-BOUNDARY-START(17182294023),
    {
      "r": 3211271,
      "p": [
        {
          "n": "type",
          "p": 160038913
        }
      ],
      "n": "GetIUnknownDerivedDetails",
      "d": 2424839,
      "h": 17182294023,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(17182294023)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(21477261319),
    {
      "t": 3276807,
      "n": "Instance",
      "d": 2424839,
      "h": 21477261319,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(21477261319)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(8592359431),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 2424839,
      "h": 8592359431,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8592359431)
  ],
  "i": [3276807
  ],
  "h": 2424839
}; }
            static get $b() { return $.$$.System.Object; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$sris.System.Runtime.InteropServices.Marshalling.IIUnknownInterfaceDetailsStrategy ]; }
            static get $fullName() { return `System.Runtime.InteropServices.Marshalling.DefaultIUnknownInterfaceDetailsStrategy`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2424839)
        
        
        //--TRIMMABLE-BOUNDARY-START(1835015)
        $asm.$cls("$sris.System.Runtime.InteropServices.Marshalling.ComImportInteropInterfaceDetailsStrategy", ($self) => class ComImportInteropInterfaceDetailsStrategy extends $.$$.System.Object
        {
            //--TRIMMABLE-BOUNDARY-START(42951507975)
            /*IIUnknownInterfaceDetailsStrategy*/ static Instance = null;
            //--TRIMMABLE-BOUNDARY-END(42951507975)
            
            //--TRIMMABLE-BOUNDARY-START(4296802311)
            /*ConditionalWeakTable<Type, Type>*/ _forwarderInterfaceCache = null;
            //--TRIMMABLE-BOUNDARY-END(4296802311)
            
            //--TRIMMABLE-BOUNDARY-START(25771638791)
            /*IComExposedDetails? */ GetComExposedTypeDetails(/*RuntimeTypeHandle*/ type)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(25771638791);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return $.$sris.System.Runtime.InteropServices.Marshalling.DefaultIUnknownInterfaceDetailsStrategy.Instance.System$Runtime$InteropServices$Marshalling$IIUnknownInterfaceDetailsStrategy$GetComExposedTypeDetails(type);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(25771638791)
            
            //--TRIMMABLE-BOUNDARY-START(34361573383)
            /*IIUnknownDerivedDetails? */ GetIUnknownDerivedDetails(/*RuntimeTypeHandle*/ type)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(34361573383);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*Type*/ let runtimeType = $.$$.System.Type.GetTypeFromHandle(type);
                if (!runtimeType.IsImport)
                {
                    return $.$sris.System.Runtime.InteropServices.Marshalling.DefaultIUnknownInterfaceDetailsStrategy.Instance.System$Runtime$InteropServices$Marshalling$IIUnknownInterfaceDetailsStrategy$GetIUnknownDerivedDetails(type);
                }
                /*Type*/ let implementationType = this._forwarderInterfaceCache.GetValue(runtimeType, new $.$$.System.Runtime.CompilerServices.ConditionalWeakTable$$$($.$$.System.Type, $.$$.System.Type).CreateValueCallback().$ctor(this,  (/*runtimeType*/ runtimeType) =>
                {
                    /*AssemblyBuilder*/ let assembly = /*$.$$.System.Reflection.Emit.AssemblyBuilder*/$.$$.DeletedObject.DefineDynamicAssembly(new $.$$.System.Reflection.AssemblyName().$ctor$2("ComImportForwarder"), runtimeType.IsCollectible ? 9/*AssemblyBuilderAccess.RunAndCollect*/ : 1/*AssemblyBuilderAccess.Run*/);
                    /*ModuleBuilder*/ let module = assembly.DefineDynamicModule("ComImportForwarder");
                    /*ConstructorInfo*/ let ignoresAccessChecksToAttributeConstructor = $.$sris.System.Runtime.InteropServices.Marshalling.ComImportInteropInterfaceDetailsStrategy.GetIgnoresAccessChecksToAttributeConstructor(module);
                    assembly.SetCustomAttribute(new CustomAttributeBuilder(ignoresAccessChecksToAttributeConstructor, $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$$.System.Object), [$.$sris.System.Runtime.InteropServices.Marshalling.ComImportInteropInterfaceDetailsStrategy.IComImportAdapter.$type.Assembly.GetName().Name], [-1], null)));
                    /*TypeBuilder*/ let implementation = module.DefineType("InterfaceForwarder", 32/*TypeAttributes.Interface*/ | 128/*TypeAttributes.Abstract*/, null, runtimeType.GetInterfaces());
                    implementation.AddInterfaceImplementation(runtimeType);
                    implementation.SetCustomAttribute(new CustomAttributeBuilder($.$$.System.Runtime.InteropServices.DynamicInterfaceCastableImplementationAttribute.$type.GetConstructor$4($.$$.System.Array.Empty($.$$.System.Type)), $.$$.System.Array.Empty($.$$.System.Object)));
                    let $i1 = 0;
                    let $arr1 = implementation.GetInterfaces();
                    while ($i1 < $arr1.length)
                    {
                        let iface = $arr1[$i1++];
                        assembly.SetCustomAttribute(new CustomAttributeBuilder(ignoresAccessChecksToAttributeConstructor, $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$$.System.Object), [iface.Assembly.GetName().Name], [-1], null)));
                        let $i2 = 0;
                        let $arr2 = iface.GetMethods();
                        while ($i2 < $arr2.length)
                        {
                            let method = $arr2[$i2++];
                            /*Type[]*/ let returnTypeOptionalModifiers = method.ReturnParameter.GetOptionalCustomModifiers();
                            /*Type[]*/ let returnTypeRequiredModifiers = method.ReturnParameter.GetRequiredCustomModifiers();
                            /*ParameterInfo[]*/ let parameters = method.GetParameters();
                            /*var*/ let parameterTypes = $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$$.System.Type), null, [parameters.length], null);
                            /*var*/ let parameterOptionalModifiers = $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$typeArray($.$$.System.Type)), null, [parameters.length], null);
                            /*var*/ let parameterRequiredModifiers = $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$typeArray($.$$.System.Type)), null, [parameters.length], null);
                            for(/*int*/ let i = 0; i < parameters.length; i++)
                            {
                                $.$$.System.Array.$WriteT1.call(parameterTypes, $.$$.System.Array.$ReadT1.call(parameters, i).ParameterType, i);
                                $.$$.System.Array.$WriteT1.call(parameterOptionalModifiers, $.$$.System.Array.$ReadT1.call(parameters, i).GetOptionalCustomModifiers(), i);
                                $.$$.System.Array.$WriteT1.call(parameterRequiredModifiers, $.$$.System.Array.$ReadT1.call(parameters, i).GetRequiredCustomModifiers(), i);
                            }
                            /*MethodBuilder*/ let builder = implementation.DefineMethod(method.Name, 1/*MethodAttributes.Private*/ | 32/*MethodAttributes.Final*/ | 128/*MethodAttributes.HideBySig*/ | 64/*MethodAttributes.Virtual*/, 32/*CallingConventions.HasThis*/, method.ReturnType, returnTypeRequiredModifiers, returnTypeOptionalModifiers, parameterTypes, parameterRequiredModifiers, parameterOptionalModifiers);
                            /*ILGenerator*/ let il = builder.GetILGenerator();
                            il.Emit(/*$.$$.System.Reflection.Emit.OpCodes*/$.$$.DeletedObject.Ldarg_0);
                            il.Emit(/*$.$$.System.Reflection.Emit.OpCodes*/$.$$.DeletedObject.Castclass, $.$sris.System.Runtime.InteropServices.Marshalling.ComImportInteropInterfaceDetailsStrategy.IComImportAdapter.$type);
                            il.Emit(/*$.$$.System.Reflection.Emit.OpCodes*/$.$$.DeletedObject.Callvirt, $.$sris.System.Runtime.InteropServices.Marshalling.ComImportInteropInterfaceDetailsStrategy.IComImportAdapter.System$Runtime$InteropServices$Marshalling$ComImportInteropInterfaceDetailsStrategy$IComImportAdapter$GetRuntimeCallableWrapperMethod);
                            il.Emit(/*$.$$.System.Reflection.Emit.OpCodes*/$.$$.DeletedObject.Castclass, iface);
                            for(/*int*/ let i = 0; i < parameters.length; i++)
                            {
                                il.Emit(/*$.$$.System.Reflection.Emit.OpCodes*/$.$$.DeletedObject.Ldarg, ((i + 1) | 0));
                            }
                            il.Emit(/*$.$$.System.Reflection.Emit.OpCodes*/$.$$.DeletedObject.Callvirt, method);
                            il.Emit(/*$.$$.System.Reflection.Emit.OpCodes*/$.$$.DeletedObject.Ret);
                            implementation.DefineMethodOverride(builder, method);
                        }
                    }
                    return implementation.CreateType();
                }, {
  "r": 187629569,
  "p": [
    {
      "n": "runtimeType",
      "p": 187629569
    }
  ],
  "n": "",
  "d": 1835015,
  "h": 0,
  "f": 17825794
}));
                return new $.$sris.System.Runtime.InteropServices.Marshalling.ComImportInteropInterfaceDetailsStrategy.ComImportDetails().$ctor$1(runtimeType.GUID, implementationType);
            }
            //--TRIMMABLE-BOUNDARY-END(34361573383)
            
            //--TRIMMABLE-BOUNDARY-START(30066606087)
            static /*ConstructorInfo */ GetIgnoresAccessChecksToAttributeConstructor(/*ModuleBuilder*/ moduleBuilder)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(30066606087);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*Type*/ let attributeType = $.$sris.System.Runtime.InteropServices.Marshalling.ComImportInteropInterfaceDetailsStrategy.EmitIgnoresAccessChecksToAttribute(moduleBuilder);
                return attributeType.GetConstructor$4($.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$$.System.Type), [$.$$.System.String.$type], [-1], null));
            }
            //--TRIMMABLE-BOUNDARY-END(30066606087)
            
            //--TRIMMABLE-BOUNDARY-START(21476671495)
            static /*Type */ EmitIgnoresAccessChecksToAttribute(/*ModuleBuilder*/ moduleBuilder)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21476671495);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let tb = moduleBuilder.DefineType("System.Runtime.CompilerServices.IgnoresAccessChecksToAttribute", 0/*TypeAttributes.NotPublic*/, $.$$.System.Attribute.$type);
                /*var*/ let attributeUsage = new CustomAttributeBuilder($.$sris.System.Runtime.InteropServices.Marshalling.ComImportInteropInterfaceDetailsStrategy.s_attributeUsageCtor, $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$$.System.Object), [$.$box(1/*AttributeTargets.Assembly*/, $.$$.System.AttributeTargets)], [-1], null), $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$$.System.Reflection.PropertyInfo), [$.$sris.System.Runtime.InteropServices.Marshalling.ComImportInteropInterfaceDetailsStrategy.s_attributeUsageAllowMultipleProperty], [-1], null), $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$$.System.Object), [$.$box(true, $.$$.System.Boolean)], [-1], null));
                tb.SetCustomAttribute(attributeUsage);
                /*var*/ let cb = tb.DefineConstructor(6/*MethodAttributes.Public*/ | 128/*MethodAttributes.HideBySig*/ | 2048/*MethodAttributes.SpecialName*/ | 4096/*MethodAttributes.RTSpecialName*/, 1/*CallingConventions.Standard*/, $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$$.System.Type), [$.$$.System.String.$type], [-1], null));
                cb.DefineParameter(1, 0/*ParameterAttributes.None*/, "assemblyName");
                /*var*/ let il = cb.GetILGenerator();
                il.Emit(/*$.$$.System.Reflection.Emit.OpCodes*/$.$$.DeletedObject.Ldarg_0);
                il.Emit(/*$.$$.System.Reflection.Emit.OpCodes*/$.$$.DeletedObject.Call, $.$sris.System.Runtime.InteropServices.Marshalling.ComImportInteropInterfaceDetailsStrategy.s_attributeBaseClassCtor);
                il.Emit(/*$.$$.System.Reflection.Emit.OpCodes*/$.$$.DeletedObject.Ret);
                return tb.CreateType();
            }
            //--TRIMMABLE-BOUNDARY-END(21476671495)
            
            //--TRIMMABLE-BOUNDARY-START(47246475271)
            /*ConstructorInfo*/ static s_attributeBaseClassCtor = null;
            //--TRIMMABLE-BOUNDARY-END(47246475271)
            
            //--TRIMMABLE-BOUNDARY-START(55836409863)
            /*ConstructorInfo*/ static s_attributeUsageCtor = null;
            //--TRIMMABLE-BOUNDARY-END(55836409863)
            
            //--TRIMMABLE-BOUNDARY-START(51541442567)
            /*PropertyInfo*/ static s_attributeUsageAllowMultipleProperty = null;
            //--TRIMMABLE-BOUNDARY-END(51541442567)
            
            //--TRIMMABLE-BOUNDARY-START(1900551)
            static $_ComImportDetails;
            static get ComImportDetails()
            {
                let $cls = $.$sris.System.Runtime.InteropServices.Marshalling.ComImportInteropInterfaceDetailsStrategy;
                return $cls.$_ComImportDetails ??= $asm.$ncls("$sris.System.Runtime.InteropServices.Marshalling.ComImportInteropInterfaceDetailsStrategy.ComImportDetails", ($self) => class ComImportDetails extends $.$$.System.Object
                {
                    //--TRIMMABLE-BOUNDARY-START(42951573511)
                    /*Guid*/ Iid;
                    //--TRIMMABLE-BOUNDARY-END(42951573511)
                    
                    //--TRIMMABLE-BOUNDARY-START(47246540807)
                    /*Type*/ Implementation = null;
                    //--TRIMMABLE-BOUNDARY-END(47246540807)
                    
                    //--TRIMMABLE-BOUNDARY-START(51541508103)
                    /*void** */ get ManagedVirtualMethodTable()
                    {
                        return null;
                    }
                    //--TRIMMABLE-BOUNDARY-END(51541508103)
                    
                    //--TRIMMABLE-BOUNDARY-START(8593145863)
                    //Generated interface implemetation for System.Runtime.InteropServices.Marshalling.IIUnknownDerivedDetails.Iid.get
                    get System$Runtime$InteropServices$Marshalling$IIUnknownDerivedDetails$Iid()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(34362949639);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return this.Iid;
                    }
                    //--TRIMMABLE-BOUNDARY-END(8593145863)
                    
                    //--TRIMMABLE-BOUNDARY-START(17183080455)
                    //Generated interface implemetation for System.Runtime.InteropServices.Marshalling.IIUnknownDerivedDetails.Implementation.get
                    get System$Runtime$InteropServices$Marshalling$IIUnknownDerivedDetails$Implementation()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(38657916935);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return this.Implementation;
                    }
                    //--TRIMMABLE-BOUNDARY-END(17183080455)
                    
                    //--TRIMMABLE-BOUNDARY-START(25773015047)
                    //Generated interface implemetation for System.Runtime.InteropServices.Marshalling.IIUnknownDerivedDetails.ManagedVirtualMethodTable.get
                    get System$Runtime$InteropServices$Marshalling$IIUnknownDerivedDetails$ManagedVirtualMethodTable()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(42952884231);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return this.ManagedVirtualMethodTable;
                    }
                    //--TRIMMABLE-BOUNDARY-END(25773015047)
                    
                    //Begin primary constructor
                    /*Guid*/ iid = new $.$$.System.Guid();
                    /*Type*/ implementation = null;
                    $ctor$1(/*Guid*/iid, /*Type*/implementation)
                    {
                        this.iid = iid;
                        this.implementation = implementation;
                        //depends on primary constructor parameter
                        this.Iid = this.iid;
                        //depends on primary constructor parameter
                        this.Implementation = this.implementation;
                        return this
                    }
                    //End primary constructor
                    static $h = 1900551;
                    static $f = 0b10000000010010000;
                    static $k = 1;
                    static $$md;
                    static get $md() { return this.$$md ??= {
  "b": 131073,
  "p": [
//--TRIMMABLE-BOUNDARY-START(42951573511),
    {
      "p": 88866817,
      "g": {
        "r": 0,
        "d": 0,
        "h": 21476737031,
        "f": 50331649
      },
      "n": "Iid",
      "d": 1900551,
      "h": 42951573511,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(42951573511),
//--TRIMMABLE-BOUNDARY-START(47246540807),
    {
      "p": 187629569,
      "g": {
        "r": 0,
        "d": 0,
        "h": 30066671623,
        "f": 50331649
      },
      "n": "Implementation",
      "d": 1900551,
      "h": 47246540807,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(47246540807),
//--TRIMMABLE-BOUNDARY-START(51541508103),
    {
      "p": $.$typePointer($.$typePointer($.$$.System.Void)).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 38656606215,
        "f": 50331649
      },
      "n": "ManagedVirtualMethodTable",
      "d": 1900551,
      "h": 51541508103,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(51541508103)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296867847),
    {
      "p": [
        {
          "n": "iid",
          "p": 88866817
        },
        {
          "n": "implementation",
          "p": 187629569
        }
      ],
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 1900551,
      "h": 4296867847,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296867847)
  ],
  "i": [3211271
  ],
  "d": 1835015,
  "h": 1900551
}; }
                    static get $b() { return $.$$.System.Object; }
                    static $$i;
                    static get $i() { return this.$$i ??= [ $.$sris.System.Runtime.InteropServices.Marshalling.IIUnknownDerivedDetails ]; }
                    static get $fullName() { return `System.Runtime.InteropServices.Marshalling.ComImportInteropInterfaceDetailsStrategy.ComImportDetails`; }
                }, $cls, ($v) => $cls.$_ComImportDetails = $v);
            }
            //--TRIMMABLE-BOUNDARY-END(1900551)
            
            //--TRIMMABLE-BOUNDARY-START(1966087)
            static $_IComImportAdapter;
            static get IComImportAdapter()
            {
                let $cls = $.$sris.System.Runtime.InteropServices.Marshalling.ComImportInteropInterfaceDetailsStrategy;
                return $cls.$_IComImportAdapter ??= $asm.$ncls("$sris.System.Runtime.InteropServices.Marshalling.ComImportInteropInterfaceDetailsStrategy.IComImportAdapter", ($self) => class IComImportAdapter
                {
                    //--TRIMMABLE-BOUNDARY-START(12886867975)
                    /*MethodInfo*/ static System$Runtime$InteropServices$Marshalling$ComImportInteropInterfaceDetailsStrategy$IComImportAdapter$GetRuntimeCallableWrapperMethod = null;
                    //--TRIMMABLE-BOUNDARY-END(12886867975)
                    
                    //--TRIMMABLE-BOUNDARY-START(4296933383)
                    //Static Initializer
                    static $sinit()
                    {
                        {
                            //--TRIMMABLE-BOUNDARY-START(12886867975)
                            this.System$Runtime$InteropServices$Marshalling$ComImportInteropInterfaceDetailsStrategy$IComImportAdapter$GetRuntimeCallableWrapperMethod = $.$sris.System.Runtime.InteropServices.Marshalling.ComImportInteropInterfaceDetailsStrategy.IComImportAdapter.$type.GetMethod$12("GetRuntimeCallableWrapper");
                            //--TRIMMABLE-BOUNDARY-END(12886867975)
                            
                        }
                    }
                    //--TRIMMABLE-BOUNDARY-END(4296933383)
                    
                    static $h = 1966087;
                    static $f = 0b10000000000100100;
                    static $k = 3;
                    static $$md;
                    static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8591900679),
    {
      "r": 131073,
      "n": "GetRuntimeCallableWrapper",
      "o": "System$Runtime$InteropServices$Marshalling$ComImportInteropInterfaceDetailsStrategy$IComImportAdapter$GetRuntimeCallableWrapper",
      "d": 1966087,
      "h": 8591900679,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(8591900679)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(12886867975),
    {
      "t": 116719617,
      "n": "GetRuntimeCallableWrapperMethod",
      "o": "System$Runtime$InteropServices$Marshalling$ComImportInteropInterfaceDetailsStrategy$IComImportAdapter$GetRuntimeCallableWrapperMethod",
      "d": 1966087,
      "h": 12886867975,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(12886867975)
  ],
  "d": 1835015,
  "h": 1966087
}; }
                    static get $fullName() { return `System.Runtime.InteropServices.Marshalling.ComImportInteropInterfaceDetailsStrategy.IComImportAdapter`; }
                }, $cls, ($v) => $cls.$_IComImportAdapter = $v);
            }
            //--TRIMMABLE-BOUNDARY-END(1966087)
            
            //--TRIMMABLE-BOUNDARY-START(8593211399)
            //Generated interface implemetation for System.Runtime.InteropServices.Marshalling.IIUnknownInterfaceDetailsStrategy.GetIUnknownDerivedDetails(System.RuntimeTypeHandle)
            System$Runtime$InteropServices$Marshalling$IIUnknownInterfaceDetailsStrategy$GetIUnknownDerivedDetails()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8593211399);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.GetIUnknownDerivedDetails(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(8593211399)
            
            //--TRIMMABLE-BOUNDARY-START(4298244103)
            //Generated interface implemetation for System.Runtime.InteropServices.Marshalling.IIUnknownInterfaceDetailsStrategy.GetComExposedTypeDetails(System.RuntimeTypeHandle)
            System$Runtime$InteropServices$Marshalling$IIUnknownInterfaceDetailsStrategy$GetComExposedTypeDetails()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4298244103);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.GetComExposedTypeDetails(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4298244103)
            
            //default reference type constructor overload
            $ctor$1()
            {
                super.$ctor();
                return this;
            }
            //default member initializer
            constructor()
            {
                super();
                //--TRIMMABLE-BOUNDARY-START(4296802311)
                this._forwarderInterfaceCache = new ($.$$.System.Runtime.CompilerServices.ConditionalWeakTable$$$($.$$.System.Type, $.$$.System.Type))().$ctor$1();
                //--TRIMMABLE-BOUNDARY-END(4296802311)
                
            }
            //--TRIMMABLE-BOUNDARY-START(8591769607)
            //Static Initializer
            static $sinit()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(42951507975)
                    this.Instance = new $.$sris.System.Runtime.InteropServices.Marshalling.ComImportInteropInterfaceDetailsStrategy().$ctor$1();
                    //--TRIMMABLE-BOUNDARY-END(42951507975)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(47246475271)
                    this.s_attributeBaseClassCtor = $.$$.System.Array.$ReadT1.call($.$$.System.Attribute.$type.GetConstructors$1(32/*BindingFlags.NonPublic*/ | 4/*BindingFlags.Instance*/), 0);
                    //--TRIMMABLE-BOUNDARY-END(47246475271)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(55836409863)
                    this.s_attributeUsageCtor = $.$$.System.AttributeUsageAttribute.$type.GetConstructor$4($.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$$.System.Type), [$.$$.System.AttributeTargets.$type], [-1], null));
                    //--TRIMMABLE-BOUNDARY-END(55836409863)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(51541442567)
                    this.s_attributeUsageAllowMultipleProperty = $.$$.System.AttributeUsageAttribute.$type.GetProperty$6("AllowMultiple");
                    //--TRIMMABLE-BOUNDARY-END(51541442567)
                    
                }
            }
            //--TRIMMABLE-BOUNDARY-END(8591769607)
            
            static $h = 1835015;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 131073,
  "m": [
//--TRIMMABLE-BOUNDARY-START(25771638791),
    {
      "r": 3014663,
      "p": [
        {
          "n": "type",
          "p": 160038913
        }
      ],
      "n": "GetComExposedTypeDetails",
      "d": 1835015,
      "h": 25771638791,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(25771638791),
//--TRIMMABLE-BOUNDARY-START(34361573383),
    {
      "r": 3211271,
      "p": [
        {
          "n": "type",
          "p": 160038913
        }
      ],
      "n": "GetIUnknownDerivedDetails",
      "d": 1835015,
      "h": 34361573383,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(34361573383),
//--TRIMMABLE-BOUNDARY-START(30066606087),
    {
      "r": 108331009,
      "p": [
        {
          "n": "moduleBuilder"
        }
      ],
      "n": "GetIgnoresAccessChecksToAttributeConstructor",
      "d": 1835015,
      "h": 30066606087,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(30066606087),
//--TRIMMABLE-BOUNDARY-START(21476671495),
    {
      "r": 187629569,
      "p": [
        {
          "n": "moduleBuilder"
        }
      ],
      "n": "EmitIgnoresAccessChecksToAttribute",
      "d": 1835015,
      "h": 21476671495,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(21476671495)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(42951507975),
    {
      "t": 3276807,
      "n": "Instance",
      "d": 1835015,
      "h": 42951507975,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(42951507975),
//--TRIMMABLE-BOUNDARY-START(4296802311),
    {
      "t": $.$$.System.Runtime.CompilerServices.ConditionalWeakTable$$$($.$$.System.Type, $.$$.System.Type).$h,
      "n": "_forwarderInterfaceCache",
      "d": 1835015,
      "h": 4296802311,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(4296802311),
//--TRIMMABLE-BOUNDARY-START(47246475271),
    {
      "t": 108331009,
      "n": "s_attributeBaseClassCtor",
      "d": 1835015,
      "h": 47246475271,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(47246475271),
//--TRIMMABLE-BOUNDARY-START(55836409863),
    {
      "t": 108331009,
      "n": "s_attributeUsageCtor",
      "d": 1835015,
      "h": 55836409863,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(55836409863),
//--TRIMMABLE-BOUNDARY-START(51541442567),
    {
      "t": 118751233,
      "n": "s_attributeUsageAllowMultipleProperty",
      "d": 1835015,
      "h": 51541442567,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(51541442567)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(12886736903),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 1835015,
      "h": 12886736903,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(12886736903)
  ],
  "i": [3276807
  ],
  "j": [1900551,1966087
  ],
  "h": 1835015
}; }
            static get $b() { return $.$$.System.Object; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$sris.System.Runtime.InteropServices.Marshalling.IIUnknownInterfaceDetailsStrategy ]; }
            static get $fullName() { return `System.Runtime.InteropServices.Marshalling.ComImportInteropInterfaceDetailsStrategy`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1835015)
        
        
        //--TRIMMABLE-BOUNDARY-START(1310727)
        $asm.$str("$sris.System.Runtime.InteropServices.ComTypes.STGMEDIUM", ($self) => class STGMEDIUM extends $.$$.System.ValueType
        {
            //--TRIMMABLE-BOUNDARY-START(12886212615)
            /*TYMED*/  get tymed() { return this.$getField(0, 4); }
            /*TYMED*/  set tymed(value) { this.$setField(0, 4, value); }
            //--TRIMMABLE-BOUNDARY-END(12886212615)
            
            //--TRIMMABLE-BOUNDARY-START(17181179911)
            /*IntPtr*/  get unionmember() { return this.$getField(4, 4); }
            /*IntPtr*/  set unionmember(value) { this.$setField(4, 4, value); }
            //--TRIMMABLE-BOUNDARY-END(17181179911)
            
            //--TRIMMABLE-BOUNDARY-START(8591245319)
            /*object?*/  get pUnkForRelease() { return this.$getField(8, 4); }
            /*object?*/  set pUnkForRelease(value) { this.$setField(8, 4, value); }
            //--TRIMMABLE-BOUNDARY-END(8591245319)
            
            //default value type constructor
            $ctor$2()
            {
                return this;
            }
            Clone($copy)
            {
                let copy = $copy ?? new this.constructor();
                copy.tymed = this.tymed;
                copy.unionmember = this.unionmember;
                copy.pUnkForRelease = this.pUnkForRelease;
                return copy;
            }
            //default member initializer
            constructor()
            {
                super();
                //--TRIMMABLE-BOUNDARY-START(12886212615)
                this.tymed = 0;
                //--TRIMMABLE-BOUNDARY-END(12886212615)
                
                //--TRIMMABLE-BOUNDARY-START(17181179911)
                this.unionmember = 0;
                //--TRIMMABLE-BOUNDARY-END(17181179911)
                
                //--TRIMMABLE-BOUNDARY-START(8591245319)
                this.pUnkForRelease = null;
                //--TRIMMABLE-BOUNDARY-END(8591245319)
                
            }
            static $h = 1310727;
            static $z = 12;
            static $f = 0b1010000001;
            static $k = 2;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 196609,
  "l": [
//--TRIMMABLE-BOUNDARY-START(12886212615),
    {
      "t": 1376263,
      "n": "tymed",
      "d": 1310727,
      "h": 12886212615,
      "f": 4194305
    },
//--TRIMMABLE-BOUNDARY-END(12886212615),
//--TRIMMABLE-BOUNDARY-START(17181179911),
    {
      "t": 786433,
      "n": "unionmember",
      "d": 1310727,
      "h": 17181179911,
      "f": 4194305
    },
//--TRIMMABLE-BOUNDARY-END(17181179911),
//--TRIMMABLE-BOUNDARY-START(8591245319),
    {
      "t": 131073,
      "n": "pUnkForRelease",
      "d": 1310727,
      "h": 8591245319,
      "f": 4194305,
      "a": [
        {
          "t": 143065089,
          "c": 4438032385,
          "a": [
            {
              "v": 25,
              "t": 148242433
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(8591245319)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296278023),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 1310727,
      "h": 4296278023,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296278023)
  ],
  "h": 1310727,
  "a": [
    {
      "t": 64159745,
      "c": 4359127041,
      "a": [
        {
          "v": 1,
          "t": 64225281
        }
      ]
    }
  ]
}; }
            static get $b() { return $.$$.System.ValueType; }
            static get $fullName() { return `System.Runtime.InteropServices.ComTypes.STGMEDIUM`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1310727)
        
        
        //--TRIMMABLE-BOUNDARY-START(1245191)
        $asm.$str("$sris.System.Runtime.InteropServices.ComTypes.STATDATA", ($self) => class STATDATA extends $.$$.System.ValueType
        {
            //--TRIMMABLE-BOUNDARY-START(21476081671)
            /*FORMATETC*/  get formatetc() { return this.$getField(0, 18); }
            /*FORMATETC*/  set formatetc(value) { this.$setField(0, 18, value); }
            //--TRIMMABLE-BOUNDARY-END(21476081671)
            
            //--TRIMMABLE-BOUNDARY-START(8591179783)
            /*ADVF*/  get advf() { return this.$getField(18, 4); }
            /*ADVF*/  set advf(value) { this.$setField(18, 4, value); }
            //--TRIMMABLE-BOUNDARY-END(8591179783)
            
            //--TRIMMABLE-BOUNDARY-START(12886147079)
            /*IAdviseSink*/  get advSink() { return this.$getField(22, 4); }
            /*IAdviseSink*/  set advSink(value) { this.$setField(22, 4, value); }
            //--TRIMMABLE-BOUNDARY-END(12886147079)
            
            //--TRIMMABLE-BOUNDARY-START(17181114375)
            /*int*/  get connection() { return this.$getField(26, 4); }
            /*int*/  set connection(value) { this.$setField(26, 4, value); }
            //--TRIMMABLE-BOUNDARY-END(17181114375)
            
            //default value type constructor
            $ctor$2()
            {
                return this;
            }
            Clone($copy)
            {
                let copy = $copy ?? new this.constructor();
                copy.formatetc = this.formatetc.Clone();
                copy.advf = this.advf;
                copy.advSink = this.advSink;
                copy.connection = this.connection;
                return copy;
            }
            //default member initializer
            constructor()
            {
                super();
                //--TRIMMABLE-BOUNDARY-START(21476081671)
                this.formatetc = $.$default($.$sris.System.Runtime.InteropServices.ComTypes.FORMATETC);
                //--TRIMMABLE-BOUNDARY-END(21476081671)
                
                //--TRIMMABLE-BOUNDARY-START(8591179783)
                this.advf = 0;
                //--TRIMMABLE-BOUNDARY-END(8591179783)
                
                //--TRIMMABLE-BOUNDARY-START(12886147079)
                this.advSink = null;
                //--TRIMMABLE-BOUNDARY-END(12886147079)
                
                //--TRIMMABLE-BOUNDARY-START(17181114375)
                this.connection = 0;
                //--TRIMMABLE-BOUNDARY-END(17181114375)
                
            }
            static $h = 1245191;
            static $z = 30;
            static $f = 0b1010000001;
            static $k = 2;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 196609,
  "l": [
//--TRIMMABLE-BOUNDARY-START(21476081671),
    {
      "t": 917511,
      "n": "formatetc",
      "d": 1245191,
      "h": 21476081671,
      "f": 4194305
    },
//--TRIMMABLE-BOUNDARY-END(21476081671),
//--TRIMMABLE-BOUNDARY-START(8591179783),
    {
      "t": 720903,
      "n": "advf",
      "d": 1245191,
      "h": 8591179783,
      "f": 4194305
    },
//--TRIMMABLE-BOUNDARY-END(8591179783),
//--TRIMMABLE-BOUNDARY-START(12886147079),
    {
      "t": 983047,
      "n": "advSink",
      "d": 1245191,
      "h": 12886147079,
      "f": 4194305
    },
//--TRIMMABLE-BOUNDARY-END(12886147079),
//--TRIMMABLE-BOUNDARY-START(17181114375),
    {
      "t": 655361,
      "n": "connection",
      "d": 1245191,
      "h": 17181114375,
      "f": 4194305
    },
//--TRIMMABLE-BOUNDARY-END(17181114375)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296212487),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 1245191,
      "h": 4296212487,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296212487)
  ],
  "h": 1245191,
  "a": [
    {
      "t": 64159745,
      "c": 4359127041,
      "a": [
        {
          "v": 1,
          "t": 64225281
        }
      ]
    }
  ]
}; }
            static get $b() { return $.$$.System.ValueType; }
            static get $fullName() { return `System.Runtime.InteropServices.ComTypes.STATDATA`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1245191)
        
        
        //--TRIMMABLE-BOUNDARY-START(917511)
        $asm.$str("$sris.System.Runtime.InteropServices.ComTypes.FORMATETC", ($self) => class FORMATETC extends $.$$.System.ValueType
        {
            //--TRIMMABLE-BOUNDARY-START(8590852103)
            /*short*/  get cfFormat() { return this.$getField(0, $.$$.System.Int16); }
            /*short*/  set cfFormat(value) { this.$setField(0, $.$$.System.Int16, value); }
            //--TRIMMABLE-BOUNDARY-END(8590852103)
            
            //--TRIMMABLE-BOUNDARY-START(21475753991)
            /*IntPtr*/  get ptd() { return this.$getField(2, $.$$.System.IntPtr); }
            /*IntPtr*/  set ptd(value) { this.$setField(2, $.$$.System.IntPtr, value); }
            //--TRIMMABLE-BOUNDARY-END(21475753991)
            
            //--TRIMMABLE-BOUNDARY-START(12885819399)
            /*DVASPECT*/  get dwAspect() { return this.$getField(6, $.$sris.System.Runtime.InteropServices.ComTypes.DVASPECT); }
            /*DVASPECT*/  set dwAspect(value) { this.$setField(6, $.$sris.System.Runtime.InteropServices.ComTypes.DVASPECT, value); }
            //--TRIMMABLE-BOUNDARY-END(12885819399)
            
            //--TRIMMABLE-BOUNDARY-START(17180786695)
            /*int*/  get lindex() { return this.$getField(10, $.$$.System.Int32); }
            /*int*/  set lindex(value) { this.$setField(10, $.$$.System.Int32, value); }
            //--TRIMMABLE-BOUNDARY-END(17180786695)
            
            //--TRIMMABLE-BOUNDARY-START(25770721287)
            /*TYMED*/  get tymed() { return this.$getField(14, $.$sris.System.Runtime.InteropServices.ComTypes.TYMED); }
            /*TYMED*/  set tymed(value) { this.$setField(14, $.$sris.System.Runtime.InteropServices.ComTypes.TYMED, value); }
            //--TRIMMABLE-BOUNDARY-END(25770721287)
            
            //default value type constructor
            $ctor$2()
            {
                return this;
            }
            Clone($copy)
            {
                let copy = $copy ?? new this.constructor();
                copy.cfFormat = this.cfFormat;
                copy.ptd = this.ptd;
                copy.dwAspect = this.dwAspect;
                copy.lindex = this.lindex;
                copy.tymed = this.tymed;
                return copy;
            }
            //default member initializer
            constructor()
            {
                super();
                //--TRIMMABLE-BOUNDARY-START(8590852103)
                this.cfFormat = 0;
                //--TRIMMABLE-BOUNDARY-END(8590852103)
                
                //--TRIMMABLE-BOUNDARY-START(21475753991)
                this.ptd = 0;
                //--TRIMMABLE-BOUNDARY-END(21475753991)
                
                //--TRIMMABLE-BOUNDARY-START(12885819399)
                this.dwAspect = 0;
                //--TRIMMABLE-BOUNDARY-END(12885819399)
                
                //--TRIMMABLE-BOUNDARY-START(17180786695)
                this.lindex = 0;
                //--TRIMMABLE-BOUNDARY-END(17180786695)
                
                //--TRIMMABLE-BOUNDARY-START(25770721287)
                this.tymed = 0;
                //--TRIMMABLE-BOUNDARY-END(25770721287)
                
            }
            static $h = 917511;
            static $z = 18;
            static $f = 0b10000000000001010000001;
            static $k = 2;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 196609,
  "l": [
//--TRIMMABLE-BOUNDARY-START(8590852103),
    {
      "t": 524289,
      "n": "cfFormat",
      "d": 917511,
      "h": 8590852103,
      "f": 4194305,
      "a": [
        {
          "t": 143065089,
          "c": 4438032385,
          "a": [
            {
              "v": 6,
              "t": 148242433
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(8590852103),
//--TRIMMABLE-BOUNDARY-START(21475753991),
    {
      "t": 786433,
      "n": "ptd",
      "d": 917511,
      "h": 21475753991,
      "f": 4194305
    },
//--TRIMMABLE-BOUNDARY-END(21475753991),
//--TRIMMABLE-BOUNDARY-START(12885819399),
    {
      "t": 851975,
      "n": "dwAspect",
      "d": 917511,
      "h": 12885819399,
      "f": 4194305,
      "a": [
        {
          "t": 143065089,
          "c": 4438032385,
          "a": [
            {
              "v": 8,
              "t": 148242433
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(12885819399),
//--TRIMMABLE-BOUNDARY-START(17180786695),
    {
      "t": 655361,
      "n": "lindex",
      "d": 917511,
      "h": 17180786695,
      "f": 4194305
    },
//--TRIMMABLE-BOUNDARY-END(17180786695),
//--TRIMMABLE-BOUNDARY-START(25770721287),
    {
      "t": 1376263,
      "n": "tymed",
      "d": 917511,
      "h": 25770721287,
      "f": 4194305,
      "a": [
        {
          "t": 143065089,
          "c": 4438032385,
          "a": [
            {
              "v": 8,
              "t": 148242433
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(25770721287)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295884807),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 917511,
      "h": 4295884807,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295884807)
  ],
  "h": 917511,
  "a": [
    {
      "t": 64159745,
      "c": 4359127041,
      "a": [
        {
          "v": 1,
          "t": 64225281
        }
      ]
    }
  ]
}; }
            static get $b() { return $.$$.System.ValueType; }
            static get $fullName() { return `System.Runtime.InteropServices.ComTypes.FORMATETC`; }
        });
        //--TRIMMABLE-BOUNDARY-END(917511)
        
        
        //--TRIMMABLE-BOUNDARY-START(589831)
        $asm.$cls("$sris.System.Runtime.InteropServices.ComConversionLossAttribute", ($self) => class ComConversionLossAttribute extends $.$$.System.Attribute
        {
            //default reference type constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                return this;
            }
            static $h = 589831;
            static $f = 0b10010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 45219841,
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295557127),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 589831,
      "h": 4295557127,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295557127)
  ],
  "h": 589831,
  "a": [
    {
      "t": 45350913,
      "c": 21520187393,
      "a": [
        {
          "v": 32767,
          "t": 45285377
        }
      ],
      "n": [
        {
          "n": "Inherited",
          "v": false,
          "t": 262145
        }
      ]
    }
  ]
}; }
            static get $b() { return $.$$.System.Attribute; }
            static get $fullName() { return `System.Runtime.InteropServices.ComConversionLossAttribute`; }
        });
        //--TRIMMABLE-BOUNDARY-END(589831)
        
        
        //--TRIMMABLE-BOUNDARY-START(393223)
        $asm.$cls("$sris.System.Runtime.InteropServices.ComAliasNameAttribute", ($self) => class ComAliasNameAttribute extends $.$$.System.Attribute
        {
            //--TRIMMABLE-BOUNDARY-START(4295360519)
            $ctor$2(/*string*/ alias)
            {
                super.$ctor$1();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4295360519);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this.Value = alias;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295360519)
            
            //--TRIMMABLE-BOUNDARY-START(21475229703)
            /*string*/ Value = null;
            //--TRIMMABLE-BOUNDARY-END(21475229703)
            
            static $h = 393223;
            static $f = 0b10010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 45219841,
  "p": [
//--TRIMMABLE-BOUNDARY-START(21475229703),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 17180262407,
        "f": 50331649
      },
      "n": "Value",
      "d": 393223,
      "h": 21475229703,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(21475229703)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295360519),
    {
      "p": [
        {
          "n": "alias",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 393223,
      "h": 4295360519,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295360519)
  ],
  "h": 393223,
  "a": [
    {
      "t": 45350913,
      "c": 21520187393,
      "a": [
        {
          "v": 10624,
          "t": 45285377
        }
      ],
      "n": [
        {
          "n": "Inherited",
          "v": false,
          "t": 262145
        }
      ]
    }
  ]
}; }
            static get $b() { return $.$$.System.Attribute; }
            static get $fullName() { return `System.Runtime.InteropServices.ComAliasNameAttribute`; }
        });
        //--TRIMMABLE-BOUNDARY-END(393223)
        
        
        //--TRIMMABLE-BOUNDARY-START(327687)
        $asm.$cls("$sris.System.Runtime.InteropServices.AutomationProxyAttribute", ($self) => class AutomationProxyAttribute extends $.$$.System.Attribute
        {
            //--TRIMMABLE-BOUNDARY-START(4295294983)
            $ctor$2(/*bool*/ val)
            {
                super.$ctor$1();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4295294983);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this.Value = val;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295294983)
            
            //--TRIMMABLE-BOUNDARY-START(21475164167)
            /*bool*/ Value = false;
            //--TRIMMABLE-BOUNDARY-END(21475164167)
            
            static $h = 327687;
            static $f = 0b10010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 45219841,
  "p": [
//--TRIMMABLE-BOUNDARY-START(21475164167),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 17180196871,
        "f": 50331649
      },
      "n": "Value",
      "d": 327687,
      "h": 21475164167,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(21475164167)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295294983),
    {
      "p": [
        {
          "n": "val",
          "p": 262145
        }
      ],
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 327687,
      "h": 4295294983,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295294983)
  ],
  "h": 327687,
  "a": [
    {
      "t": 45350913,
      "c": 21520187393,
      "a": [
        {
          "v": 1029,
          "t": 45285377
        }
      ],
      "n": [
        {
          "n": "Inherited",
          "v": false,
          "t": 262145
        }
      ]
    }
  ]
}; }
            static get $b() { return $.$$.System.Attribute; }
            static get $fullName() { return `System.Runtime.InteropServices.AutomationProxyAttribute`; }
        });
        //--TRIMMABLE-BOUNDARY-END(327687)
        
        
        //--TRIMMABLE-BOUNDARY-START(1703943)
        $asm.$cls("$sris.System.Runtime.InteropServices.ManagedToNativeComInteropStubAttribute", ($self) => class ManagedToNativeComInteropStubAttribute extends $.$$.System.Attribute
        {
            //--TRIMMABLE-BOUNDARY-START(4296671239)
            $ctor$2(/*Type*/ classType, /*string*/ methodName)
            {
                super.$ctor$1();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4296671239);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this.ClassType = classType;
                    this.MethodName = methodName;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296671239)
            
            //--TRIMMABLE-BOUNDARY-START(17181573127)
            /*Type*/ ClassType = null;
            //--TRIMMABLE-BOUNDARY-END(17181573127)
            
            //--TRIMMABLE-BOUNDARY-START(38656409607)
            /*string*/ MethodName = null;
            //--TRIMMABLE-BOUNDARY-END(38656409607)
            
            static $h = 1703943;
            static $f = 0b10010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 45219841,
  "p": [
//--TRIMMABLE-BOUNDARY-START(17181573127),
    {
      "p": 187629569,
      "g": {
        "r": 0,
        "d": 0,
        "h": 25771507719,
        "f": 50331649
      },
      "n": "ClassType",
      "d": 1703943,
      "h": 17181573127,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(17181573127),
//--TRIMMABLE-BOUNDARY-START(38656409607),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 34361442311,
        "f": 50331649
      },
      "n": "MethodName",
      "d": 1703943,
      "h": 38656409607,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(38656409607)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296671239),
    {
      "p": [
        {
          "n": "classType",
          "p": 187629569
        },
        {
          "n": "methodName",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 1703943,
      "h": 4296671239,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296671239)
  ],
  "h": 1703943,
  "a": [
    {
      "t": 45350913,
      "c": 21520187393,
      "a": [
        {
          "v": 64,
          "t": 45285377
        }
      ],
      "n": [
        {
          "n": "Inherited",
          "v": false,
          "t": 262145
        },
        {
          "n": "AllowMultiple",
          "v": false,
          "t": 262145
        }
      ]
    }
  ]
}; }
            static get $b() { return $.$$.System.Attribute; }
            static get $fullName() { return `System.Runtime.InteropServices.ManagedToNativeComInteropStubAttribute`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1703943)
        
        
        //--TRIMMABLE-BOUNDARY-START(655367)
        $asm.$cls("$sris.System.Runtime.InteropServices.ComRegisterFunctionAttribute", ($self) => class ComRegisterFunctionAttribute extends $.$$.System.Attribute
        {
            //default reference type constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                return this;
            }
            static $h = 655367;
            static $f = 0b10010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 45219841,
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295622663),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 655367,
      "h": 4295622663,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295622663)
  ],
  "h": 655367,
  "a": [
    {
      "t": 45350913,
      "c": 21520187393,
      "a": [
        {
          "v": 64,
          "t": 45285377
        }
      ],
      "n": [
        {
          "n": "Inherited",
          "v": false,
          "t": 262145
        }
      ]
    }
  ]
}; }
            static get $b() { return $.$$.System.Attribute; }
            static get $fullName() { return `System.Runtime.InteropServices.ComRegisterFunctionAttribute`; }
        });
        //--TRIMMABLE-BOUNDARY-END(655367)
        
        
        //--TRIMMABLE-BOUNDARY-START(1441799)
        $asm.$cls("$sris.System.Runtime.InteropServices.ComUnregisterFunctionAttribute", ($self) => class ComUnregisterFunctionAttribute extends $.$$.System.Attribute
        {
            //default reference type constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                return this;
            }
            static $h = 1441799;
            static $f = 0b10010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 45219841,
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296409095),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 1441799,
      "h": 4296409095,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296409095)
  ],
  "h": 1441799,
  "a": [
    {
      "t": 45350913,
      "c": 21520187393,
      "a": [
        {
          "v": 64,
          "t": 45285377
        }
      ],
      "n": [
        {
          "n": "Inherited",
          "v": false,
          "t": 262145
        }
      ]
    }
  ]
}; }
            static get $b() { return $.$$.System.Attribute; }
            static get $fullName() { return `System.Runtime.InteropServices.ComUnregisterFunctionAttribute`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1441799)
        
        
        //--TRIMMABLE-BOUNDARY-START(524295)
        $asm.$cls("$sris.System.Runtime.InteropServices.ComCompatibleVersionAttribute", ($self) => class ComCompatibleVersionAttribute extends $.$$.System.Attribute
        {
            //--TRIMMABLE-BOUNDARY-START(4295491591)
            $ctor$2(/*int*/ major, /*int*/ minor, /*int*/ build, /*int*/ revision)
            {
                super.$ctor$1();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4295491591);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this.MajorVersion = major;
                    this.MinorVersion = minor;
                    this.BuildNumber = build;
                    this.RevisionNumber = revision;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295491591)
            
            //--TRIMMABLE-BOUNDARY-START(64425033735)
            /*int*/ MajorVersion = 0;
            //--TRIMMABLE-BOUNDARY-END(64425033735)
            
            //--TRIMMABLE-BOUNDARY-START(68720001031)
            /*int*/ MinorVersion = 0;
            //--TRIMMABLE-BOUNDARY-END(68720001031)
            
            //--TRIMMABLE-BOUNDARY-START(25770328071)
            /*int*/ BuildNumber = 0;
            //--TRIMMABLE-BOUNDARY-END(25770328071)
            
            //--TRIMMABLE-BOUNDARY-START(73014968327)
            /*int*/ RevisionNumber = 0;
            //--TRIMMABLE-BOUNDARY-END(73014968327)
            
            static $h = 524295;
            static $f = 0b10010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 45219841,
  "p": [
//--TRIMMABLE-BOUNDARY-START(64425033735),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 42950197255,
        "f": 50331649
      },
      "n": "MajorVersion",
      "d": 524295,
      "h": 64425033735,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(64425033735),
//--TRIMMABLE-BOUNDARY-START(68720001031),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 51540131847,
        "f": 50331649
      },
      "n": "MinorVersion",
      "d": 524295,
      "h": 68720001031,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(68720001031),
//--TRIMMABLE-BOUNDARY-START(25770328071),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 34360262663,
        "f": 50331649
      },
      "n": "BuildNumber",
      "d": 524295,
      "h": 25770328071,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(25770328071),
//--TRIMMABLE-BOUNDARY-START(73014968327),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 60130066439,
        "f": 50331649
      },
      "n": "RevisionNumber",
      "d": 524295,
      "h": 73014968327,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(73014968327)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295491591),
    {
      "p": [
        {
          "n": "major",
          "p": 655361
        },
        {
          "n": "minor",
          "p": 655361
        },
        {
          "n": "build",
          "p": 655361
        },
        {
          "n": "revision",
          "p": 655361
        }
      ],
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 524295,
      "h": 4295491591,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295491591)
  ],
  "h": 524295,
  "a": [
    {
      "t": 45350913,
      "c": 21520187393,
      "a": [
        {
          "v": 1,
          "t": 45285377
        }
      ],
      "n": [
        {
          "n": "Inherited",
          "v": false,
          "t": 262145
        }
      ]
    }
  ]
}; }
            static get $b() { return $.$$.System.Attribute; }
            static get $fullName() { return `System.Runtime.InteropServices.ComCompatibleVersionAttribute`; }
        });
        //--TRIMMABLE-BOUNDARY-END(524295)
        
        
        //--TRIMMABLE-BOUNDARY-START(4194311)
        $asm.$cls("$sris.System.Runtime.InteropServices.TypeLibImportClassAttribute", ($self) => class TypeLibImportClassAttribute extends $.$$.System.Attribute
        {
            //--TRIMMABLE-BOUNDARY-START(4299161607)
            $ctor$2(/*Type*/ importClass)
            {
                super.$ctor$1();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4299161607);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this.Value = $.$$.System.Type.ToString.call(importClass);
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4299161607)
            
            //--TRIMMABLE-BOUNDARY-START(21479030791)
            /*string*/ Value = null;
            //--TRIMMABLE-BOUNDARY-END(21479030791)
            
            static $h = 4194311;
            static $f = 0b10010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 45219841,
  "p": [
//--TRIMMABLE-BOUNDARY-START(21479030791),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 17184063495,
        "f": 50331649
      },
      "n": "Value",
      "d": 4194311,
      "h": 21479030791,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(21479030791)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4299161607),
    {
      "p": [
        {
          "n": "importClass",
          "p": 187629569
        }
      ],
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 4194311,
      "h": 4299161607,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4299161607)
  ],
  "h": 4194311,
  "a": [
    {
      "t": 45350913,
      "c": 21520187393,
      "a": [
        {
          "v": 1024,
          "t": 45285377
        }
      ],
      "n": [
        {
          "n": "Inherited",
          "v": false,
          "t": 262145
        }
      ]
    }
  ]
}; }
            static get $b() { return $.$$.System.Attribute; }
            static get $fullName() { return `System.Runtime.InteropServices.TypeLibImportClassAttribute`; }
        });
        //--TRIMMABLE-BOUNDARY-END(4194311)
        
        
        //--TRIMMABLE-BOUNDARY-START(4063239)
        $asm.$cls("$sris.System.Runtime.InteropServices.TypeLibFuncAttribute", ($self) => class TypeLibFuncAttribute extends $.$$.System.Attribute
        {
            //--TRIMMABLE-BOUNDARY-START(4299030535)
            $ctor$3(/*TypeLibFuncFlags*/ flags)
            {
                super.$ctor$1();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4299030535);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this.Value = flags;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4299030535)
            
            //--TRIMMABLE-BOUNDARY-START(8593997831)
            $ctor$2(/*short*/ flags)
            {
                super.$ctor$1();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(8593997831);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this.Value = $.$cast(flags, $.$sris.System.Runtime.InteropServices.TypeLibFuncFlags);
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(8593997831)
            
            //--TRIMMABLE-BOUNDARY-START(25773867015)
            /*TypeLibFuncFlags*/ Value = 0;
            //--TRIMMABLE-BOUNDARY-END(25773867015)
            
            static $h = 4063239;
            static $f = 0b10010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 45219841,
  "p": [
//--TRIMMABLE-BOUNDARY-START(25773867015),
    {
      "p": 4128775,
      "g": {
        "r": 0,
        "d": 0,
        "h": 21478899719,
        "f": 50331649
      },
      "n": "Value",
      "d": 4063239,
      "h": 25773867015,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(25773867015)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4299030535),
    {
      "p": [
        {
          "n": "flags",
          "p": 4128775
        }
      ],
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 4063239,
      "h": 4299030535,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4299030535),
//--TRIMMABLE-BOUNDARY-START(8593997831),
    {
      "p": [
        {
          "n": "flags",
          "p": 524289
        }
      ],
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 4063239,
      "h": 8593997831,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8593997831)
  ],
  "h": 4063239,
  "a": [
    {
      "t": 45350913,
      "c": 21520187393,
      "a": [
        {
          "v": 64,
          "t": 45285377
        }
      ],
      "n": [
        {
          "n": "Inherited",
          "v": false,
          "t": 262145
        }
      ]
    }
  ]
}; }
            static get $b() { return $.$$.System.Attribute; }
            static get $fullName() { return `System.Runtime.InteropServices.TypeLibFuncAttribute`; }
        });
        //--TRIMMABLE-BOUNDARY-END(4063239)
        
        
        //--TRIMMABLE-BOUNDARY-START(4259847)
        $asm.$cls("$sris.System.Runtime.InteropServices.TypeLibTypeAttribute", ($self) => class TypeLibTypeAttribute extends $.$$.System.Attribute
        {
            //--TRIMMABLE-BOUNDARY-START(4299227143)
            $ctor$3(/*TypeLibTypeFlags*/ flags)
            {
                super.$ctor$1();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4299227143);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this.Value = flags;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4299227143)
            
            //--TRIMMABLE-BOUNDARY-START(8594194439)
            $ctor$2(/*short*/ flags)
            {
                super.$ctor$1();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(8594194439);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this.Value = $.$cast(flags, $.$sris.System.Runtime.InteropServices.TypeLibTypeFlags);
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(8594194439)
            
            //--TRIMMABLE-BOUNDARY-START(25774063623)
            /*TypeLibTypeFlags*/ Value = 0;
            //--TRIMMABLE-BOUNDARY-END(25774063623)
            
            static $h = 4259847;
            static $f = 0b10010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 45219841,
  "p": [
//--TRIMMABLE-BOUNDARY-START(25774063623),
    {
      "p": 4325383,
      "g": {
        "r": 0,
        "d": 0,
        "h": 21479096327,
        "f": 50331649
      },
      "n": "Value",
      "d": 4259847,
      "h": 25774063623,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(25774063623)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4299227143),
    {
      "p": [
        {
          "n": "flags",
          "p": 4325383
        }
      ],
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 4259847,
      "h": 4299227143,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4299227143),
//--TRIMMABLE-BOUNDARY-START(8594194439),
    {
      "p": [
        {
          "n": "flags",
          "p": 524289
        }
      ],
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 4259847,
      "h": 8594194439,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8594194439)
  ],
  "h": 4259847,
  "a": [
    {
      "t": 45350913,
      "c": 21520187393,
      "a": [
        {
          "v": 1052,
          "t": 45285377
        }
      ],
      "n": [
        {
          "n": "Inherited",
          "v": false,
          "t": 262145
        }
      ]
    }
  ]
}; }
            static get $b() { return $.$$.System.Attribute; }
            static get $fullName() { return `System.Runtime.InteropServices.TypeLibTypeAttribute`; }
        });
        //--TRIMMABLE-BOUNDARY-END(4259847)
        
        
        //--TRIMMABLE-BOUNDARY-START(4390919)
        $asm.$cls("$sris.System.Runtime.InteropServices.TypeLibVarAttribute", ($self) => class TypeLibVarAttribute extends $.$$.System.Attribute
        {
            //--TRIMMABLE-BOUNDARY-START(4299358215)
            $ctor$3(/*TypeLibVarFlags*/ flags)
            {
                super.$ctor$1();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4299358215);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this.Value = flags;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4299358215)
            
            //--TRIMMABLE-BOUNDARY-START(8594325511)
            $ctor$2(/*short*/ flags)
            {
                super.$ctor$1();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(8594325511);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this.Value = $.$cast(flags, $.$sris.System.Runtime.InteropServices.TypeLibVarFlags);
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(8594325511)
            
            //--TRIMMABLE-BOUNDARY-START(25774194695)
            /*TypeLibVarFlags*/ Value = 0;
            //--TRIMMABLE-BOUNDARY-END(25774194695)
            
            static $h = 4390919;
            static $f = 0b10010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 45219841,
  "p": [
//--TRIMMABLE-BOUNDARY-START(25774194695),
    {
      "p": 4456455,
      "g": {
        "r": 0,
        "d": 0,
        "h": 21479227399,
        "f": 50331649
      },
      "n": "Value",
      "d": 4390919,
      "h": 25774194695,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(25774194695)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4299358215),
    {
      "p": [
        {
          "n": "flags",
          "p": 4456455
        }
      ],
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 4390919,
      "h": 4299358215,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4299358215),
//--TRIMMABLE-BOUNDARY-START(8594325511),
    {
      "p": [
        {
          "n": "flags",
          "p": 524289
        }
      ],
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 4390919,
      "h": 8594325511,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8594325511)
  ],
  "h": 4390919,
  "a": [
    {
      "t": 45350913,
      "c": 21520187393,
      "a": [
        {
          "v": 256,
          "t": 45285377
        }
      ],
      "n": [
        {
          "n": "Inherited",
          "v": false,
          "t": 262145
        }
      ]
    }
  ]
}; }
            static get $b() { return $.$$.System.Attribute; }
            static get $fullName() { return `System.Runtime.InteropServices.TypeLibVarAttribute`; }
        });
        //--TRIMMABLE-BOUNDARY-END(4390919)
        
        
        //--TRIMMABLE-BOUNDARY-START(2883591)
        $asm.$cls("$sris.System.Runtime.InteropServices.Marshalling.GeneratedComInterfaceAttribute", ($self) => class GeneratedComInterfaceAttribute extends $.$$.System.Attribute
        {
            //--TRIMMABLE-BOUNDARY-START(64427393031)
            /*ComInterfaceOptions*/ Options = 0;
            //--TRIMMABLE-BOUNDARY-END(64427393031)
            
            //--TRIMMABLE-BOUNDARY-START(103082098695)
            /*StringMarshalling*/ StringMarshalling = 0;
            //--TRIMMABLE-BOUNDARY-END(103082098695)
            
            //--TRIMMABLE-BOUNDARY-START(107377065991)
            /*Type?*/ StringMarshallingCustomType = null;
            //--TRIMMABLE-BOUNDARY-END(107377065991)
            
            //--TRIMMABLE-BOUNDARY-START(25772687367)
            /*Type?*/ ExceptionToUnmanagedMarshaller = null;
            //--TRIMMABLE-BOUNDARY-END(25772687367)
            
            //default reference type constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                return this;
            }
            //default member initializer
            constructor()
            {
                super();
                this.Options = 3;
            }
            static $h = 2883591;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 45219841,
  "p": [
//--TRIMMABLE-BOUNDARY-START(64427393031),
    {
      "p": 2097159,
      "g": {
        "r": 0,
        "d": 0,
        "h": 42952556551,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 81607262215,
        "f": 83886081
      },
      "n": "Options",
      "d": 2883591,
      "h": 64427393031,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(64427393031),
//--TRIMMABLE-BOUNDARY-START(103082098695),
    {
      "p": 147193857,
      "g": {
        "r": 0,
        "d": 0,
        "h": 51542491143,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 90197196807,
        "f": 83886081
      },
      "n": "StringMarshalling",
      "d": 2883591,
      "h": 103082098695,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(103082098695),
//--TRIMMABLE-BOUNDARY-START(107377065991),
    {
      "p": 187629569,
      "g": {
        "r": 0,
        "d": 0,
        "h": 60132425735,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 98787131399,
        "f": 83886081
      },
      "n": "StringMarshallingCustomType",
      "d": 2883591,
      "h": 107377065991,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(107377065991),
//--TRIMMABLE-BOUNDARY-START(25772687367),
    {
      "p": 187629569,
      "g": {
        "r": 0,
        "d": 0,
        "h": 34362621959,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 73017327623,
        "f": 83886081
      },
      "n": "ExceptionToUnmanagedMarshaller",
      "d": 2883591,
      "h": 25772687367,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(25772687367)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4297850887),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 2883591,
      "h": 4297850887,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4297850887)
  ],
  "h": 2883591,
  "a": [
    {
      "t": 45350913,
      "c": 21520187393,
      "a": [
        {
          "v": 1024,
          "t": 45285377
        }
      ]
    }
  ]
}; }
            static get $b() { return $.$$.System.Attribute; }
            static get $fullName() { return `System.Runtime.InteropServices.Marshalling.GeneratedComInterfaceAttribute`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2883591)
        
        
        //--TRIMMABLE-BOUNDARY-START(2818055)
        $asm.$cls("$sris.System.Runtime.InteropServices.Marshalling.GeneratedComClassAttribute", ($self) => class GeneratedComClassAttribute extends $.$$.System.Attribute
        {
            //default reference type constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                return this;
            }
            static $h = 2818055;
            static $f = 0b10010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 45219841,
  "c": [
//--TRIMMABLE-BOUNDARY-START(4297785351),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 2818055,
      "h": 4297785351,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4297785351)
  ],
  "h": 2818055,
  "a": [
    {
      "t": 45350913,
      "c": 21520187393,
      "a": [
        {
          "v": 4,
          "t": 45285377
        }
      ]
    }
  ]
}; }
            static get $b() { return $.$$.System.Attribute; }
            static get $fullName() { return `System.Runtime.InteropServices.Marshalling.GeneratedComClassAttribute`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2818055)
        
        
        //--TRIMMABLE-BOUNDARY-START(3735559)
        $asm.$str("$sris.System.Runtime.InteropServices.Marshalling.VirtualMethodTableInfo", ($self) => class VirtualMethodTableInfo extends $.$$.System.ValueType
        {
            //--TRIMMABLE-BOUNDARY-START(4298702855)
            $ctor$3(/*void**/ thisPointer, /*void***/ virtualMethodTable)
            {
                super.$ctor$1();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4298702855);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this.ThisPointer = thisPointer;
                    this.VirtualMethodTable = virtualMethodTable;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4298702855)
            
            //--TRIMMABLE-BOUNDARY-START(42953408519)
            /*void**/ ThisPointer;
            //--TRIMMABLE-BOUNDARY-END(42953408519)
            
            //--TRIMMABLE-BOUNDARY-START(47248375815)
            /*void***/ VirtualMethodTable;
            //--TRIMMABLE-BOUNDARY-END(47248375815)
            
            //--TRIMMABLE-BOUNDARY-START(21478572039)
            /*void */ Deconstruct(/*out void**/ thisPointer, /*out void***/ virtualMethodTable)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21478572039);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                thisPointer.$v = this.ThisPointer;
                virtualMethodTable.$v = this.VirtualMethodTable;
            }
            //--TRIMMABLE-BOUNDARY-END(21478572039)
            
            //default value type constructor
            $ctor$2()
            {
                return this;
            }
            Clone($copy)
            {
                let copy = $copy ?? new this.constructor();
                copy.ThisPointer = this.ThisPointer.Clone();
                copy.VirtualMethodTable = this.VirtualMethodTable.Clone();
                return copy;
            }
            //default member initializer
            constructor()
            {
                super();
                this.ThisPointer = $.$default($.$typePointer($.$$.System.Void));
                this.VirtualMethodTable = $.$default($.$typePointer($.$typePointer($.$$.System.Void)));
            }
            static $h = 3735559;
            static $z = 8;
            static $f = 0b1010000001;
            static $k = 2;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 196609,
  "p": [
//--TRIMMABLE-BOUNDARY-START(42953408519),
    {
      "p": $.$typePointer($.$$.System.Void).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 30068506631,
        "f": 50331649
      },
      "n": "ThisPointer",
      "d": 3735559,
      "h": 42953408519,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(42953408519),
//--TRIMMABLE-BOUNDARY-START(47248375815),
    {
      "p": $.$typePointer($.$typePointer($.$$.System.Void)).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 38658441223,
        "f": 50331649
      },
      "n": "VirtualMethodTable",
      "d": 3735559,
      "h": 47248375815,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(47248375815)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(21478572039),
    {
      "r": 65537,
      "p": [
        {
          "n": "thisPointer",
          "p": $.$typePointer($.$$.System.Void).$h,
          "f": 2
        },
        {
          "n": "virtualMethodTable",
          "p": $.$typePointer($.$typePointer($.$$.System.Void)).$h,
          "f": 2
        }
      ],
      "n": "Deconstruct",
      "d": 3735559,
      "h": 21478572039,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(21478572039)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4298702855),
    {
      "p": [
        {
          "n": "thisPointer",
          "p": $.$typePointer($.$$.System.Void).$h
        },
        {
          "n": "virtualMethodTable",
          "p": $.$typePointer($.$typePointer($.$$.System.Void)).$h
        }
      ],
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 3735559,
      "h": 4298702855,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4298702855),
//--TRIMMABLE-BOUNDARY-START(8593670151),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 3735559,
      "h": 8593670151,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8593670151)
  ],
  "h": 3735559,
  "a": [
    {
      "t": 54132737,
      "c": 8644067329,
      "a": [
        {
          "v": false,
          "t": 262145
        }
      ]
    }
  ]
}; }
            static get $b() { return $.$$.System.ValueType; }
            static get $fullName() { return `System.Runtime.InteropServices.Marshalling.VirtualMethodTableInfo`; }
        });
        //--TRIMMABLE-BOUNDARY-END(3735559)
        
        
        //--TRIMMABLE-BOUNDARY-START(4521991)
        $asm.$cls("$sris.System.Runtime.InteropServices.TypeLibVersionAttribute", ($self) => class TypeLibVersionAttribute extends $.$$.System.Attribute
        {
            //--TRIMMABLE-BOUNDARY-START(4299489287)
            $ctor$2(/*int*/ major, /*int*/ minor)
            {
                super.$ctor$1();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4299489287);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this.MajorVersion = major;
                    this.MinorVersion = minor;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4299489287)
            
            //--TRIMMABLE-BOUNDARY-START(34364260359)
            /*int*/ MajorVersion = 0;
            //--TRIMMABLE-BOUNDARY-END(34364260359)
            
            //--TRIMMABLE-BOUNDARY-START(38659227655)
            /*int*/ MinorVersion = 0;
            //--TRIMMABLE-BOUNDARY-END(38659227655)
            
            static $h = 4521991;
            static $f = 0b10010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 45219841,
  "p": [
//--TRIMMABLE-BOUNDARY-START(34364260359),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 21479358471,
        "f": 50331649
      },
      "n": "MajorVersion",
      "d": 4521991,
      "h": 34364260359,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(34364260359),
//--TRIMMABLE-BOUNDARY-START(38659227655),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 30069293063,
        "f": 50331649
      },
      "n": "MinorVersion",
      "d": 4521991,
      "h": 38659227655,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(38659227655)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4299489287),
    {
      "p": [
        {
          "n": "major",
          "p": 655361
        },
        {
          "n": "minor",
          "p": 655361
        }
      ],
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 4521991,
      "h": 4299489287,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4299489287)
  ],
  "h": 4521991,
  "a": [
    {
      "t": 45350913,
      "c": 21520187393,
      "a": [
        {
          "v": 1,
          "t": 45285377
        }
      ],
      "n": [
        {
          "n": "Inherited",
          "v": false,
          "t": 262145
        }
      ]
    }
  ]
}; }
            static get $b() { return $.$$.System.Attribute; }
            static get $fullName() { return `System.Runtime.InteropServices.TypeLibVersionAttribute`; }
        });
        //--TRIMMABLE-BOUNDARY-END(4521991)
        
        
        //--TRIMMABLE-BOUNDARY-START(3801095)
        $asm.$cls("$sris.System.Runtime.InteropServices.PrimaryInteropAssemblyAttribute", ($self) => class PrimaryInteropAssemblyAttribute extends $.$$.System.Attribute
        {
            //--TRIMMABLE-BOUNDARY-START(4298768391)
            $ctor$2(/*int*/ major, /*int*/ minor)
            {
                super.$ctor$1();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4298768391);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this.MajorVersion = major;
                    this.MinorVersion = minor;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4298768391)
            
            //--TRIMMABLE-BOUNDARY-START(34363539463)
            /*int*/ MajorVersion = 0;
            //--TRIMMABLE-BOUNDARY-END(34363539463)
            
            //--TRIMMABLE-BOUNDARY-START(38658506759)
            /*int*/ MinorVersion = 0;
            //--TRIMMABLE-BOUNDARY-END(38658506759)
            
            static $h = 3801095;
            static $f = 0b10010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 45219841,
  "p": [
//--TRIMMABLE-BOUNDARY-START(34363539463),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 21478637575,
        "f": 50331649
      },
      "n": "MajorVersion",
      "d": 3801095,
      "h": 34363539463,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(34363539463),
//--TRIMMABLE-BOUNDARY-START(38658506759),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 30068572167,
        "f": 50331649
      },
      "n": "MinorVersion",
      "d": 3801095,
      "h": 38658506759,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(38658506759)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4298768391),
    {
      "p": [
        {
          "n": "major",
          "p": 655361
        },
        {
          "n": "minor",
          "p": 655361
        }
      ],
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 3801095,
      "h": 4298768391,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4298768391)
  ],
  "h": 3801095,
  "a": [
    {
      "t": 45350913,
      "c": 21520187393,
      "a": [
        {
          "v": 1,
          "t": 45285377
        }
      ],
      "n": [
        {
          "n": "Inherited",
          "v": false,
          "t": 262145
        },
        {
          "n": "AllowMultiple",
          "v": true,
          "t": 262145
        }
      ]
    }
  ]
}; }
            static get $b() { return $.$$.System.Attribute; }
            static get $fullName() { return `System.Runtime.InteropServices.PrimaryInteropAssemblyAttribute`; }
        });
        //--TRIMMABLE-BOUNDARY-END(3801095)
        
        
        //--TRIMMABLE-BOUNDARY-START(3604487)
        $asm.$cls("$sris.System.Runtime.InteropServices.Marshalling.StrategyBasedComWrappers", ($self) => class StrategyBasedComWrappers extends $.$$.System.Runtime.InteropServices.ComWrappers
        {
            //--TRIMMABLE-BOUNDARY-START(55838179335)
            /*StrategyBasedComWrappers*/ static DefaultMarshallingInstance = null;
            //--TRIMMABLE-BOUNDARY-END(55838179335)
            
            //--TRIMMABLE-BOUNDARY-START(47248244743)
            /*IIUnknownInterfaceDetailsStrategy*/ static DefaultIUnknownInterfaceDetailsStrategy = null;
            //--TRIMMABLE-BOUNDARY-END(47248244743)
            
            //--TRIMMABLE-BOUNDARY-START(51543212039)
            /*IIUnknownStrategy*/ static DefaultIUnknownStrategy = null;
            //--TRIMMABLE-BOUNDARY-END(51543212039)
            
            //--TRIMMABLE-BOUNDARY-START(34363342855)
            static /*IIUnknownCacheStrategy */ CreateDefaultCacheStrategy()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(34363342855);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return new $.$sris.System.Runtime.InteropServices.Marshalling.DefaultCaching().$ctor$1();
                }
            }
            //--TRIMMABLE-BOUNDARY-END(34363342855)
            
            //--TRIMMABLE-BOUNDARY-START(85902950407)
            /*IIUnknownInterfaceDetailsStrategy */ GetOrCreateInterfaceDetailsStrategy()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(85902950407);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                //if (OperatingSystem.IsWindows() && RuntimeFeature.IsDynamicCodeSupported && ComObject.BuiltInComSupported && ComObject.ComImportInteropEnabled) { ... }
                return $.$sris.System.Runtime.InteropServices.Marshalling.StrategyBasedComWrappers.DefaultIUnknownInterfaceDetailsStrategy;
                /*static IIUnknownInterfaceDetailsStrategy*/  function GetInteropStrategy()
                {
                    return $.$sris.System.Runtime.InteropServices.Marshalling.ComImportInteropInterfaceDetailsStrategy.Instance;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(85902950407)
            
            //--TRIMMABLE-BOUNDARY-START(90197917703)
            /*IIUnknownStrategy */ GetOrCreateIUnknownStrategy()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(90197917703);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return $.$sris.System.Runtime.InteropServices.Marshalling.StrategyBasedComWrappers.DefaultIUnknownStrategy;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(90197917703)
            
            //--TRIMMABLE-BOUNDARY-START(30068375559)
            /*IIUnknownCacheStrategy */ CreateCacheStrategy()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(30068375559);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return $.$sris.System.Runtime.InteropServices.Marshalling.StrategyBasedComWrappers.CreateDefaultCacheStrategy();
                }
            }
            //--TRIMMABLE-BOUNDARY-END(30068375559)
            
            //--TRIMMABLE-BOUNDARY-START(ALL, 25773408263, 17319854081)
            /*ComInterfaceEntry* */ ComputeVtables(/*object*/ obj, /*CreateComInterfaceFlags*/ flags, /*out int*/ count)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25773408263);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                let details;
                if (this.GetOrCreateInterfaceDetailsStrategy().System$Runtime$InteropServices$Marshalling$IIUnknownInterfaceDetailsStrategy$GetComExposedTypeDetails($.$$.System.Object.GetType.call(obj).TypeHandle) !== null && ((details = this.GetOrCreateInterfaceDetailsStrategy().System$Runtime$InteropServices$Marshalling$IIUnknownInterfaceDetailsStrategy$GetComExposedTypeDetails($.$$.System.Object.GetType.call(obj).TypeHandle), details != null && true)))
                {
                    return details.System$Runtime$InteropServices$Marshalling$IComExposedDetails$GetComInterfaceEntries(count);
                }
                count.$v = 0;
                return null;
            }
            //--TRIMMABLE-BOUNDARY-END(ALL, 25773408263, 17319854081)
            
            //--TRIMMABLE-BOUNDARY-START(ALL, 38658310151, 21614821377)
            /*object */ CreateObject$1(/*nint*/ externalComObject, /*CreateObjectFlags*/ flags)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(38658310151);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (((flags & (1/*CreateObjectFlags.TrackerObject*/)) == (1/*CreateObjectFlags.TrackerObject*/)) || ((flags & (4/*CreateObjectFlags.Aggregation*/)) == (4/*CreateObjectFlags.Aggregation*/)))
                {
                    throw new $.$$.System.NotSupportedException().$ctor$9();
                }
                /*var*/ let rcw = (() =>
                {
                    //new $.$sris.System.Runtime.InteropServices.Marshalling.ComObject()
                    const $t1 = $.$sris.System.Runtime.InteropServices.Marshalling.ComObject;
                    const $i1 = new $t1();
                    $i1.$ctor$1(this.GetOrCreateInterfaceDetailsStrategy(), this.GetOrCreateIUnknownStrategy(), this.CreateCacheStrategy(), $.$$.System.IntPtr.op_Explicit$5(externalComObject));
                    $i1.UniqueInstance = ((flags & (2/*CreateObjectFlags.UniqueInstance*/)) == (2/*CreateObjectFlags.UniqueInstance*/));
                    return $i1;
                })();
                return rcw;
            }
            //--TRIMMABLE-BOUNDARY-END(ALL, 38658310151, 21614821377)
            
            //--TRIMMABLE-BOUNDARY-START(ALL, 42953277447, 25909788673)
            /*object? */ CreateObject(/*nint*/ externalComObject, /*CreateObjectFlags*/ flags, /*object?*/ userState, /*out CreatedWrapperFlags*/ wrapperFlags)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(42953277447);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return super.CreateObject(externalComObject, flags, userState, wrapperFlags);
            }
            //--TRIMMABLE-BOUNDARY-END(ALL, 42953277447, 25909788673)
            
            //--TRIMMABLE-BOUNDARY-START(ALL, 94492884999, 64564494337)
            /*void */ ReleaseObjects(/*IEnumerable*/ objects)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(94492884999);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.System.NotImplementedException().$ctor$9();
            }
            //--TRIMMABLE-BOUNDARY-END(ALL, 94492884999, 64564494337)
            
            //default reference type constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                return this;
            }
            //--TRIMMABLE-BOUNDARY-START(4298571783)
            //Static Initializer
            static $sinit()
            {
                {
                    this.DefaultMarshallingInstance = new $.$sris.System.Runtime.InteropServices.Marshalling.StrategyBasedComWrappers().$ctor$2();
                }
                {
                    this.DefaultIUnknownInterfaceDetailsStrategy = $.$sris.System.Runtime.InteropServices.Marshalling.DefaultIUnknownInterfaceDetailsStrategy.Instance;
                }
                {
                    this.DefaultIUnknownStrategy = $.$sris.System.Runtime.InteropServices.Marshalling.FreeThreadedStrategy.Instance;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(4298571783)
            
            static $h = 3604487;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 139984897,
  "p": [
//--TRIMMABLE-BOUNDARY-START(55838179335),
    {
      "p": 3604487,
      "g": {
        "r": 0,
        "d": 0,
        "h": 81607983111,
        "f": 50331688
      },
      "n": "DefaultMarshallingInstance",
      "d": 3604487,
      "h": 55838179335,
      "f": 2097192
    },
//--TRIMMABLE-BOUNDARY-END(55838179335),
//--TRIMMABLE-BOUNDARY-START(47248244743),
    {
      "p": 3276807,
      "g": {
        "r": 0,
        "d": 0,
        "h": 64428113927,
        "f": 50331681
      },
      "n": "DefaultIUnknownInterfaceDetailsStrategy",
      "d": 3604487,
      "h": 47248244743,
      "f": 2097185
    },
//--TRIMMABLE-BOUNDARY-END(47248244743),
//--TRIMMABLE-BOUNDARY-START(51543212039),
    {
      "p": 3407879,
      "g": {
        "r": 0,
        "d": 0,
        "h": 73018048519,
        "f": 50331681
      },
      "n": "DefaultIUnknownStrategy",
      "d": 3604487,
      "h": 51543212039,
      "f": 2097185
    },
//--TRIMMABLE-BOUNDARY-END(51543212039)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(34363342855),
    {
      "r": 3080199,
      "n": "CreateDefaultCacheStrategy",
      "d": 3604487,
      "h": 34363342855,
      "f": 16777252
    },
//--TRIMMABLE-BOUNDARY-END(34363342855),
//--TRIMMABLE-BOUNDARY-START(85902950407),
    {
      "r": 3276807,
      "n": "GetOrCreateInterfaceDetailsStrategy",
      "d": 3604487,
      "h": 85902950407,
      "f": 16777348
    },
//--TRIMMABLE-BOUNDARY-END(85902950407),
//--TRIMMABLE-BOUNDARY-START(90197917703),
    {
      "r": 3407879,
      "n": "GetOrCreateIUnknownStrategy",
      "d": 3604487,
      "h": 90197917703,
      "f": 16777348
    },
//--TRIMMABLE-BOUNDARY-END(90197917703),
//--TRIMMABLE-BOUNDARY-START(30068375559),
    {
      "r": 3080199,
      "n": "CreateCacheStrategy",
      "d": 3604487,
      "h": 30068375559,
      "f": 16777348
    },
//--TRIMMABLE-BOUNDARY-END(30068375559),
//--TRIMMABLE-BOUNDARY-START(ALL, 25773408263, 17319854081),
    {
      "r": $.$typePointer($.$$.System.Runtime.InteropServices.ComWrappers.ComInterfaceEntry).$h,
      "p": [
        {
          "n": "obj",
          "p": 131073
        },
        {
          "n": "flags",
          "p": 140181505
        },
        {
          "n": "count",
          "p": 655361,
          "f": 2
        }
      ],
      "n": "ComputeVtables",
      "d": 3604487,
      "h": 25773408263,
      "f": 16875524
    },
//--TRIMMABLE-BOUNDARY-END(ALL, 25773408263, 17319854081),
//--TRIMMABLE-BOUNDARY-START(ALL, 38658310151, 21614821377),
    {
      "r": 131073,
      "p": [
        {
          "n": "externalComObject",
          "p": 786433
        },
        {
          "n": "flags",
          "p": 140312577
        }
      ],
      "n": "CreateObject",
      "o": "@$1",
      "d": 3604487,
      "h": 38658310151,
      "f": 16875524
    },
//--TRIMMABLE-BOUNDARY-END(ALL, 38658310151, 21614821377),
//--TRIMMABLE-BOUNDARY-START(ALL, 42953277447, 25909788673),
    {
      "r": 131073,
      "p": [
        {
          "n": "externalComObject",
          "p": 786433
        },
        {
          "n": "flags",
          "p": 140312577
        },
        {
          "n": "userState",
          "p": 131073
        },
        {
          "n": "wrapperFlags",
          "p": 140247041,
          "f": 2
        }
      ],
      "n": "CreateObject",
      "d": 3604487,
      "h": 42953277447,
      "f": 16875524
    },
//--TRIMMABLE-BOUNDARY-END(ALL, 42953277447, 25909788673),
//--TRIMMABLE-BOUNDARY-START(ALL, 94492884999, 64564494337),
    {
      "r": 65537,
      "p": [
        {
          "n": "objects",
          "p": 62521345
        }
      ],
      "n": "ReleaseObjects",
      "d": 3604487,
      "h": 94492884999,
      "f": 16875524
    },
//--TRIMMABLE-BOUNDARY-END(ALL, 94492884999, 64564494337)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(8593539079),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 3604487,
      "h": 8593539079,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8593539079)
  ],
  "h": 3604487,
  "a": [
    {
      "t": 159252481,
      "c": 4454219777,
      "a": [
        {
          "v": "android",
          "t": 1310721
        }
      ]
    },
    {
      "t": 159252481,
      "c": 4454219777,
      "a": [
        {
          "v": "browser",
          "t": 1310721
        }
      ]
    },
    {
      "t": 159252481,
      "c": 4454219777,
      "a": [
        {
          "v": "ios",
          "t": 1310721
        }
      ]
    },
    {
      "t": 159252481,
      "c": 4454219777,
      "a": [
        {
          "v": "tvos",
          "t": 1310721
        }
      ]
    },
    {
      "t": 54132737,
      "c": 8644067329,
      "a": [
        {
          "v": false,
          "t": 262145
        }
      ]
    }
  ]
}; }
            static get $b() { return $.$$.System.Runtime.InteropServices.ComWrappers; }
            static get $fullName() { return `System.Runtime.InteropServices.Marshalling.StrategyBasedComWrappers`; }
        });
        //--TRIMMABLE-BOUNDARY-END(3604487)
        
        
        //--TRIMMABLE-BOUNDARY-START(1638407)
        $asm.$cls("$sris.System.Runtime.InteropServices.ImportedFromTypeLibAttribute", ($self) => class ImportedFromTypeLibAttribute extends $.$$.System.Attribute
        {
            //--TRIMMABLE-BOUNDARY-START(4296605703)
            $ctor$2(/*string*/ tlbFile)
            {
                super.$ctor$1();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4296605703);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this.Value = tlbFile;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296605703)
            
            //--TRIMMABLE-BOUNDARY-START(21476474887)
            /*string*/ Value = null;
            //--TRIMMABLE-BOUNDARY-END(21476474887)
            
            static $h = 1638407;
            static $f = 0b10010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 45219841,
  "p": [
//--TRIMMABLE-BOUNDARY-START(21476474887),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 17181507591,
        "f": 50331649
      },
      "n": "Value",
      "d": 1638407,
      "h": 21476474887,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(21476474887)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296605703),
    {
      "p": [
        {
          "n": "tlbFile",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 1638407,
      "h": 4296605703,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296605703)
  ],
  "h": 1638407,
  "a": [
    {
      "t": 45350913,
      "c": 21520187393,
      "a": [
        {
          "v": 1,
          "t": 45285377
        }
      ],
      "n": [
        {
          "n": "Inherited",
          "v": false,
          "t": 262145
        }
      ]
    }
  ]
}; }
            static get $b() { return $.$$.System.Attribute; }
            static get $fullName() { return `System.Runtime.InteropServices.ImportedFromTypeLibAttribute`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1638407)
        
        
        //--TRIMMABLE-BOUNDARY-START(1769479)
        $asm.$cls("$sris.System.Runtime.InteropServices.Marshalling.ComExposedClassAttribute<>", (T) => $asm.$gt("$sris.System.Runtime.InteropServices.Marshalling.ComExposedClassAttribute<>", [T], ($self) => class ComExposedClassAttribute$$ extends $.$$.System.Attribute
        {
            //--TRIMMABLE-BOUNDARY-START(8591704071)
            /*ComWrappers.ComInterfaceEntry* */ GetComInterfaceEntries(/*out int*/ count)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(8591704071);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return T.System$Runtime$InteropServices$Marshalling$IComExposedClass$GetComInterfaceEntries(count);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(8591704071)
            
            //--TRIMMABLE-BOUNDARY-START(4297981959)
            //Generated interface implemetation for System.Runtime.InteropServices.Marshalling.IComExposedDetails.GetComInterfaceEntries(out int)
            System$Runtime$InteropServices$Marshalling$IComExposedDetails$GetComInterfaceEntries()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4297981959);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.GetComInterfaceEntries(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4297981959)
            
            //default reference type constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                return this;
            }
            static $h = 1769479;
            static $g = 1;
            static $f = 0b11010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 45219841,
  "m": [
//--TRIMMABLE-BOUNDARY-START(8591704071),
    {
      "r": $.$typePointer($.$$.System.Runtime.InteropServices.ComWrappers.ComInterfaceEntry).$h,
      "p": [
        {
          "n": "count",
          "p": 655361,
          "f": 2
        }
      ],
      "n": "GetComInterfaceEntries",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x200000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8591704071)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296736775),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x100000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296736775)
  ],
  "i": [3014663
  ],
  "g": [T?.$h??1507328
  ],
  "r": 1,
  "h": this.$h,
  "a": [
    {
      "t": 45350913,
      "c": 21520187393,
      "a": [
        {
          "v": 4,
          "t": 45285377
        }
      ],
      "n": [
        {
          "n": "Inherited",
          "v": false,
          "t": 262145
        }
      ]
    },
    {
      "t": 54132737,
      "c": 8644067329,
      "a": [
        {
          "v": false,
          "t": 262145
        }
      ]
    }
  ]
}; }
            static get $b() { return $.$$.System.Attribute; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$sris.System.Runtime.InteropServices.Marshalling.IComExposedDetails ]; }
            static get $fullName() { return `System.Runtime.InteropServices.Marshalling.ComExposedClassAttribute<${T?.$fullName}>`; }
        }));
        //--TRIMMABLE-BOUNDARY-END(1769479)
        
        
        //--TRIMMABLE-BOUNDARY-START(3473415)
        $asm.$cls("$sris.System.Runtime.InteropServices.Marshalling.IUnknownDerivedAttribute<,>", (T, TImpl) => $asm.$gt("$sris.System.Runtime.InteropServices.Marshalling.IUnknownDerivedAttribute<,>", [T, TImpl], ($self) => class IUnknownDerivedAttribute$$$ extends $.$$.System.Attribute
        {
            //--TRIMMABLE-BOUNDARY-START(4298440711)
            $ctor$2()
            {
                super.$ctor$1();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4298440711);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4298440711)
            
            //--TRIMMABLE-BOUNDARY-START(34363211783)
            /*Guid */ get Iid()
            {
                return T.System$Runtime$InteropServices$Marshalling$IIUnknownInterfaceType$Iid;
            }
            //--TRIMMABLE-BOUNDARY-END(34363211783)
            
            //--TRIMMABLE-BOUNDARY-START(38658179079)
            /*Type */ get Implementation()
            {
                return TImpl.$type;
            }
            //--TRIMMABLE-BOUNDARY-END(38658179079)
            
            //--TRIMMABLE-BOUNDARY-START(42953146375)
            /*void** */ get ManagedVirtualMethodTable()
            {
                return T.System$Runtime$InteropServices$Marshalling$IIUnknownInterfaceType$ManagedVirtualMethodTable;
            }
            //--TRIMMABLE-BOUNDARY-END(42953146375)
            
            //--TRIMMABLE-BOUNDARY-START(8593145863)
            //Generated interface implemetation for System.Runtime.InteropServices.Marshalling.IIUnknownDerivedDetails.Iid.get
            get System$Runtime$InteropServices$Marshalling$IIUnknownDerivedDetails$Iid()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(34362949639);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Iid;
            }
            //--TRIMMABLE-BOUNDARY-END(8593145863)
            
            //--TRIMMABLE-BOUNDARY-START(17183080455)
            //Generated interface implemetation for System.Runtime.InteropServices.Marshalling.IIUnknownDerivedDetails.Implementation.get
            get System$Runtime$InteropServices$Marshalling$IIUnknownDerivedDetails$Implementation()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(38657916935);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Implementation;
            }
            //--TRIMMABLE-BOUNDARY-END(17183080455)
            
            //--TRIMMABLE-BOUNDARY-START(25773015047)
            //Generated interface implemetation for System.Runtime.InteropServices.Marshalling.IIUnknownDerivedDetails.ManagedVirtualMethodTable.get
            get System$Runtime$InteropServices$Marshalling$IIUnknownDerivedDetails$ManagedVirtualMethodTable()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(42952884231);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.ManagedVirtualMethodTable;
            }
            //--TRIMMABLE-BOUNDARY-END(25773015047)
            
            static $h = 3473415;
            static $g = 2;
            static $f = 0b1010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 45219841,
  "p": [
//--TRIMMABLE-BOUNDARY-START(34363211783),
    {
      "p": 88866817,
      "g": {
        "r": 0,
        "d": 0,
        "h": Number(BigInt(this.$h)|0x300000000n),
        "f": 50331649
      },
      "n": "Iid",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x800000000n),
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(34363211783),
//--TRIMMABLE-BOUNDARY-START(38658179079),
    {
      "p": 187629569,
      "g": {
        "r": 0,
        "d": 0,
        "h": Number(BigInt(this.$h)|0x500000000n),
        "f": 50331649
      },
      "n": "Implementation",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x900000000n),
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(38658179079),
//--TRIMMABLE-BOUNDARY-START(42953146375),
    {
      "p": $.$typePointer($.$typePointer($.$$.System.Void)).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": Number(BigInt(this.$h)|0x700000000n),
        "f": 50331649
      },
      "n": "ManagedVirtualMethodTable",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0xA00000000n),
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(42953146375)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4298440711),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x100000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4298440711)
  ],
  "i": [3211271
  ],
  "g": [T?.$h??1507328,TImpl?.$h??1572864
  ],
  "r": 2,
  "h": this.$h,
  "a": [
    {
      "t": 45350913,
      "c": 21520187393,
      "a": [
        {
          "v": 1024,
          "t": 45285377
        }
      ],
      "n": [
        {
          "n": "Inherited",
          "v": false,
          "t": 262145
        }
      ]
    },
    {
      "t": 54132737,
      "c": 8644067329,
      "a": [
        {
          "v": false,
          "t": 262145
        }
      ]
    }
  ]
}; }
            static get $b() { return $.$$.System.Attribute; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$sris.System.Runtime.InteropServices.Marshalling.IIUnknownDerivedDetails ]; }
            static get $fullName() { return `System.Runtime.InteropServices.Marshalling.IUnknownDerivedAttribute<${T?.$fullName},${TImpl?.$fullName}>`; }
        }));
        //--TRIMMABLE-BOUNDARY-END(3473415)
        
        
        //--TRIMMABLE-BOUNDARY-START(196615)
        $asm.$cls("$sris.System.Runtime.CompilerServices.IUnknownConstantAttribute", ($self) => class IUnknownConstantAttribute extends $.$$.System.Runtime.CompilerServices.CustomConstantAttribute
        {
            //--TRIMMABLE-BOUNDARY-START(4295163911)
            $ctor$3()
            {
                super.$ctor$2();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4295163911);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295163911)
            
            //--TRIMMABLE-BOUNDARY-START(ALL, 17180065799, 17306943489)
            /*object */ get Value()
            {
                return new $.$$.System.Runtime.InteropServices.UnknownWrapper().$ctor$1(null);
            }
            //--TRIMMABLE-BOUNDARY-END(ALL, 17180065799, 17306943489)
            
            static $h = 196615;
            static $f = 0b10010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 127074305,
  "p": [
//--TRIMMABLE-BOUNDARY-START(ALL, 17180065799, 17306943489),
    {
      "p": 131073,
      "g": {
        "r": 0,
        "d": 0,
        "h": 12885098503,
        "f": 50364417
      },
      "n": "Value",
      "d": 196615,
      "h": 17180065799,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(ALL, 17180065799, 17306943489)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295163911),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 196615,
      "h": 4295163911,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295163911)
  ],
  "h": 196615,
  "a": [
    {
      "t": 45350913,
      "c": 21520187393,
      "a": [
        {
          "v": 2304,
          "t": 45285377
        }
      ],
      "n": [
        {
          "n": "Inherited",
          "v": false,
          "t": 262145
        }
      ]
    }
  ]
}; }
            static get $b() { return $.$$.System.Runtime.CompilerServices.CustomConstantAttribute; }
            static get $fullName() { return `System.Runtime.CompilerServices.IUnknownConstantAttribute`; }
        });
        //--TRIMMABLE-BOUNDARY-END(196615)
        
        
        //--TRIMMABLE-BOUNDARY-START(131079)
        $asm.$cls("$sris.System.Runtime.CompilerServices.IDispatchConstantAttribute", ($self) => class IDispatchConstantAttribute extends $.$$.System.Runtime.CompilerServices.CustomConstantAttribute
        {
            //--TRIMMABLE-BOUNDARY-START(4295098375)
            $ctor$3()
            {
                super.$ctor$2();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4295098375);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295098375)
            
            //--TRIMMABLE-BOUNDARY-START(ALL, 17180000263, 17306943489)
            /*object */ get Value()
            {
                return new $.$$.System.Runtime.InteropServices.DispatchWrapper().$ctor$1(null);
            }
            //--TRIMMABLE-BOUNDARY-END(ALL, 17180000263, 17306943489)
            
            static $h = 131079;
            static $f = 0b10010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 127074305,
  "p": [
//--TRIMMABLE-BOUNDARY-START(ALL, 17180000263, 17306943489),
    {
      "p": 131073,
      "g": {
        "r": 0,
        "d": 0,
        "h": 12885032967,
        "f": 50364417
      },
      "n": "Value",
      "d": 131079,
      "h": 17180000263,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(ALL, 17180000263, 17306943489)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295098375),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 131079,
      "h": 4295098375,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295098375)
  ],
  "h": 131079,
  "a": [
    {
      "t": 158924801,
      "c": 4453892097,
      "a": [
        {
          "v": "windows",
          "t": 1310721
        }
      ]
    },
    {
      "t": 45350913,
      "c": 21520187393,
      "a": [
        {
          "v": 2304,
          "t": 45285377
        }
      ],
      "n": [
        {
          "n": "Inherited",
          "v": false,
          "t": 262145
        }
      ]
    }
  ]
}; }
            static get $b() { return $.$$.System.Runtime.CompilerServices.CustomConstantAttribute; }
            static get $fullName() { return `System.Runtime.CompilerServices.IDispatchConstantAttribute`; }
        });
        //--TRIMMABLE-BOUNDARY-END(131079)
        
        
        //--TRIMMABLE-BOUNDARY-START(458759)
        $asm.$cls("$sris.System.Runtime.InteropServices.ComAwareEventInfo", ($self) => class ComAwareEventInfo extends $.$$.System.Reflection.EventInfo
        {
            //--TRIMMABLE-BOUNDARY-START(4295426055)
            /*EventInfo*/ _innerEventInfo = null;
            //--TRIMMABLE-BOUNDARY-END(4295426055)
            
            //--TRIMMABLE-BOUNDARY-START(8590393351)
            $ctor$4(/*Type*/ type, /*string*/ eventName)
            {
                super.$ctor$3();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(8590393351);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this._innerEventInfo = type.GetEvent$1(eventName);
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(8590393351)
            
            //--TRIMMABLE-BOUNDARY-START(ALL, 12885360647, 8703442945)
            /*void */ AddEventHandler(/*object*/ target, /*Delegate*/ handler)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12885360647);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$$.System.Runtime.InteropServices.Marshal.IsComObject(target))
                {
                    /*Guid*/ let sourceIid;
                    /*int*/ let dispid;
                    $.$sris.System.Runtime.InteropServices.ComAwareEventInfo.GetDataForComInvocation(this._innerEventInfo, $.$ref(() => sourceIid, ($v) => sourceIid = $v, $.$$.System.Guid), $.$ref(() => dispid, ($v) => dispid = $v, $.$$.System.Int32));
                    $.$$.System.Runtime.InteropServices.ComEventsHelper.Combine(target, sourceIid, dispid, handler);
                }
                else 
                {
                    this._innerEventInfo.AddEventHandler(target, handler);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(ALL, 12885360647, 8703442945)
            
            //--TRIMMABLE-BOUNDARY-START(ALL, 133144444935, 163322265601)
            /*void */ RemoveEventHandler(/*object*/ target, /*Delegate*/ handler)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(133144444935);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$$.System.Runtime.InteropServices.Marshal.IsComObject(target))
                {
                    /*Guid*/ let sourceIid;
                    /*int*/ let dispid;
                    $.$sris.System.Runtime.InteropServices.ComAwareEventInfo.GetDataForComInvocation(this._innerEventInfo, $.$ref(() => sourceIid, ($v) => sourceIid = $v, $.$$.System.Guid), $.$ref(() => dispid, ($v) => dispid = $v, $.$$.System.Int32));
                    $.$$.System.Runtime.InteropServices.ComEventsHelper.Remove(target, sourceIid, dispid, handler);
                }
                else 
                {
                    this._innerEventInfo.RemoveEventHandler(target, handler);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(ALL, 133144444935, 163322265601)
            
            //--TRIMMABLE-BOUNDARY-START(ALL, 17180327943, 17293377537)
            /*EventAttributes */ get Attributes()
            {
                return this._innerEventInfo.Attributes;
            }
            //--TRIMMABLE-BOUNDARY-END(ALL, 17180327943, 17293377537)
            
            //--TRIMMABLE-BOUNDARY-START(ALL, 77309870087, 103192723457)
            /*MethodInfo? */ GetAddMethod$1(/*bool*/ nonPublic)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(77309870087);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return this._innerEventInfo.GetAddMethod$1(nonPublic);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(ALL, 77309870087, 103192723457)
            
            //--TRIMMABLE-BOUNDARY-START(ALL, 98784706567, 116077625345)
            /*MethodInfo[] */ GetOtherMethods$1(/*bool*/ nonPublic)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(98784706567);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return this._innerEventInfo.GetOtherMethods$1(nonPublic);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(ALL, 98784706567, 116077625345)
            
            //--TRIMMABLE-BOUNDARY-START(ALL, 103079673863, 124667559937)
            /*MethodInfo? */ GetRaiseMethod$1(/*bool*/ nonPublic)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(103079673863);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return this._innerEventInfo.GetRaiseMethod$1(nonPublic);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(ALL, 103079673863, 124667559937)
            
            //--TRIMMABLE-BOUNDARY-START(ALL, 107374641159, 133257494529)
            /*MethodInfo? */ GetRemoveMethod$1(/*bool*/ nonPublic)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(107374641159);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return this._innerEventInfo.GetRemoveMethod$1(nonPublic);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(ALL, 107374641159, 133257494529)
            
            //--TRIMMABLE-BOUNDARY-START(ALL, 21475295239, 34475081729)
            /*Type? */ get DeclaringType()
            {
                return this._innerEventInfo.DeclaringType;
            }
            //--TRIMMABLE-BOUNDARY-END(ALL, 21475295239, 34475081729)
            
            //--TRIMMABLE-BOUNDARY-START(ALL, 81604837383, 236338544641)
            /*object[] */ GetCustomAttributes$1(/*Type*/ attributeType, /*bool*/ inherit)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(81604837383);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this._innerEventInfo.GetCustomAttributes$1(attributeType, inherit);
            }
            //--TRIMMABLE-BOUNDARY-END(ALL, 81604837383, 236338544641)
            
            //--TRIMMABLE-BOUNDARY-START(ALL, 85899804679, 232043577345)
            /*object[] */ GetCustomAttributes(/*bool*/ inherit)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(85899804679);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this._innerEventInfo.GetCustomAttributes(inherit);
            }
            //--TRIMMABLE-BOUNDARY-END(ALL, 85899804679, 232043577345)
            
            //--TRIMMABLE-BOUNDARY-START(ALL, 90194771975, 240633511937)
            /*IList<CustomAttributeData> */ GetCustomAttributesData()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(90194771975);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return this._innerEventInfo.GetCustomAttributesData();
                }
            }
            //--TRIMMABLE-BOUNDARY-END(ALL, 90194771975, 240633511937)
            
            //--TRIMMABLE-BOUNDARY-START(ALL, 111669608455, 270698283009)
            /*bool */ IsDefined(/*Type*/ attributeType, /*bool*/ inherit)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(111669608455);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this._innerEventInfo.IsDefined(attributeType, inherit);
            }
            //--TRIMMABLE-BOUNDARY-END(ALL, 111669608455, 270698283009)
            
            //--TRIMMABLE-BOUNDARY-START(ALL, 115964575751, 326532857857)
            /*int */ get MetadataToken()
            {
                return this._innerEventInfo.MetadataToken;
            }
            //--TRIMMABLE-BOUNDARY-END(ALL, 115964575751, 326532857857)
            
            //--TRIMMABLE-BOUNDARY-START(ALL, 120259543047, 330827825153)
            /*Module */ get Module()
            {
                return this._innerEventInfo.Module;
            }
            //--TRIMMABLE-BOUNDARY-END(ALL, 120259543047, 330827825153)
            
            //--TRIMMABLE-BOUNDARY-START(ALL, 124554510343, 335122792449)
            /*string */ get Name()
            {
                return this._innerEventInfo.Name;
            }
            //--TRIMMABLE-BOUNDARY-END(ALL, 124554510343, 335122792449)
            
            //--TRIMMABLE-BOUNDARY-START(ALL, 128849477639, 348007694337)
            /*Type? */ get ReflectedType()
            {
                return this._innerEventInfo.ReflectedType;
            }
            //--TRIMMABLE-BOUNDARY-END(ALL, 128849477639, 348007694337)
            
            //--TRIMMABLE-BOUNDARY-START(94489739271)
            static /*void */ GetDataForComInvocation(/*EventInfo*/ eventInfo, /*out Guid*/ sourceIid, /*out int*/ dispid)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(94489739271);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*object[]*/ let comEventInterfaces = eventInfo.DeclaringType.GetCustomAttributes$1($.$$.System.Runtime.InteropServices.ComEventInterfaceAttribute.$type, false);
                if (comEventInterfaces === null || comEventInterfaces.length === 0)
                {
                    throw new $.$$.System.InvalidOperationException().$ctor$12($.$sris.System.SR.InvalidOperation_NoComEventInterfaceAttribute);
                }
                /*ComEventInterfaceAttribute*/ let interfaceAttribute = $.$cast($.$$.System.Array.$ReadT1.call(comEventInterfaces, 0), $.$$.System.Runtime.InteropServices.ComEventInterfaceAttribute);
                if (comEventInterfaces.length > 1)
                {
                    throw new $.$$.System.Reflection.AmbiguousMatchException().$ctor$12($.$sris.System.SR.Format$6($.$sris.System.SR.AmbiguousMatch_MultipleEventInterfaceAttributes, interfaceAttribute));
                }
                /*Type*/ let sourceInterface = interfaceAttribute.SourceInterface;
                /*Guid*/ let guid = sourceInterface.GUID;
                /*MethodInfo*/ let methodInfo = sourceInterface.GetMethod$12(eventInfo.Name);
                /*Attribute?*/ let dispIdAttribute = $.$$.System.Attribute.GetCustomAttribute$3(methodInfo, $.$$.System.Runtime.InteropServices.DispIdAttribute.$type);
                if (dispIdAttribute === null)
                {
                    throw new $.$$.System.InvalidOperationException().$ctor$12($.$sris.System.SR.InvalidOperation_NoDispIdAttribute);
                }
                sourceIid.$v = guid;
                dispid.$v = ($.$cast(dispIdAttribute, $.$$.System.Runtime.InteropServices.DispIdAttribute)).Value;
            }
            //--TRIMMABLE-BOUNDARY-END(94489739271)
            
            static $h = 458759;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 113508353,
  "p": [
//--TRIMMABLE-BOUNDARY-START(ALL, 17180327943, 17293377537),
    {
      "p": 113442817,
      "g": {
        "r": 0,
        "d": 0,
        "h": 30065229831,
        "f": 50364417
      },
      "n": "Attributes",
      "d": 458759,
      "h": 17180327943,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(ALL, 17180327943, 17293377537),
//--TRIMMABLE-BOUNDARY-START(ALL, 21475295239, 34475081729),
    {
      "p": 187629569,
      "g": {
        "r": 0,
        "d": 0,
        "h": 38655164423,
        "f": 50364417
      },
      "n": "DeclaringType",
      "d": 458759,
      "h": 21475295239,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(ALL, 21475295239, 34475081729),
//--TRIMMABLE-BOUNDARY-START(ALL, 115964575751, 326532857857),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 47245099015,
        "f": 50364417
      },
      "n": "MetadataToken",
      "d": 458759,
      "h": 115964575751,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(ALL, 115964575751, 326532857857),
//--TRIMMABLE-BOUNDARY-START(ALL, 120259543047, 330827825153),
    {
      "p": 117309441,
      "g": {
        "r": 0,
        "d": 0,
        "h": 55835033607,
        "f": 50364417
      },
      "n": "Module",
      "d": 458759,
      "h": 120259543047,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(ALL, 120259543047, 330827825153),
//--TRIMMABLE-BOUNDARY-START(ALL, 124554510343, 335122792449),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 64424968199,
        "f": 50364417
      },
      "n": "Name",
      "d": 458759,
      "h": 124554510343,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(ALL, 124554510343, 335122792449),
//--TRIMMABLE-BOUNDARY-START(ALL, 128849477639, 348007694337),
    {
      "p": 187629569,
      "g": {
        "r": 0,
        "d": 0,
        "h": 73014902791,
        "f": 50364417
      },
      "n": "ReflectedType",
      "d": 458759,
      "h": 128849477639,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(ALL, 128849477639, 348007694337)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(ALL, 12885360647, 8703442945),
    {
      "r": 65537,
      "p": [
        {
          "n": "target",
          "p": 131073
        },
        {
          "n": "handler",
          "p": 66650113
        }
      ],
      "n": "AddEventHandler",
      "d": 458759,
      "h": 12885360647,
      "f": 16809985,
      "a": [
        {
          "t": 158924801,
          "c": 4453892097,
          "a": [
            {
              "v": "windows",
              "t": 1310721
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(ALL, 12885360647, 8703442945),
//--TRIMMABLE-BOUNDARY-START(ALL, 133144444935, 163322265601),
    {
      "r": 65537,
      "p": [
        {
          "n": "target",
          "p": 131073
        },
        {
          "n": "handler",
          "p": 66650113
        }
      ],
      "n": "RemoveEventHandler",
      "d": 458759,
      "h": 133144444935,
      "f": 16809985,
      "a": [
        {
          "t": 158924801,
          "c": 4453892097,
          "a": [
            {
              "v": "windows",
              "t": 1310721
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(ALL, 133144444935, 163322265601),
//--TRIMMABLE-BOUNDARY-START(ALL, 77309870087, 103192723457),
    {
      "r": 116719617,
      "p": [
        {
          "n": "nonPublic",
          "p": 262145
        }
      ],
      "n": "GetAddMethod",
      "o": "@$1",
      "d": 458759,
      "h": 77309870087,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(ALL, 77309870087, 103192723457),
//--TRIMMABLE-BOUNDARY-START(ALL, 98784706567, 116077625345),
    {
      "r": $.$typeArray($.$$.System.Reflection.MethodInfo).$h,
      "p": [
        {
          "n": "nonPublic",
          "p": 262145
        }
      ],
      "n": "GetOtherMethods",
      "o": "@$1",
      "d": 458759,
      "h": 98784706567,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(ALL, 98784706567, 116077625345),
//--TRIMMABLE-BOUNDARY-START(ALL, 103079673863, 124667559937),
    {
      "r": 116719617,
      "p": [
        {
          "n": "nonPublic",
          "p": 262145
        }
      ],
      "n": "GetRaiseMethod",
      "o": "@$1",
      "d": 458759,
      "h": 103079673863,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(ALL, 103079673863, 124667559937),
//--TRIMMABLE-BOUNDARY-START(ALL, 107374641159, 133257494529),
    {
      "r": 116719617,
      "p": [
        {
          "n": "nonPublic",
          "p": 262145
        }
      ],
      "n": "GetRemoveMethod",
      "o": "@$1",
      "d": 458759,
      "h": 107374641159,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(ALL, 107374641159, 133257494529),
//--TRIMMABLE-BOUNDARY-START(ALL, 81604837383, 236338544641),
    {
      "r": $.$typeArray($.$$.System.Object).$h,
      "p": [
        {
          "n": "attributeType",
          "p": 187629569
        },
        {
          "n": "inherit",
          "p": 262145
        }
      ],
      "n": "GetCustomAttributes",
      "o": "@$1",
      "d": 458759,
      "h": 81604837383,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(ALL, 81604837383, 236338544641),
//--TRIMMABLE-BOUNDARY-START(ALL, 85899804679, 232043577345),
    {
      "r": $.$typeArray($.$$.System.Object).$h,
      "p": [
        {
          "n": "inherit",
          "p": 262145
        }
      ],
      "n": "GetCustomAttributes",
      "d": 458759,
      "h": 85899804679,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(ALL, 85899804679, 232043577345),
//--TRIMMABLE-BOUNDARY-START(ALL, 90194771975, 240633511937),
    {
      "r": $.$$.System.Collections.Generic.IList$$($.$$.System.Reflection.CustomAttributeData).$h,
      "n": "GetCustomAttributesData",
      "d": 458759,
      "h": 90194771975,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(ALL, 90194771975, 240633511937),
//--TRIMMABLE-BOUNDARY-START(ALL, 111669608455, 270698283009),
    {
      "r": 262145,
      "p": [
        {
          "n": "attributeType",
          "p": 187629569
        },
        {
          "n": "inherit",
          "p": 262145
        }
      ],
      "n": "IsDefined",
      "d": 458759,
      "h": 111669608455,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(ALL, 111669608455, 270698283009),
//--TRIMMABLE-BOUNDARY-START(94489739271),
    {
      "r": 65537,
      "p": [
        {
          "n": "eventInfo",
          "p": 113508353
        },
        {
          "n": "sourceIid",
          "p": 88866817,
          "f": 2
        },
        {
          "n": "dispid",
          "p": 655361,
          "f": 2
        }
      ],
      "n": "GetDataForComInvocation",
      "d": 458759,
      "h": 94489739271,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(94489739271)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(4295426055),
    {
      "t": 113508353,
      "n": "_innerEventInfo",
      "d": 458759,
      "h": 4295426055,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(4295426055)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(8590393351),
    {
      "p": [
        {
          "n": "type",
          "p": 187629569
        },
        {
          "n": "eventName",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$4",
      "d": 458759,
      "h": 8590393351,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8590393351)
  ],
  "i": [114032641
  ],
  "h": 458759,
  "a": [
    {
      "t": 64159745,
      "c": 4359127041,
      "a": [
        {
          "v": 1,
          "t": 64225281
        }
      ]
    }
  ]
}; }
            static get $b() { return $.$$.System.Reflection.EventInfo; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.System.Reflection.ICustomAttributeProvider ]; }
            static get $fullName() { return `System.Runtime.InteropServices.ComAwareEventInfo`; }
        });
        //--TRIMMABLE-BOUNDARY-END(458759)
        
        
        //--TRIMMABLE-BOUNDARY-START(851975)
        $asm.$str("$sris.System.Runtime.InteropServices.ComTypes.DVASPECT", ($self) => class DVASPECT extends $.$$.System.Enum
        {
            static DVASPECT_CONTENT = 1;
            static DVASPECT_THUMBNAIL = 2;
            static DVASPECT_ICON = 4;
            static DVASPECT_DOCPRINT = 8;
            static $map;
            static get Map()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(851975);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.$map ??= 
                {
                    "DVASPECT_CONTENT": 1n,
                    "DVASPECT_THUMBNAIL": 2n,
                    "DVASPECT_ICON": 4n,
                    "DVASPECT_DOCPRINT": 8n
                };
            }
            static $h = 851975;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static get $eut() { return $.$$.System.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 1048577,
  "u": 655361,
  "l": [
//--TRIMMABLE-BOUNDARY-START(8590786567),
    {
      "t": 851975,
      "n": "DVASPECT_CONTENT",
      "d": 851975,
      "h": 8590786567,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(8590786567),
//--TRIMMABLE-BOUNDARY-START(21475688455),
    {
      "t": 851975,
      "n": "DVASPECT_THUMBNAIL",
      "d": 851975,
      "h": 21475688455,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(21475688455),
//--TRIMMABLE-BOUNDARY-START(17180721159),
    {
      "t": 851975,
      "n": "DVASPECT_ICON",
      "d": 851975,
      "h": 17180721159,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(17180721159),
//--TRIMMABLE-BOUNDARY-START(12885753863),
    {
      "t": 851975,
      "n": "DVASPECT_DOCPRINT",
      "d": 851975,
      "h": 12885753863,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(12885753863)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295819271),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 851975,
      "h": 4295819271,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295819271)
  ],
  "i": [89915393,96468993,90374145,90046465
  ],
  "h": 851975,
  "a": [
    {
      "t": 64159745,
      "c": 4359127041,
      "a": [
        {
          "v": 1,
          "t": 64225281
        }
      ]
    },
    {
      "t": 80347137,
      "c": 4375314433
    }
  ]
}; }
            static get $b() { return $.$$.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.System.IComparable, $.$$.System.ISpanFormattable, $.$$.System.IFormattable, $.$$.System.IConvertible ]; }
            static get $fullName() { return `System.Runtime.InteropServices.ComTypes.DVASPECT`; }
        });
        //--TRIMMABLE-BOUNDARY-END(851975)
        
        
        //--TRIMMABLE-BOUNDARY-START(1376263)
        $asm.$str("$sris.System.Runtime.InteropServices.ComTypes.TYMED", ($self) => class TYMED extends $.$$.System.Enum
        {
            static TYMED_HGLOBAL = 1;
            static TYMED_FILE = 2;
            static TYMED_ISTREAM = 4;
            static TYMED_ISTORAGE = 8;
            static TYMED_GDI = 16;
            static TYMED_MFPICT = 32;
            static TYMED_ENHMF = 64;
            static TYMED_NULL = 0;
            static $map;
            static get Map()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(1376263);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.$map ??= 
                {
                    "TYMED_HGLOBAL": 1n,
                    "TYMED_FILE": 2n,
                    "TYMED_ISTREAM": 4n,
                    "TYMED_ISTORAGE": 8n,
                    "TYMED_GDI": 16n,
                    "TYMED_MFPICT": 32n,
                    "TYMED_ENHMF": 64n,
                    "TYMED_NULL": 0n
                };
            }
            static $h = 1376263;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static get $eut() { return $.$$.System.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 1048577,
  "u": 655361,
  "l": [
//--TRIMMABLE-BOUNDARY-START(21476212743),
    {
      "t": 1376263,
      "n": "TYMED_HGLOBAL",
      "d": 1376263,
      "h": 21476212743,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(21476212743),
//--TRIMMABLE-BOUNDARY-START(12886278151),
    {
      "t": 1376263,
      "n": "TYMED_FILE",
      "d": 1376263,
      "h": 12886278151,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(12886278151),
//--TRIMMABLE-BOUNDARY-START(30066147335),
    {
      "t": 1376263,
      "n": "TYMED_ISTREAM",
      "d": 1376263,
      "h": 30066147335,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(30066147335),
//--TRIMMABLE-BOUNDARY-START(25771180039),
    {
      "t": 1376263,
      "n": "TYMED_ISTORAGE",
      "d": 1376263,
      "h": 25771180039,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(25771180039),
//--TRIMMABLE-BOUNDARY-START(17181245447),
    {
      "t": 1376263,
      "n": "TYMED_GDI",
      "d": 1376263,
      "h": 17181245447,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(17181245447),
//--TRIMMABLE-BOUNDARY-START(34361114631),
    {
      "t": 1376263,
      "n": "TYMED_MFPICT",
      "d": 1376263,
      "h": 34361114631,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(34361114631),
//--TRIMMABLE-BOUNDARY-START(8591310855),
    {
      "t": 1376263,
      "n": "TYMED_ENHMF",
      "d": 1376263,
      "h": 8591310855,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(8591310855),
//--TRIMMABLE-BOUNDARY-START(38656081927),
    {
      "t": 1376263,
      "n": "TYMED_NULL",
      "d": 1376263,
      "h": 38656081927,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(38656081927)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296343559),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 1376263,
      "h": 4296343559,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296343559)
  ],
  "i": [89915393,96468993,90374145,90046465
  ],
  "h": 1376263,
  "a": [
    {
      "t": 64159745,
      "c": 4359127041,
      "a": [
        {
          "v": 1,
          "t": 64225281
        }
      ]
    },
    {
      "t": 80347137,
      "c": 4375314433
    }
  ]
}; }
            static get $b() { return $.$$.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.System.IComparable, $.$$.System.ISpanFormattable, $.$$.System.IFormattable, $.$$.System.IConvertible ]; }
            static get $fullName() { return `System.Runtime.InteropServices.ComTypes.TYMED`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1376263)
        
        
        //--TRIMMABLE-BOUNDARY-START(786439)
        $asm.$str("$sris.System.Runtime.InteropServices.ComTypes.DATADIR", ($self) => class DATADIR extends $.$$.System.Enum
        {
            static DATADIR_GET = 1;
            static DATADIR_SET = 2;
            static $map;
            static get Map()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(786439);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.$map ??= 
                {
                    "DATADIR_GET": 1n,
                    "DATADIR_SET": 2n
                };
            }
            static $h = 786439;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static get $eut() { return $.$$.System.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 1048577,
  "u": 655361,
  "l": [
//--TRIMMABLE-BOUNDARY-START(8590721031),
    {
      "t": 786439,
      "n": "DATADIR_GET",
      "d": 786439,
      "h": 8590721031,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(8590721031),
//--TRIMMABLE-BOUNDARY-START(12885688327),
    {
      "t": 786439,
      "n": "DATADIR_SET",
      "d": 786439,
      "h": 12885688327,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(12885688327)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295753735),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 786439,
      "h": 4295753735,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295753735)
  ],
  "i": [89915393,96468993,90374145,90046465
  ],
  "h": 786439,
  "a": [
    {
      "t": 64159745,
      "c": 4359127041,
      "a": [
        {
          "v": 1,
          "t": 64225281
        }
      ]
    }
  ]
}; }
            static get $b() { return $.$$.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.System.IComparable, $.$$.System.ISpanFormattable, $.$$.System.IFormattable, $.$$.System.IConvertible ]; }
            static get $fullName() { return `System.Runtime.InteropServices.ComTypes.DATADIR`; }
        });
        //--TRIMMABLE-BOUNDARY-END(786439)
        
        
        //--TRIMMABLE-BOUNDARY-START(720903)
        $asm.$str("$sris.System.Runtime.InteropServices.ComTypes.ADVF", ($self) => class ADVF extends $.$$.System.Enum
        {
            static ADVF_NODATA = 1;
            static ADVF_PRIMEFIRST = 2;
            static ADVF_ONLYONCE = 4;
            static ADVF_DATAONSTOP = 64;
            static ADVFCACHE_NOHANDLER = 8;
            static ADVFCACHE_FORCEBUILTIN = 16;
            static ADVFCACHE_ONSAVE = 32;
            static $map;
            static get Map()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(720903);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.$map ??= 
                {
                    "ADVF_NODATA": 1n,
                    "ADVF_PRIMEFIRST": 2n,
                    "ADVF_ONLYONCE": 4n,
                    "ADVF_DATAONSTOP": 64n,
                    "ADVFCACHE_NOHANDLER": 8n,
                    "ADVFCACHE_FORCEBUILTIN": 16n,
                    "ADVFCACHE_ONSAVE": 32n
                };
            }
            static $h = 720903;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static get $eut() { return $.$$.System.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 1048577,
  "u": 655361,
  "l": [
//--TRIMMABLE-BOUNDARY-START(12885622791),
    {
      "t": 720903,
      "n": "ADVF_NODATA",
      "d": 720903,
      "h": 12885622791,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(12885622791),
//--TRIMMABLE-BOUNDARY-START(21475557383),
    {
      "t": 720903,
      "n": "ADVF_PRIMEFIRST",
      "d": 720903,
      "h": 21475557383,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(21475557383),
//--TRIMMABLE-BOUNDARY-START(17180590087),
    {
      "t": 720903,
      "n": "ADVF_ONLYONCE",
      "d": 720903,
      "h": 17180590087,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(17180590087),
//--TRIMMABLE-BOUNDARY-START(8590655495),
    {
      "t": 720903,
      "n": "ADVF_DATAONSTOP",
      "d": 720903,
      "h": 8590655495,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(8590655495),
//--TRIMMABLE-BOUNDARY-START(30065491975),
    {
      "t": 720903,
      "n": "ADVFCACHE_NOHANDLER",
      "d": 720903,
      "h": 30065491975,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(30065491975),
//--TRIMMABLE-BOUNDARY-START(25770524679),
    {
      "t": 720903,
      "n": "ADVFCACHE_FORCEBUILTIN",
      "d": 720903,
      "h": 25770524679,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(25770524679),
//--TRIMMABLE-BOUNDARY-START(34360459271),
    {
      "t": 720903,
      "n": "ADVFCACHE_ONSAVE",
      "d": 720903,
      "h": 34360459271,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(34360459271)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295688199),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 720903,
      "h": 4295688199,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295688199)
  ],
  "i": [89915393,96468993,90374145,90046465
  ],
  "h": 720903,
  "a": [
    {
      "t": 64159745,
      "c": 4359127041,
      "a": [
        {
          "v": 1,
          "t": 64225281
        }
      ]
    },
    {
      "t": 80347137,
      "c": 4375314433
    }
  ]
}; }
            static get $b() { return $.$$.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.System.IComparable, $.$$.System.ISpanFormattable, $.$$.System.IFormattable, $.$$.System.IConvertible ]; }
            static get $fullName() { return `System.Runtime.InteropServices.ComTypes.ADVF`; }
        });
        //--TRIMMABLE-BOUNDARY-END(720903)
        
        
        //--TRIMMABLE-BOUNDARY-START(262151)
        $asm.$str("$sris.System.Runtime.InteropServices.AssemblyRegistrationFlags", ($self) => class AssemblyRegistrationFlags extends $.$$.System.Enum
        {
            static None = 0;
            static SetCodeBase = 1;
            static $map;
            static get Map()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(262151);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.$map ??= 
                {
                    "None": 0n,
                    "SetCodeBase": 1n
                };
            }
            static $h = 262151;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static get $eut() { return $.$$.System.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 1048577,
  "u": 655361,
  "l": [
//--TRIMMABLE-BOUNDARY-START(8590196743),
    {
      "t": 262151,
      "n": "None",
      "d": 262151,
      "h": 8590196743,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(8590196743),
//--TRIMMABLE-BOUNDARY-START(12885164039),
    {
      "t": 262151,
      "n": "SetCodeBase",
      "d": 262151,
      "h": 12885164039,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(12885164039)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295229447),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 262151,
      "h": 4295229447,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295229447)
  ],
  "i": [89915393,96468993,90374145,90046465
  ],
  "h": 262151,
  "a": [
    {
      "t": 80347137,
      "c": 4375314433
    }
  ]
}; }
            static get $b() { return $.$$.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.System.IComparable, $.$$.System.ISpanFormattable, $.$$.System.IFormattable, $.$$.System.IConvertible ]; }
            static get $fullName() { return `System.Runtime.InteropServices.AssemblyRegistrationFlags`; }
        });
        //--TRIMMABLE-BOUNDARY-END(262151)
        
        
        //--TRIMMABLE-BOUNDARY-START(1507335)
        $asm.$str("$sris.System.Runtime.InteropServices.ExporterEventKind", ($self) => class ExporterEventKind extends $.$$.System.Enum
        {
            static NOTIF_TYPECONVERTED = 0;
            static NOTIF_CONVERTWARNING = 1;
            static ERROR_REFTOINVALIDASSEMBLY = 2;
            static $map;
            static get Map()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(1507335);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.$map ??= 
                {
                    "NOTIF_TYPECONVERTED": 0n,
                    "NOTIF_CONVERTWARNING": 1n,
                    "ERROR_REFTOINVALIDASSEMBLY": 2n
                };
            }
            static $h = 1507335;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static get $eut() { return $.$$.System.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 1048577,
  "u": 655361,
  "l": [
//--TRIMMABLE-BOUNDARY-START(17181376519),
    {
      "t": 1507335,
      "n": "NOTIF_TYPECONVERTED",
      "d": 1507335,
      "h": 17181376519,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(17181376519),
//--TRIMMABLE-BOUNDARY-START(12886409223),
    {
      "t": 1507335,
      "n": "NOTIF_CONVERTWARNING",
      "d": 1507335,
      "h": 12886409223,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(12886409223),
//--TRIMMABLE-BOUNDARY-START(8591441927),
    {
      "t": 1507335,
      "n": "ERROR_REFTOINVALIDASSEMBLY",
      "d": 1507335,
      "h": 8591441927,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(8591441927)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296474631),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 1507335,
      "h": 4296474631,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296474631)
  ],
  "i": [89915393,96468993,90374145,90046465
  ],
  "h": 1507335
}; }
            static get $b() { return $.$$.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.System.IComparable, $.$$.System.ISpanFormattable, $.$$.System.IFormattable, $.$$.System.IConvertible ]; }
            static get $fullName() { return `System.Runtime.InteropServices.ExporterEventKind`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1507335)
        
        
        //--TRIMMABLE-BOUNDARY-START(2097159)
        $asm.$str("$sris.System.Runtime.InteropServices.Marshalling.ComInterfaceOptions", ($self) => class ComInterfaceOptions extends $.$$.System.Enum
        {
            static None = 0;
            static ManagedObjectWrapper = 1;
            static ComObjectWrapper = 2;
            static $map;
            static get Map()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(2097159);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.$map ??= 
                {
                    "None": 0n,
                    "ManagedObjectWrapper": 1n,
                    "ComObjectWrapper": 2n
                };
            }
            static $h = 2097159;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static get $eut() { return $.$$.System.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 1048577,
  "u": 655361,
  "l": [
//--TRIMMABLE-BOUNDARY-START(17181966343),
    {
      "t": 2097159,
      "n": "None",
      "d": 2097159,
      "h": 17181966343,
      "f": 4194337,
      "a": [
        {
          "t": 64159745,
          "c": 4359127041,
          "a": [
            {
              "v": 1,
              "t": 64225281
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(17181966343),
//--TRIMMABLE-BOUNDARY-START(12886999047),
    {
      "t": 2097159,
      "n": "ManagedObjectWrapper",
      "d": 2097159,
      "h": 12886999047,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(12886999047),
//--TRIMMABLE-BOUNDARY-START(8592031751),
    {
      "t": 2097159,
      "n": "ComObjectWrapper",
      "d": 2097159,
      "h": 8592031751,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(8592031751)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4297064455),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 2097159,
      "h": 4297064455,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4297064455)
  ],
  "i": [89915393,96468993,90374145,90046465
  ],
  "h": 2097159,
  "a": [
    {
      "t": 80347137,
      "c": 4375314433
    }
  ]
}; }
            static get $b() { return $.$$.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.System.IComparable, $.$$.System.ISpanFormattable, $.$$.System.IFormattable, $.$$.System.IConvertible ]; }
            static get $fullName() { return `System.Runtime.InteropServices.Marshalling.ComInterfaceOptions`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2097159)
        
        
        //--TRIMMABLE-BOUNDARY-START(3866631)
        $asm.$str("$sris.System.Runtime.InteropServices.RegistrationClassContext", ($self) => class RegistrationClassContext extends $.$$.System.Enum
        {
            static InProcessServer = 1;
            static InProcessHandler = 2;
            static LocalServer = 4;
            static InProcessServer16 = 8;
            static RemoteServer = 16;
            static InProcessHandler16 = 32;
            static Reserved1 = 64;
            static Reserved2 = 128;
            static Reserved3 = 256;
            static Reserved4 = 512;
            static NoCodeDownload = 1024;
            static Reserved5 = 2048;
            static NoCustomMarshal = 4096;
            static EnableCodeDownload = 8192;
            static NoFailureLog = 16384;
            static DisableActivateAsActivator = 32768;
            static EnableActivateAsActivator = 65536;
            static FromDefaultContext = 131072;
            static $map;
            static get Map()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(3866631);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.$map ??= 
                {
                    "InProcessServer": 1n,
                    "InProcessHandler": 2n,
                    "LocalServer": 4n,
                    "InProcessServer16": 8n,
                    "RemoteServer": 16n,
                    "InProcessHandler16": 32n,
                    "Reserved1": 64n,
                    "Reserved2": 128n,
                    "Reserved3": 256n,
                    "Reserved4": 512n,
                    "NoCodeDownload": 1024n,
                    "Reserved5": 2048n,
                    "NoCustomMarshal": 4096n,
                    "EnableCodeDownload": 8192n,
                    "NoFailureLog": 16384n,
                    "DisableActivateAsActivator": 32768n,
                    "EnableActivateAsActivator": 65536n,
                    "FromDefaultContext": 131072n
                };
            }
            static $h = 3866631;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static get $eut() { return $.$$.System.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 1048577,
  "u": 655361,
  "l": [
//--TRIMMABLE-BOUNDARY-START(34363604999),
    {
      "t": 3866631,
      "n": "InProcessServer",
      "d": 3866631,
      "h": 34363604999,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(34363604999),
//--TRIMMABLE-BOUNDARY-START(25773670407),
    {
      "t": 3866631,
      "n": "InProcessHandler",
      "d": 3866631,
      "h": 25773670407,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(25773670407),
//--TRIMMABLE-BOUNDARY-START(42953539591),
    {
      "t": 3866631,
      "n": "LocalServer",
      "d": 3866631,
      "h": 42953539591,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(42953539591),
//--TRIMMABLE-BOUNDARY-START(38658572295),
    {
      "t": 3866631,
      "n": "InProcessServer16",
      "d": 3866631,
      "h": 38658572295,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(38658572295),
//--TRIMMABLE-BOUNDARY-START(60133408775),
    {
      "t": 3866631,
      "n": "RemoteServer",
      "d": 3866631,
      "h": 60133408775,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(60133408775),
//--TRIMMABLE-BOUNDARY-START(30068637703),
    {
      "t": 3866631,
      "n": "InProcessHandler16",
      "d": 3866631,
      "h": 30068637703,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(30068637703),
//--TRIMMABLE-BOUNDARY-START(64428376071),
    {
      "t": 3866631,
      "n": "Reserved1",
      "d": 3866631,
      "h": 64428376071,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(64428376071),
//--TRIMMABLE-BOUNDARY-START(68723343367),
    {
      "t": 3866631,
      "n": "Reserved2",
      "d": 3866631,
      "h": 68723343367,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(68723343367),
//--TRIMMABLE-BOUNDARY-START(73018310663),
    {
      "t": 3866631,
      "n": "Reserved3",
      "d": 3866631,
      "h": 73018310663,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(73018310663),
//--TRIMMABLE-BOUNDARY-START(77313277959),
    {
      "t": 3866631,
      "n": "Reserved4",
      "d": 3866631,
      "h": 77313277959,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(77313277959),
//--TRIMMABLE-BOUNDARY-START(47248506887),
    {
      "t": 3866631,
      "n": "NoCodeDownload",
      "d": 3866631,
      "h": 47248506887,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(47248506887),
//--TRIMMABLE-BOUNDARY-START(81608245255),
    {
      "t": 3866631,
      "n": "Reserved5",
      "d": 3866631,
      "h": 81608245255,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(81608245255),
//--TRIMMABLE-BOUNDARY-START(51543474183),
    {
      "t": 3866631,
      "n": "NoCustomMarshal",
      "d": 3866631,
      "h": 51543474183,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(51543474183),
//--TRIMMABLE-BOUNDARY-START(17183735815),
    {
      "t": 3866631,
      "n": "EnableCodeDownload",
      "d": 3866631,
      "h": 17183735815,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(17183735815),
//--TRIMMABLE-BOUNDARY-START(55838441479),
    {
      "t": 3866631,
      "n": "NoFailureLog",
      "d": 3866631,
      "h": 55838441479,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(55838441479),
//--TRIMMABLE-BOUNDARY-START(8593801223),
    {
      "t": 3866631,
      "n": "DisableActivateAsActivator",
      "d": 3866631,
      "h": 8593801223,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(8593801223),
//--TRIMMABLE-BOUNDARY-START(12888768519),
    {
      "t": 3866631,
      "n": "EnableActivateAsActivator",
      "d": 3866631,
      "h": 12888768519,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(12888768519),
//--TRIMMABLE-BOUNDARY-START(21478703111),
    {
      "t": 3866631,
      "n": "FromDefaultContext",
      "d": 3866631,
      "h": 21478703111,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(21478703111)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4298833927),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 3866631,
      "h": 4298833927,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4298833927)
  ],
  "i": [89915393,96468993,90374145,90046465
  ],
  "h": 3866631,
  "a": [
    {
      "t": 80347137,
      "c": 4375314433
    }
  ]
}; }
            static get $b() { return $.$$.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.System.IComparable, $.$$.System.ISpanFormattable, $.$$.System.IFormattable, $.$$.System.IConvertible ]; }
            static get $fullName() { return `System.Runtime.InteropServices.RegistrationClassContext`; }
        });
        //--TRIMMABLE-BOUNDARY-END(3866631)
        
        
        //--TRIMMABLE-BOUNDARY-START(3932167)
        $asm.$str("$sris.System.Runtime.InteropServices.RegistrationConnectionType", ($self) => class RegistrationConnectionType extends $.$$.System.Enum
        {
            static SingleUse = 0;
            static MultipleUse = 1;
            static MultiSeparate = 2;
            static Suspended = 4;
            static Surrogate = 8;
            static $map;
            static get Map()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(3932167);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.$map ??= 
                {
                    "SingleUse": 0n,
                    "MultipleUse": 1n,
                    "MultiSeparate": 2n,
                    "Suspended": 4n,
                    "Surrogate": 8n
                };
            }
            static $h = 3932167;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static get $eut() { return $.$$.System.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 1048577,
  "u": 655361,
  "l": [
//--TRIMMABLE-BOUNDARY-START(17183801351),
    {
      "t": 3932167,
      "n": "SingleUse",
      "d": 3932167,
      "h": 17183801351,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(17183801351),
//--TRIMMABLE-BOUNDARY-START(8593866759),
    {
      "t": 3932167,
      "n": "MultipleUse",
      "d": 3932167,
      "h": 8593866759,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(8593866759),
//--TRIMMABLE-BOUNDARY-START(12888834055),
    {
      "t": 3932167,
      "n": "MultiSeparate",
      "d": 3932167,
      "h": 12888834055,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(12888834055),
//--TRIMMABLE-BOUNDARY-START(25773735943),
    {
      "t": 3932167,
      "n": "Suspended",
      "d": 3932167,
      "h": 25773735943,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(25773735943),
//--TRIMMABLE-BOUNDARY-START(21478768647),
    {
      "t": 3932167,
      "n": "Surrogate",
      "d": 3932167,
      "h": 21478768647,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(21478768647)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4298899463),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 3932167,
      "h": 4298899463,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4298899463)
  ],
  "i": [89915393,96468993,90374145,90046465
  ],
  "h": 3932167,
  "a": [
    {
      "t": 80347137,
      "c": 4375314433
    }
  ]
}; }
            static get $b() { return $.$$.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.System.IComparable, $.$$.System.ISpanFormattable, $.$$.System.IFormattable, $.$$.System.IConvertible ]; }
            static get $fullName() { return `System.Runtime.InteropServices.RegistrationConnectionType`; }
        });
        //--TRIMMABLE-BOUNDARY-END(3932167)
        
        
        //--TRIMMABLE-BOUNDARY-START(4325383)
        $asm.$str("$sris.System.Runtime.InteropServices.TypeLibTypeFlags", ($self) => class TypeLibTypeFlags extends $.$$.System.Enum
        {
            static FAppObject = 1;
            static FCanCreate = 2;
            static FLicensed = 4;
            static FPreDeclId = 8;
            static FHidden = 16;
            static FControl = 32;
            static FDual = 64;
            static FNonExtensible = 128;
            static FOleAutomation = 256;
            static FRestricted = 512;
            static FAggregatable = 1024;
            static FReplaceable = 2048;
            static FDispatchable = 4096;
            static FReverseBind = 8192;
            static $map;
            static get Map()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4325383);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.$map ??= 
                {
                    "FAppObject": 1n,
                    "FCanCreate": 2n,
                    "FLicensed": 4n,
                    "FPreDeclId": 8n,
                    "FHidden": 16n,
                    "FControl": 32n,
                    "FDual": 64n,
                    "FNonExtensible": 128n,
                    "FOleAutomation": 256n,
                    "FRestricted": 512n,
                    "FAggregatable": 1024n,
                    "FReplaceable": 2048n,
                    "FDispatchable": 4096n,
                    "FReverseBind": 8192n
                };
            }
            static $h = 4325383;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static get $eut() { return $.$$.System.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 1048577,
  "u": 655361,
  "l": [
//--TRIMMABLE-BOUNDARY-START(12889227271),
    {
      "t": 4325383,
      "n": "FAppObject",
      "d": 4325383,
      "h": 12889227271,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(12889227271),
//--TRIMMABLE-BOUNDARY-START(17184194567),
    {
      "t": 4325383,
      "n": "FCanCreate",
      "d": 4325383,
      "h": 17184194567,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(17184194567),
//--TRIMMABLE-BOUNDARY-START(38659031047),
    {
      "t": 4325383,
      "n": "FLicensed",
      "d": 4325383,
      "h": 38659031047,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(38659031047),
//--TRIMMABLE-BOUNDARY-START(51543932935),
    {
      "t": 4325383,
      "n": "FPreDeclId",
      "d": 4325383,
      "h": 51543932935,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(51543932935),
//--TRIMMABLE-BOUNDARY-START(34364063751),
    {
      "t": 4325383,
      "n": "FHidden",
      "d": 4325383,
      "h": 34364063751,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(34364063751),
//--TRIMMABLE-BOUNDARY-START(21479161863),
    {
      "t": 4325383,
      "n": "FControl",
      "d": 4325383,
      "h": 21479161863,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(21479161863),
//--TRIMMABLE-BOUNDARY-START(30069096455),
    {
      "t": 4325383,
      "n": "FDual",
      "d": 4325383,
      "h": 30069096455,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(30069096455),
//--TRIMMABLE-BOUNDARY-START(42953998343),
    {
      "t": 4325383,
      "n": "FNonExtensible",
      "d": 4325383,
      "h": 42953998343,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(42953998343),
//--TRIMMABLE-BOUNDARY-START(47248965639),
    {
      "t": 4325383,
      "n": "FOleAutomation",
      "d": 4325383,
      "h": 47248965639,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(47248965639),
//--TRIMMABLE-BOUNDARY-START(60133867527),
    {
      "t": 4325383,
      "n": "FRestricted",
      "d": 4325383,
      "h": 60133867527,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(60133867527),
//--TRIMMABLE-BOUNDARY-START(8594259975),
    {
      "t": 4325383,
      "n": "FAggregatable",
      "d": 4325383,
      "h": 8594259975,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(8594259975),
//--TRIMMABLE-BOUNDARY-START(55838900231),
    {
      "t": 4325383,
      "n": "FReplaceable",
      "d": 4325383,
      "h": 55838900231,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(55838900231),
//--TRIMMABLE-BOUNDARY-START(25774129159),
    {
      "t": 4325383,
      "n": "FDispatchable",
      "d": 4325383,
      "h": 25774129159,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(25774129159),
//--TRIMMABLE-BOUNDARY-START(64428834823),
    {
      "t": 4325383,
      "n": "FReverseBind",
      "d": 4325383,
      "h": 64428834823,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(64428834823)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4299292679),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 4325383,
      "h": 4299292679,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4299292679)
  ],
  "i": [89915393,96468993,90374145,90046465
  ],
  "h": 4325383,
  "a": [
    {
      "t": 80347137,
      "c": 4375314433
    }
  ]
}; }
            static get $b() { return $.$$.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.System.IComparable, $.$$.System.ISpanFormattable, $.$$.System.IFormattable, $.$$.System.IConvertible ]; }
            static get $fullName() { return `System.Runtime.InteropServices.TypeLibTypeFlags`; }
        });
        //--TRIMMABLE-BOUNDARY-END(4325383)
        
        
        //--TRIMMABLE-BOUNDARY-START(4128775)
        $asm.$str("$sris.System.Runtime.InteropServices.TypeLibFuncFlags", ($self) => class TypeLibFuncFlags extends $.$$.System.Enum
        {
            static FRestricted = 1;
            static FSource = 2;
            static FBindable = 4;
            static FRequestEdit = 8;
            static FDisplayBind = 16;
            static FDefaultBind = 32;
            static FHidden = 64;
            static FUsesGetLastError = 128;
            static FDefaultCollelem = 256;
            static FUiDefault = 512;
            static FNonBrowsable = 1024;
            static FReplaceable = 2048;
            static FImmediateBind = 4096;
            static $map;
            static get Map()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4128775);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.$map ??= 
                {
                    "FRestricted": 1n,
                    "FSource": 2n,
                    "FBindable": 4n,
                    "FRequestEdit": 8n,
                    "FDisplayBind": 16n,
                    "FDefaultBind": 32n,
                    "FHidden": 64n,
                    "FUsesGetLastError": 128n,
                    "FDefaultCollelem": 256n,
                    "FUiDefault": 512n,
                    "FNonBrowsable": 1024n,
                    "FReplaceable": 2048n,
                    "FImmediateBind": 4096n
                };
            }
            static $h = 4128775;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static get $eut() { return $.$$.System.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 1048577,
  "u": 655361,
  "l": [
//--TRIMMABLE-BOUNDARY-START(47248769031),
    {
      "t": 4128775,
      "n": "FRestricted",
      "d": 4128775,
      "h": 47248769031,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(47248769031),
//--TRIMMABLE-BOUNDARY-START(51543736327),
    {
      "t": 4128775,
      "n": "FSource",
      "d": 4128775,
      "h": 51543736327,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(51543736327),
//--TRIMMABLE-BOUNDARY-START(8594063367),
    {
      "t": 4128775,
      "n": "FBindable",
      "d": 4128775,
      "h": 8594063367,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(8594063367),
//--TRIMMABLE-BOUNDARY-START(42953801735),
    {
      "t": 4128775,
      "n": "FRequestEdit",
      "d": 4128775,
      "h": 42953801735,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(42953801735),
//--TRIMMABLE-BOUNDARY-START(21478965255),
    {
      "t": 4128775,
      "n": "FDisplayBind",
      "d": 4128775,
      "h": 21478965255,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(21478965255),
//--TRIMMABLE-BOUNDARY-START(12889030663),
    {
      "t": 4128775,
      "n": "FDefaultBind",
      "d": 4128775,
      "h": 12889030663,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(12889030663),
//--TRIMMABLE-BOUNDARY-START(25773932551),
    {
      "t": 4128775,
      "n": "FHidden",
      "d": 4128775,
      "h": 25773932551,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(25773932551),
//--TRIMMABLE-BOUNDARY-START(60133670919),
    {
      "t": 4128775,
      "n": "FUsesGetLastError",
      "d": 4128775,
      "h": 60133670919,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(60133670919),
//--TRIMMABLE-BOUNDARY-START(17183997959),
    {
      "t": 4128775,
      "n": "FDefaultCollelem",
      "d": 4128775,
      "h": 17183997959,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(17183997959),
//--TRIMMABLE-BOUNDARY-START(55838703623),
    {
      "t": 4128775,
      "n": "FUiDefault",
      "d": 4128775,
      "h": 55838703623,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(55838703623),
//--TRIMMABLE-BOUNDARY-START(34363867143),
    {
      "t": 4128775,
      "n": "FNonBrowsable",
      "d": 4128775,
      "h": 34363867143,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(34363867143),
//--TRIMMABLE-BOUNDARY-START(38658834439),
    {
      "t": 4128775,
      "n": "FReplaceable",
      "d": 4128775,
      "h": 38658834439,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(38658834439),
//--TRIMMABLE-BOUNDARY-START(30068899847),
    {
      "t": 4128775,
      "n": "FImmediateBind",
      "d": 4128775,
      "h": 30068899847,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(30068899847)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4299096071),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 4128775,
      "h": 4299096071,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4299096071)
  ],
  "i": [89915393,96468993,90374145,90046465
  ],
  "h": 4128775,
  "a": [
    {
      "t": 80347137,
      "c": 4375314433
    }
  ]
}; }
            static get $b() { return $.$$.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.System.IComparable, $.$$.System.ISpanFormattable, $.$$.System.IFormattable, $.$$.System.IConvertible ]; }
            static get $fullName() { return `System.Runtime.InteropServices.TypeLibFuncFlags`; }
        });
        //--TRIMMABLE-BOUNDARY-END(4128775)
        
        
        //--TRIMMABLE-BOUNDARY-START(4456455)
        $asm.$str("$sris.System.Runtime.InteropServices.TypeLibVarFlags", ($self) => class TypeLibVarFlags extends $.$$.System.Enum
        {
            static FReadOnly = 1;
            static FSource = 2;
            static FBindable = 4;
            static FRequestEdit = 8;
            static FDisplayBind = 16;
            static FDefaultBind = 32;
            static FHidden = 64;
            static FRestricted = 128;
            static FDefaultCollelem = 256;
            static FUiDefault = 512;
            static FNonBrowsable = 1024;
            static FReplaceable = 2048;
            static FImmediateBind = 4096;
            static $map;
            static get Map()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4456455);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.$map ??= 
                {
                    "FReadOnly": 1n,
                    "FSource": 2n,
                    "FBindable": 4n,
                    "FRequestEdit": 8n,
                    "FDisplayBind": 16n,
                    "FDefaultBind": 32n,
                    "FHidden": 64n,
                    "FRestricted": 128n,
                    "FDefaultCollelem": 256n,
                    "FUiDefault": 512n,
                    "FNonBrowsable": 1024n,
                    "FReplaceable": 2048n,
                    "FImmediateBind": 4096n
                };
            }
            static $h = 4456455;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static get $eut() { return $.$$.System.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 1048577,
  "u": 655361,
  "l": [
//--TRIMMABLE-BOUNDARY-START(38659162119),
    {
      "t": 4456455,
      "n": "FReadOnly",
      "d": 4456455,
      "h": 38659162119,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(38659162119),
//--TRIMMABLE-BOUNDARY-START(55839031303),
    {
      "t": 4456455,
      "n": "FSource",
      "d": 4456455,
      "h": 55839031303,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(55839031303),
//--TRIMMABLE-BOUNDARY-START(8594391047),
    {
      "t": 4456455,
      "n": "FBindable",
      "d": 4456455,
      "h": 8594391047,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(8594391047),
//--TRIMMABLE-BOUNDARY-START(47249096711),
    {
      "t": 4456455,
      "n": "FRequestEdit",
      "d": 4456455,
      "h": 47249096711,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(47249096711),
//--TRIMMABLE-BOUNDARY-START(21479292935),
    {
      "t": 4456455,
      "n": "FDisplayBind",
      "d": 4456455,
      "h": 21479292935,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(21479292935),
//--TRIMMABLE-BOUNDARY-START(12889358343),
    {
      "t": 4456455,
      "n": "FDefaultBind",
      "d": 4456455,
      "h": 12889358343,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(12889358343),
//--TRIMMABLE-BOUNDARY-START(25774260231),
    {
      "t": 4456455,
      "n": "FHidden",
      "d": 4456455,
      "h": 25774260231,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(25774260231),
//--TRIMMABLE-BOUNDARY-START(51544064007),
    {
      "t": 4456455,
      "n": "FRestricted",
      "d": 4456455,
      "h": 51544064007,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(51544064007),
//--TRIMMABLE-BOUNDARY-START(17184325639),
    {
      "t": 4456455,
      "n": "FDefaultCollelem",
      "d": 4456455,
      "h": 17184325639,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(17184325639),
//--TRIMMABLE-BOUNDARY-START(60133998599),
    {
      "t": 4456455,
      "n": "FUiDefault",
      "d": 4456455,
      "h": 60133998599,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(60133998599),
//--TRIMMABLE-BOUNDARY-START(34364194823),
    {
      "t": 4456455,
      "n": "FNonBrowsable",
      "d": 4456455,
      "h": 34364194823,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(34364194823),
//--TRIMMABLE-BOUNDARY-START(42954129415),
    {
      "t": 4456455,
      "n": "FReplaceable",
      "d": 4456455,
      "h": 42954129415,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(42954129415),
//--TRIMMABLE-BOUNDARY-START(30069227527),
    {
      "t": 4456455,
      "n": "FImmediateBind",
      "d": 4456455,
      "h": 30069227527,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(30069227527)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4299423751),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 4456455,
      "h": 4299423751,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4299423751)
  ],
  "i": [89915393,96468993,90374145,90046465
  ],
  "h": 4456455,
  "a": [
    {
      "t": 80347137,
      "c": 4375314433
    }
  ]
}; }
            static get $b() { return $.$$.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.System.IComparable, $.$$.System.ISpanFormattable, $.$$.System.IFormattable, $.$$.System.IConvertible ]; }
            static get $fullName() { return `System.Runtime.InteropServices.TypeLibVarFlags`; }
        });
        //--TRIMMABLE-BOUNDARY-END(4456455)
        
        
        //--TRIMMABLE-BOUNDARY-START(2162695)
        $asm.$cls("$sris.System.Runtime.InteropServices.Marshalling.ComObject", ($self) => class ComObject extends $.$$.System.Object
        {
            //--TRIMMABLE-BOUNDARY-START(51541770247)
            /*bool*/ static BuiltInComSupported = false;
            //--TRIMMABLE-BOUNDARY-END(51541770247)
            
            //--TRIMMABLE-BOUNDARY-START(60131704839)
            /*bool*/ static ComImportInteropEnabled = false;
            //--TRIMMABLE-BOUNDARY-END(60131704839)
            
            //--TRIMMABLE-BOUNDARY-START(4297129991)
            /*void**/ _instancePointer;
            //--TRIMMABLE-BOUNDARY-END(4297129991)
            
            //--TRIMMABLE-BOUNDARY-START(12887064583)
            /*object?*/ _runtimeCallableWrapper = null;
            //--TRIMMABLE-BOUNDARY-END(12887064583)
            
            //--TRIMMABLE-BOUNDARY-START(8592097287)
            /*bool*/ _released = false;
            //--TRIMMABLE-BOUNDARY-END(8592097287)
            
            //--TRIMMABLE-BOUNDARY-START(21476999175)
            $ctor$1(/*IIUnknownInterfaceDetailsStrategy*/ interfaceDetailsStrategy, /*IIUnknownStrategy*/ iunknownStrategy, /*IIUnknownCacheStrategy*/ cacheStrategy, /*void**/ thisPointer)
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(21476999175);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this.InterfaceDetailsStrategy = interfaceDetailsStrategy;
                    this.IUnknownStrategy = iunknownStrategy;
                    this.CacheStrategy = cacheStrategy;
                    this._instancePointer = this.IUnknownStrategy.System$Runtime$InteropServices$Marshalling$IIUnknownStrategy$CreateInstancePointer(thisPointer);
                    if ($.$$.System.OperatingSystem.IsWindows() && $.$sris.System.Runtime.InteropServices.Marshalling.ComObject.BuiltInComSupported && $.$sris.System.Runtime.InteropServices.Marshalling.ComObject.ComImportInteropEnabled)
                    {
                        this._runtimeCallableWrapper = $.$$.System.Runtime.InteropServices.Marshal.GetObjectForIUnknown($.$$.System.IntPtr.op_Explicit$4(thisPointer));
                        $.$$.System.Diagnostics.Debug.Assert$2($.$$.System.Runtime.InteropServices.Marshal.IsComObject(this._runtimeCallableWrapper), "Marshal.IsComObject(_runtimeCallableWrapper)");
                    }
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(21476999175)
            
            $dtor()
            {
                this.CacheStrategy.System$Runtime$InteropServices$Marshalling$IIUnknownCacheStrategy$Clear(this.IUnknownStrategy);
                this.IUnknownStrategy.System$Runtime$InteropServices$Marshalling$IIUnknownStrategy$Release(this._instancePointer);
            }
            //--TRIMMABLE-BOUNDARY-START(124556214279)
            /*IIUnknownInterfaceDetailsStrategy*/ InterfaceDetailsStrategy = null;
            //--TRIMMABLE-BOUNDARY-END(124556214279)
            
            //--TRIMMABLE-BOUNDARY-START(128851181575)
            /*IIUnknownStrategy*/ IUnknownStrategy = null;
            //--TRIMMABLE-BOUNDARY-END(128851181575)
            
            //--TRIMMABLE-BOUNDARY-START(55836737543)
            /*IIUnknownCacheStrategy*/ CacheStrategy = null;
            //--TRIMMABLE-BOUNDARY-END(55836737543)
            
            //--TRIMMABLE-BOUNDARY-START(163210919943)
            /*bool*/ UniqueInstance = false;
            //--TRIMMABLE-BOUNDARY-END(163210919943)
            
            //--TRIMMABLE-BOUNDARY-START(68721639431)
            /*void */ FinalRelease()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(68721639431);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (this.UniqueInstance && !$.$$.System.Threading.Interlocked.Exchange$14($.$$.System.Boolean, $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateObjectReferenceT($.$$.System.Boolean, () => this._released, ($v) => this._released = $v, null), true))
                {
                    $.$$.System.GC.SuppressFinalize(this);
                    this.CacheStrategy.System$Runtime$InteropServices$Marshalling$IIUnknownCacheStrategy$Clear(this.IUnknownStrategy);
                    this.IUnknownStrategy.System$Runtime$InteropServices$Marshalling$IIUnknownStrategy$Release(this._instancePointer);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(68721639431)
            
            //--TRIMMABLE-BOUNDARY-START(ALL, 146031050759, 4437114881)
            /*RuntimeTypeHandle */ System$Runtime$InteropServices$IDynamicInterfaceCastable$GetInterfaceImplementation(/*RuntimeTypeHandle*/ interfaceType)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(146031050759);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*IIUnknownCacheStrategy.TableInfo*/ let info;
                /*int*/ let qiResult;
                if (!this.LookUpVTableInfo(interfaceType, $.$ref(() => info, ($v) => info = $v, $.$sris.System.Runtime.InteropServices.Marshalling.IIUnknownCacheStrategy.TableInfo), $.$ref(() => qiResult, ($v) => qiResult = $v, $.$$.System.Int32)))
                {
                    $.$$.System.Runtime.InteropServices.Marshal.ThrowExceptionForHR$2(qiResult);
                }
                return info.ManagedType;
            }
            //--TRIMMABLE-BOUNDARY-END(ALL, 146031050759, 4437114881)
            
            //--TRIMMABLE-BOUNDARY-START(ALL, 150326018055, 8732082177)
            /*bool */ System$Runtime$InteropServices$IDynamicInterfaceCastable$IsInterfaceImplemented(/*RuntimeTypeHandle*/ interfaceType, /*bool*/ throwIfNotImplemented)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(150326018055);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*int*/ let qiResult;
                if (!this.LookUpVTableInfo(interfaceType, $.$discardRef(), $.$ref(() => qiResult, ($v) => qiResult = $v, $.$$.System.Int32)))
                {
                    if (throwIfNotImplemented)
                    {
                        $.$$.System.Runtime.InteropServices.Marshal.ThrowExceptionForHR$2(qiResult);
                    }
                    return false;
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(ALL, 150326018055, 8732082177)
            
            //--TRIMMABLE-BOUNDARY-START(133146148871)
            /*bool */ LookUpVTableInfo(/*RuntimeTypeHandle*/ handle, /*out IIUnknownCacheStrategy.TableInfo*/ result, /*out int*/ qiHResult)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(133146148871);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.ObjectDisposedException.ThrowIf(this._released, this);
                qiHResult.$v = 0;
                if (!this.CacheStrategy.System$Runtime$InteropServices$Marshalling$IIUnknownCacheStrategy$TryGetTableInfo(handle, result))
                {
                    /*IIUnknownDerivedDetails?*/ let details = this.InterfaceDetailsStrategy.System$Runtime$InteropServices$Marshalling$IIUnknownInterfaceDetailsStrategy$GetIUnknownDerivedDetails(handle);
                    if (details === null)
                    {
                        return false;
                    }
                    /*void**/ let ppv;
                    /*int*/ let hr = this.IUnknownStrategy.System$Runtime$InteropServices$Marshalling$IIUnknownStrategy$QueryInterface(this._instancePointer, $.$ref(() => details.System$Runtime$InteropServices$Marshalling$IIUnknownDerivedDetails$Iid, ), $.$ref(() => ppv, ($v) => ppv = $v, $.$typePointer($.$$.System.Void)));
                    if (hr < 0)
                    {
                        qiHResult.$v = hr;
                        return false;
                    }
                    result.$v = this.CacheStrategy.System$Runtime$InteropServices$Marshalling$IIUnknownCacheStrategy$ConstructTableInfo(handle, details, ppv);
                    if (!this.CacheStrategy.System$Runtime$InteropServices$Marshalling$IIUnknownCacheStrategy$TrySetTableInfo(handle, result.$v))
                    {
                        /*bool*/ let found = this.CacheStrategy.System$Runtime$InteropServices$Marshalling$IIUnknownCacheStrategy$TryGetTableInfo(handle, result);
                        $.$$.System.Diagnostics.Debug.Assert$2(found, "found");
                        _ = this.IUnknownStrategy.System$Runtime$InteropServices$Marshalling$IIUnknownStrategy$Release(ppv);
                    }
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(133146148871)
            
            //--TRIMMABLE-BOUNDARY-START(ALL, 158915952647, 4298506247)
            /*VirtualMethodTableInfo */ System$Runtime$InteropServices$Marshalling$IUnmanagedVirtualMethodTableProvider$GetVirtualMethodTableInfoForKey(/*Type*/ type)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(158915952647);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*IIUnknownCacheStrategy.TableInfo*/ let result;
                /*int*/ let qiHResult;
                if (!this.LookUpVTableInfo(type.TypeHandle, $.$ref(() => result, ($v) => result = $v, $.$sris.System.Runtime.InteropServices.Marshalling.IIUnknownCacheStrategy.TableInfo), $.$ref(() => qiHResult, ($v) => qiHResult = $v, $.$$.System.Int32)))
                {
                    $.$$.System.Runtime.InteropServices.Marshal.ThrowExceptionForHR$2(qiHResult);
                }
                return new $.$sris.System.Runtime.InteropServices.Marshalling.VirtualMethodTableInfo().$ctor$3(result.ThisPtr, result.Table);
            }
            //--TRIMMABLE-BOUNDARY-END(ALL, 158915952647, 4298506247)
            
            //--TRIMMABLE-BOUNDARY-START(ALL, 154620985351, 8591900679)
            /*object */ System$Runtime$InteropServices$Marshalling$ComImportInteropInterfaceDetailsStrategy$IComImportAdapter$GetRuntimeCallableWrapper()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(154620985351);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.Diagnostics.Debug.Assert$2(this._runtimeCallableWrapper !== null, "_runtimeCallableWrapper != null");
                return this._runtimeCallableWrapper;
            }
            //--TRIMMABLE-BOUNDARY-END(ALL, 154620985351, 8591900679)
            
            //default member initializer
            constructor()
            {
                super();
                //--TRIMMABLE-BOUNDARY-START(4297129991)
                this._instancePointer = $.$default($.$typePointer($.$$.System.Void));
                //--TRIMMABLE-BOUNDARY-END(4297129991)
                
                $.$finalizer(this);
            }
            //--TRIMMABLE-BOUNDARY-START(17182031879)
            //Static Initializer
            static $sinit()
            {
                {
                    /*bool*/ let supported;
                    this.BuiltInComSupported = $.$$.System.AppContext.TryGetSwitch("System.Runtime.InteropServices.BuiltInComInterop.IsSupported", $.$ref(() => supported, ($v) => supported = $v, $.$$.System.Boolean)) ? supported : true;
                }
                {
                    /*bool*/ let enabled;
                    this.ComImportInteropEnabled = $.$$.System.AppContext.TryGetSwitch("System.Runtime.InteropServices.Marshalling.EnableGeneratedComInterfaceComImportInterop", $.$ref(() => enabled, ($v) => enabled = $v, $.$$.System.Boolean)) ? enabled : false;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(17182031879)
            
            static $h = 2162695;
            static $f = 0b10010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 131073,
  "p": [
//--TRIMMABLE-BOUNDARY-START(51541770247),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 77311574023,
        "f": 50331688
      },
      "n": "BuiltInComSupported",
      "d": 2162695,
      "h": 51541770247,
      "f": 2097192
    },
//--TRIMMABLE-BOUNDARY-END(51541770247),
//--TRIMMABLE-BOUNDARY-START(60131704839),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 94491443207,
        "f": 50331688
      },
      "n": "ComImportInteropEnabled",
      "d": 2162695,
      "h": 60131704839,
      "f": 2097192
    },
//--TRIMMABLE-BOUNDARY-END(60131704839),
//--TRIMMABLE-BOUNDARY-START(124556214279),
    {
      "p": 3276807,
      "g": {
        "r": 0,
        "d": 0,
        "h": 103081377799,
        "f": 50331650
      },
      "n": "InterfaceDetailsStrategy",
      "d": 2162695,
      "h": 124556214279,
      "f": 2097154
    },
//--TRIMMABLE-BOUNDARY-END(124556214279),
//--TRIMMABLE-BOUNDARY-START(128851181575),
    {
      "p": 3407879,
      "g": {
        "r": 0,
        "d": 0,
        "h": 111671312391,
        "f": 50331650
      },
      "n": "IUnknownStrategy",
      "d": 2162695,
      "h": 128851181575,
      "f": 2097154
    },
//--TRIMMABLE-BOUNDARY-END(128851181575),
//--TRIMMABLE-BOUNDARY-START(55836737543),
    {
      "p": 3080199,
      "g": {
        "r": 0,
        "d": 0,
        "h": 85901508615,
        "f": 50331650
      },
      "n": "CacheStrategy",
      "d": 2162695,
      "h": 55836737543,
      "f": 2097154
    },
//--TRIMMABLE-BOUNDARY-END(55836737543),
//--TRIMMABLE-BOUNDARY-START(163210919943),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 120261246983,
        "f": 50331656
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 141736083463,
        "f": 83886088
      },
      "n": "UniqueInstance",
      "d": 2162695,
      "h": 163210919943,
      "f": 2097160
    },
//--TRIMMABLE-BOUNDARY-END(163210919943)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(68721639431),
    {
      "r": 65537,
      "n": "FinalRelease",
      "d": 2162695,
      "h": 68721639431,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(68721639431),
//--TRIMMABLE-BOUNDARY-START(133146148871),
    {
      "r": 262145,
      "p": [
        {
          "n": "handle",
          "p": 160038913
        },
        {
          "n": "result",
          "p": 3145735,
          "f": 2
        },
        {
          "n": "qiHResult",
          "p": 655361,
          "f": 2
        }
      ],
      "n": "LookUpVTableInfo",
      "d": 2162695,
      "h": 133146148871,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(133146148871)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(4297129991),
    {
      "t": $.$typePointer($.$$.System.Void).$h,
      "n": "_instancePointer",
      "d": 2162695,
      "h": 4297129991,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(4297129991),
//--TRIMMABLE-BOUNDARY-START(12887064583),
    {
      "t": 131073,
      "n": "_runtimeCallableWrapper",
      "d": 2162695,
      "h": 12887064583,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(12887064583),
//--TRIMMABLE-BOUNDARY-START(8592097287),
    {
      "t": 262145,
      "n": "_released",
      "d": 2162695,
      "h": 8592097287,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(8592097287)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(21476999175),
    {
      "p": [
        {
          "n": "interfaceDetailsStrategy",
          "p": 3276807
        },
        {
          "n": "iunknownStrategy",
          "p": 3407879
        },
        {
          "n": "cacheStrategy",
          "p": 3080199
        },
        {
          "n": "thisPointer",
          "p": $.$typePointer($.$$.System.Void).$h
        }
      ],
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 2162695,
      "h": 21476999175,
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(21476999175)
  ],
  "i": [142147585,3538951,1966087
  ],
  "h": 2162695
}; }
            static get $b() { return $.$$.System.Object; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.System.Runtime.InteropServices.IDynamicInterfaceCastable, $.$sris.System.Runtime.InteropServices.Marshalling.IUnmanagedVirtualMethodTableProvider, $.$sris.System.Runtime.InteropServices.Marshalling.ComImportInteropInterfaceDetailsStrategy.IComImportAdapter ]; }
            static get $fullName() { return `System.Runtime.InteropServices.Marshalling.ComObject`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2162695)
	});
})(window, window.NetJs.$boot(), ...window.NetJs.$require("NetJs.System.Private.CoreLib", "NetJs.System.Collections", "NetJs.System.Diagnostics.Tracing", "NetJs.System.Threading", "NetJs.System.Collections.Concurrent"))
//--TRIMMABLE-BOUNDARY-END(7)
