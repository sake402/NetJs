
(function ($global, $, $$, $sc, $sdt, $st, $scc) {
    "use strict";
    let _;
    
    
    
	$.$asm(
    "NetJs.System.Runtime.InteropServices", 
    {"h":54845,"f":"System.Runtime.InteropServices","v":"1.0.35.0","a":[{"t":115015681,"c":12999917569,"a":[{"v":".NETCoreApp,Version=v10.0","t":1310721}],"n":[{"n":"FrameworkDisplayName","v":".NET 10.0","t":1310721}]},{"t":73596929,"c":4368564225,"a":[{"v":"SIT","t":1310721}]},{"t":73662465,"c":4368629761,"a":[{"v":"Debug","t":1310721}]},{"t":74121217,"c":4369088513,"a":[{"v":"1.0.35.0","t":1310721}]},{"t":74252289,"c":4369219585,"a":[{"v":"1.0.35\u002Beff628fa5ab8bd29ec37e9c13a50148694bea088","t":1310721}]},{"t":75104257,"c":4370071553,"a":[{"v":"NetJs.System.Runtime.InteropServices","t":1310721}]},{"t":75235329,"c":4370202625,"a":[{"v":"NetJs.System.Runtime.InteropServices","t":1310721}]},{"t":75366401,"c":4370333697,"a":[{"v":"1.0.35.0","t":1310721}]},{"t":115081217,"c":4410048513,"a":[{"v":"browser1.0","t":1310721}]},{"t":114819073,"c":4409786369,"a":[{"v":"browser1.0","t":1310721}]}],"m":[]},
    function($asm)
	{
        
        
        $asm.$cls("$sris.System.Runtime.InteropServices.ComTypes.IAdviseSink", ($self) => class IAdviseSink
        {
            static $h = 1037885;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {"m":[{"r":65537,"p":[{"n":"format","p":972349,"f":4,"a":[{"t":104726529,"c":4399693825}]},{"n":"stgmedium","p":1365565,"f":4,"a":[{"t":104726529,"c":4399693825}]}],"n":"OnDataChange","o":"System$Runtime$InteropServices$ComTypes$IAdviseSink$OnDataChange","d":1037885,"h":4296005181,"f":16777473,"a":[{"t":109051905,"c":4404019201}]},{"r":65537,"p":[{"n":"aspect","p":655361},{"n":"index","p":655361}],"n":"OnViewChange","o":"System$Runtime$InteropServices$ComTypes$IAdviseSink$OnViewChange","d":1037885,"h":8590972477,"f":16777473,"a":[{"t":109051905,"c":4404019201}]},{"r":65537,"p":[{"n":"moniker","p":100794369}],"n":"OnRename","o":"System$Runtime$InteropServices$ComTypes$IAdviseSink$OnRename","d":1037885,"h":12885939773,"f":16777473,"a":[{"t":109051905,"c":4404019201}]},{"r":65537,"n":"OnSave","o":"System$Runtime$InteropServices$ComTypes$IAdviseSink$OnSave","d":1037885,"h":17180907069,"f":16777473,"a":[{"t":109051905,"c":4404019201}]},{"r":65537,"n":"OnClose","o":"System$Runtime$InteropServices$ComTypes$IAdviseSink$OnClose","d":1037885,"h":21475874365,"f":16777473,"a":[{"t":109051905,"c":4404019201}]}],"h":1037885,"a":[{"t":99024897,"c":4393992193},{"t":104267777,"c":4399235073,"a":[{"v":"0000010F-0000-0000-C000-000000000046","t":1310721}]},{"t":33292289,"c":4328259585,"a":[{"v":1,"t":33357825}]},{"t":104792065,"c":4399759361,"a":[{"v":1,"t":99090433}]}]}; }
            static get $fullName() { return `System.Runtime.InteropServices.ComTypes.IAdviseSink`; }
        });
        
        $asm.$cls("$sris.System.Runtime.InteropServices.ComTypes.IDataObject", ($self) => class IDataObject
        {
            static $h = 1103421;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {"m":[{"r":65537,"p":[{"n":"format","p":972349,"f":4,"a":[{"t":104726529,"c":4399693825}]},{"n":"medium","p":1365565,"f":2}],"n":"GetData","o":"System$Runtime$InteropServices$ComTypes$IDataObject$GetData","d":1103421,"h":4296070717,"f":16777473},{"r":65537,"p":[{"n":"format","p":972349,"f":4,"a":[{"t":104726529,"c":4399693825}]},{"n":"medium","p":1365565,"f":4}],"n":"GetDataHere","o":"System$Runtime$InteropServices$ComTypes$IDataObject$GetDataHere","d":1103421,"h":8591038013,"f":16777473},{"r":655361,"p":[{"n":"format","p":972349,"f":4,"a":[{"t":104726529,"c":4399693825}]}],"n":"QueryGetData","o":"System$Runtime$InteropServices$ComTypes$IDataObject$QueryGetData","d":1103421,"h":12886005309,"f":16777473,"a":[{"t":109051905,"c":4404019201}]},{"r":655361,"p":[{"n":"formatIn","p":972349,"f":4,"a":[{"t":104726529,"c":4399693825}]},{"n":"formatOut","p":972349,"f":2}],"n":"GetCanonicalFormatEtc","o":"System$Runtime$InteropServices$ComTypes$IDataObject$GetCanonicalFormatEtc","d":1103421,"h":17180972605,"f":16777473,"a":[{"t":109051905,"c":4404019201}]},{"r":65537,"p":[{"n":"formatIn","p":972349,"f":4,"a":[{"t":104726529,"c":4399693825}]},{"n":"medium","p":1365565,"f":4,"a":[{"t":104726529,"c":4399693825}]},{"n":"release","p":262145,"a":[{"t":105578497,"c":8695513089,"a":[{"v":2,"t":110755841}]}]}],"n":"SetData","o":"System$Runtime$InteropServices$ComTypes$IDataObject$SetData","d":1103421,"h":21475939901,"f":16777473},{"r":1168957,"p":[{"n":"direction","p":841277}],"n":"EnumFormatEtc","o":"System$Runtime$InteropServices$ComTypes$IDataObject$EnumFormatEtc","d":1103421,"h":25770907197,"f":16777473},{"r":655361,"p":[{"n":"pFormatetc","p":972349,"f":4,"a":[{"t":104726529,"c":4399693825}]},{"n":"advf","p":775741},{"n":"adviseSink","p":1037885},{"n":"connection","p":655361,"f":2}],"n":"DAdvise","o":"System$Runtime$InteropServices$ComTypes$IDataObject$DAdvise","d":1103421,"h":30065874493,"f":16777473,"a":[{"t":109051905,"c":4404019201}]},{"r":65537,"p":[{"n":"connection","p":655361}],"n":"DUnadvise","o":"System$Runtime$InteropServices$ComTypes$IDataObject$DUnadvise","d":1103421,"h":34360841789,"f":16777473},{"r":655361,"p":[{"n":"enumAdvise","p":1234493,"f":2}],"n":"EnumDAdvise","o":"System$Runtime$InteropServices$ComTypes$IDataObject$EnumDAdvise","d":1103421,"h":38655809085,"f":16777473,"a":[{"t":109051905,"c":4404019201}]}],"h":1103421,"a":[{"t":23527425,"c":8613462017,"a":[{"v":false,"t":262145}]},{"t":99024897,"c":4393992193},{"t":104267777,"c":4399235073,"a":[{"v":"0000010E-0000-0000-C000-000000000046","t":1310721}]},{"t":104792065,"c":4399759361,"a":[{"v":1,"t":99090433}]}]}; }
            static get $fullName() { return `System.Runtime.InteropServices.ComTypes.IDataObject`; }
        });
        
        $asm.$cls("$sris.System.Runtime.InteropServices.ComTypes.IEnumFORMATETC", ($self) => class IEnumFORMATETC
        {
            static $h = 1168957;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {"m":[{"r":655361,"p":[{"n":"celt","p":655361},{"n":"rgelt","p":$.$typeArray($.$sris.System.Runtime.InteropServices.ComTypes.FORMATETC).$h,"a":[{"t":108658689,"c":4403625985},{"t":105578497,"c":8695513089,"a":[{"v":42,"t":110755841}],"n":[{"n":"SizeParamIndex","v":0,"t":524289}]}]},{"n":"pceltFetched","p":$.$typeArray($.$$.System.Int32).$h,"a":[{"t":108658689,"c":4403625985},{"t":105578497,"c":8695513089,"a":[{"v":42,"t":110755841}]}]}],"n":"Next","o":"System$Runtime$InteropServices$ComTypes$IEnumFORMATETC$Next","d":1168957,"h":4296136253,"f":16777473,"a":[{"t":109051905,"c":4404019201}]},{"r":655361,"p":[{"n":"celt","p":655361}],"n":"Skip","o":"System$Runtime$InteropServices$ComTypes$IEnumFORMATETC$Skip","d":1168957,"h":8591103549,"f":16777473,"a":[{"t":109051905,"c":4404019201}]},{"r":655361,"n":"Reset","o":"System$Runtime$InteropServices$ComTypes$IEnumFORMATETC$Reset","d":1168957,"h":12886070845,"f":16777473,"a":[{"t":109051905,"c":4404019201}]},{"r":65537,"p":[{"n":"newEnum","p":1168957,"f":2}],"n":"Clone","o":"System$Runtime$InteropServices$ComTypes$IEnumFORMATETC$Clone","d":1168957,"h":17181038141,"f":16777473}],"h":1168957,"a":[{"t":99024897,"c":4393992193},{"t":104267777,"c":4399235073,"a":[{"v":"00000103-0000-0000-C000-000000000046","t":1310721}]},{"t":33292289,"c":4328259585,"a":[{"v":1,"t":33357825}]},{"t":104792065,"c":4399759361,"a":[{"v":1,"t":99090433}]}]}; }
            static get $fullName() { return `System.Runtime.InteropServices.ComTypes.IEnumFORMATETC`; }
        });
        
        $asm.$cls("$sris.System.Runtime.InteropServices.ComTypes.IEnumSTATDATA", ($self) => class IEnumSTATDATA
        {
            static $h = 1234493;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {"m":[{"r":655361,"p":[{"n":"celt","p":655361},{"n":"rgelt","p":$.$typeArray($.$sris.System.Runtime.InteropServices.ComTypes.STATDATA).$h,"a":[{"t":108658689,"c":4403625985},{"t":105578497,"c":8695513089,"a":[{"v":42,"t":110755841}],"n":[{"n":"SizeParamIndex","v":0,"t":524289}]}]},{"n":"pceltFetched","p":$.$typeArray($.$$.System.Int32).$h,"a":[{"t":108658689,"c":4403625985},{"t":105578497,"c":8695513089,"a":[{"v":42,"t":110755841}],"n":[{"n":"SizeConst","v":1,"t":655361}]}]}],"n":"Next","o":"System$Runtime$InteropServices$ComTypes$IEnumSTATDATA$Next","d":1234493,"h":4296201789,"f":16777473,"a":[{"t":109051905,"c":4404019201}]},{"r":655361,"p":[{"n":"celt","p":655361}],"n":"Skip","o":"System$Runtime$InteropServices$ComTypes$IEnumSTATDATA$Skip","d":1234493,"h":8591169085,"f":16777473,"a":[{"t":109051905,"c":4404019201}]},{"r":655361,"n":"Reset","o":"System$Runtime$InteropServices$ComTypes$IEnumSTATDATA$Reset","d":1234493,"h":12886136381,"f":16777473,"a":[{"t":109051905,"c":4404019201}]},{"r":65537,"p":[{"n":"newEnum","p":1234493,"f":2}],"n":"Clone","o":"System$Runtime$InteropServices$ComTypes$IEnumSTATDATA$Clone","d":1234493,"h":17181103677,"f":16777473}],"h":1234493,"a":[{"t":99024897,"c":4393992193},{"t":104267777,"c":4399235073,"a":[{"v":"00000105-0000-0000-C000-000000000046","t":1310721}]},{"t":104792065,"c":4399759361,"a":[{"v":1,"t":99090433}]}]}; }
            static get $fullName() { return `System.Runtime.InteropServices.ComTypes.IEnumSTATDATA`; }
        });
        
        $asm.$cls("$sris.System.Runtime.InteropServices.Marshalling.IIUnknownInterfaceDetailsStrategy", ($self) => class IIUnknownInterfaceDetailsStrategy
        {
            static $h = 3331645;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {"m":[{"r":3266109,"p":[{"n":"type","p":115933185}],"n":"GetIUnknownDerivedDetails","o":"System$Runtime$InteropServices$Marshalling$IIUnknownInterfaceDetailsStrategy$GetIUnknownDerivedDetails","d":3331645,"h":4298298941,"f":16777473},{"r":3069501,"p":[{"n":"type","p":115933185}],"n":"GetComExposedTypeDetails","o":"System$Runtime$InteropServices$Marshalling$IIUnknownInterfaceDetailsStrategy$GetComExposedTypeDetails","d":3331645,"h":8593266237,"f":16777473}],"h":3331645,"a":[{"t":23527425,"c":8613462017,"a":[{"v":false,"t":262145}]}]}; }
            static get $fullName() { return `System.Runtime.InteropServices.Marshalling.IIUnknownInterfaceDetailsStrategy`; }
        });
        
        $asm.$cls("$sris.System.Runtime.InteropServices.Marshalling.IIUnknownDerivedDetails", ($self) => class IIUnknownDerivedDetails
        {
            static /*IIUnknownDerivedDetails? */ System$Runtime$InteropServices$Marshalling$IIUnknownDerivedDetails$GetFromAttribute(/*RuntimeTypeHandle*/ handle)
            {
                /*var*/ let type = $.$$.System.Type.GetTypeFromHandle(handle);
                if (type === null)
                {
                    return null;
                }
                return $.$cast($.$$.System.Reflection.CustomAttributeExtensions.GetCustomAttribute$2(type, $.$sris.System.Runtime.InteropServices.Marshalling.IUnknownDerivedAttribute$$$().$type), $.$sris.System.Runtime.InteropServices.Marshalling.IIUnknownDerivedDetails);
            }
            static $h = 3266109;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {"p":[{"p":56229889,"g":{"r":0,"d":0,"h":8593200701,"f":50331905},"n":"Iid","o":"System$Runtime$InteropServices$Marshalling$IIUnknownDerivedDetails$Iid","d":3266109,"h":4298233405,"f":2097409},{"p":142475265,"g":{"r":0,"d":0,"h":17183135293,"f":50331905},"n":"Implementation","o":"System$Runtime$InteropServices$Marshalling$IIUnknownDerivedDetails$Implementation","d":3266109,"h":12888167997,"f":2097409},{"p":$.$typePointer($.$typePointer($.$$.System.Void)).$h,"g":{"r":0,"d":0,"h":25773069885,"f":50331905},"n":"ManagedVirtualMethodTable","o":"System$Runtime$InteropServices$Marshalling$IIUnknownDerivedDetails$ManagedVirtualMethodTable","d":3266109,"h":21478102589,"f":2097409}],"m":[{"r":3266109,"p":[{"n":"handle","p":115933185}],"n":"GetFromAttribute","o":"System$Runtime$InteropServices$Marshalling$IIUnknownDerivedDetails$GetFromAttribute","d":3266109,"h":30068037181,"f":16777256}],"h":3266109,"a":[{"t":23527425,"c":8613462017,"a":[{"v":false,"t":262145}]}]}; }
            static get $fullName() { return `System.Runtime.InteropServices.Marshalling.IIUnknownDerivedDetails`; }
        });
        
        $asm.$cls("$sris.System.Runtime.InteropServices.Marshalling.IIUnknownStrategy", ($self) => class IIUnknownStrategy
        {
            static $h = 3462717;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {"m":[{"r":$.$typePointer($.$$.System.Void).$h,"p":[{"n":"unknown","p":$.$typePointer($.$$.System.Void).$h}],"n":"CreateInstancePointer","o":"System$Runtime$InteropServices$Marshalling$IIUnknownStrategy$CreateInstancePointer","d":3462717,"h":4298430013,"f":16777473},{"r":655361,"p":[{"n":"instancePtr","p":$.$typePointer($.$$.System.Void).$h},{"n":"iid","p":56229889,"f":8},{"n":"ppObj","p":$.$typePointer($.$$.System.Void).$h,"f":2}],"n":"QueryInterface","o":"System$Runtime$InteropServices$Marshalling$IIUnknownStrategy$QueryInterface","d":3462717,"h":8593397309,"f":16777473},{"r":655361,"p":[{"n":"instancePtr","p":$.$typePointer($.$$.System.Void).$h}],"n":"Release","o":"System$Runtime$InteropServices$Marshalling$IIUnknownStrategy$Release","d":3462717,"h":12888364605,"f":16777473}],"h":3462717,"a":[{"t":23527425,"c":8613462017,"a":[{"v":false,"t":262145}]}]}; }
            static get $fullName() { return `System.Runtime.InteropServices.Marshalling.IIUnknownStrategy`; }
        });
        
        $asm.$cls("$sris.System.Runtime.InteropServices.Marshalling.IIUnknownInterfaceType", ($self) => class IIUnknownInterfaceType
        {
            static $h = 3397181;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {"p":[{"p":56229889,"g":{"r":0,"d":0,"h":8593331773,"f":50331937},"n":"Iid","o":"System$Runtime$InteropServices$Marshalling$IIUnknownInterfaceType$Iid","d":3397181,"h":4298364477,"f":2097441},{"p":$.$typePointer($.$typePointer($.$$.System.Void)).$h,"g":{"r":0,"d":0,"h":17183266365,"f":50331937},"n":"ManagedVirtualMethodTable","o":"System$Runtime$InteropServices$Marshalling$IIUnknownInterfaceType$ManagedVirtualMethodTable","d":3397181,"h":12888299069,"f":2097441}],"h":3397181,"a":[{"t":23527425,"c":8613462017,"a":[{"v":false,"t":262145}]}]}; }
            static get $fullName() { return `System.Runtime.InteropServices.Marshalling.IIUnknownInterfaceType`; }
        });
        
        $asm.$cls("$sris.System.Runtime.InteropServices.Marshalling.IUnmanagedVirtualMethodTableProvider", ($self) => class IUnmanagedVirtualMethodTableProvider
        {
            static $h = 3593789;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {"m":[{"r":3790397,"p":[{"n":"type","p":142475265}],"n":"GetVirtualMethodTableInfoForKey","o":"System$Runtime$InteropServices$Marshalling$IUnmanagedVirtualMethodTableProvider$GetVirtualMethodTableInfoForKey","d":3593789,"h":4298561085,"f":16777473}],"h":3593789,"a":[{"t":23527425,"c":8613462017,"a":[{"v":false,"t":262145}]}]}; }
            static get $fullName() { return `System.Runtime.InteropServices.Marshalling.IUnmanagedVirtualMethodTableProvider`; }
        });
        
        $asm.$cls("$sris.System.Runtime.InteropServices.Marshalling.IComExposedDetails", ($self) => class IComExposedDetails
        {
            static /*IComExposedDetails? */ System$Runtime$InteropServices$Marshalling$IComExposedDetails$GetFromAttribute(/*RuntimeTypeHandle*/ handle)
            {
                /*var*/ let type = $.$$.System.Type.GetTypeFromHandle(handle);
                if (type === null)
                {
                    return null;
                }
                return $.$cast($.$$.System.Reflection.CustomAttributeExtensions.GetCustomAttribute$2(type, $.$sris.System.Runtime.InteropServices.Marshalling.ComExposedClassAttribute$$().$type), $.$sris.System.Runtime.InteropServices.Marshalling.IComExposedDetails);
            }
            static $h = 3069501;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {"m":[{"r":$.$typePointer($.$$.System.Runtime.InteropServices.ComWrappers.ComInterfaceEntry).$h,"p":[{"n":"count","p":655361,"f":2}],"n":"GetComInterfaceEntries","o":"System$Runtime$InteropServices$Marshalling$IComExposedDetails$GetComInterfaceEntries","d":3069501,"h":4298036797,"f":16777473},{"r":3069501,"p":[{"n":"handle","p":115933185}],"n":"GetFromAttribute","o":"System$Runtime$InteropServices$Marshalling$IComExposedDetails$GetFromAttribute","d":3069501,"h":8593004093,"f":16777256}],"h":3069501,"a":[{"t":23527425,"c":8613462017,"a":[{"v":false,"t":262145}]}]}; }
            static get $fullName() { return `System.Runtime.InteropServices.Marshalling.IComExposedDetails`; }
        });
        
        $asm.$cls("$sris.System.Runtime.InteropServices.Marshalling.IIUnknownCacheStrategy", ($self) => class IIUnknownCacheStrategy
        {
            static $_TableInfo;
            static get TableInfo()
            {
                let $cls = $.$sris.System.Runtime.InteropServices.Marshalling.IIUnknownCacheStrategy;
                return $cls.$_TableInfo ??= $asm.$nstr("$sris.System.Runtime.InteropServices.Marshalling.IIUnknownCacheStrategy.TableInfo", ($self) => class TableInfo extends $.$$.System.ValueType
                {
                    /*void**/ ThisPtr;
                    /*void***/ Table;
                    /*RuntimeTypeHandle*/ ManagedType;
                    //default value type constructor
                    $ctor$2()
                    {
                        return this;
                    }
                    Clone($copy)
                    {
                        let copy = $copy ?? new this.constructor();
                        copy.ThisPtr = this.ThisPtr.Clone();
                        copy.Table = this.Table.Clone();
                        copy.ManagedType = this.ManagedType.Clone();
                        return copy;
                    }
                    //default member initializer
                    constructor()
                    {
                        super();
                        this.ThisPtr = $.$default($.$typePointer($.$$.System.Void));
                        this.Table = $.$default($.$typePointer($.$typePointer($.$$.System.Void)));
                        this.ManagedType = $.$default($.$$.System.RuntimeTypeHandle);
                    }
                    static $h = 3200573;
                    static $z = 12;
                    static $f = 0b10000001010000001;
                    static $k = 2;
                    static $$md;
                    static get $md() { return this.$$md ??= {"b":196609,"p":[{"p":$.$typePointer($.$$.System.Void).$h,"g":{"r":0,"d":0,"h":12888102461,"f":50331649},"s":{"r":0,"d":0,"h":17183069757,"f":83886081},"n":"ThisPtr","d":3200573,"h":8593135165,"f":2097153},{"p":$.$typePointer($.$typePointer($.$$.System.Void)).$h,"g":{"r":0,"d":0,"h":30067971645,"f":50331649},"s":{"r":0,"d":0,"h":34362938941,"f":83886081},"n":"Table","d":3200573,"h":25773004349,"f":2097153},{"p":115933185,"g":{"r":0,"d":0,"h":47247840829,"f":50331649},"s":{"r":0,"d":0,"h":51542808125,"f":83886081},"n":"ManagedType","d":3200573,"h":42952873533,"f":2097153}],"c":[{"n":".ctor","o":"$ctor$2","d":3200573,"h":55837775421,"f":16777217}],"d":3135037,"h":3200573}; }
                    static get $b() { return $.$$.System.ValueType; }
                    static get $fullName() { return `System.Runtime.InteropServices.Marshalling.IIUnknownCacheStrategy.TableInfo`; }
                }, $cls, ($v) => $cls.$_TableInfo = $v);
            }
            static $h = 3135037;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {"m":[{"r":3200573,"p":[{"n":"handle","p":115933185},{"n":"interfaceDetails","p":3266109},{"n":"ptr","p":$.$typePointer($.$$.System.Void).$h}],"n":"ConstructTableInfo","o":"System$Runtime$InteropServices$Marshalling$IIUnknownCacheStrategy$ConstructTableInfo","d":3135037,"h":8593069629,"f":16777473},{"r":262145,"p":[{"n":"handle","p":115933185},{"n":"info","p":3200573,"f":2}],"n":"TryGetTableInfo","o":"System$Runtime$InteropServices$Marshalling$IIUnknownCacheStrategy$TryGetTableInfo","d":3135037,"h":12888036925,"f":16777473},{"r":262145,"p":[{"n":"handle","p":115933185},{"n":"info","p":3200573}],"n":"TrySetTableInfo","o":"System$Runtime$InteropServices$Marshalling$IIUnknownCacheStrategy$TrySetTableInfo","d":3135037,"h":17183004221,"f":16777473},{"r":65537,"p":[{"n":"unknownStrategy","p":3462717}],"n":"Clear","o":"System$Runtime$InteropServices$Marshalling$IIUnknownCacheStrategy$Clear","d":3135037,"h":21477971517,"f":16777473}],"j":[3200573],"h":3135037,"a":[{"t":23527425,"c":8613462017,"a":[{"v":false,"t":262145}]}]}; }
            static get $fullName() { return `System.Runtime.InteropServices.Marshalling.IIUnknownCacheStrategy`; }
        });
        
        $asm.$cls("$sris.System.Runtime.InteropServices.Marshalling.IComExposedClass", ($self) => class IComExposedClass
        {
            static $h = 3003965;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {"m":[{"r":$.$typePointer($.$$.System.Runtime.InteropServices.ComWrappers.ComInterfaceEntry).$h,"p":[{"n":"count","p":655361,"f":2}],"n":"GetComInterfaceEntries","o":"System$Runtime$InteropServices$Marshalling$IComExposedClass$GetComInterfaceEntries","d":3003965,"h":4297971261,"f":16777505}],"h":3003965,"a":[{"t":23527425,"c":8613462017,"a":[{"v":false,"t":262145}]}]}; }
            static get $fullName() { return `System.Runtime.InteropServices.Marshalling.IComExposedClass`; }
        });
        
        $asm.$cls("$sris.System.Runtime.InteropServices.Marshalling.ComInterfaceMarshaller<>", (T) => $asm.$gt("$sris.System.Runtime.InteropServices.Marshalling.ComInterfaceMarshaller<>", [T], ($self) => class ComInterfaceMarshaller$$
        {
            /*Guid?*/ static TargetInterfaceIID = null;
            static /*void* */ ConvertToUnmanaged(/*T?*/ managed)
            {
                if ($.$box(managed, T) === null)
                {
                    return null;
                }
                /*nint*/ let unknown;
                if (!$.$$.System.Runtime.InteropServices.ComWrappers.TryGetComInstance($.$box(managed, T), $.$ref(() => unknown, ($v) => unknown = $v, $.$$.System.IntPtr)))
                {
                    unknown = $.$sris.System.Runtime.InteropServices.Marshalling.StrategyBasedComWrappers.DefaultMarshallingInstance.GetOrCreateComInterfaceForObject($.$box(managed, T), 0/*CreateComInterfaceFlags.None*/);
                }
                return $.$sris.System.Runtime.InteropServices.Marshalling.ComInterfaceMarshaller$$(T).CastIUnknownToInterfaceType(unknown);
            }
            static /*T? */ ConvertToManaged(/*void**/ unmanaged)
            {
                if (unmanaged === null)
                {
                    return $.$default(T);
                }
                return $.$cast($.$sris.System.Runtime.InteropServices.Marshalling.StrategyBasedComWrappers.DefaultMarshallingInstance.GetOrCreateObjectForComInstance$1($.$$.System.IntPtr.op_Explicit$4(unmanaged), 8/*CreateObjectFlags.Unwrap*/), T);
            }
            static /*void */ Free(/*void**/ unmanaged)
            {
                if (unmanaged !== null)
                {
                    $.$$.System.Runtime.InteropServices.Marshal.Release($.$$.System.IntPtr.op_Explicit$4(unmanaged));
                }
            }
            static /*void* */ CastIUnknownToInterfaceType(/*nint*/ unknown)
            {
                if ($.$sris.System.Runtime.InteropServices.Marshalling.ComInterfaceMarshaller$$(T).TargetInterfaceIID === null)
                {
                    return $.$$.System.IntPtr.op_Explicit$5(unknown);
                }
                /*nint*/ let interfacePointer;
                if ($.$$.System.Runtime.InteropServices.Marshal.QueryInterface(unknown, $.$$.System.Nullable.GetValueRefOrDefaultRef($.$$.System.Guid, $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateObjectReferenceT($.$typeNullable($.$$.System.Guid), () => $.$sris.System.Runtime.InteropServices.Marshalling.ComInterfaceMarshaller$$(T).TargetInterfaceIID, ($v) => $.$sris.System.Runtime.InteropServices.Marshalling.ComInterfaceMarshaller$$(T).TargetInterfaceIID = $v, null)), $.$ref(() => interfacePointer, ($v) => interfacePointer = $v, $.$$.System.IntPtr)) !== 0)
                {
                    $.$$.System.Runtime.InteropServices.Marshal.Release(unknown);
                    throw new $.$$.System.InvalidCastException().$ctor$13((() =>
                    {
                        var $handler = new $.$$.System.Runtime.CompilerServices.DefaultInterpolatedStringHandler().$ctor$5(2, 1);
                        $handler.AppendLiteral("Unable to cast the provided managed object to a COM interface with ID '");
                        $handler.AppendFormatted($.$box($.$$.System.Nullable$$($.$$.System.Guid).GetValueOrDefault.call($.$sris.System.Runtime.InteropServices.Marshalling.ComInterfaceMarshaller$$(T).TargetInterfaceIID), $.$$.System.Guid), null, "B");
                        $handler.AppendLiteral("'");
                        return $handler.ToStringAndClear                ();
                    })());
                }
                $.$$.System.Runtime.InteropServices.Marshal.Release(unknown);
                return $.$$.System.IntPtr.op_Explicit$5(interfacePointer);
            }
            //Static Initializer
            static $sinit()
            {
                {
                    this.TargetInterfaceIID = ($.$sris.System.Runtime.InteropServices.Marshalling.StrategyBasedComWrappers.DefaultIUnknownInterfaceDetailsStrategy.System$Runtime$InteropServices$Marshalling$IIUnknownInterfaceDetailsStrategy$GetIUnknownDerivedDetails(T.$type.TypeHandle)?.System$Runtime$InteropServices$Marshalling$IIUnknownDerivedDetails$Iid ?? null);
                }
            }
            static $h = 2086461;
            static $g = 1;
            static $f = 0b1010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"m":[{"r":$.$typePointer($.$$.System.Void).$h,"p":[{"n":"managed","p":T?.$h??1507328}],"n":"ConvertToUnmanaged","d":this.$h,"h":Number(BigInt(this.$h)|0x200000000n),"f":16777249},{"r":T?.$h??1507328,"p":[{"n":"unmanaged","p":$.$typePointer($.$$.System.Void).$h}],"n":"ConvertToManaged","d":this.$h,"h":Number(BigInt(this.$h)|0x300000000n),"f":16777249},{"r":65537,"p":[{"n":"unmanaged","p":$.$typePointer($.$$.System.Void).$h}],"n":"Free","d":this.$h,"h":Number(BigInt(this.$h)|0x400000000n),"f":16777249},{"r":$.$typePointer($.$$.System.Void).$h,"p":[{"n":"unknown","p":786433}],"n":"CastIUnknownToInterfaceType","d":this.$h,"h":Number(BigInt(this.$h)|0x500000000n),"f":16777256}],"l":[{"t":$.$typeNullable($.$$.System.Guid).$h,"n":"TargetInterfaceIID","d":this.$h,"h":Number(BigInt(this.$h)|0x100000000n),"f":4194338}],"g":[T?.$h??1507328],"r":1,"h":this.$h,"a":[{"t":115146753,"c":4410114049,"a":[{"v":"android","t":1310721}]},{"t":115146753,"c":4410114049,"a":[{"v":"browser","t":1310721}]},{"t":115146753,"c":4410114049,"a":[{"v":"ios","t":1310721}]},{"t":115146753,"c":4410114049,"a":[{"v":"tvos","t":1310721}]},{"t":23527425,"c":8613462017,"a":[{"v":false,"t":262145}]},{"t":106692609,"c":4401659905,"a":[{"v":106758145,"t":142475265},{"v":0,"t":106823681},{"v":$.$sris.System.Runtime.InteropServices.Marshalling.ComInterfaceMarshaller$$().$h,"t":142475265}]}]}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `System.Runtime.InteropServices.Marshalling.ComInterfaceMarshaller<${T?.$fullName}>`; }
        }));
        
        $asm.$cls("$sris.System.Runtime.InteropServices.Marshalling.ExceptionAsVoidMarshaller", ($self) => class ExceptionAsVoidMarshaller
        {
            static /*void */ ConvertToUnmanaged(/*Exception*/ e)
            {
                _ = $.$$.System.Runtime.InteropServices.Marshal.GetHRForException(e);
            }
            static $h = 2741821;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"m":[{"r":65537,"p":[{"n":"e","p":47251457}],"n":"ConvertToUnmanaged","d":2741821,"h":4297709117,"f":16777249}],"h":2741821,"a":[{"t":106692609,"c":4401659905,"a":[{"v":47251457,"t":142475265},{"v":6,"t":106823681},{"v":2741821,"t":142475265}]}]}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `System.Runtime.InteropServices.Marshalling.ExceptionAsVoidMarshaller`; }
        });
        
        $asm.$cls("$sris.System.Runtime.InteropServices.Marshalling.UniqueComInterfaceMarshaller<>", (T) => $asm.$gt("$sris.System.Runtime.InteropServices.Marshalling.UniqueComInterfaceMarshaller<>", [T], ($self) => class UniqueComInterfaceMarshaller$$
        {
            static /*void* */ ConvertToUnmanaged(/*T?*/ managed)
            {
                if ($.$box(managed, T) === null)
                {
                    return null;
                }
                /*nint*/ let unknown;
                if (!$.$$.System.Runtime.InteropServices.ComWrappers.TryGetComInstance($.$box(managed, T), $.$ref(() => unknown, ($v) => unknown = $v, $.$$.System.IntPtr)))
                {
                    unknown = $.$sris.System.Runtime.InteropServices.Marshalling.StrategyBasedComWrappers.DefaultMarshallingInstance.GetOrCreateComInterfaceForObject($.$box(managed, T), 0/*CreateComInterfaceFlags.None*/);
                }
                return $.$sris.System.Runtime.InteropServices.Marshalling.ComInterfaceMarshaller$$(T).CastIUnknownToInterfaceType(unknown);
            }
            static /*T? */ ConvertToManaged(/*void**/ unmanaged)
            {
                if (unmanaged === null)
                {
                    return $.$default(T);
                }
                return $.$cast($.$sris.System.Runtime.InteropServices.Marshalling.StrategyBasedComWrappers.DefaultMarshallingInstance.GetOrCreateObjectForComInstance$1($.$$.System.IntPtr.op_Explicit$4(unmanaged), 2/*CreateObjectFlags.UniqueInstance*/), T);
            }
            static /*void */ Free(/*void**/ unmanaged)
            {
                if (unmanaged !== null)
                {
                    $.$$.System.Runtime.InteropServices.Marshal.Release($.$$.System.IntPtr.op_Explicit$4(unmanaged));
                }
            }
            static $h = 3724861;
            static $g = 1;
            static $f = 0b1010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"m":[{"r":$.$typePointer($.$$.System.Void).$h,"p":[{"n":"managed","p":T?.$h??1507328}],"n":"ConvertToUnmanaged","d":this.$h,"h":Number(BigInt(this.$h)|0x100000000n),"f":16777249},{"r":T?.$h??1507328,"p":[{"n":"unmanaged","p":$.$typePointer($.$$.System.Void).$h}],"n":"ConvertToManaged","d":this.$h,"h":Number(BigInt(this.$h)|0x200000000n),"f":16777249},{"r":65537,"p":[{"n":"unmanaged","p":$.$typePointer($.$$.System.Void).$h}],"n":"Free","d":this.$h,"h":Number(BigInt(this.$h)|0x300000000n),"f":16777249}],"g":[T?.$h??1507328],"r":1,"h":this.$h,"a":[{"t":115146753,"c":4410114049,"a":[{"v":"android","t":1310721}]},{"t":115146753,"c":4410114049,"a":[{"v":"browser","t":1310721}]},{"t":115146753,"c":4410114049,"a":[{"v":"ios","t":1310721}]},{"t":115146753,"c":4410114049,"a":[{"v":"tvos","t":1310721}]},{"t":23527425,"c":8613462017,"a":[{"v":false,"t":262145}]},{"t":106692609,"c":4401659905,"a":[{"v":106758145,"t":142475265},{"v":0,"t":106823681},{"v":$.$sris.System.Runtime.InteropServices.Marshalling.UniqueComInterfaceMarshaller$$().$h,"t":142475265}]}]}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `System.Runtime.InteropServices.Marshalling.UniqueComInterfaceMarshaller<${T?.$fullName}>`; }
        }));
        
        $asm.$cls("$sris.System.Runtime.InteropServices.Marshalling.ExceptionAsNaNMarshaller<>", (T) => $asm.$gt("$sris.System.Runtime.InteropServices.Marshalling.ExceptionAsNaNMarshaller<>", [T], ($self) => class ExceptionAsNaNMarshaller$$
        {
            static /*T */ ConvertToUnmanaged(/*Exception*/ e)
            {
                _ = $.$$.System.Runtime.InteropServices.Marshal.GetHRForException(e);
                return T.System$Numerics$IFloatingPointIeee754$$$NaN;
            }
            static $h = 2676285;
            static $g = 1;
            static $f = 0b1010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"m":[{"r":T?.$h??1507328,"p":[{"n":"e","p":47251457}],"n":"ConvertToUnmanaged","d":this.$h,"h":Number(BigInt(this.$h)|0x100000000n),"f":16777249}],"g":[T?.$h??1507328],"s":[{"n":"T","f":10,"c":[$.$$.System.Numerics.IFloatingPointIeee754$$(T).$h]}],"r":1,"h":this.$h,"a":[{"t":106692609,"c":4401659905,"a":[{"v":47251457,"t":142475265},{"v":6,"t":106823681},{"v":$.$sris.System.Runtime.InteropServices.Marshalling.ExceptionAsNaNMarshaller$$().$h,"t":142475265}]}]}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `System.Runtime.InteropServices.Marshalling.ExceptionAsNaNMarshaller<${T?.$fullName}>`; }
        }));
        
        $asm.$cls("$sris.System.Runtime.InteropServices.HandleCollector", ($self) => class HandleCollector extends $.$$.System.Object
        {
            /*int*/ static DeltaPercent = 10;
            /*int*/ _threshold = 0;
            /*int*/ _handleCount = 0;
            /*int[]*/ _gcCounts = null;
            /*int*/ _gcGeneration = 0;
            $ctor$2(/*string?*/ name, /*int*/ initialThreshold)
            {
                this.$ctor$1(name, initialThreshold, 2147483647/*int.MaxValue*/);
                {
                }
                return this;
            }
            $ctor$1(/*string?*/ name, /*int*/ initialThreshold, /*int*/ maximumThreshold)
            {
                super.$ctor();
                {
                    if (initialThreshold < 0)
                    {
                        throw new $.$$.System.ArgumentOutOfRangeException().$ctor$18("initialThreshold", $.$box(initialThreshold, $.$$.System.Int32), $.$sris.System.SR.Arg_NeedNonNegNumRequired);
                    }
                    if (maximumThreshold < 0)
                    {
                        throw new $.$$.System.ArgumentOutOfRangeException().$ctor$18("maximumThreshold", $.$box(maximumThreshold, $.$$.System.Int32), $.$sris.System.SR.Arg_NeedNonNegNumRequired);
                    }
                    if (initialThreshold > maximumThreshold)
                    {
                        throw new $.$$.System.ArgumentException().$ctor$13($.$sris.System.SR.Arg_InvalidThreshold, "initialThreshold");
                    }
                    this.Name = name ?? $.$$.System.String.Empty;
                    this.InitialThreshold = initialThreshold;
                    this.MaximumThreshold = maximumThreshold;
                    this._threshold = initialThreshold;
                    this._handleCount = 0;
                    this._gcGeneration = 0;
                }
                return this;
            }
            /*int */ get Count()
            {
                return this._handleCount;
            }
            /*int*/ InitialThreshold = 0;
            /*int*/ MaximumThreshold = 0;
            /*string*/ Name = null;
            /*void */ Add()
            {
                /*int*/ let collectionGeneration = -1;
                $.$$.System.Threading.Interlocked.Increment($.$ref(() => this._handleCount, ($v) => this._handleCount = $v, $.$$.System.Int32));
                if (this._handleCount < 0)
                {
                    throw new $.$$.System.InvalidOperationException().$ctor$12($.$sris.System.SR.InvalidOperation_HCCountOverflow);
                }
                if (this._handleCount > this._threshold)
                {
                    //lock
                    try
                    {
                        $.$$.System.Threading.Monitor.Enter$1(this)
                        {
                            this._threshold = ((this._handleCount + ($.trunc(this._handleCount / 10/*DeltaPercent*/))) | 0);
                            collectionGeneration = this._gcGeneration;
                            if (this._gcGeneration < 2)
                            {
                                this._gcGeneration++;
                            }
                        }
                    }
                    finally
                    {
                        $.$$.System.Threading.Monitor.Exit(this)
                    }
                }
                if ((collectionGeneration >= 0) && ((collectionGeneration === 0) || ($.$$.System.Array.$ReadT1.call(this._gcCounts, collectionGeneration) === $.$$.System.GC.CollectionCount(collectionGeneration))))
                {
                    $.$$.System.GC.Collect$4(collectionGeneration);
                    $.$$.System.Threading.Thread.Sleep(((10 * collectionGeneration) | 0));
                }
                for(/*int*/ let i = 1; i < 3; i++)
                {
                    $.$$.System.Array.$WriteT1.call(this._gcCounts, $.$$.System.GC.CollectionCount(i), i);
                }
            }
            /*void */ Remove()
            {
                $.$$.System.Threading.Interlocked.Decrement($.$ref(() => this._handleCount, ($v) => this._handleCount = $v, $.$$.System.Int32));
                if (this._handleCount < 0)
                {
                    throw new $.$$.System.InvalidOperationException().$ctor$12($.$sris.System.SR.InvalidOperation_HCCountOverflow);
                }
                /*int*/ let newThreshold = ((this._handleCount + $.trunc(this._handleCount / 10/*DeltaPercent*/)) | 0);
                if (newThreshold < (((this._threshold - $.trunc(this._threshold / 10/*DeltaPercent*/)) | 0)))
                {
                    //lock
                    try
                    {
                        $.$$.System.Threading.Monitor.Enter$1(this)
                        {
                            if (newThreshold > this.InitialThreshold)
                            {
                                this._threshold = newThreshold;
                            }
                            else 
                            {
                                this._threshold = this.InitialThreshold;
                            }
                            this._gcGeneration = 0;
                        }
                    }
                    finally
                    {
                        $.$$.System.Threading.Monitor.Exit(this)
                    }
                }
                for(/*int*/ let i = 1; i < 3; i++)
                {
                    $.$$.System.Array.$WriteT1.call(this._gcCounts, $.$$.System.GC.CollectionCount(i), i);
                }
            }
            //default member initializer
            constructor()
            {
                super();
                this._gcCounts = $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$$.System.Int32), null, [3], null);
            }
            static $h = 1627709;
            static $f = 0b10010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":655361,"g":{"r":0,"d":0,"h":38656333373,"f":50331649},"n":"Count","d":1627709,"h":34361366077,"f":2097153},{"p":655361,"g":{"r":0,"d":0,"h":51541235261,"f":50331649},"n":"InitialThreshold","d":1627709,"h":47246267965,"f":2097153},{"p":655361,"g":{"r":0,"d":0,"h":64426137149,"f":50331649},"n":"MaximumThreshold","d":1627709,"h":60131169853,"f":2097153},{"p":1310721,"g":{"r":0,"d":0,"h":77311039037,"f":50331649},"n":"Name","d":1627709,"h":73016071741,"f":2097153}],"m":[{"r":65537,"n":"Add","d":1627709,"h":81606006333,"f":16777217},{"r":65537,"n":"Remove","d":1627709,"h":85900973629,"f":16777217}],"l":[{"t":655361,"n":"DeltaPercent","d":1627709,"h":4296595005,"f":4194338},{"t":655361,"n":"_threshold","d":1627709,"h":8591562301,"f":4194306},{"t":655361,"n":"_handleCount","d":1627709,"h":12886529597,"f":4194306},{"t":$.$typeArray($.$$.System.Int32).$h,"n":"_gcCounts","d":1627709,"h":17181496893,"f":4194306},{"t":655361,"n":"_gcGeneration","d":1627709,"h":21476464189,"f":4194306}],"c":[{"p":[{"n":"name","p":1310721},{"n":"initialThreshold","p":655361}],"n":".ctor","o":"$ctor$2","d":1627709,"h":25771431485,"f":16777217},{"p":[{"n":"name","p":1310721},{"n":"initialThreshold","p":655361},{"n":"maximumThreshold","p":655361}],"n":".ctor","o":"$ctor$1","d":1627709,"h":30066398781,"f":16777217}],"h":1627709}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `System.Runtime.InteropServices.HandleCollector`; }
        });
        
        $asm.$cls("$sris.System.Runtime.InteropServices.Marshalling.ExceptionAsDefaultMarshaller<>", (T) => $asm.$gt("$sris.System.Runtime.InteropServices.Marshalling.ExceptionAsDefaultMarshaller<>", [T], ($self) => class ExceptionAsDefaultMarshaller$$
        {
            static /*T */ ConvertToUnmanaged(/*Exception*/ e)
            {
                _ = $.$$.System.Runtime.InteropServices.Marshal.GetHRForException(e);
                return $.$default(T);
            }
            static $h = 2545213;
            static $g = 1;
            static $f = 0b1010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"m":[{"r":T?.$h??1507328,"p":[{"n":"e","p":47251457}],"n":"ConvertToUnmanaged","d":this.$h,"h":Number(BigInt(this.$h)|0x100000000n),"f":16777249}],"g":[T?.$h??1507328],"s":[{"n":"T","f":10}],"r":1,"h":this.$h,"a":[{"t":106692609,"c":4401659905,"a":[{"v":47251457,"t":142475265},{"v":6,"t":106823681},{"v":$.$sris.System.Runtime.InteropServices.Marshalling.ExceptionAsDefaultMarshaller$$().$h,"t":142475265}]}]}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `System.Runtime.InteropServices.Marshalling.ExceptionAsDefaultMarshaller<${T?.$fullName}>`; }
        }));
        
        $asm.$cls("$sris.System.Runtime.InteropServices.Marshalling.ExceptionAsHResultMarshaller<>", (T) => $asm.$gt("$sris.System.Runtime.InteropServices.Marshalling.ExceptionAsHResultMarshaller<>", [T], ($self) => class ExceptionAsHResultMarshaller$$
        {
            static /*T */ ConvertToUnmanaged(/*Exception*/ e)
            {
                return T.System$Numerics$INumberBase$$$CreateTruncating($.$$.System.Int32, $.$$.System.Runtime.InteropServices.Marshal.GetHRForException(e));
            }
            static $h = 2610749;
            static $g = 1;
            static $f = 0b1010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"m":[{"r":T?.$h??1507328,"p":[{"n":"e","p":47251457}],"n":"ConvertToUnmanaged","d":this.$h,"h":Number(BigInt(this.$h)|0x100000000n),"f":16777249}],"g":[T?.$h??1507328],"s":[{"n":"T","f":10,"c":[$.$$.System.Numerics.INumber$$(T).$h]}],"r":1,"h":this.$h,"a":[{"t":106692609,"c":4401659905,"a":[{"v":47251457,"t":142475265},{"v":6,"t":106823681},{"v":$.$sris.System.Runtime.InteropServices.Marshalling.ExceptionAsHResultMarshaller$$().$h,"t":142475265}]}]}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `System.Runtime.InteropServices.Marshalling.ExceptionAsHResultMarshaller<${T?.$fullName}>`; }
        }));
        
        $asm.$cls("$sris.System.Security.SecureStringMarshal", ($self) => class SecureStringMarshal
        {
            static /*IntPtr */ SecureStringToCoTaskMemAnsi(/*SecureString*/ s)
            {
                return $.$$.System.Runtime.InteropServices.Marshal.SecureStringToCoTaskMemAnsi(s);
            }
            static /*IntPtr */ SecureStringToGlobalAllocAnsi(/*SecureString*/ s)
            {
                return $.$$.System.Runtime.InteropServices.Marshal.SecureStringToGlobalAllocAnsi(s);
            }
            static /*IntPtr */ SecureStringToCoTaskMemUnicode(/*SecureString*/ s)
            {
                return $.$$.System.Runtime.InteropServices.Marshal.SecureStringToCoTaskMemUnicode(s);
            }
            static /*IntPtr */ SecureStringToGlobalAllocUnicode(/*SecureString*/ s)
            {
                return $.$$.System.Runtime.InteropServices.Marshal.SecureStringToGlobalAllocUnicode(s);
            }
            static $h = 4642365;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"m":[{"r":786433,"p":[{"n":"s","p":117178369}],"n":"SecureStringToCoTaskMemAnsi","d":4642365,"h":4299609661,"f":16777249},{"r":786433,"p":[{"n":"s","p":117178369}],"n":"SecureStringToGlobalAllocAnsi","d":4642365,"h":8594576957,"f":16777249},{"r":786433,"p":[{"n":"s","p":117178369}],"n":"SecureStringToCoTaskMemUnicode","d":4642365,"h":12889544253,"f":16777249},{"r":786433,"p":[{"n":"s","p":117178369}],"n":"SecureStringToGlobalAllocUnicode","d":4642365,"h":17184511549,"f":16777249}],"h":4642365}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `System.Security.SecureStringMarshal`; }
        });
        
        $asm.$cls("$sris.System.Runtime.InteropServices.RuntimeEnvironment", ($self) => class RuntimeEnvironment
        {
            static /*string */ get SystemConfigurationFile()
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            static /*bool */ FromGlobalAccessCache(/*Assembly*/ a)
            {
                return false;
            }
            static /*string */ GetRuntimeDirectory()
            {
                /*string?*/ let runtimeDirectory = $.$$.System.Object.$type.Assembly.Location;
                if (!$.$$.System.IO.Path.IsPathRooted$1(runtimeDirectory))
                {
                    runtimeDirectory = $.$$.System.AppDomain.CurrentDomain.BaseDirectory;
                }
                /*char*/ let sep = $.$$.System.IO.Path.DirectorySeparatorChar;
                return $.$$.System.String.Concat$8($.$$.System.String.op_Implicit($.$$.System.IO.Path.GetDirectoryName$1(runtimeDirectory)), new ($.$$.System.ReadOnlySpan$$($.$$.System.Char))().$ctor$7($.$ref(() => sep, undefined, $.$$.System.Char)));
            }
            static /*IntPtr */ GetRuntimeInterfaceAsIntPtr(/*Guid*/ clsid, /*Guid*/ riid)
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            static /*object */ GetRuntimeInterfaceAsObject(/*Guid*/ clsid, /*Guid*/ riid)
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            static /*string */ GetSystemVersion()
            {
                return `v${$.$$.System.Environment.Version}`;
            }
            static $h = 4052541;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":1310721,"g":{"r":0,"d":0,"h":8593987133,"f":50331681},"n":"SystemConfigurationFile","d":4052541,"h":4299019837,"f":2097185,"a":[{"t":70909953,"c":8660844545,"a":[{"v":"RuntimeEnvironment members SystemConfigurationFile, GetRuntimeInterfaceAsIntPtr, and GetRuntimeInterfaceAsObject are not supported and throw PlatformNotSupportedException.","t":1310721}],"n":[{"n":"DiagnosticId","v":"SYSLIB0019","t":1310721},{"n":"UrlFormat","v":"https://aka.ms/dotnet-warnings/{0}","t":1310721}]}]}],"m":[{"r":262145,"p":[{"n":"a","p":73465857}],"n":"FromGlobalAccessCache","d":4052541,"h":12888954429,"f":16777249},{"r":1310721,"n":"GetRuntimeDirectory","d":4052541,"h":17183921725,"f":16777249},{"r":786433,"p":[{"n":"clsid","p":56229889},{"n":"riid","p":56229889}],"n":"GetRuntimeInterfaceAsIntPtr","d":4052541,"h":21478889021,"f":16777249,"a":[{"t":70909953,"c":8660844545,"a":[{"v":"RuntimeEnvironment members SystemConfigurationFile, GetRuntimeInterfaceAsIntPtr, and GetRuntimeInterfaceAsObject are not supported and throw PlatformNotSupportedException.","t":1310721}],"n":[{"n":"DiagnosticId","v":"SYSLIB0019","t":1310721},{"n":"UrlFormat","v":"https://aka.ms/dotnet-warnings/{0}","t":1310721}]}]},{"r":131073,"p":[{"n":"clsid","p":56229889},{"n":"riid","p":56229889}],"n":"GetRuntimeInterfaceAsObject","d":4052541,"h":25773856317,"f":16777249,"a":[{"t":70909953,"c":8660844545,"a":[{"v":"RuntimeEnvironment members SystemConfigurationFile, GetRuntimeInterfaceAsIntPtr, and GetRuntimeInterfaceAsObject are not supported and throw PlatformNotSupportedException.","t":1310721}],"n":[{"n":"DiagnosticId","v":"SYSLIB0019","t":1310721},{"n":"UrlFormat","v":"https://aka.ms/dotnet-warnings/{0}","t":1310721}]}]},{"r":1310721,"n":"GetSystemVersion","d":4052541,"h":30068823613,"f":16777249}],"h":4052541}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `System.Runtime.InteropServices.RuntimeEnvironment`; }
        });
        
        $asm.$cls("$sris.System.Obsoletions", ($self) => class Obsoletions
        {
            /*string*/ static SharedUrlFormat = null;
            /*string*/ static SystemTextEncodingUTF7Message = null;
            /*string*/ static SystemTextEncodingUTF7DiagId = null;
            /*string*/ static PrincipalPermissionAttributeMessage = null;
            /*string*/ static PrincipalPermissionAttributeDiagId = null;
            /*string*/ static CodeAccessSecurityMessage = null;
            /*string*/ static CodeAccessSecurityDiagId = null;
            /*string*/ static ConstrainedExecutionRegionMessage = null;
            /*string*/ static ConstrainedExecutionRegionDiagId = null;
            /*string*/ static GlobalAssemblyCacheMessage = null;
            /*string*/ static GlobalAssemblyCacheDiagId = null;
            /*string*/ static ThreadAbortMessage = null;
            /*string*/ static ThreadResetAbortMessage = null;
            /*string*/ static ThreadAbortDiagId = null;
            /*string*/ static DefaultCryptoAlgorithmsMessage = null;
            /*string*/ static DefaultCryptoAlgorithmsDiagId = null;
            /*string*/ static CreatePdbGeneratorMessage = null;
            /*string*/ static CreatePdbGeneratorDiagId = null;
            /*string*/ static AuthenticationManagerMessage = null;
            /*string*/ static AuthenticationManagerDiagId = null;
            /*string*/ static RemotingApisMessage = null;
            /*string*/ static RemotingApisDiagId = null;
            /*string*/ static BinaryFormatterMessage = null;
            /*string*/ static BinaryFormatterDiagId = null;
            /*string*/ static CodeBaseMessage = null;
            /*string*/ static CodeBaseDiagId = null;
            /*string*/ static EscapeUriStringMessage = null;
            /*string*/ static EscapeUriStringDiagId = null;
            /*string*/ static WebRequestMessage = null;
            /*string*/ static WebRequestDiagId = null;
            /*string*/ static DisablePrivateReflectionAttributeMessage = null;
            /*string*/ static DisablePrivateReflectionAttributeDiagId = null;
            /*string*/ static GetContextInfoMessage = null;
            /*string*/ static GetContextInfoDiagId = null;
            /*string*/ static StrongNameKeyPairMessage = null;
            /*string*/ static StrongNameKeyPairDiagId = null;
            /*string*/ static ReflectionOnlyLoadingMessage = null;
            /*string*/ static ReflectionOnlyLoadingDiagId = null;
            /*string*/ static RuntimeEnvironmentMessage = null;
            /*string*/ static RuntimeEnvironmentDiagId = null;
            /*string*/ static JsonSerializerOptionsIgnoreNullValuesMessage = null;
            /*string*/ static JsonSerializerOptionsIgnoreNullValuesDiagId = null;
            /*string*/ static DerivedCryptographicTypesMessage = null;
            /*string*/ static DerivedCryptographicTypesDiagId = null;
            /*string*/ static RijndaelMessage = null;
            /*string*/ static RijndaelDiagId = null;
            /*string*/ static RNGCryptoServiceProviderMessage = null;
            /*string*/ static RNGCryptoServiceProviderDiagId = null;
            /*string*/ static AppDomainCreateUnloadMessage = null;
            /*string*/ static AppDomainCreateUnloadDiagId = null;
            /*string*/ static SuppressIldasmAttributeMessage = null;
            /*string*/ static SuppressIldasmAttributeDiagId = null;
            /*string*/ static X509CertificateImmutableMessage = null;
            /*string*/ static X509CertificateImmutableDiagId = null;
            /*string*/ static PublicKeyPropertyMessage = null;
            /*string*/ static PublicKeyPropertyDiagId = null;
            /*string*/ static X509CertificatePrivateKeyMessage = null;
            /*string*/ static X509CertificatePrivateKeyDiagId = null;
            /*string*/ static ProduceLegacyHmacValuesMessage = null;
            /*string*/ static ProduceLegacyHmacValuesDiagId = null;
            /*string*/ static UseManagedSha1Message = null;
            /*string*/ static UseManagedSha1DiagId = null;
            /*string*/ static CryptoConfigEncodeOIDMessage = null;
            /*string*/ static CryptoConfigEncodeOIDDiagId = null;
            /*string*/ static CorruptedStateRecoveryMessage = null;
            /*string*/ static CorruptedStateRecoveryDiagId = null;
            /*string*/ static Rfc2898CryptDeriveKeyMessage = null;
            /*string*/ static Rfc2898CryptDeriveKeyDiagId = null;
            /*string*/ static CmsSignerCspParamsCtorMessage = null;
            /*string*/ static CmsSignerCspParamsCtorDiagId = null;
            /*string*/ static SignerInfoCounterSigMessage = null;
            /*string*/ static SignerInfoCounterSigDiagId = null;
            /*string*/ static RegexCompileToAssemblyMessage = null;
            /*string*/ static RegexCompileToAssemblyDiagId = null;
            /*string*/ static AssemblyNameMembersMessage = null;
            /*string*/ static AssemblyNameMembersDiagId = null;
            /*string*/ static SystemDataSerializationFormatBinaryMessage = null;
            /*string*/ static SystemDataSerializationFormatBinaryDiagId = null;
            /*string*/ static TlsVersion10and11Message = null;
            /*string*/ static TlsVersion10and11DiagId = null;
            /*string*/ static EncryptionPolicyMessage = null;
            /*string*/ static EncryptionPolicyDiagId = null;
            /*string*/ static EccXmlExportImportMessage = null;
            /*string*/ static EccXmlExportImportDiagId = null;
            /*string*/ static EcDhPublicKeyBlobMessage = null;
            /*string*/ static EcDhPublicKeyBlobDiagId = null;
            /*string*/ static AssemblyNameCodeBaseMessage = null;
            /*string*/ static AssemblyNameCodeBaseDiagId = null;
            /*string*/ static CryptoStringFactoryMessage = null;
            /*string*/ static CryptoStringFactoryDiagId = null;
            /*string*/ static ControlledExecutionRunMessage = null;
            /*string*/ static ControlledExecutionRunDiagId = null;
            /*string*/ static XmlSecureResolverMessage = null;
            /*string*/ static XmlSecureResolverDiagId = null;
            /*string*/ static RsaEncryptDecryptValueMessage = null;
            /*string*/ static RsaEncryptDecryptDiagId = null;
            /*string*/ static JsonSerializerOptionsAddContextMessage = null;
            /*string*/ static JsonSerializerOptionsAddContextDiagId = null;
            /*string*/ static LegacyFormatterMessage = null;
            /*string*/ static LegacyFormatterDiagId = null;
            /*string*/ static LegacyFormatterImplMessage = null;
            /*string*/ static LegacyFormatterImplDiagId = null;
            /*string*/ static RegexExtensibilityImplMessage = null;
            /*string*/ static RegexExtensibilityDiagId = null;
            /*string*/ static AesGcmTagConstructorMessage = null;
            /*string*/ static AesGcmTagConstructorDiagId = null;
            /*string*/ static ThreadVolatileReadWriteMessage = null;
            /*string*/ static ThreadVolatileReadWriteDiagId = null;
            /*string*/ static ArmIntrinsicPerformsUnsignedOperationMessage = null;
            /*string*/ static ArmIntrinsicPerformsUnsignedOperationDiagId = null;
            /*string*/ static LoadFromHashAlgorithmMessage = null;
            /*string*/ static LoadFromHashAlgorithmDiagId = null;
            /*string*/ static X509CtorCertDataObsoleteMessage = null;
            /*string*/ static X509CtorCertDataObsoleteDiagId = null;
            /*string*/ static TlsCipherAlgorithmEnumsMessage = null;
            /*string*/ static TlsCipherAlgorithmEnumsDiagId = null;
            /*string*/ static SystemEventsEventsThreadShutdownMessage = null;
            /*string*/ static SystemEventsEventsThreadShutdownDiagId = null;
            /*string*/ static Rfc2898DeriveBytesCtorMessage = null;
            /*string*/ static Rfc2898DeriveBytesCtorDiagId = null;
            /*string*/ static QueryableMinByMaxByTSourceObsoleteMessage = null;
            /*string*/ static QueryableMinByMaxByTSourceObsoleteDiagId = null;
            /*string*/ static XsltSettingsEnableScriptMessage = null;
            /*string*/ static XsltSettingsEnableScriptDiagId = null;
            //Static Initializer
            static $sinit()
            {
                {
                    this.SharedUrlFormat = "https://aka.ms/dotnet-warnings/{0}";
                }
                {
                    this.SystemTextEncodingUTF7Message = "The UTF-7 encoding is insecure and should not be used. Consider using UTF-8 instead.";
                }
                {
                    this.SystemTextEncodingUTF7DiagId = "SYSLIB0001";
                }
                {
                    this.PrincipalPermissionAttributeMessage = "PrincipalPermissionAttribute is not honored by the runtime and must not be used.";
                }
                {
                    this.PrincipalPermissionAttributeDiagId = "SYSLIB0002";
                }
                {
                    this.CodeAccessSecurityMessage = "Code Access Security is not supported or honored by the runtime.";
                }
                {
                    this.CodeAccessSecurityDiagId = "SYSLIB0003";
                }
                {
                    this.ConstrainedExecutionRegionMessage = "The Constrained Execution Region (CER) feature is not supported.";
                }
                {
                    this.ConstrainedExecutionRegionDiagId = "SYSLIB0004";
                }
                {
                    this.GlobalAssemblyCacheMessage = "The Global Assembly Cache is not supported.";
                }
                {
                    this.GlobalAssemblyCacheDiagId = "SYSLIB0005";
                }
                {
                    this.ThreadAbortMessage = "Thread.Abort is not supported and throws PlatformNotSupportedException.";
                }
                {
                    this.ThreadResetAbortMessage = "Thread.ResetAbort is not supported and throws PlatformNotSupportedException.";
                }
                {
                    this.ThreadAbortDiagId = "SYSLIB0006";
                }
                {
                    this.DefaultCryptoAlgorithmsMessage = "The default implementation of this cryptography algorithm is not supported.";
                }
                {
                    this.DefaultCryptoAlgorithmsDiagId = "SYSLIB0007";
                }
                {
                    this.CreatePdbGeneratorMessage = "The CreatePdbGenerator API is not supported and throws PlatformNotSupportedException.";
                }
                {
                    this.CreatePdbGeneratorDiagId = "SYSLIB0008";
                }
                {
                    this.AuthenticationManagerMessage = "AuthenticationManager is not supported. Methods will no-op or throw PlatformNotSupportedException.";
                }
                {
                    this.AuthenticationManagerDiagId = "SYSLIB0009";
                }
                {
                    this.RemotingApisMessage = "This Remoting API is not supported and throws PlatformNotSupportedException.";
                }
                {
                    this.RemotingApisDiagId = "SYSLIB0010";
                }
                {
                    this.BinaryFormatterMessage = "BinaryFormatter serialization is obsolete and should not be used. See https://aka.ms/binaryformatter for more information.";
                }
                {
                    this.BinaryFormatterDiagId = "SYSLIB0011";
                }
                {
                    this.CodeBaseMessage = "Assembly.CodeBase and Assembly.EscapedCodeBase are only included for .NET Framework compatibility. Use Assembly.Location instead.";
                }
                {
                    this.CodeBaseDiagId = "SYSLIB0012";
                }
                {
                    this.EscapeUriStringMessage = "Uri.EscapeUriString can corrupt the Uri string in some cases. Consider using Uri.EscapeDataString for query string components instead.";
                }
                {
                    this.EscapeUriStringDiagId = "SYSLIB0013";
                }
                {
                    this.WebRequestMessage = "WebRequest, HttpWebRequest, ServicePoint, and WebClient are obsolete. Use HttpClient instead.";
                }
                {
                    this.WebRequestDiagId = "SYSLIB0014";
                }
                {
                    this.DisablePrivateReflectionAttributeMessage = "DisablePrivateReflectionAttribute has no effect in .NET 6.0+.";
                }
                {
                    this.DisablePrivateReflectionAttributeDiagId = "SYSLIB0015";
                }
                {
                    this.GetContextInfoMessage = "Use the Graphics.GetContextInfo overloads that accept arguments for better performance and fewer allocations.";
                }
                {
                    this.GetContextInfoDiagId = "SYSLIB0016";
                }
                {
                    this.StrongNameKeyPairMessage = "Strong name signing is not supported and throws PlatformNotSupportedException.";
                }
                {
                    this.StrongNameKeyPairDiagId = "SYSLIB0017";
                }
                {
                    this.ReflectionOnlyLoadingMessage = "ReflectionOnly loading is not supported and throws PlatformNotSupportedException.";
                }
                {
                    this.ReflectionOnlyLoadingDiagId = "SYSLIB0018";
                }
                {
                    this.RuntimeEnvironmentMessage = "RuntimeEnvironment members SystemConfigurationFile, GetRuntimeInterfaceAsIntPtr, and GetRuntimeInterfaceAsObject are not supported and throw PlatformNotSupportedException.";
                }
                {
                    this.RuntimeEnvironmentDiagId = "SYSLIB0019";
                }
                {
                    this.JsonSerializerOptionsIgnoreNullValuesMessage = "JsonSerializerOptions.IgnoreNullValues is obsolete. To ignore null values when serializing, set DefaultIgnoreCondition to JsonIgnoreCondition.WhenWritingNull.";
                }
                {
                    this.JsonSerializerOptionsIgnoreNullValuesDiagId = "SYSLIB0020";
                }
                {
                    this.DerivedCryptographicTypesMessage = "Derived cryptographic types are obsolete. Use the Create method on the base type instead.";
                }
                {
                    this.DerivedCryptographicTypesDiagId = "SYSLIB0021";
                }
                {
                    this.RijndaelMessage = "The Rijndael and RijndaelManaged types are obsolete. Use Aes instead.";
                }
                {
                    this.RijndaelDiagId = "SYSLIB0022";
                }
                {
                    this.RNGCryptoServiceProviderMessage = "RNGCryptoServiceProvider is obsolete. To generate a random number, use one of the RandomNumberGenerator static methods instead.";
                }
                {
                    this.RNGCryptoServiceProviderDiagId = "SYSLIB0023";
                }
                {
                    this.AppDomainCreateUnloadMessage = "Creating and unloading AppDomains is not supported and throws an exception.";
                }
                {
                    this.AppDomainCreateUnloadDiagId = "SYSLIB0024";
                }
                {
                    this.SuppressIldasmAttributeMessage = "SuppressIldasmAttribute has no effect in .NET 6.0+.";
                }
                {
                    this.SuppressIldasmAttributeDiagId = "SYSLIB0025";
                }
                {
                    this.X509CertificateImmutableMessage = "X509Certificate and X509Certificate2 are immutable. Use X509CertificateLoader to create a new certificate.";
                }
                {
                    this.X509CertificateImmutableDiagId = "SYSLIB0026";
                }
                {
                    this.PublicKeyPropertyMessage = "PublicKey.Key is obsolete. Use the appropriate method to get the public key, such as GetRSAPublicKey.";
                }
                {
                    this.PublicKeyPropertyDiagId = "SYSLIB0027";
                }
                {
                    this.X509CertificatePrivateKeyMessage = "X509Certificate2.PrivateKey is obsolete. Use the appropriate method to get the private key, such as GetRSAPrivateKey, or use the CopyWithPrivateKey method to create a new instance with a private key.";
                }
                {
                    this.X509CertificatePrivateKeyDiagId = "SYSLIB0028";
                }
                {
                    this.ProduceLegacyHmacValuesMessage = "ProduceLegacyHmacValues is obsolete. Producing legacy HMAC values is not supported.";
                }
                {
                    this.ProduceLegacyHmacValuesDiagId = "SYSLIB0029";
                }
                {
                    this.UseManagedSha1Message = "HMACSHA1 always uses the algorithm implementation provided by the platform. Use a constructor without the useManagedSha1 parameter.";
                }
                {
                    this.UseManagedSha1DiagId = "SYSLIB0030";
                }
                {
                    this.CryptoConfigEncodeOIDMessage = "EncodeOID is obsolete. Use the ASN.1 functionality provided in System.Formats.Asn1.";
                }
                {
                    this.CryptoConfigEncodeOIDDiagId = "SYSLIB0031";
                }
                {
                    this.CorruptedStateRecoveryMessage = "Recovery from corrupted process state exceptions is not supported; HandleProcessCorruptedStateExceptionsAttribute is ignored.";
                }
                {
                    this.CorruptedStateRecoveryDiagId = "SYSLIB0032";
                }
                {
                    this.Rfc2898CryptDeriveKeyMessage = "Rfc2898DeriveBytes.CryptDeriveKey is obsolete and is not supported. Use PasswordDeriveBytes.CryptDeriveKey instead.";
                }
                {
                    this.Rfc2898CryptDeriveKeyDiagId = "SYSLIB0033";
                }
                {
                    this.CmsSignerCspParamsCtorMessage = "CmsSigner(CspParameters) is obsolete and is not supported. Use an alternative constructor instead.";
                }
                {
                    this.CmsSignerCspParamsCtorDiagId = "SYSLIB0034";
                }
                {
                    this.SignerInfoCounterSigMessage = "ComputeCounterSignature without specifying a CmsSigner is obsolete and is not supported. Use the overload that accepts a CmsSigner.";
                }
                {
                    this.SignerInfoCounterSigDiagId = "SYSLIB0035";
                }
                {
                    this.RegexCompileToAssemblyMessage = "Regex.CompileToAssembly is obsolete and not supported. Use the GeneratedRegexAttribute with the regular expression source generator instead.";
                }
                {
                    this.RegexCompileToAssemblyDiagId = "SYSLIB0036";
                }
                {
                    this.AssemblyNameMembersMessage = "AssemblyName members HashAlgorithm, ProcessorArchitecture, and VersionCompatibility are obsolete and not supported.";
                }
                {
                    this.AssemblyNameMembersDiagId = "SYSLIB0037";
                }
                {
                    this.SystemDataSerializationFormatBinaryMessage = "SerializationFormat.Binary is obsolete and should not be used. See https://aka.ms/serializationformat-binary-obsolete for more information.";
                }
                {
                    this.SystemDataSerializationFormatBinaryDiagId = "SYSLIB0038";
                }
                {
                    this.TlsVersion10and11Message = "TLS versions 1.0 and 1.1 have known vulnerabilities and are not recommended. Use a newer TLS version instead, or use SslProtocols.None to defer to OS defaults.";
                }
                {
                    this.TlsVersion10and11DiagId = "SYSLIB0039";
                }
                {
                    this.EncryptionPolicyMessage = "EncryptionPolicy.NoEncryption and AllowEncryption significantly reduce security and should not be used in production code.";
                }
                {
                    this.EncryptionPolicyDiagId = "SYSLIB0040";
                }
                {
                    this.EccXmlExportImportMessage = "ToXmlString and FromXmlString have no implementation for ECC types, and are obsolete. Use a standard import and export format such as ExportSubjectPublicKeyInfo or ImportSubjectPublicKeyInfo for public keys and ExportPkcs8PrivateKey or ImportPkcs8PrivateKey for private keys.";
                }
                {
                    this.EccXmlExportImportDiagId = "SYSLIB0042";
                }
                {
                    this.EcDhPublicKeyBlobMessage = "ECDiffieHellmanPublicKey.ToByteArray() and the associated constructor do not have a consistent and interoperable implementation on all platforms. Use ECDiffieHellmanPublicKey.ExportSubjectPublicKeyInfo() instead.";
                }
                {
                    this.EcDhPublicKeyBlobDiagId = "SYSLIB0043";
                }
                {
                    this.AssemblyNameCodeBaseMessage = "AssemblyName.CodeBase and AssemblyName.EscapedCodeBase are obsolete. Using them for loading an assembly is not supported.";
                }
                {
                    this.AssemblyNameCodeBaseDiagId = "SYSLIB0044";
                }
                {
                    this.CryptoStringFactoryMessage = "Cryptographic factory methods accepting an algorithm name are obsolete. Use the parameterless Create factory method on the algorithm type instead.";
                }
                {
                    this.CryptoStringFactoryDiagId = "SYSLIB0045";
                }
                {
                    this.ControlledExecutionRunMessage = "ControlledExecution.Run method may corrupt the process and should not be used in production code.";
                }
                {
                    this.ControlledExecutionRunDiagId = "SYSLIB0046";
                }
                {
                    this.XmlSecureResolverMessage = "XmlSecureResolver is obsolete. Use XmlResolver.ThrowingResolver instead when attempting to forbid XML external entity resolution.";
                }
                {
                    this.XmlSecureResolverDiagId = "SYSLIB0047";
                }
                {
                    this.RsaEncryptDecryptValueMessage = "RSA.EncryptValue and DecryptValue are not supported and throw NotSupportedException. Use RSA.Encrypt and RSA.Decrypt instead.";
                }
                {
                    this.RsaEncryptDecryptDiagId = "SYSLIB0048";
                }
                {
                    this.JsonSerializerOptionsAddContextMessage = "JsonSerializerOptions.AddContext is obsolete. To register a JsonSerializerContext, use either the TypeInfoResolver or TypeInfoResolverChain properties.";
                }
                {
                    this.JsonSerializerOptionsAddContextDiagId = "SYSLIB0049";
                }
                {
                    this.LegacyFormatterMessage = "Formatter-based serialization is obsolete and should not be used.";
                }
                {
                    this.LegacyFormatterDiagId = "SYSLIB0050";
                }
                {
                    this.LegacyFormatterImplMessage = "This API supports obsolete formatter-based serialization. It should not be called or extended by application code.";
                }
                {
                    this.LegacyFormatterImplDiagId = "SYSLIB0051";
                }
                {
                    this.RegexExtensibilityImplMessage = "This API supports obsolete mechanisms for Regex extensibility. It is not supported.";
                }
                {
                    this.RegexExtensibilityDiagId = "SYSLIB0052";
                }
                {
                    this.AesGcmTagConstructorMessage = "AesGcm should indicate the required tag size for encryption and decryption. Use a constructor that accepts the tag size.";
                }
                {
                    this.AesGcmTagConstructorDiagId = "SYSLIB0053";
                }
                {
                    this.ThreadVolatileReadWriteMessage = "Thread.VolatileRead and Thread.VolatileWrite are obsolete. Use Volatile.Read or Volatile.Write respectively instead.";
                }
                {
                    this.ThreadVolatileReadWriteDiagId = "SYSLIB0054";
                }
                {
                    this.ArmIntrinsicPerformsUnsignedOperationMessage = "The underlying hardware instruction does not perform a signed saturate narrowing operation, and it always returns an unsigned result. Use the unsigned overload instead.";
                }
                {
                    this.ArmIntrinsicPerformsUnsignedOperationDiagId = "SYSLIB0055";
                }
                {
                    this.LoadFromHashAlgorithmMessage = "LoadFrom with a custom AssemblyHashAlgorithm is obsolete. Use overloads without an AssemblyHashAlgorithm.";
                }
                {
                    this.LoadFromHashAlgorithmDiagId = "SYSLIB0056";
                }
                {
                    this.X509CtorCertDataObsoleteMessage = "Loading certificate data through the constructor or Import is obsolete. Use X509CertificateLoader instead to load certificates.";
                }
                {
                    this.X509CtorCertDataObsoleteDiagId = "SYSLIB0057";
                }
                {
                    this.TlsCipherAlgorithmEnumsMessage = "KeyExchangeAlgorithm, KeyExchangeStrength, CipherAlgorithm, CipherStrength, HashAlgorithm and HashStrength properties of SslStream are obsolete. Use NegotiatedCipherSuite instead.";
                }
                {
                    this.TlsCipherAlgorithmEnumsDiagId = "SYSLIB0058";
                }
                {
                    this.SystemEventsEventsThreadShutdownMessage = "SystemEvents.EventsThreadShutdown callbacks are not run before the process exits. Use AppDomain.ProcessExit instead.";
                }
                {
                    this.SystemEventsEventsThreadShutdownDiagId = "SYSLIB0059";
                }
                {
                    this.Rfc2898DeriveBytesCtorMessage = "The constructors on Rfc2898DeriveBytes are obsolete. Use the static Pbkdf2 method instead.";
                }
                {
                    this.Rfc2898DeriveBytesCtorDiagId = "SYSLIB0060";
                }
                {
                    this.QueryableMinByMaxByTSourceObsoleteMessage = "The Queryable MinBy and MaxBy taking an IComparer<TSource> are obsolete. Use the new ones that take an IComparer<TKey>.";
                }
                {
                    this.QueryableMinByMaxByTSourceObsoleteDiagId = "SYSLIB0061";
                }
                {
                    this.XsltSettingsEnableScriptMessage = "XSLT Script blocks are not supported.";
                }
                {
                    this.XsltSettingsEnableScriptDiagId = "SYSLIB0062";
                }
            }
            static $h = 120381;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"l":[{"t":1310721,"n":"SharedUrlFormat","d":120381,"h":4295087677,"f":4194344},{"t":1310721,"n":"SystemTextEncodingUTF7Message","d":120381,"h":8590054973,"f":4194344},{"t":1310721,"n":"SystemTextEncodingUTF7DiagId","d":120381,"h":12885022269,"f":4194344},{"t":1310721,"n":"PrincipalPermissionAttributeMessage","d":120381,"h":17179989565,"f":4194344},{"t":1310721,"n":"PrincipalPermissionAttributeDiagId","d":120381,"h":21474956861,"f":4194344},{"t":1310721,"n":"CodeAccessSecurityMessage","d":120381,"h":25769924157,"f":4194344},{"t":1310721,"n":"CodeAccessSecurityDiagId","d":120381,"h":30064891453,"f":4194344},{"t":1310721,"n":"ConstrainedExecutionRegionMessage","d":120381,"h":34359858749,"f":4194344},{"t":1310721,"n":"ConstrainedExecutionRegionDiagId","d":120381,"h":38654826045,"f":4194344},{"t":1310721,"n":"GlobalAssemblyCacheMessage","d":120381,"h":42949793341,"f":4194344},{"t":1310721,"n":"GlobalAssemblyCacheDiagId","d":120381,"h":47244760637,"f":4194344},{"t":1310721,"n":"ThreadAbortMessage","d":120381,"h":51539727933,"f":4194344},{"t":1310721,"n":"ThreadResetAbortMessage","d":120381,"h":55834695229,"f":4194344},{"t":1310721,"n":"ThreadAbortDiagId","d":120381,"h":60129662525,"f":4194344},{"t":1310721,"n":"DefaultCryptoAlgorithmsMessage","d":120381,"h":64424629821,"f":4194344},{"t":1310721,"n":"DefaultCryptoAlgorithmsDiagId","d":120381,"h":68719597117,"f":4194344},{"t":1310721,"n":"CreatePdbGeneratorMessage","d":120381,"h":73014564413,"f":4194344},{"t":1310721,"n":"CreatePdbGeneratorDiagId","d":120381,"h":77309531709,"f":4194344},{"t":1310721,"n":"AuthenticationManagerMessage","d":120381,"h":81604499005,"f":4194344},{"t":1310721,"n":"AuthenticationManagerDiagId","d":120381,"h":85899466301,"f":4194344},{"t":1310721,"n":"RemotingApisMessage","d":120381,"h":90194433597,"f":4194344},{"t":1310721,"n":"RemotingApisDiagId","d":120381,"h":94489400893,"f":4194344},{"t":1310721,"n":"BinaryFormatterMessage","d":120381,"h":98784368189,"f":4194344},{"t":1310721,"n":"BinaryFormatterDiagId","d":120381,"h":103079335485,"f":4194344},{"t":1310721,"n":"CodeBaseMessage","d":120381,"h":107374302781,"f":4194344},{"t":1310721,"n":"CodeBaseDiagId","d":120381,"h":111669270077,"f":4194344},{"t":1310721,"n":"EscapeUriStringMessage","d":120381,"h":115964237373,"f":4194344},{"t":1310721,"n":"EscapeUriStringDiagId","d":120381,"h":120259204669,"f":4194344},{"t":1310721,"n":"WebRequestMessage","d":120381,"h":124554171965,"f":4194344},{"t":1310721,"n":"WebRequestDiagId","d":120381,"h":128849139261,"f":4194344},{"t":1310721,"n":"DisablePrivateReflectionAttributeMessage","d":120381,"h":133144106557,"f":4194344},{"t":1310721,"n":"DisablePrivateReflectionAttributeDiagId","d":120381,"h":137439073853,"f":4194344},{"t":1310721,"n":"GetContextInfoMessage","d":120381,"h":141734041149,"f":4194344},{"t":1310721,"n":"GetContextInfoDiagId","d":120381,"h":146029008445,"f":4194344},{"t":1310721,"n":"StrongNameKeyPairMessage","d":120381,"h":150323975741,"f":4194344},{"t":1310721,"n":"StrongNameKeyPairDiagId","d":120381,"h":154618943037,"f":4194344},{"t":1310721,"n":"ReflectionOnlyLoadingMessage","d":120381,"h":158913910333,"f":4194344},{"t":1310721,"n":"ReflectionOnlyLoadingDiagId","d":120381,"h":163208877629,"f":4194344},{"t":1310721,"n":"RuntimeEnvironmentMessage","d":120381,"h":167503844925,"f":4194344},{"t":1310721,"n":"RuntimeEnvironmentDiagId","d":120381,"h":171798812221,"f":4194344},{"t":1310721,"n":"JsonSerializerOptionsIgnoreNullValuesMessage","d":120381,"h":176093779517,"f":4194344},{"t":1310721,"n":"JsonSerializerOptionsIgnoreNullValuesDiagId","d":120381,"h":180388746813,"f":4194344},{"t":1310721,"n":"DerivedCryptographicTypesMessage","d":120381,"h":184683714109,"f":4194344},{"t":1310721,"n":"DerivedCryptographicTypesDiagId","d":120381,"h":188978681405,"f":4194344},{"t":1310721,"n":"RijndaelMessage","d":120381,"h":193273648701,"f":4194344},{"t":1310721,"n":"RijndaelDiagId","d":120381,"h":197568615997,"f":4194344},{"t":1310721,"n":"RNGCryptoServiceProviderMessage","d":120381,"h":201863583293,"f":4194344},{"t":1310721,"n":"RNGCryptoServiceProviderDiagId","d":120381,"h":206158550589,"f":4194344},{"t":1310721,"n":"AppDomainCreateUnloadMessage","d":120381,"h":210453517885,"f":4194344},{"t":1310721,"n":"AppDomainCreateUnloadDiagId","d":120381,"h":214748485181,"f":4194344},{"t":1310721,"n":"SuppressIldasmAttributeMessage","d":120381,"h":219043452477,"f":4194344},{"t":1310721,"n":"SuppressIldasmAttributeDiagId","d":120381,"h":223338419773,"f":4194344},{"t":1310721,"n":"X509CertificateImmutableMessage","d":120381,"h":227633387069,"f":4194344},{"t":1310721,"n":"X509CertificateImmutableDiagId","d":120381,"h":231928354365,"f":4194344},{"t":1310721,"n":"PublicKeyPropertyMessage","d":120381,"h":236223321661,"f":4194344},{"t":1310721,"n":"PublicKeyPropertyDiagId","d":120381,"h":240518288957,"f":4194344},{"t":1310721,"n":"X509CertificatePrivateKeyMessage","d":120381,"h":244813256253,"f":4194344},{"t":1310721,"n":"X509CertificatePrivateKeyDiagId","d":120381,"h":249108223549,"f":4194344},{"t":1310721,"n":"ProduceLegacyHmacValuesMessage","d":120381,"h":253403190845,"f":4194344},{"t":1310721,"n":"ProduceLegacyHmacValuesDiagId","d":120381,"h":257698158141,"f":4194344},{"t":1310721,"n":"UseManagedSha1Message","d":120381,"h":261993125437,"f":4194344},{"t":1310721,"n":"UseManagedSha1DiagId","d":120381,"h":266288092733,"f":4194344},{"t":1310721,"n":"CryptoConfigEncodeOIDMessage","d":120381,"h":270583060029,"f":4194344},{"t":1310721,"n":"CryptoConfigEncodeOIDDiagId","d":120381,"h":274878027325,"f":4194344},{"t":1310721,"n":"CorruptedStateRecoveryMessage","d":120381,"h":279172994621,"f":4194344},{"t":1310721,"n":"CorruptedStateRecoveryDiagId","d":120381,"h":283467961917,"f":4194344},{"t":1310721,"n":"Rfc2898CryptDeriveKeyMessage","d":120381,"h":287762929213,"f":4194344},{"t":1310721,"n":"Rfc2898CryptDeriveKeyDiagId","d":120381,"h":292057896509,"f":4194344},{"t":1310721,"n":"CmsSignerCspParamsCtorMessage","d":120381,"h":296352863805,"f":4194344},{"t":1310721,"n":"CmsSignerCspParamsCtorDiagId","d":120381,"h":300647831101,"f":4194344},{"t":1310721,"n":"SignerInfoCounterSigMessage","d":120381,"h":304942798397,"f":4194344},{"t":1310721,"n":"SignerInfoCounterSigDiagId","d":120381,"h":309237765693,"f":4194344},{"t":1310721,"n":"RegexCompileToAssemblyMessage","d":120381,"h":313532732989,"f":4194344},{"t":1310721,"n":"RegexCompileToAssemblyDiagId","d":120381,"h":317827700285,"f":4194344},{"t":1310721,"n":"AssemblyNameMembersMessage","d":120381,"h":322122667581,"f":4194344},{"t":1310721,"n":"AssemblyNameMembersDiagId","d":120381,"h":326417634877,"f":4194344},{"t":1310721,"n":"SystemDataSerializationFormatBinaryMessage","d":120381,"h":330712602173,"f":4194344},{"t":1310721,"n":"SystemDataSerializationFormatBinaryDiagId","d":120381,"h":335007569469,"f":4194344},{"t":1310721,"n":"TlsVersion10and11Message","d":120381,"h":339302536765,"f":4194344},{"t":1310721,"n":"TlsVersion10and11DiagId","d":120381,"h":343597504061,"f":4194344},{"t":1310721,"n":"EncryptionPolicyMessage","d":120381,"h":347892471357,"f":4194344},{"t":1310721,"n":"EncryptionPolicyDiagId","d":120381,"h":352187438653,"f":4194344},{"t":1310721,"n":"EccXmlExportImportMessage","d":120381,"h":356482405949,"f":4194344},{"t":1310721,"n":"EccXmlExportImportDiagId","d":120381,"h":360777373245,"f":4194344},{"t":1310721,"n":"EcDhPublicKeyBlobMessage","d":120381,"h":365072340541,"f":4194344},{"t":1310721,"n":"EcDhPublicKeyBlobDiagId","d":120381,"h":369367307837,"f":4194344},{"t":1310721,"n":"AssemblyNameCodeBaseMessage","d":120381,"h":373662275133,"f":4194344},{"t":1310721,"n":"AssemblyNameCodeBaseDiagId","d":120381,"h":377957242429,"f":4194344},{"t":1310721,"n":"CryptoStringFactoryMessage","d":120381,"h":382252209725,"f":4194344},{"t":1310721,"n":"CryptoStringFactoryDiagId","d":120381,"h":386547177021,"f":4194344},{"t":1310721,"n":"ControlledExecutionRunMessage","d":120381,"h":390842144317,"f":4194344},{"t":1310721,"n":"ControlledExecutionRunDiagId","d":120381,"h":395137111613,"f":4194344},{"t":1310721,"n":"XmlSecureResolverMessage","d":120381,"h":399432078909,"f":4194344},{"t":1310721,"n":"XmlSecureResolverDiagId","d":120381,"h":403727046205,"f":4194344},{"t":1310721,"n":"RsaEncryptDecryptValueMessage","d":120381,"h":408022013501,"f":4194344},{"t":1310721,"n":"RsaEncryptDecryptDiagId","d":120381,"h":412316980797,"f":4194344},{"t":1310721,"n":"JsonSerializerOptionsAddContextMessage","d":120381,"h":416611948093,"f":4194344},{"t":1310721,"n":"JsonSerializerOptionsAddContextDiagId","d":120381,"h":420906915389,"f":4194344},{"t":1310721,"n":"LegacyFormatterMessage","d":120381,"h":425201882685,"f":4194344},{"t":1310721,"n":"LegacyFormatterDiagId","d":120381,"h":429496849981,"f":4194344},{"t":1310721,"n":"LegacyFormatterImplMessage","d":120381,"h":433791817277,"f":4194344},{"t":1310721,"n":"LegacyFormatterImplDiagId","d":120381,"h":438086784573,"f":4194344},{"t":1310721,"n":"RegexExtensibilityImplMessage","d":120381,"h":442381751869,"f":4194344},{"t":1310721,"n":"RegexExtensibilityDiagId","d":120381,"h":446676719165,"f":4194344},{"t":1310721,"n":"AesGcmTagConstructorMessage","d":120381,"h":450971686461,"f":4194344},{"t":1310721,"n":"AesGcmTagConstructorDiagId","d":120381,"h":455266653757,"f":4194344},{"t":1310721,"n":"ThreadVolatileReadWriteMessage","d":120381,"h":459561621053,"f":4194344},{"t":1310721,"n":"ThreadVolatileReadWriteDiagId","d":120381,"h":463856588349,"f":4194344},{"t":1310721,"n":"ArmIntrinsicPerformsUnsignedOperationMessage","d":120381,"h":468151555645,"f":4194344},{"t":1310721,"n":"ArmIntrinsicPerformsUnsignedOperationDiagId","d":120381,"h":472446522941,"f":4194344},{"t":1310721,"n":"LoadFromHashAlgorithmMessage","d":120381,"h":476741490237,"f":4194344},{"t":1310721,"n":"LoadFromHashAlgorithmDiagId","d":120381,"h":481036457533,"f":4194344},{"t":1310721,"n":"X509CtorCertDataObsoleteMessage","d":120381,"h":485331424829,"f":4194344},{"t":1310721,"n":"X509CtorCertDataObsoleteDiagId","d":120381,"h":489626392125,"f":4194344},{"t":1310721,"n":"TlsCipherAlgorithmEnumsMessage","d":120381,"h":493921359421,"f":4194344},{"t":1310721,"n":"TlsCipherAlgorithmEnumsDiagId","d":120381,"h":498216326717,"f":4194344},{"t":1310721,"n":"SystemEventsEventsThreadShutdownMessage","d":120381,"h":502511294013,"f":4194344},{"t":1310721,"n":"SystemEventsEventsThreadShutdownDiagId","d":120381,"h":506806261309,"f":4194344},{"t":1310721,"n":"Rfc2898DeriveBytesCtorMessage","d":120381,"h":511101228605,"f":4194344},{"t":1310721,"n":"Rfc2898DeriveBytesCtorDiagId","d":120381,"h":515396195901,"f":4194344},{"t":1310721,"n":"QueryableMinByMaxByTSourceObsoleteMessage","d":120381,"h":519691163197,"f":4194344},{"t":1310721,"n":"QueryableMinByMaxByTSourceObsoleteDiagId","d":120381,"h":523986130493,"f":4194344},{"t":1310721,"n":"XsltSettingsEnableScriptMessage","d":120381,"h":528281097789,"f":4194344},{"t":1310721,"n":"XsltSettingsEnableScriptDiagId","d":120381,"h":532576065085,"f":4194344}],"h":120381}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `System.Obsoletions`; }
        });
        
        $asm.$cls("$sris.System.SR", ($self) => class SR
        {
            /*global::System.Resources.ResourceManager*/ static s_resourceManager = null;
            /*global::System.Globalization.CultureInfo*/ static resourceCulture = null;
            static /*global::System.Resources.ResourceManager */ get ResourceManager()
            {
                if ($.$$.System.Object.ReferenceEquals($.$sris.System.SR.s_resourceManager, null))
                {
                    /*global::System.Resources.ResourceManager*/ let temp = new $.$$.System.Resources.ResourceManager().$ctor$3("System.Runtime.InteropServices", $.$sris.System.SR.$type.Assembly);
                    $.$sris.System.SR.s_resourceManager = temp;
                }
                return $.$sris.System.SR.s_resourceManager;
            }
            static /*global::System.Globalization.CultureInfo */ get Culture()
            {
                return $.$sris.System.SR.resourceCulture;
            }
            static /*global::System.Globalization.CultureInfo */ set Culture(value)
            {
                $.$sris.System.SR.resourceCulture = value;
            }
            static /*string */ get InvalidOperation_HCCountOverflow()
            {
                return "Handle collector count overflows or underflows.";
            }
            static /*string */ get Arg_NeedNonNegNumRequired()
            {
                return "Non-negative number required.";
            }
            static /*string */ get Arg_InvalidThreshold()
            {
                return "maximumThreshold cannot be less than initialThreshold.";
            }
            static /*string */ get InvalidOperation_NoComEventInterfaceAttribute()
            {
                return "Event invocation for COM objects requires the declaring interface of the event to be attributed with ComEventInterfaceAttribute.";
            }
            static /*string */ get AmbiguousMatch_MultipleEventInterfaceAttributes()
            {
                return "More than one ComEventInterfaceAttribute found for '{0}' on the declaring interface of the event.";
            }
            static /*string */ FormatAmbiguousMatch_MultipleEventInterfaceAttributes(/*object*/ arg1)
            {
                return $.$$.System.String.Format$9("More than one ComEventInterfaceAttribute found for '{0}' on the declaring interface of the event.", arg1);
            }
            static /*string */ get InvalidOperation_NoDispIdAttribute()
            {
                return "Event invocation for COM objects requires event to be attributed with DispIdAttribute.";
            }
            static /*string */ get IO_FileExists_Name()
            {
                return "The file '{0}' already exists.";
            }
            static /*string */ FormatIO_FileExists_Name(/*object*/ arg1)
            {
                return $.$$.System.String.Format$9("The file '{0}' already exists.", arg1);
            }
            static /*string */ get IO_FileNotFound()
            {
                return "Unable to find the specified file.";
            }
            static /*string */ get IO_FileNotFound_FileName()
            {
                return "Could not find file '{0}'.";
            }
            static /*string */ FormatIO_FileNotFound_FileName(/*object*/ arg1)
            {
                return $.$$.System.String.Format$9("Could not find file '{0}'.", arg1);
            }
            static /*string */ get IO_PathNotFound_NoPathName()
            {
                return "Could not find a part of the path.";
            }
            static /*string */ get IO_PathNotFound_Path()
            {
                return "Could not find a part of the path '{0}'.";
            }
            static /*string */ FormatIO_PathNotFound_Path(/*object*/ arg1)
            {
                return $.$$.System.String.Format$9("Could not find a part of the path '{0}'.", arg1);
            }
            static /*string */ get IO_PathTooLong()
            {
                return "The specified file name or path is too long, or a component of the specified path is too long.";
            }
            static /*string */ get IO_SharingViolation_File()
            {
                return "The process cannot access the file '{0}' because it is being used by another process.";
            }
            static /*string */ FormatIO_SharingViolation_File(/*object*/ arg1)
            {
                return $.$$.System.String.Format$9("The process cannot access the file '{0}' because it is being used by another process.", arg1);
            }
            static /*string */ get IO_SharingViolation_NoFileName()
            {
                return "The process cannot access the file because it is being used by another process.";
            }
            static /*string */ get IO_PathTooLong_Path()
            {
                return "The path '{0}' is too long, or a component of the specified path is too long.";
            }
            static /*string */ FormatIO_PathTooLong_Path(/*object*/ arg1)
            {
                return $.$$.System.String.Format$9("The path '{0}' is too long, or a component of the specified path is too long.", arg1);
            }
            static /*string */ get UnauthorizedAccess_IODenied_Path()
            {
                return "Access to the path '{0}' is denied.";
            }
            static /*string */ FormatUnauthorizedAccess_IODenied_Path(/*object*/ arg1)
            {
                return $.$$.System.String.Format$9("Access to the path '{0}' is denied.", arg1);
            }
            static /*string */ get UnauthorizedAccess_IODenied_NoPathName()
            {
                return "Access to the path is denied.";
            }
            static /*string */ get ArgumentOutOfRange_FileLengthTooBig()
            {
                return "Specified file length was too large for the file system.";
            }
            static /*string */ get ComVariantMarshaller_ManagedTypeNotSupported()
            {
                return "Type of managed object is not supported for marshalling as ComVariant.";
            }
            static /*string */ get ComVariantMarshaller_UnmanagedTypeNotSupported()
            {
                return "Type of unmanaged variant is not supported for marshalling to a managed object.";
            }
            /*bool*/ static s_usingResourceKeys = false;
            static /*bool */ GetUsingResourceKeysSwitchValue()
            {
                /*bool*/ let usingResourceKeys;
                return $.$$.System.AppContext.TryGetSwitch("System.Resources.UseSystemResourceKeys", $.$ref(() => usingResourceKeys, ($v) => usingResourceKeys = $v, $.$$.System.Boolean)) ? usingResourceKeys : false;
            }
            static /*bool */ UsingResourceKeys()
            {
                return $.$sris.System.SR.s_usingResourceKeys;
            }
            static /*string */ GetResourceString$1(/*string*/ resourceKey)
            {
                if ($.$sris.System.SR.UsingResourceKeys())
                {
                    return resourceKey;
                }
                /*string?*/ let resourceString = null;
                try
                {
                    resourceString = $.$sris.System.SR.ResourceManager.GetString$1(resourceKey);
                }
                catch($e)
                {
                }
                return resourceString;
            }
            static /*string */ GetResourceString(/*string*/ resourceKey, /*string*/ defaultString)
            {
                /*string*/ let resourceString = $.$sris.System.SR.GetResourceString$1(resourceKey);
                return $.$$.System.String.op_Equality(resourceKey, resourceString) || $.$$.System.String.op_Equality(resourceString, null) ? defaultString : resourceString;
            }
            static /*string */ Format$6(/*string*/ resourceFormat, /*object?*/ p1)
            {
                if ($.$sris.System.SR.UsingResourceKeys())
                {
                    return $.$$.System.String.Join$7(", ", $.$$.System.ReadOnlySpan$$($.$$.System.Object).op_Implicit$1([ resourceFormat, p1 ]));
                }
                return $.$$.System.String.Format$9(resourceFormat, p1);
            }
            static /*string */ Format$5(/*string*/ resourceFormat, /*object?*/ p1, /*object?*/ p2)
            {
                if ($.$sris.System.SR.UsingResourceKeys())
                {
                    return $.$$.System.String.Join$7(", ", $.$$.System.ReadOnlySpan$$($.$$.System.Object).op_Implicit$1([ resourceFormat, p1, p2 ]));
                }
                return $.$$.System.String.Format$8(resourceFormat, p1, p2);
            }
            static /*string */ Format$4(/*string*/ resourceFormat, /*object?*/ p1, /*object?*/ p2, /*object?*/ p3)
            {
                if ($.$sris.System.SR.UsingResourceKeys())
                {
                    return $.$$.System.String.Join$7(", ", $.$$.System.ReadOnlySpan$$($.$$.System.Object).op_Implicit$1([ resourceFormat, p1, p2, p3 ]));
                }
                return $.$$.System.String.Format$7(resourceFormat, p1, p2, p3);
            }
            static /*string */ Format$7(/*string*/ resourceFormat, /*params object?[]?*/ args)
            {
                if (args !== null)
                {
                    if ($.$sris.System.SR.UsingResourceKeys())
                    {
                        return resourceFormat + ", " + $.$$.System.String.Join$6(", ", args);
                    }
                    return $.$$.System.String.Format$10(resourceFormat, args);
                }
                return resourceFormat;
            }
            static /*string */ Format$2(/*IFormatProvider?*/ provider, /*string*/ resourceFormat, /*object?*/ p1)
            {
                if ($.$sris.System.SR.UsingResourceKeys())
                {
                    return $.$$.System.String.Join$7(", ", $.$$.System.ReadOnlySpan$$($.$$.System.Object).op_Implicit$1([ resourceFormat, p1 ]));
                }
                return $.$$.System.String.Format$2(provider, resourceFormat, p1);
            }
            static /*string */ Format$1(/*IFormatProvider?*/ provider, /*string*/ resourceFormat, /*object?*/ p1, /*object?*/ p2)
            {
                if ($.$sris.System.SR.UsingResourceKeys())
                {
                    return $.$$.System.String.Join$7(", ", $.$$.System.ReadOnlySpan$$($.$$.System.Object).op_Implicit$1([ resourceFormat, p1, p2 ]));
                }
                return $.$$.System.String.Format$1(provider, resourceFormat, p1, p2);
            }
            static /*string */ Format(/*IFormatProvider?*/ provider, /*string*/ resourceFormat, /*object?*/ p1, /*object?*/ p2, /*object?*/ p3)
            {
                if ($.$sris.System.SR.UsingResourceKeys())
                {
                    return $.$$.System.String.Join$7(", ", $.$$.System.ReadOnlySpan$$($.$$.System.Object).op_Implicit$1([ resourceFormat, p1, p2, p3 ]));
                }
                return $.$$.System.String.Format(provider, resourceFormat, p1, p2, p3);
            }
            static /*string */ Format$3(/*IFormatProvider?*/ provider, /*string*/ resourceFormat, /*params object?[]?*/ args)
            {
                if (args !== null)
                {
                    if ($.$sris.System.SR.UsingResourceKeys())
                    {
                        return resourceFormat + ", " + $.$$.System.String.Join$6(", ", args);
                    }
                    return $.$$.System.String.Format$3(provider, resourceFormat, args);
                }
                return resourceFormat;
            }
            //Static Initializer
            static $sinit()
            {
                {
                    this.s_usingResourceKeys = $.$sris.System.SR.GetUsingResourceKeysSwitchValue();
                }
            }
            static $h = 4707901;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"h":4707901}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `System.SR`; }
        });
        
        $asm.$cls("$sris.System.Runtime.InteropServices.Marshalling.ComVariantMarshaller", ($self) => class ComVariantMarshaller
        {
            /*short*/ static VARIANT_TRUE = -1;
            /*short*/ static VARIANT_FALSE = 0;
            static /*ComVariant */ ConvertToUnmanaged(/*object?*/ managed)
            {
                if (managed === null)
                {
                    return new $.$$.System.Runtime.InteropServices.Marshalling.ComVariant();
                }
                //switch (managed)
                {
                    let s;
                    let b;
                    let i;
                    let l;
                    let f;
                    let d;
                    let dt;
                    let errorWrapper;
                    let currencyWrapper;
                    let bStrWrapper;
                    $switchJumpStart1: 
                    //case sbyte s:
                    if ($.$is(managed, $.$$.System.SByte, { set $v(v){ s = v; } }))
                    {
                        return $.$$.System.Runtime.InteropServices.Marshalling.ComVariant.Create($.$$.System.SByte, s);
                    }
                    //case byte b:
                    else if ($.$is(managed, $.$$.System.Byte, { set $v(v){ b = v; } }))
                    {
                        return $.$$.System.Runtime.InteropServices.Marshalling.ComVariant.Create($.$$.System.Byte, b);
                    }
                    //case short s:
                    else if ($.$is(managed, $.$$.System.Int16, { set $v(v){ s = v; } }))
                    {
                        return $.$$.System.Runtime.InteropServices.Marshalling.ComVariant.Create($.$$.System.Int16, s);
                    }
                    //case ushort s:
                    else if ($.$is(managed, $.$$.System.UInt16, { set $v(v){ s = v; } }))
                    {
                        return $.$$.System.Runtime.InteropServices.Marshalling.ComVariant.Create($.$$.System.UInt16, s);
                    }
                    //case int i:
                    else if ($.$is(managed, $.$$.System.Int32, { set $v(v){ i = v; } }))
                    {
                        return $.$$.System.Runtime.InteropServices.Marshalling.ComVariant.Create($.$$.System.Int32, i);
                    }
                    //case uint i:
                    else if ($.$is(managed, $.$$.System.UInt32, { set $v(v){ i = v; } }))
                    {
                        return $.$$.System.Runtime.InteropServices.Marshalling.ComVariant.Create($.$$.System.UInt32, i);
                    }
                    //case long l:
                    else if ($.$is(managed, $.$$.System.Int64, { set $v(v){ l = v; } }))
                    {
                        return $.$$.System.Runtime.InteropServices.Marshalling.ComVariant.Create($.$$.System.Int64, l);
                    }
                    //case ulong l:
                    else if ($.$is(managed, $.$$.System.UInt64, { set $v(v){ l = v; } }))
                    {
                        return $.$$.System.Runtime.InteropServices.Marshalling.ComVariant.Create($.$$.System.UInt64, l);
                    }
                    //case float f:
                    else if ($.$is(managed, $.$$.System.Single, { set $v(v){ f = v; } }))
                    {
                        return $.$$.System.Runtime.InteropServices.Marshalling.ComVariant.Create($.$$.System.Single, f);
                    }
                    //case double d:
                    else if ($.$is(managed, $.$$.System.Double, { set $v(v){ d = v; } }))
                    {
                        return $.$$.System.Runtime.InteropServices.Marshalling.ComVariant.Create($.$$.System.Double, d);
                    }
                    //case decimal d:
                    else if ($.$is(managed, $.$$.System.Decimal, { set $v(v){ d = v; } }))
                    {
                        return $.$$.System.Runtime.InteropServices.Marshalling.ComVariant.Create($.$$.System.Decimal, d);
                    }
                    //case bool b:
                    else if ($.$is(managed, $.$$.System.Boolean, { set $v(v){ b = v; } }))
                    {
                        return $.$$.System.Runtime.InteropServices.Marshalling.ComVariant.Create($.$$.System.Boolean, b);
                    }
                    //case string s:
                    else if ($.$is(managed, $.$$.System.String, { set $v(v){ s = v; } }))
                    {
                        return $.$$.System.Runtime.InteropServices.Marshalling.ComVariant.Create($.$$.System.String, s);
                    }
                    //case DateTime dt:
                    else if ($.$is(managed, $.$$.System.DateTime, { set $v(v){ dt = v; } }))
                    {
                        return $.$$.System.Runtime.InteropServices.Marshalling.ComVariant.Create($.$$.System.DateTime, dt);
                    }
                    //case ErrorWrapper errorWrapper:
                    else if ($.$is(managed, $.$$.System.Runtime.InteropServices.ErrorWrapper, { set $v(v){ errorWrapper = v; } }))
                    {
                        return $.$$.System.Runtime.InteropServices.Marshalling.ComVariant.Create($.$$.System.Runtime.InteropServices.ErrorWrapper, errorWrapper);
                    }
                    //case CurrencyWrapper currencyWrapper:
                    else if ($.$is(managed, $.$$.System.Runtime.InteropServices.CurrencyWrapper, { set $v(v){ currencyWrapper = v; } }))
                    {
                        return $.$$.System.Runtime.InteropServices.Marshalling.ComVariant.Create($.$$.System.Runtime.InteropServices.CurrencyWrapper, currencyWrapper);
                    }
                    //case BStrWrapper bStrWrapper:
                    else if ($.$is(managed, $.$$.System.Runtime.InteropServices.BStrWrapper, { set $v(v){ bStrWrapper = v; } }))
                    {
                        return $.$$.System.Runtime.InteropServices.Marshalling.ComVariant.Create($.$$.System.Runtime.InteropServices.BStrWrapper, bStrWrapper);
                    }
                    //case DBNull:
                    else if (managed == $.$$.System.DBNull)
                    {
                        return $.$$.System.Runtime.InteropServices.Marshalling.ComVariant.Null;
                    }
                }
                /*ComVariant*/ let variant;
                if ($.$sris.System.Runtime.InteropServices.Marshalling.ComVariantMarshaller.TryCreateOleVariantForInterfaceWrapper(managed, $.$ref(() => variant, ($v) => variant = $v, $.$$.System.Runtime.InteropServices.Marshalling.ComVariant)))
                {
                    return variant;
                }
                throw new $.$$.System.ArgumentException().$ctor$13($.$sris.System.SR.ComVariantMarshaller_ManagedTypeNotSupported, "managed");
            }
            static /*bool */ TryCreateOleVariantForInterfaceWrapper(/*object*/ managed, /*out ComVariant*/ variant)
            {
                let uw;
                if ($.$is(managed, $.$$.System.Runtime.InteropServices.UnknownWrapper, { set $v(v){ uw = v; } }))
                {
                    /*object?*/ let wrapped = uw.WrappedObject;
                    if (wrapped === null)
                    {
                        variant.$v = new $.$$.System.Runtime.InteropServices.Marshalling.ComVariant();
                        return true;
                    }
                    variant.$v = $.$$.System.Runtime.InteropServices.Marshalling.ComVariant.CreateRaw($.$$.System.IntPtr, 13/*VarEnum.VT_UNKNOWN*/, $.$sris.System.Runtime.InteropServices.Marshalling.StrategyBasedComWrappers.DefaultMarshallingInstance.GetOrCreateComInterfaceForObject(wrapped, 0/*CreateComInterfaceFlags.None*/));
                    return true;
                }
                else if (!(managed === null) && !($.$sris.System.Runtime.InteropServices.Marshalling.StrategyBasedComWrappers.DefaultIUnknownInterfaceDetailsStrategy.System$Runtime$InteropServices$Marshalling$IIUnknownInterfaceDetailsStrategy$GetComExposedTypeDetails($.$$.System.Object.GetType.call(managed).TypeHandle) === null))
                {
                    variant.$v = $.$$.System.Runtime.InteropServices.Marshalling.ComVariant.CreateRaw($.$$.System.IntPtr, 13/*VarEnum.VT_UNKNOWN*/, $.$sris.System.Runtime.InteropServices.Marshalling.StrategyBasedComWrappers.DefaultMarshallingInstance.GetOrCreateComInterfaceForObject(managed, 0/*CreateComInterfaceFlags.None*/));
                    return true;
                }
                variant.$v = new $.$$.System.Runtime.InteropServices.Marshalling.ComVariant();
                return false;
            }
            static /*object? */ ConvertToManaged(/*ComVariant*/ unmanaged)
            {
                let $switch1 = unmanaged.VarType;
                switch($switch1)
                {
                    case 0/*VarEnum.VT_EMPTY*/:
                    case 16384/*VarEnum.VT_BYREF*/ | 0/*VarEnum.VT_EMPTY*/:
                    return null;
                    case 1/*VarEnum.VT_NULL*/:
                    case 16384/*VarEnum.VT_BYREF*/ | 1/*VarEnum.VT_NULL*/:
                    return $.$$.System.DBNull.Value;
                    case 16/*VarEnum.VT_I1*/:
                    return $.$box(unmanaged.As($.$$.System.SByte), $.$$.System.SByte);
                    case 17/*VarEnum.VT_UI1*/:
                    return $.$box(unmanaged.As($.$$.System.Byte), $.$$.System.Byte);
                    case 2/*VarEnum.VT_I2*/:
                    return $.$box(unmanaged.As($.$$.System.Int16), $.$$.System.Int16);
                    case 18/*VarEnum.VT_UI2*/:
                    return $.$box(unmanaged.As($.$$.System.UInt16), $.$$.System.UInt16);
                    case 22/*VarEnum.VT_INT*/:
                    case 3/*VarEnum.VT_I4*/:
                    return $.$box(unmanaged.As($.$$.System.Int32), $.$$.System.Int32);
                    case 23/*VarEnum.VT_UINT*/:
                    case 19/*VarEnum.VT_UI4*/:
                    return $.$box(unmanaged.As($.$$.System.UInt32), $.$$.System.UInt32);
                    case 20/*VarEnum.VT_I8*/:
                    return $.$box(unmanaged.As($.$$.System.Int64), $.$$.System.Int64);
                    case 21/*VarEnum.VT_UI8*/:
                    return $.$box(unmanaged.As($.$$.System.UInt64), $.$$.System.UInt64);
                    case 4/*VarEnum.VT_R4*/:
                    return $.$box(unmanaged.As($.$$.System.Single), $.$$.System.Single);
                    case 5/*VarEnum.VT_R8*/:
                    return $.$box(unmanaged.As($.$$.System.Double), $.$$.System.Double);
                    case 14/*VarEnum.VT_DECIMAL*/:
                    return unmanaged.As($.$$.System.Decimal);
                    case 11/*VarEnum.VT_BOOL*/:
                    return $.$box(unmanaged.As($.$$.System.Boolean), $.$$.System.Boolean);
                    case 8/*VarEnum.VT_BSTR*/:
                    return unmanaged.As($.$$.System.String);
                    case 7/*VarEnum.VT_DATE*/:
                    return unmanaged.As($.$$.System.DateTime);
                    case 10/*VarEnum.VT_ERROR*/:
                    return $.$box(unmanaged.As($.$$.System.Int32), $.$$.System.Int32);
                    case 6/*VarEnum.VT_CY*/:
                    return unmanaged.As($.$$.System.Runtime.InteropServices.CurrencyWrapper).WrappedObject;
                    case 13/*VarEnum.VT_UNKNOWN*/:
                    case 9/*VarEnum.VT_DISPATCH*/:
                    return $.$sris.System.Runtime.InteropServices.Marshalling.StrategyBasedComWrappers.DefaultMarshallingInstance.GetOrCreateObjectForComInstance$1(unmanaged.GetRawDataRef($.$$.System.IntPtr).$v, 8/*CreateObjectFlags.Unwrap*/);
                    case 16384/*VarEnum.VT_BYREF*/ | 12/*VarEnum.VT_VARIANT*/:
                    return $.$sris.System.Runtime.InteropServices.Marshalling.ComVariantMarshaller.ConvertToManaged($.$$.$interop.castAddress2Object(unmanaged.GetRawDataRef($.$$.System.IntPtr).$v));
                    case 16384/*VarEnum.VT_BYREF*/ | 16/*VarEnum.VT_I1*/:
                    return $.$box($.$$.$interop.castAddress2Object(unmanaged.GetRawDataRef($.$$.System.IntPtr).$v), $.$$.System.SByte);
                    case 16384/*VarEnum.VT_BYREF*/ | 17/*VarEnum.VT_UI1*/:
                    return $.$box($.$$.$interop.castAddress2Object(unmanaged.GetRawDataRef($.$$.System.IntPtr).$v), $.$$.System.Byte);
                    case 16384/*VarEnum.VT_BYREF*/ | 2/*VarEnum.VT_I2*/:
                    return $.$box($.$$.$interop.castAddress2Object(unmanaged.GetRawDataRef($.$$.System.IntPtr).$v), $.$$.System.Int16);
                    case 16384/*VarEnum.VT_BYREF*/ | 18/*VarEnum.VT_UI2*/:
                    return $.$box($.$$.$interop.castAddress2Object(unmanaged.GetRawDataRef($.$$.System.IntPtr).$v), $.$$.System.UInt16);
                    case 16384/*VarEnum.VT_BYREF*/ | 3/*VarEnum.VT_I4*/:
                    return $.$box($.$$.$interop.castAddress2Object(unmanaged.GetRawDataRef($.$$.System.IntPtr).$v), $.$$.System.Int32);
                    case 16384/*VarEnum.VT_BYREF*/ | 19/*VarEnum.VT_UI4*/:
                    return $.$box($.$$.$interop.castAddress2Object(unmanaged.GetRawDataRef($.$$.System.IntPtr).$v), $.$$.System.UInt32);
                    case 16384/*VarEnum.VT_BYREF*/ | 20/*VarEnum.VT_I8*/:
                    return $.$box($.$$.$interop.castAddress2Object(unmanaged.GetRawDataRef($.$$.System.IntPtr).$v), $.$$.System.Int64);
                    case 16384/*VarEnum.VT_BYREF*/ | 21/*VarEnum.VT_UI8*/:
                    return $.$box($.$$.$interop.castAddress2Object(unmanaged.GetRawDataRef($.$$.System.IntPtr).$v), $.$$.System.UInt64);
                    case 16384/*VarEnum.VT_BYREF*/ | 4/*VarEnum.VT_R4*/:
                    return $.$box($.$$.$interop.castAddress2Object(unmanaged.GetRawDataRef($.$$.System.IntPtr).$v), $.$$.System.Single);
                    case 16384/*VarEnum.VT_BYREF*/ | 5/*VarEnum.VT_R8*/:
                    return $.$box($.$$.$interop.castAddress2Object(unmanaged.GetRawDataRef($.$$.System.IntPtr).$v), $.$$.System.Double);
                    case 16384/*VarEnum.VT_BYREF*/ | 14/*VarEnum.VT_DECIMAL*/:
                    return $.$$.$interop.castAddress2Object(unmanaged.GetRawDataRef($.$$.System.IntPtr).$v);
                    case 16384/*VarEnum.VT_BYREF*/ | 11/*VarEnum.VT_BOOL*/:
                    return $.$box($.$$.$interop.castAddress2Object(unmanaged.GetRawDataRef($.$$.System.IntPtr).$v) !== 0/*VARIANT_FALSE*/, $.$$.System.Boolean);
                    case 16384/*VarEnum.VT_BYREF*/ | 8/*VarEnum.VT_BSTR*/:
                    return $.$$.System.Runtime.InteropServices.Marshal.PtrToStringBSTR($.$$.$interop.castAddress2Object(unmanaged.GetRawDataRef($.$$.System.IntPtr).$v));
                    case 16384/*VarEnum.VT_BYREF*/ | 7/*VarEnum.VT_DATE*/:
                    return $.$$.System.DateTime.FromOADate($.$$.$interop.castAddress2Object(unmanaged.GetRawDataRef($.$$.System.IntPtr).$v));
                    case 16384/*VarEnum.VT_BYREF*/ | 10/*VarEnum.VT_ERROR*/:
                    return $.$box($.$$.$interop.castAddress2Object(unmanaged.GetRawDataRef($.$$.System.IntPtr).$v), $.$$.System.Int32);
                    case 16384/*VarEnum.VT_BYREF*/ | 6/*VarEnum.VT_CY*/:
                    return $.$$.System.Decimal.FromOACurrency($.$$.$interop.castAddress2Object(unmanaged.GetRawDataRef($.$$.System.IntPtr).$v));
                    case 16384/*VarEnum.VT_BYREF*/ | 13/*VarEnum.VT_UNKNOWN*/:
                    return $.$sris.System.Runtime.InteropServices.Marshalling.StrategyBasedComWrappers.DefaultMarshallingInstance.GetOrCreateObjectForComInstance$1($.$$.$interop.castAddress2Object(unmanaged.GetRawDataRef($.$$.System.IntPtr).$v), 8/*CreateObjectFlags.Unwrap*/);
                    default:
                    throw new $.$$.System.ArgumentException().$ctor$13($.$sris.System.SR.ComVariantMarshaller_UnmanagedTypeNotSupported, "unmanaged");
                }
            }
            static /*void */ Free(/*ComVariant*/ unmanaged)
            {
                return unmanaged.Dispose();
            }
            static $_RefPropagate;
            static get RefPropagate()
            {
                let $cls = $.$sris.System.Runtime.InteropServices.Marshalling.ComVariantMarshaller;
                return $cls.$_RefPropagate ??= $asm.$nstr("$sris.System.Runtime.InteropServices.Marshalling.ComVariantMarshaller.RefPropagate", ($self) => class RefPropagate extends $.$$.System.ValueType
                {
                    /*ComVariant*/  get _unmanaged() { return this.$getField(0, 140); }
                    /*ComVariant*/  set _unmanaged(value) { this.$setField(0, 140, value); }
                    /*object?*/  get _managed() { return this.$getField(140, 4); }
                    /*object?*/  set _managed(value) { this.$setField(140, 4, value); }
                    /*void */ FromUnmanaged(/*ComVariant*/ unmanaged)
                    {
                        return this._unmanaged = unmanaged.Clone();
                    }
                    /*void */ FromManaged(/*object?*/ managed)
                    {
                        return this._managed = managed;
                    }
                    /*ComVariant */ ToUnmanaged()
                    {
                        if (!((this._unmanaged.VarType & (16384/*VarEnum.VT_BYREF*/)) == (16384/*VarEnum.VT_BYREF*/)))
                        {
                            return $.$sris.System.Runtime.InteropServices.Marshalling.ComVariantMarshaller.ConvertToUnmanaged(this._managed);
                        }
                        if (this._managed === null && (((this._unmanaged.VarType & ~16384/*VarEnum.VT_BYREF*/) === 8/*VarEnum.VT_BSTR*/) || ((this._unmanaged.VarType & ~16384/*VarEnum.VT_BYREF*/) === 9/*VarEnum.VT_DISPATCH*/)) || ((this._unmanaged.VarType & ~16384/*VarEnum.VT_BYREF*/) === 13/*VarEnum.VT_UNKNOWN*/))
                        {
                            $.$$.$interop.castAddress2Object(this._unmanaged.GetRawDataRef($.$$.System.IntPtr).$v).$v = 0;
                            return this._unmanaged;
                        }
                        //switch ((_unmanaged.VarType & ~VarEnum.VT_BYREF, _managed))
                        let $switch2 = this._unmanaged.VarType & ~16384/*VarEnum.VT_BYREF*/;
                        let $switch3 = this._managed;
                        {
                            let s;
                            let b;
                            let u;
                            let i;
                            let l;
                            let ul;
                            let f;
                            let d;
                            let str;
                            let dt;
                            let error;
                            let cy;
                            let unkObj;
                            $switchJumpStart1: 
                            //case (VarEnum.VT_VARIANT, _):
                            if (($switch2 === 12/*VarEnum.VT_VARIANT*/))
                            {
                                $.$$.$interop.castAddress2Object(this._unmanaged.GetRawDataRef($.$$.System.IntPtr).$v).$v = $.$sris.System.Runtime.InteropServices.Marshalling.ComVariantMarshaller.ConvertToUnmanaged(this._managed);
                            }
                            //case (VarEnum.VT_I1 or VarEnum.VT_UI1, sbyte s):
                            else if ((($switch2 === 16/*VarEnum.VT_I1*/) || ($switch2 === 17/*VarEnum.VT_UI1*/)) && ($.$is($switch3, $.$$.System.SByte, { set $v(v){ s = v; } })))
                            {
                                $.$$.$interop.castAddress2Object(this._unmanaged.GetRawDataRef($.$$.System.IntPtr).$v).$v = s;
                            }
                            //case (VarEnum.VT_I1 or VarEnum.VT_UI1, byte b):
                            else if ((($switch2 === 16/*VarEnum.VT_I1*/) || ($switch2 === 17/*VarEnum.VT_UI1*/)) && ($.$is($switch3, $.$$.System.Byte, { set $v(v){ b = v; } })))
                            {
                                $.$$.$interop.castAddress2Object(this._unmanaged.GetRawDataRef($.$$.System.IntPtr).$v).$v = b;
                            }
                            //case (VarEnum.VT_I2 or VarEnum.VT_UI2, short s):
                            else if ((($switch2 === 2/*VarEnum.VT_I2*/) || ($switch2 === 18/*VarEnum.VT_UI2*/)) && ($.$is($switch3, $.$$.System.Int16, { set $v(v){ s = v; } })))
                            {
                                $.$$.$interop.castAddress2Object(this._unmanaged.GetRawDataRef($.$$.System.IntPtr).$v).$v = s;
                            }
                            //case (VarEnum.VT_I2 or VarEnum.VT_UI2, ushort u):
                            else if ((($switch2 === 2/*VarEnum.VT_I2*/) || ($switch2 === 18/*VarEnum.VT_UI2*/)) && ($.$is($switch3, $.$$.System.UInt16, { set $v(v){ u = v; } })))
                            {
                                $.$$.$interop.castAddress2Object(this._unmanaged.GetRawDataRef($.$$.System.IntPtr).$v).$v = u;
                            }
                            //case (VarEnum.VT_I4 or VarEnum.VT_INT or VarEnum.VT_UI4 or VarEnum.VT_UINT or VarEnum.VT_ERROR, int i):
                            else if (((((($switch2 === 3/*VarEnum.VT_I4*/) || ($switch2 === 22/*VarEnum.VT_INT*/)) || ($switch2 === 19/*VarEnum.VT_UI4*/)) || ($switch2 === 23/*VarEnum.VT_UINT*/)) || ($switch2 === 10/*VarEnum.VT_ERROR*/)) && ($.$is($switch3, $.$$.System.Int32, { set $v(v){ i = v; } })))
                            {
                                $.$$.$interop.castAddress2Object(this._unmanaged.GetRawDataRef($.$$.System.IntPtr).$v).$v = i;
                            }
                            //case (VarEnum.VT_I4 or VarEnum.VT_INT or VarEnum.VT_UI4 or VarEnum.VT_UINT or VarEnum.VT_ERROR, uint u):
                            else if (((((($switch2 === 3/*VarEnum.VT_I4*/) || ($switch2 === 22/*VarEnum.VT_INT*/)) || ($switch2 === 19/*VarEnum.VT_UI4*/)) || ($switch2 === 23/*VarEnum.VT_UINT*/)) || ($switch2 === 10/*VarEnum.VT_ERROR*/)) && ($.$is($switch3, $.$$.System.UInt32, { set $v(v){ u = v; } })))
                            {
                                $.$$.$interop.castAddress2Object(this._unmanaged.GetRawDataRef($.$$.System.IntPtr).$v).$v = u;
                            }
                            //case (VarEnum.VT_I8 or VarEnum.VT_UI8, long l):
                            else if ((($switch2 === 20/*VarEnum.VT_I8*/) || ($switch2 === 21/*VarEnum.VT_UI8*/)) && ($.$is($switch3, $.$$.System.Int64, { set $v(v){ l = v; } })))
                            {
                                $.$$.$interop.castAddress2Object(this._unmanaged.GetRawDataRef($.$$.System.IntPtr).$v).$v = l;
                            }
                            //case (VarEnum.VT_I8 or VarEnum.VT_UI8, ulong ul):
                            else if ((($switch2 === 20/*VarEnum.VT_I8*/) || ($switch2 === 21/*VarEnum.VT_UI8*/)) && ($.$is($switch3, $.$$.System.UInt64, { set $v(v){ ul = v; } })))
                            {
                                $.$$.$interop.castAddress2Object(this._unmanaged.GetRawDataRef($.$$.System.IntPtr).$v).$v = ul;
                            }
                            //case (VarEnum.VT_R4, float f):
                            else if (($switch2 === 4/*VarEnum.VT_R4*/) && ($.$is($switch3, $.$$.System.Single, { set $v(v){ f = v; } })))
                            {
                                $.$$.$interop.castAddress2Object(this._unmanaged.GetRawDataRef($.$$.System.IntPtr).$v).$v = f;
                            }
                            //case (VarEnum.VT_R8, double d):
                            else if (($switch2 === 5/*VarEnum.VT_R8*/) && ($.$is($switch3, $.$$.System.Double, { set $v(v){ d = v; } })))
                            {
                                $.$$.$interop.castAddress2Object(this._unmanaged.GetRawDataRef($.$$.System.IntPtr).$v).$v = d;
                            }
                            //case (VarEnum.VT_DECIMAL, decimal d):
                            else if (($switch2 === 14/*VarEnum.VT_DECIMAL*/) && ($.$is($switch3, $.$$.System.Decimal, { set $v(v){ d = v; } })))
                            {
                                $.$$.$interop.castAddress2Object(this._unmanaged.GetRawDataRef($.$$.System.IntPtr).$v).$v = d;
                            }
                            //case (VarEnum.VT_BOOL, bool b):
                            else if (($switch2 === 11/*VarEnum.VT_BOOL*/) && ($.$is($switch3, $.$$.System.Boolean, { set $v(v){ b = v; } })))
                            {
                                $.$$.$interop.castAddress2Object(this._unmanaged.GetRawDataRef($.$$.System.IntPtr).$v).$v = b ? -1/*VARIANT_TRUE*/ : 0/*VARIANT_FALSE*/;
                            }
                            //case (VarEnum.VT_BSTR, string str):
                            else if (($switch2 === 8/*VarEnum.VT_BSTR*/) && ($.$is($switch3, $.$$.System.String, { set $v(v){ str = v; } })))
                            {
                                {
                                    /*ref IntPtr*/ let bstrStorage = $.$cast(this._unmanaged.GetRawDataRef($.$$.System.IntPtr).$v, $.$typePointer($.$$.System.IntPtr));
                                    $.$$.System.Runtime.InteropServices.Marshal.FreeBSTR(bstrStorage.$v);
                                    bstrStorage.$v = $.$$.System.Runtime.InteropServices.Marshal.StringToBSTR(str);
                                    break $switchJumpStart1;
                                }
                            }
                            //case (VarEnum.VT_BSTR, BStrWrapper str):
                            else if (($switch2 === 8/*VarEnum.VT_BSTR*/) && ($.$is($switch3, $.$$.System.Runtime.InteropServices.BStrWrapper, { set $v(v){ str = v; } })))
                            {
                                {
                                    /*ref IntPtr*/ let bstrStorage = $.$cast(this._unmanaged.GetRawDataRef($.$$.System.IntPtr).$v, $.$typePointer($.$$.System.IntPtr));
                                    $.$$.System.Runtime.InteropServices.Marshal.FreeBSTR(bstrStorage.$v);
                                    bstrStorage.$v = $.$$.System.Runtime.InteropServices.Marshal.StringToBSTR(str.WrappedObject);
                                    break $switchJumpStart1;
                                }
                            }
                            //case (VarEnum.VT_DATE, DateTime dt):
                            else if (($switch2 === 7/*VarEnum.VT_DATE*/) && ($.$is($switch3, $.$$.System.DateTime, { set $v(v){ dt = v; } })))
                            {
                                $.$$.$interop.castAddress2Object(this._unmanaged.GetRawDataRef($.$$.System.IntPtr).$v).$v = dt.ToOADate();
                            }
                            //case (VarEnum.VT_ERROR, ErrorWrapper error):
                            else if (($switch2 === 10/*VarEnum.VT_ERROR*/) && ($.$is($switch3, $.$$.System.Runtime.InteropServices.ErrorWrapper, { set $v(v){ error = v; } })))
                            {
                                $.$$.$interop.castAddress2Object(this._unmanaged.GetRawDataRef($.$$.System.IntPtr).$v).$v = error.ErrorCode;
                            }
                            //case (VarEnum.VT_CY, CurrencyWrapper cy):
                            else if (($switch2 === 6/*VarEnum.VT_CY*/) && ($.$is($switch3, $.$$.System.Runtime.InteropServices.CurrencyWrapper, { set $v(v){ cy = v; } })))
                            {
                                $.$$.$interop.castAddress2Object(this._unmanaged.GetRawDataRef($.$$.System.IntPtr).$v).$v = $.$$.System.Decimal.ToOACurrency(cy.WrappedObject);
                            }
                            //case (VarEnum.VT_UNKNOWN, object unkObj):
                            else if (($switch2 === 13/*VarEnum.VT_UNKNOWN*/) && ($.$is($switch3, $.$$.System.Object, { set $v(v){ unkObj = v; } })))
                            {
                                $.$$.$interop.castAddress2Object(this._unmanaged.GetRawDataRef($.$$.System.IntPtr).$v).$v = $.$sris.System.Runtime.InteropServices.Marshalling.StrategyBasedComWrappers.DefaultMarshallingInstance.GetOrCreateComInterfaceForObject(unkObj, 0/*CreateComInterfaceFlags.None*/);
                            }
                            //default
                            else
                            {
                                throw new $.$$.System.ArgumentException().$ctor$13("Invalid combination of unmanaged variant type and managed object type.", "_managed");
                            }
                        }
                        return this._unmanaged;
                    }
                    /*object? */ ToManaged()
                    {
                        return $.$sris.System.Runtime.InteropServices.Marshalling.ComVariantMarshaller.ConvertToManaged(this._unmanaged.Clone());
                    }
                    /*void */ Free()
                    {
                        return this._unmanaged.Dispose();
                    }
                    //default value type constructor
                    $ctor$2()
                    {
                        return this;
                    }
                    Clone($copy)
                    {
                        let copy = $copy ?? new this.constructor();
                        copy._unmanaged = this._unmanaged.Clone();
                        copy._managed = this._managed;
                        return copy;
                    }
                    //default member initializer
                    constructor()
                    {
                        super();
                        this._unmanaged = $.$default($.$$.System.Runtime.InteropServices.Marshalling.ComVariant);
                        this._managed = null;
                    }
                    static $h = 2348605;
                    static $z = 144;
                    static $f = 0b10000001010000001;
                    static $k = 2;
                    static $$md;
                    static get $md() { return this.$$md ??= {"b":196609,"m":[{"r":65537,"p":[{"n":"unmanaged","p":106102785}],"n":"FromUnmanaged","d":2348605,"h":12887250493,"f":16777217},{"r":65537,"p":[{"n":"managed","p":131073}],"n":"FromManaged","d":2348605,"h":17182217789,"f":16777217},{"r":106102785,"n":"ToUnmanaged","d":2348605,"h":21477185085,"f":16777217},{"r":131073,"n":"ToManaged","d":2348605,"h":25772152381,"f":16777217},{"r":65537,"n":"Free","d":2348605,"h":30067119677,"f":16777217}],"l":[{"t":106102785,"n":"_unmanaged","d":2348605,"h":4297315901,"f":4194306},{"t":131073,"n":"_managed","d":2348605,"h":8592283197,"f":4194306}],"c":[{"n":".ctor","o":"$ctor$2","d":2348605,"h":34362086973,"f":16777217}],"d":2283069,"h":2348605}; }
                    static get $b() { return $.$$.System.ValueType; }
                    static get $fullName() { return `System.Runtime.InteropServices.Marshalling.ComVariantMarshaller.RefPropagate`; }
                }, $cls, ($v) => $cls.$_RefPropagate = $v);
            }
            static $h = 2283069;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"m":[{"r":106102785,"p":[{"n":"managed","p":131073}],"n":"ConvertToUnmanaged","d":2283069,"h":12887184957,"f":16777249},{"r":262145,"p":[{"n":"managed","p":131073},{"n":"variant","p":106102785,"f":2}],"n":"TryCreateOleVariantForInterfaceWrapper","d":2283069,"h":17182152253,"f":16777250},{"r":131073,"p":[{"n":"unmanaged","p":106102785}],"n":"ConvertToManaged","d":2283069,"h":21477119549,"f":16777249},{"r":65537,"p":[{"n":"unmanaged","p":106102785}],"n":"Free","d":2283069,"h":25772086845,"f":16777249}],"l":[{"t":524289,"n":"VARIANT_TRUE","d":2283069,"h":4297250365,"f":4194338},{"t":524289,"n":"VARIANT_FALSE","d":2283069,"h":8592217661,"f":4194338}],"j":[2348605],"h":2283069,"a":[{"t":106692609,"c":4401659905,"a":[{"v":131073,"t":142475265},{"v":0,"t":106823681},{"v":2283069,"t":142475265}]},{"t":106692609,"c":4401659905,"a":[{"v":131073,"t":142475265},{"v":5,"t":106823681},{"v":2348605,"t":142475265}]}]}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `System.Runtime.InteropServices.Marshalling.ComVariantMarshaller`; }
        });
        
        $asm.$cls("$sris.System.Runtime.InteropServices.Marshalling.DefaultIUnknownInterfaceDetailsStrategy", ($self) => class DefaultIUnknownInterfaceDetailsStrategy extends $.$$.System.Object
        {
            /*IIUnknownInterfaceDetailsStrategy*/ static Instance = null;
            /*IComExposedDetails? */ GetComExposedTypeDetails(/*RuntimeTypeHandle*/ type)
            {
                return $.$sris.System.Runtime.InteropServices.Marshalling.IComExposedDetails.System$Runtime$InteropServices$Marshalling$IComExposedDetails$GetFromAttribute(type);
            }
            /*IIUnknownDerivedDetails? */ GetIUnknownDerivedDetails(/*RuntimeTypeHandle*/ type)
            {
                return $.$sris.System.Runtime.InteropServices.Marshalling.IIUnknownDerivedDetails.System$Runtime$InteropServices$Marshalling$IIUnknownDerivedDetails$GetFromAttribute(type);
            }
            //Generated interface implemetation for System.Runtime.InteropServices.Marshalling.IIUnknownInterfaceDetailsStrategy.GetIUnknownDerivedDetails(System.RuntimeTypeHandle)
            System$Runtime$InteropServices$Marshalling$IIUnknownInterfaceDetailsStrategy$GetIUnknownDerivedDetails()
            {
                return this.GetIUnknownDerivedDetails(...arguments);
            }
            //Generated interface implemetation for System.Runtime.InteropServices.Marshalling.IIUnknownInterfaceDetailsStrategy.GetComExposedTypeDetails(System.RuntimeTypeHandle)
            System$Runtime$InteropServices$Marshalling$IIUnknownInterfaceDetailsStrategy$GetComExposedTypeDetails()
            {
                return this.GetComExposedTypeDetails(...arguments);
            }
            //default reference type constructor overload
            $ctor$1()
            {
                super.$ctor();
                return this;
            }
            //Static Initializer
            static $sinit()
            {
                {
                    this.Instance = new $.$sris.System.Runtime.InteropServices.Marshalling.DefaultIUnknownInterfaceDetailsStrategy().$ctor$1();
                }
            }
            static $h = 2479677;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"m":[{"r":3069501,"p":[{"n":"type","p":115933185}],"n":"GetComExposedTypeDetails","d":2479677,"h":8592414269,"f":16777217},{"r":3266109,"p":[{"n":"type","p":115933185}],"n":"GetIUnknownDerivedDetails","d":2479677,"h":12887381565,"f":16777217}],"l":[{"t":3331645,"n":"Instance","d":2479677,"h":4297446973,"f":4194337}],"c":[{"n":".ctor","o":"$ctor$1","d":2479677,"h":17182348861,"f":16777217}],"i":[3331645],"h":2479677}; }
            static get $b() { return $.$$.System.Object; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$sris.System.Runtime.InteropServices.Marshalling.IIUnknownInterfaceDetailsStrategy ]; }
            static get $fullName() { return `System.Runtime.InteropServices.Marshalling.DefaultIUnknownInterfaceDetailsStrategy`; }
        });
        
        $asm.$cls("$sris.System.Runtime.InteropServices.Marshalling.DefaultCaching", ($self) => class DefaultCaching extends $.$$.System.Object
        {
            /*ConcurrentDictionary<RuntimeTypeHandle, IIUnknownCacheStrategy.TableInfo>*/ _cache = null;
            /*IIUnknownCacheStrategy.TableInfo */ System$Runtime$InteropServices$Marshalling$IIUnknownCacheStrategy$ConstructTableInfo(/*RuntimeTypeHandle*/ handle, /*IIUnknownDerivedDetails*/ details, /*void**/ ptr)
            {
                /*var*/ let obj = $.$cast(ptr, $.$typePointer($.$typePointer($.$typePointer($.$$.System.Void))));
                return (() =>
                {
                    //new $.$sris.System.Runtime.InteropServices.Marshalling.IIUnknownCacheStrategy.TableInfo()
                    const $t1 = $.$sris.System.Runtime.InteropServices.Marshalling.IIUnknownCacheStrategy.TableInfo;
                    const $i1 = new $t1();
                    $i1.ThisPtr = obj;
                    $i1.Table = obj.$v;
                    $i1.ManagedType = details.System$Runtime$InteropServices$Marshalling$IIUnknownDerivedDetails$Implementation.TypeHandle;
                    return $i1;
                })();
            }
            /*bool */ System$Runtime$InteropServices$Marshalling$IIUnknownCacheStrategy$TryGetTableInfo(/*RuntimeTypeHandle*/ handle, /*out IIUnknownCacheStrategy.TableInfo*/ info)
            {
                return this._cache.TryGetValue(handle, info);
            }
            /*bool */ System$Runtime$InteropServices$Marshalling$IIUnknownCacheStrategy$TrySetTableInfo(/*RuntimeTypeHandle*/ handle, /*IIUnknownCacheStrategy.TableInfo*/ info)
            {
                return this._cache.TryAdd(handle, info);
            }
            /*void */ System$Runtime$InteropServices$Marshalling$IIUnknownCacheStrategy$Clear(/*IIUnknownStrategy*/ unknownStrategy)
            {
                var $en2 = this._cache.Values.System$Collections$Generic$IEnumerable$$$GetEnumerator();
                while ($en2.System$Collections$IEnumerator$MoveNext())
                {
                    var info = $en2.System$Collections$Generic$IEnumerator$$$Current;
                    {
                        _ = unknownStrategy.System$Runtime$InteropServices$Marshalling$IIUnknownStrategy$Release(info.ThisPtr);
                    }
                }
                this._cache.Clear();
            }
            //default reference type constructor overload
            $ctor$1()
            {
                super.$ctor();
                return this;
            }
            //default member initializer
            constructor()
            {
                super();
                this._cache = new ($.$scc.System.Collections.Concurrent.ConcurrentDictionary$$$($.$$.System.RuntimeTypeHandle, $.$sris.System.Runtime.InteropServices.Marshalling.IIUnknownCacheStrategy.TableInfo))().$ctor$8(1, 16);
            }
            static $h = 2414141;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"l":[{"t":$.$scc.System.Collections.Concurrent.ConcurrentDictionary$$$($.$$.System.RuntimeTypeHandle, $.$sris.System.Runtime.InteropServices.Marshalling.IIUnknownCacheStrategy.TableInfo).$h,"n":"_cache","d":2414141,"h":4297381437,"f":4194306}],"c":[{"n":".ctor","o":"$ctor$1","d":2414141,"h":25772217917,"f":16777217}],"i":[3135037],"h":2414141}; }
            static get $b() { return $.$$.System.Object; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$sris.System.Runtime.InteropServices.Marshalling.IIUnknownCacheStrategy ]; }
            static get $fullName() { return `System.Runtime.InteropServices.Marshalling.DefaultCaching`; }
        });
        
        $asm.$cls("$sris.System.Runtime.InteropServices.Marshalling.FreeThreadedStrategy", ($self) => class FreeThreadedStrategy extends $.$$.System.Object
        {
            /*IIUnknownStrategy*/ static Instance = null;
            /*void* */ System$Runtime$InteropServices$Marshalling$IIUnknownStrategy$CreateInstancePointer(/*void**/ unknown)
            {
                $.$$.System.Runtime.InteropServices.Marshal.AddRef($.$$.System.IntPtr.op_Explicit$4(unknown));
                return unknown;
            }
            /*int */ System$Runtime$InteropServices$Marshalling$IIUnknownStrategy$QueryInterface(/*void**/ thisPtr, /*in Guid*/ handle, /*out void**/ ppObj)
            {
                /*nint*/ let ppv;
                /*int*/ let hr = $.$$.System.Runtime.InteropServices.Marshal.QueryInterface($.$$.System.IntPtr.op_Explicit$4(thisPtr), handle, $.$ref(() => ppv, ($v) => ppv = $v, $.$$.System.IntPtr));
                if (hr < 0)
                {
                    ppObj.$v = null;
                }
                else 
                {
                    ppObj.$v = $.$$.System.IntPtr.op_Explicit$5(ppv);
                }
                return hr;
            }
            /*int */ System$Runtime$InteropServices$Marshalling$IIUnknownStrategy$Release(/*void**/ thisPtr)
            {
                return $.$$.System.Runtime.InteropServices.Marshal.Release($.$$.System.IntPtr.op_Explicit$4(thisPtr));
            }
            //default reference type constructor overload
            $ctor$1()
            {
                super.$ctor();
                return this;
            }
            //Static Initializer
            static $sinit()
            {
                {
                    this.Instance = new $.$sris.System.Runtime.InteropServices.Marshalling.FreeThreadedStrategy().$ctor$1();
                }
            }
            static $h = 2807357;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"l":[{"t":3462717,"n":"Instance","d":2807357,"h":4297774653,"f":4194337}],"c":[{"n":".ctor","o":"$ctor$1","d":2807357,"h":21477643837,"f":16777217}],"i":[3462717],"h":2807357}; }
            static get $b() { return $.$$.System.Object; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$sris.System.Runtime.InteropServices.Marshalling.IIUnknownStrategy ]; }
            static get $fullName() { return `System.Runtime.InteropServices.Marshalling.FreeThreadedStrategy`; }
        });
        
        $asm.$cls("$sris.System.Runtime.InteropServices.Marshalling.ComImportInteropInterfaceDetailsStrategy", ($self) => class ComImportInteropInterfaceDetailsStrategy extends $.$$.System.Object
        {
            /*IIUnknownInterfaceDetailsStrategy*/ static Instance = null;
            /*ConditionalWeakTable<Type, Type>*/ _forwarderInterfaceCache = null;
            /*IComExposedDetails? */ GetComExposedTypeDetails(/*RuntimeTypeHandle*/ type)
            {
                return $.$sris.System.Runtime.InteropServices.Marshalling.DefaultIUnknownInterfaceDetailsStrategy.Instance.System$Runtime$InteropServices$Marshalling$IIUnknownInterfaceDetailsStrategy$GetComExposedTypeDetails(type);
            }
            /*IIUnknownDerivedDetails? */ GetIUnknownDerivedDetails(/*RuntimeTypeHandle*/ type)
            {
                /*Type*/ let runtimeType = $.$$.System.Type.GetTypeFromHandle(type);
                if (!runtimeType.IsImport)
                {
                    return $.$sris.System.Runtime.InteropServices.Marshalling.DefaultIUnknownInterfaceDetailsStrategy.Instance.System$Runtime$InteropServices$Marshalling$IIUnknownInterfaceDetailsStrategy$GetIUnknownDerivedDetails(type);
                }
                /*Type*/ let implementationType = this._forwarderInterfaceCache.GetValue(runtimeType, new $.$$.System.Runtime.CompilerServices.ConditionalWeakTable$$$($.$$.System.Type, $.$$.System.Type).CreateValueCallback().$ctor(this,  (/**/ runtimeType) =>
                {
                    /*AssemblyBuilder*/ let assembly = /*$.$$.System.Reflection.Emit.AssemblyBuilder*/$.$$.DeletedObject.DefineDynamicAssembly(new $.$$.System.Reflection.AssemblyName().$ctor$2("ComImportForwarder"), runtimeType.IsCollectible ? 9/*AssemblyBuilderAccess.RunAndCollect*/ : 1/*AssemblyBuilderAccess.Run*/);
                    /*ModuleBuilder*/ let module = assembly.DefineDynamicModule("ComImportForwarder");
                    /*ConstructorInfo*/ let ignoresAccessChecksToAttributeConstructor = $.$sris.System.Runtime.InteropServices.Marshalling.ComImportInteropInterfaceDetailsStrategy.GetIgnoresAccessChecksToAttributeConstructor(module);
                    assembly.SetCustomAttribute(new CustomAttributeBuilder(ignoresAccessChecksToAttributeConstructor, $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$$.System.Object), [$.$sris.System.Runtime.InteropServices.Marshalling.ComImportInteropInterfaceDetailsStrategy.IComImportAdapter.$type.Assembly.GetName().Name], [-1], null)));
                    /*TypeBuilder*/ let implementation = module.DefineType("InterfaceForwarder", 32/*TypeAttributes.Interface*/ | 128/*TypeAttributes.Abstract*/, null, runtimeType.GetInterfaces());
                    implementation.AddInterfaceImplementation(runtimeType);
                    implementation.SetCustomAttribute(new CustomAttributeBuilder($.$$.System.Runtime.InteropServices.DynamicInterfaceCastableImplementationAttribute.$type.GetConstructor$4($.$$.System.Array.Empty($.$$.System.Type)), $.$$.System.Array.Empty($.$$.System.Object)));
                    let $i1 = 0;
                    let $arr1 = implementation.GetInterfaces();
                    while ($i1 < $arr1.length)
                    {
                        let iface = $arr1[$i1++];
                        assembly.SetCustomAttribute(new CustomAttributeBuilder(ignoresAccessChecksToAttributeConstructor, $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$$.System.Object), [iface.Assembly.GetName().Name], [-1], null)));
                        let $i2 = 0;
                        let $arr2 = iface.GetMethods();
                        while ($i2 < $arr2.length)
                        {
                            let method = $arr2[$i2++];
                            /*Type[]*/ let returnTypeOptionalModifiers = method.ReturnParameter.GetOptionalCustomModifiers();
                            /*Type[]*/ let returnTypeRequiredModifiers = method.ReturnParameter.GetRequiredCustomModifiers();
                            /*ParameterInfo[]*/ let parameters = method.GetParameters();
                            /*var*/ let parameterTypes = $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$$.System.Type), null, [parameters.length], null);
                            /*var*/ let parameterOptionalModifiers = $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$typeArray($.$$.System.Type)), null, [parameters.length], null);
                            /*var*/ let parameterRequiredModifiers = $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$typeArray($.$$.System.Type)), null, [parameters.length], null);
                            for(/*int*/ let i = 0; i < parameters.length; i++)
                            {
                                $.$$.System.Array.$WriteT1.call(parameterTypes, $.$$.System.Array.$ReadT1.call(parameters, i).ParameterType, i);
                                $.$$.System.Array.$WriteT1.call(parameterOptionalModifiers, $.$$.System.Array.$ReadT1.call(parameters, i).GetOptionalCustomModifiers(), i);
                                $.$$.System.Array.$WriteT1.call(parameterRequiredModifiers, $.$$.System.Array.$ReadT1.call(parameters, i).GetRequiredCustomModifiers(), i);
                            }
                            /*MethodBuilder*/ let builder = implementation.DefineMethod(method.Name, 1/*MethodAttributes.Private*/ | 32/*MethodAttributes.Final*/ | 128/*MethodAttributes.HideBySig*/ | 64/*MethodAttributes.Virtual*/, 32/*CallingConventions.HasThis*/, method.ReturnType, returnTypeRequiredModifiers, returnTypeOptionalModifiers, parameterTypes, parameterRequiredModifiers, parameterOptionalModifiers);
                            /*ILGenerator*/ let il = builder.GetILGenerator();
                            il.Emit(/*$.$$.System.Reflection.Emit.OpCodes*/$.$$.DeletedObject.Ldarg_0);
                            il.Emit(/*$.$$.System.Reflection.Emit.OpCodes*/$.$$.DeletedObject.Castclass, $.$sris.System.Runtime.InteropServices.Marshalling.ComImportInteropInterfaceDetailsStrategy.IComImportAdapter.$type);
                            il.Emit(/*$.$$.System.Reflection.Emit.OpCodes*/$.$$.DeletedObject.Callvirt, $.$sris.System.Runtime.InteropServices.Marshalling.ComImportInteropInterfaceDetailsStrategy.IComImportAdapter.System$Runtime$InteropServices$Marshalling$ComImportInteropInterfaceDetailsStrategy$IComImportAdapter$GetRuntimeCallableWrapperMethod);
                            il.Emit(/*$.$$.System.Reflection.Emit.OpCodes*/$.$$.DeletedObject.Castclass, iface);
                            for(/*int*/ let i = 0; i < parameters.length; i++)
                            {
                                il.Emit(/*$.$$.System.Reflection.Emit.OpCodes*/$.$$.DeletedObject.Ldarg, ((i + 1) | 0));
                            }
                            il.Emit(/*$.$$.System.Reflection.Emit.OpCodes*/$.$$.DeletedObject.Callvirt, method);
                            il.Emit(/*$.$$.System.Reflection.Emit.OpCodes*/$.$$.DeletedObject.Ret);
                            implementation.DefineMethodOverride(builder, method);
                        }
                    }
                    return implementation.CreateType();
                }, {"r":142475265,"p":[{"n":"runtimeType","p":142475265}],"n":"","d":1889853,"h":0,"f":17825794}));
                return new $.$sris.System.Runtime.InteropServices.Marshalling.ComImportInteropInterfaceDetailsStrategy.ComImportDetails().$ctor$1(runtimeType.GUID, implementationType);
            }
            /*ConstructorInfo*/ static s_attributeBaseClassCtor = null;
            /*ConstructorInfo*/ static s_attributeUsageCtor = null;
            /*PropertyInfo*/ static s_attributeUsageAllowMultipleProperty = null;
            static $_ComImportDetails;
            static get ComImportDetails()
            {
                let $cls = $.$sris.System.Runtime.InteropServices.Marshalling.ComImportInteropInterfaceDetailsStrategy;
                return $cls.$_ComImportDetails ??= $asm.$ncls("$sris.System.Runtime.InteropServices.Marshalling.ComImportInteropInterfaceDetailsStrategy.ComImportDetails", ($self) => class ComImportDetails extends $.$$.System.Object
                {
                    /*Guid*/ Iid;
                    /*Type*/ Implementation = null;
                    /*void** */ get ManagedVirtualMethodTable()
                    {
                        return null;
                    }
                    //Generated interface implemetation for System.Runtime.InteropServices.Marshalling.IIUnknownDerivedDetails.Iid.get
                    get System$Runtime$InteropServices$Marshalling$IIUnknownDerivedDetails$Iid()
                    {
                        return this.Iid;
                    }
                    //Generated interface implemetation for System.Runtime.InteropServices.Marshalling.IIUnknownDerivedDetails.Implementation.get
                    get System$Runtime$InteropServices$Marshalling$IIUnknownDerivedDetails$Implementation()
                    {
                        return this.Implementation;
                    }
                    //Generated interface implemetation for System.Runtime.InteropServices.Marshalling.IIUnknownDerivedDetails.ManagedVirtualMethodTable.get
                    get System$Runtime$InteropServices$Marshalling$IIUnknownDerivedDetails$ManagedVirtualMethodTable()
                    {
                        return this.ManagedVirtualMethodTable;
                    }
                    //Begin primary constructor
                    /*Guid*/ iid = new $.$$.System.Guid();
                    /*Type*/ implementation = null;
                    $ctor$1(/*Guid*/$iid, /*Type*/$implementation)
                    {
                        this.iid = $iid;
                        this.implementation = $implementation;
                        //depends on primary constructor parameter
                        this.Iid = this.iid;
                        //depends on primary constructor parameter
                        this.Implementation = this.implementation;
                        return this
                    }
                    //End primary constructor
                    static $h = 1955389;
                    static $f = 0b10000000010010000;
                    static $k = 1;
                    static $$md;
                    static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":56229889,"g":{"r":0,"d":0,"h":17181824573,"f":50331649},"n":"Iid","d":1955389,"h":12886857277,"f":2097153},{"p":142475265,"g":{"r":0,"d":0,"h":30066726461,"f":50331649},"n":"Implementation","d":1955389,"h":25771759165,"f":2097153},{"p":$.$typePointer($.$typePointer($.$$.System.Void)).$h,"g":{"r":0,"d":0,"h":38656661053,"f":50331649},"n":"ManagedVirtualMethodTable","d":1955389,"h":34361693757,"f":2097153}],"c":[{"p":[{"n":"iid","p":56229889},{"n":"implementation","p":142475265}],"n":".ctor","o":"$ctor$1","d":1955389,"h":4296922685,"f":16777217}],"i":[3266109],"d":1889853,"h":1955389}; }
                    static get $b() { return $.$$.System.Object; }
                    static $$i;
                    static get $i() { return this.$$i ??= [ $.$sris.System.Runtime.InteropServices.Marshalling.IIUnknownDerivedDetails ]; }
                    static get $fullName() { return `System.Runtime.InteropServices.Marshalling.ComImportInteropInterfaceDetailsStrategy.ComImportDetails`; }
                }, $cls, ($v) => $cls.$_ComImportDetails = $v);
            }
            static $_IComImportAdapter;
            static get IComImportAdapter()
            {
                let $cls = $.$sris.System.Runtime.InteropServices.Marshalling.ComImportInteropInterfaceDetailsStrategy;
                return $cls.$_IComImportAdapter ??= $asm.$ncls("$sris.System.Runtime.InteropServices.Marshalling.ComImportInteropInterfaceDetailsStrategy.IComImportAdapter", ($self) => class IComImportAdapter
                {
                    /*MethodInfo*/ static System$Runtime$InteropServices$Marshalling$ComImportInteropInterfaceDetailsStrategy$IComImportAdapter$GetRuntimeCallableWrapperMethod = null;
                    //Static Initializer
                    static $sinit()
                    {
                        {
                            this.System$Runtime$InteropServices$Marshalling$ComImportInteropInterfaceDetailsStrategy$IComImportAdapter$GetRuntimeCallableWrapperMethod = $.$sris.System.Runtime.InteropServices.Marshalling.ComImportInteropInterfaceDetailsStrategy.IComImportAdapter.$type.GetMethod$12("GetRuntimeCallableWrapper");
                        }
                    }
                    static $h = 2020925;
                    static $f = 0b10000000000100100;
                    static $k = 3;
                    static $$md;
                    static get $md() { return this.$$md ??= {"m":[{"r":131073,"n":"GetRuntimeCallableWrapper","o":"System$Runtime$InteropServices$Marshalling$ComImportInteropInterfaceDetailsStrategy$IComImportAdapter$GetRuntimeCallableWrapper","d":2020925,"h":8591955517,"f":16777473}],"l":[{"t":79626241,"n":"GetRuntimeCallableWrapperMethod","o":"System$Runtime$InteropServices$Marshalling$ComImportInteropInterfaceDetailsStrategy$IComImportAdapter$GetRuntimeCallableWrapperMethod","d":2020925,"h":4296988221,"f":4194344}],"d":1889853,"h":2020925}; }
                    static get $fullName() { return `System.Runtime.InteropServices.Marshalling.ComImportInteropInterfaceDetailsStrategy.IComImportAdapter`; }
                }, $cls, ($v) => $cls.$_IComImportAdapter = $v);
            }
            //Generated interface implemetation for System.Runtime.InteropServices.Marshalling.IIUnknownInterfaceDetailsStrategy.GetIUnknownDerivedDetails(System.RuntimeTypeHandle)
            System$Runtime$InteropServices$Marshalling$IIUnknownInterfaceDetailsStrategy$GetIUnknownDerivedDetails()
            {
                return this.GetIUnknownDerivedDetails(...arguments);
            }
            //Generated interface implemetation for System.Runtime.InteropServices.Marshalling.IIUnknownInterfaceDetailsStrategy.GetComExposedTypeDetails(System.RuntimeTypeHandle)
            System$Runtime$InteropServices$Marshalling$IIUnknownInterfaceDetailsStrategy$GetComExposedTypeDetails()
            {
                return this.GetComExposedTypeDetails(...arguments);
            }
            //default reference type constructor overload
            $ctor$1()
            {
                super.$ctor();
                return this;
            }
            //default member initializer
            constructor()
            {
                super();
                this._forwarderInterfaceCache = new ($.$$.System.Runtime.CompilerServices.ConditionalWeakTable$$$($.$$.System.Type, $.$$.System.Type))().$ctor$1();
            }
            //Static Initializer
            static $sinit()
            {
                {
                    this.Instance = new $.$sris.System.Runtime.InteropServices.Marshalling.ComImportInteropInterfaceDetailsStrategy().$ctor$1();
                }
                {
                    this.s_attributeBaseClassCtor = $.$$.System.Array.$ReadT1.call($.$$.System.Attribute.$type.GetConstructors$1(32/*BindingFlags.NonPublic*/ | 4/*BindingFlags.Instance*/), 0);
                }
                {
                    this.s_attributeUsageCtor = $.$$.System.AttributeUsageAttribute.$type.GetConstructor$4($.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$$.System.Type), [$.$$.System.AttributeTargets.$type], [-1], null));
                }
                {
                    this.s_attributeUsageAllowMultipleProperty = $.$$.System.AttributeUsageAttribute.$type.GetProperty$6("AllowMultiple");
                }
            }
            static $h = 1889853;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"m":[{"r":3069501,"p":[{"n":"type","p":115933185}],"n":"GetComExposedTypeDetails","d":1889853,"h":12886791741,"f":16777217},{"r":3266109,"p":[{"n":"type","p":115933185}],"n":"GetIUnknownDerivedDetails","d":1889853,"h":17181759037,"f":16777217},{"r":75628545,"p":[{"n":"moduleBuilder"}],"n":"GetIgnoresAccessChecksToAttributeConstructor","d":1889853,"h":21476726333,"f":16777250},{"r":142475265,"p":[{"n":"moduleBuilder"}],"n":"EmitIgnoresAccessChecksToAttribute","d":1889853,"h":25771693629,"f":16777250}],"l":[{"t":3331645,"n":"Instance","d":1889853,"h":4296857149,"f":4194337},{"t":$.$$.System.Runtime.CompilerServices.ConditionalWeakTable$$$($.$$.System.Type, $.$$.System.Type).$h,"n":"_forwarderInterfaceCache","d":1889853,"h":8591824445,"f":4194306},{"t":75628545,"n":"s_attributeBaseClassCtor","d":1889853,"h":30066660925,"f":4194338},{"t":75628545,"n":"s_attributeUsageCtor","d":1889853,"h":34361628221,"f":4194338},{"t":81657857,"n":"s_attributeUsageAllowMultipleProperty","d":1889853,"h":38656595517,"f":4194338}],"c":[{"n":".ctor","o":"$ctor$1","d":1889853,"h":51541497405,"f":16777217}],"i":[3331645],"j":[1955389,2020925],"h":1889853}; }
            static get $b() { return $.$$.System.Object; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$sris.System.Runtime.InteropServices.Marshalling.IIUnknownInterfaceDetailsStrategy ]; }
            static get $fullName() { return `System.Runtime.InteropServices.Marshalling.ComImportInteropInterfaceDetailsStrategy`; }
        });
        
        $asm.$str("$sris.System.Runtime.InteropServices.ComTypes.STGMEDIUM", ($self) => class STGMEDIUM extends $.$$.System.ValueType
        {
            /*TYMED*/  get tymed() { return this.$getField(0, 4); }
            /*TYMED*/  set tymed(value) { this.$setField(0, 4, value); }
            /*IntPtr*/  get unionmember() { return this.$getField(4, 4); }
            /*IntPtr*/  set unionmember(value) { this.$setField(4, 4, value); }
            /*object?*/  get pUnkForRelease() { return this.$getField(8, 4); }
            /*object?*/  set pUnkForRelease(value) { this.$setField(8, 4, value); }
            //default value type constructor
            $ctor$2()
            {
                return this;
            }
            Clone($copy)
            {
                let copy = $copy ?? new this.constructor();
                copy.tymed = this.tymed;
                copy.unionmember = this.unionmember;
                copy.pUnkForRelease = this.pUnkForRelease;
                return copy;
            }
            //default member initializer
            constructor()
            {
                super();
                this.tymed = 0;
                this.unionmember = 0;
                this.pUnkForRelease = null;
            }
            static $h = 1365565;
            static $z = 12;
            static $f = 0b1010000001;
            static $k = 2;
            static $$md;
            static get $md() { return this.$$md ??= {"b":196609,"l":[{"t":1431101,"n":"tymed","d":1365565,"h":4296332861,"f":4194305},{"t":786433,"n":"unionmember","d":1365565,"h":8591300157,"f":4194305},{"t":131073,"n":"pUnkForRelease","d":1365565,"h":12886267453,"f":4194305,"a":[{"t":105578497,"c":8695513089,"a":[{"v":25,"t":110755841}]}]}],"c":[{"n":".ctor","o":"$ctor$2","d":1365565,"h":17181234749,"f":16777217}],"h":1365565,"a":[{"t":33292289,"c":4328259585,"a":[{"v":1,"t":33357825}]}]}; }
            static get $b() { return $.$$.System.ValueType; }
            static get $fullName() { return `System.Runtime.InteropServices.ComTypes.STGMEDIUM`; }
        });
        
        $asm.$cls("$sris.System.Runtime.InteropServices.ComConversionLossAttribute", ($self) => class ComConversionLossAttribute extends $.$$.System.Attribute
        {
            //default reference type constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                return this;
            }
            static $h = 644669;
            static $f = 0b10010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":14614529,"c":[{"n":".ctor","o":"$ctor$2","d":644669,"h":4295611965,"f":16777217}],"h":644669,"a":[{"t":14745601,"c":21489582081,"a":[{"v":32767,"t":14680065}],"n":[{"n":"Inherited","v":false,"t":262145}]}]}; }
            static get $b() { return $.$$.System.Attribute; }
            static get $fullName() { return `System.Runtime.InteropServices.ComConversionLossAttribute`; }
        });
        
        $asm.$cls("$sris.System.Runtime.InteropServices.ComRegisterFunctionAttribute", ($self) => class ComRegisterFunctionAttribute extends $.$$.System.Attribute
        {
            //default reference type constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                return this;
            }
            static $h = 710205;
            static $f = 0b10010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":14614529,"c":[{"n":".ctor","o":"$ctor$2","d":710205,"h":4295677501,"f":16777217}],"h":710205,"a":[{"t":14745601,"c":21489582081,"a":[{"v":64,"t":14680065}],"n":[{"n":"Inherited","v":false,"t":262145}]}]}; }
            static get $b() { return $.$$.System.Attribute; }
            static get $fullName() { return `System.Runtime.InteropServices.ComRegisterFunctionAttribute`; }
        });
        
        $asm.$cls("$sris.System.Runtime.InteropServices.ComUnregisterFunctionAttribute", ($self) => class ComUnregisterFunctionAttribute extends $.$$.System.Attribute
        {
            //default reference type constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                return this;
            }
            static $h = 1496637;
            static $f = 0b10010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":14614529,"c":[{"n":".ctor","o":"$ctor$2","d":1496637,"h":4296463933,"f":16777217}],"h":1496637,"a":[{"t":14745601,"c":21489582081,"a":[{"v":64,"t":14680065}],"n":[{"n":"Inherited","v":false,"t":262145}]}]}; }
            static get $b() { return $.$$.System.Attribute; }
            static get $fullName() { return `System.Runtime.InteropServices.ComUnregisterFunctionAttribute`; }
        });
        
        $asm.$cls("$sris.System.Runtime.InteropServices.AutomationProxyAttribute", ($self) => class AutomationProxyAttribute extends $.$$.System.Attribute
        {
            $ctor$2(/*bool*/ val)
            {
                super.$ctor$1();
                this.Value = val;
                return this;
            }
            /*bool*/ Value = false;
            //default member initializer
            constructor()
            {
                super();
                this.Value = false;
            }
            static $h = 382525;
            static $f = 0b10010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":14614529,"p":[{"p":262145,"g":{"r":0,"d":0,"h":17180251709,"f":50331649},"n":"Value","d":382525,"h":12885284413,"f":2097153}],"c":[{"p":[{"n":"val","p":262145}],"n":".ctor","o":"$ctor$2","d":382525,"h":4295349821,"f":16777217}],"h":382525,"a":[{"t":14745601,"c":21489582081,"a":[{"v":1029,"t":14680065}],"n":[{"n":"Inherited","v":false,"t":262145}]}]}; }
            static get $b() { return $.$$.System.Attribute; }
            static get $fullName() { return `System.Runtime.InteropServices.AutomationProxyAttribute`; }
        });
        
        $asm.$cls("$sris.System.Runtime.InteropServices.ComAliasNameAttribute", ($self) => class ComAliasNameAttribute extends $.$$.System.Attribute
        {
            $ctor$2(/*string*/ alias)
            {
                super.$ctor$1();
                this.Value = alias;
                return this;
            }
            /*string*/ Value = null;
            static $h = 448061;
            static $f = 0b10010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":14614529,"p":[{"p":1310721,"g":{"r":0,"d":0,"h":17180317245,"f":50331649},"n":"Value","d":448061,"h":12885349949,"f":2097153}],"c":[{"p":[{"n":"alias","p":1310721}],"n":".ctor","o":"$ctor$2","d":448061,"h":4295415357,"f":16777217}],"h":448061,"a":[{"t":14745601,"c":21489582081,"a":[{"v":10624,"t":14680065}],"n":[{"n":"Inherited","v":false,"t":262145}]}]}; }
            static get $b() { return $.$$.System.Attribute; }
            static get $fullName() { return `System.Runtime.InteropServices.ComAliasNameAttribute`; }
        });
        
        $asm.$str("$sris.System.Runtime.InteropServices.ComTypes.STATDATA", ($self) => class STATDATA extends $.$$.System.ValueType
        {
            /*FORMATETC*/  get formatetc() { return this.$getField(0, 18); }
            /*FORMATETC*/  set formatetc(value) { this.$setField(0, 18, value); }
            /*ADVF*/  get advf() { return this.$getField(18, 4); }
            /*ADVF*/  set advf(value) { this.$setField(18, 4, value); }
            /*IAdviseSink*/  get advSink() { return this.$getField(22, 4); }
            /*IAdviseSink*/  set advSink(value) { this.$setField(22, 4, value); }
            /*int*/  get connection() { return this.$getField(26, 4); }
            /*int*/  set connection(value) { this.$setField(26, 4, value); }
            //default value type constructor
            $ctor$2()
            {
                return this;
            }
            Clone($copy)
            {
                let copy = $copy ?? new this.constructor();
                copy.formatetc = this.formatetc.Clone();
                copy.advf = this.advf;
                copy.advSink = this.advSink;
                copy.connection = this.connection;
                return copy;
            }
            //default member initializer
            constructor()
            {
                super();
                this.formatetc = $.$default($.$sris.System.Runtime.InteropServices.ComTypes.FORMATETC);
                this.advf = 0;
                this.advSink = null;
                this.connection = 0;
            }
            static $h = 1300029;
            static $z = 30;
            static $f = 0b1010000001;
            static $k = 2;
            static $$md;
            static get $md() { return this.$$md ??= {"b":196609,"l":[{"t":972349,"n":"formatetc","d":1300029,"h":4296267325,"f":4194305},{"t":775741,"n":"advf","d":1300029,"h":8591234621,"f":4194305},{"t":1037885,"n":"advSink","d":1300029,"h":12886201917,"f":4194305},{"t":655361,"n":"connection","d":1300029,"h":17181169213,"f":4194305}],"c":[{"n":".ctor","o":"$ctor$2","d":1300029,"h":21476136509,"f":16777217}],"h":1300029,"a":[{"t":33292289,"c":4328259585,"a":[{"v":1,"t":33357825}]}]}; }
            static get $b() { return $.$$.System.ValueType; }
            static get $fullName() { return `System.Runtime.InteropServices.ComTypes.STATDATA`; }
        });
        
        $asm.$str("$sris.System.Runtime.InteropServices.ComTypes.FORMATETC", ($self) => class FORMATETC extends $.$$.System.ValueType
        {
            /*short*/  get cfFormat() { return this.$getField(0, $.$$.System.Int16); }
            /*short*/  set cfFormat(value) { this.$setField(0, $.$$.System.Int16, value); }
            /*IntPtr*/  get ptd() { return this.$getField(2, $.$$.System.IntPtr); }
            /*IntPtr*/  set ptd(value) { this.$setField(2, $.$$.System.IntPtr, value); }
            /*DVASPECT*/  get dwAspect() { return this.$getField(6, $.$sris.System.Runtime.InteropServices.ComTypes.DVASPECT); }
            /*DVASPECT*/  set dwAspect(value) { this.$setField(6, $.$sris.System.Runtime.InteropServices.ComTypes.DVASPECT, value); }
            /*int*/  get lindex() { return this.$getField(10, $.$$.System.Int32); }
            /*int*/  set lindex(value) { this.$setField(10, $.$$.System.Int32, value); }
            /*TYMED*/  get tymed() { return this.$getField(14, $.$sris.System.Runtime.InteropServices.ComTypes.TYMED); }
            /*TYMED*/  set tymed(value) { this.$setField(14, $.$sris.System.Runtime.InteropServices.ComTypes.TYMED, value); }
            //default value type constructor
            $ctor$2()
            {
                return this;
            }
            Clone($copy)
            {
                let copy = $copy ?? new this.constructor();
                copy.cfFormat = this.cfFormat;
                copy.ptd = this.ptd;
                copy.dwAspect = this.dwAspect;
                copy.lindex = this.lindex;
                copy.tymed = this.tymed;
                return copy;
            }
            //default member initializer
            constructor()
            {
                super();
                this.cfFormat = 0;
                this.ptd = 0;
                this.dwAspect = 0;
                this.lindex = 0;
                this.tymed = 0;
            }
            static $h = 972349;
            static $z = 18;
            static $f = 0b10000000000001010000001;
            static $k = 2;
            static $$md;
            static get $md() { return this.$$md ??= {"b":196609,"l":[{"t":524289,"n":"cfFormat","d":972349,"h":4295939645,"f":4194305,"a":[{"t":105578497,"c":8695513089,"a":[{"v":6,"t":110755841}]}]},{"t":786433,"n":"ptd","d":972349,"h":8590906941,"f":4194305},{"t":906813,"n":"dwAspect","d":972349,"h":12885874237,"f":4194305,"a":[{"t":105578497,"c":8695513089,"a":[{"v":8,"t":110755841}]}]},{"t":655361,"n":"lindex","d":972349,"h":17180841533,"f":4194305},{"t":1431101,"n":"tymed","d":972349,"h":21475808829,"f":4194305,"a":[{"t":105578497,"c":8695513089,"a":[{"v":8,"t":110755841}]}]}],"c":[{"n":".ctor","o":"$ctor$2","d":972349,"h":25770776125,"f":16777217}],"h":972349,"a":[{"t":33292289,"c":4328259585,"a":[{"v":1,"t":33357825}]}]}; }
            static get $b() { return $.$$.System.ValueType; }
            static get $fullName() { return `System.Runtime.InteropServices.ComTypes.FORMATETC`; }
        });
        
        $asm.$cls("$sris.System.Runtime.InteropServices.ManagedToNativeComInteropStubAttribute", ($self) => class ManagedToNativeComInteropStubAttribute extends $.$$.System.Attribute
        {
            $ctor$2(/*Type*/ classType, /*string*/ methodName)
            {
                super.$ctor$1();
                {
                    this.ClassType = classType;
                    this.MethodName = methodName;
                }
                return this;
            }
            /*Type*/ ClassType = null;
            /*string*/ MethodName = null;
            static $h = 1758781;
            static $f = 0b10010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":14614529,"p":[{"p":142475265,"g":{"r":0,"d":0,"h":17181627965,"f":50331649},"n":"ClassType","d":1758781,"h":12886660669,"f":2097153},{"p":1310721,"g":{"r":0,"d":0,"h":30066529853,"f":50331649},"n":"MethodName","d":1758781,"h":25771562557,"f":2097153}],"c":[{"p":[{"n":"classType","p":142475265},{"n":"methodName","p":1310721}],"n":".ctor","o":"$ctor$2","d":1758781,"h":4296726077,"f":16777217}],"h":1758781,"a":[{"t":14745601,"c":21489582081,"a":[{"v":64,"t":14680065}],"n":[{"n":"Inherited","v":false,"t":262145},{"n":"AllowMultiple","v":false,"t":262145}]}]}; }
            static get $b() { return $.$$.System.Attribute; }
            static get $fullName() { return `System.Runtime.InteropServices.ManagedToNativeComInteropStubAttribute`; }
        });
        
        $asm.$cls("$sris.System.Runtime.InteropServices.ComCompatibleVersionAttribute", ($self) => class ComCompatibleVersionAttribute extends $.$$.System.Attribute
        {
            $ctor$2(/*int*/ major, /*int*/ minor, /*int*/ build, /*int*/ revision)
            {
                super.$ctor$1();
                {
                    this.MajorVersion = major;
                    this.MinorVersion = minor;
                    this.BuildNumber = build;
                    this.RevisionNumber = revision;
                }
                return this;
            }
            /*int*/ MajorVersion = 0;
            /*int*/ MinorVersion = 0;
            /*int*/ BuildNumber = 0;
            /*int*/ RevisionNumber = 0;
            static $h = 579133;
            static $f = 0b10010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":14614529,"p":[{"p":655361,"g":{"r":0,"d":0,"h":17180448317,"f":50331649},"n":"MajorVersion","d":579133,"h":12885481021,"f":2097153},{"p":655361,"g":{"r":0,"d":0,"h":30065350205,"f":50331649},"n":"MinorVersion","d":579133,"h":25770382909,"f":2097153},{"p":655361,"g":{"r":0,"d":0,"h":42950252093,"f":50331649},"n":"BuildNumber","d":579133,"h":38655284797,"f":2097153},{"p":655361,"g":{"r":0,"d":0,"h":55835153981,"f":50331649},"n":"RevisionNumber","d":579133,"h":51540186685,"f":2097153}],"c":[{"p":[{"n":"major","p":655361},{"n":"minor","p":655361},{"n":"build","p":655361},{"n":"revision","p":655361}],"n":".ctor","o":"$ctor$2","d":579133,"h":4295546429,"f":16777217}],"h":579133,"a":[{"t":14745601,"c":21489582081,"a":[{"v":1,"t":14680065}],"n":[{"n":"Inherited","v":false,"t":262145}]}]}; }
            static get $b() { return $.$$.System.Attribute; }
            static get $fullName() { return `System.Runtime.InteropServices.ComCompatibleVersionAttribute`; }
        });
        
        $asm.$cls("$sris.System.Runtime.InteropServices.Marshalling.GeneratedComInterfaceAttribute", ($self) => class GeneratedComInterfaceAttribute extends $.$$.System.Attribute
        {
            /*ComInterfaceOptions*/ Options = 0;
            /*StringMarshalling*/ StringMarshalling = 0;
            /*Type?*/ StringMarshallingCustomType = null;
            /*Type?*/ ExceptionToUnmanagedMarshaller = null;
            //default reference type constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                return this;
            }
            //default member initializer
            constructor()
            {
                super();
                this.Options = 3;
                this.StringMarshalling = 0;
            }
            static $h = 2938429;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":14614529,"p":[{"p":2151997,"g":{"r":0,"d":0,"h":12887840317,"f":50331649},"s":{"r":0,"d":0,"h":17182807613,"f":83886081},"n":"Options","d":2938429,"h":8592873021,"f":2097153},{"p":109707265,"g":{"r":0,"d":0,"h":30067709501,"f":50331649},"s":{"r":0,"d":0,"h":34362676797,"f":83886081},"n":"StringMarshalling","d":2938429,"h":25772742205,"f":2097153},{"p":142475265,"g":{"r":0,"d":0,"h":47247578685,"f":50331649},"s":{"r":0,"d":0,"h":51542545981,"f":83886081},"n":"StringMarshallingCustomType","d":2938429,"h":42952611389,"f":2097153},{"p":142475265,"g":{"r":0,"d":0,"h":64427447869,"f":50331649},"s":{"r":0,"d":0,"h":68722415165,"f":83886081},"n":"ExceptionToUnmanagedMarshaller","d":2938429,"h":60132480573,"f":2097153}],"c":[{"n":".ctor","o":"$ctor$2","d":2938429,"h":73017382461,"f":16777217}],"h":2938429,"a":[{"t":14745601,"c":21489582081,"a":[{"v":1024,"t":14680065}]}]}; }
            static get $b() { return $.$$.System.Attribute; }
            static get $fullName() { return `System.Runtime.InteropServices.Marshalling.GeneratedComInterfaceAttribute`; }
        });
        
        $asm.$cls("$sris.System.Runtime.InteropServices.TypeLibTypeAttribute", ($self) => class TypeLibTypeAttribute extends $.$$.System.Attribute
        {
            $ctor$3(/*TypeLibTypeFlags*/ flags)
            {
                super.$ctor$1();
                {
                    this.Value = flags;
                }
                return this;
            }
            $ctor$2(/*short*/ flags)
            {
                super.$ctor$1();
                {
                    this.Value = $.$cast(flags, $.$sris.System.Runtime.InteropServices.TypeLibTypeFlags);
                }
                return this;
            }
            /*TypeLibTypeFlags*/ Value = 0;
            //default member initializer
            constructor()
            {
                super();
                this.Value = 0;
            }
            static $h = 4314685;
            static $f = 0b10010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":14614529,"p":[{"p":4380221,"g":{"r":0,"d":0,"h":21479151165,"f":50331649},"n":"Value","d":4314685,"h":17184183869,"f":2097153}],"c":[{"p":[{"n":"flags","p":4380221}],"n":".ctor","o":"$ctor$3","d":4314685,"h":4299281981,"f":16777217},{"p":[{"n":"flags","p":524289}],"n":".ctor","o":"$ctor$2","d":4314685,"h":8594249277,"f":16777217}],"h":4314685,"a":[{"t":14745601,"c":21489582081,"a":[{"v":1052,"t":14680065}],"n":[{"n":"Inherited","v":false,"t":262145}]}]}; }
            static get $b() { return $.$$.System.Attribute; }
            static get $fullName() { return `System.Runtime.InteropServices.TypeLibTypeAttribute`; }
        });
        
        $asm.$cls("$sris.System.Runtime.InteropServices.TypeLibVersionAttribute", ($self) => class TypeLibVersionAttribute extends $.$$.System.Attribute
        {
            $ctor$2(/*int*/ major, /*int*/ minor)
            {
                super.$ctor$1();
                {
                    this.MajorVersion = major;
                    this.MinorVersion = minor;
                }
                return this;
            }
            /*int*/ MajorVersion = 0;
            /*int*/ MinorVersion = 0;
            static $h = 4576829;
            static $f = 0b10010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":14614529,"p":[{"p":655361,"g":{"r":0,"d":0,"h":17184446013,"f":50331649},"n":"MajorVersion","d":4576829,"h":12889478717,"f":2097153},{"p":655361,"g":{"r":0,"d":0,"h":30069347901,"f":50331649},"n":"MinorVersion","d":4576829,"h":25774380605,"f":2097153}],"c":[{"p":[{"n":"major","p":655361},{"n":"minor","p":655361}],"n":".ctor","o":"$ctor$2","d":4576829,"h":4299544125,"f":16777217}],"h":4576829,"a":[{"t":14745601,"c":21489582081,"a":[{"v":1,"t":14680065}],"n":[{"n":"Inherited","v":false,"t":262145}]}]}; }
            static get $b() { return $.$$.System.Attribute; }
            static get $fullName() { return `System.Runtime.InteropServices.TypeLibVersionAttribute`; }
        });
        
        $asm.$cls("$sris.System.Runtime.InteropServices.TypeLibFuncAttribute", ($self) => class TypeLibFuncAttribute extends $.$$.System.Attribute
        {
            $ctor$3(/*TypeLibFuncFlags*/ flags)
            {
                super.$ctor$1();
                {
                    this.Value = flags;
                }
                return this;
            }
            $ctor$2(/*short*/ flags)
            {
                super.$ctor$1();
                {
                    this.Value = $.$cast(flags, $.$sris.System.Runtime.InteropServices.TypeLibFuncFlags);
                }
                return this;
            }
            /*TypeLibFuncFlags*/ Value = 0;
            //default member initializer
            constructor()
            {
                super();
                this.Value = 0;
            }
            static $h = 4118077;
            static $f = 0b10010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":14614529,"p":[{"p":4183613,"g":{"r":0,"d":0,"h":21478954557,"f":50331649},"n":"Value","d":4118077,"h":17183987261,"f":2097153}],"c":[{"p":[{"n":"flags","p":4183613}],"n":".ctor","o":"$ctor$3","d":4118077,"h":4299085373,"f":16777217},{"p":[{"n":"flags","p":524289}],"n":".ctor","o":"$ctor$2","d":4118077,"h":8594052669,"f":16777217}],"h":4118077,"a":[{"t":14745601,"c":21489582081,"a":[{"v":64,"t":14680065}],"n":[{"n":"Inherited","v":false,"t":262145}]}]}; }
            static get $b() { return $.$$.System.Attribute; }
            static get $fullName() { return `System.Runtime.InteropServices.TypeLibFuncAttribute`; }
        });
        
        $asm.$cls("$sris.System.Runtime.InteropServices.Marshalling.GeneratedComClassAttribute", ($self) => class GeneratedComClassAttribute extends $.$$.System.Attribute
        {
            //default reference type constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                return this;
            }
            static $h = 2872893;
            static $f = 0b10010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":14614529,"c":[{"n":".ctor","o":"$ctor$2","d":2872893,"h":4297840189,"f":16777217}],"h":2872893,"a":[{"t":14745601,"c":21489582081,"a":[{"v":4,"t":14680065}]}]}; }
            static get $b() { return $.$$.System.Attribute; }
            static get $fullName() { return `System.Runtime.InteropServices.Marshalling.GeneratedComClassAttribute`; }
        });
        
        $asm.$cls("$sris.System.Runtime.InteropServices.TypeLibImportClassAttribute", ($self) => class TypeLibImportClassAttribute extends $.$$.System.Attribute
        {
            $ctor$2(/*Type*/ importClass)
            {
                super.$ctor$1();
                this.Value = $.$$.System.Type.ToString.call(importClass);
                return this;
            }
            /*string*/ Value = null;
            static $h = 4249149;
            static $f = 0b10010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":14614529,"p":[{"p":1310721,"g":{"r":0,"d":0,"h":17184118333,"f":50331649},"n":"Value","d":4249149,"h":12889151037,"f":2097153}],"c":[{"p":[{"n":"importClass","p":142475265}],"n":".ctor","o":"$ctor$2","d":4249149,"h":4299216445,"f":16777217}],"h":4249149,"a":[{"t":14745601,"c":21489582081,"a":[{"v":1024,"t":14680065}],"n":[{"n":"Inherited","v":false,"t":262145}]}]}; }
            static get $b() { return $.$$.System.Attribute; }
            static get $fullName() { return `System.Runtime.InteropServices.TypeLibImportClassAttribute`; }
        });
        
        $asm.$cls("$sris.System.Runtime.InteropServices.Marshalling.StrategyBasedComWrappers", ($self) => class StrategyBasedComWrappers extends $.$$.System.Runtime.InteropServices.ComWrappers
        {
            /*StrategyBasedComWrappers*/ static DefaultMarshallingInstance = null;
            /*IIUnknownInterfaceDetailsStrategy*/ static DefaultIUnknownInterfaceDetailsStrategy = null;
            /*IIUnknownStrategy*/ static DefaultIUnknownStrategy = null;
            static /*IIUnknownCacheStrategy */ CreateDefaultCacheStrategy()
            {
                return new $.$sris.System.Runtime.InteropServices.Marshalling.DefaultCaching().$ctor$1();
            }
            /*IIUnknownInterfaceDetailsStrategy */ GetOrCreateInterfaceDetailsStrategy()
            {
                //if (OperatingSystem.IsWindows() && RuntimeFeature.IsDynamicCodeSupported && ComObject.BuiltInComSupported && ComObject.ComImportInteropEnabled) { ... }
                return $.$sris.System.Runtime.InteropServices.Marshalling.StrategyBasedComWrappers.DefaultIUnknownInterfaceDetailsStrategy;
                /*static IIUnknownInterfaceDetailsStrategy*/  function GetInteropStrategy()
                {
                    return $.$sris.System.Runtime.InteropServices.Marshalling.ComImportInteropInterfaceDetailsStrategy.Instance;
                }
            }
            /*IIUnknownStrategy */ GetOrCreateIUnknownStrategy()
            {
                return $.$sris.System.Runtime.InteropServices.Marshalling.StrategyBasedComWrappers.DefaultIUnknownStrategy;
            }
            /*IIUnknownCacheStrategy */ CreateCacheStrategy()
            {
                return $.$sris.System.Runtime.InteropServices.Marshalling.StrategyBasedComWrappers.CreateDefaultCacheStrategy();
            }
            /*ComInterfaceEntry* */ ComputeVtables(/*object*/ obj, /*CreateComInterfaceFlags*/ flags, /*out int*/ count)
            {
                let details;
                if (this.GetOrCreateInterfaceDetailsStrategy().System$Runtime$InteropServices$Marshalling$IIUnknownInterfaceDetailsStrategy$GetComExposedTypeDetails($.$$.System.Object.GetType.call(obj).TypeHandle) !== null && ((details = this.GetOrCreateInterfaceDetailsStrategy().System$Runtime$InteropServices$Marshalling$IIUnknownInterfaceDetailsStrategy$GetComExposedTypeDetails($.$$.System.Object.GetType.call(obj).TypeHandle), details != null && true)))
                {
                    return details.System$Runtime$InteropServices$Marshalling$IComExposedDetails$GetComInterfaceEntries(count);
                }
                count.$v = 0;
                return null;
            }
            /*object */ CreateObject$1(/*nint*/ externalComObject, /*CreateObjectFlags*/ flags)
            {
                if (((flags & (1/*CreateObjectFlags.TrackerObject*/)) == (1/*CreateObjectFlags.TrackerObject*/)) || ((flags & (4/*CreateObjectFlags.Aggregation*/)) == (4/*CreateObjectFlags.Aggregation*/)))
                {
                    throw new $.$$.System.NotSupportedException().$ctor$9();
                }
                /*var*/ let rcw = (() =>
                {
                    //new $.$sris.System.Runtime.InteropServices.Marshalling.ComObject()
                    const $t1 = $.$sris.System.Runtime.InteropServices.Marshalling.ComObject;
                    const $i1 = new $t1();
                    $i1.$ctor$1(this.GetOrCreateInterfaceDetailsStrategy(), this.GetOrCreateIUnknownStrategy(), this.CreateCacheStrategy(), $.$$.System.IntPtr.op_Explicit$5(externalComObject));
                    $i1.UniqueInstance = ((flags & (2/*CreateObjectFlags.UniqueInstance*/)) == (2/*CreateObjectFlags.UniqueInstance*/));
                    return $i1;
                })();
                return rcw;
            }
            /*object? */ CreateObject(/*nint*/ externalComObject, /*CreateObjectFlags*/ flags, /*object?*/ userState, /*out CreatedWrapperFlags*/ wrapperFlags)
            {
                return super.CreateObject(externalComObject, flags, userState, wrapperFlags);
            }
            /*void */ ReleaseObjects(/*IEnumerable*/ objects)
            {
                throw new $.$$.System.NotImplementedException().$ctor$9();
            }
            //default reference type constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                return this;
            }
            //Static Initializer
            static $sinit()
            {
                {
                    this.DefaultMarshallingInstance = new $.$sris.System.Runtime.InteropServices.Marshalling.StrategyBasedComWrappers().$ctor$2();
                }
                {
                    this.DefaultIUnknownInterfaceDetailsStrategy = $.$sris.System.Runtime.InteropServices.Marshalling.DefaultIUnknownInterfaceDetailsStrategy.Instance;
                }
                {
                    this.DefaultIUnknownStrategy = $.$sris.System.Runtime.InteropServices.Marshalling.FreeThreadedStrategy.Instance;
                }
            }
            static $h = 3659325;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":102498305,"p":[{"p":3659325,"g":{"r":0,"d":0,"h":12888561213,"f":50331688},"n":"DefaultMarshallingInstance","d":3659325,"h":8593593917,"f":2097192},{"p":3331645,"g":{"r":0,"d":0,"h":25773463101,"f":50331681},"n":"DefaultIUnknownInterfaceDetailsStrategy","d":3659325,"h":21478495805,"f":2097185},{"p":3462717,"g":{"r":0,"d":0,"h":38658364989,"f":50331681},"n":"DefaultIUnknownStrategy","d":3659325,"h":34363397693,"f":2097185}],"m":[{"r":3135037,"n":"CreateDefaultCacheStrategy","d":3659325,"h":42953332285,"f":16777252},{"r":3331645,"n":"GetOrCreateInterfaceDetailsStrategy","d":3659325,"h":47248299581,"f":16777348},{"r":3462717,"n":"GetOrCreateIUnknownStrategy","d":3659325,"h":51543266877,"f":16777348},{"r":3135037,"n":"CreateCacheStrategy","d":3659325,"h":55838234173,"f":16777348},{"r":$.$typePointer($.$$.System.Runtime.InteropServices.ComWrappers.ComInterfaceEntry).$h,"p":[{"n":"obj","p":131073},{"n":"flags","p":102694913},{"n":"count","p":655361,"f":2}],"n":"ComputeVtables","d":3659325,"h":60133201469,"f":16875524},{"r":131073,"p":[{"n":"externalComObject","p":786433},{"n":"flags","p":102825985}],"n":"CreateObject","o":"@$1","d":3659325,"h":64428168765,"f":16875524},{"r":131073,"p":[{"n":"externalComObject","p":786433},{"n":"flags","p":102825985},{"n":"userState","p":131073},{"n":"wrapperFlags","p":102760449,"f":2}],"n":"CreateObject","d":3659325,"h":68723136061,"f":16875524},{"r":65537,"p":[{"n":"objects","p":31719425}],"n":"ReleaseObjects","d":3659325,"h":73018103357,"f":16875524}],"c":[{"n":".ctor","o":"$ctor$2","d":3659325,"h":77313070653,"f":16777217}],"h":3659325,"a":[{"t":115146753,"c":4410114049,"a":[{"v":"android","t":1310721}]},{"t":115146753,"c":4410114049,"a":[{"v":"browser","t":1310721}]},{"t":115146753,"c":4410114049,"a":[{"v":"ios","t":1310721}]},{"t":115146753,"c":4410114049,"a":[{"v":"tvos","t":1310721}]},{"t":23527425,"c":8613462017,"a":[{"v":false,"t":262145}]}]}; }
            static get $b() { return $.$$.System.Runtime.InteropServices.ComWrappers; }
            static get $fullName() { return `System.Runtime.InteropServices.Marshalling.StrategyBasedComWrappers`; }
        });
        
        $asm.$str("$sris.System.Runtime.InteropServices.Marshalling.VirtualMethodTableInfo", ($self) => class VirtualMethodTableInfo extends $.$$.System.ValueType
        {
            $ctor$3(/*void**/ thisPointer, /*void***/ virtualMethodTable)
            {
                super.$ctor$1();
                {
                    this.ThisPointer = thisPointer;
                    this.VirtualMethodTable = virtualMethodTable;
                }
                return this;
            }
            /*void**/ ThisPointer;
            /*void***/ VirtualMethodTable;
            /*void */ Deconstruct(/*out void**/ thisPointer, /*out void***/ virtualMethodTable)
            {
                thisPointer.$v = this.ThisPointer;
                virtualMethodTable.$v = this.VirtualMethodTable;
            }
            //default value type constructor
            $ctor$2()
            {
                return this;
            }
            Clone($copy)
            {
                let copy = $copy ?? new this.constructor();
                copy.ThisPointer = this.ThisPointer.Clone();
                copy.VirtualMethodTable = this.VirtualMethodTable.Clone();
                return copy;
            }
            //default member initializer
            constructor()
            {
                super();
                this.ThisPointer = $.$default($.$typePointer($.$$.System.Void));
                this.VirtualMethodTable = $.$default($.$typePointer($.$typePointer($.$$.System.Void)));
            }
            static $h = 3790397;
            static $z = 8;
            static $f = 0b1010000001;
            static $k = 2;
            static $$md;
            static get $md() { return this.$$md ??= {"b":196609,"p":[{"p":$.$typePointer($.$$.System.Void).$h,"g":{"r":0,"d":0,"h":17183659581,"f":50331649},"n":"ThisPointer","d":3790397,"h":12888692285,"f":2097153},{"p":$.$typePointer($.$typePointer($.$$.System.Void)).$h,"g":{"r":0,"d":0,"h":30068561469,"f":50331649},"n":"VirtualMethodTable","d":3790397,"h":25773594173,"f":2097153}],"m":[{"r":65537,"p":[{"n":"thisPointer","p":$.$typePointer($.$$.System.Void).$h,"f":2},{"n":"virtualMethodTable","p":$.$typePointer($.$typePointer($.$$.System.Void)).$h,"f":2}],"n":"Deconstruct","d":3790397,"h":34363528765,"f":16777217}],"c":[{"p":[{"n":"thisPointer","p":$.$typePointer($.$$.System.Void).$h},{"n":"virtualMethodTable","p":$.$typePointer($.$typePointer($.$$.System.Void)).$h}],"n":".ctor","o":"$ctor$3","d":3790397,"h":4298757693,"f":16777217},{"n":".ctor","o":"$ctor$2","d":3790397,"h":38658496061,"f":16777217}],"h":3790397,"a":[{"t":23527425,"c":8613462017,"a":[{"v":false,"t":262145}]}]}; }
            static get $b() { return $.$$.System.ValueType; }
            static get $fullName() { return `System.Runtime.InteropServices.Marshalling.VirtualMethodTableInfo`; }
        });
        
        $asm.$cls("$sris.System.Runtime.InteropServices.PrimaryInteropAssemblyAttribute", ($self) => class PrimaryInteropAssemblyAttribute extends $.$$.System.Attribute
        {
            $ctor$2(/*int*/ major, /*int*/ minor)
            {
                super.$ctor$1();
                {
                    this.MajorVersion = major;
                    this.MinorVersion = minor;
                }
                return this;
            }
            /*int*/ MajorVersion = 0;
            /*int*/ MinorVersion = 0;
            static $h = 3855933;
            static $f = 0b10010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":14614529,"p":[{"p":655361,"g":{"r":0,"d":0,"h":17183725117,"f":50331649},"n":"MajorVersion","d":3855933,"h":12888757821,"f":2097153},{"p":655361,"g":{"r":0,"d":0,"h":30068627005,"f":50331649},"n":"MinorVersion","d":3855933,"h":25773659709,"f":2097153}],"c":[{"p":[{"n":"major","p":655361},{"n":"minor","p":655361}],"n":".ctor","o":"$ctor$2","d":3855933,"h":4298823229,"f":16777217}],"h":3855933,"a":[{"t":14745601,"c":21489582081,"a":[{"v":1,"t":14680065}],"n":[{"n":"Inherited","v":false,"t":262145},{"n":"AllowMultiple","v":true,"t":262145}]}]}; }
            static get $b() { return $.$$.System.Attribute; }
            static get $fullName() { return `System.Runtime.InteropServices.PrimaryInteropAssemblyAttribute`; }
        });
        
        $asm.$cls("$sris.System.Runtime.InteropServices.ImportedFromTypeLibAttribute", ($self) => class ImportedFromTypeLibAttribute extends $.$$.System.Attribute
        {
            $ctor$2(/*string*/ tlbFile)
            {
                super.$ctor$1();
                this.Value = tlbFile;
                return this;
            }
            /*string*/ Value = null;
            static $h = 1693245;
            static $f = 0b10010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":14614529,"p":[{"p":1310721,"g":{"r":0,"d":0,"h":17181562429,"f":50331649},"n":"Value","d":1693245,"h":12886595133,"f":2097153}],"c":[{"p":[{"n":"tlbFile","p":1310721}],"n":".ctor","o":"$ctor$2","d":1693245,"h":4296660541,"f":16777217}],"h":1693245,"a":[{"t":14745601,"c":21489582081,"a":[{"v":1,"t":14680065}],"n":[{"n":"Inherited","v":false,"t":262145}]}]}; }
            static get $b() { return $.$$.System.Attribute; }
            static get $fullName() { return `System.Runtime.InteropServices.ImportedFromTypeLibAttribute`; }
        });
        
        $asm.$cls("$sris.System.Runtime.InteropServices.TypeLibVarAttribute", ($self) => class TypeLibVarAttribute extends $.$$.System.Attribute
        {
            $ctor$3(/*TypeLibVarFlags*/ flags)
            {
                super.$ctor$1();
                {
                    this.Value = flags;
                }
                return this;
            }
            $ctor$2(/*short*/ flags)
            {
                super.$ctor$1();
                {
                    this.Value = $.$cast(flags, $.$sris.System.Runtime.InteropServices.TypeLibVarFlags);
                }
                return this;
            }
            /*TypeLibVarFlags*/ Value = 0;
            //default member initializer
            constructor()
            {
                super();
                this.Value = 0;
            }
            static $h = 4445757;
            static $f = 0b10010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":14614529,"p":[{"p":4511293,"g":{"r":0,"d":0,"h":21479282237,"f":50331649},"n":"Value","d":4445757,"h":17184314941,"f":2097153}],"c":[{"p":[{"n":"flags","p":4511293}],"n":".ctor","o":"$ctor$3","d":4445757,"h":4299413053,"f":16777217},{"p":[{"n":"flags","p":524289}],"n":".ctor","o":"$ctor$2","d":4445757,"h":8594380349,"f":16777217}],"h":4445757,"a":[{"t":14745601,"c":21489582081,"a":[{"v":256,"t":14680065}],"n":[{"n":"Inherited","v":false,"t":262145}]}]}; }
            static get $b() { return $.$$.System.Attribute; }
            static get $fullName() { return `System.Runtime.InteropServices.TypeLibVarAttribute`; }
        });
        
        $asm.$cls("$sris.System.Runtime.InteropServices.Marshalling.ComExposedClassAttribute<>", (T) => $asm.$gt("$sris.System.Runtime.InteropServices.Marshalling.ComExposedClassAttribute<>", [T], ($self) => class ComExposedClassAttribute$$ extends $.$$.System.Attribute
        {
            /*ComWrappers.ComInterfaceEntry* */ GetComInterfaceEntries(/*out int*/ count)
            {
                return T.System$Runtime$InteropServices$Marshalling$IComExposedClass$GetComInterfaceEntries(count);
            }
            //Generated interface implemetation for System.Runtime.InteropServices.Marshalling.IComExposedDetails.GetComInterfaceEntries(out int)
            System$Runtime$InteropServices$Marshalling$IComExposedDetails$GetComInterfaceEntries()
            {
                return this.GetComInterfaceEntries(...arguments);
            }
            //default reference type constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                return this;
            }
            static $h = 1824317;
            static $g = 1;
            static $f = 0b11010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":14614529,"m":[{"r":$.$typePointer($.$$.System.Runtime.InteropServices.ComWrappers.ComInterfaceEntry).$h,"p":[{"n":"count","p":655361,"f":2}],"n":"GetComInterfaceEntries","d":this.$h,"h":Number(BigInt(this.$h)|0x100000000n),"f":16777217}],"c":[{"n":".ctor","o":"$ctor$2","d":this.$h,"h":Number(BigInt(this.$h)|0x200000000n),"f":16777217}],"i":[3069501],"g":[T?.$h??1507328],"r":1,"h":this.$h,"a":[{"t":14745601,"c":21489582081,"a":[{"v":4,"t":14680065}],"n":[{"n":"Inherited","v":false,"t":262145}]},{"t":23527425,"c":8613462017,"a":[{"v":false,"t":262145}]}]}; }
            static get $b() { return $.$$.System.Attribute; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$sris.System.Runtime.InteropServices.Marshalling.IComExposedDetails ]; }
            static get $fullName() { return `System.Runtime.InteropServices.Marshalling.ComExposedClassAttribute<${T?.$fullName}>`; }
        }));
        
        $asm.$cls("$sris.System.Runtime.InteropServices.Marshalling.IUnknownDerivedAttribute<,>", (T, TImpl) => $asm.$gt("$sris.System.Runtime.InteropServices.Marshalling.IUnknownDerivedAttribute<,>", [T, TImpl], ($self) => class IUnknownDerivedAttribute$$$ extends $.$$.System.Attribute
        {
            $ctor$2()
            {
                super.$ctor$1();
                {
                }
                return this;
            }
            /*Guid */ get Iid()
            {
                return T.System$Runtime$InteropServices$Marshalling$IIUnknownInterfaceType$Iid;
            }
            /*Type */ get Implementation()
            {
                return TImpl.$type;
            }
            /*void** */ get ManagedVirtualMethodTable()
            {
                return T.System$Runtime$InteropServices$Marshalling$IIUnknownInterfaceType$ManagedVirtualMethodTable;
            }
            //Generated interface implemetation for System.Runtime.InteropServices.Marshalling.IIUnknownDerivedDetails.Iid.get
            get System$Runtime$InteropServices$Marshalling$IIUnknownDerivedDetails$Iid()
            {
                return this.Iid;
            }
            //Generated interface implemetation for System.Runtime.InteropServices.Marshalling.IIUnknownDerivedDetails.Implementation.get
            get System$Runtime$InteropServices$Marshalling$IIUnknownDerivedDetails$Implementation()
            {
                return this.Implementation;
            }
            //Generated interface implemetation for System.Runtime.InteropServices.Marshalling.IIUnknownDerivedDetails.ManagedVirtualMethodTable.get
            get System$Runtime$InteropServices$Marshalling$IIUnknownDerivedDetails$ManagedVirtualMethodTable()
            {
                return this.ManagedVirtualMethodTable;
            }
            static $h = 3528253;
            static $g = 2;
            static $f = 0b1010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":14614529,"p":[{"p":56229889,"g":{"r":0,"d":0,"h":Number(BigInt(this.$h)|0x300000000n),"f":50331649},"n":"Iid","d":this.$h,"h":Number(BigInt(this.$h)|0x200000000n),"f":2097153},{"p":142475265,"g":{"r":0,"d":0,"h":Number(BigInt(this.$h)|0x500000000n),"f":50331649},"n":"Implementation","d":this.$h,"h":Number(BigInt(this.$h)|0x400000000n),"f":2097153},{"p":$.$typePointer($.$typePointer($.$$.System.Void)).$h,"g":{"r":0,"d":0,"h":Number(BigInt(this.$h)|0x700000000n),"f":50331649},"n":"ManagedVirtualMethodTable","d":this.$h,"h":Number(BigInt(this.$h)|0x600000000n),"f":2097153}],"c":[{"n":".ctor","o":"$ctor$2","d":this.$h,"h":Number(BigInt(this.$h)|0x100000000n),"f":16777217}],"i":[3266109],"g":[T?.$h??1507328,TImpl?.$h??1572864],"r":2,"h":this.$h,"a":[{"t":14745601,"c":21489582081,"a":[{"v":1024,"t":14680065}],"n":[{"n":"Inherited","v":false,"t":262145}]},{"t":23527425,"c":8613462017,"a":[{"v":false,"t":262145}]}]}; }
            static get $b() { return $.$$.System.Attribute; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$sris.System.Runtime.InteropServices.Marshalling.IIUnknownDerivedDetails ]; }
            static get $fullName() { return `System.Runtime.InteropServices.Marshalling.IUnknownDerivedAttribute<${T?.$fullName},${TImpl?.$fullName}>`; }
        }));
        
        $asm.$cls("$sris.System.Runtime.CompilerServices.IUnknownConstantAttribute", ($self) => class IUnknownConstantAttribute extends $.$$.System.Runtime.CompilerServices.CustomConstantAttribute
        {
            $ctor$3()
            {
                super.$ctor$2();
                {
                }
                return this;
            }
            /*object */ get Value()
            {
                return new $.$$.System.Runtime.InteropServices.UnknownWrapper().$ctor$1(null);
            }
            static $h = 251453;
            static $f = 0b10010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":89784321,"p":[{"p":131073,"g":{"r":0,"d":0,"h":12885153341,"f":50364417},"n":"Value","d":251453,"h":8590186045,"f":2129921}],"c":[{"n":".ctor","o":"$ctor$3","d":251453,"h":4295218749,"f":16777217}],"h":251453,"a":[{"t":14745601,"c":21489582081,"a":[{"v":2304,"t":14680065}],"n":[{"n":"Inherited","v":false,"t":262145}]}]}; }
            static get $b() { return $.$$.System.Runtime.CompilerServices.CustomConstantAttribute; }
            static get $fullName() { return `System.Runtime.CompilerServices.IUnknownConstantAttribute`; }
        });
        
        $asm.$cls("$sris.System.Runtime.CompilerServices.IDispatchConstantAttribute", ($self) => class IDispatchConstantAttribute extends $.$$.System.Runtime.CompilerServices.CustomConstantAttribute
        {
            $ctor$3()
            {
                super.$ctor$2();
                {
                }
                return this;
            }
            /*object */ get Value()
            {
                return new $.$$.System.Runtime.InteropServices.DispatchWrapper().$ctor$1(null);
            }
            static $h = 185917;
            static $f = 0b10010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":89784321,"p":[{"p":131073,"g":{"r":0,"d":0,"h":12885087805,"f":50364417},"n":"Value","d":185917,"h":8590120509,"f":2129921}],"c":[{"n":".ctor","o":"$ctor$3","d":185917,"h":4295153213,"f":16777217}],"h":185917,"a":[{"t":114819073,"c":4409786369,"a":[{"v":"windows","t":1310721}]},{"t":14745601,"c":21489582081,"a":[{"v":2304,"t":14680065}],"n":[{"n":"Inherited","v":false,"t":262145}]}]}; }
            static get $b() { return $.$$.System.Runtime.CompilerServices.CustomConstantAttribute; }
            static get $fullName() { return `System.Runtime.CompilerServices.IDispatchConstantAttribute`; }
        });
        
        $asm.$cls("$sris.System.Runtime.InteropServices.ComAwareEventInfo", ($self) => class ComAwareEventInfo extends $.$$.System.Reflection.EventInfo
        {
            /*EventInfo*/ _innerEventInfo = null;
            $ctor$4(/*Type*/ type, /*string*/ eventName)
            {
                super.$ctor$3();
                {
                    this._innerEventInfo = type.GetEvent$1(eventName);
                }
                return this;
            }
            /*void */ AddEventHandler(/*object*/ target, /*Delegate*/ handler)
            {
                if ($.$$.System.Runtime.InteropServices.Marshal.IsComObject(target))
                {
                    /*Guid*/ let sourceIid;
                    /*int*/ let dispid;
                    $.$sris.System.Runtime.InteropServices.ComAwareEventInfo.GetDataForComInvocation(this._innerEventInfo, $.$ref(() => sourceIid, ($v) => sourceIid = $v, $.$$.System.Guid), $.$ref(() => dispid, ($v) => dispid = $v, $.$$.System.Int32));
                    $.$$.System.Runtime.InteropServices.ComEventsHelper.Combine(target, sourceIid, dispid, handler);
                }
                else 
                {
                    this._innerEventInfo.AddEventHandler(target, handler);
                }
            }
            /*void */ RemoveEventHandler(/*object*/ target, /*Delegate*/ handler)
            {
                if ($.$$.System.Runtime.InteropServices.Marshal.IsComObject(target))
                {
                    /*Guid*/ let sourceIid;
                    /*int*/ let dispid;
                    $.$sris.System.Runtime.InteropServices.ComAwareEventInfo.GetDataForComInvocation(this._innerEventInfo, $.$ref(() => sourceIid, ($v) => sourceIid = $v, $.$$.System.Guid), $.$ref(() => dispid, ($v) => dispid = $v, $.$$.System.Int32));
                    $.$$.System.Runtime.InteropServices.ComEventsHelper.Remove(target, sourceIid, dispid, handler);
                }
                else 
                {
                    this._innerEventInfo.RemoveEventHandler(target, handler);
                }
            }
            /*EventAttributes */ get Attributes()
            {
                return this._innerEventInfo.Attributes;
            }
            /*MethodInfo? */ GetAddMethod$1(/*bool*/ nonPublic)
            {
                return this._innerEventInfo.GetAddMethod$1(nonPublic);
            }
            /*MethodInfo[] */ GetOtherMethods$1(/*bool*/ nonPublic)
            {
                return this._innerEventInfo.GetOtherMethods$1(nonPublic);
            }
            /*MethodInfo? */ GetRaiseMethod$1(/*bool*/ nonPublic)
            {
                return this._innerEventInfo.GetRaiseMethod$1(nonPublic);
            }
            /*MethodInfo? */ GetRemoveMethod$1(/*bool*/ nonPublic)
            {
                return this._innerEventInfo.GetRemoveMethod$1(nonPublic);
            }
            /*Type? */ get DeclaringType()
            {
                return this._innerEventInfo.DeclaringType;
            }
            /*object[] */ GetCustomAttributes$1(/*Type*/ attributeType, /*bool*/ inherit)
            {
                return this._innerEventInfo.GetCustomAttributes$1(attributeType, inherit);
            }
            /*object[] */ GetCustomAttributes(/*bool*/ inherit)
            {
                return this._innerEventInfo.GetCustomAttributes(inherit);
            }
            /*IList<CustomAttributeData> */ GetCustomAttributesData()
            {
                return this._innerEventInfo.GetCustomAttributesData();
            }
            /*bool */ IsDefined(/*Type*/ attributeType, /*bool*/ inherit)
            {
                return this._innerEventInfo.IsDefined(attributeType, inherit);
            }
            /*int */ get MetadataToken()
            {
                return this._innerEventInfo.MetadataToken;
            }
            /*Module */ get Module()
            {
                return this._innerEventInfo.Module;
            }
            /*string */ get Name()
            {
                return this._innerEventInfo.Name;
            }
            /*Type? */ get ReflectedType()
            {
                return this._innerEventInfo.ReflectedType;
            }
            static /*void */ GetDataForComInvocation(/*EventInfo*/ eventInfo, /*out Guid*/ sourceIid, /*out int*/ dispid)
            {
                /*object[]*/ let comEventInterfaces = eventInfo.DeclaringType.GetCustomAttributes$1($.$$.System.Runtime.InteropServices.ComEventInterfaceAttribute.$type, false);
                if (comEventInterfaces === null || comEventInterfaces.length === 0)
                {
                    throw new $.$$.System.InvalidOperationException().$ctor$12($.$sris.System.SR.InvalidOperation_NoComEventInterfaceAttribute);
                }
                /*ComEventInterfaceAttribute*/ let interfaceAttribute = $.$cast($.$$.System.Array.$ReadT1.call(comEventInterfaces, 0), $.$$.System.Runtime.InteropServices.ComEventInterfaceAttribute);
                if (comEventInterfaces.length > 1)
                {
                    throw new $.$$.System.Reflection.AmbiguousMatchException().$ctor$12($.$sris.System.SR.Format$6($.$sris.System.SR.AmbiguousMatch_MultipleEventInterfaceAttributes, interfaceAttribute));
                }
                /*Type*/ let sourceInterface = interfaceAttribute.SourceInterface;
                /*Guid*/ let guid = sourceInterface.GUID;
                /*MethodInfo*/ let methodInfo = sourceInterface.GetMethod$12(eventInfo.Name);
                /*Attribute?*/ let dispIdAttribute = $.$$.System.Attribute.GetCustomAttribute$3(methodInfo, $.$$.System.Runtime.InteropServices.DispIdAttribute.$type);
                if (dispIdAttribute === null)
                {
                    throw new $.$$.System.InvalidOperationException().$ctor$12($.$sris.System.SR.InvalidOperation_NoDispIdAttribute);
                }
                sourceIid.$v = guid;
                dispid.$v = ($.$cast(dispIdAttribute, $.$$.System.Runtime.InteropServices.DispIdAttribute)).Value;
            }
            static $h = 513597;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":76414977,"p":[{"p":76349441,"g":{"r":0,"d":0,"h":25770317373,"f":50364417},"n":"Attributes","d":513597,"h":21475350077,"f":2129921},{"p":142475265,"g":{"r":0,"d":0,"h":51540121149,"f":50364417},"n":"DeclaringType","d":513597,"h":47245153853,"f":2129921},{"p":655361,"g":{"r":0,"d":0,"h":77309924925,"f":50364417},"n":"MetadataToken","d":513597,"h":73014957629,"f":2129921},{"p":80216065,"g":{"r":0,"d":0,"h":85899859517,"f":50364417},"n":"Module","d":513597,"h":81604892221,"f":2129921},{"p":1310721,"g":{"r":0,"d":0,"h":94489794109,"f":50364417},"n":"Name","d":513597,"h":90194826813,"f":2129921},{"p":142475265,"g":{"r":0,"d":0,"h":103079728701,"f":50364417},"n":"ReflectedType","d":513597,"h":98784761405,"f":2129921}],"m":[{"r":65537,"p":[{"n":"target","p":131073},{"n":"handler","p":35782657}],"n":"AddEventHandler","d":513597,"h":12885415485,"f":16809985,"a":[{"t":114819073,"c":4409786369,"a":[{"v":"windows","t":1310721}]}]},{"r":65537,"p":[{"n":"target","p":131073},{"n":"handler","p":35782657}],"n":"RemoveEventHandler","d":513597,"h":17180382781,"f":16809985,"a":[{"t":114819073,"c":4409786369,"a":[{"v":"windows","t":1310721}]}]},{"r":79626241,"p":[{"n":"nonPublic","p":262145}],"n":"GetAddMethod","o":"@$1","d":513597,"h":30065284669,"f":16809985},{"r":$.$typeArray($.$$.System.Reflection.MethodInfo).$h,"p":[{"n":"nonPublic","p":262145}],"n":"GetOtherMethods","o":"@$1","d":513597,"h":34360251965,"f":16809985},{"r":79626241,"p":[{"n":"nonPublic","p":262145}],"n":"GetRaiseMethod","o":"@$1","d":513597,"h":38655219261,"f":16809985},{"r":79626241,"p":[{"n":"nonPublic","p":262145}],"n":"GetRemoveMethod","o":"@$1","d":513597,"h":42950186557,"f":16809985},{"r":$.$typeArray($.$$.System.Object).$h,"p":[{"n":"attributeType","p":142475265},{"n":"inherit","p":262145}],"n":"GetCustomAttributes","o":"@$1","d":513597,"h":55835088445,"f":16809985},{"r":$.$typeArray($.$$.System.Object).$h,"p":[{"n":"inherit","p":262145}],"n":"GetCustomAttributes","d":513597,"h":60130055741,"f":16809985},{"r":$.$$.System.Collections.Generic.IList$$($.$$.System.Reflection.CustomAttributeData).$h,"n":"GetCustomAttributesData","d":513597,"h":64425023037,"f":16809985},{"r":262145,"p":[{"n":"attributeType","p":142475265},{"n":"inherit","p":262145}],"n":"IsDefined","d":513597,"h":68719990333,"f":16809985},{"r":65537,"p":[{"n":"eventInfo","p":76414977},{"n":"sourceIid","p":56229889,"f":2},{"n":"dispid","p":655361,"f":2}],"n":"GetDataForComInvocation","d":513597,"h":107374695997,"f":16777250}],"l":[{"t":76414977,"n":"_innerEventInfo","d":513597,"h":4295480893,"f":4194306}],"c":[{"p":[{"n":"type","p":142475265},{"n":"eventName","p":1310721}],"n":".ctor","o":"$ctor$4","d":513597,"h":8590448189,"f":16777217}],"i":[76939265],"h":513597,"a":[{"t":33292289,"c":4328259585,"a":[{"v":1,"t":33357825}]}]}; }
            static get $b() { return $.$$.System.Reflection.EventInfo; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.System.Reflection.ICustomAttributeProvider ]; }
            static get $fullName() { return `System.Runtime.InteropServices.ComAwareEventInfo`; }
        });
        
        $asm.$str("$sris.System.Runtime.InteropServices.ComTypes.DVASPECT", ($self) => class DVASPECT extends $.$$.System.Enum
        {
            static DVASPECT_CONTENT = 1;
            static DVASPECT_THUMBNAIL = 2;
            static DVASPECT_ICON = 4;
            static DVASPECT_DOCPRINT = 8;
            static $map;
            static get Map()
            {
                return this.$map ??= 
                {
                    "DVASPECT_CONTENT": 1n,
                    "DVASPECT_THUMBNAIL": 2n,
                    "DVASPECT_ICON": 4n,
                    "DVASPECT_DOCPRINT": 8n
                };
            }
            static $h = 906813;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static get $eut() { return $.$$.System.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {"b":1048577,"u":655361,"l":[{"t":906813,"n":"DVASPECT_CONTENT","d":906813,"h":4295874109,"f":4194337},{"t":906813,"n":"DVASPECT_THUMBNAIL","d":906813,"h":8590841405,"f":4194337},{"t":906813,"n":"DVASPECT_ICON","d":906813,"h":12885808701,"f":4194337},{"t":906813,"n":"DVASPECT_DOCPRINT","d":906813,"h":17180775997,"f":4194337}],"c":[{"n":".ctor","o":"$ctor$3","d":906813,"h":21475743293,"f":16777217}],"i":[57278465,63832065,57737217,57409537],"h":906813,"a":[{"t":33292289,"c":4328259585,"a":[{"v":1,"t":33357825}]},{"t":47710209,"c":4342677505}]}; }
            static get $b() { return $.$$.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.System.IComparable, $.$$.System.ISpanFormattable, $.$$.System.IFormattable, $.$$.System.IConvertible ]; }
            static get $fullName() { return `System.Runtime.InteropServices.ComTypes.DVASPECT`; }
        });
        
        $asm.$str("$sris.System.Runtime.InteropServices.ComTypes.DATADIR", ($self) => class DATADIR extends $.$$.System.Enum
        {
            static DATADIR_GET = 1;
            static DATADIR_SET = 2;
            static $map;
            static get Map()
            {
                return this.$map ??= 
                {
                    "DATADIR_GET": 1n,
                    "DATADIR_SET": 2n
                };
            }
            static $h = 841277;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static get $eut() { return $.$$.System.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {"b":1048577,"u":655361,"l":[{"t":841277,"n":"DATADIR_GET","d":841277,"h":4295808573,"f":4194337},{"t":841277,"n":"DATADIR_SET","d":841277,"h":8590775869,"f":4194337}],"c":[{"n":".ctor","o":"$ctor$3","d":841277,"h":12885743165,"f":16777217}],"i":[57278465,63832065,57737217,57409537],"h":841277,"a":[{"t":33292289,"c":4328259585,"a":[{"v":1,"t":33357825}]}]}; }
            static get $b() { return $.$$.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.System.IComparable, $.$$.System.ISpanFormattable, $.$$.System.IFormattable, $.$$.System.IConvertible ]; }
            static get $fullName() { return `System.Runtime.InteropServices.ComTypes.DATADIR`; }
        });
        
        $asm.$str("$sris.System.Runtime.InteropServices.AssemblyRegistrationFlags", ($self) => class AssemblyRegistrationFlags extends $.$$.System.Enum
        {
            static None = 0;
            static SetCodeBase = 1;
            static $map;
            static get Map()
            {
                return this.$map ??= 
                {
                    "None": 0n,
                    "SetCodeBase": 1n
                };
            }
            static $h = 316989;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static get $eut() { return $.$$.System.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {"b":1048577,"u":655361,"l":[{"t":316989,"n":"None","d":316989,"h":4295284285,"f":4194337},{"t":316989,"n":"SetCodeBase","d":316989,"h":8590251581,"f":4194337}],"c":[{"n":".ctor","o":"$ctor$3","d":316989,"h":12885218877,"f":16777217}],"i":[57278465,63832065,57737217,57409537],"h":316989,"a":[{"t":47710209,"c":4342677505}]}; }
            static get $b() { return $.$$.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.System.IComparable, $.$$.System.ISpanFormattable, $.$$.System.IFormattable, $.$$.System.IConvertible ]; }
            static get $fullName() { return `System.Runtime.InteropServices.AssemblyRegistrationFlags`; }
        });
        
        $asm.$str("$sris.System.Runtime.InteropServices.ComTypes.TYMED", ($self) => class TYMED extends $.$$.System.Enum
        {
            static TYMED_HGLOBAL = 1;
            static TYMED_FILE = 2;
            static TYMED_ISTREAM = 4;
            static TYMED_ISTORAGE = 8;
            static TYMED_GDI = 16;
            static TYMED_MFPICT = 32;
            static TYMED_ENHMF = 64;
            static TYMED_NULL = 0;
            static $map;
            static get Map()
            {
                return this.$map ??= 
                {
                    "TYMED_HGLOBAL": 1n,
                    "TYMED_FILE": 2n,
                    "TYMED_ISTREAM": 4n,
                    "TYMED_ISTORAGE": 8n,
                    "TYMED_GDI": 16n,
                    "TYMED_MFPICT": 32n,
                    "TYMED_ENHMF": 64n,
                    "TYMED_NULL": 0n
                };
            }
            static $h = 1431101;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static get $eut() { return $.$$.System.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {"b":1048577,"u":655361,"l":[{"t":1431101,"n":"TYMED_HGLOBAL","d":1431101,"h":4296398397,"f":4194337},{"t":1431101,"n":"TYMED_FILE","d":1431101,"h":8591365693,"f":4194337},{"t":1431101,"n":"TYMED_ISTREAM","d":1431101,"h":12886332989,"f":4194337},{"t":1431101,"n":"TYMED_ISTORAGE","d":1431101,"h":17181300285,"f":4194337},{"t":1431101,"n":"TYMED_GDI","d":1431101,"h":21476267581,"f":4194337},{"t":1431101,"n":"TYMED_MFPICT","d":1431101,"h":25771234877,"f":4194337},{"t":1431101,"n":"TYMED_ENHMF","d":1431101,"h":30066202173,"f":4194337},{"t":1431101,"n":"TYMED_NULL","d":1431101,"h":34361169469,"f":4194337}],"c":[{"n":".ctor","o":"$ctor$3","d":1431101,"h":38656136765,"f":16777217}],"i":[57278465,63832065,57737217,57409537],"h":1431101,"a":[{"t":33292289,"c":4328259585,"a":[{"v":1,"t":33357825}]},{"t":47710209,"c":4342677505}]}; }
            static get $b() { return $.$$.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.System.IComparable, $.$$.System.ISpanFormattable, $.$$.System.IFormattable, $.$$.System.IConvertible ]; }
            static get $fullName() { return `System.Runtime.InteropServices.ComTypes.TYMED`; }
        });
        
        $asm.$str("$sris.System.Runtime.InteropServices.ComTypes.ADVF", ($self) => class ADVF extends $.$$.System.Enum
        {
            static ADVF_NODATA = 1;
            static ADVF_PRIMEFIRST = 2;
            static ADVF_ONLYONCE = 4;
            static ADVF_DATAONSTOP = 64;
            static ADVFCACHE_NOHANDLER = 8;
            static ADVFCACHE_FORCEBUILTIN = 16;
            static ADVFCACHE_ONSAVE = 32;
            static $map;
            static get Map()
            {
                return this.$map ??= 
                {
                    "ADVF_NODATA": 1n,
                    "ADVF_PRIMEFIRST": 2n,
                    "ADVF_ONLYONCE": 4n,
                    "ADVF_DATAONSTOP": 64n,
                    "ADVFCACHE_NOHANDLER": 8n,
                    "ADVFCACHE_FORCEBUILTIN": 16n,
                    "ADVFCACHE_ONSAVE": 32n
                };
            }
            static $h = 775741;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static get $eut() { return $.$$.System.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {"b":1048577,"u":655361,"l":[{"t":775741,"n":"ADVF_NODATA","d":775741,"h":4295743037,"f":4194337},{"t":775741,"n":"ADVF_PRIMEFIRST","d":775741,"h":8590710333,"f":4194337},{"t":775741,"n":"ADVF_ONLYONCE","d":775741,"h":12885677629,"f":4194337},{"t":775741,"n":"ADVF_DATAONSTOP","d":775741,"h":17180644925,"f":4194337},{"t":775741,"n":"ADVFCACHE_NOHANDLER","d":775741,"h":21475612221,"f":4194337},{"t":775741,"n":"ADVFCACHE_FORCEBUILTIN","d":775741,"h":25770579517,"f":4194337},{"t":775741,"n":"ADVFCACHE_ONSAVE","d":775741,"h":30065546813,"f":4194337}],"c":[{"n":".ctor","o":"$ctor$3","d":775741,"h":34360514109,"f":16777217}],"i":[57278465,63832065,57737217,57409537],"h":775741,"a":[{"t":33292289,"c":4328259585,"a":[{"v":1,"t":33357825}]},{"t":47710209,"c":4342677505}]}; }
            static get $b() { return $.$$.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.System.IComparable, $.$$.System.ISpanFormattable, $.$$.System.IFormattable, $.$$.System.IConvertible ]; }
            static get $fullName() { return `System.Runtime.InteropServices.ComTypes.ADVF`; }
        });
        
        $asm.$str("$sris.System.Runtime.InteropServices.ExporterEventKind", ($self) => class ExporterEventKind extends $.$$.System.Enum
        {
            static NOTIF_TYPECONVERTED = 0;
            static NOTIF_CONVERTWARNING = 1;
            static ERROR_REFTOINVALIDASSEMBLY = 2;
            static $map;
            static get Map()
            {
                return this.$map ??= 
                {
                    "NOTIF_TYPECONVERTED": 0n,
                    "NOTIF_CONVERTWARNING": 1n,
                    "ERROR_REFTOINVALIDASSEMBLY": 2n
                };
            }
            static $h = 1562173;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static get $eut() { return $.$$.System.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {"b":1048577,"u":655361,"l":[{"t":1562173,"n":"NOTIF_TYPECONVERTED","d":1562173,"h":4296529469,"f":4194337},{"t":1562173,"n":"NOTIF_CONVERTWARNING","d":1562173,"h":8591496765,"f":4194337},{"t":1562173,"n":"ERROR_REFTOINVALIDASSEMBLY","d":1562173,"h":12886464061,"f":4194337}],"c":[{"n":".ctor","o":"$ctor$3","d":1562173,"h":17181431357,"f":16777217}],"i":[57278465,63832065,57737217,57409537],"h":1562173}; }
            static get $b() { return $.$$.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.System.IComparable, $.$$.System.ISpanFormattable, $.$$.System.IFormattable, $.$$.System.IConvertible ]; }
            static get $fullName() { return `System.Runtime.InteropServices.ExporterEventKind`; }
        });
        
        $asm.$str("$sris.System.Runtime.InteropServices.Marshalling.ComInterfaceOptions", ($self) => class ComInterfaceOptions extends $.$$.System.Enum
        {
            static None = 0;
            static ManagedObjectWrapper = 1;
            static ComObjectWrapper = 2;
            static $map;
            static get Map()
            {
                return this.$map ??= 
                {
                    "None": 0n,
                    "ManagedObjectWrapper": 1n,
                    "ComObjectWrapper": 2n
                };
            }
            static $h = 2151997;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static get $eut() { return $.$$.System.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {"b":1048577,"u":655361,"l":[{"t":2151997,"n":"None","d":2151997,"h":4297119293,"f":4194337,"a":[{"t":33292289,"c":4328259585,"a":[{"v":1,"t":33357825}]}]},{"t":2151997,"n":"ManagedObjectWrapper","d":2151997,"h":8592086589,"f":4194337},{"t":2151997,"n":"ComObjectWrapper","d":2151997,"h":12887053885,"f":4194337}],"c":[{"n":".ctor","o":"$ctor$3","d":2151997,"h":17182021181,"f":16777217}],"i":[57278465,63832065,57737217,57409537],"h":2151997,"a":[{"t":47710209,"c":4342677505}]}; }
            static get $b() { return $.$$.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.System.IComparable, $.$$.System.ISpanFormattable, $.$$.System.IFormattable, $.$$.System.IConvertible ]; }
            static get $fullName() { return `System.Runtime.InteropServices.Marshalling.ComInterfaceOptions`; }
        });
        
        $asm.$str("$sris.System.Runtime.InteropServices.TypeLibFuncFlags", ($self) => class TypeLibFuncFlags extends $.$$.System.Enum
        {
            static FRestricted = 1;
            static FSource = 2;
            static FBindable = 4;
            static FRequestEdit = 8;
            static FDisplayBind = 16;
            static FDefaultBind = 32;
            static FHidden = 64;
            static FUsesGetLastError = 128;
            static FDefaultCollelem = 256;
            static FUiDefault = 512;
            static FNonBrowsable = 1024;
            static FReplaceable = 2048;
            static FImmediateBind = 4096;
            static $map;
            static get Map()
            {
                return this.$map ??= 
                {
                    "FRestricted": 1n,
                    "FSource": 2n,
                    "FBindable": 4n,
                    "FRequestEdit": 8n,
                    "FDisplayBind": 16n,
                    "FDefaultBind": 32n,
                    "FHidden": 64n,
                    "FUsesGetLastError": 128n,
                    "FDefaultCollelem": 256n,
                    "FUiDefault": 512n,
                    "FNonBrowsable": 1024n,
                    "FReplaceable": 2048n,
                    "FImmediateBind": 4096n
                };
            }
            static $h = 4183613;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static get $eut() { return $.$$.System.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {"b":1048577,"u":655361,"l":[{"t":4183613,"n":"FRestricted","d":4183613,"h":4299150909,"f":4194337},{"t":4183613,"n":"FSource","d":4183613,"h":8594118205,"f":4194337},{"t":4183613,"n":"FBindable","d":4183613,"h":12889085501,"f":4194337},{"t":4183613,"n":"FRequestEdit","d":4183613,"h":17184052797,"f":4194337},{"t":4183613,"n":"FDisplayBind","d":4183613,"h":21479020093,"f":4194337},{"t":4183613,"n":"FDefaultBind","d":4183613,"h":25773987389,"f":4194337},{"t":4183613,"n":"FHidden","d":4183613,"h":30068954685,"f":4194337},{"t":4183613,"n":"FUsesGetLastError","d":4183613,"h":34363921981,"f":4194337},{"t":4183613,"n":"FDefaultCollelem","d":4183613,"h":38658889277,"f":4194337},{"t":4183613,"n":"FUiDefault","d":4183613,"h":42953856573,"f":4194337},{"t":4183613,"n":"FNonBrowsable","d":4183613,"h":47248823869,"f":4194337},{"t":4183613,"n":"FReplaceable","d":4183613,"h":51543791165,"f":4194337},{"t":4183613,"n":"FImmediateBind","d":4183613,"h":55838758461,"f":4194337}],"c":[{"n":".ctor","o":"$ctor$3","d":4183613,"h":60133725757,"f":16777217}],"i":[57278465,63832065,57737217,57409537],"h":4183613,"a":[{"t":47710209,"c":4342677505}]}; }
            static get $b() { return $.$$.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.System.IComparable, $.$$.System.ISpanFormattable, $.$$.System.IFormattable, $.$$.System.IConvertible ]; }
            static get $fullName() { return `System.Runtime.InteropServices.TypeLibFuncFlags`; }
        });
        
        $asm.$str("$sris.System.Runtime.InteropServices.TypeLibTypeFlags", ($self) => class TypeLibTypeFlags extends $.$$.System.Enum
        {
            static FAppObject = 1;
            static FCanCreate = 2;
            static FLicensed = 4;
            static FPreDeclId = 8;
            static FHidden = 16;
            static FControl = 32;
            static FDual = 64;
            static FNonExtensible = 128;
            static FOleAutomation = 256;
            static FRestricted = 512;
            static FAggregatable = 1024;
            static FReplaceable = 2048;
            static FDispatchable = 4096;
            static FReverseBind = 8192;
            static $map;
            static get Map()
            {
                return this.$map ??= 
                {
                    "FAppObject": 1n,
                    "FCanCreate": 2n,
                    "FLicensed": 4n,
                    "FPreDeclId": 8n,
                    "FHidden": 16n,
                    "FControl": 32n,
                    "FDual": 64n,
                    "FNonExtensible": 128n,
                    "FOleAutomation": 256n,
                    "FRestricted": 512n,
                    "FAggregatable": 1024n,
                    "FReplaceable": 2048n,
                    "FDispatchable": 4096n,
                    "FReverseBind": 8192n
                };
            }
            static $h = 4380221;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static get $eut() { return $.$$.System.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {"b":1048577,"u":655361,"l":[{"t":4380221,"n":"FAppObject","d":4380221,"h":4299347517,"f":4194337},{"t":4380221,"n":"FCanCreate","d":4380221,"h":8594314813,"f":4194337},{"t":4380221,"n":"FLicensed","d":4380221,"h":12889282109,"f":4194337},{"t":4380221,"n":"FPreDeclId","d":4380221,"h":17184249405,"f":4194337},{"t":4380221,"n":"FHidden","d":4380221,"h":21479216701,"f":4194337},{"t":4380221,"n":"FControl","d":4380221,"h":25774183997,"f":4194337},{"t":4380221,"n":"FDual","d":4380221,"h":30069151293,"f":4194337},{"t":4380221,"n":"FNonExtensible","d":4380221,"h":34364118589,"f":4194337},{"t":4380221,"n":"FOleAutomation","d":4380221,"h":38659085885,"f":4194337},{"t":4380221,"n":"FRestricted","d":4380221,"h":42954053181,"f":4194337},{"t":4380221,"n":"FAggregatable","d":4380221,"h":47249020477,"f":4194337},{"t":4380221,"n":"FReplaceable","d":4380221,"h":51543987773,"f":4194337},{"t":4380221,"n":"FDispatchable","d":4380221,"h":55838955069,"f":4194337},{"t":4380221,"n":"FReverseBind","d":4380221,"h":60133922365,"f":4194337}],"c":[{"n":".ctor","o":"$ctor$3","d":4380221,"h":64428889661,"f":16777217}],"i":[57278465,63832065,57737217,57409537],"h":4380221,"a":[{"t":47710209,"c":4342677505}]}; }
            static get $b() { return $.$$.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.System.IComparable, $.$$.System.ISpanFormattable, $.$$.System.IFormattable, $.$$.System.IConvertible ]; }
            static get $fullName() { return `System.Runtime.InteropServices.TypeLibTypeFlags`; }
        });
        
        $asm.$str("$sris.System.Runtime.InteropServices.RegistrationConnectionType", ($self) => class RegistrationConnectionType extends $.$$.System.Enum
        {
            static SingleUse = 0;
            static MultipleUse = 1;
            static MultiSeparate = 2;
            static Suspended = 4;
            static Surrogate = 8;
            static $map;
            static get Map()
            {
                return this.$map ??= 
                {
                    "SingleUse": 0n,
                    "MultipleUse": 1n,
                    "MultiSeparate": 2n,
                    "Suspended": 4n,
                    "Surrogate": 8n
                };
            }
            static $h = 3987005;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static get $eut() { return $.$$.System.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {"b":1048577,"u":655361,"l":[{"t":3987005,"n":"SingleUse","d":3987005,"h":4298954301,"f":4194337},{"t":3987005,"n":"MultipleUse","d":3987005,"h":8593921597,"f":4194337},{"t":3987005,"n":"MultiSeparate","d":3987005,"h":12888888893,"f":4194337},{"t":3987005,"n":"Suspended","d":3987005,"h":17183856189,"f":4194337},{"t":3987005,"n":"Surrogate","d":3987005,"h":21478823485,"f":4194337}],"c":[{"n":".ctor","o":"$ctor$3","d":3987005,"h":25773790781,"f":16777217}],"i":[57278465,63832065,57737217,57409537],"h":3987005,"a":[{"t":47710209,"c":4342677505}]}; }
            static get $b() { return $.$$.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.System.IComparable, $.$$.System.ISpanFormattable, $.$$.System.IFormattable, $.$$.System.IConvertible ]; }
            static get $fullName() { return `System.Runtime.InteropServices.RegistrationConnectionType`; }
        });
        
        $asm.$str("$sris.System.Runtime.InteropServices.RegistrationClassContext", ($self) => class RegistrationClassContext extends $.$$.System.Enum
        {
            static InProcessServer = 1;
            static InProcessHandler = 2;
            static LocalServer = 4;
            static InProcessServer16 = 8;
            static RemoteServer = 16;
            static InProcessHandler16 = 32;
            static Reserved1 = 64;
            static Reserved2 = 128;
            static Reserved3 = 256;
            static Reserved4 = 512;
            static NoCodeDownload = 1024;
            static Reserved5 = 2048;
            static NoCustomMarshal = 4096;
            static EnableCodeDownload = 8192;
            static NoFailureLog = 16384;
            static DisableActivateAsActivator = 32768;
            static EnableActivateAsActivator = 65536;
            static FromDefaultContext = 131072;
            static $map;
            static get Map()
            {
                return this.$map ??= 
                {
                    "InProcessServer": 1n,
                    "InProcessHandler": 2n,
                    "LocalServer": 4n,
                    "InProcessServer16": 8n,
                    "RemoteServer": 16n,
                    "InProcessHandler16": 32n,
                    "Reserved1": 64n,
                    "Reserved2": 128n,
                    "Reserved3": 256n,
                    "Reserved4": 512n,
                    "NoCodeDownload": 1024n,
                    "Reserved5": 2048n,
                    "NoCustomMarshal": 4096n,
                    "EnableCodeDownload": 8192n,
                    "NoFailureLog": 16384n,
                    "DisableActivateAsActivator": 32768n,
                    "EnableActivateAsActivator": 65536n,
                    "FromDefaultContext": 131072n
                };
            }
            static $h = 3921469;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static get $eut() { return $.$$.System.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {"b":1048577,"u":655361,"l":[{"t":3921469,"n":"InProcessServer","d":3921469,"h":4298888765,"f":4194337},{"t":3921469,"n":"InProcessHandler","d":3921469,"h":8593856061,"f":4194337},{"t":3921469,"n":"LocalServer","d":3921469,"h":12888823357,"f":4194337},{"t":3921469,"n":"InProcessServer16","d":3921469,"h":17183790653,"f":4194337},{"t":3921469,"n":"RemoteServer","d":3921469,"h":21478757949,"f":4194337},{"t":3921469,"n":"InProcessHandler16","d":3921469,"h":25773725245,"f":4194337},{"t":3921469,"n":"Reserved1","d":3921469,"h":30068692541,"f":4194337},{"t":3921469,"n":"Reserved2","d":3921469,"h":34363659837,"f":4194337},{"t":3921469,"n":"Reserved3","d":3921469,"h":38658627133,"f":4194337},{"t":3921469,"n":"Reserved4","d":3921469,"h":42953594429,"f":4194337},{"t":3921469,"n":"NoCodeDownload","d":3921469,"h":47248561725,"f":4194337},{"t":3921469,"n":"Reserved5","d":3921469,"h":51543529021,"f":4194337},{"t":3921469,"n":"NoCustomMarshal","d":3921469,"h":55838496317,"f":4194337},{"t":3921469,"n":"EnableCodeDownload","d":3921469,"h":60133463613,"f":4194337},{"t":3921469,"n":"NoFailureLog","d":3921469,"h":64428430909,"f":4194337},{"t":3921469,"n":"DisableActivateAsActivator","d":3921469,"h":68723398205,"f":4194337},{"t":3921469,"n":"EnableActivateAsActivator","d":3921469,"h":73018365501,"f":4194337},{"t":3921469,"n":"FromDefaultContext","d":3921469,"h":77313332797,"f":4194337}],"c":[{"n":".ctor","o":"$ctor$3","d":3921469,"h":81608300093,"f":16777217}],"i":[57278465,63832065,57737217,57409537],"h":3921469,"a":[{"t":47710209,"c":4342677505}]}; }
            static get $b() { return $.$$.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.System.IComparable, $.$$.System.ISpanFormattable, $.$$.System.IFormattable, $.$$.System.IConvertible ]; }
            static get $fullName() { return `System.Runtime.InteropServices.RegistrationClassContext`; }
        });
        
        $asm.$str("$sris.System.Runtime.InteropServices.TypeLibVarFlags", ($self) => class TypeLibVarFlags extends $.$$.System.Enum
        {
            static FReadOnly = 1;
            static FSource = 2;
            static FBindable = 4;
            static FRequestEdit = 8;
            static FDisplayBind = 16;
            static FDefaultBind = 32;
            static FHidden = 64;
            static FRestricted = 128;
            static FDefaultCollelem = 256;
            static FUiDefault = 512;
            static FNonBrowsable = 1024;
            static FReplaceable = 2048;
            static FImmediateBind = 4096;
            static $map;
            static get Map()
            {
                return this.$map ??= 
                {
                    "FReadOnly": 1n,
                    "FSource": 2n,
                    "FBindable": 4n,
                    "FRequestEdit": 8n,
                    "FDisplayBind": 16n,
                    "FDefaultBind": 32n,
                    "FHidden": 64n,
                    "FRestricted": 128n,
                    "FDefaultCollelem": 256n,
                    "FUiDefault": 512n,
                    "FNonBrowsable": 1024n,
                    "FReplaceable": 2048n,
                    "FImmediateBind": 4096n
                };
            }
            static $h = 4511293;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static get $eut() { return $.$$.System.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {"b":1048577,"u":655361,"l":[{"t":4511293,"n":"FReadOnly","d":4511293,"h":4299478589,"f":4194337},{"t":4511293,"n":"FSource","d":4511293,"h":8594445885,"f":4194337},{"t":4511293,"n":"FBindable","d":4511293,"h":12889413181,"f":4194337},{"t":4511293,"n":"FRequestEdit","d":4511293,"h":17184380477,"f":4194337},{"t":4511293,"n":"FDisplayBind","d":4511293,"h":21479347773,"f":4194337},{"t":4511293,"n":"FDefaultBind","d":4511293,"h":25774315069,"f":4194337},{"t":4511293,"n":"FHidden","d":4511293,"h":30069282365,"f":4194337},{"t":4511293,"n":"FRestricted","d":4511293,"h":34364249661,"f":4194337},{"t":4511293,"n":"FDefaultCollelem","d":4511293,"h":38659216957,"f":4194337},{"t":4511293,"n":"FUiDefault","d":4511293,"h":42954184253,"f":4194337},{"t":4511293,"n":"FNonBrowsable","d":4511293,"h":47249151549,"f":4194337},{"t":4511293,"n":"FReplaceable","d":4511293,"h":51544118845,"f":4194337},{"t":4511293,"n":"FImmediateBind","d":4511293,"h":55839086141,"f":4194337}],"c":[{"n":".ctor","o":"$ctor$3","d":4511293,"h":60134053437,"f":16777217}],"i":[57278465,63832065,57737217,57409537],"h":4511293,"a":[{"t":47710209,"c":4342677505}]}; }
            static get $b() { return $.$$.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.System.IComparable, $.$$.System.ISpanFormattable, $.$$.System.IFormattable, $.$$.System.IConvertible ]; }
            static get $fullName() { return `System.Runtime.InteropServices.TypeLibVarFlags`; }
        });
        
        $asm.$cls("$sris.System.Runtime.InteropServices.Marshalling.ComObject", ($self) => class ComObject extends $.$$.System.Object
        {
            /*bool*/ static BuiltInComSupported = false;
            /*bool*/ static ComImportInteropEnabled = false;
            /*void**/ _instancePointer;
            /*object?*/ _runtimeCallableWrapper = null;
            /*bool*/ _released = false;
            $ctor$1(/*IIUnknownInterfaceDetailsStrategy*/ interfaceDetailsStrategy, /*IIUnknownStrategy*/ iunknownStrategy, /*IIUnknownCacheStrategy*/ cacheStrategy, /*void**/ thisPointer)
            {
                super.$ctor();
                {
                    this.InterfaceDetailsStrategy = interfaceDetailsStrategy;
                    this.IUnknownStrategy = iunknownStrategy;
                    this.CacheStrategy = cacheStrategy;
                    this._instancePointer = this.IUnknownStrategy.System$Runtime$InteropServices$Marshalling$IIUnknownStrategy$CreateInstancePointer(thisPointer);
                    if ($.$$.System.OperatingSystem.IsWindows() && $.$sris.System.Runtime.InteropServices.Marshalling.ComObject.BuiltInComSupported && $.$sris.System.Runtime.InteropServices.Marshalling.ComObject.ComImportInteropEnabled)
                    {
                        this._runtimeCallableWrapper = $.$$.System.Runtime.InteropServices.Marshal.GetObjectForIUnknown($.$$.System.IntPtr.op_Explicit$4(thisPointer));
                        $.$$.System.Diagnostics.Debug.Assert$2($.$$.System.Runtime.InteropServices.Marshal.IsComObject(this._runtimeCallableWrapper), "Marshal.IsComObject(_runtimeCallableWrapper)");
                    }
                }
                return this;
            }
            $dtor()
            {
                this.CacheStrategy.System$Runtime$InteropServices$Marshalling$IIUnknownCacheStrategy$Clear(this.IUnknownStrategy);
                this.IUnknownStrategy.System$Runtime$InteropServices$Marshalling$IIUnknownStrategy$Release(this._instancePointer);
            }
            /*IIUnknownInterfaceDetailsStrategy*/ InterfaceDetailsStrategy = null;
            /*IIUnknownStrategy*/ IUnknownStrategy = null;
            /*IIUnknownCacheStrategy*/ CacheStrategy = null;
            /*bool*/ UniqueInstance = false;
            /*void */ FinalRelease()
            {
                if (this.UniqueInstance && !$.$$.System.Threading.Interlocked.Exchange$14($.$$.System.Boolean, $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateObjectReferenceT($.$$.System.Boolean, () => this._released, ($v) => this._released = $v, null), true))
                {
                    $.$$.System.GC.SuppressFinalize(this);
                    this.CacheStrategy.System$Runtime$InteropServices$Marshalling$IIUnknownCacheStrategy$Clear(this.IUnknownStrategy);
                    this.IUnknownStrategy.System$Runtime$InteropServices$Marshalling$IIUnknownStrategy$Release(this._instancePointer);
                }
            }
            /*RuntimeTypeHandle */ System$Runtime$InteropServices$IDynamicInterfaceCastable$GetInterfaceImplementation(/*RuntimeTypeHandle*/ interfaceType)
            {
                /*IIUnknownCacheStrategy.TableInfo*/ let info;
                /*int*/ let qiResult;
                if (!this.LookUpVTableInfo(interfaceType, $.$ref(() => info, ($v) => info = $v, $.$sris.System.Runtime.InteropServices.Marshalling.IIUnknownCacheStrategy.TableInfo), $.$ref(() => qiResult, ($v) => qiResult = $v, $.$$.System.Int32)))
                {
                    $.$$.System.Runtime.InteropServices.Marshal.ThrowExceptionForHR$2(qiResult);
                }
                return info.ManagedType;
            }
            /*bool */ System$Runtime$InteropServices$IDynamicInterfaceCastable$IsInterfaceImplemented(/*RuntimeTypeHandle*/ interfaceType, /*bool*/ throwIfNotImplemented)
            {
                /*int*/ let qiResult;
                if (!this.LookUpVTableInfo(interfaceType, $.$discardRef(), $.$ref(() => qiResult, ($v) => qiResult = $v, $.$$.System.Int32)))
                {
                    if (throwIfNotImplemented)
                    {
                        $.$$.System.Runtime.InteropServices.Marshal.ThrowExceptionForHR$2(qiResult);
                    }
                    return false;
                }
                return true;
            }
            /*bool */ LookUpVTableInfo(/*RuntimeTypeHandle*/ handle, /*out IIUnknownCacheStrategy.TableInfo*/ result, /*out int*/ qiHResult)
            {
                $.$$.System.ObjectDisposedException.ThrowIf(this._released, this);
                qiHResult.$v = 0;
                if (!this.CacheStrategy.System$Runtime$InteropServices$Marshalling$IIUnknownCacheStrategy$TryGetTableInfo(handle, result))
                {
                    /*IIUnknownDerivedDetails?*/ let details = this.InterfaceDetailsStrategy.System$Runtime$InteropServices$Marshalling$IIUnknownInterfaceDetailsStrategy$GetIUnknownDerivedDetails(handle);
                    if (details === null)
                    {
                        return false;
                    }
                    /*void**/ let ppv;
                    /*int*/ let hr = this.IUnknownStrategy.System$Runtime$InteropServices$Marshalling$IIUnknownStrategy$QueryInterface(this._instancePointer, $.$ref(() => details.System$Runtime$InteropServices$Marshalling$IIUnknownDerivedDetails$Iid, ), $.$ref(() => ppv, ($v) => ppv = $v, $.$typePointer($.$$.System.Void)));
                    if (hr < 0)
                    {
                        qiHResult.$v = hr;
                        return false;
                    }
                    result.$v = this.CacheStrategy.System$Runtime$InteropServices$Marshalling$IIUnknownCacheStrategy$ConstructTableInfo(handle, details, ppv);
                    if (!this.CacheStrategy.System$Runtime$InteropServices$Marshalling$IIUnknownCacheStrategy$TrySetTableInfo(handle, result.$v))
                    {
                        /*bool*/ let found = this.CacheStrategy.System$Runtime$InteropServices$Marshalling$IIUnknownCacheStrategy$TryGetTableInfo(handle, result);
                        $.$$.System.Diagnostics.Debug.Assert$2(found, "found");
                        _ = this.IUnknownStrategy.System$Runtime$InteropServices$Marshalling$IIUnknownStrategy$Release(ppv);
                    }
                }
                return true;
            }
            /*VirtualMethodTableInfo */ System$Runtime$InteropServices$Marshalling$IUnmanagedVirtualMethodTableProvider$GetVirtualMethodTableInfoForKey(/*Type*/ type)
            {
                /*IIUnknownCacheStrategy.TableInfo*/ let result;
                /*int*/ let qiHResult;
                if (!this.LookUpVTableInfo(type.TypeHandle, $.$ref(() => result, ($v) => result = $v, $.$sris.System.Runtime.InteropServices.Marshalling.IIUnknownCacheStrategy.TableInfo), $.$ref(() => qiHResult, ($v) => qiHResult = $v, $.$$.System.Int32)))
                {
                    $.$$.System.Runtime.InteropServices.Marshal.ThrowExceptionForHR$2(qiHResult);
                }
                return new $.$sris.System.Runtime.InteropServices.Marshalling.VirtualMethodTableInfo().$ctor$3(result.ThisPtr, result.Table);
            }
            /*object */ System$Runtime$InteropServices$Marshalling$ComImportInteropInterfaceDetailsStrategy$IComImportAdapter$GetRuntimeCallableWrapper()
            {
                $.$$.System.Diagnostics.Debug.Assert$2(this._runtimeCallableWrapper !== null, "_runtimeCallableWrapper != null");
                return this._runtimeCallableWrapper;
            }
            //default member initializer
            constructor()
            {
                super();
                this._instancePointer = $.$default($.$typePointer($.$$.System.Void));
                this.UniqueInstance = false;
                $.$finalizer(this);
            }
            //Static Initializer
            static $sinit()
            {
                {
                    /*bool*/ let supported;
                    this.BuiltInComSupported = $.$$.System.AppContext.TryGetSwitch("System.Runtime.InteropServices.BuiltInComInterop.IsSupported", $.$ref(() => supported, ($v) => supported = $v, $.$$.System.Boolean)) ? supported : true;
                }
                {
                    /*bool*/ let enabled;
                    this.ComImportInteropEnabled = $.$$.System.AppContext.TryGetSwitch("System.Runtime.InteropServices.Marshalling.EnableGeneratedComInterfaceComImportInterop", $.$ref(() => enabled, ($v) => enabled = $v, $.$$.System.Boolean)) ? enabled : false;
                }
            }
            static $h = 2217533;
            static $f = 0b10010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":262145,"g":{"r":0,"d":0,"h":12887119421,"f":50331688},"n":"BuiltInComSupported","d":2217533,"h":8592152125,"f":2097192},{"p":262145,"g":{"r":0,"d":0,"h":25772021309,"f":50331688},"n":"ComImportInteropEnabled","d":2217533,"h":21477054013,"f":2097192},{"p":3331645,"g":{"r":0,"d":0,"h":60131759677,"f":50331650},"n":"InterfaceDetailsStrategy","d":2217533,"h":55836792381,"f":2097154},{"p":3462717,"g":{"r":0,"d":0,"h":73016661565,"f":50331650},"n":"IUnknownStrategy","d":2217533,"h":68721694269,"f":2097154},{"p":3135037,"g":{"r":0,"d":0,"h":85901563453,"f":50331650},"n":"CacheStrategy","d":2217533,"h":81606596157,"f":2097154},{"p":262145,"g":{"r":0,"d":0,"h":98786465341,"f":50331656},"s":{"r":0,"d":0,"h":103081432637,"f":83886088},"n":"UniqueInstance","d":2217533,"h":94491498045,"f":2097160}],"m":[{"r":65537,"n":"FinalRelease","d":2217533,"h":107376399933,"f":16777217},{"r":262145,"p":[{"n":"handle","p":115933185},{"n":"result","p":3200573,"f":2},{"n":"qiHResult","p":655361,"f":2}],"n":"LookUpVTableInfo","d":2217533,"h":120261301821,"f":16777218}],"l":[{"t":$.$typePointer($.$$.System.Void).$h,"n":"_instancePointer","d":2217533,"h":30066988605,"f":4194306},{"t":131073,"n":"_runtimeCallableWrapper","d":2217533,"h":34361955901,"f":4194306},{"t":262145,"n":"_released","d":2217533,"h":38656923197,"f":4194306}],"c":[{"p":[{"n":"interfaceDetailsStrategy","p":3331645},{"n":"iunknownStrategy","p":3462717},{"n":"cacheStrategy","p":3135037},{"n":"thisPointer","p":$.$typePointer($.$$.System.Void).$h}],"n":".ctor","o":"$ctor$1","d":2217533,"h":42951890493,"f":16777224}],"i":[104660993,3593789,2020925],"h":2217533}; }
            static get $b() { return $.$$.System.Object; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.System.Runtime.InteropServices.IDynamicInterfaceCastable, $.$sris.System.Runtime.InteropServices.Marshalling.IUnmanagedVirtualMethodTableProvider, $.$sris.System.Runtime.InteropServices.Marshalling.ComImportInteropInterfaceDetailsStrategy.IComImportAdapter ]; }
            static get $fullName() { return `System.Runtime.InteropServices.Marshalling.ComObject`; }
        });
	});
})(window, window.NetJs.$boot(), ...window.NetJs.$require("NetJs.System.Private.CoreLib", "NetJs.System.Collections", "NetJs.System.Diagnostics.Tracing", "NetJs.System.Threading", "NetJs.System.Collections.Concurrent"))