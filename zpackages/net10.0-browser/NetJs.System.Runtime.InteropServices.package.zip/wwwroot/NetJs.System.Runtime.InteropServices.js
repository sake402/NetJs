
//--TRIMMABLE-BOUNDARY-START(7)
(async function () {
(function ($global, $, $$, $sc, $sdt, $st, $scc) {
    "use strict";
    let _;
    let $tdYAbj;
    
    
    
	$.$asm(
    "NetJs.System.Runtime.InteropServices", 
    {
  "h": 7,
  "f": "System.Runtime.InteropServices",
  "v": "1.0.35.0",
  "a": [
    {
      "t": 160038913,
      "c": 13044940801,
      "a": [
        {
          "v": ".NETCoreApp,Version=v10.0",
          "t": 1310721
        }
      ],
      "n": [
        {
          "n": "FrameworkDisplayName",
          "v": ".NET 10.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107151361,
      "c": 8697085953,
      "a": [
        {
          "v": "SIT",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107216897,
      "c": 8697151489,
      "a": [
        {
          "v": "Debug",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107675649,
      "c": 8697610241,
      "a": [
        {
          "v": "1.0.35.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107806721,
      "c": 8697741313,
      "a": [
        {
          "v": "1.0.35\u002B96771abe2820045936210554b19d0578b9bc2b1c",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108658689,
      "c": 8698593281,
      "a": [
        {
          "v": "NetJs.System.Runtime.InteropServices",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108789761,
      "c": 8698724353,
      "a": [
        {
          "v": "NetJs.System.Runtime.InteropServices",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108920833,
      "c": 8698855425,
      "a": [
        {
          "v": "1.0.35.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 160104449,
      "c": 4455071745,
      "a": [
        {
          "v": "browser1.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 159842305,
      "c": 4454809601,
      "a": [
        {
          "v": "browser1.0",
          "t": 1310721
        }
      ]
    }
  ],
  "m": []
},
    function($asm)
	{
        
        
        //--TRIMMABLE-BOUNDARY-START(983047)
        $asm.$cls(`$sris.SRIC.IAdviseSink`, ($self) => class IAdviseSink
        {
            static $h = 983047;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8590917639),
    {
      "r": 65537,
      "p": [
        {
          "n": "format",
          "p": 917511,
          "f": 4,
          "a": [
            {
              "t": 143130625,
              "c": 4438097921
            }
          ]
        },
        {
          "n": "stgmedium",
          "p": 1310727,
          "f": 4,
          "a": [
            {
              "t": 143130625,
              "c": 4438097921
            }
          ]
        }
      ],
      "n": "OnDataChange",
      "o": "SRIC$IAdviseSink$OnDataChange",
      "d": 983047,
      "h": 8590917639,
      "f": 16777473,
      "a": [
        {
          "t": 147456001,
          "c": 4442423297
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(8590917639),
//--TRIMMABLE-BOUNDARY-START(21475819527),
    {
      "r": 65537,
      "p": [
        {
          "n": "aspect",
          "p": 655361
        },
        {
          "n": "index",
          "p": 655361
        }
      ],
      "n": "OnViewChange",
      "o": "SRIC$IAdviseSink$OnViewChange",
      "d": 983047,
      "h": 21475819527,
      "f": 16777473,
      "a": [
        {
          "t": 147456001,
          "c": 4442423297
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(21475819527),
//--TRIMMABLE-BOUNDARY-START(12885884935),
    {
      "r": 65537,
      "p": [
        {
          "n": "moniker",
          "p": 139198465
        }
      ],
      "n": "OnRename",
      "o": "SRIC$IAdviseSink$OnRename",
      "d": 983047,
      "h": 12885884935,
      "f": 16777473,
      "a": [
        {
          "t": 147456001,
          "c": 4442423297
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(12885884935),
//--TRIMMABLE-BOUNDARY-START(17180852231),
    {
      "r": 65537,
      "n": "OnSave",
      "o": "SRIC$IAdviseSink$OnSave",
      "d": 983047,
      "h": 17180852231,
      "f": 16777473,
      "a": [
        {
          "t": 147456001,
          "c": 4442423297
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(17180852231),
//--TRIMMABLE-BOUNDARY-START(4295950343),
    {
      "r": 65537,
      "n": "OnClose",
      "o": "SRIC$IAdviseSink$OnClose",
      "d": 983047,
      "h": 4295950343,
      "f": 16777473,
      "a": [
        {
          "t": 147456001,
          "c": 4442423297
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(4295950343)
  ],
  "h": 983047,
  "a": [
    {
      "t": 137428993,
      "c": 4432396289
    },
    {
      "t": 142671873,
      "c": 8732606465,
      "a": [
        {
          "v": "0000010F-0000-0000-C000-000000000046",
          "t": 1310721
        }
      ]
    },
    {
      "t": 65011713,
      "c": 12949913601,
      "a": [
        {
          "v": 1,
          "t": 65077249
        }
      ]
    },
    {
      "t": 143196161,
      "c": 13028098049,
      "a": [
        {
          "v": 1,
          "t": 137494529
        }
      ]
    }
  ]
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `System.Runtime.InteropServices.ComTypes.IAdviseSink`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `System${separator}Runtime${separator}InteropServices${separator}ComTypes${separator}IAdviseSink`; }
        });
        //--TRIMMABLE-BOUNDARY-END(983047)
        
        

        //--TRIMMABLE-BOUNDARY-START(1179655)
        $asm.$cls(`$sris.SRIC.IEnumSTATDATA`, ($self) => class IEnumSTATDATA
        {
            static $h = 1179655;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8591114247),
    {
      "r": 655361,
      "p": [
        {
          "n": "celt",
          "p": 655361
        },
        {
          "n": "rgelt",
          "p": $.$typeArray($.$sris.SRIC.STATDATA).$h,
          "a": [
            {
              "t": 147062785,
              "c": 4442030081
            },
            {
              "t": 143982593,
              "c": 13028884481,
              "a": [
                {
                  "v": 42,
                  "t": 149159937
                }
              ],
              "n": [
                {
                  "n": "SizeParamIndex",
                  "v": 0,
                  "t": 524289
                }
              ]
            }
          ]
        },
        {
          "n": "pceltFetched",
          "p": $.$typeArray($.$$.S.Int32).$h,
          "a": [
            {
              "t": 147062785,
              "c": 4442030081
            },
            {
              "t": 143982593,
              "c": 13028884481,
              "a": [
                {
                  "v": 42,
                  "t": 149159937
                }
              ],
              "n": [
                {
                  "n": "SizeConst",
                  "v": 1,
                  "t": 655361
                }
              ]
            }
          ]
        }
      ],
      "n": "Next",
      "o": "SRIC$IEnumSTATDATA$Next",
      "d": 1179655,
      "h": 8591114247,
      "f": 16777473,
      "a": [
        {
          "t": 147456001,
          "c": 4442423297
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(8591114247),
//--TRIMMABLE-BOUNDARY-START(17181048839),
    {
      "r": 655361,
      "p": [
        {
          "n": "celt",
          "p": 655361
        }
      ],
      "n": "Skip",
      "o": "SRIC$IEnumSTATDATA$Skip",
      "d": 1179655,
      "h": 17181048839,
      "f": 16777473,
      "a": [
        {
          "t": 147456001,
          "c": 4442423297
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(17181048839),
//--TRIMMABLE-BOUNDARY-START(12886081543),
    {
      "r": 655361,
      "n": "Reset",
      "o": "SRIC$IEnumSTATDATA$Reset",
      "d": 1179655,
      "h": 12886081543,
      "f": 16777473,
      "a": [
        {
          "t": 147456001,
          "c": 4442423297
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(12886081543),
//--TRIMMABLE-BOUNDARY-START(4296146951),
    {
      "r": 65537,
      "p": [
        {
          "n": "newEnum",
          "p": 1179655,
          "f": 2
        }
      ],
      "n": "Clone",
      "o": "SRIC$IEnumSTATDATA$Clone",
      "d": 1179655,
      "h": 4296146951,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(4296146951)
  ],
  "h": 1179655,
  "a": [
    {
      "t": 137428993,
      "c": 4432396289
    },
    {
      "t": 142671873,
      "c": 8732606465,
      "a": [
        {
          "v": "00000105-0000-0000-C000-000000000046",
          "t": 1310721
        }
      ]
    },
    {
      "t": 143196161,
      "c": 13028098049,
      "a": [
        {
          "v": 1,
          "t": 137494529
        }
      ]
    }
  ]
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `System.Runtime.InteropServices.ComTypes.IEnumSTATDATA`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `System${separator}Runtime${separator}InteropServices${separator}ComTypes${separator}IEnumSTATDATA`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1179655)
        
        

        //--TRIMMABLE-BOUNDARY-START(1114119)
        $asm.$cls(`$sris.SRIC.IEnumFORMATETC`, ($self) => class IEnumFORMATETC
        {
            static $h = 1114119;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8591048711),
    {
      "r": 655361,
      "p": [
        {
          "n": "celt",
          "p": 655361
        },
        {
          "n": "rgelt",
          "p": $.$typeArray($.$sris.SRIC.FORMATETC).$h,
          "a": [
            {
              "t": 147062785,
              "c": 4442030081
            },
            {
              "t": 143982593,
              "c": 13028884481,
              "a": [
                {
                  "v": 42,
                  "t": 149159937
                }
              ],
              "n": [
                {
                  "n": "SizeParamIndex",
                  "v": 0,
                  "t": 524289
                }
              ]
            }
          ]
        },
        {
          "n": "pceltFetched",
          "p": $.$typeArray($.$$.S.Int32).$h,
          "a": [
            {
              "t": 147062785,
              "c": 4442030081
            },
            {
              "t": 143982593,
              "c": 13028884481,
              "a": [
                {
                  "v": 42,
                  "t": 149159937
                }
              ]
            }
          ]
        }
      ],
      "n": "Next",
      "o": "SRIC$IEnumFORMATETC$Next",
      "d": 1114119,
      "h": 8591048711,
      "f": 16777473,
      "a": [
        {
          "t": 147456001,
          "c": 4442423297
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(8591048711),
//--TRIMMABLE-BOUNDARY-START(17180983303),
    {
      "r": 655361,
      "p": [
        {
          "n": "celt",
          "p": 655361
        }
      ],
      "n": "Skip",
      "o": "SRIC$IEnumFORMATETC$Skip",
      "d": 1114119,
      "h": 17180983303,
      "f": 16777473,
      "a": [
        {
          "t": 147456001,
          "c": 4442423297
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(17180983303),
//--TRIMMABLE-BOUNDARY-START(12886016007),
    {
      "r": 655361,
      "n": "Reset",
      "o": "SRIC$IEnumFORMATETC$Reset",
      "d": 1114119,
      "h": 12886016007,
      "f": 16777473,
      "a": [
        {
          "t": 147456001,
          "c": 4442423297
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(12886016007),
//--TRIMMABLE-BOUNDARY-START(4296081415),
    {
      "r": 65537,
      "p": [
        {
          "n": "newEnum",
          "p": 1114119,
          "f": 2
        }
      ],
      "n": "Clone",
      "o": "SRIC$IEnumFORMATETC$Clone",
      "d": 1114119,
      "h": 4296081415,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(4296081415)
  ],
  "h": 1114119,
  "a": [
    {
      "t": 137428993,
      "c": 4432396289
    },
    {
      "t": 142671873,
      "c": 8732606465,
      "a": [
        {
          "v": "00000103-0000-0000-C000-000000000046",
          "t": 1310721
        }
      ]
    },
    {
      "t": 65011713,
      "c": 12949913601,
      "a": [
        {
          "v": 1,
          "t": 65077249
        }
      ]
    },
    {
      "t": 143196161,
      "c": 13028098049,
      "a": [
        {
          "v": 1,
          "t": 137494529
        }
      ]
    }
  ]
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `System.Runtime.InteropServices.ComTypes.IEnumFORMATETC`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `System${separator}Runtime${separator}InteropServices${separator}ComTypes${separator}IEnumFORMATETC`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1114119)
        
        

        //--TRIMMABLE-BOUNDARY-START(3276807)
        $asm.$cls(`$sris.SRIM.IIUnknownInterfaceDetailsStrategy`, ($self) => class IIUnknownInterfaceDetailsStrategy
        {
            static $h = 3276807;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8593211399),
    {
      "r": 3211271,
      "p": [
        {
          "n": "type",
          "p": 160956417
        }
      ],
      "n": "GetIUnknownDerivedDetails",
      "o": "SRIM$IIUnknownInterfaceDetailsStrategy$GetIUnknownDerivedDetails",
      "d": 3276807,
      "h": 8593211399,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(8593211399),
//--TRIMMABLE-BOUNDARY-START(4298244103),
    {
      "r": 3014663,
      "p": [
        {
          "n": "type",
          "p": 160956417
        }
      ],
      "n": "GetComExposedTypeDetails",
      "o": "SRIM$IIUnknownInterfaceDetailsStrategy$GetComExposedTypeDetails",
      "d": 3276807,
      "h": 4298244103,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(4298244103)
  ],
  "h": 3276807,
  "a": [
    {
      "t": 54984705,
      "c": 8644919297,
      "a": [
        {
          "v": false,
          "t": 262145
        }
      ]
    }
  ]
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `System.Runtime.InteropServices.Marshalling.IIUnknownInterfaceDetailsStrategy`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `System${separator}Runtime${separator}InteropServices${separator}Marshalling${separator}IIUnknownInterfaceDetailsStrategy`; }
        });
        //--TRIMMABLE-BOUNDARY-END(3276807)
        
        

        //--TRIMMABLE-BOUNDARY-START(2949127)
        $asm.$cls(`$sris.SRIM.IComExposedClass`, ($self) => class IComExposedClass
        {
            static $h = 2949127;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4297916423),
    {
      "r": $.$typePointer($.$$.SRI.ComWrappers.ComInterfaceEntry).$h,
      "p": [
        {
          "n": "count",
          "p": 655361,
          "f": 2
        }
      ],
      "n": "GetComInterfaceEntries",
      "o": "SRIM$IComExposedClass$GetComInterfaceEntries",
      "d": 2949127,
      "h": 4297916423,
      "f": 16777505
    },
//--TRIMMABLE-BOUNDARY-END(4297916423)
  ],
  "h": 2949127,
  "a": [
    {
      "t": 54984705,
      "c": 8644919297,
      "a": [
        {
          "v": false,
          "t": 262145
        }
      ]
    }
  ]
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `System.Runtime.InteropServices.Marshalling.IComExposedClass`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `System${separator}Runtime${separator}InteropServices${separator}Marshalling${separator}IComExposedClass`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2949127)
        
        

        //--TRIMMABLE-BOUNDARY-START(3407879)
        $asm.$cls(`$sris.SRIM.IIUnknownStrategy`, ($self) => class IIUnknownStrategy
        {
            static $h = 3407879;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4298375175),
    {
      "r": $.$typePointer($.$$.S.Void).$h,
      "p": [
        {
          "n": "unknown",
          "p": $.$typePointer($.$$.S.Void).$h
        }
      ],
      "n": "CreateInstancePointer",
      "o": "SRIM$IIUnknownStrategy$CreateInstancePointer",
      "d": 3407879,
      "h": 4298375175,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(4298375175),
//--TRIMMABLE-BOUNDARY-START(8593342471),
    {
      "r": 655361,
      "p": [
        {
          "n": "instancePtr",
          "p": $.$typePointer($.$$.S.Void).$h
        },
        {
          "n": "iid",
          "p": 89784321,
          "f": 8
        },
        {
          "n": "ppObj",
          "p": $.$typePointer($.$$.S.Void).$h,
          "f": 2
        }
      ],
      "n": "QueryInterface",
      "o": "SRIM$IIUnknownStrategy$QueryInterface",
      "d": 3407879,
      "h": 8593342471,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(8593342471),
//--TRIMMABLE-BOUNDARY-START(12888309767),
    {
      "r": 655361,
      "p": [
        {
          "n": "instancePtr",
          "p": $.$typePointer($.$$.S.Void).$h
        }
      ],
      "n": "Release",
      "o": "SRIM$IIUnknownStrategy$Release",
      "d": 3407879,
      "h": 12888309767,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(12888309767)
  ],
  "h": 3407879,
  "a": [
    {
      "t": 54984705,
      "c": 8644919297,
      "a": [
        {
          "v": false,
          "t": 262145
        }
      ]
    }
  ]
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `System.Runtime.InteropServices.Marshalling.IIUnknownStrategy`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `System${separator}Runtime${separator}InteropServices${separator}Marshalling${separator}IIUnknownStrategy`; }
        });
        //--TRIMMABLE-BOUNDARY-END(3407879)
        
        

        //--TRIMMABLE-BOUNDARY-START(1048583)
        $asm.$cls(`$sris.SRIC.IDataObject`, ($self) => class IDataObject
        {
            static $h = 1048583;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(25770852359),
    {
      "r": 65537,
      "p": [
        {
          "n": "format",
          "p": 917511,
          "f": 4,
          "a": [
            {
              "t": 143130625,
              "c": 4438097921
            }
          ]
        },
        {
          "n": "medium",
          "p": 1310727,
          "f": 2
        }
      ],
      "n": "GetData",
      "o": "SRIC$IDataObject$GetData",
      "d": 1048583,
      "h": 25770852359,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(25770852359),
//--TRIMMABLE-BOUNDARY-START(30065819655),
    {
      "r": 65537,
      "p": [
        {
          "n": "format",
          "p": 917511,
          "f": 4,
          "a": [
            {
              "t": 143130625,
              "c": 4438097921
            }
          ]
        },
        {
          "n": "medium",
          "p": 1310727,
          "f": 4
        }
      ],
      "n": "GetDataHere",
      "o": "SRIC$IDataObject$GetDataHere",
      "d": 1048583,
      "h": 30065819655,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(30065819655),
//--TRIMMABLE-BOUNDARY-START(34360786951),
    {
      "r": 655361,
      "p": [
        {
          "n": "format",
          "p": 917511,
          "f": 4,
          "a": [
            {
              "t": 143130625,
              "c": 4438097921
            }
          ]
        }
      ],
      "n": "QueryGetData",
      "o": "SRIC$IDataObject$QueryGetData",
      "d": 1048583,
      "h": 34360786951,
      "f": 16777473,
      "a": [
        {
          "t": 147456001,
          "c": 4442423297
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(34360786951),
//--TRIMMABLE-BOUNDARY-START(21475885063),
    {
      "r": 655361,
      "p": [
        {
          "n": "formatIn",
          "p": 917511,
          "f": 4,
          "a": [
            {
              "t": 143130625,
              "c": 4438097921
            }
          ]
        },
        {
          "n": "formatOut",
          "p": 917511,
          "f": 2
        }
      ],
      "n": "GetCanonicalFormatEtc",
      "o": "SRIC$IDataObject$GetCanonicalFormatEtc",
      "d": 1048583,
      "h": 21475885063,
      "f": 16777473,
      "a": [
        {
          "t": 147456001,
          "c": 4442423297
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(21475885063),
//--TRIMMABLE-BOUNDARY-START(38655754247),
    {
      "r": 65537,
      "p": [
        {
          "n": "formatIn",
          "p": 917511,
          "f": 4,
          "a": [
            {
              "t": 143130625,
              "c": 4438097921
            }
          ]
        },
        {
          "n": "medium",
          "p": 1310727,
          "f": 4,
          "a": [
            {
              "t": 143130625,
              "c": 4438097921
            }
          ]
        },
        {
          "n": "release",
          "p": 262145,
          "a": [
            {
              "t": 143982593,
              "c": 13028884481,
              "a": [
                {
                  "v": 2,
                  "t": 149159937
                }
              ]
            }
          ]
        }
      ],
      "n": "SetData",
      "o": "SRIC$IDataObject$SetData",
      "d": 1048583,
      "h": 38655754247,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(38655754247),
//--TRIMMABLE-BOUNDARY-START(17180917767),
    {
      "r": 1114119,
      "p": [
        {
          "n": "direction",
          "p": 786439
        }
      ],
      "n": "EnumFormatEtc",
      "o": "SRIC$IDataObject$EnumFormatEtc",
      "d": 1048583,
      "h": 17180917767,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(17180917767),
//--TRIMMABLE-BOUNDARY-START(4296015879),
    {
      "r": 655361,
      "p": [
        {
          "n": "pFormatetc",
          "p": 917511,
          "f": 4,
          "a": [
            {
              "t": 143130625,
              "c": 4438097921
            }
          ]
        },
        {
          "n": "advf",
          "p": 720903
        },
        {
          "n": "adviseSink",
          "p": 983047
        },
        {
          "n": "connection",
          "p": 655361,
          "f": 2
        }
      ],
      "n": "DAdvise",
      "o": "SRIC$IDataObject$DAdvise",
      "d": 1048583,
      "h": 4296015879,
      "f": 16777473,
      "a": [
        {
          "t": 147456001,
          "c": 4442423297
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(4296015879),
//--TRIMMABLE-BOUNDARY-START(8590983175),
    {
      "r": 65537,
      "p": [
        {
          "n": "connection",
          "p": 655361
        }
      ],
      "n": "DUnadvise",
      "o": "SRIC$IDataObject$DUnadvise",
      "d": 1048583,
      "h": 8590983175,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(8590983175),
//--TRIMMABLE-BOUNDARY-START(12885950471),
    {
      "r": 655361,
      "p": [
        {
          "n": "enumAdvise",
          "p": 1179655,
          "f": 2
        }
      ],
      "n": "EnumDAdvise",
      "o": "SRIC$IDataObject$EnumDAdvise",
      "d": 1048583,
      "h": 12885950471,
      "f": 16777473,
      "a": [
        {
          "t": 147456001,
          "c": 4442423297
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(12885950471)
  ],
  "h": 1048583,
  "a": [
    {
      "t": 54984705,
      "c": 8644919297,
      "a": [
        {
          "v": false,
          "t": 262145
        }
      ]
    },
    {
      "t": 137428993,
      "c": 4432396289
    },
    {
      "t": 142671873,
      "c": 8732606465,
      "a": [
        {
          "v": "0000010E-0000-0000-C000-000000000046",
          "t": 1310721
        }
      ]
    },
    {
      "t": 143196161,
      "c": 13028098049,
      "a": [
        {
          "v": 1,
          "t": 137494529
        }
      ]
    }
  ]
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `System.Runtime.InteropServices.ComTypes.IDataObject`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `System${separator}Runtime${separator}InteropServices${separator}ComTypes${separator}IDataObject`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1048583)
        
        

        //--TRIMMABLE-BOUNDARY-START(3538951)
        $asm.$cls(`$sris.SRIM.IUnmanagedVirtualMethodTableProvider`, ($self) => class IUnmanagedVirtualMethodTableProvider
        {
            static $h = 3538951;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4298506247),
    {
      "r": 3735559,
      "p": [
        {
          "n": "type",
          "p": 188547073
        }
      ],
      "n": "GetVirtualMethodTableInfoForKey",
      "o": "SRIM$IUnmanagedVirtualMethodTableProvider$GetVirtualMethodTableInfoForKey",
      "d": 3538951,
      "h": 4298506247,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(4298506247)
  ],
  "h": 3538951,
  "a": [
    {
      "t": 54984705,
      "c": 8644919297,
      "a": [
        {
          "v": false,
          "t": 262145
        }
      ]
    }
  ]
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `System.Runtime.InteropServices.Marshalling.IUnmanagedVirtualMethodTableProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `System${separator}Runtime${separator}InteropServices${separator}Marshalling${separator}IUnmanagedVirtualMethodTableProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(3538951)
        
        

        //--TRIMMABLE-BOUNDARY-START(3014663)
        $asm.$cls(`$sris.SRIM.IComExposedDetails`, ($self) => class IComExposedDetails
        {
            //--TRIMMABLE-BOUNDARY-START(8592949255)
            static /*IComExposedDetails? */ SRIM$IComExposedDetails$GetFromAttribute(/*RuntimeTypeHandle*/ handle)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8592949255);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let type = $.$$.S.Type.GetTypeFromHandle(handle);
                if (type === null)
                {
                    return null;
                }
                return $.$cast($.$$.SR.CustomAttributeExtensions.GetCustomAttribute$2(type, $.$sris.SRIM.ComExposedClassAttribute$$().$type), $.$sris.SRIM.IComExposedDetails);
            }
            //--TRIMMABLE-BOUNDARY-END(8592949255)
            
            static $h = 3014663;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4297981959),
    {
      "r": $.$typePointer($.$$.SRI.ComWrappers.ComInterfaceEntry).$h,
      "p": [
        {
          "n": "count",
          "p": 655361,
          "f": 2
        }
      ],
      "n": "GetComInterfaceEntries",
      "o": "SRIM$IComExposedDetails$GetComInterfaceEntries",
      "d": 3014663,
      "h": 4297981959,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(4297981959),
//--TRIMMABLE-BOUNDARY-START(8592949255),
    {
      "r": 3014663,
      "p": [
        {
          "n": "handle",
          "p": 160956417
        }
      ],
      "n": "GetFromAttribute",
      "o": "SRIM$IComExposedDetails$GetFromAttribute",
      "d": 3014663,
      "h": 8592949255,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(8592949255)
  ],
  "h": 3014663,
  "a": [
    {
      "t": 54984705,
      "c": 8644919297,
      "a": [
        {
          "v": false,
          "t": 262145
        }
      ]
    }
  ]
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `System.Runtime.InteropServices.Marshalling.IComExposedDetails`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `System${separator}Runtime${separator}InteropServices${separator}Marshalling${separator}IComExposedDetails`; }
        });
        //--TRIMMABLE-BOUNDARY-END(3014663)
        
        

        //--TRIMMABLE-BOUNDARY-START(3211271)
        $asm.$cls(`$sris.SRIM.IIUnknownDerivedDetails`, ($self) => class IIUnknownDerivedDetails
        {
            //--TRIMMABLE-BOUNDARY-START(30067982343)
            static /*IIUnknownDerivedDetails? */ SRIM$IIUnknownDerivedDetails$GetFromAttribute(/*RuntimeTypeHandle*/ handle)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(30067982343);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let type = $.$$.S.Type.GetTypeFromHandle(handle);
                if (type === null)
                {
                    return null;
                }
                return $.$cast($.$$.SR.CustomAttributeExtensions.GetCustomAttribute$2(type, $.$sris.SRIM.IUnknownDerivedAttribute$$$().$type), $.$sris.SRIM.IIUnknownDerivedDetails);
            }
            //--TRIMMABLE-BOUNDARY-END(30067982343)
            
            static $h = 3211271;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(34362949639),
    {
      "p": 89784321,
      "g": {
        "r": 0,
        "d": 0,
        "h": 8593145863,
        "f": 50331905
      },
      "n": "Iid",
      "o": "SRIM$IIUnknownDerivedDetails$Iid",
      "d": 3211271,
      "h": 34362949639,
      "f": 2097409
    },
//--TRIMMABLE-BOUNDARY-END(34362949639),
//--TRIMMABLE-BOUNDARY-START(38657916935),
    {
      "p": 188547073,
      "g": {
        "r": 0,
        "d": 0,
        "h": 17183080455,
        "f": 50331905
      },
      "n": "Implementation",
      "o": "SRIM$IIUnknownDerivedDetails$Implementation",
      "d": 3211271,
      "h": 38657916935,
      "f": 2097409
    },
//--TRIMMABLE-BOUNDARY-END(38657916935),
//--TRIMMABLE-BOUNDARY-START(42952884231),
    {
      "p": $.$typePointer($.$typePointer($.$$.S.Void)).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 25773015047,
        "f": 50331905
      },
      "n": "ManagedVirtualMethodTable",
      "o": "SRIM$IIUnknownDerivedDetails$ManagedVirtualMethodTable",
      "d": 3211271,
      "h": 42952884231,
      "f": 2097409
    },
//--TRIMMABLE-BOUNDARY-END(42952884231)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(30067982343),
    {
      "r": 3211271,
      "p": [
        {
          "n": "handle",
          "p": 160956417
        }
      ],
      "n": "GetFromAttribute",
      "o": "SRIM$IIUnknownDerivedDetails$GetFromAttribute",
      "d": 3211271,
      "h": 30067982343,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(30067982343)
  ],
  "h": 3211271,
  "a": [
    {
      "t": 54984705,
      "c": 8644919297,
      "a": [
        {
          "v": false,
          "t": 262145
        }
      ]
    }
  ]
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `System.Runtime.InteropServices.Marshalling.IIUnknownDerivedDetails`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `System${separator}Runtime${separator}InteropServices${separator}Marshalling${separator}IIUnknownDerivedDetails`; }
        });
        //--TRIMMABLE-BOUNDARY-END(3211271)
        
        

        //--TRIMMABLE-BOUNDARY-START(3080199)
        $asm.$cls(`$sris.SRIM.IIUnknownCacheStrategy`, ($self) => class IIUnknownCacheStrategy
        {
            //--TRIMMABLE-BOUNDARY-START(3145735)
            static $_TableInfo;
            static get TableInfo()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(3145735);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                let $cls = $.$sris.SRIM.IIUnknownCacheStrategy;
                return $cls.$_TableInfo ??= $asm.$nstr(`$sris.SRIM.IIUnknownCacheStrategy.TableInfo`, ($self) => class TableInfo extends $.$$.S.ValueType
                {
                    //--TRIMMABLE-BOUNDARY-START(81607524359)
                    /*void**/ ThisPtr;
                    //--TRIMMABLE-BOUNDARY-END(81607524359)
                    
                    //--TRIMMABLE-BOUNDARY-START(77312557063)
                    /*void***/ Table;
                    //--TRIMMABLE-BOUNDARY-END(77312557063)
                    
                    //--TRIMMABLE-BOUNDARY-START(47247785991)
                    /*RuntimeTypeHandle*/ ManagedType;
                    //--TRIMMABLE-BOUNDARY-END(47247785991)
                    
                    //--TRIMMABLE-BOUNDARY-START(17183014919)
                    //default constructor overload
                    $ctor$2()
                    {
                        super.$ctor$1();
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(17183014919);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return this;
                    }
                    //--TRIMMABLE-BOUNDARY-END(17183014919)
                    
                    //--TRIMMABLE-BOUNDARY-START(17183014919)
                    //generic new constructor
                    $gctor()
                    {
                        return this.$ctor$2();
                    }
                    //--TRIMMABLE-BOUNDARY-END(17183014919)
                    
                    $clone($copy)
                    {
                        let copy = $copy ?? new this.constructor();
                        copy.ThisPtr = this.ThisPtr.$clone();
                        copy.Table = this.Table.$clone();
                        copy.ManagedType = this.ManagedType.$clone();
                        return copy;
                    }
                    //default member initializer
                    constructor()
                    {
                        super();
                        //--TRIMMABLE-BOUNDARY-START(81607524359)
                        this.ThisPtr = $.$default($.$typePointer($.$$.S.Void));
                        //--TRIMMABLE-BOUNDARY-END(81607524359)
                        
                        //--TRIMMABLE-BOUNDARY-START(77312557063)
                        this.Table = $.$default($.$typePointer($.$typePointer($.$$.S.Void)));
                        //--TRIMMABLE-BOUNDARY-END(77312557063)
                        
                        //--TRIMMABLE-BOUNDARY-START(47247785991)
                        this.ManagedType = $.$default($.$$.S.RuntimeTypeHandle);
                        //--TRIMMABLE-BOUNDARY-END(47247785991)
                        
                    }
                    static $h = 3145735;
                    static $z = 12;
                    static $f = 0b10000001010000001;
                    static $k = 2;
                    static $$b;
                    static get $b() { return this.$$b ??= $.$$.S.ValueType; }
                    static $$md;
                    static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(81607524359),
    {
      "p": $.$typePointer($.$$.S.Void).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 42952818695,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 73017589767,
        "f": 83886081
      },
      "n": "ThisPtr",
      "d": 3145735,
      "h": 81607524359,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(81607524359),
//--TRIMMABLE-BOUNDARY-START(77312557063),
    {
      "p": $.$typePointer($.$typePointer($.$$.S.Void)).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 34362884103,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 64427655175,
        "f": 83886081
      },
      "n": "Table",
      "d": 3145735,
      "h": 77312557063,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(77312557063),
//--TRIMMABLE-BOUNDARY-START(47247785991),
    {
      "p": 160956417,
      "g": {
        "r": 0,
        "d": 0,
        "h": 25772949511,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 55837720583,
        "f": 83886081
      },
      "n": "ManagedType",
      "d": 3145735,
      "h": 47247785991,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(47247785991)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(17183014919),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 3145735,
      "h": 17183014919,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(17183014919)
  ],
  "d": 3080199,
  "h": 3145735
}; }
                    static $$fullName;
                    static get $fullName() { return this.$$fullName ??= `System.Runtime.InteropServices.Marshalling.IIUnknownCacheStrategy+TableInfo`; }
                    static $$getFullName = {};
                    static $getFullName(separator) { return this.$$getFullName[separator] ??= `System${separator}Runtime${separator}InteropServices${separator}Marshalling${separator}IIUnknownCacheStrategy${separator}TableInfo`; }
                }, $cls, ($v) => $cls.$_TableInfo = $v);
            }
            //--TRIMMABLE-BOUNDARY-END(3145735)
            
            static $h = 3080199;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8593014791),
    {
      "r": 3145735,
      "p": [
        {
          "n": "handle",
          "p": 160956417
        },
        {
          "n": "interfaceDetails",
          "p": 3211271
        },
        {
          "n": "ptr",
          "p": $.$typePointer($.$$.S.Void).$h
        }
      ],
      "n": "ConstructTableInfo",
      "o": "SRIM$IIUnknownCacheStrategy$ConstructTableInfo",
      "d": 3080199,
      "h": 8593014791,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(8593014791),
//--TRIMMABLE-BOUNDARY-START(12887982087),
    {
      "r": 262145,
      "p": [
        {
          "n": "handle",
          "p": 160956417
        },
        {
          "n": "info",
          "p": 3145735,
          "f": 2
        }
      ],
      "n": "TryGetTableInfo",
      "o": "SRIM$IIUnknownCacheStrategy$TryGetTableInfo",
      "d": 3080199,
      "h": 12887982087,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(12887982087),
//--TRIMMABLE-BOUNDARY-START(17182949383),
    {
      "r": 262145,
      "p": [
        {
          "n": "handle",
          "p": 160956417
        },
        {
          "n": "info",
          "p": 3145735
        }
      ],
      "n": "TrySetTableInfo",
      "o": "SRIM$IIUnknownCacheStrategy$TrySetTableInfo",
      "d": 3080199,
      "h": 17182949383,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(17182949383),
//--TRIMMABLE-BOUNDARY-START(4298047495),
    {
      "r": 65537,
      "p": [
        {
          "n": "unknownStrategy",
          "p": 3407879
        }
      ],
      "n": "Clear",
      "o": "SRIM$IIUnknownCacheStrategy$Clear",
      "d": 3080199,
      "h": 4298047495,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(4298047495)
  ],
  "h": 3080199,
  "a": [
    {
      "t": 54984705,
      "c": 8644919297,
      "a": [
        {
          "v": false,
          "t": 262145
        }
      ]
    }
  ]
}; }
            static $$n;
            static get $n() { return this.$$n ??= [ $.$sris.SRIM.IIUnknownCacheStrategy.TableInfo ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `System.Runtime.InteropServices.Marshalling.IIUnknownCacheStrategy`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `System${separator}Runtime${separator}InteropServices${separator}Marshalling${separator}IIUnknownCacheStrategy`; }
        });
        //--TRIMMABLE-BOUNDARY-END(3080199)
        
        

        //--TRIMMABLE-BOUNDARY-START(3342343)
        $asm.$cls(`$sris.SRIM.IIUnknownInterfaceType`, ($self) => class IIUnknownInterfaceType
        {
            static $h = 3342343;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(21478178823),
    {
      "p": 89784321,
      "g": {
        "r": 0,
        "d": 0,
        "h": 8593276935,
        "f": 50331937
      },
      "n": "Iid",
      "o": "SRIM$IIUnknownInterfaceType$Iid",
      "d": 3342343,
      "h": 21478178823,
      "f": 2097441
    },
//--TRIMMABLE-BOUNDARY-END(21478178823),
//--TRIMMABLE-BOUNDARY-START(25773146119),
    {
      "p": $.$typePointer($.$typePointer($.$$.S.Void)).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 17183211527,
        "f": 50331937
      },
      "n": "ManagedVirtualMethodTable",
      "o": "SRIM$IIUnknownInterfaceType$ManagedVirtualMethodTable",
      "d": 3342343,
      "h": 25773146119,
      "f": 2097441
    },
//--TRIMMABLE-BOUNDARY-END(25773146119)
  ],
  "h": 3342343,
  "a": [
    {
      "t": 54984705,
      "c": 8644919297,
      "a": [
        {
          "v": false,
          "t": 262145
        }
      ]
    }
  ]
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `System.Runtime.InteropServices.Marshalling.IIUnknownInterfaceType`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `System${separator}Runtime${separator}InteropServices${separator}Marshalling${separator}IIUnknownInterfaceType`; }
        });
        //--TRIMMABLE-BOUNDARY-END(3342343)
        
        

        //--TRIMMABLE-BOUNDARY-START(2621447)
        $asm.$cls(`$sris.SRIM.ExceptionAsNaNMarshaller<>`, (T) => $asm.$gt(`$sris.SRIM.ExceptionAsNaNMarshaller<>`, [T], ($self) => class ExceptionAsNaNMarshaller$$
        {
            //--TRIMMABLE-BOUNDARY-START(4297588743)
            static /*T */ ConvertToUnmanaged(/*Exception*/ e)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4297588743);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                _ = $.$$.SRI.Marshal.GetHRForException(e);
                return T.SN$1$IFloatingPointIeee754$$$NaN;
            }
            //--TRIMMABLE-BOUNDARY-END(4297588743)
            
            static $H = 2621447;
            static $h = 2621447;
            static $g = 1;
            static $f = 0b1010001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4297588743),
    {
      "r": T?.$h??1572864,
      "p": [
        {
          "n": "e",
          "p": 80805889
        }
      ],
      "n": "ConvertToUnmanaged",
      "d": this.$h,
      "H": 4297588743,
      "h": Number(BigInt(this.$h)|0x100000000n),
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(4297588743)
  ],
  "s": [
    {
      "h": T?.$h??1572864,
      "n": "T",
      "f": 10,
      "c": [$.$$.SN$1.IFloatingPointIeee754$$(T).$h
      ]
    }
  ],
  "r": 1,
  "H": 2621447,
  "h": this.$h,
  "a": [
    {
      "t": 145096705,
      "c": 17324965889,
      "a": [
        {
          "v": 80805889,
          "t": 188547073
        },
        {
          "v": 6,
          "t": 145227777
        },
        {
          "v": 2621447,
          "t": 188547073
        }
      ]
    }
  ]
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `System.Runtime.InteropServices.Marshalling.ExceptionAsNaNMarshaller<${T?.$fullName}>`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `System${separator}Runtime${separator}InteropServices${separator}Marshalling${separator}ExceptionAsNaNMarshaller$${T?.$getFullName(separator)}$`; }
        }));
        //--TRIMMABLE-BOUNDARY-END(2621447)
        
        

        //--TRIMMABLE-BOUNDARY-START(3670023)
        $asm.$cls(`$sris.SRIM.UniqueComInterfaceMarshaller<>`, (T) => $asm.$gt(`$sris.SRIM.UniqueComInterfaceMarshaller<>`, [T], ($self) => class UniqueComInterfaceMarshaller$$
        {
            //--TRIMMABLE-BOUNDARY-START(8593604615)
            static /*void* */ ConvertToUnmanaged(/*T?*/ managed)
            {
                /*nint*/ let unknown;
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8593604615);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (managed === null)
                {
                    return null;
                }
                if (!$.$$.SRI.ComWrappers.TryGetComInstance($.$box(managed, T), $.$ref(() => unknown, ($v) => unknown = $v, $.$$.S.IntPtr)))
                {
                    unknown = $.$sris.SRIM.StrategyBasedComWrappers.DefaultMarshallingInstance.GetOrCreateComInterfaceForObject($.$box(managed, T), 0/*CreateComInterfaceFlags.None*/);
                }
                return $.$sris.SRIM.ComInterfaceMarshaller$$(T).CastIUnknownToInterfaceType(unknown);
            }
            //--TRIMMABLE-BOUNDARY-END(8593604615)
            
            //--TRIMMABLE-BOUNDARY-START(4298637319)
            static /*T? */ ConvertToManaged(/*void**/ unmanaged)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4298637319);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (unmanaged === null)
                {
                    return $.$default(T);
                }
                return $.$cast($.$sris.SRIM.StrategyBasedComWrappers.DefaultMarshallingInstance.GetOrCreateObjectForComInstance$1($.$$.$interop.$ptr2Addr(unmanaged), 2/*CreateObjectFlags.UniqueInstance*/), T);
            }
            //--TRIMMABLE-BOUNDARY-END(4298637319)
            
            //--TRIMMABLE-BOUNDARY-START(12888571911)
            static /*void */ Free(/*void**/ unmanaged)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12888571911);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (unmanaged !== null)
                {
                    $.$$.SRI.Marshal.Release($.$$.$interop.$ptr2Addr(unmanaged));
                }
            }
            //--TRIMMABLE-BOUNDARY-END(12888571911)
            
            static $H = 3670023;
            static $h = 3670023;
            static $g = 1;
            static $f = 0b1010001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8593604615),
    {
      "r": $.$typePointer($.$$.S.Void).$h,
      "p": [
        {
          "n": "managed",
          "p": T?.$h??1572864
        }
      ],
      "n": "ConvertToUnmanaged",
      "d": this.$h,
      "H": 8593604615,
      "h": Number(BigInt(this.$h)|0x200000000n),
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8593604615),
//--TRIMMABLE-BOUNDARY-START(4298637319),
    {
      "r": T?.$h??1572864,
      "p": [
        {
          "n": "unmanaged",
          "p": $.$typePointer($.$$.S.Void).$h
        }
      ],
      "n": "ConvertToManaged",
      "d": this.$h,
      "H": 4298637319,
      "h": Number(BigInt(this.$h)|0x100000000n),
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(4298637319),
//--TRIMMABLE-BOUNDARY-START(12888571911),
    {
      "r": 65537,
      "p": [
        {
          "n": "unmanaged",
          "p": $.$typePointer($.$$.S.Void).$h
        }
      ],
      "n": "Free",
      "d": this.$h,
      "H": 12888571911,
      "h": Number(BigInt(this.$h)|0x300000000n),
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(12888571911)
  ],
  "s": [
    {
      "h": T?.$h??1572864,
      "n": "T"
    }
  ],
  "r": 1,
  "H": 3670023,
  "h": this.$h,
  "a": [
    {
      "t": 160169985,
      "c": 13045071873,
      "a": [
        {
          "v": "android",
          "t": 1310721
        }
      ]
    },
    {
      "t": 160169985,
      "c": 13045071873,
      "a": [
        {
          "v": "browser",
          "t": 1310721
        }
      ]
    },
    {
      "t": 160169985,
      "c": 13045071873,
      "a": [
        {
          "v": "ios",
          "t": 1310721
        }
      ]
    },
    {
      "t": 160169985,
      "c": 13045071873,
      "a": [
        {
          "v": "tvos",
          "t": 1310721
        }
      ]
    },
    {
      "t": 54984705,
      "c": 8644919297,
      "a": [
        {
          "v": false,
          "t": 262145
        }
      ]
    },
    {
      "t": 145096705,
      "c": 17324965889,
      "a": [
        {
          "v": 145162241,
          "t": 188547073
        },
        {
          "v": 0,
          "t": 145227777
        },
        {
          "v": 3670023,
          "t": 188547073
        }
      ]
    }
  ]
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `System.Runtime.InteropServices.Marshalling.UniqueComInterfaceMarshaller<${T?.$fullName}>`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `System${separator}Runtime${separator}InteropServices${separator}Marshalling${separator}UniqueComInterfaceMarshaller$${T?.$getFullName(separator)}$`; }
        }));
        //--TRIMMABLE-BOUNDARY-END(3670023)
        
        

        //--TRIMMABLE-BOUNDARY-START(4587527)
        $asm.$cls(`$sris.SS.SecureStringMarshal`, ($self) => class SecureStringMarshal
        {
            //--TRIMMABLE-BOUNDARY-START(4299554823)
            static /*IntPtr */ SecureStringToCoTaskMemAnsi(/*SecureString*/ s)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4299554823);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return $.$$.SRI.Marshal.SecureStringToCoTaskMemAnsi(s);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(4299554823)
            
            //--TRIMMABLE-BOUNDARY-START(12889489415)
            static /*IntPtr */ SecureStringToGlobalAllocAnsi(/*SecureString*/ s)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(12889489415);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return $.$$.SRI.Marshal.SecureStringToGlobalAllocAnsi(s);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(12889489415)
            
            //--TRIMMABLE-BOUNDARY-START(8594522119)
            static /*IntPtr */ SecureStringToCoTaskMemUnicode(/*SecureString*/ s)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(8594522119);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return $.$$.SRI.Marshal.SecureStringToCoTaskMemUnicode(s);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(8594522119)
            
            //--TRIMMABLE-BOUNDARY-START(17184456711)
            static /*IntPtr */ SecureStringToGlobalAllocUnicode(/*SecureString*/ s)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(17184456711);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return $.$$.SRI.Marshal.SecureStringToGlobalAllocUnicode(s);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(17184456711)
            
            static $h = 4587527;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4299554823),
    {
      "r": 786433,
      "p": [
        {
          "n": "s",
          "p": 162201601
        }
      ],
      "n": "SecureStringToCoTaskMemAnsi",
      "d": 4587527,
      "h": 4299554823,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(4299554823),
//--TRIMMABLE-BOUNDARY-START(12889489415),
    {
      "r": 786433,
      "p": [
        {
          "n": "s",
          "p": 162201601
        }
      ],
      "n": "SecureStringToGlobalAllocAnsi",
      "d": 4587527,
      "h": 12889489415,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(12889489415),
//--TRIMMABLE-BOUNDARY-START(8594522119),
    {
      "r": 786433,
      "p": [
        {
          "n": "s",
          "p": 162201601
        }
      ],
      "n": "SecureStringToCoTaskMemUnicode",
      "d": 4587527,
      "h": 8594522119,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8594522119),
//--TRIMMABLE-BOUNDARY-START(17184456711),
    {
      "r": 786433,
      "p": [
        {
          "n": "s",
          "p": 162201601
        }
      ],
      "n": "SecureStringToGlobalAllocUnicode",
      "d": 4587527,
      "h": 17184456711,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(17184456711)
  ],
  "h": 4587527
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `System.Security.SecureStringMarshal`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `System${separator}Security${separator}SecureStringMarshal`; }
        });
        //--TRIMMABLE-BOUNDARY-END(4587527)
        
        

        //--TRIMMABLE-BOUNDARY-START(2490375)
        $asm.$cls(`$sris.SRIM.ExceptionAsDefaultMarshaller<>`, (T) => $asm.$gt(`$sris.SRIM.ExceptionAsDefaultMarshaller<>`, [T], ($self) => class ExceptionAsDefaultMarshaller$$
        {
            //--TRIMMABLE-BOUNDARY-START(4297457671)
            static /*T */ ConvertToUnmanaged(/*Exception*/ e)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4297457671);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                _ = $.$$.SRI.Marshal.GetHRForException(e);
                return $.$default(T);
            }
            //--TRIMMABLE-BOUNDARY-END(4297457671)
            
            static $H = 2490375;
            static $h = 2490375;
            static $g = 1;
            static $f = 0b1010001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4297457671),
    {
      "r": T?.$h??1572864,
      "p": [
        {
          "n": "e",
          "p": 80805889
        }
      ],
      "n": "ConvertToUnmanaged",
      "d": this.$h,
      "H": 4297457671,
      "h": Number(BigInt(this.$h)|0x100000000n),
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(4297457671)
  ],
  "s": [
    {
      "h": T?.$h??1572864,
      "n": "T",
      "f": 10
    }
  ],
  "r": 1,
  "H": 2490375,
  "h": this.$h,
  "a": [
    {
      "t": 145096705,
      "c": 17324965889,
      "a": [
        {
          "v": 80805889,
          "t": 188547073
        },
        {
          "v": 6,
          "t": 145227777
        },
        {
          "v": 2490375,
          "t": 188547073
        }
      ]
    }
  ]
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `System.Runtime.InteropServices.Marshalling.ExceptionAsDefaultMarshaller<${T?.$fullName}>`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `System${separator}Runtime${separator}InteropServices${separator}Marshalling${separator}ExceptionAsDefaultMarshaller$${T?.$getFullName(separator)}$`; }
        }));
        //--TRIMMABLE-BOUNDARY-END(2490375)
        
        

        //--TRIMMABLE-BOUNDARY-START(2555911)
        $asm.$cls(`$sris.SRIM.ExceptionAsHResultMarshaller<>`, (T) => $asm.$gt(`$sris.SRIM.ExceptionAsHResultMarshaller<>`, [T], ($self) => class ExceptionAsHResultMarshaller$$
        {
            //--TRIMMABLE-BOUNDARY-START(4297523207)
            static /*T */ ConvertToUnmanaged(/*Exception*/ e)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4297523207);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return T.SN$1$INumberBase$$$CreateTruncating($.$$.S.Int32, $.$$.SRI.Marshal.GetHRForException(e));
            }
            //--TRIMMABLE-BOUNDARY-END(4297523207)
            
            static $H = 2555911;
            static $h = 2555911;
            static $g = 1;
            static $f = 0b1010001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4297523207),
    {
      "r": T?.$h??1572864,
      "p": [
        {
          "n": "e",
          "p": 80805889
        }
      ],
      "n": "ConvertToUnmanaged",
      "d": this.$h,
      "H": 4297523207,
      "h": Number(BigInt(this.$h)|0x100000000n),
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(4297523207)
  ],
  "s": [
    {
      "h": T?.$h??1572864,
      "n": "T",
      "f": 10,
      "c": [$.$$.SN$1.INumber$$(T).$h
      ]
    }
  ],
  "r": 1,
  "H": 2555911,
  "h": this.$h,
  "a": [
    {
      "t": 145096705,
      "c": 17324965889,
      "a": [
        {
          "v": 80805889,
          "t": 188547073
        },
        {
          "v": 6,
          "t": 145227777
        },
        {
          "v": 2555911,
          "t": 188547073
        }
      ]
    }
  ]
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `System.Runtime.InteropServices.Marshalling.ExceptionAsHResultMarshaller<${T?.$fullName}>`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `System${separator}Runtime${separator}InteropServices${separator}Marshalling${separator}ExceptionAsHResultMarshaller$${T?.$getFullName(separator)}$`; }
        }));
        //--TRIMMABLE-BOUNDARY-END(2555911)
        
        

        //--TRIMMABLE-BOUNDARY-START(4653063)
        $asm.$cls(`$sris.S.SR`, ($self) => class SR
        {
            //--TRIMMABLE-BOUNDARY-START(369371840519)
            /*bool*/ static s_usingResourceKeys = false;
            //--TRIMMABLE-BOUNDARY-END(369371840519)
            
            //--TRIMMABLE-BOUNDARY-START(300652363783)
            static /*bool */ GetUsingResourceKeysSwitchValue()
            {
                {
                    /*bool*/ let usingResourceKeys;
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(300652363783);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return $.$$.S.AppContext.TryGetSwitch("System.Resources.UseSystemResourceKeys", $.$ref(() => usingResourceKeys, ($v) => usingResourceKeys = $v, $.$$.S.Boolean)) ? usingResourceKeys : false;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(300652363783)
            
            //--TRIMMABLE-BOUNDARY-START(390846676999)
            static /*bool */ UsingResourceKeys()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(390846676999);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return $.$sris.S.SR.s_usingResourceKeys;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(390846676999)
            
            //--TRIMMABLE-BOUNDARY-START(296357396487)
            static /*string */ GetResourceString$1(/*string*/ resourceKey)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(296357396487);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$sris.S.SR.UsingResourceKeys())
                {
                    return resourceKey;
                }
                /*string?*/ let resourceString = null;
                try
                {
                    resourceString = $.$sris.S.SR.ResourceManager.GetString$1(resourceKey);
                }
                catch($e)
                {
                }
                return resourceString;
            }
            //--TRIMMABLE-BOUNDARY-END(296357396487)
            
            //--TRIMMABLE-BOUNDARY-START(292062429191)
            static /*string */ GetResourceString(/*string*/ resourceKey, /*string*/ defaultString)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(292062429191);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*string*/ let resourceString = $.$sris.S.SR.GetResourceString$1(resourceKey);
                return resourceKey === resourceString || resourceString === null ? defaultString : resourceString;
            }
            //--TRIMMABLE-BOUNDARY-END(292062429191)
            
            //--TRIMMABLE-BOUNDARY-START(64429162503)
            static /*string */ Format$6(/*string*/ resourceFormat, /*object?*/ p1)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(64429162503);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$sris.S.SR.UsingResourceKeys())
                {
                    return $.$$.S.String.Join$7(", ", $.$$.S.ReadOnlySpan$$($.$$.S.Object).op_Implicit$1([ resourceFormat, p1 ]));
                }
                return $.$$.S.String.Format$9(resourceFormat, p1);
            }
            //--TRIMMABLE-BOUNDARY-END(64429162503)
            
            //--TRIMMABLE-BOUNDARY-START(60134195207)
            static /*string */ Format$5(/*string*/ resourceFormat, /*object?*/ p1, /*object?*/ p2)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(60134195207);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$sris.S.SR.UsingResourceKeys())
                {
                    return $.$$.S.String.Join$7(", ", $.$$.S.ReadOnlySpan$$($.$$.S.Object).op_Implicit$1([ resourceFormat, p1, p2 ]));
                }
                return $.$$.S.String.Format$8(resourceFormat, p1, p2);
            }
            //--TRIMMABLE-BOUNDARY-END(60134195207)
            
            //--TRIMMABLE-BOUNDARY-START(55839227911)
            static /*string */ Format$4(/*string*/ resourceFormat, /*object?*/ p1, /*object?*/ p2, /*object?*/ p3)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(55839227911);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$sris.S.SR.UsingResourceKeys())
                {
                    return $.$$.S.String.Join$7(", ", $.$$.S.ReadOnlySpan$$($.$$.S.Object).op_Implicit$1([ resourceFormat, p1, p2, p3 ]));
                }
                return $.$$.S.String.Format$7(resourceFormat, p1, p2, p3);
            }
            //--TRIMMABLE-BOUNDARY-END(55839227911)
            
            //--TRIMMABLE-BOUNDARY-START(68724129799)
            static /*string */ Format$7(/*string*/ resourceFormat, /*params object?[]?*/ args)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(68724129799);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (args !== null)
                {
                    if ($.$sris.S.SR.UsingResourceKeys())
                    {
                        return $.$strNN(resourceFormat) + ", " + $.$strNN($.$$.S.String.Join$6(", ", args));
                    }
                    return $.$$.S.String.Format$10(resourceFormat, args);
                }
                return resourceFormat;
            }
            //--TRIMMABLE-BOUNDARY-END(68724129799)
            
            //--TRIMMABLE-BOUNDARY-START(47249293319)
            static /*string */ Format$2(/*IFormatProvider?*/ provider, /*string*/ resourceFormat, /*object?*/ p1)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(47249293319);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$sris.S.SR.UsingResourceKeys())
                {
                    return $.$$.S.String.Join$7(", ", $.$$.S.ReadOnlySpan$$($.$$.S.Object).op_Implicit$1([ resourceFormat, p1 ]));
                }
                return $.$$.S.String.Format$4(provider, resourceFormat, p1);
            }
            //--TRIMMABLE-BOUNDARY-END(47249293319)
            
            //--TRIMMABLE-BOUNDARY-START(42954326023)
            static /*string */ Format$1(/*IFormatProvider?*/ provider, /*string*/ resourceFormat, /*object?*/ p1, /*object?*/ p2)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(42954326023);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$sris.S.SR.UsingResourceKeys())
                {
                    return $.$$.S.String.Join$7(", ", $.$$.S.ReadOnlySpan$$($.$$.S.Object).op_Implicit$1([ resourceFormat, p1, p2 ]));
                }
                return $.$$.S.String.Format$3(provider, resourceFormat, p1, p2);
            }
            //--TRIMMABLE-BOUNDARY-END(42954326023)
            
            //--TRIMMABLE-BOUNDARY-START(38659358727)
            static /*string */ Format(/*IFormatProvider?*/ provider, /*string*/ resourceFormat, /*object?*/ p1, /*object?*/ p2, /*object?*/ p3)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(38659358727);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$sris.S.SR.UsingResourceKeys())
                {
                    return $.$$.S.String.Join$7(", ", $.$$.S.ReadOnlySpan$$($.$$.S.Object).op_Implicit$1([ resourceFormat, p1, p2, p3 ]));
                }
                return $.$$.S.String.Format$2(provider, resourceFormat, p1, p2, p3);
            }
            //--TRIMMABLE-BOUNDARY-END(38659358727)
            
            //--TRIMMABLE-BOUNDARY-START(51544260615)
            static /*string */ Format$3(/*IFormatProvider?*/ provider, /*string*/ resourceFormat, /*params object?[]?*/ args)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(51544260615);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (args !== null)
                {
                    if ($.$sris.S.SR.UsingResourceKeys())
                    {
                        return $.$strNN(resourceFormat) + ", " + $.$strNN($.$$.S.String.Join$6(", ", args));
                    }
                    return $.$$.S.String.Format$5(provider, resourceFormat, args);
                }
                return resourceFormat;
            }
            //--TRIMMABLE-BOUNDARY-END(51544260615)
            
            //--TRIMMABLE-BOUNDARY-START(365076873223)
            /*global::System.Resources.ResourceManager*/ static s_resourceManager = null;
            //--TRIMMABLE-BOUNDARY-END(365076873223)
            
            //--TRIMMABLE-BOUNDARY-START(356486938631)
            /*global::System.Globalization.CultureInfo*/ static resourceCulture = null;
            //--TRIMMABLE-BOUNDARY-END(356486938631)
            
            //--TRIMMABLE-BOUNDARY-START(360781905927)
            static /*global::System.Resources.ResourceManager */ get ResourceManager()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(270587592711);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$$.S.Object.ReferenceEquals($.$sris.S.SR.s_resourceManager, null))
                {
                    /*global::System.Resources.ResourceManager*/ let temp = new $.$$.SR$1.ResourceManager().$ctor$3("System.Runtime.InteropServices", $.$sris.S.SR.$type.Assembly);
                    $.$sris.S.SR.s_resourceManager = temp;
                }
                return $.$sris.S.SR.s_resourceManager;
            }
            //--TRIMMABLE-BOUNDARY-END(360781905927)
            
            //--TRIMMABLE-BOUNDARY-START(34364391431)
            static /*global::System.Globalization.CultureInfo */ get Culture()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(158918443015);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$sris.S.SR.resourceCulture;
            }
            static /*global::System.Globalization.CultureInfo */ set Culture(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(377961775111);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$sris.S.SR.resourceCulture = value;
            }
            //--TRIMMABLE-BOUNDARY-END(34364391431)
            
            //--TRIMMABLE-BOUNDARY-START(304947331079)
            static /*string */ get InvalidOperation_HCCountOverflow()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(167508377607);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "Handle collector count overflows or underflows.";
            }
            //--TRIMMABLE-BOUNDARY-END(304947331079)
            
            //--TRIMMABLE-BOUNDARY-START(17184522247)
            static /*string */ get Arg_NeedNonNegNumRequired()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(124558704647);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "Non-negative number required.";
            }
            //--TRIMMABLE-BOUNDARY-END(17184522247)
            
            //--TRIMMABLE-BOUNDARY-START(12889554951)
            static /*string */ get Arg_InvalidThreshold()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(115968770055);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "maximumThreshold cannot be less than initialThreshold.";
            }
            //--TRIMMABLE-BOUNDARY-END(12889554951)
            
            //--TRIMMABLE-BOUNDARY-START(309242298375)
            static /*string */ get InvalidOperation_NoComEventInterfaceAttribute()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(176098312199);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "Event invocation for COM objects requires the declaring interface of the event to be attributed with ComEventInterfaceAttribute.";
            }
            //--TRIMMABLE-BOUNDARY-END(309242298375)
            
            //--TRIMMABLE-BOUNDARY-START(8594587655)
            static /*string */ get AmbiguousMatch_MultipleEventInterfaceAttributes()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(107378835463);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "More than one ComEventInterfaceAttribute found for '{0}' on the declaring interface of the event.";
            }
            //--TRIMMABLE-BOUNDARY-END(8594587655)
            
            //--TRIMMABLE-BOUNDARY-START(73019097095)
            static /*string */ FormatAmbiguousMatch_MultipleEventInterfaceAttributes(/*object*/ arg1)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(73019097095);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$$.S.String.Format$9("More than one ComEventInterfaceAttribute found for '{0}' on the declaring interface of the event.", arg1);
            }
            //--TRIMMABLE-BOUNDARY-END(73019097095)
            
            //--TRIMMABLE-BOUNDARY-START(313537265671)
            static /*string */ get InvalidOperation_NoDispIdAttribute()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(184688246791);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "Event invocation for COM objects requires event to be attributed with DispIdAttribute.";
            }
            //--TRIMMABLE-BOUNDARY-END(313537265671)
            
            //--TRIMMABLE-BOUNDARY-START(317832232967)
            static /*string */ get IO_FileExists_Name()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(193278181383);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "The file '{0}' already exists.";
            }
            //--TRIMMABLE-BOUNDARY-END(317832232967)
            
            //--TRIMMABLE-BOUNDARY-START(77314064391)
            static /*string */ FormatIO_FileExists_Name(/*object*/ arg1)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(77314064391);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$$.S.String.Format$9("The file '{0}' already exists.", arg1);
            }
            //--TRIMMABLE-BOUNDARY-END(77314064391)
            
            //--TRIMMABLE-BOUNDARY-START(322127200263)
            static /*string */ get IO_FileNotFound()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(210458050567);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "Unable to find the specified file.";
            }
            //--TRIMMABLE-BOUNDARY-END(322127200263)
            
            //--TRIMMABLE-BOUNDARY-START(326422167559)
            static /*string */ get IO_FileNotFound_FileName()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(201868115975);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "Could not find file '{0}'.";
            }
            //--TRIMMABLE-BOUNDARY-END(326422167559)
            
            //--TRIMMABLE-BOUNDARY-START(81609031687)
            static /*string */ FormatIO_FileNotFound_FileName(/*object*/ arg1)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(81609031687);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$$.S.String.Format$9("Could not find file '{0}'.", arg1);
            }
            //--TRIMMABLE-BOUNDARY-END(81609031687)
            
            //--TRIMMABLE-BOUNDARY-START(330717134855)
            static /*string */ get IO_PathNotFound_NoPathName()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(219047985159);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "Could not find a part of the path.";
            }
            //--TRIMMABLE-BOUNDARY-END(330717134855)
            
            //--TRIMMABLE-BOUNDARY-START(335012102151)
            static /*string */ get IO_PathNotFound_Path()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(227637919751);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "Could not find a part of the path '{0}'.";
            }
            //--TRIMMABLE-BOUNDARY-END(335012102151)
            
            //--TRIMMABLE-BOUNDARY-START(85903998983)
            static /*string */ FormatIO_PathNotFound_Path(/*object*/ arg1)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(85903998983);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$$.S.String.Format$9("Could not find a part of the path '{0}'.", arg1);
            }
            //--TRIMMABLE-BOUNDARY-END(85903998983)
            
            //--TRIMMABLE-BOUNDARY-START(339307069447)
            static /*string */ get IO_PathTooLong()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(244817788935);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "The specified file name or path is too long, or a component of the specified path is too long.";
            }
            //--TRIMMABLE-BOUNDARY-END(339307069447)
            
            //--TRIMMABLE-BOUNDARY-START(347897004039)
            static /*string */ get IO_SharingViolation_File()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(253407723527);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "The process cannot access the file '{0}' because it is being used by another process.";
            }
            //--TRIMMABLE-BOUNDARY-END(347897004039)
            
            //--TRIMMABLE-BOUNDARY-START(94493933575)
            static /*string */ FormatIO_SharingViolation_File(/*object*/ arg1)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(94493933575);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$$.S.String.Format$9("The process cannot access the file '{0}' because it is being used by another process.", arg1);
            }
            //--TRIMMABLE-BOUNDARY-END(94493933575)
            
            //--TRIMMABLE-BOUNDARY-START(352191971335)
            static /*string */ get IO_SharingViolation_NoFileName()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(261997658119);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "The process cannot access the file because it is being used by another process.";
            }
            //--TRIMMABLE-BOUNDARY-END(352191971335)
            
            //--TRIMMABLE-BOUNDARY-START(343602036743)
            static /*string */ get IO_PathTooLong_Path()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(236227854343);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "The path '{0}' is too long, or a component of the specified path is too long.";
            }
            //--TRIMMABLE-BOUNDARY-END(343602036743)
            
            //--TRIMMABLE-BOUNDARY-START(90198966279)
            static /*string */ FormatIO_PathTooLong_Path(/*object*/ arg1)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(90198966279);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$$.S.String.Format$9("The path '{0}' is too long, or a component of the specified path is too long.", arg1);
            }
            //--TRIMMABLE-BOUNDARY-END(90198966279)
            
            //--TRIMMABLE-BOUNDARY-START(386551709703)
            static /*string */ get UnauthorizedAccess_IODenied_Path()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(287767461895);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "Access to the path '{0}' is denied.";
            }
            //--TRIMMABLE-BOUNDARY-END(386551709703)
            
            //--TRIMMABLE-BOUNDARY-START(98788900871)
            static /*string */ FormatUnauthorizedAccess_IODenied_Path(/*object*/ arg1)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(98788900871);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$$.S.String.Format$9("Access to the path '{0}' is denied.", arg1);
            }
            //--TRIMMABLE-BOUNDARY-END(98788900871)
            
            //--TRIMMABLE-BOUNDARY-START(382256742407)
            static /*string */ get UnauthorizedAccess_IODenied_NoPathName()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(279177527303);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "Access to the path is denied.";
            }
            //--TRIMMABLE-BOUNDARY-END(382256742407)
            
            //--TRIMMABLE-BOUNDARY-START(21479489543)
            static /*string */ get ArgumentOutOfRange_FileLengthTooBig()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(133148639239);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "Specified file length was too large for the file system.";
            }
            //--TRIMMABLE-BOUNDARY-END(21479489543)
            
            //--TRIMMABLE-BOUNDARY-START(25774456839)
            static /*string */ get ComVariantMarshaller_ManagedTypeNotSupported()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(141738573831);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "Type of managed object is not supported for marshalling as ComVariant.";
            }
            //--TRIMMABLE-BOUNDARY-END(25774456839)
            
            //--TRIMMABLE-BOUNDARY-START(30069424135)
            static /*string */ get ComVariantMarshaller_UnmanagedTypeNotSupported()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(150328508423);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "Type of unmanaged variant is not supported for marshalling to a managed object.";
            }
            //--TRIMMABLE-BOUNDARY-END(30069424135)
            
            //--TRIMMABLE-BOUNDARY-START(4299620359)
            //Static Initializer
            static $sinit()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4299620359);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                {
                    //--TRIMMABLE-BOUNDARY-START(369371840519)
                    this.s_usingResourceKeys = $.$sris.S.SR.GetUsingResourceKeysSwitchValue();
                    //--TRIMMABLE-BOUNDARY-END(369371840519)
                    
                }
            }
            //--TRIMMABLE-BOUNDARY-END(4299620359)
            
            static $h = 4653063;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "h": 4653063
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `System.SR`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `System${separator}SR`; }
        });
        //--TRIMMABLE-BOUNDARY-END(4653063)
        
        

        //--TRIMMABLE-BOUNDARY-START(2228231)
        $asm.$cls(`$sris.SRIM.ComVariantMarshaller`, ($self) => class ComVariantMarshaller
        {
            //--TRIMMABLE-BOUNDARY-START(25772032007)
            /*short*/ static VARIANT_TRUE = -1;
            //--TRIMMABLE-BOUNDARY-END(25772032007)
            
            //--TRIMMABLE-BOUNDARY-START(21477064711)
            /*short*/ static VARIANT_FALSE = 0;
            //--TRIMMABLE-BOUNDARY-END(21477064711)
            
            //--TRIMMABLE-BOUNDARY-START(8592162823)
            static /*ComVariant */ ConvertToUnmanaged(/*object?*/ managed)
            {
                /*ComVariant*/ let variant;
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8592162823);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (managed === null)
                {
                    return new $.$$.SRIM.ComVariant();
                }
                //switch (managed)
                {
                    let s;
                    let b;
                    let i;
                    let l;
                    let f;
                    let d;
                    let dt;
                    let errorWrapper;
                    let currencyWrapper;
                    let bStrWrapper;
                    $switchJumpStart1: 
                    //case sbyte s:
                    if ($.$is(managed, $.$$.S.SByte, { set $v(v){ s = v; } }))
                    {
                        return $.$$.SRIM.ComVariant.Create($.$$.S.SByte, s);
                    }
                    //case byte b:
                    else if ($.$is(managed, $.$$.S.Byte, { set $v(v){ b = v; } }))
                    {
                        return $.$$.SRIM.ComVariant.Create($.$$.S.Byte, b);
                    }
                    //case short s:
                    else if ($.$is(managed, $.$$.S.Int16, { set $v(v){ s = v; } }))
                    {
                        return $.$$.SRIM.ComVariant.Create($.$$.S.Int16, s);
                    }
                    //case ushort s:
                    else if ($.$is(managed, $.$$.S.UInt16, { set $v(v){ s = v; } }))
                    {
                        return $.$$.SRIM.ComVariant.Create($.$$.S.UInt16, s);
                    }
                    //case int i:
                    else if ($.$is(managed, $.$$.S.Int32, { set $v(v){ i = v; } }))
                    {
                        return $.$$.SRIM.ComVariant.Create($.$$.S.Int32, i);
                    }
                    //case uint i:
                    else if ($.$is(managed, $.$$.S.UInt32, { set $v(v){ i = v; } }))
                    {
                        return $.$$.SRIM.ComVariant.Create($.$$.S.UInt32, i);
                    }
                    //case long l:
                    else if ($.$is(managed, $.$$.S.Int64, { set $v(v){ l = v; } }))
                    {
                        return $.$$.SRIM.ComVariant.Create($.$$.S.Int64, l);
                    }
                    //case ulong l:
                    else if ($.$is(managed, $.$$.S.UInt64, { set $v(v){ l = v; } }))
                    {
                        return $.$$.SRIM.ComVariant.Create($.$$.S.UInt64, l);
                    }
                    //case float f:
                    else if ($.$is(managed, $.$$.S.Single, { set $v(v){ f = v; } }))
                    {
                        return $.$$.SRIM.ComVariant.Create($.$$.S.Single, f);
                    }
                    //case double d:
                    else if ($.$is(managed, $.$$.S.Double, { set $v(v){ d = v; } }))
                    {
                        return $.$$.SRIM.ComVariant.Create($.$$.S.Double, d);
                    }
                    //case decimal d:
                    else if ($.$is(managed, $.$$.S.Decimal, { set $v(v){ d = v; } }))
                    {
                        return $.$$.SRIM.ComVariant.Create($.$$.S.Decimal, d);
                    }
                    //case bool b:
                    else if ($.$is(managed, $.$$.S.Boolean, { set $v(v){ b = v; } }))
                    {
                        return $.$$.SRIM.ComVariant.Create($.$$.S.Boolean, b);
                    }
                    //case string s:
                    else if ($.$is(managed, $.$$.S.String, { set $v(v){ s = v; } }))
                    {
                        return $.$$.SRIM.ComVariant.Create($.$$.S.String, s);
                    }
                    //case DateTime dt:
                    else if ($.$is(managed, $.$$.S.DateTime, { set $v(v){ dt = v; } }))
                    {
                        return $.$$.SRIM.ComVariant.Create($.$$.S.DateTime, dt);
                    }
                    //case ErrorWrapper errorWrapper:
                    else if ($.$is(managed, $.$$.SRI.ErrorWrapper, { set $v(v){ errorWrapper = v; } }))
                    {
                        return $.$$.SRIM.ComVariant.Create($.$$.SRI.ErrorWrapper, errorWrapper);
                    }
                    //case CurrencyWrapper currencyWrapper:
                    else if ($.$is(managed, $.$$.SRI.CurrencyWrapper, { set $v(v){ currencyWrapper = v; } }))
                    {
                        return $.$$.SRIM.ComVariant.Create($.$$.SRI.CurrencyWrapper, currencyWrapper);
                    }
                    //case BStrWrapper bStrWrapper:
                    else if ($.$is(managed, $.$$.SRI.BStrWrapper, { set $v(v){ bStrWrapper = v; } }))
                    {
                        return $.$$.SRIM.ComVariant.Create($.$$.SRI.BStrWrapper, bStrWrapper);
                    }
                    //case DBNull:
                    else if (managed == $.$$.S.DBNull)
                    {
                        return $.$$.SRIM.ComVariant.Null;
                    }
                }
                if ($.$sris.SRIM.ComVariantMarshaller.TryCreateOleVariantForInterfaceWrapper(managed, $.$ref(() => variant, ($v) => variant = $v, $.$$.SRIM.ComVariant)))
                {
                    return variant;
                }
                throw new $.$$.S.ArgumentException().$ctor$13($.$sris.S.SR.ComVariantMarshaller_ManagedTypeNotSupported, "managed");
            }
            //--TRIMMABLE-BOUNDARY-END(8592162823)
            
            //--TRIMMABLE-BOUNDARY-START(17182097415)
            static /*bool */ TryCreateOleVariantForInterfaceWrapper(/*object*/ managed, /*out ComVariant*/ variant)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17182097415);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                let uw;
                if ($.$is(managed, $.$$.SRI.UnknownWrapper, { set $v($v){ uw = $v; } }))
                {
                    /*object?*/ let wrapped = uw.WrappedObject;
                    if (wrapped === null)
                    {
                        variant.$v = new $.$$.SRIM.ComVariant();
                        return true;
                    }
                    variant.$v = $.$$.SRIM.ComVariant.CreateRaw($.$$.S.IntPtr, 13/*VarEnum.VT_UNKNOWN*/, $.$sris.SRIM.StrategyBasedComWrappers.DefaultMarshallingInstance.GetOrCreateComInterfaceForObject(wrapped, 0/*CreateComInterfaceFlags.None*/));
                    return true;
                }
                else if (!(managed === null) && !($.$sris.SRIM.StrategyBasedComWrappers.DefaultIUnknownInterfaceDetailsStrategy.SRIM$IIUnknownInterfaceDetailsStrategy$GetComExposedTypeDetails($.$$.S.Object.GetType.call(managed).TypeHandle) === null))
                {
                    variant.$v = $.$$.SRIM.ComVariant.CreateRaw($.$$.S.IntPtr, 13/*VarEnum.VT_UNKNOWN*/, $.$sris.SRIM.StrategyBasedComWrappers.DefaultMarshallingInstance.GetOrCreateComInterfaceForObject(managed, 0/*CreateComInterfaceFlags.None*/));
                    return true;
                }
                variant.$v = new $.$$.SRIM.ComVariant();
                return false;
            }
            //--TRIMMABLE-BOUNDARY-END(17182097415)
            
            //--TRIMMABLE-BOUNDARY-START(4297195527)
            static /*object? */ ConvertToManaged(/*ComVariant*/ unmanaged)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4297195527);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                let $switch3 = unmanaged.VarType;
                switch($switch3)
                {
                    case 0/*VarEnum.VT_EMPTY*/:
                    case 16384/*VarEnum.VT_BYREF*/ | 0/*VarEnum.VT_EMPTY*/:
                    return null;
                    case 1/*VarEnum.VT_NULL*/:
                    case 16384/*VarEnum.VT_BYREF*/ | 1/*VarEnum.VT_NULL*/:
                    return $.$$.S.DBNull.Value;
                    case 16/*VarEnum.VT_I1*/:
                    return $.$box(unmanaged.As($.$$.S.SByte), $.$$.S.SByte);
                    case 17/*VarEnum.VT_UI1*/:
                    return $.$box(unmanaged.As($.$$.S.Byte), $.$$.S.Byte);
                    case 2/*VarEnum.VT_I2*/:
                    return $.$box(unmanaged.As($.$$.S.Int16), $.$$.S.Int16);
                    case 18/*VarEnum.VT_UI2*/:
                    return $.$box(unmanaged.As($.$$.S.UInt16), $.$$.S.UInt16);
                    case 22/*VarEnum.VT_INT*/:
                    case 3/*VarEnum.VT_I4*/:
                    return $.$box(unmanaged.As($.$$.S.Int32), $.$$.S.Int32);
                    case 23/*VarEnum.VT_UINT*/:
                    case 19/*VarEnum.VT_UI4*/:
                    return $.$box(unmanaged.As($.$$.S.UInt32), $.$$.S.UInt32);
                    case 20/*VarEnum.VT_I8*/:
                    return $.$box(unmanaged.As($.$$.S.Int64), $.$$.S.Int64);
                    case 21/*VarEnum.VT_UI8*/:
                    return $.$box(unmanaged.As($.$$.S.UInt64), $.$$.S.UInt64);
                    case 4/*VarEnum.VT_R4*/:
                    return $.$box(unmanaged.As($.$$.S.Single), $.$$.S.Single);
                    case 5/*VarEnum.VT_R8*/:
                    return $.$box(unmanaged.As($.$$.S.Double), $.$$.S.Double);
                    case 14/*VarEnum.VT_DECIMAL*/:
                    return unmanaged.As($.$$.S.Decimal);
                    case 11/*VarEnum.VT_BOOL*/:
                    return $.$box(unmanaged.As($.$$.S.Boolean), $.$$.S.Boolean);
                    case 8/*VarEnum.VT_BSTR*/:
                    return unmanaged.As($.$$.S.String);
                    case 7/*VarEnum.VT_DATE*/:
                    return unmanaged.As($.$$.S.DateTime);
                    case 10/*VarEnum.VT_ERROR*/:
                    return $.$box(unmanaged.As($.$$.S.Int32), $.$$.S.Int32);
                    case 6/*VarEnum.VT_CY*/:
                    return unmanaged.As($.$$.SRI.CurrencyWrapper).WrappedObject;
                    case 13/*VarEnum.VT_UNKNOWN*/:
                    case 9/*VarEnum.VT_DISPATCH*/:
                    return $.$sris.SRIM.StrategyBasedComWrappers.DefaultMarshallingInstance.GetOrCreateObjectForComInstance$1(unmanaged.GetRawDataRef($.$$.S.IntPtr).$v, 8/*CreateObjectFlags.Unwrap*/);
                    case 16384/*VarEnum.VT_BYREF*/ | 12/*VarEnum.VT_VARIANT*/:
                    return $.$sris.SRIM.ComVariantMarshaller.ConvertToManaged($.$$.$interop.castAddress2Object(unmanaged.GetRawDataRef($.$$.S.IntPtr).$v));
                    case 16384/*VarEnum.VT_BYREF*/ | 16/*VarEnum.VT_I1*/:
                    return $.$box($.$$.$interop.castAddress2Object(unmanaged.GetRawDataRef($.$$.S.IntPtr).$v), $.$$.S.SByte);
                    case 16384/*VarEnum.VT_BYREF*/ | 17/*VarEnum.VT_UI1*/:
                    return $.$box($.$$.$interop.castAddress2Object(unmanaged.GetRawDataRef($.$$.S.IntPtr).$v), $.$$.S.Byte);
                    case 16384/*VarEnum.VT_BYREF*/ | 2/*VarEnum.VT_I2*/:
                    return $.$box($.$$.$interop.castAddress2Object(unmanaged.GetRawDataRef($.$$.S.IntPtr).$v), $.$$.S.Int16);
                    case 16384/*VarEnum.VT_BYREF*/ | 18/*VarEnum.VT_UI2*/:
                    return $.$box($.$$.$interop.castAddress2Object(unmanaged.GetRawDataRef($.$$.S.IntPtr).$v), $.$$.S.UInt16);
                    case 16384/*VarEnum.VT_BYREF*/ | 3/*VarEnum.VT_I4*/:
                    return $.$box($.$$.$interop.castAddress2Object(unmanaged.GetRawDataRef($.$$.S.IntPtr).$v), $.$$.S.Int32);
                    case 16384/*VarEnum.VT_BYREF*/ | 19/*VarEnum.VT_UI4*/:
                    return $.$box($.$$.$interop.castAddress2Object(unmanaged.GetRawDataRef($.$$.S.IntPtr).$v), $.$$.S.UInt32);
                    case 16384/*VarEnum.VT_BYREF*/ | 20/*VarEnum.VT_I8*/:
                    return $.$box($.$$.$interop.castAddress2Object(unmanaged.GetRawDataRef($.$$.S.IntPtr).$v), $.$$.S.Int64);
                    case 16384/*VarEnum.VT_BYREF*/ | 21/*VarEnum.VT_UI8*/:
                    return $.$box($.$$.$interop.castAddress2Object(unmanaged.GetRawDataRef($.$$.S.IntPtr).$v), $.$$.S.UInt64);
                    case 16384/*VarEnum.VT_BYREF*/ | 4/*VarEnum.VT_R4*/:
                    return $.$box($.$$.$interop.castAddress2Object(unmanaged.GetRawDataRef($.$$.S.IntPtr).$v), $.$$.S.Single);
                    case 16384/*VarEnum.VT_BYREF*/ | 5/*VarEnum.VT_R8*/:
                    return $.$box($.$$.$interop.castAddress2Object(unmanaged.GetRawDataRef($.$$.S.IntPtr).$v), $.$$.S.Double);
                    case 16384/*VarEnum.VT_BYREF*/ | 14/*VarEnum.VT_DECIMAL*/:
                    return $.$$.$interop.castAddress2Object(unmanaged.GetRawDataRef($.$$.S.IntPtr).$v);
                    case 16384/*VarEnum.VT_BYREF*/ | 11/*VarEnum.VT_BOOL*/:
                    return $.$box($.$$.$interop.castAddress2Object(unmanaged.GetRawDataRef($.$$.S.IntPtr).$v) !== 0/*VARIANT_FALSE*/, $.$$.S.Boolean);
                    case 16384/*VarEnum.VT_BYREF*/ | 8/*VarEnum.VT_BSTR*/:
                    return $.$$.SRI.Marshal.PtrToStringBSTR($.$$.$interop.castAddress2Object(unmanaged.GetRawDataRef($.$$.S.IntPtr).$v));
                    case 16384/*VarEnum.VT_BYREF*/ | 7/*VarEnum.VT_DATE*/:
                    return $.$$.S.DateTime.FromOADate($.$$.$interop.castAddress2Object(unmanaged.GetRawDataRef($.$$.S.IntPtr).$v));
                    case 16384/*VarEnum.VT_BYREF*/ | 10/*VarEnum.VT_ERROR*/:
                    return $.$box($.$$.$interop.castAddress2Object(unmanaged.GetRawDataRef($.$$.S.IntPtr).$v), $.$$.S.Int32);
                    case 16384/*VarEnum.VT_BYREF*/ | 6/*VarEnum.VT_CY*/:
                    return $.$$.S.Decimal.FromOACurrency($.$$.$interop.castAddress2Object(unmanaged.GetRawDataRef($.$$.S.IntPtr).$v));
                    case 16384/*VarEnum.VT_BYREF*/ | 13/*VarEnum.VT_UNKNOWN*/:
                    return $.$sris.SRIM.StrategyBasedComWrappers.DefaultMarshallingInstance.GetOrCreateObjectForComInstance$1($.$$.$interop.castAddress2Object(unmanaged.GetRawDataRef($.$$.S.IntPtr).$v), 8/*CreateObjectFlags.Unwrap*/);
                    default:
                    throw new $.$$.S.ArgumentException().$ctor$13($.$sris.S.SR.ComVariantMarshaller_UnmanagedTypeNotSupported, "unmanaged");
                }
            }
            //--TRIMMABLE-BOUNDARY-END(4297195527)
            
            //--TRIMMABLE-BOUNDARY-START(12887130119)
            static /*void */ Free(/*ComVariant*/ unmanaged)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(12887130119);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return unmanaged.Dispose();
                }
            }
            //--TRIMMABLE-BOUNDARY-END(12887130119)
            
            //--TRIMMABLE-BOUNDARY-START(2293767)
            static $_RefPropagate;
            static get RefPropagate()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(2293767);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                let $cls = $.$sris.SRIM.ComVariantMarshaller;
                return $cls.$_RefPropagate ??= $asm.$nstr(`$sris.SRIM.ComVariantMarshaller.RefPropagate`, ($self) => class RefPropagate extends $.$$.S.ValueType
                {
                    //--TRIMMABLE-BOUNDARY-START(8592228359)
                    /*ComVariant*/ _unmanaged;
                    //--TRIMMABLE-BOUNDARY-END(8592228359)
                    
                    //--TRIMMABLE-BOUNDARY-START(4297261063)
                    /*object?*/ _managed = null;
                    //--TRIMMABLE-BOUNDARY-END(4297261063)
                    
                    //--TRIMMABLE-BOUNDARY-START(25772097543)
                    /*void */ FromUnmanaged(/*ComVariant*/ unmanaged)
                    {
                        {
                            //--TRIMMABLE-BOUNDARY-START(TRACE)
                            $.$trace(25772097543);
                            //--TRIMMABLE-BOUNDARY-END(TRACE)
                            return this._unmanaged = $.$clone(unmanaged);
                        }
                    }
                    //--TRIMMABLE-BOUNDARY-END(25772097543)
                    
                    //--TRIMMABLE-BOUNDARY-START(21477130247)
                    /*void */ FromManaged(/*object?*/ managed)
                    {
                        {
                            //--TRIMMABLE-BOUNDARY-START(TRACE)
                            $.$trace(21477130247);
                            //--TRIMMABLE-BOUNDARY-END(TRACE)
                            return this._managed = managed;
                        }
                    }
                    //--TRIMMABLE-BOUNDARY-END(21477130247)
                    
                    //--TRIMMABLE-BOUNDARY-START(34362032135)
                    /*ComVariant */ ToUnmanaged()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(34362032135);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        if (!((this._unmanaged.VarType & (16384/*VarEnum.VT_BYREF*/)) == (16384/*VarEnum.VT_BYREF*/)))
                        {
                            return $.$sris.SRIM.ComVariantMarshaller.ConvertToUnmanaged(this._managed);
                        }
                        if (this._managed === null && (((this._unmanaged.VarType & ~16384/*VarEnum.VT_BYREF*/) === 8/*VarEnum.VT_BSTR*/) || ((this._unmanaged.VarType & ~16384/*VarEnum.VT_BYREF*/) === 9/*VarEnum.VT_DISPATCH*/)) || ((this._unmanaged.VarType & ~16384/*VarEnum.VT_BYREF*/) === 13/*VarEnum.VT_UNKNOWN*/))
                        {
                            $.$$.$interop.castAddress2Object(this._unmanaged.GetRawDataRef($.$$.S.IntPtr).$v).$v = 0;
                            return $.$clone(this._unmanaged);
                        }
                        //switch ((_unmanaged.VarType & ~VarEnum.VT_BYREF, _managed))
                        let $switch5 = this._unmanaged.VarType & ~16384/*VarEnum.VT_BYREF*/;
                        let $switch6 = this._managed;
                        {
                            let s;
                            let b;
                            let u;
                            let i;
                            let l;
                            let ul;
                            let f;
                            let d;
                            let str;
                            let dt;
                            let error;
                            let cy;
                            let unkObj;
                            $switchJumpStart4: 
                            //case (VarEnum.VT_VARIANT, _):
                            if (($switch5 === 12/*VarEnum.VT_VARIANT*/))
                            {
                                $.$$.$interop.castAddress2Object(this._unmanaged.GetRawDataRef($.$$.S.IntPtr).$v).$v = $.$sris.SRIM.ComVariantMarshaller.ConvertToUnmanaged(this._managed);
                            }
                            //case (VarEnum.VT_I1 or VarEnum.VT_UI1, sbyte s):
                            else if ((($switch5 === 16/*VarEnum.VT_I1*/) || ($switch5 === 17/*VarEnum.VT_UI1*/)) && ($.$is($switch6, $.$$.S.SByte, { set $v(v){ s = v; } })))
                            {
                                $.$$.$interop.castAddress2Object(this._unmanaged.GetRawDataRef($.$$.S.IntPtr).$v).$v = s;
                            }
                            //case (VarEnum.VT_I1 or VarEnum.VT_UI1, byte b):
                            else if ((($switch5 === 16/*VarEnum.VT_I1*/) || ($switch5 === 17/*VarEnum.VT_UI1*/)) && ($.$is($switch6, $.$$.S.Byte, { set $v(v){ b = v; } })))
                            {
                                $.$$.$interop.castAddress2Object(this._unmanaged.GetRawDataRef($.$$.S.IntPtr).$v).$v = b;
                            }
                            //case (VarEnum.VT_I2 or VarEnum.VT_UI2, short s):
                            else if ((($switch5 === 2/*VarEnum.VT_I2*/) || ($switch5 === 18/*VarEnum.VT_UI2*/)) && ($.$is($switch6, $.$$.S.Int16, { set $v(v){ s = v; } })))
                            {
                                $.$$.$interop.castAddress2Object(this._unmanaged.GetRawDataRef($.$$.S.IntPtr).$v).$v = s;
                            }
                            //case (VarEnum.VT_I2 or VarEnum.VT_UI2, ushort u):
                            else if ((($switch5 === 2/*VarEnum.VT_I2*/) || ($switch5 === 18/*VarEnum.VT_UI2*/)) && ($.$is($switch6, $.$$.S.UInt16, { set $v(v){ u = v; } })))
                            {
                                $.$$.$interop.castAddress2Object(this._unmanaged.GetRawDataRef($.$$.S.IntPtr).$v).$v = u;
                            }
                            //case (VarEnum.VT_I4 or VarEnum.VT_INT or VarEnum.VT_UI4 or VarEnum.VT_UINT or VarEnum.VT_ERROR, int i):
                            else if (((((($switch5 === 3/*VarEnum.VT_I4*/) || ($switch5 === 22/*VarEnum.VT_INT*/)) || ($switch5 === 19/*VarEnum.VT_UI4*/)) || ($switch5 === 23/*VarEnum.VT_UINT*/)) || ($switch5 === 10/*VarEnum.VT_ERROR*/)) && ($.$is($switch6, $.$$.S.Int32, { set $v(v){ i = v; } })))
                            {
                                $.$$.$interop.castAddress2Object(this._unmanaged.GetRawDataRef($.$$.S.IntPtr).$v).$v = i;
                            }
                            //case (VarEnum.VT_I4 or VarEnum.VT_INT or VarEnum.VT_UI4 or VarEnum.VT_UINT or VarEnum.VT_ERROR, uint u):
                            else if (((((($switch5 === 3/*VarEnum.VT_I4*/) || ($switch5 === 22/*VarEnum.VT_INT*/)) || ($switch5 === 19/*VarEnum.VT_UI4*/)) || ($switch5 === 23/*VarEnum.VT_UINT*/)) || ($switch5 === 10/*VarEnum.VT_ERROR*/)) && ($.$is($switch6, $.$$.S.UInt32, { set $v(v){ u = v; } })))
                            {
                                $.$$.$interop.castAddress2Object(this._unmanaged.GetRawDataRef($.$$.S.IntPtr).$v).$v = u;
                            }
                            //case (VarEnum.VT_I8 or VarEnum.VT_UI8, long l):
                            else if ((($switch5 === 20/*VarEnum.VT_I8*/) || ($switch5 === 21/*VarEnum.VT_UI8*/)) && ($.$is($switch6, $.$$.S.Int64, { set $v(v){ l = v; } })))
                            {
                                $.$$.$interop.castAddress2Object(this._unmanaged.GetRawDataRef($.$$.S.IntPtr).$v).$v = l;
                            }
                            //case (VarEnum.VT_I8 or VarEnum.VT_UI8, ulong ul):
                            else if ((($switch5 === 20/*VarEnum.VT_I8*/) || ($switch5 === 21/*VarEnum.VT_UI8*/)) && ($.$is($switch6, $.$$.S.UInt64, { set $v(v){ ul = v; } })))
                            {
                                $.$$.$interop.castAddress2Object(this._unmanaged.GetRawDataRef($.$$.S.IntPtr).$v).$v = ul;
                            }
                            //case (VarEnum.VT_R4, float f):
                            else if (($switch5 === 4/*VarEnum.VT_R4*/) && ($.$is($switch6, $.$$.S.Single, { set $v(v){ f = v; } })))
                            {
                                $.$$.$interop.castAddress2Object(this._unmanaged.GetRawDataRef($.$$.S.IntPtr).$v).$v = f;
                            }
                            //case (VarEnum.VT_R8, double d):
                            else if (($switch5 === 5/*VarEnum.VT_R8*/) && ($.$is($switch6, $.$$.S.Double, { set $v(v){ d = v; } })))
                            {
                                $.$$.$interop.castAddress2Object(this._unmanaged.GetRawDataRef($.$$.S.IntPtr).$v).$v = d;
                            }
                            //case (VarEnum.VT_DECIMAL, decimal d):
                            else if (($switch5 === 14/*VarEnum.VT_DECIMAL*/) && ($.$is($switch6, $.$$.S.Decimal, { set $v(v){ d = v; } })))
                            {
                                $.$$.$interop.castAddress2Object(this._unmanaged.GetRawDataRef($.$$.S.IntPtr).$v).$v = d;
                            }
                            //case (VarEnum.VT_BOOL, bool b):
                            else if (($switch5 === 11/*VarEnum.VT_BOOL*/) && ($.$is($switch6, $.$$.S.Boolean, { set $v(v){ b = v; } })))
                            {
                                $.$$.$interop.castAddress2Object(this._unmanaged.GetRawDataRef($.$$.S.IntPtr).$v).$v = b ? -1/*VARIANT_TRUE*/ : 0/*VARIANT_FALSE*/;
                            }
                            //case (VarEnum.VT_BSTR, string str):
                            else if (($switch5 === 8/*VarEnum.VT_BSTR*/) && ($.$is($switch6, $.$$.S.String, { set $v(v){ str = v; } })))
                            {
                                {
                                    /*ref IntPtr*/ let bstrStorage = $.$$.$interop.$addr2Ptr(this._unmanaged.GetRawDataRef($.$$.S.IntPtr).$v, null);
                                    $.$$.SRI.Marshal.FreeBSTR(bstrStorage.$v);
                                    bstrStorage.$v = $.$$.SRI.Marshal.StringToBSTR(str);
                                    break $switchJumpStart4;
                                }
                            }
                            //case (VarEnum.VT_BSTR, BStrWrapper str):
                            else if (($switch5 === 8/*VarEnum.VT_BSTR*/) && ($.$is($switch6, $.$$.SRI.BStrWrapper, { set $v(v){ str = v; } })))
                            {
                                {
                                    /*ref IntPtr*/ let bstrStorage = $.$$.$interop.$addr2Ptr(this._unmanaged.GetRawDataRef($.$$.S.IntPtr).$v, null);
                                    $.$$.SRI.Marshal.FreeBSTR(bstrStorage.$v);
                                    bstrStorage.$v = $.$$.SRI.Marshal.StringToBSTR(str.WrappedObject);
                                    break $switchJumpStart4;
                                }
                            }
                            //case (VarEnum.VT_DATE, DateTime dt):
                            else if (($switch5 === 7/*VarEnum.VT_DATE*/) && ($.$is($switch6, $.$$.S.DateTime, { set $v(v){ dt = v; } })))
                            {
                                $.$$.$interop.castAddress2Object(this._unmanaged.GetRawDataRef($.$$.S.IntPtr).$v).$v = dt.ToOADate();
                            }
                            //case (VarEnum.VT_ERROR, ErrorWrapper error):
                            else if (($switch5 === 10/*VarEnum.VT_ERROR*/) && ($.$is($switch6, $.$$.SRI.ErrorWrapper, { set $v(v){ error = v; } })))
                            {
                                $.$$.$interop.castAddress2Object(this._unmanaged.GetRawDataRef($.$$.S.IntPtr).$v).$v = error.ErrorCode;
                            }
                            //case (VarEnum.VT_CY, CurrencyWrapper cy):
                            else if (($switch5 === 6/*VarEnum.VT_CY*/) && ($.$is($switch6, $.$$.SRI.CurrencyWrapper, { set $v(v){ cy = v; } })))
                            {
                                $.$$.$interop.castAddress2Object(this._unmanaged.GetRawDataRef($.$$.S.IntPtr).$v).$v = $.$$.S.Decimal.ToOACurrency(cy.WrappedObject);
                            }
                            //case (VarEnum.VT_UNKNOWN, object unkObj):
                            else if (($switch5 === 13/*VarEnum.VT_UNKNOWN*/) && ($.$is($switch6, $.$$.S.Object, { set $v(v){ unkObj = v; } })))
                            {
                                $.$$.$interop.castAddress2Object(this._unmanaged.GetRawDataRef($.$$.S.IntPtr).$v).$v = $.$sris.SRIM.StrategyBasedComWrappers.DefaultMarshallingInstance.GetOrCreateComInterfaceForObject(unkObj, 0/*CreateComInterfaceFlags.None*/);
                            }
                            //default
                            else
                            {
                                throw new $.$$.S.ArgumentException().$ctor$13("Invalid combination of unmanaged variant type and managed object type.", "_managed");
                            }
                        }
                        return $.$clone(this._unmanaged);
                    }
                    //--TRIMMABLE-BOUNDARY-END(34362032135)
                    
                    //--TRIMMABLE-BOUNDARY-START(30067064839)
                    /*object? */ ToManaged()
                    {
                        {
                            //--TRIMMABLE-BOUNDARY-START(TRACE)
                            $.$trace(30067064839);
                            //--TRIMMABLE-BOUNDARY-END(TRACE)
                            return $.$sris.SRIM.ComVariantMarshaller.ConvertToManaged($.$clone(this._unmanaged));
                        }
                    }
                    //--TRIMMABLE-BOUNDARY-END(30067064839)
                    
                    //--TRIMMABLE-BOUNDARY-START(17182162951)
                    /*void */ Free()
                    {
                        {
                            //--TRIMMABLE-BOUNDARY-START(TRACE)
                            $.$trace(17182162951);
                            //--TRIMMABLE-BOUNDARY-END(TRACE)
                            return this._unmanaged.Dispose();
                        }
                    }
                    //--TRIMMABLE-BOUNDARY-END(17182162951)
                    
                    //--TRIMMABLE-BOUNDARY-START(12887195655)
                    //default constructor overload
                    $ctor$2()
                    {
                        super.$ctor$1();
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(12887195655);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return this;
                    }
                    //--TRIMMABLE-BOUNDARY-END(12887195655)
                    
                    //--TRIMMABLE-BOUNDARY-START(12887195655)
                    //generic new constructor
                    $gctor()
                    {
                        return this.$ctor$2();
                    }
                    //--TRIMMABLE-BOUNDARY-END(12887195655)
                    
                    $clone($copy)
                    {
                        let copy = $copy ?? new this.constructor();
                        copy._unmanaged = this._unmanaged.$clone();
                        copy._managed = this._managed;
                        return copy;
                    }
                    //default member initializer
                    constructor()
                    {
                        super();
                        //--TRIMMABLE-BOUNDARY-START(8592228359)
                        this._unmanaged = $.$default($.$$.SRIM.ComVariant);
                        //--TRIMMABLE-BOUNDARY-END(8592228359)
                        
                    }
                    static $h = 2293767;
                    static $z = 144;
                    static $f = 0b10000001010000001;
                    static $k = 2;
                    static $$b;
                    static get $b() { return this.$$b ??= $.$$.S.ValueType; }
                    static $$md;
                    static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(25772097543),
    {
      "r": 65537,
      "p": [
        {
          "n": "unmanaged",
          "p": 144506881
        }
      ],
      "n": "FromUnmanaged",
      "d": 2293767,
      "h": 25772097543,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(25772097543),
//--TRIMMABLE-BOUNDARY-START(21477130247),
    {
      "r": 65537,
      "p": [
        {
          "n": "managed",
          "p": 131073
        }
      ],
      "n": "FromManaged",
      "d": 2293767,
      "h": 21477130247,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(21477130247),
//--TRIMMABLE-BOUNDARY-START(34362032135),
    {
      "r": 144506881,
      "n": "ToUnmanaged",
      "d": 2293767,
      "h": 34362032135,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(34362032135),
//--TRIMMABLE-BOUNDARY-START(30067064839),
    {
      "r": 131073,
      "n": "ToManaged",
      "d": 2293767,
      "h": 30067064839,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(30067064839),
//--TRIMMABLE-BOUNDARY-START(17182162951),
    {
      "r": 65537,
      "n": "Free",
      "d": 2293767,
      "h": 17182162951,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(17182162951)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(8592228359),
    {
      "t": 144506881,
      "n": "_unmanaged",
      "d": 2293767,
      "h": 8592228359,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(8592228359),
//--TRIMMABLE-BOUNDARY-START(4297261063),
    {
      "t": 131073,
      "n": "_managed",
      "d": 2293767,
      "h": 4297261063,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(4297261063)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(12887195655),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 2293767,
      "h": 12887195655,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(12887195655)
  ],
  "d": 2228231,
  "h": 2293767
}; }
                    static $$fullName;
                    static get $fullName() { return this.$$fullName ??= `System.Runtime.InteropServices.Marshalling.ComVariantMarshaller+RefPropagate`; }
                    static $$getFullName = {};
                    static $getFullName(separator) { return this.$$getFullName[separator] ??= `System${separator}Runtime${separator}InteropServices${separator}Marshalling${separator}ComVariantMarshaller${separator}RefPropagate`; }
                }, $cls, ($v) => $cls.$_RefPropagate = $v);
            }
            //--TRIMMABLE-BOUNDARY-END(2293767)
            
            static $h = 2228231;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8592162823),
    {
      "r": 144506881,
      "p": [
        {
          "n": "managed",
          "p": 131073
        }
      ],
      "n": "ConvertToUnmanaged",
      "d": 2228231,
      "h": 8592162823,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8592162823),
//--TRIMMABLE-BOUNDARY-START(17182097415),
    {
      "r": 262145,
      "p": [
        {
          "n": "managed",
          "p": 131073
        },
        {
          "n": "variant",
          "p": 144506881,
          "f": 2
        }
      ],
      "n": "TryCreateOleVariantForInterfaceWrapper",
      "d": 2228231,
      "h": 17182097415,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(17182097415),
//--TRIMMABLE-BOUNDARY-START(4297195527),
    {
      "r": 131073,
      "p": [
        {
          "n": "unmanaged",
          "p": 144506881
        }
      ],
      "n": "ConvertToManaged",
      "d": 2228231,
      "h": 4297195527,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(4297195527),
//--TRIMMABLE-BOUNDARY-START(12887130119),
    {
      "r": 65537,
      "p": [
        {
          "n": "unmanaged",
          "p": 144506881
        }
      ],
      "n": "Free",
      "d": 2228231,
      "h": 12887130119,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(12887130119)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(25772032007),
    {
      "t": 524289,
      "n": "VARIANT_TRUE",
      "d": 2228231,
      "h": 25772032007,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(25772032007),
//--TRIMMABLE-BOUNDARY-START(21477064711),
    {
      "t": 524289,
      "n": "VARIANT_FALSE",
      "d": 2228231,
      "h": 21477064711,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(21477064711)
  ],
  "h": 2228231,
  "a": [
    {
      "t": 145096705,
      "c": 17324965889,
      "a": [
        {
          "v": 131073,
          "t": 188547073
        },
        {
          "v": 0,
          "t": 145227777
        },
        {
          "v": 2228231,
          "t": 188547073
        }
      ]
    },
    {
      "t": 145096705,
      "c": 17324965889,
      "a": [
        {
          "v": 131073,
          "t": 188547073
        },
        {
          "v": 5,
          "t": 145227777
        },
        {
          "v": 2293767,
          "t": 188547073
        }
      ]
    }
  ]
}; }
            static $$n;
            static get $n() { return this.$$n ??= [ $.$sris.SRIM.ComVariantMarshaller.RefPropagate ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `System.Runtime.InteropServices.Marshalling.ComVariantMarshaller`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `System${separator}Runtime${separator}InteropServices${separator}Marshalling${separator}ComVariantMarshaller`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2228231)
        
        

        //--TRIMMABLE-BOUNDARY-START(1572871)
        $asm.$cls(`$sris.SRI.HandleCollector`, ($self) => class HandleCollector extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(51541180423)
            /*int*/ static DeltaPercent = 10;
            //--TRIMMABLE-BOUNDARY-END(51541180423)
            
            //--TRIMMABLE-BOUNDARY-START(17181442055)
            /*int*/ _threshold = 0;
            //--TRIMMABLE-BOUNDARY-END(17181442055)
            
            //--TRIMMABLE-BOUNDARY-START(12886474759)
            /*int*/ _handleCount = 0;
            //--TRIMMABLE-BOUNDARY-END(12886474759)
            
            //--TRIMMABLE-BOUNDARY-START(4296540167)
            /*int[]*/ _gcCounts = null;
            //--TRIMMABLE-BOUNDARY-END(4296540167)
            
            //--TRIMMABLE-BOUNDARY-START(8591507463)
            /*int*/ _gcGeneration = 0;
            //--TRIMMABLE-BOUNDARY-END(8591507463)
            
            //--TRIMMABLE-BOUNDARY-START(38656278535)
            $ctor$2(/*string?*/ name, /*int*/ initialThreshold)
            {
                this.$ctor$1(name, initialThreshold, 2147483647/*int.MaxValue*/);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(38656278535);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(38656278535)
            
            //--TRIMMABLE-BOUNDARY-START(34361311239)
            $ctor$1(/*string?*/ name, /*int*/ initialThreshold, /*int*/ maximumThreshold)
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(34361311239);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    if (initialThreshold < 0)
                    {
                        throw new $.$$.S.ArgumentOutOfRangeException().$ctor$18("initialThreshold", $.$box(initialThreshold, $.$$.S.Int32), $.$sris.S.SR.Arg_NeedNonNegNumRequired);
                    }
                    if (maximumThreshold < 0)
                    {
                        throw new $.$$.S.ArgumentOutOfRangeException().$ctor$18("maximumThreshold", $.$box(maximumThreshold, $.$$.S.Int32), $.$sris.S.SR.Arg_NeedNonNegNumRequired);
                    }
                    if (initialThreshold > maximumThreshold)
                    {
                        throw new $.$$.S.ArgumentException().$ctor$13($.$sris.S.SR.Arg_InvalidThreshold, "initialThreshold");
                    }
                    this.Name = name ?? $.$$.S.String.Empty;
                    this.InitialThreshold = initialThreshold;
                    this.MaximumThreshold = maximumThreshold;
                    this._threshold = initialThreshold;
                    this._handleCount = 0;
                    this._gcGeneration = 0;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(34361311239)
            
            //--TRIMMABLE-BOUNDARY-START(47246213127)
            /*int */ get Count()
            {
                return this._handleCount;
            }
            //--TRIMMABLE-BOUNDARY-END(47246213127)
            
            //--TRIMMABLE-BOUNDARY-START(90195886087)
            /*int*/ InitialThreshold = 0;
            //--TRIMMABLE-BOUNDARY-END(90195886087)
            
            //--TRIMMABLE-BOUNDARY-START(94490853383)
            /*int*/ MaximumThreshold = 0;
            //--TRIMMABLE-BOUNDARY-END(94490853383)
            
            //--TRIMMABLE-BOUNDARY-START(98785820679)
            /*string*/ Name = null;
            //--TRIMMABLE-BOUNDARY-END(98785820679)
            
            //--TRIMMABLE-BOUNDARY-START(42951245831)
            /*void */ Add()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(42951245831);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*int*/ let collectionGeneration = -1;
                $.$$.ST$1.Interlocked.Increment($.$ref(() => this._handleCount, ($v) => this._handleCount = $v, $.$$.S.Int32));
                if (this._handleCount < 0)
                {
                    throw new $.$$.S.InvalidOperationException().$ctor$12($.$sris.S.SR.InvalidOperation_HCCountOverflow);
                }
                if (this._handleCount > this._threshold)
                {
                    //lock(this)
                    try
                    {
                        $.$$.ST$1.Monitor.Enter$1(this)
                        {
                            this._threshold = ((this._handleCount + ($.trunc(this._handleCount / 10/*DeltaPercent*/))) | 0);
                            collectionGeneration = this._gcGeneration;
                            if (this._gcGeneration < 2)
                            {
                                this._gcGeneration++;
                            }
                        }
                    }
                    finally
                    {
                        $.$$.ST$1.Monitor.Exit(this)
                    }
                }
                if ((collectionGeneration >= 0) && ((collectionGeneration === 0) || ($.$$.System.Array.$ReadT1.call(this._gcCounts, collectionGeneration) === $.$$.S.GC.CollectionCount(collectionGeneration))))
                {
                    $.$$.S.GC.Collect$4(collectionGeneration);
                    $.$$.ST$1.Thread.Sleep(((10 * collectionGeneration) | 0));
                }
                for(/*int*/ let i = 1; i < 3; i++)
                {
                    $.$$.System.Array.$WriteT1.call(this._gcCounts, $.$$.S.GC.CollectionCount(i), i);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(42951245831)
            
            //--TRIMMABLE-BOUNDARY-START(103080787975)
            /*void */ Remove()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(103080787975);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.ST$1.Interlocked.Decrement($.$ref(() => this._handleCount, ($v) => this._handleCount = $v, $.$$.S.Int32));
                if (this._handleCount < 0)
                {
                    throw new $.$$.S.InvalidOperationException().$ctor$12($.$sris.S.SR.InvalidOperation_HCCountOverflow);
                }
                /*int*/ let newThreshold = ((this._handleCount + $.trunc(this._handleCount / 10/*DeltaPercent*/)) | 0);
                if (newThreshold < (((this._threshold - $.trunc(this._threshold / 10/*DeltaPercent*/)) | 0)))
                {
                    //lock(this)
                    try
                    {
                        $.$$.ST$1.Monitor.Enter$1(this)
                        {
                            if (newThreshold > this.InitialThreshold)
                            {
                                this._threshold = newThreshold;
                            }
                            else 
                            {
                                this._threshold = this.InitialThreshold;
                            }
                            this._gcGeneration = 0;
                        }
                    }
                    finally
                    {
                        $.$$.ST$1.Monitor.Exit(this)
                    }
                }
                for(/*int*/ let i = 1; i < 3; i++)
                {
                    $.$$.System.Array.$WriteT1.call(this._gcCounts, $.$$.S.GC.CollectionCount(i), i);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(103080787975)
            
            //default member initializer
            constructor()
            {
                super();
                //--TRIMMABLE-BOUNDARY-START(4296540167)
                this._gcCounts = $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Int32), null, [3], null);
                //--TRIMMABLE-BOUNDARY-END(4296540167)
                
            }
            static $h = 1572871;
            static $f = 0b10010001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(47246213127),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 60131115015,
        "f": 50331649
      },
      "n": "Count",
      "d": 1572871,
      "h": 47246213127,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(47246213127),
//--TRIMMABLE-BOUNDARY-START(90195886087),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 68721049607,
        "f": 50331649
      },
      "n": "InitialThreshold",
      "d": 1572871,
      "h": 90195886087,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(90195886087),
//--TRIMMABLE-BOUNDARY-START(94490853383),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 77310984199,
        "f": 50331649
      },
      "n": "MaximumThreshold",
      "d": 1572871,
      "h": 94490853383,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(94490853383),
//--TRIMMABLE-BOUNDARY-START(98785820679),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 85900918791,
        "f": 50331649
      },
      "n": "Name",
      "d": 1572871,
      "h": 98785820679,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(98785820679)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(42951245831),
    {
      "r": 65537,
      "n": "Add",
      "d": 1572871,
      "h": 42951245831,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(42951245831),
//--TRIMMABLE-BOUNDARY-START(103080787975),
    {
      "r": 65537,
      "n": "Remove",
      "d": 1572871,
      "h": 103080787975,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(103080787975)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(51541180423),
    {
      "t": 655361,
      "n": "DeltaPercent",
      "d": 1572871,
      "h": 51541180423,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(51541180423),
//--TRIMMABLE-BOUNDARY-START(17181442055),
    {
      "t": 655361,
      "n": "_threshold",
      "d": 1572871,
      "h": 17181442055,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(17181442055),
//--TRIMMABLE-BOUNDARY-START(12886474759),
    {
      "t": 655361,
      "n": "_handleCount",
      "d": 1572871,
      "h": 12886474759,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(12886474759),
//--TRIMMABLE-BOUNDARY-START(4296540167),
    {
      "t": $.$typeArray($.$$.S.Int32).$h,
      "n": "_gcCounts",
      "d": 1572871,
      "h": 4296540167,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(4296540167),
//--TRIMMABLE-BOUNDARY-START(8591507463),
    {
      "t": 655361,
      "n": "_gcGeneration",
      "d": 1572871,
      "h": 8591507463,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(8591507463)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(38656278535),
    {
      "p": [
        {
          "n": "name",
          "p": 1310721
        },
        {
          "n": "initialThreshold",
          "p": 655361
        }
      ],
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 1572871,
      "h": 38656278535,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(38656278535),
//--TRIMMABLE-BOUNDARY-START(34361311239),
    {
      "p": [
        {
          "n": "name",
          "p": 1310721
        },
        {
          "n": "initialThreshold",
          "p": 655361
        },
        {
          "n": "maximumThreshold",
          "p": 655361
        }
      ],
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 1572871,
      "h": 34361311239,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(34361311239)
  ],
  "h": 1572871
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `System.Runtime.InteropServices.HandleCollector`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `System${separator}Runtime${separator}InteropServices${separator}HandleCollector`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1572871)
        
        

        //--TRIMMABLE-BOUNDARY-START(65543)
        $asm.$cls(`$sris.S.Obsoletions`, ($self) => class Obsoletions
        {
            //--TRIMMABLE-BOUNDARY-START(382252154887)
            /*string*/ static SharedUrlFormat = null;
            //--TRIMMABLE-BOUNDARY-END(382252154887)
            
            //--TRIMMABLE-BOUNDARY-START(433791762439)
            /*string*/ static SystemTextEncodingUTF7Message = null;
            //--TRIMMABLE-BOUNDARY-END(433791762439)
            
            //--TRIMMABLE-BOUNDARY-START(429496795143)
            /*string*/ static SystemTextEncodingUTF7DiagId = null;
            //--TRIMMABLE-BOUNDARY-END(429496795143)
            
            //--TRIMMABLE-BOUNDARY-START(266288037895)
            /*string*/ static PrincipalPermissionAttributeMessage = null;
            //--TRIMMABLE-BOUNDARY-END(266288037895)
            
            //--TRIMMABLE-BOUNDARY-START(261993070599)
            /*string*/ static PrincipalPermissionAttributeDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(261993070599)
            
            //--TRIMMABLE-BOUNDARY-START(77309476871)
            /*string*/ static CodeAccessSecurityMessage = null;
            //--TRIMMABLE-BOUNDARY-END(77309476871)
            
            //--TRIMMABLE-BOUNDARY-START(73014509575)
            /*string*/ static CodeAccessSecurityDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(73014509575)
            
            //--TRIMMABLE-BOUNDARY-START(94489346055)
            /*string*/ static ConstrainedExecutionRegionMessage = null;
            //--TRIMMABLE-BOUNDARY-END(94489346055)
            
            //--TRIMMABLE-BOUNDARY-START(90194378759)
            /*string*/ static ConstrainedExecutionRegionDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(90194378759)
            
            //--TRIMMABLE-BOUNDARY-START(214748430343)
            /*string*/ static GlobalAssemblyCacheMessage = null;
            //--TRIMMABLE-BOUNDARY-END(214748430343)
            
            //--TRIMMABLE-BOUNDARY-START(210453463047)
            /*string*/ static GlobalAssemblyCacheDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(210453463047)
            
            //--TRIMMABLE-BOUNDARY-START(442381697031)
            /*string*/ static ThreadAbortMessage = null;
            //--TRIMMABLE-BOUNDARY-END(442381697031)
            
            //--TRIMMABLE-BOUNDARY-START(446676664327)
            /*string*/ static ThreadResetAbortMessage = null;
            //--TRIMMABLE-BOUNDARY-END(446676664327)
            
            //--TRIMMABLE-BOUNDARY-START(438086729735)
            /*string*/ static ThreadAbortDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(438086729735)
            
            //--TRIMMABLE-BOUNDARY-START(146028953607)
            /*string*/ static DefaultCryptoAlgorithmsMessage = null;
            //--TRIMMABLE-BOUNDARY-END(146028953607)
            
            //--TRIMMABLE-BOUNDARY-START(141733986311)
            /*string*/ static DefaultCryptoAlgorithmsDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(141733986311)
            
            //--TRIMMABLE-BOUNDARY-START(120259149831)
            /*string*/ static CreatePdbGeneratorMessage = null;
            //--TRIMMABLE-BOUNDARY-END(120259149831)
            
            //--TRIMMABLE-BOUNDARY-START(115964182535)
            /*string*/ static CreatePdbGeneratorDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(115964182535)
            
            //--TRIMMABLE-BOUNDARY-START(51539673095)
            /*string*/ static AuthenticationManagerMessage = null;
            //--TRIMMABLE-BOUNDARY-END(51539673095)
            
            //--TRIMMABLE-BOUNDARY-START(47244705799)
            /*string*/ static AuthenticationManagerDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(47244705799)
            
            //--TRIMMABLE-BOUNDARY-START(326417580039)
            /*string*/ static RemotingApisMessage = null;
            //--TRIMMABLE-BOUNDARY-END(326417580039)
            
            //--TRIMMABLE-BOUNDARY-START(322122612743)
            /*string*/ static RemotingApisDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(322122612743)
            
            //--TRIMMABLE-BOUNDARY-START(60129607687)
            /*string*/ static BinaryFormatterMessage = null;
            //--TRIMMABLE-BOUNDARY-END(60129607687)
            
            //--TRIMMABLE-BOUNDARY-START(55834640391)
            /*string*/ static BinaryFormatterDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(55834640391)
            
            //--TRIMMABLE-BOUNDARY-START(85899411463)
            /*string*/ static CodeBaseMessage = null;
            //--TRIMMABLE-BOUNDARY-END(85899411463)
            
            //--TRIMMABLE-BOUNDARY-START(81604444167)
            /*string*/ static CodeBaseDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(81604444167)
            
            //--TRIMMABLE-BOUNDARY-START(197568561159)
            /*string*/ static EscapeUriStringMessage = null;
            //--TRIMMABLE-BOUNDARY-END(197568561159)
            
            //--TRIMMABLE-BOUNDARY-START(193273593863)
            /*string*/ static EscapeUriStringDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(193273593863)
            
            //--TRIMMABLE-BOUNDARY-START(489626337287)
            /*string*/ static WebRequestMessage = null;
            //--TRIMMABLE-BOUNDARY-END(489626337287)
            
            //--TRIMMABLE-BOUNDARY-START(485331369991)
            /*string*/ static WebRequestDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(485331369991)
            
            //--TRIMMABLE-BOUNDARY-START(163208822791)
            /*string*/ static DisablePrivateReflectionAttributeMessage = null;
            //--TRIMMABLE-BOUNDARY-END(163208822791)
            
            //--TRIMMABLE-BOUNDARY-START(158913855495)
            /*string*/ static DisablePrivateReflectionAttributeDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(158913855495)
            
            //--TRIMMABLE-BOUNDARY-START(206158495751)
            /*string*/ static GetContextInfoMessage = null;
            //--TRIMMABLE-BOUNDARY-END(206158495751)
            
            //--TRIMMABLE-BOUNDARY-START(201863528455)
            /*string*/ static GetContextInfoDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(201863528455)
            
            //--TRIMMABLE-BOUNDARY-START(399432024071)
            /*string*/ static StrongNameKeyPairMessage = null;
            //--TRIMMABLE-BOUNDARY-END(399432024071)
            
            //--TRIMMABLE-BOUNDARY-START(395137056775)
            /*string*/ static StrongNameKeyPairDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(395137056775)
            
            //--TRIMMABLE-BOUNDARY-START(300647776263)
            /*string*/ static ReflectionOnlyLoadingMessage = null;
            //--TRIMMABLE-BOUNDARY-END(300647776263)
            
            //--TRIMMABLE-BOUNDARY-START(296352808967)
            /*string*/ static ReflectionOnlyLoadingDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(296352808967)
            
            //--TRIMMABLE-BOUNDARY-START(377957187591)
            /*string*/ static RuntimeEnvironmentMessage = null;
            //--TRIMMABLE-BOUNDARY-END(377957187591)
            
            //--TRIMMABLE-BOUNDARY-START(373662220295)
            /*string*/ static RuntimeEnvironmentDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(373662220295)
            
            //--TRIMMABLE-BOUNDARY-START(231928299527)
            /*string*/ static JsonSerializerOptionsIgnoreNullValuesMessage = null;
            //--TRIMMABLE-BOUNDARY-END(231928299527)
            
            //--TRIMMABLE-BOUNDARY-START(227633332231)
            /*string*/ static JsonSerializerOptionsIgnoreNullValuesDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(227633332231)
            
            //--TRIMMABLE-BOUNDARY-START(154618888199)
            /*string*/ static DerivedCryptographicTypesMessage = null;
            //--TRIMMABLE-BOUNDARY-END(154618888199)
            
            //--TRIMMABLE-BOUNDARY-START(150323920903)
            /*string*/ static DerivedCryptographicTypesDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(150323920903)
            
            //--TRIMMABLE-BOUNDARY-START(352187383815)
            /*string*/ static RijndaelMessage = null;
            //--TRIMMABLE-BOUNDARY-END(352187383815)
            
            //--TRIMMABLE-BOUNDARY-START(347892416519)
            /*string*/ static RijndaelDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(347892416519)
            
            //--TRIMMABLE-BOUNDARY-START(360777318407)
            /*string*/ static RNGCryptoServiceProviderMessage = null;
            //--TRIMMABLE-BOUNDARY-END(360777318407)
            
            //--TRIMMABLE-BOUNDARY-START(356482351111)
            /*string*/ static RNGCryptoServiceProviderDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(356482351111)
            
            //--TRIMMABLE-BOUNDARY-START(17179934727)
            /*string*/ static AppDomainCreateUnloadMessage = null;
            //--TRIMMABLE-BOUNDARY-END(17179934727)
            
            //--TRIMMABLE-BOUNDARY-START(12884967431)
            /*string*/ static AppDomainCreateUnloadDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(12884967431)
            
            //--TRIMMABLE-BOUNDARY-START(408021958663)
            /*string*/ static SuppressIldasmAttributeMessage = null;
            //--TRIMMABLE-BOUNDARY-END(408021958663)
            
            //--TRIMMABLE-BOUNDARY-START(403726991367)
            /*string*/ static SuppressIldasmAttributeDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(403726991367)
            
            //--TRIMMABLE-BOUNDARY-START(498216271879)
            /*string*/ static X509CertificateImmutableMessage = null;
            //--TRIMMABLE-BOUNDARY-END(498216271879)
            
            //--TRIMMABLE-BOUNDARY-START(493921304583)
            /*string*/ static X509CertificateImmutableDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(493921304583)
            
            //--TRIMMABLE-BOUNDARY-START(283467907079)
            /*string*/ static PublicKeyPropertyMessage = null;
            //--TRIMMABLE-BOUNDARY-END(283467907079)
            
            //--TRIMMABLE-BOUNDARY-START(279172939783)
            /*string*/ static PublicKeyPropertyDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(279172939783)
            
            //--TRIMMABLE-BOUNDARY-START(506806206471)
            /*string*/ static X509CertificatePrivateKeyMessage = null;
            //--TRIMMABLE-BOUNDARY-END(506806206471)
            
            //--TRIMMABLE-BOUNDARY-START(502511239175)
            /*string*/ static X509CertificatePrivateKeyDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(502511239175)
            
            //--TRIMMABLE-BOUNDARY-START(274877972487)
            /*string*/ static ProduceLegacyHmacValuesMessage = null;
            //--TRIMMABLE-BOUNDARY-END(274877972487)
            
            //--TRIMMABLE-BOUNDARY-START(270583005191)
            /*string*/ static ProduceLegacyHmacValuesDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(270583005191)
            
            //--TRIMMABLE-BOUNDARY-START(481036402695)
            /*string*/ static UseManagedSha1Message = null;
            //--TRIMMABLE-BOUNDARY-END(481036402695)
            
            //--TRIMMABLE-BOUNDARY-START(476741435399)
            /*string*/ static UseManagedSha1DiagId = null;
            //--TRIMMABLE-BOUNDARY-END(476741435399)
            
            //--TRIMMABLE-BOUNDARY-START(128849084423)
            /*string*/ static CryptoConfigEncodeOIDMessage = null;
            //--TRIMMABLE-BOUNDARY-END(128849084423)
            
            //--TRIMMABLE-BOUNDARY-START(124554117127)
            /*string*/ static CryptoConfigEncodeOIDDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(124554117127)
            
            //--TRIMMABLE-BOUNDARY-START(111669215239)
            /*string*/ static CorruptedStateRecoveryMessage = null;
            //--TRIMMABLE-BOUNDARY-END(111669215239)
            
            //--TRIMMABLE-BOUNDARY-START(107374247943)
            /*string*/ static CorruptedStateRecoveryDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(107374247943)
            
            //--TRIMMABLE-BOUNDARY-START(335007514631)
            /*string*/ static Rfc2898CryptDeriveKeyMessage = null;
            //--TRIMMABLE-BOUNDARY-END(335007514631)
            
            //--TRIMMABLE-BOUNDARY-START(330712547335)
            /*string*/ static Rfc2898CryptDeriveKeyDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(330712547335)
            
            //--TRIMMABLE-BOUNDARY-START(68719542279)
            /*string*/ static CmsSignerCspParamsCtorMessage = null;
            //--TRIMMABLE-BOUNDARY-END(68719542279)
            
            //--TRIMMABLE-BOUNDARY-START(64424574983)
            /*string*/ static CmsSignerCspParamsCtorDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(64424574983)
            
            //--TRIMMABLE-BOUNDARY-START(390842089479)
            /*string*/ static SignerInfoCounterSigMessage = null;
            //--TRIMMABLE-BOUNDARY-END(390842089479)
            
            //--TRIMMABLE-BOUNDARY-START(386547122183)
            /*string*/ static SignerInfoCounterSigDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(386547122183)
            
            //--TRIMMABLE-BOUNDARY-START(309237710855)
            /*string*/ static RegexCompileToAssemblyMessage = null;
            //--TRIMMABLE-BOUNDARY-END(309237710855)
            
            //--TRIMMABLE-BOUNDARY-START(304942743559)
            /*string*/ static RegexCompileToAssemblyDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(304942743559)
            
            //--TRIMMABLE-BOUNDARY-START(42949738503)
            /*string*/ static AssemblyNameMembersMessage = null;
            //--TRIMMABLE-BOUNDARY-END(42949738503)
            
            //--TRIMMABLE-BOUNDARY-START(38654771207)
            /*string*/ static AssemblyNameMembersDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(38654771207)
            
            //--TRIMMABLE-BOUNDARY-START(416611893255)
            /*string*/ static SystemDataSerializationFormatBinaryMessage = null;
            //--TRIMMABLE-BOUNDARY-END(416611893255)
            
            //--TRIMMABLE-BOUNDARY-START(412316925959)
            /*string*/ static SystemDataSerializationFormatBinaryDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(412316925959)
            
            //--TRIMMABLE-BOUNDARY-START(472446468103)
            /*string*/ static TlsVersion10and11Message = null;
            //--TRIMMABLE-BOUNDARY-END(472446468103)
            
            //--TRIMMABLE-BOUNDARY-START(468151500807)
            /*string*/ static TlsVersion10and11DiagId = null;
            //--TRIMMABLE-BOUNDARY-END(468151500807)
            
            //--TRIMMABLE-BOUNDARY-START(188978626567)
            /*string*/ static EncryptionPolicyMessage = null;
            //--TRIMMABLE-BOUNDARY-END(188978626567)
            
            //--TRIMMABLE-BOUNDARY-START(184683659271)
            /*string*/ static EncryptionPolicyDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(184683659271)
            
            //--TRIMMABLE-BOUNDARY-START(171798757383)
            /*string*/ static EccXmlExportImportMessage = null;
            //--TRIMMABLE-BOUNDARY-END(171798757383)
            
            //--TRIMMABLE-BOUNDARY-START(167503790087)
            /*string*/ static EccXmlExportImportDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(167503790087)
            
            //--TRIMMABLE-BOUNDARY-START(180388691975)
            /*string*/ static EcDhPublicKeyBlobMessage = null;
            //--TRIMMABLE-BOUNDARY-END(180388691975)
            
            //--TRIMMABLE-BOUNDARY-START(176093724679)
            /*string*/ static EcDhPublicKeyBlobDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(176093724679)
            
            //--TRIMMABLE-BOUNDARY-START(34359803911)
            /*string*/ static AssemblyNameCodeBaseMessage = null;
            //--TRIMMABLE-BOUNDARY-END(34359803911)
            
            //--TRIMMABLE-BOUNDARY-START(30064836615)
            /*string*/ static AssemblyNameCodeBaseDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(30064836615)
            
            //--TRIMMABLE-BOUNDARY-START(137439019015)
            /*string*/ static CryptoStringFactoryMessage = null;
            //--TRIMMABLE-BOUNDARY-END(137439019015)
            
            //--TRIMMABLE-BOUNDARY-START(133144051719)
            /*string*/ static CryptoStringFactoryDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(133144051719)
            
            //--TRIMMABLE-BOUNDARY-START(103079280647)
            /*string*/ static ControlledExecutionRunMessage = null;
            //--TRIMMABLE-BOUNDARY-END(103079280647)
            
            //--TRIMMABLE-BOUNDARY-START(98784313351)
            /*string*/ static ControlledExecutionRunDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(98784313351)
            
            //--TRIMMABLE-BOUNDARY-START(523986075655)
            /*string*/ static XmlSecureResolverMessage = null;
            //--TRIMMABLE-BOUNDARY-END(523986075655)
            
            //--TRIMMABLE-BOUNDARY-START(519691108359)
            /*string*/ static XmlSecureResolverDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(519691108359)
            
            //--TRIMMABLE-BOUNDARY-START(369367252999)
            /*string*/ static RsaEncryptDecryptValueMessage = null;
            //--TRIMMABLE-BOUNDARY-END(369367252999)
            
            //--TRIMMABLE-BOUNDARY-START(365072285703)
            /*string*/ static RsaEncryptDecryptDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(365072285703)
            
            //--TRIMMABLE-BOUNDARY-START(223338364935)
            /*string*/ static JsonSerializerOptionsAddContextMessage = null;
            //--TRIMMABLE-BOUNDARY-END(223338364935)
            
            //--TRIMMABLE-BOUNDARY-START(219043397639)
            /*string*/ static JsonSerializerOptionsAddContextDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(219043397639)
            
            //--TRIMMABLE-BOUNDARY-START(249108168711)
            /*string*/ static LegacyFormatterMessage = null;
            //--TRIMMABLE-BOUNDARY-END(249108168711)
            
            //--TRIMMABLE-BOUNDARY-START(236223266823)
            /*string*/ static LegacyFormatterDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(236223266823)
            
            //--TRIMMABLE-BOUNDARY-START(244813201415)
            /*string*/ static LegacyFormatterImplMessage = null;
            //--TRIMMABLE-BOUNDARY-END(244813201415)
            
            //--TRIMMABLE-BOUNDARY-START(240518234119)
            /*string*/ static LegacyFormatterImplDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(240518234119)
            
            //--TRIMMABLE-BOUNDARY-START(317827645447)
            /*string*/ static RegexExtensibilityImplMessage = null;
            //--TRIMMABLE-BOUNDARY-END(317827645447)
            
            //--TRIMMABLE-BOUNDARY-START(313532678151)
            /*string*/ static RegexExtensibilityDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(313532678151)
            
            //--TRIMMABLE-BOUNDARY-START(8590000135)
            /*string*/ static AesGcmTagConstructorMessage = null;
            //--TRIMMABLE-BOUNDARY-END(8590000135)
            
            //--TRIMMABLE-BOUNDARY-START(4295032839)
            /*string*/ static AesGcmTagConstructorDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(4295032839)
            
            //--TRIMMABLE-BOUNDARY-START(455266598919)
            /*string*/ static ThreadVolatileReadWriteMessage = null;
            //--TRIMMABLE-BOUNDARY-END(455266598919)
            
            //--TRIMMABLE-BOUNDARY-START(450971631623)
            /*string*/ static ThreadVolatileReadWriteDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(450971631623)
            
            //--TRIMMABLE-BOUNDARY-START(25769869319)
            /*string*/ static ArmIntrinsicPerformsUnsignedOperationMessage = null;
            //--TRIMMABLE-BOUNDARY-END(25769869319)
            
            //--TRIMMABLE-BOUNDARY-START(21474902023)
            /*string*/ static ArmIntrinsicPerformsUnsignedOperationDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(21474902023)
            
            //--TRIMMABLE-BOUNDARY-START(257698103303)
            /*string*/ static LoadFromHashAlgorithmMessage = null;
            //--TRIMMABLE-BOUNDARY-END(257698103303)
            
            //--TRIMMABLE-BOUNDARY-START(253403136007)
            /*string*/ static LoadFromHashAlgorithmDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(253403136007)
            
            //--TRIMMABLE-BOUNDARY-START(515396141063)
            /*string*/ static X509CtorCertDataObsoleteMessage = null;
            //--TRIMMABLE-BOUNDARY-END(515396141063)
            
            //--TRIMMABLE-BOUNDARY-START(511101173767)
            /*string*/ static X509CtorCertDataObsoleteDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(511101173767)
            
            //--TRIMMABLE-BOUNDARY-START(463856533511)
            /*string*/ static TlsCipherAlgorithmEnumsMessage = null;
            //--TRIMMABLE-BOUNDARY-END(463856533511)
            
            //--TRIMMABLE-BOUNDARY-START(459561566215)
            /*string*/ static TlsCipherAlgorithmEnumsDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(459561566215)
            
            //--TRIMMABLE-BOUNDARY-START(425201827847)
            /*string*/ static SystemEventsEventsThreadShutdownMessage = null;
            //--TRIMMABLE-BOUNDARY-END(425201827847)
            
            //--TRIMMABLE-BOUNDARY-START(420906860551)
            /*string*/ static SystemEventsEventsThreadShutdownDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(420906860551)
            
            //--TRIMMABLE-BOUNDARY-START(343597449223)
            /*string*/ static Rfc2898DeriveBytesCtorMessage = null;
            //--TRIMMABLE-BOUNDARY-END(343597449223)
            
            //--TRIMMABLE-BOUNDARY-START(339302481927)
            /*string*/ static Rfc2898DeriveBytesCtorDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(339302481927)
            
            //--TRIMMABLE-BOUNDARY-START(292057841671)
            /*string*/ static QueryableMinByMaxByTSourceObsoleteMessage = null;
            //--TRIMMABLE-BOUNDARY-END(292057841671)
            
            //--TRIMMABLE-BOUNDARY-START(287762874375)
            /*string*/ static QueryableMinByMaxByTSourceObsoleteDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(287762874375)
            
            //--TRIMMABLE-BOUNDARY-START(532576010247)
            /*string*/ static XsltSettingsEnableScriptMessage = null;
            //--TRIMMABLE-BOUNDARY-END(532576010247)
            
            //--TRIMMABLE-BOUNDARY-START(528281042951)
            /*string*/ static XsltSettingsEnableScriptDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(528281042951)
            
            //--TRIMMABLE-BOUNDARY-START(SINIT)
            //Static Initializer
            static $sinit()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(382252154887)
                    this.SharedUrlFormat = "https://aka.ms/dotnet-warnings/{0}";
                    //--TRIMMABLE-BOUNDARY-END(382252154887)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(433791762439)
                    this.SystemTextEncodingUTF7Message = "The UTF-7 encoding is insecure and should not be used. Consider using UTF-8 instead.";
                    //--TRIMMABLE-BOUNDARY-END(433791762439)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(429496795143)
                    this.SystemTextEncodingUTF7DiagId = "SYSLIB0001";
                    //--TRIMMABLE-BOUNDARY-END(429496795143)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(266288037895)
                    this.PrincipalPermissionAttributeMessage = "PrincipalPermissionAttribute is not honored by the runtime and must not be used.";
                    //--TRIMMABLE-BOUNDARY-END(266288037895)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(261993070599)
                    this.PrincipalPermissionAttributeDiagId = "SYSLIB0002";
                    //--TRIMMABLE-BOUNDARY-END(261993070599)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(77309476871)
                    this.CodeAccessSecurityMessage = "Code Access Security is not supported or honored by the runtime.";
                    //--TRIMMABLE-BOUNDARY-END(77309476871)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(73014509575)
                    this.CodeAccessSecurityDiagId = "SYSLIB0003";
                    //--TRIMMABLE-BOUNDARY-END(73014509575)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(94489346055)
                    this.ConstrainedExecutionRegionMessage = "The Constrained Execution Region (CER) feature is not supported.";
                    //--TRIMMABLE-BOUNDARY-END(94489346055)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(90194378759)
                    this.ConstrainedExecutionRegionDiagId = "SYSLIB0004";
                    //--TRIMMABLE-BOUNDARY-END(90194378759)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(214748430343)
                    this.GlobalAssemblyCacheMessage = "The Global Assembly Cache is not supported.";
                    //--TRIMMABLE-BOUNDARY-END(214748430343)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(210453463047)
                    this.GlobalAssemblyCacheDiagId = "SYSLIB0005";
                    //--TRIMMABLE-BOUNDARY-END(210453463047)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(442381697031)
                    this.ThreadAbortMessage = "Thread.Abort is not supported and throws PlatformNotSupportedException.";
                    //--TRIMMABLE-BOUNDARY-END(442381697031)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(446676664327)
                    this.ThreadResetAbortMessage = "Thread.ResetAbort is not supported and throws PlatformNotSupportedException.";
                    //--TRIMMABLE-BOUNDARY-END(446676664327)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(438086729735)
                    this.ThreadAbortDiagId = "SYSLIB0006";
                    //--TRIMMABLE-BOUNDARY-END(438086729735)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(146028953607)
                    this.DefaultCryptoAlgorithmsMessage = "The default implementation of this cryptography algorithm is not supported.";
                    //--TRIMMABLE-BOUNDARY-END(146028953607)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(141733986311)
                    this.DefaultCryptoAlgorithmsDiagId = "SYSLIB0007";
                    //--TRIMMABLE-BOUNDARY-END(141733986311)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(120259149831)
                    this.CreatePdbGeneratorMessage = "The CreatePdbGenerator API is not supported and throws PlatformNotSupportedException.";
                    //--TRIMMABLE-BOUNDARY-END(120259149831)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(115964182535)
                    this.CreatePdbGeneratorDiagId = "SYSLIB0008";
                    //--TRIMMABLE-BOUNDARY-END(115964182535)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(51539673095)
                    this.AuthenticationManagerMessage = "AuthenticationManager is not supported. Methods will no-op or throw PlatformNotSupportedException.";
                    //--TRIMMABLE-BOUNDARY-END(51539673095)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(47244705799)
                    this.AuthenticationManagerDiagId = "SYSLIB0009";
                    //--TRIMMABLE-BOUNDARY-END(47244705799)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(326417580039)
                    this.RemotingApisMessage = "This Remoting API is not supported and throws PlatformNotSupportedException.";
                    //--TRIMMABLE-BOUNDARY-END(326417580039)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(322122612743)
                    this.RemotingApisDiagId = "SYSLIB0010";
                    //--TRIMMABLE-BOUNDARY-END(322122612743)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(60129607687)
                    this.BinaryFormatterMessage = "BinaryFormatter serialization is obsolete and should not be used. See https://aka.ms/binaryformatter for more information.";
                    //--TRIMMABLE-BOUNDARY-END(60129607687)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(55834640391)
                    this.BinaryFormatterDiagId = "SYSLIB0011";
                    //--TRIMMABLE-BOUNDARY-END(55834640391)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(85899411463)
                    this.CodeBaseMessage = "Assembly.CodeBase and Assembly.EscapedCodeBase are only included for .NET Framework compatibility. Use Assembly.Location instead.";
                    //--TRIMMABLE-BOUNDARY-END(85899411463)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(81604444167)
                    this.CodeBaseDiagId = "SYSLIB0012";
                    //--TRIMMABLE-BOUNDARY-END(81604444167)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(197568561159)
                    this.EscapeUriStringMessage = "Uri.EscapeUriString can corrupt the Uri string in some cases. Consider using Uri.EscapeDataString for query string components instead.";
                    //--TRIMMABLE-BOUNDARY-END(197568561159)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(193273593863)
                    this.EscapeUriStringDiagId = "SYSLIB0013";
                    //--TRIMMABLE-BOUNDARY-END(193273593863)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(489626337287)
                    this.WebRequestMessage = "WebRequest, HttpWebRequest, ServicePoint, and WebClient are obsolete. Use HttpClient instead.";
                    //--TRIMMABLE-BOUNDARY-END(489626337287)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(485331369991)
                    this.WebRequestDiagId = "SYSLIB0014";
                    //--TRIMMABLE-BOUNDARY-END(485331369991)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(163208822791)
                    this.DisablePrivateReflectionAttributeMessage = "DisablePrivateReflectionAttribute has no effect in .NET 6.0+.";
                    //--TRIMMABLE-BOUNDARY-END(163208822791)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(158913855495)
                    this.DisablePrivateReflectionAttributeDiagId = "SYSLIB0015";
                    //--TRIMMABLE-BOUNDARY-END(158913855495)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(206158495751)
                    this.GetContextInfoMessage = "Use the Graphics.GetContextInfo overloads that accept arguments for better performance and fewer allocations.";
                    //--TRIMMABLE-BOUNDARY-END(206158495751)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(201863528455)
                    this.GetContextInfoDiagId = "SYSLIB0016";
                    //--TRIMMABLE-BOUNDARY-END(201863528455)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(399432024071)
                    this.StrongNameKeyPairMessage = "Strong name signing is not supported and throws PlatformNotSupportedException.";
                    //--TRIMMABLE-BOUNDARY-END(399432024071)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(395137056775)
                    this.StrongNameKeyPairDiagId = "SYSLIB0017";
                    //--TRIMMABLE-BOUNDARY-END(395137056775)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(300647776263)
                    this.ReflectionOnlyLoadingMessage = "ReflectionOnly loading is not supported and throws PlatformNotSupportedException.";
                    //--TRIMMABLE-BOUNDARY-END(300647776263)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(296352808967)
                    this.ReflectionOnlyLoadingDiagId = "SYSLIB0018";
                    //--TRIMMABLE-BOUNDARY-END(296352808967)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(377957187591)
                    this.RuntimeEnvironmentMessage = "RuntimeEnvironment members SystemConfigurationFile, GetRuntimeInterfaceAsIntPtr, and GetRuntimeInterfaceAsObject are not supported and throw PlatformNotSupportedException.";
                    //--TRIMMABLE-BOUNDARY-END(377957187591)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(373662220295)
                    this.RuntimeEnvironmentDiagId = "SYSLIB0019";
                    //--TRIMMABLE-BOUNDARY-END(373662220295)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(231928299527)
                    this.JsonSerializerOptionsIgnoreNullValuesMessage = "JsonSerializerOptions.IgnoreNullValues is obsolete. To ignore null values when serializing, set DefaultIgnoreCondition to JsonIgnoreCondition.WhenWritingNull.";
                    //--TRIMMABLE-BOUNDARY-END(231928299527)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(227633332231)
                    this.JsonSerializerOptionsIgnoreNullValuesDiagId = "SYSLIB0020";
                    //--TRIMMABLE-BOUNDARY-END(227633332231)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(154618888199)
                    this.DerivedCryptographicTypesMessage = "Derived cryptographic types are obsolete. Use the Create method on the base type instead.";
                    //--TRIMMABLE-BOUNDARY-END(154618888199)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(150323920903)
                    this.DerivedCryptographicTypesDiagId = "SYSLIB0021";
                    //--TRIMMABLE-BOUNDARY-END(150323920903)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(352187383815)
                    this.RijndaelMessage = "The Rijndael and RijndaelManaged types are obsolete. Use Aes instead.";
                    //--TRIMMABLE-BOUNDARY-END(352187383815)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(347892416519)
                    this.RijndaelDiagId = "SYSLIB0022";
                    //--TRIMMABLE-BOUNDARY-END(347892416519)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(360777318407)
                    this.RNGCryptoServiceProviderMessage = "RNGCryptoServiceProvider is obsolete. To generate a random number, use one of the RandomNumberGenerator static methods instead.";
                    //--TRIMMABLE-BOUNDARY-END(360777318407)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(356482351111)
                    this.RNGCryptoServiceProviderDiagId = "SYSLIB0023";
                    //--TRIMMABLE-BOUNDARY-END(356482351111)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(17179934727)
                    this.AppDomainCreateUnloadMessage = "Creating and unloading AppDomains is not supported and throws an exception.";
                    //--TRIMMABLE-BOUNDARY-END(17179934727)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(12884967431)
                    this.AppDomainCreateUnloadDiagId = "SYSLIB0024";
                    //--TRIMMABLE-BOUNDARY-END(12884967431)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(408021958663)
                    this.SuppressIldasmAttributeMessage = "SuppressIldasmAttribute has no effect in .NET 6.0+.";
                    //--TRIMMABLE-BOUNDARY-END(408021958663)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(403726991367)
                    this.SuppressIldasmAttributeDiagId = "SYSLIB0025";
                    //--TRIMMABLE-BOUNDARY-END(403726991367)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(498216271879)
                    this.X509CertificateImmutableMessage = "X509Certificate and X509Certificate2 are immutable. Use X509CertificateLoader to create a new certificate.";
                    //--TRIMMABLE-BOUNDARY-END(498216271879)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(493921304583)
                    this.X509CertificateImmutableDiagId = "SYSLIB0026";
                    //--TRIMMABLE-BOUNDARY-END(493921304583)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(283467907079)
                    this.PublicKeyPropertyMessage = "PublicKey.Key is obsolete. Use the appropriate method to get the public key, such as GetRSAPublicKey.";
                    //--TRIMMABLE-BOUNDARY-END(283467907079)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(279172939783)
                    this.PublicKeyPropertyDiagId = "SYSLIB0027";
                    //--TRIMMABLE-BOUNDARY-END(279172939783)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(506806206471)
                    this.X509CertificatePrivateKeyMessage = "X509Certificate2.PrivateKey is obsolete. Use the appropriate method to get the private key, such as GetRSAPrivateKey, or use the CopyWithPrivateKey method to create a new instance with a private key.";
                    //--TRIMMABLE-BOUNDARY-END(506806206471)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(502511239175)
                    this.X509CertificatePrivateKeyDiagId = "SYSLIB0028";
                    //--TRIMMABLE-BOUNDARY-END(502511239175)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(274877972487)
                    this.ProduceLegacyHmacValuesMessage = "ProduceLegacyHmacValues is obsolete. Producing legacy HMAC values is not supported.";
                    //--TRIMMABLE-BOUNDARY-END(274877972487)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(270583005191)
                    this.ProduceLegacyHmacValuesDiagId = "SYSLIB0029";
                    //--TRIMMABLE-BOUNDARY-END(270583005191)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(481036402695)
                    this.UseManagedSha1Message = "HMACSHA1 always uses the algorithm implementation provided by the platform. Use a constructor without the useManagedSha1 parameter.";
                    //--TRIMMABLE-BOUNDARY-END(481036402695)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(476741435399)
                    this.UseManagedSha1DiagId = "SYSLIB0030";
                    //--TRIMMABLE-BOUNDARY-END(476741435399)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(128849084423)
                    this.CryptoConfigEncodeOIDMessage = "EncodeOID is obsolete. Use the ASN.1 functionality provided in System.Formats.Asn1.";
                    //--TRIMMABLE-BOUNDARY-END(128849084423)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(124554117127)
                    this.CryptoConfigEncodeOIDDiagId = "SYSLIB0031";
                    //--TRIMMABLE-BOUNDARY-END(124554117127)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(111669215239)
                    this.CorruptedStateRecoveryMessage = "Recovery from corrupted process state exceptions is not supported; HandleProcessCorruptedStateExceptionsAttribute is ignored.";
                    //--TRIMMABLE-BOUNDARY-END(111669215239)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(107374247943)
                    this.CorruptedStateRecoveryDiagId = "SYSLIB0032";
                    //--TRIMMABLE-BOUNDARY-END(107374247943)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(335007514631)
                    this.Rfc2898CryptDeriveKeyMessage = "Rfc2898DeriveBytes.CryptDeriveKey is obsolete and is not supported. Use PasswordDeriveBytes.CryptDeriveKey instead.";
                    //--TRIMMABLE-BOUNDARY-END(335007514631)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(330712547335)
                    this.Rfc2898CryptDeriveKeyDiagId = "SYSLIB0033";
                    //--TRIMMABLE-BOUNDARY-END(330712547335)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(68719542279)
                    this.CmsSignerCspParamsCtorMessage = "CmsSigner(CspParameters) is obsolete and is not supported. Use an alternative constructor instead.";
                    //--TRIMMABLE-BOUNDARY-END(68719542279)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(64424574983)
                    this.CmsSignerCspParamsCtorDiagId = "SYSLIB0034";
                    //--TRIMMABLE-BOUNDARY-END(64424574983)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(390842089479)
                    this.SignerInfoCounterSigMessage = "ComputeCounterSignature without specifying a CmsSigner is obsolete and is not supported. Use the overload that accepts a CmsSigner.";
                    //--TRIMMABLE-BOUNDARY-END(390842089479)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(386547122183)
                    this.SignerInfoCounterSigDiagId = "SYSLIB0035";
                    //--TRIMMABLE-BOUNDARY-END(386547122183)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(309237710855)
                    this.RegexCompileToAssemblyMessage = "Regex.CompileToAssembly is obsolete and not supported. Use the GeneratedRegexAttribute with the regular expression source generator instead.";
                    //--TRIMMABLE-BOUNDARY-END(309237710855)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(304942743559)
                    this.RegexCompileToAssemblyDiagId = "SYSLIB0036";
                    //--TRIMMABLE-BOUNDARY-END(304942743559)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(42949738503)
                    this.AssemblyNameMembersMessage = "AssemblyName members HashAlgorithm, ProcessorArchitecture, and VersionCompatibility are obsolete and not supported.";
                    //--TRIMMABLE-BOUNDARY-END(42949738503)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(38654771207)
                    this.AssemblyNameMembersDiagId = "SYSLIB0037";
                    //--TRIMMABLE-BOUNDARY-END(38654771207)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(416611893255)
                    this.SystemDataSerializationFormatBinaryMessage = "SerializationFormat.Binary is obsolete and should not be used. See https://aka.ms/serializationformat-binary-obsolete for more information.";
                    //--TRIMMABLE-BOUNDARY-END(416611893255)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(412316925959)
                    this.SystemDataSerializationFormatBinaryDiagId = "SYSLIB0038";
                    //--TRIMMABLE-BOUNDARY-END(412316925959)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(472446468103)
                    this.TlsVersion10and11Message = "TLS versions 1.0 and 1.1 have known vulnerabilities and are not recommended. Use a newer TLS version instead, or use SslProtocols.None to defer to OS defaults.";
                    //--TRIMMABLE-BOUNDARY-END(472446468103)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(468151500807)
                    this.TlsVersion10and11DiagId = "SYSLIB0039";
                    //--TRIMMABLE-BOUNDARY-END(468151500807)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(188978626567)
                    this.EncryptionPolicyMessage = "EncryptionPolicy.NoEncryption and AllowEncryption significantly reduce security and should not be used in production code.";
                    //--TRIMMABLE-BOUNDARY-END(188978626567)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(184683659271)
                    this.EncryptionPolicyDiagId = "SYSLIB0040";
                    //--TRIMMABLE-BOUNDARY-END(184683659271)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(171798757383)
                    this.EccXmlExportImportMessage = "ToXmlString and FromXmlString have no implementation for ECC types, and are obsolete. Use a standard import and export format such as ExportSubjectPublicKeyInfo or ImportSubjectPublicKeyInfo for public keys and ExportPkcs8PrivateKey or ImportPkcs8PrivateKey for private keys.";
                    //--TRIMMABLE-BOUNDARY-END(171798757383)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(167503790087)
                    this.EccXmlExportImportDiagId = "SYSLIB0042";
                    //--TRIMMABLE-BOUNDARY-END(167503790087)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(180388691975)
                    this.EcDhPublicKeyBlobMessage = "ECDiffieHellmanPublicKey.ToByteArray() and the associated constructor do not have a consistent and interoperable implementation on all platforms. Use ECDiffieHellmanPublicKey.ExportSubjectPublicKeyInfo() instead.";
                    //--TRIMMABLE-BOUNDARY-END(180388691975)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(176093724679)
                    this.EcDhPublicKeyBlobDiagId = "SYSLIB0043";
                    //--TRIMMABLE-BOUNDARY-END(176093724679)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(34359803911)
                    this.AssemblyNameCodeBaseMessage = "AssemblyName.CodeBase and AssemblyName.EscapedCodeBase are obsolete. Using them for loading an assembly is not supported.";
                    //--TRIMMABLE-BOUNDARY-END(34359803911)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(30064836615)
                    this.AssemblyNameCodeBaseDiagId = "SYSLIB0044";
                    //--TRIMMABLE-BOUNDARY-END(30064836615)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(137439019015)
                    this.CryptoStringFactoryMessage = "Cryptographic factory methods accepting an algorithm name are obsolete. Use the parameterless Create factory method on the algorithm type instead.";
                    //--TRIMMABLE-BOUNDARY-END(137439019015)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(133144051719)
                    this.CryptoStringFactoryDiagId = "SYSLIB0045";
                    //--TRIMMABLE-BOUNDARY-END(133144051719)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(103079280647)
                    this.ControlledExecutionRunMessage = "ControlledExecution.Run method may corrupt the process and should not be used in production code.";
                    //--TRIMMABLE-BOUNDARY-END(103079280647)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(98784313351)
                    this.ControlledExecutionRunDiagId = "SYSLIB0046";
                    //--TRIMMABLE-BOUNDARY-END(98784313351)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(523986075655)
                    this.XmlSecureResolverMessage = "XmlSecureResolver is obsolete. Use XmlResolver.ThrowingResolver instead when attempting to forbid XML external entity resolution.";
                    //--TRIMMABLE-BOUNDARY-END(523986075655)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(519691108359)
                    this.XmlSecureResolverDiagId = "SYSLIB0047";
                    //--TRIMMABLE-BOUNDARY-END(519691108359)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(369367252999)
                    this.RsaEncryptDecryptValueMessage = "RSA.EncryptValue and DecryptValue are not supported and throw NotSupportedException. Use RSA.Encrypt and RSA.Decrypt instead.";
                    //--TRIMMABLE-BOUNDARY-END(369367252999)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(365072285703)
                    this.RsaEncryptDecryptDiagId = "SYSLIB0048";
                    //--TRIMMABLE-BOUNDARY-END(365072285703)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(223338364935)
                    this.JsonSerializerOptionsAddContextMessage = "JsonSerializerOptions.AddContext is obsolete. To register a JsonSerializerContext, use either the TypeInfoResolver or TypeInfoResolverChain properties.";
                    //--TRIMMABLE-BOUNDARY-END(223338364935)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(219043397639)
                    this.JsonSerializerOptionsAddContextDiagId = "SYSLIB0049";
                    //--TRIMMABLE-BOUNDARY-END(219043397639)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(249108168711)
                    this.LegacyFormatterMessage = "Formatter-based serialization is obsolete and should not be used.";
                    //--TRIMMABLE-BOUNDARY-END(249108168711)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(236223266823)
                    this.LegacyFormatterDiagId = "SYSLIB0050";
                    //--TRIMMABLE-BOUNDARY-END(236223266823)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(244813201415)
                    this.LegacyFormatterImplMessage = "This API supports obsolete formatter-based serialization. It should not be called or extended by application code.";
                    //--TRIMMABLE-BOUNDARY-END(244813201415)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(240518234119)
                    this.LegacyFormatterImplDiagId = "SYSLIB0051";
                    //--TRIMMABLE-BOUNDARY-END(240518234119)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(317827645447)
                    this.RegexExtensibilityImplMessage = "This API supports obsolete mechanisms for Regex extensibility. It is not supported.";
                    //--TRIMMABLE-BOUNDARY-END(317827645447)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(313532678151)
                    this.RegexExtensibilityDiagId = "SYSLIB0052";
                    //--TRIMMABLE-BOUNDARY-END(313532678151)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(8590000135)
                    this.AesGcmTagConstructorMessage = "AesGcm should indicate the required tag size for encryption and decryption. Use a constructor that accepts the tag size.";
                    //--TRIMMABLE-BOUNDARY-END(8590000135)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(4295032839)
                    this.AesGcmTagConstructorDiagId = "SYSLIB0053";
                    //--TRIMMABLE-BOUNDARY-END(4295032839)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(455266598919)
                    this.ThreadVolatileReadWriteMessage = "Thread.VolatileRead and Thread.VolatileWrite are obsolete. Use Volatile.Read or Volatile.Write respectively instead.";
                    //--TRIMMABLE-BOUNDARY-END(455266598919)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(450971631623)
                    this.ThreadVolatileReadWriteDiagId = "SYSLIB0054";
                    //--TRIMMABLE-BOUNDARY-END(450971631623)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(25769869319)
                    this.ArmIntrinsicPerformsUnsignedOperationMessage = "The underlying hardware instruction does not perform a signed saturate narrowing operation, and it always returns an unsigned result. Use the unsigned overload instead.";
                    //--TRIMMABLE-BOUNDARY-END(25769869319)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(21474902023)
                    this.ArmIntrinsicPerformsUnsignedOperationDiagId = "SYSLIB0055";
                    //--TRIMMABLE-BOUNDARY-END(21474902023)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(257698103303)
                    this.LoadFromHashAlgorithmMessage = "LoadFrom with a custom AssemblyHashAlgorithm is obsolete. Use overloads without an AssemblyHashAlgorithm.";
                    //--TRIMMABLE-BOUNDARY-END(257698103303)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(253403136007)
                    this.LoadFromHashAlgorithmDiagId = "SYSLIB0056";
                    //--TRIMMABLE-BOUNDARY-END(253403136007)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(515396141063)
                    this.X509CtorCertDataObsoleteMessage = "Loading certificate data through the constructor or Import is obsolete. Use X509CertificateLoader instead to load certificates.";
                    //--TRIMMABLE-BOUNDARY-END(515396141063)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(511101173767)
                    this.X509CtorCertDataObsoleteDiagId = "SYSLIB0057";
                    //--TRIMMABLE-BOUNDARY-END(511101173767)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(463856533511)
                    this.TlsCipherAlgorithmEnumsMessage = "KeyExchangeAlgorithm, KeyExchangeStrength, CipherAlgorithm, CipherStrength, HashAlgorithm and HashStrength properties of SslStream are obsolete. Use NegotiatedCipherSuite instead.";
                    //--TRIMMABLE-BOUNDARY-END(463856533511)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(459561566215)
                    this.TlsCipherAlgorithmEnumsDiagId = "SYSLIB0058";
                    //--TRIMMABLE-BOUNDARY-END(459561566215)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(425201827847)
                    this.SystemEventsEventsThreadShutdownMessage = "SystemEvents.EventsThreadShutdown callbacks are not run before the process exits. Use AppDomain.ProcessExit instead.";
                    //--TRIMMABLE-BOUNDARY-END(425201827847)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(420906860551)
                    this.SystemEventsEventsThreadShutdownDiagId = "SYSLIB0059";
                    //--TRIMMABLE-BOUNDARY-END(420906860551)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(343597449223)
                    this.Rfc2898DeriveBytesCtorMessage = "The constructors on Rfc2898DeriveBytes are obsolete. Use the static Pbkdf2 method instead.";
                    //--TRIMMABLE-BOUNDARY-END(343597449223)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(339302481927)
                    this.Rfc2898DeriveBytesCtorDiagId = "SYSLIB0060";
                    //--TRIMMABLE-BOUNDARY-END(339302481927)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(292057841671)
                    this.QueryableMinByMaxByTSourceObsoleteMessage = "The Queryable MinBy and MaxBy taking an IComparer<TSource> are obsolete. Use the new ones that take an IComparer<TKey>.";
                    //--TRIMMABLE-BOUNDARY-END(292057841671)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(287762874375)
                    this.QueryableMinByMaxByTSourceObsoleteDiagId = "SYSLIB0061";
                    //--TRIMMABLE-BOUNDARY-END(287762874375)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(532576010247)
                    this.XsltSettingsEnableScriptMessage = "XSLT Script blocks are not supported.";
                    //--TRIMMABLE-BOUNDARY-END(532576010247)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(528281042951)
                    this.XsltSettingsEnableScriptDiagId = "SYSLIB0062";
                    //--TRIMMABLE-BOUNDARY-END(528281042951)
                    
                }
            }
            //--TRIMMABLE-BOUNDARY-END(SINIT)
            
            static $h = 65543;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "l": [
//--TRIMMABLE-BOUNDARY-START(382252154887),
    {
      "t": 1310721,
      "n": "SharedUrlFormat",
      "d": 65543,
      "h": 382252154887,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(382252154887),
//--TRIMMABLE-BOUNDARY-START(433791762439),
    {
      "t": 1310721,
      "n": "SystemTextEncodingUTF7Message",
      "d": 65543,
      "h": 433791762439,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(433791762439),
//--TRIMMABLE-BOUNDARY-START(429496795143),
    {
      "t": 1310721,
      "n": "SystemTextEncodingUTF7DiagId",
      "d": 65543,
      "h": 429496795143,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(429496795143),
//--TRIMMABLE-BOUNDARY-START(266288037895),
    {
      "t": 1310721,
      "n": "PrincipalPermissionAttributeMessage",
      "d": 65543,
      "h": 266288037895,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(266288037895),
//--TRIMMABLE-BOUNDARY-START(261993070599),
    {
      "t": 1310721,
      "n": "PrincipalPermissionAttributeDiagId",
      "d": 65543,
      "h": 261993070599,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(261993070599),
//--TRIMMABLE-BOUNDARY-START(77309476871),
    {
      "t": 1310721,
      "n": "CodeAccessSecurityMessage",
      "d": 65543,
      "h": 77309476871,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(77309476871),
//--TRIMMABLE-BOUNDARY-START(73014509575),
    {
      "t": 1310721,
      "n": "CodeAccessSecurityDiagId",
      "d": 65543,
      "h": 73014509575,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(73014509575),
//--TRIMMABLE-BOUNDARY-START(94489346055),
    {
      "t": 1310721,
      "n": "ConstrainedExecutionRegionMessage",
      "d": 65543,
      "h": 94489346055,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(94489346055),
//--TRIMMABLE-BOUNDARY-START(90194378759),
    {
      "t": 1310721,
      "n": "ConstrainedExecutionRegionDiagId",
      "d": 65543,
      "h": 90194378759,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(90194378759),
//--TRIMMABLE-BOUNDARY-START(214748430343),
    {
      "t": 1310721,
      "n": "GlobalAssemblyCacheMessage",
      "d": 65543,
      "h": 214748430343,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(214748430343),
//--TRIMMABLE-BOUNDARY-START(210453463047),
    {
      "t": 1310721,
      "n": "GlobalAssemblyCacheDiagId",
      "d": 65543,
      "h": 210453463047,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(210453463047),
//--TRIMMABLE-BOUNDARY-START(442381697031),
    {
      "t": 1310721,
      "n": "ThreadAbortMessage",
      "d": 65543,
      "h": 442381697031,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(442381697031),
//--TRIMMABLE-BOUNDARY-START(446676664327),
    {
      "t": 1310721,
      "n": "ThreadResetAbortMessage",
      "d": 65543,
      "h": 446676664327,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(446676664327),
//--TRIMMABLE-BOUNDARY-START(438086729735),
    {
      "t": 1310721,
      "n": "ThreadAbortDiagId",
      "d": 65543,
      "h": 438086729735,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(438086729735),
//--TRIMMABLE-BOUNDARY-START(146028953607),
    {
      "t": 1310721,
      "n": "DefaultCryptoAlgorithmsMessage",
      "d": 65543,
      "h": 146028953607,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(146028953607),
//--TRIMMABLE-BOUNDARY-START(141733986311),
    {
      "t": 1310721,
      "n": "DefaultCryptoAlgorithmsDiagId",
      "d": 65543,
      "h": 141733986311,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(141733986311),
//--TRIMMABLE-BOUNDARY-START(120259149831),
    {
      "t": 1310721,
      "n": "CreatePdbGeneratorMessage",
      "d": 65543,
      "h": 120259149831,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(120259149831),
//--TRIMMABLE-BOUNDARY-START(115964182535),
    {
      "t": 1310721,
      "n": "CreatePdbGeneratorDiagId",
      "d": 65543,
      "h": 115964182535,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(115964182535),
//--TRIMMABLE-BOUNDARY-START(51539673095),
    {
      "t": 1310721,
      "n": "AuthenticationManagerMessage",
      "d": 65543,
      "h": 51539673095,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(51539673095),
//--TRIMMABLE-BOUNDARY-START(47244705799),
    {
      "t": 1310721,
      "n": "AuthenticationManagerDiagId",
      "d": 65543,
      "h": 47244705799,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(47244705799),
//--TRIMMABLE-BOUNDARY-START(326417580039),
    {
      "t": 1310721,
      "n": "RemotingApisMessage",
      "d": 65543,
      "h": 326417580039,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(326417580039),
//--TRIMMABLE-BOUNDARY-START(322122612743),
    {
      "t": 1310721,
      "n": "RemotingApisDiagId",
      "d": 65543,
      "h": 322122612743,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(322122612743),
//--TRIMMABLE-BOUNDARY-START(60129607687),
    {
      "t": 1310721,
      "n": "BinaryFormatterMessage",
      "d": 65543,
      "h": 60129607687,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(60129607687),
//--TRIMMABLE-BOUNDARY-START(55834640391),
    {
      "t": 1310721,
      "n": "BinaryFormatterDiagId",
      "d": 65543,
      "h": 55834640391,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(55834640391),
//--TRIMMABLE-BOUNDARY-START(85899411463),
    {
      "t": 1310721,
      "n": "CodeBaseMessage",
      "d": 65543,
      "h": 85899411463,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(85899411463),
//--TRIMMABLE-BOUNDARY-START(81604444167),
    {
      "t": 1310721,
      "n": "CodeBaseDiagId",
      "d": 65543,
      "h": 81604444167,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(81604444167),
//--TRIMMABLE-BOUNDARY-START(197568561159),
    {
      "t": 1310721,
      "n": "EscapeUriStringMessage",
      "d": 65543,
      "h": 197568561159,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(197568561159),
//--TRIMMABLE-BOUNDARY-START(193273593863),
    {
      "t": 1310721,
      "n": "EscapeUriStringDiagId",
      "d": 65543,
      "h": 193273593863,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(193273593863),
//--TRIMMABLE-BOUNDARY-START(489626337287),
    {
      "t": 1310721,
      "n": "WebRequestMessage",
      "d": 65543,
      "h": 489626337287,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(489626337287),
//--TRIMMABLE-BOUNDARY-START(485331369991),
    {
      "t": 1310721,
      "n": "WebRequestDiagId",
      "d": 65543,
      "h": 485331369991,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(485331369991),
//--TRIMMABLE-BOUNDARY-START(163208822791),
    {
      "t": 1310721,
      "n": "DisablePrivateReflectionAttributeMessage",
      "d": 65543,
      "h": 163208822791,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(163208822791),
//--TRIMMABLE-BOUNDARY-START(158913855495),
    {
      "t": 1310721,
      "n": "DisablePrivateReflectionAttributeDiagId",
      "d": 65543,
      "h": 158913855495,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(158913855495),
//--TRIMMABLE-BOUNDARY-START(206158495751),
    {
      "t": 1310721,
      "n": "GetContextInfoMessage",
      "d": 65543,
      "h": 206158495751,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(206158495751),
//--TRIMMABLE-BOUNDARY-START(201863528455),
    {
      "t": 1310721,
      "n": "GetContextInfoDiagId",
      "d": 65543,
      "h": 201863528455,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(201863528455),
//--TRIMMABLE-BOUNDARY-START(399432024071),
    {
      "t": 1310721,
      "n": "StrongNameKeyPairMessage",
      "d": 65543,
      "h": 399432024071,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(399432024071),
//--TRIMMABLE-BOUNDARY-START(395137056775),
    {
      "t": 1310721,
      "n": "StrongNameKeyPairDiagId",
      "d": 65543,
      "h": 395137056775,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(395137056775),
//--TRIMMABLE-BOUNDARY-START(300647776263),
    {
      "t": 1310721,
      "n": "ReflectionOnlyLoadingMessage",
      "d": 65543,
      "h": 300647776263,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(300647776263),
//--TRIMMABLE-BOUNDARY-START(296352808967),
    {
      "t": 1310721,
      "n": "ReflectionOnlyLoadingDiagId",
      "d": 65543,
      "h": 296352808967,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(296352808967),
//--TRIMMABLE-BOUNDARY-START(377957187591),
    {
      "t": 1310721,
      "n": "RuntimeEnvironmentMessage",
      "d": 65543,
      "h": 377957187591,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(377957187591),
//--TRIMMABLE-BOUNDARY-START(373662220295),
    {
      "t": 1310721,
      "n": "RuntimeEnvironmentDiagId",
      "d": 65543,
      "h": 373662220295,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(373662220295),
//--TRIMMABLE-BOUNDARY-START(231928299527),
    {
      "t": 1310721,
      "n": "JsonSerializerOptionsIgnoreNullValuesMessage",
      "d": 65543,
      "h": 231928299527,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(231928299527),
//--TRIMMABLE-BOUNDARY-START(227633332231),
    {
      "t": 1310721,
      "n": "JsonSerializerOptionsIgnoreNullValuesDiagId",
      "d": 65543,
      "h": 227633332231,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(227633332231),
//--TRIMMABLE-BOUNDARY-START(154618888199),
    {
      "t": 1310721,
      "n": "DerivedCryptographicTypesMessage",
      "d": 65543,
      "h": 154618888199,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(154618888199),
//--TRIMMABLE-BOUNDARY-START(150323920903),
    {
      "t": 1310721,
      "n": "DerivedCryptographicTypesDiagId",
      "d": 65543,
      "h": 150323920903,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(150323920903),
//--TRIMMABLE-BOUNDARY-START(352187383815),
    {
      "t": 1310721,
      "n": "RijndaelMessage",
      "d": 65543,
      "h": 352187383815,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(352187383815),
//--TRIMMABLE-BOUNDARY-START(347892416519),
    {
      "t": 1310721,
      "n": "RijndaelDiagId",
      "d": 65543,
      "h": 347892416519,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(347892416519),
//--TRIMMABLE-BOUNDARY-START(360777318407),
    {
      "t": 1310721,
      "n": "RNGCryptoServiceProviderMessage",
      "d": 65543,
      "h": 360777318407,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(360777318407),
//--TRIMMABLE-BOUNDARY-START(356482351111),
    {
      "t": 1310721,
      "n": "RNGCryptoServiceProviderDiagId",
      "d": 65543,
      "h": 356482351111,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(356482351111),
//--TRIMMABLE-BOUNDARY-START(17179934727),
    {
      "t": 1310721,
      "n": "AppDomainCreateUnloadMessage",
      "d": 65543,
      "h": 17179934727,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(17179934727),
//--TRIMMABLE-BOUNDARY-START(12884967431),
    {
      "t": 1310721,
      "n": "AppDomainCreateUnloadDiagId",
      "d": 65543,
      "h": 12884967431,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(12884967431),
//--TRIMMABLE-BOUNDARY-START(408021958663),
    {
      "t": 1310721,
      "n": "SuppressIldasmAttributeMessage",
      "d": 65543,
      "h": 408021958663,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(408021958663),
//--TRIMMABLE-BOUNDARY-START(403726991367),
    {
      "t": 1310721,
      "n": "SuppressIldasmAttributeDiagId",
      "d": 65543,
      "h": 403726991367,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(403726991367),
//--TRIMMABLE-BOUNDARY-START(498216271879),
    {
      "t": 1310721,
      "n": "X509CertificateImmutableMessage",
      "d": 65543,
      "h": 498216271879,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(498216271879),
//--TRIMMABLE-BOUNDARY-START(493921304583),
    {
      "t": 1310721,
      "n": "X509CertificateImmutableDiagId",
      "d": 65543,
      "h": 493921304583,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(493921304583),
//--TRIMMABLE-BOUNDARY-START(283467907079),
    {
      "t": 1310721,
      "n": "PublicKeyPropertyMessage",
      "d": 65543,
      "h": 283467907079,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(283467907079),
//--TRIMMABLE-BOUNDARY-START(279172939783),
    {
      "t": 1310721,
      "n": "PublicKeyPropertyDiagId",
      "d": 65543,
      "h": 279172939783,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(279172939783),
//--TRIMMABLE-BOUNDARY-START(506806206471),
    {
      "t": 1310721,
      "n": "X509CertificatePrivateKeyMessage",
      "d": 65543,
      "h": 506806206471,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(506806206471),
//--TRIMMABLE-BOUNDARY-START(502511239175),
    {
      "t": 1310721,
      "n": "X509CertificatePrivateKeyDiagId",
      "d": 65543,
      "h": 502511239175,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(502511239175),
//--TRIMMABLE-BOUNDARY-START(274877972487),
    {
      "t": 1310721,
      "n": "ProduceLegacyHmacValuesMessage",
      "d": 65543,
      "h": 274877972487,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(274877972487),
//--TRIMMABLE-BOUNDARY-START(270583005191),
    {
      "t": 1310721,
      "n": "ProduceLegacyHmacValuesDiagId",
      "d": 65543,
      "h": 270583005191,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(270583005191),
//--TRIMMABLE-BOUNDARY-START(481036402695),
    {
      "t": 1310721,
      "n": "UseManagedSha1Message",
      "d": 65543,
      "h": 481036402695,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(481036402695),
//--TRIMMABLE-BOUNDARY-START(476741435399),
    {
      "t": 1310721,
      "n": "UseManagedSha1DiagId",
      "d": 65543,
      "h": 476741435399,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(476741435399),
//--TRIMMABLE-BOUNDARY-START(128849084423),
    {
      "t": 1310721,
      "n": "CryptoConfigEncodeOIDMessage",
      "d": 65543,
      "h": 128849084423,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(128849084423),
//--TRIMMABLE-BOUNDARY-START(124554117127),
    {
      "t": 1310721,
      "n": "CryptoConfigEncodeOIDDiagId",
      "d": 65543,
      "h": 124554117127,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(124554117127),
//--TRIMMABLE-BOUNDARY-START(111669215239),
    {
      "t": 1310721,
      "n": "CorruptedStateRecoveryMessage",
      "d": 65543,
      "h": 111669215239,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(111669215239),
//--TRIMMABLE-BOUNDARY-START(107374247943),
    {
      "t": 1310721,
      "n": "CorruptedStateRecoveryDiagId",
      "d": 65543,
      "h": 107374247943,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(107374247943),
//--TRIMMABLE-BOUNDARY-START(335007514631),
    {
      "t": 1310721,
      "n": "Rfc2898CryptDeriveKeyMessage",
      "d": 65543,
      "h": 335007514631,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(335007514631),
//--TRIMMABLE-BOUNDARY-START(330712547335),
    {
      "t": 1310721,
      "n": "Rfc2898CryptDeriveKeyDiagId",
      "d": 65543,
      "h": 330712547335,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(330712547335),
//--TRIMMABLE-BOUNDARY-START(68719542279),
    {
      "t": 1310721,
      "n": "CmsSignerCspParamsCtorMessage",
      "d": 65543,
      "h": 68719542279,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(68719542279),
//--TRIMMABLE-BOUNDARY-START(64424574983),
    {
      "t": 1310721,
      "n": "CmsSignerCspParamsCtorDiagId",
      "d": 65543,
      "h": 64424574983,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(64424574983),
//--TRIMMABLE-BOUNDARY-START(390842089479),
    {
      "t": 1310721,
      "n": "SignerInfoCounterSigMessage",
      "d": 65543,
      "h": 390842089479,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(390842089479),
//--TRIMMABLE-BOUNDARY-START(386547122183),
    {
      "t": 1310721,
      "n": "SignerInfoCounterSigDiagId",
      "d": 65543,
      "h": 386547122183,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(386547122183),
//--TRIMMABLE-BOUNDARY-START(309237710855),
    {
      "t": 1310721,
      "n": "RegexCompileToAssemblyMessage",
      "d": 65543,
      "h": 309237710855,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(309237710855),
//--TRIMMABLE-BOUNDARY-START(304942743559),
    {
      "t": 1310721,
      "n": "RegexCompileToAssemblyDiagId",
      "d": 65543,
      "h": 304942743559,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(304942743559),
//--TRIMMABLE-BOUNDARY-START(42949738503),
    {
      "t": 1310721,
      "n": "AssemblyNameMembersMessage",
      "d": 65543,
      "h": 42949738503,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(42949738503),
//--TRIMMABLE-BOUNDARY-START(38654771207),
    {
      "t": 1310721,
      "n": "AssemblyNameMembersDiagId",
      "d": 65543,
      "h": 38654771207,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(38654771207),
//--TRIMMABLE-BOUNDARY-START(416611893255),
    {
      "t": 1310721,
      "n": "SystemDataSerializationFormatBinaryMessage",
      "d": 65543,
      "h": 416611893255,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(416611893255),
//--TRIMMABLE-BOUNDARY-START(412316925959),
    {
      "t": 1310721,
      "n": "SystemDataSerializationFormatBinaryDiagId",
      "d": 65543,
      "h": 412316925959,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(412316925959),
//--TRIMMABLE-BOUNDARY-START(472446468103),
    {
      "t": 1310721,
      "n": "TlsVersion10and11Message",
      "d": 65543,
      "h": 472446468103,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(472446468103),
//--TRIMMABLE-BOUNDARY-START(468151500807),
    {
      "t": 1310721,
      "n": "TlsVersion10and11DiagId",
      "d": 65543,
      "h": 468151500807,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(468151500807),
//--TRIMMABLE-BOUNDARY-START(188978626567),
    {
      "t": 1310721,
      "n": "EncryptionPolicyMessage",
      "d": 65543,
      "h": 188978626567,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(188978626567),
//--TRIMMABLE-BOUNDARY-START(184683659271),
    {
      "t": 1310721,
      "n": "EncryptionPolicyDiagId",
      "d": 65543,
      "h": 184683659271,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(184683659271),
//--TRIMMABLE-BOUNDARY-START(171798757383),
    {
      "t": 1310721,
      "n": "EccXmlExportImportMessage",
      "d": 65543,
      "h": 171798757383,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(171798757383),
//--TRIMMABLE-BOUNDARY-START(167503790087),
    {
      "t": 1310721,
      "n": "EccXmlExportImportDiagId",
      "d": 65543,
      "h": 167503790087,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(167503790087),
//--TRIMMABLE-BOUNDARY-START(180388691975),
    {
      "t": 1310721,
      "n": "EcDhPublicKeyBlobMessage",
      "d": 65543,
      "h": 180388691975,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(180388691975),
//--TRIMMABLE-BOUNDARY-START(176093724679),
    {
      "t": 1310721,
      "n": "EcDhPublicKeyBlobDiagId",
      "d": 65543,
      "h": 176093724679,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(176093724679),
//--TRIMMABLE-BOUNDARY-START(34359803911),
    {
      "t": 1310721,
      "n": "AssemblyNameCodeBaseMessage",
      "d": 65543,
      "h": 34359803911,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(34359803911),
//--TRIMMABLE-BOUNDARY-START(30064836615),
    {
      "t": 1310721,
      "n": "AssemblyNameCodeBaseDiagId",
      "d": 65543,
      "h": 30064836615,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(30064836615),
//--TRIMMABLE-BOUNDARY-START(137439019015),
    {
      "t": 1310721,
      "n": "CryptoStringFactoryMessage",
      "d": 65543,
      "h": 137439019015,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(137439019015),
//--TRIMMABLE-BOUNDARY-START(133144051719),
    {
      "t": 1310721,
      "n": "CryptoStringFactoryDiagId",
      "d": 65543,
      "h": 133144051719,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(133144051719),
//--TRIMMABLE-BOUNDARY-START(103079280647),
    {
      "t": 1310721,
      "n": "ControlledExecutionRunMessage",
      "d": 65543,
      "h": 103079280647,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(103079280647),
//--TRIMMABLE-BOUNDARY-START(98784313351),
    {
      "t": 1310721,
      "n": "ControlledExecutionRunDiagId",
      "d": 65543,
      "h": 98784313351,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(98784313351),
//--TRIMMABLE-BOUNDARY-START(523986075655),
    {
      "t": 1310721,
      "n": "XmlSecureResolverMessage",
      "d": 65543,
      "h": 523986075655,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(523986075655),
//--TRIMMABLE-BOUNDARY-START(519691108359),
    {
      "t": 1310721,
      "n": "XmlSecureResolverDiagId",
      "d": 65543,
      "h": 519691108359,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(519691108359),
//--TRIMMABLE-BOUNDARY-START(369367252999),
    {
      "t": 1310721,
      "n": "RsaEncryptDecryptValueMessage",
      "d": 65543,
      "h": 369367252999,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(369367252999),
//--TRIMMABLE-BOUNDARY-START(365072285703),
    {
      "t": 1310721,
      "n": "RsaEncryptDecryptDiagId",
      "d": 65543,
      "h": 365072285703,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(365072285703),
//--TRIMMABLE-BOUNDARY-START(223338364935),
    {
      "t": 1310721,
      "n": "JsonSerializerOptionsAddContextMessage",
      "d": 65543,
      "h": 223338364935,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(223338364935),
//--TRIMMABLE-BOUNDARY-START(219043397639),
    {
      "t": 1310721,
      "n": "JsonSerializerOptionsAddContextDiagId",
      "d": 65543,
      "h": 219043397639,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(219043397639),
//--TRIMMABLE-BOUNDARY-START(249108168711),
    {
      "t": 1310721,
      "n": "LegacyFormatterMessage",
      "d": 65543,
      "h": 249108168711,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(249108168711),
//--TRIMMABLE-BOUNDARY-START(236223266823),
    {
      "t": 1310721,
      "n": "LegacyFormatterDiagId",
      "d": 65543,
      "h": 236223266823,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(236223266823),
//--TRIMMABLE-BOUNDARY-START(244813201415),
    {
      "t": 1310721,
      "n": "LegacyFormatterImplMessage",
      "d": 65543,
      "h": 244813201415,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(244813201415),
//--TRIMMABLE-BOUNDARY-START(240518234119),
    {
      "t": 1310721,
      "n": "LegacyFormatterImplDiagId",
      "d": 65543,
      "h": 240518234119,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(240518234119),
//--TRIMMABLE-BOUNDARY-START(317827645447),
    {
      "t": 1310721,
      "n": "RegexExtensibilityImplMessage",
      "d": 65543,
      "h": 317827645447,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(317827645447),
//--TRIMMABLE-BOUNDARY-START(313532678151),
    {
      "t": 1310721,
      "n": "RegexExtensibilityDiagId",
      "d": 65543,
      "h": 313532678151,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(313532678151),
//--TRIMMABLE-BOUNDARY-START(8590000135),
    {
      "t": 1310721,
      "n": "AesGcmTagConstructorMessage",
      "d": 65543,
      "h": 8590000135,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(8590000135),
//--TRIMMABLE-BOUNDARY-START(4295032839),
    {
      "t": 1310721,
      "n": "AesGcmTagConstructorDiagId",
      "d": 65543,
      "h": 4295032839,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(4295032839),
//--TRIMMABLE-BOUNDARY-START(455266598919),
    {
      "t": 1310721,
      "n": "ThreadVolatileReadWriteMessage",
      "d": 65543,
      "h": 455266598919,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(455266598919),
//--TRIMMABLE-BOUNDARY-START(450971631623),
    {
      "t": 1310721,
      "n": "ThreadVolatileReadWriteDiagId",
      "d": 65543,
      "h": 450971631623,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(450971631623),
//--TRIMMABLE-BOUNDARY-START(25769869319),
    {
      "t": 1310721,
      "n": "ArmIntrinsicPerformsUnsignedOperationMessage",
      "d": 65543,
      "h": 25769869319,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(25769869319),
//--TRIMMABLE-BOUNDARY-START(21474902023),
    {
      "t": 1310721,
      "n": "ArmIntrinsicPerformsUnsignedOperationDiagId",
      "d": 65543,
      "h": 21474902023,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(21474902023),
//--TRIMMABLE-BOUNDARY-START(257698103303),
    {
      "t": 1310721,
      "n": "LoadFromHashAlgorithmMessage",
      "d": 65543,
      "h": 257698103303,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(257698103303),
//--TRIMMABLE-BOUNDARY-START(253403136007),
    {
      "t": 1310721,
      "n": "LoadFromHashAlgorithmDiagId",
      "d": 65543,
      "h": 253403136007,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(253403136007),
//--TRIMMABLE-BOUNDARY-START(515396141063),
    {
      "t": 1310721,
      "n": "X509CtorCertDataObsoleteMessage",
      "d": 65543,
      "h": 515396141063,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(515396141063),
//--TRIMMABLE-BOUNDARY-START(511101173767),
    {
      "t": 1310721,
      "n": "X509CtorCertDataObsoleteDiagId",
      "d": 65543,
      "h": 511101173767,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(511101173767),
//--TRIMMABLE-BOUNDARY-START(463856533511),
    {
      "t": 1310721,
      "n": "TlsCipherAlgorithmEnumsMessage",
      "d": 65543,
      "h": 463856533511,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(463856533511),
//--TRIMMABLE-BOUNDARY-START(459561566215),
    {
      "t": 1310721,
      "n": "TlsCipherAlgorithmEnumsDiagId",
      "d": 65543,
      "h": 459561566215,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(459561566215),
//--TRIMMABLE-BOUNDARY-START(425201827847),
    {
      "t": 1310721,
      "n": "SystemEventsEventsThreadShutdownMessage",
      "d": 65543,
      "h": 425201827847,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(425201827847),
//--TRIMMABLE-BOUNDARY-START(420906860551),
    {
      "t": 1310721,
      "n": "SystemEventsEventsThreadShutdownDiagId",
      "d": 65543,
      "h": 420906860551,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(420906860551),
//--TRIMMABLE-BOUNDARY-START(343597449223),
    {
      "t": 1310721,
      "n": "Rfc2898DeriveBytesCtorMessage",
      "d": 65543,
      "h": 343597449223,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(343597449223),
//--TRIMMABLE-BOUNDARY-START(339302481927),
    {
      "t": 1310721,
      "n": "Rfc2898DeriveBytesCtorDiagId",
      "d": 65543,
      "h": 339302481927,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(339302481927),
//--TRIMMABLE-BOUNDARY-START(292057841671),
    {
      "t": 1310721,
      "n": "QueryableMinByMaxByTSourceObsoleteMessage",
      "d": 65543,
      "h": 292057841671,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(292057841671),
//--TRIMMABLE-BOUNDARY-START(287762874375),
    {
      "t": 1310721,
      "n": "QueryableMinByMaxByTSourceObsoleteDiagId",
      "d": 65543,
      "h": 287762874375,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(287762874375),
//--TRIMMABLE-BOUNDARY-START(532576010247),
    {
      "t": 1310721,
      "n": "XsltSettingsEnableScriptMessage",
      "d": 65543,
      "h": 532576010247,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(532576010247),
//--TRIMMABLE-BOUNDARY-START(528281042951),
    {
      "t": 1310721,
      "n": "XsltSettingsEnableScriptDiagId",
      "d": 65543,
      "h": 528281042951,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(528281042951)
  ],
  "h": 65543
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `System.Obsoletions`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `System${separator}Obsoletions`; }
        });
        //--TRIMMABLE-BOUNDARY-END(65543)
        
        

        //--TRIMMABLE-BOUNDARY-START(2686983)
        $asm.$cls(`$sris.SRIM.ExceptionAsVoidMarshaller`, ($self) => class ExceptionAsVoidMarshaller
        {
            //--TRIMMABLE-BOUNDARY-START(4297654279)
            static /*void */ ConvertToUnmanaged(/*Exception*/ e)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4297654279);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                _ = $.$$.SRI.Marshal.GetHRForException(e);
            }
            //--TRIMMABLE-BOUNDARY-END(4297654279)
            
            static $h = 2686983;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4297654279),
    {
      "r": 65537,
      "p": [
        {
          "n": "e",
          "p": 80805889
        }
      ],
      "n": "ConvertToUnmanaged",
      "d": 2686983,
      "h": 4297654279,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(4297654279)
  ],
  "h": 2686983,
  "a": [
    {
      "t": 145096705,
      "c": 17324965889,
      "a": [
        {
          "v": 80805889,
          "t": 188547073
        },
        {
          "v": 6,
          "t": 145227777
        },
        {
          "v": 2686983,
          "t": 188547073
        }
      ]
    }
  ]
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `System.Runtime.InteropServices.Marshalling.ExceptionAsVoidMarshaller`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `System${separator}Runtime${separator}InteropServices${separator}Marshalling${separator}ExceptionAsVoidMarshaller`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2686983)
        
        

        //--TRIMMABLE-BOUNDARY-START(3997703)
        $asm.$cls(`$sris.SRI.RuntimeEnvironment`, ($self) => class RuntimeEnvironment
        {
            //--TRIMMABLE-BOUNDARY-START(34363736071)
            static /*string */ get SystemConfigurationFile()
            {
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(34363736071)
            
            //--TRIMMABLE-BOUNDARY-START(4298964999)
            static /*bool */ FromGlobalAccessCache(/*Assembly*/ a)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4298964999);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return false;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(4298964999)
            
            //--TRIMMABLE-BOUNDARY-START(17183866887)
            static /*string */ GetRuntimeDirectory()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17183866887);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*string?*/ let runtimeDirectory = $.$$.S.Object.$type.Assembly.Location;
                if (!$.$$.SI.Path.IsPathRooted$1(runtimeDirectory))
                {
                    runtimeDirectory = $.$$.S.AppDomain.CurrentDomain.BaseDirectory;
                }
                /*char*/ let sep = $.$$.SI.Path.DirectorySeparatorChar;
                return $.$$.S.String.Concat$8($.$$.S.String.op_Implicit($.$$.SI.Path.GetDirectoryName$1(runtimeDirectory)), new ($.$$.S.ReadOnlySpan$$($.$$.S.Char))().$ctor$5($.$ref(() => sep, undefined, $.$$.S.Char)));
            }
            //--TRIMMABLE-BOUNDARY-END(17183866887)
            
            //--TRIMMABLE-BOUNDARY-START(21478834183)
            static /*IntPtr */ GetRuntimeInterfaceAsIntPtr(/*Guid*/ clsid, /*Guid*/ riid)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(21478834183);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
                }
            }
            //--TRIMMABLE-BOUNDARY-END(21478834183)
            
            //--TRIMMABLE-BOUNDARY-START(25773801479)
            static /*object */ GetRuntimeInterfaceAsObject(/*Guid*/ clsid, /*Guid*/ riid)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(25773801479);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
                }
            }
            //--TRIMMABLE-BOUNDARY-END(25773801479)
            
            //--TRIMMABLE-BOUNDARY-START(30068768775)
            static /*string */ GetSystemVersion()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(30068768775);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return `v${$.$strNN($.$$.S.Environment.Version)}`;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(30068768775)
            
            static $h = 3997703;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(34363736071),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 12888899591,
        "f": 50331681
      },
      "n": "SystemConfigurationFile",
      "d": 3997703,
      "h": 34363736071,
      "f": 2097185,
      "a": [
        {
          "t": 104464385,
          "c": 30169235457,
          "a": [
            {
              "v": "RuntimeEnvironment members SystemConfigurationFile, GetRuntimeInterfaceAsIntPtr, and GetRuntimeInterfaceAsObject are not supported and throw PlatformNotSupportedException.",
              "t": 1310721
            }
          ],
          "n": [
            {
              "n": "DiagnosticId",
              "v": "SYSLIB0019",
              "t": 1310721
            },
            {
              "n": "UrlFormat",
              "v": "https://aka.ms/dotnet-warnings/{0}",
              "t": 1310721
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(34363736071)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(4298964999),
    {
      "r": 262145,
      "p": [
        {
          "n": "a",
          "p": 107020289
        }
      ],
      "n": "FromGlobalAccessCache",
      "d": 3997703,
      "h": 4298964999,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(4298964999),
//--TRIMMABLE-BOUNDARY-START(17183866887),
    {
      "r": 1310721,
      "n": "GetRuntimeDirectory",
      "d": 3997703,
      "h": 17183866887,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(17183866887),
//--TRIMMABLE-BOUNDARY-START(21478834183),
    {
      "r": 786433,
      "p": [
        {
          "n": "clsid",
          "p": 89784321
        },
        {
          "n": "riid",
          "p": 89784321
        }
      ],
      "n": "GetRuntimeInterfaceAsIntPtr",
      "d": 3997703,
      "h": 21478834183,
      "f": 16777249,
      "a": [
        {
          "t": 104464385,
          "c": 30169235457,
          "a": [
            {
              "v": "RuntimeEnvironment members SystemConfigurationFile, GetRuntimeInterfaceAsIntPtr, and GetRuntimeInterfaceAsObject are not supported and throw PlatformNotSupportedException.",
              "t": 1310721
            }
          ],
          "n": [
            {
              "n": "DiagnosticId",
              "v": "SYSLIB0019",
              "t": 1310721
            },
            {
              "n": "UrlFormat",
              "v": "https://aka.ms/dotnet-warnings/{0}",
              "t": 1310721
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(21478834183),
//--TRIMMABLE-BOUNDARY-START(25773801479),
    {
      "r": 131073,
      "p": [
        {
          "n": "clsid",
          "p": 89784321
        },
        {
          "n": "riid",
          "p": 89784321
        }
      ],
      "n": "GetRuntimeInterfaceAsObject",
      "d": 3997703,
      "h": 25773801479,
      "f": 16777249,
      "a": [
        {
          "t": 104464385,
          "c": 30169235457,
          "a": [
            {
              "v": "RuntimeEnvironment members SystemConfigurationFile, GetRuntimeInterfaceAsIntPtr, and GetRuntimeInterfaceAsObject are not supported and throw PlatformNotSupportedException.",
              "t": 1310721
            }
          ],
          "n": [
            {
              "n": "DiagnosticId",
              "v": "SYSLIB0019",
              "t": 1310721
            },
            {
              "n": "UrlFormat",
              "v": "https://aka.ms/dotnet-warnings/{0}",
              "t": 1310721
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(25773801479),
//--TRIMMABLE-BOUNDARY-START(30068768775),
    {
      "r": 1310721,
      "n": "GetSystemVersion",
      "d": 3997703,
      "h": 30068768775,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(30068768775)
  ],
  "h": 3997703
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `System.Runtime.InteropServices.RuntimeEnvironment`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `System${separator}Runtime${separator}InteropServices${separator}RuntimeEnvironment`; }
        });
        //--TRIMMABLE-BOUNDARY-END(3997703)
        
        

        //--TRIMMABLE-BOUNDARY-START(2031623)
        $asm.$cls(`$sris.SRIM.ComInterfaceMarshaller<>`, (T) => $asm.$gt(`$sris.SRIM.ComInterfaceMarshaller<>`, [T], ($self) => class ComInterfaceMarshaller$$
        {
            //--TRIMMABLE-BOUNDARY-START(25771835399)
            /*Guid?*/ static TargetInterfaceIID = null;
            //--TRIMMABLE-BOUNDARY-END(25771835399)
            
            //--TRIMMABLE-BOUNDARY-START(17181900807)
            static /*void* */ ConvertToUnmanaged(/*T?*/ managed)
            {
                /*nint*/ let unknown;
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17181900807);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (managed === null)
                {
                    return null;
                }
                if (!$.$$.SRI.ComWrappers.TryGetComInstance($.$box(managed, T), $.$ref(() => unknown, ($v) => unknown = $v, $.$$.S.IntPtr)))
                {
                    unknown = $.$sris.SRIM.StrategyBasedComWrappers.DefaultMarshallingInstance.GetOrCreateComInterfaceForObject($.$box(managed, T), 0/*CreateComInterfaceFlags.None*/);
                }
                return $.$sris.SRIM.ComInterfaceMarshaller$$(T).CastIUnknownToInterfaceType(unknown);
            }
            //--TRIMMABLE-BOUNDARY-END(17181900807)
            
            //--TRIMMABLE-BOUNDARY-START(12886933511)
            static /*T? */ ConvertToManaged(/*void**/ unmanaged)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12886933511);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (unmanaged === null)
                {
                    return $.$default(T);
                }
                return $.$cast($.$sris.SRIM.StrategyBasedComWrappers.DefaultMarshallingInstance.GetOrCreateObjectForComInstance$1($.$$.$interop.$ptr2Addr(unmanaged), 8/*CreateObjectFlags.Unwrap*/), T);
            }
            //--TRIMMABLE-BOUNDARY-END(12886933511)
            
            //--TRIMMABLE-BOUNDARY-START(21476868103)
            static /*void */ Free(/*void**/ unmanaged)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21476868103);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (unmanaged !== null)
                {
                    $.$$.SRI.Marshal.Release($.$$.$interop.$ptr2Addr(unmanaged));
                }
            }
            //--TRIMMABLE-BOUNDARY-END(21476868103)
            
            //--TRIMMABLE-BOUNDARY-START(8591966215)
            static /*void* */ CastIUnknownToInterfaceType(/*nint*/ unknown)
            {
                /*nint*/ let interfacePointer;
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591966215);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$sris.SRIM.ComInterfaceMarshaller$$(T).TargetInterfaceIID === null)
                {
                    return $.$$.$interop.$addr2Ptr(unknown, null);
                }
                if ($.$$.SRI.Marshal.QueryInterface(unknown, $.$$.S.Nullable.GetValueRefOrDefaultRef($.$$.S.Guid, $.$$.SRC.RuntimeHelpers.CreateObjectReferenceT($.$typeNullable($.$$.S.Guid), () => $.$sris.SRIM.ComInterfaceMarshaller$$(T).TargetInterfaceIID, ($v) => $.$sris.SRIM.ComInterfaceMarshaller$$(T).TargetInterfaceIID = $v, null, true)), $.$ref(() => interfacePointer, ($v) => interfacePointer = $v, $.$$.S.IntPtr)) !== 0)
                {
                    $.$$.SRI.Marshal.Release(unknown);
                    throw new $.$$.S.InvalidCastException().$ctor$13((() =>
                    {
                        var $handler = new $.$$.SRC.DefaultInterpolatedStringHandler().$ctor$5(2, 1);
                        $handler.AppendLiteral("Unable to cast the provided managed object to a COM interface with ID '");
                        $handler.AppendFormatted($.$box($.$$.S.Nullable$$($.$$.S.Guid).GetValueOrDefault.call($.$sris.SRIM.ComInterfaceMarshaller$$(T).TargetInterfaceIID), $.$$.S.Guid), null, "B");
                        $handler.AppendLiteral("'");
                        return $handler.ToStringAndClear                ();
                    })());
                }
                $.$$.SRI.Marshal.Release(unknown);
                return $.$$.$interop.$addr2Ptr(interfacePointer, null);
            }
            //--TRIMMABLE-BOUNDARY-END(8591966215)
            
            //--TRIMMABLE-BOUNDARY-START(4296998919)
            //Static Initializer
            static $sinit()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296998919);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                {
                    //--TRIMMABLE-BOUNDARY-START(25771835399)
                    this.TargetInterfaceIID = ($.$sris.SRIM.StrategyBasedComWrappers.DefaultIUnknownInterfaceDetailsStrategy.SRIM$IIUnknownInterfaceDetailsStrategy$GetIUnknownDerivedDetails(T.$type.TypeHandle)?.SRIM$IIUnknownDerivedDetails$Iid ?? null);
                    //--TRIMMABLE-BOUNDARY-END(25771835399)
                    
                }
            }
            //--TRIMMABLE-BOUNDARY-END(4296998919)
            
            static $H = 2031623;
            static $h = 2031623;
            static $g = 1;
            static $f = 0b1010001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(17181900807),
    {
      "r": $.$typePointer($.$$.S.Void).$h,
      "p": [
        {
          "n": "managed",
          "p": T?.$h??1572864
        }
      ],
      "n": "ConvertToUnmanaged",
      "d": this.$h,
      "H": 17181900807,
      "h": Number(BigInt(this.$h)|0x400000000n),
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(17181900807),
//--TRIMMABLE-BOUNDARY-START(12886933511),
    {
      "r": T?.$h??1572864,
      "p": [
        {
          "n": "unmanaged",
          "p": $.$typePointer($.$$.S.Void).$h
        }
      ],
      "n": "ConvertToManaged",
      "d": this.$h,
      "H": 12886933511,
      "h": Number(BigInt(this.$h)|0x300000000n),
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(12886933511),
//--TRIMMABLE-BOUNDARY-START(21476868103),
    {
      "r": 65537,
      "p": [
        {
          "n": "unmanaged",
          "p": $.$typePointer($.$$.S.Void).$h
        }
      ],
      "n": "Free",
      "d": this.$h,
      "H": 21476868103,
      "h": Number(BigInt(this.$h)|0x500000000n),
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(21476868103),
//--TRIMMABLE-BOUNDARY-START(8591966215),
    {
      "r": $.$typePointer($.$$.S.Void).$h,
      "p": [
        {
          "n": "unknown",
          "p": 786433
        }
      ],
      "n": "CastIUnknownToInterfaceType",
      "d": this.$h,
      "H": 8591966215,
      "h": Number(BigInt(this.$h)|0x200000000n),
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(8591966215)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(25771835399),
    {
      "t": $.$typeNullable($.$$.S.Guid).$h,
      "n": "TargetInterfaceIID",
      "d": this.$h,
      "H": 25771835399,
      "h": Number(BigInt(this.$h)|0x600000000n),
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(25771835399)
  ],
  "s": [
    {
      "h": T?.$h??1572864,
      "n": "T"
    }
  ],
  "r": 1,
  "H": 2031623,
  "h": this.$h,
  "a": [
    {
      "t": 160169985,
      "c": 13045071873,
      "a": [
        {
          "v": "android",
          "t": 1310721
        }
      ]
    },
    {
      "t": 160169985,
      "c": 13045071873,
      "a": [
        {
          "v": "browser",
          "t": 1310721
        }
      ]
    },
    {
      "t": 160169985,
      "c": 13045071873,
      "a": [
        {
          "v": "ios",
          "t": 1310721
        }
      ]
    },
    {
      "t": 160169985,
      "c": 13045071873,
      "a": [
        {
          "v": "tvos",
          "t": 1310721
        }
      ]
    },
    {
      "t": 54984705,
      "c": 8644919297,
      "a": [
        {
          "v": false,
          "t": 262145
        }
      ]
    },
    {
      "t": 145096705,
      "c": 17324965889,
      "a": [
        {
          "v": 145162241,
          "t": 188547073
        },
        {
          "v": 0,
          "t": 145227777
        },
        {
          "v": 2031623,
          "t": 188547073
        }
      ]
    }
  ]
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `System.Runtime.InteropServices.Marshalling.ComInterfaceMarshaller<${T?.$fullName}>`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `System${separator}Runtime${separator}InteropServices${separator}Marshalling${separator}ComInterfaceMarshaller$${T?.$getFullName(separator)}$`; }
        }));
        //--TRIMMABLE-BOUNDARY-END(2031623)
        
        

        //--TRIMMABLE-BOUNDARY-START(2424839)
        $asm.$cls(`$sris.SRIM.DefaultIUnknownInterfaceDetailsStrategy`, ($self) => class DefaultIUnknownInterfaceDetailsStrategy extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(21477261319)
            /*IIUnknownInterfaceDetailsStrategy*/ static Instance = null;
            //--TRIMMABLE-BOUNDARY-END(21477261319)
            
            //--TRIMMABLE-BOUNDARY-START(12887326727)
            /*IComExposedDetails? */ GetComExposedTypeDetails(/*RuntimeTypeHandle*/ type)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12887326727);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$sris.SRIM.IComExposedDetails.SRIM$IComExposedDetails$GetFromAttribute(type);
            }
            //--TRIMMABLE-BOUNDARY-END(12887326727)
            
            //--TRIMMABLE-BOUNDARY-START(17182294023)
            /*IIUnknownDerivedDetails? */ GetIUnknownDerivedDetails(/*RuntimeTypeHandle*/ type)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17182294023);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$sris.SRIM.IIUnknownDerivedDetails.SRIM$IIUnknownDerivedDetails$GetFromAttribute(type);
            }
            //--TRIMMABLE-BOUNDARY-END(17182294023)
            
            //--TRIMMABLE-BOUNDARY-START(8593211399)
            //Generated interface implemetation for System.Runtime.InteropServices.Marshalling.IIUnknownInterfaceDetailsStrategy.GetIUnknownDerivedDetails(System.RuntimeTypeHandle)
            SRIM$IIUnknownInterfaceDetailsStrategy$GetIUnknownDerivedDetails()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8593211399);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.GetIUnknownDerivedDetails(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(8593211399)
            
            //--TRIMMABLE-BOUNDARY-START(4298244103)
            //Generated interface implemetation for System.Runtime.InteropServices.Marshalling.IIUnknownInterfaceDetailsStrategy.GetComExposedTypeDetails(System.RuntimeTypeHandle)
            SRIM$IIUnknownInterfaceDetailsStrategy$GetComExposedTypeDetails()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4298244103);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.GetComExposedTypeDetails(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4298244103)
            
            //--TRIMMABLE-BOUNDARY-START(8592359431)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8592359431);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(8592359431)
            
            //--TRIMMABLE-BOUNDARY-START(8592359431)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(8592359431)
            
            //--TRIMMABLE-BOUNDARY-START(4297392135)
            //Static Initializer
            static $sinit()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4297392135);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                {
                    //--TRIMMABLE-BOUNDARY-START(21477261319)
                    this.Instance = new $.$sris.SRIM.DefaultIUnknownInterfaceDetailsStrategy().$ctor$1();
                    //--TRIMMABLE-BOUNDARY-END(21477261319)
                    
                }
            }
            //--TRIMMABLE-BOUNDARY-END(4297392135)
            
            static $h = 2424839;
            static $f = 0b10010000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(12887326727),
    {
      "r": 3014663,
      "p": [
        {
          "n": "type",
          "p": 160956417
        }
      ],
      "n": "GetComExposedTypeDetails",
      "d": 2424839,
      "h": 12887326727,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(12887326727),
//--TRIMMABLE-BOUNDARY-START(17182294023),
    {
      "r": 3211271,
      "p": [
        {
          "n": "type",
          "p": 160956417
        }
      ],
      "n": "GetIUnknownDerivedDetails",
      "d": 2424839,
      "h": 17182294023,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(17182294023)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(21477261319),
    {
      "t": 3276807,
      "n": "Instance",
      "d": 2424839,
      "h": 21477261319,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(21477261319)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(8592359431),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 2424839,
      "h": 8592359431,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8592359431)
  ],
  "h": 2424839
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$sris.SRIM.IIUnknownInterfaceDetailsStrategy ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `System.Runtime.InteropServices.Marshalling.DefaultIUnknownInterfaceDetailsStrategy`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `System${separator}Runtime${separator}InteropServices${separator}Marshalling${separator}DefaultIUnknownInterfaceDetailsStrategy`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2424839)
        
        

        //--TRIMMABLE-BOUNDARY-START(2752519)
        $asm.$cls(`$sris.SRIM.FreeThreadedStrategy`, ($self) => class FreeThreadedStrategy extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(12887654407)
            /*IIUnknownStrategy*/ static Instance = null;
            //--TRIMMABLE-BOUNDARY-END(12887654407)
            
            //--TRIMMABLE-BOUNDARY-START(17182621703)
            /*void* */ SRIM$IIUnknownStrategy$CreateInstancePointer(/*void**/ unknown)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17182621703);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.SRI.Marshal.AddRef($.$$.$interop.$ptr2Addr(unknown));
                return unknown;
            }
            //--TRIMMABLE-BOUNDARY-END(17182621703)
            
            //--TRIMMABLE-BOUNDARY-START(21477588999)
            /*int */ SRIM$IIUnknownStrategy$QueryInterface(/*void**/ thisPtr, /*in Guid*/ handle, /*out void**/ ppObj)
            {
                /*nint*/ let ppv;
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21477588999);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*int*/ let hr = $.$$.SRI.Marshal.QueryInterface($.$$.$interop.$ptr2Addr(thisPtr), handle, $.$ref(() => ppv, ($v) => ppv = $v, $.$$.S.IntPtr));
                if (hr < 0)
                {
                    ppObj.$v = null;
                }
                else 
                {
                    ppObj.$v = $.$$.$interop.$addr2Ptr(ppv, null);
                }
                return hr;
            }
            //--TRIMMABLE-BOUNDARY-END(21477588999)
            
            //--TRIMMABLE-BOUNDARY-START(25772556295)
            /*int */ SRIM$IIUnknownStrategy$Release(/*void**/ thisPtr)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(25772556295);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return $.$$.SRI.Marshal.Release($.$$.$interop.$ptr2Addr(thisPtr));
                }
            }
            //--TRIMMABLE-BOUNDARY-END(25772556295)
            
            //--TRIMMABLE-BOUNDARY-START(8592687111)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8592687111);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(8592687111)
            
            //--TRIMMABLE-BOUNDARY-START(8592687111)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(8592687111)
            
            //--TRIMMABLE-BOUNDARY-START(4297719815)
            //Static Initializer
            static $sinit()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4297719815);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                {
                    //--TRIMMABLE-BOUNDARY-START(12887654407)
                    this.Instance = new $.$sris.SRIM.FreeThreadedStrategy().$ctor$1();
                    //--TRIMMABLE-BOUNDARY-END(12887654407)
                    
                }
            }
            //--TRIMMABLE-BOUNDARY-END(4297719815)
            
            static $h = 2752519;
            static $f = 0b10010000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "l": [
//--TRIMMABLE-BOUNDARY-START(12887654407),
    {
      "t": 3407879,
      "n": "Instance",
      "d": 2752519,
      "h": 12887654407,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(12887654407)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(8592687111),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 2752519,
      "h": 8592687111,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8592687111)
  ],
  "h": 2752519
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$sris.SRIM.IIUnknownStrategy ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `System.Runtime.InteropServices.Marshalling.FreeThreadedStrategy`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `System${separator}Runtime${separator}InteropServices${separator}Marshalling${separator}FreeThreadedStrategy`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2752519)
        
        

        //--TRIMMABLE-BOUNDARY-START(2359303)
        $asm.$cls(`$sris.SRIM.DefaultCaching`, ($self) => class DefaultCaching extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(4297326599)
            /*ConcurrentDictionary<RuntimeTypeHandle, IIUnknownCacheStrategy.TableInfo>*/ _cache = null;
            //--TRIMMABLE-BOUNDARY-END(4297326599)
            
            //--TRIMMABLE-BOUNDARY-START(17182228487)
            /*IIUnknownCacheStrategy.TableInfo */ SRIM$IIUnknownCacheStrategy$ConstructTableInfo(/*RuntimeTypeHandle*/ handle, /*IIUnknownDerivedDetails*/ details, /*void**/ ptr)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17182228487);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let obj = $.$cast(ptr, $.$typePointer($.$typePointer($.$typePointer($.$$.S.Void))));
                return (() =>
                {
                    //new $.$sris.SRIM.IIUnknownCacheStrategy.TableInfo()
                    const $t1 = $.$sris.SRIM.IIUnknownCacheStrategy.TableInfo;
                    const $i1 = new $t1();
                    $i1.$ctor$2();
                    $i1.ThisPtr = obj;
                    $i1.Table = obj.$v;
                    $i1.ManagedType = details.SRIM$IIUnknownDerivedDetails$Implementation.TypeHandle;
                    return $i1;
                })();
            }
            //--TRIMMABLE-BOUNDARY-END(17182228487)
            
            //--TRIMMABLE-BOUNDARY-START(21477195783)
            /*bool */ SRIM$IIUnknownCacheStrategy$TryGetTableInfo(/*RuntimeTypeHandle*/ handle, /*out IIUnknownCacheStrategy.TableInfo*/ info)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21477195783);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this._cache.TryGetValue(handle, info);
            }
            //--TRIMMABLE-BOUNDARY-END(21477195783)
            
            //--TRIMMABLE-BOUNDARY-START(25772163079)
            /*bool */ SRIM$IIUnknownCacheStrategy$TrySetTableInfo(/*RuntimeTypeHandle*/ handle, /*IIUnknownCacheStrategy.TableInfo*/ info)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25772163079);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this._cache.TryAdd(handle, info);
            }
            //--TRIMMABLE-BOUNDARY-END(25772163079)
            
            //--TRIMMABLE-BOUNDARY-START(12887261191)
            /*void */ SRIM$IIUnknownCacheStrategy$Clear(/*IIUnknownStrategy*/ unknownStrategy)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12887261191);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                let $en3 = this._cache.Values.SCG$IEnumerable$$$GetEnumerator();
                while ($en3.SC$1$IEnumerator$MoveNext())
                {
                    let info = $en3.SCG$IEnumerator$$$Current;
                    {
                        _ = unknownStrategy.SRIM$IIUnknownStrategy$Release(info.ThisPtr);
                    }
                }
                this._cache.Clear();
            }
            //--TRIMMABLE-BOUNDARY-END(12887261191)
            
            //--TRIMMABLE-BOUNDARY-START(8592293895)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8592293895);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(8592293895)
            
            //--TRIMMABLE-BOUNDARY-START(8592293895)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(8592293895)
            
            //default member initializer
            constructor()
            {
                super();
                //--TRIMMABLE-BOUNDARY-START(4297326599)
                this._cache = new ($.$scc.SCC.ConcurrentDictionary$$$($.$$.S.RuntimeTypeHandle, $.$sris.SRIM.IIUnknownCacheStrategy.TableInfo))().$ctor$8(1, 16);
                //--TRIMMABLE-BOUNDARY-END(4297326599)
                
            }
            static $h = 2359303;
            static $f = 0b10010000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "l": [
//--TRIMMABLE-BOUNDARY-START(4297326599),
    {
      "t": $.$scc.SCC.ConcurrentDictionary$$$($.$$.S.RuntimeTypeHandle, $.$sris.SRIM.IIUnknownCacheStrategy.TableInfo).$h,
      "n": "_cache",
      "d": 2359303,
      "h": 4297326599,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(4297326599)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(8592293895),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 2359303,
      "h": 8592293895,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8592293895)
  ],
  "h": 2359303
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$sris.SRIM.IIUnknownCacheStrategy ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `System.Runtime.InteropServices.Marshalling.DefaultCaching`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `System${separator}Runtime${separator}InteropServices${separator}Marshalling${separator}DefaultCaching`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2359303)
        
        

        //--TRIMMABLE-BOUNDARY-START(1835015)
        $asm.$cls(`$sris.SRIM.ComImportInteropInterfaceDetailsStrategy`, ($self) => class ComImportInteropInterfaceDetailsStrategy extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(34361573383)
            /*IIUnknownInterfaceDetailsStrategy*/ static Instance = null;
            //--TRIMMABLE-BOUNDARY-END(34361573383)
            
            //--TRIMMABLE-BOUNDARY-START(4296802311)
            /*ConditionalWeakTable<Type, Type>*/ _forwarderInterfaceCache = null;
            //--TRIMMABLE-BOUNDARY-END(4296802311)
            
            //--TRIMMABLE-BOUNDARY-START(21476671495)
            /*IComExposedDetails? */ GetComExposedTypeDetails(/*RuntimeTypeHandle*/ type)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(21476671495);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return $.$sris.SRIM.DefaultIUnknownInterfaceDetailsStrategy.Instance.SRIM$IIUnknownInterfaceDetailsStrategy$GetComExposedTypeDetails(type);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(21476671495)
            
            //--TRIMMABLE-BOUNDARY-START(30066606087)
            /*IIUnknownDerivedDetails? */ GetIUnknownDerivedDetails(/*RuntimeTypeHandle*/ type)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(30066606087);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*Type*/ let runtimeType = $.$$.S.Type.GetTypeFromHandle(type);
                if (!runtimeType.IsImport)
                {
                    return $.$sris.SRIM.DefaultIUnknownInterfaceDetailsStrategy.Instance.SRIM$IIUnknownInterfaceDetailsStrategy$GetIUnknownDerivedDetails(type);
                }
                /*Type*/ let implementationType = this._forwarderInterfaceCache.GetValue(runtimeType, new ($.$$.SRC.ConditionalWeakTable$$$($.$$.S.Type, $.$$.S.Type).CreateValueCallback)().$ctor(this,  (/*runtimeType*/ runtimeType) =>
                {
                    /*AssemblyBuilder*/ let assembly = /*$.$$.SRE.AssemblyBuilder*/$.$$.DeletedObject.DefineDynamicAssembly(new $.$$.SR.AssemblyName().$ctor$2("ComImportForwarder"), runtimeType.IsCollectible ? 9/*AssemblyBuilderAccess.RunAndCollect*/ : 1/*AssemblyBuilderAccess.Run*/);
                    /*ModuleBuilder*/ let module = assembly.DefineDynamicModule("ComImportForwarder");
                    /*ConstructorInfo*/ let ignoresAccessChecksToAttributeConstructor = $.$sris.SRIM.ComImportInteropInterfaceDetailsStrategy.GetIgnoresAccessChecksToAttributeConstructor(module);
                    assembly.SetCustomAttribute(new CustomAttributeBuilder(ignoresAccessChecksToAttributeConstructor, $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Object), [$.$sris.SRIM.ComImportInteropInterfaceDetailsStrategy.IComImportAdapter.$type.Assembly.GetName().Name], [-1], null)));
                    /*TypeBuilder*/ let implementation = module.DefineType("InterfaceForwarder", 32/*TypeAttributes.Interface*/ | 128/*TypeAttributes.Abstract*/, null, runtimeType.GetInterfaces());
                    implementation.AddInterfaceImplementation(runtimeType);
                    implementation.SetCustomAttribute(new CustomAttributeBuilder($.$$.SRI.DynamicInterfaceCastableImplementationAttribute.$type.GetConstructor$4($.$$.S.Array.Empty($.$$.S.Type)), $.$$.S.Array.Empty($.$$.S.Object)));
                    let $i1 = 0;
                    let $arr1 = implementation.GetInterfaces();
                    while ($i1 < $arr1.length)
                    {
                        let iface = $arr1[$i1++];
                        assembly.SetCustomAttribute(new CustomAttributeBuilder(ignoresAccessChecksToAttributeConstructor, $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Object), [iface.Assembly.GetName().Name], [-1], null)));
                        let $i2 = 0;
                        let $arr2 = iface.GetMethods();
                        while ($i2 < $arr2.length)
                        {
                            let method = $arr2[$i2++];
                            /*Type[]*/ let returnTypeOptionalModifiers = method.ReturnParameter.GetOptionalCustomModifiers();
                            /*Type[]*/ let returnTypeRequiredModifiers = method.ReturnParameter.GetRequiredCustomModifiers();
                            /*ParameterInfo[]*/ let parameters = method.GetParameters();
                            /*var*/ let parameterTypes = $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Type), null, [parameters.length], null);
                            /*var*/ let parameterOptionalModifiers = $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$typeArray($.$$.S.Type)), null, [parameters.length], null);
                            /*var*/ let parameterRequiredModifiers = $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$typeArray($.$$.S.Type)), null, [parameters.length], null);
                            for(/*int*/ let i = 0; i < parameters.length; i++)
                            {
                                $.$$.System.Array.$WriteT1.call(parameterTypes, $.$$.System.Array.$ReadT1.call(parameters, i).ParameterType, i);
                                $.$$.System.Array.$WriteT1.call(parameterOptionalModifiers, $.$$.System.Array.$ReadT1.call(parameters, i).GetOptionalCustomModifiers(), i);
                                $.$$.System.Array.$WriteT1.call(parameterRequiredModifiers, $.$$.System.Array.$ReadT1.call(parameters, i).GetRequiredCustomModifiers(), i);
                            }
                            /*MethodBuilder*/ let builder = implementation.DefineMethod(method.Name, 1/*MethodAttributes.Private*/ | 32/*MethodAttributes.Final*/ | 128/*MethodAttributes.HideBySig*/ | 64/*MethodAttributes.Virtual*/, 32/*CallingConventions.HasThis*/, method.ReturnType, returnTypeRequiredModifiers, returnTypeOptionalModifiers, parameterTypes, parameterRequiredModifiers, parameterOptionalModifiers);
                            /*ILGenerator*/ let il = builder.GetILGenerator();
                            il.Emit(/*$.$$.SRE.OpCodes*/$.$$.DeletedObject.Ldarg_0);
                            il.Emit(/*$.$$.SRE.OpCodes*/$.$$.DeletedObject.Castclass, $.$sris.SRIM.ComImportInteropInterfaceDetailsStrategy.IComImportAdapter.$type);
                            il.Emit(/*$.$$.SRE.OpCodes*/$.$$.DeletedObject.Callvirt, $.$sris.SRIM.ComImportInteropInterfaceDetailsStrategy.IComImportAdapter.System$Runtime$InteropServices$Marshalling$ComImportInteropInterfaceDetailsStrategy$IComImportAdapter$GetRuntimeCallableWrapperMethod);
                            il.Emit(/*$.$$.SRE.OpCodes*/$.$$.DeletedObject.Castclass, iface);
                            for(/*int*/ let i = 0; i < parameters.length; i++)
                            {
                                il.Emit(/*$.$$.SRE.OpCodes*/$.$$.DeletedObject.Ldarg, ((i + 1) | 0));
                            }
                            il.Emit(/*$.$$.SRE.OpCodes*/$.$$.DeletedObject.Callvirt, method);
                            il.Emit(/*$.$$.SRE.OpCodes*/$.$$.DeletedObject.Ret);
                            implementation.DefineMethodOverride(builder, method);
                        }
                    }
                    return implementation.CreateType();
                }, $tdYAbj ??= {"r":188547073,"p":[{"n":"runtimeType","p":188547073}],"n":"","d":1835015,"h":0,"f":17825794}));
                return new $.$sris.SRIM.ComImportInteropInterfaceDetailsStrategy.ComImportDetails().$ctor$1(runtimeType.GUID, implementationType);
            }
            //--TRIMMABLE-BOUNDARY-END(30066606087)
            
            //--TRIMMABLE-BOUNDARY-START(25771638791)
            static /*ConstructorInfo */ GetIgnoresAccessChecksToAttributeConstructor(/*ModuleBuilder*/ moduleBuilder)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25771638791);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*Type*/ let attributeType = $.$sris.SRIM.ComImportInteropInterfaceDetailsStrategy.EmitIgnoresAccessChecksToAttribute(moduleBuilder);
                return attributeType.GetConstructor$4($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Type), [$.$$.S.String.$type], [-1], null));
            }
            //--TRIMMABLE-BOUNDARY-END(25771638791)
            
            //--TRIMMABLE-BOUNDARY-START(17181704199)
            static /*Type */ EmitIgnoresAccessChecksToAttribute(/*ModuleBuilder*/ moduleBuilder)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17181704199);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let tb = moduleBuilder.DefineType("System.Runtime.CompilerServices.IgnoresAccessChecksToAttribute", 0/*TypeAttributes.NotPublic*/, $.$$.S.Attribute.$type);
                /*var*/ let attributeUsage = new CustomAttributeBuilder($.$sris.SRIM.ComImportInteropInterfaceDetailsStrategy.s_attributeUsageCtor, $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Object), [$.$box(1/*AttributeTargets.Assembly*/, $.$$.S.AttributeTargets)], [-1], null), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.SR.PropertyInfo), [$.$sris.SRIM.ComImportInteropInterfaceDetailsStrategy.s_attributeUsageAllowMultipleProperty], [-1], null), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Object), [$.$box(true, $.$$.S.Boolean)], [-1], null));
                tb.SetCustomAttribute(attributeUsage);
                /*var*/ let cb = tb.DefineConstructor(6/*MethodAttributes.Public*/ | 128/*MethodAttributes.HideBySig*/ | 2048/*MethodAttributes.SpecialName*/ | 4096/*MethodAttributes.RTSpecialName*/, 1/*CallingConventions.Standard*/, $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Type), [$.$$.S.String.$type], [-1], null));
                cb.DefineParameter(1, 0/*ParameterAttributes.None*/, "assemblyName");
                /*var*/ let il = cb.GetILGenerator();
                il.Emit(/*$.$$.SRE.OpCodes*/$.$$.DeletedObject.Ldarg_0);
                il.Emit(/*$.$$.SRE.OpCodes*/$.$$.DeletedObject.Call, $.$sris.SRIM.ComImportInteropInterfaceDetailsStrategy.s_attributeBaseClassCtor);
                il.Emit(/*$.$$.SRE.OpCodes*/$.$$.DeletedObject.Ret);
                return tb.CreateType();
            }
            //--TRIMMABLE-BOUNDARY-END(17181704199)
            
            //--TRIMMABLE-BOUNDARY-START(38656540679)
            /*ConstructorInfo*/ static s_attributeBaseClassCtor = null;
            //--TRIMMABLE-BOUNDARY-END(38656540679)
            
            //--TRIMMABLE-BOUNDARY-START(47246475271)
            /*ConstructorInfo*/ static s_attributeUsageCtor = null;
            //--TRIMMABLE-BOUNDARY-END(47246475271)
            
            //--TRIMMABLE-BOUNDARY-START(42951507975)
            /*PropertyInfo*/ static s_attributeUsageAllowMultipleProperty = null;
            //--TRIMMABLE-BOUNDARY-END(42951507975)
            
            //--TRIMMABLE-BOUNDARY-START(1900551)
            static $_ComImportDetails;
            static get ComImportDetails()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(1900551);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                let $cls = $.$sris.SRIM.ComImportInteropInterfaceDetailsStrategy;
                return $cls.$_ComImportDetails ??= $asm.$ncls(`$sris.SRIM.ComImportInteropInterfaceDetailsStrategy.ComImportDetails`, ($self) => class ComImportDetails extends $.$$.S.Object
                {
                    //--TRIMMABLE-BOUNDARY-START(42951573511)
                    /*Guid*/ Iid;
                    //--TRIMMABLE-BOUNDARY-END(42951573511)
                    
                    //--TRIMMABLE-BOUNDARY-START(47246540807)
                    /*Type*/ Implementation = null;
                    //--TRIMMABLE-BOUNDARY-END(47246540807)
                    
                    //--TRIMMABLE-BOUNDARY-START(51541508103)
                    /*void** */ get ManagedVirtualMethodTable()
                    {
                        return null;
                    }
                    //--TRIMMABLE-BOUNDARY-END(51541508103)
                    
                    //--TRIMMABLE-BOUNDARY-START(8593145863)
                    //Generated interface implemetation for System.Runtime.InteropServices.Marshalling.IIUnknownDerivedDetails.Iid.get
                    get SRIM$IIUnknownDerivedDetails$Iid()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(34362949639);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return this.Iid;
                    }
                    //--TRIMMABLE-BOUNDARY-END(8593145863)
                    
                    //--TRIMMABLE-BOUNDARY-START(17183080455)
                    //Generated interface implemetation for System.Runtime.InteropServices.Marshalling.IIUnknownDerivedDetails.Implementation.get
                    get SRIM$IIUnknownDerivedDetails$Implementation()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(38657916935);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return this.Implementation;
                    }
                    //--TRIMMABLE-BOUNDARY-END(17183080455)
                    
                    //--TRIMMABLE-BOUNDARY-START(25773015047)
                    //Generated interface implemetation for System.Runtime.InteropServices.Marshalling.IIUnknownDerivedDetails.ManagedVirtualMethodTable.get
                    get SRIM$IIUnknownDerivedDetails$ManagedVirtualMethodTable()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(42952884231);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return this.ManagedVirtualMethodTable;
                    }
                    //--TRIMMABLE-BOUNDARY-END(25773015047)
                    
                    //Begin primary constructor
                    /*Guid*/ iid = new $.$$.S.Guid();
                    /*Type*/ implementation = null;
                    $ctor$1(/*Guid*/iid, /*Type*/implementation)
                    {
                        this.iid = iid;
                        this.implementation = implementation;
                        super.$ctor();
                        //--TRIMMABLE-BOUNDARY-START(42951573511)
                        //depends on primary constructor parameter
                        this.Iid = this.iid;
                        //--TRIMMABLE-BOUNDARY-END(42951573511)
                        
                        //--TRIMMABLE-BOUNDARY-START(47246540807)
                        //depends on primary constructor parameter
                        this.Implementation = this.implementation;
                        //--TRIMMABLE-BOUNDARY-END(47246540807)
                        
                        return this
                    }
                    //End primary constructor
                    static $h = 1900551;
                    static $f = 0b10000000010010000;
                    static $k = 1;
                    static $$b;
                    static get $b() { return this.$$b ??= $.$$.S.Object; }
                    static $$md;
                    static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(42951573511),
    {
      "p": 89784321,
      "g": {
        "r": 0,
        "d": 0,
        "h": 21476737031,
        "f": 50331649
      },
      "n": "Iid",
      "d": 1900551,
      "h": 42951573511,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(42951573511),
//--TRIMMABLE-BOUNDARY-START(47246540807),
    {
      "p": 188547073,
      "g": {
        "r": 0,
        "d": 0,
        "h": 30066671623,
        "f": 50331649
      },
      "n": "Implementation",
      "d": 1900551,
      "h": 47246540807,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(47246540807),
//--TRIMMABLE-BOUNDARY-START(51541508103),
    {
      "p": $.$typePointer($.$typePointer($.$$.S.Void)).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 38656606215,
        "f": 50331649
      },
      "n": "ManagedVirtualMethodTable",
      "d": 1900551,
      "h": 51541508103,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(51541508103)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(12886802439),
    {
      "p": [
        {
          "n": "iid",
          "p": 89784321
        },
        {
          "n": "implementation",
          "p": 188547073
        }
      ],
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 1900551,
      "h": 12886802439,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(12886802439)
  ],
  "d": 1835015,
  "h": 1900551
}; }
                    static $$i;
                    static get $i() { return this.$$i ??= [ $.$sris.SRIM.IIUnknownDerivedDetails ]; }
                    static $$fullName;
                    static get $fullName() { return this.$$fullName ??= `System.Runtime.InteropServices.Marshalling.ComImportInteropInterfaceDetailsStrategy+ComImportDetails`; }
                    static $$getFullName = {};
                    static $getFullName(separator) { return this.$$getFullName[separator] ??= `System${separator}Runtime${separator}InteropServices${separator}Marshalling${separator}ComImportInteropInterfaceDetailsStrategy${separator}ComImportDetails`; }
                }, $cls, ($v) => $cls.$_ComImportDetails = $v);
            }
            //--TRIMMABLE-BOUNDARY-END(1900551)
            
            //--TRIMMABLE-BOUNDARY-START(1966087)
            static $_IComImportAdapter;
            static get IComImportAdapter()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(1966087);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                let $cls = $.$sris.SRIM.ComImportInteropInterfaceDetailsStrategy;
                return $cls.$_IComImportAdapter ??= $asm.$ncls(`$sris.SRIM.ComImportInteropInterfaceDetailsStrategy.IComImportAdapter`, ($self) => class IComImportAdapter
                {
                    //--TRIMMABLE-BOUNDARY-START(12886867975)
                    /*MethodInfo*/ static System$Runtime$InteropServices$Marshalling$ComImportInteropInterfaceDetailsStrategy$IComImportAdapter$GetRuntimeCallableWrapperMethod = null;
                    //--TRIMMABLE-BOUNDARY-END(12886867975)
                    
                    //--TRIMMABLE-BOUNDARY-START(4296933383)
                    //Static Initializer
                    static $sinit()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(4296933383);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        {
                            //--TRIMMABLE-BOUNDARY-START(12886867975)
                            this.System$Runtime$InteropServices$Marshalling$ComImportInteropInterfaceDetailsStrategy$IComImportAdapter$GetRuntimeCallableWrapperMethod = $.$sris.SRIM.ComImportInteropInterfaceDetailsStrategy.IComImportAdapter.$type.GetMethod$12("GetRuntimeCallableWrapper");
                            //--TRIMMABLE-BOUNDARY-END(12886867975)
                            
                        }
                    }
                    //--TRIMMABLE-BOUNDARY-END(4296933383)
                    
                    static $h = 1966087;
                    static $f = 0b10000000000100100;
                    static $k = 3;
                    static $$md;
                    static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8591900679),
    {
      "r": 131073,
      "n": "GetRuntimeCallableWrapper",
      "o": "SRIM$ComImportInteropInterfaceDetailsStrategy$IComImportAdapter$GetRuntimeCallableWrapper",
      "d": 1966087,
      "h": 8591900679,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(8591900679)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(12886867975),
    {
      "t": 117571585,
      "n": "GetRuntimeCallableWrapperMethod",
      "o": "System$Runtime$InteropServices$Marshalling$ComImportInteropInterfaceDetailsStrategy$IComImportAdapter$GetRuntimeCallableWrapperMethod",
      "d": 1966087,
      "h": 12886867975,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(12886867975)
  ],
  "d": 1835015,
  "h": 1966087
}; }
                    static $$fullName;
                    static get $fullName() { return this.$$fullName ??= `System.Runtime.InteropServices.Marshalling.ComImportInteropInterfaceDetailsStrategy+IComImportAdapter`; }
                    static $$getFullName = {};
                    static $getFullName(separator) { return this.$$getFullName[separator] ??= `System${separator}Runtime${separator}InteropServices${separator}Marshalling${separator}ComImportInteropInterfaceDetailsStrategy${separator}IComImportAdapter`; }
                }, $cls, ($v) => $cls.$_IComImportAdapter = $v);
            }
            //--TRIMMABLE-BOUNDARY-END(1966087)
            
            //--TRIMMABLE-BOUNDARY-START(8593211399)
            //Generated interface implemetation for System.Runtime.InteropServices.Marshalling.IIUnknownInterfaceDetailsStrategy.GetIUnknownDerivedDetails(System.RuntimeTypeHandle)
            SRIM$IIUnknownInterfaceDetailsStrategy$GetIUnknownDerivedDetails()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8593211399);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.GetIUnknownDerivedDetails(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(8593211399)
            
            //--TRIMMABLE-BOUNDARY-START(4298244103)
            //Generated interface implemetation for System.Runtime.InteropServices.Marshalling.IIUnknownInterfaceDetailsStrategy.GetComExposedTypeDetails(System.RuntimeTypeHandle)
            SRIM$IIUnknownInterfaceDetailsStrategy$GetComExposedTypeDetails()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4298244103);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.GetComExposedTypeDetails(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4298244103)
            
            //--TRIMMABLE-BOUNDARY-START(12886736903)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12886736903);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(12886736903)
            
            //--TRIMMABLE-BOUNDARY-START(12886736903)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(12886736903)
            
            //default member initializer
            constructor()
            {
                super();
                //--TRIMMABLE-BOUNDARY-START(4296802311)
                this._forwarderInterfaceCache = new ($.$$.SRC.ConditionalWeakTable$$$($.$$.S.Type, $.$$.S.Type))().$ctor$1();
                //--TRIMMABLE-BOUNDARY-END(4296802311)
                
            }
            //--TRIMMABLE-BOUNDARY-START(8591769607)
            //Static Initializer
            static $sinit()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591769607);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                {
                    //--TRIMMABLE-BOUNDARY-START(34361573383)
                    this.Instance = new $.$sris.SRIM.ComImportInteropInterfaceDetailsStrategy().$ctor$1();
                    //--TRIMMABLE-BOUNDARY-END(34361573383)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(38656540679)
                    this.s_attributeBaseClassCtor = $.$$.System.Array.$ReadT1.call($.$$.S.Attribute.$type.GetConstructors$1(32/*BindingFlags.NonPublic*/ | 4/*BindingFlags.Instance*/), 0);
                    //--TRIMMABLE-BOUNDARY-END(38656540679)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(47246475271)
                    this.s_attributeUsageCtor = $.$$.S.AttributeUsageAttribute.$type.GetConstructor$4($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Type), [$.$$.S.AttributeTargets.$type], [-1], null));
                    //--TRIMMABLE-BOUNDARY-END(47246475271)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(42951507975)
                    this.s_attributeUsageAllowMultipleProperty = $.$$.S.AttributeUsageAttribute.$type.GetProperty$6("AllowMultiple");
                    //--TRIMMABLE-BOUNDARY-END(42951507975)
                    
                }
            }
            //--TRIMMABLE-BOUNDARY-END(8591769607)
            
            static $h = 1835015;
            static $f = 0b10010000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(21476671495),
    {
      "r": 3014663,
      "p": [
        {
          "n": "type",
          "p": 160956417
        }
      ],
      "n": "GetComExposedTypeDetails",
      "d": 1835015,
      "h": 21476671495,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(21476671495),
//--TRIMMABLE-BOUNDARY-START(30066606087),
    {
      "r": 3211271,
      "p": [
        {
          "n": "type",
          "p": 160956417
        }
      ],
      "n": "GetIUnknownDerivedDetails",
      "d": 1835015,
      "h": 30066606087,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(30066606087),
//--TRIMMABLE-BOUNDARY-START(25771638791),
    {
      "r": 109182977,
      "p": [
        {
          "n": "moduleBuilder"
        }
      ],
      "n": "GetIgnoresAccessChecksToAttributeConstructor",
      "d": 1835015,
      "h": 25771638791,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(25771638791),
//--TRIMMABLE-BOUNDARY-START(17181704199),
    {
      "r": 188547073,
      "p": [
        {
          "n": "moduleBuilder"
        }
      ],
      "n": "EmitIgnoresAccessChecksToAttribute",
      "d": 1835015,
      "h": 17181704199,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(17181704199)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(34361573383),
    {
      "t": 3276807,
      "n": "Instance",
      "d": 1835015,
      "h": 34361573383,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(34361573383),
//--TRIMMABLE-BOUNDARY-START(4296802311),
    {
      "t": $.$$.SRC.ConditionalWeakTable$$$($.$$.S.Type, $.$$.S.Type).$h,
      "n": "_forwarderInterfaceCache",
      "d": 1835015,
      "h": 4296802311,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(4296802311),
//--TRIMMABLE-BOUNDARY-START(38656540679),
    {
      "t": 109182977,
      "n": "s_attributeBaseClassCtor",
      "d": 1835015,
      "h": 38656540679,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(38656540679),
//--TRIMMABLE-BOUNDARY-START(47246475271),
    {
      "t": 109182977,
      "n": "s_attributeUsageCtor",
      "d": 1835015,
      "h": 47246475271,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(47246475271),
//--TRIMMABLE-BOUNDARY-START(42951507975),
    {
      "t": 119603201,
      "n": "s_attributeUsageAllowMultipleProperty",
      "d": 1835015,
      "h": 42951507975,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(42951507975)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(12886736903),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 1835015,
      "h": 12886736903,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(12886736903)
  ],
  "h": 1835015
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$sris.SRIM.IIUnknownInterfaceDetailsStrategy ]; }
            static $$n;
            static get $n() { return this.$$n ??= [ $.$sris.SRIM.ComImportInteropInterfaceDetailsStrategy.ComImportDetails, $.$sris.SRIM.ComImportInteropInterfaceDetailsStrategy.IComImportAdapter ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `System.Runtime.InteropServices.Marshalling.ComImportInteropInterfaceDetailsStrategy`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `System${separator}Runtime${separator}InteropServices${separator}Marshalling${separator}ComImportInteropInterfaceDetailsStrategy`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1835015)
        
        

        //--TRIMMABLE-BOUNDARY-START(589831)
        $asm.$cls(`$sris.SRI.ComConversionLossAttribute`, ($self) => class ComConversionLossAttribute extends $.$$.S.Attribute
        {
            //--TRIMMABLE-BOUNDARY-START(4295557127)
            //default constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295557127);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295557127)
            
            //--TRIMMABLE-BOUNDARY-START(4295557127)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$2();
            }
            //--TRIMMABLE-BOUNDARY-END(4295557127)
            
            static $h = 589831;
            static $f = 0b10010001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Attribute; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295557127),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 589831,
      "h": 4295557127,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295557127)
  ],
  "h": 589831,
  "a": [
    {
      "t": 46202881,
      "c": 25816006657,
      "a": [
        {
          "v": 32767,
          "t": 46137345
        }
      ],
      "n": [
        {
          "n": "Inherited",
          "v": false,
          "t": 262145
        }
      ]
    }
  ]
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `System.Runtime.InteropServices.ComConversionLossAttribute`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `System${separator}Runtime${separator}InteropServices${separator}ComConversionLossAttribute`; }
        });
        //--TRIMMABLE-BOUNDARY-END(589831)
        
        

        //--TRIMMABLE-BOUNDARY-START(655367)
        $asm.$cls(`$sris.SRI.ComRegisterFunctionAttribute`, ($self) => class ComRegisterFunctionAttribute extends $.$$.S.Attribute
        {
            //--TRIMMABLE-BOUNDARY-START(4295622663)
            //default constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295622663);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295622663)
            
            //--TRIMMABLE-BOUNDARY-START(4295622663)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$2();
            }
            //--TRIMMABLE-BOUNDARY-END(4295622663)
            
            static $h = 655367;
            static $f = 0b10010001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Attribute; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295622663),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 655367,
      "h": 4295622663,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295622663)
  ],
  "h": 655367,
  "a": [
    {
      "t": 46202881,
      "c": 25816006657,
      "a": [
        {
          "v": 64,
          "t": 46137345
        }
      ],
      "n": [
        {
          "n": "Inherited",
          "v": false,
          "t": 262145
        }
      ]
    }
  ]
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `System.Runtime.InteropServices.ComRegisterFunctionAttribute`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `System${separator}Runtime${separator}InteropServices${separator}ComRegisterFunctionAttribute`; }
        });
        //--TRIMMABLE-BOUNDARY-END(655367)
        
        

        //--TRIMMABLE-BOUNDARY-START(1245191)
        $asm.$str(`$sris.SRIC.STATDATA`, ($self) => class STATDATA extends $.$$.S.ValueType
        {
            //--TRIMMABLE-BOUNDARY-START(21476081671)
            /*FORMATETC*/ formatetc;
            //--TRIMMABLE-BOUNDARY-END(21476081671)
            
            //--TRIMMABLE-BOUNDARY-START(8591179783)
            /*ADVF*/ advf = 0;
            //--TRIMMABLE-BOUNDARY-END(8591179783)
            
            //--TRIMMABLE-BOUNDARY-START(12886147079)
            /*IAdviseSink*/ advSink = null;
            //--TRIMMABLE-BOUNDARY-END(12886147079)
            
            //--TRIMMABLE-BOUNDARY-START(17181114375)
            /*int*/ connection = 0;
            //--TRIMMABLE-BOUNDARY-END(17181114375)
            
            //--TRIMMABLE-BOUNDARY-START(4296212487)
            //default constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296212487);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296212487)
            
            //--TRIMMABLE-BOUNDARY-START(4296212487)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$2();
            }
            //--TRIMMABLE-BOUNDARY-END(4296212487)
            
            $clone($copy)
            {
                let copy = $copy ?? new this.constructor();
                copy.formatetc = this.formatetc.$clone();
                copy.advf = this.advf;
                copy.advSink = this.advSink;
                copy.connection = this.connection;
                return copy;
            }
            //default member initializer
            constructor()
            {
                super();
                //--TRIMMABLE-BOUNDARY-START(21476081671)
                this.formatetc = $.$default($.$sris.SRIC.FORMATETC);
                //--TRIMMABLE-BOUNDARY-END(21476081671)
                
            }
            static $h = 1245191;
            static $z = 30;
            static $f = 0b1010000001;
            static $k = 2;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.ValueType; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "l": [
//--TRIMMABLE-BOUNDARY-START(21476081671),
    {
      "t": 917511,
      "n": "formatetc",
      "d": 1245191,
      "h": 21476081671,
      "f": 4194305
    },
//--TRIMMABLE-BOUNDARY-END(21476081671),
//--TRIMMABLE-BOUNDARY-START(8591179783),
    {
      "t": 720903,
      "n": "advf",
      "d": 1245191,
      "h": 8591179783,
      "f": 4194305
    },
//--TRIMMABLE-BOUNDARY-END(8591179783),
//--TRIMMABLE-BOUNDARY-START(12886147079),
    {
      "t": 983047,
      "n": "advSink",
      "d": 1245191,
      "h": 12886147079,
      "f": 4194305
    },
//--TRIMMABLE-BOUNDARY-END(12886147079),
//--TRIMMABLE-BOUNDARY-START(17181114375),
    {
      "t": 655361,
      "n": "connection",
      "d": 1245191,
      "h": 17181114375,
      "f": 4194305
    },
//--TRIMMABLE-BOUNDARY-END(17181114375)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296212487),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 1245191,
      "h": 4296212487,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296212487)
  ],
  "h": 1245191,
  "a": [
    {
      "t": 65011713,
      "c": 12949913601,
      "a": [
        {
          "v": 1,
          "t": 65077249
        }
      ]
    }
  ]
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `System.Runtime.InteropServices.ComTypes.STATDATA`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `System${separator}Runtime${separator}InteropServices${separator}ComTypes${separator}STATDATA`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1245191)
        
        

        //--TRIMMABLE-BOUNDARY-START(1310727)
        $asm.$str(`$sris.SRIC.STGMEDIUM`, ($self) => class STGMEDIUM extends $.$$.S.ValueType
        {
            //--TRIMMABLE-BOUNDARY-START(12886212615)
            /*TYMED*/ tymed = 0;
            //--TRIMMABLE-BOUNDARY-END(12886212615)
            
            //--TRIMMABLE-BOUNDARY-START(17181179911)
            /*IntPtr*/ unionmember = 0;
            //--TRIMMABLE-BOUNDARY-END(17181179911)
            
            //--TRIMMABLE-BOUNDARY-START(8591245319)
            /*object?*/ pUnkForRelease = null;
            //--TRIMMABLE-BOUNDARY-END(8591245319)
            
            //--TRIMMABLE-BOUNDARY-START(4296278023)
            //default constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296278023);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296278023)
            
            //--TRIMMABLE-BOUNDARY-START(4296278023)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$2();
            }
            //--TRIMMABLE-BOUNDARY-END(4296278023)
            
            $clone($copy)
            {
                let copy = $copy ?? new this.constructor();
                copy.tymed = this.tymed;
                copy.unionmember = this.unionmember;
                copy.pUnkForRelease = this.pUnkForRelease;
                return copy;
            }
            static $h = 1310727;
            static $z = 12;
            static $f = 0b1010000001;
            static $k = 2;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.ValueType; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "l": [
//--TRIMMABLE-BOUNDARY-START(12886212615),
    {
      "t": 1376263,
      "n": "tymed",
      "d": 1310727,
      "h": 12886212615,
      "f": 4194305
    },
//--TRIMMABLE-BOUNDARY-END(12886212615),
//--TRIMMABLE-BOUNDARY-START(17181179911),
    {
      "t": 786433,
      "n": "unionmember",
      "d": 1310727,
      "h": 17181179911,
      "f": 4194305
    },
//--TRIMMABLE-BOUNDARY-END(17181179911),
//--TRIMMABLE-BOUNDARY-START(8591245319),
    {
      "t": 131073,
      "n": "pUnkForRelease",
      "d": 1310727,
      "h": 8591245319,
      "f": 4194305,
      "a": [
        {
          "t": 143982593,
          "c": 13028884481,
          "a": [
            {
              "v": 25,
              "t": 149159937
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(8591245319)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296278023),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 1310727,
      "h": 4296278023,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296278023)
  ],
  "h": 1310727,
  "a": [
    {
      "t": 65011713,
      "c": 12949913601,
      "a": [
        {
          "v": 1,
          "t": 65077249
        }
      ]
    }
  ]
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `System.Runtime.InteropServices.ComTypes.STGMEDIUM`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `System${separator}Runtime${separator}InteropServices${separator}ComTypes${separator}STGMEDIUM`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1310727)
        
        

        //--TRIMMABLE-BOUNDARY-START(327687)
        $asm.$cls(`$sris.SRI.AutomationProxyAttribute`, ($self) => class AutomationProxyAttribute extends $.$$.S.Attribute
        {
            //--TRIMMABLE-BOUNDARY-START(8590262279)
            $ctor$2(/*bool*/ val)
            {
                super.$ctor$1();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(8590262279);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this.Value = val;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(8590262279)
            
            //--TRIMMABLE-BOUNDARY-START(21475164167)
            /*bool*/ Value = false;
            //--TRIMMABLE-BOUNDARY-END(21475164167)
            
            static $h = 327687;
            static $f = 0b10010001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Attribute; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(21475164167),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 17180196871,
        "f": 50331649
      },
      "n": "Value",
      "d": 327687,
      "h": 21475164167,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(21475164167)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(8590262279),
    {
      "p": [
        {
          "n": "val",
          "p": 262145
        }
      ],
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 327687,
      "h": 8590262279,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8590262279)
  ],
  "h": 327687,
  "a": [
    {
      "t": 46202881,
      "c": 25816006657,
      "a": [
        {
          "v": 1029,
          "t": 46137345
        }
      ],
      "n": [
        {
          "n": "Inherited",
          "v": false,
          "t": 262145
        }
      ]
    }
  ]
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `System.Runtime.InteropServices.AutomationProxyAttribute`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `System${separator}Runtime${separator}InteropServices${separator}AutomationProxyAttribute`; }
        });
        //--TRIMMABLE-BOUNDARY-END(327687)
        
        

        //--TRIMMABLE-BOUNDARY-START(1638407)
        $asm.$cls(`$sris.SRI.ImportedFromTypeLibAttribute`, ($self) => class ImportedFromTypeLibAttribute extends $.$$.S.Attribute
        {
            //--TRIMMABLE-BOUNDARY-START(8591572999)
            $ctor$2(/*string*/ tlbFile)
            {
                super.$ctor$1();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(8591572999);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this.Value = tlbFile;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(8591572999)
            
            //--TRIMMABLE-BOUNDARY-START(21476474887)
            /*string*/ Value = null;
            //--TRIMMABLE-BOUNDARY-END(21476474887)
            
            static $h = 1638407;
            static $f = 0b10010001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Attribute; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(21476474887),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 17181507591,
        "f": 50331649
      },
      "n": "Value",
      "d": 1638407,
      "h": 21476474887,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(21476474887)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(8591572999),
    {
      "p": [
        {
          "n": "tlbFile",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 1638407,
      "h": 8591572999,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8591572999)
  ],
  "h": 1638407,
  "a": [
    {
      "t": 46202881,
      "c": 25816006657,
      "a": [
        {
          "v": 1,
          "t": 46137345
        }
      ],
      "n": [
        {
          "n": "Inherited",
          "v": false,
          "t": 262145
        }
      ]
    }
  ]
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `System.Runtime.InteropServices.ImportedFromTypeLibAttribute`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `System${separator}Runtime${separator}InteropServices${separator}ImportedFromTypeLibAttribute`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1638407)
        
        

        //--TRIMMABLE-BOUNDARY-START(917511)
        $asm.$str(`$sris.SRIC.FORMATETC`, ($self) => class FORMATETC extends $.$$.S.ValueType
        {
            //--TRIMMABLE-BOUNDARY-START(8590852103)
            /*short*/ cfFormat = 0;
            //--TRIMMABLE-BOUNDARY-END(8590852103)
            
            //--TRIMMABLE-BOUNDARY-START(21475753991)
            /*IntPtr*/ ptd = 0;
            //--TRIMMABLE-BOUNDARY-END(21475753991)
            
            //--TRIMMABLE-BOUNDARY-START(12885819399)
            /*DVASPECT*/ dwAspect = 0;
            //--TRIMMABLE-BOUNDARY-END(12885819399)
            
            //--TRIMMABLE-BOUNDARY-START(17180786695)
            /*int*/ lindex = 0;
            //--TRIMMABLE-BOUNDARY-END(17180786695)
            
            //--TRIMMABLE-BOUNDARY-START(25770721287)
            /*TYMED*/ tymed = 0;
            //--TRIMMABLE-BOUNDARY-END(25770721287)
            
            //--TRIMMABLE-BOUNDARY-START(4295884807)
            //default constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295884807);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295884807)
            
            //--TRIMMABLE-BOUNDARY-START(4295884807)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$2();
            }
            //--TRIMMABLE-BOUNDARY-END(4295884807)
            
            $clone($copy)
            {
                let copy = $copy ?? new this.constructor();
                copy.cfFormat = this.cfFormat;
                copy.ptd = this.ptd;
                copy.dwAspect = this.dwAspect;
                copy.lindex = this.lindex;
                copy.tymed = this.tymed;
                return copy;
            }
            static $h = 917511;
            static $z = 18;
            static $f = 0b10000000000001010000001;
            static $k = 2;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.ValueType; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "l": [
//--TRIMMABLE-BOUNDARY-START(8590852103),
    {
      "t": 524289,
      "n": "cfFormat",
      "d": 917511,
      "h": 8590852103,
      "f": 4194305,
      "a": [
        {
          "t": 143982593,
          "c": 13028884481,
          "a": [
            {
              "v": 6,
              "t": 149159937
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(8590852103),
//--TRIMMABLE-BOUNDARY-START(21475753991),
    {
      "t": 786433,
      "n": "ptd",
      "d": 917511,
      "h": 21475753991,
      "f": 4194305
    },
//--TRIMMABLE-BOUNDARY-END(21475753991),
//--TRIMMABLE-BOUNDARY-START(12885819399),
    {
      "t": 851975,
      "n": "dwAspect",
      "d": 917511,
      "h": 12885819399,
      "f": 4194305,
      "a": [
        {
          "t": 143982593,
          "c": 13028884481,
          "a": [
            {
              "v": 8,
              "t": 149159937
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(12885819399),
//--TRIMMABLE-BOUNDARY-START(17180786695),
    {
      "t": 655361,
      "n": "lindex",
      "d": 917511,
      "h": 17180786695,
      "f": 4194305
    },
//--TRIMMABLE-BOUNDARY-END(17180786695),
//--TRIMMABLE-BOUNDARY-START(25770721287),
    {
      "t": 1376263,
      "n": "tymed",
      "d": 917511,
      "h": 25770721287,
      "f": 4194305,
      "a": [
        {
          "t": 143982593,
          "c": 13028884481,
          "a": [
            {
              "v": 8,
              "t": 149159937
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(25770721287)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295884807),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 917511,
      "h": 4295884807,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295884807)
  ],
  "h": 917511,
  "a": [
    {
      "t": 65011713,
      "c": 12949913601,
      "a": [
        {
          "v": 1,
          "t": 65077249
        }
      ]
    }
  ]
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `System.Runtime.InteropServices.ComTypes.FORMATETC`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `System${separator}Runtime${separator}InteropServices${separator}ComTypes${separator}FORMATETC`; }
        });
        //--TRIMMABLE-BOUNDARY-END(917511)
        
        

        //--TRIMMABLE-BOUNDARY-START(1441799)
        $asm.$cls(`$sris.SRI.ComUnregisterFunctionAttribute`, ($self) => class ComUnregisterFunctionAttribute extends $.$$.S.Attribute
        {
            //--TRIMMABLE-BOUNDARY-START(4296409095)
            //default constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296409095);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296409095)
            
            //--TRIMMABLE-BOUNDARY-START(4296409095)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$2();
            }
            //--TRIMMABLE-BOUNDARY-END(4296409095)
            
            static $h = 1441799;
            static $f = 0b10010001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Attribute; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296409095),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 1441799,
      "h": 4296409095,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296409095)
  ],
  "h": 1441799,
  "a": [
    {
      "t": 46202881,
      "c": 25816006657,
      "a": [
        {
          "v": 64,
          "t": 46137345
        }
      ],
      "n": [
        {
          "n": "Inherited",
          "v": false,
          "t": 262145
        }
      ]
    }
  ]
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `System.Runtime.InteropServices.ComUnregisterFunctionAttribute`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `System${separator}Runtime${separator}InteropServices${separator}ComUnregisterFunctionAttribute`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1441799)
        
        

        //--TRIMMABLE-BOUNDARY-START(393223)
        $asm.$cls(`$sris.SRI.ComAliasNameAttribute`, ($self) => class ComAliasNameAttribute extends $.$$.S.Attribute
        {
            //--TRIMMABLE-BOUNDARY-START(8590327815)
            $ctor$2(/*string*/ alias)
            {
                super.$ctor$1();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(8590327815);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this.Value = alias;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(8590327815)
            
            //--TRIMMABLE-BOUNDARY-START(21475229703)
            /*string*/ Value = null;
            //--TRIMMABLE-BOUNDARY-END(21475229703)
            
            static $h = 393223;
            static $f = 0b10010001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Attribute; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(21475229703),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 17180262407,
        "f": 50331649
      },
      "n": "Value",
      "d": 393223,
      "h": 21475229703,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(21475229703)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(8590327815),
    {
      "p": [
        {
          "n": "alias",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 393223,
      "h": 8590327815,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8590327815)
  ],
  "h": 393223,
  "a": [
    {
      "t": 46202881,
      "c": 25816006657,
      "a": [
        {
          "v": 10624,
          "t": 46137345
        }
      ],
      "n": [
        {
          "n": "Inherited",
          "v": false,
          "t": 262145
        }
      ]
    }
  ]
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `System.Runtime.InteropServices.ComAliasNameAttribute`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `System${separator}Runtime${separator}InteropServices${separator}ComAliasNameAttribute`; }
        });
        //--TRIMMABLE-BOUNDARY-END(393223)
        
        

        //--TRIMMABLE-BOUNDARY-START(2818055)
        $asm.$cls(`$sris.SRIM.GeneratedComClassAttribute`, ($self) => class GeneratedComClassAttribute extends $.$$.S.Attribute
        {
            //--TRIMMABLE-BOUNDARY-START(4297785351)
            //default constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4297785351);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4297785351)
            
            //--TRIMMABLE-BOUNDARY-START(4297785351)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$2();
            }
            //--TRIMMABLE-BOUNDARY-END(4297785351)
            
            static $h = 2818055;
            static $f = 0b10010001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Attribute; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4297785351),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 2818055,
      "h": 4297785351,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4297785351)
  ],
  "h": 2818055,
  "a": [
    {
      "t": 46202881,
      "c": 25816006657,
      "a": [
        {
          "v": 4,
          "t": 46137345
        }
      ]
    }
  ]
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `System.Runtime.InteropServices.Marshalling.GeneratedComClassAttribute`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `System${separator}Runtime${separator}InteropServices${separator}Marshalling${separator}GeneratedComClassAttribute`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2818055)
        
        

        //--TRIMMABLE-BOUNDARY-START(4390919)
        $asm.$cls(`$sris.SRI.TypeLibVarAttribute`, ($self) => class TypeLibVarAttribute extends $.$$.S.Attribute
        {
            //--TRIMMABLE-BOUNDARY-START(12889292807)
            $ctor$3(/*TypeLibVarFlags*/ flags)
            {
                super.$ctor$1();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(12889292807);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this.Value = flags;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(12889292807)
            
            //--TRIMMABLE-BOUNDARY-START(8594325511)
            $ctor$2(/*short*/ flags)
            {
                super.$ctor$1();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(8594325511);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this.Value = $.$cast(flags, $.$sris.SRI.TypeLibVarFlags);
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(8594325511)
            
            //--TRIMMABLE-BOUNDARY-START(25774194695)
            /*TypeLibVarFlags*/ Value = 0;
            //--TRIMMABLE-BOUNDARY-END(25774194695)
            
            static $h = 4390919;
            static $f = 0b10010001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Attribute; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(25774194695),
    {
      "p": 4456455,
      "g": {
        "r": 0,
        "d": 0,
        "h": 21479227399,
        "f": 50331649
      },
      "n": "Value",
      "d": 4390919,
      "h": 25774194695,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(25774194695)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(12889292807),
    {
      "p": [
        {
          "n": "flags",
          "p": 4456455
        }
      ],
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 4390919,
      "h": 12889292807,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(12889292807),
//--TRIMMABLE-BOUNDARY-START(8594325511),
    {
      "p": [
        {
          "n": "flags",
          "p": 524289
        }
      ],
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 4390919,
      "h": 8594325511,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8594325511)
  ],
  "h": 4390919,
  "a": [
    {
      "t": 46202881,
      "c": 25816006657,
      "a": [
        {
          "v": 256,
          "t": 46137345
        }
      ],
      "n": [
        {
          "n": "Inherited",
          "v": false,
          "t": 262145
        }
      ]
    }
  ]
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `System.Runtime.InteropServices.TypeLibVarAttribute`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `System${separator}Runtime${separator}InteropServices${separator}TypeLibVarAttribute`; }
        });
        //--TRIMMABLE-BOUNDARY-END(4390919)
        
        

        //--TRIMMABLE-BOUNDARY-START(4521991)
        $asm.$cls(`$sris.SRI.TypeLibVersionAttribute`, ($self) => class TypeLibVersionAttribute extends $.$$.S.Attribute
        {
            //--TRIMMABLE-BOUNDARY-START(12889423879)
            $ctor$2(/*int*/ major, /*int*/ minor)
            {
                super.$ctor$1();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(12889423879);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this.MajorVersion = major;
                    this.MinorVersion = minor;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(12889423879)
            
            //--TRIMMABLE-BOUNDARY-START(34364260359)
            /*int*/ MajorVersion = 0;
            //--TRIMMABLE-BOUNDARY-END(34364260359)
            
            //--TRIMMABLE-BOUNDARY-START(38659227655)
            /*int*/ MinorVersion = 0;
            //--TRIMMABLE-BOUNDARY-END(38659227655)
            
            static $h = 4521991;
            static $f = 0b10010001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Attribute; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(34364260359),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 21479358471,
        "f": 50331649
      },
      "n": "MajorVersion",
      "d": 4521991,
      "h": 34364260359,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(34364260359),
//--TRIMMABLE-BOUNDARY-START(38659227655),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 30069293063,
        "f": 50331649
      },
      "n": "MinorVersion",
      "d": 4521991,
      "h": 38659227655,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(38659227655)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(12889423879),
    {
      "p": [
        {
          "n": "major",
          "p": 655361
        },
        {
          "n": "minor",
          "p": 655361
        }
      ],
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 4521991,
      "h": 12889423879,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(12889423879)
  ],
  "h": 4521991,
  "a": [
    {
      "t": 46202881,
      "c": 25816006657,
      "a": [
        {
          "v": 1,
          "t": 46137345
        }
      ],
      "n": [
        {
          "n": "Inherited",
          "v": false,
          "t": 262145
        }
      ]
    }
  ]
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `System.Runtime.InteropServices.TypeLibVersionAttribute`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `System${separator}Runtime${separator}InteropServices${separator}TypeLibVersionAttribute`; }
        });
        //--TRIMMABLE-BOUNDARY-END(4521991)
        
        

        //--TRIMMABLE-BOUNDARY-START(4259847)
        $asm.$cls(`$sris.SRI.TypeLibTypeAttribute`, ($self) => class TypeLibTypeAttribute extends $.$$.S.Attribute
        {
            //--TRIMMABLE-BOUNDARY-START(12889161735)
            $ctor$3(/*TypeLibTypeFlags*/ flags)
            {
                super.$ctor$1();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(12889161735);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this.Value = flags;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(12889161735)
            
            //--TRIMMABLE-BOUNDARY-START(8594194439)
            $ctor$2(/*short*/ flags)
            {
                super.$ctor$1();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(8594194439);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this.Value = $.$cast(flags, $.$sris.SRI.TypeLibTypeFlags);
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(8594194439)
            
            //--TRIMMABLE-BOUNDARY-START(25774063623)
            /*TypeLibTypeFlags*/ Value = 0;
            //--TRIMMABLE-BOUNDARY-END(25774063623)
            
            static $h = 4259847;
            static $f = 0b10010001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Attribute; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(25774063623),
    {
      "p": 4325383,
      "g": {
        "r": 0,
        "d": 0,
        "h": 21479096327,
        "f": 50331649
      },
      "n": "Value",
      "d": 4259847,
      "h": 25774063623,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(25774063623)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(12889161735),
    {
      "p": [
        {
          "n": "flags",
          "p": 4325383
        }
      ],
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 4259847,
      "h": 12889161735,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(12889161735),
//--TRIMMABLE-BOUNDARY-START(8594194439),
    {
      "p": [
        {
          "n": "flags",
          "p": 524289
        }
      ],
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 4259847,
      "h": 8594194439,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8594194439)
  ],
  "h": 4259847,
  "a": [
    {
      "t": 46202881,
      "c": 25816006657,
      "a": [
        {
          "v": 1052,
          "t": 46137345
        }
      ],
      "n": [
        {
          "n": "Inherited",
          "v": false,
          "t": 262145
        }
      ]
    }
  ]
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `System.Runtime.InteropServices.TypeLibTypeAttribute`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `System${separator}Runtime${separator}InteropServices${separator}TypeLibTypeAttribute`; }
        });
        //--TRIMMABLE-BOUNDARY-END(4259847)
        
        

        //--TRIMMABLE-BOUNDARY-START(524295)
        $asm.$cls(`$sris.SRI.ComCompatibleVersionAttribute`, ($self) => class ComCompatibleVersionAttribute extends $.$$.S.Attribute
        {
            //--TRIMMABLE-BOUNDARY-START(21475360775)
            $ctor$2(/*int*/ major, /*int*/ minor, /*int*/ build, /*int*/ revision)
            {
                super.$ctor$1();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(21475360775);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this.MajorVersion = major;
                    this.MinorVersion = minor;
                    this.BuildNumber = build;
                    this.RevisionNumber = revision;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(21475360775)
            
            //--TRIMMABLE-BOUNDARY-START(64425033735)
            /*int*/ MajorVersion = 0;
            //--TRIMMABLE-BOUNDARY-END(64425033735)
            
            //--TRIMMABLE-BOUNDARY-START(68720001031)
            /*int*/ MinorVersion = 0;
            //--TRIMMABLE-BOUNDARY-END(68720001031)
            
            //--TRIMMABLE-BOUNDARY-START(25770328071)
            /*int*/ BuildNumber = 0;
            //--TRIMMABLE-BOUNDARY-END(25770328071)
            
            //--TRIMMABLE-BOUNDARY-START(73014968327)
            /*int*/ RevisionNumber = 0;
            //--TRIMMABLE-BOUNDARY-END(73014968327)
            
            static $h = 524295;
            static $f = 0b10010001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Attribute; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(64425033735),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 42950197255,
        "f": 50331649
      },
      "n": "MajorVersion",
      "d": 524295,
      "h": 64425033735,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(64425033735),
//--TRIMMABLE-BOUNDARY-START(68720001031),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 51540131847,
        "f": 50331649
      },
      "n": "MinorVersion",
      "d": 524295,
      "h": 68720001031,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(68720001031),
//--TRIMMABLE-BOUNDARY-START(25770328071),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 34360262663,
        "f": 50331649
      },
      "n": "BuildNumber",
      "d": 524295,
      "h": 25770328071,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(25770328071),
//--TRIMMABLE-BOUNDARY-START(73014968327),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 60130066439,
        "f": 50331649
      },
      "n": "RevisionNumber",
      "d": 524295,
      "h": 73014968327,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(73014968327)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(21475360775),
    {
      "p": [
        {
          "n": "major",
          "p": 655361
        },
        {
          "n": "minor",
          "p": 655361
        },
        {
          "n": "build",
          "p": 655361
        },
        {
          "n": "revision",
          "p": 655361
        }
      ],
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 524295,
      "h": 21475360775,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(21475360775)
  ],
  "h": 524295,
  "a": [
    {
      "t": 46202881,
      "c": 25816006657,
      "a": [
        {
          "v": 1,
          "t": 46137345
        }
      ],
      "n": [
        {
          "n": "Inherited",
          "v": false,
          "t": 262145
        }
      ]
    }
  ]
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `System.Runtime.InteropServices.ComCompatibleVersionAttribute`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `System${separator}Runtime${separator}InteropServices${separator}ComCompatibleVersionAttribute`; }
        });
        //--TRIMMABLE-BOUNDARY-END(524295)
        
        

        //--TRIMMABLE-BOUNDARY-START(4194311)
        $asm.$cls(`$sris.SRI.TypeLibImportClassAttribute`, ($self) => class TypeLibImportClassAttribute extends $.$$.S.Attribute
        {
            //--TRIMMABLE-BOUNDARY-START(8594128903)
            $ctor$2(/*Type*/ importClass)
            {
                super.$ctor$1();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(8594128903);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this.Value = importClass.ToString();
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(8594128903)
            
            //--TRIMMABLE-BOUNDARY-START(21479030791)
            /*string*/ Value = null;
            //--TRIMMABLE-BOUNDARY-END(21479030791)
            
            static $h = 4194311;
            static $f = 0b10010001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Attribute; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(21479030791),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 17184063495,
        "f": 50331649
      },
      "n": "Value",
      "d": 4194311,
      "h": 21479030791,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(21479030791)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(8594128903),
    {
      "p": [
        {
          "n": "importClass",
          "p": 188547073
        }
      ],
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 4194311,
      "h": 8594128903,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8594128903)
  ],
  "h": 4194311,
  "a": [
    {
      "t": 46202881,
      "c": 25816006657,
      "a": [
        {
          "v": 1024,
          "t": 46137345
        }
      ],
      "n": [
        {
          "n": "Inherited",
          "v": false,
          "t": 262145
        }
      ]
    }
  ]
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `System.Runtime.InteropServices.TypeLibImportClassAttribute`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `System${separator}Runtime${separator}InteropServices${separator}TypeLibImportClassAttribute`; }
        });
        //--TRIMMABLE-BOUNDARY-END(4194311)
        
        

        //--TRIMMABLE-BOUNDARY-START(1703943)
        $asm.$cls(`$sris.SRI.ManagedToNativeComInteropStubAttribute`, ($self) => class ManagedToNativeComInteropStubAttribute extends $.$$.S.Attribute
        {
            //--TRIMMABLE-BOUNDARY-START(12886605831)
            $ctor$2(/*Type*/ classType, /*string*/ methodName)
            {
                super.$ctor$1();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(12886605831);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this.ClassType = classType;
                    this.MethodName = methodName;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(12886605831)
            
            //--TRIMMABLE-BOUNDARY-START(17181573127)
            /*Type*/ ClassType = null;
            //--TRIMMABLE-BOUNDARY-END(17181573127)
            
            //--TRIMMABLE-BOUNDARY-START(38656409607)
            /*string*/ MethodName = null;
            //--TRIMMABLE-BOUNDARY-END(38656409607)
            
            static $h = 1703943;
            static $f = 0b10010001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Attribute; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(17181573127),
    {
      "p": 188547073,
      "g": {
        "r": 0,
        "d": 0,
        "h": 25771507719,
        "f": 50331649
      },
      "n": "ClassType",
      "d": 1703943,
      "h": 17181573127,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(17181573127),
//--TRIMMABLE-BOUNDARY-START(38656409607),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 34361442311,
        "f": 50331649
      },
      "n": "MethodName",
      "d": 1703943,
      "h": 38656409607,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(38656409607)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(12886605831),
    {
      "p": [
        {
          "n": "classType",
          "p": 188547073
        },
        {
          "n": "methodName",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 1703943,
      "h": 12886605831,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(12886605831)
  ],
  "h": 1703943,
  "a": [
    {
      "t": 46202881,
      "c": 25816006657,
      "a": [
        {
          "v": 64,
          "t": 46137345
        }
      ],
      "n": [
        {
          "n": "Inherited",
          "v": false,
          "t": 262145
        },
        {
          "n": "AllowMultiple",
          "v": false,
          "t": 262145
        }
      ]
    }
  ]
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `System.Runtime.InteropServices.ManagedToNativeComInteropStubAttribute`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `System${separator}Runtime${separator}InteropServices${separator}ManagedToNativeComInteropStubAttribute`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1703943)
        
        

        //--TRIMMABLE-BOUNDARY-START(3801095)
        $asm.$cls(`$sris.SRI.PrimaryInteropAssemblyAttribute`, ($self) => class PrimaryInteropAssemblyAttribute extends $.$$.S.Attribute
        {
            //--TRIMMABLE-BOUNDARY-START(12888702983)
            $ctor$2(/*int*/ major, /*int*/ minor)
            {
                super.$ctor$1();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(12888702983);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this.MajorVersion = major;
                    this.MinorVersion = minor;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(12888702983)
            
            //--TRIMMABLE-BOUNDARY-START(34363539463)
            /*int*/ MajorVersion = 0;
            //--TRIMMABLE-BOUNDARY-END(34363539463)
            
            //--TRIMMABLE-BOUNDARY-START(38658506759)
            /*int*/ MinorVersion = 0;
            //--TRIMMABLE-BOUNDARY-END(38658506759)
            
            static $h = 3801095;
            static $f = 0b10010001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Attribute; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(34363539463),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 21478637575,
        "f": 50331649
      },
      "n": "MajorVersion",
      "d": 3801095,
      "h": 34363539463,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(34363539463),
//--TRIMMABLE-BOUNDARY-START(38658506759),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 30068572167,
        "f": 50331649
      },
      "n": "MinorVersion",
      "d": 3801095,
      "h": 38658506759,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(38658506759)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(12888702983),
    {
      "p": [
        {
          "n": "major",
          "p": 655361
        },
        {
          "n": "minor",
          "p": 655361
        }
      ],
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 3801095,
      "h": 12888702983,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(12888702983)
  ],
  "h": 3801095,
  "a": [
    {
      "t": 46202881,
      "c": 25816006657,
      "a": [
        {
          "v": 1,
          "t": 46137345
        }
      ],
      "n": [
        {
          "n": "Inherited",
          "v": false,
          "t": 262145
        },
        {
          "n": "AllowMultiple",
          "v": true,
          "t": 262145
        }
      ]
    }
  ]
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `System.Runtime.InteropServices.PrimaryInteropAssemblyAttribute`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `System${separator}Runtime${separator}InteropServices${separator}PrimaryInteropAssemblyAttribute`; }
        });
        //--TRIMMABLE-BOUNDARY-END(3801095)
        
        

        //--TRIMMABLE-BOUNDARY-START(4063239)
        $asm.$cls(`$sris.SRI.TypeLibFuncAttribute`, ($self) => class TypeLibFuncAttribute extends $.$$.S.Attribute
        {
            //--TRIMMABLE-BOUNDARY-START(12888965127)
            $ctor$3(/*TypeLibFuncFlags*/ flags)
            {
                super.$ctor$1();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(12888965127);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this.Value = flags;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(12888965127)
            
            //--TRIMMABLE-BOUNDARY-START(8593997831)
            $ctor$2(/*short*/ flags)
            {
                super.$ctor$1();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(8593997831);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this.Value = $.$cast(flags, $.$sris.SRI.TypeLibFuncFlags);
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(8593997831)
            
            //--TRIMMABLE-BOUNDARY-START(25773867015)
            /*TypeLibFuncFlags*/ Value = 0;
            //--TRIMMABLE-BOUNDARY-END(25773867015)
            
            static $h = 4063239;
            static $f = 0b10010001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Attribute; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(25773867015),
    {
      "p": 4128775,
      "g": {
        "r": 0,
        "d": 0,
        "h": 21478899719,
        "f": 50331649
      },
      "n": "Value",
      "d": 4063239,
      "h": 25773867015,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(25773867015)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(12888965127),
    {
      "p": [
        {
          "n": "flags",
          "p": 4128775
        }
      ],
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 4063239,
      "h": 12888965127,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(12888965127),
//--TRIMMABLE-BOUNDARY-START(8593997831),
    {
      "p": [
        {
          "n": "flags",
          "p": 524289
        }
      ],
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 4063239,
      "h": 8593997831,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8593997831)
  ],
  "h": 4063239,
  "a": [
    {
      "t": 46202881,
      "c": 25816006657,
      "a": [
        {
          "v": 64,
          "t": 46137345
        }
      ],
      "n": [
        {
          "n": "Inherited",
          "v": false,
          "t": 262145
        }
      ]
    }
  ]
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `System.Runtime.InteropServices.TypeLibFuncAttribute`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `System${separator}Runtime${separator}InteropServices${separator}TypeLibFuncAttribute`; }
        });
        //--TRIMMABLE-BOUNDARY-END(4063239)
        
        

        //--TRIMMABLE-BOUNDARY-START(2883591)
        $asm.$cls(`$sris.SRIM.GeneratedComInterfaceAttribute`, ($self) => class GeneratedComInterfaceAttribute extends $.$$.S.Attribute
        {
            //--TRIMMABLE-BOUNDARY-START(64427393031)
            /*ComInterfaceOptions*/ Options = 0;
            //--TRIMMABLE-BOUNDARY-END(64427393031)
            
            //--TRIMMABLE-BOUNDARY-START(103082098695)
            /*StringMarshalling*/ StringMarshalling = 0;
            //--TRIMMABLE-BOUNDARY-END(103082098695)
            
            //--TRIMMABLE-BOUNDARY-START(107377065991)
            /*Type?*/ StringMarshallingCustomType = null;
            //--TRIMMABLE-BOUNDARY-END(107377065991)
            
            //--TRIMMABLE-BOUNDARY-START(25772687367)
            /*Type?*/ ExceptionToUnmanagedMarshaller = null;
            //--TRIMMABLE-BOUNDARY-END(25772687367)
            
            //--TRIMMABLE-BOUNDARY-START(21477720071)
            //default constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21477720071);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(21477720071)
            
            //--TRIMMABLE-BOUNDARY-START(21477720071)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$2();
            }
            //--TRIMMABLE-BOUNDARY-END(21477720071)
            
            //default member initializer
            constructor()
            {
                super();
                //--TRIMMABLE-BOUNDARY-START(64427393031)
                this.Options = 3;
                //--TRIMMABLE-BOUNDARY-END(64427393031)
                
            }
            static $h = 2883591;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Attribute; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(64427393031),
    {
      "p": 2097159,
      "g": {
        "r": 0,
        "d": 0,
        "h": 42952556551,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 81607262215,
        "f": 83886081
      },
      "n": "Options",
      "d": 2883591,
      "h": 64427393031,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(64427393031),
//--TRIMMABLE-BOUNDARY-START(103082098695),
    {
      "p": 148111361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 51542491143,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 90197196807,
        "f": 83886081
      },
      "n": "StringMarshalling",
      "d": 2883591,
      "h": 103082098695,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(103082098695),
//--TRIMMABLE-BOUNDARY-START(107377065991),
    {
      "p": 188547073,
      "g": {
        "r": 0,
        "d": 0,
        "h": 60132425735,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 98787131399,
        "f": 83886081
      },
      "n": "StringMarshallingCustomType",
      "d": 2883591,
      "h": 107377065991,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(107377065991),
//--TRIMMABLE-BOUNDARY-START(25772687367),
    {
      "p": 188547073,
      "g": {
        "r": 0,
        "d": 0,
        "h": 34362621959,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 73017327623,
        "f": 83886081
      },
      "n": "ExceptionToUnmanagedMarshaller",
      "d": 2883591,
      "h": 25772687367,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(25772687367)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(21477720071),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 2883591,
      "h": 21477720071,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(21477720071)
  ],
  "h": 2883591,
  "a": [
    {
      "t": 46202881,
      "c": 25816006657,
      "a": [
        {
          "v": 1024,
          "t": 46137345
        }
      ]
    }
  ]
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `System.Runtime.InteropServices.Marshalling.GeneratedComInterfaceAttribute`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `System${separator}Runtime${separator}InteropServices${separator}Marshalling${separator}GeneratedComInterfaceAttribute`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2883591)
        
        

        //--TRIMMABLE-BOUNDARY-START(3604487)
        $asm.$cls(`$sris.SRIM.StrategyBasedComWrappers`, ($self) => class StrategyBasedComWrappers extends $.$$.SRI.ComWrappers
        {
            //--TRIMMABLE-BOUNDARY-START(55838179335)
            /*StrategyBasedComWrappers*/ static DefaultMarshallingInstance = null;
            //--TRIMMABLE-BOUNDARY-END(55838179335)
            
            //--TRIMMABLE-BOUNDARY-START(47248244743)
            /*IIUnknownInterfaceDetailsStrategy*/ static DefaultIUnknownInterfaceDetailsStrategy = null;
            //--TRIMMABLE-BOUNDARY-END(47248244743)
            
            //--TRIMMABLE-BOUNDARY-START(51543212039)
            /*IIUnknownStrategy*/ static DefaultIUnknownStrategy = null;
            //--TRIMMABLE-BOUNDARY-END(51543212039)
            
            //--TRIMMABLE-BOUNDARY-START(34363342855)
            static /*IIUnknownCacheStrategy */ CreateDefaultCacheStrategy()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(34363342855);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return new $.$sris.SRIM.DefaultCaching().$ctor$1();
                }
            }
            //--TRIMMABLE-BOUNDARY-END(34363342855)
            
            //--TRIMMABLE-BOUNDARY-START(85902950407)
            /*IIUnknownInterfaceDetailsStrategy */ GetOrCreateInterfaceDetailsStrategy()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(85902950407);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                //if (OperatingSystem.IsWindows() && RuntimeFeature.IsDynamicCodeSupported && ComObject.BuiltInComSupported && ComObject.ComImportInteropEnabled) { ... }
                return $.$sris.SRIM.StrategyBasedComWrappers.DefaultIUnknownInterfaceDetailsStrategy;
                /*static IIUnknownInterfaceDetailsStrategy*/  function GetInteropStrategy()
                {
                    return $.$sris.SRIM.ComImportInteropInterfaceDetailsStrategy.Instance;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(85902950407)
            
            //--TRIMMABLE-BOUNDARY-START(90197917703)
            /*IIUnknownStrategy */ GetOrCreateIUnknownStrategy()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(90197917703);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return $.$sris.SRIM.StrategyBasedComWrappers.DefaultIUnknownStrategy;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(90197917703)
            
            //--TRIMMABLE-BOUNDARY-START(30068375559)
            /*IIUnknownCacheStrategy */ CreateCacheStrategy()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(30068375559);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return $.$sris.SRIM.StrategyBasedComWrappers.CreateDefaultCacheStrategy();
                }
            }
            //--TRIMMABLE-BOUNDARY-END(30068375559)
            
            //--TRIMMABLE-BOUNDARY-START(25773408263)
            /*ComInterfaceEntry* */ ComputeVtables(/*object*/ obj, /*CreateComInterfaceFlags*/ flags, /*out int*/ count)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25773408263);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                let details;
                if (this.GetOrCreateInterfaceDetailsStrategy().SRIM$IIUnknownInterfaceDetailsStrategy$GetComExposedTypeDetails($.$$.S.Object.GetType.call(obj).TypeHandle) !== null && ((details = this.GetOrCreateInterfaceDetailsStrategy().SRIM$IIUnknownInterfaceDetailsStrategy$GetComExposedTypeDetails($.$$.S.Object.GetType.call(obj).TypeHandle), details != null && true)))
                {
                    return details.SRIM$IComExposedDetails$GetComInterfaceEntries(count);
                }
                count.$v = 0;
                return null;
            }
            //--TRIMMABLE-BOUNDARY-END(25773408263)
            
            //--TRIMMABLE-BOUNDARY-START(42953277447)
            /*object */ CreateObject$1(/*nint*/ externalComObject, /*CreateObjectFlags*/ flags)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(42953277447);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (((flags & (1/*CreateObjectFlags.TrackerObject*/)) == (1/*CreateObjectFlags.TrackerObject*/)) || ((flags & (4/*CreateObjectFlags.Aggregation*/)) == (4/*CreateObjectFlags.Aggregation*/)))
                {
                    throw new $.$$.S.NotSupportedException().$ctor$9();
                }
                /*var*/ let rcw = (() =>
                {
                    //new $.$sris.SRIM.ComObject()
                    const $t2 = $.$sris.SRIM.ComObject;
                    const $i2 = new $t2();
                    $i2.$ctor$1(this.GetOrCreateInterfaceDetailsStrategy(), this.GetOrCreateIUnknownStrategy(), this.CreateCacheStrategy(), $.$$.$interop.$addr2Ptr(externalComObject, null));
                    $i2.UniqueInstance = ((flags & (2/*CreateObjectFlags.UniqueInstance*/)) == (2/*CreateObjectFlags.UniqueInstance*/));
                    return $i2;
                })();
                return rcw;
            }
            //--TRIMMABLE-BOUNDARY-END(42953277447)
            
            //--TRIMMABLE-BOUNDARY-START(38658310151)
            /*object? */ CreateObject(/*nint*/ externalComObject, /*CreateObjectFlags*/ flags, /*object?*/ userState, /*out CreatedWrapperFlags*/ wrapperFlags)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(38658310151);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return super.CreateObject(externalComObject, flags, userState, wrapperFlags);
            }
            //--TRIMMABLE-BOUNDARY-END(38658310151)
            
            //--TRIMMABLE-BOUNDARY-START(94492884999)
            /*void */ ReleaseObjects(/*IEnumerable*/ objects)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(94492884999);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.NotImplementedException().$ctor$9();
            }
            //--TRIMMABLE-BOUNDARY-END(94492884999)
            
            //--TRIMMABLE-BOUNDARY-START(21478440967)
            //default constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21478440967);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(21478440967)
            
            //--TRIMMABLE-BOUNDARY-START(21478440967)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$2();
            }
            //--TRIMMABLE-BOUNDARY-END(21478440967)
            
            //--TRIMMABLE-BOUNDARY-START(17183473671)
            //Static Initializer
            static $sinit()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17183473671);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                {
                    //--TRIMMABLE-BOUNDARY-START(55838179335)
                    this.DefaultMarshallingInstance = new $.$sris.SRIM.StrategyBasedComWrappers().$ctor$2();
                    //--TRIMMABLE-BOUNDARY-END(55838179335)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(47248244743)
                    this.DefaultIUnknownInterfaceDetailsStrategy = $.$sris.SRIM.DefaultIUnknownInterfaceDetailsStrategy.Instance;
                    //--TRIMMABLE-BOUNDARY-END(47248244743)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(51543212039)
                    this.DefaultIUnknownStrategy = $.$sris.SRIM.FreeThreadedStrategy.Instance;
                    //--TRIMMABLE-BOUNDARY-END(51543212039)
                    
                }
            }
            //--TRIMMABLE-BOUNDARY-END(17183473671)
            
            static $h = 3604487;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.SRI.ComWrappers; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(55838179335),
    {
      "p": 3604487,
      "g": {
        "r": 0,
        "d": 0,
        "h": 81607983111,
        "f": 50331688
      },
      "n": "DefaultMarshallingInstance",
      "d": 3604487,
      "h": 55838179335,
      "f": 2097192
    },
//--TRIMMABLE-BOUNDARY-END(55838179335),
//--TRIMMABLE-BOUNDARY-START(47248244743),
    {
      "p": 3276807,
      "g": {
        "r": 0,
        "d": 0,
        "h": 64428113927,
        "f": 50331681
      },
      "n": "DefaultIUnknownInterfaceDetailsStrategy",
      "d": 3604487,
      "h": 47248244743,
      "f": 2097185
    },
//--TRIMMABLE-BOUNDARY-END(47248244743),
//--TRIMMABLE-BOUNDARY-START(51543212039),
    {
      "p": 3407879,
      "g": {
        "r": 0,
        "d": 0,
        "h": 73018048519,
        "f": 50331681
      },
      "n": "DefaultIUnknownStrategy",
      "d": 3604487,
      "h": 51543212039,
      "f": 2097185
    },
//--TRIMMABLE-BOUNDARY-END(51543212039)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(34363342855),
    {
      "r": 3080199,
      "n": "CreateDefaultCacheStrategy",
      "d": 3604487,
      "h": 34363342855,
      "f": 16777252
    },
//--TRIMMABLE-BOUNDARY-END(34363342855),
//--TRIMMABLE-BOUNDARY-START(85902950407),
    {
      "r": 3276807,
      "n": "GetOrCreateInterfaceDetailsStrategy",
      "d": 3604487,
      "h": 85902950407,
      "f": 16777348
    },
//--TRIMMABLE-BOUNDARY-END(85902950407),
//--TRIMMABLE-BOUNDARY-START(90197917703),
    {
      "r": 3407879,
      "n": "GetOrCreateIUnknownStrategy",
      "d": 3604487,
      "h": 90197917703,
      "f": 16777348
    },
//--TRIMMABLE-BOUNDARY-END(90197917703),
//--TRIMMABLE-BOUNDARY-START(30068375559),
    {
      "r": 3080199,
      "n": "CreateCacheStrategy",
      "d": 3604487,
      "h": 30068375559,
      "f": 16777348
    },
//--TRIMMABLE-BOUNDARY-END(30068375559),
//--TRIMMABLE-BOUNDARY-START(25773408263),
    {
      "r": $.$typePointer($.$$.SRI.ComWrappers.ComInterfaceEntry).$h,
      "p": [
        {
          "n": "obj",
          "p": 131073
        },
        {
          "n": "flags",
          "p": 141099009
        },
        {
          "n": "count",
          "p": 655361,
          "f": 2
        }
      ],
      "n": "ComputeVtables",
      "d": 3604487,
      "h": 25773408263,
      "f": 16875524
    },
//--TRIMMABLE-BOUNDARY-END(25773408263),
//--TRIMMABLE-BOUNDARY-START(42953277447),
    {
      "r": 131073,
      "p": [
        {
          "n": "externalComObject",
          "p": 786433
        },
        {
          "n": "flags",
          "p": 141230081
        }
      ],
      "n": "CreateObject",
      "o": "@$1",
      "d": 3604487,
      "h": 42953277447,
      "f": 16875524
    },
//--TRIMMABLE-BOUNDARY-END(42953277447),
//--TRIMMABLE-BOUNDARY-START(38658310151),
    {
      "r": 131073,
      "p": [
        {
          "n": "externalComObject",
          "p": 786433
        },
        {
          "n": "flags",
          "p": 141230081
        },
        {
          "n": "userState",
          "p": 131073
        },
        {
          "n": "wrapperFlags",
          "p": 141164545,
          "f": 2
        }
      ],
      "n": "CreateObject",
      "d": 3604487,
      "h": 38658310151,
      "f": 16875524
    },
//--TRIMMABLE-BOUNDARY-END(38658310151),
//--TRIMMABLE-BOUNDARY-START(94492884999),
    {
      "r": 65537,
      "p": [
        {
          "n": "objects",
          "p": 63373313
        }
      ],
      "n": "ReleaseObjects",
      "d": 3604487,
      "h": 94492884999,
      "f": 16875524
    },
//--TRIMMABLE-BOUNDARY-END(94492884999)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(21478440967),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 3604487,
      "h": 21478440967,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(21478440967)
  ],
  "h": 3604487,
  "a": [
    {
      "t": 160169985,
      "c": 13045071873,
      "a": [
        {
          "v": "android",
          "t": 1310721
        }
      ]
    },
    {
      "t": 160169985,
      "c": 13045071873,
      "a": [
        {
          "v": "browser",
          "t": 1310721
        }
      ]
    },
    {
      "t": 160169985,
      "c": 13045071873,
      "a": [
        {
          "v": "ios",
          "t": 1310721
        }
      ]
    },
    {
      "t": 160169985,
      "c": 13045071873,
      "a": [
        {
          "v": "tvos",
          "t": 1310721
        }
      ]
    },
    {
      "t": 54984705,
      "c": 8644919297,
      "a": [
        {
          "v": false,
          "t": 262145
        }
      ]
    }
  ]
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `System.Runtime.InteropServices.Marshalling.StrategyBasedComWrappers`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `System${separator}Runtime${separator}InteropServices${separator}Marshalling${separator}StrategyBasedComWrappers`; }
        });
        //--TRIMMABLE-BOUNDARY-END(3604487)
        
        

        //--TRIMMABLE-BOUNDARY-START(3735559)
        $asm.$str(`$sris.SRIM.VirtualMethodTableInfo`, ($self) => class VirtualMethodTableInfo extends $.$$.S.ValueType
        {
            //--TRIMMABLE-BOUNDARY-START(17183604743)
            $ctor$3(/*void**/ thisPointer, /*void***/ virtualMethodTable)
            {
                super.$ctor$1();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(17183604743);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this.ThisPointer = thisPointer;
                    this.VirtualMethodTable = virtualMethodTable;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(17183604743)
            
            //--TRIMMABLE-BOUNDARY-START(42953408519)
            /*void**/ ThisPointer;
            //--TRIMMABLE-BOUNDARY-END(42953408519)
            
            //--TRIMMABLE-BOUNDARY-START(47248375815)
            /*void***/ VirtualMethodTable;
            //--TRIMMABLE-BOUNDARY-END(47248375815)
            
            //--TRIMMABLE-BOUNDARY-START(21478572039)
            /*void */ Deconstruct(/*out void**/ thisPointer, /*out void***/ virtualMethodTable)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21478572039);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                thisPointer.$v = this.ThisPointer;
                virtualMethodTable.$v = this.VirtualMethodTable;
            }
            //--TRIMMABLE-BOUNDARY-END(21478572039)
            
            //--TRIMMABLE-BOUNDARY-START(12888637447)
            //default constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12888637447);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(12888637447)
            
            //--TRIMMABLE-BOUNDARY-START(12888637447)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$2();
            }
            //--TRIMMABLE-BOUNDARY-END(12888637447)
            
            $clone($copy)
            {
                let copy = $copy ?? new this.constructor();
                copy.ThisPointer = this.ThisPointer.$clone();
                copy.VirtualMethodTable = this.VirtualMethodTable.$clone();
                return copy;
            }
            //default member initializer
            constructor()
            {
                super();
                //--TRIMMABLE-BOUNDARY-START(42953408519)
                this.ThisPointer = $.$default($.$typePointer($.$$.S.Void));
                //--TRIMMABLE-BOUNDARY-END(42953408519)
                
                //--TRIMMABLE-BOUNDARY-START(47248375815)
                this.VirtualMethodTable = $.$default($.$typePointer($.$typePointer($.$$.S.Void)));
                //--TRIMMABLE-BOUNDARY-END(47248375815)
                
            }
            static $h = 3735559;
            static $z = 8;
            static $f = 0b1010000001;
            static $k = 2;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.ValueType; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(42953408519),
    {
      "p": $.$typePointer($.$$.S.Void).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 30068506631,
        "f": 50331649
      },
      "n": "ThisPointer",
      "d": 3735559,
      "h": 42953408519,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(42953408519),
//--TRIMMABLE-BOUNDARY-START(47248375815),
    {
      "p": $.$typePointer($.$typePointer($.$$.S.Void)).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 38658441223,
        "f": 50331649
      },
      "n": "VirtualMethodTable",
      "d": 3735559,
      "h": 47248375815,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(47248375815)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(21478572039),
    {
      "r": 65537,
      "p": [
        {
          "n": "thisPointer",
          "p": $.$typePointer($.$$.S.Void).$h,
          "f": 2
        },
        {
          "n": "virtualMethodTable",
          "p": $.$typePointer($.$typePointer($.$$.S.Void)).$h,
          "f": 2
        }
      ],
      "n": "Deconstruct",
      "d": 3735559,
      "h": 21478572039,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(21478572039)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(17183604743),
    {
      "p": [
        {
          "n": "thisPointer",
          "p": $.$typePointer($.$$.S.Void).$h
        },
        {
          "n": "virtualMethodTable",
          "p": $.$typePointer($.$typePointer($.$$.S.Void)).$h
        }
      ],
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 3735559,
      "h": 17183604743,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(17183604743),
//--TRIMMABLE-BOUNDARY-START(12888637447),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 3735559,
      "h": 12888637447,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(12888637447)
  ],
  "h": 3735559,
  "a": [
    {
      "t": 54984705,
      "c": 8644919297,
      "a": [
        {
          "v": false,
          "t": 262145
        }
      ]
    }
  ]
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `System.Runtime.InteropServices.Marshalling.VirtualMethodTableInfo`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `System${separator}Runtime${separator}InteropServices${separator}Marshalling${separator}VirtualMethodTableInfo`; }
        });
        //--TRIMMABLE-BOUNDARY-END(3735559)
        
        

        //--TRIMMABLE-BOUNDARY-START(1769479)
        $asm.$cls(`$sris.SRIM.ComExposedClassAttribute<>`, (T) => $asm.$gt(`$sris.SRIM.ComExposedClassAttribute<>`, [T], ($self) => class ComExposedClassAttribute$$ extends $.$$.S.Attribute
        {
            //--TRIMMABLE-BOUNDARY-START(8591704071)
            /*ComWrappers.ComInterfaceEntry* */ GetComInterfaceEntries(/*out int*/ count)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(8591704071);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return T.SRIM$IComExposedClass$GetComInterfaceEntries(count);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(8591704071)
            
            //--TRIMMABLE-BOUNDARY-START(4297981959)
            //Generated interface implemetation for System.Runtime.InteropServices.Marshalling.IComExposedDetails.GetComInterfaceEntries(out int)
            SRIM$IComExposedDetails$GetComInterfaceEntries()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4297981959);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.GetComInterfaceEntries(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4297981959)
            
            //--TRIMMABLE-BOUNDARY-START(4296736775)
            //default constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296736775);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296736775)
            
            //--TRIMMABLE-BOUNDARY-START(4296736775)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$2();
            }
            //--TRIMMABLE-BOUNDARY-END(4296736775)
            
            static $H = 1769479;
            static $h = 1769479;
            static $g = 1;
            static $f = 0b11010001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Attribute; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8591704071),
    {
      "r": $.$typePointer($.$$.SRI.ComWrappers.ComInterfaceEntry).$h,
      "p": [
        {
          "n": "count",
          "p": 655361,
          "f": 2
        }
      ],
      "n": "GetComInterfaceEntries",
      "d": this.$h,
      "H": 8591704071,
      "h": Number(BigInt(this.$h)|0x200000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8591704071)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296736775),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": this.$h,
      "H": 4296736775,
      "h": Number(BigInt(this.$h)|0x100000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296736775)
  ],
  "s": [
    {
      "h": T?.$h??1572864,
      "n": "T",
      "c": [2949127
      ]
    }
  ],
  "r": 1,
  "H": 1769479,
  "h": this.$h,
  "a": [
    {
      "t": 46202881,
      "c": 25816006657,
      "a": [
        {
          "v": 4,
          "t": 46137345
        }
      ],
      "n": [
        {
          "n": "Inherited",
          "v": false,
          "t": 262145
        }
      ]
    },
    {
      "t": 54984705,
      "c": 8644919297,
      "a": [
        {
          "v": false,
          "t": 262145
        }
      ]
    }
  ]
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$sris.SRIM.IComExposedDetails ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `System.Runtime.InteropServices.Marshalling.ComExposedClassAttribute<${T?.$fullName}>`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `System${separator}Runtime${separator}InteropServices${separator}Marshalling${separator}ComExposedClassAttribute$${T?.$getFullName(separator)}$`; }
        }));
        //--TRIMMABLE-BOUNDARY-END(1769479)
        
        

        //--TRIMMABLE-BOUNDARY-START(3473415)
        $asm.$cls(`$sris.SRIM.IUnknownDerivedAttribute<,>`, (T, TImpl) => $asm.$gt(`$sris.SRIM.IUnknownDerivedAttribute<,>`, [T, TImpl], ($self) => class IUnknownDerivedAttribute$$$ extends $.$$.S.Attribute
        {
            //--TRIMMABLE-BOUNDARY-START(4298440711)
            $ctor$2()
            {
                super.$ctor$1();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4298440711);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4298440711)
            
            //--TRIMMABLE-BOUNDARY-START(34363211783)
            /*Guid */ get Iid()
            {
                return T.SRIM$IIUnknownInterfaceType$Iid;
            }
            //--TRIMMABLE-BOUNDARY-END(34363211783)
            
            //--TRIMMABLE-BOUNDARY-START(38658179079)
            /*Type */ get Implementation()
            {
                return TImpl.$type;
            }
            //--TRIMMABLE-BOUNDARY-END(38658179079)
            
            //--TRIMMABLE-BOUNDARY-START(42953146375)
            /*void** */ get ManagedVirtualMethodTable()
            {
                return T.SRIM$IIUnknownInterfaceType$ManagedVirtualMethodTable;
            }
            //--TRIMMABLE-BOUNDARY-END(42953146375)
            
            //--TRIMMABLE-BOUNDARY-START(8593145863)
            //Generated interface implemetation for System.Runtime.InteropServices.Marshalling.IIUnknownDerivedDetails.Iid.get
            get SRIM$IIUnknownDerivedDetails$Iid()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(34362949639);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Iid;
            }
            //--TRIMMABLE-BOUNDARY-END(8593145863)
            
            //--TRIMMABLE-BOUNDARY-START(17183080455)
            //Generated interface implemetation for System.Runtime.InteropServices.Marshalling.IIUnknownDerivedDetails.Implementation.get
            get SRIM$IIUnknownDerivedDetails$Implementation()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(38657916935);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Implementation;
            }
            //--TRIMMABLE-BOUNDARY-END(17183080455)
            
            //--TRIMMABLE-BOUNDARY-START(25773015047)
            //Generated interface implemetation for System.Runtime.InteropServices.Marshalling.IIUnknownDerivedDetails.ManagedVirtualMethodTable.get
            get SRIM$IIUnknownDerivedDetails$ManagedVirtualMethodTable()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(42952884231);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.ManagedVirtualMethodTable;
            }
            //--TRIMMABLE-BOUNDARY-END(25773015047)
            
            //--TRIMMABLE-BOUNDARY-START(4298440711)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$2();
            }
            //--TRIMMABLE-BOUNDARY-END(4298440711)
            
            static $H = 3473415;
            static $h = 3473415;
            static $g = 2;
            static $f = 0b1010001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Attribute; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(34363211783),
    {
      "p": 89784321,
      "g": {
        "r": 0,
        "d": 0,
        "H": 12888375303,
        "h": Number(BigInt(this.$h)|0x300000000n),
        "f": 50331649
      },
      "n": "Iid",
      "d": this.$h,
      "H": 34363211783,
      "h": Number(BigInt(this.$h)|0x800000000n),
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(34363211783),
//--TRIMMABLE-BOUNDARY-START(38658179079),
    {
      "p": 188547073,
      "g": {
        "r": 0,
        "d": 0,
        "H": 21478309895,
        "h": Number(BigInt(this.$h)|0x500000000n),
        "f": 50331649
      },
      "n": "Implementation",
      "d": this.$h,
      "H": 38658179079,
      "h": Number(BigInt(this.$h)|0x900000000n),
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(38658179079),
//--TRIMMABLE-BOUNDARY-START(42953146375),
    {
      "p": $.$typePointer($.$typePointer($.$$.S.Void)).$h,
      "g": {
        "r": 0,
        "d": 0,
        "H": 30068244487,
        "h": Number(BigInt(this.$h)|0x700000000n),
        "f": 50331649
      },
      "n": "ManagedVirtualMethodTable",
      "d": this.$h,
      "H": 42953146375,
      "h": Number(BigInt(this.$h)|0xA00000000n),
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(42953146375)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4298440711),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": this.$h,
      "H": 4298440711,
      "h": Number(BigInt(this.$h)|0x100000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4298440711)
  ],
  "s": [
    {
      "h": T?.$h??1572864,
      "n": "T",
      "c": [3342343
      ]
    },
    {
      "h": TImpl?.$h??1638400,
      "n": "TImpl"
    }
  ],
  "r": 2,
  "H": 3473415,
  "h": this.$h,
  "a": [
    {
      "t": 46202881,
      "c": 25816006657,
      "a": [
        {
          "v": 1024,
          "t": 46137345
        }
      ],
      "n": [
        {
          "n": "Inherited",
          "v": false,
          "t": 262145
        }
      ]
    },
    {
      "t": 54984705,
      "c": 8644919297,
      "a": [
        {
          "v": false,
          "t": 262145
        }
      ]
    }
  ]
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$sris.SRIM.IIUnknownDerivedDetails ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `System.Runtime.InteropServices.Marshalling.IUnknownDerivedAttribute<${T?.$fullName},${TImpl?.$fullName}>`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `System${separator}Runtime${separator}InteropServices${separator}Marshalling${separator}IUnknownDerivedAttribute$${T?.$getFullName(separator)}$${TImpl?.$getFullName(separator)}$`; }
        }));
        //--TRIMMABLE-BOUNDARY-END(3473415)
        
        

        //--TRIMMABLE-BOUNDARY-START(196615)
        $asm.$cls(`$sris.SRC.IUnknownConstantAttribute`, ($self) => class IUnknownConstantAttribute extends $.$$.SRC.CustomConstantAttribute
        {
            //--TRIMMABLE-BOUNDARY-START(4295163911)
            $ctor$3()
            {
                super.$ctor$2();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4295163911);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295163911)
            
            //--TRIMMABLE-BOUNDARY-START(17180065799)
            /*object */ get Value()
            {
                return new $.$$.SRI.UnknownWrapper().$ctor$1(null);
            }
            //--TRIMMABLE-BOUNDARY-END(17180065799)
            
            //--TRIMMABLE-BOUNDARY-START(4295163911)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$3();
            }
            //--TRIMMABLE-BOUNDARY-END(4295163911)
            
            static $h = 196615;
            static $f = 0b10010001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.SRC.CustomConstantAttribute; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(17180065799),
    {
      "p": 131073,
      "g": {
        "r": 0,
        "d": 0,
        "h": 12885098503,
        "f": 50364417
      },
      "n": "Value",
      "d": 196615,
      "h": 17180065799,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(17180065799)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295163911),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 196615,
      "h": 4295163911,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295163911)
  ],
  "h": 196615,
  "a": [
    {
      "t": 46202881,
      "c": 25816006657,
      "a": [
        {
          "v": 2304,
          "t": 46137345
        }
      ],
      "n": [
        {
          "n": "Inherited",
          "v": false,
          "t": 262145
        }
      ]
    }
  ]
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `System.Runtime.CompilerServices.IUnknownConstantAttribute`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `System${separator}Runtime${separator}CompilerServices${separator}IUnknownConstantAttribute`; }
        });
        //--TRIMMABLE-BOUNDARY-END(196615)
        
        

        //--TRIMMABLE-BOUNDARY-START(131079)
        $asm.$cls(`$sris.SRC.IDispatchConstantAttribute`, ($self) => class IDispatchConstantAttribute extends $.$$.SRC.CustomConstantAttribute
        {
            //--TRIMMABLE-BOUNDARY-START(4295098375)
            $ctor$3()
            {
                super.$ctor$2();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4295098375);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295098375)
            
            //--TRIMMABLE-BOUNDARY-START(17180000263)
            /*object */ get Value()
            {
                return new $.$$.SRI.DispatchWrapper().$ctor$1(null);
            }
            //--TRIMMABLE-BOUNDARY-END(17180000263)
            
            //--TRIMMABLE-BOUNDARY-START(4295098375)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$3();
            }
            //--TRIMMABLE-BOUNDARY-END(4295098375)
            
            static $h = 131079;
            static $f = 0b10010001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.SRC.CustomConstantAttribute; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(17180000263),
    {
      "p": 131073,
      "g": {
        "r": 0,
        "d": 0,
        "h": 12885032967,
        "f": 50364417
      },
      "n": "Value",
      "d": 131079,
      "h": 17180000263,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(17180000263)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295098375),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 131079,
      "h": 4295098375,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295098375)
  ],
  "h": 131079,
  "a": [
    {
      "t": 159842305,
      "c": 4454809601,
      "a": [
        {
          "v": "windows",
          "t": 1310721
        }
      ]
    },
    {
      "t": 46202881,
      "c": 25816006657,
      "a": [
        {
          "v": 2304,
          "t": 46137345
        }
      ],
      "n": [
        {
          "n": "Inherited",
          "v": false,
          "t": 262145
        }
      ]
    }
  ]
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `System.Runtime.CompilerServices.IDispatchConstantAttribute`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `System${separator}Runtime${separator}CompilerServices${separator}IDispatchConstantAttribute`; }
        });
        //--TRIMMABLE-BOUNDARY-END(131079)
        
        

        //--TRIMMABLE-BOUNDARY-START(458759)
        $asm.$cls(`$sris.SRI.ComAwareEventInfo`, ($self) => class ComAwareEventInfo extends $.$$.SR.EventInfo
        {
            //--TRIMMABLE-BOUNDARY-START(4295426055)
            /*EventInfo*/ _innerEventInfo = null;
            //--TRIMMABLE-BOUNDARY-END(4295426055)
            
            //--TRIMMABLE-BOUNDARY-START(8590393351)
            $ctor$4(/*Type*/ type, /*string*/ eventName)
            {
                super.$ctor$3();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(8590393351);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this._innerEventInfo = type.GetEvent$1(eventName);
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(8590393351)
            
            //--TRIMMABLE-BOUNDARY-START(12885360647)
            /*void */ AddEventHandler(/*object*/ target, /*Delegate*/ handler)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12885360647);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$$.SRI.Marshal.IsComObject(target))
                {
                    /*Guid*/ let sourceIid;
                    /*int*/ let dispid;
                    $.$sris.SRI.ComAwareEventInfo.GetDataForComInvocation(this._innerEventInfo, $.$ref(() => sourceIid, ($v) => sourceIid = $v, $.$$.S.Guid), $.$ref(() => dispid, ($v) => dispid = $v, $.$$.S.Int32));
                    $.$$.SRI.ComEventsHelper.Combine(target, sourceIid, dispid, handler);
                }
                else 
                {
                    this._innerEventInfo.AddEventHandler(target, handler);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(12885360647)
            
            //--TRIMMABLE-BOUNDARY-START(133144444935)
            /*void */ RemoveEventHandler(/*object*/ target, /*Delegate*/ handler)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(133144444935);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$$.SRI.Marshal.IsComObject(target))
                {
                    /*Guid*/ let sourceIid;
                    /*int*/ let dispid;
                    $.$sris.SRI.ComAwareEventInfo.GetDataForComInvocation(this._innerEventInfo, $.$ref(() => sourceIid, ($v) => sourceIid = $v, $.$$.S.Guid), $.$ref(() => dispid, ($v) => dispid = $v, $.$$.S.Int32));
                    $.$$.SRI.ComEventsHelper.Remove(target, sourceIid, dispid, handler);
                }
                else 
                {
                    this._innerEventInfo.RemoveEventHandler(target, handler);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(133144444935)
            
            //--TRIMMABLE-BOUNDARY-START(17180327943)
            /*EventAttributes */ get Attributes()
            {
                return this._innerEventInfo.Attributes;
            }
            //--TRIMMABLE-BOUNDARY-END(17180327943)
            
            //--TRIMMABLE-BOUNDARY-START(77309870087)
            /*MethodInfo? */ GetAddMethod$1(/*bool*/ nonPublic)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(77309870087);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return this._innerEventInfo.GetAddMethod$1(nonPublic);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(77309870087)
            
            //--TRIMMABLE-BOUNDARY-START(98784706567)
            /*MethodInfo[] */ GetOtherMethods$1(/*bool*/ nonPublic)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(98784706567);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return this._innerEventInfo.GetOtherMethods$1(nonPublic);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(98784706567)
            
            //--TRIMMABLE-BOUNDARY-START(103079673863)
            /*MethodInfo? */ GetRaiseMethod$1(/*bool*/ nonPublic)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(103079673863);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return this._innerEventInfo.GetRaiseMethod$1(nonPublic);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(103079673863)
            
            //--TRIMMABLE-BOUNDARY-START(107374641159)
            /*MethodInfo? */ GetRemoveMethod$1(/*bool*/ nonPublic)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(107374641159);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return this._innerEventInfo.GetRemoveMethod$1(nonPublic);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(107374641159)
            
            //--TRIMMABLE-BOUNDARY-START(21475295239)
            /*Type? */ get DeclaringType()
            {
                return this._innerEventInfo.DeclaringType;
            }
            //--TRIMMABLE-BOUNDARY-END(21475295239)
            
            //--TRIMMABLE-BOUNDARY-START(85899804679)
            /*object[] */ GetCustomAttributes$1(/*Type*/ attributeType, /*bool*/ inherit)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(85899804679);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this._innerEventInfo.GetCustomAttributes$1(attributeType, inherit);
            }
            //--TRIMMABLE-BOUNDARY-END(85899804679)
            
            //--TRIMMABLE-BOUNDARY-START(81604837383)
            /*object[] */ GetCustomAttributes(/*bool*/ inherit)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(81604837383);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this._innerEventInfo.GetCustomAttributes(inherit);
            }
            //--TRIMMABLE-BOUNDARY-END(81604837383)
            
            //--TRIMMABLE-BOUNDARY-START(90194771975)
            /*IList<CustomAttributeData> */ GetCustomAttributesData()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(90194771975);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return this._innerEventInfo.GetCustomAttributesData();
                }
            }
            //--TRIMMABLE-BOUNDARY-END(90194771975)
            
            //--TRIMMABLE-BOUNDARY-START(111669608455)
            /*bool */ IsDefined(/*Type*/ attributeType, /*bool*/ inherit)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(111669608455);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this._innerEventInfo.IsDefined(attributeType, inherit);
            }
            //--TRIMMABLE-BOUNDARY-END(111669608455)
            
            //--TRIMMABLE-BOUNDARY-START(115964575751)
            /*int */ get MetadataToken()
            {
                return this._innerEventInfo.MetadataToken;
            }
            //--TRIMMABLE-BOUNDARY-END(115964575751)
            
            //--TRIMMABLE-BOUNDARY-START(120259543047)
            /*Module */ get Module()
            {
                return this._innerEventInfo.Module;
            }
            //--TRIMMABLE-BOUNDARY-END(120259543047)
            
            //--TRIMMABLE-BOUNDARY-START(124554510343)
            /*string */ get Name()
            {
                return this._innerEventInfo.Name;
            }
            //--TRIMMABLE-BOUNDARY-END(124554510343)
            
            //--TRIMMABLE-BOUNDARY-START(128849477639)
            /*Type? */ get ReflectedType()
            {
                return this._innerEventInfo.ReflectedType;
            }
            //--TRIMMABLE-BOUNDARY-END(128849477639)
            
            //--TRIMMABLE-BOUNDARY-START(94489739271)
            static /*void */ GetDataForComInvocation(/*EventInfo*/ eventInfo, /*out Guid*/ sourceIid, /*out int*/ dispid)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(94489739271);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*object[]*/ let comEventInterfaces = eventInfo.DeclaringType.GetCustomAttributes$1($.$$.SRI.ComEventInterfaceAttribute.$type, false);
                if (comEventInterfaces === null || comEventInterfaces.length === 0)
                {
                    throw new $.$$.S.InvalidOperationException().$ctor$12($.$sris.S.SR.InvalidOperation_NoComEventInterfaceAttribute);
                }
                /*ComEventInterfaceAttribute*/ let interfaceAttribute = $.$cast($.$$.System.Array.$ReadT1.call(comEventInterfaces, 0), $.$$.SRI.ComEventInterfaceAttribute);
                if (comEventInterfaces.length > 1)
                {
                    throw new $.$$.SR.AmbiguousMatchException().$ctor$12($.$sris.S.SR.Format$6($.$sris.S.SR.AmbiguousMatch_MultipleEventInterfaceAttributes, interfaceAttribute));
                }
                /*Type*/ let sourceInterface = interfaceAttribute.SourceInterface;
                /*Guid*/ let guid = sourceInterface.GUID;
                /*MethodInfo*/ let methodInfo = sourceInterface.GetMethod$12(eventInfo.Name);
                /*Attribute?*/ let dispIdAttribute = $.$$.S.Attribute.GetCustomAttribute$3(methodInfo, $.$$.SRI.DispIdAttribute.$type);
                if (dispIdAttribute === null)
                {
                    throw new $.$$.S.InvalidOperationException().$ctor$12($.$sris.S.SR.InvalidOperation_NoDispIdAttribute);
                }
                sourceIid.$v = guid;
                dispid.$v = ($.$cast(dispIdAttribute, $.$$.SRI.DispIdAttribute)).Value;
            }
            //--TRIMMABLE-BOUNDARY-END(94489739271)
            
            static $h = 458759;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.SR.EventInfo; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(17180327943),
    {
      "p": 114294785,
      "g": {
        "r": 0,
        "d": 0,
        "h": 30065229831,
        "f": 50364417
      },
      "n": "Attributes",
      "d": 458759,
      "h": 17180327943,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(17180327943),
//--TRIMMABLE-BOUNDARY-START(21475295239),
    {
      "p": 188547073,
      "g": {
        "r": 0,
        "d": 0,
        "h": 38655164423,
        "f": 50364417
      },
      "n": "DeclaringType",
      "d": 458759,
      "h": 21475295239,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(21475295239),
//--TRIMMABLE-BOUNDARY-START(115964575751),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 47245099015,
        "f": 50364417
      },
      "n": "MetadataToken",
      "d": 458759,
      "h": 115964575751,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(115964575751),
//--TRIMMABLE-BOUNDARY-START(120259543047),
    {
      "p": 118161409,
      "g": {
        "r": 0,
        "d": 0,
        "h": 55835033607,
        "f": 50364417
      },
      "n": "Module",
      "d": 458759,
      "h": 120259543047,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(120259543047),
//--TRIMMABLE-BOUNDARY-START(124554510343),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 64424968199,
        "f": 50364417
      },
      "n": "Name",
      "d": 458759,
      "h": 124554510343,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(124554510343),
//--TRIMMABLE-BOUNDARY-START(128849477639),
    {
      "p": 188547073,
      "g": {
        "r": 0,
        "d": 0,
        "h": 73014902791,
        "f": 50364417
      },
      "n": "ReflectedType",
      "d": 458759,
      "h": 128849477639,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(128849477639)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(12885360647),
    {
      "r": 65537,
      "p": [
        {
          "n": "target",
          "p": 131073
        },
        {
          "n": "handler",
          "p": 67502081
        }
      ],
      "n": "AddEventHandler",
      "d": 458759,
      "h": 12885360647,
      "f": 16809985,
      "a": [
        {
          "t": 159842305,
          "c": 4454809601,
          "a": [
            {
              "v": "windows",
              "t": 1310721
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(12885360647),
//--TRIMMABLE-BOUNDARY-START(133144444935),
    {
      "r": 65537,
      "p": [
        {
          "n": "target",
          "p": 131073
        },
        {
          "n": "handler",
          "p": 67502081
        }
      ],
      "n": "RemoveEventHandler",
      "d": 458759,
      "h": 133144444935,
      "f": 16809985,
      "a": [
        {
          "t": 159842305,
          "c": 4454809601,
          "a": [
            {
              "v": "windows",
              "t": 1310721
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(133144444935),
//--TRIMMABLE-BOUNDARY-START(77309870087),
    {
      "r": 117571585,
      "p": [
        {
          "n": "nonPublic",
          "p": 262145
        }
      ],
      "n": "GetAddMethod",
      "o": "@$1",
      "d": 458759,
      "h": 77309870087,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(77309870087),
//--TRIMMABLE-BOUNDARY-START(98784706567),
    {
      "r": $.$typeArray($.$$.SR.MethodInfo).$h,
      "p": [
        {
          "n": "nonPublic",
          "p": 262145
        }
      ],
      "n": "GetOtherMethods",
      "o": "@$1",
      "d": 458759,
      "h": 98784706567,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(98784706567),
//--TRIMMABLE-BOUNDARY-START(103079673863),
    {
      "r": 117571585,
      "p": [
        {
          "n": "nonPublic",
          "p": 262145
        }
      ],
      "n": "GetRaiseMethod",
      "o": "@$1",
      "d": 458759,
      "h": 103079673863,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(103079673863),
//--TRIMMABLE-BOUNDARY-START(107374641159),
    {
      "r": 117571585,
      "p": [
        {
          "n": "nonPublic",
          "p": 262145
        }
      ],
      "n": "GetRemoveMethod",
      "o": "@$1",
      "d": 458759,
      "h": 107374641159,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(107374641159),
//--TRIMMABLE-BOUNDARY-START(85899804679),
    {
      "r": $.$typeArray($.$$.S.Object).$h,
      "p": [
        {
          "n": "attributeType",
          "p": 188547073
        },
        {
          "n": "inherit",
          "p": 262145
        }
      ],
      "n": "GetCustomAttributes",
      "o": "@$1",
      "d": 458759,
      "h": 85899804679,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(85899804679),
//--TRIMMABLE-BOUNDARY-START(81604837383),
    {
      "r": $.$typeArray($.$$.S.Object).$h,
      "p": [
        {
          "n": "inherit",
          "p": 262145
        }
      ],
      "n": "GetCustomAttributes",
      "d": 458759,
      "h": 81604837383,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(81604837383),
//--TRIMMABLE-BOUNDARY-START(90194771975),
    {
      "r": $.$$.SCG.IList$$($.$$.SR.CustomAttributeData).$h,
      "n": "GetCustomAttributesData",
      "d": 458759,
      "h": 90194771975,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(90194771975),
//--TRIMMABLE-BOUNDARY-START(111669608455),
    {
      "r": 262145,
      "p": [
        {
          "n": "attributeType",
          "p": 188547073
        },
        {
          "n": "inherit",
          "p": 262145
        }
      ],
      "n": "IsDefined",
      "d": 458759,
      "h": 111669608455,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(111669608455),
//--TRIMMABLE-BOUNDARY-START(94489739271),
    {
      "r": 65537,
      "p": [
        {
          "n": "eventInfo",
          "p": 114360321
        },
        {
          "n": "sourceIid",
          "p": 89784321,
          "f": 2
        },
        {
          "n": "dispid",
          "p": 655361,
          "f": 2
        }
      ],
      "n": "GetDataForComInvocation",
      "d": 458759,
      "h": 94489739271,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(94489739271)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(4295426055),
    {
      "t": 114360321,
      "n": "_innerEventInfo",
      "d": 458759,
      "h": 4295426055,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(4295426055)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(8590393351),
    {
      "p": [
        {
          "n": "type",
          "p": 188547073
        },
        {
          "n": "eventName",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$4",
      "d": 458759,
      "h": 8590393351,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8590393351)
  ],
  "h": 458759,
  "a": [
    {
      "t": 65011713,
      "c": 12949913601,
      "a": [
        {
          "v": 1,
          "t": 65077249
        }
      ]
    }
  ]
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.SR.ICustomAttributeProvider ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `System.Runtime.InteropServices.ComAwareEventInfo`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `System${separator}Runtime${separator}InteropServices${separator}ComAwareEventInfo`; }
        });
        //--TRIMMABLE-BOUNDARY-END(458759)
        
        

        //--TRIMMABLE-BOUNDARY-START(1507335)
        $asm.$str(`$sris.SRI.ExporterEventKind`, ($self) => class ExporterEventKind extends $.$$.S.Enum$$$($self, $.$$.S.UInt32)
        {
            static NOTIF_TYPECONVERTED = 0;
            static NOTIF_CONVERTWARNING = 1;
            static ERROR_REFTOINVALIDASSEMBLY = 2;
            static $map;
            static get Map()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(1507335);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.$map ??= 
                {
                    "NOTIF_TYPECONVERTED": 0n,
                    "NOTIF_CONVERTWARNING": 1n,
                    "ERROR_REFTOINVALIDASSEMBLY": 2n
                };
            }
            //--TRIMMABLE-BOUNDARY-START(4296474631)
            //default constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296474631);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296474631)
            
            //--TRIMMABLE-BOUNDARY-START(4296474631)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$3();
            }
            //--TRIMMABLE-BOUNDARY-END(4296474631)
            
            static $h = 1507335;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Enum; }
            static get $eut() { return $.$$.S.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "u": 655361,
  "l": [
//--TRIMMABLE-BOUNDARY-START(17181376519),
    {
      "t": 1507335,
      "n": "NOTIF_TYPECONVERTED",
      "d": 1507335,
      "h": 17181376519,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(17181376519),
//--TRIMMABLE-BOUNDARY-START(12886409223),
    {
      "t": 1507335,
      "n": "NOTIF_CONVERTWARNING",
      "d": 1507335,
      "h": 12886409223,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(12886409223),
//--TRIMMABLE-BOUNDARY-START(8591441927),
    {
      "t": 1507335,
      "n": "ERROR_REFTOINVALIDASSEMBLY",
      "d": 1507335,
      "h": 8591441927,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(8591441927)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296474631),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 1507335,
      "h": 4296474631,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296474631)
  ],
  "h": 1507335
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.S.IComparable, $.$$.S.ISpanFormattable, $.$$.S.IFormattable, $.$$.S.IConvertible ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `System.Runtime.InteropServices.ExporterEventKind`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `System${separator}Runtime${separator}InteropServices${separator}ExporterEventKind`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1507335)
        
        

        //--TRIMMABLE-BOUNDARY-START(786439)
        $asm.$str(`$sris.SRIC.DATADIR`, ($self) => class DATADIR extends $.$$.S.Enum$$$($self, $.$$.S.UInt32)
        {
            static DATADIR_GET = 1;
            static DATADIR_SET = 2;
            static $map;
            static get Map()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(786439);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.$map ??= 
                {
                    "DATADIR_GET": 1n,
                    "DATADIR_SET": 2n
                };
            }
            //--TRIMMABLE-BOUNDARY-START(4295753735)
            //default constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295753735);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295753735)
            
            //--TRIMMABLE-BOUNDARY-START(4295753735)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$3();
            }
            //--TRIMMABLE-BOUNDARY-END(4295753735)
            
            static $h = 786439;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Enum; }
            static get $eut() { return $.$$.S.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "u": 655361,
  "l": [
//--TRIMMABLE-BOUNDARY-START(8590721031),
    {
      "t": 786439,
      "n": "DATADIR_GET",
      "d": 786439,
      "h": 8590721031,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(8590721031),
//--TRIMMABLE-BOUNDARY-START(12885688327),
    {
      "t": 786439,
      "n": "DATADIR_SET",
      "d": 786439,
      "h": 12885688327,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(12885688327)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295753735),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 786439,
      "h": 4295753735,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295753735)
  ],
  "h": 786439,
  "a": [
    {
      "t": 65011713,
      "c": 12949913601,
      "a": [
        {
          "v": 1,
          "t": 65077249
        }
      ]
    }
  ]
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.S.IComparable, $.$$.S.ISpanFormattable, $.$$.S.IFormattable, $.$$.S.IConvertible ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `System.Runtime.InteropServices.ComTypes.DATADIR`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `System${separator}Runtime${separator}InteropServices${separator}ComTypes${separator}DATADIR`; }
        });
        //--TRIMMABLE-BOUNDARY-END(786439)
        
        

        //--TRIMMABLE-BOUNDARY-START(851975)
        $asm.$str(`$sris.SRIC.DVASPECT`, ($self) => class DVASPECT extends $.$$.S.Enum$$$($self, $.$$.S.UInt32)
        {
            static DVASPECT_CONTENT = 1;
            static DVASPECT_THUMBNAIL = 2;
            static DVASPECT_ICON = 4;
            static DVASPECT_DOCPRINT = 8;
            static $map;
            static get Map()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(851975);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.$map ??= 
                {
                    "DVASPECT_CONTENT": 1n,
                    "DVASPECT_THUMBNAIL": 2n,
                    "DVASPECT_ICON": 4n,
                    "DVASPECT_DOCPRINT": 8n
                };
            }
            //--TRIMMABLE-BOUNDARY-START(4295819271)
            //default constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295819271);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295819271)
            
            //--TRIMMABLE-BOUNDARY-START(4295819271)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$3();
            }
            //--TRIMMABLE-BOUNDARY-END(4295819271)
            
            static $h = 851975;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Enum; }
            static get $eut() { return $.$$.S.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "u": 655361,
  "l": [
//--TRIMMABLE-BOUNDARY-START(8590786567),
    {
      "t": 851975,
      "n": "DVASPECT_CONTENT",
      "d": 851975,
      "h": 8590786567,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(8590786567),
//--TRIMMABLE-BOUNDARY-START(21475688455),
    {
      "t": 851975,
      "n": "DVASPECT_THUMBNAIL",
      "d": 851975,
      "h": 21475688455,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(21475688455),
//--TRIMMABLE-BOUNDARY-START(17180721159),
    {
      "t": 851975,
      "n": "DVASPECT_ICON",
      "d": 851975,
      "h": 17180721159,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(17180721159),
//--TRIMMABLE-BOUNDARY-START(12885753863),
    {
      "t": 851975,
      "n": "DVASPECT_DOCPRINT",
      "d": 851975,
      "h": 12885753863,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(12885753863)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295819271),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 851975,
      "h": 4295819271,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295819271)
  ],
  "h": 851975,
  "a": [
    {
      "t": 65011713,
      "c": 12949913601,
      "a": [
        {
          "v": 1,
          "t": 65077249
        }
      ]
    },
    {
      "t": 81264641,
      "c": 4376231937
    }
  ]
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.S.IComparable, $.$$.S.ISpanFormattable, $.$$.S.IFormattable, $.$$.S.IConvertible ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `System.Runtime.InteropServices.ComTypes.DVASPECT`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `System${separator}Runtime${separator}InteropServices${separator}ComTypes${separator}DVASPECT`; }
        });
        //--TRIMMABLE-BOUNDARY-END(851975)
        
        

        //--TRIMMABLE-BOUNDARY-START(262151)
        $asm.$str(`$sris.SRI.AssemblyRegistrationFlags`, ($self) => class AssemblyRegistrationFlags extends $.$$.S.Enum$$$($self, $.$$.S.UInt32)
        {
            static None = 0;
            static SetCodeBase = 1;
            static $map;
            static get Map()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(262151);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.$map ??= 
                {
                    "None": 0n,
                    "SetCodeBase": 1n
                };
            }
            //--TRIMMABLE-BOUNDARY-START(4295229447)
            //default constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295229447);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295229447)
            
            //--TRIMMABLE-BOUNDARY-START(4295229447)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$3();
            }
            //--TRIMMABLE-BOUNDARY-END(4295229447)
            
            static $h = 262151;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Enum; }
            static get $eut() { return $.$$.S.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "u": 655361,
  "l": [
//--TRIMMABLE-BOUNDARY-START(8590196743),
    {
      "t": 262151,
      "n": "None",
      "d": 262151,
      "h": 8590196743,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(8590196743),
//--TRIMMABLE-BOUNDARY-START(12885164039),
    {
      "t": 262151,
      "n": "SetCodeBase",
      "d": 262151,
      "h": 12885164039,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(12885164039)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295229447),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 262151,
      "h": 4295229447,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295229447)
  ],
  "h": 262151,
  "a": [
    {
      "t": 81264641,
      "c": 4376231937
    }
  ]
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.S.IComparable, $.$$.S.ISpanFormattable, $.$$.S.IFormattable, $.$$.S.IConvertible ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `System.Runtime.InteropServices.AssemblyRegistrationFlags`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `System${separator}Runtime${separator}InteropServices${separator}AssemblyRegistrationFlags`; }
        });
        //--TRIMMABLE-BOUNDARY-END(262151)
        
        

        //--TRIMMABLE-BOUNDARY-START(1376263)
        $asm.$str(`$sris.SRIC.TYMED`, ($self) => class TYMED extends $.$$.S.Enum$$$($self, $.$$.S.UInt32)
        {
            static TYMED_HGLOBAL = 1;
            static TYMED_FILE = 2;
            static TYMED_ISTREAM = 4;
            static TYMED_ISTORAGE = 8;
            static TYMED_GDI = 16;
            static TYMED_MFPICT = 32;
            static TYMED_ENHMF = 64;
            static TYMED_NULL = 0;
            static $map;
            static get Map()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(1376263);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.$map ??= 
                {
                    "TYMED_HGLOBAL": 1n,
                    "TYMED_FILE": 2n,
                    "TYMED_ISTREAM": 4n,
                    "TYMED_ISTORAGE": 8n,
                    "TYMED_GDI": 16n,
                    "TYMED_MFPICT": 32n,
                    "TYMED_ENHMF": 64n,
                    "TYMED_NULL": 0n
                };
            }
            //--TRIMMABLE-BOUNDARY-START(4296343559)
            //default constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296343559);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296343559)
            
            //--TRIMMABLE-BOUNDARY-START(4296343559)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$3();
            }
            //--TRIMMABLE-BOUNDARY-END(4296343559)
            
            static $h = 1376263;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Enum; }
            static get $eut() { return $.$$.S.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "u": 655361,
  "l": [
//--TRIMMABLE-BOUNDARY-START(21476212743),
    {
      "t": 1376263,
      "n": "TYMED_HGLOBAL",
      "d": 1376263,
      "h": 21476212743,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(21476212743),
//--TRIMMABLE-BOUNDARY-START(12886278151),
    {
      "t": 1376263,
      "n": "TYMED_FILE",
      "d": 1376263,
      "h": 12886278151,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(12886278151),
//--TRIMMABLE-BOUNDARY-START(30066147335),
    {
      "t": 1376263,
      "n": "TYMED_ISTREAM",
      "d": 1376263,
      "h": 30066147335,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(30066147335),
//--TRIMMABLE-BOUNDARY-START(25771180039),
    {
      "t": 1376263,
      "n": "TYMED_ISTORAGE",
      "d": 1376263,
      "h": 25771180039,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(25771180039),
//--TRIMMABLE-BOUNDARY-START(17181245447),
    {
      "t": 1376263,
      "n": "TYMED_GDI",
      "d": 1376263,
      "h": 17181245447,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(17181245447),
//--TRIMMABLE-BOUNDARY-START(34361114631),
    {
      "t": 1376263,
      "n": "TYMED_MFPICT",
      "d": 1376263,
      "h": 34361114631,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(34361114631),
//--TRIMMABLE-BOUNDARY-START(8591310855),
    {
      "t": 1376263,
      "n": "TYMED_ENHMF",
      "d": 1376263,
      "h": 8591310855,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(8591310855),
//--TRIMMABLE-BOUNDARY-START(38656081927),
    {
      "t": 1376263,
      "n": "TYMED_NULL",
      "d": 1376263,
      "h": 38656081927,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(38656081927)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296343559),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 1376263,
      "h": 4296343559,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296343559)
  ],
  "h": 1376263,
  "a": [
    {
      "t": 65011713,
      "c": 12949913601,
      "a": [
        {
          "v": 1,
          "t": 65077249
        }
      ]
    },
    {
      "t": 81264641,
      "c": 4376231937
    }
  ]
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.S.IComparable, $.$$.S.ISpanFormattable, $.$$.S.IFormattable, $.$$.S.IConvertible ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `System.Runtime.InteropServices.ComTypes.TYMED`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `System${separator}Runtime${separator}InteropServices${separator}ComTypes${separator}TYMED`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1376263)
        
        

        //--TRIMMABLE-BOUNDARY-START(720903)
        $asm.$str(`$sris.SRIC.ADVF`, ($self) => class ADVF extends $.$$.S.Enum$$$($self, $.$$.S.UInt32)
        {
            static ADVF_NODATA = 1;
            static ADVF_PRIMEFIRST = 2;
            static ADVF_ONLYONCE = 4;
            static ADVF_DATAONSTOP = 64;
            static ADVFCACHE_NOHANDLER = 8;
            static ADVFCACHE_FORCEBUILTIN = 16;
            static ADVFCACHE_ONSAVE = 32;
            static $map;
            static get Map()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(720903);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.$map ??= 
                {
                    "ADVF_NODATA": 1n,
                    "ADVF_PRIMEFIRST": 2n,
                    "ADVF_ONLYONCE": 4n,
                    "ADVF_DATAONSTOP": 64n,
                    "ADVFCACHE_NOHANDLER": 8n,
                    "ADVFCACHE_FORCEBUILTIN": 16n,
                    "ADVFCACHE_ONSAVE": 32n
                };
            }
            //--TRIMMABLE-BOUNDARY-START(4295688199)
            //default constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295688199);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295688199)
            
            //--TRIMMABLE-BOUNDARY-START(4295688199)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$3();
            }
            //--TRIMMABLE-BOUNDARY-END(4295688199)
            
            static $h = 720903;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Enum; }
            static get $eut() { return $.$$.S.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "u": 655361,
  "l": [
//--TRIMMABLE-BOUNDARY-START(12885622791),
    {
      "t": 720903,
      "n": "ADVF_NODATA",
      "d": 720903,
      "h": 12885622791,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(12885622791),
//--TRIMMABLE-BOUNDARY-START(21475557383),
    {
      "t": 720903,
      "n": "ADVF_PRIMEFIRST",
      "d": 720903,
      "h": 21475557383,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(21475557383),
//--TRIMMABLE-BOUNDARY-START(17180590087),
    {
      "t": 720903,
      "n": "ADVF_ONLYONCE",
      "d": 720903,
      "h": 17180590087,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(17180590087),
//--TRIMMABLE-BOUNDARY-START(8590655495),
    {
      "t": 720903,
      "n": "ADVF_DATAONSTOP",
      "d": 720903,
      "h": 8590655495,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(8590655495),
//--TRIMMABLE-BOUNDARY-START(30065491975),
    {
      "t": 720903,
      "n": "ADVFCACHE_NOHANDLER",
      "d": 720903,
      "h": 30065491975,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(30065491975),
//--TRIMMABLE-BOUNDARY-START(25770524679),
    {
      "t": 720903,
      "n": "ADVFCACHE_FORCEBUILTIN",
      "d": 720903,
      "h": 25770524679,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(25770524679),
//--TRIMMABLE-BOUNDARY-START(34360459271),
    {
      "t": 720903,
      "n": "ADVFCACHE_ONSAVE",
      "d": 720903,
      "h": 34360459271,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(34360459271)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295688199),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 720903,
      "h": 4295688199,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295688199)
  ],
  "h": 720903,
  "a": [
    {
      "t": 65011713,
      "c": 12949913601,
      "a": [
        {
          "v": 1,
          "t": 65077249
        }
      ]
    },
    {
      "t": 81264641,
      "c": 4376231937
    }
  ]
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.S.IComparable, $.$$.S.ISpanFormattable, $.$$.S.IFormattable, $.$$.S.IConvertible ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `System.Runtime.InteropServices.ComTypes.ADVF`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `System${separator}Runtime${separator}InteropServices${separator}ComTypes${separator}ADVF`; }
        });
        //--TRIMMABLE-BOUNDARY-END(720903)
        
        

        //--TRIMMABLE-BOUNDARY-START(2097159)
        $asm.$str(`$sris.SRIM.ComInterfaceOptions`, ($self) => class ComInterfaceOptions extends $.$$.S.Enum$$$($self, $.$$.S.UInt32)
        {
            static None = 0;
            static ManagedObjectWrapper = 1;
            static ComObjectWrapper = 2;
            static $map;
            static get Map()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(2097159);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.$map ??= 
                {
                    "None": 0n,
                    "ManagedObjectWrapper": 1n,
                    "ComObjectWrapper": 2n
                };
            }
            //--TRIMMABLE-BOUNDARY-START(4297064455)
            //default constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4297064455);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4297064455)
            
            //--TRIMMABLE-BOUNDARY-START(4297064455)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$3();
            }
            //--TRIMMABLE-BOUNDARY-END(4297064455)
            
            static $h = 2097159;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Enum; }
            static get $eut() { return $.$$.S.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "u": 655361,
  "l": [
//--TRIMMABLE-BOUNDARY-START(17181966343),
    {
      "t": 2097159,
      "n": "None",
      "d": 2097159,
      "h": 17181966343,
      "f": 4194337,
      "a": [
        {
          "t": 65011713,
          "c": 12949913601,
          "a": [
            {
              "v": 1,
              "t": 65077249
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(17181966343),
//--TRIMMABLE-BOUNDARY-START(12886999047),
    {
      "t": 2097159,
      "n": "ManagedObjectWrapper",
      "d": 2097159,
      "h": 12886999047,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(12886999047),
//--TRIMMABLE-BOUNDARY-START(8592031751),
    {
      "t": 2097159,
      "n": "ComObjectWrapper",
      "d": 2097159,
      "h": 8592031751,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(8592031751)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4297064455),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 2097159,
      "h": 4297064455,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4297064455)
  ],
  "h": 2097159,
  "a": [
    {
      "t": 81264641,
      "c": 4376231937
    }
  ]
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.S.IComparable, $.$$.S.ISpanFormattable, $.$$.S.IFormattable, $.$$.S.IConvertible ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `System.Runtime.InteropServices.Marshalling.ComInterfaceOptions`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `System${separator}Runtime${separator}InteropServices${separator}Marshalling${separator}ComInterfaceOptions`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2097159)
        
        

        //--TRIMMABLE-BOUNDARY-START(4325383)
        $asm.$str(`$sris.SRI.TypeLibTypeFlags`, ($self) => class TypeLibTypeFlags extends $.$$.S.Enum$$$($self, $.$$.S.UInt32)
        {
            static FAppObject = 1;
            static FCanCreate = 2;
            static FLicensed = 4;
            static FPreDeclId = 8;
            static FHidden = 16;
            static FControl = 32;
            static FDual = 64;
            static FNonExtensible = 128;
            static FOleAutomation = 256;
            static FRestricted = 512;
            static FAggregatable = 1024;
            static FReplaceable = 2048;
            static FDispatchable = 4096;
            static FReverseBind = 8192;
            static $map;
            static get Map()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4325383);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.$map ??= 
                {
                    "FAppObject": 1n,
                    "FCanCreate": 2n,
                    "FLicensed": 4n,
                    "FPreDeclId": 8n,
                    "FHidden": 16n,
                    "FControl": 32n,
                    "FDual": 64n,
                    "FNonExtensible": 128n,
                    "FOleAutomation": 256n,
                    "FRestricted": 512n,
                    "FAggregatable": 1024n,
                    "FReplaceable": 2048n,
                    "FDispatchable": 4096n,
                    "FReverseBind": 8192n
                };
            }
            //--TRIMMABLE-BOUNDARY-START(4299292679)
            //default constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4299292679);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4299292679)
            
            //--TRIMMABLE-BOUNDARY-START(4299292679)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$3();
            }
            //--TRIMMABLE-BOUNDARY-END(4299292679)
            
            static $h = 4325383;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Enum; }
            static get $eut() { return $.$$.S.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "u": 655361,
  "l": [
//--TRIMMABLE-BOUNDARY-START(12889227271),
    {
      "t": 4325383,
      "n": "FAppObject",
      "d": 4325383,
      "h": 12889227271,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(12889227271),
//--TRIMMABLE-BOUNDARY-START(17184194567),
    {
      "t": 4325383,
      "n": "FCanCreate",
      "d": 4325383,
      "h": 17184194567,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(17184194567),
//--TRIMMABLE-BOUNDARY-START(38659031047),
    {
      "t": 4325383,
      "n": "FLicensed",
      "d": 4325383,
      "h": 38659031047,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(38659031047),
//--TRIMMABLE-BOUNDARY-START(51543932935),
    {
      "t": 4325383,
      "n": "FPreDeclId",
      "d": 4325383,
      "h": 51543932935,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(51543932935),
//--TRIMMABLE-BOUNDARY-START(34364063751),
    {
      "t": 4325383,
      "n": "FHidden",
      "d": 4325383,
      "h": 34364063751,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(34364063751),
//--TRIMMABLE-BOUNDARY-START(21479161863),
    {
      "t": 4325383,
      "n": "FControl",
      "d": 4325383,
      "h": 21479161863,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(21479161863),
//--TRIMMABLE-BOUNDARY-START(30069096455),
    {
      "t": 4325383,
      "n": "FDual",
      "d": 4325383,
      "h": 30069096455,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(30069096455),
//--TRIMMABLE-BOUNDARY-START(42953998343),
    {
      "t": 4325383,
      "n": "FNonExtensible",
      "d": 4325383,
      "h": 42953998343,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(42953998343),
//--TRIMMABLE-BOUNDARY-START(47248965639),
    {
      "t": 4325383,
      "n": "FOleAutomation",
      "d": 4325383,
      "h": 47248965639,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(47248965639),
//--TRIMMABLE-BOUNDARY-START(60133867527),
    {
      "t": 4325383,
      "n": "FRestricted",
      "d": 4325383,
      "h": 60133867527,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(60133867527),
//--TRIMMABLE-BOUNDARY-START(8594259975),
    {
      "t": 4325383,
      "n": "FAggregatable",
      "d": 4325383,
      "h": 8594259975,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(8594259975),
//--TRIMMABLE-BOUNDARY-START(55838900231),
    {
      "t": 4325383,
      "n": "FReplaceable",
      "d": 4325383,
      "h": 55838900231,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(55838900231),
//--TRIMMABLE-BOUNDARY-START(25774129159),
    {
      "t": 4325383,
      "n": "FDispatchable",
      "d": 4325383,
      "h": 25774129159,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(25774129159),
//--TRIMMABLE-BOUNDARY-START(64428834823),
    {
      "t": 4325383,
      "n": "FReverseBind",
      "d": 4325383,
      "h": 64428834823,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(64428834823)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4299292679),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 4325383,
      "h": 4299292679,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4299292679)
  ],
  "h": 4325383,
  "a": [
    {
      "t": 81264641,
      "c": 4376231937
    }
  ]
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.S.IComparable, $.$$.S.ISpanFormattable, $.$$.S.IFormattable, $.$$.S.IConvertible ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `System.Runtime.InteropServices.TypeLibTypeFlags`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `System${separator}Runtime${separator}InteropServices${separator}TypeLibTypeFlags`; }
        });
        //--TRIMMABLE-BOUNDARY-END(4325383)
        
        

        //--TRIMMABLE-BOUNDARY-START(3866631)
        $asm.$str(`$sris.SRI.RegistrationClassContext`, ($self) => class RegistrationClassContext extends $.$$.S.Enum$$$($self, $.$$.S.UInt32)
        {
            static InProcessServer = 1;
            static InProcessHandler = 2;
            static LocalServer = 4;
            static InProcessServer16 = 8;
            static RemoteServer = 16;
            static InProcessHandler16 = 32;
            static Reserved1 = 64;
            static Reserved2 = 128;
            static Reserved3 = 256;
            static Reserved4 = 512;
            static NoCodeDownload = 1024;
            static Reserved5 = 2048;
            static NoCustomMarshal = 4096;
            static EnableCodeDownload = 8192;
            static NoFailureLog = 16384;
            static DisableActivateAsActivator = 32768;
            static EnableActivateAsActivator = 65536;
            static FromDefaultContext = 131072;
            static $map;
            static get Map()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(3866631);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.$map ??= 
                {
                    "InProcessServer": 1n,
                    "InProcessHandler": 2n,
                    "LocalServer": 4n,
                    "InProcessServer16": 8n,
                    "RemoteServer": 16n,
                    "InProcessHandler16": 32n,
                    "Reserved1": 64n,
                    "Reserved2": 128n,
                    "Reserved3": 256n,
                    "Reserved4": 512n,
                    "NoCodeDownload": 1024n,
                    "Reserved5": 2048n,
                    "NoCustomMarshal": 4096n,
                    "EnableCodeDownload": 8192n,
                    "NoFailureLog": 16384n,
                    "DisableActivateAsActivator": 32768n,
                    "EnableActivateAsActivator": 65536n,
                    "FromDefaultContext": 131072n
                };
            }
            //--TRIMMABLE-BOUNDARY-START(4298833927)
            //default constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4298833927);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4298833927)
            
            //--TRIMMABLE-BOUNDARY-START(4298833927)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$3();
            }
            //--TRIMMABLE-BOUNDARY-END(4298833927)
            
            static $h = 3866631;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Enum; }
            static get $eut() { return $.$$.S.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "u": 655361,
  "l": [
//--TRIMMABLE-BOUNDARY-START(34363604999),
    {
      "t": 3866631,
      "n": "InProcessServer",
      "d": 3866631,
      "h": 34363604999,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(34363604999),
//--TRIMMABLE-BOUNDARY-START(25773670407),
    {
      "t": 3866631,
      "n": "InProcessHandler",
      "d": 3866631,
      "h": 25773670407,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(25773670407),
//--TRIMMABLE-BOUNDARY-START(42953539591),
    {
      "t": 3866631,
      "n": "LocalServer",
      "d": 3866631,
      "h": 42953539591,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(42953539591),
//--TRIMMABLE-BOUNDARY-START(38658572295),
    {
      "t": 3866631,
      "n": "InProcessServer16",
      "d": 3866631,
      "h": 38658572295,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(38658572295),
//--TRIMMABLE-BOUNDARY-START(60133408775),
    {
      "t": 3866631,
      "n": "RemoteServer",
      "d": 3866631,
      "h": 60133408775,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(60133408775),
//--TRIMMABLE-BOUNDARY-START(30068637703),
    {
      "t": 3866631,
      "n": "InProcessHandler16",
      "d": 3866631,
      "h": 30068637703,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(30068637703),
//--TRIMMABLE-BOUNDARY-START(64428376071),
    {
      "t": 3866631,
      "n": "Reserved1",
      "d": 3866631,
      "h": 64428376071,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(64428376071),
//--TRIMMABLE-BOUNDARY-START(68723343367),
    {
      "t": 3866631,
      "n": "Reserved2",
      "d": 3866631,
      "h": 68723343367,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(68723343367),
//--TRIMMABLE-BOUNDARY-START(73018310663),
    {
      "t": 3866631,
      "n": "Reserved3",
      "d": 3866631,
      "h": 73018310663,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(73018310663),
//--TRIMMABLE-BOUNDARY-START(77313277959),
    {
      "t": 3866631,
      "n": "Reserved4",
      "d": 3866631,
      "h": 77313277959,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(77313277959),
//--TRIMMABLE-BOUNDARY-START(47248506887),
    {
      "t": 3866631,
      "n": "NoCodeDownload",
      "d": 3866631,
      "h": 47248506887,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(47248506887),
//--TRIMMABLE-BOUNDARY-START(81608245255),
    {
      "t": 3866631,
      "n": "Reserved5",
      "d": 3866631,
      "h": 81608245255,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(81608245255),
//--TRIMMABLE-BOUNDARY-START(51543474183),
    {
      "t": 3866631,
      "n": "NoCustomMarshal",
      "d": 3866631,
      "h": 51543474183,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(51543474183),
//--TRIMMABLE-BOUNDARY-START(17183735815),
    {
      "t": 3866631,
      "n": "EnableCodeDownload",
      "d": 3866631,
      "h": 17183735815,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(17183735815),
//--TRIMMABLE-BOUNDARY-START(55838441479),
    {
      "t": 3866631,
      "n": "NoFailureLog",
      "d": 3866631,
      "h": 55838441479,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(55838441479),
//--TRIMMABLE-BOUNDARY-START(8593801223),
    {
      "t": 3866631,
      "n": "DisableActivateAsActivator",
      "d": 3866631,
      "h": 8593801223,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(8593801223),
//--TRIMMABLE-BOUNDARY-START(12888768519),
    {
      "t": 3866631,
      "n": "EnableActivateAsActivator",
      "d": 3866631,
      "h": 12888768519,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(12888768519),
//--TRIMMABLE-BOUNDARY-START(21478703111),
    {
      "t": 3866631,
      "n": "FromDefaultContext",
      "d": 3866631,
      "h": 21478703111,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(21478703111)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4298833927),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 3866631,
      "h": 4298833927,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4298833927)
  ],
  "h": 3866631,
  "a": [
    {
      "t": 81264641,
      "c": 4376231937
    }
  ]
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.S.IComparable, $.$$.S.ISpanFormattable, $.$$.S.IFormattable, $.$$.S.IConvertible ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `System.Runtime.InteropServices.RegistrationClassContext`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `System${separator}Runtime${separator}InteropServices${separator}RegistrationClassContext`; }
        });
        //--TRIMMABLE-BOUNDARY-END(3866631)
        
        

        //--TRIMMABLE-BOUNDARY-START(4456455)
        $asm.$str(`$sris.SRI.TypeLibVarFlags`, ($self) => class TypeLibVarFlags extends $.$$.S.Enum$$$($self, $.$$.S.UInt32)
        {
            static FReadOnly = 1;
            static FSource = 2;
            static FBindable = 4;
            static FRequestEdit = 8;
            static FDisplayBind = 16;
            static FDefaultBind = 32;
            static FHidden = 64;
            static FRestricted = 128;
            static FDefaultCollelem = 256;
            static FUiDefault = 512;
            static FNonBrowsable = 1024;
            static FReplaceable = 2048;
            static FImmediateBind = 4096;
            static $map;
            static get Map()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4456455);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.$map ??= 
                {
                    "FReadOnly": 1n,
                    "FSource": 2n,
                    "FBindable": 4n,
                    "FRequestEdit": 8n,
                    "FDisplayBind": 16n,
                    "FDefaultBind": 32n,
                    "FHidden": 64n,
                    "FRestricted": 128n,
                    "FDefaultCollelem": 256n,
                    "FUiDefault": 512n,
                    "FNonBrowsable": 1024n,
                    "FReplaceable": 2048n,
                    "FImmediateBind": 4096n
                };
            }
            //--TRIMMABLE-BOUNDARY-START(4299423751)
            //default constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4299423751);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4299423751)
            
            //--TRIMMABLE-BOUNDARY-START(4299423751)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$3();
            }
            //--TRIMMABLE-BOUNDARY-END(4299423751)
            
            static $h = 4456455;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Enum; }
            static get $eut() { return $.$$.S.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "u": 655361,
  "l": [
//--TRIMMABLE-BOUNDARY-START(38659162119),
    {
      "t": 4456455,
      "n": "FReadOnly",
      "d": 4456455,
      "h": 38659162119,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(38659162119),
//--TRIMMABLE-BOUNDARY-START(55839031303),
    {
      "t": 4456455,
      "n": "FSource",
      "d": 4456455,
      "h": 55839031303,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(55839031303),
//--TRIMMABLE-BOUNDARY-START(8594391047),
    {
      "t": 4456455,
      "n": "FBindable",
      "d": 4456455,
      "h": 8594391047,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(8594391047),
//--TRIMMABLE-BOUNDARY-START(47249096711),
    {
      "t": 4456455,
      "n": "FRequestEdit",
      "d": 4456455,
      "h": 47249096711,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(47249096711),
//--TRIMMABLE-BOUNDARY-START(21479292935),
    {
      "t": 4456455,
      "n": "FDisplayBind",
      "d": 4456455,
      "h": 21479292935,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(21479292935),
//--TRIMMABLE-BOUNDARY-START(12889358343),
    {
      "t": 4456455,
      "n": "FDefaultBind",
      "d": 4456455,
      "h": 12889358343,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(12889358343),
//--TRIMMABLE-BOUNDARY-START(25774260231),
    {
      "t": 4456455,
      "n": "FHidden",
      "d": 4456455,
      "h": 25774260231,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(25774260231),
//--TRIMMABLE-BOUNDARY-START(51544064007),
    {
      "t": 4456455,
      "n": "FRestricted",
      "d": 4456455,
      "h": 51544064007,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(51544064007),
//--TRIMMABLE-BOUNDARY-START(17184325639),
    {
      "t": 4456455,
      "n": "FDefaultCollelem",
      "d": 4456455,
      "h": 17184325639,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(17184325639),
//--TRIMMABLE-BOUNDARY-START(60133998599),
    {
      "t": 4456455,
      "n": "FUiDefault",
      "d": 4456455,
      "h": 60133998599,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(60133998599),
//--TRIMMABLE-BOUNDARY-START(34364194823),
    {
      "t": 4456455,
      "n": "FNonBrowsable",
      "d": 4456455,
      "h": 34364194823,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(34364194823),
//--TRIMMABLE-BOUNDARY-START(42954129415),
    {
      "t": 4456455,
      "n": "FReplaceable",
      "d": 4456455,
      "h": 42954129415,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(42954129415),
//--TRIMMABLE-BOUNDARY-START(30069227527),
    {
      "t": 4456455,
      "n": "FImmediateBind",
      "d": 4456455,
      "h": 30069227527,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(30069227527)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4299423751),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 4456455,
      "h": 4299423751,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4299423751)
  ],
  "h": 4456455,
  "a": [
    {
      "t": 81264641,
      "c": 4376231937
    }
  ]
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.S.IComparable, $.$$.S.ISpanFormattable, $.$$.S.IFormattable, $.$$.S.IConvertible ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `System.Runtime.InteropServices.TypeLibVarFlags`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `System${separator}Runtime${separator}InteropServices${separator}TypeLibVarFlags`; }
        });
        //--TRIMMABLE-BOUNDARY-END(4456455)
        
        

        //--TRIMMABLE-BOUNDARY-START(4128775)
        $asm.$str(`$sris.SRI.TypeLibFuncFlags`, ($self) => class TypeLibFuncFlags extends $.$$.S.Enum$$$($self, $.$$.S.UInt32)
        {
            static FRestricted = 1;
            static FSource = 2;
            static FBindable = 4;
            static FRequestEdit = 8;
            static FDisplayBind = 16;
            static FDefaultBind = 32;
            static FHidden = 64;
            static FUsesGetLastError = 128;
            static FDefaultCollelem = 256;
            static FUiDefault = 512;
            static FNonBrowsable = 1024;
            static FReplaceable = 2048;
            static FImmediateBind = 4096;
            static $map;
            static get Map()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4128775);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.$map ??= 
                {
                    "FRestricted": 1n,
                    "FSource": 2n,
                    "FBindable": 4n,
                    "FRequestEdit": 8n,
                    "FDisplayBind": 16n,
                    "FDefaultBind": 32n,
                    "FHidden": 64n,
                    "FUsesGetLastError": 128n,
                    "FDefaultCollelem": 256n,
                    "FUiDefault": 512n,
                    "FNonBrowsable": 1024n,
                    "FReplaceable": 2048n,
                    "FImmediateBind": 4096n
                };
            }
            //--TRIMMABLE-BOUNDARY-START(4299096071)
            //default constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4299096071);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4299096071)
            
            //--TRIMMABLE-BOUNDARY-START(4299096071)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$3();
            }
            //--TRIMMABLE-BOUNDARY-END(4299096071)
            
            static $h = 4128775;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Enum; }
            static get $eut() { return $.$$.S.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "u": 655361,
  "l": [
//--TRIMMABLE-BOUNDARY-START(47248769031),
    {
      "t": 4128775,
      "n": "FRestricted",
      "d": 4128775,
      "h": 47248769031,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(47248769031),
//--TRIMMABLE-BOUNDARY-START(51543736327),
    {
      "t": 4128775,
      "n": "FSource",
      "d": 4128775,
      "h": 51543736327,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(51543736327),
//--TRIMMABLE-BOUNDARY-START(8594063367),
    {
      "t": 4128775,
      "n": "FBindable",
      "d": 4128775,
      "h": 8594063367,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(8594063367),
//--TRIMMABLE-BOUNDARY-START(42953801735),
    {
      "t": 4128775,
      "n": "FRequestEdit",
      "d": 4128775,
      "h": 42953801735,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(42953801735),
//--TRIMMABLE-BOUNDARY-START(21478965255),
    {
      "t": 4128775,
      "n": "FDisplayBind",
      "d": 4128775,
      "h": 21478965255,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(21478965255),
//--TRIMMABLE-BOUNDARY-START(12889030663),
    {
      "t": 4128775,
      "n": "FDefaultBind",
      "d": 4128775,
      "h": 12889030663,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(12889030663),
//--TRIMMABLE-BOUNDARY-START(25773932551),
    {
      "t": 4128775,
      "n": "FHidden",
      "d": 4128775,
      "h": 25773932551,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(25773932551),
//--TRIMMABLE-BOUNDARY-START(60133670919),
    {
      "t": 4128775,
      "n": "FUsesGetLastError",
      "d": 4128775,
      "h": 60133670919,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(60133670919),
//--TRIMMABLE-BOUNDARY-START(17183997959),
    {
      "t": 4128775,
      "n": "FDefaultCollelem",
      "d": 4128775,
      "h": 17183997959,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(17183997959),
//--TRIMMABLE-BOUNDARY-START(55838703623),
    {
      "t": 4128775,
      "n": "FUiDefault",
      "d": 4128775,
      "h": 55838703623,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(55838703623),
//--TRIMMABLE-BOUNDARY-START(34363867143),
    {
      "t": 4128775,
      "n": "FNonBrowsable",
      "d": 4128775,
      "h": 34363867143,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(34363867143),
//--TRIMMABLE-BOUNDARY-START(38658834439),
    {
      "t": 4128775,
      "n": "FReplaceable",
      "d": 4128775,
      "h": 38658834439,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(38658834439),
//--TRIMMABLE-BOUNDARY-START(30068899847),
    {
      "t": 4128775,
      "n": "FImmediateBind",
      "d": 4128775,
      "h": 30068899847,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(30068899847)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4299096071),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 4128775,
      "h": 4299096071,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4299096071)
  ],
  "h": 4128775,
  "a": [
    {
      "t": 81264641,
      "c": 4376231937
    }
  ]
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.S.IComparable, $.$$.S.ISpanFormattable, $.$$.S.IFormattable, $.$$.S.IConvertible ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `System.Runtime.InteropServices.TypeLibFuncFlags`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `System${separator}Runtime${separator}InteropServices${separator}TypeLibFuncFlags`; }
        });
        //--TRIMMABLE-BOUNDARY-END(4128775)
        
        

        //--TRIMMABLE-BOUNDARY-START(3932167)
        $asm.$str(`$sris.SRI.RegistrationConnectionType`, ($self) => class RegistrationConnectionType extends $.$$.S.Enum$$$($self, $.$$.S.UInt32)
        {
            static SingleUse = 0;
            static MultipleUse = 1;
            static MultiSeparate = 2;
            static Suspended = 4;
            static Surrogate = 8;
            static $map;
            static get Map()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(3932167);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.$map ??= 
                {
                    "SingleUse": 0n,
                    "MultipleUse": 1n,
                    "MultiSeparate": 2n,
                    "Suspended": 4n,
                    "Surrogate": 8n
                };
            }
            //--TRIMMABLE-BOUNDARY-START(4298899463)
            //default constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4298899463);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4298899463)
            
            //--TRIMMABLE-BOUNDARY-START(4298899463)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$3();
            }
            //--TRIMMABLE-BOUNDARY-END(4298899463)
            
            static $h = 3932167;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Enum; }
            static get $eut() { return $.$$.S.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "u": 655361,
  "l": [
//--TRIMMABLE-BOUNDARY-START(17183801351),
    {
      "t": 3932167,
      "n": "SingleUse",
      "d": 3932167,
      "h": 17183801351,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(17183801351),
//--TRIMMABLE-BOUNDARY-START(8593866759),
    {
      "t": 3932167,
      "n": "MultipleUse",
      "d": 3932167,
      "h": 8593866759,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(8593866759),
//--TRIMMABLE-BOUNDARY-START(12888834055),
    {
      "t": 3932167,
      "n": "MultiSeparate",
      "d": 3932167,
      "h": 12888834055,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(12888834055),
//--TRIMMABLE-BOUNDARY-START(25773735943),
    {
      "t": 3932167,
      "n": "Suspended",
      "d": 3932167,
      "h": 25773735943,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(25773735943),
//--TRIMMABLE-BOUNDARY-START(21478768647),
    {
      "t": 3932167,
      "n": "Surrogate",
      "d": 3932167,
      "h": 21478768647,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(21478768647)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4298899463),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 3932167,
      "h": 4298899463,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4298899463)
  ],
  "h": 3932167,
  "a": [
    {
      "t": 81264641,
      "c": 4376231937
    }
  ]
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.S.IComparable, $.$$.S.ISpanFormattable, $.$$.S.IFormattable, $.$$.S.IConvertible ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `System.Runtime.InteropServices.RegistrationConnectionType`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `System${separator}Runtime${separator}InteropServices${separator}RegistrationConnectionType`; }
        });
        //--TRIMMABLE-BOUNDARY-END(3932167)
        
        

        //--TRIMMABLE-BOUNDARY-START(2162695)
        $asm.$cls(`$sris.SRIM.ComObject`, ($self) => class ComObject extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(51541770247)
            /*bool*/ static BuiltInComSupported = false;
            //--TRIMMABLE-BOUNDARY-END(51541770247)
            
            //--TRIMMABLE-BOUNDARY-START(60131704839)
            /*bool*/ static ComImportInteropEnabled = false;
            //--TRIMMABLE-BOUNDARY-END(60131704839)
            
            //--TRIMMABLE-BOUNDARY-START(4297129991)
            /*void**/ _instancePointer;
            //--TRIMMABLE-BOUNDARY-END(4297129991)
            
            //--TRIMMABLE-BOUNDARY-START(12887064583)
            /*object?*/ _runtimeCallableWrapper = null;
            //--TRIMMABLE-BOUNDARY-END(12887064583)
            
            //--TRIMMABLE-BOUNDARY-START(8592097287)
            /*bool*/ _released = false;
            //--TRIMMABLE-BOUNDARY-END(8592097287)
            
            //--TRIMMABLE-BOUNDARY-START(47246802951)
            $ctor$1(/*IIUnknownInterfaceDetailsStrategy*/ interfaceDetailsStrategy, /*IIUnknownStrategy*/ iunknownStrategy, /*IIUnknownCacheStrategy*/ cacheStrategy, /*void**/ thisPointer)
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(47246802951);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this.InterfaceDetailsStrategy = interfaceDetailsStrategy;
                    this.IUnknownStrategy = iunknownStrategy;
                    this.CacheStrategy = cacheStrategy;
                    this._instancePointer = this.IUnknownStrategy.SRIM$IIUnknownStrategy$CreateInstancePointer(thisPointer);
                    if ($.$$.S.OperatingSystem.IsWindows() && $.$sris.SRIM.ComObject.BuiltInComSupported && $.$sris.SRIM.ComObject.ComImportInteropEnabled)
                    {
                        this._runtimeCallableWrapper = $.$$.SRI.Marshal.GetObjectForIUnknown($.$$.$interop.$ptr2Addr(thisPointer));
                        $.$$.SD.Debug.Assert$4($.$$.SRI.Marshal.IsComObject(this._runtimeCallableWrapper), "Marshal.IsComObject(_runtimeCallableWrapper)");
                    }
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(47246802951)
            
            $dtor()
            {
                this.CacheStrategy.SRIM$IIUnknownCacheStrategy$Clear(this.IUnknownStrategy);
                this.IUnknownStrategy.SRIM$IIUnknownStrategy$Release(this._instancePointer);
            }
            //--TRIMMABLE-BOUNDARY-START(124556214279)
            /*IIUnknownInterfaceDetailsStrategy*/ InterfaceDetailsStrategy = null;
            //--TRIMMABLE-BOUNDARY-END(124556214279)
            
            //--TRIMMABLE-BOUNDARY-START(128851181575)
            /*IIUnknownStrategy*/ IUnknownStrategy = null;
            //--TRIMMABLE-BOUNDARY-END(128851181575)
            
            //--TRIMMABLE-BOUNDARY-START(55836737543)
            /*IIUnknownCacheStrategy*/ CacheStrategy = null;
            //--TRIMMABLE-BOUNDARY-END(55836737543)
            
            //--TRIMMABLE-BOUNDARY-START(163210919943)
            /*bool*/ UniqueInstance = false;
            //--TRIMMABLE-BOUNDARY-END(163210919943)
            
            //--TRIMMABLE-BOUNDARY-START(68721639431)
            /*void */ FinalRelease()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(68721639431);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (this.UniqueInstance && !$.$$.ST$1.Interlocked.Exchange$14($.$$.S.Boolean, $.$$.SRC.RuntimeHelpers.CreateObjectReferenceT($.$$.S.Boolean, () => this._released, ($v) => this._released = $v, null, true), true))
                {
                    $.$$.S.GC.SuppressFinalize(this);
                    this.CacheStrategy.SRIM$IIUnknownCacheStrategy$Clear(this.IUnknownStrategy);
                    this.IUnknownStrategy.SRIM$IIUnknownStrategy$Release(this._instancePointer);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(68721639431)
            
            //--TRIMMABLE-BOUNDARY-START(146031050759)
            /*RuntimeTypeHandle */ SRI$IDynamicInterfaceCastable$GetInterfaceImplementation(/*RuntimeTypeHandle*/ interfaceType)
            {
                /*IIUnknownCacheStrategy.TableInfo*/ let info;
                /*int*/ let qiResult;
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(146031050759);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (!this.LookUpVTableInfo(interfaceType, $.$ref(() => info, ($v) => info = $v, $.$sris.SRIM.IIUnknownCacheStrategy.TableInfo), $.$ref(() => qiResult, ($v) => qiResult = $v, $.$$.S.Int32)))
                {
                    $.$$.SRI.Marshal.ThrowExceptionForHR$2(qiResult);
                }
                return info.ManagedType;
            }
            //--TRIMMABLE-BOUNDARY-END(146031050759)
            
            //--TRIMMABLE-BOUNDARY-START(150326018055)
            /*bool */ SRI$IDynamicInterfaceCastable$IsInterfaceImplemented(/*RuntimeTypeHandle*/ interfaceType, /*bool*/ throwIfNotImplemented)
            {
                /*int*/ let qiResult;
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(150326018055);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (!this.LookUpVTableInfo(interfaceType, $.$discardRef(), $.$ref(() => qiResult, ($v) => qiResult = $v, $.$$.S.Int32)))
                {
                    if (throwIfNotImplemented)
                    {
                        $.$$.SRI.Marshal.ThrowExceptionForHR$2(qiResult);
                    }
                    return false;
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(150326018055)
            
            //--TRIMMABLE-BOUNDARY-START(133146148871)
            /*bool */ LookUpVTableInfo(/*RuntimeTypeHandle*/ handle, /*out IIUnknownCacheStrategy.TableInfo*/ result, /*out int*/ qiHResult)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(133146148871);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.S.ObjectDisposedException.ThrowIf(this._released, this);
                qiHResult.$v = 0;
                if (!this.CacheStrategy.SRIM$IIUnknownCacheStrategy$TryGetTableInfo(handle, result))
                {
                    /*void**/ let ppv;
                    /*IIUnknownDerivedDetails?*/ let details = this.InterfaceDetailsStrategy.SRIM$IIUnknownInterfaceDetailsStrategy$GetIUnknownDerivedDetails(handle);
                    if (details === null)
                    {
                        return false;
                    }
                    /*int*/ let hr = this.IUnknownStrategy.SRIM$IIUnknownStrategy$QueryInterface(this._instancePointer, $.$ref(() => details.SRIM$IIUnknownDerivedDetails$Iid, ), $.$ref(() => ppv, ($v) => ppv = $v, $.$typePointer($.$$.S.Void)));
                    if (hr < 0)
                    {
                        qiHResult.$v = hr;
                        return false;
                    }
                    result.$v = this.CacheStrategy.SRIM$IIUnknownCacheStrategy$ConstructTableInfo(handle, details, ppv);
                    if (!this.CacheStrategy.SRIM$IIUnknownCacheStrategy$TrySetTableInfo(handle, result.$v))
                    {
                        /*bool*/ let found = this.CacheStrategy.SRIM$IIUnknownCacheStrategy$TryGetTableInfo(handle, result);
                        $.$$.SD.Debug.Assert$4(found, "found");
                        _ = this.IUnknownStrategy.SRIM$IIUnknownStrategy$Release(ppv);
                    }
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(133146148871)
            
            //--TRIMMABLE-BOUNDARY-START(158915952647)
            /*VirtualMethodTableInfo */ SRIM$IUnmanagedVirtualMethodTableProvider$GetVirtualMethodTableInfoForKey(/*Type*/ type)
            {
                /*IIUnknownCacheStrategy.TableInfo*/ let result;
                /*int*/ let qiHResult;
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(158915952647);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (!this.LookUpVTableInfo(type.TypeHandle, $.$ref(() => result, ($v) => result = $v, $.$sris.SRIM.IIUnknownCacheStrategy.TableInfo), $.$ref(() => qiHResult, ($v) => qiHResult = $v, $.$$.S.Int32)))
                {
                    $.$$.SRI.Marshal.ThrowExceptionForHR$2(qiHResult);
                }
                return new $.$sris.SRIM.VirtualMethodTableInfo().$ctor$3(result.ThisPtr, result.Table);
            }
            //--TRIMMABLE-BOUNDARY-END(158915952647)
            
            //--TRIMMABLE-BOUNDARY-START(154620985351)
            /*object */ SRIM$ComImportInteropInterfaceDetailsStrategy$IComImportAdapter$GetRuntimeCallableWrapper()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(154620985351);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.SD.Debug.Assert$4(this._runtimeCallableWrapper !== null, "_runtimeCallableWrapper != null");
                return this._runtimeCallableWrapper;
            }
            //--TRIMMABLE-BOUNDARY-END(154620985351)
            
            //default member initializer
            constructor()
            {
                super();
                //--TRIMMABLE-BOUNDARY-START(4297129991)
                this._instancePointer = $.$default($.$typePointer($.$$.S.Void));
                //--TRIMMABLE-BOUNDARY-END(4297129991)
                
                $.$finalizer(this);
            }
            //--TRIMMABLE-BOUNDARY-START(42951835655)
            //Static Initializer
            static $sinit()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(42951835655);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                {
                    /*bool*/ let supported;
                    //--TRIMMABLE-BOUNDARY-START(51541770247)
                    this.BuiltInComSupported = $.$$.S.AppContext.TryGetSwitch("System.Runtime.InteropServices.BuiltInComInterop.IsSupported", $.$ref(() => supported, ($v) => supported = $v, $.$$.S.Boolean)) ? supported : true;
                    //--TRIMMABLE-BOUNDARY-END(51541770247)
                    
                }
                {
                    /*bool*/ let enabled;
                    //--TRIMMABLE-BOUNDARY-START(60131704839)
                    this.ComImportInteropEnabled = $.$$.S.AppContext.TryGetSwitch("System.Runtime.InteropServices.Marshalling.EnableGeneratedComInterfaceComImportInterop", $.$ref(() => enabled, ($v) => enabled = $v, $.$$.S.Boolean)) ? enabled : false;
                    //--TRIMMABLE-BOUNDARY-END(60131704839)
                    
                }
            }
            //--TRIMMABLE-BOUNDARY-END(42951835655)
            
            static $h = 2162695;
            static $f = 0b10010001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(51541770247),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 77311574023,
        "f": 50331688
      },
      "n": "BuiltInComSupported",
      "d": 2162695,
      "h": 51541770247,
      "f": 2097192
    },
//--TRIMMABLE-BOUNDARY-END(51541770247),
//--TRIMMABLE-BOUNDARY-START(60131704839),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 94491443207,
        "f": 50331688
      },
      "n": "ComImportInteropEnabled",
      "d": 2162695,
      "h": 60131704839,
      "f": 2097192
    },
//--TRIMMABLE-BOUNDARY-END(60131704839),
//--TRIMMABLE-BOUNDARY-START(124556214279),
    {
      "p": 3276807,
      "g": {
        "r": 0,
        "d": 0,
        "h": 103081377799,
        "f": 50331650
      },
      "n": "InterfaceDetailsStrategy",
      "d": 2162695,
      "h": 124556214279,
      "f": 2097154
    },
//--TRIMMABLE-BOUNDARY-END(124556214279),
//--TRIMMABLE-BOUNDARY-START(128851181575),
    {
      "p": 3407879,
      "g": {
        "r": 0,
        "d": 0,
        "h": 111671312391,
        "f": 50331650
      },
      "n": "IUnknownStrategy",
      "d": 2162695,
      "h": 128851181575,
      "f": 2097154
    },
//--TRIMMABLE-BOUNDARY-END(128851181575),
//--TRIMMABLE-BOUNDARY-START(55836737543),
    {
      "p": 3080199,
      "g": {
        "r": 0,
        "d": 0,
        "h": 85901508615,
        "f": 50331650
      },
      "n": "CacheStrategy",
      "d": 2162695,
      "h": 55836737543,
      "f": 2097154
    },
//--TRIMMABLE-BOUNDARY-END(55836737543),
//--TRIMMABLE-BOUNDARY-START(163210919943),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 120261246983,
        "f": 50331656
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 141736083463,
        "f": 83886088
      },
      "n": "UniqueInstance",
      "d": 2162695,
      "h": 163210919943,
      "f": 2097160
    },
//--TRIMMABLE-BOUNDARY-END(163210919943)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(68721639431),
    {
      "r": 65537,
      "n": "FinalRelease",
      "d": 2162695,
      "h": 68721639431,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(68721639431),
//--TRIMMABLE-BOUNDARY-START(133146148871),
    {
      "r": 262145,
      "p": [
        {
          "n": "handle",
          "p": 160956417
        },
        {
          "n": "result",
          "p": 3145735,
          "f": 2
        },
        {
          "n": "qiHResult",
          "p": 655361,
          "f": 2
        }
      ],
      "n": "LookUpVTableInfo",
      "d": 2162695,
      "h": 133146148871,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(133146148871)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(4297129991),
    {
      "t": $.$typePointer($.$$.S.Void).$h,
      "n": "_instancePointer",
      "d": 2162695,
      "h": 4297129991,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(4297129991),
//--TRIMMABLE-BOUNDARY-START(12887064583),
    {
      "t": 131073,
      "n": "_runtimeCallableWrapper",
      "d": 2162695,
      "h": 12887064583,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(12887064583),
//--TRIMMABLE-BOUNDARY-START(8592097287),
    {
      "t": 262145,
      "n": "_released",
      "d": 2162695,
      "h": 8592097287,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(8592097287)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(47246802951),
    {
      "p": [
        {
          "n": "interfaceDetailsStrategy",
          "p": 3276807
        },
        {
          "n": "iunknownStrategy",
          "p": 3407879
        },
        {
          "n": "cacheStrategy",
          "p": 3080199
        },
        {
          "n": "thisPointer",
          "p": $.$typePointer($.$$.S.Void).$h
        }
      ],
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 2162695,
      "h": 47246802951,
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(47246802951)
  ],
  "h": 2162695
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.SRI.IDynamicInterfaceCastable, $.$sris.SRIM.IUnmanagedVirtualMethodTableProvider, $.$sris.SRIM.ComImportInteropInterfaceDetailsStrategy.IComImportAdapter ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `System.Runtime.InteropServices.Marshalling.ComObject`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `System${separator}Runtime${separator}InteropServices${separator}Marshalling${separator}ComObject`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2162695)
	});
})(window, window.NetJs.$boot(), ...await window.NetJs.$require("NetJs.System.Private.CoreLib", "NetJs.System.Collections", "NetJs.System.Diagnostics.Tracing", "NetJs.System.Threading", "NetJs.System.Collections.Concurrent"));
})();
//--TRIMMABLE-BOUNDARY-END(7)
