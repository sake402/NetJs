
(function ($global, $, $spc, $sc, $sdt, $st, $scc) {
    "use strict";
    let _;
    
    
    
	$.$asm(
    "NetJs.System.Runtime.InteropServices", 
    {"h":35715,"f":"System.Runtime.InteropServices","v":"1.0.35.0","a":[{"t":115146753,"c":13000048641,"a":[{"v":".NETCoreApp,Version=v10.0","t":1310721}],"n":[{"n":"FrameworkDisplayName","v":".NET 10.0","t":1310721}]},{"t":73596929,"c":4368564225,"a":[{"v":"SIT","t":1310721}]},{"t":73662465,"c":4368629761,"a":[{"v":"Debug","t":1310721}]},{"t":74121217,"c":4369088513,"a":[{"v":"1.0.35.0","t":1310721}]},{"t":74252289,"c":4369219585,"a":[{"v":"1.0.35\u002B760b8187d87d291733fdcda9f4d484d24d61a938","t":1310721}]},{"t":75104257,"c":4370071553,"a":[{"v":"NetJs.System.Runtime.InteropServices","t":1310721}]},{"t":75235329,"c":4370202625,"a":[{"v":"NetJs.System.Runtime.InteropServices","t":1310721}]},{"t":75366401,"c":4370333697,"a":[{"v":"1.0.35.0","t":1310721}]},{"t":115212289,"c":4410179585,"a":[{"v":"browser1.0","t":1310721}]},{"t":114950145,"c":4409917441,"a":[{"v":"browser1.0","t":1310721}]}],"m":[]},
    function($asm)
	{
        
        
        $asm.$cls("$sris.System.Runtime.InteropServices.ComTypes.IEnumSTATDATA", ($self) => class IEnumSTATDATA
        {
            static $h = 1215363;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {"m":[{"r":655361,"p":[{"n":"celt","p":655361},{"n":"rgelt","p":0,"a":[{"t":108789761,"c":4403757057},{"t":105709569,"c":8695644161,"a":[{"v":42,"t":110886913}],"n":[{"n":"SizeParamIndex","v":0,"t":524289}]}]},{"n":"pceltFetched","p":0,"a":[{"t":108789761,"c":4403757057},{"t":105709569,"c":8695644161,"a":[{"v":42,"t":110886913}],"n":[{"n":"SizeConst","v":1,"t":655361}]}]}],"n":"Next","o":"System$Runtime$InteropServices$ComTypes$IEnumSTATDATA$Next","d":1215363,"h":4296182659,"f":257,"a":[{"t":109182977,"c":4404150273}]},{"r":655361,"p":[{"n":"celt","p":655361}],"n":"Skip","o":"System$Runtime$InteropServices$ComTypes$IEnumSTATDATA$Skip","d":1215363,"h":8591149955,"f":257,"a":[{"t":109182977,"c":4404150273}]},{"r":655361,"n":"Reset","o":"System$Runtime$InteropServices$ComTypes$IEnumSTATDATA$Reset","d":1215363,"h":12886117251,"f":257,"a":[{"t":109182977,"c":4404150273}]},{"r":65537,"p":[{"n":"newEnum","p":1215363,"f":2}],"n":"Clone","o":"System$Runtime$InteropServices$ComTypes$IEnumSTATDATA$Clone","d":1215363,"h":17181084547,"f":257}],"h":1215363,"a":[{"t":99155969,"c":4394123265},{"t":104398849,"c":4399366145,"a":[{"v":"00000105-0000-0000-C000-000000000046","t":1310721}]},{"t":104923137,"c":4399890433,"a":[{"v":1,"t":99221505}]}]}; }
            static get $fullName() { return `System.Runtime.InteropServices.ComTypes.IEnumSTATDATA`; }
        });
        
        $asm.$cls("$sris.System.Runtime.InteropServices.ComTypes.IAdviseSink", ($self) => class IAdviseSink
        {
            static $h = 1018755;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {"m":[{"r":65537,"p":[{"n":"format","p":953219,"f":4,"a":[{"t":104857601,"c":4399824897}]},{"n":"stgmedium","p":1346435,"f":4,"a":[{"t":104857601,"c":4399824897}]}],"n":"OnDataChange","o":"System$Runtime$InteropServices$ComTypes$IAdviseSink$OnDataChange","d":1018755,"h":4295986051,"f":257,"a":[{"t":109182977,"c":4404150273}]},{"r":65537,"p":[{"n":"aspect","p":655361},{"n":"index","p":655361}],"n":"OnViewChange","o":"System$Runtime$InteropServices$ComTypes$IAdviseSink$OnViewChange","d":1018755,"h":8590953347,"f":257,"a":[{"t":109182977,"c":4404150273}]},{"r":65537,"p":[{"n":"moniker","p":100925441}],"n":"OnRename","o":"System$Runtime$InteropServices$ComTypes$IAdviseSink$OnRename","d":1018755,"h":12885920643,"f":257,"a":[{"t":109182977,"c":4404150273}]},{"r":65537,"n":"OnSave","o":"System$Runtime$InteropServices$ComTypes$IAdviseSink$OnSave","d":1018755,"h":17180887939,"f":257,"a":[{"t":109182977,"c":4404150273}]},{"r":65537,"n":"OnClose","o":"System$Runtime$InteropServices$ComTypes$IAdviseSink$OnClose","d":1018755,"h":21475855235,"f":257,"a":[{"t":109182977,"c":4404150273}]}],"h":1018755,"a":[{"t":99155969,"c":4394123265},{"t":104398849,"c":4399366145,"a":[{"v":"0000010F-0000-0000-C000-000000000046","t":1310721}]},{"t":33161217,"c":4328128513,"a":[{"v":1,"t":33226753}]},{"t":104923137,"c":4399890433,"a":[{"v":1,"t":99221505}]}]}; }
            static get $fullName() { return `System.Runtime.InteropServices.ComTypes.IAdviseSink`; }
        });
        
        $asm.$cls("$sris.System.Runtime.InteropServices.ComTypes.IDataObject", ($self) => class IDataObject
        {
            static $h = 1084291;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {"m":[{"r":65537,"p":[{"n":"format","p":953219,"f":4,"a":[{"t":104857601,"c":4399824897}]},{"n":"medium","p":1346435,"f":2}],"n":"GetData","o":"System$Runtime$InteropServices$ComTypes$IDataObject$GetData","d":1084291,"h":4296051587,"f":257},{"r":65537,"p":[{"n":"format","p":953219,"f":4,"a":[{"t":104857601,"c":4399824897}]},{"n":"medium","p":1346435,"f":4}],"n":"GetDataHere","o":"System$Runtime$InteropServices$ComTypes$IDataObject$GetDataHere","d":1084291,"h":8591018883,"f":257},{"r":655361,"p":[{"n":"format","p":953219,"f":4,"a":[{"t":104857601,"c":4399824897}]}],"n":"QueryGetData","o":"System$Runtime$InteropServices$ComTypes$IDataObject$QueryGetData","d":1084291,"h":12885986179,"f":257,"a":[{"t":109182977,"c":4404150273}]},{"r":655361,"p":[{"n":"formatIn","p":953219,"f":4,"a":[{"t":104857601,"c":4399824897}]},{"n":"formatOut","p":953219,"f":2}],"n":"GetCanonicalFormatEtc","o":"System$Runtime$InteropServices$ComTypes$IDataObject$GetCanonicalFormatEtc","d":1084291,"h":17180953475,"f":257,"a":[{"t":109182977,"c":4404150273}]},{"r":65537,"p":[{"n":"formatIn","p":953219,"f":4,"a":[{"t":104857601,"c":4399824897}]},{"n":"medium","p":1346435,"f":4,"a":[{"t":104857601,"c":4399824897}]},{"n":"release","p":262145,"a":[{"t":105709569,"c":8695644161,"a":[{"v":2,"t":110886913}]}]}],"n":"SetData","o":"System$Runtime$InteropServices$ComTypes$IDataObject$SetData","d":1084291,"h":21475920771,"f":257},{"r":1149827,"p":[{"n":"direction","p":822147}],"n":"EnumFormatEtc","o":"System$Runtime$InteropServices$ComTypes$IDataObject$EnumFormatEtc","d":1084291,"h":25770888067,"f":257},{"r":655361,"p":[{"n":"pFormatetc","p":953219,"f":4,"a":[{"t":104857601,"c":4399824897}]},{"n":"advf","p":756611},{"n":"adviseSink","p":1018755},{"n":"connection","p":655361,"f":2}],"n":"DAdvise","o":"System$Runtime$InteropServices$ComTypes$IDataObject$DAdvise","d":1084291,"h":30065855363,"f":257,"a":[{"t":109182977,"c":4404150273}]},{"r":65537,"p":[{"n":"connection","p":655361}],"n":"DUnadvise","o":"System$Runtime$InteropServices$ComTypes$IDataObject$DUnadvise","d":1084291,"h":34360822659,"f":257},{"r":655361,"p":[{"n":"enumAdvise","p":1215363,"f":2}],"n":"EnumDAdvise","o":"System$Runtime$InteropServices$ComTypes$IDataObject$EnumDAdvise","d":1084291,"h":38655789955,"f":257,"a":[{"t":109182977,"c":4404150273}]}],"h":1084291,"a":[{"t":23396353,"c":8613330945,"a":[{"v":false,"t":262145}]},{"t":99155969,"c":4394123265},{"t":104398849,"c":4399366145,"a":[{"v":"0000010E-0000-0000-C000-000000000046","t":1310721}]},{"t":104923137,"c":4399890433,"a":[{"v":1,"t":99221505}]}]}; }
            static get $fullName() { return `System.Runtime.InteropServices.ComTypes.IDataObject`; }
        });
        
        $asm.$cls("$sris.System.Runtime.InteropServices.ComTypes.IEnumFORMATETC", ($self) => class IEnumFORMATETC
        {
            static $h = 1149827;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {"m":[{"r":655361,"p":[{"n":"celt","p":655361},{"n":"rgelt","p":0,"a":[{"t":108789761,"c":4403757057},{"t":105709569,"c":8695644161,"a":[{"v":42,"t":110886913}],"n":[{"n":"SizeParamIndex","v":0,"t":524289}]}]},{"n":"pceltFetched","p":0,"a":[{"t":108789761,"c":4403757057},{"t":105709569,"c":8695644161,"a":[{"v":42,"t":110886913}]}]}],"n":"Next","o":"System$Runtime$InteropServices$ComTypes$IEnumFORMATETC$Next","d":1149827,"h":4296117123,"f":257,"a":[{"t":109182977,"c":4404150273}]},{"r":655361,"p":[{"n":"celt","p":655361}],"n":"Skip","o":"System$Runtime$InteropServices$ComTypes$IEnumFORMATETC$Skip","d":1149827,"h":8591084419,"f":257,"a":[{"t":109182977,"c":4404150273}]},{"r":655361,"n":"Reset","o":"System$Runtime$InteropServices$ComTypes$IEnumFORMATETC$Reset","d":1149827,"h":12886051715,"f":257,"a":[{"t":109182977,"c":4404150273}]},{"r":65537,"p":[{"n":"newEnum","p":1149827,"f":2}],"n":"Clone","o":"System$Runtime$InteropServices$ComTypes$IEnumFORMATETC$Clone","d":1149827,"h":17181019011,"f":257}],"h":1149827,"a":[{"t":99155969,"c":4394123265},{"t":104398849,"c":4399366145,"a":[{"v":"00000103-0000-0000-C000-000000000046","t":1310721}]},{"t":33161217,"c":4328128513,"a":[{"v":1,"t":33226753}]},{"t":104923137,"c":4399890433,"a":[{"v":1,"t":99221505}]}]}; }
            static get $fullName() { return `System.Runtime.InteropServices.ComTypes.IEnumFORMATETC`; }
        });
        
        $asm.$cls("$sris.System.Runtime.InteropServices.Marshalling.IComExposedClass", ($self) => class IComExposedClass
        {
            static $h = 2984835;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {"m":[{"r":0,"p":[{"n":"count","p":655361,"f":2}],"n":"GetComInterfaceEntries","o":"System$Runtime$InteropServices$Marshalling$IComExposedClass$GetComInterfaceEntries","d":2984835,"h":4297952131,"f":289}],"h":2984835,"a":[{"t":23396353,"c":8613330945,"a":[{"v":false,"t":262145}]}]}; }
            static get $fullName() { return `System.Runtime.InteropServices.Marshalling.IComExposedClass`; }
        });
        
        $asm.$cls("$sris.System.Runtime.InteropServices.Marshalling.IComExposedDetails", ($self) => class IComExposedDetails
        {
            static /*IComExposedDetails? */ System$Runtime$InteropServices$Marshalling$IComExposedDetails$GetFromAttribute(/*RuntimeTypeHandle*/ handle)
            {
                /*var*/ let type = $.$spc.System.Type.GetTypeFromHandle(handle);
                if (type === null)
                {
                    return null;
                }
                return $.$cast($.$spc.System.Reflection.CustomAttributeExtensions.GetCustomAttribute$2(type, $.$sris.System.Runtime.InteropServices.Marshalling.ComExposedClassAttribute$$().$type), $.$sris.System.Runtime.InteropServices.Marshalling.IComExposedDetails);
            }
            static $h = 3050371;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {"m":[{"r":0,"p":[{"n":"count","p":655361,"f":2}],"n":"GetComInterfaceEntries","o":"System$Runtime$InteropServices$Marshalling$IComExposedDetails$GetComInterfaceEntries","d":3050371,"h":4298017667,"f":257},{"r":3050371,"p":[{"n":"handle","p":116064257}],"n":"GetFromAttribute","o":"System$Runtime$InteropServices$Marshalling$IComExposedDetails$GetFromAttribute","d":3050371,"h":8592984963,"f":40}],"h":3050371,"a":[{"t":23396353,"c":8613330945,"a":[{"v":false,"t":262145}]}]}; }
            static get $fullName() { return `System.Runtime.InteropServices.Marshalling.IComExposedDetails`; }
        });
        
        $asm.$cls("$sris.System.Runtime.InteropServices.Marshalling.IIUnknownCacheStrategy", ($self) => class IIUnknownCacheStrategy
        {
            static $_TableInfo;
            static get TableInfo()
            {
                let $cls = $.$sris.System.Runtime.InteropServices.Marshalling.IIUnknownCacheStrategy;
                return $cls.$_TableInfo ??= $asm.$nstr("$sris.System.Runtime.InteropServices.Marshalling.IIUnknownCacheStrategy.TableInfo", ($self) => class TableInfo extends $.$spc.System.ValueType
                {
                    /*void**/ ThisPtr;
                    /*void***/ Table;
                    /*RuntimeTypeHandle*/ ManagedType;
                    //default value type constructor
                    $ctor$2()
                    {
                        return this;
                    }
                    Clone($copy)
                    {
                        let copy = $copy ?? new this.constructor();
                        copy.ThisPtr = this.ThisPtr.Clone();
                        copy.Table = this.Table.Clone();
                        copy.ManagedType = this.ManagedType.Clone();
                        return copy;
                    }
                    //default member initializer
                    constructor()
                    {
                        super();
                        this.ThisPtr = $.$default($.$typePointer($.$spc.System.Void));
                        this.Table = $.$default($.$typePointer($.$typePointer($.$spc.System.Void)));
                        this.ManagedType = $.$default($.$spc.System.RuntimeTypeHandle);
                    }
                    static $h = 3181443;
                    static $z = 9;
                    static $f = 0b10000001010000001;
                    static $k = 2;
                    static $$md;
                    static get $md() { return this.$$md ??= {"b":196609,"p":[{"p":0,"g":{"r":0,"d":0,"h":12888083331,"f":1},"s":{"r":0,"d":0,"h":17183050627,"f":1},"n":"ThisPtr","d":3181443,"h":8593116035,"f":1},{"p":0,"g":{"r":0,"d":0,"h":30067952515,"f":1},"s":{"r":0,"d":0,"h":34362919811,"f":1},"n":"Table","d":3181443,"h":25772985219,"f":1},{"p":116064257,"g":{"r":0,"d":0,"h":47247821699,"f":1},"s":{"r":0,"d":0,"h":51542788995,"f":1},"n":"ManagedType","d":3181443,"h":42952854403,"f":1}],"c":[{"n":".ctor","o":"$ctor$2","d":3181443,"h":55837756291,"f":1}],"d":3115907,"h":3181443}; }
                    static get $b() { return $.$spc.System.ValueType; }
                    static get $fullName() { return `System.Runtime.InteropServices.Marshalling.IIUnknownCacheStrategy.TableInfo`; }
                }, $cls, ($v) => $cls.$_TableInfo = $v);
            }
            static $h = 3115907;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {"m":[{"r":3181443,"p":[{"n":"handle","p":116064257},{"n":"interfaceDetails","p":3246979},{"n":"ptr","p":0}],"n":"ConstructTableInfo","o":"System$Runtime$InteropServices$Marshalling$IIUnknownCacheStrategy$ConstructTableInfo","d":3115907,"h":8593050499,"f":257},{"r":262145,"p":[{"n":"handle","p":116064257},{"n":"info","p":3181443,"f":2}],"n":"TryGetTableInfo","o":"System$Runtime$InteropServices$Marshalling$IIUnknownCacheStrategy$TryGetTableInfo","d":3115907,"h":12888017795,"f":257},{"r":262145,"p":[{"n":"handle","p":116064257},{"n":"info","p":3181443}],"n":"TrySetTableInfo","o":"System$Runtime$InteropServices$Marshalling$IIUnknownCacheStrategy$TrySetTableInfo","d":3115907,"h":17182985091,"f":257},{"r":65537,"p":[{"n":"unknownStrategy","p":3443587}],"n":"Clear","o":"System$Runtime$InteropServices$Marshalling$IIUnknownCacheStrategy$Clear","d":3115907,"h":21477952387,"f":257}],"j":[3181443],"h":3115907,"a":[{"t":23396353,"c":8613330945,"a":[{"v":false,"t":262145}]}]}; }
            static get $fullName() { return `System.Runtime.InteropServices.Marshalling.IIUnknownCacheStrategy`; }
        });
        
        $asm.$cls("$sris.System.Runtime.InteropServices.Marshalling.IIUnknownDerivedDetails", ($self) => class IIUnknownDerivedDetails
        {
            static /*IIUnknownDerivedDetails? */ System$Runtime$InteropServices$Marshalling$IIUnknownDerivedDetails$GetFromAttribute(/*RuntimeTypeHandle*/ handle)
            {
                /*var*/ let type = $.$spc.System.Type.GetTypeFromHandle(handle);
                if (type === null)
                {
                    return null;
                }
                return $.$cast($.$spc.System.Reflection.CustomAttributeExtensions.GetCustomAttribute$2(type, $.$sris.System.Runtime.InteropServices.Marshalling.IUnknownDerivedAttribute$$$().$type), $.$sris.System.Runtime.InteropServices.Marshalling.IIUnknownDerivedDetails);
            }
            static $h = 3246979;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {"p":[{"p":56164353,"g":{"r":0,"d":0,"h":8593181571,"f":257},"n":"Iid","o":"System$Runtime$InteropServices$Marshalling$IIUnknownDerivedDetails$Iid","d":3246979,"h":4298214275,"f":257},{"p":142606337,"g":{"r":0,"d":0,"h":17183116163,"f":257},"n":"Implementation","o":"System$Runtime$InteropServices$Marshalling$IIUnknownDerivedDetails$Implementation","d":3246979,"h":12888148867,"f":257},{"p":0,"g":{"r":0,"d":0,"h":25773050755,"f":257},"n":"ManagedVirtualMethodTable","o":"System$Runtime$InteropServices$Marshalling$IIUnknownDerivedDetails$ManagedVirtualMethodTable","d":3246979,"h":21478083459,"f":257}],"m":[{"r":3246979,"p":[{"n":"handle","p":116064257}],"n":"GetFromAttribute","o":"System$Runtime$InteropServices$Marshalling$IIUnknownDerivedDetails$GetFromAttribute","d":3246979,"h":30068018051,"f":40}],"h":3246979,"a":[{"t":23396353,"c":8613330945,"a":[{"v":false,"t":262145}]}]}; }
            static get $fullName() { return `System.Runtime.InteropServices.Marshalling.IIUnknownDerivedDetails`; }
        });
        
        $asm.$cls("$sris.System.Runtime.InteropServices.Marshalling.IIUnknownInterfaceDetailsStrategy", ($self) => class IIUnknownInterfaceDetailsStrategy
        {
            static $h = 3312515;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {"m":[{"r":3246979,"p":[{"n":"type","p":116064257}],"n":"GetIUnknownDerivedDetails","o":"System$Runtime$InteropServices$Marshalling$IIUnknownInterfaceDetailsStrategy$GetIUnknownDerivedDetails","d":3312515,"h":4298279811,"f":257},{"r":3050371,"p":[{"n":"type","p":116064257}],"n":"GetComExposedTypeDetails","o":"System$Runtime$InteropServices$Marshalling$IIUnknownInterfaceDetailsStrategy$GetComExposedTypeDetails","d":3312515,"h":8593247107,"f":257}],"h":3312515,"a":[{"t":23396353,"c":8613330945,"a":[{"v":false,"t":262145}]}]}; }
            static get $fullName() { return `System.Runtime.InteropServices.Marshalling.IIUnknownInterfaceDetailsStrategy`; }
        });
        
        $asm.$cls("$sris.System.Runtime.InteropServices.Marshalling.IIUnknownInterfaceType", ($self) => class IIUnknownInterfaceType
        {
            static $h = 3378051;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {"p":[{"p":56164353,"g":{"r":0,"d":0,"h":8593312643,"f":289},"n":"Iid","o":"System$Runtime$InteropServices$Marshalling$IIUnknownInterfaceType$Iid","d":3378051,"h":4298345347,"f":289},{"p":0,"g":{"r":0,"d":0,"h":17183247235,"f":289},"n":"ManagedVirtualMethodTable","o":"System$Runtime$InteropServices$Marshalling$IIUnknownInterfaceType$ManagedVirtualMethodTable","d":3378051,"h":12888279939,"f":289}],"h":3378051,"a":[{"t":23396353,"c":8613330945,"a":[{"v":false,"t":262145}]}]}; }
            static get $fullName() { return `System.Runtime.InteropServices.Marshalling.IIUnknownInterfaceType`; }
        });
        
        $asm.$cls("$sris.System.Runtime.InteropServices.Marshalling.IIUnknownStrategy", ($self) => class IIUnknownStrategy
        {
            static $h = 3443587;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {"m":[{"r":0,"p":[{"n":"unknown","p":0}],"n":"CreateInstancePointer","o":"System$Runtime$InteropServices$Marshalling$IIUnknownStrategy$CreateInstancePointer","d":3443587,"h":4298410883,"f":257},{"r":655361,"p":[{"n":"instancePtr","p":0},{"n":"iid","p":56164353,"f":8},{"n":"ppObj","p":0,"f":2}],"n":"QueryInterface","o":"System$Runtime$InteropServices$Marshalling$IIUnknownStrategy$QueryInterface","d":3443587,"h":8593378179,"f":257},{"r":655361,"p":[{"n":"instancePtr","p":0}],"n":"Release","o":"System$Runtime$InteropServices$Marshalling$IIUnknownStrategy$Release","d":3443587,"h":12888345475,"f":257}],"h":3443587,"a":[{"t":23396353,"c":8613330945,"a":[{"v":false,"t":262145}]}]}; }
            static get $fullName() { return `System.Runtime.InteropServices.Marshalling.IIUnknownStrategy`; }
        });
        
        $asm.$cls("$sris.System.Runtime.InteropServices.Marshalling.IUnmanagedVirtualMethodTableProvider", ($self) => class IUnmanagedVirtualMethodTableProvider
        {
            static $h = 3574659;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {"m":[{"r":3771267,"p":[{"n":"type","p":142606337}],"n":"GetVirtualMethodTableInfoForKey","o":"System$Runtime$InteropServices$Marshalling$IUnmanagedVirtualMethodTableProvider$GetVirtualMethodTableInfoForKey","d":3574659,"h":4298541955,"f":257}],"h":3574659,"a":[{"t":23396353,"c":8613330945,"a":[{"v":false,"t":262145}]}]}; }
            static get $fullName() { return `System.Runtime.InteropServices.Marshalling.IUnmanagedVirtualMethodTableProvider`; }
        });
        
        $asm.$cls("$sris.System.SR", ($self) => class SR
        {
            /*global::System.Resources.ResourceManager*/ static s_resourceManager = null;
            /*global::System.Globalization.CultureInfo*/ static resourceCulture = null;
            static /*global::System.Resources.ResourceManager */ get ResourceManager()
            {
                if ($.$spc.System.Object.ReferenceEquals($.$sris.System.SR.s_resourceManager, null))
                {
                    /*global::System.Resources.ResourceManager*/ let temp = new $.$spc.System.Resources.ResourceManager().$ctor$3("System.Runtime.InteropServices", $.$sris.System.SR.$type.Assembly);
                    $.$sris.System.SR.s_resourceManager = temp;
                }
                return $.$sris.System.SR.s_resourceManager;
            }
            static /*global::System.Globalization.CultureInfo */ get Culture()
            {
                return $.$sris.System.SR.resourceCulture;
            }
            static /*global::System.Globalization.CultureInfo */ set Culture(value)
            {
                $.$sris.System.SR.resourceCulture = value;
            }
            static /*string */ get InvalidOperation_HCCountOverflow()
            {
                return "Handle collector count overflows or underflows.";
            }
            static /*string */ get Arg_NeedNonNegNumRequired()
            {
                return "Non-negative number required.";
            }
            static /*string */ get Arg_InvalidThreshold()
            {
                return "maximumThreshold cannot be less than initialThreshold.";
            }
            static /*string */ get InvalidOperation_NoComEventInterfaceAttribute()
            {
                return "Event invocation for COM objects requires the declaring interface of the event to be attributed with ComEventInterfaceAttribute.";
            }
            static /*string */ get AmbiguousMatch_MultipleEventInterfaceAttributes()
            {
                return "More than one ComEventInterfaceAttribute found for '{0}' on the declaring interface of the event.";
            }
            static /*string */ FormatAmbiguousMatch_MultipleEventInterfaceAttributes(/*object*/ arg1)
            {
                return $.$spc.System.String.Format("More than one ComEventInterfaceAttribute found for '{0}' on the declaring interface of the event.", arg1);
            }
            static /*string */ get InvalidOperation_NoDispIdAttribute()
            {
                return "Event invocation for COM objects requires event to be attributed with DispIdAttribute.";
            }
            static /*string */ get IO_FileExists_Name()
            {
                return "The file '{0}' already exists.";
            }
            static /*string */ FormatIO_FileExists_Name(/*object*/ arg1)
            {
                return $.$spc.System.String.Format("The file '{0}' already exists.", arg1);
            }
            static /*string */ get IO_FileNotFound()
            {
                return "Unable to find the specified file.";
            }
            static /*string */ get IO_FileNotFound_FileName()
            {
                return "Could not find file '{0}'.";
            }
            static /*string */ FormatIO_FileNotFound_FileName(/*object*/ arg1)
            {
                return $.$spc.System.String.Format("Could not find file '{0}'.", arg1);
            }
            static /*string */ get IO_PathNotFound_NoPathName()
            {
                return "Could not find a part of the path.";
            }
            static /*string */ get IO_PathNotFound_Path()
            {
                return "Could not find a part of the path '{0}'.";
            }
            static /*string */ FormatIO_PathNotFound_Path(/*object*/ arg1)
            {
                return $.$spc.System.String.Format("Could not find a part of the path '{0}'.", arg1);
            }
            static /*string */ get IO_PathTooLong()
            {
                return "The specified file name or path is too long, or a component of the specified path is too long.";
            }
            static /*string */ get IO_SharingViolation_File()
            {
                return "The process cannot access the file '{0}' because it is being used by another process.";
            }
            static /*string */ FormatIO_SharingViolation_File(/*object*/ arg1)
            {
                return $.$spc.System.String.Format("The process cannot access the file '{0}' because it is being used by another process.", arg1);
            }
            static /*string */ get IO_SharingViolation_NoFileName()
            {
                return "The process cannot access the file because it is being used by another process.";
            }
            static /*string */ get IO_PathTooLong_Path()
            {
                return "The path '{0}' is too long, or a component of the specified path is too long.";
            }
            static /*string */ FormatIO_PathTooLong_Path(/*object*/ arg1)
            {
                return $.$spc.System.String.Format("The path '{0}' is too long, or a component of the specified path is too long.", arg1);
            }
            static /*string */ get UnauthorizedAccess_IODenied_Path()
            {
                return "Access to the path '{0}' is denied.";
            }
            static /*string */ FormatUnauthorizedAccess_IODenied_Path(/*object*/ arg1)
            {
                return $.$spc.System.String.Format("Access to the path '{0}' is denied.", arg1);
            }
            static /*string */ get UnauthorizedAccess_IODenied_NoPathName()
            {
                return "Access to the path is denied.";
            }
            static /*string */ get ArgumentOutOfRange_FileLengthTooBig()
            {
                return "Specified file length was too large for the file system.";
            }
            static /*string */ get ComVariantMarshaller_ManagedTypeNotSupported()
            {
                return "Type of managed object is not supported for marshalling as ComVariant.";
            }
            static /*string */ get ComVariantMarshaller_UnmanagedTypeNotSupported()
            {
                return "Type of unmanaged variant is not supported for marshalling to a managed object.";
            }
            /*bool*/ static s_usingResourceKeys = false;
            static /*bool */ GetUsingResourceKeysSwitchValue()
            {
                /*bool*/ let usingResourceKeys;
                return $.$spc.System.AppContext.TryGetSwitch("System.Resources.UseSystemResourceKeys", $.$ref(() => usingResourceKeys, ($v) => usingResourceKeys = $v, $.$spc.System.Boolean)) ? usingResourceKeys : false;
            }
            static /*bool */ UsingResourceKeys()
            {
                return $.$sris.System.SR.s_usingResourceKeys;
            }
            static /*string */ GetResourceString(/*string*/ resourceKey)
            {
                if ($.$sris.System.SR.UsingResourceKeys())
                {
                    return resourceKey;
                }
                /*string?*/ let resourceString = null;
                try
                {
                    resourceString = $.$sris.System.SR.ResourceManager.GetString(resourceKey);
                }
                catch($e)
                {
                }
                return resourceString;
            }
            static /*string */ GetResourceString$1(/*string*/ resourceKey, /*string*/ defaultString)
            {
                /*string*/ let resourceString = $.$sris.System.SR.GetResourceString(resourceKey);
                return $.$spc.System.String.op_Equality(resourceKey, resourceString) || $.$spc.System.String.op_Equality(resourceString, null) ? defaultString : resourceString;
            }
            static /*string */ Format(/*string*/ resourceFormat, /*object?*/ p1)
            {
                if ($.$sris.System.SR.UsingResourceKeys())
                {
                    return $.$spc.System.String.Join$10(", ", $.$spc.System.ReadOnlySpan$$($.$spc.System.Object).op_Implicit([ resourceFormat, p1 ]));
                }
                return $.$spc.System.String.Format(resourceFormat, p1);
            }
            static /*string */ Format$1(/*string*/ resourceFormat, /*object?*/ p1, /*object?*/ p2)
            {
                if ($.$sris.System.SR.UsingResourceKeys())
                {
                    return $.$spc.System.String.Join$10(", ", $.$spc.System.ReadOnlySpan$$($.$spc.System.Object).op_Implicit([ resourceFormat, p1, p2 ]));
                }
                return $.$spc.System.String.Format$1(resourceFormat, p1, p2);
            }
            static /*string */ Format$2(/*string*/ resourceFormat, /*object?*/ p1, /*object?*/ p2, /*object?*/ p3)
            {
                if ($.$sris.System.SR.UsingResourceKeys())
                {
                    return $.$spc.System.String.Join$10(", ", $.$spc.System.ReadOnlySpan$$($.$spc.System.Object).op_Implicit([ resourceFormat, p1, p2, p3 ]));
                }
                return $.$spc.System.String.Format$2(resourceFormat, p1, p2, p3);
            }
            static /*string */ Format$3(/*string*/ resourceFormat, /*params object?[]?*/ args)
            {
                if (args !== null)
                {
                    if ($.$sris.System.SR.UsingResourceKeys())
                    {
                        return resourceFormat + ", " + $.$spc.System.String.Join$9(", ", args);
                    }
                    return $.$spc.System.String.Format$3(resourceFormat, args);
                }
                return resourceFormat;
            }
            static /*string */ Format$4(/*IFormatProvider?*/ provider, /*string*/ resourceFormat, /*object?*/ p1)
            {
                if ($.$sris.System.SR.UsingResourceKeys())
                {
                    return $.$spc.System.String.Join$10(", ", $.$spc.System.ReadOnlySpan$$($.$spc.System.Object).op_Implicit([ resourceFormat, p1 ]));
                }
                return $.$spc.System.String.Format$5(provider, resourceFormat, p1);
            }
            static /*string */ Format$5(/*IFormatProvider?*/ provider, /*string*/ resourceFormat, /*object?*/ p1, /*object?*/ p2)
            {
                if ($.$sris.System.SR.UsingResourceKeys())
                {
                    return $.$spc.System.String.Join$10(", ", $.$spc.System.ReadOnlySpan$$($.$spc.System.Object).op_Implicit([ resourceFormat, p1, p2 ]));
                }
                return $.$spc.System.String.Format$6(provider, resourceFormat, p1, p2);
            }
            static /*string */ Format$6(/*IFormatProvider?*/ provider, /*string*/ resourceFormat, /*object?*/ p1, /*object?*/ p2, /*object?*/ p3)
            {
                if ($.$sris.System.SR.UsingResourceKeys())
                {
                    return $.$spc.System.String.Join$10(", ", $.$spc.System.ReadOnlySpan$$($.$spc.System.Object).op_Implicit([ resourceFormat, p1, p2, p3 ]));
                }
                return $.$spc.System.String.Format$7(provider, resourceFormat, p1, p2, p3);
            }
            static /*string */ Format$7(/*IFormatProvider?*/ provider, /*string*/ resourceFormat, /*params object?[]?*/ args)
            {
                if (args !== null)
                {
                    if ($.$sris.System.SR.UsingResourceKeys())
                    {
                        return resourceFormat + ", " + $.$spc.System.String.Join$9(", ", args);
                    }
                    return $.$spc.System.String.Format$8(provider, resourceFormat, args);
                }
                return resourceFormat;
            }
            //Static Initializer
            static $sinit()
            {
                {
                    this.s_usingResourceKeys = $.$sris.System.SR.GetUsingResourceKeysSwitchValue();
                }
            }
            static $h = 4688771;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"h":4688771}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.SR`; }
        });
        
        $asm.$cls("$sris.System.Runtime.InteropServices.HandleCollector", ($self) => class HandleCollector extends $.$spc.System.Object
        {
            /*int*/ static DeltaPercent = 10;
            /*int*/ _threshold = 0;
            /*int*/ _handleCount = 0;
            /*int[]*/ _gcCounts = null;
            /*int*/ _gcGeneration = 0;
            $ctor$1(/*string?*/ name, /*int*/ initialThreshold)
            {
                this.$ctor$2(name, initialThreshold, 2147483647/*int.MaxValue*/);
                {
                }
                return this;
            }
            $ctor$2(/*string?*/ name, /*int*/ initialThreshold, /*int*/ maximumThreshold)
            {
                super.$ctor();
                {
                    if (initialThreshold < 0)
                    {
                        throw new $.$spc.System.ArgumentOutOfRangeException().$ctor$19("initialThreshold", $.$box(initialThreshold, $.$spc.System.Int32), $.$sris.System.SR.Arg_NeedNonNegNumRequired);
                    }
                    if (maximumThreshold < 0)
                    {
                        throw new $.$spc.System.ArgumentOutOfRangeException().$ctor$19("maximumThreshold", $.$box(maximumThreshold, $.$spc.System.Int32), $.$sris.System.SR.Arg_NeedNonNegNumRequired);
                    }
                    if (initialThreshold > maximumThreshold)
                    {
                        throw new $.$spc.System.ArgumentException().$ctor$13($.$sris.System.SR.Arg_InvalidThreshold, "initialThreshold");
                    }
                    this.Name = name ?? $.$spc.System.String.Empty;
                    this.InitialThreshold = initialThreshold;
                    this.MaximumThreshold = maximumThreshold;
                    this._threshold = initialThreshold;
                    this._handleCount = 0;
                    this._gcGeneration = 0;
                }
                return this;
            }
            /*int */ get Count()
            {
                return this._handleCount;
            }
            /*int*/ InitialThreshold = 0;
            /*int*/ MaximumThreshold = 0;
            /*string*/ Name = null;
            /*void */ Add()
            {
                /*int*/ let collectionGeneration = -1;
                $.$spc.System.Threading.Interlocked.Increment($.$ref(() => this._handleCount, ($v) => this._handleCount = $v, $.$spc.System.Int32));
                if (this._handleCount < 0)
                {
                    throw new $.$spc.System.InvalidOperationException().$ctor$10($.$sris.System.SR.InvalidOperation_HCCountOverflow);
                }
                if (this._handleCount > this._threshold)
                {
                    //lock
                    try
                    {
                        $.$spc.System.Threading.Monitor.Enter(this)
                        {
                            this._threshold = ((this._handleCount + ($.trunc(this._handleCount / 10/*DeltaPercent*/))) | 0);
                            collectionGeneration = this._gcGeneration;
                            if (this._gcGeneration < 2)
                            {
                                this._gcGeneration++;
                            }
                        }
                    }
                    finally
                    {
                        $.$spc.System.Threading.Monitor.Exit(this)
                    }
                }
                if ((collectionGeneration >= 0) && ((collectionGeneration === 0) || ($.$spc.System.Array.$ReadT1.call(this._gcCounts, collectionGeneration) === $.$spc.System.GC.CollectionCount(collectionGeneration))))
                {
                    $.$spc.System.GC.Collect(collectionGeneration);
                    $.$spc.System.Threading.Thread.Sleep(((10 * collectionGeneration) | 0));
                }
                for(/*int*/ let i = 1; i < 3; i++)
                {
                    $.$spc.System.Array.$WriteT1.call(this._gcCounts, $.$spc.System.GC.CollectionCount(i), i);
                }
            }
            /*void */ Remove()
            {
                $.$spc.System.Threading.Interlocked.Decrement($.$ref(() => this._handleCount, ($v) => this._handleCount = $v, $.$spc.System.Int32));
                if (this._handleCount < 0)
                {
                    throw new $.$spc.System.InvalidOperationException().$ctor$10($.$sris.System.SR.InvalidOperation_HCCountOverflow);
                }
                /*int*/ let newThreshold = ((this._handleCount + $.trunc(this._handleCount / 10/*DeltaPercent*/)) | 0);
                if (newThreshold < (((this._threshold - $.trunc(this._threshold / 10/*DeltaPercent*/)) | 0)))
                {
                    //lock
                    try
                    {
                        $.$spc.System.Threading.Monitor.Enter(this)
                        {
                            if (newThreshold > this.InitialThreshold)
                            {
                                this._threshold = newThreshold;
                            }
                            else 
                            {
                                this._threshold = this.InitialThreshold;
                            }
                            this._gcGeneration = 0;
                        }
                    }
                    finally
                    {
                        $.$spc.System.Threading.Monitor.Exit(this)
                    }
                }
                for(/*int*/ let i = 1; i < 3; i++)
                {
                    $.$spc.System.Array.$WriteT1.call(this._gcCounts, $.$spc.System.GC.CollectionCount(i), i);
                }
            }
            //default member initializer
            constructor()
            {
                super();
                this._gcCounts = $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$spc.System.Int32), null, [3], null);
            }
            static $h = 1608579;
            static $f = 0b10010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":655361,"g":{"r":0,"d":0,"h":38656314243,"f":1},"n":"Count","d":1608579,"h":34361346947,"f":1},{"p":655361,"g":{"r":0,"d":0,"h":51541216131,"f":1},"n":"InitialThreshold","d":1608579,"h":47246248835,"f":1},{"p":655361,"g":{"r":0,"d":0,"h":64426118019,"f":1},"n":"MaximumThreshold","d":1608579,"h":60131150723,"f":1},{"p":1310721,"g":{"r":0,"d":0,"h":77311019907,"f":1},"n":"Name","d":1608579,"h":73016052611,"f":1}],"m":[{"r":65537,"n":"Add","d":1608579,"h":81605987203,"f":1},{"r":65537,"n":"Remove","d":1608579,"h":85900954499,"f":1}],"l":[{"t":655361,"n":"DeltaPercent","d":1608579,"h":4296575875,"f":34},{"t":655361,"n":"_threshold","d":1608579,"h":8591543171,"f":2},{"t":655361,"n":"_handleCount","d":1608579,"h":12886510467,"f":2},{"t":0,"n":"_gcCounts","d":1608579,"h":17181477763,"f":2},{"t":655361,"n":"_gcGeneration","d":1608579,"h":21476445059,"f":2}],"c":[{"p":[{"n":"name","p":1310721},{"n":"initialThreshold","p":655361}],"n":".ctor","o":"$ctor$1","d":1608579,"h":25771412355,"f":1},{"p":[{"n":"name","p":1310721},{"n":"initialThreshold","p":655361},{"n":"maximumThreshold","p":655361}],"n":".ctor","o":"$ctor$2","d":1608579,"h":30066379651,"f":1}],"h":1608579}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.Runtime.InteropServices.HandleCollector`; }
        });
        
        $asm.$cls("$sris.System.Runtime.InteropServices.Marshalling.UniqueComInterfaceMarshaller<>", (T) => $asm.$gt("$sris.System.Runtime.InteropServices.Marshalling.UniqueComInterfaceMarshaller<>", [T], ($self) => class UniqueComInterfaceMarshaller$$
        {
            static /*void* */ ConvertToUnmanaged(/*T?*/ managed)
            {
                if ($.$box(managed, T) === null)
                {
                    return null;
                }
                /*nint*/ let unknown;
                if (!$.$spc.System.Runtime.InteropServices.ComWrappers.TryGetComInstance($.$box(managed, T), $.$ref(() => unknown, ($v) => unknown = $v, $.$spc.System.IntPtr)))
                {
                    unknown = $.$sris.System.Runtime.InteropServices.Marshalling.StrategyBasedComWrappers.DefaultMarshallingInstance.GetOrCreateComInterfaceForObject($.$box(managed, T), 0/*CreateComInterfaceFlags.None*/);
                }
                return $.$sris.System.Runtime.InteropServices.Marshalling.ComInterfaceMarshaller$$(T).CastIUnknownToInterfaceType(unknown);
            }
            static /*T? */ ConvertToManaged(/*void**/ unmanaged)
            {
                if (unmanaged === null)
                {
                    return $.$default(T);
                }
                return $.$cast($.$sris.System.Runtime.InteropServices.Marshalling.StrategyBasedComWrappers.DefaultMarshallingInstance.GetOrCreateObjectForComInstance($.$spc.System.IntPtr.op_Explicit$2(unmanaged), 2/*CreateObjectFlags.UniqueInstance*/), T);
            }
            static /*void */ Free(/*void**/ unmanaged)
            {
                if (unmanaged !== null)
                {
                    $.$spc.System.Runtime.InteropServices.Marshal.Release($.$spc.System.IntPtr.op_Explicit$2(unmanaged));
                }
            }
            static $h = 3705731;
            static $g = 1;
            static $f = 0b1010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"m":[{"r":0,"p":[{"n":"managed","p":T?.$h??1507328}],"n":"ConvertToUnmanaged","d":this.$h,"h":Number(BigInt(this.$h)|0x100000000n),"f":33},{"r":T?.$h??1507328,"p":[{"n":"unmanaged","p":0}],"n":"ConvertToManaged","d":this.$h,"h":Number(BigInt(this.$h)|0x200000000n),"f":33},{"r":65537,"p":[{"n":"unmanaged","p":0}],"n":"Free","d":this.$h,"h":Number(BigInt(this.$h)|0x300000000n),"f":33}],"g":[T?.$h??1507328],"r":1,"h":this.$h,"a":[{"t":115277825,"c":4410245121,"a":[{"v":"android","t":1310721}]},{"t":115277825,"c":4410245121,"a":[{"v":"browser","t":1310721}]},{"t":115277825,"c":4410245121,"a":[{"v":"ios","t":1310721}]},{"t":115277825,"c":4410245121,"a":[{"v":"tvos","t":1310721}]},{"t":23396353,"c":8613330945,"a":[{"v":false,"t":262145}]},{"t":106823681,"c":4401790977,"a":[{"v":106889217,"t":142606337},{"v":0,"t":106954753},{"v":$.$sris.System.Runtime.InteropServices.Marshalling.UniqueComInterfaceMarshaller$$().$h,"t":142606337}]}]}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.Runtime.InteropServices.Marshalling.UniqueComInterfaceMarshaller<${T?.$fullName}>`; }
        }));
        
        $asm.$cls("$sris.System.Runtime.InteropServices.Marshalling.ExceptionAsDefaultMarshaller<>", (T) => $asm.$gt("$sris.System.Runtime.InteropServices.Marshalling.ExceptionAsDefaultMarshaller<>", [T], ($self) => class ExceptionAsDefaultMarshaller$$
        {
            static /*T */ ConvertToUnmanaged(/*Exception*/ e)
            {
                _ = $.$spc.System.Runtime.InteropServices.Marshal.GetHRForException(e);
                return $.$default(T);
            }
            static $h = 2526083;
            static $g = 1;
            static $f = 0b1010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"m":[{"r":T?.$h??1507328,"p":[{"n":"e","p":47185921}],"n":"ConvertToUnmanaged","d":this.$h,"h":Number(BigInt(this.$h)|0x100000000n),"f":33}],"g":[T?.$h??1507328],"s":[{"n":"T","f":10}],"r":1,"h":this.$h,"a":[{"t":106823681,"c":4401790977,"a":[{"v":47185921,"t":142606337},{"v":6,"t":106954753},{"v":$.$sris.System.Runtime.InteropServices.Marshalling.ExceptionAsDefaultMarshaller$$().$h,"t":142606337}]}]}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.Runtime.InteropServices.Marshalling.ExceptionAsDefaultMarshaller<${T?.$fullName}>`; }
        }));
        
        $asm.$cls("$sris.System.Runtime.InteropServices.Marshalling.ExceptionAsNaNMarshaller<>", (T) => $asm.$gt("$sris.System.Runtime.InteropServices.Marshalling.ExceptionAsNaNMarshaller<>", [T], ($self) => class ExceptionAsNaNMarshaller$$
        {
            static /*T */ ConvertToUnmanaged(/*Exception*/ e)
            {
                _ = $.$spc.System.Runtime.InteropServices.Marshal.GetHRForException(e);
                return T.System$Numerics$IFloatingPointIeee754$$$NaN;
            }
            static $h = 2657155;
            static $g = 1;
            static $f = 0b1010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"m":[{"r":T?.$h??1507328,"p":[{"n":"e","p":47185921}],"n":"ConvertToUnmanaged","d":this.$h,"h":Number(BigInt(this.$h)|0x100000000n),"f":33}],"g":[T?.$h??1507328],"s":[{"n":"T","f":10,"c":[$.$spc.System.Numerics.IFloatingPointIeee754$$(T).$h]}],"r":1,"h":this.$h,"a":[{"t":106823681,"c":4401790977,"a":[{"v":47185921,"t":142606337},{"v":6,"t":106954753},{"v":$.$sris.System.Runtime.InteropServices.Marshalling.ExceptionAsNaNMarshaller$$().$h,"t":142606337}]}]}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.Runtime.InteropServices.Marshalling.ExceptionAsNaNMarshaller<${T?.$fullName}>`; }
        }));
        
        $asm.$cls("$sris.System.Runtime.InteropServices.Marshalling.ComVariantMarshaller", ($self) => class ComVariantMarshaller
        {
            /*short*/ static VARIANT_TRUE = -1;
            /*short*/ static VARIANT_FALSE = 0;
            static /*ComVariant */ ConvertToUnmanaged(/*object?*/ managed)
            {
                if (managed === null)
                {
                    return new $.$spc.System.Runtime.InteropServices.Marshalling.ComVariant();
                }
                //switch (managed)
                {
                    let s;
                    let b;
                    let i;
                    let l;
                    let f;
                    let d;
                    let dt;
                    let errorWrapper;
                    let currencyWrapper;
                    let bStrWrapper;
                    $switchJumpStart1: 
                    //case sbyte s:
                    if ($.$is(managed, $.$spc.System.SByte, { set $v(v){ s = v; } }))
                    {
                        return $.$spc.System.Runtime.InteropServices.Marshalling.ComVariant.Create($.$spc.System.SByte, s);
                    }
                    //case byte b:
                    else if ($.$is(managed, $.$spc.System.Byte, { set $v(v){ b = v; } }))
                    {
                        return $.$spc.System.Runtime.InteropServices.Marshalling.ComVariant.Create($.$spc.System.Byte, b);
                    }
                    //case short s:
                    else if ($.$is(managed, $.$spc.System.Int16, { set $v(v){ s = v; } }))
                    {
                        return $.$spc.System.Runtime.InteropServices.Marshalling.ComVariant.Create($.$spc.System.Int16, s);
                    }
                    //case ushort s:
                    else if ($.$is(managed, $.$spc.System.UInt16, { set $v(v){ s = v; } }))
                    {
                        return $.$spc.System.Runtime.InteropServices.Marshalling.ComVariant.Create($.$spc.System.UInt16, s);
                    }
                    //case int i:
                    else if ($.$is(managed, $.$spc.System.Int32, { set $v(v){ i = v; } }))
                    {
                        return $.$spc.System.Runtime.InteropServices.Marshalling.ComVariant.Create($.$spc.System.Int32, i);
                    }
                    //case uint i:
                    else if ($.$is(managed, $.$spc.System.UInt32, { set $v(v){ i = v; } }))
                    {
                        return $.$spc.System.Runtime.InteropServices.Marshalling.ComVariant.Create($.$spc.System.UInt32, i);
                    }
                    //case long l:
                    else if ($.$is(managed, $.$spc.System.Int64, { set $v(v){ l = v; } }))
                    {
                        return $.$spc.System.Runtime.InteropServices.Marshalling.ComVariant.Create($.$spc.System.Int64, l);
                    }
                    //case ulong l:
                    else if ($.$is(managed, $.$spc.System.UInt64, { set $v(v){ l = v; } }))
                    {
                        return $.$spc.System.Runtime.InteropServices.Marshalling.ComVariant.Create($.$spc.System.UInt64, l);
                    }
                    //case float f:
                    else if ($.$is(managed, $.$spc.System.Single, { set $v(v){ f = v; } }))
                    {
                        return $.$spc.System.Runtime.InteropServices.Marshalling.ComVariant.Create($.$spc.System.Single, f);
                    }
                    //case double d:
                    else if ($.$is(managed, $.$spc.System.Double, { set $v(v){ d = v; } }))
                    {
                        return $.$spc.System.Runtime.InteropServices.Marshalling.ComVariant.Create($.$spc.System.Double, d);
                    }
                    //case decimal d:
                    else if ($.$is(managed, $.$spc.System.Decimal, { set $v(v){ d = v; } }))
                    {
                        return $.$spc.System.Runtime.InteropServices.Marshalling.ComVariant.Create($.$spc.System.Decimal, d);
                    }
                    //case bool b:
                    else if ($.$is(managed, $.$spc.System.Boolean, { set $v(v){ b = v; } }))
                    {
                        return $.$spc.System.Runtime.InteropServices.Marshalling.ComVariant.Create($.$spc.System.Boolean, b);
                    }
                    //case string s:
                    else if ($.$is(managed, $.$spc.System.String, { set $v(v){ s = v; } }))
                    {
                        return $.$spc.System.Runtime.InteropServices.Marshalling.ComVariant.Create($.$spc.System.String, s);
                    }
                    //case DateTime dt:
                    else if ($.$is(managed, $.$spc.System.DateTime, { set $v(v){ dt = v; } }))
                    {
                        return $.$spc.System.Runtime.InteropServices.Marshalling.ComVariant.Create($.$spc.System.DateTime, dt);
                    }
                    //case ErrorWrapper errorWrapper:
                    else if ($.$is(managed, $.$spc.System.Runtime.InteropServices.ErrorWrapper, { set $v(v){ errorWrapper = v; } }))
                    {
                        return $.$spc.System.Runtime.InteropServices.Marshalling.ComVariant.Create($.$spc.System.Runtime.InteropServices.ErrorWrapper, errorWrapper);
                    }
                    //case CurrencyWrapper currencyWrapper:
                    else if ($.$is(managed, $.$spc.System.Runtime.InteropServices.CurrencyWrapper, { set $v(v){ currencyWrapper = v; } }))
                    {
                        return $.$spc.System.Runtime.InteropServices.Marshalling.ComVariant.Create($.$spc.System.Runtime.InteropServices.CurrencyWrapper, currencyWrapper);
                    }
                    //case BStrWrapper bStrWrapper:
                    else if ($.$is(managed, $.$spc.System.Runtime.InteropServices.BStrWrapper, { set $v(v){ bStrWrapper = v; } }))
                    {
                        return $.$spc.System.Runtime.InteropServices.Marshalling.ComVariant.Create($.$spc.System.Runtime.InteropServices.BStrWrapper, bStrWrapper);
                    }
                    //case DBNull:
                    else if (managed == $.$spc.System.DBNull)
                    {
                        return $.$spc.System.Runtime.InteropServices.Marshalling.ComVariant.Null;
                    }
                }
                /*ComVariant*/ let variant;
                if ($.$sris.System.Runtime.InteropServices.Marshalling.ComVariantMarshaller.TryCreateOleVariantForInterfaceWrapper(managed, $.$ref(() => variant, ($v) => variant = $v, $.$spc.System.Runtime.InteropServices.Marshalling.ComVariant)))
                {
                    return variant;
                }
                throw new $.$spc.System.ArgumentException().$ctor$13($.$sris.System.SR.ComVariantMarshaller_ManagedTypeNotSupported, "managed");
            }
            static /*bool */ TryCreateOleVariantForInterfaceWrapper(/*object*/ managed, /*out ComVariant*/ variant)
            {
                let uw;
                if ($.$is(managed, $.$spc.System.Runtime.InteropServices.UnknownWrapper, { set $v(v){ uw = v; } }))
                {
                    /*object?*/ let wrapped = uw.WrappedObject;
                    if (wrapped === null)
                    {
                        variant.$v = new $.$spc.System.Runtime.InteropServices.Marshalling.ComVariant();
                        return true;
                    }
                    variant.$v = $.$spc.System.Runtime.InteropServices.Marshalling.ComVariant.CreateRaw($.$spc.System.IntPtr, 13/*VarEnum.VT_UNKNOWN*/, $.$sris.System.Runtime.InteropServices.Marshalling.StrategyBasedComWrappers.DefaultMarshallingInstance.GetOrCreateComInterfaceForObject(wrapped, 0/*CreateComInterfaceFlags.None*/));
                    return true;
                }
                else if (!(managed === null) && !($.$sris.System.Runtime.InteropServices.Marshalling.StrategyBasedComWrappers.DefaultIUnknownInterfaceDetailsStrategy.System$Runtime$InteropServices$Marshalling$IIUnknownInterfaceDetailsStrategy$GetComExposedTypeDetails($.$spc.System.Object.GetType.call(managed).TypeHandle) === null))
                {
                    variant.$v = $.$spc.System.Runtime.InteropServices.Marshalling.ComVariant.CreateRaw($.$spc.System.IntPtr, 13/*VarEnum.VT_UNKNOWN*/, $.$sris.System.Runtime.InteropServices.Marshalling.StrategyBasedComWrappers.DefaultMarshallingInstance.GetOrCreateComInterfaceForObject(managed, 0/*CreateComInterfaceFlags.None*/));
                    return true;
                }
                variant.$v = new $.$spc.System.Runtime.InteropServices.Marshalling.ComVariant();
                return false;
            }
            static /*object? */ ConvertToManaged(/*ComVariant*/ unmanaged)
            {
                let $switch1 = unmanaged.VarType;
                switch($switch1)
                {
                    case 0/*VarEnum.VT_EMPTY*/:
                    case 16384/*VarEnum.VT_BYREF*/ | 0/*VarEnum.VT_EMPTY*/:
                    return null;
                    case 1/*VarEnum.VT_NULL*/:
                    case 16384/*VarEnum.VT_BYREF*/ | 1/*VarEnum.VT_NULL*/:
                    return $.$spc.System.DBNull.Value;
                    case 16/*VarEnum.VT_I1*/:
                    return $.$box(unmanaged.As($.$spc.System.SByte), $.$spc.System.SByte);
                    case 17/*VarEnum.VT_UI1*/:
                    return $.$box(unmanaged.As($.$spc.System.Byte), $.$spc.System.Byte);
                    case 2/*VarEnum.VT_I2*/:
                    return $.$box(unmanaged.As($.$spc.System.Int16), $.$spc.System.Int16);
                    case 18/*VarEnum.VT_UI2*/:
                    return $.$box(unmanaged.As($.$spc.System.UInt16), $.$spc.System.UInt16);
                    case 22/*VarEnum.VT_INT*/:
                    case 3/*VarEnum.VT_I4*/:
                    return $.$box(unmanaged.As($.$spc.System.Int32), $.$spc.System.Int32);
                    case 23/*VarEnum.VT_UINT*/:
                    case 19/*VarEnum.VT_UI4*/:
                    return $.$box(unmanaged.As($.$spc.System.UInt32), $.$spc.System.UInt32);
                    case 20/*VarEnum.VT_I8*/:
                    return $.$box(unmanaged.As($.$spc.System.Int64), $.$spc.System.Int64);
                    case 21/*VarEnum.VT_UI8*/:
                    return $.$box(unmanaged.As($.$spc.System.UInt64), $.$spc.System.UInt64);
                    case 4/*VarEnum.VT_R4*/:
                    return $.$box(unmanaged.As($.$spc.System.Single), $.$spc.System.Single);
                    case 5/*VarEnum.VT_R8*/:
                    return $.$box(unmanaged.As($.$spc.System.Double), $.$spc.System.Double);
                    case 14/*VarEnum.VT_DECIMAL*/:
                    return unmanaged.As($.$spc.System.Decimal);
                    case 11/*VarEnum.VT_BOOL*/:
                    return $.$box(unmanaged.As($.$spc.System.Boolean), $.$spc.System.Boolean);
                    case 8/*VarEnum.VT_BSTR*/:
                    return unmanaged.As($.$spc.System.String);
                    case 7/*VarEnum.VT_DATE*/:
                    return unmanaged.As($.$spc.System.DateTime);
                    case 10/*VarEnum.VT_ERROR*/:
                    return $.$box(unmanaged.As($.$spc.System.Int32), $.$spc.System.Int32);
                    case 6/*VarEnum.VT_CY*/:
                    return unmanaged.As($.$spc.System.Runtime.InteropServices.CurrencyWrapper).WrappedObject;
                    case 13/*VarEnum.VT_UNKNOWN*/:
                    case 9/*VarEnum.VT_DISPATCH*/:
                    return $.$sris.System.Runtime.InteropServices.Marshalling.StrategyBasedComWrappers.DefaultMarshallingInstance.GetOrCreateObjectForComInstance(unmanaged.GetRawDataRef($.$spc.System.IntPtr).$v, 8/*CreateObjectFlags.Unwrap*/);
                    case 16384/*VarEnum.VT_BYREF*/ | 12/*VarEnum.VT_VARIANT*/:
                    return $.$sris.System.Runtime.InteropServices.Marshalling.ComVariantMarshaller.ConvertToManaged($.$spc.InteropUtility.castAddress2Object(unmanaged.GetRawDataRef($.$spc.System.IntPtr).$v));
                    case 16384/*VarEnum.VT_BYREF*/ | 16/*VarEnum.VT_I1*/:
                    return $.$box($.$spc.InteropUtility.castAddress2Object(unmanaged.GetRawDataRef($.$spc.System.IntPtr).$v), $.$spc.System.SByte);
                    case 16384/*VarEnum.VT_BYREF*/ | 17/*VarEnum.VT_UI1*/:
                    return $.$box($.$spc.InteropUtility.castAddress2Object(unmanaged.GetRawDataRef($.$spc.System.IntPtr).$v), $.$spc.System.Byte);
                    case 16384/*VarEnum.VT_BYREF*/ | 2/*VarEnum.VT_I2*/:
                    return $.$box($.$spc.InteropUtility.castAddress2Object(unmanaged.GetRawDataRef($.$spc.System.IntPtr).$v), $.$spc.System.Int16);
                    case 16384/*VarEnum.VT_BYREF*/ | 18/*VarEnum.VT_UI2*/:
                    return $.$box($.$spc.InteropUtility.castAddress2Object(unmanaged.GetRawDataRef($.$spc.System.IntPtr).$v), $.$spc.System.UInt16);
                    case 16384/*VarEnum.VT_BYREF*/ | 3/*VarEnum.VT_I4*/:
                    return $.$box($.$spc.InteropUtility.castAddress2Object(unmanaged.GetRawDataRef($.$spc.System.IntPtr).$v), $.$spc.System.Int32);
                    case 16384/*VarEnum.VT_BYREF*/ | 19/*VarEnum.VT_UI4*/:
                    return $.$box($.$spc.InteropUtility.castAddress2Object(unmanaged.GetRawDataRef($.$spc.System.IntPtr).$v), $.$spc.System.UInt32);
                    case 16384/*VarEnum.VT_BYREF*/ | 20/*VarEnum.VT_I8*/:
                    return $.$box($.$spc.InteropUtility.castAddress2Object(unmanaged.GetRawDataRef($.$spc.System.IntPtr).$v), $.$spc.System.Int64);
                    case 16384/*VarEnum.VT_BYREF*/ | 21/*VarEnum.VT_UI8*/:
                    return $.$box($.$spc.InteropUtility.castAddress2Object(unmanaged.GetRawDataRef($.$spc.System.IntPtr).$v), $.$spc.System.UInt64);
                    case 16384/*VarEnum.VT_BYREF*/ | 4/*VarEnum.VT_R4*/:
                    return $.$box($.$spc.InteropUtility.castAddress2Object(unmanaged.GetRawDataRef($.$spc.System.IntPtr).$v), $.$spc.System.Single);
                    case 16384/*VarEnum.VT_BYREF*/ | 5/*VarEnum.VT_R8*/:
                    return $.$box($.$spc.InteropUtility.castAddress2Object(unmanaged.GetRawDataRef($.$spc.System.IntPtr).$v), $.$spc.System.Double);
                    case 16384/*VarEnum.VT_BYREF*/ | 14/*VarEnum.VT_DECIMAL*/:
                    return $.$spc.InteropUtility.castAddress2Object(unmanaged.GetRawDataRef($.$spc.System.IntPtr).$v);
                    case 16384/*VarEnum.VT_BYREF*/ | 11/*VarEnum.VT_BOOL*/:
                    return $.$box($.$spc.InteropUtility.castAddress2Object(unmanaged.GetRawDataRef($.$spc.System.IntPtr).$v) !== 0/*VARIANT_FALSE*/, $.$spc.System.Boolean);
                    case 16384/*VarEnum.VT_BYREF*/ | 8/*VarEnum.VT_BSTR*/:
                    return $.$spc.System.Runtime.InteropServices.Marshal.PtrToStringBSTR($.$spc.InteropUtility.castAddress2Object(unmanaged.GetRawDataRef($.$spc.System.IntPtr).$v));
                    case 16384/*VarEnum.VT_BYREF*/ | 7/*VarEnum.VT_DATE*/:
                    return $.$spc.System.DateTime.FromOADate($.$spc.InteropUtility.castAddress2Object(unmanaged.GetRawDataRef($.$spc.System.IntPtr).$v));
                    case 16384/*VarEnum.VT_BYREF*/ | 10/*VarEnum.VT_ERROR*/:
                    return $.$box($.$spc.InteropUtility.castAddress2Object(unmanaged.GetRawDataRef($.$spc.System.IntPtr).$v), $.$spc.System.Int32);
                    case 16384/*VarEnum.VT_BYREF*/ | 6/*VarEnum.VT_CY*/:
                    return $.$spc.System.Decimal.FromOACurrency($.$spc.InteropUtility.castAddress2Object(unmanaged.GetRawDataRef($.$spc.System.IntPtr).$v));
                    case 16384/*VarEnum.VT_BYREF*/ | 13/*VarEnum.VT_UNKNOWN*/:
                    return $.$sris.System.Runtime.InteropServices.Marshalling.StrategyBasedComWrappers.DefaultMarshallingInstance.GetOrCreateObjectForComInstance($.$spc.InteropUtility.castAddress2Object(unmanaged.GetRawDataRef($.$spc.System.IntPtr).$v), 8/*CreateObjectFlags.Unwrap*/);
                    default:
                    throw new $.$spc.System.ArgumentException().$ctor$13($.$sris.System.SR.ComVariantMarshaller_UnmanagedTypeNotSupported, "unmanaged");
                }
            }
            static /*void */ Free(/*ComVariant*/ unmanaged)
            {
                return unmanaged.Dispose();
            }
            static $_RefPropagate;
            static get RefPropagate()
            {
                let $cls = $.$sris.System.Runtime.InteropServices.Marshalling.ComVariantMarshaller;
                return $cls.$_RefPropagate ??= $asm.$nstr("$sris.System.Runtime.InteropServices.Marshalling.ComVariantMarshaller.RefPropagate", ($self) => class RefPropagate extends $.$spc.System.ValueType
                {
                    /*ComVariant*/  get _unmanaged() { return this.$getField(0, 125); }
                    /*ComVariant*/  set _unmanaged(value) { this.$setField(0, 125, value); }
                    /*object?*/  get _managed() { return this.$getField(125, 4); }
                    /*object?*/  set _managed(value) { this.$setField(125, 4, value); }
                    /*void */ FromUnmanaged(/*ComVariant*/ unmanaged)
                    {
                        return this._unmanaged = unmanaged.Clone();
                    }
                    /*void */ FromManaged(/*object?*/ managed)
                    {
                        return this._managed = managed;
                    }
                    /*ComVariant */ ToUnmanaged()
                    {
                        if (!((this._unmanaged.VarType & (16384/*VarEnum.VT_BYREF*/)) == (16384/*VarEnum.VT_BYREF*/)))
                        {
                            return $.$sris.System.Runtime.InteropServices.Marshalling.ComVariantMarshaller.ConvertToUnmanaged(this._managed);
                        }
                        if (this._managed === null && (((this._unmanaged.VarType & ~16384/*VarEnum.VT_BYREF*/) === 8/*VarEnum.VT_BSTR*/) || ((this._unmanaged.VarType & ~16384/*VarEnum.VT_BYREF*/) === 9/*VarEnum.VT_DISPATCH*/)) || ((this._unmanaged.VarType & ~16384/*VarEnum.VT_BYREF*/) === 13/*VarEnum.VT_UNKNOWN*/))
                        {
                            $.$spc.InteropUtility.castAddress2Object(this._unmanaged.GetRawDataRef($.$spc.System.IntPtr).$v).$v = 0;
                            return this._unmanaged;
                        }
                        //switch ((_unmanaged.VarType & ~VarEnum.VT_BYREF, _managed))
                        let $switch2 = this._unmanaged.VarType & ~16384/*VarEnum.VT_BYREF*/;
                        let $switch3 = this._managed;
                        {
                            let s;
                            let b;
                            let u;
                            let i;
                            let l;
                            let ul;
                            let f;
                            let d;
                            let str;
                            let dt;
                            let error;
                            let cy;
                            let unkObj;
                            $switchJumpStart1: 
                            //case (VarEnum.VT_VARIANT, _):
                            if (($switch2 === 12/*VarEnum.VT_VARIANT*/))
                            {
                                $.$spc.InteropUtility.castAddress2Object(this._unmanaged.GetRawDataRef($.$spc.System.IntPtr).$v).$v = $.$sris.System.Runtime.InteropServices.Marshalling.ComVariantMarshaller.ConvertToUnmanaged(this._managed);
                            }
                            //case (VarEnum.VT_I1 or VarEnum.VT_UI1, sbyte s):
                            else if ((($switch2 === 16/*VarEnum.VT_I1*/) || ($switch2 === 17/*VarEnum.VT_UI1*/)) && ($.$is($switch3, $.$spc.System.SByte, { set $v(v){ s = v; } })))
                            {
                                $.$spc.InteropUtility.castAddress2Object(this._unmanaged.GetRawDataRef($.$spc.System.IntPtr).$v).$v = s;
                            }
                            //case (VarEnum.VT_I1 or VarEnum.VT_UI1, byte b):
                            else if ((($switch2 === 16/*VarEnum.VT_I1*/) || ($switch2 === 17/*VarEnum.VT_UI1*/)) && ($.$is($switch3, $.$spc.System.Byte, { set $v(v){ b = v; } })))
                            {
                                $.$spc.InteropUtility.castAddress2Object(this._unmanaged.GetRawDataRef($.$spc.System.IntPtr).$v).$v = b;
                            }
                            //case (VarEnum.VT_I2 or VarEnum.VT_UI2, short s):
                            else if ((($switch2 === 2/*VarEnum.VT_I2*/) || ($switch2 === 18/*VarEnum.VT_UI2*/)) && ($.$is($switch3, $.$spc.System.Int16, { set $v(v){ s = v; } })))
                            {
                                $.$spc.InteropUtility.castAddress2Object(this._unmanaged.GetRawDataRef($.$spc.System.IntPtr).$v).$v = s;
                            }
                            //case (VarEnum.VT_I2 or VarEnum.VT_UI2, ushort u):
                            else if ((($switch2 === 2/*VarEnum.VT_I2*/) || ($switch2 === 18/*VarEnum.VT_UI2*/)) && ($.$is($switch3, $.$spc.System.UInt16, { set $v(v){ u = v; } })))
                            {
                                $.$spc.InteropUtility.castAddress2Object(this._unmanaged.GetRawDataRef($.$spc.System.IntPtr).$v).$v = u;
                            }
                            //case (VarEnum.VT_I4 or VarEnum.VT_INT or VarEnum.VT_UI4 or VarEnum.VT_UINT or VarEnum.VT_ERROR, int i):
                            else if (((((($switch2 === 3/*VarEnum.VT_I4*/) || ($switch2 === 22/*VarEnum.VT_INT*/)) || ($switch2 === 19/*VarEnum.VT_UI4*/)) || ($switch2 === 23/*VarEnum.VT_UINT*/)) || ($switch2 === 10/*VarEnum.VT_ERROR*/)) && ($.$is($switch3, $.$spc.System.Int32, { set $v(v){ i = v; } })))
                            {
                                $.$spc.InteropUtility.castAddress2Object(this._unmanaged.GetRawDataRef($.$spc.System.IntPtr).$v).$v = i;
                            }
                            //case (VarEnum.VT_I4 or VarEnum.VT_INT or VarEnum.VT_UI4 or VarEnum.VT_UINT or VarEnum.VT_ERROR, uint u):
                            else if (((((($switch2 === 3/*VarEnum.VT_I4*/) || ($switch2 === 22/*VarEnum.VT_INT*/)) || ($switch2 === 19/*VarEnum.VT_UI4*/)) || ($switch2 === 23/*VarEnum.VT_UINT*/)) || ($switch2 === 10/*VarEnum.VT_ERROR*/)) && ($.$is($switch3, $.$spc.System.UInt32, { set $v(v){ u = v; } })))
                            {
                                $.$spc.InteropUtility.castAddress2Object(this._unmanaged.GetRawDataRef($.$spc.System.IntPtr).$v).$v = u;
                            }
                            //case (VarEnum.VT_I8 or VarEnum.VT_UI8, long l):
                            else if ((($switch2 === 20/*VarEnum.VT_I8*/) || ($switch2 === 21/*VarEnum.VT_UI8*/)) && ($.$is($switch3, $.$spc.System.Int64, { set $v(v){ l = v; } })))
                            {
                                $.$spc.InteropUtility.castAddress2Object(this._unmanaged.GetRawDataRef($.$spc.System.IntPtr).$v).$v = l;
                            }
                            //case (VarEnum.VT_I8 or VarEnum.VT_UI8, ulong ul):
                            else if ((($switch2 === 20/*VarEnum.VT_I8*/) || ($switch2 === 21/*VarEnum.VT_UI8*/)) && ($.$is($switch3, $.$spc.System.UInt64, { set $v(v){ ul = v; } })))
                            {
                                $.$spc.InteropUtility.castAddress2Object(this._unmanaged.GetRawDataRef($.$spc.System.IntPtr).$v).$v = ul;
                            }
                            //case (VarEnum.VT_R4, float f):
                            else if (($switch2 === 4/*VarEnum.VT_R4*/) && ($.$is($switch3, $.$spc.System.Single, { set $v(v){ f = v; } })))
                            {
                                $.$spc.InteropUtility.castAddress2Object(this._unmanaged.GetRawDataRef($.$spc.System.IntPtr).$v).$v = f;
                            }
                            //case (VarEnum.VT_R8, double d):
                            else if (($switch2 === 5/*VarEnum.VT_R8*/) && ($.$is($switch3, $.$spc.System.Double, { set $v(v){ d = v; } })))
                            {
                                $.$spc.InteropUtility.castAddress2Object(this._unmanaged.GetRawDataRef($.$spc.System.IntPtr).$v).$v = d;
                            }
                            //case (VarEnum.VT_DECIMAL, decimal d):
                            else if (($switch2 === 14/*VarEnum.VT_DECIMAL*/) && ($.$is($switch3, $.$spc.System.Decimal, { set $v(v){ d = v; } })))
                            {
                                $.$spc.InteropUtility.castAddress2Object(this._unmanaged.GetRawDataRef($.$spc.System.IntPtr).$v).$v = d;
                            }
                            //case (VarEnum.VT_BOOL, bool b):
                            else if (($switch2 === 11/*VarEnum.VT_BOOL*/) && ($.$is($switch3, $.$spc.System.Boolean, { set $v(v){ b = v; } })))
                            {
                                $.$spc.InteropUtility.castAddress2Object(this._unmanaged.GetRawDataRef($.$spc.System.IntPtr).$v).$v = b ? -1/*VARIANT_TRUE*/ : 0/*VARIANT_FALSE*/;
                            }
                            //case (VarEnum.VT_BSTR, string str):
                            else if (($switch2 === 8/*VarEnum.VT_BSTR*/) && ($.$is($switch3, $.$spc.System.String, { set $v(v){ str = v; } })))
                            {
                                {
                                    /*ref IntPtr*/ let bstrStorage = $.$cast(this._unmanaged.GetRawDataRef($.$spc.System.IntPtr).$v, $.$typePointer($.$spc.System.IntPtr));
                                    $.$spc.System.Runtime.InteropServices.Marshal.FreeBSTR(bstrStorage.$v);
                                    bstrStorage.$v = $.$spc.System.Runtime.InteropServices.Marshal.StringToBSTR(str);
                                    break $switchJumpStart1;
                                }
                            }
                            //case (VarEnum.VT_BSTR, BStrWrapper str):
                            else if (($switch2 === 8/*VarEnum.VT_BSTR*/) && ($.$is($switch3, $.$spc.System.Runtime.InteropServices.BStrWrapper, { set $v(v){ str = v; } })))
                            {
                                {
                                    /*ref IntPtr*/ let bstrStorage = $.$cast(this._unmanaged.GetRawDataRef($.$spc.System.IntPtr).$v, $.$typePointer($.$spc.System.IntPtr));
                                    $.$spc.System.Runtime.InteropServices.Marshal.FreeBSTR(bstrStorage.$v);
                                    bstrStorage.$v = $.$spc.System.Runtime.InteropServices.Marshal.StringToBSTR(str.WrappedObject);
                                    break $switchJumpStart1;
                                }
                            }
                            //case (VarEnum.VT_DATE, DateTime dt):
                            else if (($switch2 === 7/*VarEnum.VT_DATE*/) && ($.$is($switch3, $.$spc.System.DateTime, { set $v(v){ dt = v; } })))
                            {
                                $.$spc.InteropUtility.castAddress2Object(this._unmanaged.GetRawDataRef($.$spc.System.IntPtr).$v).$v = dt.ToOADate();
                            }
                            //case (VarEnum.VT_ERROR, ErrorWrapper error):
                            else if (($switch2 === 10/*VarEnum.VT_ERROR*/) && ($.$is($switch3, $.$spc.System.Runtime.InteropServices.ErrorWrapper, { set $v(v){ error = v; } })))
                            {
                                $.$spc.InteropUtility.castAddress2Object(this._unmanaged.GetRawDataRef($.$spc.System.IntPtr).$v).$v = error.ErrorCode;
                            }
                            //case (VarEnum.VT_CY, CurrencyWrapper cy):
                            else if (($switch2 === 6/*VarEnum.VT_CY*/) && ($.$is($switch3, $.$spc.System.Runtime.InteropServices.CurrencyWrapper, { set $v(v){ cy = v; } })))
                            {
                                $.$spc.InteropUtility.castAddress2Object(this._unmanaged.GetRawDataRef($.$spc.System.IntPtr).$v).$v = $.$spc.System.Decimal.ToOACurrency(cy.WrappedObject);
                            }
                            //case (VarEnum.VT_UNKNOWN, object unkObj):
                            else if (($switch2 === 13/*VarEnum.VT_UNKNOWN*/) && ($.$is($switch3, $.$spc.System.Object, { set $v(v){ unkObj = v; } })))
                            {
                                $.$spc.InteropUtility.castAddress2Object(this._unmanaged.GetRawDataRef($.$spc.System.IntPtr).$v).$v = $.$sris.System.Runtime.InteropServices.Marshalling.StrategyBasedComWrappers.DefaultMarshallingInstance.GetOrCreateComInterfaceForObject(unkObj, 0/*CreateComInterfaceFlags.None*/);
                            }
                            //default
                            else
                            {
                                throw new $.$spc.System.ArgumentException().$ctor$13("Invalid combination of unmanaged variant type and managed object type.", "_managed");
                            }
                        }
                        return this._unmanaged;
                    }
                    /*object? */ ToManaged()
                    {
                        return $.$sris.System.Runtime.InteropServices.Marshalling.ComVariantMarshaller.ConvertToManaged(this._unmanaged.Clone());
                    }
                    /*void */ Free()
                    {
                        return this._unmanaged.Dispose();
                    }
                    //default value type constructor
                    $ctor$2()
                    {
                        return this;
                    }
                    Clone($copy)
                    {
                        let copy = $copy ?? new this.constructor();
                        copy._unmanaged = this._unmanaged.Clone();
                        copy._managed = this._managed;
                        return copy;
                    }
                    //default member initializer
                    constructor()
                    {
                        super();
                        this._unmanaged = $.$default($.$spc.System.Runtime.InteropServices.Marshalling.ComVariant);
                        this._managed = null;
                    }
                    static $h = 2329475;
                    static $z = 129;
                    static $f = 0b10000001010000001;
                    static $k = 2;
                    static $$md;
                    static get $md() { return this.$$md ??= {"b":196609,"m":[{"r":65537,"p":[{"n":"unmanaged","p":106233857}],"n":"FromUnmanaged","d":2329475,"h":12887231363,"f":1},{"r":65537,"p":[{"n":"managed","p":131073}],"n":"FromManaged","d":2329475,"h":17182198659,"f":1},{"r":106233857,"n":"ToUnmanaged","d":2329475,"h":21477165955,"f":1},{"r":131073,"n":"ToManaged","d":2329475,"h":25772133251,"f":1},{"r":65537,"n":"Free","d":2329475,"h":30067100547,"f":1}],"l":[{"t":106233857,"n":"_unmanaged","d":2329475,"h":4297296771,"f":2},{"t":131073,"n":"_managed","d":2329475,"h":8592264067,"f":2}],"c":[{"n":".ctor","o":"$ctor$2","d":2329475,"h":34362067843,"f":1}],"d":2263939,"h":2329475}; }
                    static get $b() { return $.$spc.System.ValueType; }
                    static get $fullName() { return `System.Runtime.InteropServices.Marshalling.ComVariantMarshaller.RefPropagate`; }
                }, $cls, ($v) => $cls.$_RefPropagate = $v);
            }
            static $h = 2263939;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"m":[{"r":106233857,"p":[{"n":"managed","p":131073}],"n":"ConvertToUnmanaged","d":2263939,"h":12887165827,"f":33},{"r":262145,"p":[{"n":"managed","p":131073},{"n":"variant","p":106233857,"f":2}],"n":"TryCreateOleVariantForInterfaceWrapper","d":2263939,"h":17182133123,"f":34},{"r":131073,"p":[{"n":"unmanaged","p":106233857}],"n":"ConvertToManaged","d":2263939,"h":21477100419,"f":33},{"r":65537,"p":[{"n":"unmanaged","p":106233857}],"n":"Free","d":2263939,"h":25772067715,"f":33}],"l":[{"t":524289,"n":"VARIANT_TRUE","d":2263939,"h":4297231235,"f":34},{"t":524289,"n":"VARIANT_FALSE","d":2263939,"h":8592198531,"f":34}],"j":[2329475],"h":2263939,"a":[{"t":106823681,"c":4401790977,"a":[{"v":131073,"t":142606337},{"v":0,"t":106954753},{"v":2263939,"t":142606337}]},{"t":106823681,"c":4401790977,"a":[{"v":131073,"t":142606337},{"v":5,"t":106954753},{"v":2329475,"t":142606337}]}]}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.Runtime.InteropServices.Marshalling.ComVariantMarshaller`; }
        });
        
        $asm.$cls("$sris.System.Runtime.InteropServices.Marshalling.ComInterfaceMarshaller<>", (T) => $asm.$gt("$sris.System.Runtime.InteropServices.Marshalling.ComInterfaceMarshaller<>", [T], ($self) => class ComInterfaceMarshaller$$
        {
            /*Guid?*/ static TargetInterfaceIID = null;
            static /*void* */ ConvertToUnmanaged(/*T?*/ managed)
            {
                if ($.$box(managed, T) === null)
                {
                    return null;
                }
                /*nint*/ let unknown;
                if (!$.$spc.System.Runtime.InteropServices.ComWrappers.TryGetComInstance($.$box(managed, T), $.$ref(() => unknown, ($v) => unknown = $v, $.$spc.System.IntPtr)))
                {
                    unknown = $.$sris.System.Runtime.InteropServices.Marshalling.StrategyBasedComWrappers.DefaultMarshallingInstance.GetOrCreateComInterfaceForObject($.$box(managed, T), 0/*CreateComInterfaceFlags.None*/);
                }
                return $.$sris.System.Runtime.InteropServices.Marshalling.ComInterfaceMarshaller$$(T).CastIUnknownToInterfaceType(unknown);
            }
            static /*T? */ ConvertToManaged(/*void**/ unmanaged)
            {
                if (unmanaged === null)
                {
                    return $.$default(T);
                }
                return $.$cast($.$sris.System.Runtime.InteropServices.Marshalling.StrategyBasedComWrappers.DefaultMarshallingInstance.GetOrCreateObjectForComInstance($.$spc.System.IntPtr.op_Explicit$2(unmanaged), 8/*CreateObjectFlags.Unwrap*/), T);
            }
            static /*void */ Free(/*void**/ unmanaged)
            {
                if (unmanaged !== null)
                {
                    $.$spc.System.Runtime.InteropServices.Marshal.Release($.$spc.System.IntPtr.op_Explicit$2(unmanaged));
                }
            }
            static /*void* */ CastIUnknownToInterfaceType(/*nint*/ unknown)
            {
                if ($.$sris.System.Runtime.InteropServices.Marshalling.ComInterfaceMarshaller$$(T).TargetInterfaceIID === null)
                {
                    return $.$spc.System.IntPtr.op_Explicit$3(unknown);
                }
                /*nint*/ let interfacePointer;
                if ($.$spc.System.Runtime.InteropServices.Marshal.QueryInterface(unknown, $.$spc.System.Nullable.GetValueRefOrDefaultRef($.$spc.System.Guid, $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateObjectReferenceT($.$typeNullable($.$spc.System.Guid), () => $.$sris.System.Runtime.InteropServices.Marshalling.ComInterfaceMarshaller$$(T).TargetInterfaceIID, ($v) => $.$sris.System.Runtime.InteropServices.Marshalling.ComInterfaceMarshaller$$(T).TargetInterfaceIID = $v, null)), $.$ref(() => interfacePointer, ($v) => interfacePointer = $v, $.$spc.System.IntPtr)) !== 0)
                {
                    $.$spc.System.Runtime.InteropServices.Marshal.Release(unknown);
                    throw new $.$spc.System.InvalidCastException().$ctor$10((() =>
                    {
                        var $handler = new $.$spc.System.Runtime.CompilerServices.DefaultInterpolatedStringHandler().$ctor$2(2, 1);
                        $handler.AppendLiteral("Unable to cast the provided managed object to a COM interface with ID '");
                        $handler.AppendFormatted$8($.$box($.$spc.System.Nullable$$($.$spc.System.Guid).GetValueOrDefault.call($.$sris.System.Runtime.InteropServices.Marshalling.ComInterfaceMarshaller$$(T).TargetInterfaceIID), $.$spc.System.Guid), null, "B");
                        $handler.AppendLiteral("'");
                        return $handler.ToStringAndClear();
                    })());
                }
                $.$spc.System.Runtime.InteropServices.Marshal.Release(unknown);
                return $.$spc.System.IntPtr.op_Explicit$3(interfacePointer);
            }
            //Static Initializer
            static $sinit()
            {
                {
                    this.TargetInterfaceIID = ($.$sris.System.Runtime.InteropServices.Marshalling.StrategyBasedComWrappers.DefaultIUnknownInterfaceDetailsStrategy.System$Runtime$InteropServices$Marshalling$IIUnknownInterfaceDetailsStrategy$GetIUnknownDerivedDetails(T.$type.TypeHandle)?.System$Runtime$InteropServices$Marshalling$IIUnknownDerivedDetails$Iid ?? null);
                }
            }
            static $h = 2067331;
            static $g = 1;
            static $f = 0b1010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"m":[{"r":0,"p":[{"n":"managed","p":T?.$h??1507328}],"n":"ConvertToUnmanaged","d":this.$h,"h":Number(BigInt(this.$h)|0x200000000n),"f":33},{"r":T?.$h??1507328,"p":[{"n":"unmanaged","p":0}],"n":"ConvertToManaged","d":this.$h,"h":Number(BigInt(this.$h)|0x300000000n),"f":33},{"r":65537,"p":[{"n":"unmanaged","p":0}],"n":"Free","d":this.$h,"h":Number(BigInt(this.$h)|0x400000000n),"f":33},{"r":0,"p":[{"n":"unknown","p":786433}],"n":"CastIUnknownToInterfaceType","d":this.$h,"h":Number(BigInt(this.$h)|0x500000000n),"f":40}],"l":[{"t":$.$typeNullable($.$spc.System.Guid).$h,"n":"TargetInterfaceIID","d":this.$h,"h":Number(BigInt(this.$h)|0x100000000n),"f":34}],"g":[T?.$h??1507328],"r":1,"h":this.$h,"a":[{"t":115277825,"c":4410245121,"a":[{"v":"android","t":1310721}]},{"t":115277825,"c":4410245121,"a":[{"v":"browser","t":1310721}]},{"t":115277825,"c":4410245121,"a":[{"v":"ios","t":1310721}]},{"t":115277825,"c":4410245121,"a":[{"v":"tvos","t":1310721}]},{"t":23396353,"c":8613330945,"a":[{"v":false,"t":262145}]},{"t":106823681,"c":4401790977,"a":[{"v":106889217,"t":142606337},{"v":0,"t":106954753},{"v":$.$sris.System.Runtime.InteropServices.Marshalling.ComInterfaceMarshaller$$().$h,"t":142606337}]}]}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.Runtime.InteropServices.Marshalling.ComInterfaceMarshaller<${T?.$fullName}>`; }
        }));
        
        $asm.$cls("$sris.System.Runtime.InteropServices.Marshalling.ExceptionAsVoidMarshaller", ($self) => class ExceptionAsVoidMarshaller
        {
            static /*void */ ConvertToUnmanaged(/*Exception*/ e)
            {
                _ = $.$spc.System.Runtime.InteropServices.Marshal.GetHRForException(e);
            }
            static $h = 2722691;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"m":[{"r":65537,"p":[{"n":"e","p":47185921}],"n":"ConvertToUnmanaged","d":2722691,"h":4297689987,"f":33}],"h":2722691,"a":[{"t":106823681,"c":4401790977,"a":[{"v":47185921,"t":142606337},{"v":6,"t":106954753},{"v":2722691,"t":142606337}]}]}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.Runtime.InteropServices.Marshalling.ExceptionAsVoidMarshaller`; }
        });
        
        $asm.$cls("$sris.System.Runtime.InteropServices.Marshalling.ExceptionAsHResultMarshaller<>", (T) => $asm.$gt("$sris.System.Runtime.InteropServices.Marshalling.ExceptionAsHResultMarshaller<>", [T], ($self) => class ExceptionAsHResultMarshaller$$
        {
            static /*T */ ConvertToUnmanaged(/*Exception*/ e)
            {
                return T.System$Numerics$INumberBase$$$CreateTruncating($.$spc.System.Int32, $.$spc.System.Runtime.InteropServices.Marshal.GetHRForException(e));
            }
            static $h = 2591619;
            static $g = 1;
            static $f = 0b1010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"m":[{"r":T?.$h??1507328,"p":[{"n":"e","p":47185921}],"n":"ConvertToUnmanaged","d":this.$h,"h":Number(BigInt(this.$h)|0x100000000n),"f":33}],"g":[T?.$h??1507328],"s":[{"n":"T","f":10,"c":[$.$spc.System.Numerics.INumber$$(T).$h]}],"r":1,"h":this.$h,"a":[{"t":106823681,"c":4401790977,"a":[{"v":47185921,"t":142606337},{"v":6,"t":106954753},{"v":$.$sris.System.Runtime.InteropServices.Marshalling.ExceptionAsHResultMarshaller$$().$h,"t":142606337}]}]}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.Runtime.InteropServices.Marshalling.ExceptionAsHResultMarshaller<${T?.$fullName}>`; }
        }));
        
        $asm.$cls("$sris.System.Runtime.InteropServices.RuntimeEnvironment", ($self) => class RuntimeEnvironment
        {
            static /*string */ get SystemConfigurationFile()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static /*bool */ FromGlobalAccessCache(/*Assembly*/ a)
            {
                return false;
            }
            static /*string */ GetRuntimeDirectory()
            {
                /*string?*/ let runtimeDirectory = $.$spc.System.Object.$type.Assembly.Location;
                if (!$.$spc.System.IO.Path.IsPathRooted(runtimeDirectory))
                {
                    runtimeDirectory = $.$spc.System.AppDomain.CurrentDomain.BaseDirectory;
                }
                /*char*/ let sep = $.$spc.System.IO.Path.DirectorySeparatorChar;
                return $.$spc.System.String.Concat$10($.$spc.System.String.op_Implicit($.$spc.System.IO.Path.GetDirectoryName(runtimeDirectory)), new ($.$spc.System.ReadOnlySpan$$($.$spc.System.Char))().$ctor$5($.$ref(() => sep, undefined, $.$spc.System.Char)));
            }
            static /*IntPtr */ GetRuntimeInterfaceAsIntPtr(/*Guid*/ clsid, /*Guid*/ riid)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static /*object */ GetRuntimeInterfaceAsObject(/*Guid*/ clsid, /*Guid*/ riid)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static /*string */ GetSystemVersion()
            {
                return `v${$.$spc.System.Environment.Version}`;
            }
            static $h = 4033411;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":1310721,"g":{"r":0,"d":0,"h":8593968003,"f":33},"n":"SystemConfigurationFile","d":4033411,"h":4299000707,"f":33,"a":[{"t":70909953,"c":8660844545,"a":[{"v":"RuntimeEnvironment members SystemConfigurationFile, GetRuntimeInterfaceAsIntPtr, and GetRuntimeInterfaceAsObject are not supported and throw PlatformNotSupportedException.","t":1310721}],"n":[{"n":"DiagnosticId","v":"SYSLIB0019","t":1310721},{"n":"UrlFormat","v":"https://aka.ms/dotnet-warnings/{0}","t":1310721}]}]}],"m":[{"r":262145,"p":[{"n":"a","p":73465857}],"n":"FromGlobalAccessCache","d":4033411,"h":12888935299,"f":33},{"r":1310721,"n":"GetRuntimeDirectory","d":4033411,"h":17183902595,"f":33},{"r":786433,"p":[{"n":"clsid","p":56164353},{"n":"riid","p":56164353}],"n":"GetRuntimeInterfaceAsIntPtr","d":4033411,"h":21478869891,"f":33,"a":[{"t":70909953,"c":8660844545,"a":[{"v":"RuntimeEnvironment members SystemConfigurationFile, GetRuntimeInterfaceAsIntPtr, and GetRuntimeInterfaceAsObject are not supported and throw PlatformNotSupportedException.","t":1310721}],"n":[{"n":"DiagnosticId","v":"SYSLIB0019","t":1310721},{"n":"UrlFormat","v":"https://aka.ms/dotnet-warnings/{0}","t":1310721}]}]},{"r":131073,"p":[{"n":"clsid","p":56164353},{"n":"riid","p":56164353}],"n":"GetRuntimeInterfaceAsObject","d":4033411,"h":25773837187,"f":33,"a":[{"t":70909953,"c":8660844545,"a":[{"v":"RuntimeEnvironment members SystemConfigurationFile, GetRuntimeInterfaceAsIntPtr, and GetRuntimeInterfaceAsObject are not supported and throw PlatformNotSupportedException.","t":1310721}],"n":[{"n":"DiagnosticId","v":"SYSLIB0019","t":1310721},{"n":"UrlFormat","v":"https://aka.ms/dotnet-warnings/{0}","t":1310721}]}]},{"r":1310721,"n":"GetSystemVersion","d":4033411,"h":30068804483,"f":33}],"h":4033411}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.Runtime.InteropServices.RuntimeEnvironment`; }
        });
        
        $asm.$cls("$sris.System.Obsoletions", ($self) => class Obsoletions
        {
            /*string*/ static SharedUrlFormat = null;
            /*string*/ static SystemTextEncodingUTF7Message = null;
            /*string*/ static SystemTextEncodingUTF7DiagId = null;
            /*string*/ static PrincipalPermissionAttributeMessage = null;
            /*string*/ static PrincipalPermissionAttributeDiagId = null;
            /*string*/ static CodeAccessSecurityMessage = null;
            /*string*/ static CodeAccessSecurityDiagId = null;
            /*string*/ static ConstrainedExecutionRegionMessage = null;
            /*string*/ static ConstrainedExecutionRegionDiagId = null;
            /*string*/ static GlobalAssemblyCacheMessage = null;
            /*string*/ static GlobalAssemblyCacheDiagId = null;
            /*string*/ static ThreadAbortMessage = null;
            /*string*/ static ThreadResetAbortMessage = null;
            /*string*/ static ThreadAbortDiagId = null;
            /*string*/ static DefaultCryptoAlgorithmsMessage = null;
            /*string*/ static DefaultCryptoAlgorithmsDiagId = null;
            /*string*/ static CreatePdbGeneratorMessage = null;
            /*string*/ static CreatePdbGeneratorDiagId = null;
            /*string*/ static AuthenticationManagerMessage = null;
            /*string*/ static AuthenticationManagerDiagId = null;
            /*string*/ static RemotingApisMessage = null;
            /*string*/ static RemotingApisDiagId = null;
            /*string*/ static BinaryFormatterMessage = null;
            /*string*/ static BinaryFormatterDiagId = null;
            /*string*/ static CodeBaseMessage = null;
            /*string*/ static CodeBaseDiagId = null;
            /*string*/ static EscapeUriStringMessage = null;
            /*string*/ static EscapeUriStringDiagId = null;
            /*string*/ static WebRequestMessage = null;
            /*string*/ static WebRequestDiagId = null;
            /*string*/ static DisablePrivateReflectionAttributeMessage = null;
            /*string*/ static DisablePrivateReflectionAttributeDiagId = null;
            /*string*/ static GetContextInfoMessage = null;
            /*string*/ static GetContextInfoDiagId = null;
            /*string*/ static StrongNameKeyPairMessage = null;
            /*string*/ static StrongNameKeyPairDiagId = null;
            /*string*/ static ReflectionOnlyLoadingMessage = null;
            /*string*/ static ReflectionOnlyLoadingDiagId = null;
            /*string*/ static RuntimeEnvironmentMessage = null;
            /*string*/ static RuntimeEnvironmentDiagId = null;
            /*string*/ static JsonSerializerOptionsIgnoreNullValuesMessage = null;
            /*string*/ static JsonSerializerOptionsIgnoreNullValuesDiagId = null;
            /*string*/ static DerivedCryptographicTypesMessage = null;
            /*string*/ static DerivedCryptographicTypesDiagId = null;
            /*string*/ static RijndaelMessage = null;
            /*string*/ static RijndaelDiagId = null;
            /*string*/ static RNGCryptoServiceProviderMessage = null;
            /*string*/ static RNGCryptoServiceProviderDiagId = null;
            /*string*/ static AppDomainCreateUnloadMessage = null;
            /*string*/ static AppDomainCreateUnloadDiagId = null;
            /*string*/ static SuppressIldasmAttributeMessage = null;
            /*string*/ static SuppressIldasmAttributeDiagId = null;
            /*string*/ static X509CertificateImmutableMessage = null;
            /*string*/ static X509CertificateImmutableDiagId = null;
            /*string*/ static PublicKeyPropertyMessage = null;
            /*string*/ static PublicKeyPropertyDiagId = null;
            /*string*/ static X509CertificatePrivateKeyMessage = null;
            /*string*/ static X509CertificatePrivateKeyDiagId = null;
            /*string*/ static ProduceLegacyHmacValuesMessage = null;
            /*string*/ static ProduceLegacyHmacValuesDiagId = null;
            /*string*/ static UseManagedSha1Message = null;
            /*string*/ static UseManagedSha1DiagId = null;
            /*string*/ static CryptoConfigEncodeOIDMessage = null;
            /*string*/ static CryptoConfigEncodeOIDDiagId = null;
            /*string*/ static CorruptedStateRecoveryMessage = null;
            /*string*/ static CorruptedStateRecoveryDiagId = null;
            /*string*/ static Rfc2898CryptDeriveKeyMessage = null;
            /*string*/ static Rfc2898CryptDeriveKeyDiagId = null;
            /*string*/ static CmsSignerCspParamsCtorMessage = null;
            /*string*/ static CmsSignerCspParamsCtorDiagId = null;
            /*string*/ static SignerInfoCounterSigMessage = null;
            /*string*/ static SignerInfoCounterSigDiagId = null;
            /*string*/ static RegexCompileToAssemblyMessage = null;
            /*string*/ static RegexCompileToAssemblyDiagId = null;
            /*string*/ static AssemblyNameMembersMessage = null;
            /*string*/ static AssemblyNameMembersDiagId = null;
            /*string*/ static SystemDataSerializationFormatBinaryMessage = null;
            /*string*/ static SystemDataSerializationFormatBinaryDiagId = null;
            /*string*/ static TlsVersion10and11Message = null;
            /*string*/ static TlsVersion10and11DiagId = null;
            /*string*/ static EncryptionPolicyMessage = null;
            /*string*/ static EncryptionPolicyDiagId = null;
            /*string*/ static EccXmlExportImportMessage = null;
            /*string*/ static EccXmlExportImportDiagId = null;
            /*string*/ static EcDhPublicKeyBlobMessage = null;
            /*string*/ static EcDhPublicKeyBlobDiagId = null;
            /*string*/ static AssemblyNameCodeBaseMessage = null;
            /*string*/ static AssemblyNameCodeBaseDiagId = null;
            /*string*/ static CryptoStringFactoryMessage = null;
            /*string*/ static CryptoStringFactoryDiagId = null;
            /*string*/ static ControlledExecutionRunMessage = null;
            /*string*/ static ControlledExecutionRunDiagId = null;
            /*string*/ static XmlSecureResolverMessage = null;
            /*string*/ static XmlSecureResolverDiagId = null;
            /*string*/ static RsaEncryptDecryptValueMessage = null;
            /*string*/ static RsaEncryptDecryptDiagId = null;
            /*string*/ static JsonSerializerOptionsAddContextMessage = null;
            /*string*/ static JsonSerializerOptionsAddContextDiagId = null;
            /*string*/ static LegacyFormatterMessage = null;
            /*string*/ static LegacyFormatterDiagId = null;
            /*string*/ static LegacyFormatterImplMessage = null;
            /*string*/ static LegacyFormatterImplDiagId = null;
            /*string*/ static RegexExtensibilityImplMessage = null;
            /*string*/ static RegexExtensibilityDiagId = null;
            /*string*/ static AesGcmTagConstructorMessage = null;
            /*string*/ static AesGcmTagConstructorDiagId = null;
            /*string*/ static ThreadVolatileReadWriteMessage = null;
            /*string*/ static ThreadVolatileReadWriteDiagId = null;
            /*string*/ static ArmIntrinsicPerformsUnsignedOperationMessage = null;
            /*string*/ static ArmIntrinsicPerformsUnsignedOperationDiagId = null;
            /*string*/ static LoadFromHashAlgorithmMessage = null;
            /*string*/ static LoadFromHashAlgorithmDiagId = null;
            /*string*/ static X509CtorCertDataObsoleteMessage = null;
            /*string*/ static X509CtorCertDataObsoleteDiagId = null;
            /*string*/ static TlsCipherAlgorithmEnumsMessage = null;
            /*string*/ static TlsCipherAlgorithmEnumsDiagId = null;
            /*string*/ static SystemEventsEventsThreadShutdownMessage = null;
            /*string*/ static SystemEventsEventsThreadShutdownDiagId = null;
            /*string*/ static Rfc2898DeriveBytesCtorMessage = null;
            /*string*/ static Rfc2898DeriveBytesCtorDiagId = null;
            /*string*/ static QueryableMinByMaxByTSourceObsoleteMessage = null;
            /*string*/ static QueryableMinByMaxByTSourceObsoleteDiagId = null;
            /*string*/ static XsltSettingsEnableScriptMessage = null;
            /*string*/ static XsltSettingsEnableScriptDiagId = null;
            //Static Initializer
            static $sinit()
            {
                {
                    this.SharedUrlFormat = "https://aka.ms/dotnet-warnings/{0}";
                }
                {
                    this.SystemTextEncodingUTF7Message = "The UTF-7 encoding is insecure and should not be used. Consider using UTF-8 instead.";
                }
                {
                    this.SystemTextEncodingUTF7DiagId = "SYSLIB0001";
                }
                {
                    this.PrincipalPermissionAttributeMessage = "PrincipalPermissionAttribute is not honored by the runtime and must not be used.";
                }
                {
                    this.PrincipalPermissionAttributeDiagId = "SYSLIB0002";
                }
                {
                    this.CodeAccessSecurityMessage = "Code Access Security is not supported or honored by the runtime.";
                }
                {
                    this.CodeAccessSecurityDiagId = "SYSLIB0003";
                }
                {
                    this.ConstrainedExecutionRegionMessage = "The Constrained Execution Region (CER) feature is not supported.";
                }
                {
                    this.ConstrainedExecutionRegionDiagId = "SYSLIB0004";
                }
                {
                    this.GlobalAssemblyCacheMessage = "The Global Assembly Cache is not supported.";
                }
                {
                    this.GlobalAssemblyCacheDiagId = "SYSLIB0005";
                }
                {
                    this.ThreadAbortMessage = "Thread.Abort is not supported and throws PlatformNotSupportedException.";
                }
                {
                    this.ThreadResetAbortMessage = "Thread.ResetAbort is not supported and throws PlatformNotSupportedException.";
                }
                {
                    this.ThreadAbortDiagId = "SYSLIB0006";
                }
                {
                    this.DefaultCryptoAlgorithmsMessage = "The default implementation of this cryptography algorithm is not supported.";
                }
                {
                    this.DefaultCryptoAlgorithmsDiagId = "SYSLIB0007";
                }
                {
                    this.CreatePdbGeneratorMessage = "The CreatePdbGenerator API is not supported and throws PlatformNotSupportedException.";
                }
                {
                    this.CreatePdbGeneratorDiagId = "SYSLIB0008";
                }
                {
                    this.AuthenticationManagerMessage = "AuthenticationManager is not supported. Methods will no-op or throw PlatformNotSupportedException.";
                }
                {
                    this.AuthenticationManagerDiagId = "SYSLIB0009";
                }
                {
                    this.RemotingApisMessage = "This Remoting API is not supported and throws PlatformNotSupportedException.";
                }
                {
                    this.RemotingApisDiagId = "SYSLIB0010";
                }
                {
                    this.BinaryFormatterMessage = "BinaryFormatter serialization is obsolete and should not be used. See https://aka.ms/binaryformatter for more information.";
                }
                {
                    this.BinaryFormatterDiagId = "SYSLIB0011";
                }
                {
                    this.CodeBaseMessage = "Assembly.CodeBase and Assembly.EscapedCodeBase are only included for .NET Framework compatibility. Use Assembly.Location instead.";
                }
                {
                    this.CodeBaseDiagId = "SYSLIB0012";
                }
                {
                    this.EscapeUriStringMessage = "Uri.EscapeUriString can corrupt the Uri string in some cases. Consider using Uri.EscapeDataString for query string components instead.";
                }
                {
                    this.EscapeUriStringDiagId = "SYSLIB0013";
                }
                {
                    this.WebRequestMessage = "WebRequest, HttpWebRequest, ServicePoint, and WebClient are obsolete. Use HttpClient instead.";
                }
                {
                    this.WebRequestDiagId = "SYSLIB0014";
                }
                {
                    this.DisablePrivateReflectionAttributeMessage = "DisablePrivateReflectionAttribute has no effect in .NET 6.0+.";
                }
                {
                    this.DisablePrivateReflectionAttributeDiagId = "SYSLIB0015";
                }
                {
                    this.GetContextInfoMessage = "Use the Graphics.GetContextInfo overloads that accept arguments for better performance and fewer allocations.";
                }
                {
                    this.GetContextInfoDiagId = "SYSLIB0016";
                }
                {
                    this.StrongNameKeyPairMessage = "Strong name signing is not supported and throws PlatformNotSupportedException.";
                }
                {
                    this.StrongNameKeyPairDiagId = "SYSLIB0017";
                }
                {
                    this.ReflectionOnlyLoadingMessage = "ReflectionOnly loading is not supported and throws PlatformNotSupportedException.";
                }
                {
                    this.ReflectionOnlyLoadingDiagId = "SYSLIB0018";
                }
                {
                    this.RuntimeEnvironmentMessage = "RuntimeEnvironment members SystemConfigurationFile, GetRuntimeInterfaceAsIntPtr, and GetRuntimeInterfaceAsObject are not supported and throw PlatformNotSupportedException.";
                }
                {
                    this.RuntimeEnvironmentDiagId = "SYSLIB0019";
                }
                {
                    this.JsonSerializerOptionsIgnoreNullValuesMessage = "JsonSerializerOptions.IgnoreNullValues is obsolete. To ignore null values when serializing, set DefaultIgnoreCondition to JsonIgnoreCondition.WhenWritingNull.";
                }
                {
                    this.JsonSerializerOptionsIgnoreNullValuesDiagId = "SYSLIB0020";
                }
                {
                    this.DerivedCryptographicTypesMessage = "Derived cryptographic types are obsolete. Use the Create method on the base type instead.";
                }
                {
                    this.DerivedCryptographicTypesDiagId = "SYSLIB0021";
                }
                {
                    this.RijndaelMessage = "The Rijndael and RijndaelManaged types are obsolete. Use Aes instead.";
                }
                {
                    this.RijndaelDiagId = "SYSLIB0022";
                }
                {
                    this.RNGCryptoServiceProviderMessage = "RNGCryptoServiceProvider is obsolete. To generate a random number, use one of the RandomNumberGenerator static methods instead.";
                }
                {
                    this.RNGCryptoServiceProviderDiagId = "SYSLIB0023";
                }
                {
                    this.AppDomainCreateUnloadMessage = "Creating and unloading AppDomains is not supported and throws an exception.";
                }
                {
                    this.AppDomainCreateUnloadDiagId = "SYSLIB0024";
                }
                {
                    this.SuppressIldasmAttributeMessage = "SuppressIldasmAttribute has no effect in .NET 6.0+.";
                }
                {
                    this.SuppressIldasmAttributeDiagId = "SYSLIB0025";
                }
                {
                    this.X509CertificateImmutableMessage = "X509Certificate and X509Certificate2 are immutable. Use X509CertificateLoader to create a new certificate.";
                }
                {
                    this.X509CertificateImmutableDiagId = "SYSLIB0026";
                }
                {
                    this.PublicKeyPropertyMessage = "PublicKey.Key is obsolete. Use the appropriate method to get the public key, such as GetRSAPublicKey.";
                }
                {
                    this.PublicKeyPropertyDiagId = "SYSLIB0027";
                }
                {
                    this.X509CertificatePrivateKeyMessage = "X509Certificate2.PrivateKey is obsolete. Use the appropriate method to get the private key, such as GetRSAPrivateKey, or use the CopyWithPrivateKey method to create a new instance with a private key.";
                }
                {
                    this.X509CertificatePrivateKeyDiagId = "SYSLIB0028";
                }
                {
                    this.ProduceLegacyHmacValuesMessage = "ProduceLegacyHmacValues is obsolete. Producing legacy HMAC values is not supported.";
                }
                {
                    this.ProduceLegacyHmacValuesDiagId = "SYSLIB0029";
                }
                {
                    this.UseManagedSha1Message = "HMACSHA1 always uses the algorithm implementation provided by the platform. Use a constructor without the useManagedSha1 parameter.";
                }
                {
                    this.UseManagedSha1DiagId = "SYSLIB0030";
                }
                {
                    this.CryptoConfigEncodeOIDMessage = "EncodeOID is obsolete. Use the ASN.1 functionality provided in System.Formats.Asn1.";
                }
                {
                    this.CryptoConfigEncodeOIDDiagId = "SYSLIB0031";
                }
                {
                    this.CorruptedStateRecoveryMessage = "Recovery from corrupted process state exceptions is not supported; HandleProcessCorruptedStateExceptionsAttribute is ignored.";
                }
                {
                    this.CorruptedStateRecoveryDiagId = "SYSLIB0032";
                }
                {
                    this.Rfc2898CryptDeriveKeyMessage = "Rfc2898DeriveBytes.CryptDeriveKey is obsolete and is not supported. Use PasswordDeriveBytes.CryptDeriveKey instead.";
                }
                {
                    this.Rfc2898CryptDeriveKeyDiagId = "SYSLIB0033";
                }
                {
                    this.CmsSignerCspParamsCtorMessage = "CmsSigner(CspParameters) is obsolete and is not supported. Use an alternative constructor instead.";
                }
                {
                    this.CmsSignerCspParamsCtorDiagId = "SYSLIB0034";
                }
                {
                    this.SignerInfoCounterSigMessage = "ComputeCounterSignature without specifying a CmsSigner is obsolete and is not supported. Use the overload that accepts a CmsSigner.";
                }
                {
                    this.SignerInfoCounterSigDiagId = "SYSLIB0035";
                }
                {
                    this.RegexCompileToAssemblyMessage = "Regex.CompileToAssembly is obsolete and not supported. Use the GeneratedRegexAttribute with the regular expression source generator instead.";
                }
                {
                    this.RegexCompileToAssemblyDiagId = "SYSLIB0036";
                }
                {
                    this.AssemblyNameMembersMessage = "AssemblyName members HashAlgorithm, ProcessorArchitecture, and VersionCompatibility are obsolete and not supported.";
                }
                {
                    this.AssemblyNameMembersDiagId = "SYSLIB0037";
                }
                {
                    this.SystemDataSerializationFormatBinaryMessage = "SerializationFormat.Binary is obsolete and should not be used. See https://aka.ms/serializationformat-binary-obsolete for more information.";
                }
                {
                    this.SystemDataSerializationFormatBinaryDiagId = "SYSLIB0038";
                }
                {
                    this.TlsVersion10and11Message = "TLS versions 1.0 and 1.1 have known vulnerabilities and are not recommended. Use a newer TLS version instead, or use SslProtocols.None to defer to OS defaults.";
                }
                {
                    this.TlsVersion10and11DiagId = "SYSLIB0039";
                }
                {
                    this.EncryptionPolicyMessage = "EncryptionPolicy.NoEncryption and AllowEncryption significantly reduce security and should not be used in production code.";
                }
                {
                    this.EncryptionPolicyDiagId = "SYSLIB0040";
                }
                {
                    this.EccXmlExportImportMessage = "ToXmlString and FromXmlString have no implementation for ECC types, and are obsolete. Use a standard import and export format such as ExportSubjectPublicKeyInfo or ImportSubjectPublicKeyInfo for public keys and ExportPkcs8PrivateKey or ImportPkcs8PrivateKey for private keys.";
                }
                {
                    this.EccXmlExportImportDiagId = "SYSLIB0042";
                }
                {
                    this.EcDhPublicKeyBlobMessage = "ECDiffieHellmanPublicKey.ToByteArray() and the associated constructor do not have a consistent and interoperable implementation on all platforms. Use ECDiffieHellmanPublicKey.ExportSubjectPublicKeyInfo() instead.";
                }
                {
                    this.EcDhPublicKeyBlobDiagId = "SYSLIB0043";
                }
                {
                    this.AssemblyNameCodeBaseMessage = "AssemblyName.CodeBase and AssemblyName.EscapedCodeBase are obsolete. Using them for loading an assembly is not supported.";
                }
                {
                    this.AssemblyNameCodeBaseDiagId = "SYSLIB0044";
                }
                {
                    this.CryptoStringFactoryMessage = "Cryptographic factory methods accepting an algorithm name are obsolete. Use the parameterless Create factory method on the algorithm type instead.";
                }
                {
                    this.CryptoStringFactoryDiagId = "SYSLIB0045";
                }
                {
                    this.ControlledExecutionRunMessage = "ControlledExecution.Run method may corrupt the process and should not be used in production code.";
                }
                {
                    this.ControlledExecutionRunDiagId = "SYSLIB0046";
                }
                {
                    this.XmlSecureResolverMessage = "XmlSecureResolver is obsolete. Use XmlResolver.ThrowingResolver instead when attempting to forbid XML external entity resolution.";
                }
                {
                    this.XmlSecureResolverDiagId = "SYSLIB0047";
                }
                {
                    this.RsaEncryptDecryptValueMessage = "RSA.EncryptValue and DecryptValue are not supported and throw NotSupportedException. Use RSA.Encrypt and RSA.Decrypt instead.";
                }
                {
                    this.RsaEncryptDecryptDiagId = "SYSLIB0048";
                }
                {
                    this.JsonSerializerOptionsAddContextMessage = "JsonSerializerOptions.AddContext is obsolete. To register a JsonSerializerContext, use either the TypeInfoResolver or TypeInfoResolverChain properties.";
                }
                {
                    this.JsonSerializerOptionsAddContextDiagId = "SYSLIB0049";
                }
                {
                    this.LegacyFormatterMessage = "Formatter-based serialization is obsolete and should not be used.";
                }
                {
                    this.LegacyFormatterDiagId = "SYSLIB0050";
                }
                {
                    this.LegacyFormatterImplMessage = "This API supports obsolete formatter-based serialization. It should not be called or extended by application code.";
                }
                {
                    this.LegacyFormatterImplDiagId = "SYSLIB0051";
                }
                {
                    this.RegexExtensibilityImplMessage = "This API supports obsolete mechanisms for Regex extensibility. It is not supported.";
                }
                {
                    this.RegexExtensibilityDiagId = "SYSLIB0052";
                }
                {
                    this.AesGcmTagConstructorMessage = "AesGcm should indicate the required tag size for encryption and decryption. Use a constructor that accepts the tag size.";
                }
                {
                    this.AesGcmTagConstructorDiagId = "SYSLIB0053";
                }
                {
                    this.ThreadVolatileReadWriteMessage = "Thread.VolatileRead and Thread.VolatileWrite are obsolete. Use Volatile.Read or Volatile.Write respectively instead.";
                }
                {
                    this.ThreadVolatileReadWriteDiagId = "SYSLIB0054";
                }
                {
                    this.ArmIntrinsicPerformsUnsignedOperationMessage = "The underlying hardware instruction does not perform a signed saturate narrowing operation, and it always returns an unsigned result. Use the unsigned overload instead.";
                }
                {
                    this.ArmIntrinsicPerformsUnsignedOperationDiagId = "SYSLIB0055";
                }
                {
                    this.LoadFromHashAlgorithmMessage = "LoadFrom with a custom AssemblyHashAlgorithm is obsolete. Use overloads without an AssemblyHashAlgorithm.";
                }
                {
                    this.LoadFromHashAlgorithmDiagId = "SYSLIB0056";
                }
                {
                    this.X509CtorCertDataObsoleteMessage = "Loading certificate data through the constructor or Import is obsolete. Use X509CertificateLoader instead to load certificates.";
                }
                {
                    this.X509CtorCertDataObsoleteDiagId = "SYSLIB0057";
                }
                {
                    this.TlsCipherAlgorithmEnumsMessage = "KeyExchangeAlgorithm, KeyExchangeStrength, CipherAlgorithm, CipherStrength, HashAlgorithm and HashStrength properties of SslStream are obsolete. Use NegotiatedCipherSuite instead.";
                }
                {
                    this.TlsCipherAlgorithmEnumsDiagId = "SYSLIB0058";
                }
                {
                    this.SystemEventsEventsThreadShutdownMessage = "SystemEvents.EventsThreadShutdown callbacks are not run before the process exits. Use AppDomain.ProcessExit instead.";
                }
                {
                    this.SystemEventsEventsThreadShutdownDiagId = "SYSLIB0059";
                }
                {
                    this.Rfc2898DeriveBytesCtorMessage = "The constructors on Rfc2898DeriveBytes are obsolete. Use the static Pbkdf2 method instead.";
                }
                {
                    this.Rfc2898DeriveBytesCtorDiagId = "SYSLIB0060";
                }
                {
                    this.QueryableMinByMaxByTSourceObsoleteMessage = "The Queryable MinBy and MaxBy taking an IComparer<TSource> are obsolete. Use the new ones that take an IComparer<TKey>.";
                }
                {
                    this.QueryableMinByMaxByTSourceObsoleteDiagId = "SYSLIB0061";
                }
                {
                    this.XsltSettingsEnableScriptMessage = "XSLT Script blocks are not supported.";
                }
                {
                    this.XsltSettingsEnableScriptDiagId = "SYSLIB0062";
                }
            }
            static $h = 101251;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"l":[{"t":1310721,"n":"SharedUrlFormat","d":101251,"h":4295068547,"f":40},{"t":1310721,"n":"SystemTextEncodingUTF7Message","d":101251,"h":8590035843,"f":40},{"t":1310721,"n":"SystemTextEncodingUTF7DiagId","d":101251,"h":12885003139,"f":40},{"t":1310721,"n":"PrincipalPermissionAttributeMessage","d":101251,"h":17179970435,"f":40},{"t":1310721,"n":"PrincipalPermissionAttributeDiagId","d":101251,"h":21474937731,"f":40},{"t":1310721,"n":"CodeAccessSecurityMessage","d":101251,"h":25769905027,"f":40},{"t":1310721,"n":"CodeAccessSecurityDiagId","d":101251,"h":30064872323,"f":40},{"t":1310721,"n":"ConstrainedExecutionRegionMessage","d":101251,"h":34359839619,"f":40},{"t":1310721,"n":"ConstrainedExecutionRegionDiagId","d":101251,"h":38654806915,"f":40},{"t":1310721,"n":"GlobalAssemblyCacheMessage","d":101251,"h":42949774211,"f":40},{"t":1310721,"n":"GlobalAssemblyCacheDiagId","d":101251,"h":47244741507,"f":40},{"t":1310721,"n":"ThreadAbortMessage","d":101251,"h":51539708803,"f":40},{"t":1310721,"n":"ThreadResetAbortMessage","d":101251,"h":55834676099,"f":40},{"t":1310721,"n":"ThreadAbortDiagId","d":101251,"h":60129643395,"f":40},{"t":1310721,"n":"DefaultCryptoAlgorithmsMessage","d":101251,"h":64424610691,"f":40},{"t":1310721,"n":"DefaultCryptoAlgorithmsDiagId","d":101251,"h":68719577987,"f":40},{"t":1310721,"n":"CreatePdbGeneratorMessage","d":101251,"h":73014545283,"f":40},{"t":1310721,"n":"CreatePdbGeneratorDiagId","d":101251,"h":77309512579,"f":40},{"t":1310721,"n":"AuthenticationManagerMessage","d":101251,"h":81604479875,"f":40},{"t":1310721,"n":"AuthenticationManagerDiagId","d":101251,"h":85899447171,"f":40},{"t":1310721,"n":"RemotingApisMessage","d":101251,"h":90194414467,"f":40},{"t":1310721,"n":"RemotingApisDiagId","d":101251,"h":94489381763,"f":40},{"t":1310721,"n":"BinaryFormatterMessage","d":101251,"h":98784349059,"f":40},{"t":1310721,"n":"BinaryFormatterDiagId","d":101251,"h":103079316355,"f":40},{"t":1310721,"n":"CodeBaseMessage","d":101251,"h":107374283651,"f":40},{"t":1310721,"n":"CodeBaseDiagId","d":101251,"h":111669250947,"f":40},{"t":1310721,"n":"EscapeUriStringMessage","d":101251,"h":115964218243,"f":40},{"t":1310721,"n":"EscapeUriStringDiagId","d":101251,"h":120259185539,"f":40},{"t":1310721,"n":"WebRequestMessage","d":101251,"h":124554152835,"f":40},{"t":1310721,"n":"WebRequestDiagId","d":101251,"h":128849120131,"f":40},{"t":1310721,"n":"DisablePrivateReflectionAttributeMessage","d":101251,"h":133144087427,"f":40},{"t":1310721,"n":"DisablePrivateReflectionAttributeDiagId","d":101251,"h":137439054723,"f":40},{"t":1310721,"n":"GetContextInfoMessage","d":101251,"h":141734022019,"f":40},{"t":1310721,"n":"GetContextInfoDiagId","d":101251,"h":146028989315,"f":40},{"t":1310721,"n":"StrongNameKeyPairMessage","d":101251,"h":150323956611,"f":40},{"t":1310721,"n":"StrongNameKeyPairDiagId","d":101251,"h":154618923907,"f":40},{"t":1310721,"n":"ReflectionOnlyLoadingMessage","d":101251,"h":158913891203,"f":40},{"t":1310721,"n":"ReflectionOnlyLoadingDiagId","d":101251,"h":163208858499,"f":40},{"t":1310721,"n":"RuntimeEnvironmentMessage","d":101251,"h":167503825795,"f":40},{"t":1310721,"n":"RuntimeEnvironmentDiagId","d":101251,"h":171798793091,"f":40},{"t":1310721,"n":"JsonSerializerOptionsIgnoreNullValuesMessage","d":101251,"h":176093760387,"f":40},{"t":1310721,"n":"JsonSerializerOptionsIgnoreNullValuesDiagId","d":101251,"h":180388727683,"f":40},{"t":1310721,"n":"DerivedCryptographicTypesMessage","d":101251,"h":184683694979,"f":40},{"t":1310721,"n":"DerivedCryptographicTypesDiagId","d":101251,"h":188978662275,"f":40},{"t":1310721,"n":"RijndaelMessage","d":101251,"h":193273629571,"f":40},{"t":1310721,"n":"RijndaelDiagId","d":101251,"h":197568596867,"f":40},{"t":1310721,"n":"RNGCryptoServiceProviderMessage","d":101251,"h":201863564163,"f":40},{"t":1310721,"n":"RNGCryptoServiceProviderDiagId","d":101251,"h":206158531459,"f":40},{"t":1310721,"n":"AppDomainCreateUnloadMessage","d":101251,"h":210453498755,"f":40},{"t":1310721,"n":"AppDomainCreateUnloadDiagId","d":101251,"h":214748466051,"f":40},{"t":1310721,"n":"SuppressIldasmAttributeMessage","d":101251,"h":219043433347,"f":40},{"t":1310721,"n":"SuppressIldasmAttributeDiagId","d":101251,"h":223338400643,"f":40},{"t":1310721,"n":"X509CertificateImmutableMessage","d":101251,"h":227633367939,"f":40},{"t":1310721,"n":"X509CertificateImmutableDiagId","d":101251,"h":231928335235,"f":40},{"t":1310721,"n":"PublicKeyPropertyMessage","d":101251,"h":236223302531,"f":40},{"t":1310721,"n":"PublicKeyPropertyDiagId","d":101251,"h":240518269827,"f":40},{"t":1310721,"n":"X509CertificatePrivateKeyMessage","d":101251,"h":244813237123,"f":40},{"t":1310721,"n":"X509CertificatePrivateKeyDiagId","d":101251,"h":249108204419,"f":40},{"t":1310721,"n":"ProduceLegacyHmacValuesMessage","d":101251,"h":253403171715,"f":40},{"t":1310721,"n":"ProduceLegacyHmacValuesDiagId","d":101251,"h":257698139011,"f":40},{"t":1310721,"n":"UseManagedSha1Message","d":101251,"h":261993106307,"f":40},{"t":1310721,"n":"UseManagedSha1DiagId","d":101251,"h":266288073603,"f":40},{"t":1310721,"n":"CryptoConfigEncodeOIDMessage","d":101251,"h":270583040899,"f":40},{"t":1310721,"n":"CryptoConfigEncodeOIDDiagId","d":101251,"h":274878008195,"f":40},{"t":1310721,"n":"CorruptedStateRecoveryMessage","d":101251,"h":279172975491,"f":40},{"t":1310721,"n":"CorruptedStateRecoveryDiagId","d":101251,"h":283467942787,"f":40},{"t":1310721,"n":"Rfc2898CryptDeriveKeyMessage","d":101251,"h":287762910083,"f":40},{"t":1310721,"n":"Rfc2898CryptDeriveKeyDiagId","d":101251,"h":292057877379,"f":40},{"t":1310721,"n":"CmsSignerCspParamsCtorMessage","d":101251,"h":296352844675,"f":40},{"t":1310721,"n":"CmsSignerCspParamsCtorDiagId","d":101251,"h":300647811971,"f":40},{"t":1310721,"n":"SignerInfoCounterSigMessage","d":101251,"h":304942779267,"f":40},{"t":1310721,"n":"SignerInfoCounterSigDiagId","d":101251,"h":309237746563,"f":40},{"t":1310721,"n":"RegexCompileToAssemblyMessage","d":101251,"h":313532713859,"f":40},{"t":1310721,"n":"RegexCompileToAssemblyDiagId","d":101251,"h":317827681155,"f":40},{"t":1310721,"n":"AssemblyNameMembersMessage","d":101251,"h":322122648451,"f":40},{"t":1310721,"n":"AssemblyNameMembersDiagId","d":101251,"h":326417615747,"f":40},{"t":1310721,"n":"SystemDataSerializationFormatBinaryMessage","d":101251,"h":330712583043,"f":40},{"t":1310721,"n":"SystemDataSerializationFormatBinaryDiagId","d":101251,"h":335007550339,"f":40},{"t":1310721,"n":"TlsVersion10and11Message","d":101251,"h":339302517635,"f":40},{"t":1310721,"n":"TlsVersion10and11DiagId","d":101251,"h":343597484931,"f":40},{"t":1310721,"n":"EncryptionPolicyMessage","d":101251,"h":347892452227,"f":40},{"t":1310721,"n":"EncryptionPolicyDiagId","d":101251,"h":352187419523,"f":40},{"t":1310721,"n":"EccXmlExportImportMessage","d":101251,"h":356482386819,"f":40},{"t":1310721,"n":"EccXmlExportImportDiagId","d":101251,"h":360777354115,"f":40},{"t":1310721,"n":"EcDhPublicKeyBlobMessage","d":101251,"h":365072321411,"f":40},{"t":1310721,"n":"EcDhPublicKeyBlobDiagId","d":101251,"h":369367288707,"f":40},{"t":1310721,"n":"AssemblyNameCodeBaseMessage","d":101251,"h":373662256003,"f":40},{"t":1310721,"n":"AssemblyNameCodeBaseDiagId","d":101251,"h":377957223299,"f":40},{"t":1310721,"n":"CryptoStringFactoryMessage","d":101251,"h":382252190595,"f":40},{"t":1310721,"n":"CryptoStringFactoryDiagId","d":101251,"h":386547157891,"f":40},{"t":1310721,"n":"ControlledExecutionRunMessage","d":101251,"h":390842125187,"f":40},{"t":1310721,"n":"ControlledExecutionRunDiagId","d":101251,"h":395137092483,"f":40},{"t":1310721,"n":"XmlSecureResolverMessage","d":101251,"h":399432059779,"f":40},{"t":1310721,"n":"XmlSecureResolverDiagId","d":101251,"h":403727027075,"f":40},{"t":1310721,"n":"RsaEncryptDecryptValueMessage","d":101251,"h":408021994371,"f":40},{"t":1310721,"n":"RsaEncryptDecryptDiagId","d":101251,"h":412316961667,"f":40},{"t":1310721,"n":"JsonSerializerOptionsAddContextMessage","d":101251,"h":416611928963,"f":40},{"t":1310721,"n":"JsonSerializerOptionsAddContextDiagId","d":101251,"h":420906896259,"f":40},{"t":1310721,"n":"LegacyFormatterMessage","d":101251,"h":425201863555,"f":40},{"t":1310721,"n":"LegacyFormatterDiagId","d":101251,"h":429496830851,"f":40},{"t":1310721,"n":"LegacyFormatterImplMessage","d":101251,"h":433791798147,"f":40},{"t":1310721,"n":"LegacyFormatterImplDiagId","d":101251,"h":438086765443,"f":40},{"t":1310721,"n":"RegexExtensibilityImplMessage","d":101251,"h":442381732739,"f":40},{"t":1310721,"n":"RegexExtensibilityDiagId","d":101251,"h":446676700035,"f":40},{"t":1310721,"n":"AesGcmTagConstructorMessage","d":101251,"h":450971667331,"f":40},{"t":1310721,"n":"AesGcmTagConstructorDiagId","d":101251,"h":455266634627,"f":40},{"t":1310721,"n":"ThreadVolatileReadWriteMessage","d":101251,"h":459561601923,"f":40},{"t":1310721,"n":"ThreadVolatileReadWriteDiagId","d":101251,"h":463856569219,"f":40},{"t":1310721,"n":"ArmIntrinsicPerformsUnsignedOperationMessage","d":101251,"h":468151536515,"f":40},{"t":1310721,"n":"ArmIntrinsicPerformsUnsignedOperationDiagId","d":101251,"h":472446503811,"f":40},{"t":1310721,"n":"LoadFromHashAlgorithmMessage","d":101251,"h":476741471107,"f":40},{"t":1310721,"n":"LoadFromHashAlgorithmDiagId","d":101251,"h":481036438403,"f":40},{"t":1310721,"n":"X509CtorCertDataObsoleteMessage","d":101251,"h":485331405699,"f":40},{"t":1310721,"n":"X509CtorCertDataObsoleteDiagId","d":101251,"h":489626372995,"f":40},{"t":1310721,"n":"TlsCipherAlgorithmEnumsMessage","d":101251,"h":493921340291,"f":40},{"t":1310721,"n":"TlsCipherAlgorithmEnumsDiagId","d":101251,"h":498216307587,"f":40},{"t":1310721,"n":"SystemEventsEventsThreadShutdownMessage","d":101251,"h":502511274883,"f":40},{"t":1310721,"n":"SystemEventsEventsThreadShutdownDiagId","d":101251,"h":506806242179,"f":40},{"t":1310721,"n":"Rfc2898DeriveBytesCtorMessage","d":101251,"h":511101209475,"f":40},{"t":1310721,"n":"Rfc2898DeriveBytesCtorDiagId","d":101251,"h":515396176771,"f":40},{"t":1310721,"n":"QueryableMinByMaxByTSourceObsoleteMessage","d":101251,"h":519691144067,"f":40},{"t":1310721,"n":"QueryableMinByMaxByTSourceObsoleteDiagId","d":101251,"h":523986111363,"f":40},{"t":1310721,"n":"XsltSettingsEnableScriptMessage","d":101251,"h":528281078659,"f":40},{"t":1310721,"n":"XsltSettingsEnableScriptDiagId","d":101251,"h":532576045955,"f":40}],"h":101251}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.Obsoletions`; }
        });
        
        $asm.$cls("$sris.System.Security.SecureStringMarshal", ($self) => class SecureStringMarshal
        {
            static /*IntPtr */ SecureStringToCoTaskMemAnsi(/*SecureString*/ s)
            {
                return $.$spc.System.Runtime.InteropServices.Marshal.SecureStringToCoTaskMemAnsi(s);
            }
            static /*IntPtr */ SecureStringToGlobalAllocAnsi(/*SecureString*/ s)
            {
                return $.$spc.System.Runtime.InteropServices.Marshal.SecureStringToGlobalAllocAnsi(s);
            }
            static /*IntPtr */ SecureStringToCoTaskMemUnicode(/*SecureString*/ s)
            {
                return $.$spc.System.Runtime.InteropServices.Marshal.SecureStringToCoTaskMemUnicode(s);
            }
            static /*IntPtr */ SecureStringToGlobalAllocUnicode(/*SecureString*/ s)
            {
                return $.$spc.System.Runtime.InteropServices.Marshal.SecureStringToGlobalAllocUnicode(s);
            }
            static $h = 4623235;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"m":[{"r":786433,"p":[{"n":"s","p":117309441}],"n":"SecureStringToCoTaskMemAnsi","d":4623235,"h":4299590531,"f":33},{"r":786433,"p":[{"n":"s","p":117309441}],"n":"SecureStringToGlobalAllocAnsi","d":4623235,"h":8594557827,"f":33},{"r":786433,"p":[{"n":"s","p":117309441}],"n":"SecureStringToCoTaskMemUnicode","d":4623235,"h":12889525123,"f":33},{"r":786433,"p":[{"n":"s","p":117309441}],"n":"SecureStringToGlobalAllocUnicode","d":4623235,"h":17184492419,"f":33}],"h":4623235}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.Security.SecureStringMarshal`; }
        });
        
        $asm.$cls("$sris.System.Runtime.InteropServices.Marshalling.ComImportInteropInterfaceDetailsStrategy", ($self) => class ComImportInteropInterfaceDetailsStrategy extends $.$spc.System.Object
        {
            /*IIUnknownInterfaceDetailsStrategy*/ static Instance = null;
            /*ConditionalWeakTable<Type, Type>*/ _forwarderInterfaceCache = null;
            /*IComExposedDetails? */ GetComExposedTypeDetails(/*RuntimeTypeHandle*/ type)
            {
                return $.$sris.System.Runtime.InteropServices.Marshalling.DefaultIUnknownInterfaceDetailsStrategy.Instance.System$Runtime$InteropServices$Marshalling$IIUnknownInterfaceDetailsStrategy$GetComExposedTypeDetails(type);
            }
            /*IIUnknownDerivedDetails? */ GetIUnknownDerivedDetails(/*RuntimeTypeHandle*/ type)
            {
                /*Type*/ let runtimeType = $.$spc.System.Type.GetTypeFromHandle(type);
                if (!runtimeType.IsImport)
                {
                    return $.$sris.System.Runtime.InteropServices.Marshalling.DefaultIUnknownInterfaceDetailsStrategy.Instance.System$Runtime$InteropServices$Marshalling$IIUnknownInterfaceDetailsStrategy$GetIUnknownDerivedDetails(type);
                }
                /*Type*/ let implementationType = this._forwarderInterfaceCache.GetValue(runtimeType, new $.$spc.System.Runtime.CompilerServices.ConditionalWeakTable$$$($.$spc.System.Type, $.$spc.System.Type).CreateValueCallback().$ctor(this,  (/*runtimeType*/ runtimeType) =>
                {
                    /*AssemblyBuilder*/ let assembly = /*$.$spc.System.Reflection.Emit.AssemblyBuilder*/$.$spc.DeletedObject.DefineDynamicAssembly(new $.$spc.System.Reflection.AssemblyName().$ctor$1("ComImportForwarder"), runtimeType.IsCollectible ? 9/*AssemblyBuilderAccess.RunAndCollect*/ : 1/*AssemblyBuilderAccess.Run*/);
                    /*ModuleBuilder*/ let module = assembly.DefineDynamicModule("ComImportForwarder");
                    /*ConstructorInfo*/ let ignoresAccessChecksToAttributeConstructor = $.$sris.System.Runtime.InteropServices.Marshalling.ComImportInteropInterfaceDetailsStrategy.GetIgnoresAccessChecksToAttributeConstructor(module);
                    assembly.SetCustomAttribute$1(new CustomAttributeBuilder(ignoresAccessChecksToAttributeConstructor, $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$spc.System.Object), [$.$sris.System.Runtime.InteropServices.Marshalling.ComImportInteropInterfaceDetailsStrategy.IComImportAdapter.$type.Assembly.GetName().Name], [-1], null)));
                    /*TypeBuilder*/ let implementation = module.DefineType$3("InterfaceForwarder", 32/*TypeAttributes.Interface*/ | 128/*TypeAttributes.Abstract*/, null, runtimeType.GetInterfaces());
                    implementation.AddInterfaceImplementation(runtimeType);
                    implementation.SetCustomAttribute$1(new CustomAttributeBuilder($.$spc.System.Runtime.InteropServices.DynamicInterfaceCastableImplementationAttribute.$type.GetConstructor$1($.$spc.System.Array.Empty($.$spc.System.Type)), $.$spc.System.Array.Empty($.$spc.System.Object)));
                    let $i1 = 0;
                    let $arr1 = implementation.GetInterfaces();
                    while ($i1 < $arr1.length)
                    {
                        let iface = $arr1[$i1++];
                        assembly.SetCustomAttribute$1(new CustomAttributeBuilder(ignoresAccessChecksToAttributeConstructor, $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$spc.System.Object), [iface.Assembly.GetName().Name], [-1], null)));
                        let $i2 = 0;
                        let $arr2 = iface.GetMethods();
                        while ($i2 < $arr2.length)
                        {
                            let method = $arr2[$i2++];
                            /*Type[]*/ let returnTypeOptionalModifiers = method.ReturnParameter.GetOptionalCustomModifiers();
                            /*Type[]*/ let returnTypeRequiredModifiers = method.ReturnParameter.GetRequiredCustomModifiers();
                            /*ParameterInfo[]*/ let parameters = method.GetParameters();
                            /*var*/ let parameterTypes = $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$spc.System.Type), null, [parameters.length], null);
                            /*var*/ let parameterOptionalModifiers = $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$typeArray($.$spc.System.Type)), null, [parameters.length], null);
                            /*var*/ let parameterRequiredModifiers = $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$typeArray($.$spc.System.Type)), null, [parameters.length], null);
                            for(/*int*/ let i = 0; i < parameters.length; i++)
                            {
                                $.$spc.System.Array.$WriteT1.call(parameterTypes, $.$spc.System.Array.$ReadT1.call(parameters, i).ParameterType, i);
                                $.$spc.System.Array.$WriteT1.call(parameterOptionalModifiers, $.$spc.System.Array.$ReadT1.call(parameters, i).GetOptionalCustomModifiers(), i);
                                $.$spc.System.Array.$WriteT1.call(parameterRequiredModifiers, $.$spc.System.Array.$ReadT1.call(parameters, i).GetRequiredCustomModifiers(), i);
                            }
                            /*MethodBuilder*/ let builder = implementation.DefineMethod$4(method.Name, 1/*MethodAttributes.Private*/ | 32/*MethodAttributes.Final*/ | 128/*MethodAttributes.HideBySig*/ | 64/*MethodAttributes.Virtual*/, 32/*CallingConventions.HasThis*/, method.ReturnType, returnTypeRequiredModifiers, returnTypeOptionalModifiers, parameterTypes, parameterRequiredModifiers, parameterOptionalModifiers);
                            /*ILGenerator*/ let il = builder.GetILGenerator();
                            il.Emit(/*$.$spc.System.Reflection.Emit.OpCodes*/$.$spc.DeletedObject.Ldarg_0);
                            il.Emit$10(/*$.$spc.System.Reflection.Emit.OpCodes*/$.$spc.DeletedObject.Castclass, $.$sris.System.Runtime.InteropServices.Marshalling.ComImportInteropInterfaceDetailsStrategy.IComImportAdapter.$type);
                            il.Emit$7(/*$.$spc.System.Reflection.Emit.OpCodes*/$.$spc.DeletedObject.Callvirt, $.$sris.System.Runtime.InteropServices.Marshalling.ComImportInteropInterfaceDetailsStrategy.IComImportAdapter.System$Runtime$InteropServices$Marshalling$ComImportInteropInterfaceDetailsStrategy$IComImportAdapter$GetRuntimeCallableWrapperMethod);
                            il.Emit$10(/*$.$spc.System.Reflection.Emit.OpCodes*/$.$spc.DeletedObject.Castclass, iface);
                            for(/*int*/ let i = 0; i < parameters.length; i++)
                            {
                                il.Emit$6(/*$.$spc.System.Reflection.Emit.OpCodes*/$.$spc.DeletedObject.Ldarg, ((i + 1) | 0));
                            }
                            il.Emit$7(/*$.$spc.System.Reflection.Emit.OpCodes*/$.$spc.DeletedObject.Callvirt, method);
                            il.Emit(/*$.$spc.System.Reflection.Emit.OpCodes*/$.$spc.DeletedObject.Ret);
                            implementation.DefineMethodOverride(builder, method);
                        }
                    }
                    return implementation.CreateType();
                }));
                return new $.$sris.System.Runtime.InteropServices.Marshalling.ComImportInteropInterfaceDetailsStrategy.ComImportDetails().$ctor$1(runtimeType.GUID, implementationType);
            }
            /*ConstructorInfo*/ static s_attributeBaseClassCtor = null;
            /*ConstructorInfo*/ static s_attributeUsageCtor = null;
            /*PropertyInfo*/ static s_attributeUsageAllowMultipleProperty = null;
            static $_ComImportDetails;
            static get ComImportDetails()
            {
                let $cls = $.$sris.System.Runtime.InteropServices.Marshalling.ComImportInteropInterfaceDetailsStrategy;
                return $cls.$_ComImportDetails ??= $asm.$ncls("$sris.System.Runtime.InteropServices.Marshalling.ComImportInteropInterfaceDetailsStrategy.ComImportDetails", ($self) => class ComImportDetails extends $.$spc.System.Object
                {
                    /*Guid*/ Iid;
                    /*Type*/ Implementation = null;
                    /*void** */ get ManagedVirtualMethodTable()
                    {
                        return null;
                    }
                    //Generated interface implemetation for System.Runtime.InteropServices.Marshalling.IIUnknownDerivedDetails.Iid.get
                    get System$Runtime$InteropServices$Marshalling$IIUnknownDerivedDetails$Iid()
                    {
                        return this.Iid;
                    }
                    //Generated interface implemetation for System.Runtime.InteropServices.Marshalling.IIUnknownDerivedDetails.Implementation.get
                    get System$Runtime$InteropServices$Marshalling$IIUnknownDerivedDetails$Implementation()
                    {
                        return this.Implementation;
                    }
                    //Generated interface implemetation for System.Runtime.InteropServices.Marshalling.IIUnknownDerivedDetails.ManagedVirtualMethodTable.get
                    get System$Runtime$InteropServices$Marshalling$IIUnknownDerivedDetails$ManagedVirtualMethodTable()
                    {
                        return this.ManagedVirtualMethodTable;
                    }
                    //Begin primary constructor
                    /*Guid*/ iid = new $.$spc.System.Guid();
                    /*Type*/ implementation = null;
                    $ctor$1(/*Guid*/$iid, /*Type*/$implementation)
                    {
                        this.iid = $iid;
                        this.implementation = $implementation;
                        //depends on primary constructor parameter
                        this.Iid = this.iid;
                        //depends on primary constructor parameter
                        this.Implementation = this.implementation;
                        return this
                    }
                    //End primary constructor
                    static $h = 1936259;
                    static $f = 0b10000000010010000;
                    static $k = 1;
                    static $$md;
                    static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":56164353,"g":{"r":0,"d":0,"h":17181805443,"f":1},"n":"Iid","d":1936259,"h":12886838147,"f":1},{"p":142606337,"g":{"r":0,"d":0,"h":30066707331,"f":1},"n":"Implementation","d":1936259,"h":25771740035,"f":1},{"p":0,"g":{"r":0,"d":0,"h":38656641923,"f":1},"n":"ManagedVirtualMethodTable","d":1936259,"h":34361674627,"f":1}],"c":[{"p":[{"n":"iid","p":56164353},{"n":"implementation","p":142606337}],"n":".ctor","o":"$ctor$1","d":1936259,"h":4296903555,"f":1}],"i":[3246979],"d":1870723,"h":1936259}; }
                    static get $b() { return $.$spc.System.Object; }
                    static $$i;
                    static get $i() { return this.$$i ??= [ $.$sris.System.Runtime.InteropServices.Marshalling.IIUnknownDerivedDetails ]; }
                    static get $fullName() { return `System.Runtime.InteropServices.Marshalling.ComImportInteropInterfaceDetailsStrategy.ComImportDetails`; }
                }, $cls, ($v) => $cls.$_ComImportDetails = $v);
            }
            static $_IComImportAdapter;
            static get IComImportAdapter()
            {
                let $cls = $.$sris.System.Runtime.InteropServices.Marshalling.ComImportInteropInterfaceDetailsStrategy;
                return $cls.$_IComImportAdapter ??= $asm.$ncls("$sris.System.Runtime.InteropServices.Marshalling.ComImportInteropInterfaceDetailsStrategy.IComImportAdapter", ($self) => class IComImportAdapter
                {
                    /*MethodInfo*/ static System$Runtime$InteropServices$Marshalling$ComImportInteropInterfaceDetailsStrategy$IComImportAdapter$GetRuntimeCallableWrapperMethod = null;
                    //Static Initializer
                    static $sinit()
                    {
                        {
                            this.System$Runtime$InteropServices$Marshalling$ComImportInteropInterfaceDetailsStrategy$IComImportAdapter$GetRuntimeCallableWrapperMethod = $.$sris.System.Runtime.InteropServices.Marshalling.ComImportInteropInterfaceDetailsStrategy.IComImportAdapter.$type.GetMethod$1("GetRuntimeCallableWrapper");
                        }
                    }
                    static $h = 2001795;
                    static $f = 0b10000000000100100;
                    static $k = 3;
                    static $$md;
                    static get $md() { return this.$$md ??= {"m":[{"r":131073,"n":"GetRuntimeCallableWrapper","o":"System$Runtime$InteropServices$Marshalling$ComImportInteropInterfaceDetailsStrategy$IComImportAdapter$GetRuntimeCallableWrapper","d":2001795,"h":8591936387,"f":257}],"l":[{"t":79626241,"n":"GetRuntimeCallableWrapperMethod","o":"System$Runtime$InteropServices$Marshalling$ComImportInteropInterfaceDetailsStrategy$IComImportAdapter$GetRuntimeCallableWrapperMethod","d":2001795,"h":4296969091,"f":40}],"d":1870723,"h":2001795}; }
                    static get $fullName() { return `System.Runtime.InteropServices.Marshalling.ComImportInteropInterfaceDetailsStrategy.IComImportAdapter`; }
                }, $cls, ($v) => $cls.$_IComImportAdapter = $v);
            }
            //Generated interface implemetation for System.Runtime.InteropServices.Marshalling.IIUnknownInterfaceDetailsStrategy.GetIUnknownDerivedDetails(System.RuntimeTypeHandle)
            System$Runtime$InteropServices$Marshalling$IIUnknownInterfaceDetailsStrategy$GetIUnknownDerivedDetails()
            {
                return this.GetIUnknownDerivedDetails(...arguments);
            }
            //Generated interface implemetation for System.Runtime.InteropServices.Marshalling.IIUnknownInterfaceDetailsStrategy.GetComExposedTypeDetails(System.RuntimeTypeHandle)
            System$Runtime$InteropServices$Marshalling$IIUnknownInterfaceDetailsStrategy$GetComExposedTypeDetails()
            {
                return this.GetComExposedTypeDetails(...arguments);
            }
            //default reference type constructor overload
            $ctor$1()
            {
                super.$ctor();
                return this;
            }
            //default member initializer
            constructor()
            {
                super();
                this._forwarderInterfaceCache = new ($.$spc.System.Runtime.CompilerServices.ConditionalWeakTable$$$($.$spc.System.Type, $.$spc.System.Type))().$ctor$1();
            }
            //Static Initializer
            static $sinit()
            {
                {
                    this.Instance = new $.$sris.System.Runtime.InteropServices.Marshalling.ComImportInteropInterfaceDetailsStrategy().$ctor$1();
                }
                {
                    this.s_attributeBaseClassCtor = $.$spc.System.Array.$ReadT1.call($.$spc.System.Attribute.$type.GetConstructors$1(32/*BindingFlags.NonPublic*/ | 4/*BindingFlags.Instance*/), 0);
                }
                {
                    this.s_attributeUsageCtor = $.$spc.System.AttributeUsageAttribute.$type.GetConstructor$1($.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$spc.System.Type), [$.$spc.System.AttributeTargets.$type], [-1], null));
                }
                {
                    this.s_attributeUsageAllowMultipleProperty = $.$spc.System.AttributeUsageAttribute.$type.GetProperty("AllowMultiple");
                }
            }
            static $h = 1870723;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"m":[{"r":3050371,"p":[{"n":"type","p":116064257}],"n":"GetComExposedTypeDetails","d":1870723,"h":12886772611,"f":1},{"r":3246979,"p":[{"n":"type","p":116064257}],"n":"GetIUnknownDerivedDetails","d":1870723,"h":17181739907,"f":1},{"r":75628545,"p":[{"n":"moduleBuilder"}],"n":"GetIgnoresAccessChecksToAttributeConstructor","d":1870723,"h":21476707203,"f":34},{"r":142606337,"p":[{"n":"moduleBuilder"}],"n":"EmitIgnoresAccessChecksToAttribute","d":1870723,"h":25771674499,"f":34}],"l":[{"t":3312515,"n":"Instance","d":1870723,"h":4296838019,"f":33},{"t":$.$spc.System.Runtime.CompilerServices.ConditionalWeakTable$$$($.$spc.System.Type, $.$spc.System.Type).$h,"n":"_forwarderInterfaceCache","d":1870723,"h":8591805315,"f":2},{"t":75628545,"n":"s_attributeBaseClassCtor","d":1870723,"h":30066641795,"f":34},{"t":75628545,"n":"s_attributeUsageCtor","d":1870723,"h":34361609091,"f":34},{"t":81657857,"n":"s_attributeUsageAllowMultipleProperty","d":1870723,"h":38656576387,"f":34}],"c":[{"n":".ctor","o":"$ctor$1","d":1870723,"h":51541478275,"f":1}],"i":[3312515],"j":[1936259,2001795],"h":1870723}; }
            static get $b() { return $.$spc.System.Object; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$sris.System.Runtime.InteropServices.Marshalling.IIUnknownInterfaceDetailsStrategy ]; }
            static get $fullName() { return `System.Runtime.InteropServices.Marshalling.ComImportInteropInterfaceDetailsStrategy`; }
        });
        
        $asm.$cls("$sris.System.Runtime.InteropServices.Marshalling.DefaultCaching", ($self) => class DefaultCaching extends $.$spc.System.Object
        {
            /*ConcurrentDictionary<RuntimeTypeHandle, IIUnknownCacheStrategy.TableInfo>*/ _cache = null;
            /*IIUnknownCacheStrategy.TableInfo */ System$Runtime$InteropServices$Marshalling$IIUnknownCacheStrategy$ConstructTableInfo(/*RuntimeTypeHandle*/ handle, /*IIUnknownDerivedDetails*/ details, /*void**/ ptr)
            {
                /*var*/ let obj = $.$cast(ptr, $.$typePointer($.$typePointer($.$typePointer($.$spc.System.Void))));
                return (() =>
                {
                    //new $.$sris.System.Runtime.InteropServices.Marshalling.IIUnknownCacheStrategy.TableInfo()
                    const $t1 = $.$sris.System.Runtime.InteropServices.Marshalling.IIUnknownCacheStrategy.TableInfo;
                    const $i1 = new $t1();
                    $i1.ThisPtr = obj;
                    $i1.Table = obj.$v;
                    $i1.ManagedType = details.System$Runtime$InteropServices$Marshalling$IIUnknownDerivedDetails$Implementation.TypeHandle;
                    return $i1;
                })();
            }
            /*bool */ System$Runtime$InteropServices$Marshalling$IIUnknownCacheStrategy$TryGetTableInfo(/*RuntimeTypeHandle*/ handle, /*out IIUnknownCacheStrategy.TableInfo*/ info)
            {
                return this._cache.TryGetValue(handle, info);
            }
            /*bool */ System$Runtime$InteropServices$Marshalling$IIUnknownCacheStrategy$TrySetTableInfo(/*RuntimeTypeHandle*/ handle, /*IIUnknownCacheStrategy.TableInfo*/ info)
            {
                return this._cache.TryAdd(handle, info);
            }
            /*void */ System$Runtime$InteropServices$Marshalling$IIUnknownCacheStrategy$Clear(/*IIUnknownStrategy*/ unknownStrategy)
            {
                var $en2 = this._cache.Values.System$Collections$Generic$IEnumerable$$$GetEnumerator();
                while ($en2.System$Collections$IEnumerator$MoveNext())
                {
                    var info = $en2.System$Collections$Generic$IEnumerator$$$Current;
                    {
                        _ = unknownStrategy.System$Runtime$InteropServices$Marshalling$IIUnknownStrategy$Release(info.ThisPtr);
                    }
                }
                this._cache.Clear();
            }
            //default reference type constructor overload
            $ctor$1()
            {
                super.$ctor();
                return this;
            }
            //default member initializer
            constructor()
            {
                super();
                this._cache = new ($.$scc.System.Collections.Concurrent.ConcurrentDictionary$$$($.$spc.System.RuntimeTypeHandle, $.$sris.System.Runtime.InteropServices.Marshalling.IIUnknownCacheStrategy.TableInfo))().$ctor$2(1, 16);
            }
            static $h = 2395011;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"l":[{"t":$.$scc.System.Collections.Concurrent.ConcurrentDictionary$$$($.$spc.System.RuntimeTypeHandle, $.$sris.System.Runtime.InteropServices.Marshalling.IIUnknownCacheStrategy.TableInfo).$h,"n":"_cache","d":2395011,"h":4297362307,"f":2}],"c":[{"n":".ctor","o":"$ctor$1","d":2395011,"h":25772198787,"f":1}],"i":[3115907],"h":2395011}; }
            static get $b() { return $.$spc.System.Object; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$sris.System.Runtime.InteropServices.Marshalling.IIUnknownCacheStrategy ]; }
            static get $fullName() { return `System.Runtime.InteropServices.Marshalling.DefaultCaching`; }
        });
        
        $asm.$cls("$sris.System.Runtime.InteropServices.Marshalling.FreeThreadedStrategy", ($self) => class FreeThreadedStrategy extends $.$spc.System.Object
        {
            /*IIUnknownStrategy*/ static Instance = null;
            /*void* */ System$Runtime$InteropServices$Marshalling$IIUnknownStrategy$CreateInstancePointer(/*void**/ unknown)
            {
                $.$spc.System.Runtime.InteropServices.Marshal.AddRef($.$spc.System.IntPtr.op_Explicit$2(unknown));
                return unknown;
            }
            /*int */ System$Runtime$InteropServices$Marshalling$IIUnknownStrategy$QueryInterface(/*void**/ thisPtr, /*in Guid*/ handle, /*out void**/ ppObj)
            {
                /*nint*/ let ppv;
                /*int*/ let hr = $.$spc.System.Runtime.InteropServices.Marshal.QueryInterface($.$spc.System.IntPtr.op_Explicit$2(thisPtr), handle, $.$ref(() => ppv, ($v) => ppv = $v, $.$spc.System.IntPtr));
                if (hr < 0)
                {
                    ppObj.$v = null;
                }
                else 
                {
                    ppObj.$v = $.$spc.System.IntPtr.op_Explicit$3(ppv);
                }
                return hr;
            }
            /*int */ System$Runtime$InteropServices$Marshalling$IIUnknownStrategy$Release(/*void**/ thisPtr)
            {
                return $.$spc.System.Runtime.InteropServices.Marshal.Release($.$spc.System.IntPtr.op_Explicit$2(thisPtr));
            }
            //default reference type constructor overload
            $ctor$1()
            {
                super.$ctor();
                return this;
            }
            //Static Initializer
            static $sinit()
            {
                {
                    this.Instance = new $.$sris.System.Runtime.InteropServices.Marshalling.FreeThreadedStrategy().$ctor$1();
                }
            }
            static $h = 2788227;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"l":[{"t":3443587,"n":"Instance","d":2788227,"h":4297755523,"f":33}],"c":[{"n":".ctor","o":"$ctor$1","d":2788227,"h":21477624707,"f":1}],"i":[3443587],"h":2788227}; }
            static get $b() { return $.$spc.System.Object; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$sris.System.Runtime.InteropServices.Marshalling.IIUnknownStrategy ]; }
            static get $fullName() { return `System.Runtime.InteropServices.Marshalling.FreeThreadedStrategy`; }
        });
        
        $asm.$cls("$sris.System.Runtime.InteropServices.Marshalling.DefaultIUnknownInterfaceDetailsStrategy", ($self) => class DefaultIUnknownInterfaceDetailsStrategy extends $.$spc.System.Object
        {
            /*IIUnknownInterfaceDetailsStrategy*/ static Instance = null;
            /*IComExposedDetails? */ GetComExposedTypeDetails(/*RuntimeTypeHandle*/ type)
            {
                return $.$sris.System.Runtime.InteropServices.Marshalling.IComExposedDetails.System$Runtime$InteropServices$Marshalling$IComExposedDetails$GetFromAttribute(type);
            }
            /*IIUnknownDerivedDetails? */ GetIUnknownDerivedDetails(/*RuntimeTypeHandle*/ type)
            {
                return $.$sris.System.Runtime.InteropServices.Marshalling.IIUnknownDerivedDetails.System$Runtime$InteropServices$Marshalling$IIUnknownDerivedDetails$GetFromAttribute(type);
            }
            //Generated interface implemetation for System.Runtime.InteropServices.Marshalling.IIUnknownInterfaceDetailsStrategy.GetIUnknownDerivedDetails(System.RuntimeTypeHandle)
            System$Runtime$InteropServices$Marshalling$IIUnknownInterfaceDetailsStrategy$GetIUnknownDerivedDetails()
            {
                return this.GetIUnknownDerivedDetails(...arguments);
            }
            //Generated interface implemetation for System.Runtime.InteropServices.Marshalling.IIUnknownInterfaceDetailsStrategy.GetComExposedTypeDetails(System.RuntimeTypeHandle)
            System$Runtime$InteropServices$Marshalling$IIUnknownInterfaceDetailsStrategy$GetComExposedTypeDetails()
            {
                return this.GetComExposedTypeDetails(...arguments);
            }
            //default reference type constructor overload
            $ctor$1()
            {
                super.$ctor();
                return this;
            }
            //Static Initializer
            static $sinit()
            {
                {
                    this.Instance = new $.$sris.System.Runtime.InteropServices.Marshalling.DefaultIUnknownInterfaceDetailsStrategy().$ctor$1();
                }
            }
            static $h = 2460547;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"m":[{"r":3050371,"p":[{"n":"type","p":116064257}],"n":"GetComExposedTypeDetails","d":2460547,"h":8592395139,"f":1},{"r":3246979,"p":[{"n":"type","p":116064257}],"n":"GetIUnknownDerivedDetails","d":2460547,"h":12887362435,"f":1}],"l":[{"t":3312515,"n":"Instance","d":2460547,"h":4297427843,"f":33}],"c":[{"n":".ctor","o":"$ctor$1","d":2460547,"h":17182329731,"f":1}],"i":[3312515],"h":2460547}; }
            static get $b() { return $.$spc.System.Object; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$sris.System.Runtime.InteropServices.Marshalling.IIUnknownInterfaceDetailsStrategy ]; }
            static get $fullName() { return `System.Runtime.InteropServices.Marshalling.DefaultIUnknownInterfaceDetailsStrategy`; }
        });
        
        $asm.$str("$sris.System.Runtime.InteropServices.ComTypes.FORMATETC", ($self) => class FORMATETC extends $.$spc.System.ValueType
        {
            /*short*/  get cfFormat() { return this.$getField(0, $.$spc.System.Int16); }
            /*short*/  set cfFormat(value) { this.$setField(0, $.$spc.System.Int16, value); }
            /*IntPtr*/  get ptd() { return this.$getField(2, $.$spc.System.IntPtr); }
            /*IntPtr*/  set ptd(value) { this.$setField(2, $.$spc.System.IntPtr, value); }
            /*DVASPECT*/  get dwAspect() { return this.$getField(6, $.$sris.System.Runtime.InteropServices.ComTypes.DVASPECT); }
            /*DVASPECT*/  set dwAspect(value) { this.$setField(6, $.$sris.System.Runtime.InteropServices.ComTypes.DVASPECT, value); }
            /*int*/  get lindex() { return this.$getField(10, $.$spc.System.Int32); }
            /*int*/  set lindex(value) { this.$setField(10, $.$spc.System.Int32, value); }
            /*TYMED*/  get tymed() { return this.$getField(14, $.$sris.System.Runtime.InteropServices.ComTypes.TYMED); }
            /*TYMED*/  set tymed(value) { this.$setField(14, $.$sris.System.Runtime.InteropServices.ComTypes.TYMED, value); }
            //default value type constructor
            $ctor$2()
            {
                return this;
            }
            Clone($copy)
            {
                let copy = $copy ?? new this.constructor();
                copy.cfFormat = this.cfFormat;
                copy.ptd = this.ptd;
                copy.dwAspect = this.dwAspect;
                copy.lindex = this.lindex;
                copy.tymed = this.tymed;
                return copy;
            }
            //default member initializer
            constructor()
            {
                super();
                this.cfFormat = 0;
                this.ptd = 0;
                this.dwAspect = 0;
                this.lindex = 0;
                this.tymed = 0;
            }
            static $h = 953219;
            static $z = 18;
            static $f = 0b10000000000001010000001;
            static $k = 2;
            static $$md;
            static get $md() { return this.$$md ??= {"b":196609,"l":[{"t":524289,"n":"cfFormat","d":953219,"h":4295920515,"f":1,"a":[{"t":105709569,"c":8695644161,"a":[{"v":6,"t":110886913}]}]},{"t":786433,"n":"ptd","d":953219,"h":8590887811,"f":1},{"t":887683,"n":"dwAspect","d":953219,"h":12885855107,"f":1,"a":[{"t":105709569,"c":8695644161,"a":[{"v":8,"t":110886913}]}]},{"t":655361,"n":"lindex","d":953219,"h":17180822403,"f":1},{"t":1411971,"n":"tymed","d":953219,"h":21475789699,"f":1,"a":[{"t":105709569,"c":8695644161,"a":[{"v":8,"t":110886913}]}]}],"c":[{"n":".ctor","o":"$ctor$2","d":953219,"h":25770756995,"f":1}],"h":953219,"a":[{"t":33161217,"c":4328128513,"a":[{"v":1,"t":33226753}]}]}; }
            static get $b() { return $.$spc.System.ValueType; }
            static get $fullName() { return `System.Runtime.InteropServices.ComTypes.FORMATETC`; }
        });
        
        $asm.$str("$sris.System.Runtime.InteropServices.ComTypes.STATDATA", ($self) => class STATDATA extends $.$spc.System.ValueType
        {
            /*FORMATETC*/  get formatetc() { return this.$getField(0, 18); }
            /*FORMATETC*/  set formatetc(value) { this.$setField(0, 18, value); }
            /*ADVF*/  get advf() { return this.$getField(18, 4); }
            /*ADVF*/  set advf(value) { this.$setField(18, 4, value); }
            /*IAdviseSink*/  get advSink() { return this.$getField(22, 4); }
            /*IAdviseSink*/  set advSink(value) { this.$setField(22, 4, value); }
            /*int*/  get connection() { return this.$getField(26, 4); }
            /*int*/  set connection(value) { this.$setField(26, 4, value); }
            //default value type constructor
            $ctor$2()
            {
                return this;
            }
            Clone($copy)
            {
                let copy = $copy ?? new this.constructor();
                copy.formatetc = this.formatetc.Clone();
                copy.advf = this.advf;
                copy.advSink = this.advSink;
                copy.connection = this.connection;
                return copy;
            }
            //default member initializer
            constructor()
            {
                super();
                this.formatetc = $.$default($.$sris.System.Runtime.InteropServices.ComTypes.FORMATETC);
                this.advf = 0;
                this.advSink = null;
                this.connection = 0;
            }
            static $h = 1280899;
            static $z = 30;
            static $f = 0b1010000001;
            static $k = 2;
            static $$md;
            static get $md() { return this.$$md ??= {"b":196609,"l":[{"t":953219,"n":"formatetc","d":1280899,"h":4296248195,"f":1},{"t":756611,"n":"advf","d":1280899,"h":8591215491,"f":1},{"t":1018755,"n":"advSink","d":1280899,"h":12886182787,"f":1},{"t":655361,"n":"connection","d":1280899,"h":17181150083,"f":1}],"c":[{"n":".ctor","o":"$ctor$2","d":1280899,"h":21476117379,"f":1}],"h":1280899,"a":[{"t":33161217,"c":4328128513,"a":[{"v":1,"t":33226753}]}]}; }
            static get $b() { return $.$spc.System.ValueType; }
            static get $fullName() { return `System.Runtime.InteropServices.ComTypes.STATDATA`; }
        });
        
        $asm.$cls("$sris.System.Runtime.InteropServices.AutomationProxyAttribute", ($self) => class AutomationProxyAttribute extends $.$spc.System.Attribute
        {
            $ctor$2(/*bool*/ val)
            {
                super.$ctor$1();
                this.Value = val;
                return this;
            }
            /*bool*/ Value = false;
            //default member initializer
            constructor()
            {
                super();
                this.Value = false;
            }
            static $h = 363395;
            static $f = 0b10010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":14483457,"p":[{"p":262145,"g":{"r":0,"d":0,"h":17180232579,"f":1},"n":"Value","d":363395,"h":12885265283,"f":1}],"c":[{"p":[{"n":"val","p":262145}],"n":".ctor","o":"$ctor$2","d":363395,"h":4295330691,"f":1}],"h":363395,"a":[{"t":14614529,"c":21489451009,"a":[{"v":1029,"t":14548993}],"n":[{"n":"Inherited","v":false,"t":262145}]}]}; }
            static get $b() { return $.$spc.System.Attribute; }
            static get $fullName() { return `System.Runtime.InteropServices.AutomationProxyAttribute`; }
        });
        
        $asm.$cls("$sris.System.Runtime.InteropServices.ComConversionLossAttribute", ($self) => class ComConversionLossAttribute extends $.$spc.System.Attribute
        {
            //default reference type constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                return this;
            }
            static $h = 625539;
            static $f = 0b10010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":14483457,"c":[{"n":".ctor","o":"$ctor$2","d":625539,"h":4295592835,"f":1}],"h":625539,"a":[{"t":14614529,"c":21489451009,"a":[{"v":32767,"t":14548993}],"n":[{"n":"Inherited","v":false,"t":262145}]}]}; }
            static get $b() { return $.$spc.System.Attribute; }
            static get $fullName() { return `System.Runtime.InteropServices.ComConversionLossAttribute`; }
        });
        
        $asm.$str("$sris.System.Runtime.InteropServices.ComTypes.STGMEDIUM", ($self) => class STGMEDIUM extends $.$spc.System.ValueType
        {
            /*TYMED*/  get tymed() { return this.$getField(0, 4); }
            /*TYMED*/  set tymed(value) { this.$setField(0, 4, value); }
            /*IntPtr*/  get unionmember() { return this.$getField(4, 4); }
            /*IntPtr*/  set unionmember(value) { this.$setField(4, 4, value); }
            /*object?*/  get pUnkForRelease() { return this.$getField(8, 4); }
            /*object?*/  set pUnkForRelease(value) { this.$setField(8, 4, value); }
            //default value type constructor
            $ctor$2()
            {
                return this;
            }
            Clone($copy)
            {
                let copy = $copy ?? new this.constructor();
                copy.tymed = this.tymed;
                copy.unionmember = this.unionmember;
                copy.pUnkForRelease = this.pUnkForRelease;
                return copy;
            }
            //default member initializer
            constructor()
            {
                super();
                this.tymed = 0;
                this.unionmember = 0;
                this.pUnkForRelease = null;
            }
            static $h = 1346435;
            static $z = 12;
            static $f = 0b1010000001;
            static $k = 2;
            static $$md;
            static get $md() { return this.$$md ??= {"b":196609,"l":[{"t":1411971,"n":"tymed","d":1346435,"h":4296313731,"f":1},{"t":786433,"n":"unionmember","d":1346435,"h":8591281027,"f":1},{"t":131073,"n":"pUnkForRelease","d":1346435,"h":12886248323,"f":1,"a":[{"t":105709569,"c":8695644161,"a":[{"v":25,"t":110886913}]}]}],"c":[{"n":".ctor","o":"$ctor$2","d":1346435,"h":17181215619,"f":1}],"h":1346435,"a":[{"t":33161217,"c":4328128513,"a":[{"v":1,"t":33226753}]}]}; }
            static get $b() { return $.$spc.System.ValueType; }
            static get $fullName() { return `System.Runtime.InteropServices.ComTypes.STGMEDIUM`; }
        });
        
        $asm.$cls("$sris.System.Runtime.InteropServices.ComAliasNameAttribute", ($self) => class ComAliasNameAttribute extends $.$spc.System.Attribute
        {
            $ctor$2(/*string*/ alias)
            {
                super.$ctor$1();
                this.Value = alias;
                return this;
            }
            /*string*/ Value = null;
            static $h = 428931;
            static $f = 0b10010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":14483457,"p":[{"p":1310721,"g":{"r":0,"d":0,"h":17180298115,"f":1},"n":"Value","d":428931,"h":12885330819,"f":1}],"c":[{"p":[{"n":"alias","p":1310721}],"n":".ctor","o":"$ctor$2","d":428931,"h":4295396227,"f":1}],"h":428931,"a":[{"t":14614529,"c":21489451009,"a":[{"v":10624,"t":14548993}],"n":[{"n":"Inherited","v":false,"t":262145}]}]}; }
            static get $b() { return $.$spc.System.Attribute; }
            static get $fullName() { return `System.Runtime.InteropServices.ComAliasNameAttribute`; }
        });
        
        $asm.$cls("$sris.System.Runtime.InteropServices.ComCompatibleVersionAttribute", ($self) => class ComCompatibleVersionAttribute extends $.$spc.System.Attribute
        {
            $ctor$2(/*int*/ major, /*int*/ minor, /*int*/ build, /*int*/ revision)
            {
                super.$ctor$1();
                {
                    this.MajorVersion = major;
                    this.MinorVersion = minor;
                    this.BuildNumber = build;
                    this.RevisionNumber = revision;
                }
                return this;
            }
            /*int*/ MajorVersion = 0;
            /*int*/ MinorVersion = 0;
            /*int*/ BuildNumber = 0;
            /*int*/ RevisionNumber = 0;
            static $h = 560003;
            static $f = 0b10010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":14483457,"p":[{"p":655361,"g":{"r":0,"d":0,"h":17180429187,"f":1},"n":"MajorVersion","d":560003,"h":12885461891,"f":1},{"p":655361,"g":{"r":0,"d":0,"h":30065331075,"f":1},"n":"MinorVersion","d":560003,"h":25770363779,"f":1},{"p":655361,"g":{"r":0,"d":0,"h":42950232963,"f":1},"n":"BuildNumber","d":560003,"h":38655265667,"f":1},{"p":655361,"g":{"r":0,"d":0,"h":55835134851,"f":1},"n":"RevisionNumber","d":560003,"h":51540167555,"f":1}],"c":[{"p":[{"n":"major","p":655361},{"n":"minor","p":655361},{"n":"build","p":655361},{"n":"revision","p":655361}],"n":".ctor","o":"$ctor$2","d":560003,"h":4295527299,"f":1}],"h":560003,"a":[{"t":14614529,"c":21489451009,"a":[{"v":1,"t":14548993}],"n":[{"n":"Inherited","v":false,"t":262145}]}]}; }
            static get $b() { return $.$spc.System.Attribute; }
            static get $fullName() { return `System.Runtime.InteropServices.ComCompatibleVersionAttribute`; }
        });
        
        $asm.$cls("$sris.System.Runtime.InteropServices.ComRegisterFunctionAttribute", ($self) => class ComRegisterFunctionAttribute extends $.$spc.System.Attribute
        {
            //default reference type constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                return this;
            }
            static $h = 691075;
            static $f = 0b10010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":14483457,"c":[{"n":".ctor","o":"$ctor$2","d":691075,"h":4295658371,"f":1}],"h":691075,"a":[{"t":14614529,"c":21489451009,"a":[{"v":64,"t":14548993}],"n":[{"n":"Inherited","v":false,"t":262145}]}]}; }
            static get $b() { return $.$spc.System.Attribute; }
            static get $fullName() { return `System.Runtime.InteropServices.ComRegisterFunctionAttribute`; }
        });
        
        $asm.$cls("$sris.System.Runtime.InteropServices.ComUnregisterFunctionAttribute", ($self) => class ComUnregisterFunctionAttribute extends $.$spc.System.Attribute
        {
            //default reference type constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                return this;
            }
            static $h = 1477507;
            static $f = 0b10010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":14483457,"c":[{"n":".ctor","o":"$ctor$2","d":1477507,"h":4296444803,"f":1}],"h":1477507,"a":[{"t":14614529,"c":21489451009,"a":[{"v":64,"t":14548993}],"n":[{"n":"Inherited","v":false,"t":262145}]}]}; }
            static get $b() { return $.$spc.System.Attribute; }
            static get $fullName() { return `System.Runtime.InteropServices.ComUnregisterFunctionAttribute`; }
        });
        
        $asm.$cls("$sris.System.Runtime.InteropServices.ManagedToNativeComInteropStubAttribute", ($self) => class ManagedToNativeComInteropStubAttribute extends $.$spc.System.Attribute
        {
            $ctor$2(/*Type*/ classType, /*string*/ methodName)
            {
                super.$ctor$1();
                {
                    this.ClassType = classType;
                    this.MethodName = methodName;
                }
                return this;
            }
            /*Type*/ ClassType = null;
            /*string*/ MethodName = null;
            static $h = 1739651;
            static $f = 0b10010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":14483457,"p":[{"p":142606337,"g":{"r":0,"d":0,"h":17181608835,"f":1},"n":"ClassType","d":1739651,"h":12886641539,"f":1},{"p":1310721,"g":{"r":0,"d":0,"h":30066510723,"f":1},"n":"MethodName","d":1739651,"h":25771543427,"f":1}],"c":[{"p":[{"n":"classType","p":142606337},{"n":"methodName","p":1310721}],"n":".ctor","o":"$ctor$2","d":1739651,"h":4296706947,"f":1}],"h":1739651,"a":[{"t":14614529,"c":21489451009,"a":[{"v":64,"t":14548993}],"n":[{"n":"Inherited","v":false,"t":262145},{"n":"AllowMultiple","v":false,"t":262145}]}]}; }
            static get $b() { return $.$spc.System.Attribute; }
            static get $fullName() { return `System.Runtime.InteropServices.ManagedToNativeComInteropStubAttribute`; }
        });
        
        $asm.$cls("$sris.System.Runtime.InteropServices.Marshalling.GeneratedComClassAttribute", ($self) => class GeneratedComClassAttribute extends $.$spc.System.Attribute
        {
            //default reference type constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                return this;
            }
            static $h = 2853763;
            static $f = 0b10010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":14483457,"c":[{"n":".ctor","o":"$ctor$2","d":2853763,"h":4297821059,"f":1}],"h":2853763,"a":[{"t":14614529,"c":21489451009,"a":[{"v":4,"t":14548993}]}]}; }
            static get $b() { return $.$spc.System.Attribute; }
            static get $fullName() { return `System.Runtime.InteropServices.Marshalling.GeneratedComClassAttribute`; }
        });
        
        $asm.$cls("$sris.System.Runtime.InteropServices.Marshalling.GeneratedComInterfaceAttribute", ($self) => class GeneratedComInterfaceAttribute extends $.$spc.System.Attribute
        {
            /*ComInterfaceOptions*/ Options = 0;
            /*StringMarshalling*/ StringMarshalling = 0;
            /*Type?*/ StringMarshallingCustomType = null;
            /*Type?*/ ExceptionToUnmanagedMarshaller = null;
            //default reference type constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                return this;
            }
            //default member initializer
            constructor()
            {
                super();
                this.Options = 3;
                this.StringMarshalling = 0;
            }
            static $h = 2919299;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":14483457,"p":[{"p":2132867,"g":{"r":0,"d":0,"h":12887821187,"f":1},"s":{"r":0,"d":0,"h":17182788483,"f":1},"n":"Options","d":2919299,"h":8592853891,"f":1},{"p":109838337,"g":{"r":0,"d":0,"h":30067690371,"f":1},"s":{"r":0,"d":0,"h":34362657667,"f":1},"n":"StringMarshalling","d":2919299,"h":25772723075,"f":1},{"p":142606337,"g":{"r":0,"d":0,"h":47247559555,"f":1},"s":{"r":0,"d":0,"h":51542526851,"f":1},"n":"StringMarshallingCustomType","d":2919299,"h":42952592259,"f":1},{"p":142606337,"g":{"r":0,"d":0,"h":64427428739,"f":1},"s":{"r":0,"d":0,"h":68722396035,"f":1},"n":"ExceptionToUnmanagedMarshaller","d":2919299,"h":60132461443,"f":1}],"c":[{"n":".ctor","o":"$ctor$2","d":2919299,"h":73017363331,"f":1}],"h":2919299,"a":[{"t":14614529,"c":21489451009,"a":[{"v":1024,"t":14548993}]}]}; }
            static get $b() { return $.$spc.System.Attribute; }
            static get $fullName() { return `System.Runtime.InteropServices.Marshalling.GeneratedComInterfaceAttribute`; }
        });
        
        $asm.$cls("$sris.System.Runtime.InteropServices.Marshalling.StrategyBasedComWrappers", ($self) => class StrategyBasedComWrappers extends $.$spc.System.Runtime.InteropServices.ComWrappers
        {
            /*StrategyBasedComWrappers*/ static DefaultMarshallingInstance = null;
            /*IIUnknownInterfaceDetailsStrategy*/ static DefaultIUnknownInterfaceDetailsStrategy = null;
            /*IIUnknownStrategy*/ static DefaultIUnknownStrategy = null;
            static /*IIUnknownCacheStrategy */ CreateDefaultCacheStrategy()
            {
                return new $.$sris.System.Runtime.InteropServices.Marshalling.DefaultCaching().$ctor$1();
            }
            /*IIUnknownInterfaceDetailsStrategy */ GetOrCreateInterfaceDetailsStrategy()
            {
                //if (OperatingSystem.IsWindows() && RuntimeFeature.IsDynamicCodeSupported && ComObject.BuiltInComSupported && ComObject.ComImportInteropEnabled) { ... }
                return $.$sris.System.Runtime.InteropServices.Marshalling.StrategyBasedComWrappers.DefaultIUnknownInterfaceDetailsStrategy;
                /*static IIUnknownInterfaceDetailsStrategy*/  function GetInteropStrategy()
                {
                    return $.$sris.System.Runtime.InteropServices.Marshalling.ComImportInteropInterfaceDetailsStrategy.Instance;
                }
            }
            /*IIUnknownStrategy */ GetOrCreateIUnknownStrategy()
            {
                return $.$sris.System.Runtime.InteropServices.Marshalling.StrategyBasedComWrappers.DefaultIUnknownStrategy;
            }
            /*IIUnknownCacheStrategy */ CreateCacheStrategy()
            {
                return $.$sris.System.Runtime.InteropServices.Marshalling.StrategyBasedComWrappers.CreateDefaultCacheStrategy();
            }
            /*ComInterfaceEntry* */ ComputeVtables(/*object*/ obj, /*CreateComInterfaceFlags*/ flags, /*out int*/ count)
            {
                let details;
                if (this.GetOrCreateInterfaceDetailsStrategy().System$Runtime$InteropServices$Marshalling$IIUnknownInterfaceDetailsStrategy$GetComExposedTypeDetails($.$spc.System.Object.GetType.call(obj).TypeHandle) !== null && ((details = this.GetOrCreateInterfaceDetailsStrategy().System$Runtime$InteropServices$Marshalling$IIUnknownInterfaceDetailsStrategy$GetComExposedTypeDetails($.$spc.System.Object.GetType.call(obj).TypeHandle), details != null && true)))
                {
                    return details.System$Runtime$InteropServices$Marshalling$IComExposedDetails$GetComInterfaceEntries(count);
                }
                count.$v = 0;
                return null;
            }
            /*object */ CreateObject(/*nint*/ externalComObject, /*CreateObjectFlags*/ flags)
            {
                if (((flags & (1/*CreateObjectFlags.TrackerObject*/)) == (1/*CreateObjectFlags.TrackerObject*/)) || ((flags & (4/*CreateObjectFlags.Aggregation*/)) == (4/*CreateObjectFlags.Aggregation*/)))
                {
                    throw new $.$spc.System.NotSupportedException().$ctor$9();
                }
                /*var*/ let rcw = (() =>
                {
                    //new $.$sris.System.Runtime.InteropServices.Marshalling.ComObject()
                    const $t1 = $.$sris.System.Runtime.InteropServices.Marshalling.ComObject;
                    const $i1 = new $t1();
                    $i1.$ctor$1(this.GetOrCreateInterfaceDetailsStrategy(), this.GetOrCreateIUnknownStrategy(), this.CreateCacheStrategy(), $.$spc.System.IntPtr.op_Explicit$3(externalComObject));
                    $i1.UniqueInstance = ((flags & (2/*CreateObjectFlags.UniqueInstance*/)) == (2/*CreateObjectFlags.UniqueInstance*/));
                    return $i1;
                })();
                return rcw;
            }
            /*object? */ CreateObject$1(/*nint*/ externalComObject, /*CreateObjectFlags*/ flags, /*object?*/ userState, /*out CreatedWrapperFlags*/ wrapperFlags)
            {
                return super.CreateObject$1(externalComObject, flags, userState, wrapperFlags);
            }
            /*void */ ReleaseObjects(/*IEnumerable*/ objects)
            {
                throw new $.$spc.System.NotImplementedException().$ctor$9();
            }
            //default reference type constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                return this;
            }
            //Static Initializer
            static $sinit()
            {
                {
                    this.DefaultMarshallingInstance = new $.$sris.System.Runtime.InteropServices.Marshalling.StrategyBasedComWrappers().$ctor$2();
                }
                {
                    this.DefaultIUnknownInterfaceDetailsStrategy = $.$sris.System.Runtime.InteropServices.Marshalling.DefaultIUnknownInterfaceDetailsStrategy.Instance;
                }
                {
                    this.DefaultIUnknownStrategy = $.$sris.System.Runtime.InteropServices.Marshalling.FreeThreadedStrategy.Instance;
                }
            }
            static $h = 3640195;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":102629377,"p":[{"p":3640195,"g":{"r":0,"d":0,"h":12888542083,"f":40},"n":"DefaultMarshallingInstance","d":3640195,"h":8593574787,"f":40},{"p":3312515,"g":{"r":0,"d":0,"h":25773443971,"f":33},"n":"DefaultIUnknownInterfaceDetailsStrategy","d":3640195,"h":21478476675,"f":33},{"p":3443587,"g":{"r":0,"d":0,"h":38658345859,"f":33},"n":"DefaultIUnknownStrategy","d":3640195,"h":34363378563,"f":33}],"m":[{"r":3115907,"n":"CreateDefaultCacheStrategy","d":3640195,"h":42953313155,"f":36},{"r":3312515,"n":"GetOrCreateInterfaceDetailsStrategy","d":3640195,"h":47248280451,"f":132},{"r":3443587,"n":"GetOrCreateIUnknownStrategy","d":3640195,"h":51543247747,"f":132},{"r":3115907,"n":"CreateCacheStrategy","d":3640195,"h":55838215043,"f":132},{"r":0,"p":[{"n":"obj","p":131073},{"n":"flags","p":102825985},{"n":"count","p":655361,"f":2}],"n":"ComputeVtables","d":3640195,"h":60133182339,"f":98308},{"r":131073,"p":[{"n":"externalComObject","p":786433},{"n":"flags","p":102957057}],"n":"CreateObject","d":3640195,"h":64428149635,"f":98308},{"r":131073,"p":[{"n":"externalComObject","p":786433},{"n":"flags","p":102957057},{"n":"userState","p":131073},{"n":"wrapperFlags","p":102891521,"f":2}],"n":"CreateObject","o":"@$1","d":3640195,"h":68723116931,"f":98308},{"r":65537,"p":[{"n":"objects","p":31588353}],"n":"ReleaseObjects","d":3640195,"h":73018084227,"f":98308}],"c":[{"n":".ctor","o":"$ctor$2","d":3640195,"h":77313051523,"f":1}],"h":3640195,"a":[{"t":115277825,"c":4410245121,"a":[{"v":"android","t":1310721}]},{"t":115277825,"c":4410245121,"a":[{"v":"browser","t":1310721}]},{"t":115277825,"c":4410245121,"a":[{"v":"ios","t":1310721}]},{"t":115277825,"c":4410245121,"a":[{"v":"tvos","t":1310721}]},{"t":23396353,"c":8613330945,"a":[{"v":false,"t":262145}]}]}; }
            static get $b() { return $.$spc.System.Runtime.InteropServices.ComWrappers; }
            static get $fullName() { return `System.Runtime.InteropServices.Marshalling.StrategyBasedComWrappers`; }
        });
        
        $asm.$cls("$sris.System.Runtime.InteropServices.TypeLibTypeAttribute", ($self) => class TypeLibTypeAttribute extends $.$spc.System.Attribute
        {
            $ctor$2(/*TypeLibTypeFlags*/ flags)
            {
                super.$ctor$1();
                {
                    this.Value = flags;
                }
                return this;
            }
            $ctor$3(/*short*/ flags)
            {
                super.$ctor$1();
                {
                    this.Value = $.$cast(flags, $.$sris.System.Runtime.InteropServices.TypeLibTypeFlags);
                }
                return this;
            }
            /*TypeLibTypeFlags*/ Value = 0;
            //default member initializer
            constructor()
            {
                super();
                this.Value = 0;
            }
            static $h = 4295555;
            static $f = 0b10010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":14483457,"p":[{"p":4361091,"g":{"r":0,"d":0,"h":21479132035,"f":1},"n":"Value","d":4295555,"h":17184164739,"f":1}],"c":[{"p":[{"n":"flags","p":4361091}],"n":".ctor","o":"$ctor$2","d":4295555,"h":4299262851,"f":1},{"p":[{"n":"flags","p":524289}],"n":".ctor","o":"$ctor$3","d":4295555,"h":8594230147,"f":1}],"h":4295555,"a":[{"t":14614529,"c":21489451009,"a":[{"v":1052,"t":14548993}],"n":[{"n":"Inherited","v":false,"t":262145}]}]}; }
            static get $b() { return $.$spc.System.Attribute; }
            static get $fullName() { return `System.Runtime.InteropServices.TypeLibTypeAttribute`; }
        });
        
        $asm.$cls("$sris.System.Runtime.InteropServices.TypeLibImportClassAttribute", ($self) => class TypeLibImportClassAttribute extends $.$spc.System.Attribute
        {
            $ctor$2(/*Type*/ importClass)
            {
                super.$ctor$1();
                this.Value = $.$spc.System.Type.ToString.call(importClass);
                return this;
            }
            /*string*/ Value = null;
            static $h = 4230019;
            static $f = 0b10010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":14483457,"p":[{"p":1310721,"g":{"r":0,"d":0,"h":17184099203,"f":1},"n":"Value","d":4230019,"h":12889131907,"f":1}],"c":[{"p":[{"n":"importClass","p":142606337}],"n":".ctor","o":"$ctor$2","d":4230019,"h":4299197315,"f":1}],"h":4230019,"a":[{"t":14614529,"c":21489451009,"a":[{"v":1024,"t":14548993}],"n":[{"n":"Inherited","v":false,"t":262145}]}]}; }
            static get $b() { return $.$spc.System.Attribute; }
            static get $fullName() { return `System.Runtime.InteropServices.TypeLibImportClassAttribute`; }
        });
        
        $asm.$cls("$sris.System.Runtime.InteropServices.TypeLibVarAttribute", ($self) => class TypeLibVarAttribute extends $.$spc.System.Attribute
        {
            $ctor$2(/*TypeLibVarFlags*/ flags)
            {
                super.$ctor$1();
                {
                    this.Value = flags;
                }
                return this;
            }
            $ctor$3(/*short*/ flags)
            {
                super.$ctor$1();
                {
                    this.Value = $.$cast(flags, $.$sris.System.Runtime.InteropServices.TypeLibVarFlags);
                }
                return this;
            }
            /*TypeLibVarFlags*/ Value = 0;
            //default member initializer
            constructor()
            {
                super();
                this.Value = 0;
            }
            static $h = 4426627;
            static $f = 0b10010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":14483457,"p":[{"p":4492163,"g":{"r":0,"d":0,"h":21479263107,"f":1},"n":"Value","d":4426627,"h":17184295811,"f":1}],"c":[{"p":[{"n":"flags","p":4492163}],"n":".ctor","o":"$ctor$2","d":4426627,"h":4299393923,"f":1},{"p":[{"n":"flags","p":524289}],"n":".ctor","o":"$ctor$3","d":4426627,"h":8594361219,"f":1}],"h":4426627,"a":[{"t":14614529,"c":21489451009,"a":[{"v":256,"t":14548993}],"n":[{"n":"Inherited","v":false,"t":262145}]}]}; }
            static get $b() { return $.$spc.System.Attribute; }
            static get $fullName() { return `System.Runtime.InteropServices.TypeLibVarAttribute`; }
        });
        
        $asm.$cls("$sris.System.Runtime.InteropServices.TypeLibVersionAttribute", ($self) => class TypeLibVersionAttribute extends $.$spc.System.Attribute
        {
            $ctor$2(/*int*/ major, /*int*/ minor)
            {
                super.$ctor$1();
                {
                    this.MajorVersion = major;
                    this.MinorVersion = minor;
                }
                return this;
            }
            /*int*/ MajorVersion = 0;
            /*int*/ MinorVersion = 0;
            static $h = 4557699;
            static $f = 0b10010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":14483457,"p":[{"p":655361,"g":{"r":0,"d":0,"h":17184426883,"f":1},"n":"MajorVersion","d":4557699,"h":12889459587,"f":1},{"p":655361,"g":{"r":0,"d":0,"h":30069328771,"f":1},"n":"MinorVersion","d":4557699,"h":25774361475,"f":1}],"c":[{"p":[{"n":"major","p":655361},{"n":"minor","p":655361}],"n":".ctor","o":"$ctor$2","d":4557699,"h":4299524995,"f":1}],"h":4557699,"a":[{"t":14614529,"c":21489451009,"a":[{"v":1,"t":14548993}],"n":[{"n":"Inherited","v":false,"t":262145}]}]}; }
            static get $b() { return $.$spc.System.Attribute; }
            static get $fullName() { return `System.Runtime.InteropServices.TypeLibVersionAttribute`; }
        });
        
        $asm.$cls("$sris.System.Runtime.InteropServices.TypeLibFuncAttribute", ($self) => class TypeLibFuncAttribute extends $.$spc.System.Attribute
        {
            $ctor$2(/*TypeLibFuncFlags*/ flags)
            {
                super.$ctor$1();
                {
                    this.Value = flags;
                }
                return this;
            }
            $ctor$3(/*short*/ flags)
            {
                super.$ctor$1();
                {
                    this.Value = $.$cast(flags, $.$sris.System.Runtime.InteropServices.TypeLibFuncFlags);
                }
                return this;
            }
            /*TypeLibFuncFlags*/ Value = 0;
            //default member initializer
            constructor()
            {
                super();
                this.Value = 0;
            }
            static $h = 4098947;
            static $f = 0b10010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":14483457,"p":[{"p":4164483,"g":{"r":0,"d":0,"h":21478935427,"f":1},"n":"Value","d":4098947,"h":17183968131,"f":1}],"c":[{"p":[{"n":"flags","p":4164483}],"n":".ctor","o":"$ctor$2","d":4098947,"h":4299066243,"f":1},{"p":[{"n":"flags","p":524289}],"n":".ctor","o":"$ctor$3","d":4098947,"h":8594033539,"f":1}],"h":4098947,"a":[{"t":14614529,"c":21489451009,"a":[{"v":64,"t":14548993}],"n":[{"n":"Inherited","v":false,"t":262145}]}]}; }
            static get $b() { return $.$spc.System.Attribute; }
            static get $fullName() { return `System.Runtime.InteropServices.TypeLibFuncAttribute`; }
        });
        
        $asm.$str("$sris.System.Runtime.InteropServices.Marshalling.VirtualMethodTableInfo", ($self) => class VirtualMethodTableInfo extends $.$spc.System.ValueType
        {
            $ctor$2(/*void**/ thisPointer, /*void***/ virtualMethodTable)
            {
                super.$ctor$1();
                {
                    this.ThisPointer = thisPointer;
                    this.VirtualMethodTable = virtualMethodTable;
                }
                return this;
            }
            /*void**/ ThisPointer;
            /*void***/ VirtualMethodTable;
            /*void */ Deconstruct(/*out void**/ thisPointer, /*out void***/ virtualMethodTable)
            {
                thisPointer.$v = this.ThisPointer;
                virtualMethodTable.$v = this.VirtualMethodTable;
            }
            //default value type constructor
            $ctor$3()
            {
                return this;
            }
            Clone($copy)
            {
                let copy = $copy ?? new this.constructor();
                copy.ThisPointer = this.ThisPointer.Clone();
                copy.VirtualMethodTable = this.VirtualMethodTable.Clone();
                return copy;
            }
            //default member initializer
            constructor()
            {
                super();
                this.ThisPointer = $.$default($.$typePointer($.$spc.System.Void));
                this.VirtualMethodTable = $.$default($.$typePointer($.$typePointer($.$spc.System.Void)));
            }
            static $h = 3771267;
            static $z = 8;
            static $f = 0b1010000001;
            static $k = 2;
            static $$md;
            static get $md() { return this.$$md ??= {"b":196609,"p":[{"p":0,"g":{"r":0,"d":0,"h":17183640451,"f":1},"n":"ThisPointer","d":3771267,"h":12888673155,"f":1},{"p":0,"g":{"r":0,"d":0,"h":30068542339,"f":1},"n":"VirtualMethodTable","d":3771267,"h":25773575043,"f":1}],"m":[{"r":65537,"p":[{"n":"thisPointer","p":0,"f":2},{"n":"virtualMethodTable","p":0,"f":2}],"n":"Deconstruct","d":3771267,"h":34363509635,"f":1}],"c":[{"p":[{"n":"thisPointer","p":0},{"n":"virtualMethodTable","p":0}],"n":".ctor","o":"$ctor$2","d":3771267,"h":4298738563,"f":1},{"n":".ctor","o":"$ctor$3","d":3771267,"h":38658476931,"f":1}],"h":3771267,"a":[{"t":23396353,"c":8613330945,"a":[{"v":false,"t":262145}]}]}; }
            static get $b() { return $.$spc.System.ValueType; }
            static get $fullName() { return `System.Runtime.InteropServices.Marshalling.VirtualMethodTableInfo`; }
        });
        
        $asm.$cls("$sris.System.Runtime.InteropServices.ImportedFromTypeLibAttribute", ($self) => class ImportedFromTypeLibAttribute extends $.$spc.System.Attribute
        {
            $ctor$2(/*string*/ tlbFile)
            {
                super.$ctor$1();
                this.Value = tlbFile;
                return this;
            }
            /*string*/ Value = null;
            static $h = 1674115;
            static $f = 0b10010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":14483457,"p":[{"p":1310721,"g":{"r":0,"d":0,"h":17181543299,"f":1},"n":"Value","d":1674115,"h":12886576003,"f":1}],"c":[{"p":[{"n":"tlbFile","p":1310721}],"n":".ctor","o":"$ctor$2","d":1674115,"h":4296641411,"f":1}],"h":1674115,"a":[{"t":14614529,"c":21489451009,"a":[{"v":1,"t":14548993}],"n":[{"n":"Inherited","v":false,"t":262145}]}]}; }
            static get $b() { return $.$spc.System.Attribute; }
            static get $fullName() { return `System.Runtime.InteropServices.ImportedFromTypeLibAttribute`; }
        });
        
        $asm.$cls("$sris.System.Runtime.InteropServices.PrimaryInteropAssemblyAttribute", ($self) => class PrimaryInteropAssemblyAttribute extends $.$spc.System.Attribute
        {
            $ctor$2(/*int*/ major, /*int*/ minor)
            {
                super.$ctor$1();
                {
                    this.MajorVersion = major;
                    this.MinorVersion = minor;
                }
                return this;
            }
            /*int*/ MajorVersion = 0;
            /*int*/ MinorVersion = 0;
            static $h = 3836803;
            static $f = 0b10010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":14483457,"p":[{"p":655361,"g":{"r":0,"d":0,"h":17183705987,"f":1},"n":"MajorVersion","d":3836803,"h":12888738691,"f":1},{"p":655361,"g":{"r":0,"d":0,"h":30068607875,"f":1},"n":"MinorVersion","d":3836803,"h":25773640579,"f":1}],"c":[{"p":[{"n":"major","p":655361},{"n":"minor","p":655361}],"n":".ctor","o":"$ctor$2","d":3836803,"h":4298804099,"f":1}],"h":3836803,"a":[{"t":14614529,"c":21489451009,"a":[{"v":1,"t":14548993}],"n":[{"n":"Inherited","v":false,"t":262145},{"n":"AllowMultiple","v":true,"t":262145}]}]}; }
            static get $b() { return $.$spc.System.Attribute; }
            static get $fullName() { return `System.Runtime.InteropServices.PrimaryInteropAssemblyAttribute`; }
        });
        
        $asm.$cls("$sris.System.Runtime.InteropServices.Marshalling.ComExposedClassAttribute<>", (T) => $asm.$gt("$sris.System.Runtime.InteropServices.Marshalling.ComExposedClassAttribute<>", [T], ($self) => class ComExposedClassAttribute$$ extends $.$spc.System.Attribute
        {
            /*ComWrappers.ComInterfaceEntry* */ GetComInterfaceEntries(/*out int*/ count)
            {
                return T.System$Runtime$InteropServices$Marshalling$IComExposedClass$GetComInterfaceEntries(count);
            }
            //Generated interface implemetation for System.Runtime.InteropServices.Marshalling.IComExposedDetails.GetComInterfaceEntries(out int)
            System$Runtime$InteropServices$Marshalling$IComExposedDetails$GetComInterfaceEntries()
            {
                return this.GetComInterfaceEntries(...arguments);
            }
            //default reference type constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                return this;
            }
            static $h = 1805187;
            static $g = 1;
            static $f = 0b11010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":14483457,"m":[{"r":0,"p":[{"n":"count","p":655361,"f":2}],"n":"GetComInterfaceEntries","d":this.$h,"h":Number(BigInt(this.$h)|0x100000000n),"f":1}],"c":[{"n":".ctor","o":"$ctor$2","d":this.$h,"h":Number(BigInt(this.$h)|0x200000000n),"f":1}],"i":[3050371],"g":[T?.$h??1507328],"r":1,"h":this.$h,"a":[{"t":14614529,"c":21489451009,"a":[{"v":4,"t":14548993}],"n":[{"n":"Inherited","v":false,"t":262145}]},{"t":23396353,"c":8613330945,"a":[{"v":false,"t":262145}]}]}; }
            static get $b() { return $.$spc.System.Attribute; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$sris.System.Runtime.InteropServices.Marshalling.IComExposedDetails ]; }
            static get $fullName() { return `System.Runtime.InteropServices.Marshalling.ComExposedClassAttribute<${T?.$fullName}>`; }
        }));
        
        $asm.$cls("$sris.System.Runtime.InteropServices.Marshalling.IUnknownDerivedAttribute<,>", (T, TImpl) => $asm.$gt("$sris.System.Runtime.InteropServices.Marshalling.IUnknownDerivedAttribute<,>", [T, TImpl], ($self) => class IUnknownDerivedAttribute$$$ extends $.$spc.System.Attribute
        {
            $ctor$2()
            {
                super.$ctor$1();
                {
                }
                return this;
            }
            /*Guid */ get Iid()
            {
                return T.System$Runtime$InteropServices$Marshalling$IIUnknownInterfaceType$Iid;
            }
            /*Type */ get Implementation()
            {
                return TImpl.$type;
            }
            /*void** */ get ManagedVirtualMethodTable()
            {
                return T.System$Runtime$InteropServices$Marshalling$IIUnknownInterfaceType$ManagedVirtualMethodTable;
            }
            //Generated interface implemetation for System.Runtime.InteropServices.Marshalling.IIUnknownDerivedDetails.Iid.get
            get System$Runtime$InteropServices$Marshalling$IIUnknownDerivedDetails$Iid()
            {
                return this.Iid;
            }
            //Generated interface implemetation for System.Runtime.InteropServices.Marshalling.IIUnknownDerivedDetails.Implementation.get
            get System$Runtime$InteropServices$Marshalling$IIUnknownDerivedDetails$Implementation()
            {
                return this.Implementation;
            }
            //Generated interface implemetation for System.Runtime.InteropServices.Marshalling.IIUnknownDerivedDetails.ManagedVirtualMethodTable.get
            get System$Runtime$InteropServices$Marshalling$IIUnknownDerivedDetails$ManagedVirtualMethodTable()
            {
                return this.ManagedVirtualMethodTable;
            }
            static $h = 3509123;
            static $g = 2;
            static $f = 0b1010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":14483457,"p":[{"p":56164353,"g":{"r":0,"d":0,"h":Number(BigInt(this.$h)|0x300000000n),"f":1},"n":"Iid","d":this.$h,"h":Number(BigInt(this.$h)|0x200000000n),"f":1},{"p":142606337,"g":{"r":0,"d":0,"h":Number(BigInt(this.$h)|0x500000000n),"f":1},"n":"Implementation","d":this.$h,"h":Number(BigInt(this.$h)|0x400000000n),"f":1},{"p":0,"g":{"r":0,"d":0,"h":Number(BigInt(this.$h)|0x700000000n),"f":1},"n":"ManagedVirtualMethodTable","d":this.$h,"h":Number(BigInt(this.$h)|0x600000000n),"f":1}],"c":[{"n":".ctor","o":"$ctor$2","d":this.$h,"h":Number(BigInt(this.$h)|0x100000000n),"f":1}],"i":[3246979],"g":[T?.$h??1507328,TImpl?.$h??1572864],"r":2,"h":this.$h,"a":[{"t":14614529,"c":21489451009,"a":[{"v":1024,"t":14548993}],"n":[{"n":"Inherited","v":false,"t":262145}]},{"t":23396353,"c":8613330945,"a":[{"v":false,"t":262145}]}]}; }
            static get $b() { return $.$spc.System.Attribute; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$sris.System.Runtime.InteropServices.Marshalling.IIUnknownDerivedDetails ]; }
            static get $fullName() { return `System.Runtime.InteropServices.Marshalling.IUnknownDerivedAttribute<${T?.$fullName},${TImpl?.$fullName}>`; }
        }));
        
        $asm.$cls("$sris.System.Runtime.CompilerServices.IUnknownConstantAttribute", ($self) => class IUnknownConstantAttribute extends $.$spc.System.Runtime.CompilerServices.CustomConstantAttribute
        {
            $ctor$3()
            {
                super.$ctor$2();
                {
                }
                return this;
            }
            /*object */ get Value()
            {
                return new $.$spc.System.Runtime.InteropServices.UnknownWrapper().$ctor$1(null);
            }
            static $h = 232323;
            static $f = 0b10010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":89915393,"p":[{"p":131073,"g":{"r":0,"d":0,"h":12885134211,"f":32769},"n":"Value","d":232323,"h":8590166915,"f":32769}],"c":[{"n":".ctor","o":"$ctor$3","d":232323,"h":4295199619,"f":1}],"h":232323,"a":[{"t":14614529,"c":21489451009,"a":[{"v":2304,"t":14548993}],"n":[{"n":"Inherited","v":false,"t":262145}]}]}; }
            static get $b() { return $.$spc.System.Runtime.CompilerServices.CustomConstantAttribute; }
            static get $fullName() { return `System.Runtime.CompilerServices.IUnknownConstantAttribute`; }
        });
        
        $asm.$cls("$sris.System.Runtime.CompilerServices.IDispatchConstantAttribute", ($self) => class IDispatchConstantAttribute extends $.$spc.System.Runtime.CompilerServices.CustomConstantAttribute
        {
            $ctor$3()
            {
                super.$ctor$2();
                {
                }
                return this;
            }
            /*object */ get Value()
            {
                return new $.$spc.System.Runtime.InteropServices.DispatchWrapper().$ctor$1(null);
            }
            static $h = 166787;
            static $f = 0b10010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":89915393,"p":[{"p":131073,"g":{"r":0,"d":0,"h":12885068675,"f":32769},"n":"Value","d":166787,"h":8590101379,"f":32769}],"c":[{"n":".ctor","o":"$ctor$3","d":166787,"h":4295134083,"f":1}],"h":166787,"a":[{"t":114950145,"c":4409917441,"a":[{"v":"windows","t":1310721}]},{"t":14614529,"c":21489451009,"a":[{"v":2304,"t":14548993}],"n":[{"n":"Inherited","v":false,"t":262145}]}]}; }
            static get $b() { return $.$spc.System.Runtime.CompilerServices.CustomConstantAttribute; }
            static get $fullName() { return `System.Runtime.CompilerServices.IDispatchConstantAttribute`; }
        });
        
        $asm.$cls("$sris.System.Runtime.InteropServices.ComAwareEventInfo", ($self) => class ComAwareEventInfo extends $.$spc.System.Reflection.EventInfo
        {
            /*EventInfo*/ _innerEventInfo = null;
            $ctor$4(/*Type*/ type, /*string*/ eventName)
            {
                super.$ctor$3();
                {
                    this._innerEventInfo = type.GetEvent(eventName);
                }
                return this;
            }
            /*void */ AddEventHandler(/*object*/ target, /*Delegate*/ handler)
            {
                if ($.$spc.System.Runtime.InteropServices.Marshal.IsComObject(target))
                {
                    /*Guid*/ let sourceIid;
                    /*int*/ let dispid;
                    $.$sris.System.Runtime.InteropServices.ComAwareEventInfo.GetDataForComInvocation(this._innerEventInfo, $.$ref(() => sourceIid, ($v) => sourceIid = $v, $.$spc.System.Guid), $.$ref(() => dispid, ($v) => dispid = $v, $.$spc.System.Int32));
                    $.$spc.System.Runtime.InteropServices.ComEventsHelper.Combine(target, sourceIid, dispid, handler);
                }
                else 
                {
                    this._innerEventInfo.AddEventHandler(target, handler);
                }
            }
            /*void */ RemoveEventHandler(/*object*/ target, /*Delegate*/ handler)
            {
                if ($.$spc.System.Runtime.InteropServices.Marshal.IsComObject(target))
                {
                    /*Guid*/ let sourceIid;
                    /*int*/ let dispid;
                    $.$sris.System.Runtime.InteropServices.ComAwareEventInfo.GetDataForComInvocation(this._innerEventInfo, $.$ref(() => sourceIid, ($v) => sourceIid = $v, $.$spc.System.Guid), $.$ref(() => dispid, ($v) => dispid = $v, $.$spc.System.Int32));
                    $.$spc.System.Runtime.InteropServices.ComEventsHelper.Remove(target, sourceIid, dispid, handler);
                }
                else 
                {
                    this._innerEventInfo.RemoveEventHandler(target, handler);
                }
            }
            /*EventAttributes */ get Attributes()
            {
                return this._innerEventInfo.Attributes;
            }
            /*MethodInfo? */ GetAddMethod$1(/*bool*/ nonPublic)
            {
                return this._innerEventInfo.GetAddMethod$1(nonPublic);
            }
            /*MethodInfo[] */ GetOtherMethods$1(/*bool*/ nonPublic)
            {
                return this._innerEventInfo.GetOtherMethods$1(nonPublic);
            }
            /*MethodInfo? */ GetRaiseMethod$1(/*bool*/ nonPublic)
            {
                return this._innerEventInfo.GetRaiseMethod$1(nonPublic);
            }
            /*MethodInfo? */ GetRemoveMethod$1(/*bool*/ nonPublic)
            {
                return this._innerEventInfo.GetRemoveMethod$1(nonPublic);
            }
            /*Type? */ get DeclaringType()
            {
                return this._innerEventInfo.DeclaringType;
            }
            /*object[] */ GetCustomAttributes$1(/*Type*/ attributeType, /*bool*/ inherit)
            {
                return this._innerEventInfo.GetCustomAttributes$1(attributeType, inherit);
            }
            /*object[] */ GetCustomAttributes(/*bool*/ inherit)
            {
                return this._innerEventInfo.GetCustomAttributes(inherit);
            }
            /*IList<CustomAttributeData> */ GetCustomAttributesData()
            {
                return this._innerEventInfo.GetCustomAttributesData();
            }
            /*bool */ IsDefined(/*Type*/ attributeType, /*bool*/ inherit)
            {
                return this._innerEventInfo.IsDefined(attributeType, inherit);
            }
            /*int */ get MetadataToken()
            {
                return this._innerEventInfo.MetadataToken;
            }
            /*Module */ get Module()
            {
                return this._innerEventInfo.Module;
            }
            /*string */ get Name()
            {
                return this._innerEventInfo.Name;
            }
            /*Type? */ get ReflectedType()
            {
                return this._innerEventInfo.ReflectedType;
            }
            static /*void */ GetDataForComInvocation(/*EventInfo*/ eventInfo, /*out Guid*/ sourceIid, /*out int*/ dispid)
            {
                /*object[]*/ let comEventInterfaces = eventInfo.DeclaringType.GetCustomAttributes$1($.$spc.System.Runtime.InteropServices.ComEventInterfaceAttribute.$type, false);
                if (comEventInterfaces === null || comEventInterfaces.length === 0)
                {
                    throw new $.$spc.System.InvalidOperationException().$ctor$10($.$sris.System.SR.InvalidOperation_NoComEventInterfaceAttribute);
                }
                /*ComEventInterfaceAttribute*/ let interfaceAttribute = $.$cast($.$spc.System.Array.$ReadT1.call(comEventInterfaces, 0), $.$spc.System.Runtime.InteropServices.ComEventInterfaceAttribute);
                if (comEventInterfaces.length > 1)
                {
                    throw new $.$spc.System.Reflection.AmbiguousMatchException().$ctor$10($.$sris.System.SR.Format($.$sris.System.SR.AmbiguousMatch_MultipleEventInterfaceAttributes, interfaceAttribute));
                }
                /*Type*/ let sourceInterface = interfaceAttribute.SourceInterface;
                /*Guid*/ let guid = sourceInterface.GUID;
                /*MethodInfo*/ let methodInfo = sourceInterface.GetMethod$1(eventInfo.Name);
                /*Attribute?*/ let dispIdAttribute = $.$spc.System.Attribute.GetCustomAttribute$2(methodInfo, $.$spc.System.Runtime.InteropServices.DispIdAttribute.$type);
                if (dispIdAttribute === null)
                {
                    throw new $.$spc.System.InvalidOperationException().$ctor$10($.$sris.System.SR.InvalidOperation_NoDispIdAttribute);
                }
                sourceIid.$v = guid;
                dispid.$v = ($.$cast(dispIdAttribute, $.$spc.System.Runtime.InteropServices.DispIdAttribute)).Value;
            }
            static $h = 494467;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":76414977,"p":[{"p":76349441,"g":{"r":0,"d":0,"h":25770298243,"f":32769},"n":"Attributes","d":494467,"h":21475330947,"f":32769},{"p":142606337,"g":{"r":0,"d":0,"h":51540102019,"f":32769},"n":"DeclaringType","d":494467,"h":47245134723,"f":32769},{"p":655361,"g":{"r":0,"d":0,"h":77309905795,"f":32769},"n":"MetadataToken","d":494467,"h":73014938499,"f":32769},{"p":80216065,"g":{"r":0,"d":0,"h":85899840387,"f":32769},"n":"Module","d":494467,"h":81604873091,"f":32769},{"p":1310721,"g":{"r":0,"d":0,"h":94489774979,"f":32769},"n":"Name","d":494467,"h":90194807683,"f":32769},{"p":142606337,"g":{"r":0,"d":0,"h":103079709571,"f":32769},"n":"ReflectedType","d":494467,"h":98784742275,"f":32769}],"m":[{"r":65537,"p":[{"n":"target","p":131073},{"n":"handler","p":35651585}],"n":"AddEventHandler","d":494467,"h":12885396355,"f":32769,"a":[{"t":114950145,"c":4409917441,"a":[{"v":"windows","t":1310721}]}]},{"r":65537,"p":[{"n":"target","p":131073},{"n":"handler","p":35651585}],"n":"RemoveEventHandler","d":494467,"h":17180363651,"f":32769,"a":[{"t":114950145,"c":4409917441,"a":[{"v":"windows","t":1310721}]}]},{"r":79626241,"p":[{"n":"nonPublic","p":262145}],"n":"GetAddMethod","o":"@$1","d":494467,"h":30065265539,"f":32769},{"r":0,"p":[{"n":"nonPublic","p":262145}],"n":"GetOtherMethods","o":"@$1","d":494467,"h":34360232835,"f":32769},{"r":79626241,"p":[{"n":"nonPublic","p":262145}],"n":"GetRaiseMethod","o":"@$1","d":494467,"h":38655200131,"f":32769},{"r":79626241,"p":[{"n":"nonPublic","p":262145}],"n":"GetRemoveMethod","o":"@$1","d":494467,"h":42950167427,"f":32769},{"r":0,"p":[{"n":"attributeType","p":142606337},{"n":"inherit","p":262145}],"n":"GetCustomAttributes","o":"@$1","d":494467,"h":55835069315,"f":32769},{"r":0,"p":[{"n":"inherit","p":262145}],"n":"GetCustomAttributes","d":494467,"h":60130036611,"f":32769},{"r":$.$spc.System.Collections.Generic.IList$$($.$spc.System.Reflection.CustomAttributeData).$h,"n":"GetCustomAttributesData","d":494467,"h":64425003907,"f":32769},{"r":262145,"p":[{"n":"attributeType","p":142606337},{"n":"inherit","p":262145}],"n":"IsDefined","d":494467,"h":68719971203,"f":32769},{"r":65537,"p":[{"n":"eventInfo","p":76414977},{"n":"sourceIid","p":56164353,"f":2},{"n":"dispid","p":655361,"f":2}],"n":"GetDataForComInvocation","d":494467,"h":107374676867,"f":34}],"l":[{"t":76414977,"n":"_innerEventInfo","d":494467,"h":4295461763,"f":2}],"c":[{"p":[{"n":"type","p":142606337},{"n":"eventName","p":1310721}],"n":".ctor","o":"$ctor$4","d":494467,"h":8590429059,"f":1}],"i":[76939265],"h":494467,"a":[{"t":33161217,"c":4328128513,"a":[{"v":1,"t":33226753}]}]}; }
            static get $b() { return $.$spc.System.Reflection.EventInfo; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.Reflection.ICustomAttributeProvider ]; }
            static get $fullName() { return `System.Runtime.InteropServices.ComAwareEventInfo`; }
        });
        
        $asm.$str("$sris.System.Runtime.InteropServices.ComTypes.DATADIR", ($self) => class DATADIR extends $.$spc.System.Enum
        {
            static DATADIR_GET = 1;
            static DATADIR_SET = 2;
            static $map;
            static get Map()
            {
                return this.$map ??= 
                {
                    "DATADIR_GET": 1n,
                    "DATADIR_SET": 2n
                };
            }
            static $h = 822147;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static get $eut() { return $.$spc.System.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {"b":1048577,"u":655361,"l":[{"t":822147,"n":"DATADIR_GET","d":822147,"h":4295789443,"f":33},{"t":822147,"n":"DATADIR_SET","d":822147,"h":8590756739,"f":33}],"c":[{"n":".ctor","o":"$ctor$3","d":822147,"h":12885724035,"f":1}],"i":[57212929,63766529,57671681,57344001],"h":822147,"a":[{"t":33161217,"c":4328128513,"a":[{"v":1,"t":33226753}]}]}; }
            static get $b() { return $.$spc.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IComparable, $.$spc.System.ISpanFormattable, $.$spc.System.IFormattable, $.$spc.System.IConvertible ]; }
            static get $fullName() { return `System.Runtime.InteropServices.ComTypes.DATADIR`; }
        });
        
        $asm.$str("$sris.System.Runtime.InteropServices.ComTypes.ADVF", ($self) => class ADVF extends $.$spc.System.Enum
        {
            static ADVF_NODATA = 1;
            static ADVF_PRIMEFIRST = 2;
            static ADVF_ONLYONCE = 4;
            static ADVF_DATAONSTOP = 64;
            static ADVFCACHE_NOHANDLER = 8;
            static ADVFCACHE_FORCEBUILTIN = 16;
            static ADVFCACHE_ONSAVE = 32;
            static $map;
            static get Map()
            {
                return this.$map ??= 
                {
                    "ADVF_NODATA": 1n,
                    "ADVF_PRIMEFIRST": 2n,
                    "ADVF_ONLYONCE": 4n,
                    "ADVF_DATAONSTOP": 64n,
                    "ADVFCACHE_NOHANDLER": 8n,
                    "ADVFCACHE_FORCEBUILTIN": 16n,
                    "ADVFCACHE_ONSAVE": 32n
                };
            }
            static $h = 756611;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static get $eut() { return $.$spc.System.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {"b":1048577,"u":655361,"l":[{"t":756611,"n":"ADVF_NODATA","d":756611,"h":4295723907,"f":33},{"t":756611,"n":"ADVF_PRIMEFIRST","d":756611,"h":8590691203,"f":33},{"t":756611,"n":"ADVF_ONLYONCE","d":756611,"h":12885658499,"f":33},{"t":756611,"n":"ADVF_DATAONSTOP","d":756611,"h":17180625795,"f":33},{"t":756611,"n":"ADVFCACHE_NOHANDLER","d":756611,"h":21475593091,"f":33},{"t":756611,"n":"ADVFCACHE_FORCEBUILTIN","d":756611,"h":25770560387,"f":33},{"t":756611,"n":"ADVFCACHE_ONSAVE","d":756611,"h":30065527683,"f":33}],"c":[{"n":".ctor","o":"$ctor$3","d":756611,"h":34360494979,"f":1}],"i":[57212929,63766529,57671681,57344001],"h":756611,"a":[{"t":33161217,"c":4328128513,"a":[{"v":1,"t":33226753}]},{"t":47644673,"c":4342611969}]}; }
            static get $b() { return $.$spc.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IComparable, $.$spc.System.ISpanFormattable, $.$spc.System.IFormattable, $.$spc.System.IConvertible ]; }
            static get $fullName() { return `System.Runtime.InteropServices.ComTypes.ADVF`; }
        });
        
        $asm.$str("$sris.System.Runtime.InteropServices.ComTypes.DVASPECT", ($self) => class DVASPECT extends $.$spc.System.Enum
        {
            static DVASPECT_CONTENT = 1;
            static DVASPECT_THUMBNAIL = 2;
            static DVASPECT_ICON = 4;
            static DVASPECT_DOCPRINT = 8;
            static $map;
            static get Map()
            {
                return this.$map ??= 
                {
                    "DVASPECT_CONTENT": 1n,
                    "DVASPECT_THUMBNAIL": 2n,
                    "DVASPECT_ICON": 4n,
                    "DVASPECT_DOCPRINT": 8n
                };
            }
            static $h = 887683;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static get $eut() { return $.$spc.System.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {"b":1048577,"u":655361,"l":[{"t":887683,"n":"DVASPECT_CONTENT","d":887683,"h":4295854979,"f":33},{"t":887683,"n":"DVASPECT_THUMBNAIL","d":887683,"h":8590822275,"f":33},{"t":887683,"n":"DVASPECT_ICON","d":887683,"h":12885789571,"f":33},{"t":887683,"n":"DVASPECT_DOCPRINT","d":887683,"h":17180756867,"f":33}],"c":[{"n":".ctor","o":"$ctor$3","d":887683,"h":21475724163,"f":1}],"i":[57212929,63766529,57671681,57344001],"h":887683,"a":[{"t":33161217,"c":4328128513,"a":[{"v":1,"t":33226753}]},{"t":47644673,"c":4342611969}]}; }
            static get $b() { return $.$spc.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IComparable, $.$spc.System.ISpanFormattable, $.$spc.System.IFormattable, $.$spc.System.IConvertible ]; }
            static get $fullName() { return `System.Runtime.InteropServices.ComTypes.DVASPECT`; }
        });
        
        $asm.$str("$sris.System.Runtime.InteropServices.AssemblyRegistrationFlags", ($self) => class AssemblyRegistrationFlags extends $.$spc.System.Enum
        {
            static None = 0;
            static SetCodeBase = 1;
            static $map;
            static get Map()
            {
                return this.$map ??= 
                {
                    "None": 0n,
                    "SetCodeBase": 1n
                };
            }
            static $h = 297859;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static get $eut() { return $.$spc.System.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {"b":1048577,"u":655361,"l":[{"t":297859,"n":"None","d":297859,"h":4295265155,"f":33},{"t":297859,"n":"SetCodeBase","d":297859,"h":8590232451,"f":33}],"c":[{"n":".ctor","o":"$ctor$3","d":297859,"h":12885199747,"f":1}],"i":[57212929,63766529,57671681,57344001],"h":297859,"a":[{"t":47644673,"c":4342611969}]}; }
            static get $b() { return $.$spc.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IComparable, $.$spc.System.ISpanFormattable, $.$spc.System.IFormattable, $.$spc.System.IConvertible ]; }
            static get $fullName() { return `System.Runtime.InteropServices.AssemblyRegistrationFlags`; }
        });
        
        $asm.$str("$sris.System.Runtime.InteropServices.ComTypes.TYMED", ($self) => class TYMED extends $.$spc.System.Enum
        {
            static TYMED_HGLOBAL = 1;
            static TYMED_FILE = 2;
            static TYMED_ISTREAM = 4;
            static TYMED_ISTORAGE = 8;
            static TYMED_GDI = 16;
            static TYMED_MFPICT = 32;
            static TYMED_ENHMF = 64;
            static TYMED_NULL = 0;
            static $map;
            static get Map()
            {
                return this.$map ??= 
                {
                    "TYMED_HGLOBAL": 1n,
                    "TYMED_FILE": 2n,
                    "TYMED_ISTREAM": 4n,
                    "TYMED_ISTORAGE": 8n,
                    "TYMED_GDI": 16n,
                    "TYMED_MFPICT": 32n,
                    "TYMED_ENHMF": 64n,
                    "TYMED_NULL": 0n
                };
            }
            static $h = 1411971;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static get $eut() { return $.$spc.System.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {"b":1048577,"u":655361,"l":[{"t":1411971,"n":"TYMED_HGLOBAL","d":1411971,"h":4296379267,"f":33},{"t":1411971,"n":"TYMED_FILE","d":1411971,"h":8591346563,"f":33},{"t":1411971,"n":"TYMED_ISTREAM","d":1411971,"h":12886313859,"f":33},{"t":1411971,"n":"TYMED_ISTORAGE","d":1411971,"h":17181281155,"f":33},{"t":1411971,"n":"TYMED_GDI","d":1411971,"h":21476248451,"f":33},{"t":1411971,"n":"TYMED_MFPICT","d":1411971,"h":25771215747,"f":33},{"t":1411971,"n":"TYMED_ENHMF","d":1411971,"h":30066183043,"f":33},{"t":1411971,"n":"TYMED_NULL","d":1411971,"h":34361150339,"f":33}],"c":[{"n":".ctor","o":"$ctor$3","d":1411971,"h":38656117635,"f":1}],"i":[57212929,63766529,57671681,57344001],"h":1411971,"a":[{"t":33161217,"c":4328128513,"a":[{"v":1,"t":33226753}]},{"t":47644673,"c":4342611969}]}; }
            static get $b() { return $.$spc.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IComparable, $.$spc.System.ISpanFormattable, $.$spc.System.IFormattable, $.$spc.System.IConvertible ]; }
            static get $fullName() { return `System.Runtime.InteropServices.ComTypes.TYMED`; }
        });
        
        $asm.$str("$sris.System.Runtime.InteropServices.ExporterEventKind", ($self) => class ExporterEventKind extends $.$spc.System.Enum
        {
            static NOTIF_TYPECONVERTED = 0;
            static NOTIF_CONVERTWARNING = 1;
            static ERROR_REFTOINVALIDASSEMBLY = 2;
            static $map;
            static get Map()
            {
                return this.$map ??= 
                {
                    "NOTIF_TYPECONVERTED": 0n,
                    "NOTIF_CONVERTWARNING": 1n,
                    "ERROR_REFTOINVALIDASSEMBLY": 2n
                };
            }
            static $h = 1543043;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static get $eut() { return $.$spc.System.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {"b":1048577,"u":655361,"l":[{"t":1543043,"n":"NOTIF_TYPECONVERTED","d":1543043,"h":4296510339,"f":33},{"t":1543043,"n":"NOTIF_CONVERTWARNING","d":1543043,"h":8591477635,"f":33},{"t":1543043,"n":"ERROR_REFTOINVALIDASSEMBLY","d":1543043,"h":12886444931,"f":33}],"c":[{"n":".ctor","o":"$ctor$3","d":1543043,"h":17181412227,"f":1}],"i":[57212929,63766529,57671681,57344001],"h":1543043}; }
            static get $b() { return $.$spc.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IComparable, $.$spc.System.ISpanFormattable, $.$spc.System.IFormattable, $.$spc.System.IConvertible ]; }
            static get $fullName() { return `System.Runtime.InteropServices.ExporterEventKind`; }
        });
        
        $asm.$str("$sris.System.Runtime.InteropServices.Marshalling.ComInterfaceOptions", ($self) => class ComInterfaceOptions extends $.$spc.System.Enum
        {
            static None = 0;
            static ManagedObjectWrapper = 1;
            static ComObjectWrapper = 2;
            static $map;
            static get Map()
            {
                return this.$map ??= 
                {
                    "None": 0n,
                    "ManagedObjectWrapper": 1n,
                    "ComObjectWrapper": 2n
                };
            }
            static $h = 2132867;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static get $eut() { return $.$spc.System.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {"b":1048577,"u":655361,"l":[{"t":2132867,"n":"None","d":2132867,"h":4297100163,"f":33,"a":[{"t":33161217,"c":4328128513,"a":[{"v":1,"t":33226753}]}]},{"t":2132867,"n":"ManagedObjectWrapper","d":2132867,"h":8592067459,"f":33},{"t":2132867,"n":"ComObjectWrapper","d":2132867,"h":12887034755,"f":33}],"c":[{"n":".ctor","o":"$ctor$3","d":2132867,"h":17182002051,"f":1}],"i":[57212929,63766529,57671681,57344001],"h":2132867,"a":[{"t":47644673,"c":4342611969}]}; }
            static get $b() { return $.$spc.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IComparable, $.$spc.System.ISpanFormattable, $.$spc.System.IFormattable, $.$spc.System.IConvertible ]; }
            static get $fullName() { return `System.Runtime.InteropServices.Marshalling.ComInterfaceOptions`; }
        });
        
        $asm.$str("$sris.System.Runtime.InteropServices.RegistrationClassContext", ($self) => class RegistrationClassContext extends $.$spc.System.Enum
        {
            static InProcessServer = 1;
            static InProcessHandler = 2;
            static LocalServer = 4;
            static InProcessServer16 = 8;
            static RemoteServer = 16;
            static InProcessHandler16 = 32;
            static Reserved1 = 64;
            static Reserved2 = 128;
            static Reserved3 = 256;
            static Reserved4 = 512;
            static NoCodeDownload = 1024;
            static Reserved5 = 2048;
            static NoCustomMarshal = 4096;
            static EnableCodeDownload = 8192;
            static NoFailureLog = 16384;
            static DisableActivateAsActivator = 32768;
            static EnableActivateAsActivator = 65536;
            static FromDefaultContext = 131072;
            static $map;
            static get Map()
            {
                return this.$map ??= 
                {
                    "InProcessServer": 1n,
                    "InProcessHandler": 2n,
                    "LocalServer": 4n,
                    "InProcessServer16": 8n,
                    "RemoteServer": 16n,
                    "InProcessHandler16": 32n,
                    "Reserved1": 64n,
                    "Reserved2": 128n,
                    "Reserved3": 256n,
                    "Reserved4": 512n,
                    "NoCodeDownload": 1024n,
                    "Reserved5": 2048n,
                    "NoCustomMarshal": 4096n,
                    "EnableCodeDownload": 8192n,
                    "NoFailureLog": 16384n,
                    "DisableActivateAsActivator": 32768n,
                    "EnableActivateAsActivator": 65536n,
                    "FromDefaultContext": 131072n
                };
            }
            static $h = 3902339;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static get $eut() { return $.$spc.System.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {"b":1048577,"u":655361,"l":[{"t":3902339,"n":"InProcessServer","d":3902339,"h":4298869635,"f":33},{"t":3902339,"n":"InProcessHandler","d":3902339,"h":8593836931,"f":33},{"t":3902339,"n":"LocalServer","d":3902339,"h":12888804227,"f":33},{"t":3902339,"n":"InProcessServer16","d":3902339,"h":17183771523,"f":33},{"t":3902339,"n":"RemoteServer","d":3902339,"h":21478738819,"f":33},{"t":3902339,"n":"InProcessHandler16","d":3902339,"h":25773706115,"f":33},{"t":3902339,"n":"Reserved1","d":3902339,"h":30068673411,"f":33},{"t":3902339,"n":"Reserved2","d":3902339,"h":34363640707,"f":33},{"t":3902339,"n":"Reserved3","d":3902339,"h":38658608003,"f":33},{"t":3902339,"n":"Reserved4","d":3902339,"h":42953575299,"f":33},{"t":3902339,"n":"NoCodeDownload","d":3902339,"h":47248542595,"f":33},{"t":3902339,"n":"Reserved5","d":3902339,"h":51543509891,"f":33},{"t":3902339,"n":"NoCustomMarshal","d":3902339,"h":55838477187,"f":33},{"t":3902339,"n":"EnableCodeDownload","d":3902339,"h":60133444483,"f":33},{"t":3902339,"n":"NoFailureLog","d":3902339,"h":64428411779,"f":33},{"t":3902339,"n":"DisableActivateAsActivator","d":3902339,"h":68723379075,"f":33},{"t":3902339,"n":"EnableActivateAsActivator","d":3902339,"h":73018346371,"f":33},{"t":3902339,"n":"FromDefaultContext","d":3902339,"h":77313313667,"f":33}],"c":[{"n":".ctor","o":"$ctor$3","d":3902339,"h":81608280963,"f":1}],"i":[57212929,63766529,57671681,57344001],"h":3902339,"a":[{"t":47644673,"c":4342611969}]}; }
            static get $b() { return $.$spc.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IComparable, $.$spc.System.ISpanFormattable, $.$spc.System.IFormattable, $.$spc.System.IConvertible ]; }
            static get $fullName() { return `System.Runtime.InteropServices.RegistrationClassContext`; }
        });
        
        $asm.$str("$sris.System.Runtime.InteropServices.RegistrationConnectionType", ($self) => class RegistrationConnectionType extends $.$spc.System.Enum
        {
            static SingleUse = 0;
            static MultipleUse = 1;
            static MultiSeparate = 2;
            static Suspended = 4;
            static Surrogate = 8;
            static $map;
            static get Map()
            {
                return this.$map ??= 
                {
                    "SingleUse": 0n,
                    "MultipleUse": 1n,
                    "MultiSeparate": 2n,
                    "Suspended": 4n,
                    "Surrogate": 8n
                };
            }
            static $h = 3967875;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static get $eut() { return $.$spc.System.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {"b":1048577,"u":655361,"l":[{"t":3967875,"n":"SingleUse","d":3967875,"h":4298935171,"f":33},{"t":3967875,"n":"MultipleUse","d":3967875,"h":8593902467,"f":33},{"t":3967875,"n":"MultiSeparate","d":3967875,"h":12888869763,"f":33},{"t":3967875,"n":"Suspended","d":3967875,"h":17183837059,"f":33},{"t":3967875,"n":"Surrogate","d":3967875,"h":21478804355,"f":33}],"c":[{"n":".ctor","o":"$ctor$3","d":3967875,"h":25773771651,"f":1}],"i":[57212929,63766529,57671681,57344001],"h":3967875,"a":[{"t":47644673,"c":4342611969}]}; }
            static get $b() { return $.$spc.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IComparable, $.$spc.System.ISpanFormattable, $.$spc.System.IFormattable, $.$spc.System.IConvertible ]; }
            static get $fullName() { return `System.Runtime.InteropServices.RegistrationConnectionType`; }
        });
        
        $asm.$str("$sris.System.Runtime.InteropServices.TypeLibFuncFlags", ($self) => class TypeLibFuncFlags extends $.$spc.System.Enum
        {
            static FRestricted = 1;
            static FSource = 2;
            static FBindable = 4;
            static FRequestEdit = 8;
            static FDisplayBind = 16;
            static FDefaultBind = 32;
            static FHidden = 64;
            static FUsesGetLastError = 128;
            static FDefaultCollelem = 256;
            static FUiDefault = 512;
            static FNonBrowsable = 1024;
            static FReplaceable = 2048;
            static FImmediateBind = 4096;
            static $map;
            static get Map()
            {
                return this.$map ??= 
                {
                    "FRestricted": 1n,
                    "FSource": 2n,
                    "FBindable": 4n,
                    "FRequestEdit": 8n,
                    "FDisplayBind": 16n,
                    "FDefaultBind": 32n,
                    "FHidden": 64n,
                    "FUsesGetLastError": 128n,
                    "FDefaultCollelem": 256n,
                    "FUiDefault": 512n,
                    "FNonBrowsable": 1024n,
                    "FReplaceable": 2048n,
                    "FImmediateBind": 4096n
                };
            }
            static $h = 4164483;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static get $eut() { return $.$spc.System.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {"b":1048577,"u":655361,"l":[{"t":4164483,"n":"FRestricted","d":4164483,"h":4299131779,"f":33},{"t":4164483,"n":"FSource","d":4164483,"h":8594099075,"f":33},{"t":4164483,"n":"FBindable","d":4164483,"h":12889066371,"f":33},{"t":4164483,"n":"FRequestEdit","d":4164483,"h":17184033667,"f":33},{"t":4164483,"n":"FDisplayBind","d":4164483,"h":21479000963,"f":33},{"t":4164483,"n":"FDefaultBind","d":4164483,"h":25773968259,"f":33},{"t":4164483,"n":"FHidden","d":4164483,"h":30068935555,"f":33},{"t":4164483,"n":"FUsesGetLastError","d":4164483,"h":34363902851,"f":33},{"t":4164483,"n":"FDefaultCollelem","d":4164483,"h":38658870147,"f":33},{"t":4164483,"n":"FUiDefault","d":4164483,"h":42953837443,"f":33},{"t":4164483,"n":"FNonBrowsable","d":4164483,"h":47248804739,"f":33},{"t":4164483,"n":"FReplaceable","d":4164483,"h":51543772035,"f":33},{"t":4164483,"n":"FImmediateBind","d":4164483,"h":55838739331,"f":33}],"c":[{"n":".ctor","o":"$ctor$3","d":4164483,"h":60133706627,"f":1}],"i":[57212929,63766529,57671681,57344001],"h":4164483,"a":[{"t":47644673,"c":4342611969}]}; }
            static get $b() { return $.$spc.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IComparable, $.$spc.System.ISpanFormattable, $.$spc.System.IFormattable, $.$spc.System.IConvertible ]; }
            static get $fullName() { return `System.Runtime.InteropServices.TypeLibFuncFlags`; }
        });
        
        $asm.$str("$sris.System.Runtime.InteropServices.TypeLibTypeFlags", ($self) => class TypeLibTypeFlags extends $.$spc.System.Enum
        {
            static FAppObject = 1;
            static FCanCreate = 2;
            static FLicensed = 4;
            static FPreDeclId = 8;
            static FHidden = 16;
            static FControl = 32;
            static FDual = 64;
            static FNonExtensible = 128;
            static FOleAutomation = 256;
            static FRestricted = 512;
            static FAggregatable = 1024;
            static FReplaceable = 2048;
            static FDispatchable = 4096;
            static FReverseBind = 8192;
            static $map;
            static get Map()
            {
                return this.$map ??= 
                {
                    "FAppObject": 1n,
                    "FCanCreate": 2n,
                    "FLicensed": 4n,
                    "FPreDeclId": 8n,
                    "FHidden": 16n,
                    "FControl": 32n,
                    "FDual": 64n,
                    "FNonExtensible": 128n,
                    "FOleAutomation": 256n,
                    "FRestricted": 512n,
                    "FAggregatable": 1024n,
                    "FReplaceable": 2048n,
                    "FDispatchable": 4096n,
                    "FReverseBind": 8192n
                };
            }
            static $h = 4361091;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static get $eut() { return $.$spc.System.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {"b":1048577,"u":655361,"l":[{"t":4361091,"n":"FAppObject","d":4361091,"h":4299328387,"f":33},{"t":4361091,"n":"FCanCreate","d":4361091,"h":8594295683,"f":33},{"t":4361091,"n":"FLicensed","d":4361091,"h":12889262979,"f":33},{"t":4361091,"n":"FPreDeclId","d":4361091,"h":17184230275,"f":33},{"t":4361091,"n":"FHidden","d":4361091,"h":21479197571,"f":33},{"t":4361091,"n":"FControl","d":4361091,"h":25774164867,"f":33},{"t":4361091,"n":"FDual","d":4361091,"h":30069132163,"f":33},{"t":4361091,"n":"FNonExtensible","d":4361091,"h":34364099459,"f":33},{"t":4361091,"n":"FOleAutomation","d":4361091,"h":38659066755,"f":33},{"t":4361091,"n":"FRestricted","d":4361091,"h":42954034051,"f":33},{"t":4361091,"n":"FAggregatable","d":4361091,"h":47249001347,"f":33},{"t":4361091,"n":"FReplaceable","d":4361091,"h":51543968643,"f":33},{"t":4361091,"n":"FDispatchable","d":4361091,"h":55838935939,"f":33},{"t":4361091,"n":"FReverseBind","d":4361091,"h":60133903235,"f":33}],"c":[{"n":".ctor","o":"$ctor$3","d":4361091,"h":64428870531,"f":1}],"i":[57212929,63766529,57671681,57344001],"h":4361091,"a":[{"t":47644673,"c":4342611969}]}; }
            static get $b() { return $.$spc.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IComparable, $.$spc.System.ISpanFormattable, $.$spc.System.IFormattable, $.$spc.System.IConvertible ]; }
            static get $fullName() { return `System.Runtime.InteropServices.TypeLibTypeFlags`; }
        });
        
        $asm.$str("$sris.System.Runtime.InteropServices.TypeLibVarFlags", ($self) => class TypeLibVarFlags extends $.$spc.System.Enum
        {
            static FReadOnly = 1;
            static FSource = 2;
            static FBindable = 4;
            static FRequestEdit = 8;
            static FDisplayBind = 16;
            static FDefaultBind = 32;
            static FHidden = 64;
            static FRestricted = 128;
            static FDefaultCollelem = 256;
            static FUiDefault = 512;
            static FNonBrowsable = 1024;
            static FReplaceable = 2048;
            static FImmediateBind = 4096;
            static $map;
            static get Map()
            {
                return this.$map ??= 
                {
                    "FReadOnly": 1n,
                    "FSource": 2n,
                    "FBindable": 4n,
                    "FRequestEdit": 8n,
                    "FDisplayBind": 16n,
                    "FDefaultBind": 32n,
                    "FHidden": 64n,
                    "FRestricted": 128n,
                    "FDefaultCollelem": 256n,
                    "FUiDefault": 512n,
                    "FNonBrowsable": 1024n,
                    "FReplaceable": 2048n,
                    "FImmediateBind": 4096n
                };
            }
            static $h = 4492163;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static get $eut() { return $.$spc.System.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {"b":1048577,"u":655361,"l":[{"t":4492163,"n":"FReadOnly","d":4492163,"h":4299459459,"f":33},{"t":4492163,"n":"FSource","d":4492163,"h":8594426755,"f":33},{"t":4492163,"n":"FBindable","d":4492163,"h":12889394051,"f":33},{"t":4492163,"n":"FRequestEdit","d":4492163,"h":17184361347,"f":33},{"t":4492163,"n":"FDisplayBind","d":4492163,"h":21479328643,"f":33},{"t":4492163,"n":"FDefaultBind","d":4492163,"h":25774295939,"f":33},{"t":4492163,"n":"FHidden","d":4492163,"h":30069263235,"f":33},{"t":4492163,"n":"FRestricted","d":4492163,"h":34364230531,"f":33},{"t":4492163,"n":"FDefaultCollelem","d":4492163,"h":38659197827,"f":33},{"t":4492163,"n":"FUiDefault","d":4492163,"h":42954165123,"f":33},{"t":4492163,"n":"FNonBrowsable","d":4492163,"h":47249132419,"f":33},{"t":4492163,"n":"FReplaceable","d":4492163,"h":51544099715,"f":33},{"t":4492163,"n":"FImmediateBind","d":4492163,"h":55839067011,"f":33}],"c":[{"n":".ctor","o":"$ctor$3","d":4492163,"h":60134034307,"f":1}],"i":[57212929,63766529,57671681,57344001],"h":4492163,"a":[{"t":47644673,"c":4342611969}]}; }
            static get $b() { return $.$spc.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IComparable, $.$spc.System.ISpanFormattable, $.$spc.System.IFormattable, $.$spc.System.IConvertible ]; }
            static get $fullName() { return `System.Runtime.InteropServices.TypeLibVarFlags`; }
        });
        
        $asm.$cls("$sris.System.Runtime.InteropServices.Marshalling.ComObject", ($self) => class ComObject extends $.$spc.System.Object
        {
            /*bool*/ static BuiltInComSupported = false;
            /*bool*/ static ComImportInteropEnabled = false;
            /*void**/ _instancePointer;
            /*object?*/ _runtimeCallableWrapper = null;
            /*bool*/ _released = false;
            $ctor$1(/*IIUnknownInterfaceDetailsStrategy*/ interfaceDetailsStrategy, /*IIUnknownStrategy*/ iunknownStrategy, /*IIUnknownCacheStrategy*/ cacheStrategy, /*void**/ thisPointer)
            {
                super.$ctor();
                {
                    this.InterfaceDetailsStrategy = interfaceDetailsStrategy;
                    this.IUnknownStrategy = iunknownStrategy;
                    this.CacheStrategy = cacheStrategy;
                    this._instancePointer = this.IUnknownStrategy.System$Runtime$InteropServices$Marshalling$IIUnknownStrategy$CreateInstancePointer(thisPointer);
                    if ($.$spc.System.OperatingSystem.IsWindows() && $.$sris.System.Runtime.InteropServices.Marshalling.ComObject.BuiltInComSupported && $.$sris.System.Runtime.InteropServices.Marshalling.ComObject.ComImportInteropEnabled)
                    {
                        this._runtimeCallableWrapper = $.$spc.System.Runtime.InteropServices.Marshal.GetObjectForIUnknown($.$spc.System.IntPtr.op_Explicit$2(thisPointer));
                        $.$spc.System.Diagnostics.Debug.Assert$1($.$spc.System.Runtime.InteropServices.Marshal.IsComObject(this._runtimeCallableWrapper), "Marshal.IsComObject(_runtimeCallableWrapper)");
                    }
                }
                return this;
            }
            $dtor()
            {
                this.CacheStrategy.System$Runtime$InteropServices$Marshalling$IIUnknownCacheStrategy$Clear(this.IUnknownStrategy);
                this.IUnknownStrategy.System$Runtime$InteropServices$Marshalling$IIUnknownStrategy$Release(this._instancePointer);
            }
            /*IIUnknownInterfaceDetailsStrategy*/ InterfaceDetailsStrategy = null;
            /*IIUnknownStrategy*/ IUnknownStrategy = null;
            /*IIUnknownCacheStrategy*/ CacheStrategy = null;
            /*bool*/ UniqueInstance = false;
            /*void */ FinalRelease()
            {
                if (this.UniqueInstance && !$.$spc.System.Threading.Interlocked.Exchange$14($.$spc.System.Boolean, $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateObjectReferenceT($.$spc.System.Boolean, () => this._released, ($v) => this._released = $v, null), true))
                {
                    $.$spc.System.GC.SuppressFinalize(this);
                    this.CacheStrategy.System$Runtime$InteropServices$Marshalling$IIUnknownCacheStrategy$Clear(this.IUnknownStrategy);
                    this.IUnknownStrategy.System$Runtime$InteropServices$Marshalling$IIUnknownStrategy$Release(this._instancePointer);
                }
            }
            /*RuntimeTypeHandle */ System$Runtime$InteropServices$IDynamicInterfaceCastable$GetInterfaceImplementation(/*RuntimeTypeHandle*/ interfaceType)
            {
                /*IIUnknownCacheStrategy.TableInfo*/ let info;
                /*int*/ let qiResult;
                if (!this.LookUpVTableInfo(interfaceType, $.$ref(() => info, ($v) => info = $v, $.$sris.System.Runtime.InteropServices.Marshalling.IIUnknownCacheStrategy.TableInfo), $.$ref(() => qiResult, ($v) => qiResult = $v, $.$spc.System.Int32)))
                {
                    $.$spc.System.Runtime.InteropServices.Marshal.ThrowExceptionForHR(qiResult);
                }
                return info.ManagedType;
            }
            /*bool */ System$Runtime$InteropServices$IDynamicInterfaceCastable$IsInterfaceImplemented(/*RuntimeTypeHandle*/ interfaceType, /*bool*/ throwIfNotImplemented)
            {
                /*int*/ let qiResult;
                if (!this.LookUpVTableInfo(interfaceType, $.$discardRef(), $.$ref(() => qiResult, ($v) => qiResult = $v, $.$spc.System.Int32)))
                {
                    if (throwIfNotImplemented)
                    {
                        $.$spc.System.Runtime.InteropServices.Marshal.ThrowExceptionForHR(qiResult);
                    }
                    return false;
                }
                return true;
            }
            /*bool */ LookUpVTableInfo(/*RuntimeTypeHandle*/ handle, /*out IIUnknownCacheStrategy.TableInfo*/ result, /*out int*/ qiHResult)
            {
                $.$spc.System.ObjectDisposedException.ThrowIf(this._released, this);
                qiHResult.$v = 0;
                if (!this.CacheStrategy.System$Runtime$InteropServices$Marshalling$IIUnknownCacheStrategy$TryGetTableInfo(handle, result))
                {
                    /*IIUnknownDerivedDetails?*/ let details = this.InterfaceDetailsStrategy.System$Runtime$InteropServices$Marshalling$IIUnknownInterfaceDetailsStrategy$GetIUnknownDerivedDetails(handle);
                    if (details === null)
                    {
                        return false;
                    }
                    /*void**/ let ppv;
                    /*int*/ let hr = this.IUnknownStrategy.System$Runtime$InteropServices$Marshalling$IIUnknownStrategy$QueryInterface(this._instancePointer, $.$ref(() => details.System$Runtime$InteropServices$Marshalling$IIUnknownDerivedDetails$Iid, ), $.$ref(() => ppv, ($v) => ppv = $v, $.$typePointer($.$spc.System.Void)));
                    if (hr < 0)
                    {
                        qiHResult.$v = hr;
                        return false;
                    }
                    result.$v = this.CacheStrategy.System$Runtime$InteropServices$Marshalling$IIUnknownCacheStrategy$ConstructTableInfo(handle, details, ppv);
                    if (!this.CacheStrategy.System$Runtime$InteropServices$Marshalling$IIUnknownCacheStrategy$TrySetTableInfo(handle, result.$v))
                    {
                        /*bool*/ let found = this.CacheStrategy.System$Runtime$InteropServices$Marshalling$IIUnknownCacheStrategy$TryGetTableInfo(handle, result);
                        $.$spc.System.Diagnostics.Debug.Assert$1(found, "found");
                        _ = this.IUnknownStrategy.System$Runtime$InteropServices$Marshalling$IIUnknownStrategy$Release(ppv);
                    }
                }
                return true;
            }
            /*VirtualMethodTableInfo */ System$Runtime$InteropServices$Marshalling$IUnmanagedVirtualMethodTableProvider$GetVirtualMethodTableInfoForKey(/*Type*/ type)
            {
                /*IIUnknownCacheStrategy.TableInfo*/ let result;
                /*int*/ let qiHResult;
                if (!this.LookUpVTableInfo(type.TypeHandle, $.$ref(() => result, ($v) => result = $v, $.$sris.System.Runtime.InteropServices.Marshalling.IIUnknownCacheStrategy.TableInfo), $.$ref(() => qiHResult, ($v) => qiHResult = $v, $.$spc.System.Int32)))
                {
                    $.$spc.System.Runtime.InteropServices.Marshal.ThrowExceptionForHR(qiHResult);
                }
                return new $.$sris.System.Runtime.InteropServices.Marshalling.VirtualMethodTableInfo().$ctor$2(result.ThisPtr, result.Table);
            }
            /*object */ System$Runtime$InteropServices$Marshalling$ComImportInteropInterfaceDetailsStrategy$IComImportAdapter$GetRuntimeCallableWrapper()
            {
                $.$spc.System.Diagnostics.Debug.Assert$1(this._runtimeCallableWrapper !== null, "_runtimeCallableWrapper != null");
                return this._runtimeCallableWrapper;
            }
            //default member initializer
            constructor()
            {
                super();
                this._instancePointer = $.$default($.$typePointer($.$spc.System.Void));
                this.UniqueInstance = false;
                $.$finalizer(this);
            }
            //Static Initializer
            static $sinit()
            {
                {
                    /*bool*/ let supported;
                    this.BuiltInComSupported = $.$spc.System.AppContext.TryGetSwitch("System.Runtime.InteropServices.BuiltInComInterop.IsSupported", $.$ref(() => supported, ($v) => supported = $v, $.$spc.System.Boolean)) ? supported : true;
                }
                {
                    /*bool*/ let enabled;
                    this.ComImportInteropEnabled = $.$spc.System.AppContext.TryGetSwitch("System.Runtime.InteropServices.Marshalling.EnableGeneratedComInterfaceComImportInterop", $.$ref(() => enabled, ($v) => enabled = $v, $.$spc.System.Boolean)) ? enabled : false;
                }
            }
            static $h = 2198403;
            static $f = 0b10010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":262145,"g":{"r":0,"d":0,"h":12887100291,"f":40},"n":"BuiltInComSupported","d":2198403,"h":8592132995,"f":40},{"p":262145,"g":{"r":0,"d":0,"h":25772002179,"f":40},"n":"ComImportInteropEnabled","d":2198403,"h":21477034883,"f":40},{"p":3312515,"g":{"r":0,"d":0,"h":60131740547,"f":2},"n":"InterfaceDetailsStrategy","d":2198403,"h":55836773251,"f":2},{"p":3443587,"g":{"r":0,"d":0,"h":73016642435,"f":2},"n":"IUnknownStrategy","d":2198403,"h":68721675139,"f":2},{"p":3115907,"g":{"r":0,"d":0,"h":85901544323,"f":2},"n":"CacheStrategy","d":2198403,"h":81606577027,"f":2},{"p":262145,"g":{"r":0,"d":0,"h":98786446211,"f":8},"s":{"r":0,"d":0,"h":103081413507,"f":8},"n":"UniqueInstance","d":2198403,"h":94491478915,"f":8}],"m":[{"r":65537,"n":"FinalRelease","d":2198403,"h":107376380803,"f":1},{"r":262145,"p":[{"n":"handle","p":116064257},{"n":"result","p":3181443,"f":2},{"n":"qiHResult","p":655361,"f":2}],"n":"LookUpVTableInfo","d":2198403,"h":120261282691,"f":2}],"l":[{"t":0,"n":"_instancePointer","d":2198403,"h":30066969475,"f":2},{"t":131073,"n":"_runtimeCallableWrapper","d":2198403,"h":34361936771,"f":2},{"t":262145,"n":"_released","d":2198403,"h":38656904067,"f":2}],"c":[{"p":[{"n":"interfaceDetailsStrategy","p":3312515},{"n":"iunknownStrategy","p":3443587},{"n":"cacheStrategy","p":3115907},{"n":"thisPointer","p":0}],"n":".ctor","o":"$ctor$1","d":2198403,"h":42951871363,"f":8}],"i":[104792065,3574659,2001795],"h":2198403}; }
            static get $b() { return $.$spc.System.Object; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.Runtime.InteropServices.IDynamicInterfaceCastable, $.$sris.System.Runtime.InteropServices.Marshalling.IUnmanagedVirtualMethodTableProvider, $.$sris.System.Runtime.InteropServices.Marshalling.ComImportInteropInterfaceDetailsStrategy.IComImportAdapter ]; }
            static get $fullName() { return `System.Runtime.InteropServices.Marshalling.ComObject`; }
        });
	});
})(window, window.NetJs.$boot(), ...window.NetJs.$require("NetJs.System.Private.CoreLib", "NetJs.System.Collections", "NetJs.System.Diagnostics.Tracing", "NetJs.System.Threading", "NetJs.System.Collections.Concurrent"))