
(function ($global, $, $spc, $sc, $sdt, $st, $scc) {
    "use strict";
    let _;
    
    
    
	$.$asm(
    "NetJs.System.Runtime.InteropServices", 
    {"h":54146,"f":"System.Runtime.InteropServices","v":"1.0.35.0","a":[{"t":115146753,"c":13000048641,"a":[{"v":".NETCoreApp,Version=v10.0","t":1310721}],"n":[{"n":"FrameworkDisplayName","v":".NET 10.0","t":1310721}]},{"t":73596929,"c":4368564225,"a":[{"v":"SIT","t":1310721}]},{"t":73662465,"c":4368629761,"a":[{"v":"Debug","t":1310721}]},{"t":74121217,"c":4369088513,"a":[{"v":"1.0.35.0","t":1310721}]},{"t":74252289,"c":4369219585,"a":[{"v":"1.0.35\u002Bbeaaf5d41a0179d1ed930cf3efa03ea73d37a2ca","t":1310721}]},{"t":75104257,"c":4370071553,"a":[{"v":"NetJs.System.Runtime.InteropServices","t":1310721}]},{"t":75235329,"c":4370202625,"a":[{"v":"NetJs.System.Runtime.InteropServices","t":1310721}]},{"t":75366401,"c":4370333697,"a":[{"v":"1.0.35.0","t":1310721}]},{"t":115212289,"c":4410179585,"a":[{"v":"browser1.0","t":1310721}]},{"t":114950145,"c":4409917441,"a":[{"v":"browser1.0","t":1310721}]}],"m":[]},
    function($asm)
	{
        
        
        $asm.$cls("$sris.System.Runtime.InteropServices.ComTypes.IAdviseSink", ($self) => class IAdviseSink
        {
            static $h = 1037186;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {"m":[{"r":65537,"p":[{"n":"format","p":971650,"f":4,"a":[{"t":104857601,"c":4399824897}]},{"n":"stgmedium","p":1364866,"f":4,"a":[{"t":104857601,"c":4399824897}]}],"n":"OnDataChange","o":"System$Runtime$InteropServices$ComTypes$IAdviseSink$OnDataChange","d":1037186,"h":4296004482,"f":257,"a":[{"t":109182977,"c":4404150273}]},{"r":65537,"p":[{"n":"aspect","p":655361},{"n":"index","p":655361}],"n":"OnViewChange","o":"System$Runtime$InteropServices$ComTypes$IAdviseSink$OnViewChange","d":1037186,"h":8590971778,"f":257,"a":[{"t":109182977,"c":4404150273}]},{"r":65537,"p":[{"n":"moniker","p":100925441}],"n":"OnRename","o":"System$Runtime$InteropServices$ComTypes$IAdviseSink$OnRename","d":1037186,"h":12885939074,"f":257,"a":[{"t":109182977,"c":4404150273}]},{"r":65537,"n":"OnSave","o":"System$Runtime$InteropServices$ComTypes$IAdviseSink$OnSave","d":1037186,"h":17180906370,"f":257,"a":[{"t":109182977,"c":4404150273}]},{"r":65537,"n":"OnClose","o":"System$Runtime$InteropServices$ComTypes$IAdviseSink$OnClose","d":1037186,"h":21475873666,"f":257,"a":[{"t":109182977,"c":4404150273}]}],"h":1037186,"a":[{"t":99155969,"c":4394123265},{"t":104398849,"c":4399366145,"a":[{"v":"0000010F-0000-0000-C000-000000000046","t":1310721}]},{"t":33161217,"c":4328128513,"a":[{"v":1,"t":33226753}]},{"t":104923137,"c":4399890433,"a":[{"v":1,"t":99221505}]}]}; }
            static get $fullName() { return `System.Runtime.InteropServices.ComTypes.IAdviseSink`; }
        });
        
        $asm.$cls("$sris.System.Runtime.InteropServices.ComTypes.IDataObject", ($self) => class IDataObject
        {
            static $h = 1102722;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {"m":[{"r":65537,"p":[{"n":"format","p":971650,"f":4,"a":[{"t":104857601,"c":4399824897}]},{"n":"medium","p":1364866,"f":2}],"n":"GetData","o":"System$Runtime$InteropServices$ComTypes$IDataObject$GetData","d":1102722,"h":4296070018,"f":257},{"r":65537,"p":[{"n":"format","p":971650,"f":4,"a":[{"t":104857601,"c":4399824897}]},{"n":"medium","p":1364866,"f":4}],"n":"GetDataHere","o":"System$Runtime$InteropServices$ComTypes$IDataObject$GetDataHere","d":1102722,"h":8591037314,"f":257},{"r":655361,"p":[{"n":"format","p":971650,"f":4,"a":[{"t":104857601,"c":4399824897}]}],"n":"QueryGetData","o":"System$Runtime$InteropServices$ComTypes$IDataObject$QueryGetData","d":1102722,"h":12886004610,"f":257,"a":[{"t":109182977,"c":4404150273}]},{"r":655361,"p":[{"n":"formatIn","p":971650,"f":4,"a":[{"t":104857601,"c":4399824897}]},{"n":"formatOut","p":971650,"f":2}],"n":"GetCanonicalFormatEtc","o":"System$Runtime$InteropServices$ComTypes$IDataObject$GetCanonicalFormatEtc","d":1102722,"h":17180971906,"f":257,"a":[{"t":109182977,"c":4404150273}]},{"r":65537,"p":[{"n":"formatIn","p":971650,"f":4,"a":[{"t":104857601,"c":4399824897}]},{"n":"medium","p":1364866,"f":4,"a":[{"t":104857601,"c":4399824897}]},{"n":"release","p":262145,"a":[{"t":105709569,"c":8695644161,"a":[{"v":2,"t":110886913}]}]}],"n":"SetData","o":"System$Runtime$InteropServices$ComTypes$IDataObject$SetData","d":1102722,"h":21475939202,"f":257},{"r":1168258,"p":[{"n":"direction","p":840578}],"n":"EnumFormatEtc","o":"System$Runtime$InteropServices$ComTypes$IDataObject$EnumFormatEtc","d":1102722,"h":25770906498,"f":257},{"r":655361,"p":[{"n":"pFormatetc","p":971650,"f":4,"a":[{"t":104857601,"c":4399824897}]},{"n":"advf","p":775042},{"n":"adviseSink","p":1037186},{"n":"connection","p":655361,"f":2}],"n":"DAdvise","o":"System$Runtime$InteropServices$ComTypes$IDataObject$DAdvise","d":1102722,"h":30065873794,"f":257,"a":[{"t":109182977,"c":4404150273}]},{"r":65537,"p":[{"n":"connection","p":655361}],"n":"DUnadvise","o":"System$Runtime$InteropServices$ComTypes$IDataObject$DUnadvise","d":1102722,"h":34360841090,"f":257},{"r":655361,"p":[{"n":"enumAdvise","p":1233794,"f":2}],"n":"EnumDAdvise","o":"System$Runtime$InteropServices$ComTypes$IDataObject$EnumDAdvise","d":1102722,"h":38655808386,"f":257,"a":[{"t":109182977,"c":4404150273}]}],"h":1102722,"a":[{"t":23396353,"c":8613330945,"a":[{"v":false,"t":262145}]},{"t":99155969,"c":4394123265},{"t":104398849,"c":4399366145,"a":[{"v":"0000010E-0000-0000-C000-000000000046","t":1310721}]},{"t":104923137,"c":4399890433,"a":[{"v":1,"t":99221505}]}]}; }
            static get $fullName() { return `System.Runtime.InteropServices.ComTypes.IDataObject`; }
        });
        
        $asm.$cls("$sris.System.Runtime.InteropServices.ComTypes.IEnumFORMATETC", ($self) => class IEnumFORMATETC
        {
            static $h = 1168258;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {"m":[{"r":655361,"p":[{"n":"celt","p":655361},{"n":"rgelt","p":0,"a":[{"t":108789761,"c":4403757057},{"t":105709569,"c":8695644161,"a":[{"v":42,"t":110886913}],"n":[{"n":"SizeParamIndex","v":0,"t":524289}]}]},{"n":"pceltFetched","p":0,"a":[{"t":108789761,"c":4403757057},{"t":105709569,"c":8695644161,"a":[{"v":42,"t":110886913}]}]}],"n":"Next","o":"System$Runtime$InteropServices$ComTypes$IEnumFORMATETC$Next","d":1168258,"h":4296135554,"f":257,"a":[{"t":109182977,"c":4404150273}]},{"r":655361,"p":[{"n":"celt","p":655361}],"n":"Skip","o":"System$Runtime$InteropServices$ComTypes$IEnumFORMATETC$Skip","d":1168258,"h":8591102850,"f":257,"a":[{"t":109182977,"c":4404150273}]},{"r":655361,"n":"Reset","o":"System$Runtime$InteropServices$ComTypes$IEnumFORMATETC$Reset","d":1168258,"h":12886070146,"f":257,"a":[{"t":109182977,"c":4404150273}]},{"r":65537,"p":[{"n":"newEnum","p":1168258,"f":2}],"n":"Clone","o":"System$Runtime$InteropServices$ComTypes$IEnumFORMATETC$Clone","d":1168258,"h":17181037442,"f":257}],"h":1168258,"a":[{"t":99155969,"c":4394123265},{"t":104398849,"c":4399366145,"a":[{"v":"00000103-0000-0000-C000-000000000046","t":1310721}]},{"t":33161217,"c":4328128513,"a":[{"v":1,"t":33226753}]},{"t":104923137,"c":4399890433,"a":[{"v":1,"t":99221505}]}]}; }
            static get $fullName() { return `System.Runtime.InteropServices.ComTypes.IEnumFORMATETC`; }
        });
        
        $asm.$cls("$sris.System.Runtime.InteropServices.ComTypes.IEnumSTATDATA", ($self) => class IEnumSTATDATA
        {
            static $h = 1233794;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {"m":[{"r":655361,"p":[{"n":"celt","p":655361},{"n":"rgelt","p":0,"a":[{"t":108789761,"c":4403757057},{"t":105709569,"c":8695644161,"a":[{"v":42,"t":110886913}],"n":[{"n":"SizeParamIndex","v":0,"t":524289}]}]},{"n":"pceltFetched","p":0,"a":[{"t":108789761,"c":4403757057},{"t":105709569,"c":8695644161,"a":[{"v":42,"t":110886913}],"n":[{"n":"SizeConst","v":1,"t":655361}]}]}],"n":"Next","o":"System$Runtime$InteropServices$ComTypes$IEnumSTATDATA$Next","d":1233794,"h":4296201090,"f":257,"a":[{"t":109182977,"c":4404150273}]},{"r":655361,"p":[{"n":"celt","p":655361}],"n":"Skip","o":"System$Runtime$InteropServices$ComTypes$IEnumSTATDATA$Skip","d":1233794,"h":8591168386,"f":257,"a":[{"t":109182977,"c":4404150273}]},{"r":655361,"n":"Reset","o":"System$Runtime$InteropServices$ComTypes$IEnumSTATDATA$Reset","d":1233794,"h":12886135682,"f":257,"a":[{"t":109182977,"c":4404150273}]},{"r":65537,"p":[{"n":"newEnum","p":1233794,"f":2}],"n":"Clone","o":"System$Runtime$InteropServices$ComTypes$IEnumSTATDATA$Clone","d":1233794,"h":17181102978,"f":257}],"h":1233794,"a":[{"t":99155969,"c":4394123265},{"t":104398849,"c":4399366145,"a":[{"v":"00000105-0000-0000-C000-000000000046","t":1310721}]},{"t":104923137,"c":4399890433,"a":[{"v":1,"t":99221505}]}]}; }
            static get $fullName() { return `System.Runtime.InteropServices.ComTypes.IEnumSTATDATA`; }
        });
        
        $asm.$cls("$sris.System.Runtime.InteropServices.Marshalling.IComExposedDetails", ($self) => class IComExposedDetails
        {
            static /*IComExposedDetails? */ System$Runtime$InteropServices$Marshalling$IComExposedDetails$GetFromAttribute(/*RuntimeTypeHandle*/ handle)
            {
                /*var*/ let type = $.$spc.System.Type.GetTypeFromHandle(handle);
                if (type === null)
                {
                    return null;
                }
                return $.$cast($.$spc.System.Reflection.CustomAttributeExtensions.GetCustomAttribute$2(type, $.$sris.System.Runtime.InteropServices.Marshalling.ComExposedClassAttribute$$().$type), $.$sris.System.Runtime.InteropServices.Marshalling.IComExposedDetails);
            }
            static $h = 3068802;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {"m":[{"r":0,"p":[{"n":"count","p":655361,"f":2}],"n":"GetComInterfaceEntries","o":"System$Runtime$InteropServices$Marshalling$IComExposedDetails$GetComInterfaceEntries","d":3068802,"h":4298036098,"f":257},{"r":3068802,"p":[{"n":"handle","p":116064257}],"n":"GetFromAttribute","o":"System$Runtime$InteropServices$Marshalling$IComExposedDetails$GetFromAttribute","d":3068802,"h":8593003394,"f":40}],"h":3068802,"a":[{"t":23396353,"c":8613330945,"a":[{"v":false,"t":262145}]}]}; }
            static get $fullName() { return `System.Runtime.InteropServices.Marshalling.IComExposedDetails`; }
        });
        
        $asm.$cls("$sris.System.Runtime.InteropServices.Marshalling.IComExposedClass", ($self) => class IComExposedClass
        {
            static $h = 3003266;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {"m":[{"r":0,"p":[{"n":"count","p":655361,"f":2}],"n":"GetComInterfaceEntries","o":"System$Runtime$InteropServices$Marshalling$IComExposedClass$GetComInterfaceEntries","d":3003266,"h":4297970562,"f":289}],"h":3003266,"a":[{"t":23396353,"c":8613330945,"a":[{"v":false,"t":262145}]}]}; }
            static get $fullName() { return `System.Runtime.InteropServices.Marshalling.IComExposedClass`; }
        });
        
        $asm.$cls("$sris.System.Runtime.InteropServices.Marshalling.IIUnknownDerivedDetails", ($self) => class IIUnknownDerivedDetails
        {
            static /*IIUnknownDerivedDetails? */ System$Runtime$InteropServices$Marshalling$IIUnknownDerivedDetails$GetFromAttribute(/*RuntimeTypeHandle*/ handle)
            {
                /*var*/ let type = $.$spc.System.Type.GetTypeFromHandle(handle);
                if (type === null)
                {
                    return null;
                }
                return $.$cast($.$spc.System.Reflection.CustomAttributeExtensions.GetCustomAttribute$2(type, $.$sris.System.Runtime.InteropServices.Marshalling.IUnknownDerivedAttribute$$$().$type), $.$sris.System.Runtime.InteropServices.Marshalling.IIUnknownDerivedDetails);
            }
            static $h = 3265410;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {"p":[{"p":56164353,"g":{"r":0,"d":0,"h":8593200002,"f":257},"n":"Iid","o":"System$Runtime$InteropServices$Marshalling$IIUnknownDerivedDetails$Iid","d":3265410,"h":4298232706,"f":257},{"p":142606337,"g":{"r":0,"d":0,"h":17183134594,"f":257},"n":"Implementation","o":"System$Runtime$InteropServices$Marshalling$IIUnknownDerivedDetails$Implementation","d":3265410,"h":12888167298,"f":257},{"p":0,"g":{"r":0,"d":0,"h":25773069186,"f":257},"n":"ManagedVirtualMethodTable","o":"System$Runtime$InteropServices$Marshalling$IIUnknownDerivedDetails$ManagedVirtualMethodTable","d":3265410,"h":21478101890,"f":257}],"m":[{"r":3265410,"p":[{"n":"handle","p":116064257}],"n":"GetFromAttribute","o":"System$Runtime$InteropServices$Marshalling$IIUnknownDerivedDetails$GetFromAttribute","d":3265410,"h":30068036482,"f":40}],"h":3265410,"a":[{"t":23396353,"c":8613330945,"a":[{"v":false,"t":262145}]}]}; }
            static get $fullName() { return `System.Runtime.InteropServices.Marshalling.IIUnknownDerivedDetails`; }
        });
        
        $asm.$cls("$sris.System.Runtime.InteropServices.Marshalling.IIUnknownInterfaceType", ($self) => class IIUnknownInterfaceType
        {
            static $h = 3396482;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {"p":[{"p":56164353,"g":{"r":0,"d":0,"h":8593331074,"f":289},"n":"Iid","o":"System$Runtime$InteropServices$Marshalling$IIUnknownInterfaceType$Iid","d":3396482,"h":4298363778,"f":289},{"p":0,"g":{"r":0,"d":0,"h":17183265666,"f":289},"n":"ManagedVirtualMethodTable","o":"System$Runtime$InteropServices$Marshalling$IIUnknownInterfaceType$ManagedVirtualMethodTable","d":3396482,"h":12888298370,"f":289}],"h":3396482,"a":[{"t":23396353,"c":8613330945,"a":[{"v":false,"t":262145}]}]}; }
            static get $fullName() { return `System.Runtime.InteropServices.Marshalling.IIUnknownInterfaceType`; }
        });
        
        $asm.$cls("$sris.System.Runtime.InteropServices.Marshalling.IIUnknownStrategy", ($self) => class IIUnknownStrategy
        {
            static $h = 3462018;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {"m":[{"r":0,"p":[{"n":"unknown","p":0}],"n":"CreateInstancePointer","o":"System$Runtime$InteropServices$Marshalling$IIUnknownStrategy$CreateInstancePointer","d":3462018,"h":4298429314,"f":257},{"r":655361,"p":[{"n":"instancePtr","p":0},{"n":"iid","p":56164353,"f":8},{"n":"ppObj","p":0,"f":2}],"n":"QueryInterface","o":"System$Runtime$InteropServices$Marshalling$IIUnknownStrategy$QueryInterface","d":3462018,"h":8593396610,"f":257},{"r":655361,"p":[{"n":"instancePtr","p":0}],"n":"Release","o":"System$Runtime$InteropServices$Marshalling$IIUnknownStrategy$Release","d":3462018,"h":12888363906,"f":257}],"h":3462018,"a":[{"t":23396353,"c":8613330945,"a":[{"v":false,"t":262145}]}]}; }
            static get $fullName() { return `System.Runtime.InteropServices.Marshalling.IIUnknownStrategy`; }
        });
        
        $asm.$cls("$sris.System.Runtime.InteropServices.Marshalling.IIUnknownCacheStrategy", ($self) => class IIUnknownCacheStrategy
        {
            static $_TableInfo;
            static get TableInfo()
            {
                let $cls = $.$sris.System.Runtime.InteropServices.Marshalling.IIUnknownCacheStrategy;
                return $cls.$_TableInfo ??= $asm.$nstr("$sris.System.Runtime.InteropServices.Marshalling.IIUnknownCacheStrategy.TableInfo", ($self) => class TableInfo extends $.$spc.System.ValueType
                {
                    /*void**/ ThisPtr;
                    /*void***/ Table;
                    /*RuntimeTypeHandle*/ ManagedType;
                    //default value type constructor
                    $ctor$2()
                    {
                        return this;
                    }
                    Clone($copy)
                    {
                        let copy = $copy ?? new this.constructor();
                        copy.ThisPtr = this.ThisPtr.Clone();
                        copy.Table = this.Table.Clone();
                        copy.ManagedType = this.ManagedType.Clone();
                        return copy;
                    }
                    //default member initializer
                    constructor()
                    {
                        super();
                        this.ThisPtr = $.$default($.$typePointer($.$spc.System.Void));
                        this.Table = $.$default($.$typePointer($.$typePointer($.$spc.System.Void)));
                        this.ManagedType = $.$default($.$spc.System.RuntimeTypeHandle);
                    }
                    static $h = 3199874;
                    static $z = 9;
                    static $f = 0b10000001010000001;
                    static $k = 2;
                    static $$md;
                    static get $md() { return this.$$md ??= {"b":196609,"p":[{"p":0,"g":{"r":0,"d":0,"h":12888101762,"f":1},"s":{"r":0,"d":0,"h":17183069058,"f":1},"n":"ThisPtr","d":3199874,"h":8593134466,"f":1},{"p":0,"g":{"r":0,"d":0,"h":30067970946,"f":1},"s":{"r":0,"d":0,"h":34362938242,"f":1},"n":"Table","d":3199874,"h":25773003650,"f":1},{"p":116064257,"g":{"r":0,"d":0,"h":47247840130,"f":1},"s":{"r":0,"d":0,"h":51542807426,"f":1},"n":"ManagedType","d":3199874,"h":42952872834,"f":1}],"c":[{"n":".ctor","o":"$ctor$2","d":3199874,"h":55837774722,"f":1}],"d":3134338,"h":3199874}; }
                    static get $b() { return $.$spc.System.ValueType; }
                    static get $fullName() { return `System.Runtime.InteropServices.Marshalling.IIUnknownCacheStrategy.TableInfo`; }
                }, $cls, ($v) => $cls.$_TableInfo = $v);
            }
            static $h = 3134338;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {"m":[{"r":3199874,"p":[{"n":"handle","p":116064257},{"n":"interfaceDetails","p":3265410},{"n":"ptr","p":0}],"n":"ConstructTableInfo","o":"System$Runtime$InteropServices$Marshalling$IIUnknownCacheStrategy$ConstructTableInfo","d":3134338,"h":8593068930,"f":257},{"r":262145,"p":[{"n":"handle","p":116064257},{"n":"info","p":3199874,"f":2}],"n":"TryGetTableInfo","o":"System$Runtime$InteropServices$Marshalling$IIUnknownCacheStrategy$TryGetTableInfo","d":3134338,"h":12888036226,"f":257},{"r":262145,"p":[{"n":"handle","p":116064257},{"n":"info","p":3199874}],"n":"TrySetTableInfo","o":"System$Runtime$InteropServices$Marshalling$IIUnknownCacheStrategy$TrySetTableInfo","d":3134338,"h":17183003522,"f":257},{"r":65537,"p":[{"n":"unknownStrategy","p":3462018}],"n":"Clear","o":"System$Runtime$InteropServices$Marshalling$IIUnknownCacheStrategy$Clear","d":3134338,"h":21477970818,"f":257}],"j":[3199874],"h":3134338,"a":[{"t":23396353,"c":8613330945,"a":[{"v":false,"t":262145}]}]}; }
            static get $fullName() { return `System.Runtime.InteropServices.Marshalling.IIUnknownCacheStrategy`; }
        });
        
        $asm.$cls("$sris.System.Runtime.InteropServices.Marshalling.IIUnknownInterfaceDetailsStrategy", ($self) => class IIUnknownInterfaceDetailsStrategy
        {
            static $h = 3330946;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {"m":[{"r":3265410,"p":[{"n":"type","p":116064257}],"n":"GetIUnknownDerivedDetails","o":"System$Runtime$InteropServices$Marshalling$IIUnknownInterfaceDetailsStrategy$GetIUnknownDerivedDetails","d":3330946,"h":4298298242,"f":257},{"r":3068802,"p":[{"n":"type","p":116064257}],"n":"GetComExposedTypeDetails","o":"System$Runtime$InteropServices$Marshalling$IIUnknownInterfaceDetailsStrategy$GetComExposedTypeDetails","d":3330946,"h":8593265538,"f":257}],"h":3330946,"a":[{"t":23396353,"c":8613330945,"a":[{"v":false,"t":262145}]}]}; }
            static get $fullName() { return `System.Runtime.InteropServices.Marshalling.IIUnknownInterfaceDetailsStrategy`; }
        });
        
        $asm.$cls("$sris.System.Runtime.InteropServices.Marshalling.IUnmanagedVirtualMethodTableProvider", ($self) => class IUnmanagedVirtualMethodTableProvider
        {
            static $h = 3593090;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {"m":[{"r":3789698,"p":[{"n":"type","p":142606337}],"n":"GetVirtualMethodTableInfoForKey","o":"System$Runtime$InteropServices$Marshalling$IUnmanagedVirtualMethodTableProvider$GetVirtualMethodTableInfoForKey","d":3593090,"h":4298560386,"f":257}],"h":3593090,"a":[{"t":23396353,"c":8613330945,"a":[{"v":false,"t":262145}]}]}; }
            static get $fullName() { return `System.Runtime.InteropServices.Marshalling.IUnmanagedVirtualMethodTableProvider`; }
        });
        
        $asm.$cls("$sris.System.SR", ($self) => class SR
        {
            /*global::System.Resources.ResourceManager*/ static s_resourceManager = null;
            /*global::System.Globalization.CultureInfo*/ static resourceCulture = null;
            static /*global::System.Resources.ResourceManager */ get ResourceManager()
            {
                if ($.$spc.System.Object.ReferenceEquals($.$sris.System.SR.s_resourceManager, null))
                {
                    /*global::System.Resources.ResourceManager*/ let temp = new $.$spc.System.Resources.ResourceManager().$ctor$3("System.Runtime.InteropServices", $.$sris.System.SR.$type.Assembly);
                    $.$sris.System.SR.s_resourceManager = temp;
                }
                return $.$sris.System.SR.s_resourceManager;
            }
            static /*global::System.Globalization.CultureInfo */ get Culture()
            {
                return $.$sris.System.SR.resourceCulture;
            }
            static /*global::System.Globalization.CultureInfo */ set Culture(value)
            {
                $.$sris.System.SR.resourceCulture = value;
            }
            static /*string */ get InvalidOperation_HCCountOverflow()
            {
                return "Handle collector count overflows or underflows.";
            }
            static /*string */ get Arg_NeedNonNegNumRequired()
            {
                return "Non-negative number required.";
            }
            static /*string */ get Arg_InvalidThreshold()
            {
                return "maximumThreshold cannot be less than initialThreshold.";
            }
            static /*string */ get InvalidOperation_NoComEventInterfaceAttribute()
            {
                return "Event invocation for COM objects requires the declaring interface of the event to be attributed with ComEventInterfaceAttribute.";
            }
            static /*string */ get AmbiguousMatch_MultipleEventInterfaceAttributes()
            {
                return "More than one ComEventInterfaceAttribute found for '{0}' on the declaring interface of the event.";
            }
            static /*string */ FormatAmbiguousMatch_MultipleEventInterfaceAttributes(/*object*/ arg1)
            {
                return $.$spc.System.String.Format("More than one ComEventInterfaceAttribute found for '{0}' on the declaring interface of the event.", arg1);
            }
            static /*string */ get InvalidOperation_NoDispIdAttribute()
            {
                return "Event invocation for COM objects requires event to be attributed with DispIdAttribute.";
            }
            static /*string */ get IO_FileExists_Name()
            {
                return "The file '{0}' already exists.";
            }
            static /*string */ FormatIO_FileExists_Name(/*object*/ arg1)
            {
                return $.$spc.System.String.Format("The file '{0}' already exists.", arg1);
            }
            static /*string */ get IO_FileNotFound()
            {
                return "Unable to find the specified file.";
            }
            static /*string */ get IO_FileNotFound_FileName()
            {
                return "Could not find file '{0}'.";
            }
            static /*string */ FormatIO_FileNotFound_FileName(/*object*/ arg1)
            {
                return $.$spc.System.String.Format("Could not find file '{0}'.", arg1);
            }
            static /*string */ get IO_PathNotFound_NoPathName()
            {
                return "Could not find a part of the path.";
            }
            static /*string */ get IO_PathNotFound_Path()
            {
                return "Could not find a part of the path '{0}'.";
            }
            static /*string */ FormatIO_PathNotFound_Path(/*object*/ arg1)
            {
                return $.$spc.System.String.Format("Could not find a part of the path '{0}'.", arg1);
            }
            static /*string */ get IO_PathTooLong()
            {
                return "The specified file name or path is too long, or a component of the specified path is too long.";
            }
            static /*string */ get IO_SharingViolation_File()
            {
                return "The process cannot access the file '{0}' because it is being used by another process.";
            }
            static /*string */ FormatIO_SharingViolation_File(/*object*/ arg1)
            {
                return $.$spc.System.String.Format("The process cannot access the file '{0}' because it is being used by another process.", arg1);
            }
            static /*string */ get IO_SharingViolation_NoFileName()
            {
                return "The process cannot access the file because it is being used by another process.";
            }
            static /*string */ get IO_PathTooLong_Path()
            {
                return "The path '{0}' is too long, or a component of the specified path is too long.";
            }
            static /*string */ FormatIO_PathTooLong_Path(/*object*/ arg1)
            {
                return $.$spc.System.String.Format("The path '{0}' is too long, or a component of the specified path is too long.", arg1);
            }
            static /*string */ get UnauthorizedAccess_IODenied_Path()
            {
                return "Access to the path '{0}' is denied.";
            }
            static /*string */ FormatUnauthorizedAccess_IODenied_Path(/*object*/ arg1)
            {
                return $.$spc.System.String.Format("Access to the path '{0}' is denied.", arg1);
            }
            static /*string */ get UnauthorizedAccess_IODenied_NoPathName()
            {
                return "Access to the path is denied.";
            }
            static /*string */ get ArgumentOutOfRange_FileLengthTooBig()
            {
                return "Specified file length was too large for the file system.";
            }
            static /*string */ get ComVariantMarshaller_ManagedTypeNotSupported()
            {
                return "Type of managed object is not supported for marshalling as ComVariant.";
            }
            static /*string */ get ComVariantMarshaller_UnmanagedTypeNotSupported()
            {
                return "Type of unmanaged variant is not supported for marshalling to a managed object.";
            }
            /*bool*/ static s_usingResourceKeys = false;
            static /*bool */ GetUsingResourceKeysSwitchValue()
            {
                /*bool*/ let usingResourceKeys;
                return $.$spc.System.AppContext.TryGetSwitch("System.Resources.UseSystemResourceKeys", $.$ref(() => usingResourceKeys, ($v) => usingResourceKeys = $v, $.$spc.System.Boolean)) ? usingResourceKeys : false;
            }
            static /*bool */ UsingResourceKeys()
            {
                return $.$sris.System.SR.s_usingResourceKeys;
            }
            static /*string */ GetResourceString(/*string*/ resourceKey)
            {
                if ($.$sris.System.SR.UsingResourceKeys())
                {
                    return resourceKey;
                }
                /*string?*/ let resourceString = null;
                try
                {
                    resourceString = $.$sris.System.SR.ResourceManager.GetString(resourceKey);
                }
                catch($e)
                {
                }
                return resourceString;
            }
            static /*string */ GetResourceString$1(/*string*/ resourceKey, /*string*/ defaultString)
            {
                /*string*/ let resourceString = $.$sris.System.SR.GetResourceString(resourceKey);
                return $.$spc.System.String.op_Equality(resourceKey, resourceString) || $.$spc.System.String.op_Equality(resourceString, null) ? defaultString : resourceString;
            }
            static /*string */ Format(/*string*/ resourceFormat, /*object?*/ p1)
            {
                if ($.$sris.System.SR.UsingResourceKeys())
                {
                    return $.$spc.System.String.Join$10(", ", $.$spc.System.ReadOnlySpan$$($.$spc.System.Object).op_Implicit([ resourceFormat, p1 ]));
                }
                return $.$spc.System.String.Format(resourceFormat, p1);
            }
            static /*string */ Format$1(/*string*/ resourceFormat, /*object?*/ p1, /*object?*/ p2)
            {
                if ($.$sris.System.SR.UsingResourceKeys())
                {
                    return $.$spc.System.String.Join$10(", ", $.$spc.System.ReadOnlySpan$$($.$spc.System.Object).op_Implicit([ resourceFormat, p1, p2 ]));
                }
                return $.$spc.System.String.Format$1(resourceFormat, p1, p2);
            }
            static /*string */ Format$2(/*string*/ resourceFormat, /*object?*/ p1, /*object?*/ p2, /*object?*/ p3)
            {
                if ($.$sris.System.SR.UsingResourceKeys())
                {
                    return $.$spc.System.String.Join$10(", ", $.$spc.System.ReadOnlySpan$$($.$spc.System.Object).op_Implicit([ resourceFormat, p1, p2, p3 ]));
                }
                return $.$spc.System.String.Format$2(resourceFormat, p1, p2, p3);
            }
            static /*string */ Format$3(/*string*/ resourceFormat, /*params object?[]?*/ args)
            {
                if (args !== null)
                {
                    if ($.$sris.System.SR.UsingResourceKeys())
                    {
                        return resourceFormat + ", " + $.$spc.System.String.Join$9(", ", args);
                    }
                    return $.$spc.System.String.Format$3(resourceFormat, args);
                }
                return resourceFormat;
            }
            static /*string */ Format$4(/*IFormatProvider?*/ provider, /*string*/ resourceFormat, /*object?*/ p1)
            {
                if ($.$sris.System.SR.UsingResourceKeys())
                {
                    return $.$spc.System.String.Join$10(", ", $.$spc.System.ReadOnlySpan$$($.$spc.System.Object).op_Implicit([ resourceFormat, p1 ]));
                }
                return $.$spc.System.String.Format$5(provider, resourceFormat, p1);
            }
            static /*string */ Format$5(/*IFormatProvider?*/ provider, /*string*/ resourceFormat, /*object?*/ p1, /*object?*/ p2)
            {
                if ($.$sris.System.SR.UsingResourceKeys())
                {
                    return $.$spc.System.String.Join$10(", ", $.$spc.System.ReadOnlySpan$$($.$spc.System.Object).op_Implicit([ resourceFormat, p1, p2 ]));
                }
                return $.$spc.System.String.Format$6(provider, resourceFormat, p1, p2);
            }
            static /*string */ Format$6(/*IFormatProvider?*/ provider, /*string*/ resourceFormat, /*object?*/ p1, /*object?*/ p2, /*object?*/ p3)
            {
                if ($.$sris.System.SR.UsingResourceKeys())
                {
                    return $.$spc.System.String.Join$10(", ", $.$spc.System.ReadOnlySpan$$($.$spc.System.Object).op_Implicit([ resourceFormat, p1, p2, p3 ]));
                }
                return $.$spc.System.String.Format$7(provider, resourceFormat, p1, p2, p3);
            }
            static /*string */ Format$7(/*IFormatProvider?*/ provider, /*string*/ resourceFormat, /*params object?[]?*/ args)
            {
                if (args !== null)
                {
                    if ($.$sris.System.SR.UsingResourceKeys())
                    {
                        return resourceFormat + ", " + $.$spc.System.String.Join$9(", ", args);
                    }
                    return $.$spc.System.String.Format$8(provider, resourceFormat, args);
                }
                return resourceFormat;
            }
            //Static Initializer
            static $sinit()
            {
                {
                    this.s_usingResourceKeys = $.$sris.System.SR.GetUsingResourceKeysSwitchValue();
                }
            }
            static $h = 4707202;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"h":4707202}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.SR`; }
        });
        
        $asm.$cls("$sris.System.Runtime.InteropServices.HandleCollector", ($self) => class HandleCollector extends $.$spc.System.Object
        {
            /*int*/ static DeltaPercent = 10;
            /*int*/ _threshold = 0;
            /*int*/ _handleCount = 0;
            /*int[]*/ _gcCounts = null;
            /*int*/ _gcGeneration = 0;
            $ctor$1(/*string?*/ name, /*int*/ initialThreshold)
            {
                this.$ctor$2(name, initialThreshold, 2147483647/*int.MaxValue*/);
                {
                }
                return this;
            }
            $ctor$2(/*string?*/ name, /*int*/ initialThreshold, /*int*/ maximumThreshold)
            {
                super.$ctor();
                {
                    if (initialThreshold < 0)
                    {
                        throw new $.$spc.System.ArgumentOutOfRangeException().$ctor$19("initialThreshold", $.$box(initialThreshold, $.$spc.System.Int32), $.$sris.System.SR.Arg_NeedNonNegNumRequired);
                    }
                    if (maximumThreshold < 0)
                    {
                        throw new $.$spc.System.ArgumentOutOfRangeException().$ctor$19("maximumThreshold", $.$box(maximumThreshold, $.$spc.System.Int32), $.$sris.System.SR.Arg_NeedNonNegNumRequired);
                    }
                    if (initialThreshold > maximumThreshold)
                    {
                        throw new $.$spc.System.ArgumentException().$ctor$13($.$sris.System.SR.Arg_InvalidThreshold, "initialThreshold");
                    }
                    this.Name = name ?? $.$spc.System.String.Empty;
                    this.InitialThreshold = initialThreshold;
                    this.MaximumThreshold = maximumThreshold;
                    this._threshold = initialThreshold;
                    this._handleCount = 0;
                    this._gcGeneration = 0;
                }
                return this;
            }
            /*int */ get Count()
            {
                return this._handleCount;
            }
            /*int*/ InitialThreshold = 0;
            /*int*/ MaximumThreshold = 0;
            /*string*/ Name = null;
            /*void */ Add()
            {
                /*int*/ let collectionGeneration = -1;
                $.$spc.System.Threading.Interlocked.Increment($.$ref(() => this._handleCount, ($v) => this._handleCount = $v, $.$spc.System.Int32));
                if (this._handleCount < 0)
                {
                    throw new $.$spc.System.InvalidOperationException().$ctor$10($.$sris.System.SR.InvalidOperation_HCCountOverflow);
                }
                if (this._handleCount > this._threshold)
                {
                    //lock
                    try
                    {
                        $.$spc.System.Threading.Monitor.Enter(this)
                        {
                            this._threshold = ((this._handleCount + ($.trunc(this._handleCount / 10/*DeltaPercent*/))) | 0);
                            collectionGeneration = this._gcGeneration;
                            if (this._gcGeneration < 2)
                            {
                                this._gcGeneration++;
                            }
                        }
                    }
                    finally
                    {
                        $.$spc.System.Threading.Monitor.Exit(this)
                    }
                }
                if ((collectionGeneration >= 0) && ((collectionGeneration === 0) || ($.$spc.System.Array.$ReadT1.call(this._gcCounts, collectionGeneration) === $.$spc.System.GC.CollectionCount(collectionGeneration))))
                {
                    $.$spc.System.GC.Collect(collectionGeneration);
                    $.$spc.System.Threading.Thread.Sleep(((10 * collectionGeneration) | 0));
                }
                for(/*int*/ let i = 1; i < 3; i++)
                {
                    $.$spc.System.Array.$WriteT1.call(this._gcCounts, $.$spc.System.GC.CollectionCount(i), i);
                }
            }
            /*void */ Remove()
            {
                $.$spc.System.Threading.Interlocked.Decrement($.$ref(() => this._handleCount, ($v) => this._handleCount = $v, $.$spc.System.Int32));
                if (this._handleCount < 0)
                {
                    throw new $.$spc.System.InvalidOperationException().$ctor$10($.$sris.System.SR.InvalidOperation_HCCountOverflow);
                }
                /*int*/ let newThreshold = ((this._handleCount + $.trunc(this._handleCount / 10/*DeltaPercent*/)) | 0);
                if (newThreshold < (((this._threshold - $.trunc(this._threshold / 10/*DeltaPercent*/)) | 0)))
                {
                    //lock
                    try
                    {
                        $.$spc.System.Threading.Monitor.Enter(this)
                        {
                            if (newThreshold > this.InitialThreshold)
                            {
                                this._threshold = newThreshold;
                            }
                            else 
                            {
                                this._threshold = this.InitialThreshold;
                            }
                            this._gcGeneration = 0;
                        }
                    }
                    finally
                    {
                        $.$spc.System.Threading.Monitor.Exit(this)
                    }
                }
                for(/*int*/ let i = 1; i < 3; i++)
                {
                    $.$spc.System.Array.$WriteT1.call(this._gcCounts, $.$spc.System.GC.CollectionCount(i), i);
                }
            }
            //default member initializer
            constructor()
            {
                super();
                this._gcCounts = $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$spc.System.Int32), null, [3], null);
            }
            static $h = 1627010;
            static $f = 0b10010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":655361,"g":{"r":0,"d":0,"h":38656332674,"f":1},"n":"Count","d":1627010,"h":34361365378,"f":1},{"p":655361,"g":{"r":0,"d":0,"h":51541234562,"f":1},"n":"InitialThreshold","d":1627010,"h":47246267266,"f":1},{"p":655361,"g":{"r":0,"d":0,"h":64426136450,"f":1},"n":"MaximumThreshold","d":1627010,"h":60131169154,"f":1},{"p":1310721,"g":{"r":0,"d":0,"h":77311038338,"f":1},"n":"Name","d":1627010,"h":73016071042,"f":1}],"m":[{"r":65537,"n":"Add","d":1627010,"h":81606005634,"f":1},{"r":65537,"n":"Remove","d":1627010,"h":85900972930,"f":1}],"l":[{"t":655361,"n":"DeltaPercent","d":1627010,"h":4296594306,"f":34},{"t":655361,"n":"_threshold","d":1627010,"h":8591561602,"f":2},{"t":655361,"n":"_handleCount","d":1627010,"h":12886528898,"f":2},{"t":0,"n":"_gcCounts","d":1627010,"h":17181496194,"f":2},{"t":655361,"n":"_gcGeneration","d":1627010,"h":21476463490,"f":2}],"c":[{"p":[{"n":"name","p":1310721},{"n":"initialThreshold","p":655361}],"n":".ctor","o":"$ctor$1","d":1627010,"h":25771430786,"f":1},{"p":[{"n":"name","p":1310721},{"n":"initialThreshold","p":655361},{"n":"maximumThreshold","p":655361}],"n":".ctor","o":"$ctor$2","d":1627010,"h":30066398082,"f":1}],"h":1627010}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.Runtime.InteropServices.HandleCollector`; }
        });
        
        $asm.$cls("$sris.System.Runtime.InteropServices.Marshalling.ComVariantMarshaller", ($self) => class ComVariantMarshaller
        {
            /*short*/ static VARIANT_TRUE = -1;
            /*short*/ static VARIANT_FALSE = 0;
            static /*ComVariant */ ConvertToUnmanaged(/*object?*/ managed)
            {
                if (managed === null)
                {
                    return new $.$spc.System.Runtime.InteropServices.Marshalling.ComVariant();
                }
                //switch (managed)
                {
                    let s;
                    let b;
                    let i;
                    let l;
                    let f;
                    let d;
                    let dt;
                    let errorWrapper;
                    let currencyWrapper;
                    let bStrWrapper;
                    $switchJumpStart1: 
                    //case sbyte s:
                    if ($.$is(managed, $.$spc.System.SByte, { set $v(v){ s = v; } }))
                    {
                        return $.$spc.System.Runtime.InteropServices.Marshalling.ComVariant.Create($.$spc.System.SByte, s);
                    }
                    //case byte b:
                    else if ($.$is(managed, $.$spc.System.Byte, { set $v(v){ b = v; } }))
                    {
                        return $.$spc.System.Runtime.InteropServices.Marshalling.ComVariant.Create($.$spc.System.Byte, b);
                    }
                    //case short s:
                    else if ($.$is(managed, $.$spc.System.Int16, { set $v(v){ s = v; } }))
                    {
                        return $.$spc.System.Runtime.InteropServices.Marshalling.ComVariant.Create($.$spc.System.Int16, s);
                    }
                    //case ushort s:
                    else if ($.$is(managed, $.$spc.System.UInt16, { set $v(v){ s = v; } }))
                    {
                        return $.$spc.System.Runtime.InteropServices.Marshalling.ComVariant.Create($.$spc.System.UInt16, s);
                    }
                    //case int i:
                    else if ($.$is(managed, $.$spc.System.Int32, { set $v(v){ i = v; } }))
                    {
                        return $.$spc.System.Runtime.InteropServices.Marshalling.ComVariant.Create($.$spc.System.Int32, i);
                    }
                    //case uint i:
                    else if ($.$is(managed, $.$spc.System.UInt32, { set $v(v){ i = v; } }))
                    {
                        return $.$spc.System.Runtime.InteropServices.Marshalling.ComVariant.Create($.$spc.System.UInt32, i);
                    }
                    //case long l:
                    else if ($.$is(managed, $.$spc.System.Int64, { set $v(v){ l = v; } }))
                    {
                        return $.$spc.System.Runtime.InteropServices.Marshalling.ComVariant.Create($.$spc.System.Int64, l);
                    }
                    //case ulong l:
                    else if ($.$is(managed, $.$spc.System.UInt64, { set $v(v){ l = v; } }))
                    {
                        return $.$spc.System.Runtime.InteropServices.Marshalling.ComVariant.Create($.$spc.System.UInt64, l);
                    }
                    //case float f:
                    else if ($.$is(managed, $.$spc.System.Single, { set $v(v){ f = v; } }))
                    {
                        return $.$spc.System.Runtime.InteropServices.Marshalling.ComVariant.Create($.$spc.System.Single, f);
                    }
                    //case double d:
                    else if ($.$is(managed, $.$spc.System.Double, { set $v(v){ d = v; } }))
                    {
                        return $.$spc.System.Runtime.InteropServices.Marshalling.ComVariant.Create($.$spc.System.Double, d);
                    }
                    //case decimal d:
                    else if ($.$is(managed, $.$spc.System.Decimal, { set $v(v){ d = v; } }))
                    {
                        return $.$spc.System.Runtime.InteropServices.Marshalling.ComVariant.Create($.$spc.System.Decimal, d);
                    }
                    //case bool b:
                    else if ($.$is(managed, $.$spc.System.Boolean, { set $v(v){ b = v; } }))
                    {
                        return $.$spc.System.Runtime.InteropServices.Marshalling.ComVariant.Create($.$spc.System.Boolean, b);
                    }
                    //case string s:
                    else if ($.$is(managed, $.$spc.System.String, { set $v(v){ s = v; } }))
                    {
                        return $.$spc.System.Runtime.InteropServices.Marshalling.ComVariant.Create($.$spc.System.String, s);
                    }
                    //case DateTime dt:
                    else if ($.$is(managed, $.$spc.System.DateTime, { set $v(v){ dt = v; } }))
                    {
                        return $.$spc.System.Runtime.InteropServices.Marshalling.ComVariant.Create($.$spc.System.DateTime, dt);
                    }
                    //case ErrorWrapper errorWrapper:
                    else if ($.$is(managed, $.$spc.System.Runtime.InteropServices.ErrorWrapper, { set $v(v){ errorWrapper = v; } }))
                    {
                        return $.$spc.System.Runtime.InteropServices.Marshalling.ComVariant.Create($.$spc.System.Runtime.InteropServices.ErrorWrapper, errorWrapper);
                    }
                    //case CurrencyWrapper currencyWrapper:
                    else if ($.$is(managed, $.$spc.System.Runtime.InteropServices.CurrencyWrapper, { set $v(v){ currencyWrapper = v; } }))
                    {
                        return $.$spc.System.Runtime.InteropServices.Marshalling.ComVariant.Create($.$spc.System.Runtime.InteropServices.CurrencyWrapper, currencyWrapper);
                    }
                    //case BStrWrapper bStrWrapper:
                    else if ($.$is(managed, $.$spc.System.Runtime.InteropServices.BStrWrapper, { set $v(v){ bStrWrapper = v; } }))
                    {
                        return $.$spc.System.Runtime.InteropServices.Marshalling.ComVariant.Create($.$spc.System.Runtime.InteropServices.BStrWrapper, bStrWrapper);
                    }
                    //case DBNull:
                    else if (managed == $.$spc.System.DBNull)
                    {
                        return $.$spc.System.Runtime.InteropServices.Marshalling.ComVariant.Null;
                    }
                }
                /*ComVariant*/ let variant;
                if ($.$sris.System.Runtime.InteropServices.Marshalling.ComVariantMarshaller.TryCreateOleVariantForInterfaceWrapper(managed, $.$ref(() => variant, ($v) => variant = $v, $.$spc.System.Runtime.InteropServices.Marshalling.ComVariant)))
                {
                    return variant;
                }
                throw new $.$spc.System.ArgumentException().$ctor$13($.$sris.System.SR.ComVariantMarshaller_ManagedTypeNotSupported, "managed");
            }
            static /*bool */ TryCreateOleVariantForInterfaceWrapper(/*object*/ managed, /*out ComVariant*/ variant)
            {
                let uw;
                if ($.$is(managed, $.$spc.System.Runtime.InteropServices.UnknownWrapper, { set $v(v){ uw = v; } }))
                {
                    /*object?*/ let wrapped = uw.WrappedObject;
                    if (wrapped === null)
                    {
                        variant.$v = new $.$spc.System.Runtime.InteropServices.Marshalling.ComVariant();
                        return true;
                    }
                    variant.$v = $.$spc.System.Runtime.InteropServices.Marshalling.ComVariant.CreateRaw($.$spc.System.IntPtr, 13/*VarEnum.VT_UNKNOWN*/, $.$sris.System.Runtime.InteropServices.Marshalling.StrategyBasedComWrappers.DefaultMarshallingInstance.GetOrCreateComInterfaceForObject(wrapped, 0/*CreateComInterfaceFlags.None*/));
                    return true;
                }
                else if (!(managed === null) && !($.$sris.System.Runtime.InteropServices.Marshalling.StrategyBasedComWrappers.DefaultIUnknownInterfaceDetailsStrategy.System$Runtime$InteropServices$Marshalling$IIUnknownInterfaceDetailsStrategy$GetComExposedTypeDetails($.$spc.System.Object.GetType.call(managed).TypeHandle) === null))
                {
                    variant.$v = $.$spc.System.Runtime.InteropServices.Marshalling.ComVariant.CreateRaw($.$spc.System.IntPtr, 13/*VarEnum.VT_UNKNOWN*/, $.$sris.System.Runtime.InteropServices.Marshalling.StrategyBasedComWrappers.DefaultMarshallingInstance.GetOrCreateComInterfaceForObject(managed, 0/*CreateComInterfaceFlags.None*/));
                    return true;
                }
                variant.$v = new $.$spc.System.Runtime.InteropServices.Marshalling.ComVariant();
                return false;
            }
            static /*object? */ ConvertToManaged(/*ComVariant*/ unmanaged)
            {
                let $switch1 = unmanaged.VarType;
                switch($switch1)
                {
                    case 0/*VarEnum.VT_EMPTY*/:
                    case 16384/*VarEnum.VT_BYREF*/ | 0/*VarEnum.VT_EMPTY*/:
                    return null;
                    case 1/*VarEnum.VT_NULL*/:
                    case 16384/*VarEnum.VT_BYREF*/ | 1/*VarEnum.VT_NULL*/:
                    return $.$spc.System.DBNull.Value;
                    case 16/*VarEnum.VT_I1*/:
                    return $.$box(unmanaged.As($.$spc.System.SByte), $.$spc.System.SByte);
                    case 17/*VarEnum.VT_UI1*/:
                    return $.$box(unmanaged.As($.$spc.System.Byte), $.$spc.System.Byte);
                    case 2/*VarEnum.VT_I2*/:
                    return $.$box(unmanaged.As($.$spc.System.Int16), $.$spc.System.Int16);
                    case 18/*VarEnum.VT_UI2*/:
                    return $.$box(unmanaged.As($.$spc.System.UInt16), $.$spc.System.UInt16);
                    case 22/*VarEnum.VT_INT*/:
                    case 3/*VarEnum.VT_I4*/:
                    return $.$box(unmanaged.As($.$spc.System.Int32), $.$spc.System.Int32);
                    case 23/*VarEnum.VT_UINT*/:
                    case 19/*VarEnum.VT_UI4*/:
                    return $.$box(unmanaged.As($.$spc.System.UInt32), $.$spc.System.UInt32);
                    case 20/*VarEnum.VT_I8*/:
                    return $.$box(unmanaged.As($.$spc.System.Int64), $.$spc.System.Int64);
                    case 21/*VarEnum.VT_UI8*/:
                    return $.$box(unmanaged.As($.$spc.System.UInt64), $.$spc.System.UInt64);
                    case 4/*VarEnum.VT_R4*/:
                    return $.$box(unmanaged.As($.$spc.System.Single), $.$spc.System.Single);
                    case 5/*VarEnum.VT_R8*/:
                    return $.$box(unmanaged.As($.$spc.System.Double), $.$spc.System.Double);
                    case 14/*VarEnum.VT_DECIMAL*/:
                    return unmanaged.As($.$spc.System.Decimal);
                    case 11/*VarEnum.VT_BOOL*/:
                    return $.$box(unmanaged.As($.$spc.System.Boolean), $.$spc.System.Boolean);
                    case 8/*VarEnum.VT_BSTR*/:
                    return unmanaged.As($.$spc.System.String);
                    case 7/*VarEnum.VT_DATE*/:
                    return unmanaged.As($.$spc.System.DateTime);
                    case 10/*VarEnum.VT_ERROR*/:
                    return $.$box(unmanaged.As($.$spc.System.Int32), $.$spc.System.Int32);
                    case 6/*VarEnum.VT_CY*/:
                    return unmanaged.As($.$spc.System.Runtime.InteropServices.CurrencyWrapper).WrappedObject;
                    case 13/*VarEnum.VT_UNKNOWN*/:
                    case 9/*VarEnum.VT_DISPATCH*/:
                    return $.$sris.System.Runtime.InteropServices.Marshalling.StrategyBasedComWrappers.DefaultMarshallingInstance.GetOrCreateObjectForComInstance(unmanaged.GetRawDataRef($.$spc.System.IntPtr).$v, 8/*CreateObjectFlags.Unwrap*/);
                    case 16384/*VarEnum.VT_BYREF*/ | 12/*VarEnum.VT_VARIANT*/:
                    return $.$sris.System.Runtime.InteropServices.Marshalling.ComVariantMarshaller.ConvertToManaged($.$spc.InteropUtility.castAddress2Object(unmanaged.GetRawDataRef($.$spc.System.IntPtr).$v));
                    case 16384/*VarEnum.VT_BYREF*/ | 16/*VarEnum.VT_I1*/:
                    return $.$box($.$spc.InteropUtility.castAddress2Object(unmanaged.GetRawDataRef($.$spc.System.IntPtr).$v), $.$spc.System.SByte);
                    case 16384/*VarEnum.VT_BYREF*/ | 17/*VarEnum.VT_UI1*/:
                    return $.$box($.$spc.InteropUtility.castAddress2Object(unmanaged.GetRawDataRef($.$spc.System.IntPtr).$v), $.$spc.System.Byte);
                    case 16384/*VarEnum.VT_BYREF*/ | 2/*VarEnum.VT_I2*/:
                    return $.$box($.$spc.InteropUtility.castAddress2Object(unmanaged.GetRawDataRef($.$spc.System.IntPtr).$v), $.$spc.System.Int16);
                    case 16384/*VarEnum.VT_BYREF*/ | 18/*VarEnum.VT_UI2*/:
                    return $.$box($.$spc.InteropUtility.castAddress2Object(unmanaged.GetRawDataRef($.$spc.System.IntPtr).$v), $.$spc.System.UInt16);
                    case 16384/*VarEnum.VT_BYREF*/ | 3/*VarEnum.VT_I4*/:
                    return $.$box($.$spc.InteropUtility.castAddress2Object(unmanaged.GetRawDataRef($.$spc.System.IntPtr).$v), $.$spc.System.Int32);
                    case 16384/*VarEnum.VT_BYREF*/ | 19/*VarEnum.VT_UI4*/:
                    return $.$box($.$spc.InteropUtility.castAddress2Object(unmanaged.GetRawDataRef($.$spc.System.IntPtr).$v), $.$spc.System.UInt32);
                    case 16384/*VarEnum.VT_BYREF*/ | 20/*VarEnum.VT_I8*/:
                    return $.$box($.$spc.InteropUtility.castAddress2Object(unmanaged.GetRawDataRef($.$spc.System.IntPtr).$v), $.$spc.System.Int64);
                    case 16384/*VarEnum.VT_BYREF*/ | 21/*VarEnum.VT_UI8*/:
                    return $.$box($.$spc.InteropUtility.castAddress2Object(unmanaged.GetRawDataRef($.$spc.System.IntPtr).$v), $.$spc.System.UInt64);
                    case 16384/*VarEnum.VT_BYREF*/ | 4/*VarEnum.VT_R4*/:
                    return $.$box($.$spc.InteropUtility.castAddress2Object(unmanaged.GetRawDataRef($.$spc.System.IntPtr).$v), $.$spc.System.Single);
                    case 16384/*VarEnum.VT_BYREF*/ | 5/*VarEnum.VT_R8*/:
                    return $.$box($.$spc.InteropUtility.castAddress2Object(unmanaged.GetRawDataRef($.$spc.System.IntPtr).$v), $.$spc.System.Double);
                    case 16384/*VarEnum.VT_BYREF*/ | 14/*VarEnum.VT_DECIMAL*/:
                    return $.$spc.InteropUtility.castAddress2Object(unmanaged.GetRawDataRef($.$spc.System.IntPtr).$v);
                    case 16384/*VarEnum.VT_BYREF*/ | 11/*VarEnum.VT_BOOL*/:
                    return $.$box($.$spc.InteropUtility.castAddress2Object(unmanaged.GetRawDataRef($.$spc.System.IntPtr).$v) !== 0/*VARIANT_FALSE*/, $.$spc.System.Boolean);
                    case 16384/*VarEnum.VT_BYREF*/ | 8/*VarEnum.VT_BSTR*/:
                    return $.$spc.System.Runtime.InteropServices.Marshal.PtrToStringBSTR($.$spc.InteropUtility.castAddress2Object(unmanaged.GetRawDataRef($.$spc.System.IntPtr).$v));
                    case 16384/*VarEnum.VT_BYREF*/ | 7/*VarEnum.VT_DATE*/:
                    return $.$spc.System.DateTime.FromOADate($.$spc.InteropUtility.castAddress2Object(unmanaged.GetRawDataRef($.$spc.System.IntPtr).$v));
                    case 16384/*VarEnum.VT_BYREF*/ | 10/*VarEnum.VT_ERROR*/:
                    return $.$box($.$spc.InteropUtility.castAddress2Object(unmanaged.GetRawDataRef($.$spc.System.IntPtr).$v), $.$spc.System.Int32);
                    case 16384/*VarEnum.VT_BYREF*/ | 6/*VarEnum.VT_CY*/:
                    return $.$spc.System.Decimal.FromOACurrency($.$spc.InteropUtility.castAddress2Object(unmanaged.GetRawDataRef($.$spc.System.IntPtr).$v));
                    case 16384/*VarEnum.VT_BYREF*/ | 13/*VarEnum.VT_UNKNOWN*/:
                    return $.$sris.System.Runtime.InteropServices.Marshalling.StrategyBasedComWrappers.DefaultMarshallingInstance.GetOrCreateObjectForComInstance($.$spc.InteropUtility.castAddress2Object(unmanaged.GetRawDataRef($.$spc.System.IntPtr).$v), 8/*CreateObjectFlags.Unwrap*/);
                    default:
                    throw new $.$spc.System.ArgumentException().$ctor$13($.$sris.System.SR.ComVariantMarshaller_UnmanagedTypeNotSupported, "unmanaged");
                }
            }
            static /*void */ Free(/*ComVariant*/ unmanaged)
            {
                return unmanaged.Dispose();
            }
            static $_RefPropagate;
            static get RefPropagate()
            {
                let $cls = $.$sris.System.Runtime.InteropServices.Marshalling.ComVariantMarshaller;
                return $cls.$_RefPropagate ??= $asm.$nstr("$sris.System.Runtime.InteropServices.Marshalling.ComVariantMarshaller.RefPropagate", ($self) => class RefPropagate extends $.$spc.System.ValueType
                {
                    /*ComVariant*/  get _unmanaged() { return this.$getField(0, 125); }
                    /*ComVariant*/  set _unmanaged(value) { this.$setField(0, 125, value); }
                    /*object?*/  get _managed() { return this.$getField(125, 4); }
                    /*object?*/  set _managed(value) { this.$setField(125, 4, value); }
                    /*void */ FromUnmanaged(/*ComVariant*/ unmanaged)
                    {
                        return this._unmanaged = unmanaged.Clone();
                    }
                    /*void */ FromManaged(/*object?*/ managed)
                    {
                        return this._managed = managed;
                    }
                    /*ComVariant */ ToUnmanaged()
                    {
                        if (!((this._unmanaged.VarType & (16384/*VarEnum.VT_BYREF*/)) == (16384/*VarEnum.VT_BYREF*/)))
                        {
                            return $.$sris.System.Runtime.InteropServices.Marshalling.ComVariantMarshaller.ConvertToUnmanaged(this._managed);
                        }
                        if (this._managed === null && (((this._unmanaged.VarType & ~16384/*VarEnum.VT_BYREF*/) === 8/*VarEnum.VT_BSTR*/) || ((this._unmanaged.VarType & ~16384/*VarEnum.VT_BYREF*/) === 9/*VarEnum.VT_DISPATCH*/)) || ((this._unmanaged.VarType & ~16384/*VarEnum.VT_BYREF*/) === 13/*VarEnum.VT_UNKNOWN*/))
                        {
                            $.$spc.InteropUtility.castAddress2Object(this._unmanaged.GetRawDataRef($.$spc.System.IntPtr).$v).$v = 0;
                            return this._unmanaged;
                        }
                        //switch ((_unmanaged.VarType & ~VarEnum.VT_BYREF, _managed))
                        let $switch2 = this._unmanaged.VarType & ~16384/*VarEnum.VT_BYREF*/;
                        let $switch3 = this._managed;
                        {
                            let s;
                            let b;
                            let u;
                            let i;
                            let l;
                            let ul;
                            let f;
                            let d;
                            let str;
                            let dt;
                            let error;
                            let cy;
                            let unkObj;
                            $switchJumpStart1: 
                            //case (VarEnum.VT_VARIANT, _):
                            if (($switch2 === 12/*VarEnum.VT_VARIANT*/))
                            {
                                $.$spc.InteropUtility.castAddress2Object(this._unmanaged.GetRawDataRef($.$spc.System.IntPtr).$v).$v = $.$sris.System.Runtime.InteropServices.Marshalling.ComVariantMarshaller.ConvertToUnmanaged(this._managed);
                            }
                            //case (VarEnum.VT_I1 or VarEnum.VT_UI1, sbyte s):
                            else if ((($switch2 === 16/*VarEnum.VT_I1*/) || ($switch2 === 17/*VarEnum.VT_UI1*/)) && ($.$is($switch3, $.$spc.System.SByte, { set $v(v){ s = v; } })))
                            {
                                $.$spc.InteropUtility.castAddress2Object(this._unmanaged.GetRawDataRef($.$spc.System.IntPtr).$v).$v = s;
                            }
                            //case (VarEnum.VT_I1 or VarEnum.VT_UI1, byte b):
                            else if ((($switch2 === 16/*VarEnum.VT_I1*/) || ($switch2 === 17/*VarEnum.VT_UI1*/)) && ($.$is($switch3, $.$spc.System.Byte, { set $v(v){ b = v; } })))
                            {
                                $.$spc.InteropUtility.castAddress2Object(this._unmanaged.GetRawDataRef($.$spc.System.IntPtr).$v).$v = b;
                            }
                            //case (VarEnum.VT_I2 or VarEnum.VT_UI2, short s):
                            else if ((($switch2 === 2/*VarEnum.VT_I2*/) || ($switch2 === 18/*VarEnum.VT_UI2*/)) && ($.$is($switch3, $.$spc.System.Int16, { set $v(v){ s = v; } })))
                            {
                                $.$spc.InteropUtility.castAddress2Object(this._unmanaged.GetRawDataRef($.$spc.System.IntPtr).$v).$v = s;
                            }
                            //case (VarEnum.VT_I2 or VarEnum.VT_UI2, ushort u):
                            else if ((($switch2 === 2/*VarEnum.VT_I2*/) || ($switch2 === 18/*VarEnum.VT_UI2*/)) && ($.$is($switch3, $.$spc.System.UInt16, { set $v(v){ u = v; } })))
                            {
                                $.$spc.InteropUtility.castAddress2Object(this._unmanaged.GetRawDataRef($.$spc.System.IntPtr).$v).$v = u;
                            }
                            //case (VarEnum.VT_I4 or VarEnum.VT_INT or VarEnum.VT_UI4 or VarEnum.VT_UINT or VarEnum.VT_ERROR, int i):
                            else if (((((($switch2 === 3/*VarEnum.VT_I4*/) || ($switch2 === 22/*VarEnum.VT_INT*/)) || ($switch2 === 19/*VarEnum.VT_UI4*/)) || ($switch2 === 23/*VarEnum.VT_UINT*/)) || ($switch2 === 10/*VarEnum.VT_ERROR*/)) && ($.$is($switch3, $.$spc.System.Int32, { set $v(v){ i = v; } })))
                            {
                                $.$spc.InteropUtility.castAddress2Object(this._unmanaged.GetRawDataRef($.$spc.System.IntPtr).$v).$v = i;
                            }
                            //case (VarEnum.VT_I4 or VarEnum.VT_INT or VarEnum.VT_UI4 or VarEnum.VT_UINT or VarEnum.VT_ERROR, uint u):
                            else if (((((($switch2 === 3/*VarEnum.VT_I4*/) || ($switch2 === 22/*VarEnum.VT_INT*/)) || ($switch2 === 19/*VarEnum.VT_UI4*/)) || ($switch2 === 23/*VarEnum.VT_UINT*/)) || ($switch2 === 10/*VarEnum.VT_ERROR*/)) && ($.$is($switch3, $.$spc.System.UInt32, { set $v(v){ u = v; } })))
                            {
                                $.$spc.InteropUtility.castAddress2Object(this._unmanaged.GetRawDataRef($.$spc.System.IntPtr).$v).$v = u;
                            }
                            //case (VarEnum.VT_I8 or VarEnum.VT_UI8, long l):
                            else if ((($switch2 === 20/*VarEnum.VT_I8*/) || ($switch2 === 21/*VarEnum.VT_UI8*/)) && ($.$is($switch3, $.$spc.System.Int64, { set $v(v){ l = v; } })))
                            {
                                $.$spc.InteropUtility.castAddress2Object(this._unmanaged.GetRawDataRef($.$spc.System.IntPtr).$v).$v = l;
                            }
                            //case (VarEnum.VT_I8 or VarEnum.VT_UI8, ulong ul):
                            else if ((($switch2 === 20/*VarEnum.VT_I8*/) || ($switch2 === 21/*VarEnum.VT_UI8*/)) && ($.$is($switch3, $.$spc.System.UInt64, { set $v(v){ ul = v; } })))
                            {
                                $.$spc.InteropUtility.castAddress2Object(this._unmanaged.GetRawDataRef($.$spc.System.IntPtr).$v).$v = ul;
                            }
                            //case (VarEnum.VT_R4, float f):
                            else if (($switch2 === 4/*VarEnum.VT_R4*/) && ($.$is($switch3, $.$spc.System.Single, { set $v(v){ f = v; } })))
                            {
                                $.$spc.InteropUtility.castAddress2Object(this._unmanaged.GetRawDataRef($.$spc.System.IntPtr).$v).$v = f;
                            }
                            //case (VarEnum.VT_R8, double d):
                            else if (($switch2 === 5/*VarEnum.VT_R8*/) && ($.$is($switch3, $.$spc.System.Double, { set $v(v){ d = v; } })))
                            {
                                $.$spc.InteropUtility.castAddress2Object(this._unmanaged.GetRawDataRef($.$spc.System.IntPtr).$v).$v = d;
                            }
                            //case (VarEnum.VT_DECIMAL, decimal d):
                            else if (($switch2 === 14/*VarEnum.VT_DECIMAL*/) && ($.$is($switch3, $.$spc.System.Decimal, { set $v(v){ d = v; } })))
                            {
                                $.$spc.InteropUtility.castAddress2Object(this._unmanaged.GetRawDataRef($.$spc.System.IntPtr).$v).$v = d;
                            }
                            //case (VarEnum.VT_BOOL, bool b):
                            else if (($switch2 === 11/*VarEnum.VT_BOOL*/) && ($.$is($switch3, $.$spc.System.Boolean, { set $v(v){ b = v; } })))
                            {
                                $.$spc.InteropUtility.castAddress2Object(this._unmanaged.GetRawDataRef($.$spc.System.IntPtr).$v).$v = b ? -1/*VARIANT_TRUE*/ : 0/*VARIANT_FALSE*/;
                            }
                            //case (VarEnum.VT_BSTR, string str):
                            else if (($switch2 === 8/*VarEnum.VT_BSTR*/) && ($.$is($switch3, $.$spc.System.String, { set $v(v){ str = v; } })))
                            {
                                {
                                    /*ref IntPtr*/ let bstrStorage = $.$cast(this._unmanaged.GetRawDataRef($.$spc.System.IntPtr).$v, $.$typePointer($.$spc.System.IntPtr));
                                    $.$spc.System.Runtime.InteropServices.Marshal.FreeBSTR(bstrStorage.$v);
                                    bstrStorage.$v = $.$spc.System.Runtime.InteropServices.Marshal.StringToBSTR(str);
                                    break $switchJumpStart1;
                                }
                            }
                            //case (VarEnum.VT_BSTR, BStrWrapper str):
                            else if (($switch2 === 8/*VarEnum.VT_BSTR*/) && ($.$is($switch3, $.$spc.System.Runtime.InteropServices.BStrWrapper, { set $v(v){ str = v; } })))
                            {
                                {
                                    /*ref IntPtr*/ let bstrStorage = $.$cast(this._unmanaged.GetRawDataRef($.$spc.System.IntPtr).$v, $.$typePointer($.$spc.System.IntPtr));
                                    $.$spc.System.Runtime.InteropServices.Marshal.FreeBSTR(bstrStorage.$v);
                                    bstrStorage.$v = $.$spc.System.Runtime.InteropServices.Marshal.StringToBSTR(str.WrappedObject);
                                    break $switchJumpStart1;
                                }
                            }
                            //case (VarEnum.VT_DATE, DateTime dt):
                            else if (($switch2 === 7/*VarEnum.VT_DATE*/) && ($.$is($switch3, $.$spc.System.DateTime, { set $v(v){ dt = v; } })))
                            {
                                $.$spc.InteropUtility.castAddress2Object(this._unmanaged.GetRawDataRef($.$spc.System.IntPtr).$v).$v = dt.ToOADate();
                            }
                            //case (VarEnum.VT_ERROR, ErrorWrapper error):
                            else if (($switch2 === 10/*VarEnum.VT_ERROR*/) && ($.$is($switch3, $.$spc.System.Runtime.InteropServices.ErrorWrapper, { set $v(v){ error = v; } })))
                            {
                                $.$spc.InteropUtility.castAddress2Object(this._unmanaged.GetRawDataRef($.$spc.System.IntPtr).$v).$v = error.ErrorCode;
                            }
                            //case (VarEnum.VT_CY, CurrencyWrapper cy):
                            else if (($switch2 === 6/*VarEnum.VT_CY*/) && ($.$is($switch3, $.$spc.System.Runtime.InteropServices.CurrencyWrapper, { set $v(v){ cy = v; } })))
                            {
                                $.$spc.InteropUtility.castAddress2Object(this._unmanaged.GetRawDataRef($.$spc.System.IntPtr).$v).$v = $.$spc.System.Decimal.ToOACurrency(cy.WrappedObject);
                            }
                            //case (VarEnum.VT_UNKNOWN, object unkObj):
                            else if (($switch2 === 13/*VarEnum.VT_UNKNOWN*/) && ($.$is($switch3, $.$spc.System.Object, { set $v(v){ unkObj = v; } })))
                            {
                                $.$spc.InteropUtility.castAddress2Object(this._unmanaged.GetRawDataRef($.$spc.System.IntPtr).$v).$v = $.$sris.System.Runtime.InteropServices.Marshalling.StrategyBasedComWrappers.DefaultMarshallingInstance.GetOrCreateComInterfaceForObject(unkObj, 0/*CreateComInterfaceFlags.None*/);
                            }
                            //default
                            else
                            {
                                throw new $.$spc.System.ArgumentException().$ctor$13("Invalid combination of unmanaged variant type and managed object type.", "_managed");
                            }
                        }
                        return this._unmanaged;
                    }
                    /*object? */ ToManaged()
                    {
                        return $.$sris.System.Runtime.InteropServices.Marshalling.ComVariantMarshaller.ConvertToManaged(this._unmanaged.Clone());
                    }
                    /*void */ Free()
                    {
                        return this._unmanaged.Dispose();
                    }
                    //default value type constructor
                    $ctor$2()
                    {
                        return this;
                    }
                    Clone($copy)
                    {
                        let copy = $copy ?? new this.constructor();
                        copy._unmanaged = this._unmanaged.Clone();
                        copy._managed = this._managed;
                        return copy;
                    }
                    //default member initializer
                    constructor()
                    {
                        super();
                        this._unmanaged = $.$default($.$spc.System.Runtime.InteropServices.Marshalling.ComVariant);
                        this._managed = null;
                    }
                    static $h = 2347906;
                    static $z = 129;
                    static $f = 0b10000001010000001;
                    static $k = 2;
                    static $$md;
                    static get $md() { return this.$$md ??= {"b":196609,"m":[{"r":65537,"p":[{"n":"unmanaged","p":106233857}],"n":"FromUnmanaged","d":2347906,"h":12887249794,"f":1},{"r":65537,"p":[{"n":"managed","p":131073}],"n":"FromManaged","d":2347906,"h":17182217090,"f":1},{"r":106233857,"n":"ToUnmanaged","d":2347906,"h":21477184386,"f":1},{"r":131073,"n":"ToManaged","d":2347906,"h":25772151682,"f":1},{"r":65537,"n":"Free","d":2347906,"h":30067118978,"f":1}],"l":[{"t":106233857,"n":"_unmanaged","d":2347906,"h":4297315202,"f":2},{"t":131073,"n":"_managed","d":2347906,"h":8592282498,"f":2}],"c":[{"n":".ctor","o":"$ctor$2","d":2347906,"h":34362086274,"f":1}],"d":2282370,"h":2347906}; }
                    static get $b() { return $.$spc.System.ValueType; }
                    static get $fullName() { return `System.Runtime.InteropServices.Marshalling.ComVariantMarshaller.RefPropagate`; }
                }, $cls, ($v) => $cls.$_RefPropagate = $v);
            }
            static $h = 2282370;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"m":[{"r":106233857,"p":[{"n":"managed","p":131073}],"n":"ConvertToUnmanaged","d":2282370,"h":12887184258,"f":33},{"r":262145,"p":[{"n":"managed","p":131073},{"n":"variant","p":106233857,"f":2}],"n":"TryCreateOleVariantForInterfaceWrapper","d":2282370,"h":17182151554,"f":34},{"r":131073,"p":[{"n":"unmanaged","p":106233857}],"n":"ConvertToManaged","d":2282370,"h":21477118850,"f":33},{"r":65537,"p":[{"n":"unmanaged","p":106233857}],"n":"Free","d":2282370,"h":25772086146,"f":33}],"l":[{"t":524289,"n":"VARIANT_TRUE","d":2282370,"h":4297249666,"f":34},{"t":524289,"n":"VARIANT_FALSE","d":2282370,"h":8592216962,"f":34}],"j":[2347906],"h":2282370,"a":[{"t":106823681,"c":4401790977,"a":[{"v":131073,"t":142606337},{"v":0,"t":106954753},{"v":2282370,"t":142606337}]},{"t":106823681,"c":4401790977,"a":[{"v":131073,"t":142606337},{"v":5,"t":106954753},{"v":2347906,"t":142606337}]}]}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.Runtime.InteropServices.Marshalling.ComVariantMarshaller`; }
        });
        
        $asm.$cls("$sris.System.Runtime.InteropServices.Marshalling.UniqueComInterfaceMarshaller<>", (T) => $asm.$gt("$sris.System.Runtime.InteropServices.Marshalling.UniqueComInterfaceMarshaller<>", [T], ($self) => class UniqueComInterfaceMarshaller$$
        {
            static /*void* */ ConvertToUnmanaged(/*T?*/ managed)
            {
                if ($.$box(managed, T) === null)
                {
                    return null;
                }
                /*nint*/ let unknown;
                if (!$.$spc.System.Runtime.InteropServices.ComWrappers.TryGetComInstance($.$box(managed, T), $.$ref(() => unknown, ($v) => unknown = $v, $.$spc.System.IntPtr)))
                {
                    unknown = $.$sris.System.Runtime.InteropServices.Marshalling.StrategyBasedComWrappers.DefaultMarshallingInstance.GetOrCreateComInterfaceForObject($.$box(managed, T), 0/*CreateComInterfaceFlags.None*/);
                }
                return $.$sris.System.Runtime.InteropServices.Marshalling.ComInterfaceMarshaller$$(T).CastIUnknownToInterfaceType(unknown);
            }
            static /*T? */ ConvertToManaged(/*void**/ unmanaged)
            {
                if (unmanaged === null)
                {
                    return $.$default(T);
                }
                return $.$cast($.$sris.System.Runtime.InteropServices.Marshalling.StrategyBasedComWrappers.DefaultMarshallingInstance.GetOrCreateObjectForComInstance($.$spc.System.IntPtr.op_Explicit$2(unmanaged), 2/*CreateObjectFlags.UniqueInstance*/), T);
            }
            static /*void */ Free(/*void**/ unmanaged)
            {
                if (unmanaged !== null)
                {
                    $.$spc.System.Runtime.InteropServices.Marshal.Release($.$spc.System.IntPtr.op_Explicit$2(unmanaged));
                }
            }
            static $h = 3724162;
            static $g = 1;
            static $f = 0b1010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"m":[{"r":0,"p":[{"n":"managed","p":T?.$h??1507328}],"n":"ConvertToUnmanaged","d":this.$h,"h":Number(BigInt(this.$h)|0x100000000n),"f":33},{"r":T?.$h??1507328,"p":[{"n":"unmanaged","p":0}],"n":"ConvertToManaged","d":this.$h,"h":Number(BigInt(this.$h)|0x200000000n),"f":33},{"r":65537,"p":[{"n":"unmanaged","p":0}],"n":"Free","d":this.$h,"h":Number(BigInt(this.$h)|0x300000000n),"f":33}],"g":[T?.$h??1507328],"r":1,"h":this.$h,"a":[{"t":115277825,"c":4410245121,"a":[{"v":"android","t":1310721}]},{"t":115277825,"c":4410245121,"a":[{"v":"browser","t":1310721}]},{"t":115277825,"c":4410245121,"a":[{"v":"ios","t":1310721}]},{"t":115277825,"c":4410245121,"a":[{"v":"tvos","t":1310721}]},{"t":23396353,"c":8613330945,"a":[{"v":false,"t":262145}]},{"t":106823681,"c":4401790977,"a":[{"v":106889217,"t":142606337},{"v":0,"t":106954753},{"v":$.$sris.System.Runtime.InteropServices.Marshalling.UniqueComInterfaceMarshaller$$().$h,"t":142606337}]}]}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.Runtime.InteropServices.Marshalling.UniqueComInterfaceMarshaller<${T?.$fullName}>`; }
        }));
        
        $asm.$cls("$sris.System.Runtime.InteropServices.Marshalling.ExceptionAsDefaultMarshaller<>", (T) => $asm.$gt("$sris.System.Runtime.InteropServices.Marshalling.ExceptionAsDefaultMarshaller<>", [T], ($self) => class ExceptionAsDefaultMarshaller$$
        {
            static /*T */ ConvertToUnmanaged(/*Exception*/ e)
            {
                _ = $.$spc.System.Runtime.InteropServices.Marshal.GetHRForException(e);
                return $.$default(T);
            }
            static $h = 2544514;
            static $g = 1;
            static $f = 0b1010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"m":[{"r":T?.$h??1507328,"p":[{"n":"e","p":47185921}],"n":"ConvertToUnmanaged","d":this.$h,"h":Number(BigInt(this.$h)|0x100000000n),"f":33}],"g":[T?.$h??1507328],"s":[{"n":"T","f":10}],"r":1,"h":this.$h,"a":[{"t":106823681,"c":4401790977,"a":[{"v":47185921,"t":142606337},{"v":6,"t":106954753},{"v":$.$sris.System.Runtime.InteropServices.Marshalling.ExceptionAsDefaultMarshaller$$().$h,"t":142606337}]}]}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.Runtime.InteropServices.Marshalling.ExceptionAsDefaultMarshaller<${T?.$fullName}>`; }
        }));
        
        $asm.$cls("$sris.System.Runtime.InteropServices.Marshalling.ExceptionAsNaNMarshaller<>", (T) => $asm.$gt("$sris.System.Runtime.InteropServices.Marshalling.ExceptionAsNaNMarshaller<>", [T], ($self) => class ExceptionAsNaNMarshaller$$
        {
            static /*T */ ConvertToUnmanaged(/*Exception*/ e)
            {
                _ = $.$spc.System.Runtime.InteropServices.Marshal.GetHRForException(e);
                return T.System$Numerics$IFloatingPointIeee754$$$NaN;
            }
            static $h = 2675586;
            static $g = 1;
            static $f = 0b1010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"m":[{"r":T?.$h??1507328,"p":[{"n":"e","p":47185921}],"n":"ConvertToUnmanaged","d":this.$h,"h":Number(BigInt(this.$h)|0x100000000n),"f":33}],"g":[T?.$h??1507328],"s":[{"n":"T","f":10,"c":[$.$spc.System.Numerics.IFloatingPointIeee754$$(T).$h]}],"r":1,"h":this.$h,"a":[{"t":106823681,"c":4401790977,"a":[{"v":47185921,"t":142606337},{"v":6,"t":106954753},{"v":$.$sris.System.Runtime.InteropServices.Marshalling.ExceptionAsNaNMarshaller$$().$h,"t":142606337}]}]}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.Runtime.InteropServices.Marshalling.ExceptionAsNaNMarshaller<${T?.$fullName}>`; }
        }));
        
        $asm.$cls("$sris.System.Runtime.InteropServices.Marshalling.ExceptionAsVoidMarshaller", ($self) => class ExceptionAsVoidMarshaller
        {
            static /*void */ ConvertToUnmanaged(/*Exception*/ e)
            {
                _ = $.$spc.System.Runtime.InteropServices.Marshal.GetHRForException(e);
            }
            static $h = 2741122;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"m":[{"r":65537,"p":[{"n":"e","p":47185921}],"n":"ConvertToUnmanaged","d":2741122,"h":4297708418,"f":33}],"h":2741122,"a":[{"t":106823681,"c":4401790977,"a":[{"v":47185921,"t":142606337},{"v":6,"t":106954753},{"v":2741122,"t":142606337}]}]}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.Runtime.InteropServices.Marshalling.ExceptionAsVoidMarshaller`; }
        });
        
        $asm.$cls("$sris.System.Runtime.InteropServices.Marshalling.ExceptionAsHResultMarshaller<>", (T) => $asm.$gt("$sris.System.Runtime.InteropServices.Marshalling.ExceptionAsHResultMarshaller<>", [T], ($self) => class ExceptionAsHResultMarshaller$$
        {
            static /*T */ ConvertToUnmanaged(/*Exception*/ e)
            {
                return T.System$Numerics$INumberBase$$$CreateTruncating($.$spc.System.Int32, $.$spc.System.Runtime.InteropServices.Marshal.GetHRForException(e));
            }
            static $h = 2610050;
            static $g = 1;
            static $f = 0b1010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"m":[{"r":T?.$h??1507328,"p":[{"n":"e","p":47185921}],"n":"ConvertToUnmanaged","d":this.$h,"h":Number(BigInt(this.$h)|0x100000000n),"f":33}],"g":[T?.$h??1507328],"s":[{"n":"T","f":10,"c":[$.$spc.System.Numerics.INumber$$(T).$h]}],"r":1,"h":this.$h,"a":[{"t":106823681,"c":4401790977,"a":[{"v":47185921,"t":142606337},{"v":6,"t":106954753},{"v":$.$sris.System.Runtime.InteropServices.Marshalling.ExceptionAsHResultMarshaller$$().$h,"t":142606337}]}]}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.Runtime.InteropServices.Marshalling.ExceptionAsHResultMarshaller<${T?.$fullName}>`; }
        }));
        
        $asm.$cls("$sris.System.Runtime.InteropServices.Marshalling.ComInterfaceMarshaller<>", (T) => $asm.$gt("$sris.System.Runtime.InteropServices.Marshalling.ComInterfaceMarshaller<>", [T], ($self) => class ComInterfaceMarshaller$$
        {
            /*Guid?*/ static TargetInterfaceIID = null;
            static /*void* */ ConvertToUnmanaged(/*T?*/ managed)
            {
                if ($.$box(managed, T) === null)
                {
                    return null;
                }
                /*nint*/ let unknown;
                if (!$.$spc.System.Runtime.InteropServices.ComWrappers.TryGetComInstance($.$box(managed, T), $.$ref(() => unknown, ($v) => unknown = $v, $.$spc.System.IntPtr)))
                {
                    unknown = $.$sris.System.Runtime.InteropServices.Marshalling.StrategyBasedComWrappers.DefaultMarshallingInstance.GetOrCreateComInterfaceForObject($.$box(managed, T), 0/*CreateComInterfaceFlags.None*/);
                }
                return $.$sris.System.Runtime.InteropServices.Marshalling.ComInterfaceMarshaller$$(T).CastIUnknownToInterfaceType(unknown);
            }
            static /*T? */ ConvertToManaged(/*void**/ unmanaged)
            {
                if (unmanaged === null)
                {
                    return $.$default(T);
                }
                return $.$cast($.$sris.System.Runtime.InteropServices.Marshalling.StrategyBasedComWrappers.DefaultMarshallingInstance.GetOrCreateObjectForComInstance($.$spc.System.IntPtr.op_Explicit$2(unmanaged), 8/*CreateObjectFlags.Unwrap*/), T);
            }
            static /*void */ Free(/*void**/ unmanaged)
            {
                if (unmanaged !== null)
                {
                    $.$spc.System.Runtime.InteropServices.Marshal.Release($.$spc.System.IntPtr.op_Explicit$2(unmanaged));
                }
            }
            static /*void* */ CastIUnknownToInterfaceType(/*nint*/ unknown)
            {
                if ($.$sris.System.Runtime.InteropServices.Marshalling.ComInterfaceMarshaller$$(T).TargetInterfaceIID === null)
                {
                    return $.$spc.System.IntPtr.op_Explicit$3(unknown);
                }
                /*nint*/ let interfacePointer;
                if ($.$spc.System.Runtime.InteropServices.Marshal.QueryInterface(unknown, $.$spc.System.Nullable.GetValueRefOrDefaultRef($.$spc.System.Guid, $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateObjectReferenceT($.$typeNullable($.$spc.System.Guid), () => $.$sris.System.Runtime.InteropServices.Marshalling.ComInterfaceMarshaller$$(T).TargetInterfaceIID, ($v) => $.$sris.System.Runtime.InteropServices.Marshalling.ComInterfaceMarshaller$$(T).TargetInterfaceIID = $v, null)), $.$ref(() => interfacePointer, ($v) => interfacePointer = $v, $.$spc.System.IntPtr)) !== 0)
                {
                    $.$spc.System.Runtime.InteropServices.Marshal.Release(unknown);
                    throw new $.$spc.System.InvalidCastException().$ctor$10((() =>
                    {
                        var $handler = new $.$spc.System.Runtime.CompilerServices.DefaultInterpolatedStringHandler().$ctor$2(2, 1);
                        $handler.AppendLiteral("Unable to cast the provided managed object to a COM interface with ID '");
                        $handler.AppendFormatted$8($.$box($.$spc.System.Nullable$$($.$spc.System.Guid).GetValueOrDefault.call($.$sris.System.Runtime.InteropServices.Marshalling.ComInterfaceMarshaller$$(T).TargetInterfaceIID), $.$spc.System.Guid), null, "B");
                        $handler.AppendLiteral("'");
                        return $handler.ToStringAndClear();
                    })());
                }
                $.$spc.System.Runtime.InteropServices.Marshal.Release(unknown);
                return $.$spc.System.IntPtr.op_Explicit$3(interfacePointer);
            }
            //Static Initializer
            static $sinit()
            {
                {
                    this.TargetInterfaceIID = ($.$sris.System.Runtime.InteropServices.Marshalling.StrategyBasedComWrappers.DefaultIUnknownInterfaceDetailsStrategy.System$Runtime$InteropServices$Marshalling$IIUnknownInterfaceDetailsStrategy$GetIUnknownDerivedDetails(T.$type.TypeHandle)?.System$Runtime$InteropServices$Marshalling$IIUnknownDerivedDetails$Iid ?? null);
                }
            }
            static $h = 2085762;
            static $g = 1;
            static $f = 0b1010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"m":[{"r":0,"p":[{"n":"managed","p":T?.$h??1507328}],"n":"ConvertToUnmanaged","d":this.$h,"h":Number(BigInt(this.$h)|0x200000000n),"f":33},{"r":T?.$h??1507328,"p":[{"n":"unmanaged","p":0}],"n":"ConvertToManaged","d":this.$h,"h":Number(BigInt(this.$h)|0x300000000n),"f":33},{"r":65537,"p":[{"n":"unmanaged","p":0}],"n":"Free","d":this.$h,"h":Number(BigInt(this.$h)|0x400000000n),"f":33},{"r":0,"p":[{"n":"unknown","p":786433}],"n":"CastIUnknownToInterfaceType","d":this.$h,"h":Number(BigInt(this.$h)|0x500000000n),"f":40}],"l":[{"t":$.$typeNullable($.$spc.System.Guid).$h,"n":"TargetInterfaceIID","d":this.$h,"h":Number(BigInt(this.$h)|0x100000000n),"f":34}],"g":[T?.$h??1507328],"r":1,"h":this.$h,"a":[{"t":115277825,"c":4410245121,"a":[{"v":"android","t":1310721}]},{"t":115277825,"c":4410245121,"a":[{"v":"browser","t":1310721}]},{"t":115277825,"c":4410245121,"a":[{"v":"ios","t":1310721}]},{"t":115277825,"c":4410245121,"a":[{"v":"tvos","t":1310721}]},{"t":23396353,"c":8613330945,"a":[{"v":false,"t":262145}]},{"t":106823681,"c":4401790977,"a":[{"v":106889217,"t":142606337},{"v":0,"t":106954753},{"v":$.$sris.System.Runtime.InteropServices.Marshalling.ComInterfaceMarshaller$$().$h,"t":142606337}]}]}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.Runtime.InteropServices.Marshalling.ComInterfaceMarshaller<${T?.$fullName}>`; }
        }));
        
        $asm.$cls("$sris.System.Runtime.InteropServices.RuntimeEnvironment", ($self) => class RuntimeEnvironment
        {
            static /*string */ get SystemConfigurationFile()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static /*bool */ FromGlobalAccessCache(/*Assembly*/ a)
            {
                return false;
            }
            static /*string */ GetRuntimeDirectory()
            {
                /*string?*/ let runtimeDirectory = $.$spc.System.Object.$type.Assembly.Location;
                if (!$.$spc.System.IO.Path.IsPathRooted(runtimeDirectory))
                {
                    runtimeDirectory = $.$spc.System.AppDomain.CurrentDomain.BaseDirectory;
                }
                /*char*/ let sep = $.$spc.System.IO.Path.DirectorySeparatorChar;
                return $.$spc.System.String.Concat$10($.$spc.System.String.op_Implicit($.$spc.System.IO.Path.GetDirectoryName(runtimeDirectory)), new ($.$spc.System.ReadOnlySpan$$($.$spc.System.Char))().$ctor$5($.$ref(() => sep, undefined, $.$spc.System.Char)));
            }
            static /*IntPtr */ GetRuntimeInterfaceAsIntPtr(/*Guid*/ clsid, /*Guid*/ riid)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static /*object */ GetRuntimeInterfaceAsObject(/*Guid*/ clsid, /*Guid*/ riid)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static /*string */ GetSystemVersion()
            {
                return `v${$.$spc.System.Environment.Version}`;
            }
            static $h = 4051842;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":1310721,"g":{"r":0,"d":0,"h":8593986434,"f":33},"n":"SystemConfigurationFile","d":4051842,"h":4299019138,"f":33,"a":[{"t":70909953,"c":8660844545,"a":[{"v":"RuntimeEnvironment members SystemConfigurationFile, GetRuntimeInterfaceAsIntPtr, and GetRuntimeInterfaceAsObject are not supported and throw PlatformNotSupportedException.","t":1310721}],"n":[{"n":"DiagnosticId","v":"SYSLIB0019","t":1310721},{"n":"UrlFormat","v":"https://aka.ms/dotnet-warnings/{0}","t":1310721}]}]}],"m":[{"r":262145,"p":[{"n":"a","p":73465857}],"n":"FromGlobalAccessCache","d":4051842,"h":12888953730,"f":33},{"r":1310721,"n":"GetRuntimeDirectory","d":4051842,"h":17183921026,"f":33},{"r":786433,"p":[{"n":"clsid","p":56164353},{"n":"riid","p":56164353}],"n":"GetRuntimeInterfaceAsIntPtr","d":4051842,"h":21478888322,"f":33,"a":[{"t":70909953,"c":8660844545,"a":[{"v":"RuntimeEnvironment members SystemConfigurationFile, GetRuntimeInterfaceAsIntPtr, and GetRuntimeInterfaceAsObject are not supported and throw PlatformNotSupportedException.","t":1310721}],"n":[{"n":"DiagnosticId","v":"SYSLIB0019","t":1310721},{"n":"UrlFormat","v":"https://aka.ms/dotnet-warnings/{0}","t":1310721}]}]},{"r":131073,"p":[{"n":"clsid","p":56164353},{"n":"riid","p":56164353}],"n":"GetRuntimeInterfaceAsObject","d":4051842,"h":25773855618,"f":33,"a":[{"t":70909953,"c":8660844545,"a":[{"v":"RuntimeEnvironment members SystemConfigurationFile, GetRuntimeInterfaceAsIntPtr, and GetRuntimeInterfaceAsObject are not supported and throw PlatformNotSupportedException.","t":1310721}],"n":[{"n":"DiagnosticId","v":"SYSLIB0019","t":1310721},{"n":"UrlFormat","v":"https://aka.ms/dotnet-warnings/{0}","t":1310721}]}]},{"r":1310721,"n":"GetSystemVersion","d":4051842,"h":30068822914,"f":33}],"h":4051842}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.Runtime.InteropServices.RuntimeEnvironment`; }
        });
        
        $asm.$cls("$sris.System.Security.SecureStringMarshal", ($self) => class SecureStringMarshal
        {
            static /*IntPtr */ SecureStringToCoTaskMemAnsi(/*SecureString*/ s)
            {
                return $.$spc.System.Runtime.InteropServices.Marshal.SecureStringToCoTaskMemAnsi(s);
            }
            static /*IntPtr */ SecureStringToGlobalAllocAnsi(/*SecureString*/ s)
            {
                return $.$spc.System.Runtime.InteropServices.Marshal.SecureStringToGlobalAllocAnsi(s);
            }
            static /*IntPtr */ SecureStringToCoTaskMemUnicode(/*SecureString*/ s)
            {
                return $.$spc.System.Runtime.InteropServices.Marshal.SecureStringToCoTaskMemUnicode(s);
            }
            static /*IntPtr */ SecureStringToGlobalAllocUnicode(/*SecureString*/ s)
            {
                return $.$spc.System.Runtime.InteropServices.Marshal.SecureStringToGlobalAllocUnicode(s);
            }
            static $h = 4641666;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"m":[{"r":786433,"p":[{"n":"s","p":117309441}],"n":"SecureStringToCoTaskMemAnsi","d":4641666,"h":4299608962,"f":33},{"r":786433,"p":[{"n":"s","p":117309441}],"n":"SecureStringToGlobalAllocAnsi","d":4641666,"h":8594576258,"f":33},{"r":786433,"p":[{"n":"s","p":117309441}],"n":"SecureStringToCoTaskMemUnicode","d":4641666,"h":12889543554,"f":33},{"r":786433,"p":[{"n":"s","p":117309441}],"n":"SecureStringToGlobalAllocUnicode","d":4641666,"h":17184510850,"f":33}],"h":4641666}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.Security.SecureStringMarshal`; }
        });
        
        $asm.$cls("$sris.System.Obsoletions", ($self) => class Obsoletions
        {
            /*string*/ static SharedUrlFormat = null;
            /*string*/ static SystemTextEncodingUTF7Message = null;
            /*string*/ static SystemTextEncodingUTF7DiagId = null;
            /*string*/ static PrincipalPermissionAttributeMessage = null;
            /*string*/ static PrincipalPermissionAttributeDiagId = null;
            /*string*/ static CodeAccessSecurityMessage = null;
            /*string*/ static CodeAccessSecurityDiagId = null;
            /*string*/ static ConstrainedExecutionRegionMessage = null;
            /*string*/ static ConstrainedExecutionRegionDiagId = null;
            /*string*/ static GlobalAssemblyCacheMessage = null;
            /*string*/ static GlobalAssemblyCacheDiagId = null;
            /*string*/ static ThreadAbortMessage = null;
            /*string*/ static ThreadResetAbortMessage = null;
            /*string*/ static ThreadAbortDiagId = null;
            /*string*/ static DefaultCryptoAlgorithmsMessage = null;
            /*string*/ static DefaultCryptoAlgorithmsDiagId = null;
            /*string*/ static CreatePdbGeneratorMessage = null;
            /*string*/ static CreatePdbGeneratorDiagId = null;
            /*string*/ static AuthenticationManagerMessage = null;
            /*string*/ static AuthenticationManagerDiagId = null;
            /*string*/ static RemotingApisMessage = null;
            /*string*/ static RemotingApisDiagId = null;
            /*string*/ static BinaryFormatterMessage = null;
            /*string*/ static BinaryFormatterDiagId = null;
            /*string*/ static CodeBaseMessage = null;
            /*string*/ static CodeBaseDiagId = null;
            /*string*/ static EscapeUriStringMessage = null;
            /*string*/ static EscapeUriStringDiagId = null;
            /*string*/ static WebRequestMessage = null;
            /*string*/ static WebRequestDiagId = null;
            /*string*/ static DisablePrivateReflectionAttributeMessage = null;
            /*string*/ static DisablePrivateReflectionAttributeDiagId = null;
            /*string*/ static GetContextInfoMessage = null;
            /*string*/ static GetContextInfoDiagId = null;
            /*string*/ static StrongNameKeyPairMessage = null;
            /*string*/ static StrongNameKeyPairDiagId = null;
            /*string*/ static ReflectionOnlyLoadingMessage = null;
            /*string*/ static ReflectionOnlyLoadingDiagId = null;
            /*string*/ static RuntimeEnvironmentMessage = null;
            /*string*/ static RuntimeEnvironmentDiagId = null;
            /*string*/ static JsonSerializerOptionsIgnoreNullValuesMessage = null;
            /*string*/ static JsonSerializerOptionsIgnoreNullValuesDiagId = null;
            /*string*/ static DerivedCryptographicTypesMessage = null;
            /*string*/ static DerivedCryptographicTypesDiagId = null;
            /*string*/ static RijndaelMessage = null;
            /*string*/ static RijndaelDiagId = null;
            /*string*/ static RNGCryptoServiceProviderMessage = null;
            /*string*/ static RNGCryptoServiceProviderDiagId = null;
            /*string*/ static AppDomainCreateUnloadMessage = null;
            /*string*/ static AppDomainCreateUnloadDiagId = null;
            /*string*/ static SuppressIldasmAttributeMessage = null;
            /*string*/ static SuppressIldasmAttributeDiagId = null;
            /*string*/ static X509CertificateImmutableMessage = null;
            /*string*/ static X509CertificateImmutableDiagId = null;
            /*string*/ static PublicKeyPropertyMessage = null;
            /*string*/ static PublicKeyPropertyDiagId = null;
            /*string*/ static X509CertificatePrivateKeyMessage = null;
            /*string*/ static X509CertificatePrivateKeyDiagId = null;
            /*string*/ static ProduceLegacyHmacValuesMessage = null;
            /*string*/ static ProduceLegacyHmacValuesDiagId = null;
            /*string*/ static UseManagedSha1Message = null;
            /*string*/ static UseManagedSha1DiagId = null;
            /*string*/ static CryptoConfigEncodeOIDMessage = null;
            /*string*/ static CryptoConfigEncodeOIDDiagId = null;
            /*string*/ static CorruptedStateRecoveryMessage = null;
            /*string*/ static CorruptedStateRecoveryDiagId = null;
            /*string*/ static Rfc2898CryptDeriveKeyMessage = null;
            /*string*/ static Rfc2898CryptDeriveKeyDiagId = null;
            /*string*/ static CmsSignerCspParamsCtorMessage = null;
            /*string*/ static CmsSignerCspParamsCtorDiagId = null;
            /*string*/ static SignerInfoCounterSigMessage = null;
            /*string*/ static SignerInfoCounterSigDiagId = null;
            /*string*/ static RegexCompileToAssemblyMessage = null;
            /*string*/ static RegexCompileToAssemblyDiagId = null;
            /*string*/ static AssemblyNameMembersMessage = null;
            /*string*/ static AssemblyNameMembersDiagId = null;
            /*string*/ static SystemDataSerializationFormatBinaryMessage = null;
            /*string*/ static SystemDataSerializationFormatBinaryDiagId = null;
            /*string*/ static TlsVersion10and11Message = null;
            /*string*/ static TlsVersion10and11DiagId = null;
            /*string*/ static EncryptionPolicyMessage = null;
            /*string*/ static EncryptionPolicyDiagId = null;
            /*string*/ static EccXmlExportImportMessage = null;
            /*string*/ static EccXmlExportImportDiagId = null;
            /*string*/ static EcDhPublicKeyBlobMessage = null;
            /*string*/ static EcDhPublicKeyBlobDiagId = null;
            /*string*/ static AssemblyNameCodeBaseMessage = null;
            /*string*/ static AssemblyNameCodeBaseDiagId = null;
            /*string*/ static CryptoStringFactoryMessage = null;
            /*string*/ static CryptoStringFactoryDiagId = null;
            /*string*/ static ControlledExecutionRunMessage = null;
            /*string*/ static ControlledExecutionRunDiagId = null;
            /*string*/ static XmlSecureResolverMessage = null;
            /*string*/ static XmlSecureResolverDiagId = null;
            /*string*/ static RsaEncryptDecryptValueMessage = null;
            /*string*/ static RsaEncryptDecryptDiagId = null;
            /*string*/ static JsonSerializerOptionsAddContextMessage = null;
            /*string*/ static JsonSerializerOptionsAddContextDiagId = null;
            /*string*/ static LegacyFormatterMessage = null;
            /*string*/ static LegacyFormatterDiagId = null;
            /*string*/ static LegacyFormatterImplMessage = null;
            /*string*/ static LegacyFormatterImplDiagId = null;
            /*string*/ static RegexExtensibilityImplMessage = null;
            /*string*/ static RegexExtensibilityDiagId = null;
            /*string*/ static AesGcmTagConstructorMessage = null;
            /*string*/ static AesGcmTagConstructorDiagId = null;
            /*string*/ static ThreadVolatileReadWriteMessage = null;
            /*string*/ static ThreadVolatileReadWriteDiagId = null;
            /*string*/ static ArmIntrinsicPerformsUnsignedOperationMessage = null;
            /*string*/ static ArmIntrinsicPerformsUnsignedOperationDiagId = null;
            /*string*/ static LoadFromHashAlgorithmMessage = null;
            /*string*/ static LoadFromHashAlgorithmDiagId = null;
            /*string*/ static X509CtorCertDataObsoleteMessage = null;
            /*string*/ static X509CtorCertDataObsoleteDiagId = null;
            /*string*/ static TlsCipherAlgorithmEnumsMessage = null;
            /*string*/ static TlsCipherAlgorithmEnumsDiagId = null;
            /*string*/ static SystemEventsEventsThreadShutdownMessage = null;
            /*string*/ static SystemEventsEventsThreadShutdownDiagId = null;
            /*string*/ static Rfc2898DeriveBytesCtorMessage = null;
            /*string*/ static Rfc2898DeriveBytesCtorDiagId = null;
            /*string*/ static QueryableMinByMaxByTSourceObsoleteMessage = null;
            /*string*/ static QueryableMinByMaxByTSourceObsoleteDiagId = null;
            /*string*/ static XsltSettingsEnableScriptMessage = null;
            /*string*/ static XsltSettingsEnableScriptDiagId = null;
            //Static Initializer
            static $sinit()
            {
                {
                    this.SharedUrlFormat = "https://aka.ms/dotnet-warnings/{0}";
                }
                {
                    this.SystemTextEncodingUTF7Message = "The UTF-7 encoding is insecure and should not be used. Consider using UTF-8 instead.";
                }
                {
                    this.SystemTextEncodingUTF7DiagId = "SYSLIB0001";
                }
                {
                    this.PrincipalPermissionAttributeMessage = "PrincipalPermissionAttribute is not honored by the runtime and must not be used.";
                }
                {
                    this.PrincipalPermissionAttributeDiagId = "SYSLIB0002";
                }
                {
                    this.CodeAccessSecurityMessage = "Code Access Security is not supported or honored by the runtime.";
                }
                {
                    this.CodeAccessSecurityDiagId = "SYSLIB0003";
                }
                {
                    this.ConstrainedExecutionRegionMessage = "The Constrained Execution Region (CER) feature is not supported.";
                }
                {
                    this.ConstrainedExecutionRegionDiagId = "SYSLIB0004";
                }
                {
                    this.GlobalAssemblyCacheMessage = "The Global Assembly Cache is not supported.";
                }
                {
                    this.GlobalAssemblyCacheDiagId = "SYSLIB0005";
                }
                {
                    this.ThreadAbortMessage = "Thread.Abort is not supported and throws PlatformNotSupportedException.";
                }
                {
                    this.ThreadResetAbortMessage = "Thread.ResetAbort is not supported and throws PlatformNotSupportedException.";
                }
                {
                    this.ThreadAbortDiagId = "SYSLIB0006";
                }
                {
                    this.DefaultCryptoAlgorithmsMessage = "The default implementation of this cryptography algorithm is not supported.";
                }
                {
                    this.DefaultCryptoAlgorithmsDiagId = "SYSLIB0007";
                }
                {
                    this.CreatePdbGeneratorMessage = "The CreatePdbGenerator API is not supported and throws PlatformNotSupportedException.";
                }
                {
                    this.CreatePdbGeneratorDiagId = "SYSLIB0008";
                }
                {
                    this.AuthenticationManagerMessage = "AuthenticationManager is not supported. Methods will no-op or throw PlatformNotSupportedException.";
                }
                {
                    this.AuthenticationManagerDiagId = "SYSLIB0009";
                }
                {
                    this.RemotingApisMessage = "This Remoting API is not supported and throws PlatformNotSupportedException.";
                }
                {
                    this.RemotingApisDiagId = "SYSLIB0010";
                }
                {
                    this.BinaryFormatterMessage = "BinaryFormatter serialization is obsolete and should not be used. See https://aka.ms/binaryformatter for more information.";
                }
                {
                    this.BinaryFormatterDiagId = "SYSLIB0011";
                }
                {
                    this.CodeBaseMessage = "Assembly.CodeBase and Assembly.EscapedCodeBase are only included for .NET Framework compatibility. Use Assembly.Location instead.";
                }
                {
                    this.CodeBaseDiagId = "SYSLIB0012";
                }
                {
                    this.EscapeUriStringMessage = "Uri.EscapeUriString can corrupt the Uri string in some cases. Consider using Uri.EscapeDataString for query string components instead.";
                }
                {
                    this.EscapeUriStringDiagId = "SYSLIB0013";
                }
                {
                    this.WebRequestMessage = "WebRequest, HttpWebRequest, ServicePoint, and WebClient are obsolete. Use HttpClient instead.";
                }
                {
                    this.WebRequestDiagId = "SYSLIB0014";
                }
                {
                    this.DisablePrivateReflectionAttributeMessage = "DisablePrivateReflectionAttribute has no effect in .NET 6.0+.";
                }
                {
                    this.DisablePrivateReflectionAttributeDiagId = "SYSLIB0015";
                }
                {
                    this.GetContextInfoMessage = "Use the Graphics.GetContextInfo overloads that accept arguments for better performance and fewer allocations.";
                }
                {
                    this.GetContextInfoDiagId = "SYSLIB0016";
                }
                {
                    this.StrongNameKeyPairMessage = "Strong name signing is not supported and throws PlatformNotSupportedException.";
                }
                {
                    this.StrongNameKeyPairDiagId = "SYSLIB0017";
                }
                {
                    this.ReflectionOnlyLoadingMessage = "ReflectionOnly loading is not supported and throws PlatformNotSupportedException.";
                }
                {
                    this.ReflectionOnlyLoadingDiagId = "SYSLIB0018";
                }
                {
                    this.RuntimeEnvironmentMessage = "RuntimeEnvironment members SystemConfigurationFile, GetRuntimeInterfaceAsIntPtr, and GetRuntimeInterfaceAsObject are not supported and throw PlatformNotSupportedException.";
                }
                {
                    this.RuntimeEnvironmentDiagId = "SYSLIB0019";
                }
                {
                    this.JsonSerializerOptionsIgnoreNullValuesMessage = "JsonSerializerOptions.IgnoreNullValues is obsolete. To ignore null values when serializing, set DefaultIgnoreCondition to JsonIgnoreCondition.WhenWritingNull.";
                }
                {
                    this.JsonSerializerOptionsIgnoreNullValuesDiagId = "SYSLIB0020";
                }
                {
                    this.DerivedCryptographicTypesMessage = "Derived cryptographic types are obsolete. Use the Create method on the base type instead.";
                }
                {
                    this.DerivedCryptographicTypesDiagId = "SYSLIB0021";
                }
                {
                    this.RijndaelMessage = "The Rijndael and RijndaelManaged types are obsolete. Use Aes instead.";
                }
                {
                    this.RijndaelDiagId = "SYSLIB0022";
                }
                {
                    this.RNGCryptoServiceProviderMessage = "RNGCryptoServiceProvider is obsolete. To generate a random number, use one of the RandomNumberGenerator static methods instead.";
                }
                {
                    this.RNGCryptoServiceProviderDiagId = "SYSLIB0023";
                }
                {
                    this.AppDomainCreateUnloadMessage = "Creating and unloading AppDomains is not supported and throws an exception.";
                }
                {
                    this.AppDomainCreateUnloadDiagId = "SYSLIB0024";
                }
                {
                    this.SuppressIldasmAttributeMessage = "SuppressIldasmAttribute has no effect in .NET 6.0+.";
                }
                {
                    this.SuppressIldasmAttributeDiagId = "SYSLIB0025";
                }
                {
                    this.X509CertificateImmutableMessage = "X509Certificate and X509Certificate2 are immutable. Use X509CertificateLoader to create a new certificate.";
                }
                {
                    this.X509CertificateImmutableDiagId = "SYSLIB0026";
                }
                {
                    this.PublicKeyPropertyMessage = "PublicKey.Key is obsolete. Use the appropriate method to get the public key, such as GetRSAPublicKey.";
                }
                {
                    this.PublicKeyPropertyDiagId = "SYSLIB0027";
                }
                {
                    this.X509CertificatePrivateKeyMessage = "X509Certificate2.PrivateKey is obsolete. Use the appropriate method to get the private key, such as GetRSAPrivateKey, or use the CopyWithPrivateKey method to create a new instance with a private key.";
                }
                {
                    this.X509CertificatePrivateKeyDiagId = "SYSLIB0028";
                }
                {
                    this.ProduceLegacyHmacValuesMessage = "ProduceLegacyHmacValues is obsolete. Producing legacy HMAC values is not supported.";
                }
                {
                    this.ProduceLegacyHmacValuesDiagId = "SYSLIB0029";
                }
                {
                    this.UseManagedSha1Message = "HMACSHA1 always uses the algorithm implementation provided by the platform. Use a constructor without the useManagedSha1 parameter.";
                }
                {
                    this.UseManagedSha1DiagId = "SYSLIB0030";
                }
                {
                    this.CryptoConfigEncodeOIDMessage = "EncodeOID is obsolete. Use the ASN.1 functionality provided in System.Formats.Asn1.";
                }
                {
                    this.CryptoConfigEncodeOIDDiagId = "SYSLIB0031";
                }
                {
                    this.CorruptedStateRecoveryMessage = "Recovery from corrupted process state exceptions is not supported; HandleProcessCorruptedStateExceptionsAttribute is ignored.";
                }
                {
                    this.CorruptedStateRecoveryDiagId = "SYSLIB0032";
                }
                {
                    this.Rfc2898CryptDeriveKeyMessage = "Rfc2898DeriveBytes.CryptDeriveKey is obsolete and is not supported. Use PasswordDeriveBytes.CryptDeriveKey instead.";
                }
                {
                    this.Rfc2898CryptDeriveKeyDiagId = "SYSLIB0033";
                }
                {
                    this.CmsSignerCspParamsCtorMessage = "CmsSigner(CspParameters) is obsolete and is not supported. Use an alternative constructor instead.";
                }
                {
                    this.CmsSignerCspParamsCtorDiagId = "SYSLIB0034";
                }
                {
                    this.SignerInfoCounterSigMessage = "ComputeCounterSignature without specifying a CmsSigner is obsolete and is not supported. Use the overload that accepts a CmsSigner.";
                }
                {
                    this.SignerInfoCounterSigDiagId = "SYSLIB0035";
                }
                {
                    this.RegexCompileToAssemblyMessage = "Regex.CompileToAssembly is obsolete and not supported. Use the GeneratedRegexAttribute with the regular expression source generator instead.";
                }
                {
                    this.RegexCompileToAssemblyDiagId = "SYSLIB0036";
                }
                {
                    this.AssemblyNameMembersMessage = "AssemblyName members HashAlgorithm, ProcessorArchitecture, and VersionCompatibility are obsolete and not supported.";
                }
                {
                    this.AssemblyNameMembersDiagId = "SYSLIB0037";
                }
                {
                    this.SystemDataSerializationFormatBinaryMessage = "SerializationFormat.Binary is obsolete and should not be used. See https://aka.ms/serializationformat-binary-obsolete for more information.";
                }
                {
                    this.SystemDataSerializationFormatBinaryDiagId = "SYSLIB0038";
                }
                {
                    this.TlsVersion10and11Message = "TLS versions 1.0 and 1.1 have known vulnerabilities and are not recommended. Use a newer TLS version instead, or use SslProtocols.None to defer to OS defaults.";
                }
                {
                    this.TlsVersion10and11DiagId = "SYSLIB0039";
                }
                {
                    this.EncryptionPolicyMessage = "EncryptionPolicy.NoEncryption and AllowEncryption significantly reduce security and should not be used in production code.";
                }
                {
                    this.EncryptionPolicyDiagId = "SYSLIB0040";
                }
                {
                    this.EccXmlExportImportMessage = "ToXmlString and FromXmlString have no implementation for ECC types, and are obsolete. Use a standard import and export format such as ExportSubjectPublicKeyInfo or ImportSubjectPublicKeyInfo for public keys and ExportPkcs8PrivateKey or ImportPkcs8PrivateKey for private keys.";
                }
                {
                    this.EccXmlExportImportDiagId = "SYSLIB0042";
                }
                {
                    this.EcDhPublicKeyBlobMessage = "ECDiffieHellmanPublicKey.ToByteArray() and the associated constructor do not have a consistent and interoperable implementation on all platforms. Use ECDiffieHellmanPublicKey.ExportSubjectPublicKeyInfo() instead.";
                }
                {
                    this.EcDhPublicKeyBlobDiagId = "SYSLIB0043";
                }
                {
                    this.AssemblyNameCodeBaseMessage = "AssemblyName.CodeBase and AssemblyName.EscapedCodeBase are obsolete. Using them for loading an assembly is not supported.";
                }
                {
                    this.AssemblyNameCodeBaseDiagId = "SYSLIB0044";
                }
                {
                    this.CryptoStringFactoryMessage = "Cryptographic factory methods accepting an algorithm name are obsolete. Use the parameterless Create factory method on the algorithm type instead.";
                }
                {
                    this.CryptoStringFactoryDiagId = "SYSLIB0045";
                }
                {
                    this.ControlledExecutionRunMessage = "ControlledExecution.Run method may corrupt the process and should not be used in production code.";
                }
                {
                    this.ControlledExecutionRunDiagId = "SYSLIB0046";
                }
                {
                    this.XmlSecureResolverMessage = "XmlSecureResolver is obsolete. Use XmlResolver.ThrowingResolver instead when attempting to forbid XML external entity resolution.";
                }
                {
                    this.XmlSecureResolverDiagId = "SYSLIB0047";
                }
                {
                    this.RsaEncryptDecryptValueMessage = "RSA.EncryptValue and DecryptValue are not supported and throw NotSupportedException. Use RSA.Encrypt and RSA.Decrypt instead.";
                }
                {
                    this.RsaEncryptDecryptDiagId = "SYSLIB0048";
                }
                {
                    this.JsonSerializerOptionsAddContextMessage = "JsonSerializerOptions.AddContext is obsolete. To register a JsonSerializerContext, use either the TypeInfoResolver or TypeInfoResolverChain properties.";
                }
                {
                    this.JsonSerializerOptionsAddContextDiagId = "SYSLIB0049";
                }
                {
                    this.LegacyFormatterMessage = "Formatter-based serialization is obsolete and should not be used.";
                }
                {
                    this.LegacyFormatterDiagId = "SYSLIB0050";
                }
                {
                    this.LegacyFormatterImplMessage = "This API supports obsolete formatter-based serialization. It should not be called or extended by application code.";
                }
                {
                    this.LegacyFormatterImplDiagId = "SYSLIB0051";
                }
                {
                    this.RegexExtensibilityImplMessage = "This API supports obsolete mechanisms for Regex extensibility. It is not supported.";
                }
                {
                    this.RegexExtensibilityDiagId = "SYSLIB0052";
                }
                {
                    this.AesGcmTagConstructorMessage = "AesGcm should indicate the required tag size for encryption and decryption. Use a constructor that accepts the tag size.";
                }
                {
                    this.AesGcmTagConstructorDiagId = "SYSLIB0053";
                }
                {
                    this.ThreadVolatileReadWriteMessage = "Thread.VolatileRead and Thread.VolatileWrite are obsolete. Use Volatile.Read or Volatile.Write respectively instead.";
                }
                {
                    this.ThreadVolatileReadWriteDiagId = "SYSLIB0054";
                }
                {
                    this.ArmIntrinsicPerformsUnsignedOperationMessage = "The underlying hardware instruction does not perform a signed saturate narrowing operation, and it always returns an unsigned result. Use the unsigned overload instead.";
                }
                {
                    this.ArmIntrinsicPerformsUnsignedOperationDiagId = "SYSLIB0055";
                }
                {
                    this.LoadFromHashAlgorithmMessage = "LoadFrom with a custom AssemblyHashAlgorithm is obsolete. Use overloads without an AssemblyHashAlgorithm.";
                }
                {
                    this.LoadFromHashAlgorithmDiagId = "SYSLIB0056";
                }
                {
                    this.X509CtorCertDataObsoleteMessage = "Loading certificate data through the constructor or Import is obsolete. Use X509CertificateLoader instead to load certificates.";
                }
                {
                    this.X509CtorCertDataObsoleteDiagId = "SYSLIB0057";
                }
                {
                    this.TlsCipherAlgorithmEnumsMessage = "KeyExchangeAlgorithm, KeyExchangeStrength, CipherAlgorithm, CipherStrength, HashAlgorithm and HashStrength properties of SslStream are obsolete. Use NegotiatedCipherSuite instead.";
                }
                {
                    this.TlsCipherAlgorithmEnumsDiagId = "SYSLIB0058";
                }
                {
                    this.SystemEventsEventsThreadShutdownMessage = "SystemEvents.EventsThreadShutdown callbacks are not run before the process exits. Use AppDomain.ProcessExit instead.";
                }
                {
                    this.SystemEventsEventsThreadShutdownDiagId = "SYSLIB0059";
                }
                {
                    this.Rfc2898DeriveBytesCtorMessage = "The constructors on Rfc2898DeriveBytes are obsolete. Use the static Pbkdf2 method instead.";
                }
                {
                    this.Rfc2898DeriveBytesCtorDiagId = "SYSLIB0060";
                }
                {
                    this.QueryableMinByMaxByTSourceObsoleteMessage = "The Queryable MinBy and MaxBy taking an IComparer<TSource> are obsolete. Use the new ones that take an IComparer<TKey>.";
                }
                {
                    this.QueryableMinByMaxByTSourceObsoleteDiagId = "SYSLIB0061";
                }
                {
                    this.XsltSettingsEnableScriptMessage = "XSLT Script blocks are not supported.";
                }
                {
                    this.XsltSettingsEnableScriptDiagId = "SYSLIB0062";
                }
            }
            static $h = 119682;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"l":[{"t":1310721,"n":"SharedUrlFormat","d":119682,"h":4295086978,"f":40},{"t":1310721,"n":"SystemTextEncodingUTF7Message","d":119682,"h":8590054274,"f":40},{"t":1310721,"n":"SystemTextEncodingUTF7DiagId","d":119682,"h":12885021570,"f":40},{"t":1310721,"n":"PrincipalPermissionAttributeMessage","d":119682,"h":17179988866,"f":40},{"t":1310721,"n":"PrincipalPermissionAttributeDiagId","d":119682,"h":21474956162,"f":40},{"t":1310721,"n":"CodeAccessSecurityMessage","d":119682,"h":25769923458,"f":40},{"t":1310721,"n":"CodeAccessSecurityDiagId","d":119682,"h":30064890754,"f":40},{"t":1310721,"n":"ConstrainedExecutionRegionMessage","d":119682,"h":34359858050,"f":40},{"t":1310721,"n":"ConstrainedExecutionRegionDiagId","d":119682,"h":38654825346,"f":40},{"t":1310721,"n":"GlobalAssemblyCacheMessage","d":119682,"h":42949792642,"f":40},{"t":1310721,"n":"GlobalAssemblyCacheDiagId","d":119682,"h":47244759938,"f":40},{"t":1310721,"n":"ThreadAbortMessage","d":119682,"h":51539727234,"f":40},{"t":1310721,"n":"ThreadResetAbortMessage","d":119682,"h":55834694530,"f":40},{"t":1310721,"n":"ThreadAbortDiagId","d":119682,"h":60129661826,"f":40},{"t":1310721,"n":"DefaultCryptoAlgorithmsMessage","d":119682,"h":64424629122,"f":40},{"t":1310721,"n":"DefaultCryptoAlgorithmsDiagId","d":119682,"h":68719596418,"f":40},{"t":1310721,"n":"CreatePdbGeneratorMessage","d":119682,"h":73014563714,"f":40},{"t":1310721,"n":"CreatePdbGeneratorDiagId","d":119682,"h":77309531010,"f":40},{"t":1310721,"n":"AuthenticationManagerMessage","d":119682,"h":81604498306,"f":40},{"t":1310721,"n":"AuthenticationManagerDiagId","d":119682,"h":85899465602,"f":40},{"t":1310721,"n":"RemotingApisMessage","d":119682,"h":90194432898,"f":40},{"t":1310721,"n":"RemotingApisDiagId","d":119682,"h":94489400194,"f":40},{"t":1310721,"n":"BinaryFormatterMessage","d":119682,"h":98784367490,"f":40},{"t":1310721,"n":"BinaryFormatterDiagId","d":119682,"h":103079334786,"f":40},{"t":1310721,"n":"CodeBaseMessage","d":119682,"h":107374302082,"f":40},{"t":1310721,"n":"CodeBaseDiagId","d":119682,"h":111669269378,"f":40},{"t":1310721,"n":"EscapeUriStringMessage","d":119682,"h":115964236674,"f":40},{"t":1310721,"n":"EscapeUriStringDiagId","d":119682,"h":120259203970,"f":40},{"t":1310721,"n":"WebRequestMessage","d":119682,"h":124554171266,"f":40},{"t":1310721,"n":"WebRequestDiagId","d":119682,"h":128849138562,"f":40},{"t":1310721,"n":"DisablePrivateReflectionAttributeMessage","d":119682,"h":133144105858,"f":40},{"t":1310721,"n":"DisablePrivateReflectionAttributeDiagId","d":119682,"h":137439073154,"f":40},{"t":1310721,"n":"GetContextInfoMessage","d":119682,"h":141734040450,"f":40},{"t":1310721,"n":"GetContextInfoDiagId","d":119682,"h":146029007746,"f":40},{"t":1310721,"n":"StrongNameKeyPairMessage","d":119682,"h":150323975042,"f":40},{"t":1310721,"n":"StrongNameKeyPairDiagId","d":119682,"h":154618942338,"f":40},{"t":1310721,"n":"ReflectionOnlyLoadingMessage","d":119682,"h":158913909634,"f":40},{"t":1310721,"n":"ReflectionOnlyLoadingDiagId","d":119682,"h":163208876930,"f":40},{"t":1310721,"n":"RuntimeEnvironmentMessage","d":119682,"h":167503844226,"f":40},{"t":1310721,"n":"RuntimeEnvironmentDiagId","d":119682,"h":171798811522,"f":40},{"t":1310721,"n":"JsonSerializerOptionsIgnoreNullValuesMessage","d":119682,"h":176093778818,"f":40},{"t":1310721,"n":"JsonSerializerOptionsIgnoreNullValuesDiagId","d":119682,"h":180388746114,"f":40},{"t":1310721,"n":"DerivedCryptographicTypesMessage","d":119682,"h":184683713410,"f":40},{"t":1310721,"n":"DerivedCryptographicTypesDiagId","d":119682,"h":188978680706,"f":40},{"t":1310721,"n":"RijndaelMessage","d":119682,"h":193273648002,"f":40},{"t":1310721,"n":"RijndaelDiagId","d":119682,"h":197568615298,"f":40},{"t":1310721,"n":"RNGCryptoServiceProviderMessage","d":119682,"h":201863582594,"f":40},{"t":1310721,"n":"RNGCryptoServiceProviderDiagId","d":119682,"h":206158549890,"f":40},{"t":1310721,"n":"AppDomainCreateUnloadMessage","d":119682,"h":210453517186,"f":40},{"t":1310721,"n":"AppDomainCreateUnloadDiagId","d":119682,"h":214748484482,"f":40},{"t":1310721,"n":"SuppressIldasmAttributeMessage","d":119682,"h":219043451778,"f":40},{"t":1310721,"n":"SuppressIldasmAttributeDiagId","d":119682,"h":223338419074,"f":40},{"t":1310721,"n":"X509CertificateImmutableMessage","d":119682,"h":227633386370,"f":40},{"t":1310721,"n":"X509CertificateImmutableDiagId","d":119682,"h":231928353666,"f":40},{"t":1310721,"n":"PublicKeyPropertyMessage","d":119682,"h":236223320962,"f":40},{"t":1310721,"n":"PublicKeyPropertyDiagId","d":119682,"h":240518288258,"f":40},{"t":1310721,"n":"X509CertificatePrivateKeyMessage","d":119682,"h":244813255554,"f":40},{"t":1310721,"n":"X509CertificatePrivateKeyDiagId","d":119682,"h":249108222850,"f":40},{"t":1310721,"n":"ProduceLegacyHmacValuesMessage","d":119682,"h":253403190146,"f":40},{"t":1310721,"n":"ProduceLegacyHmacValuesDiagId","d":119682,"h":257698157442,"f":40},{"t":1310721,"n":"UseManagedSha1Message","d":119682,"h":261993124738,"f":40},{"t":1310721,"n":"UseManagedSha1DiagId","d":119682,"h":266288092034,"f":40},{"t":1310721,"n":"CryptoConfigEncodeOIDMessage","d":119682,"h":270583059330,"f":40},{"t":1310721,"n":"CryptoConfigEncodeOIDDiagId","d":119682,"h":274878026626,"f":40},{"t":1310721,"n":"CorruptedStateRecoveryMessage","d":119682,"h":279172993922,"f":40},{"t":1310721,"n":"CorruptedStateRecoveryDiagId","d":119682,"h":283467961218,"f":40},{"t":1310721,"n":"Rfc2898CryptDeriveKeyMessage","d":119682,"h":287762928514,"f":40},{"t":1310721,"n":"Rfc2898CryptDeriveKeyDiagId","d":119682,"h":292057895810,"f":40},{"t":1310721,"n":"CmsSignerCspParamsCtorMessage","d":119682,"h":296352863106,"f":40},{"t":1310721,"n":"CmsSignerCspParamsCtorDiagId","d":119682,"h":300647830402,"f":40},{"t":1310721,"n":"SignerInfoCounterSigMessage","d":119682,"h":304942797698,"f":40},{"t":1310721,"n":"SignerInfoCounterSigDiagId","d":119682,"h":309237764994,"f":40},{"t":1310721,"n":"RegexCompileToAssemblyMessage","d":119682,"h":313532732290,"f":40},{"t":1310721,"n":"RegexCompileToAssemblyDiagId","d":119682,"h":317827699586,"f":40},{"t":1310721,"n":"AssemblyNameMembersMessage","d":119682,"h":322122666882,"f":40},{"t":1310721,"n":"AssemblyNameMembersDiagId","d":119682,"h":326417634178,"f":40},{"t":1310721,"n":"SystemDataSerializationFormatBinaryMessage","d":119682,"h":330712601474,"f":40},{"t":1310721,"n":"SystemDataSerializationFormatBinaryDiagId","d":119682,"h":335007568770,"f":40},{"t":1310721,"n":"TlsVersion10and11Message","d":119682,"h":339302536066,"f":40},{"t":1310721,"n":"TlsVersion10and11DiagId","d":119682,"h":343597503362,"f":40},{"t":1310721,"n":"EncryptionPolicyMessage","d":119682,"h":347892470658,"f":40},{"t":1310721,"n":"EncryptionPolicyDiagId","d":119682,"h":352187437954,"f":40},{"t":1310721,"n":"EccXmlExportImportMessage","d":119682,"h":356482405250,"f":40},{"t":1310721,"n":"EccXmlExportImportDiagId","d":119682,"h":360777372546,"f":40},{"t":1310721,"n":"EcDhPublicKeyBlobMessage","d":119682,"h":365072339842,"f":40},{"t":1310721,"n":"EcDhPublicKeyBlobDiagId","d":119682,"h":369367307138,"f":40},{"t":1310721,"n":"AssemblyNameCodeBaseMessage","d":119682,"h":373662274434,"f":40},{"t":1310721,"n":"AssemblyNameCodeBaseDiagId","d":119682,"h":377957241730,"f":40},{"t":1310721,"n":"CryptoStringFactoryMessage","d":119682,"h":382252209026,"f":40},{"t":1310721,"n":"CryptoStringFactoryDiagId","d":119682,"h":386547176322,"f":40},{"t":1310721,"n":"ControlledExecutionRunMessage","d":119682,"h":390842143618,"f":40},{"t":1310721,"n":"ControlledExecutionRunDiagId","d":119682,"h":395137110914,"f":40},{"t":1310721,"n":"XmlSecureResolverMessage","d":119682,"h":399432078210,"f":40},{"t":1310721,"n":"XmlSecureResolverDiagId","d":119682,"h":403727045506,"f":40},{"t":1310721,"n":"RsaEncryptDecryptValueMessage","d":119682,"h":408022012802,"f":40},{"t":1310721,"n":"RsaEncryptDecryptDiagId","d":119682,"h":412316980098,"f":40},{"t":1310721,"n":"JsonSerializerOptionsAddContextMessage","d":119682,"h":416611947394,"f":40},{"t":1310721,"n":"JsonSerializerOptionsAddContextDiagId","d":119682,"h":420906914690,"f":40},{"t":1310721,"n":"LegacyFormatterMessage","d":119682,"h":425201881986,"f":40},{"t":1310721,"n":"LegacyFormatterDiagId","d":119682,"h":429496849282,"f":40},{"t":1310721,"n":"LegacyFormatterImplMessage","d":119682,"h":433791816578,"f":40},{"t":1310721,"n":"LegacyFormatterImplDiagId","d":119682,"h":438086783874,"f":40},{"t":1310721,"n":"RegexExtensibilityImplMessage","d":119682,"h":442381751170,"f":40},{"t":1310721,"n":"RegexExtensibilityDiagId","d":119682,"h":446676718466,"f":40},{"t":1310721,"n":"AesGcmTagConstructorMessage","d":119682,"h":450971685762,"f":40},{"t":1310721,"n":"AesGcmTagConstructorDiagId","d":119682,"h":455266653058,"f":40},{"t":1310721,"n":"ThreadVolatileReadWriteMessage","d":119682,"h":459561620354,"f":40},{"t":1310721,"n":"ThreadVolatileReadWriteDiagId","d":119682,"h":463856587650,"f":40},{"t":1310721,"n":"ArmIntrinsicPerformsUnsignedOperationMessage","d":119682,"h":468151554946,"f":40},{"t":1310721,"n":"ArmIntrinsicPerformsUnsignedOperationDiagId","d":119682,"h":472446522242,"f":40},{"t":1310721,"n":"LoadFromHashAlgorithmMessage","d":119682,"h":476741489538,"f":40},{"t":1310721,"n":"LoadFromHashAlgorithmDiagId","d":119682,"h":481036456834,"f":40},{"t":1310721,"n":"X509CtorCertDataObsoleteMessage","d":119682,"h":485331424130,"f":40},{"t":1310721,"n":"X509CtorCertDataObsoleteDiagId","d":119682,"h":489626391426,"f":40},{"t":1310721,"n":"TlsCipherAlgorithmEnumsMessage","d":119682,"h":493921358722,"f":40},{"t":1310721,"n":"TlsCipherAlgorithmEnumsDiagId","d":119682,"h":498216326018,"f":40},{"t":1310721,"n":"SystemEventsEventsThreadShutdownMessage","d":119682,"h":502511293314,"f":40},{"t":1310721,"n":"SystemEventsEventsThreadShutdownDiagId","d":119682,"h":506806260610,"f":40},{"t":1310721,"n":"Rfc2898DeriveBytesCtorMessage","d":119682,"h":511101227906,"f":40},{"t":1310721,"n":"Rfc2898DeriveBytesCtorDiagId","d":119682,"h":515396195202,"f":40},{"t":1310721,"n":"QueryableMinByMaxByTSourceObsoleteMessage","d":119682,"h":519691162498,"f":40},{"t":1310721,"n":"QueryableMinByMaxByTSourceObsoleteDiagId","d":119682,"h":523986129794,"f":40},{"t":1310721,"n":"XsltSettingsEnableScriptMessage","d":119682,"h":528281097090,"f":40},{"t":1310721,"n":"XsltSettingsEnableScriptDiagId","d":119682,"h":532576064386,"f":40}],"h":119682}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.Obsoletions`; }
        });
        
        $asm.$cls("$sris.System.Runtime.InteropServices.Marshalling.ComImportInteropInterfaceDetailsStrategy", ($self) => class ComImportInteropInterfaceDetailsStrategy extends $.$spc.System.Object
        {
            /*IIUnknownInterfaceDetailsStrategy*/ static Instance = null;
            /*ConditionalWeakTable<Type, Type>*/ _forwarderInterfaceCache = null;
            /*IComExposedDetails? */ GetComExposedTypeDetails(/*RuntimeTypeHandle*/ type)
            {
                return $.$sris.System.Runtime.InteropServices.Marshalling.DefaultIUnknownInterfaceDetailsStrategy.Instance.System$Runtime$InteropServices$Marshalling$IIUnknownInterfaceDetailsStrategy$GetComExposedTypeDetails(type);
            }
            /*IIUnknownDerivedDetails? */ GetIUnknownDerivedDetails(/*RuntimeTypeHandle*/ type)
            {
                /*Type*/ let runtimeType = $.$spc.System.Type.GetTypeFromHandle(type);
                if (!runtimeType.IsImport)
                {
                    return $.$sris.System.Runtime.InteropServices.Marshalling.DefaultIUnknownInterfaceDetailsStrategy.Instance.System$Runtime$InteropServices$Marshalling$IIUnknownInterfaceDetailsStrategy$GetIUnknownDerivedDetails(type);
                }
                /*Type*/ let implementationType = this._forwarderInterfaceCache.GetValue(runtimeType, new $.$spc.System.Runtime.CompilerServices.ConditionalWeakTable$$$($.$spc.System.Type, $.$spc.System.Type).CreateValueCallback().$ctor(this,  (/**/ runtimeType) =>
                {
                    /*AssemblyBuilder*/ let assembly = /*$.$spc.System.Reflection.Emit.AssemblyBuilder*/$.$spc.DeletedObject.DefineDynamicAssembly(new $.$spc.System.Reflection.AssemblyName().$ctor$1("ComImportForwarder"), runtimeType.IsCollectible ? 9/*AssemblyBuilderAccess.RunAndCollect*/ : 1/*AssemblyBuilderAccess.Run*/);
                    /*ModuleBuilder*/ let module = assembly.DefineDynamicModule("ComImportForwarder");
                    /*ConstructorInfo*/ let ignoresAccessChecksToAttributeConstructor = $.$sris.System.Runtime.InteropServices.Marshalling.ComImportInteropInterfaceDetailsStrategy.GetIgnoresAccessChecksToAttributeConstructor(module);
                    assembly.SetCustomAttribute$1(new CustomAttributeBuilder(ignoresAccessChecksToAttributeConstructor, $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$spc.System.Object), [$.$sris.System.Runtime.InteropServices.Marshalling.ComImportInteropInterfaceDetailsStrategy.IComImportAdapter.$type.Assembly.GetName().Name], [-1], null)));
                    /*TypeBuilder*/ let implementation = module.DefineType$3("InterfaceForwarder", 32/*TypeAttributes.Interface*/ | 128/*TypeAttributes.Abstract*/, null, runtimeType.GetInterfaces());
                    implementation.AddInterfaceImplementation(runtimeType);
                    implementation.SetCustomAttribute$1(new CustomAttributeBuilder($.$spc.System.Runtime.InteropServices.DynamicInterfaceCastableImplementationAttribute.$type.GetConstructor$1($.$spc.System.Array.Empty($.$spc.System.Type)), $.$spc.System.Array.Empty($.$spc.System.Object)));
                    let $i1 = 0;
                    let $arr1 = implementation.GetInterfaces();
                    while ($i1 < $arr1.length)
                    {
                        let iface = $arr1[$i1++];
                        assembly.SetCustomAttribute$1(new CustomAttributeBuilder(ignoresAccessChecksToAttributeConstructor, $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$spc.System.Object), [iface.Assembly.GetName().Name], [-1], null)));
                        let $i2 = 0;
                        let $arr2 = iface.GetMethods();
                        while ($i2 < $arr2.length)
                        {
                            let method = $arr2[$i2++];
                            /*Type[]*/ let returnTypeOptionalModifiers = method.ReturnParameter.GetOptionalCustomModifiers();
                            /*Type[]*/ let returnTypeRequiredModifiers = method.ReturnParameter.GetRequiredCustomModifiers();
                            /*ParameterInfo[]*/ let parameters = method.GetParameters();
                            /*var*/ let parameterTypes = $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$spc.System.Type), null, [parameters.length], null);
                            /*var*/ let parameterOptionalModifiers = $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$typeArray($.$spc.System.Type)), null, [parameters.length], null);
                            /*var*/ let parameterRequiredModifiers = $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$typeArray($.$spc.System.Type)), null, [parameters.length], null);
                            for(/*int*/ let i = 0; i < parameters.length; i++)
                            {
                                $.$spc.System.Array.$WriteT1.call(parameterTypes, $.$spc.System.Array.$ReadT1.call(parameters, i).ParameterType, i);
                                $.$spc.System.Array.$WriteT1.call(parameterOptionalModifiers, $.$spc.System.Array.$ReadT1.call(parameters, i).GetOptionalCustomModifiers(), i);
                                $.$spc.System.Array.$WriteT1.call(parameterRequiredModifiers, $.$spc.System.Array.$ReadT1.call(parameters, i).GetRequiredCustomModifiers(), i);
                            }
                            /*MethodBuilder*/ let builder = implementation.DefineMethod$4(method.Name, 1/*MethodAttributes.Private*/ | 32/*MethodAttributes.Final*/ | 128/*MethodAttributes.HideBySig*/ | 64/*MethodAttributes.Virtual*/, 32/*CallingConventions.HasThis*/, method.ReturnType, returnTypeRequiredModifiers, returnTypeOptionalModifiers, parameterTypes, parameterRequiredModifiers, parameterOptionalModifiers);
                            /*ILGenerator*/ let il = builder.GetILGenerator();
                            il.Emit(/*$.$spc.System.Reflection.Emit.OpCodes*/$.$spc.DeletedObject.Ldarg_0);
                            il.Emit$10(/*$.$spc.System.Reflection.Emit.OpCodes*/$.$spc.DeletedObject.Castclass, $.$sris.System.Runtime.InteropServices.Marshalling.ComImportInteropInterfaceDetailsStrategy.IComImportAdapter.$type);
                            il.Emit$7(/*$.$spc.System.Reflection.Emit.OpCodes*/$.$spc.DeletedObject.Callvirt, $.$sris.System.Runtime.InteropServices.Marshalling.ComImportInteropInterfaceDetailsStrategy.IComImportAdapter.$sris$System$Runtime$InteropServices$Marshalling$ComImportInteropInterfaceDetailsStrategy$IComImportAdapter$GetRuntimeCallableWrapperMethod);
                            il.Emit$10(/*$.$spc.System.Reflection.Emit.OpCodes*/$.$spc.DeletedObject.Castclass, iface);
                            for(/*int*/ let i = 0; i < parameters.length; i++)
                            {
                                il.Emit$6(/*$.$spc.System.Reflection.Emit.OpCodes*/$.$spc.DeletedObject.Ldarg, ((i + 1) | 0));
                            }
                            il.Emit$7(/*$.$spc.System.Reflection.Emit.OpCodes*/$.$spc.DeletedObject.Callvirt, method);
                            il.Emit(/*$.$spc.System.Reflection.Emit.OpCodes*/$.$spc.DeletedObject.Ret);
                            implementation.DefineMethodOverride(builder, method);
                        }
                    }
                    return implementation.CreateType();
                }));
                return new $.$sris.System.Runtime.InteropServices.Marshalling.ComImportInteropInterfaceDetailsStrategy.ComImportDetails().$ctor$1(runtimeType.GUID, implementationType);
            }
            /*ConstructorInfo*/ static s_attributeBaseClassCtor = null;
            /*ConstructorInfo*/ static s_attributeUsageCtor = null;
            /*PropertyInfo*/ static s_attributeUsageAllowMultipleProperty = null;
            static $_ComImportDetails;
            static get ComImportDetails()
            {
                let $cls = $.$sris.System.Runtime.InteropServices.Marshalling.ComImportInteropInterfaceDetailsStrategy;
                return $cls.$_ComImportDetails ??= $asm.$ncls("$sris.System.Runtime.InteropServices.Marshalling.ComImportInteropInterfaceDetailsStrategy.ComImportDetails", ($self) => class ComImportDetails extends $.$spc.System.Object
                {
                    /*Guid*/ Iid;
                    /*Type*/ Implementation = null;
                    /*void** */ get ManagedVirtualMethodTable()
                    {
                        return null;
                    }
                    //Generated interface implemetation for System.Runtime.InteropServices.Marshalling.IIUnknownDerivedDetails.Iid.get
                    get System$Runtime$InteropServices$Marshalling$IIUnknownDerivedDetails$Iid()
                    {
                        return this.Iid;
                    }
                    //Generated interface implemetation for System.Runtime.InteropServices.Marshalling.IIUnknownDerivedDetails.Implementation.get
                    get System$Runtime$InteropServices$Marshalling$IIUnknownDerivedDetails$Implementation()
                    {
                        return this.Implementation;
                    }
                    //Generated interface implemetation for System.Runtime.InteropServices.Marshalling.IIUnknownDerivedDetails.ManagedVirtualMethodTable.get
                    get System$Runtime$InteropServices$Marshalling$IIUnknownDerivedDetails$ManagedVirtualMethodTable()
                    {
                        return this.ManagedVirtualMethodTable;
                    }
                    //Begin primary constructor
                    /*Guid*/ iid = new $.$spc.System.Guid();
                    /*Type*/ implementation = null;
                    $ctor$1(/*Guid*/$iid, /*Type*/$implementation)
                    {
                        this.iid = $iid;
                        this.implementation = $implementation;
                        //depends on primary constructor parameter
                        this.Iid = this.iid;
                        //depends on primary constructor parameter
                        this.Implementation = this.implementation;
                        return this
                    }
                    //End primary constructor
                    static $h = 1954690;
                    static $f = 0b10000000010010000;
                    static $k = 1;
                    static $$md;
                    static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":56164353,"g":{"r":0,"d":0,"h":17181823874,"f":1},"n":"Iid","d":1954690,"h":12886856578,"f":1},{"p":142606337,"g":{"r":0,"d":0,"h":30066725762,"f":1},"n":"Implementation","d":1954690,"h":25771758466,"f":1},{"p":0,"g":{"r":0,"d":0,"h":38656660354,"f":1},"n":"ManagedVirtualMethodTable","d":1954690,"h":34361693058,"f":1}],"c":[{"p":[{"n":"iid","p":56164353},{"n":"implementation","p":142606337}],"n":".ctor","o":"$ctor$1","d":1954690,"h":4296921986,"f":1}],"i":[3265410],"d":1889154,"h":1954690}; }
                    static get $b() { return $.$spc.System.Object; }
                    static $$i;
                    static get $i() { return this.$$i ??= [ $.$sris.System.Runtime.InteropServices.Marshalling.IIUnknownDerivedDetails ]; }
                    static get $fullName() { return `System.Runtime.InteropServices.Marshalling.ComImportInteropInterfaceDetailsStrategy.ComImportDetails`; }
                }, $cls, ($v) => $cls.$_ComImportDetails = $v);
            }
            static $_IComImportAdapter;
            static get IComImportAdapter()
            {
                let $cls = $.$sris.System.Runtime.InteropServices.Marshalling.ComImportInteropInterfaceDetailsStrategy;
                return $cls.$_IComImportAdapter ??= $asm.$ncls("$sris.System.Runtime.InteropServices.Marshalling.ComImportInteropInterfaceDetailsStrategy.IComImportAdapter", ($self) => class IComImportAdapter
                {
                    /*MethodInfo*/ static $sris$System$Runtime$InteropServices$Marshalling$ComImportInteropInterfaceDetailsStrategy$IComImportAdapter$GetRuntimeCallableWrapperMethod = null;
                    //Static Initializer
                    static $sinit()
                    {
                        {
                            this.$sris$System$Runtime$InteropServices$Marshalling$ComImportInteropInterfaceDetailsStrategy$IComImportAdapter$GetRuntimeCallableWrapperMethod = $.$sris.System.Runtime.InteropServices.Marshalling.ComImportInteropInterfaceDetailsStrategy.IComImportAdapter.$type.GetMethod$1("GetRuntimeCallableWrapper");
                        }
                    }
                    static $h = 2020226;
                    static $f = 0b10000000000100100;
                    static $k = 3;
                    static $$md;
                    static get $md() { return this.$$md ??= {"m":[{"r":131073,"n":"GetRuntimeCallableWrapper","o":"System$Runtime$InteropServices$Marshalling$ComImportInteropInterfaceDetailsStrategy$IComImportAdapter$GetRuntimeCallableWrapper","d":2020226,"h":8591954818,"f":257}],"l":[{"t":79626241,"n":"GetRuntimeCallableWrapperMethod","o":"$sris$System$Runtime$InteropServices$Marshalling$ComImportInteropInterfaceDetailsStrategy$IComImportAdapter$GetRuntimeCallableWrapperMethod","d":2020226,"h":4296987522,"f":40}],"d":1889154,"h":2020226}; }
                    static get $fullName() { return `System.Runtime.InteropServices.Marshalling.ComImportInteropInterfaceDetailsStrategy.IComImportAdapter`; }
                }, $cls, ($v) => $cls.$_IComImportAdapter = $v);
            }
            //Generated interface implemetation for System.Runtime.InteropServices.Marshalling.IIUnknownInterfaceDetailsStrategy.GetIUnknownDerivedDetails(System.RuntimeTypeHandle)
            System$Runtime$InteropServices$Marshalling$IIUnknownInterfaceDetailsStrategy$GetIUnknownDerivedDetails()
            {
                return this.GetIUnknownDerivedDetails(...arguments);
            }
            //Generated interface implemetation for System.Runtime.InteropServices.Marshalling.IIUnknownInterfaceDetailsStrategy.GetComExposedTypeDetails(System.RuntimeTypeHandle)
            System$Runtime$InteropServices$Marshalling$IIUnknownInterfaceDetailsStrategy$GetComExposedTypeDetails()
            {
                return this.GetComExposedTypeDetails(...arguments);
            }
            //default reference type constructor overload
            $ctor$1()
            {
                super.$ctor();
                return this;
            }
            //default member initializer
            constructor()
            {
                super();
                this._forwarderInterfaceCache = new ($.$spc.System.Runtime.CompilerServices.ConditionalWeakTable$$$($.$spc.System.Type, $.$spc.System.Type))().$ctor$1();
            }
            //Static Initializer
            static $sinit()
            {
                {
                    this.Instance = new $.$sris.System.Runtime.InteropServices.Marshalling.ComImportInteropInterfaceDetailsStrategy().$ctor$1();
                }
                {
                    this.s_attributeBaseClassCtor = $.$spc.System.Array.$ReadT1.call($.$spc.System.Attribute.$type.GetConstructors$1(32/*BindingFlags.NonPublic*/ | 4/*BindingFlags.Instance*/), 0);
                }
                {
                    this.s_attributeUsageCtor = $.$spc.System.AttributeUsageAttribute.$type.GetConstructor$1($.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$spc.System.Type), [$.$spc.System.AttributeTargets.$type], [-1], null));
                }
                {
                    this.s_attributeUsageAllowMultipleProperty = $.$spc.System.AttributeUsageAttribute.$type.GetProperty("AllowMultiple");
                }
            }
            static $h = 1889154;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"m":[{"r":3068802,"p":[{"n":"type","p":116064257}],"n":"GetComExposedTypeDetails","d":1889154,"h":12886791042,"f":1},{"r":3265410,"p":[{"n":"type","p":116064257}],"n":"GetIUnknownDerivedDetails","d":1889154,"h":17181758338,"f":1},{"r":75628545,"p":[{"n":"moduleBuilder"}],"n":"GetIgnoresAccessChecksToAttributeConstructor","d":1889154,"h":21476725634,"f":34},{"r":142606337,"p":[{"n":"moduleBuilder"}],"n":"EmitIgnoresAccessChecksToAttribute","d":1889154,"h":25771692930,"f":34}],"l":[{"t":3330946,"n":"Instance","d":1889154,"h":4296856450,"f":33},{"t":$.$spc.System.Runtime.CompilerServices.ConditionalWeakTable$$$($.$spc.System.Type, $.$spc.System.Type).$h,"n":"_forwarderInterfaceCache","d":1889154,"h":8591823746,"f":2},{"t":75628545,"n":"s_attributeBaseClassCtor","d":1889154,"h":30066660226,"f":34},{"t":75628545,"n":"s_attributeUsageCtor","d":1889154,"h":34361627522,"f":34},{"t":81657857,"n":"s_attributeUsageAllowMultipleProperty","d":1889154,"h":38656594818,"f":34}],"c":[{"n":".ctor","o":"$ctor$1","d":1889154,"h":51541496706,"f":1}],"i":[3330946],"j":[1954690,2020226],"h":1889154}; }
            static get $b() { return $.$spc.System.Object; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$sris.System.Runtime.InteropServices.Marshalling.IIUnknownInterfaceDetailsStrategy ]; }
            static get $fullName() { return `System.Runtime.InteropServices.Marshalling.ComImportInteropInterfaceDetailsStrategy`; }
        });
        
        $asm.$cls("$sris.System.Runtime.InteropServices.Marshalling.DefaultCaching", ($self) => class DefaultCaching extends $.$spc.System.Object
        {
            /*ConcurrentDictionary<RuntimeTypeHandle, IIUnknownCacheStrategy.TableInfo>*/ _cache = null;
            /*IIUnknownCacheStrategy.TableInfo */ System$Runtime$InteropServices$Marshalling$IIUnknownCacheStrategy$ConstructTableInfo(/*RuntimeTypeHandle*/ handle, /*IIUnknownDerivedDetails*/ details, /*void**/ ptr)
            {
                /*var*/ let obj = $.$cast(ptr, $.$typePointer($.$typePointer($.$typePointer($.$spc.System.Void))));
                return (() =>
                {
                    //new $.$sris.System.Runtime.InteropServices.Marshalling.IIUnknownCacheStrategy.TableInfo()
                    const $t1 = $.$sris.System.Runtime.InteropServices.Marshalling.IIUnknownCacheStrategy.TableInfo;
                    const $i1 = new $t1();
                    $i1.ThisPtr = obj;
                    $i1.Table = obj.$v;
                    $i1.ManagedType = details.System$Runtime$InteropServices$Marshalling$IIUnknownDerivedDetails$Implementation.TypeHandle;
                    return $i1;
                })();
            }
            /*bool */ System$Runtime$InteropServices$Marshalling$IIUnknownCacheStrategy$TryGetTableInfo(/*RuntimeTypeHandle*/ handle, /*out IIUnknownCacheStrategy.TableInfo*/ info)
            {
                return this._cache.TryGetValue(handle, info);
            }
            /*bool */ System$Runtime$InteropServices$Marshalling$IIUnknownCacheStrategy$TrySetTableInfo(/*RuntimeTypeHandle*/ handle, /*IIUnknownCacheStrategy.TableInfo*/ info)
            {
                return this._cache.TryAdd(handle, info);
            }
            /*void */ System$Runtime$InteropServices$Marshalling$IIUnknownCacheStrategy$Clear(/*IIUnknownStrategy*/ unknownStrategy)
            {
                var $en2 = this._cache.Values.System$Collections$Generic$IEnumerable$$$GetEnumerator();
                while ($en2.System$Collections$IEnumerator$MoveNext())
                {
                    var info = $en2.System$Collections$Generic$IEnumerator$$$Current;
                    {
                        _ = unknownStrategy.System$Runtime$InteropServices$Marshalling$IIUnknownStrategy$Release(info.ThisPtr);
                    }
                }
                this._cache.Clear();
            }
            //default reference type constructor overload
            $ctor$1()
            {
                super.$ctor();
                return this;
            }
            //default member initializer
            constructor()
            {
                super();
                this._cache = new ($.$scc.System.Collections.Concurrent.ConcurrentDictionary$$$($.$spc.System.RuntimeTypeHandle, $.$sris.System.Runtime.InteropServices.Marshalling.IIUnknownCacheStrategy.TableInfo))().$ctor$2(1, 16);
            }
            static $h = 2413442;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"l":[{"t":$.$scc.System.Collections.Concurrent.ConcurrentDictionary$$$($.$spc.System.RuntimeTypeHandle, $.$sris.System.Runtime.InteropServices.Marshalling.IIUnknownCacheStrategy.TableInfo).$h,"n":"_cache","d":2413442,"h":4297380738,"f":2}],"c":[{"n":".ctor","o":"$ctor$1","d":2413442,"h":25772217218,"f":1}],"i":[3134338],"h":2413442}; }
            static get $b() { return $.$spc.System.Object; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$sris.System.Runtime.InteropServices.Marshalling.IIUnknownCacheStrategy ]; }
            static get $fullName() { return `System.Runtime.InteropServices.Marshalling.DefaultCaching`; }
        });
        
        $asm.$cls("$sris.System.Runtime.InteropServices.Marshalling.DefaultIUnknownInterfaceDetailsStrategy", ($self) => class DefaultIUnknownInterfaceDetailsStrategy extends $.$spc.System.Object
        {
            /*IIUnknownInterfaceDetailsStrategy*/ static Instance = null;
            /*IComExposedDetails? */ GetComExposedTypeDetails(/*RuntimeTypeHandle*/ type)
            {
                return $.$sris.System.Runtime.InteropServices.Marshalling.IComExposedDetails.System$Runtime$InteropServices$Marshalling$IComExposedDetails$GetFromAttribute(type);
            }
            /*IIUnknownDerivedDetails? */ GetIUnknownDerivedDetails(/*RuntimeTypeHandle*/ type)
            {
                return $.$sris.System.Runtime.InteropServices.Marshalling.IIUnknownDerivedDetails.System$Runtime$InteropServices$Marshalling$IIUnknownDerivedDetails$GetFromAttribute(type);
            }
            //Generated interface implemetation for System.Runtime.InteropServices.Marshalling.IIUnknownInterfaceDetailsStrategy.GetIUnknownDerivedDetails(System.RuntimeTypeHandle)
            System$Runtime$InteropServices$Marshalling$IIUnknownInterfaceDetailsStrategy$GetIUnknownDerivedDetails()
            {
                return this.GetIUnknownDerivedDetails(...arguments);
            }
            //Generated interface implemetation for System.Runtime.InteropServices.Marshalling.IIUnknownInterfaceDetailsStrategy.GetComExposedTypeDetails(System.RuntimeTypeHandle)
            System$Runtime$InteropServices$Marshalling$IIUnknownInterfaceDetailsStrategy$GetComExposedTypeDetails()
            {
                return this.GetComExposedTypeDetails(...arguments);
            }
            //default reference type constructor overload
            $ctor$1()
            {
                super.$ctor();
                return this;
            }
            //Static Initializer
            static $sinit()
            {
                {
                    this.Instance = new $.$sris.System.Runtime.InteropServices.Marshalling.DefaultIUnknownInterfaceDetailsStrategy().$ctor$1();
                }
            }
            static $h = 2478978;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"m":[{"r":3068802,"p":[{"n":"type","p":116064257}],"n":"GetComExposedTypeDetails","d":2478978,"h":8592413570,"f":1},{"r":3265410,"p":[{"n":"type","p":116064257}],"n":"GetIUnknownDerivedDetails","d":2478978,"h":12887380866,"f":1}],"l":[{"t":3330946,"n":"Instance","d":2478978,"h":4297446274,"f":33}],"c":[{"n":".ctor","o":"$ctor$1","d":2478978,"h":17182348162,"f":1}],"i":[3330946],"h":2478978}; }
            static get $b() { return $.$spc.System.Object; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$sris.System.Runtime.InteropServices.Marshalling.IIUnknownInterfaceDetailsStrategy ]; }
            static get $fullName() { return `System.Runtime.InteropServices.Marshalling.DefaultIUnknownInterfaceDetailsStrategy`; }
        });
        
        $asm.$cls("$sris.System.Runtime.InteropServices.Marshalling.FreeThreadedStrategy", ($self) => class FreeThreadedStrategy extends $.$spc.System.Object
        {
            /*IIUnknownStrategy*/ static Instance = null;
            /*void* */ System$Runtime$InteropServices$Marshalling$IIUnknownStrategy$CreateInstancePointer(/*void**/ unknown)
            {
                $.$spc.System.Runtime.InteropServices.Marshal.AddRef($.$spc.System.IntPtr.op_Explicit$2(unknown));
                return unknown;
            }
            /*int */ System$Runtime$InteropServices$Marshalling$IIUnknownStrategy$QueryInterface(/*void**/ thisPtr, /*in Guid*/ handle, /*out void**/ ppObj)
            {
                /*nint*/ let ppv;
                /*int*/ let hr = $.$spc.System.Runtime.InteropServices.Marshal.QueryInterface($.$spc.System.IntPtr.op_Explicit$2(thisPtr), handle, $.$ref(() => ppv, ($v) => ppv = $v, $.$spc.System.IntPtr));
                if (hr < 0)
                {
                    ppObj.$v = null;
                }
                else 
                {
                    ppObj.$v = $.$spc.System.IntPtr.op_Explicit$3(ppv);
                }
                return hr;
            }
            /*int */ System$Runtime$InteropServices$Marshalling$IIUnknownStrategy$Release(/*void**/ thisPtr)
            {
                return $.$spc.System.Runtime.InteropServices.Marshal.Release($.$spc.System.IntPtr.op_Explicit$2(thisPtr));
            }
            //default reference type constructor overload
            $ctor$1()
            {
                super.$ctor();
                return this;
            }
            //Static Initializer
            static $sinit()
            {
                {
                    this.Instance = new $.$sris.System.Runtime.InteropServices.Marshalling.FreeThreadedStrategy().$ctor$1();
                }
            }
            static $h = 2806658;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"l":[{"t":3462018,"n":"Instance","d":2806658,"h":4297773954,"f":33}],"c":[{"n":".ctor","o":"$ctor$1","d":2806658,"h":21477643138,"f":1}],"i":[3462018],"h":2806658}; }
            static get $b() { return $.$spc.System.Object; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$sris.System.Runtime.InteropServices.Marshalling.IIUnknownStrategy ]; }
            static get $fullName() { return `System.Runtime.InteropServices.Marshalling.FreeThreadedStrategy`; }
        });
        
        $asm.$str("$sris.System.Runtime.InteropServices.ComTypes.FORMATETC", ($self) => class FORMATETC extends $.$spc.System.ValueType
        {
            /*short*/  get cfFormat() { return this.$getField(0, $.$spc.System.Int16); }
            /*short*/  set cfFormat(value) { this.$setField(0, $.$spc.System.Int16, value); }
            /*IntPtr*/  get ptd() { return this.$getField(2, $.$spc.System.IntPtr); }
            /*IntPtr*/  set ptd(value) { this.$setField(2, $.$spc.System.IntPtr, value); }
            /*DVASPECT*/  get dwAspect() { return this.$getField(6, $.$sris.System.Runtime.InteropServices.ComTypes.DVASPECT); }
            /*DVASPECT*/  set dwAspect(value) { this.$setField(6, $.$sris.System.Runtime.InteropServices.ComTypes.DVASPECT, value); }
            /*int*/  get lindex() { return this.$getField(10, $.$spc.System.Int32); }
            /*int*/  set lindex(value) { this.$setField(10, $.$spc.System.Int32, value); }
            /*TYMED*/  get tymed() { return this.$getField(14, $.$sris.System.Runtime.InteropServices.ComTypes.TYMED); }
            /*TYMED*/  set tymed(value) { this.$setField(14, $.$sris.System.Runtime.InteropServices.ComTypes.TYMED, value); }
            //default value type constructor
            $ctor$2()
            {
                return this;
            }
            Clone($copy)
            {
                let copy = $copy ?? new this.constructor();
                copy.cfFormat = this.cfFormat;
                copy.ptd = this.ptd;
                copy.dwAspect = this.dwAspect;
                copy.lindex = this.lindex;
                copy.tymed = this.tymed;
                return copy;
            }
            //default member initializer
            constructor()
            {
                super();
                this.cfFormat = 0;
                this.ptd = 0;
                this.dwAspect = 0;
                this.lindex = 0;
                this.tymed = 0;
            }
            static $h = 971650;
            static $z = 18;
            static $f = 0b10000000000001010000001;
            static $k = 2;
            static $$md;
            static get $md() { return this.$$md ??= {"b":196609,"l":[{"t":524289,"n":"cfFormat","d":971650,"h":4295938946,"f":1,"a":[{"t":105709569,"c":8695644161,"a":[{"v":6,"t":110886913}]}]},{"t":786433,"n":"ptd","d":971650,"h":8590906242,"f":1},{"t":906114,"n":"dwAspect","d":971650,"h":12885873538,"f":1,"a":[{"t":105709569,"c":8695644161,"a":[{"v":8,"t":110886913}]}]},{"t":655361,"n":"lindex","d":971650,"h":17180840834,"f":1},{"t":1430402,"n":"tymed","d":971650,"h":21475808130,"f":1,"a":[{"t":105709569,"c":8695644161,"a":[{"v":8,"t":110886913}]}]}],"c":[{"n":".ctor","o":"$ctor$2","d":971650,"h":25770775426,"f":1}],"h":971650,"a":[{"t":33161217,"c":4328128513,"a":[{"v":1,"t":33226753}]}]}; }
            static get $b() { return $.$spc.System.ValueType; }
            static get $fullName() { return `System.Runtime.InteropServices.ComTypes.FORMATETC`; }
        });
        
        $asm.$str("$sris.System.Runtime.InteropServices.ComTypes.STATDATA", ($self) => class STATDATA extends $.$spc.System.ValueType
        {
            /*FORMATETC*/  get formatetc() { return this.$getField(0, 18); }
            /*FORMATETC*/  set formatetc(value) { this.$setField(0, 18, value); }
            /*ADVF*/  get advf() { return this.$getField(18, 4); }
            /*ADVF*/  set advf(value) { this.$setField(18, 4, value); }
            /*IAdviseSink*/  get advSink() { return this.$getField(22, 4); }
            /*IAdviseSink*/  set advSink(value) { this.$setField(22, 4, value); }
            /*int*/  get connection() { return this.$getField(26, 4); }
            /*int*/  set connection(value) { this.$setField(26, 4, value); }
            //default value type constructor
            $ctor$2()
            {
                return this;
            }
            Clone($copy)
            {
                let copy = $copy ?? new this.constructor();
                copy.formatetc = this.formatetc.Clone();
                copy.advf = this.advf;
                copy.advSink = this.advSink;
                copy.connection = this.connection;
                return copy;
            }
            //default member initializer
            constructor()
            {
                super();
                this.formatetc = $.$default($.$sris.System.Runtime.InteropServices.ComTypes.FORMATETC);
                this.advf = 0;
                this.advSink = null;
                this.connection = 0;
            }
            static $h = 1299330;
            static $z = 30;
            static $f = 0b1010000001;
            static $k = 2;
            static $$md;
            static get $md() { return this.$$md ??= {"b":196609,"l":[{"t":971650,"n":"formatetc","d":1299330,"h":4296266626,"f":1},{"t":775042,"n":"advf","d":1299330,"h":8591233922,"f":1},{"t":1037186,"n":"advSink","d":1299330,"h":12886201218,"f":1},{"t":655361,"n":"connection","d":1299330,"h":17181168514,"f":1}],"c":[{"n":".ctor","o":"$ctor$2","d":1299330,"h":21476135810,"f":1}],"h":1299330,"a":[{"t":33161217,"c":4328128513,"a":[{"v":1,"t":33226753}]}]}; }
            static get $b() { return $.$spc.System.ValueType; }
            static get $fullName() { return `System.Runtime.InteropServices.ComTypes.STATDATA`; }
        });
        
        $asm.$str("$sris.System.Runtime.InteropServices.ComTypes.STGMEDIUM", ($self) => class STGMEDIUM extends $.$spc.System.ValueType
        {
            /*TYMED*/  get tymed() { return this.$getField(0, 4); }
            /*TYMED*/  set tymed(value) { this.$setField(0, 4, value); }
            /*IntPtr*/  get unionmember() { return this.$getField(4, 4); }
            /*IntPtr*/  set unionmember(value) { this.$setField(4, 4, value); }
            /*object?*/  get pUnkForRelease() { return this.$getField(8, 4); }
            /*object?*/  set pUnkForRelease(value) { this.$setField(8, 4, value); }
            //default value type constructor
            $ctor$2()
            {
                return this;
            }
            Clone($copy)
            {
                let copy = $copy ?? new this.constructor();
                copy.tymed = this.tymed;
                copy.unionmember = this.unionmember;
                copy.pUnkForRelease = this.pUnkForRelease;
                return copy;
            }
            //default member initializer
            constructor()
            {
                super();
                this.tymed = 0;
                this.unionmember = 0;
                this.pUnkForRelease = null;
            }
            static $h = 1364866;
            static $z = 12;
            static $f = 0b1010000001;
            static $k = 2;
            static $$md;
            static get $md() { return this.$$md ??= {"b":196609,"l":[{"t":1430402,"n":"tymed","d":1364866,"h":4296332162,"f":1},{"t":786433,"n":"unionmember","d":1364866,"h":8591299458,"f":1},{"t":131073,"n":"pUnkForRelease","d":1364866,"h":12886266754,"f":1,"a":[{"t":105709569,"c":8695644161,"a":[{"v":25,"t":110886913}]}]}],"c":[{"n":".ctor","o":"$ctor$2","d":1364866,"h":17181234050,"f":1}],"h":1364866,"a":[{"t":33161217,"c":4328128513,"a":[{"v":1,"t":33226753}]}]}; }
            static get $b() { return $.$spc.System.ValueType; }
            static get $fullName() { return `System.Runtime.InteropServices.ComTypes.STGMEDIUM`; }
        });
        
        $asm.$cls("$sris.System.Runtime.InteropServices.ComAliasNameAttribute", ($self) => class ComAliasNameAttribute extends $.$spc.System.Attribute
        {
            $ctor$2(/*string*/ alias)
            {
                super.$ctor$1();
                this.Value = alias;
                return this;
            }
            /*string*/ Value = null;
            static $h = 447362;
            static $f = 0b10010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":14483457,"p":[{"p":1310721,"g":{"r":0,"d":0,"h":17180316546,"f":1},"n":"Value","d":447362,"h":12885349250,"f":1}],"c":[{"p":[{"n":"alias","p":1310721}],"n":".ctor","o":"$ctor$2","d":447362,"h":4295414658,"f":1}],"h":447362,"a":[{"t":14614529,"c":21489451009,"a":[{"v":10624,"t":14548993}],"n":[{"n":"Inherited","v":false,"t":262145}]}]}; }
            static get $b() { return $.$spc.System.Attribute; }
            static get $fullName() { return `System.Runtime.InteropServices.ComAliasNameAttribute`; }
        });
        
        $asm.$cls("$sris.System.Runtime.InteropServices.AutomationProxyAttribute", ($self) => class AutomationProxyAttribute extends $.$spc.System.Attribute
        {
            $ctor$2(/*bool*/ val)
            {
                super.$ctor$1();
                this.Value = val;
                return this;
            }
            /*bool*/ Value = false;
            //default member initializer
            constructor()
            {
                super();
                this.Value = false;
            }
            static $h = 381826;
            static $f = 0b10010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":14483457,"p":[{"p":262145,"g":{"r":0,"d":0,"h":17180251010,"f":1},"n":"Value","d":381826,"h":12885283714,"f":1}],"c":[{"p":[{"n":"val","p":262145}],"n":".ctor","o":"$ctor$2","d":381826,"h":4295349122,"f":1}],"h":381826,"a":[{"t":14614529,"c":21489451009,"a":[{"v":1029,"t":14548993}],"n":[{"n":"Inherited","v":false,"t":262145}]}]}; }
            static get $b() { return $.$spc.System.Attribute; }
            static get $fullName() { return `System.Runtime.InteropServices.AutomationProxyAttribute`; }
        });
        
        $asm.$cls("$sris.System.Runtime.InteropServices.ComCompatibleVersionAttribute", ($self) => class ComCompatibleVersionAttribute extends $.$spc.System.Attribute
        {
            $ctor$2(/*int*/ major, /*int*/ minor, /*int*/ build, /*int*/ revision)
            {
                super.$ctor$1();
                {
                    this.MajorVersion = major;
                    this.MinorVersion = minor;
                    this.BuildNumber = build;
                    this.RevisionNumber = revision;
                }
                return this;
            }
            /*int*/ MajorVersion = 0;
            /*int*/ MinorVersion = 0;
            /*int*/ BuildNumber = 0;
            /*int*/ RevisionNumber = 0;
            static $h = 578434;
            static $f = 0b10010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":14483457,"p":[{"p":655361,"g":{"r":0,"d":0,"h":17180447618,"f":1},"n":"MajorVersion","d":578434,"h":12885480322,"f":1},{"p":655361,"g":{"r":0,"d":0,"h":30065349506,"f":1},"n":"MinorVersion","d":578434,"h":25770382210,"f":1},{"p":655361,"g":{"r":0,"d":0,"h":42950251394,"f":1},"n":"BuildNumber","d":578434,"h":38655284098,"f":1},{"p":655361,"g":{"r":0,"d":0,"h":55835153282,"f":1},"n":"RevisionNumber","d":578434,"h":51540185986,"f":1}],"c":[{"p":[{"n":"major","p":655361},{"n":"minor","p":655361},{"n":"build","p":655361},{"n":"revision","p":655361}],"n":".ctor","o":"$ctor$2","d":578434,"h":4295545730,"f":1}],"h":578434,"a":[{"t":14614529,"c":21489451009,"a":[{"v":1,"t":14548993}],"n":[{"n":"Inherited","v":false,"t":262145}]}]}; }
            static get $b() { return $.$spc.System.Attribute; }
            static get $fullName() { return `System.Runtime.InteropServices.ComCompatibleVersionAttribute`; }
        });
        
        $asm.$cls("$sris.System.Runtime.InteropServices.ComConversionLossAttribute", ($self) => class ComConversionLossAttribute extends $.$spc.System.Attribute
        {
            //default reference type constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                return this;
            }
            static $h = 643970;
            static $f = 0b10010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":14483457,"c":[{"n":".ctor","o":"$ctor$2","d":643970,"h":4295611266,"f":1}],"h":643970,"a":[{"t":14614529,"c":21489451009,"a":[{"v":32767,"t":14548993}],"n":[{"n":"Inherited","v":false,"t":262145}]}]}; }
            static get $b() { return $.$spc.System.Attribute; }
            static get $fullName() { return `System.Runtime.InteropServices.ComConversionLossAttribute`; }
        });
        
        $asm.$cls("$sris.System.Runtime.InteropServices.ComRegisterFunctionAttribute", ($self) => class ComRegisterFunctionAttribute extends $.$spc.System.Attribute
        {
            //default reference type constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                return this;
            }
            static $h = 709506;
            static $f = 0b10010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":14483457,"c":[{"n":".ctor","o":"$ctor$2","d":709506,"h":4295676802,"f":1}],"h":709506,"a":[{"t":14614529,"c":21489451009,"a":[{"v":64,"t":14548993}],"n":[{"n":"Inherited","v":false,"t":262145}]}]}; }
            static get $b() { return $.$spc.System.Attribute; }
            static get $fullName() { return `System.Runtime.InteropServices.ComRegisterFunctionAttribute`; }
        });
        
        $asm.$cls("$sris.System.Runtime.InteropServices.ComUnregisterFunctionAttribute", ($self) => class ComUnregisterFunctionAttribute extends $.$spc.System.Attribute
        {
            //default reference type constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                return this;
            }
            static $h = 1495938;
            static $f = 0b10010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":14483457,"c":[{"n":".ctor","o":"$ctor$2","d":1495938,"h":4296463234,"f":1}],"h":1495938,"a":[{"t":14614529,"c":21489451009,"a":[{"v":64,"t":14548993}],"n":[{"n":"Inherited","v":false,"t":262145}]}]}; }
            static get $b() { return $.$spc.System.Attribute; }
            static get $fullName() { return `System.Runtime.InteropServices.ComUnregisterFunctionAttribute`; }
        });
        
        $asm.$cls("$sris.System.Runtime.InteropServices.ManagedToNativeComInteropStubAttribute", ($self) => class ManagedToNativeComInteropStubAttribute extends $.$spc.System.Attribute
        {
            $ctor$2(/*Type*/ classType, /*string*/ methodName)
            {
                super.$ctor$1();
                {
                    this.ClassType = classType;
                    this.MethodName = methodName;
                }
                return this;
            }
            /*Type*/ ClassType = null;
            /*string*/ MethodName = null;
            static $h = 1758082;
            static $f = 0b10010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":14483457,"p":[{"p":142606337,"g":{"r":0,"d":0,"h":17181627266,"f":1},"n":"ClassType","d":1758082,"h":12886659970,"f":1},{"p":1310721,"g":{"r":0,"d":0,"h":30066529154,"f":1},"n":"MethodName","d":1758082,"h":25771561858,"f":1}],"c":[{"p":[{"n":"classType","p":142606337},{"n":"methodName","p":1310721}],"n":".ctor","o":"$ctor$2","d":1758082,"h":4296725378,"f":1}],"h":1758082,"a":[{"t":14614529,"c":21489451009,"a":[{"v":64,"t":14548993}],"n":[{"n":"Inherited","v":false,"t":262145},{"n":"AllowMultiple","v":false,"t":262145}]}]}; }
            static get $b() { return $.$spc.System.Attribute; }
            static get $fullName() { return `System.Runtime.InteropServices.ManagedToNativeComInteropStubAttribute`; }
        });
        
        $asm.$cls("$sris.System.Runtime.InteropServices.Marshalling.GeneratedComClassAttribute", ($self) => class GeneratedComClassAttribute extends $.$spc.System.Attribute
        {
            //default reference type constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                return this;
            }
            static $h = 2872194;
            static $f = 0b10010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":14483457,"c":[{"n":".ctor","o":"$ctor$2","d":2872194,"h":4297839490,"f":1}],"h":2872194,"a":[{"t":14614529,"c":21489451009,"a":[{"v":4,"t":14548993}]}]}; }
            static get $b() { return $.$spc.System.Attribute; }
            static get $fullName() { return `System.Runtime.InteropServices.Marshalling.GeneratedComClassAttribute`; }
        });
        
        $asm.$cls("$sris.System.Runtime.InteropServices.Marshalling.GeneratedComInterfaceAttribute", ($self) => class GeneratedComInterfaceAttribute extends $.$spc.System.Attribute
        {
            /*ComInterfaceOptions*/ Options = 0;
            /*StringMarshalling*/ StringMarshalling = 0;
            /*Type?*/ StringMarshallingCustomType = null;
            /*Type?*/ ExceptionToUnmanagedMarshaller = null;
            //default reference type constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                return this;
            }
            //default member initializer
            constructor()
            {
                super();
                this.Options = 3;
                this.StringMarshalling = 0;
            }
            static $h = 2937730;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":14483457,"p":[{"p":2151298,"g":{"r":0,"d":0,"h":12887839618,"f":1},"s":{"r":0,"d":0,"h":17182806914,"f":1},"n":"Options","d":2937730,"h":8592872322,"f":1},{"p":109838337,"g":{"r":0,"d":0,"h":30067708802,"f":1},"s":{"r":0,"d":0,"h":34362676098,"f":1},"n":"StringMarshalling","d":2937730,"h":25772741506,"f":1},{"p":142606337,"g":{"r":0,"d":0,"h":47247577986,"f":1},"s":{"r":0,"d":0,"h":51542545282,"f":1},"n":"StringMarshallingCustomType","d":2937730,"h":42952610690,"f":1},{"p":142606337,"g":{"r":0,"d":0,"h":64427447170,"f":1},"s":{"r":0,"d":0,"h":68722414466,"f":1},"n":"ExceptionToUnmanagedMarshaller","d":2937730,"h":60132479874,"f":1}],"c":[{"n":".ctor","o":"$ctor$2","d":2937730,"h":73017381762,"f":1}],"h":2937730,"a":[{"t":14614529,"c":21489451009,"a":[{"v":1024,"t":14548993}]}]}; }
            static get $b() { return $.$spc.System.Attribute; }
            static get $fullName() { return `System.Runtime.InteropServices.Marshalling.GeneratedComInterfaceAttribute`; }
        });
        
        $asm.$cls("$sris.System.Runtime.InteropServices.Marshalling.StrategyBasedComWrappers", ($self) => class StrategyBasedComWrappers extends $.$spc.System.Runtime.InteropServices.ComWrappers
        {
            /*StrategyBasedComWrappers*/ static DefaultMarshallingInstance = null;
            /*IIUnknownInterfaceDetailsStrategy*/ static DefaultIUnknownInterfaceDetailsStrategy = null;
            /*IIUnknownStrategy*/ static DefaultIUnknownStrategy = null;
            static /*IIUnknownCacheStrategy */ CreateDefaultCacheStrategy()
            {
                return new $.$sris.System.Runtime.InteropServices.Marshalling.DefaultCaching().$ctor$1();
            }
            /*IIUnknownInterfaceDetailsStrategy */ GetOrCreateInterfaceDetailsStrategy()
            {
                //if (OperatingSystem.IsWindows() && RuntimeFeature.IsDynamicCodeSupported && ComObject.BuiltInComSupported && ComObject.ComImportInteropEnabled) { ... }
                return $.$sris.System.Runtime.InteropServices.Marshalling.StrategyBasedComWrappers.DefaultIUnknownInterfaceDetailsStrategy;
                /*static IIUnknownInterfaceDetailsStrategy*/  function GetInteropStrategy()
                {
                    return $.$sris.System.Runtime.InteropServices.Marshalling.ComImportInteropInterfaceDetailsStrategy.Instance;
                }
            }
            /*IIUnknownStrategy */ GetOrCreateIUnknownStrategy()
            {
                return $.$sris.System.Runtime.InteropServices.Marshalling.StrategyBasedComWrappers.DefaultIUnknownStrategy;
            }
            /*IIUnknownCacheStrategy */ CreateCacheStrategy()
            {
                return $.$sris.System.Runtime.InteropServices.Marshalling.StrategyBasedComWrappers.CreateDefaultCacheStrategy();
            }
            /*ComInterfaceEntry* */ ComputeVtables(/*object*/ obj, /*CreateComInterfaceFlags*/ flags, /*out int*/ count)
            {
                let details;
                if (this.GetOrCreateInterfaceDetailsStrategy().System$Runtime$InteropServices$Marshalling$IIUnknownInterfaceDetailsStrategy$GetComExposedTypeDetails($.$spc.System.Object.GetType.call(obj).TypeHandle) !== null && ((details = this.GetOrCreateInterfaceDetailsStrategy().System$Runtime$InteropServices$Marshalling$IIUnknownInterfaceDetailsStrategy$GetComExposedTypeDetails($.$spc.System.Object.GetType.call(obj).TypeHandle), details != null && true)))
                {
                    return details.System$Runtime$InteropServices$Marshalling$IComExposedDetails$GetComInterfaceEntries(count);
                }
                count.$v = 0;
                return null;
            }
            /*object */ CreateObject(/*nint*/ externalComObject, /*CreateObjectFlags*/ flags)
            {
                if (((flags & (1/*CreateObjectFlags.TrackerObject*/)) == (1/*CreateObjectFlags.TrackerObject*/)) || ((flags & (4/*CreateObjectFlags.Aggregation*/)) == (4/*CreateObjectFlags.Aggregation*/)))
                {
                    throw new $.$spc.System.NotSupportedException().$ctor$9();
                }
                /*var*/ let rcw = (() =>
                {
                    //new $.$sris.System.Runtime.InteropServices.Marshalling.ComObject()
                    const $t1 = $.$sris.System.Runtime.InteropServices.Marshalling.ComObject;
                    const $i1 = new $t1();
                    $i1.$ctor$1(this.GetOrCreateInterfaceDetailsStrategy(), this.GetOrCreateIUnknownStrategy(), this.CreateCacheStrategy(), $.$spc.System.IntPtr.op_Explicit$3(externalComObject));
                    $i1.UniqueInstance = ((flags & (2/*CreateObjectFlags.UniqueInstance*/)) == (2/*CreateObjectFlags.UniqueInstance*/));
                    return $i1;
                })();
                return rcw;
            }
            /*object? */ CreateObject$1(/*nint*/ externalComObject, /*CreateObjectFlags*/ flags, /*object?*/ userState, /*out CreatedWrapperFlags*/ wrapperFlags)
            {
                return super.CreateObject$1(externalComObject, flags, userState, wrapperFlags);
            }
            /*void */ ReleaseObjects(/*IEnumerable*/ objects)
            {
                throw new $.$spc.System.NotImplementedException().$ctor$9();
            }
            //default reference type constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                return this;
            }
            //Static Initializer
            static $sinit()
            {
                {
                    this.DefaultMarshallingInstance = new $.$sris.System.Runtime.InteropServices.Marshalling.StrategyBasedComWrappers().$ctor$2();
                }
                {
                    this.DefaultIUnknownInterfaceDetailsStrategy = $.$sris.System.Runtime.InteropServices.Marshalling.DefaultIUnknownInterfaceDetailsStrategy.Instance;
                }
                {
                    this.DefaultIUnknownStrategy = $.$sris.System.Runtime.InteropServices.Marshalling.FreeThreadedStrategy.Instance;
                }
            }
            static $h = 3658626;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":102629377,"p":[{"p":3658626,"g":{"r":0,"d":0,"h":12888560514,"f":40},"n":"DefaultMarshallingInstance","d":3658626,"h":8593593218,"f":40},{"p":3330946,"g":{"r":0,"d":0,"h":25773462402,"f":33},"n":"DefaultIUnknownInterfaceDetailsStrategy","d":3658626,"h":21478495106,"f":33},{"p":3462018,"g":{"r":0,"d":0,"h":38658364290,"f":33},"n":"DefaultIUnknownStrategy","d":3658626,"h":34363396994,"f":33}],"m":[{"r":3134338,"n":"CreateDefaultCacheStrategy","d":3658626,"h":42953331586,"f":36},{"r":3330946,"n":"GetOrCreateInterfaceDetailsStrategy","d":3658626,"h":47248298882,"f":132},{"r":3462018,"n":"GetOrCreateIUnknownStrategy","d":3658626,"h":51543266178,"f":132},{"r":3134338,"n":"CreateCacheStrategy","d":3658626,"h":55838233474,"f":132},{"r":0,"p":[{"n":"obj","p":131073},{"n":"flags","p":102825985},{"n":"count","p":655361,"f":2}],"n":"ComputeVtables","d":3658626,"h":60133200770,"f":98308},{"r":131073,"p":[{"n":"externalComObject","p":786433},{"n":"flags","p":102957057}],"n":"CreateObject","d":3658626,"h":64428168066,"f":98308},{"r":131073,"p":[{"n":"externalComObject","p":786433},{"n":"flags","p":102957057},{"n":"userState","p":131073},{"n":"wrapperFlags","p":102891521,"f":2}],"n":"CreateObject","o":"@$1","d":3658626,"h":68723135362,"f":98308},{"r":65537,"p":[{"n":"objects","p":31588353}],"n":"ReleaseObjects","d":3658626,"h":73018102658,"f":98308}],"c":[{"n":".ctor","o":"$ctor$2","d":3658626,"h":77313069954,"f":1}],"h":3658626,"a":[{"t":115277825,"c":4410245121,"a":[{"v":"android","t":1310721}]},{"t":115277825,"c":4410245121,"a":[{"v":"browser","t":1310721}]},{"t":115277825,"c":4410245121,"a":[{"v":"ios","t":1310721}]},{"t":115277825,"c":4410245121,"a":[{"v":"tvos","t":1310721}]},{"t":23396353,"c":8613330945,"a":[{"v":false,"t":262145}]}]}; }
            static get $b() { return $.$spc.System.Runtime.InteropServices.ComWrappers; }
            static get $fullName() { return `System.Runtime.InteropServices.Marshalling.StrategyBasedComWrappers`; }
        });
        
        $asm.$cls("$sris.System.Runtime.InteropServices.PrimaryInteropAssemblyAttribute", ($self) => class PrimaryInteropAssemblyAttribute extends $.$spc.System.Attribute
        {
            $ctor$2(/*int*/ major, /*int*/ minor)
            {
                super.$ctor$1();
                {
                    this.MajorVersion = major;
                    this.MinorVersion = minor;
                }
                return this;
            }
            /*int*/ MajorVersion = 0;
            /*int*/ MinorVersion = 0;
            static $h = 3855234;
            static $f = 0b10010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":14483457,"p":[{"p":655361,"g":{"r":0,"d":0,"h":17183724418,"f":1},"n":"MajorVersion","d":3855234,"h":12888757122,"f":1},{"p":655361,"g":{"r":0,"d":0,"h":30068626306,"f":1},"n":"MinorVersion","d":3855234,"h":25773659010,"f":1}],"c":[{"p":[{"n":"major","p":655361},{"n":"minor","p":655361}],"n":".ctor","o":"$ctor$2","d":3855234,"h":4298822530,"f":1}],"h":3855234,"a":[{"t":14614529,"c":21489451009,"a":[{"v":1,"t":14548993}],"n":[{"n":"Inherited","v":false,"t":262145},{"n":"AllowMultiple","v":true,"t":262145}]}]}; }
            static get $b() { return $.$spc.System.Attribute; }
            static get $fullName() { return `System.Runtime.InteropServices.PrimaryInteropAssemblyAttribute`; }
        });
        
        $asm.$cls("$sris.System.Runtime.InteropServices.TypeLibImportClassAttribute", ($self) => class TypeLibImportClassAttribute extends $.$spc.System.Attribute
        {
            $ctor$2(/*Type*/ importClass)
            {
                super.$ctor$1();
                this.Value = $.$spc.System.Type.ToString.call(importClass);
                return this;
            }
            /*string*/ Value = null;
            static $h = 4248450;
            static $f = 0b10010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":14483457,"p":[{"p":1310721,"g":{"r":0,"d":0,"h":17184117634,"f":1},"n":"Value","d":4248450,"h":12889150338,"f":1}],"c":[{"p":[{"n":"importClass","p":142606337}],"n":".ctor","o":"$ctor$2","d":4248450,"h":4299215746,"f":1}],"h":4248450,"a":[{"t":14614529,"c":21489451009,"a":[{"v":1024,"t":14548993}],"n":[{"n":"Inherited","v":false,"t":262145}]}]}; }
            static get $b() { return $.$spc.System.Attribute; }
            static get $fullName() { return `System.Runtime.InteropServices.TypeLibImportClassAttribute`; }
        });
        
        $asm.$cls("$sris.System.Runtime.InteropServices.TypeLibVarAttribute", ($self) => class TypeLibVarAttribute extends $.$spc.System.Attribute
        {
            $ctor$2(/*TypeLibVarFlags*/ flags)
            {
                super.$ctor$1();
                {
                    this.Value = flags;
                }
                return this;
            }
            $ctor$3(/*short*/ flags)
            {
                super.$ctor$1();
                {
                    this.Value = $.$cast(flags, $.$sris.System.Runtime.InteropServices.TypeLibVarFlags);
                }
                return this;
            }
            /*TypeLibVarFlags*/ Value = 0;
            //default member initializer
            constructor()
            {
                super();
                this.Value = 0;
            }
            static $h = 4445058;
            static $f = 0b10010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":14483457,"p":[{"p":4510594,"g":{"r":0,"d":0,"h":21479281538,"f":1},"n":"Value","d":4445058,"h":17184314242,"f":1}],"c":[{"p":[{"n":"flags","p":4510594}],"n":".ctor","o":"$ctor$2","d":4445058,"h":4299412354,"f":1},{"p":[{"n":"flags","p":524289}],"n":".ctor","o":"$ctor$3","d":4445058,"h":8594379650,"f":1}],"h":4445058,"a":[{"t":14614529,"c":21489451009,"a":[{"v":256,"t":14548993}],"n":[{"n":"Inherited","v":false,"t":262145}]}]}; }
            static get $b() { return $.$spc.System.Attribute; }
            static get $fullName() { return `System.Runtime.InteropServices.TypeLibVarAttribute`; }
        });
        
        $asm.$cls("$sris.System.Runtime.InteropServices.TypeLibTypeAttribute", ($self) => class TypeLibTypeAttribute extends $.$spc.System.Attribute
        {
            $ctor$2(/*TypeLibTypeFlags*/ flags)
            {
                super.$ctor$1();
                {
                    this.Value = flags;
                }
                return this;
            }
            $ctor$3(/*short*/ flags)
            {
                super.$ctor$1();
                {
                    this.Value = $.$cast(flags, $.$sris.System.Runtime.InteropServices.TypeLibTypeFlags);
                }
                return this;
            }
            /*TypeLibTypeFlags*/ Value = 0;
            //default member initializer
            constructor()
            {
                super();
                this.Value = 0;
            }
            static $h = 4313986;
            static $f = 0b10010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":14483457,"p":[{"p":4379522,"g":{"r":0,"d":0,"h":21479150466,"f":1},"n":"Value","d":4313986,"h":17184183170,"f":1}],"c":[{"p":[{"n":"flags","p":4379522}],"n":".ctor","o":"$ctor$2","d":4313986,"h":4299281282,"f":1},{"p":[{"n":"flags","p":524289}],"n":".ctor","o":"$ctor$3","d":4313986,"h":8594248578,"f":1}],"h":4313986,"a":[{"t":14614529,"c":21489451009,"a":[{"v":1052,"t":14548993}],"n":[{"n":"Inherited","v":false,"t":262145}]}]}; }
            static get $b() { return $.$spc.System.Attribute; }
            static get $fullName() { return `System.Runtime.InteropServices.TypeLibTypeAttribute`; }
        });
        
        $asm.$cls("$sris.System.Runtime.InteropServices.TypeLibVersionAttribute", ($self) => class TypeLibVersionAttribute extends $.$spc.System.Attribute
        {
            $ctor$2(/*int*/ major, /*int*/ minor)
            {
                super.$ctor$1();
                {
                    this.MajorVersion = major;
                    this.MinorVersion = minor;
                }
                return this;
            }
            /*int*/ MajorVersion = 0;
            /*int*/ MinorVersion = 0;
            static $h = 4576130;
            static $f = 0b10010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":14483457,"p":[{"p":655361,"g":{"r":0,"d":0,"h":17184445314,"f":1},"n":"MajorVersion","d":4576130,"h":12889478018,"f":1},{"p":655361,"g":{"r":0,"d":0,"h":30069347202,"f":1},"n":"MinorVersion","d":4576130,"h":25774379906,"f":1}],"c":[{"p":[{"n":"major","p":655361},{"n":"minor","p":655361}],"n":".ctor","o":"$ctor$2","d":4576130,"h":4299543426,"f":1}],"h":4576130,"a":[{"t":14614529,"c":21489451009,"a":[{"v":1,"t":14548993}],"n":[{"n":"Inherited","v":false,"t":262145}]}]}; }
            static get $b() { return $.$spc.System.Attribute; }
            static get $fullName() { return `System.Runtime.InteropServices.TypeLibVersionAttribute`; }
        });
        
        $asm.$cls("$sris.System.Runtime.InteropServices.TypeLibFuncAttribute", ($self) => class TypeLibFuncAttribute extends $.$spc.System.Attribute
        {
            $ctor$2(/*TypeLibFuncFlags*/ flags)
            {
                super.$ctor$1();
                {
                    this.Value = flags;
                }
                return this;
            }
            $ctor$3(/*short*/ flags)
            {
                super.$ctor$1();
                {
                    this.Value = $.$cast(flags, $.$sris.System.Runtime.InteropServices.TypeLibFuncFlags);
                }
                return this;
            }
            /*TypeLibFuncFlags*/ Value = 0;
            //default member initializer
            constructor()
            {
                super();
                this.Value = 0;
            }
            static $h = 4117378;
            static $f = 0b10010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":14483457,"p":[{"p":4182914,"g":{"r":0,"d":0,"h":21478953858,"f":1},"n":"Value","d":4117378,"h":17183986562,"f":1}],"c":[{"p":[{"n":"flags","p":4182914}],"n":".ctor","o":"$ctor$2","d":4117378,"h":4299084674,"f":1},{"p":[{"n":"flags","p":524289}],"n":".ctor","o":"$ctor$3","d":4117378,"h":8594051970,"f":1}],"h":4117378,"a":[{"t":14614529,"c":21489451009,"a":[{"v":64,"t":14548993}],"n":[{"n":"Inherited","v":false,"t":262145}]}]}; }
            static get $b() { return $.$spc.System.Attribute; }
            static get $fullName() { return `System.Runtime.InteropServices.TypeLibFuncAttribute`; }
        });
        
        $asm.$str("$sris.System.Runtime.InteropServices.Marshalling.VirtualMethodTableInfo", ($self) => class VirtualMethodTableInfo extends $.$spc.System.ValueType
        {
            $ctor$2(/*void**/ thisPointer, /*void***/ virtualMethodTable)
            {
                super.$ctor$1();
                {
                    this.ThisPointer = thisPointer;
                    this.VirtualMethodTable = virtualMethodTable;
                }
                return this;
            }
            /*void**/ ThisPointer;
            /*void***/ VirtualMethodTable;
            /*void */ Deconstruct(/*out void**/ thisPointer, /*out void***/ virtualMethodTable)
            {
                thisPointer.$v = this.ThisPointer;
                virtualMethodTable.$v = this.VirtualMethodTable;
            }
            //default value type constructor
            $ctor$3()
            {
                return this;
            }
            Clone($copy)
            {
                let copy = $copy ?? new this.constructor();
                copy.ThisPointer = this.ThisPointer.Clone();
                copy.VirtualMethodTable = this.VirtualMethodTable.Clone();
                return copy;
            }
            //default member initializer
            constructor()
            {
                super();
                this.ThisPointer = $.$default($.$typePointer($.$spc.System.Void));
                this.VirtualMethodTable = $.$default($.$typePointer($.$typePointer($.$spc.System.Void)));
            }
            static $h = 3789698;
            static $z = 8;
            static $f = 0b1010000001;
            static $k = 2;
            static $$md;
            static get $md() { return this.$$md ??= {"b":196609,"p":[{"p":0,"g":{"r":0,"d":0,"h":17183658882,"f":1},"n":"ThisPointer","d":3789698,"h":12888691586,"f":1},{"p":0,"g":{"r":0,"d":0,"h":30068560770,"f":1},"n":"VirtualMethodTable","d":3789698,"h":25773593474,"f":1}],"m":[{"r":65537,"p":[{"n":"thisPointer","p":0,"f":2},{"n":"virtualMethodTable","p":0,"f":2}],"n":"Deconstruct","d":3789698,"h":34363528066,"f":1}],"c":[{"p":[{"n":"thisPointer","p":0},{"n":"virtualMethodTable","p":0}],"n":".ctor","o":"$ctor$2","d":3789698,"h":4298756994,"f":1},{"n":".ctor","o":"$ctor$3","d":3789698,"h":38658495362,"f":1}],"h":3789698,"a":[{"t":23396353,"c":8613330945,"a":[{"v":false,"t":262145}]}]}; }
            static get $b() { return $.$spc.System.ValueType; }
            static get $fullName() { return `System.Runtime.InteropServices.Marshalling.VirtualMethodTableInfo`; }
        });
        
        $asm.$cls("$sris.System.Runtime.InteropServices.ImportedFromTypeLibAttribute", ($self) => class ImportedFromTypeLibAttribute extends $.$spc.System.Attribute
        {
            $ctor$2(/*string*/ tlbFile)
            {
                super.$ctor$1();
                this.Value = tlbFile;
                return this;
            }
            /*string*/ Value = null;
            static $h = 1692546;
            static $f = 0b10010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":14483457,"p":[{"p":1310721,"g":{"r":0,"d":0,"h":17181561730,"f":1},"n":"Value","d":1692546,"h":12886594434,"f":1}],"c":[{"p":[{"n":"tlbFile","p":1310721}],"n":".ctor","o":"$ctor$2","d":1692546,"h":4296659842,"f":1}],"h":1692546,"a":[{"t":14614529,"c":21489451009,"a":[{"v":1,"t":14548993}],"n":[{"n":"Inherited","v":false,"t":262145}]}]}; }
            static get $b() { return $.$spc.System.Attribute; }
            static get $fullName() { return `System.Runtime.InteropServices.ImportedFromTypeLibAttribute`; }
        });
        
        $asm.$cls("$sris.System.Runtime.InteropServices.Marshalling.ComExposedClassAttribute<>", (T) => $asm.$gt("$sris.System.Runtime.InteropServices.Marshalling.ComExposedClassAttribute<>", [T], ($self) => class ComExposedClassAttribute$$ extends $.$spc.System.Attribute
        {
            /*ComWrappers.ComInterfaceEntry* */ GetComInterfaceEntries(/*out int*/ count)
            {
                return T.System$Runtime$InteropServices$Marshalling$IComExposedClass$GetComInterfaceEntries(count);
            }
            //Generated interface implemetation for System.Runtime.InteropServices.Marshalling.IComExposedDetails.GetComInterfaceEntries(out int)
            System$Runtime$InteropServices$Marshalling$IComExposedDetails$GetComInterfaceEntries()
            {
                return this.GetComInterfaceEntries(...arguments);
            }
            //default reference type constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                return this;
            }
            static $h = 1823618;
            static $g = 1;
            static $f = 0b11010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":14483457,"m":[{"r":0,"p":[{"n":"count","p":655361,"f":2}],"n":"GetComInterfaceEntries","d":this.$h,"h":Number(BigInt(this.$h)|0x100000000n),"f":1}],"c":[{"n":".ctor","o":"$ctor$2","d":this.$h,"h":Number(BigInt(this.$h)|0x200000000n),"f":1}],"i":[3068802],"g":[T?.$h??1507328],"r":1,"h":this.$h,"a":[{"t":14614529,"c":21489451009,"a":[{"v":4,"t":14548993}],"n":[{"n":"Inherited","v":false,"t":262145}]},{"t":23396353,"c":8613330945,"a":[{"v":false,"t":262145}]}]}; }
            static get $b() { return $.$spc.System.Attribute; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$sris.System.Runtime.InteropServices.Marshalling.IComExposedDetails ]; }
            static get $fullName() { return `System.Runtime.InteropServices.Marshalling.ComExposedClassAttribute<${T?.$fullName}>`; }
        }));
        
        $asm.$cls("$sris.System.Runtime.InteropServices.Marshalling.IUnknownDerivedAttribute<,>", (T, TImpl) => $asm.$gt("$sris.System.Runtime.InteropServices.Marshalling.IUnknownDerivedAttribute<,>", [T, TImpl], ($self) => class IUnknownDerivedAttribute$$$ extends $.$spc.System.Attribute
        {
            $ctor$2()
            {
                super.$ctor$1();
                {
                }
                return this;
            }
            /*Guid */ get Iid()
            {
                return T.System$Runtime$InteropServices$Marshalling$IIUnknownInterfaceType$Iid;
            }
            /*Type */ get Implementation()
            {
                return TImpl.$type;
            }
            /*void** */ get ManagedVirtualMethodTable()
            {
                return T.System$Runtime$InteropServices$Marshalling$IIUnknownInterfaceType$ManagedVirtualMethodTable;
            }
            //Generated interface implemetation for System.Runtime.InteropServices.Marshalling.IIUnknownDerivedDetails.Iid.get
            get System$Runtime$InteropServices$Marshalling$IIUnknownDerivedDetails$Iid()
            {
                return this.Iid;
            }
            //Generated interface implemetation for System.Runtime.InteropServices.Marshalling.IIUnknownDerivedDetails.Implementation.get
            get System$Runtime$InteropServices$Marshalling$IIUnknownDerivedDetails$Implementation()
            {
                return this.Implementation;
            }
            //Generated interface implemetation for System.Runtime.InteropServices.Marshalling.IIUnknownDerivedDetails.ManagedVirtualMethodTable.get
            get System$Runtime$InteropServices$Marshalling$IIUnknownDerivedDetails$ManagedVirtualMethodTable()
            {
                return this.ManagedVirtualMethodTable;
            }
            static $h = 3527554;
            static $g = 2;
            static $f = 0b1010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":14483457,"p":[{"p":56164353,"g":{"r":0,"d":0,"h":Number(BigInt(this.$h)|0x300000000n),"f":1},"n":"Iid","d":this.$h,"h":Number(BigInt(this.$h)|0x200000000n),"f":1},{"p":142606337,"g":{"r":0,"d":0,"h":Number(BigInt(this.$h)|0x500000000n),"f":1},"n":"Implementation","d":this.$h,"h":Number(BigInt(this.$h)|0x400000000n),"f":1},{"p":0,"g":{"r":0,"d":0,"h":Number(BigInt(this.$h)|0x700000000n),"f":1},"n":"ManagedVirtualMethodTable","d":this.$h,"h":Number(BigInt(this.$h)|0x600000000n),"f":1}],"c":[{"n":".ctor","o":"$ctor$2","d":this.$h,"h":Number(BigInt(this.$h)|0x100000000n),"f":1}],"i":[3265410],"g":[T?.$h??1507328,TImpl?.$h??1572864],"r":2,"h":this.$h,"a":[{"t":14614529,"c":21489451009,"a":[{"v":1024,"t":14548993}],"n":[{"n":"Inherited","v":false,"t":262145}]},{"t":23396353,"c":8613330945,"a":[{"v":false,"t":262145}]}]}; }
            static get $b() { return $.$spc.System.Attribute; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$sris.System.Runtime.InteropServices.Marshalling.IIUnknownDerivedDetails ]; }
            static get $fullName() { return `System.Runtime.InteropServices.Marshalling.IUnknownDerivedAttribute<${T?.$fullName},${TImpl?.$fullName}>`; }
        }));
        
        $asm.$cls("$sris.System.Runtime.CompilerServices.IDispatchConstantAttribute", ($self) => class IDispatchConstantAttribute extends $.$spc.System.Runtime.CompilerServices.CustomConstantAttribute
        {
            $ctor$3()
            {
                super.$ctor$2();
                {
                }
                return this;
            }
            /*object */ get Value()
            {
                return new $.$spc.System.Runtime.InteropServices.DispatchWrapper().$ctor$1(null);
            }
            static $h = 185218;
            static $f = 0b10010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":89915393,"p":[{"p":131073,"g":{"r":0,"d":0,"h":12885087106,"f":32769},"n":"Value","d":185218,"h":8590119810,"f":32769}],"c":[{"n":".ctor","o":"$ctor$3","d":185218,"h":4295152514,"f":1}],"h":185218,"a":[{"t":114950145,"c":4409917441,"a":[{"v":"windows","t":1310721}]},{"t":14614529,"c":21489451009,"a":[{"v":2304,"t":14548993}],"n":[{"n":"Inherited","v":false,"t":262145}]}]}; }
            static get $b() { return $.$spc.System.Runtime.CompilerServices.CustomConstantAttribute; }
            static get $fullName() { return `System.Runtime.CompilerServices.IDispatchConstantAttribute`; }
        });
        
        $asm.$cls("$sris.System.Runtime.CompilerServices.IUnknownConstantAttribute", ($self) => class IUnknownConstantAttribute extends $.$spc.System.Runtime.CompilerServices.CustomConstantAttribute
        {
            $ctor$3()
            {
                super.$ctor$2();
                {
                }
                return this;
            }
            /*object */ get Value()
            {
                return new $.$spc.System.Runtime.InteropServices.UnknownWrapper().$ctor$1(null);
            }
            static $h = 250754;
            static $f = 0b10010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":89915393,"p":[{"p":131073,"g":{"r":0,"d":0,"h":12885152642,"f":32769},"n":"Value","d":250754,"h":8590185346,"f":32769}],"c":[{"n":".ctor","o":"$ctor$3","d":250754,"h":4295218050,"f":1}],"h":250754,"a":[{"t":14614529,"c":21489451009,"a":[{"v":2304,"t":14548993}],"n":[{"n":"Inherited","v":false,"t":262145}]}]}; }
            static get $b() { return $.$spc.System.Runtime.CompilerServices.CustomConstantAttribute; }
            static get $fullName() { return `System.Runtime.CompilerServices.IUnknownConstantAttribute`; }
        });
        
        $asm.$cls("$sris.System.Runtime.InteropServices.ComAwareEventInfo", ($self) => class ComAwareEventInfo extends $.$spc.System.Reflection.EventInfo
        {
            /*EventInfo*/ _innerEventInfo = null;
            $ctor$4(/*Type*/ type, /*string*/ eventName)
            {
                super.$ctor$3();
                {
                    this._innerEventInfo = type.GetEvent(eventName);
                }
                return this;
            }
            /*void */ AddEventHandler(/*object*/ target, /*Delegate*/ handler)
            {
                if ($.$spc.System.Runtime.InteropServices.Marshal.IsComObject(target))
                {
                    /*Guid*/ let sourceIid;
                    /*int*/ let dispid;
                    $.$sris.System.Runtime.InteropServices.ComAwareEventInfo.GetDataForComInvocation(this._innerEventInfo, $.$ref(() => sourceIid, ($v) => sourceIid = $v, $.$spc.System.Guid), $.$ref(() => dispid, ($v) => dispid = $v, $.$spc.System.Int32));
                    $.$spc.System.Runtime.InteropServices.ComEventsHelper.Combine(target, sourceIid, dispid, handler);
                }
                else 
                {
                    this._innerEventInfo.AddEventHandler(target, handler);
                }
            }
            /*void */ RemoveEventHandler(/*object*/ target, /*Delegate*/ handler)
            {
                if ($.$spc.System.Runtime.InteropServices.Marshal.IsComObject(target))
                {
                    /*Guid*/ let sourceIid;
                    /*int*/ let dispid;
                    $.$sris.System.Runtime.InteropServices.ComAwareEventInfo.GetDataForComInvocation(this._innerEventInfo, $.$ref(() => sourceIid, ($v) => sourceIid = $v, $.$spc.System.Guid), $.$ref(() => dispid, ($v) => dispid = $v, $.$spc.System.Int32));
                    $.$spc.System.Runtime.InteropServices.ComEventsHelper.Remove(target, sourceIid, dispid, handler);
                }
                else 
                {
                    this._innerEventInfo.RemoveEventHandler(target, handler);
                }
            }
            /*EventAttributes */ get Attributes()
            {
                return this._innerEventInfo.Attributes;
            }
            /*MethodInfo? */ GetAddMethod$1(/*bool*/ nonPublic)
            {
                return this._innerEventInfo.GetAddMethod$1(nonPublic);
            }
            /*MethodInfo[] */ GetOtherMethods$1(/*bool*/ nonPublic)
            {
                return this._innerEventInfo.GetOtherMethods$1(nonPublic);
            }
            /*MethodInfo? */ GetRaiseMethod$1(/*bool*/ nonPublic)
            {
                return this._innerEventInfo.GetRaiseMethod$1(nonPublic);
            }
            /*MethodInfo? */ GetRemoveMethod$1(/*bool*/ nonPublic)
            {
                return this._innerEventInfo.GetRemoveMethod$1(nonPublic);
            }
            /*Type? */ get DeclaringType()
            {
                return this._innerEventInfo.DeclaringType;
            }
            /*object[] */ GetCustomAttributes$1(/*Type*/ attributeType, /*bool*/ inherit)
            {
                return this._innerEventInfo.GetCustomAttributes$1(attributeType, inherit);
            }
            /*object[] */ GetCustomAttributes(/*bool*/ inherit)
            {
                return this._innerEventInfo.GetCustomAttributes(inherit);
            }
            /*IList<CustomAttributeData> */ GetCustomAttributesData()
            {
                return this._innerEventInfo.GetCustomAttributesData();
            }
            /*bool */ IsDefined(/*Type*/ attributeType, /*bool*/ inherit)
            {
                return this._innerEventInfo.IsDefined(attributeType, inherit);
            }
            /*int */ get MetadataToken()
            {
                return this._innerEventInfo.MetadataToken;
            }
            /*Module */ get Module()
            {
                return this._innerEventInfo.Module;
            }
            /*string */ get Name()
            {
                return this._innerEventInfo.Name;
            }
            /*Type? */ get ReflectedType()
            {
                return this._innerEventInfo.ReflectedType;
            }
            static /*void */ GetDataForComInvocation(/*EventInfo*/ eventInfo, /*out Guid*/ sourceIid, /*out int*/ dispid)
            {
                /*object[]*/ let comEventInterfaces = eventInfo.DeclaringType.GetCustomAttributes$1($.$spc.System.Runtime.InteropServices.ComEventInterfaceAttribute.$type, false);
                if (comEventInterfaces === null || comEventInterfaces.length === 0)
                {
                    throw new $.$spc.System.InvalidOperationException().$ctor$10($.$sris.System.SR.InvalidOperation_NoComEventInterfaceAttribute);
                }
                /*ComEventInterfaceAttribute*/ let interfaceAttribute = $.$cast($.$spc.System.Array.$ReadT1.call(comEventInterfaces, 0), $.$spc.System.Runtime.InteropServices.ComEventInterfaceAttribute);
                if (comEventInterfaces.length > 1)
                {
                    throw new $.$spc.System.Reflection.AmbiguousMatchException().$ctor$10($.$sris.System.SR.Format($.$sris.System.SR.AmbiguousMatch_MultipleEventInterfaceAttributes, interfaceAttribute));
                }
                /*Type*/ let sourceInterface = interfaceAttribute.SourceInterface;
                /*Guid*/ let guid = sourceInterface.GUID;
                /*MethodInfo*/ let methodInfo = sourceInterface.GetMethod$1(eventInfo.Name);
                /*Attribute?*/ let dispIdAttribute = $.$spc.System.Attribute.GetCustomAttribute$2(methodInfo, $.$spc.System.Runtime.InteropServices.DispIdAttribute.$type);
                if (dispIdAttribute === null)
                {
                    throw new $.$spc.System.InvalidOperationException().$ctor$10($.$sris.System.SR.InvalidOperation_NoDispIdAttribute);
                }
                sourceIid.$v = guid;
                dispid.$v = ($.$cast(dispIdAttribute, $.$spc.System.Runtime.InteropServices.DispIdAttribute)).Value;
            }
            static $h = 512898;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":76414977,"p":[{"p":76349441,"g":{"r":0,"d":0,"h":25770316674,"f":32769},"n":"Attributes","d":512898,"h":21475349378,"f":32769},{"p":142606337,"g":{"r":0,"d":0,"h":51540120450,"f":32769},"n":"DeclaringType","d":512898,"h":47245153154,"f":32769},{"p":655361,"g":{"r":0,"d":0,"h":77309924226,"f":32769},"n":"MetadataToken","d":512898,"h":73014956930,"f":32769},{"p":80216065,"g":{"r":0,"d":0,"h":85899858818,"f":32769},"n":"Module","d":512898,"h":81604891522,"f":32769},{"p":1310721,"g":{"r":0,"d":0,"h":94489793410,"f":32769},"n":"Name","d":512898,"h":90194826114,"f":32769},{"p":142606337,"g":{"r":0,"d":0,"h":103079728002,"f":32769},"n":"ReflectedType","d":512898,"h":98784760706,"f":32769}],"m":[{"r":65537,"p":[{"n":"target","p":131073},{"n":"handler","p":35651585}],"n":"AddEventHandler","d":512898,"h":12885414786,"f":32769,"a":[{"t":114950145,"c":4409917441,"a":[{"v":"windows","t":1310721}]}]},{"r":65537,"p":[{"n":"target","p":131073},{"n":"handler","p":35651585}],"n":"RemoveEventHandler","d":512898,"h":17180382082,"f":32769,"a":[{"t":114950145,"c":4409917441,"a":[{"v":"windows","t":1310721}]}]},{"r":79626241,"p":[{"n":"nonPublic","p":262145}],"n":"GetAddMethod","o":"@$1","d":512898,"h":30065283970,"f":32769},{"r":0,"p":[{"n":"nonPublic","p":262145}],"n":"GetOtherMethods","o":"@$1","d":512898,"h":34360251266,"f":32769},{"r":79626241,"p":[{"n":"nonPublic","p":262145}],"n":"GetRaiseMethod","o":"@$1","d":512898,"h":38655218562,"f":32769},{"r":79626241,"p":[{"n":"nonPublic","p":262145}],"n":"GetRemoveMethod","o":"@$1","d":512898,"h":42950185858,"f":32769},{"r":0,"p":[{"n":"attributeType","p":142606337},{"n":"inherit","p":262145}],"n":"GetCustomAttributes","o":"@$1","d":512898,"h":55835087746,"f":32769},{"r":0,"p":[{"n":"inherit","p":262145}],"n":"GetCustomAttributes","d":512898,"h":60130055042,"f":32769},{"r":$.$spc.System.Collections.Generic.IList$$($.$spc.System.Reflection.CustomAttributeData).$h,"n":"GetCustomAttributesData","d":512898,"h":64425022338,"f":32769},{"r":262145,"p":[{"n":"attributeType","p":142606337},{"n":"inherit","p":262145}],"n":"IsDefined","d":512898,"h":68719989634,"f":32769},{"r":65537,"p":[{"n":"eventInfo","p":76414977},{"n":"sourceIid","p":56164353,"f":2},{"n":"dispid","p":655361,"f":2}],"n":"GetDataForComInvocation","d":512898,"h":107374695298,"f":34}],"l":[{"t":76414977,"n":"_innerEventInfo","d":512898,"h":4295480194,"f":2}],"c":[{"p":[{"n":"type","p":142606337},{"n":"eventName","p":1310721}],"n":".ctor","o":"$ctor$4","d":512898,"h":8590447490,"f":1}],"i":[76939265],"h":512898,"a":[{"t":33161217,"c":4328128513,"a":[{"v":1,"t":33226753}]}]}; }
            static get $b() { return $.$spc.System.Reflection.EventInfo; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.Reflection.ICustomAttributeProvider ]; }
            static get $fullName() { return `System.Runtime.InteropServices.ComAwareEventInfo`; }
        });
        
        $asm.$str("$sris.System.Runtime.InteropServices.ComTypes.DVASPECT", ($self) => class DVASPECT extends $.$spc.System.Enum
        {
            static DVASPECT_CONTENT = 1;
            static DVASPECT_THUMBNAIL = 2;
            static DVASPECT_ICON = 4;
            static DVASPECT_DOCPRINT = 8;
            static $map;
            static get Map()
            {
                return this.$map ??= 
                {
                    "DVASPECT_CONTENT": 1n,
                    "DVASPECT_THUMBNAIL": 2n,
                    "DVASPECT_ICON": 4n,
                    "DVASPECT_DOCPRINT": 8n
                };
            }
            static $h = 906114;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static get $eut() { return $.$spc.System.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {"b":1048577,"u":655361,"l":[{"t":906114,"n":"DVASPECT_CONTENT","d":906114,"h":4295873410,"f":33},{"t":906114,"n":"DVASPECT_THUMBNAIL","d":906114,"h":8590840706,"f":33},{"t":906114,"n":"DVASPECT_ICON","d":906114,"h":12885808002,"f":33},{"t":906114,"n":"DVASPECT_DOCPRINT","d":906114,"h":17180775298,"f":33}],"c":[{"n":".ctor","o":"$ctor$3","d":906114,"h":21475742594,"f":1}],"i":[57212929,63766529,57671681,57344001],"h":906114,"a":[{"t":33161217,"c":4328128513,"a":[{"v":1,"t":33226753}]},{"t":47644673,"c":4342611969}]}; }
            static get $b() { return $.$spc.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IComparable, $.$spc.System.ISpanFormattable, $.$spc.System.IFormattable, $.$spc.System.IConvertible ]; }
            static get $fullName() { return `System.Runtime.InteropServices.ComTypes.DVASPECT`; }
        });
        
        $asm.$str("$sris.System.Runtime.InteropServices.ComTypes.DATADIR", ($self) => class DATADIR extends $.$spc.System.Enum
        {
            static DATADIR_GET = 1;
            static DATADIR_SET = 2;
            static $map;
            static get Map()
            {
                return this.$map ??= 
                {
                    "DATADIR_GET": 1n,
                    "DATADIR_SET": 2n
                };
            }
            static $h = 840578;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static get $eut() { return $.$spc.System.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {"b":1048577,"u":655361,"l":[{"t":840578,"n":"DATADIR_GET","d":840578,"h":4295807874,"f":33},{"t":840578,"n":"DATADIR_SET","d":840578,"h":8590775170,"f":33}],"c":[{"n":".ctor","o":"$ctor$3","d":840578,"h":12885742466,"f":1}],"i":[57212929,63766529,57671681,57344001],"h":840578,"a":[{"t":33161217,"c":4328128513,"a":[{"v":1,"t":33226753}]}]}; }
            static get $b() { return $.$spc.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IComparable, $.$spc.System.ISpanFormattable, $.$spc.System.IFormattable, $.$spc.System.IConvertible ]; }
            static get $fullName() { return `System.Runtime.InteropServices.ComTypes.DATADIR`; }
        });
        
        $asm.$str("$sris.System.Runtime.InteropServices.ComTypes.ADVF", ($self) => class ADVF extends $.$spc.System.Enum
        {
            static ADVF_NODATA = 1;
            static ADVF_PRIMEFIRST = 2;
            static ADVF_ONLYONCE = 4;
            static ADVF_DATAONSTOP = 64;
            static ADVFCACHE_NOHANDLER = 8;
            static ADVFCACHE_FORCEBUILTIN = 16;
            static ADVFCACHE_ONSAVE = 32;
            static $map;
            static get Map()
            {
                return this.$map ??= 
                {
                    "ADVF_NODATA": 1n,
                    "ADVF_PRIMEFIRST": 2n,
                    "ADVF_ONLYONCE": 4n,
                    "ADVF_DATAONSTOP": 64n,
                    "ADVFCACHE_NOHANDLER": 8n,
                    "ADVFCACHE_FORCEBUILTIN": 16n,
                    "ADVFCACHE_ONSAVE": 32n
                };
            }
            static $h = 775042;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static get $eut() { return $.$spc.System.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {"b":1048577,"u":655361,"l":[{"t":775042,"n":"ADVF_NODATA","d":775042,"h":4295742338,"f":33},{"t":775042,"n":"ADVF_PRIMEFIRST","d":775042,"h":8590709634,"f":33},{"t":775042,"n":"ADVF_ONLYONCE","d":775042,"h":12885676930,"f":33},{"t":775042,"n":"ADVF_DATAONSTOP","d":775042,"h":17180644226,"f":33},{"t":775042,"n":"ADVFCACHE_NOHANDLER","d":775042,"h":21475611522,"f":33},{"t":775042,"n":"ADVFCACHE_FORCEBUILTIN","d":775042,"h":25770578818,"f":33},{"t":775042,"n":"ADVFCACHE_ONSAVE","d":775042,"h":30065546114,"f":33}],"c":[{"n":".ctor","o":"$ctor$3","d":775042,"h":34360513410,"f":1}],"i":[57212929,63766529,57671681,57344001],"h":775042,"a":[{"t":33161217,"c":4328128513,"a":[{"v":1,"t":33226753}]},{"t":47644673,"c":4342611969}]}; }
            static get $b() { return $.$spc.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IComparable, $.$spc.System.ISpanFormattable, $.$spc.System.IFormattable, $.$spc.System.IConvertible ]; }
            static get $fullName() { return `System.Runtime.InteropServices.ComTypes.ADVF`; }
        });
        
        $asm.$str("$sris.System.Runtime.InteropServices.AssemblyRegistrationFlags", ($self) => class AssemblyRegistrationFlags extends $.$spc.System.Enum
        {
            static None = 0;
            static SetCodeBase = 1;
            static $map;
            static get Map()
            {
                return this.$map ??= 
                {
                    "None": 0n,
                    "SetCodeBase": 1n
                };
            }
            static $h = 316290;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static get $eut() { return $.$spc.System.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {"b":1048577,"u":655361,"l":[{"t":316290,"n":"None","d":316290,"h":4295283586,"f":33},{"t":316290,"n":"SetCodeBase","d":316290,"h":8590250882,"f":33}],"c":[{"n":".ctor","o":"$ctor$3","d":316290,"h":12885218178,"f":1}],"i":[57212929,63766529,57671681,57344001],"h":316290,"a":[{"t":47644673,"c":4342611969}]}; }
            static get $b() { return $.$spc.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IComparable, $.$spc.System.ISpanFormattable, $.$spc.System.IFormattable, $.$spc.System.IConvertible ]; }
            static get $fullName() { return `System.Runtime.InteropServices.AssemblyRegistrationFlags`; }
        });
        
        $asm.$str("$sris.System.Runtime.InteropServices.ComTypes.TYMED", ($self) => class TYMED extends $.$spc.System.Enum
        {
            static TYMED_HGLOBAL = 1;
            static TYMED_FILE = 2;
            static TYMED_ISTREAM = 4;
            static TYMED_ISTORAGE = 8;
            static TYMED_GDI = 16;
            static TYMED_MFPICT = 32;
            static TYMED_ENHMF = 64;
            static TYMED_NULL = 0;
            static $map;
            static get Map()
            {
                return this.$map ??= 
                {
                    "TYMED_HGLOBAL": 1n,
                    "TYMED_FILE": 2n,
                    "TYMED_ISTREAM": 4n,
                    "TYMED_ISTORAGE": 8n,
                    "TYMED_GDI": 16n,
                    "TYMED_MFPICT": 32n,
                    "TYMED_ENHMF": 64n,
                    "TYMED_NULL": 0n
                };
            }
            static $h = 1430402;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static get $eut() { return $.$spc.System.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {"b":1048577,"u":655361,"l":[{"t":1430402,"n":"TYMED_HGLOBAL","d":1430402,"h":4296397698,"f":33},{"t":1430402,"n":"TYMED_FILE","d":1430402,"h":8591364994,"f":33},{"t":1430402,"n":"TYMED_ISTREAM","d":1430402,"h":12886332290,"f":33},{"t":1430402,"n":"TYMED_ISTORAGE","d":1430402,"h":17181299586,"f":33},{"t":1430402,"n":"TYMED_GDI","d":1430402,"h":21476266882,"f":33},{"t":1430402,"n":"TYMED_MFPICT","d":1430402,"h":25771234178,"f":33},{"t":1430402,"n":"TYMED_ENHMF","d":1430402,"h":30066201474,"f":33},{"t":1430402,"n":"TYMED_NULL","d":1430402,"h":34361168770,"f":33}],"c":[{"n":".ctor","o":"$ctor$3","d":1430402,"h":38656136066,"f":1}],"i":[57212929,63766529,57671681,57344001],"h":1430402,"a":[{"t":33161217,"c":4328128513,"a":[{"v":1,"t":33226753}]},{"t":47644673,"c":4342611969}]}; }
            static get $b() { return $.$spc.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IComparable, $.$spc.System.ISpanFormattable, $.$spc.System.IFormattable, $.$spc.System.IConvertible ]; }
            static get $fullName() { return `System.Runtime.InteropServices.ComTypes.TYMED`; }
        });
        
        $asm.$str("$sris.System.Runtime.InteropServices.ExporterEventKind", ($self) => class ExporterEventKind extends $.$spc.System.Enum
        {
            static NOTIF_TYPECONVERTED = 0;
            static NOTIF_CONVERTWARNING = 1;
            static ERROR_REFTOINVALIDASSEMBLY = 2;
            static $map;
            static get Map()
            {
                return this.$map ??= 
                {
                    "NOTIF_TYPECONVERTED": 0n,
                    "NOTIF_CONVERTWARNING": 1n,
                    "ERROR_REFTOINVALIDASSEMBLY": 2n
                };
            }
            static $h = 1561474;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static get $eut() { return $.$spc.System.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {"b":1048577,"u":655361,"l":[{"t":1561474,"n":"NOTIF_TYPECONVERTED","d":1561474,"h":4296528770,"f":33},{"t":1561474,"n":"NOTIF_CONVERTWARNING","d":1561474,"h":8591496066,"f":33},{"t":1561474,"n":"ERROR_REFTOINVALIDASSEMBLY","d":1561474,"h":12886463362,"f":33}],"c":[{"n":".ctor","o":"$ctor$3","d":1561474,"h":17181430658,"f":1}],"i":[57212929,63766529,57671681,57344001],"h":1561474}; }
            static get $b() { return $.$spc.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IComparable, $.$spc.System.ISpanFormattable, $.$spc.System.IFormattable, $.$spc.System.IConvertible ]; }
            static get $fullName() { return `System.Runtime.InteropServices.ExporterEventKind`; }
        });
        
        $asm.$str("$sris.System.Runtime.InteropServices.Marshalling.ComInterfaceOptions", ($self) => class ComInterfaceOptions extends $.$spc.System.Enum
        {
            static None = 0;
            static ManagedObjectWrapper = 1;
            static ComObjectWrapper = 2;
            static $map;
            static get Map()
            {
                return this.$map ??= 
                {
                    "None": 0n,
                    "ManagedObjectWrapper": 1n,
                    "ComObjectWrapper": 2n
                };
            }
            static $h = 2151298;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static get $eut() { return $.$spc.System.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {"b":1048577,"u":655361,"l":[{"t":2151298,"n":"None","d":2151298,"h":4297118594,"f":33,"a":[{"t":33161217,"c":4328128513,"a":[{"v":1,"t":33226753}]}]},{"t":2151298,"n":"ManagedObjectWrapper","d":2151298,"h":8592085890,"f":33},{"t":2151298,"n":"ComObjectWrapper","d":2151298,"h":12887053186,"f":33}],"c":[{"n":".ctor","o":"$ctor$3","d":2151298,"h":17182020482,"f":1}],"i":[57212929,63766529,57671681,57344001],"h":2151298,"a":[{"t":47644673,"c":4342611969}]}; }
            static get $b() { return $.$spc.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IComparable, $.$spc.System.ISpanFormattable, $.$spc.System.IFormattable, $.$spc.System.IConvertible ]; }
            static get $fullName() { return `System.Runtime.InteropServices.Marshalling.ComInterfaceOptions`; }
        });
        
        $asm.$str("$sris.System.Runtime.InteropServices.RegistrationClassContext", ($self) => class RegistrationClassContext extends $.$spc.System.Enum
        {
            static InProcessServer = 1;
            static InProcessHandler = 2;
            static LocalServer = 4;
            static InProcessServer16 = 8;
            static RemoteServer = 16;
            static InProcessHandler16 = 32;
            static Reserved1 = 64;
            static Reserved2 = 128;
            static Reserved3 = 256;
            static Reserved4 = 512;
            static NoCodeDownload = 1024;
            static Reserved5 = 2048;
            static NoCustomMarshal = 4096;
            static EnableCodeDownload = 8192;
            static NoFailureLog = 16384;
            static DisableActivateAsActivator = 32768;
            static EnableActivateAsActivator = 65536;
            static FromDefaultContext = 131072;
            static $map;
            static get Map()
            {
                return this.$map ??= 
                {
                    "InProcessServer": 1n,
                    "InProcessHandler": 2n,
                    "LocalServer": 4n,
                    "InProcessServer16": 8n,
                    "RemoteServer": 16n,
                    "InProcessHandler16": 32n,
                    "Reserved1": 64n,
                    "Reserved2": 128n,
                    "Reserved3": 256n,
                    "Reserved4": 512n,
                    "NoCodeDownload": 1024n,
                    "Reserved5": 2048n,
                    "NoCustomMarshal": 4096n,
                    "EnableCodeDownload": 8192n,
                    "NoFailureLog": 16384n,
                    "DisableActivateAsActivator": 32768n,
                    "EnableActivateAsActivator": 65536n,
                    "FromDefaultContext": 131072n
                };
            }
            static $h = 3920770;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static get $eut() { return $.$spc.System.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {"b":1048577,"u":655361,"l":[{"t":3920770,"n":"InProcessServer","d":3920770,"h":4298888066,"f":33},{"t":3920770,"n":"InProcessHandler","d":3920770,"h":8593855362,"f":33},{"t":3920770,"n":"LocalServer","d":3920770,"h":12888822658,"f":33},{"t":3920770,"n":"InProcessServer16","d":3920770,"h":17183789954,"f":33},{"t":3920770,"n":"RemoteServer","d":3920770,"h":21478757250,"f":33},{"t":3920770,"n":"InProcessHandler16","d":3920770,"h":25773724546,"f":33},{"t":3920770,"n":"Reserved1","d":3920770,"h":30068691842,"f":33},{"t":3920770,"n":"Reserved2","d":3920770,"h":34363659138,"f":33},{"t":3920770,"n":"Reserved3","d":3920770,"h":38658626434,"f":33},{"t":3920770,"n":"Reserved4","d":3920770,"h":42953593730,"f":33},{"t":3920770,"n":"NoCodeDownload","d":3920770,"h":47248561026,"f":33},{"t":3920770,"n":"Reserved5","d":3920770,"h":51543528322,"f":33},{"t":3920770,"n":"NoCustomMarshal","d":3920770,"h":55838495618,"f":33},{"t":3920770,"n":"EnableCodeDownload","d":3920770,"h":60133462914,"f":33},{"t":3920770,"n":"NoFailureLog","d":3920770,"h":64428430210,"f":33},{"t":3920770,"n":"DisableActivateAsActivator","d":3920770,"h":68723397506,"f":33},{"t":3920770,"n":"EnableActivateAsActivator","d":3920770,"h":73018364802,"f":33},{"t":3920770,"n":"FromDefaultContext","d":3920770,"h":77313332098,"f":33}],"c":[{"n":".ctor","o":"$ctor$3","d":3920770,"h":81608299394,"f":1}],"i":[57212929,63766529,57671681,57344001],"h":3920770,"a":[{"t":47644673,"c":4342611969}]}; }
            static get $b() { return $.$spc.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IComparable, $.$spc.System.ISpanFormattable, $.$spc.System.IFormattable, $.$spc.System.IConvertible ]; }
            static get $fullName() { return `System.Runtime.InteropServices.RegistrationClassContext`; }
        });
        
        $asm.$str("$sris.System.Runtime.InteropServices.RegistrationConnectionType", ($self) => class RegistrationConnectionType extends $.$spc.System.Enum
        {
            static SingleUse = 0;
            static MultipleUse = 1;
            static MultiSeparate = 2;
            static Suspended = 4;
            static Surrogate = 8;
            static $map;
            static get Map()
            {
                return this.$map ??= 
                {
                    "SingleUse": 0n,
                    "MultipleUse": 1n,
                    "MultiSeparate": 2n,
                    "Suspended": 4n,
                    "Surrogate": 8n
                };
            }
            static $h = 3986306;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static get $eut() { return $.$spc.System.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {"b":1048577,"u":655361,"l":[{"t":3986306,"n":"SingleUse","d":3986306,"h":4298953602,"f":33},{"t":3986306,"n":"MultipleUse","d":3986306,"h":8593920898,"f":33},{"t":3986306,"n":"MultiSeparate","d":3986306,"h":12888888194,"f":33},{"t":3986306,"n":"Suspended","d":3986306,"h":17183855490,"f":33},{"t":3986306,"n":"Surrogate","d":3986306,"h":21478822786,"f":33}],"c":[{"n":".ctor","o":"$ctor$3","d":3986306,"h":25773790082,"f":1}],"i":[57212929,63766529,57671681,57344001],"h":3986306,"a":[{"t":47644673,"c":4342611969}]}; }
            static get $b() { return $.$spc.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IComparable, $.$spc.System.ISpanFormattable, $.$spc.System.IFormattable, $.$spc.System.IConvertible ]; }
            static get $fullName() { return `System.Runtime.InteropServices.RegistrationConnectionType`; }
        });
        
        $asm.$str("$sris.System.Runtime.InteropServices.TypeLibTypeFlags", ($self) => class TypeLibTypeFlags extends $.$spc.System.Enum
        {
            static FAppObject = 1;
            static FCanCreate = 2;
            static FLicensed = 4;
            static FPreDeclId = 8;
            static FHidden = 16;
            static FControl = 32;
            static FDual = 64;
            static FNonExtensible = 128;
            static FOleAutomation = 256;
            static FRestricted = 512;
            static FAggregatable = 1024;
            static FReplaceable = 2048;
            static FDispatchable = 4096;
            static FReverseBind = 8192;
            static $map;
            static get Map()
            {
                return this.$map ??= 
                {
                    "FAppObject": 1n,
                    "FCanCreate": 2n,
                    "FLicensed": 4n,
                    "FPreDeclId": 8n,
                    "FHidden": 16n,
                    "FControl": 32n,
                    "FDual": 64n,
                    "FNonExtensible": 128n,
                    "FOleAutomation": 256n,
                    "FRestricted": 512n,
                    "FAggregatable": 1024n,
                    "FReplaceable": 2048n,
                    "FDispatchable": 4096n,
                    "FReverseBind": 8192n
                };
            }
            static $h = 4379522;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static get $eut() { return $.$spc.System.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {"b":1048577,"u":655361,"l":[{"t":4379522,"n":"FAppObject","d":4379522,"h":4299346818,"f":33},{"t":4379522,"n":"FCanCreate","d":4379522,"h":8594314114,"f":33},{"t":4379522,"n":"FLicensed","d":4379522,"h":12889281410,"f":33},{"t":4379522,"n":"FPreDeclId","d":4379522,"h":17184248706,"f":33},{"t":4379522,"n":"FHidden","d":4379522,"h":21479216002,"f":33},{"t":4379522,"n":"FControl","d":4379522,"h":25774183298,"f":33},{"t":4379522,"n":"FDual","d":4379522,"h":30069150594,"f":33},{"t":4379522,"n":"FNonExtensible","d":4379522,"h":34364117890,"f":33},{"t":4379522,"n":"FOleAutomation","d":4379522,"h":38659085186,"f":33},{"t":4379522,"n":"FRestricted","d":4379522,"h":42954052482,"f":33},{"t":4379522,"n":"FAggregatable","d":4379522,"h":47249019778,"f":33},{"t":4379522,"n":"FReplaceable","d":4379522,"h":51543987074,"f":33},{"t":4379522,"n":"FDispatchable","d":4379522,"h":55838954370,"f":33},{"t":4379522,"n":"FReverseBind","d":4379522,"h":60133921666,"f":33}],"c":[{"n":".ctor","o":"$ctor$3","d":4379522,"h":64428888962,"f":1}],"i":[57212929,63766529,57671681,57344001],"h":4379522,"a":[{"t":47644673,"c":4342611969}]}; }
            static get $b() { return $.$spc.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IComparable, $.$spc.System.ISpanFormattable, $.$spc.System.IFormattable, $.$spc.System.IConvertible ]; }
            static get $fullName() { return `System.Runtime.InteropServices.TypeLibTypeFlags`; }
        });
        
        $asm.$str("$sris.System.Runtime.InteropServices.TypeLibVarFlags", ($self) => class TypeLibVarFlags extends $.$spc.System.Enum
        {
            static FReadOnly = 1;
            static FSource = 2;
            static FBindable = 4;
            static FRequestEdit = 8;
            static FDisplayBind = 16;
            static FDefaultBind = 32;
            static FHidden = 64;
            static FRestricted = 128;
            static FDefaultCollelem = 256;
            static FUiDefault = 512;
            static FNonBrowsable = 1024;
            static FReplaceable = 2048;
            static FImmediateBind = 4096;
            static $map;
            static get Map()
            {
                return this.$map ??= 
                {
                    "FReadOnly": 1n,
                    "FSource": 2n,
                    "FBindable": 4n,
                    "FRequestEdit": 8n,
                    "FDisplayBind": 16n,
                    "FDefaultBind": 32n,
                    "FHidden": 64n,
                    "FRestricted": 128n,
                    "FDefaultCollelem": 256n,
                    "FUiDefault": 512n,
                    "FNonBrowsable": 1024n,
                    "FReplaceable": 2048n,
                    "FImmediateBind": 4096n
                };
            }
            static $h = 4510594;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static get $eut() { return $.$spc.System.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {"b":1048577,"u":655361,"l":[{"t":4510594,"n":"FReadOnly","d":4510594,"h":4299477890,"f":33},{"t":4510594,"n":"FSource","d":4510594,"h":8594445186,"f":33},{"t":4510594,"n":"FBindable","d":4510594,"h":12889412482,"f":33},{"t":4510594,"n":"FRequestEdit","d":4510594,"h":17184379778,"f":33},{"t":4510594,"n":"FDisplayBind","d":4510594,"h":21479347074,"f":33},{"t":4510594,"n":"FDefaultBind","d":4510594,"h":25774314370,"f":33},{"t":4510594,"n":"FHidden","d":4510594,"h":30069281666,"f":33},{"t":4510594,"n":"FRestricted","d":4510594,"h":34364248962,"f":33},{"t":4510594,"n":"FDefaultCollelem","d":4510594,"h":38659216258,"f":33},{"t":4510594,"n":"FUiDefault","d":4510594,"h":42954183554,"f":33},{"t":4510594,"n":"FNonBrowsable","d":4510594,"h":47249150850,"f":33},{"t":4510594,"n":"FReplaceable","d":4510594,"h":51544118146,"f":33},{"t":4510594,"n":"FImmediateBind","d":4510594,"h":55839085442,"f":33}],"c":[{"n":".ctor","o":"$ctor$3","d":4510594,"h":60134052738,"f":1}],"i":[57212929,63766529,57671681,57344001],"h":4510594,"a":[{"t":47644673,"c":4342611969}]}; }
            static get $b() { return $.$spc.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IComparable, $.$spc.System.ISpanFormattable, $.$spc.System.IFormattable, $.$spc.System.IConvertible ]; }
            static get $fullName() { return `System.Runtime.InteropServices.TypeLibVarFlags`; }
        });
        
        $asm.$str("$sris.System.Runtime.InteropServices.TypeLibFuncFlags", ($self) => class TypeLibFuncFlags extends $.$spc.System.Enum
        {
            static FRestricted = 1;
            static FSource = 2;
            static FBindable = 4;
            static FRequestEdit = 8;
            static FDisplayBind = 16;
            static FDefaultBind = 32;
            static FHidden = 64;
            static FUsesGetLastError = 128;
            static FDefaultCollelem = 256;
            static FUiDefault = 512;
            static FNonBrowsable = 1024;
            static FReplaceable = 2048;
            static FImmediateBind = 4096;
            static $map;
            static get Map()
            {
                return this.$map ??= 
                {
                    "FRestricted": 1n,
                    "FSource": 2n,
                    "FBindable": 4n,
                    "FRequestEdit": 8n,
                    "FDisplayBind": 16n,
                    "FDefaultBind": 32n,
                    "FHidden": 64n,
                    "FUsesGetLastError": 128n,
                    "FDefaultCollelem": 256n,
                    "FUiDefault": 512n,
                    "FNonBrowsable": 1024n,
                    "FReplaceable": 2048n,
                    "FImmediateBind": 4096n
                };
            }
            static $h = 4182914;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static get $eut() { return $.$spc.System.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {"b":1048577,"u":655361,"l":[{"t":4182914,"n":"FRestricted","d":4182914,"h":4299150210,"f":33},{"t":4182914,"n":"FSource","d":4182914,"h":8594117506,"f":33},{"t":4182914,"n":"FBindable","d":4182914,"h":12889084802,"f":33},{"t":4182914,"n":"FRequestEdit","d":4182914,"h":17184052098,"f":33},{"t":4182914,"n":"FDisplayBind","d":4182914,"h":21479019394,"f":33},{"t":4182914,"n":"FDefaultBind","d":4182914,"h":25773986690,"f":33},{"t":4182914,"n":"FHidden","d":4182914,"h":30068953986,"f":33},{"t":4182914,"n":"FUsesGetLastError","d":4182914,"h":34363921282,"f":33},{"t":4182914,"n":"FDefaultCollelem","d":4182914,"h":38658888578,"f":33},{"t":4182914,"n":"FUiDefault","d":4182914,"h":42953855874,"f":33},{"t":4182914,"n":"FNonBrowsable","d":4182914,"h":47248823170,"f":33},{"t":4182914,"n":"FReplaceable","d":4182914,"h":51543790466,"f":33},{"t":4182914,"n":"FImmediateBind","d":4182914,"h":55838757762,"f":33}],"c":[{"n":".ctor","o":"$ctor$3","d":4182914,"h":60133725058,"f":1}],"i":[57212929,63766529,57671681,57344001],"h":4182914,"a":[{"t":47644673,"c":4342611969}]}; }
            static get $b() { return $.$spc.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IComparable, $.$spc.System.ISpanFormattable, $.$spc.System.IFormattable, $.$spc.System.IConvertible ]; }
            static get $fullName() { return `System.Runtime.InteropServices.TypeLibFuncFlags`; }
        });
        
        $asm.$cls("$sris.System.Runtime.InteropServices.Marshalling.ComObject", ($self) => class ComObject extends $.$spc.System.Object
        {
            /*bool*/ static BuiltInComSupported = false;
            /*bool*/ static ComImportInteropEnabled = false;
            /*void**/ _instancePointer;
            /*object?*/ _runtimeCallableWrapper = null;
            /*bool*/ _released = false;
            $ctor$1(/*IIUnknownInterfaceDetailsStrategy*/ interfaceDetailsStrategy, /*IIUnknownStrategy*/ iunknownStrategy, /*IIUnknownCacheStrategy*/ cacheStrategy, /*void**/ thisPointer)
            {
                super.$ctor();
                {
                    this.InterfaceDetailsStrategy = interfaceDetailsStrategy;
                    this.IUnknownStrategy = iunknownStrategy;
                    this.CacheStrategy = cacheStrategy;
                    this._instancePointer = this.IUnknownStrategy.System$Runtime$InteropServices$Marshalling$IIUnknownStrategy$CreateInstancePointer(thisPointer);
                    if ($.$spc.System.OperatingSystem.IsWindows() && $.$sris.System.Runtime.InteropServices.Marshalling.ComObject.BuiltInComSupported && $.$sris.System.Runtime.InteropServices.Marshalling.ComObject.ComImportInteropEnabled)
                    {
                        this._runtimeCallableWrapper = $.$spc.System.Runtime.InteropServices.Marshal.GetObjectForIUnknown($.$spc.System.IntPtr.op_Explicit$2(thisPointer));
                        $.$spc.System.Diagnostics.Debug.Assert$1($.$spc.System.Runtime.InteropServices.Marshal.IsComObject(this._runtimeCallableWrapper), "Marshal.IsComObject(_runtimeCallableWrapper)");
                    }
                }
                return this;
            }
            $dtor()
            {
                this.CacheStrategy.System$Runtime$InteropServices$Marshalling$IIUnknownCacheStrategy$Clear(this.IUnknownStrategy);
                this.IUnknownStrategy.System$Runtime$InteropServices$Marshalling$IIUnknownStrategy$Release(this._instancePointer);
            }
            /*IIUnknownInterfaceDetailsStrategy*/ InterfaceDetailsStrategy = null;
            /*IIUnknownStrategy*/ IUnknownStrategy = null;
            /*IIUnknownCacheStrategy*/ CacheStrategy = null;
            /*bool*/ UniqueInstance = false;
            /*void */ FinalRelease()
            {
                if (this.UniqueInstance && !$.$spc.System.Threading.Interlocked.Exchange$14($.$spc.System.Boolean, $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateObjectReferenceT($.$spc.System.Boolean, () => this._released, ($v) => this._released = $v, null), true))
                {
                    $.$spc.System.GC.SuppressFinalize(this);
                    this.CacheStrategy.System$Runtime$InteropServices$Marshalling$IIUnknownCacheStrategy$Clear(this.IUnknownStrategy);
                    this.IUnknownStrategy.System$Runtime$InteropServices$Marshalling$IIUnknownStrategy$Release(this._instancePointer);
                }
            }
            /*RuntimeTypeHandle */ System$Runtime$InteropServices$IDynamicInterfaceCastable$GetInterfaceImplementation(/*RuntimeTypeHandle*/ interfaceType)
            {
                /*IIUnknownCacheStrategy.TableInfo*/ let info;
                /*int*/ let qiResult;
                if (!this.LookUpVTableInfo(interfaceType, $.$ref(() => info, ($v) => info = $v, $.$sris.System.Runtime.InteropServices.Marshalling.IIUnknownCacheStrategy.TableInfo), $.$ref(() => qiResult, ($v) => qiResult = $v, $.$spc.System.Int32)))
                {
                    $.$spc.System.Runtime.InteropServices.Marshal.ThrowExceptionForHR(qiResult);
                }
                return info.ManagedType;
            }
            /*bool */ System$Runtime$InteropServices$IDynamicInterfaceCastable$IsInterfaceImplemented(/*RuntimeTypeHandle*/ interfaceType, /*bool*/ throwIfNotImplemented)
            {
                /*int*/ let qiResult;
                if (!this.LookUpVTableInfo(interfaceType, $.$discardRef(), $.$ref(() => qiResult, ($v) => qiResult = $v, $.$spc.System.Int32)))
                {
                    if (throwIfNotImplemented)
                    {
                        $.$spc.System.Runtime.InteropServices.Marshal.ThrowExceptionForHR(qiResult);
                    }
                    return false;
                }
                return true;
            }
            /*bool */ LookUpVTableInfo(/*RuntimeTypeHandle*/ handle, /*out IIUnknownCacheStrategy.TableInfo*/ result, /*out int*/ qiHResult)
            {
                $.$spc.System.ObjectDisposedException.ThrowIf(this._released, this);
                qiHResult.$v = 0;
                if (!this.CacheStrategy.System$Runtime$InteropServices$Marshalling$IIUnknownCacheStrategy$TryGetTableInfo(handle, result))
                {
                    /*IIUnknownDerivedDetails?*/ let details = this.InterfaceDetailsStrategy.System$Runtime$InteropServices$Marshalling$IIUnknownInterfaceDetailsStrategy$GetIUnknownDerivedDetails(handle);
                    if (details === null)
                    {
                        return false;
                    }
                    /*void**/ let ppv;
                    /*int*/ let hr = this.IUnknownStrategy.System$Runtime$InteropServices$Marshalling$IIUnknownStrategy$QueryInterface(this._instancePointer, $.$ref(() => details.System$Runtime$InteropServices$Marshalling$IIUnknownDerivedDetails$Iid, ), $.$ref(() => ppv, ($v) => ppv = $v, $.$typePointer($.$spc.System.Void)));
                    if (hr < 0)
                    {
                        qiHResult.$v = hr;
                        return false;
                    }
                    result.$v = this.CacheStrategy.System$Runtime$InteropServices$Marshalling$IIUnknownCacheStrategy$ConstructTableInfo(handle, details, ppv);
                    if (!this.CacheStrategy.System$Runtime$InteropServices$Marshalling$IIUnknownCacheStrategy$TrySetTableInfo(handle, result.$v))
                    {
                        /*bool*/ let found = this.CacheStrategy.System$Runtime$InteropServices$Marshalling$IIUnknownCacheStrategy$TryGetTableInfo(handle, result);
                        $.$spc.System.Diagnostics.Debug.Assert$1(found, "found");
                        _ = this.IUnknownStrategy.System$Runtime$InteropServices$Marshalling$IIUnknownStrategy$Release(ppv);
                    }
                }
                return true;
            }
            /*VirtualMethodTableInfo */ System$Runtime$InteropServices$Marshalling$IUnmanagedVirtualMethodTableProvider$GetVirtualMethodTableInfoForKey(/*Type*/ type)
            {
                /*IIUnknownCacheStrategy.TableInfo*/ let result;
                /*int*/ let qiHResult;
                if (!this.LookUpVTableInfo(type.TypeHandle, $.$ref(() => result, ($v) => result = $v, $.$sris.System.Runtime.InteropServices.Marshalling.IIUnknownCacheStrategy.TableInfo), $.$ref(() => qiHResult, ($v) => qiHResult = $v, $.$spc.System.Int32)))
                {
                    $.$spc.System.Runtime.InteropServices.Marshal.ThrowExceptionForHR(qiHResult);
                }
                return new $.$sris.System.Runtime.InteropServices.Marshalling.VirtualMethodTableInfo().$ctor$2(result.ThisPtr, result.Table);
            }
            /*object */ System$Runtime$InteropServices$Marshalling$ComImportInteropInterfaceDetailsStrategy$IComImportAdapter$GetRuntimeCallableWrapper()
            {
                $.$spc.System.Diagnostics.Debug.Assert$1(this._runtimeCallableWrapper !== null, "_runtimeCallableWrapper != null");
                return this._runtimeCallableWrapper;
            }
            //default member initializer
            constructor()
            {
                super();
                this._instancePointer = $.$default($.$typePointer($.$spc.System.Void));
                this.UniqueInstance = false;
                $.$finalizer(this);
            }
            //Static Initializer
            static $sinit()
            {
                {
                    /*bool*/ let supported;
                    this.BuiltInComSupported = $.$spc.System.AppContext.TryGetSwitch("System.Runtime.InteropServices.BuiltInComInterop.IsSupported", $.$ref(() => supported, ($v) => supported = $v, $.$spc.System.Boolean)) ? supported : true;
                }
                {
                    /*bool*/ let enabled;
                    this.ComImportInteropEnabled = $.$spc.System.AppContext.TryGetSwitch("System.Runtime.InteropServices.Marshalling.EnableGeneratedComInterfaceComImportInterop", $.$ref(() => enabled, ($v) => enabled = $v, $.$spc.System.Boolean)) ? enabled : false;
                }
            }
            static $h = 2216834;
            static $f = 0b10010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":262145,"g":{"r":0,"d":0,"h":12887118722,"f":40},"n":"BuiltInComSupported","d":2216834,"h":8592151426,"f":40},{"p":262145,"g":{"r":0,"d":0,"h":25772020610,"f":40},"n":"ComImportInteropEnabled","d":2216834,"h":21477053314,"f":40},{"p":3330946,"g":{"r":0,"d":0,"h":60131758978,"f":2},"n":"InterfaceDetailsStrategy","d":2216834,"h":55836791682,"f":2},{"p":3462018,"g":{"r":0,"d":0,"h":73016660866,"f":2},"n":"IUnknownStrategy","d":2216834,"h":68721693570,"f":2},{"p":3134338,"g":{"r":0,"d":0,"h":85901562754,"f":2},"n":"CacheStrategy","d":2216834,"h":81606595458,"f":2},{"p":262145,"g":{"r":0,"d":0,"h":98786464642,"f":8},"s":{"r":0,"d":0,"h":103081431938,"f":8},"n":"UniqueInstance","d":2216834,"h":94491497346,"f":8}],"m":[{"r":65537,"n":"FinalRelease","d":2216834,"h":107376399234,"f":1},{"r":262145,"p":[{"n":"handle","p":116064257},{"n":"result","p":3199874,"f":2},{"n":"qiHResult","p":655361,"f":2}],"n":"LookUpVTableInfo","d":2216834,"h":120261301122,"f":2}],"l":[{"t":0,"n":"_instancePointer","d":2216834,"h":30066987906,"f":2},{"t":131073,"n":"_runtimeCallableWrapper","d":2216834,"h":34361955202,"f":2},{"t":262145,"n":"_released","d":2216834,"h":38656922498,"f":2}],"c":[{"p":[{"n":"interfaceDetailsStrategy","p":3330946},{"n":"iunknownStrategy","p":3462018},{"n":"cacheStrategy","p":3134338},{"n":"thisPointer","p":0}],"n":".ctor","o":"$ctor$1","d":2216834,"h":42951889794,"f":8}],"i":[104792065,3593090,2020226],"h":2216834}; }
            static get $b() { return $.$spc.System.Object; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.Runtime.InteropServices.IDynamicInterfaceCastable, $.$sris.System.Runtime.InteropServices.Marshalling.IUnmanagedVirtualMethodTableProvider, $.$sris.System.Runtime.InteropServices.Marshalling.ComImportInteropInterfaceDetailsStrategy.IComImportAdapter ]; }
            static get $fullName() { return `System.Runtime.InteropServices.Marshalling.ComObject`; }
        });
	});
})(window, window.NetJs.$boot(), ...window.NetJs.$require("NetJs.System.Private.CoreLib", "NetJs.System.Collections", "NetJs.System.Diagnostics.Tracing", "NetJs.System.Threading", "NetJs.System.Collections.Concurrent"))