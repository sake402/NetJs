
(function ($global, $, $spc, $sc, $sdt, $st, $scc) {
    "use strict";
    let _;
    
    
    
	$.$asm(
    "NetJs.System.Runtime.InteropServices", 
    {"h":39832,"f":"System.Runtime.InteropServices","v":"1.0.35.0","a":[{"t":115146753,"c":13000048641,"a":[{"v":".NETCoreApp,Version=v10.0","t":1310721}],"n":[{"n":"FrameworkDisplayName","v":".NET 10.0","t":1310721}]},{"t":73596929,"c":4368564225,"a":[{"v":"SIT","t":1310721}]},{"t":73662465,"c":4368629761,"a":[{"v":"Debug","t":1310721}]},{"t":74121217,"c":4369088513,"a":[{"v":"1.0.35.0","t":1310721}]},{"t":74252289,"c":4369219585,"a":[{"v":"1.0.35\u002B5b8aaafb3aebad7fc7141c6e509af03c92d8b793","t":1310721}]},{"t":75104257,"c":4370071553,"a":[{"v":"NetJs.System.Runtime.InteropServices","t":1310721}]},{"t":75235329,"c":4370202625,"a":[{"v":"NetJs.System.Runtime.InteropServices","t":1310721}]},{"t":75366401,"c":4370333697,"a":[{"v":"1.0.35.0","t":1310721}]},{"t":115212289,"c":4410179585,"a":[{"v":"browser1.0","t":1310721}]},{"t":114950145,"c":4409917441,"a":[{"v":"browser1.0","t":1310721}]}],"m":[]},
    function($asm)
	{
        
        
        $asm.$cls("$sris.System.Runtime.InteropServices.ComTypes.IAdviseSink", ($self) => class IAdviseSink
        {
            static $h = 1022872;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {"m":[{"r":65537,"p":[{"n":"format","p":957336,"f":4,"a":[{"t":104857601,"c":4399824897}]},{"n":"stgmedium","p":1350552,"f":4,"a":[{"t":104857601,"c":4399824897}]}],"n":"OnDataChange","o":"System$Runtime$InteropServices$ComTypes$IAdviseSink$OnDataChange","d":1022872,"h":4295990168,"f":257,"a":[{"t":109182977,"c":4404150273}]},{"r":65537,"p":[{"n":"aspect","p":655361},{"n":"index","p":655361}],"n":"OnViewChange","o":"System$Runtime$InteropServices$ComTypes$IAdviseSink$OnViewChange","d":1022872,"h":8590957464,"f":257,"a":[{"t":109182977,"c":4404150273}]},{"r":65537,"p":[{"n":"moniker","p":100925441}],"n":"OnRename","o":"System$Runtime$InteropServices$ComTypes$IAdviseSink$OnRename","d":1022872,"h":12885924760,"f":257,"a":[{"t":109182977,"c":4404150273}]},{"r":65537,"n":"OnSave","o":"System$Runtime$InteropServices$ComTypes$IAdviseSink$OnSave","d":1022872,"h":17180892056,"f":257,"a":[{"t":109182977,"c":4404150273}]},{"r":65537,"n":"OnClose","o":"System$Runtime$InteropServices$ComTypes$IAdviseSink$OnClose","d":1022872,"h":21475859352,"f":257,"a":[{"t":109182977,"c":4404150273}]}],"h":1022872,"a":[{"t":99155969,"c":4394123265},{"t":104398849,"c":4399366145,"a":[{"v":"0000010F-0000-0000-C000-000000000046","t":1310721}]},{"t":33161217,"c":4328128513,"a":[{"v":1,"t":33226753}]},{"t":104923137,"c":4399890433,"a":[{"v":1,"t":99221505}]}]}; }
            static get $fullName() { return `System.Runtime.InteropServices.ComTypes.IAdviseSink`; }
        });
        
        $asm.$cls("$sris.System.Runtime.InteropServices.ComTypes.IDataObject", ($self) => class IDataObject
        {
            static $h = 1088408;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {"m":[{"r":65537,"p":[{"n":"format","p":957336,"f":4,"a":[{"t":104857601,"c":4399824897}]},{"n":"medium","p":1350552,"f":2}],"n":"GetData","o":"System$Runtime$InteropServices$ComTypes$IDataObject$GetData","d":1088408,"h":4296055704,"f":257},{"r":65537,"p":[{"n":"format","p":957336,"f":4,"a":[{"t":104857601,"c":4399824897}]},{"n":"medium","p":1350552,"f":4}],"n":"GetDataHere","o":"System$Runtime$InteropServices$ComTypes$IDataObject$GetDataHere","d":1088408,"h":8591023000,"f":257},{"r":655361,"p":[{"n":"format","p":957336,"f":4,"a":[{"t":104857601,"c":4399824897}]}],"n":"QueryGetData","o":"System$Runtime$InteropServices$ComTypes$IDataObject$QueryGetData","d":1088408,"h":12885990296,"f":257,"a":[{"t":109182977,"c":4404150273}]},{"r":655361,"p":[{"n":"formatIn","p":957336,"f":4,"a":[{"t":104857601,"c":4399824897}]},{"n":"formatOut","p":957336,"f":2}],"n":"GetCanonicalFormatEtc","o":"System$Runtime$InteropServices$ComTypes$IDataObject$GetCanonicalFormatEtc","d":1088408,"h":17180957592,"f":257,"a":[{"t":109182977,"c":4404150273}]},{"r":65537,"p":[{"n":"formatIn","p":957336,"f":4,"a":[{"t":104857601,"c":4399824897}]},{"n":"medium","p":1350552,"f":4,"a":[{"t":104857601,"c":4399824897}]},{"n":"release","p":262145,"a":[{"t":105709569,"c":8695644161,"a":[{"v":2,"t":110886913}]}]}],"n":"SetData","o":"System$Runtime$InteropServices$ComTypes$IDataObject$SetData","d":1088408,"h":21475924888,"f":257},{"r":1153944,"p":[{"n":"direction","p":826264}],"n":"EnumFormatEtc","o":"System$Runtime$InteropServices$ComTypes$IDataObject$EnumFormatEtc","d":1088408,"h":25770892184,"f":257},{"r":655361,"p":[{"n":"pFormatetc","p":957336,"f":4,"a":[{"t":104857601,"c":4399824897}]},{"n":"advf","p":760728},{"n":"adviseSink","p":1022872},{"n":"connection","p":655361,"f":2}],"n":"DAdvise","o":"System$Runtime$InteropServices$ComTypes$IDataObject$DAdvise","d":1088408,"h":30065859480,"f":257,"a":[{"t":109182977,"c":4404150273}]},{"r":65537,"p":[{"n":"connection","p":655361}],"n":"DUnadvise","o":"System$Runtime$InteropServices$ComTypes$IDataObject$DUnadvise","d":1088408,"h":34360826776,"f":257},{"r":655361,"p":[{"n":"enumAdvise","p":1219480,"f":2}],"n":"EnumDAdvise","o":"System$Runtime$InteropServices$ComTypes$IDataObject$EnumDAdvise","d":1088408,"h":38655794072,"f":257,"a":[{"t":109182977,"c":4404150273}]}],"h":1088408,"a":[{"t":23396353,"c":8613330945,"a":[{"v":false,"t":262145}]},{"t":99155969,"c":4394123265},{"t":104398849,"c":4399366145,"a":[{"v":"0000010E-0000-0000-C000-000000000046","t":1310721}]},{"t":104923137,"c":4399890433,"a":[{"v":1,"t":99221505}]}]}; }
            static get $fullName() { return `System.Runtime.InteropServices.ComTypes.IDataObject`; }
        });
        
        $asm.$cls("$sris.System.Runtime.InteropServices.ComTypes.IEnumFORMATETC", ($self) => class IEnumFORMATETC
        {
            static $h = 1153944;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {"m":[{"r":655361,"p":[{"n":"celt","p":655361},{"n":"rgelt","p":0,"a":[{"t":108789761,"c":4403757057},{"t":105709569,"c":8695644161,"a":[{"v":42,"t":110886913}],"n":[{"n":"SizeParamIndex","v":0,"t":524289}]}]},{"n":"pceltFetched","p":0,"a":[{"t":108789761,"c":4403757057},{"t":105709569,"c":8695644161,"a":[{"v":42,"t":110886913}]}]}],"n":"Next","o":"System$Runtime$InteropServices$ComTypes$IEnumFORMATETC$Next","d":1153944,"h":4296121240,"f":257,"a":[{"t":109182977,"c":4404150273}]},{"r":655361,"p":[{"n":"celt","p":655361}],"n":"Skip","o":"System$Runtime$InteropServices$ComTypes$IEnumFORMATETC$Skip","d":1153944,"h":8591088536,"f":257,"a":[{"t":109182977,"c":4404150273}]},{"r":655361,"n":"Reset","o":"System$Runtime$InteropServices$ComTypes$IEnumFORMATETC$Reset","d":1153944,"h":12886055832,"f":257,"a":[{"t":109182977,"c":4404150273}]},{"r":65537,"p":[{"n":"newEnum","p":1153944,"f":2}],"n":"Clone","o":"System$Runtime$InteropServices$ComTypes$IEnumFORMATETC$Clone","d":1153944,"h":17181023128,"f":257}],"h":1153944,"a":[{"t":99155969,"c":4394123265},{"t":104398849,"c":4399366145,"a":[{"v":"00000103-0000-0000-C000-000000000046","t":1310721}]},{"t":33161217,"c":4328128513,"a":[{"v":1,"t":33226753}]},{"t":104923137,"c":4399890433,"a":[{"v":1,"t":99221505}]}]}; }
            static get $fullName() { return `System.Runtime.InteropServices.ComTypes.IEnumFORMATETC`; }
        });
        
        $asm.$cls("$sris.System.Runtime.InteropServices.ComTypes.IEnumSTATDATA", ($self) => class IEnumSTATDATA
        {
            static $h = 1219480;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {"m":[{"r":655361,"p":[{"n":"celt","p":655361},{"n":"rgelt","p":0,"a":[{"t":108789761,"c":4403757057},{"t":105709569,"c":8695644161,"a":[{"v":42,"t":110886913}],"n":[{"n":"SizeParamIndex","v":0,"t":524289}]}]},{"n":"pceltFetched","p":0,"a":[{"t":108789761,"c":4403757057},{"t":105709569,"c":8695644161,"a":[{"v":42,"t":110886913}],"n":[{"n":"SizeConst","v":1,"t":655361}]}]}],"n":"Next","o":"System$Runtime$InteropServices$ComTypes$IEnumSTATDATA$Next","d":1219480,"h":4296186776,"f":257,"a":[{"t":109182977,"c":4404150273}]},{"r":655361,"p":[{"n":"celt","p":655361}],"n":"Skip","o":"System$Runtime$InteropServices$ComTypes$IEnumSTATDATA$Skip","d":1219480,"h":8591154072,"f":257,"a":[{"t":109182977,"c":4404150273}]},{"r":655361,"n":"Reset","o":"System$Runtime$InteropServices$ComTypes$IEnumSTATDATA$Reset","d":1219480,"h":12886121368,"f":257,"a":[{"t":109182977,"c":4404150273}]},{"r":65537,"p":[{"n":"newEnum","p":1219480,"f":2}],"n":"Clone","o":"System$Runtime$InteropServices$ComTypes$IEnumSTATDATA$Clone","d":1219480,"h":17181088664,"f":257}],"h":1219480,"a":[{"t":99155969,"c":4394123265},{"t":104398849,"c":4399366145,"a":[{"v":"00000105-0000-0000-C000-000000000046","t":1310721}]},{"t":104923137,"c":4399890433,"a":[{"v":1,"t":99221505}]}]}; }
            static get $fullName() { return `System.Runtime.InteropServices.ComTypes.IEnumSTATDATA`; }
        });
        
        $asm.$cls("$sris.System.Runtime.InteropServices.Marshalling.IComExposedClass", ($self) => class IComExposedClass
        {
            static $h = 2988952;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {"m":[{"r":0,"p":[{"n":"count","p":655361,"f":2}],"n":"GetComInterfaceEntries","o":"System$Runtime$InteropServices$Marshalling$IComExposedClass$GetComInterfaceEntries","d":2988952,"h":4297956248,"f":289}],"h":2988952,"a":[{"t":23396353,"c":8613330945,"a":[{"v":false,"t":262145}]}]}; }
            static get $fullName() { return `System.Runtime.InteropServices.Marshalling.IComExposedClass`; }
        });
        
        $asm.$cls("$sris.System.Runtime.InteropServices.Marshalling.IComExposedDetails", ($self) => class IComExposedDetails
        {
            static /*IComExposedDetails? */ System$Runtime$InteropServices$Marshalling$IComExposedDetails$GetFromAttribute(/*RuntimeTypeHandle*/ handle)
            {
                /*var*/ let type = $.$spc.System.Type.GetTypeFromHandle(handle);
                if (type === null)
                {
                    return null;
                }
                return $.$cast($.$spc.System.Reflection.CustomAttributeExtensions.GetCustomAttribute$2(type, $.$sris.System.Runtime.InteropServices.Marshalling.ComExposedClassAttribute$$().$type), $.$sris.System.Runtime.InteropServices.Marshalling.IComExposedDetails);
            }
            static $h = 3054488;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {"m":[{"r":0,"p":[{"n":"count","p":655361,"f":2}],"n":"GetComInterfaceEntries","o":"System$Runtime$InteropServices$Marshalling$IComExposedDetails$GetComInterfaceEntries","d":3054488,"h":4298021784,"f":257},{"r":3054488,"p":[{"n":"handle","p":116064257}],"n":"GetFromAttribute","o":"System$Runtime$InteropServices$Marshalling$IComExposedDetails$GetFromAttribute","d":3054488,"h":8592989080,"f":40}],"h":3054488,"a":[{"t":23396353,"c":8613330945,"a":[{"v":false,"t":262145}]}]}; }
            static get $fullName() { return `System.Runtime.InteropServices.Marshalling.IComExposedDetails`; }
        });
        
        $asm.$cls("$sris.System.Runtime.InteropServices.Marshalling.IIUnknownCacheStrategy", ($self) => class IIUnknownCacheStrategy
        {
            static $_TableInfo;
            static get TableInfo()
            {
                let $cls = $.$sris.System.Runtime.InteropServices.Marshalling.IIUnknownCacheStrategy;
                return $cls.$_TableInfo ??= $asm.$nstr("$sris.System.Runtime.InteropServices.Marshalling.IIUnknownCacheStrategy.TableInfo", ($self) => class TableInfo extends $.$spc.System.ValueType
                {
                    /*void**/ ThisPtr;
                    /*void***/ Table;
                    /*RuntimeTypeHandle*/ ManagedType;
                    //default value type constructor
                    $ctor$2()
                    {
                        return this;
                    }
                    Clone($copy)
                    {
                        let copy = $copy ?? new this.constructor();
                        copy.ThisPtr = this.ThisPtr.Clone();
                        copy.Table = this.Table.Clone();
                        copy.ManagedType = this.ManagedType.Clone();
                        return copy;
                    }
                    //default member initializer
                    constructor()
                    {
                        super();
                        this.ThisPtr = $.$default($.$typePointer($.$spc.System.Void));
                        this.Table = $.$default($.$typePointer($.$typePointer($.$spc.System.Void)));
                        this.ManagedType = $.$default($.$spc.System.RuntimeTypeHandle);
                    }
                    static $h = 3185560;
                    static $z = 9;
                    static $f = 0b10000001010000001;
                    static $k = 2;
                    static $$md;
                    static get $md() { return this.$$md ??= {"b":196609,"p":[{"p":0,"g":{"r":0,"d":0,"h":12888087448,"f":1},"s":{"r":0,"d":0,"h":17183054744,"f":1},"n":"ThisPtr","d":3185560,"h":8593120152,"f":1},{"p":0,"g":{"r":0,"d":0,"h":30067956632,"f":1},"s":{"r":0,"d":0,"h":34362923928,"f":1},"n":"Table","d":3185560,"h":25772989336,"f":1},{"p":116064257,"g":{"r":0,"d":0,"h":47247825816,"f":1},"s":{"r":0,"d":0,"h":51542793112,"f":1},"n":"ManagedType","d":3185560,"h":42952858520,"f":1}],"c":[{"n":".ctor","o":"$ctor$2","d":3185560,"h":55837760408,"f":1}],"d":3120024,"h":3185560}; }
                    static get $b() { return $.$spc.System.ValueType; }
                    static get $fullName() { return `System.Runtime.InteropServices.Marshalling.IIUnknownCacheStrategy.TableInfo`; }
                }, $cls, ($v) => $cls.$_TableInfo = $v);
            }
            static $h = 3120024;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {"m":[{"r":3185560,"p":[{"n":"handle","p":116064257},{"n":"interfaceDetails","p":3251096},{"n":"ptr","p":0}],"n":"ConstructTableInfo","o":"System$Runtime$InteropServices$Marshalling$IIUnknownCacheStrategy$ConstructTableInfo","d":3120024,"h":8593054616,"f":257},{"r":262145,"p":[{"n":"handle","p":116064257},{"n":"info","p":3185560,"f":2}],"n":"TryGetTableInfo","o":"System$Runtime$InteropServices$Marshalling$IIUnknownCacheStrategy$TryGetTableInfo","d":3120024,"h":12888021912,"f":257},{"r":262145,"p":[{"n":"handle","p":116064257},{"n":"info","p":3185560}],"n":"TrySetTableInfo","o":"System$Runtime$InteropServices$Marshalling$IIUnknownCacheStrategy$TrySetTableInfo","d":3120024,"h":17182989208,"f":257},{"r":65537,"p":[{"n":"unknownStrategy","p":3447704}],"n":"Clear","o":"System$Runtime$InteropServices$Marshalling$IIUnknownCacheStrategy$Clear","d":3120024,"h":21477956504,"f":257}],"j":[3185560],"h":3120024,"a":[{"t":23396353,"c":8613330945,"a":[{"v":false,"t":262145}]}]}; }
            static get $fullName() { return `System.Runtime.InteropServices.Marshalling.IIUnknownCacheStrategy`; }
        });
        
        $asm.$cls("$sris.System.Runtime.InteropServices.Marshalling.IIUnknownInterfaceDetailsStrategy", ($self) => class IIUnknownInterfaceDetailsStrategy
        {
            static $h = 3316632;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {"m":[{"r":3251096,"p":[{"n":"type","p":116064257}],"n":"GetIUnknownDerivedDetails","o":"System$Runtime$InteropServices$Marshalling$IIUnknownInterfaceDetailsStrategy$GetIUnknownDerivedDetails","d":3316632,"h":4298283928,"f":257},{"r":3054488,"p":[{"n":"type","p":116064257}],"n":"GetComExposedTypeDetails","o":"System$Runtime$InteropServices$Marshalling$IIUnknownInterfaceDetailsStrategy$GetComExposedTypeDetails","d":3316632,"h":8593251224,"f":257}],"h":3316632,"a":[{"t":23396353,"c":8613330945,"a":[{"v":false,"t":262145}]}]}; }
            static get $fullName() { return `System.Runtime.InteropServices.Marshalling.IIUnknownInterfaceDetailsStrategy`; }
        });
        
        $asm.$cls("$sris.System.Runtime.InteropServices.Marshalling.IIUnknownInterfaceType", ($self) => class IIUnknownInterfaceType
        {
            static $h = 3382168;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {"p":[{"p":56164353,"g":{"r":0,"d":0,"h":8593316760,"f":289},"n":"Iid","o":"System$Runtime$InteropServices$Marshalling$IIUnknownInterfaceType$Iid","d":3382168,"h":4298349464,"f":289},{"p":0,"g":{"r":0,"d":0,"h":17183251352,"f":289},"n":"ManagedVirtualMethodTable","o":"System$Runtime$InteropServices$Marshalling$IIUnknownInterfaceType$ManagedVirtualMethodTable","d":3382168,"h":12888284056,"f":289}],"h":3382168,"a":[{"t":23396353,"c":8613330945,"a":[{"v":false,"t":262145}]}]}; }
            static get $fullName() { return `System.Runtime.InteropServices.Marshalling.IIUnknownInterfaceType`; }
        });
        
        $asm.$cls("$sris.System.Runtime.InteropServices.Marshalling.IIUnknownDerivedDetails", ($self) => class IIUnknownDerivedDetails
        {
            static /*IIUnknownDerivedDetails? */ System$Runtime$InteropServices$Marshalling$IIUnknownDerivedDetails$GetFromAttribute(/*RuntimeTypeHandle*/ handle)
            {
                /*var*/ let type = $.$spc.System.Type.GetTypeFromHandle(handle);
                if (type === null)
                {
                    return null;
                }
                return $.$cast($.$spc.System.Reflection.CustomAttributeExtensions.GetCustomAttribute$2(type, $.$sris.System.Runtime.InteropServices.Marshalling.IUnknownDerivedAttribute$$$().$type), $.$sris.System.Runtime.InteropServices.Marshalling.IIUnknownDerivedDetails);
            }
            static $h = 3251096;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {"p":[{"p":56164353,"g":{"r":0,"d":0,"h":8593185688,"f":257},"n":"Iid","o":"System$Runtime$InteropServices$Marshalling$IIUnknownDerivedDetails$Iid","d":3251096,"h":4298218392,"f":257},{"p":142606337,"g":{"r":0,"d":0,"h":17183120280,"f":257},"n":"Implementation","o":"System$Runtime$InteropServices$Marshalling$IIUnknownDerivedDetails$Implementation","d":3251096,"h":12888152984,"f":257},{"p":0,"g":{"r":0,"d":0,"h":25773054872,"f":257},"n":"ManagedVirtualMethodTable","o":"System$Runtime$InteropServices$Marshalling$IIUnknownDerivedDetails$ManagedVirtualMethodTable","d":3251096,"h":21478087576,"f":257}],"m":[{"r":3251096,"p":[{"n":"handle","p":116064257}],"n":"GetFromAttribute","o":"System$Runtime$InteropServices$Marshalling$IIUnknownDerivedDetails$GetFromAttribute","d":3251096,"h":30068022168,"f":40}],"h":3251096,"a":[{"t":23396353,"c":8613330945,"a":[{"v":false,"t":262145}]}]}; }
            static get $fullName() { return `System.Runtime.InteropServices.Marshalling.IIUnknownDerivedDetails`; }
        });
        
        $asm.$cls("$sris.System.Runtime.InteropServices.Marshalling.IIUnknownStrategy", ($self) => class IIUnknownStrategy
        {
            static $h = 3447704;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {"m":[{"r":0,"p":[{"n":"unknown","p":0}],"n":"CreateInstancePointer","o":"System$Runtime$InteropServices$Marshalling$IIUnknownStrategy$CreateInstancePointer","d":3447704,"h":4298415000,"f":257},{"r":655361,"p":[{"n":"instancePtr","p":0},{"n":"iid","p":56164353,"f":8},{"n":"ppObj","p":0,"f":2}],"n":"QueryInterface","o":"System$Runtime$InteropServices$Marshalling$IIUnknownStrategy$QueryInterface","d":3447704,"h":8593382296,"f":257},{"r":655361,"p":[{"n":"instancePtr","p":0}],"n":"Release","o":"System$Runtime$InteropServices$Marshalling$IIUnknownStrategy$Release","d":3447704,"h":12888349592,"f":257}],"h":3447704,"a":[{"t":23396353,"c":8613330945,"a":[{"v":false,"t":262145}]}]}; }
            static get $fullName() { return `System.Runtime.InteropServices.Marshalling.IIUnknownStrategy`; }
        });
        
        $asm.$cls("$sris.System.Runtime.InteropServices.Marshalling.IUnmanagedVirtualMethodTableProvider", ($self) => class IUnmanagedVirtualMethodTableProvider
        {
            static $h = 3578776;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {"m":[{"r":3775384,"p":[{"n":"type","p":142606337}],"n":"GetVirtualMethodTableInfoForKey","o":"System$Runtime$InteropServices$Marshalling$IUnmanagedVirtualMethodTableProvider$GetVirtualMethodTableInfoForKey","d":3578776,"h":4298546072,"f":257}],"h":3578776,"a":[{"t":23396353,"c":8613330945,"a":[{"v":false,"t":262145}]}]}; }
            static get $fullName() { return `System.Runtime.InteropServices.Marshalling.IUnmanagedVirtualMethodTableProvider`; }
        });
        
        $asm.$cls("$sris.System.SR", ($self) => class SR
        {
            /*global::System.Resources.ResourceManager*/ static s_resourceManager = null;
            /*global::System.Globalization.CultureInfo*/ static resourceCulture = null;
            static /*global::System.Resources.ResourceManager */ get ResourceManager()
            {
                if ($.$spc.System.Object.ReferenceEquals($.$sris.System.SR.s_resourceManager, null))
                {
                    /*global::System.Resources.ResourceManager*/ let temp = new $.$spc.System.Resources.ResourceManager().$ctor$3("System.Runtime.InteropServices", $.$sris.System.SR.$type.Assembly);
                    $.$sris.System.SR.s_resourceManager = temp;
                }
                return $.$sris.System.SR.s_resourceManager;
            }
            static /*global::System.Globalization.CultureInfo */ get Culture()
            {
                return $.$sris.System.SR.resourceCulture;
            }
            static /*global::System.Globalization.CultureInfo */ set Culture(value)
            {
                $.$sris.System.SR.resourceCulture = value;
            }
            static /*string */ get InvalidOperation_HCCountOverflow()
            {
                return "Handle collector count overflows or underflows.";
            }
            static /*string */ get Arg_NeedNonNegNumRequired()
            {
                return "Non-negative number required.";
            }
            static /*string */ get Arg_InvalidThreshold()
            {
                return "maximumThreshold cannot be less than initialThreshold.";
            }
            static /*string */ get InvalidOperation_NoComEventInterfaceAttribute()
            {
                return "Event invocation for COM objects requires the declaring interface of the event to be attributed with ComEventInterfaceAttribute.";
            }
            static /*string */ get AmbiguousMatch_MultipleEventInterfaceAttributes()
            {
                return "More than one ComEventInterfaceAttribute found for '{0}' on the declaring interface of the event.";
            }
            static /*string */ FormatAmbiguousMatch_MultipleEventInterfaceAttributes(/*object*/ arg1)
            {
                return $.$spc.System.String.Format("More than one ComEventInterfaceAttribute found for '{0}' on the declaring interface of the event.", arg1);
            }
            static /*string */ get InvalidOperation_NoDispIdAttribute()
            {
                return "Event invocation for COM objects requires event to be attributed with DispIdAttribute.";
            }
            static /*string */ get IO_FileExists_Name()
            {
                return "The file '{0}' already exists.";
            }
            static /*string */ FormatIO_FileExists_Name(/*object*/ arg1)
            {
                return $.$spc.System.String.Format("The file '{0}' already exists.", arg1);
            }
            static /*string */ get IO_FileNotFound()
            {
                return "Unable to find the specified file.";
            }
            static /*string */ get IO_FileNotFound_FileName()
            {
                return "Could not find file '{0}'.";
            }
            static /*string */ FormatIO_FileNotFound_FileName(/*object*/ arg1)
            {
                return $.$spc.System.String.Format("Could not find file '{0}'.", arg1);
            }
            static /*string */ get IO_PathNotFound_NoPathName()
            {
                return "Could not find a part of the path.";
            }
            static /*string */ get IO_PathNotFound_Path()
            {
                return "Could not find a part of the path '{0}'.";
            }
            static /*string */ FormatIO_PathNotFound_Path(/*object*/ arg1)
            {
                return $.$spc.System.String.Format("Could not find a part of the path '{0}'.", arg1);
            }
            static /*string */ get IO_PathTooLong()
            {
                return "The specified file name or path is too long, or a component of the specified path is too long.";
            }
            static /*string */ get IO_SharingViolation_File()
            {
                return "The process cannot access the file '{0}' because it is being used by another process.";
            }
            static /*string */ FormatIO_SharingViolation_File(/*object*/ arg1)
            {
                return $.$spc.System.String.Format("The process cannot access the file '{0}' because it is being used by another process.", arg1);
            }
            static /*string */ get IO_SharingViolation_NoFileName()
            {
                return "The process cannot access the file because it is being used by another process.";
            }
            static /*string */ get IO_PathTooLong_Path()
            {
                return "The path '{0}' is too long, or a component of the specified path is too long.";
            }
            static /*string */ FormatIO_PathTooLong_Path(/*object*/ arg1)
            {
                return $.$spc.System.String.Format("The path '{0}' is too long, or a component of the specified path is too long.", arg1);
            }
            static /*string */ get UnauthorizedAccess_IODenied_Path()
            {
                return "Access to the path '{0}' is denied.";
            }
            static /*string */ FormatUnauthorizedAccess_IODenied_Path(/*object*/ arg1)
            {
                return $.$spc.System.String.Format("Access to the path '{0}' is denied.", arg1);
            }
            static /*string */ get UnauthorizedAccess_IODenied_NoPathName()
            {
                return "Access to the path is denied.";
            }
            static /*string */ get ArgumentOutOfRange_FileLengthTooBig()
            {
                return "Specified file length was too large for the file system.";
            }
            static /*string */ get ComVariantMarshaller_ManagedTypeNotSupported()
            {
                return "Type of managed object is not supported for marshalling as ComVariant.";
            }
            static /*string */ get ComVariantMarshaller_UnmanagedTypeNotSupported()
            {
                return "Type of unmanaged variant is not supported for marshalling to a managed object.";
            }
            /*bool*/ static s_usingResourceKeys = false;
            static /*bool */ GetUsingResourceKeysSwitchValue()
            {
                /*bool*/ let usingResourceKeys;
                return $.$spc.System.AppContext.TryGetSwitch("System.Resources.UseSystemResourceKeys", $.$ref(() => usingResourceKeys, ($v) => usingResourceKeys = $v, $.$spc.System.Boolean)) ? usingResourceKeys : false;
            }
            static /*bool */ UsingResourceKeys()
            {
                return $.$sris.System.SR.s_usingResourceKeys;
            }
            static /*string */ GetResourceString(/*string*/ resourceKey)
            {
                if ($.$sris.System.SR.UsingResourceKeys())
                {
                    return resourceKey;
                }
                /*string?*/ let resourceString = null;
                try
                {
                    resourceString = $.$sris.System.SR.ResourceManager.GetString(resourceKey);
                }
                catch($e)
                {
                }
                return resourceString;
            }
            static /*string */ GetResourceString$1(/*string*/ resourceKey, /*string*/ defaultString)
            {
                /*string*/ let resourceString = $.$sris.System.SR.GetResourceString(resourceKey);
                return $.$spc.System.String.op_Equality(resourceKey, resourceString) || $.$spc.System.String.op_Equality(resourceString, null) ? defaultString : resourceString;
            }
            static /*string */ Format(/*string*/ resourceFormat, /*object?*/ p1)
            {
                if ($.$sris.System.SR.UsingResourceKeys())
                {
                    return $.$spc.System.String.Join$10(", ", $.$spc.System.ReadOnlySpan$$($.$spc.System.Object).op_Implicit([ resourceFormat, p1 ]));
                }
                return $.$spc.System.String.Format(resourceFormat, p1);
            }
            static /*string */ Format$1(/*string*/ resourceFormat, /*object?*/ p1, /*object?*/ p2)
            {
                if ($.$sris.System.SR.UsingResourceKeys())
                {
                    return $.$spc.System.String.Join$10(", ", $.$spc.System.ReadOnlySpan$$($.$spc.System.Object).op_Implicit([ resourceFormat, p1, p2 ]));
                }
                return $.$spc.System.String.Format$1(resourceFormat, p1, p2);
            }
            static /*string */ Format$2(/*string*/ resourceFormat, /*object?*/ p1, /*object?*/ p2, /*object?*/ p3)
            {
                if ($.$sris.System.SR.UsingResourceKeys())
                {
                    return $.$spc.System.String.Join$10(", ", $.$spc.System.ReadOnlySpan$$($.$spc.System.Object).op_Implicit([ resourceFormat, p1, p2, p3 ]));
                }
                return $.$spc.System.String.Format$2(resourceFormat, p1, p2, p3);
            }
            static /*string */ Format$3(/*string*/ resourceFormat, /*params object?[]?*/ args)
            {
                if (args !== null)
                {
                    if ($.$sris.System.SR.UsingResourceKeys())
                    {
                        return resourceFormat + ", " + $.$spc.System.String.Join$9(", ", args);
                    }
                    return $.$spc.System.String.Format$3(resourceFormat, args);
                }
                return resourceFormat;
            }
            static /*string */ Format$4(/*IFormatProvider?*/ provider, /*string*/ resourceFormat, /*object?*/ p1)
            {
                if ($.$sris.System.SR.UsingResourceKeys())
                {
                    return $.$spc.System.String.Join$10(", ", $.$spc.System.ReadOnlySpan$$($.$spc.System.Object).op_Implicit([ resourceFormat, p1 ]));
                }
                return $.$spc.System.String.Format$5(provider, resourceFormat, p1);
            }
            static /*string */ Format$5(/*IFormatProvider?*/ provider, /*string*/ resourceFormat, /*object?*/ p1, /*object?*/ p2)
            {
                if ($.$sris.System.SR.UsingResourceKeys())
                {
                    return $.$spc.System.String.Join$10(", ", $.$spc.System.ReadOnlySpan$$($.$spc.System.Object).op_Implicit([ resourceFormat, p1, p2 ]));
                }
                return $.$spc.System.String.Format$6(provider, resourceFormat, p1, p2);
            }
            static /*string */ Format$6(/*IFormatProvider?*/ provider, /*string*/ resourceFormat, /*object?*/ p1, /*object?*/ p2, /*object?*/ p3)
            {
                if ($.$sris.System.SR.UsingResourceKeys())
                {
                    return $.$spc.System.String.Join$10(", ", $.$spc.System.ReadOnlySpan$$($.$spc.System.Object).op_Implicit([ resourceFormat, p1, p2, p3 ]));
                }
                return $.$spc.System.String.Format$7(provider, resourceFormat, p1, p2, p3);
            }
            static /*string */ Format$7(/*IFormatProvider?*/ provider, /*string*/ resourceFormat, /*params object?[]?*/ args)
            {
                if (args !== null)
                {
                    if ($.$sris.System.SR.UsingResourceKeys())
                    {
                        return resourceFormat + ", " + $.$spc.System.String.Join$9(", ", args);
                    }
                    return $.$spc.System.String.Format$8(provider, resourceFormat, args);
                }
                return resourceFormat;
            }
            //Static Initializer
            static $sinit()
            {
                {
                    this.s_usingResourceKeys = $.$sris.System.SR.GetUsingResourceKeysSwitchValue();
                }
            }
            static $h = 4692888;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"h":4692888}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.SR`; }
        });
        
        $asm.$cls("$sris.System.Runtime.InteropServices.HandleCollector", ($self) => class HandleCollector extends $.$spc.System.Object
        {
            /*int*/ static DeltaPercent = 10;
            /*int*/ _threshold = 0;
            /*int*/ _handleCount = 0;
            /*int[]*/ _gcCounts = null;
            /*int*/ _gcGeneration = 0;
            $ctor$1(/*string?*/ name, /*int*/ initialThreshold)
            {
                this.$ctor$2(name, initialThreshold, 2147483647/*int.MaxValue*/);
                {
                }
                return this;
            }
            $ctor$2(/*string?*/ name, /*int*/ initialThreshold, /*int*/ maximumThreshold)
            {
                super.$ctor();
                {
                    if (initialThreshold < 0)
                    {
                        throw new $.$spc.System.ArgumentOutOfRangeException().$ctor$19("initialThreshold", $.$box(initialThreshold, $.$spc.System.Int32), $.$sris.System.SR.Arg_NeedNonNegNumRequired);
                    }
                    if (maximumThreshold < 0)
                    {
                        throw new $.$spc.System.ArgumentOutOfRangeException().$ctor$19("maximumThreshold", $.$box(maximumThreshold, $.$spc.System.Int32), $.$sris.System.SR.Arg_NeedNonNegNumRequired);
                    }
                    if (initialThreshold > maximumThreshold)
                    {
                        throw new $.$spc.System.ArgumentException().$ctor$13($.$sris.System.SR.Arg_InvalidThreshold, "initialThreshold");
                    }
                    this.Name = name ?? $.$spc.System.String.Empty;
                    this.InitialThreshold = initialThreshold;
                    this.MaximumThreshold = maximumThreshold;
                    this._threshold = initialThreshold;
                    this._handleCount = 0;
                    this._gcGeneration = 0;
                }
                return this;
            }
            /*int */ get Count()
            {
                return this._handleCount;
            }
            /*int*/ InitialThreshold = 0;
            /*int*/ MaximumThreshold = 0;
            /*string*/ Name = null;
            /*void */ Add()
            {
                /*int*/ let collectionGeneration = -1;
                $.$spc.System.Threading.Interlocked.Increment($.$ref(() => this._handleCount, ($v) => this._handleCount = $v, $.$spc.System.Int32));
                if (this._handleCount < 0)
                {
                    throw new $.$spc.System.InvalidOperationException().$ctor$10($.$sris.System.SR.InvalidOperation_HCCountOverflow);
                }
                if (this._handleCount > this._threshold)
                {
                    //lock
                    try
                    {
                        $.$spc.System.Threading.Monitor.Enter(this)
                        {
                            this._threshold = ((this._handleCount + ($.trunc(this._handleCount / 10/*DeltaPercent*/))) | 0);
                            collectionGeneration = this._gcGeneration;
                            if (this._gcGeneration < 2)
                            {
                                this._gcGeneration++;
                            }
                        }
                    }
                    finally
                    {
                        $.$spc.System.Threading.Monitor.Exit(this)
                    }
                }
                if ((collectionGeneration >= 0) && ((collectionGeneration === 0) || ($.$spc.System.Array.$ReadT1.call(this._gcCounts, collectionGeneration) === $.$spc.System.GC.CollectionCount(collectionGeneration))))
                {
                    $.$spc.System.GC.Collect(collectionGeneration);
                    $.$spc.System.Threading.Thread.Sleep(((10 * collectionGeneration) | 0));
                }
                for(/*int*/ let i = 1; i < 3; i++)
                {
                    $.$spc.System.Array.$WriteT1.call(this._gcCounts, $.$spc.System.GC.CollectionCount(i), i);
                }
            }
            /*void */ Remove()
            {
                $.$spc.System.Threading.Interlocked.Decrement($.$ref(() => this._handleCount, ($v) => this._handleCount = $v, $.$spc.System.Int32));
                if (this._handleCount < 0)
                {
                    throw new $.$spc.System.InvalidOperationException().$ctor$10($.$sris.System.SR.InvalidOperation_HCCountOverflow);
                }
                /*int*/ let newThreshold = ((this._handleCount + $.trunc(this._handleCount / 10/*DeltaPercent*/)) | 0);
                if (newThreshold < (((this._threshold - $.trunc(this._threshold / 10/*DeltaPercent*/)) | 0)))
                {
                    //lock
                    try
                    {
                        $.$spc.System.Threading.Monitor.Enter(this)
                        {
                            if (newThreshold > this.InitialThreshold)
                            {
                                this._threshold = newThreshold;
                            }
                            else 
                            {
                                this._threshold = this.InitialThreshold;
                            }
                            this._gcGeneration = 0;
                        }
                    }
                    finally
                    {
                        $.$spc.System.Threading.Monitor.Exit(this)
                    }
                }
                for(/*int*/ let i = 1; i < 3; i++)
                {
                    $.$spc.System.Array.$WriteT1.call(this._gcCounts, $.$spc.System.GC.CollectionCount(i), i);
                }
            }
            //default member initializer
            constructor()
            {
                super();
                this._gcCounts = $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$spc.System.Int32), null, [3], null);
            }
            static $h = 1612696;
            static $f = 0b10010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":655361,"g":{"r":0,"d":0,"h":38656318360,"f":1},"n":"Count","d":1612696,"h":34361351064,"f":1},{"p":655361,"g":{"r":0,"d":0,"h":51541220248,"f":1},"n":"InitialThreshold","d":1612696,"h":47246252952,"f":1},{"p":655361,"g":{"r":0,"d":0,"h":64426122136,"f":1},"n":"MaximumThreshold","d":1612696,"h":60131154840,"f":1},{"p":1310721,"g":{"r":0,"d":0,"h":77311024024,"f":1},"n":"Name","d":1612696,"h":73016056728,"f":1}],"m":[{"r":65537,"n":"Add","d":1612696,"h":81605991320,"f":1},{"r":65537,"n":"Remove","d":1612696,"h":85900958616,"f":1}],"l":[{"t":655361,"n":"DeltaPercent","d":1612696,"h":4296579992,"f":34},{"t":655361,"n":"_threshold","d":1612696,"h":8591547288,"f":2},{"t":655361,"n":"_handleCount","d":1612696,"h":12886514584,"f":2},{"t":0,"n":"_gcCounts","d":1612696,"h":17181481880,"f":2},{"t":655361,"n":"_gcGeneration","d":1612696,"h":21476449176,"f":2}],"c":[{"p":[{"n":"name","p":1310721},{"n":"initialThreshold","p":655361}],"n":".ctor","o":"$ctor$1","d":1612696,"h":25771416472,"f":1},{"p":[{"n":"name","p":1310721},{"n":"initialThreshold","p":655361},{"n":"maximumThreshold","p":655361}],"n":".ctor","o":"$ctor$2","d":1612696,"h":30066383768,"f":1}],"h":1612696}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.Runtime.InteropServices.HandleCollector`; }
        });
        
        $asm.$cls("$sris.System.Runtime.InteropServices.Marshalling.UniqueComInterfaceMarshaller<>", (T) => $asm.$gt("$sris.System.Runtime.InteropServices.Marshalling.UniqueComInterfaceMarshaller<>", [T], ($self) => class UniqueComInterfaceMarshaller$$
        {
            static /*void* */ ConvertToUnmanaged(/*T?*/ managed)
            {
                if ($.$box(managed, T) === null)
                {
                    return null;
                }
                /*nint*/ let unknown;
                if (!$.$spc.System.Runtime.InteropServices.ComWrappers.TryGetComInstance($.$box(managed, T), $.$ref(() => unknown, ($v) => unknown = $v, $.$spc.System.IntPtr)))
                {
                    unknown = $.$sris.System.Runtime.InteropServices.Marshalling.StrategyBasedComWrappers.DefaultMarshallingInstance.GetOrCreateComInterfaceForObject($.$box(managed, T), 0/*CreateComInterfaceFlags.None*/);
                }
                return $.$sris.System.Runtime.InteropServices.Marshalling.ComInterfaceMarshaller$$(T).CastIUnknownToInterfaceType(unknown);
            }
            static /*T? */ ConvertToManaged(/*void**/ unmanaged)
            {
                if (unmanaged === null)
                {
                    return $.$default(T);
                }
                return $.$cast($.$sris.System.Runtime.InteropServices.Marshalling.StrategyBasedComWrappers.DefaultMarshallingInstance.GetOrCreateObjectForComInstance($.$spc.System.IntPtr.op_Explicit$2(unmanaged), 2/*CreateObjectFlags.UniqueInstance*/), T);
            }
            static /*void */ Free(/*void**/ unmanaged)
            {
                if (unmanaged !== null)
                {
                    $.$spc.System.Runtime.InteropServices.Marshal.Release($.$spc.System.IntPtr.op_Explicit$2(unmanaged));
                }
            }
            static $h = 3709848;
            static $g = 1;
            static $f = 0b1010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"m":[{"r":0,"p":[{"n":"managed","p":T?.$h??1507328}],"n":"ConvertToUnmanaged","d":this.$h,"h":Number(BigInt(this.$h)|0x100000000n),"f":33},{"r":T?.$h??1507328,"p":[{"n":"unmanaged","p":0}],"n":"ConvertToManaged","d":this.$h,"h":Number(BigInt(this.$h)|0x200000000n),"f":33},{"r":65537,"p":[{"n":"unmanaged","p":0}],"n":"Free","d":this.$h,"h":Number(BigInt(this.$h)|0x300000000n),"f":33}],"g":[T?.$h??1507328],"r":1,"h":this.$h,"a":[{"t":115277825,"c":4410245121,"a":[{"v":"android","t":1310721}]},{"t":115277825,"c":4410245121,"a":[{"v":"browser","t":1310721}]},{"t":115277825,"c":4410245121,"a":[{"v":"ios","t":1310721}]},{"t":115277825,"c":4410245121,"a":[{"v":"tvos","t":1310721}]},{"t":23396353,"c":8613330945,"a":[{"v":false,"t":262145}]},{"t":106823681,"c":4401790977,"a":[{"v":106889217,"t":142606337},{"v":0,"t":106954753},{"v":$.$sris.System.Runtime.InteropServices.Marshalling.UniqueComInterfaceMarshaller$$().$h,"t":142606337}]}]}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.Runtime.InteropServices.Marshalling.UniqueComInterfaceMarshaller<${T?.$fullName}>`; }
        }));
        
        $asm.$cls("$sris.System.Runtime.InteropServices.Marshalling.ComVariantMarshaller", ($self) => class ComVariantMarshaller
        {
            /*short*/ static VARIANT_TRUE = -1;
            /*short*/ static VARIANT_FALSE = 0;
            static /*ComVariant */ ConvertToUnmanaged(/*object?*/ managed)
            {
                if (managed === null)
                {
                    return new $.$spc.System.Runtime.InteropServices.Marshalling.ComVariant();
                }
                //switch (managed)
                {
                    let s;
                    let b;
                    let i;
                    let l;
                    let f;
                    let d;
                    let dt;
                    let errorWrapper;
                    let currencyWrapper;
                    let bStrWrapper;
                    $switchJumpStart1: 
                    //case sbyte s:
                    if ($.$is(managed, $.$spc.System.SByte, { set $v(v){ s = v; } }))
                    {
                        return $.$spc.System.Runtime.InteropServices.Marshalling.ComVariant.Create($.$spc.System.SByte, s);
                    }
                    //case byte b:
                    else if ($.$is(managed, $.$spc.System.Byte, { set $v(v){ b = v; } }))
                    {
                        return $.$spc.System.Runtime.InteropServices.Marshalling.ComVariant.Create($.$spc.System.Byte, b);
                    }
                    //case short s:
                    else if ($.$is(managed, $.$spc.System.Int16, { set $v(v){ s = v; } }))
                    {
                        return $.$spc.System.Runtime.InteropServices.Marshalling.ComVariant.Create($.$spc.System.Int16, s);
                    }
                    //case ushort s:
                    else if ($.$is(managed, $.$spc.System.UInt16, { set $v(v){ s = v; } }))
                    {
                        return $.$spc.System.Runtime.InteropServices.Marshalling.ComVariant.Create($.$spc.System.UInt16, s);
                    }
                    //case int i:
                    else if ($.$is(managed, $.$spc.System.Int32, { set $v(v){ i = v; } }))
                    {
                        return $.$spc.System.Runtime.InteropServices.Marshalling.ComVariant.Create($.$spc.System.Int32, i);
                    }
                    //case uint i:
                    else if ($.$is(managed, $.$spc.System.UInt32, { set $v(v){ i = v; } }))
                    {
                        return $.$spc.System.Runtime.InteropServices.Marshalling.ComVariant.Create($.$spc.System.UInt32, i);
                    }
                    //case long l:
                    else if ($.$is(managed, $.$spc.System.Int64, { set $v(v){ l = v; } }))
                    {
                        return $.$spc.System.Runtime.InteropServices.Marshalling.ComVariant.Create($.$spc.System.Int64, l);
                    }
                    //case ulong l:
                    else if ($.$is(managed, $.$spc.System.UInt64, { set $v(v){ l = v; } }))
                    {
                        return $.$spc.System.Runtime.InteropServices.Marshalling.ComVariant.Create($.$spc.System.UInt64, l);
                    }
                    //case float f:
                    else if ($.$is(managed, $.$spc.System.Single, { set $v(v){ f = v; } }))
                    {
                        return $.$spc.System.Runtime.InteropServices.Marshalling.ComVariant.Create($.$spc.System.Single, f);
                    }
                    //case double d:
                    else if ($.$is(managed, $.$spc.System.Double, { set $v(v){ d = v; } }))
                    {
                        return $.$spc.System.Runtime.InteropServices.Marshalling.ComVariant.Create($.$spc.System.Double, d);
                    }
                    //case decimal d:
                    else if ($.$is(managed, $.$spc.System.Decimal, { set $v(v){ d = v; } }))
                    {
                        return $.$spc.System.Runtime.InteropServices.Marshalling.ComVariant.Create($.$spc.System.Decimal, d);
                    }
                    //case bool b:
                    else if ($.$is(managed, $.$spc.System.Boolean, { set $v(v){ b = v; } }))
                    {
                        return $.$spc.System.Runtime.InteropServices.Marshalling.ComVariant.Create($.$spc.System.Boolean, b);
                    }
                    //case string s:
                    else if ($.$is(managed, $.$spc.System.String, { set $v(v){ s = v; } }))
                    {
                        return $.$spc.System.Runtime.InteropServices.Marshalling.ComVariant.Create($.$spc.System.String, s);
                    }
                    //case DateTime dt:
                    else if ($.$is(managed, $.$spc.System.DateTime, { set $v(v){ dt = v; } }))
                    {
                        return $.$spc.System.Runtime.InteropServices.Marshalling.ComVariant.Create($.$spc.System.DateTime, dt);
                    }
                    //case ErrorWrapper errorWrapper:
                    else if ($.$is(managed, $.$spc.System.Runtime.InteropServices.ErrorWrapper, { set $v(v){ errorWrapper = v; } }))
                    {
                        return $.$spc.System.Runtime.InteropServices.Marshalling.ComVariant.Create($.$spc.System.Runtime.InteropServices.ErrorWrapper, errorWrapper);
                    }
                    //case CurrencyWrapper currencyWrapper:
                    else if ($.$is(managed, $.$spc.System.Runtime.InteropServices.CurrencyWrapper, { set $v(v){ currencyWrapper = v; } }))
                    {
                        return $.$spc.System.Runtime.InteropServices.Marshalling.ComVariant.Create($.$spc.System.Runtime.InteropServices.CurrencyWrapper, currencyWrapper);
                    }
                    //case BStrWrapper bStrWrapper:
                    else if ($.$is(managed, $.$spc.System.Runtime.InteropServices.BStrWrapper, { set $v(v){ bStrWrapper = v; } }))
                    {
                        return $.$spc.System.Runtime.InteropServices.Marshalling.ComVariant.Create($.$spc.System.Runtime.InteropServices.BStrWrapper, bStrWrapper);
                    }
                    //case DBNull:
                    else if (managed == $.$spc.System.DBNull)
                    {
                        return $.$spc.System.Runtime.InteropServices.Marshalling.ComVariant.Null;
                    }
                }
                /*ComVariant*/ let variant;
                if ($.$sris.System.Runtime.InteropServices.Marshalling.ComVariantMarshaller.TryCreateOleVariantForInterfaceWrapper(managed, $.$ref(() => variant, ($v) => variant = $v, $.$spc.System.Runtime.InteropServices.Marshalling.ComVariant)))
                {
                    return variant;
                }
                throw new $.$spc.System.ArgumentException().$ctor$13($.$sris.System.SR.ComVariantMarshaller_ManagedTypeNotSupported, "managed");
            }
            static /*bool */ TryCreateOleVariantForInterfaceWrapper(/*object*/ managed, /*out ComVariant*/ variant)
            {
                let uw;
                if ($.$is(managed, $.$spc.System.Runtime.InteropServices.UnknownWrapper, { set $v(v){ uw = v; } }))
                {
                    /*object?*/ let wrapped = uw.WrappedObject;
                    if (wrapped === null)
                    {
                        variant.$v = new $.$spc.System.Runtime.InteropServices.Marshalling.ComVariant();
                        return true;
                    }
                    variant.$v = $.$spc.System.Runtime.InteropServices.Marshalling.ComVariant.CreateRaw($.$spc.System.IntPtr, 13/*VarEnum.VT_UNKNOWN*/, $.$sris.System.Runtime.InteropServices.Marshalling.StrategyBasedComWrappers.DefaultMarshallingInstance.GetOrCreateComInterfaceForObject(wrapped, 0/*CreateComInterfaceFlags.None*/));
                    return true;
                }
                else if (!(managed === null) && !($.$sris.System.Runtime.InteropServices.Marshalling.StrategyBasedComWrappers.DefaultIUnknownInterfaceDetailsStrategy.System$Runtime$InteropServices$Marshalling$IIUnknownInterfaceDetailsStrategy$GetComExposedTypeDetails($.$spc.System.Object.GetType.call(managed).TypeHandle) === null))
                {
                    variant.$v = $.$spc.System.Runtime.InteropServices.Marshalling.ComVariant.CreateRaw($.$spc.System.IntPtr, 13/*VarEnum.VT_UNKNOWN*/, $.$sris.System.Runtime.InteropServices.Marshalling.StrategyBasedComWrappers.DefaultMarshallingInstance.GetOrCreateComInterfaceForObject(managed, 0/*CreateComInterfaceFlags.None*/));
                    return true;
                }
                variant.$v = new $.$spc.System.Runtime.InteropServices.Marshalling.ComVariant();
                return false;
            }
            static /*object? */ ConvertToManaged(/*ComVariant*/ unmanaged)
            {
                let $switch1 = unmanaged.VarType;
                switch($switch1)
                {
                    case 0/*VarEnum.VT_EMPTY*/:
                    case 16384/*VarEnum.VT_BYREF*/ | 0/*VarEnum.VT_EMPTY*/:
                    return null;
                    case 1/*VarEnum.VT_NULL*/:
                    case 16384/*VarEnum.VT_BYREF*/ | 1/*VarEnum.VT_NULL*/:
                    return $.$spc.System.DBNull.Value;
                    case 16/*VarEnum.VT_I1*/:
                    return $.$box(unmanaged.As($.$spc.System.SByte), $.$spc.System.SByte);
                    case 17/*VarEnum.VT_UI1*/:
                    return $.$box(unmanaged.As($.$spc.System.Byte), $.$spc.System.Byte);
                    case 2/*VarEnum.VT_I2*/:
                    return $.$box(unmanaged.As($.$spc.System.Int16), $.$spc.System.Int16);
                    case 18/*VarEnum.VT_UI2*/:
                    return $.$box(unmanaged.As($.$spc.System.UInt16), $.$spc.System.UInt16);
                    case 22/*VarEnum.VT_INT*/:
                    case 3/*VarEnum.VT_I4*/:
                    return $.$box(unmanaged.As($.$spc.System.Int32), $.$spc.System.Int32);
                    case 23/*VarEnum.VT_UINT*/:
                    case 19/*VarEnum.VT_UI4*/:
                    return $.$box(unmanaged.As($.$spc.System.UInt32), $.$spc.System.UInt32);
                    case 20/*VarEnum.VT_I8*/:
                    return $.$box(unmanaged.As($.$spc.System.Int64), $.$spc.System.Int64);
                    case 21/*VarEnum.VT_UI8*/:
                    return $.$box(unmanaged.As($.$spc.System.UInt64), $.$spc.System.UInt64);
                    case 4/*VarEnum.VT_R4*/:
                    return $.$box(unmanaged.As($.$spc.System.Single), $.$spc.System.Single);
                    case 5/*VarEnum.VT_R8*/:
                    return $.$box(unmanaged.As($.$spc.System.Double), $.$spc.System.Double);
                    case 14/*VarEnum.VT_DECIMAL*/:
                    return unmanaged.As($.$spc.System.Decimal);
                    case 11/*VarEnum.VT_BOOL*/:
                    return $.$box(unmanaged.As($.$spc.System.Boolean), $.$spc.System.Boolean);
                    case 8/*VarEnum.VT_BSTR*/:
                    return unmanaged.As($.$spc.System.String);
                    case 7/*VarEnum.VT_DATE*/:
                    return unmanaged.As($.$spc.System.DateTime);
                    case 10/*VarEnum.VT_ERROR*/:
                    return $.$box(unmanaged.As($.$spc.System.Int32), $.$spc.System.Int32);
                    case 6/*VarEnum.VT_CY*/:
                    return unmanaged.As($.$spc.System.Runtime.InteropServices.CurrencyWrapper).WrappedObject;
                    case 13/*VarEnum.VT_UNKNOWN*/:
                    case 9/*VarEnum.VT_DISPATCH*/:
                    return $.$sris.System.Runtime.InteropServices.Marshalling.StrategyBasedComWrappers.DefaultMarshallingInstance.GetOrCreateObjectForComInstance(unmanaged.GetRawDataRef($.$spc.System.IntPtr).$v, 8/*CreateObjectFlags.Unwrap*/);
                    case 16384/*VarEnum.VT_BYREF*/ | 12/*VarEnum.VT_VARIANT*/:
                    return $.$sris.System.Runtime.InteropServices.Marshalling.ComVariantMarshaller.ConvertToManaged($.$spc.InteropUtility.castAddress2Object(unmanaged.GetRawDataRef($.$spc.System.IntPtr).$v));
                    case 16384/*VarEnum.VT_BYREF*/ | 16/*VarEnum.VT_I1*/:
                    return $.$box($.$spc.InteropUtility.castAddress2Object(unmanaged.GetRawDataRef($.$spc.System.IntPtr).$v), $.$spc.System.SByte);
                    case 16384/*VarEnum.VT_BYREF*/ | 17/*VarEnum.VT_UI1*/:
                    return $.$box($.$spc.InteropUtility.castAddress2Object(unmanaged.GetRawDataRef($.$spc.System.IntPtr).$v), $.$spc.System.Byte);
                    case 16384/*VarEnum.VT_BYREF*/ | 2/*VarEnum.VT_I2*/:
                    return $.$box($.$spc.InteropUtility.castAddress2Object(unmanaged.GetRawDataRef($.$spc.System.IntPtr).$v), $.$spc.System.Int16);
                    case 16384/*VarEnum.VT_BYREF*/ | 18/*VarEnum.VT_UI2*/:
                    return $.$box($.$spc.InteropUtility.castAddress2Object(unmanaged.GetRawDataRef($.$spc.System.IntPtr).$v), $.$spc.System.UInt16);
                    case 16384/*VarEnum.VT_BYREF*/ | 3/*VarEnum.VT_I4*/:
                    return $.$box($.$spc.InteropUtility.castAddress2Object(unmanaged.GetRawDataRef($.$spc.System.IntPtr).$v), $.$spc.System.Int32);
                    case 16384/*VarEnum.VT_BYREF*/ | 19/*VarEnum.VT_UI4*/:
                    return $.$box($.$spc.InteropUtility.castAddress2Object(unmanaged.GetRawDataRef($.$spc.System.IntPtr).$v), $.$spc.System.UInt32);
                    case 16384/*VarEnum.VT_BYREF*/ | 20/*VarEnum.VT_I8*/:
                    return $.$box($.$spc.InteropUtility.castAddress2Object(unmanaged.GetRawDataRef($.$spc.System.IntPtr).$v), $.$spc.System.Int64);
                    case 16384/*VarEnum.VT_BYREF*/ | 21/*VarEnum.VT_UI8*/:
                    return $.$box($.$spc.InteropUtility.castAddress2Object(unmanaged.GetRawDataRef($.$spc.System.IntPtr).$v), $.$spc.System.UInt64);
                    case 16384/*VarEnum.VT_BYREF*/ | 4/*VarEnum.VT_R4*/:
                    return $.$box($.$spc.InteropUtility.castAddress2Object(unmanaged.GetRawDataRef($.$spc.System.IntPtr).$v), $.$spc.System.Single);
                    case 16384/*VarEnum.VT_BYREF*/ | 5/*VarEnum.VT_R8*/:
                    return $.$box($.$spc.InteropUtility.castAddress2Object(unmanaged.GetRawDataRef($.$spc.System.IntPtr).$v), $.$spc.System.Double);
                    case 16384/*VarEnum.VT_BYREF*/ | 14/*VarEnum.VT_DECIMAL*/:
                    return $.$spc.InteropUtility.castAddress2Object(unmanaged.GetRawDataRef($.$spc.System.IntPtr).$v);
                    case 16384/*VarEnum.VT_BYREF*/ | 11/*VarEnum.VT_BOOL*/:
                    return $.$box($.$spc.InteropUtility.castAddress2Object(unmanaged.GetRawDataRef($.$spc.System.IntPtr).$v) !== 0/*VARIANT_FALSE*/, $.$spc.System.Boolean);
                    case 16384/*VarEnum.VT_BYREF*/ | 8/*VarEnum.VT_BSTR*/:
                    return $.$spc.System.Runtime.InteropServices.Marshal.PtrToStringBSTR($.$spc.InteropUtility.castAddress2Object(unmanaged.GetRawDataRef($.$spc.System.IntPtr).$v));
                    case 16384/*VarEnum.VT_BYREF*/ | 7/*VarEnum.VT_DATE*/:
                    return $.$spc.System.DateTime.FromOADate($.$spc.InteropUtility.castAddress2Object(unmanaged.GetRawDataRef($.$spc.System.IntPtr).$v));
                    case 16384/*VarEnum.VT_BYREF*/ | 10/*VarEnum.VT_ERROR*/:
                    return $.$box($.$spc.InteropUtility.castAddress2Object(unmanaged.GetRawDataRef($.$spc.System.IntPtr).$v), $.$spc.System.Int32);
                    case 16384/*VarEnum.VT_BYREF*/ | 6/*VarEnum.VT_CY*/:
                    return $.$spc.System.Decimal.FromOACurrency($.$spc.InteropUtility.castAddress2Object(unmanaged.GetRawDataRef($.$spc.System.IntPtr).$v));
                    case 16384/*VarEnum.VT_BYREF*/ | 13/*VarEnum.VT_UNKNOWN*/:
                    return $.$sris.System.Runtime.InteropServices.Marshalling.StrategyBasedComWrappers.DefaultMarshallingInstance.GetOrCreateObjectForComInstance($.$spc.InteropUtility.castAddress2Object(unmanaged.GetRawDataRef($.$spc.System.IntPtr).$v), 8/*CreateObjectFlags.Unwrap*/);
                    default:
                    throw new $.$spc.System.ArgumentException().$ctor$13($.$sris.System.SR.ComVariantMarshaller_UnmanagedTypeNotSupported, "unmanaged");
                }
            }
            static /*void */ Free(/*ComVariant*/ unmanaged)
            {
                return unmanaged.Dispose();
            }
            static $_RefPropagate;
            static get RefPropagate()
            {
                let $cls = $.$sris.System.Runtime.InteropServices.Marshalling.ComVariantMarshaller;
                return $cls.$_RefPropagate ??= $asm.$nstr("$sris.System.Runtime.InteropServices.Marshalling.ComVariantMarshaller.RefPropagate", ($self) => class RefPropagate extends $.$spc.System.ValueType
                {
                    /*ComVariant*/  get _unmanaged() { return this.$getField(0, 125); }
                    /*ComVariant*/  set _unmanaged(value) { this.$setField(0, 125, value); }
                    /*object?*/  get _managed() { return this.$getField(125, 4); }
                    /*object?*/  set _managed(value) { this.$setField(125, 4, value); }
                    /*void */ FromUnmanaged(/*ComVariant*/ unmanaged)
                    {
                        return this._unmanaged = unmanaged.Clone();
                    }
                    /*void */ FromManaged(/*object?*/ managed)
                    {
                        return this._managed = managed;
                    }
                    /*ComVariant */ ToUnmanaged()
                    {
                        if (!((this._unmanaged.VarType & (16384/*VarEnum.VT_BYREF*/)) == (16384/*VarEnum.VT_BYREF*/)))
                        {
                            return $.$sris.System.Runtime.InteropServices.Marshalling.ComVariantMarshaller.ConvertToUnmanaged(this._managed);
                        }
                        if (this._managed === null && (((this._unmanaged.VarType & ~16384/*VarEnum.VT_BYREF*/) === 8/*VarEnum.VT_BSTR*/) || ((this._unmanaged.VarType & ~16384/*VarEnum.VT_BYREF*/) === 9/*VarEnum.VT_DISPATCH*/)) || ((this._unmanaged.VarType & ~16384/*VarEnum.VT_BYREF*/) === 13/*VarEnum.VT_UNKNOWN*/))
                        {
                            $.$spc.InteropUtility.castAddress2Object(this._unmanaged.GetRawDataRef($.$spc.System.IntPtr).$v).$v = 0;
                            return this._unmanaged;
                        }
                        //switch ((_unmanaged.VarType & ~VarEnum.VT_BYREF, _managed))
                        let $switch2 = this._unmanaged.VarType & ~16384/*VarEnum.VT_BYREF*/;
                        let $switch3 = this._managed;
                        {
                            let s;
                            let b;
                            let u;
                            let i;
                            let l;
                            let ul;
                            let f;
                            let d;
                            let str;
                            let dt;
                            let error;
                            let cy;
                            let unkObj;
                            $switchJumpStart1: 
                            //case (VarEnum.VT_VARIANT, _):
                            if (($switch2 === 12/*VarEnum.VT_VARIANT*/))
                            {
                                $.$spc.InteropUtility.castAddress2Object(this._unmanaged.GetRawDataRef($.$spc.System.IntPtr).$v).$v = $.$sris.System.Runtime.InteropServices.Marshalling.ComVariantMarshaller.ConvertToUnmanaged(this._managed);
                            }
                            //case (VarEnum.VT_I1 or VarEnum.VT_UI1, sbyte s):
                            else if ((($switch2 === 16/*VarEnum.VT_I1*/) || ($switch2 === 17/*VarEnum.VT_UI1*/)) && ($.$is($switch3, $.$spc.System.SByte, { set $v(v){ s = v; } })))
                            {
                                $.$spc.InteropUtility.castAddress2Object(this._unmanaged.GetRawDataRef($.$spc.System.IntPtr).$v).$v = s;
                            }
                            //case (VarEnum.VT_I1 or VarEnum.VT_UI1, byte b):
                            else if ((($switch2 === 16/*VarEnum.VT_I1*/) || ($switch2 === 17/*VarEnum.VT_UI1*/)) && ($.$is($switch3, $.$spc.System.Byte, { set $v(v){ b = v; } })))
                            {
                                $.$spc.InteropUtility.castAddress2Object(this._unmanaged.GetRawDataRef($.$spc.System.IntPtr).$v).$v = b;
                            }
                            //case (VarEnum.VT_I2 or VarEnum.VT_UI2, short s):
                            else if ((($switch2 === 2/*VarEnum.VT_I2*/) || ($switch2 === 18/*VarEnum.VT_UI2*/)) && ($.$is($switch3, $.$spc.System.Int16, { set $v(v){ s = v; } })))
                            {
                                $.$spc.InteropUtility.castAddress2Object(this._unmanaged.GetRawDataRef($.$spc.System.IntPtr).$v).$v = s;
                            }
                            //case (VarEnum.VT_I2 or VarEnum.VT_UI2, ushort u):
                            else if ((($switch2 === 2/*VarEnum.VT_I2*/) || ($switch2 === 18/*VarEnum.VT_UI2*/)) && ($.$is($switch3, $.$spc.System.UInt16, { set $v(v){ u = v; } })))
                            {
                                $.$spc.InteropUtility.castAddress2Object(this._unmanaged.GetRawDataRef($.$spc.System.IntPtr).$v).$v = u;
                            }
                            //case (VarEnum.VT_I4 or VarEnum.VT_INT or VarEnum.VT_UI4 or VarEnum.VT_UINT or VarEnum.VT_ERROR, int i):
                            else if (((((($switch2 === 3/*VarEnum.VT_I4*/) || ($switch2 === 22/*VarEnum.VT_INT*/)) || ($switch2 === 19/*VarEnum.VT_UI4*/)) || ($switch2 === 23/*VarEnum.VT_UINT*/)) || ($switch2 === 10/*VarEnum.VT_ERROR*/)) && ($.$is($switch3, $.$spc.System.Int32, { set $v(v){ i = v; } })))
                            {
                                $.$spc.InteropUtility.castAddress2Object(this._unmanaged.GetRawDataRef($.$spc.System.IntPtr).$v).$v = i;
                            }
                            //case (VarEnum.VT_I4 or VarEnum.VT_INT or VarEnum.VT_UI4 or VarEnum.VT_UINT or VarEnum.VT_ERROR, uint u):
                            else if (((((($switch2 === 3/*VarEnum.VT_I4*/) || ($switch2 === 22/*VarEnum.VT_INT*/)) || ($switch2 === 19/*VarEnum.VT_UI4*/)) || ($switch2 === 23/*VarEnum.VT_UINT*/)) || ($switch2 === 10/*VarEnum.VT_ERROR*/)) && ($.$is($switch3, $.$spc.System.UInt32, { set $v(v){ u = v; } })))
                            {
                                $.$spc.InteropUtility.castAddress2Object(this._unmanaged.GetRawDataRef($.$spc.System.IntPtr).$v).$v = u;
                            }
                            //case (VarEnum.VT_I8 or VarEnum.VT_UI8, long l):
                            else if ((($switch2 === 20/*VarEnum.VT_I8*/) || ($switch2 === 21/*VarEnum.VT_UI8*/)) && ($.$is($switch3, $.$spc.System.Int64, { set $v(v){ l = v; } })))
                            {
                                $.$spc.InteropUtility.castAddress2Object(this._unmanaged.GetRawDataRef($.$spc.System.IntPtr).$v).$v = l;
                            }
                            //case (VarEnum.VT_I8 or VarEnum.VT_UI8, ulong ul):
                            else if ((($switch2 === 20/*VarEnum.VT_I8*/) || ($switch2 === 21/*VarEnum.VT_UI8*/)) && ($.$is($switch3, $.$spc.System.UInt64, { set $v(v){ ul = v; } })))
                            {
                                $.$spc.InteropUtility.castAddress2Object(this._unmanaged.GetRawDataRef($.$spc.System.IntPtr).$v).$v = ul;
                            }
                            //case (VarEnum.VT_R4, float f):
                            else if (($switch2 === 4/*VarEnum.VT_R4*/) && ($.$is($switch3, $.$spc.System.Single, { set $v(v){ f = v; } })))
                            {
                                $.$spc.InteropUtility.castAddress2Object(this._unmanaged.GetRawDataRef($.$spc.System.IntPtr).$v).$v = f;
                            }
                            //case (VarEnum.VT_R8, double d):
                            else if (($switch2 === 5/*VarEnum.VT_R8*/) && ($.$is($switch3, $.$spc.System.Double, { set $v(v){ d = v; } })))
                            {
                                $.$spc.InteropUtility.castAddress2Object(this._unmanaged.GetRawDataRef($.$spc.System.IntPtr).$v).$v = d;
                            }
                            //case (VarEnum.VT_DECIMAL, decimal d):
                            else if (($switch2 === 14/*VarEnum.VT_DECIMAL*/) && ($.$is($switch3, $.$spc.System.Decimal, { set $v(v){ d = v; } })))
                            {
                                $.$spc.InteropUtility.castAddress2Object(this._unmanaged.GetRawDataRef($.$spc.System.IntPtr).$v).$v = d;
                            }
                            //case (VarEnum.VT_BOOL, bool b):
                            else if (($switch2 === 11/*VarEnum.VT_BOOL*/) && ($.$is($switch3, $.$spc.System.Boolean, { set $v(v){ b = v; } })))
                            {
                                $.$spc.InteropUtility.castAddress2Object(this._unmanaged.GetRawDataRef($.$spc.System.IntPtr).$v).$v = b ? -1/*VARIANT_TRUE*/ : 0/*VARIANT_FALSE*/;
                            }
                            //case (VarEnum.VT_BSTR, string str):
                            else if (($switch2 === 8/*VarEnum.VT_BSTR*/) && ($.$is($switch3, $.$spc.System.String, { set $v(v){ str = v; } })))
                            {
                                {
                                    /*ref IntPtr*/ let bstrStorage = $.$cast(this._unmanaged.GetRawDataRef($.$spc.System.IntPtr).$v, $.$typePointer($.$spc.System.IntPtr));
                                    $.$spc.System.Runtime.InteropServices.Marshal.FreeBSTR(bstrStorage.$v);
                                    bstrStorage.$v = $.$spc.System.Runtime.InteropServices.Marshal.StringToBSTR(str);
                                    break $switchJumpStart1;
                                }
                            }
                            //case (VarEnum.VT_BSTR, BStrWrapper str):
                            else if (($switch2 === 8/*VarEnum.VT_BSTR*/) && ($.$is($switch3, $.$spc.System.Runtime.InteropServices.BStrWrapper, { set $v(v){ str = v; } })))
                            {
                                {
                                    /*ref IntPtr*/ let bstrStorage = $.$cast(this._unmanaged.GetRawDataRef($.$spc.System.IntPtr).$v, $.$typePointer($.$spc.System.IntPtr));
                                    $.$spc.System.Runtime.InteropServices.Marshal.FreeBSTR(bstrStorage.$v);
                                    bstrStorage.$v = $.$spc.System.Runtime.InteropServices.Marshal.StringToBSTR(str.WrappedObject);
                                    break $switchJumpStart1;
                                }
                            }
                            //case (VarEnum.VT_DATE, DateTime dt):
                            else if (($switch2 === 7/*VarEnum.VT_DATE*/) && ($.$is($switch3, $.$spc.System.DateTime, { set $v(v){ dt = v; } })))
                            {
                                $.$spc.InteropUtility.castAddress2Object(this._unmanaged.GetRawDataRef($.$spc.System.IntPtr).$v).$v = dt.ToOADate();
                            }
                            //case (VarEnum.VT_ERROR, ErrorWrapper error):
                            else if (($switch2 === 10/*VarEnum.VT_ERROR*/) && ($.$is($switch3, $.$spc.System.Runtime.InteropServices.ErrorWrapper, { set $v(v){ error = v; } })))
                            {
                                $.$spc.InteropUtility.castAddress2Object(this._unmanaged.GetRawDataRef($.$spc.System.IntPtr).$v).$v = error.ErrorCode;
                            }
                            //case (VarEnum.VT_CY, CurrencyWrapper cy):
                            else if (($switch2 === 6/*VarEnum.VT_CY*/) && ($.$is($switch3, $.$spc.System.Runtime.InteropServices.CurrencyWrapper, { set $v(v){ cy = v; } })))
                            {
                                $.$spc.InteropUtility.castAddress2Object(this._unmanaged.GetRawDataRef($.$spc.System.IntPtr).$v).$v = $.$spc.System.Decimal.ToOACurrency(cy.WrappedObject);
                            }
                            //case (VarEnum.VT_UNKNOWN, object unkObj):
                            else if (($switch2 === 13/*VarEnum.VT_UNKNOWN*/) && ($.$is($switch3, $.$spc.System.Object, { set $v(v){ unkObj = v; } })))
                            {
                                $.$spc.InteropUtility.castAddress2Object(this._unmanaged.GetRawDataRef($.$spc.System.IntPtr).$v).$v = $.$sris.System.Runtime.InteropServices.Marshalling.StrategyBasedComWrappers.DefaultMarshallingInstance.GetOrCreateComInterfaceForObject(unkObj, 0/*CreateComInterfaceFlags.None*/);
                            }
                            //default
                            else
                            {
                                throw new $.$spc.System.ArgumentException().$ctor$13("Invalid combination of unmanaged variant type and managed object type.", "_managed");
                            }
                        }
                        return this._unmanaged;
                    }
                    /*object? */ ToManaged()
                    {
                        return $.$sris.System.Runtime.InteropServices.Marshalling.ComVariantMarshaller.ConvertToManaged(this._unmanaged.Clone());
                    }
                    /*void */ Free()
                    {
                        return this._unmanaged.Dispose();
                    }
                    //default value type constructor
                    $ctor$2()
                    {
                        return this;
                    }
                    Clone($copy)
                    {
                        let copy = $copy ?? new this.constructor();
                        copy._unmanaged = this._unmanaged.Clone();
                        copy._managed = this._managed;
                        return copy;
                    }
                    //default member initializer
                    constructor()
                    {
                        super();
                        this._unmanaged = $.$default($.$spc.System.Runtime.InteropServices.Marshalling.ComVariant);
                        this._managed = null;
                    }
                    static $h = 2333592;
                    static $z = 129;
                    static $f = 0b10000001010000001;
                    static $k = 2;
                    static $$md;
                    static get $md() { return this.$$md ??= {"b":196609,"m":[{"r":65537,"p":[{"n":"unmanaged","p":106233857}],"n":"FromUnmanaged","d":2333592,"h":12887235480,"f":1},{"r":65537,"p":[{"n":"managed","p":131073}],"n":"FromManaged","d":2333592,"h":17182202776,"f":1},{"r":106233857,"n":"ToUnmanaged","d":2333592,"h":21477170072,"f":1},{"r":131073,"n":"ToManaged","d":2333592,"h":25772137368,"f":1},{"r":65537,"n":"Free","d":2333592,"h":30067104664,"f":1}],"l":[{"t":106233857,"n":"_unmanaged","d":2333592,"h":4297300888,"f":2},{"t":131073,"n":"_managed","d":2333592,"h":8592268184,"f":2}],"c":[{"n":".ctor","o":"$ctor$2","d":2333592,"h":34362071960,"f":1}],"d":2268056,"h":2333592}; }
                    static get $b() { return $.$spc.System.ValueType; }
                    static get $fullName() { return `System.Runtime.InteropServices.Marshalling.ComVariantMarshaller.RefPropagate`; }
                }, $cls, ($v) => $cls.$_RefPropagate = $v);
            }
            static $h = 2268056;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"m":[{"r":106233857,"p":[{"n":"managed","p":131073}],"n":"ConvertToUnmanaged","d":2268056,"h":12887169944,"f":33},{"r":262145,"p":[{"n":"managed","p":131073},{"n":"variant","p":106233857,"f":2}],"n":"TryCreateOleVariantForInterfaceWrapper","d":2268056,"h":17182137240,"f":34},{"r":131073,"p":[{"n":"unmanaged","p":106233857}],"n":"ConvertToManaged","d":2268056,"h":21477104536,"f":33},{"r":65537,"p":[{"n":"unmanaged","p":106233857}],"n":"Free","d":2268056,"h":25772071832,"f":33}],"l":[{"t":524289,"n":"VARIANT_TRUE","d":2268056,"h":4297235352,"f":34},{"t":524289,"n":"VARIANT_FALSE","d":2268056,"h":8592202648,"f":34}],"j":[2333592],"h":2268056,"a":[{"t":106823681,"c":4401790977,"a":[{"v":131073,"t":142606337},{"v":0,"t":106954753},{"v":2268056,"t":142606337}]},{"t":106823681,"c":4401790977,"a":[{"v":131073,"t":142606337},{"v":5,"t":106954753},{"v":2333592,"t":142606337}]}]}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.Runtime.InteropServices.Marshalling.ComVariantMarshaller`; }
        });
        
        $asm.$cls("$sris.System.Runtime.InteropServices.Marshalling.ExceptionAsDefaultMarshaller<>", (T) => $asm.$gt("$sris.System.Runtime.InteropServices.Marshalling.ExceptionAsDefaultMarshaller<>", [T], ($self) => class ExceptionAsDefaultMarshaller$$
        {
            static /*T */ ConvertToUnmanaged(/*Exception*/ e)
            {
                _ = $.$spc.System.Runtime.InteropServices.Marshal.GetHRForException(e);
                return $.$default(T);
            }
            static $h = 2530200;
            static $g = 1;
            static $f = 0b1010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"m":[{"r":T?.$h??1507328,"p":[{"n":"e","p":47185921}],"n":"ConvertToUnmanaged","d":this.$h,"h":Number(BigInt(this.$h)|0x100000000n),"f":33}],"g":[T?.$h??1507328],"s":[{"n":"T","f":10}],"r":1,"h":this.$h,"a":[{"t":106823681,"c":4401790977,"a":[{"v":47185921,"t":142606337},{"v":6,"t":106954753},{"v":$.$sris.System.Runtime.InteropServices.Marshalling.ExceptionAsDefaultMarshaller$$().$h,"t":142606337}]}]}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.Runtime.InteropServices.Marshalling.ExceptionAsDefaultMarshaller<${T?.$fullName}>`; }
        }));
        
        $asm.$cls("$sris.System.Runtime.InteropServices.Marshalling.ExceptionAsNaNMarshaller<>", (T) => $asm.$gt("$sris.System.Runtime.InteropServices.Marshalling.ExceptionAsNaNMarshaller<>", [T], ($self) => class ExceptionAsNaNMarshaller$$
        {
            static /*T */ ConvertToUnmanaged(/*Exception*/ e)
            {
                _ = $.$spc.System.Runtime.InteropServices.Marshal.GetHRForException(e);
                return T.System$Numerics$IFloatingPointIeee754$$$NaN;
            }
            static $h = 2661272;
            static $g = 1;
            static $f = 0b1010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"m":[{"r":T?.$h??1507328,"p":[{"n":"e","p":47185921}],"n":"ConvertToUnmanaged","d":this.$h,"h":Number(BigInt(this.$h)|0x100000000n),"f":33}],"g":[T?.$h??1507328],"s":[{"n":"T","f":10,"c":[$.$spc.System.Numerics.IFloatingPointIeee754$$(T).$h]}],"r":1,"h":this.$h,"a":[{"t":106823681,"c":4401790977,"a":[{"v":47185921,"t":142606337},{"v":6,"t":106954753},{"v":$.$sris.System.Runtime.InteropServices.Marshalling.ExceptionAsNaNMarshaller$$().$h,"t":142606337}]}]}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.Runtime.InteropServices.Marshalling.ExceptionAsNaNMarshaller<${T?.$fullName}>`; }
        }));
        
        $asm.$cls("$sris.System.Runtime.InteropServices.Marshalling.ExceptionAsVoidMarshaller", ($self) => class ExceptionAsVoidMarshaller
        {
            static /*void */ ConvertToUnmanaged(/*Exception*/ e)
            {
                _ = $.$spc.System.Runtime.InteropServices.Marshal.GetHRForException(e);
            }
            static $h = 2726808;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"m":[{"r":65537,"p":[{"n":"e","p":47185921}],"n":"ConvertToUnmanaged","d":2726808,"h":4297694104,"f":33}],"h":2726808,"a":[{"t":106823681,"c":4401790977,"a":[{"v":47185921,"t":142606337},{"v":6,"t":106954753},{"v":2726808,"t":142606337}]}]}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.Runtime.InteropServices.Marshalling.ExceptionAsVoidMarshaller`; }
        });
        
        $asm.$cls("$sris.System.Runtime.InteropServices.Marshalling.ExceptionAsHResultMarshaller<>", (T) => $asm.$gt("$sris.System.Runtime.InteropServices.Marshalling.ExceptionAsHResultMarshaller<>", [T], ($self) => class ExceptionAsHResultMarshaller$$
        {
            static /*T */ ConvertToUnmanaged(/*Exception*/ e)
            {
                return T.System$Numerics$INumberBase$$$CreateTruncating($.$spc.System.Int32, $.$spc.System.Runtime.InteropServices.Marshal.GetHRForException(e));
            }
            static $h = 2595736;
            static $g = 1;
            static $f = 0b1010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"m":[{"r":T?.$h??1507328,"p":[{"n":"e","p":47185921}],"n":"ConvertToUnmanaged","d":this.$h,"h":Number(BigInt(this.$h)|0x100000000n),"f":33}],"g":[T?.$h??1507328],"s":[{"n":"T","f":10,"c":[$.$spc.System.Numerics.INumber$$(T).$h]}],"r":1,"h":this.$h,"a":[{"t":106823681,"c":4401790977,"a":[{"v":47185921,"t":142606337},{"v":6,"t":106954753},{"v":$.$sris.System.Runtime.InteropServices.Marshalling.ExceptionAsHResultMarshaller$$().$h,"t":142606337}]}]}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.Runtime.InteropServices.Marshalling.ExceptionAsHResultMarshaller<${T?.$fullName}>`; }
        }));
        
        $asm.$cls("$sris.System.Runtime.InteropServices.RuntimeEnvironment", ($self) => class RuntimeEnvironment
        {
            static /*string */ get SystemConfigurationFile()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static /*bool */ FromGlobalAccessCache(/*Assembly*/ a)
            {
                return false;
            }
            static /*string */ GetRuntimeDirectory()
            {
                /*string?*/ let runtimeDirectory = $.$spc.System.Object.$type.Assembly.Location;
                if (!$.$spc.System.IO.Path.IsPathRooted(runtimeDirectory))
                {
                    runtimeDirectory = $.$spc.System.AppDomain.CurrentDomain.BaseDirectory;
                }
                /*char*/ let sep = $.$spc.System.IO.Path.DirectorySeparatorChar;
                return $.$spc.System.String.Concat$10($.$spc.System.String.op_Implicit($.$spc.System.IO.Path.GetDirectoryName(runtimeDirectory)), new ($.$spc.System.ReadOnlySpan$$($.$spc.System.Char))().$ctor$5($.$ref(() => sep, undefined, $.$spc.System.Char)));
            }
            static /*IntPtr */ GetRuntimeInterfaceAsIntPtr(/*Guid*/ clsid, /*Guid*/ riid)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static /*object */ GetRuntimeInterfaceAsObject(/*Guid*/ clsid, /*Guid*/ riid)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static /*string */ GetSystemVersion()
            {
                return `v${$.$spc.System.Environment.Version}`;
            }
            static $h = 4037528;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":1310721,"g":{"r":0,"d":0,"h":8593972120,"f":33},"n":"SystemConfigurationFile","d":4037528,"h":4299004824,"f":33,"a":[{"t":70909953,"c":8660844545,"a":[{"v":"RuntimeEnvironment members SystemConfigurationFile, GetRuntimeInterfaceAsIntPtr, and GetRuntimeInterfaceAsObject are not supported and throw PlatformNotSupportedException.","t":1310721}],"n":[{"n":"DiagnosticId","v":"SYSLIB0019","t":1310721},{"n":"UrlFormat","v":"https://aka.ms/dotnet-warnings/{0}","t":1310721}]}]}],"m":[{"r":262145,"p":[{"n":"a","p":73465857}],"n":"FromGlobalAccessCache","d":4037528,"h":12888939416,"f":33},{"r":1310721,"n":"GetRuntimeDirectory","d":4037528,"h":17183906712,"f":33},{"r":786433,"p":[{"n":"clsid","p":56164353},{"n":"riid","p":56164353}],"n":"GetRuntimeInterfaceAsIntPtr","d":4037528,"h":21478874008,"f":33,"a":[{"t":70909953,"c":8660844545,"a":[{"v":"RuntimeEnvironment members SystemConfigurationFile, GetRuntimeInterfaceAsIntPtr, and GetRuntimeInterfaceAsObject are not supported and throw PlatformNotSupportedException.","t":1310721}],"n":[{"n":"DiagnosticId","v":"SYSLIB0019","t":1310721},{"n":"UrlFormat","v":"https://aka.ms/dotnet-warnings/{0}","t":1310721}]}]},{"r":131073,"p":[{"n":"clsid","p":56164353},{"n":"riid","p":56164353}],"n":"GetRuntimeInterfaceAsObject","d":4037528,"h":25773841304,"f":33,"a":[{"t":70909953,"c":8660844545,"a":[{"v":"RuntimeEnvironment members SystemConfigurationFile, GetRuntimeInterfaceAsIntPtr, and GetRuntimeInterfaceAsObject are not supported and throw PlatformNotSupportedException.","t":1310721}],"n":[{"n":"DiagnosticId","v":"SYSLIB0019","t":1310721},{"n":"UrlFormat","v":"https://aka.ms/dotnet-warnings/{0}","t":1310721}]}]},{"r":1310721,"n":"GetSystemVersion","d":4037528,"h":30068808600,"f":33}],"h":4037528}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.Runtime.InteropServices.RuntimeEnvironment`; }
        });
        
        $asm.$cls("$sris.System.Runtime.InteropServices.Marshalling.ComInterfaceMarshaller<>", (T) => $asm.$gt("$sris.System.Runtime.InteropServices.Marshalling.ComInterfaceMarshaller<>", [T], ($self) => class ComInterfaceMarshaller$$
        {
            /*Guid?*/ static TargetInterfaceIID = null;
            static /*void* */ ConvertToUnmanaged(/*T?*/ managed)
            {
                if ($.$box(managed, T) === null)
                {
                    return null;
                }
                /*nint*/ let unknown;
                if (!$.$spc.System.Runtime.InteropServices.ComWrappers.TryGetComInstance($.$box(managed, T), $.$ref(() => unknown, ($v) => unknown = $v, $.$spc.System.IntPtr)))
                {
                    unknown = $.$sris.System.Runtime.InteropServices.Marshalling.StrategyBasedComWrappers.DefaultMarshallingInstance.GetOrCreateComInterfaceForObject($.$box(managed, T), 0/*CreateComInterfaceFlags.None*/);
                }
                return $.$sris.System.Runtime.InteropServices.Marshalling.ComInterfaceMarshaller$$(T).CastIUnknownToInterfaceType(unknown);
            }
            static /*T? */ ConvertToManaged(/*void**/ unmanaged)
            {
                if (unmanaged === null)
                {
                    return $.$default(T);
                }
                return $.$cast($.$sris.System.Runtime.InteropServices.Marshalling.StrategyBasedComWrappers.DefaultMarshallingInstance.GetOrCreateObjectForComInstance($.$spc.System.IntPtr.op_Explicit$2(unmanaged), 8/*CreateObjectFlags.Unwrap*/), T);
            }
            static /*void */ Free(/*void**/ unmanaged)
            {
                if (unmanaged !== null)
                {
                    $.$spc.System.Runtime.InteropServices.Marshal.Release($.$spc.System.IntPtr.op_Explicit$2(unmanaged));
                }
            }
            static /*void* */ CastIUnknownToInterfaceType(/*nint*/ unknown)
            {
                if ($.$sris.System.Runtime.InteropServices.Marshalling.ComInterfaceMarshaller$$(T).TargetInterfaceIID === null)
                {
                    return $.$spc.System.IntPtr.op_Explicit$3(unknown);
                }
                /*nint*/ let interfacePointer;
                if ($.$spc.System.Runtime.InteropServices.Marshal.QueryInterface(unknown, $.$spc.System.Nullable.GetValueRefOrDefaultRef($.$spc.System.Guid, $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateObjectReferenceT($.$typeNullable($.$spc.System.Guid), () => $.$sris.System.Runtime.InteropServices.Marshalling.ComInterfaceMarshaller$$(T).TargetInterfaceIID, ($v) => $.$sris.System.Runtime.InteropServices.Marshalling.ComInterfaceMarshaller$$(T).TargetInterfaceIID = $v, null)), $.$ref(() => interfacePointer, ($v) => interfacePointer = $v, $.$spc.System.IntPtr)) !== 0)
                {
                    $.$spc.System.Runtime.InteropServices.Marshal.Release(unknown);
                    throw new $.$spc.System.InvalidCastException().$ctor$10((() =>
                    {
                        var $handler = new $.$spc.System.Runtime.CompilerServices.DefaultInterpolatedStringHandler().$ctor$2(2, 1);
                        $handler.AppendLiteral("Unable to cast the provided managed object to a COM interface with ID '");
                        $handler.AppendFormatted$8($.$box($.$spc.System.Nullable$$($.$spc.System.Guid).GetValueOrDefault.call($.$sris.System.Runtime.InteropServices.Marshalling.ComInterfaceMarshaller$$(T).TargetInterfaceIID), $.$spc.System.Guid), null, "B");
                        $handler.AppendLiteral("'");
                        return $handler.ToStringAndClear();
                    })());
                }
                $.$spc.System.Runtime.InteropServices.Marshal.Release(unknown);
                return $.$spc.System.IntPtr.op_Explicit$3(interfacePointer);
            }
            //Static Initializer
            static $sinit()
            {
                {
                    this.TargetInterfaceIID = ($.$sris.System.Runtime.InteropServices.Marshalling.StrategyBasedComWrappers.DefaultIUnknownInterfaceDetailsStrategy.System$Runtime$InteropServices$Marshalling$IIUnknownInterfaceDetailsStrategy$GetIUnknownDerivedDetails(T.$type.TypeHandle)?.System$Runtime$InteropServices$Marshalling$IIUnknownDerivedDetails$Iid ?? null);
                }
            }
            static $h = 2071448;
            static $g = 1;
            static $f = 0b1010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"m":[{"r":0,"p":[{"n":"managed","p":T?.$h??1507328}],"n":"ConvertToUnmanaged","d":this.$h,"h":Number(BigInt(this.$h)|0x200000000n),"f":33},{"r":T?.$h??1507328,"p":[{"n":"unmanaged","p":0}],"n":"ConvertToManaged","d":this.$h,"h":Number(BigInt(this.$h)|0x300000000n),"f":33},{"r":65537,"p":[{"n":"unmanaged","p":0}],"n":"Free","d":this.$h,"h":Number(BigInt(this.$h)|0x400000000n),"f":33},{"r":0,"p":[{"n":"unknown","p":786433}],"n":"CastIUnknownToInterfaceType","d":this.$h,"h":Number(BigInt(this.$h)|0x500000000n),"f":40}],"l":[{"t":$.$typeNullable($.$spc.System.Guid).$h,"n":"TargetInterfaceIID","d":this.$h,"h":Number(BigInt(this.$h)|0x100000000n),"f":34}],"g":[T?.$h??1507328],"r":1,"h":this.$h,"a":[{"t":115277825,"c":4410245121,"a":[{"v":"android","t":1310721}]},{"t":115277825,"c":4410245121,"a":[{"v":"browser","t":1310721}]},{"t":115277825,"c":4410245121,"a":[{"v":"ios","t":1310721}]},{"t":115277825,"c":4410245121,"a":[{"v":"tvos","t":1310721}]},{"t":23396353,"c":8613330945,"a":[{"v":false,"t":262145}]},{"t":106823681,"c":4401790977,"a":[{"v":106889217,"t":142606337},{"v":0,"t":106954753},{"v":$.$sris.System.Runtime.InteropServices.Marshalling.ComInterfaceMarshaller$$().$h,"t":142606337}]}]}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.Runtime.InteropServices.Marshalling.ComInterfaceMarshaller<${T?.$fullName}>`; }
        }));
        
        $asm.$cls("$sris.System.Security.SecureStringMarshal", ($self) => class SecureStringMarshal
        {
            static /*IntPtr */ SecureStringToCoTaskMemAnsi(/*SecureString*/ s)
            {
                return $.$spc.System.Runtime.InteropServices.Marshal.SecureStringToCoTaskMemAnsi(s);
            }
            static /*IntPtr */ SecureStringToGlobalAllocAnsi(/*SecureString*/ s)
            {
                return $.$spc.System.Runtime.InteropServices.Marshal.SecureStringToGlobalAllocAnsi(s);
            }
            static /*IntPtr */ SecureStringToCoTaskMemUnicode(/*SecureString*/ s)
            {
                return $.$spc.System.Runtime.InteropServices.Marshal.SecureStringToCoTaskMemUnicode(s);
            }
            static /*IntPtr */ SecureStringToGlobalAllocUnicode(/*SecureString*/ s)
            {
                return $.$spc.System.Runtime.InteropServices.Marshal.SecureStringToGlobalAllocUnicode(s);
            }
            static $h = 4627352;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"m":[{"r":786433,"p":[{"n":"s","p":117309441}],"n":"SecureStringToCoTaskMemAnsi","d":4627352,"h":4299594648,"f":33},{"r":786433,"p":[{"n":"s","p":117309441}],"n":"SecureStringToGlobalAllocAnsi","d":4627352,"h":8594561944,"f":33},{"r":786433,"p":[{"n":"s","p":117309441}],"n":"SecureStringToCoTaskMemUnicode","d":4627352,"h":12889529240,"f":33},{"r":786433,"p":[{"n":"s","p":117309441}],"n":"SecureStringToGlobalAllocUnicode","d":4627352,"h":17184496536,"f":33}],"h":4627352}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.Security.SecureStringMarshal`; }
        });
        
        $asm.$cls("$sris.System.Obsoletions", ($self) => class Obsoletions
        {
            /*string*/ static SharedUrlFormat = null;
            /*string*/ static SystemTextEncodingUTF7Message = null;
            /*string*/ static SystemTextEncodingUTF7DiagId = null;
            /*string*/ static PrincipalPermissionAttributeMessage = null;
            /*string*/ static PrincipalPermissionAttributeDiagId = null;
            /*string*/ static CodeAccessSecurityMessage = null;
            /*string*/ static CodeAccessSecurityDiagId = null;
            /*string*/ static ConstrainedExecutionRegionMessage = null;
            /*string*/ static ConstrainedExecutionRegionDiagId = null;
            /*string*/ static GlobalAssemblyCacheMessage = null;
            /*string*/ static GlobalAssemblyCacheDiagId = null;
            /*string*/ static ThreadAbortMessage = null;
            /*string*/ static ThreadResetAbortMessage = null;
            /*string*/ static ThreadAbortDiagId = null;
            /*string*/ static DefaultCryptoAlgorithmsMessage = null;
            /*string*/ static DefaultCryptoAlgorithmsDiagId = null;
            /*string*/ static CreatePdbGeneratorMessage = null;
            /*string*/ static CreatePdbGeneratorDiagId = null;
            /*string*/ static AuthenticationManagerMessage = null;
            /*string*/ static AuthenticationManagerDiagId = null;
            /*string*/ static RemotingApisMessage = null;
            /*string*/ static RemotingApisDiagId = null;
            /*string*/ static BinaryFormatterMessage = null;
            /*string*/ static BinaryFormatterDiagId = null;
            /*string*/ static CodeBaseMessage = null;
            /*string*/ static CodeBaseDiagId = null;
            /*string*/ static EscapeUriStringMessage = null;
            /*string*/ static EscapeUriStringDiagId = null;
            /*string*/ static WebRequestMessage = null;
            /*string*/ static WebRequestDiagId = null;
            /*string*/ static DisablePrivateReflectionAttributeMessage = null;
            /*string*/ static DisablePrivateReflectionAttributeDiagId = null;
            /*string*/ static GetContextInfoMessage = null;
            /*string*/ static GetContextInfoDiagId = null;
            /*string*/ static StrongNameKeyPairMessage = null;
            /*string*/ static StrongNameKeyPairDiagId = null;
            /*string*/ static ReflectionOnlyLoadingMessage = null;
            /*string*/ static ReflectionOnlyLoadingDiagId = null;
            /*string*/ static RuntimeEnvironmentMessage = null;
            /*string*/ static RuntimeEnvironmentDiagId = null;
            /*string*/ static JsonSerializerOptionsIgnoreNullValuesMessage = null;
            /*string*/ static JsonSerializerOptionsIgnoreNullValuesDiagId = null;
            /*string*/ static DerivedCryptographicTypesMessage = null;
            /*string*/ static DerivedCryptographicTypesDiagId = null;
            /*string*/ static RijndaelMessage = null;
            /*string*/ static RijndaelDiagId = null;
            /*string*/ static RNGCryptoServiceProviderMessage = null;
            /*string*/ static RNGCryptoServiceProviderDiagId = null;
            /*string*/ static AppDomainCreateUnloadMessage = null;
            /*string*/ static AppDomainCreateUnloadDiagId = null;
            /*string*/ static SuppressIldasmAttributeMessage = null;
            /*string*/ static SuppressIldasmAttributeDiagId = null;
            /*string*/ static X509CertificateImmutableMessage = null;
            /*string*/ static X509CertificateImmutableDiagId = null;
            /*string*/ static PublicKeyPropertyMessage = null;
            /*string*/ static PublicKeyPropertyDiagId = null;
            /*string*/ static X509CertificatePrivateKeyMessage = null;
            /*string*/ static X509CertificatePrivateKeyDiagId = null;
            /*string*/ static ProduceLegacyHmacValuesMessage = null;
            /*string*/ static ProduceLegacyHmacValuesDiagId = null;
            /*string*/ static UseManagedSha1Message = null;
            /*string*/ static UseManagedSha1DiagId = null;
            /*string*/ static CryptoConfigEncodeOIDMessage = null;
            /*string*/ static CryptoConfigEncodeOIDDiagId = null;
            /*string*/ static CorruptedStateRecoveryMessage = null;
            /*string*/ static CorruptedStateRecoveryDiagId = null;
            /*string*/ static Rfc2898CryptDeriveKeyMessage = null;
            /*string*/ static Rfc2898CryptDeriveKeyDiagId = null;
            /*string*/ static CmsSignerCspParamsCtorMessage = null;
            /*string*/ static CmsSignerCspParamsCtorDiagId = null;
            /*string*/ static SignerInfoCounterSigMessage = null;
            /*string*/ static SignerInfoCounterSigDiagId = null;
            /*string*/ static RegexCompileToAssemblyMessage = null;
            /*string*/ static RegexCompileToAssemblyDiagId = null;
            /*string*/ static AssemblyNameMembersMessage = null;
            /*string*/ static AssemblyNameMembersDiagId = null;
            /*string*/ static SystemDataSerializationFormatBinaryMessage = null;
            /*string*/ static SystemDataSerializationFormatBinaryDiagId = null;
            /*string*/ static TlsVersion10and11Message = null;
            /*string*/ static TlsVersion10and11DiagId = null;
            /*string*/ static EncryptionPolicyMessage = null;
            /*string*/ static EncryptionPolicyDiagId = null;
            /*string*/ static EccXmlExportImportMessage = null;
            /*string*/ static EccXmlExportImportDiagId = null;
            /*string*/ static EcDhPublicKeyBlobMessage = null;
            /*string*/ static EcDhPublicKeyBlobDiagId = null;
            /*string*/ static AssemblyNameCodeBaseMessage = null;
            /*string*/ static AssemblyNameCodeBaseDiagId = null;
            /*string*/ static CryptoStringFactoryMessage = null;
            /*string*/ static CryptoStringFactoryDiagId = null;
            /*string*/ static ControlledExecutionRunMessage = null;
            /*string*/ static ControlledExecutionRunDiagId = null;
            /*string*/ static XmlSecureResolverMessage = null;
            /*string*/ static XmlSecureResolverDiagId = null;
            /*string*/ static RsaEncryptDecryptValueMessage = null;
            /*string*/ static RsaEncryptDecryptDiagId = null;
            /*string*/ static JsonSerializerOptionsAddContextMessage = null;
            /*string*/ static JsonSerializerOptionsAddContextDiagId = null;
            /*string*/ static LegacyFormatterMessage = null;
            /*string*/ static LegacyFormatterDiagId = null;
            /*string*/ static LegacyFormatterImplMessage = null;
            /*string*/ static LegacyFormatterImplDiagId = null;
            /*string*/ static RegexExtensibilityImplMessage = null;
            /*string*/ static RegexExtensibilityDiagId = null;
            /*string*/ static AesGcmTagConstructorMessage = null;
            /*string*/ static AesGcmTagConstructorDiagId = null;
            /*string*/ static ThreadVolatileReadWriteMessage = null;
            /*string*/ static ThreadVolatileReadWriteDiagId = null;
            /*string*/ static ArmIntrinsicPerformsUnsignedOperationMessage = null;
            /*string*/ static ArmIntrinsicPerformsUnsignedOperationDiagId = null;
            /*string*/ static LoadFromHashAlgorithmMessage = null;
            /*string*/ static LoadFromHashAlgorithmDiagId = null;
            /*string*/ static X509CtorCertDataObsoleteMessage = null;
            /*string*/ static X509CtorCertDataObsoleteDiagId = null;
            /*string*/ static TlsCipherAlgorithmEnumsMessage = null;
            /*string*/ static TlsCipherAlgorithmEnumsDiagId = null;
            /*string*/ static SystemEventsEventsThreadShutdownMessage = null;
            /*string*/ static SystemEventsEventsThreadShutdownDiagId = null;
            /*string*/ static Rfc2898DeriveBytesCtorMessage = null;
            /*string*/ static Rfc2898DeriveBytesCtorDiagId = null;
            /*string*/ static QueryableMinByMaxByTSourceObsoleteMessage = null;
            /*string*/ static QueryableMinByMaxByTSourceObsoleteDiagId = null;
            /*string*/ static XsltSettingsEnableScriptMessage = null;
            /*string*/ static XsltSettingsEnableScriptDiagId = null;
            //Static Initializer
            static $sinit()
            {
                {
                    this.SharedUrlFormat = "https://aka.ms/dotnet-warnings/{0}";
                }
                {
                    this.SystemTextEncodingUTF7Message = "The UTF-7 encoding is insecure and should not be used. Consider using UTF-8 instead.";
                }
                {
                    this.SystemTextEncodingUTF7DiagId = "SYSLIB0001";
                }
                {
                    this.PrincipalPermissionAttributeMessage = "PrincipalPermissionAttribute is not honored by the runtime and must not be used.";
                }
                {
                    this.PrincipalPermissionAttributeDiagId = "SYSLIB0002";
                }
                {
                    this.CodeAccessSecurityMessage = "Code Access Security is not supported or honored by the runtime.";
                }
                {
                    this.CodeAccessSecurityDiagId = "SYSLIB0003";
                }
                {
                    this.ConstrainedExecutionRegionMessage = "The Constrained Execution Region (CER) feature is not supported.";
                }
                {
                    this.ConstrainedExecutionRegionDiagId = "SYSLIB0004";
                }
                {
                    this.GlobalAssemblyCacheMessage = "The Global Assembly Cache is not supported.";
                }
                {
                    this.GlobalAssemblyCacheDiagId = "SYSLIB0005";
                }
                {
                    this.ThreadAbortMessage = "Thread.Abort is not supported and throws PlatformNotSupportedException.";
                }
                {
                    this.ThreadResetAbortMessage = "Thread.ResetAbort is not supported and throws PlatformNotSupportedException.";
                }
                {
                    this.ThreadAbortDiagId = "SYSLIB0006";
                }
                {
                    this.DefaultCryptoAlgorithmsMessage = "The default implementation of this cryptography algorithm is not supported.";
                }
                {
                    this.DefaultCryptoAlgorithmsDiagId = "SYSLIB0007";
                }
                {
                    this.CreatePdbGeneratorMessage = "The CreatePdbGenerator API is not supported and throws PlatformNotSupportedException.";
                }
                {
                    this.CreatePdbGeneratorDiagId = "SYSLIB0008";
                }
                {
                    this.AuthenticationManagerMessage = "AuthenticationManager is not supported. Methods will no-op or throw PlatformNotSupportedException.";
                }
                {
                    this.AuthenticationManagerDiagId = "SYSLIB0009";
                }
                {
                    this.RemotingApisMessage = "This Remoting API is not supported and throws PlatformNotSupportedException.";
                }
                {
                    this.RemotingApisDiagId = "SYSLIB0010";
                }
                {
                    this.BinaryFormatterMessage = "BinaryFormatter serialization is obsolete and should not be used. See https://aka.ms/binaryformatter for more information.";
                }
                {
                    this.BinaryFormatterDiagId = "SYSLIB0011";
                }
                {
                    this.CodeBaseMessage = "Assembly.CodeBase and Assembly.EscapedCodeBase are only included for .NET Framework compatibility. Use Assembly.Location instead.";
                }
                {
                    this.CodeBaseDiagId = "SYSLIB0012";
                }
                {
                    this.EscapeUriStringMessage = "Uri.EscapeUriString can corrupt the Uri string in some cases. Consider using Uri.EscapeDataString for query string components instead.";
                }
                {
                    this.EscapeUriStringDiagId = "SYSLIB0013";
                }
                {
                    this.WebRequestMessage = "WebRequest, HttpWebRequest, ServicePoint, and WebClient are obsolete. Use HttpClient instead.";
                }
                {
                    this.WebRequestDiagId = "SYSLIB0014";
                }
                {
                    this.DisablePrivateReflectionAttributeMessage = "DisablePrivateReflectionAttribute has no effect in .NET 6.0+.";
                }
                {
                    this.DisablePrivateReflectionAttributeDiagId = "SYSLIB0015";
                }
                {
                    this.GetContextInfoMessage = "Use the Graphics.GetContextInfo overloads that accept arguments for better performance and fewer allocations.";
                }
                {
                    this.GetContextInfoDiagId = "SYSLIB0016";
                }
                {
                    this.StrongNameKeyPairMessage = "Strong name signing is not supported and throws PlatformNotSupportedException.";
                }
                {
                    this.StrongNameKeyPairDiagId = "SYSLIB0017";
                }
                {
                    this.ReflectionOnlyLoadingMessage = "ReflectionOnly loading is not supported and throws PlatformNotSupportedException.";
                }
                {
                    this.ReflectionOnlyLoadingDiagId = "SYSLIB0018";
                }
                {
                    this.RuntimeEnvironmentMessage = "RuntimeEnvironment members SystemConfigurationFile, GetRuntimeInterfaceAsIntPtr, and GetRuntimeInterfaceAsObject are not supported and throw PlatformNotSupportedException.";
                }
                {
                    this.RuntimeEnvironmentDiagId = "SYSLIB0019";
                }
                {
                    this.JsonSerializerOptionsIgnoreNullValuesMessage = "JsonSerializerOptions.IgnoreNullValues is obsolete. To ignore null values when serializing, set DefaultIgnoreCondition to JsonIgnoreCondition.WhenWritingNull.";
                }
                {
                    this.JsonSerializerOptionsIgnoreNullValuesDiagId = "SYSLIB0020";
                }
                {
                    this.DerivedCryptographicTypesMessage = "Derived cryptographic types are obsolete. Use the Create method on the base type instead.";
                }
                {
                    this.DerivedCryptographicTypesDiagId = "SYSLIB0021";
                }
                {
                    this.RijndaelMessage = "The Rijndael and RijndaelManaged types are obsolete. Use Aes instead.";
                }
                {
                    this.RijndaelDiagId = "SYSLIB0022";
                }
                {
                    this.RNGCryptoServiceProviderMessage = "RNGCryptoServiceProvider is obsolete. To generate a random number, use one of the RandomNumberGenerator static methods instead.";
                }
                {
                    this.RNGCryptoServiceProviderDiagId = "SYSLIB0023";
                }
                {
                    this.AppDomainCreateUnloadMessage = "Creating and unloading AppDomains is not supported and throws an exception.";
                }
                {
                    this.AppDomainCreateUnloadDiagId = "SYSLIB0024";
                }
                {
                    this.SuppressIldasmAttributeMessage = "SuppressIldasmAttribute has no effect in .NET 6.0+.";
                }
                {
                    this.SuppressIldasmAttributeDiagId = "SYSLIB0025";
                }
                {
                    this.X509CertificateImmutableMessage = "X509Certificate and X509Certificate2 are immutable. Use X509CertificateLoader to create a new certificate.";
                }
                {
                    this.X509CertificateImmutableDiagId = "SYSLIB0026";
                }
                {
                    this.PublicKeyPropertyMessage = "PublicKey.Key is obsolete. Use the appropriate method to get the public key, such as GetRSAPublicKey.";
                }
                {
                    this.PublicKeyPropertyDiagId = "SYSLIB0027";
                }
                {
                    this.X509CertificatePrivateKeyMessage = "X509Certificate2.PrivateKey is obsolete. Use the appropriate method to get the private key, such as GetRSAPrivateKey, or use the CopyWithPrivateKey method to create a new instance with a private key.";
                }
                {
                    this.X509CertificatePrivateKeyDiagId = "SYSLIB0028";
                }
                {
                    this.ProduceLegacyHmacValuesMessage = "ProduceLegacyHmacValues is obsolete. Producing legacy HMAC values is not supported.";
                }
                {
                    this.ProduceLegacyHmacValuesDiagId = "SYSLIB0029";
                }
                {
                    this.UseManagedSha1Message = "HMACSHA1 always uses the algorithm implementation provided by the platform. Use a constructor without the useManagedSha1 parameter.";
                }
                {
                    this.UseManagedSha1DiagId = "SYSLIB0030";
                }
                {
                    this.CryptoConfigEncodeOIDMessage = "EncodeOID is obsolete. Use the ASN.1 functionality provided in System.Formats.Asn1.";
                }
                {
                    this.CryptoConfigEncodeOIDDiagId = "SYSLIB0031";
                }
                {
                    this.CorruptedStateRecoveryMessage = "Recovery from corrupted process state exceptions is not supported; HandleProcessCorruptedStateExceptionsAttribute is ignored.";
                }
                {
                    this.CorruptedStateRecoveryDiagId = "SYSLIB0032";
                }
                {
                    this.Rfc2898CryptDeriveKeyMessage = "Rfc2898DeriveBytes.CryptDeriveKey is obsolete and is not supported. Use PasswordDeriveBytes.CryptDeriveKey instead.";
                }
                {
                    this.Rfc2898CryptDeriveKeyDiagId = "SYSLIB0033";
                }
                {
                    this.CmsSignerCspParamsCtorMessage = "CmsSigner(CspParameters) is obsolete and is not supported. Use an alternative constructor instead.";
                }
                {
                    this.CmsSignerCspParamsCtorDiagId = "SYSLIB0034";
                }
                {
                    this.SignerInfoCounterSigMessage = "ComputeCounterSignature without specifying a CmsSigner is obsolete and is not supported. Use the overload that accepts a CmsSigner.";
                }
                {
                    this.SignerInfoCounterSigDiagId = "SYSLIB0035";
                }
                {
                    this.RegexCompileToAssemblyMessage = "Regex.CompileToAssembly is obsolete and not supported. Use the GeneratedRegexAttribute with the regular expression source generator instead.";
                }
                {
                    this.RegexCompileToAssemblyDiagId = "SYSLIB0036";
                }
                {
                    this.AssemblyNameMembersMessage = "AssemblyName members HashAlgorithm, ProcessorArchitecture, and VersionCompatibility are obsolete and not supported.";
                }
                {
                    this.AssemblyNameMembersDiagId = "SYSLIB0037";
                }
                {
                    this.SystemDataSerializationFormatBinaryMessage = "SerializationFormat.Binary is obsolete and should not be used. See https://aka.ms/serializationformat-binary-obsolete for more information.";
                }
                {
                    this.SystemDataSerializationFormatBinaryDiagId = "SYSLIB0038";
                }
                {
                    this.TlsVersion10and11Message = "TLS versions 1.0 and 1.1 have known vulnerabilities and are not recommended. Use a newer TLS version instead, or use SslProtocols.None to defer to OS defaults.";
                }
                {
                    this.TlsVersion10and11DiagId = "SYSLIB0039";
                }
                {
                    this.EncryptionPolicyMessage = "EncryptionPolicy.NoEncryption and AllowEncryption significantly reduce security and should not be used in production code.";
                }
                {
                    this.EncryptionPolicyDiagId = "SYSLIB0040";
                }
                {
                    this.EccXmlExportImportMessage = "ToXmlString and FromXmlString have no implementation for ECC types, and are obsolete. Use a standard import and export format such as ExportSubjectPublicKeyInfo or ImportSubjectPublicKeyInfo for public keys and ExportPkcs8PrivateKey or ImportPkcs8PrivateKey for private keys.";
                }
                {
                    this.EccXmlExportImportDiagId = "SYSLIB0042";
                }
                {
                    this.EcDhPublicKeyBlobMessage = "ECDiffieHellmanPublicKey.ToByteArray() and the associated constructor do not have a consistent and interoperable implementation on all platforms. Use ECDiffieHellmanPublicKey.ExportSubjectPublicKeyInfo() instead.";
                }
                {
                    this.EcDhPublicKeyBlobDiagId = "SYSLIB0043";
                }
                {
                    this.AssemblyNameCodeBaseMessage = "AssemblyName.CodeBase and AssemblyName.EscapedCodeBase are obsolete. Using them for loading an assembly is not supported.";
                }
                {
                    this.AssemblyNameCodeBaseDiagId = "SYSLIB0044";
                }
                {
                    this.CryptoStringFactoryMessage = "Cryptographic factory methods accepting an algorithm name are obsolete. Use the parameterless Create factory method on the algorithm type instead.";
                }
                {
                    this.CryptoStringFactoryDiagId = "SYSLIB0045";
                }
                {
                    this.ControlledExecutionRunMessage = "ControlledExecution.Run method may corrupt the process and should not be used in production code.";
                }
                {
                    this.ControlledExecutionRunDiagId = "SYSLIB0046";
                }
                {
                    this.XmlSecureResolverMessage = "XmlSecureResolver is obsolete. Use XmlResolver.ThrowingResolver instead when attempting to forbid XML external entity resolution.";
                }
                {
                    this.XmlSecureResolverDiagId = "SYSLIB0047";
                }
                {
                    this.RsaEncryptDecryptValueMessage = "RSA.EncryptValue and DecryptValue are not supported and throw NotSupportedException. Use RSA.Encrypt and RSA.Decrypt instead.";
                }
                {
                    this.RsaEncryptDecryptDiagId = "SYSLIB0048";
                }
                {
                    this.JsonSerializerOptionsAddContextMessage = "JsonSerializerOptions.AddContext is obsolete. To register a JsonSerializerContext, use either the TypeInfoResolver or TypeInfoResolverChain properties.";
                }
                {
                    this.JsonSerializerOptionsAddContextDiagId = "SYSLIB0049";
                }
                {
                    this.LegacyFormatterMessage = "Formatter-based serialization is obsolete and should not be used.";
                }
                {
                    this.LegacyFormatterDiagId = "SYSLIB0050";
                }
                {
                    this.LegacyFormatterImplMessage = "This API supports obsolete formatter-based serialization. It should not be called or extended by application code.";
                }
                {
                    this.LegacyFormatterImplDiagId = "SYSLIB0051";
                }
                {
                    this.RegexExtensibilityImplMessage = "This API supports obsolete mechanisms for Regex extensibility. It is not supported.";
                }
                {
                    this.RegexExtensibilityDiagId = "SYSLIB0052";
                }
                {
                    this.AesGcmTagConstructorMessage = "AesGcm should indicate the required tag size for encryption and decryption. Use a constructor that accepts the tag size.";
                }
                {
                    this.AesGcmTagConstructorDiagId = "SYSLIB0053";
                }
                {
                    this.ThreadVolatileReadWriteMessage = "Thread.VolatileRead and Thread.VolatileWrite are obsolete. Use Volatile.Read or Volatile.Write respectively instead.";
                }
                {
                    this.ThreadVolatileReadWriteDiagId = "SYSLIB0054";
                }
                {
                    this.ArmIntrinsicPerformsUnsignedOperationMessage = "The underlying hardware instruction does not perform a signed saturate narrowing operation, and it always returns an unsigned result. Use the unsigned overload instead.";
                }
                {
                    this.ArmIntrinsicPerformsUnsignedOperationDiagId = "SYSLIB0055";
                }
                {
                    this.LoadFromHashAlgorithmMessage = "LoadFrom with a custom AssemblyHashAlgorithm is obsolete. Use overloads without an AssemblyHashAlgorithm.";
                }
                {
                    this.LoadFromHashAlgorithmDiagId = "SYSLIB0056";
                }
                {
                    this.X509CtorCertDataObsoleteMessage = "Loading certificate data through the constructor or Import is obsolete. Use X509CertificateLoader instead to load certificates.";
                }
                {
                    this.X509CtorCertDataObsoleteDiagId = "SYSLIB0057";
                }
                {
                    this.TlsCipherAlgorithmEnumsMessage = "KeyExchangeAlgorithm, KeyExchangeStrength, CipherAlgorithm, CipherStrength, HashAlgorithm and HashStrength properties of SslStream are obsolete. Use NegotiatedCipherSuite instead.";
                }
                {
                    this.TlsCipherAlgorithmEnumsDiagId = "SYSLIB0058";
                }
                {
                    this.SystemEventsEventsThreadShutdownMessage = "SystemEvents.EventsThreadShutdown callbacks are not run before the process exits. Use AppDomain.ProcessExit instead.";
                }
                {
                    this.SystemEventsEventsThreadShutdownDiagId = "SYSLIB0059";
                }
                {
                    this.Rfc2898DeriveBytesCtorMessage = "The constructors on Rfc2898DeriveBytes are obsolete. Use the static Pbkdf2 method instead.";
                }
                {
                    this.Rfc2898DeriveBytesCtorDiagId = "SYSLIB0060";
                }
                {
                    this.QueryableMinByMaxByTSourceObsoleteMessage = "The Queryable MinBy and MaxBy taking an IComparer<TSource> are obsolete. Use the new ones that take an IComparer<TKey>.";
                }
                {
                    this.QueryableMinByMaxByTSourceObsoleteDiagId = "SYSLIB0061";
                }
                {
                    this.XsltSettingsEnableScriptMessage = "XSLT Script blocks are not supported.";
                }
                {
                    this.XsltSettingsEnableScriptDiagId = "SYSLIB0062";
                }
            }
            static $h = 105368;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"l":[{"t":1310721,"n":"SharedUrlFormat","d":105368,"h":4295072664,"f":40},{"t":1310721,"n":"SystemTextEncodingUTF7Message","d":105368,"h":8590039960,"f":40},{"t":1310721,"n":"SystemTextEncodingUTF7DiagId","d":105368,"h":12885007256,"f":40},{"t":1310721,"n":"PrincipalPermissionAttributeMessage","d":105368,"h":17179974552,"f":40},{"t":1310721,"n":"PrincipalPermissionAttributeDiagId","d":105368,"h":21474941848,"f":40},{"t":1310721,"n":"CodeAccessSecurityMessage","d":105368,"h":25769909144,"f":40},{"t":1310721,"n":"CodeAccessSecurityDiagId","d":105368,"h":30064876440,"f":40},{"t":1310721,"n":"ConstrainedExecutionRegionMessage","d":105368,"h":34359843736,"f":40},{"t":1310721,"n":"ConstrainedExecutionRegionDiagId","d":105368,"h":38654811032,"f":40},{"t":1310721,"n":"GlobalAssemblyCacheMessage","d":105368,"h":42949778328,"f":40},{"t":1310721,"n":"GlobalAssemblyCacheDiagId","d":105368,"h":47244745624,"f":40},{"t":1310721,"n":"ThreadAbortMessage","d":105368,"h":51539712920,"f":40},{"t":1310721,"n":"ThreadResetAbortMessage","d":105368,"h":55834680216,"f":40},{"t":1310721,"n":"ThreadAbortDiagId","d":105368,"h":60129647512,"f":40},{"t":1310721,"n":"DefaultCryptoAlgorithmsMessage","d":105368,"h":64424614808,"f":40},{"t":1310721,"n":"DefaultCryptoAlgorithmsDiagId","d":105368,"h":68719582104,"f":40},{"t":1310721,"n":"CreatePdbGeneratorMessage","d":105368,"h":73014549400,"f":40},{"t":1310721,"n":"CreatePdbGeneratorDiagId","d":105368,"h":77309516696,"f":40},{"t":1310721,"n":"AuthenticationManagerMessage","d":105368,"h":81604483992,"f":40},{"t":1310721,"n":"AuthenticationManagerDiagId","d":105368,"h":85899451288,"f":40},{"t":1310721,"n":"RemotingApisMessage","d":105368,"h":90194418584,"f":40},{"t":1310721,"n":"RemotingApisDiagId","d":105368,"h":94489385880,"f":40},{"t":1310721,"n":"BinaryFormatterMessage","d":105368,"h":98784353176,"f":40},{"t":1310721,"n":"BinaryFormatterDiagId","d":105368,"h":103079320472,"f":40},{"t":1310721,"n":"CodeBaseMessage","d":105368,"h":107374287768,"f":40},{"t":1310721,"n":"CodeBaseDiagId","d":105368,"h":111669255064,"f":40},{"t":1310721,"n":"EscapeUriStringMessage","d":105368,"h":115964222360,"f":40},{"t":1310721,"n":"EscapeUriStringDiagId","d":105368,"h":120259189656,"f":40},{"t":1310721,"n":"WebRequestMessage","d":105368,"h":124554156952,"f":40},{"t":1310721,"n":"WebRequestDiagId","d":105368,"h":128849124248,"f":40},{"t":1310721,"n":"DisablePrivateReflectionAttributeMessage","d":105368,"h":133144091544,"f":40},{"t":1310721,"n":"DisablePrivateReflectionAttributeDiagId","d":105368,"h":137439058840,"f":40},{"t":1310721,"n":"GetContextInfoMessage","d":105368,"h":141734026136,"f":40},{"t":1310721,"n":"GetContextInfoDiagId","d":105368,"h":146028993432,"f":40},{"t":1310721,"n":"StrongNameKeyPairMessage","d":105368,"h":150323960728,"f":40},{"t":1310721,"n":"StrongNameKeyPairDiagId","d":105368,"h":154618928024,"f":40},{"t":1310721,"n":"ReflectionOnlyLoadingMessage","d":105368,"h":158913895320,"f":40},{"t":1310721,"n":"ReflectionOnlyLoadingDiagId","d":105368,"h":163208862616,"f":40},{"t":1310721,"n":"RuntimeEnvironmentMessage","d":105368,"h":167503829912,"f":40},{"t":1310721,"n":"RuntimeEnvironmentDiagId","d":105368,"h":171798797208,"f":40},{"t":1310721,"n":"JsonSerializerOptionsIgnoreNullValuesMessage","d":105368,"h":176093764504,"f":40},{"t":1310721,"n":"JsonSerializerOptionsIgnoreNullValuesDiagId","d":105368,"h":180388731800,"f":40},{"t":1310721,"n":"DerivedCryptographicTypesMessage","d":105368,"h":184683699096,"f":40},{"t":1310721,"n":"DerivedCryptographicTypesDiagId","d":105368,"h":188978666392,"f":40},{"t":1310721,"n":"RijndaelMessage","d":105368,"h":193273633688,"f":40},{"t":1310721,"n":"RijndaelDiagId","d":105368,"h":197568600984,"f":40},{"t":1310721,"n":"RNGCryptoServiceProviderMessage","d":105368,"h":201863568280,"f":40},{"t":1310721,"n":"RNGCryptoServiceProviderDiagId","d":105368,"h":206158535576,"f":40},{"t":1310721,"n":"AppDomainCreateUnloadMessage","d":105368,"h":210453502872,"f":40},{"t":1310721,"n":"AppDomainCreateUnloadDiagId","d":105368,"h":214748470168,"f":40},{"t":1310721,"n":"SuppressIldasmAttributeMessage","d":105368,"h":219043437464,"f":40},{"t":1310721,"n":"SuppressIldasmAttributeDiagId","d":105368,"h":223338404760,"f":40},{"t":1310721,"n":"X509CertificateImmutableMessage","d":105368,"h":227633372056,"f":40},{"t":1310721,"n":"X509CertificateImmutableDiagId","d":105368,"h":231928339352,"f":40},{"t":1310721,"n":"PublicKeyPropertyMessage","d":105368,"h":236223306648,"f":40},{"t":1310721,"n":"PublicKeyPropertyDiagId","d":105368,"h":240518273944,"f":40},{"t":1310721,"n":"X509CertificatePrivateKeyMessage","d":105368,"h":244813241240,"f":40},{"t":1310721,"n":"X509CertificatePrivateKeyDiagId","d":105368,"h":249108208536,"f":40},{"t":1310721,"n":"ProduceLegacyHmacValuesMessage","d":105368,"h":253403175832,"f":40},{"t":1310721,"n":"ProduceLegacyHmacValuesDiagId","d":105368,"h":257698143128,"f":40},{"t":1310721,"n":"UseManagedSha1Message","d":105368,"h":261993110424,"f":40},{"t":1310721,"n":"UseManagedSha1DiagId","d":105368,"h":266288077720,"f":40},{"t":1310721,"n":"CryptoConfigEncodeOIDMessage","d":105368,"h":270583045016,"f":40},{"t":1310721,"n":"CryptoConfigEncodeOIDDiagId","d":105368,"h":274878012312,"f":40},{"t":1310721,"n":"CorruptedStateRecoveryMessage","d":105368,"h":279172979608,"f":40},{"t":1310721,"n":"CorruptedStateRecoveryDiagId","d":105368,"h":283467946904,"f":40},{"t":1310721,"n":"Rfc2898CryptDeriveKeyMessage","d":105368,"h":287762914200,"f":40},{"t":1310721,"n":"Rfc2898CryptDeriveKeyDiagId","d":105368,"h":292057881496,"f":40},{"t":1310721,"n":"CmsSignerCspParamsCtorMessage","d":105368,"h":296352848792,"f":40},{"t":1310721,"n":"CmsSignerCspParamsCtorDiagId","d":105368,"h":300647816088,"f":40},{"t":1310721,"n":"SignerInfoCounterSigMessage","d":105368,"h":304942783384,"f":40},{"t":1310721,"n":"SignerInfoCounterSigDiagId","d":105368,"h":309237750680,"f":40},{"t":1310721,"n":"RegexCompileToAssemblyMessage","d":105368,"h":313532717976,"f":40},{"t":1310721,"n":"RegexCompileToAssemblyDiagId","d":105368,"h":317827685272,"f":40},{"t":1310721,"n":"AssemblyNameMembersMessage","d":105368,"h":322122652568,"f":40},{"t":1310721,"n":"AssemblyNameMembersDiagId","d":105368,"h":326417619864,"f":40},{"t":1310721,"n":"SystemDataSerializationFormatBinaryMessage","d":105368,"h":330712587160,"f":40},{"t":1310721,"n":"SystemDataSerializationFormatBinaryDiagId","d":105368,"h":335007554456,"f":40},{"t":1310721,"n":"TlsVersion10and11Message","d":105368,"h":339302521752,"f":40},{"t":1310721,"n":"TlsVersion10and11DiagId","d":105368,"h":343597489048,"f":40},{"t":1310721,"n":"EncryptionPolicyMessage","d":105368,"h":347892456344,"f":40},{"t":1310721,"n":"EncryptionPolicyDiagId","d":105368,"h":352187423640,"f":40},{"t":1310721,"n":"EccXmlExportImportMessage","d":105368,"h":356482390936,"f":40},{"t":1310721,"n":"EccXmlExportImportDiagId","d":105368,"h":360777358232,"f":40},{"t":1310721,"n":"EcDhPublicKeyBlobMessage","d":105368,"h":365072325528,"f":40},{"t":1310721,"n":"EcDhPublicKeyBlobDiagId","d":105368,"h":369367292824,"f":40},{"t":1310721,"n":"AssemblyNameCodeBaseMessage","d":105368,"h":373662260120,"f":40},{"t":1310721,"n":"AssemblyNameCodeBaseDiagId","d":105368,"h":377957227416,"f":40},{"t":1310721,"n":"CryptoStringFactoryMessage","d":105368,"h":382252194712,"f":40},{"t":1310721,"n":"CryptoStringFactoryDiagId","d":105368,"h":386547162008,"f":40},{"t":1310721,"n":"ControlledExecutionRunMessage","d":105368,"h":390842129304,"f":40},{"t":1310721,"n":"ControlledExecutionRunDiagId","d":105368,"h":395137096600,"f":40},{"t":1310721,"n":"XmlSecureResolverMessage","d":105368,"h":399432063896,"f":40},{"t":1310721,"n":"XmlSecureResolverDiagId","d":105368,"h":403727031192,"f":40},{"t":1310721,"n":"RsaEncryptDecryptValueMessage","d":105368,"h":408021998488,"f":40},{"t":1310721,"n":"RsaEncryptDecryptDiagId","d":105368,"h":412316965784,"f":40},{"t":1310721,"n":"JsonSerializerOptionsAddContextMessage","d":105368,"h":416611933080,"f":40},{"t":1310721,"n":"JsonSerializerOptionsAddContextDiagId","d":105368,"h":420906900376,"f":40},{"t":1310721,"n":"LegacyFormatterMessage","d":105368,"h":425201867672,"f":40},{"t":1310721,"n":"LegacyFormatterDiagId","d":105368,"h":429496834968,"f":40},{"t":1310721,"n":"LegacyFormatterImplMessage","d":105368,"h":433791802264,"f":40},{"t":1310721,"n":"LegacyFormatterImplDiagId","d":105368,"h":438086769560,"f":40},{"t":1310721,"n":"RegexExtensibilityImplMessage","d":105368,"h":442381736856,"f":40},{"t":1310721,"n":"RegexExtensibilityDiagId","d":105368,"h":446676704152,"f":40},{"t":1310721,"n":"AesGcmTagConstructorMessage","d":105368,"h":450971671448,"f":40},{"t":1310721,"n":"AesGcmTagConstructorDiagId","d":105368,"h":455266638744,"f":40},{"t":1310721,"n":"ThreadVolatileReadWriteMessage","d":105368,"h":459561606040,"f":40},{"t":1310721,"n":"ThreadVolatileReadWriteDiagId","d":105368,"h":463856573336,"f":40},{"t":1310721,"n":"ArmIntrinsicPerformsUnsignedOperationMessage","d":105368,"h":468151540632,"f":40},{"t":1310721,"n":"ArmIntrinsicPerformsUnsignedOperationDiagId","d":105368,"h":472446507928,"f":40},{"t":1310721,"n":"LoadFromHashAlgorithmMessage","d":105368,"h":476741475224,"f":40},{"t":1310721,"n":"LoadFromHashAlgorithmDiagId","d":105368,"h":481036442520,"f":40},{"t":1310721,"n":"X509CtorCertDataObsoleteMessage","d":105368,"h":485331409816,"f":40},{"t":1310721,"n":"X509CtorCertDataObsoleteDiagId","d":105368,"h":489626377112,"f":40},{"t":1310721,"n":"TlsCipherAlgorithmEnumsMessage","d":105368,"h":493921344408,"f":40},{"t":1310721,"n":"TlsCipherAlgorithmEnumsDiagId","d":105368,"h":498216311704,"f":40},{"t":1310721,"n":"SystemEventsEventsThreadShutdownMessage","d":105368,"h":502511279000,"f":40},{"t":1310721,"n":"SystemEventsEventsThreadShutdownDiagId","d":105368,"h":506806246296,"f":40},{"t":1310721,"n":"Rfc2898DeriveBytesCtorMessage","d":105368,"h":511101213592,"f":40},{"t":1310721,"n":"Rfc2898DeriveBytesCtorDiagId","d":105368,"h":515396180888,"f":40},{"t":1310721,"n":"QueryableMinByMaxByTSourceObsoleteMessage","d":105368,"h":519691148184,"f":40},{"t":1310721,"n":"QueryableMinByMaxByTSourceObsoleteDiagId","d":105368,"h":523986115480,"f":40},{"t":1310721,"n":"XsltSettingsEnableScriptMessage","d":105368,"h":528281082776,"f":40},{"t":1310721,"n":"XsltSettingsEnableScriptDiagId","d":105368,"h":532576050072,"f":40}],"h":105368}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.Obsoletions`; }
        });
        
        $asm.$cls("$sris.System.Runtime.InteropServices.Marshalling.ComImportInteropInterfaceDetailsStrategy", ($self) => class ComImportInteropInterfaceDetailsStrategy extends $.$spc.System.Object
        {
            /*IIUnknownInterfaceDetailsStrategy*/ static Instance = null;
            /*ConditionalWeakTable<Type, Type>*/ _forwarderInterfaceCache = null;
            /*IComExposedDetails? */ GetComExposedTypeDetails(/*RuntimeTypeHandle*/ type)
            {
                return $.$sris.System.Runtime.InteropServices.Marshalling.DefaultIUnknownInterfaceDetailsStrategy.Instance.System$Runtime$InteropServices$Marshalling$IIUnknownInterfaceDetailsStrategy$GetComExposedTypeDetails(type);
            }
            /*IIUnknownDerivedDetails? */ GetIUnknownDerivedDetails(/*RuntimeTypeHandle*/ type)
            {
                /*Type*/ let runtimeType = $.$spc.System.Type.GetTypeFromHandle(type);
                if (!runtimeType.IsImport)
                {
                    return $.$sris.System.Runtime.InteropServices.Marshalling.DefaultIUnknownInterfaceDetailsStrategy.Instance.System$Runtime$InteropServices$Marshalling$IIUnknownInterfaceDetailsStrategy$GetIUnknownDerivedDetails(type);
                }
                /*Type*/ let implementationType = this._forwarderInterfaceCache.GetValue(runtimeType, new $.$spc.System.Runtime.CompilerServices.ConditionalWeakTable$$$($.$spc.System.Type, $.$spc.System.Type).CreateValueCallback().$ctor(this,  (/**/ runtimeType) =>
                {
                    /*AssemblyBuilder*/ let assembly = /*$.$spc.System.Reflection.Emit.AssemblyBuilder*/$.$spc.DeletedObject.DefineDynamicAssembly(new $.$spc.System.Reflection.AssemblyName().$ctor$1("ComImportForwarder"), runtimeType.IsCollectible ? 9/*AssemblyBuilderAccess.RunAndCollect*/ : 1/*AssemblyBuilderAccess.Run*/);
                    /*ModuleBuilder*/ let module = assembly.DefineDynamicModule("ComImportForwarder");
                    /*ConstructorInfo*/ let ignoresAccessChecksToAttributeConstructor = $.$sris.System.Runtime.InteropServices.Marshalling.ComImportInteropInterfaceDetailsStrategy.GetIgnoresAccessChecksToAttributeConstructor(module);
                    assembly.SetCustomAttribute$1(new CustomAttributeBuilder(ignoresAccessChecksToAttributeConstructor, $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$spc.System.Object), [$.$sris.System.Runtime.InteropServices.Marshalling.ComImportInteropInterfaceDetailsStrategy.IComImportAdapter.$type.Assembly.GetName().Name], [-1], null)));
                    /*TypeBuilder*/ let implementation = module.DefineType$3("InterfaceForwarder", 32/*TypeAttributes.Interface*/ | 128/*TypeAttributes.Abstract*/, null, runtimeType.GetInterfaces());
                    implementation.AddInterfaceImplementation(runtimeType);
                    implementation.SetCustomAttribute$1(new CustomAttributeBuilder($.$spc.System.Runtime.InteropServices.DynamicInterfaceCastableImplementationAttribute.$type.GetConstructor$1($.$spc.System.Array.Empty($.$spc.System.Type)), $.$spc.System.Array.Empty($.$spc.System.Object)));
                    let $i1 = 0;
                    let $arr1 = implementation.GetInterfaces();
                    while ($i1 < $arr1.length)
                    {
                        let iface = $arr1[$i1++];
                        assembly.SetCustomAttribute$1(new CustomAttributeBuilder(ignoresAccessChecksToAttributeConstructor, $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$spc.System.Object), [iface.Assembly.GetName().Name], [-1], null)));
                        let $i2 = 0;
                        let $arr2 = iface.GetMethods();
                        while ($i2 < $arr2.length)
                        {
                            let method = $arr2[$i2++];
                            /*Type[]*/ let returnTypeOptionalModifiers = method.ReturnParameter.GetOptionalCustomModifiers();
                            /*Type[]*/ let returnTypeRequiredModifiers = method.ReturnParameter.GetRequiredCustomModifiers();
                            /*ParameterInfo[]*/ let parameters = method.GetParameters();
                            /*var*/ let parameterTypes = $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$spc.System.Type), null, [parameters.length], null);
                            /*var*/ let parameterOptionalModifiers = $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$typeArray($.$spc.System.Type)), null, [parameters.length], null);
                            /*var*/ let parameterRequiredModifiers = $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$typeArray($.$spc.System.Type)), null, [parameters.length], null);
                            for(/*int*/ let i = 0; i < parameters.length; i++)
                            {
                                $.$spc.System.Array.$WriteT1.call(parameterTypes, $.$spc.System.Array.$ReadT1.call(parameters, i).ParameterType, i);
                                $.$spc.System.Array.$WriteT1.call(parameterOptionalModifiers, $.$spc.System.Array.$ReadT1.call(parameters, i).GetOptionalCustomModifiers(), i);
                                $.$spc.System.Array.$WriteT1.call(parameterRequiredModifiers, $.$spc.System.Array.$ReadT1.call(parameters, i).GetRequiredCustomModifiers(), i);
                            }
                            /*MethodBuilder*/ let builder = implementation.DefineMethod$4(method.Name, 1/*MethodAttributes.Private*/ | 32/*MethodAttributes.Final*/ | 128/*MethodAttributes.HideBySig*/ | 64/*MethodAttributes.Virtual*/, 32/*CallingConventions.HasThis*/, method.ReturnType, returnTypeRequiredModifiers, returnTypeOptionalModifiers, parameterTypes, parameterRequiredModifiers, parameterOptionalModifiers);
                            /*ILGenerator*/ let il = builder.GetILGenerator();
                            il.Emit(/*$.$spc.System.Reflection.Emit.OpCodes*/$.$spc.DeletedObject.Ldarg_0);
                            il.Emit$10(/*$.$spc.System.Reflection.Emit.OpCodes*/$.$spc.DeletedObject.Castclass, $.$sris.System.Runtime.InteropServices.Marshalling.ComImportInteropInterfaceDetailsStrategy.IComImportAdapter.$type);
                            il.Emit$7(/*$.$spc.System.Reflection.Emit.OpCodes*/$.$spc.DeletedObject.Callvirt, $.$sris.System.Runtime.InteropServices.Marshalling.ComImportInteropInterfaceDetailsStrategy.IComImportAdapter.$sris$System$Runtime$InteropServices$Marshalling$ComImportInteropInterfaceDetailsStrategy$IComImportAdapter$GetRuntimeCallableWrapperMethod);
                            il.Emit$10(/*$.$spc.System.Reflection.Emit.OpCodes*/$.$spc.DeletedObject.Castclass, iface);
                            for(/*int*/ let i = 0; i < parameters.length; i++)
                            {
                                il.Emit$6(/*$.$spc.System.Reflection.Emit.OpCodes*/$.$spc.DeletedObject.Ldarg, ((i + 1) | 0));
                            }
                            il.Emit$7(/*$.$spc.System.Reflection.Emit.OpCodes*/$.$spc.DeletedObject.Callvirt, method);
                            il.Emit(/*$.$spc.System.Reflection.Emit.OpCodes*/$.$spc.DeletedObject.Ret);
                            implementation.DefineMethodOverride(builder, method);
                        }
                    }
                    return implementation.CreateType();
                }));
                return new $.$sris.System.Runtime.InteropServices.Marshalling.ComImportInteropInterfaceDetailsStrategy.ComImportDetails().$ctor$1(runtimeType.GUID, implementationType);
            }
            /*ConstructorInfo*/ static s_attributeBaseClassCtor = null;
            /*ConstructorInfo*/ static s_attributeUsageCtor = null;
            /*PropertyInfo*/ static s_attributeUsageAllowMultipleProperty = null;
            static $_ComImportDetails;
            static get ComImportDetails()
            {
                let $cls = $.$sris.System.Runtime.InteropServices.Marshalling.ComImportInteropInterfaceDetailsStrategy;
                return $cls.$_ComImportDetails ??= $asm.$ncls("$sris.System.Runtime.InteropServices.Marshalling.ComImportInteropInterfaceDetailsStrategy.ComImportDetails", ($self) => class ComImportDetails extends $.$spc.System.Object
                {
                    /*Guid*/ Iid;
                    /*Type*/ Implementation = null;
                    /*void** */ get ManagedVirtualMethodTable()
                    {
                        return null;
                    }
                    //Generated interface implemetation for System.Runtime.InteropServices.Marshalling.IIUnknownDerivedDetails.Iid.get
                    get System$Runtime$InteropServices$Marshalling$IIUnknownDerivedDetails$Iid()
                    {
                        return this.Iid;
                    }
                    //Generated interface implemetation for System.Runtime.InteropServices.Marshalling.IIUnknownDerivedDetails.Implementation.get
                    get System$Runtime$InteropServices$Marshalling$IIUnknownDerivedDetails$Implementation()
                    {
                        return this.Implementation;
                    }
                    //Generated interface implemetation for System.Runtime.InteropServices.Marshalling.IIUnknownDerivedDetails.ManagedVirtualMethodTable.get
                    get System$Runtime$InteropServices$Marshalling$IIUnknownDerivedDetails$ManagedVirtualMethodTable()
                    {
                        return this.ManagedVirtualMethodTable;
                    }
                    //Begin primary constructor
                    /*Guid*/ iid = new $.$spc.System.Guid();
                    /*Type*/ implementation = null;
                    $ctor$1(/*Guid*/$iid, /*Type*/$implementation)
                    {
                        this.iid = $iid;
                        this.implementation = $implementation;
                        //depends on primary constructor parameter
                        this.Iid = this.iid;
                        //depends on primary constructor parameter
                        this.Implementation = this.implementation;
                        return this
                    }
                    //End primary constructor
                    static $h = 1940376;
                    static $f = 0b10000000010010000;
                    static $k = 1;
                    static $$md;
                    static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":56164353,"g":{"r":0,"d":0,"h":17181809560,"f":1},"n":"Iid","d":1940376,"h":12886842264,"f":1},{"p":142606337,"g":{"r":0,"d":0,"h":30066711448,"f":1},"n":"Implementation","d":1940376,"h":25771744152,"f":1},{"p":0,"g":{"r":0,"d":0,"h":38656646040,"f":1},"n":"ManagedVirtualMethodTable","d":1940376,"h":34361678744,"f":1}],"c":[{"p":[{"n":"iid","p":56164353},{"n":"implementation","p":142606337}],"n":".ctor","o":"$ctor$1","d":1940376,"h":4296907672,"f":1}],"i":[3251096],"d":1874840,"h":1940376}; }
                    static get $b() { return $.$spc.System.Object; }
                    static $$i;
                    static get $i() { return this.$$i ??= [ $.$sris.System.Runtime.InteropServices.Marshalling.IIUnknownDerivedDetails ]; }
                    static get $fullName() { return `System.Runtime.InteropServices.Marshalling.ComImportInteropInterfaceDetailsStrategy.ComImportDetails`; }
                }, $cls, ($v) => $cls.$_ComImportDetails = $v);
            }
            static $_IComImportAdapter;
            static get IComImportAdapter()
            {
                let $cls = $.$sris.System.Runtime.InteropServices.Marshalling.ComImportInteropInterfaceDetailsStrategy;
                return $cls.$_IComImportAdapter ??= $asm.$ncls("$sris.System.Runtime.InteropServices.Marshalling.ComImportInteropInterfaceDetailsStrategy.IComImportAdapter", ($self) => class IComImportAdapter
                {
                    /*MethodInfo*/ static $sris$System$Runtime$InteropServices$Marshalling$ComImportInteropInterfaceDetailsStrategy$IComImportAdapter$GetRuntimeCallableWrapperMethod = null;
                    //Static Initializer
                    static $sinit()
                    {
                        {
                            this.$sris$System$Runtime$InteropServices$Marshalling$ComImportInteropInterfaceDetailsStrategy$IComImportAdapter$GetRuntimeCallableWrapperMethod = $.$sris.System.Runtime.InteropServices.Marshalling.ComImportInteropInterfaceDetailsStrategy.IComImportAdapter.$type.GetMethod$1("GetRuntimeCallableWrapper");
                        }
                    }
                    static $h = 2005912;
                    static $f = 0b10000000000100100;
                    static $k = 3;
                    static $$md;
                    static get $md() { return this.$$md ??= {"m":[{"r":131073,"n":"GetRuntimeCallableWrapper","o":"System$Runtime$InteropServices$Marshalling$ComImportInteropInterfaceDetailsStrategy$IComImportAdapter$GetRuntimeCallableWrapper","d":2005912,"h":8591940504,"f":257}],"l":[{"t":79626241,"n":"GetRuntimeCallableWrapperMethod","o":"$sris$System$Runtime$InteropServices$Marshalling$ComImportInteropInterfaceDetailsStrategy$IComImportAdapter$GetRuntimeCallableWrapperMethod","d":2005912,"h":4296973208,"f":40}],"d":1874840,"h":2005912}; }
                    static get $fullName() { return `System.Runtime.InteropServices.Marshalling.ComImportInteropInterfaceDetailsStrategy.IComImportAdapter`; }
                }, $cls, ($v) => $cls.$_IComImportAdapter = $v);
            }
            //Generated interface implemetation for System.Runtime.InteropServices.Marshalling.IIUnknownInterfaceDetailsStrategy.GetIUnknownDerivedDetails(System.RuntimeTypeHandle)
            System$Runtime$InteropServices$Marshalling$IIUnknownInterfaceDetailsStrategy$GetIUnknownDerivedDetails()
            {
                return this.GetIUnknownDerivedDetails(...arguments);
            }
            //Generated interface implemetation for System.Runtime.InteropServices.Marshalling.IIUnknownInterfaceDetailsStrategy.GetComExposedTypeDetails(System.RuntimeTypeHandle)
            System$Runtime$InteropServices$Marshalling$IIUnknownInterfaceDetailsStrategy$GetComExposedTypeDetails()
            {
                return this.GetComExposedTypeDetails(...arguments);
            }
            //default reference type constructor overload
            $ctor$1()
            {
                super.$ctor();
                return this;
            }
            //default member initializer
            constructor()
            {
                super();
                this._forwarderInterfaceCache = new ($.$spc.System.Runtime.CompilerServices.ConditionalWeakTable$$$($.$spc.System.Type, $.$spc.System.Type))().$ctor$1();
            }
            //Static Initializer
            static $sinit()
            {
                {
                    this.Instance = new $.$sris.System.Runtime.InteropServices.Marshalling.ComImportInteropInterfaceDetailsStrategy().$ctor$1();
                }
                {
                    this.s_attributeBaseClassCtor = $.$spc.System.Array.$ReadT1.call($.$spc.System.Attribute.$type.GetConstructors$1(32/*BindingFlags.NonPublic*/ | 4/*BindingFlags.Instance*/), 0);
                }
                {
                    this.s_attributeUsageCtor = $.$spc.System.AttributeUsageAttribute.$type.GetConstructor$1($.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$spc.System.Type), [$.$spc.System.AttributeTargets.$type], [-1], null));
                }
                {
                    this.s_attributeUsageAllowMultipleProperty = $.$spc.System.AttributeUsageAttribute.$type.GetProperty("AllowMultiple");
                }
            }
            static $h = 1874840;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"m":[{"r":3054488,"p":[{"n":"type","p":116064257}],"n":"GetComExposedTypeDetails","d":1874840,"h":12886776728,"f":1},{"r":3251096,"p":[{"n":"type","p":116064257}],"n":"GetIUnknownDerivedDetails","d":1874840,"h":17181744024,"f":1},{"r":75628545,"p":[{"n":"moduleBuilder"}],"n":"GetIgnoresAccessChecksToAttributeConstructor","d":1874840,"h":21476711320,"f":34},{"r":142606337,"p":[{"n":"moduleBuilder"}],"n":"EmitIgnoresAccessChecksToAttribute","d":1874840,"h":25771678616,"f":34}],"l":[{"t":3316632,"n":"Instance","d":1874840,"h":4296842136,"f":33},{"t":$.$spc.System.Runtime.CompilerServices.ConditionalWeakTable$$$($.$spc.System.Type, $.$spc.System.Type).$h,"n":"_forwarderInterfaceCache","d":1874840,"h":8591809432,"f":2},{"t":75628545,"n":"s_attributeBaseClassCtor","d":1874840,"h":30066645912,"f":34},{"t":75628545,"n":"s_attributeUsageCtor","d":1874840,"h":34361613208,"f":34},{"t":81657857,"n":"s_attributeUsageAllowMultipleProperty","d":1874840,"h":38656580504,"f":34}],"c":[{"n":".ctor","o":"$ctor$1","d":1874840,"h":51541482392,"f":1}],"i":[3316632],"j":[1940376,2005912],"h":1874840}; }
            static get $b() { return $.$spc.System.Object; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$sris.System.Runtime.InteropServices.Marshalling.IIUnknownInterfaceDetailsStrategy ]; }
            static get $fullName() { return `System.Runtime.InteropServices.Marshalling.ComImportInteropInterfaceDetailsStrategy`; }
        });
        
        $asm.$cls("$sris.System.Runtime.InteropServices.Marshalling.DefaultCaching", ($self) => class DefaultCaching extends $.$spc.System.Object
        {
            /*ConcurrentDictionary<RuntimeTypeHandle, IIUnknownCacheStrategy.TableInfo>*/ _cache = null;
            /*IIUnknownCacheStrategy.TableInfo */ System$Runtime$InteropServices$Marshalling$IIUnknownCacheStrategy$ConstructTableInfo(/*RuntimeTypeHandle*/ handle, /*IIUnknownDerivedDetails*/ details, /*void**/ ptr)
            {
                /*var*/ let obj = $.$cast(ptr, $.$typePointer($.$typePointer($.$typePointer($.$spc.System.Void))));
                return (() =>
                {
                    //new $.$sris.System.Runtime.InteropServices.Marshalling.IIUnknownCacheStrategy.TableInfo()
                    const $t1 = $.$sris.System.Runtime.InteropServices.Marshalling.IIUnknownCacheStrategy.TableInfo;
                    const $i1 = new $t1();
                    $i1.ThisPtr = obj;
                    $i1.Table = obj.$v;
                    $i1.ManagedType = details.System$Runtime$InteropServices$Marshalling$IIUnknownDerivedDetails$Implementation.TypeHandle;
                    return $i1;
                })();
            }
            /*bool */ System$Runtime$InteropServices$Marshalling$IIUnknownCacheStrategy$TryGetTableInfo(/*RuntimeTypeHandle*/ handle, /*out IIUnknownCacheStrategy.TableInfo*/ info)
            {
                return this._cache.TryGetValue(handle, info);
            }
            /*bool */ System$Runtime$InteropServices$Marshalling$IIUnknownCacheStrategy$TrySetTableInfo(/*RuntimeTypeHandle*/ handle, /*IIUnknownCacheStrategy.TableInfo*/ info)
            {
                return this._cache.TryAdd(handle, info);
            }
            /*void */ System$Runtime$InteropServices$Marshalling$IIUnknownCacheStrategy$Clear(/*IIUnknownStrategy*/ unknownStrategy)
            {
                var $en2 = this._cache.Values.System$Collections$Generic$IEnumerable$$$GetEnumerator();
                while ($en2.System$Collections$IEnumerator$MoveNext())
                {
                    var info = $en2.System$Collections$Generic$IEnumerator$$$Current;
                    {
                        _ = unknownStrategy.System$Runtime$InteropServices$Marshalling$IIUnknownStrategy$Release(info.ThisPtr);
                    }
                }
                this._cache.Clear();
            }
            //default reference type constructor overload
            $ctor$1()
            {
                super.$ctor();
                return this;
            }
            //default member initializer
            constructor()
            {
                super();
                this._cache = new ($.$scc.System.Collections.Concurrent.ConcurrentDictionary$$$($.$spc.System.RuntimeTypeHandle, $.$sris.System.Runtime.InteropServices.Marshalling.IIUnknownCacheStrategy.TableInfo))().$ctor$2(1, 16);
            }
            static $h = 2399128;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"l":[{"t":$.$scc.System.Collections.Concurrent.ConcurrentDictionary$$$($.$spc.System.RuntimeTypeHandle, $.$sris.System.Runtime.InteropServices.Marshalling.IIUnknownCacheStrategy.TableInfo).$h,"n":"_cache","d":2399128,"h":4297366424,"f":2}],"c":[{"n":".ctor","o":"$ctor$1","d":2399128,"h":25772202904,"f":1}],"i":[3120024],"h":2399128}; }
            static get $b() { return $.$spc.System.Object; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$sris.System.Runtime.InteropServices.Marshalling.IIUnknownCacheStrategy ]; }
            static get $fullName() { return `System.Runtime.InteropServices.Marshalling.DefaultCaching`; }
        });
        
        $asm.$cls("$sris.System.Runtime.InteropServices.Marshalling.DefaultIUnknownInterfaceDetailsStrategy", ($self) => class DefaultIUnknownInterfaceDetailsStrategy extends $.$spc.System.Object
        {
            /*IIUnknownInterfaceDetailsStrategy*/ static Instance = null;
            /*IComExposedDetails? */ GetComExposedTypeDetails(/*RuntimeTypeHandle*/ type)
            {
                return $.$sris.System.Runtime.InteropServices.Marshalling.IComExposedDetails.System$Runtime$InteropServices$Marshalling$IComExposedDetails$GetFromAttribute(type);
            }
            /*IIUnknownDerivedDetails? */ GetIUnknownDerivedDetails(/*RuntimeTypeHandle*/ type)
            {
                return $.$sris.System.Runtime.InteropServices.Marshalling.IIUnknownDerivedDetails.System$Runtime$InteropServices$Marshalling$IIUnknownDerivedDetails$GetFromAttribute(type);
            }
            //Generated interface implemetation for System.Runtime.InteropServices.Marshalling.IIUnknownInterfaceDetailsStrategy.GetIUnknownDerivedDetails(System.RuntimeTypeHandle)
            System$Runtime$InteropServices$Marshalling$IIUnknownInterfaceDetailsStrategy$GetIUnknownDerivedDetails()
            {
                return this.GetIUnknownDerivedDetails(...arguments);
            }
            //Generated interface implemetation for System.Runtime.InteropServices.Marshalling.IIUnknownInterfaceDetailsStrategy.GetComExposedTypeDetails(System.RuntimeTypeHandle)
            System$Runtime$InteropServices$Marshalling$IIUnknownInterfaceDetailsStrategy$GetComExposedTypeDetails()
            {
                return this.GetComExposedTypeDetails(...arguments);
            }
            //default reference type constructor overload
            $ctor$1()
            {
                super.$ctor();
                return this;
            }
            //Static Initializer
            static $sinit()
            {
                {
                    this.Instance = new $.$sris.System.Runtime.InteropServices.Marshalling.DefaultIUnknownInterfaceDetailsStrategy().$ctor$1();
                }
            }
            static $h = 2464664;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"m":[{"r":3054488,"p":[{"n":"type","p":116064257}],"n":"GetComExposedTypeDetails","d":2464664,"h":8592399256,"f":1},{"r":3251096,"p":[{"n":"type","p":116064257}],"n":"GetIUnknownDerivedDetails","d":2464664,"h":12887366552,"f":1}],"l":[{"t":3316632,"n":"Instance","d":2464664,"h":4297431960,"f":33}],"c":[{"n":".ctor","o":"$ctor$1","d":2464664,"h":17182333848,"f":1}],"i":[3316632],"h":2464664}; }
            static get $b() { return $.$spc.System.Object; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$sris.System.Runtime.InteropServices.Marshalling.IIUnknownInterfaceDetailsStrategy ]; }
            static get $fullName() { return `System.Runtime.InteropServices.Marshalling.DefaultIUnknownInterfaceDetailsStrategy`; }
        });
        
        $asm.$cls("$sris.System.Runtime.InteropServices.Marshalling.FreeThreadedStrategy", ($self) => class FreeThreadedStrategy extends $.$spc.System.Object
        {
            /*IIUnknownStrategy*/ static Instance = null;
            /*void* */ System$Runtime$InteropServices$Marshalling$IIUnknownStrategy$CreateInstancePointer(/*void**/ unknown)
            {
                $.$spc.System.Runtime.InteropServices.Marshal.AddRef($.$spc.System.IntPtr.op_Explicit$2(unknown));
                return unknown;
            }
            /*int */ System$Runtime$InteropServices$Marshalling$IIUnknownStrategy$QueryInterface(/*void**/ thisPtr, /*in Guid*/ handle, /*out void**/ ppObj)
            {
                /*nint*/ let ppv;
                /*int*/ let hr = $.$spc.System.Runtime.InteropServices.Marshal.QueryInterface($.$spc.System.IntPtr.op_Explicit$2(thisPtr), handle, $.$ref(() => ppv, ($v) => ppv = $v, $.$spc.System.IntPtr));
                if (hr < 0)
                {
                    ppObj.$v = null;
                }
                else 
                {
                    ppObj.$v = $.$spc.System.IntPtr.op_Explicit$3(ppv);
                }
                return hr;
            }
            /*int */ System$Runtime$InteropServices$Marshalling$IIUnknownStrategy$Release(/*void**/ thisPtr)
            {
                return $.$spc.System.Runtime.InteropServices.Marshal.Release($.$spc.System.IntPtr.op_Explicit$2(thisPtr));
            }
            //default reference type constructor overload
            $ctor$1()
            {
                super.$ctor();
                return this;
            }
            //Static Initializer
            static $sinit()
            {
                {
                    this.Instance = new $.$sris.System.Runtime.InteropServices.Marshalling.FreeThreadedStrategy().$ctor$1();
                }
            }
            static $h = 2792344;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"l":[{"t":3447704,"n":"Instance","d":2792344,"h":4297759640,"f":33}],"c":[{"n":".ctor","o":"$ctor$1","d":2792344,"h":21477628824,"f":1}],"i":[3447704],"h":2792344}; }
            static get $b() { return $.$spc.System.Object; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$sris.System.Runtime.InteropServices.Marshalling.IIUnknownStrategy ]; }
            static get $fullName() { return `System.Runtime.InteropServices.Marshalling.FreeThreadedStrategy`; }
        });
        
        $asm.$str("$sris.System.Runtime.InteropServices.ComTypes.FORMATETC", ($self) => class FORMATETC extends $.$spc.System.ValueType
        {
            /*short*/  get cfFormat() { return this.$getField(0, $.$spc.System.Int16); }
            /*short*/  set cfFormat(value) { this.$setField(0, $.$spc.System.Int16, value); }
            /*IntPtr*/  get ptd() { return this.$getField(2, $.$spc.System.IntPtr); }
            /*IntPtr*/  set ptd(value) { this.$setField(2, $.$spc.System.IntPtr, value); }
            /*DVASPECT*/  get dwAspect() { return this.$getField(6, $.$sris.System.Runtime.InteropServices.ComTypes.DVASPECT); }
            /*DVASPECT*/  set dwAspect(value) { this.$setField(6, $.$sris.System.Runtime.InteropServices.ComTypes.DVASPECT, value); }
            /*int*/  get lindex() { return this.$getField(10, $.$spc.System.Int32); }
            /*int*/  set lindex(value) { this.$setField(10, $.$spc.System.Int32, value); }
            /*TYMED*/  get tymed() { return this.$getField(14, $.$sris.System.Runtime.InteropServices.ComTypes.TYMED); }
            /*TYMED*/  set tymed(value) { this.$setField(14, $.$sris.System.Runtime.InteropServices.ComTypes.TYMED, value); }
            //default value type constructor
            $ctor$2()
            {
                return this;
            }
            Clone($copy)
            {
                let copy = $copy ?? new this.constructor();
                copy.cfFormat = this.cfFormat;
                copy.ptd = this.ptd;
                copy.dwAspect = this.dwAspect;
                copy.lindex = this.lindex;
                copy.tymed = this.tymed;
                return copy;
            }
            //default member initializer
            constructor()
            {
                super();
                this.cfFormat = 0;
                this.ptd = 0;
                this.dwAspect = 0;
                this.lindex = 0;
                this.tymed = 0;
            }
            static $h = 957336;
            static $z = 18;
            static $f = 0b10000000000001010000001;
            static $k = 2;
            static $$md;
            static get $md() { return this.$$md ??= {"b":196609,"l":[{"t":524289,"n":"cfFormat","d":957336,"h":4295924632,"f":1,"a":[{"t":105709569,"c":8695644161,"a":[{"v":6,"t":110886913}]}]},{"t":786433,"n":"ptd","d":957336,"h":8590891928,"f":1},{"t":891800,"n":"dwAspect","d":957336,"h":12885859224,"f":1,"a":[{"t":105709569,"c":8695644161,"a":[{"v":8,"t":110886913}]}]},{"t":655361,"n":"lindex","d":957336,"h":17180826520,"f":1},{"t":1416088,"n":"tymed","d":957336,"h":21475793816,"f":1,"a":[{"t":105709569,"c":8695644161,"a":[{"v":8,"t":110886913}]}]}],"c":[{"n":".ctor","o":"$ctor$2","d":957336,"h":25770761112,"f":1}],"h":957336,"a":[{"t":33161217,"c":4328128513,"a":[{"v":1,"t":33226753}]}]}; }
            static get $b() { return $.$spc.System.ValueType; }
            static get $fullName() { return `System.Runtime.InteropServices.ComTypes.FORMATETC`; }
        });
        
        $asm.$str("$sris.System.Runtime.InteropServices.ComTypes.STATDATA", ($self) => class STATDATA extends $.$spc.System.ValueType
        {
            /*FORMATETC*/  get formatetc() { return this.$getField(0, 18); }
            /*FORMATETC*/  set formatetc(value) { this.$setField(0, 18, value); }
            /*ADVF*/  get advf() { return this.$getField(18, 4); }
            /*ADVF*/  set advf(value) { this.$setField(18, 4, value); }
            /*IAdviseSink*/  get advSink() { return this.$getField(22, 4); }
            /*IAdviseSink*/  set advSink(value) { this.$setField(22, 4, value); }
            /*int*/  get connection() { return this.$getField(26, 4); }
            /*int*/  set connection(value) { this.$setField(26, 4, value); }
            //default value type constructor
            $ctor$2()
            {
                return this;
            }
            Clone($copy)
            {
                let copy = $copy ?? new this.constructor();
                copy.formatetc = this.formatetc.Clone();
                copy.advf = this.advf;
                copy.advSink = this.advSink;
                copy.connection = this.connection;
                return copy;
            }
            //default member initializer
            constructor()
            {
                super();
                this.formatetc = $.$default($.$sris.System.Runtime.InteropServices.ComTypes.FORMATETC);
                this.advf = 0;
                this.advSink = null;
                this.connection = 0;
            }
            static $h = 1285016;
            static $z = 30;
            static $f = 0b1010000001;
            static $k = 2;
            static $$md;
            static get $md() { return this.$$md ??= {"b":196609,"l":[{"t":957336,"n":"formatetc","d":1285016,"h":4296252312,"f":1},{"t":760728,"n":"advf","d":1285016,"h":8591219608,"f":1},{"t":1022872,"n":"advSink","d":1285016,"h":12886186904,"f":1},{"t":655361,"n":"connection","d":1285016,"h":17181154200,"f":1}],"c":[{"n":".ctor","o":"$ctor$2","d":1285016,"h":21476121496,"f":1}],"h":1285016,"a":[{"t":33161217,"c":4328128513,"a":[{"v":1,"t":33226753}]}]}; }
            static get $b() { return $.$spc.System.ValueType; }
            static get $fullName() { return `System.Runtime.InteropServices.ComTypes.STATDATA`; }
        });
        
        $asm.$cls("$sris.System.Runtime.InteropServices.ComConversionLossAttribute", ($self) => class ComConversionLossAttribute extends $.$spc.System.Attribute
        {
            //default reference type constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                return this;
            }
            static $h = 629656;
            static $f = 0b10010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":14483457,"c":[{"n":".ctor","o":"$ctor$2","d":629656,"h":4295596952,"f":1}],"h":629656,"a":[{"t":14614529,"c":21489451009,"a":[{"v":32767,"t":14548993}],"n":[{"n":"Inherited","v":false,"t":262145}]}]}; }
            static get $b() { return $.$spc.System.Attribute; }
            static get $fullName() { return `System.Runtime.InteropServices.ComConversionLossAttribute`; }
        });
        
        $asm.$cls("$sris.System.Runtime.InteropServices.AutomationProxyAttribute", ($self) => class AutomationProxyAttribute extends $.$spc.System.Attribute
        {
            $ctor$2(/*bool*/ val)
            {
                super.$ctor$1();
                this.Value = val;
                return this;
            }
            /*bool*/ Value = false;
            //default member initializer
            constructor()
            {
                super();
                this.Value = false;
            }
            static $h = 367512;
            static $f = 0b10010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":14483457,"p":[{"p":262145,"g":{"r":0,"d":0,"h":17180236696,"f":1},"n":"Value","d":367512,"h":12885269400,"f":1}],"c":[{"p":[{"n":"val","p":262145}],"n":".ctor","o":"$ctor$2","d":367512,"h":4295334808,"f":1}],"h":367512,"a":[{"t":14614529,"c":21489451009,"a":[{"v":1029,"t":14548993}],"n":[{"n":"Inherited","v":false,"t":262145}]}]}; }
            static get $b() { return $.$spc.System.Attribute; }
            static get $fullName() { return `System.Runtime.InteropServices.AutomationProxyAttribute`; }
        });
        
        $asm.$cls("$sris.System.Runtime.InteropServices.ComAliasNameAttribute", ($self) => class ComAliasNameAttribute extends $.$spc.System.Attribute
        {
            $ctor$2(/*string*/ alias)
            {
                super.$ctor$1();
                this.Value = alias;
                return this;
            }
            /*string*/ Value = null;
            static $h = 433048;
            static $f = 0b10010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":14483457,"p":[{"p":1310721,"g":{"r":0,"d":0,"h":17180302232,"f":1},"n":"Value","d":433048,"h":12885334936,"f":1}],"c":[{"p":[{"n":"alias","p":1310721}],"n":".ctor","o":"$ctor$2","d":433048,"h":4295400344,"f":1}],"h":433048,"a":[{"t":14614529,"c":21489451009,"a":[{"v":10624,"t":14548993}],"n":[{"n":"Inherited","v":false,"t":262145}]}]}; }
            static get $b() { return $.$spc.System.Attribute; }
            static get $fullName() { return `System.Runtime.InteropServices.ComAliasNameAttribute`; }
        });
        
        $asm.$cls("$sris.System.Runtime.InteropServices.ComCompatibleVersionAttribute", ($self) => class ComCompatibleVersionAttribute extends $.$spc.System.Attribute
        {
            $ctor$2(/*int*/ major, /*int*/ minor, /*int*/ build, /*int*/ revision)
            {
                super.$ctor$1();
                {
                    this.MajorVersion = major;
                    this.MinorVersion = minor;
                    this.BuildNumber = build;
                    this.RevisionNumber = revision;
                }
                return this;
            }
            /*int*/ MajorVersion = 0;
            /*int*/ MinorVersion = 0;
            /*int*/ BuildNumber = 0;
            /*int*/ RevisionNumber = 0;
            static $h = 564120;
            static $f = 0b10010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":14483457,"p":[{"p":655361,"g":{"r":0,"d":0,"h":17180433304,"f":1},"n":"MajorVersion","d":564120,"h":12885466008,"f":1},{"p":655361,"g":{"r":0,"d":0,"h":30065335192,"f":1},"n":"MinorVersion","d":564120,"h":25770367896,"f":1},{"p":655361,"g":{"r":0,"d":0,"h":42950237080,"f":1},"n":"BuildNumber","d":564120,"h":38655269784,"f":1},{"p":655361,"g":{"r":0,"d":0,"h":55835138968,"f":1},"n":"RevisionNumber","d":564120,"h":51540171672,"f":1}],"c":[{"p":[{"n":"major","p":655361},{"n":"minor","p":655361},{"n":"build","p":655361},{"n":"revision","p":655361}],"n":".ctor","o":"$ctor$2","d":564120,"h":4295531416,"f":1}],"h":564120,"a":[{"t":14614529,"c":21489451009,"a":[{"v":1,"t":14548993}],"n":[{"n":"Inherited","v":false,"t":262145}]}]}; }
            static get $b() { return $.$spc.System.Attribute; }
            static get $fullName() { return `System.Runtime.InteropServices.ComCompatibleVersionAttribute`; }
        });
        
        $asm.$cls("$sris.System.Runtime.InteropServices.ComRegisterFunctionAttribute", ($self) => class ComRegisterFunctionAttribute extends $.$spc.System.Attribute
        {
            //default reference type constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                return this;
            }
            static $h = 695192;
            static $f = 0b10010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":14483457,"c":[{"n":".ctor","o":"$ctor$2","d":695192,"h":4295662488,"f":1}],"h":695192,"a":[{"t":14614529,"c":21489451009,"a":[{"v":64,"t":14548993}],"n":[{"n":"Inherited","v":false,"t":262145}]}]}; }
            static get $b() { return $.$spc.System.Attribute; }
            static get $fullName() { return `System.Runtime.InteropServices.ComRegisterFunctionAttribute`; }
        });
        
        $asm.$cls("$sris.System.Runtime.InteropServices.ComUnregisterFunctionAttribute", ($self) => class ComUnregisterFunctionAttribute extends $.$spc.System.Attribute
        {
            //default reference type constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                return this;
            }
            static $h = 1481624;
            static $f = 0b10010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":14483457,"c":[{"n":".ctor","o":"$ctor$2","d":1481624,"h":4296448920,"f":1}],"h":1481624,"a":[{"t":14614529,"c":21489451009,"a":[{"v":64,"t":14548993}],"n":[{"n":"Inherited","v":false,"t":262145}]}]}; }
            static get $b() { return $.$spc.System.Attribute; }
            static get $fullName() { return `System.Runtime.InteropServices.ComUnregisterFunctionAttribute`; }
        });
        
        $asm.$cls("$sris.System.Runtime.InteropServices.ImportedFromTypeLibAttribute", ($self) => class ImportedFromTypeLibAttribute extends $.$spc.System.Attribute
        {
            $ctor$2(/*string*/ tlbFile)
            {
                super.$ctor$1();
                this.Value = tlbFile;
                return this;
            }
            /*string*/ Value = null;
            static $h = 1678232;
            static $f = 0b10010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":14483457,"p":[{"p":1310721,"g":{"r":0,"d":0,"h":17181547416,"f":1},"n":"Value","d":1678232,"h":12886580120,"f":1}],"c":[{"p":[{"n":"tlbFile","p":1310721}],"n":".ctor","o":"$ctor$2","d":1678232,"h":4296645528,"f":1}],"h":1678232,"a":[{"t":14614529,"c":21489451009,"a":[{"v":1,"t":14548993}],"n":[{"n":"Inherited","v":false,"t":262145}]}]}; }
            static get $b() { return $.$spc.System.Attribute; }
            static get $fullName() { return `System.Runtime.InteropServices.ImportedFromTypeLibAttribute`; }
        });
        
        $asm.$cls("$sris.System.Runtime.InteropServices.ManagedToNativeComInteropStubAttribute", ($self) => class ManagedToNativeComInteropStubAttribute extends $.$spc.System.Attribute
        {
            $ctor$2(/*Type*/ classType, /*string*/ methodName)
            {
                super.$ctor$1();
                {
                    this.ClassType = classType;
                    this.MethodName = methodName;
                }
                return this;
            }
            /*Type*/ ClassType = null;
            /*string*/ MethodName = null;
            static $h = 1743768;
            static $f = 0b10010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":14483457,"p":[{"p":142606337,"g":{"r":0,"d":0,"h":17181612952,"f":1},"n":"ClassType","d":1743768,"h":12886645656,"f":1},{"p":1310721,"g":{"r":0,"d":0,"h":30066514840,"f":1},"n":"MethodName","d":1743768,"h":25771547544,"f":1}],"c":[{"p":[{"n":"classType","p":142606337},{"n":"methodName","p":1310721}],"n":".ctor","o":"$ctor$2","d":1743768,"h":4296711064,"f":1}],"h":1743768,"a":[{"t":14614529,"c":21489451009,"a":[{"v":64,"t":14548993}],"n":[{"n":"Inherited","v":false,"t":262145},{"n":"AllowMultiple","v":false,"t":262145}]}]}; }
            static get $b() { return $.$spc.System.Attribute; }
            static get $fullName() { return `System.Runtime.InteropServices.ManagedToNativeComInteropStubAttribute`; }
        });
        
        $asm.$str("$sris.System.Runtime.InteropServices.ComTypes.STGMEDIUM", ($self) => class STGMEDIUM extends $.$spc.System.ValueType
        {
            /*TYMED*/  get tymed() { return this.$getField(0, 4); }
            /*TYMED*/  set tymed(value) { this.$setField(0, 4, value); }
            /*IntPtr*/  get unionmember() { return this.$getField(4, 4); }
            /*IntPtr*/  set unionmember(value) { this.$setField(4, 4, value); }
            /*object?*/  get pUnkForRelease() { return this.$getField(8, 4); }
            /*object?*/  set pUnkForRelease(value) { this.$setField(8, 4, value); }
            //default value type constructor
            $ctor$2()
            {
                return this;
            }
            Clone($copy)
            {
                let copy = $copy ?? new this.constructor();
                copy.tymed = this.tymed;
                copy.unionmember = this.unionmember;
                copy.pUnkForRelease = this.pUnkForRelease;
                return copy;
            }
            //default member initializer
            constructor()
            {
                super();
                this.tymed = 0;
                this.unionmember = 0;
                this.pUnkForRelease = null;
            }
            static $h = 1350552;
            static $z = 12;
            static $f = 0b1010000001;
            static $k = 2;
            static $$md;
            static get $md() { return this.$$md ??= {"b":196609,"l":[{"t":1416088,"n":"tymed","d":1350552,"h":4296317848,"f":1},{"t":786433,"n":"unionmember","d":1350552,"h":8591285144,"f":1},{"t":131073,"n":"pUnkForRelease","d":1350552,"h":12886252440,"f":1,"a":[{"t":105709569,"c":8695644161,"a":[{"v":25,"t":110886913}]}]}],"c":[{"n":".ctor","o":"$ctor$2","d":1350552,"h":17181219736,"f":1}],"h":1350552,"a":[{"t":33161217,"c":4328128513,"a":[{"v":1,"t":33226753}]}]}; }
            static get $b() { return $.$spc.System.ValueType; }
            static get $fullName() { return `System.Runtime.InteropServices.ComTypes.STGMEDIUM`; }
        });
        
        $asm.$cls("$sris.System.Runtime.InteropServices.Marshalling.GeneratedComClassAttribute", ($self) => class GeneratedComClassAttribute extends $.$spc.System.Attribute
        {
            //default reference type constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                return this;
            }
            static $h = 2857880;
            static $f = 0b10010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":14483457,"c":[{"n":".ctor","o":"$ctor$2","d":2857880,"h":4297825176,"f":1}],"h":2857880,"a":[{"t":14614529,"c":21489451009,"a":[{"v":4,"t":14548993}]}]}; }
            static get $b() { return $.$spc.System.Attribute; }
            static get $fullName() { return `System.Runtime.InteropServices.Marshalling.GeneratedComClassAttribute`; }
        });
        
        $asm.$cls("$sris.System.Runtime.InteropServices.Marshalling.GeneratedComInterfaceAttribute", ($self) => class GeneratedComInterfaceAttribute extends $.$spc.System.Attribute
        {
            /*ComInterfaceOptions*/ Options = 0;
            /*StringMarshalling*/ StringMarshalling = 0;
            /*Type?*/ StringMarshallingCustomType = null;
            /*Type?*/ ExceptionToUnmanagedMarshaller = null;
            //default reference type constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                return this;
            }
            //default member initializer
            constructor()
            {
                super();
                this.Options = 3;
                this.StringMarshalling = 0;
            }
            static $h = 2923416;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":14483457,"p":[{"p":2136984,"g":{"r":0,"d":0,"h":12887825304,"f":1},"s":{"r":0,"d":0,"h":17182792600,"f":1},"n":"Options","d":2923416,"h":8592858008,"f":1},{"p":109838337,"g":{"r":0,"d":0,"h":30067694488,"f":1},"s":{"r":0,"d":0,"h":34362661784,"f":1},"n":"StringMarshalling","d":2923416,"h":25772727192,"f":1},{"p":142606337,"g":{"r":0,"d":0,"h":47247563672,"f":1},"s":{"r":0,"d":0,"h":51542530968,"f":1},"n":"StringMarshallingCustomType","d":2923416,"h":42952596376,"f":1},{"p":142606337,"g":{"r":0,"d":0,"h":64427432856,"f":1},"s":{"r":0,"d":0,"h":68722400152,"f":1},"n":"ExceptionToUnmanagedMarshaller","d":2923416,"h":60132465560,"f":1}],"c":[{"n":".ctor","o":"$ctor$2","d":2923416,"h":73017367448,"f":1}],"h":2923416,"a":[{"t":14614529,"c":21489451009,"a":[{"v":1024,"t":14548993}]}]}; }
            static get $b() { return $.$spc.System.Attribute; }
            static get $fullName() { return `System.Runtime.InteropServices.Marshalling.GeneratedComInterfaceAttribute`; }
        });
        
        $asm.$str("$sris.System.Runtime.InteropServices.Marshalling.VirtualMethodTableInfo", ($self) => class VirtualMethodTableInfo extends $.$spc.System.ValueType
        {
            $ctor$2(/*void**/ thisPointer, /*void***/ virtualMethodTable)
            {
                super.$ctor$1();
                {
                    this.ThisPointer = thisPointer;
                    this.VirtualMethodTable = virtualMethodTable;
                }
                return this;
            }
            /*void**/ ThisPointer;
            /*void***/ VirtualMethodTable;
            /*void */ Deconstruct(/*out void**/ thisPointer, /*out void***/ virtualMethodTable)
            {
                thisPointer.$v = this.ThisPointer;
                virtualMethodTable.$v = this.VirtualMethodTable;
            }
            //default value type constructor
            $ctor$3()
            {
                return this;
            }
            Clone($copy)
            {
                let copy = $copy ?? new this.constructor();
                copy.ThisPointer = this.ThisPointer.Clone();
                copy.VirtualMethodTable = this.VirtualMethodTable.Clone();
                return copy;
            }
            //default member initializer
            constructor()
            {
                super();
                this.ThisPointer = $.$default($.$typePointer($.$spc.System.Void));
                this.VirtualMethodTable = $.$default($.$typePointer($.$typePointer($.$spc.System.Void)));
            }
            static $h = 3775384;
            static $z = 8;
            static $f = 0b1010000001;
            static $k = 2;
            static $$md;
            static get $md() { return this.$$md ??= {"b":196609,"p":[{"p":0,"g":{"r":0,"d":0,"h":17183644568,"f":1},"n":"ThisPointer","d":3775384,"h":12888677272,"f":1},{"p":0,"g":{"r":0,"d":0,"h":30068546456,"f":1},"n":"VirtualMethodTable","d":3775384,"h":25773579160,"f":1}],"m":[{"r":65537,"p":[{"n":"thisPointer","p":0,"f":2},{"n":"virtualMethodTable","p":0,"f":2}],"n":"Deconstruct","d":3775384,"h":34363513752,"f":1}],"c":[{"p":[{"n":"thisPointer","p":0},{"n":"virtualMethodTable","p":0}],"n":".ctor","o":"$ctor$2","d":3775384,"h":4298742680,"f":1},{"n":".ctor","o":"$ctor$3","d":3775384,"h":38658481048,"f":1}],"h":3775384,"a":[{"t":23396353,"c":8613330945,"a":[{"v":false,"t":262145}]}]}; }
            static get $b() { return $.$spc.System.ValueType; }
            static get $fullName() { return `System.Runtime.InteropServices.Marshalling.VirtualMethodTableInfo`; }
        });
        
        $asm.$cls("$sris.System.Runtime.InteropServices.Marshalling.StrategyBasedComWrappers", ($self) => class StrategyBasedComWrappers extends $.$spc.System.Runtime.InteropServices.ComWrappers
        {
            /*StrategyBasedComWrappers*/ static DefaultMarshallingInstance = null;
            /*IIUnknownInterfaceDetailsStrategy*/ static DefaultIUnknownInterfaceDetailsStrategy = null;
            /*IIUnknownStrategy*/ static DefaultIUnknownStrategy = null;
            static /*IIUnknownCacheStrategy */ CreateDefaultCacheStrategy()
            {
                return new $.$sris.System.Runtime.InteropServices.Marshalling.DefaultCaching().$ctor$1();
            }
            /*IIUnknownInterfaceDetailsStrategy */ GetOrCreateInterfaceDetailsStrategy()
            {
                //if (OperatingSystem.IsWindows() && RuntimeFeature.IsDynamicCodeSupported && ComObject.BuiltInComSupported && ComObject.ComImportInteropEnabled) { ... }
                return $.$sris.System.Runtime.InteropServices.Marshalling.StrategyBasedComWrappers.DefaultIUnknownInterfaceDetailsStrategy;
                /*static IIUnknownInterfaceDetailsStrategy*/  function GetInteropStrategy()
                {
                    return $.$sris.System.Runtime.InteropServices.Marshalling.ComImportInteropInterfaceDetailsStrategy.Instance;
                }
            }
            /*IIUnknownStrategy */ GetOrCreateIUnknownStrategy()
            {
                return $.$sris.System.Runtime.InteropServices.Marshalling.StrategyBasedComWrappers.DefaultIUnknownStrategy;
            }
            /*IIUnknownCacheStrategy */ CreateCacheStrategy()
            {
                return $.$sris.System.Runtime.InteropServices.Marshalling.StrategyBasedComWrappers.CreateDefaultCacheStrategy();
            }
            /*ComInterfaceEntry* */ ComputeVtables(/*object*/ obj, /*CreateComInterfaceFlags*/ flags, /*out int*/ count)
            {
                let details;
                if (this.GetOrCreateInterfaceDetailsStrategy().System$Runtime$InteropServices$Marshalling$IIUnknownInterfaceDetailsStrategy$GetComExposedTypeDetails($.$spc.System.Object.GetType.call(obj).TypeHandle) !== null && ((details = this.GetOrCreateInterfaceDetailsStrategy().System$Runtime$InteropServices$Marshalling$IIUnknownInterfaceDetailsStrategy$GetComExposedTypeDetails($.$spc.System.Object.GetType.call(obj).TypeHandle), details != null && true)))
                {
                    return details.System$Runtime$InteropServices$Marshalling$IComExposedDetails$GetComInterfaceEntries(count);
                }
                count.$v = 0;
                return null;
            }
            /*object */ CreateObject(/*nint*/ externalComObject, /*CreateObjectFlags*/ flags)
            {
                if (((flags & (1/*CreateObjectFlags.TrackerObject*/)) == (1/*CreateObjectFlags.TrackerObject*/)) || ((flags & (4/*CreateObjectFlags.Aggregation*/)) == (4/*CreateObjectFlags.Aggregation*/)))
                {
                    throw new $.$spc.System.NotSupportedException().$ctor$9();
                }
                /*var*/ let rcw = (() =>
                {
                    //new $.$sris.System.Runtime.InteropServices.Marshalling.ComObject()
                    const $t1 = $.$sris.System.Runtime.InteropServices.Marshalling.ComObject;
                    const $i1 = new $t1();
                    $i1.$ctor$1(this.GetOrCreateInterfaceDetailsStrategy(), this.GetOrCreateIUnknownStrategy(), this.CreateCacheStrategy(), $.$spc.System.IntPtr.op_Explicit$3(externalComObject));
                    $i1.UniqueInstance = ((flags & (2/*CreateObjectFlags.UniqueInstance*/)) == (2/*CreateObjectFlags.UniqueInstance*/));
                    return $i1;
                })();
                return rcw;
            }
            /*object? */ CreateObject$1(/*nint*/ externalComObject, /*CreateObjectFlags*/ flags, /*object?*/ userState, /*out CreatedWrapperFlags*/ wrapperFlags)
            {
                return super.CreateObject$1(externalComObject, flags, userState, wrapperFlags);
            }
            /*void */ ReleaseObjects(/*IEnumerable*/ objects)
            {
                throw new $.$spc.System.NotImplementedException().$ctor$9();
            }
            //default reference type constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                return this;
            }
            //Static Initializer
            static $sinit()
            {
                {
                    this.DefaultMarshallingInstance = new $.$sris.System.Runtime.InteropServices.Marshalling.StrategyBasedComWrappers().$ctor$2();
                }
                {
                    this.DefaultIUnknownInterfaceDetailsStrategy = $.$sris.System.Runtime.InteropServices.Marshalling.DefaultIUnknownInterfaceDetailsStrategy.Instance;
                }
                {
                    this.DefaultIUnknownStrategy = $.$sris.System.Runtime.InteropServices.Marshalling.FreeThreadedStrategy.Instance;
                }
            }
            static $h = 3644312;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":102629377,"p":[{"p":3644312,"g":{"r":0,"d":0,"h":12888546200,"f":40},"n":"DefaultMarshallingInstance","d":3644312,"h":8593578904,"f":40},{"p":3316632,"g":{"r":0,"d":0,"h":25773448088,"f":33},"n":"DefaultIUnknownInterfaceDetailsStrategy","d":3644312,"h":21478480792,"f":33},{"p":3447704,"g":{"r":0,"d":0,"h":38658349976,"f":33},"n":"DefaultIUnknownStrategy","d":3644312,"h":34363382680,"f":33}],"m":[{"r":3120024,"n":"CreateDefaultCacheStrategy","d":3644312,"h":42953317272,"f":36},{"r":3316632,"n":"GetOrCreateInterfaceDetailsStrategy","d":3644312,"h":47248284568,"f":132},{"r":3447704,"n":"GetOrCreateIUnknownStrategy","d":3644312,"h":51543251864,"f":132},{"r":3120024,"n":"CreateCacheStrategy","d":3644312,"h":55838219160,"f":132},{"r":0,"p":[{"n":"obj","p":131073},{"n":"flags","p":102825985},{"n":"count","p":655361,"f":2}],"n":"ComputeVtables","d":3644312,"h":60133186456,"f":98308},{"r":131073,"p":[{"n":"externalComObject","p":786433},{"n":"flags","p":102957057}],"n":"CreateObject","d":3644312,"h":64428153752,"f":98308},{"r":131073,"p":[{"n":"externalComObject","p":786433},{"n":"flags","p":102957057},{"n":"userState","p":131073},{"n":"wrapperFlags","p":102891521,"f":2}],"n":"CreateObject","o":"@$1","d":3644312,"h":68723121048,"f":98308},{"r":65537,"p":[{"n":"objects","p":31588353}],"n":"ReleaseObjects","d":3644312,"h":73018088344,"f":98308}],"c":[{"n":".ctor","o":"$ctor$2","d":3644312,"h":77313055640,"f":1}],"h":3644312,"a":[{"t":115277825,"c":4410245121,"a":[{"v":"android","t":1310721}]},{"t":115277825,"c":4410245121,"a":[{"v":"browser","t":1310721}]},{"t":115277825,"c":4410245121,"a":[{"v":"ios","t":1310721}]},{"t":115277825,"c":4410245121,"a":[{"v":"tvos","t":1310721}]},{"t":23396353,"c":8613330945,"a":[{"v":false,"t":262145}]}]}; }
            static get $b() { return $.$spc.System.Runtime.InteropServices.ComWrappers; }
            static get $fullName() { return `System.Runtime.InteropServices.Marshalling.StrategyBasedComWrappers`; }
        });
        
        $asm.$cls("$sris.System.Runtime.InteropServices.PrimaryInteropAssemblyAttribute", ($self) => class PrimaryInteropAssemblyAttribute extends $.$spc.System.Attribute
        {
            $ctor$2(/*int*/ major, /*int*/ minor)
            {
                super.$ctor$1();
                {
                    this.MajorVersion = major;
                    this.MinorVersion = minor;
                }
                return this;
            }
            /*int*/ MajorVersion = 0;
            /*int*/ MinorVersion = 0;
            static $h = 3840920;
            static $f = 0b10010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":14483457,"p":[{"p":655361,"g":{"r":0,"d":0,"h":17183710104,"f":1},"n":"MajorVersion","d":3840920,"h":12888742808,"f":1},{"p":655361,"g":{"r":0,"d":0,"h":30068611992,"f":1},"n":"MinorVersion","d":3840920,"h":25773644696,"f":1}],"c":[{"p":[{"n":"major","p":655361},{"n":"minor","p":655361}],"n":".ctor","o":"$ctor$2","d":3840920,"h":4298808216,"f":1}],"h":3840920,"a":[{"t":14614529,"c":21489451009,"a":[{"v":1,"t":14548993}],"n":[{"n":"Inherited","v":false,"t":262145},{"n":"AllowMultiple","v":true,"t":262145}]}]}; }
            static get $b() { return $.$spc.System.Attribute; }
            static get $fullName() { return `System.Runtime.InteropServices.PrimaryInteropAssemblyAttribute`; }
        });
        
        $asm.$cls("$sris.System.Runtime.InteropServices.TypeLibTypeAttribute", ($self) => class TypeLibTypeAttribute extends $.$spc.System.Attribute
        {
            $ctor$2(/*TypeLibTypeFlags*/ flags)
            {
                super.$ctor$1();
                {
                    this.Value = flags;
                }
                return this;
            }
            $ctor$3(/*short*/ flags)
            {
                super.$ctor$1();
                {
                    this.Value = $.$cast(flags, $.$sris.System.Runtime.InteropServices.TypeLibTypeFlags);
                }
                return this;
            }
            /*TypeLibTypeFlags*/ Value = 0;
            //default member initializer
            constructor()
            {
                super();
                this.Value = 0;
            }
            static $h = 4299672;
            static $f = 0b10010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":14483457,"p":[{"p":4365208,"g":{"r":0,"d":0,"h":21479136152,"f":1},"n":"Value","d":4299672,"h":17184168856,"f":1}],"c":[{"p":[{"n":"flags","p":4365208}],"n":".ctor","o":"$ctor$2","d":4299672,"h":4299266968,"f":1},{"p":[{"n":"flags","p":524289}],"n":".ctor","o":"$ctor$3","d":4299672,"h":8594234264,"f":1}],"h":4299672,"a":[{"t":14614529,"c":21489451009,"a":[{"v":1052,"t":14548993}],"n":[{"n":"Inherited","v":false,"t":262145}]}]}; }
            static get $b() { return $.$spc.System.Attribute; }
            static get $fullName() { return `System.Runtime.InteropServices.TypeLibTypeAttribute`; }
        });
        
        $asm.$cls("$sris.System.Runtime.InteropServices.TypeLibVarAttribute", ($self) => class TypeLibVarAttribute extends $.$spc.System.Attribute
        {
            $ctor$2(/*TypeLibVarFlags*/ flags)
            {
                super.$ctor$1();
                {
                    this.Value = flags;
                }
                return this;
            }
            $ctor$3(/*short*/ flags)
            {
                super.$ctor$1();
                {
                    this.Value = $.$cast(flags, $.$sris.System.Runtime.InteropServices.TypeLibVarFlags);
                }
                return this;
            }
            /*TypeLibVarFlags*/ Value = 0;
            //default member initializer
            constructor()
            {
                super();
                this.Value = 0;
            }
            static $h = 4430744;
            static $f = 0b10010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":14483457,"p":[{"p":4496280,"g":{"r":0,"d":0,"h":21479267224,"f":1},"n":"Value","d":4430744,"h":17184299928,"f":1}],"c":[{"p":[{"n":"flags","p":4496280}],"n":".ctor","o":"$ctor$2","d":4430744,"h":4299398040,"f":1},{"p":[{"n":"flags","p":524289}],"n":".ctor","o":"$ctor$3","d":4430744,"h":8594365336,"f":1}],"h":4430744,"a":[{"t":14614529,"c":21489451009,"a":[{"v":256,"t":14548993}],"n":[{"n":"Inherited","v":false,"t":262145}]}]}; }
            static get $b() { return $.$spc.System.Attribute; }
            static get $fullName() { return `System.Runtime.InteropServices.TypeLibVarAttribute`; }
        });
        
        $asm.$cls("$sris.System.Runtime.InteropServices.TypeLibVersionAttribute", ($self) => class TypeLibVersionAttribute extends $.$spc.System.Attribute
        {
            $ctor$2(/*int*/ major, /*int*/ minor)
            {
                super.$ctor$1();
                {
                    this.MajorVersion = major;
                    this.MinorVersion = minor;
                }
                return this;
            }
            /*int*/ MajorVersion = 0;
            /*int*/ MinorVersion = 0;
            static $h = 4561816;
            static $f = 0b10010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":14483457,"p":[{"p":655361,"g":{"r":0,"d":0,"h":17184431000,"f":1},"n":"MajorVersion","d":4561816,"h":12889463704,"f":1},{"p":655361,"g":{"r":0,"d":0,"h":30069332888,"f":1},"n":"MinorVersion","d":4561816,"h":25774365592,"f":1}],"c":[{"p":[{"n":"major","p":655361},{"n":"minor","p":655361}],"n":".ctor","o":"$ctor$2","d":4561816,"h":4299529112,"f":1}],"h":4561816,"a":[{"t":14614529,"c":21489451009,"a":[{"v":1,"t":14548993}],"n":[{"n":"Inherited","v":false,"t":262145}]}]}; }
            static get $b() { return $.$spc.System.Attribute; }
            static get $fullName() { return `System.Runtime.InteropServices.TypeLibVersionAttribute`; }
        });
        
        $asm.$cls("$sris.System.Runtime.InteropServices.TypeLibFuncAttribute", ($self) => class TypeLibFuncAttribute extends $.$spc.System.Attribute
        {
            $ctor$2(/*TypeLibFuncFlags*/ flags)
            {
                super.$ctor$1();
                {
                    this.Value = flags;
                }
                return this;
            }
            $ctor$3(/*short*/ flags)
            {
                super.$ctor$1();
                {
                    this.Value = $.$cast(flags, $.$sris.System.Runtime.InteropServices.TypeLibFuncFlags);
                }
                return this;
            }
            /*TypeLibFuncFlags*/ Value = 0;
            //default member initializer
            constructor()
            {
                super();
                this.Value = 0;
            }
            static $h = 4103064;
            static $f = 0b10010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":14483457,"p":[{"p":4168600,"g":{"r":0,"d":0,"h":21478939544,"f":1},"n":"Value","d":4103064,"h":17183972248,"f":1}],"c":[{"p":[{"n":"flags","p":4168600}],"n":".ctor","o":"$ctor$2","d":4103064,"h":4299070360,"f":1},{"p":[{"n":"flags","p":524289}],"n":".ctor","o":"$ctor$3","d":4103064,"h":8594037656,"f":1}],"h":4103064,"a":[{"t":14614529,"c":21489451009,"a":[{"v":64,"t":14548993}],"n":[{"n":"Inherited","v":false,"t":262145}]}]}; }
            static get $b() { return $.$spc.System.Attribute; }
            static get $fullName() { return `System.Runtime.InteropServices.TypeLibFuncAttribute`; }
        });
        
        $asm.$cls("$sris.System.Runtime.InteropServices.TypeLibImportClassAttribute", ($self) => class TypeLibImportClassAttribute extends $.$spc.System.Attribute
        {
            $ctor$2(/*Type*/ importClass)
            {
                super.$ctor$1();
                this.Value = $.$spc.System.Type.ToString.call(importClass);
                return this;
            }
            /*string*/ Value = null;
            static $h = 4234136;
            static $f = 0b10010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":14483457,"p":[{"p":1310721,"g":{"r":0,"d":0,"h":17184103320,"f":1},"n":"Value","d":4234136,"h":12889136024,"f":1}],"c":[{"p":[{"n":"importClass","p":142606337}],"n":".ctor","o":"$ctor$2","d":4234136,"h":4299201432,"f":1}],"h":4234136,"a":[{"t":14614529,"c":21489451009,"a":[{"v":1024,"t":14548993}],"n":[{"n":"Inherited","v":false,"t":262145}]}]}; }
            static get $b() { return $.$spc.System.Attribute; }
            static get $fullName() { return `System.Runtime.InteropServices.TypeLibImportClassAttribute`; }
        });
        
        $asm.$cls("$sris.System.Runtime.InteropServices.Marshalling.ComExposedClassAttribute<>", (T) => $asm.$gt("$sris.System.Runtime.InteropServices.Marshalling.ComExposedClassAttribute<>", [T], ($self) => class ComExposedClassAttribute$$ extends $.$spc.System.Attribute
        {
            /*ComWrappers.ComInterfaceEntry* */ GetComInterfaceEntries(/*out int*/ count)
            {
                return T.System$Runtime$InteropServices$Marshalling$IComExposedClass$GetComInterfaceEntries(count);
            }
            //Generated interface implemetation for System.Runtime.InteropServices.Marshalling.IComExposedDetails.GetComInterfaceEntries(out int)
            System$Runtime$InteropServices$Marshalling$IComExposedDetails$GetComInterfaceEntries()
            {
                return this.GetComInterfaceEntries(...arguments);
            }
            //default reference type constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                return this;
            }
            static $h = 1809304;
            static $g = 1;
            static $f = 0b11010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":14483457,"m":[{"r":0,"p":[{"n":"count","p":655361,"f":2}],"n":"GetComInterfaceEntries","d":this.$h,"h":Number(BigInt(this.$h)|0x100000000n),"f":1}],"c":[{"n":".ctor","o":"$ctor$2","d":this.$h,"h":Number(BigInt(this.$h)|0x200000000n),"f":1}],"i":[3054488],"g":[T?.$h??1507328],"r":1,"h":this.$h,"a":[{"t":14614529,"c":21489451009,"a":[{"v":4,"t":14548993}],"n":[{"n":"Inherited","v":false,"t":262145}]},{"t":23396353,"c":8613330945,"a":[{"v":false,"t":262145}]}]}; }
            static get $b() { return $.$spc.System.Attribute; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$sris.System.Runtime.InteropServices.Marshalling.IComExposedDetails ]; }
            static get $fullName() { return `System.Runtime.InteropServices.Marshalling.ComExposedClassAttribute<${T?.$fullName}>`; }
        }));
        
        $asm.$cls("$sris.System.Runtime.InteropServices.Marshalling.IUnknownDerivedAttribute<,>", (T, TImpl) => $asm.$gt("$sris.System.Runtime.InteropServices.Marshalling.IUnknownDerivedAttribute<,>", [T, TImpl], ($self) => class IUnknownDerivedAttribute$$$ extends $.$spc.System.Attribute
        {
            $ctor$2()
            {
                super.$ctor$1();
                {
                }
                return this;
            }
            /*Guid */ get Iid()
            {
                return T.System$Runtime$InteropServices$Marshalling$IIUnknownInterfaceType$Iid;
            }
            /*Type */ get Implementation()
            {
                return TImpl.$type;
            }
            /*void** */ get ManagedVirtualMethodTable()
            {
                return T.System$Runtime$InteropServices$Marshalling$IIUnknownInterfaceType$ManagedVirtualMethodTable;
            }
            //Generated interface implemetation for System.Runtime.InteropServices.Marshalling.IIUnknownDerivedDetails.Iid.get
            get System$Runtime$InteropServices$Marshalling$IIUnknownDerivedDetails$Iid()
            {
                return this.Iid;
            }
            //Generated interface implemetation for System.Runtime.InteropServices.Marshalling.IIUnknownDerivedDetails.Implementation.get
            get System$Runtime$InteropServices$Marshalling$IIUnknownDerivedDetails$Implementation()
            {
                return this.Implementation;
            }
            //Generated interface implemetation for System.Runtime.InteropServices.Marshalling.IIUnknownDerivedDetails.ManagedVirtualMethodTable.get
            get System$Runtime$InteropServices$Marshalling$IIUnknownDerivedDetails$ManagedVirtualMethodTable()
            {
                return this.ManagedVirtualMethodTable;
            }
            static $h = 3513240;
            static $g = 2;
            static $f = 0b1010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":14483457,"p":[{"p":56164353,"g":{"r":0,"d":0,"h":Number(BigInt(this.$h)|0x300000000n),"f":1},"n":"Iid","d":this.$h,"h":Number(BigInt(this.$h)|0x200000000n),"f":1},{"p":142606337,"g":{"r":0,"d":0,"h":Number(BigInt(this.$h)|0x500000000n),"f":1},"n":"Implementation","d":this.$h,"h":Number(BigInt(this.$h)|0x400000000n),"f":1},{"p":0,"g":{"r":0,"d":0,"h":Number(BigInt(this.$h)|0x700000000n),"f":1},"n":"ManagedVirtualMethodTable","d":this.$h,"h":Number(BigInt(this.$h)|0x600000000n),"f":1}],"c":[{"n":".ctor","o":"$ctor$2","d":this.$h,"h":Number(BigInt(this.$h)|0x100000000n),"f":1}],"i":[3251096],"g":[T?.$h??1507328,TImpl?.$h??1572864],"r":2,"h":this.$h,"a":[{"t":14614529,"c":21489451009,"a":[{"v":1024,"t":14548993}],"n":[{"n":"Inherited","v":false,"t":262145}]},{"t":23396353,"c":8613330945,"a":[{"v":false,"t":262145}]}]}; }
            static get $b() { return $.$spc.System.Attribute; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$sris.System.Runtime.InteropServices.Marshalling.IIUnknownDerivedDetails ]; }
            static get $fullName() { return `System.Runtime.InteropServices.Marshalling.IUnknownDerivedAttribute<${T?.$fullName},${TImpl?.$fullName}>`; }
        }));
        
        $asm.$cls("$sris.System.Runtime.CompilerServices.IDispatchConstantAttribute", ($self) => class IDispatchConstantAttribute extends $.$spc.System.Runtime.CompilerServices.CustomConstantAttribute
        {
            $ctor$3()
            {
                super.$ctor$2();
                {
                }
                return this;
            }
            /*object */ get Value()
            {
                return new $.$spc.System.Runtime.InteropServices.DispatchWrapper().$ctor$1(null);
            }
            static $h = 170904;
            static $f = 0b10010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":89915393,"p":[{"p":131073,"g":{"r":0,"d":0,"h":12885072792,"f":32769},"n":"Value","d":170904,"h":8590105496,"f":32769}],"c":[{"n":".ctor","o":"$ctor$3","d":170904,"h":4295138200,"f":1}],"h":170904,"a":[{"t":114950145,"c":4409917441,"a":[{"v":"windows","t":1310721}]},{"t":14614529,"c":21489451009,"a":[{"v":2304,"t":14548993}],"n":[{"n":"Inherited","v":false,"t":262145}]}]}; }
            static get $b() { return $.$spc.System.Runtime.CompilerServices.CustomConstantAttribute; }
            static get $fullName() { return `System.Runtime.CompilerServices.IDispatchConstantAttribute`; }
        });
        
        $asm.$cls("$sris.System.Runtime.CompilerServices.IUnknownConstantAttribute", ($self) => class IUnknownConstantAttribute extends $.$spc.System.Runtime.CompilerServices.CustomConstantAttribute
        {
            $ctor$3()
            {
                super.$ctor$2();
                {
                }
                return this;
            }
            /*object */ get Value()
            {
                return new $.$spc.System.Runtime.InteropServices.UnknownWrapper().$ctor$1(null);
            }
            static $h = 236440;
            static $f = 0b10010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":89915393,"p":[{"p":131073,"g":{"r":0,"d":0,"h":12885138328,"f":32769},"n":"Value","d":236440,"h":8590171032,"f":32769}],"c":[{"n":".ctor","o":"$ctor$3","d":236440,"h":4295203736,"f":1}],"h":236440,"a":[{"t":14614529,"c":21489451009,"a":[{"v":2304,"t":14548993}],"n":[{"n":"Inherited","v":false,"t":262145}]}]}; }
            static get $b() { return $.$spc.System.Runtime.CompilerServices.CustomConstantAttribute; }
            static get $fullName() { return `System.Runtime.CompilerServices.IUnknownConstantAttribute`; }
        });
        
        $asm.$cls("$sris.System.Runtime.InteropServices.ComAwareEventInfo", ($self) => class ComAwareEventInfo extends $.$spc.System.Reflection.EventInfo
        {
            /*EventInfo*/ _innerEventInfo = null;
            $ctor$4(/*Type*/ type, /*string*/ eventName)
            {
                super.$ctor$3();
                {
                    this._innerEventInfo = type.GetEvent(eventName);
                }
                return this;
            }
            /*void */ AddEventHandler(/*object*/ target, /*Delegate*/ handler)
            {
                if ($.$spc.System.Runtime.InteropServices.Marshal.IsComObject(target))
                {
                    /*Guid*/ let sourceIid;
                    /*int*/ let dispid;
                    $.$sris.System.Runtime.InteropServices.ComAwareEventInfo.GetDataForComInvocation(this._innerEventInfo, $.$ref(() => sourceIid, ($v) => sourceIid = $v, $.$spc.System.Guid), $.$ref(() => dispid, ($v) => dispid = $v, $.$spc.System.Int32));
                    $.$spc.System.Runtime.InteropServices.ComEventsHelper.Combine(target, sourceIid, dispid, handler);
                }
                else 
                {
                    this._innerEventInfo.AddEventHandler(target, handler);
                }
            }
            /*void */ RemoveEventHandler(/*object*/ target, /*Delegate*/ handler)
            {
                if ($.$spc.System.Runtime.InteropServices.Marshal.IsComObject(target))
                {
                    /*Guid*/ let sourceIid;
                    /*int*/ let dispid;
                    $.$sris.System.Runtime.InteropServices.ComAwareEventInfo.GetDataForComInvocation(this._innerEventInfo, $.$ref(() => sourceIid, ($v) => sourceIid = $v, $.$spc.System.Guid), $.$ref(() => dispid, ($v) => dispid = $v, $.$spc.System.Int32));
                    $.$spc.System.Runtime.InteropServices.ComEventsHelper.Remove(target, sourceIid, dispid, handler);
                }
                else 
                {
                    this._innerEventInfo.RemoveEventHandler(target, handler);
                }
            }
            /*EventAttributes */ get Attributes()
            {
                return this._innerEventInfo.Attributes;
            }
            /*MethodInfo? */ GetAddMethod$1(/*bool*/ nonPublic)
            {
                return this._innerEventInfo.GetAddMethod$1(nonPublic);
            }
            /*MethodInfo[] */ GetOtherMethods$1(/*bool*/ nonPublic)
            {
                return this._innerEventInfo.GetOtherMethods$1(nonPublic);
            }
            /*MethodInfo? */ GetRaiseMethod$1(/*bool*/ nonPublic)
            {
                return this._innerEventInfo.GetRaiseMethod$1(nonPublic);
            }
            /*MethodInfo? */ GetRemoveMethod$1(/*bool*/ nonPublic)
            {
                return this._innerEventInfo.GetRemoveMethod$1(nonPublic);
            }
            /*Type? */ get DeclaringType()
            {
                return this._innerEventInfo.DeclaringType;
            }
            /*object[] */ GetCustomAttributes$1(/*Type*/ attributeType, /*bool*/ inherit)
            {
                return this._innerEventInfo.GetCustomAttributes$1(attributeType, inherit);
            }
            /*object[] */ GetCustomAttributes(/*bool*/ inherit)
            {
                return this._innerEventInfo.GetCustomAttributes(inherit);
            }
            /*IList<CustomAttributeData> */ GetCustomAttributesData()
            {
                return this._innerEventInfo.GetCustomAttributesData();
            }
            /*bool */ IsDefined(/*Type*/ attributeType, /*bool*/ inherit)
            {
                return this._innerEventInfo.IsDefined(attributeType, inherit);
            }
            /*int */ get MetadataToken()
            {
                return this._innerEventInfo.MetadataToken;
            }
            /*Module */ get Module()
            {
                return this._innerEventInfo.Module;
            }
            /*string */ get Name()
            {
                return this._innerEventInfo.Name;
            }
            /*Type? */ get ReflectedType()
            {
                return this._innerEventInfo.ReflectedType;
            }
            static /*void */ GetDataForComInvocation(/*EventInfo*/ eventInfo, /*out Guid*/ sourceIid, /*out int*/ dispid)
            {
                /*object[]*/ let comEventInterfaces = eventInfo.DeclaringType.GetCustomAttributes$1($.$spc.System.Runtime.InteropServices.ComEventInterfaceAttribute.$type, false);
                if (comEventInterfaces === null || comEventInterfaces.length === 0)
                {
                    throw new $.$spc.System.InvalidOperationException().$ctor$10($.$sris.System.SR.InvalidOperation_NoComEventInterfaceAttribute);
                }
                /*ComEventInterfaceAttribute*/ let interfaceAttribute = $.$cast($.$spc.System.Array.$ReadT1.call(comEventInterfaces, 0), $.$spc.System.Runtime.InteropServices.ComEventInterfaceAttribute);
                if (comEventInterfaces.length > 1)
                {
                    throw new $.$spc.System.Reflection.AmbiguousMatchException().$ctor$10($.$sris.System.SR.Format($.$sris.System.SR.AmbiguousMatch_MultipleEventInterfaceAttributes, interfaceAttribute));
                }
                /*Type*/ let sourceInterface = interfaceAttribute.SourceInterface;
                /*Guid*/ let guid = sourceInterface.GUID;
                /*MethodInfo*/ let methodInfo = sourceInterface.GetMethod$1(eventInfo.Name);
                /*Attribute?*/ let dispIdAttribute = $.$spc.System.Attribute.GetCustomAttribute$2(methodInfo, $.$spc.System.Runtime.InteropServices.DispIdAttribute.$type);
                if (dispIdAttribute === null)
                {
                    throw new $.$spc.System.InvalidOperationException().$ctor$10($.$sris.System.SR.InvalidOperation_NoDispIdAttribute);
                }
                sourceIid.$v = guid;
                dispid.$v = ($.$cast(dispIdAttribute, $.$spc.System.Runtime.InteropServices.DispIdAttribute)).Value;
            }
            static $h = 498584;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":76414977,"p":[{"p":76349441,"g":{"r":0,"d":0,"h":25770302360,"f":32769},"n":"Attributes","d":498584,"h":21475335064,"f":32769},{"p":142606337,"g":{"r":0,"d":0,"h":51540106136,"f":32769},"n":"DeclaringType","d":498584,"h":47245138840,"f":32769},{"p":655361,"g":{"r":0,"d":0,"h":77309909912,"f":32769},"n":"MetadataToken","d":498584,"h":73014942616,"f":32769},{"p":80216065,"g":{"r":0,"d":0,"h":85899844504,"f":32769},"n":"Module","d":498584,"h":81604877208,"f":32769},{"p":1310721,"g":{"r":0,"d":0,"h":94489779096,"f":32769},"n":"Name","d":498584,"h":90194811800,"f":32769},{"p":142606337,"g":{"r":0,"d":0,"h":103079713688,"f":32769},"n":"ReflectedType","d":498584,"h":98784746392,"f":32769}],"m":[{"r":65537,"p":[{"n":"target","p":131073},{"n":"handler","p":35651585}],"n":"AddEventHandler","d":498584,"h":12885400472,"f":32769,"a":[{"t":114950145,"c":4409917441,"a":[{"v":"windows","t":1310721}]}]},{"r":65537,"p":[{"n":"target","p":131073},{"n":"handler","p":35651585}],"n":"RemoveEventHandler","d":498584,"h":17180367768,"f":32769,"a":[{"t":114950145,"c":4409917441,"a":[{"v":"windows","t":1310721}]}]},{"r":79626241,"p":[{"n":"nonPublic","p":262145}],"n":"GetAddMethod","o":"@$1","d":498584,"h":30065269656,"f":32769},{"r":0,"p":[{"n":"nonPublic","p":262145}],"n":"GetOtherMethods","o":"@$1","d":498584,"h":34360236952,"f":32769},{"r":79626241,"p":[{"n":"nonPublic","p":262145}],"n":"GetRaiseMethod","o":"@$1","d":498584,"h":38655204248,"f":32769},{"r":79626241,"p":[{"n":"nonPublic","p":262145}],"n":"GetRemoveMethod","o":"@$1","d":498584,"h":42950171544,"f":32769},{"r":0,"p":[{"n":"attributeType","p":142606337},{"n":"inherit","p":262145}],"n":"GetCustomAttributes","o":"@$1","d":498584,"h":55835073432,"f":32769},{"r":0,"p":[{"n":"inherit","p":262145}],"n":"GetCustomAttributes","d":498584,"h":60130040728,"f":32769},{"r":$.$spc.System.Collections.Generic.IList$$($.$spc.System.Reflection.CustomAttributeData).$h,"n":"GetCustomAttributesData","d":498584,"h":64425008024,"f":32769},{"r":262145,"p":[{"n":"attributeType","p":142606337},{"n":"inherit","p":262145}],"n":"IsDefined","d":498584,"h":68719975320,"f":32769},{"r":65537,"p":[{"n":"eventInfo","p":76414977},{"n":"sourceIid","p":56164353,"f":2},{"n":"dispid","p":655361,"f":2}],"n":"GetDataForComInvocation","d":498584,"h":107374680984,"f":34}],"l":[{"t":76414977,"n":"_innerEventInfo","d":498584,"h":4295465880,"f":2}],"c":[{"p":[{"n":"type","p":142606337},{"n":"eventName","p":1310721}],"n":".ctor","o":"$ctor$4","d":498584,"h":8590433176,"f":1}],"i":[76939265],"h":498584,"a":[{"t":33161217,"c":4328128513,"a":[{"v":1,"t":33226753}]}]}; }
            static get $b() { return $.$spc.System.Reflection.EventInfo; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.Reflection.ICustomAttributeProvider ]; }
            static get $fullName() { return `System.Runtime.InteropServices.ComAwareEventInfo`; }
        });
        
        $asm.$str("$sris.System.Runtime.InteropServices.ComTypes.DATADIR", ($self) => class DATADIR extends $.$spc.System.Enum
        {
            static DATADIR_GET = 1;
            static DATADIR_SET = 2;
            static $map;
            static get Map()
            {
                return this.$map ??= 
                {
                    "DATADIR_GET": 1n,
                    "DATADIR_SET": 2n
                };
            }
            static $h = 826264;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static get $eut() { return $.$spc.System.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {"b":1048577,"u":655361,"l":[{"t":826264,"n":"DATADIR_GET","d":826264,"h":4295793560,"f":33},{"t":826264,"n":"DATADIR_SET","d":826264,"h":8590760856,"f":33}],"c":[{"n":".ctor","o":"$ctor$3","d":826264,"h":12885728152,"f":1}],"i":[57212929,63766529,57671681,57344001],"h":826264,"a":[{"t":33161217,"c":4328128513,"a":[{"v":1,"t":33226753}]}]}; }
            static get $b() { return $.$spc.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IComparable, $.$spc.System.ISpanFormattable, $.$spc.System.IFormattable, $.$spc.System.IConvertible ]; }
            static get $fullName() { return `System.Runtime.InteropServices.ComTypes.DATADIR`; }
        });
        
        $asm.$str("$sris.System.Runtime.InteropServices.ComTypes.ADVF", ($self) => class ADVF extends $.$spc.System.Enum
        {
            static ADVF_NODATA = 1;
            static ADVF_PRIMEFIRST = 2;
            static ADVF_ONLYONCE = 4;
            static ADVF_DATAONSTOP = 64;
            static ADVFCACHE_NOHANDLER = 8;
            static ADVFCACHE_FORCEBUILTIN = 16;
            static ADVFCACHE_ONSAVE = 32;
            static $map;
            static get Map()
            {
                return this.$map ??= 
                {
                    "ADVF_NODATA": 1n,
                    "ADVF_PRIMEFIRST": 2n,
                    "ADVF_ONLYONCE": 4n,
                    "ADVF_DATAONSTOP": 64n,
                    "ADVFCACHE_NOHANDLER": 8n,
                    "ADVFCACHE_FORCEBUILTIN": 16n,
                    "ADVFCACHE_ONSAVE": 32n
                };
            }
            static $h = 760728;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static get $eut() { return $.$spc.System.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {"b":1048577,"u":655361,"l":[{"t":760728,"n":"ADVF_NODATA","d":760728,"h":4295728024,"f":33},{"t":760728,"n":"ADVF_PRIMEFIRST","d":760728,"h":8590695320,"f":33},{"t":760728,"n":"ADVF_ONLYONCE","d":760728,"h":12885662616,"f":33},{"t":760728,"n":"ADVF_DATAONSTOP","d":760728,"h":17180629912,"f":33},{"t":760728,"n":"ADVFCACHE_NOHANDLER","d":760728,"h":21475597208,"f":33},{"t":760728,"n":"ADVFCACHE_FORCEBUILTIN","d":760728,"h":25770564504,"f":33},{"t":760728,"n":"ADVFCACHE_ONSAVE","d":760728,"h":30065531800,"f":33}],"c":[{"n":".ctor","o":"$ctor$3","d":760728,"h":34360499096,"f":1}],"i":[57212929,63766529,57671681,57344001],"h":760728,"a":[{"t":33161217,"c":4328128513,"a":[{"v":1,"t":33226753}]},{"t":47644673,"c":4342611969}]}; }
            static get $b() { return $.$spc.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IComparable, $.$spc.System.ISpanFormattable, $.$spc.System.IFormattable, $.$spc.System.IConvertible ]; }
            static get $fullName() { return `System.Runtime.InteropServices.ComTypes.ADVF`; }
        });
        
        $asm.$str("$sris.System.Runtime.InteropServices.ComTypes.DVASPECT", ($self) => class DVASPECT extends $.$spc.System.Enum
        {
            static DVASPECT_CONTENT = 1;
            static DVASPECT_THUMBNAIL = 2;
            static DVASPECT_ICON = 4;
            static DVASPECT_DOCPRINT = 8;
            static $map;
            static get Map()
            {
                return this.$map ??= 
                {
                    "DVASPECT_CONTENT": 1n,
                    "DVASPECT_THUMBNAIL": 2n,
                    "DVASPECT_ICON": 4n,
                    "DVASPECT_DOCPRINT": 8n
                };
            }
            static $h = 891800;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static get $eut() { return $.$spc.System.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {"b":1048577,"u":655361,"l":[{"t":891800,"n":"DVASPECT_CONTENT","d":891800,"h":4295859096,"f":33},{"t":891800,"n":"DVASPECT_THUMBNAIL","d":891800,"h":8590826392,"f":33},{"t":891800,"n":"DVASPECT_ICON","d":891800,"h":12885793688,"f":33},{"t":891800,"n":"DVASPECT_DOCPRINT","d":891800,"h":17180760984,"f":33}],"c":[{"n":".ctor","o":"$ctor$3","d":891800,"h":21475728280,"f":1}],"i":[57212929,63766529,57671681,57344001],"h":891800,"a":[{"t":33161217,"c":4328128513,"a":[{"v":1,"t":33226753}]},{"t":47644673,"c":4342611969}]}; }
            static get $b() { return $.$spc.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IComparable, $.$spc.System.ISpanFormattable, $.$spc.System.IFormattable, $.$spc.System.IConvertible ]; }
            static get $fullName() { return `System.Runtime.InteropServices.ComTypes.DVASPECT`; }
        });
        
        $asm.$str("$sris.System.Runtime.InteropServices.AssemblyRegistrationFlags", ($self) => class AssemblyRegistrationFlags extends $.$spc.System.Enum
        {
            static None = 0;
            static SetCodeBase = 1;
            static $map;
            static get Map()
            {
                return this.$map ??= 
                {
                    "None": 0n,
                    "SetCodeBase": 1n
                };
            }
            static $h = 301976;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static get $eut() { return $.$spc.System.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {"b":1048577,"u":655361,"l":[{"t":301976,"n":"None","d":301976,"h":4295269272,"f":33},{"t":301976,"n":"SetCodeBase","d":301976,"h":8590236568,"f":33}],"c":[{"n":".ctor","o":"$ctor$3","d":301976,"h":12885203864,"f":1}],"i":[57212929,63766529,57671681,57344001],"h":301976,"a":[{"t":47644673,"c":4342611969}]}; }
            static get $b() { return $.$spc.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IComparable, $.$spc.System.ISpanFormattable, $.$spc.System.IFormattable, $.$spc.System.IConvertible ]; }
            static get $fullName() { return `System.Runtime.InteropServices.AssemblyRegistrationFlags`; }
        });
        
        $asm.$str("$sris.System.Runtime.InteropServices.ComTypes.TYMED", ($self) => class TYMED extends $.$spc.System.Enum
        {
            static TYMED_HGLOBAL = 1;
            static TYMED_FILE = 2;
            static TYMED_ISTREAM = 4;
            static TYMED_ISTORAGE = 8;
            static TYMED_GDI = 16;
            static TYMED_MFPICT = 32;
            static TYMED_ENHMF = 64;
            static TYMED_NULL = 0;
            static $map;
            static get Map()
            {
                return this.$map ??= 
                {
                    "TYMED_HGLOBAL": 1n,
                    "TYMED_FILE": 2n,
                    "TYMED_ISTREAM": 4n,
                    "TYMED_ISTORAGE": 8n,
                    "TYMED_GDI": 16n,
                    "TYMED_MFPICT": 32n,
                    "TYMED_ENHMF": 64n,
                    "TYMED_NULL": 0n
                };
            }
            static $h = 1416088;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static get $eut() { return $.$spc.System.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {"b":1048577,"u":655361,"l":[{"t":1416088,"n":"TYMED_HGLOBAL","d":1416088,"h":4296383384,"f":33},{"t":1416088,"n":"TYMED_FILE","d":1416088,"h":8591350680,"f":33},{"t":1416088,"n":"TYMED_ISTREAM","d":1416088,"h":12886317976,"f":33},{"t":1416088,"n":"TYMED_ISTORAGE","d":1416088,"h":17181285272,"f":33},{"t":1416088,"n":"TYMED_GDI","d":1416088,"h":21476252568,"f":33},{"t":1416088,"n":"TYMED_MFPICT","d":1416088,"h":25771219864,"f":33},{"t":1416088,"n":"TYMED_ENHMF","d":1416088,"h":30066187160,"f":33},{"t":1416088,"n":"TYMED_NULL","d":1416088,"h":34361154456,"f":33}],"c":[{"n":".ctor","o":"$ctor$3","d":1416088,"h":38656121752,"f":1}],"i":[57212929,63766529,57671681,57344001],"h":1416088,"a":[{"t":33161217,"c":4328128513,"a":[{"v":1,"t":33226753}]},{"t":47644673,"c":4342611969}]}; }
            static get $b() { return $.$spc.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IComparable, $.$spc.System.ISpanFormattable, $.$spc.System.IFormattable, $.$spc.System.IConvertible ]; }
            static get $fullName() { return `System.Runtime.InteropServices.ComTypes.TYMED`; }
        });
        
        $asm.$str("$sris.System.Runtime.InteropServices.ExporterEventKind", ($self) => class ExporterEventKind extends $.$spc.System.Enum
        {
            static NOTIF_TYPECONVERTED = 0;
            static NOTIF_CONVERTWARNING = 1;
            static ERROR_REFTOINVALIDASSEMBLY = 2;
            static $map;
            static get Map()
            {
                return this.$map ??= 
                {
                    "NOTIF_TYPECONVERTED": 0n,
                    "NOTIF_CONVERTWARNING": 1n,
                    "ERROR_REFTOINVALIDASSEMBLY": 2n
                };
            }
            static $h = 1547160;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static get $eut() { return $.$spc.System.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {"b":1048577,"u":655361,"l":[{"t":1547160,"n":"NOTIF_TYPECONVERTED","d":1547160,"h":4296514456,"f":33},{"t":1547160,"n":"NOTIF_CONVERTWARNING","d":1547160,"h":8591481752,"f":33},{"t":1547160,"n":"ERROR_REFTOINVALIDASSEMBLY","d":1547160,"h":12886449048,"f":33}],"c":[{"n":".ctor","o":"$ctor$3","d":1547160,"h":17181416344,"f":1}],"i":[57212929,63766529,57671681,57344001],"h":1547160}; }
            static get $b() { return $.$spc.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IComparable, $.$spc.System.ISpanFormattable, $.$spc.System.IFormattable, $.$spc.System.IConvertible ]; }
            static get $fullName() { return `System.Runtime.InteropServices.ExporterEventKind`; }
        });
        
        $asm.$str("$sris.System.Runtime.InteropServices.Marshalling.ComInterfaceOptions", ($self) => class ComInterfaceOptions extends $.$spc.System.Enum
        {
            static None = 0;
            static ManagedObjectWrapper = 1;
            static ComObjectWrapper = 2;
            static $map;
            static get Map()
            {
                return this.$map ??= 
                {
                    "None": 0n,
                    "ManagedObjectWrapper": 1n,
                    "ComObjectWrapper": 2n
                };
            }
            static $h = 2136984;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static get $eut() { return $.$spc.System.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {"b":1048577,"u":655361,"l":[{"t":2136984,"n":"None","d":2136984,"h":4297104280,"f":33,"a":[{"t":33161217,"c":4328128513,"a":[{"v":1,"t":33226753}]}]},{"t":2136984,"n":"ManagedObjectWrapper","d":2136984,"h":8592071576,"f":33},{"t":2136984,"n":"ComObjectWrapper","d":2136984,"h":12887038872,"f":33}],"c":[{"n":".ctor","o":"$ctor$3","d":2136984,"h":17182006168,"f":1}],"i":[57212929,63766529,57671681,57344001],"h":2136984,"a":[{"t":47644673,"c":4342611969}]}; }
            static get $b() { return $.$spc.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IComparable, $.$spc.System.ISpanFormattable, $.$spc.System.IFormattable, $.$spc.System.IConvertible ]; }
            static get $fullName() { return `System.Runtime.InteropServices.Marshalling.ComInterfaceOptions`; }
        });
        
        $asm.$str("$sris.System.Runtime.InteropServices.RegistrationClassContext", ($self) => class RegistrationClassContext extends $.$spc.System.Enum
        {
            static InProcessServer = 1;
            static InProcessHandler = 2;
            static LocalServer = 4;
            static InProcessServer16 = 8;
            static RemoteServer = 16;
            static InProcessHandler16 = 32;
            static Reserved1 = 64;
            static Reserved2 = 128;
            static Reserved3 = 256;
            static Reserved4 = 512;
            static NoCodeDownload = 1024;
            static Reserved5 = 2048;
            static NoCustomMarshal = 4096;
            static EnableCodeDownload = 8192;
            static NoFailureLog = 16384;
            static DisableActivateAsActivator = 32768;
            static EnableActivateAsActivator = 65536;
            static FromDefaultContext = 131072;
            static $map;
            static get Map()
            {
                return this.$map ??= 
                {
                    "InProcessServer": 1n,
                    "InProcessHandler": 2n,
                    "LocalServer": 4n,
                    "InProcessServer16": 8n,
                    "RemoteServer": 16n,
                    "InProcessHandler16": 32n,
                    "Reserved1": 64n,
                    "Reserved2": 128n,
                    "Reserved3": 256n,
                    "Reserved4": 512n,
                    "NoCodeDownload": 1024n,
                    "Reserved5": 2048n,
                    "NoCustomMarshal": 4096n,
                    "EnableCodeDownload": 8192n,
                    "NoFailureLog": 16384n,
                    "DisableActivateAsActivator": 32768n,
                    "EnableActivateAsActivator": 65536n,
                    "FromDefaultContext": 131072n
                };
            }
            static $h = 3906456;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static get $eut() { return $.$spc.System.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {"b":1048577,"u":655361,"l":[{"t":3906456,"n":"InProcessServer","d":3906456,"h":4298873752,"f":33},{"t":3906456,"n":"InProcessHandler","d":3906456,"h":8593841048,"f":33},{"t":3906456,"n":"LocalServer","d":3906456,"h":12888808344,"f":33},{"t":3906456,"n":"InProcessServer16","d":3906456,"h":17183775640,"f":33},{"t":3906456,"n":"RemoteServer","d":3906456,"h":21478742936,"f":33},{"t":3906456,"n":"InProcessHandler16","d":3906456,"h":25773710232,"f":33},{"t":3906456,"n":"Reserved1","d":3906456,"h":30068677528,"f":33},{"t":3906456,"n":"Reserved2","d":3906456,"h":34363644824,"f":33},{"t":3906456,"n":"Reserved3","d":3906456,"h":38658612120,"f":33},{"t":3906456,"n":"Reserved4","d":3906456,"h":42953579416,"f":33},{"t":3906456,"n":"NoCodeDownload","d":3906456,"h":47248546712,"f":33},{"t":3906456,"n":"Reserved5","d":3906456,"h":51543514008,"f":33},{"t":3906456,"n":"NoCustomMarshal","d":3906456,"h":55838481304,"f":33},{"t":3906456,"n":"EnableCodeDownload","d":3906456,"h":60133448600,"f":33},{"t":3906456,"n":"NoFailureLog","d":3906456,"h":64428415896,"f":33},{"t":3906456,"n":"DisableActivateAsActivator","d":3906456,"h":68723383192,"f":33},{"t":3906456,"n":"EnableActivateAsActivator","d":3906456,"h":73018350488,"f":33},{"t":3906456,"n":"FromDefaultContext","d":3906456,"h":77313317784,"f":33}],"c":[{"n":".ctor","o":"$ctor$3","d":3906456,"h":81608285080,"f":1}],"i":[57212929,63766529,57671681,57344001],"h":3906456,"a":[{"t":47644673,"c":4342611969}]}; }
            static get $b() { return $.$spc.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IComparable, $.$spc.System.ISpanFormattable, $.$spc.System.IFormattable, $.$spc.System.IConvertible ]; }
            static get $fullName() { return `System.Runtime.InteropServices.RegistrationClassContext`; }
        });
        
        $asm.$str("$sris.System.Runtime.InteropServices.RegistrationConnectionType", ($self) => class RegistrationConnectionType extends $.$spc.System.Enum
        {
            static SingleUse = 0;
            static MultipleUse = 1;
            static MultiSeparate = 2;
            static Suspended = 4;
            static Surrogate = 8;
            static $map;
            static get Map()
            {
                return this.$map ??= 
                {
                    "SingleUse": 0n,
                    "MultipleUse": 1n,
                    "MultiSeparate": 2n,
                    "Suspended": 4n,
                    "Surrogate": 8n
                };
            }
            static $h = 3971992;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static get $eut() { return $.$spc.System.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {"b":1048577,"u":655361,"l":[{"t":3971992,"n":"SingleUse","d":3971992,"h":4298939288,"f":33},{"t":3971992,"n":"MultipleUse","d":3971992,"h":8593906584,"f":33},{"t":3971992,"n":"MultiSeparate","d":3971992,"h":12888873880,"f":33},{"t":3971992,"n":"Suspended","d":3971992,"h":17183841176,"f":33},{"t":3971992,"n":"Surrogate","d":3971992,"h":21478808472,"f":33}],"c":[{"n":".ctor","o":"$ctor$3","d":3971992,"h":25773775768,"f":1}],"i":[57212929,63766529,57671681,57344001],"h":3971992,"a":[{"t":47644673,"c":4342611969}]}; }
            static get $b() { return $.$spc.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IComparable, $.$spc.System.ISpanFormattable, $.$spc.System.IFormattable, $.$spc.System.IConvertible ]; }
            static get $fullName() { return `System.Runtime.InteropServices.RegistrationConnectionType`; }
        });
        
        $asm.$str("$sris.System.Runtime.InteropServices.TypeLibTypeFlags", ($self) => class TypeLibTypeFlags extends $.$spc.System.Enum
        {
            static FAppObject = 1;
            static FCanCreate = 2;
            static FLicensed = 4;
            static FPreDeclId = 8;
            static FHidden = 16;
            static FControl = 32;
            static FDual = 64;
            static FNonExtensible = 128;
            static FOleAutomation = 256;
            static FRestricted = 512;
            static FAggregatable = 1024;
            static FReplaceable = 2048;
            static FDispatchable = 4096;
            static FReverseBind = 8192;
            static $map;
            static get Map()
            {
                return this.$map ??= 
                {
                    "FAppObject": 1n,
                    "FCanCreate": 2n,
                    "FLicensed": 4n,
                    "FPreDeclId": 8n,
                    "FHidden": 16n,
                    "FControl": 32n,
                    "FDual": 64n,
                    "FNonExtensible": 128n,
                    "FOleAutomation": 256n,
                    "FRestricted": 512n,
                    "FAggregatable": 1024n,
                    "FReplaceable": 2048n,
                    "FDispatchable": 4096n,
                    "FReverseBind": 8192n
                };
            }
            static $h = 4365208;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static get $eut() { return $.$spc.System.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {"b":1048577,"u":655361,"l":[{"t":4365208,"n":"FAppObject","d":4365208,"h":4299332504,"f":33},{"t":4365208,"n":"FCanCreate","d":4365208,"h":8594299800,"f":33},{"t":4365208,"n":"FLicensed","d":4365208,"h":12889267096,"f":33},{"t":4365208,"n":"FPreDeclId","d":4365208,"h":17184234392,"f":33},{"t":4365208,"n":"FHidden","d":4365208,"h":21479201688,"f":33},{"t":4365208,"n":"FControl","d":4365208,"h":25774168984,"f":33},{"t":4365208,"n":"FDual","d":4365208,"h":30069136280,"f":33},{"t":4365208,"n":"FNonExtensible","d":4365208,"h":34364103576,"f":33},{"t":4365208,"n":"FOleAutomation","d":4365208,"h":38659070872,"f":33},{"t":4365208,"n":"FRestricted","d":4365208,"h":42954038168,"f":33},{"t":4365208,"n":"FAggregatable","d":4365208,"h":47249005464,"f":33},{"t":4365208,"n":"FReplaceable","d":4365208,"h":51543972760,"f":33},{"t":4365208,"n":"FDispatchable","d":4365208,"h":55838940056,"f":33},{"t":4365208,"n":"FReverseBind","d":4365208,"h":60133907352,"f":33}],"c":[{"n":".ctor","o":"$ctor$3","d":4365208,"h":64428874648,"f":1}],"i":[57212929,63766529,57671681,57344001],"h":4365208,"a":[{"t":47644673,"c":4342611969}]}; }
            static get $b() { return $.$spc.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IComparable, $.$spc.System.ISpanFormattable, $.$spc.System.IFormattable, $.$spc.System.IConvertible ]; }
            static get $fullName() { return `System.Runtime.InteropServices.TypeLibTypeFlags`; }
        });
        
        $asm.$str("$sris.System.Runtime.InteropServices.TypeLibVarFlags", ($self) => class TypeLibVarFlags extends $.$spc.System.Enum
        {
            static FReadOnly = 1;
            static FSource = 2;
            static FBindable = 4;
            static FRequestEdit = 8;
            static FDisplayBind = 16;
            static FDefaultBind = 32;
            static FHidden = 64;
            static FRestricted = 128;
            static FDefaultCollelem = 256;
            static FUiDefault = 512;
            static FNonBrowsable = 1024;
            static FReplaceable = 2048;
            static FImmediateBind = 4096;
            static $map;
            static get Map()
            {
                return this.$map ??= 
                {
                    "FReadOnly": 1n,
                    "FSource": 2n,
                    "FBindable": 4n,
                    "FRequestEdit": 8n,
                    "FDisplayBind": 16n,
                    "FDefaultBind": 32n,
                    "FHidden": 64n,
                    "FRestricted": 128n,
                    "FDefaultCollelem": 256n,
                    "FUiDefault": 512n,
                    "FNonBrowsable": 1024n,
                    "FReplaceable": 2048n,
                    "FImmediateBind": 4096n
                };
            }
            static $h = 4496280;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static get $eut() { return $.$spc.System.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {"b":1048577,"u":655361,"l":[{"t":4496280,"n":"FReadOnly","d":4496280,"h":4299463576,"f":33},{"t":4496280,"n":"FSource","d":4496280,"h":8594430872,"f":33},{"t":4496280,"n":"FBindable","d":4496280,"h":12889398168,"f":33},{"t":4496280,"n":"FRequestEdit","d":4496280,"h":17184365464,"f":33},{"t":4496280,"n":"FDisplayBind","d":4496280,"h":21479332760,"f":33},{"t":4496280,"n":"FDefaultBind","d":4496280,"h":25774300056,"f":33},{"t":4496280,"n":"FHidden","d":4496280,"h":30069267352,"f":33},{"t":4496280,"n":"FRestricted","d":4496280,"h":34364234648,"f":33},{"t":4496280,"n":"FDefaultCollelem","d":4496280,"h":38659201944,"f":33},{"t":4496280,"n":"FUiDefault","d":4496280,"h":42954169240,"f":33},{"t":4496280,"n":"FNonBrowsable","d":4496280,"h":47249136536,"f":33},{"t":4496280,"n":"FReplaceable","d":4496280,"h":51544103832,"f":33},{"t":4496280,"n":"FImmediateBind","d":4496280,"h":55839071128,"f":33}],"c":[{"n":".ctor","o":"$ctor$3","d":4496280,"h":60134038424,"f":1}],"i":[57212929,63766529,57671681,57344001],"h":4496280,"a":[{"t":47644673,"c":4342611969}]}; }
            static get $b() { return $.$spc.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IComparable, $.$spc.System.ISpanFormattable, $.$spc.System.IFormattable, $.$spc.System.IConvertible ]; }
            static get $fullName() { return `System.Runtime.InteropServices.TypeLibVarFlags`; }
        });
        
        $asm.$str("$sris.System.Runtime.InteropServices.TypeLibFuncFlags", ($self) => class TypeLibFuncFlags extends $.$spc.System.Enum
        {
            static FRestricted = 1;
            static FSource = 2;
            static FBindable = 4;
            static FRequestEdit = 8;
            static FDisplayBind = 16;
            static FDefaultBind = 32;
            static FHidden = 64;
            static FUsesGetLastError = 128;
            static FDefaultCollelem = 256;
            static FUiDefault = 512;
            static FNonBrowsable = 1024;
            static FReplaceable = 2048;
            static FImmediateBind = 4096;
            static $map;
            static get Map()
            {
                return this.$map ??= 
                {
                    "FRestricted": 1n,
                    "FSource": 2n,
                    "FBindable": 4n,
                    "FRequestEdit": 8n,
                    "FDisplayBind": 16n,
                    "FDefaultBind": 32n,
                    "FHidden": 64n,
                    "FUsesGetLastError": 128n,
                    "FDefaultCollelem": 256n,
                    "FUiDefault": 512n,
                    "FNonBrowsable": 1024n,
                    "FReplaceable": 2048n,
                    "FImmediateBind": 4096n
                };
            }
            static $h = 4168600;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static get $eut() { return $.$spc.System.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {"b":1048577,"u":655361,"l":[{"t":4168600,"n":"FRestricted","d":4168600,"h":4299135896,"f":33},{"t":4168600,"n":"FSource","d":4168600,"h":8594103192,"f":33},{"t":4168600,"n":"FBindable","d":4168600,"h":12889070488,"f":33},{"t":4168600,"n":"FRequestEdit","d":4168600,"h":17184037784,"f":33},{"t":4168600,"n":"FDisplayBind","d":4168600,"h":21479005080,"f":33},{"t":4168600,"n":"FDefaultBind","d":4168600,"h":25773972376,"f":33},{"t":4168600,"n":"FHidden","d":4168600,"h":30068939672,"f":33},{"t":4168600,"n":"FUsesGetLastError","d":4168600,"h":34363906968,"f":33},{"t":4168600,"n":"FDefaultCollelem","d":4168600,"h":38658874264,"f":33},{"t":4168600,"n":"FUiDefault","d":4168600,"h":42953841560,"f":33},{"t":4168600,"n":"FNonBrowsable","d":4168600,"h":47248808856,"f":33},{"t":4168600,"n":"FReplaceable","d":4168600,"h":51543776152,"f":33},{"t":4168600,"n":"FImmediateBind","d":4168600,"h":55838743448,"f":33}],"c":[{"n":".ctor","o":"$ctor$3","d":4168600,"h":60133710744,"f":1}],"i":[57212929,63766529,57671681,57344001],"h":4168600,"a":[{"t":47644673,"c":4342611969}]}; }
            static get $b() { return $.$spc.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IComparable, $.$spc.System.ISpanFormattable, $.$spc.System.IFormattable, $.$spc.System.IConvertible ]; }
            static get $fullName() { return `System.Runtime.InteropServices.TypeLibFuncFlags`; }
        });
        
        $asm.$cls("$sris.System.Runtime.InteropServices.Marshalling.ComObject", ($self) => class ComObject extends $.$spc.System.Object
        {
            /*bool*/ static BuiltInComSupported = false;
            /*bool*/ static ComImportInteropEnabled = false;
            /*void**/ _instancePointer;
            /*object?*/ _runtimeCallableWrapper = null;
            /*bool*/ _released = false;
            $ctor$1(/*IIUnknownInterfaceDetailsStrategy*/ interfaceDetailsStrategy, /*IIUnknownStrategy*/ iunknownStrategy, /*IIUnknownCacheStrategy*/ cacheStrategy, /*void**/ thisPointer)
            {
                super.$ctor();
                {
                    this.InterfaceDetailsStrategy = interfaceDetailsStrategy;
                    this.IUnknownStrategy = iunknownStrategy;
                    this.CacheStrategy = cacheStrategy;
                    this._instancePointer = this.IUnknownStrategy.System$Runtime$InteropServices$Marshalling$IIUnknownStrategy$CreateInstancePointer(thisPointer);
                    if ($.$spc.System.OperatingSystem.IsWindows() && $.$sris.System.Runtime.InteropServices.Marshalling.ComObject.BuiltInComSupported && $.$sris.System.Runtime.InteropServices.Marshalling.ComObject.ComImportInteropEnabled)
                    {
                        this._runtimeCallableWrapper = $.$spc.System.Runtime.InteropServices.Marshal.GetObjectForIUnknown($.$spc.System.IntPtr.op_Explicit$2(thisPointer));
                        $.$spc.System.Diagnostics.Debug.Assert$1($.$spc.System.Runtime.InteropServices.Marshal.IsComObject(this._runtimeCallableWrapper), "Marshal.IsComObject(_runtimeCallableWrapper)");
                    }
                }
                return this;
            }
            $dtor()
            {
                this.CacheStrategy.System$Runtime$InteropServices$Marshalling$IIUnknownCacheStrategy$Clear(this.IUnknownStrategy);
                this.IUnknownStrategy.System$Runtime$InteropServices$Marshalling$IIUnknownStrategy$Release(this._instancePointer);
            }
            /*IIUnknownInterfaceDetailsStrategy*/ InterfaceDetailsStrategy = null;
            /*IIUnknownStrategy*/ IUnknownStrategy = null;
            /*IIUnknownCacheStrategy*/ CacheStrategy = null;
            /*bool*/ UniqueInstance = false;
            /*void */ FinalRelease()
            {
                if (this.UniqueInstance && !$.$spc.System.Threading.Interlocked.Exchange$14($.$spc.System.Boolean, $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateObjectReferenceT($.$spc.System.Boolean, () => this._released, ($v) => this._released = $v, null), true))
                {
                    $.$spc.System.GC.SuppressFinalize(this);
                    this.CacheStrategy.System$Runtime$InteropServices$Marshalling$IIUnknownCacheStrategy$Clear(this.IUnknownStrategy);
                    this.IUnknownStrategy.System$Runtime$InteropServices$Marshalling$IIUnknownStrategy$Release(this._instancePointer);
                }
            }
            /*RuntimeTypeHandle */ System$Runtime$InteropServices$IDynamicInterfaceCastable$GetInterfaceImplementation(/*RuntimeTypeHandle*/ interfaceType)
            {
                /*IIUnknownCacheStrategy.TableInfo*/ let info;
                /*int*/ let qiResult;
                if (!this.LookUpVTableInfo(interfaceType, $.$ref(() => info, ($v) => info = $v, $.$sris.System.Runtime.InteropServices.Marshalling.IIUnknownCacheStrategy.TableInfo), $.$ref(() => qiResult, ($v) => qiResult = $v, $.$spc.System.Int32)))
                {
                    $.$spc.System.Runtime.InteropServices.Marshal.ThrowExceptionForHR(qiResult);
                }
                return info.ManagedType;
            }
            /*bool */ System$Runtime$InteropServices$IDynamicInterfaceCastable$IsInterfaceImplemented(/*RuntimeTypeHandle*/ interfaceType, /*bool*/ throwIfNotImplemented)
            {
                /*int*/ let qiResult;
                if (!this.LookUpVTableInfo(interfaceType, $.$discardRef(), $.$ref(() => qiResult, ($v) => qiResult = $v, $.$spc.System.Int32)))
                {
                    if (throwIfNotImplemented)
                    {
                        $.$spc.System.Runtime.InteropServices.Marshal.ThrowExceptionForHR(qiResult);
                    }
                    return false;
                }
                return true;
            }
            /*bool */ LookUpVTableInfo(/*RuntimeTypeHandle*/ handle, /*out IIUnknownCacheStrategy.TableInfo*/ result, /*out int*/ qiHResult)
            {
                $.$spc.System.ObjectDisposedException.ThrowIf(this._released, this);
                qiHResult.$v = 0;
                if (!this.CacheStrategy.System$Runtime$InteropServices$Marshalling$IIUnknownCacheStrategy$TryGetTableInfo(handle, result))
                {
                    /*IIUnknownDerivedDetails?*/ let details = this.InterfaceDetailsStrategy.System$Runtime$InteropServices$Marshalling$IIUnknownInterfaceDetailsStrategy$GetIUnknownDerivedDetails(handle);
                    if (details === null)
                    {
                        return false;
                    }
                    /*void**/ let ppv;
                    /*int*/ let hr = this.IUnknownStrategy.System$Runtime$InteropServices$Marshalling$IIUnknownStrategy$QueryInterface(this._instancePointer, $.$ref(() => details.System$Runtime$InteropServices$Marshalling$IIUnknownDerivedDetails$Iid, ), $.$ref(() => ppv, ($v) => ppv = $v, $.$typePointer($.$spc.System.Void)));
                    if (hr < 0)
                    {
                        qiHResult.$v = hr;
                        return false;
                    }
                    result.$v = this.CacheStrategy.System$Runtime$InteropServices$Marshalling$IIUnknownCacheStrategy$ConstructTableInfo(handle, details, ppv);
                    if (!this.CacheStrategy.System$Runtime$InteropServices$Marshalling$IIUnknownCacheStrategy$TrySetTableInfo(handle, result.$v))
                    {
                        /*bool*/ let found = this.CacheStrategy.System$Runtime$InteropServices$Marshalling$IIUnknownCacheStrategy$TryGetTableInfo(handle, result);
                        $.$spc.System.Diagnostics.Debug.Assert$1(found, "found");
                        _ = this.IUnknownStrategy.System$Runtime$InteropServices$Marshalling$IIUnknownStrategy$Release(ppv);
                    }
                }
                return true;
            }
            /*VirtualMethodTableInfo */ System$Runtime$InteropServices$Marshalling$IUnmanagedVirtualMethodTableProvider$GetVirtualMethodTableInfoForKey(/*Type*/ type)
            {
                /*IIUnknownCacheStrategy.TableInfo*/ let result;
                /*int*/ let qiHResult;
                if (!this.LookUpVTableInfo(type.TypeHandle, $.$ref(() => result, ($v) => result = $v, $.$sris.System.Runtime.InteropServices.Marshalling.IIUnknownCacheStrategy.TableInfo), $.$ref(() => qiHResult, ($v) => qiHResult = $v, $.$spc.System.Int32)))
                {
                    $.$spc.System.Runtime.InteropServices.Marshal.ThrowExceptionForHR(qiHResult);
                }
                return new $.$sris.System.Runtime.InteropServices.Marshalling.VirtualMethodTableInfo().$ctor$2(result.ThisPtr, result.Table);
            }
            /*object */ System$Runtime$InteropServices$Marshalling$ComImportInteropInterfaceDetailsStrategy$IComImportAdapter$GetRuntimeCallableWrapper()
            {
                $.$spc.System.Diagnostics.Debug.Assert$1(this._runtimeCallableWrapper !== null, "_runtimeCallableWrapper != null");
                return this._runtimeCallableWrapper;
            }
            //default member initializer
            constructor()
            {
                super();
                this._instancePointer = $.$default($.$typePointer($.$spc.System.Void));
                this.UniqueInstance = false;
                $.$finalizer(this);
            }
            //Static Initializer
            static $sinit()
            {
                {
                    /*bool*/ let supported;
                    this.BuiltInComSupported = $.$spc.System.AppContext.TryGetSwitch("System.Runtime.InteropServices.BuiltInComInterop.IsSupported", $.$ref(() => supported, ($v) => supported = $v, $.$spc.System.Boolean)) ? supported : true;
                }
                {
                    /*bool*/ let enabled;
                    this.ComImportInteropEnabled = $.$spc.System.AppContext.TryGetSwitch("System.Runtime.InteropServices.Marshalling.EnableGeneratedComInterfaceComImportInterop", $.$ref(() => enabled, ($v) => enabled = $v, $.$spc.System.Boolean)) ? enabled : false;
                }
            }
            static $h = 2202520;
            static $f = 0b10010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":262145,"g":{"r":0,"d":0,"h":12887104408,"f":40},"n":"BuiltInComSupported","d":2202520,"h":8592137112,"f":40},{"p":262145,"g":{"r":0,"d":0,"h":25772006296,"f":40},"n":"ComImportInteropEnabled","d":2202520,"h":21477039000,"f":40},{"p":3316632,"g":{"r":0,"d":0,"h":60131744664,"f":2},"n":"InterfaceDetailsStrategy","d":2202520,"h":55836777368,"f":2},{"p":3447704,"g":{"r":0,"d":0,"h":73016646552,"f":2},"n":"IUnknownStrategy","d":2202520,"h":68721679256,"f":2},{"p":3120024,"g":{"r":0,"d":0,"h":85901548440,"f":2},"n":"CacheStrategy","d":2202520,"h":81606581144,"f":2},{"p":262145,"g":{"r":0,"d":0,"h":98786450328,"f":8},"s":{"r":0,"d":0,"h":103081417624,"f":8},"n":"UniqueInstance","d":2202520,"h":94491483032,"f":8}],"m":[{"r":65537,"n":"FinalRelease","d":2202520,"h":107376384920,"f":1},{"r":262145,"p":[{"n":"handle","p":116064257},{"n":"result","p":3185560,"f":2},{"n":"qiHResult","p":655361,"f":2}],"n":"LookUpVTableInfo","d":2202520,"h":120261286808,"f":2}],"l":[{"t":0,"n":"_instancePointer","d":2202520,"h":30066973592,"f":2},{"t":131073,"n":"_runtimeCallableWrapper","d":2202520,"h":34361940888,"f":2},{"t":262145,"n":"_released","d":2202520,"h":38656908184,"f":2}],"c":[{"p":[{"n":"interfaceDetailsStrategy","p":3316632},{"n":"iunknownStrategy","p":3447704},{"n":"cacheStrategy","p":3120024},{"n":"thisPointer","p":0}],"n":".ctor","o":"$ctor$1","d":2202520,"h":42951875480,"f":8}],"i":[104792065,3578776,2005912],"h":2202520}; }
            static get $b() { return $.$spc.System.Object; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.Runtime.InteropServices.IDynamicInterfaceCastable, $.$sris.System.Runtime.InteropServices.Marshalling.IUnmanagedVirtualMethodTableProvider, $.$sris.System.Runtime.InteropServices.Marshalling.ComImportInteropInterfaceDetailsStrategy.IComImportAdapter ]; }
            static get $fullName() { return `System.Runtime.InteropServices.Marshalling.ComObject`; }
        });
	});
})(window, window.NetJs.$boot(), ...window.NetJs.$require("NetJs.System.Private.CoreLib", "NetJs.System.Collections", "NetJs.System.Diagnostics.Tracing", "NetJs.System.Threading", "NetJs.System.Collections.Concurrent"))