
//--TRIMMABLE-BOUNDARY-START(36019)
(function ($global, $, $$) {
    "use strict";
    let _;
    
    
    
	$.$asm(
    "NetJs.System.Runtime.Intrinsics", 
    {
  "h": 36019,
  "f": "System.Runtime.Intrinsics",
  "v": "1.0.35.0",
  "a": [
    {
      "t": 159121409,
      "c": 13044023297,
      "a": [
        {
          "v": ".NETCoreApp,Version=v10.0",
          "t": 1310721
        }
      ],
      "n": [
        {
          "n": "FrameworkDisplayName",
          "v": ".NET 10.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 106299393,
      "c": 4401266689,
      "a": [
        {
          "v": "SIT",
          "t": 1310721
        }
      ]
    },
    {
      "t": 106364929,
      "c": 4401332225,
      "a": [
        {
          "v": "Debug",
          "t": 1310721
        }
      ]
    },
    {
      "t": 106823681,
      "c": 4401790977,
      "a": [
        {
          "v": "1.0.35.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 106954753,
      "c": 4401922049,
      "a": [
        {
          "v": "1.0.35\u002B39e7ca3e4bf1d7d75afdb3a3db320b6c1a1b2fcf",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107806721,
      "c": 4402774017,
      "a": [
        {
          "v": "NetJs.System.Runtime.Intrinsics",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107937793,
      "c": 4402905089,
      "a": [
        {
          "v": "NetJs.System.Runtime.Intrinsics",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108068865,
      "c": 4403036161,
      "a": [
        {
          "v": "1.0.35.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 159186945,
      "c": 4454154241,
      "a": [
        {
          "v": "browser1.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 158924801,
      "c": 4453892097,
      "a": [
        {
          "v": "browser1.0",
          "t": 1310721
        }
      ]
    }
  ],
  "m": []
},
    function($asm)
	{
        
        
        //--TRIMMABLE-BOUNDARY-START(101555)
        $asm.$cls("$sri.System.Experimentals", ($self) => class Experimentals
        {
            //--TRIMMABLE-BOUNDARY-START(12885003443)
            /*string*/ static SharedUrlFormat = null;
            //--TRIMMABLE-BOUNDARY-END(12885003443)
            
            //--TRIMMABLE-BOUNDARY-START(21474938035)
            /*string*/ static TensorTDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(21474938035)
            
            //--TRIMMABLE-BOUNDARY-START(17179970739)
            /*string*/ static SystemColorsDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(17179970739)
            
            //--TRIMMABLE-BOUNDARY-START(4295068851)
            /*string*/ static ArmSveDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(4295068851)
            
            //--TRIMMABLE-BOUNDARY-START(25769905331)
            /*string*/ static X86BaseDivRemDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(25769905331)
            
            //--TRIMMABLE-BOUNDARY-START(8590036147)
            /*string*/ static PostQuantumCryptographyDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(8590036147)
            
            //Static Initializer
            static $sinit()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(12885003443)
                    this.SharedUrlFormat = "https://aka.ms/dotnet-warnings/{0}";
                    //--TRIMMABLE-BOUNDARY-END(12885003443)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(21474938035)
                    this.TensorTDiagId = "SYSLIB5001";
                    //--TRIMMABLE-BOUNDARY-END(21474938035)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(17179970739)
                    this.SystemColorsDiagId = "SYSLIB5002";
                    //--TRIMMABLE-BOUNDARY-END(17179970739)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(4295068851)
                    this.ArmSveDiagId = "SYSLIB5003";
                    //--TRIMMABLE-BOUNDARY-END(4295068851)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(25769905331)
                    this.X86BaseDivRemDiagId = "SYSLIB5004";
                    //--TRIMMABLE-BOUNDARY-END(25769905331)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(8590036147)
                    this.PostQuantumCryptographyDiagId = "SYSLIB5006";
                    //--TRIMMABLE-BOUNDARY-END(8590036147)
                    
                }
            }
            static $h = 101555;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 131073,
  "l": [
//--TRIMMABLE-BOUNDARY-START(12885003443),
    {
      "t": 1310721,
      "n": "SharedUrlFormat",
      "d": 101555,
      "h": 12885003443,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(12885003443),
//--TRIMMABLE-BOUNDARY-START(21474938035),
    {
      "t": 1310721,
      "n": "TensorTDiagId",
      "d": 101555,
      "h": 21474938035,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(21474938035),
//--TRIMMABLE-BOUNDARY-START(17179970739),
    {
      "t": 1310721,
      "n": "SystemColorsDiagId",
      "d": 101555,
      "h": 17179970739,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(17179970739),
//--TRIMMABLE-BOUNDARY-START(4295068851),
    {
      "t": 1310721,
      "n": "ArmSveDiagId",
      "d": 101555,
      "h": 4295068851,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(4295068851),
//--TRIMMABLE-BOUNDARY-START(25769905331),
    {
      "t": 1310721,
      "n": "X86BaseDivRemDiagId",
      "d": 101555,
      "h": 25769905331,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(25769905331),
//--TRIMMABLE-BOUNDARY-START(8590036147),
    {
      "t": 1310721,
      "n": "PostQuantumCryptographyDiagId",
      "d": 101555,
      "h": 8590036147,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(8590036147)
  ],
  "h": 101555
}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `System.Experimentals`; }
        });
        //--TRIMMABLE-BOUNDARY-END(101555)
	});
})(window, window.NetJs.$boot(), ...window.NetJs.$require("NetJs.System.Private.CoreLib"))
//--TRIMMABLE-BOUNDARY-END(36019)
