
//--TRIMMABLE-BOUNDARY-START(50542)
(function ($global, $, $$) {
    "use strict";
    let _;
    
    
    
	$.$asm(
    "NetJs.System.Runtime.Intrinsics", 
    {
  "h": 50542,
  "f": "System.Runtime.Intrinsics",
  "v": "1.0.35.0",
  "a": [
    {
      "t": 159252481,
      "c": 13044154369,
      "a": [
        {
          "v": ".NETCoreApp,Version=v10.0",
          "t": 1310721
        }
      ],
      "n": [
        {
          "n": "FrameworkDisplayName",
          "v": ".NET 10.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 106430465,
      "c": 8696365057,
      "a": [
        {
          "v": "SIT",
          "t": 1310721
        }
      ]
    },
    {
      "t": 106496001,
      "c": 8696430593,
      "a": [
        {
          "v": "Debug",
          "t": 1310721
        }
      ]
    },
    {
      "t": 106954753,
      "c": 8696889345,
      "a": [
        {
          "v": "1.0.35.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107085825,
      "c": 8697020417,
      "a": [
        {
          "v": "1.0.35\u002Bdf6f45b09d58f65c84d384efc8772929a0c6464b",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107937793,
      "c": 8697872385,
      "a": [
        {
          "v": "NetJs.System.Runtime.Intrinsics",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108068865,
      "c": 8698003457,
      "a": [
        {
          "v": "NetJs.System.Runtime.Intrinsics",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108199937,
      "c": 8698134529,
      "a": [
        {
          "v": "1.0.35.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 159318017,
      "c": 4454285313,
      "a": [
        {
          "v": "browser1.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 159055873,
      "c": 4454023169,
      "a": [
        {
          "v": "browser1.0",
          "t": 1310721
        }
      ]
    }
  ],
  "m": []
},
    function($asm)
	{
        
        
        //--TRIMMABLE-BOUNDARY-START(116078)
        $asm.$cls("$sri.System.Experimentals", ($self) => class Experimentals
        {
            //--TRIMMABLE-BOUNDARY-START(12885017966)
            /*string*/ static SharedUrlFormat = null;
            //--TRIMMABLE-BOUNDARY-END(12885017966)
            
            //--TRIMMABLE-BOUNDARY-START(21474952558)
            /*string*/ static TensorTDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(21474952558)
            
            //--TRIMMABLE-BOUNDARY-START(17179985262)
            /*string*/ static SystemColorsDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(17179985262)
            
            //--TRIMMABLE-BOUNDARY-START(4295083374)
            /*string*/ static ArmSveDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(4295083374)
            
            //--TRIMMABLE-BOUNDARY-START(25769919854)
            /*string*/ static X86BaseDivRemDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(25769919854)
            
            //--TRIMMABLE-BOUNDARY-START(8590050670)
            /*string*/ static PostQuantumCryptographyDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(8590050670)
            
            //--TRIMMABLE-BOUNDARY-START(SINIT)
            //Static Initializer
            static $sinit()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(12885017966)
                    this.SharedUrlFormat = "https://aka.ms/dotnet-warnings/{0}";
                    //--TRIMMABLE-BOUNDARY-END(12885017966)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(21474952558)
                    this.TensorTDiagId = "SYSLIB5001";
                    //--TRIMMABLE-BOUNDARY-END(21474952558)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(17179985262)
                    this.SystemColorsDiagId = "SYSLIB5002";
                    //--TRIMMABLE-BOUNDARY-END(17179985262)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(4295083374)
                    this.ArmSveDiagId = "SYSLIB5003";
                    //--TRIMMABLE-BOUNDARY-END(4295083374)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(25769919854)
                    this.X86BaseDivRemDiagId = "SYSLIB5004";
                    //--TRIMMABLE-BOUNDARY-END(25769919854)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(8590050670)
                    this.PostQuantumCryptographyDiagId = "SYSLIB5006";
                    //--TRIMMABLE-BOUNDARY-END(8590050670)
                    
                }
            }
            //--TRIMMABLE-BOUNDARY-END(SINIT)
            
            static $h = 116078;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 131073,
  "l": [
//--TRIMMABLE-BOUNDARY-START(12885017966),
    {
      "t": 1310721,
      "n": "SharedUrlFormat",
      "d": 116078,
      "h": 12885017966,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(12885017966),
//--TRIMMABLE-BOUNDARY-START(21474952558),
    {
      "t": 1310721,
      "n": "TensorTDiagId",
      "d": 116078,
      "h": 21474952558,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(21474952558),
//--TRIMMABLE-BOUNDARY-START(17179985262),
    {
      "t": 1310721,
      "n": "SystemColorsDiagId",
      "d": 116078,
      "h": 17179985262,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(17179985262),
//--TRIMMABLE-BOUNDARY-START(4295083374),
    {
      "t": 1310721,
      "n": "ArmSveDiagId",
      "d": 116078,
      "h": 4295083374,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(4295083374),
//--TRIMMABLE-BOUNDARY-START(25769919854),
    {
      "t": 1310721,
      "n": "X86BaseDivRemDiagId",
      "d": 116078,
      "h": 25769919854,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(25769919854),
//--TRIMMABLE-BOUNDARY-START(8590050670),
    {
      "t": 1310721,
      "n": "PostQuantumCryptographyDiagId",
      "d": 116078,
      "h": 8590050670,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(8590050670)
  ],
  "h": 116078
}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `System.Experimentals`; }
        });
        //--TRIMMABLE-BOUNDARY-END(116078)
	});
})(window, window.NetJs.$boot(), ...window.NetJs.$require("NetJs.System.Private.CoreLib"))
//--TRIMMABLE-BOUNDARY-END(50542)
