
(function ($global, $, $spc) {
    "use strict";
    let _;
    
    
    
	$.$asm(
    "NetJs.System.Runtime.Intrinsics", 
    {"h":51591,"f":"System.Runtime.Intrinsics","v":"1.0.35.0","a":[{"t":115146753,"c":13000048641,"a":[{"v":".NETCoreApp,Version=v10.0","t":1310721}],"n":[{"n":"FrameworkDisplayName","v":".NET 10.0","t":1310721}]},{"t":73596929,"c":4368564225,"a":[{"v":"SIT","t":1310721}]},{"t":73662465,"c":4368629761,"a":[{"v":"Debug","t":1310721}]},{"t":74121217,"c":4369088513,"a":[{"v":"1.0.35.0","t":1310721}]},{"t":74252289,"c":4369219585,"a":[{"v":"1.0.35\u002Bb2f64e36cd2325469603c9f9f7251f0c62e9b41f","t":1310721}]},{"t":75104257,"c":4370071553,"a":[{"v":"NetJs.System.Runtime.Intrinsics","t":1310721}]},{"t":75235329,"c":4370202625,"a":[{"v":"NetJs.System.Runtime.Intrinsics","t":1310721}]},{"t":75366401,"c":4370333697,"a":[{"v":"1.0.35.0","t":1310721}]},{"t":115212289,"c":4410179585,"a":[{"v":"browser1.0","t":1310721}]},{"t":114950145,"c":4409917441,"a":[{"v":"browser1.0","t":1310721}]}],"m":[]},
    function($asm)
	{
        
        
        $asm.$cls("$sri.System.Experimentals", ($self) => class Experimentals
        {
            /*string*/ static SharedUrlFormat = null;
            /*string*/ static TensorTDiagId = null;
            /*string*/ static SystemColorsDiagId = null;
            /*string*/ static ArmSveDiagId = null;
            /*string*/ static X86BaseDivRemDiagId = null;
            /*string*/ static PostQuantumCryptographyDiagId = null;
            //Static Initializer
            static $sinit()
            {
                {
                    this.SharedUrlFormat = "https://aka.ms/dotnet-warnings/{0}";
                }
                {
                    this.TensorTDiagId = "SYSLIB5001";
                }
                {
                    this.SystemColorsDiagId = "SYSLIB5002";
                }
                {
                    this.ArmSveDiagId = "SYSLIB5003";
                }
                {
                    this.X86BaseDivRemDiagId = "SYSLIB5004";
                }
                {
                    this.PostQuantumCryptographyDiagId = "SYSLIB5006";
                }
            }
            static $h = 117127;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"l":[{"t":1310721,"n":"SharedUrlFormat","d":117127,"h":4295084423,"f":40},{"t":1310721,"n":"TensorTDiagId","d":117127,"h":8590051719,"f":40},{"t":1310721,"n":"SystemColorsDiagId","d":117127,"h":12885019015,"f":40},{"t":1310721,"n":"ArmSveDiagId","d":117127,"h":17179986311,"f":40},{"t":1310721,"n":"X86BaseDivRemDiagId","d":117127,"h":21474953607,"f":40},{"t":1310721,"n":"PostQuantumCryptographyDiagId","d":117127,"h":25769920903,"f":40}],"h":117127}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.Experimentals`; }
        });
	});
})(window, window.NetJs.$boot(), ...window.NetJs.$require("NetJs.System.Private.CoreLib"))