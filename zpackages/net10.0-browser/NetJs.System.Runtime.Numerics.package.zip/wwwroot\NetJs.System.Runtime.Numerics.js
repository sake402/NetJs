
(function ($global, $, $spc, $sm, $spu, $sr, $sri) {
    "use strict";
    let _;
    
    
    
	$.$asm(
    "NetJs.System.Runtime.Numerics", 
    {"h":43793,"f":"System.Runtime.Numerics","v":"1.0.35.0","a":[{"t":92405761,"c":4387373057,"a":[{"v":"System.Runtime.Numerics.Tests, PublicKey=00240000048000009400000006020000002400005253413100040000010001004b86c4cb78549b34bab61a3b1800e23bfeb5b3ec390074041536a7e3cbd97f5f04cf0f857155a8928eaa29ebfd11cfbbad3ba70efea7bda3226c6a8d370a4cd303f714486b6ebc225985a638471e6ef571cc92a4613c00b8fa65d61ccee0cbe5f36330c9a01f4183559f1bef24cc2917c6d913e3a541333a1d05d9bed22b38cb","t":1310721}]},{"t":115146753,"c":13000048641,"a":[{"v":".NETCoreApp,Version=v10.0","t":1310721}],"n":[{"n":"FrameworkDisplayName","v":".NET 10.0","t":1310721}]},{"t":73596929,"c":4368564225,"a":[{"v":"SIT","t":1310721}]},{"t":73662465,"c":4368629761,"a":[{"v":"Debug","t":1310721}]},{"t":74121217,"c":4369088513,"a":[{"v":"1.0.35.0","t":1310721}]},{"t":74252289,"c":4369219585,"a":[{"v":"1.0.35\u002Bf7a34a6f78fee11131301a9f55ca16a968616013","t":1310721}]},{"t":75104257,"c":4370071553,"a":[{"v":"NetJs.System.Runtime.Numerics","t":1310721}]},{"t":75235329,"c":4370202625,"a":[{"v":"NetJs.System.Runtime.Numerics","t":1310721}]},{"t":75366401,"c":4370333697,"a":[{"v":"1.0.35.0","t":1310721}]},{"t":115212289,"c":4410179585,"a":[{"v":"browser1.0","t":1310721}]},{"t":114950145,"c":4409917441,"a":[{"v":"browser1.0","t":1310721}]}],"m":[]},
    function($asm)
	{
        
        
        $asm.$cls("$srn.System.IBigIntegerHexOrBinaryParser<,>", (TParser, TChar) => $asm.$gt("$srn.System.IBigIntegerHexOrBinaryParser<,>", [TParser, TChar], ($self) => class IBigIntegerHexOrBinaryParser$$$
        {
            static /*int */ get System$IBigIntegerHexOrBinaryParser$$$$DigitsPerBlock()
            {
                return $.trunc((($.$spc.System.UInt32.$z * 8) | 0) / TParser.System$IBigIntegerHexOrBinaryParser$$$$BitsPerDigit);
            }
            static /*bool */ System$IBigIntegerHexOrBinaryParser$$$$TryParseUnalignedBlock(/*ReadOnlySpan<TChar>*/ input, /*out uint*/ result)
            {
                if ($.$spc.System.Type.op_Equality$1(TChar.$type, $.$spc.System.Char.$type))
                {
                    return $.$spc.System.UInt32.TryParse$4($.$spc.System.Runtime.InteropServices.MemoryMarshal.Cast$1(TChar, $.$spc.System.Char, input), TParser.System$IBigIntegerHexOrBinaryParser$$$$BlockNumberStyle, null, result);
                }
                throw new $.$spc.System.NotSupportedException().$ctor$9();
            }
            static /*bool */ System$IBigIntegerHexOrBinaryParser$$$$TryParseSingleBlock(/*ReadOnlySpan<TChar>*/ input, /*out uint*/ result)
            {
                return TParser.System$IBigIntegerHexOrBinaryParser$$$$TryParseUnalignedBlock(input, result);
            }
            static /*bool */ System$IBigIntegerHexOrBinaryParser$$$$TryParseWholeBlocks(/*ReadOnlySpan<TChar>*/ input, /*Span<uint>*/ destination)
            {
                $.$spc.System.Diagnostics.Debug.Assert$1(((destination.Length * TParser.System$IBigIntegerHexOrBinaryParser$$$$DigitsPerBlock) | 0) === input.Length, "destination.Length * TParser.DigitsPerBlock == input.Length");
                /*ref TChar*/ let lastWholeBlockStart = $.$spc.System.Runtime.CompilerServices.Unsafe.Add(TChar, $.$spc.System.Runtime.InteropServices.MemoryMarshal.GetReference$1(TChar, input), ((input.Length - TParser.System$IBigIntegerHexOrBinaryParser$$$$DigitsPerBlock) | 0));
                for(/*int*/ let i = 0; i < destination.Length; i++)
                {
                    if (!TParser.System$IBigIntegerHexOrBinaryParser$$$$TryParseSingleBlock($.$spc.System.Runtime.InteropServices.MemoryMarshal.CreateReadOnlySpan(TChar, $.$spc.System.Runtime.CompilerServices.Unsafe.Subtract(TChar, lastWholeBlockStart, ((i * TParser.System$IBigIntegerHexOrBinaryParser$$$$DigitsPerBlock) | 0)), TParser.System$IBigIntegerHexOrBinaryParser$$$$DigitsPerBlock), destination.get_Item(i)))
                    {
                        return false;
                    }
                }
                return true;
            }
            static $h = 371473;
            static $g = 2;
            static $f = 0b1100100;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {"p":[{"p":655361,"g":{"r":0,"d":0,"h":Number(BigInt(this.$h)|0x200000000n),"f":289},"n":"BitsPerDigit","o":"System$IBigIntegerHexOrBinaryParser$$$$BitsPerDigit","d":this.$h,"h":Number(BigInt(this.$h)|0x100000000n),"f":289},{"p":655361,"g":{"r":0,"d":0,"h":Number(BigInt(this.$h)|0x400000000n),"f":161},"n":"DigitsPerBlock","o":"System$IBigIntegerHexOrBinaryParser$$$$DigitsPerBlock","d":this.$h,"h":Number(BigInt(this.$h)|0x300000000n),"f":161},{"p":54067201,"g":{"r":0,"d":0,"h":Number(BigInt(this.$h)|0x600000000n),"f":289},"n":"BlockNumberStyle","o":"System$IBigIntegerHexOrBinaryParser$$$$BlockNumberStyle","d":this.$h,"h":Number(BigInt(this.$h)|0x500000000n),"f":289}],"m":[{"r":720897,"p":[{"n":"ch","p":720897}],"n":"GetSignBitsIfValid","o":"System$IBigIntegerHexOrBinaryParser$$$$GetSignBitsIfValid","d":this.$h,"h":Number(BigInt(this.$h)|0x700000000n),"f":289},{"r":262145,"p":[{"n":"input","p":$.$spc.System.ReadOnlySpan$$(TChar).$h},{"n":"result","p":720897,"f":2}],"n":"TryParseUnalignedBlock","o":"System$IBigIntegerHexOrBinaryParser$$$$TryParseUnalignedBlock","d":this.$h,"h":Number(BigInt(this.$h)|0x800000000n),"f":161},{"r":262145,"p":[{"n":"input","p":$.$spc.System.ReadOnlySpan$$(TChar).$h},{"n":"result","p":720897,"f":2}],"n":"TryParseSingleBlock","o":"System$IBigIntegerHexOrBinaryParser$$$$TryParseSingleBlock","d":this.$h,"h":Number(BigInt(this.$h)|0x900000000n),"f":161},{"r":262145,"p":[{"n":"input","p":$.$spc.System.ReadOnlySpan$$(TChar).$h},{"n":"destination","p":$.$spc.System.Span$$($.$spc.System.UInt32).$h}],"n":"TryParseWholeBlocks","o":"System$IBigIntegerHexOrBinaryParser$$$$TryParseWholeBlocks","d":this.$h,"h":Number(BigInt(this.$h)|0xA00000000n),"f":161}],"g":[TParser?.$h??1507328,TChar?.$h??1572864],"s":[{"n":"TParser","f":2,"c":[this.$h]},{"n":"TChar","f":10,"c":[$.$spc.System.Numerics.IBinaryInteger$$(TChar).$h]}],"r":2,"h":this.$h}; }
            static get $fullName() { return `System.IBigIntegerHexOrBinaryParser<${TParser?.$fullName},${TChar?.$fullName}>`; }
        }));
        
        $asm.$cls("$srn.System.IUtfChar<>", (TSelf) => $asm.$gt("$srn.System.IUtfChar<>", [TSelf], ($self) => class IUtfChar$$
        {
            static $h = 437009;
            static $g = 1;
            static $f = 0b1100100;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {"m":[{"r":TSelf?.$h??1507328,"p":[{"n":"value","p":393217}],"n":"CastFrom","o":"System$IUtfChar$$$CastFrom","d":this.$h,"h":Number(BigInt(this.$h)|0x100000000n),"f":289},{"r":TSelf?.$h??1507328,"p":[{"n":"value","p":458753}],"n":"CastFrom","o":"System$IUtfChar$$$CastFrom$1","d":this.$h,"h":Number(BigInt(this.$h)|0x200000000n),"f":289},{"r":TSelf?.$h??1507328,"p":[{"n":"value","p":655361}],"n":"CastFrom","o":"System$IUtfChar$$$CastFrom$2","d":this.$h,"h":Number(BigInt(this.$h)|0x300000000n),"f":289},{"r":TSelf?.$h??1507328,"p":[{"n":"value","p":720897}],"n":"CastFrom","o":"System$IUtfChar$$$CastFrom$3","d":this.$h,"h":Number(BigInt(this.$h)|0x400000000n),"f":289},{"r":TSelf?.$h??1507328,"p":[{"n":"value","p":983041}],"n":"CastFrom","o":"System$IUtfChar$$$CastFrom$4","d":this.$h,"h":Number(BigInt(this.$h)|0x500000000n),"f":289},{"r":720897,"p":[{"n":"value","p":TSelf?.$h??1507328}],"n":"CastToUInt32","o":"System$IUtfChar$$$CastToUInt32","d":this.$h,"h":Number(BigInt(this.$h)|0x600000000n),"f":289}],"i":[$.$spc.System.IEquatable$$(TSelf).$h],"g":[TSelf?.$h??1507328],"s":[{"n":"TSelf","f":10,"c":[this.$h]}],"r":1,"h":this.$h}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IEquatable$$(TSelf) ]; }
            static get $fullName() { return `System.IUtfChar<${TSelf?.$fullName}>`; }
        }));
        
        $asm.$cls("$srn.System.Numerics.NumericsHelpers", ($self) => class NumericsHelpers
        {
            /*int*/ static kcbitUint = 32;
            static /*void */ GetDoubleParts(/*double*/ dbl, /*out int*/ sign, /*out int*/ exp, /*out ulong*/ man, /*out bool*/ fFinite)
            {
                /*ulong*/ let bits = $.$spc.System.BitConverter.DoubleToUInt64Bits(dbl);
                sign.$v = ((1 - ($.$cast((bits >> 62n), $.$spc.System.Int32) & 2)) | 0);
                man.$v = bits & 4503599627370495n;
                exp.$v = $.$cast((bits >> 52n), $.$spc.System.Int32) & 2047;
                if (exp.$v === 0)
                {
                    fFinite.$v = true;
                    if (man.$v !== 0n)
                    {
                        exp.$v = -1074;
                    }
                }
                else if (exp.$v === 2047)
                {
                    fFinite.$v = false;
                    exp.$v = 2147483647/*int.MaxValue*/;
                }
                else 
                {
                    fFinite.$v = true;
                    man.$v |= 4503599627370496n;
                    exp.$v -= 1075;
                }
            }
            static /*double */ GetDoubleFromParts(/*int*/ sign, /*int*/ exp, /*ulong*/ man)
            {
                /*ulong*/ let bits;
                if (man === 0n)
                {
                    bits = 0n;
                }
                else 
                {
                    /*int*/ let cbitShift = (($.$spc.System.Numerics.BitOperations.LeadingZeroCount$1(man) - 11) | 0);
                    if (cbitShift < 0)
                    {
                        man >>= -cbitShift;
                    }
                    else 
                    {
                        man <<= cbitShift;
                    }
                    exp -= cbitShift;
                    $.$spc.System.Diagnostics.Debug.Assert$1((man & 18442240474082181120n) === 4503599627370496n, "(man & 0xFFF0000000000000) == 0x0010000000000000");
                    exp += 1075;
                    if (exp >= 2047)
                    {
                        bits = 9218868437227405312n;
                    }
                    else if (exp <= 0)
                    {
                        exp--;
                        if (exp < -52)
                        {
                            bits = 0n;
                        }
                        else 
                        {
                            bits = man >> BigInt(-exp);
                            $.$spc.System.Diagnostics.Debug.Assert$1(bits !== 0n, "bits != 0");
                        }
                    }
                    else 
                    {
                        bits = (man & 4503599627370495n) | (BigInt.asUintN(64, $.$cast(exp, $.$spc.System.UInt64) << 52n));
                    }
                }
                if (sign < 0)
                {
                    bits |= 9223372036854775808n;
                }
                return $.$spc.System.BitConverter.UInt64BitsToDouble(bits);
            }
            static /*void */ DangerousMakeTwosComplement(/*Span<uint>*/ d)
            {
                d = $.$spc.System.MemoryExtensions.TrimStart$2($.$spc.System.UInt32, d, 0);
                if (d.Length > 0)
                {
                    d.get_Item(0).$v = ((-(d.get_Item(0).$v | 0)) >>> 0);
                    d = d.Slice(1);
                }
                if (d.IsEmpty)
                {
                    return;
                }
                /*int*/ let offset = 0;
                /*ref uint*/ let start = $.$spc.System.Runtime.InteropServices.MemoryMarshal.GetReference($.$spc.System.UInt32, d);
                //Vector512.IsHardwareAccelerated && d.Length - offset >= Vector512<uint>.Count { ... }
                //Vector256.IsHardwareAccelerated && d.Length - offset >= Vector256<uint>.Count { ... }
                //Vector128.IsHardwareAccelerated && d.Length - offset >= Vector128<uint>.Count { ... }
                for(; offset < d.Length; offset++)
                {
                    d.get_Item(offset).$v = ~d.get_Item(offset).$v;
                }
            }
            static /*ulong */ MakeUInt64(/*uint*/ uHi, /*uint*/ uLo)
            {
                return (BigInt.asUintN(64, $.$cast(uHi, $.$spc.System.UInt64) << BigInt(32/*kcbitUint*/))) | BigInt(uLo);
            }
            static /*uint */ Abs(/*int*/ a)
            {
                //unchecked
                {
                    /*uint*/ let mask = ((a >> 31) >>> 0);
                    return ((((a >>> 0) ^ mask) - mask) >>> 0);
                }
            }
            static $h = 1157905;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"m":[{"r":65537,"p":[{"n":"dbl","p":1179649},{"n":"sign","p":655361,"f":2},{"n":"exp","p":655361,"f":2},{"n":"man","p":983041,"f":2},{"n":"fFinite","p":262145,"f":2}],"n":"GetDoubleParts","d":1157905,"h":8591092497,"f":33},{"r":1179649,"p":[{"n":"sign","p":655361},{"n":"exp","p":655361},{"n":"man","p":983041}],"n":"GetDoubleFromParts","d":1157905,"h":12886059793,"f":33},{"r":65537,"p":[{"n":"d","p":$.$spc.System.Span$$($.$spc.System.UInt32).$h}],"n":"DangerousMakeTwosComplement","d":1157905,"h":17181027089,"f":33},{"r":983041,"p":[{"n":"uHi","p":720897},{"n":"uLo","p":720897}],"n":"MakeUInt64","d":1157905,"h":21475994385,"f":33},{"r":720897,"p":[{"n":"a","p":655361}],"n":"Abs","d":1157905,"h":25770961681,"f":33}],"l":[{"t":655361,"n":"kcbitUint","d":1157905,"h":4296125201,"f":34}],"h":1157905}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.Numerics.NumericsHelpers`; }
        });
        
        $asm.$cls("$srn.System.ThrowHelper", ($self) => class ThrowHelper
        {
            static /*void */ ThrowOverflowException()
            {
                throw new $.$spc.System.OverflowException().$ctor$13();
            }
            static /*void */ ThrowNotSupportedException()
            {
                throw new $.$spc.System.NotSupportedException().$ctor$9();
            }
            static /*void */ ThrowValueArgumentOutOfRange_NeedNonNegNumException()
            {
                throw new $.$spc.System.ArgumentOutOfRangeException().$ctor$17("value", $.$srn.System.SR.ArgumentOutOfRange_NeedNonNegNum);
            }
            static /*void */ ThrowFormatException_BadFormatSpecifier()
            {
                throw new $.$spc.System.FormatException().$ctor$10($.$srn.System.SR.Argument_BadFormatSpecifier);
            }
            static $h = 1354513;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"m":[{"r":65537,"n":"ThrowOverflowException","d":1354513,"h":4296321809,"f":40},{"r":65537,"n":"ThrowNotSupportedException","d":1354513,"h":8591289105,"f":40},{"r":65537,"n":"ThrowValueArgumentOutOfRange_NeedNonNegNumException","d":1354513,"h":12886256401,"f":40},{"r":65537,"n":"ThrowFormatException_BadFormatSpecifier","d":1354513,"h":17181223697,"f":40}],"h":1354513,"a":[{"t":38600705,"c":4333568001}]}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.ThrowHelper`; }
        });
        
        $asm.$cls("$srn.System.SR", ($self) => class SR
        {
            /*global::System.Resources.ResourceManager*/ static s_resourceManager = null;
            /*global::System.Globalization.CultureInfo*/ static resourceCulture = null;
            static /*global::System.Resources.ResourceManager */ get ResourceManager()
            {
                if ($.$spc.System.Object.ReferenceEquals($.$srn.System.SR.s_resourceManager, null))
                {
                    /*global::System.Resources.ResourceManager*/ let temp = new $.$spc.System.Resources.ResourceManager().$ctor$3("System.Runtime.Numerics", $.$srn.System.SR.$type.Assembly);
                    $.$srn.System.SR.s_resourceManager = temp;
                }
                return $.$srn.System.SR.s_resourceManager;
            }
            static /*global::System.Globalization.CultureInfo */ get Culture()
            {
                return $.$srn.System.SR.resourceCulture;
            }
            static /*global::System.Globalization.CultureInfo */ set Culture(value)
            {
                $.$srn.System.SR.resourceCulture = value;
            }
            static /*string */ get Arg_HexStyleNotSupported()
            {
                return "The number style AllowHexSpecifier is not supported on floating point data types.";
            }
            static /*string */ get Argument_BadFormatSpecifier()
            {
                return "Format specifier was invalid.";
            }
            static /*string */ get Argument_InvalidNumberStyles()
            {
                return "An undefined NumberStyles value is being used.";
            }
            static /*string */ get Argument_InvalidHexStyle()
            {
                return "With the AllowHexSpecifier bit set in the enum bit field, the only other valid bits that can be combined into the enum value must be a subset of those in HexNumber.";
            }
            static /*string */ get Argument_MinMaxValue()
            {
                return "'{0}' cannot be greater than {1}.";
            }
            static /*string */ FormatArgument_MinMaxValue(/*object*/ arg1, /*object*/ arg2)
            {
                return $.$spc.System.String.Format$1("'{0}' cannot be greater than {1}.", arg1, arg2);
            }
            static /*string */ get Argument_MustBeBigInt()
            {
                return "The parameter must be a BigInteger.";
            }
            static /*string */ get ArgumentOutOfRange_NeedNonNegNum()
            {
                return "Non-negative number required.";
            }
            static /*string */ get Format_TooLarge()
            {
                return "The value is too large to be represented by this format specifier.";
            }
            static /*string */ get Overflow_BigIntInfinity()
            {
                return "BigInteger cannot represent infinity.";
            }
            static /*string */ get Overflow_NotANumber()
            {
                return "The value is not a number.";
            }
            static /*string */ get Overflow_ParseBigInteger()
            {
                return "The value could not be parsed.";
            }
            static /*string */ get Overflow_Int32()
            {
                return "Value was either too large or too small for an Int32.";
            }
            static /*string */ get Overflow_Int64()
            {
                return "Value was either too large or too small for an Int64.";
            }
            static /*string */ get Overflow_Int128()
            {
                return "Value was either too large or too small for an Int128.";
            }
            static /*string */ get Overflow_UInt32()
            {
                return "Value was either too large or too small for a UInt32.";
            }
            static /*string */ get Overflow_UInt64()
            {
                return "Value was either too large or too small for a UInt64.";
            }
            static /*string */ get Overflow_UInt128()
            {
                return "Value was either too large or too small for a UInt128.";
            }
            static /*string */ get Overflow_Decimal()
            {
                return "Value was either too large or too small for a Decimal.";
            }
            static /*string */ get Overflow_Negative_Unsigned()
            {
                return "Negative values do not have an unsigned representation.";
            }
            /*bool*/ static s_usingResourceKeys = false;
            static /*bool */ GetUsingResourceKeysSwitchValue()
            {
                /*bool*/ let usingResourceKeys;
                return $.$spc.System.AppContext.TryGetSwitch("System.Resources.UseSystemResourceKeys", $.$ref(() => usingResourceKeys, ($v) => usingResourceKeys = $v, $.$spc.System.Boolean)) ? usingResourceKeys : false;
            }
            static /*bool */ UsingResourceKeys()
            {
                return $.$srn.System.SR.s_usingResourceKeys;
            }
            static /*string */ GetResourceString(/*string*/ resourceKey)
            {
                if ($.$srn.System.SR.UsingResourceKeys())
                {
                    return resourceKey;
                }
                /*string?*/ let resourceString = null;
                try
                {
                    resourceString = $.$srn.System.SR.ResourceManager.GetString(resourceKey);
                }
                catch($e)
                {
                }
                return resourceString;
            }
            static /*string */ GetResourceString$1(/*string*/ resourceKey, /*string*/ defaultString)
            {
                /*string*/ let resourceString = $.$srn.System.SR.GetResourceString(resourceKey);
                return $.$spc.System.String.op_Equality(resourceKey, resourceString) || $.$spc.System.String.op_Equality(resourceString, null) ? defaultString : resourceString;
            }
            static /*string */ Format(/*string*/ resourceFormat, /*object?*/ p1)
            {
                if ($.$srn.System.SR.UsingResourceKeys())
                {
                    return $.$spc.System.String.Join$10(", ", $.$spc.System.ReadOnlySpan$$($.$spc.System.Object).op_Implicit([ resourceFormat, p1 ]));
                }
                return $.$spc.System.String.Format(resourceFormat, p1);
            }
            static /*string */ Format$1(/*string*/ resourceFormat, /*object?*/ p1, /*object?*/ p2)
            {
                if ($.$srn.System.SR.UsingResourceKeys())
                {
                    return $.$spc.System.String.Join$10(", ", $.$spc.System.ReadOnlySpan$$($.$spc.System.Object).op_Implicit([ resourceFormat, p1, p2 ]));
                }
                return $.$spc.System.String.Format$1(resourceFormat, p1, p2);
            }
            static /*string */ Format$2(/*string*/ resourceFormat, /*object?*/ p1, /*object?*/ p2, /*object?*/ p3)
            {
                if ($.$srn.System.SR.UsingResourceKeys())
                {
                    return $.$spc.System.String.Join$10(", ", $.$spc.System.ReadOnlySpan$$($.$spc.System.Object).op_Implicit([ resourceFormat, p1, p2, p3 ]));
                }
                return $.$spc.System.String.Format$2(resourceFormat, p1, p2, p3);
            }
            static /*string */ Format$3(/*string*/ resourceFormat, /*params object?[]?*/ args)
            {
                if (args !== null)
                {
                    if ($.$srn.System.SR.UsingResourceKeys())
                    {
                        return resourceFormat + ", " + $.$spc.System.String.Join$9(", ", args);
                    }
                    return $.$spc.System.String.Format$3(resourceFormat, args);
                }
                return resourceFormat;
            }
            static /*string */ Format$4(/*IFormatProvider?*/ provider, /*string*/ resourceFormat, /*object?*/ p1)
            {
                if ($.$srn.System.SR.UsingResourceKeys())
                {
                    return $.$spc.System.String.Join$10(", ", $.$spc.System.ReadOnlySpan$$($.$spc.System.Object).op_Implicit([ resourceFormat, p1 ]));
                }
                return $.$spc.System.String.Format$5(provider, resourceFormat, p1);
            }
            static /*string */ Format$5(/*IFormatProvider?*/ provider, /*string*/ resourceFormat, /*object?*/ p1, /*object?*/ p2)
            {
                if ($.$srn.System.SR.UsingResourceKeys())
                {
                    return $.$spc.System.String.Join$10(", ", $.$spc.System.ReadOnlySpan$$($.$spc.System.Object).op_Implicit([ resourceFormat, p1, p2 ]));
                }
                return $.$spc.System.String.Format$6(provider, resourceFormat, p1, p2);
            }
            static /*string */ Format$6(/*IFormatProvider?*/ provider, /*string*/ resourceFormat, /*object?*/ p1, /*object?*/ p2, /*object?*/ p3)
            {
                if ($.$srn.System.SR.UsingResourceKeys())
                {
                    return $.$spc.System.String.Join$10(", ", $.$spc.System.ReadOnlySpan$$($.$spc.System.Object).op_Implicit([ resourceFormat, p1, p2, p3 ]));
                }
                return $.$spc.System.String.Format$7(provider, resourceFormat, p1, p2, p3);
            }
            static /*string */ Format$7(/*IFormatProvider?*/ provider, /*string*/ resourceFormat, /*params object?[]?*/ args)
            {
                if (args !== null)
                {
                    if ($.$srn.System.SR.UsingResourceKeys())
                    {
                        return resourceFormat + ", " + $.$spc.System.String.Join$9(", ", args);
                    }
                    return $.$spc.System.String.Format$8(provider, resourceFormat, args);
                }
                return resourceFormat;
            }
            //Static Initializer
            static $sinit()
            {
                {
                    this.s_usingResourceKeys = $.$srn.System.SR.GetUsingResourceKeysSwitchValue();
                }
            }
            static $h = 1223441;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"h":1223441}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.SR`; }
        });
        
        $asm.$cls("$srn.System.Numerics.BigIntegerCalculator", ($self) => class BigIntegerCalculator
        {
            /*int*/ static CopyToThreshold = 8;
            static /*void */ CopyTail(/*ReadOnlySpan<uint>*/ source, /*Span<uint>*/ dest, /*int*/ start)
            {
                source.Slice(start).CopyTo(dest.Slice(start));
            }
            static /*void */ Add(/*ReadOnlySpan<uint>*/ left, /*uint*/ right, /*Span<uint>*/ bits)
            {
                $.$spc.System.Diagnostics.Debug.Assert$1(left.Length >= 1, "left.Length >= 1");
                $.$spc.System.Diagnostics.Debug.Assert$1(bits.Length === ((left.Length + 1) | 0), "bits.Length == left.Length + 1");
                $.$srn.System.Numerics.BigIntegerCalculator.Add$2(left, bits, $.$spc.System.Runtime.InteropServices.MemoryMarshal.GetReference($.$spc.System.UInt32, bits), 0, BigInt(right));
            }
            static /*void */ Add$1(/*ReadOnlySpan<uint>*/ left, /*ReadOnlySpan<uint>*/ right, /*Span<uint>*/ bits)
            {
                $.$spc.System.Diagnostics.Debug.Assert$1(right.Length >= 1, "right.Length >= 1");
                $.$spc.System.Diagnostics.Debug.Assert$1(left.Length >= right.Length, "left.Length >= right.Length");
                $.$spc.System.Diagnostics.Debug.Assert$1(bits.Length === ((left.Length + 1) | 0), "bits.Length == left.Length + 1");
                /*ref uint*/ let resultPtr = $.$spc.System.Runtime.InteropServices.MemoryMarshal.GetReference($.$spc.System.UInt32, bits);
                /*ref uint*/ let rightPtr = $.$spc.System.Runtime.InteropServices.MemoryMarshal.GetReference$1($.$spc.System.UInt32, right);
                /*ref uint*/ let leftPtr = $.$spc.System.Runtime.InteropServices.MemoryMarshal.GetReference$1($.$spc.System.UInt32, left);
                /*int*/ let i = 0;
                /*long*/ let carry = 0n;
                do
                {
                    carry += BigInt($.$spc.System.Runtime.CompilerServices.Unsafe.Add($.$spc.System.UInt32, leftPtr, i).$v);
                    carry += BigInt($.$spc.System.Runtime.CompilerServices.Unsafe.Add($.$spc.System.UInt32, rightPtr, i).$v);
                    resultPtr.SetAt($.$cast(carry, $.$spc.System.UInt32), i);
                    carry >>= 32n;
                    i++;
                }
                while(i < right.Length);
                $.$srn.System.Numerics.BigIntegerCalculator.Add$2(left, bits, resultPtr, i, carry);
            }
            static /*void */ AddSelf(/*Span<uint>*/ left, /*ReadOnlySpan<uint>*/ right)
            {
                $.$spc.System.Diagnostics.Debug.Assert$1(left.Length >= right.Length, "left.Length >= right.Length");
                /*int*/ let i = 0;
                /*long*/ let carry = 0n;
                /*ref uint*/ let leftPtr = $.$spc.System.Runtime.InteropServices.MemoryMarshal.GetReference($.$spc.System.UInt32, left);
                for(; i < right.Length; i++)
                {
                    /*long*/ let digit = (BigInt($.$spc.System.Runtime.CompilerServices.Unsafe.Add($.$spc.System.UInt32, leftPtr, i).$v) + carry) + BigInt(right.get_Item(i).$v);
                    leftPtr.SetAt($.$cast(digit, $.$spc.System.UInt32), i);
                    carry = digit >> 32n;
                }
                for(; carry !== 0n && i < left.Length; i++)
                {
                    /*long*/ let digit = BigInt(left.get_Item(i).$v) + carry;
                    left.get_Item(i).$v = $.$cast(digit, $.$spc.System.UInt32);
                    carry = digit >> 32n;
                }
                $.$spc.System.Diagnostics.Debug.Assert$1(carry === 0n, "carry == 0");
            }
            static /*void */ Subtract(/*ReadOnlySpan<uint>*/ left, /*uint*/ right, /*Span<uint>*/ bits)
            {
                $.$spc.System.Diagnostics.Debug.Assert$1(left.Length >= 1, "left.Length >= 1");
                $.$spc.System.Diagnostics.Debug.Assert$1(left.get_Item(0).$v >= right || left.Length >= 2, "left[0] >= right || left.Length >= 2");
                $.$spc.System.Diagnostics.Debug.Assert$1(bits.Length === left.Length, "bits.Length == left.Length");
                $.$srn.System.Numerics.BigIntegerCalculator.Subtract$2(left, bits, $.$spc.System.Runtime.InteropServices.MemoryMarshal.GetReference($.$spc.System.UInt32, bits), 0, -BigInt(right));
            }
            static /*void */ Subtract$1(/*ReadOnlySpan<uint>*/ left, /*ReadOnlySpan<uint>*/ right, /*Span<uint>*/ bits)
            {
                $.$spc.System.Diagnostics.Debug.Assert$1(right.Length >= 1, "right.Length >= 1");
                $.$spc.System.Diagnostics.Debug.Assert$1(left.Length >= right.Length, "left.Length >= right.Length");
                $.$spc.System.Diagnostics.Debug.Assert$1($.$srn.System.Numerics.BigIntegerCalculator.CompareActual(left, right) >= 0, "CompareActual(left, right) >= 0");
                $.$spc.System.Diagnostics.Debug.Assert$1(bits.Length === left.Length, "bits.Length == left.Length");
                /*ref uint*/ let resultPtr = $.$spc.System.Runtime.InteropServices.MemoryMarshal.GetReference($.$spc.System.UInt32, bits);
                /*ref uint*/ let rightPtr = $.$spc.System.Runtime.InteropServices.MemoryMarshal.GetReference$1($.$spc.System.UInt32, right);
                /*ref uint*/ let leftPtr = $.$spc.System.Runtime.InteropServices.MemoryMarshal.GetReference$1($.$spc.System.UInt32, left);
                /*int*/ let i = 0;
                /*long*/ let carry = 0n;
                do
                {
                    carry += BigInt($.$spc.System.Runtime.CompilerServices.Unsafe.Add($.$spc.System.UInt32, leftPtr, i).$v);
                    carry -= BigInt($.$spc.System.Runtime.CompilerServices.Unsafe.Add($.$spc.System.UInt32, rightPtr, i).$v);
                    resultPtr.SetAt($.$cast(carry, $.$spc.System.UInt32), i);
                    carry >>= 32n;
                    i++;
                }
                while(i < right.Length);
                $.$srn.System.Numerics.BigIntegerCalculator.Subtract$2(left, bits, resultPtr, i, carry);
            }
            static /*void */ SubtractSelf(/*Span<uint>*/ left, /*ReadOnlySpan<uint>*/ right)
            {
                $.$spc.System.Diagnostics.Debug.Assert$1(left.Length >= right.Length, "left.Length >= right.Length");
                /*int*/ let i = 0;
                /*long*/ let carry = 0n;
                /*ref uint*/ let leftPtr = $.$spc.System.Runtime.InteropServices.MemoryMarshal.GetReference($.$spc.System.UInt32, left);
                for(; i < right.Length; i++)
                {
                    /*long*/ let digit = (BigInt($.$spc.System.Runtime.CompilerServices.Unsafe.Add($.$spc.System.UInt32, leftPtr, i).$v) + carry) - BigInt(right.get_Item(i).$v);
                    leftPtr.SetAt($.$cast(digit, $.$spc.System.UInt32), i);
                    carry = digit >> 32n;
                }
                for(; carry !== 0n && i < left.Length; i++)
                {
                    /*long*/ let digit = BigInt(left.get_Item(i).$v) + carry;
                    left.get_Item(i).$v = $.$cast(digit, $.$spc.System.UInt32);
                    carry = digit >> 32n;
                }
            }
            static /*void */ Add$2(/*ReadOnlySpan<uint>*/ left, /*Span<uint>*/ bits, /*ref uint*/ resultPtr, /*int*/ startIndex, /*long*/ initialCarry)
            {
                /*int*/ let i = startIndex;
                /*long*/ let carry = initialCarry;
                if (left.Length <= 8/*CopyToThreshold*/)
                {
                    for(; i < left.Length; i++)
                    {
                        carry += BigInt(left.get_Item(i).$v);
                        resultPtr.SetAt($.$cast(carry, $.$spc.System.UInt32), i);
                        carry >>= 32n;
                    }
                    resultPtr.SetAt($.$cast(carry, $.$spc.System.UInt32), left.Length);
                }
                else 
                {
                    for(; i < left.Length; )
                    {
                        carry += BigInt(left.get_Item(i).$v);
                        resultPtr.SetAt($.$cast(carry, $.$spc.System.UInt32), i);
                        i++;
                        carry >>= 32n;
                        if (carry === 0n)
                        {
                            break;
                        }
                    }
                    resultPtr.SetAt($.$cast(carry, $.$spc.System.UInt32), left.Length);
                    if (i < left.Length)
                    {
                        $.$srn.System.Numerics.BigIntegerCalculator.CopyTail(left, bits, i);
                    }
                }
            }
            static /*void */ Subtract$2(/*ReadOnlySpan<uint>*/ left, /*Span<uint>*/ bits, /*ref uint*/ resultPtr, /*int*/ startIndex, /*long*/ initialCarry)
            {
                /*int*/ let i = startIndex;
                /*long*/ let carry = initialCarry;
                if (left.Length <= 8/*CopyToThreshold*/)
                {
                    for(; i < left.Length; i++)
                    {
                        carry += BigInt(left.get_Item(i).$v);
                        resultPtr.SetAt($.$cast(carry, $.$spc.System.UInt32), i);
                        carry >>= 32n;
                    }
                }
                else 
                {
                    for(; i < left.Length; )
                    {
                        carry += BigInt(left.get_Item(i).$v);
                        resultPtr.SetAt($.$cast(carry, $.$spc.System.UInt32), i);
                        i++;
                        carry >>= 32n;
                        if (carry === 0n)
                        {
                            break;
                        }
                    }
                    if (i < left.Length)
                    {
                        $.$srn.System.Numerics.BigIntegerCalculator.CopyTail(left, bits, i);
                    }
                }
            }
            static $_FastReducer;
            static get FastReducer()
            {
                let $cls = $.$srn.System.Numerics.BigIntegerCalculator;
                return $cls.$_FastReducer ??= $asm.$nstr("$srn.System.Numerics.BigIntegerCalculator.FastReducer", ($self) => class FastReducer extends $.$spc.System.ValueType
                {
                    /*ReadOnlySpan<uint>*/  get _modulus() { return this.$getField(0, 8); }
                    /*ReadOnlySpan<uint>*/  set _modulus(value) { this.$setField(0, 8, value); }
                    /*ReadOnlySpan<uint>*/  get _mu() { return this.$getField(8, 8); }
                    /*ReadOnlySpan<uint>*/  set _mu(value) { this.$setField(8, 8, value); }
                    /*Span<uint>*/  get _q1() { return this.$getField(16, 8); }
                    /*Span<uint>*/  set _q1(value) { this.$setField(16, 8, value); }
                    /*Span<uint>*/  get _q2() { return this.$getField(24, 8); }
                    /*Span<uint>*/  set _q2(value) { this.$setField(24, 8, value); }
                    $ctor$2(/*ReadOnlySpan<uint>*/ modulus, /*Span<uint>*/ r, /*Span<uint>*/ mu, /*Span<uint>*/ q1, /*Span<uint>*/ q2)
                    {
                        super.$ctor$1();
                        {
                            $.$spc.System.Diagnostics.Debug.Assert$1(!modulus.IsEmpty, "!modulus.IsEmpty");
                            $.$spc.System.Diagnostics.Debug.Assert$1(r.Length === ((((modulus.Length * 2) | 0) + 1) | 0), "r.Length == modulus.Length * 2 + 1");
                            $.$spc.System.Diagnostics.Debug.Assert$1(mu.Length === ((((r.Length - modulus.Length) | 0) + 1) | 0), "mu.Length == r.Length - modulus.Length + 1");
                            $.$spc.System.Diagnostics.Debug.Assert$1(q1.Length === ((((modulus.Length * 2) | 0) + 2) | 0), "q1.Length == modulus.Length * 2 + 2");
                            $.$spc.System.Diagnostics.Debug.Assert$1(q2.Length === ((((modulus.Length * 2) | 0) + 2) | 0), "q2.Length == modulus.Length * 2 + 2");
                            r.get_Item(((r.Length - 1) | 0)).$v = 1;
                            $.$srn.System.Numerics.BigIntegerCalculator.DivRem(r, modulus, mu);
                            this._modulus = modulus;
                            this._q1 = q1;
                            this._q2 = q2;
                            this._mu = $.$spc.System.Span$$($.$spc.System.UInt32).op_Implicit$2(mu.Slice$1(0, $.$srn.System.Numerics.BigIntegerCalculator.ActualLength($.$spc.System.Span$$($.$spc.System.UInt32).op_Implicit$2(mu))));
                        }
                        return this;
                    }
                    /*int */ Reduce(/*Span<uint>*/ value)
                    {
                        $.$spc.System.Diagnostics.Debug.Assert$1(value.Length <= ((this._modulus.Length * 2) | 0), "value.Length <= _modulus.Length * 2");
                        if (value.Length < this._modulus.Length)
                        {
                            return value.Length;
                        }
                        this._q1.Clear();
                        /*int*/ let l1 = $.$srn.System.Numerics.BigIntegerCalculator.FastReducer.DivMul($.$spc.System.Span$$($.$spc.System.UInt32).op_Implicit$2(value), this._mu, this._q1, ((this._modulus.Length - 1) | 0));
                        this._q2.Clear();
                        /*int*/ let l2 = $.$srn.System.Numerics.BigIntegerCalculator.FastReducer.DivMul($.$spc.System.Span$$($.$spc.System.UInt32).op_Implicit$2(this._q1.Slice$1(0, l1)), this._modulus, this._q2, ((this._modulus.Length + 1) | 0));
                        /*var*/ let length = $.$srn.System.Numerics.BigIntegerCalculator.FastReducer.SubMod(value, $.$spc.System.Span$$($.$spc.System.UInt32).op_Implicit$2(this._q2.Slice$1(0, l2)), this._modulus, ((this._modulus.Length + 1) | 0));
                        value = value.Slice(length);
                        value.Clear();
                        return length;
                    }
                    static /*int */ DivMul(/*ReadOnlySpan<uint>*/ left, /*ReadOnlySpan<uint>*/ right, /*Span<uint>*/ bits, /*int*/ k)
                    {
                        $.$spc.System.Diagnostics.Debug.Assert$1(!right.IsEmpty, "!right.IsEmpty");
                        $.$spc.System.Diagnostics.Debug.Assert$1(!bits.IsEmpty, "!bits.IsEmpty");
                        $.$spc.System.Diagnostics.Debug.Assert$1(((bits.Length + k) | 0) >= ((left.Length + right.Length) | 0), "bits.Length + k >= left.Length + right.Length");
                        if (left.Length > k)
                        {
                            left = left.Slice(k);
                            if (left.Length < right.Length)
                            {
                                $.$srn.System.Numerics.BigIntegerCalculator.Multiply$1(right, left, bits.Slice$1(0, ((left.Length + right.Length) | 0)));
                            }
                            else 
                            {
                                $.$srn.System.Numerics.BigIntegerCalculator.Multiply$1(left, right, bits.Slice$1(0, ((left.Length + right.Length) | 0)));
                            }
                            return $.$srn.System.Numerics.BigIntegerCalculator.ActualLength($.$spc.System.Span$$($.$spc.System.UInt32).op_Implicit$2(bits.Slice$1(0, ((left.Length + right.Length) | 0))));
                        }
                        return 0;
                    }
                    static /*int */ SubMod(/*Span<uint>*/ left, /*ReadOnlySpan<uint>*/ right, /*ReadOnlySpan<uint>*/ modulus, /*int*/ k)
                    {
                        if (left.Length > k)
                        {
                            left = left.Slice$1(0, k);
                        }
                        if (right.Length > k)
                        {
                            right = right.Slice$1(0, k);
                        }
                        $.$srn.System.Numerics.BigIntegerCalculator.SubtractSelf(left, right);
                        left = left.Slice$1(0, $.$srn.System.Numerics.BigIntegerCalculator.ActualLength($.$spc.System.Span$$($.$spc.System.UInt32).op_Implicit$2(left)));
                        while($.$srn.System.Numerics.BigIntegerCalculator.Compare($.$spc.System.Span$$($.$spc.System.UInt32).op_Implicit$2(left), modulus) >= 0)
                        {
                            $.$srn.System.Numerics.BigIntegerCalculator.SubtractSelf(left, modulus);
                            left = left.Slice$1(0, $.$srn.System.Numerics.BigIntegerCalculator.ActualLength($.$spc.System.Span$$($.$spc.System.UInt32).op_Implicit$2(left)));
                        }
                        return left.Length;
                    }
                    //default value type constructor
                    $ctor$3()
                    {
                        return this;
                    }
                    Clone($copy)
                    {
                        let copy = $copy ?? new this.constructor();
                        copy._modulus = this._modulus.Clone();
                        copy._mu = this._mu.Clone();
                        copy._q1 = this._q1.Clone();
                        copy._q2 = this._q2.Clone();
                        return copy;
                    }
                    //default member initializer
                    constructor()
                    {
                        super();
                        this._modulus = $.$default($.$spc.System.ReadOnlySpan$$($.$spc.System.UInt32));
                        this._mu = $.$default($.$spc.System.ReadOnlySpan$$($.$spc.System.UInt32));
                        this._q1 = $.$default($.$spc.System.Span$$($.$spc.System.UInt32));
                        this._q2 = $.$default($.$spc.System.Span$$($.$spc.System.UInt32));
                    }
                    static $h = 1026833;
                    static $z = 32;
                    static $f = 0b10000001010000000;
                    static $k = 2;
                    static $$md;
                    static get $md() { return this.$$md ??= {"b":196609,"m":[{"r":655361,"p":[{"n":"value","p":$.$spc.System.Span$$($.$spc.System.UInt32).$h}],"n":"Reduce","d":1026833,"h":25770830609,"f":1},{"r":655361,"p":[{"n":"left","p":$.$spc.System.ReadOnlySpan$$($.$spc.System.UInt32).$h},{"n":"right","p":$.$spc.System.ReadOnlySpan$$($.$spc.System.UInt32).$h},{"n":"bits","p":$.$spc.System.Span$$($.$spc.System.UInt32).$h},{"n":"k","p":655361}],"n":"DivMul","d":1026833,"h":30065797905,"f":34},{"r":655361,"p":[{"n":"left","p":$.$spc.System.Span$$($.$spc.System.UInt32).$h},{"n":"right","p":$.$spc.System.ReadOnlySpan$$($.$spc.System.UInt32).$h},{"n":"modulus","p":$.$spc.System.ReadOnlySpan$$($.$spc.System.UInt32).$h},{"n":"k","p":655361}],"n":"SubMod","d":1026833,"h":34360765201,"f":34}],"l":[{"t":$.$spc.System.ReadOnlySpan$$($.$spc.System.UInt32).$h,"n":"_modulus","d":1026833,"h":4295994129,"f":2},{"t":$.$spc.System.ReadOnlySpan$$($.$spc.System.UInt32).$h,"n":"_mu","d":1026833,"h":8590961425,"f":2},{"t":$.$spc.System.Span$$($.$spc.System.UInt32).$h,"n":"_q1","d":1026833,"h":12885928721,"f":2},{"t":$.$spc.System.Span$$($.$spc.System.UInt32).$h,"n":"_q2","d":1026833,"h":17180896017,"f":2}],"c":[{"p":[{"n":"modulus","p":$.$spc.System.ReadOnlySpan$$($.$spc.System.UInt32).$h},{"n":"r","p":$.$spc.System.Span$$($.$spc.System.UInt32).$h},{"n":"mu","p":$.$spc.System.Span$$($.$spc.System.UInt32).$h},{"n":"q1","p":$.$spc.System.Span$$($.$spc.System.UInt32).$h},{"n":"q2","p":$.$spc.System.Span$$($.$spc.System.UInt32).$h}],"n":".ctor","o":"$ctor$2","d":1026833,"h":21475863313,"f":1},{"n":".ctor","o":"$ctor$3","d":1026833,"h":38655732497,"f":1}],"d":961297,"h":1026833}; }
                    static get $b() { return $.$spc.System.ValueType; }
                    static get $fullName() { return `System.Numerics.BigIntegerCalculator.FastReducer`; }
                }, $cls, ($v) => $cls.$_FastReducer = $v);
            }
            static /*uint */ Gcd(/*uint*/ left, /*uint*/ right)
            {
                while(right !== 0)
                {
                    /*uint*/ let temp = left % right;
                    left = right;
                    right = temp;
                }
                return left;
            }
            static /*ulong */ Gcd$1(/*ulong*/ left, /*ulong*/ right)
            {
                while(right > 4294967295n)
                {
                    /*ulong*/ let temp = left % right;
                    left = right;
                    right = temp;
                }
                if (right !== 0n)
                {
                    return BigInt($.$srn.System.Numerics.BigIntegerCalculator.Gcd($.$cast(right, $.$spc.System.UInt32), $.$cast((left % right), $.$spc.System.UInt32)));
                }
                return left;
            }
            static /*uint */ Gcd$2(/*ReadOnlySpan<uint>*/ left, /*uint*/ right)
            {
                $.$spc.System.Diagnostics.Debug.Assert$1(left.Length >= 1, "left.Length >= 1");
                $.$spc.System.Diagnostics.Debug.Assert$1(right !== 0, "right != 0");
                /*uint*/ let temp = $.$srn.System.Numerics.BigIntegerCalculator.Remainder(left, right);
                return $.$srn.System.Numerics.BigIntegerCalculator.Gcd(right, temp);
            }
            static /*void */ Gcd$3(/*ReadOnlySpan<uint>*/ left, /*ReadOnlySpan<uint>*/ right, /*Span<uint>*/ result)
            {
                $.$spc.System.Diagnostics.Debug.Assert$1(left.Length >= 2, "left.Length >= 2");
                $.$spc.System.Diagnostics.Debug.Assert$1(right.Length >= 2, "right.Length >= 2");
                $.$spc.System.Diagnostics.Debug.Assert$1($.$srn.System.Numerics.BigIntegerCalculator.CompareActual(left, right) >= 0, "CompareActual(left, right) >= 0");
                $.$spc.System.Diagnostics.Debug.Assert$1(result.Length === left.Length, "result.Length == left.Length");
                left.CopyTo(result);
                /*uint[]?*/ let rightCopyFromPool = null;
                /*Span<uint>*/ let rightCopy = (right.Length <= $.$srn.System.Numerics.BigIntegerCalculator.StackAllocThreshold ? $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.StackAllocSpan($.$spc.System.UInt32, $.$srn.System.Numerics.BigIntegerCalculator.StackAllocThreshold, null) : $.$spc.System.Span$$($.$spc.System.UInt32).op_Implicit(rightCopyFromPool = $.$spc.System.Buffers.ArrayPool$$($.$spc.System.UInt32).Shared.Rent(right.Length))).Slice$1(0, right.Length);
                right.CopyTo(rightCopy);
                $.$srn.System.Numerics.BigIntegerCalculator.Gcd$4(result, rightCopy);
                if (rightCopyFromPool !== null)
                {
                    $.$spc.System.Buffers.ArrayPool$$($.$spc.System.UInt32).Shared.Return(rightCopyFromPool, false);
                }
            }
            static /*void */ Gcd$4(/*Span<uint>*/ left, /*Span<uint>*/ right)
            {
                $.$spc.System.Diagnostics.Debug.Assert$1(left.Length >= 2, "left.Length >= 2");
                $.$spc.System.Diagnostics.Debug.Assert$1(right.Length >= 2, "right.Length >= 2");
                $.$spc.System.Diagnostics.Debug.Assert$1(left.Length >= right.Length, "left.Length >= right.Length");
                /*Span<uint>*/ let result = left;
                while(right.Length > 2)
                {
                    /*ulong*/ let x, y;
                    $.$srn.System.Numerics.BigIntegerCalculator.ExtractDigits($.$spc.System.Span$$($.$spc.System.UInt32).op_Implicit$2(left), $.$spc.System.Span$$($.$spc.System.UInt32).op_Implicit$2(right), $.$ref(() => x, ($v) => x = $v, $.$spc.System.UInt64), $.$ref(() => y, ($v) => y = $v, $.$spc.System.UInt64));
                    /*uint*/ let a = 1, b = 0;
                    /*uint*/ let c = 0, d = 1;
                    /*int*/ let iteration = 0;
                    while(y !== 0n)
                    {
                        /*ulong*/ let q, r, s, t;
                        q = x / y;
                        if (q > 4294967295n)
                        {
                            break;
                        }
                        r = BigInt(a) + q * BigInt(c);
                        s = BigInt(b) + q * BigInt(d);
                        t = x - q * y;
                        if (r > 2147483647n || s > 2147483647n)
                        {
                            break;
                        }
                        if (t < s || t + r > y - BigInt(c))
                        {
                            break;
                        }
                        a = $.$cast(r, $.$spc.System.UInt32);
                        b = $.$cast(s, $.$spc.System.UInt32);
                        x = t;
                        ++iteration;
                        if (x === BigInt(b))
                        {
                            break;
                        }
                        q = y / x;
                        if (q > 4294967295n)
                        {
                            break;
                        }
                        r = BigInt(d) + q * BigInt(b);
                        s = BigInt(c) + q * BigInt(a);
                        t = y - q * x;
                        if (r > 2147483647n || s > 2147483647n)
                        {
                            break;
                        }
                        if (t < s || t + r > x - BigInt(b))
                        {
                            break;
                        }
                        d = $.$cast(r, $.$spc.System.UInt32);
                        c = $.$cast(s, $.$spc.System.UInt32);
                        y = t;
                        ++iteration;
                        if (y === BigInt(c))
                        {
                            break;
                        }
                    }
                    if (b === 0)
                    {
                        left = left.Slice$1(0, $.$srn.System.Numerics.BigIntegerCalculator.Reduce(left, $.$spc.System.Span$$($.$spc.System.UInt32).op_Implicit$2(right)));
                        /*Span<uint>*/ let temp = left;
                        left = right;
                        right = temp;
                    }
                    else 
                    {
                        /*var*/ let count = $.$srn.System.Numerics.BigIntegerCalculator.LehmerCore(left, right, BigInt(a), BigInt(b), BigInt(c), BigInt(d));
                        left = left.Slice$1(0, $.$srn.System.Numerics.BigIntegerCalculator.Refresh(left, count));
                        right = right.Slice$1(0, $.$srn.System.Numerics.BigIntegerCalculator.Refresh(right, count));
                        if (iteration % 2 === 1)
                        {
                            /*Span<uint>*/ let temp = left;
                            left = right;
                            right = temp;
                        }
                    }
                }
                if (right.Length > 0)
                {
                    $.$srn.System.Numerics.BigIntegerCalculator.Reduce(left, $.$spc.System.Span$$($.$spc.System.UInt32).op_Implicit$2(right));
                    /*ulong*/ let x = BigInt(right.get_Item(0).$v);
                    /*ulong*/ let y = BigInt(left.get_Item(0).$v);
                    if (right.Length > 1)
                    {
                        x |= BigInt.asUintN(64, $.$cast(right.get_Item(1).$v, $.$spc.System.UInt64) << 32n);
                        y |= BigInt.asUintN(64, $.$cast(left.get_Item(1).$v, $.$spc.System.UInt64) << 32n);
                    }
                    left = left.Slice$1(0, $.$srn.System.Numerics.BigIntegerCalculator.Overwrite(left, $.$srn.System.Numerics.BigIntegerCalculator.Gcd$1(x, y)));
                    right.Clear();
                }
                left.CopyTo(result);
            }
            static /*int */ Overwrite(/*Span<uint>*/ buffer, /*ulong*/ value)
            {
                $.$spc.System.Diagnostics.Debug.Assert$1(buffer.Length >= 2, "buffer.Length >= 2");
                if (buffer.Length > 2)
                {
                    buffer.Slice(2).Clear();
                }
                /*uint*/ let lo = $.$cast(value, $.$spc.System.UInt32);
                /*uint*/ let hi = $.$cast((value >> 32n), $.$spc.System.UInt32);
                buffer.get_Item(1).$v = hi;
                buffer.get_Item(0).$v = lo;
                return hi !== 0 ? 2 : lo !== 0 ? 1 : 0;
            }
            static /*void */ ExtractDigits(/*ReadOnlySpan<uint>*/ xBuffer, /*ReadOnlySpan<uint>*/ yBuffer, /*out ulong*/ x, /*out ulong*/ y)
            {
                $.$spc.System.Diagnostics.Debug.Assert$1(xBuffer.Length >= 3, "xBuffer.Length >= 3");
                $.$spc.System.Diagnostics.Debug.Assert$1(yBuffer.Length >= 3, "yBuffer.Length >= 3");
                $.$spc.System.Diagnostics.Debug.Assert$1(xBuffer.Length >= yBuffer.Length, "xBuffer.Length >= yBuffer.Length");
                /*ulong*/ let xh = BigInt(xBuffer.get_Item(((xBuffer.Length - 1) | 0)).$v);
                /*ulong*/ let xm = BigInt(xBuffer.get_Item(((xBuffer.Length - 2) | 0)).$v);
                /*ulong*/ let xl = BigInt(xBuffer.get_Item(((xBuffer.Length - 3) | 0)).$v);
                /*ulong*/ let yh, ym, yl;
                let $switch1 = ((xBuffer.Length - yBuffer.Length) | 0);
                switch($switch1)
                {
                    case 0:
                    yh = BigInt(yBuffer.get_Item(((yBuffer.Length - 1) | 0)).$v);
                    ym = BigInt(yBuffer.get_Item(((yBuffer.Length - 2) | 0)).$v);
                    yl = BigInt(yBuffer.get_Item(((yBuffer.Length - 3) | 0)).$v);
                    break;
                    case 1:
                    yh = 0n;
                    ym = BigInt(yBuffer.get_Item(((yBuffer.Length - 1) | 0)).$v);
                    yl = BigInt(yBuffer.get_Item(((yBuffer.Length - 2) | 0)).$v);
                    break;
                    case 2:
                    yh = 0n;
                    ym = 0n;
                    yl = BigInt(yBuffer.get_Item(((yBuffer.Length - 1) | 0)).$v);
                    break;
                    default:
                    yh = 0n;
                    ym = 0n;
                    yl = 0n;
                    break;
                }
                /*int*/ let z = $.$spc.System.Numerics.BitOperations.LeadingZeroCount($.$cast(xh, $.$spc.System.UInt32));
                x.$v = ((BigInt.asUintN(64, xh << BigInt(((32 + z) | 0)))) | (BigInt.asUintN(64, xm << BigInt(z))) | (xl >> BigInt(((32 - z) | 0)))) >> 1n;
                y.$v = ((BigInt.asUintN(64, yh << BigInt(((32 + z) | 0)))) | (BigInt.asUintN(64, ym << BigInt(z))) | (yl >> BigInt(((32 - z) | 0)))) >> 1n;
                $.$spc.System.Diagnostics.Debug.Assert$1(x.$v >= y.$v, "x >= y");
            }
            static /*int */ LehmerCore(/*Span<uint>*/ x, /*Span<uint>*/ y, /*long*/ a, /*long*/ b, /*long*/ c, /*long*/ d)
            {
                $.$spc.System.Diagnostics.Debug.Assert$1(x.Length >= 1, "x.Length >= 1");
                $.$spc.System.Diagnostics.Debug.Assert$1(y.Length >= 1, "y.Length >= 1");
                $.$spc.System.Diagnostics.Debug.Assert$1(x.Length >= y.Length, "x.Length >= y.Length");
                $.$spc.System.Diagnostics.Debug.Assert$1(a <= 2147483647n && b <= 2147483647n, "a <= 0x7FFFFFFF && b <= 0x7FFFFFFF");
                $.$spc.System.Diagnostics.Debug.Assert$1(c <= 2147483647n && d <= 2147483647n, "c <= 0x7FFFFFFF && d <= 0x7FFFFFFF");
                /*int*/ let length = y.Length;
                /*long*/ let xCarry = 0n, yCarry = 0n;
                for(/*int*/ let i = 0; i < length; i++)
                {
                    /*long*/ let xDigit = a * BigInt(x.get_Item(i).$v) - b * BigInt(y.get_Item(i).$v) + xCarry;
                    /*long*/ let yDigit = d * BigInt(y.get_Item(i).$v) - c * BigInt(x.get_Item(i).$v) + yCarry;
                    xCarry = xDigit >> 32n;
                    yCarry = yDigit >> 32n;
                    x.get_Item(i).$v = $.$cast(xDigit, $.$spc.System.UInt32);
                    y.get_Item(i).$v = $.$cast(yDigit, $.$spc.System.UInt32);
                }
                return length;
            }
            static /*int */ Refresh(/*Span<uint>*/ bits, /*int*/ maxLength)
            {
                $.$spc.System.Diagnostics.Debug.Assert$1(bits.Length >= maxLength, "bits.Length >= maxLength");
                if (bits.Length > maxLength)
                {
                    bits.Slice(maxLength).Clear();
                }
                return $.$srn.System.Numerics.BigIntegerCalculator.ActualLength($.$spc.System.Span$$($.$spc.System.UInt32).op_Implicit$2(bits.Slice$1(0, maxLength)));
            }
            /*int*/ static SquareThreshold = 32;
            static /*void */ Square(/*ReadOnlySpan<uint>*/ value, /*Span<uint>*/ bits)
            {
                $.$spc.System.Diagnostics.Debug.Assert$1(bits.Length === ((value.Length + value.Length) | 0), "bits.Length == value.Length + value.Length");
                if (value.Length < $.$srn.System.Numerics.BigIntegerCalculator.SquareThreshold)
                {
                    /*ref uint*/ let resultPtr = $.$spc.System.Runtime.InteropServices.MemoryMarshal.GetReference($.$spc.System.UInt32, bits);
                    for(/*int*/ let i = 0; i < value.Length; i++)
                    {
                        /*ulong*/ let carry = 0n;
                        /*uint*/ let v = value.get_Item(i).$v;
                        for(/*int*/ let j = 0; j < i; j++)
                        {
                            /*ulong*/ let digit1 = BigInt($.$spc.System.Runtime.CompilerServices.Unsafe.Add($.$spc.System.UInt32, resultPtr, ((i + j) | 0)).$v) + carry;
                            /*ulong*/ let digit2 = $.$cast(value.get_Item(j).$v, $.$spc.System.UInt64) * BigInt(v);
                            resultPtr.SetAt($.$cast((digit1 + (BigInt.asUintN(64, digit2 << 1n))), $.$spc.System.UInt32), ((i + j) | 0));
                            carry = (digit2 + (digit1 >> 1n)) >> 31n;
                        }
                        /*ulong*/ let digits = $.$cast(v, $.$spc.System.UInt64) * BigInt(v) + carry;
                        resultPtr.SetAt($.$cast(digits, $.$spc.System.UInt32), ((i + i) | 0));
                        resultPtr.SetAt($.$cast((digits >> 32n), $.$spc.System.UInt32), ((((i + i) | 0) + 1) | 0));
                    }
                }
                else 
                {
                    /*int*/ let n = value.Length >> 1;
                    /*int*/ let n2 = n << 1;
                    /*ReadOnlySpan<uint>*/ let valueLow = value.Slice$1(0, n);
                    /*ReadOnlySpan<uint>*/ let valueHigh = value.Slice(n);
                    /*Span<uint>*/ let bitsLow = bits.Slice$1(0, n2);
                    /*Span<uint>*/ let bitsHigh = bits.Slice(n2);
                    $.$srn.System.Numerics.BigIntegerCalculator.Square(valueLow, bitsLow);
                    $.$srn.System.Numerics.BigIntegerCalculator.Square(valueHigh, bitsHigh);
                    /*int*/ let foldLength = ((valueHigh.Length + 1) | 0);
                    /*uint[]?*/ let foldFromPool = null;
                    /*Span<uint>*/ let fold = (BigInt((foldLength >>> 0)) <= BigInt($.$srn.System.Numerics.BigIntegerCalculator.StackAllocThreshold) ? $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.StackAllocSpan($.$spc.System.UInt32, $.$srn.System.Numerics.BigIntegerCalculator.StackAllocThreshold, null) : $.$spc.System.Span$$($.$spc.System.UInt32).op_Implicit(foldFromPool = $.$spc.System.Buffers.ArrayPool$$($.$spc.System.UInt32).Shared.Rent(foldLength))).Slice$1(0, foldLength);
                    fold.Clear();
                    /*int*/ let coreLength = ((foldLength + foldLength) | 0);
                    /*uint[]?*/ let coreFromPool = null;
                    /*Span<uint>*/ let core = (BigInt((coreLength >>> 0)) <= BigInt($.$srn.System.Numerics.BigIntegerCalculator.StackAllocThreshold) ? $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.StackAllocSpan($.$spc.System.UInt32, $.$srn.System.Numerics.BigIntegerCalculator.StackAllocThreshold, null) : $.$spc.System.Span$$($.$spc.System.UInt32).op_Implicit(coreFromPool = $.$spc.System.Buffers.ArrayPool$$($.$spc.System.UInt32).Shared.Rent(coreLength))).Slice$1(0, coreLength);
                    core.Clear();
                    $.$srn.System.Numerics.BigIntegerCalculator.Add$1(valueHigh, valueLow, fold);
                    $.$srn.System.Numerics.BigIntegerCalculator.Square($.$spc.System.Span$$($.$spc.System.UInt32).op_Implicit$2(fold), core);
                    if (foldFromPool !== null)
                    {
                        $.$spc.System.Buffers.ArrayPool$$($.$spc.System.UInt32).Shared.Return(foldFromPool, false);
                    }
                    $.$srn.System.Numerics.BigIntegerCalculator.SubtractCore($.$spc.System.Span$$($.$spc.System.UInt32).op_Implicit$2(bitsHigh), $.$spc.System.Span$$($.$spc.System.UInt32).op_Implicit$2(bitsLow), core);
                    $.$srn.System.Numerics.BigIntegerCalculator.AddSelf(bits.Slice(n), $.$spc.System.Span$$($.$spc.System.UInt32).op_Implicit$2(core));
                    if (coreFromPool !== null)
                    {
                        $.$spc.System.Buffers.ArrayPool$$($.$spc.System.UInt32).Shared.Return(coreFromPool, false);
                    }
                }
            }
            static /*void */ Multiply(/*ReadOnlySpan<uint>*/ left, /*uint*/ right, /*Span<uint>*/ bits)
            {
                $.$spc.System.Diagnostics.Debug.Assert$1(bits.Length === ((left.Length + 1) | 0), "bits.Length == left.Length + 1");
                /*int*/ let i = 0;
                /*ulong*/ let carry = 0n;
                for(; i < left.Length; i++)
                {
                    /*ulong*/ let digits = $.$cast(left.get_Item(i).$v, $.$spc.System.UInt64) * BigInt(right) + carry;
                    bits.get_Item(i).$v = $.$cast(digits, $.$spc.System.UInt32);
                    carry = digits >> 32n;
                }
                bits.get_Item(i).$v = $.$cast(carry, $.$spc.System.UInt32);
            }
            /*int*/ static MultiplyKaratsubaThreshold = 32;
            static /*void */ Multiply$1(/*ReadOnlySpan<uint>*/ left, /*ReadOnlySpan<uint>*/ right, /*Span<uint>*/ bits)
            {
                $.$spc.System.Diagnostics.Debug.Assert$1(left.Length >= right.Length, "left.Length >= right.Length");
                $.$spc.System.Diagnostics.Debug.Assert$1(bits.Length >= ((left.Length + right.Length) | 0), "bits.Length >= left.Length + right.Length");
                $.$spc.System.Diagnostics.Debug.Assert$1($.$spc.System.MemoryExtensions.Trim$2($.$spc.System.UInt32, bits, 0).IsEmpty, "bits.Trim(0u).IsEmpty");
                $.$spc.System.Diagnostics.Debug.Assert$1($.$srn.System.Numerics.BigIntegerCalculator.MultiplyKaratsubaThreshold >= 2, "MultiplyKaratsubaThreshold >= 2");
                if (right.Length < $.$srn.System.Numerics.BigIntegerCalculator.MultiplyKaratsubaThreshold)
                {
                    Naive(left, right, bits);
                    return;
                }
                /*int*/ let n = (((left.Length + 1) | 0)) >> 1;
                if (right.Length <= n)
                {
                    /*ReadOnlySpan<uint>*/ let leftLow = left.Slice$1(0, n);
                    /*ReadOnlySpan<uint>*/ let leftHigh = left.Slice(n);
                    $.$spc.System.Diagnostics.Debug.Assert$1(leftLow.Length >= leftHigh.Length, "leftLow.Length >= leftHigh.Length");
                    /*Span<uint>*/ let bitsLow = bits.Slice$1(0, ((n + right.Length) | 0));
                    /*Span<uint>*/ let bitsHigh = bits.Slice(n);
                    $.$srn.System.Numerics.BigIntegerCalculator.Multiply$1(leftLow, right, bitsLow);
                    /*int*/ let carryLength = right.Length;
                    /*uint[]?*/ let carryFromPool = null;
                    /*Span<uint>*/ let carry = (BigInt((carryLength >>> 0)) <= BigInt($.$srn.System.Numerics.BigIntegerCalculator.StackAllocThreshold) ? $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.StackAllocSpan($.$spc.System.UInt32, $.$srn.System.Numerics.BigIntegerCalculator.StackAllocThreshold, null) : $.$spc.System.Span$$($.$spc.System.UInt32).op_Implicit(carryFromPool = $.$spc.System.Buffers.ArrayPool$$($.$spc.System.UInt32).Shared.Rent(carryLength))).Slice$1(0, carryLength);
                    /*Span<uint>*/ let carryOrig = bits.Slice$1(n, right.Length);
                    carryOrig.CopyTo(carry);
                    carryOrig.Clear();
                    if (leftHigh.Length < right.Length)
                    {
                        MultiplyKaratsuba(right, leftHigh, bitsHigh.Slice$1(0, ((leftHigh.Length + right.Length) | 0)), (((right.Length + 1) | 0)) >> 1);
                    }
                    else 
                    {
                        $.$srn.System.Numerics.BigIntegerCalculator.Multiply$1(leftHigh, right, bitsHigh.Slice$1(0, ((leftHigh.Length + right.Length) | 0)));
                    }
                    $.$srn.System.Numerics.BigIntegerCalculator.AddSelf(bitsHigh, $.$spc.System.Span$$($.$spc.System.UInt32).op_Implicit$2(carry));
                    if (carryFromPool !== null)
                    {
                        $.$spc.System.Buffers.ArrayPool$$($.$spc.System.UInt32).Shared.Return(carryFromPool, false);
                    }
                }
                else 
                {
                    MultiplyKaratsuba(left, right, bits, n);
                }
                /*static void*/  function MultiplyKaratsuba(/*ReadOnlySpan<uint>*/ left, /*ReadOnlySpan<uint>*/ right, /*Span<uint>*/ bits, /*int*/ n)
                {
                    $.$spc.System.Diagnostics.Debug.Assert$1(left.Length >= right.Length, "left.Length >= right.Length");
                    $.$spc.System.Diagnostics.Debug.Assert$1((((((2 * n) | 0) - left.Length) | 0) === 0) || (((((2 * n) | 0) - left.Length) | 0) === 1), "2 * n - left.Length is 0 or 1");
                    $.$spc.System.Diagnostics.Debug.Assert$1(right.Length > n, "right.Length > n");
                    $.$spc.System.Diagnostics.Debug.Assert$1(bits.Length >= ((left.Length + right.Length) | 0), "bits.Length >= left.Length + right.Length");
                    if (right.Length < $.$srn.System.Numerics.BigIntegerCalculator.MultiplyKaratsubaThreshold)
                    {
                        Naive(left, right, bits);
                    }
                    else 
                    {
                        /*ReadOnlySpan<uint>*/ let leftLow = left.Slice$1(0, n);
                        /*ReadOnlySpan<uint>*/ let leftHigh = left.Slice(n);
                        /*ReadOnlySpan<uint>*/ let rightLow = right.Slice$1(0, n);
                        /*ReadOnlySpan<uint>*/ let rightHigh = right.Slice(n);
                        /*Span<uint>*/ let bitsLow = bits.Slice$1(0, ((n + n) | 0));
                        /*Span<uint>*/ let bitsHigh = bits.Slice(((n + n) | 0));
                        $.$spc.System.Diagnostics.Debug.Assert$1(leftLow.Length >= leftHigh.Length, "leftLow.Length >= leftHigh.Length");
                        $.$spc.System.Diagnostics.Debug.Assert$1(rightLow.Length >= rightHigh.Length, "rightLow.Length >= rightHigh.Length");
                        $.$spc.System.Diagnostics.Debug.Assert$1(bitsLow.Length >= bitsHigh.Length, "bitsLow.Length >= bitsHigh.Length");
                        MultiplyKaratsuba(leftLow, rightLow, bitsLow, (((leftLow.Length + 1) | 0)) >> 1);
                        $.$srn.System.Numerics.BigIntegerCalculator.Multiply$1(leftHigh, rightHigh, bitsHigh);
                        /*int*/ let foldLength = ((n + 1) | 0);
                        /*uint[]?*/ let leftFoldFromPool = null;
                        /*Span<uint>*/ let leftFold = (BigInt((foldLength >>> 0)) <= BigInt($.$srn.System.Numerics.BigIntegerCalculator.StackAllocThreshold) ? $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.StackAllocSpan($.$spc.System.UInt32, $.$srn.System.Numerics.BigIntegerCalculator.StackAllocThreshold, null) : $.$spc.System.Span$$($.$spc.System.UInt32).op_Implicit(leftFoldFromPool = $.$spc.System.Buffers.ArrayPool$$($.$spc.System.UInt32).Shared.Rent(foldLength))).Slice$1(0, foldLength);
                        leftFold.Clear();
                        /*uint[]?*/ let rightFoldFromPool = null;
                        /*Span<uint>*/ let rightFold = (BigInt((foldLength >>> 0)) <= BigInt($.$srn.System.Numerics.BigIntegerCalculator.StackAllocThreshold) ? $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.StackAllocSpan($.$spc.System.UInt32, $.$srn.System.Numerics.BigIntegerCalculator.StackAllocThreshold, null) : $.$spc.System.Span$$($.$spc.System.UInt32).op_Implicit(rightFoldFromPool = $.$spc.System.Buffers.ArrayPool$$($.$spc.System.UInt32).Shared.Rent(foldLength))).Slice$1(0, foldLength);
                        rightFold.Clear();
                        $.$srn.System.Numerics.BigIntegerCalculator.Add$1(leftLow, leftHigh, leftFold);
                        $.$srn.System.Numerics.BigIntegerCalculator.Add$1(rightLow, rightHigh, rightFold);
                        /*int*/ let coreLength = ((foldLength + foldLength) | 0);
                        /*uint[]?*/ let coreFromPool = null;
                        /*Span<uint>*/ let core = (BigInt((coreLength >>> 0)) <= BigInt($.$srn.System.Numerics.BigIntegerCalculator.StackAllocThreshold) ? $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.StackAllocSpan($.$spc.System.UInt32, $.$srn.System.Numerics.BigIntegerCalculator.StackAllocThreshold, null) : $.$spc.System.Span$$($.$spc.System.UInt32).op_Implicit(coreFromPool = $.$spc.System.Buffers.ArrayPool$$($.$spc.System.UInt32).Shared.Rent(coreLength))).Slice$1(0, coreLength);
                        core.Clear();
                        MultiplyKaratsuba($.$spc.System.Span$$($.$spc.System.UInt32).op_Implicit$2(leftFold), $.$spc.System.Span$$($.$spc.System.UInt32).op_Implicit$2(rightFold), core, (((leftFold.Length + 1) | 0)) >> 1);
                        if (leftFoldFromPool !== null)
                        {
                            $.$spc.System.Buffers.ArrayPool$$($.$spc.System.UInt32).Shared.Return(leftFoldFromPool, false);
                        }
                        if (rightFoldFromPool !== null)
                        {
                            $.$spc.System.Buffers.ArrayPool$$($.$spc.System.UInt32).Shared.Return(rightFoldFromPool, false);
                        }
                        $.$srn.System.Numerics.BigIntegerCalculator.SubtractCore($.$spc.System.Span$$($.$spc.System.UInt32).op_Implicit$2(bitsLow), $.$spc.System.Span$$($.$spc.System.UInt32).op_Implicit$2(bitsHigh), core);
                        $.$spc.System.Diagnostics.Debug.Assert$1($.$srn.System.Numerics.BigIntegerCalculator.ActualLength($.$spc.System.Span$$($.$spc.System.UInt32).op_Implicit$2(core)) <= ((left.Length + 1) | 0), "ActualLength(core) <= left.Length + 1");
                        $.$srn.System.Numerics.BigIntegerCalculator.AddSelf(bits.Slice(n), $.$spc.System.Span$$($.$spc.System.UInt32).op_Implicit$2(core.Slice$1(0, $.$srn.System.Numerics.BigIntegerCalculator.ActualLength($.$spc.System.Span$$($.$spc.System.UInt32).op_Implicit$2(core)))));
                        if (coreFromPool !== null)
                        {
                            $.$spc.System.Buffers.ArrayPool$$($.$spc.System.UInt32).Shared.Return(coreFromPool, false);
                        }
                    }
                }
                /*static void*/  function Naive(/*ReadOnlySpan<uint>*/ left, /*ReadOnlySpan<uint>*/ right, /*Span<uint>*/ bits)
                {
                    $.$spc.System.Diagnostics.Debug.Assert$1(right.Length < $.$srn.System.Numerics.BigIntegerCalculator.MultiplyKaratsubaThreshold, "right.Length < MultiplyKaratsubaThreshold");
                    /*ref uint*/ let resultPtr = $.$spc.System.Runtime.InteropServices.MemoryMarshal.GetReference($.$spc.System.UInt32, bits);
                    for(/*int*/ let i = 0; i < right.Length; i++)
                    {
                        /*uint*/ let rv = right.get_Item(i).$v;
                        /*ulong*/ let carry = 0n;
                        for(/*int*/ let j = 0; j < left.Length; j++)
                        {
                            /*ref uint*/ let elementPtr = $.$spc.System.Runtime.CompilerServices.Unsafe.Add($.$spc.System.UInt32, resultPtr, ((i + j) | 0));
                            /*ulong*/ let digits = BigInt(elementPtr.$v) + carry + $.$cast(left.get_Item(j).$v, $.$spc.System.UInt64) * BigInt(rv);
                            elementPtr.$v = $.$cast(digits, $.$spc.System.UInt32);
                            carry = digits >> 32n;
                        }
                        resultPtr.SetAt($.$cast(carry, $.$spc.System.UInt32), ((i + left.Length) | 0));
                    }
                }
            }
            static /*void */ SubtractCore(/*ReadOnlySpan<uint>*/ left, /*ReadOnlySpan<uint>*/ right, /*Span<uint>*/ core)
            {
                $.$spc.System.Diagnostics.Debug.Assert$1(left.Length >= right.Length, "left.Length >= right.Length");
                $.$spc.System.Diagnostics.Debug.Assert$1(core.Length >= left.Length, "core.Length >= left.Length");
                /*int*/ let i = 0;
                /*long*/ let carry = 0n;
                /*ref uint*/ let leftPtr = $.$spc.System.Runtime.InteropServices.MemoryMarshal.GetReference$1($.$spc.System.UInt32, left);
                /*ref uint*/ let corePtr = $.$spc.System.Runtime.InteropServices.MemoryMarshal.GetReference($.$spc.System.UInt32, core);
                for(; i < right.Length; i++)
                {
                    /*long*/ let digit = (BigInt($.$spc.System.Runtime.CompilerServices.Unsafe.Add($.$spc.System.UInt32, corePtr, i).$v) + carry) - BigInt($.$spc.System.Runtime.CompilerServices.Unsafe.Add($.$spc.System.UInt32, leftPtr, i).$v) - BigInt(right.get_Item(i).$v);
                    corePtr.SetAt($.$cast(digit, $.$spc.System.UInt32), i);
                    carry = digit >> 32n;
                }
                for(; i < left.Length; i++)
                {
                    /*long*/ let digit = (BigInt($.$spc.System.Runtime.CompilerServices.Unsafe.Add($.$spc.System.UInt32, corePtr, i).$v) + carry) - BigInt(left.get_Item(i).$v);
                    corePtr.SetAt($.$cast(digit, $.$spc.System.UInt32), i);
                    carry = digit >> 32n;
                }
                for(; carry !== 0n && i < core.Length; i++)
                {
                    /*long*/ let digit = BigInt(core.get_Item(i).$v) + carry;
                    core.get_Item(i).$v = $.$cast(digit, $.$spc.System.UInt32);
                    carry = digit >> 32n;
                }
            }
            /*int*/ static StackAllocThreshold = 64;
            static /*int */ Compare(/*ReadOnlySpan<uint>*/ left, /*ReadOnlySpan<uint>*/ right)
            {
                $.$spc.System.Diagnostics.Debug.Assert$1(left.Length <= right.Length || $.$spc.System.MemoryExtensions.ContainsAnyExcept$5($.$spc.System.UInt32, left.Slice(right.Length), 0), "left.Length <= right.Length || left.Slice(right.Length).ContainsAnyExcept(0u)");
                $.$spc.System.Diagnostics.Debug.Assert$1(left.Length >= right.Length || $.$spc.System.MemoryExtensions.ContainsAnyExcept$5($.$spc.System.UInt32, right.Slice(left.Length), 0), "left.Length >= right.Length || right.Slice(left.Length).ContainsAnyExcept(0u)");
                if (left.Length !== right.Length)
                {
                    return left.Length < right.Length ? -1 : 1;
                }
                /*int*/ let iv = left.Length;
                while(--iv >= 0 && left.get_Item(iv).$v === right.get_Item(iv).$v)
                {
                }
                if (iv < 0)
                {
                    return 0;
                }
                return left.get_Item(iv).$v < right.get_Item(iv).$v ? -1 : 1;
            }
            static /*int */ CompareActual(/*ReadOnlySpan<uint>*/ left, /*ReadOnlySpan<uint>*/ right)
            {
                if (left.Length !== right.Length)
                {
                    if (left.Length < right.Length)
                    {
                        if ($.$srn.System.Numerics.BigIntegerCalculator.ActualLength(right.Slice(left.Length)) > 0)
                        {
                            return -1;
                        }
                        right = right.Slice$1(0, left.Length);
                    }
                    else 
                    {
                        if ($.$srn.System.Numerics.BigIntegerCalculator.ActualLength(left.Slice(right.Length)) > 0)
                        {
                            return +1;
                        }
                        left = left.Slice$1(0, right.Length);
                    }
                }
                return $.$srn.System.Numerics.BigIntegerCalculator.Compare(left, right);
            }
            static /*int */ ActualLength(/*ReadOnlySpan<uint>*/ value)
            {
                /*int*/ let length = value.Length;
                while(length > 0 && (value.get_Item(((length - 1) | 0)).$v >>> 0) == 0)
                {
                    --length;
                }
                return length;
            }
            static /*int */ Reduce(/*Span<uint>*/ bits, /*ReadOnlySpan<uint>*/ modulus)
            {
                if (bits.Length >= modulus.Length)
                {
                    $.$srn.System.Numerics.BigIntegerCalculator.DivRem(bits, modulus, new ($.$spc.System.Span$$($.$spc.System.UInt32))());
                    return $.$srn.System.Numerics.BigIntegerCalculator.ActualLength($.$spc.System.Span$$($.$spc.System.UInt32).op_Implicit$2(bits.Slice$1(0, modulus.Length)));
                }
                return bits.Length;
            }
            static /*void */ InitializeForDebug(/*Span<uint>*/ bits)
            {
                bits.Fill(205);
            }
            /*int*/ static DivideBurnikelZieglerThreshold = 32;
            static /*void */ Divide(/*ReadOnlySpan<uint>*/ left, /*uint*/ right, /*Span<uint>*/ quotient, /*out uint*/ remainder)
            {
                $.$srn.System.Numerics.BigIntegerCalculator.InitializeForDebug(quotient);
                /*ulong*/ let carry = 0n;
                $.$srn.System.Numerics.BigIntegerCalculator.Divide$2(left, right, quotient, $.$ref(() => carry, ($v) => carry = $v, $.$spc.System.UInt64));
                remainder.$v = $.$cast(carry, $.$spc.System.UInt32);
            }
            static /*void */ Divide$1(/*ReadOnlySpan<uint>*/ left, /*uint*/ right, /*Span<uint>*/ quotient)
            {
                $.$srn.System.Numerics.BigIntegerCalculator.InitializeForDebug(quotient);
                /*ulong*/ let carry = 0n;
                $.$srn.System.Numerics.BigIntegerCalculator.Divide$2(left, right, quotient, $.$ref(() => carry, ($v) => carry = $v, $.$spc.System.UInt64));
            }
            static /*void */ Divide$2(/*ReadOnlySpan<uint>*/ left, /*uint*/ right, /*Span<uint>*/ quotient, /*ref ulong*/ carry)
            {
                $.$spc.System.Diagnostics.Debug.Assert$1(left.Length >= 1, "left.Length >= 1");
                $.$spc.System.Diagnostics.Debug.Assert$1(quotient.Length === left.Length, "quotient.Length == left.Length");
                $.$srn.System.Numerics.BigIntegerCalculator.InitializeForDebug(quotient);
                for(/*int*/ let i = ((left.Length - 1) | 0); i >= 0; i--)
                {
                    /*ulong*/ let value = (BigInt.asUintN(64, carry.$v << 32n)) | BigInt(left.get_Item(i).$v);
                    /*ulong*/ let digit = value / BigInt(right);
                    quotient.get_Item(i).$v = $.$cast(digit, $.$spc.System.UInt32);
                    carry.$v = value - digit * BigInt(right);
                }
            }
            static /*uint */ Remainder(/*ReadOnlySpan<uint>*/ left, /*uint*/ right)
            {
                $.$spc.System.Diagnostics.Debug.Assert$1(left.Length >= 1, "left.Length >= 1");
                /*ulong*/ let carry = 0n;
                for(/*int*/ let i = ((left.Length - 1) | 0); i >= 0; i--)
                {
                    /*ulong*/ let value = (BigInt.asUintN(64, carry << 32n)) | BigInt(left.get_Item(i).$v);
                    carry = value % BigInt(right);
                }
                return $.$cast(carry, $.$spc.System.UInt32);
            }
            static /*void */ Divide$3(/*ReadOnlySpan<uint>*/ left, /*ReadOnlySpan<uint>*/ right, /*Span<uint>*/ quotient, /*Span<uint>*/ remainder)
            {
                $.$spc.System.Diagnostics.Debug.Assert$1(left.Length >= 1, "left.Length >= 1");
                $.$spc.System.Diagnostics.Debug.Assert$1(right.Length >= 1, "right.Length >= 1");
                $.$spc.System.Diagnostics.Debug.Assert$1(left.Length >= right.Length, "left.Length >= right.Length");
                $.$spc.System.Diagnostics.Debug.Assert$1(quotient.Length === ((((left.Length - right.Length) | 0) + 1) | 0), "quotient.Length == left.Length - right.Length + 1");
                $.$spc.System.Diagnostics.Debug.Assert$1(remainder.Length === left.Length, "remainder.Length == left.Length");
                $.$srn.System.Numerics.BigIntegerCalculator.InitializeForDebug(quotient);
                $.$srn.System.Numerics.BigIntegerCalculator.InitializeForDebug(remainder);
                if (right.Length < $.$srn.System.Numerics.BigIntegerCalculator.DivideBurnikelZieglerThreshold || ((left.Length - right.Length) | 0) < $.$srn.System.Numerics.BigIntegerCalculator.DivideBurnikelZieglerThreshold)
                {
                    left.CopyTo(remainder);
                    $.$srn.System.Numerics.BigIntegerCalculator.DivideGrammarSchool(remainder, right, quotient);
                }
                else 
                {
                    $.$srn.System.Numerics.BigIntegerCalculator.DivideBurnikelZiegler(left, right, quotient, remainder);
                }
            }
            static /*void */ Divide$4(/*ReadOnlySpan<uint>*/ left, /*ReadOnlySpan<uint>*/ right, /*Span<uint>*/ quotient)
            {
                $.$spc.System.Diagnostics.Debug.Assert$1(left.Length >= 1, "left.Length >= 1");
                $.$spc.System.Diagnostics.Debug.Assert$1(right.Length >= 1, "right.Length >= 1");
                $.$spc.System.Diagnostics.Debug.Assert$1(left.Length >= right.Length, "left.Length >= right.Length");
                $.$spc.System.Diagnostics.Debug.Assert$1(quotient.Length === ((((left.Length - right.Length) | 0) + 1) | 0), "quotient.Length == left.Length - right.Length + 1");
                $.$srn.System.Numerics.BigIntegerCalculator.InitializeForDebug(quotient);
                if (right.Length < $.$srn.System.Numerics.BigIntegerCalculator.DivideBurnikelZieglerThreshold || ((left.Length - right.Length) | 0) < $.$srn.System.Numerics.BigIntegerCalculator.DivideBurnikelZieglerThreshold)
                {
                    /*uint[]?*/ let leftCopyFromPool = null;
                    /*Span<uint>*/ let leftCopy = (left.Length <= $.$srn.System.Numerics.BigIntegerCalculator.StackAllocThreshold ? $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.StackAllocSpan($.$spc.System.UInt32, $.$srn.System.Numerics.BigIntegerCalculator.StackAllocThreshold, null) : $.$spc.System.Span$$($.$spc.System.UInt32).op_Implicit(leftCopyFromPool = $.$spc.System.Buffers.ArrayPool$$($.$spc.System.UInt32).Shared.Rent(left.Length))).Slice$1(0, left.Length);
                    left.CopyTo(leftCopy);
                    $.$srn.System.Numerics.BigIntegerCalculator.DivideGrammarSchool(leftCopy, right, quotient);
                    if (leftCopyFromPool !== null)
                    {
                        $.$spc.System.Buffers.ArrayPool$$($.$spc.System.UInt32).Shared.Return(leftCopyFromPool, false);
                    }
                }
                else 
                {
                    $.$srn.System.Numerics.BigIntegerCalculator.DivideBurnikelZiegler(left, right, quotient, new ($.$spc.System.Span$$($.$spc.System.UInt32))());
                }
            }
            static /*void */ Remainder$1(/*ReadOnlySpan<uint>*/ left, /*ReadOnlySpan<uint>*/ right, /*Span<uint>*/ remainder)
            {
                $.$spc.System.Diagnostics.Debug.Assert$1(left.Length >= 1, "left.Length >= 1");
                $.$spc.System.Diagnostics.Debug.Assert$1(right.Length >= 1, "right.Length >= 1");
                $.$spc.System.Diagnostics.Debug.Assert$1(left.Length >= right.Length, "left.Length >= right.Length");
                $.$spc.System.Diagnostics.Debug.Assert$1(remainder.Length === left.Length, "remainder.Length == left.Length");
                $.$srn.System.Numerics.BigIntegerCalculator.InitializeForDebug(remainder);
                if (right.Length < $.$srn.System.Numerics.BigIntegerCalculator.DivideBurnikelZieglerThreshold || ((left.Length - right.Length) | 0) < $.$srn.System.Numerics.BigIntegerCalculator.DivideBurnikelZieglerThreshold)
                {
                    left.CopyTo(remainder);
                    $.$srn.System.Numerics.BigIntegerCalculator.DivideGrammarSchool(remainder, right, new ($.$spc.System.Span$$($.$spc.System.UInt32))());
                }
                else 
                {
                    /*int*/ let quotientLength = ((((left.Length - right.Length) | 0) + 1) | 0);
                    /*uint[]?*/ let quotientFromPool = null;
                    /*Span<uint>*/ let quotient = (quotientLength <= $.$srn.System.Numerics.BigIntegerCalculator.StackAllocThreshold ? $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.StackAllocSpan($.$spc.System.UInt32, $.$srn.System.Numerics.BigIntegerCalculator.StackAllocThreshold, null) : $.$spc.System.Span$$($.$spc.System.UInt32).op_Implicit(quotientFromPool = $.$spc.System.Buffers.ArrayPool$$($.$spc.System.UInt32).Shared.Rent(quotientLength))).Slice$1(0, quotientLength);
                    $.$srn.System.Numerics.BigIntegerCalculator.DivideBurnikelZiegler(left, right, quotient, remainder);
                    if (quotientFromPool !== null)
                    {
                        $.$spc.System.Buffers.ArrayPool$$($.$spc.System.UInt32).Shared.Return(quotientFromPool, false);
                    }
                }
            }
            static /*void */ DivRem(/*Span<uint>*/ left, /*ReadOnlySpan<uint>*/ right, /*Span<uint>*/ quotient)
            {
                $.$spc.System.Diagnostics.Debug.Assert$1(left.Length >= 1, "left.Length >= 1");
                $.$spc.System.Diagnostics.Debug.Assert$1(right.Length >= 1, "right.Length >= 1");
                $.$spc.System.Diagnostics.Debug.Assert$1(left.Length >= right.Length, "left.Length >= right.Length");
                $.$spc.System.Diagnostics.Debug.Assert$1(quotient.Length === ((((left.Length - right.Length) | 0) + 1) | 0) || quotient.Length === 0, "quotient.Length == left.Length - right.Length + 1\r\n                || quotient.Length == 0");
                $.$srn.System.Numerics.BigIntegerCalculator.InitializeForDebug(quotient);
                if (right.Length < $.$srn.System.Numerics.BigIntegerCalculator.DivideBurnikelZieglerThreshold || ((left.Length - right.Length) | 0) < $.$srn.System.Numerics.BigIntegerCalculator.DivideBurnikelZieglerThreshold)
                {
                    $.$srn.System.Numerics.BigIntegerCalculator.DivideGrammarSchool(left, right, quotient);
                }
                else 
                {
                    /*uint[]?*/ let leftCopyFromPool = null;
                    /*Span<uint>*/ let leftCopy = (left.Length <= $.$srn.System.Numerics.BigIntegerCalculator.StackAllocThreshold ? $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.StackAllocSpan($.$spc.System.UInt32, $.$srn.System.Numerics.BigIntegerCalculator.StackAllocThreshold, null) : $.$spc.System.Span$$($.$spc.System.UInt32).op_Implicit(leftCopyFromPool = $.$spc.System.Buffers.ArrayPool$$($.$spc.System.UInt32).Shared.Rent(left.Length))).Slice$1(0, left.Length);
                    left.CopyTo(leftCopy);
                    /*uint[]?*/ let quotientActualFromPool = null;
                    /*scoped Span<uint>*/ let quotientActual;
                    if (quotient.Length === 0)
                    {
                        /*int*/ let quotientLength = ((((left.Length - right.Length) | 0) + 1) | 0);
                        quotientActual = (quotientLength <= $.$srn.System.Numerics.BigIntegerCalculator.StackAllocThreshold ? $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.StackAllocSpan($.$spc.System.UInt32, $.$srn.System.Numerics.BigIntegerCalculator.StackAllocThreshold, null) : $.$spc.System.Span$$($.$spc.System.UInt32).op_Implicit(quotientActualFromPool = $.$spc.System.Buffers.ArrayPool$$($.$spc.System.UInt32).Shared.Rent(quotientLength))).Slice$1(0, quotientLength);
                    }
                    else 
                    {
                        quotientActual = quotient;
                    }
                    $.$srn.System.Numerics.BigIntegerCalculator.DivideBurnikelZiegler($.$spc.System.Span$$($.$spc.System.UInt32).op_Implicit$2(leftCopy), right, quotientActual, left);
                    if (quotientActualFromPool !== null)
                    {
                        $.$spc.System.Buffers.ArrayPool$$($.$spc.System.UInt32).Shared.Return(quotientActualFromPool, false);
                    }
                    if (leftCopyFromPool !== null)
                    {
                        $.$spc.System.Buffers.ArrayPool$$($.$spc.System.UInt32).Shared.Return(leftCopyFromPool, false);
                    }
                }
            }
            static /*void */ DivideGrammarSchool(/*Span<uint>*/ left, /*ReadOnlySpan<uint>*/ right, /*Span<uint>*/ quotient)
            {
                $.$spc.System.Diagnostics.Debug.Assert$1(left.Length >= 1, "left.Length >= 1");
                $.$spc.System.Diagnostics.Debug.Assert$1(right.Length >= 1, "right.Length >= 1");
                $.$spc.System.Diagnostics.Debug.Assert$1(left.Length >= right.Length, "left.Length >= right.Length");
                $.$spc.System.Diagnostics.Debug.Assert$1(quotient.Length === 0 || quotient.Length === ((((left.Length - right.Length) | 0) + 1) | 0) || ($.$srn.System.Numerics.BigIntegerCalculator.CompareActual($.$spc.System.Span$$($.$spc.System.UInt32).op_Implicit$2(left.Slice(((left.Length - right.Length) | 0))), right) < 0 && quotient.Length === ((left.Length - right.Length) | 0)), "quotient.Length == 0\r\n                || quotient.Length == left.Length - right.Length + 1\r\n                || (CompareActual(left.Slice(left.Length - right.Length), right) < 0 && quotient.Length == left.Length - right.Length)");
                /*uint*/ let divHi = right.get_Item(((right.Length - 1) | 0)).$v;
                /*uint*/ let divLo = right.Length > 1 ? right.get_Item(((right.Length - 2) | 0)).$v : 0;
                /*int*/ let shift = $.$spc.System.Numerics.BitOperations.LeadingZeroCount(divHi);
                /*int*/ let backShift = ((32 - shift) | 0);
                if (shift > 0)
                {
                    /*uint*/ let divNx = right.Length > 2 ? right.get_Item(((right.Length - 3) | 0)).$v : 0;
                    divHi = ((divHi << shift) >>> 0) | (divLo >>> backShift);
                    divLo = ((divLo << shift) >>> 0) | (divNx >>> backShift);
                }
                for(/*int*/ let i = left.Length; i >= right.Length; i--)
                {
                    /*int*/ let n = ((i - right.Length) | 0);
                    /*uint*/ let t = (i >>> 0) < (left.Length >>> 0) ? left.get_Item(i).$v : 0;
                    /*ulong*/ let valHi = (BigInt.asUintN(64, $.$cast(t, $.$spc.System.UInt64) << 32n)) | BigInt(left.get_Item(((i - 1) | 0)).$v);
                    /*uint*/ let valLo = i > 1 ? left.get_Item(((i - 2) | 0)).$v : 0;
                    if (shift > 0)
                    {
                        /*uint*/ let valNx = i > 2 ? left.get_Item(((i - 3) | 0)).$v : 0;
                        valHi = (BigInt.asUintN(64, valHi << BigInt(shift))) | (BigInt(valLo >>> backShift));
                        valLo = ((valLo << shift) >>> 0) | (valNx >>> backShift);
                    }
                    /*ulong*/ let digit = valHi / BigInt(divHi);
                    if (digit > 4294967295n)
                    {
                        digit = 4294967295n;
                    }
                    while($.$srn.System.Numerics.BigIntegerCalculator.DivideGuessTooBig(digit, valHi, valLo, divHi, divLo))
                    {
                        --digit;
                    }
                    if (digit > 0n)
                    {
                        /*uint*/ let carry = $.$srn.System.Numerics.BigIntegerCalculator.SubtractDivisor(left.Slice(n), right, digit);
                        if (carry !== t)
                        {
                            $.$spc.System.Diagnostics.Debug.Assert$1(carry == (((t + 1) >>> 0) >>> 0), "carry == t + 1");
                            carry = $.$srn.System.Numerics.BigIntegerCalculator.AddDivisor(left.Slice(n), right);
                            --digit;
                            $.$spc.System.Diagnostics.Debug.Assert$1(carry === 1, "carry == 1");
                        }
                    }
                    if ((n >>> 0) < (quotient.Length >>> 0))
                    {
                        quotient.get_Item(n).$v = $.$cast(digit, $.$spc.System.UInt32);
                    }
                    if ((i >>> 0) < (left.Length >>> 0))
                    {
                        left.get_Item(i).$v = 0;
                    }
                }
            }
            static /*uint */ AddDivisor(/*Span<uint>*/ left, /*ReadOnlySpan<uint>*/ right)
            {
                $.$spc.System.Diagnostics.Debug.Assert$1(left.Length >= right.Length, "left.Length >= right.Length");
                /*ulong*/ let carry = 0n;
                for(/*int*/ let i = 0; i < right.Length; i++)
                {
                    /*ref uint*/ let leftElement = left.get_Item(i);
                    /*ulong*/ let digit = (BigInt(leftElement.$v) + carry) + BigInt(right.get_Item(i).$v);
                    leftElement.$v = $.$cast(digit, $.$spc.System.UInt32);
                    carry = digit >> 32n;
                }
                return $.$cast(carry, $.$spc.System.UInt32);
            }
            static /*uint */ SubtractDivisor(/*Span<uint>*/ left, /*ReadOnlySpan<uint>*/ right, /*ulong*/ q)
            {
                $.$spc.System.Diagnostics.Debug.Assert$1(left.Length >= right.Length, "left.Length >= right.Length");
                $.$spc.System.Diagnostics.Debug.Assert$1(q <= 4294967295n, "q <= 0xFFFFFFFF");
                /*ulong*/ let carry = 0n;
                for(/*int*/ let i = 0; i < right.Length; i++)
                {
                    carry += BigInt(right.get_Item(i).$v) * q;
                    /*uint*/ let digit = $.$cast(carry, $.$spc.System.UInt32);
                    carry >>= 32n;
                    /*ref uint*/ let leftElement = left.get_Item(i);
                    if (leftElement.$v < digit)
                    {
                        ++carry;
                    }
                    leftElement.$v -= digit;
                }
                return $.$cast(carry, $.$spc.System.UInt32);
            }
            static /*bool */ DivideGuessTooBig(/*ulong*/ q, /*ulong*/ valHi, /*uint*/ valLo, /*uint*/ divHi, /*uint*/ divLo)
            {
                $.$spc.System.Diagnostics.Debug.Assert$1(q <= 4294967295n, "q <= 0xFFFFFFFF");
                /*ulong*/ let chkHi = BigInt(divHi) * q;
                /*ulong*/ let chkLo = BigInt(divLo) * q;
                chkHi += (chkLo >> 32n);
                /*uint*/ let chkLoUInt32 = $.$cast((chkLo), $.$spc.System.UInt32);
                return (chkHi > valHi) || ((chkHi === valHi) && (chkLoUInt32 > valLo));
            }
            static /*void */ DivideBurnikelZiegler(/*ReadOnlySpan<uint>*/ left, /*ReadOnlySpan<uint>*/ right, /*Span<uint>*/ quotient, /*Span<uint>*/ remainder)
            {
                $.$spc.System.Diagnostics.Debug.Assert$1(left.Length >= 1, "left.Length >= 1");
                $.$spc.System.Diagnostics.Debug.Assert$1(right.Length >= 1, "right.Length >= 1");
                $.$spc.System.Diagnostics.Debug.Assert$1(left.Length >= right.Length, "left.Length >= right.Length");
                $.$spc.System.Diagnostics.Debug.Assert$1(quotient.Length === ((((left.Length - right.Length) | 0) + 1) | 0), "quotient.Length == left.Length - right.Length + 1");
                $.$spc.System.Diagnostics.Debug.Assert$1(remainder.Length === left.Length || remainder.Length === 0, "remainder.Length == left.Length\r\n                        || remainder.Length == 0");
                /*int*/ let n;
                {
                    /*int*/ let m = ($.$spc.System.Numerics.BitOperations.RoundUpToPowerOf2((($.trunc((right.Length >>> 0) / ($.$srn.System.Numerics.BigIntegerCalculator.DivideBurnikelZieglerThreshold >>> 0)) + 1) >>> 0)) | 0);
                    /*int*/ let j = $.trunc((((((right.Length + m) | 0) - 1) | 0)) / m);
                    n = ((j * m) | 0);
                }
                /*int*/ let sigmaDigit = ((n - right.Length) | 0);
                /*int*/ let sigmaSmall = $.$spc.System.Numerics.BitOperations.LeadingZeroCount(right.get_Item(right.Length - 1).$v);
                /*uint[]?*/ let bFromPool = null;
                /*Span<uint>*/ let b = (n <= $.$srn.System.Numerics.BigIntegerCalculator.StackAllocThreshold ? $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.StackAllocSpan($.$spc.System.UInt32, $.$srn.System.Numerics.BigIntegerCalculator.StackAllocThreshold, null) : $.$spc.System.Span$$($.$spc.System.UInt32).op_Implicit(bFromPool = $.$spc.System.Buffers.ArrayPool$$($.$spc.System.UInt32).Shared.Rent(n))).Slice$1(0, n);
                /*int*/ let aLength = ((left.Length + sigmaDigit) | 0);
                if ($.$spc.System.Numerics.BitOperations.LeadingZeroCount(left.get_Item(left.Length - 1).$v) <= sigmaSmall)
                {
                    ++aLength;
                }
                /*uint[]?*/ let aFromPool = null;
                /*Span<uint>*/ let a = (aLength <= $.$srn.System.Numerics.BigIntegerCalculator.StackAllocThreshold ? $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.StackAllocSpan($.$spc.System.UInt32, $.$srn.System.Numerics.BigIntegerCalculator.StackAllocThreshold, null) : $.$spc.System.Span$$($.$spc.System.UInt32).op_Implicit(aFromPool = $.$spc.System.Buffers.ArrayPool$$($.$spc.System.UInt32).Shared.Rent(aLength))).Slice$1(0, aLength);
                /*static void*/  function Normalize(/*ReadOnlySpan<uint>*/ src, /*int*/ sigmaDigit, /*int*/ sigmaSmall, /*Span<uint>*/ bits)
                {
                    $.$spc.System.Diagnostics.Debug.Assert$1((sigmaSmall >>> 0) <= 32, "(uint)sigmaSmall <= 32");
                    $.$spc.System.Diagnostics.Debug.Assert$1(((src.Length + sigmaDigit) | 0) <= bits.Length, "src.Length + sigmaDigit <= bits.Length");
                    bits.Slice$1(0, sigmaDigit).Clear();
                    /*Span<uint>*/ let dst = bits.Slice(sigmaDigit);
                    src.CopyTo(dst);
                    dst.Slice(src.Length).Clear();
                    if (sigmaSmall !== 0)
                    {
                        /*int*/ let carryShift = ((32 - sigmaSmall) | 0);
                        /*uint*/ let carry = 0;
                        for(/*int*/ let i = 0; i < bits.Length; i++)
                        {
                            /*uint*/ let carryTmp = bits.get_Item(i).$v >>> carryShift;
                            bits.get_Item(i).$v = (bits.get_Item(i).$v << sigmaSmall) >>> 0 | carry;
                            carry = carryTmp;
                        }
                        $.$spc.System.Diagnostics.Debug.Assert$1(carry === 0, "carry == 0");
                    }
                }
                Normalize(left, sigmaDigit, sigmaSmall, a);
                Normalize(right, sigmaDigit, sigmaSmall, b);
                /*int*/ let t = $.$spc.System.Math.Max$4(2, $.trunc((((((a.Length + n) | 0) - 1) | 0)) / n));
                $.$spc.System.Diagnostics.Debug.Assert$1(t < a.Length || (t === a.Length && (a.get_Item(a.Length - 1).$v | 0) >= 0), "t < a.Length || (t == a.Length && (int)a[^1] >= 0)");
                /*uint[]?*/ let rFromPool = null;
                /*Span<uint>*/ let r = ((((n + 1) | 0)) <= $.$srn.System.Numerics.BigIntegerCalculator.StackAllocThreshold ? $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.StackAllocSpan($.$spc.System.UInt32, $.$srn.System.Numerics.BigIntegerCalculator.StackAllocThreshold, null) : $.$spc.System.Span$$($.$spc.System.UInt32).op_Implicit(rFromPool = $.$spc.System.Buffers.ArrayPool$$($.$spc.System.UInt32).Shared.Rent(((n + 1) | 0)))).Slice$1(0, ((n + 1) | 0));
                /*uint[]?*/ let zFromPool = null;
                /*Span<uint>*/ let z = (((2 * n) | 0) <= $.$srn.System.Numerics.BigIntegerCalculator.StackAllocThreshold ? $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.StackAllocSpan($.$spc.System.UInt32, $.$srn.System.Numerics.BigIntegerCalculator.StackAllocThreshold, null) : $.$spc.System.Span$$($.$spc.System.UInt32).op_Implicit(zFromPool = $.$spc.System.Buffers.ArrayPool$$($.$spc.System.UInt32).Shared.Rent(((2 * n) | 0)))).Slice$1(0, ((2 * n) | 0));
                a.Slice((((((t - 2) | 0)) * n) | 0)).CopyTo(z);
                z.Slice(((a.Length - (((((t - 2) | 0)) * n) | 0)) | 0)).Clear();
                /*Span<uint>*/ let quotientUpper = quotient.Slice((((((t - 2) | 0)) * n) | 0));
                if (quotientUpper.Length < n)
                {
                    /*uint[]?*/ let qFromPool = null;
                    /*Span<uint>*/ let q = (n <= $.$srn.System.Numerics.BigIntegerCalculator.StackAllocThreshold ? $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.StackAllocSpan($.$spc.System.UInt32, $.$srn.System.Numerics.BigIntegerCalculator.StackAllocThreshold, null) : $.$spc.System.Span$$($.$spc.System.UInt32).op_Implicit(qFromPool = $.$spc.System.Buffers.ArrayPool$$($.$spc.System.UInt32).Shared.Rent(n))).Slice$1(0, n);
                    $.$srn.System.Numerics.BigIntegerCalculator.BurnikelZieglerD2n1n($.$spc.System.Span$$($.$spc.System.UInt32).op_Implicit$2(z), $.$spc.System.Span$$($.$spc.System.UInt32).op_Implicit$2(b), q, r);
                    $.$spc.System.Diagnostics.Debug.Assert$1(!$.$spc.System.MemoryExtensions.ContainsAnyExcept$5($.$spc.System.UInt32, $.$spc.System.Span$$($.$spc.System.UInt32).op_Implicit$2(q.Slice(quotientUpper.Length)), 0), "!q.Slice(quotientUpper.Length).ContainsAnyExcept(0u)");
                    q.Slice$1(0, quotientUpper.Length).CopyTo(quotientUpper);
                    if (qFromPool !== null)
                    {
                        $.$spc.System.Buffers.ArrayPool$$($.$spc.System.UInt32).Shared.Return(qFromPool, false);
                    }
                }
                else 
                {
                    $.$srn.System.Numerics.BigIntegerCalculator.BurnikelZieglerD2n1n($.$spc.System.Span$$($.$spc.System.UInt32).op_Implicit$2(z), $.$spc.System.Span$$($.$spc.System.UInt32).op_Implicit$2(b), quotientUpper.Slice$1(0, n), r);
                    quotientUpper.Slice(n).Clear();
                }
                for(/*int*/ let i = ((t - 3) | 0); i >= 0; i--)
                {
                    a.Slice$1(((i * n) | 0), n).CopyTo(z);
                    r.Slice$1(0, n).CopyTo(z.Slice(n));
                    $.$srn.System.Numerics.BigIntegerCalculator.BurnikelZieglerD2n1n($.$spc.System.Span$$($.$spc.System.UInt32).op_Implicit$2(z), $.$spc.System.Span$$($.$spc.System.UInt32).op_Implicit$2(b), quotient.Slice$1(((i * n) | 0), n), r);
                }
                if (zFromPool !== null)
                {
                    $.$spc.System.Buffers.ArrayPool$$($.$spc.System.UInt32).Shared.Return(zFromPool, false);
                }
                if (bFromPool !== null)
                {
                    $.$spc.System.Buffers.ArrayPool$$($.$spc.System.UInt32).Shared.Return(bFromPool, false);
                }
                if (aFromPool !== null)
                {
                    $.$spc.System.Buffers.ArrayPool$$($.$spc.System.UInt32).Shared.Return(aFromPool, false);
                }
                $.$spc.System.Diagnostics.Debug.Assert$1(r.get_Item(r.Length - 1).$v === 0, "r[^1] == 0");
                $.$spc.System.Diagnostics.Debug.Assert$1(!$.$spc.System.MemoryExtensions.ContainsAnyExcept$5($.$spc.System.UInt32, $.$spc.System.Span$$($.$spc.System.UInt32).op_Implicit$2(r.Slice$1(0, sigmaDigit)), 0), "!r.Slice(0, sigmaDigit).ContainsAnyExcept(0u)");
                if (remainder.Length !== 0)
                {
                    /*Span<uint>*/ let rt = r.Slice(sigmaDigit);
                    remainder.Slice(rt.Length).Clear();
                    if (sigmaSmall !== 0)
                    {
                        $.$spc.System.Diagnostics.Debug.Assert$1((sigmaSmall >>> 0) <= 32, "(uint)sigmaSmall <= 32");
                        /*int*/ let carryShift = ((32 - sigmaSmall) | 0);
                        /*uint*/ let carry = 0;
                        for(/*int*/ let i = ((rt.Length - 1) | 0); i >= 0; i--)
                        {
                            remainder.get_Item(i).$v = rt.get_Item(i).$v >>> sigmaSmall | carry;
                            carry = (rt.get_Item(i).$v << carryShift) >>> 0;
                        }
                        $.$spc.System.Diagnostics.Debug.Assert$1(carry === 0, "carry == 0");
                    }
                    else 
                    {
                        rt.CopyTo(remainder);
                    }
                }
                if (rFromPool !== null)
                {
                    $.$spc.System.Buffers.ArrayPool$$($.$spc.System.UInt32).Shared.Return(rFromPool, false);
                }
            }
            static /*void */ BurnikelZieglerFallback(/*ReadOnlySpan<uint>*/ left, /*ReadOnlySpan<uint>*/ right, /*Span<uint>*/ quotient, /*Span<uint>*/ remainder)
            {
                $.$spc.System.Diagnostics.Debug.Assert$1(left.Length === ((2 * right.Length) | 0), "left.Length == 2 * right.Length");
                $.$spc.System.Diagnostics.Debug.Assert$1($.$srn.System.Numerics.BigIntegerCalculator.CompareActual(left.Slice(right.Length), right) < 0, "CompareActual(left.Slice(right.Length), right) < 0");
                $.$spc.System.Diagnostics.Debug.Assert$1(quotient.Length === right.Length, "quotient.Length == right.Length");
                $.$spc.System.Diagnostics.Debug.Assert$1(remainder.Length >= ((right.Length + 1) | 0), "remainder.Length >= right.Length + 1");
                $.$spc.System.Diagnostics.Debug.Assert$1(right.get_Item(right.Length - 1).$v > 0, "right[^1] > 0");
                $.$spc.System.Diagnostics.Debug.Assert$1(right.Length < $.$srn.System.Numerics.BigIntegerCalculator.DivideBurnikelZieglerThreshold, "right.Length < DivideBurnikelZieglerThreshold");
                left = left.Slice$1(0, $.$srn.System.Numerics.BigIntegerCalculator.ActualLength(left));
                if (left.Length < right.Length)
                {
                    quotient.Clear();
                    left.CopyTo(remainder);
                    remainder.Slice(left.Length).Clear();
                }
                else if (right.Length === 1)
                {
                    /*ulong*/ let carry;
                    if (quotient.Length < left.Length)
                    {
                        $.$spc.System.Diagnostics.Debug.Assert$1(((quotient.Length + 1) | 0) === left.Length, "quotient.Length + 1 == left.Length");
                        $.$spc.System.Diagnostics.Debug.Assert$1(left.get_Item(left.Length - 1).$v < right.get_Item(0).$v, "left[^1] < right[0]");
                        carry = BigInt(left.get_Item(left.Length - 1).$v);
                        $.$srn.System.Numerics.BigIntegerCalculator.Divide$2(left.Slice$1(0, quotient.Length), right.get_Item(0).$v, quotient, $.$ref(() => carry, ($v) => carry = $v, $.$spc.System.UInt64));
                    }
                    else 
                    {
                        carry = 0n;
                        quotient.Slice(left.Length).Clear();
                        $.$srn.System.Numerics.BigIntegerCalculator.Divide$2(left, right.get_Item(0).$v, quotient, $.$ref(() => carry, ($v) => carry = $v, $.$spc.System.UInt64));
                    }
                    if (remainder.Length !== 0)
                    {
                        remainder.Slice(1).Clear();
                        remainder.get_Item(0).$v = $.$cast(carry, $.$spc.System.UInt32);
                    }
                }
                else 
                {
                    /*uint[]?*/ let r1FromPool = null;
                    /*Span<uint>*/ let r1 = (left.Length <= $.$srn.System.Numerics.BigIntegerCalculator.StackAllocThreshold ? $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.StackAllocSpan($.$spc.System.UInt32, $.$srn.System.Numerics.BigIntegerCalculator.StackAllocThreshold, null) : $.$spc.System.Span$$($.$spc.System.UInt32).op_Implicit(r1FromPool = $.$spc.System.Buffers.ArrayPool$$($.$spc.System.UInt32).Shared.Rent(left.Length))).Slice$1(0, left.Length);
                    left.CopyTo(r1);
                    /*int*/ let quotientLength = $.$spc.System.Math.Min$4(((((left.Length - right.Length) | 0) + 1) | 0), quotient.Length);
                    quotient.Slice(quotientLength).Clear();
                    $.$srn.System.Numerics.BigIntegerCalculator.DivideGrammarSchool(r1, right, quotient.Slice$1(0, quotientLength));
                    if (r1.Length < remainder.Length)
                    {
                        remainder.Slice(r1.Length).Clear();
                        r1.CopyTo(remainder);
                    }
                    else 
                    {
                        $.$spc.System.Diagnostics.Debug.Assert$1(!$.$spc.System.MemoryExtensions.ContainsAnyExcept$5($.$spc.System.UInt32, $.$spc.System.Span$$($.$spc.System.UInt32).op_Implicit$2(r1.Slice(remainder.Length)), 0), "!r1.Slice(remainder.Length).ContainsAnyExcept(0u)");
                        r1.Slice$1(0, remainder.Length).CopyTo(remainder);
                    }
                    if (r1FromPool !== null)
                    {
                        $.$spc.System.Buffers.ArrayPool$$($.$spc.System.UInt32).Shared.Return(r1FromPool, false);
                    }
                }
            }
            static /*void */ BurnikelZieglerD2n1n(/*ReadOnlySpan<uint>*/ left, /*ReadOnlySpan<uint>*/ right, /*Span<uint>*/ quotient, /*Span<uint>*/ remainder)
            {
                $.$spc.System.Diagnostics.Debug.Assert$1(left.Length === ((2 * right.Length) | 0), "left.Length == 2 * right.Length");
                $.$spc.System.Diagnostics.Debug.Assert$1($.$srn.System.Numerics.BigIntegerCalculator.CompareActual(left.Slice(right.Length), right) < 0, "CompareActual(left.Slice(right.Length), right) < 0");
                $.$spc.System.Diagnostics.Debug.Assert$1(quotient.Length === right.Length, "quotient.Length == right.Length");
                $.$spc.System.Diagnostics.Debug.Assert$1(remainder.Length >= ((right.Length + 1) | 0), "remainder.Length >= right.Length + 1");
                $.$spc.System.Diagnostics.Debug.Assert$1(right.get_Item(right.Length - 1).$v > 0, "right[^1] > 0");
                if ((right.Length & 1) !== 0 || right.Length < $.$srn.System.Numerics.BigIntegerCalculator.DivideBurnikelZieglerThreshold)
                {
                    $.$srn.System.Numerics.BigIntegerCalculator.BurnikelZieglerFallback(left, right, quotient, remainder);
                    return;
                }
                /*int*/ let halfN = right.Length >> 1;
                /*uint[]?*/ let r1FromPool = null;
                /*Span<uint>*/ let r1 = ((((right.Length + 1) | 0)) <= $.$srn.System.Numerics.BigIntegerCalculator.StackAllocThreshold ? $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.StackAllocSpan($.$spc.System.UInt32, $.$srn.System.Numerics.BigIntegerCalculator.StackAllocThreshold, null) : $.$spc.System.Span$$($.$spc.System.UInt32).op_Implicit(r1FromPool = $.$spc.System.Buffers.ArrayPool$$($.$spc.System.UInt32).Shared.Rent(((right.Length + 1) | 0)))).Slice$1(0, ((right.Length + 1) | 0));
                $.$srn.System.Numerics.BigIntegerCalculator.BurnikelZieglerD3n2n(left.Slice(right.Length), left.Slice$1(halfN, halfN), right, quotient.Slice(halfN), r1);
                $.$srn.System.Numerics.BigIntegerCalculator.BurnikelZieglerD3n2n($.$spc.System.Span$$($.$spc.System.UInt32).op_Implicit$2(r1.Slice$1(0, right.Length)), left.Slice$1(0, halfN), right, quotient.Slice$1(0, halfN), remainder);
                if (r1FromPool !== null)
                {
                    $.$spc.System.Buffers.ArrayPool$$($.$spc.System.UInt32).Shared.Return(r1FromPool, false);
                }
            }
            static /*void */ BurnikelZieglerD3n2n(/*ReadOnlySpan<uint>*/ left12, /*ReadOnlySpan<uint>*/ left3, /*ReadOnlySpan<uint>*/ right, /*Span<uint>*/ quotient, /*Span<uint>*/ remainder)
            {
                $.$spc.System.Diagnostics.Debug.Assert$1(right.Length % 2 === 0, "right.Length % 2 == 0");
                $.$spc.System.Diagnostics.Debug.Assert$1(left12.Length === right.Length, "left12.Length == right.Length");
                $.$spc.System.Diagnostics.Debug.Assert$1(((2 * left3.Length) | 0) === right.Length, "2 * left3.Length == right.Length");
                $.$spc.System.Diagnostics.Debug.Assert$1(((2 * quotient.Length) | 0) === right.Length, "2 * quotient.Length == right.Length");
                $.$spc.System.Diagnostics.Debug.Assert$1(remainder.Length >= ((right.Length + 1) | 0), "remainder.Length >= right.Length + 1");
                $.$spc.System.Diagnostics.Debug.Assert$1(right.get_Item(right.Length - 1).$v > 0, "right[^1] > 0");
                $.$spc.System.Diagnostics.Debug.Assert$1($.$srn.System.Numerics.BigIntegerCalculator.CompareActual(left12, right) < 0, "CompareActual(left12, right) < 0");
                /*int*/ let n = right.Length >> 1;
                /*ReadOnlySpan<uint>*/ let a1 = left12.Slice(n);
                /*ReadOnlySpan<uint>*/ let b1 = right.Slice(n);
                /*ReadOnlySpan<uint>*/ let b2 = right.Slice$1(0, n);
                /*Span<uint>*/ let r1 = remainder.Slice(n);
                /*uint[]?*/ let dFromPool = null;
                /*Span<uint>*/ let d = (right.Length <= $.$srn.System.Numerics.BigIntegerCalculator.StackAllocThreshold ? $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.StackAllocSpan($.$spc.System.UInt32, $.$srn.System.Numerics.BigIntegerCalculator.StackAllocThreshold, null) : $.$spc.System.Span$$($.$spc.System.UInt32).op_Implicit(dFromPool = $.$spc.System.Buffers.ArrayPool$$($.$spc.System.UInt32).Shared.Rent(right.Length))).Slice$1(0, right.Length);
                if ($.$srn.System.Numerics.BigIntegerCalculator.CompareActual(a1, b1) < 0)
                {
                    $.$srn.System.Numerics.BigIntegerCalculator.BurnikelZieglerD2n1n(left12, b1, quotient, r1);
                    d.Clear();
                    MultiplyActual($.$spc.System.Span$$($.$spc.System.UInt32).op_Implicit$2(quotient), b2, d);
                }
                else 
                {
                    $.$spc.System.Diagnostics.Debug.Assert$1($.$srn.System.Numerics.BigIntegerCalculator.CompareActual(a1, b1) === 0, "CompareActual(a1, b1) == 0");
                    quotient.Fill(4294967295/*uint.MaxValue*/);
                    /*ReadOnlySpan<uint>*/ let a2 = left12.Slice$1(0, n);
                    $.$srn.System.Numerics.BigIntegerCalculator.Add$1(a2, b1, r1);
                    d.Slice$1(0, n).Clear();
                    b2.CopyTo(d.Slice(n));
                    $.$srn.System.Numerics.BigIntegerCalculator.SubtractSelf(d, b2);
                }
                left3.CopyTo(remainder.Slice$1(0, n));
                /*Span<uint>*/ let rr = remainder.Slice$1(0, ((d.Length + 1) | 0));
                while($.$srn.System.Numerics.BigIntegerCalculator.CompareActual($.$spc.System.Span$$($.$spc.System.UInt32).op_Implicit$2(rr), $.$spc.System.Span$$($.$spc.System.UInt32).op_Implicit$2(d)) < 0)
                {
                    $.$srn.System.Numerics.BigIntegerCalculator.AddSelf(rr, right);
                    /*int*/ let qi = -1;
                    while(quotient.get_Item(++qi).$v === 0)
                    {
                    }
                    $.$spc.System.Diagnostics.Debug.Assert$1((qi >>> 0) < (quotient.Length >>> 0), "(uint)qi < (uint)quotient.Length");
                    --quotient.get_Item(qi).$v;
                    quotient.Slice$1(0, qi).Fill(4294967295/*uint.MaxValue*/);
                }
                $.$srn.System.Numerics.BigIntegerCalculator.SubtractSelf(rr, $.$spc.System.Span$$($.$spc.System.UInt32).op_Implicit$2(d));
                if (dFromPool !== null)
                {
                    $.$spc.System.Buffers.ArrayPool$$($.$spc.System.UInt32).Shared.Return(dFromPool, false);
                }
                /*static void*/  function MultiplyActual(/*ReadOnlySpan<uint>*/ left, /*ReadOnlySpan<uint>*/ right, /*Span<uint>*/ bits)
                {
                    $.$spc.System.Diagnostics.Debug.Assert$1(bits.Length === ((left.Length + right.Length) | 0), "bits.Length == left.Length + right.Length");
                    left = left.Slice$1(0, $.$srn.System.Numerics.BigIntegerCalculator.ActualLength(left));
                    right = right.Slice$1(0, $.$srn.System.Numerics.BigIntegerCalculator.ActualLength(right));
                    bits = bits.Slice$1(0, ((left.Length + right.Length) | 0));
                    if (left.Length < right.Length)
                    {
                        $.$srn.System.Numerics.BigIntegerCalculator.Multiply$1(right, left, bits);
                    }
                    else 
                    {
                        $.$srn.System.Numerics.BigIntegerCalculator.Multiply$1(left, right, bits);
                    }
                }
            }
            static /*void */ Pow(/*uint*/ value, /*uint*/ power, /*Span<uint>*/ bits)
            {
                $.$srn.System.Numerics.BigIntegerCalculator.Pow$1(value !== 0 ? new ($.$spc.System.ReadOnlySpan$$($.$spc.System.UInt32))().$ctor$5($.$ref(() => value, undefined, $.$spc.System.UInt32)) : new ($.$spc.System.ReadOnlySpan$$($.$spc.System.UInt32))(), power, bits);
            }
            static /*void */ Pow$1(/*ReadOnlySpan<uint>*/ value, /*uint*/ power, /*Span<uint>*/ bits)
            {
                $.$spc.System.Diagnostics.Debug.Assert$1(bits.Length === $.$srn.System.Numerics.BigIntegerCalculator.PowBound(power, value.Length), "bits.Length == PowBound(power, value.Length)");
                /*uint[]?*/ let tempFromPool = null;
                /*Span<uint>*/ let temp = (bits.Length <= $.$srn.System.Numerics.BigIntegerCalculator.StackAllocThreshold ? $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.StackAllocSpan($.$spc.System.UInt32, $.$srn.System.Numerics.BigIntegerCalculator.StackAllocThreshold, null) : $.$spc.System.Span$$($.$spc.System.UInt32).op_Implicit(tempFromPool = $.$spc.System.Buffers.ArrayPool$$($.$spc.System.UInt32).Shared.Rent(bits.Length))).Slice$1(0, bits.Length);
                temp.Clear();
                /*uint[]?*/ let valueCopyFromPool = null;
                /*Span<uint>*/ let valueCopy = (bits.Length <= $.$srn.System.Numerics.BigIntegerCalculator.StackAllocThreshold ? $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.StackAllocSpan($.$spc.System.UInt32, $.$srn.System.Numerics.BigIntegerCalculator.StackAllocThreshold, null) : $.$spc.System.Span$$($.$spc.System.UInt32).op_Implicit(valueCopyFromPool = $.$spc.System.Buffers.ArrayPool$$($.$spc.System.UInt32).Shared.Rent(bits.Length))).Slice$1(0, bits.Length);
                value.CopyTo(valueCopy);
                valueCopy.Slice(value.Length).Clear();
                /*Span<uint>*/ let result = $.$srn.System.Numerics.BigIntegerCalculator.PowCore(valueCopy, value.Length, temp, power, bits);
                result.CopyTo(bits);
                bits.Slice(result.Length).Clear();
                if (tempFromPool !== null)
                {
                    $.$spc.System.Buffers.ArrayPool$$($.$spc.System.UInt32).Shared.Return(tempFromPool, false);
                }
                if (valueCopyFromPool !== null)
                {
                    $.$spc.System.Buffers.ArrayPool$$($.$spc.System.UInt32).Shared.Return(valueCopyFromPool, false);
                }
            }
            static /*Span<uint> */ PowCore(/*Span<uint>*/ value, /*int*/ valueLength, /*Span<uint>*/ temp, /*uint*/ power, /*Span<uint>*/ result)
            {
                $.$spc.System.Diagnostics.Debug.Assert$1(value.Length >= valueLength, "value.Length >= valueLength");
                $.$spc.System.Diagnostics.Debug.Assert$1(temp.Length === result.Length, "temp.Length == result.Length");
                $.$spc.System.Diagnostics.Debug.Assert$1(value.Length === temp.Length, "value.Length == temp.Length");
                result.get_Item(0).$v = 1;
                /*int*/ let resultLength = 1;
                while(power !== 0)
                {
                    if ((power & 1) === 1)
                    {
                        resultLength = $.$srn.System.Numerics.BigIntegerCalculator.MultiplySelf($.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateObjectReferenceT($.$spc.System.Span$$($.$spc.System.UInt32), () => result, ($v) => result = $v, null), resultLength, $.$spc.System.Span$$($.$spc.System.UInt32).op_Implicit$2(value.Slice$1(0, valueLength)), $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateObjectReferenceT($.$spc.System.Span$$($.$spc.System.UInt32), () => temp, ($v) => temp = $v, null));
                    }
                    if (power !== 1)
                    {
                        valueLength = $.$srn.System.Numerics.BigIntegerCalculator.SquareSelf($.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateObjectReferenceT($.$spc.System.Span$$($.$spc.System.UInt32), () => value, ($v) => value = $v, null), valueLength, $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateObjectReferenceT($.$spc.System.Span$$($.$spc.System.UInt32), () => temp, ($v) => temp = $v, null));
                    }
                    power >>= 1;
                }
                return result.Slice$1(0, resultLength);
            }
            static /*int */ MultiplySelf(/*ref Span<uint>*/ left, /*int*/ leftLength, /*ReadOnlySpan<uint>*/ right, /*ref Span<uint>*/ temp)
            {
                $.$spc.System.Diagnostics.Debug.Assert$1(leftLength <= left.$v.Length, "leftLength <= left.Length");
                /*int*/ let resultLength = ((leftLength + right.Length) | 0);
                if (leftLength >= right.Length)
                {
                    $.$srn.System.Numerics.BigIntegerCalculator.Multiply$1($.$spc.System.Span$$($.$spc.System.UInt32).op_Implicit$2(left.$v.Slice$1(0, leftLength)), right, temp.$v.Slice$1(0, resultLength));
                }
                else 
                {
                    $.$srn.System.Numerics.BigIntegerCalculator.Multiply$1(right, $.$spc.System.Span$$($.$spc.System.UInt32).op_Implicit$2(left.$v.Slice$1(0, leftLength)), temp.$v.Slice$1(0, resultLength));
                }
                left.$v.Clear();
                /*Span<uint>*/ let t = left.$v;
                left.$v = temp.$v;
                temp.$v = t;
                return $.$srn.System.Numerics.BigIntegerCalculator.ActualLength($.$spc.System.Span$$($.$spc.System.UInt32).op_Implicit$2(left.$v.Slice$1(0, resultLength)));
            }
            static /*int */ SquareSelf(/*ref Span<uint>*/ value, /*int*/ valueLength, /*ref Span<uint>*/ temp)
            {
                $.$spc.System.Diagnostics.Debug.Assert$1(valueLength <= value.$v.Length, "valueLength <= value.Length");
                $.$spc.System.Diagnostics.Debug.Assert$1(temp.$v.Length >= ((valueLength + valueLength) | 0), "temp.Length >= valueLength + valueLength");
                /*int*/ let resultLength = ((valueLength + valueLength) | 0);
                $.$srn.System.Numerics.BigIntegerCalculator.Square($.$spc.System.Span$$($.$spc.System.UInt32).op_Implicit$2(value.$v.Slice$1(0, valueLength)), temp.$v.Slice$1(0, resultLength));
                value.$v.Clear();
                /*Span<uint>*/ let t = value.$v;
                value.$v = temp.$v;
                temp.$v = t;
                return $.$srn.System.Numerics.BigIntegerCalculator.ActualLength($.$spc.System.Span$$($.$spc.System.UInt32).op_Implicit$2(value.$v.Slice$1(0, resultLength)));
            }
            static /*int */ PowBound(/*uint*/ power, /*int*/ valueLength)
            {
                /*int*/ let resultLength = 1;
                while(power !== 0)
                {
                    //checked
                    {
                        if ((power & 1) === 1)
                        {
                            resultLength += valueLength;
                        }
                        if (power !== 1)
                        {
                            valueLength += valueLength;
                        }
                    }
                    power >>= 1;
                }
                return resultLength;
            }
            static /*uint */ Pow$2(/*uint*/ value, /*uint*/ power, /*uint*/ modulus)
            {
                return $.$srn.System.Numerics.BigIntegerCalculator.PowCore$2(BigInt(value), power, modulus, 1n);
            }
            static /*uint */ Pow$3(/*ReadOnlySpan<uint>*/ value, /*uint*/ power, /*uint*/ modulus)
            {
                /*uint*/ let v = $.$srn.System.Numerics.BigIntegerCalculator.Remainder(value, modulus);
                return $.$srn.System.Numerics.BigIntegerCalculator.PowCore$2(BigInt(v), power, modulus, 1n);
            }
            static /*uint */ Pow$4(/*uint*/ value, /*ReadOnlySpan<uint>*/ power, /*uint*/ modulus)
            {
                return $.$srn.System.Numerics.BigIntegerCalculator.PowCore$1(BigInt(value), power, modulus, 1n);
            }
            static /*uint */ Pow$5(/*ReadOnlySpan<uint>*/ value, /*ReadOnlySpan<uint>*/ power, /*uint*/ modulus)
            {
                /*uint*/ let v = $.$srn.System.Numerics.BigIntegerCalculator.Remainder(value, modulus);
                return $.$srn.System.Numerics.BigIntegerCalculator.PowCore$1(BigInt(v), power, modulus, 1n);
            }
            static /*uint */ PowCore$1(/*ulong*/ value, /*ReadOnlySpan<uint>*/ power, /*uint*/ modulus, /*ulong*/ result)
            {
                for(/*int*/ let i = 0; i < ((power.Length - 1) | 0); i++)
                {
                    /*uint*/ let p = power.get_Item(i).$v;
                    for(/*int*/ let j = 0; j < 32; j++)
                    {
                        if ((p & 1) === 1)
                        {
                            result = (result * value) % BigInt(modulus);
                        }
                        value = (value * value) % BigInt(modulus);
                        p >>= 1;
                    }
                }
                return $.$srn.System.Numerics.BigIntegerCalculator.PowCore$2(value, power.get_Item(((power.Length - 1) | 0)).$v, modulus, result);
            }
            static /*uint */ PowCore$2(/*ulong*/ value, /*uint*/ power, /*uint*/ modulus, /*ulong*/ result)
            {
                while(power !== 0)
                {
                    if ((power & 1) === 1)
                    {
                        result = (result * value) % BigInt(modulus);
                    }
                    if (power !== 1)
                    {
                        value = (value * value) % BigInt(modulus);
                    }
                    power >>= 1;
                }
                return $.$cast((result % BigInt(modulus)), $.$spc.System.UInt32);
            }
            static /*void */ Pow$6(/*uint*/ value, /*uint*/ power, /*ReadOnlySpan<uint>*/ modulus, /*Span<uint>*/ bits)
            {
                $.$srn.System.Numerics.BigIntegerCalculator.Pow$7(value !== 0 ? new ($.$spc.System.ReadOnlySpan$$($.$spc.System.UInt32))().$ctor$5($.$ref(() => value, undefined, $.$spc.System.UInt32)) : new ($.$spc.System.ReadOnlySpan$$($.$spc.System.UInt32))(), power, modulus, bits);
            }
            static /*void */ Pow$7(/*ReadOnlySpan<uint>*/ value, /*uint*/ power, /*ReadOnlySpan<uint>*/ modulus, /*Span<uint>*/ bits)
            {
                $.$spc.System.Diagnostics.Debug.Assert$1(!modulus.IsEmpty, "!modulus.IsEmpty");
                $.$spc.System.Diagnostics.Debug.Assert$1(bits.Length === ((modulus.Length + modulus.Length) | 0), "bits.Length == modulus.Length + modulus.Length");
                /*uint[]?*/ let valueCopyFromPool = null;
                /*int*/ let size = $.$spc.System.Math.Max$4(value.Length, bits.Length);
                /*Span<uint>*/ let valueCopy = (size <= $.$srn.System.Numerics.BigIntegerCalculator.StackAllocThreshold ? $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.StackAllocSpan($.$spc.System.UInt32, $.$srn.System.Numerics.BigIntegerCalculator.StackAllocThreshold, null) : $.$spc.System.Span$$($.$spc.System.UInt32).op_Implicit(valueCopyFromPool = $.$spc.System.Buffers.ArrayPool$$($.$spc.System.UInt32).Shared.Rent(size))).Slice$1(0, size);
                valueCopy.Slice(value.Length).Clear();
                if (value.Length > modulus.Length)
                {
                    $.$srn.System.Numerics.BigIntegerCalculator.Remainder$1(value, modulus, valueCopy.Slice$1(0, value.Length));
                }
                else 
                {
                    value.CopyTo(valueCopy);
                }
                /*uint[]?*/ let tempFromPool = null;
                /*Span<uint>*/ let temp = (bits.Length <= $.$srn.System.Numerics.BigIntegerCalculator.StackAllocThreshold ? $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.StackAllocSpan($.$spc.System.UInt32, $.$srn.System.Numerics.BigIntegerCalculator.StackAllocThreshold, null) : $.$spc.System.Span$$($.$spc.System.UInt32).op_Implicit(tempFromPool = $.$spc.System.Buffers.ArrayPool$$($.$spc.System.UInt32).Shared.Rent(bits.Length))).Slice$1(0, bits.Length);
                temp.Clear();
                $.$srn.System.Numerics.BigIntegerCalculator.PowCore$4(valueCopy, $.$srn.System.Numerics.BigIntegerCalculator.ActualLength($.$spc.System.Span$$($.$spc.System.UInt32).op_Implicit$2(valueCopy)), power, modulus, temp, bits);
                if (valueCopyFromPool !== null)
                {
                    $.$spc.System.Buffers.ArrayPool$$($.$spc.System.UInt32).Shared.Return(valueCopyFromPool, false);
                }
                if (tempFromPool !== null)
                {
                    $.$spc.System.Buffers.ArrayPool$$($.$spc.System.UInt32).Shared.Return(tempFromPool, false);
                }
            }
            static /*void */ Pow$8(/*uint*/ value, /*ReadOnlySpan<uint>*/ power, /*ReadOnlySpan<uint>*/ modulus, /*Span<uint>*/ bits)
            {
                $.$srn.System.Numerics.BigIntegerCalculator.Pow$9(value !== 0 ? new ($.$spc.System.ReadOnlySpan$$($.$spc.System.UInt32))().$ctor$5($.$ref(() => value, undefined, $.$spc.System.UInt32)) : new ($.$spc.System.ReadOnlySpan$$($.$spc.System.UInt32))(), power, modulus, bits);
            }
            static /*void */ Pow$9(/*ReadOnlySpan<uint>*/ value, /*ReadOnlySpan<uint>*/ power, /*ReadOnlySpan<uint>*/ modulus, /*Span<uint>*/ bits)
            {
                $.$spc.System.Diagnostics.Debug.Assert$1(!modulus.IsEmpty, "!modulus.IsEmpty");
                $.$spc.System.Diagnostics.Debug.Assert$1(bits.Length === ((modulus.Length + modulus.Length) | 0), "bits.Length == modulus.Length + modulus.Length");
                /*int*/ let size = $.$spc.System.Math.Max$4(value.Length, bits.Length);
                /*uint[]?*/ let valueCopyFromPool = null;
                /*Span<uint>*/ let valueCopy = (size <= $.$srn.System.Numerics.BigIntegerCalculator.StackAllocThreshold ? $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.StackAllocSpan($.$spc.System.UInt32, $.$srn.System.Numerics.BigIntegerCalculator.StackAllocThreshold, null) : $.$spc.System.Span$$($.$spc.System.UInt32).op_Implicit(valueCopyFromPool = $.$spc.System.Buffers.ArrayPool$$($.$spc.System.UInt32).Shared.Rent(size))).Slice$1(0, size);
                valueCopy.Slice(value.Length).Clear();
                if (value.Length > modulus.Length)
                {
                    $.$srn.System.Numerics.BigIntegerCalculator.Remainder$1(value, modulus, valueCopy.Slice$1(0, value.Length));
                }
                else 
                {
                    value.CopyTo(valueCopy);
                }
                /*uint[]?*/ let tempFromPool = null;
                /*Span<uint>*/ let temp = (bits.Length <= $.$srn.System.Numerics.BigIntegerCalculator.StackAllocThreshold ? $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.StackAllocSpan($.$spc.System.UInt32, $.$srn.System.Numerics.BigIntegerCalculator.StackAllocThreshold, null) : $.$spc.System.Span$$($.$spc.System.UInt32).op_Implicit(tempFromPool = $.$spc.System.Buffers.ArrayPool$$($.$spc.System.UInt32).Shared.Rent(bits.Length))).Slice$1(0, bits.Length);
                temp.Clear();
                $.$srn.System.Numerics.BigIntegerCalculator.PowCore$3(valueCopy, $.$srn.System.Numerics.BigIntegerCalculator.ActualLength($.$spc.System.Span$$($.$spc.System.UInt32).op_Implicit$2(valueCopy)), power, modulus, temp, bits);
                if (valueCopyFromPool !== null)
                {
                    $.$spc.System.Buffers.ArrayPool$$($.$spc.System.UInt32).Shared.Return(valueCopyFromPool, false);
                }
                if (tempFromPool !== null)
                {
                    $.$spc.System.Buffers.ArrayPool$$($.$spc.System.UInt32).Shared.Return(tempFromPool, false);
                }
            }
            /*int*/ static ReducerThreshold = 32;
            static /*void */ PowCore$3(/*Span<uint>*/ value, /*int*/ valueLength, /*ReadOnlySpan<uint>*/ power, /*ReadOnlySpan<uint>*/ modulus, /*Span<uint>*/ temp, /*Span<uint>*/ bits)
            {
                bits.get_Item(0).$v = 1;
                if (modulus.Length < $.$srn.System.Numerics.BigIntegerCalculator.ReducerThreshold)
                {
                    /*Span<uint>*/ let result = $.$srn.System.Numerics.BigIntegerCalculator.PowCore$5(value, valueLength, power, modulus, bits, 1, temp);
                    result.CopyTo(bits);
                    bits.Slice(result.Length).Clear();
                }
                else 
                {
                    /*int*/ let size = ((((modulus.Length * 2) | 0) + 1) | 0);
                    /*uint[]?*/ let rFromPool = null;
                    /*Span<uint>*/ let r = (BigInt((size >>> 0)) <= BigInt($.$srn.System.Numerics.BigIntegerCalculator.StackAllocThreshold) ? $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.StackAllocSpan($.$spc.System.UInt32, $.$srn.System.Numerics.BigIntegerCalculator.StackAllocThreshold, null) : $.$spc.System.Span$$($.$spc.System.UInt32).op_Implicit(rFromPool = $.$spc.System.Buffers.ArrayPool$$($.$spc.System.UInt32).Shared.Rent(size))).Slice$1(0, size);
                    r.Clear();
                    size = ((((r.Length - modulus.Length) | 0) + 1) | 0);
                    /*uint[]?*/ let muFromPool = null;
                    /*Span<uint>*/ let mu = (BigInt((size >>> 0)) <= BigInt($.$srn.System.Numerics.BigIntegerCalculator.StackAllocThreshold) ? $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.StackAllocSpan($.$spc.System.UInt32, $.$srn.System.Numerics.BigIntegerCalculator.StackAllocThreshold, null) : $.$spc.System.Span$$($.$spc.System.UInt32).op_Implicit(muFromPool = $.$spc.System.Buffers.ArrayPool$$($.$spc.System.UInt32).Shared.Rent(size))).Slice$1(0, size);
                    mu.Clear();
                    size = ((((modulus.Length * 2) | 0) + 2) | 0);
                    /*uint[]?*/ let q1FromPool = null;
                    /*Span<uint>*/ let q1 = (BigInt((size >>> 0)) <= BigInt($.$srn.System.Numerics.BigIntegerCalculator.StackAllocThreshold) ? $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.StackAllocSpan($.$spc.System.UInt32, $.$srn.System.Numerics.BigIntegerCalculator.StackAllocThreshold, null) : $.$spc.System.Span$$($.$spc.System.UInt32).op_Implicit(q1FromPool = $.$spc.System.Buffers.ArrayPool$$($.$spc.System.UInt32).Shared.Rent(size))).Slice$1(0, size);
                    q1.Clear();
                    /*uint[]?*/ let q2FromPool = null;
                    /*Span<uint>*/ let q2 = (BigInt((size >>> 0)) <= BigInt($.$srn.System.Numerics.BigIntegerCalculator.StackAllocThreshold) ? $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.StackAllocSpan($.$spc.System.UInt32, $.$srn.System.Numerics.BigIntegerCalculator.StackAllocThreshold, null) : $.$spc.System.Span$$($.$spc.System.UInt32).op_Implicit(q2FromPool = $.$spc.System.Buffers.ArrayPool$$($.$spc.System.UInt32).Shared.Rent(size))).Slice$1(0, size);
                    q2.Clear();
                    /*FastReducer*/ let reducer = new $.$srn.System.Numerics.BigIntegerCalculator.FastReducer().$ctor$2(modulus, r, mu, q1, q2);
                    if (rFromPool !== null)
                    {
                        $.$spc.System.Buffers.ArrayPool$$($.$spc.System.UInt32).Shared.Return(rFromPool, false);
                    }
                    /*Span<uint>*/ let result = $.$srn.System.Numerics.BigIntegerCalculator.PowCore$7(value, valueLength, power, $.$ref(() => reducer, ), bits, 1, temp);
                    result.CopyTo(bits);
                    bits.Slice(result.Length).Clear();
                    if (muFromPool !== null)
                    {
                        $.$spc.System.Buffers.ArrayPool$$($.$spc.System.UInt32).Shared.Return(muFromPool, false);
                    }
                    if (q1FromPool !== null)
                    {
                        $.$spc.System.Buffers.ArrayPool$$($.$spc.System.UInt32).Shared.Return(q1FromPool, false);
                    }
                    if (q2FromPool !== null)
                    {
                        $.$spc.System.Buffers.ArrayPool$$($.$spc.System.UInt32).Shared.Return(q2FromPool, false);
                    }
                }
            }
            static /*void */ PowCore$4(/*Span<uint>*/ value, /*int*/ valueLength, /*uint*/ power, /*ReadOnlySpan<uint>*/ modulus, /*Span<uint>*/ temp, /*Span<uint>*/ bits)
            {
                bits.get_Item(0).$v = 1;
                if (modulus.Length < $.$srn.System.Numerics.BigIntegerCalculator.ReducerThreshold)
                {
                    /*Span<uint>*/ let result = $.$srn.System.Numerics.BigIntegerCalculator.PowCore$6(value, valueLength, power, modulus, bits, 1, temp);
                    result.CopyTo(bits);
                    bits.Slice(result.Length).Clear();
                }
                else 
                {
                    /*int*/ let size = ((((modulus.Length * 2) | 0) + 1) | 0);
                    /*uint[]?*/ let rFromPool = null;
                    /*Span<uint>*/ let r = (BigInt((size >>> 0)) <= BigInt($.$srn.System.Numerics.BigIntegerCalculator.StackAllocThreshold) ? $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.StackAllocSpan($.$spc.System.UInt32, $.$srn.System.Numerics.BigIntegerCalculator.StackAllocThreshold, null) : $.$spc.System.Span$$($.$spc.System.UInt32).op_Implicit(rFromPool = $.$spc.System.Buffers.ArrayPool$$($.$spc.System.UInt32).Shared.Rent(size))).Slice$1(0, size);
                    r.Clear();
                    size = ((((r.Length - modulus.Length) | 0) + 1) | 0);
                    /*uint[]?*/ let muFromPool = null;
                    /*Span<uint>*/ let mu = (BigInt((size >>> 0)) <= BigInt($.$srn.System.Numerics.BigIntegerCalculator.StackAllocThreshold) ? $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.StackAllocSpan($.$spc.System.UInt32, $.$srn.System.Numerics.BigIntegerCalculator.StackAllocThreshold, null) : $.$spc.System.Span$$($.$spc.System.UInt32).op_Implicit(muFromPool = $.$spc.System.Buffers.ArrayPool$$($.$spc.System.UInt32).Shared.Rent(size))).Slice$1(0, size);
                    mu.Clear();
                    size = ((((modulus.Length * 2) | 0) + 2) | 0);
                    /*uint[]?*/ let q1FromPool = null;
                    /*Span<uint>*/ let q1 = (BigInt((size >>> 0)) <= BigInt($.$srn.System.Numerics.BigIntegerCalculator.StackAllocThreshold) ? $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.StackAllocSpan($.$spc.System.UInt32, $.$srn.System.Numerics.BigIntegerCalculator.StackAllocThreshold, null) : $.$spc.System.Span$$($.$spc.System.UInt32).op_Implicit(q1FromPool = $.$spc.System.Buffers.ArrayPool$$($.$spc.System.UInt32).Shared.Rent(size))).Slice$1(0, size);
                    q1.Clear();
                    /*uint[]?*/ let q2FromPool = null;
                    /*Span<uint>*/ let q2 = (BigInt((size >>> 0)) <= BigInt($.$srn.System.Numerics.BigIntegerCalculator.StackAllocThreshold) ? $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.StackAllocSpan($.$spc.System.UInt32, $.$srn.System.Numerics.BigIntegerCalculator.StackAllocThreshold, null) : $.$spc.System.Span$$($.$spc.System.UInt32).op_Implicit(q2FromPool = $.$spc.System.Buffers.ArrayPool$$($.$spc.System.UInt32).Shared.Rent(size))).Slice$1(0, size);
                    q2.Clear();
                    /*FastReducer*/ let reducer = new $.$srn.System.Numerics.BigIntegerCalculator.FastReducer().$ctor$2(modulus, r, mu, q1, q2);
                    if (rFromPool !== null)
                    {
                        $.$spc.System.Buffers.ArrayPool$$($.$spc.System.UInt32).Shared.Return(rFromPool, false);
                    }
                    /*Span<uint>*/ let result = $.$srn.System.Numerics.BigIntegerCalculator.PowCore$8(value, valueLength, power, $.$ref(() => reducer, ), bits, 1, temp);
                    result.CopyTo(bits);
                    bits.Slice(result.Length).Clear();
                    if (muFromPool !== null)
                    {
                        $.$spc.System.Buffers.ArrayPool$$($.$spc.System.UInt32).Shared.Return(muFromPool, false);
                    }
                    if (q1FromPool !== null)
                    {
                        $.$spc.System.Buffers.ArrayPool$$($.$spc.System.UInt32).Shared.Return(q1FromPool, false);
                    }
                    if (q2FromPool !== null)
                    {
                        $.$spc.System.Buffers.ArrayPool$$($.$spc.System.UInt32).Shared.Return(q2FromPool, false);
                    }
                }
            }
            static /*Span<uint> */ PowCore$5(/*Span<uint>*/ value, /*int*/ valueLength, /*ReadOnlySpan<uint>*/ power, /*ReadOnlySpan<uint>*/ modulus, /*Span<uint>*/ result, /*int*/ resultLength, /*Span<uint>*/ temp)
            {
                for(/*int*/ let i = 0; i < ((power.Length - 1) | 0); i++)
                {
                    /*uint*/ let p = power.get_Item(i).$v;
                    for(/*int*/ let j = 0; j < 32; j++)
                    {
                        if ((p & 1) === 1)
                        {
                            resultLength = $.$srn.System.Numerics.BigIntegerCalculator.MultiplySelf($.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateObjectReferenceT($.$spc.System.Span$$($.$spc.System.UInt32), () => result, ($v) => result = $v, null), resultLength, $.$spc.System.Span$$($.$spc.System.UInt32).op_Implicit$2(value.Slice$1(0, valueLength)), $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateObjectReferenceT($.$spc.System.Span$$($.$spc.System.UInt32), () => temp, ($v) => temp = $v, null));
                            resultLength = $.$srn.System.Numerics.BigIntegerCalculator.Reduce(result.Slice$1(0, resultLength), modulus);
                        }
                        valueLength = $.$srn.System.Numerics.BigIntegerCalculator.SquareSelf($.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateObjectReferenceT($.$spc.System.Span$$($.$spc.System.UInt32), () => value, ($v) => value = $v, null), valueLength, $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateObjectReferenceT($.$spc.System.Span$$($.$spc.System.UInt32), () => temp, ($v) => temp = $v, null));
                        valueLength = $.$srn.System.Numerics.BigIntegerCalculator.Reduce(value.Slice$1(0, valueLength), modulus);
                        p >>= 1;
                    }
                }
                return $.$srn.System.Numerics.BigIntegerCalculator.PowCore$6(value, valueLength, power.get_Item(((power.Length - 1) | 0)).$v, modulus, result, resultLength, temp);
            }
            static /*Span<uint> */ PowCore$6(/*Span<uint>*/ value, /*int*/ valueLength, /*uint*/ power, /*ReadOnlySpan<uint>*/ modulus, /*Span<uint>*/ result, /*int*/ resultLength, /*Span<uint>*/ temp)
            {
                while(power !== 0)
                {
                    if ((power & 1) === 1)
                    {
                        resultLength = $.$srn.System.Numerics.BigIntegerCalculator.MultiplySelf($.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateObjectReferenceT($.$spc.System.Span$$($.$spc.System.UInt32), () => result, ($v) => result = $v, null), resultLength, $.$spc.System.Span$$($.$spc.System.UInt32).op_Implicit$2(value.Slice$1(0, valueLength)), $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateObjectReferenceT($.$spc.System.Span$$($.$spc.System.UInt32), () => temp, ($v) => temp = $v, null));
                        resultLength = $.$srn.System.Numerics.BigIntegerCalculator.Reduce(result.Slice$1(0, resultLength), modulus);
                    }
                    if (power !== 1)
                    {
                        valueLength = $.$srn.System.Numerics.BigIntegerCalculator.SquareSelf($.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateObjectReferenceT($.$spc.System.Span$$($.$spc.System.UInt32), () => value, ($v) => value = $v, null), valueLength, $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateObjectReferenceT($.$spc.System.Span$$($.$spc.System.UInt32), () => temp, ($v) => temp = $v, null));
                        valueLength = $.$srn.System.Numerics.BigIntegerCalculator.Reduce(value.Slice$1(0, valueLength), modulus);
                    }
                    power >>= 1;
                }
                return result.Slice$1(0, resultLength);
            }
            static /*Span<uint> */ PowCore$7(/*Span<uint>*/ value, /*int*/ valueLength, /*ReadOnlySpan<uint>*/ power, /*in FastReducer*/ reducer, /*Span<uint>*/ result, /*int*/ resultLength, /*Span<uint>*/ temp)
            {
                for(/*int*/ let i = 0; i < ((power.Length - 1) | 0); i++)
                {
                    /*uint*/ let p = power.get_Item(i).$v;
                    for(/*int*/ let j = 0; j < 32; j++)
                    {
                        if ((p & 1) === 1)
                        {
                            resultLength = $.$srn.System.Numerics.BigIntegerCalculator.MultiplySelf($.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateObjectReferenceT($.$spc.System.Span$$($.$spc.System.UInt32), () => result, ($v) => result = $v, null), resultLength, $.$spc.System.Span$$($.$spc.System.UInt32).op_Implicit$2(value.Slice$1(0, valueLength)), $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateObjectReferenceT($.$spc.System.Span$$($.$spc.System.UInt32), () => temp, ($v) => temp = $v, null));
                            resultLength = reducer.$v.Reduce(result.Slice$1(0, resultLength));
                        }
                        valueLength = $.$srn.System.Numerics.BigIntegerCalculator.SquareSelf($.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateObjectReferenceT($.$spc.System.Span$$($.$spc.System.UInt32), () => value, ($v) => value = $v, null), valueLength, $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateObjectReferenceT($.$spc.System.Span$$($.$spc.System.UInt32), () => temp, ($v) => temp = $v, null));
                        valueLength = reducer.$v.Reduce(value.Slice$1(0, valueLength));
                        p >>= 1;
                    }
                }
                return $.$srn.System.Numerics.BigIntegerCalculator.PowCore$8(value, valueLength, power.get_Item(((power.Length - 1) | 0)).$v, reducer, result, resultLength, temp);
            }
            static /*Span<uint> */ PowCore$8(/*Span<uint>*/ value, /*int*/ valueLength, /*uint*/ power, /*in FastReducer*/ reducer, /*Span<uint>*/ result, /*int*/ resultLength, /*Span<uint>*/ temp)
            {
                while(power !== 0)
                {
                    if ((power & 1) === 1)
                    {
                        resultLength = $.$srn.System.Numerics.BigIntegerCalculator.MultiplySelf($.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateObjectReferenceT($.$spc.System.Span$$($.$spc.System.UInt32), () => result, ($v) => result = $v, null), resultLength, $.$spc.System.Span$$($.$spc.System.UInt32).op_Implicit$2(value.Slice$1(0, valueLength)), $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateObjectReferenceT($.$spc.System.Span$$($.$spc.System.UInt32), () => temp, ($v) => temp = $v, null));
                        resultLength = reducer.$v.Reduce(result.Slice$1(0, resultLength));
                    }
                    if (power !== 1)
                    {
                        valueLength = $.$srn.System.Numerics.BigIntegerCalculator.SquareSelf($.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateObjectReferenceT($.$spc.System.Span$$($.$spc.System.UInt32), () => value, ($v) => value = $v, null), valueLength, $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateObjectReferenceT($.$spc.System.Span$$($.$spc.System.UInt32), () => temp, ($v) => temp = $v, null));
                        valueLength = reducer.$v.Reduce(value.Slice$1(0, valueLength));
                    }
                    power >>= 1;
                }
                return result.Slice$1(0, resultLength);
            }
            static $h = 961297;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"m":[{"r":65537,"p":[{"n":"source","p":$.$spc.System.ReadOnlySpan$$($.$spc.System.UInt32).$h},{"n":"dest","p":$.$spc.System.Span$$($.$spc.System.UInt32).$h},{"n":"start","p":655361}],"n":"CopyTail","d":961297,"h":8590895889,"f":34},{"r":65537,"p":[{"n":"left","p":$.$spc.System.ReadOnlySpan$$($.$spc.System.UInt32).$h},{"n":"right","p":720897},{"n":"bits","p":$.$spc.System.Span$$($.$spc.System.UInt32).$h}],"n":"Add","d":961297,"h":12885863185,"f":33},{"r":65537,"p":[{"n":"left","p":$.$spc.System.ReadOnlySpan$$($.$spc.System.UInt32).$h},{"n":"right","p":$.$spc.System.ReadOnlySpan$$($.$spc.System.UInt32).$h},{"n":"bits","p":$.$spc.System.Span$$($.$spc.System.UInt32).$h}],"n":"Add","o":"@$1","d":961297,"h":17180830481,"f":33},{"r":65537,"p":[{"n":"left","p":$.$spc.System.Span$$($.$spc.System.UInt32).$h},{"n":"right","p":$.$spc.System.ReadOnlySpan$$($.$spc.System.UInt32).$h}],"n":"AddSelf","d":961297,"h":21475797777,"f":33},{"r":65537,"p":[{"n":"left","p":$.$spc.System.ReadOnlySpan$$($.$spc.System.UInt32).$h},{"n":"right","p":720897},{"n":"bits","p":$.$spc.System.Span$$($.$spc.System.UInt32).$h}],"n":"Subtract","d":961297,"h":25770765073,"f":33},{"r":65537,"p":[{"n":"left","p":$.$spc.System.ReadOnlySpan$$($.$spc.System.UInt32).$h},{"n":"right","p":$.$spc.System.ReadOnlySpan$$($.$spc.System.UInt32).$h},{"n":"bits","p":$.$spc.System.Span$$($.$spc.System.UInt32).$h}],"n":"Subtract","o":"@$1","d":961297,"h":30065732369,"f":33},{"r":65537,"p":[{"n":"left","p":$.$spc.System.Span$$($.$spc.System.UInt32).$h},{"n":"right","p":$.$spc.System.ReadOnlySpan$$($.$spc.System.UInt32).$h}],"n":"SubtractSelf","d":961297,"h":34360699665,"f":33},{"r":65537,"p":[{"n":"left","p":$.$spc.System.ReadOnlySpan$$($.$spc.System.UInt32).$h},{"n":"bits","p":$.$spc.System.Span$$($.$spc.System.UInt32).$h},{"n":"resultPtr","p":720897,"f":4},{"n":"startIndex","p":655361},{"n":"initialCarry","p":917505}],"n":"Add","o":"@$2","d":961297,"h":38655666961,"f":34},{"r":65537,"p":[{"n":"left","p":$.$spc.System.ReadOnlySpan$$($.$spc.System.UInt32).$h},{"n":"bits","p":$.$spc.System.Span$$($.$spc.System.UInt32).$h},{"n":"resultPtr","p":720897,"f":4},{"n":"startIndex","p":655361},{"n":"initialCarry","p":917505}],"n":"Subtract","o":"@$2","d":961297,"h":42950634257,"f":34},{"r":720897,"p":[{"n":"left","p":720897},{"n":"right","p":720897}],"n":"Gcd","d":961297,"h":51540568849,"f":33},{"r":983041,"p":[{"n":"left","p":983041},{"n":"right","p":983041}],"n":"Gcd","o":"@$1","d":961297,"h":55835536145,"f":33},{"r":720897,"p":[{"n":"left","p":$.$spc.System.ReadOnlySpan$$($.$spc.System.UInt32).$h},{"n":"right","p":720897}],"n":"Gcd","o":"@$2","d":961297,"h":60130503441,"f":33},{"r":65537,"p":[{"n":"left","p":$.$spc.System.ReadOnlySpan$$($.$spc.System.UInt32).$h},{"n":"right","p":$.$spc.System.ReadOnlySpan$$($.$spc.System.UInt32).$h},{"n":"result","p":$.$spc.System.Span$$($.$spc.System.UInt32).$h}],"n":"Gcd","o":"@$3","d":961297,"h":64425470737,"f":33},{"r":65537,"p":[{"n":"left","p":$.$spc.System.Span$$($.$spc.System.UInt32).$h},{"n":"right","p":$.$spc.System.Span$$($.$spc.System.UInt32).$h}],"n":"Gcd","o":"@$4","d":961297,"h":68720438033,"f":34},{"r":655361,"p":[{"n":"buffer","p":$.$spc.System.Span$$($.$spc.System.UInt32).$h},{"n":"value","p":983041}],"n":"Overwrite","d":961297,"h":73015405329,"f":34},{"r":65537,"p":[{"n":"xBuffer","p":$.$spc.System.ReadOnlySpan$$($.$spc.System.UInt32).$h},{"n":"yBuffer","p":$.$spc.System.ReadOnlySpan$$($.$spc.System.UInt32).$h},{"n":"x","p":983041,"f":2},{"n":"y","p":983041,"f":2}],"n":"ExtractDigits","d":961297,"h":77310372625,"f":34},{"r":655361,"p":[{"n":"x","p":$.$spc.System.Span$$($.$spc.System.UInt32).$h},{"n":"y","p":$.$spc.System.Span$$($.$spc.System.UInt32).$h},{"n":"a","p":917505},{"n":"b","p":917505},{"n":"c","p":917505},{"n":"d","p":917505}],"n":"LehmerCore","d":961297,"h":81605339921,"f":34},{"r":655361,"p":[{"n":"bits","p":$.$spc.System.Span$$($.$spc.System.UInt32).$h},{"n":"maxLength","p":655361}],"n":"Refresh","d":961297,"h":85900307217,"f":34},{"r":65537,"p":[{"n":"value","p":$.$spc.System.ReadOnlySpan$$($.$spc.System.UInt32).$h},{"n":"bits","p":$.$spc.System.Span$$($.$spc.System.UInt32).$h}],"n":"Square","d":961297,"h":94490241809,"f":33},{"r":65537,"p":[{"n":"left","p":$.$spc.System.ReadOnlySpan$$($.$spc.System.UInt32).$h},{"n":"right","p":720897},{"n":"bits","p":$.$spc.System.Span$$($.$spc.System.UInt32).$h}],"n":"Multiply","d":961297,"h":98785209105,"f":33},{"r":65537,"p":[{"n":"left","p":$.$spc.System.ReadOnlySpan$$($.$spc.System.UInt32).$h},{"n":"right","p":$.$spc.System.ReadOnlySpan$$($.$spc.System.UInt32).$h},{"n":"bits","p":$.$spc.System.Span$$($.$spc.System.UInt32).$h}],"n":"Multiply","o":"@$1","d":961297,"h":107375143697,"f":33},{"r":65537,"p":[{"n":"left","p":$.$spc.System.ReadOnlySpan$$($.$spc.System.UInt32).$h},{"n":"right","p":$.$spc.System.ReadOnlySpan$$($.$spc.System.UInt32).$h},{"n":"core","p":$.$spc.System.Span$$($.$spc.System.UInt32).$h}],"n":"SubtractCore","d":961297,"h":111670110993,"f":34},{"r":655361,"p":[{"n":"left","p":$.$spc.System.ReadOnlySpan$$($.$spc.System.UInt32).$h},{"n":"right","p":$.$spc.System.ReadOnlySpan$$($.$spc.System.UInt32).$h}],"n":"Compare","d":961297,"h":120260045585,"f":33},{"r":655361,"p":[{"n":"left","p":$.$spc.System.ReadOnlySpan$$($.$spc.System.UInt32).$h},{"n":"right","p":$.$spc.System.ReadOnlySpan$$($.$spc.System.UInt32).$h}],"n":"CompareActual","d":961297,"h":124555012881,"f":34},{"r":655361,"p":[{"n":"value","p":$.$spc.System.ReadOnlySpan$$($.$spc.System.UInt32).$h}],"n":"ActualLength","d":961297,"h":128849980177,"f":33},{"r":655361,"p":[{"n":"bits","p":$.$spc.System.Span$$($.$spc.System.UInt32).$h},{"n":"modulus","p":$.$spc.System.ReadOnlySpan$$($.$spc.System.UInt32).$h}],"n":"Reduce","d":961297,"h":133144947473,"f":34},{"r":65537,"p":[{"n":"bits","p":$.$spc.System.Span$$($.$spc.System.UInt32).$h}],"n":"InitializeForDebug","d":961297,"h":137439914769,"f":33,"a":[{"t":35979265,"c":4330946561,"a":[{"v":"DEBUG","t":1310721}]}]},{"r":65537,"p":[{"n":"left","p":$.$spc.System.ReadOnlySpan$$($.$spc.System.UInt32).$h},{"n":"right","p":720897},{"n":"quotient","p":$.$spc.System.Span$$($.$spc.System.UInt32).$h},{"n":"remainder","p":720897,"f":2}],"n":"Divide","d":961297,"h":146029849361,"f":33},{"r":65537,"p":[{"n":"left","p":$.$spc.System.ReadOnlySpan$$($.$spc.System.UInt32).$h},{"n":"right","p":720897},{"n":"quotient","p":$.$spc.System.Span$$($.$spc.System.UInt32).$h}],"n":"Divide","o":"@$1","d":961297,"h":150324816657,"f":33},{"r":65537,"p":[{"n":"left","p":$.$spc.System.ReadOnlySpan$$($.$spc.System.UInt32).$h},{"n":"right","p":720897},{"n":"quotient","p":$.$spc.System.Span$$($.$spc.System.UInt32).$h},{"n":"carry","p":983041,"f":4}],"n":"Divide","o":"@$2","d":961297,"h":154619783953,"f":34},{"r":720897,"p":[{"n":"left","p":$.$spc.System.ReadOnlySpan$$($.$spc.System.UInt32).$h},{"n":"right","p":720897}],"n":"Remainder","d":961297,"h":158914751249,"f":33},{"r":65537,"p":[{"n":"left","p":$.$spc.System.ReadOnlySpan$$($.$spc.System.UInt32).$h},{"n":"right","p":$.$spc.System.ReadOnlySpan$$($.$spc.System.UInt32).$h},{"n":"quotient","p":$.$spc.System.Span$$($.$spc.System.UInt32).$h},{"n":"remainder","p":$.$spc.System.Span$$($.$spc.System.UInt32).$h}],"n":"Divide","o":"@$3","d":961297,"h":163209718545,"f":33},{"r":65537,"p":[{"n":"left","p":$.$spc.System.ReadOnlySpan$$($.$spc.System.UInt32).$h},{"n":"right","p":$.$spc.System.ReadOnlySpan$$($.$spc.System.UInt32).$h},{"n":"quotient","p":$.$spc.System.Span$$($.$spc.System.UInt32).$h}],"n":"Divide","o":"@$4","d":961297,"h":167504685841,"f":33},{"r":65537,"p":[{"n":"left","p":$.$spc.System.ReadOnlySpan$$($.$spc.System.UInt32).$h},{"n":"right","p":$.$spc.System.ReadOnlySpan$$($.$spc.System.UInt32).$h},{"n":"remainder","p":$.$spc.System.Span$$($.$spc.System.UInt32).$h}],"n":"Remainder","o":"@$1","d":961297,"h":171799653137,"f":33},{"r":65537,"p":[{"n":"left","p":$.$spc.System.Span$$($.$spc.System.UInt32).$h},{"n":"right","p":$.$spc.System.ReadOnlySpan$$($.$spc.System.UInt32).$h},{"n":"quotient","p":$.$spc.System.Span$$($.$spc.System.UInt32).$h}],"n":"DivRem","d":961297,"h":176094620433,"f":34},{"r":65537,"p":[{"n":"left","p":$.$spc.System.Span$$($.$spc.System.UInt32).$h},{"n":"right","p":$.$spc.System.ReadOnlySpan$$($.$spc.System.UInt32).$h},{"n":"quotient","p":$.$spc.System.Span$$($.$spc.System.UInt32).$h}],"n":"DivideGrammarSchool","d":961297,"h":180389587729,"f":34},{"r":720897,"p":[{"n":"left","p":$.$spc.System.Span$$($.$spc.System.UInt32).$h},{"n":"right","p":$.$spc.System.ReadOnlySpan$$($.$spc.System.UInt32).$h}],"n":"AddDivisor","d":961297,"h":184684555025,"f":34},{"r":720897,"p":[{"n":"left","p":$.$spc.System.Span$$($.$spc.System.UInt32).$h},{"n":"right","p":$.$spc.System.ReadOnlySpan$$($.$spc.System.UInt32).$h},{"n":"q","p":983041}],"n":"SubtractDivisor","d":961297,"h":188979522321,"f":34},{"r":262145,"p":[{"n":"q","p":983041},{"n":"valHi","p":983041},{"n":"valLo","p":720897},{"n":"divHi","p":720897},{"n":"divLo","p":720897}],"n":"DivideGuessTooBig","d":961297,"h":193274489617,"f":34},{"r":65537,"p":[{"n":"left","p":$.$spc.System.ReadOnlySpan$$($.$spc.System.UInt32).$h},{"n":"right","p":$.$spc.System.ReadOnlySpan$$($.$spc.System.UInt32).$h},{"n":"quotient","p":$.$spc.System.Span$$($.$spc.System.UInt32).$h},{"n":"remainder","p":$.$spc.System.Span$$($.$spc.System.UInt32).$h}],"n":"DivideBurnikelZiegler","d":961297,"h":197569456913,"f":34},{"r":65537,"p":[{"n":"left","p":$.$spc.System.ReadOnlySpan$$($.$spc.System.UInt32).$h},{"n":"right","p":$.$spc.System.ReadOnlySpan$$($.$spc.System.UInt32).$h},{"n":"quotient","p":$.$spc.System.Span$$($.$spc.System.UInt32).$h},{"n":"remainder","p":$.$spc.System.Span$$($.$spc.System.UInt32).$h}],"n":"BurnikelZieglerFallback","d":961297,"h":201864424209,"f":34},{"r":65537,"p":[{"n":"left","p":$.$spc.System.ReadOnlySpan$$($.$spc.System.UInt32).$h},{"n":"right","p":$.$spc.System.ReadOnlySpan$$($.$spc.System.UInt32).$h},{"n":"quotient","p":$.$spc.System.Span$$($.$spc.System.UInt32).$h},{"n":"remainder","p":$.$spc.System.Span$$($.$spc.System.UInt32).$h}],"n":"BurnikelZieglerD2n1n","d":961297,"h":206159391505,"f":34},{"r":65537,"p":[{"n":"left12","p":$.$spc.System.ReadOnlySpan$$($.$spc.System.UInt32).$h},{"n":"left3","p":$.$spc.System.ReadOnlySpan$$($.$spc.System.UInt32).$h},{"n":"right","p":$.$spc.System.ReadOnlySpan$$($.$spc.System.UInt32).$h},{"n":"quotient","p":$.$spc.System.Span$$($.$spc.System.UInt32).$h},{"n":"remainder","p":$.$spc.System.Span$$($.$spc.System.UInt32).$h}],"n":"BurnikelZieglerD3n2n","d":961297,"h":210454358801,"f":34},{"r":65537,"p":[{"n":"value","p":720897},{"n":"power","p":720897},{"n":"bits","p":$.$spc.System.Span$$($.$spc.System.UInt32).$h}],"n":"Pow","d":961297,"h":214749326097,"f":33},{"r":65537,"p":[{"n":"value","p":$.$spc.System.ReadOnlySpan$$($.$spc.System.UInt32).$h},{"n":"power","p":720897},{"n":"bits","p":$.$spc.System.Span$$($.$spc.System.UInt32).$h}],"n":"Pow","o":"@$1","d":961297,"h":219044293393,"f":33},{"r":$.$spc.System.Span$$($.$spc.System.UInt32).$h,"p":[{"n":"value","p":$.$spc.System.Span$$($.$spc.System.UInt32).$h},{"n":"valueLength","p":655361},{"n":"temp","p":$.$spc.System.Span$$($.$spc.System.UInt32).$h},{"n":"power","p":720897},{"n":"result","p":$.$spc.System.Span$$($.$spc.System.UInt32).$h}],"n":"PowCore","d":961297,"h":223339260689,"f":34},{"r":655361,"p":[{"n":"left","p":$.$spc.System.Span$$($.$spc.System.UInt32).$h,"f":4},{"n":"leftLength","p":655361},{"n":"right","p":$.$spc.System.ReadOnlySpan$$($.$spc.System.UInt32).$h},{"n":"temp","p":$.$spc.System.Span$$($.$spc.System.UInt32).$h,"f":4}],"n":"MultiplySelf","d":961297,"h":227634227985,"f":34},{"r":655361,"p":[{"n":"value","p":$.$spc.System.Span$$($.$spc.System.UInt32).$h,"f":4},{"n":"valueLength","p":655361},{"n":"temp","p":$.$spc.System.Span$$($.$spc.System.UInt32).$h,"f":4}],"n":"SquareSelf","d":961297,"h":231929195281,"f":34},{"r":655361,"p":[{"n":"power","p":720897},{"n":"valueLength","p":655361}],"n":"PowBound","d":961297,"h":236224162577,"f":33},{"r":720897,"p":[{"n":"value","p":720897},{"n":"power","p":720897},{"n":"modulus","p":720897}],"n":"Pow","o":"@$2","d":961297,"h":240519129873,"f":33},{"r":720897,"p":[{"n":"value","p":$.$spc.System.ReadOnlySpan$$($.$spc.System.UInt32).$h},{"n":"power","p":720897},{"n":"modulus","p":720897}],"n":"Pow","o":"@$3","d":961297,"h":244814097169,"f":33},{"r":720897,"p":[{"n":"value","p":720897},{"n":"power","p":$.$spc.System.ReadOnlySpan$$($.$spc.System.UInt32).$h},{"n":"modulus","p":720897}],"n":"Pow","o":"@$4","d":961297,"h":249109064465,"f":33},{"r":720897,"p":[{"n":"value","p":$.$spc.System.ReadOnlySpan$$($.$spc.System.UInt32).$h},{"n":"power","p":$.$spc.System.ReadOnlySpan$$($.$spc.System.UInt32).$h},{"n":"modulus","p":720897}],"n":"Pow","o":"@$5","d":961297,"h":253404031761,"f":33},{"r":720897,"p":[{"n":"value","p":983041},{"n":"power","p":$.$spc.System.ReadOnlySpan$$($.$spc.System.UInt32).$h},{"n":"modulus","p":720897},{"n":"result","p":983041}],"n":"PowCore","o":"@$1","d":961297,"h":257698999057,"f":34},{"r":720897,"p":[{"n":"value","p":983041},{"n":"power","p":720897},{"n":"modulus","p":720897},{"n":"result","p":983041}],"n":"PowCore","o":"@$2","d":961297,"h":261993966353,"f":34},{"r":65537,"p":[{"n":"value","p":720897},{"n":"power","p":720897},{"n":"modulus","p":$.$spc.System.ReadOnlySpan$$($.$spc.System.UInt32).$h},{"n":"bits","p":$.$spc.System.Span$$($.$spc.System.UInt32).$h}],"n":"Pow","o":"@$6","d":961297,"h":266288933649,"f":33},{"r":65537,"p":[{"n":"value","p":$.$spc.System.ReadOnlySpan$$($.$spc.System.UInt32).$h},{"n":"power","p":720897},{"n":"modulus","p":$.$spc.System.ReadOnlySpan$$($.$spc.System.UInt32).$h},{"n":"bits","p":$.$spc.System.Span$$($.$spc.System.UInt32).$h}],"n":"Pow","o":"@$7","d":961297,"h":270583900945,"f":33},{"r":65537,"p":[{"n":"value","p":720897},{"n":"power","p":$.$spc.System.ReadOnlySpan$$($.$spc.System.UInt32).$h},{"n":"modulus","p":$.$spc.System.ReadOnlySpan$$($.$spc.System.UInt32).$h},{"n":"bits","p":$.$spc.System.Span$$($.$spc.System.UInt32).$h}],"n":"Pow","o":"@$8","d":961297,"h":274878868241,"f":33},{"r":65537,"p":[{"n":"value","p":$.$spc.System.ReadOnlySpan$$($.$spc.System.UInt32).$h},{"n":"power","p":$.$spc.System.ReadOnlySpan$$($.$spc.System.UInt32).$h},{"n":"modulus","p":$.$spc.System.ReadOnlySpan$$($.$spc.System.UInt32).$h},{"n":"bits","p":$.$spc.System.Span$$($.$spc.System.UInt32).$h}],"n":"Pow","o":"@$9","d":961297,"h":279173835537,"f":33},{"r":65537,"p":[{"n":"value","p":$.$spc.System.Span$$($.$spc.System.UInt32).$h},{"n":"valueLength","p":655361},{"n":"power","p":$.$spc.System.ReadOnlySpan$$($.$spc.System.UInt32).$h},{"n":"modulus","p":$.$spc.System.ReadOnlySpan$$($.$spc.System.UInt32).$h},{"n":"temp","p":$.$spc.System.Span$$($.$spc.System.UInt32).$h},{"n":"bits","p":$.$spc.System.Span$$($.$spc.System.UInt32).$h}],"n":"PowCore","o":"@$3","d":961297,"h":287763770129,"f":34},{"r":65537,"p":[{"n":"value","p":$.$spc.System.Span$$($.$spc.System.UInt32).$h},{"n":"valueLength","p":655361},{"n":"power","p":720897},{"n":"modulus","p":$.$spc.System.ReadOnlySpan$$($.$spc.System.UInt32).$h},{"n":"temp","p":$.$spc.System.Span$$($.$spc.System.UInt32).$h},{"n":"bits","p":$.$spc.System.Span$$($.$spc.System.UInt32).$h}],"n":"PowCore","o":"@$4","d":961297,"h":292058737425,"f":34},{"r":$.$spc.System.Span$$($.$spc.System.UInt32).$h,"p":[{"n":"value","p":$.$spc.System.Span$$($.$spc.System.UInt32).$h},{"n":"valueLength","p":655361},{"n":"power","p":$.$spc.System.ReadOnlySpan$$($.$spc.System.UInt32).$h},{"n":"modulus","p":$.$spc.System.ReadOnlySpan$$($.$spc.System.UInt32).$h},{"n":"result","p":$.$spc.System.Span$$($.$spc.System.UInt32).$h},{"n":"resultLength","p":655361},{"n":"temp","p":$.$spc.System.Span$$($.$spc.System.UInt32).$h}],"n":"PowCore","o":"@$5","d":961297,"h":296353704721,"f":34},{"r":$.$spc.System.Span$$($.$spc.System.UInt32).$h,"p":[{"n":"value","p":$.$spc.System.Span$$($.$spc.System.UInt32).$h},{"n":"valueLength","p":655361},{"n":"power","p":720897},{"n":"modulus","p":$.$spc.System.ReadOnlySpan$$($.$spc.System.UInt32).$h},{"n":"result","p":$.$spc.System.Span$$($.$spc.System.UInt32).$h},{"n":"resultLength","p":655361},{"n":"temp","p":$.$spc.System.Span$$($.$spc.System.UInt32).$h}],"n":"PowCore","o":"@$6","d":961297,"h":300648672017,"f":34},{"r":$.$spc.System.Span$$($.$spc.System.UInt32).$h,"p":[{"n":"value","p":$.$spc.System.Span$$($.$spc.System.UInt32).$h},{"n":"valueLength","p":655361},{"n":"power","p":$.$spc.System.ReadOnlySpan$$($.$spc.System.UInt32).$h},{"n":"reducer","p":1026833,"f":8},{"n":"result","p":$.$spc.System.Span$$($.$spc.System.UInt32).$h},{"n":"resultLength","p":655361},{"n":"temp","p":$.$spc.System.Span$$($.$spc.System.UInt32).$h}],"n":"PowCore","o":"@$7","d":961297,"h":304943639313,"f":34},{"r":$.$spc.System.Span$$($.$spc.System.UInt32).$h,"p":[{"n":"value","p":$.$spc.System.Span$$($.$spc.System.UInt32).$h},{"n":"valueLength","p":655361},{"n":"power","p":720897},{"n":"reducer","p":1026833,"f":8},{"n":"result","p":$.$spc.System.Span$$($.$spc.System.UInt32).$h},{"n":"resultLength","p":655361},{"n":"temp","p":$.$spc.System.Span$$($.$spc.System.UInt32).$h}],"n":"PowCore","o":"@$8","d":961297,"h":309238606609,"f":34}],"l":[{"t":655361,"n":"CopyToThreshold","d":961297,"h":4295928593,"f":34},{"t":655361,"n":"SquareThreshold","d":961297,"h":90195274513,"f":40},{"t":655361,"n":"MultiplyKaratsubaThreshold","d":961297,"h":103080176401,"f":40},{"t":655361,"n":"StackAllocThreshold","d":961297,"h":115965078289,"f":40},{"t":655361,"n":"DivideBurnikelZieglerThreshold","d":961297,"h":141734882065,"f":40},{"t":655361,"n":"ReducerThreshold","d":961297,"h":283468802833,"f":40}],"j":[1026833],"h":961297}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.Numerics.BigIntegerCalculator`; }
        });
        
        $asm.$cls("$srn.System.Buffers.Text.FormattingHelpers", ($self) => class FormattingHelpers
        {
            static /*int */ CountDigits(/*ulong*/ value)
            {
                /*ReadOnlySpan<byte>*/ let log2ToPow10 = new ($.$spc.System.ReadOnlySpan$$($.$spc.System.Byte))().$ctor$2([ 1, 1, 1, 2, 2, 2, 3, 3, 3, 4, 4, 4, 4, 5, 5, 5, 6, 6, 6, 7, 7, 7, 7, 8, 8, 8, 9, 9, 9, 10, 10, 10, 10, 11, 11, 11, 12, 12, 12, 13, 13, 13, 13, 14, 14, 14, 15, 15, 15, 16, 16, 16, 16, 17, 17, 17, 18, 18, 18, 19, 19, 19, 19, 20 ]);
                $.$spc.System.Diagnostics.Debug.Assert$1(log2ToPow10.Length === 64, "log2ToPow10.Length == 64");
                /*nint*/ let elementOffset = log2ToPow10.get_Item($.$cast($.$spc.System.UInt64.Log2(value), $.$spc.System.Int32)).$v;
                /*ReadOnlySpan<ulong>*/ let powersOf10 = new ($.$spc.System.ReadOnlySpan$$($.$spc.System.UInt64))().$ctor$2([ 0n, 0n, 10n, 100n, 1000n, 10000n, 100000n, 1000000n, 10000000n, 100000000n, 1000000000n, 10000000000n, 100000000000n, 1000000000000n, 10000000000000n, 100000000000000n, 1000000000000000n, 10000000000000000n, 100000000000000000n, 1000000000000000000n, 10000000000000000000n ]);
                $.$spc.System.Diagnostics.Debug.Assert$1((elementOffset + 1) <= powersOf10.Length, "(elementOffset + 1) <= powersOf10.Length");
                /*ulong*/ let powerOf10 = $.$spc.System.Runtime.InteropServices.MemoryMarshal.GetReference$1($.$spc.System.UInt64, powersOf10).GetAt(elementOffset);
                /*int*/ let index = elementOffset;
                return ((index - (value < powerOf10 ? 1 : 0)) | 0);
            }
            static /*int */ CountDigits$1(/*uint*/ value)
            {
                /*ReadOnlySpan<long>*/ let table = new ($.$spc.System.ReadOnlySpan$$($.$spc.System.Int64))().$ctor$2([ 4294967296n, 8589934582n, 8589934582n, 8589934582n, 12884901788n, 12884901788n, 12884901788n, 17179868184n, 17179868184n, 17179868184n, 21474826480n, 21474826480n, 21474826480n, 21474826480n, 25769703776n, 25769703776n, 25769703776n, 30063771072n, 30063771072n, 30063771072n, 34349738368n, 34349738368n, 34349738368n, 34349738368n, 38554705664n, 38554705664n, 38554705664n, 41949672960n, 41949672960n, 41949672960n, 42949672960n, 42949672960n ]);
                $.$spc.System.Diagnostics.Debug.Assert$1(table.Length === 32, "Every result of uint.Log2(value) needs a long entry in the table.");
                /*long*/ let tableValue = table.get_Item(($.$spc.System.UInt32.Log2(value) | 0)).$v;
                return $.$cast(((BigInt(value) + tableValue) >> 32n), $.$spc.System.Int32);
            }
            static /*int */ CountHexDigits(/*ulong*/ value)
            {
                return ((($.$spc.System.Numerics.BitOperations.Log2$1(value) >> 2) + 1) | 0);
            }
            static /*int */ CountDecimalTrailingZeros(/*uint*/ value, /*out uint*/ valueWithoutTrailingZeros)
            {
                /*int*/ let zeroCount = 0;
                if (value !== 0)
                {
                    while(true)
                    {
                        /*uint*/ let temp = $.trunc(value / 10);
                        if (value !== (((temp * 10) >>> 0)))
                        {
                            break;
                        }
                        value = temp;
                        zeroCount++;
                    }
                }
                valueWithoutTrailingZeros.$v = value;
                return zeroCount;
            }
            static $h = 240401;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"m":[{"r":655361,"p":[{"n":"value","p":983041}],"n":"CountDigits","d":240401,"h":4295207697,"f":33},{"r":655361,"p":[{"n":"value","p":720897}],"n":"CountDigits","o":"@$1","d":240401,"h":8590174993,"f":33},{"r":655361,"p":[{"n":"value","p":983041}],"n":"CountHexDigits","d":240401,"h":12885142289,"f":33},{"r":655361,"p":[{"n":"value","p":720897},{"n":"valueWithoutTrailingZeros","p":720897,"f":2}],"n":"CountDecimalTrailingZeros","d":240401,"h":17180109585,"f":33}],"h":240401}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.Buffers.Text.FormattingHelpers`; }
        });
        
        $asm.$cls("$srn.System.Number", ($self) => class Number
        {
            /*int*/ static DecimalNumberBufferLength = 31;
            /*int*/ static DoubleNumberBufferLength = 769;
            /*int*/ static Int32NumberBufferLength = 11;
            /*int*/ static Int64NumberBufferLength = 20;
            /*int*/ static Int128NumberBufferLength = 40;
            /*int*/ static SingleNumberBufferLength = 114;
            /*int*/ static HalfNumberBufferLength = 23;
            /*int*/ static UInt32NumberBufferLength = 11;
            /*int*/ static UInt64NumberBufferLength = 21;
            /*int*/ static UInt128NumberBufferLength = 40;
            static $_NumberBuffer;
            static get NumberBuffer()
            {
                let $cls = $.$srn.System.Number;
                return $cls.$_NumberBuffer ??= $asm.$nstr("$srn.System.Number.NumberBuffer", ($self) => class NumberBuffer extends $.$spc.System.ValueType
                {
                    /*int*/  get DigitsCount() { return this.$getField(0, 4); }
                    /*int*/  set DigitsCount(value) { this.$setField(0, 4, value); }
                    /*int*/  get Scale() { return this.$getField(4, 4); }
                    /*int*/  set Scale(value) { this.$setField(4, 4, value); }
                    /*bool*/  get IsNegative() { return this.$getField(8, 1); }
                    /*bool*/  set IsNegative(value) { this.$setField(8, 1, value); }
                    /*bool*/  get HasNonZeroTail() { return this.$getField(9, 1); }
                    /*bool*/  set HasNonZeroTail(value) { this.$setField(9, 1, value); }
                    /*NumberBufferKind*/  get Kind() { return this.$getField(10, 1); }
                    /*NumberBufferKind*/  set Kind(value) { this.$setField(10, 1, value); }
                    /*Span<byte>*/  get Digits() { return this.$getField(11, 5); }
                    /*Span<byte>*/  set Digits(value) { this.$setField(11, 5, value); }
                    /*byte* */ get DigitsPtr()
                    {
                        return $.$cast($.$spc.System.Runtime.CompilerServices.Unsafe.AsPointer($.$spc.System.Byte, $.$spc.System.Runtime.InteropServices.MemoryMarshal.GetReference($.$spc.System.Byte, this.Digits)), $.$typePointer($.$spc.System.Byte));
                    }
                    $ctor$2(/*NumberBufferKind*/ kind, /*byte**/ digits, /*int*/ digitsLength)
                    {
                        this.$ctor$3(kind, new ($.$spc.System.Span$$($.$spc.System.Byte))().$ctor$4(digits, digitsLength));
                        {
                            $.$spc.System.Diagnostics.Debug.Assert$1(digits !== null, "digits != null");
                        }
                        return this;
                    }
                    $ctor$3(/*NumberBufferKind*/ kind, /*Span<byte>*/ digits)
                    {
                        super.$ctor$1();
                        {
                            $.$spc.System.Diagnostics.Debug.Assert$1(!digits.IsEmpty, "!digits.IsEmpty");
                            this.DigitsCount = 0;
                            this.Scale = 0;
                            this.IsNegative = false;
                            this.HasNonZeroTail = false;
                            this.Kind = kind;
                            this.Digits = digits;
                            this.Digits.Fill(204);
                            this.Digits.get_Item(0).$v = /*\u0000*/ 0;
                            this.CheckConsistency();
                        }
                        return this;
                    }
                    /*void */ CheckConsistency()
                    {
                        $.$spc.System.Diagnostics.Debug.Assert$1((this.Kind === 1/*NumberBufferKind.Integer*/) || (this.Kind === 2/*NumberBufferKind.Decimal*/) || (this.Kind === 3/*NumberBufferKind.FloatingPoint*/), "(Kind == NumberBufferKind.Integer) || (Kind == NumberBufferKind.Decimal) || (Kind == NumberBufferKind.FloatingPoint)");
                        $.$spc.System.Diagnostics.Debug.Assert$1(this.Digits.get_Item(0).$v !== /*0*/ 48, "Leading zeros should never be stored in a Number");
                        /*int*/ let numDigits;
                        for(numDigits = 0; numDigits < this.Digits.Length; numDigits++)
                        {
                            /*byte*/ let digit = this.Digits.get_Item(numDigits).$v;
                            if (digit === 0)
                            {
                                break;
                            }
                            $.$spc.System.Diagnostics.Debug.Assert$2($.$spc.System.Char.IsAsciiDigit(digit), `Unexpected character found in Number: ${digit}`);
                        }
                        $.$spc.System.Diagnostics.Debug.Assert$1(numDigits === this.DigitsCount, "Null terminator found in unexpected location in Number");
                        $.$spc.System.Diagnostics.Debug.Assert$1(numDigits < this.Digits.Length, "Null terminator not found in Number");
                    }
                    static/*conventional*/ /*string */ ToString()
                    {
                        /*StringBuilder*/ let sb = new $.$spc.System.Text.StringBuilder().$ctor$1();
                        sb.Append$7(/*[*/ 91);
                        sb.Append$7(/*\"*/ 34);
                        for(/*int*/ let i = 0; i < this.Digits.Length; i++)
                        {
                            /*byte*/ let digit = this.Digits.get_Item(i).$v;
                            if (digit === 0)
                            {
                                break;
                            }
                            sb.Append$7((digit));
                        }
                        sb.Append$7(/*\"*/ 34);
                        sb.Append$2(", Length = ").Append$11(this.DigitsCount);
                        sb.Append$2(", Scale = ").Append$11(this.Scale);
                        sb.Append$2(", IsNegative = ").Append$6(this.IsNegative);
                        sb.Append$2(", HasNonZeroTail = ").Append$6(this.HasNonZeroTail);
                        sb.Append$2(", Kind = ").Append$19($.$box(this.Kind, $.$srn.System.Number.NumberBufferKind));
                        sb.Append$7(/*]*/ 93);
                        return $.$spc.System.Text.StringBuilder.ToString.call(sb);
                    }
                    //Static convention instance redirect
                    /*string */ ToString() { return $.$srn.System.Number.NumberBuffer.ToString.apply(this, arguments); }
                    //default value type constructor
                    $ctor$4()
                    {
                        return this;
                    }
                    Clone($copy)
                    {
                        let copy = $copy ?? new this.constructor();
                        copy.DigitsCount = this.DigitsCount;
                        copy.Scale = this.Scale;
                        copy.IsNegative = this.IsNegative;
                        copy.HasNonZeroTail = this.HasNonZeroTail;
                        copy.Kind = this.Kind;
                        copy.Digits = this.Digits.Clone();
                        return copy;
                    }
                    //default member initializer
                    constructor()
                    {
                        super();
                        this.DigitsCount = 0;
                        this.Scale = 0;
                        this.IsNegative = false;
                        this.HasNonZeroTail = false;
                        this.Kind = 0;
                        this.Digits = $.$default($.$spc.System.Span$$($.$spc.System.Byte));
                    }
                    static $h = 568081;
                    static $z = 16;
                    static $f = 0b10000001010000000;
                    static $k = 2;
                    static $$md;
                    static get $md() { return this.$$md ??= {"b":196609,"p":[{"p":0,"g":{"r":0,"d":0,"h":34360306449,"f":1},"n":"DigitsPtr","d":568081,"h":30065339153,"f":1}],"m":[{"r":65537,"n":"CheckConsistency","d":568081,"h":47245208337,"f":1,"a":[{"t":35979265,"c":4330946561,"a":[{"v":"DEBUG","t":1310721}]}]},{"r":1310721,"n":"ToString","d":568081,"h":51540175633,"f":32769}],"l":[{"t":655361,"n":"DigitsCount","d":568081,"h":4295535377,"f":1},{"t":655361,"n":"Scale","d":568081,"h":8590502673,"f":1},{"t":262145,"n":"IsNegative","d":568081,"h":12885469969,"f":1},{"t":262145,"n":"HasNonZeroTail","d":568081,"h":17180437265,"f":1},{"t":633617,"n":"Kind","d":568081,"h":21475404561,"f":1},{"t":$.$spc.System.Span$$($.$spc.System.Byte).$h,"n":"Digits","d":568081,"h":25770371857,"f":1}],"c":[{"p":[{"n":"kind","p":633617},{"n":"digits","p":0},{"n":"digitsLength","p":655361}],"n":".ctor","o":"$ctor$2","d":568081,"h":38655273745,"f":1},{"p":[{"n":"kind","p":633617},{"n":"digits","p":$.$spc.System.Span$$($.$spc.System.Byte).$h}],"n":".ctor","o":"$ctor$3","d":568081,"h":42950241041,"f":1},{"n":".ctor","o":"$ctor$4","d":568081,"h":55835142929,"f":1}],"d":502545,"h":568081}; }
                    static get $b() { return $.$spc.System.ValueType; }
                    static get $fullName() { return `System.Number.NumberBuffer`; }
                }, $cls, ($v) => $cls.$_NumberBuffer = $v);
            }
            static $_NumberBufferKind;
            static get NumberBufferKind()
            {
                let $cls = $.$srn.System.Number;
                return $cls.$_NumberBufferKind ??= $asm.$nstr("$srn.System.Number.NumberBufferKind", ($self) => class NumberBufferKind extends $.$spc.System.Enum
                {
                    static Unknown = 0;
                    static Integer = 1;
                    static Decimal = 2;
                    static FloatingPoint = 3;
                    static $map;
                    static get Map()
                    {
                        return this.$map ??= 
                        {
                            "Unknown": 0n,
                            "Integer": 1n,
                            "Decimal": 2n,
                            "FloatingPoint": 3n
                        };
                    }
                    static $h = 633617;
                    static $z = 1;
                    static $f = 0b110000011010001000;
                    static $k = 4;
                    static get $eut() { return $.$spc.System.Byte; }
                    static $$md;
                    static get $md() { return this.$$md ??= {"b":1048577,"u":393217,"l":[{"t":633617,"n":"Unknown","d":633617,"h":4295600913,"f":33},{"t":633617,"n":"Integer","d":633617,"h":8590568209,"f":33},{"t":633617,"n":"Decimal","d":633617,"h":12885535505,"f":33},{"t":633617,"n":"FloatingPoint","d":633617,"h":17180502801,"f":33}],"c":[{"n":".ctor","o":"$ctor$3","d":633617,"h":21475470097,"f":1}],"i":[57278465,63832065,57737217,57409537],"d":502545,"h":633617}; }
                    static get $b() { return $.$spc.System.Enum; }
                    static $$i;
                    static get $i() { return this.$$i ??= [ $.$spc.System.IComparable, $.$spc.System.ISpanFormattable, $.$spc.System.IFormattable, $.$spc.System.IConvertible ]; }
                    static get $fullName() { return `System.Number.NumberBufferKind`; }
                }, $cls, ($v) => $cls.$_NumberBufferKind = $v);
            }
            static /*bool */ AllowHyphenDuringParsing(/*this NumberFormatInfo*/ info)
            {
                /*string*/ let negativeSign = info.NegativeSign;
                return negativeSign.length === 1 && (() =>
                {
                    let $switch1 = $.$spc.System.String.get_Chars.call(negativeSign, 0);
                    if ((((((($switch1 === /*\u2012*/ 8210) || ($switch1 === /*\u207B*/ 8315)) || ($switch1 === /*\u208B*/ 8331)) || ($switch1 === /*\u2212*/ 8722)) || ($switch1 === /*\u2796*/ 10134)) || ($switch1 === /*\uFE63*/ 65123)) || ($switch1 === /*\uFF0D*/ 65293))
                    {
                        return true;
                    }
                    return false;
                })();
            }
            static /*ReadOnlySpan<TChar> */ PositiveSignTChar(TChar, /*this NumberFormatInfo*/ info)
            {
                $.$spc.System.Diagnostics.Debug.Assert$1($.$spc.System.Type.op_Equality$1(TChar.$type, $.$srn.System.Utf16Char.$type), "typeof(TChar) == typeof(Utf16Char)");
                return $.$spc.System.Runtime.InteropServices.MemoryMarshal.Cast$1($.$spc.System.Char, TChar, $.$spc.System.String.op_Implicit(info.PositiveSign));
            }
            static /*ReadOnlySpan<TChar> */ NegativeSignTChar(TChar, /*this NumberFormatInfo*/ info)
            {
                $.$spc.System.Diagnostics.Debug.Assert$1($.$spc.System.Type.op_Equality$1(TChar.$type, $.$srn.System.Utf16Char.$type), "typeof(TChar) == typeof(Utf16Char)");
                return $.$spc.System.Runtime.InteropServices.MemoryMarshal.Cast$1($.$spc.System.Char, TChar, $.$spc.System.String.op_Implicit(info.NegativeSign));
            }
            static /*ReadOnlySpan<TChar> */ CurrencySymbolTChar(TChar, /*this NumberFormatInfo*/ info)
            {
                $.$spc.System.Diagnostics.Debug.Assert$1($.$spc.System.Type.op_Equality$1(TChar.$type, $.$srn.System.Utf16Char.$type), "typeof(TChar) == typeof(Utf16Char)");
                return $.$spc.System.Runtime.InteropServices.MemoryMarshal.Cast$1($.$spc.System.Char, TChar, $.$spc.System.String.op_Implicit(info.CurrencySymbol));
            }
            static /*ReadOnlySpan<TChar> */ PercentSymbolTChar(TChar, /*this NumberFormatInfo*/ info)
            {
                $.$spc.System.Diagnostics.Debug.Assert$1($.$spc.System.Type.op_Equality$1(TChar.$type, $.$srn.System.Utf16Char.$type), "typeof(TChar) == typeof(Utf16Char)");
                return $.$spc.System.Runtime.InteropServices.MemoryMarshal.Cast$1($.$spc.System.Char, TChar, $.$spc.System.String.op_Implicit(info.PercentSymbol));
            }
            static /*ReadOnlySpan<TChar> */ PerMilleSymbolTChar(TChar, /*this NumberFormatInfo*/ info)
            {
                $.$spc.System.Diagnostics.Debug.Assert$1($.$spc.System.Type.op_Equality$1(TChar.$type, $.$srn.System.Utf16Char.$type), "typeof(TChar) == typeof(Utf16Char)");
                return $.$spc.System.Runtime.InteropServices.MemoryMarshal.Cast$1($.$spc.System.Char, TChar, $.$spc.System.String.op_Implicit(info.PerMilleSymbol));
            }
            static /*ReadOnlySpan<TChar> */ CurrencyDecimalSeparatorTChar(TChar, /*this NumberFormatInfo*/ info)
            {
                $.$spc.System.Diagnostics.Debug.Assert$1($.$spc.System.Type.op_Equality$1(TChar.$type, $.$srn.System.Utf16Char.$type), "typeof(TChar) == typeof(Utf16Char)");
                return $.$spc.System.Runtime.InteropServices.MemoryMarshal.Cast$1($.$spc.System.Char, TChar, $.$spc.System.String.op_Implicit(info.CurrencyDecimalSeparator));
            }
            static /*ReadOnlySpan<TChar> */ CurrencyGroupSeparatorTChar(TChar, /*this NumberFormatInfo*/ info)
            {
                $.$spc.System.Diagnostics.Debug.Assert$1($.$spc.System.Type.op_Equality$1(TChar.$type, $.$srn.System.Utf16Char.$type), "typeof(TChar) == typeof(Utf16Char)");
                return $.$spc.System.Runtime.InteropServices.MemoryMarshal.Cast$1($.$spc.System.Char, TChar, $.$spc.System.String.op_Implicit(info.CurrencyGroupSeparator));
            }
            static /*ReadOnlySpan<TChar> */ NumberDecimalSeparatorTChar(TChar, /*this NumberFormatInfo*/ info)
            {
                $.$spc.System.Diagnostics.Debug.Assert$1($.$spc.System.Type.op_Equality$1(TChar.$type, $.$srn.System.Utf16Char.$type), "typeof(TChar) == typeof(Utf16Char)");
                return $.$spc.System.Runtime.InteropServices.MemoryMarshal.Cast$1($.$spc.System.Char, TChar, $.$spc.System.String.op_Implicit(info.NumberDecimalSeparator));
            }
            static /*ReadOnlySpan<TChar> */ NumberGroupSeparatorTChar(TChar, /*this NumberFormatInfo*/ info)
            {
                $.$spc.System.Diagnostics.Debug.Assert$1($.$spc.System.Type.op_Equality$1(TChar.$type, $.$srn.System.Utf16Char.$type), "typeof(TChar) == typeof(Utf16Char)");
                return $.$spc.System.Runtime.InteropServices.MemoryMarshal.Cast$1($.$spc.System.Char, TChar, $.$spc.System.String.op_Implicit(info.NumberGroupSeparator));
            }
            static /*ReadOnlySpan<TChar> */ PercentDecimalSeparatorTChar(TChar, /*this NumberFormatInfo*/ info)
            {
                $.$spc.System.Diagnostics.Debug.Assert$1($.$spc.System.Type.op_Equality$1(TChar.$type, $.$srn.System.Utf16Char.$type), "typeof(TChar) == typeof(Utf16Char)");
                return $.$spc.System.Runtime.InteropServices.MemoryMarshal.Cast$1($.$spc.System.Char, TChar, $.$spc.System.String.op_Implicit(info.PercentDecimalSeparator));
            }
            static /*ReadOnlySpan<TChar> */ PercentGroupSeparatorTChar(TChar, /*this NumberFormatInfo*/ info)
            {
                $.$spc.System.Diagnostics.Debug.Assert$1($.$spc.System.Type.op_Equality$1(TChar.$type, $.$srn.System.Utf16Char.$type), "typeof(TChar) == typeof(Utf16Char)");
                return $.$spc.System.Runtime.InteropServices.MemoryMarshal.Cast$1($.$spc.System.Char, TChar, $.$spc.System.String.op_Implicit(info.PercentGroupSeparator));
            }
            static /*bool */ TryParseNumber(TChar, /*scoped ref TChar**/ str, /*TChar**/ strEnd, /*NumberStyles*/ styles, /*ref NumberBuffer*/ number, /*NumberFormatInfo*/ info)
            {
                $.$spc.System.Diagnostics.Debug.Assert$1(str.$v !== null, "str != null");
                $.$spc.System.Diagnostics.Debug.Assert$1(strEnd !== null, "strEnd != null");
                $.$spc.System.Diagnostics.Debug.Assert$1($.$spc.NetJs.RefOrPointer.Compare(str.$v, strEnd) <= 0, "str <= strEnd");
                $.$spc.System.Diagnostics.Debug.Assert$1((styles & (512/*NumberStyles.AllowHexSpecifier*/ | 1024/*NumberStyles.AllowBinarySpecifier*/)) === 0, "(styles & (NumberStyles.AllowHexSpecifier | NumberStyles.AllowBinarySpecifier)) == 0");
                /*int*/ let StateSign = 1;
                /*int*/ let StateParens = 2;
                /*int*/ let StateDigits = 4;
                /*int*/ let StateNonZero = 8;
                /*int*/ let StateDecimal = 16;
                /*int*/ let StateCurrency = 32;
                $.$spc.System.Diagnostics.Debug.Assert$1(number.$v.DigitsCount === 0, "number.DigitsCount == 0");
                $.$spc.System.Diagnostics.Debug.Assert$1(number.$v.Scale === 0, "number.Scale == 0");
                $.$spc.System.Diagnostics.Debug.Assert$1(!number.$v.IsNegative, "!number.IsNegative");
                $.$spc.System.Diagnostics.Debug.Assert$1(!number.$v.HasNonZeroTail, "!number.HasNonZeroTail");
                number.$v.CheckConsistency();
                /*ReadOnlySpan<TChar>*/ let decSep;
                /*ReadOnlySpan<TChar>*/ let groupSep;
                /*ReadOnlySpan<TChar>*/ let currSymbol = $.$spc.System.ReadOnlySpan$$(TChar).Empty;
                /*bool*/ let parsingCurrency = false;
                if ((styles & 256/*NumberStyles.AllowCurrencySymbol*/) !== 0)
                {
                    currSymbol = $.$srn.System.Number.CurrencySymbolTChar(TChar, info);
                    decSep = $.$srn.System.Number.CurrencyDecimalSeparatorTChar(TChar, info);
                    groupSep = $.$srn.System.Number.CurrencyGroupSeparatorTChar(TChar, info);
                    parsingCurrency = true;
                }
                else 
                {
                    decSep = $.$srn.System.Number.NumberDecimalSeparatorTChar(TChar, info);
                    groupSep = $.$srn.System.Number.NumberGroupSeparatorTChar(TChar, info);
                }
                /*int*/ let state = 0;
                /*TChar**/ let p = str.$v;
                /*uint*/ let ch = ($.$spc.NetJs.RefOrPointer.Compare(p, strEnd) < 0) ? TChar.System$IUtfChar$$$CastToUInt32(p.$v) : /*\u0000*/ 0;
                /*TChar**/ let next;
                while(true)
                {
                    if (!$.$srn.System.Number.IsWhite(ch) || (styles & 1/*NumberStyles.AllowLeadingWhite*/) === 0 || ((state & StateSign) !== 0 && (state & StateCurrency) === 0 && info.NumberNegativePattern !== 2))
                    {
                        if (((styles & 4/*NumberStyles.AllowLeadingSign*/) !== 0) && (state & StateSign) === 0 && ((next = $.$srn.System.Number.MatchChars(TChar, p, strEnd, $.$srn.System.Number.PositiveSignTChar(TChar, info))) !== null || ((next = $.$srn.System.Number.MatchNegativeSignChars(TChar, p, strEnd, info)) !== null && (number.$v.IsNegative = true))))
                        {
                            state |= StateSign;
                            p = next.Add(-1);
                        }
                        else if (ch === /*(*/ 40 && ((styles & 16/*NumberStyles.AllowParentheses*/) !== 0) && ((state & StateSign) === 0))
                        {
                            state |= StateSign | StateParens;
                            number.$v.IsNegative = true;
                        }
                        else if (!currSymbol.IsEmpty && (next = $.$srn.System.Number.MatchChars(TChar, p, strEnd, currSymbol)) !== null)
                        {
                            state |= StateCurrency;
                            currSymbol = $.$spc.System.ReadOnlySpan$$(TChar).Empty;
                            p = next.Add(-1);
                        }
                        else 
                        {
                            break;
                        }
                    }
                    ch = $.$spc.NetJs.RefOrPointer.Compare(p = p.Add(1), strEnd) < 0 ? TChar.System$IUtfChar$$$CastToUInt32(p.$v) : /*\u0000*/ 0;
                }
                /*int*/ let digCount = 0;
                /*int*/ let digEnd = 0;
                /*int*/ let maxDigCount = ((number.$v.Digits.Length - 1) | 0);
                /*int*/ let numberOfTrailingZeros = 0;
                while(true)
                {
                    if ($.$srn.System.Number.IsDigit(ch))
                    {
                        state |= StateDigits;
                        if (ch !== /*0*/ 48 || (state & StateNonZero) !== 0)
                        {
                            if (digCount < maxDigCount)
                            {
                                number.$v.Digits.get_Item(digCount).$v = $.$cast(ch, $.$spc.System.Byte);
                                if ((ch !== /*0*/ 48) || (number.$v.Kind !== 1/*NumberBufferKind.Integer*/))
                                {
                                    digEnd = ((digCount + 1) | 0);
                                }
                            }
                            else if (ch !== /*0*/ 48)
                            {
                                number.$v.HasNonZeroTail = true;
                            }
                            if ((state & StateDecimal) === 0)
                            {
                                number.$v.Scale++;
                            }
                            if (digCount < maxDigCount)
                            {
                                if (ch === /*0*/ 48)
                                {
                                    numberOfTrailingZeros++;
                                }
                                else 
                                {
                                    numberOfTrailingZeros = 0;
                                }
                            }
                            digCount++;
                            state |= StateNonZero;
                        }
                        else if ((state & StateDecimal) !== 0)
                        {
                            number.$v.Scale--;
                        }
                    }
                    else if (((styles & 32/*NumberStyles.AllowDecimalPoint*/) !== 0) && ((state & StateDecimal) === 0) && ((next = $.$srn.System.Number.MatchChars(TChar, p, strEnd, decSep)) !== null || (parsingCurrency && (state & StateCurrency) === 0 && (next = $.$srn.System.Number.MatchChars(TChar, p, strEnd, $.$srn.System.Number.NumberDecimalSeparatorTChar(TChar, info))) !== null)))
                    {
                        state |= StateDecimal;
                        p = next.Add(-1);
                    }
                    else if (((styles & 64/*NumberStyles.AllowThousands*/) !== 0) && ((state & StateDigits) !== 0) && ((state & StateDecimal) === 0) && ((next = $.$srn.System.Number.MatchChars(TChar, p, strEnd, groupSep)) !== null || (parsingCurrency && (state & StateCurrency) === 0 && (next = $.$srn.System.Number.MatchChars(TChar, p, strEnd, $.$srn.System.Number.NumberGroupSeparatorTChar(TChar, info))) !== null)))
                    {
                        p = next.Add(-1);
                    }
                    else 
                    {
                        break;
                    }
                    ch = $.$spc.NetJs.RefOrPointer.Compare(p = p.Add(1), strEnd) < 0 ? TChar.System$IUtfChar$$$CastToUInt32(p.$v) : /*\u0000*/ 0;
                }
                /*bool*/ let negExp = false;
                number.$v.DigitsCount = digEnd;
                number.$v.Digits.get_Item(digEnd).$v = /*\u0000*/ 0;
                if ((state & StateDigits) !== 0)
                {
                    if ((ch === /*E*/ 69 || ch === /*e*/ 101) && ((styles & 128/*NumberStyles.AllowExponent*/) !== 0))
                    {
                        /*TChar**/ let temp = p;
                        ch = $.$spc.NetJs.RefOrPointer.Compare(p = p.Add(1), strEnd) < 0 ? TChar.System$IUtfChar$$$CastToUInt32(p.$v) : /*\u0000*/ 0;
                        if ((next = $.$srn.System.Number.MatchChars(TChar, p, strEnd, $.$srn.System.Number.PositiveSignTChar(TChar, info))) !== null)
                        {
                            ch = $.$spc.NetJs.RefOrPointer.Compare((p = next), strEnd) < 0 ? TChar.System$IUtfChar$$$CastToUInt32(p.$v) : /*\u0000*/ 0;
                        }
                        else if ((next = $.$srn.System.Number.MatchNegativeSignChars(TChar, p, strEnd, info)) !== null)
                        {
                            ch = $.$spc.NetJs.RefOrPointer.Compare((p = next), strEnd) < 0 ? TChar.System$IUtfChar$$$CastToUInt32(p.$v) : /*\u0000*/ 0;
                            negExp = true;
                        }
                        if ($.$srn.System.Number.IsDigit(ch))
                        {
                            /*int*/ let exp = 0;
                            do
                            {
                                if (exp >= 100000000)
                                {
                                    exp = 2147483647/*int.MaxValue*/;
                                    number.$v.Scale = 0;
                                    while($.$srn.System.Number.IsDigit(ch))
                                    {
                                        ch = $.$spc.NetJs.RefOrPointer.Compare(p = p.Add(1), strEnd) < 0 ? TChar.System$IUtfChar$$$CastToUInt32(p.$v) : /*\u0000*/ 0;
                                    }
                                    break;
                                }
                                exp = (((((exp * 10) | 0)) + ((((ch - /*0*/ 48) >>> 0)) | 0)) | 0);
                                ch = $.$spc.NetJs.RefOrPointer.Compare(p = p.Add(1), strEnd) < 0 ? TChar.System$IUtfChar$$$CastToUInt32(p.$v) : /*\u0000*/ 0;
                            }
                            while($.$srn.System.Number.IsDigit(ch));
                            if (negExp)
                            {
                                exp = -exp;
                            }
                            number.$v.Scale += exp;
                        }
                        else 
                        {
                            p = temp;
                            ch = $.$spc.NetJs.RefOrPointer.Compare(p, strEnd) < 0 ? TChar.System$IUtfChar$$$CastToUInt32(p.$v) : /*\u0000*/ 0;
                        }
                    }
                    if (number.$v.Kind === 3/*NumberBufferKind.FloatingPoint*/ && !number.$v.HasNonZeroTail)
                    {
                        /*int*/ let numberOfFractionalDigits = ((digEnd - number.$v.Scale) | 0);
                        if (numberOfFractionalDigits > 0)
                        {
                            numberOfTrailingZeros = $.$spc.System.Math.Min$4(numberOfTrailingZeros, numberOfFractionalDigits);
                            $.$spc.System.Diagnostics.Debug.Assert$1(numberOfTrailingZeros >= 0, "numberOfTrailingZeros >= 0");
                            number.$v.DigitsCount = ((digEnd - numberOfTrailingZeros) | 0);
                            number.$v.Digits.get_Item(number.$v.DigitsCount).$v = /*\u0000*/ 0;
                        }
                    }
                    while(true)
                    {
                        if (!$.$srn.System.Number.IsWhite(ch) || (styles & 2/*NumberStyles.AllowTrailingWhite*/) === 0)
                        {
                            if ((styles & 8/*NumberStyles.AllowTrailingSign*/) !== 0 && ((state & StateSign) === 0) && ((next = $.$srn.System.Number.MatchChars(TChar, p, strEnd, $.$srn.System.Number.PositiveSignTChar(TChar, info))) !== null || (((next = $.$srn.System.Number.MatchNegativeSignChars(TChar, p, strEnd, info)) !== null) && (number.$v.IsNegative = true))))
                            {
                                state |= StateSign;
                                p = next.Add(-1);
                            }
                            else if (ch === /*)*/ 41 && ((state & StateParens) !== 0))
                            {
                                state &= ~StateParens;
                            }
                            else if (!currSymbol.IsEmpty && (next = $.$srn.System.Number.MatchChars(TChar, p, strEnd, currSymbol)) !== null)
                            {
                                currSymbol = $.$spc.System.ReadOnlySpan$$(TChar).Empty;
                                p = next.Add(-1);
                            }
                            else 
                            {
                                break;
                            }
                        }
                        ch = $.$spc.NetJs.RefOrPointer.Compare(p = p.Add(1), strEnd) < 0 ? TChar.System$IUtfChar$$$CastToUInt32(p.$v) : /*\u0000*/ 0;
                    }
                    if ((state & StateParens) === 0)
                    {
                        if ((state & StateNonZero) === 0)
                        {
                            if (number.$v.Kind !== 2/*NumberBufferKind.Decimal*/)
                            {
                                number.$v.Scale = 0;
                            }
                            if ((number.$v.Kind === 1/*NumberBufferKind.Integer*/) && (state & StateDecimal) === 0)
                            {
                                number.$v.IsNegative = false;
                            }
                        }
                        str.$v = p;
                        return true;
                    }
                }
                str.$v = p;
                return false;
            }
            static /*bool */ TryStringToNumber(TChar, /*ReadOnlySpan<TChar>*/ value, /*NumberStyles*/ styles, /*ref NumberBuffer*/ number, /*NumberFormatInfo*/ info)
            {
                $.$spc.System.Diagnostics.Debug.Assert$1(info !== null, "info != null");
                /*fixed*/ 
                {
                    /*TChar**/ let stringPointer = $.$spc.System.Runtime.InteropServices.MemoryMarshal.GetReference$1(TChar, value);
                    /*TChar**/ let p = stringPointer;
                    if (!$.$srn.System.Number.TryParseNumber(TChar, $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateObjectReferenceT($.$typePointer(TChar), () => p, ($v) => p = $v, null), p.Add(value.Length), styles, number, info) || ($.$cast((p.Subtract(stringPointer)), $.$spc.System.Int32) < value.Length && !$.$srn.System.Number.TrailingZeros(TChar, value, $.$cast((p.Subtract(stringPointer)), $.$spc.System.Int32))))
                    {
                        number.$v.CheckConsistency();
                        return false;
                    }
                }
                number.$v.CheckConsistency();
                return true;
            }
            static /*bool */ TrailingZeros(TChar, /*ReadOnlySpan<TChar>*/ value, /*int*/ index)
            {
                return !$.$spc.System.MemoryExtensions.ContainsAnyExcept$5(TChar, value.Slice(index), TChar.System$IUtfChar$$$CastFrom$1(/*\u0000*/ 0));
            }
            static /*bool */ IsWhite(/*uint*/ ch)
            {
                return (ch === 32) || ((((ch - 9) >>> 0)) <= (((13 - 9) | 0)));
            }
            static /*bool */ IsDigit(/*uint*/ ch)
            {
                return ((((ch - /*0*/ 48) >>> 0)) >>> 0) <= 9;
            }
            static $_ParsingStatus;
            static get ParsingStatus()
            {
                let $cls = $.$srn.System.Number;
                return $cls.$_ParsingStatus ??= $asm.$nstr("$srn.System.Number.ParsingStatus", ($self) => class ParsingStatus extends $.$spc.System.Enum
                {
                    static OK = 0;
                    static Failed = 1;
                    static Overflow = 2;
                    static $map;
                    static get Map()
                    {
                        return this.$map ??= 
                        {
                            "OK": 0n,
                            "Failed": 1n,
                            "Overflow": 2n
                        };
                    }
                    static $h = 699153;
                    static $z = 4;
                    static $f = 0b110000011010001000;
                    static $k = 4;
                    static get $eut() { return $.$spc.System.Int32; }
                    static $$md;
                    static get $md() { return this.$$md ??= {"b":1048577,"u":655361,"l":[{"t":699153,"n":"OK","d":699153,"h":4295666449,"f":33},{"t":699153,"n":"Failed","d":699153,"h":8590633745,"f":33},{"t":699153,"n":"Overflow","d":699153,"h":12885601041,"f":33}],"c":[{"n":".ctor","o":"$ctor$3","d":699153,"h":17180568337,"f":1}],"i":[57278465,63832065,57737217,57409537],"d":502545,"h":699153}; }
                    static get $b() { return $.$spc.System.Enum; }
                    static $$i;
                    static get $i() { return this.$$i ??= [ $.$spc.System.IComparable, $.$spc.System.ISpanFormattable, $.$spc.System.IFormattable, $.$spc.System.IConvertible ]; }
                    static get $fullName() { return `System.Number.ParsingStatus`; }
                }, $cls, ($v) => $cls.$_ParsingStatus = $v);
            }
            static /*bool */ IsSpaceReplacingChar(/*uint*/ c)
            {
                return (c === /*\u00A0*/ 160) || (c === /*\u202F*/ 8239);
            }
            static /*TChar* */ MatchNegativeSignChars(TChar, /*TChar**/ p, /*TChar**/ pEnd, /*NumberFormatInfo*/ info)
            {
                /*TChar**/ let ret = $.$srn.System.Number.MatchChars(TChar, p, pEnd, $.$srn.System.Number.NegativeSignTChar(TChar, info));
                if ((ret === null) && $.$srn.System.Number.AllowHyphenDuringParsing(info) && ($.$spc.NetJs.RefOrPointer.Compare(p, pEnd) < 0) && (TChar.System$IUtfChar$$$CastToUInt32(p.$v) === /*-*/ 45))
                {
                    ret = p.Add(1);
                }
                return ret;
            }
            static /*TChar* */ MatchChars(TChar, /*TChar**/ p, /*TChar**/ pEnd, /*ReadOnlySpan<TChar>*/ value)
            {
                $.$spc.System.Diagnostics.Debug.Assert$1((p !== null) && (pEnd !== null) && ($.$spc.NetJs.RefOrPointer.Compare(p, pEnd) <= 0), "(p != null) && (pEnd != null) && (p <= pEnd)");
                /*fixed*/ 
                {
                    /*TChar**/ let stringPointer = $.$spc.System.Runtime.InteropServices.MemoryMarshal.GetReference$1(TChar, value);
                    /*TChar**/ let str = stringPointer;
                    if (TChar.System$IUtfChar$$$CastToUInt32(str.$v) !== /*\u0000*/ 0)
                    {
                        while(true)
                        {
                            /*uint*/ let cp = ($.$spc.NetJs.RefOrPointer.Compare(p, pEnd) < 0) ? TChar.System$IUtfChar$$$CastToUInt32(p.$v) : /*\u0000*/ 0;
                            /*uint*/ let val = TChar.System$IUtfChar$$$CastToUInt32(str.$v);
                            if ((cp !== val) && !($.$srn.System.Number.IsSpaceReplacingChar(val) && (cp === /* */ 32)))
                            {
                                break;
                            }
                            p = p.Add(1);
                            str = str.Add(1);
                            if (TChar.System$IUtfChar$$$CastToUInt32(str.$v) === /*\u0000*/ 0)
                            {
                                return p;
                            }
                        }
                    }
                }
                return null;
            }
            /*int*/ static CharStackBufferSize = 32;
            /*int*/ static DefaultPrecisionExponentialFormat = 6;
            /*int*/ static MaxUInt32DecDigits = 10;
            /*string*/ static PosNumberFormat = null;
            /*string[]*/ static s_posCurrencyFormats = null;
            /*string[]*/ static s_negCurrencyFormats = null;
            /*string[]*/ static s_posPercentFormats = null;
            /*string[]*/ static s_negPercentFormats = null;
            /*string[]*/ static s_negNumberFormats = null;
            static /*char */ ParseFormatSpecifier(/*ReadOnlySpan<char>*/ format, /*out int*/ digits)
            {
                /*char*/ let c = 0;
                if (format.Length > 0)
                {
                    c = format.get_Item(0).$v;
                    if ($.$spc.System.Char.IsAsciiLetter(c))
                    {
                        if (format.Length === 1)
                        {
                            digits.$v = -1;
                            return c;
                        }
                        if (format.Length === 2)
                        {
                            /*int*/ let d = format.get_Item(1).$v - /*0*/ 48;
                            if ((d >>> 0) < 10)
                            {
                                digits.$v = d;
                                return c;
                            }
                        }
                        else if (format.Length === 3)
                        {
                            /*int*/ let d1 = format.get_Item(1).$v - /*0*/ 48, d2 = format.get_Item(2).$v - /*0*/ 48;
                            if ((d1 >>> 0) < 10 && (d2 >>> 0) < 10)
                            {
                                digits.$v = ((((d1 * 10) | 0) + d2) | 0);
                                return c;
                            }
                        }
                        /*int*/ let n = 0;
                        /*int*/ let i = 1;
                        while((i >>> 0) < (format.Length >>> 0) && $.$spc.System.Char.IsAsciiDigit(format.get_Item(i).$v))
                        {
                            if (n >= 100000000)
                            {
                                $.$srn.System.ThrowHelper.ThrowFormatException_BadFormatSpecifier();
                            }
                            n = (((((((n * 10) | 0)) + format.get_Item(i++).$v) | 0) - /*0*/ 48) | 0);
                        }
                        if ((i >>> 0) >= (format.Length >>> 0) || format.get_Item(i).$v === /*\u0000*/ 0)
                        {
                            digits.$v = n;
                            return c;
                        }
                    }
                }
                digits.$v = -1;
                return format.Length === 0 || c === /*\u0000*/ 0 ? /*G*/ 71 : /*\u0000*/ 0;
            }
            static /*TChar* */ UInt32ToDecChars(TChar, /*TChar**/ bufferEnd, /*uint*/ value, /*int*/ digits)
            {
                while(value !== 0 || digits > 0)
                {
                    digits--;
                    /*uint*/ let remainder;
        $.$tupleUnpack(($tp) =>
                    {
                        value = $tp.Item1;
                        remainder = $tp.Item2;
                    }).$v = $.$spc.System.Math.DivRem$7(value, 10);
                    (bufferEnd = bufferEnd.Add(-1)).$v = TChar.System$IUtfChar$$$CastFrom$3(((remainder + /*0*/ 48) >>> 0));
                }
                return bufferEnd;
            }
            static /*void */ NumberToString(TChar, /*ref ValueListBuilder<TChar>*/ vlb, /*ref NumberBuffer*/ number, /*char*/ format, /*int*/ nMaxDigits, /*NumberFormatInfo*/ info)
            {
                $.$spc.System.Diagnostics.Debug.Assert$1((TChar.$z??4) === $.$spc.System.Char.$z || (TChar.$z??4) === $.$spc.System.Byte.$z, "sizeof(TChar) == sizeof(char) || sizeof(TChar) == sizeof(byte)");
                number.$v.CheckConsistency();
                /*bool*/ let isCorrectlyRounded = (number.$v.Kind === 3/*NumberBufferKind.FloatingPoint*/);
                let $switchJumpState1;
                $switchJumpStart1: while(true)
                {
                    switch($switchJumpState1 ?? format)
                    {
                        case /*C*/ 67:
                        case /*c*/ 99:
                        {
                            if (nMaxDigits < 0)
                            {
                                nMaxDigits = info.CurrencyDecimalDigits;
                            }
                            $.$srn.System.Number.RoundNumber(number, ((number.$v.Scale + nMaxDigits) | 0), isCorrectlyRounded);
                            $.$srn.System.Number.FormatCurrency(TChar, vlb, number, nMaxDigits, info);
                            break;
                        }
                        case /*F*/ 70:
                        case /*f*/ 102:
                        {
                            if (nMaxDigits < 0)
                            {
                                nMaxDigits = info.NumberDecimalDigits;
                            }
                            $.$srn.System.Number.RoundNumber(number, ((number.$v.Scale + nMaxDigits) | 0), isCorrectlyRounded);
                            if (number.$v.IsNegative)
                            {
                                vlb.$v.Append$1($.$srn.System.Number.NegativeSignTChar(TChar, info));
                            }
                            $.$srn.System.Number.FormatFixed(TChar, vlb, number, nMaxDigits, null, $.$srn.System.Number.NumberDecimalSeparatorTChar(TChar, info), $.$spc.System.ReadOnlySpan$$(TChar).op_Implicit(null));
                            break;
                        }
                        case /*N*/ 78:
                        case /*n*/ 110:
                        {
                            if (nMaxDigits < 0)
                            {
                                nMaxDigits = info.NumberDecimalDigits;
                            }
                            $.$srn.System.Number.RoundNumber(number, ((number.$v.Scale + nMaxDigits) | 0), isCorrectlyRounded);
                            $.$srn.System.Number.FormatNumber(TChar, vlb, number, nMaxDigits, info);
                            break;
                        }
                        case /*E*/ 69:
                        case /*e*/ 101:
                        {
                            if (nMaxDigits < 0)
                            {
                                nMaxDigits = 6/*DefaultPrecisionExponentialFormat*/;
                            }
                            nMaxDigits++;
                            $.$srn.System.Number.RoundNumber(number, nMaxDigits, isCorrectlyRounded);
                            if (number.$v.IsNegative)
                            {
                                vlb.$v.Append$1($.$srn.System.Number.NegativeSignTChar(TChar, info));
                            }
                            $.$srn.System.Number.FormatScientific(TChar, vlb, number, nMaxDigits, info, format);
                            break;
                        }
                        case /*G*/ 71:
                        case /*g*/ 103:
                        {
                            /*bool*/ let noRounding;
                            let $gotoJumpState2 = 0;
                            $gotoJumpStart2: while(true)
                            {
                                switch($gotoJumpState2)
                                {
                                    case 0:
                                    {
                                        noRounding = false;
                                        if (nMaxDigits < 1)
                                        {
                                            if ((number.$v.Kind === 2/*NumberBufferKind.Decimal*/) && (nMaxDigits === -1))
                                            {
                                                noRounding = true;
                                                if (number.$v.Digits.get_Item(0).$v === 0)
                                                {
                                                    $gotoJumpState2 = 2; /*goto SkipSign*/
                                                    continue $gotoJumpStart2;
                                                }
                                                $gotoJumpState2 = 1; /*goto SkipRounding*/
                                                continue $gotoJumpStart2;
                                            }
                                            else 
                                            {
                                                nMaxDigits = number.$v.DigitsCount;
                                            }
                                        }
                                        $.$srn.System.Number.RoundNumber(number, nMaxDigits, isCorrectlyRounded);
                                    }
                                    case 1: /*SkipRounding*/
                                    if (number.$v.IsNegative)
                                    {
                                        vlb.$v.Append$1($.$srn.System.Number.NegativeSignTChar(TChar, info));
                                    }
                                    case 2: /*SkipSign*/
                                    $.$srn.System.Number.FormatGeneral(TChar, vlb, number, nMaxDigits, info, $.$cast((((format - (/*G*/ 71 - /*E*/ 69)) | 0)), $.$spc.System.Char), noRounding);
                                    break;
                                }
                                break;
                            }
                        }
                        case /*P*/ 80:
                        case /*p*/ 112:
                        {
                            if (nMaxDigits < 0)
                            {
                                nMaxDigits = info.PercentDecimalDigits;
                            }
                            number.$v.Scale += 2;
                            $.$srn.System.Number.RoundNumber(number, ((number.$v.Scale + nMaxDigits) | 0), isCorrectlyRounded);
                            $.$srn.System.Number.FormatPercent(TChar, vlb, number, nMaxDigits, info);
                            break;
                        }
                        case /*R*/ 82:
                        case /*r*/ 114:
                        {
                            format = $.$cast((((format - (/*R*/ 82 - /*G*/ 71)) | 0)), $.$spc.System.Char);
                            $.$spc.System.Diagnostics.Debug.Assert$1((format === /*G*/ 71) || (format === /*g*/ 103), "format is 'G' or 'g'");
                            $switchJumpState1 = /*G*/ 71; /*goto case 'G'*/
                            continue $switchJumpStart1;
                        }
                        default:
                        $.$srn.System.ThrowHelper.ThrowFormatException_BadFormatSpecifier();
                        break;
                    }
                    break;
                }
            }
            static /*void */ NumberToStringFormat(TChar, /*ref ValueListBuilder<TChar>*/ vlb, /*ref NumberBuffer*/ number, /*ReadOnlySpan<char>*/ format, /*NumberFormatInfo*/ info)
            {
                $.$spc.System.Diagnostics.Debug.Assert$1((TChar.$z??4) === $.$spc.System.Char.$z || (TChar.$z??4) === $.$spc.System.Byte.$z, "sizeof(TChar) == sizeof(char) || sizeof(TChar) == sizeof(byte)");
                number.$v.CheckConsistency();
                /*int*/ let digitCount;
                /*int*/ let decimalPos;
                /*int*/ let firstDigit;
                /*int*/ let lastDigit;
                /*int*/ let digPos;
                /*bool*/ let scientific;
                /*int*/ let thousandPos;
                /*int*/ let thousandCount = 0;
                /*bool*/ let thousandSeps;
                /*int*/ let scaleAdjust;
                /*int*/ let adjust;
                /*int*/ let section;
                /*int*/ let src;
                /*byte**/ let dig = number.$v.DigitsPtr;
                /*char*/ let ch;
                section = $.$srn.System.Number.FindSection(format, dig.GetAt(0) === 0 ? 2 : number.$v.IsNegative ? 1 : 0);
                while(true)
                {
                    digitCount = 0;
                    decimalPos = -1;
                    firstDigit = 2147483647;
                    lastDigit = 0;
                    scientific = false;
                    thousandPos = -1;
                    thousandSeps = false;
                    scaleAdjust = 0;
                    src = section;
                    /*fixed*/ 
                    {
                        /*char**/ let pFormat = $.$spc.System.Runtime.InteropServices.MemoryMarshal.GetReference$1($.$spc.System.Char, format);
                        while(src < format.Length && (ch = pFormat.GetAt(src++)) !== 0 && ch !== /*;*/ 59)
                        {
                            switch(ch)
                            {
                                case /*#*/ 35:
                                digitCount++;
                                break;
                                case /*0*/ 48:
                                if (firstDigit === 2147483647)
                                {
                                    firstDigit = digitCount;
                                }
                                digitCount++;
                                lastDigit = digitCount;
                                break;
                                case /*.*/ 46:
                                if (decimalPos < 0)
                                {
                                    decimalPos = digitCount;
                                }
                                break;
                                case /*,*/ 44:
                                if (digitCount > 0 && decimalPos < 0)
                                {
                                    if (thousandPos >= 0)
                                    {
                                        if (thousandPos === digitCount)
                                        {
                                            thousandCount++;
                                            break;
                                        }
                                        thousandSeps = true;
                                    }
                                    thousandPos = digitCount;
                                    thousandCount = 1;
                                }
                                break;
                                case /*%*/ 37:
                                scaleAdjust += 2;
                                break;
                                case /*\u2030*/ 8240:
                                scaleAdjust += 3;
                                break;
                                case /*'*/ 39:
                                case /*\"*/ 34:
                                while(src < format.Length && pFormat.GetAt(src) !== 0 && pFormat.GetAt(src++) !== ch)
                                {
                                }
                                break;
                                case /*\\*/ 92:
                                if (src < format.Length && pFormat.GetAt(src) !== 0)
                                {
                                    src++;
                                }
                                break;
                                case /*E*/ 69:
                                case /*e*/ 101:
                                if ((src < format.Length && pFormat.GetAt(src) === /*0*/ 48) || (((src + 1) | 0) < format.Length && (pFormat.GetAt(src) === /*+*/ 43 || pFormat.GetAt(src) === /*-*/ 45) && pFormat.GetAt(((src + 1) | 0)) === /*0*/ 48))
                                {
                                    while(++src < format.Length && pFormat.GetAt(src) === /*0*/ 48)
                                    {
                                    }
                                    scientific = true;
                                }
                                break;
                            }
                        }
                    }
                    if (decimalPos < 0)
                    {
                        decimalPos = digitCount;
                    }
                    if (thousandPos >= 0)
                    {
                        if (thousandPos === decimalPos)
                        {
                            scaleAdjust -= ((thousandCount * 3) | 0);
                        }
                        else 
                        {
                            thousandSeps = true;
                        }
                    }
                    if (dig.GetAt(0) !== 0)
                    {
                        number.$v.Scale += scaleAdjust;
                        /*int*/ let pos = scientific ? digitCount : ((((number.$v.Scale + digitCount) | 0) - decimalPos) | 0);
                        $.$srn.System.Number.RoundNumber(number, pos, false);
                        if (dig.GetAt(0) === 0)
                        {
                            src = $.$srn.System.Number.FindSection(format, 2);
                            if (src !== section)
                            {
                                section = src;
                                continue;
                            }
                        }
                    }
                    else 
                    {
                        if (number.$v.Kind !== 3/*NumberBufferKind.FloatingPoint*/)
                        {
                            number.$v.IsNegative = false;
                        }
                        number.$v.Scale = 0;
                    }
                    break;
                }
                firstDigit = firstDigit < decimalPos ? ((decimalPos - firstDigit) | 0) : 0;
                lastDigit = lastDigit > decimalPos ? ((decimalPos - lastDigit) | 0) : 0;
                if (scientific)
                {
                    digPos = decimalPos;
                    adjust = 0;
                }
                else 
                {
                    digPos = number.$v.Scale > decimalPos ? number.$v.Scale : decimalPos;
                    adjust = ((number.$v.Scale - decimalPos) | 0);
                }
                src = section;
                /*Span<int>*/ let thousandsSepPos = $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.StackAllocSpan($.$spc.System.Int32, 4, null);
                /*int*/ let thousandsSepCtr = -1;
                if (thousandSeps)
                {
                    if (info.NumberGroupSeparator.length > 0)
                    {
                        /*int[]*/ let groupDigits = $.$srn.System.Number.NumberGroupSizes(info);
                        /*int*/ let groupSizeIndex = 0;
                        /*int*/ let groupTotalSizeCount = 0;
                        /*int*/ let groupSizeLen = groupDigits.length;
                        if (groupSizeLen !== 0)
                        {
                            groupTotalSizeCount = $.$spc.System.Array.$ReadT1.call(groupDigits, groupSizeIndex);
                        }
                        /*int*/ let groupSize = groupTotalSizeCount;
                        /*int*/ let totalDigits = ((digPos + ((adjust < 0) ? adjust : 0)) | 0);
                        /*int*/ let numDigits = (firstDigit > totalDigits) ? firstDigit : totalDigits;
                        while(numDigits > groupTotalSizeCount)
                        {
                            if (groupSize === 0)
                            {
                                break;
                            }
                            ++thousandsSepCtr;
                            if (thousandsSepCtr >= thousandsSepPos.Length)
                            {
                                /*var*/ let newThousandsSepPos = $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$spc.System.Int32), null, [((thousandsSepPos.Length * 2) | 0)], null);
                                thousandsSepPos.CopyTo($.$spc.System.Span$$($.$spc.System.Int32).op_Implicit(newThousandsSepPos));
                                thousandsSepPos = $.$spc.System.Span$$($.$spc.System.Int32).op_Implicit(newThousandsSepPos);
                            }
                            thousandsSepPos.get_Item(thousandsSepCtr).$v = groupTotalSizeCount;
                            if (groupSizeIndex < ((groupSizeLen - 1) | 0))
                            {
                                groupSizeIndex++;
                                groupSize = $.$spc.System.Array.$ReadT1.call(groupDigits, groupSizeIndex);
                            }
                            groupTotalSizeCount += groupSize;
                        }
                    }
                }
                if (number.$v.IsNegative && (section === 0) && (number.$v.Scale !== 0))
                {
                    vlb.$v.Append$1($.$srn.System.Number.NegativeSignTChar(TChar, info));
                }
                /*bool*/ let decimalWritten = false;
                /*fixed*/ 
                {
                    /*char**/ let pFormat = $.$spc.System.Runtime.InteropServices.MemoryMarshal.GetReference$1($.$spc.System.Char, format);
                    /*byte**/ let cur = dig;
                    while(src < format.Length && (ch = pFormat.GetAt(src++)) !== 0 && ch !== /*;*/ 59)
                    {
                        if (adjust > 0)
                        {
                            switch(ch)
                            {
                                case /*#*/ 35:
                                case /*0*/ 48:
                                case /*.*/ 46:
                                while(adjust > 0)
                                {
                                    vlb.$v.Append(TChar.System$IUtfChar$$$CastFrom$1(cur.$v !== 0 ? ((() =>
                                    {
                                        var $oldp = cur.Clone();
                                        cur = cur.Add(1);
                                        return $oldp;
                                    })().$v) : /*0*/ 48));
                                    if (thousandSeps && digPos > 1 && thousandsSepCtr >= 0)
                                    {
                                        if (digPos === ((thousandsSepPos.get_Item(thousandsSepCtr).$v + 1) | 0))
                                        {
                                            vlb.$v.Append$1($.$srn.System.Number.NumberGroupSeparatorTChar(TChar, info));
                                            thousandsSepCtr--;
                                        }
                                    }
                                    digPos--;
                                    adjust--;
                                }
                                break;
                            }
                        }
                        switch(ch)
                        {
                            case /*#*/ 35:
                            case /*0*/ 48:
                            {
                                if (adjust < 0)
                                {
                                    adjust++;
                                    ch = digPos <= firstDigit ? /*0*/ 48 : /*\u0000*/ 0;
                                }
                                else 
                                {
                                    ch = cur.$v !== 0 ? ((() =>
                                    {
                                        var $oldp = cur.Clone();
                                        cur = cur.Add(1);
                                        return $oldp;
                                    })().$v) : digPos > lastDigit ? /*0*/ 48 : /*\u0000*/ 0;
                                }
                                if (ch !== 0)
                                {
                                    vlb.$v.Append(TChar.System$IUtfChar$$$CastFrom$1(ch));
                                    if (thousandSeps && digPos > 1 && thousandsSepCtr >= 0)
                                    {
                                        if (digPos === ((thousandsSepPos.get_Item(thousandsSepCtr).$v + 1) | 0))
                                        {
                                            vlb.$v.Append$1($.$srn.System.Number.NumberGroupSeparatorTChar(TChar, info));
                                            thousandsSepCtr--;
                                        }
                                    }
                                }
                                digPos--;
                                break;
                            }
                            case /*.*/ 46:
                            {
                                if (digPos !== 0 || decimalWritten)
                                {
                                    break;
                                }
                                if (lastDigit < 0 || (decimalPos < digitCount && cur.$v !== 0))
                                {
                                    vlb.$v.Append$1($.$srn.System.Number.NumberDecimalSeparatorTChar(TChar, info));
                                    decimalWritten = true;
                                }
                                break;
                            }
                            case /*\u2030*/ 8240:
                            vlb.$v.Append$1($.$srn.System.Number.PerMilleSymbolTChar(TChar, info));
                            break;
                            case /*%*/ 37:
                            vlb.$v.Append$1($.$srn.System.Number.PercentSymbolTChar(TChar, info));
                            break;
                            case /*,*/ 44:
                            break;
                            case /*'*/ 39:
                            case /*\"*/ 34:
                            while(src < format.Length && pFormat.GetAt(src) !== 0 && pFormat.GetAt(src) !== ch)
                            {
                                $.$srn.System.Number.AppendUnknownChar(TChar, vlb, pFormat.GetAt(src++));
                            }
                            if (src < format.Length && pFormat.GetAt(src) !== 0)
                            {
                                src++;
                            }
                            break;
                            case /*\\*/ 92:
                            if (src < format.Length && pFormat.GetAt(src) !== 0)
                            {
                                $.$srn.System.Number.AppendUnknownChar(TChar, vlb, pFormat.GetAt(src++));
                            }
                            break;
                            case /*E*/ 69:
                            case /*e*/ 101:
                            {
                                /*bool*/ let positiveSign = false;
                                /*int*/ let i = 0;
                                if (scientific)
                                {
                                    if (src < format.Length && pFormat.GetAt(src) === /*0*/ 48)
                                    {
                                        i++;
                                    }
                                    else if (((src + 1) | 0) < format.Length && pFormat.GetAt(src) === /*+*/ 43 && pFormat.GetAt(((src + 1) | 0)) === /*0*/ 48)
                                    {
                                        positiveSign = true;
                                    }
                                    else if (((src + 1) | 0) < format.Length && pFormat.GetAt(src) === /*-*/ 45 && pFormat.GetAt(((src + 1) | 0)) === /*0*/ 48)
                                    {
                                    }
                                    else 
                                    {
                                        vlb.$v.Append(TChar.System$IUtfChar$$$CastFrom$1(ch));
                                        break;
                                    }
                                    while(++src < format.Length && pFormat.GetAt(src) === /*0*/ 48)
                                    {
                                        i++;
                                    }
                                    if (i > 10)
                                    {
                                        i = 10;
                                    }
                                    /*int*/ let exp = dig.GetAt(0) === 0 ? 0 : ((number.$v.Scale - decimalPos) | 0);
                                    $.$srn.System.Number.FormatExponent(TChar, vlb, info, exp, ch, i, positiveSign);
                                    scientific = false;
                                }
                                else 
                                {
                                    vlb.$v.Append(TChar.System$IUtfChar$$$CastFrom$1(ch));
                                    if (src < format.Length)
                                    {
                                        if (pFormat.GetAt(src) === /*+*/ 43 || pFormat.GetAt(src) === /*-*/ 45)
                                        {
                                            $.$srn.System.Number.AppendUnknownChar(TChar, vlb, pFormat.GetAt(src++));
                                        }
                                        while(src < format.Length && pFormat.GetAt(src) === /*0*/ 48)
                                        {
                                            $.$srn.System.Number.AppendUnknownChar(TChar, vlb, pFormat.GetAt(src++));
                                        }
                                    }
                                }
                                break;
                            }
                            default:
                            $.$srn.System.Number.AppendUnknownChar(TChar, vlb, ch);
                            break;
                        }
                    }
                }
                if (number.$v.IsNegative && (section === 0) && (number.$v.Scale === 0) && (vlb.$v.Length > 0))
                {
                    vlb.$v.Insert(0, $.$srn.System.Number.NegativeSignTChar(TChar, info));
                }
            }
            static /*void */ FormatCurrency(TChar, /*ref ValueListBuilder<TChar>*/ vlb, /*ref NumberBuffer*/ number, /*int*/ nMaxDigits, /*NumberFormatInfo*/ info)
            {
                $.$spc.System.Diagnostics.Debug.Assert$1((TChar.$z??4) === $.$spc.System.Char.$z || (TChar.$z??4) === $.$spc.System.Byte.$z, "sizeof(TChar) == sizeof(char) || sizeof(TChar) == sizeof(byte)");
                /*string*/ let fmt = number.$v.IsNegative ? $.$spc.System.Array.$ReadT1.call($.$srn.System.Number.s_negCurrencyFormats, info.CurrencyNegativePattern) : $.$spc.System.Array.$ReadT1.call($.$srn.System.Number.s_posCurrencyFormats, info.CurrencyPositivePattern);
                var $en2 = $.$spc.System.String.GetEnumerator.call(fmt);
                while ($en2.MoveNext())
                {
                    var ch = $en2.Current;
                    {
                        switch(ch)
                        {
                            case /*#*/ 35:
                            $.$srn.System.Number.FormatFixed(TChar, vlb, number, nMaxDigits, $.$srn.System.Number.CurrencyGroupSizes(info), $.$srn.System.Number.CurrencyDecimalSeparatorTChar(TChar, info), $.$srn.System.Number.CurrencyGroupSeparatorTChar(TChar, info));
                            break;
                            case /*-*/ 45:
                            vlb.$v.Append$1($.$srn.System.Number.NegativeSignTChar(TChar, info));
                            break;
                            case /*$*/ 36:
                            vlb.$v.Append$1($.$srn.System.Number.CurrencySymbolTChar(TChar, info));
                            break;
                            default:
                            vlb.$v.Append(TChar.System$IUtfChar$$$CastFrom$1(ch));
                            break;
                        }
                    }
                }
            }
            static /*void */ FormatFixed(TChar, /*ref ValueListBuilder<TChar>*/ vlb, /*ref NumberBuffer*/ number, /*int*/ nMaxDigits, /*int[]?*/ groupDigits, /*ReadOnlySpan<TChar>*/ sDecimal, /*ReadOnlySpan<TChar>*/ sGroup)
            {
                $.$spc.System.Diagnostics.Debug.Assert$1((TChar.$z??4) === $.$spc.System.Char.$z || (TChar.$z??4) === $.$spc.System.Byte.$z, "sizeof(TChar) == sizeof(char) || sizeof(TChar) == sizeof(byte)");
                /*int*/ let digPos = number.$v.Scale;
                /*byte**/ let dig = number.$v.DigitsPtr;
                if (digPos > 0)
                {
                    if (groupDigits !== null)
                    {
                        /*int*/ let groupSizeIndex = 0;
                        /*int*/ let bufferSize = digPos;
                        /*int*/ let groupSize = 0;
                        if (groupDigits.length !== 0)
                        {
                            /*int*/ let groupSizeCount = $.$spc.System.Array.$ReadT1.call(groupDigits, groupSizeIndex);
                            while(digPos > groupSizeCount)
                            {
                                groupSize = $.$spc.System.Array.$ReadT1.call(groupDigits, groupSizeIndex);
                                if (groupSize === 0)
                                {
                                    break;
                                }
                                bufferSize += sGroup.Length;
                                if (groupSizeIndex < ((groupDigits.length - 1) | 0))
                                {
                                    groupSizeIndex++;
                                }
                                groupSizeCount += $.$spc.System.Array.$ReadT1.call(groupDigits, groupSizeIndex);
                                $.$spc.System.ArgumentOutOfRangeException.ThrowIfNegative($.$spc.System.Int32, groupSizeCount | bufferSize, $.$spc.System.String.Empty);
                            }
                            groupSize = groupSizeCount === 0 ? 0 : $.$spc.System.Array.$ReadT1.call(groupDigits, 0);
                        }
                        groupSizeIndex = 0;
                        /*int*/ let digitCount = 0;
                        /*int*/ let digLength = number.$v.DigitsCount;
                        /*int*/ let digStart = (digPos < digLength) ? digPos : digLength;
                        /*fixed*/ 
                        {
                            /*TChar**/ let spanPtr = $.$spc.System.Runtime.InteropServices.MemoryMarshal.GetReference(TChar, vlb.$v.AppendSpan(bufferSize));
                            /*TChar**/ let p = spanPtr.Add(bufferSize).Add(-1);
                            for(/*int*/ let i = ((digPos - 1) | 0); i >= 0; i--)
                            {
                                ((() =>
                                {
                                    var $oldp = p.Clone();
                                    p = p.Add(-1);
                                    return $oldp;
                                })()).$v = TChar.System$IUtfChar$$$CastFrom$1((i < digStart) ? dig.GetAt(i) : /*0*/ 48);
                                if (groupSize > 0)
                                {
                                    digitCount++;
                                    if ((digitCount === groupSize) && (i !== 0))
                                    {
                                        for(/*int*/ let j = ((sGroup.Length - 1) | 0); j >= 0; j--)
                                        {
                                            ((() =>
                                            {
                                                var $oldp = p.Clone();
                                                p = p.Add(-1);
                                                return $oldp;
                                            })()).$v = sGroup.get_Item(j).$v;
                                        }
                                        if (groupSizeIndex < ((groupDigits.length - 1) | 0))
                                        {
                                            groupSizeIndex++;
                                            groupSize = $.$spc.System.Array.$ReadT1.call(groupDigits, groupSizeIndex);
                                        }
                                        digitCount = 0;
                                    }
                                }
                            }
                            $.$spc.System.Diagnostics.Debug.Assert$1($.$spc.NetJs.RefOrPointer.Compare(p, spanPtr.Add(-1)) >= 0, "Underflow");
                            dig = dig.Add(digStart);
                        }
                    }
                    else 
                    {
                        do
                        {
                            vlb.$v.Append(TChar.System$IUtfChar$$$CastFrom$1(dig.$v !== 0 ? ((() =>
                            {
                                var $oldp = dig.Clone();
                                dig = dig.Add(1);
                                return $oldp;
                            })().$v) : /*0*/ 48));
                        }
                        while(--digPos > 0);
                    }
                }
                else 
                {
                    vlb.$v.Append(TChar.System$IUtfChar$$$CastFrom$1(/*0*/ 48));
                }
                if (nMaxDigits > 0)
                {
                    vlb.$v.Append$1(sDecimal);
                    if ((digPos < 0) && (nMaxDigits > 0))
                    {
                        /*int*/ let zeroes = $.$spc.System.Math.Min$4(-digPos, nMaxDigits);
                        for(/*int*/ let i = 0; i < zeroes; i++)
                        {
                            vlb.$v.Append(TChar.System$IUtfChar$$$CastFrom$1(/*0*/ 48));
                        }
                        digPos += zeroes;
                        nMaxDigits -= zeroes;
                    }
                    while(nMaxDigits > 0)
                    {
                        vlb.$v.Append(TChar.System$IUtfChar$$$CastFrom$1((dig.$v !== 0) ? ((() =>
                        {
                            var $oldp = dig.Clone();
                            dig = dig.Add(1);
                            return $oldp;
                        })().$v) : /*0*/ 48));
                        nMaxDigits--;
                    }
                }
            }
            static /*void */ AppendUnknownChar(TChar, /*ref ValueListBuilder<TChar>*/ vlb, /*char*/ ch)
            {
                $.$spc.System.Diagnostics.Debug.Assert$1((TChar.$z??4) === $.$spc.System.Char.$z || (TChar.$z??4) === $.$spc.System.Byte.$z, "sizeof(TChar) == sizeof(char) || sizeof(TChar) == sizeof(byte)");
                if ((TChar.$z??4) === $.$spc.System.Char.$z || $.$spc.System.Char.IsAscii(ch))
                {
                    vlb.$v.Append(TChar.System$IUtfChar$$$CastFrom$1(ch));
                }
                else 
                {
                    AppendNonAsciiBytes(vlb, ch);
                }
                /*static void*/  function AppendNonAsciiBytes(/*ref ValueListBuilder<TChar>*/ vlb, /*char*/ ch)
                {
                    /*var*/ let r = new $.$spc.System.Text.Rune().$ctor$2(ch);
                    r.EncodeToUtf8($.$spc.System.Runtime.InteropServices.MemoryMarshal.AsBytes(TChar, vlb.$v.AppendSpan(r.Utf8SequenceLength)));
                }
            }
            static /*void */ FormatNumber(TChar, /*ref ValueListBuilder<TChar>*/ vlb, /*ref NumberBuffer*/ number, /*int*/ nMaxDigits, /*NumberFormatInfo*/ info)
            {
                $.$spc.System.Diagnostics.Debug.Assert$1((TChar.$z??4) === $.$spc.System.Char.$z || (TChar.$z??4) === $.$spc.System.Byte.$z, "sizeof(TChar) == sizeof(char) || sizeof(TChar) == sizeof(byte)");
                /*string*/ let fmt = number.$v.IsNegative ? $.$spc.System.Array.$ReadT1.call($.$srn.System.Number.s_negNumberFormats, info.NumberNegativePattern) : "#"/*PosNumberFormat*/;
                var $en2 = $.$spc.System.String.GetEnumerator.call(fmt);
                while ($en2.MoveNext())
                {
                    var ch = $en2.Current;
                    {
                        switch(ch)
                        {
                            case /*#*/ 35:
                            $.$srn.System.Number.FormatFixed(TChar, vlb, number, nMaxDigits, $.$srn.System.Number.NumberGroupSizes(info), $.$srn.System.Number.NumberDecimalSeparatorTChar(TChar, info), $.$srn.System.Number.NumberGroupSeparatorTChar(TChar, info));
                            break;
                            case /*-*/ 45:
                            vlb.$v.Append$1($.$srn.System.Number.NegativeSignTChar(TChar, info));
                            break;
                            default:
                            vlb.$v.Append(TChar.System$IUtfChar$$$CastFrom$1(ch));
                            break;
                        }
                    }
                }
            }
            static /*void */ FormatScientific(TChar, /*ref ValueListBuilder<TChar>*/ vlb, /*ref NumberBuffer*/ number, /*int*/ nMaxDigits, /*NumberFormatInfo*/ info, /*char*/ expChar)
            {
                $.$spc.System.Diagnostics.Debug.Assert$1((TChar.$z??4) === $.$spc.System.Char.$z || (TChar.$z??4) === $.$spc.System.Byte.$z, "sizeof(TChar) == sizeof(char) || sizeof(TChar) == sizeof(byte)");
                /*byte**/ let dig = number.$v.DigitsPtr;
                vlb.$v.Append(TChar.System$IUtfChar$$$CastFrom$1((dig.$v !== 0) ? ((() =>
                {
                    var $oldp = dig.Clone();
                    dig = dig.Add(1);
                    return $oldp;
                })().$v) : /*0*/ 48));
                if (nMaxDigits !== 1)
                {
                    vlb.$v.Append$1($.$srn.System.Number.NumberDecimalSeparatorTChar(TChar, info));
                }
                while(--nMaxDigits > 0)
                {
                    vlb.$v.Append(TChar.System$IUtfChar$$$CastFrom$1((dig.$v !== 0) ? ((() =>
                    {
                        var $oldp = dig.Clone();
                        dig = dig.Add(1);
                        return $oldp;
                    })().$v) : /*0*/ 48));
                }
                /*int*/ let e = number.$v.Digits.get_Item(0).$v === 0 ? 0 : ((number.$v.Scale - 1) | 0);
                $.$srn.System.Number.FormatExponent(TChar, vlb, info, e, expChar, 3, true);
            }
            static /*void */ FormatExponent(TChar, /*ref ValueListBuilder<TChar>*/ vlb, /*NumberFormatInfo*/ info, /*int*/ value, /*char*/ expChar, /*int*/ minDigits, /*bool*/ positiveSign)
            {
                $.$spc.System.Diagnostics.Debug.Assert$1((TChar.$z??4) === $.$spc.System.Char.$z || (TChar.$z??4) === $.$spc.System.Byte.$z, "sizeof(TChar) == sizeof(char) || sizeof(TChar) == sizeof(byte)");
                vlb.$v.Append(TChar.System$IUtfChar$$$CastFrom$1(expChar));
                if (value < 0)
                {
                    vlb.$v.Append$1($.$srn.System.Number.NegativeSignTChar(TChar, info));
                    value = -value;
                }
                else 
                {
                    if (positiveSign)
                    {
                        vlb.$v.Append$1($.$srn.System.Number.PositiveSignTChar(TChar, info));
                    }
                }
                /*TChar**/ let digits = $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.StackAllocPointer(TChar, 10/*MaxUInt32DecDigits*/, null);
                /*TChar**/ let p = $.$srn.System.Number.UInt32ToDecChars(TChar, digits.Add(10/*MaxUInt32DecDigits*/), (value >>> 0), minDigits);
                vlb.$v.Append$1(new ($.$spc.System.ReadOnlySpan$$(TChar))().$ctor$4(p, $.$cast((digits.Add(10/*MaxUInt32DecDigits*/).Subtract(p)), $.$spc.System.Int32)));
            }
            static /*void */ FormatGeneral(TChar, /*ref ValueListBuilder<TChar>*/ vlb, /*ref NumberBuffer*/ number, /*int*/ nMaxDigits, /*NumberFormatInfo*/ info, /*char*/ expChar, /*bool*/ suppressScientific)
            {
                $.$spc.System.Diagnostics.Debug.Assert$1((TChar.$z??4) === $.$spc.System.Char.$z || (TChar.$z??4) === $.$spc.System.Byte.$z, "sizeof(TChar) == sizeof(char) || sizeof(TChar) == sizeof(byte)");
                /*int*/ let digPos = number.$v.Scale;
                /*bool*/ let scientific = false;
                if (!suppressScientific)
                {
                    if (digPos > nMaxDigits || digPos < -3)
                    {
                        digPos = 1;
                        scientific = true;
                    }
                }
                /*byte**/ let dig = number.$v.DigitsPtr;
                if (digPos > 0)
                {
                    do
                    {
                        vlb.$v.Append(TChar.System$IUtfChar$$$CastFrom$1((dig.$v !== 0) ? ((() =>
                        {
                            var $oldp = dig.Clone();
                            dig = dig.Add(1);
                            return $oldp;
                        })().$v) : /*0*/ 48));
                    }
                    while(--digPos > 0);
                }
                else 
                {
                    vlb.$v.Append(TChar.System$IUtfChar$$$CastFrom$1(/*0*/ 48));
                }
                if (dig.$v !== 0 || digPos < 0)
                {
                    vlb.$v.Append$1($.$srn.System.Number.NumberDecimalSeparatorTChar(TChar, info));
                    while(digPos < 0)
                    {
                        vlb.$v.Append(TChar.System$IUtfChar$$$CastFrom$1(/*0*/ 48));
                        digPos++;
                    }
                    while(dig.$v !== 0)
                    {
                        vlb.$v.Append(TChar.System$IUtfChar$$$CastFrom((() =>
                        {
                            var $oldp = dig.Clone();
                            dig = dig.Add(1);
                            return $oldp;
                        })().$v));
                    }
                }
                if (scientific)
                {
                    $.$srn.System.Number.FormatExponent(TChar, vlb, info, ((number.$v.Scale - 1) | 0), expChar, 2, true);
                }
            }
            static /*void */ FormatPercent(TChar, /*ref ValueListBuilder<TChar>*/ vlb, /*ref NumberBuffer*/ number, /*int*/ nMaxDigits, /*NumberFormatInfo*/ info)
            {
                $.$spc.System.Diagnostics.Debug.Assert$1((TChar.$z??4) === $.$spc.System.Char.$z || (TChar.$z??4) === $.$spc.System.Byte.$z, "sizeof(TChar) == sizeof(char) || sizeof(TChar) == sizeof(byte)");
                /*string*/ let fmt = number.$v.IsNegative ? $.$spc.System.Array.$ReadT1.call($.$srn.System.Number.s_negPercentFormats, info.PercentNegativePattern) : $.$spc.System.Array.$ReadT1.call($.$srn.System.Number.s_posPercentFormats, info.PercentPositivePattern);
                var $en2 = $.$spc.System.String.GetEnumerator.call(fmt);
                while ($en2.MoveNext())
                {
                    var ch = $en2.Current;
                    {
                        switch(ch)
                        {
                            case /*#*/ 35:
                            $.$srn.System.Number.FormatFixed(TChar, vlb, number, nMaxDigits, $.$srn.System.Number.PercentGroupSizes(info), $.$srn.System.Number.PercentDecimalSeparatorTChar(TChar, info), $.$srn.System.Number.PercentGroupSeparatorTChar(TChar, info));
                            break;
                            case /*-*/ 45:
                            vlb.$v.Append$1($.$srn.System.Number.NegativeSignTChar(TChar, info));
                            break;
                            case /*%*/ 37:
                            vlb.$v.Append$1($.$srn.System.Number.PercentSymbolTChar(TChar, info));
                            break;
                            default:
                            vlb.$v.Append(TChar.System$IUtfChar$$$CastFrom$1(ch));
                            break;
                        }
                    }
                }
            }
            static /*void */ RoundNumber(/*ref NumberBuffer*/ number, /*int*/ pos, /*bool*/ isCorrectlyRounded)
            {
                /*byte**/ let dig = number.$v.DigitsPtr;
                /*int*/ let i = 0;
                while(i < pos && dig.GetAt(i) !== /*\u0000*/ 0)
                {
                    i++;
                }
                if ((i === pos) && ShouldRoundUp(dig, i, number.$v.Kind, isCorrectlyRounded))
                {
                    while(i > 0 && dig.GetAt(((i - 1) | 0)) === /*9*/ 57)
                    {
                        i--;
                    }
                    if (i > 0)
                    {
                        dig.get_Item(((i - 1) | 0)).$v++;
                    }
                    else 
                    {
                        number.$v.Scale++;
                        dig.SetAt((/*1*/ 49), 0);
                        i = 1;
                    }
                }
                else 
                {
                    while(i > 0 && dig.GetAt(((i - 1) | 0)) === /*0*/ 48)
                    {
                        i--;
                    }
                }
                if (i === 0)
                {
                    if (number.$v.Kind !== 3/*NumberBufferKind.FloatingPoint*/)
                    {
                        number.$v.IsNegative = false;
                    }
                    number.$v.Scale = 0;
                }
                dig.SetAt((/*\u0000*/ 0), i);
                number.$v.DigitsCount = i;
                number.$v.CheckConsistency();
                /*static bool*/  function ShouldRoundUp(/*byte**/ dig, /*int*/ i, /*NumberBufferKind*/ numberKind, /*bool*/ isCorrectlyRounded)
                {
                    /*byte*/ let digit = dig.GetAt(i);
                    if ((digit === /*\u0000*/ 0) || isCorrectlyRounded)
                    {
                        return false;
                    }
                    return digit >= /*5*/ 53;
                }
            }
            static /*int */ FindSection(/*ReadOnlySpan<char>*/ format, /*int*/ section)
            {
                /*int*/ let src;
                /*char*/ let ch;
                if (section === 0)
                {
                    return 0;
                }
                /*fixed*/ 
                {
                    /*char**/ let pFormat = $.$spc.System.Runtime.InteropServices.MemoryMarshal.GetReference$1($.$spc.System.Char, format);
                    src = 0;
                    while(true)
                    {
                        if (src >= format.Length)
                        {
                            return 0;
                        }
                        let $switchJumpState1;
                        $switchJumpStart1: while(true)
                        {
                            let $switch1 = $switchJumpState1 ?? (ch = pFormat.GetAt(src++));
                            switch($switch1)
                            {
                                case /*'*/ 39:
                                case /*\"*/ 34:
                                while(src < format.Length && pFormat.GetAt(src) !== 0 && pFormat.GetAt(src++) !== ch)
                                {
                                }
                                break;
                                case /*\\*/ 92:
                                if (src < format.Length && pFormat.GetAt(src) !== 0)
                                {
                                    src++;
                                }
                                break;
                                case /*;*/ 59:
                                if (--section !== 0)
                                {
                                    break;
                                }
                                if (src < format.Length && pFormat.GetAt(src) !== 0 && pFormat.GetAt(src) !== /*;*/ 59)
                                {
                                    return src;
                                }
                                $switchJumpState1 = /*\u0000*/ 0; /*goto case '\0'*/
                                continue $switchJumpStart1;
                                case /*\u0000*/ 0:
                                return 0;
                            }
                            break;
                        }
                    }
                }
            }
            static /*int[] */ NumberGroupSizes(/*this NumberFormatInfo*/ info)
            {
                return info.NumberGroupSizes;
            }
            static /*int[] */ CurrencyGroupSizes(/*this NumberFormatInfo*/ info)
            {
                return info.CurrencyGroupSizes;
            }
            static /*int[] */ PercentGroupSizes(/*this NumberFormatInfo*/ info)
            {
                return info.PercentGroupSizes;
            }
            /*NumberStyles*/ static InvalidNumberStyles = -2048;
            static /*ReadOnlySpan<uint> */ get UInt32PowersOfTen()
            {
                return this.$cacheUInt32PowersOfTen ??= new ($.$spc.System.ReadOnlySpan$$($.$spc.System.UInt32))().$ctor$2([ 1, 10, 100, 1000, 10000, 100000, 1000000, 10000000, 100000000, 1000000000 ]);
            }
            static /*void */ ThrowOverflowOrFormatException(/*ParsingStatus*/ status)
            {
                throw $.$srn.System.Number.GetException(status);
            }
            static /*Exception */ GetException(/*ParsingStatus*/ status)
            {
                return status === 1/*ParsingStatus.Failed*/ ? new $.$spc.System.FormatException().$ctor$10($.$srn.System.SR.Overflow_ParseBigInteger) : new $.$spc.System.OverflowException().$ctor$14($.$srn.System.SR.Overflow_ParseBigInteger);
            }
            static /*bool */ TryValidateParseStyleInteger(/*NumberStyles*/ style, /*out ArgumentException?*/ e)
            {
                if ((style & -2048/*InvalidNumberStyles*/) !== 0)
                {
                    e.$v = new $.$spc.System.ArgumentException().$ctor$13($.$srn.System.SR.Argument_InvalidNumberStyles, "style");
                    return false;
                }
                if ((style & 512/*NumberStyles.AllowHexSpecifier*/) !== 0)
                {
                    if ((style & ~515/*NumberStyles.HexNumber*/) !== 0)
                    {
                        e.$v = new $.$spc.System.ArgumentException().$ctor$13($.$srn.System.SR.Argument_InvalidHexStyle, "style");
                        return false;
                    }
                }
                e.$v = null;
                return true;
            }
            static /*ParsingStatus */ TryParseBigInteger(/*ReadOnlySpan<char>*/ value, /*NumberStyles*/ style, /*NumberFormatInfo*/ info, /*out BigInteger*/ result)
            {
                /*ArgumentException?*/ let e;
                if (!$.$srn.System.Number.TryValidateParseStyleInteger(style, $.$ref(() => e, ($v) => e = $v, $.$spc.System.ArgumentException)))
                {
                    throw e;
                }
                if ((style & 512/*NumberStyles.AllowHexSpecifier*/) !== 0)
                {
                    return $.$srn.System.Number.TryParseBigIntegerHexOrBinaryNumberStyle($.$srn.System.BigIntegerHexParser$$($.$spc.System.Char), $.$spc.System.Char, value, style, result);
                }
                if ((style & 1024/*NumberStyles.AllowBinarySpecifier*/) !== 0)
                {
                    return $.$srn.System.Number.TryParseBigIntegerHexOrBinaryNumberStyle($.$srn.System.BigIntegerBinaryParser$$($.$spc.System.Char), $.$spc.System.Char, value, style, result);
                }
                return $.$srn.System.Number.TryParseBigIntegerNumber(value, style, info, result);
            }
            static /*ParsingStatus */ TryParseBigIntegerNumber(/*ReadOnlySpan<char>*/ value, /*NumberStyles*/ style, /*NumberFormatInfo*/ info, /*out BigInteger*/ result)
            {
                /*scoped Span<byte>*/ let buffer;
                /*byte[]?*/ let arrayFromPool = null;
                if (value.Length === 0)
                {
                    result.$v = new $.$srn.System.Numerics.BigInteger();
                    return 1/*ParsingStatus.Failed*/;
                }
                if (value.Length < 255)
                {
                    buffer = $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.StackAllocSpan($.$spc.System.Byte, ((((value.Length + 1) | 0) + 1) | 0), null);
                }
                else 
                {
                    buffer = $.$spc.System.Span$$($.$spc.System.Byte).op_Implicit(arrayFromPool = $.$spc.System.Buffers.ArrayPool$$($.$spc.System.Byte).Shared.Rent(((((value.Length + 1) | 0) + 1) | 0)));
                }
                /*ParsingStatus*/ let ret;
                /*fixed*/ 
                {
                    /*byte**/ let ptr = buffer.GetPinnableReference();
                    /*NumberBuffer*/ let number = new $.$srn.System.Number.NumberBuffer().$ctor$3(1/*NumberBufferKind.Integer*/, buffer);
                    if (!$.$srn.System.Number.TryStringToNumber($.$srn.System.Utf16Char, $.$spc.System.Runtime.InteropServices.MemoryMarshal.Cast$1($.$spc.System.Char, $.$srn.System.Utf16Char, value), style, $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateObjectReferenceT($.$srn.System.Number.NumberBuffer, () => number, ($v) => number = $v, null), info))
                    {
                        result.$v = new $.$srn.System.Numerics.BigInteger();
                        ret = 1/*ParsingStatus.Failed*/;
                    }
                    else 
                    {
                        ret = $.$srn.System.Number.NumberToBigInteger($.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateObjectReferenceT($.$srn.System.Number.NumberBuffer, () => number, ($v) => number = $v, null), result);
                    }
                }
                if (arrayFromPool !== null)
                {
                    $.$spc.System.Buffers.ArrayPool$$($.$spc.System.Byte).Shared.Return(arrayFromPool, false);
                }
                return ret;
            }
            static /*BigInteger */ ParseBigInteger(/*ReadOnlySpan<char>*/ value, /*NumberStyles*/ style, /*NumberFormatInfo*/ info)
            {
                /*ArgumentException?*/ let e;
                if (!$.$srn.System.Number.TryValidateParseStyleInteger(style, $.$ref(() => e, ($v) => e = $v, $.$spc.System.ArgumentException)))
                {
                    throw e;
                }
                /*BigInteger*/ let result;
                /*ParsingStatus*/ let status = $.$srn.System.Number.TryParseBigInteger(value, style, info, $.$ref(() => result, ($v) => result = $v, $.$srn.System.Numerics.BigInteger));
                if (status !== 0/*ParsingStatus.OK*/)
                {
                    $.$srn.System.Number.ThrowOverflowOrFormatException(status);
                }
                return result;
            }
            static /*ParsingStatus */ TryParseBigIntegerHexOrBinaryNumberStyle(TParser, TChar, /*ReadOnlySpan<TChar>*/ value, /*NumberStyles*/ style, /*out BigInteger*/ result)
            {
                /*int*/ let whiteIndex;
                /*uint*/ let signBits;
                /*int*/ let leadingBitsCount;
                /*uint*/ let leading;
                /*int*/ let wholeBlockCount;
                /*int*/ let totalUIntCount;
                /*uint[]*/ let bits;
                /*Span<uint>*/ let wholeBlockDestination;
                let $gotoJumpState1 = 0;
                $gotoJumpStart1: while(true)
                {
                    switch($gotoJumpState1)
                    {
                        case 0:
                        {
                            if ((style & 1/*NumberStyles.AllowLeadingWhite*/) !== 0)
                            {
                                for(whiteIndex = 0; whiteIndex < value.Length; whiteIndex++)
                                {
                                    if (!$.$srn.System.Number.IsWhite($.$spc.System.UInt32.CreateTruncating(TChar, value.get_Item(whiteIndex).$v)))
                                    {
                                        break;
                                    }
                                }
                                let $t2 = value;
                                value = $t2.Slice$1(whiteIndex, $t2.Length - whiteIndex);
                            }
                            if ((style & 2/*NumberStyles.AllowTrailingWhite*/) !== 0)
                            {
                                for(whiteIndex = ((value.Length - 1) | 0); whiteIndex >= 0; whiteIndex--)
                                {
                                    if (!$.$srn.System.Number.IsWhite($.$spc.System.UInt32.CreateTruncating(TChar, value.get_Item(whiteIndex).$v)))
                                    {
                                        break;
                                    }
                                }
                                let $t2 = value;
                                value = $t2.Slice$1(0, (((whiteIndex + 1) | 0)));
                            }
                            if (value.IsEmpty)
                            {
                                $gotoJumpState1 = 1; /*goto FailExit*/
                                continue $gotoJumpStart1;
                            }
                            signBits = TParser.System$IBigIntegerHexOrBinaryParser$$$$GetSignBitsIfValid($.$spc.System.UInt32.CreateTruncating(TChar, value.get_Item(0).$v));
                            leadingBitsCount = value.Length % TParser.System$IBigIntegerHexOrBinaryParser$$$$DigitsPerBlock;
                            leading = signBits;
                            if (leadingBitsCount !== 0)
                            {
                                let $t2 = value;
                                if (!TParser.System$IBigIntegerHexOrBinaryParser$$$$TryParseUnalignedBlock($t2.Slice$1(0, leadingBitsCount - 0), $.$ref(() => leading, ($v) => leading = $v, $.$spc.System.UInt32)))
                                {
                                    $gotoJumpState1 = 1; /*goto FailExit*/
                                    continue $gotoJumpStart1;
                                }
                                leading |= (signBits << (((leadingBitsCount * TParser.System$IBigIntegerHexOrBinaryParser$$$$BitsPerDigit) | 0))) >>> 0;
                                let $t4 = value;
                                value = $t4.Slice$1(leadingBitsCount, $t4.Length - leadingBitsCount);
                            }
                            while(!value.IsEmpty && leading === signBits)
                            {
                                let $t2 = value;
                                if (!TParser.System$IBigIntegerHexOrBinaryParser$$$$TryParseSingleBlock($t2.Slice$1(0, TParser.System$IBigIntegerHexOrBinaryParser$$$$DigitsPerBlock - 0), $.$ref(() => leading, ($v) => leading = $v, $.$spc.System.UInt32)))
                                {
                                    $gotoJumpState1 = 1; /*goto FailExit*/
                                    continue $gotoJumpStart1;
                                }
                                let $t4 = value;
                                value = $t4.Slice$1(TParser.System$IBigIntegerHexOrBinaryParser$$$$DigitsPerBlock, $t4.Length - TParser.System$IBigIntegerHexOrBinaryParser$$$$DigitsPerBlock);
                            }
                            if (value.IsEmpty)
                            {
                                if (((leading ^ signBits) | 0) >= 0)
                                {
                                    result.$v = new $.$srn.System.Numerics.BigInteger().$ctor$2((leading | 0));
                                    return 0/*ParsingStatus.OK*/;
                                }
                                else if (leading !== 0)
                                {
                                    result.$v = new $.$srn.System.Numerics.BigInteger().$ctor$11((signBits | 0) | 1, $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$spc.System.UInt32.$type, [ (((leading ^ signBits) - signBits) >>> 0) ], null, null));
                                    return 0/*ParsingStatus.OK*/;
                                }
                                else 
                                {
                                    result.$v = new $.$srn.System.Numerics.BigInteger().$ctor$11(-1, $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$spc.System.UInt32.$type, [ 0, 1 ], null, null));
                                    return 0/*ParsingStatus.OK*/;
                                }
                            }
                            wholeBlockCount = $.trunc(value.Length / TParser.System$IBigIntegerHexOrBinaryParser$$$$DigitsPerBlock);
                            totalUIntCount = ((wholeBlockCount + 1) | 0);
                            if (totalUIntCount > $.$srn.System.Numerics.BigInteger.MaxLength)
                            {
                                result.$v = new $.$srn.System.Numerics.BigInteger();
                                return 2/*ParsingStatus.Overflow*/;
                            }
                            bits = $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$spc.System.UInt32), null, [totalUIntCount], null);
                            wholeBlockDestination = $.$spc.System.MemoryExtensions.AsSpan$9($.$spc.System.UInt32, bits, 0, wholeBlockCount);
                            if (!TParser.System$IBigIntegerHexOrBinaryParser$$$$TryParseWholeBlocks(value, wholeBlockDestination))
                            {
                                $gotoJumpState1 = 1; /*goto FailExit*/
                                continue $gotoJumpStart1;
                            }
                            $.$spc.System.Array.$WriteT1.call(bits, leading, bits.length - 1);
                            if (signBits !== 0)
                            {
                                if ($.$spc.System.MemoryExtensions.ContainsAnyExcept$5($.$spc.System.UInt32, $.$spc.System.Span$$($.$spc.System.UInt32).op_Implicit$2($.$spc.System.MemoryExtensions.AsSpan$8($.$spc.System.UInt32, bits)), 0))
                                {
                                    $.$srn.System.Numerics.NumericsHelpers.DangerousMakeTwosComplement($.$spc.System.Span$$($.$spc.System.UInt32).op_Implicit(bits));
                                }
                                else 
                                {
                                    bits = $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$spc.System.UInt32), null, [((bits.length + 1) | 0)], null);
                                    $.$spc.System.Array.$WriteT1.call(bits, 1, bits.length - 1);
                                }
                                result.$v = new $.$srn.System.Numerics.BigInteger().$ctor$11(-1, bits);
                                return 0/*ParsingStatus.OK*/;
                            }
                            else 
                            {
                                $.$spc.System.Diagnostics.Debug.Assert$1(leading !== 0, "leading != 0");
                                result.$v = new $.$srn.System.Numerics.BigInteger().$ctor$11(1, bits);
                                return 0/*ParsingStatus.OK*/;
                            }
                        }
                        case 1: /*FailExit*/
                        result.$v = new $.$srn.System.Numerics.BigInteger();
                        return 1/*ParsingStatus.Failed*/;
                    }
                    break;
                }
            }
            /*int*/ static BigIntegerParseNaiveThreshold = 1233;
            /*int*/ static BigIntegerParseNaiveThresholdInRecursive = 128;
            static /*ParsingStatus */ NumberToBigInteger(/*ref NumberBuffer*/ number, /*out BigInteger*/ result)
            {
                if (number.$v.Scale === 2147483647/*int.MaxValue*/)
                {
                    result.$v = new $.$srn.System.Numerics.BigInteger();
                    return 2/*ParsingStatus.Overflow*/;
                }
                if (number.$v.Scale < 0)
                {
                    result.$v = new $.$srn.System.Numerics.BigInteger();
                    return 1/*ParsingStatus.Failed*/;
                }
                /*uint[]?*/ let base1E9FromPool = null;
                /*scoped Span<uint>*/ let base1E9;
                {
                    /*ReadOnlySpan<byte>*/ let intDigits = $.$spc.System.Span$$($.$spc.System.Byte).op_Implicit$2(number.$v.Digits.Slice$1(0, $.$spc.System.Math.Min$4(number.$v.Scale, number.$v.DigitsCount)));
                    /*int*/ let intDigitsEnd = $.$spc.System.MemoryExtensions.IndexOf$2($.$spc.System.Byte, intDigits, 0);
                    if (intDigitsEnd < 0)
                    {
                        /*ReadOnlySpan<byte>*/ let fracDigitsSpan = $.$spc.System.Span$$($.$spc.System.Byte).op_Implicit$2(number.$v.Digits.Slice(intDigits.Length));
                        var $en4 = fracDigitsSpan.GetEnumerator();
                        while ($en4.MoveNext())
                        {
                            var digitChar = $en4.Current.$v;
                            {
                                if (digitChar === /*\u0000*/ 0)
                                {
                                    break;
                                }
                                if (digitChar !== /*0*/ 48)
                                {
                                    result.$v = new $.$srn.System.Numerics.BigInteger();
                                    return 1/*ParsingStatus.Failed*/;
                                }
                            }
                        }
                    }
                    else 
                    {
                        intDigits = intDigits.Slice$1(0, intDigitsEnd);
                    }
                    /*int*/ let base1E9Length = $.trunc((((((intDigits.Length + 9/*PowersOf1e9.MaxPartialDigits*/) | 0) - 1) | 0)) / 9/*PowersOf1e9.MaxPartialDigits*/);
                    base1E9 = (base1E9Length <= $.$srn.System.Numerics.BigIntegerCalculator.StackAllocThreshold ? $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.StackAllocSpan($.$spc.System.UInt32, $.$srn.System.Numerics.BigIntegerCalculator.StackAllocThreshold, null) : $.$spc.System.Span$$($.$spc.System.UInt32).op_Implicit(base1E9FromPool = $.$spc.System.Buffers.ArrayPool$$($.$spc.System.UInt32).Shared.Rent(base1E9Length))).Slice$1(0, base1E9Length);
                    /*int*/ let di = base1E9Length;
                    let $t1 = intDigits;
                    /*ReadOnlySpan<byte>*/ let leadingDigits = $t1.Slice$1(0, (intDigits.Length % 9/*PowersOf1e9.MaxPartialDigits*/));
                    if (leadingDigits.Length !== 0)
                    {
                        $.$spc.System.UInt32.TryParse$2(leadingDigits, base1E9.get_Item(--di));
                    }
                    intDigits = intDigits.Slice(leadingDigits.Length);
                    $.$spc.System.Diagnostics.Debug.Assert$1(intDigits.Length % 9/*PowersOf1e9.MaxPartialDigits*/ === 0, "intDigits.Length % PowersOf1e9.MaxPartialDigits == 0");
                    for(--di; di >= 0; --di)
                    {
                        $.$spc.System.UInt32.TryParse$2(intDigits.Slice$1(0, 9/*PowersOf1e9.MaxPartialDigits*/), base1E9.get_Item(di));
                        intDigits = intDigits.Slice(9/*PowersOf1e9.MaxPartialDigits*/);
                    }
                    $.$spc.System.Diagnostics.Debug.Assert$1(intDigits.Length === 0, "intDigits.Length == 0");
                }
                /*double*/ let digitRatio = 0.10381025297;
                /*int*/ let resultLength = $.$checked($.$checked($.$cast((digitRatio * number.$v.Scale), $.$spc.System.Int32) + 1, 1) + 2, 1);
                /*uint[]?*/ let resultBufferFromPool = null;
                /*Span<uint>*/ let resultBuffer = (resultLength <= $.$srn.System.Numerics.BigIntegerCalculator.StackAllocThreshold ? $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.StackAllocSpan($.$spc.System.UInt32, $.$srn.System.Numerics.BigIntegerCalculator.StackAllocThreshold, null) : $.$spc.System.Span$$($.$spc.System.UInt32).op_Implicit(resultBufferFromPool = $.$spc.System.Buffers.ArrayPool$$($.$spc.System.UInt32).Shared.Rent(resultLength))).Slice$1(0, resultLength);
                resultBuffer.Clear();
                /*int*/ let totalDigitCount = $.$spc.System.Math.Min$4(number.$v.DigitsCount, number.$v.Scale);
                /*int*/ let trailingZeroCount = ((number.$v.Scale - totalDigitCount) | 0);
                if (number.$v.Scale <= $.$srn.System.Number.BigIntegerParseNaiveThreshold)
                {
                    Naive($.$spc.System.Span$$($.$spc.System.UInt32).op_Implicit$2(base1E9), trailingZeroCount, resultBuffer);
                }
                else 
                {
                    DivideAndConquer($.$spc.System.Span$$($.$spc.System.UInt32).op_Implicit$2(base1E9), trailingZeroCount, resultBuffer);
                }
                result.$v = new $.$srn.System.Numerics.BigInteger().$ctor$12($.$spc.System.Span$$($.$spc.System.UInt32).op_Implicit$2(resultBuffer), number.$v.IsNegative);
                if (base1E9FromPool !== null)
                {
                    $.$spc.System.Buffers.ArrayPool$$($.$spc.System.UInt32).Shared.Return(base1E9FromPool, false);
                }
                if (resultBufferFromPool !== null)
                {
                    $.$spc.System.Buffers.ArrayPool$$($.$spc.System.UInt32).Shared.Return(resultBufferFromPool, false);
                }
                return 0/*ParsingStatus.OK*/;
                /*static void*/  function DivideAndConquer(/*ReadOnlySpan<uint>*/ base1E9, /*int*/ trailingZeroCount, /*scoped Span<uint>*/ bits)
                {
                    /*int*/ let valueDigits = (((((((base1E9.Length - 1) | 0)) * 9/*PowersOf1e9.MaxPartialDigits*/) | 0) + $.$srn.System.Buffers.Text.FormattingHelpers.CountDigits$1(base1E9.get_Item(base1E9.Length - 1).$v)) | 0);
                    /*int*/ let maxIndex;
                    /*int*/ let powersOf1e9BufferLength = $.$srn.System.Number.PowersOf1e9.GetBufferSize($.$spc.System.Math.Max$4(valueDigits, ((trailingZeroCount + 1) | 0)), $.$ref(() => maxIndex, ($v) => maxIndex = $v, $.$spc.System.Int32));
                    /*uint[]?*/ let powersOf1e9BufferFromPool = null;
                    /*Span<uint>*/ let powersOf1e9Buffer = (powersOf1e9BufferLength <= $.$srn.System.Numerics.BigIntegerCalculator.StackAllocThreshold ? $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.StackAllocSpan($.$spc.System.UInt32, $.$srn.System.Numerics.BigIntegerCalculator.StackAllocThreshold, null) : $.$spc.System.Span$$($.$spc.System.UInt32).op_Implicit(powersOf1e9BufferFromPool = $.$spc.System.Buffers.ArrayPool$$($.$spc.System.UInt32).Shared.Rent(powersOf1e9BufferLength))).Slice$1(0, powersOf1e9BufferLength);
                    powersOf1e9Buffer.Clear();
                    /*PowersOf1e9*/ let powersOf1e9 = new $.$srn.System.Number.PowersOf1e9().$ctor$2(powersOf1e9Buffer);
                    if (trailingZeroCount > 0)
                    {
                        /*int*/ let leadingLength = $.$checked($.$cast((digitRatio * 9/*PowersOf1e9.MaxPartialDigits*/ * base1E9.Length), $.$spc.System.Int32) + 3, 1);
                        /*uint[]?*/ let leadingFromPool = null;
                        /*Span<uint>*/ let leading = (leadingLength <= $.$srn.System.Numerics.BigIntegerCalculator.StackAllocThreshold ? $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.StackAllocSpan($.$spc.System.UInt32, $.$srn.System.Numerics.BigIntegerCalculator.StackAllocThreshold, null) : $.$spc.System.Span$$($.$spc.System.UInt32).op_Implicit(leadingFromPool = $.$spc.System.Buffers.ArrayPool$$($.$spc.System.UInt32).Shared.Rent(leadingLength))).Slice$1(0, leadingLength);
                        leading.Clear();
                        Recursive($.$ref(() => powersOf1e9, ), maxIndex, base1E9, leading);
                        leading = leading.Slice$1(0, $.$srn.System.Numerics.BigIntegerCalculator.ActualLength($.$spc.System.Span$$($.$spc.System.UInt32).op_Implicit$2(leading)));
                        powersOf1e9.MultiplyPowerOfTen($.$spc.System.Span$$($.$spc.System.UInt32).op_Implicit$2(leading), trailingZeroCount, bits);
                        if (leadingFromPool !== null)
                        {
                            $.$spc.System.Buffers.ArrayPool$$($.$spc.System.UInt32).Shared.Return(leadingFromPool, false);
                        }
                    }
                    else 
                    {
                        Recursive($.$ref(() => powersOf1e9, ), maxIndex, base1E9, bits);
                    }
                    if (powersOf1e9BufferFromPool !== null)
                    {
                        $.$spc.System.Buffers.ArrayPool$$($.$spc.System.UInt32).Shared.Return(powersOf1e9BufferFromPool, false);
                    }
                }
                /*static void*/  function Recursive(/*in PowersOf1e9*/ powersOf1e9, /*int*/ powersOf1e9Index, /*ReadOnlySpan<uint>*/ base1E9, /*Span<uint>*/ bits)
                {
                    $.$spc.System.Diagnostics.Debug.Assert$1($.$spc.System.MemoryExtensions.Trim$2($.$spc.System.UInt32, bits, 0).Length === 0, "bits.Trim(0u).Length == 0");
                    $.$spc.System.Diagnostics.Debug.Assert$1($.$srn.System.Number.BigIntegerParseNaiveThresholdInRecursive > 1, "BigIntegerParseNaiveThresholdInRecursive > 1");
                    base1E9 = base1E9.Slice$1(0, $.$srn.System.Numerics.BigIntegerCalculator.ActualLength(base1E9));
                    if (base1E9.Length < $.$srn.System.Number.BigIntegerParseNaiveThresholdInRecursive)
                    {
                        NaiveBase1E9ToBits(base1E9, bits);
                        return;
                    }
                    /*int*/ let multiplier1E9Length = 1 << powersOf1e9Index;
                    while(base1E9.Length <= multiplier1E9Length)
                    {
                        multiplier1E9Length = 1 << (--powersOf1e9Index);
                    }
                    /*ReadOnlySpan<uint>*/ let multiplier = powersOf1e9.$v.GetSpan(powersOf1e9Index);
                    /*int*/ let multiplierTrailingZeroCount = $.$srn.System.Number.PowersOf1e9.OmittedLength(powersOf1e9Index);
                    $.$spc.System.Diagnostics.Debug.Assert$1(multiplier1E9Length < base1E9.Length && base1E9.Length <= ((multiplier1E9Length * 2) | 0), "multiplier1E9Length < base1E9.Length && base1E9.Length <= multiplier1E9Length * 2");
                    /*int*/ let bufferLength = $.$checked($.$checked($.$cast((digitRatio * 9/*PowersOf1e9.MaxPartialDigits*/ * multiplier1E9Length), $.$spc.System.Int32) + 1, 1) + 2, 1);
                    /*uint[]?*/ let bufferFromPool = null;
                    /*scoped Span<uint>*/ let buffer = (bufferLength <= $.$srn.System.Numerics.BigIntegerCalculator.StackAllocThreshold ? $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.StackAllocSpan($.$spc.System.UInt32, $.$srn.System.Numerics.BigIntegerCalculator.StackAllocThreshold, null) : $.$spc.System.Span$$($.$spc.System.UInt32).op_Implicit(bufferFromPool = $.$spc.System.Buffers.ArrayPool$$($.$spc.System.UInt32).Shared.Rent(bufferLength))).Slice$1(0, bufferLength);
                    buffer.Clear();
                    let $t2 = base1E9;
                    Recursive(powersOf1e9, ((powersOf1e9Index - 1) | 0), $t2.Slice$1(multiplier1E9Length, $t2.Length - multiplier1E9Length), buffer);
                    /*ReadOnlySpan<uint>*/ let buffer2 = $.$spc.System.Span$$($.$spc.System.UInt32).op_Implicit$2(buffer.Slice$1(0, $.$srn.System.Numerics.BigIntegerCalculator.ActualLength($.$spc.System.Span$$($.$spc.System.UInt32).op_Implicit$2(buffer))));
                    /*Span<uint>*/ let bitsUpper = bits.Slice$1(multiplierTrailingZeroCount, ((buffer2.Length + multiplier.Length) | 0));
                    if (multiplier.Length < buffer2.Length)
                    {
                        $.$srn.System.Numerics.BigIntegerCalculator.Multiply$1(buffer2, multiplier, bitsUpper);
                    }
                    else 
                    {
                        $.$srn.System.Numerics.BigIntegerCalculator.Multiply$1(multiplier, buffer2, bitsUpper);
                    }
                    buffer.Clear();
                    let $t4 = base1E9;
                    Recursive(powersOf1e9, ((powersOf1e9Index - 1) | 0), $t4.Slice$1(0, multiplier1E9Length), buffer);
                    $.$srn.System.Numerics.BigIntegerCalculator.AddSelf(bits, $.$spc.System.Span$$($.$spc.System.UInt32).op_Implicit$2(buffer.Slice$1(0, $.$srn.System.Numerics.BigIntegerCalculator.ActualLength($.$spc.System.Span$$($.$spc.System.UInt32).op_Implicit$2(buffer)))));
                    if (bufferFromPool !== null)
                    {
                        $.$spc.System.Buffers.ArrayPool$$($.$spc.System.UInt32).Shared.Return(bufferFromPool, false);
                    }
                }
                /*static void*/  function Naive(/*ReadOnlySpan<uint>*/ base1E9, /*int*/ trailingZeroCount, /*scoped Span<uint>*/ bits)
                {
                    if (base1E9.Length === 0)
                    {
                        return;
                    }
                    /*int*/ let resultLength = NaiveBase1E9ToBits(base1E9, bits);
                    /*int*/ let remainingTrailingZeroCount;
                    /*int*/ let trailingPartialCount = $.$spc.System.Math.DivRem(trailingZeroCount, 9/*PowersOf1e9.MaxPartialDigits*/, $.$ref(() => remainingTrailingZeroCount, ($v) => remainingTrailingZeroCount = $v, $.$spc.System.Int32));
                    for(/*int*/ let i = 0; i < trailingPartialCount; i++)
                    {
                        /*uint*/ let carry = MultiplyAdd(bits.Slice$1(0, resultLength), 1000000000/*PowersOf1e9.TenPowMaxPartial*/, 0);
                        $.$spc.System.Diagnostics.Debug.Assert$1(bits.get_Item(resultLength).$v === 0, "bits[resultLength] == 0");
                        if (carry !== 0)
                        {
                            bits.get_Item(resultLength++).$v = carry;
                        }
                    }
                    if (remainingTrailingZeroCount !== 0)
                    {
                        /*uint*/ let multiplier = $.$srn.System.Number.UInt32PowersOfTen.get_Item(remainingTrailingZeroCount).$v;
                        /*uint*/ let carry = MultiplyAdd(bits.Slice$1(0, resultLength), multiplier, 0);
                        $.$spc.System.Diagnostics.Debug.Assert$1(bits.get_Item(resultLength).$v === 0, "bits[resultLength] == 0");
                        if (carry !== 0)
                        {
                            bits.get_Item(resultLength++).$v = carry;
                        }
                    }
                }
                /*static int*/  function NaiveBase1E9ToBits(/*ReadOnlySpan<uint>*/ base1E9, /*Span<uint>*/ bits)
                {
                    if (base1E9.Length === 0)
                    {
                        return 0;
                    }
                    /*int*/ let resultLength = 1;
                    bits.get_Item(0).$v = base1E9.get_Item(base1E9.Length - 1).$v;
                    for(/*int*/ let i = ((base1E9.Length - 2) | 0); i >= 0; i--)
                    {
                        /*uint*/ let carry = MultiplyAdd(bits.Slice$1(0, resultLength), 1000000000/*PowersOf1e9.TenPowMaxPartial*/, base1E9.get_Item(i).$v);
                        $.$spc.System.Diagnostics.Debug.Assert$1(bits.get_Item(resultLength).$v === 0, "bits[resultLength] == 0");
                        if (carry !== 0)
                        {
                            bits.get_Item(resultLength++).$v = carry;
                        }
                    }
                    return resultLength;
                }
                /*static uint*/  function MultiplyAdd(/*Span<uint>*/ bits, /*uint*/ multiplier, /*uint*/ addValue)
                {
                    /*uint*/ let carry = addValue;
                    for(/*int*/ let i = 0; i < bits.Length; i++)
                    {
                        /*ulong*/ let p = $.$cast(multiplier, $.$spc.System.UInt64) * BigInt(bits.get_Item(i).$v) + BigInt(carry);
                        bits.get_Item(i).$v = $.$cast(p, $.$spc.System.UInt32);
                        carry = $.$cast((p >> 32n), $.$spc.System.UInt32);
                    }
                    return carry;
                }
            }
            static /*string? */ FormatBigIntegerToHex(/*bool*/ targetSpan, /*BigInteger*/ value, /*char*/ format, /*int*/ digits, /*NumberFormatInfo*/ info, /*Span<char>*/ destination, /*out int*/ charsWritten, /*out bool*/ spanSuccess)
            {
                $.$spc.System.Diagnostics.Debug.Assert$1(format === /*x*/ 120 || format === /*X*/ 88, "format == 'x' || format == 'X'");
                /*byte[]?*/ let arrayToReturnToPool = null;
                /*Span<byte>*/ let bits = $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.StackAllocSpan($.$spc.System.Byte, 64, null);
                /*int*/ let bytesWrittenOrNeeded;
                if (!value.TryWriteOrCountBytes(bits, $.$ref(() => bytesWrittenOrNeeded, ($v) => bytesWrittenOrNeeded = $v, $.$spc.System.Int32), false, false))
                {
                    bits = $.$spc.System.Span$$($.$spc.System.Byte).op_Implicit(arrayToReturnToPool = $.$spc.System.Buffers.ArrayPool$$($.$spc.System.Byte).Shared.Rent(bytesWrittenOrNeeded));
                    /*bool*/ let success = value.TryWriteBytes(bits, $.$ref(() => bytesWrittenOrNeeded, ($v) => bytesWrittenOrNeeded = $v, $.$spc.System.Int32), false, false);
                    $.$spc.System.Diagnostics.Debug.Assert$1(success, "success");
                }
                bits = bits.Slice$1(0, bytesWrittenOrNeeded);
                /*var*/ let sb = new $.$srn.System.Text.ValueStringBuilder().$ctor$2($.$spc.System.Runtime.CompilerServices.RuntimeHelpers.StackAllocSpan($.$spc.System.Char, 128, null));
                /*int*/ let cur = ((bits.Length - 1) | 0);
                if (cur > -1)
                {
                    /*bool*/ let clearHighF = false;
                    /*byte*/ let head = bits.get_Item(cur).$v;
                    if (head > 247)
                    {
                        head -= 240;
                        clearHighF = true;
                    }
                    if (head < 8 || clearHighF)
                    {
                        sb.Append(head < 10 ? $.$cast((head + /*0*/ 48), $.$spc.System.Char) : format === /*X*/ 88 ? $.$cast(((((((head & 15) - 10) | 0) + /*A*/ 65) | 0)), $.$spc.System.Char) : $.$cast(((((((head & 15) - 10) | 0) + /*a*/ 97) | 0)), $.$spc.System.Char));
                        cur--;
                    }
                }
                if (cur > -1)
                {
                    /*Span<char>*/ let chars = sb.AppendSpan((((((cur + 1) | 0)) * 2) | 0));
                    /*int*/ let charsPos = 0;
                    /*string*/ let hexValues = format === /*x*/ 120 ? "0123456789abcdef" : "0123456789ABCDEF";
                    while(cur > -1)
                    {
                        /*byte*/ let b = bits.get_Item(cur--).$v;
                        chars.get_Item(charsPos++).$v = $.$spc.System.String.get_Chars.call(hexValues, b >>> 4);
                        chars.get_Item(charsPos++).$v = $.$spc.System.String.get_Chars.call(hexValues, b & 15);
                    }
                }
                if (digits > sb.Length)
                {
                    sb.Insert(0, value._sign >= 0 ? /*0*/ 48 : (format === /*x*/ 120) ? /*f*/ 102 : /*F*/ 70, ((digits - sb.Length) | 0));
                }
                if (arrayToReturnToPool !== null)
                {
                    $.$spc.System.Buffers.ArrayPool$$($.$spc.System.Byte).Shared.Return(arrayToReturnToPool, false);
                }
                if (targetSpan)
                {
                    spanSuccess.$v = sb.TryCopyTo(destination, charsWritten);
                    return null;
                }
                else 
                {
                    charsWritten.$v = 0;
                    spanSuccess.$v = false;
                    return $.$srn.System.Text.ValueStringBuilder.ToString.call(sb);
                }
            }
            static /*string? */ FormatBigIntegerToBinary(/*bool*/ targetSpan, /*BigInteger*/ value, /*int*/ digits, /*Span<char>*/ destination, /*out int*/ charsWritten, /*out bool*/ spanSuccess)
            {
                /*byte[]?*/ let arrayToReturnToPool = null;
                /*Span<byte>*/ let bytes = $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.StackAllocSpan($.$spc.System.Byte, 64, null);
                /*int*/ let bytesWrittenOrNeeded;
                if (!value.TryWriteOrCountBytes(bytes, $.$ref(() => bytesWrittenOrNeeded, ($v) => bytesWrittenOrNeeded = $v, $.$spc.System.Int32), false, false))
                {
                    bytes = $.$spc.System.Span$$($.$spc.System.Byte).op_Implicit(arrayToReturnToPool = $.$spc.System.Buffers.ArrayPool$$($.$spc.System.Byte).Shared.Rent(bytesWrittenOrNeeded));
                    /*bool*/ let success = value.TryWriteBytes(bytes, $.$discardRef(), false, false);
                    $.$spc.System.Diagnostics.Debug.Assert$1(success, "success");
                }
                bytes = bytes.Slice$1(0, bytesWrittenOrNeeded);
                $.$spc.System.Diagnostics.Debug.Assert$1(!bytes.IsEmpty, "!bytes.IsEmpty");
                /*byte*/ let highByte = bytes.get_Item(bytes.Length - 1).$v;
                /*int*/ let charsInHighByte = ((9 - $.$spc.System.Byte.LeadingZeroCount(value._sign >= 0 ? highByte : $.$cast(~highByte, $.$spc.System.Byte))) | 0);
                /*long*/ let tmpCharCount = BigInt(charsInHighByte) + (BigInt.asIntN(64, $.$cast((((bytes.Length - 1) | 0)), $.$spc.System.Int64) << 3n));
                if (tmpCharCount > BigInt($.$spc.System.Array.MaxLength))
                {
                    $.$spc.System.Diagnostics.Debug.Assert$1(!(arrayToReturnToPool === null), "arrayToReturnToPool is not null");
                    $.$spc.System.Buffers.ArrayPool$$($.$spc.System.Byte).Shared.Return(arrayToReturnToPool, false);
                    throw new $.$spc.System.FormatException().$ctor$10($.$srn.System.SR.Format_TooLarge);
                }
                /*int*/ let charsForBits = $.$cast(tmpCharCount, $.$spc.System.Int32);
                $.$spc.System.Diagnostics.Debug.Assert$1(digits < $.$spc.System.Array.MaxLength, "digits < Array.MaxLength");
                /*int*/ let charsIncludeDigits = $.$spc.System.Math.Max$4(digits, charsForBits);
                try
                {
                    /*scoped ValueStringBuilder*/ let sb;
                    if (targetSpan)
                    {
                        if (charsIncludeDigits > destination.Length)
                        {
                            charsWritten.$v = 0;
                            spanSuccess.$v = false;
                            return null;
                        }
                        sb = new $.$srn.System.Text.ValueStringBuilder().$ctor$2(destination);
                    }
                    else 
                    {
                        sb = charsIncludeDigits > 512 ? new $.$srn.System.Text.ValueStringBuilder().$ctor$3(charsIncludeDigits) : new $.$srn.System.Text.ValueStringBuilder().$ctor$2($.$spc.System.Runtime.CompilerServices.RuntimeHelpers.StackAllocSpan($.$spc.System.Char, 512, null));
                    }
                    if (digits > charsForBits)
                    {
                        sb.Append$2(value._sign >= 0 ? /*0*/ 48 : /*1*/ 49, ((digits - charsForBits) | 0));
                    }
                    AppendByte($.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateObjectReferenceT($.$srn.System.Text.ValueStringBuilder, () => sb, ($v) => sb = $v, null), highByte, ((charsInHighByte - 1) | 0));
                    for(/*int*/ let i = ((bytes.Length - 2) | 0); i >= 0; i--)
                    {
                        AppendByte($.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateObjectReferenceT($.$srn.System.Text.ValueStringBuilder, () => sb, ($v) => sb = $v, null), bytes.get_Item(i).$v, 7);
                    }
                    $.$spc.System.Diagnostics.Debug.Assert$1(sb.Length === charsIncludeDigits, "sb.Length == charsIncludeDigits");
                    if (targetSpan)
                    {
                        charsWritten.$v = charsIncludeDigits;
                        spanSuccess.$v = true;
                        return null;
                    }
                    charsWritten.$v = 0;
                    spanSuccess.$v = false;
                    return $.$srn.System.Text.ValueStringBuilder.ToString.call(sb);
                }
                finally
                {
                    {
                        if (!(arrayToReturnToPool === null))
                        {
                            $.$spc.System.Buffers.ArrayPool$$($.$spc.System.Byte).Shared.Return(arrayToReturnToPool, false);
                        }
                    }
                }
                /*static void*/  function AppendByte(/*ref ValueStringBuilder*/ sb, /*byte*/ b, /*int*/ startHighBit)
                {
                    for(/*int*/ let i = startHighBit; i >= 0; i--)
                    {
                        sb.$v.Append($.$cast((((/*0*/ 48 + ((b >>> i) & 1)) | 0)), $.$spc.System.Char));
                    }
                }
            }
            static /*string */ FormatBigInteger(/*BigInteger*/ value, /*string?*/ format, /*NumberFormatInfo*/ info)
            {
                return $.$srn.System.Number.FormatBigInteger$1(false, value, format, $.$spc.System.String.op_Implicit(format), info, new ($.$spc.System.Span$$($.$spc.System.Char))(), $.$discardRef(), $.$discardRef());
            }
            static /*bool */ TryFormatBigInteger(/*BigInteger*/ value, /*ReadOnlySpan<char>*/ format, /*NumberFormatInfo*/ info, /*Span<char>*/ destination, /*out int*/ charsWritten)
            {
                /*bool*/ let spanSuccess;
                $.$srn.System.Number.FormatBigInteger$1(true, value, null, format, info, destination, charsWritten, $.$ref(() => spanSuccess, ($v) => spanSuccess = $v, $.$spc.System.Boolean));
                return spanSuccess;
            }
            static /*string? */ FormatBigInteger$1(/*bool*/ targetSpan, /*BigInteger*/ value, /*string?*/ formatString, /*ReadOnlySpan<char>*/ formatSpan, /*NumberFormatInfo*/ info, /*Span<char>*/ destination, /*out int*/ charsWritten, /*out bool*/ spanSuccess)
            {
                $.$spc.System.Diagnostics.Debug.Assert$1($.$spc.System.String.op_Equality(formatString, null) || formatString.length === formatSpan.Length, "formatString == null || formatString.Length == formatSpan.Length");
                /*uint*/ let TenPowMaxPartial = 1000000000/*PowersOf1e9.TenPowMaxPartial*/;
                /*int*/ let MaxPartialDigits = 9/*PowersOf1e9.MaxPartialDigits*/;
                /*int*/ let digits = 0;
                /*char*/ let fmt = $.$srn.System.Number.ParseFormatSpecifier(formatSpan, $.$ref(() => digits, ($v) => digits = $v, $.$spc.System.Int32));
                if (fmt === /*x*/ 120 || fmt === /*X*/ 88)
                {
                    return $.$srn.System.Number.FormatBigIntegerToHex(targetSpan, value, fmt, digits, info, destination, charsWritten, spanSuccess);
                }
                if (fmt === /*b*/ 98 || fmt === /*B*/ 66)
                {
                    return $.$srn.System.Number.FormatBigIntegerToBinary(targetSpan, value, digits, destination, charsWritten, spanSuccess);
                }
                if (value._bits === null)
                {
                    if (fmt === /*g*/ 103 || fmt === /*G*/ 71 || fmt === /*r*/ 114 || fmt === /*R*/ 82)
                    {
                        formatSpan = $.$spc.System.String.op_Implicit(formatString = digits > 0 ? `D${digits}` : "D");
                    }
                    if (targetSpan)
                    {
                        spanSuccess.$v = $.$spc.System.Int32.TryFormat.call(value._sign, destination, charsWritten, formatSpan, info);
                        return null;
                    }
                    else 
                    {
                        $.$spc.System.Diagnostics.Debug.Assert$1($.$spc.System.String.op_Inequality(formatString, null), "formatString != null");
                        charsWritten.$v = 0;
                        spanSuccess.$v = false;
                        return $.$spc.System.Int32.ToString$3.call(value._sign, formatString, info);
                    }
                }
                /*int*/ let cuSrc = value._bits.length;
                /*int*/ let cuMax = (($.trunc(((cuSrc * (((MaxPartialDigits + 1) | 0))) | 0) / MaxPartialDigits) + 1) | 0);
                $.$spc.System.Diagnostics.Debug.Assert$1($.$cast($.$srn.System.Numerics.BigInteger.MaxLength, $.$spc.System.Int64) * (BigInt(MaxPartialDigits + 1)) / BigInt(MaxPartialDigits) + 1n < $.$cast(2147483647/*int.MaxValue*/, $.$spc.System.Int64), "(long)BigInteger.MaxLength * (MaxPartialDigits + 1) / MaxPartialDigits + 1 < (long)int.MaxValue");
                /*uint[]?*/ let bufferToReturn = null;
                /*Span<uint>*/ let base1E9Buffer = cuMax < $.$srn.System.Numerics.BigIntegerCalculator.StackAllocThreshold ? $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.StackAllocSpan($.$spc.System.UInt32, cuMax, null) : ($.$spc.System.Span$$($.$spc.System.UInt32).op_Implicit(bufferToReturn = $.$spc.System.Buffers.ArrayPool$$($.$spc.System.UInt32).Shared.Rent(cuMax)));
                /*int*/ let cuDst = 0;
                for(/*int*/ let iuSrc = cuSrc; --iuSrc >= 0; )
                {
                    /*uint*/ let uCarry = $.$spc.System.Array.$ReadT1.call(value._bits, iuSrc);
                    for(/*int*/ let iuDst = 0; iuDst < cuDst; iuDst++)
                    {
                        $.$spc.System.Diagnostics.Debug.Assert$1(base1E9Buffer.get_Item(iuDst).$v < TenPowMaxPartial, "base1E9Buffer[iuDst] < TenPowMaxPartial");
                        /*ulong*/ let uuRes = $.$srn.System.Numerics.NumericsHelpers.MakeUInt64(base1E9Buffer.get_Item(iuDst).$v, uCarry);
                        const { Item1: quo, Item2: rem } = $.$spc.System.Math.DivRem$9(uuRes, BigInt(TenPowMaxPartial));
                        uCarry = $.$cast(quo, $.$spc.System.UInt32);
                        base1E9Buffer.get_Item(iuDst).$v = $.$cast(rem, $.$spc.System.UInt32);
                    }
                    if (uCarry !== 0)
                    {
                        $.$tupleUnpack(($tp) =>
                        {
                            uCarry = $tp.Item1;
                            base1E9Buffer.get_Item(cuDst++).$v = $tp.Item2;
                        }).$v = $.$spc.System.Math.DivRem$7(uCarry, TenPowMaxPartial);
                        if (uCarry !== 0)
                        {
                            base1E9Buffer.get_Item(cuDst++).$v = uCarry;
                        }
                    }
                }
                let $t2 = base1E9Buffer;
                /*ReadOnlySpan<uint>*/ let base1E9Value = $.$spc.System.Span$$($.$spc.System.UInt32).op_Implicit$2($t2.Slice$1(0, cuDst));
                /*int*/ let valueDigits = (((((((base1E9Value.Length - 1) | 0)) * MaxPartialDigits) | 0) + $.$srn.System.Buffers.Text.FormattingHelpers.CountDigits$1(base1E9Value.get_Item(base1E9Value.Length - 1).$v)) | 0);
                /*string?*/ let strResult;
                if (fmt === /*g*/ 103 || fmt === /*G*/ 71 || fmt === /*d*/ 100 || fmt === /*D*/ 68 || fmt === /*r*/ 114 || fmt === /*R*/ 82)
                {
                    /*int*/ let strDigits = $.$spc.System.Math.Max$4(digits, valueDigits);
                    /*string?*/ let sNegative = value.Sign < 0 ? info.NegativeSign : null;
                    const $t3 = sNegative;
                    /*int*/ let strLength = ((strDigits + ($.$ifnn($t3, ($t) => $t.length) ?? 0)) | 0);
                    if (targetSpan)
                    {
                        if (destination.Length < strLength)
                        {
                            spanSuccess.$v = false;
                            charsWritten.$v = 0;
                        }
                        else 
                        {
                            const $t4 = sNegative;
                            $.$ifnn($t4, ($t) => $.$spc.System.String.CopyTo$1.call($t, destination));
                            /*fixed*/ 
                            {
                                /*char**/ let ptr = $.$spc.System.Runtime.InteropServices.MemoryMarshal.GetReference($.$spc.System.Char, destination);
                                $.$srn.System.Number.BigIntegerToDecChars($.$srn.System.Utf16Char, $.$cast(ptr, $.$typePointer($.$srn.System.Utf16Char)).Add(strLength), base1E9Value, digits);
                            }
                            charsWritten.$v = strLength;
                            spanSuccess.$v = true;
                        }
                        strResult = null;
                    }
                    else 
                    {
                        spanSuccess.$v = false;
                        charsWritten.$v = 0;
                        /*fixed*/ 
                        {
                            /*uint**/ let ptr = base1E9Value.GetPinnableReference();
                            strResult = $.$spc.System.String.Create$8($.$spc.System.ValueTuple$$$$$($.$spc.System.Int32, $.$spc.System.IntPtr, $.$spc.System.Int32, $.$spc.System.String), strLength, new ($.$spc.System.ValueTuple$$$$$($.$spc.System.Int32, $.$spc.System.IntPtr, $.$spc.System.Int32, $.$spc.System.String))().$ctor$2(digits, $.$cast(ptr, $.$spc.System.IntPtr), base1E9Value.Length, sNegative), new ($.$spc.System.Buffers.SpanAction$$$($.$spc.System.Char, $.$spc.System.ValueTuple$$$$$($.$spc.System.Int32, $.$spc.System.IntPtr, $.$spc.System.Int32, $.$spc.System.String)))().$ctor($.$srn.System.Number, /*static*/ (/*span*/ span, /*state*/ state) =>
                            {
                                const $t4 = () => state.Item4;
                                $.$ifnn($t4, ($t) => $.$spc.System.String.CopyTo$1.call($t, span));
                                /*fixed*/ 
                                {
                                    /*char**/ let ptr = $.$spc.System.Runtime.InteropServices.MemoryMarshal.GetReference($.$spc.System.Char, span);
                                    $.$srn.System.Number.BigIntegerToDecChars($.$srn.System.Utf16Char, $.$cast(ptr, $.$typePointer($.$srn.System.Utf16Char)).Add(span.Length), new ($.$spc.System.ReadOnlySpan$$($.$spc.System.UInt32))().$ctor$4($.$spc.System.IntPtr.op_Explicit$3(state.Item2), state.Item3), state.Item1);
                                }
                            }, {"r":65537,"p":[{"n":"span","p":$.$spc.System.Span$$($.$spc.System.Char).$h},{"n":"state","p":$.$spc.System.ValueTuple$$$$$($.$spc.System.Int32, $.$spc.System.IntPtr, $.$spc.System.Int32, $.$spc.System.String).$h}],"n":"","d":502545,"h":0,"f":1048610}));
                        }
                    }
                }
                else 
                {
                    /*byte[]?*/ let numberBufferToReturn = null;
                    /*Span<byte>*/ let numberBuffer = ((valueDigits + 1) | 0) <= 32/*CharStackBufferSize*/ ? $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.StackAllocSpan($.$spc.System.Byte, ((valueDigits + 1) | 0), null) : ($.$spc.System.Span$$($.$spc.System.Byte).op_Implicit(numberBufferToReturn = $.$spc.System.Buffers.ArrayPool$$($.$spc.System.Byte).Shared.Rent(((valueDigits + 1) | 0))));
                    /*fixed*/ 
                    {
                        /*byte**/ let ptr = numberBuffer.GetPinnableReference();
                        /*scoped NumberBuffer*/ let number = new $.$srn.System.Number.NumberBuffer().$ctor$2(1/*NumberBufferKind.Integer*/, ptr, ((valueDigits + 1) | 0));
                        $.$srn.System.Number.BigIntegerToDecChars($.$srn.System.Utf8Char, $.$cast(ptr, $.$typePointer($.$srn.System.Utf8Char)).Add(valueDigits), base1E9Value, valueDigits);
                        let $t3 = number.Digits;
                        $t3.get_Item($t3.Length - 1).$v = 0;
                        number.DigitsCount = valueDigits;
                        number.Scale = valueDigits;
                        number.IsNegative = value.Sign < 0;
                        /*scoped var*/ let vlb = new ($.$srn.System.Collections.Generic.ValueListBuilder$$($.$srn.System.Utf16Char))().$ctor$2($.$spc.System.Runtime.CompilerServices.RuntimeHelpers.StackAllocSpan($.$srn.System.Utf16Char, 32/*CharStackBufferSize*/, null));
                        if (fmt !== 0)
                        {
                            $.$srn.System.Number.NumberToString($.$srn.System.Utf16Char, $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateObjectReferenceT($.$srn.System.Collections.Generic.ValueListBuilder$$($.$srn.System.Utf16Char), () => vlb, ($v) => vlb = $v, null), $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateObjectReferenceT($.$srn.System.Number.NumberBuffer, () => number, ($v) => number = $v, null), fmt, digits, info);
                        }
                        else 
                        {
                            $.$srn.System.Number.NumberToStringFormat($.$srn.System.Utf16Char, $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateObjectReferenceT($.$srn.System.Collections.Generic.ValueListBuilder$$($.$srn.System.Utf16Char), () => vlb, ($v) => vlb = $v, null), $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateObjectReferenceT($.$srn.System.Number.NumberBuffer, () => number, ($v) => number = $v, null), formatSpan, info);
                        }
                        if (targetSpan)
                        {
                            spanSuccess.$v = vlb.TryCopyTo($.$spc.System.Runtime.InteropServices.MemoryMarshal.Cast($.$spc.System.Char, $.$srn.System.Utf16Char, destination), charsWritten);
                            strResult = null;
                        }
                        else 
                        {
                            charsWritten.$v = 0;
                            spanSuccess.$v = false;
                            strResult = $.$spc.System.ReadOnlySpan$$($.$spc.System.Char).ToString.call($.$spc.System.Runtime.InteropServices.MemoryMarshal.Cast$1($.$srn.System.Utf16Char, $.$spc.System.Char, vlb.AsSpan()));
                        }
                        vlb.Dispose();
                        if (numberBufferToReturn !== null)
                        {
                            $.$spc.System.Buffers.ArrayPool$$($.$spc.System.Byte).Shared.Return(numberBufferToReturn, false);
                        }
                    }
                }
                if (bufferToReturn !== null)
                {
                    $.$spc.System.Buffers.ArrayPool$$($.$spc.System.UInt32).Shared.Return(bufferToReturn, false);
                }
                return strResult;
            }
            static /*TChar* */ BigIntegerToDecChars(TChar, /*TChar**/ bufferEnd, /*ReadOnlySpan<uint>*/ base1E9Value, /*int*/ digits)
            {
                $.$spc.System.Diagnostics.Debug.Assert$1(base1E9Value.get_Item(base1E9Value.Length - 1).$v !== 0, "Leading zeros should be trimmed by caller.");
                for(/*int*/ let i = 0; i < ((base1E9Value.Length - 1) | 0); i++)
                {
                    bufferEnd = $.$srn.System.Number.UInt32ToDecChars(TChar, bufferEnd, base1E9Value.get_Item(i).$v, 9/*PowersOf1e9.MaxPartialDigits*/);
                    digits -= 9/*PowersOf1e9.MaxPartialDigits*/;
                }
                return $.$srn.System.Number.UInt32ToDecChars(TChar, bufferEnd, base1E9Value.get_Item(base1E9Value.Length - 1).$v, digits);
            }
            static $_PowersOf1e9;
            static get PowersOf1e9()
            {
                let $cls = $.$srn.System.Number;
                return $cls.$_PowersOf1e9 ??= $asm.$nstr("$srn.System.Number.PowersOf1e9", ($self) => class PowersOf1e9 extends $.$spc.System.ValueType
                {
                    /*ReadOnlySpan<uint>*/  get pow1E9() { return this.$getField(0, 8); }
                    /*ReadOnlySpan<uint>*/  set pow1E9(value) { this.$setField(0, 8, value); }
                    /*uint*/ static TenPowMaxPartial = 1000000000;
                    /*int*/ static MaxPartialDigits = 9;
                    static /*ReadOnlySpan<int> */ get Indexes()
                    {
                        return this.$cacheIndexes ??= new ($.$spc.System.ReadOnlySpan$$($.$spc.System.Int32))().$ctor$2([ 0, 1, 3, 6, 12, 23, 44, 86, 170, 338, 673, 1342, 2680, 5355, 10705, 21405, 42804, 85602, 171198, 342390, 684773, 1369538, 2739067, 5478125, 10956241, 21912473, 43824936, 87649862, 175299713, 484817143, 969634274, 1939268536 ]);
                    }
                    static /*ReadOnlySpan<uint> */ get LeadingPowers1E9()
                    {
                        return this.$cacheLeadingPowers1E9 ??= new ($.$spc.System.ReadOnlySpan$$($.$spc.System.UInt32))().$ctor$2([ 1000000000, 2808348672, 232830643, 3008077584, 2076772117, 12621774, 4130660608, 835571558, 1441351422, 977976457, 264170013, 37092, 767623168, 4241160024, 1260959332, 2541775228, 2965753944, 1796720685, 484800439, 1311835347, 2945126454, 3563705203, 1375821026, 3940379521, 184513341, 2872588323, 2214530454, 38258512, 2980860351, 114267010, 2188874685, 234079247, 2101059099, 1948702207, 947446250, 864457656, 507589568, 1321007357, 3911984176, 1011110295, 2382358050, 2389730781, 730678769, 440721283 ]);
                    }
                    $ctor$2(/*Span<uint>*/ pow1E9)
                    {
                        super.$ctor$1();
                        {
                            $.$spc.System.Diagnostics.Debug.Assert$1(pow1E9.Length >= 1, "pow1E9.Length >= 1");
                            $.$spc.System.Diagnostics.Debug.Assert$1($.$srn.System.Number.PowersOf1e9.Indexes.get_Item(6).$v === $.$srn.System.Number.PowersOf1e9.LeadingPowers1E9.Length, "Indexes[6] == LeadingPowers1E9.Length");
                            if (pow1E9.Length <= $.$srn.System.Number.PowersOf1e9.LeadingPowers1E9.Length)
                            {
                                this.pow1E9 = $.$srn.System.Number.PowersOf1e9.LeadingPowers1E9;
                                return this;
                            }
                            $.$srn.System.Number.PowersOf1e9.LeadingPowers1E9.CopyTo(pow1E9.Slice$1(0, $.$srn.System.Number.PowersOf1e9.LeadingPowers1E9.Length));
                            this.pow1E9 = $.$spc.System.Span$$($.$spc.System.UInt32).op_Implicit$2(pow1E9);
                            /*ReadOnlySpan<uint>*/ let src = $.$spc.System.Span$$($.$spc.System.UInt32).op_Implicit$2(pow1E9.Slice$1($.$srn.System.Number.PowersOf1e9.Indexes.get_Item(5).$v, (($.$srn.System.Number.PowersOf1e9.Indexes.get_Item(6).$v - $.$srn.System.Number.PowersOf1e9.Indexes.get_Item(5).$v) | 0)));
                            /*int*/ let toExclusive = $.$srn.System.Number.PowersOf1e9.Indexes.get_Item(6).$v;
                            for(/*int*/ let i = 6; ((i + 1) | 0) < $.$srn.System.Number.PowersOf1e9.Indexes.Length; i++)
                            {
                                $.$spc.System.Diagnostics.Debug.Assert$1((((((2 * src.Length) | 0) - ((($.$srn.System.Number.PowersOf1e9.Indexes.get_Item(((i + 1) | 0)).$v - $.$srn.System.Number.PowersOf1e9.Indexes.get_Item(i).$v) | 0))) | 0) === 0) || (((((2 * src.Length) | 0) - ((($.$srn.System.Number.PowersOf1e9.Indexes.get_Item(((i + 1) | 0)).$v - $.$srn.System.Number.PowersOf1e9.Indexes.get_Item(i).$v) | 0))) | 0) === 1), "2 * src.Length - (Indexes[i + 1] - Indexes[i]) is 0 or 1");
                                if (((pow1E9.Length - toExclusive) | 0) < (src.Length << 1))
                                {
                                    break;
                                }
                                /*Span<uint>*/ let dst = pow1E9.Slice$1(toExclusive, src.Length << 1);
                                $.$srn.System.Numerics.BigIntegerCalculator.Square(src, dst);
                                /*int*/ let $from = toExclusive;
                                toExclusive = $.$srn.System.Number.PowersOf1e9.Indexes.get_Item(((i + 1) | 0)).$v;
                                src = $.$spc.System.Span$$($.$spc.System.UInt32).op_Implicit$2(pow1E9.Slice$1($from, ((toExclusive - $from) | 0)));
                                $.$spc.System.Diagnostics.Debug.Assert$1(toExclusive === pow1E9.Length || pow1E9.get_Item(toExclusive).$v === 0, "toExclusive == pow1E9.Length || pow1E9[toExclusive] == 0");
                            }
                        }
                        return this;
                    }
                    static /*int */ GetBufferSize(/*int*/ digits, /*out int*/ maxIndex)
                    {
                        /*uint*/ let scale1E9 = $.trunc(((((digits - 1) | 0)) >>> 0) / 9/*MaxPartialDigits*/);
                        maxIndex.$v = $.$spc.System.Numerics.BitOperations.Log2(scale1E9);
                        /*int*/ let index = ((maxIndex.$v + 1) | 0);
                        /*int*/ let bufferSize;
                        if ((index >>> 0) < ($.$srn.System.Number.PowersOf1e9.Indexes.Length >>> 0))
                        {
                            bufferSize = $.$srn.System.Number.PowersOf1e9.Indexes.get_Item(index).$v;
                        }
                        else 
                        {
                            maxIndex.$v = (($.$srn.System.Number.PowersOf1e9.Indexes.Length - 2) | 0);
                            bufferSize = $.$srn.System.Number.PowersOf1e9.Indexes.get_Item($.$srn.System.Number.PowersOf1e9.Indexes.Length - 1).$v;
                        }
                        return ++bufferSize;
                    }
                    /*ReadOnlySpan<uint> */ GetSpan(/*int*/ index)
                    {
                        /*int*/ let $from = $.$srn.System.Number.PowersOf1e9.Indexes.get_Item(index).$v;
                        /*int*/ let toExclusive = $.$srn.System.Number.PowersOf1e9.Indexes.get_Item(((index + 1) | 0)).$v;
                        return this.pow1E9.Slice$1($from, ((toExclusive - $from) | 0));
                    }
                    static /*int */ OmittedLength(/*int*/ index)
                    {
                        return (((9/*MaxPartialDigits*/ * (1 << index)) | 0)) >> 5;
                    }
                    /*void */ MultiplyPowerOfTen(/*ReadOnlySpan<uint>*/ left, /*int*/ trailingZeroCount, /*Span<uint>*/ bits)
                    {
                        $.$spc.System.Diagnostics.Debug.Assert$1(trailingZeroCount >= 0, "trailingZeroCount >= 0");
                        if (trailingZeroCount < $.$srn.System.Number.UInt32PowersOfTen.Length)
                        {
                            $.$srn.System.Numerics.BigIntegerCalculator.Multiply(left, $.$srn.System.Number.UInt32PowersOfTen.get_Item(trailingZeroCount).$v, bits.Slice$1(0, ((left.Length + 1) | 0)));
                            return;
                        }
                        /*uint[]?*/ let powersOfTenFromPool = null;
                        /*Span<uint>*/ let powersOfTen = (bits.Length <= $.$srn.System.Numerics.BigIntegerCalculator.StackAllocThreshold ? $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.StackAllocSpan($.$spc.System.UInt32, $.$srn.System.Numerics.BigIntegerCalculator.StackAllocThreshold, null) : $.$spc.System.Span$$($.$spc.System.UInt32).op_Implicit(powersOfTenFromPool = $.$spc.System.Buffers.ArrayPool$$($.$spc.System.UInt32).Shared.Rent(bits.Length))).Slice$1(0, bits.Length);
                        /*scoped Span<uint>*/ let powersOfTen2 = bits;
                        /*int*/ let remainingTrailingZeroCount;
                        /*int*/ let trailingPartialCount = $.$spc.System.Math.DivRem(trailingZeroCount, 9/*MaxPartialDigits*/, $.$ref(() => remainingTrailingZeroCount, ($v) => remainingTrailingZeroCount = $v, $.$spc.System.Int32));
                        /*int*/ let fi = $.$spc.System.Numerics.BitOperations.TrailingZeroCount(trailingPartialCount);
                        /*int*/ let omittedLength = $.$srn.System.Number.PowersOf1e9.OmittedLength(fi);
                        /*ReadOnlySpan<uint>*/ let first = this.GetSpan(fi);
                        /*int*/ let curLength = first.Length;
                        trailingPartialCount >>= fi;
                        trailingPartialCount >>= 1;
                        if (($.$spc.System.Numerics.BitOperations.PopCount((trailingPartialCount >>> 0)) & 1) !== 0)
                        {
                            powersOfTen2 = powersOfTen;
                            powersOfTen = bits;
                            powersOfTen2.Clear();
                        }
                        first.CopyTo(powersOfTen);
                        for(++fi; trailingPartialCount !== 0; ++fi, trailingPartialCount >>= 1)
                        {
                            $.$spc.System.Diagnostics.Debug.Assert$1(((fi + 1) | 0) < $.$srn.System.Number.PowersOf1e9.Indexes.Length, "fi + 1 < Indexes.Length");
                            if ((trailingPartialCount & 1) !== 0)
                            {
                                omittedLength += $.$srn.System.Number.PowersOf1e9.OmittedLength(fi);
                                /*ReadOnlySpan<uint>*/ let power = this.GetSpan(fi);
                                /*Span<uint>*/ let src = powersOfTen.Slice$1(0, curLength);
                                /*Span<uint>*/ let dst = powersOfTen2.Slice$1(0, curLength += power.Length);
                                if (power.Length < src.Length)
                                {
                                    $.$srn.System.Numerics.BigIntegerCalculator.Multiply$1($.$spc.System.Span$$($.$spc.System.UInt32).op_Implicit$2(src), power, dst);
                                }
                                else 
                                {
                                    $.$srn.System.Numerics.BigIntegerCalculator.Multiply$1(power, $.$spc.System.Span$$($.$spc.System.UInt32).op_Implicit$2(src), dst);
                                }
                                /*Span<uint>*/ let tmp = powersOfTen;
                                powersOfTen = powersOfTen2;
                                powersOfTen2 = tmp;
                                powersOfTen2.Clear();
                                while(--curLength >= 0 && powersOfTen.get_Item(curLength).$v === 0)
                                {
                                }
                                ++curLength;
                            }
                        }
                        $.$spc.System.Diagnostics.Debug.Assert$1($.$spc.System.Runtime.CompilerServices.Unsafe.AreSame($.$spc.System.UInt32, bits.get_Item(0), powersOfTen2.get_Item(0)), "Unsafe.AreSame(ref bits[0], ref powersOfTen2[0])");
                        powersOfTen = powersOfTen.Slice$1(0, curLength);
                        /*Span<uint>*/ let bits2 = bits.Slice$1(omittedLength, curLength += left.Length);
                        if (left.Length < powersOfTen.Length)
                        {
                            $.$srn.System.Numerics.BigIntegerCalculator.Multiply$1($.$spc.System.Span$$($.$spc.System.UInt32).op_Implicit$2(powersOfTen), left, bits2);
                        }
                        else 
                        {
                            $.$srn.System.Numerics.BigIntegerCalculator.Multiply$1(left, $.$spc.System.Span$$($.$spc.System.UInt32).op_Implicit$2(powersOfTen), bits2);
                        }
                        if (powersOfTenFromPool !== null)
                        {
                            $.$spc.System.Buffers.ArrayPool$$($.$spc.System.UInt32).Shared.Return(powersOfTenFromPool, false);
                        }
                        if (remainingTrailingZeroCount > 0)
                        {
                            /*uint*/ let multiplier = $.$srn.System.Number.UInt32PowersOfTen.get_Item(remainingTrailingZeroCount).$v;
                            /*uint*/ let carry = 0;
                            for(/*int*/ let i = 0; i < bits2.Length; i++)
                            {
                                /*ulong*/ let p = $.$cast(multiplier, $.$spc.System.UInt64) * BigInt(bits2.get_Item(i).$v) + BigInt(carry);
                                bits2.get_Item(i).$v = $.$cast(p, $.$spc.System.UInt32);
                                carry = $.$cast((p >> 32n), $.$spc.System.UInt32);
                            }
                            if (carry !== 0)
                            {
                                bits.get_Item(((omittedLength + curLength) | 0)).$v = carry;
                            }
                        }
                    }
                    //default value type constructor
                    $ctor$3()
                    {
                        return this;
                    }
                    Clone($copy)
                    {
                        let copy = $copy ?? new this.constructor();
                        copy.pow1E9 = this.pow1E9.Clone();
                        return copy;
                    }
                    //default member initializer
                    constructor()
                    {
                        super();
                        this.pow1E9 = $.$default($.$spc.System.ReadOnlySpan$$($.$spc.System.UInt32));
                    }
                    static $h = 764689;
                    static $z = 8;
                    static $f = 0b10000001010000000;
                    static $k = 2;
                    static $$md;
                    static get $md() { return this.$$md ??= {"b":196609,"p":[{"p":$.$spc.System.ReadOnlySpan$$($.$spc.System.Int32).$h,"g":{"r":0,"d":0,"h":21475601169,"f":34},"n":"Indexes","d":764689,"h":17180633873,"f":34},{"p":$.$spc.System.ReadOnlySpan$$($.$spc.System.UInt32).$h,"g":{"r":0,"d":0,"h":30065535761,"f":34},"n":"LeadingPowers1E9","d":764689,"h":25770568465,"f":34}],"m":[{"r":655361,"p":[{"n":"digits","p":655361},{"n":"maxIndex","p":655361,"f":2}],"n":"GetBufferSize","d":764689,"h":38655470353,"f":33},{"r":$.$spc.System.ReadOnlySpan$$($.$spc.System.UInt32).$h,"p":[{"n":"index","p":655361}],"n":"GetSpan","d":764689,"h":42950437649,"f":1},{"r":655361,"p":[{"n":"index","p":655361}],"n":"OmittedLength","d":764689,"h":47245404945,"f":33},{"r":65537,"p":[{"n":"left","p":$.$spc.System.ReadOnlySpan$$($.$spc.System.UInt32).$h},{"n":"trailingZeroCount","p":655361},{"n":"bits","p":$.$spc.System.Span$$($.$spc.System.UInt32).$h}],"n":"MultiplyPowerOfTen","d":764689,"h":51540372241,"f":1}],"l":[{"t":$.$spc.System.ReadOnlySpan$$($.$spc.System.UInt32).$h,"n":"pow1E9","d":764689,"h":4295731985,"f":2},{"t":720897,"n":"TenPowMaxPartial","d":764689,"h":8590699281,"f":33},{"t":655361,"n":"MaxPartialDigits","d":764689,"h":12885666577,"f":33}],"c":[{"p":[{"n":"pow1E9","p":$.$spc.System.Span$$($.$spc.System.UInt32).$h}],"n":".ctor","o":"$ctor$2","d":764689,"h":34360503057,"f":1},{"n":".ctor","o":"$ctor$3","d":764689,"h":55835339537,"f":1}],"d":502545,"h":764689}; }
                    static get $b() { return $.$spc.System.ValueType; }
                    static get $fullName() { return `System.Number.PowersOf1e9`; }
                }, $cls, ($v) => $cls.$_PowersOf1e9 = $v);
            }
            //Static Initializer
            static $sinit()
            {
                {
                    this.PosNumberFormat = "#";
                }
                {
                    this.s_posCurrencyFormats = $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$spc.System.String.$type, [ "$#", "#$", "$ #", "# $" ], null, null);
                }
                {
                    this.s_negCurrencyFormats = $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$spc.System.String.$type, [ "($#)", "-$#", "$-#", "$#-", "(#$)", "-#$", "#-$", "#$-", "-# $", "-$ #", "# $-", "$ #-", "$ -#", "#- $", "($ #)", "(# $)", "$- #" ], null, null);
                }
                {
                    this.s_posPercentFormats = $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$spc.System.String.$type, [ "# %", "#%", "%#", "% #" ], null, null);
                }
                {
                    this.s_negPercentFormats = $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$spc.System.String.$type, [ "-# %", "-#%", "-%#", "%-#", "%#-", "#-%", "#%-", "-% #", "# %-", "% #-", "% -#", "#- %" ], null, null);
                }
                {
                    this.s_negNumberFormats = $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$spc.System.String.$type, [ "(#)", "-#", "- #", "#-", "# -" ], null, null);
                }
            }
            static $h = 502545;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":$.$spc.System.ReadOnlySpan$$($.$spc.System.UInt32).$h,"g":{"r":0,"d":0,"h":266288474897,"f":34},"n":"UInt32PowersOfTen","d":502545,"h":261993507601,"f":34}],"m":[{"r":262145,"p":[{"n":"info","p":54001665}],"n":"AllowHyphenDuringParsing","d":502545,"h":55835077393,"f":40},{"r":(TChar) => $.$spc.System.ReadOnlySpan$$(TChar).$h,"p":[{"n":"info","p":54001665}],"g":["TChar"],"n":"PositiveSignTChar","d":502545,"h":60130044689,"f":131112},{"r":(TChar) => $.$spc.System.ReadOnlySpan$$(TChar).$h,"p":[{"n":"info","p":54001665}],"g":["TChar"],"n":"NegativeSignTChar","d":502545,"h":64425011985,"f":131112},{"r":(TChar) => $.$spc.System.ReadOnlySpan$$(TChar).$h,"p":[{"n":"info","p":54001665}],"g":["TChar"],"n":"CurrencySymbolTChar","d":502545,"h":68719979281,"f":131112},{"r":(TChar) => $.$spc.System.ReadOnlySpan$$(TChar).$h,"p":[{"n":"info","p":54001665}],"g":["TChar"],"n":"PercentSymbolTChar","d":502545,"h":73014946577,"f":131112},{"r":(TChar) => $.$spc.System.ReadOnlySpan$$(TChar).$h,"p":[{"n":"info","p":54001665}],"g":["TChar"],"n":"PerMilleSymbolTChar","d":502545,"h":77309913873,"f":131112},{"r":(TChar) => $.$spc.System.ReadOnlySpan$$(TChar).$h,"p":[{"n":"info","p":54001665}],"g":["TChar"],"n":"CurrencyDecimalSeparatorTChar","d":502545,"h":81604881169,"f":131112},{"r":(TChar) => $.$spc.System.ReadOnlySpan$$(TChar).$h,"p":[{"n":"info","p":54001665}],"g":["TChar"],"n":"CurrencyGroupSeparatorTChar","d":502545,"h":85899848465,"f":131112},{"r":(TChar) => $.$spc.System.ReadOnlySpan$$(TChar).$h,"p":[{"n":"info","p":54001665}],"g":["TChar"],"n":"NumberDecimalSeparatorTChar","d":502545,"h":90194815761,"f":131112},{"r":(TChar) => $.$spc.System.ReadOnlySpan$$(TChar).$h,"p":[{"n":"info","p":54001665}],"g":["TChar"],"n":"NumberGroupSeparatorTChar","d":502545,"h":94489783057,"f":131112},{"r":(TChar) => $.$spc.System.ReadOnlySpan$$(TChar).$h,"p":[{"n":"info","p":54001665}],"g":["TChar"],"n":"PercentDecimalSeparatorTChar","d":502545,"h":98784750353,"f":131112},{"r":(TChar) => $.$spc.System.ReadOnlySpan$$(TChar).$h,"p":[{"n":"info","p":54001665}],"g":["TChar"],"n":"PercentGroupSeparatorTChar","d":502545,"h":103079717649,"f":131112},{"r":262145,"p":[{"n":"str","p":0,"f":4},{"n":"strEnd","p":0},{"n":"styles","p":54067201},{"n":"number","p":568081,"f":4},{"n":"info","p":54001665}],"g":["TChar"],"n":"TryParseNumber","d":502545,"h":107374684945,"f":131106},{"r":262145,"p":[{"n":"value","p":(TChar) => $.$spc.System.ReadOnlySpan$$(TChar).$h},{"n":"styles","p":54067201},{"n":"number","p":568081,"f":4},{"n":"info","p":54001665}],"g":["TChar"],"n":"TryStringToNumber","d":502545,"h":111669652241,"f":131112},{"r":262145,"p":[{"n":"value","p":(TChar) => $.$spc.System.ReadOnlySpan$$(TChar).$h},{"n":"index","p":655361}],"g":["TChar"],"n":"TrailingZeros","d":502545,"h":115964619537,"f":131106},{"r":262145,"p":[{"n":"ch","p":720897}],"n":"IsWhite","d":502545,"h":120259586833,"f":34},{"r":262145,"p":[{"n":"ch","p":720897}],"n":"IsDigit","d":502545,"h":124554554129,"f":34},{"r":262145,"p":[{"n":"c","p":720897}],"n":"IsSpaceReplacingChar","d":502545,"h":133144488721,"f":34},{"r":0,"p":[{"n":"p","p":0},{"n":"pEnd","p":0},{"n":"info","p":54001665}],"g":["TChar"],"n":"MatchNegativeSignChars","d":502545,"h":137439456017,"f":131106},{"r":0,"p":[{"n":"p","p":0},{"n":"pEnd","p":0},{"n":"value","p":(TChar) => $.$spc.System.ReadOnlySpan$$(TChar).$h}],"g":["TChar"],"n":"MatchChars","d":502545,"h":141734423313,"f":131106},{"r":458753,"p":[{"n":"format","p":$.$spc.System.ReadOnlySpan$$($.$spc.System.Char).$h},{"n":"digits","p":655361,"f":2}],"n":"ParseFormatSpecifier","d":502545,"h":184684096273,"f":40},{"r":0,"p":[{"n":"bufferEnd","p":0},{"n":"value","p":720897},{"n":"digits","p":655361}],"g":["TChar"],"n":"UInt32ToDecChars","d":502545,"h":188979063569,"f":131112},{"r":65537,"p":[{"n":"vlb","p":(TChar) => $.$srn.System.Collections.Generic.ValueListBuilder$$(TChar).$h,"f":4},{"n":"number","p":568081,"f":4},{"n":"format","p":458753},{"n":"nMaxDigits","p":655361},{"n":"info","p":54001665}],"g":["TChar"],"n":"NumberToString","d":502545,"h":193274030865,"f":131112},{"r":65537,"p":[{"n":"vlb","p":(TChar) => $.$srn.System.Collections.Generic.ValueListBuilder$$(TChar).$h,"f":4},{"n":"number","p":568081,"f":4},{"n":"format","p":$.$spc.System.ReadOnlySpan$$($.$spc.System.Char).$h},{"n":"info","p":54001665}],"g":["TChar"],"n":"NumberToStringFormat","d":502545,"h":197568998161,"f":131112},{"r":65537,"p":[{"n":"vlb","p":(TChar) => $.$srn.System.Collections.Generic.ValueListBuilder$$(TChar).$h,"f":4},{"n":"number","p":568081,"f":4},{"n":"nMaxDigits","p":655361},{"n":"info","p":54001665}],"g":["TChar"],"n":"FormatCurrency","d":502545,"h":201863965457,"f":131106},{"r":65537,"p":[{"n":"vlb","p":(TChar) => $.$srn.System.Collections.Generic.ValueListBuilder$$(TChar).$h,"f":4},{"n":"number","p":568081,"f":4},{"n":"nMaxDigits","p":655361},{"n":"groupDigits","p":0},{"n":"sDecimal","p":(TChar) => $.$spc.System.ReadOnlySpan$$(TChar).$h},{"n":"sGroup","p":(TChar) => $.$spc.System.ReadOnlySpan$$(TChar).$h}],"g":["TChar"],"n":"FormatFixed","d":502545,"h":206158932753,"f":131106},{"r":65537,"p":[{"n":"vlb","p":(TChar) => $.$srn.System.Collections.Generic.ValueListBuilder$$(TChar).$h,"f":4},{"n":"ch","p":458753}],"g":["TChar"],"n":"AppendUnknownChar","d":502545,"h":210453900049,"f":131106},{"r":65537,"p":[{"n":"vlb","p":(TChar) => $.$srn.System.Collections.Generic.ValueListBuilder$$(TChar).$h,"f":4},{"n":"number","p":568081,"f":4},{"n":"nMaxDigits","p":655361},{"n":"info","p":54001665}],"g":["TChar"],"n":"FormatNumber","d":502545,"h":214748867345,"f":131106},{"r":65537,"p":[{"n":"vlb","p":(TChar) => $.$srn.System.Collections.Generic.ValueListBuilder$$(TChar).$h,"f":4},{"n":"number","p":568081,"f":4},{"n":"nMaxDigits","p":655361},{"n":"info","p":54001665},{"n":"expChar","p":458753}],"g":["TChar"],"n":"FormatScientific","d":502545,"h":219043834641,"f":131106},{"r":65537,"p":[{"n":"vlb","p":(TChar) => $.$srn.System.Collections.Generic.ValueListBuilder$$(TChar).$h,"f":4},{"n":"info","p":54001665},{"n":"value","p":655361},{"n":"expChar","p":458753},{"n":"minDigits","p":655361},{"n":"positiveSign","p":262145}],"g":["TChar"],"n":"FormatExponent","d":502545,"h":223338801937,"f":131106},{"r":65537,"p":[{"n":"vlb","p":(TChar) => $.$srn.System.Collections.Generic.ValueListBuilder$$(TChar).$h,"f":4},{"n":"number","p":568081,"f":4},{"n":"nMaxDigits","p":655361},{"n":"info","p":54001665},{"n":"expChar","p":458753},{"n":"suppressScientific","p":262145}],"g":["TChar"],"n":"FormatGeneral","d":502545,"h":227633769233,"f":131106},{"r":65537,"p":[{"n":"vlb","p":(TChar) => $.$srn.System.Collections.Generic.ValueListBuilder$$(TChar).$h,"f":4},{"n":"number","p":568081,"f":4},{"n":"nMaxDigits","p":655361},{"n":"info","p":54001665}],"g":["TChar"],"n":"FormatPercent","d":502545,"h":231928736529,"f":131106},{"r":65537,"p":[{"n":"number","p":568081,"f":4},{"n":"pos","p":655361},{"n":"isCorrectlyRounded","p":262145}],"n":"RoundNumber","d":502545,"h":236223703825,"f":40},{"r":655361,"p":[{"n":"format","p":$.$spc.System.ReadOnlySpan$$($.$spc.System.Char).$h},{"n":"section","p":655361}],"n":"FindSection","d":502545,"h":240518671121,"f":34},{"r":0,"p":[{"n":"info","p":54001665}],"n":"NumberGroupSizes","d":502545,"h":244813638417,"f":34},{"r":0,"p":[{"n":"info","p":54001665}],"n":"CurrencyGroupSizes","d":502545,"h":249108605713,"f":34},{"r":0,"p":[{"n":"info","p":54001665}],"n":"PercentGroupSizes","d":502545,"h":253403573009,"f":34},{"r":65537,"p":[{"n":"status","p":699153}],"n":"ThrowOverflowOrFormatException","d":502545,"h":270583442193,"f":40},{"r":47251457,"p":[{"n":"status","p":699153}],"n":"GetException","d":502545,"h":274878409489,"f":34},{"r":262145,"p":[{"n":"style","p":54067201},{"n":"e","p":13434881,"f":2}],"n":"TryValidateParseStyleInteger","d":502545,"h":279173376785,"f":40},{"r":699153,"p":[{"n":"value","p":$.$spc.System.ReadOnlySpan$$($.$spc.System.Char).$h},{"n":"style","p":54067201},{"n":"info","p":54001665},{"n":"result","p":830225,"f":2}],"n":"TryParseBigInteger","d":502545,"h":283468344081,"f":40},{"r":699153,"p":[{"n":"value","p":$.$spc.System.ReadOnlySpan$$($.$spc.System.Char).$h},{"n":"style","p":54067201},{"n":"info","p":54001665},{"n":"result","p":830225,"f":2}],"n":"TryParseBigIntegerNumber","d":502545,"h":287763311377,"f":40},{"r":830225,"p":[{"n":"value","p":$.$spc.System.ReadOnlySpan$$($.$spc.System.Char).$h},{"n":"style","p":54067201},{"n":"info","p":54001665}],"n":"ParseBigInteger","d":502545,"h":292058278673,"f":40},{"r":699153,"p":[{"n":"value","p":(TParser, TChar) => $.$spc.System.ReadOnlySpan$$(TChar).$h},{"n":"style","p":54067201},{"n":"result","p":830225,"f":2}],"g":["TParser","TChar"],"n":"TryParseBigIntegerHexOrBinaryNumberStyle","d":502545,"h":296353245969,"f":131112},{"r":699153,"p":[{"n":"number","p":568081,"f":4},{"n":"result","p":830225,"f":2}],"n":"NumberToBigInteger","d":502545,"h":309238147857,"f":34},{"r":1310721,"p":[{"n":"targetSpan","p":262145},{"n":"value","p":830225},{"n":"format","p":458753},{"n":"digits","p":655361},{"n":"info","p":54001665},{"n":"destination","p":$.$spc.System.Span$$($.$spc.System.Char).$h},{"n":"charsWritten","p":655361,"f":2},{"n":"spanSuccess","p":262145,"f":2}],"n":"FormatBigIntegerToHex","d":502545,"h":313533115153,"f":34},{"r":1310721,"p":[{"n":"targetSpan","p":262145},{"n":"value","p":830225},{"n":"digits","p":655361},{"n":"destination","p":$.$spc.System.Span$$($.$spc.System.Char).$h},{"n":"charsWritten","p":655361,"f":2},{"n":"spanSuccess","p":262145,"f":2}],"n":"FormatBigIntegerToBinary","d":502545,"h":317828082449,"f":34},{"r":1310721,"p":[{"n":"value","p":830225},{"n":"format","p":1310721},{"n":"info","p":54001665}],"n":"FormatBigInteger","d":502545,"h":322123049745,"f":40},{"r":262145,"p":[{"n":"value","p":830225},{"n":"format","p":$.$spc.System.ReadOnlySpan$$($.$spc.System.Char).$h},{"n":"info","p":54001665},{"n":"destination","p":$.$spc.System.Span$$($.$spc.System.Char).$h},{"n":"charsWritten","p":655361,"f":2}],"n":"TryFormatBigInteger","d":502545,"h":326418017041,"f":40},{"r":1310721,"p":[{"n":"targetSpan","p":262145},{"n":"value","p":830225},{"n":"formatString","p":1310721},{"n":"formatSpan","p":$.$spc.System.ReadOnlySpan$$($.$spc.System.Char).$h},{"n":"info","p":54001665},{"n":"destination","p":$.$spc.System.Span$$($.$spc.System.Char).$h},{"n":"charsWritten","p":655361,"f":2},{"n":"spanSuccess","p":262145,"f":2}],"n":"FormatBigInteger","o":"@$1","d":502545,"h":330712984337,"f":34},{"r":0,"p":[{"n":"bufferEnd","p":0},{"n":"base1E9Value","p":$.$spc.System.ReadOnlySpan$$($.$spc.System.UInt32).$h},{"n":"digits","p":655361}],"g":["TChar"],"n":"BigIntegerToDecChars","d":502545,"h":335007951633,"f":131106}],"l":[{"t":655361,"n":"DecimalNumberBufferLength","d":502545,"h":4295469841,"f":40},{"t":655361,"n":"DoubleNumberBufferLength","d":502545,"h":8590437137,"f":40},{"t":655361,"n":"Int32NumberBufferLength","d":502545,"h":12885404433,"f":40},{"t":655361,"n":"Int64NumberBufferLength","d":502545,"h":17180371729,"f":40},{"t":655361,"n":"Int128NumberBufferLength","d":502545,"h":21475339025,"f":40},{"t":655361,"n":"SingleNumberBufferLength","d":502545,"h":25770306321,"f":40},{"t":655361,"n":"HalfNumberBufferLength","d":502545,"h":30065273617,"f":40},{"t":655361,"n":"UInt32NumberBufferLength","d":502545,"h":34360240913,"f":40},{"t":655361,"n":"UInt64NumberBufferLength","d":502545,"h":38655208209,"f":40},{"t":655361,"n":"UInt128NumberBufferLength","d":502545,"h":42950175505,"f":40},{"t":655361,"n":"CharStackBufferSize","d":502545,"h":146029390609,"f":34},{"t":655361,"n":"DefaultPrecisionExponentialFormat","d":502545,"h":150324357905,"f":34},{"t":655361,"n":"MaxUInt32DecDigits","d":502545,"h":154619325201,"f":34},{"t":1310721,"n":"PosNumberFormat","d":502545,"h":158914292497,"f":34},{"t":0,"n":"s_posCurrencyFormats","d":502545,"h":163209259793,"f":34},{"t":0,"n":"s_negCurrencyFormats","d":502545,"h":167504227089,"f":34},{"t":0,"n":"s_posPercentFormats","d":502545,"h":171799194385,"f":34},{"t":0,"n":"s_negPercentFormats","d":502545,"h":176094161681,"f":34},{"t":0,"n":"s_negNumberFormats","d":502545,"h":180389128977,"f":34},{"t":54067201,"n":"InvalidNumberStyles","d":502545,"h":257698540305,"f":34},{"t":655361,"n":"BigIntegerParseNaiveThreshold","d":502545,"h":300648213265,"f":33},{"t":655361,"n":"BigIntegerParseNaiveThresholdInRecursive","d":502545,"h":304943180561,"f":33}],"j":[568081,633617,699153,764689],"h":502545}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.Number`; }
        });
        
        $asm.$str("$srn.System.Collections.Generic.ValueListBuilder<>", (T) => $asm.$gt("$srn.System.Collections.Generic.ValueListBuilder<>", [T], ($self) => class ValueListBuilder$$ extends $.$spc.System.ValueType
        {
            /*Span<T>*/  get _span() { return this.$getField(0, 8); }
            /*Span<T>*/  set _span(value) { this.$setField(0, 8, value); }
            /*T[]?*/  get _arrayFromPool() { return this.$getField(8, 4); }
            /*T[]?*/  set _arrayFromPool(value) { this.$setField(8, 4, value); }
            /*int*/  get _pos() { return this.$getField(12, 4); }
            /*int*/  set _pos(value) { this.$setField(12, 4, value); }
            $ctor$2(/*Span<T?>*/ scratchBuffer)
            {
                super.$ctor$1();
                {
                    this._span = scratchBuffer;
                }
                return this;
            }
            $ctor$3(/*int*/ capacity)
            {
                super.$ctor$1();
                {
                    this.Grow(capacity);
                }
                return this;
            }
            /*int */ get Length()
            {
                return this._pos;
            }
            /*int */ set Length(value)
            {
                $.$spc.System.Diagnostics.Debug.Assert$1(value >= 0, "value >= 0");
                $.$spc.System.Diagnostics.Debug.Assert$1(value <= this._span.Length, "value <= _span.Length");
                this._pos = value;
            }
            /*ref T*/ get_Item(/*int*/ index)
            {
                $.$spc.System.Diagnostics.Debug.Assert$1(index < this._pos, "index < _pos");
                return this._span.get_Item(index);
            }
            /*void */ Append(/*T*/ item)
            {
                /*int*/ let pos = this._pos;
                /*Span<T>*/ let span = this._span;
                if ((pos >>> 0) < (span.Length >>> 0))
                {
                    span.get_Item(pos).$v = item;
                    this._pos = ((pos + 1) | 0);
                }
                else 
                {
                    this.AddWithResize(item);
                }
            }
            /*void */ Append$1(/*scoped ReadOnlySpan<T>*/ source)
            {
                /*int*/ let pos = this._pos;
                /*Span<T>*/ let span = this._span;
                if (source.Length === 1 && (pos >>> 0) < (span.Length >>> 0))
                {
                    span.get_Item(pos).$v = source.get_Item(0).$v;
                    this._pos = ((pos + 1) | 0);
                }
                else 
                {
                    this.AppendMultiChar(source);
                }
            }
            /*void */ AppendMultiChar(/*scoped ReadOnlySpan<T>*/ source)
            {
                if (((((this._pos + source.Length) | 0)) >>> 0) > (this._span.Length >>> 0))
                {
                    this.Grow(((((this._span.Length - this._pos) | 0) + source.Length) | 0));
                }
                source.CopyTo(this._span.Slice(this._pos));
                this._pos += source.Length;
            }
            /*void */ Insert(/*int*/ index, /*scoped ReadOnlySpan<T>*/ source)
            {
                $.$spc.System.Diagnostics.Debug.Assert$1(index === 0, "Implementation currently only supports index == 0");
                if (((((this._pos + source.Length) | 0)) >>> 0) > (this._span.Length >>> 0))
                {
                    this.Grow(source.Length);
                }
                this._span.Slice$1(0, this._pos).CopyTo(this._span.Slice(source.Length));
                source.CopyTo(this._span);
                this._pos += source.Length;
            }
            /*Span<T> */ AppendSpan(/*int*/ length)
            {
                $.$spc.System.Diagnostics.Debug.Assert$1(length >= 0, "length >= 0");
                /*int*/ let pos = this._pos;
                /*Span<T>*/ let span = this._span;
                if ($.$cast((pos >>> 0), $.$spc.System.UInt64) + $.$cast((length >>> 0), $.$spc.System.UInt64) <= $.$cast((span.Length >>> 0), $.$spc.System.UInt64))
                {
                    this._pos = ((pos + length) | 0);
                    return span.Slice$1(pos, length);
                }
                else 
                {
                    return this.AppendSpanWithGrow(length);
                }
            }
            /*Span<T> */ AppendSpanWithGrow(/*int*/ length)
            {
                /*int*/ let pos = this._pos;
                this.Grow(((((this._span.Length - pos) | 0) + length) | 0));
                this._pos += length;
                return this._span.Slice$1(pos, length);
            }
            /*void */ AddWithResize(/*T*/ item)
            {
                $.$spc.System.Diagnostics.Debug.Assert$1(this._pos === this._span.Length, "_pos == _span.Length");
                /*int*/ let pos = this._pos;
                this.Grow(1);
                this._span.get_Item(pos).$v = item;
                this._pos = ((pos + 1) | 0);
            }
            /*ReadOnlySpan<T> */ AsSpan()
            {
                return $.$spc.System.Span$$(T).op_Implicit$2(this._span.Slice$1(0, this._pos));
            }
            /*bool */ TryCopyTo(/*Span<T>*/ destination, /*out int*/ itemsWritten)
            {
                if (this._span.Slice$1(0, this._pos).TryCopyTo(destination))
                {
                    itemsWritten.$v = this._pos;
                    return true;
                }
                itemsWritten.$v = 0;
                return false;
            }
            /*void */ Dispose()
            {
                /*T[]?*/ let toReturn = this._arrayFromPool;
                if (toReturn !== null)
                {
                    this._arrayFromPool = null;
                    if (!T.$type.IsPrimitive)
                    {
                        $.$spc.System.Array.Clear$1(toReturn, 0, this._pos);
                    }
                    $.$spc.System.Buffers.ArrayPool$$(T).Shared.Return(toReturn, false);
                }
            }
            /*void */ Grow(/*int*/ additionalCapacityRequired)
            {
                /*int*/ let ArrayMaxLength = 2147483591;
                /*int*/ let nextCapacity = $.$spc.System.Math.Max$4(this._span.Length !== 0 ? ((this._span.Length * 2) | 0) : 4, ((this._span.Length + additionalCapacityRequired) | 0));
                if ((nextCapacity >>> 0) > ArrayMaxLength)
                {
                    nextCapacity = $.$spc.System.Math.Max$4($.$spc.System.Math.Max$4(((this._span.Length + 1) | 0), ArrayMaxLength), this._span.Length);
                }
                /*T[]*/ let array = $.$spc.System.Buffers.ArrayPool$$(T).Shared.Rent(nextCapacity);
                this._span.CopyTo($.$spc.System.Span$$(T).op_Implicit(array));
                /*T[]?*/ let toReturn = this._arrayFromPool;
                this._span = $.$spc.System.Span$$(T).op_Implicit(this._arrayFromPool = array);
                if (toReturn !== null)
                {
                    if (!T.$type.IsPrimitive)
                    {
                        $.$spc.System.Array.Clear$1(toReturn, 0, this._pos);
                    }
                    $.$spc.System.Buffers.ArrayPool$$(T).Shared.Return(toReturn, false);
                }
            }
            //default value type constructor
            $ctor$4()
            {
                return this;
            }
            Clone($copy)
            {
                let copy = $copy ?? new this.constructor();
                copy._span = this._span.Clone();
                copy._arrayFromPool = this._arrayFromPool;
                copy._pos = this._pos;
                return copy;
            }
            //default member initializer
            constructor()
            {
                super();
                this._span = $.$default($.$spc.System.Span$$(T));
                this._arrayFromPool = null;
                this._pos = 0;
            }
            static $h = 305937;
            static $g = 1;
            static $z = 16;
            static $f = 0b1011000000;
            static $k = 2;
            static $$md;
            static get $md() { return this.$$md ??= {"b":196609,"p":[{"p":655361,"g":{"r":0,"d":0,"h":Number(BigInt(this.$h)|0x700000000n),"f":1},"s":{"r":0,"d":0,"h":Number(BigInt(this.$h)|0x800000000n),"f":1},"n":"Length","d":this.$h,"h":Number(BigInt(this.$h)|0x600000000n),"f":1},{"p":T?.$h??1507328,"i":[{"n":"index","p":655361}],"g":{"r":0,"d":0,"h":Number(BigInt(this.$h)|0xA00000000n),"f":1},"n":"Item","o":"@$2","d":this.$h,"h":Number(BigInt(this.$h)|0x900000000n),"f":1}],"m":[{"r":65537,"p":[{"n":"item","p":T?.$h??1507328}],"n":"Append","d":this.$h,"h":Number(BigInt(this.$h)|0xB00000000n),"f":1},{"r":65537,"p":[{"n":"source","p":$.$spc.System.ReadOnlySpan$$(T).$h}],"n":"Append","o":"@$1","d":this.$h,"h":Number(BigInt(this.$h)|0xC00000000n),"f":1},{"r":65537,"p":[{"n":"source","p":$.$spc.System.ReadOnlySpan$$(T).$h}],"n":"AppendMultiChar","d":this.$h,"h":Number(BigInt(this.$h)|0xD00000000n),"f":2},{"r":65537,"p":[{"n":"index","p":655361},{"n":"source","p":$.$spc.System.ReadOnlySpan$$(T).$h}],"n":"Insert","d":this.$h,"h":Number(BigInt(this.$h)|0xE00000000n),"f":1},{"r":$.$spc.System.Span$$(T).$h,"p":[{"n":"length","p":655361}],"n":"AppendSpan","d":this.$h,"h":Number(BigInt(this.$h)|0xF00000000n),"f":1},{"r":$.$spc.System.Span$$(T).$h,"p":[{"n":"length","p":655361}],"n":"AppendSpanWithGrow","d":this.$h,"h":Number(BigInt(this.$h)|0x1000000000n),"f":2},{"r":65537,"p":[{"n":"item","p":T?.$h??1507328}],"n":"AddWithResize","d":this.$h,"h":Number(BigInt(this.$h)|0x1100000000n),"f":2},{"r":$.$spc.System.ReadOnlySpan$$(T).$h,"n":"AsSpan","d":this.$h,"h":Number(BigInt(this.$h)|0x1200000000n),"f":1},{"r":262145,"p":[{"n":"destination","p":$.$spc.System.Span$$(T).$h},{"n":"itemsWritten","p":655361,"f":2}],"n":"TryCopyTo","d":this.$h,"h":Number(BigInt(this.$h)|0x1300000000n),"f":1},{"r":65537,"n":"Dispose","d":this.$h,"h":Number(BigInt(this.$h)|0x1400000000n),"f":1},{"r":65537,"p":[{"n":"additionalCapacityRequired","p":655361,"f":65,"v":1}],"n":"Grow","d":this.$h,"h":Number(BigInt(this.$h)|0x1500000000n),"f":2}],"l":[{"t":$.$spc.System.Span$$(T).$h,"n":"_span","d":this.$h,"h":Number(BigInt(this.$h)|0x100000000n),"f":2},{"t":0,"n":"_arrayFromPool","d":this.$h,"h":Number(BigInt(this.$h)|0x200000000n),"f":2},{"t":655361,"n":"_pos","d":this.$h,"h":Number(BigInt(this.$h)|0x300000000n),"f":2}],"c":[{"p":[{"n":"scratchBuffer","p":$.$spc.System.Span$$(T).$h}],"n":".ctor","o":"$ctor$2","d":this.$h,"h":Number(BigInt(this.$h)|0x400000000n),"f":1},{"p":[{"n":"capacity","p":655361}],"n":".ctor","o":"$ctor$3","d":this.$h,"h":Number(BigInt(this.$h)|0x500000000n),"f":1},{"n":".ctor","o":"$ctor$4","d":this.$h,"h":Number(BigInt(this.$h)|0x1600000000n),"f":1}],"g":[T?.$h??1507328],"r":1,"h":this.$h}; }
            static get $b() { return $.$spc.System.ValueType; }
            static get $fullName() { return `System.Collections.Generic.ValueListBuilder<${T?.$fullName}>`; }
        }));
        
        $asm.$str("$srn.System.Text.ValueStringBuilder", ($self) => class ValueStringBuilder extends $.$spc.System.ValueType
        {
            /*char[]?*/  get _arrayToReturnToPool() { return this.$getField(0, 4); }
            /*char[]?*/  set _arrayToReturnToPool(value) { this.$setField(0, 4, value); }
            /*Span<char>*/  get _chars() { return this.$getField(4, 6); }
            /*Span<char>*/  set _chars(value) { this.$setField(4, 6, value); }
            /*int*/  get _pos() { return this.$getField(10, 4); }
            /*int*/  set _pos(value) { this.$setField(10, 4, value); }
            $ctor$2(/*Span<char>*/ initialBuffer)
            {
                super.$ctor$1();
                {
                    this._arrayToReturnToPool = null;
                    this._chars = initialBuffer;
                    this._pos = 0;
                }
                return this;
            }
            $ctor$3(/*int*/ initialCapacity)
            {
                super.$ctor$1();
                {
                    this._arrayToReturnToPool = $.$spc.System.Buffers.ArrayPool$$($.$spc.System.Char).Shared.Rent(initialCapacity);
                    this._chars = $.$spc.System.Span$$($.$spc.System.Char).op_Implicit(this._arrayToReturnToPool);
                    this._pos = 0;
                }
                return this;
            }
            /*int */ get Length()
            {
                return this._pos;
            }
            /*int */ set Length(value)
            {
                $.$spc.System.Diagnostics.Debug.Assert$1(value >= 0, "value >= 0");
                $.$spc.System.Diagnostics.Debug.Assert$1(value <= this._chars.Length, "value <= _chars.Length");
                this._pos = value;
            }
            /*int */ get Capacity()
            {
                return this._chars.Length;
            }
            /*void */ EnsureCapacity(/*int*/ capacity)
            {
                $.$spc.System.Diagnostics.Debug.Assert$1(capacity >= 0, "capacity >= 0");
                if ((capacity >>> 0) > (this._chars.Length >>> 0))
                {
                    this.Grow(((capacity - this._pos) | 0));
                }
            }
            /*ref char */ GetPinnableReference()
            {
                return $.$spc.System.Runtime.InteropServices.MemoryMarshal.GetReference($.$spc.System.Char, this._chars);
            }
            /*ref char */ GetPinnableReference$1(/*bool*/ terminate)
            {
                if (terminate)
                {
                    this.EnsureCapacity(((this.Length + 1) | 0));
                    this._chars.get_Item(this.Length).$v = /*\u0000*/ 0;
                }
                return $.$spc.System.Runtime.InteropServices.MemoryMarshal.GetReference($.$spc.System.Char, this._chars);
            }
            /*ref char*/ get_Item(/*int*/ index)
            {
                $.$spc.System.Diagnostics.Debug.Assert$1(index < this._pos, "index < _pos");
                return this._chars.get_Item(index);
            }
            static/*conventional*/ /*string */ ToString()
            {
                /*string*/ let s = $.$spc.System.Span$$($.$spc.System.Char).ToString.call(this._chars.Slice$1(0, this._pos));
                this.Dispose();
                return s;
            }
            //Static convention instance redirect
            /*string */ ToString() { return $.$srn.System.Text.ValueStringBuilder.ToString.apply(this, arguments); }
            /*Span<char> */ get RawChars()
            {
                return this._chars;
            }
            /*ReadOnlySpan<char> */ AsSpan(/*bool*/ terminate)
            {
                if (terminate)
                {
                    this.EnsureCapacity(((this.Length + 1) | 0));
                    this._chars.get_Item(this.Length).$v = /*\u0000*/ 0;
                }
                return $.$spc.System.Span$$($.$spc.System.Char).op_Implicit$2(this._chars.Slice$1(0, this._pos));
            }
            /*ReadOnlySpan<char> */ AsSpan$1()
            {
                return $.$spc.System.Span$$($.$spc.System.Char).op_Implicit$2(this._chars.Slice$1(0, this._pos));
            }
            /*ReadOnlySpan<char> */ AsSpan$2(/*int*/ start)
            {
                return $.$spc.System.Span$$($.$spc.System.Char).op_Implicit$2(this._chars.Slice$1(start, ((this._pos - start) | 0)));
            }
            /*ReadOnlySpan<char> */ AsSpan$3(/*int*/ start, /*int*/ length)
            {
                return $.$spc.System.Span$$($.$spc.System.Char).op_Implicit$2(this._chars.Slice$1(start, length));
            }
            /*bool */ TryCopyTo(/*Span<char>*/ destination, /*out int*/ charsWritten)
            {
                if (this._chars.Slice$1(0, this._pos).TryCopyTo(destination))
                {
                    charsWritten.$v = this._pos;
                    this.Dispose();
                    return true;
                }
                else 
                {
                    charsWritten.$v = 0;
                    this.Dispose();
                    return false;
                }
            }
            /*void */ Insert(/*int*/ index, /*char*/ value, /*int*/ count)
            {
                if (this._pos > ((this._chars.Length - count) | 0))
                {
                    this.Grow(count);
                }
                /*int*/ let remaining = ((this._pos - index) | 0);
                this._chars.Slice$1(index, remaining).CopyTo(this._chars.Slice(((index + count) | 0)));
                this._chars.Slice$1(index, count).Fill(value);
                this._pos += count;
            }
            /*void */ Insert$1(/*int*/ index, /*string?*/ s)
            {
                if ($.$spc.System.String.op_Equality(s, null))
                {
                    return;
                }
                /*int*/ let count = s.length;
                if (this._pos > (((this._chars.Length - count) | 0)))
                {
                    this.Grow(count);
                }
                /*int*/ let remaining = ((this._pos - index) | 0);
                this._chars.Slice$1(index, remaining).CopyTo(this._chars.Slice(((index + count) | 0)));
                $.$spc.System.String.CopyTo$1.call(s, this._chars.Slice(index));
                this._pos += count;
            }
            /*void */ Append(/*char*/ c)
            {
                /*int*/ let pos = this._pos;
                /*Span<char>*/ let chars = this._chars;
                if ((pos >>> 0) < (chars.Length >>> 0))
                {
                    chars.get_Item(pos).$v = c;
                    this._pos = ((pos + 1) | 0);
                }
                else 
                {
                    this.GrowAndAppend(c);
                }
            }
            /*void */ Append$1(/*string?*/ s)
            {
                if ($.$spc.System.String.op_Equality(s, null))
                {
                    return;
                }
                /*int*/ let pos = this._pos;
                if (s.length === 1 && (pos >>> 0) < (this._chars.Length >>> 0))
                {
                    this._chars.get_Item(pos).$v = $.$spc.System.String.get_Chars.call(s, 0);
                    this._pos = ((pos + 1) | 0);
                }
                else 
                {
                    this.AppendSlow(s);
                }
            }
            /*void */ AppendSlow(/*string*/ s)
            {
                /*int*/ let pos = this._pos;
                if (pos > ((this._chars.Length - s.length) | 0))
                {
                    this.Grow(s.length);
                }
                $.$spc.System.String.CopyTo$1.call(s, this._chars.Slice(pos));
                this._pos += s.length;
            }
            /*void */ Append$2(/*char*/ c, /*int*/ count)
            {
                if (this._pos > ((this._chars.Length - count) | 0))
                {
                    this.Grow(count);
                }
                /*Span<char>*/ let dst = this._chars.Slice$1(this._pos, count);
                for(/*int*/ let i = 0; i < dst.Length; i++)
                {
                    dst.get_Item(i).$v = c;
                }
                this._pos += count;
            }
            /*void */ Append$3(/*scoped ReadOnlySpan<char>*/ value)
            {
                /*int*/ let pos = this._pos;
                if (pos > ((this._chars.Length - value.Length) | 0))
                {
                    this.Grow(value.Length);
                }
                value.CopyTo(this._chars.Slice(this._pos));
                this._pos += value.Length;
            }
            /*Span<char> */ AppendSpan(/*int*/ length)
            {
                /*int*/ let origPos = this._pos;
                if (origPos > ((this._chars.Length - length) | 0))
                {
                    this.Grow(length);
                }
                this._pos = ((origPos + length) | 0);
                return this._chars.Slice$1(origPos, length);
            }
            /*void */ GrowAndAppend(/*char*/ c)
            {
                this.Grow(1);
                this.Append(c);
            }
            /*void */ Grow(/*int*/ additionalCapacityBeyondPos)
            {
                $.$spc.System.Diagnostics.Debug.Assert$1(additionalCapacityBeyondPos > 0, "additionalCapacityBeyondPos > 0");
                $.$spc.System.Diagnostics.Debug.Assert$1(this._pos > ((this._chars.Length - additionalCapacityBeyondPos) | 0), "Grow called incorrectly, no resize is needed.");
                /*uint*/ let ArrayMaxLength = 2147483591;
                /*int*/ let newCapacity = ($.$spc.System.Math.Max$10(((((this._pos + additionalCapacityBeyondPos) | 0)) >>> 0), $.$spc.System.Math.Min$10((((this._chars.Length >>> 0) * 2) >>> 0), ArrayMaxLength)) | 0);
                /*char[]*/ let poolArray = $.$spc.System.Buffers.ArrayPool$$($.$spc.System.Char).Shared.Rent(newCapacity);
                this._chars.Slice$1(0, this._pos).CopyTo($.$spc.System.Span$$($.$spc.System.Char).op_Implicit(poolArray));
                /*char[]?*/ let toReturn = this._arrayToReturnToPool;
                this._chars = $.$spc.System.Span$$($.$spc.System.Char).op_Implicit(this._arrayToReturnToPool = poolArray);
                if (toReturn !== null)
                {
                    $.$spc.System.Buffers.ArrayPool$$($.$spc.System.Char).Shared.Return(toReturn, false);
                }
            }
            /*void */ Dispose()
            {
                /*char[]?*/ let toReturn = this._arrayToReturnToPool;
                new $.$srn.System.Text.ValueStringBuilder().Clone(this);
                if (toReturn !== null)
                {
                    $.$spc.System.Buffers.ArrayPool$$($.$spc.System.Char).Shared.Return(toReturn, false);
                }
            }
            //default value type constructor
            $ctor$4()
            {
                return this;
            }
            Clone($copy)
            {
                let copy = $copy ?? new this.constructor();
                copy._arrayToReturnToPool = this._arrayToReturnToPool;
                copy._chars = this._chars.Clone();
                copy._pos = this._pos;
                return copy;
            }
            //default member initializer
            constructor()
            {
                super();
                this._arrayToReturnToPool = null;
                this._chars = $.$default($.$spc.System.Span$$($.$spc.System.Char));
                this._pos = 0;
            }
            static $h = 1288977;
            static $z = 14;
            static $f = 0b1010000000;
            static $k = 2;
            static $$md;
            static get $md() { return this.$$md ??= {"b":196609,"p":[{"p":655361,"g":{"r":0,"d":0,"h":30066060049,"f":1},"s":{"r":0,"d":0,"h":34361027345,"f":1},"n":"Length","d":1288977,"h":25771092753,"f":1},{"p":655361,"g":{"r":0,"d":0,"h":42950961937,"f":1},"n":"Capacity","d":1288977,"h":38655994641,"f":1},{"p":458753,"i":[{"n":"index","p":655361}],"g":{"r":0,"d":0,"h":64425798417,"f":1},"n":"Item","o":"@$2","d":1288977,"h":60130831121,"f":1},{"p":$.$spc.System.Span$$($.$spc.System.Char).$h,"g":{"r":0,"d":0,"h":77310700305,"f":1},"n":"RawChars","d":1288977,"h":73015733009,"f":1}],"m":[{"r":65537,"p":[{"n":"capacity","p":655361}],"n":"EnsureCapacity","d":1288977,"h":47245929233,"f":1},{"r":458753,"n":"GetPinnableReference","d":1288977,"h":51540896529,"f":1},{"r":458753,"p":[{"n":"terminate","p":262145}],"n":"GetPinnableReference","o":"@$1","d":1288977,"h":55835863825,"f":1},{"r":1310721,"n":"ToString","d":1288977,"h":68720765713,"f":32769},{"r":$.$spc.System.ReadOnlySpan$$($.$spc.System.Char).$h,"p":[{"n":"terminate","p":262145}],"n":"AsSpan","d":1288977,"h":81605667601,"f":1},{"r":$.$spc.System.ReadOnlySpan$$($.$spc.System.Char).$h,"n":"AsSpan","o":"@$1","d":1288977,"h":85900634897,"f":1},{"r":$.$spc.System.ReadOnlySpan$$($.$spc.System.Char).$h,"p":[{"n":"start","p":655361}],"n":"AsSpan","o":"@$2","d":1288977,"h":90195602193,"f":1},{"r":$.$spc.System.ReadOnlySpan$$($.$spc.System.Char).$h,"p":[{"n":"start","p":655361},{"n":"length","p":655361}],"n":"AsSpan","o":"@$3","d":1288977,"h":94490569489,"f":1},{"r":262145,"p":[{"n":"destination","p":$.$spc.System.Span$$($.$spc.System.Char).$h},{"n":"charsWritten","p":655361,"f":2}],"n":"TryCopyTo","d":1288977,"h":98785536785,"f":1},{"r":65537,"p":[{"n":"index","p":655361},{"n":"value","p":458753},{"n":"count","p":655361}],"n":"Insert","d":1288977,"h":103080504081,"f":1},{"r":65537,"p":[{"n":"index","p":655361},{"n":"s","p":1310721}],"n":"Insert","o":"@$1","d":1288977,"h":107375471377,"f":1},{"r":65537,"p":[{"n":"c","p":458753}],"n":"Append","d":1288977,"h":111670438673,"f":1},{"r":65537,"p":[{"n":"s","p":1310721}],"n":"Append","o":"@$1","d":1288977,"h":115965405969,"f":1},{"r":65537,"p":[{"n":"s","p":1310721}],"n":"AppendSlow","d":1288977,"h":120260373265,"f":2},{"r":65537,"p":[{"n":"c","p":458753},{"n":"count","p":655361}],"n":"Append","o":"@$2","d":1288977,"h":124555340561,"f":1},{"r":65537,"p":[{"n":"value","p":$.$spc.System.ReadOnlySpan$$($.$spc.System.Char).$h}],"n":"Append","o":"@$3","d":1288977,"h":128850307857,"f":1},{"r":$.$spc.System.Span$$($.$spc.System.Char).$h,"p":[{"n":"length","p":655361}],"n":"AppendSpan","d":1288977,"h":133145275153,"f":1},{"r":65537,"p":[{"n":"c","p":458753}],"n":"GrowAndAppend","d":1288977,"h":137440242449,"f":2},{"r":65537,"p":[{"n":"additionalCapacityBeyondPos","p":655361}],"n":"Grow","d":1288977,"h":141735209745,"f":2},{"r":65537,"n":"Dispose","d":1288977,"h":146030177041,"f":1}],"l":[{"t":0,"n":"_arrayToReturnToPool","d":1288977,"h":4296256273,"f":2},{"t":$.$spc.System.Span$$($.$spc.System.Char).$h,"n":"_chars","d":1288977,"h":8591223569,"f":2},{"t":655361,"n":"_pos","d":1288977,"h":12886190865,"f":2}],"c":[{"p":[{"n":"initialBuffer","p":$.$spc.System.Span$$($.$spc.System.Char).$h}],"n":".ctor","o":"$ctor$2","d":1288977,"h":17181158161,"f":1},{"p":[{"n":"initialCapacity","p":655361}],"n":".ctor","o":"$ctor$3","d":1288977,"h":21476125457,"f":1},{"n":".ctor","o":"$ctor$4","d":1288977,"h":150325144337,"f":1}],"h":1288977}; }
            static get $b() { return $.$spc.System.ValueType; }
            static get $fullName() { return `System.Text.ValueStringBuilder`; }
        });
        
        $asm.$str("$srn.System.BigIntegerHexParser<>", (TChar) => $asm.$gt("$srn.System.BigIntegerHexParser<>", [TChar], ($self) => class BigIntegerHexParser$$ extends $.$spc.System.ValueType
        {
            static /*int */ get BitsPerDigit()
            {
                return 4;
            }
            static /*NumberStyles */ get BlockNumberStyle()
            {
                return 512/*NumberStyles.AllowHexSpecifier*/;
            }
            static /*uint */ GetSignBitsIfValid(/*uint*/ ch)
            {
                return (((ch & 248) === 48 ? 0 : -1) >>> 0);
            }
            static /*bool */ TryParseWholeBlocks(/*ReadOnlySpan<TChar>*/ input, /*Span<uint>*/ destination)
            {
                if ($.$spc.System.Type.op_Equality$1(TChar.$type, $.$spc.System.Char.$type))
                {
                    if ($.$spc.System.Convert.FromHexString$4($.$spc.System.Runtime.InteropServices.MemoryMarshal.Cast$1(TChar, $.$spc.System.Char, input), $.$spc.System.Runtime.InteropServices.MemoryMarshal.AsBytes($.$spc.System.UInt32, destination), $.$discardRef(), $.$discardRef()) !== 0/*OperationStatus.Done*/)
                    {
                        return false;
                    }
                    if ($.$spc.System.BitConverter.IsLittleEndian)
                    {
                        $.$spc.System.MemoryExtensions.Reverse($.$spc.System.Byte, $.$spc.System.Runtime.InteropServices.MemoryMarshal.AsBytes($.$spc.System.UInt32, destination));
                    }
                    else 
                    {
                        $.$spc.System.MemoryExtensions.Reverse($.$spc.System.UInt32, destination);
                    }
                    return true;
                }
                throw new $.$spc.System.NotSupportedException().$ctor$9();
            }
            //Generated interface implemetation for System.IBigIntegerHexOrBinaryParser<System.BigIntegerHexParser<TChar>, TChar>.BitsPerDigit.get
            static get System$IBigIntegerHexOrBinaryParser$$$$BitsPerDigit()
            {
                return $.$srn.System.BigIntegerHexParser$$(TChar).BitsPerDigit;
            }
            //Generated interface implemetation for System.IBigIntegerHexOrBinaryParser<System.BigIntegerHexParser<TChar>, TChar>.BlockNumberStyle.get
            static get System$IBigIntegerHexOrBinaryParser$$$$BlockNumberStyle()
            {
                return $.$srn.System.BigIntegerHexParser$$(TChar).BlockNumberStyle;
            }
            //Generated interface implemetation for System.IBigIntegerHexOrBinaryParser<System.BigIntegerHexParser<TChar>, TChar>.GetSignBitsIfValid(uint)
            static System$IBigIntegerHexOrBinaryParser$$$$GetSignBitsIfValid()
            {
                return $.$srn.System.BigIntegerHexParser$$(TChar).GetSignBitsIfValid(...arguments);
            }
            //Generated interface implemetation for System.IBigIntegerHexOrBinaryParser<System.BigIntegerHexParser<TChar>, TChar>.TryParseWholeBlocks(System.ReadOnlySpan<TChar>, System.Span<uint>)
            static System$IBigIntegerHexOrBinaryParser$$$$TryParseWholeBlocks()
            {
                return $.$srn.System.BigIntegerHexParser$$(TChar).TryParseWholeBlocks(...arguments);
            }
            //default value type constructor
            $ctor$2()
            {
                return this;
            }
            Clone($copy)
            {
                let copy = $copy ?? new this.constructor();
                return copy;
            }
            static $h = 174865;
            static $g = 1;
            static $z = 0;
            static $f = 0b1011000000;
            static $k = 2;
            static $$md;
            static get $md() { return this.$$md ??= {"b":196609,"p":[{"p":655361,"g":{"r":0,"d":0,"h":Number(BigInt(this.$h)|0x200000000n),"f":33},"n":"BitsPerDigit","d":this.$h,"h":Number(BigInt(this.$h)|0x100000000n),"f":33},{"p":54067201,"g":{"r":0,"d":0,"h":Number(BigInt(this.$h)|0x400000000n),"f":33},"n":"BlockNumberStyle","d":this.$h,"h":Number(BigInt(this.$h)|0x300000000n),"f":33}],"m":[{"r":720897,"p":[{"n":"ch","p":720897}],"n":"GetSignBitsIfValid","d":this.$h,"h":Number(BigInt(this.$h)|0x500000000n),"f":33},{"r":262145,"p":[{"n":"input","p":$.$spc.System.ReadOnlySpan$$(TChar).$h},{"n":"destination","p":$.$spc.System.Span$$($.$spc.System.UInt32).$h}],"n":"TryParseWholeBlocks","d":this.$h,"h":Number(BigInt(this.$h)|0x600000000n),"f":33}],"c":[{"n":".ctor","o":"$ctor$2","d":this.$h,"h":Number(BigInt(this.$h)|0x700000000n),"f":1}],"i":[$.$srn.System.IBigIntegerHexOrBinaryParser$$$($.$srn.System.BigIntegerHexParser$$(TChar), TChar).$h],"g":[TChar?.$h??1507328],"s":[{"n":"TChar","f":10,"c":[$.$spc.System.Numerics.IBinaryInteger$$(TChar).$h]}],"r":1,"h":this.$h}; }
            static get $b() { return $.$spc.System.ValueType; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$srn.System.IBigIntegerHexOrBinaryParser$$$($.$srn.System.BigIntegerHexParser$$(TChar), TChar) ]; }
            static get $fullName() { return `System.BigIntegerHexParser<${TChar?.$fullName}>`; }
        }));
        
        $asm.$str("$srn.System.BigIntegerBinaryParser<>", (TChar) => $asm.$gt("$srn.System.BigIntegerBinaryParser<>", [TChar], ($self) => class BigIntegerBinaryParser$$ extends $.$spc.System.ValueType
        {
            static /*int */ get BitsPerDigit()
            {
                return 1;
            }
            static /*NumberStyles */ get BlockNumberStyle()
            {
                return 1024/*NumberStyles.AllowBinarySpecifier*/;
            }
            static /*uint */ GetSignBitsIfValid(/*uint*/ ch)
            {
                return ((((ch | 0) << 31) >> 31) >>> 0);
            }
            //Generated interface implemetation for System.IBigIntegerHexOrBinaryParser<System.BigIntegerBinaryParser<TChar>, TChar>.BitsPerDigit.get
            static get System$IBigIntegerHexOrBinaryParser$$$$BitsPerDigit()
            {
                return $.$srn.System.BigIntegerBinaryParser$$(TChar).BitsPerDigit;
            }
            //Generated interface implemetation for System.IBigIntegerHexOrBinaryParser<System.BigIntegerBinaryParser<TChar>, TChar>.BlockNumberStyle.get
            static get System$IBigIntegerHexOrBinaryParser$$$$BlockNumberStyle()
            {
                return $.$srn.System.BigIntegerBinaryParser$$(TChar).BlockNumberStyle;
            }
            //Generated interface implemetation for System.IBigIntegerHexOrBinaryParser<System.BigIntegerBinaryParser<TChar>, TChar>.GetSignBitsIfValid(uint)
            static System$IBigIntegerHexOrBinaryParser$$$$GetSignBitsIfValid()
            {
                return $.$srn.System.BigIntegerBinaryParser$$(TChar).GetSignBitsIfValid(...arguments);
            }
            //default value type constructor
            $ctor$2()
            {
                return this;
            }
            Clone($copy)
            {
                let copy = $copy ?? new this.constructor();
                return copy;
            }
            static $h = 109329;
            static $g = 1;
            static $z = 0;
            static $f = 0b1011000000;
            static $k = 2;
            static $$md;
            static get $md() { return this.$$md ??= {"b":196609,"p":[{"p":655361,"g":{"r":0,"d":0,"h":Number(BigInt(this.$h)|0x200000000n),"f":33},"n":"BitsPerDigit","d":this.$h,"h":Number(BigInt(this.$h)|0x100000000n),"f":33},{"p":54067201,"g":{"r":0,"d":0,"h":Number(BigInt(this.$h)|0x400000000n),"f":33},"n":"BlockNumberStyle","d":this.$h,"h":Number(BigInt(this.$h)|0x300000000n),"f":33}],"m":[{"r":720897,"p":[{"n":"ch","p":720897}],"n":"GetSignBitsIfValid","d":this.$h,"h":Number(BigInt(this.$h)|0x500000000n),"f":33}],"c":[{"n":".ctor","o":"$ctor$2","d":this.$h,"h":Number(BigInt(this.$h)|0x600000000n),"f":1}],"i":[$.$srn.System.IBigIntegerHexOrBinaryParser$$$($.$srn.System.BigIntegerBinaryParser$$(TChar), TChar).$h],"g":[TChar?.$h??1507328],"s":[{"n":"TChar","f":10,"c":[$.$spc.System.Numerics.IBinaryInteger$$(TChar).$h]}],"r":1,"h":this.$h}; }
            static get $b() { return $.$spc.System.ValueType; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$srn.System.IBigIntegerHexOrBinaryParser$$$($.$srn.System.BigIntegerBinaryParser$$(TChar), TChar) ]; }
            static get $fullName() { return `System.BigIntegerBinaryParser<${TChar?.$fullName}>`; }
        }));
        
        $asm.$str("$srn.System.Utf16Char", ($self) => class Utf16Char extends $.$spc.System.ValueType
        {
            /*char*/ value$ = 0;
            static/*conventional*/ /*char */ value$get()
            {
                if (typeof this === "number")
                {
                    return this;
                }
                return this.value$;
            }
            static/*conventional*/ /*char */ value$set(value)
            {
                this.value$ = value;
            }
            //Static convention instance get redirect
            /*char */ get value() { return $.$srn.System.Utf16Char.value$get.apply(this); }
            //Static convention instance set redirect
            /*char */ set value(value) { return $.$srn.System.Utf16Char.value$set.apply(this, [value]); }
            static /*Utf16Char */ CastFrom(/*byte*/ value)
            {
                return new $.$srn.System.Utf16Char().$ctor$2(value);
            }
            static /*Utf16Char */ CastFrom$1(/*char*/ value)
            {
                return new $.$srn.System.Utf16Char().$ctor$2(value);
            }
            static /*Utf16Char */ CastFrom$2(/*int*/ value)
            {
                return new $.$srn.System.Utf16Char().$ctor$2($.$cast(value, $.$spc.System.Char));
            }
            static /*Utf16Char */ CastFrom$3(/*uint*/ value)
            {
                return new $.$srn.System.Utf16Char().$ctor$2($.$cast(value, $.$spc.System.Char));
            }
            static /*Utf16Char */ CastFrom$4(/*ulong*/ value)
            {
                return new $.$srn.System.Utf16Char().$ctor$2($.$cast(value, $.$spc.System.Char));
            }
            static /*uint */ CastToUInt32(/*Utf16Char*/ value)
            {
                return $.$srn.System.Utf16Char.value$get.call(value);
            }
            static/*conventional*/ /*bool */ Equals$2(/*Utf16Char*/ other)
            {
                return $.$srn.System.Utf16Char.value$get.call(this) === $.$srn.System.Utf16Char.value$get.call(other);
            }
            //Static convention instance redirect
            /*bool */ Equals$2() { return $.$srn.System.Utf16Char.Equals$2.apply(this, arguments); }
            //Generated interface implemetation for System.IUtfChar<System.Utf16Char>.CastFrom(byte)
            static System$IUtfChar$$$CastFrom()
            {
                return $.$srn.System.Utf16Char.CastFrom(...arguments);
            }
            //Generated interface implemetation for System.IUtfChar<System.Utf16Char>.CastFrom(char)
            static System$IUtfChar$$$CastFrom$1()
            {
                return $.$srn.System.Utf16Char.CastFrom$1(...arguments);
            }
            //Generated interface implemetation for System.IUtfChar<System.Utf16Char>.CastFrom(int)
            static System$IUtfChar$$$CastFrom$2()
            {
                return $.$srn.System.Utf16Char.CastFrom$2(...arguments);
            }
            //Generated interface implemetation for System.IUtfChar<System.Utf16Char>.CastFrom(uint)
            static System$IUtfChar$$$CastFrom$3()
            {
                return $.$srn.System.Utf16Char.CastFrom$3(...arguments);
            }
            //Generated interface implemetation for System.IUtfChar<System.Utf16Char>.CastFrom(ulong)
            static System$IUtfChar$$$CastFrom$4()
            {
                return $.$srn.System.Utf16Char.CastFrom$4(...arguments);
            }
            //Generated interface implemetation for System.IUtfChar<System.Utf16Char>.CastToUInt32(System.Utf16Char)
            static System$IUtfChar$$$CastToUInt32()
            {
                return $.$srn.System.Utf16Char.CastToUInt32(...arguments);
            }
            //Generated interface implemetation for System.IEquatable<System.Utf16Char>.Equals(System.Utf16Char)
            static /*conventional*/ System$IEquatable$$$Equals()
            {
                return $.$srn.System.Utf16Char.Equals$2.apply(this, arguments);
            }
            //Static convention instance redirect
            System$IEquatable$$$Equals()
            {
                return $.$srn.System.Utf16Char.Equals$2.apply(this, arguments);
            }
            //default value type constructor
            $ctor$3()
            {
                return this;
            }
            //default member initializer
            constructor()
            {
                super();
                this.value = ch$get.call(this);
            }
            static $h = 1420049;
            static $z = 2;
            static $f = 0b11010000000;
            static $k = 2;
            static $$md;
            static get $md() { return this.$$md ??= {"b":196609,"p":[{"p":458753,"g":{"r":0,"d":0,"h":17181289233,"f":2},"s":{"r":0,"d":0,"h":21476256529,"f":2},"n":"value","d":1420049,"h":12886321937,"f":2}],"m":[{"r":1420049,"p":[{"n":"value","p":393217}],"n":"CastFrom","d":1420049,"h":25771223825,"f":33},{"r":1420049,"p":[{"n":"value","p":458753}],"n":"CastFrom","o":"@$1","d":1420049,"h":30066191121,"f":33},{"r":1420049,"p":[{"n":"value","p":655361}],"n":"CastFrom","o":"@$2","d":1420049,"h":34361158417,"f":33},{"r":1420049,"p":[{"n":"value","p":720897}],"n":"CastFrom","o":"@$3","d":1420049,"h":38656125713,"f":33},{"r":1420049,"p":[{"n":"value","p":983041}],"n":"CastFrom","o":"@$4","d":1420049,"h":42951093009,"f":33},{"r":720897,"p":[{"n":"value","p":1420049}],"n":"CastToUInt32","d":1420049,"h":47246060305,"f":33},{"r":262145,"p":[{"n":"other","p":1420049}],"n":"Equals","o":"@$2","d":1420049,"h":51541027601,"f":1}],"c":[{"p":[{"n":"ch","p":458753}],"n":".ctor","o":"$ctor$2","d":1420049,"h":4296387345,"f":1},{"n":".ctor","o":"$ctor$3","d":1420049,"h":55835994897,"f":1}],"i":[$.$srn.System.IUtfChar$$($.$srn.System.Utf16Char).$h,$.$spc.System.IEquatable$$($.$srn.System.Utf16Char).$h],"h":1420049}; }
            static get $b() { return $.$spc.System.ValueType; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$srn.System.IUtfChar$$($.$srn.System.Utf16Char), $.$spc.System.IEquatable$$($.$srn.System.Utf16Char) ]; }
            static get $fullName() { return `System.Utf16Char`; }
        });
        
        $asm.$str("$srn.System.Utf8Char", ($self) => class Utf8Char extends $.$spc.System.ValueType
        {
            /*byte*/ value$ = 0;
            static/*conventional*/ /*byte */ value$get()
            {
                if (typeof this === "number")
                {
                    return this;
                }
                return this.value$;
            }
            static/*conventional*/ /*byte */ value$set(value)
            {
                this.value$ = value;
            }
            //Static convention instance get redirect
            /*byte */ get value() { return $.$srn.System.Utf8Char.value$get.apply(this); }
            //Static convention instance set redirect
            /*byte */ set value(value) { return $.$srn.System.Utf8Char.value$set.apply(this, [value]); }
            static /*Utf8Char */ CastFrom(/*byte*/ value)
            {
                return new $.$srn.System.Utf8Char().$ctor$2(value);
            }
            static /*Utf8Char */ CastFrom$1(/*char*/ value)
            {
                return new $.$srn.System.Utf8Char().$ctor$2($.$cast(value, $.$spc.System.Byte));
            }
            static /*Utf8Char */ CastFrom$2(/*int*/ value)
            {
                return new $.$srn.System.Utf8Char().$ctor$2($.$cast(value, $.$spc.System.Byte));
            }
            static /*Utf8Char */ CastFrom$3(/*uint*/ value)
            {
                return new $.$srn.System.Utf8Char().$ctor$2($.$cast(value, $.$spc.System.Byte));
            }
            static /*Utf8Char */ CastFrom$4(/*ulong*/ value)
            {
                return new $.$srn.System.Utf8Char().$ctor$2($.$cast(value, $.$spc.System.Byte));
            }
            static /*uint */ CastToUInt32(/*Utf8Char*/ value)
            {
                return $.$srn.System.Utf8Char.value$get.call(value);
            }
            static/*conventional*/ /*bool */ Equals$2(/*Utf8Char*/ other)
            {
                return $.$srn.System.Utf8Char.value$get.call(this) === $.$srn.System.Utf8Char.value$get.call(other);
            }
            //Static convention instance redirect
            /*bool */ Equals$2() { return $.$srn.System.Utf8Char.Equals$2.apply(this, arguments); }
            //Generated interface implemetation for System.IUtfChar<System.Utf8Char>.CastFrom(byte)
            static System$IUtfChar$$$CastFrom()
            {
                return $.$srn.System.Utf8Char.CastFrom(...arguments);
            }
            //Generated interface implemetation for System.IUtfChar<System.Utf8Char>.CastFrom(char)
            static System$IUtfChar$$$CastFrom$1()
            {
                return $.$srn.System.Utf8Char.CastFrom$1(...arguments);
            }
            //Generated interface implemetation for System.IUtfChar<System.Utf8Char>.CastFrom(int)
            static System$IUtfChar$$$CastFrom$2()
            {
                return $.$srn.System.Utf8Char.CastFrom$2(...arguments);
            }
            //Generated interface implemetation for System.IUtfChar<System.Utf8Char>.CastFrom(uint)
            static System$IUtfChar$$$CastFrom$3()
            {
                return $.$srn.System.Utf8Char.CastFrom$3(...arguments);
            }
            //Generated interface implemetation for System.IUtfChar<System.Utf8Char>.CastFrom(ulong)
            static System$IUtfChar$$$CastFrom$4()
            {
                return $.$srn.System.Utf8Char.CastFrom$4(...arguments);
            }
            //Generated interface implemetation for System.IUtfChar<System.Utf8Char>.CastToUInt32(System.Utf8Char)
            static System$IUtfChar$$$CastToUInt32()
            {
                return $.$srn.System.Utf8Char.CastToUInt32(...arguments);
            }
            //Generated interface implemetation for System.IEquatable<System.Utf8Char>.Equals(System.Utf8Char)
            static /*conventional*/ System$IEquatable$$$Equals()
            {
                return $.$srn.System.Utf8Char.Equals$2.apply(this, arguments);
            }
            //Static convention instance redirect
            System$IEquatable$$$Equals()
            {
                return $.$srn.System.Utf8Char.Equals$2.apply(this, arguments);
            }
            //default value type constructor
            $ctor$3()
            {
                return this;
            }
            //default member initializer
            constructor()
            {
                super();
                this.value = ch$get.call(this);
            }
            static $h = 1485585;
            static $z = 1;
            static $f = 0b11010000000;
            static $k = 2;
            static $$md;
            static get $md() { return this.$$md ??= {"b":196609,"p":[{"p":393217,"g":{"r":0,"d":0,"h":17181354769,"f":2},"s":{"r":0,"d":0,"h":21476322065,"f":2},"n":"value","d":1485585,"h":12886387473,"f":2}],"m":[{"r":1485585,"p":[{"n":"value","p":393217}],"n":"CastFrom","d":1485585,"h":25771289361,"f":33},{"r":1485585,"p":[{"n":"value","p":458753}],"n":"CastFrom","o":"@$1","d":1485585,"h":30066256657,"f":33},{"r":1485585,"p":[{"n":"value","p":655361}],"n":"CastFrom","o":"@$2","d":1485585,"h":34361223953,"f":33},{"r":1485585,"p":[{"n":"value","p":720897}],"n":"CastFrom","o":"@$3","d":1485585,"h":38656191249,"f":33},{"r":1485585,"p":[{"n":"value","p":983041}],"n":"CastFrom","o":"@$4","d":1485585,"h":42951158545,"f":33},{"r":720897,"p":[{"n":"value","p":1485585}],"n":"CastToUInt32","d":1485585,"h":47246125841,"f":33},{"r":262145,"p":[{"n":"other","p":1485585}],"n":"Equals","o":"@$2","d":1485585,"h":51541093137,"f":1}],"c":[{"p":[{"n":"ch","p":393217}],"n":".ctor","o":"$ctor$2","d":1485585,"h":4296452881,"f":1},{"n":".ctor","o":"$ctor$3","d":1485585,"h":55836060433,"f":1}],"i":[$.$srn.System.IUtfChar$$($.$srn.System.Utf8Char).$h,$.$spc.System.IEquatable$$($.$srn.System.Utf8Char).$h],"h":1485585}; }
            static get $b() { return $.$spc.System.ValueType; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$srn.System.IUtfChar$$($.$srn.System.Utf8Char), $.$spc.System.IEquatable$$($.$srn.System.Utf8Char) ]; }
            static get $fullName() { return `System.Utf8Char`; }
        });
        
        $asm.$str("$srn.System.Numerics.Complex", ($self) => class Complex extends $.$spc.System.ValueType
        {
            /*NumberStyles*/ static DefaultNumberStyle = 231;
            /*NumberStyles*/ static InvalidNumberStyles = -1024;
            /*Complex*/ static Zero;
            /*Complex*/ static One;
            /*Complex*/ static ImaginaryOne;
            /*Complex*/ static NaN;
            /*Complex*/ static Infinity;
            /*double*/ static InverseOfLog10 = 0.43429448190325;
            /*double*/ static s_sqrtRescaleThreshold = 0;
            /*double*/ static s_asinOverflowThreshold = 0;
            /*double*/ static s_log2 = 0;
            /*double*/  get m_real() { return this.$getField(0, $.$spc.System.Double); }
            /*double*/  set m_real(value) { this.$setField(0, $.$spc.System.Double, value); }
            /*double*/  get m_imaginary() { return this.$getField(8, $.$spc.System.Double); }
            /*double*/  set m_imaginary(value) { this.$setField(8, $.$spc.System.Double, value); }
            $ctor$2(/*double*/ real, /*double*/ imaginary)
            {
                super.$ctor$1();
                {
                    this.m_real = real;
                    this.m_imaginary = imaginary;
                }
                return this;
            }
            /*double */ get Real()
            {
                return this.m_real;
            }
            /*double */ get Imaginary()
            {
                return this.m_imaginary;
            }
            /*double */ get Magnitude()
            {
                return $.$srn.System.Numerics.Complex.Abs(this);
            }
            /*double */ get Phase()
            {
                return Math.atan2(this.m_imaginary, this.m_real);
            }
            static /*Complex */ FromPolarCoordinates(/*double*/ magnitude, /*double*/ phase)
            {
                const { Item1: sin, Item2: cos } = $.$spc.System.Math.SinCos(phase);
                return new $.$srn.System.Numerics.Complex().$ctor$2(magnitude * cos, magnitude * sin);
            }
            static /*Complex */ Negate(/*Complex*/ value)
            {
                return $.$srn.System.Numerics.Complex.op_UnaryNegation(value);
            }
            static /*Complex */ Add(/*Complex*/ left, /*Complex*/ right)
            {
                return $.$srn.System.Numerics.Complex.op_Addition(left, right);
            }
            static /*Complex */ Add$1(/*Complex*/ left, /*double*/ right)
            {
                return $.$srn.System.Numerics.Complex.op_Addition$1(left, right);
            }
            static /*Complex */ Add$2(/*double*/ left, /*Complex*/ right)
            {
                return left + right;
            }
            static /*Complex */ Subtract(/*Complex*/ left, /*Complex*/ right)
            {
                return $.$srn.System.Numerics.Complex.op_Subtraction(left, right);
            }
            static /*Complex */ Subtract$1(/*Complex*/ left, /*double*/ right)
            {
                return $.$srn.System.Numerics.Complex.op_Subtraction$1(left, right);
            }
            static /*Complex */ Subtract$2(/*double*/ left, /*Complex*/ right)
            {
                return left - right;
            }
            static /*Complex */ Multiply(/*Complex*/ left, /*Complex*/ right)
            {
                return $.$srn.System.Numerics.Complex.op_Multiply(left, right);
            }
            static /*Complex */ Multiply$1(/*Complex*/ left, /*double*/ right)
            {
                return $.$srn.System.Numerics.Complex.op_Multiply$1(left, right);
            }
            static /*Complex */ Multiply$2(/*double*/ left, /*Complex*/ right)
            {
                return left * right;
            }
            static /*Complex */ Divide(/*Complex*/ dividend, /*Complex*/ divisor)
            {
                return $.$srn.System.Numerics.Complex.op_Division(dividend, divisor);
            }
            static /*Complex */ Divide$1(/*Complex*/ dividend, /*double*/ divisor)
            {
                return $.$srn.System.Numerics.Complex.op_Division$1(dividend, divisor);
            }
            static /*Complex */ Divide$2(/*double*/ dividend, /*Complex*/ divisor)
            {
                return dividend / divisor;
            }
            static /*Complex */ op_UnaryNegation(/*Complex*/ value)
            {
                return new $.$srn.System.Numerics.Complex().$ctor$2(-value.m_real, -value.m_imaginary);
            }
            static /*Complex */ op_Addition(/*Complex*/ left, /*Complex*/ right)
            {
                return new $.$srn.System.Numerics.Complex().$ctor$2(left.m_real + right.m_real, left.m_imaginary + right.m_imaginary);
            }
            static /*Complex */ op_Addition$1(/*Complex*/ left, /*double*/ right)
            {
                return new $.$srn.System.Numerics.Complex().$ctor$2(left.m_real + right, left.m_imaginary);
            }
            static /*Complex */ op_Addition$2(/*double*/ left, /*Complex*/ right)
            {
                return new $.$srn.System.Numerics.Complex().$ctor$2(left + right.m_real, right.m_imaginary);
            }
            static /*Complex */ op_Subtraction(/*Complex*/ left, /*Complex*/ right)
            {
                return new $.$srn.System.Numerics.Complex().$ctor$2(left.m_real - right.m_real, left.m_imaginary - right.m_imaginary);
            }
            static /*Complex */ op_Subtraction$1(/*Complex*/ left, /*double*/ right)
            {
                return new $.$srn.System.Numerics.Complex().$ctor$2(left.m_real - right, left.m_imaginary);
            }
            static /*Complex */ op_Subtraction$2(/*double*/ left, /*Complex*/ right)
            {
                return new $.$srn.System.Numerics.Complex().$ctor$2(left - right.m_real, -right.m_imaginary);
            }
            static /*Complex */ op_Multiply(/*Complex*/ left, /*Complex*/ right)
            {
                /*double*/ let result_realpart = (left.m_real * right.m_real) - (left.m_imaginary * right.m_imaginary);
                /*double*/ let result_imaginarypart = (left.m_imaginary * right.m_real) + (left.m_real * right.m_imaginary);
                return new $.$srn.System.Numerics.Complex().$ctor$2(result_realpart, result_imaginarypart);
            }
            static /*Complex */ op_Multiply$1(/*Complex*/ left, /*double*/ right)
            {
                if (!$.$spc.System.Double.IsFinite(left.m_real))
                {
                    if (!$.$spc.System.Double.IsFinite(left.m_imaginary))
                    {
                        return new $.$srn.System.Numerics.Complex().$ctor$2(Number.NaN/*double.NaN*/, Number.NaN/*double.NaN*/);
                    }
                    return new $.$srn.System.Numerics.Complex().$ctor$2(left.m_real * right, Number.NaN/*double.NaN*/);
                }
                if (!$.$spc.System.Double.IsFinite(left.m_imaginary))
                {
                    return new $.$srn.System.Numerics.Complex().$ctor$2(Number.NaN/*double.NaN*/, left.m_imaginary * right);
                }
                return new $.$srn.System.Numerics.Complex().$ctor$2(left.m_real * right, left.m_imaginary * right);
            }
            static /*Complex */ op_Multiply$2(/*double*/ left, /*Complex*/ right)
            {
                if (!$.$spc.System.Double.IsFinite(right.m_real))
                {
                    if (!$.$spc.System.Double.IsFinite(right.m_imaginary))
                    {
                        return new $.$srn.System.Numerics.Complex().$ctor$2(Number.NaN/*double.NaN*/, Number.NaN/*double.NaN*/);
                    }
                    return new $.$srn.System.Numerics.Complex().$ctor$2(left * right.m_real, Number.NaN/*double.NaN*/);
                }
                if (!$.$spc.System.Double.IsFinite(right.m_imaginary))
                {
                    return new $.$srn.System.Numerics.Complex().$ctor$2(Number.NaN/*double.NaN*/, left * right.m_imaginary);
                }
                return new $.$srn.System.Numerics.Complex().$ctor$2(left * right.m_real, left * right.m_imaginary);
            }
            static /*Complex */ op_Division(/*Complex*/ left, /*Complex*/ right)
            {
                /*double*/ let a = left.m_real;
                /*double*/ let b = left.m_imaginary;
                /*double*/ let c = right.m_real;
                /*double*/ let d = right.m_imaginary;
                if ($.$spc.System.Math.Abs$6(d) < $.$spc.System.Math.Abs$6(c))
                {
                    /*double*/ let doc = d / c;
                    return new $.$srn.System.Numerics.Complex().$ctor$2((a + b * doc) / (c + d * doc), (b - a * doc) / (c + d * doc));
                }
                else 
                {
                    /*double*/ let cod = c / d;
                    return new $.$srn.System.Numerics.Complex().$ctor$2((b + a * cod) / (d + c * cod), (-a + b * cod) / (d + c * cod));
                }
            }
            static /*Complex */ op_Division$1(/*Complex*/ left, /*double*/ right)
            {
                if (right === 0)
                {
                    return new $.$srn.System.Numerics.Complex().$ctor$2(Number.NaN/*double.NaN*/, Number.NaN/*double.NaN*/);
                }
                if (!$.$spc.System.Double.IsFinite(left.m_real))
                {
                    if (!$.$spc.System.Double.IsFinite(left.m_imaginary))
                    {
                        return new $.$srn.System.Numerics.Complex().$ctor$2(Number.NaN/*double.NaN*/, Number.NaN/*double.NaN*/);
                    }
                    return new $.$srn.System.Numerics.Complex().$ctor$2(left.m_real / right, Number.NaN/*double.NaN*/);
                }
                if (!$.$spc.System.Double.IsFinite(left.m_imaginary))
                {
                    return new $.$srn.System.Numerics.Complex().$ctor$2(Number.NaN/*double.NaN*/, left.m_imaginary / right);
                }
                return new $.$srn.System.Numerics.Complex().$ctor$2(left.m_real / right, left.m_imaginary / right);
            }
            static /*Complex */ op_Division$2(/*double*/ left, /*Complex*/ right)
            {
                /*double*/ let a = left;
                /*double*/ let c = right.m_real;
                /*double*/ let d = right.m_imaginary;
                if ($.$spc.System.Math.Abs$6(d) < $.$spc.System.Math.Abs$6(c))
                {
                    /*double*/ let doc = d / c;
                    return new $.$srn.System.Numerics.Complex().$ctor$2(a / (c + d * doc), (-a * doc) / (c + d * doc));
                }
                else 
                {
                    /*double*/ let cod = c / d;
                    return new $.$srn.System.Numerics.Complex().$ctor$2(a * cod / (d + c * cod), -a / (d + c * cod));
                }
            }
            static /*double */ Abs(/*Complex*/ value)
            {
                return $.$spc.System.Double.Hypot(value.m_real, value.m_imaginary);
            }
            static /*double */ Log1P(/*double*/ x)
            {
                $.$spc.System.Diagnostics.Debug.Assert$1((x >= 0) || $.$spc.System.Double.IsNaN(x), "(x >= 0.0) || double.IsNaN(x)");
                /*double*/ let xp1 = 1 + x;
                if (xp1 === 1)
                {
                    return x;
                }
                else if (x < 0.75)
                {
                    return x * Math.log(xp1) / (xp1 - 1);
                }
                else 
                {
                    return Math.log(xp1);
                }
            }
            static /*Complex */ Conjugate(/*Complex*/ value)
            {
                return new $.$srn.System.Numerics.Complex().$ctor$2(value.m_real, -value.m_imaginary);
            }
            static /*Complex */ Reciprocal(/*Complex*/ value)
            {
                if (value.m_real === 0 && value.m_imaginary === 0)
                {
                    return $.$srn.System.Numerics.Complex.Zero;
                }
                return $.$srn.System.Numerics.Complex.op_Division($.$srn.System.Numerics.Complex.One, value);
            }
            static /*bool */ op_Equality(/*Complex*/ left, /*Complex*/ right)
            {
                return left.m_real === right.m_real && left.m_imaginary === right.m_imaginary;
            }
            static /*bool */ op_Inequality(/*Complex*/ left, /*Complex*/ right)
            {
                return left.m_real !== right.m_real || left.m_imaginary !== right.m_imaginary;
            }
            static/*conventional*/ /*bool */ Equals(/*object?*/ obj)
            {
                let other;
                return $.$is(obj, $.$srn.System.Numerics.Complex, { set $v(v){ other = v; } }) && this.Equals$2(other);
            }
            //Static convention instance redirect
            /*bool */ Equals() { return $.$srn.System.Numerics.Complex.Equals.apply(this, arguments); }
            /*bool */ Equals$2(/*Complex*/ value)
            {
                return $.$spc.System.Double.Equals$2.call(this.m_real, value.m_real) && $.$spc.System.Double.Equals$2.call(this.m_imaginary, value.m_imaginary);
            }
            static/*conventional*/ /*int */ GetHashCode()
            {
                return $.$spc.System.HashCode.Combine$1($.$spc.System.Double, $.$spc.System.Double, this.m_real, this.m_imaginary);
            }
            //Static convention instance redirect
            /*int */ GetHashCode() { return $.$srn.System.Numerics.Complex.GetHashCode.apply(this, arguments); }
            static/*conventional*/ /*string */ ToString()
            {
                return this.ToString$3(null, null);
            }
            //Static convention instance redirect
            /*string */ ToString() { return $.$srn.System.Numerics.Complex.ToString.apply(this, arguments); }
            /*string */ ToString$1(/*string?*/ format)
            {
                return this.ToString$3(format, null);
            }
            /*string */ ToString$2(/*IFormatProvider?*/ provider)
            {
                return this.ToString$3(null, provider);
            }
            /*string */ ToString$3(/*string?*/ format, /*IFormatProvider?*/ provider)
            {
                /*var*/ let handler = new $.$spc.System.Runtime.CompilerServices.DefaultInterpolatedStringHandler().$ctor$4(4, 2, provider, $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.StackAllocSpan($.$spc.System.Char, 512, null));
                handler.AppendLiteral("<");
                handler.AppendFormatted$1($.$spc.System.Double, this.m_real, format);
                handler.AppendLiteral("; ");
                handler.AppendFormatted$1($.$spc.System.Double, this.m_imaginary, format);
                handler.AppendLiteral(">");
                return handler.ToStringAndClear();
            }
            static /*Complex */ Sin(/*Complex*/ value)
            {
                const { Item1: sin, Item2: cos } = $.$spc.System.Math.SinCos(value.m_real);
                return new $.$srn.System.Numerics.Complex().$ctor$2(sin * Math.cosh(value.m_imaginary), cos * Math.sinh(value.m_imaginary));
            }
            static /*Complex */ Sinh(/*Complex*/ value)
            {
                /*Complex*/ let sin = $.$srn.System.Numerics.Complex.Sin(new $.$srn.System.Numerics.Complex().$ctor$2(-value.m_imaginary, value.m_real));
                return new $.$srn.System.Numerics.Complex().$ctor$2(sin.m_imaginary, -sin.m_real);
            }
            static /*Complex */ Asin(/*Complex*/ value)
            {
                /*double*/ let b, bPrime, v;
                $.$srn.System.Numerics.Complex.Asin_Internal($.$spc.System.Math.Abs$6(value.Real), $.$spc.System.Math.Abs$6(value.Imaginary), $.$ref(() => b, ($v) => b = $v, $.$spc.System.Double), $.$ref(() => bPrime, ($v) => bPrime = $v, $.$spc.System.Double), $.$ref(() => v, ($v) => v = $v, $.$spc.System.Double));
                /*double*/ let u;
                if (bPrime < 0)
                {
                    u = Math.asin(b);
                }
                else 
                {
                    u = Math.atan(bPrime);
                }
                if (value.Real < 0)
                {
                    u = -u;
                }
                if (value.Imaginary < 0)
                {
                    v = -v;
                }
                return new $.$srn.System.Numerics.Complex().$ctor$2(u, v);
            }
            static /*Complex */ Cos(/*Complex*/ value)
            {
                const { Item1: sin, Item2: cos } = $.$spc.System.Math.SinCos(value.m_real);
                return new $.$srn.System.Numerics.Complex().$ctor$2(cos * Math.cosh(value.m_imaginary), -sin * Math.sinh(value.m_imaginary));
            }
            static /*Complex */ Cosh(/*Complex*/ value)
            {
                return $.$srn.System.Numerics.Complex.Cos(new $.$srn.System.Numerics.Complex().$ctor$2(-value.m_imaginary, value.m_real));
            }
            static /*Complex */ Acos(/*Complex*/ value)
            {
                /*double*/ let b, bPrime, v;
                $.$srn.System.Numerics.Complex.Asin_Internal($.$spc.System.Math.Abs$6(value.Real), $.$spc.System.Math.Abs$6(value.Imaginary), $.$ref(() => b, ($v) => b = $v, $.$spc.System.Double), $.$ref(() => bPrime, ($v) => bPrime = $v, $.$spc.System.Double), $.$ref(() => v, ($v) => v = $v, $.$spc.System.Double));
                /*double*/ let u;
                if (bPrime < 0)
                {
                    u = Math.acos(b);
                }
                else 
                {
                    u = Math.atan(1 / bPrime);
                }
                if (value.Real < 0)
                {
                    u = 3.141592653589793/*Math.PI*/ - u;
                }
                if (value.Imaginary > 0)
                {
                    v = -v;
                }
                return new $.$srn.System.Numerics.Complex().$ctor$2(u, v);
            }
            static /*Complex */ Tan(/*Complex*/ value)
            {
                /*double*/ let x2 = 2 * value.m_real;
                /*double*/ let y2 = 2 * value.m_imaginary;
                const { Item1: sin, Item2: cos } = $.$spc.System.Math.SinCos(x2);
                /*double*/ let cosh = Math.cosh(y2);
                if ($.$spc.System.Math.Abs$6(value.m_imaginary) <= 4)
                {
                    /*double*/ let D = cos + cosh;
                    return new $.$srn.System.Numerics.Complex().$ctor$2(sin / D, Math.sinh(y2) / D);
                }
                else 
                {
                    /*double*/ let D = 1 + cos / cosh;
                    return new $.$srn.System.Numerics.Complex().$ctor$2(sin / cosh / D, Math.tanh(y2) / D);
                }
            }
            static /*Complex */ Tanh(/*Complex*/ value)
            {
                /*Complex*/ let tan = $.$srn.System.Numerics.Complex.Tan(new $.$srn.System.Numerics.Complex().$ctor$2(-value.m_imaginary, value.m_real));
                return new $.$srn.System.Numerics.Complex().$ctor$2(tan.m_imaginary, -tan.m_real);
            }
            static /*Complex */ Atan(/*Complex*/ value)
            {
                /*Complex*/ let two = new $.$srn.System.Numerics.Complex().$ctor$2(2, 0);
                return $.$srn.System.Numerics.Complex.op_Multiply(($.$srn.System.Numerics.Complex.op_Division($.$srn.System.Numerics.Complex.ImaginaryOne, two)), ($.$srn.System.Numerics.Complex.op_Subtraction($.$srn.System.Numerics.Complex.Log($.$srn.System.Numerics.Complex.op_Subtraction($.$srn.System.Numerics.Complex.One, $.$srn.System.Numerics.Complex.op_Multiply($.$srn.System.Numerics.Complex.ImaginaryOne, value))), $.$srn.System.Numerics.Complex.Log($.$srn.System.Numerics.Complex.op_Addition($.$srn.System.Numerics.Complex.One, $.$srn.System.Numerics.Complex.op_Multiply($.$srn.System.Numerics.Complex.ImaginaryOne, value))))));
            }
            static /*void */ Asin_Internal(/*double*/ x, /*double*/ y, /*out double*/ b, /*out double*/ bPrime, /*out double*/ v)
            {
                $.$spc.System.Diagnostics.Debug.Assert$1((x >= 0) || $.$spc.System.Double.IsNaN(x), "(x >= 0.0) || double.IsNaN(x)");
                $.$spc.System.Diagnostics.Debug.Assert$1((y >= 0) || $.$spc.System.Double.IsNaN(y), "(y >= 0.0) || double.IsNaN(y)");
                if ((x > $.$srn.System.Numerics.Complex.s_asinOverflowThreshold) || (y > $.$srn.System.Numerics.Complex.s_asinOverflowThreshold))
                {
                    b.$v = -1;
                    bPrime.$v = x / y;
                    /*double*/ let small, big;
                    if (x < y)
                    {
                        small = x;
                        big = y;
                    }
                    else 
                    {
                        small = y;
                        big = x;
                    }
                    /*double*/ let ratio = small / big;
                    v.$v = $.$srn.System.Numerics.Complex.s_log2 + Math.log(big) + 0.5 * $.$srn.System.Numerics.Complex.Log1P(ratio * ratio);
                }
                else 
                {
                    /*double*/ let r = $.$spc.System.Double.Hypot((x + 1), y);
                    /*double*/ let s = $.$spc.System.Double.Hypot((x - 1), y);
                    /*double*/ let a = (r + s) * 0.5;
                    b.$v = x / a;
                    if (b.$v > 0.75)
                    {
                        if (x <= 1)
                        {
                            /*double*/ let amx = (y * y / (r + (x + 1)) + (s + (1 - x))) * 0.5;
                            bPrime.$v = x / Math.sqrt((a + x) * amx);
                        }
                        else 
                        {
                            /*double*/ let t = (1 / (r + (x + 1)) + 1 / (s + (x - 1))) * 0.5;
                            bPrime.$v = x / y / Math.sqrt((a + x) * t);
                        }
                    }
                    else 
                    {
                        bPrime.$v = -1;
                    }
                    if (a < 1.5)
                    {
                        if (x < 1)
                        {
                            /*double*/ let t = (1 / (r + (x + 1)) + 1 / (s + (1 - x))) * 0.5;
                            /*double*/ let am1 = y * y * t;
                            v.$v = $.$srn.System.Numerics.Complex.Log1P(am1 + y * Math.sqrt(t * (a + 1)));
                        }
                        else 
                        {
                            /*double*/ let am1 = (y * y / (r + (x + 1)) + (s + (x - 1))) * 0.5;
                            v.$v = $.$srn.System.Numerics.Complex.Log1P(am1 + Math.sqrt(am1 * (a + 1)));
                        }
                    }
                    else 
                    {
                        v.$v = Math.log(a + Math.sqrt((a - 1) * (a + 1)));
                    }
                }
            }
            static /*bool */ IsFinite(/*Complex*/ value)
            {
                return $.$spc.System.Double.IsFinite(value.m_real) && $.$spc.System.Double.IsFinite(value.m_imaginary);
            }
            static /*bool */ IsInfinity(/*Complex*/ value)
            {
                return $.$spc.System.Double.IsInfinity(value.m_real) || $.$spc.System.Double.IsInfinity(value.m_imaginary);
            }
            static /*bool */ IsNaN(/*Complex*/ value)
            {
                return !$.$srn.System.Numerics.Complex.IsInfinity(value) && !$.$srn.System.Numerics.Complex.IsFinite(value);
            }
            static /*Complex */ Log(/*Complex*/ value)
            {
                return new $.$srn.System.Numerics.Complex().$ctor$2(Math.log($.$srn.System.Numerics.Complex.Abs(value)), Math.atan2(value.m_imaginary, value.m_real));
            }
            static /*Complex */ Log$1(/*Complex*/ value, /*double*/ baseValue)
            {
                return $.$srn.System.Numerics.Complex.op_Division($.$srn.System.Numerics.Complex.Log(value), $.$srn.System.Numerics.Complex.Log($.$srn.System.Numerics.Complex.op_Implicit$2(baseValue)));
            }
            static /*Complex */ Log10(/*Complex*/ value)
            {
                /*Complex*/ let tempLog = $.$srn.System.Numerics.Complex.Log(value);
                return $.$srn.System.Numerics.Complex.Scale(tempLog, 0.43429448190325/*InverseOfLog10*/);
            }
            static /*Complex */ Exp(/*Complex*/ value)
            {
                /*double*/ let expReal = Math.exp(value.m_real);
                return $.$srn.System.Numerics.Complex.FromPolarCoordinates(expReal, value.m_imaginary);
            }
            static /*Complex */ Sqrt(/*Complex*/ value)
            {
                if ($.$spc.System.Double.IsNaN(value.m_real))
                {
                    if ($.$spc.System.Double.IsInfinity(value.m_imaginary))
                    {
                        return new $.$srn.System.Numerics.Complex().$ctor$2(Number.POSITIVE_INFINITY/*double.PositiveInfinity*/, value.m_imaginary);
                    }
                    return new $.$srn.System.Numerics.Complex().$ctor$2(Number.NaN/*double.NaN*/, Number.NaN/*double.NaN*/);
                }
                if ($.$spc.System.Double.IsNaN(value.m_imaginary))
                {
                    if ($.$spc.System.Double.IsPositiveInfinity(value.m_real))
                    {
                        return new $.$srn.System.Numerics.Complex().$ctor$2(Number.NaN/*double.NaN*/, Number.POSITIVE_INFINITY/*double.PositiveInfinity*/);
                    }
                    if ($.$spc.System.Double.IsNegativeInfinity(value.m_real))
                    {
                        return new $.$srn.System.Numerics.Complex().$ctor$2(Number.POSITIVE_INFINITY/*double.PositiveInfinity*/, Number.NaN/*double.NaN*/);
                    }
                    return new $.$srn.System.Numerics.Complex().$ctor$2(Number.NaN/*double.NaN*/, Number.NaN/*double.NaN*/);
                }
                if (value.m_imaginary === 0)
                {
                    if (value.m_real < 0)
                    {
                        return new $.$srn.System.Numerics.Complex().$ctor$2(0, Math.sqrt(-value.m_real));
                    }
                    return new $.$srn.System.Numerics.Complex().$ctor$2(Math.sqrt(value.m_real), 0);
                }
                /*bool*/ let rescale = false;
                /*double*/ let realCopy = value.m_real;
                /*double*/ let imaginaryCopy = value.m_imaginary;
                if (($.$spc.System.Math.Abs$6(realCopy) >= $.$srn.System.Numerics.Complex.s_sqrtRescaleThreshold) || ($.$spc.System.Math.Abs$6(imaginaryCopy) >= $.$srn.System.Numerics.Complex.s_sqrtRescaleThreshold))
                {
                    if ($.$spc.System.Double.IsInfinity(value.m_imaginary))
                    {
                        return (new $.$srn.System.Numerics.Complex().$ctor$2(Number.POSITIVE_INFINITY/*double.PositiveInfinity*/, imaginaryCopy));
                    }
                    realCopy *= 0.25;
                    imaginaryCopy *= 0.25;
                    rescale = true;
                }
                /*double*/ let x, y;
                if (realCopy >= 0)
                {
                    x = Math.sqrt(($.$spc.System.Double.Hypot(realCopy, imaginaryCopy) + realCopy) * 0.5);
                    y = imaginaryCopy / (2 * x);
                }
                else 
                {
                    y = Math.sqrt(($.$spc.System.Double.Hypot(realCopy, imaginaryCopy) - realCopy) * 0.5);
                    if (imaginaryCopy < 0)
                    {
                        y = -y;
                    }
                    x = imaginaryCopy / (2 * y);
                }
                if (rescale)
                {
                    x *= 2;
                    y *= 2;
                }
                return new $.$srn.System.Numerics.Complex().$ctor$2(x, y);
            }
            static /*Complex */ Pow(/*Complex*/ value, /*Complex*/ power)
            {
                if ($.$srn.System.Numerics.Complex.op_Equality(power, $.$srn.System.Numerics.Complex.Zero))
                {
                    return $.$srn.System.Numerics.Complex.One;
                }
                if ($.$srn.System.Numerics.Complex.op_Equality(value, $.$srn.System.Numerics.Complex.Zero))
                {
                    return $.$srn.System.Numerics.Complex.Zero;
                }
                /*double*/ let valueReal = value.m_real;
                /*double*/ let valueImaginary = value.m_imaginary;
                /*double*/ let powerReal = power.m_real;
                /*double*/ let powerImaginary = power.m_imaginary;
                /*double*/ let rho = $.$srn.System.Numerics.Complex.Abs(value);
                /*double*/ let theta = Math.atan2(valueImaginary, valueReal);
                /*double*/ let newRho = powerReal * theta + powerImaginary * Math.log(rho);
                /*double*/ let t = Math.pow(rho, powerReal) * Math.exp(-powerImaginary * theta);
                return $.$srn.System.Numerics.Complex.FromPolarCoordinates(t, newRho);
            }
            static /*Complex */ Pow$1(/*Complex*/ value, /*double*/ power)
            {
                return $.$srn.System.Numerics.Complex.Pow(value, new $.$srn.System.Numerics.Complex().$ctor$2(power, 0));
            }
            static /*Complex */ Scale(/*Complex*/ value, /*double*/ factor)
            {
                /*double*/ let realResult = factor * value.m_real;
                /*double*/ let imaginaryResuilt = factor * value.m_imaginary;
                return new $.$srn.System.Numerics.Complex().$ctor$2(realResult, imaginaryResuilt);
            }
            static /*Complex */ op_Explicit(/*decimal*/ value)
            {
                return new $.$srn.System.Numerics.Complex().$ctor$2($.$spc.System.Decimal.op_Explicit$12(value), 0);
            }
            static /*Complex */ op_Explicit$1(/*Int128*/ value)
            {
                return new $.$srn.System.Numerics.Complex().$ctor$2($.$spc.System.Int128.op_Explicit$3(value), 0);
            }
            static /*Complex */ op_Explicit$2(/*BigInteger*/ value)
            {
                return new $.$srn.System.Numerics.Complex().$ctor$2($.$srn.System.Numerics.BigInteger.op_Explicit$3(value), 0);
            }
            static /*Complex */ op_Explicit$3(/*UInt128*/ value)
            {
                return new $.$srn.System.Numerics.Complex().$ctor$2($.$spc.System.UInt128.op_Explicit$3(value), 0);
            }
            static /*Complex */ op_Implicit(/*byte*/ value)
            {
                return new $.$srn.System.Numerics.Complex().$ctor$2(value, 0);
            }
            static /*Complex */ op_Implicit$1(/*char*/ value)
            {
                return new $.$srn.System.Numerics.Complex().$ctor$2(value, 0);
            }
            static /*Complex */ op_Implicit$2(/*double*/ value)
            {
                return new $.$srn.System.Numerics.Complex().$ctor$2(value, 0);
            }
            static /*Complex */ op_Implicit$3(/*Half*/ value)
            {
                return new $.$srn.System.Numerics.Complex().$ctor$2($.$spc.System.Half.op_Explicit$26(value), 0);
            }
            static /*Complex */ op_Implicit$4(/*short*/ value)
            {
                return new $.$srn.System.Numerics.Complex().$ctor$2(value, 0);
            }
            static /*Complex */ op_Implicit$5(/*int*/ value)
            {
                return new $.$srn.System.Numerics.Complex().$ctor$2(value, 0);
            }
            static /*Complex */ op_Implicit$6(/*long*/ value)
            {
                return new $.$srn.System.Numerics.Complex().$ctor$2(Number(value), 0);
            }
            static /*Complex */ op_Implicit$7(/*nint*/ value)
            {
                return new $.$srn.System.Numerics.Complex().$ctor$2(value, 0);
            }
            static /*Complex */ op_Implicit$8(/*sbyte*/ value)
            {
                return new $.$srn.System.Numerics.Complex().$ctor$2(value, 0);
            }
            static /*Complex */ op_Implicit$9(/*float*/ value)
            {
                return new $.$srn.System.Numerics.Complex().$ctor$2(value, 0);
            }
            static /*Complex */ op_Implicit$10(/*ushort*/ value)
            {
                return new $.$srn.System.Numerics.Complex().$ctor$2(value, 0);
            }
            static /*Complex */ op_Implicit$11(/*uint*/ value)
            {
                return new $.$srn.System.Numerics.Complex().$ctor$2(value, 0);
            }
            static /*Complex */ op_Implicit$12(/*ulong*/ value)
            {
                return new $.$srn.System.Numerics.Complex().$ctor$2(Number(value), 0);
            }
            static /*Complex */ op_Implicit$13(/*nuint*/ value)
            {
                return new $.$srn.System.Numerics.Complex().$ctor$2(value, 0);
            }
            static /*Complex */ get System$Numerics$IAdditiveIdentity$$$$AdditiveIdentity()
            {
                return new $.$srn.System.Numerics.Complex().$ctor$2(0, 0);
            }
            static /*Complex */ op_Decrement(/*Complex*/ value)
            {
                return $.$srn.System.Numerics.Complex.op_Subtraction(value, $.$srn.System.Numerics.Complex.One);
            }
            static /*Complex */ op_Increment(/*Complex*/ value)
            {
                return $.$srn.System.Numerics.Complex.op_Addition(value, $.$srn.System.Numerics.Complex.One);
            }
            static /*Complex */ get System$Numerics$IMultiplicativeIdentity$$$$MultiplicativeIdentity()
            {
                return new $.$srn.System.Numerics.Complex().$ctor$2(1, 0);
            }
            static /*Complex */ get System$Numerics$INumberBase$$$One()
            {
                return new $.$srn.System.Numerics.Complex().$ctor$2(1, 0);
            }
            static /*int */ get System$Numerics$INumberBase$$$Radix()
            {
                return 2;
            }
            static /*Complex */ get System$Numerics$INumberBase$$$Zero()
            {
                return new $.$srn.System.Numerics.Complex().$ctor$2(0, 0);
            }
            static /*Complex */ System$Numerics$INumberBase$$$Abs(/*Complex*/ value)
            {
                return $.$srn.System.Numerics.Complex.op_Implicit$2($.$srn.System.Numerics.Complex.Abs(value));
            }
            static /*Complex */ CreateChecked(TOther, /*TOther*/ value)
            {
                /*Complex*/ let result;
                if ($.$spc.System.Type.op_Equality$1(TOther.$type, $.$srn.System.Numerics.Complex.$type))
                {
                    result = $.$cast($.$box(value, TOther), $.$srn.System.Numerics.Complex);
                }
                else if (!$.$srn.System.Numerics.Complex.TryConvertFrom(TOther, value, $.$ref(() => result, ($v) => result = $v, $.$srn.System.Numerics.Complex)) && !TOther.System$Numerics$INumberBase$$$TryConvertToChecked($.$srn.System.Numerics.Complex, value, $.$ref(() => result, ($v) => result = $v, $.$srn.System.Numerics.Complex)))
                {
                    $.$srn.System.ThrowHelper.ThrowNotSupportedException();
                }
                return result;
            }
            static /*Complex */ CreateSaturating(TOther, /*TOther*/ value)
            {
                /*Complex*/ let result;
                if ($.$spc.System.Type.op_Equality$1(TOther.$type, $.$srn.System.Numerics.Complex.$type))
                {
                    result = $.$cast($.$box(value, TOther), $.$srn.System.Numerics.Complex);
                }
                else if (!$.$srn.System.Numerics.Complex.TryConvertFrom(TOther, value, $.$ref(() => result, ($v) => result = $v, $.$srn.System.Numerics.Complex)) && !TOther.System$Numerics$INumberBase$$$TryConvertToSaturating($.$srn.System.Numerics.Complex, value, $.$ref(() => result, ($v) => result = $v, $.$srn.System.Numerics.Complex)))
                {
                    $.$srn.System.ThrowHelper.ThrowNotSupportedException();
                }
                return result;
            }
            static /*Complex */ CreateTruncating(TOther, /*TOther*/ value)
            {
                /*Complex*/ let result;
                if ($.$spc.System.Type.op_Equality$1(TOther.$type, $.$srn.System.Numerics.Complex.$type))
                {
                    result = $.$cast($.$box(value, TOther), $.$srn.System.Numerics.Complex);
                }
                else if (!$.$srn.System.Numerics.Complex.TryConvertFrom(TOther, value, $.$ref(() => result, ($v) => result = $v, $.$srn.System.Numerics.Complex)) && !TOther.System$Numerics$INumberBase$$$TryConvertToTruncating($.$srn.System.Numerics.Complex, value, $.$ref(() => result, ($v) => result = $v, $.$srn.System.Numerics.Complex)))
                {
                    $.$srn.System.ThrowHelper.ThrowNotSupportedException();
                }
                return result;
            }
            static /*bool */ System$Numerics$INumberBase$$$IsCanonical(/*Complex*/ value)
            {
                return true;
            }
            static /*bool */ IsComplexNumber(/*Complex*/ value)
            {
                return (value.m_real !== 0) && (value.m_imaginary !== 0);
            }
            static /*bool */ IsEvenInteger(/*Complex*/ value)
            {
                return (value.m_imaginary === 0) && $.$spc.System.Double.IsEvenInteger(value.m_real);
            }
            static /*bool */ IsImaginaryNumber(/*Complex*/ value)
            {
                return (value.m_real === 0) && $.$spc.System.Double.IsRealNumber(value.m_imaginary);
            }
            static /*bool */ IsInteger(/*Complex*/ value)
            {
                return (value.m_imaginary === 0) && $.$spc.System.Double.IsInteger(value.m_real);
            }
            static /*bool */ IsNegative(/*Complex*/ value)
            {
                return (value.m_imaginary === 0) && $.$spc.System.Double.IsNegative(value.m_real);
            }
            static /*bool */ IsNegativeInfinity(/*Complex*/ value)
            {
                return (value.m_imaginary === 0) && $.$spc.System.Double.IsNegativeInfinity(value.m_real);
            }
            static /*bool */ IsNormal(/*Complex*/ value)
            {
                return $.$spc.System.Double.IsNormal(value.m_real) && ((value.m_imaginary === 0) || $.$spc.System.Double.IsNormal(value.m_imaginary));
            }
            static /*bool */ IsOddInteger(/*Complex*/ value)
            {
                return (value.m_imaginary === 0) && $.$spc.System.Double.IsOddInteger(value.m_real);
            }
            static /*bool */ IsPositive(/*Complex*/ value)
            {
                return (value.m_imaginary === 0) && $.$spc.System.Double.IsPositive(value.m_real);
            }
            static /*bool */ IsPositiveInfinity(/*Complex*/ value)
            {
                return (value.m_imaginary === 0) && $.$spc.System.Double.IsPositiveInfinity(value.m_real);
            }
            static /*bool */ IsRealNumber(/*Complex*/ value)
            {
                return (value.m_imaginary === 0) && $.$spc.System.Double.IsRealNumber(value.m_real);
            }
            static /*bool */ IsSubnormal(/*Complex*/ value)
            {
                return $.$spc.System.Double.IsSubnormal(value.m_real) || $.$spc.System.Double.IsSubnormal(value.m_imaginary);
            }
            static /*bool */ System$Numerics$INumberBase$$$IsZero(/*Complex*/ value)
            {
                return (value.m_real === 0) && (value.m_imaginary === 0);
            }
            static /*Complex */ MaxMagnitude(/*Complex*/ x, /*Complex*/ y)
            {
                /*double*/ let ax = $.$srn.System.Numerics.Complex.Abs(x);
                /*double*/ let ay = $.$srn.System.Numerics.Complex.Abs(y);
                if ((ax > ay) || $.$spc.System.Double.IsNaN(ax))
                {
                    return x;
                }
                if (ax === ay)
                {
                    if ($.$spc.System.Double.IsNegative(y.m_real))
                    {
                        if ($.$spc.System.Double.IsNegative(y.m_imaginary))
                        {
                            return x;
                        }
                        else 
                        {
                            if ($.$spc.System.Double.IsNegative(x.m_real))
                            {
                                return y;
                            }
                            else 
                            {
                                return x;
                            }
                        }
                    }
                    else if ($.$spc.System.Double.IsNegative(y.m_imaginary))
                    {
                        if ($.$spc.System.Double.IsNegative(x.m_real))
                        {
                            return y;
                        }
                        else 
                        {
                            return x;
                        }
                    }
                }
                return y;
            }
            static /*Complex */ System$Numerics$INumberBase$$$MaxMagnitudeNumber(/*Complex*/ x, /*Complex*/ y)
            {
                /*double*/ let ax = $.$srn.System.Numerics.Complex.Abs(x);
                /*double*/ let ay = $.$srn.System.Numerics.Complex.Abs(y);
                if ((ax > ay) || $.$spc.System.Double.IsNaN(ay))
                {
                    return x;
                }
                if (ax === ay)
                {
                    if ($.$spc.System.Double.IsNegative(y.m_real))
                    {
                        if ($.$spc.System.Double.IsNegative(y.m_imaginary))
                        {
                            return x;
                        }
                        else 
                        {
                            if ($.$spc.System.Double.IsNegative(x.m_real))
                            {
                                return y;
                            }
                            else 
                            {
                                return x;
                            }
                        }
                    }
                    else if ($.$spc.System.Double.IsNegative(y.m_imaginary))
                    {
                        if ($.$spc.System.Double.IsNegative(x.m_real))
                        {
                            return y;
                        }
                        else 
                        {
                            return x;
                        }
                    }
                }
                return y;
            }
            static /*Complex */ MinMagnitude(/*Complex*/ x, /*Complex*/ y)
            {
                /*double*/ let ax = $.$srn.System.Numerics.Complex.Abs(x);
                /*double*/ let ay = $.$srn.System.Numerics.Complex.Abs(y);
                if ((ax < ay) || $.$spc.System.Double.IsNaN(ax))
                {
                    return x;
                }
                if (ax === ay)
                {
                    if ($.$spc.System.Double.IsNegative(y.m_real))
                    {
                        if ($.$spc.System.Double.IsNegative(y.m_imaginary))
                        {
                            return y;
                        }
                        else 
                        {
                            if ($.$spc.System.Double.IsNegative(x.m_real))
                            {
                                return x;
                            }
                            else 
                            {
                                return y;
                            }
                        }
                    }
                    else if ($.$spc.System.Double.IsNegative(y.m_imaginary))
                    {
                        if ($.$spc.System.Double.IsNegative(x.m_real))
                        {
                            return x;
                        }
                        else 
                        {
                            return y;
                        }
                    }
                    else 
                    {
                        return x;
                    }
                }
                return y;
            }
            static /*Complex */ System$Numerics$INumberBase$$$MinMagnitudeNumber(/*Complex*/ x, /*Complex*/ y)
            {
                /*double*/ let ax = $.$srn.System.Numerics.Complex.Abs(x);
                /*double*/ let ay = $.$srn.System.Numerics.Complex.Abs(y);
                if ((ax < ay) || $.$spc.System.Double.IsNaN(ay))
                {
                    return x;
                }
                if (ax === ay)
                {
                    if ($.$spc.System.Double.IsNegative(y.m_real))
                    {
                        if ($.$spc.System.Double.IsNegative(y.m_imaginary))
                        {
                            return y;
                        }
                        else 
                        {
                            if ($.$spc.System.Double.IsNegative(x.m_real))
                            {
                                return x;
                            }
                            else 
                            {
                                return y;
                            }
                        }
                    }
                    else if ($.$spc.System.Double.IsNegative(y.m_imaginary))
                    {
                        if ($.$spc.System.Double.IsNegative(x.m_real))
                        {
                            return x;
                        }
                        else 
                        {
                            return y;
                        }
                    }
                    else 
                    {
                        return x;
                    }
                }
                return y;
            }
            static /*Complex */ System$Numerics$INumberBase$$$MultiplyAddEstimate(/*Complex*/ left, /*Complex*/ right, /*Complex*/ addend)
            {
                /*double*/ let result_realpart = addend.m_real;
                result_realpart = $.$spc.System.Double.MultiplyAddEstimate(-left.m_imaginary, right.m_imaginary, result_realpart);
                result_realpart = $.$spc.System.Double.MultiplyAddEstimate(left.m_real, right.m_real, result_realpart);
                /*double*/ let result_imaginarypart = addend.m_imaginary;
                result_imaginarypart = $.$spc.System.Double.MultiplyAddEstimate(left.m_real, right.m_imaginary, result_imaginarypart);
                result_imaginarypart = $.$spc.System.Double.MultiplyAddEstimate(left.m_imaginary, right.m_real, result_imaginarypart);
                return new $.$srn.System.Numerics.Complex().$ctor$2(result_realpart, result_imaginarypart);
            }
            static /*Complex */ Parse(/*ReadOnlySpan<char>*/ s, /*NumberStyles*/ style, /*IFormatProvider?*/ provider)
            {
                /*Complex*/ let result;
                if (!$.$srn.System.Numerics.Complex.TryParse(s, style, provider, $.$ref(() => result, ($v) => result = $v, $.$srn.System.Numerics.Complex)))
                {
                    $.$srn.System.ThrowHelper.ThrowOverflowException();
                }
                return result;
            }
            static /*Complex */ Parse$1(/*string*/ s, /*NumberStyles*/ style, /*IFormatProvider?*/ provider)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(s, "s");
                return $.$srn.System.Numerics.Complex.Parse($.$spc.System.MemoryExtensions.AsSpan$3(s), style, provider);
            }
            static /*bool */ System$Numerics$INumberBase$$$TryConvertFromChecked(TOther, /*TOther*/ value, /*out Complex*/ result)
            {
                return $.$srn.System.Numerics.Complex.TryConvertFrom(TOther, value, result);
            }
            static /*bool */ System$Numerics$INumberBase$$$TryConvertFromSaturating(TOther, /*TOther*/ value, /*out Complex*/ result)
            {
                return $.$srn.System.Numerics.Complex.TryConvertFrom(TOther, value, result);
            }
            static /*bool */ System$Numerics$INumberBase$$$TryConvertFromTruncating(TOther, /*TOther*/ value, /*out Complex*/ result)
            {
                return $.$srn.System.Numerics.Complex.TryConvertFrom(TOther, value, result);
            }
            static /*bool */ TryConvertFrom(TOther, /*TOther*/ value, /*out Complex*/ result)
            {
                if ($.$spc.System.Type.op_Equality$1(TOther.$type, $.$spc.System.Byte.$type))
                {
                    /*byte*/ let actualValue = $.$cast($.$box(value, TOther), $.$spc.System.Byte);
                    result.$v = $.$srn.System.Numerics.Complex.op_Implicit(actualValue);
                    return true;
                }
                else if ($.$spc.System.Type.op_Equality$1(TOther.$type, $.$spc.System.Char.$type))
                {
                    /*char*/ let actualValue = $.$cast($.$box(value, TOther), $.$spc.System.Char);
                    result.$v = $.$srn.System.Numerics.Complex.op_Implicit$1(actualValue);
                    return true;
                }
                else if ($.$spc.System.Type.op_Equality$1(TOther.$type, $.$spc.System.Decimal.$type))
                {
                    /*decimal*/ let actualValue = $.$cast($.$box(value, TOther), $.$spc.System.Decimal);
                    result.$v = $.$srn.System.Numerics.Complex.op_Explicit(actualValue);
                    return true;
                }
                else if ($.$spc.System.Type.op_Equality$1(TOther.$type, $.$spc.System.Double.$type))
                {
                    /*double*/ let actualValue = $.$cast($.$box(value, TOther), $.$spc.System.Double);
                    result.$v = $.$srn.System.Numerics.Complex.op_Implicit$2(actualValue);
                    return true;
                }
                else if ($.$spc.System.Type.op_Equality$1(TOther.$type, $.$spc.System.Half.$type))
                {
                    /*Half*/ let actualValue = $.$cast($.$box(value, TOther), $.$spc.System.Half);
                    result.$v = $.$srn.System.Numerics.Complex.op_Implicit$3(actualValue);
                    return true;
                }
                else if ($.$spc.System.Type.op_Equality$1(TOther.$type, $.$spc.System.Int16.$type))
                {
                    /*short*/ let actualValue = $.$cast($.$box(value, TOther), $.$spc.System.Int16);
                    result.$v = $.$srn.System.Numerics.Complex.op_Implicit$4(actualValue);
                    return true;
                }
                else if ($.$spc.System.Type.op_Equality$1(TOther.$type, $.$spc.System.Int32.$type))
                {
                    /*int*/ let actualValue = $.$cast($.$box(value, TOther), $.$spc.System.Int32);
                    result.$v = $.$srn.System.Numerics.Complex.op_Implicit$5(actualValue);
                    return true;
                }
                else if ($.$spc.System.Type.op_Equality$1(TOther.$type, $.$spc.System.Int64.$type))
                {
                    /*long*/ let actualValue = $.$cast($.$box(value, TOther), $.$spc.System.Int64);
                    result.$v = $.$srn.System.Numerics.Complex.op_Implicit$6(actualValue);
                    return true;
                }
                else if ($.$spc.System.Type.op_Equality$1(TOther.$type, $.$spc.System.Int128.$type))
                {
                    /*Int128*/ let actualValue = $.$cast($.$box(value, TOther), $.$spc.System.Int128);
                    result.$v = $.$srn.System.Numerics.Complex.op_Explicit$1(actualValue);
                    return true;
                }
                else if ($.$spc.System.Type.op_Equality$1(TOther.$type, $.$spc.System.IntPtr.$type))
                {
                    /*nint*/ let actualValue = $.$cast($.$box(value, TOther), $.$spc.System.IntPtr);
                    result.$v = $.$srn.System.Numerics.Complex.op_Implicit$7(actualValue);
                    return true;
                }
                else if ($.$spc.System.Type.op_Equality$1(TOther.$type, $.$spc.System.SByte.$type))
                {
                    /*sbyte*/ let actualValue = $.$cast($.$box(value, TOther), $.$spc.System.SByte);
                    result.$v = $.$srn.System.Numerics.Complex.op_Implicit$8(actualValue);
                    return true;
                }
                else if ($.$spc.System.Type.op_Equality$1(TOther.$type, $.$spc.System.Single.$type))
                {
                    /*float*/ let actualValue = $.$cast($.$box(value, TOther), $.$spc.System.Single);
                    result.$v = $.$srn.System.Numerics.Complex.op_Implicit$9(actualValue);
                    return true;
                }
                else if ($.$spc.System.Type.op_Equality$1(TOther.$type, $.$spc.System.UInt16.$type))
                {
                    /*ushort*/ let actualValue = $.$cast($.$box(value, TOther), $.$spc.System.UInt16);
                    result.$v = $.$srn.System.Numerics.Complex.op_Implicit$10(actualValue);
                    return true;
                }
                else if ($.$spc.System.Type.op_Equality$1(TOther.$type, $.$spc.System.UInt32.$type))
                {
                    /*uint*/ let actualValue = $.$cast($.$box(value, TOther), $.$spc.System.UInt32);
                    result.$v = $.$srn.System.Numerics.Complex.op_Implicit$11(actualValue);
                    return true;
                }
                else if ($.$spc.System.Type.op_Equality$1(TOther.$type, $.$spc.System.UInt64.$type))
                {
                    /*ulong*/ let actualValue = $.$cast($.$box(value, TOther), $.$spc.System.UInt64);
                    result.$v = $.$srn.System.Numerics.Complex.op_Implicit$12(actualValue);
                    return true;
                }
                else if ($.$spc.System.Type.op_Equality$1(TOther.$type, $.$spc.System.UInt128.$type))
                {
                    /*UInt128*/ let actualValue = $.$cast($.$box(value, TOther), $.$spc.System.UInt128);
                    result.$v = $.$srn.System.Numerics.Complex.op_Explicit$3(actualValue);
                    return true;
                }
                else if ($.$spc.System.Type.op_Equality$1(TOther.$type, $.$spc.System.UIntPtr.$type))
                {
                    /*nuint*/ let actualValue = $.$cast($.$box(value, TOther), $.$spc.System.UIntPtr);
                    result.$v = $.$srn.System.Numerics.Complex.op_Implicit$13(actualValue);
                    return true;
                }
                else 
                {
                    result.$v = new $.$srn.System.Numerics.Complex();
                    return false;
                }
            }
            static /*bool */ System$Numerics$INumberBase$$$TryConvertToChecked(TOther, /*Complex*/ value, /*out TOther*/ result)
            {
                if ($.$spc.System.Type.op_Equality$1(TOther.$type, $.$spc.System.Byte.$type))
                {
                    if (value.m_imaginary !== 0)
                    {
                        $.$srn.System.ThrowHelper.ThrowOverflowException();
                    }
                    /*byte*/ let actualResult = $.$cast(value.m_real, $.$spc.System.Byte);
                    result.$v = $.$cast($.$box(actualResult, $.$spc.System.Byte), TOther);
                    return true;
                }
                else if ($.$spc.System.Type.op_Equality$1(TOther.$type, $.$spc.System.Char.$type))
                {
                    if (value.m_imaginary !== 0)
                    {
                        $.$srn.System.ThrowHelper.ThrowOverflowException();
                    }
                    /*char*/ let actualResult = $.$cast(value.m_real, $.$spc.System.Char);
                    result.$v = $.$cast($.$box(actualResult, $.$spc.System.Char), TOther);
                    return true;
                }
                else if ($.$spc.System.Type.op_Equality$1(TOther.$type, $.$spc.System.Decimal.$type))
                {
                    if (value.m_imaginary !== 0)
                    {
                        $.$srn.System.ThrowHelper.ThrowOverflowException();
                    }
                    /*decimal*/ let actualResult = $.$spc.System.Decimal.op_Explicit$1(value.m_real);
                    result.$v = $.$cast($.$cast(actualResult, $.$spc.System.Object), TOther);
                    return true;
                }
                else if ($.$spc.System.Type.op_Equality$1(TOther.$type, $.$spc.System.Double.$type))
                {
                    /*double*/ let actualResult = (value.m_imaginary !== 0) ? Number.NaN/*double.NaN*/ : value.m_real;
                    result.$v = $.$cast($.$box(actualResult, $.$spc.System.Double), TOther);
                    return true;
                }
                else if ($.$spc.System.Type.op_Equality$1(TOther.$type, $.$spc.System.Half.$type))
                {
                    /*Half*/ let actualResult = (value.m_imaginary !== 0) ? $.$spc.System.Half.NaN : $.$spc.System.Half.op_Explicit$2(value.m_real);
                    result.$v = $.$cast($.$cast(actualResult, $.$spc.System.Object), TOther);
                    return true;
                }
                else if ($.$spc.System.Type.op_Equality$1(TOther.$type, $.$spc.System.Int16.$type))
                {
                    if (value.m_imaginary !== 0)
                    {
                        $.$srn.System.ThrowHelper.ThrowOverflowException();
                    }
                    /*short*/ let actualResult = $.$cast(value.m_real, $.$spc.System.Int16);
                    result.$v = $.$cast($.$box(actualResult, $.$spc.System.Int16), TOther);
                    return true;
                }
                else if ($.$spc.System.Type.op_Equality$1(TOther.$type, $.$spc.System.Int32.$type))
                {
                    if (value.m_imaginary !== 0)
                    {
                        $.$srn.System.ThrowHelper.ThrowOverflowException();
                    }
                    /*int*/ let actualResult = $.$cast(value.m_real, $.$spc.System.Int32);
                    result.$v = $.$cast($.$box(actualResult, $.$spc.System.Int32), TOther);
                    return true;
                }
                else if ($.$spc.System.Type.op_Equality$1(TOther.$type, $.$spc.System.Int64.$type))
                {
                    if (value.m_imaginary !== 0)
                    {
                        $.$srn.System.ThrowHelper.ThrowOverflowException();
                    }
                    /*long*/ let actualResult = $.$cast(value.m_real, $.$spc.System.Int64);
                    result.$v = $.$cast($.$box(actualResult, $.$spc.System.Int64), TOther);
                    return true;
                }
                else if ($.$spc.System.Type.op_Equality$1(TOther.$type, $.$spc.System.Int128.$type))
                {
                    if (value.m_imaginary !== 0)
                    {
                        $.$srn.System.ThrowHelper.ThrowOverflowException();
                    }
                    /*Int128*/ let actualResult = $.$spc.System.Int128.op_Explicit$17(value.m_real);
                    result.$v = $.$cast($.$cast(actualResult, $.$spc.System.Object), TOther);
                    return true;
                }
                else if ($.$spc.System.Type.op_Equality$1(TOther.$type, $.$spc.System.IntPtr.$type))
                {
                    if (value.m_imaginary !== 0)
                    {
                        $.$srn.System.ThrowHelper.ThrowOverflowException();
                    }
                    /*nint*/ let actualResult = $.$cast(value.m_real, $.$spc.System.IntPtr);
                    result.$v = $.$cast($.$box(actualResult, $.$spc.System.IntPtr), TOther);
                    return true;
                }
                else if ($.$spc.System.Type.op_Equality$1(TOther.$type, $.$srn.System.Numerics.BigInteger.$type))
                {
                    if (value.m_imaginary !== 0)
                    {
                        $.$srn.System.ThrowHelper.ThrowOverflowException();
                    }
                    /*BigInteger*/ let actualResult = $.$srn.System.Numerics.BigInteger.op_Explicit$18(value.m_real);
                    result.$v = $.$cast($.$cast(actualResult, $.$spc.System.Object), TOther);
                    return true;
                }
                else if ($.$spc.System.Type.op_Equality$1(TOther.$type, $.$spc.System.SByte.$type))
                {
                    if (value.m_imaginary !== 0)
                    {
                        $.$srn.System.ThrowHelper.ThrowOverflowException();
                    }
                    /*sbyte*/ let actualResult = $.$cast(value.m_real, $.$spc.System.SByte);
                    result.$v = $.$cast($.$box(actualResult, $.$spc.System.SByte), TOther);
                    return true;
                }
                else if ($.$spc.System.Type.op_Equality$1(TOther.$type, $.$spc.System.Single.$type))
                {
                    /*float*/ let actualResult = (value.m_imaginary !== 0) ? Number.NaN/*float.NaN*/ : $.$cast(value.m_real, $.$spc.System.Single);
                    result.$v = $.$cast($.$box(actualResult, $.$spc.System.Single), TOther);
                    return true;
                }
                else if ($.$spc.System.Type.op_Equality$1(TOther.$type, $.$spc.System.UInt16.$type))
                {
                    if (value.m_imaginary !== 0)
                    {
                        $.$srn.System.ThrowHelper.ThrowOverflowException();
                    }
                    /*ushort*/ let actualResult = $.$cast(value.m_real, $.$spc.System.UInt16);
                    result.$v = $.$cast($.$box(actualResult, $.$spc.System.UInt16), TOther);
                    return true;
                }
                else if ($.$spc.System.Type.op_Equality$1(TOther.$type, $.$spc.System.UInt32.$type))
                {
                    if (value.m_imaginary !== 0)
                    {
                        $.$srn.System.ThrowHelper.ThrowOverflowException();
                    }
                    /*uint*/ let actualResult = $.$cast(value.m_real, $.$spc.System.UInt32);
                    result.$v = $.$cast($.$box(actualResult, $.$spc.System.UInt32), TOther);
                    return true;
                }
                else if ($.$spc.System.Type.op_Equality$1(TOther.$type, $.$spc.System.UInt64.$type))
                {
                    if (value.m_imaginary !== 0)
                    {
                        $.$srn.System.ThrowHelper.ThrowOverflowException();
                    }
                    /*ulong*/ let actualResult = $.$cast(value.m_real, $.$spc.System.UInt64);
                    result.$v = $.$cast($.$box(actualResult, $.$spc.System.UInt64), TOther);
                    return true;
                }
                else if ($.$spc.System.Type.op_Equality$1(TOther.$type, $.$spc.System.UInt128.$type))
                {
                    if (value.m_imaginary !== 0)
                    {
                        $.$srn.System.ThrowHelper.ThrowOverflowException();
                    }
                    /*UInt128*/ let actualResult = $.$spc.System.UInt128.op_Explicit$17(value.m_real);
                    result.$v = $.$cast($.$cast(actualResult, $.$spc.System.Object), TOther);
                    return true;
                }
                else if ($.$spc.System.Type.op_Equality$1(TOther.$type, $.$spc.System.UIntPtr.$type))
                {
                    if (value.m_imaginary !== 0)
                    {
                        $.$srn.System.ThrowHelper.ThrowOverflowException();
                    }
                    /*nuint*/ let actualResult = $.$cast(value.m_real, $.$spc.System.UIntPtr);
                    result.$v = $.$cast($.$box(actualResult, $.$spc.System.UIntPtr), TOther);
                    return true;
                }
                else 
                {
                    result.$v = $.$default(TOther);
                    return false;
                }
            }
            static /*bool */ System$Numerics$INumberBase$$$TryConvertToSaturating(TOther, /*Complex*/ value, /*out TOther*/ result)
            {
                if ($.$spc.System.Type.op_Equality$1(TOther.$type, $.$spc.System.Byte.$type))
                {
                    /*byte*/ let actualResult = (value.m_real >= 255/*byte.MaxValue*/) ? 255/*byte.MaxValue*/ : (value.m_real <= 0/*byte.MinValue*/) ? 0/*byte.MinValue*/ : $.$cast(value.m_real, $.$spc.System.Byte);
                    result.$v = $.$cast($.$box(actualResult, $.$spc.System.Byte), TOther);
                    return true;
                }
                else if ($.$spc.System.Type.op_Equality$1(TOther.$type, $.$spc.System.Char.$type))
                {
                    /*char*/ let actualResult = (value.m_real >= /*\uFFFF*/ 65535) ? /*\uFFFF*/ 65535 : (value.m_real <= /*\u0000*/ 0) ? /*\u0000*/ 0 : $.$cast(value.m_real, $.$spc.System.Char);
                    result.$v = $.$cast($.$box(actualResult, $.$spc.System.Char), TOther);
                    return true;
                }
                else if ($.$spc.System.Type.op_Equality$1(TOther.$type, $.$spc.System.Decimal.$type))
                {
                    /*decimal*/ let actualResult = (value.m_real >= $.$spc.System.Decimal.op_Explicit$12(new $.$spc.System.Decimal().$ctor$9([-1, -1, -1, 0]))) ? new $.$spc.System.Decimal().$ctor$9([-1, -1, -1, 0]) : (value.m_real <= $.$spc.System.Decimal.op_Explicit$12(new $.$spc.System.Decimal().$ctor$9([-1, -1, -1, -2147483648]))) ? new $.$spc.System.Decimal().$ctor$9([-1, -1, -1, -2147483648]) : $.$spc.System.Decimal.op_Explicit$1(value.m_real);
                    result.$v = $.$cast($.$cast(actualResult, $.$spc.System.Object), TOther);
                    return true;
                }
                else if ($.$spc.System.Type.op_Equality$1(TOther.$type, $.$spc.System.Double.$type))
                {
                    /*double*/ let actualResult = value.m_real;
                    result.$v = $.$cast($.$box(actualResult, $.$spc.System.Double), TOther);
                    return true;
                }
                else if ($.$spc.System.Type.op_Equality$1(TOther.$type, $.$spc.System.Half.$type))
                {
                    /*Half*/ let actualResult = $.$spc.System.Half.op_Explicit$2(value.m_real);
                    result.$v = $.$cast($.$cast(actualResult, $.$spc.System.Object), TOther);
                    return true;
                }
                else if ($.$spc.System.Type.op_Equality$1(TOther.$type, $.$spc.System.Int16.$type))
                {
                    /*short*/ let actualResult = (value.m_real >= 32767/*short.MaxValue*/) ? 32767/*short.MaxValue*/ : (value.m_real <= -32768/*short.MinValue*/) ? -32768/*short.MinValue*/ : $.$cast(value.m_real, $.$spc.System.Int16);
                    result.$v = $.$cast($.$box(actualResult, $.$spc.System.Int16), TOther);
                    return true;
                }
                else if ($.$spc.System.Type.op_Equality$1(TOther.$type, $.$spc.System.Int32.$type))
                {
                    /*int*/ let actualResult = (value.m_real >= 2147483647/*int.MaxValue*/) ? 2147483647/*int.MaxValue*/ : (value.m_real <= -2147483648/*int.MinValue*/) ? -2147483648/*int.MinValue*/ : $.$cast(value.m_real, $.$spc.System.Int32);
                    result.$v = $.$cast($.$box(actualResult, $.$spc.System.Int32), TOther);
                    return true;
                }
                else if ($.$spc.System.Type.op_Equality$1(TOther.$type, $.$spc.System.Int64.$type))
                {
                    /*long*/ let actualResult = (value.m_real >= Number(9223372036854775807n)) ? 9223372036854775807n : (value.m_real <= Number(-9223372036854775808n)) ? -9223372036854775808n : $.$cast(value.m_real, $.$spc.System.Int64);
                    result.$v = $.$cast($.$box(actualResult, $.$spc.System.Int64), TOther);
                    return true;
                }
                else if ($.$spc.System.Type.op_Equality$1(TOther.$type, $.$spc.System.Int128.$type))
                {
                    /*Int128*/ let actualResult = (value.m_real >= +1.7014118346046923E+38) ? $.$spc.System.Int128.MaxValue : (value.m_real <= -1.7014118346046923E+38) ? $.$spc.System.Int128.MinValue : $.$spc.System.Int128.op_Explicit$17(value.m_real);
                    result.$v = $.$cast($.$cast(actualResult, $.$spc.System.Object), TOther);
                    return true;
                }
                else if ($.$spc.System.Type.op_Equality$1(TOther.$type, $.$spc.System.IntPtr.$type))
                {
                    /*nint*/ let actualResult = (value.m_real >= $.$spc.System.IntPtr.MaxValue) ? $.$spc.System.IntPtr.MaxValue : (value.m_real <= $.$spc.System.IntPtr.MinValue) ? $.$spc.System.IntPtr.MinValue : $.$cast(value.m_real, $.$spc.System.IntPtr);
                    result.$v = $.$cast($.$box(actualResult, $.$spc.System.IntPtr), TOther);
                    return true;
                }
                else if ($.$spc.System.Type.op_Equality$1(TOther.$type, $.$srn.System.Numerics.BigInteger.$type))
                {
                    /*BigInteger*/ let actualResult = $.$srn.System.Numerics.BigInteger.op_Explicit$18(value.m_real);
                    result.$v = $.$cast($.$cast(actualResult, $.$spc.System.Object), TOther);
                    return true;
                }
                else if ($.$spc.System.Type.op_Equality$1(TOther.$type, $.$spc.System.SByte.$type))
                {
                    /*sbyte*/ let actualResult = (value.m_real >= 127/*sbyte.MaxValue*/) ? 127/*sbyte.MaxValue*/ : (value.m_real <= -128/*sbyte.MinValue*/) ? -128/*sbyte.MinValue*/ : $.$cast(value.m_real, $.$spc.System.SByte);
                    result.$v = $.$cast($.$box(actualResult, $.$spc.System.SByte), TOther);
                    return true;
                }
                else if ($.$spc.System.Type.op_Equality$1(TOther.$type, $.$spc.System.Single.$type))
                {
                    /*float*/ let actualResult = $.$cast(value.m_real, $.$spc.System.Single);
                    result.$v = $.$cast($.$box(actualResult, $.$spc.System.Single), TOther);
                    return true;
                }
                else if ($.$spc.System.Type.op_Equality$1(TOther.$type, $.$spc.System.UInt16.$type))
                {
                    /*ushort*/ let actualResult = (value.m_real >= 65535/*ushort.MaxValue*/) ? 65535/*ushort.MaxValue*/ : (value.m_real <= 0/*ushort.MinValue*/) ? 0/*ushort.MinValue*/ : $.$cast(value.m_real, $.$spc.System.UInt16);
                    result.$v = $.$cast($.$box(actualResult, $.$spc.System.UInt16), TOther);
                    return true;
                }
                else if ($.$spc.System.Type.op_Equality$1(TOther.$type, $.$spc.System.UInt32.$type))
                {
                    /*uint*/ let actualResult = (value.m_real >= 4294967295/*uint.MaxValue*/) ? 4294967295/*uint.MaxValue*/ : (value.m_real <= 0/*uint.MinValue*/) ? 0/*uint.MinValue*/ : $.$cast(value.m_real, $.$spc.System.UInt32);
                    result.$v = $.$cast($.$box(actualResult, $.$spc.System.UInt32), TOther);
                    return true;
                }
                else if ($.$spc.System.Type.op_Equality$1(TOther.$type, $.$spc.System.UInt64.$type))
                {
                    /*ulong*/ let actualResult = (value.m_real >= Number(18446744073709551615n)) ? 18446744073709551615n : (value.m_real <= Number(0n)) ? 0n : $.$cast(value.m_real, $.$spc.System.UInt64);
                    result.$v = $.$cast($.$box(actualResult, $.$spc.System.UInt64), TOther);
                    return true;
                }
                else if ($.$spc.System.Type.op_Equality$1(TOther.$type, $.$spc.System.UInt128.$type))
                {
                    /*UInt128*/ let actualResult = (value.m_real >= 3.402823669209385E+38) ? $.$spc.System.UInt128.MaxValue : (value.m_real <= 0) ? $.$spc.System.UInt128.MinValue : $.$spc.System.UInt128.op_Explicit$17(value.m_real);
                    result.$v = $.$cast($.$cast(actualResult, $.$spc.System.Object), TOther);
                    return true;
                }
                else if ($.$spc.System.Type.op_Equality$1(TOther.$type, $.$spc.System.UIntPtr.$type))
                {
                    /*nuint*/ let actualResult = (value.m_real >= $.$spc.System.UIntPtr.MaxValue) ? $.$spc.System.UIntPtr.MaxValue : (value.m_real <= $.$spc.System.UIntPtr.MinValue) ? $.$spc.System.UIntPtr.MinValue : $.$cast(value.m_real, $.$spc.System.UIntPtr);
                    result.$v = $.$cast($.$box(actualResult, $.$spc.System.UIntPtr), TOther);
                    return true;
                }
                else 
                {
                    result.$v = $.$default(TOther);
                    return false;
                }
            }
            static /*bool */ System$Numerics$INumberBase$$$TryConvertToTruncating(TOther, /*Complex*/ value, /*out TOther*/ result)
            {
                if ($.$spc.System.Type.op_Equality$1(TOther.$type, $.$spc.System.Byte.$type))
                {
                    /*byte*/ let actualResult = (value.m_real >= 255/*byte.MaxValue*/) ? 255/*byte.MaxValue*/ : (value.m_real <= 0/*byte.MinValue*/) ? 0/*byte.MinValue*/ : $.$cast(value.m_real, $.$spc.System.Byte);
                    result.$v = $.$cast($.$box(actualResult, $.$spc.System.Byte), TOther);
                    return true;
                }
                else if ($.$spc.System.Type.op_Equality$1(TOther.$type, $.$spc.System.Char.$type))
                {
                    /*char*/ let actualResult = (value.m_real >= /*\uFFFF*/ 65535) ? /*\uFFFF*/ 65535 : (value.m_real <= /*\u0000*/ 0) ? /*\u0000*/ 0 : $.$cast(value.m_real, $.$spc.System.Char);
                    result.$v = $.$cast($.$box(actualResult, $.$spc.System.Char), TOther);
                    return true;
                }
                else if ($.$spc.System.Type.op_Equality$1(TOther.$type, $.$spc.System.Decimal.$type))
                {
                    /*decimal*/ let actualResult = (value.m_real >= $.$spc.System.Decimal.op_Explicit$12(new $.$spc.System.Decimal().$ctor$9([-1, -1, -1, 0]))) ? new $.$spc.System.Decimal().$ctor$9([-1, -1, -1, 0]) : (value.m_real <= $.$spc.System.Decimal.op_Explicit$12(new $.$spc.System.Decimal().$ctor$9([-1, -1, -1, -2147483648]))) ? new $.$spc.System.Decimal().$ctor$9([-1, -1, -1, -2147483648]) : $.$spc.System.Decimal.op_Explicit$1(value.m_real);
                    result.$v = $.$cast($.$cast(actualResult, $.$spc.System.Object), TOther);
                    return true;
                }
                else if ($.$spc.System.Type.op_Equality$1(TOther.$type, $.$spc.System.Double.$type))
                {
                    /*double*/ let actualResult = value.m_real;
                    result.$v = $.$cast($.$box(actualResult, $.$spc.System.Double), TOther);
                    return true;
                }
                else if ($.$spc.System.Type.op_Equality$1(TOther.$type, $.$spc.System.Half.$type))
                {
                    /*Half*/ let actualResult = $.$spc.System.Half.op_Explicit$2(value.m_real);
                    result.$v = $.$cast($.$cast(actualResult, $.$spc.System.Object), TOther);
                    return true;
                }
                else if ($.$spc.System.Type.op_Equality$1(TOther.$type, $.$spc.System.Int16.$type))
                {
                    /*short*/ let actualResult = (value.m_real >= 32767/*short.MaxValue*/) ? 32767/*short.MaxValue*/ : (value.m_real <= -32768/*short.MinValue*/) ? -32768/*short.MinValue*/ : $.$cast(value.m_real, $.$spc.System.Int16);
                    result.$v = $.$cast($.$box(actualResult, $.$spc.System.Int16), TOther);
                    return true;
                }
                else if ($.$spc.System.Type.op_Equality$1(TOther.$type, $.$spc.System.Int32.$type))
                {
                    /*int*/ let actualResult = (value.m_real >= 2147483647/*int.MaxValue*/) ? 2147483647/*int.MaxValue*/ : (value.m_real <= -2147483648/*int.MinValue*/) ? -2147483648/*int.MinValue*/ : $.$cast(value.m_real, $.$spc.System.Int32);
                    result.$v = $.$cast($.$box(actualResult, $.$spc.System.Int32), TOther);
                    return true;
                }
                else if ($.$spc.System.Type.op_Equality$1(TOther.$type, $.$spc.System.Int64.$type))
                {
                    /*long*/ let actualResult = (value.m_real >= Number(9223372036854775807n)) ? 9223372036854775807n : (value.m_real <= Number(-9223372036854775808n)) ? -9223372036854775808n : $.$cast(value.m_real, $.$spc.System.Int64);
                    result.$v = $.$cast($.$box(actualResult, $.$spc.System.Int64), TOther);
                    return true;
                }
                else if ($.$spc.System.Type.op_Equality$1(TOther.$type, $.$spc.System.Int128.$type))
                {
                    /*Int128*/ let actualResult = (value.m_real >= +1.7014118346046923E+38) ? $.$spc.System.Int128.MaxValue : (value.m_real <= -1.7014118346046923E+38) ? $.$spc.System.Int128.MinValue : $.$spc.System.Int128.op_Explicit$17(value.m_real);
                    result.$v = $.$cast($.$cast(actualResult, $.$spc.System.Object), TOther);
                    return true;
                }
                else if ($.$spc.System.Type.op_Equality$1(TOther.$type, $.$spc.System.IntPtr.$type))
                {
                    /*nint*/ let actualResult = (value.m_real >= $.$spc.System.IntPtr.MaxValue) ? $.$spc.System.IntPtr.MaxValue : (value.m_real <= $.$spc.System.IntPtr.MinValue) ? $.$spc.System.IntPtr.MinValue : $.$cast(value.m_real, $.$spc.System.IntPtr);
                    result.$v = $.$cast($.$box(actualResult, $.$spc.System.IntPtr), TOther);
                    return true;
                }
                else if ($.$spc.System.Type.op_Equality$1(TOther.$type, $.$srn.System.Numerics.BigInteger.$type))
                {
                    /*BigInteger*/ let actualResult = $.$srn.System.Numerics.BigInteger.op_Explicit$18(value.m_real);
                    result.$v = $.$cast($.$cast(actualResult, $.$spc.System.Object), TOther);
                    return true;
                }
                else if ($.$spc.System.Type.op_Equality$1(TOther.$type, $.$spc.System.SByte.$type))
                {
                    /*sbyte*/ let actualResult = (value.m_real >= 127/*sbyte.MaxValue*/) ? 127/*sbyte.MaxValue*/ : (value.m_real <= -128/*sbyte.MinValue*/) ? -128/*sbyte.MinValue*/ : $.$cast(value.m_real, $.$spc.System.SByte);
                    result.$v = $.$cast($.$box(actualResult, $.$spc.System.SByte), TOther);
                    return true;
                }
                else if ($.$spc.System.Type.op_Equality$1(TOther.$type, $.$spc.System.Single.$type))
                {
                    /*float*/ let actualResult = $.$cast(value.m_real, $.$spc.System.Single);
                    result.$v = $.$cast($.$box(actualResult, $.$spc.System.Single), TOther);
                    return true;
                }
                else if ($.$spc.System.Type.op_Equality$1(TOther.$type, $.$spc.System.UInt16.$type))
                {
                    /*ushort*/ let actualResult = (value.m_real >= 65535/*ushort.MaxValue*/) ? 65535/*ushort.MaxValue*/ : (value.m_real <= 0/*ushort.MinValue*/) ? 0/*ushort.MinValue*/ : $.$cast(value.m_real, $.$spc.System.UInt16);
                    result.$v = $.$cast($.$box(actualResult, $.$spc.System.UInt16), TOther);
                    return true;
                }
                else if ($.$spc.System.Type.op_Equality$1(TOther.$type, $.$spc.System.UInt32.$type))
                {
                    /*uint*/ let actualResult = (value.m_real >= 4294967295/*uint.MaxValue*/) ? 4294967295/*uint.MaxValue*/ : (value.m_real <= 0/*uint.MinValue*/) ? 0/*uint.MinValue*/ : $.$cast(value.m_real, $.$spc.System.UInt32);
                    result.$v = $.$cast($.$box(actualResult, $.$spc.System.UInt32), TOther);
                    return true;
                }
                else if ($.$spc.System.Type.op_Equality$1(TOther.$type, $.$spc.System.UInt64.$type))
                {
                    /*ulong*/ let actualResult = (value.m_real >= Number(18446744073709551615n)) ? 18446744073709551615n : (value.m_real <= Number(0n)) ? 0n : $.$cast(value.m_real, $.$spc.System.UInt64);
                    result.$v = $.$cast($.$box(actualResult, $.$spc.System.UInt64), TOther);
                    return true;
                }
                else if ($.$spc.System.Type.op_Equality$1(TOther.$type, $.$spc.System.UInt128.$type))
                {
                    /*UInt128*/ let actualResult = (value.m_real >= 3.402823669209385E+38) ? $.$spc.System.UInt128.MaxValue : (value.m_real <= 0) ? $.$spc.System.UInt128.MinValue : $.$spc.System.UInt128.op_Explicit$17(value.m_real);
                    result.$v = $.$cast($.$cast(actualResult, $.$spc.System.Object), TOther);
                    return true;
                }
                else if ($.$spc.System.Type.op_Equality$1(TOther.$type, $.$spc.System.UIntPtr.$type))
                {
                    /*nuint*/ let actualResult = (value.m_real >= $.$spc.System.UIntPtr.MaxValue) ? $.$spc.System.UIntPtr.MaxValue : (value.m_real <= $.$spc.System.UIntPtr.MinValue) ? $.$spc.System.UIntPtr.MinValue : $.$cast(value.m_real, $.$spc.System.UIntPtr);
                    result.$v = $.$cast($.$box(actualResult, $.$spc.System.UIntPtr), TOther);
                    return true;
                }
                else 
                {
                    result.$v = $.$default(TOther);
                    return false;
                }
            }
            static /*bool */ TryParse(/*ReadOnlySpan<char>*/ s, /*NumberStyles*/ style, /*IFormatProvider?*/ provider, /*out Complex*/ result)
            {
                ValidateParseStyleFloatingPoint(style);
                /*int*/ let openBracket = $.$spc.System.MemoryExtensions.IndexOf$2($.$spc.System.Char, s, /*<*/ 60);
                /*int*/ let semicolon = $.$spc.System.MemoryExtensions.IndexOf$2($.$spc.System.Char, s, /*;*/ 59);
                /*int*/ let closeBracket = $.$spc.System.MemoryExtensions.IndexOf$2($.$spc.System.Char, s, /*>*/ 62);
                if ((s.Length < 5) || (openBracket === -1) || (semicolon === -1) || (closeBracket === -1) || (openBracket > semicolon) || (openBracket > closeBracket) || (semicolon > closeBracket))
                {
                    result.$v = new $.$srn.System.Numerics.Complex();
                    return false;
                }
                if ((openBracket !== 0) && (((style & 1/*NumberStyles.AllowLeadingWhite*/) === 0) || !$.$spc.System.MemoryExtensions.IsWhiteSpace(s.Slice$1(0, openBracket))))
                {
                    result.$v = new $.$srn.System.Numerics.Complex();
                    return false;
                }
                /*double*/ let real;
                if (!$.$spc.System.Double.TryParse$4(s.Slice$1(((openBracket + 1) | 0), ((((semicolon - openBracket) | 0) - 1) | 0)), style, provider, $.$ref(() => real, ($v) => real = $v, $.$spc.System.Double)))
                {
                    result.$v = new $.$srn.System.Numerics.Complex();
                    return false;
                }
                if ($.$spc.System.Char.IsWhiteSpace(s.get_Item(((semicolon + 1) | 0)).$v))
                {
                    semicolon += 1;
                }
                /*double*/ let imaginary;
                if (!$.$spc.System.Double.TryParse$4(s.Slice$1(((semicolon + 1) | 0), ((((closeBracket - semicolon) | 0) - 1) | 0)), style, provider, $.$ref(() => imaginary, ($v) => imaginary = $v, $.$spc.System.Double)))
                {
                    result.$v = new $.$srn.System.Numerics.Complex();
                    return false;
                }
                if ((closeBracket !== (((s.Length - 1) | 0))) && (((style & 2/*NumberStyles.AllowTrailingWhite*/) === 0) || !$.$spc.System.MemoryExtensions.IsWhiteSpace(s.Slice(closeBracket))))
                {
                    result.$v = new $.$srn.System.Numerics.Complex();
                    return false;
                }
                result.$v = new $.$srn.System.Numerics.Complex().$ctor$2(real, imaginary);
                return true;
                /*static void*/  function ValidateParseStyleFloatingPoint(/*NumberStyles*/ style)
                {
                    if ((style & (-1024/*InvalidNumberStyles*/ | 512/*NumberStyles.AllowHexSpecifier*/)) !== 0)
                    {
                        ThrowInvalid(style);
                        /*static void*/  function ThrowInvalid(/*NumberStyles*/ value)
                        {
                            if ((value & -1024/*InvalidNumberStyles*/) !== 0)
                            {
                                throw new $.$spc.System.ArgumentException().$ctor$13($.$srn.System.SR.Argument_InvalidNumberStyles, "style");
                            }
                            throw new $.$spc.System.ArgumentException().$ctor$10($.$srn.System.SR.Arg_HexStyleNotSupported);
                        }
                    }
                }
            }
            static /*bool */ TryParse$1(/*string?*/ s, /*NumberStyles*/ style, /*IFormatProvider?*/ provider, /*out Complex*/ result)
            {
                if (s === null)
                {
                    result.$v = new $.$srn.System.Numerics.Complex();
                    return false;
                }
                return $.$srn.System.Numerics.Complex.TryParse($.$spc.System.MemoryExtensions.AsSpan$3(s), style, provider, result);
            }
            static /*Complex */ Parse$2(/*string*/ s, /*IFormatProvider?*/ provider)
            {
                return $.$srn.System.Numerics.Complex.Parse$1(s, 231/*DefaultNumberStyle*/, provider);
            }
            static /*bool */ TryParse$2(/*string?*/ s, /*IFormatProvider?*/ provider, /*out Complex*/ result)
            {
                return $.$srn.System.Numerics.Complex.TryParse$1(s, 231/*DefaultNumberStyle*/, provider, result);
            }
            static /*Complex */ get System$Numerics$ISignedNumber$$$NegativeOne()
            {
                return new $.$srn.System.Numerics.Complex().$ctor$2(-1, 0);
            }
            /*bool */ TryFormat(/*Span<char>*/ destination, /*out int*/ charsWritten, /*ReadOnlySpan<char>*/ format, /*IFormatProvider?*/ provider)
            {
                return this.TryFormatCore($.$spc.System.Char, destination, charsWritten, format, provider);
            }
            /*bool */ TryFormat$1(/*Span<byte>*/ utf8Destination, /*out int*/ bytesWritten, /*ReadOnlySpan<char>*/ format, /*IFormatProvider?*/ provider)
            {
                return this.TryFormatCore($.$spc.System.Byte, utf8Destination, bytesWritten, format, provider);
            }
            /*bool */ TryFormatCore(TChar, /*Span<TChar>*/ destination, /*out int*/ charsWritten, /*ReadOnlySpan<char>*/ format, /*IFormatProvider?*/ provider)
            {
                $.$spc.System.Diagnostics.Debug.Assert$1($.$spc.System.Type.op_Equality$1(TChar.$type, $.$spc.System.Char.$type) || $.$spc.System.Type.op_Equality$1(TChar.$type, $.$spc.System.Byte.$type), "typeof(TChar) == typeof(char) || typeof(TChar) == typeof(byte)");
                if (destination.Length >= 6)
                {
                    /*int*/ let realChars;
                    if ($.$spc.System.Type.op_Equality$1(TChar.$type, $.$spc.System.Char.$type) ? $.$spc.System.Double.TryFormat.call(this.m_real, $.$spc.System.Runtime.CompilerServices.Unsafe.BitCast($.$spc.System.Span$$(TChar), $.$spc.System.Span$$($.$spc.System.Char), destination.Slice(1)), $.$ref(() => realChars, ($v) => realChars = $v, $.$spc.System.Int32), format, provider) : $.$spc.System.Double.TryFormat$1.call(this.m_real, $.$spc.System.Runtime.CompilerServices.Unsafe.BitCast($.$spc.System.Span$$(TChar), $.$spc.System.Span$$($.$spc.System.Byte), destination.Slice(1)), $.$ref(() => realChars, ($v) => realChars = $v, $.$spc.System.Int32), format, provider))
                    {
                        destination.get_Item(0).$v = TChar.System$Numerics$INumberBase$$$CreateTruncating($.$spc.System.Char, /*<*/ 60);
                        destination = destination.Slice(((1 + realChars) | 0));
                        if (destination.Length >= 4)
                        {
                            /*int*/ let imaginaryChars;
                            if ($.$spc.System.Type.op_Equality$1(TChar.$type, $.$spc.System.Char.$type) ? $.$spc.System.Double.TryFormat.call(this.m_imaginary, $.$spc.System.Runtime.CompilerServices.Unsafe.BitCast($.$spc.System.Span$$(TChar), $.$spc.System.Span$$($.$spc.System.Char), destination.Slice(2)), $.$ref(() => imaginaryChars, ($v) => imaginaryChars = $v, $.$spc.System.Int32), format, provider) : $.$spc.System.Double.TryFormat$1.call(this.m_imaginary, $.$spc.System.Runtime.CompilerServices.Unsafe.BitCast($.$spc.System.Span$$(TChar), $.$spc.System.Span$$($.$spc.System.Byte), destination.Slice(2)), $.$ref(() => imaginaryChars, ($v) => imaginaryChars = $v, $.$spc.System.Int32), format, provider))
                            {
                                if (((((2 + imaginaryChars) | 0)) >>> 0) < (destination.Length >>> 0))
                                {
                                    destination.get_Item(0).$v = TChar.System$Numerics$INumberBase$$$CreateTruncating($.$spc.System.Char, /*;*/ 59);
                                    destination.get_Item(1).$v = TChar.System$Numerics$INumberBase$$$CreateTruncating($.$spc.System.Char, /* */ 32);
                                    destination.get_Item(((2 + imaginaryChars) | 0)).$v = TChar.System$Numerics$INumberBase$$$CreateTruncating($.$spc.System.Char, /*>*/ 62);
                                    charsWritten.$v = ((((realChars + imaginaryChars) | 0) + 4) | 0);
                                    return true;
                                }
                            }
                        }
                    }
                }
                charsWritten.$v = 0;
                return false;
            }
            static /*Complex */ Parse$3(/*ReadOnlySpan<char>*/ s, /*IFormatProvider?*/ provider)
            {
                return $.$srn.System.Numerics.Complex.Parse(s, 231/*DefaultNumberStyle*/, provider);
            }
            static /*bool */ TryParse$3(/*ReadOnlySpan<char>*/ s, /*IFormatProvider?*/ provider, /*out Complex*/ result)
            {
                return $.$srn.System.Numerics.Complex.TryParse(s, 231/*DefaultNumberStyle*/, provider, result);
            }
            static /*Complex */ op_UnaryPlus(/*Complex*/ value)
            {
                return value;
            }
            //Generated interface implemetation for System.Numerics.INumberBase<System.Numerics.Complex>.CreateChecked<TOther>(TOther)
            static System$Numerics$INumberBase$$$CreateChecked()
            {
                return $.$srn.System.Numerics.Complex.CreateChecked(...arguments);
            }
            //Generated interface implemetation for System.Numerics.INumberBase<System.Numerics.Complex>.CreateSaturating<TOther>(TOther)
            static System$Numerics$INumberBase$$$CreateSaturating()
            {
                return $.$srn.System.Numerics.Complex.CreateSaturating(...arguments);
            }
            //Generated interface implemetation for System.Numerics.INumberBase<System.Numerics.Complex>.CreateTruncating<TOther>(TOther)
            static System$Numerics$INumberBase$$$CreateTruncating()
            {
                return $.$srn.System.Numerics.Complex.CreateTruncating(...arguments);
            }
            //Generated interface implemetation for System.Numerics.INumberBase<System.Numerics.Complex>.IsComplexNumber(System.Numerics.Complex)
            static System$Numerics$INumberBase$$$IsComplexNumber()
            {
                return $.$srn.System.Numerics.Complex.IsComplexNumber(...arguments);
            }
            //Generated interface implemetation for System.Numerics.INumberBase<System.Numerics.Complex>.IsEvenInteger(System.Numerics.Complex)
            static System$Numerics$INumberBase$$$IsEvenInteger()
            {
                return $.$srn.System.Numerics.Complex.IsEvenInteger(...arguments);
            }
            //Generated interface implemetation for System.Numerics.INumberBase<System.Numerics.Complex>.IsFinite(System.Numerics.Complex)
            static System$Numerics$INumberBase$$$IsFinite()
            {
                return $.$srn.System.Numerics.Complex.IsFinite(...arguments);
            }
            //Generated interface implemetation for System.Numerics.INumberBase<System.Numerics.Complex>.IsImaginaryNumber(System.Numerics.Complex)
            static System$Numerics$INumberBase$$$IsImaginaryNumber()
            {
                return $.$srn.System.Numerics.Complex.IsImaginaryNumber(...arguments);
            }
            //Generated interface implemetation for System.Numerics.INumberBase<System.Numerics.Complex>.IsInfinity(System.Numerics.Complex)
            static System$Numerics$INumberBase$$$IsInfinity()
            {
                return $.$srn.System.Numerics.Complex.IsInfinity(...arguments);
            }
            //Generated interface implemetation for System.Numerics.INumberBase<System.Numerics.Complex>.IsInteger(System.Numerics.Complex)
            static System$Numerics$INumberBase$$$IsInteger()
            {
                return $.$srn.System.Numerics.Complex.IsInteger(...arguments);
            }
            //Generated interface implemetation for System.Numerics.INumberBase<System.Numerics.Complex>.IsNaN(System.Numerics.Complex)
            static System$Numerics$INumberBase$$$IsNaN()
            {
                return $.$srn.System.Numerics.Complex.IsNaN(...arguments);
            }
            //Generated interface implemetation for System.Numerics.INumberBase<System.Numerics.Complex>.IsNegative(System.Numerics.Complex)
            static System$Numerics$INumberBase$$$IsNegative()
            {
                return $.$srn.System.Numerics.Complex.IsNegative(...arguments);
            }
            //Generated interface implemetation for System.Numerics.INumberBase<System.Numerics.Complex>.IsNegativeInfinity(System.Numerics.Complex)
            static System$Numerics$INumberBase$$$IsNegativeInfinity()
            {
                return $.$srn.System.Numerics.Complex.IsNegativeInfinity(...arguments);
            }
            //Generated interface implemetation for System.Numerics.INumberBase<System.Numerics.Complex>.IsNormal(System.Numerics.Complex)
            static System$Numerics$INumberBase$$$IsNormal()
            {
                return $.$srn.System.Numerics.Complex.IsNormal(...arguments);
            }
            //Generated interface implemetation for System.Numerics.INumberBase<System.Numerics.Complex>.IsOddInteger(System.Numerics.Complex)
            static System$Numerics$INumberBase$$$IsOddInteger()
            {
                return $.$srn.System.Numerics.Complex.IsOddInteger(...arguments);
            }
            //Generated interface implemetation for System.Numerics.INumberBase<System.Numerics.Complex>.IsPositive(System.Numerics.Complex)
            static System$Numerics$INumberBase$$$IsPositive()
            {
                return $.$srn.System.Numerics.Complex.IsPositive(...arguments);
            }
            //Generated interface implemetation for System.Numerics.INumberBase<System.Numerics.Complex>.IsPositiveInfinity(System.Numerics.Complex)
            static System$Numerics$INumberBase$$$IsPositiveInfinity()
            {
                return $.$srn.System.Numerics.Complex.IsPositiveInfinity(...arguments);
            }
            //Generated interface implemetation for System.Numerics.INumberBase<System.Numerics.Complex>.IsRealNumber(System.Numerics.Complex)
            static System$Numerics$INumberBase$$$IsRealNumber()
            {
                return $.$srn.System.Numerics.Complex.IsRealNumber(...arguments);
            }
            //Generated interface implemetation for System.Numerics.INumberBase<System.Numerics.Complex>.IsSubnormal(System.Numerics.Complex)
            static System$Numerics$INumberBase$$$IsSubnormal()
            {
                return $.$srn.System.Numerics.Complex.IsSubnormal(...arguments);
            }
            //Generated interface implemetation for System.Numerics.INumberBase<System.Numerics.Complex>.MaxMagnitude(System.Numerics.Complex, System.Numerics.Complex)
            static System$Numerics$INumberBase$$$MaxMagnitude()
            {
                return $.$srn.System.Numerics.Complex.MaxMagnitude(...arguments);
            }
            //Generated interface implemetation for System.Numerics.INumberBase<System.Numerics.Complex>.MinMagnitude(System.Numerics.Complex, System.Numerics.Complex)
            static System$Numerics$INumberBase$$$MinMagnitude()
            {
                return $.$srn.System.Numerics.Complex.MinMagnitude(...arguments);
            }
            //Generated interface implemetation for System.Numerics.INumberBase<System.Numerics.Complex>.Parse(string, System.Globalization.NumberStyles, System.IFormatProvider?)
            static System$Numerics$INumberBase$$$Parse()
            {
                return $.$srn.System.Numerics.Complex.Parse$1(...arguments);
            }
            //Generated interface implemetation for System.Numerics.INumberBase<System.Numerics.Complex>.Parse(System.ReadOnlySpan<char>, System.Globalization.NumberStyles, System.IFormatProvider?)
            static System$Numerics$INumberBase$$$Parse$1()
            {
                return $.$srn.System.Numerics.Complex.Parse(...arguments);
            }
            //Generated interface implemetation for System.Numerics.INumberBase<System.Numerics.Complex>.TryParse(string?, System.Globalization.NumberStyles, System.IFormatProvider?, out System.Numerics.Complex)
            static System$Numerics$INumberBase$$$TryParse()
            {
                return $.$srn.System.Numerics.Complex.TryParse$1(...arguments);
            }
            //Generated interface implemetation for System.Numerics.INumberBase<System.Numerics.Complex>.TryParse(System.ReadOnlySpan<char>, System.Globalization.NumberStyles, System.IFormatProvider?, out System.Numerics.Complex)
            static System$Numerics$INumberBase$$$TryParse$1()
            {
                return $.$srn.System.Numerics.Complex.TryParse(...arguments);
            }
            //Generated interface implemetation for System.Numerics.IAdditionOperators<System.Numerics.Complex, System.Numerics.Complex, System.Numerics.Complex>.operator +(System.Numerics.Complex, System.Numerics.Complex)
            static System$Numerics$IAdditionOperators$$$$$op_Addition()
            {
                return $.$srn.System.Numerics.Complex.op_Addition(...arguments);
            }
            //Generated interface implemetation for System.Numerics.IDecrementOperators<System.Numerics.Complex>.operator --(System.Numerics.Complex)
            static System$Numerics$IDecrementOperators$$$op_Decrement()
            {
                return $.$srn.System.Numerics.Complex.op_Decrement(...arguments);
            }
            //Generated interface implemetation for System.Numerics.IDivisionOperators<System.Numerics.Complex, System.Numerics.Complex, System.Numerics.Complex>.operator /(System.Numerics.Complex, System.Numerics.Complex)
            static System$Numerics$IDivisionOperators$$$$$op_Division()
            {
                return $.$srn.System.Numerics.Complex.op_Division(...arguments);
            }
            //Generated interface implemetation for System.IEquatable<System.Numerics.Complex>.Equals(System.Numerics.Complex)
            System$IEquatable$$$Equals()
            {
                return this.Equals$2(...arguments);
            }
            //Generated interface implemetation for System.Numerics.IEqualityOperators<System.Numerics.Complex, System.Numerics.Complex, bool>.operator ==(System.Numerics.Complex, System.Numerics.Complex)
            static System$Numerics$IEqualityOperators$$$$$op_Equality()
            {
                return $.$srn.System.Numerics.Complex.op_Equality(...arguments);
            }
            //Generated interface implemetation for System.Numerics.IEqualityOperators<System.Numerics.Complex, System.Numerics.Complex, bool>.operator !=(System.Numerics.Complex, System.Numerics.Complex)
            static System$Numerics$IEqualityOperators$$$$$op_Inequality()
            {
                return $.$srn.System.Numerics.Complex.op_Inequality(...arguments);
            }
            //Generated interface implemetation for System.Numerics.IIncrementOperators<System.Numerics.Complex>.operator ++(System.Numerics.Complex)
            static System$Numerics$IIncrementOperators$$$op_Increment()
            {
                return $.$srn.System.Numerics.Complex.op_Increment(...arguments);
            }
            //Generated interface implemetation for System.Numerics.IMultiplyOperators<System.Numerics.Complex, System.Numerics.Complex, System.Numerics.Complex>.operator *(System.Numerics.Complex, System.Numerics.Complex)
            static System$Numerics$IMultiplyOperators$$$$$op_Multiply()
            {
                return $.$srn.System.Numerics.Complex.op_Multiply(...arguments);
            }
            //Generated interface implemetation for System.ISpanFormattable.TryFormat(System.Span<char>, out int, System.ReadOnlySpan<char>, System.IFormatProvider?)
            System$ISpanFormattable$TryFormat()
            {
                return this.TryFormat(...arguments);
            }
            //Generated interface implemetation for System.IFormattable.ToString(string?, System.IFormatProvider?)
            System$IFormattable$ToString()
            {
                return this.ToString$3(...arguments);
            }
            //Generated interface implemetation for System.ISpanParsable<System.Numerics.Complex>.Parse(System.ReadOnlySpan<char>, System.IFormatProvider?)
            static System$ISpanParsable$$$Parse()
            {
                return $.$srn.System.Numerics.Complex.Parse$3(...arguments);
            }
            //Generated interface implemetation for System.ISpanParsable<System.Numerics.Complex>.TryParse(System.ReadOnlySpan<char>, System.IFormatProvider?, out System.Numerics.Complex)
            static System$ISpanParsable$$$TryParse()
            {
                return $.$srn.System.Numerics.Complex.TryParse$3(...arguments);
            }
            //Generated interface implemetation for System.IParsable<System.Numerics.Complex>.Parse(string, System.IFormatProvider?)
            static System$IParsable$$$Parse()
            {
                return $.$srn.System.Numerics.Complex.Parse$2(...arguments);
            }
            //Generated interface implemetation for System.IParsable<System.Numerics.Complex>.TryParse(string?, System.IFormatProvider?, out System.Numerics.Complex)
            static System$IParsable$$$TryParse()
            {
                return $.$srn.System.Numerics.Complex.TryParse$2(...arguments);
            }
            //Generated interface implemetation for System.Numerics.ISubtractionOperators<System.Numerics.Complex, System.Numerics.Complex, System.Numerics.Complex>.operator -(System.Numerics.Complex, System.Numerics.Complex)
            static System$Numerics$ISubtractionOperators$$$$$op_Subtraction()
            {
                return $.$srn.System.Numerics.Complex.op_Subtraction(...arguments);
            }
            //Generated interface implemetation for System.Numerics.IUnaryPlusOperators<System.Numerics.Complex, System.Numerics.Complex>.operator +(System.Numerics.Complex)
            static System$Numerics$IUnaryPlusOperators$$$$op_UnaryPlus()
            {
                return $.$srn.System.Numerics.Complex.op_UnaryPlus(...arguments);
            }
            //Generated interface implemetation for System.Numerics.IUnaryNegationOperators<System.Numerics.Complex, System.Numerics.Complex>.operator -(System.Numerics.Complex)
            static System$Numerics$IUnaryNegationOperators$$$$op_UnaryNegation()
            {
                return $.$srn.System.Numerics.Complex.op_UnaryNegation(...arguments);
            }
            //Generated interface implemetation for System.IUtf8SpanFormattable.TryFormat(System.Span<byte>, out int, System.ReadOnlySpan<char>, System.IFormatProvider?)
            System$IUtf8SpanFormattable$TryFormat()
            {
                return this.TryFormat$1(...arguments);
            }
            //default value type constructor
            $ctor$3()
            {
                return this;
            }
            Clone($copy)
            {
                let copy = $copy ?? new this.constructor();
                copy.m_real = this.m_real;
                copy.m_imaginary = this.m_imaginary;
                return copy;
            }
            //default member initializer
            constructor()
            {
                super();
                this.m_real = 0;
                this.m_imaginary = 0;
            }
            //Static Initializer
            static $sinit()
            {
                {
                    this.Zero = new $.$srn.System.Numerics.Complex().$ctor$2(0, 0);
                }
                {
                    this.One = new $.$srn.System.Numerics.Complex().$ctor$2(1, 0);
                }
                {
                    this.ImaginaryOne = new $.$srn.System.Numerics.Complex().$ctor$2(0, 1);
                }
                {
                    this.NaN = new $.$srn.System.Numerics.Complex().$ctor$2(Number.NaN/*double.NaN*/, Number.NaN/*double.NaN*/);
                }
                {
                    this.Infinity = new $.$srn.System.Numerics.Complex().$ctor$2(Number.POSITIVE_INFINITY/*double.PositiveInfinity*/, Number.POSITIVE_INFINITY/*double.PositiveInfinity*/);
                }
                {
                    this.s_sqrtRescaleThreshold = 1.7976931348623157E+308/*double.MaxValue*/ / (Math.sqrt(2) + 1);
                }
                {
                    this.s_asinOverflowThreshold = Math.sqrt(1.7976931348623157E+308/*double.MaxValue*/) / 2;
                }
                {
                    this.s_log2 = Math.log(2);
                }
            }
            static $h = 1092369;
            static $z = 16;
            static $f = 0b10000000000001010000001;
            static $k = 2;
            static $$md;
            static get $md() { return this.$$md ??= {"b":196609,"p":[{"p":1179649,"g":{"r":0,"d":0,"h":68720569105,"f":1},"n":"Real","d":1092369,"h":64425601809,"f":1},{"p":1179649,"g":{"r":0,"d":0,"h":77310503697,"f":1},"n":"Imaginary","d":1092369,"h":73015536401,"f":1},{"p":1179649,"g":{"r":0,"d":0,"h":85900438289,"f":1},"n":"Magnitude","d":1092369,"h":81605470993,"f":1},{"p":1179649,"g":{"r":0,"d":0,"h":94490372881,"f":1},"n":"Phase","d":1092369,"h":90195405585,"f":1},{"p":1092369,"g":{"r":0,"d":0,"h":442382723857,"f":34},"n":"{$.$spc.System.Numerics.IAdditiveIdentity$$$($.$srn.System.Numerics.Complex, $.$srn.System.Numerics.Complex).$h}.AdditiveIdentity","o":"System$Numerics$IAdditiveIdentity$$$$AdditiveIdentity","d":1092369,"h":438087756561,"f":34},{"p":1092369,"g":{"r":0,"d":0,"h":459562593041,"f":34},"n":"{$.$spc.System.Numerics.IMultiplicativeIdentity$$$($.$srn.System.Numerics.Complex, $.$srn.System.Numerics.Complex).$h}.MultiplicativeIdentity","o":"System$Numerics$IMultiplicativeIdentity$$$$MultiplicativeIdentity","d":1092369,"h":455267625745,"f":34},{"p":1092369,"g":{"r":0,"d":0,"h":468152527633,"f":34},"n":"{$.$spc.System.Numerics.INumberBase$$($.$srn.System.Numerics.Complex).$h}.One","o":"System$Numerics$INumberBase$$$One","d":1092369,"h":463857560337,"f":34},{"p":655361,"g":{"r":0,"d":0,"h":476742462225,"f":34},"n":"{$.$spc.System.Numerics.INumberBase$$($.$srn.System.Numerics.Complex).$h}.Radix","o":"System$Numerics$INumberBase$$$Radix","d":1092369,"h":472447494929,"f":34},{"p":1092369,"g":{"r":0,"d":0,"h":485332396817,"f":34},"n":"{$.$spc.System.Numerics.INumberBase$$($.$srn.System.Numerics.Complex).$h}.Zero","o":"System$Numerics$INumberBase$$$Zero","d":1092369,"h":481037429521,"f":34},{"p":1092369,"g":{"r":0,"d":0,"h":648541154065,"f":34},"n":"{$.$spc.System.Numerics.ISignedNumber$$($.$srn.System.Numerics.Complex).$h}.NegativeOne","o":"System$Numerics$ISignedNumber$$$NegativeOne","d":1092369,"h":644246186769,"f":34}],"m":[{"r":1092369,"p":[{"n":"magnitude","p":1179649},{"n":"phase","p":1179649}],"n":"FromPolarCoordinates","d":1092369,"h":98785340177,"f":33},{"r":1092369,"p":[{"n":"value","p":1092369}],"n":"Negate","d":1092369,"h":103080307473,"f":33},{"r":1092369,"p":[{"n":"left","p":1092369},{"n":"right","p":1092369}],"n":"Add","d":1092369,"h":107375274769,"f":33},{"r":1092369,"p":[{"n":"left","p":1092369},{"n":"right","p":1179649}],"n":"Add","o":"@$1","d":1092369,"h":111670242065,"f":33},{"r":1092369,"p":[{"n":"left","p":1179649},{"n":"right","p":1092369}],"n":"Add","o":"@$2","d":1092369,"h":115965209361,"f":33},{"r":1092369,"p":[{"n":"left","p":1092369},{"n":"right","p":1092369}],"n":"Subtract","d":1092369,"h":120260176657,"f":33},{"r":1092369,"p":[{"n":"left","p":1092369},{"n":"right","p":1179649}],"n":"Subtract","o":"@$1","d":1092369,"h":124555143953,"f":33},{"r":1092369,"p":[{"n":"left","p":1179649},{"n":"right","p":1092369}],"n":"Subtract","o":"@$2","d":1092369,"h":128850111249,"f":33},{"r":1092369,"p":[{"n":"left","p":1092369},{"n":"right","p":1092369}],"n":"Multiply","d":1092369,"h":133145078545,"f":33},{"r":1092369,"p":[{"n":"left","p":1092369},{"n":"right","p":1179649}],"n":"Multiply","o":"@$1","d":1092369,"h":137440045841,"f":33},{"r":1092369,"p":[{"n":"left","p":1179649},{"n":"right","p":1092369}],"n":"Multiply","o":"@$2","d":1092369,"h":141735013137,"f":33},{"r":1092369,"p":[{"n":"dividend","p":1092369},{"n":"divisor","p":1092369}],"n":"Divide","d":1092369,"h":146029980433,"f":33},{"r":1092369,"p":[{"n":"dividend","p":1092369},{"n":"divisor","p":1179649}],"n":"Divide","o":"@$1","d":1092369,"h":150324947729,"f":33},{"r":1092369,"p":[{"n":"dividend","p":1179649},{"n":"divisor","p":1092369}],"n":"Divide","o":"@$2","d":1092369,"h":154619915025,"f":33},{"r":1179649,"p":[{"n":"value","p":1092369}],"n":"Abs","d":1092369,"h":214749457169,"f":33},{"r":1179649,"p":[{"n":"x","p":1179649}],"n":"Log1P","d":1092369,"h":219044424465,"f":34},{"r":1092369,"p":[{"n":"value","p":1092369}],"n":"Conjugate","d":1092369,"h":223339391761,"f":33},{"r":1092369,"p":[{"n":"value","p":1092369}],"n":"Reciprocal","d":1092369,"h":227634359057,"f":33},{"r":262145,"p":[{"n":"obj","p":131073}],"n":"Equals","d":1092369,"h":240519260945,"f":32769},{"r":262145,"p":[{"n":"value","p":1092369}],"n":"Equals","o":"@$2","d":1092369,"h":244814228241,"f":1},{"r":655361,"n":"GetHashCode","d":1092369,"h":249109195537,"f":32769},{"r":1310721,"n":"ToString","d":1092369,"h":253404162833,"f":32769},{"r":1310721,"p":[{"n":"format","p":1310721}],"n":"ToString","o":"@$1","d":1092369,"h":257699130129,"f":1},{"r":1310721,"p":[{"n":"provider","p":57671681}],"n":"ToString","o":"@$2","d":1092369,"h":261994097425,"f":1},{"r":1310721,"p":[{"n":"format","p":1310721},{"n":"provider","p":57671681}],"n":"ToString","o":"@$3","d":1092369,"h":266289064721,"f":1},{"r":1092369,"p":[{"n":"value","p":1092369}],"n":"Sin","d":1092369,"h":270584032017,"f":33},{"r":1092369,"p":[{"n":"value","p":1092369}],"n":"Sinh","d":1092369,"h":274878999313,"f":33},{"r":1092369,"p":[{"n":"value","p":1092369}],"n":"Asin","d":1092369,"h":279173966609,"f":33},{"r":1092369,"p":[{"n":"value","p":1092369}],"n":"Cos","d":1092369,"h":283468933905,"f":33},{"r":1092369,"p":[{"n":"value","p":1092369}],"n":"Cosh","d":1092369,"h":287763901201,"f":33},{"r":1092369,"p":[{"n":"value","p":1092369}],"n":"Acos","d":1092369,"h":292058868497,"f":33},{"r":1092369,"p":[{"n":"value","p":1092369}],"n":"Tan","d":1092369,"h":296353835793,"f":33},{"r":1092369,"p":[{"n":"value","p":1092369}],"n":"Tanh","d":1092369,"h":300648803089,"f":33},{"r":1092369,"p":[{"n":"value","p":1092369}],"n":"Atan","d":1092369,"h":304943770385,"f":33},{"r":65537,"p":[{"n":"x","p":1179649},{"n":"y","p":1179649},{"n":"b","p":1179649,"f":2},{"n":"bPrime","p":1179649,"f":2},{"n":"v","p":1179649,"f":2}],"n":"Asin_Internal","d":1092369,"h":309238737681,"f":34},{"r":262145,"p":[{"n":"value","p":1092369}],"n":"IsFinite","d":1092369,"h":313533704977,"f":33},{"r":262145,"p":[{"n":"value","p":1092369}],"n":"IsInfinity","d":1092369,"h":317828672273,"f":33},{"r":262145,"p":[{"n":"value","p":1092369}],"n":"IsNaN","d":1092369,"h":322123639569,"f":33},{"r":1092369,"p":[{"n":"value","p":1092369}],"n":"Log","d":1092369,"h":326418606865,"f":33},{"r":1092369,"p":[{"n":"value","p":1092369},{"n":"baseValue","p":1179649}],"n":"Log","o":"@$1","d":1092369,"h":330713574161,"f":33},{"r":1092369,"p":[{"n":"value","p":1092369}],"n":"Log10","d":1092369,"h":335008541457,"f":33},{"r":1092369,"p":[{"n":"value","p":1092369}],"n":"Exp","d":1092369,"h":339303508753,"f":33},{"r":1092369,"p":[{"n":"value","p":1092369}],"n":"Sqrt","d":1092369,"h":343598476049,"f":33},{"r":1092369,"p":[{"n":"value","p":1092369},{"n":"power","p":1092369}],"n":"Pow","d":1092369,"h":347893443345,"f":33},{"r":1092369,"p":[{"n":"value","p":1092369},{"n":"power","p":1179649}],"n":"Pow","o":"@$1","d":1092369,"h":352188410641,"f":33},{"r":1092369,"p":[{"n":"value","p":1092369},{"n":"factor","p":1179649}],"n":"Scale","d":1092369,"h":356483377937,"f":34},{"r":1092369,"p":[{"n":"value","p":(TOther) => TOther.$h}],"g":["TOther"],"n":"CreateChecked","d":1092369,"h":493922331409,"f":131105},{"r":1092369,"p":[{"n":"value","p":(TOther) => TOther.$h}],"g":["TOther"],"n":"CreateSaturating","d":1092369,"h":498217298705,"f":131105},{"r":1092369,"p":[{"n":"value","p":(TOther) => TOther.$h}],"g":["TOther"],"n":"CreateTruncating","d":1092369,"h":502512266001,"f":131105},{"r":262145,"p":[{"n":"value","p":1092369}],"n":"IsComplexNumber","d":1092369,"h":511102200593,"f":33},{"r":262145,"p":[{"n":"value","p":1092369}],"n":"IsEvenInteger","d":1092369,"h":515397167889,"f":33},{"r":262145,"p":[{"n":"value","p":1092369}],"n":"IsImaginaryNumber","d":1092369,"h":519692135185,"f":33},{"r":262145,"p":[{"n":"value","p":1092369}],"n":"IsInteger","d":1092369,"h":523987102481,"f":33},{"r":262145,"p":[{"n":"value","p":1092369}],"n":"IsNegative","d":1092369,"h":528282069777,"f":33},{"r":262145,"p":[{"n":"value","p":1092369}],"n":"IsNegativeInfinity","d":1092369,"h":532577037073,"f":33},{"r":262145,"p":[{"n":"value","p":1092369}],"n":"IsNormal","d":1092369,"h":536872004369,"f":33},{"r":262145,"p":[{"n":"value","p":1092369}],"n":"IsOddInteger","d":1092369,"h":541166971665,"f":33},{"r":262145,"p":[{"n":"value","p":1092369}],"n":"IsPositive","d":1092369,"h":545461938961,"f":33},{"r":262145,"p":[{"n":"value","p":1092369}],"n":"IsPositiveInfinity","d":1092369,"h":549756906257,"f":33},{"r":262145,"p":[{"n":"value","p":1092369}],"n":"IsRealNumber","d":1092369,"h":554051873553,"f":33},{"r":262145,"p":[{"n":"value","p":1092369}],"n":"IsSubnormal","d":1092369,"h":558346840849,"f":33},{"r":1092369,"p":[{"n":"x","p":1092369},{"n":"y","p":1092369}],"n":"MaxMagnitude","d":1092369,"h":566936775441,"f":33},{"r":1092369,"p":[{"n":"x","p":1092369},{"n":"y","p":1092369}],"n":"MinMagnitude","d":1092369,"h":575526710033,"f":33},{"r":1092369,"p":[{"n":"s","p":$.$spc.System.ReadOnlySpan$$($.$spc.System.Char).$h},{"n":"style","p":54067201},{"n":"provider","p":57671681}],"n":"Parse","d":1092369,"h":588411611921,"f":33},{"r":1092369,"p":[{"n":"s","p":1310721},{"n":"style","p":54067201},{"n":"provider","p":57671681}],"n":"Parse","o":"@$1","d":1092369,"h":592706579217,"f":33},{"r":262145,"p":[{"n":"value","p":(TOther) => TOther.$h},{"n":"result","p":1092369,"f":2}],"g":["TOther"],"n":"TryConvertFrom","d":1092369,"h":609886448401,"f":131106},{"r":262145,"p":[{"n":"s","p":$.$spc.System.ReadOnlySpan$$($.$spc.System.Char).$h},{"n":"style","p":54067201},{"n":"provider","p":57671681},{"n":"result","p":1092369,"f":2}],"n":"TryParse","d":1092369,"h":627066317585,"f":33},{"r":262145,"p":[{"n":"s","p":1310721},{"n":"style","p":54067201},{"n":"provider","p":57671681},{"n":"result","p":1092369,"f":2}],"n":"TryParse","o":"@$1","d":1092369,"h":631361284881,"f":33},{"r":1092369,"p":[{"n":"s","p":1310721},{"n":"provider","p":57671681}],"n":"Parse","o":"@$2","d":1092369,"h":635656252177,"f":33},{"r":262145,"p":[{"n":"s","p":1310721},{"n":"provider","p":57671681},{"n":"result","p":1092369,"f":2}],"n":"TryParse","o":"@$2","d":1092369,"h":639951219473,"f":33},{"r":262145,"p":[{"n":"destination","p":$.$spc.System.Span$$($.$spc.System.Char).$h},{"n":"charsWritten","p":655361,"f":2},{"n":"format","p":$.$spc.System.ReadOnlySpan$$($.$spc.System.Char).$h,"f":65},{"n":"provider","p":57671681,"f":65}],"n":"TryFormat","d":1092369,"h":652836121361,"f":1},{"r":262145,"p":[{"n":"utf8Destination","p":$.$spc.System.Span$$($.$spc.System.Byte).$h},{"n":"bytesWritten","p":655361,"f":2},{"n":"format","p":$.$spc.System.ReadOnlySpan$$($.$spc.System.Char).$h,"f":65},{"n":"provider","p":57671681,"f":65}],"n":"TryFormat","o":"@$1","d":1092369,"h":657131088657,"f":1},{"r":262145,"p":[{"n":"destination","p":(TChar) => $.$spc.System.Span$$(TChar).$h},{"n":"charsWritten","p":655361,"f":2},{"n":"format","p":$.$spc.System.ReadOnlySpan$$($.$spc.System.Char).$h},{"n":"provider","p":57671681}],"g":["TChar"],"n":"TryFormatCore","d":1092369,"h":661426055953,"f":131074},{"r":1092369,"p":[{"n":"s","p":$.$spc.System.ReadOnlySpan$$($.$spc.System.Char).$h},{"n":"provider","p":57671681}],"n":"Parse","o":"@$3","d":1092369,"h":665721023249,"f":33},{"r":262145,"p":[{"n":"s","p":$.$spc.System.ReadOnlySpan$$($.$spc.System.Char).$h},{"n":"provider","p":57671681},{"n":"result","p":1092369,"f":2}],"n":"TryParse","o":"@$3","d":1092369,"h":670015990545,"f":33}],"l":[{"t":54067201,"n":"DefaultNumberStyle","d":1092369,"h":4296059665,"f":34},{"t":54067201,"n":"InvalidNumberStyles","d":1092369,"h":8591026961,"f":34},{"t":1092369,"n":"Zero","d":1092369,"h":12885994257,"f":33},{"t":1092369,"n":"One","d":1092369,"h":17180961553,"f":33},{"t":1092369,"n":"ImaginaryOne","d":1092369,"h":21475928849,"f":33},{"t":1092369,"n":"NaN","d":1092369,"h":25770896145,"f":33},{"t":1092369,"n":"Infinity","d":1092369,"h":30065863441,"f":33},{"t":1179649,"n":"InverseOfLog10","d":1092369,"h":34360830737,"f":34},{"t":1179649,"n":"s_sqrtRescaleThreshold","d":1092369,"h":38655798033,"f":34},{"t":1179649,"n":"s_asinOverflowThreshold","d":1092369,"h":42950765329,"f":34},{"t":1179649,"n":"s_log2","d":1092369,"h":47245732625,"f":34},{"t":1179649,"n":"m_real","d":1092369,"h":51540699921,"f":2},{"t":1179649,"n":"m_imaginary","d":1092369,"h":55835667217,"f":2}],"c":[{"p":[{"n":"real","p":1179649},{"n":"imaginary","p":1179649}],"n":".ctor","o":"$ctor$2","d":1092369,"h":60130634513,"f":1},{"n":".ctor","o":"$ctor$3","d":1092369,"h":678605925137,"f":1}],"i":[$.$spc.System.Numerics.ISignedNumber$$($.$srn.System.Numerics.Complex).$h,$.$spc.System.Numerics.INumberBase$$($.$srn.System.Numerics.Complex).$h,$.$spc.System.Numerics.IAdditionOperators$$$$($.$srn.System.Numerics.Complex, $.$srn.System.Numerics.Complex, $.$srn.System.Numerics.Complex).$h,$.$spc.System.Numerics.IAdditiveIdentity$$$($.$srn.System.Numerics.Complex, $.$srn.System.Numerics.Complex).$h,$.$spc.System.Numerics.IDecrementOperators$$($.$srn.System.Numerics.Complex).$h,$.$spc.System.Numerics.IDivisionOperators$$$$($.$srn.System.Numerics.Complex, $.$srn.System.Numerics.Complex, $.$srn.System.Numerics.Complex).$h,$.$spc.System.IEquatable$$($.$srn.System.Numerics.Complex).$h,$.$spc.System.Numerics.IEqualityOperators$$$$($.$srn.System.Numerics.Complex, $.$srn.System.Numerics.Complex, $.$spc.System.Boolean).$h,$.$spc.System.Numerics.IIncrementOperators$$($.$srn.System.Numerics.Complex).$h,$.$spc.System.Numerics.IMultiplicativeIdentity$$$($.$srn.System.Numerics.Complex, $.$srn.System.Numerics.Complex).$h,$.$spc.System.Numerics.IMultiplyOperators$$$$($.$srn.System.Numerics.Complex, $.$srn.System.Numerics.Complex, $.$srn.System.Numerics.Complex).$h,63832065,57737217,$.$spc.System.ISpanParsable$$($.$srn.System.Numerics.Complex).$h,$.$spc.System.IParsable$$($.$srn.System.Numerics.Complex).$h,$.$spc.System.Numerics.ISubtractionOperators$$$$($.$srn.System.Numerics.Complex, $.$srn.System.Numerics.Complex, $.$srn.System.Numerics.Complex).$h,$.$spc.System.Numerics.IUnaryPlusOperators$$$($.$srn.System.Numerics.Complex, $.$srn.System.Numerics.Complex).$h,$.$spc.System.Numerics.IUnaryNegationOperators$$$($.$srn.System.Numerics.Complex, $.$srn.System.Numerics.Complex).$h,$.$spc.System.IUtf8SpanParsable$$($.$srn.System.Numerics.Complex).$h,64159745],"h":1092369,"a":[{"t":118226945,"c":4413194241},{"t":96272385,"c":4391239681,"a":[{"v":"System.Numerics, Version=4.0.0.0, Culture=neutral, PublicKeyToken=b77a5c561934e089","t":1310721}]}]}; }
            static get $b() { return $.$spc.System.ValueType; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.Numerics.ISignedNumber$$($.$srn.System.Numerics.Complex), $.$spc.System.Numerics.INumberBase$$($.$srn.System.Numerics.Complex), $.$spc.System.Numerics.IAdditionOperators$$$$($.$srn.System.Numerics.Complex, $.$srn.System.Numerics.Complex, $.$srn.System.Numerics.Complex), $.$spc.System.Numerics.IAdditiveIdentity$$$($.$srn.System.Numerics.Complex, $.$srn.System.Numerics.Complex), $.$spc.System.Numerics.IDecrementOperators$$($.$srn.System.Numerics.Complex), $.$spc.System.Numerics.IDivisionOperators$$$$($.$srn.System.Numerics.Complex, $.$srn.System.Numerics.Complex, $.$srn.System.Numerics.Complex), $.$spc.System.IEquatable$$($.$srn.System.Numerics.Complex), $.$spc.System.Numerics.IEqualityOperators$$$$($.$srn.System.Numerics.Complex, $.$srn.System.Numerics.Complex, $.$spc.System.Boolean), $.$spc.System.Numerics.IIncrementOperators$$($.$srn.System.Numerics.Complex), $.$spc.System.Numerics.IMultiplicativeIdentity$$$($.$srn.System.Numerics.Complex, $.$srn.System.Numerics.Complex), $.$spc.System.Numerics.IMultiplyOperators$$$$($.$srn.System.Numerics.Complex, $.$srn.System.Numerics.Complex, $.$srn.System.Numerics.Complex), $.$spc.System.ISpanFormattable, $.$spc.System.IFormattable, $.$spc.System.ISpanParsable$$($.$srn.System.Numerics.Complex), $.$spc.System.IParsable$$($.$srn.System.Numerics.Complex), $.$spc.System.Numerics.ISubtractionOperators$$$$($.$srn.System.Numerics.Complex, $.$srn.System.Numerics.Complex, $.$srn.System.Numerics.Complex), $.$spc.System.Numerics.IUnaryPlusOperators$$$($.$srn.System.Numerics.Complex, $.$srn.System.Numerics.Complex), $.$spc.System.Numerics.IUnaryNegationOperators$$$($.$srn.System.Numerics.Complex, $.$srn.System.Numerics.Complex), $.$spc.System.IUtf8SpanParsable$$($.$srn.System.Numerics.Complex), $.$spc.System.IUtf8SpanFormattable ]; }
            static get $fullName() { return `System.Numerics.Complex`; }
        });
        
        $asm.$str("$srn.System.Numerics.BigInteger", ($self) => class BigInteger extends $.$spc.System.ValueType
        {
            /*uint*/ static kuMaskHighBit = 2147483648;
            /*int*/ static kcbitUint = 32;
            /*int*/ static kcbitUlong = 64;
            /*int*/ static DecimalScaleFactorMask = 16711680;
            static /*int */ get MaxLength()
            {
                return $.trunc($.$spc.System.Array.MaxLength / 32/*kcbitUint*/);
            }
            /*int*/  get _sign() { return this.$getField(0, 4); }
            /*int*/  set _sign(value) { this.$setField(0, 4, value); }
            /*uint[]?*/  get _bits() { return this.$getField(4, 4); }
            /*uint[]?*/  set _bits(value) { this.$setField(4, 4, value); }
            /*BigInteger*/ static s_bnMinInt;
            /*BigInteger*/ static s_bnOneInt;
            /*BigInteger*/ static s_bnZeroInt;
            /*BigInteger*/ static s_bnMinusOneInt;
            $ctor$2(/*int*/ value)
            {
                super.$ctor$1();
                {
                    if (value === -2147483648/*int.MinValue*/)
                    {
                        $.$srn.System.Numerics.BigInteger.s_bnMinInt.Clone(this);
                    }
                    else 
                    {
                        this._sign = value;
                        this._bits = null;
                    }
                    this.AssertValid();
                }
                return this;
            }
            $ctor$3(/*uint*/ value)
            {
                super.$ctor$1();
                {
                    if (value <= 2147483647/*int.MaxValue*/)
                    {
                        this._sign = (value | 0);
                        this._bits = null;
                    }
                    else 
                    {
                        this._sign = +1;
                        this._bits = $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$spc.System.UInt32), null, [1], null);
                        $.$spc.System.Array.$WriteT1.call(this._bits, value, 0);
                    }
                    this.AssertValid();
                }
                return this;
            }
            $ctor$4(/*long*/ value)
            {
                super.$ctor$1();
                {
                    if (BigInt(-2147483648/*int.MinValue*/) < value && value <= BigInt(2147483647/*int.MaxValue*/))
                    {
                        this._sign = $.$cast(value, $.$spc.System.Int32);
                        this._bits = null;
                    }
                    else if (value === BigInt(-2147483648/*int.MinValue*/))
                    {
                        $.$srn.System.Numerics.BigInteger.s_bnMinInt.Clone(this);
                    }
                    else 
                    {
                        /*ulong*/ let x;
                        if (value < 0n)
                        {
                            x = $.$cast(-value, $.$spc.System.UInt64);
                            this._sign = -1;
                        }
                        else 
                        {
                            x = $.$cast(value, $.$spc.System.UInt64);
                            this._sign = +1;
                        }
                        if (x <= BigInt(4294967295/*uint.MaxValue*/))
                        {
                            this._bits = $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$spc.System.UInt32), null, [1], null);
                            $.$spc.System.Array.$WriteT1.call(this._bits, $.$cast(x, $.$spc.System.UInt32), 0);
                        }
                        else 
                        {
                            this._bits = $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$spc.System.UInt32), null, [2], null);
                            $.$spc.System.Array.$WriteT1.call(this._bits, $.$cast(x, $.$spc.System.UInt32), 0);
                            $.$spc.System.Array.$WriteT1.call(this._bits, $.$cast((x >> BigInt(32/*kcbitUint*/)), $.$spc.System.UInt32), 1);
                        }
                    }
                    this.AssertValid();
                }
                return this;
            }
            $ctor$5(/*ulong*/ value)
            {
                super.$ctor$1();
                {
                    if (value <= BigInt(2147483647/*int.MaxValue*/))
                    {
                        this._sign = $.$cast(value, $.$spc.System.Int32);
                        this._bits = null;
                    }
                    else if (value <= BigInt(4294967295/*uint.MaxValue*/))
                    {
                        this._sign = +1;
                        this._bits = $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$spc.System.UInt32), null, [1], null);
                        $.$spc.System.Array.$WriteT1.call(this._bits, $.$cast(value, $.$spc.System.UInt32), 0);
                    }
                    else 
                    {
                        this._sign = +1;
                        this._bits = $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$spc.System.UInt32), null, [2], null);
                        $.$spc.System.Array.$WriteT1.call(this._bits, $.$cast(value, $.$spc.System.UInt32), 0);
                        $.$spc.System.Array.$WriteT1.call(this._bits, $.$cast((value >> BigInt(32/*kcbitUint*/)), $.$spc.System.UInt32), 1);
                    }
                    this.AssertValid();
                }
                return this;
            }
            $ctor$6(/*float*/ value)
            {
                this.$ctor$7($.$cast(value, $.$spc.System.Double));
                {
                }
                return this;
            }
            $ctor$7(/*double*/ value)
            {
                super.$ctor$1();
                {
                    if (!$.$spc.System.Double.IsFinite(value))
                    {
                        if ($.$spc.System.Double.IsInfinity(value))
                        {
                            throw new $.$spc.System.OverflowException().$ctor$14($.$srn.System.SR.Overflow_BigIntInfinity);
                        }
                        else 
                        {
                            throw new $.$spc.System.OverflowException().$ctor$14($.$srn.System.SR.Overflow_NotANumber);
                        }
                    }
                    this._sign = 0;
                    this._bits = null;
                    /*int*/ let sign, exp;
                    /*ulong*/ let man;
                    $.$srn.System.Numerics.NumericsHelpers.GetDoubleParts(value, $.$ref(() => sign, ($v) => sign = $v, $.$spc.System.Int32), $.$ref(() => exp, ($v) => exp = $v, $.$spc.System.Int32), $.$ref(() => man, ($v) => man = $v, $.$spc.System.UInt64), $.$discardRef());
                    $.$spc.System.Diagnostics.Debug.Assert$1(sign === +1 || sign === -1, "sign == +1 || sign == -1");
                    if (man === 0n)
                    {
                        $.$srn.System.Numerics.BigInteger.Zero.Clone(this);
                        return this;
                    }
                    $.$spc.System.Diagnostics.Debug.Assert$1(man < (BigInt.asUintN(64, 1n << 53n)), "man < (1UL << 53)");
                    $.$spc.System.Diagnostics.Debug.Assert$1(exp <= 0 || man >= (BigInt.asUintN(64, 1n << 52n)), "exp <= 0 || man >= (1UL << 52)");
                    if (exp <= 0)
                    {
                        if (exp <= -64/*kcbitUlong*/)
                        {
                            $.$srn.System.Numerics.BigInteger.Zero.Clone(this);
                            return this;
                        }
                        $.$srn.System.Numerics.BigInteger.op_Implicit$10(man >> BigInt(-exp)).Clone(this);
                        if (sign < 0)
                        {
                            this._sign = -this._sign;
                        }
                    }
                    else if (exp <= 11)
                    {
                        $.$srn.System.Numerics.BigInteger.op_Implicit$10(BigInt.asUintN(64, man << BigInt(exp))).Clone(this);
                        if (sign < 0)
                        {
                            this._sign = -this._sign;
                        }
                    }
                    else 
                    {
                        man <<= 11n;
                        exp -= 11;
                        /*int*/ let cu = (($.trunc((((exp - 1) | 0)) / 32/*kcbitUint*/) + 1) | 0);
                        /*int*/ let cbit = ((((cu * 32/*kcbitUint*/) | 0) - exp) | 0);
                        $.$spc.System.Diagnostics.Debug.Assert$1(0 <= cbit && cbit < 32/*kcbitUint*/, "0 <= cbit && cbit < kcbitUint");
                        $.$spc.System.Diagnostics.Debug.Assert$1(cu >= 1, "cu >= 1");
                        this._bits = $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$spc.System.UInt32), null, [((cu + 2) | 0)], null);
                        $.$spc.System.Array.$WriteT1.call(this._bits, $.$cast((man >> BigInt((((cbit + 32/*kcbitUint*/) | 0)))), $.$spc.System.UInt32), ((cu + 1) | 0));
                        $.$spc.System.Array.$WriteT1.call(this._bits, $.$cast((man >> BigInt(cbit)), $.$spc.System.UInt32), cu);
                        if (cbit > 0)
                        {
                            $.$spc.System.Array.$WriteT1.call(this._bits, ($.$cast(man, $.$spc.System.UInt32) << (((32/*kcbitUint*/ - cbit) | 0))) >>> 0, ((cu - 1) | 0));
                        }
                        this._sign = sign;
                    }
                    this.AssertValid();
                }
                return this;
            }
            $ctor$8(/*decimal*/ value)
            {
                super.$ctor$1();
                {
                    /*Span<int>*/ let bits = $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.StackAllocSpan($.$spc.System.Int32, 4, null);
                    $.$spc.System.Decimal.GetBits$1($.$spc.System.Decimal.Truncate(value), bits);
                    $.$spc.System.Diagnostics.Debug.Assert$1(bits.Length === 4 && (bits.get_Item(3).$v & 16711680/*DecimalScaleFactorMask*/) === 0, "bits.Length == 4 && (bits[3] & DecimalScaleFactorMask) == 0");
                    /*int*/ let signMask = (2147483648/*kuMaskHighBit*/ | 0);
                    /*int*/ let size = 3;
                    while(size > 0 && bits.get_Item(((size - 1) | 0)).$v === 0)
                    {
                        size--;
                    }
                    if (size === 0)
                    {
                        $.$srn.System.Numerics.BigInteger.s_bnZeroInt.Clone(this);
                    }
                    else if (size === 1 && bits.get_Item(0).$v > 0)
                    {
                        this._sign = bits.get_Item(0).$v;
                        this._sign *= ((bits.get_Item(3).$v & signMask) !== 0) ? -1 : +1;
                        this._bits = null;
                    }
                    else 
                    {
                        this._bits = $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$spc.System.UInt32), null, [size], null);
                        //unchecked
                        {
                            this._bits[0] = (bits.get_Item(0).$v >>> 0);
                            if (size > 1)
                            {
                                this._bits[1] = (bits.get_Item(1).$v >>> 0);
                            }
                            if (size > 2)
                            {
                                this._bits[2] = (bits.get_Item(2).$v >>> 0);
                            }
                        }
                        this._sign = ((bits.get_Item(3).$v & signMask) !== 0) ? -1 : +1;
                    }
                    this.AssertValid();
                }
                return this;
            }
            $ctor$9(/*byte[]*/ value)
            {
                this.$ctor$10(new ($.$spc.System.ReadOnlySpan$$($.$spc.System.Byte))().$ctor$2($.$firstOf(value, () => { throw new $.$spc.System.ArgumentNullException().$ctor$16("value") })), false, false);
                {
                }
                return this;
            }
            $ctor$10(/*ReadOnlySpan<byte>*/ value, /*bool*/ isUnsigned, /*bool*/ isBigEndian)
            {
                super.$ctor$1();
                {
                    /*int*/ let byteCount = value.Length;
                    /*bool*/ let isNegative;
                    if (byteCount > 0)
                    {
                        /*byte*/ let mostSignificantByte = isBigEndian ? value.get_Item(0).$v : value.get_Item(((byteCount - 1) | 0)).$v;
                        isNegative = (mostSignificantByte & 128) !== 0 && !isUnsigned;
                        if (mostSignificantByte === 0)
                        {
                            if (isBigEndian)
                            {
                                /*int*/ let offset = 1;
                                while(offset < byteCount && value.get_Item(offset).$v === 0)
                                {
                                    offset++;
                                }
                                value = value.Slice(offset);
                                byteCount = value.Length;
                            }
                            else 
                            {
                                byteCount -= 2;
                                while(byteCount >= 0 && value.get_Item(byteCount).$v === 0)
                                {
                                    byteCount--;
                                }
                                byteCount++;
                            }
                        }
                    }
                    else 
                    {
                        isNegative = false;
                    }
                    if (byteCount === 0)
                    {
                        this._sign = 0;
                        this._bits = null;
                        this.AssertValid();
                        return this;
                    }
                    if (byteCount <= 4)
                    {
                        this._sign = isNegative ? (4294967295 | 0) : 0;
                        if (isBigEndian)
                        {
                            for(/*int*/ let i = 0; i < byteCount; i++)
                            {
                                this._sign = (this._sign << 8) | value.get_Item(i).$v;
                            }
                        }
                        else 
                        {
                            for(/*int*/ let i = ((byteCount - 1) | 0); i >= 0; i--)
                            {
                                this._sign = (this._sign << 8) | value.get_Item(i).$v;
                            }
                        }
                        this._bits = null;
                        if (this._sign < 0 && !isNegative)
                        {
                            this._bits = $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$spc.System.UInt32), [(this._sign >>> 0)], [1], null);
                            this._sign = +1;
                        }
                        if (this._sign === -2147483648/*int.MinValue*/)
                        {
                            $.$srn.System.Numerics.BigInteger.s_bnMinInt.Clone(this);
                        }
                    }
                    else 
                    {
                        /*int*/ let unalignedBytes;
                        /*int*/ let wholeUInt32Count = $.$spc.System.Math.DivRem(byteCount, 4, $.$ref(() => unalignedBytes, ($v) => unalignedBytes = $v, $.$spc.System.Int32));
                        /*uint[]*/ let val = $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$spc.System.UInt32), null, [((wholeUInt32Count + (unalignedBytes === 0 ? 0 : 1)) | 0)], null);
                        if (isBigEndian)
                        {
                            /*Span<byte>*/ let uintBytes = $.$spc.System.Runtime.InteropServices.MemoryMarshal.AsBytes($.$spc.System.UInt32, $.$spc.System.MemoryExtensions.AsSpan$9($.$spc.System.UInt32, val, 0, wholeUInt32Count));
                            value.Slice(unalignedBytes).CopyTo(uintBytes);
                            $.$spc.System.MemoryExtensions.Reverse($.$spc.System.Byte, uintBytes);
                        }
                        else 
                        {
                            value.Slice$1(0, ((wholeUInt32Count * 4) | 0)).CopyTo($.$spc.System.Runtime.InteropServices.MemoryMarshal.AsBytes($.$spc.System.UInt32, $.$spc.System.MemoryExtensions.AsSpan$8($.$spc.System.UInt32, val)));
                        }
                        if (!$.$spc.System.BitConverter.IsLittleEndian)
                        {
                            $.$spc.System.Buffers.Binary.BinaryPrimitives.ReverseEndianness$15($.$spc.System.Span$$($.$spc.System.UInt32).op_Implicit$2($.$spc.System.MemoryExtensions.AsSpan$9($.$spc.System.UInt32, val, 0, wholeUInt32Count)), $.$spc.System.Span$$($.$spc.System.UInt32).op_Implicit(val));
                        }
                        if (unalignedBytes !== 0)
                        {
                            if (isNegative)
                            {
                                $.$spc.System.Array.$WriteT1.call(val, 4294967295, wholeUInt32Count);
                            }
                            if (isBigEndian)
                            {
                                for(/*int*/ let curByte = 0; curByte < unalignedBytes; curByte++)
                                {
                                    /*byte*/ let curByteValue = value.get_Item(curByte).$v;
                                    $.$spc.System.Array.$WriteT1.call(val, (($.$spc.System.Array.$ReadT1.call(val, wholeUInt32Count) << 8) >>> 0) | curByteValue, wholeUInt32Count);
                                }
                            }
                            else 
                            {
                                for(/*int*/ let curByte = ((byteCount - 1) | 0); curByte >= ((byteCount - unalignedBytes) | 0); curByte--)
                                {
                                    /*byte*/ let curByteValue = value.get_Item(curByte).$v;
                                    $.$spc.System.Array.$WriteT1.call(val, (($.$spc.System.Array.$ReadT1.call(val, wholeUInt32Count) << 8) >>> 0) | curByteValue, wholeUInt32Count);
                                }
                            }
                        }
                        if (isNegative)
                        {
                            $.$srn.System.Numerics.NumericsHelpers.DangerousMakeTwosComplement($.$spc.System.Span$$($.$spc.System.UInt32).op_Implicit(val));
                            /*int*/ let len = ((val.length - 1) | 0);
                            while(len >= 0 && $.$spc.System.Array.$ReadT1.call(val, len) === 0)
                            {
                                len--;
                            }
                            len++;
                            if (len === 1)
                            {
                                let $switch2 = $.$spc.System.Array.$ReadT1.call(val, 0);
                                switch($switch2)
                                {
                                    case 1:
                                    $.$srn.System.Numerics.BigInteger.s_bnMinusOneInt.Clone(this);
                                    return this;
                                    case 2147483648/*kuMaskHighBit*/:
                                    $.$srn.System.Numerics.BigInteger.s_bnMinInt.Clone(this);
                                    return this;
                                    default:
                                    if ((val[0] | 0) > 0)
                                    {
                                        this._sign = (((-1) * (($.$spc.System.Array.$ReadT1.call(val, 0) | 0))) | 0);
                                        this._bits = null;
                                        this.AssertValid();
                                        return this;
                                    }
                                    break;
                                }
                            }
                            if (len !== val.length)
                            {
                                this._sign = -1;
                                this._bits = $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$spc.System.UInt32), null, [len], null);
                                $.$spc.System.Array.Copy(val, this._bits, len);
                            }
                            else 
                            {
                                this._sign = -1;
                                this._bits = val;
                            }
                        }
                        else 
                        {
                            this._sign = +1;
                            this._bits = val;
                        }
                    }
                    this.AssertValid();
                }
                return this;
            }
            $ctor$11(/*int*/ n, /*uint[]?*/ rgu)
            {
                super.$ctor$1();
                {
                    if ((!(rgu === null)) && (rgu.length > $.$srn.System.Numerics.BigInteger.MaxLength))
                    {
                        $.$srn.System.ThrowHelper.ThrowOverflowException();
                    }
                    this._sign = n;
                    this._bits = rgu;
                    this.AssertValid();
                }
                return this;
            }
            $ctor$12(/*ReadOnlySpan<uint>*/ value, /*bool*/ negative)
            {
                super.$ctor$1();
                {
                    /*int*/ let length = (($.$spc.System.MemoryExtensions.LastIndexOfAnyExcept$5($.$spc.System.UInt32, value, 0) + 1) | 0);
                    let $t1 = value;
                    value = $t1.Slice$1(0, length);
                    if (value.Length > $.$srn.System.Numerics.BigInteger.MaxLength)
                    {
                        $.$srn.System.ThrowHelper.ThrowOverflowException();
                    }
                    if (value.Length === 0)
                    {
                        new $.$srn.System.Numerics.BigInteger().Clone(this);
                    }
                    else if (value.Length === 1)
                    {
                        if (value.get_Item(0).$v < 2147483648/*kuMaskHighBit*/)
                        {
                            this._sign = negative ? -(value.get_Item(0).$v | 0) : (value.get_Item(0).$v | 0);
                            this._bits = null;
                        }
                        else if (negative && value.get_Item(0).$v === 2147483648/*kuMaskHighBit*/)
                        {
                            $.$srn.System.Numerics.BigInteger.s_bnMinInt.Clone(this);
                        }
                        else 
                        {
                            this._sign = negative ? -1 : +1;
                            this._bits = $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$spc.System.UInt32.$type, [ value.get_Item(0).$v ], null, null);
                        }
                    }
                    else 
                    {
                        this._sign = negative ? -1 : +1;
                        this._bits = value.ToArray();
                    }
                    this.AssertValid();
                }
                return this;
            }
            $ctor$13(/*Span<uint>*/ value)
            {
                super.$ctor$1();
                {
                    /*bool*/ let isNegative;
                    /*int*/ let length;
                    if ((value.Length > 0) && ((value.get_Item(value.Length - 1).$v | 0) < 0))
                    {
                        isNegative = true;
                        length = (($.$spc.System.MemoryExtensions.LastIndexOfAnyExcept$5($.$spc.System.UInt32, $.$spc.System.Span$$($.$spc.System.UInt32).op_Implicit$2(value), 4294967295/*uint.MaxValue*/) + 1) | 0);
                        if ((length === 0) || ((value.get_Item(((length - 1) | 0)).$v | 0) >= 0))
                        {
                            length++;
                        }
                        $.$spc.System.Diagnostics.Debug.Assert$1((value.get_Item(((length - 1) | 0)).$v | 0) < 0, "(int)value[length - 1] < 0");
                    }
                    else 
                    {
                        isNegative = false;
                        length = (($.$spc.System.MemoryExtensions.LastIndexOfAnyExcept$5($.$spc.System.UInt32, $.$spc.System.Span$$($.$spc.System.UInt32).op_Implicit$2(value), 0) + 1) | 0);
                    }
                    let $t1 = value;
                    value = $t1.Slice$1(0, length);
                    if (value.Length > $.$srn.System.Numerics.BigInteger.MaxLength)
                    {
                        $.$srn.System.ThrowHelper.ThrowOverflowException();
                    }
                    if (value.Length === 0)
                    {
                        $.$srn.System.Numerics.BigInteger.s_bnZeroInt.Clone(this);
                    }
                    else if (value.Length === 1)
                    {
                        if (isNegative)
                        {
                            if (value.get_Item(0).$v === 4294967295/*uint.MaxValue*/)
                            {
                                $.$srn.System.Numerics.BigInteger.s_bnMinusOneInt.Clone(this);
                            }
                            else if (value.get_Item(0).$v === 2147483648/*kuMaskHighBit*/)
                            {
                                $.$srn.System.Numerics.BigInteger.s_bnMinInt.Clone(this);
                            }
                            else 
                            {
                                this._sign = (value.get_Item(0).$v | 0);
                                this._bits = null;
                            }
                        }
                        else if ((value.get_Item(0).$v | 0) < 0)
                        {
                            this._sign = +1;
                            this._bits = $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$spc.System.UInt32.$type, [ value.get_Item(0).$v ], null, null);
                        }
                        else 
                        {
                            this._sign = (value.get_Item(0).$v | 0);
                            this._bits = null;
                        }
                    }
                    else 
                    {
                        if (isNegative)
                        {
                            $.$srn.System.Numerics.NumericsHelpers.DangerousMakeTwosComplement(value);
                            length = (($.$spc.System.MemoryExtensions.LastIndexOfAnyExcept$5($.$spc.System.UInt32, $.$spc.System.Span$$($.$spc.System.UInt32).op_Implicit$2(value), 0) + 1) | 0);
                            let $t2 = value;
                            value = $t2.Slice$1(0, length);
                            this._sign = -1;
                        }
                        else 
                        {
                            this._sign = +1;
                        }
                        this._bits = value.ToArray();
                    }
                    this.AssertValid();
                }
                return this;
            }
            static /*BigInteger */ get Zero()
            {
                return $.$srn.System.Numerics.BigInteger.s_bnZeroInt;
            }
            static /*BigInteger */ get One()
            {
                return $.$srn.System.Numerics.BigInteger.s_bnOneInt;
            }
            static /*BigInteger */ get MinusOne()
            {
                return $.$srn.System.Numerics.BigInteger.s_bnMinusOneInt;
            }
            /*bool */ get IsPowerOfTwo()
            {
                this.AssertValid();
                if (this._bits === null)
                {
                    return $.$spc.System.Numerics.BitOperations.IsPow2(this._sign);
                }
                if (this._sign !== 1)
                {
                    return false;
                }
                /*int*/ let iu = ((this._bits.length - 1) | 0);
                return $.$spc.System.Numerics.BitOperations.IsPow2$1($.$spc.System.Array.$ReadT1.call(this._bits, iu)) && !$.$spc.System.MemoryExtensions.ContainsAnyExcept$5($.$spc.System.UInt32, $.$spc.System.Span$$($.$spc.System.UInt32).op_Implicit$2($.$spc.System.MemoryExtensions.AsSpan$9($.$spc.System.UInt32, this._bits, 0, iu)), 0);
            }
            /*bool */ get IsZero()
            {
                this.AssertValid();
                return this._sign === 0;
            }
            /*bool */ get IsOne()
            {
                this.AssertValid();
                return this._sign === 1 && this._bits === null;
            }
            /*bool */ get IsEven()
            {
                this.AssertValid();
                return this._bits === null ? (this._sign & 1) === 0 : ($.$spc.System.Array.$ReadT1.call(this._bits, 0) & 1) === 0;
            }
            /*int */ get Sign()
            {
                this.AssertValid();
                return (((this._sign >> (((32/*kcbitUint*/ - 1) | 0))) - (-this._sign >> (((32/*kcbitUint*/ - 1) | 0)))) | 0);
            }
            static /*BigInteger */ Parse(/*string*/ value)
            {
                return $.$srn.System.Numerics.BigInteger.Parse$1(value, 7/*NumberStyles.Integer*/);
            }
            static /*BigInteger */ Parse$1(/*string*/ value, /*NumberStyles*/ style)
            {
                return $.$srn.System.Numerics.BigInteger.Parse$3(value, style, $.$spc.System.Globalization.NumberFormatInfo.CurrentInfo);
            }
            static /*BigInteger */ Parse$2(/*string*/ value, /*IFormatProvider?*/ provider)
            {
                return $.$srn.System.Numerics.BigInteger.Parse$3(value, 7/*NumberStyles.Integer*/, $.$spc.System.Globalization.NumberFormatInfo.GetInstance(provider));
            }
            static /*BigInteger */ Parse$3(/*string*/ value, /*NumberStyles*/ style, /*IFormatProvider?*/ provider)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(value, "value");
                return $.$srn.System.Numerics.BigInteger.Parse$4($.$spc.System.MemoryExtensions.AsSpan$3(value), style, $.$spc.System.Globalization.NumberFormatInfo.GetInstance(provider));
            }
            static /*bool */ TryParse(/*string?*/ value, /*out BigInteger*/ result)
            {
                return $.$srn.System.Numerics.BigInteger.TryParse$1(value, 7/*NumberStyles.Integer*/, $.$spc.System.Globalization.NumberFormatInfo.CurrentInfo, result);
            }
            static /*bool */ TryParse$1(/*string?*/ value, /*NumberStyles*/ style, /*IFormatProvider?*/ provider, /*out BigInteger*/ result)
            {
                return $.$srn.System.Numerics.BigInteger.TryParse$3($.$spc.System.MemoryExtensions.AsSpan$3(value), style, $.$spc.System.Globalization.NumberFormatInfo.GetInstance(provider), result);
            }
            static /*BigInteger */ Parse$4(/*ReadOnlySpan<char>*/ value, /*NumberStyles*/ style, /*IFormatProvider?*/ provider)
            {
                return $.$srn.System.Number.ParseBigInteger(value, style, $.$spc.System.Globalization.NumberFormatInfo.GetInstance(provider));
            }
            static /*bool */ TryParse$2(/*ReadOnlySpan<char>*/ value, /*out BigInteger*/ result)
            {
                return $.$srn.System.Numerics.BigInteger.TryParse$3(value, 7/*NumberStyles.Integer*/, $.$spc.System.Globalization.NumberFormatInfo.CurrentInfo, result);
            }
            static /*bool */ TryParse$3(/*ReadOnlySpan<char>*/ value, /*NumberStyles*/ style, /*IFormatProvider?*/ provider, /*out BigInteger*/ result)
            {
                return $.$srn.System.Number.TryParseBigInteger(value, style, $.$spc.System.Globalization.NumberFormatInfo.GetInstance(provider), result) === 0/*Number.ParsingStatus.OK*/;
            }
            static /*int */ Compare(/*BigInteger*/ left, /*BigInteger*/ right)
            {
                return left.CompareTo$2(right);
            }
            static /*BigInteger */ Abs(/*BigInteger*/ value)
            {
                return ($.$srn.System.Numerics.BigInteger.op_GreaterThanOrEqual(value, $.$srn.System.Numerics.BigInteger.Zero)) ? value : $.$srn.System.Numerics.BigInteger.op_UnaryNegation(value);
            }
            static /*BigInteger */ Add(/*BigInteger*/ left, /*BigInteger*/ right)
            {
                return $.$srn.System.Numerics.BigInteger.op_Addition(left, right);
            }
            static /*BigInteger */ Subtract(/*BigInteger*/ left, /*BigInteger*/ right)
            {
                return $.$srn.System.Numerics.BigInteger.op_Subtraction(left, right);
            }
            static /*BigInteger */ Multiply(/*BigInteger*/ left, /*BigInteger*/ right)
            {
                return $.$srn.System.Numerics.BigInteger.op_Multiply(left, right);
            }
            static /*BigInteger */ Divide(/*BigInteger*/ dividend, /*BigInteger*/ divisor)
            {
                return $.$srn.System.Numerics.BigInteger.op_Division(dividend, divisor);
            }
            static /*BigInteger */ Remainder(/*BigInteger*/ dividend, /*BigInteger*/ divisor)
            {
                return $.$srn.System.Numerics.BigInteger.op_Modulus(dividend, divisor);
            }
            static /*BigInteger */ DivRem(/*BigInteger*/ dividend, /*BigInteger*/ divisor, /*out BigInteger*/ remainder)
            {
                dividend.AssertValid();
                divisor.AssertValid();
                /*bool*/ let trivialDividend = dividend._bits === null;
                /*bool*/ let trivialDivisor = divisor._bits === null;
                if (trivialDividend && trivialDivisor)
                {
                    /*BigInteger*/ let quotient;
                    $.$tupleUnpack(($tp) =>
                    {
                        quotient = $tp.Item1;
                        remainder.$v = $tp.Item2;
                    }).$v = $.$spc.System.Math.DivRem$6(dividend._sign, divisor._sign);
                    return quotient;
                }
                if (trivialDividend)
                {
                    remainder.$v = dividend;
                    return $.$srn.System.Numerics.BigInteger.s_bnZeroInt;
                }
                $.$spc.System.Diagnostics.Debug.Assert$1(dividend._bits !== null, "dividend._bits != null");
                if (trivialDivisor)
                {
                    /*uint*/ let rest;
                    /*uint[]?*/ let bitsFromPool = null;
                    /*int*/ let size = dividend._bits.length;
                    /*Span<uint>*/ let quotient = (BigInt((size >>> 0)) <= BigInt($.$srn.System.Numerics.BigIntegerCalculator.StackAllocThreshold) ? $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.StackAllocSpan($.$spc.System.UInt32, $.$srn.System.Numerics.BigIntegerCalculator.StackAllocThreshold, null) : $.$spc.System.Span$$($.$spc.System.UInt32).op_Implicit(bitsFromPool = $.$spc.System.Buffers.ArrayPool$$($.$spc.System.UInt32).Shared.Rent(size))).Slice$1(0, size);
                    try
                    {
                        $.$srn.System.Numerics.BigIntegerCalculator.Divide($.$spc.System.ReadOnlySpan$$($.$spc.System.UInt32).op_Implicit(dividend._bits), $.$srn.System.Numerics.NumericsHelpers.Abs(divisor._sign), quotient, $.$ref(() => rest, ($v) => rest = $v, $.$spc.System.UInt32));
                        remainder.$v = $.$srn.System.Numerics.BigInteger.op_Implicit$4(dividend._sign < 0 ? BigInt(-1) * BigInt(rest) : BigInt(rest));
                        return new $.$srn.System.Numerics.BigInteger().$ctor$12($.$spc.System.Span$$($.$spc.System.UInt32).op_Implicit$2(quotient), $.$spc.System.Boolean.op_ExclusiveOr$1((dividend._sign < 0), (divisor._sign < 0)));
                    }
                    finally
                    {
                        {
                            if (bitsFromPool !== null)
                            {
                                $.$spc.System.Buffers.ArrayPool$$($.$spc.System.UInt32).Shared.Return(bitsFromPool, false);
                            }
                        }
                    }
                }
                $.$spc.System.Diagnostics.Debug.Assert$1(divisor._bits !== null, "divisor._bits != null");
                if (dividend._bits.length < divisor._bits.length)
                {
                    remainder.$v = dividend;
                    return $.$srn.System.Numerics.BigInteger.s_bnZeroInt;
                }
                else 
                {
                    /*uint[]?*/ let remainderFromPool = null;
                    /*int*/ let size = dividend._bits.length;
                    /*Span<uint>*/ let rest = (BigInt((size >>> 0)) <= BigInt($.$srn.System.Numerics.BigIntegerCalculator.StackAllocThreshold) ? $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.StackAllocSpan($.$spc.System.UInt32, $.$srn.System.Numerics.BigIntegerCalculator.StackAllocThreshold, null) : $.$spc.System.Span$$($.$spc.System.UInt32).op_Implicit(remainderFromPool = $.$spc.System.Buffers.ArrayPool$$($.$spc.System.UInt32).Shared.Rent(size))).Slice$1(0, size);
                    /*uint[]?*/ let quotientFromPool = null;
                    size = ((((dividend._bits.length - divisor._bits.length) | 0) + 1) | 0);
                    /*Span<uint>*/ let quotient = (BigInt((size >>> 0)) <= BigInt($.$srn.System.Numerics.BigIntegerCalculator.StackAllocThreshold) ? $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.StackAllocSpan($.$spc.System.UInt32, $.$srn.System.Numerics.BigIntegerCalculator.StackAllocThreshold, null) : $.$spc.System.Span$$($.$spc.System.UInt32).op_Implicit(quotientFromPool = $.$spc.System.Buffers.ArrayPool$$($.$spc.System.UInt32).Shared.Rent(size))).Slice$1(0, size);
                    $.$srn.System.Numerics.BigIntegerCalculator.Divide$3($.$spc.System.ReadOnlySpan$$($.$spc.System.UInt32).op_Implicit(dividend._bits), $.$spc.System.ReadOnlySpan$$($.$spc.System.UInt32).op_Implicit(divisor._bits), quotient, rest);
                    remainder.$v = new $.$srn.System.Numerics.BigInteger().$ctor$12($.$spc.System.Span$$($.$spc.System.UInt32).op_Implicit$2(rest), dividend._sign < 0);
                    /*var*/ let result = new $.$srn.System.Numerics.BigInteger().$ctor$12($.$spc.System.Span$$($.$spc.System.UInt32).op_Implicit$2(quotient), $.$spc.System.Boolean.op_ExclusiveOr$1((dividend._sign < 0), (divisor._sign < 0)));
                    if (remainderFromPool !== null)
                    {
                        $.$spc.System.Buffers.ArrayPool$$($.$spc.System.UInt32).Shared.Return(remainderFromPool, false);
                    }
                    if (quotientFromPool !== null)
                    {
                        $.$spc.System.Buffers.ArrayPool$$($.$spc.System.UInt32).Shared.Return(quotientFromPool, false);
                    }
                    return result;
                }
            }
            static /*BigInteger */ Negate(/*BigInteger*/ value)
            {
                return $.$srn.System.Numerics.BigInteger.op_UnaryNegation(value);
            }
            static /*double */ Log(/*BigInteger*/ value)
            {
                return $.$srn.System.Numerics.BigInteger.Log$1(value, 2.718281828459045/*Math.E*/);
            }
            static /*double */ Log$1(/*BigInteger*/ value, /*double*/ baseValue)
            {
                if (value._sign < 0 || baseValue === 1)
                {
                    return Number.NaN/*double.NaN*/;
                }
                if (baseValue === Number.POSITIVE_INFINITY/*double.PositiveInfinity*/)
                {
                    return value.IsOne ? 0 : Number.NaN/*double.NaN*/;
                }
                if (baseValue === 0 && !value.IsOne)
                {
                    return Number.NaN/*double.NaN*/;
                }
                if (value._bits === null)
                {
                    return $.$spc.System.Math.Log(value._sign, baseValue);
                }
                /*ulong*/ let h = BigInt($.$spc.System.Array.$ReadT1.call(value._bits, ((value._bits.length - 1) | 0)));
                /*ulong*/ let m = BigInt(value._bits.length > 1 ? $.$spc.System.Array.$ReadT1.call(value._bits, ((value._bits.length - 2) | 0)) : 0);
                /*ulong*/ let l = BigInt(value._bits.length > 2 ? $.$spc.System.Array.$ReadT1.call(value._bits, ((value._bits.length - 3) | 0)) : 0);
                /*int*/ let c = $.$spc.System.Numerics.BitOperations.LeadingZeroCount($.$cast(h, $.$spc.System.UInt32));
                /*long*/ let b = $.$cast(value._bits.length, $.$spc.System.Int64) * 32n - BigInt(c);
                /*ulong*/ let x = (BigInt.asUintN(64, h << BigInt(((32 + c) | 0)))) | (BigInt.asUintN(64, m << BigInt(c))) | (l >> BigInt(((32 - c) | 0)));
                return $.$spc.System.Math.Log(Number(x), baseValue) + (Number(b - 64n)) / $.$spc.System.Math.Log(baseValue, 2);
            }
            static /*double */ Log10(/*BigInteger*/ value)
            {
                return $.$srn.System.Numerics.BigInteger.Log$1(value, 10);
            }
            static /*BigInteger */ GreatestCommonDivisor(/*BigInteger*/ left, /*BigInteger*/ right)
            {
                left.AssertValid();
                right.AssertValid();
                /*bool*/ let trivialLeft = left._bits === null;
                /*bool*/ let trivialRight = right._bits === null;
                if (trivialLeft && trivialRight)
                {
                    return $.$srn.System.Numerics.BigInteger.op_Implicit$9($.$srn.System.Numerics.BigIntegerCalculator.Gcd($.$srn.System.Numerics.NumericsHelpers.Abs(left._sign), $.$srn.System.Numerics.NumericsHelpers.Abs(right._sign)));
                }
                if (trivialLeft)
                {
                    $.$spc.System.Diagnostics.Debug.Assert$1(right._bits !== null, "right._bits != null");
                    return left._sign !== 0 ? $.$srn.System.Numerics.BigInteger.op_Implicit$9($.$srn.System.Numerics.BigIntegerCalculator.Gcd$2($.$spc.System.ReadOnlySpan$$($.$spc.System.UInt32).op_Implicit(right._bits), $.$srn.System.Numerics.NumericsHelpers.Abs(left._sign))) : new $.$srn.System.Numerics.BigInteger().$ctor$12($.$spc.System.ReadOnlySpan$$($.$spc.System.UInt32).op_Implicit(right._bits), false);
                }
                if (trivialRight)
                {
                    $.$spc.System.Diagnostics.Debug.Assert$1(left._bits !== null, "left._bits != null");
                    return right._sign !== 0 ? $.$srn.System.Numerics.BigInteger.op_Implicit$9($.$srn.System.Numerics.BigIntegerCalculator.Gcd$2($.$spc.System.ReadOnlySpan$$($.$spc.System.UInt32).op_Implicit(left._bits), $.$srn.System.Numerics.NumericsHelpers.Abs(right._sign))) : new $.$srn.System.Numerics.BigInteger().$ctor$12($.$spc.System.ReadOnlySpan$$($.$spc.System.UInt32).op_Implicit(left._bits), false);
                }
                $.$spc.System.Diagnostics.Debug.Assert$1(left._bits !== null && right._bits !== null, "left._bits != null && right._bits != null");
                if ($.$srn.System.Numerics.BigIntegerCalculator.Compare($.$spc.System.ReadOnlySpan$$($.$spc.System.UInt32).op_Implicit(left._bits), $.$spc.System.ReadOnlySpan$$($.$spc.System.UInt32).op_Implicit(right._bits)) < 0)
                {
                    return $.$srn.System.Numerics.BigInteger.GreatestCommonDivisor$1($.$spc.System.ReadOnlySpan$$($.$spc.System.UInt32).op_Implicit(right._bits), $.$spc.System.ReadOnlySpan$$($.$spc.System.UInt32).op_Implicit(left._bits));
                }
                else 
                {
                    return $.$srn.System.Numerics.BigInteger.GreatestCommonDivisor$1($.$spc.System.ReadOnlySpan$$($.$spc.System.UInt32).op_Implicit(left._bits), $.$spc.System.ReadOnlySpan$$($.$spc.System.UInt32).op_Implicit(right._bits));
                }
            }
            static /*BigInteger */ GreatestCommonDivisor$1(/*ReadOnlySpan<uint>*/ leftBits, /*ReadOnlySpan<uint>*/ rightBits)
            {
                $.$spc.System.Diagnostics.Debug.Assert$1($.$srn.System.Numerics.BigIntegerCalculator.Compare(leftBits, rightBits) >= 0, "BigIntegerCalculator.Compare(leftBits, rightBits) >= 0");
                /*uint[]?*/ let bitsFromPool = null;
                /*BigInteger*/ let result;
                if (rightBits.Length === 1)
                {
                    /*uint*/ let temp = $.$srn.System.Numerics.BigIntegerCalculator.Remainder(leftBits, rightBits.get_Item(0).$v);
                    result = $.$srn.System.Numerics.BigInteger.op_Implicit$9($.$srn.System.Numerics.BigIntegerCalculator.Gcd(rightBits.get_Item(0).$v, temp));
                }
                else if (rightBits.Length === 2)
                {
                    /*Span<uint>*/ let bits = (leftBits.Length <= $.$srn.System.Numerics.BigIntegerCalculator.StackAllocThreshold ? $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.StackAllocSpan($.$spc.System.UInt32, $.$srn.System.Numerics.BigIntegerCalculator.StackAllocThreshold, null) : $.$spc.System.Span$$($.$spc.System.UInt32).op_Implicit(bitsFromPool = $.$spc.System.Buffers.ArrayPool$$($.$spc.System.UInt32).Shared.Rent(leftBits.Length))).Slice$1(0, leftBits.Length);
                    $.$srn.System.Numerics.BigIntegerCalculator.Remainder$1(leftBits, rightBits, bits);
                    /*ulong*/ let left = (BigInt.asUintN(64, $.$cast(rightBits.get_Item(1).$v, $.$spc.System.UInt64) << 32n)) | BigInt(rightBits.get_Item(0).$v);
                    /*ulong*/ let right = (BigInt.asUintN(64, $.$cast(bits.get_Item(1).$v, $.$spc.System.UInt64) << 32n)) | BigInt(bits.get_Item(0).$v);
                    result = $.$srn.System.Numerics.BigInteger.op_Implicit$10($.$srn.System.Numerics.BigIntegerCalculator.Gcd$1(left, right));
                }
                else 
                {
                    /*Span<uint>*/ let bits = (leftBits.Length <= $.$srn.System.Numerics.BigIntegerCalculator.StackAllocThreshold ? $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.StackAllocSpan($.$spc.System.UInt32, $.$srn.System.Numerics.BigIntegerCalculator.StackAllocThreshold, null) : $.$spc.System.Span$$($.$spc.System.UInt32).op_Implicit(bitsFromPool = $.$spc.System.Buffers.ArrayPool$$($.$spc.System.UInt32).Shared.Rent(leftBits.Length))).Slice$1(0, leftBits.Length);
                    $.$srn.System.Numerics.BigIntegerCalculator.Gcd$3(leftBits, rightBits, bits);
                    result = new $.$srn.System.Numerics.BigInteger().$ctor$12($.$spc.System.Span$$($.$spc.System.UInt32).op_Implicit$2(bits), false);
                }
                if (bitsFromPool !== null)
                {
                    $.$spc.System.Buffers.ArrayPool$$($.$spc.System.UInt32).Shared.Return(bitsFromPool, false);
                }
                return result;
            }
            static /*BigInteger */ Max(/*BigInteger*/ left, /*BigInteger*/ right)
            {
                if (left.CompareTo$2(right) < 0)
                {
                    return right;
                }
                return left;
            }
            static /*BigInteger */ Min(/*BigInteger*/ left, /*BigInteger*/ right)
            {
                if (left.CompareTo$2(right) <= 0)
                {
                    return left;
                }
                return right;
            }
            static /*BigInteger */ ModPow(/*BigInteger*/ value, /*BigInteger*/ exponent, /*BigInteger*/ modulus)
            {
                $.$spc.System.ArgumentOutOfRangeException.ThrowIfNegative($.$spc.System.Int32, exponent.Sign, "exponent");
                value.AssertValid();
                exponent.AssertValid();
                modulus.AssertValid();
                /*bool*/ let trivialValue = value._bits === null;
                /*bool*/ let trivialExponent = exponent._bits === null;
                /*bool*/ let trivialModulus = modulus._bits === null;
                /*BigInteger*/ let result;
                if (trivialModulus)
                {
                    /*uint*/ let bits = trivialValue && trivialExponent ? $.$srn.System.Numerics.BigIntegerCalculator.Pow$2($.$srn.System.Numerics.NumericsHelpers.Abs(value._sign), $.$srn.System.Numerics.NumericsHelpers.Abs(exponent._sign), $.$srn.System.Numerics.NumericsHelpers.Abs(modulus._sign)) : trivialValue ? $.$srn.System.Numerics.BigIntegerCalculator.Pow$4($.$srn.System.Numerics.NumericsHelpers.Abs(value._sign), $.$spc.System.ReadOnlySpan$$($.$spc.System.UInt32).op_Implicit(exponent._bits), $.$srn.System.Numerics.NumericsHelpers.Abs(modulus._sign)) : trivialExponent ? $.$srn.System.Numerics.BigIntegerCalculator.Pow$3($.$spc.System.ReadOnlySpan$$($.$spc.System.UInt32).op_Implicit(value._bits), $.$srn.System.Numerics.NumericsHelpers.Abs(exponent._sign), $.$srn.System.Numerics.NumericsHelpers.Abs(modulus._sign)) : $.$srn.System.Numerics.BigIntegerCalculator.Pow$5($.$spc.System.ReadOnlySpan$$($.$spc.System.UInt32).op_Implicit(value._bits), $.$spc.System.ReadOnlySpan$$($.$spc.System.UInt32).op_Implicit(exponent._bits), $.$srn.System.Numerics.NumericsHelpers.Abs(modulus._sign));
                    result = $.$srn.System.Numerics.BigInteger.op_Implicit$4(value._sign < 0 && !exponent.IsEven ? BigInt(-1) * BigInt(bits) : BigInt(bits));
                }
                else 
                {
                    const $t1 = () => modulus._bits;
                    /*int*/ let size = ($.$ifnn($t1, ($t) => $t.length) ?? 1) << 1;
                    /*uint[]?*/ let bitsFromPool = null;
                    /*Span<uint>*/ let bits = (BigInt((size >>> 0)) <= BigInt($.$srn.System.Numerics.BigIntegerCalculator.StackAllocThreshold) ? $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.StackAllocSpan($.$spc.System.UInt32, $.$srn.System.Numerics.BigIntegerCalculator.StackAllocThreshold, null) : $.$spc.System.Span$$($.$spc.System.UInt32).op_Implicit(bitsFromPool = $.$spc.System.Buffers.ArrayPool$$($.$spc.System.UInt32).Shared.Rent(size))).Slice$1(0, size);
                    bits.Clear();
                    if (trivialValue)
                    {
                        if (trivialExponent)
                        {
                            $.$srn.System.Numerics.BigIntegerCalculator.Pow$6($.$srn.System.Numerics.NumericsHelpers.Abs(value._sign), $.$srn.System.Numerics.NumericsHelpers.Abs(exponent._sign), $.$spc.System.ReadOnlySpan$$($.$spc.System.UInt32).op_Implicit(modulus._bits), bits);
                        }
                        else 
                        {
                            $.$srn.System.Numerics.BigIntegerCalculator.Pow$8($.$srn.System.Numerics.NumericsHelpers.Abs(value._sign), $.$spc.System.ReadOnlySpan$$($.$spc.System.UInt32).op_Implicit(exponent._bits), $.$spc.System.ReadOnlySpan$$($.$spc.System.UInt32).op_Implicit(modulus._bits), bits);
                        }
                    }
                    else if (trivialExponent)
                    {
                        $.$srn.System.Numerics.BigIntegerCalculator.Pow$7($.$spc.System.ReadOnlySpan$$($.$spc.System.UInt32).op_Implicit(value._bits), $.$srn.System.Numerics.NumericsHelpers.Abs(exponent._sign), $.$spc.System.ReadOnlySpan$$($.$spc.System.UInt32).op_Implicit(modulus._bits), bits);
                    }
                    else 
                    {
                        $.$srn.System.Numerics.BigIntegerCalculator.Pow$9($.$spc.System.ReadOnlySpan$$($.$spc.System.UInt32).op_Implicit(value._bits), $.$spc.System.ReadOnlySpan$$($.$spc.System.UInt32).op_Implicit(exponent._bits), $.$spc.System.ReadOnlySpan$$($.$spc.System.UInt32).op_Implicit(modulus._bits), bits);
                    }
                    result = new $.$srn.System.Numerics.BigInteger().$ctor$12($.$spc.System.Span$$($.$spc.System.UInt32).op_Implicit$2(bits), value._sign < 0 && !exponent.IsEven);
                    if (bitsFromPool !== null)
                    {
                        $.$spc.System.Buffers.ArrayPool$$($.$spc.System.UInt32).Shared.Return(bitsFromPool, false);
                    }
                }
                return result;
            }
            static /*BigInteger */ Pow(/*BigInteger*/ value, /*int*/ exponent)
            {
                $.$spc.System.ArgumentOutOfRangeException.ThrowIfNegative($.$spc.System.Int32, exponent, "exponent");
                value.AssertValid();
                if (exponent === 0)
                {
                    return $.$srn.System.Numerics.BigInteger.s_bnOneInt;
                }
                if (exponent === 1)
                {
                    return value;
                }
                /*bool*/ let trivialValue = value._bits === null;
                /*uint*/ let power = $.$srn.System.Numerics.NumericsHelpers.Abs(exponent);
                /*uint[]?*/ let bitsFromPool = null;
                /*BigInteger*/ let result;
                if (trivialValue)
                {
                    if (value._sign === 1)
                    {
                        return value;
                    }
                    if (value._sign === -1)
                    {
                        return (exponent & 1) !== 0 ? value : $.$srn.System.Numerics.BigInteger.s_bnOneInt;
                    }
                    if (value._sign === 0)
                    {
                        return value;
                    }
                    /*int*/ let size = $.$srn.System.Numerics.BigIntegerCalculator.PowBound(power, 1);
                    /*Span<uint>*/ let bits = (BigInt((size >>> 0)) <= BigInt($.$srn.System.Numerics.BigIntegerCalculator.StackAllocThreshold) ? $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.StackAllocSpan($.$spc.System.UInt32, $.$srn.System.Numerics.BigIntegerCalculator.StackAllocThreshold, null) : $.$spc.System.Span$$($.$spc.System.UInt32).op_Implicit(bitsFromPool = $.$spc.System.Buffers.ArrayPool$$($.$spc.System.UInt32).Shared.Rent(size))).Slice$1(0, size);
                    bits.Clear();
                    $.$srn.System.Numerics.BigIntegerCalculator.Pow($.$srn.System.Numerics.NumericsHelpers.Abs(value._sign), power, bits);
                    result = new $.$srn.System.Numerics.BigInteger().$ctor$12($.$spc.System.Span$$($.$spc.System.UInt32).op_Implicit$2(bits), value._sign < 0 && (exponent & 1) !== 0);
                }
                else 
                {
                    /*int*/ let size = $.$srn.System.Numerics.BigIntegerCalculator.PowBound(power, value._bits.length);
                    /*Span<uint>*/ let bits = (BigInt((size >>> 0)) <= BigInt($.$srn.System.Numerics.BigIntegerCalculator.StackAllocThreshold) ? $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.StackAllocSpan($.$spc.System.UInt32, $.$srn.System.Numerics.BigIntegerCalculator.StackAllocThreshold, null) : $.$spc.System.Span$$($.$spc.System.UInt32).op_Implicit(bitsFromPool = $.$spc.System.Buffers.ArrayPool$$($.$spc.System.UInt32).Shared.Rent(size))).Slice$1(0, size);
                    bits.Clear();
                    $.$srn.System.Numerics.BigIntegerCalculator.Pow$1($.$spc.System.ReadOnlySpan$$($.$spc.System.UInt32).op_Implicit(value._bits), power, bits);
                    result = new $.$srn.System.Numerics.BigInteger().$ctor$12($.$spc.System.Span$$($.$spc.System.UInt32).op_Implicit$2(bits), value._sign < 0 && (exponent & 1) !== 0);
                }
                if (bitsFromPool !== null)
                {
                    $.$spc.System.Buffers.ArrayPool$$($.$spc.System.UInt32).Shared.Return(bitsFromPool, false);
                }
                return result;
            }
            static/*conventional*/ /*int */ GetHashCode()
            {
                this.AssertValid();
                if (this._bits === null)
                {
                    return this._sign;
                }
                /*HashCode*/ let hash = new $.$spc.System.HashCode();
                hash.AddBytes($.$spc.System.Span$$($.$spc.System.Byte).op_Implicit$2($.$spc.System.Runtime.InteropServices.MemoryMarshal.AsBytes($.$spc.System.UInt32, $.$spc.System.MemoryExtensions.AsSpan$8($.$spc.System.UInt32, this._bits))));
                hash.Add($.$spc.System.Int32, this._sign);
                return hash.ToHashCode();
            }
            //Static convention instance redirect
            /*int */ GetHashCode() { return $.$srn.System.Numerics.BigInteger.GetHashCode.apply(this, arguments); }
            static/*conventional*/ /*bool */ Equals(/*object?*/ obj)
            {
                this.AssertValid();
                let other;
                return $.$is(obj, $.$srn.System.Numerics.BigInteger, { set $v(v){ other = v; } }) && this.Equals$4(other);
            }
            //Static convention instance redirect
            /*bool */ Equals() { return $.$srn.System.Numerics.BigInteger.Equals.apply(this, arguments); }
            /*bool */ Equals$2(/*long*/ other)
            {
                this.AssertValid();
                if (this._bits === null)
                {
                    return BigInt(this._sign) === other;
                }
                /*int*/ let cu;
                if ((BigInt(this._sign) ^ other) < 0n || (cu = this._bits.length) > 2)
                {
                    return false;
                }
                /*ulong*/ let uu = other < 0n ? $.$cast(-other, $.$spc.System.UInt64) : $.$cast(other, $.$spc.System.UInt64);
                if (cu === 1)
                {
                    return BigInt($.$spc.System.Array.$ReadT1.call(this._bits, 0)) === uu;
                }
                return $.$srn.System.Numerics.NumericsHelpers.MakeUInt64($.$spc.System.Array.$ReadT1.call(this._bits, 1), $.$spc.System.Array.$ReadT1.call(this._bits, 0)) === uu;
            }
            /*bool */ Equals$3(/*ulong*/ other)
            {
                this.AssertValid();
                if (this._sign < 0)
                {
                    return false;
                }
                if (this._bits === null)
                {
                    return $.$cast(this._sign, $.$spc.System.UInt64) === other;
                }
                /*int*/ let cu = this._bits.length;
                if (cu > 2)
                {
                    return false;
                }
                if (cu === 1)
                {
                    return BigInt($.$spc.System.Array.$ReadT1.call(this._bits, 0)) === other;
                }
                return $.$srn.System.Numerics.NumericsHelpers.MakeUInt64($.$spc.System.Array.$ReadT1.call(this._bits, 1), $.$spc.System.Array.$ReadT1.call(this._bits, 0)) === other;
            }
            /*bool */ Equals$4(/*BigInteger*/ other)
            {
                this.AssertValid();
                other.AssertValid();
                return this._sign === other._sign && $.$spc.System.MemoryExtensions.SequenceEqual$1($.$spc.System.UInt32, $.$spc.System.Span$$($.$spc.System.UInt32).op_Implicit$2($.$spc.System.MemoryExtensions.AsSpan$8($.$spc.System.UInt32, this._bits)), $.$spc.System.ReadOnlySpan$$($.$spc.System.UInt32).op_Implicit(other._bits));
            }
            /*int */ CompareTo(/*long*/ other)
            {
                this.AssertValid();
                if (this._bits === null)
                {
                    return $.$spc.System.Int64.CompareTo$1.call(($.$cast(this._sign, $.$spc.System.Int64)), other);
                }
                /*int*/ let cu;
                if ((BigInt(this._sign) ^ other) < 0n || (cu = this._bits.length) > 2)
                {
                    return this._sign;
                }
                /*ulong*/ let uu = other < 0n ? $.$cast(-other, $.$spc.System.UInt64) : $.$cast(other, $.$spc.System.UInt64);
                /*ulong*/ let uuTmp = cu === 2 ? $.$srn.System.Numerics.NumericsHelpers.MakeUInt64($.$spc.System.Array.$ReadT1.call(this._bits, 1), $.$spc.System.Array.$ReadT1.call(this._bits, 0)) : BigInt($.$spc.System.Array.$ReadT1.call(this._bits, 0));
                return ((this._sign * $.$spc.System.UInt64.CompareTo$1.call(uuTmp, uu)) | 0);
            }
            /*int */ CompareTo$1(/*ulong*/ other)
            {
                this.AssertValid();
                if (this._sign < 0)
                {
                    return -1;
                }
                if (this._bits === null)
                {
                    return $.$spc.System.UInt64.CompareTo$1.call(($.$cast(this._sign, $.$spc.System.UInt64)), other);
                }
                /*int*/ let cu = this._bits.length;
                if (cu > 2)
                {
                    return +1;
                }
                /*ulong*/ let uuTmp = cu === 2 ? $.$srn.System.Numerics.NumericsHelpers.MakeUInt64($.$spc.System.Array.$ReadT1.call(this._bits, 1), $.$spc.System.Array.$ReadT1.call(this._bits, 0)) : BigInt($.$spc.System.Array.$ReadT1.call(this._bits, 0));
                return $.$spc.System.UInt64.CompareTo$1.call(uuTmp, other);
            }
            /*int */ CompareTo$2(/*BigInteger*/ other)
            {
                this.AssertValid();
                other.AssertValid();
                if ((this._sign ^ other._sign) < 0)
                {
                    return this._sign < 0 ? -1 : +1;
                }
                if (this._bits === null)
                {
                    if (other._bits === null)
                    {
                        return this._sign < other._sign ? -1 : this._sign > other._sign ? +1 : 0;
                    }
                    return -other._sign;
                }
                if (other._bits === null)
                {
                    return this._sign;
                }
                /*int*/ let bitsResult = $.$srn.System.Numerics.BigIntegerCalculator.Compare($.$spc.System.ReadOnlySpan$$($.$spc.System.UInt32).op_Implicit(this._bits), $.$spc.System.ReadOnlySpan$$($.$spc.System.UInt32).op_Implicit(other._bits));
                return this._sign < 0 ? -bitsResult : bitsResult;
            }
            /*int */ CompareTo$3(/*object?*/ obj)
            {
                if (obj === null)
                {
                    return 1;
                }
                let bigInt;
                if (!$.$is(obj, $.$srn.System.Numerics.BigInteger, { set $v(v){ bigInt = v; } }))
                {
                    throw new $.$spc.System.ArgumentException().$ctor$13($.$srn.System.SR.Argument_MustBeBigInt, "obj");
                }
                return this.CompareTo$2(bigInt);
            }
            /*byte[] */ ToByteArray()
            {
                return this.ToByteArray$1(false, false);
            }
            /*byte[] */ ToByteArray$1(/*bool*/ isUnsigned, /*bool*/ isBigEndian)
            {
                /*int*/ let ignored = 0;
                return this.TryGetBytes(0/*GetBytesMode.AllocateArray*/, new ($.$spc.System.Span$$($.$spc.System.Byte))(), isUnsigned, isBigEndian, $.$ref(() => ignored, ($v) => ignored = $v, $.$spc.System.Int32));
            }
            /*bool */ TryWriteBytes(/*Span<byte>*/ destination, /*out int*/ bytesWritten, /*bool*/ isUnsigned, /*bool*/ isBigEndian)
            {
                bytesWritten.$v = 0;
                if (this.TryGetBytes(2/*GetBytesMode.Span*/, destination, isUnsigned, isBigEndian, bytesWritten) === null)
                {
                    bytesWritten.$v = 0;
                    return false;
                }
                return true;
            }
            /*bool */ TryWriteOrCountBytes(/*Span<byte>*/ destination, /*out int*/ bytesWritten, /*bool*/ isUnsigned, /*bool*/ isBigEndian)
            {
                bytesWritten.$v = 0;
                return this.TryGetBytes(2/*GetBytesMode.Span*/, destination, isUnsigned, isBigEndian, bytesWritten) !== null;
            }
            /*int */ GetByteCount(/*bool*/ isUnsigned)
            {
                /*int*/ let count = 0;
                /*bool*/ let IsBigEndian = false;
                this.TryGetBytes(1/*GetBytesMode.Count*/, $.$default($.$spc.System.Span$$($.$spc.System.Byte)), isUnsigned, IsBigEndian, $.$ref(() => count, ($v) => count = $v, $.$spc.System.Int32));
                return count;
            }
            static $_GetBytesMode;
            static get GetBytesMode()
            {
                let $cls = $.$srn.System.Numerics.BigInteger;
                return $cls.$_GetBytesMode ??= $asm.$nstr("$srn.System.Numerics.BigInteger.GetBytesMode", ($self) => class GetBytesMode extends $.$spc.System.Enum
                {
                    static AllocateArray = 0;
                    static Count = 1;
                    static Span = 2;
                    static $map;
                    static get Map()
                    {
                        return this.$map ??= 
                        {
                            "AllocateArray": 0n,
                            "Count": 1n,
                            "Span": 2n
                        };
                    }
                    static $h = 895761;
                    static $z = 4;
                    static $f = 0b110000011010001000;
                    static $k = 4;
                    static get $eut() { return $.$spc.System.Int32; }
                    static $$md;
                    static get $md() { return this.$$md ??= {"b":1048577,"u":655361,"l":[{"t":895761,"n":"AllocateArray","d":895761,"h":4295863057,"f":33},{"t":895761,"n":"Count","d":895761,"h":8590830353,"f":33},{"t":895761,"n":"Span","d":895761,"h":12885797649,"f":33}],"c":[{"n":".ctor","o":"$ctor$3","d":895761,"h":17180764945,"f":1}],"i":[57278465,63832065,57737217,57409537],"d":830225,"h":895761}; }
                    static get $b() { return $.$spc.System.Enum; }
                    static $$i;
                    static get $i() { return this.$$i ??= [ $.$spc.System.IComparable, $.$spc.System.ISpanFormattable, $.$spc.System.IFormattable, $.$spc.System.IConvertible ]; }
                    static get $fullName() { return `System.Numerics.BigInteger.GetBytesMode`; }
                }, $cls, ($v) => $cls.$_GetBytesMode = $v);
            }
            /*byte[]? */ TryGetBytes(/*GetBytesMode*/ mode, /*Span<byte>*/ destination, /*bool*/ isUnsigned, /*bool*/ isBigEndian, /*ref int*/ bytesWritten)
            {
                $.$spc.System.Diagnostics.Debug.Assert$2(mode === 0/*GetBytesMode.AllocateArray*/ || mode === 1/*GetBytesMode.Count*/ || mode === 2/*GetBytesMode.Span*/, `Unexpected mode ${mode}.`);
                $.$spc.System.Diagnostics.Debug.Assert$1(mode === 2/*GetBytesMode.Span*/ || destination.IsEmpty, `If we're not in span mode, we shouldn't have been passed a destination.`);
                /*int*/ let sign = this._sign;
                if (sign === 0)
                {
                    switch(mode)
                    {
                        case 0/*GetBytesMode.AllocateArray*/:
                        return $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$spc.System.Byte), [0], [-1], null);
                        case 1/*GetBytesMode.Count*/:
                        bytesWritten.$v = 1;
                        return null;
                        default:
                        bytesWritten.$v = 1;
                        if (destination.Length !== 0)
                        {
                            destination.get_Item(0).$v = 0;
                            return $.$spc.System.Array.Empty($.$spc.System.Byte);
                        }
                        return null;
                    }
                }
                if (isUnsigned && sign < 0)
                {
                    throw new $.$spc.System.OverflowException().$ctor$14($.$srn.System.SR.Overflow_Negative_Unsigned);
                }
                /*byte*/ let highByte;
                /*int*/ let nonZeroDwordIndex = 0;
                /*uint*/ let highDword;
                /*uint[]?*/ let bits = this._bits;
                if (bits === null)
                {
                    highByte = $.$cast(((sign < 0) ? 255 : 0), $.$spc.System.Byte);
                    highDword = (sign >>> 0);
                }
                else if (sign === -1)
                {
                    highByte = 255;
                    $.$spc.System.Diagnostics.Debug.Assert$1(bits.length > 0, "bits.Length > 0");
                    $.$spc.System.Diagnostics.Debug.Assert$1($.$spc.System.Array.$ReadT1.call(bits, ((bits.length - 1) | 0)) !== 0, "bits[bits.Length - 1] != 0");
                    while($.$spc.System.Array.$ReadT1.call(bits, nonZeroDwordIndex) === 0)
                    {
                        nonZeroDwordIndex++;
                    }
                    highDword = ~$.$spc.System.Array.$ReadT1.call(bits, ((bits.length - 1) | 0));
                    if (((bits.length - 1) | 0) === nonZeroDwordIndex)
                    {
                        $.$spc.System.Diagnostics.Debug.Assert$1(highDword <= (((4294967295/*uint.MaxValue*/ - 1) >>> 0) >>> 0), "highDword <= uint.MaxValue - 1");
                        highDword += 1;
                    }
                }
                else 
                {
                    $.$spc.System.Diagnostics.Debug.Assert$1(sign === 1, "sign == 1");
                    highByte = 0;
                    highDword = $.$spc.System.Array.$ReadT1.call(bits, ((bits.length - 1) | 0));
                }
                /*byte*/ let msb;
                /*int*/ let msbIndex;
                if ((msb = $.$cast((highDword >>> 24), $.$spc.System.Byte)) !== highByte)
                {
                    msbIndex = 3;
                }
                else if ((msb = $.$cast((highDword >>> 16), $.$spc.System.Byte)) !== highByte)
                {
                    msbIndex = 2;
                }
                else if ((msb = $.$cast((highDword >>> 8), $.$spc.System.Byte)) !== highByte)
                {
                    msbIndex = 1;
                }
                else 
                {
                    msb = $.$cast(highDword, $.$spc.System.Byte);
                    msbIndex = 0;
                }
                /*bool*/ let needExtraByte = (msb & 128) !== (highByte & 128) && !isUnsigned;
                /*int*/ let length = ((((msbIndex + 1) | 0) + (needExtraByte ? 1 : 0)) | 0);
                if (bits !== null)
                {
                    length = $.$checked($.$checked(4 * ($.$checked(bits.length - 1, 1)), 1) + length, 1);
                }
                /*byte[]*/ let array;
                switch(mode)
                {
                    case 0/*GetBytesMode.AllocateArray*/:
                    destination = $.$spc.System.Span$$($.$spc.System.Byte).op_Implicit(array = $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$spc.System.Byte), null, [length], null));
                    break;
                    case 1/*GetBytesMode.Count*/:
                    bytesWritten.$v = length;
                    return null;
                    default:
                    bytesWritten.$v = length;
                    if (destination.Length < length)
                    {
                        return null;
                    }
                    array = $.$spc.System.Array.Empty($.$spc.System.Byte);
                    break;
                }
                /*int*/ let curByte = isBigEndian ? length : 0;
                /*int*/ let increment = isBigEndian ? -1 : 1;
                if (bits !== null)
                {
                    if ($.$spc.System.BitConverter.IsLittleEndian && sign > 0)
                    {
                        /*ReadOnlySpan<byte>*/ let srcBytes = $.$spc.System.Span$$($.$spc.System.Byte).op_Implicit$2($.$spc.System.Runtime.InteropServices.MemoryMarshal.AsBytes($.$spc.System.UInt32, $.$spc.System.MemoryExtensions.AsSpan$2($.$spc.System.UInt32, bits, $.$spc.System.Range.EndAt($.$spc.System.Index.FromEnd(1)))));
                        if (isBigEndian)
                        {
                            curByte = ((length - srcBytes.Length) | 0);
                            /*Span<byte>*/ let destBytes = destination.Slice$1(curByte, srcBytes.Length);
                            srcBytes.CopyTo(destBytes);
                            $.$spc.System.MemoryExtensions.Reverse($.$spc.System.Byte, destBytes);
                        }
                        else 
                        {
                            srcBytes.CopyTo(destination);
                            curByte = srcBytes.Length;
                        }
                    }
                    else 
                    {
                        for(/*int*/ let i = 0; i < ((bits.length - 1) | 0); i++)
                        {
                            /*uint*/ let dword = $.$spc.System.Array.$ReadT1.call(bits, i);
                            if (sign === -1)
                            {
                                dword = ~dword;
                                if (i <= nonZeroDwordIndex)
                                {
                                    dword = ((dword + 1) >>> 0);
                                }
                            }
                            if (isBigEndian)
                            {
                                curByte -= 4;
                                $.$spc.System.Buffers.Binary.BinaryPrimitives.WriteUInt32BigEndian(destination.Slice(curByte), dword);
                            }
                            else 
                            {
                                $.$spc.System.Buffers.Binary.BinaryPrimitives.WriteUInt32LittleEndian(destination.Slice(curByte), dword);
                                curByte += 4;
                            }
                        }
                    }
                }
                if (isBigEndian)
                {
                    curByte--;
                }
                $.$spc.System.Diagnostics.Debug.Assert$1(msbIndex >= 0 && msbIndex <= 3, "msbIndex >= 0 && msbIndex <= 3");
                destination.get_Item(curByte).$v = $.$cast(highDword, $.$spc.System.Byte);
                if (msbIndex !== 0)
                {
                    curByte += increment;
                    destination.get_Item(curByte).$v = $.$cast((highDword >>> 8), $.$spc.System.Byte);
                    if (msbIndex !== 1)
                    {
                        curByte += increment;
                        destination.get_Item(curByte).$v = $.$cast((highDword >>> 16), $.$spc.System.Byte);
                        if (msbIndex !== 2)
                        {
                            curByte += increment;
                            destination.get_Item(curByte).$v = $.$cast((highDword >>> 24), $.$spc.System.Byte);
                        }
                    }
                }
                $.$spc.System.Diagnostics.Debug.Assert$1(isBigEndian || (!needExtraByte && curByte === ((length - 1) | 0)) || (needExtraByte && curByte === ((length - 2) | 0)), "isBigEndian || (!needExtraByte && curByte == length - 1) || (needExtraByte && curByte == length - 2)");
                $.$spc.System.Diagnostics.Debug.Assert$1(!isBigEndian || (!needExtraByte && curByte === 0) || (needExtraByte && curByte === 1), "!isBigEndian || (!needExtraByte && curByte == 0) || (needExtraByte && curByte == 1)");
                if (needExtraByte)
                {
                    curByte += increment;
                    destination.get_Item(curByte).$v = highByte;
                }
                return array;
            }
            /*int */ WriteTo(/*Span<uint>*/ buffer)
            {
                $.$spc.System.Diagnostics.Debug.Assert$1(this._bits === null || this._sign === 0 ? buffer.Length === 2 : buffer.Length >= ((this._bits.length + 1) | 0), "_bits is null || _sign == 0 ? buffer.Length == 2 : buffer.Length >= _bits.Length + 1");
                /*uint*/ let highDWord;
                if (this._bits === null)
                {
                    buffer.get_Item(0).$v = (this._sign >>> 0);
                    highDWord = (this._sign < 0) ? 4294967295/*uint.MaxValue*/ : 0;
                }
                else 
                {
                    $.$spc.System.MemoryExtensions.CopyTo($.$spc.System.UInt32, this._bits, buffer);
                    buffer = buffer.Slice$1(0, ((this._bits.length + 1) | 0));
                    if (this._sign === -1)
                    {
                        $.$srn.System.Numerics.NumericsHelpers.DangerousMakeTwosComplement(buffer.Slice$1(0, ((buffer.Length - 1) | 0)));
                        highDWord = 4294967295/*uint.MaxValue*/;
                    }
                    else 
                    {
                        highDWord = 0;
                    }
                }
                /*int*/ let msb = ((buffer.Length - 2) | 0);
                while(msb > 0 && buffer.get_Item(msb).$v === highDWord)
                {
                    msb--;
                }
                /*bool*/ let needExtraByte = (buffer.get_Item(msb).$v & 2147483648) !== (highDWord & 2147483648);
                /*int*/ let count;
                if (needExtraByte)
                {
                    count = ((msb + 2) | 0);
                    buffer = buffer.Slice$1(0, count);
                    buffer.get_Item(((buffer.Length - 1) | 0)).$v = highDWord;
                }
                else 
                {
                    count = ((msb + 1) | 0);
                }
                return count;
            }
            static/*conventional*/ /*string */ ToString()
            {
                return $.$srn.System.Number.FormatBigInteger(this, null, $.$spc.System.Globalization.NumberFormatInfo.CurrentInfo);
            }
            //Static convention instance redirect
            /*string */ ToString() { return $.$srn.System.Numerics.BigInteger.ToString.apply(this, arguments); }
            /*string */ ToString$1(/*IFormatProvider?*/ provider)
            {
                return $.$srn.System.Number.FormatBigInteger(this, null, $.$spc.System.Globalization.NumberFormatInfo.GetInstance(provider));
            }
            /*string */ ToString$2(/*string?*/ format)
            {
                return $.$srn.System.Number.FormatBigInteger(this, format, $.$spc.System.Globalization.NumberFormatInfo.CurrentInfo);
            }
            /*string */ ToString$3(/*string?*/ format, /*IFormatProvider?*/ provider)
            {
                return $.$srn.System.Number.FormatBigInteger(this, format, $.$spc.System.Globalization.NumberFormatInfo.GetInstance(provider));
            }
            /*string */ get DebuggerDisplay()
            {
                if ((this._bits === null) || (this._bits.length <= 4))
                {
                    return $.$srn.System.Numerics.BigInteger.ToString.call(this);
                }
                /*double*/ let log10Of2 = 0.3010299956639812;
                /*ulong*/ let highBits = (BigInt.asUintN(64, $.$cast($.$spc.System.Array.$ReadT1.call(this._bits, this._bits.length - 1), $.$spc.System.UInt64) << BigInt(32/*kcbitUint*/))) + BigInt($.$spc.System.Array.$ReadT1.call(this._bits, this._bits.length - 2));
                /*double*/ let lowBitsCount32 = ((this._bits.length - 2) | 0);
                /*double*/ let exponentLow = lowBitsCount32 * 32/*kcbitUint*/ * log10Of2;
                /*long*/ let exponent = $.$cast(exponentLow, $.$spc.System.Int64);
                /*double*/ let significand = $.$cast(highBits, $.$spc.System.Double) * Math.pow(10, exponentLow - Number(exponent));
                /*double*/ let log10 = Math.log10(significand);
                if (log10 >= 1)
                {
                    exponent += $.$cast(log10, $.$spc.System.Int64);
                    significand /= Math.pow(10, Math.floor(log10));
                }
                significand = $.$spc.System.Math.Round$5(significand, 8);
                if (significand >= 10)
                {
                    significand /= 10;
                    exponent++;
                }
                /*string*/ let signStr = this._sign < 0 ? $.$spc.System.Globalization.NumberFormatInfo.CurrentInfo.NegativeSign : "";
                return (() =>
                {
                    var $handler = new $.$spc.System.Runtime.CompilerServices.DefaultInterpolatedStringHandler().$ctor$2(1, 3);
                    $handler.AppendFormatted$8($.$box(signStr, $.$spc.System.String), null, null);
                    $handler.AppendFormatted$8($.$box(significand, $.$spc.System.Double), null, "F8");
                    $handler.AppendLiteral("e+");
                    $handler.AppendFormatted$8($.$box(exponent, $.$spc.System.Int64), null, null);
                    return $handler.ToStringAndClear();
                })();
            }
            /*bool */ TryFormat(/*Span<char>*/ destination, /*out int*/ charsWritten, /*ReadOnlySpan<char>*/ format, /*IFormatProvider?*/ provider)
            {
                return $.$srn.System.Number.TryFormatBigInteger(this, format, $.$spc.System.Globalization.NumberFormatInfo.GetInstance(provider), destination, charsWritten);
            }
            static /*BigInteger */ Add$1(/*ReadOnlySpan<uint>*/ leftBits, /*int*/ leftSign, /*ReadOnlySpan<uint>*/ rightBits, /*int*/ rightSign)
            {
                /*bool*/ let trivialLeft = leftBits.IsEmpty;
                /*bool*/ let trivialRight = rightBits.IsEmpty;
                $.$spc.System.Diagnostics.Debug.Assert$1(!(trivialLeft && trivialRight), "Trivial cases should be handled on the caller operator");
                /*BigInteger*/ let result;
                /*uint[]?*/ let bitsFromPool = null;
                if (trivialLeft)
                {
                    $.$spc.System.Diagnostics.Debug.Assert$1(!rightBits.IsEmpty, "!rightBits.IsEmpty");
                    /*int*/ let size = ((rightBits.Length + 1) | 0);
                    /*Span<uint>*/ let bits = (BigInt((size >>> 0)) <= BigInt($.$srn.System.Numerics.BigIntegerCalculator.StackAllocThreshold) ? $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.StackAllocSpan($.$spc.System.UInt32, $.$srn.System.Numerics.BigIntegerCalculator.StackAllocThreshold, null) : $.$spc.System.Span$$($.$spc.System.UInt32).op_Implicit(bitsFromPool = $.$spc.System.Buffers.ArrayPool$$($.$spc.System.UInt32).Shared.Rent(size))).Slice$1(0, size);
                    $.$srn.System.Numerics.BigIntegerCalculator.Add(rightBits, $.$srn.System.Numerics.NumericsHelpers.Abs(leftSign), bits);
                    result = new $.$srn.System.Numerics.BigInteger().$ctor$12($.$spc.System.Span$$($.$spc.System.UInt32).op_Implicit$2(bits), leftSign < 0);
                }
                else if (trivialRight)
                {
                    $.$spc.System.Diagnostics.Debug.Assert$1(!leftBits.IsEmpty, "!leftBits.IsEmpty");
                    /*int*/ let size = ((leftBits.Length + 1) | 0);
                    /*Span<uint>*/ let bits = (BigInt((size >>> 0)) <= BigInt($.$srn.System.Numerics.BigIntegerCalculator.StackAllocThreshold) ? $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.StackAllocSpan($.$spc.System.UInt32, $.$srn.System.Numerics.BigIntegerCalculator.StackAllocThreshold, null) : $.$spc.System.Span$$($.$spc.System.UInt32).op_Implicit(bitsFromPool = $.$spc.System.Buffers.ArrayPool$$($.$spc.System.UInt32).Shared.Rent(size))).Slice$1(0, size);
                    $.$srn.System.Numerics.BigIntegerCalculator.Add(leftBits, $.$srn.System.Numerics.NumericsHelpers.Abs(rightSign), bits);
                    result = new $.$srn.System.Numerics.BigInteger().$ctor$12($.$spc.System.Span$$($.$spc.System.UInt32).op_Implicit$2(bits), leftSign < 0);
                }
                else if (leftBits.Length < rightBits.Length)
                {
                    $.$spc.System.Diagnostics.Debug.Assert$1(!leftBits.IsEmpty && !rightBits.IsEmpty, "!leftBits.IsEmpty && !rightBits.IsEmpty");
                    /*int*/ let size = ((rightBits.Length + 1) | 0);
                    /*Span<uint>*/ let bits = (BigInt((size >>> 0)) <= BigInt($.$srn.System.Numerics.BigIntegerCalculator.StackAllocThreshold) ? $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.StackAllocSpan($.$spc.System.UInt32, $.$srn.System.Numerics.BigIntegerCalculator.StackAllocThreshold, null) : $.$spc.System.Span$$($.$spc.System.UInt32).op_Implicit(bitsFromPool = $.$spc.System.Buffers.ArrayPool$$($.$spc.System.UInt32).Shared.Rent(size))).Slice$1(0, size);
                    $.$srn.System.Numerics.BigIntegerCalculator.Add$1(rightBits, leftBits, bits);
                    result = new $.$srn.System.Numerics.BigInteger().$ctor$12($.$spc.System.Span$$($.$spc.System.UInt32).op_Implicit$2(bits), leftSign < 0);
                }
                else 
                {
                    $.$spc.System.Diagnostics.Debug.Assert$1(!leftBits.IsEmpty && !rightBits.IsEmpty, "!leftBits.IsEmpty && !rightBits.IsEmpty");
                    /*int*/ let size = ((leftBits.Length + 1) | 0);
                    /*Span<uint>*/ let bits = (BigInt((size >>> 0)) <= BigInt($.$srn.System.Numerics.BigIntegerCalculator.StackAllocThreshold) ? $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.StackAllocSpan($.$spc.System.UInt32, $.$srn.System.Numerics.BigIntegerCalculator.StackAllocThreshold, null) : $.$spc.System.Span$$($.$spc.System.UInt32).op_Implicit(bitsFromPool = $.$spc.System.Buffers.ArrayPool$$($.$spc.System.UInt32).Shared.Rent(size))).Slice$1(0, size);
                    $.$srn.System.Numerics.BigIntegerCalculator.Add$1(leftBits, rightBits, bits);
                    result = new $.$srn.System.Numerics.BigInteger().$ctor$12($.$spc.System.Span$$($.$spc.System.UInt32).op_Implicit$2(bits), leftSign < 0);
                }
                if (bitsFromPool !== null)
                {
                    $.$spc.System.Buffers.ArrayPool$$($.$spc.System.UInt32).Shared.Return(bitsFromPool, false);
                }
                return result;
            }
            static /*BigInteger */ op_Subtraction(/*BigInteger*/ left, /*BigInteger*/ right)
            {
                left.AssertValid();
                right.AssertValid();
                if (left._bits === null && right._bits === null)
                {
                    return $.$srn.System.Numerics.BigInteger.op_Implicit$4($.$cast(left._sign, $.$spc.System.Int64) - BigInt(right._sign));
                }
                if (left._sign < 0 !== right._sign < 0)
                {
                    return $.$srn.System.Numerics.BigInteger.Add$1($.$spc.System.ReadOnlySpan$$($.$spc.System.UInt32).op_Implicit(left._bits), left._sign, $.$spc.System.ReadOnlySpan$$($.$spc.System.UInt32).op_Implicit(right._bits), ((-1 * right._sign) | 0));
                }
                return $.$srn.System.Numerics.BigInteger.Subtract$1($.$spc.System.ReadOnlySpan$$($.$spc.System.UInt32).op_Implicit(left._bits), left._sign, $.$spc.System.ReadOnlySpan$$($.$spc.System.UInt32).op_Implicit(right._bits), right._sign);
            }
            static /*BigInteger */ Subtract$1(/*ReadOnlySpan<uint>*/ leftBits, /*int*/ leftSign, /*ReadOnlySpan<uint>*/ rightBits, /*int*/ rightSign)
            {
                /*bool*/ let trivialLeft = leftBits.IsEmpty;
                /*bool*/ let trivialRight = rightBits.IsEmpty;
                $.$spc.System.Diagnostics.Debug.Assert$1(!(trivialLeft && trivialRight), "Trivial cases should be handled on the caller operator");
                /*BigInteger*/ let result;
                /*uint[]?*/ let bitsFromPool = null;
                if (trivialLeft)
                {
                    $.$spc.System.Diagnostics.Debug.Assert$1(!rightBits.IsEmpty, "!rightBits.IsEmpty");
                    /*int*/ let size = rightBits.Length;
                    /*Span<uint>*/ let bits = (size <= $.$srn.System.Numerics.BigIntegerCalculator.StackAllocThreshold ? $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.StackAllocSpan($.$spc.System.UInt32, $.$srn.System.Numerics.BigIntegerCalculator.StackAllocThreshold, null) : $.$spc.System.Span$$($.$spc.System.UInt32).op_Implicit(bitsFromPool = $.$spc.System.Buffers.ArrayPool$$($.$spc.System.UInt32).Shared.Rent(size))).Slice$1(0, size);
                    $.$srn.System.Numerics.BigIntegerCalculator.Subtract(rightBits, $.$srn.System.Numerics.NumericsHelpers.Abs(leftSign), bits);
                    result = new $.$srn.System.Numerics.BigInteger().$ctor$12($.$spc.System.Span$$($.$spc.System.UInt32).op_Implicit$2(bits), leftSign >= 0);
                }
                else if (trivialRight)
                {
                    $.$spc.System.Diagnostics.Debug.Assert$1(!leftBits.IsEmpty, "!leftBits.IsEmpty");
                    /*int*/ let size = leftBits.Length;
                    /*Span<uint>*/ let bits = (size <= $.$srn.System.Numerics.BigIntegerCalculator.StackAllocThreshold ? $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.StackAllocSpan($.$spc.System.UInt32, $.$srn.System.Numerics.BigIntegerCalculator.StackAllocThreshold, null) : $.$spc.System.Span$$($.$spc.System.UInt32).op_Implicit(bitsFromPool = $.$spc.System.Buffers.ArrayPool$$($.$spc.System.UInt32).Shared.Rent(size))).Slice$1(0, size);
                    $.$srn.System.Numerics.BigIntegerCalculator.Subtract(leftBits, $.$srn.System.Numerics.NumericsHelpers.Abs(rightSign), bits);
                    result = new $.$srn.System.Numerics.BigInteger().$ctor$12($.$spc.System.Span$$($.$spc.System.UInt32).op_Implicit$2(bits), leftSign < 0);
                }
                else if ($.$srn.System.Numerics.BigIntegerCalculator.Compare(leftBits, rightBits) < 0)
                {
                    /*int*/ let size = rightBits.Length;
                    /*Span<uint>*/ let bits = (size <= $.$srn.System.Numerics.BigIntegerCalculator.StackAllocThreshold ? $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.StackAllocSpan($.$spc.System.UInt32, $.$srn.System.Numerics.BigIntegerCalculator.StackAllocThreshold, null) : $.$spc.System.Span$$($.$spc.System.UInt32).op_Implicit(bitsFromPool = $.$spc.System.Buffers.ArrayPool$$($.$spc.System.UInt32).Shared.Rent(size))).Slice$1(0, size);
                    $.$srn.System.Numerics.BigIntegerCalculator.Subtract$1(rightBits, leftBits, bits);
                    result = new $.$srn.System.Numerics.BigInteger().$ctor$12($.$spc.System.Span$$($.$spc.System.UInt32).op_Implicit$2(bits), leftSign >= 0);
                }
                else 
                {
                    $.$spc.System.Diagnostics.Debug.Assert$1(!leftBits.IsEmpty && !rightBits.IsEmpty, "!leftBits.IsEmpty && !rightBits.IsEmpty");
                    /*int*/ let size = leftBits.Length;
                    /*Span<uint>*/ let bits = (size <= $.$srn.System.Numerics.BigIntegerCalculator.StackAllocThreshold ? $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.StackAllocSpan($.$spc.System.UInt32, $.$srn.System.Numerics.BigIntegerCalculator.StackAllocThreshold, null) : $.$spc.System.Span$$($.$spc.System.UInt32).op_Implicit(bitsFromPool = $.$spc.System.Buffers.ArrayPool$$($.$spc.System.UInt32).Shared.Rent(size))).Slice$1(0, size);
                    $.$srn.System.Numerics.BigIntegerCalculator.Subtract$1(leftBits, rightBits, bits);
                    result = new $.$srn.System.Numerics.BigInteger().$ctor$12($.$spc.System.Span$$($.$spc.System.UInt32).op_Implicit$2(bits), leftSign < 0);
                }
                if (bitsFromPool !== null)
                {
                    $.$spc.System.Buffers.ArrayPool$$($.$spc.System.UInt32).Shared.Return(bitsFromPool, false);
                }
                return result;
            }
            static /*byte */ op_Explicit(/*BigInteger*/ value)
            {
                return $.$cast(($.$srn.System.Numerics.BigInteger.op_Explicit$6(value)), $.$spc.System.Byte);
            }
            static /*char */ op_Explicit$1(/*BigInteger*/ value)
            {
                return $.$cast(($.$srn.System.Numerics.BigInteger.op_Explicit$6(value)), $.$spc.System.Char);
            }
            static /*decimal */ op_Explicit$2(/*BigInteger*/ value)
            {
                value.AssertValid();
                if (value._bits === null)
                {
                    return $.$spc.System.Decimal.op_Implicit$5(value._sign);
                }
                /*int*/ let length = value._bits.length;
                if (length > 3)
                {
                    throw new $.$spc.System.OverflowException().$ctor$14($.$srn.System.SR.Overflow_Decimal);
                }
                /*int*/ let lo = 0, mi = 0, hi = 0;
                //unchecked
                {
                    if (length > 2)
                    {
                        hi = (value._bits[2] | 0);
                    }
                    if (length > 1)
                    {
                        mi = (value._bits[1] | 0);
                    }
                    if (length > 0)
                    {
                        lo = (value._bits[0] | 0);
                    }
                }
                return new $.$spc.System.Decimal().$ctor$11(lo, mi, hi, value._sign < 0, 0);
            }
            static /*double */ op_Explicit$3(/*BigInteger*/ value)
            {
                value.AssertValid();
                /*int*/ let sign = value._sign;
                /*uint[]?*/ let bits = value._bits;
                if (bits === null)
                {
                    return sign;
                }
                /*int*/ let length = bits.length;
                /*int*/ let InfinityLength = $.trunc(1024 / 32/*kcbitUint*/);
                if (length > InfinityLength)
                {
                    if (sign === 1)
                    {
                        return Number.POSITIVE_INFINITY/*double.PositiveInfinity*/;
                    }
                    else 
                    {
                        return Number.NEGATIVE_INFINITY/*double.NegativeInfinity*/;
                    }
                }
                /*ulong*/ let h = BigInt($.$spc.System.Array.$ReadT1.call(bits, ((length - 1) | 0)));
                /*ulong*/ let m = BigInt(length > 1 ? $.$spc.System.Array.$ReadT1.call(bits, ((length - 2) | 0)) : 0);
                /*ulong*/ let l = BigInt(length > 2 ? $.$spc.System.Array.$ReadT1.call(bits, ((length - 3) | 0)) : 0);
                /*int*/ let z = $.$spc.System.Numerics.BitOperations.LeadingZeroCount($.$cast(h, $.$spc.System.UInt32));
                /*int*/ let exp = (((((((length - 2) | 0)) * 32) | 0) - z) | 0);
                /*ulong*/ let man = (BigInt.asUintN(64, h << BigInt(((32 + z) | 0)))) | (BigInt.asUintN(64, m << BigInt(z))) | (l >> BigInt(((32 - z) | 0)));
                return $.$srn.System.Numerics.NumericsHelpers.GetDoubleFromParts(sign, exp, man);
            }
            static /*Half */ op_Explicit$4(/*BigInteger*/ value)
            {
                return $.$spc.System.Half.op_Explicit$2($.$srn.System.Numerics.BigInteger.op_Explicit$3(value));
            }
            static /*short */ op_Explicit$5(/*BigInteger*/ value)
            {
                return $.$cast(($.$srn.System.Numerics.BigInteger.op_Explicit$6(value)), $.$spc.System.Int16);
            }
            static /*int */ op_Explicit$6(/*BigInteger*/ value)
            {
                value.AssertValid();
                if (value._bits === null)
                {
                    return value._sign;
                }
                if (value._bits.length > 1)
                {
                    throw new $.$spc.System.OverflowException().$ctor$14($.$srn.System.SR.Overflow_Int32);
                }
                if (value._sign > 0)
                {
                    return ($.$spc.System.Array.$ReadT1.call(value._bits, 0) | 0);
                }
                if ($.$spc.System.Array.$ReadT1.call(value._bits, 0) > 2147483648/*kuMaskHighBit*/)
                {
                    throw new $.$spc.System.OverflowException().$ctor$14($.$srn.System.SR.Overflow_Int32);
                }
                return -(value._bits[0] | 0);
            }
            static /*long */ op_Explicit$7(/*BigInteger*/ value)
            {
                value.AssertValid();
                if (value._bits === null)
                {
                    return BigInt(value._sign);
                }
                /*int*/ let len = value._bits.length;
                if (len > 2)
                {
                    throw new $.$spc.System.OverflowException().$ctor$14($.$srn.System.SR.Overflow_Int64);
                }
                /*ulong*/ let uu;
                if (len > 1)
                {
                    uu = $.$srn.System.Numerics.NumericsHelpers.MakeUInt64($.$spc.System.Array.$ReadT1.call(value._bits, 1), $.$spc.System.Array.$ReadT1.call(value._bits, 0));
                }
                else 
                {
                    uu = BigInt($.$spc.System.Array.$ReadT1.call(value._bits, 0));
                }
                /*long*/ let ll = value._sign > 0 ? $.$cast(uu, $.$spc.System.Int64) : -$.$cast(uu, $.$spc.System.Int64);
                if ((ll > 0n && value._sign > 0) || (ll < 0n && value._sign < 0))
                {
                    return ll;
                }
                throw new $.$spc.System.OverflowException().$ctor$14($.$srn.System.SR.Overflow_Int64);
            }
            static /*Int128 */ op_Explicit$8(/*BigInteger*/ value)
            {
                value.AssertValid();
                if (value._bits === null)
                {
                    return $.$spc.System.Int128.op_Implicit$3(value._sign);
                }
                /*int*/ let len = value._bits.length;
                if (len > 4)
                {
                    throw new $.$spc.System.OverflowException().$ctor$14($.$srn.System.SR.Overflow_Int128);
                }
                /*UInt128*/ let uu;
                if (len > 2)
                {
                    uu = new $.$spc.System.UInt128().$ctor$2($.$srn.System.Numerics.NumericsHelpers.MakeUInt64((len > 3) ? $.$spc.System.Array.$ReadT1.call(value._bits, 3) : 0, $.$spc.System.Array.$ReadT1.call(value._bits, 2)), $.$srn.System.Numerics.NumericsHelpers.MakeUInt64($.$spc.System.Array.$ReadT1.call(value._bits, 1), $.$spc.System.Array.$ReadT1.call(value._bits, 0)));
                }
                else if (len > 1)
                {
                    uu = $.$spc.System.UInt128.op_Implicit$4($.$srn.System.Numerics.NumericsHelpers.MakeUInt64($.$spc.System.Array.$ReadT1.call(value._bits, 1), $.$spc.System.Array.$ReadT1.call(value._bits, 0)));
                }
                else 
                {
                    uu = $.$spc.System.UInt128.op_Implicit$3($.$spc.System.Array.$ReadT1.call(value._bits, 0));
                }
                /*Int128*/ let ll = (value._sign > 0) ? $.$spc.System.UInt128.op_Explicit$8(uu) : $.$spc.System.Int128.op_UnaryNegation($.$spc.System.UInt128.op_Explicit$8(uu));
                if ((($.$spc.System.Int128.op_GreaterThan(ll, $.$spc.System.Int128.op_Implicit$3(0))) && (value._sign > 0)) || (($.$spc.System.Int128.op_LessThan(ll, $.$spc.System.Int128.op_Implicit$3(0))) && (value._sign < 0)))
                {
                    return ll;
                }
                throw new $.$spc.System.OverflowException().$ctor$14($.$srn.System.SR.Overflow_Int128);
            }
            static /*nint */ op_Explicit$9(/*BigInteger*/ value)
            {
                if ($.$spc.System.Environment.Is64BitProcess)
                {
                    return $.$cast($.$srn.System.Numerics.BigInteger.op_Explicit$7(value), $.$spc.System.IntPtr);
                }
                else 
                {
                    return $.$srn.System.Numerics.BigInteger.op_Explicit$6(value);
                }
            }
            static /*sbyte */ op_Explicit$10(/*BigInteger*/ value)
            {
                return $.$cast(($.$srn.System.Numerics.BigInteger.op_Explicit$6(value)), $.$spc.System.SByte);
            }
            static /*float */ op_Explicit$11(/*BigInteger*/ value)
            {
                return $.$cast(($.$srn.System.Numerics.BigInteger.op_Explicit$3(value)), $.$spc.System.Single);
            }
            static /*ushort */ op_Explicit$12(/*BigInteger*/ value)
            {
                return $.$cast(($.$srn.System.Numerics.BigInteger.op_Explicit$6(value)), $.$spc.System.UInt16);
            }
            static /*uint */ op_Explicit$13(/*BigInteger*/ value)
            {
                value.AssertValid();
                if (value._bits === null)
                {
                    return (value._sign >>> 0);
                }
                else if (value._bits.length > 1 || value._sign < 0)
                {
                    throw new $.$spc.System.OverflowException().$ctor$14($.$srn.System.SR.Overflow_UInt32);
                }
                else 
                {
                    return $.$spc.System.Array.$ReadT1.call(value._bits, 0);
                }
            }
            static /*ulong */ op_Explicit$14(/*BigInteger*/ value)
            {
                value.AssertValid();
                if (value._bits === null)
                {
                    return $.$cast(value._sign, $.$spc.System.UInt64);
                }
                /*int*/ let len = value._bits.length;
                if (len > 2 || value._sign < 0)
                {
                    throw new $.$spc.System.OverflowException().$ctor$14($.$srn.System.SR.Overflow_UInt64);
                }
                if (len > 1)
                {
                    return $.$srn.System.Numerics.NumericsHelpers.MakeUInt64($.$spc.System.Array.$ReadT1.call(value._bits, 1), $.$spc.System.Array.$ReadT1.call(value._bits, 0));
                }
                return BigInt($.$spc.System.Array.$ReadT1.call(value._bits, 0));
            }
            static /*UInt128 */ op_Explicit$15(/*BigInteger*/ value)
            {
                value.AssertValid();
                if (value._bits === null)
                {
                    return $.$spc.System.UInt128.op_Explicit$19(value._sign);
                }
                /*int*/ let len = value._bits.length;
                if ((len > 4) || (value._sign < 0))
                {
                    throw new $.$spc.System.OverflowException().$ctor$14($.$srn.System.SR.Overflow_UInt128);
                }
                if (len > 2)
                {
                    return new $.$spc.System.UInt128().$ctor$2($.$srn.System.Numerics.NumericsHelpers.MakeUInt64((len > 3) ? $.$spc.System.Array.$ReadT1.call(value._bits, 3) : 0, $.$spc.System.Array.$ReadT1.call(value._bits, 2)), $.$srn.System.Numerics.NumericsHelpers.MakeUInt64($.$spc.System.Array.$ReadT1.call(value._bits, 1), $.$spc.System.Array.$ReadT1.call(value._bits, 0)));
                }
                else if (len > 1)
                {
                    return $.$spc.System.UInt128.op_Implicit$4($.$srn.System.Numerics.NumericsHelpers.MakeUInt64($.$spc.System.Array.$ReadT1.call(value._bits, 1), $.$spc.System.Array.$ReadT1.call(value._bits, 0)));
                }
                return $.$spc.System.UInt128.op_Implicit$3($.$spc.System.Array.$ReadT1.call(value._bits, 0));
            }
            static /*nuint */ op_Explicit$16(/*BigInteger*/ value)
            {
                if ($.$spc.System.Environment.Is64BitProcess)
                {
                    return $.$cast($.$srn.System.Numerics.BigInteger.op_Explicit$14(value), $.$spc.System.UIntPtr);
                }
                else 
                {
                    return $.$srn.System.Numerics.BigInteger.op_Explicit$13(value);
                }
            }
            static /*BigInteger */ op_Explicit$17(/*decimal*/ value)
            {
                return new $.$srn.System.Numerics.BigInteger().$ctor$8(value);
            }
            static /*BigInteger */ op_Explicit$18(/*double*/ value)
            {
                return new $.$srn.System.Numerics.BigInteger().$ctor$7(value);
            }
            static /*BigInteger */ op_Explicit$19(/*Half*/ value)
            {
                return new $.$srn.System.Numerics.BigInteger().$ctor$6($.$spc.System.Half.op_Explicit$27(value));
            }
            static /*BigInteger */ op_Explicit$20(/*Complex*/ value)
            {
                if (value.Imaginary !== 0)
                {
                    $.$srn.System.ThrowHelper.ThrowOverflowException();
                }
                return $.$srn.System.Numerics.BigInteger.op_Explicit$18(value.Real);
            }
            static /*BigInteger */ op_Explicit$21(/*float*/ value)
            {
                return new $.$srn.System.Numerics.BigInteger().$ctor$6(value);
            }
            static /*BigInteger */ op_Implicit(/*byte*/ value)
            {
                return new $.$srn.System.Numerics.BigInteger().$ctor$2(value);
            }
            static /*BigInteger */ op_Implicit$1(/*char*/ value)
            {
                return new $.$srn.System.Numerics.BigInteger().$ctor$2(value);
            }
            static /*BigInteger */ op_Implicit$2(/*short*/ value)
            {
                return new $.$srn.System.Numerics.BigInteger().$ctor$2(value);
            }
            static /*BigInteger */ op_Implicit$3(/*int*/ value)
            {
                return new $.$srn.System.Numerics.BigInteger().$ctor$2(value);
            }
            static /*BigInteger */ op_Implicit$4(/*long*/ value)
            {
                return new $.$srn.System.Numerics.BigInteger().$ctor$4(value);
            }
            static /*BigInteger */ op_Implicit$5(/*Int128*/ value)
            {
                /*int*/ let sign;
                /*uint[]?*/ let bits;
                if (($.$spc.System.Int128.op_Implicit$3(-2147483648/*int.MinValue*/) < value) && ($.$spc.System.Int128.op_LessThanOrEqual(value, $.$spc.System.Int128.op_Implicit$3(2147483647/*int.MaxValue*/))))
                {
                    sign = $.$spc.System.Int128.op_Explicit$6(value);
                    bits = null;
                }
                else if ($.$spc.System.Int128.op_Equality(value, $.$spc.System.Int128.op_Implicit$3(-2147483648/*int.MinValue*/)))
                {
                    return $.$srn.System.Numerics.BigInteger.s_bnMinInt;
                }
                else 
                {
                    /*UInt128*/ let x;
                    if ($.$spc.System.Int128.op_LessThan(value, $.$spc.System.Int128.op_Implicit$3(0)))
                    {
                        x = $.$spc.System.Int128.op_Explicit$14(($.$spc.System.Int128.op_UnaryNegation(value)));
                        sign = -1;
                    }
                    else 
                    {
                        x = $.$spc.System.Int128.op_Explicit$14(value);
                        sign = +1;
                    }
                    if ($.$spc.System.UInt128.op_LessThanOrEqual(x, $.$spc.System.UInt128.op_Implicit$3(4294967295/*uint.MaxValue*/)))
                    {
                        bits = $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$spc.System.UInt32), null, [1], null);
                        $.$spc.System.Array.$WriteT1.call(bits, $.$spc.System.UInt128.op_Explicit$13(($.$spc.System.UInt128.op_RightShift(x, (((32/*kcbitUint*/ * 0) | 0))))), 0);
                    }
                    else if ($.$spc.System.UInt128.op_LessThanOrEqual(x, $.$spc.System.UInt128.op_Implicit$4(18446744073709551615n)))
                    {
                        bits = $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$spc.System.UInt32), null, [2], null);
                        $.$spc.System.Array.$WriteT1.call(bits, $.$spc.System.UInt128.op_Explicit$13(($.$spc.System.UInt128.op_RightShift(x, (((32/*kcbitUint*/ * 0) | 0))))), 0);
                        $.$spc.System.Array.$WriteT1.call(bits, $.$spc.System.UInt128.op_Explicit$13(($.$spc.System.UInt128.op_RightShift(x, (((32/*kcbitUint*/ * 1) | 0))))), 1);
                    }
                    else if ($.$spc.System.UInt128.op_LessThanOrEqual(x, new $.$spc.System.UInt128().$ctor$2(4294967295n, 18446744073709551615n)))
                    {
                        bits = $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$spc.System.UInt32), null, [3], null);
                        $.$spc.System.Array.$WriteT1.call(bits, $.$spc.System.UInt128.op_Explicit$13(($.$spc.System.UInt128.op_RightShift(x, (((32/*kcbitUint*/ * 0) | 0))))), 0);
                        $.$spc.System.Array.$WriteT1.call(bits, $.$spc.System.UInt128.op_Explicit$13(($.$spc.System.UInt128.op_RightShift(x, (((32/*kcbitUint*/ * 1) | 0))))), 1);
                        $.$spc.System.Array.$WriteT1.call(bits, $.$spc.System.UInt128.op_Explicit$13(($.$spc.System.UInt128.op_RightShift(x, (((32/*kcbitUint*/ * 2) | 0))))), 2);
                    }
                    else 
                    {
                        bits = $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$spc.System.UInt32), null, [4], null);
                        $.$spc.System.Array.$WriteT1.call(bits, $.$spc.System.UInt128.op_Explicit$13(($.$spc.System.UInt128.op_RightShift(x, (((32/*kcbitUint*/ * 0) | 0))))), 0);
                        $.$spc.System.Array.$WriteT1.call(bits, $.$spc.System.UInt128.op_Explicit$13(($.$spc.System.UInt128.op_RightShift(x, (((32/*kcbitUint*/ * 1) | 0))))), 1);
                        $.$spc.System.Array.$WriteT1.call(bits, $.$spc.System.UInt128.op_Explicit$13(($.$spc.System.UInt128.op_RightShift(x, (((32/*kcbitUint*/ * 2) | 0))))), 2);
                        $.$spc.System.Array.$WriteT1.call(bits, $.$spc.System.UInt128.op_Explicit$13(($.$spc.System.UInt128.op_RightShift(x, (((32/*kcbitUint*/ * 3) | 0))))), 3);
                    }
                }
                return new $.$srn.System.Numerics.BigInteger().$ctor$11(sign, bits);
            }
            static /*BigInteger */ op_Implicit$6(/*nint*/ value)
            {
                if ($.$spc.System.Environment.Is64BitProcess)
                {
                    return new $.$srn.System.Numerics.BigInteger().$ctor$4(BigInt(value));
                }
                else 
                {
                    return new $.$srn.System.Numerics.BigInteger().$ctor$2(value);
                }
            }
            static /*BigInteger */ op_Implicit$7(/*sbyte*/ value)
            {
                return new $.$srn.System.Numerics.BigInteger().$ctor$2(value);
            }
            static /*BigInteger */ op_Implicit$8(/*ushort*/ value)
            {
                return new $.$srn.System.Numerics.BigInteger().$ctor$2(value);
            }
            static /*BigInteger */ op_Implicit$9(/*uint*/ value)
            {
                return new $.$srn.System.Numerics.BigInteger().$ctor$3(value);
            }
            static /*BigInteger */ op_Implicit$10(/*ulong*/ value)
            {
                return new $.$srn.System.Numerics.BigInteger().$ctor$5(value);
            }
            static /*BigInteger */ op_Implicit$11(/*UInt128*/ value)
            {
                /*int*/ let sign = +1;
                /*uint[]?*/ let bits;
                if ($.$spc.System.UInt128.op_LessThanOrEqual(value, $.$spc.System.UInt128.op_Implicit$3(2147483647/*int.MaxValue*/)))
                {
                    sign = $.$spc.System.UInt128.op_Explicit$6(value);
                    bits = null;
                }
                else if ($.$spc.System.UInt128.op_LessThanOrEqual(value, $.$spc.System.UInt128.op_Implicit$3(4294967295/*uint.MaxValue*/)))
                {
                    bits = $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$spc.System.UInt32), null, [1], null);
                    $.$spc.System.Array.$WriteT1.call(bits, $.$spc.System.UInt128.op_Explicit$13(($.$spc.System.UInt128.op_RightShift(value, (((32/*kcbitUint*/ * 0) | 0))))), 0);
                }
                else if ($.$spc.System.UInt128.op_LessThanOrEqual(value, $.$spc.System.UInt128.op_Implicit$4(18446744073709551615n)))
                {
                    bits = $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$spc.System.UInt32), null, [2], null);
                    $.$spc.System.Array.$WriteT1.call(bits, $.$spc.System.UInt128.op_Explicit$13(($.$spc.System.UInt128.op_RightShift(value, (((32/*kcbitUint*/ * 0) | 0))))), 0);
                    $.$spc.System.Array.$WriteT1.call(bits, $.$spc.System.UInt128.op_Explicit$13(($.$spc.System.UInt128.op_RightShift(value, (((32/*kcbitUint*/ * 1) | 0))))), 1);
                }
                else if ($.$spc.System.UInt128.op_LessThanOrEqual(value, new $.$spc.System.UInt128().$ctor$2(4294967295n, 18446744073709551615n)))
                {
                    bits = $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$spc.System.UInt32), null, [3], null);
                    $.$spc.System.Array.$WriteT1.call(bits, $.$spc.System.UInt128.op_Explicit$13(($.$spc.System.UInt128.op_RightShift(value, (((32/*kcbitUint*/ * 0) | 0))))), 0);
                    $.$spc.System.Array.$WriteT1.call(bits, $.$spc.System.UInt128.op_Explicit$13(($.$spc.System.UInt128.op_RightShift(value, (((32/*kcbitUint*/ * 1) | 0))))), 1);
                    $.$spc.System.Array.$WriteT1.call(bits, $.$spc.System.UInt128.op_Explicit$13(($.$spc.System.UInt128.op_RightShift(value, (((32/*kcbitUint*/ * 2) | 0))))), 2);
                }
                else 
                {
                    bits = $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$spc.System.UInt32), null, [4], null);
                    $.$spc.System.Array.$WriteT1.call(bits, $.$spc.System.UInt128.op_Explicit$13(($.$spc.System.UInt128.op_RightShift(value, (((32/*kcbitUint*/ * 0) | 0))))), 0);
                    $.$spc.System.Array.$WriteT1.call(bits, $.$spc.System.UInt128.op_Explicit$13(($.$spc.System.UInt128.op_RightShift(value, (((32/*kcbitUint*/ * 1) | 0))))), 1);
                    $.$spc.System.Array.$WriteT1.call(bits, $.$spc.System.UInt128.op_Explicit$13(($.$spc.System.UInt128.op_RightShift(value, (((32/*kcbitUint*/ * 2) | 0))))), 2);
                    $.$spc.System.Array.$WriteT1.call(bits, $.$spc.System.UInt128.op_Explicit$13(($.$spc.System.UInt128.op_RightShift(value, (((32/*kcbitUint*/ * 3) | 0))))), 3);
                }
                return new $.$srn.System.Numerics.BigInteger().$ctor$11(sign, bits);
            }
            static /*BigInteger */ op_Implicit$12(/*nuint*/ value)
            {
                if ($.$spc.System.Environment.Is64BitProcess)
                {
                    return new $.$srn.System.Numerics.BigInteger().$ctor$5(BigInt(value));
                }
                else 
                {
                    return new $.$srn.System.Numerics.BigInteger().$ctor$3(value);
                }
            }
            static /*BigInteger */ op_BitwiseAnd(/*BigInteger*/ left, /*BigInteger*/ right)
            {
                if (left.IsZero || right.IsZero)
                {
                    return $.$srn.System.Numerics.BigInteger.Zero;
                }
                if (left._bits === null && right._bits === null)
                {
                    return $.$srn.System.Numerics.BigInteger.op_Implicit$3(left._sign & right._sign);
                }
                /*uint*/ let xExtend = (left._sign < 0) ? 4294967295/*uint.MaxValue*/ : 0;
                /*uint*/ let yExtend = (right._sign < 0) ? 4294967295/*uint.MaxValue*/ : 0;
                /*uint[]?*/ let leftBufferFromPool = null;
                const $t1 = () => left._bits;
                /*int*/ let size = ((($.$ifnn($t1, ($t) => $t.length) ?? 1) + 1) | 0);
                /*Span<uint>*/ let x = (BigInt((size >>> 0)) <= BigInt($.$srn.System.Numerics.BigIntegerCalculator.StackAllocThreshold) ? $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.StackAllocSpan($.$spc.System.UInt32, $.$srn.System.Numerics.BigIntegerCalculator.StackAllocThreshold, null) : $.$spc.System.Span$$($.$spc.System.UInt32).op_Implicit(leftBufferFromPool = $.$spc.System.Buffers.ArrayPool$$($.$spc.System.UInt32).Shared.Rent(size))).Slice$1(0, size);
                x = x.Slice$1(0, left.WriteTo(x));
                /*uint[]?*/ let rightBufferFromPool = null;
                const $t2 = () => right._bits;
                size = ((($.$ifnn($t2, ($t) => $t.length) ?? 1) + 1) | 0);
                /*Span<uint>*/ let y = (BigInt((size >>> 0)) <= BigInt($.$srn.System.Numerics.BigIntegerCalculator.StackAllocThreshold) ? $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.StackAllocSpan($.$spc.System.UInt32, $.$srn.System.Numerics.BigIntegerCalculator.StackAllocThreshold, null) : $.$spc.System.Span$$($.$spc.System.UInt32).op_Implicit(rightBufferFromPool = $.$spc.System.Buffers.ArrayPool$$($.$spc.System.UInt32).Shared.Rent(size))).Slice$1(0, size);
                y = y.Slice$1(0, right.WriteTo(y));
                /*uint[]?*/ let resultBufferFromPool = null;
                size = $.$spc.System.Math.Max$4(x.Length, y.Length);
                /*Span<uint>*/ let z = (size <= $.$srn.System.Numerics.BigIntegerCalculator.StackAllocThreshold ? $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.StackAllocSpan($.$spc.System.UInt32, $.$srn.System.Numerics.BigIntegerCalculator.StackAllocThreshold, null) : $.$spc.System.Span$$($.$spc.System.UInt32).op_Implicit(resultBufferFromPool = $.$spc.System.Buffers.ArrayPool$$($.$spc.System.UInt32).Shared.Rent(size))).Slice$1(0, size);
                for(/*int*/ let i = 0; i < z.Length; i++)
                {
                    /*uint*/ let xu = ((i >>> 0) < (x.Length >>> 0)) ? x.get_Item(i).$v : xExtend;
                    /*uint*/ let yu = ((i >>> 0) < (y.Length >>> 0)) ? y.get_Item(i).$v : yExtend;
                    z.get_Item(i).$v = xu & yu;
                }
                if (leftBufferFromPool !== null)
                {
                    $.$spc.System.Buffers.ArrayPool$$($.$spc.System.UInt32).Shared.Return(leftBufferFromPool, false);
                }
                if (rightBufferFromPool !== null)
                {
                    $.$spc.System.Buffers.ArrayPool$$($.$spc.System.UInt32).Shared.Return(rightBufferFromPool, false);
                }
                /*var*/ let result = new $.$srn.System.Numerics.BigInteger().$ctor$13(z);
                if (resultBufferFromPool !== null)
                {
                    $.$spc.System.Buffers.ArrayPool$$($.$spc.System.UInt32).Shared.Return(resultBufferFromPool, false);
                }
                return result;
            }
            static /*BigInteger */ op_BitwiseOr(/*BigInteger*/ left, /*BigInteger*/ right)
            {
                if (left.IsZero)
                {
                    return right;
                }
                if (right.IsZero)
                {
                    return left;
                }
                if (left._bits === null && right._bits === null)
                {
                    return $.$srn.System.Numerics.BigInteger.op_Implicit$3(left._sign | right._sign);
                }
                /*uint*/ let xExtend = (left._sign < 0) ? 4294967295/*uint.MaxValue*/ : 0;
                /*uint*/ let yExtend = (right._sign < 0) ? 4294967295/*uint.MaxValue*/ : 0;
                /*uint[]?*/ let leftBufferFromPool = null;
                const $t1 = () => left._bits;
                /*int*/ let size = ((($.$ifnn($t1, ($t) => $t.length) ?? 1) + 1) | 0);
                /*Span<uint>*/ let x = (BigInt((size >>> 0)) <= BigInt($.$srn.System.Numerics.BigIntegerCalculator.StackAllocThreshold) ? $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.StackAllocSpan($.$spc.System.UInt32, $.$srn.System.Numerics.BigIntegerCalculator.StackAllocThreshold, null) : $.$spc.System.Span$$($.$spc.System.UInt32).op_Implicit(leftBufferFromPool = $.$spc.System.Buffers.ArrayPool$$($.$spc.System.UInt32).Shared.Rent(size))).Slice$1(0, size);
                x = x.Slice$1(0, left.WriteTo(x));
                /*uint[]?*/ let rightBufferFromPool = null;
                const $t2 = () => right._bits;
                size = ((($.$ifnn($t2, ($t) => $t.length) ?? 1) + 1) | 0);
                /*Span<uint>*/ let y = (BigInt((size >>> 0)) <= BigInt($.$srn.System.Numerics.BigIntegerCalculator.StackAllocThreshold) ? $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.StackAllocSpan($.$spc.System.UInt32, $.$srn.System.Numerics.BigIntegerCalculator.StackAllocThreshold, null) : $.$spc.System.Span$$($.$spc.System.UInt32).op_Implicit(rightBufferFromPool = $.$spc.System.Buffers.ArrayPool$$($.$spc.System.UInt32).Shared.Rent(size))).Slice$1(0, size);
                y = y.Slice$1(0, right.WriteTo(y));
                /*uint[]?*/ let resultBufferFromPool = null;
                size = $.$spc.System.Math.Max$4(x.Length, y.Length);
                /*Span<uint>*/ let z = (size <= $.$srn.System.Numerics.BigIntegerCalculator.StackAllocThreshold ? $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.StackAllocSpan($.$spc.System.UInt32, $.$srn.System.Numerics.BigIntegerCalculator.StackAllocThreshold, null) : $.$spc.System.Span$$($.$spc.System.UInt32).op_Implicit(resultBufferFromPool = $.$spc.System.Buffers.ArrayPool$$($.$spc.System.UInt32).Shared.Rent(size))).Slice$1(0, size);
                for(/*int*/ let i = 0; i < z.Length; i++)
                {
                    /*uint*/ let xu = ((i >>> 0) < (x.Length >>> 0)) ? x.get_Item(i).$v : xExtend;
                    /*uint*/ let yu = ((i >>> 0) < (y.Length >>> 0)) ? y.get_Item(i).$v : yExtend;
                    z.get_Item(i).$v = xu | yu;
                }
                if (leftBufferFromPool !== null)
                {
                    $.$spc.System.Buffers.ArrayPool$$($.$spc.System.UInt32).Shared.Return(leftBufferFromPool, false);
                }
                if (rightBufferFromPool !== null)
                {
                    $.$spc.System.Buffers.ArrayPool$$($.$spc.System.UInt32).Shared.Return(rightBufferFromPool, false);
                }
                /*var*/ let result = new $.$srn.System.Numerics.BigInteger().$ctor$13(z);
                if (resultBufferFromPool !== null)
                {
                    $.$spc.System.Buffers.ArrayPool$$($.$spc.System.UInt32).Shared.Return(resultBufferFromPool, false);
                }
                return result;
            }
            static /*BigInteger */ op_ExclusiveOr(/*BigInteger*/ left, /*BigInteger*/ right)
            {
                if (left._bits === null && right._bits === null)
                {
                    return $.$srn.System.Numerics.BigInteger.op_Implicit$3(left._sign ^ right._sign);
                }
                /*uint*/ let xExtend = (left._sign < 0) ? 4294967295/*uint.MaxValue*/ : 0;
                /*uint*/ let yExtend = (right._sign < 0) ? 4294967295/*uint.MaxValue*/ : 0;
                /*uint[]?*/ let leftBufferFromPool = null;
                const $t1 = () => left._bits;
                /*int*/ let size = ((($.$ifnn($t1, ($t) => $t.length) ?? 1) + 1) | 0);
                /*Span<uint>*/ let x = (BigInt((size >>> 0)) <= BigInt($.$srn.System.Numerics.BigIntegerCalculator.StackAllocThreshold) ? $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.StackAllocSpan($.$spc.System.UInt32, $.$srn.System.Numerics.BigIntegerCalculator.StackAllocThreshold, null) : $.$spc.System.Span$$($.$spc.System.UInt32).op_Implicit(leftBufferFromPool = $.$spc.System.Buffers.ArrayPool$$($.$spc.System.UInt32).Shared.Rent(size))).Slice$1(0, size);
                x = x.Slice$1(0, left.WriteTo(x));
                /*uint[]?*/ let rightBufferFromPool = null;
                const $t2 = () => right._bits;
                size = ((($.$ifnn($t2, ($t) => $t.length) ?? 1) + 1) | 0);
                /*Span<uint>*/ let y = (BigInt((size >>> 0)) <= BigInt($.$srn.System.Numerics.BigIntegerCalculator.StackAllocThreshold) ? $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.StackAllocSpan($.$spc.System.UInt32, $.$srn.System.Numerics.BigIntegerCalculator.StackAllocThreshold, null) : $.$spc.System.Span$$($.$spc.System.UInt32).op_Implicit(rightBufferFromPool = $.$spc.System.Buffers.ArrayPool$$($.$spc.System.UInt32).Shared.Rent(size))).Slice$1(0, size);
                y = y.Slice$1(0, right.WriteTo(y));
                /*uint[]?*/ let resultBufferFromPool = null;
                size = $.$spc.System.Math.Max$4(x.Length, y.Length);
                /*Span<uint>*/ let z = (size <= $.$srn.System.Numerics.BigIntegerCalculator.StackAllocThreshold ? $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.StackAllocSpan($.$spc.System.UInt32, $.$srn.System.Numerics.BigIntegerCalculator.StackAllocThreshold, null) : $.$spc.System.Span$$($.$spc.System.UInt32).op_Implicit(resultBufferFromPool = $.$spc.System.Buffers.ArrayPool$$($.$spc.System.UInt32).Shared.Rent(size))).Slice$1(0, size);
                for(/*int*/ let i = 0; i < z.Length; i++)
                {
                    /*uint*/ let xu = ((i >>> 0) < (x.Length >>> 0)) ? x.get_Item(i).$v : xExtend;
                    /*uint*/ let yu = ((i >>> 0) < (y.Length >>> 0)) ? y.get_Item(i).$v : yExtend;
                    z.get_Item(i).$v = xu ^ yu;
                }
                if (leftBufferFromPool !== null)
                {
                    $.$spc.System.Buffers.ArrayPool$$($.$spc.System.UInt32).Shared.Return(leftBufferFromPool, false);
                }
                if (rightBufferFromPool !== null)
                {
                    $.$spc.System.Buffers.ArrayPool$$($.$spc.System.UInt32).Shared.Return(rightBufferFromPool, false);
                }
                /*var*/ let result = new $.$srn.System.Numerics.BigInteger().$ctor$13(z);
                if (resultBufferFromPool !== null)
                {
                    $.$spc.System.Buffers.ArrayPool$$($.$spc.System.UInt32).Shared.Return(resultBufferFromPool, false);
                }
                return result;
            }
            static /*BigInteger */ op_LeftShift(/*BigInteger*/ value, /*int*/ shift)
            {
                if (shift === 0)
                {
                    return value;
                }
                if (shift === -2147483648/*int.MinValue*/)
                {
                    return ($.$srn.System.Numerics.BigInteger.op_RightShift(($.$srn.System.Numerics.BigInteger.op_RightShift(value, 2147483647/*int.MaxValue*/)), 1));
                }
                if (shift < 0)
                {
                    return $.$srn.System.Numerics.BigInteger.op_RightShift(value, -shift);
                }
                const { Item1: digitShift, Item2: smallShift } = $.$spc.System.Math.DivRem$6(shift, 32/*kcbitUint*/);
                /*uint[]?*/ let xdFromPool = null;
                const $t1 = () => value._bits;
                /*int*/ let xl = $.$ifnn($t1, ($t) => $t.length) ?? 1;
                /*Span<uint>*/ let xd = (xl <= $.$srn.System.Numerics.BigIntegerCalculator.StackAllocThreshold ? $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.StackAllocSpan($.$spc.System.UInt32, $.$srn.System.Numerics.BigIntegerCalculator.StackAllocThreshold, null) : $.$spc.System.Span$$($.$spc.System.UInt32).op_Implicit(xdFromPool = $.$spc.System.Buffers.ArrayPool$$($.$spc.System.UInt32).Shared.Rent(xl))).Slice$1(0, xl);
                /*bool*/ let negx = value.GetPartsForBitManipulation(xd);
                /*int*/ let zl = ((((xl + digitShift) | 0) + 1) | 0);
                /*uint[]?*/ let zdFromPool = null;
                /*Span<uint>*/ let zd = (BigInt((zl >>> 0)) <= BigInt($.$srn.System.Numerics.BigIntegerCalculator.StackAllocThreshold) ? $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.StackAllocSpan($.$spc.System.UInt32, $.$srn.System.Numerics.BigIntegerCalculator.StackAllocThreshold, null) : $.$spc.System.Span$$($.$spc.System.UInt32).op_Implicit(zdFromPool = $.$spc.System.Buffers.ArrayPool$$($.$spc.System.UInt32).Shared.Rent(zl))).Slice$1(0, zl);
                zd.Clear();
                /*uint*/ let carry = 0;
                if (smallShift === 0)
                {
                    for(/*int*/ let i = 0; i < xd.Length; i++)
                    {
                        zd.get_Item(((i + digitShift) | 0)).$v = xd.get_Item(i).$v;
                    }
                }
                else 
                {
                    /*int*/ let carryShift = ((32/*kcbitUint*/ - smallShift) | 0);
                    /*int*/ let i;
                    for(i = 0; i < xd.Length; i++)
                    {
                        /*uint*/ let rot = xd.get_Item(i).$v;
                        zd.get_Item(((i + digitShift) | 0)).$v = (rot << smallShift) >>> 0 | carry;
                        carry = rot >>> carryShift;
                    }
                }
                zd.get_Item(((zd.Length - 1) | 0)).$v = carry;
                /*var*/ let result = new $.$srn.System.Numerics.BigInteger().$ctor$12($.$spc.System.Span$$($.$spc.System.UInt32).op_Implicit$2(zd), negx);
                if (xdFromPool !== null)
                {
                    $.$spc.System.Buffers.ArrayPool$$($.$spc.System.UInt32).Shared.Return(xdFromPool, false);
                }
                if (zdFromPool !== null)
                {
                    $.$spc.System.Buffers.ArrayPool$$($.$spc.System.UInt32).Shared.Return(zdFromPool, false);
                }
                return result;
            }
            static /*BigInteger */ op_RightShift(/*BigInteger*/ value, /*int*/ shift)
            {
                /*BigInteger*/ let result;
                /*uint[]?*/ let xdFromPool;
                /*int*/ let xl;
                /*Span<uint>*/ let xd;
                /*bool*/ let negx;
                /*bool*/ let trackSignBit;
                /*uint[]?*/ let zdFromPool;
                /*int*/ let zl;
                /*Span<uint>*/ let zd;
                let $gotoJumpState1 = 0;
                $gotoJumpStart1: while(true)
                {
                    switch($gotoJumpState1)
                    {
                        case 0:
                        {
                            if (shift === 0)
                            {
                                return value;
                            }
                            if (shift === -2147483648/*int.MinValue*/)
                            {
                                return ($.$srn.System.Numerics.BigInteger.op_LeftShift(($.$srn.System.Numerics.BigInteger.op_LeftShift(value, 2147483647/*int.MaxValue*/)), 1));
                            }
                            if (shift < 0)
                            {
                                return $.$srn.System.Numerics.BigInteger.op_LeftShift(value, -shift);
                            }
                            const { Item1: digitShift, Item2: smallShift } = $.$spc.System.Math.DivRem$6(shift, 32/*kcbitUint*/);
                            xdFromPool = null;
                            const $t2 = () => value._bits;
                            xl = $.$ifnn($t2, ($t) => $t.length) ?? 1;
                            xd = (xl <= $.$srn.System.Numerics.BigIntegerCalculator.StackAllocThreshold ? $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.StackAllocSpan($.$spc.System.UInt32, $.$srn.System.Numerics.BigIntegerCalculator.StackAllocThreshold, null) : $.$spc.System.Span$$($.$spc.System.UInt32).op_Implicit(xdFromPool = $.$spc.System.Buffers.ArrayPool$$($.$spc.System.UInt32).Shared.Rent(xl))).Slice$1(0, xl);
                            negx = value.GetPartsForBitManipulation(xd);
                            trackSignBit = false;
                            if (negx)
                            {
                                if (BigInt(shift) >= ($.$cast(32/*kcbitUint*/, $.$spc.System.Int64) * BigInt(xd.Length)))
                                {
                                    result = $.$srn.System.Numerics.BigInteger.MinusOne;
                                    $gotoJumpState1 = 1; /*goto exit*/
                                    continue $gotoJumpStart1;
                                }
                                $.$srn.System.Numerics.NumericsHelpers.DangerousMakeTwosComplement(xd);
                                trackSignBit = smallShift === 0 && (xd.get_Item(((xd.Length - 1) | 0)).$v >>> 0) == 0;
                            }
                            zdFromPool = null;
                            zl = (($.$spc.System.Math.Max$4(((xl - digitShift) | 0), 0) + (trackSignBit ? 1 : 0)) | 0);
                            zd = (BigInt((zl >>> 0)) <= BigInt($.$srn.System.Numerics.BigIntegerCalculator.StackAllocThreshold) ? $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.StackAllocSpan($.$spc.System.UInt32, $.$srn.System.Numerics.BigIntegerCalculator.StackAllocThreshold, null) : $.$spc.System.Span$$($.$spc.System.UInt32).op_Implicit(zdFromPool = $.$spc.System.Buffers.ArrayPool$$($.$spc.System.UInt32).Shared.Rent(zl))).Slice$1(0, zl);
                            zd.Clear();
                            if (smallShift === 0)
                            {
                                for(/*int*/ let i = ((xd.Length - 1) | 0); i >= digitShift; i--)
                                {
                                    zd.get_Item(((i - digitShift) | 0)).$v = xd.get_Item(i).$v;
                                }
                            }
                            else 
                            {
                                /*int*/ let carryShift = ((32/*kcbitUint*/ - smallShift) | 0);
                                /*uint*/ let carry = 0;
                                for(/*int*/ let i = ((xd.Length - 1) | 0); i >= digitShift; i--)
                                {
                                    /*uint*/ let rot = xd.get_Item(i).$v;
                                    if (negx && i === ((xd.Length - 1) | 0))
                                    {
                                        zd.get_Item(((i - digitShift) | 0)).$v = (rot >>> smallShift) | ((4294967295 << carryShift) >>> 0);
                                    }
                                    else 
                                    {
                                        zd.get_Item(((i - digitShift) | 0)).$v = (rot >>> smallShift) | carry;
                                    }
                                    carry = (rot << carryShift) >>> 0;
                                }
                            }
                            if (negx)
                            {
                                if (trackSignBit)
                                {
                                    zd.get_Item(((zd.Length - 1) | 0)).$v = 4294967295;
                                }
                                $.$srn.System.Numerics.NumericsHelpers.DangerousMakeTwosComplement(zd);
                            }
                            result = new $.$srn.System.Numerics.BigInteger().$ctor$12($.$spc.System.Span$$($.$spc.System.UInt32).op_Implicit$2(zd), negx);
                            if (zdFromPool !== null)
                            {
                                $.$spc.System.Buffers.ArrayPool$$($.$spc.System.UInt32).Shared.Return(zdFromPool, false);
                            }
                        }
                        case 1: /*exit*/
                        if (xdFromPool !== null)
                        {
                            $.$spc.System.Buffers.ArrayPool$$($.$spc.System.UInt32).Shared.Return(xdFromPool, false);
                        }
                        return result;
                    }
                    break;
                }
            }
            static /*BigInteger */ op_OnesComplement(/*BigInteger*/ value)
            {
                return $.$srn.System.Numerics.BigInteger.op_UnaryNegation(($.$srn.System.Numerics.BigInteger.op_Addition(value, $.$srn.System.Numerics.BigInteger.One)));
            }
            static /*BigInteger */ op_UnaryNegation(/*BigInteger*/ value)
            {
                value.AssertValid();
                return new $.$srn.System.Numerics.BigInteger().$ctor$11(-value._sign, value._bits);
            }
            static /*BigInteger */ op_UnaryPlus(/*BigInteger*/ value)
            {
                value.AssertValid();
                return value;
            }
            static /*BigInteger */ op_Increment(/*BigInteger*/ value)
            {
                return $.$srn.System.Numerics.BigInteger.op_Addition(value, $.$srn.System.Numerics.BigInteger.One);
            }
            static /*BigInteger */ op_Decrement(/*BigInteger*/ value)
            {
                return $.$srn.System.Numerics.BigInteger.op_Subtraction(value, $.$srn.System.Numerics.BigInteger.One);
            }
            static /*BigInteger */ op_Addition(/*BigInteger*/ left, /*BigInteger*/ right)
            {
                left.AssertValid();
                right.AssertValid();
                if (left._bits === null && right._bits === null)
                {
                    return $.$srn.System.Numerics.BigInteger.op_Implicit$4($.$cast(left._sign, $.$spc.System.Int64) + BigInt(right._sign));
                }
                if (left._sign < 0 !== right._sign < 0)
                {
                    return $.$srn.System.Numerics.BigInteger.Subtract$1($.$spc.System.ReadOnlySpan$$($.$spc.System.UInt32).op_Implicit(left._bits), left._sign, $.$spc.System.ReadOnlySpan$$($.$spc.System.UInt32).op_Implicit(right._bits), ((-1 * right._sign) | 0));
                }
                return $.$srn.System.Numerics.BigInteger.Add$1($.$spc.System.ReadOnlySpan$$($.$spc.System.UInt32).op_Implicit(left._bits), left._sign, $.$spc.System.ReadOnlySpan$$($.$spc.System.UInt32).op_Implicit(right._bits), right._sign);
            }
            static /*BigInteger */ op_Multiply(/*BigInteger*/ left, /*BigInteger*/ right)
            {
                left.AssertValid();
                right.AssertValid();
                if (left._bits === null && right._bits === null)
                {
                    return $.$srn.System.Numerics.BigInteger.op_Implicit$4($.$cast(left._sign, $.$spc.System.Int64) * BigInt(right._sign));
                }
                return $.$srn.System.Numerics.BigInteger.Multiply$1($.$spc.System.ReadOnlySpan$$($.$spc.System.UInt32).op_Implicit(left._bits), left._sign, $.$spc.System.ReadOnlySpan$$($.$spc.System.UInt32).op_Implicit(right._bits), right._sign);
            }
            static /*BigInteger */ Multiply$1(/*ReadOnlySpan<uint>*/ left, /*int*/ leftSign, /*ReadOnlySpan<uint>*/ right, /*int*/ rightSign)
            {
                /*bool*/ let trivialLeft = left.IsEmpty;
                /*bool*/ let trivialRight = right.IsEmpty;
                $.$spc.System.Diagnostics.Debug.Assert$1(!(trivialLeft && trivialRight), "Trivial cases should be handled on the caller operator");
                /*BigInteger*/ let result;
                /*uint[]?*/ let bitsFromPool = null;
                if (trivialLeft)
                {
                    $.$spc.System.Diagnostics.Debug.Assert$1(!right.IsEmpty, "!right.IsEmpty");
                    /*int*/ let size = ((right.Length + 1) | 0);
                    /*Span<uint>*/ let bits = (BigInt((size >>> 0)) <= BigInt($.$srn.System.Numerics.BigIntegerCalculator.StackAllocThreshold) ? $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.StackAllocSpan($.$spc.System.UInt32, $.$srn.System.Numerics.BigIntegerCalculator.StackAllocThreshold, null) : $.$spc.System.Span$$($.$spc.System.UInt32).op_Implicit(bitsFromPool = $.$spc.System.Buffers.ArrayPool$$($.$spc.System.UInt32).Shared.Rent(size))).Slice$1(0, size);
                    $.$srn.System.Numerics.BigIntegerCalculator.Multiply(right, $.$srn.System.Numerics.NumericsHelpers.Abs(leftSign), bits);
                    result = new $.$srn.System.Numerics.BigInteger().$ctor$12($.$spc.System.Span$$($.$spc.System.UInt32).op_Implicit$2(bits), $.$spc.System.Boolean.op_ExclusiveOr$1((leftSign < 0), (rightSign < 0)));
                }
                else if (trivialRight)
                {
                    $.$spc.System.Diagnostics.Debug.Assert$1(!left.IsEmpty, "!left.IsEmpty");
                    /*int*/ let size = ((left.Length + 1) | 0);
                    /*Span<uint>*/ let bits = (BigInt((size >>> 0)) <= BigInt($.$srn.System.Numerics.BigIntegerCalculator.StackAllocThreshold) ? $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.StackAllocSpan($.$spc.System.UInt32, $.$srn.System.Numerics.BigIntegerCalculator.StackAllocThreshold, null) : $.$spc.System.Span$$($.$spc.System.UInt32).op_Implicit(bitsFromPool = $.$spc.System.Buffers.ArrayPool$$($.$spc.System.UInt32).Shared.Rent(size))).Slice$1(0, size);
                    $.$srn.System.Numerics.BigIntegerCalculator.Multiply(left, $.$srn.System.Numerics.NumericsHelpers.Abs(rightSign), bits);
                    result = new $.$srn.System.Numerics.BigInteger().$ctor$12($.$spc.System.Span$$($.$spc.System.UInt32).op_Implicit$2(bits), $.$spc.System.Boolean.op_ExclusiveOr$1((leftSign < 0), (rightSign < 0)));
                }
                else if ($.$spc.System.ReadOnlySpan$$($.$spc.System.UInt32).op_Equality(left, right))
                {
                    /*int*/ let size = ((left.Length + right.Length) | 0);
                    /*Span<uint>*/ let bits = (BigInt((size >>> 0)) <= BigInt($.$srn.System.Numerics.BigIntegerCalculator.StackAllocThreshold) ? $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.StackAllocSpan($.$spc.System.UInt32, $.$srn.System.Numerics.BigIntegerCalculator.StackAllocThreshold, null) : $.$spc.System.Span$$($.$spc.System.UInt32).op_Implicit(bitsFromPool = $.$spc.System.Buffers.ArrayPool$$($.$spc.System.UInt32).Shared.Rent(size))).Slice$1(0, size);
                    $.$srn.System.Numerics.BigIntegerCalculator.Square(left, bits);
                    result = new $.$srn.System.Numerics.BigInteger().$ctor$12($.$spc.System.Span$$($.$spc.System.UInt32).op_Implicit$2(bits), $.$spc.System.Boolean.op_ExclusiveOr$1((leftSign < 0), (rightSign < 0)));
                }
                else if (left.Length < right.Length)
                {
                    $.$spc.System.Diagnostics.Debug.Assert$1(!left.IsEmpty && !right.IsEmpty, "!left.IsEmpty && !right.IsEmpty");
                    /*int*/ let size = ((left.Length + right.Length) | 0);
                    /*Span<uint>*/ let bits = (BigInt((size >>> 0)) <= BigInt($.$srn.System.Numerics.BigIntegerCalculator.StackAllocThreshold) ? $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.StackAllocSpan($.$spc.System.UInt32, $.$srn.System.Numerics.BigIntegerCalculator.StackAllocThreshold, null) : $.$spc.System.Span$$($.$spc.System.UInt32).op_Implicit(bitsFromPool = $.$spc.System.Buffers.ArrayPool$$($.$spc.System.UInt32).Shared.Rent(size))).Slice$1(0, size);
                    bits.Clear();
                    $.$srn.System.Numerics.BigIntegerCalculator.Multiply$1(right, left, bits);
                    result = new $.$srn.System.Numerics.BigInteger().$ctor$12($.$spc.System.Span$$($.$spc.System.UInt32).op_Implicit$2(bits), $.$spc.System.Boolean.op_ExclusiveOr$1((leftSign < 0), (rightSign < 0)));
                }
                else 
                {
                    $.$spc.System.Diagnostics.Debug.Assert$1(!left.IsEmpty && !right.IsEmpty, "!left.IsEmpty && !right.IsEmpty");
                    /*int*/ let size = ((left.Length + right.Length) | 0);
                    /*Span<uint>*/ let bits = (BigInt((size >>> 0)) <= BigInt($.$srn.System.Numerics.BigIntegerCalculator.StackAllocThreshold) ? $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.StackAllocSpan($.$spc.System.UInt32, $.$srn.System.Numerics.BigIntegerCalculator.StackAllocThreshold, null) : $.$spc.System.Span$$($.$spc.System.UInt32).op_Implicit(bitsFromPool = $.$spc.System.Buffers.ArrayPool$$($.$spc.System.UInt32).Shared.Rent(size))).Slice$1(0, size);
                    bits.Clear();
                    $.$srn.System.Numerics.BigIntegerCalculator.Multiply$1(left, right, bits);
                    result = new $.$srn.System.Numerics.BigInteger().$ctor$12($.$spc.System.Span$$($.$spc.System.UInt32).op_Implicit$2(bits), $.$spc.System.Boolean.op_ExclusiveOr$1((leftSign < 0), (rightSign < 0)));
                }
                if (bitsFromPool !== null)
                {
                    $.$spc.System.Buffers.ArrayPool$$($.$spc.System.UInt32).Shared.Return(bitsFromPool, false);
                }
                return result;
            }
            static /*BigInteger */ op_Division(/*BigInteger*/ dividend, /*BigInteger*/ divisor)
            {
                dividend.AssertValid();
                divisor.AssertValid();
                /*bool*/ let trivialDividend = dividend._bits === null;
                /*bool*/ let trivialDivisor = divisor._bits === null;
                if (trivialDividend && trivialDivisor)
                {
                    return $.$srn.System.Numerics.BigInteger.op_Implicit$3($.trunc(dividend._sign / divisor._sign));
                }
                if (trivialDividend)
                {
                    return $.$srn.System.Numerics.BigInteger.s_bnZeroInt;
                }
                /*uint[]?*/ let quotientFromPool = null;
                if (trivialDivisor)
                {
                    $.$spc.System.Diagnostics.Debug.Assert$1(dividend._bits !== null, "dividend._bits != null");
                    /*int*/ let size = dividend._bits.length;
                    /*Span<uint>*/ let quotient = (BigInt((size >>> 0)) <= BigInt($.$srn.System.Numerics.BigIntegerCalculator.StackAllocThreshold) ? $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.StackAllocSpan($.$spc.System.UInt32, $.$srn.System.Numerics.BigIntegerCalculator.StackAllocThreshold, null) : $.$spc.System.Span$$($.$spc.System.UInt32).op_Implicit(quotientFromPool = $.$spc.System.Buffers.ArrayPool$$($.$spc.System.UInt32).Shared.Rent(size))).Slice$1(0, size);
                    try
                    {
                        $.$srn.System.Numerics.BigIntegerCalculator.Divide$1($.$spc.System.ReadOnlySpan$$($.$spc.System.UInt32).op_Implicit(dividend._bits), $.$srn.System.Numerics.NumericsHelpers.Abs(divisor._sign), quotient);
                        return new $.$srn.System.Numerics.BigInteger().$ctor$12($.$spc.System.Span$$($.$spc.System.UInt32).op_Implicit$2(quotient), $.$spc.System.Boolean.op_ExclusiveOr$1((dividend._sign < 0), (divisor._sign < 0)));
                    }
                    finally
                    {
                        {
                            if (quotientFromPool !== null)
                            {
                                $.$spc.System.Buffers.ArrayPool$$($.$spc.System.UInt32).Shared.Return(quotientFromPool, false);
                            }
                        }
                    }
                }
                $.$spc.System.Diagnostics.Debug.Assert$1(dividend._bits !== null && divisor._bits !== null, "dividend._bits != null && divisor._bits != null");
                if (dividend._bits.length < divisor._bits.length)
                {
                    return $.$srn.System.Numerics.BigInteger.s_bnZeroInt;
                }
                else 
                {
                    /*int*/ let size = ((((dividend._bits.length - divisor._bits.length) | 0) + 1) | 0);
                    /*Span<uint>*/ let quotient = (BigInt((size >>> 0)) < BigInt($.$srn.System.Numerics.BigIntegerCalculator.StackAllocThreshold) ? $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.StackAllocSpan($.$spc.System.UInt32, $.$srn.System.Numerics.BigIntegerCalculator.StackAllocThreshold, null) : $.$spc.System.Span$$($.$spc.System.UInt32).op_Implicit(quotientFromPool = $.$spc.System.Buffers.ArrayPool$$($.$spc.System.UInt32).Shared.Rent(size))).Slice$1(0, size);
                    $.$srn.System.Numerics.BigIntegerCalculator.Divide$4($.$spc.System.ReadOnlySpan$$($.$spc.System.UInt32).op_Implicit(dividend._bits), $.$spc.System.ReadOnlySpan$$($.$spc.System.UInt32).op_Implicit(divisor._bits), quotient);
                    /*var*/ let result = new $.$srn.System.Numerics.BigInteger().$ctor$12($.$spc.System.Span$$($.$spc.System.UInt32).op_Implicit$2(quotient), $.$spc.System.Boolean.op_ExclusiveOr$1((dividend._sign < 0), (divisor._sign < 0)));
                    if (quotientFromPool !== null)
                    {
                        $.$spc.System.Buffers.ArrayPool$$($.$spc.System.UInt32).Shared.Return(quotientFromPool, false);
                    }
                    return result;
                }
            }
            static /*BigInteger */ op_Modulus(/*BigInteger*/ dividend, /*BigInteger*/ divisor)
            {
                dividend.AssertValid();
                divisor.AssertValid();
                /*bool*/ let trivialDividend = dividend._bits === null;
                /*bool*/ let trivialDivisor = divisor._bits === null;
                if (trivialDividend && trivialDivisor)
                {
                    return $.$srn.System.Numerics.BigInteger.op_Implicit$3(dividend._sign % divisor._sign);
                }
                if (trivialDividend)
                {
                    return dividend;
                }
                if (trivialDivisor)
                {
                    $.$spc.System.Diagnostics.Debug.Assert$1(dividend._bits !== null, "dividend._bits != null");
                    /*uint*/ let remainder = $.$srn.System.Numerics.BigIntegerCalculator.Remainder($.$spc.System.ReadOnlySpan$$($.$spc.System.UInt32).op_Implicit(dividend._bits), $.$srn.System.Numerics.NumericsHelpers.Abs(divisor._sign));
                    return $.$srn.System.Numerics.BigInteger.op_Implicit$4(dividend._sign < 0 ? BigInt(-1) * BigInt(remainder) : BigInt(remainder));
                }
                $.$spc.System.Diagnostics.Debug.Assert$1(dividend._bits !== null && divisor._bits !== null, "dividend._bits != null && divisor._bits != null");
                if (dividend._bits.length < divisor._bits.length)
                {
                    return dividend;
                }
                /*uint[]?*/ let bitsFromPool = null;
                /*int*/ let size = dividend._bits.length;
                /*Span<uint>*/ let bits = (size <= $.$srn.System.Numerics.BigIntegerCalculator.StackAllocThreshold ? $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.StackAllocSpan($.$spc.System.UInt32, $.$srn.System.Numerics.BigIntegerCalculator.StackAllocThreshold, null) : $.$spc.System.Span$$($.$spc.System.UInt32).op_Implicit(bitsFromPool = $.$spc.System.Buffers.ArrayPool$$($.$spc.System.UInt32).Shared.Rent(size))).Slice$1(0, size);
                $.$srn.System.Numerics.BigIntegerCalculator.Remainder$1($.$spc.System.ReadOnlySpan$$($.$spc.System.UInt32).op_Implicit(dividend._bits), $.$spc.System.ReadOnlySpan$$($.$spc.System.UInt32).op_Implicit(divisor._bits), bits);
                /*var*/ let result = new $.$srn.System.Numerics.BigInteger().$ctor$12($.$spc.System.Span$$($.$spc.System.UInt32).op_Implicit$2(bits), dividend._sign < 0);
                if (bitsFromPool !== null)
                {
                    $.$spc.System.Buffers.ArrayPool$$($.$spc.System.UInt32).Shared.Return(bitsFromPool, false);
                }
                return result;
            }
            static /*bool */ op_LessThan(/*BigInteger*/ left, /*BigInteger*/ right)
            {
                return left.CompareTo$2(right) < 0;
            }
            static /*bool */ op_LessThanOrEqual(/*BigInteger*/ left, /*BigInteger*/ right)
            {
                return left.CompareTo$2(right) <= 0;
            }
            static /*bool */ op_GreaterThan(/*BigInteger*/ left, /*BigInteger*/ right)
            {
                return left.CompareTo$2(right) > 0;
            }
            static /*bool */ op_GreaterThanOrEqual(/*BigInteger*/ left, /*BigInteger*/ right)
            {
                return left.CompareTo$2(right) >= 0;
            }
            static /*bool */ op_Equality(/*BigInteger*/ left, /*BigInteger*/ right)
            {
                return left.Equals$4(right);
            }
            static /*bool */ op_Inequality(/*BigInteger*/ left, /*BigInteger*/ right)
            {
                return !left.Equals$4(right);
            }
            static /*bool */ op_LessThan$1(/*BigInteger*/ left, /*long*/ right)
            {
                return left.CompareTo(right) < 0;
            }
            static /*bool */ op_LessThanOrEqual$1(/*BigInteger*/ left, /*long*/ right)
            {
                return left.CompareTo(right) <= 0;
            }
            static /*bool */ op_GreaterThan$1(/*BigInteger*/ left, /*long*/ right)
            {
                return left.CompareTo(right) > 0;
            }
            static /*bool */ op_GreaterThanOrEqual$1(/*BigInteger*/ left, /*long*/ right)
            {
                return left.CompareTo(right) >= 0;
            }
            static /*bool */ op_Equality$1(/*BigInteger*/ left, /*long*/ right)
            {
                return left.Equals$2(right);
            }
            static /*bool */ op_Inequality$1(/*BigInteger*/ left, /*long*/ right)
            {
                return !left.Equals$2(right);
            }
            static /*bool */ op_LessThan$2(/*long*/ left, /*BigInteger*/ right)
            {
                return right.CompareTo(left) > 0;
            }
            static /*bool */ op_LessThanOrEqual$2(/*long*/ left, /*BigInteger*/ right)
            {
                return right.CompareTo(left) >= 0;
            }
            static /*bool */ op_GreaterThan$2(/*long*/ left, /*BigInteger*/ right)
            {
                return right.CompareTo(left) < 0;
            }
            static /*bool */ op_GreaterThanOrEqual$2(/*long*/ left, /*BigInteger*/ right)
            {
                return right.CompareTo(left) <= 0;
            }
            static /*bool */ op_Equality$2(/*long*/ left, /*BigInteger*/ right)
            {
                return right.Equals$2(left);
            }
            static /*bool */ op_Inequality$2(/*long*/ left, /*BigInteger*/ right)
            {
                return !right.Equals$2(left);
            }
            static /*bool */ op_LessThan$3(/*BigInteger*/ left, /*ulong*/ right)
            {
                return left.CompareTo$1(right) < 0;
            }
            static /*bool */ op_LessThanOrEqual$3(/*BigInteger*/ left, /*ulong*/ right)
            {
                return left.CompareTo$1(right) <= 0;
            }
            static /*bool */ op_GreaterThan$3(/*BigInteger*/ left, /*ulong*/ right)
            {
                return left.CompareTo$1(right) > 0;
            }
            static /*bool */ op_GreaterThanOrEqual$3(/*BigInteger*/ left, /*ulong*/ right)
            {
                return left.CompareTo$1(right) >= 0;
            }
            static /*bool */ op_Equality$3(/*BigInteger*/ left, /*ulong*/ right)
            {
                return left.Equals$3(right);
            }
            static /*bool */ op_Inequality$3(/*BigInteger*/ left, /*ulong*/ right)
            {
                return !left.Equals$3(right);
            }
            static /*bool */ op_LessThan$4(/*ulong*/ left, /*BigInteger*/ right)
            {
                return right.CompareTo$1(left) > 0;
            }
            static /*bool */ op_LessThanOrEqual$4(/*ulong*/ left, /*BigInteger*/ right)
            {
                return right.CompareTo$1(left) >= 0;
            }
            static /*bool */ op_GreaterThan$4(/*ulong*/ left, /*BigInteger*/ right)
            {
                return right.CompareTo$1(left) < 0;
            }
            static /*bool */ op_GreaterThanOrEqual$4(/*ulong*/ left, /*BigInteger*/ right)
            {
                return right.CompareTo$1(left) <= 0;
            }
            static /*bool */ op_Equality$4(/*ulong*/ left, /*BigInteger*/ right)
            {
                return right.Equals$3(left);
            }
            static /*bool */ op_Inequality$4(/*ulong*/ left, /*BigInteger*/ right)
            {
                return !right.Equals$3(left);
            }
            /*long */ GetBitLength()
            {
                this.AssertValid();
                /*uint*/ let highValue;
                /*int*/ let bitsArrayLength;
                /*int*/ let sign = this._sign;
                /*uint[]?*/ let bits = this._bits;
                if (bits === null)
                {
                    bitsArrayLength = 1;
                    highValue = ((sign < 0 ? -sign : sign) >>> 0);
                }
                else 
                {
                    bitsArrayLength = bits.length;
                    highValue = $.$spc.System.Array.$ReadT1.call(bits, ((bitsArrayLength - 1) | 0));
                }
                /*long*/ let bitLength = BigInt(bitsArrayLength) * 32n - BigInt($.$spc.System.Numerics.BitOperations.LeadingZeroCount(highValue));
                if (sign >= 0)
                {
                    return bitLength;
                }
                if ((highValue & (((highValue - 1) >>> 0))) !== 0)
                {
                    return bitLength;
                }
                for(/*int*/ let i = ((bitsArrayLength - 2) | 0); i >= 0; i--)
                {
                    if ($.$spc.System.Array.$ReadT1.call(bits, i) === 0)
                    {
                        continue;
                    }
                    return bitLength;
                }
                return bitLength - 1n;
            }
            /*bool */ GetPartsForBitManipulation(/*Span<uint>*/ xd)
            {
                $.$spc.System.Diagnostics.Debug.Assert$1(this._bits === null ? xd.Length === 1 : xd.Length === this._bits.length, "_bits is null ? xd.Length == 1 : xd.Length == _bits.Length");
                if (this._bits === null)
                {
                    xd.get_Item(0).$v = ((this._sign < 0 ? -this._sign : this._sign) >>> 0);
                }
                else 
                {
                    $.$spc.System.MemoryExtensions.CopyTo($.$spc.System.UInt32, this._bits, xd);
                }
                return this._sign < 0;
            }
            /*void */ AssertValid()
            {
                if (this._bits !== null)
                {
                    $.$spc.System.Diagnostics.Debug.Assert$1(this._sign === 1 || this._sign === -1, "_sign == 1 || _sign == -1");
                    $.$spc.System.Diagnostics.Debug.Assert$1(this._bits.length > 0, "_bits.Length > 0");
                    $.$spc.System.Diagnostics.Debug.Assert$1(this._bits.length > 1 || $.$spc.System.Array.$ReadT1.call(this._bits, 0) >= 2147483648/*kuMaskHighBit*/, "_bits.Length > 1 || _bits[0] >= kuMaskHighBit");
                    $.$spc.System.Diagnostics.Debug.Assert$1($.$spc.System.Array.$ReadT1.call(this._bits, ((this._bits.length - 1) | 0)) !== 0, "_bits[_bits.Length - 1] != 0");
                    $.$spc.System.Diagnostics.Debug.Assert$1(this._bits.length <= $.$srn.System.Numerics.BigInteger.MaxLength, "_bits.Length <= MaxLength");
                }
                else 
                {
                    $.$spc.System.Diagnostics.Debug.Assert$1(this._sign > -2147483648/*int.MinValue*/, "_sign > int.MinValue");
                }
            }
            static /*BigInteger */ get System$Numerics$IAdditiveIdentity$$$$AdditiveIdentity()
            {
                return $.$srn.System.Numerics.BigInteger.Zero;
            }
            static /*(BigInteger Quotient, BigInteger Remainder) */ DivRem$1(/*BigInteger*/ left, /*BigInteger*/ right)
            {
                /*BigInteger*/ let remainder;
                /*BigInteger*/ let quotient = $.$srn.System.Numerics.BigInteger.DivRem(left, right, $.$ref(() => remainder, ($v) => remainder = $v, $.$srn.System.Numerics.BigInteger));
                return new ($.$spc.System.ValueTuple$$$($.$srn.System.Numerics.BigInteger, $.$srn.System.Numerics.BigInteger))().$ctor$2(quotient, remainder);
            }
            static /*BigInteger */ LeadingZeroCount(/*BigInteger*/ value)
            {
                value.AssertValid();
                if (value._bits === null)
                {
                    return $.$srn.System.Numerics.BigInteger.op_Implicit$3($.$spc.System.Int32.LeadingZeroCount(value._sign));
                }
                let $t1 = value._bits;
                return $.$srn.System.Numerics.BigInteger.op_Implicit$9((value._sign >= 0) ? $.$spc.System.UInt32.LeadingZeroCount($.$spc.System.Array.$ReadT1.call($t1, $t1.length - 1)) : 0);
            }
            static /*BigInteger */ PopCount(/*BigInteger*/ value)
            {
                value.AssertValid();
                if (value._bits === null)
                {
                    return $.$srn.System.Numerics.BigInteger.op_Implicit$3($.$spc.System.Int32.PopCount(value._sign));
                }
                /*ulong*/ let result = 0n;
                if (value._sign >= 0)
                {
                    for(/*int*/ let i = 0; i < value._bits.length; i++)
                    {
                        /*uint*/ let part = $.$spc.System.Array.$ReadT1.call(value._bits, i);
                        result += BigInt($.$spc.System.UInt32.PopCount(part));
                    }
                }
                else 
                {
                    /*int*/ let i = 0;
                    /*uint*/ let part;
                    do
                    {
                        part = ((~$.$spc.System.Array.$ReadT1.call(value._bits, i) + 1) >>> 0);
                        result += BigInt($.$spc.System.UInt32.PopCount(part));
                        i++;
                    }
                    while((part === 0) && (i < value._bits.length));
                    while(i < value._bits.length)
                    {
                        part = ~$.$spc.System.Array.$ReadT1.call(value._bits, i);
                        result += BigInt($.$spc.System.UInt32.PopCount(part));
                        i++;
                    }
                }
                return $.$srn.System.Numerics.BigInteger.op_Implicit$10(result);
            }
            static /*BigInteger */ RotateLeft(/*BigInteger*/ value, /*int*/ rotateAmount)
            {
                value.AssertValid();
                /*bool*/ let negx = value._sign < 0;
                /*uint*/ let smallBits = $.$srn.System.Numerics.NumericsHelpers.Abs(value._sign);
                /*scoped ReadOnlySpan<uint>*/ let bits = $.$spc.System.ReadOnlySpan$$($.$spc.System.UInt32).op_Implicit(value._bits);
                if (bits.IsEmpty)
                {
                    bits = new ($.$spc.System.ReadOnlySpan$$($.$spc.System.UInt32))().$ctor$5($.$ref(() => smallBits, undefined, $.$spc.System.UInt32));
                }
                /*int*/ let xl = bits.Length;
                if (negx && (bits.get_Item(bits.Length - 1).$v >= 2147483648/*kuMaskHighBit*/) && ((bits.get_Item(bits.Length - 1).$v !== 2147483648/*kuMaskHighBit*/) || $.$spc.System.MemoryExtensions.IndexOfAnyExcept$5($.$spc.System.UInt32, bits, 0) !== (((bits.Length - 1) | 0))))
                {
                    ++xl;
                }
                /*int*/ let byteCount = ((xl * 4) | 0);
                rotateAmount = $.$cast((BigInt(rotateAmount) % (BigInt(byteCount) * 8n)), $.$spc.System.Int32);
                if (rotateAmount === 0)
                {
                    return value;
                }
                if (rotateAmount === -2147483648/*int.MinValue*/)
                {
                    return $.$srn.System.Numerics.BigInteger.RotateRight($.$srn.System.Numerics.BigInteger.RotateRight(value, 2147483647/*int.MaxValue*/), 1);
                }
                if (rotateAmount < 0)
                {
                    return $.$srn.System.Numerics.BigInteger.RotateRight(value, -rotateAmount);
                }
                const { Item1: digitShift, Item2: smallShift } = $.$spc.System.Math.DivRem$6(rotateAmount, 32/*kcbitUint*/);
                /*uint[]?*/ let xdFromPool = null;
                /*Span<uint>*/ let xd = (xl <= $.$srn.System.Numerics.BigIntegerCalculator.StackAllocThreshold) ? $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.StackAllocSpan($.$spc.System.UInt32, $.$srn.System.Numerics.BigIntegerCalculator.StackAllocThreshold, null) : $.$spc.System.Span$$($.$spc.System.UInt32).op_Implicit(xdFromPool = $.$spc.System.Buffers.ArrayPool$$($.$spc.System.UInt32).Shared.Rent(xl));
                xd = xd.Slice$1(0, xl);
                xd.get_Item(xd.Length - 1).$v = 0;
                bits.CopyTo(xd);
                /*int*/ let zl = xl;
                /*uint[]?*/ let zdFromPool = null;
                /*Span<uint>*/ let zd = (zl <= $.$srn.System.Numerics.BigIntegerCalculator.StackAllocThreshold) ? $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.StackAllocSpan($.$spc.System.UInt32, $.$srn.System.Numerics.BigIntegerCalculator.StackAllocThreshold, null) : $.$spc.System.Span$$($.$spc.System.UInt32).op_Implicit(zdFromPool = $.$spc.System.Buffers.ArrayPool$$($.$spc.System.UInt32).Shared.Rent(zl));
                zd = zd.Slice$1(0, zl);
                zd.Clear();
                if (negx)
                {
                    $.$srn.System.Numerics.NumericsHelpers.DangerousMakeTwosComplement(xd);
                }
                if (smallShift === 0)
                {
                    /*int*/ let dstIndex = 0;
                    /*int*/ let srcIndex = ((xd.Length - digitShift) | 0);
                    do
                    {
                        zd.get_Item(dstIndex).$v = xd.get_Item(srcIndex).$v;
                        dstIndex++;
                        srcIndex++;
                    }
                    while(srcIndex < xd.Length);
                    srcIndex = 0;
                    while(dstIndex < zd.Length)
                    {
                        zd.get_Item(dstIndex).$v = xd.get_Item(srcIndex).$v;
                        dstIndex++;
                        srcIndex++;
                    }
                }
                else 
                {
                    /*int*/ let carryShift = ((32/*kcbitUint*/ - smallShift) | 0);
                    /*int*/ let dstIndex = 0;
                    /*int*/ let srcIndex = 0;
                    /*uint*/ let carry = 0;
                    if (digitShift === 0)
                    {
                        carry = xd.get_Item(xd.Length - 1).$v >>> carryShift;
                    }
                    else 
                    {
                        srcIndex = ((xd.Length - digitShift) | 0);
                        carry = xd.get_Item(((srcIndex - 1) | 0)).$v >>> carryShift;
                    }
                    do
                    {
                        /*uint*/ let part = xd.get_Item(srcIndex).$v;
                        zd.get_Item(dstIndex).$v = ((part << smallShift) >>> 0) | carry;
                        carry = part >>> carryShift;
                        dstIndex++;
                        srcIndex++;
                    }
                    while(srcIndex < xd.Length);
                    srcIndex = 0;
                    while(dstIndex < zd.Length)
                    {
                        /*uint*/ let part = xd.get_Item(srcIndex).$v;
                        zd.get_Item(dstIndex).$v = ((part << smallShift) >>> 0) | carry;
                        carry = part >>> carryShift;
                        dstIndex++;
                        srcIndex++;
                    }
                }
                if (negx && (zd.get_Item(zd.Length - 1).$v | 0) < 0)
                {
                    $.$srn.System.Numerics.NumericsHelpers.DangerousMakeTwosComplement(zd);
                }
                else 
                {
                    negx = false;
                }
                /*var*/ let result = new $.$srn.System.Numerics.BigInteger().$ctor$12($.$spc.System.Span$$($.$spc.System.UInt32).op_Implicit$2(zd), negx);
                if (xdFromPool !== null)
                {
                    $.$spc.System.Buffers.ArrayPool$$($.$spc.System.UInt32).Shared.Return(xdFromPool, false);
                }
                if (zdFromPool !== null)
                {
                    $.$spc.System.Buffers.ArrayPool$$($.$spc.System.UInt32).Shared.Return(zdFromPool, false);
                }
                return result;
            }
            static /*BigInteger */ RotateRight(/*BigInteger*/ value, /*int*/ rotateAmount)
            {
                value.AssertValid();
                /*bool*/ let negx = value._sign < 0;
                /*uint*/ let smallBits = $.$srn.System.Numerics.NumericsHelpers.Abs(value._sign);
                /*scoped ReadOnlySpan<uint>*/ let bits = $.$spc.System.ReadOnlySpan$$($.$spc.System.UInt32).op_Implicit(value._bits);
                if (bits.IsEmpty)
                {
                    bits = new ($.$spc.System.ReadOnlySpan$$($.$spc.System.UInt32))().$ctor$5($.$ref(() => smallBits, undefined, $.$spc.System.UInt32));
                }
                /*int*/ let xl = bits.Length;
                if (negx && (bits.get_Item(bits.Length - 1).$v >= 2147483648/*kuMaskHighBit*/) && ((bits.get_Item(bits.Length - 1).$v !== 2147483648/*kuMaskHighBit*/) || $.$spc.System.MemoryExtensions.IndexOfAnyExcept$5($.$spc.System.UInt32, bits, 0) !== (((bits.Length - 1) | 0))))
                {
                    ++xl;
                }
                /*int*/ let byteCount = ((xl * 4) | 0);
                rotateAmount = $.$cast((BigInt(rotateAmount) % (BigInt(byteCount) * 8n)), $.$spc.System.Int32);
                if (rotateAmount === 0)
                {
                    return value;
                }
                if (rotateAmount === -2147483648/*int.MinValue*/)
                {
                    return $.$srn.System.Numerics.BigInteger.RotateLeft($.$srn.System.Numerics.BigInteger.RotateLeft(value, 2147483647/*int.MaxValue*/), 1);
                }
                if (rotateAmount < 0)
                {
                    return $.$srn.System.Numerics.BigInteger.RotateLeft(value, -rotateAmount);
                }
                const { Item1: digitShift, Item2: smallShift } = $.$spc.System.Math.DivRem$6(rotateAmount, 32/*kcbitUint*/);
                /*uint[]?*/ let xdFromPool = null;
                /*Span<uint>*/ let xd = (xl <= $.$srn.System.Numerics.BigIntegerCalculator.StackAllocThreshold) ? $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.StackAllocSpan($.$spc.System.UInt32, $.$srn.System.Numerics.BigIntegerCalculator.StackAllocThreshold, null) : $.$spc.System.Span$$($.$spc.System.UInt32).op_Implicit(xdFromPool = $.$spc.System.Buffers.ArrayPool$$($.$spc.System.UInt32).Shared.Rent(xl));
                xd = xd.Slice$1(0, xl);
                xd.get_Item(xd.Length - 1).$v = 0;
                bits.CopyTo(xd);
                /*int*/ let zl = xl;
                /*uint[]?*/ let zdFromPool = null;
                /*Span<uint>*/ let zd = (zl <= $.$srn.System.Numerics.BigIntegerCalculator.StackAllocThreshold) ? $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.StackAllocSpan($.$spc.System.UInt32, $.$srn.System.Numerics.BigIntegerCalculator.StackAllocThreshold, null) : $.$spc.System.Span$$($.$spc.System.UInt32).op_Implicit(zdFromPool = $.$spc.System.Buffers.ArrayPool$$($.$spc.System.UInt32).Shared.Rent(zl));
                zd = zd.Slice$1(0, zl);
                zd.Clear();
                if (negx)
                {
                    $.$srn.System.Numerics.NumericsHelpers.DangerousMakeTwosComplement(xd);
                }
                if (smallShift === 0)
                {
                    /*int*/ let dstIndex = 0;
                    /*int*/ let srcIndex = digitShift;
                    do
                    {
                        zd.get_Item(dstIndex).$v = xd.get_Item(srcIndex).$v;
                        dstIndex++;
                        srcIndex++;
                    }
                    while(srcIndex < xd.Length);
                    srcIndex = 0;
                    while(dstIndex < zd.Length)
                    {
                        zd.get_Item(dstIndex).$v = xd.get_Item(srcIndex).$v;
                        dstIndex++;
                        srcIndex++;
                    }
                }
                else 
                {
                    /*int*/ let carryShift = ((32/*kcbitUint*/ - smallShift) | 0);
                    /*int*/ let dstIndex = ((xd.Length - 1) | 0);
                    /*int*/ let srcIndex = digitShift === 0 ? ((xd.Length - 1) | 0) : ((digitShift - 1) | 0);
                    /*uint*/ let carry = (xd.get_Item(digitShift).$v << carryShift) >>> 0;
                    do
                    {
                        /*uint*/ let part = xd.get_Item(srcIndex).$v;
                        zd.get_Item(dstIndex).$v = (part >>> smallShift) | carry;
                        carry = (part << carryShift) >>> 0;
                        dstIndex--;
                        srcIndex--;
                    }
                    while((srcIndex >>> 0) < (xd.Length >>> 0));
                    srcIndex = ((xd.Length - 1) | 0);
                    while((dstIndex >>> 0) < (zd.Length >>> 0))
                    {
                        /*uint*/ let part = xd.get_Item(srcIndex).$v;
                        zd.get_Item(dstIndex).$v = (part >>> smallShift) | carry;
                        carry = (part << carryShift) >>> 0;
                        dstIndex--;
                        srcIndex--;
                    }
                }
                if (negx && (zd.get_Item(zd.Length - 1).$v | 0) < 0)
                {
                    $.$srn.System.Numerics.NumericsHelpers.DangerousMakeTwosComplement(zd);
                }
                else 
                {
                    negx = false;
                }
                /*var*/ let result = new $.$srn.System.Numerics.BigInteger().$ctor$12($.$spc.System.Span$$($.$spc.System.UInt32).op_Implicit$2(zd), negx);
                if (xdFromPool !== null)
                {
                    $.$spc.System.Buffers.ArrayPool$$($.$spc.System.UInt32).Shared.Return(xdFromPool, false);
                }
                if (zdFromPool !== null)
                {
                    $.$spc.System.Buffers.ArrayPool$$($.$spc.System.UInt32).Shared.Return(zdFromPool, false);
                }
                return result;
            }
            static /*BigInteger */ TrailingZeroCount(/*BigInteger*/ value)
            {
                value.AssertValid();
                if (value._bits === null)
                {
                    return $.$srn.System.Numerics.BigInteger.op_Implicit$3($.$spc.System.Int32.TrailingZeroCount(value._sign));
                }
                /*ulong*/ let result = 0n;
                /*uint*/ let part = $.$spc.System.Array.$ReadT1.call(value._bits, 0);
                for(/*int*/ let i = 1; (part === 0) && (i < value._bits.length); i++)
                {
                    part = $.$spc.System.Array.$ReadT1.call(value._bits, i);
                    result += (BigInt($.$spc.System.UInt32.$z * 8));
                }
                result += BigInt($.$spc.System.UInt32.TrailingZeroCount(part));
                return $.$srn.System.Numerics.BigInteger.op_Implicit$10(result);
            }
            static /*bool */ System$Numerics$IBinaryInteger$$$TryReadBigEndian(/*ReadOnlySpan<byte>*/ source, /*bool*/ isUnsigned, /*out BigInteger*/ value)
            {
                value.$v = new $.$srn.System.Numerics.BigInteger().$ctor$10(source, false, true);
                return true;
            }
            static /*bool */ System$Numerics$IBinaryInteger$$$TryReadLittleEndian(/*ReadOnlySpan<byte>*/ source, /*bool*/ isUnsigned, /*out BigInteger*/ value)
            {
                value.$v = new $.$srn.System.Numerics.BigInteger().$ctor$10(source, false, false);
                return true;
            }
            /*int */ System$Numerics$IBinaryInteger$$$GetShortestBitLength()
            {
                this.AssertValid();
                /*uint[]?*/ let bits = this._bits;
                if (bits === null)
                {
                    /*int*/ let value = this._sign;
                    if (value >= 0)
                    {
                        return ((((($.$spc.System.Int32.$z * 8) | 0)) - $.$spc.System.Numerics.BitOperations.LeadingZeroCount(((value) >>> 0))) | 0);
                    }
                    else 
                    {
                        return ((((((($.$spc.System.Int32.$z * 8) | 0)) + 1) | 0) - $.$spc.System.Numerics.BitOperations.LeadingZeroCount(((~value) >>> 0))) | 0);
                    }
                }
                /*int*/ let result = (((((bits.length - 1) | 0)) * 32) | 0);
                if (this._sign >= 0)
                {
                    result += ((((($.$spc.System.UInt32.$z * 8) | 0)) - $.$spc.System.Numerics.BitOperations.LeadingZeroCount($.$spc.System.Array.$ReadT1.call(bits, bits.length - 1))) | 0);
                }
                else 
                {
                    /*uint*/ let part = ((~$.$spc.System.Array.$ReadT1.call(bits, bits.length - 1) + 1) >>> 0);
                    for(/*int*/ let index = 0; index < ((bits.length - 1) | 0); index++)
                    {
                        if ($.$spc.System.Array.$ReadT1.call(bits, index) !== 0)
                        {
                            part -= 1;
                            break;
                        }
                    }
                    result += ((((((($.$spc.System.UInt32.$z * 8) | 0)) + 1) | 0) - $.$spc.System.Numerics.BitOperations.LeadingZeroCount(~part)) | 0);
                }
                return result;
            }
            /*int */ System$Numerics$IBinaryInteger$$$GetByteCount()
            {
                return this.GetGenericMathByteCount();
            }
            /*bool */ System$Numerics$IBinaryInteger$$$TryWriteBigEndian(/*Span<byte>*/ destination, /*out int*/ bytesWritten)
            {
                this.AssertValid();
                /*uint[]?*/ let bits = this._bits;
                /*int*/ let byteCount = this.GetGenericMathByteCount();
                if (destination.Length >= byteCount)
                {
                    if (bits === null)
                    {
                        /*int*/ let value = $.$spc.System.BitConverter.IsLittleEndian ? $.$spc.System.Buffers.Binary.BinaryPrimitives.ReverseEndianness$2(this._sign) : this._sign;
                        $.$spc.System.Runtime.CompilerServices.Unsafe.WriteUnaligned$1($.$spc.System.Int32, $.$spc.System.Runtime.InteropServices.MemoryMarshal.GetReference($.$spc.System.Byte, destination), value);
                    }
                    else if (this._sign >= 0)
                    {
                        /*ref byte*/ let startAddress = $.$spc.System.Runtime.InteropServices.MemoryMarshal.GetReference($.$spc.System.Byte, destination);
                        /*ref byte*/ let address = $.$spc.System.Runtime.CompilerServices.Unsafe.Add($.$spc.System.Byte, startAddress, (((((bits.length - 1) | 0)) * $.$spc.System.UInt32.$z) | 0));
                        for(/*int*/ let i = 0; i < bits.length; i++)
                        {
                            /*uint*/ let part = $.$spc.System.Array.$ReadT1.call(bits, i);
                            if ($.$spc.System.BitConverter.IsLittleEndian)
                            {
                                part = $.$spc.System.Buffers.Binary.BinaryPrimitives.ReverseEndianness$9(part);
                            }
                            $.$spc.System.Runtime.CompilerServices.Unsafe.WriteUnaligned$1($.$spc.System.UInt32, address, part);
                            address = $.$spc.System.Runtime.CompilerServices.Unsafe.Subtract($.$spc.System.Byte, address, $.$spc.System.UInt32.$z);
                        }
                    }
                    else 
                    {
                        /*ref byte*/ let startAddress = $.$spc.System.Runtime.InteropServices.MemoryMarshal.GetReference($.$spc.System.Byte, destination);
                        /*ref byte*/ let address = $.$spc.System.Runtime.CompilerServices.Unsafe.Add($.$spc.System.Byte, startAddress, ((byteCount - $.$spc.System.UInt32.$z) | 0));
                        /*int*/ let i = 0;
                        /*uint*/ let part;
                        do
                        {
                            part = ((~$.$spc.System.Array.$ReadT1.call(bits, i) + 1) >>> 0);
                            if ($.$spc.System.BitConverter.IsLittleEndian)
                            {
                                part = $.$spc.System.Buffers.Binary.BinaryPrimitives.ReverseEndianness$9(part);
                            }
                            $.$spc.System.Runtime.CompilerServices.Unsafe.WriteUnaligned$1($.$spc.System.UInt32, address, part);
                            address = $.$spc.System.Runtime.CompilerServices.Unsafe.Subtract($.$spc.System.Byte, address, $.$spc.System.UInt32.$z);
                            i++;
                        }
                        while((part === 0) && (i < bits.length));
                        while(i < bits.length)
                        {
                            part = ~$.$spc.System.Array.$ReadT1.call(bits, i);
                            if ($.$spc.System.BitConverter.IsLittleEndian)
                            {
                                part = $.$spc.System.Buffers.Binary.BinaryPrimitives.ReverseEndianness$9(part);
                            }
                            $.$spc.System.Runtime.CompilerServices.Unsafe.WriteUnaligned$1($.$spc.System.UInt32, address, part);
                            address = $.$spc.System.Runtime.CompilerServices.Unsafe.Subtract($.$spc.System.Byte, address, $.$spc.System.UInt32.$z);
                            i++;
                        }
                        if ($.$spc.System.Runtime.CompilerServices.Unsafe.AreSame($.$spc.System.Byte, address, startAddress))
                        {
                            $.$spc.System.Runtime.CompilerServices.Unsafe.WriteUnaligned$1($.$spc.System.UInt32, address, 4294967295/*uint.MaxValue*/);
                        }
                        else 
                        {
                            $.$spc.System.Diagnostics.Debug.Assert$1($.$spc.System.Runtime.CompilerServices.Unsafe.AreSame($.$spc.System.Byte, startAddress, $.$spc.System.Runtime.CompilerServices.Unsafe.Add($.$spc.System.Byte, address, $.$spc.System.UInt32.$z)), "Unsafe.AreSame(ref startAddress, ref Unsafe.Add(ref address, sizeof(uint)))");
                        }
                    }
                    bytesWritten.$v = byteCount;
                    return true;
                }
                else 
                {
                    bytesWritten.$v = 0;
                    return false;
                }
            }
            /*bool */ System$Numerics$IBinaryInteger$$$TryWriteLittleEndian(/*Span<byte>*/ destination, /*out int*/ bytesWritten)
            {
                this.AssertValid();
                /*uint[]?*/ let bits = this._bits;
                /*int*/ let byteCount = this.GetGenericMathByteCount();
                if (destination.Length >= byteCount)
                {
                    if (bits === null)
                    {
                        /*int*/ let value = $.$spc.System.BitConverter.IsLittleEndian ? this._sign : $.$spc.System.Buffers.Binary.BinaryPrimitives.ReverseEndianness$2(this._sign);
                        $.$spc.System.Runtime.CompilerServices.Unsafe.WriteUnaligned$1($.$spc.System.Int32, $.$spc.System.Runtime.InteropServices.MemoryMarshal.GetReference($.$spc.System.Byte, destination), value);
                    }
                    else if (this._sign >= 0)
                    {
                        /*ref byte*/ let address = $.$spc.System.Runtime.InteropServices.MemoryMarshal.GetReference($.$spc.System.Byte, destination);
                        for(/*int*/ let i = 0; i < bits.length; i++)
                        {
                            /*uint*/ let part = $.$spc.System.Array.$ReadT1.call(bits, i);
                            if (!$.$spc.System.BitConverter.IsLittleEndian)
                            {
                                part = $.$spc.System.Buffers.Binary.BinaryPrimitives.ReverseEndianness$9(part);
                            }
                            $.$spc.System.Runtime.CompilerServices.Unsafe.WriteUnaligned$1($.$spc.System.UInt32, address, part);
                            address = $.$spc.System.Runtime.CompilerServices.Unsafe.Add($.$spc.System.Byte, address, $.$spc.System.UInt32.$z);
                        }
                    }
                    else 
                    {
                        /*ref byte*/ let address = $.$spc.System.Runtime.InteropServices.MemoryMarshal.GetReference($.$spc.System.Byte, destination);
                        /*ref byte*/ let lastAddress = $.$spc.System.Runtime.CompilerServices.Unsafe.Add($.$spc.System.Byte, address, ((byteCount - $.$spc.System.UInt32.$z) | 0));
                        /*int*/ let i = 0;
                        /*uint*/ let part;
                        do
                        {
                            part = ((~$.$spc.System.Array.$ReadT1.call(bits, i) + 1) >>> 0);
                            if (!$.$spc.System.BitConverter.IsLittleEndian)
                            {
                                part = $.$spc.System.Buffers.Binary.BinaryPrimitives.ReverseEndianness$9(part);
                            }
                            $.$spc.System.Runtime.CompilerServices.Unsafe.WriteUnaligned$1($.$spc.System.UInt32, address, part);
                            address = $.$spc.System.Runtime.CompilerServices.Unsafe.Add($.$spc.System.Byte, address, $.$spc.System.UInt32.$z);
                            i++;
                        }
                        while((part === 0) && (i < bits.length));
                        while(i < bits.length)
                        {
                            part = ~$.$spc.System.Array.$ReadT1.call(bits, i);
                            if (!$.$spc.System.BitConverter.IsLittleEndian)
                            {
                                part = $.$spc.System.Buffers.Binary.BinaryPrimitives.ReverseEndianness$9(part);
                            }
                            $.$spc.System.Runtime.CompilerServices.Unsafe.WriteUnaligned$1($.$spc.System.UInt32, address, part);
                            address = $.$spc.System.Runtime.CompilerServices.Unsafe.Add($.$spc.System.Byte, address, $.$spc.System.UInt32.$z);
                            i++;
                        }
                        if ($.$spc.System.Runtime.CompilerServices.Unsafe.AreSame($.$spc.System.Byte, address, lastAddress))
                        {
                            $.$spc.System.Runtime.CompilerServices.Unsafe.WriteUnaligned$1($.$spc.System.UInt32, address, 4294967295/*uint.MaxValue*/);
                        }
                        else 
                        {
                            $.$spc.System.Diagnostics.Debug.Assert$1($.$spc.System.Runtime.CompilerServices.Unsafe.AreSame($.$spc.System.Byte, lastAddress, $.$spc.System.Runtime.CompilerServices.Unsafe.Subtract($.$spc.System.Byte, address, $.$spc.System.UInt32.$z)), "Unsafe.AreSame(ref lastAddress, ref Unsafe.Subtract(ref address, sizeof(uint)))");
                        }
                    }
                    bytesWritten.$v = byteCount;
                    return true;
                }
                else 
                {
                    bytesWritten.$v = 0;
                    return false;
                }
            }
            /*int */ GetGenericMathByteCount()
            {
                this.AssertValid();
                /*uint[]?*/ let bits = this._bits;
                if (bits === null)
                {
                    return $.$spc.System.Int32.$z;
                }
                /*int*/ let result = ((bits.length * 4) | 0);
                if (this._sign < 0)
                {
                    /*uint*/ let part = ((~$.$spc.System.Array.$ReadT1.call(bits, bits.length - 1) + 1) >>> 0);
                    for(/*int*/ let index = 0; index < ((bits.length - 1) | 0); index++)
                    {
                        if ($.$spc.System.Array.$ReadT1.call(bits, index) !== 0)
                        {
                            part -= 1;
                            break;
                        }
                    }
                    if ((part | 0) >= 0)
                    {
                        result += $.$spc.System.UInt32.$z;
                    }
                }
                return result;
            }
            static /*BigInteger */ get System$Numerics$IBinaryNumber$$$AllBitsSet()
            {
                return $.$srn.System.Numerics.BigInteger.MinusOne;
            }
            static /*bool */ IsPow2(/*BigInteger*/ value)
            {
                return value.IsPowerOfTwo;
            }
            static /*BigInteger */ Log2(/*BigInteger*/ value)
            {
                value.AssertValid();
                if ($.$srn.System.Numerics.BigInteger.IsNegative(value))
                {
                    $.$srn.System.ThrowHelper.ThrowValueArgumentOutOfRange_NeedNonNegNumException();
                }
                if (value._bits === null)
                {
                    return $.$srn.System.Numerics.BigInteger.op_Implicit$9(31 ^ $.$spc.System.UInt32.LeadingZeroCount(((value._sign | 1) >>> 0)));
                }
                let $t1 = value._bits;
                return $.$srn.System.Numerics.BigInteger.op_Implicit$4((BigInt((((value._bits.length * 32) | 0)) - 1)) ^ BigInt($.$spc.System.UInt32.LeadingZeroCount($.$spc.System.Array.$ReadT1.call($t1, $t1.length - 1))));
            }
            static /*BigInteger */ get System$Numerics$IMultiplicativeIdentity$$$$MultiplicativeIdentity()
            {
                return $.$srn.System.Numerics.BigInteger.One;
            }
            static /*BigInteger */ Clamp(/*BigInteger*/ value, /*BigInteger*/ min, /*BigInteger*/ max)
            {
                value.AssertValid();
                min.AssertValid();
                max.AssertValid();
                if ($.$srn.System.Numerics.BigInteger.op_GreaterThan(min, max))
                {
                    ThrowMinMaxException($.$srn.System.Numerics.BigInteger, min, max);
                }
                if ($.$srn.System.Numerics.BigInteger.op_LessThan(value, min))
                {
                    return min;
                }
                else if ($.$srn.System.Numerics.BigInteger.op_GreaterThan(value, max))
                {
                    return max;
                }
                return value;
                /*static void*/  function ThrowMinMaxException(T, /*T*/ min, /*T*/ max)
                {
                    throw new $.$spc.System.ArgumentException().$ctor$10($.$srn.System.SR.Format$1($.$srn.System.SR.Argument_MinMaxValue, $.$box(min, T), $.$box(max, T)));
                }
            }
            static /*BigInteger */ CopySign(/*BigInteger*/ value, /*BigInteger*/ sign)
            {
                value.AssertValid();
                sign.AssertValid();
                /*int*/ let currentSign = value._sign;
                if (value._bits === null)
                {
                    currentSign = (currentSign >= 0) ? 1 : -1;
                }
                /*int*/ let targetSign = sign._sign;
                if (sign._bits === null)
                {
                    targetSign = (targetSign >= 0) ? 1 : -1;
                }
                return (currentSign === targetSign) ? value : $.$srn.System.Numerics.BigInteger.op_UnaryNegation(value);
            }
            static /*BigInteger */ System$Numerics$INumber$$$MaxNumber(/*BigInteger*/ x, /*BigInteger*/ y)
            {
                return $.$srn.System.Numerics.BigInteger.Max(x, y);
            }
            static /*BigInteger */ System$Numerics$INumber$$$MinNumber(/*BigInteger*/ x, /*BigInteger*/ y)
            {
                return $.$srn.System.Numerics.BigInteger.Min(x, y);
            }
            static /*int */ System$Numerics$INumber$$$Sign(/*BigInteger*/ value)
            {
                value.AssertValid();
                if (value._bits === null)
                {
                    return $.$spc.System.Int32.Sign(value._sign);
                }
                return value._sign;
            }
            static /*int */ get System$Numerics$INumberBase$$$Radix()
            {
                return 2;
            }
            static /*BigInteger */ CreateChecked(TOther, /*TOther*/ value)
            {
                /*BigInteger*/ let result;
                if ($.$spc.System.Type.op_Equality$1(TOther.$type, $.$srn.System.Numerics.BigInteger.$type))
                {
                    result = $.$cast($.$box(value, TOther), $.$srn.System.Numerics.BigInteger);
                }
                else if (!$.$srn.System.Numerics.BigInteger.TryConvertFromChecked(TOther, value, $.$ref(() => result, ($v) => result = $v, $.$srn.System.Numerics.BigInteger)) && !TOther.System$Numerics$INumberBase$$$TryConvertToChecked($.$srn.System.Numerics.BigInteger, value, $.$ref(() => result, ($v) => result = $v, $.$srn.System.Numerics.BigInteger)))
                {
                    $.$srn.System.ThrowHelper.ThrowNotSupportedException();
                }
                return result;
            }
            static /*BigInteger */ CreateSaturating(TOther, /*TOther*/ value)
            {
                /*BigInteger*/ let result;
                if ($.$spc.System.Type.op_Equality$1(TOther.$type, $.$srn.System.Numerics.BigInteger.$type))
                {
                    result = $.$cast($.$box(value, TOther), $.$srn.System.Numerics.BigInteger);
                }
                else if (!$.$srn.System.Numerics.BigInteger.TryConvertFromSaturating(TOther, value, $.$ref(() => result, ($v) => result = $v, $.$srn.System.Numerics.BigInteger)) && !TOther.System$Numerics$INumberBase$$$TryConvertToSaturating($.$srn.System.Numerics.BigInteger, value, $.$ref(() => result, ($v) => result = $v, $.$srn.System.Numerics.BigInteger)))
                {
                    $.$srn.System.ThrowHelper.ThrowNotSupportedException();
                }
                return result;
            }
            static /*BigInteger */ CreateTruncating(TOther, /*TOther*/ value)
            {
                /*BigInteger*/ let result;
                if ($.$spc.System.Type.op_Equality$1(TOther.$type, $.$srn.System.Numerics.BigInteger.$type))
                {
                    result = $.$cast($.$box(value, TOther), $.$srn.System.Numerics.BigInteger);
                }
                else if (!$.$srn.System.Numerics.BigInteger.TryConvertFromTruncating(TOther, value, $.$ref(() => result, ($v) => result = $v, $.$srn.System.Numerics.BigInteger)) && !TOther.System$Numerics$INumberBase$$$TryConvertToTruncating($.$srn.System.Numerics.BigInteger, value, $.$ref(() => result, ($v) => result = $v, $.$srn.System.Numerics.BigInteger)))
                {
                    $.$srn.System.ThrowHelper.ThrowNotSupportedException();
                }
                return result;
            }
            static /*bool */ System$Numerics$INumberBase$$$IsCanonical(/*BigInteger*/ value)
            {
                return true;
            }
            static /*bool */ System$Numerics$INumberBase$$$IsComplexNumber(/*BigInteger*/ value)
            {
                return false;
            }
            static /*bool */ IsEvenInteger(/*BigInteger*/ value)
            {
                value.AssertValid();
                if (value._bits === null)
                {
                    return (value._sign & 1) === 0;
                }
                return ($.$spc.System.Array.$ReadT1.call(value._bits, 0) & 1) === 0;
            }
            static /*bool */ System$Numerics$INumberBase$$$IsFinite(/*BigInteger*/ value)
            {
                return true;
            }
            static /*bool */ System$Numerics$INumberBase$$$IsImaginaryNumber(/*BigInteger*/ value)
            {
                return false;
            }
            static /*bool */ System$Numerics$INumberBase$$$IsInfinity(/*BigInteger*/ value)
            {
                return false;
            }
            static /*bool */ System$Numerics$INumberBase$$$IsInteger(/*BigInteger*/ value)
            {
                return true;
            }
            static /*bool */ System$Numerics$INumberBase$$$IsNaN(/*BigInteger*/ value)
            {
                return false;
            }
            static /*bool */ IsNegative(/*BigInteger*/ value)
            {
                value.AssertValid();
                return value._sign < 0;
            }
            static /*bool */ System$Numerics$INumberBase$$$IsNegativeInfinity(/*BigInteger*/ value)
            {
                return false;
            }
            static /*bool */ System$Numerics$INumberBase$$$IsNormal(/*BigInteger*/ value)
            {
                return ($.$srn.System.Numerics.BigInteger.op_Inequality$1(value, 0n));
            }
            static /*bool */ IsOddInteger(/*BigInteger*/ value)
            {
                value.AssertValid();
                if (value._bits === null)
                {
                    return (value._sign & 1) !== 0;
                }
                return ($.$spc.System.Array.$ReadT1.call(value._bits, 0) & 1) !== 0;
            }
            static /*bool */ IsPositive(/*BigInteger*/ value)
            {
                value.AssertValid();
                return value._sign >= 0;
            }
            static /*bool */ System$Numerics$INumberBase$$$IsPositiveInfinity(/*BigInteger*/ value)
            {
                return false;
            }
            static /*bool */ System$Numerics$INumberBase$$$IsRealNumber(/*BigInteger*/ value)
            {
                return true;
            }
            static /*bool */ System$Numerics$INumberBase$$$IsSubnormal(/*BigInteger*/ value)
            {
                return false;
            }
            static /*bool */ System$Numerics$INumberBase$$$IsZero(/*BigInteger*/ value)
            {
                value.AssertValid();
                return value._sign === 0;
            }
            static /*BigInteger */ MaxMagnitude(/*BigInteger*/ x, /*BigInteger*/ y)
            {
                x.AssertValid();
                y.AssertValid();
                /*BigInteger*/ let ax = $.$srn.System.Numerics.BigInteger.Abs(x);
                /*BigInteger*/ let ay = $.$srn.System.Numerics.BigInteger.Abs(y);
                if ($.$srn.System.Numerics.BigInteger.op_GreaterThan(ax, ay))
                {
                    return x;
                }
                if ($.$srn.System.Numerics.BigInteger.op_Equality(ax, ay))
                {
                    return $.$srn.System.Numerics.BigInteger.IsNegative(x) ? y : x;
                }
                return y;
            }
            static /*BigInteger */ System$Numerics$INumberBase$$$MaxMagnitudeNumber(/*BigInteger*/ x, /*BigInteger*/ y)
            {
                return $.$srn.System.Numerics.BigInteger.MaxMagnitude(x, y);
            }
            static /*BigInteger */ MinMagnitude(/*BigInteger*/ x, /*BigInteger*/ y)
            {
                x.AssertValid();
                y.AssertValid();
                /*BigInteger*/ let ax = $.$srn.System.Numerics.BigInteger.Abs(x);
                /*BigInteger*/ let ay = $.$srn.System.Numerics.BigInteger.Abs(y);
                if ($.$srn.System.Numerics.BigInteger.op_LessThan(ax, ay))
                {
                    return x;
                }
                if ($.$srn.System.Numerics.BigInteger.op_Equality(ax, ay))
                {
                    return $.$srn.System.Numerics.BigInteger.IsNegative(x) ? x : y;
                }
                return y;
            }
            static /*BigInteger */ System$Numerics$INumberBase$$$MinMagnitudeNumber(/*BigInteger*/ x, /*BigInteger*/ y)
            {
                return $.$srn.System.Numerics.BigInteger.MinMagnitude(x, y);
            }
            static /*BigInteger */ System$Numerics$INumberBase$$$MultiplyAddEstimate(/*BigInteger*/ left, /*BigInteger*/ right, /*BigInteger*/ addend)
            {
                return $.$srn.System.Numerics.BigInteger.op_Addition(($.$srn.System.Numerics.BigInteger.op_Multiply(left, right)), addend);
            }
            static /*bool */ System$Numerics$INumberBase$$$TryConvertFromChecked(TOther, /*TOther*/ value, /*out BigInteger*/ result)
            {
                return $.$srn.System.Numerics.BigInteger.TryConvertFromChecked(TOther, value, result);
            }
            static /*bool */ TryConvertFromChecked(TOther, /*TOther*/ value, /*out BigInteger*/ result)
            {
                if ($.$spc.System.Type.op_Equality$1(TOther.$type, $.$spc.System.Byte.$type))
                {
                    /*byte*/ let actualValue = $.$cast($.$box(value, TOther), $.$spc.System.Byte);
                    result.$v = $.$srn.System.Numerics.BigInteger.op_Implicit(actualValue);
                    return true;
                }
                else if ($.$spc.System.Type.op_Equality$1(TOther.$type, $.$spc.System.Char.$type))
                {
                    /*char*/ let actualValue = $.$cast($.$box(value, TOther), $.$spc.System.Char);
                    result.$v = $.$srn.System.Numerics.BigInteger.op_Implicit$1(actualValue);
                    return true;
                }
                else if ($.$spc.System.Type.op_Equality$1(TOther.$type, $.$spc.System.Decimal.$type))
                {
                    /*decimal*/ let actualValue = $.$cast($.$box(value, TOther), $.$spc.System.Decimal);
                    result.$v = $.$srn.System.Numerics.BigInteger.op_Explicit$17(actualValue);
                    return true;
                }
                else if ($.$spc.System.Type.op_Equality$1(TOther.$type, $.$spc.System.Double.$type))
                {
                    /*double*/ let actualValue = $.$cast($.$box(value, TOther), $.$spc.System.Double);
                    result.$v = $.$srn.System.Numerics.BigInteger.op_Explicit$18(actualValue);
                    return true;
                }
                else if ($.$spc.System.Type.op_Equality$1(TOther.$type, $.$spc.System.Half.$type))
                {
                    /*Half*/ let actualValue = $.$cast($.$box(value, TOther), $.$spc.System.Half);
                    result.$v = $.$srn.System.Numerics.BigInteger.op_Explicit$19(actualValue);
                    return true;
                }
                else if ($.$spc.System.Type.op_Equality$1(TOther.$type, $.$spc.System.Int16.$type))
                {
                    /*short*/ let actualValue = $.$cast($.$box(value, TOther), $.$spc.System.Int16);
                    result.$v = $.$srn.System.Numerics.BigInteger.op_Implicit$2(actualValue);
                    return true;
                }
                else if ($.$spc.System.Type.op_Equality$1(TOther.$type, $.$spc.System.Int32.$type))
                {
                    /*int*/ let actualValue = $.$cast($.$box(value, TOther), $.$spc.System.Int32);
                    result.$v = $.$srn.System.Numerics.BigInteger.op_Implicit$3(actualValue);
                    return true;
                }
                else if ($.$spc.System.Type.op_Equality$1(TOther.$type, $.$spc.System.Int64.$type))
                {
                    /*long*/ let actualValue = $.$cast($.$box(value, TOther), $.$spc.System.Int64);
                    result.$v = $.$srn.System.Numerics.BigInteger.op_Implicit$4(actualValue);
                    return true;
                }
                else if ($.$spc.System.Type.op_Equality$1(TOther.$type, $.$spc.System.Int128.$type))
                {
                    /*Int128*/ let actualValue = $.$cast($.$box(value, TOther), $.$spc.System.Int128);
                    result.$v = $.$srn.System.Numerics.BigInteger.op_Implicit$5(actualValue);
                    return true;
                }
                else if ($.$spc.System.Type.op_Equality$1(TOther.$type, $.$spc.System.IntPtr.$type))
                {
                    /*nint*/ let actualValue = $.$cast($.$box(value, TOther), $.$spc.System.IntPtr);
                    result.$v = $.$srn.System.Numerics.BigInteger.op_Implicit$6(actualValue);
                    return true;
                }
                else if ($.$spc.System.Type.op_Equality$1(TOther.$type, $.$spc.System.SByte.$type))
                {
                    /*sbyte*/ let actualValue = $.$cast($.$box(value, TOther), $.$spc.System.SByte);
                    result.$v = $.$srn.System.Numerics.BigInteger.op_Implicit$7(actualValue);
                    return true;
                }
                else if ($.$spc.System.Type.op_Equality$1(TOther.$type, $.$spc.System.Single.$type))
                {
                    /*float*/ let actualValue = $.$cast($.$box(value, TOther), $.$spc.System.Single);
                    result.$v = $.$srn.System.Numerics.BigInteger.op_Explicit$21(actualValue);
                    return true;
                }
                else if ($.$spc.System.Type.op_Equality$1(TOther.$type, $.$spc.System.UInt16.$type))
                {
                    /*ushort*/ let actualValue = $.$cast($.$box(value, TOther), $.$spc.System.UInt16);
                    result.$v = $.$srn.System.Numerics.BigInteger.op_Implicit$8(actualValue);
                    return true;
                }
                else if ($.$spc.System.Type.op_Equality$1(TOther.$type, $.$spc.System.UInt32.$type))
                {
                    /*uint*/ let actualValue = $.$cast($.$box(value, TOther), $.$spc.System.UInt32);
                    result.$v = $.$srn.System.Numerics.BigInteger.op_Implicit$9(actualValue);
                    return true;
                }
                else if ($.$spc.System.Type.op_Equality$1(TOther.$type, $.$spc.System.UInt64.$type))
                {
                    /*ulong*/ let actualValue = $.$cast($.$box(value, TOther), $.$spc.System.UInt64);
                    result.$v = $.$srn.System.Numerics.BigInteger.op_Implicit$10(actualValue);
                    return true;
                }
                else if ($.$spc.System.Type.op_Equality$1(TOther.$type, $.$spc.System.UInt128.$type))
                {
                    /*UInt128*/ let actualValue = $.$cast($.$box(value, TOther), $.$spc.System.UInt128);
                    result.$v = $.$srn.System.Numerics.BigInteger.op_Implicit$11(actualValue);
                    return true;
                }
                else if ($.$spc.System.Type.op_Equality$1(TOther.$type, $.$spc.System.UIntPtr.$type))
                {
                    /*nuint*/ let actualValue = $.$cast($.$box(value, TOther), $.$spc.System.UIntPtr);
                    result.$v = $.$srn.System.Numerics.BigInteger.op_Implicit$12(actualValue);
                    return true;
                }
                else 
                {
                    result.$v = new $.$srn.System.Numerics.BigInteger();
                    return false;
                }
            }
            static /*bool */ System$Numerics$INumberBase$$$TryConvertFromSaturating(TOther, /*TOther*/ value, /*out BigInteger*/ result)
            {
                return $.$srn.System.Numerics.BigInteger.TryConvertFromSaturating(TOther, value, result);
            }
            static /*bool */ TryConvertFromSaturating(TOther, /*TOther*/ value, /*out BigInteger*/ result)
            {
                if ($.$spc.System.Type.op_Equality$1(TOther.$type, $.$spc.System.Byte.$type))
                {
                    /*byte*/ let actualValue = $.$cast($.$box(value, TOther), $.$spc.System.Byte);
                    result.$v = $.$srn.System.Numerics.BigInteger.op_Implicit(actualValue);
                    return true;
                }
                else if ($.$spc.System.Type.op_Equality$1(TOther.$type, $.$spc.System.Char.$type))
                {
                    /*char*/ let actualValue = $.$cast($.$box(value, TOther), $.$spc.System.Char);
                    result.$v = $.$srn.System.Numerics.BigInteger.op_Implicit$1(actualValue);
                    return true;
                }
                else if ($.$spc.System.Type.op_Equality$1(TOther.$type, $.$spc.System.Decimal.$type))
                {
                    /*decimal*/ let actualValue = $.$cast($.$box(value, TOther), $.$spc.System.Decimal);
                    result.$v = $.$srn.System.Numerics.BigInteger.op_Explicit$17(actualValue);
                    return true;
                }
                else if ($.$spc.System.Type.op_Equality$1(TOther.$type, $.$spc.System.Double.$type))
                {
                    /*double*/ let actualValue = $.$cast($.$box(value, TOther), $.$spc.System.Double);
                    result.$v = $.$spc.System.Double.IsNaN(actualValue) ? $.$srn.System.Numerics.BigInteger.Zero : $.$srn.System.Numerics.BigInteger.op_Explicit$18(actualValue);
                    return true;
                }
                else if ($.$spc.System.Type.op_Equality$1(TOther.$type, $.$spc.System.Half.$type))
                {
                    /*Half*/ let actualValue = $.$cast($.$box(value, TOther), $.$spc.System.Half);
                    result.$v = $.$spc.System.Half.IsNaN(actualValue) ? $.$srn.System.Numerics.BigInteger.Zero : $.$srn.System.Numerics.BigInteger.op_Explicit$19(actualValue);
                    return true;
                }
                else if ($.$spc.System.Type.op_Equality$1(TOther.$type, $.$spc.System.Int16.$type))
                {
                    /*short*/ let actualValue = $.$cast($.$box(value, TOther), $.$spc.System.Int16);
                    result.$v = $.$srn.System.Numerics.BigInteger.op_Implicit$2(actualValue);
                    return true;
                }
                else if ($.$spc.System.Type.op_Equality$1(TOther.$type, $.$spc.System.Int32.$type))
                {
                    /*int*/ let actualValue = $.$cast($.$box(value, TOther), $.$spc.System.Int32);
                    result.$v = $.$srn.System.Numerics.BigInteger.op_Implicit$3(actualValue);
                    return true;
                }
                else if ($.$spc.System.Type.op_Equality$1(TOther.$type, $.$spc.System.Int64.$type))
                {
                    /*long*/ let actualValue = $.$cast($.$box(value, TOther), $.$spc.System.Int64);
                    result.$v = $.$srn.System.Numerics.BigInteger.op_Implicit$4(actualValue);
                    return true;
                }
                else if ($.$spc.System.Type.op_Equality$1(TOther.$type, $.$spc.System.Int128.$type))
                {
                    /*Int128*/ let actualValue = $.$cast($.$box(value, TOther), $.$spc.System.Int128);
                    result.$v = $.$srn.System.Numerics.BigInteger.op_Implicit$5(actualValue);
                    return true;
                }
                else if ($.$spc.System.Type.op_Equality$1(TOther.$type, $.$spc.System.IntPtr.$type))
                {
                    /*nint*/ let actualValue = $.$cast($.$box(value, TOther), $.$spc.System.IntPtr);
                    result.$v = $.$srn.System.Numerics.BigInteger.op_Implicit$6(actualValue);
                    return true;
                }
                else if ($.$spc.System.Type.op_Equality$1(TOther.$type, $.$spc.System.SByte.$type))
                {
                    /*sbyte*/ let actualValue = $.$cast($.$box(value, TOther), $.$spc.System.SByte);
                    result.$v = $.$srn.System.Numerics.BigInteger.op_Implicit$7(actualValue);
                    return true;
                }
                else if ($.$spc.System.Type.op_Equality$1(TOther.$type, $.$spc.System.Single.$type))
                {
                    /*float*/ let actualValue = $.$cast($.$box(value, TOther), $.$spc.System.Single);
                    result.$v = $.$spc.System.Single.IsNaN(actualValue) ? $.$srn.System.Numerics.BigInteger.Zero : $.$srn.System.Numerics.BigInteger.op_Explicit$21(actualValue);
                    return true;
                }
                else if ($.$spc.System.Type.op_Equality$1(TOther.$type, $.$spc.System.UInt16.$type))
                {
                    /*ushort*/ let actualValue = $.$cast($.$box(value, TOther), $.$spc.System.UInt16);
                    result.$v = $.$srn.System.Numerics.BigInteger.op_Implicit$8(actualValue);
                    return true;
                }
                else if ($.$spc.System.Type.op_Equality$1(TOther.$type, $.$spc.System.UInt32.$type))
                {
                    /*uint*/ let actualValue = $.$cast($.$box(value, TOther), $.$spc.System.UInt32);
                    result.$v = $.$srn.System.Numerics.BigInteger.op_Implicit$9(actualValue);
                    return true;
                }
                else if ($.$spc.System.Type.op_Equality$1(TOther.$type, $.$spc.System.UInt64.$type))
                {
                    /*ulong*/ let actualValue = $.$cast($.$box(value, TOther), $.$spc.System.UInt64);
                    result.$v = $.$srn.System.Numerics.BigInteger.op_Implicit$10(actualValue);
                    return true;
                }
                else if ($.$spc.System.Type.op_Equality$1(TOther.$type, $.$spc.System.UInt128.$type))
                {
                    /*UInt128*/ let actualValue = $.$cast($.$box(value, TOther), $.$spc.System.UInt128);
                    result.$v = $.$srn.System.Numerics.BigInteger.op_Implicit$11(actualValue);
                    return true;
                }
                else if ($.$spc.System.Type.op_Equality$1(TOther.$type, $.$spc.System.UIntPtr.$type))
                {
                    /*nuint*/ let actualValue = $.$cast($.$box(value, TOther), $.$spc.System.UIntPtr);
                    result.$v = $.$srn.System.Numerics.BigInteger.op_Implicit$12(actualValue);
                    return true;
                }
                else 
                {
                    result.$v = new $.$srn.System.Numerics.BigInteger();
                    return false;
                }
            }
            static /*bool */ System$Numerics$INumberBase$$$TryConvertFromTruncating(TOther, /*TOther*/ value, /*out BigInteger*/ result)
            {
                return $.$srn.System.Numerics.BigInteger.TryConvertFromTruncating(TOther, value, result);
            }
            static /*bool */ TryConvertFromTruncating(TOther, /*TOther*/ value, /*out BigInteger*/ result)
            {
                if ($.$spc.System.Type.op_Equality$1(TOther.$type, $.$spc.System.Byte.$type))
                {
                    /*byte*/ let actualValue = $.$cast($.$box(value, TOther), $.$spc.System.Byte);
                    result.$v = $.$srn.System.Numerics.BigInteger.op_Implicit(actualValue);
                    return true;
                }
                else if ($.$spc.System.Type.op_Equality$1(TOther.$type, $.$spc.System.Char.$type))
                {
                    /*char*/ let actualValue = $.$cast($.$box(value, TOther), $.$spc.System.Char);
                    result.$v = $.$srn.System.Numerics.BigInteger.op_Implicit$1(actualValue);
                    return true;
                }
                else if ($.$spc.System.Type.op_Equality$1(TOther.$type, $.$spc.System.Decimal.$type))
                {
                    /*decimal*/ let actualValue = $.$cast($.$box(value, TOther), $.$spc.System.Decimal);
                    result.$v = $.$srn.System.Numerics.BigInteger.op_Explicit$17(actualValue);
                    return true;
                }
                else if ($.$spc.System.Type.op_Equality$1(TOther.$type, $.$spc.System.Double.$type))
                {
                    /*double*/ let actualValue = $.$cast($.$box(value, TOther), $.$spc.System.Double);
                    result.$v = $.$spc.System.Double.IsNaN(actualValue) ? $.$srn.System.Numerics.BigInteger.Zero : $.$srn.System.Numerics.BigInteger.op_Explicit$18(actualValue);
                    return true;
                }
                else if ($.$spc.System.Type.op_Equality$1(TOther.$type, $.$spc.System.Half.$type))
                {
                    /*Half*/ let actualValue = $.$cast($.$box(value, TOther), $.$spc.System.Half);
                    result.$v = $.$spc.System.Half.IsNaN(actualValue) ? $.$srn.System.Numerics.BigInteger.Zero : $.$srn.System.Numerics.BigInteger.op_Explicit$19(actualValue);
                    return true;
                }
                else if ($.$spc.System.Type.op_Equality$1(TOther.$type, $.$spc.System.Int16.$type))
                {
                    /*short*/ let actualValue = $.$cast($.$box(value, TOther), $.$spc.System.Int16);
                    result.$v = $.$srn.System.Numerics.BigInteger.op_Implicit$2(actualValue);
                    return true;
                }
                else if ($.$spc.System.Type.op_Equality$1(TOther.$type, $.$spc.System.Int32.$type))
                {
                    /*int*/ let actualValue = $.$cast($.$box(value, TOther), $.$spc.System.Int32);
                    result.$v = $.$srn.System.Numerics.BigInteger.op_Implicit$3(actualValue);
                    return true;
                }
                else if ($.$spc.System.Type.op_Equality$1(TOther.$type, $.$spc.System.Int64.$type))
                {
                    /*long*/ let actualValue = $.$cast($.$box(value, TOther), $.$spc.System.Int64);
                    result.$v = $.$srn.System.Numerics.BigInteger.op_Implicit$4(actualValue);
                    return true;
                }
                else if ($.$spc.System.Type.op_Equality$1(TOther.$type, $.$spc.System.Int128.$type))
                {
                    /*Int128*/ let actualValue = $.$cast($.$box(value, TOther), $.$spc.System.Int128);
                    result.$v = $.$srn.System.Numerics.BigInteger.op_Implicit$5(actualValue);
                    return true;
                }
                else if ($.$spc.System.Type.op_Equality$1(TOther.$type, $.$spc.System.IntPtr.$type))
                {
                    /*nint*/ let actualValue = $.$cast($.$box(value, TOther), $.$spc.System.IntPtr);
                    result.$v = $.$srn.System.Numerics.BigInteger.op_Implicit$6(actualValue);
                    return true;
                }
                else if ($.$spc.System.Type.op_Equality$1(TOther.$type, $.$spc.System.SByte.$type))
                {
                    /*sbyte*/ let actualValue = $.$cast($.$box(value, TOther), $.$spc.System.SByte);
                    result.$v = $.$srn.System.Numerics.BigInteger.op_Implicit$7(actualValue);
                    return true;
                }
                else if ($.$spc.System.Type.op_Equality$1(TOther.$type, $.$spc.System.Single.$type))
                {
                    /*float*/ let actualValue = $.$cast($.$box(value, TOther), $.$spc.System.Single);
                    result.$v = $.$spc.System.Single.IsNaN(actualValue) ? $.$srn.System.Numerics.BigInteger.Zero : $.$srn.System.Numerics.BigInteger.op_Explicit$21(actualValue);
                    return true;
                }
                else if ($.$spc.System.Type.op_Equality$1(TOther.$type, $.$spc.System.UInt16.$type))
                {
                    /*ushort*/ let actualValue = $.$cast($.$box(value, TOther), $.$spc.System.UInt16);
                    result.$v = $.$srn.System.Numerics.BigInteger.op_Implicit$8(actualValue);
                    return true;
                }
                else if ($.$spc.System.Type.op_Equality$1(TOther.$type, $.$spc.System.UInt32.$type))
                {
                    /*uint*/ let actualValue = $.$cast($.$box(value, TOther), $.$spc.System.UInt32);
                    result.$v = $.$srn.System.Numerics.BigInteger.op_Implicit$9(actualValue);
                    return true;
                }
                else if ($.$spc.System.Type.op_Equality$1(TOther.$type, $.$spc.System.UInt64.$type))
                {
                    /*ulong*/ let actualValue = $.$cast($.$box(value, TOther), $.$spc.System.UInt64);
                    result.$v = $.$srn.System.Numerics.BigInteger.op_Implicit$10(actualValue);
                    return true;
                }
                else if ($.$spc.System.Type.op_Equality$1(TOther.$type, $.$spc.System.UInt128.$type))
                {
                    /*UInt128*/ let actualValue = $.$cast($.$box(value, TOther), $.$spc.System.UInt128);
                    result.$v = $.$srn.System.Numerics.BigInteger.op_Implicit$11(actualValue);
                    return true;
                }
                else if ($.$spc.System.Type.op_Equality$1(TOther.$type, $.$spc.System.UIntPtr.$type))
                {
                    /*nuint*/ let actualValue = $.$cast($.$box(value, TOther), $.$spc.System.UIntPtr);
                    result.$v = $.$srn.System.Numerics.BigInteger.op_Implicit$12(actualValue);
                    return true;
                }
                else 
                {
                    result.$v = new $.$srn.System.Numerics.BigInteger();
                    return false;
                }
            }
            static /*bool */ System$Numerics$INumberBase$$$TryConvertToChecked(TOther, /*BigInteger*/ value, /*out TOther*/ result)
            {
                if ($.$spc.System.Type.op_Equality$1(TOther.$type, $.$spc.System.Byte.$type))
                {
                    /*byte*/ let actualResult = $.$srn.System.Numerics.BigInteger.op_Explicit(value);
                    result.$v = $.$cast($.$box(actualResult, $.$spc.System.Byte), TOther);
                    return true;
                }
                else if ($.$spc.System.Type.op_Equality$1(TOther.$type, $.$spc.System.Char.$type))
                {
                    /*char*/ let actualResult = $.$srn.System.Numerics.BigInteger.op_Explicit$1(value);
                    result.$v = $.$cast($.$box(actualResult, $.$spc.System.Char), TOther);
                    return true;
                }
                else if ($.$spc.System.Type.op_Equality$1(TOther.$type, $.$spc.System.Decimal.$type))
                {
                    /*decimal*/ let actualResult = $.$srn.System.Numerics.BigInteger.op_Explicit$2(value);
                    result.$v = $.$cast($.$cast(actualResult, $.$spc.System.Object), TOther);
                    return true;
                }
                else if ($.$spc.System.Type.op_Equality$1(TOther.$type, $.$spc.System.Double.$type))
                {
                    /*double*/ let actualResult = $.$srn.System.Numerics.BigInteger.op_Explicit$3(value);
                    result.$v = $.$cast($.$box(actualResult, $.$spc.System.Double), TOther);
                    return true;
                }
                else if ($.$spc.System.Type.op_Equality$1(TOther.$type, $.$spc.System.Half.$type))
                {
                    /*Half*/ let actualResult = $.$srn.System.Numerics.BigInteger.op_Explicit$4(value);
                    result.$v = $.$cast($.$cast(actualResult, $.$spc.System.Object), TOther);
                    return true;
                }
                else if ($.$spc.System.Type.op_Equality$1(TOther.$type, $.$spc.System.Int16.$type))
                {
                    /*short*/ let actualResult = $.$srn.System.Numerics.BigInteger.op_Explicit$5(value);
                    result.$v = $.$cast($.$box(actualResult, $.$spc.System.Int16), TOther);
                    return true;
                }
                else if ($.$spc.System.Type.op_Equality$1(TOther.$type, $.$spc.System.Int32.$type))
                {
                    /*int*/ let actualResult = $.$srn.System.Numerics.BigInteger.op_Explicit$6(value);
                    result.$v = $.$cast($.$box(actualResult, $.$spc.System.Int32), TOther);
                    return true;
                }
                else if ($.$spc.System.Type.op_Equality$1(TOther.$type, $.$spc.System.Int64.$type))
                {
                    /*long*/ let actualResult = $.$srn.System.Numerics.BigInteger.op_Explicit$7(value);
                    result.$v = $.$cast($.$box(actualResult, $.$spc.System.Int64), TOther);
                    return true;
                }
                else if ($.$spc.System.Type.op_Equality$1(TOther.$type, $.$spc.System.Int128.$type))
                {
                    /*Int128*/ let actualResult = $.$srn.System.Numerics.BigInteger.op_Explicit$8(value);
                    result.$v = $.$cast($.$cast(actualResult, $.$spc.System.Object), TOther);
                    return true;
                }
                else if ($.$spc.System.Type.op_Equality$1(TOther.$type, $.$spc.System.IntPtr.$type))
                {
                    /*nint*/ let actualResult = $.$srn.System.Numerics.BigInteger.op_Explicit$9(value);
                    result.$v = $.$cast($.$box(actualResult, $.$spc.System.IntPtr), TOther);
                    return true;
                }
                else if ($.$spc.System.Type.op_Equality$1(TOther.$type, $.$srn.System.Numerics.Complex.$type))
                {
                    /*Complex*/ let actualResult = $.$srn.System.Numerics.Complex.op_Explicit$2(value);
                    result.$v = $.$cast($.$cast(actualResult, $.$spc.System.Object), TOther);
                    return true;
                }
                else if ($.$spc.System.Type.op_Equality$1(TOther.$type, $.$spc.System.SByte.$type))
                {
                    /*sbyte*/ let actualResult = $.$srn.System.Numerics.BigInteger.op_Explicit$10(value);
                    result.$v = $.$cast($.$box(actualResult, $.$spc.System.SByte), TOther);
                    return true;
                }
                else if ($.$spc.System.Type.op_Equality$1(TOther.$type, $.$spc.System.Single.$type))
                {
                    /*float*/ let actualResult = $.$srn.System.Numerics.BigInteger.op_Explicit$11(value);
                    result.$v = $.$cast($.$box(actualResult, $.$spc.System.Single), TOther);
                    return true;
                }
                else if ($.$spc.System.Type.op_Equality$1(TOther.$type, $.$spc.System.UInt16.$type))
                {
                    /*ushort*/ let actualResult = $.$srn.System.Numerics.BigInteger.op_Explicit$12(value);
                    result.$v = $.$cast($.$box(actualResult, $.$spc.System.UInt16), TOther);
                    return true;
                }
                else if ($.$spc.System.Type.op_Equality$1(TOther.$type, $.$spc.System.UInt32.$type))
                {
                    /*uint*/ let actualResult = $.$srn.System.Numerics.BigInteger.op_Explicit$13(value);
                    result.$v = $.$cast($.$box(actualResult, $.$spc.System.UInt32), TOther);
                    return true;
                }
                else if ($.$spc.System.Type.op_Equality$1(TOther.$type, $.$spc.System.UInt64.$type))
                {
                    /*ulong*/ let actualResult = $.$srn.System.Numerics.BigInteger.op_Explicit$14(value);
                    result.$v = $.$cast($.$box(actualResult, $.$spc.System.UInt64), TOther);
                    return true;
                }
                else if ($.$spc.System.Type.op_Equality$1(TOther.$type, $.$spc.System.UInt128.$type))
                {
                    /*UInt128*/ let actualResult = $.$srn.System.Numerics.BigInteger.op_Explicit$15(value);
                    result.$v = $.$cast($.$cast(actualResult, $.$spc.System.Object), TOther);
                    return true;
                }
                else if ($.$spc.System.Type.op_Equality$1(TOther.$type, $.$spc.System.UIntPtr.$type))
                {
                    /*nuint*/ let actualResult = $.$srn.System.Numerics.BigInteger.op_Explicit$16(value);
                    result.$v = $.$cast($.$box(actualResult, $.$spc.System.UIntPtr), TOther);
                    return true;
                }
                else 
                {
                    result.$v = $.$default(TOther);
                    return false;
                }
            }
            static /*bool */ System$Numerics$INumberBase$$$TryConvertToSaturating(TOther, /*BigInteger*/ value, /*out TOther*/ result)
            {
                if ($.$spc.System.Type.op_Equality$1(TOther.$type, $.$spc.System.Byte.$type))
                {
                    /*byte*/ let actualResult;
                    if (!(value._bits === null))
                    {
                        actualResult = $.$srn.System.Numerics.BigInteger.IsNegative(value) ? 0/*byte.MinValue*/ : 255/*byte.MaxValue*/;
                    }
                    else 
                    {
                        actualResult = (value._sign >= 255/*byte.MaxValue*/) ? 255/*byte.MaxValue*/ : (value._sign <= 0/*byte.MinValue*/) ? 0/*byte.MinValue*/ : $.$cast(value._sign, $.$spc.System.Byte);
                    }
                    result.$v = $.$cast($.$box(actualResult, $.$spc.System.Byte), TOther);
                    return true;
                }
                else if ($.$spc.System.Type.op_Equality$1(TOther.$type, $.$spc.System.Char.$type))
                {
                    /*char*/ let actualResult;
                    if (!(value._bits === null))
                    {
                        actualResult = $.$srn.System.Numerics.BigInteger.IsNegative(value) ? /*\u0000*/ 0 : /*\uFFFF*/ 65535;
                    }
                    else 
                    {
                        actualResult = (value._sign >= /*\uFFFF*/ 65535) ? /*\uFFFF*/ 65535 : (value._sign <= /*\u0000*/ 0) ? /*\u0000*/ 0 : $.$cast(value._sign, $.$spc.System.Char);
                    }
                    result.$v = $.$cast($.$box(actualResult, $.$spc.System.Char), TOther);
                    return true;
                }
                else if ($.$spc.System.Type.op_Equality$1(TOther.$type, $.$spc.System.Decimal.$type))
                {
                    /*decimal*/ let actualResult = ($.$srn.System.Numerics.BigInteger.op_GreaterThanOrEqual(value, $.$srn.System.Numerics.BigInteger.op_Implicit$5(new $.$spc.System.Int128().$ctor$2(4294967295n, 18446744073709551615n)))) ? new $.$spc.System.Decimal().$ctor$9([-1, -1, -1, 0]) : ($.$srn.System.Numerics.BigInteger.op_LessThanOrEqual(value, $.$srn.System.Numerics.BigInteger.op_Implicit$5(new $.$spc.System.Int128().$ctor$2(18446744069414584320n, 1n)))) ? new $.$spc.System.Decimal().$ctor$9([-1, -1, -1, -2147483648]) : $.$srn.System.Numerics.BigInteger.op_Explicit$2(value);
                    result.$v = $.$cast($.$cast(actualResult, $.$spc.System.Object), TOther);
                    return true;
                }
                else if ($.$spc.System.Type.op_Equality$1(TOther.$type, $.$spc.System.Double.$type))
                {
                    /*double*/ let actualResult = $.$srn.System.Numerics.BigInteger.op_Explicit$3(value);
                    result.$v = $.$cast($.$box(actualResult, $.$spc.System.Double), TOther);
                    return true;
                }
                else if ($.$spc.System.Type.op_Equality$1(TOther.$type, $.$spc.System.Half.$type))
                {
                    /*Half*/ let actualResult = $.$srn.System.Numerics.BigInteger.op_Explicit$4(value);
                    result.$v = $.$cast($.$cast(actualResult, $.$spc.System.Object), TOther);
                    return true;
                }
                else if ($.$spc.System.Type.op_Equality$1(TOther.$type, $.$spc.System.Int16.$type))
                {
                    /*short*/ let actualResult;
                    if (!(value._bits === null))
                    {
                        actualResult = $.$srn.System.Numerics.BigInteger.IsNegative(value) ? -32768/*short.MinValue*/ : 32767/*short.MaxValue*/;
                    }
                    else 
                    {
                        actualResult = (value._sign >= 32767/*short.MaxValue*/) ? 32767/*short.MaxValue*/ : (value._sign <= -32768/*short.MinValue*/) ? -32768/*short.MinValue*/ : $.$cast(value._sign, $.$spc.System.Int16);
                    }
                    result.$v = $.$cast($.$box(actualResult, $.$spc.System.Int16), TOther);
                    return true;
                }
                else if ($.$spc.System.Type.op_Equality$1(TOther.$type, $.$spc.System.Int32.$type))
                {
                    /*int*/ let actualResult;
                    if (!(value._bits === null))
                    {
                        actualResult = $.$srn.System.Numerics.BigInteger.IsNegative(value) ? -2147483648/*int.MinValue*/ : 2147483647/*int.MaxValue*/;
                    }
                    else 
                    {
                        actualResult = (value._sign >= 2147483647/*int.MaxValue*/) ? 2147483647/*int.MaxValue*/ : (value._sign <= -2147483648/*int.MinValue*/) ? -2147483648/*int.MinValue*/ : value._sign;
                    }
                    result.$v = $.$cast($.$box(actualResult, $.$spc.System.Int32), TOther);
                    return true;
                }
                else if ($.$spc.System.Type.op_Equality$1(TOther.$type, $.$spc.System.Int64.$type))
                {
                    /*long*/ let actualResult = ($.$srn.System.Numerics.BigInteger.op_GreaterThanOrEqual$1(value, 9223372036854775807n)) ? 9223372036854775807n : ($.$srn.System.Numerics.BigInteger.op_LessThanOrEqual$1(value, -9223372036854775808n)) ? -9223372036854775808n : $.$srn.System.Numerics.BigInteger.op_Explicit$7(value);
                    result.$v = $.$cast($.$box(actualResult, $.$spc.System.Int64), TOther);
                    return true;
                }
                else if ($.$spc.System.Type.op_Equality$1(TOther.$type, $.$spc.System.Int128.$type))
                {
                    /*Int128*/ let actualResult = ($.$srn.System.Numerics.BigInteger.op_GreaterThanOrEqual(value, $.$srn.System.Numerics.BigInteger.op_Implicit$5($.$spc.System.Int128.MaxValue))) ? $.$spc.System.Int128.MaxValue : ($.$srn.System.Numerics.BigInteger.op_LessThanOrEqual(value, $.$srn.System.Numerics.BigInteger.op_Implicit$5($.$spc.System.Int128.MinValue))) ? $.$spc.System.Int128.MinValue : $.$srn.System.Numerics.BigInteger.op_Explicit$8(value);
                    result.$v = $.$cast($.$cast(actualResult, $.$spc.System.Object), TOther);
                    return true;
                }
                else if ($.$spc.System.Type.op_Equality$1(TOther.$type, $.$spc.System.IntPtr.$type))
                {
                    /*nint*/ let actualResult = ($.$srn.System.Numerics.BigInteger.op_GreaterThanOrEqual(value, BigInt($.$spc.System.IntPtr.MaxValue))) ? $.$spc.System.IntPtr.MaxValue : ($.$srn.System.Numerics.BigInteger.op_LessThanOrEqual(value, BigInt($.$spc.System.IntPtr.MinValue))) ? $.$spc.System.IntPtr.MinValue : $.$srn.System.Numerics.BigInteger.op_Explicit$9(value);
                    result.$v = $.$cast($.$box(actualResult, $.$spc.System.IntPtr), TOther);
                    return true;
                }
                else if ($.$spc.System.Type.op_Equality$1(TOther.$type, $.$srn.System.Numerics.Complex.$type))
                {
                    /*Complex*/ let actualResult = $.$srn.System.Numerics.Complex.op_Explicit$2(value);
                    result.$v = $.$cast($.$cast(actualResult, $.$spc.System.Object), TOther);
                    return true;
                }
                else if ($.$spc.System.Type.op_Equality$1(TOther.$type, $.$spc.System.SByte.$type))
                {
                    /*sbyte*/ let actualResult;
                    if (!(value._bits === null))
                    {
                        actualResult = $.$srn.System.Numerics.BigInteger.IsNegative(value) ? -128/*sbyte.MinValue*/ : 127/*sbyte.MaxValue*/;
                    }
                    else 
                    {
                        actualResult = (value._sign >= 127/*sbyte.MaxValue*/) ? 127/*sbyte.MaxValue*/ : (value._sign <= -128/*sbyte.MinValue*/) ? -128/*sbyte.MinValue*/ : $.$cast(value._sign, $.$spc.System.SByte);
                    }
                    result.$v = $.$cast($.$box(actualResult, $.$spc.System.SByte), TOther);
                    return true;
                }
                else if ($.$spc.System.Type.op_Equality$1(TOther.$type, $.$spc.System.Single.$type))
                {
                    /*float*/ let actualResult = $.$srn.System.Numerics.BigInteger.op_Explicit$11(value);
                    result.$v = $.$cast($.$box(actualResult, $.$spc.System.Single), TOther);
                    return true;
                }
                else if ($.$spc.System.Type.op_Equality$1(TOther.$type, $.$spc.System.UInt16.$type))
                {
                    /*ushort*/ let actualResult;
                    if (!(value._bits === null))
                    {
                        actualResult = $.$srn.System.Numerics.BigInteger.IsNegative(value) ? 0/*ushort.MinValue*/ : 65535/*ushort.MaxValue*/;
                    }
                    else 
                    {
                        actualResult = (value._sign >= 65535/*ushort.MaxValue*/) ? 65535/*ushort.MaxValue*/ : (value._sign <= 0/*ushort.MinValue*/) ? 0/*ushort.MinValue*/ : $.$cast(value._sign, $.$spc.System.UInt16);
                    }
                    result.$v = $.$cast($.$box(actualResult, $.$spc.System.UInt16), TOther);
                    return true;
                }
                else if ($.$spc.System.Type.op_Equality$1(TOther.$type, $.$spc.System.UInt32.$type))
                {
                    /*uint*/ let actualResult = ($.$srn.System.Numerics.BigInteger.op_GreaterThanOrEqual(value, BigInt(4294967295/*uint.MaxValue*/))) ? 4294967295/*uint.MaxValue*/ : $.$srn.System.Numerics.BigInteger.IsNegative(value) ? 0/*uint.MinValue*/ : $.$srn.System.Numerics.BigInteger.op_Explicit$13(value);
                    result.$v = $.$cast($.$box(actualResult, $.$spc.System.UInt32), TOther);
                    return true;
                }
                else if ($.$spc.System.Type.op_Equality$1(TOther.$type, $.$spc.System.UInt64.$type))
                {
                    /*ulong*/ let actualResult = ($.$srn.System.Numerics.BigInteger.op_GreaterThanOrEqual$3(value, 18446744073709551615n)) ? 18446744073709551615n : $.$srn.System.Numerics.BigInteger.IsNegative(value) ? 0n : $.$srn.System.Numerics.BigInteger.op_Explicit$14(value);
                    result.$v = $.$cast($.$box(actualResult, $.$spc.System.UInt64), TOther);
                    return true;
                }
                else if ($.$spc.System.Type.op_Equality$1(TOther.$type, $.$spc.System.UInt128.$type))
                {
                    /*UInt128*/ let actualResult = ($.$srn.System.Numerics.BigInteger.op_GreaterThanOrEqual(value, $.$srn.System.Numerics.BigInteger.op_Implicit$11($.$spc.System.UInt128.MaxValue))) ? $.$spc.System.UInt128.MaxValue : $.$srn.System.Numerics.BigInteger.IsNegative(value) ? $.$spc.System.UInt128.MinValue : $.$srn.System.Numerics.BigInteger.op_Explicit$15(value);
                    result.$v = $.$cast($.$cast(actualResult, $.$spc.System.Object), TOther);
                    return true;
                }
                else if ($.$spc.System.Type.op_Equality$1(TOther.$type, $.$spc.System.UIntPtr.$type))
                {
                    /*nuint*/ let actualResult = ($.$srn.System.Numerics.BigInteger.op_GreaterThanOrEqual(value, BigInt($.$spc.System.UIntPtr.MaxValue))) ? $.$spc.System.UIntPtr.MaxValue : $.$srn.System.Numerics.BigInteger.IsNegative(value) ? $.$spc.System.UIntPtr.MinValue : $.$srn.System.Numerics.BigInteger.op_Explicit$16(value);
                    result.$v = $.$cast($.$box(actualResult, $.$spc.System.UIntPtr), TOther);
                    return true;
                }
                else 
                {
                    result.$v = $.$default(TOther);
                    return false;
                }
            }
            static /*bool */ System$Numerics$INumberBase$$$TryConvertToTruncating(TOther, /*BigInteger*/ value, /*out TOther*/ result)
            {
                if ($.$spc.System.Type.op_Equality$1(TOther.$type, $.$spc.System.Byte.$type))
                {
                    /*byte*/ let actualResult;
                    if (!(value._bits === null))
                    {
                        /*uint*/ let bits = $.$spc.System.Array.$ReadT1.call(value._bits, 0);
                        if ($.$srn.System.Numerics.BigInteger.IsNegative(value))
                        {
                            bits = ((~bits + 1) >>> 0);
                        }
                        actualResult = $.$cast(bits, $.$spc.System.Byte);
                    }
                    else 
                    {
                        actualResult = $.$cast(value._sign, $.$spc.System.Byte);
                    }
                    result.$v = $.$cast($.$box(actualResult, $.$spc.System.Byte), TOther);
                    return true;
                }
                else if ($.$spc.System.Type.op_Equality$1(TOther.$type, $.$spc.System.Char.$type))
                {
                    /*char*/ let actualResult;
                    if (!(value._bits === null))
                    {
                        /*uint*/ let bits = $.$spc.System.Array.$ReadT1.call(value._bits, 0);
                        if ($.$srn.System.Numerics.BigInteger.IsNegative(value))
                        {
                            bits = ((~bits + 1) >>> 0);
                        }
                        actualResult = $.$cast(bits, $.$spc.System.Char);
                    }
                    else 
                    {
                        actualResult = $.$cast(value._sign, $.$spc.System.Char);
                    }
                    result.$v = $.$cast($.$box(actualResult, $.$spc.System.Char), TOther);
                    return true;
                }
                else if ($.$spc.System.Type.op_Equality$1(TOther.$type, $.$spc.System.Decimal.$type))
                {
                    /*decimal*/ let actualResult = ($.$srn.System.Numerics.BigInteger.op_GreaterThanOrEqual(value, $.$srn.System.Numerics.BigInteger.op_Implicit$5(new $.$spc.System.Int128().$ctor$2(4294967295n, 18446744073709551615n)))) ? new $.$spc.System.Decimal().$ctor$9([-1, -1, -1, 0]) : ($.$srn.System.Numerics.BigInteger.op_LessThanOrEqual(value, $.$srn.System.Numerics.BigInteger.op_Implicit$5(new $.$spc.System.Int128().$ctor$2(18446744069414584320n, 1n)))) ? new $.$spc.System.Decimal().$ctor$9([-1, -1, -1, -2147483648]) : $.$srn.System.Numerics.BigInteger.op_Explicit$2(value);
                    result.$v = $.$cast($.$cast(actualResult, $.$spc.System.Object), TOther);
                    return true;
                }
                else if ($.$spc.System.Type.op_Equality$1(TOther.$type, $.$spc.System.Double.$type))
                {
                    /*double*/ let actualResult = $.$srn.System.Numerics.BigInteger.op_Explicit$3(value);
                    result.$v = $.$cast($.$box(actualResult, $.$spc.System.Double), TOther);
                    return true;
                }
                else if ($.$spc.System.Type.op_Equality$1(TOther.$type, $.$spc.System.Half.$type))
                {
                    /*Half*/ let actualResult = $.$srn.System.Numerics.BigInteger.op_Explicit$4(value);
                    result.$v = $.$cast($.$cast(actualResult, $.$spc.System.Object), TOther);
                    return true;
                }
                else if ($.$spc.System.Type.op_Equality$1(TOther.$type, $.$spc.System.Int16.$type))
                {
                    /*short*/ let actualResult;
                    if (!(value._bits === null))
                    {
                        actualResult = $.$srn.System.Numerics.BigInteger.IsNegative(value) ? $.$cast((((~$.$spc.System.Array.$ReadT1.call(value._bits, 0) + 1) >>> 0)), $.$spc.System.Int16) : $.$cast($.$spc.System.Array.$ReadT1.call(value._bits, 0), $.$spc.System.Int16);
                    }
                    else 
                    {
                        actualResult = $.$cast(value._sign, $.$spc.System.Int16);
                    }
                    result.$v = $.$cast($.$box(actualResult, $.$spc.System.Int16), TOther);
                    return true;
                }
                else if ($.$spc.System.Type.op_Equality$1(TOther.$type, $.$spc.System.Int32.$type))
                {
                    /*int*/ let actualResult;
                    if (!(value._bits === null))
                    {
                        actualResult = $.$srn.System.Numerics.BigInteger.IsNegative(value) ? ((((~$.$spc.System.Array.$ReadT1.call(value._bits, 0) + 1) >>> 0)) | 0) : ($.$spc.System.Array.$ReadT1.call(value._bits, 0) | 0);
                    }
                    else 
                    {
                        actualResult = value._sign;
                    }
                    result.$v = $.$cast($.$box(actualResult, $.$spc.System.Int32), TOther);
                    return true;
                }
                else if ($.$spc.System.Type.op_Equality$1(TOther.$type, $.$spc.System.Int64.$type))
                {
                    /*long*/ let actualResult;
                    if (!(value._bits === null))
                    {
                        /*ulong*/ let bits = 0n;
                        if (value._bits.length >= 2)
                        {
                            bits = BigInt($.$spc.System.Array.$ReadT1.call(value._bits, 1));
                            bits <<= 32n;
                        }
                        bits |= BigInt($.$spc.System.Array.$ReadT1.call(value._bits, 0));
                        if ($.$srn.System.Numerics.BigInteger.IsNegative(value))
                        {
                            bits = (~bits & 0xFFFFFFFFFFFFFFFFn) + 1n;
                        }
                        actualResult = $.$cast(bits, $.$spc.System.Int64);
                    }
                    else 
                    {
                        actualResult = BigInt(value._sign);
                    }
                    result.$v = $.$cast($.$box(actualResult, $.$spc.System.Int64), TOther);
                    return true;
                }
                else if ($.$spc.System.Type.op_Equality$1(TOther.$type, $.$spc.System.Int128.$type))
                {
                    /*Int128*/ let actualResult;
                    if (!(value._bits === null))
                    {
                        /*ulong*/ let lowerBits = 0n;
                        /*ulong*/ let upperBits = 0n;
                        if (value._bits.length >= 4)
                        {
                            upperBits = BigInt($.$spc.System.Array.$ReadT1.call(value._bits, 3));
                            upperBits <<= 32n;
                        }
                        if (value._bits.length >= 3)
                        {
                            upperBits |= BigInt($.$spc.System.Array.$ReadT1.call(value._bits, 2));
                        }
                        if (value._bits.length >= 2)
                        {
                            lowerBits = BigInt($.$spc.System.Array.$ReadT1.call(value._bits, 1));
                            lowerBits <<= 32n;
                        }
                        lowerBits |= BigInt($.$spc.System.Array.$ReadT1.call(value._bits, 0));
                        /*UInt128*/ let bits = new $.$spc.System.UInt128().$ctor$2(upperBits, lowerBits);
                        if ($.$srn.System.Numerics.BigInteger.IsNegative(value))
                        {
                            bits = $.$spc.System.UInt128.op_Addition($.$spc.System.UInt128.op_OnesComplement(bits), $.$spc.System.UInt128.op_Implicit(1));
                        }
                        actualResult = $.$spc.System.UInt128.op_Explicit$8(bits);
                    }
                    else 
                    {
                        actualResult = $.$spc.System.Int128.op_Implicit$3(value._sign);
                    }
                    result.$v = $.$cast($.$cast(actualResult, $.$spc.System.Object), TOther);
                    return true;
                }
                else if ($.$spc.System.Type.op_Equality$1(TOther.$type, $.$spc.System.IntPtr.$type))
                {
                    /*nint*/ let actualResult;
                    if (!(value._bits === null))
                    {
                        /*nuint*/ let bits = 0;
                        if ($.$spc.System.Environment.Is64BitProcess && (value._bits.length >= 2))
                        {
                            bits = $.$spc.System.Array.$ReadT1.call(value._bits, 1);
                            bits <<= 32;
                        }
                        bits |= $.$spc.System.Array.$ReadT1.call(value._bits, 0);
                        if ($.$srn.System.Numerics.BigInteger.IsNegative(value))
                        {
                            bits = ~bits + 1;
                        }
                        actualResult = $.$cast(bits, $.$spc.System.IntPtr);
                    }
                    else 
                    {
                        actualResult = value._sign;
                    }
                    result.$v = $.$cast($.$box(actualResult, $.$spc.System.IntPtr), TOther);
                    return true;
                }
                else if ($.$spc.System.Type.op_Equality$1(TOther.$type, $.$srn.System.Numerics.Complex.$type))
                {
                    /*Complex*/ let actualResult = $.$srn.System.Numerics.Complex.op_Explicit$2(value);
                    result.$v = $.$cast($.$cast(actualResult, $.$spc.System.Object), TOther);
                    return true;
                }
                else if ($.$spc.System.Type.op_Equality$1(TOther.$type, $.$spc.System.SByte.$type))
                {
                    /*sbyte*/ let actualResult;
                    if (!(value._bits === null))
                    {
                        actualResult = $.$srn.System.Numerics.BigInteger.IsNegative(value) ? $.$cast((((~$.$spc.System.Array.$ReadT1.call(value._bits, 0) + 1) >>> 0)), $.$spc.System.SByte) : $.$cast($.$spc.System.Array.$ReadT1.call(value._bits, 0), $.$spc.System.SByte);
                    }
                    else 
                    {
                        actualResult = $.$cast(value._sign, $.$spc.System.SByte);
                    }
                    result.$v = $.$cast($.$box(actualResult, $.$spc.System.SByte), TOther);
                    return true;
                }
                else if ($.$spc.System.Type.op_Equality$1(TOther.$type, $.$spc.System.Single.$type))
                {
                    /*float*/ let actualResult = $.$srn.System.Numerics.BigInteger.op_Explicit$11(value);
                    result.$v = $.$cast($.$box(actualResult, $.$spc.System.Single), TOther);
                    return true;
                }
                else if ($.$spc.System.Type.op_Equality$1(TOther.$type, $.$spc.System.UInt16.$type))
                {
                    /*ushort*/ let actualResult;
                    if (!(value._bits === null))
                    {
                        /*uint*/ let bits = $.$spc.System.Array.$ReadT1.call(value._bits, 0);
                        if ($.$srn.System.Numerics.BigInteger.IsNegative(value))
                        {
                            bits = ((~bits + 1) >>> 0);
                        }
                        actualResult = $.$cast(bits, $.$spc.System.UInt16);
                    }
                    else 
                    {
                        actualResult = $.$cast(value._sign, $.$spc.System.UInt16);
                    }
                    result.$v = $.$cast($.$box(actualResult, $.$spc.System.UInt16), TOther);
                    return true;
                }
                else if ($.$spc.System.Type.op_Equality$1(TOther.$type, $.$spc.System.UInt32.$type))
                {
                    /*uint*/ let actualResult;
                    if (!(value._bits === null))
                    {
                        /*uint*/ let bits = $.$spc.System.Array.$ReadT1.call(value._bits, 0);
                        if ($.$srn.System.Numerics.BigInteger.IsNegative(value))
                        {
                            bits = ((~bits + 1) >>> 0);
                        }
                        actualResult = bits;
                    }
                    else 
                    {
                        actualResult = (value._sign >>> 0);
                    }
                    result.$v = $.$cast($.$box(actualResult, $.$spc.System.UInt32), TOther);
                    return true;
                }
                else if ($.$spc.System.Type.op_Equality$1(TOther.$type, $.$spc.System.UInt64.$type))
                {
                    /*ulong*/ let actualResult;
                    if (!(value._bits === null))
                    {
                        /*ulong*/ let bits = 0n;
                        if (value._bits.length >= 2)
                        {
                            bits = BigInt($.$spc.System.Array.$ReadT1.call(value._bits, 1));
                            bits <<= 32n;
                        }
                        bits |= BigInt($.$spc.System.Array.$ReadT1.call(value._bits, 0));
                        if ($.$srn.System.Numerics.BigInteger.IsNegative(value))
                        {
                            bits = (~bits & 0xFFFFFFFFFFFFFFFFn) + 1n;
                        }
                        actualResult = bits;
                    }
                    else 
                    {
                        actualResult = $.$cast(value._sign, $.$spc.System.UInt64);
                    }
                    result.$v = $.$cast($.$box(actualResult, $.$spc.System.UInt64), TOther);
                    return true;
                }
                else if ($.$spc.System.Type.op_Equality$1(TOther.$type, $.$spc.System.UInt128.$type))
                {
                    /*UInt128*/ let actualResult;
                    if (!(value._bits === null))
                    {
                        /*ulong*/ let lowerBits = 0n;
                        /*ulong*/ let upperBits = 0n;
                        if (value._bits.length >= 4)
                        {
                            upperBits = BigInt($.$spc.System.Array.$ReadT1.call(value._bits, 3));
                            upperBits <<= 32n;
                        }
                        if (value._bits.length >= 3)
                        {
                            upperBits |= BigInt($.$spc.System.Array.$ReadT1.call(value._bits, 2));
                        }
                        if (value._bits.length >= 2)
                        {
                            lowerBits = BigInt($.$spc.System.Array.$ReadT1.call(value._bits, 1));
                            lowerBits <<= 32n;
                        }
                        lowerBits |= BigInt($.$spc.System.Array.$ReadT1.call(value._bits, 0));
                        /*UInt128*/ let bits = new $.$spc.System.UInt128().$ctor$2(upperBits, lowerBits);
                        if ($.$srn.System.Numerics.BigInteger.IsNegative(value))
                        {
                            bits = $.$spc.System.UInt128.op_Addition($.$spc.System.UInt128.op_OnesComplement(bits), $.$spc.System.UInt128.op_Implicit(1));
                        }
                        actualResult = bits;
                    }
                    else 
                    {
                        actualResult = $.$spc.System.UInt128.op_Explicit$19(value._sign);
                    }
                    result.$v = $.$cast($.$cast(actualResult, $.$spc.System.Object), TOther);
                    return true;
                }
                else if ($.$spc.System.Type.op_Equality$1(TOther.$type, $.$spc.System.UIntPtr.$type))
                {
                    /*nuint*/ let actualResult;
                    if (!(value._bits === null))
                    {
                        /*nuint*/ let bits = 0;
                        if ($.$spc.System.Environment.Is64BitProcess && (value._bits.length >= 2))
                        {
                            bits = $.$spc.System.Array.$ReadT1.call(value._bits, 1);
                            bits <<= 32;
                        }
                        bits |= $.$spc.System.Array.$ReadT1.call(value._bits, 0);
                        if ($.$srn.System.Numerics.BigInteger.IsNegative(value))
                        {
                            bits = ~bits + 1;
                        }
                        actualResult = bits;
                    }
                    else 
                    {
                        actualResult = (value._sign >>> 0);
                    }
                    result.$v = $.$cast($.$box(actualResult, $.$spc.System.UIntPtr), TOther);
                    return true;
                }
                else 
                {
                    result.$v = $.$default(TOther);
                    return false;
                }
            }
            static /*bool */ TryParse$4(/*string?*/ s, /*IFormatProvider?*/ provider, /*out BigInteger*/ result)
            {
                return $.$srn.System.Numerics.BigInteger.TryParse$1(s, 7/*NumberStyles.Integer*/, provider, result);
            }
            static /*BigInteger */ op_UnsignedRightShift(/*BigInteger*/ value, /*int*/ shiftAmount)
            {
                /*BigInteger*/ let result;
                /*bool*/ let negx;
                /*uint*/ let smallBits;
                /*scoped ReadOnlySpan<uint>*/ let bits;
                /*int*/ let xl;
                /*uint[]?*/ let xdFromPool;
                /*Span<uint>*/ let xd;
                /*uint[]?*/ let zdFromPool;
                /*int*/ let zl;
                /*Span<uint>*/ let zd;
                let $gotoJumpState1 = 0;
                $gotoJumpStart1: while(true)
                {
                    switch($gotoJumpState1)
                    {
                        case 0:
                        {
                            value.AssertValid();
                            if (shiftAmount === 0)
                            {
                                return value;
                            }
                            if (shiftAmount === -2147483648/*int.MinValue*/)
                            {
                                return ($.$srn.System.Numerics.BigInteger.op_LeftShift(($.$srn.System.Numerics.BigInteger.op_LeftShift(value, 2147483647/*int.MaxValue*/)), 1));
                            }
                            if (shiftAmount < 0)
                            {
                                return $.$srn.System.Numerics.BigInteger.op_LeftShift(value, -shiftAmount);
                            }
                            const { Item1: digitShift, Item2: smallShift } = $.$spc.System.Math.DivRem$6(shiftAmount, 32/*kcbitUint*/);
                            negx = value._sign < 0;
                            smallBits = $.$srn.System.Numerics.NumericsHelpers.Abs(value._sign);
                            bits = $.$spc.System.ReadOnlySpan$$($.$spc.System.UInt32).op_Implicit(value._bits);
                            if (bits.IsEmpty)
                            {
                                bits = new ($.$spc.System.ReadOnlySpan$$($.$spc.System.UInt32))().$ctor$5($.$ref(() => smallBits, undefined, $.$spc.System.UInt32));
                            }
                            xl = bits.Length;
                            if (negx && (bits.get_Item(bits.Length - 1).$v >= 2147483648/*kuMaskHighBit*/) && ((bits.get_Item(bits.Length - 1).$v !== 2147483648/*kuMaskHighBit*/) || $.$spc.System.MemoryExtensions.IndexOfAnyExcept$5($.$spc.System.UInt32, bits, 0) !== (((bits.Length - 1) | 0))))
                            {
                                ++xl;
                            }
                            xdFromPool = null;
                            xd = (xl <= $.$srn.System.Numerics.BigIntegerCalculator.StackAllocThreshold ? $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.StackAllocSpan($.$spc.System.UInt32, $.$srn.System.Numerics.BigIntegerCalculator.StackAllocThreshold, null) : $.$spc.System.Span$$($.$spc.System.UInt32).op_Implicit(xdFromPool = $.$spc.System.Buffers.ArrayPool$$($.$spc.System.UInt32).Shared.Rent(xl))).Slice$1(0, xl);
                            xd.get_Item(xd.Length - 1).$v = 0;
                            bits.CopyTo(xd);
                            if (negx)
                            {
                                if (BigInt(shiftAmount) >= ($.$cast(32/*kcbitUint*/, $.$spc.System.Int64) * BigInt(xd.Length)))
                                {
                                    result = $.$srn.System.Numerics.BigInteger.MinusOne;
                                    $gotoJumpState1 = 1; /*goto exit*/
                                    continue $gotoJumpStart1;
                                }
                                $.$srn.System.Numerics.NumericsHelpers.DangerousMakeTwosComplement(xd);
                            }
                            zdFromPool = null;
                            zl = $.$spc.System.Math.Max$4(((xl - digitShift) | 0), 0);
                            zd = (BigInt((zl >>> 0)) <= BigInt($.$srn.System.Numerics.BigIntegerCalculator.StackAllocThreshold) ? $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.StackAllocSpan($.$spc.System.UInt32, $.$srn.System.Numerics.BigIntegerCalculator.StackAllocThreshold, null) : $.$spc.System.Span$$($.$spc.System.UInt32).op_Implicit(zdFromPool = $.$spc.System.Buffers.ArrayPool$$($.$spc.System.UInt32).Shared.Rent(zl))).Slice$1(0, zl);
                            zd.Clear();
                            if (smallShift === 0)
                            {
                                for(/*int*/ let i = ((xd.Length - 1) | 0); i >= digitShift; i--)
                                {
                                    zd.get_Item(((i - digitShift) | 0)).$v = xd.get_Item(i).$v;
                                }
                            }
                            else 
                            {
                                /*int*/ let carryShift = ((32/*kcbitUint*/ - smallShift) | 0);
                                /*uint*/ let carry = 0;
                                for(/*int*/ let i = ((xd.Length - 1) | 0); i >= digitShift; i--)
                                {
                                    /*uint*/ let rot = xd.get_Item(i).$v;
                                    zd.get_Item(((i - digitShift) | 0)).$v = (rot >>> smallShift) | carry;
                                    carry = (rot << carryShift) >>> 0;
                                }
                            }
                            if (negx && (zd.get_Item(zd.Length - 1).$v | 0) < 0)
                            {
                                $.$srn.System.Numerics.NumericsHelpers.DangerousMakeTwosComplement(zd);
                            }
                            else 
                            {
                                negx = false;
                            }
                            result = new $.$srn.System.Numerics.BigInteger().$ctor$12($.$spc.System.Span$$($.$spc.System.UInt32).op_Implicit$2(zd), negx);
                            if (zdFromPool !== null)
                            {
                                $.$spc.System.Buffers.ArrayPool$$($.$spc.System.UInt32).Shared.Return(zdFromPool, false);
                            }
                        }
                        case 1: /*exit*/
                        if (xdFromPool !== null)
                        {
                            $.$spc.System.Buffers.ArrayPool$$($.$spc.System.UInt32).Shared.Return(xdFromPool, false);
                        }
                        return result;
                    }
                    break;
                }
            }
            static /*BigInteger */ get System$Numerics$ISignedNumber$$$NegativeOne()
            {
                return $.$srn.System.Numerics.BigInteger.MinusOne;
            }
            static /*BigInteger */ Parse$5(/*ReadOnlySpan<char>*/ s, /*IFormatProvider?*/ provider)
            {
                return $.$srn.System.Numerics.BigInteger.Parse$4(s, 7/*NumberStyles.Integer*/, provider);
            }
            static /*bool */ TryParse$5(/*ReadOnlySpan<char>*/ s, /*IFormatProvider?*/ provider, /*out BigInteger*/ result)
            {
                return $.$srn.System.Numerics.BigInteger.TryParse$3(s, 7/*NumberStyles.Integer*/, provider, result);
            }
            //Generated interface implemetation for System.Numerics.IBinaryInteger<System.Numerics.BigInteger>.DivRem(System.Numerics.BigInteger, System.Numerics.BigInteger)
            static System$Numerics$IBinaryInteger$$$DivRem()
            {
                return $.$srn.System.Numerics.BigInteger.DivRem$1(...arguments);
            }
            //Generated interface implemetation for System.Numerics.IBinaryInteger<System.Numerics.BigInteger>.LeadingZeroCount(System.Numerics.BigInteger)
            static System$Numerics$IBinaryInteger$$$LeadingZeroCount()
            {
                return $.$srn.System.Numerics.BigInteger.LeadingZeroCount(...arguments);
            }
            //Generated interface implemetation for System.Numerics.IBinaryInteger<System.Numerics.BigInteger>.PopCount(System.Numerics.BigInteger)
            static System$Numerics$IBinaryInteger$$$PopCount()
            {
                return $.$srn.System.Numerics.BigInteger.PopCount(...arguments);
            }
            //Generated interface implemetation for System.Numerics.IBinaryInteger<System.Numerics.BigInteger>.RotateLeft(System.Numerics.BigInteger, int)
            static System$Numerics$IBinaryInteger$$$RotateLeft()
            {
                return $.$srn.System.Numerics.BigInteger.RotateLeft(...arguments);
            }
            //Generated interface implemetation for System.Numerics.IBinaryInteger<System.Numerics.BigInteger>.RotateRight(System.Numerics.BigInteger, int)
            static System$Numerics$IBinaryInteger$$$RotateRight()
            {
                return $.$srn.System.Numerics.BigInteger.RotateRight(...arguments);
            }
            //Generated interface implemetation for System.Numerics.IBinaryInteger<System.Numerics.BigInteger>.TrailingZeroCount(System.Numerics.BigInteger)
            static System$Numerics$IBinaryInteger$$$TrailingZeroCount()
            {
                return $.$srn.System.Numerics.BigInteger.TrailingZeroCount(...arguments);
            }
            //Generated interface implemetation for System.Numerics.IBinaryNumber<System.Numerics.BigInteger>.IsPow2(System.Numerics.BigInteger)
            static System$Numerics$IBinaryNumber$$$IsPow2()
            {
                return $.$srn.System.Numerics.BigInteger.IsPow2(...arguments);
            }
            //Generated interface implemetation for System.Numerics.IBinaryNumber<System.Numerics.BigInteger>.Log2(System.Numerics.BigInteger)
            static System$Numerics$IBinaryNumber$$$Log2()
            {
                return $.$srn.System.Numerics.BigInteger.Log2(...arguments);
            }
            //Generated interface implemetation for System.Numerics.IBitwiseOperators<System.Numerics.BigInteger, System.Numerics.BigInteger, System.Numerics.BigInteger>.operator &(System.Numerics.BigInteger, System.Numerics.BigInteger)
            static System$Numerics$IBitwiseOperators$$$$$op_BitwiseAnd()
            {
                return $.$srn.System.Numerics.BigInteger.op_BitwiseAnd(...arguments);
            }
            //Generated interface implemetation for System.Numerics.IBitwiseOperators<System.Numerics.BigInteger, System.Numerics.BigInteger, System.Numerics.BigInteger>.operator |(System.Numerics.BigInteger, System.Numerics.BigInteger)
            static System$Numerics$IBitwiseOperators$$$$$op_BitwiseOr()
            {
                return $.$srn.System.Numerics.BigInteger.op_BitwiseOr(...arguments);
            }
            //Generated interface implemetation for System.Numerics.IBitwiseOperators<System.Numerics.BigInteger, System.Numerics.BigInteger, System.Numerics.BigInteger>.operator ^(System.Numerics.BigInteger, System.Numerics.BigInteger)
            static System$Numerics$IBitwiseOperators$$$$$op_ExclusiveOr()
            {
                return $.$srn.System.Numerics.BigInteger.op_ExclusiveOr(...arguments);
            }
            //Generated interface implemetation for System.Numerics.IBitwiseOperators<System.Numerics.BigInteger, System.Numerics.BigInteger, System.Numerics.BigInteger>.operator ~(System.Numerics.BigInteger)
            static System$Numerics$IBitwiseOperators$$$$$op_OnesComplement()
            {
                return $.$srn.System.Numerics.BigInteger.op_OnesComplement(...arguments);
            }
            //Generated interface implemetation for System.Numerics.INumber<System.Numerics.BigInteger>.Clamp(System.Numerics.BigInteger, System.Numerics.BigInteger, System.Numerics.BigInteger)
            static System$Numerics$INumber$$$Clamp()
            {
                return $.$srn.System.Numerics.BigInteger.Clamp(...arguments);
            }
            //Generated interface implemetation for System.Numerics.INumber<System.Numerics.BigInteger>.CopySign(System.Numerics.BigInteger, System.Numerics.BigInteger)
            static System$Numerics$INumber$$$CopySign()
            {
                return $.$srn.System.Numerics.BigInteger.CopySign(...arguments);
            }
            //Generated interface implemetation for System.Numerics.INumber<System.Numerics.BigInteger>.Max(System.Numerics.BigInteger, System.Numerics.BigInteger)
            static System$Numerics$INumber$$$Max()
            {
                return $.$srn.System.Numerics.BigInteger.Max(...arguments);
            }
            //Generated interface implemetation for System.Numerics.INumber<System.Numerics.BigInteger>.Min(System.Numerics.BigInteger, System.Numerics.BigInteger)
            static System$Numerics$INumber$$$Min()
            {
                return $.$srn.System.Numerics.BigInteger.Min(...arguments);
            }
            //Generated interface implemetation for System.IComparable.CompareTo(object?)
            System$IComparable$CompareTo()
            {
                return this.CompareTo$3(...arguments);
            }
            //Generated interface implemetation for System.IComparable<System.Numerics.BigInteger>.CompareTo(System.Numerics.BigInteger)
            System$IComparable$$$CompareTo()
            {
                return this.CompareTo$2(...arguments);
            }
            //Generated interface implemetation for System.Numerics.IComparisonOperators<System.Numerics.BigInteger, System.Numerics.BigInteger, bool>.operator <(System.Numerics.BigInteger, System.Numerics.BigInteger)
            static System$Numerics$IComparisonOperators$$$$$op_LessThan()
            {
                return $.$srn.System.Numerics.BigInteger.op_LessThan(...arguments);
            }
            //Generated interface implemetation for System.Numerics.IComparisonOperators<System.Numerics.BigInteger, System.Numerics.BigInteger, bool>.operator <=(System.Numerics.BigInteger, System.Numerics.BigInteger)
            static System$Numerics$IComparisonOperators$$$$$op_LessThanOrEqual()
            {
                return $.$srn.System.Numerics.BigInteger.op_LessThanOrEqual(...arguments);
            }
            //Generated interface implemetation for System.Numerics.IComparisonOperators<System.Numerics.BigInteger, System.Numerics.BigInteger, bool>.operator >(System.Numerics.BigInteger, System.Numerics.BigInteger)
            static System$Numerics$IComparisonOperators$$$$$op_GreaterThan()
            {
                return $.$srn.System.Numerics.BigInteger.op_GreaterThan(...arguments);
            }
            //Generated interface implemetation for System.Numerics.IComparisonOperators<System.Numerics.BigInteger, System.Numerics.BigInteger, bool>.operator >=(System.Numerics.BigInteger, System.Numerics.BigInteger)
            static System$Numerics$IComparisonOperators$$$$$op_GreaterThanOrEqual()
            {
                return $.$srn.System.Numerics.BigInteger.op_GreaterThanOrEqual(...arguments);
            }
            //Generated interface implemetation for System.Numerics.IModulusOperators<System.Numerics.BigInteger, System.Numerics.BigInteger, System.Numerics.BigInteger>.operator %(System.Numerics.BigInteger, System.Numerics.BigInteger)
            static System$Numerics$IModulusOperators$$$$$op_Modulus()
            {
                return $.$srn.System.Numerics.BigInteger.op_Modulus(...arguments);
            }
            //Generated interface implemetation for System.Numerics.IShiftOperators<System.Numerics.BigInteger, int, System.Numerics.BigInteger>.operator <<(System.Numerics.BigInteger, int)
            static System$Numerics$IShiftOperators$$$$$op_LeftShift()
            {
                return $.$srn.System.Numerics.BigInteger.op_LeftShift(...arguments);
            }
            //Generated interface implemetation for System.Numerics.IShiftOperators<System.Numerics.BigInteger, int, System.Numerics.BigInteger>.operator >>(System.Numerics.BigInteger, int)
            static System$Numerics$IShiftOperators$$$$$op_RightShift()
            {
                return $.$srn.System.Numerics.BigInteger.op_RightShift(...arguments);
            }
            //Generated interface implemetation for System.Numerics.IShiftOperators<System.Numerics.BigInteger, int, System.Numerics.BigInteger>.operator >>>(System.Numerics.BigInteger, int)
            static System$Numerics$IShiftOperators$$$$$op_UnsignedRightShift()
            {
                return $.$srn.System.Numerics.BigInteger.op_UnsignedRightShift(...arguments);
            }
            //Generated interface implemetation for System.Numerics.INumberBase<System.Numerics.BigInteger>.One.get
            static get System$Numerics$INumberBase$$$One()
            {
                return $.$srn.System.Numerics.BigInteger.One;
            }
            //Generated interface implemetation for System.Numerics.INumberBase<System.Numerics.BigInteger>.Zero.get
            static get System$Numerics$INumberBase$$$Zero()
            {
                return $.$srn.System.Numerics.BigInteger.Zero;
            }
            //Generated interface implemetation for System.Numerics.INumberBase<System.Numerics.BigInteger>.Abs(System.Numerics.BigInteger)
            static System$Numerics$INumberBase$$$Abs()
            {
                return $.$srn.System.Numerics.BigInteger.Abs(...arguments);
            }
            //Generated interface implemetation for System.Numerics.INumberBase<System.Numerics.BigInteger>.CreateChecked<TOther>(TOther)
            static System$Numerics$INumberBase$$$CreateChecked()
            {
                return $.$srn.System.Numerics.BigInteger.CreateChecked(...arguments);
            }
            //Generated interface implemetation for System.Numerics.INumberBase<System.Numerics.BigInteger>.CreateSaturating<TOther>(TOther)
            static System$Numerics$INumberBase$$$CreateSaturating()
            {
                return $.$srn.System.Numerics.BigInteger.CreateSaturating(...arguments);
            }
            //Generated interface implemetation for System.Numerics.INumberBase<System.Numerics.BigInteger>.CreateTruncating<TOther>(TOther)
            static System$Numerics$INumberBase$$$CreateTruncating()
            {
                return $.$srn.System.Numerics.BigInteger.CreateTruncating(...arguments);
            }
            //Generated interface implemetation for System.Numerics.INumberBase<System.Numerics.BigInteger>.IsEvenInteger(System.Numerics.BigInteger)
            static System$Numerics$INumberBase$$$IsEvenInteger()
            {
                return $.$srn.System.Numerics.BigInteger.IsEvenInteger(...arguments);
            }
            //Generated interface implemetation for System.Numerics.INumberBase<System.Numerics.BigInteger>.IsNegative(System.Numerics.BigInteger)
            static System$Numerics$INumberBase$$$IsNegative()
            {
                return $.$srn.System.Numerics.BigInteger.IsNegative(...arguments);
            }
            //Generated interface implemetation for System.Numerics.INumberBase<System.Numerics.BigInteger>.IsOddInteger(System.Numerics.BigInteger)
            static System$Numerics$INumberBase$$$IsOddInteger()
            {
                return $.$srn.System.Numerics.BigInteger.IsOddInteger(...arguments);
            }
            //Generated interface implemetation for System.Numerics.INumberBase<System.Numerics.BigInteger>.IsPositive(System.Numerics.BigInteger)
            static System$Numerics$INumberBase$$$IsPositive()
            {
                return $.$srn.System.Numerics.BigInteger.IsPositive(...arguments);
            }
            //Generated interface implemetation for System.Numerics.INumberBase<System.Numerics.BigInteger>.MaxMagnitude(System.Numerics.BigInteger, System.Numerics.BigInteger)
            static System$Numerics$INumberBase$$$MaxMagnitude()
            {
                return $.$srn.System.Numerics.BigInteger.MaxMagnitude(...arguments);
            }
            //Generated interface implemetation for System.Numerics.INumberBase<System.Numerics.BigInteger>.MinMagnitude(System.Numerics.BigInteger, System.Numerics.BigInteger)
            static System$Numerics$INumberBase$$$MinMagnitude()
            {
                return $.$srn.System.Numerics.BigInteger.MinMagnitude(...arguments);
            }
            //Generated interface implemetation for System.Numerics.INumberBase<System.Numerics.BigInteger>.Parse(string, System.Globalization.NumberStyles, System.IFormatProvider?)
            static System$Numerics$INumberBase$$$Parse()
            {
                return $.$srn.System.Numerics.BigInteger.Parse$3(...arguments);
            }
            //Generated interface implemetation for System.Numerics.INumberBase<System.Numerics.BigInteger>.Parse(System.ReadOnlySpan<char>, System.Globalization.NumberStyles, System.IFormatProvider?)
            static System$Numerics$INumberBase$$$Parse$1()
            {
                return $.$srn.System.Numerics.BigInteger.Parse$4(...arguments);
            }
            //Generated interface implemetation for System.Numerics.INumberBase<System.Numerics.BigInteger>.TryParse(string?, System.Globalization.NumberStyles, System.IFormatProvider?, out System.Numerics.BigInteger)
            static System$Numerics$INumberBase$$$TryParse()
            {
                return $.$srn.System.Numerics.BigInteger.TryParse$1(...arguments);
            }
            //Generated interface implemetation for System.Numerics.INumberBase<System.Numerics.BigInteger>.TryParse(System.ReadOnlySpan<char>, System.Globalization.NumberStyles, System.IFormatProvider?, out System.Numerics.BigInteger)
            static System$Numerics$INumberBase$$$TryParse$1()
            {
                return $.$srn.System.Numerics.BigInteger.TryParse$3(...arguments);
            }
            //Generated interface implemetation for System.Numerics.IAdditionOperators<System.Numerics.BigInteger, System.Numerics.BigInteger, System.Numerics.BigInteger>.operator +(System.Numerics.BigInteger, System.Numerics.BigInteger)
            static System$Numerics$IAdditionOperators$$$$$op_Addition()
            {
                return $.$srn.System.Numerics.BigInteger.op_Addition(...arguments);
            }
            //Generated interface implemetation for System.Numerics.IDecrementOperators<System.Numerics.BigInteger>.operator --(System.Numerics.BigInteger)
            static System$Numerics$IDecrementOperators$$$op_Decrement()
            {
                return $.$srn.System.Numerics.BigInteger.op_Decrement(...arguments);
            }
            //Generated interface implemetation for System.Numerics.IDivisionOperators<System.Numerics.BigInteger, System.Numerics.BigInteger, System.Numerics.BigInteger>.operator /(System.Numerics.BigInteger, System.Numerics.BigInteger)
            static System$Numerics$IDivisionOperators$$$$$op_Division()
            {
                return $.$srn.System.Numerics.BigInteger.op_Division(...arguments);
            }
            //Generated interface implemetation for System.IEquatable<System.Numerics.BigInteger>.Equals(System.Numerics.BigInteger)
            System$IEquatable$$$Equals()
            {
                return this.Equals$4(...arguments);
            }
            //Generated interface implemetation for System.Numerics.IEqualityOperators<System.Numerics.BigInteger, System.Numerics.BigInteger, bool>.operator ==(System.Numerics.BigInteger, System.Numerics.BigInteger)
            static System$Numerics$IEqualityOperators$$$$$op_Equality()
            {
                return $.$srn.System.Numerics.BigInteger.op_Equality(...arguments);
            }
            //Generated interface implemetation for System.Numerics.IEqualityOperators<System.Numerics.BigInteger, System.Numerics.BigInteger, bool>.operator !=(System.Numerics.BigInteger, System.Numerics.BigInteger)
            static System$Numerics$IEqualityOperators$$$$$op_Inequality()
            {
                return $.$srn.System.Numerics.BigInteger.op_Inequality(...arguments);
            }
            //Generated interface implemetation for System.Numerics.IIncrementOperators<System.Numerics.BigInteger>.operator ++(System.Numerics.BigInteger)
            static System$Numerics$IIncrementOperators$$$op_Increment()
            {
                return $.$srn.System.Numerics.BigInteger.op_Increment(...arguments);
            }
            //Generated interface implemetation for System.Numerics.IMultiplyOperators<System.Numerics.BigInteger, System.Numerics.BigInteger, System.Numerics.BigInteger>.operator *(System.Numerics.BigInteger, System.Numerics.BigInteger)
            static System$Numerics$IMultiplyOperators$$$$$op_Multiply()
            {
                return $.$srn.System.Numerics.BigInteger.op_Multiply(...arguments);
            }
            //Generated interface implemetation for System.ISpanFormattable.TryFormat(System.Span<char>, out int, System.ReadOnlySpan<char>, System.IFormatProvider?)
            System$ISpanFormattable$TryFormat()
            {
                return this.TryFormat(...arguments);
            }
            //Generated interface implemetation for System.IFormattable.ToString(string?, System.IFormatProvider?)
            System$IFormattable$ToString()
            {
                return this.ToString$3(...arguments);
            }
            //Generated interface implemetation for System.ISpanParsable<System.Numerics.BigInteger>.Parse(System.ReadOnlySpan<char>, System.IFormatProvider?)
            static System$ISpanParsable$$$Parse()
            {
                return $.$srn.System.Numerics.BigInteger.Parse$5(...arguments);
            }
            //Generated interface implemetation for System.ISpanParsable<System.Numerics.BigInteger>.TryParse(System.ReadOnlySpan<char>, System.IFormatProvider?, out System.Numerics.BigInteger)
            static System$ISpanParsable$$$TryParse()
            {
                return $.$srn.System.Numerics.BigInteger.TryParse$5(...arguments);
            }
            //Generated interface implemetation for System.IParsable<System.Numerics.BigInteger>.Parse(string, System.IFormatProvider?)
            static System$IParsable$$$Parse()
            {
                return $.$srn.System.Numerics.BigInteger.Parse$2(...arguments);
            }
            //Generated interface implemetation for System.IParsable<System.Numerics.BigInteger>.TryParse(string?, System.IFormatProvider?, out System.Numerics.BigInteger)
            static System$IParsable$$$TryParse()
            {
                return $.$srn.System.Numerics.BigInteger.TryParse$4(...arguments);
            }
            //Generated interface implemetation for System.Numerics.ISubtractionOperators<System.Numerics.BigInteger, System.Numerics.BigInteger, System.Numerics.BigInteger>.operator -(System.Numerics.BigInteger, System.Numerics.BigInteger)
            static System$Numerics$ISubtractionOperators$$$$$op_Subtraction()
            {
                return $.$srn.System.Numerics.BigInteger.op_Subtraction(...arguments);
            }
            //Generated interface implemetation for System.Numerics.IUnaryPlusOperators<System.Numerics.BigInteger, System.Numerics.BigInteger>.operator +(System.Numerics.BigInteger)
            static System$Numerics$IUnaryPlusOperators$$$$op_UnaryPlus()
            {
                return $.$srn.System.Numerics.BigInteger.op_UnaryPlus(...arguments);
            }
            //Generated interface implemetation for System.Numerics.IUnaryNegationOperators<System.Numerics.BigInteger, System.Numerics.BigInteger>.operator -(System.Numerics.BigInteger)
            static System$Numerics$IUnaryNegationOperators$$$$op_UnaryNegation()
            {
                return $.$srn.System.Numerics.BigInteger.op_UnaryNegation(...arguments);
            }
            //default value type constructor
            $ctor$14()
            {
                return this;
            }
            Clone($copy)
            {
                let copy = $copy ?? new this.constructor();
                copy._sign = this._sign;
                copy._bits = this._bits;
                return copy;
            }
            //default member initializer
            constructor()
            {
                super();
                this._sign = 0;
                this._bits = null;
            }
            //Static Initializer
            static $sinit()
            {
                {
                    this.s_bnMinInt = new $.$srn.System.Numerics.BigInteger().$ctor$11(-1, $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$spc.System.UInt32), [2147483648/*kuMaskHighBit*/], [-1], null));
                }
                {
                    this.s_bnOneInt = new $.$srn.System.Numerics.BigInteger().$ctor$2(1);
                }
                {
                    this.s_bnZeroInt = new $.$srn.System.Numerics.BigInteger().$ctor$2(0);
                }
                {
                    this.s_bnMinusOneInt = new $.$srn.System.Numerics.BigInteger().$ctor$2(-1);
                }
            }
            static $h = 830225;
            static $z = 8;
            static $f = 0b1010000001;
            static $k = 2;
            static $$md;
            static get $md() { return this.$$md ??= {"b":196609,"p":[{"p":655361,"g":{"r":0,"d":0,"h":25770634001,"f":40},"n":"MaxLength","d":830225,"h":21475666705,"f":40},{"p":830225,"g":{"r":0,"d":0,"h":111669979921,"f":33},"n":"Zero","d":830225,"h":107375012625,"f":33},{"p":830225,"g":{"r":0,"d":0,"h":120259914513,"f":33},"n":"One","d":830225,"h":115964947217,"f":33},{"p":830225,"g":{"r":0,"d":0,"h":128849849105,"f":33},"n":"MinusOne","d":830225,"h":124554881809,"f":33},{"p":262145,"g":{"r":0,"d":0,"h":137439783697,"f":1},"n":"IsPowerOfTwo","d":830225,"h":133144816401,"f":1},{"p":262145,"g":{"r":0,"d":0,"h":146029718289,"f":1},"n":"IsZero","d":830225,"h":141734750993,"f":1},{"p":262145,"g":{"r":0,"d":0,"h":154619652881,"f":1},"n":"IsOne","d":830225,"h":150324685585,"f":1},{"p":262145,"g":{"r":0,"d":0,"h":163209587473,"f":1},"n":"IsEven","d":830225,"h":158914620177,"f":1},{"p":655361,"g":{"r":0,"d":0,"h":171799522065,"f":1},"n":"Sign","d":830225,"h":167504554769,"f":1},{"p":1310721,"g":{"r":0,"d":0,"h":386547886865,"f":2},"n":"DebuggerDisplay","d":830225,"h":382252919569,"f":2},{"p":830225,"g":{"r":0,"d":0,"h":768799976209,"f":34},"n":"{$.$spc.System.Numerics.IAdditiveIdentity$$$($.$srn.System.Numerics.BigInteger, $.$srn.System.Numerics.BigInteger).$h}.AdditiveIdentity","o":"System$Numerics$IAdditiveIdentity$$$$AdditiveIdentity","d":830225,"h":764505008913,"f":34},{"p":830225,"g":{"r":0,"d":0,"h":833224485649,"f":34},"n":"{$.$spc.System.Numerics.IBinaryNumber$$($.$srn.System.Numerics.BigInteger).$h}.AllBitsSet","o":"System$Numerics$IBinaryNumber$$$AllBitsSet","d":830225,"h":828929518353,"f":34},{"p":830225,"g":{"r":0,"d":0,"h":850404354833,"f":34},"n":"{$.$spc.System.Numerics.IMultiplicativeIdentity$$$($.$srn.System.Numerics.BigInteger, $.$srn.System.Numerics.BigInteger).$h}.MultiplicativeIdentity","o":"System$Numerics$IMultiplicativeIdentity$$$$MultiplicativeIdentity","d":830225,"h":846109387537,"f":34},{"p":655361,"g":{"r":0,"d":0,"h":880469125905,"f":34},"n":"{$.$spc.System.Numerics.INumberBase$$($.$srn.System.Numerics.BigInteger).$h}.Radix","o":"System$Numerics$INumberBase$$$Radix","d":830225,"h":876174158609,"f":34},{"p":830225,"g":{"r":0,"d":0,"h":1043677883153,"f":34},"n":"{$.$spc.System.Numerics.ISignedNumber$$($.$srn.System.Numerics.BigInteger).$h}.NegativeOne","o":"System$Numerics$ISignedNumber$$$NegativeOne","d":830225,"h":1039382915857,"f":34}],"m":[{"r":830225,"p":[{"n":"value","p":1310721}],"n":"Parse","d":830225,"h":176094489361,"f":33},{"r":830225,"p":[{"n":"value","p":1310721},{"n":"style","p":54067201}],"n":"Parse","o":"@$1","d":830225,"h":180389456657,"f":33},{"r":830225,"p":[{"n":"value","p":1310721},{"n":"provider","p":57671681}],"n":"Parse","o":"@$2","d":830225,"h":184684423953,"f":33},{"r":830225,"p":[{"n":"value","p":1310721},{"n":"style","p":54067201},{"n":"provider","p":57671681}],"n":"Parse","o":"@$3","d":830225,"h":188979391249,"f":33},{"r":262145,"p":[{"n":"value","p":1310721},{"n":"result","p":830225,"f":2}],"n":"TryParse","d":830225,"h":193274358545,"f":33},{"r":262145,"p":[{"n":"value","p":1310721},{"n":"style","p":54067201},{"n":"provider","p":57671681},{"n":"result","p":830225,"f":2}],"n":"TryParse","o":"@$1","d":830225,"h":197569325841,"f":33},{"r":830225,"p":[{"n":"value","p":$.$spc.System.ReadOnlySpan$$($.$spc.System.Char).$h},{"n":"style","p":54067201,"f":65,"v":7},{"n":"provider","p":57671681,"f":65}],"n":"Parse","o":"@$4","d":830225,"h":201864293137,"f":33},{"r":262145,"p":[{"n":"value","p":$.$spc.System.ReadOnlySpan$$($.$spc.System.Char).$h},{"n":"result","p":830225,"f":2}],"n":"TryParse","o":"@$2","d":830225,"h":206159260433,"f":33},{"r":262145,"p":[{"n":"value","p":$.$spc.System.ReadOnlySpan$$($.$spc.System.Char).$h},{"n":"style","p":54067201},{"n":"provider","p":57671681},{"n":"result","p":830225,"f":2}],"n":"TryParse","o":"@$3","d":830225,"h":210454227729,"f":33},{"r":655361,"p":[{"n":"left","p":830225},{"n":"right","p":830225}],"n":"Compare","d":830225,"h":214749195025,"f":33},{"r":830225,"p":[{"n":"value","p":830225}],"n":"Abs","d":830225,"h":219044162321,"f":33},{"r":830225,"p":[{"n":"left","p":830225},{"n":"right","p":830225}],"n":"Add","d":830225,"h":223339129617,"f":33},{"r":830225,"p":[{"n":"left","p":830225},{"n":"right","p":830225}],"n":"Subtract","d":830225,"h":227634096913,"f":33},{"r":830225,"p":[{"n":"left","p":830225},{"n":"right","p":830225}],"n":"Multiply","d":830225,"h":231929064209,"f":33},{"r":830225,"p":[{"n":"dividend","p":830225},{"n":"divisor","p":830225}],"n":"Divide","d":830225,"h":236224031505,"f":33},{"r":830225,"p":[{"n":"dividend","p":830225},{"n":"divisor","p":830225}],"n":"Remainder","d":830225,"h":240518998801,"f":33},{"r":830225,"p":[{"n":"dividend","p":830225},{"n":"divisor","p":830225},{"n":"remainder","p":830225,"f":2}],"n":"DivRem","d":830225,"h":244813966097,"f":33},{"r":830225,"p":[{"n":"value","p":830225}],"n":"Negate","d":830225,"h":249108933393,"f":33},{"r":1179649,"p":[{"n":"value","p":830225}],"n":"Log","d":830225,"h":253403900689,"f":33},{"r":1179649,"p":[{"n":"value","p":830225},{"n":"baseValue","p":1179649}],"n":"Log","o":"@$1","d":830225,"h":257698867985,"f":33},{"r":1179649,"p":[{"n":"value","p":830225}],"n":"Log10","d":830225,"h":261993835281,"f":33},{"r":830225,"p":[{"n":"left","p":830225},{"n":"right","p":830225}],"n":"GreatestCommonDivisor","d":830225,"h":266288802577,"f":33},{"r":830225,"p":[{"n":"leftBits","p":$.$spc.System.ReadOnlySpan$$($.$spc.System.UInt32).$h},{"n":"rightBits","p":$.$spc.System.ReadOnlySpan$$($.$spc.System.UInt32).$h}],"n":"GreatestCommonDivisor","o":"@$1","d":830225,"h":270583769873,"f":34},{"r":830225,"p":[{"n":"left","p":830225},{"n":"right","p":830225}],"n":"Max","d":830225,"h":274878737169,"f":33},{"r":830225,"p":[{"n":"left","p":830225},{"n":"right","p":830225}],"n":"Min","d":830225,"h":279173704465,"f":33},{"r":830225,"p":[{"n":"value","p":830225},{"n":"exponent","p":830225},{"n":"modulus","p":830225}],"n":"ModPow","d":830225,"h":283468671761,"f":33},{"r":830225,"p":[{"n":"value","p":830225},{"n":"exponent","p":655361}],"n":"Pow","d":830225,"h":287763639057,"f":33},{"r":655361,"n":"GetHashCode","d":830225,"h":292058606353,"f":32769},{"r":262145,"p":[{"n":"obj","p":131073}],"n":"Equals","d":830225,"h":296353573649,"f":32769},{"r":262145,"p":[{"n":"other","p":917505}],"n":"Equals","o":"@$2","d":830225,"h":300648540945,"f":1},{"r":262145,"p":[{"n":"other","p":983041}],"n":"Equals","o":"@$3","d":830225,"h":304943508241,"f":1,"a":[{"t":23461889,"c":8613396481,"a":[{"v":false,"t":262145}]}]},{"r":262145,"p":[{"n":"other","p":830225}],"n":"Equals","o":"@$4","d":830225,"h":309238475537,"f":1},{"r":655361,"p":[{"n":"other","p":917505}],"n":"CompareTo","d":830225,"h":313533442833,"f":1},{"r":655361,"p":[{"n":"other","p":983041}],"n":"CompareTo","o":"@$1","d":830225,"h":317828410129,"f":1,"a":[{"t":23461889,"c":8613396481,"a":[{"v":false,"t":262145}]}]},{"r":655361,"p":[{"n":"other","p":830225}],"n":"CompareTo","o":"@$2","d":830225,"h":322123377425,"f":1},{"r":655361,"p":[{"n":"obj","p":131073}],"n":"CompareTo","o":"@$3","d":830225,"h":326418344721,"f":1},{"r":0,"n":"ToByteArray","d":830225,"h":330713312017,"f":1},{"r":0,"p":[{"n":"isUnsigned","p":262145,"f":65,"v":false},{"n":"isBigEndian","p":262145,"f":65,"v":false}],"n":"ToByteArray","o":"@$1","d":830225,"h":335008279313,"f":1},{"r":262145,"p":[{"n":"destination","p":$.$spc.System.Span$$($.$spc.System.Byte).$h},{"n":"bytesWritten","p":655361,"f":2},{"n":"isUnsigned","p":262145,"f":65,"v":false},{"n":"isBigEndian","p":262145,"f":65,"v":false}],"n":"TryWriteBytes","d":830225,"h":339303246609,"f":1},{"r":262145,"p":[{"n":"destination","p":$.$spc.System.Span$$($.$spc.System.Byte).$h},{"n":"bytesWritten","p":655361,"f":2},{"n":"isUnsigned","p":262145,"f":65,"v":false},{"n":"isBigEndian","p":262145,"f":65,"v":false}],"n":"TryWriteOrCountBytes","d":830225,"h":343598213905,"f":8},{"r":655361,"p":[{"n":"isUnsigned","p":262145,"f":65,"v":false}],"n":"GetByteCount","d":830225,"h":347893181201,"f":1},{"r":0,"p":[{"n":"mode","p":895761},{"n":"destination","p":$.$spc.System.Span$$($.$spc.System.Byte).$h},{"n":"isUnsigned","p":262145},{"n":"isBigEndian","p":262145},{"n":"bytesWritten","p":655361,"f":4}],"n":"TryGetBytes","d":830225,"h":356483115793,"f":2},{"r":655361,"p":[{"n":"buffer","p":$.$spc.System.Span$$($.$spc.System.UInt32).$h}],"n":"WriteTo","d":830225,"h":360778083089,"f":2},{"r":1310721,"n":"ToString","d":830225,"h":365073050385,"f":32769},{"r":1310721,"p":[{"n":"provider","p":57671681}],"n":"ToString","o":"@$1","d":830225,"h":369368017681,"f":1},{"r":1310721,"p":[{"n":"format","p":1310721}],"n":"ToString","o":"@$2","d":830225,"h":373662984977,"f":1},{"r":1310721,"p":[{"n":"format","p":1310721},{"n":"provider","p":57671681}],"n":"ToString","o":"@$3","d":830225,"h":377957952273,"f":1},{"r":262145,"p":[{"n":"destination","p":$.$spc.System.Span$$($.$spc.System.Char).$h},{"n":"charsWritten","p":655361,"f":2},{"n":"format","p":$.$spc.System.ReadOnlySpan$$($.$spc.System.Char).$h,"f":65},{"n":"provider","p":57671681,"f":65}],"n":"TryFormat","d":830225,"h":390842854161,"f":1},{"r":830225,"p":[{"n":"leftBits","p":$.$spc.System.ReadOnlySpan$$($.$spc.System.UInt32).$h},{"n":"leftSign","p":655361},{"n":"rightBits","p":$.$spc.System.ReadOnlySpan$$($.$spc.System.UInt32).$h},{"n":"rightSign","p":655361}],"n":"Add","o":"@$1","d":830225,"h":395137821457,"f":34},{"r":830225,"p":[{"n":"leftBits","p":$.$spc.System.ReadOnlySpan$$($.$spc.System.UInt32).$h},{"n":"leftSign","p":655361},{"n":"rightBits","p":$.$spc.System.ReadOnlySpan$$($.$spc.System.UInt32).$h},{"n":"rightSign","p":655361}],"n":"Subtract","o":"@$1","d":830225,"h":403727756049,"f":34},{"r":830225,"p":[{"n":"left","p":$.$spc.System.ReadOnlySpan$$($.$spc.System.UInt32).$h},{"n":"leftSign","p":655361},{"n":"right","p":$.$spc.System.ReadOnlySpan$$($.$spc.System.UInt32).$h},{"n":"rightSign","p":655361}],"n":"Multiply","o":"@$1","d":830225,"h":609886186257,"f":34},{"r":917505,"n":"GetBitLength","d":830225,"h":751620107025,"f":1},{"r":262145,"p":[{"n":"xd","p":$.$spc.System.Span$$($.$spc.System.UInt32).$h}],"n":"GetPartsForBitManipulation","d":830225,"h":755915074321,"f":2},{"r":65537,"n":"AssertValid","d":830225,"h":760210041617,"f":2,"a":[{"t":35979265,"c":4330946561,"a":[{"v":"DEBUG","t":1310721}]}]},{"r":$.$spc.System.ValueTuple$$$($.$srn.System.Numerics.BigInteger, $.$srn.System.Numerics.BigInteger).$h,"p":[{"n":"left","p":830225},{"n":"right","p":830225}],"n":"DivRem","o":"@$1","d":830225,"h":773094943505,"f":33},{"r":830225,"p":[{"n":"value","p":830225}],"n":"LeadingZeroCount","d":830225,"h":777389910801,"f":33},{"r":830225,"p":[{"n":"value","p":830225}],"n":"PopCount","d":830225,"h":781684878097,"f":33},{"r":830225,"p":[{"n":"value","p":830225},{"n":"rotateAmount","p":655361}],"n":"RotateLeft","d":830225,"h":785979845393,"f":33},{"r":830225,"p":[{"n":"value","p":830225},{"n":"rotateAmount","p":655361}],"n":"RotateRight","d":830225,"h":790274812689,"f":33},{"r":830225,"p":[{"n":"value","p":830225}],"n":"TrailingZeroCount","d":830225,"h":794569779985,"f":33},{"r":655361,"n":"GetGenericMathByteCount","d":830225,"h":824634551057,"f":2},{"r":262145,"p":[{"n":"value","p":830225}],"n":"IsPow2","d":830225,"h":837519452945,"f":33},{"r":830225,"p":[{"n":"value","p":830225}],"n":"Log2","d":830225,"h":841814420241,"f":33},{"r":830225,"p":[{"n":"value","p":830225},{"n":"min","p":830225},{"n":"max","p":830225}],"n":"Clamp","d":830225,"h":854699322129,"f":33},{"r":830225,"p":[{"n":"value","p":830225},{"n":"sign","p":830225}],"n":"CopySign","d":830225,"h":858994289425,"f":33},{"r":830225,"p":[{"n":"value","p":(TOther) => TOther.$h}],"g":["TOther"],"n":"CreateChecked","d":830225,"h":884764093201,"f":131105},{"r":830225,"p":[{"n":"value","p":(TOther) => TOther.$h}],"g":["TOther"],"n":"CreateSaturating","d":830225,"h":889059060497,"f":131105},{"r":830225,"p":[{"n":"value","p":(TOther) => TOther.$h}],"g":["TOther"],"n":"CreateTruncating","d":830225,"h":893354027793,"f":131105},{"r":262145,"p":[{"n":"value","p":830225}],"n":"IsEvenInteger","d":830225,"h":906238929681,"f":33},{"r":262145,"p":[{"n":"value","p":830225}],"n":"IsNegative","d":830225,"h":932008733457,"f":33},{"r":262145,"p":[{"n":"value","p":830225}],"n":"IsOddInteger","d":830225,"h":944893635345,"f":33},{"r":262145,"p":[{"n":"value","p":830225}],"n":"IsPositive","d":830225,"h":949188602641,"f":33},{"r":830225,"p":[{"n":"x","p":830225},{"n":"y","p":830225}],"n":"MaxMagnitude","d":830225,"h":970663439121,"f":33},{"r":830225,"p":[{"n":"x","p":830225},{"n":"y","p":830225}],"n":"MinMagnitude","d":830225,"h":979253373713,"f":33},{"r":262145,"p":[{"n":"value","p":(TOther) => TOther.$h},{"n":"result","p":830225,"f":2}],"g":["TOther"],"n":"TryConvertFromChecked","d":830225,"h":996433242897,"f":131106},{"r":262145,"p":[{"n":"value","p":(TOther) => TOther.$h},{"n":"result","p":830225,"f":2}],"g":["TOther"],"n":"TryConvertFromSaturating","d":830225,"h":1005023177489,"f":131106},{"r":262145,"p":[{"n":"value","p":(TOther) => TOther.$h},{"n":"result","p":830225,"f":2}],"g":["TOther"],"n":"TryConvertFromTruncating","d":830225,"h":1013613112081,"f":131106},{"r":262145,"p":[{"n":"s","p":1310721},{"n":"provider","p":57671681},{"n":"result","p":830225,"f":2}],"n":"TryParse","o":"@$4","d":830225,"h":1030792981265,"f":33},{"r":830225,"p":[{"n":"s","p":$.$spc.System.ReadOnlySpan$$($.$spc.System.Char).$h},{"n":"provider","p":57671681}],"n":"Parse","o":"@$5","d":830225,"h":1047972850449,"f":33},{"r":262145,"p":[{"n":"s","p":$.$spc.System.ReadOnlySpan$$($.$spc.System.Char).$h},{"n":"provider","p":57671681},{"n":"result","p":830225,"f":2}],"n":"TryParse","o":"@$5","d":830225,"h":1052267817745,"f":33}],"l":[{"t":720897,"n":"kuMaskHighBit","d":830225,"h":4295797521,"f":40},{"t":655361,"n":"kcbitUint","d":830225,"h":8590764817,"f":40},{"t":655361,"n":"kcbitUlong","d":830225,"h":12885732113,"f":40},{"t":655361,"n":"DecimalScaleFactorMask","d":830225,"h":17180699409,"f":40},{"t":655361,"n":"_sign","d":830225,"h":30065601297,"f":8},{"t":0,"n":"_bits","d":830225,"h":34360568593,"f":8},{"t":830225,"n":"s_bnMinInt","d":830225,"h":38655535889,"f":34},{"t":830225,"n":"s_bnOneInt","d":830225,"h":42950503185,"f":34},{"t":830225,"n":"s_bnZeroInt","d":830225,"h":47245470481,"f":34},{"t":830225,"n":"s_bnMinusOneInt","d":830225,"h":51540437777,"f":34}],"c":[{"p":[{"n":"value","p":655361}],"n":".ctor","o":"$ctor$2","d":830225,"h":55835405073,"f":1},{"p":[{"n":"value","p":720897}],"n":".ctor","o":"$ctor$3","d":830225,"h":60130372369,"f":1,"a":[{"t":23461889,"c":8613396481,"a":[{"v":false,"t":262145}]}]},{"p":[{"n":"value","p":917505}],"n":".ctor","o":"$ctor$4","d":830225,"h":64425339665,"f":1},{"p":[{"n":"value","p":983041}],"n":".ctor","o":"$ctor$5","d":830225,"h":68720306961,"f":1,"a":[{"t":23461889,"c":8613396481,"a":[{"v":false,"t":262145}]}]},{"p":[{"n":"value","p":1114113}],"n":".ctor","o":"$ctor$6","d":830225,"h":73015274257,"f":1},{"p":[{"n":"value","p":1179649}],"n":".ctor","o":"$ctor$7","d":830225,"h":77310241553,"f":1},{"p":[{"n":"value","p":35061761}],"n":".ctor","o":"$ctor$8","d":830225,"h":81605208849,"f":1},{"p":[{"n":"value","p":0}],"n":".ctor","o":"$ctor$9","d":830225,"h":85900176145,"f":1,"a":[{"t":23461889,"c":8613396481,"a":[{"v":false,"t":262145}]}]},{"p":[{"n":"value","p":$.$spc.System.ReadOnlySpan$$($.$spc.System.Byte).$h},{"n":"isUnsigned","p":262145,"f":65,"v":false},{"n":"isBigEndian","p":262145,"f":65,"v":false}],"n":".ctor","o":"$ctor$10","d":830225,"h":90195143441,"f":1},{"p":[{"n":"n","p":655361},{"n":"rgu","p":0}],"n":".ctor","o":"$ctor$11","d":830225,"h":94490110737,"f":8},{"p":[{"n":"value","p":$.$spc.System.ReadOnlySpan$$($.$spc.System.UInt32).$h},{"n":"negative","p":262145}],"n":".ctor","o":"$ctor$12","d":830225,"h":98785078033,"f":8},{"p":[{"n":"value","p":$.$spc.System.Span$$($.$spc.System.UInt32).$h}],"n":".ctor","o":"$ctor$13","d":830225,"h":103080045329,"f":2},{"n":".ctor","o":"$ctor$14","d":830225,"h":1056562785041,"f":1}],"i":[$.$spc.System.Numerics.IBinaryInteger$$($.$srn.System.Numerics.BigInteger).$h,$.$spc.System.Numerics.IBinaryNumber$$($.$srn.System.Numerics.BigInteger).$h,$.$spc.System.Numerics.IBitwiseOperators$$$$($.$srn.System.Numerics.BigInteger, $.$srn.System.Numerics.BigInteger, $.$srn.System.Numerics.BigInteger).$h,$.$spc.System.Numerics.INumber$$($.$srn.System.Numerics.BigInteger).$h,57278465,$.$spc.System.IComparable$$($.$srn.System.Numerics.BigInteger).$h,$.$spc.System.Numerics.IComparisonOperators$$$$($.$srn.System.Numerics.BigInteger, $.$srn.System.Numerics.BigInteger, $.$spc.System.Boolean).$h,$.$spc.System.Numerics.IModulusOperators$$$$($.$srn.System.Numerics.BigInteger, $.$srn.System.Numerics.BigInteger, $.$srn.System.Numerics.BigInteger).$h,$.$spc.System.Numerics.IShiftOperators$$$$($.$srn.System.Numerics.BigInteger, $.$spc.System.Int32, $.$srn.System.Numerics.BigInteger).$h,$.$spc.System.Numerics.ISignedNumber$$($.$srn.System.Numerics.BigInteger).$h,$.$spc.System.Numerics.INumberBase$$($.$srn.System.Numerics.BigInteger).$h,$.$spc.System.Numerics.IAdditionOperators$$$$($.$srn.System.Numerics.BigInteger, $.$srn.System.Numerics.BigInteger, $.$srn.System.Numerics.BigInteger).$h,$.$spc.System.Numerics.IAdditiveIdentity$$$($.$srn.System.Numerics.BigInteger, $.$srn.System.Numerics.BigInteger).$h,$.$spc.System.Numerics.IDecrementOperators$$($.$srn.System.Numerics.BigInteger).$h,$.$spc.System.Numerics.IDivisionOperators$$$$($.$srn.System.Numerics.BigInteger, $.$srn.System.Numerics.BigInteger, $.$srn.System.Numerics.BigInteger).$h,$.$spc.System.IEquatable$$($.$srn.System.Numerics.BigInteger).$h,$.$spc.System.Numerics.IEqualityOperators$$$$($.$srn.System.Numerics.BigInteger, $.$srn.System.Numerics.BigInteger, $.$spc.System.Boolean).$h,$.$spc.System.Numerics.IIncrementOperators$$($.$srn.System.Numerics.BigInteger).$h,$.$spc.System.Numerics.IMultiplicativeIdentity$$$($.$srn.System.Numerics.BigInteger, $.$srn.System.Numerics.BigInteger).$h,$.$spc.System.Numerics.IMultiplyOperators$$$$($.$srn.System.Numerics.BigInteger, $.$srn.System.Numerics.BigInteger, $.$srn.System.Numerics.BigInteger).$h,63832065,57737217,$.$spc.System.ISpanParsable$$($.$srn.System.Numerics.BigInteger).$h,$.$spc.System.IParsable$$($.$srn.System.Numerics.BigInteger).$h,$.$spc.System.Numerics.ISubtractionOperators$$$$($.$srn.System.Numerics.BigInteger, $.$srn.System.Numerics.BigInteger, $.$srn.System.Numerics.BigInteger).$h,$.$spc.System.Numerics.IUnaryPlusOperators$$$($.$srn.System.Numerics.BigInteger, $.$srn.System.Numerics.BigInteger).$h,$.$spc.System.Numerics.IUnaryNegationOperators$$$($.$srn.System.Numerics.BigInteger, $.$srn.System.Numerics.BigInteger).$h,64159745,$.$spc.System.IUtf8SpanParsable$$($.$srn.System.Numerics.BigInteger).$h],"j":[895761],"h":830225,"a":[{"t":118226945,"c":4413194241},{"t":96272385,"c":4391239681,"a":[{"v":"System.Numerics, Version=4.0.0.0, PublicKeyToken=b77a5c561934e089","t":1310721}]},{"t":37617665,"c":8627552257,"a":[{"v":"{DebuggerDisplay,nq}","t":1310721}]}]}; }
            static get $b() { return $.$spc.System.ValueType; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.Numerics.IBinaryInteger$$($.$srn.System.Numerics.BigInteger), $.$spc.System.Numerics.IBinaryNumber$$($.$srn.System.Numerics.BigInteger), $.$spc.System.Numerics.IBitwiseOperators$$$$($.$srn.System.Numerics.BigInteger, $.$srn.System.Numerics.BigInteger, $.$srn.System.Numerics.BigInteger), $.$spc.System.Numerics.INumber$$($.$srn.System.Numerics.BigInteger), $.$spc.System.IComparable, $.$spc.System.IComparable$$($.$srn.System.Numerics.BigInteger), $.$spc.System.Numerics.IComparisonOperators$$$$($.$srn.System.Numerics.BigInteger, $.$srn.System.Numerics.BigInteger, $.$spc.System.Boolean), $.$spc.System.Numerics.IModulusOperators$$$$($.$srn.System.Numerics.BigInteger, $.$srn.System.Numerics.BigInteger, $.$srn.System.Numerics.BigInteger), $.$spc.System.Numerics.IShiftOperators$$$$($.$srn.System.Numerics.BigInteger, $.$spc.System.Int32, $.$srn.System.Numerics.BigInteger), $.$spc.System.Numerics.ISignedNumber$$($.$srn.System.Numerics.BigInteger), $.$spc.System.Numerics.INumberBase$$($.$srn.System.Numerics.BigInteger), $.$spc.System.Numerics.IAdditionOperators$$$$($.$srn.System.Numerics.BigInteger, $.$srn.System.Numerics.BigInteger, $.$srn.System.Numerics.BigInteger), $.$spc.System.Numerics.IAdditiveIdentity$$$($.$srn.System.Numerics.BigInteger, $.$srn.System.Numerics.BigInteger), $.$spc.System.Numerics.IDecrementOperators$$($.$srn.System.Numerics.BigInteger), $.$spc.System.Numerics.IDivisionOperators$$$$($.$srn.System.Numerics.BigInteger, $.$srn.System.Numerics.BigInteger, $.$srn.System.Numerics.BigInteger), $.$spc.System.IEquatable$$($.$srn.System.Numerics.BigInteger), $.$spc.System.Numerics.IEqualityOperators$$$$($.$srn.System.Numerics.BigInteger, $.$srn.System.Numerics.BigInteger, $.$spc.System.Boolean), $.$spc.System.Numerics.IIncrementOperators$$($.$srn.System.Numerics.BigInteger), $.$spc.System.Numerics.IMultiplicativeIdentity$$$($.$srn.System.Numerics.BigInteger, $.$srn.System.Numerics.BigInteger), $.$spc.System.Numerics.IMultiplyOperators$$$$($.$srn.System.Numerics.BigInteger, $.$srn.System.Numerics.BigInteger, $.$srn.System.Numerics.BigInteger), $.$spc.System.ISpanFormattable, $.$spc.System.IFormattable, $.$spc.System.ISpanParsable$$($.$srn.System.Numerics.BigInteger), $.$spc.System.IParsable$$($.$srn.System.Numerics.BigInteger), $.$spc.System.Numerics.ISubtractionOperators$$$$($.$srn.System.Numerics.BigInteger, $.$srn.System.Numerics.BigInteger, $.$srn.System.Numerics.BigInteger), $.$spc.System.Numerics.IUnaryPlusOperators$$$($.$srn.System.Numerics.BigInteger, $.$srn.System.Numerics.BigInteger), $.$spc.System.Numerics.IUnaryNegationOperators$$$($.$srn.System.Numerics.BigInteger, $.$srn.System.Numerics.BigInteger), $.$spc.System.IUtf8SpanFormattable, $.$spc.System.IUtf8SpanParsable$$($.$srn.System.Numerics.BigInteger) ]; }
            static get $fullName() { return `System.Numerics.BigInteger`; }
        });
	});
})(window, window.NetJs.$boot(), ...window.NetJs.$require("NetJs.System.Private.CoreLib", "NetJs.System.Memory", "NetJs.System.Private.Uri", "NetJs.System.Runtime", "NetJs.System.Runtime.Intrinsics"))