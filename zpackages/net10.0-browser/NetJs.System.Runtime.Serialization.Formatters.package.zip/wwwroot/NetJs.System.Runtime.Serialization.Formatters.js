
//--TRIMMABLE-BOUNDARY-START(27)
(async function () {
(function ($global, $, $$, $sc, $sdt, $st, $scc, $sm, $spu, $sr, $scn) {
    "use strict";
    let _;
    let $AaoiKd;
    
    
    
	$.$asm(
    "NetJs.System.Runtime.Serialization.Formatters", 
    {
  "h": 27,
  "f": "System.Runtime.Serialization.Formatters",
  "v": "1.0.35.0",
  "a": [
    {
      "t": 134545409,
      "c": 8724480001,
      "a": [
        {
          "v": 100139009,
          "t": 188547073
        }
      ]
    },
    {
      "t": 134545409,
      "c": 8724480001,
      "a": [
        {
          "v": 163119105,
          "t": 188547073
        }
      ]
    },
    {
      "t": 134545409,
      "c": 8724480001,
      "a": [
        {
          "v": 158007297,
          "t": 188547073
        }
      ]
    },
    {
      "t": 134545409,
      "c": 8724480001,
      "a": [
        {
          "v": 158072833,
          "t": 188547073
        }
      ]
    },
    {
      "t": 134545409,
      "c": 8724480001,
      "a": [
        {
          "v": 158269441,
          "t": 188547073
        }
      ]
    },
    {
      "t": 134545409,
      "c": 8724480001,
      "a": [
        {
          "v": 158728193,
          "t": 188547073
        }
      ]
    },
    {
      "t": 134545409,
      "c": 8724480001,
      "a": [
        {
          "v": 158859265,
          "t": 188547073
        }
      ]
    },
    {
      "t": 134545409,
      "c": 8724480001,
      "a": [
        {
          "v": 158924801,
          "t": 188547073
        }
      ]
    },
    {
      "t": 160038913,
      "c": 13044940801,
      "a": [
        {
          "v": ".NETCoreApp,Version=v10.0",
          "t": 1310721
        }
      ],
      "n": [
        {
          "n": "FrameworkDisplayName",
          "v": ".NET 10.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107151361,
      "c": 8697085953,
      "a": [
        {
          "v": "SIT",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107216897,
      "c": 8697151489,
      "a": [
        {
          "v": "Debug",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107675649,
      "c": 8697610241,
      "a": [
        {
          "v": "1.0.35.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107806721,
      "c": 8697741313,
      "a": [
        {
          "v": "1.0.35\u002B96771abe2820045936210554b19d0578b9bc2b1c",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108658689,
      "c": 8698593281,
      "a": [
        {
          "v": "NetJs.System.Runtime.Serialization.Formatters",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108789761,
      "c": 8698724353,
      "a": [
        {
          "v": "NetJs.System.Runtime.Serialization.Formatters",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108920833,
      "c": 8698855425,
      "a": [
        {
          "v": "1.0.35.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 160104449,
      "c": 4455071745,
      "a": [
        {
          "v": "browser1.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 159842305,
      "c": 4454809601,
      "a": [
        {
          "v": "browser1.0",
          "t": 1310721
        }
      ]
    }
  ],
  "m": []
},
    function($asm)
	{
        
        
        //--TRIMMABLE-BOUNDARY-START(1048603)
        $asm.$cls(`$srsf.SRS.ISurrogateSelector`, ($self) => class ISurrogateSelector
        {
            static $h = 1048603;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4296015899),
    {
      "r": 65537,
      "p": [
        {
          "n": "selector",
          "p": 1048603
        }
      ],
      "n": "ChainSelector",
      "o": "SRS$ISurrogateSelector$ChainSelector",
      "d": 1048603,
      "h": 4296015899,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(4296015899),
//--TRIMMABLE-BOUNDARY-START(12885950491),
    {
      "r": 983067,
      "p": [
        {
          "n": "type",
          "p": 188547073
        },
        {
          "n": "context",
          "p": 158990337
        },
        {
          "n": "selector",
          "p": 1048603,
          "f": 2
        }
      ],
      "n": "GetSurrogate",
      "o": "SRS$ISurrogateSelector$GetSurrogate",
      "d": 1048603,
      "h": 12885950491,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(12885950491),
//--TRIMMABLE-BOUNDARY-START(8590983195),
    {
      "r": 1048603,
      "n": "GetNextSelector",
      "o": "SRS$ISurrogateSelector$GetNextSelector",
      "d": 1048603,
      "h": 8590983195,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(8590983195)
  ],
  "h": 1048603,
  "a": [
    {
      "t": 104464385,
      "c": 30169235457,
      "a": [
        {
          "v": "Formatter-based serialization is obsolete and should not be used.",
          "t": 1310721
        }
      ],
      "n": [
        {
          "n": "DiagnosticId",
          "v": "SYSLIB0050",
          "t": 1310721
        },
        {
          "n": "UrlFormat",
          "v": "https://aka.ms/dotnet-warnings/{0}",
          "t": 1310721
        }
      ]
    }
  ]
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `System.Runtime.Serialization.ISurrogateSelector`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `System${separator}Runtime${separator}Serialization${separator}ISurrogateSelector`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1048603)
        
        

        //--TRIMMABLE-BOUNDARY-START(983067)
        $asm.$cls(`$srsf.SRS.ISerializationSurrogate`, ($self) => class ISerializationSurrogate
        {
            static $h = 983067;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4295950363),
    {
      "r": 65537,
      "p": [
        {
          "n": "obj",
          "p": 131073
        },
        {
          "n": "info",
          "p": 158859265
        },
        {
          "n": "context",
          "p": 158990337
        }
      ],
      "n": "GetObjectData",
      "o": "SRS$ISerializationSurrogate$GetObjectData",
      "d": 983067,
      "h": 4295950363,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(4295950363),
//--TRIMMABLE-BOUNDARY-START(8590917659),
    {
      "r": 131073,
      "p": [
        {
          "n": "obj",
          "p": 131073
        },
        {
          "n": "info",
          "p": 158859265
        },
        {
          "n": "context",
          "p": 158990337
        },
        {
          "n": "selector",
          "p": 1048603
        }
      ],
      "n": "SetObjectData",
      "o": "SRS$ISerializationSurrogate$SetObjectData",
      "d": 983067,
      "h": 8590917659,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(8590917659)
  ],
  "h": 983067,
  "a": [
    {
      "t": 104464385,
      "c": 30169235457,
      "a": [
        {
          "v": "Formatter-based serialization is obsolete and should not be used.",
          "t": 1310721
        }
      ],
      "n": [
        {
          "n": "DiagnosticId",
          "v": "SYSLIB0050",
          "t": 1310721
        },
        {
          "n": "UrlFormat",
          "v": "https://aka.ms/dotnet-warnings/{0}",
          "t": 1310721
        }
      ]
    }
  ]
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `System.Runtime.Serialization.ISerializationSurrogate`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `System${separator}Runtime${separator}Serialization${separator}ISerializationSurrogate`; }
        });
        //--TRIMMABLE-BOUNDARY-END(983067)
        
        

        //--TRIMMABLE-BOUNDARY-START(917531)
        $asm.$cls(`$srsf.SRS.IFormatter`, ($self) => class IFormatter
        {
            //--TRIMMABLE-BOUNDARY-START(42950590491)
            /*string*/ static System$Runtime$Serialization$IFormatter$RequiresDynamicCodeMessage = null;
            //--TRIMMABLE-BOUNDARY-END(42950590491)
            
            //--TRIMMABLE-BOUNDARY-START(47245557787)
            /*string*/ static System$Runtime$Serialization$IFormatter$RequiresUnreferencedCodeMessage = null;
            //--TRIMMABLE-BOUNDARY-END(47245557787)
            
            //--TRIMMABLE-BOUNDARY-START(SINIT)
            //Static Initializer
            static $sinit()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(42950590491)
                    this.System$Runtime$Serialization$IFormatter$RequiresDynamicCodeMessage = "BinaryFormatter serialization uses dynamic code generation, the type of objects being processed cannot be statically discovered.";
                    //--TRIMMABLE-BOUNDARY-END(42950590491)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(47245557787)
                    this.System$Runtime$Serialization$IFormatter$RequiresUnreferencedCodeMessage = "BinaryFormatter serialization is not trim compatible because the type of objects being processed cannot be statically discovered.";
                    //--TRIMMABLE-BOUNDARY-END(47245557787)
                    
                }
            }
            //--TRIMMABLE-BOUNDARY-END(SINIT)
            
            static $h = 917531;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(81605296155),
    {
      "p": 1048603,
      "g": {
        "r": 0,
        "d": 0,
        "h": 38655623195,
        "f": 50331905
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 77310328859,
        "f": 83886337
      },
      "n": "SurrogateSelector",
      "o": "SRS$IFormatter$SurrogateSelector",
      "d": 917531,
      "h": 81605296155,
      "f": 2097409
    },
//--TRIMMABLE-BOUNDARY-END(81605296155),
//--TRIMMABLE-BOUNDARY-START(4295884827),
    {
      "p": 1572891,
      "g": {
        "r": 0,
        "d": 0,
        "h": 21475754011,
        "f": 50331905
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 60130459675,
        "f": 83886337
      },
      "n": "Binder",
      "o": "SRS$IFormatter$Binder",
      "d": 917531,
      "h": 4295884827,
      "f": 2097409
    },
//--TRIMMABLE-BOUNDARY-END(4295884827),
//--TRIMMABLE-BOUNDARY-START(8590852123),
    {
      "p": 158990337,
      "g": {
        "r": 0,
        "d": 0,
        "h": 30065688603,
        "f": 50331905
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 68720394267,
        "f": 83886337
      },
      "n": "Context",
      "o": "SRS$IFormatter$Context",
      "d": 917531,
      "h": 8590852123,
      "f": 2097409
    },
//--TRIMMABLE-BOUNDARY-END(8590852123)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(12885819419),
    {
      "r": 131073,
      "p": [
        {
          "n": "serializationStream",
          "p": 95748097
        }
      ],
      "n": "Deserialize",
      "o": "SRS$IFormatter$Deserialize",
      "d": 917531,
      "h": 12885819419,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(12885819419),
//--TRIMMABLE-BOUNDARY-START(51540525083),
    {
      "r": 65537,
      "p": [
        {
          "n": "serializationStream",
          "p": 95748097
        },
        {
          "n": "graph",
          "p": 131073
        }
      ],
      "n": "Serialize",
      "o": "SRS$IFormatter$Serialize",
      "d": 917531,
      "h": 51540525083,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(51540525083)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(42950590491),
    {
      "t": 1310721,
      "n": "RequiresDynamicCodeMessage",
      "o": "System$Runtime$Serialization$IFormatter$RequiresDynamicCodeMessage",
      "d": 917531,
      "h": 42950590491,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(42950590491),
//--TRIMMABLE-BOUNDARY-START(47245557787),
    {
      "t": 1310721,
      "n": "RequiresUnreferencedCodeMessage",
      "o": "System$Runtime$Serialization$IFormatter$RequiresUnreferencedCodeMessage",
      "d": 917531,
      "h": 47245557787,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(47245557787)
  ],
  "h": 917531,
  "a": [
    {
      "t": 104464385,
      "c": 30169235457,
      "a": [
        {
          "v": "BinaryFormatter serialization is obsolete and should not be used. See https://aka.ms/binaryformatter for more information.",
          "t": 1310721
        }
      ],
      "n": [
        {
          "n": "DiagnosticId",
          "v": "SYSLIB0011",
          "t": 1310721
        },
        {
          "n": "UrlFormat",
          "v": "https://aka.ms/dotnet-warnings/{0}",
          "t": 1310721
        }
      ]
    }
  ]
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `System.Runtime.Serialization.IFormatter`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `System${separator}Runtime${separator}Serialization${separator}IFormatter`; }
        });
        //--TRIMMABLE-BOUNDARY-END(917531)
        
        

        //--TRIMMABLE-BOUNDARY-START(720923)
        $asm.$cls(`$srsf.SRSF.IFieldInfo`, ($self) => class IFieldInfo
        {
            static $h = 720923;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(4295688219),
    {
      "p": $.$typeArray($.$$.S.String).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 17180590107,
        "f": 50331905
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 34360459291,
        "f": 83886337
      },
      "n": "FieldNames",
      "o": "SRSF$IFieldInfo$FieldNames",
      "d": 720923,
      "h": 4295688219,
      "f": 2097409
    },
//--TRIMMABLE-BOUNDARY-END(4295688219),
//--TRIMMABLE-BOUNDARY-START(8590655515),
    {
      "p": $.$typeArray($.$$.S.Type).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 25770524699,
        "f": 50331905
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 42950393883,
        "f": 83886337
      },
      "n": "FieldTypes",
      "o": "SRSF$IFieldInfo$FieldTypes",
      "d": 720923,
      "h": 8590655515,
      "f": 2097409
    },
//--TRIMMABLE-BOUNDARY-END(8590655515)
  ],
  "h": 720923,
  "a": [
    {
      "t": 104464385,
      "c": 30169235457,
      "a": [
        {
          "v": "Formatter-based serialization is obsolete and should not be used.",
          "t": 1310721
        }
      ],
      "n": [
        {
          "n": "DiagnosticId",
          "v": "SYSLIB0050",
          "t": 1310721
        },
        {
          "n": "UrlFormat",
          "v": "https://aka.ms/dotnet-warnings/{0}",
          "t": 1310721
        }
      ]
    }
  ]
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `System.Runtime.Serialization.Formatters.IFieldInfo`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `System${separator}Runtime${separator}Serialization${separator}Formatters${separator}IFieldInfo`; }
        });
        //--TRIMMABLE-BOUNDARY-END(720923)
        
        

        //--TRIMMABLE-BOUNDARY-START(1572891)
        $asm.$cls(`$srsf.SRS.SerializationBinder`, ($self) => class SerializationBinder extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8591507483)
            /*void */ BindToName(/*Type*/ serializedType, /*out string?*/ assemblyName, /*out string?*/ typeName)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591507483);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                assemblyName.$v = null;
                typeName.$v = null;
            }
            //--TRIMMABLE-BOUNDARY-END(8591507483)
            
            //--TRIMMABLE-BOUNDARY-START(4296540187)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296540187);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296540187)
            
            //--TRIMMABLE-BOUNDARY-START(4296540187)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4296540187)
            
            static $h = 1572891;
            static $f = 0b110001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8591507483),
    {
      "r": 65537,
      "p": [
        {
          "n": "serializedType",
          "p": 188547073
        },
        {
          "n": "assemblyName",
          "p": 1310721,
          "f": 2
        },
        {
          "n": "typeName",
          "p": 1310721,
          "f": 2
        }
      ],
      "n": "BindToName",
      "d": 1572891,
      "h": 8591507483,
      "f": 16777345
    },
//--TRIMMABLE-BOUNDARY-END(8591507483),
//--TRIMMABLE-BOUNDARY-START(12886474779),
    {
      "r": 188547073,
      "p": [
        {
          "n": "assemblyName",
          "p": 1310721
        },
        {
          "n": "typeName",
          "p": 1310721
        }
      ],
      "n": "BindToType",
      "d": 1572891,
      "h": 12886474779,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(12886474779)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296540187),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 1572891,
      "h": 4296540187,
      "f": 16777220
    },
//--TRIMMABLE-BOUNDARY-END(4296540187)
  ],
  "h": 1572891
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `System.Runtime.Serialization.SerializationBinder`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `System${separator}Runtime${separator}Serialization${separator}SerializationBinder`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1572891)
        
        

        //--TRIMMABLE-BOUNDARY-START(393243)
        $asm.$cls(`$srsf.SRS.Formatter`, ($self) => class Formatter extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(51540000795)
            /*ObjectIDGenerator*/ m_idGenerator = null;
            //--TRIMMABLE-BOUNDARY-END(51540000795)
            
            //--TRIMMABLE-BOUNDARY-START(55834968091)
            /*Queue*/ m_objectQueue = null;
            //--TRIMMABLE-BOUNDARY-END(55834968091)
            
            //--TRIMMABLE-BOUNDARY-START(4295360539)
            $ctor$1()
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4295360539);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this.m_objectQueue = new $.$scn.SC.Queue().$ctor$1();
                    this.m_idGenerator = new $.$srsf.SRS.ObjectIDGenerator().$ctor$1();
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295360539)
            
            //--TRIMMABLE-BOUNDARY-START(47245033499)
            /*object? */ GetNext(/*out long*/ objID)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(47245033499);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (this.m_objectQueue.Count === 0)
                {
                    objID.$v = 0n;
                    return null;
                }
                /*object*/ let obj = this.m_objectQueue.Dequeue();
                /*bool*/ let isNew;
                objID.$v = this.m_idGenerator.HasId(obj, $.$ref(() => isNew, ($v) => isNew = $v, $.$$.S.Boolean));
                if (isNew)
                {
                    throw new $.$$.SRS.SerializationException().$ctor$12($.$srsf.S.SR.Serialization_NoID);
                }
                return obj;
            }
            //--TRIMMABLE-BOUNDARY-END(47245033499)
            
            //--TRIMMABLE-BOUNDARY-START(60129935387)
            /*long */ Schedule(/*object?*/ obj)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(60129935387);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (obj === null)
                {
                    return 0n;
                }
                /*bool*/ let isNew;
                /*long*/ let id = this.m_idGenerator.GetId(obj, $.$ref(() => isNew, ($v) => isNew = $v, $.$$.S.Boolean));
                if (isNew)
                {
                    this.m_objectQueue.Enqueue(obj);
                }
                return id;
            }
            //--TRIMMABLE-BOUNDARY-END(60129935387)
            
            //--TRIMMABLE-BOUNDARY-START(141734314011)
            /*void */ WriteMember(/*string*/ memberName, /*object?*/ data)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(141734314011);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (data === null)
                {
                    this.WriteObjectRef(data, memberName, $.$$.S.Object.$type);
                    return;
                }
                /*Type*/ let varType = $.$$.S.Object.GetType.call(data);
                if (varType === $.$$.S.Boolean.$type)
                {
                    this.WriteBoolean($.$$.S.Convert.ToBoolean$9(data, $.$$.SG.CultureInfo.InvariantCulture), memberName);
                }
                else if (varType === $.$$.S.Char.$type)
                {
                    this.WriteChar($.$$.S.Convert.ToChar$9(data, $.$$.SG.CultureInfo.InvariantCulture), memberName);
                }
                else if (varType === $.$$.S.SByte.$type)
                {
                    this.WriteSByte($.$$.S.Convert.ToSByte$9(data, $.$$.SG.CultureInfo.InvariantCulture), memberName);
                }
                else if (varType === $.$$.S.Byte.$type)
                {
                    this.WriteByte($.$$.S.Convert.ToByte$9(data, $.$$.SG.CultureInfo.InvariantCulture), memberName);
                }
                else if (varType === $.$$.S.Int16.$type)
                {
                    this.WriteInt16($.$$.S.Convert.ToInt16$9(data, $.$$.SG.CultureInfo.InvariantCulture), memberName);
                }
                else if (varType === $.$$.S.Int32.$type)
                {
                    this.WriteInt32($.$$.S.Convert.ToInt32$9(data, $.$$.SG.CultureInfo.InvariantCulture), memberName);
                }
                else if (varType === $.$$.S.Int64.$type)
                {
                    this.WriteInt64($.$$.S.Convert.ToInt64$9(data, $.$$.SG.CultureInfo.InvariantCulture), memberName);
                }
                else if (varType === $.$$.S.Single.$type)
                {
                    this.WriteSingle($.$$.S.Convert.ToSingle$9(data, $.$$.SG.CultureInfo.InvariantCulture), memberName);
                }
                else if (varType === $.$$.S.Double.$type)
                {
                    this.WriteDouble($.$$.S.Convert.ToDouble$9(data, $.$$.SG.CultureInfo.InvariantCulture), memberName);
                }
                else if (varType === $.$$.S.DateTime.$type)
                {
                    this.WriteDateTime($.$$.S.Convert.ToDateTime$9(data, $.$$.SG.CultureInfo.InvariantCulture), memberName);
                }
                else if (varType === $.$$.S.Decimal.$type)
                {
                    this.WriteDecimal($.$$.S.Convert.ToDecimal$9(data, $.$$.SG.CultureInfo.InvariantCulture), memberName);
                }
                else if (varType === $.$$.S.UInt16.$type)
                {
                    this.WriteUInt16($.$$.S.Convert.ToUInt16$9(data, $.$$.SG.CultureInfo.InvariantCulture), memberName);
                }
                else if (varType === $.$$.S.UInt32.$type)
                {
                    this.WriteUInt32($.$$.S.Convert.ToUInt32$9(data, $.$$.SG.CultureInfo.InvariantCulture), memberName);
                }
                else if (varType === $.$$.S.UInt64.$type)
                {
                    this.WriteUInt64($.$$.S.Convert.ToUInt64$9(data, $.$$.SG.CultureInfo.InvariantCulture), memberName);
                }
                else if (varType.IsArray)
                {
                    this.WriteArray(data, memberName, varType);
                }
                else if (varType.IsValueType)
                {
                    this.WriteValueType(data, memberName, varType);
                }
                else 
                {
                    this.WriteObjectRef(data, memberName, varType);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(141734314011)
            
            //--TRIMMABLE-BOUNDARY-START(12885819419)
            //Generated interface implemetation for System.Runtime.Serialization.IFormatter.Deserialize(System.IO.Stream)
            SRS$IFormatter$Deserialize()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12885819419);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Deserialize(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(12885819419)
            
            //--TRIMMABLE-BOUNDARY-START(51540525083)
            //Generated interface implemetation for System.Runtime.Serialization.IFormatter.Serialize(System.IO.Stream, object)
            SRS$IFormatter$Serialize()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(51540525083);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Serialize(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(51540525083)
            
            //--TRIMMABLE-BOUNDARY-START(38655623195)
            //Generated interface implemetation for System.Runtime.Serialization.IFormatter.SurrogateSelector.get
            get SRS$IFormatter$SurrogateSelector()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(81605296155);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.SurrogateSelector;
            }
            //--TRIMMABLE-BOUNDARY-END(38655623195)
            
            //--TRIMMABLE-BOUNDARY-START(77310328859)
            //Generated interface implemetation for System.Runtime.Serialization.IFormatter.SurrogateSelector.set
            set SRS$IFormatter$SurrogateSelector(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(81605296155);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.SurrogateSelector = value;
            }
            //--TRIMMABLE-BOUNDARY-END(77310328859)
            
            //--TRIMMABLE-BOUNDARY-START(21475754011)
            //Generated interface implemetation for System.Runtime.Serialization.IFormatter.Binder.get
            get SRS$IFormatter$Binder()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295884827);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Binder;
            }
            //--TRIMMABLE-BOUNDARY-END(21475754011)
            
            //--TRIMMABLE-BOUNDARY-START(60130459675)
            //Generated interface implemetation for System.Runtime.Serialization.IFormatter.Binder.set
            set SRS$IFormatter$Binder(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295884827);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.Binder = value;
            }
            //--TRIMMABLE-BOUNDARY-END(60130459675)
            
            //--TRIMMABLE-BOUNDARY-START(30065688603)
            //Generated interface implemetation for System.Runtime.Serialization.IFormatter.Context.get
            get SRS$IFormatter$Context()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590852123);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Context;
            }
            //--TRIMMABLE-BOUNDARY-END(30065688603)
            
            //--TRIMMABLE-BOUNDARY-START(68720394267)
            //Generated interface implemetation for System.Runtime.Serialization.IFormatter.Context.set
            set SRS$IFormatter$Context(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590852123);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.Context = value;
            }
            //--TRIMMABLE-BOUNDARY-END(68720394267)
            
            //--TRIMMABLE-BOUNDARY-START(4295360539)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4295360539)
            
            static $h = 393243;
            static $f = 0b110001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(94489673755),
    {
      "p": 1048603,
      "g": {
        "r": 0,
        "d": 0,
        "h": 42950066203,
        "f": 50331905
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 90194706459,
        "f": 83886337
      },
      "n": "SurrogateSelector",
      "d": 393243,
      "h": 94489673755,
      "f": 2097409
    },
//--TRIMMABLE-BOUNDARY-END(94489673755),
//--TRIMMABLE-BOUNDARY-START(8590327835),
    {
      "p": 1572891,
      "g": {
        "r": 0,
        "d": 0,
        "h": 25770197019,
        "f": 50331905
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 73014837275,
        "f": 83886337
      },
      "n": "Binder",
      "d": 393243,
      "h": 8590327835,
      "f": 2097409
    },
//--TRIMMABLE-BOUNDARY-END(8590327835),
//--TRIMMABLE-BOUNDARY-START(12885295131),
    {
      "p": 158990337,
      "g": {
        "r": 0,
        "d": 0,
        "h": 34360131611,
        "f": 50331905
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 81604771867,
        "f": 83886337
      },
      "n": "Context",
      "d": 393243,
      "h": 12885295131,
      "f": 2097409
    },
//--TRIMMABLE-BOUNDARY-END(12885295131)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(17180262427),
    {
      "r": 131073,
      "p": [
        {
          "n": "serializationStream",
          "p": 95748097
        }
      ],
      "n": "Deserialize",
      "d": 393243,
      "h": 17180262427,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(17180262427),
//--TRIMMABLE-BOUNDARY-START(47245033499),
    {
      "r": 131073,
      "p": [
        {
          "n": "objID",
          "p": 917505,
          "f": 2
        }
      ],
      "n": "GetNext",
      "d": 393243,
      "h": 47245033499,
      "f": 16777348
    },
//--TRIMMABLE-BOUNDARY-END(47245033499),
//--TRIMMABLE-BOUNDARY-START(60129935387),
    {
      "r": 917505,
      "p": [
        {
          "n": "obj",
          "p": 131073
        }
      ],
      "n": "Schedule",
      "d": 393243,
      "h": 60129935387,
      "f": 16777348
    },
//--TRIMMABLE-BOUNDARY-END(60129935387),
//--TRIMMABLE-BOUNDARY-START(64424902683),
    {
      "r": 65537,
      "p": [
        {
          "n": "serializationStream",
          "p": 95748097
        },
        {
          "n": "graph",
          "p": 131073
        }
      ],
      "n": "Serialize",
      "d": 393243,
      "h": 64424902683,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(64424902683),
//--TRIMMABLE-BOUNDARY-START(98784641051),
    {
      "r": 65537,
      "p": [
        {
          "n": "obj",
          "p": 131073
        },
        {
          "n": "name",
          "p": 1310721
        },
        {
          "n": "memberType",
          "p": 188547073
        }
      ],
      "n": "WriteArray",
      "d": 393243,
      "h": 98784641051,
      "f": 16777476
    },
//--TRIMMABLE-BOUNDARY-END(98784641051),
//--TRIMMABLE-BOUNDARY-START(103079608347),
    {
      "r": 65537,
      "p": [
        {
          "n": "val",
          "p": 262145
        },
        {
          "n": "name",
          "p": 1310721
        }
      ],
      "n": "WriteBoolean",
      "d": 393243,
      "h": 103079608347,
      "f": 16777476
    },
//--TRIMMABLE-BOUNDARY-END(103079608347),
//--TRIMMABLE-BOUNDARY-START(107374575643),
    {
      "r": 65537,
      "p": [
        {
          "n": "val",
          "p": 393217
        },
        {
          "n": "name",
          "p": 1310721
        }
      ],
      "n": "WriteByte",
      "d": 393243,
      "h": 107374575643,
      "f": 16777476
    },
//--TRIMMABLE-BOUNDARY-END(107374575643),
//--TRIMMABLE-BOUNDARY-START(111669542939),
    {
      "r": 65537,
      "p": [
        {
          "n": "val",
          "p": 458753
        },
        {
          "n": "name",
          "p": 1310721
        }
      ],
      "n": "WriteChar",
      "d": 393243,
      "h": 111669542939,
      "f": 16777476
    },
//--TRIMMABLE-BOUNDARY-END(111669542939),
//--TRIMMABLE-BOUNDARY-START(115964510235),
    {
      "r": 65537,
      "p": [
        {
          "n": "val",
          "p": 65994753
        },
        {
          "n": "name",
          "p": 1310721
        }
      ],
      "n": "WriteDateTime",
      "d": 393243,
      "h": 115964510235,
      "f": 16777476
    },
//--TRIMMABLE-BOUNDARY-END(115964510235),
//--TRIMMABLE-BOUNDARY-START(120259477531),
    {
      "r": 65537,
      "p": [
        {
          "n": "val",
          "p": 66846721
        },
        {
          "n": "name",
          "p": 1310721
        }
      ],
      "n": "WriteDecimal",
      "d": 393243,
      "h": 120259477531,
      "f": 16777476
    },
//--TRIMMABLE-BOUNDARY-END(120259477531),
//--TRIMMABLE-BOUNDARY-START(124554444827),
    {
      "r": 65537,
      "p": [
        {
          "n": "val",
          "p": 1179649
        },
        {
          "n": "name",
          "p": 1310721
        }
      ],
      "n": "WriteDouble",
      "d": 393243,
      "h": 124554444827,
      "f": 16777476
    },
//--TRIMMABLE-BOUNDARY-END(124554444827),
//--TRIMMABLE-BOUNDARY-START(128849412123),
    {
      "r": 65537,
      "p": [
        {
          "n": "val",
          "p": 524289
        },
        {
          "n": "name",
          "p": 1310721
        }
      ],
      "n": "WriteInt16",
      "d": 393243,
      "h": 128849412123,
      "f": 16777476
    },
//--TRIMMABLE-BOUNDARY-END(128849412123),
//--TRIMMABLE-BOUNDARY-START(133144379419),
    {
      "r": 65537,
      "p": [
        {
          "n": "val",
          "p": 655361
        },
        {
          "n": "name",
          "p": 1310721
        }
      ],
      "n": "WriteInt32",
      "d": 393243,
      "h": 133144379419,
      "f": 16777476
    },
//--TRIMMABLE-BOUNDARY-END(133144379419),
//--TRIMMABLE-BOUNDARY-START(137439346715),
    {
      "r": 65537,
      "p": [
        {
          "n": "val",
          "p": 917505
        },
        {
          "n": "name",
          "p": 1310721
        }
      ],
      "n": "WriteInt64",
      "d": 393243,
      "h": 137439346715,
      "f": 16777476
    },
//--TRIMMABLE-BOUNDARY-END(137439346715),
//--TRIMMABLE-BOUNDARY-START(146029281307),
    {
      "r": 65537,
      "p": [
        {
          "n": "obj",
          "p": 131073
        },
        {
          "n": "name",
          "p": 1310721
        },
        {
          "n": "memberType",
          "p": 188547073
        }
      ],
      "n": "WriteObjectRef",
      "d": 393243,
      "h": 146029281307,
      "f": 16777476
    },
//--TRIMMABLE-BOUNDARY-END(146029281307),
//--TRIMMABLE-BOUNDARY-START(141734314011),
    {
      "r": 65537,
      "p": [
        {
          "n": "memberName",
          "p": 1310721
        },
        {
          "n": "data",
          "p": 131073
        }
      ],
      "n": "WriteMember",
      "d": 393243,
      "h": 141734314011,
      "f": 16777348
    },
//--TRIMMABLE-BOUNDARY-END(141734314011),
//--TRIMMABLE-BOUNDARY-START(150324248603),
    {
      "r": 65537,
      "p": [
        {
          "n": "val",
          "p": 327681
        },
        {
          "n": "name",
          "p": 1310721
        }
      ],
      "n": "WriteSByte",
      "d": 393243,
      "h": 150324248603,
      "f": 16777476,
      "a": [
        {
          "t": 54984705,
          "c": 8644919297,
          "a": [
            {
              "v": false,
              "t": 262145
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(150324248603),
//--TRIMMABLE-BOUNDARY-START(154619215899),
    {
      "r": 65537,
      "p": [
        {
          "n": "val",
          "p": 1114113
        },
        {
          "n": "name",
          "p": 1310721
        }
      ],
      "n": "WriteSingle",
      "d": 393243,
      "h": 154619215899,
      "f": 16777476
    },
//--TRIMMABLE-BOUNDARY-END(154619215899),
//--TRIMMABLE-BOUNDARY-START(158914183195),
    {
      "r": 65537,
      "p": [
        {
          "n": "val",
          "p": 186646529
        },
        {
          "n": "name",
          "p": 1310721
        }
      ],
      "n": "WriteTimeSpan",
      "d": 393243,
      "h": 158914183195,
      "f": 16777476
    },
//--TRIMMABLE-BOUNDARY-END(158914183195),
//--TRIMMABLE-BOUNDARY-START(163209150491),
    {
      "r": 65537,
      "p": [
        {
          "n": "val",
          "p": 589825
        },
        {
          "n": "name",
          "p": 1310721
        }
      ],
      "n": "WriteUInt16",
      "d": 393243,
      "h": 163209150491,
      "f": 16777476,
      "a": [
        {
          "t": 54984705,
          "c": 8644919297,
          "a": [
            {
              "v": false,
              "t": 262145
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(163209150491),
//--TRIMMABLE-BOUNDARY-START(167504117787),
    {
      "r": 65537,
      "p": [
        {
          "n": "val",
          "p": 720897
        },
        {
          "n": "name",
          "p": 1310721
        }
      ],
      "n": "WriteUInt32",
      "d": 393243,
      "h": 167504117787,
      "f": 16777476,
      "a": [
        {
          "t": 54984705,
          "c": 8644919297,
          "a": [
            {
              "v": false,
              "t": 262145
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(167504117787),
//--TRIMMABLE-BOUNDARY-START(171799085083),
    {
      "r": 65537,
      "p": [
        {
          "n": "val",
          "p": 983041
        },
        {
          "n": "name",
          "p": 1310721
        }
      ],
      "n": "WriteUInt64",
      "d": 393243,
      "h": 171799085083,
      "f": 16777476,
      "a": [
        {
          "t": 54984705,
          "c": 8644919297,
          "a": [
            {
              "v": false,
              "t": 262145
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(171799085083),
//--TRIMMABLE-BOUNDARY-START(176094052379),
    {
      "r": 65537,
      "p": [
        {
          "n": "obj",
          "p": 131073
        },
        {
          "n": "name",
          "p": 1310721
        },
        {
          "n": "memberType",
          "p": 188547073
        }
      ],
      "n": "WriteValueType",
      "d": 393243,
      "h": 176094052379,
      "f": 16777476
    },
//--TRIMMABLE-BOUNDARY-END(176094052379)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(51540000795),
    {
      "t": 1441819,
      "n": "m_idGenerator",
      "d": 393243,
      "h": 51540000795,
      "f": 4194308
    },
//--TRIMMABLE-BOUNDARY-END(51540000795),
//--TRIMMABLE-BOUNDARY-START(55834968091),
    {
      "t": 393232,
      "n": "m_objectQueue",
      "d": 393243,
      "h": 55834968091,
      "f": 4194308
    },
//--TRIMMABLE-BOUNDARY-END(55834968091)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295360539),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 393243,
      "h": 4295360539,
      "f": 16777220
    },
//--TRIMMABLE-BOUNDARY-END(4295360539)
  ],
  "h": 393243,
  "a": [
    {
      "t": 54984705,
      "c": 8644919297,
      "a": [
        {
          "v": false,
          "t": 262145
        }
      ]
    },
    {
      "t": 104464385,
      "c": 30169235457,
      "a": [
        {
          "v": "BinaryFormatter serialization is obsolete and should not be used. See https://aka.ms/binaryformatter for more information.",
          "t": 1310721
        }
      ],
      "n": [
        {
          "n": "DiagnosticId",
          "v": "SYSLIB0011",
          "t": 1310721
        },
        {
          "n": "UrlFormat",
          "v": "https://aka.ms/dotnet-warnings/{0}",
          "t": 1310721
        }
      ]
    }
  ]
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$srsf.SRS.IFormatter ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `System.Runtime.Serialization.Formatter`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `System${separator}Runtime${separator}Serialization${separator}Formatter`; }
        });
        //--TRIMMABLE-BOUNDARY-END(393243)
        
        

        //--TRIMMABLE-BOUNDARY-START(1179675)
        $asm.$cls(`$srsf.SRS.MemberHolder`, ($self) => class MemberHolder extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8591114267)
            /*Type*/ _memberType = null;
            //--TRIMMABLE-BOUNDARY-END(8591114267)
            
            //--TRIMMABLE-BOUNDARY-START(4296146971)
            /*StreamingContext*/ _context;
            //--TRIMMABLE-BOUNDARY-END(4296146971)
            
            //--TRIMMABLE-BOUNDARY-START(12886081563)
            $ctor$1(/*Type*/ type, /*StreamingContext*/ ctx)
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(12886081563);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this._memberType = type;
                    this._context = ctx;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(12886081563)
            
            //--TRIMMABLE-BOUNDARY-START(21476016155)
            /*int */ GetHashCode()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(21476016155);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return this._memberType.GetHashCode();
                }
            }
            //--TRIMMABLE-BOUNDARY-END(21476016155)
            
            //--TRIMMABLE-BOUNDARY-START(17181048859)
            /*bool */ Equals$1(/*object?*/ obj)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17181048859);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                let mh;
                return $.$is(obj, $.$srsf.SRS.MemberHolder, { set $v($v){ mh = $v; } }) && $.$$.S.Object.ReferenceEquals(mh._memberType, this._memberType) && mh._context.State === this._context.State;
            }
            //--TRIMMABLE-BOUNDARY-END(17181048859)
            
            //default member initializer
            constructor()
            {
                super();
                //--TRIMMABLE-BOUNDARY-START(4296146971)
                this._context = $.$default($.$$.SRS.StreamingContext);
                //--TRIMMABLE-BOUNDARY-END(4296146971)
                
            }
            static $h = 1179675;
            static $f = 0b10010000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(21476016155),
    {
      "r": 655361,
      "n": "GetHashCode",
      "d": 1179675,
      "h": 21476016155,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(21476016155),
//--TRIMMABLE-BOUNDARY-START(17181048859),
    {
      "r": 262145,
      "p": [
        {
          "n": "obj",
          "p": 131073
        }
      ],
      "n": "Equals",
      "o": "@$1",
      "d": 1179675,
      "h": 17181048859,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(17181048859)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(8591114267),
    {
      "t": 188547073,
      "n": "_memberType",
      "d": 1179675,
      "h": 8591114267,
      "f": 4194312
    },
//--TRIMMABLE-BOUNDARY-END(8591114267),
//--TRIMMABLE-BOUNDARY-START(4296146971),
    {
      "t": 158990337,
      "n": "_context",
      "d": 1179675,
      "h": 4296146971,
      "f": 4194312
    },
//--TRIMMABLE-BOUNDARY-END(4296146971)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(12886081563),
    {
      "p": [
        {
          "n": "type",
          "p": 188547073
        },
        {
          "n": "ctx",
          "p": 158990337
        }
      ],
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 1179675,
      "h": 12886081563,
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(12886081563)
  ],
  "h": 1179675
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `System.Runtime.Serialization.MemberHolder`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `System${separator}Runtime${separator}Serialization${separator}MemberHolder`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1179675)
        
        

        //--TRIMMABLE-BOUNDARY-START(131099)
        $asm.$cls(`$srsf.S.Obsoletions`, ($self) => class Obsoletions
        {
            //--TRIMMABLE-BOUNDARY-START(382252220443)
            /*string*/ static SharedUrlFormat = null;
            //--TRIMMABLE-BOUNDARY-END(382252220443)
            
            //--TRIMMABLE-BOUNDARY-START(433791827995)
            /*string*/ static SystemTextEncodingUTF7Message = null;
            //--TRIMMABLE-BOUNDARY-END(433791827995)
            
            //--TRIMMABLE-BOUNDARY-START(429496860699)
            /*string*/ static SystemTextEncodingUTF7DiagId = null;
            //--TRIMMABLE-BOUNDARY-END(429496860699)
            
            //--TRIMMABLE-BOUNDARY-START(266288103451)
            /*string*/ static PrincipalPermissionAttributeMessage = null;
            //--TRIMMABLE-BOUNDARY-END(266288103451)
            
            //--TRIMMABLE-BOUNDARY-START(261993136155)
            /*string*/ static PrincipalPermissionAttributeDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(261993136155)
            
            //--TRIMMABLE-BOUNDARY-START(77309542427)
            /*string*/ static CodeAccessSecurityMessage = null;
            //--TRIMMABLE-BOUNDARY-END(77309542427)
            
            //--TRIMMABLE-BOUNDARY-START(73014575131)
            /*string*/ static CodeAccessSecurityDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(73014575131)
            
            //--TRIMMABLE-BOUNDARY-START(94489411611)
            /*string*/ static ConstrainedExecutionRegionMessage = null;
            //--TRIMMABLE-BOUNDARY-END(94489411611)
            
            //--TRIMMABLE-BOUNDARY-START(90194444315)
            /*string*/ static ConstrainedExecutionRegionDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(90194444315)
            
            //--TRIMMABLE-BOUNDARY-START(214748495899)
            /*string*/ static GlobalAssemblyCacheMessage = null;
            //--TRIMMABLE-BOUNDARY-END(214748495899)
            
            //--TRIMMABLE-BOUNDARY-START(210453528603)
            /*string*/ static GlobalAssemblyCacheDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(210453528603)
            
            //--TRIMMABLE-BOUNDARY-START(442381762587)
            /*string*/ static ThreadAbortMessage = null;
            //--TRIMMABLE-BOUNDARY-END(442381762587)
            
            //--TRIMMABLE-BOUNDARY-START(446676729883)
            /*string*/ static ThreadResetAbortMessage = null;
            //--TRIMMABLE-BOUNDARY-END(446676729883)
            
            //--TRIMMABLE-BOUNDARY-START(438086795291)
            /*string*/ static ThreadAbortDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(438086795291)
            
            //--TRIMMABLE-BOUNDARY-START(146029019163)
            /*string*/ static DefaultCryptoAlgorithmsMessage = null;
            //--TRIMMABLE-BOUNDARY-END(146029019163)
            
            //--TRIMMABLE-BOUNDARY-START(141734051867)
            /*string*/ static DefaultCryptoAlgorithmsDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(141734051867)
            
            //--TRIMMABLE-BOUNDARY-START(120259215387)
            /*string*/ static CreatePdbGeneratorMessage = null;
            //--TRIMMABLE-BOUNDARY-END(120259215387)
            
            //--TRIMMABLE-BOUNDARY-START(115964248091)
            /*string*/ static CreatePdbGeneratorDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(115964248091)
            
            //--TRIMMABLE-BOUNDARY-START(51539738651)
            /*string*/ static AuthenticationManagerMessage = null;
            //--TRIMMABLE-BOUNDARY-END(51539738651)
            
            //--TRIMMABLE-BOUNDARY-START(47244771355)
            /*string*/ static AuthenticationManagerDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(47244771355)
            
            //--TRIMMABLE-BOUNDARY-START(326417645595)
            /*string*/ static RemotingApisMessage = null;
            //--TRIMMABLE-BOUNDARY-END(326417645595)
            
            //--TRIMMABLE-BOUNDARY-START(322122678299)
            /*string*/ static RemotingApisDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(322122678299)
            
            //--TRIMMABLE-BOUNDARY-START(60129673243)
            /*string*/ static BinaryFormatterMessage = null;
            //--TRIMMABLE-BOUNDARY-END(60129673243)
            
            //--TRIMMABLE-BOUNDARY-START(55834705947)
            /*string*/ static BinaryFormatterDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(55834705947)
            
            //--TRIMMABLE-BOUNDARY-START(85899477019)
            /*string*/ static CodeBaseMessage = null;
            //--TRIMMABLE-BOUNDARY-END(85899477019)
            
            //--TRIMMABLE-BOUNDARY-START(81604509723)
            /*string*/ static CodeBaseDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(81604509723)
            
            //--TRIMMABLE-BOUNDARY-START(197568626715)
            /*string*/ static EscapeUriStringMessage = null;
            //--TRIMMABLE-BOUNDARY-END(197568626715)
            
            //--TRIMMABLE-BOUNDARY-START(193273659419)
            /*string*/ static EscapeUriStringDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(193273659419)
            
            //--TRIMMABLE-BOUNDARY-START(489626402843)
            /*string*/ static WebRequestMessage = null;
            //--TRIMMABLE-BOUNDARY-END(489626402843)
            
            //--TRIMMABLE-BOUNDARY-START(485331435547)
            /*string*/ static WebRequestDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(485331435547)
            
            //--TRIMMABLE-BOUNDARY-START(163208888347)
            /*string*/ static DisablePrivateReflectionAttributeMessage = null;
            //--TRIMMABLE-BOUNDARY-END(163208888347)
            
            //--TRIMMABLE-BOUNDARY-START(158913921051)
            /*string*/ static DisablePrivateReflectionAttributeDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(158913921051)
            
            //--TRIMMABLE-BOUNDARY-START(206158561307)
            /*string*/ static GetContextInfoMessage = null;
            //--TRIMMABLE-BOUNDARY-END(206158561307)
            
            //--TRIMMABLE-BOUNDARY-START(201863594011)
            /*string*/ static GetContextInfoDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(201863594011)
            
            //--TRIMMABLE-BOUNDARY-START(399432089627)
            /*string*/ static StrongNameKeyPairMessage = null;
            //--TRIMMABLE-BOUNDARY-END(399432089627)
            
            //--TRIMMABLE-BOUNDARY-START(395137122331)
            /*string*/ static StrongNameKeyPairDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(395137122331)
            
            //--TRIMMABLE-BOUNDARY-START(300647841819)
            /*string*/ static ReflectionOnlyLoadingMessage = null;
            //--TRIMMABLE-BOUNDARY-END(300647841819)
            
            //--TRIMMABLE-BOUNDARY-START(296352874523)
            /*string*/ static ReflectionOnlyLoadingDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(296352874523)
            
            //--TRIMMABLE-BOUNDARY-START(377957253147)
            /*string*/ static RuntimeEnvironmentMessage = null;
            //--TRIMMABLE-BOUNDARY-END(377957253147)
            
            //--TRIMMABLE-BOUNDARY-START(373662285851)
            /*string*/ static RuntimeEnvironmentDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(373662285851)
            
            //--TRIMMABLE-BOUNDARY-START(231928365083)
            /*string*/ static JsonSerializerOptionsIgnoreNullValuesMessage = null;
            //--TRIMMABLE-BOUNDARY-END(231928365083)
            
            //--TRIMMABLE-BOUNDARY-START(227633397787)
            /*string*/ static JsonSerializerOptionsIgnoreNullValuesDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(227633397787)
            
            //--TRIMMABLE-BOUNDARY-START(154618953755)
            /*string*/ static DerivedCryptographicTypesMessage = null;
            //--TRIMMABLE-BOUNDARY-END(154618953755)
            
            //--TRIMMABLE-BOUNDARY-START(150323986459)
            /*string*/ static DerivedCryptographicTypesDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(150323986459)
            
            //--TRIMMABLE-BOUNDARY-START(352187449371)
            /*string*/ static RijndaelMessage = null;
            //--TRIMMABLE-BOUNDARY-END(352187449371)
            
            //--TRIMMABLE-BOUNDARY-START(347892482075)
            /*string*/ static RijndaelDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(347892482075)
            
            //--TRIMMABLE-BOUNDARY-START(360777383963)
            /*string*/ static RNGCryptoServiceProviderMessage = null;
            //--TRIMMABLE-BOUNDARY-END(360777383963)
            
            //--TRIMMABLE-BOUNDARY-START(356482416667)
            /*string*/ static RNGCryptoServiceProviderDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(356482416667)
            
            //--TRIMMABLE-BOUNDARY-START(17180000283)
            /*string*/ static AppDomainCreateUnloadMessage = null;
            //--TRIMMABLE-BOUNDARY-END(17180000283)
            
            //--TRIMMABLE-BOUNDARY-START(12885032987)
            /*string*/ static AppDomainCreateUnloadDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(12885032987)
            
            //--TRIMMABLE-BOUNDARY-START(408022024219)
            /*string*/ static SuppressIldasmAttributeMessage = null;
            //--TRIMMABLE-BOUNDARY-END(408022024219)
            
            //--TRIMMABLE-BOUNDARY-START(403727056923)
            /*string*/ static SuppressIldasmAttributeDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(403727056923)
            
            //--TRIMMABLE-BOUNDARY-START(498216337435)
            /*string*/ static X509CertificateImmutableMessage = null;
            //--TRIMMABLE-BOUNDARY-END(498216337435)
            
            //--TRIMMABLE-BOUNDARY-START(493921370139)
            /*string*/ static X509CertificateImmutableDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(493921370139)
            
            //--TRIMMABLE-BOUNDARY-START(283467972635)
            /*string*/ static PublicKeyPropertyMessage = null;
            //--TRIMMABLE-BOUNDARY-END(283467972635)
            
            //--TRIMMABLE-BOUNDARY-START(279173005339)
            /*string*/ static PublicKeyPropertyDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(279173005339)
            
            //--TRIMMABLE-BOUNDARY-START(506806272027)
            /*string*/ static X509CertificatePrivateKeyMessage = null;
            //--TRIMMABLE-BOUNDARY-END(506806272027)
            
            //--TRIMMABLE-BOUNDARY-START(502511304731)
            /*string*/ static X509CertificatePrivateKeyDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(502511304731)
            
            //--TRIMMABLE-BOUNDARY-START(274878038043)
            /*string*/ static ProduceLegacyHmacValuesMessage = null;
            //--TRIMMABLE-BOUNDARY-END(274878038043)
            
            //--TRIMMABLE-BOUNDARY-START(270583070747)
            /*string*/ static ProduceLegacyHmacValuesDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(270583070747)
            
            //--TRIMMABLE-BOUNDARY-START(481036468251)
            /*string*/ static UseManagedSha1Message = null;
            //--TRIMMABLE-BOUNDARY-END(481036468251)
            
            //--TRIMMABLE-BOUNDARY-START(476741500955)
            /*string*/ static UseManagedSha1DiagId = null;
            //--TRIMMABLE-BOUNDARY-END(476741500955)
            
            //--TRIMMABLE-BOUNDARY-START(128849149979)
            /*string*/ static CryptoConfigEncodeOIDMessage = null;
            //--TRIMMABLE-BOUNDARY-END(128849149979)
            
            //--TRIMMABLE-BOUNDARY-START(124554182683)
            /*string*/ static CryptoConfigEncodeOIDDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(124554182683)
            
            //--TRIMMABLE-BOUNDARY-START(111669280795)
            /*string*/ static CorruptedStateRecoveryMessage = null;
            //--TRIMMABLE-BOUNDARY-END(111669280795)
            
            //--TRIMMABLE-BOUNDARY-START(107374313499)
            /*string*/ static CorruptedStateRecoveryDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(107374313499)
            
            //--TRIMMABLE-BOUNDARY-START(335007580187)
            /*string*/ static Rfc2898CryptDeriveKeyMessage = null;
            //--TRIMMABLE-BOUNDARY-END(335007580187)
            
            //--TRIMMABLE-BOUNDARY-START(330712612891)
            /*string*/ static Rfc2898CryptDeriveKeyDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(330712612891)
            
            //--TRIMMABLE-BOUNDARY-START(68719607835)
            /*string*/ static CmsSignerCspParamsCtorMessage = null;
            //--TRIMMABLE-BOUNDARY-END(68719607835)
            
            //--TRIMMABLE-BOUNDARY-START(64424640539)
            /*string*/ static CmsSignerCspParamsCtorDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(64424640539)
            
            //--TRIMMABLE-BOUNDARY-START(390842155035)
            /*string*/ static SignerInfoCounterSigMessage = null;
            //--TRIMMABLE-BOUNDARY-END(390842155035)
            
            //--TRIMMABLE-BOUNDARY-START(386547187739)
            /*string*/ static SignerInfoCounterSigDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(386547187739)
            
            //--TRIMMABLE-BOUNDARY-START(309237776411)
            /*string*/ static RegexCompileToAssemblyMessage = null;
            //--TRIMMABLE-BOUNDARY-END(309237776411)
            
            //--TRIMMABLE-BOUNDARY-START(304942809115)
            /*string*/ static RegexCompileToAssemblyDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(304942809115)
            
            //--TRIMMABLE-BOUNDARY-START(42949804059)
            /*string*/ static AssemblyNameMembersMessage = null;
            //--TRIMMABLE-BOUNDARY-END(42949804059)
            
            //--TRIMMABLE-BOUNDARY-START(38654836763)
            /*string*/ static AssemblyNameMembersDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(38654836763)
            
            //--TRIMMABLE-BOUNDARY-START(416611958811)
            /*string*/ static SystemDataSerializationFormatBinaryMessage = null;
            //--TRIMMABLE-BOUNDARY-END(416611958811)
            
            //--TRIMMABLE-BOUNDARY-START(412316991515)
            /*string*/ static SystemDataSerializationFormatBinaryDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(412316991515)
            
            //--TRIMMABLE-BOUNDARY-START(472446533659)
            /*string*/ static TlsVersion10and11Message = null;
            //--TRIMMABLE-BOUNDARY-END(472446533659)
            
            //--TRIMMABLE-BOUNDARY-START(468151566363)
            /*string*/ static TlsVersion10and11DiagId = null;
            //--TRIMMABLE-BOUNDARY-END(468151566363)
            
            //--TRIMMABLE-BOUNDARY-START(188978692123)
            /*string*/ static EncryptionPolicyMessage = null;
            //--TRIMMABLE-BOUNDARY-END(188978692123)
            
            //--TRIMMABLE-BOUNDARY-START(184683724827)
            /*string*/ static EncryptionPolicyDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(184683724827)
            
            //--TRIMMABLE-BOUNDARY-START(171798822939)
            /*string*/ static EccXmlExportImportMessage = null;
            //--TRIMMABLE-BOUNDARY-END(171798822939)
            
            //--TRIMMABLE-BOUNDARY-START(167503855643)
            /*string*/ static EccXmlExportImportDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(167503855643)
            
            //--TRIMMABLE-BOUNDARY-START(180388757531)
            /*string*/ static EcDhPublicKeyBlobMessage = null;
            //--TRIMMABLE-BOUNDARY-END(180388757531)
            
            //--TRIMMABLE-BOUNDARY-START(176093790235)
            /*string*/ static EcDhPublicKeyBlobDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(176093790235)
            
            //--TRIMMABLE-BOUNDARY-START(34359869467)
            /*string*/ static AssemblyNameCodeBaseMessage = null;
            //--TRIMMABLE-BOUNDARY-END(34359869467)
            
            //--TRIMMABLE-BOUNDARY-START(30064902171)
            /*string*/ static AssemblyNameCodeBaseDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(30064902171)
            
            //--TRIMMABLE-BOUNDARY-START(137439084571)
            /*string*/ static CryptoStringFactoryMessage = null;
            //--TRIMMABLE-BOUNDARY-END(137439084571)
            
            //--TRIMMABLE-BOUNDARY-START(133144117275)
            /*string*/ static CryptoStringFactoryDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(133144117275)
            
            //--TRIMMABLE-BOUNDARY-START(103079346203)
            /*string*/ static ControlledExecutionRunMessage = null;
            //--TRIMMABLE-BOUNDARY-END(103079346203)
            
            //--TRIMMABLE-BOUNDARY-START(98784378907)
            /*string*/ static ControlledExecutionRunDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(98784378907)
            
            //--TRIMMABLE-BOUNDARY-START(523986141211)
            /*string*/ static XmlSecureResolverMessage = null;
            //--TRIMMABLE-BOUNDARY-END(523986141211)
            
            //--TRIMMABLE-BOUNDARY-START(519691173915)
            /*string*/ static XmlSecureResolverDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(519691173915)
            
            //--TRIMMABLE-BOUNDARY-START(369367318555)
            /*string*/ static RsaEncryptDecryptValueMessage = null;
            //--TRIMMABLE-BOUNDARY-END(369367318555)
            
            //--TRIMMABLE-BOUNDARY-START(365072351259)
            /*string*/ static RsaEncryptDecryptDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(365072351259)
            
            //--TRIMMABLE-BOUNDARY-START(223338430491)
            /*string*/ static JsonSerializerOptionsAddContextMessage = null;
            //--TRIMMABLE-BOUNDARY-END(223338430491)
            
            //--TRIMMABLE-BOUNDARY-START(219043463195)
            /*string*/ static JsonSerializerOptionsAddContextDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(219043463195)
            
            //--TRIMMABLE-BOUNDARY-START(249108234267)
            /*string*/ static LegacyFormatterMessage = null;
            //--TRIMMABLE-BOUNDARY-END(249108234267)
            
            //--TRIMMABLE-BOUNDARY-START(236223332379)
            /*string*/ static LegacyFormatterDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(236223332379)
            
            //--TRIMMABLE-BOUNDARY-START(244813266971)
            /*string*/ static LegacyFormatterImplMessage = null;
            //--TRIMMABLE-BOUNDARY-END(244813266971)
            
            //--TRIMMABLE-BOUNDARY-START(240518299675)
            /*string*/ static LegacyFormatterImplDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(240518299675)
            
            //--TRIMMABLE-BOUNDARY-START(317827711003)
            /*string*/ static RegexExtensibilityImplMessage = null;
            //--TRIMMABLE-BOUNDARY-END(317827711003)
            
            //--TRIMMABLE-BOUNDARY-START(313532743707)
            /*string*/ static RegexExtensibilityDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(313532743707)
            
            //--TRIMMABLE-BOUNDARY-START(8590065691)
            /*string*/ static AesGcmTagConstructorMessage = null;
            //--TRIMMABLE-BOUNDARY-END(8590065691)
            
            //--TRIMMABLE-BOUNDARY-START(4295098395)
            /*string*/ static AesGcmTagConstructorDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(4295098395)
            
            //--TRIMMABLE-BOUNDARY-START(455266664475)
            /*string*/ static ThreadVolatileReadWriteMessage = null;
            //--TRIMMABLE-BOUNDARY-END(455266664475)
            
            //--TRIMMABLE-BOUNDARY-START(450971697179)
            /*string*/ static ThreadVolatileReadWriteDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(450971697179)
            
            //--TRIMMABLE-BOUNDARY-START(25769934875)
            /*string*/ static ArmIntrinsicPerformsUnsignedOperationMessage = null;
            //--TRIMMABLE-BOUNDARY-END(25769934875)
            
            //--TRIMMABLE-BOUNDARY-START(21474967579)
            /*string*/ static ArmIntrinsicPerformsUnsignedOperationDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(21474967579)
            
            //--TRIMMABLE-BOUNDARY-START(257698168859)
            /*string*/ static LoadFromHashAlgorithmMessage = null;
            //--TRIMMABLE-BOUNDARY-END(257698168859)
            
            //--TRIMMABLE-BOUNDARY-START(253403201563)
            /*string*/ static LoadFromHashAlgorithmDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(253403201563)
            
            //--TRIMMABLE-BOUNDARY-START(515396206619)
            /*string*/ static X509CtorCertDataObsoleteMessage = null;
            //--TRIMMABLE-BOUNDARY-END(515396206619)
            
            //--TRIMMABLE-BOUNDARY-START(511101239323)
            /*string*/ static X509CtorCertDataObsoleteDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(511101239323)
            
            //--TRIMMABLE-BOUNDARY-START(463856599067)
            /*string*/ static TlsCipherAlgorithmEnumsMessage = null;
            //--TRIMMABLE-BOUNDARY-END(463856599067)
            
            //--TRIMMABLE-BOUNDARY-START(459561631771)
            /*string*/ static TlsCipherAlgorithmEnumsDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(459561631771)
            
            //--TRIMMABLE-BOUNDARY-START(425201893403)
            /*string*/ static SystemEventsEventsThreadShutdownMessage = null;
            //--TRIMMABLE-BOUNDARY-END(425201893403)
            
            //--TRIMMABLE-BOUNDARY-START(420906926107)
            /*string*/ static SystemEventsEventsThreadShutdownDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(420906926107)
            
            //--TRIMMABLE-BOUNDARY-START(343597514779)
            /*string*/ static Rfc2898DeriveBytesCtorMessage = null;
            //--TRIMMABLE-BOUNDARY-END(343597514779)
            
            //--TRIMMABLE-BOUNDARY-START(339302547483)
            /*string*/ static Rfc2898DeriveBytesCtorDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(339302547483)
            
            //--TRIMMABLE-BOUNDARY-START(292057907227)
            /*string*/ static QueryableMinByMaxByTSourceObsoleteMessage = null;
            //--TRIMMABLE-BOUNDARY-END(292057907227)
            
            //--TRIMMABLE-BOUNDARY-START(287762939931)
            /*string*/ static QueryableMinByMaxByTSourceObsoleteDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(287762939931)
            
            //--TRIMMABLE-BOUNDARY-START(532576075803)
            /*string*/ static XsltSettingsEnableScriptMessage = null;
            //--TRIMMABLE-BOUNDARY-END(532576075803)
            
            //--TRIMMABLE-BOUNDARY-START(528281108507)
            /*string*/ static XsltSettingsEnableScriptDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(528281108507)
            
            //--TRIMMABLE-BOUNDARY-START(SINIT)
            //Static Initializer
            static $sinit()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(382252220443)
                    this.SharedUrlFormat = "https://aka.ms/dotnet-warnings/{0}";
                    //--TRIMMABLE-BOUNDARY-END(382252220443)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(433791827995)
                    this.SystemTextEncodingUTF7Message = "The UTF-7 encoding is insecure and should not be used. Consider using UTF-8 instead.";
                    //--TRIMMABLE-BOUNDARY-END(433791827995)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(429496860699)
                    this.SystemTextEncodingUTF7DiagId = "SYSLIB0001";
                    //--TRIMMABLE-BOUNDARY-END(429496860699)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(266288103451)
                    this.PrincipalPermissionAttributeMessage = "PrincipalPermissionAttribute is not honored by the runtime and must not be used.";
                    //--TRIMMABLE-BOUNDARY-END(266288103451)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(261993136155)
                    this.PrincipalPermissionAttributeDiagId = "SYSLIB0002";
                    //--TRIMMABLE-BOUNDARY-END(261993136155)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(77309542427)
                    this.CodeAccessSecurityMessage = "Code Access Security is not supported or honored by the runtime.";
                    //--TRIMMABLE-BOUNDARY-END(77309542427)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(73014575131)
                    this.CodeAccessSecurityDiagId = "SYSLIB0003";
                    //--TRIMMABLE-BOUNDARY-END(73014575131)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(94489411611)
                    this.ConstrainedExecutionRegionMessage = "The Constrained Execution Region (CER) feature is not supported.";
                    //--TRIMMABLE-BOUNDARY-END(94489411611)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(90194444315)
                    this.ConstrainedExecutionRegionDiagId = "SYSLIB0004";
                    //--TRIMMABLE-BOUNDARY-END(90194444315)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(214748495899)
                    this.GlobalAssemblyCacheMessage = "The Global Assembly Cache is not supported.";
                    //--TRIMMABLE-BOUNDARY-END(214748495899)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(210453528603)
                    this.GlobalAssemblyCacheDiagId = "SYSLIB0005";
                    //--TRIMMABLE-BOUNDARY-END(210453528603)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(442381762587)
                    this.ThreadAbortMessage = "Thread.Abort is not supported and throws PlatformNotSupportedException.";
                    //--TRIMMABLE-BOUNDARY-END(442381762587)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(446676729883)
                    this.ThreadResetAbortMessage = "Thread.ResetAbort is not supported and throws PlatformNotSupportedException.";
                    //--TRIMMABLE-BOUNDARY-END(446676729883)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(438086795291)
                    this.ThreadAbortDiagId = "SYSLIB0006";
                    //--TRIMMABLE-BOUNDARY-END(438086795291)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(146029019163)
                    this.DefaultCryptoAlgorithmsMessage = "The default implementation of this cryptography algorithm is not supported.";
                    //--TRIMMABLE-BOUNDARY-END(146029019163)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(141734051867)
                    this.DefaultCryptoAlgorithmsDiagId = "SYSLIB0007";
                    //--TRIMMABLE-BOUNDARY-END(141734051867)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(120259215387)
                    this.CreatePdbGeneratorMessage = "The CreatePdbGenerator API is not supported and throws PlatformNotSupportedException.";
                    //--TRIMMABLE-BOUNDARY-END(120259215387)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(115964248091)
                    this.CreatePdbGeneratorDiagId = "SYSLIB0008";
                    //--TRIMMABLE-BOUNDARY-END(115964248091)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(51539738651)
                    this.AuthenticationManagerMessage = "AuthenticationManager is not supported. Methods will no-op or throw PlatformNotSupportedException.";
                    //--TRIMMABLE-BOUNDARY-END(51539738651)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(47244771355)
                    this.AuthenticationManagerDiagId = "SYSLIB0009";
                    //--TRIMMABLE-BOUNDARY-END(47244771355)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(326417645595)
                    this.RemotingApisMessage = "This Remoting API is not supported and throws PlatformNotSupportedException.";
                    //--TRIMMABLE-BOUNDARY-END(326417645595)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(322122678299)
                    this.RemotingApisDiagId = "SYSLIB0010";
                    //--TRIMMABLE-BOUNDARY-END(322122678299)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(60129673243)
                    this.BinaryFormatterMessage = "BinaryFormatter serialization is obsolete and should not be used. See https://aka.ms/binaryformatter for more information.";
                    //--TRIMMABLE-BOUNDARY-END(60129673243)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(55834705947)
                    this.BinaryFormatterDiagId = "SYSLIB0011";
                    //--TRIMMABLE-BOUNDARY-END(55834705947)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(85899477019)
                    this.CodeBaseMessage = "Assembly.CodeBase and Assembly.EscapedCodeBase are only included for .NET Framework compatibility. Use Assembly.Location instead.";
                    //--TRIMMABLE-BOUNDARY-END(85899477019)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(81604509723)
                    this.CodeBaseDiagId = "SYSLIB0012";
                    //--TRIMMABLE-BOUNDARY-END(81604509723)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(197568626715)
                    this.EscapeUriStringMessage = "Uri.EscapeUriString can corrupt the Uri string in some cases. Consider using Uri.EscapeDataString for query string components instead.";
                    //--TRIMMABLE-BOUNDARY-END(197568626715)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(193273659419)
                    this.EscapeUriStringDiagId = "SYSLIB0013";
                    //--TRIMMABLE-BOUNDARY-END(193273659419)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(489626402843)
                    this.WebRequestMessage = "WebRequest, HttpWebRequest, ServicePoint, and WebClient are obsolete. Use HttpClient instead.";
                    //--TRIMMABLE-BOUNDARY-END(489626402843)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(485331435547)
                    this.WebRequestDiagId = "SYSLIB0014";
                    //--TRIMMABLE-BOUNDARY-END(485331435547)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(163208888347)
                    this.DisablePrivateReflectionAttributeMessage = "DisablePrivateReflectionAttribute has no effect in .NET 6.0+.";
                    //--TRIMMABLE-BOUNDARY-END(163208888347)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(158913921051)
                    this.DisablePrivateReflectionAttributeDiagId = "SYSLIB0015";
                    //--TRIMMABLE-BOUNDARY-END(158913921051)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(206158561307)
                    this.GetContextInfoMessage = "Use the Graphics.GetContextInfo overloads that accept arguments for better performance and fewer allocations.";
                    //--TRIMMABLE-BOUNDARY-END(206158561307)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(201863594011)
                    this.GetContextInfoDiagId = "SYSLIB0016";
                    //--TRIMMABLE-BOUNDARY-END(201863594011)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(399432089627)
                    this.StrongNameKeyPairMessage = "Strong name signing is not supported and throws PlatformNotSupportedException.";
                    //--TRIMMABLE-BOUNDARY-END(399432089627)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(395137122331)
                    this.StrongNameKeyPairDiagId = "SYSLIB0017";
                    //--TRIMMABLE-BOUNDARY-END(395137122331)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(300647841819)
                    this.ReflectionOnlyLoadingMessage = "ReflectionOnly loading is not supported and throws PlatformNotSupportedException.";
                    //--TRIMMABLE-BOUNDARY-END(300647841819)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(296352874523)
                    this.ReflectionOnlyLoadingDiagId = "SYSLIB0018";
                    //--TRIMMABLE-BOUNDARY-END(296352874523)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(377957253147)
                    this.RuntimeEnvironmentMessage = "RuntimeEnvironment members SystemConfigurationFile, GetRuntimeInterfaceAsIntPtr, and GetRuntimeInterfaceAsObject are not supported and throw PlatformNotSupportedException.";
                    //--TRIMMABLE-BOUNDARY-END(377957253147)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(373662285851)
                    this.RuntimeEnvironmentDiagId = "SYSLIB0019";
                    //--TRIMMABLE-BOUNDARY-END(373662285851)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(231928365083)
                    this.JsonSerializerOptionsIgnoreNullValuesMessage = "JsonSerializerOptions.IgnoreNullValues is obsolete. To ignore null values when serializing, set DefaultIgnoreCondition to JsonIgnoreCondition.WhenWritingNull.";
                    //--TRIMMABLE-BOUNDARY-END(231928365083)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(227633397787)
                    this.JsonSerializerOptionsIgnoreNullValuesDiagId = "SYSLIB0020";
                    //--TRIMMABLE-BOUNDARY-END(227633397787)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(154618953755)
                    this.DerivedCryptographicTypesMessage = "Derived cryptographic types are obsolete. Use the Create method on the base type instead.";
                    //--TRIMMABLE-BOUNDARY-END(154618953755)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(150323986459)
                    this.DerivedCryptographicTypesDiagId = "SYSLIB0021";
                    //--TRIMMABLE-BOUNDARY-END(150323986459)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(352187449371)
                    this.RijndaelMessage = "The Rijndael and RijndaelManaged types are obsolete. Use Aes instead.";
                    //--TRIMMABLE-BOUNDARY-END(352187449371)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(347892482075)
                    this.RijndaelDiagId = "SYSLIB0022";
                    //--TRIMMABLE-BOUNDARY-END(347892482075)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(360777383963)
                    this.RNGCryptoServiceProviderMessage = "RNGCryptoServiceProvider is obsolete. To generate a random number, use one of the RandomNumberGenerator static methods instead.";
                    //--TRIMMABLE-BOUNDARY-END(360777383963)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(356482416667)
                    this.RNGCryptoServiceProviderDiagId = "SYSLIB0023";
                    //--TRIMMABLE-BOUNDARY-END(356482416667)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(17180000283)
                    this.AppDomainCreateUnloadMessage = "Creating and unloading AppDomains is not supported and throws an exception.";
                    //--TRIMMABLE-BOUNDARY-END(17180000283)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(12885032987)
                    this.AppDomainCreateUnloadDiagId = "SYSLIB0024";
                    //--TRIMMABLE-BOUNDARY-END(12885032987)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(408022024219)
                    this.SuppressIldasmAttributeMessage = "SuppressIldasmAttribute has no effect in .NET 6.0+.";
                    //--TRIMMABLE-BOUNDARY-END(408022024219)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(403727056923)
                    this.SuppressIldasmAttributeDiagId = "SYSLIB0025";
                    //--TRIMMABLE-BOUNDARY-END(403727056923)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(498216337435)
                    this.X509CertificateImmutableMessage = "X509Certificate and X509Certificate2 are immutable. Use X509CertificateLoader to create a new certificate.";
                    //--TRIMMABLE-BOUNDARY-END(498216337435)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(493921370139)
                    this.X509CertificateImmutableDiagId = "SYSLIB0026";
                    //--TRIMMABLE-BOUNDARY-END(493921370139)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(283467972635)
                    this.PublicKeyPropertyMessage = "PublicKey.Key is obsolete. Use the appropriate method to get the public key, such as GetRSAPublicKey.";
                    //--TRIMMABLE-BOUNDARY-END(283467972635)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(279173005339)
                    this.PublicKeyPropertyDiagId = "SYSLIB0027";
                    //--TRIMMABLE-BOUNDARY-END(279173005339)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(506806272027)
                    this.X509CertificatePrivateKeyMessage = "X509Certificate2.PrivateKey is obsolete. Use the appropriate method to get the private key, such as GetRSAPrivateKey, or use the CopyWithPrivateKey method to create a new instance with a private key.";
                    //--TRIMMABLE-BOUNDARY-END(506806272027)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(502511304731)
                    this.X509CertificatePrivateKeyDiagId = "SYSLIB0028";
                    //--TRIMMABLE-BOUNDARY-END(502511304731)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(274878038043)
                    this.ProduceLegacyHmacValuesMessage = "ProduceLegacyHmacValues is obsolete. Producing legacy HMAC values is not supported.";
                    //--TRIMMABLE-BOUNDARY-END(274878038043)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(270583070747)
                    this.ProduceLegacyHmacValuesDiagId = "SYSLIB0029";
                    //--TRIMMABLE-BOUNDARY-END(270583070747)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(481036468251)
                    this.UseManagedSha1Message = "HMACSHA1 always uses the algorithm implementation provided by the platform. Use a constructor without the useManagedSha1 parameter.";
                    //--TRIMMABLE-BOUNDARY-END(481036468251)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(476741500955)
                    this.UseManagedSha1DiagId = "SYSLIB0030";
                    //--TRIMMABLE-BOUNDARY-END(476741500955)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(128849149979)
                    this.CryptoConfigEncodeOIDMessage = "EncodeOID is obsolete. Use the ASN.1 functionality provided in System.Formats.Asn1.";
                    //--TRIMMABLE-BOUNDARY-END(128849149979)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(124554182683)
                    this.CryptoConfigEncodeOIDDiagId = "SYSLIB0031";
                    //--TRIMMABLE-BOUNDARY-END(124554182683)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(111669280795)
                    this.CorruptedStateRecoveryMessage = "Recovery from corrupted process state exceptions is not supported; HandleProcessCorruptedStateExceptionsAttribute is ignored.";
                    //--TRIMMABLE-BOUNDARY-END(111669280795)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(107374313499)
                    this.CorruptedStateRecoveryDiagId = "SYSLIB0032";
                    //--TRIMMABLE-BOUNDARY-END(107374313499)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(335007580187)
                    this.Rfc2898CryptDeriveKeyMessage = "Rfc2898DeriveBytes.CryptDeriveKey is obsolete and is not supported. Use PasswordDeriveBytes.CryptDeriveKey instead.";
                    //--TRIMMABLE-BOUNDARY-END(335007580187)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(330712612891)
                    this.Rfc2898CryptDeriveKeyDiagId = "SYSLIB0033";
                    //--TRIMMABLE-BOUNDARY-END(330712612891)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(68719607835)
                    this.CmsSignerCspParamsCtorMessage = "CmsSigner(CspParameters) is obsolete and is not supported. Use an alternative constructor instead.";
                    //--TRIMMABLE-BOUNDARY-END(68719607835)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(64424640539)
                    this.CmsSignerCspParamsCtorDiagId = "SYSLIB0034";
                    //--TRIMMABLE-BOUNDARY-END(64424640539)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(390842155035)
                    this.SignerInfoCounterSigMessage = "ComputeCounterSignature without specifying a CmsSigner is obsolete and is not supported. Use the overload that accepts a CmsSigner.";
                    //--TRIMMABLE-BOUNDARY-END(390842155035)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(386547187739)
                    this.SignerInfoCounterSigDiagId = "SYSLIB0035";
                    //--TRIMMABLE-BOUNDARY-END(386547187739)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(309237776411)
                    this.RegexCompileToAssemblyMessage = "Regex.CompileToAssembly is obsolete and not supported. Use the GeneratedRegexAttribute with the regular expression source generator instead.";
                    //--TRIMMABLE-BOUNDARY-END(309237776411)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(304942809115)
                    this.RegexCompileToAssemblyDiagId = "SYSLIB0036";
                    //--TRIMMABLE-BOUNDARY-END(304942809115)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(42949804059)
                    this.AssemblyNameMembersMessage = "AssemblyName members HashAlgorithm, ProcessorArchitecture, and VersionCompatibility are obsolete and not supported.";
                    //--TRIMMABLE-BOUNDARY-END(42949804059)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(38654836763)
                    this.AssemblyNameMembersDiagId = "SYSLIB0037";
                    //--TRIMMABLE-BOUNDARY-END(38654836763)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(416611958811)
                    this.SystemDataSerializationFormatBinaryMessage = "SerializationFormat.Binary is obsolete and should not be used. See https://aka.ms/serializationformat-binary-obsolete for more information.";
                    //--TRIMMABLE-BOUNDARY-END(416611958811)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(412316991515)
                    this.SystemDataSerializationFormatBinaryDiagId = "SYSLIB0038";
                    //--TRIMMABLE-BOUNDARY-END(412316991515)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(472446533659)
                    this.TlsVersion10and11Message = "TLS versions 1.0 and 1.1 have known vulnerabilities and are not recommended. Use a newer TLS version instead, or use SslProtocols.None to defer to OS defaults.";
                    //--TRIMMABLE-BOUNDARY-END(472446533659)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(468151566363)
                    this.TlsVersion10and11DiagId = "SYSLIB0039";
                    //--TRIMMABLE-BOUNDARY-END(468151566363)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(188978692123)
                    this.EncryptionPolicyMessage = "EncryptionPolicy.NoEncryption and AllowEncryption significantly reduce security and should not be used in production code.";
                    //--TRIMMABLE-BOUNDARY-END(188978692123)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(184683724827)
                    this.EncryptionPolicyDiagId = "SYSLIB0040";
                    //--TRIMMABLE-BOUNDARY-END(184683724827)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(171798822939)
                    this.EccXmlExportImportMessage = "ToXmlString and FromXmlString have no implementation for ECC types, and are obsolete. Use a standard import and export format such as ExportSubjectPublicKeyInfo or ImportSubjectPublicKeyInfo for public keys and ExportPkcs8PrivateKey or ImportPkcs8PrivateKey for private keys.";
                    //--TRIMMABLE-BOUNDARY-END(171798822939)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(167503855643)
                    this.EccXmlExportImportDiagId = "SYSLIB0042";
                    //--TRIMMABLE-BOUNDARY-END(167503855643)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(180388757531)
                    this.EcDhPublicKeyBlobMessage = "ECDiffieHellmanPublicKey.ToByteArray() and the associated constructor do not have a consistent and interoperable implementation on all platforms. Use ECDiffieHellmanPublicKey.ExportSubjectPublicKeyInfo() instead.";
                    //--TRIMMABLE-BOUNDARY-END(180388757531)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(176093790235)
                    this.EcDhPublicKeyBlobDiagId = "SYSLIB0043";
                    //--TRIMMABLE-BOUNDARY-END(176093790235)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(34359869467)
                    this.AssemblyNameCodeBaseMessage = "AssemblyName.CodeBase and AssemblyName.EscapedCodeBase are obsolete. Using them for loading an assembly is not supported.";
                    //--TRIMMABLE-BOUNDARY-END(34359869467)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(30064902171)
                    this.AssemblyNameCodeBaseDiagId = "SYSLIB0044";
                    //--TRIMMABLE-BOUNDARY-END(30064902171)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(137439084571)
                    this.CryptoStringFactoryMessage = "Cryptographic factory methods accepting an algorithm name are obsolete. Use the parameterless Create factory method on the algorithm type instead.";
                    //--TRIMMABLE-BOUNDARY-END(137439084571)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(133144117275)
                    this.CryptoStringFactoryDiagId = "SYSLIB0045";
                    //--TRIMMABLE-BOUNDARY-END(133144117275)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(103079346203)
                    this.ControlledExecutionRunMessage = "ControlledExecution.Run method may corrupt the process and should not be used in production code.";
                    //--TRIMMABLE-BOUNDARY-END(103079346203)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(98784378907)
                    this.ControlledExecutionRunDiagId = "SYSLIB0046";
                    //--TRIMMABLE-BOUNDARY-END(98784378907)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(523986141211)
                    this.XmlSecureResolverMessage = "XmlSecureResolver is obsolete. Use XmlResolver.ThrowingResolver instead when attempting to forbid XML external entity resolution.";
                    //--TRIMMABLE-BOUNDARY-END(523986141211)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(519691173915)
                    this.XmlSecureResolverDiagId = "SYSLIB0047";
                    //--TRIMMABLE-BOUNDARY-END(519691173915)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(369367318555)
                    this.RsaEncryptDecryptValueMessage = "RSA.EncryptValue and DecryptValue are not supported and throw NotSupportedException. Use RSA.Encrypt and RSA.Decrypt instead.";
                    //--TRIMMABLE-BOUNDARY-END(369367318555)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(365072351259)
                    this.RsaEncryptDecryptDiagId = "SYSLIB0048";
                    //--TRIMMABLE-BOUNDARY-END(365072351259)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(223338430491)
                    this.JsonSerializerOptionsAddContextMessage = "JsonSerializerOptions.AddContext is obsolete. To register a JsonSerializerContext, use either the TypeInfoResolver or TypeInfoResolverChain properties.";
                    //--TRIMMABLE-BOUNDARY-END(223338430491)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(219043463195)
                    this.JsonSerializerOptionsAddContextDiagId = "SYSLIB0049";
                    //--TRIMMABLE-BOUNDARY-END(219043463195)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(249108234267)
                    this.LegacyFormatterMessage = "Formatter-based serialization is obsolete and should not be used.";
                    //--TRIMMABLE-BOUNDARY-END(249108234267)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(236223332379)
                    this.LegacyFormatterDiagId = "SYSLIB0050";
                    //--TRIMMABLE-BOUNDARY-END(236223332379)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(244813266971)
                    this.LegacyFormatterImplMessage = "This API supports obsolete formatter-based serialization. It should not be called or extended by application code.";
                    //--TRIMMABLE-BOUNDARY-END(244813266971)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(240518299675)
                    this.LegacyFormatterImplDiagId = "SYSLIB0051";
                    //--TRIMMABLE-BOUNDARY-END(240518299675)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(317827711003)
                    this.RegexExtensibilityImplMessage = "This API supports obsolete mechanisms for Regex extensibility. It is not supported.";
                    //--TRIMMABLE-BOUNDARY-END(317827711003)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(313532743707)
                    this.RegexExtensibilityDiagId = "SYSLIB0052";
                    //--TRIMMABLE-BOUNDARY-END(313532743707)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(8590065691)
                    this.AesGcmTagConstructorMessage = "AesGcm should indicate the required tag size for encryption and decryption. Use a constructor that accepts the tag size.";
                    //--TRIMMABLE-BOUNDARY-END(8590065691)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(4295098395)
                    this.AesGcmTagConstructorDiagId = "SYSLIB0053";
                    //--TRIMMABLE-BOUNDARY-END(4295098395)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(455266664475)
                    this.ThreadVolatileReadWriteMessage = "Thread.VolatileRead and Thread.VolatileWrite are obsolete. Use Volatile.Read or Volatile.Write respectively instead.";
                    //--TRIMMABLE-BOUNDARY-END(455266664475)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(450971697179)
                    this.ThreadVolatileReadWriteDiagId = "SYSLIB0054";
                    //--TRIMMABLE-BOUNDARY-END(450971697179)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(25769934875)
                    this.ArmIntrinsicPerformsUnsignedOperationMessage = "The underlying hardware instruction does not perform a signed saturate narrowing operation, and it always returns an unsigned result. Use the unsigned overload instead.";
                    //--TRIMMABLE-BOUNDARY-END(25769934875)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(21474967579)
                    this.ArmIntrinsicPerformsUnsignedOperationDiagId = "SYSLIB0055";
                    //--TRIMMABLE-BOUNDARY-END(21474967579)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(257698168859)
                    this.LoadFromHashAlgorithmMessage = "LoadFrom with a custom AssemblyHashAlgorithm is obsolete. Use overloads without an AssemblyHashAlgorithm.";
                    //--TRIMMABLE-BOUNDARY-END(257698168859)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(253403201563)
                    this.LoadFromHashAlgorithmDiagId = "SYSLIB0056";
                    //--TRIMMABLE-BOUNDARY-END(253403201563)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(515396206619)
                    this.X509CtorCertDataObsoleteMessage = "Loading certificate data through the constructor or Import is obsolete. Use X509CertificateLoader instead to load certificates.";
                    //--TRIMMABLE-BOUNDARY-END(515396206619)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(511101239323)
                    this.X509CtorCertDataObsoleteDiagId = "SYSLIB0057";
                    //--TRIMMABLE-BOUNDARY-END(511101239323)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(463856599067)
                    this.TlsCipherAlgorithmEnumsMessage = "KeyExchangeAlgorithm, KeyExchangeStrength, CipherAlgorithm, CipherStrength, HashAlgorithm and HashStrength properties of SslStream are obsolete. Use NegotiatedCipherSuite instead.";
                    //--TRIMMABLE-BOUNDARY-END(463856599067)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(459561631771)
                    this.TlsCipherAlgorithmEnumsDiagId = "SYSLIB0058";
                    //--TRIMMABLE-BOUNDARY-END(459561631771)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(425201893403)
                    this.SystemEventsEventsThreadShutdownMessage = "SystemEvents.EventsThreadShutdown callbacks are not run before the process exits. Use AppDomain.ProcessExit instead.";
                    //--TRIMMABLE-BOUNDARY-END(425201893403)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(420906926107)
                    this.SystemEventsEventsThreadShutdownDiagId = "SYSLIB0059";
                    //--TRIMMABLE-BOUNDARY-END(420906926107)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(343597514779)
                    this.Rfc2898DeriveBytesCtorMessage = "The constructors on Rfc2898DeriveBytes are obsolete. Use the static Pbkdf2 method instead.";
                    //--TRIMMABLE-BOUNDARY-END(343597514779)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(339302547483)
                    this.Rfc2898DeriveBytesCtorDiagId = "SYSLIB0060";
                    //--TRIMMABLE-BOUNDARY-END(339302547483)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(292057907227)
                    this.QueryableMinByMaxByTSourceObsoleteMessage = "The Queryable MinBy and MaxBy taking an IComparer<TSource> are obsolete. Use the new ones that take an IComparer<TKey>.";
                    //--TRIMMABLE-BOUNDARY-END(292057907227)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(287762939931)
                    this.QueryableMinByMaxByTSourceObsoleteDiagId = "SYSLIB0061";
                    //--TRIMMABLE-BOUNDARY-END(287762939931)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(532576075803)
                    this.XsltSettingsEnableScriptMessage = "XSLT Script blocks are not supported.";
                    //--TRIMMABLE-BOUNDARY-END(532576075803)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(528281108507)
                    this.XsltSettingsEnableScriptDiagId = "SYSLIB0062";
                    //--TRIMMABLE-BOUNDARY-END(528281108507)
                    
                }
            }
            //--TRIMMABLE-BOUNDARY-END(SINIT)
            
            static $h = 131099;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "l": [
//--TRIMMABLE-BOUNDARY-START(382252220443),
    {
      "t": 1310721,
      "n": "SharedUrlFormat",
      "d": 131099,
      "h": 382252220443,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(382252220443),
//--TRIMMABLE-BOUNDARY-START(433791827995),
    {
      "t": 1310721,
      "n": "SystemTextEncodingUTF7Message",
      "d": 131099,
      "h": 433791827995,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(433791827995),
//--TRIMMABLE-BOUNDARY-START(429496860699),
    {
      "t": 1310721,
      "n": "SystemTextEncodingUTF7DiagId",
      "d": 131099,
      "h": 429496860699,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(429496860699),
//--TRIMMABLE-BOUNDARY-START(266288103451),
    {
      "t": 1310721,
      "n": "PrincipalPermissionAttributeMessage",
      "d": 131099,
      "h": 266288103451,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(266288103451),
//--TRIMMABLE-BOUNDARY-START(261993136155),
    {
      "t": 1310721,
      "n": "PrincipalPermissionAttributeDiagId",
      "d": 131099,
      "h": 261993136155,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(261993136155),
//--TRIMMABLE-BOUNDARY-START(77309542427),
    {
      "t": 1310721,
      "n": "CodeAccessSecurityMessage",
      "d": 131099,
      "h": 77309542427,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(77309542427),
//--TRIMMABLE-BOUNDARY-START(73014575131),
    {
      "t": 1310721,
      "n": "CodeAccessSecurityDiagId",
      "d": 131099,
      "h": 73014575131,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(73014575131),
//--TRIMMABLE-BOUNDARY-START(94489411611),
    {
      "t": 1310721,
      "n": "ConstrainedExecutionRegionMessage",
      "d": 131099,
      "h": 94489411611,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(94489411611),
//--TRIMMABLE-BOUNDARY-START(90194444315),
    {
      "t": 1310721,
      "n": "ConstrainedExecutionRegionDiagId",
      "d": 131099,
      "h": 90194444315,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(90194444315),
//--TRIMMABLE-BOUNDARY-START(214748495899),
    {
      "t": 1310721,
      "n": "GlobalAssemblyCacheMessage",
      "d": 131099,
      "h": 214748495899,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(214748495899),
//--TRIMMABLE-BOUNDARY-START(210453528603),
    {
      "t": 1310721,
      "n": "GlobalAssemblyCacheDiagId",
      "d": 131099,
      "h": 210453528603,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(210453528603),
//--TRIMMABLE-BOUNDARY-START(442381762587),
    {
      "t": 1310721,
      "n": "ThreadAbortMessage",
      "d": 131099,
      "h": 442381762587,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(442381762587),
//--TRIMMABLE-BOUNDARY-START(446676729883),
    {
      "t": 1310721,
      "n": "ThreadResetAbortMessage",
      "d": 131099,
      "h": 446676729883,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(446676729883),
//--TRIMMABLE-BOUNDARY-START(438086795291),
    {
      "t": 1310721,
      "n": "ThreadAbortDiagId",
      "d": 131099,
      "h": 438086795291,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(438086795291),
//--TRIMMABLE-BOUNDARY-START(146029019163),
    {
      "t": 1310721,
      "n": "DefaultCryptoAlgorithmsMessage",
      "d": 131099,
      "h": 146029019163,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(146029019163),
//--TRIMMABLE-BOUNDARY-START(141734051867),
    {
      "t": 1310721,
      "n": "DefaultCryptoAlgorithmsDiagId",
      "d": 131099,
      "h": 141734051867,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(141734051867),
//--TRIMMABLE-BOUNDARY-START(120259215387),
    {
      "t": 1310721,
      "n": "CreatePdbGeneratorMessage",
      "d": 131099,
      "h": 120259215387,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(120259215387),
//--TRIMMABLE-BOUNDARY-START(115964248091),
    {
      "t": 1310721,
      "n": "CreatePdbGeneratorDiagId",
      "d": 131099,
      "h": 115964248091,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(115964248091),
//--TRIMMABLE-BOUNDARY-START(51539738651),
    {
      "t": 1310721,
      "n": "AuthenticationManagerMessage",
      "d": 131099,
      "h": 51539738651,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(51539738651),
//--TRIMMABLE-BOUNDARY-START(47244771355),
    {
      "t": 1310721,
      "n": "AuthenticationManagerDiagId",
      "d": 131099,
      "h": 47244771355,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(47244771355),
//--TRIMMABLE-BOUNDARY-START(326417645595),
    {
      "t": 1310721,
      "n": "RemotingApisMessage",
      "d": 131099,
      "h": 326417645595,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(326417645595),
//--TRIMMABLE-BOUNDARY-START(322122678299),
    {
      "t": 1310721,
      "n": "RemotingApisDiagId",
      "d": 131099,
      "h": 322122678299,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(322122678299),
//--TRIMMABLE-BOUNDARY-START(60129673243),
    {
      "t": 1310721,
      "n": "BinaryFormatterMessage",
      "d": 131099,
      "h": 60129673243,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(60129673243),
//--TRIMMABLE-BOUNDARY-START(55834705947),
    {
      "t": 1310721,
      "n": "BinaryFormatterDiagId",
      "d": 131099,
      "h": 55834705947,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(55834705947),
//--TRIMMABLE-BOUNDARY-START(85899477019),
    {
      "t": 1310721,
      "n": "CodeBaseMessage",
      "d": 131099,
      "h": 85899477019,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(85899477019),
//--TRIMMABLE-BOUNDARY-START(81604509723),
    {
      "t": 1310721,
      "n": "CodeBaseDiagId",
      "d": 131099,
      "h": 81604509723,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(81604509723),
//--TRIMMABLE-BOUNDARY-START(197568626715),
    {
      "t": 1310721,
      "n": "EscapeUriStringMessage",
      "d": 131099,
      "h": 197568626715,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(197568626715),
//--TRIMMABLE-BOUNDARY-START(193273659419),
    {
      "t": 1310721,
      "n": "EscapeUriStringDiagId",
      "d": 131099,
      "h": 193273659419,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(193273659419),
//--TRIMMABLE-BOUNDARY-START(489626402843),
    {
      "t": 1310721,
      "n": "WebRequestMessage",
      "d": 131099,
      "h": 489626402843,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(489626402843),
//--TRIMMABLE-BOUNDARY-START(485331435547),
    {
      "t": 1310721,
      "n": "WebRequestDiagId",
      "d": 131099,
      "h": 485331435547,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(485331435547),
//--TRIMMABLE-BOUNDARY-START(163208888347),
    {
      "t": 1310721,
      "n": "DisablePrivateReflectionAttributeMessage",
      "d": 131099,
      "h": 163208888347,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(163208888347),
//--TRIMMABLE-BOUNDARY-START(158913921051),
    {
      "t": 1310721,
      "n": "DisablePrivateReflectionAttributeDiagId",
      "d": 131099,
      "h": 158913921051,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(158913921051),
//--TRIMMABLE-BOUNDARY-START(206158561307),
    {
      "t": 1310721,
      "n": "GetContextInfoMessage",
      "d": 131099,
      "h": 206158561307,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(206158561307),
//--TRIMMABLE-BOUNDARY-START(201863594011),
    {
      "t": 1310721,
      "n": "GetContextInfoDiagId",
      "d": 131099,
      "h": 201863594011,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(201863594011),
//--TRIMMABLE-BOUNDARY-START(399432089627),
    {
      "t": 1310721,
      "n": "StrongNameKeyPairMessage",
      "d": 131099,
      "h": 399432089627,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(399432089627),
//--TRIMMABLE-BOUNDARY-START(395137122331),
    {
      "t": 1310721,
      "n": "StrongNameKeyPairDiagId",
      "d": 131099,
      "h": 395137122331,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(395137122331),
//--TRIMMABLE-BOUNDARY-START(300647841819),
    {
      "t": 1310721,
      "n": "ReflectionOnlyLoadingMessage",
      "d": 131099,
      "h": 300647841819,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(300647841819),
//--TRIMMABLE-BOUNDARY-START(296352874523),
    {
      "t": 1310721,
      "n": "ReflectionOnlyLoadingDiagId",
      "d": 131099,
      "h": 296352874523,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(296352874523),
//--TRIMMABLE-BOUNDARY-START(377957253147),
    {
      "t": 1310721,
      "n": "RuntimeEnvironmentMessage",
      "d": 131099,
      "h": 377957253147,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(377957253147),
//--TRIMMABLE-BOUNDARY-START(373662285851),
    {
      "t": 1310721,
      "n": "RuntimeEnvironmentDiagId",
      "d": 131099,
      "h": 373662285851,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(373662285851),
//--TRIMMABLE-BOUNDARY-START(231928365083),
    {
      "t": 1310721,
      "n": "JsonSerializerOptionsIgnoreNullValuesMessage",
      "d": 131099,
      "h": 231928365083,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(231928365083),
//--TRIMMABLE-BOUNDARY-START(227633397787),
    {
      "t": 1310721,
      "n": "JsonSerializerOptionsIgnoreNullValuesDiagId",
      "d": 131099,
      "h": 227633397787,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(227633397787),
//--TRIMMABLE-BOUNDARY-START(154618953755),
    {
      "t": 1310721,
      "n": "DerivedCryptographicTypesMessage",
      "d": 131099,
      "h": 154618953755,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(154618953755),
//--TRIMMABLE-BOUNDARY-START(150323986459),
    {
      "t": 1310721,
      "n": "DerivedCryptographicTypesDiagId",
      "d": 131099,
      "h": 150323986459,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(150323986459),
//--TRIMMABLE-BOUNDARY-START(352187449371),
    {
      "t": 1310721,
      "n": "RijndaelMessage",
      "d": 131099,
      "h": 352187449371,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(352187449371),
//--TRIMMABLE-BOUNDARY-START(347892482075),
    {
      "t": 1310721,
      "n": "RijndaelDiagId",
      "d": 131099,
      "h": 347892482075,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(347892482075),
//--TRIMMABLE-BOUNDARY-START(360777383963),
    {
      "t": 1310721,
      "n": "RNGCryptoServiceProviderMessage",
      "d": 131099,
      "h": 360777383963,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(360777383963),
//--TRIMMABLE-BOUNDARY-START(356482416667),
    {
      "t": 1310721,
      "n": "RNGCryptoServiceProviderDiagId",
      "d": 131099,
      "h": 356482416667,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(356482416667),
//--TRIMMABLE-BOUNDARY-START(17180000283),
    {
      "t": 1310721,
      "n": "AppDomainCreateUnloadMessage",
      "d": 131099,
      "h": 17180000283,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(17180000283),
//--TRIMMABLE-BOUNDARY-START(12885032987),
    {
      "t": 1310721,
      "n": "AppDomainCreateUnloadDiagId",
      "d": 131099,
      "h": 12885032987,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(12885032987),
//--TRIMMABLE-BOUNDARY-START(408022024219),
    {
      "t": 1310721,
      "n": "SuppressIldasmAttributeMessage",
      "d": 131099,
      "h": 408022024219,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(408022024219),
//--TRIMMABLE-BOUNDARY-START(403727056923),
    {
      "t": 1310721,
      "n": "SuppressIldasmAttributeDiagId",
      "d": 131099,
      "h": 403727056923,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(403727056923),
//--TRIMMABLE-BOUNDARY-START(498216337435),
    {
      "t": 1310721,
      "n": "X509CertificateImmutableMessage",
      "d": 131099,
      "h": 498216337435,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(498216337435),
//--TRIMMABLE-BOUNDARY-START(493921370139),
    {
      "t": 1310721,
      "n": "X509CertificateImmutableDiagId",
      "d": 131099,
      "h": 493921370139,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(493921370139),
//--TRIMMABLE-BOUNDARY-START(283467972635),
    {
      "t": 1310721,
      "n": "PublicKeyPropertyMessage",
      "d": 131099,
      "h": 283467972635,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(283467972635),
//--TRIMMABLE-BOUNDARY-START(279173005339),
    {
      "t": 1310721,
      "n": "PublicKeyPropertyDiagId",
      "d": 131099,
      "h": 279173005339,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(279173005339),
//--TRIMMABLE-BOUNDARY-START(506806272027),
    {
      "t": 1310721,
      "n": "X509CertificatePrivateKeyMessage",
      "d": 131099,
      "h": 506806272027,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(506806272027),
//--TRIMMABLE-BOUNDARY-START(502511304731),
    {
      "t": 1310721,
      "n": "X509CertificatePrivateKeyDiagId",
      "d": 131099,
      "h": 502511304731,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(502511304731),
//--TRIMMABLE-BOUNDARY-START(274878038043),
    {
      "t": 1310721,
      "n": "ProduceLegacyHmacValuesMessage",
      "d": 131099,
      "h": 274878038043,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(274878038043),
//--TRIMMABLE-BOUNDARY-START(270583070747),
    {
      "t": 1310721,
      "n": "ProduceLegacyHmacValuesDiagId",
      "d": 131099,
      "h": 270583070747,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(270583070747),
//--TRIMMABLE-BOUNDARY-START(481036468251),
    {
      "t": 1310721,
      "n": "UseManagedSha1Message",
      "d": 131099,
      "h": 481036468251,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(481036468251),
//--TRIMMABLE-BOUNDARY-START(476741500955),
    {
      "t": 1310721,
      "n": "UseManagedSha1DiagId",
      "d": 131099,
      "h": 476741500955,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(476741500955),
//--TRIMMABLE-BOUNDARY-START(128849149979),
    {
      "t": 1310721,
      "n": "CryptoConfigEncodeOIDMessage",
      "d": 131099,
      "h": 128849149979,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(128849149979),
//--TRIMMABLE-BOUNDARY-START(124554182683),
    {
      "t": 1310721,
      "n": "CryptoConfigEncodeOIDDiagId",
      "d": 131099,
      "h": 124554182683,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(124554182683),
//--TRIMMABLE-BOUNDARY-START(111669280795),
    {
      "t": 1310721,
      "n": "CorruptedStateRecoveryMessage",
      "d": 131099,
      "h": 111669280795,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(111669280795),
//--TRIMMABLE-BOUNDARY-START(107374313499),
    {
      "t": 1310721,
      "n": "CorruptedStateRecoveryDiagId",
      "d": 131099,
      "h": 107374313499,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(107374313499),
//--TRIMMABLE-BOUNDARY-START(335007580187),
    {
      "t": 1310721,
      "n": "Rfc2898CryptDeriveKeyMessage",
      "d": 131099,
      "h": 335007580187,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(335007580187),
//--TRIMMABLE-BOUNDARY-START(330712612891),
    {
      "t": 1310721,
      "n": "Rfc2898CryptDeriveKeyDiagId",
      "d": 131099,
      "h": 330712612891,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(330712612891),
//--TRIMMABLE-BOUNDARY-START(68719607835),
    {
      "t": 1310721,
      "n": "CmsSignerCspParamsCtorMessage",
      "d": 131099,
      "h": 68719607835,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(68719607835),
//--TRIMMABLE-BOUNDARY-START(64424640539),
    {
      "t": 1310721,
      "n": "CmsSignerCspParamsCtorDiagId",
      "d": 131099,
      "h": 64424640539,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(64424640539),
//--TRIMMABLE-BOUNDARY-START(390842155035),
    {
      "t": 1310721,
      "n": "SignerInfoCounterSigMessage",
      "d": 131099,
      "h": 390842155035,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(390842155035),
//--TRIMMABLE-BOUNDARY-START(386547187739),
    {
      "t": 1310721,
      "n": "SignerInfoCounterSigDiagId",
      "d": 131099,
      "h": 386547187739,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(386547187739),
//--TRIMMABLE-BOUNDARY-START(309237776411),
    {
      "t": 1310721,
      "n": "RegexCompileToAssemblyMessage",
      "d": 131099,
      "h": 309237776411,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(309237776411),
//--TRIMMABLE-BOUNDARY-START(304942809115),
    {
      "t": 1310721,
      "n": "RegexCompileToAssemblyDiagId",
      "d": 131099,
      "h": 304942809115,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(304942809115),
//--TRIMMABLE-BOUNDARY-START(42949804059),
    {
      "t": 1310721,
      "n": "AssemblyNameMembersMessage",
      "d": 131099,
      "h": 42949804059,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(42949804059),
//--TRIMMABLE-BOUNDARY-START(38654836763),
    {
      "t": 1310721,
      "n": "AssemblyNameMembersDiagId",
      "d": 131099,
      "h": 38654836763,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(38654836763),
//--TRIMMABLE-BOUNDARY-START(416611958811),
    {
      "t": 1310721,
      "n": "SystemDataSerializationFormatBinaryMessage",
      "d": 131099,
      "h": 416611958811,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(416611958811),
//--TRIMMABLE-BOUNDARY-START(412316991515),
    {
      "t": 1310721,
      "n": "SystemDataSerializationFormatBinaryDiagId",
      "d": 131099,
      "h": 412316991515,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(412316991515),
//--TRIMMABLE-BOUNDARY-START(472446533659),
    {
      "t": 1310721,
      "n": "TlsVersion10and11Message",
      "d": 131099,
      "h": 472446533659,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(472446533659),
//--TRIMMABLE-BOUNDARY-START(468151566363),
    {
      "t": 1310721,
      "n": "TlsVersion10and11DiagId",
      "d": 131099,
      "h": 468151566363,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(468151566363),
//--TRIMMABLE-BOUNDARY-START(188978692123),
    {
      "t": 1310721,
      "n": "EncryptionPolicyMessage",
      "d": 131099,
      "h": 188978692123,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(188978692123),
//--TRIMMABLE-BOUNDARY-START(184683724827),
    {
      "t": 1310721,
      "n": "EncryptionPolicyDiagId",
      "d": 131099,
      "h": 184683724827,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(184683724827),
//--TRIMMABLE-BOUNDARY-START(171798822939),
    {
      "t": 1310721,
      "n": "EccXmlExportImportMessage",
      "d": 131099,
      "h": 171798822939,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(171798822939),
//--TRIMMABLE-BOUNDARY-START(167503855643),
    {
      "t": 1310721,
      "n": "EccXmlExportImportDiagId",
      "d": 131099,
      "h": 167503855643,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(167503855643),
//--TRIMMABLE-BOUNDARY-START(180388757531),
    {
      "t": 1310721,
      "n": "EcDhPublicKeyBlobMessage",
      "d": 131099,
      "h": 180388757531,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(180388757531),
//--TRIMMABLE-BOUNDARY-START(176093790235),
    {
      "t": 1310721,
      "n": "EcDhPublicKeyBlobDiagId",
      "d": 131099,
      "h": 176093790235,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(176093790235),
//--TRIMMABLE-BOUNDARY-START(34359869467),
    {
      "t": 1310721,
      "n": "AssemblyNameCodeBaseMessage",
      "d": 131099,
      "h": 34359869467,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(34359869467),
//--TRIMMABLE-BOUNDARY-START(30064902171),
    {
      "t": 1310721,
      "n": "AssemblyNameCodeBaseDiagId",
      "d": 131099,
      "h": 30064902171,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(30064902171),
//--TRIMMABLE-BOUNDARY-START(137439084571),
    {
      "t": 1310721,
      "n": "CryptoStringFactoryMessage",
      "d": 131099,
      "h": 137439084571,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(137439084571),
//--TRIMMABLE-BOUNDARY-START(133144117275),
    {
      "t": 1310721,
      "n": "CryptoStringFactoryDiagId",
      "d": 131099,
      "h": 133144117275,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(133144117275),
//--TRIMMABLE-BOUNDARY-START(103079346203),
    {
      "t": 1310721,
      "n": "ControlledExecutionRunMessage",
      "d": 131099,
      "h": 103079346203,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(103079346203),
//--TRIMMABLE-BOUNDARY-START(98784378907),
    {
      "t": 1310721,
      "n": "ControlledExecutionRunDiagId",
      "d": 131099,
      "h": 98784378907,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(98784378907),
//--TRIMMABLE-BOUNDARY-START(523986141211),
    {
      "t": 1310721,
      "n": "XmlSecureResolverMessage",
      "d": 131099,
      "h": 523986141211,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(523986141211),
//--TRIMMABLE-BOUNDARY-START(519691173915),
    {
      "t": 1310721,
      "n": "XmlSecureResolverDiagId",
      "d": 131099,
      "h": 519691173915,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(519691173915),
//--TRIMMABLE-BOUNDARY-START(369367318555),
    {
      "t": 1310721,
      "n": "RsaEncryptDecryptValueMessage",
      "d": 131099,
      "h": 369367318555,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(369367318555),
//--TRIMMABLE-BOUNDARY-START(365072351259),
    {
      "t": 1310721,
      "n": "RsaEncryptDecryptDiagId",
      "d": 131099,
      "h": 365072351259,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(365072351259),
//--TRIMMABLE-BOUNDARY-START(223338430491),
    {
      "t": 1310721,
      "n": "JsonSerializerOptionsAddContextMessage",
      "d": 131099,
      "h": 223338430491,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(223338430491),
//--TRIMMABLE-BOUNDARY-START(219043463195),
    {
      "t": 1310721,
      "n": "JsonSerializerOptionsAddContextDiagId",
      "d": 131099,
      "h": 219043463195,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(219043463195),
//--TRIMMABLE-BOUNDARY-START(249108234267),
    {
      "t": 1310721,
      "n": "LegacyFormatterMessage",
      "d": 131099,
      "h": 249108234267,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(249108234267),
//--TRIMMABLE-BOUNDARY-START(236223332379),
    {
      "t": 1310721,
      "n": "LegacyFormatterDiagId",
      "d": 131099,
      "h": 236223332379,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(236223332379),
//--TRIMMABLE-BOUNDARY-START(244813266971),
    {
      "t": 1310721,
      "n": "LegacyFormatterImplMessage",
      "d": 131099,
      "h": 244813266971,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(244813266971),
//--TRIMMABLE-BOUNDARY-START(240518299675),
    {
      "t": 1310721,
      "n": "LegacyFormatterImplDiagId",
      "d": 131099,
      "h": 240518299675,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(240518299675),
//--TRIMMABLE-BOUNDARY-START(317827711003),
    {
      "t": 1310721,
      "n": "RegexExtensibilityImplMessage",
      "d": 131099,
      "h": 317827711003,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(317827711003),
//--TRIMMABLE-BOUNDARY-START(313532743707),
    {
      "t": 1310721,
      "n": "RegexExtensibilityDiagId",
      "d": 131099,
      "h": 313532743707,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(313532743707),
//--TRIMMABLE-BOUNDARY-START(8590065691),
    {
      "t": 1310721,
      "n": "AesGcmTagConstructorMessage",
      "d": 131099,
      "h": 8590065691,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(8590065691),
//--TRIMMABLE-BOUNDARY-START(4295098395),
    {
      "t": 1310721,
      "n": "AesGcmTagConstructorDiagId",
      "d": 131099,
      "h": 4295098395,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(4295098395),
//--TRIMMABLE-BOUNDARY-START(455266664475),
    {
      "t": 1310721,
      "n": "ThreadVolatileReadWriteMessage",
      "d": 131099,
      "h": 455266664475,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(455266664475),
//--TRIMMABLE-BOUNDARY-START(450971697179),
    {
      "t": 1310721,
      "n": "ThreadVolatileReadWriteDiagId",
      "d": 131099,
      "h": 450971697179,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(450971697179),
//--TRIMMABLE-BOUNDARY-START(25769934875),
    {
      "t": 1310721,
      "n": "ArmIntrinsicPerformsUnsignedOperationMessage",
      "d": 131099,
      "h": 25769934875,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(25769934875),
//--TRIMMABLE-BOUNDARY-START(21474967579),
    {
      "t": 1310721,
      "n": "ArmIntrinsicPerformsUnsignedOperationDiagId",
      "d": 131099,
      "h": 21474967579,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(21474967579),
//--TRIMMABLE-BOUNDARY-START(257698168859),
    {
      "t": 1310721,
      "n": "LoadFromHashAlgorithmMessage",
      "d": 131099,
      "h": 257698168859,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(257698168859),
//--TRIMMABLE-BOUNDARY-START(253403201563),
    {
      "t": 1310721,
      "n": "LoadFromHashAlgorithmDiagId",
      "d": 131099,
      "h": 253403201563,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(253403201563),
//--TRIMMABLE-BOUNDARY-START(515396206619),
    {
      "t": 1310721,
      "n": "X509CtorCertDataObsoleteMessage",
      "d": 131099,
      "h": 515396206619,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(515396206619),
//--TRIMMABLE-BOUNDARY-START(511101239323),
    {
      "t": 1310721,
      "n": "X509CtorCertDataObsoleteDiagId",
      "d": 131099,
      "h": 511101239323,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(511101239323),
//--TRIMMABLE-BOUNDARY-START(463856599067),
    {
      "t": 1310721,
      "n": "TlsCipherAlgorithmEnumsMessage",
      "d": 131099,
      "h": 463856599067,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(463856599067),
//--TRIMMABLE-BOUNDARY-START(459561631771),
    {
      "t": 1310721,
      "n": "TlsCipherAlgorithmEnumsDiagId",
      "d": 131099,
      "h": 459561631771,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(459561631771),
//--TRIMMABLE-BOUNDARY-START(425201893403),
    {
      "t": 1310721,
      "n": "SystemEventsEventsThreadShutdownMessage",
      "d": 131099,
      "h": 425201893403,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(425201893403),
//--TRIMMABLE-BOUNDARY-START(420906926107),
    {
      "t": 1310721,
      "n": "SystemEventsEventsThreadShutdownDiagId",
      "d": 131099,
      "h": 420906926107,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(420906926107),
//--TRIMMABLE-BOUNDARY-START(343597514779),
    {
      "t": 1310721,
      "n": "Rfc2898DeriveBytesCtorMessage",
      "d": 131099,
      "h": 343597514779,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(343597514779),
//--TRIMMABLE-BOUNDARY-START(339302547483),
    {
      "t": 1310721,
      "n": "Rfc2898DeriveBytesCtorDiagId",
      "d": 131099,
      "h": 339302547483,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(339302547483),
//--TRIMMABLE-BOUNDARY-START(292057907227),
    {
      "t": 1310721,
      "n": "QueryableMinByMaxByTSourceObsoleteMessage",
      "d": 131099,
      "h": 292057907227,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(292057907227),
//--TRIMMABLE-BOUNDARY-START(287762939931),
    {
      "t": 1310721,
      "n": "QueryableMinByMaxByTSourceObsoleteDiagId",
      "d": 131099,
      "h": 287762939931,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(287762939931),
//--TRIMMABLE-BOUNDARY-START(532576075803),
    {
      "t": 1310721,
      "n": "XsltSettingsEnableScriptMessage",
      "d": 131099,
      "h": 532576075803,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(532576075803),
//--TRIMMABLE-BOUNDARY-START(528281108507),
    {
      "t": 1310721,
      "n": "XsltSettingsEnableScriptDiagId",
      "d": 131099,
      "h": 528281108507,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(528281108507)
  ],
  "h": 131099
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `System.Obsoletions`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `System${separator}Obsoletions`; }
        });
        //--TRIMMABLE-BOUNDARY-END(131099)
        
        

        //--TRIMMABLE-BOUNDARY-START(2424859)
        $asm.$cls(`$srsf.S.SR`, ($self) => class SR
        {
            //--TRIMMABLE-BOUNDARY-START(846110982171)
            /*bool*/ static s_usingResourceKeys = false;
            //--TRIMMABLE-BOUNDARY-END(846110982171)
            
            //--TRIMMABLE-BOUNDARY-START(824636145691)
            static /*bool */ GetUsingResourceKeysSwitchValue()
            {
                {
                    /*bool*/ let usingResourceKeys;
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(824636145691);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return $.$$.S.AppContext.TryGetSwitch("System.Resources.UseSystemResourceKeys", $.$ref(() => usingResourceKeys, ($v) => usingResourceKeys = $v, $.$$.S.Boolean)) ? usingResourceKeys : false;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(824636145691)
            
            //--TRIMMABLE-BOUNDARY-START(1090924118043)
            static /*bool */ UsingResourceKeys()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(1090924118043);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return $.$srsf.S.SR.s_usingResourceKeys;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(1090924118043)
            
            //--TRIMMABLE-BOUNDARY-START(820341178395)
            static /*string */ GetResourceString$1(/*string*/ resourceKey)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(820341178395);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$srsf.S.SR.UsingResourceKeys())
                {
                    return resourceKey;
                }
                /*string?*/ let resourceString = null;
                try
                {
                    resourceString = $.$srsf.S.SR.ResourceManager.GetString$1(resourceKey);
                }
                catch($e)
                {
                }
                return resourceString;
            }
            //--TRIMMABLE-BOUNDARY-END(820341178395)
            
            //--TRIMMABLE-BOUNDARY-START(816046211099)
            static /*string */ GetResourceString(/*string*/ resourceKey, /*string*/ defaultString)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(816046211099);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*string*/ let resourceString = $.$srsf.S.SR.GetResourceString$1(resourceKey);
                return resourceKey === resourceString || resourceString === null ? defaultString : resourceString;
            }
            //--TRIMMABLE-BOUNDARY-END(816046211099)
            
            //--TRIMMABLE-BOUNDARY-START(85901770779)
            static /*string */ Format$6(/*string*/ resourceFormat, /*object?*/ p1)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(85901770779);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$srsf.S.SR.UsingResourceKeys())
                {
                    return $.$$.S.String.Join$7(", ", $.$$.S.ReadOnlySpan$$($.$$.S.Object).op_Implicit$1([ resourceFormat, p1 ]));
                }
                return $.$$.S.String.Format$9(resourceFormat, p1);
            }
            //--TRIMMABLE-BOUNDARY-END(85901770779)
            
            //--TRIMMABLE-BOUNDARY-START(81606803483)
            static /*string */ Format$5(/*string*/ resourceFormat, /*object?*/ p1, /*object?*/ p2)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(81606803483);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$srsf.S.SR.UsingResourceKeys())
                {
                    return $.$$.S.String.Join$7(", ", $.$$.S.ReadOnlySpan$$($.$$.S.Object).op_Implicit$1([ resourceFormat, p1, p2 ]));
                }
                return $.$$.S.String.Format$8(resourceFormat, p1, p2);
            }
            //--TRIMMABLE-BOUNDARY-END(81606803483)
            
            //--TRIMMABLE-BOUNDARY-START(77311836187)
            static /*string */ Format$4(/*string*/ resourceFormat, /*object?*/ p1, /*object?*/ p2, /*object?*/ p3)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(77311836187);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$srsf.S.SR.UsingResourceKeys())
                {
                    return $.$$.S.String.Join$7(", ", $.$$.S.ReadOnlySpan$$($.$$.S.Object).op_Implicit$1([ resourceFormat, p1, p2, p3 ]));
                }
                return $.$$.S.String.Format$7(resourceFormat, p1, p2, p3);
            }
            //--TRIMMABLE-BOUNDARY-END(77311836187)
            
            //--TRIMMABLE-BOUNDARY-START(90196738075)
            static /*string */ Format$7(/*string*/ resourceFormat, /*params object?[]?*/ args)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(90196738075);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (args !== null)
                {
                    if ($.$srsf.S.SR.UsingResourceKeys())
                    {
                        return $.$strNN(resourceFormat) + ", " + $.$strNN($.$$.S.String.Join$6(", ", args));
                    }
                    return $.$$.S.String.Format$10(resourceFormat, args);
                }
                return resourceFormat;
            }
            //--TRIMMABLE-BOUNDARY-END(90196738075)
            
            //--TRIMMABLE-BOUNDARY-START(68721901595)
            static /*string */ Format$2(/*IFormatProvider?*/ provider, /*string*/ resourceFormat, /*object?*/ p1)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(68721901595);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$srsf.S.SR.UsingResourceKeys())
                {
                    return $.$$.S.String.Join$7(", ", $.$$.S.ReadOnlySpan$$($.$$.S.Object).op_Implicit$1([ resourceFormat, p1 ]));
                }
                return $.$$.S.String.Format$4(provider, resourceFormat, p1);
            }
            //--TRIMMABLE-BOUNDARY-END(68721901595)
            
            //--TRIMMABLE-BOUNDARY-START(64426934299)
            static /*string */ Format$1(/*IFormatProvider?*/ provider, /*string*/ resourceFormat, /*object?*/ p1, /*object?*/ p2)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(64426934299);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$srsf.S.SR.UsingResourceKeys())
                {
                    return $.$$.S.String.Join$7(", ", $.$$.S.ReadOnlySpan$$($.$$.S.Object).op_Implicit$1([ resourceFormat, p1, p2 ]));
                }
                return $.$$.S.String.Format$3(provider, resourceFormat, p1, p2);
            }
            //--TRIMMABLE-BOUNDARY-END(64426934299)
            
            //--TRIMMABLE-BOUNDARY-START(60131967003)
            static /*string */ Format(/*IFormatProvider?*/ provider, /*string*/ resourceFormat, /*object?*/ p1, /*object?*/ p2, /*object?*/ p3)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(60131967003);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$srsf.S.SR.UsingResourceKeys())
                {
                    return $.$$.S.String.Join$7(", ", $.$$.S.ReadOnlySpan$$($.$$.S.Object).op_Implicit$1([ resourceFormat, p1, p2, p3 ]));
                }
                return $.$$.S.String.Format$2(provider, resourceFormat, p1, p2, p3);
            }
            //--TRIMMABLE-BOUNDARY-END(60131967003)
            
            //--TRIMMABLE-BOUNDARY-START(73016868891)
            static /*string */ Format$3(/*IFormatProvider?*/ provider, /*string*/ resourceFormat, /*params object?[]?*/ args)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(73016868891);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (args !== null)
                {
                    if ($.$srsf.S.SR.UsingResourceKeys())
                    {
                        return $.$strNN(resourceFormat) + ", " + $.$strNN($.$$.S.String.Join$6(", ", args));
                    }
                    return $.$$.S.String.Format$5(provider, resourceFormat, args);
                }
                return resourceFormat;
            }
            //--TRIMMABLE-BOUNDARY-END(73016868891)
            
            //--TRIMMABLE-BOUNDARY-START(841816014875)
            /*global::System.Resources.ResourceManager*/ static s_resourceManager = null;
            //--TRIMMABLE-BOUNDARY-END(841816014875)
            
            //--TRIMMABLE-BOUNDARY-START(833226080283)
            /*global::System.Globalization.CultureInfo*/ static resourceCulture = null;
            //--TRIMMABLE-BOUNDARY-END(833226080283)
            
            //--TRIMMABLE-BOUNDARY-START(837521047579)
            static /*global::System.Resources.ResourceManager */ get ResourceManager()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(347894775835);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$$.S.Object.ReferenceEquals($.$srsf.S.SR.s_resourceManager, null))
                {
                    /*global::System.Resources.ResourceManager*/ let temp = new $.$$.SR$1.ResourceManager().$ctor$3("System.Runtime.Serialization.Formatters", $.$srsf.S.SR.$type.Assembly);
                    $.$srsf.S.SR.s_resourceManager = temp;
                }
                return $.$srsf.S.SR.s_resourceManager;
            }
            //--TRIMMABLE-BOUNDARY-END(837521047579)
            
            //--TRIMMABLE-BOUNDARY-START(55836999707)
            static /*global::System.Globalization.CultureInfo */ get Culture()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(330714906651);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$srsf.S.SR.resourceCulture;
            }
            static /*global::System.Globalization.CultureInfo */ set Culture(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(1086629150747);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$srsf.S.SR.resourceCulture = value;
            }
            //--TRIMMABLE-BOUNDARY-END(55836999707)
            
            //--TRIMMABLE-BOUNDARY-START(8592359451)
            static /*string */ get Arg_HTCapacityOverflow()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(236225626139);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "Hashtable's capacity overflowed and went negative. Check load factor, capacity and the current size of the table.";
            }
            //--TRIMMABLE-BOUNDARY-END(8592359451)
            
            //--TRIMMABLE-BOUNDARY-START(957780131867)
            static /*string */ get Serialization_NonSerType()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(571233075227);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "Type '{0}' in Assembly '{1}' is not marked as serializable.";
            }
            //--TRIMMABLE-BOUNDARY-END(957780131867)
            
            //--TRIMMABLE-BOUNDARY-START(171801116699)
            static /*string */ FormatSerialization_NonSerType(/*object*/ arg1, /*object*/ arg2)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(171801116699);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$$.S.String.Format$8("Type '{0}' in Assembly '{1}' is not marked as serializable.", arg1, arg2);
            }
            //--TRIMMABLE-BOUNDARY-END(171801116699)
            
            //--TRIMMABLE-BOUNDARY-START(12887326747)
            static /*string */ get Argument_DataLengthDifferent()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(244815560731);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "Parameters 'members' and 'data' must have the same length.";
            }
            //--TRIMMABLE-BOUNDARY-END(12887326747)
            
            //--TRIMMABLE-BOUNDARY-START(34362163227)
            static /*string */ get ArgumentNull_NullMember()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(287765233691);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "Member at position {0} was null.";
            }
            //--TRIMMABLE-BOUNDARY-END(34362163227)
            
            //--TRIMMABLE-BOUNDARY-START(94491705371)
            static /*string */ FormatArgumentNull_NullMember(/*object*/ arg1)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(94491705371);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$$.S.String.Format$9("Member at position {0} was null.", arg1);
            }
            //--TRIMMABLE-BOUNDARY-END(94491705371)
            
            //--TRIMMABLE-BOUNDARY-START(1069449281563)
            static /*string */ get Serialization_UnknownMemberInfo()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(794571374619);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "Only FieldInfo, PropertyInfo, and SerializationMemberInfo are recognized.";
            }
            //--TRIMMABLE-BOUNDARY-END(1069449281563)
            
            //--TRIMMABLE-BOUNDARY-START(949190197275)
            static /*string */ get Serialization_NoID()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(554053206043);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "Object has never been assigned an objectID.";
            }
            //--TRIMMABLE-BOUNDARY-END(949190197275)
            
            //--TRIMMABLE-BOUNDARY-START(1022204641307)
            static /*string */ get Serialization_TooManyElements()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(700082094107);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "The internal array cannot expand to greater than Int32.MaxValue elements.";
            }
            //--TRIMMABLE-BOUNDARY-END(1022204641307)
            
            //--TRIMMABLE-BOUNDARY-START(17182294043)
            static /*string */ get Argument_InvalidFieldInfo()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(253405495323);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "The FieldInfo object is not valid.";
            }
            //--TRIMMABLE-BOUNDARY-END(17182294043)
            
            //--TRIMMABLE-BOUNDARY-START(944895229979)
            static /*string */ get Serialization_NeverSeen()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(545463271451);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "A fixup is registered to the object with ID {0}, but the object does not appear in the graph.";
            }
            //--TRIMMABLE-BOUNDARY-END(944895229979)
            
            //--TRIMMABLE-BOUNDARY-START(163211182107)
            static /*string */ FormatSerialization_NeverSeen(/*object*/ arg1)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(163211182107);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$$.S.String.Format$9("A fixup is registered to the object with ID {0}, but the object does not appear in the graph.", arg1);
            }
            //--TRIMMABLE-BOUNDARY-END(163211182107)
            
            //--TRIMMABLE-BOUNDARY-START(914830458907)
            static /*string */ get Serialization_IORIncomplete()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(485333729307);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "The object with ID {0} implements the IObjectReference interface for which all dependencies cannot be resolved. The likely cause is two instances of IObjectReference that have a mutual dependency on each other.";
            }
            //--TRIMMABLE-BOUNDARY-END(914830458907)
            
            //--TRIMMABLE-BOUNDARY-START(137441378331)
            static /*string */ FormatSerialization_IORIncomplete(/*object*/ arg1)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(137441378331);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$$.S.String.Format$9("The object with ID {0} implements the IObjectReference interface for which all dependencies cannot be resolved. The likely cause is two instances of IObjectReference that have a mutual dependency on each other.", arg1);
            }
            //--TRIMMABLE-BOUNDARY-END(137441378331)
            
            //--TRIMMABLE-BOUNDARY-START(970665033755)
            static /*string */ get Serialization_ObjectNotSupplied()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(597002879003);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "The object with ID {0} was referenced in a fixup but does not exist.";
            }
            //--TRIMMABLE-BOUNDARY-END(970665033755)
            
            //--TRIMMABLE-BOUNDARY-START(180391051291)
            static /*string */ FormatSerialization_ObjectNotSupplied(/*object*/ arg1)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(180391051291);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$$.S.String.Format$9("The object with ID {0} was referenced in a fixup but does not exist.", arg1);
            }
            //--TRIMMABLE-BOUNDARY-END(180391051291)
            
            //--TRIMMABLE-BOUNDARY-START(962075099163)
            static /*string */ get Serialization_NotCyclicallyReferenceableSurrogate()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(579823009819);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "{0}.SetObjectData returns a value that is neither null nor equal to the first parameter. Such Surrogates cannot be part of cyclical reference.";
            }
            //--TRIMMABLE-BOUNDARY-END(962075099163)
            
            //--TRIMMABLE-BOUNDARY-START(176096083995)
            static /*string */ FormatSerialization_NotCyclicallyReferenceableSurrogate(/*object*/ arg1)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(176096083995);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$$.S.String.Format$9("{0}.SetObjectData returns a value that is neither null nor equal to the first parameter. Such Surrogates cannot be part of cyclical reference.", arg1);
            }
            //--TRIMMABLE-BOUNDARY-END(176096083995)
            
            //--TRIMMABLE-BOUNDARY-START(1026499608603)
            static /*string */ get Serialization_TooManyReferences()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(708672028699);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "The implementation of the IObjectReference interface returns too many nested references to other objects that implement IObjectReference.";
            }
            //--TRIMMABLE-BOUNDARY-END(1026499608603)
            
            //--TRIMMABLE-BOUNDARY-START(940600262683)
            static /*string */ get Serialization_MissingObject()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(536873336859);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "The object with ID {0} was referenced in a fixup but has not been registered.";
            }
            //--TRIMMABLE-BOUNDARY-END(940600262683)
            
            //--TRIMMABLE-BOUNDARY-START(158916214811)
            static /*string */ FormatSerialization_MissingObject(/*object*/ arg1)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(158916214811);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$$.S.String.Format$9("The object with ID {0} was referenced in a fixup but has not been registered.", arg1);
            }
            //--TRIMMABLE-BOUNDARY-END(158916214811)
            
            //--TRIMMABLE-BOUNDARY-START(897650589723)
            static /*string */ get Serialization_InvalidFixupDiscovered()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(450973990939);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "A fixup on an object implementing ISerializable or having a surrogate was discovered for an object which does not have a SerializationInfo available.";
            }
            //--TRIMMABLE-BOUNDARY-END(897650589723)
            
            //--TRIMMABLE-BOUNDARY-START(1047974445083)
            static /*string */ get Serialization_TypeLoadFailure()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(751621701659);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "Unable to load type {0} required for deserialization.";
            }
            //--TRIMMABLE-BOUNDARY-END(1047974445083)
            
            //--TRIMMABLE-BOUNDARY-START(210455822363)
            static /*string */ FormatSerialization_TypeLoadFailure(/*object*/ arg1)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(210455822363);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$$.S.String.Format$9("Unable to load type {0} required for deserialization.", arg1);
            }
            //--TRIMMABLE-BOUNDARY-END(210455822363)
            
            //--TRIMMABLE-BOUNDARY-START(1073744248859)
            static /*string */ get Serialization_ValueTypeFixup()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(803161309211);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "ValueType fixup on Arrays is not implemented.";
            }
            //--TRIMMABLE-BOUNDARY-END(1073744248859)
            
            //--TRIMMABLE-BOUNDARY-START(992139870235)
            static /*string */ get Serialization_PartialValueTypeFixup()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(639952551963);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "Fixing up a partially available ValueType chain is not implemented.";
            }
            //--TRIMMABLE-BOUNDARY-END(992139870235)
            
            //--TRIMMABLE-BOUNDARY-START(1065154314267)
            static /*string */ get Serialization_UnableToFixup()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(785981440027);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "Cannot perform fixup.";
            }
            //--TRIMMABLE-BOUNDARY-END(1065154314267)
            
            //--TRIMMABLE-BOUNDARY-START(38657130523)
            static /*string */ get ArgumentOutOfRange_ObjectID()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(296355168283);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "objectID cannot be less than or equal to zero.";
            }
            //--TRIMMABLE-BOUNDARY-END(38657130523)
            
            //--TRIMMABLE-BOUNDARY-START(996434837531)
            static /*string */ get Serialization_RegisterTwice()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(648542486555);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "An object cannot be registered twice.";
            }
            //--TRIMMABLE-BOUNDARY-END(996434837531)
            
            //--TRIMMABLE-BOUNDARY-START(966370066459)
            static /*string */ get Serialization_NotISer()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(588412944411);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "The given object does not implement the ISerializable interface.";
            }
            //--TRIMMABLE-BOUNDARY-END(966370066459)
            
            //--TRIMMABLE-BOUNDARY-START(876175753243)
            static /*string */ get Serialization_ConstructorNotFound()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(408024317979);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "The constructor to deserialize an object of type '{0}' was not found.";
            }
            //--TRIMMABLE-BOUNDARY-END(876175753243)
            
            //--TRIMMABLE-BOUNDARY-START(120261509147)
            static /*string */ FormatSerialization_ConstructorNotFound(/*object*/ arg1)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(120261509147);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$$.S.String.Format$9("The constructor to deserialize an object of type '{0}' was not found.", arg1);
            }
            //--TRIMMABLE-BOUNDARY-END(120261509147)
            
            //--TRIMMABLE-BOUNDARY-START(893355622427)
            static /*string */ get Serialization_IncorrectNumberOfFixups()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(442384056347);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "The ObjectManager found an invalid number of fixups. This usually indicates a problem in the Formatter.";
            }
            //--TRIMMABLE-BOUNDARY-END(893355622427)
            
            //--TRIMMABLE-BOUNDARY-START(901945557019)
            static /*string */ get Serialization_InvalidFixupType()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(459563925531);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "A member fixup was registered for an object which implements ISerializable or has a surrogate. In this situation, a delayed fixup must be used.";
            }
            //--TRIMMABLE-BOUNDARY-END(901945557019)
            
            //--TRIMMABLE-BOUNDARY-START(889060655131)
            static /*string */ get Serialization_IdTooSmall()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(433794121755);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "Object IDs must be greater than zero.";
            }
            //--TRIMMABLE-BOUNDARY-END(889060655131)
            
            //--TRIMMABLE-BOUNDARY-START(983549935643)
            static /*string */ get Serialization_ParentChildIdentical()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(622772682779);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "The ID of the containing object cannot be the same as the object ID.";
            }
            //--TRIMMABLE-BOUNDARY-END(983549935643)
            
            //--TRIMMABLE-BOUNDARY-START(910535491611)
            static /*string */ get Serialization_InvalidType()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(476743794715);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "Only system-provided types can be passed to the GetUninitializedObject method. '{0}' is not a valid instance of a type.";
            }
            //--TRIMMABLE-BOUNDARY-END(910535491611)
            
            //--TRIMMABLE-BOUNDARY-START(133146411035)
            static /*string */ FormatSerialization_InvalidType(/*object*/ arg1)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(133146411035);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$$.S.String.Format$9("Only system-provided types can be passed to the GetUninitializedObject method. '{0}' is not a valid instance of a type.", arg1);
            }
            //--TRIMMABLE-BOUNDARY-END(133146411035)
            
            //--TRIMMABLE-BOUNDARY-START(30067195931)
            static /*string */ get Argument_MustSupplyParent()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(279175299099);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "When supplying the ID of a containing object, the FieldInfo that identifies the current field within that object must also be supplied.";
            }
            //--TRIMMABLE-BOUNDARY-END(30067195931)
            
            //--TRIMMABLE-BOUNDARY-START(21477261339)
            static /*string */ get Argument_MemberAndArray()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(261995429915);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "Cannot supply both a MemberInfo and an Array to indicate the parent of a value type.";
            }
            //--TRIMMABLE-BOUNDARY-END(21477261339)
            
            //--TRIMMABLE-BOUNDARY-START(880470720539)
            static /*string */ get Serialization_CorruptedStream()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(416614252571);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "Invalid BinaryFormatter stream.";
            }
            //--TRIMMABLE-BOUNDARY-END(880470720539)
            
            //--TRIMMABLE-BOUNDARY-START(1005024772123)
            static /*string */ get Serialization_Stream()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(665722355739);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "Attempting to deserialize an empty stream.";
            }
            //--TRIMMABLE-BOUNDARY-END(1005024772123)
            
            //--TRIMMABLE-BOUNDARY-START(871880785947)
            static /*string */ get Serialization_BinaryHeader()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(399434383387);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "Binary stream '{0}' does not contain a valid BinaryHeader. Possible causes are invalid stream or object version change between serialization and deserialization.";
            }
            //--TRIMMABLE-BOUNDARY-END(871880785947)
            
            //--TRIMMABLE-BOUNDARY-START(115966541851)
            static /*string */ FormatSerialization_BinaryHeader(/*object*/ arg1)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(115966541851);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$$.S.String.Format$9("Binary stream '{0}' does not contain a valid BinaryHeader. Possible causes are invalid stream or object version change between serialization and deserialization.", arg1);
            }
            //--TRIMMABLE-BOUNDARY-END(115966541851)
            
            //--TRIMMABLE-BOUNDARY-START(1043679477787)
            static /*string */ get Serialization_TypeExpected()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(743031767067);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "Invalid expected type.";
            }
            //--TRIMMABLE-BOUNDARY-END(1043679477787)
            
            //--TRIMMABLE-BOUNDARY-START(1009319739419)
            static /*string */ get Serialization_StreamEnd()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(674312290331);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "End of Stream encountered before parsing was completed.";
            }
            //--TRIMMABLE-BOUNDARY-END(1009319739419)
            
            //--TRIMMABLE-BOUNDARY-START(884765687835)
            static /*string */ get Serialization_CrossAppDomainError()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(425204187163);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "Cross-AppDomain BinaryFormatter error; expected '{0}' but received '{1}'.";
            }
            //--TRIMMABLE-BOUNDARY-END(884765687835)
            
            //--TRIMMABLE-BOUNDARY-START(124556476443)
            static /*string */ FormatSerialization_CrossAppDomainError(/*object*/ arg1, /*object*/ arg2)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(124556476443);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$$.S.String.Format$8("Cross-AppDomain BinaryFormatter error; expected '{0}' but received '{1}'.", arg1, arg2);
            }
            //--TRIMMABLE-BOUNDARY-END(124556476443)
            
            //--TRIMMABLE-BOUNDARY-START(927715360795)
            static /*string */ get Serialization_Map()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(511103533083);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "No map for object '{0}'.";
            }
            //--TRIMMABLE-BOUNDARY-END(927715360795)
            
            //--TRIMMABLE-BOUNDARY-START(146031312923)
            static /*string */ FormatSerialization_Map(/*object*/ arg1)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(146031312923);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$$.S.String.Format$9("No map for object '{0}'.", arg1);
            }
            //--TRIMMABLE-BOUNDARY-END(146031312923)
            
            //--TRIMMABLE-BOUNDARY-START(858995884059)
            static /*string */ get Serialization_Assembly()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(373664579611);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "No assembly information is available for object on the wire, '{0}'.";
            }
            //--TRIMMABLE-BOUNDARY-END(858995884059)
            
            //--TRIMMABLE-BOUNDARY-START(103081639963)
            static /*string */ FormatSerialization_Assembly(/*object*/ arg1)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(103081639963);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$$.S.String.Format$9("No assembly information is available for object on the wire, '{0}'.", arg1);
            }
            //--TRIMMABLE-BOUNDARY-END(103081639963)
            
            //--TRIMMABLE-BOUNDARY-START(974960001051)
            static /*string */ get Serialization_ObjectTypeEnum()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(605592813595);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "Invalid ObjectTypeEnum {0}.";
            }
            //--TRIMMABLE-BOUNDARY-END(974960001051)
            
            //--TRIMMABLE-BOUNDARY-START(184686018587)
            static /*string */ FormatSerialization_ObjectTypeEnum(/*object*/ arg1)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(184686018587);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$$.S.String.Format$9("Invalid ObjectTypeEnum {0}.", arg1);
            }
            //--TRIMMABLE-BOUNDARY-END(184686018587)
            
            //--TRIMMABLE-BOUNDARY-START(863290851355)
            static /*string */ get Serialization_AssemblyId()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(382254514203);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "No assembly ID for object type '{0}'.";
            }
            //--TRIMMABLE-BOUNDARY-END(863290851355)
            
            //--TRIMMABLE-BOUNDARY-START(107376607259)
            static /*string */ FormatSerialization_AssemblyId(/*object*/ arg1)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(107376607259);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$$.S.String.Format$9("No assembly ID for object type '{0}'.", arg1);
            }
            //--TRIMMABLE-BOUNDARY-END(107376607259)
            
            //--TRIMMABLE-BOUNDARY-START(850405949467)
            static /*string */ get Serialization_ArrayType()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(356484710427);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "Invalid array type '{0}'.";
            }
            //--TRIMMABLE-BOUNDARY-END(850405949467)
            
            //--TRIMMABLE-BOUNDARY-START(98786672667)
            static /*string */ FormatSerialization_ArrayType(/*object*/ arg1)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(98786672667);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$$.S.String.Format$9("Invalid array type '{0}'.", arg1);
            }
            //--TRIMMABLE-BOUNDARY-END(98786672667)
            
            //--TRIMMABLE-BOUNDARY-START(1039384510491)
            static /*string */ get Serialization_TypeCode()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(734441832475);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "Invalid type code in stream '{0}'.";
            }
            //--TRIMMABLE-BOUNDARY-END(1039384510491)
            
            //--TRIMMABLE-BOUNDARY-START(206160855067)
            static /*string */ FormatSerialization_TypeCode(/*object*/ arg1)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(206160855067);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$$.S.String.Format$9("Invalid type code in stream '{0}'.", arg1);
            }
            //--TRIMMABLE-BOUNDARY-END(206160855067)
            
            //--TRIMMABLE-BOUNDARY-START(1060859346971)
            static /*string */ get Serialization_TypeWrite()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(777391505435);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "Invalid write type request '{0}'.";
            }
            //--TRIMMABLE-BOUNDARY-END(1060859346971)
            
            //--TRIMMABLE-BOUNDARY-START(223340724251)
            static /*string */ FormatSerialization_TypeWrite(/*object*/ arg1)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(223340724251);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$$.S.String.Format$9("Invalid write type request '{0}'.", arg1);
            }
            //--TRIMMABLE-BOUNDARY-END(223340724251)
            
            //--TRIMMABLE-BOUNDARY-START(1056564379675)
            static /*string */ get Serialization_TypeRead()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(768801570843);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "Invalid read type request '{0}'.";
            }
            //--TRIMMABLE-BOUNDARY-END(1056564379675)
            
            //--TRIMMABLE-BOUNDARY-START(219045756955)
            static /*string */ FormatSerialization_TypeRead(/*object*/ arg1)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(219045756955);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$$.S.String.Format$9("Invalid read type request '{0}'.", arg1);
            }
            //--TRIMMABLE-BOUNDARY-END(219045756955)
            
            //--TRIMMABLE-BOUNDARY-START(867585818651)
            static /*string */ get Serialization_AssemblyNotFound()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(390844448795);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "Unable to find assembly '{0}'.";
            }
            //--TRIMMABLE-BOUNDARY-END(867585818651)
            
            //--TRIMMABLE-BOUNDARY-START(111671574555)
            static /*string */ FormatSerialization_AssemblyNotFound(/*object*/ arg1)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(111671574555);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$$.S.String.Format$9("Unable to find assembly '{0}'.", arg1);
            }
            //--TRIMMABLE-BOUNDARY-END(111671574555)
            
            //--TRIMMABLE-BOUNDARY-START(906240524315)
            static /*string */ get Serialization_InvalidFormat()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(468153860123);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "The input stream is not a valid binary format. The starting contents (in bytes) are: {0} ...";
            }
            //--TRIMMABLE-BOUNDARY-END(906240524315)
            
            //--TRIMMABLE-BOUNDARY-START(128851443739)
            static /*string */ FormatSerialization_InvalidFormat(/*object*/ arg1)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(128851443739);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$$.S.String.Format$9("The input stream is not a valid binary format. The starting contents (in bytes) are: {0} ...", arg1);
            }
            //--TRIMMABLE-BOUNDARY-END(128851443739)
            
            //--TRIMMABLE-BOUNDARY-START(1030794575899)
            static /*string */ get Serialization_TopObject()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(717261963291);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "No top object.";
            }
            //--TRIMMABLE-BOUNDARY-END(1030794575899)
            
            //--TRIMMABLE-BOUNDARY-START(1078039216155)
            static /*string */ get Serialization_XMLElement()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(811751243803);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "Invalid element '{0}'.";
            }
            //--TRIMMABLE-BOUNDARY-END(1078039216155)
            
            //--TRIMMABLE-BOUNDARY-START(227635691547)
            static /*string */ FormatSerialization_XMLElement(/*object*/ arg1)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(227635691547);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$$.S.String.Format$9("Invalid element '{0}'.", arg1);
            }
            //--TRIMMABLE-BOUNDARY-END(227635691547)
            
            //--TRIMMABLE-BOUNDARY-START(1035089543195)
            static /*string */ get Serialization_TopObjectInstantiate()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(725851897883);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "Top object cannot be instantiated for element '{0}'.";
            }
            //--TRIMMABLE-BOUNDARY-END(1035089543195)
            
            //--TRIMMABLE-BOUNDARY-START(201865887771)
            static /*string */ FormatSerialization_TopObjectInstantiate(/*object*/ arg1)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(201865887771);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$$.S.String.Format$9("Top object cannot be instantiated for element '{0}'.", arg1);
            }
            //--TRIMMABLE-BOUNDARY-END(201865887771)
            
            //--TRIMMABLE-BOUNDARY-START(854700916763)
            static /*string */ get Serialization_ArrayTypeObject()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(365074645019);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "Array element type is Object, 'dt' attribute is null.";
            }
            //--TRIMMABLE-BOUNDARY-END(854700916763)
            
            //--TRIMMABLE-BOUNDARY-START(1052269412379)
            static /*string */ get Serialization_TypeMissing()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(760211636251);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "Type is missing for member of type Object '{0}'.";
            }
            //--TRIMMABLE-BOUNDARY-END(1052269412379)
            
            //--TRIMMABLE-BOUNDARY-START(214750789659)
            static /*string */ FormatSerialization_TypeMissing(/*object*/ arg1)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(214750789659);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$$.S.String.Format$9("Type is missing for member of type Object '{0}'.", arg1);
            }
            //--TRIMMABLE-BOUNDARY-END(214750789659)
            
            //--TRIMMABLE-BOUNDARY-START(979254968347)
            static /*string */ get Serialization_ObjNoID()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(614182748187);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "Object {0} has never been assigned an objectID.";
            }
            //--TRIMMABLE-BOUNDARY-END(979254968347)
            
            //--TRIMMABLE-BOUNDARY-START(188980985883)
            static /*string */ FormatSerialization_ObjNoID(/*object*/ arg1)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(188980985883);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$$.S.String.Format$9("Object {0} has never been assigned an objectID.", arg1);
            }
            //--TRIMMABLE-BOUNDARY-END(188980985883)
            
            //--TRIMMABLE-BOUNDARY-START(1000729804827)
            static /*string */ get Serialization_SerMemberInfo()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(657132421147);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "MemberInfo type {0} cannot be serialized.";
            }
            //--TRIMMABLE-BOUNDARY-END(1000729804827)
            
            //--TRIMMABLE-BOUNDARY-START(197570920475)
            static /*string */ FormatSerialization_SerMemberInfo(/*object*/ arg1)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(197570920475);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$$.S.String.Format$9("MemberInfo type {0} cannot be serialized.", arg1);
            }
            //--TRIMMABLE-BOUNDARY-END(197570920475)
            
            //--TRIMMABLE-BOUNDARY-START(25772228635)
            static /*string */ get Argument_MustSupplyContainer()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(270585364507);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "When supplying a FieldInfo for fixing up a nested type, a valid ID for that containing object must also be supplied.";
            }
            //--TRIMMABLE-BOUNDARY-END(25772228635)
            
            //--TRIMMABLE-BOUNDARY-START(987844902939)
            static /*string */ get Serialization_ParseError()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(631362617371);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "Parse error. Current element is not compatible with the next element, {0}.";
            }
            //--TRIMMABLE-BOUNDARY-END(987844902939)
            
            //--TRIMMABLE-BOUNDARY-START(193275953179)
            static /*string */ FormatSerialization_ParseError(/*object*/ arg1)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(193275953179);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$$.S.String.Format$9("Parse error. Current element is not compatible with the next element, {0}.", arg1);
            }
            //--TRIMMABLE-BOUNDARY-END(193275953179)
            
            //--TRIMMABLE-BOUNDARY-START(919125426203)
            static /*string */ get Serialization_ISerializableMemberInfo()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(493923663899);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "MemberInfo requested for ISerializable type.";
            }
            //--TRIMMABLE-BOUNDARY-END(919125426203)
            
            //--TRIMMABLE-BOUNDARY-START(932010328091)
            static /*string */ get Serialization_MemberInfo()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(519693467675);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "MemberInfo cannot be obtained for ISerialized Object '{0}'.";
            }
            //--TRIMMABLE-BOUNDARY-END(932010328091)
            
            //--TRIMMABLE-BOUNDARY-START(150326280219)
            static /*string */ FormatSerialization_MemberInfo(/*object*/ arg1)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(150326280219);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$$.S.String.Format$9("MemberInfo cannot be obtained for ISerialized Object '{0}'.", arg1);
            }
            //--TRIMMABLE-BOUNDARY-END(150326280219)
            
            //--TRIMMABLE-BOUNDARY-START(923420393499)
            static /*string */ get Serialization_ISerializableTypes()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(502513598491);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "Types not available for ISerializable object '{0}'.";
            }
            //--TRIMMABLE-BOUNDARY-END(923420393499)
            
            //--TRIMMABLE-BOUNDARY-START(141736345627)
            static /*string */ FormatSerialization_ISerializableTypes(/*object*/ arg1)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(141736345627);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$$.S.String.Format$9("Types not available for ISerializable object '{0}'.", arg1);
            }
            //--TRIMMABLE-BOUNDARY-END(141736345627)
            
            //--TRIMMABLE-BOUNDARY-START(936305295387)
            static /*string */ get Serialization_MissingMember()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(528283402267);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "Member '{0}' in class '{1}' is not present in the serialized stream and is not marked with {2}.";
            }
            //--TRIMMABLE-BOUNDARY-END(936305295387)
            
            //--TRIMMABLE-BOUNDARY-START(154621247515)
            static /*string */ FormatSerialization_MissingMember(/*object*/ arg1, /*object*/ arg2, /*object*/ arg3)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(154621247515);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$$.S.String.Format$7("Member '{0}' in class '{1}' is not present in the serialized stream and is not marked with {2}.", arg1, arg2, arg3);
            }
            //--TRIMMABLE-BOUNDARY-END(154621247515)
            
            //--TRIMMABLE-BOUNDARY-START(953485164571)
            static /*string */ get Serialization_NoMemberInfo()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(562643140635);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "No MemberInfo for Object {0}.";
            }
            //--TRIMMABLE-BOUNDARY-END(953485164571)
            
            //--TRIMMABLE-BOUNDARY-START(167506149403)
            static /*string */ FormatSerialization_NoMemberInfo(/*object*/ arg1)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(167506149403);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$$.S.String.Format$9("No MemberInfo for Object {0}.", arg1);
            }
            //--TRIMMABLE-BOUNDARY-END(167506149403)
            
            //--TRIMMABLE-BOUNDARY-START(1017909674011)
            static /*string */ get Serialization_SurrogateCycleInArgument()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(691492159515);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "Selector contained a cycle.";
            }
            //--TRIMMABLE-BOUNDARY-END(1017909674011)
            
            //--TRIMMABLE-BOUNDARY-START(1013614706715)
            static /*string */ get Serialization_SurrogateCycle()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(682902224923);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "Adding selector will introduce a cycle.";
            }
            //--TRIMMABLE-BOUNDARY-END(1013614706715)
            
            //--TRIMMABLE-BOUNDARY-START(828931112987)
            static /*string */ get IO_EOF_ReadBeyondEOF()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(339304841243);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "Unable to read beyond the end of the stream.";
            }
            //--TRIMMABLE-BOUNDARY-END(828931112987)
            
            //--TRIMMABLE-BOUNDARY-START(47247065115)
            static /*string */ get BinaryFormatter_SerializationDisallowed()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(313535037467);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "BinaryFormatter serialization and deserialization are disabled within this application. See https://aka.ms/binaryformatter for more information.";
            }
            //--TRIMMABLE-BOUNDARY-END(47247065115)
            
            //--TRIMMABLE-BOUNDARY-START(51542032411)
            static /*string */ get BinaryFormatter_SerializationNotSupportedOnThisPlatform()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(322124972059);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "BinaryFormatter serialization and deserialization are not supported on this platform. See https://aka.ms/binaryformatter for more information.";
            }
            //--TRIMMABLE-BOUNDARY-END(51542032411)
            
            //--TRIMMABLE-BOUNDARY-START(42952097819)
            static /*string */ get BinaryFormatter_Removed()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(304945102875);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "BinaryFormatter serialization and deserialization have been removed. See https://aka.ms/binaryformatter for more information.";
            }
            //--TRIMMABLE-BOUNDARY-END(42952097819)
            
            //--TRIMMABLE-BOUNDARY-START(4297392155)
            //Static Initializer
            static $sinit()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4297392155);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                {
                    //--TRIMMABLE-BOUNDARY-START(846110982171)
                    this.s_usingResourceKeys = $.$srsf.S.SR.GetUsingResourceKeysSwitchValue();
                    //--TRIMMABLE-BOUNDARY-END(846110982171)
                    
                }
            }
            //--TRIMMABLE-BOUNDARY-END(4297392155)
            
            static $h = 2424859;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "h": 2424859
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `System.SR`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `System${separator}SR`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2424859)
        
        

        //--TRIMMABLE-BOUNDARY-START(65563)
        $asm.$cls(`$srsf.SC.HashHelpers`, ($self) => class HashHelpers
        {
            //--TRIMMABLE-BOUNDARY-START(30064836635)
            /*uint*/ static HashCollisionThreshold = 100;
            //--TRIMMABLE-BOUNDARY-END(30064836635)
            
            //--TRIMMABLE-BOUNDARY-START(42949738523)
            /*int*/ static MaxPrimeArrayLength = 2147483587;
            //--TRIMMABLE-BOUNDARY-END(42949738523)
            
            //--TRIMMABLE-BOUNDARY-START(34359803931)
            /*int*/ static HashPrime = 101;
            //--TRIMMABLE-BOUNDARY-END(34359803931)
            
            //--TRIMMABLE-BOUNDARY-START(47244705819)
            static /*ReadOnlySpan<int> */ get Primes()
            {
                return this.$cachePrimes ??= new ($.$$.S.ReadOnlySpan$$($.$$.S.Int32))().$ctor$7([ 3, 7, 11, 17, 23, 29, 37, 47, 59, 71, 89, 107, 131, 163, 197, 239, 293, 353, 431, 521, 631, 761, 919, 1103, 1327, 1597, 1931, 2333, 2801, 3371, 4049, 4861, 5839, 7013, 8419, 10103, 12143, 14591, 17519, 21023, 25229, 30293, 36353, 43627, 52361, 62851, 75431, 90523, 108631, 130363, 156437, 187751, 225307, 270371, 324449, 389357, 467237, 560689, 672827, 807403, 968897, 1162687, 1395263, 1674319, 2009191, 2411033, 2893249, 3471899, 4166287, 4999559, 5999471, 7199369 ]);
            }
            //--TRIMMABLE-BOUNDARY-END(47244705819)
            
            //--TRIMMABLE-BOUNDARY-START(38654771227)
            static /*bool */ IsPrime(/*int*/ candidate)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(38654771227);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ((candidate & 1) !== 0)
                {
                    /*int*/ let limit = $.$cast(Math.sqrt(candidate), $.$$.S.Int32);
                    for(/*int*/ let divisor = 3; divisor <= limit; divisor += 2)
                    {
                        if ((candidate % divisor) === 0)
                        {
                            return false;
                        }
                    }
                    return true;
                }
                return candidate === 2;
            }
            //--TRIMMABLE-BOUNDARY-END(38654771227)
            
            //--TRIMMABLE-BOUNDARY-START(25769869339)
            static /*int */ GetPrime(/*int*/ min)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25769869339);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (min < 0)
                {
                    throw new $.$$.S.ArgumentException().$ctor$14($.$srsf.S.SR.Arg_HTCapacityOverflow);
                }
                let $en1 = $.$srsf.SC.HashHelpers.Primes.GetEnumerator();
                while ($en1.MoveNext())
                {
                    let prime = $en1.Current.$v;
                    {
                        if (prime >= min)
                        {
                            return prime;
                        }
                    }
                }
                for(/*int*/ let i = (min | 1); i < 2147483647/*int.MaxValue*/; i += 2)
                {
                    if ($.$srsf.SC.HashHelpers.IsPrime(i) && ((((i - 1) | 0)) % 101/*HashPrime*/ !== 0))
                    {
                        return i;
                    }
                }
                return min;
            }
            //--TRIMMABLE-BOUNDARY-END(25769869339)
            
            //--TRIMMABLE-BOUNDARY-START(4295032859)
            static /*int */ ExpandPrime(/*int*/ oldSize)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295032859);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*int*/ let newSize = ((2 * oldSize) | 0);
                if ((newSize >>> 0) > 2147483587/*MaxPrimeArrayLength*/ && 2147483587/*MaxPrimeArrayLength*/ > oldSize)
                {
                    $.$$.SD.Debug.Assert$4(2147483587/*MaxPrimeArrayLength*/ === $.$srsf.SC.HashHelpers.GetPrime(2147483587/*MaxPrimeArrayLength*/), "Invalid MaxPrimeArrayLength");
                    return 2147483587/*MaxPrimeArrayLength*/;
                }
                return $.$srsf.SC.HashHelpers.GetPrime(newSize);
            }
            //--TRIMMABLE-BOUNDARY-END(4295032859)
            
            //--TRIMMABLE-BOUNDARY-START(21474902043)
            static /*ulong */ GetFastModMultiplier(/*uint*/ divisor)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(21474902043);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return BigInt.asUintN(64, 18446744073709551615n / BigInt(divisor) + 1n);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(21474902043)
            
            //--TRIMMABLE-BOUNDARY-START(8590000155)
            static /*uint */ FastMod(/*uint*/ value, /*uint*/ divisor, /*ulong*/ multiplier)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590000155);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.SD.Debug.Assert$4(divisor <= 2147483647/*int.MaxValue*/, "divisor <= int.MaxValue");
                /*uint*/ let highbits = $.$cast(((BigInt.asUintN(64, (BigInt.asUintN(64, ((BigInt.asUintN(64, multiplier * BigInt(value))) >> 32n) + 1n)) * BigInt(divisor))) >> 32n), $.$$.S.UInt32);
                $.$$.SD.Debug.Assert$4(highbits === value % divisor, "highbits == value % divisor");
                return highbits;
            }
            //--TRIMMABLE-BOUNDARY-END(8590000155)
            
            static $h = 65563;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(47244705819),
    {
      "p": $.$$.S.ReadOnlySpan$$($.$$.S.Int32).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 17179934747,
        "f": 50331688
      },
      "n": "Primes",
      "d": 65563,
      "h": 47244705819,
      "f": 2097192
    },
//--TRIMMABLE-BOUNDARY-END(47244705819)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(38654771227),
    {
      "r": 262145,
      "p": [
        {
          "n": "candidate",
          "p": 655361
        }
      ],
      "n": "IsPrime",
      "d": 65563,
      "h": 38654771227,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(38654771227),
//--TRIMMABLE-BOUNDARY-START(25769869339),
    {
      "r": 655361,
      "p": [
        {
          "n": "min",
          "p": 655361
        }
      ],
      "n": "GetPrime",
      "d": 65563,
      "h": 25769869339,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(25769869339),
//--TRIMMABLE-BOUNDARY-START(4295032859),
    {
      "r": 655361,
      "p": [
        {
          "n": "oldSize",
          "p": 655361
        }
      ],
      "n": "ExpandPrime",
      "d": 65563,
      "h": 4295032859,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(4295032859),
//--TRIMMABLE-BOUNDARY-START(21474902043),
    {
      "r": 983041,
      "p": [
        {
          "n": "divisor",
          "p": 720897
        }
      ],
      "n": "GetFastModMultiplier",
      "d": 65563,
      "h": 21474902043,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(21474902043),
//--TRIMMABLE-BOUNDARY-START(8590000155),
    {
      "r": 720897,
      "p": [
        {
          "n": "value",
          "p": 720897
        },
        {
          "n": "divisor",
          "p": 720897
        },
        {
          "n": "multiplier",
          "p": 983041
        }
      ],
      "n": "FastMod",
      "d": 65563,
      "h": 8590000155,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8590000155)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(30064836635),
    {
      "t": 720897,
      "n": "HashCollisionThreshold",
      "d": 65563,
      "h": 30064836635,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(30064836635),
//--TRIMMABLE-BOUNDARY-START(42949738523),
    {
      "t": 655361,
      "n": "MaxPrimeArrayLength",
      "d": 65563,
      "h": 42949738523,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(42949738523),
//--TRIMMABLE-BOUNDARY-START(34359803931),
    {
      "t": 655361,
      "n": "HashPrime",
      "d": 65563,
      "h": 34359803931,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(34359803931)
  ],
  "h": 65563
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `System.Collections.HashHelpers`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `System${separator}Collections${separator}HashHelpers`; }
        });
        //--TRIMMABLE-BOUNDARY-END(65563)
        
        

        //--TRIMMABLE-BOUNDARY-START(1966107)
        $asm.$cls(`$srsf.SRS.SerializationObjectManager`, ($self) => class SerializationObjectManager extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(34361704475)
            /*string*/ static SerializationObjectManagerUnreferencedCodeMessage = null;
            //--TRIMMABLE-BOUNDARY-END(34361704475)
            
            //--TRIMMABLE-BOUNDARY-START(8591900699)
            /*Dictionary<object, object>*/ _objectSeenTable = null;
            //--TRIMMABLE-BOUNDARY-END(8591900699)
            
            //--TRIMMABLE-BOUNDARY-START(4296933403)
            /*StreamingContext*/ _context;
            //--TRIMMABLE-BOUNDARY-END(4296933403)
            
            //--TRIMMABLE-BOUNDARY-START(12886867995)
            /*SerializationEventHandler?*/ _onSerializedHandler = null;
            //--TRIMMABLE-BOUNDARY-END(12886867995)
            
            //--TRIMMABLE-BOUNDARY-START(17181835291)
            $ctor$1(/*StreamingContext*/ context)
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(17181835291);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this._context = context;
                    this._objectSeenTable = new ($.$$.SCG.Dictionary$$$($.$$.S.Object, $.$$.S.Object))().$ctor$1();
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(17181835291)
            
            //--TRIMMABLE-BOUNDARY-START(30066737179)
            /*void */ RegisterObject(/*object*/ obj)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(30066737179);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*SerializationEvents*/ let cache = $.$srsf.SRS.SerializationEventsCache.GetSerializationEventsForType($.$$.S.Object.GetType.call(obj));
                if (cache.HasOnSerializingEvents)
                {
                    if (this._objectSeenTable.TryAdd(obj, $.$box(true, $.$$.S.Boolean)))
                    {
                        cache.InvokeOnSerializing(obj, this._context);
                        this.AddOnSerialized(obj);
                    }
                }
            }
            //--TRIMMABLE-BOUNDARY-END(30066737179)
            
            //--TRIMMABLE-BOUNDARY-START(25771769883)
            /*void */ RaiseOnSerializedEvent()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(25771769883);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return (this._onSerializedHandler?.Invoke(this._context) ?? null);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(25771769883)
            
            //--TRIMMABLE-BOUNDARY-START(21476802587)
            /*void */ AddOnSerialized(/*object*/ obj)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21476802587);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*SerializationEvents*/ let cache = $.$srsf.SRS.SerializationEventsCache.GetSerializationEventsForType($.$$.S.Object.GetType.call(obj));
                this._onSerializedHandler = cache.AddOnSerialized(obj, this._onSerializedHandler);
            }
            //--TRIMMABLE-BOUNDARY-END(21476802587)
            
            //default member initializer
            constructor()
            {
                super();
                //--TRIMMABLE-BOUNDARY-START(4296933403)
                this._context = $.$default($.$$.SRS.StreamingContext);
                //--TRIMMABLE-BOUNDARY-END(4296933403)
                
            }
            //--TRIMMABLE-BOUNDARY-START(SINIT)
            //Static Initializer
            static $sinit()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(34361704475)
                    this.SerializationObjectManagerUnreferencedCodeMessage = "SerializationObjectManager is not trim compatible because the type of objects being managed cannot be statically discovered.";
                    //--TRIMMABLE-BOUNDARY-END(34361704475)
                    
                }
            }
            //--TRIMMABLE-BOUNDARY-END(SINIT)
            
            static $h = 1966107;
            static $f = 0b10010001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(30066737179),
    {
      "r": 65537,
      "p": [
        {
          "n": "obj",
          "p": 131073
        }
      ],
      "n": "RegisterObject",
      "d": 1966107,
      "h": 30066737179,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(30066737179),
//--TRIMMABLE-BOUNDARY-START(25771769883),
    {
      "r": 65537,
      "n": "RaiseOnSerializedEvent",
      "d": 1966107,
      "h": 25771769883,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(25771769883),
//--TRIMMABLE-BOUNDARY-START(21476802587),
    {
      "r": 65537,
      "p": [
        {
          "n": "obj",
          "p": 131073
        }
      ],
      "n": "AddOnSerialized",
      "d": 1966107,
      "h": 21476802587,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(21476802587)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(34361704475),
    {
      "t": 1310721,
      "n": "SerializationObjectManagerUnreferencedCodeMessage",
      "d": 1966107,
      "h": 34361704475,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(34361704475),
//--TRIMMABLE-BOUNDARY-START(8591900699),
    {
      "t": $.$$.SCG.Dictionary$$$($.$$.S.Object, $.$$.S.Object).$h,
      "n": "_objectSeenTable",
      "d": 1966107,
      "h": 8591900699,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(8591900699),
//--TRIMMABLE-BOUNDARY-START(4296933403),
    {
      "t": 158990337,
      "n": "_context",
      "d": 1966107,
      "h": 4296933403,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(4296933403),
//--TRIMMABLE-BOUNDARY-START(12886867995),
    {
      "t": 1638427,
      "n": "_onSerializedHandler",
      "d": 1966107,
      "h": 12886867995,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(12886867995)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(17181835291),
    {
      "p": [
        {
          "n": "context",
          "p": 158990337
        }
      ],
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 1966107,
      "h": 17181835291,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(17181835291)
  ],
  "h": 1966107,
  "a": [
    {
      "t": 104464385,
      "c": 30169235457,
      "a": [
        {
          "v": "Formatter-based serialization is obsolete and should not be used.",
          "t": 1310721
        }
      ],
      "n": [
        {
          "n": "DiagnosticId",
          "v": "SYSLIB0050",
          "t": 1310721
        },
        {
          "n": "UrlFormat",
          "v": "https://aka.ms/dotnet-warnings/{0}",
          "t": 1310721
        }
      ]
    }
  ]
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `System.Runtime.Serialization.SerializationObjectManager`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `System${separator}Runtime${separator}Serialization${separator}SerializationObjectManager`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1966107)
        
        

        //--TRIMMABLE-BOUNDARY-START(1703963)
        $asm.$cls(`$srsf.SRS.SerializationEvents`, ($self) => class SerializationEvents extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(17181573147)
            /*List<MethodInfo>?*/ _onSerializingMethods = null;
            //--TRIMMABLE-BOUNDARY-END(17181573147)
            
            //--TRIMMABLE-BOUNDARY-START(12886605851)
            /*List<MethodInfo>?*/ _onSerializedMethods = null;
            //--TRIMMABLE-BOUNDARY-END(12886605851)
            
            //--TRIMMABLE-BOUNDARY-START(8591638555)
            /*List<MethodInfo>?*/ _onDeserializingMethods = null;
            //--TRIMMABLE-BOUNDARY-END(8591638555)
            
            //--TRIMMABLE-BOUNDARY-START(4296671259)
            /*List<MethodInfo>?*/ _onDeserializedMethods = null;
            //--TRIMMABLE-BOUNDARY-END(4296671259)
            
            //--TRIMMABLE-BOUNDARY-START(21476540443)
            $ctor$1(/*Type?*/ t)
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(21476540443);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this._onSerializingMethods = this.GetMethodsWithAttribute($.$$.SRS.OnSerializingAttribute.$type, t);
                    this._onSerializedMethods = this.GetMethodsWithAttribute($.$$.SRS.OnSerializedAttribute.$type, t);
                    this._onDeserializingMethods = this.GetMethodsWithAttribute($.$$.SRS.OnDeserializingAttribute.$type, t);
                    this._onDeserializedMethods = this.GetMethodsWithAttribute($.$$.SRS.OnDeserializedAttribute.$type, t);
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(21476540443)
            
            //--TRIMMABLE-BOUNDARY-START(47246344219)
            /*List<MethodInfo>? */ GetMethodsWithAttribute(/*Type*/ attribute, /*Type?*/ t)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(47246344219);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*List<MethodInfo>?*/ let mi = null;
                /*Type?*/ let baseType = t;
                while(baseType !== null && baseType !== $.$$.S.Object.$type)
                {
                    /*MethodInfo[]*/ let mis = baseType.GetMethods$1(2/*BindingFlags.DeclaredOnly*/ | 4/*BindingFlags.Instance*/ | 32/*BindingFlags.NonPublic*/ | 16/*BindingFlags.Public*/);
                    let $i1 = 0;
                    let $arr1 = mis;
                    while ($i1 < $arr1.length)
                    {
                        let m = $arr1[$i1++];
                        if (m.IsDefined(attribute, false))
                        {
                            mi ??= new ($.$$.SCG.List$$($.$$.SR.MethodInfo))().$ctor$1();
                            mi.Add(m);
                        }
                    }
                    baseType = baseType.BaseType;
                }
                mi?.Reverse();
                return mi;
            }
            //--TRIMMABLE-BOUNDARY-END(47246344219)
            
            //--TRIMMABLE-BOUNDARY-START(51541311515)
            /*bool */ get HasOnSerializingEvents()
            {
                return this._onSerializingMethods !== null || this._onSerializedMethods !== null;
            }
            //--TRIMMABLE-BOUNDARY-END(51541311515)
            
            //--TRIMMABLE-BOUNDARY-START(68721180699)
            /*void */ InvokeOnSerializing(/*object*/ obj, /*StreamingContext*/ context)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(68721180699);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return $.$srsf.SRS.SerializationEvents.InvokeOnDelegate(obj, context, this._onSerializingMethods);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(68721180699)
            
            //--TRIMMABLE-BOUNDARY-START(64426213403)
            /*void */ InvokeOnDeserializing(/*object*/ obj, /*StreamingContext*/ context)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(64426213403);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return $.$srsf.SRS.SerializationEvents.InvokeOnDelegate(obj, context, this._onDeserializingMethods);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(64426213403)
            
            //--TRIMMABLE-BOUNDARY-START(60131246107)
            /*void */ InvokeOnDeserialized(/*object*/ obj, /*StreamingContext*/ context)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(60131246107);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return $.$srsf.SRS.SerializationEvents.InvokeOnDelegate(obj, context, this._onDeserializedMethods);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(60131246107)
            
            //--TRIMMABLE-BOUNDARY-START(34361442331)
            /*SerializationEventHandler? */ AddOnSerialized(/*object*/ obj, /*SerializationEventHandler?*/ handler)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(34361442331);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return $.$srsf.SRS.SerializationEvents.AddOnDelegate(obj, handler, this._onSerializedMethods);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(34361442331)
            
            //--TRIMMABLE-BOUNDARY-START(30066475035)
            /*SerializationEventHandler? */ AddOnDeserialized(/*object*/ obj, /*SerializationEventHandler?*/ handler)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(30066475035);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return $.$srsf.SRS.SerializationEvents.AddOnDelegate(obj, handler, this._onDeserializedMethods);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(30066475035)
            
            //--TRIMMABLE-BOUNDARY-START(55836278811)
            static /*void */ InvokeOnDelegate(/*object*/ obj, /*StreamingContext*/ context, /*List<MethodInfo>?*/ methods)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(55836278811);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.SD.Debug.Assert$4(obj !== null, "object should have been initialized");
                $.$srsf.SRS.SerializationEvents.AddOnDelegate(obj, null, methods)?.Invoke(context);
            }
            //--TRIMMABLE-BOUNDARY-END(55836278811)
            
            //--TRIMMABLE-BOUNDARY-START(25771507739)
            static /*SerializationEventHandler? */ AddOnDelegate(/*object*/ obj, /*SerializationEventHandler?*/ handler, /*List<MethodInfo>?*/ methods)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25771507739);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (methods !== null)
                {
                    let $en2 = methods.GetEnumerator();
                    while ($en2.MoveNext())
                    {
                        let m = $en2.Current;
                        {
                            /*SerializationEventHandler*/ let onDeserialized = m.CreateDelegate$3($.$srsf.SRS.SerializationEventHandler, obj);
                            handler = $.$cast($.$$.S.Delegate.Combine$2(handler, onDeserialized), $.$srsf.SRS.SerializationEventHandler);
                        }
                    }
                }
                return handler;
            }
            //--TRIMMABLE-BOUNDARY-END(25771507739)
            
            static $h = 1703963;
            static $f = 0b10010000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(51541311515),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 42951376923,
        "f": 50331656
      },
      "n": "HasOnSerializingEvents",
      "d": 1703963,
      "h": 51541311515,
      "f": 2097160
    },
//--TRIMMABLE-BOUNDARY-END(51541311515)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(47246344219),
    {
      "r": $.$$.SCG.List$$($.$$.SR.MethodInfo).$h,
      "p": [
        {
          "n": "attribute",
          "p": 188547073
        },
        {
          "n": "t",
          "p": 188547073
        }
      ],
      "n": "GetMethodsWithAttribute",
      "d": 1703963,
      "h": 47246344219,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(47246344219),
//--TRIMMABLE-BOUNDARY-START(68721180699),
    {
      "r": 65537,
      "p": [
        {
          "n": "obj",
          "p": 131073
        },
        {
          "n": "context",
          "p": 158990337
        }
      ],
      "n": "InvokeOnSerializing",
      "d": 1703963,
      "h": 68721180699,
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(68721180699),
//--TRIMMABLE-BOUNDARY-START(64426213403),
    {
      "r": 65537,
      "p": [
        {
          "n": "obj",
          "p": 131073
        },
        {
          "n": "context",
          "p": 158990337
        }
      ],
      "n": "InvokeOnDeserializing",
      "d": 1703963,
      "h": 64426213403,
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(64426213403),
//--TRIMMABLE-BOUNDARY-START(60131246107),
    {
      "r": 65537,
      "p": [
        {
          "n": "obj",
          "p": 131073
        },
        {
          "n": "context",
          "p": 158990337
        }
      ],
      "n": "InvokeOnDeserialized",
      "d": 1703963,
      "h": 60131246107,
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(60131246107),
//--TRIMMABLE-BOUNDARY-START(34361442331),
    {
      "r": 1638427,
      "p": [
        {
          "n": "obj",
          "p": 131073
        },
        {
          "n": "handler",
          "p": 1638427
        }
      ],
      "n": "AddOnSerialized",
      "d": 1703963,
      "h": 34361442331,
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(34361442331),
//--TRIMMABLE-BOUNDARY-START(30066475035),
    {
      "r": 1638427,
      "p": [
        {
          "n": "obj",
          "p": 131073
        },
        {
          "n": "handler",
          "p": 1638427
        }
      ],
      "n": "AddOnDeserialized",
      "d": 1703963,
      "h": 30066475035,
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(30066475035),
//--TRIMMABLE-BOUNDARY-START(55836278811),
    {
      "r": 65537,
      "p": [
        {
          "n": "obj",
          "p": 131073
        },
        {
          "n": "context",
          "p": 158990337
        },
        {
          "n": "methods",
          "p": $.$$.SCG.List$$($.$$.SR.MethodInfo).$h
        }
      ],
      "n": "InvokeOnDelegate",
      "d": 1703963,
      "h": 55836278811,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(55836278811),
//--TRIMMABLE-BOUNDARY-START(25771507739),
    {
      "r": 1638427,
      "p": [
        {
          "n": "obj",
          "p": 131073
        },
        {
          "n": "handler",
          "p": 1638427
        },
        {
          "n": "methods",
          "p": $.$$.SCG.List$$($.$$.SR.MethodInfo).$h
        }
      ],
      "n": "AddOnDelegate",
      "d": 1703963,
      "h": 25771507739,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(25771507739)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(17181573147),
    {
      "t": $.$$.SCG.List$$($.$$.SR.MethodInfo).$h,
      "n": "_onSerializingMethods",
      "d": 1703963,
      "h": 17181573147,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(17181573147),
//--TRIMMABLE-BOUNDARY-START(12886605851),
    {
      "t": $.$$.SCG.List$$($.$$.SR.MethodInfo).$h,
      "n": "_onSerializedMethods",
      "d": 1703963,
      "h": 12886605851,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(12886605851),
//--TRIMMABLE-BOUNDARY-START(8591638555),
    {
      "t": $.$$.SCG.List$$($.$$.SR.MethodInfo).$h,
      "n": "_onDeserializingMethods",
      "d": 1703963,
      "h": 8591638555,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(8591638555),
//--TRIMMABLE-BOUNDARY-START(4296671259),
    {
      "t": $.$$.SCG.List$$($.$$.SR.MethodInfo).$h,
      "n": "_onDeserializedMethods",
      "d": 1703963,
      "h": 4296671259,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(4296671259)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(21476540443),
    {
      "p": [
        {
          "n": "t",
          "p": 188547073
        }
      ],
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 1703963,
      "h": 21476540443,
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(21476540443)
  ],
  "h": 1703963
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `System.Runtime.Serialization.SerializationEvents`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `System${separator}Runtime${separator}Serialization${separator}SerializationEvents`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1703963)
        
        

        //--TRIMMABLE-BOUNDARY-START(1507355)
        $asm.$cls(`$srsf.SRS.ObjectManager`, ($self) => class ObjectManager extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(77310918683)
            /*int*/ static DefaultInitialSize = 16;
            //--TRIMMABLE-BOUNDARY-END(77310918683)
            
            //--TRIMMABLE-BOUNDARY-START(141735428123)
            /*int*/ static MaxArraySize = 1048576;
            //--TRIMMABLE-BOUNDARY-END(141735428123)
            
            //--TRIMMABLE-BOUNDARY-START(60131049499)
            /*int*/ static ArrayMask = 1048575;
            //--TRIMMABLE-BOUNDARY-END(60131049499)
            
            //--TRIMMABLE-BOUNDARY-START(146030395419)
            /*int*/ static MaxReferenceDepth = 100;
            //--TRIMMABLE-BOUNDARY-END(146030395419)
            
            //--TRIMMABLE-BOUNDARY-START(150325362715)
            /*string*/ static ObjectManagerUnreferencedCodeMessage = null;
            //--TRIMMABLE-BOUNDARY-END(150325362715)
            
            //--TRIMMABLE-BOUNDARY-START(214749872155)
            /*FieldInfo*/ static s_nullableValueField = null;
            //--TRIMMABLE-BOUNDARY-END(214749872155)
            
            //--TRIMMABLE-BOUNDARY-START(17181376539)
            /*DeserializationEventHandler?*/ _onDeserializationHandler = null;
            //--TRIMMABLE-BOUNDARY-END(17181376539)
            
            //--TRIMMABLE-BOUNDARY-START(21476343835)
            /*SerializationEventHandler?*/ _onDeserializedHandler = null;
            //--TRIMMABLE-BOUNDARY-END(21476343835)
            
            //--TRIMMABLE-BOUNDARY-START(12886409243)
            /*ObjectHolder[]*/ _objects = null;
            //--TRIMMABLE-BOUNDARY-END(12886409243)
            
            //--TRIMMABLE-BOUNDARY-START(34361245723)
            /*object?*/ _topObject = null;
            //--TRIMMABLE-BOUNDARY-END(34361245723)
            
            //--TRIMMABLE-BOUNDARY-START(30066278427)
            /*ObjectHolderList?*/ _specialFixupObjects = null;
            //--TRIMMABLE-BOUNDARY-END(30066278427)
            
            //--TRIMMABLE-BOUNDARY-START(8591441947)
            /*long*/ _fixupCount = 0n;
            //--TRIMMABLE-BOUNDARY-END(8591441947)
            
            //--TRIMMABLE-BOUNDARY-START(25771311131)
            /*ISurrogateSelector?*/ _selector = null;
            //--TRIMMABLE-BOUNDARY-END(25771311131)
            
            //--TRIMMABLE-BOUNDARY-START(4296474651)
            /*StreamingContext*/ _context;
            //--TRIMMABLE-BOUNDARY-END(4296474651)
            
            //--TRIMMABLE-BOUNDARY-START(42951180315)
            $ctor$1(/*ISurrogateSelector?*/ selector, /*StreamingContext*/ context)
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(42951180315);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this._objects = $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$srsf.SRS.ObjectHolder), null, [16/*DefaultInitialSize*/], null);
                    this._selector = selector;
                    this._context = context;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(42951180315)
            
            //--TRIMMABLE-BOUNDARY-START(64426016795)
            /*bool */ CanCallGetType(/*object?*/ obj)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(64426016795);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return true;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(64426016795)
            
            //--TRIMMABLE-BOUNDARY-START(231929741339)
            /*object? */ get TopObject()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(120260591643);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this._topObject;
            }
            /*object? */ set TopObject(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(223339806747);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this._topObject = value;
            }
            //--TRIMMABLE-BOUNDARY-END(231929741339)
            
            //--TRIMMABLE-BOUNDARY-START(227634774043)
            /*ObjectHolderList */ get SpecialFixupObjects()
            {
                return this._specialFixupObjects ??= new $.$srsf.SRS.ObjectHolderList().$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(227634774043)
            
            //--TRIMMABLE-BOUNDARY-START(94490787867)
            /*ObjectHolder? */ FindObjectHolder(/*long*/ objectID)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(94490787867);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*int*/ let index = $.$cast((objectID & BigInt(1048575/*ArrayMask*/)), $.$$.S.Int32);
                if (index >= this._objects.length)
                {
                    return null;
                }
                /*ObjectHolder?*/ let temp = $.$$.System.Array.$ReadT1.call(this._objects, index);
                while(temp !== null)
                {
                    if (temp._id === objectID)
                    {
                        return temp;
                    }
                    temp = temp._next;
                }
                return temp;
            }
            //--TRIMMABLE-BOUNDARY-END(94490787867)
            
            //--TRIMMABLE-BOUNDARY-START(98785755163)
            /*ObjectHolder */ FindOrCreateObjectHolder(/*long*/ objectID)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(98785755163);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*ObjectHolder?*/ let holder = this.FindObjectHolder(objectID);
                if (holder === null)
                {
                    holder = new $.$srsf.SRS.ObjectHolder().$ctor$1(objectID);
                    this.AddObjectHolder(holder);
                }
                return holder;
            }
            //--TRIMMABLE-BOUNDARY-END(98785755163)
            
            //--TRIMMABLE-BOUNDARY-START(47246147611)
            /*void */ AddObjectHolder(/*ObjectHolder*/ holder)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(47246147611);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.SD.Debug.Assert$4(holder !== null, "holder!=null");
                $.$$.SD.Debug.Assert$4(holder._id >= 0n, "holder.m_id>=0");
                if (holder._id >= BigInt(this._objects.length) && this._objects.length !== 1048576/*MaxArraySize*/)
                {
                    /*int*/ let newSize = 1048576/*MaxArraySize*/;
                    if (holder._id < BigInt($.trunc(1048576/*MaxArraySize*/ / 2)))
                    {
                        newSize = (((this._objects.length * 2) | 0));
                        while(BigInt(newSize) <= holder._id && newSize < 1048576/*MaxArraySize*/)
                        {
                            newSize *= 2;
                        }
                        if (newSize > 1048576/*MaxArraySize*/)
                        {
                            newSize = 1048576/*MaxArraySize*/;
                        }
                    }
                    /*ObjectHolder[]*/ let temp = $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$srsf.SRS.ObjectHolder), null, [newSize], null);
                    $.$$.S.Array.Copy$2(this._objects, temp, this._objects.length);
                    this._objects = temp;
                }
                /*int*/ let index = $.$cast((holder._id & BigInt(1048575/*ArrayMask*/)), $.$$.S.Int32);
                /*ObjectHolder*/ let tempHolder = $.$$.System.Array.$ReadT1.call(this._objects, index);
                holder._next = tempHolder;
                $.$$.System.Array.$WriteT1.call(this._objects, holder, index);
            }
            //--TRIMMABLE-BOUNDARY-END(47246147611)
            
            //--TRIMMABLE-BOUNDARY-START(124555558939)
            /*bool */ GetCompletionInfo(/*FixupHolder*/ fixup, /*out ObjectHolder?*/ holder, /*out object*/ member, /*bool*/ bThrowIfMissing)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(124555558939);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                member.$v = fixup._fixupInfo;
                holder.$v = this.FindObjectHolder(fixup._id);
                if (holder.$v === null || holder.$v.CanObjectValueChange || holder.$v.ObjectValue === null)
                {
                    if (bThrowIfMissing)
                    {
                        if (holder.$v === null)
                        {
                            throw new $.$$.SRS.SerializationException().$ctor$12($.$srsf.S.SR.Format$6($.$srsf.S.SR.Serialization_NeverSeen, $.$box(fixup._id, $.$$.S.Int64)));
                        }
                        if (holder.$v.IsIncompleteObjectReference)
                        {
                            throw new $.$$.SRS.SerializationException().$ctor$12($.$srsf.S.SR.Format$6($.$srsf.S.SR.Serialization_IORIncomplete, $.$box(fixup._id, $.$$.S.Int64)));
                        }
                        throw new $.$$.SRS.SerializationException().$ctor$12($.$srsf.S.SR.Format$6($.$srsf.S.SR.Serialization_ObjectNotSupplied, $.$box(fixup._id, $.$$.S.Int64)));
                    }
                    return false;
                }
                if (!holder.$v.CompletelyFixed)
                {
                    if (holder.$v.ObjectValue !== null && $.$is(holder.$v.ObjectValue, $.$$.S.ValueType))
                    {
                        this.SpecialFixupObjects.Add(holder.$v);
                        return false;
                    }
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(124555558939)
            
            //--TRIMMABLE-BOUNDARY-START(103080722459)
            /*void */ FixupSpecialObject(/*ObjectHolder*/ holder)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(103080722459);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*ISurrogateSelector?*/ let uselessSelector = null;
                $.$$.SD.Debug.Assert$4(holder.RequiresSerInfoFixup, "[ObjectManager.FixupSpecialObject]holder.HasSurrogate||holder.HasISerializable");
                if (holder.HasSurrogate)
                {
                    /*ISerializationSurrogate?*/ let surrogate = holder.Surrogate;
                    $.$$.SD.Debug.Assert$4(surrogate !== null, "surrogate!=null");
                    $.$$.SD.Debug.Assert$4(holder.SerializationInfo !== null, "holder.SerializationInfo != null");
                    /*object?*/ let returnValue = surrogate.SRS$ISerializationSurrogate$SetObjectData(holder.ObjectValue, holder.SerializationInfo, this._context, uselessSelector);
                    if (returnValue !== null)
                    {
                        if (!holder.CanSurrogatedObjectValueChange && returnValue !== holder.ObjectValue)
                        {
                            throw new $.$$.SRS.SerializationException().$ctor$12($.$srsf.S.SR.Format$6($.$srsf.S.SR.Serialization_NotCyclicallyReferenceableSurrogate, $.$$.S.Object.GetType.call(surrogate).FullName));
                        }
                        holder.SetObjectValue(returnValue, this);
                    }
                    holder._surrogate = null;
                    holder.SetFlags();
                }
                else 
                {
                    $.$$.SD.Debug.Assert$4($.$is(holder.ObjectValue, $.$$.SRS.ISerializable), "holder.m_object is ISerializable");
                    this.CompleteISerializableObject(holder.ObjectValue, holder.SerializationInfo, this._context);
                }
                holder.SerializationInfo = null;
                holder.RequiresSerInfoFixup = false;
                if (holder.RequiresValueTypeFixup && holder.ValueTypeFixupPerformed)
                {
                    this.DoValueTypeFixup(null, holder, holder.ObjectValue);
                }
                this.DoNewlyRegisteredObjectFixups(holder);
            }
            //--TRIMMABLE-BOUNDARY-END(103080722459)
            
            //--TRIMMABLE-BOUNDARY-START(210454904859)
            /*bool */ ResolveObjectReference(/*ObjectHolder*/ holder)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(210454904859);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*object?*/ let tempObject;
                $.$$.SD.Debug.Assert$4(holder.IsIncompleteObjectReference, "holder.IsIncompleteObjectReference");
                /*int*/ let depthCount = 0;
                try
                {
                    do
                    {
                        tempObject = holder.ObjectValue;
                        $.$$.SD.Debug.Assert$4(holder.ObjectValue !== null, "holder.ObjectValue != null");
                        holder.SetObjectValue(($.$cast((holder.ObjectValue), $.$$.SRS.IObjectReference)).SRS$IObjectReference$GetRealObject(this._context), this);
                        if (holder.ObjectValue === null)
                        {
                            holder.SetObjectValue(tempObject, this);
                            return false;
                        }
                        if (depthCount++ === 100/*MaxReferenceDepth*/)
                        {
                            throw new $.$$.SRS.SerializationException().$ctor$12($.$srsf.S.SR.Serialization_TooManyReferences);
                        }
                    }
                    while(($.$is(holder.ObjectValue, $.$$.SRS.IObjectReference)) && (tempObject !== holder.ObjectValue));
                }
                catch($e)
                {
                    return false;
                }
                holder.IsIncompleteObjectReference = false;
                this.DoNewlyRegisteredObjectFixups(holder);
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(210454904859)
            
            //--TRIMMABLE-BOUNDARY-START(90195820571)
            /*bool */ DoValueTypeFixup(/*FieldInfo?*/ memberToFix, /*ObjectHolder*/ holder, /*object?*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(90195820571);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let fieldsTemp = $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.SR.FieldInfo), null, [4], null);
                /*FieldInfo[]*/ let fields;
                /*int*/ let currentFieldIndex = 0;
                /*int[]?*/ let arrayIndex = null;
                /*ValueTypeFixupInfo*/ let currFixup;
                /*object?*/ let fixupObj = holder.ObjectValue;
                $.$$.SD.Debug.Assert$4(holder !== null, "[TypedReferenceBuilder.ctor]holder!=null");
                $.$$.SD.Debug.Assert$4(holder.RequiresValueTypeFixup, "[TypedReferenceBuilder.ctor]holder.RequiresValueTypeFixup");
                while(holder.RequiresValueTypeFixup)
                {
                    if ((((currentFieldIndex + 1) | 0)) >= fieldsTemp.length)
                    {
                        /*var*/ let temp = $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.SR.FieldInfo), null, [((fieldsTemp.length * 2) | 0)], null);
                        $.$$.S.Array.Copy$2(fieldsTemp, temp, fieldsTemp.length);
                        fieldsTemp = temp;
                    }
                    currFixup = holder.ValueFixup;
                    fixupObj = holder.ObjectValue;
                    if ($.$$.SR.FieldInfo.op_Inequality$1(currFixup.ParentField, null))
                    {
                        /*FieldInfo*/ let parentField = currFixup.ParentField;
                        /*ObjectHolder?*/ let tempHolder = this.FindObjectHolder(currFixup.ContainerID);
                        $.$$.SD.Debug.Assert$4(tempHolder !== null, "tempHolder != null");
                        if (tempHolder.ObjectValue === null)
                        {
                            break;
                        }
                        /*FieldInfo?*/ let nullableValueField = $.$srsf.SRS.ObjectManager.GetNullableValueField(parentField.FieldType);
                        if ($.$$.SR.FieldInfo.op_Inequality$1(nullableValueField, null))
                        {
                            $.$$.System.Array.$WriteT1.call(fieldsTemp, nullableValueField, currentFieldIndex);
                            currentFieldIndex++;
                        }
                        $.$$.System.Array.$WriteT1.call(fieldsTemp, parentField, currentFieldIndex);
                        holder = tempHolder;
                        currentFieldIndex++;
                    }
                    else 
                    {
                        $.$$.SD.Debug.Assert$4(currFixup.ParentIndex !== null, "[ObjectManager.DoValueTypeFixup]currFixup.ParentIndex!=null");
                        holder = this.FindObjectHolder(currFixup.ContainerID);
                        arrayIndex = currFixup.ParentIndex;
                        break;
                    }
                }
                if (!($.$is(holder.ObjectValue, $.$$.S.Array)) && holder.ObjectValue !== null)
                {
                    fixupObj = holder.ObjectValue;
                    $.$$.SD.Debug.Assert$4(fixupObj !== null, "[ObjectManager.DoValueTypeFixup]FixupObj!=null");
                }
                if (currentFieldIndex !== 0)
                {
                    fields = $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.SR.FieldInfo), null, [currentFieldIndex], null);
                    for(/*int*/ let i = 0; i < currentFieldIndex; i++)
                    {
                        /*FieldInfo?*/ let fieldInfo = $.$$.System.Array.$ReadT1.call(fieldsTemp, (((((currentFieldIndex - 1) | 0) - i) | 0)));
                        /*SerializationFieldInfo?*/ let serInfo = $.$as(fieldInfo, $.$srsf.SRS.SerializationFieldInfo);
                        $.$$.System.Array.$WriteT1.call(fields, serInfo === null ? fieldInfo : serInfo.FieldInfo, i);
                    }
                    $.$$.SD.Debug.Assert$4(fixupObj !== null, "[ObjectManager.DoValueTypeFixup]fixupObj!=null");
                    /*TypedReference*/ let typedRef = $.$$.S.TypedReference.MakeTypedReference(fixupObj, fields);
                    if ($.$$.SR.FieldInfo.op_Inequality$1(memberToFix, null))
                    {
                        memberToFix.SetValueDirect(typedRef, value);
                    }
                    else 
                    {
                        $.$$.S.TypedReference.SetTypedReference(typedRef, value);
                    }
                }
                else if ($.$$.SR.FieldInfo.op_Inequality$1(memberToFix, null))
                {
                    $.$srsf.SRS.FormatterServices.SerializationSetValue(memberToFix, fixupObj, value);
                }
                if (arrayIndex !== null && holder.ObjectValue !== null)
                {
                    ($.$cast((holder.ObjectValue), $.$$.S.Array)).SetValue$3(fixupObj, arrayIndex);
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(90195820571)
            
            //--TRIMMABLE-BOUNDARY-START(133145493531)
            static /*FieldInfo? */ GetNullableValueField(/*Type*/ type)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(133145493531);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$$.S.Nullable.GetUnderlyingType(type) !== null)
                {
                    return $.$cast(type.GetMemberWithSameMetadataDefinitionAs($.$srsf.SRS.ObjectManager.s_nullableValueField), $.$$.SR.FieldInfo);
                }
                return null;
            }
            //--TRIMMABLE-BOUNDARY-END(133145493531)
            
            //--TRIMMABLE-BOUNDARY-START(73015951387)
            /*void */ CompleteObject(/*ObjectHolder*/ holder, /*bool*/ bObjectFullyComplete)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(73015951387);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*FixupHolderList?*/ let fixups = holder._missingElements;
                /*FixupHolder?*/ let currentFixup;
                /*SerializationInfo?*/ let si;
                /*object?*/ let fixupInfo;
                /*ObjectHolder?*/ let tempObjectHolder;
                /*int*/ let fixupsPerformed = 0;
                $.$$.SD.Debug.Assert$4(holder !== null, "[ObjectManager.CompleteObject]holder.m_object!=null");
                if (holder.ObjectValue === null)
                {
                    throw new $.$$.SRS.SerializationException().$ctor$12($.$srsf.S.SR.Format$6($.$srsf.S.SR.Serialization_MissingObject, $.$box(holder._id, $.$$.S.Int64)));
                }
                if (fixups === null)
                {
                    return;
                }
                if (holder.HasSurrogate || holder.HasISerializable)
                {
                    si = holder._serInfo;
                    if (si === null)
                    {
                        throw new $.$$.SRS.SerializationException().$ctor$12($.$srsf.S.SR.Serialization_InvalidFixupDiscovered);
                    }
                    if (fixups !== null)
                    {
                        for(/*int*/ let i = 0; i < fixups._count; i++)
                        {
                            if ($.$$.System.Array.$ReadT1.call(fixups._values, i) === null)
                            {
                                continue;
                            }
                            $.$$.SD.Debug.Assert$4($.$$.System.Array.$ReadT1.call(fixups._values, i)._fixupType === 4/*FixupHolder.DelayedFixup*/, "fixups.m_values[i].m_fixupType==FixupHolder.DelayedFixup");
                            if (this.GetCompletionInfo($.$$.System.Array.$ReadT1.call(fixups._values, i), $.$ref(() => tempObjectHolder, ($v) => tempObjectHolder = $v, $.$srsf.SRS.ObjectHolder), $.$ref(() => fixupInfo, ($v) => fixupInfo = $v, $.$$.S.Object), bObjectFullyComplete))
                            {
                                /*object?*/ let holderValue = tempObjectHolder.ObjectValue;
                                $.$$.SD.Debug.Assert$4(holderValue !== null, "holderValue != null");
                                if (this.CanCallGetType(holderValue))
                                {
                                    $.$srsf.SRS.SerializationInfoExtensions.UpdateValue(si, $.$cast(fixupInfo, $.$$.S.String), holderValue, $.$$.S.Object.GetType.call(holderValue));
                                }
                                else 
                                {
                                    $.$srsf.SRS.SerializationInfoExtensions.UpdateValue(si, $.$cast(fixupInfo, $.$$.S.String), holderValue, $.$$.S.MarshalByRefObject.$type);
                                }
                                fixupsPerformed++;
                                $.$$.System.Array.$WriteT1.call(fixups._values, null, i);
                                if (!bObjectFullyComplete)
                                {
                                    holder.DecrementFixupsRemaining(this);
                                    tempObjectHolder.RemoveDependency(holder._id);
                                }
                            }
                        }
                    }
                }
                else 
                {
                    for(/*int*/ let i = 0; i < fixups._count; i++)
                    {
                        currentFixup = $.$$.System.Array.$ReadT1.call(fixups._values, i);
                        if (currentFixup === null)
                        {
                            continue;
                        }
                        if (this.GetCompletionInfo(currentFixup, $.$ref(() => tempObjectHolder, ($v) => tempObjectHolder = $v, $.$srsf.SRS.ObjectHolder), $.$ref(() => fixupInfo, ($v) => fixupInfo = $v, $.$$.S.Object), bObjectFullyComplete))
                        {
                            if (tempObjectHolder.TypeLoadExceptionReachable)
                            {
                                holder.TypeLoadException = tempObjectHolder.TypeLoadException;
                                if (holder.Reachable)
                                {
                                    throw new $.$$.SRS.SerializationException().$ctor$12($.$srsf.S.SR.Format$6($.$srsf.S.SR.Serialization_TypeLoadFailure, holder.TypeLoadException.TypeName));
                                }
                            }
                            if (holder.Reachable)
                            {
                                tempObjectHolder.Reachable = true;
                            }
                            var tempMember;
                            let $switch5 = currentFixup._fixupType;
                            switch($switch5)
                            {
                                case 1/*FixupHolder.ArrayFixup*/:
                                $.$$.SD.Debug.Assert$4($.$is(holder.ObjectValue, $.$$.S.Array), "holder.ObjectValue is Array");
                                if (holder.RequiresValueTypeFixup)
                                {
                                    throw new $.$$.SRS.SerializationException().$ctor$12($.$srsf.S.SR.Serialization_ValueTypeFixup);
                                }
                                else 
                                {
                                    ($.$cast((holder.ObjectValue), $.$$.S.Array)).SetValue$3(tempObjectHolder.ObjectValue, ($.$cast(fixupInfo, $.$typeArray($.$$.S.Int32))));
                                }
                                break;
                                case 2/*FixupHolder.MemberFixup*/:
                                $.$$.SD.Debug.Assert$4($.$is(fixupInfo, $.$$.SR.MemberInfo), "fixupInfo is MemberInfo");
                                tempMember = $.$cast(fixupInfo, $.$$.SR.MemberInfo);
                                if ($.$is(tempMember, $.$$.SR.FieldInfo))
                                {
                                    if (holder.RequiresValueTypeFixup && holder.ValueTypeFixupPerformed)
                                    {
                                        if (!this.DoValueTypeFixup($.$cast(tempMember, $.$$.SR.FieldInfo), holder, tempObjectHolder.ObjectValue))
                                        {
                                            throw new $.$$.SRS.SerializationException().$ctor$12($.$srsf.S.SR.Serialization_PartialValueTypeFixup);
                                        }
                                    }
                                    else 
                                    {
                                        $.$srsf.SRS.FormatterServices.SerializationSetValue(tempMember, holder.ObjectValue, tempObjectHolder.ObjectValue);
                                    }
                                    if (tempObjectHolder.RequiresValueTypeFixup)
                                    {
                                        tempObjectHolder.ValueTypeFixupPerformed = true;
                                    }
                                }
                                else 
                                {
                                    throw new $.$$.SRS.SerializationException().$ctor$12($.$srsf.S.SR.Serialization_UnableToFixup);
                                }
                                break;
                                default:
                                throw new $.$$.SRS.SerializationException().$ctor$12($.$srsf.S.SR.Serialization_UnableToFixup);
                            }
                            fixupsPerformed++;
                            $.$$.System.Array.$WriteT1.call(fixups._values, null, i);
                            if (!bObjectFullyComplete)
                            {
                                holder.DecrementFixupsRemaining(this);
                                tempObjectHolder.RemoveDependency(holder._id);
                            }
                        }
                    }
                }
                this._fixupCount -= BigInt(fixupsPerformed);
                if (fixups._count === fixupsPerformed)
                {
                    holder._missingElements = null;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(73015951387)
            
            //--TRIMMABLE-BOUNDARY-START(85900853275)
            /*void */ DoNewlyRegisteredObjectFixups(/*ObjectHolder*/ holder)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(85900853275);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (holder.CanObjectValueChange)
                {
                    return;
                }
                /*LongList?*/ let dependencies = holder.DependentObjects;
                if (dependencies === null)
                {
                    return;
                }
                dependencies.StartEnumeration();
                while(dependencies.MoveNext())
                {
                    /*ObjectHolder?*/ let temp = this.FindObjectHolder(dependencies.Current);
                    $.$$.SD.Debug.Assert$4(temp !== null, "temp != null");
                    $.$$.SD.Debug.Assert$4(temp.DirectlyDependentObjects > 0, "temp.m_missingElementsRemaining>0");
                    temp.DecrementFixupsRemaining(this);
                    if (((temp.DirectlyDependentObjects)) === 0)
                    {
                        if (temp.ObjectValue !== null)
                        {
                            this.CompleteObject(temp, true);
                        }
                        else 
                        {
                            temp.MarkForCompletionWhenAvailable();
                        }
                    }
                }
            }
            //--TRIMMABLE-BOUNDARY-END(85900853275)
            
            //--TRIMMABLE-BOUNDARY-START(137440460827)
            /*object? */ GetObject(/*long*/ objectID)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(137440460827);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (objectID <= 0n)
                {
                    throw new $.$$.S.ArgumentOutOfRangeException().$ctor$19("objectID", $.$srsf.S.SR.ArgumentOutOfRange_ObjectID);
                }
                /*ObjectHolder?*/ let holder = this.FindObjectHolder(objectID);
                if (holder === null || holder.CanObjectValueChange)
                {
                    return null;
                }
                return holder.ObjectValue;
            }
            //--TRIMMABLE-BOUNDARY-END(137440460827)
            
            //--TRIMMABLE-BOUNDARY-START(201864970267)
            /*void */ RegisterObject$3(/*object*/ obj, /*long*/ objectID)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(201864970267);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.RegisterObject$1(obj, objectID, null, 0n, null);
            }
            //--TRIMMABLE-BOUNDARY-END(201864970267)
            
            //--TRIMMABLE-BOUNDARY-START(197570002971)
            /*void */ RegisterObject$2(/*object*/ obj, /*long*/ objectID, /*SerializationInfo*/ info)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(197570002971);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.RegisterObject$1(obj, objectID, info, 0n, null);
            }
            //--TRIMMABLE-BOUNDARY-END(197570002971)
            
            //--TRIMMABLE-BOUNDARY-START(193275035675)
            /*void */ RegisterObject$1(/*object*/ obj, /*long*/ objectID, /*SerializationInfo?*/ info, /*long*/ idOfContainingObj, /*MemberInfo?*/ member)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(193275035675);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.RegisterObject(obj, objectID, info, idOfContainingObj, member, null);
            }
            //--TRIMMABLE-BOUNDARY-END(193275035675)
            
            //--TRIMMABLE-BOUNDARY-START(206159937563)
            /*void */ RegisterString(/*string?*/ obj, /*long*/ objectID, /*SerializationInfo?*/ info, /*long*/ idOfContainingObj, /*MemberInfo?*/ member)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(206159937563);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*ObjectHolder*/ let temp;
                $.$$.SD.Debug.Assert$4($.$$.SR.MemberInfo.op_Equality(member, null) || $.$is(member, $.$$.SR.FieldInfo), "RegisterString - member is FieldInfo");
                temp = new $.$srsf.SRS.ObjectHolder().$ctor$3(obj, objectID, info, null, idOfContainingObj, $.$cast(member, $.$$.SR.FieldInfo), null);
                this.AddObjectHolder(temp);
                return;
            }
            //--TRIMMABLE-BOUNDARY-END(206159937563)
            
            //--TRIMMABLE-BOUNDARY-START(188980068379)
            /*void */ RegisterObject(/*object*/ obj, /*long*/ objectID, /*SerializationInfo?*/ info, /*long*/ idOfContainingObj, /*MemberInfo?*/ member, /*int[]?*/ arrayIndex)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(188980068379);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.S.ArgumentNullException.ThrowIfNull$2(obj, "obj");
                if (objectID <= 0n)
                {
                    throw new $.$$.S.ArgumentOutOfRangeException().$ctor$19("objectID", $.$srsf.S.SR.ArgumentOutOfRange_ObjectID);
                }
                if ($.$$.SR.MemberInfo.op_Inequality(member, null) && !($.$is(member, $.$$.SR.FieldInfo)))
                {
                    throw new $.$$.SRS.SerializationException().$ctor$12($.$srsf.S.SR.Serialization_UnknownMemberInfo);
                }
                /*ObjectHolder?*/ let temp;
                /*ISerializationSurrogate?*/ let surrogate = null;
                /*ISurrogateSelector*/ let useless;
                if (this._selector !== null)
                {
                    /*Type*/ let selectorType = this.CanCallGetType(obj) ? $.$$.S.Object.GetType.call(obj) : $.$$.S.MarshalByRefObject.$type;
                    surrogate = this._selector.SRS$ISurrogateSelector$GetSurrogate(selectorType, this._context, $.$ref(() => useless, ($v) => useless = $v, $.$srsf.SRS.ISurrogateSelector));
                }
                if ($.$is(obj, $.$$.SRS.IDeserializationCallback))
                {
                    let $t7 = ($.$cast(obj, $.$$.SRS.IDeserializationCallback));
                    /*DeserializationEventHandler*/ let d = new $.$srsf.SRS.DeserializationEventHandler().$ctor($t7, $t7.SRS$IDeserializationCallback$OnDeserialization);
                    this.AddOnDeserialization(d);
                }
                if (arrayIndex !== null)
                {
                    arrayIndex = $.$cast(arrayIndex.Clone(), $.$typeArray($.$$.S.Int32));
                }
                temp = this.FindObjectHolder(objectID);
                if (temp === null)
                {
                    temp = new $.$srsf.SRS.ObjectHolder().$ctor$2(obj, objectID, info, surrogate, idOfContainingObj, $.$cast(member, $.$$.SR.FieldInfo), arrayIndex);
                    this.AddObjectHolder(temp);
                    if (temp.RequiresDelayedFixup)
                    {
                        this.SpecialFixupObjects.Add(temp);
                    }
                    this.AddOnDeserialized(obj);
                    return;
                }
                if (temp.ObjectValue !== null)
                {
                    throw new $.$$.SRS.SerializationException().$ctor$12($.$srsf.S.SR.Serialization_RegisterTwice);
                }
                temp.UpdateData(obj, info, surrogate, idOfContainingObj, $.$cast(member, $.$$.SR.FieldInfo), arrayIndex, this);
                if (temp.DirectlyDependentObjects > 0)
                {
                    this.CompleteObject(temp, false);
                }
                if (temp.RequiresDelayedFixup)
                {
                    this.SpecialFixupObjects.Add(temp);
                }
                if (temp.CompletelyFixed)
                {
                    this.DoNewlyRegisteredObjectFixups(temp);
                    temp.DependentObjects = null;
                }
                if (temp.TotalDependentObjects > 0)
                {
                    this.AddOnDeserialized(obj);
                }
                else 
                {
                    this.RaiseOnDeserializedEvent(obj);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(188980068379)
            
            //--TRIMMABLE-BOUNDARY-START(68720984091)
            /*void */ CompleteISerializableObject(/*object*/ obj, /*SerializationInfo?*/ info, /*StreamingContext*/ context)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(68720984091);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.S.ArgumentNullException.ThrowIfNull$2(obj, "obj");
                if (!($.$is(obj, $.$$.SRS.ISerializable)))
                {
                    throw new $.$$.S.ArgumentException().$ctor$14($.$srsf.S.SR.Serialization_NotISer);
                }
                /*ConstructorInfo*/ let constInfo;
                /*Type*/ let t = $.$$.S.Object.GetType.call(obj);
                try
                {
                    constInfo = $.$srsf.SRS.ObjectManager.GetDeserializationConstructor(t);
                }
                catch(e)
                {
                    throw new $.$$.SRS.SerializationException().$ctor$11($.$srsf.S.SR.Format$6($.$srsf.S.SR.Serialization_ConstructorNotFound, t), e);
                }
                constInfo.Invoke(obj, $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Object), [info, context], [-1], null));
            }
            //--TRIMMABLE-BOUNDARY-END(68720984091)
            
            //--TRIMMABLE-BOUNDARY-START(128850526235)
            static /*ConstructorInfo */ GetDeserializationConstructor(/*Type*/ t)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(128850526235);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                let $i8 = 0;
                let $arr8 = t.GetConstructors$1(16/*BindingFlags.Public*/ | 32/*BindingFlags.NonPublic*/ | 4/*BindingFlags.Instance*/ | 2/*BindingFlags.DeclaredOnly*/);
                while ($i8 < $arr8.length)
                {
                    let ci = $arr8[$i8++];
                    /*ParameterInfo[]*/ let parameters = ci.GetParameters();
                    if (parameters.length === 2 && $.$$.System.Array.$ReadT1.call(parameters, 0).ParameterType === $.$$.SRS.SerializationInfo.$type && $.$$.System.Array.$ReadT1.call(parameters, 1).ParameterType === $.$$.SRS.StreamingContext.$type)
                    {
                        return ci;
                    }
                }
                throw new $.$$.SRS.SerializationException().$ctor$12($.$srsf.S.SR.Format$6($.$srsf.S.SR.Serialization_ConstructorNotFound, t.FullName));
            }
            //--TRIMMABLE-BOUNDARY-END(128850526235)
            
            //--TRIMMABLE-BOUNDARY-START(81605885979)
            /*void */ DoFixups()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(81605885979);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*ObjectHolder?*/ let temp;
                /*int*/ let fixupCount = -1;
                while(fixupCount !== 0)
                {
                    fixupCount = 0;
                    /*ObjectHolderListEnumerator*/ let fixupObjectsEnum = this.SpecialFixupObjects.GetFixupEnumerator();
                    while(fixupObjectsEnum.MoveNext())
                    {
                        temp = fixupObjectsEnum.Current;
                        if (temp.ObjectValue === null)
                        {
                            throw new $.$$.SRS.SerializationException().$ctor$12($.$srsf.S.SR.Format$6($.$srsf.S.SR.Serialization_ObjectNotSupplied, $.$box(temp._id, $.$$.S.Int64)));
                        }
                        if (temp.TotalDependentObjects === 0)
                        {
                            if (temp.RequiresSerInfoFixup)
                            {
                                this.FixupSpecialObject(temp);
                                fixupCount++;
                            }
                            else if (!temp.IsIncompleteObjectReference)
                            {
                                this.CompleteObject(temp, true);
                            }
                            if (temp.IsIncompleteObjectReference && this.ResolveObjectReference(temp))
                            {
                                fixupCount++;
                            }
                        }
                    }
                }
                $.$$.SD.Debug.Assert$4(this._fixupCount >= 0n, "[ObjectManager.DoFixups]m_fixupCount>=0");
                if (this._fixupCount === 0n)
                {
                    if ($.$is(this.TopObject, $.$srsf.SRS.TypeLoadExceptionHolder))
                    {
                        throw new $.$$.SRS.SerializationException().$ctor$12($.$srsf.S.SR.Format$6($.$srsf.S.SR.Serialization_TypeLoadFailure, ($.$cast(this.TopObject, $.$srsf.SRS.TypeLoadExceptionHolder)).TypeName));
                    }
                    return;
                }
                for(/*int*/ let i = 0; i < this._objects.length; i++)
                {
                    temp = $.$$.System.Array.$ReadT1.call(this._objects, i);
                    while(temp !== null)
                    {
                        if (temp.TotalDependentObjects > 0)
                        {
                            this.CompleteObject(temp, true);
                        }
                        temp = temp._next;
                    }
                    if (this._fixupCount === 0n)
                    {
                        return;
                    }
                }
                throw new $.$$.SRS.SerializationException().$ctor$12($.$srsf.S.SR.Serialization_IncorrectNumberOfFixups);
            }
            //--TRIMMABLE-BOUNDARY-END(81605885979)
            
            //--TRIMMABLE-BOUNDARY-START(184685101083)
            /*void */ RegisterFixup(/*FixupHolder*/ fixup, /*long*/ objectToBeFixed, /*long*/ objectRequired)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(184685101083);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*ObjectHolder*/ let ohToBeFixed = this.FindOrCreateObjectHolder(objectToBeFixed);
                /*ObjectHolder*/ let ohRequired;
                if (ohToBeFixed.RequiresSerInfoFixup && fixup._fixupType === 2/*FixupHolder.MemberFixup*/)
                {
                    throw new $.$$.SRS.SerializationException().$ctor$12($.$srsf.S.SR.Serialization_InvalidFixupType);
                }
                ohToBeFixed.AddFixup(fixup, this);
                ohRequired = this.FindOrCreateObjectHolder(objectRequired);
                ohRequired.AddDependency(objectToBeFixed);
                this._fixupCount++;
            }
            //--TRIMMABLE-BOUNDARY-END(184685101083)
            
            //--TRIMMABLE-BOUNDARY-START(180390133787)
            /*void */ RecordFixup(/*long*/ objectToBeFixed, /*MemberInfo*/ member, /*long*/ objectRequired)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(180390133787);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (objectToBeFixed <= 0n || objectRequired <= 0n)
                {
                    throw new $.$$.S.ArgumentOutOfRangeException().$ctor$19(objectToBeFixed <= 0n ? "objectToBeFixed" : "objectRequired", $.$srsf.S.SR.Serialization_IdTooSmall);
                }
                $.$$.S.ArgumentNullException.ThrowIfNull$2(member, "member");
                if (!($.$is(member, $.$$.SR.FieldInfo)))
                {
                    throw new $.$$.SRS.SerializationException().$ctor$12($.$srsf.S.SR.Format$6($.$srsf.S.SR.Serialization_InvalidType, $.$$.S.Object.GetType.call(member)));
                }
                /*FixupHolder*/ let fixup = new $.$srsf.SRS.FixupHolder().$ctor$1(objectRequired, member, 2/*FixupHolder.MemberFixup*/);
                this.RegisterFixup(fixup, objectToBeFixed, objectRequired);
            }
            //--TRIMMABLE-BOUNDARY-END(180390133787)
            
            //--TRIMMABLE-BOUNDARY-START(176095166491)
            /*void */ RecordDelayedFixup(/*long*/ objectToBeFixed, /*string*/ memberName, /*long*/ objectRequired)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(176095166491);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (objectToBeFixed <= 0n || objectRequired <= 0n)
                {
                    throw new $.$$.S.ArgumentOutOfRangeException().$ctor$19(objectToBeFixed <= 0n ? "objectToBeFixed" : "objectRequired", $.$srsf.S.SR.Serialization_IdTooSmall);
                }
                $.$$.S.ArgumentNullException.ThrowIfNull$2(memberName, "memberName");
                /*FixupHolder*/ let fixup = new $.$srsf.SRS.FixupHolder().$ctor$1(objectRequired, memberName, 4/*FixupHolder.DelayedFixup*/);
                this.RegisterFixup(fixup, objectToBeFixed, objectRequired);
            }
            //--TRIMMABLE-BOUNDARY-END(176095166491)
            
            //--TRIMMABLE-BOUNDARY-START(167505231899)
            /*void */ RecordArrayElementFixup(/*long*/ arrayToBeFixed, /*int*/ index, /*long*/ objectRequired)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(167505231899);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*int[]*/ let indexArray = $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Int32), null, [1], null);
                $.$$.System.Array.$WriteT1.call(indexArray, index, 0);
                this.RecordArrayElementFixup$1(arrayToBeFixed, indexArray, objectRequired);
            }
            //--TRIMMABLE-BOUNDARY-END(167505231899)
            
            //--TRIMMABLE-BOUNDARY-START(171800199195)
            /*void */ RecordArrayElementFixup$1(/*long*/ arrayToBeFixed, /*int[]*/ indices, /*long*/ objectRequired)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(171800199195);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (arrayToBeFixed <= 0n || objectRequired <= 0n)
                {
                    throw new $.$$.S.ArgumentOutOfRangeException().$ctor$19(arrayToBeFixed <= 0n ? "arrayToBeFixed" : "objectRequired", $.$srsf.S.SR.Serialization_IdTooSmall);
                }
                $.$$.S.ArgumentNullException.ThrowIfNull$2(indices, "indices");
                /*FixupHolder*/ let fixup = new $.$srsf.SRS.FixupHolder().$ctor$1(objectRequired, indices, 1/*FixupHolder.ArrayFixup*/);
                this.RegisterFixup(fixup, arrayToBeFixed, objectRequired);
            }
            //--TRIMMABLE-BOUNDARY-END(171800199195)
            
            //--TRIMMABLE-BOUNDARY-START(154620330011)
            /*void */ RaiseDeserializationEvent()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(154620330011);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this._onDeserializedHandler?.Invoke(this._context);
                this._onDeserializationHandler?.Invoke(null);
            }
            //--TRIMMABLE-BOUNDARY-END(154620330011)
            
            //--TRIMMABLE-BOUNDARY-START(51541114907)
            /*void */ AddOnDeserialization(/*DeserializationEventHandler*/ handler)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(51541114907);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this._onDeserializationHandler = $.$cast($.$$.S.Delegate.Combine$2(this._onDeserializationHandler, handler), $.$srsf.SRS.DeserializationEventHandler);
            }
            //--TRIMMABLE-BOUNDARY-END(51541114907)
            
            //--TRIMMABLE-BOUNDARY-START(55836082203)
            /*void */ AddOnDeserialized(/*object*/ obj)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(55836082203);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*SerializationEvents*/ let cache = $.$srsf.SRS.SerializationEventsCache.GetSerializationEventsForType($.$$.S.Object.GetType.call(obj));
                this._onDeserializedHandler = cache.AddOnDeserialized(obj, this._onDeserializedHandler);
            }
            //--TRIMMABLE-BOUNDARY-END(55836082203)
            
            //--TRIMMABLE-BOUNDARY-START(158915297307)
            /*void */ RaiseOnDeserializedEvent(/*object*/ obj)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(158915297307);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*SerializationEvents*/ let cache = $.$srsf.SRS.SerializationEventsCache.GetSerializationEventsForType($.$$.S.Object.GetType.call(obj));
                cache.InvokeOnDeserialized(obj, this._context);
            }
            //--TRIMMABLE-BOUNDARY-END(158915297307)
            
            //--TRIMMABLE-BOUNDARY-START(163210264603)
            /*void */ RaiseOnDeserializingEvent(/*object*/ obj)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(163210264603);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*SerializationEvents*/ let cache = $.$srsf.SRS.SerializationEventsCache.GetSerializationEventsForType($.$$.S.Object.GetType.call(obj));
                cache.InvokeOnDeserializing(obj, this._context);
            }
            //--TRIMMABLE-BOUNDARY-END(163210264603)
            
            //default member initializer
            constructor()
            {
                super();
                //--TRIMMABLE-BOUNDARY-START(4296474651)
                this._context = $.$default($.$$.SRS.StreamingContext);
                //--TRIMMABLE-BOUNDARY-END(4296474651)
                
            }
            //--TRIMMABLE-BOUNDARY-START(38656213019)
            //Static Initializer
            static $sinit()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(38656213019);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                {
                    //--TRIMMABLE-BOUNDARY-START(150325362715)
                    this.ObjectManagerUnreferencedCodeMessage = "ObjectManager is not trim compatible because the type of objects being managed cannot be statically discovered.";
                    //--TRIMMABLE-BOUNDARY-END(150325362715)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(214749872155)
                    this.s_nullableValueField = $.$$.S.Nullable$$().$type.GetField$1("value", 32/*BindingFlags.NonPublic*/ | 4/*BindingFlags.Instance*/);
                    //--TRIMMABLE-BOUNDARY-END(214749872155)
                    
                }
            }
            //--TRIMMABLE-BOUNDARY-END(38656213019)
            
            static $h = 1507355;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(231929741339),
    {
      "p": 131073,
      "g": {
        "r": 0,
        "d": 0,
        "h": 120260591643,
        "f": 50331656
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 223339806747,
        "f": 83886088
      },
      "n": "TopObject",
      "d": 1507355,
      "h": 231929741339,
      "f": 2097160
    },
//--TRIMMABLE-BOUNDARY-END(231929741339),
//--TRIMMABLE-BOUNDARY-START(227634774043),
    {
      "p": 1310747,
      "g": {
        "r": 0,
        "d": 0,
        "h": 111670657051,
        "f": 50331656
      },
      "n": "SpecialFixupObjects",
      "d": 1507355,
      "h": 227634774043,
      "f": 2097160
    },
//--TRIMMABLE-BOUNDARY-END(227634774043)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(64426016795),
    {
      "r": 262145,
      "p": [
        {
          "n": "obj",
          "p": 131073
        }
      ],
      "n": "CanCallGetType",
      "d": 1507355,
      "h": 64426016795,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(64426016795),
//--TRIMMABLE-BOUNDARY-START(94490787867),
    {
      "r": 1245211,
      "p": [
        {
          "n": "objectID",
          "p": 917505
        }
      ],
      "n": "FindObjectHolder",
      "d": 1507355,
      "h": 94490787867,
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(94490787867),
//--TRIMMABLE-BOUNDARY-START(98785755163),
    {
      "r": 1245211,
      "p": [
        {
          "n": "objectID",
          "p": 917505
        }
      ],
      "n": "FindOrCreateObjectHolder",
      "d": 1507355,
      "h": 98785755163,
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(98785755163),
//--TRIMMABLE-BOUNDARY-START(47246147611),
    {
      "r": 65537,
      "p": [
        {
          "n": "holder",
          "p": 1245211
        }
      ],
      "n": "AddObjectHolder",
      "d": 1507355,
      "h": 47246147611,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(47246147611),
//--TRIMMABLE-BOUNDARY-START(124555558939),
    {
      "r": 262145,
      "p": [
        {
          "n": "fixup",
          "p": 262171
        },
        {
          "n": "holder",
          "p": 1245211,
          "f": 2
        },
        {
          "n": "member",
          "p": 131073,
          "f": 2
        },
        {
          "n": "bThrowIfMissing",
          "p": 262145
        }
      ],
      "n": "GetCompletionInfo",
      "d": 1507355,
      "h": 124555558939,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(124555558939),
//--TRIMMABLE-BOUNDARY-START(103080722459),
    {
      "r": 65537,
      "p": [
        {
          "n": "holder",
          "p": 1245211
        }
      ],
      "n": "FixupSpecialObject",
      "d": 1507355,
      "h": 103080722459,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(103080722459),
//--TRIMMABLE-BOUNDARY-START(210454904859),
    {
      "r": 262145,
      "p": [
        {
          "n": "holder",
          "p": 1245211
        }
      ],
      "n": "ResolveObjectReference",
      "d": 1507355,
      "h": 210454904859,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(210454904859),
//--TRIMMABLE-BOUNDARY-START(90195820571),
    {
      "r": 262145,
      "p": [
        {
          "n": "memberToFix",
          "p": 114622465
        },
        {
          "n": "holder",
          "p": 1245211
        },
        {
          "n": "value",
          "p": 131073
        }
      ],
      "n": "DoValueTypeFixup",
      "d": 1507355,
      "h": 90195820571,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(90195820571),
//--TRIMMABLE-BOUNDARY-START(133145493531),
    {
      "r": 114622465,
      "p": [
        {
          "n": "type",
          "p": 188547073
        }
      ],
      "n": "GetNullableValueField",
      "d": 1507355,
      "h": 133145493531,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(133145493531),
//--TRIMMABLE-BOUNDARY-START(73015951387),
    {
      "r": 65537,
      "p": [
        {
          "n": "holder",
          "p": 1245211
        },
        {
          "n": "bObjectFullyComplete",
          "p": 262145
        }
      ],
      "n": "CompleteObject",
      "d": 1507355,
      "h": 73015951387,
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(73015951387),
//--TRIMMABLE-BOUNDARY-START(85900853275),
    {
      "r": 65537,
      "p": [
        {
          "n": "holder",
          "p": 1245211
        }
      ],
      "n": "DoNewlyRegisteredObjectFixups",
      "d": 1507355,
      "h": 85900853275,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(85900853275),
//--TRIMMABLE-BOUNDARY-START(137440460827),
    {
      "r": 131073,
      "p": [
        {
          "n": "objectID",
          "p": 917505
        }
      ],
      "n": "GetObject",
      "d": 1507355,
      "h": 137440460827,
      "f": 16777345
    },
//--TRIMMABLE-BOUNDARY-END(137440460827),
//--TRIMMABLE-BOUNDARY-START(201864970267),
    {
      "r": 65537,
      "p": [
        {
          "n": "obj",
          "p": 131073
        },
        {
          "n": "objectID",
          "p": 917505
        }
      ],
      "n": "RegisterObject",
      "o": "@$3",
      "d": 1507355,
      "h": 201864970267,
      "f": 16777345
    },
//--TRIMMABLE-BOUNDARY-END(201864970267),
//--TRIMMABLE-BOUNDARY-START(197570002971),
    {
      "r": 65537,
      "p": [
        {
          "n": "obj",
          "p": 131073
        },
        {
          "n": "objectID",
          "p": 917505
        },
        {
          "n": "info",
          "p": 158859265
        }
      ],
      "n": "RegisterObject",
      "o": "@$2",
      "d": 1507355,
      "h": 197570002971,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(197570002971),
//--TRIMMABLE-BOUNDARY-START(193275035675),
    {
      "r": 65537,
      "p": [
        {
          "n": "obj",
          "p": 131073
        },
        {
          "n": "objectID",
          "p": 917505
        },
        {
          "n": "info",
          "p": 158859265
        },
        {
          "n": "idOfContainingObj",
          "p": 917505
        },
        {
          "n": "member",
          "p": 116195329
        }
      ],
      "n": "RegisterObject",
      "o": "@$1",
      "d": 1507355,
      "h": 193275035675,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(193275035675),
//--TRIMMABLE-BOUNDARY-START(206159937563),
    {
      "r": 65537,
      "p": [
        {
          "n": "obj",
          "p": 1310721
        },
        {
          "n": "objectID",
          "p": 917505
        },
        {
          "n": "info",
          "p": 158859265
        },
        {
          "n": "idOfContainingObj",
          "p": 917505
        },
        {
          "n": "member",
          "p": 116195329
        }
      ],
      "n": "RegisterString",
      "d": 1507355,
      "h": 206159937563,
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(206159937563),
//--TRIMMABLE-BOUNDARY-START(188980068379),
    {
      "r": 65537,
      "p": [
        {
          "n": "obj",
          "p": 131073
        },
        {
          "n": "objectID",
          "p": 917505
        },
        {
          "n": "info",
          "p": 158859265
        },
        {
          "n": "idOfContainingObj",
          "p": 917505
        },
        {
          "n": "member",
          "p": 116195329
        },
        {
          "n": "arrayIndex",
          "p": $.$typeArray($.$$.S.Int32).$h
        }
      ],
      "n": "RegisterObject",
      "d": 1507355,
      "h": 188980068379,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(188980068379),
//--TRIMMABLE-BOUNDARY-START(68720984091),
    {
      "r": 65537,
      "p": [
        {
          "n": "obj",
          "p": 131073
        },
        {
          "n": "info",
          "p": 158859265
        },
        {
          "n": "context",
          "p": 158990337
        }
      ],
      "n": "CompleteISerializableObject",
      "d": 1507355,
      "h": 68720984091,
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(68720984091),
//--TRIMMABLE-BOUNDARY-START(128850526235),
    {
      "r": 109182977,
      "p": [
        {
          "n": "t",
          "p": 188547073
        }
      ],
      "n": "GetDeserializationConstructor",
      "d": 1507355,
      "h": 128850526235,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(128850526235),
//--TRIMMABLE-BOUNDARY-START(81605885979),
    {
      "r": 65537,
      "n": "DoFixups",
      "d": 1507355,
      "h": 81605885979,
      "f": 16777345
    },
//--TRIMMABLE-BOUNDARY-END(81605885979),
//--TRIMMABLE-BOUNDARY-START(184685101083),
    {
      "r": 65537,
      "p": [
        {
          "n": "fixup",
          "p": 262171
        },
        {
          "n": "objectToBeFixed",
          "p": 917505
        },
        {
          "n": "objectRequired",
          "p": 917505
        }
      ],
      "n": "RegisterFixup",
      "d": 1507355,
      "h": 184685101083,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(184685101083),
//--TRIMMABLE-BOUNDARY-START(180390133787),
    {
      "r": 65537,
      "p": [
        {
          "n": "objectToBeFixed",
          "p": 917505
        },
        {
          "n": "member",
          "p": 116195329
        },
        {
          "n": "objectRequired",
          "p": 917505
        }
      ],
      "n": "RecordFixup",
      "d": 1507355,
      "h": 180390133787,
      "f": 16777345
    },
//--TRIMMABLE-BOUNDARY-END(180390133787),
//--TRIMMABLE-BOUNDARY-START(176095166491),
    {
      "r": 65537,
      "p": [
        {
          "n": "objectToBeFixed",
          "p": 917505
        },
        {
          "n": "memberName",
          "p": 1310721
        },
        {
          "n": "objectRequired",
          "p": 917505
        }
      ],
      "n": "RecordDelayedFixup",
      "d": 1507355,
      "h": 176095166491,
      "f": 16777345
    },
//--TRIMMABLE-BOUNDARY-END(176095166491),
//--TRIMMABLE-BOUNDARY-START(167505231899),
    {
      "r": 65537,
      "p": [
        {
          "n": "arrayToBeFixed",
          "p": 917505
        },
        {
          "n": "index",
          "p": 655361
        },
        {
          "n": "objectRequired",
          "p": 917505
        }
      ],
      "n": "RecordArrayElementFixup",
      "d": 1507355,
      "h": 167505231899,
      "f": 16777345
    },
//--TRIMMABLE-BOUNDARY-END(167505231899),
//--TRIMMABLE-BOUNDARY-START(171800199195),
    {
      "r": 65537,
      "p": [
        {
          "n": "arrayToBeFixed",
          "p": 917505
        },
        {
          "n": "indices",
          "p": $.$typeArray($.$$.S.Int32).$h
        },
        {
          "n": "objectRequired",
          "p": 917505
        }
      ],
      "n": "RecordArrayElementFixup",
      "o": "@$1",
      "d": 1507355,
      "h": 171800199195,
      "f": 16777345
    },
//--TRIMMABLE-BOUNDARY-END(171800199195),
//--TRIMMABLE-BOUNDARY-START(154620330011),
    {
      "r": 65537,
      "n": "RaiseDeserializationEvent",
      "d": 1507355,
      "h": 154620330011,
      "f": 16777345
    },
//--TRIMMABLE-BOUNDARY-END(154620330011),
//--TRIMMABLE-BOUNDARY-START(51541114907),
    {
      "r": 65537,
      "p": [
        {
          "n": "handler",
          "p": 196635
        }
      ],
      "n": "AddOnDeserialization",
      "d": 1507355,
      "h": 51541114907,
      "f": 16777352
    },
//--TRIMMABLE-BOUNDARY-END(51541114907),
//--TRIMMABLE-BOUNDARY-START(55836082203),
    {
      "r": 65537,
      "p": [
        {
          "n": "obj",
          "p": 131073
        }
      ],
      "n": "AddOnDeserialized",
      "d": 1507355,
      "h": 55836082203,
      "f": 16777352
    },
//--TRIMMABLE-BOUNDARY-END(55836082203),
//--TRIMMABLE-BOUNDARY-START(158915297307),
    {
      "r": 65537,
      "p": [
        {
          "n": "obj",
          "p": 131073
        }
      ],
      "n": "RaiseOnDeserializedEvent",
      "d": 1507355,
      "h": 158915297307,
      "f": 16777352
    },
//--TRIMMABLE-BOUNDARY-END(158915297307),
//--TRIMMABLE-BOUNDARY-START(163210264603),
    {
      "r": 65537,
      "p": [
        {
          "n": "obj",
          "p": 131073
        }
      ],
      "n": "RaiseOnDeserializingEvent",
      "d": 1507355,
      "h": 163210264603,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(163210264603)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(77310918683),
    {
      "t": 655361,
      "n": "DefaultInitialSize",
      "d": 1507355,
      "h": 77310918683,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(77310918683),
//--TRIMMABLE-BOUNDARY-START(141735428123),
    {
      "t": 655361,
      "n": "MaxArraySize",
      "d": 1507355,
      "h": 141735428123,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(141735428123),
//--TRIMMABLE-BOUNDARY-START(60131049499),
    {
      "t": 655361,
      "n": "ArrayMask",
      "d": 1507355,
      "h": 60131049499,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(60131049499),
//--TRIMMABLE-BOUNDARY-START(146030395419),
    {
      "t": 655361,
      "n": "MaxReferenceDepth",
      "d": 1507355,
      "h": 146030395419,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(146030395419),
//--TRIMMABLE-BOUNDARY-START(150325362715),
    {
      "t": 1310721,
      "n": "ObjectManagerUnreferencedCodeMessage",
      "d": 1507355,
      "h": 150325362715,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(150325362715),
//--TRIMMABLE-BOUNDARY-START(214749872155),
    {
      "t": 114622465,
      "n": "s_nullableValueField",
      "d": 1507355,
      "h": 214749872155,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(214749872155),
//--TRIMMABLE-BOUNDARY-START(17181376539),
    {
      "t": 196635,
      "n": "_onDeserializationHandler",
      "d": 1507355,
      "h": 17181376539,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(17181376539),
//--TRIMMABLE-BOUNDARY-START(21476343835),
    {
      "t": 1638427,
      "n": "_onDeserializedHandler",
      "d": 1507355,
      "h": 21476343835,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(21476343835),
//--TRIMMABLE-BOUNDARY-START(12886409243),
    {
      "t": $.$typeArray($.$srsf.SRS.ObjectHolder).$h,
      "n": "_objects",
      "d": 1507355,
      "h": 12886409243,
      "f": 4194312
    },
//--TRIMMABLE-BOUNDARY-END(12886409243),
//--TRIMMABLE-BOUNDARY-START(34361245723),
    {
      "t": 131073,
      "n": "_topObject",
      "d": 1507355,
      "h": 34361245723,
      "f": 4194312
    },
//--TRIMMABLE-BOUNDARY-END(34361245723),
//--TRIMMABLE-BOUNDARY-START(30066278427),
    {
      "t": 1310747,
      "n": "_specialFixupObjects",
      "d": 1507355,
      "h": 30066278427,
      "f": 4194312
    },
//--TRIMMABLE-BOUNDARY-END(30066278427),
//--TRIMMABLE-BOUNDARY-START(8591441947),
    {
      "t": 917505,
      "n": "_fixupCount",
      "d": 1507355,
      "h": 8591441947,
      "f": 4194312
    },
//--TRIMMABLE-BOUNDARY-END(8591441947),
//--TRIMMABLE-BOUNDARY-START(25771311131),
    {
      "t": 1048603,
      "n": "_selector",
      "d": 1507355,
      "h": 25771311131,
      "f": 4194312
    },
//--TRIMMABLE-BOUNDARY-END(25771311131),
//--TRIMMABLE-BOUNDARY-START(4296474651),
    {
      "t": 158990337,
      "n": "_context",
      "d": 1507355,
      "h": 4296474651,
      "f": 4194312
    },
//--TRIMMABLE-BOUNDARY-END(4296474651)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(42951180315),
    {
      "p": [
        {
          "n": "selector",
          "p": 1048603
        },
        {
          "n": "context",
          "p": 158990337
        }
      ],
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 1507355,
      "h": 42951180315,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(42951180315)
  ],
  "h": 1507355,
  "a": [
    {
      "t": 104464385,
      "c": 30169235457,
      "a": [
        {
          "v": "Formatter-based serialization is obsolete and should not be used.",
          "t": 1310721
        }
      ],
      "n": [
        {
          "n": "DiagnosticId",
          "v": "SYSLIB0050",
          "t": 1310721
        },
        {
          "n": "UrlFormat",
          "v": "https://aka.ms/dotnet-warnings/{0}",
          "t": 1310721
        }
      ]
    }
  ]
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `System.Runtime.Serialization.ObjectManager`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `System${separator}Runtime${separator}Serialization${separator}ObjectManager`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1507355)
        
        

        //--TRIMMABLE-BOUNDARY-START(1441819)
        $asm.$cls(`$srsf.SRS.ObjectIDGenerator`, ($self) => class ObjectIDGenerator extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(38656147483)
            /*int*/ static NumBins = 4;
            //--TRIMMABLE-BOUNDARY-END(38656147483)
            
            //--TRIMMABLE-BOUNDARY-START(4296409115)
            /*int*/ _currentCount = 0;
            //--TRIMMABLE-BOUNDARY-END(4296409115)
            
            //--TRIMMABLE-BOUNDARY-START(8591376411)
            /*int*/ _currentSize = 0;
            //--TRIMMABLE-BOUNDARY-END(8591376411)
            
            //--TRIMMABLE-BOUNDARY-START(12886343707)
            /*long[]*/ _ids = null;
            //--TRIMMABLE-BOUNDARY-END(12886343707)
            
            //--TRIMMABLE-BOUNDARY-START(17181311003)
            /*object[]*/ _objs = null;
            //--TRIMMABLE-BOUNDARY-END(17181311003)
            
            //--TRIMMABLE-BOUNDARY-START(21476278299)
            $ctor$1()
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(21476278299);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this._currentCount = 1;
                    this._currentSize = 3;
                    this._ids = $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Int64), null, [((this._currentSize * 4/*NumBins*/) | 0)], null);
                    this._objs = $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Object), null, [((this._currentSize * 4/*NumBins*/) | 0)], null);
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(21476278299)
            
            //--TRIMMABLE-BOUNDARY-START(25771245595)
            /*int */ FindElement(/*object*/ obj, /*out bool*/ found)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25771245595);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*int*/ let hashcode = $.$$.SRC.RuntimeHelpers.GetHashCode$1(obj);
                /*int*/ let hashIncrement = (((1 + ((hashcode & 2147483647) % (((this._currentSize - 2) | 0)))) | 0));
                do
                {
                    /*int*/ let pos = ((((hashcode & 2147483647) % this._currentSize) * 4/*NumBins*/) | 0);
                    for(/*int*/ let i = pos; i < ((pos + 4/*NumBins*/) | 0); i++)
                    {
                        if ($.$$.System.Array.$ReadT1.call(this._objs, i) === null)
                        {
                            found.$v = false;
                            return i;
                        }
                        if ($.$$.System.Array.$ReadT1.call(this._objs, i) === obj)
                        {
                            found.$v = true;
                            return i;
                        }
                    }
                    hashcode += hashIncrement;
                }
                while(true);
            }
            //--TRIMMABLE-BOUNDARY-END(25771245595)
            
            //--TRIMMABLE-BOUNDARY-START(30066212891)
            /*long */ GetId(/*object*/ obj, /*out bool*/ firstTime)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(30066212891);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.S.ArgumentNullException.ThrowIfNull$2(obj, "obj");
                /*bool*/ let found;
                /*int*/ let pos = this.FindElement(obj, $.$ref(() => found, ($v) => found = $v, $.$$.S.Boolean));
                /*long*/ let foundID;
                if (!found)
                {
                    $.$$.System.Array.$WriteT1.call(this._objs, obj, pos);
                    $.$$.System.Array.$WriteT1.call(this._ids, BigInt(this._currentCount++), pos);
                    foundID = $.$$.System.Array.$ReadT1.call(this._ids, pos);
                    if (this._currentCount > $.trunc((((this._currentSize * 4/*NumBins*/) | 0)) / 2))
                    {
                        this.Rehash();
                    }
                }
                else 
                {
                    foundID = $.$$.System.Array.$ReadT1.call(this._ids, pos);
                }
                firstTime.$v = !found;
                return foundID;
            }
            //--TRIMMABLE-BOUNDARY-END(30066212891)
            
            //--TRIMMABLE-BOUNDARY-START(34361180187)
            /*long */ HasId(/*object*/ obj, /*out bool*/ firstTime)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(34361180187);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.S.ArgumentNullException.ThrowIfNull$2(obj, "obj");
                /*bool*/ let found;
                /*int*/ let pos = this.FindElement(obj, $.$ref(() => found, ($v) => found = $v, $.$$.S.Boolean));
                if (found)
                {
                    firstTime.$v = false;
                    return $.$$.System.Array.$ReadT1.call(this._ids, pos);
                }
                firstTime.$v = true;
                return 0n;
            }
            //--TRIMMABLE-BOUNDARY-END(34361180187)
            
            //--TRIMMABLE-BOUNDARY-START(42951114779)
            /*void */ Rehash()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(42951114779);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*int*/ let currSize = this._currentSize;
                /*int*/ let newSize = $.$srsf.SC.HashHelpers.ExpandPrime(currSize);
                if (newSize === currSize)
                {
                    throw new $.$$.SRS.SerializationException().$ctor$12($.$srsf.S.SR.Serialization_TooManyElements);
                }
                this._currentSize = newSize;
                /*long[]*/ let newIds = $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Int64), null, [((this._currentSize * 4/*NumBins*/) | 0)], null);
                /*object[]*/ let newObjs = $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Object), null, [((this._currentSize * 4/*NumBins*/) | 0)], null);
                /*long[]*/ let oldIds = this._ids;
                /*object[]*/ let oldObjs = this._objs;
                this._ids = newIds;
                this._objs = newObjs;
                for(/*int*/ let j = 0; j < oldObjs.length; j++)
                {
                    if ($.$$.System.Array.$ReadT1.call(oldObjs, j) !== null)
                    {
                        /*int*/ let pos = this.FindElement($.$$.System.Array.$ReadT1.call(oldObjs, j), $.$discardRef());
                        $.$$.System.Array.$WriteT1.call(this._objs, $.$$.System.Array.$ReadT1.call(oldObjs, j), pos);
                        $.$$.System.Array.$WriteT1.call(this._ids, $.$$.System.Array.$ReadT1.call(oldIds, j), pos);
                    }
                }
            }
            //--TRIMMABLE-BOUNDARY-END(42951114779)
            
            //--TRIMMABLE-BOUNDARY-START(21476278299)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(21476278299)
            
            static $h = 1441819;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(25771245595),
    {
      "r": 655361,
      "p": [
        {
          "n": "obj",
          "p": 131073
        },
        {
          "n": "found",
          "p": 262145,
          "f": 2
        }
      ],
      "n": "FindElement",
      "d": 1441819,
      "h": 25771245595,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(25771245595),
//--TRIMMABLE-BOUNDARY-START(30066212891),
    {
      "r": 917505,
      "p": [
        {
          "n": "obj",
          "p": 131073
        },
        {
          "n": "firstTime",
          "p": 262145,
          "f": 2
        }
      ],
      "n": "GetId",
      "d": 1441819,
      "h": 30066212891,
      "f": 16777345
    },
//--TRIMMABLE-BOUNDARY-END(30066212891),
//--TRIMMABLE-BOUNDARY-START(34361180187),
    {
      "r": 917505,
      "p": [
        {
          "n": "obj",
          "p": 131073
        },
        {
          "n": "firstTime",
          "p": 262145,
          "f": 2
        }
      ],
      "n": "HasId",
      "d": 1441819,
      "h": 34361180187,
      "f": 16777345
    },
//--TRIMMABLE-BOUNDARY-END(34361180187),
//--TRIMMABLE-BOUNDARY-START(42951114779),
    {
      "r": 65537,
      "n": "Rehash",
      "d": 1441819,
      "h": 42951114779,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(42951114779)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(38656147483),
    {
      "t": 655361,
      "n": "NumBins",
      "d": 1441819,
      "h": 38656147483,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(38656147483),
//--TRIMMABLE-BOUNDARY-START(4296409115),
    {
      "t": 655361,
      "n": "_currentCount",
      "d": 1441819,
      "h": 4296409115,
      "f": 4194312
    },
//--TRIMMABLE-BOUNDARY-END(4296409115),
//--TRIMMABLE-BOUNDARY-START(8591376411),
    {
      "t": 655361,
      "n": "_currentSize",
      "d": 1441819,
      "h": 8591376411,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(8591376411),
//--TRIMMABLE-BOUNDARY-START(12886343707),
    {
      "t": $.$typeArray($.$$.S.Int64).$h,
      "n": "_ids",
      "d": 1441819,
      "h": 12886343707,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(12886343707),
//--TRIMMABLE-BOUNDARY-START(17181311003),
    {
      "t": $.$typeArray($.$$.S.Object).$h,
      "n": "_objs",
      "d": 1441819,
      "h": 17181311003,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(17181311003)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(21476278299),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 1441819,
      "h": 21476278299,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(21476278299)
  ],
  "h": 1441819,
  "a": [
    {
      "t": 104464385,
      "c": 30169235457,
      "a": [
        {
          "v": "Formatter-based serialization is obsolete and should not be used.",
          "t": 1310721
        }
      ],
      "n": [
        {
          "n": "DiagnosticId",
          "v": "SYSLIB0050",
          "t": 1310721
        },
        {
          "n": "UrlFormat",
          "v": "https://aka.ms/dotnet-warnings/{0}",
          "t": 1310721
        }
      ]
    }
  ]
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `System.Runtime.Serialization.ObjectIDGenerator`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `System${separator}Runtime${separator}Serialization${separator}ObjectIDGenerator`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1441819)
        
        

        //--TRIMMABLE-BOUNDARY-START(2359323)
        $asm.$cls(`$srsf.SRS.ValueTypeFixupInfo`, ($self) => class ValueTypeFixupInfo extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(4297326619)
            /*long*/ _containerID = 0n;
            //--TRIMMABLE-BOUNDARY-END(4297326619)
            
            //--TRIMMABLE-BOUNDARY-START(8592293915)
            /*FieldInfo?*/ _parentField = null;
            //--TRIMMABLE-BOUNDARY-END(8592293915)
            
            //--TRIMMABLE-BOUNDARY-START(12887261211)
            /*int[]?*/ _parentIndex = null;
            //--TRIMMABLE-BOUNDARY-END(12887261211)
            
            //--TRIMMABLE-BOUNDARY-START(17182228507)
            $ctor$1(/*long*/ containerID, /*FieldInfo?*/ member, /*int[]?*/ parentIndex)
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(17182228507);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    if ($.$$.SR.FieldInfo.op_Equality$1(member, null) && parentIndex === null)
                    {
                        throw new $.$$.S.ArgumentException().$ctor$14($.$srsf.S.SR.Argument_MustSupplyParent);
                    }
                    if (containerID === 0n && $.$$.SR.FieldInfo.op_Equality$1(member, null))
                    {
                        this._containerID = containerID;
                        this._parentField = member;
                        this._parentIndex = parentIndex;
                    }
                    if ($.$$.SR.FieldInfo.op_Inequality$1(member, null))
                    {
                        if (parentIndex !== null)
                        {
                            throw new $.$$.S.ArgumentException().$ctor$14($.$srsf.S.SR.Argument_MemberAndArray);
                        }
                        if (member.FieldType.IsValueType && containerID === 0n)
                        {
                            throw new $.$$.S.ArgumentException().$ctor$14($.$srsf.S.SR.Argument_MustSupplyContainer);
                        }
                    }
                    this._containerID = containerID;
                    this._parentField = member;
                    this._parentIndex = parentIndex;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(17182228507)
            
            //--TRIMMABLE-BOUNDARY-START(21477195803)
            /*long */ get ContainerID()
            {
                return this._containerID;
            }
            //--TRIMMABLE-BOUNDARY-END(21477195803)
            
            //--TRIMMABLE-BOUNDARY-START(51541966875)
            /*FieldInfo? */ get ParentField()
            {
                return this._parentField;
            }
            //--TRIMMABLE-BOUNDARY-END(51541966875)
            
            //--TRIMMABLE-BOUNDARY-START(55836934171)
            /*int[]? */ get ParentIndex()
            {
                return this._parentIndex;
            }
            //--TRIMMABLE-BOUNDARY-END(55836934171)
            
            static $h = 2359323;
            static $f = 0b10010000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(21477195803),
    {
      "p": 917505,
      "g": {
        "r": 0,
        "d": 0,
        "h": 30067130395,
        "f": 50331649
      },
      "n": "ContainerID",
      "d": 2359323,
      "h": 21477195803,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(21477195803),
//--TRIMMABLE-BOUNDARY-START(51541966875),
    {
      "p": 114622465,
      "g": {
        "r": 0,
        "d": 0,
        "h": 38657064987,
        "f": 50331649
      },
      "n": "ParentField",
      "d": 2359323,
      "h": 51541966875,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(51541966875),
//--TRIMMABLE-BOUNDARY-START(55836934171),
    {
      "p": $.$typeArray($.$$.S.Int32).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 47246999579,
        "f": 50331649
      },
      "n": "ParentIndex",
      "d": 2359323,
      "h": 55836934171,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(55836934171)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(4297326619),
    {
      "t": 917505,
      "n": "_containerID",
      "d": 2359323,
      "h": 4297326619,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(4297326619),
//--TRIMMABLE-BOUNDARY-START(8592293915),
    {
      "t": 114622465,
      "n": "_parentField",
      "d": 2359323,
      "h": 8592293915,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(8592293915),
//--TRIMMABLE-BOUNDARY-START(12887261211),
    {
      "t": $.$typeArray($.$$.S.Int32).$h,
      "n": "_parentIndex",
      "d": 2359323,
      "h": 12887261211,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(12887261211)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(17182228507),
    {
      "p": [
        {
          "n": "containerID",
          "p": 917505
        },
        {
          "n": "member",
          "p": 114622465
        },
        {
          "n": "parentIndex",
          "p": $.$typeArray($.$$.S.Int32).$h
        }
      ],
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 2359323,
      "h": 17182228507,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(17182228507)
  ],
  "h": 2359323
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `System.Runtime.Serialization.ValueTypeFixupInfo`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `System${separator}Runtime${separator}Serialization${separator}ValueTypeFixupInfo`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2359323)
        
        

        //--TRIMMABLE-BOUNDARY-START(1769499)
        $asm.$cls(`$srsf.SRS.SerializationEventsCache`, ($self) => class SerializationEventsCache
        {
            //--TRIMMABLE-BOUNDARY-START(17181638683)
            /*ConcurrentDictionary<Type, SerializationEvents>*/ static s_cache = null;
            //--TRIMMABLE-BOUNDARY-END(17181638683)
            
            //--TRIMMABLE-BOUNDARY-START(12886671387)
            static /*SerializationEvents */ GetSerializationEventsForType(/*Type*/ t)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(12886671387);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return $.$srsf.SRS.SerializationEventsCache.s_cache.GetOrAdd(t, new ($.$$.S.Func$$$($.$$.S.Type, $.$srsf.SRS.SerializationEvents))().$ctor($.$srsf.SRS.SerializationEventsCache, $.$srsf.SRS.SerializationEventsCache.CreateSerializationEvents));
                }
            }
            //--TRIMMABLE-BOUNDARY-END(12886671387)
            
            //--TRIMMABLE-BOUNDARY-START(8591704091)
            static /*SerializationEvents */ CreateSerializationEvents(/*Type*/ t)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(8591704091);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return new $.$srsf.SRS.SerializationEvents().$ctor$1(t);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(8591704091)
            
            //--TRIMMABLE-BOUNDARY-START(4296736795)
            //Static Initializer
            static $sinit()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296736795);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                {
                    //--TRIMMABLE-BOUNDARY-START(17181638683)
                    this.s_cache = new ($.$scc.SCC.ConcurrentDictionary$$$($.$$.S.Type, $.$srsf.SRS.SerializationEvents))().$ctor$1();
                    //--TRIMMABLE-BOUNDARY-END(17181638683)
                    
                }
            }
            //--TRIMMABLE-BOUNDARY-END(4296736795)
            
            static $h = 1769499;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(12886671387),
    {
      "r": 1703963,
      "p": [
        {
          "n": "t",
          "p": 188547073
        }
      ],
      "n": "GetSerializationEventsForType",
      "d": 1769499,
      "h": 12886671387,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(12886671387),
//--TRIMMABLE-BOUNDARY-START(8591704091),
    {
      "r": 1703963,
      "p": [
        {
          "n": "t",
          "p": 188547073
        }
      ],
      "n": "CreateSerializationEvents",
      "d": 1769499,
      "h": 8591704091,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(8591704091)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(17181638683),
    {
      "t": $.$scc.SCC.ConcurrentDictionary$$$($.$$.S.Type, $.$srsf.SRS.SerializationEvents).$h,
      "n": "s_cache",
      "d": 1769499,
      "h": 17181638683,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(17181638683)
  ],
  "h": 1769499
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `System.Runtime.Serialization.SerializationEventsCache`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `System${separator}Runtime${separator}Serialization${separator}SerializationEventsCache`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1769499)
        
        

        //--TRIMMABLE-BOUNDARY-START(2162715)
        $asm.$cls(`$srsf.SRS.SurrogateKey`, ($self) => class SurrogateKey extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8592097307)
            /*Type*/ _type = null;
            //--TRIMMABLE-BOUNDARY-END(8592097307)
            
            //--TRIMMABLE-BOUNDARY-START(4297130011)
            /*StreamingContext*/ _context;
            //--TRIMMABLE-BOUNDARY-END(4297130011)
            
            //--TRIMMABLE-BOUNDARY-START(12887064603)
            $ctor$1(/*Type*/ type, /*StreamingContext*/ context)
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(12887064603);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$$.SD.Debug.Assert$4(type !== null, "type != null");
                    this._type = type;
                    this._context = context;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(12887064603)
            
            //--TRIMMABLE-BOUNDARY-START(17182031899)
            /*int */ GetHashCode()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(17182031899);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return this._type.GetHashCode();
                }
            }
            //--TRIMMABLE-BOUNDARY-END(17182031899)
            
            //default member initializer
            constructor()
            {
                super();
                //--TRIMMABLE-BOUNDARY-START(4297130011)
                this._context = $.$default($.$$.SRS.StreamingContext);
                //--TRIMMABLE-BOUNDARY-END(4297130011)
                
            }
            static $h = 2162715;
            static $f = 0b10010000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(17182031899),
    {
      "r": 655361,
      "n": "GetHashCode",
      "d": 2162715,
      "h": 17182031899,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(17182031899)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(8592097307),
    {
      "t": 188547073,
      "n": "_type",
      "d": 2162715,
      "h": 8592097307,
      "f": 4194312
    },
//--TRIMMABLE-BOUNDARY-END(8592097307),
//--TRIMMABLE-BOUNDARY-START(4297130011),
    {
      "t": 158990337,
      "n": "_context",
      "d": 2162715,
      "h": 4297130011,
      "f": 4194312
    },
//--TRIMMABLE-BOUNDARY-END(4297130011)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(12887064603),
    {
      "p": [
        {
          "n": "type",
          "p": 188547073
        },
        {
          "n": "context",
          "p": 158990337
        }
      ],
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 2162715,
      "h": 12887064603,
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(12887064603)
  ],
  "h": 2162715
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `System.Runtime.Serialization.SurrogateKey`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `System${separator}Runtime${separator}Serialization${separator}SurrogateKey`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2162715)
        
        

        //--TRIMMABLE-BOUNDARY-START(1245211)
        $asm.$cls(`$srsf.SRS.ObjectHolder`, ($self) => class ObjectHolder extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(313533857819)
            /*int*/ static IncompleteObjectReference = 1;
            //--TRIMMABLE-BOUNDARY-END(313533857819)
            
            //--TRIMMABLE-BOUNDARY-START(296353988635)
            /*int*/ static HAS_ISERIALIZABLE = 2;
            //--TRIMMABLE-BOUNDARY-END(296353988635)
            
            //--TRIMMABLE-BOUNDARY-START(300648955931)
            /*int*/ static HAS_SURROGATE = 4;
            //--TRIMMABLE-BOUNDARY-END(300648955931)
            
            //--TRIMMABLE-BOUNDARY-START(347893596187)
            /*int*/ static REQUIRES_VALUETYPE_FIXUP = 8;
            //--TRIMMABLE-BOUNDARY-END(347893596187)
            
            //--TRIMMABLE-BOUNDARY-START(343598628891)
            /*int*/ static REQUIRES_DELAYED_FIXUP = 7;
            //--TRIMMABLE-BOUNDARY-END(343598628891)
            
            //--TRIMMABLE-BOUNDARY-START(365073465371)
            /*int*/ static SER_INFO_FIXED = 16384;
            //--TRIMMABLE-BOUNDARY-END(365073465371)
            
            //--TRIMMABLE-BOUNDARY-START(472447647771)
            /*int*/ static VALUETYPE_FIXUP_PERFORMED = 32768;
            //--TRIMMABLE-BOUNDARY-END(472447647771)
            
            //--TRIMMABLE-BOUNDARY-START(38655950875)
            /*object?*/ _object = null;
            //--TRIMMABLE-BOUNDARY-END(38655950875)
            
            //--TRIMMABLE-BOUNDARY-START(12886147099)
            /*long*/ _id = 0n;
            //--TRIMMABLE-BOUNDARY-END(12886147099)
            
            //--TRIMMABLE-BOUNDARY-START(30066016283)
            /*int*/ _missingElementsRemaining = 0;
            //--TRIMMABLE-BOUNDARY-END(30066016283)
            
            //--TRIMMABLE-BOUNDARY-START(21476081691)
            /*int*/ _missingDecendents = 0;
            //--TRIMMABLE-BOUNDARY-END(21476081691)
            
            //--TRIMMABLE-BOUNDARY-START(47245885467)
            /*SerializationInfo?*/ _serInfo = null;
            //--TRIMMABLE-BOUNDARY-END(47245885467)
            
            //--TRIMMABLE-BOUNDARY-START(51540852763)
            /*ISerializationSurrogate?*/ _surrogate = null;
            //--TRIMMABLE-BOUNDARY-END(51540852763)
            
            //--TRIMMABLE-BOUNDARY-START(25771048987)
            /*FixupHolderList?*/ _missingElements = null;
            //--TRIMMABLE-BOUNDARY-END(25771048987)
            
            //--TRIMMABLE-BOUNDARY-START(4296212507)
            /*LongList?*/ _dependentObjects = null;
            //--TRIMMABLE-BOUNDARY-END(4296212507)
            
            //--TRIMMABLE-BOUNDARY-START(34360983579)
            /*ObjectHolder?*/ _next = null;
            //--TRIMMABLE-BOUNDARY-END(34360983579)
            
            //--TRIMMABLE-BOUNDARY-START(8591179803)
            /*int*/ _flags = 0;
            //--TRIMMABLE-BOUNDARY-END(8591179803)
            
            //--TRIMMABLE-BOUNDARY-START(17181114395)
            /*bool*/ _markForFixupWhenAvailable = false;
            //--TRIMMABLE-BOUNDARY-END(17181114395)
            
            //--TRIMMABLE-BOUNDARY-START(60130787355)
            /*ValueTypeFixupInfo?*/ _valueFixup = null;
            //--TRIMMABLE-BOUNDARY-END(60130787355)
            
            //--TRIMMABLE-BOUNDARY-START(55835820059)
            /*TypeLoadExceptionHolder?*/ _typeLoad = null;
            //--TRIMMABLE-BOUNDARY-END(55835820059)
            
            //--TRIMMABLE-BOUNDARY-START(42950918171)
            /*bool*/ _reachable = false;
            //--TRIMMABLE-BOUNDARY-END(42950918171)
            
            //--TRIMMABLE-BOUNDARY-START(64425754651)
            $ctor$1(/*long*/ objID)
            {
                this.$ctor$3(null, objID, null, null, 0n, null, null);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(64425754651);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(64425754651)
            
            //--TRIMMABLE-BOUNDARY-START(68720721947)
            $ctor$2(/*object?*/ obj, /*long*/ objID, /*SerializationInfo?*/ info, /*ISerializationSurrogate?*/ surrogate, /*long*/ idOfContainingObj, /*FieldInfo?*/ field, /*int[]?*/ arrayIndex)
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(68720721947);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$$.SD.Debug.Assert$4(objID >= 0n, "objID>=0");
                    this._object = obj;
                    this._id = objID;
                    this._flags = 0;
                    this._missingElementsRemaining = 0;
                    this._missingDecendents = 0;
                    this._dependentObjects = null;
                    this._next = null;
                    this._serInfo = info;
                    this._surrogate = surrogate;
                    this._markForFixupWhenAvailable = false;
                    if ($.$is(obj, $.$srsf.SRS.TypeLoadExceptionHolder))
                    {
                        this._typeLoad = $.$cast(obj, $.$srsf.SRS.TypeLoadExceptionHolder);
                    }
                    if (idOfContainingObj !== 0n && (($.$$.SR.FieldInfo.op_Inequality$1(field, null) && field.FieldType.IsValueType) || arrayIndex !== null))
                    {
                        if (idOfContainingObj === objID)
                        {
                            throw new $.$$.SRS.SerializationException().$ctor$12($.$srsf.S.SR.Serialization_ParentChildIdentical);
                        }
                        this._valueFixup = new $.$srsf.SRS.ValueTypeFixupInfo().$ctor$1(idOfContainingObj, field, arrayIndex);
                    }
                    this.SetFlags();
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(68720721947)
            
            //--TRIMMABLE-BOUNDARY-START(73015689243)
            $ctor$3(/*string?*/ obj, /*long*/ objID, /*SerializationInfo?*/ info, /*ISerializationSurrogate?*/ surrogate, /*long*/ idOfContainingObj, /*FieldInfo?*/ field, /*int[]?*/ arrayIndex)
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(73015689243);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$$.SD.Debug.Assert$4(objID >= 0n, "objID>=0");
                    this._object = obj;
                    this._id = objID;
                    this._flags = 0;
                    this._missingElementsRemaining = 0;
                    this._missingDecendents = 0;
                    this._dependentObjects = null;
                    this._next = null;
                    this._serInfo = info;
                    this._surrogate = surrogate;
                    this._markForFixupWhenAvailable = false;
                    if (idOfContainingObj !== 0n && arrayIndex !== null)
                    {
                        this._valueFixup = new $.$srsf.SRS.ValueTypeFixupInfo().$ctor$1(idOfContainingObj, field, arrayIndex);
                    }
                    if (this._valueFixup !== null)
                    {
                        this._flags |= 8/*REQUIRES_VALUETYPE_FIXUP*/;
                    }
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(73015689243)
            
            //--TRIMMABLE-BOUNDARY-START(317828825115)
            /*void */ IncrementDescendentFixups(/*int*/ amount)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(317828825115);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return this._missingDecendents += amount;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(317828825115)
            
            //--TRIMMABLE-BOUNDARY-START(103080460315)
            /*void */ DecrementFixupsRemaining(/*ObjectManager*/ manager)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(103080460315);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this._missingElementsRemaining--;
                if (this.RequiresValueTypeFixup)
                {
                    this.UpdateDescendentDependencyChain(-1, manager);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(103080460315)
            
            //--TRIMMABLE-BOUNDARY-START(339303661595)
            /*void */ RemoveDependency(/*long*/ id)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(339303661595);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.SD.Debug.Assert$4(this._dependentObjects !== null, "[ObjectHolder.RemoveDependency]m_dependentObjects!=null");
                $.$$.SD.Debug.Assert$4(id >= 0n, "[ObjectHolder.RemoveDependency]id>=0");
                this._dependentObjects.RemoveElement(id);
            }
            //--TRIMMABLE-BOUNDARY-END(339303661595)
            
            //--TRIMMABLE-BOUNDARY-START(81605623835)
            /*void */ AddFixup(/*FixupHolder*/ fixup, /*ObjectManager*/ manager)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(81605623835);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this._missingElements ??= new $.$srsf.SRS.FixupHolderList().$ctor$1();
                this._missingElements.Add(fixup);
                this._missingElementsRemaining++;
                if (this.RequiresValueTypeFixup)
                {
                    this.UpdateDescendentDependencyChain(1, manager);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(81605623835)
            
            //--TRIMMABLE-BOUNDARY-START(463857713179)
            /*void */ UpdateDescendentDependencyChain(/*int*/ amount, /*ObjectManager*/ manager)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(463857713179);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*ObjectHolder*/ let holder = this;
                do
                {
                    holder = manager.FindOrCreateObjectHolder(holder.ContainerID);
                    $.$$.SD.Debug.Assert$4(holder !== null, "[ObjectHolder.UpdateTotalDependencyChain]holder!=null");
                    holder.IncrementDescendentFixups(amount);
                }
                while(holder.RequiresValueTypeFixup);
            }
            //--TRIMMABLE-BOUNDARY-END(463857713179)
            
            //--TRIMMABLE-BOUNDARY-START(77310656539)
            /*void */ AddDependency(/*long*/ dependentObject)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(77310656539);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this._dependentObjects ??= new $.$srsf.SRS.LongList().$ctor$1();
                this._dependentObjects.Add(dependentObject);
            }
            //--TRIMMABLE-BOUNDARY-END(77310656539)
            
            //--TRIMMABLE-BOUNDARY-START(459562745883)
            /*void */ UpdateData(/*object*/ obj, /*SerializationInfo?*/ info, /*ISerializationSurrogate?*/ surrogate, /*long*/ idOfContainer, /*FieldInfo?*/ field, /*int[]?*/ arrayIndex, /*ObjectManager*/ manager)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(459562745883);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.SD.Debug.Assert$4(obj !== null, "obj!=null");
                $.$$.SD.Debug.Assert$4(this._id > 0n, "m_id>0");
                this.SetObjectValue(obj, manager);
                this._serInfo = info;
                this._surrogate = surrogate;
                if (idOfContainer !== 0n && (($.$$.SR.FieldInfo.op_Inequality$1(field, null) && field.FieldType.IsValueType) || arrayIndex !== null))
                {
                    if (idOfContainer === this._id)
                    {
                        throw new $.$$.SRS.SerializationException().$ctor$12($.$srsf.S.SR.Serialization_ParentChildIdentical);
                    }
                    this._valueFixup = new $.$srsf.SRS.ValueTypeFixupInfo().$ctor$1(idOfContainer, field, arrayIndex);
                }
                this.SetFlags();
                if (this.RequiresValueTypeFixup)
                {
                    this.UpdateDescendentDependencyChain(this._missingElementsRemaining, manager);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(459562745883)
            
            //--TRIMMABLE-BOUNDARY-START(326418759707)
            /*void */ MarkForCompletionWhenAvailable()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(326418759707);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return this._markForFixupWhenAvailable = true;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(326418759707)
            
            //--TRIMMABLE-BOUNDARY-START(433792942107)
            /*void */ SetFlags()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(433792942107);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$is(this._object, $.$$.SRS.IObjectReference))
                {
                    this._flags |= 1/*IncompleteObjectReference*/;
                }
                this._flags &= ~(2/*HAS_ISERIALIZABLE*/ | 4/*HAS_SURROGATE*/);
                if (this._surrogate !== null)
                {
                    this._flags |= 4/*HAS_SURROGATE*/;
                }
                else if ($.$is(this._object, $.$$.SRS.ISerializable))
                {
                    this._flags |= 2/*HAS_ISERIALIZABLE*/;
                }
                if (this._valueFixup !== null)
                {
                    this._flags |= 8/*REQUIRES_VALUETYPE_FIXUP*/;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(433792942107)
            
            //--TRIMMABLE-BOUNDARY-START(322123792411)
            /*bool */ get IsIncompleteObjectReference()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(188979806235);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return (this._flags & 1/*IncompleteObjectReference*/) !== 0;
            }
            /*bool */ set IsIncompleteObjectReference(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(386548301851);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (value)
                {
                    this._flags |= 1/*IncompleteObjectReference*/;
                }
                else 
                {
                    this._flags &= ~1/*IncompleteObjectReference*/;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(322123792411)
            
            //--TRIMMABLE-BOUNDARY-START(352188563483)
            /*bool */ get RequiresDelayedFixup()
            {
                return (this._flags & 7/*REQUIRES_DELAYED_FIXUP*/) !== 0;
            }
            //--TRIMMABLE-BOUNDARY-END(352188563483)
            
            //--TRIMMABLE-BOUNDARY-START(360778498075)
            /*bool */ get RequiresValueTypeFixup()
            {
                return (this._flags & 8/*REQUIRES_VALUETYPE_FIXUP*/) !== 0;
            }
            //--TRIMMABLE-BOUNDARY-END(360778498075)
            
            //--TRIMMABLE-BOUNDARY-START(476742615067)
            /*bool */ get ValueTypeFixupPerformed()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(292059021339);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return (((this._flags & 32768/*VALUETYPE_FIXUP_PERFORMED*/) !== 0) || (this._object !== null && ((this._dependentObjects === null) || this._dependentObjects.Count === 0)));
            }
            /*bool */ set ValueTypeFixupPerformed(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(429497974811);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (value)
                {
                    this._flags |= 32768/*VALUETYPE_FIXUP_PERFORMED*/;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(476742615067)
            
            //--TRIMMABLE-BOUNDARY-START(304943923227)
            /*bool */ get HasISerializable()
            {
                return (this._flags & 2/*HAS_ISERIALIZABLE*/) !== 0;
            }
            //--TRIMMABLE-BOUNDARY-END(304943923227)
            
            //--TRIMMABLE-BOUNDARY-START(309238890523)
            /*bool */ get HasSurrogate()
            {
                return (this._flags & 4/*HAS_SURROGATE*/) !== 0;
            }
            //--TRIMMABLE-BOUNDARY-END(309238890523)
            
            //--TRIMMABLE-BOUNDARY-START(90195558427)
            /*bool */ get CanSurrogatedObjectValueChange()
            {
                return (this._surrogate === null || $.$$.S.Object.GetType.call(this._surrogate) !== $.$srsf.SRS.SurrogateForCyclicalReference.$type);
            }
            //--TRIMMABLE-BOUNDARY-END(90195558427)
            
            //--TRIMMABLE-BOUNDARY-START(85900591131)
            /*bool */ get CanObjectValueChange()
            {
                return this.IsIncompleteObjectReference ? true : this.HasSurrogate ? this.CanSurrogatedObjectValueChange : false;
            }
            //--TRIMMABLE-BOUNDARY-END(85900591131)
            
            //--TRIMMABLE-BOUNDARY-START(111670394907)
            /*int */ get DirectlyDependentObjects()
            {
                return this._missingElementsRemaining;
            }
            //--TRIMMABLE-BOUNDARY-END(111670394907)
            
            //--TRIMMABLE-BOUNDARY-START(446677843995)
            /*int */ get TotalDependentObjects()
            {
                return ((this._missingElementsRemaining + this._missingDecendents) | 0);
            }
            //--TRIMMABLE-BOUNDARY-END(446677843995)
            
            //--TRIMMABLE-BOUNDARY-START(335008694299)
            /*bool */ get Reachable()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(206159675419);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this._reachable;
            }
            /*bool */ set Reachable(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(395138236443);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this._reachable = value;
            }
            //--TRIMMABLE-BOUNDARY-END(335008694299)
            
            //--TRIMMABLE-BOUNDARY-START(455267778587)
            /*bool */ get TypeLoadExceptionReachable()
            {
                return this._typeLoad !== null;
            }
            //--TRIMMABLE-BOUNDARY-END(455267778587)
            
            //--TRIMMABLE-BOUNDARY-START(450972811291)
            /*TypeLoadExceptionHolder? */ get TypeLoadException()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(266289217563);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this._typeLoad;
            }
            /*TypeLoadExceptionHolder? */ set TypeLoadException(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(420908040219);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this._typeLoad = value;
            }
            //--TRIMMABLE-BOUNDARY-END(450972811291)
            
            //--TRIMMABLE-BOUNDARY-START(330713727003)
            /*object? */ get ObjectValue()
            {
                return this._object;
            }
            //--TRIMMABLE-BOUNDARY-END(330713727003)
            
            //--TRIMMABLE-BOUNDARY-START(438087909403)
            /*void */ SetObjectValue(/*object?*/ obj, /*ObjectManager*/ manager)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(438087909403);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this._object = obj;
                if (obj === manager.TopObject)
                {
                    this._reachable = true;
                }
                if ($.$is(obj, $.$srsf.SRS.TypeLoadExceptionHolder))
                {
                    this._typeLoad = $.$cast(obj, $.$srsf.SRS.TypeLoadExceptionHolder);
                }
                if (this._markForFixupWhenAvailable)
                {
                    manager.CompleteObject(this, true);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(438087909403)
            
            //--TRIMMABLE-BOUNDARY-START(369368432667)
            /*SerializationInfo? */ get SerializationInfo()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(240519413787);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this._serInfo;
            }
            /*SerializationInfo? */ set SerializationInfo(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(412318105627);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this._serInfo = value;
            }
            //--TRIMMABLE-BOUNDARY-END(369368432667)
            
            //--TRIMMABLE-BOUNDARY-START(442382876699)
            /*ISerializationSurrogate? */ get Surrogate()
            {
                return this._surrogate;
            }
            //--TRIMMABLE-BOUNDARY-END(442382876699)
            
            //--TRIMMABLE-BOUNDARY-START(107375427611)
            /*LongList? */ get DependentObjects()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(154620067867);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this._dependentObjects;
            }
            /*LongList? */ set DependentObjects(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(377958367259);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this._dependentObjects = value;
            }
            //--TRIMMABLE-BOUNDARY-END(107375427611)
            
            //--TRIMMABLE-BOUNDARY-START(356483530779)
            /*bool */ get RequiresSerInfoFixup()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(223339544603);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (((this._flags & 4/*HAS_SURROGATE*/) === 0) && ((this._flags & 2/*HAS_ISERIALIZABLE*/) === 0))
                {
                    return false;
                }
                return (this._flags & 16384/*SER_INFO_FIXED*/) === 0;
            }
            /*bool */ set RequiresSerInfoFixup(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(403728171035);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (!value)
                {
                    this._flags |= 16384/*SER_INFO_FIXED*/;
                }
                else 
                {
                    this._flags &= ~16384/*SER_INFO_FIXED*/;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(356483530779)
            
            //--TRIMMABLE-BOUNDARY-START(468152680475)
            /*ValueTypeFixupInfo? */ get ValueFixup()
            {
                return this._valueFixup;
            }
            //--TRIMMABLE-BOUNDARY-END(468152680475)
            
            //--TRIMMABLE-BOUNDARY-START(94490525723)
            /*bool */ get CompletelyFixed()
            {
                return !this.RequiresSerInfoFixup && !this.IsIncompleteObjectReference;
            }
            //--TRIMMABLE-BOUNDARY-END(94490525723)
            
            //--TRIMMABLE-BOUNDARY-START(98785493019)
            /*long */ get ContainerID()
            {
                return this._valueFixup !== null ? this._valueFixup.ContainerID : 0n;
            }
            //--TRIMMABLE-BOUNDARY-END(98785493019)
            
            static $h = 1245211;
            static $f = 0b10010000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(322123792411),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 188979806235,
        "f": 50331656
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 386548301851,
        "f": 83886088
      },
      "n": "IsIncompleteObjectReference",
      "d": 1245211,
      "h": 322123792411,
      "f": 2097160
    },
//--TRIMMABLE-BOUNDARY-END(322123792411),
//--TRIMMABLE-BOUNDARY-START(352188563483),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 214749610011,
        "f": 50331656
      },
      "n": "RequiresDelayedFixup",
      "d": 1245211,
      "h": 352188563483,
      "f": 2097160
    },
//--TRIMMABLE-BOUNDARY-END(352188563483),
//--TRIMMABLE-BOUNDARY-START(360778498075),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 231929479195,
        "f": 50331656
      },
      "n": "RequiresValueTypeFixup",
      "d": 1245211,
      "h": 360778498075,
      "f": 2097160
    },
//--TRIMMABLE-BOUNDARY-END(360778498075),
//--TRIMMABLE-BOUNDARY-START(476742615067),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 292059021339,
        "f": 50331656
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 429497974811,
        "f": 83886088
      },
      "n": "ValueTypeFixupPerformed",
      "d": 1245211,
      "h": 476742615067,
      "f": 2097160
    },
//--TRIMMABLE-BOUNDARY-END(476742615067),
//--TRIMMABLE-BOUNDARY-START(304943923227),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 171799937051,
        "f": 50331656
      },
      "n": "HasISerializable",
      "d": 1245211,
      "h": 304943923227,
      "f": 2097160
    },
//--TRIMMABLE-BOUNDARY-END(304943923227),
//--TRIMMABLE-BOUNDARY-START(309238890523),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 180389871643,
        "f": 50331656
      },
      "n": "HasSurrogate",
      "d": 1245211,
      "h": 309238890523,
      "f": 2097160
    },
//--TRIMMABLE-BOUNDARY-END(309238890523),
//--TRIMMABLE-BOUNDARY-START(90195558427),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 128850264091,
        "f": 50331656
      },
      "n": "CanSurrogatedObjectValueChange",
      "d": 1245211,
      "h": 90195558427,
      "f": 2097160
    },
//--TRIMMABLE-BOUNDARY-END(90195558427),
//--TRIMMABLE-BOUNDARY-START(85900591131),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 120260329499,
        "f": 50331656
      },
      "n": "CanObjectValueChange",
      "d": 1245211,
      "h": 85900591131,
      "f": 2097160
    },
//--TRIMMABLE-BOUNDARY-END(85900591131),
//--TRIMMABLE-BOUNDARY-START(111670394907),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 163210002459,
        "f": 50331656
      },
      "n": "DirectlyDependentObjects",
      "d": 1245211,
      "h": 111670394907,
      "f": 2097160
    },
//--TRIMMABLE-BOUNDARY-END(111670394907),
//--TRIMMABLE-BOUNDARY-START(446677843995),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 257699282971,
        "f": 50331656
      },
      "n": "TotalDependentObjects",
      "d": 1245211,
      "h": 446677843995,
      "f": 2097160
    },
//--TRIMMABLE-BOUNDARY-END(446677843995),
//--TRIMMABLE-BOUNDARY-START(335008694299),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 206159675419,
        "f": 50331656
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 395138236443,
        "f": 83886088
      },
      "n": "Reachable",
      "d": 1245211,
      "h": 335008694299,
      "f": 2097160
    },
//--TRIMMABLE-BOUNDARY-END(335008694299),
//--TRIMMABLE-BOUNDARY-START(455267778587),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 274879152155,
        "f": 50331656
      },
      "n": "TypeLoadExceptionReachable",
      "d": 1245211,
      "h": 455267778587,
      "f": 2097160
    },
//--TRIMMABLE-BOUNDARY-END(455267778587),
//--TRIMMABLE-BOUNDARY-START(330713727003),
    {
      "p": 131073,
      "g": {
        "r": 0,
        "d": 0,
        "h": 197569740827,
        "f": 50331656
      },
      "n": "ObjectValue",
      "d": 1245211,
      "h": 330713727003,
      "f": 2097160
    },
//--TRIMMABLE-BOUNDARY-END(330713727003),
//--TRIMMABLE-BOUNDARY-START(369368432667),
    {
      "p": 158859265,
      "g": {
        "r": 0,
        "d": 0,
        "h": 240519413787,
        "f": 50331656
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 412318105627,
        "f": 83886088
      },
      "n": "SerializationInfo",
      "d": 1245211,
      "h": 369368432667,
      "f": 2097160
    },
//--TRIMMABLE-BOUNDARY-END(369368432667),
//--TRIMMABLE-BOUNDARY-START(442382876699),
    {
      "p": 983067,
      "g": {
        "r": 0,
        "d": 0,
        "h": 249109348379,
        "f": 50331656
      },
      "n": "Surrogate",
      "d": 1245211,
      "h": 442382876699,
      "f": 2097160
    },
//--TRIMMABLE-BOUNDARY-END(442382876699),
//--TRIMMABLE-BOUNDARY-START(107375427611),
    {
      "p": 1114139,
      "g": {
        "r": 0,
        "d": 0,
        "h": 154620067867,
        "f": 50331656
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 377958367259,
        "f": 83886088
      },
      "n": "DependentObjects",
      "d": 1245211,
      "h": 107375427611,
      "f": 2097160
    },
//--TRIMMABLE-BOUNDARY-END(107375427611),
//--TRIMMABLE-BOUNDARY-START(356483530779),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 223339544603,
        "f": 50331656
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 403728171035,
        "f": 83886088
      },
      "n": "RequiresSerInfoFixup",
      "d": 1245211,
      "h": 356483530779,
      "f": 2097160
    },
//--TRIMMABLE-BOUNDARY-END(356483530779),
//--TRIMMABLE-BOUNDARY-START(468152680475),
    {
      "p": 2359323,
      "g": {
        "r": 0,
        "d": 0,
        "h": 283469086747,
        "f": 50331656
      },
      "n": "ValueFixup",
      "d": 1245211,
      "h": 468152680475,
      "f": 2097160
    },
//--TRIMMABLE-BOUNDARY-END(468152680475),
//--TRIMMABLE-BOUNDARY-START(94490525723),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 137440198683,
        "f": 50331656
      },
      "n": "CompletelyFixed",
      "d": 1245211,
      "h": 94490525723,
      "f": 2097160
    },
//--TRIMMABLE-BOUNDARY-END(94490525723),
//--TRIMMABLE-BOUNDARY-START(98785493019),
    {
      "p": 917505,
      "g": {
        "r": 0,
        "d": 0,
        "h": 146030133275,
        "f": 50331656
      },
      "n": "ContainerID",
      "d": 1245211,
      "h": 98785493019,
      "f": 2097160
    },
//--TRIMMABLE-BOUNDARY-END(98785493019)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(317828825115),
    {
      "r": 65537,
      "p": [
        {
          "n": "amount",
          "p": 655361
        }
      ],
      "n": "IncrementDescendentFixups",
      "d": 1245211,
      "h": 317828825115,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(317828825115),
//--TRIMMABLE-BOUNDARY-START(103080460315),
    {
      "r": 65537,
      "p": [
        {
          "n": "manager",
          "p": 1507355
        }
      ],
      "n": "DecrementFixupsRemaining",
      "d": 1245211,
      "h": 103080460315,
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(103080460315),
//--TRIMMABLE-BOUNDARY-START(339303661595),
    {
      "r": 65537,
      "p": [
        {
          "n": "id",
          "p": 917505
        }
      ],
      "n": "RemoveDependency",
      "d": 1245211,
      "h": 339303661595,
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(339303661595),
//--TRIMMABLE-BOUNDARY-START(81605623835),
    {
      "r": 65537,
      "p": [
        {
          "n": "fixup",
          "p": 262171
        },
        {
          "n": "manager",
          "p": 1507355
        }
      ],
      "n": "AddFixup",
      "d": 1245211,
      "h": 81605623835,
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(81605623835),
//--TRIMMABLE-BOUNDARY-START(463857713179),
    {
      "r": 65537,
      "p": [
        {
          "n": "amount",
          "p": 655361
        },
        {
          "n": "manager",
          "p": 1507355
        }
      ],
      "n": "UpdateDescendentDependencyChain",
      "d": 1245211,
      "h": 463857713179,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(463857713179),
//--TRIMMABLE-BOUNDARY-START(77310656539),
    {
      "r": 65537,
      "p": [
        {
          "n": "dependentObject",
          "p": 917505
        }
      ],
      "n": "AddDependency",
      "d": 1245211,
      "h": 77310656539,
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(77310656539),
//--TRIMMABLE-BOUNDARY-START(459562745883),
    {
      "r": 65537,
      "p": [
        {
          "n": "obj",
          "p": 131073
        },
        {
          "n": "info",
          "p": 158859265
        },
        {
          "n": "surrogate",
          "p": 983067
        },
        {
          "n": "idOfContainer",
          "p": 917505
        },
        {
          "n": "field",
          "p": 114622465
        },
        {
          "n": "arrayIndex",
          "p": $.$typeArray($.$$.S.Int32).$h
        },
        {
          "n": "manager",
          "p": 1507355
        }
      ],
      "n": "UpdateData",
      "d": 1245211,
      "h": 459562745883,
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(459562745883),
//--TRIMMABLE-BOUNDARY-START(326418759707),
    {
      "r": 65537,
      "n": "MarkForCompletionWhenAvailable",
      "d": 1245211,
      "h": 326418759707,
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(326418759707),
//--TRIMMABLE-BOUNDARY-START(433792942107),
    {
      "r": 65537,
      "n": "SetFlags",
      "d": 1245211,
      "h": 433792942107,
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(433792942107),
//--TRIMMABLE-BOUNDARY-START(438087909403),
    {
      "r": 65537,
      "p": [
        {
          "n": "obj",
          "p": 131073
        },
        {
          "n": "manager",
          "p": 1507355
        }
      ],
      "n": "SetObjectValue",
      "d": 1245211,
      "h": 438087909403,
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(438087909403)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(313533857819),
    {
      "t": 655361,
      "n": "IncompleteObjectReference",
      "d": 1245211,
      "h": 313533857819,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(313533857819),
//--TRIMMABLE-BOUNDARY-START(296353988635),
    {
      "t": 655361,
      "n": "HAS_ISERIALIZABLE",
      "d": 1245211,
      "h": 296353988635,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(296353988635),
//--TRIMMABLE-BOUNDARY-START(300648955931),
    {
      "t": 655361,
      "n": "HAS_SURROGATE",
      "d": 1245211,
      "h": 300648955931,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(300648955931),
//--TRIMMABLE-BOUNDARY-START(347893596187),
    {
      "t": 655361,
      "n": "REQUIRES_VALUETYPE_FIXUP",
      "d": 1245211,
      "h": 347893596187,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(347893596187),
//--TRIMMABLE-BOUNDARY-START(343598628891),
    {
      "t": 655361,
      "n": "REQUIRES_DELAYED_FIXUP",
      "d": 1245211,
      "h": 343598628891,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(343598628891),
//--TRIMMABLE-BOUNDARY-START(365073465371),
    {
      "t": 655361,
      "n": "SER_INFO_FIXED",
      "d": 1245211,
      "h": 365073465371,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(365073465371),
//--TRIMMABLE-BOUNDARY-START(472447647771),
    {
      "t": 655361,
      "n": "VALUETYPE_FIXUP_PERFORMED",
      "d": 1245211,
      "h": 472447647771,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(472447647771),
//--TRIMMABLE-BOUNDARY-START(38655950875),
    {
      "t": 131073,
      "n": "_object",
      "d": 1245211,
      "h": 38655950875,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(38655950875),
//--TRIMMABLE-BOUNDARY-START(12886147099),
    {
      "t": 917505,
      "n": "_id",
      "d": 1245211,
      "h": 12886147099,
      "f": 4194312
    },
//--TRIMMABLE-BOUNDARY-END(12886147099),
//--TRIMMABLE-BOUNDARY-START(30066016283),
    {
      "t": 655361,
      "n": "_missingElementsRemaining",
      "d": 1245211,
      "h": 30066016283,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(30066016283),
//--TRIMMABLE-BOUNDARY-START(21476081691),
    {
      "t": 655361,
      "n": "_missingDecendents",
      "d": 1245211,
      "h": 21476081691,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(21476081691),
//--TRIMMABLE-BOUNDARY-START(47245885467),
    {
      "t": 158859265,
      "n": "_serInfo",
      "d": 1245211,
      "h": 47245885467,
      "f": 4194312
    },
//--TRIMMABLE-BOUNDARY-END(47245885467),
//--TRIMMABLE-BOUNDARY-START(51540852763),
    {
      "t": 983067,
      "n": "_surrogate",
      "d": 1245211,
      "h": 51540852763,
      "f": 4194312
    },
//--TRIMMABLE-BOUNDARY-END(51540852763),
//--TRIMMABLE-BOUNDARY-START(25771048987),
    {
      "t": 327707,
      "n": "_missingElements",
      "d": 1245211,
      "h": 25771048987,
      "f": 4194312
    },
//--TRIMMABLE-BOUNDARY-END(25771048987),
//--TRIMMABLE-BOUNDARY-START(4296212507),
    {
      "t": 1114139,
      "n": "_dependentObjects",
      "d": 1245211,
      "h": 4296212507,
      "f": 4194312
    },
//--TRIMMABLE-BOUNDARY-END(4296212507),
//--TRIMMABLE-BOUNDARY-START(34360983579),
    {
      "t": 1245211,
      "n": "_next",
      "d": 1245211,
      "h": 34360983579,
      "f": 4194312
    },
//--TRIMMABLE-BOUNDARY-END(34360983579),
//--TRIMMABLE-BOUNDARY-START(8591179803),
    {
      "t": 655361,
      "n": "_flags",
      "d": 1245211,
      "h": 8591179803,
      "f": 4194312
    },
//--TRIMMABLE-BOUNDARY-END(8591179803),
//--TRIMMABLE-BOUNDARY-START(17181114395),
    {
      "t": 262145,
      "n": "_markForFixupWhenAvailable",
      "d": 1245211,
      "h": 17181114395,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(17181114395),
//--TRIMMABLE-BOUNDARY-START(60130787355),
    {
      "t": 2359323,
      "n": "_valueFixup",
      "d": 1245211,
      "h": 60130787355,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(60130787355),
//--TRIMMABLE-BOUNDARY-START(55835820059),
    {
      "t": 2293787,
      "n": "_typeLoad",
      "d": 1245211,
      "h": 55835820059,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(55835820059),
//--TRIMMABLE-BOUNDARY-START(42950918171),
    {
      "t": 262145,
      "n": "_reachable",
      "d": 1245211,
      "h": 42950918171,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(42950918171)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(64425754651),
    {
      "p": [
        {
          "n": "objID",
          "p": 917505
        }
      ],
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 1245211,
      "h": 64425754651,
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(64425754651),
//--TRIMMABLE-BOUNDARY-START(68720721947),
    {
      "p": [
        {
          "n": "obj",
          "p": 131073
        },
        {
          "n": "objID",
          "p": 917505
        },
        {
          "n": "info",
          "p": 158859265
        },
        {
          "n": "surrogate",
          "p": 983067
        },
        {
          "n": "idOfContainingObj",
          "p": 917505
        },
        {
          "n": "field",
          "p": 114622465
        },
        {
          "n": "arrayIndex",
          "p": $.$typeArray($.$$.S.Int32).$h
        }
      ],
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 1245211,
      "h": 68720721947,
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(68720721947),
//--TRIMMABLE-BOUNDARY-START(73015689243),
    {
      "p": [
        {
          "n": "obj",
          "p": 1310721
        },
        {
          "n": "objID",
          "p": 917505
        },
        {
          "n": "info",
          "p": 158859265
        },
        {
          "n": "surrogate",
          "p": 983067
        },
        {
          "n": "idOfContainingObj",
          "p": 917505
        },
        {
          "n": "field",
          "p": 114622465
        },
        {
          "n": "arrayIndex",
          "p": $.$typeArray($.$$.S.Int32).$h
        }
      ],
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 1245211,
      "h": 73015689243,
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(73015689243)
  ],
  "h": 1245211
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `System.Runtime.Serialization.ObjectHolder`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `System${separator}Runtime${separator}Serialization${separator}ObjectHolder`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1245211)
        
        

        //--TRIMMABLE-BOUNDARY-START(262171)
        $asm.$cls(`$srsf.SRS.FixupHolder`, ($self) => class FixupHolder extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(21475098651)
            /*int*/ static ArrayFixup = 1;
            //--TRIMMABLE-BOUNDARY-END(21475098651)
            
            //--TRIMMABLE-BOUNDARY-START(30065033243)
            /*int*/ static MemberFixup = 2;
            //--TRIMMABLE-BOUNDARY-END(30065033243)
            
            //--TRIMMABLE-BOUNDARY-START(25770065947)
            /*int*/ static DelayedFixup = 4;
            //--TRIMMABLE-BOUNDARY-END(25770065947)
            
            //--TRIMMABLE-BOUNDARY-START(12885164059)
            /*long*/ _id = 0n;
            //--TRIMMABLE-BOUNDARY-END(12885164059)
            
            //--TRIMMABLE-BOUNDARY-START(4295229467)
            /*object*/ _fixupInfo = null;
            //--TRIMMABLE-BOUNDARY-END(4295229467)
            
            //--TRIMMABLE-BOUNDARY-START(8590196763)
            /*int*/ _fixupType = 0;
            //--TRIMMABLE-BOUNDARY-END(8590196763)
            
            //--TRIMMABLE-BOUNDARY-START(17180131355)
            $ctor$1(/*long*/ id, /*object*/ fixupInfo, /*int*/ fixupType)
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(17180131355);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$$.SD.Debug.Assert$4(id > 0n, "id>0");
                    $.$$.SD.Debug.Assert$4(fixupInfo !== null, "fixupInfo!=null");
                    $.$$.SD.Debug.Assert$4(fixupType === 1/*ArrayFixup*/ || fixupType === 2/*MemberFixup*/ || fixupType === 4/*DelayedFixup*/, "fixupType==ArrayFixup || fixupType == MemberFixup || fixupType==DelayedFixup");
                    this._id = id;
                    this._fixupInfo = fixupInfo;
                    this._fixupType = fixupType;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(17180131355)
            
            static $h = 262171;
            static $f = 0b10010000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "l": [
//--TRIMMABLE-BOUNDARY-START(21475098651),
    {
      "t": 655361,
      "n": "ArrayFixup",
      "d": 262171,
      "h": 21475098651,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(21475098651),
//--TRIMMABLE-BOUNDARY-START(30065033243),
    {
      "t": 655361,
      "n": "MemberFixup",
      "d": 262171,
      "h": 30065033243,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(30065033243),
//--TRIMMABLE-BOUNDARY-START(25770065947),
    {
      "t": 655361,
      "n": "DelayedFixup",
      "d": 262171,
      "h": 25770065947,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(25770065947),
//--TRIMMABLE-BOUNDARY-START(12885164059),
    {
      "t": 917505,
      "n": "_id",
      "d": 262171,
      "h": 12885164059,
      "f": 4194312
    },
//--TRIMMABLE-BOUNDARY-END(12885164059),
//--TRIMMABLE-BOUNDARY-START(4295229467),
    {
      "t": 131073,
      "n": "_fixupInfo",
      "d": 262171,
      "h": 4295229467,
      "f": 4194312
    },
//--TRIMMABLE-BOUNDARY-END(4295229467),
//--TRIMMABLE-BOUNDARY-START(8590196763),
    {
      "t": 655361,
      "n": "_fixupType",
      "d": 262171,
      "h": 8590196763,
      "f": 4194312
    },
//--TRIMMABLE-BOUNDARY-END(8590196763)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(17180131355),
    {
      "p": [
        {
          "n": "id",
          "p": 917505
        },
        {
          "n": "fixupInfo",
          "p": 131073
        },
        {
          "n": "fixupType",
          "p": 655361
        }
      ],
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 262171,
      "h": 17180131355,
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(17180131355)
  ],
  "h": 262171
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `System.Runtime.Serialization.FixupHolder`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `System${separator}Runtime${separator}Serialization${separator}FixupHolder`; }
        });
        //--TRIMMABLE-BOUNDARY-END(262171)
        
        

        //--TRIMMABLE-BOUNDARY-START(327707)
        $asm.$cls(`$srsf.SRS.FixupHolderList`, ($self) => class FixupHolderList extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(30065098779)
            /*int*/ static InitialSize = 2;
            //--TRIMMABLE-BOUNDARY-END(30065098779)
            
            //--TRIMMABLE-BOUNDARY-START(8590262299)
            /*FixupHolder?[]*/ _values = null;
            //--TRIMMABLE-BOUNDARY-END(8590262299)
            
            //--TRIMMABLE-BOUNDARY-START(4295295003)
            /*int*/ _count = 0;
            //--TRIMMABLE-BOUNDARY-END(4295295003)
            
            //--TRIMMABLE-BOUNDARY-START(12885229595)
            $ctor$1()
            {
                this.$ctor$2(2/*InitialSize*/);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(12885229595);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(12885229595)
            
            //--TRIMMABLE-BOUNDARY-START(17180196891)
            $ctor$2(/*int*/ startingSize)
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(17180196891);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this._count = 0;
                    this._values = $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$srsf.SRS.FixupHolder), null, [startingSize], null);
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(17180196891)
            
            //--TRIMMABLE-BOUNDARY-START(21475164187)
            /*void */ Add(/*FixupHolder*/ fixup)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21475164187);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (this._count === this._values.length)
                {
                    this.EnlargeArray();
                }
                $.$$.System.Array.$WriteT1.call(this._values, fixup, this._count++);
            }
            //--TRIMMABLE-BOUNDARY-END(21475164187)
            
            //--TRIMMABLE-BOUNDARY-START(25770131483)
            /*void */ EnlargeArray()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25770131483);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*int*/ let newLength = ((this._values.length * 2) | 0);
                if (newLength < 0)
                {
                    newLength = 2147483647/*int.MaxValue*/;
                }
                /*FixupHolder[]*/ let temp = $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$srsf.SRS.FixupHolder), null, [newLength], null);
                $.$$.S.Array.Copy$2(this._values, temp, this._count);
                this._values = temp;
            }
            //--TRIMMABLE-BOUNDARY-END(25770131483)
            
            //--TRIMMABLE-BOUNDARY-START(12885229595)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(12885229595)
            
            static $h = 327707;
            static $f = 0b10010000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(21475164187),
    {
      "r": 65537,
      "p": [
        {
          "n": "fixup",
          "p": 262171
        }
      ],
      "n": "Add",
      "d": 327707,
      "h": 21475164187,
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(21475164187),
//--TRIMMABLE-BOUNDARY-START(25770131483),
    {
      "r": 65537,
      "n": "EnlargeArray",
      "d": 327707,
      "h": 25770131483,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(25770131483)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(30065098779),
    {
      "t": 655361,
      "n": "InitialSize",
      "d": 327707,
      "h": 30065098779,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(30065098779),
//--TRIMMABLE-BOUNDARY-START(8590262299),
    {
      "t": $.$typeArray($.$srsf.SRS.FixupHolder).$h,
      "n": "_values",
      "d": 327707,
      "h": 8590262299,
      "f": 4194312
    },
//--TRIMMABLE-BOUNDARY-END(8590262299),
//--TRIMMABLE-BOUNDARY-START(4295295003),
    {
      "t": 655361,
      "n": "_count",
      "d": 327707,
      "h": 4295295003,
      "f": 4194312
    },
//--TRIMMABLE-BOUNDARY-END(4295295003)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(12885229595),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 327707,
      "h": 12885229595,
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(12885229595),
//--TRIMMABLE-BOUNDARY-START(17180196891),
    {
      "p": [
        {
          "n": "startingSize",
          "p": 655361
        }
      ],
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 327707,
      "h": 17180196891,
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(17180196891)
  ],
  "h": 327707
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `System.Runtime.Serialization.FixupHolderList`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `System${separator}Runtime${separator}Serialization${separator}FixupHolderList`; }
        });
        //--TRIMMABLE-BOUNDARY-END(327707)
        
        

        //--TRIMMABLE-BOUNDARY-START(1114139)
        $asm.$cls(`$srsf.SRS.LongList`, ($self) => class LongList extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(64425623579)
            /*int*/ static InitialSize = 2;
            //--TRIMMABLE-BOUNDARY-END(64425623579)
            
            //--TRIMMABLE-BOUNDARY-START(17180983323)
            /*long[]*/ _values = null;
            //--TRIMMABLE-BOUNDARY-END(17180983323)
            
            //--TRIMMABLE-BOUNDARY-START(4296081435)
            /*int*/ _count = 0;
            //--TRIMMABLE-BOUNDARY-END(4296081435)
            
            //--TRIMMABLE-BOUNDARY-START(12886016027)
            /*int*/ _totalItems = 0;
            //--TRIMMABLE-BOUNDARY-END(12886016027)
            
            //--TRIMMABLE-BOUNDARY-START(8591048731)
            /*int*/ _currentItem = 0;
            //--TRIMMABLE-BOUNDARY-END(8591048731)
            
            //--TRIMMABLE-BOUNDARY-START(21475950619)
            $ctor$1()
            {
                this.$ctor$2(2/*InitialSize*/);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(21475950619);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(21475950619)
            
            //--TRIMMABLE-BOUNDARY-START(25770917915)
            $ctor$2(/*int*/ startingSize)
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(25770917915);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this._count = 0;
                    this._totalItems = 0;
                    this._values = $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Int64), null, [startingSize], null);
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(25770917915)
            
            //--TRIMMABLE-BOUNDARY-START(30065885211)
            /*void */ Add(/*long*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(30065885211);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (this._totalItems === this._values.length)
                {
                    this.EnlargeArray();
                }
                $.$$.System.Array.$WriteT1.call(this._values, value, this._totalItems++);
                this._count++;
            }
            //--TRIMMABLE-BOUNDARY-END(30065885211)
            
            //--TRIMMABLE-BOUNDARY-START(34360852507)
            /*int */ get Count()
            {
                return this._count;
            }
            //--TRIMMABLE-BOUNDARY-END(34360852507)
            
            //--TRIMMABLE-BOUNDARY-START(77310525467)
            /*void */ StartEnumeration()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(77310525467);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return this._currentItem = -1;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(77310525467)
            
            //--TRIMMABLE-BOUNDARY-START(68720590875)
            /*bool */ MoveNext()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(68720590875);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                while(++this._currentItem < this._totalItems && $.$$.System.Array.$ReadT1.call(this._values, this._currentItem) === BigInt(-1))
                {
                }
                return this._currentItem !== this._totalItems;
            }
            //--TRIMMABLE-BOUNDARY-END(68720590875)
            
            //--TRIMMABLE-BOUNDARY-START(38655819803)
            /*long */ get Current()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(60130656283);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.SD.Debug.Assert$4(this._currentItem !== -1, "[LongList.Current]m_currentItem!=-1");
                $.$$.SD.Debug.Assert$4($.$$.System.Array.$ReadT1.call(this._values, this._currentItem) !== BigInt(-1), "[LongList.Current]m_values[m_currentItem]!=-1");
                return $.$$.System.Array.$ReadT1.call(this._values, this._currentItem);
            }
            //--TRIMMABLE-BOUNDARY-END(38655819803)
            
            //--TRIMMABLE-BOUNDARY-START(73015558171)
            /*bool */ RemoveElement(/*long*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(73015558171);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*int*/ let i;
                for(i = 0; i < this._totalItems; i++)
                {
                    if ($.$$.System.Array.$ReadT1.call(this._values, i) === value)
                    {
                        break;
                    }
                }
                if (i === this._totalItems)
                {
                    return false;
                }
                $.$$.System.Array.$WriteT1.call(this._values, BigInt(-1), i);
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(73015558171)
            
            //--TRIMMABLE-BOUNDARY-START(42950787099)
            /*void */ EnlargeArray()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(42950787099);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*int*/ let newLength = ((this._values.length * 2) | 0);
                if (newLength < 0)
                {
                    newLength = 2147483647/*int.MaxValue*/;
                }
                /*long[]*/ let temp = $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Int64), null, [newLength], null);
                $.$$.S.Array.Copy$2(this._values, temp, this._count);
                this._values = temp;
            }
            //--TRIMMABLE-BOUNDARY-END(42950787099)
            
            //--TRIMMABLE-BOUNDARY-START(21475950619)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(21475950619)
            
            static $h = 1114139;
            static $f = 0b10010000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(34360852507),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 51540721691,
        "f": 50331656
      },
      "n": "Count",
      "d": 1114139,
      "h": 34360852507,
      "f": 2097160
    },
//--TRIMMABLE-BOUNDARY-END(34360852507),
//--TRIMMABLE-BOUNDARY-START(38655819803),
    {
      "p": 917505,
      "g": {
        "r": 0,
        "d": 0,
        "h": 60130656283,
        "f": 50331656
      },
      "n": "Current",
      "d": 1114139,
      "h": 38655819803,
      "f": 2097160
    },
//--TRIMMABLE-BOUNDARY-END(38655819803)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(30065885211),
    {
      "r": 65537,
      "p": [
        {
          "n": "value",
          "p": 917505
        }
      ],
      "n": "Add",
      "d": 1114139,
      "h": 30065885211,
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(30065885211),
//--TRIMMABLE-BOUNDARY-START(77310525467),
    {
      "r": 65537,
      "n": "StartEnumeration",
      "d": 1114139,
      "h": 77310525467,
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(77310525467),
//--TRIMMABLE-BOUNDARY-START(68720590875),
    {
      "r": 262145,
      "n": "MoveNext",
      "d": 1114139,
      "h": 68720590875,
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(68720590875),
//--TRIMMABLE-BOUNDARY-START(73015558171),
    {
      "r": 262145,
      "p": [
        {
          "n": "value",
          "p": 917505
        }
      ],
      "n": "RemoveElement",
      "d": 1114139,
      "h": 73015558171,
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(73015558171),
//--TRIMMABLE-BOUNDARY-START(42950787099),
    {
      "r": 65537,
      "n": "EnlargeArray",
      "d": 1114139,
      "h": 42950787099,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(42950787099)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(64425623579),
    {
      "t": 655361,
      "n": "InitialSize",
      "d": 1114139,
      "h": 64425623579,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(64425623579),
//--TRIMMABLE-BOUNDARY-START(17180983323),
    {
      "t": $.$typeArray($.$$.S.Int64).$h,
      "n": "_values",
      "d": 1114139,
      "h": 17180983323,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(17180983323),
//--TRIMMABLE-BOUNDARY-START(4296081435),
    {
      "t": 655361,
      "n": "_count",
      "d": 1114139,
      "h": 4296081435,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(4296081435),
//--TRIMMABLE-BOUNDARY-START(12886016027),
    {
      "t": 655361,
      "n": "_totalItems",
      "d": 1114139,
      "h": 12886016027,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(12886016027),
//--TRIMMABLE-BOUNDARY-START(8591048731),
    {
      "t": 655361,
      "n": "_currentItem",
      "d": 1114139,
      "h": 8591048731,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(8591048731)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(21475950619),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 1114139,
      "h": 21475950619,
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(21475950619),
//--TRIMMABLE-BOUNDARY-START(25770917915),
    {
      "p": [
        {
          "n": "startingSize",
          "p": 655361
        }
      ],
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 1114139,
      "h": 25770917915,
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(25770917915)
  ],
  "h": 1114139
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `System.Runtime.Serialization.LongList`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `System${separator}Runtime${separator}Serialization${separator}LongList`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1114139)
        
        

        //--TRIMMABLE-BOUNDARY-START(1310747)
        $asm.$cls(`$srsf.SRS.ObjectHolderList`, ($self) => class ObjectHolderList extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(30066081819)
            /*int*/ static DefaultInitialSize = 8;
            //--TRIMMABLE-BOUNDARY-END(30066081819)
            
            //--TRIMMABLE-BOUNDARY-START(8591245339)
            /*ObjectHolder[]*/ _values = null;
            //--TRIMMABLE-BOUNDARY-END(8591245339)
            
            //--TRIMMABLE-BOUNDARY-START(4296278043)
            /*int*/ _count = 0;
            //--TRIMMABLE-BOUNDARY-END(4296278043)
            
            //--TRIMMABLE-BOUNDARY-START(12886212635)
            $ctor$1()
            {
                this.$ctor$2(8/*DefaultInitialSize*/);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(12886212635);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(12886212635)
            
            //--TRIMMABLE-BOUNDARY-START(17181179931)
            $ctor$2(/*int*/ startingSize)
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(17181179931);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$$.SD.Debug.Assert$4(startingSize > 0 && startingSize < 4096, "startingSize>0 && startingSize<0x1000");
                    this._count = 0;
                    this._values = $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$srsf.SRS.ObjectHolder), null, [startingSize], null);
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(17181179931)
            
            //--TRIMMABLE-BOUNDARY-START(21476147227)
            /*void */ Add(/*ObjectHolder*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21476147227);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (this._count === this._values.length)
                {
                    this.EnlargeArray();
                }
                $.$$.System.Array.$WriteT1.call(this._values, value, this._count++);
            }
            //--TRIMMABLE-BOUNDARY-END(21476147227)
            
            //--TRIMMABLE-BOUNDARY-START(55835885595)
            /*ObjectHolderListEnumerator */ GetFixupEnumerator()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(55835885595);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return new $.$srsf.SRS.ObjectHolderListEnumerator().$ctor$1(this, true);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(55835885595)
            
            //--TRIMMABLE-BOUNDARY-START(34361049115)
            /*void */ EnlargeArray()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(34361049115);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*int*/ let newLength = ((this._values.length * 2) | 0);
                if (newLength < 0)
                {
                    newLength = 2147483647/*int.MaxValue*/;
                }
                /*ObjectHolder[]*/ let temp = $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$srsf.SRS.ObjectHolder), null, [newLength], null);
                $.$$.S.Array.Copy$2(this._values, temp, this._count);
                this._values = temp;
            }
            //--TRIMMABLE-BOUNDARY-END(34361049115)
            
            //--TRIMMABLE-BOUNDARY-START(60130852891)
            /*int */ get Version()
            {
                return this._count;
            }
            //--TRIMMABLE-BOUNDARY-END(60130852891)
            
            //--TRIMMABLE-BOUNDARY-START(25771114523)
            /*int */ get Count()
            {
                return this._count;
            }
            //--TRIMMABLE-BOUNDARY-END(25771114523)
            
            //--TRIMMABLE-BOUNDARY-START(12886212635)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(12886212635)
            
            static $h = 1310747;
            static $f = 0b10010000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(60130852891),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 51540918299,
        "f": 50331656
      },
      "n": "Version",
      "d": 1310747,
      "h": 60130852891,
      "f": 2097160
    },
//--TRIMMABLE-BOUNDARY-END(60130852891),
//--TRIMMABLE-BOUNDARY-START(25771114523),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 42950983707,
        "f": 50331656
      },
      "n": "Count",
      "d": 1310747,
      "h": 25771114523,
      "f": 2097160
    },
//--TRIMMABLE-BOUNDARY-END(25771114523)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(21476147227),
    {
      "r": 65537,
      "p": [
        {
          "n": "value",
          "p": 1245211
        }
      ],
      "n": "Add",
      "d": 1310747,
      "h": 21476147227,
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(21476147227),
//--TRIMMABLE-BOUNDARY-START(55835885595),
    {
      "r": 1376283,
      "n": "GetFixupEnumerator",
      "d": 1310747,
      "h": 55835885595,
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(55835885595),
//--TRIMMABLE-BOUNDARY-START(34361049115),
    {
      "r": 65537,
      "n": "EnlargeArray",
      "d": 1310747,
      "h": 34361049115,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(34361049115)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(30066081819),
    {
      "t": 655361,
      "n": "DefaultInitialSize",
      "d": 1310747,
      "h": 30066081819,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(30066081819),
//--TRIMMABLE-BOUNDARY-START(8591245339),
    {
      "t": $.$typeArray($.$srsf.SRS.ObjectHolder).$h,
      "n": "_values",
      "d": 1310747,
      "h": 8591245339,
      "f": 4194312
    },
//--TRIMMABLE-BOUNDARY-END(8591245339),
//--TRIMMABLE-BOUNDARY-START(4296278043),
    {
      "t": 655361,
      "n": "_count",
      "d": 1310747,
      "h": 4296278043,
      "f": 4194312
    },
//--TRIMMABLE-BOUNDARY-END(4296278043)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(12886212635),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 1310747,
      "h": 12886212635,
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(12886212635),
//--TRIMMABLE-BOUNDARY-START(17181179931),
    {
      "p": [
        {
          "n": "startingSize",
          "p": 655361
        }
      ],
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 1310747,
      "h": 17181179931,
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(17181179931)
  ],
  "h": 1310747
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `System.Runtime.Serialization.ObjectHolderList`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `System${separator}Runtime${separator}Serialization${separator}ObjectHolderList`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1310747)
        
        

        //--TRIMMABLE-BOUNDARY-START(1376283)
        $asm.$cls(`$srsf.SRS.ObjectHolderListEnumerator`, ($self) => class ObjectHolderListEnumerator extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8591310875)
            /*bool*/ _isFixupEnumerator = false;
            //--TRIMMABLE-BOUNDARY-END(8591310875)
            
            //--TRIMMABLE-BOUNDARY-START(12886278171)
            /*ObjectHolderList*/ _list = null;
            //--TRIMMABLE-BOUNDARY-END(12886278171)
            
            //--TRIMMABLE-BOUNDARY-START(17181245467)
            /*int*/ _startingVersion = 0;
            //--TRIMMABLE-BOUNDARY-END(17181245467)
            
            //--TRIMMABLE-BOUNDARY-START(4296343579)
            /*int*/ _currPos = 0;
            //--TRIMMABLE-BOUNDARY-END(4296343579)
            
            //--TRIMMABLE-BOUNDARY-START(21476212763)
            $ctor$1(/*ObjectHolderList*/ list, /*bool*/ isFixupEnumerator)
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(21476212763);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$$.SD.Debug.Assert$4(list !== null, "[ObjectHolderListEnumerator.ctor]list!=null");
                    this._list = list;
                    this._startingVersion = this._list.Version;
                    this._currPos = -1;
                    this._isFixupEnumerator = isFixupEnumerator;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(21476212763)
            
            //--TRIMMABLE-BOUNDARY-START(38656081947)
            /*bool */ MoveNext()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(38656081947);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.SD.Debug.Assert$4(this._startingVersion === this._list.Version, "[ObjectHolderListEnumerator.MoveNext]m_startingVersion==m_list.Version");
                if (this._isFixupEnumerator)
                {
                    while(++this._currPos < this._list.Count && $.$$.System.Array.$ReadT1.call(this._list._values, this._currPos).CompletelyFixed)
                    {
                    }
                    return this._currPos !== this._list.Count;
                }
                else 
                {
                    this._currPos++;
                    return this._currPos !== this._list.Count;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(38656081947)
            
            //--TRIMMABLE-BOUNDARY-START(25771180059)
            /*ObjectHolder */ get Current()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(34361114651);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.SD.Debug.Assert$4(this._currPos !== -1, "[ObjectHolderListEnumerator.Current]m_currPos!=-1");
                $.$$.SD.Debug.Assert$4(this._currPos < this._list.Count, "[ObjectHolderListEnumerator.Current]m_currPos<m_list.Count");
                $.$$.SD.Debug.Assert$4(this._startingVersion === this._list.Version, "[ObjectHolderListEnumerator.Current]m_startingVersion==m_list.Version");
                return $.$$.System.Array.$ReadT1.call(this._list._values, this._currPos);
            }
            //--TRIMMABLE-BOUNDARY-END(25771180059)
            
            static $h = 1376283;
            static $f = 0b10010000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(25771180059),
    {
      "p": 1245211,
      "g": {
        "r": 0,
        "d": 0,
        "h": 34361114651,
        "f": 50331656
      },
      "n": "Current",
      "d": 1376283,
      "h": 25771180059,
      "f": 2097160
    },
//--TRIMMABLE-BOUNDARY-END(25771180059)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(38656081947),
    {
      "r": 262145,
      "n": "MoveNext",
      "d": 1376283,
      "h": 38656081947,
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(38656081947)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(8591310875),
    {
      "t": 262145,
      "n": "_isFixupEnumerator",
      "d": 1376283,
      "h": 8591310875,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(8591310875),
//--TRIMMABLE-BOUNDARY-START(12886278171),
    {
      "t": 1310747,
      "n": "_list",
      "d": 1376283,
      "h": 12886278171,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(12886278171),
//--TRIMMABLE-BOUNDARY-START(17181245467),
    {
      "t": 655361,
      "n": "_startingVersion",
      "d": 1376283,
      "h": 17181245467,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(17181245467),
//--TRIMMABLE-BOUNDARY-START(4296343579),
    {
      "t": 655361,
      "n": "_currPos",
      "d": 1376283,
      "h": 4296343579,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(4296343579)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(21476212763),
    {
      "p": [
        {
          "n": "list",
          "p": 1310747
        },
        {
          "n": "isFixupEnumerator",
          "p": 262145
        }
      ],
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 1376283,
      "h": 21476212763,
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(21476212763)
  ],
  "h": 1376283
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `System.Runtime.Serialization.ObjectHolderListEnumerator`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `System${separator}Runtime${separator}Serialization${separator}ObjectHolderListEnumerator`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1376283)
        
        

        //--TRIMMABLE-BOUNDARY-START(2293787)
        $asm.$cls(`$srsf.SRS.TypeLoadExceptionHolder`, ($self) => class TypeLoadExceptionHolder extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8592228379)
            $ctor$1(/*string?*/ typeName)
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(8592228379);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this.TypeName = typeName;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(8592228379)
            
            //--TRIMMABLE-BOUNDARY-START(21477130267)
            /*string?*/ TypeName = null;
            //--TRIMMABLE-BOUNDARY-END(21477130267)
            
            static $h = 2293787;
            static $f = 0b10010001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(21477130267),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 17182162971,
        "f": 50331656
      },
      "n": "TypeName",
      "d": 2293787,
      "h": 21477130267,
      "f": 2097160
    },
//--TRIMMABLE-BOUNDARY-END(21477130267)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(8592228379),
    {
      "p": [
        {
          "n": "typeName",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 2293787,
      "h": 8592228379,
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(8592228379)
  ],
  "h": 2293787
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `System.Runtime.Serialization.TypeLoadExceptionHolder`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `System${separator}Runtime${separator}Serialization${separator}TypeLoadExceptionHolder`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2293787)
        
        

        //--TRIMMABLE-BOUNDARY-START(1900571)
        $asm.$cls(`$srsf.SRS.SerializationInfoExtensions`, ($self) => class SerializationInfoExtensions
        {
            //--TRIMMABLE-BOUNDARY-START(8591835163)
            /*Action<SerializationInfo, string, object, Type>*/ static s_updateValue = null;
            //--TRIMMABLE-BOUNDARY-END(8591835163)
            
            //--TRIMMABLE-BOUNDARY-START(12886802459)
            static /*void */ UpdateValue(/*this SerializationInfo*/ si, /*string*/ name, /*object*/ value, /*Type*/ type)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(12886802459);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return $.$srsf.SRS.SerializationInfoExtensions.s_updateValue.Invoke(si, name, value, type);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(12886802459)
            
            //--TRIMMABLE-BOUNDARY-START(4296867867)
            //Static Initializer
            static $sinit()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296867867);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                {
                    //--TRIMMABLE-BOUNDARY-START(8591835163)
                    this.s_updateValue = $.$$.SRS.SerializationInfo.$type.GetMethod$9("UpdateValue", 16/*BindingFlags.Public*/ | 32/*BindingFlags.NonPublic*/ | 4/*BindingFlags.Instance*/).CreateDelegate$2($.$$.S.Action$$$$$($.$$.SRS.SerializationInfo, $.$$.S.String, $.$$.S.Object, $.$$.S.Type));
                    //--TRIMMABLE-BOUNDARY-END(8591835163)
                    
                }
            }
            //--TRIMMABLE-BOUNDARY-END(4296867867)
            
            static $h = 1900571;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(12886802459),
    {
      "r": 65537,
      "p": [
        {
          "n": "si",
          "p": 158859265
        },
        {
          "n": "name",
          "p": 1310721
        },
        {
          "n": "value",
          "p": 131073
        },
        {
          "n": "type",
          "p": 188547073
        }
      ],
      "n": "UpdateValue",
      "d": 1900571,
      "h": 12886802459,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(12886802459)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(8591835163),
    {
      "t": $.$$.S.Action$$$$$($.$$.SRS.SerializationInfo, $.$$.S.String, $.$$.S.Object, $.$$.S.Type).$h,
      "n": "s_updateValue",
      "d": 1900571,
      "h": 8591835163,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(8591835163)
  ],
  "h": 1900571
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `System.Runtime.Serialization.SerializationInfoExtensions`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `System${separator}Runtime${separator}Serialization${separator}SerializationInfoExtensions`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1900571)
        
        

        //--TRIMMABLE-BOUNDARY-START(851995)
        $asm.$cls(`$srsf.SRS.FormatterServices`, ($self) => class FormatterServices
        {
            //--TRIMMABLE-BOUNDARY-START(85900197915)
            /*ConcurrentDictionary<MemberHolder, MemberInfo[]>*/ static s_memberInfoTable = null;
            //--TRIMMABLE-BOUNDARY-END(85900197915)
            
            //--TRIMMABLE-BOUNDARY-START(68720328731)
            static /*FieldInfo[] */ InternalGetSerializableMembers(/*Type*/ type)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(68720328731);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.SD.Debug.Assert$4(type !== null, "type != null");
                if (type.IsInterface)
                {
                    return $.$$.S.Array.Empty($.$$.SR.FieldInfo);
                }
                if (!type.IsSerializable)
                {
                    throw new $.$$.SRS.SerializationException().$ctor$12($.$srsf.S.SR.Format$5($.$srsf.S.SR.Serialization_NonSerType, type.FullName, type.Assembly.FullName));
                }
                /*FieldInfo[]*/ let typeMembers = $.$srsf.SRS.FormatterServices.GetSerializableFields(type);
                /*Type?*/ let parentType = type.BaseType;
                if (parentType !== null && parentType !== $.$$.S.Object.$type)
                {
                    /*Type[]?*/ let parentTypes;
                    /*int*/ let parentTypeCount;
                    /*bool*/ let classNamesUnique = $.$srsf.SRS.FormatterServices.GetParentTypes(parentType, $.$ref(() => parentTypes, ($v) => parentTypes = $v, $.$typeArray($.$$.S.Type)), $.$ref(() => parentTypeCount, ($v) => parentTypeCount = $v, $.$$.S.Int32));
                    if (parentTypeCount > 0)
                    {
                        /*var*/ let allMembers = new ($.$$.SCG.List$$($.$$.SR.FieldInfo))().$ctor$1();
                        for(/*int*/ let i = 0; i < parentTypeCount; i++)
                        {
                            parentType = $.$$.System.Array.$ReadT1.call(parentTypes, i);
                            if (!parentType.IsSerializable)
                            {
                                throw new $.$$.SRS.SerializationException().$ctor$12($.$srsf.S.SR.Format$5($.$srsf.S.SR.Serialization_NonSerType, parentType.FullName, parentType.Module$1.Assembly.FullName));
                            }
                            /*FieldInfo[]*/ let typeFields = parentType.GetFields$1(32/*BindingFlags.NonPublic*/ | 4/*BindingFlags.Instance*/);
                            /*string*/ let typeName = classNamesUnique ? parentType.Name : parentType.FullName;
                            let $i3 = 0;
                            let $arr3 = typeFields;
                            while ($i3 < $arr3.length)
                            {
                                let field = $arr3[$i3++];
                                if (!field.IsNotSerialized)
                                {
                                    allMembers.Add(new $.$srsf.SRS.SerializationFieldInfo().$ctor$4(field, typeName));
                                }
                            }
                        }
                        if (allMembers !== null && allMembers.Count > 0)
                        {
                            /*var*/ let membersTemp = $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.SR.FieldInfo), null, [((allMembers.Count + typeMembers.length) | 0)], null);
                            $.$$.S.Array.Copy$2(typeMembers, membersTemp, typeMembers.length);
                            allMembers.CopyTo$1(membersTemp, typeMembers.length);
                            typeMembers = membersTemp;
                        }
                    }
                }
                return typeMembers;
            }
            //--TRIMMABLE-BOUNDARY-END(68720328731)
            
            //--TRIMMABLE-BOUNDARY-START(42950524955)
            static /*FieldInfo[] */ GetSerializableFields(/*Type*/ type)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(42950524955);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*FieldInfo[]*/ let fields = type.GetFields$1(16/*BindingFlags.Public*/ | 32/*BindingFlags.NonPublic*/ | 4/*BindingFlags.Instance*/);
                /*int*/ let countProper = 0;
                for(/*int*/ let i = 0; i < fields.length; i++)
                {
                    if (($.$$.System.Array.$ReadT1.call(fields, i).Attributes & 128/*FieldAttributes.NotSerialized*/) === 128/*FieldAttributes.NotSerialized*/)
                    {
                        continue;
                    }
                    countProper++;
                }
                if (countProper !== fields.length)
                {
                    /*var*/ let properFields = $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.SR.FieldInfo), null, [countProper], null);
                    countProper = 0;
                    for(/*int*/ let i = 0; i < fields.length; i++)
                    {
                        if (($.$$.System.Array.$ReadT1.call(fields, i).Attributes & 128/*FieldAttributes.NotSerialized*/) === 128/*FieldAttributes.NotSerialized*/)
                        {
                            continue;
                        }
                        $.$$.System.Array.$WriteT1.call(properFields, $.$$.System.Array.$ReadT1.call(fields, i), countProper);
                        countProper++;
                    }
                    return properFields;
                }
                else 
                {
                    return fields;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(42950524955)
            
            //--TRIMMABLE-BOUNDARY-START(34360590363)
            static /*bool */ GetParentTypes(/*Type*/ parentType, /*out Type[]?*/ parentTypes, /*out int*/ parentTypeCount)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(34360590363);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                parentTypes.$v = null;
                parentTypeCount.$v = 0;
                /*bool*/ let unique = true;
                /*Type*/ let objectType = $.$$.S.Object.$type;
                for(/*Type*/ let t1 = parentType; t1 !== objectType; t1 = t1.BaseType)
                {
                    if (t1.IsInterface)
                    {
                        continue;
                    }
                    /*string*/ let t1Name = t1.Name;
                    for(/*int*/ let i = 0; unique && i < parentTypeCount.$v; i++)
                    {
                        /*string*/ let t2Name = $.$$.System.Array.$ReadT1.call(parentTypes.$v, i).Name;
                        if (t2Name.length === t1Name.length && $.$$.S.String.get_Chars.call(t2Name, 0) === $.$$.S.String.get_Chars.call(t1Name, 0) && t1Name === t2Name)
                        {
                            unique = false;
                            break;
                        }
                    }
                    if (parentTypes.$v === null || parentTypeCount.$v === parentTypes.$v.length)
                    {
                        $.$$.S.Array.Resize($.$$.S.Type, parentTypes, $.$$.S.Math.Max$4(((parentTypeCount.$v * 2) | 0), 12));
                    }
                    $.$$.System.Array.$WriteT1.call(parentTypes.$v, t1, parentTypeCount.$v++);
                }
                return unique;
            }
            //--TRIMMABLE-BOUNDARY-END(34360590363)
            
            //--TRIMMABLE-BOUNDARY-START(51540459547)
            static /*MemberInfo[] */ GetSerializableMembers$1(/*Type*/ type)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(51540459547);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$srsf.SRS.FormatterServices.GetSerializableMembers(type, new $.$$.SRS.StreamingContext().$ctor$4(255/*StreamingContextStates.All*/));
            }
            //--TRIMMABLE-BOUNDARY-END(51540459547)
            
            //--TRIMMABLE-BOUNDARY-START(47245492251)
            static /*MemberInfo[] */ GetSerializableMembers(/*Type*/ type, /*StreamingContext*/ context)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(47245492251);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.S.ArgumentNullException.ThrowIfNull$2(type, "type");
                return $.$srsf.SRS.FormatterServices.s_memberInfoTable.GetOrAdd(new $.$srsf.SRS.MemberHolder().$ctor$1(type, context), new ($.$$.S.Func$$$($.$srsf.SRS.MemberHolder, $.$typeArray($.$$.SR.MemberInfo)))().$ctor(this,  (/*mh*/ mh) =>
                {
                    return $.$srsf.SRS.FormatterServices.InternalGetSerializableMembers(mh._memberType);
                }, $AaoiKd ??= {"r":$.$typeArray($.$$.SR.MemberInfo).$h,"p":[{"n":"mh","p":1179675}],"n":"","d":851995,"h":0,"f":17825794}));
            }
            //--TRIMMABLE-BOUNDARY-END(47245492251)
            
            //--TRIMMABLE-BOUNDARY-START(8590786587)
            static /*void */ CheckTypeSecurity(/*Type*/ t, /*TypeFilterLevel*/ securityLevel)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590786587);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
            }
            //--TRIMMABLE-BOUNDARY-END(8590786587)
            
            //--TRIMMABLE-BOUNDARY-START(64425361435)
            static /*object */ GetUninitializedObject(/*Type*/ type)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(64425361435);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return $.$$.SRC.RuntimeHelpers.GetUninitializedObject(type);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(64425361435)
            
            //--TRIMMABLE-BOUNDARY-START(38655557659)
            static /*object */ GetSafeUninitializedObject(/*Type*/ type)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(38655557659);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return $.$$.SRC.RuntimeHelpers.GetUninitializedObject(type);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(38655557659)
            
            //--TRIMMABLE-BOUNDARY-START(90195165211)
            static /*void */ SerializationSetValue(/*MemberInfo*/ fi, /*object?*/ target, /*object?*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(90195165211);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.SD.Debug.Assert$4($.$$.SR.MemberInfo.op_Inequality(fi, null), "fi != null");
                let serField;
                if ($.$is(fi, $.$$.SR.FieldInfo, { set $v($v){ serField = $v; } }))
                {
                    serField.SetValue$1(target, value);
                    return;
                }
                throw new $.$$.S.ArgumentException().$ctor$14($.$srsf.S.SR.Argument_InvalidFieldInfo);
            }
            //--TRIMMABLE-BOUNDARY-END(90195165211)
            
            //--TRIMMABLE-BOUNDARY-START(81605230619)
            static /*object */ PopulateObjectMembers(/*object*/ obj, /*MemberInfo[]*/ members, /*object?[]*/ data)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(81605230619);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.S.ArgumentNullException.ThrowIfNull$2(obj, "obj");
                $.$$.S.ArgumentNullException.ThrowIfNull$2(members, "members");
                $.$$.S.ArgumentNullException.ThrowIfNull$2(data, "data");
                if (members.length !== data.length)
                {
                    throw new $.$$.S.ArgumentException().$ctor$14($.$srsf.S.SR.Argument_DataLengthDifferent);
                }
                for(/*int*/ let i = 0; i < members.length; i++)
                {
                    /*MemberInfo*/ let member = $.$$.System.Array.$ReadT1.call(members, i);
                    if ($.$$.SR.MemberInfo.op_Equality(member, null))
                    {
                        throw new $.$$.S.ArgumentNullException().$ctor$18("members", $.$srsf.S.SR.Format$6($.$srsf.S.SR.ArgumentNull_NullMember, $.$box(i, $.$$.S.Int32)));
                    }
                    /*object?*/ let value = $.$$.System.Array.$ReadT1.call(data, i);
                    if (value === null)
                    {
                        continue;
                    }
                    let field;
                    if ($.$is(member, $.$$.SR.FieldInfo, { set $v($v){ field = $v; } }))
                    {
                        field.SetValue$1(obj, $.$$.System.Array.$ReadT1.call(data, i));
                        continue;
                    }
                    throw new $.$$.SRS.SerializationException().$ctor$12($.$srsf.S.SR.Serialization_UnknownMemberInfo);
                }
                return obj;
            }
            //--TRIMMABLE-BOUNDARY-END(81605230619)
            
            //--TRIMMABLE-BOUNDARY-START(30065623067)
            static /*object?[] */ GetObjectData(/*object*/ obj, /*MemberInfo[]*/ members)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(30065623067);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.S.ArgumentNullException.ThrowIfNull$2(obj, "obj");
                $.$$.S.ArgumentNullException.ThrowIfNull$2(members, "members");
                /*object?[]*/ let data = $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Object), null, [members.length], null);
                for(/*int*/ let i = 0; i < members.length; i++)
                {
                    /*MemberInfo*/ let member = $.$$.System.Array.$ReadT1.call(members, i);
                    if ($.$$.SR.MemberInfo.op_Equality(member, null))
                    {
                        throw new $.$$.S.ArgumentNullException().$ctor$18("members", $.$srsf.S.SR.Format$6($.$srsf.S.SR.ArgumentNull_NullMember, $.$box(i, $.$$.S.Int32)));
                    }
                    /*FieldInfo?*/ let field = $.$as(member, $.$$.SR.FieldInfo);
                    if ($.$$.SR.FieldInfo.op_Equality$1(field, null))
                    {
                        throw new $.$$.SRS.SerializationException().$ctor$12($.$srsf.S.SR.Serialization_UnknownMemberInfo);
                    }
                    $.$$.System.Array.$WriteT1.call(data, field.GetValue(obj), i);
                }
                return data;
            }
            //--TRIMMABLE-BOUNDARY-END(30065623067)
            
            //--TRIMMABLE-BOUNDARY-START(55835426843)
            static /*ISerializationSurrogate */ GetSurrogateForCyclicalReference(/*ISerializationSurrogate*/ innerSurrogate)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(55835426843);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.S.ArgumentNullException.ThrowIfNull$2(innerSurrogate, "innerSurrogate");
                return new $.$srsf.SRS.SurrogateForCyclicalReference().$ctor$1(innerSurrogate);
            }
            //--TRIMMABLE-BOUNDARY-END(55835426843)
            
            //--TRIMMABLE-BOUNDARY-START(60130394139)
            static /*Type? */ GetTypeFromAssembly(/*Assembly*/ assem, /*string*/ name)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(60130394139);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.S.ArgumentNullException.ThrowIfNull$2(assem, "assem");
                return assem.GetType$1(name, false, false);
            }
            //--TRIMMABLE-BOUNDARY-END(60130394139)
            
            //--TRIMMABLE-BOUNDARY-START(73015296027)
            static /*Assembly */ LoadAssemblyFromString(/*string*/ assemblyName)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(73015296027);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$$.SR.Assembly.Load$3(new $.$$.SR.AssemblyName().$ctor$2(assemblyName));
            }
            //--TRIMMABLE-BOUNDARY-END(73015296027)
            
            //--TRIMMABLE-BOUNDARY-START(77310263323)
            static /*Assembly? */ LoadAssemblyFromStringNoThrow(/*string*/ assemblyName)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(77310263323);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                try
                {
                    return $.$srsf.SRS.FormatterServices.LoadAssemblyFromString(assemblyName);
                }
                catch($e)
                {
                }
                return null;
            }
            //--TRIMMABLE-BOUNDARY-END(77310263323)
            
            //--TRIMMABLE-BOUNDARY-START(12885753883)
            static /*string */ GetClrAssemblyName(/*Type*/ type, /*out bool*/ hasTypeForwardedFrom)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12885753883);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.S.ArgumentNullException.ThrowIfNull$2(type, "type");
                /*Type*/ let attributedType = type;
                while(attributedType.HasElementType)
                {
                    attributedType = attributedType.GetElementType();
                }
                let $i5 = 0;
                let $arr5 = attributedType.GetCustomAttributes$1($.$$.SRC.TypeForwardedFromAttribute.$type, false);
                while ($i5 < $arr5.length)
                {
                    let first = $arr5[$i5++];
                    hasTypeForwardedFrom.$v = true;
                    return ($.$cast(first, $.$$.SRC.TypeForwardedFromAttribute)).AssemblyFullName;
                }
                hasTypeForwardedFrom.$v = false;
                return type.Assembly.FullName;
            }
            //--TRIMMABLE-BOUNDARY-END(12885753883)
            
            //--TRIMMABLE-BOUNDARY-START(17180721179)
            static /*string */ GetClrTypeFullName(/*Type*/ type)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17180721179);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return type.IsArray ? $.$srsf.SRS.FormatterServices.GetClrTypeFullNameForArray(type) : $.$srsf.SRS.FormatterServices.GetClrTypeFullNameForNonArrayTypes(type);
            }
            //--TRIMMABLE-BOUNDARY-END(17180721179)
            
            //--TRIMMABLE-BOUNDARY-START(21475688475)
            static /*string */ GetClrTypeFullNameForArray(/*Type*/ type)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21475688475);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*int*/ let rank = type.GetArrayRank();
                $.$$.SD.Debug.Assert$4(rank >= 1, "rank >= 1");
                /*string*/ let typeName = $.$srsf.SRS.FormatterServices.GetClrTypeFullName(type.GetElementType());
                return rank === 1 ? $.$strNN(typeName) + "[]" : $.$strNN(typeName) + "[" + $.$strNN($.$$.S.String.Create(/*,*/ 44, ((rank - 1) | 0))) + "]";
            }
            //--TRIMMABLE-BOUNDARY-END(21475688475)
            
            //--TRIMMABLE-BOUNDARY-START(25770655771)
            static /*string */ GetClrTypeFullNameForNonArrayTypes(/*Type*/ type)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25770655771);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (!type.IsGenericType)
                {
                    return type.FullName;
                }
                /*var*/ let builder = new $.$$.ST.StringBuilder().$ctor$8(type.GetGenericTypeDefinition().FullName).Append$5(/*[*/ 91);
                /*bool*/ let hasTypeForwardedFrom;
                let $i6 = 0;
                let $arr6 = type.GetGenericArguments();
                while ($i6 < $arr6.length)
                {
                    let genericArgument = $arr6[$i6++];
                    builder.Append$5(/*[*/ 91).Append$21($.$srsf.SRS.FormatterServices.GetClrTypeFullName(genericArgument)).Append$21(", ");
                    builder.Append$21($.$srsf.SRS.FormatterServices.GetClrAssemblyName(genericArgument, $.$ref(() => hasTypeForwardedFrom, ($v) => hasTypeForwardedFrom = $v, $.$$.S.Boolean))).Append$21("],");
                }
                return builder.Remove$1(((builder.Length - 1) | 0), 1).Append$5(/*]*/ 93).ToString();
            }
            //--TRIMMABLE-BOUNDARY-END(25770655771)
            
            //--TRIMMABLE-BOUNDARY-START(4295819291)
            //Static Initializer
            static $sinit()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295819291);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                {
                    //--TRIMMABLE-BOUNDARY-START(85900197915)
                    this.s_memberInfoTable = new ($.$scc.SCC.ConcurrentDictionary$$$($.$srsf.SRS.MemberHolder, $.$typeArray($.$$.SR.MemberInfo)))().$ctor$1();
                    //--TRIMMABLE-BOUNDARY-END(85900197915)
                    
                }
            }
            //--TRIMMABLE-BOUNDARY-END(4295819291)
            
            static $h = 851995;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(68720328731),
    {
      "r": $.$typeArray($.$$.SR.FieldInfo).$h,
      "p": [
        {
          "n": "type",
          "p": 188547073
        }
      ],
      "n": "InternalGetSerializableMembers",
      "d": 851995,
      "h": 68720328731,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(68720328731),
//--TRIMMABLE-BOUNDARY-START(42950524955),
    {
      "r": $.$typeArray($.$$.SR.FieldInfo).$h,
      "p": [
        {
          "n": "type",
          "p": 188547073
        }
      ],
      "n": "GetSerializableFields",
      "d": 851995,
      "h": 42950524955,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(42950524955),
//--TRIMMABLE-BOUNDARY-START(34360590363),
    {
      "r": 262145,
      "p": [
        {
          "n": "parentType",
          "p": 188547073
        },
        {
          "n": "parentTypes",
          "p": $.$typeArray($.$$.S.Type).$h,
          "f": 2
        },
        {
          "n": "parentTypeCount",
          "p": 655361,
          "f": 2
        }
      ],
      "n": "GetParentTypes",
      "d": 851995,
      "h": 34360590363,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(34360590363),
//--TRIMMABLE-BOUNDARY-START(51540459547),
    {
      "r": $.$typeArray($.$$.SR.MemberInfo).$h,
      "p": [
        {
          "n": "type",
          "p": 188547073
        }
      ],
      "n": "GetSerializableMembers",
      "o": "@$1",
      "d": 851995,
      "h": 51540459547,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(51540459547),
//--TRIMMABLE-BOUNDARY-START(47245492251),
    {
      "r": $.$typeArray($.$$.SR.MemberInfo).$h,
      "p": [
        {
          "n": "type",
          "p": 188547073
        },
        {
          "n": "context",
          "p": 158990337
        }
      ],
      "n": "GetSerializableMembers",
      "d": 851995,
      "h": 47245492251,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(47245492251),
//--TRIMMABLE-BOUNDARY-START(8590786587),
    {
      "r": 65537,
      "p": [
        {
          "n": "t",
          "p": 188547073
        },
        {
          "n": "securityLevel",
          "p": 786459
        }
      ],
      "n": "CheckTypeSecurity",
      "d": 851995,
      "h": 8590786587,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8590786587),
//--TRIMMABLE-BOUNDARY-START(64425361435),
    {
      "r": 131073,
      "p": [
        {
          "n": "type",
          "p": 188547073
        }
      ],
      "n": "GetUninitializedObject",
      "d": 851995,
      "h": 64425361435,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(64425361435),
//--TRIMMABLE-BOUNDARY-START(38655557659),
    {
      "r": 131073,
      "p": [
        {
          "n": "type",
          "p": 188547073
        }
      ],
      "n": "GetSafeUninitializedObject",
      "d": 851995,
      "h": 38655557659,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(38655557659),
//--TRIMMABLE-BOUNDARY-START(90195165211),
    {
      "r": 65537,
      "p": [
        {
          "n": "fi",
          "p": 116195329
        },
        {
          "n": "target",
          "p": 131073
        },
        {
          "n": "value",
          "p": 131073
        }
      ],
      "n": "SerializationSetValue",
      "d": 851995,
      "h": 90195165211,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(90195165211),
//--TRIMMABLE-BOUNDARY-START(81605230619),
    {
      "r": 131073,
      "p": [
        {
          "n": "obj",
          "p": 131073
        },
        {
          "n": "members",
          "p": $.$typeArray($.$$.SR.MemberInfo).$h
        },
        {
          "n": "data",
          "p": $.$typeArray($.$$.S.Object).$h
        }
      ],
      "n": "PopulateObjectMembers",
      "d": 851995,
      "h": 81605230619,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(81605230619),
//--TRIMMABLE-BOUNDARY-START(30065623067),
    {
      "r": $.$typeArray($.$$.S.Object).$h,
      "p": [
        {
          "n": "obj",
          "p": 131073
        },
        {
          "n": "members",
          "p": $.$typeArray($.$$.SR.MemberInfo).$h
        }
      ],
      "n": "GetObjectData",
      "d": 851995,
      "h": 30065623067,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(30065623067),
//--TRIMMABLE-BOUNDARY-START(55835426843),
    {
      "r": 983067,
      "p": [
        {
          "n": "innerSurrogate",
          "p": 983067
        }
      ],
      "n": "GetSurrogateForCyclicalReference",
      "d": 851995,
      "h": 55835426843,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(55835426843),
//--TRIMMABLE-BOUNDARY-START(60130394139),
    {
      "r": 188547073,
      "p": [
        {
          "n": "assem",
          "p": 107020289
        },
        {
          "n": "name",
          "p": 1310721
        }
      ],
      "n": "GetTypeFromAssembly",
      "d": 851995,
      "h": 60130394139,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(60130394139),
//--TRIMMABLE-BOUNDARY-START(73015296027),
    {
      "r": 107020289,
      "p": [
        {
          "n": "assemblyName",
          "p": 1310721
        }
      ],
      "n": "LoadAssemblyFromString",
      "d": 851995,
      "h": 73015296027,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(73015296027),
//--TRIMMABLE-BOUNDARY-START(77310263323),
    {
      "r": 107020289,
      "p": [
        {
          "n": "assemblyName",
          "p": 1310721
        }
      ],
      "n": "LoadAssemblyFromStringNoThrow",
      "d": 851995,
      "h": 77310263323,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(77310263323),
//--TRIMMABLE-BOUNDARY-START(12885753883),
    {
      "r": 1310721,
      "p": [
        {
          "n": "type",
          "p": 188547073
        },
        {
          "n": "hasTypeForwardedFrom",
          "p": 262145,
          "f": 2
        }
      ],
      "n": "GetClrAssemblyName",
      "d": 851995,
      "h": 12885753883,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(12885753883),
//--TRIMMABLE-BOUNDARY-START(17180721179),
    {
      "r": 1310721,
      "p": [
        {
          "n": "type",
          "p": 188547073
        }
      ],
      "n": "GetClrTypeFullName",
      "d": 851995,
      "h": 17180721179,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(17180721179),
//--TRIMMABLE-BOUNDARY-START(21475688475),
    {
      "r": 1310721,
      "p": [
        {
          "n": "type",
          "p": 188547073
        }
      ],
      "n": "GetClrTypeFullNameForArray",
      "d": 851995,
      "h": 21475688475,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(21475688475),
//--TRIMMABLE-BOUNDARY-START(25770655771),
    {
      "r": 1310721,
      "p": [
        {
          "n": "type",
          "p": 188547073
        }
      ],
      "n": "GetClrTypeFullNameForNonArrayTypes",
      "d": 851995,
      "h": 25770655771,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(25770655771)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(85900197915),
    {
      "t": $.$scc.SCC.ConcurrentDictionary$$$($.$srsf.SRS.MemberHolder, $.$typeArray($.$$.SR.MemberInfo)).$h,
      "n": "s_memberInfoTable",
      "d": 851995,
      "h": 85900197915,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(85900197915)
  ],
  "h": 851995,
  "a": [
    {
      "t": 104464385,
      "c": 30169235457,
      "a": [
        {
          "v": "Formatter-based serialization is obsolete and should not be used.",
          "t": 1310721
        }
      ],
      "n": [
        {
          "n": "DiagnosticId",
          "v": "SYSLIB0050",
          "t": 1310721
        },
        {
          "n": "UrlFormat",
          "v": "https://aka.ms/dotnet-warnings/{0}",
          "t": 1310721
        }
      ]
    }
  ]
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `System.Runtime.Serialization.FormatterServices`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `System${separator}Runtime${separator}Serialization${separator}FormatterServices`; }
        });
        //--TRIMMABLE-BOUNDARY-END(851995)
        
        

        //--TRIMMABLE-BOUNDARY-START(458779)
        $asm.$cls(`$srsf.SRS.FormatterConverter`, ($self) => class FormatterConverter extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8590393371)
            /*object */ Convert(/*object*/ value, /*Type*/ type)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590393371);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.S.ArgumentNullException.ThrowIfNull$2(value, "value");
                return $.$$.S.Convert.ChangeType(value, type, $.$$.SG.CultureInfo.InvariantCulture);
            }
            //--TRIMMABLE-BOUNDARY-END(8590393371)
            
            //--TRIMMABLE-BOUNDARY-START(12885360667)
            /*object */ Convert$1(/*object*/ value, /*TypeCode*/ typeCode)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12885360667);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.S.ArgumentNullException.ThrowIfNull$2(value, "value");
                return $.$$.S.Convert.ChangeType$2(value, typeCode, $.$$.SG.CultureInfo.InvariantCulture);
            }
            //--TRIMMABLE-BOUNDARY-END(12885360667)
            
            //--TRIMMABLE-BOUNDARY-START(17180327963)
            /*bool */ ToBoolean(/*object*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17180327963);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.S.ArgumentNullException.ThrowIfNull$2(value, "value");
                return $.$$.S.Convert.ToBoolean$9(value, $.$$.SG.CultureInfo.InvariantCulture);
            }
            //--TRIMMABLE-BOUNDARY-END(17180327963)
            
            //--TRIMMABLE-BOUNDARY-START(25770262555)
            /*char */ ToChar(/*object*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25770262555);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.S.ArgumentNullException.ThrowIfNull$2(value, "value");
                return $.$$.S.Convert.ToChar$9(value, $.$$.SG.CultureInfo.InvariantCulture);
            }
            //--TRIMMABLE-BOUNDARY-END(25770262555)
            
            //--TRIMMABLE-BOUNDARY-START(55835033627)
            /*sbyte */ ToSByte(/*object*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(55835033627);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.S.ArgumentNullException.ThrowIfNull$2(value, "value");
                return $.$$.S.Convert.ToSByte$9(value, $.$$.SG.CultureInfo.InvariantCulture);
            }
            //--TRIMMABLE-BOUNDARY-END(55835033627)
            
            //--TRIMMABLE-BOUNDARY-START(21475295259)
            /*byte */ ToByte(/*object*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21475295259);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.S.ArgumentNullException.ThrowIfNull$2(value, "value");
                return $.$$.S.Convert.ToByte$9(value, $.$$.SG.CultureInfo.InvariantCulture);
            }
            //--TRIMMABLE-BOUNDARY-END(21475295259)
            
            //--TRIMMABLE-BOUNDARY-START(42950131739)
            /*short */ ToInt16(/*object*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(42950131739);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.S.ArgumentNullException.ThrowIfNull$2(value, "value");
                return $.$$.S.Convert.ToInt16$9(value, $.$$.SG.CultureInfo.InvariantCulture);
            }
            //--TRIMMABLE-BOUNDARY-END(42950131739)
            
            //--TRIMMABLE-BOUNDARY-START(68719935515)
            /*ushort */ ToUInt16(/*object*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(68719935515);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.S.ArgumentNullException.ThrowIfNull$2(value, "value");
                return $.$$.S.Convert.ToUInt16$9(value, $.$$.SG.CultureInfo.InvariantCulture);
            }
            //--TRIMMABLE-BOUNDARY-END(68719935515)
            
            //--TRIMMABLE-BOUNDARY-START(47245099035)
            /*int */ ToInt32(/*object*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(47245099035);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.S.ArgumentNullException.ThrowIfNull$2(value, "value");
                return $.$$.S.Convert.ToInt32$9(value, $.$$.SG.CultureInfo.InvariantCulture);
            }
            //--TRIMMABLE-BOUNDARY-END(47245099035)
            
            //--TRIMMABLE-BOUNDARY-START(73014902811)
            /*uint */ ToUInt32(/*object*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(73014902811);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.S.ArgumentNullException.ThrowIfNull$2(value, "value");
                return $.$$.S.Convert.ToUInt32$9(value, $.$$.SG.CultureInfo.InvariantCulture);
            }
            //--TRIMMABLE-BOUNDARY-END(73014902811)
            
            //--TRIMMABLE-BOUNDARY-START(51540066331)
            /*long */ ToInt64(/*object*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(51540066331);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.S.ArgumentNullException.ThrowIfNull$2(value, "value");
                return $.$$.S.Convert.ToInt64$9(value, $.$$.SG.CultureInfo.InvariantCulture);
            }
            //--TRIMMABLE-BOUNDARY-END(51540066331)
            
            //--TRIMMABLE-BOUNDARY-START(77309870107)
            /*ulong */ ToUInt64(/*object*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(77309870107);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.S.ArgumentNullException.ThrowIfNull$2(value, "value");
                return $.$$.S.Convert.ToUInt64$9(value, $.$$.SG.CultureInfo.InvariantCulture);
            }
            //--TRIMMABLE-BOUNDARY-END(77309870107)
            
            //--TRIMMABLE-BOUNDARY-START(60130000923)
            /*float */ ToSingle(/*object*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(60130000923);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.S.ArgumentNullException.ThrowIfNull$2(value, "value");
                return $.$$.S.Convert.ToSingle$9(value, $.$$.SG.CultureInfo.InvariantCulture);
            }
            //--TRIMMABLE-BOUNDARY-END(60130000923)
            
            //--TRIMMABLE-BOUNDARY-START(38655164443)
            /*double */ ToDouble(/*object*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(38655164443);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.S.ArgumentNullException.ThrowIfNull$2(value, "value");
                return $.$$.S.Convert.ToDouble$9(value, $.$$.SG.CultureInfo.InvariantCulture);
            }
            //--TRIMMABLE-BOUNDARY-END(38655164443)
            
            //--TRIMMABLE-BOUNDARY-START(34360197147)
            /*decimal */ ToDecimal(/*object*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(34360197147);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.S.ArgumentNullException.ThrowIfNull$2(value, "value");
                return $.$$.S.Convert.ToDecimal$9(value, $.$$.SG.CultureInfo.InvariantCulture);
            }
            //--TRIMMABLE-BOUNDARY-END(34360197147)
            
            //--TRIMMABLE-BOUNDARY-START(30065229851)
            /*DateTime */ ToDateTime(/*object*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(30065229851);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.S.ArgumentNullException.ThrowIfNull$2(value, "value");
                return $.$$.S.Convert.ToDateTime$9(value, $.$$.SG.CultureInfo.InvariantCulture);
            }
            //--TRIMMABLE-BOUNDARY-END(30065229851)
            
            //--TRIMMABLE-BOUNDARY-START(64424968219)
            /*string? */ ToString$1(/*object*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(64424968219);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.S.ArgumentNullException.ThrowIfNull$2(value, "value");
                return $.$$.S.Convert.ToString$23(value, $.$$.SG.CultureInfo.InvariantCulture);
            }
            //--TRIMMABLE-BOUNDARY-END(64424968219)
            
            //--TRIMMABLE-BOUNDARY-START(4453040129)
            //Generated interface implemetation for System.Runtime.Serialization.IFormatterConverter.Convert(object, System.Type)
            SRS$IFormatterConverter$Convert()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4453040129);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Convert(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4453040129)
            
            //--TRIMMABLE-BOUNDARY-START(8748007425)
            //Generated interface implemetation for System.Runtime.Serialization.IFormatterConverter.Convert(object, System.TypeCode)
            SRS$IFormatterConverter$Convert$1()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8748007425);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Convert$1(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(8748007425)
            
            //--TRIMMABLE-BOUNDARY-START(13042974721)
            //Generated interface implemetation for System.Runtime.Serialization.IFormatterConverter.ToBoolean(object)
            SRS$IFormatterConverter$ToBoolean()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(13042974721);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.ToBoolean(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(13042974721)
            
            //--TRIMMABLE-BOUNDARY-START(21632909313)
            //Generated interface implemetation for System.Runtime.Serialization.IFormatterConverter.ToChar(object)
            SRS$IFormatterConverter$ToChar()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21632909313);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.ToChar(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(21632909313)
            
            //--TRIMMABLE-BOUNDARY-START(51697680385)
            //Generated interface implemetation for System.Runtime.Serialization.IFormatterConverter.ToSByte(object)
            SRS$IFormatterConverter$ToSByte()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(51697680385);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.ToSByte(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(51697680385)
            
            //--TRIMMABLE-BOUNDARY-START(17337942017)
            //Generated interface implemetation for System.Runtime.Serialization.IFormatterConverter.ToByte(object)
            SRS$IFormatterConverter$ToByte()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17337942017);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.ToByte(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(17337942017)
            
            //--TRIMMABLE-BOUNDARY-START(38812778497)
            //Generated interface implemetation for System.Runtime.Serialization.IFormatterConverter.ToInt16(object)
            SRS$IFormatterConverter$ToInt16()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(38812778497);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.ToInt16(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(38812778497)
            
            //--TRIMMABLE-BOUNDARY-START(64582582273)
            //Generated interface implemetation for System.Runtime.Serialization.IFormatterConverter.ToUInt16(object)
            SRS$IFormatterConverter$ToUInt16()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(64582582273);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.ToUInt16(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(64582582273)
            
            //--TRIMMABLE-BOUNDARY-START(43107745793)
            //Generated interface implemetation for System.Runtime.Serialization.IFormatterConverter.ToInt32(object)
            SRS$IFormatterConverter$ToInt32()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(43107745793);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.ToInt32(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(43107745793)
            
            //--TRIMMABLE-BOUNDARY-START(68877549569)
            //Generated interface implemetation for System.Runtime.Serialization.IFormatterConverter.ToUInt32(object)
            SRS$IFormatterConverter$ToUInt32()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(68877549569);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.ToUInt32(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(68877549569)
            
            //--TRIMMABLE-BOUNDARY-START(47402713089)
            //Generated interface implemetation for System.Runtime.Serialization.IFormatterConverter.ToInt64(object)
            SRS$IFormatterConverter$ToInt64()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(47402713089);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.ToInt64(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(47402713089)
            
            //--TRIMMABLE-BOUNDARY-START(73172516865)
            //Generated interface implemetation for System.Runtime.Serialization.IFormatterConverter.ToUInt64(object)
            SRS$IFormatterConverter$ToUInt64()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(73172516865);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.ToUInt64(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(73172516865)
            
            //--TRIMMABLE-BOUNDARY-START(55992647681)
            //Generated interface implemetation for System.Runtime.Serialization.IFormatterConverter.ToSingle(object)
            SRS$IFormatterConverter$ToSingle()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(55992647681);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.ToSingle(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(55992647681)
            
            //--TRIMMABLE-BOUNDARY-START(34517811201)
            //Generated interface implemetation for System.Runtime.Serialization.IFormatterConverter.ToDouble(object)
            SRS$IFormatterConverter$ToDouble()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(34517811201);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.ToDouble(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(34517811201)
            
            //--TRIMMABLE-BOUNDARY-START(30222843905)
            //Generated interface implemetation for System.Runtime.Serialization.IFormatterConverter.ToDecimal(object)
            SRS$IFormatterConverter$ToDecimal()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(30222843905);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.ToDecimal(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(30222843905)
            
            //--TRIMMABLE-BOUNDARY-START(25927876609)
            //Generated interface implemetation for System.Runtime.Serialization.IFormatterConverter.ToDateTime(object)
            SRS$IFormatterConverter$ToDateTime()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25927876609);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.ToDateTime(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(25927876609)
            
            //--TRIMMABLE-BOUNDARY-START(60287614977)
            //Generated interface implemetation for System.Runtime.Serialization.IFormatterConverter.ToString(object)
            SRS$IFormatterConverter$ToString()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(60287614977);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.ToString$1(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(60287614977)
            
            //--TRIMMABLE-BOUNDARY-START(4295426075)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295426075);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295426075)
            
            //--TRIMMABLE-BOUNDARY-START(4295426075)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4295426075)
            
            static $h = 458779;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8590393371),
    {
      "r": 131073,
      "p": [
        {
          "n": "value",
          "p": 131073
        },
        {
          "n": "type",
          "p": 188547073
        }
      ],
      "n": "Convert",
      "d": 458779,
      "h": 8590393371,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8590393371),
//--TRIMMABLE-BOUNDARY-START(12885360667),
    {
      "r": 131073,
      "p": [
        {
          "n": "value",
          "p": 131073
        },
        {
          "n": "typeCode",
          "p": 188678145
        }
      ],
      "n": "Convert",
      "o": "@$1",
      "d": 458779,
      "h": 12885360667,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(12885360667),
//--TRIMMABLE-BOUNDARY-START(17180327963),
    {
      "r": 262145,
      "p": [
        {
          "n": "value",
          "p": 131073
        }
      ],
      "n": "ToBoolean",
      "d": 458779,
      "h": 17180327963,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(17180327963),
//--TRIMMABLE-BOUNDARY-START(25770262555),
    {
      "r": 458753,
      "p": [
        {
          "n": "value",
          "p": 131073
        }
      ],
      "n": "ToChar",
      "d": 458779,
      "h": 25770262555,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(25770262555),
//--TRIMMABLE-BOUNDARY-START(55835033627),
    {
      "r": 327681,
      "p": [
        {
          "n": "value",
          "p": 131073
        }
      ],
      "n": "ToSByte",
      "d": 458779,
      "h": 55835033627,
      "f": 16777217,
      "a": [
        {
          "t": 54984705,
          "c": 8644919297,
          "a": [
            {
              "v": false,
              "t": 262145
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(55835033627),
//--TRIMMABLE-BOUNDARY-START(21475295259),
    {
      "r": 393217,
      "p": [
        {
          "n": "value",
          "p": 131073
        }
      ],
      "n": "ToByte",
      "d": 458779,
      "h": 21475295259,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(21475295259),
//--TRIMMABLE-BOUNDARY-START(42950131739),
    {
      "r": 524289,
      "p": [
        {
          "n": "value",
          "p": 131073
        }
      ],
      "n": "ToInt16",
      "d": 458779,
      "h": 42950131739,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(42950131739),
//--TRIMMABLE-BOUNDARY-START(68719935515),
    {
      "r": 589825,
      "p": [
        {
          "n": "value",
          "p": 131073
        }
      ],
      "n": "ToUInt16",
      "d": 458779,
      "h": 68719935515,
      "f": 16777217,
      "a": [
        {
          "t": 54984705,
          "c": 8644919297,
          "a": [
            {
              "v": false,
              "t": 262145
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(68719935515),
//--TRIMMABLE-BOUNDARY-START(47245099035),
    {
      "r": 655361,
      "p": [
        {
          "n": "value",
          "p": 131073
        }
      ],
      "n": "ToInt32",
      "d": 458779,
      "h": 47245099035,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(47245099035),
//--TRIMMABLE-BOUNDARY-START(73014902811),
    {
      "r": 720897,
      "p": [
        {
          "n": "value",
          "p": 131073
        }
      ],
      "n": "ToUInt32",
      "d": 458779,
      "h": 73014902811,
      "f": 16777217,
      "a": [
        {
          "t": 54984705,
          "c": 8644919297,
          "a": [
            {
              "v": false,
              "t": 262145
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(73014902811),
//--TRIMMABLE-BOUNDARY-START(51540066331),
    {
      "r": 917505,
      "p": [
        {
          "n": "value",
          "p": 131073
        }
      ],
      "n": "ToInt64",
      "d": 458779,
      "h": 51540066331,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(51540066331),
//--TRIMMABLE-BOUNDARY-START(77309870107),
    {
      "r": 983041,
      "p": [
        {
          "n": "value",
          "p": 131073
        }
      ],
      "n": "ToUInt64",
      "d": 458779,
      "h": 77309870107,
      "f": 16777217,
      "a": [
        {
          "t": 54984705,
          "c": 8644919297,
          "a": [
            {
              "v": false,
              "t": 262145
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(77309870107),
//--TRIMMABLE-BOUNDARY-START(60130000923),
    {
      "r": 1114113,
      "p": [
        {
          "n": "value",
          "p": 131073
        }
      ],
      "n": "ToSingle",
      "d": 458779,
      "h": 60130000923,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(60130000923),
//--TRIMMABLE-BOUNDARY-START(38655164443),
    {
      "r": 1179649,
      "p": [
        {
          "n": "value",
          "p": 131073
        }
      ],
      "n": "ToDouble",
      "d": 458779,
      "h": 38655164443,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(38655164443),
//--TRIMMABLE-BOUNDARY-START(34360197147),
    {
      "r": 66846721,
      "p": [
        {
          "n": "value",
          "p": 131073
        }
      ],
      "n": "ToDecimal",
      "d": 458779,
      "h": 34360197147,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(34360197147),
//--TRIMMABLE-BOUNDARY-START(30065229851),
    {
      "r": 65994753,
      "p": [
        {
          "n": "value",
          "p": 131073
        }
      ],
      "n": "ToDateTime",
      "d": 458779,
      "h": 30065229851,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(30065229851),
//--TRIMMABLE-BOUNDARY-START(64424968219),
    {
      "r": 1310721,
      "p": [
        {
          "n": "value",
          "p": 131073
        }
      ],
      "n": "ToString",
      "o": "@$1",
      "d": 458779,
      "h": 64424968219,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(64424968219)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295426075),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 458779,
      "h": 4295426075,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295426075)
  ],
  "h": 458779,
  "a": [
    {
      "t": 104464385,
      "c": 30169235457,
      "a": [
        {
          "v": "Formatter-based serialization is obsolete and should not be used.",
          "t": 1310721
        }
      ],
      "n": [
        {
          "n": "DiagnosticId",
          "v": "SYSLIB0050",
          "t": 1310721
        },
        {
          "n": "UrlFormat",
          "v": "https://aka.ms/dotnet-warnings/{0}",
          "t": 1310721
        }
      ]
    }
  ]
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.SRS.IFormatterConverter ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `System.Runtime.Serialization.FormatterConverter`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `System${separator}Runtime${separator}Serialization${separator}FormatterConverter`; }
        });
        //--TRIMMABLE-BOUNDARY-END(458779)
        
        

        //--TRIMMABLE-BOUNDARY-START(524315)
        $asm.$cls(`$srsf.SRSFB.BinaryFormatter`, ($self) => class BinaryFormatter extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(21475360795)
            /*ISurrogateSelector?*/ _surrogates = null;
            //--TRIMMABLE-BOUNDARY-END(21475360795)
            
            //--TRIMMABLE-BOUNDARY-START(12885426203)
            /*StreamingContext*/ _context;
            //--TRIMMABLE-BOUNDARY-END(12885426203)
            
            //--TRIMMABLE-BOUNDARY-START(8590458907)
            /*SerializationBinder?*/ _binder = null;
            //--TRIMMABLE-BOUNDARY-END(8590458907)
            
            //--TRIMMABLE-BOUNDARY-START(25770328091)
            /*FormatterTypeStyle*/ _typeFormat = 1;
            //--TRIMMABLE-BOUNDARY-END(25770328091)
            
            //--TRIMMABLE-BOUNDARY-START(4295491611)
            /*FormatterAssemblyStyle*/ _assemblyFormat = 0;
            //--TRIMMABLE-BOUNDARY-END(4295491611)
            
            //--TRIMMABLE-BOUNDARY-START(17180393499)
            /*TypeFilterLevel*/ _securityLevel = 3;
            //--TRIMMABLE-BOUNDARY-END(17180393499)
            
            //--TRIMMABLE-BOUNDARY-START(171799216155)
            /*FormatterTypeStyle */ get TypeFormat()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(107374706715);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this._typeFormat;
            }
            /*FormatterTypeStyle */ set TypeFormat(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(163209281563);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this._typeFormat = value;
            }
            //--TRIMMABLE-BOUNDARY-END(171799216155)
            
            //--TRIMMABLE-BOUNDARY-START(38655229979)
            /*FormatterAssemblyStyle */ get AssemblyFormat()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(64425033755);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this._assemblyFormat;
            }
            /*FormatterAssemblyStyle */ set AssemblyFormat(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(120259608603);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this._assemblyFormat = value;
            }
            //--TRIMMABLE-BOUNDARY-END(38655229979)
            
            //--TRIMMABLE-BOUNDARY-START(55835099163)
            /*TypeFilterLevel */ get FilterLevel()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(90194837531);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this._securityLevel;
            }
            /*TypeFilterLevel */ set FilterLevel(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(146029412379);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this._securityLevel = value;
            }
            //--TRIMMABLE-BOUNDARY-END(55835099163)
            
            //--TRIMMABLE-BOUNDARY-START(167504248859)
            /*ISurrogateSelector? */ get SurrogateSelector()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(98784772123);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this._surrogates;
            }
            /*ISurrogateSelector? */ set SurrogateSelector(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(154619346971);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this._surrogates = value;
            }
            //--TRIMMABLE-BOUNDARY-END(167504248859)
            
            //--TRIMMABLE-BOUNDARY-START(42950197275)
            /*SerializationBinder? */ get Binder()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(73014968347);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this._binder;
            }
            /*SerializationBinder? */ set Binder(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(128849543195);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this._binder = value;
            }
            //--TRIMMABLE-BOUNDARY-END(42950197275)
            
            //--TRIMMABLE-BOUNDARY-START(47245164571)
            /*StreamingContext */ get Context()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(81604902939);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this._context;
            }
            /*StreamingContext */ set Context(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(137439477787);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this._context = value;
            }
            //--TRIMMABLE-BOUNDARY-END(47245164571)
            
            //--TRIMMABLE-BOUNDARY-START(30065295387)
            $ctor$1()
            {
                this.$ctor$2(null, new $.$$.SRS.StreamingContext().$ctor$4(255/*StreamingContextStates.All*/));
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(30065295387);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(30065295387)
            
            //--TRIMMABLE-BOUNDARY-START(34360262683)
            $ctor$2(/*ISurrogateSelector?*/ selector, /*StreamingContext*/ context)
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(34360262683);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this._surrogates = selector;
                    this._context = context;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(34360262683)
            
            //--TRIMMABLE-BOUNDARY-START(51540131867)
            /*object */ Deserialize(/*Stream*/ serializationStream)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(51540131867);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    throw new $.$$.S.PlatformNotSupportedException().$ctor$16($.$srsf.S.SR.BinaryFormatter_Removed);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(51540131867)
            
            //--TRIMMABLE-BOUNDARY-START(111669674011)
            /*void */ Serialize(/*Stream*/ serializationStream, /*object*/ graph)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(111669674011);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    throw new $.$$.S.PlatformNotSupportedException().$ctor$16($.$srsf.S.SR.BinaryFormatter_Removed);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(111669674011)
            
            //--TRIMMABLE-BOUNDARY-START(12885819419)
            //Generated interface implemetation for System.Runtime.Serialization.IFormatter.Deserialize(System.IO.Stream)
            SRS$IFormatter$Deserialize()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12885819419);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Deserialize(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(12885819419)
            
            //--TRIMMABLE-BOUNDARY-START(51540525083)
            //Generated interface implemetation for System.Runtime.Serialization.IFormatter.Serialize(System.IO.Stream, object)
            SRS$IFormatter$Serialize()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(51540525083);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Serialize(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(51540525083)
            
            //--TRIMMABLE-BOUNDARY-START(38655623195)
            //Generated interface implemetation for System.Runtime.Serialization.IFormatter.SurrogateSelector.get
            get SRS$IFormatter$SurrogateSelector()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(81605296155);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.SurrogateSelector;
            }
            //--TRIMMABLE-BOUNDARY-END(38655623195)
            
            //--TRIMMABLE-BOUNDARY-START(77310328859)
            //Generated interface implemetation for System.Runtime.Serialization.IFormatter.SurrogateSelector.set
            set SRS$IFormatter$SurrogateSelector(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(81605296155);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.SurrogateSelector = value;
            }
            //--TRIMMABLE-BOUNDARY-END(77310328859)
            
            //--TRIMMABLE-BOUNDARY-START(21475754011)
            //Generated interface implemetation for System.Runtime.Serialization.IFormatter.Binder.get
            get SRS$IFormatter$Binder()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295884827);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Binder;
            }
            //--TRIMMABLE-BOUNDARY-END(21475754011)
            
            //--TRIMMABLE-BOUNDARY-START(60130459675)
            //Generated interface implemetation for System.Runtime.Serialization.IFormatter.Binder.set
            set SRS$IFormatter$Binder(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295884827);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.Binder = value;
            }
            //--TRIMMABLE-BOUNDARY-END(60130459675)
            
            //--TRIMMABLE-BOUNDARY-START(30065688603)
            //Generated interface implemetation for System.Runtime.Serialization.IFormatter.Context.get
            get SRS$IFormatter$Context()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590852123);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Context;
            }
            //--TRIMMABLE-BOUNDARY-END(30065688603)
            
            //--TRIMMABLE-BOUNDARY-START(68720394267)
            //Generated interface implemetation for System.Runtime.Serialization.IFormatter.Context.set
            set SRS$IFormatter$Context(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590852123);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.Context = value;
            }
            //--TRIMMABLE-BOUNDARY-END(68720394267)
            
            //--TRIMMABLE-BOUNDARY-START(30065295387)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(30065295387)
            
            //default member initializer
            constructor()
            {
                super();
                //--TRIMMABLE-BOUNDARY-START(12885426203)
                this._context = $.$default($.$$.SRS.StreamingContext);
                //--TRIMMABLE-BOUNDARY-END(12885426203)
                
            }
            static $h = 524315;
            static $f = 0b10010001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(171799216155),
    {
      "p": 655387,
      "g": {
        "r": 0,
        "d": 0,
        "h": 107374706715,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 163209281563,
        "f": 83886081
      },
      "n": "TypeFormat",
      "d": 524315,
      "h": 171799216155,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(171799216155),
//--TRIMMABLE-BOUNDARY-START(38655229979),
    {
      "p": 589851,
      "g": {
        "r": 0,
        "d": 0,
        "h": 64425033755,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 120259608603,
        "f": 83886081
      },
      "n": "AssemblyFormat",
      "d": 524315,
      "h": 38655229979,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(38655229979),
//--TRIMMABLE-BOUNDARY-START(55835099163),
    {
      "p": 786459,
      "g": {
        "r": 0,
        "d": 0,
        "h": 90194837531,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 146029412379,
        "f": 83886081
      },
      "n": "FilterLevel",
      "d": 524315,
      "h": 55835099163,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(55835099163),
//--TRIMMABLE-BOUNDARY-START(167504248859),
    {
      "p": 1048603,
      "g": {
        "r": 0,
        "d": 0,
        "h": 98784772123,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 154619346971,
        "f": 83886081
      },
      "n": "SurrogateSelector",
      "d": 524315,
      "h": 167504248859,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(167504248859),
//--TRIMMABLE-BOUNDARY-START(42950197275),
    {
      "p": 1572891,
      "g": {
        "r": 0,
        "d": 0,
        "h": 73014968347,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 128849543195,
        "f": 83886081
      },
      "n": "Binder",
      "d": 524315,
      "h": 42950197275,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(42950197275),
//--TRIMMABLE-BOUNDARY-START(47245164571),
    {
      "p": 158990337,
      "g": {
        "r": 0,
        "d": 0,
        "h": 81604902939,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 137439477787,
        "f": 83886081
      },
      "n": "Context",
      "d": 524315,
      "h": 47245164571,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(47245164571)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(51540131867),
    {
      "r": 131073,
      "p": [
        {
          "n": "serializationStream",
          "p": 95748097
        }
      ],
      "n": "Deserialize",
      "d": 524315,
      "h": 51540131867,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(51540131867),
//--TRIMMABLE-BOUNDARY-START(111669674011),
    {
      "r": 65537,
      "p": [
        {
          "n": "serializationStream",
          "p": 95748097
        },
        {
          "n": "graph",
          "p": 131073
        }
      ],
      "n": "Serialize",
      "d": 524315,
      "h": 111669674011,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(111669674011)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(21475360795),
    {
      "t": 1048603,
      "n": "_surrogates",
      "d": 524315,
      "h": 21475360795,
      "f": 4194312
    },
//--TRIMMABLE-BOUNDARY-END(21475360795),
//--TRIMMABLE-BOUNDARY-START(12885426203),
    {
      "t": 158990337,
      "n": "_context",
      "d": 524315,
      "h": 12885426203,
      "f": 4194312
    },
//--TRIMMABLE-BOUNDARY-END(12885426203),
//--TRIMMABLE-BOUNDARY-START(8590458907),
    {
      "t": 1572891,
      "n": "_binder",
      "d": 524315,
      "h": 8590458907,
      "f": 4194312
    },
//--TRIMMABLE-BOUNDARY-END(8590458907),
//--TRIMMABLE-BOUNDARY-START(25770328091),
    {
      "t": 655387,
      "n": "_typeFormat",
      "d": 524315,
      "h": 25770328091,
      "f": 4194312
    },
//--TRIMMABLE-BOUNDARY-END(25770328091),
//--TRIMMABLE-BOUNDARY-START(4295491611),
    {
      "t": 589851,
      "n": "_assemblyFormat",
      "d": 524315,
      "h": 4295491611,
      "f": 4194312
    },
//--TRIMMABLE-BOUNDARY-END(4295491611),
//--TRIMMABLE-BOUNDARY-START(17180393499),
    {
      "t": 786459,
      "n": "_securityLevel",
      "d": 524315,
      "h": 17180393499,
      "f": 4194312
    },
//--TRIMMABLE-BOUNDARY-END(17180393499)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(30065295387),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 524315,
      "h": 30065295387,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(30065295387),
//--TRIMMABLE-BOUNDARY-START(34360262683),
    {
      "p": [
        {
          "n": "selector",
          "p": 1048603
        },
        {
          "n": "context",
          "p": 158990337
        }
      ],
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 524315,
      "h": 34360262683,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(34360262683)
  ],
  "h": 524315,
  "a": [
    {
      "t": 104464385,
      "c": 30169235457,
      "a": [
        {
          "v": "BinaryFormatter serialization is obsolete and should not be used. See https://aka.ms/binaryformatter for more information.",
          "t": 1310721
        }
      ],
      "n": [
        {
          "n": "DiagnosticId",
          "v": "SYSLIB0011",
          "t": 1310721
        },
        {
          "n": "UrlFormat",
          "v": "https://aka.ms/dotnet-warnings/{0}",
          "t": 1310721
        }
      ]
    }
  ]
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$srsf.SRS.IFormatter ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `System.Runtime.Serialization.Formatters.Binary.BinaryFormatter`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `System${separator}Runtime${separator}Serialization${separator}Formatters${separator}Binary${separator}BinaryFormatter`; }
        });
        //--TRIMMABLE-BOUNDARY-END(524315)
        
        

        //--TRIMMABLE-BOUNDARY-START(2228251)
        $asm.$cls(`$srsf.SRS.SurrogateSelector`, ($self) => class SurrogateSelector extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8592162843)
            /*SurrogateHashtable*/ _surrogates = null;
            //--TRIMMABLE-BOUNDARY-END(8592162843)
            
            //--TRIMMABLE-BOUNDARY-START(4297195547)
            /*ISurrogateSelector?*/ _nextSelector = null;
            //--TRIMMABLE-BOUNDARY-END(4297195547)
            
            //--TRIMMABLE-BOUNDARY-START(17182097435)
            /*void */ AddSurrogate(/*Type*/ type, /*StreamingContext*/ context, /*ISerializationSurrogate*/ surrogate)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17182097435);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.S.ArgumentNullException.ThrowIfNull$2(type, "type");
                $.$$.S.ArgumentNullException.ThrowIfNull$2(surrogate, "surrogate");
                /*var*/ let key = new $.$srsf.SRS.SurrogateKey().$ctor$1(type, context);
                this._surrogates.Add(key, surrogate);
            }
            //--TRIMMABLE-BOUNDARY-END(17182097435)
            
            //--TRIMMABLE-BOUNDARY-START(34361966619)
            static /*bool */ HasCycle(/*ISurrogateSelector*/ selector)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(34361966619);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.SD.Debug.Assert$4(selector !== null, "[HasCycle]selector!=null");
                /*ISurrogateSelector?*/ let head = selector, tail = selector;
                while(head !== null)
                {
                    head = head.SRS$ISurrogateSelector$GetNextSelector();
                    if (head === null)
                    {
                        return true;
                    }
                    if (head === tail)
                    {
                        return false;
                    }
                    head = head.SRS$ISurrogateSelector$GetNextSelector();
                    tail = tail.SRS$ISurrogateSelector$GetNextSelector();
                    if (head === tail)
                    {
                        return false;
                    }
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(34361966619)
            
            //--TRIMMABLE-BOUNDARY-START(21477064731)
            /*void */ ChainSelector(/*ISurrogateSelector*/ selector)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21477064731);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.S.ArgumentNullException.ThrowIfNull$2(selector, "selector");
                if (selector === this)
                {
                    throw new $.$$.SRS.SerializationException().$ctor$12($.$srsf.S.SR.Serialization_SurrogateCycle);
                }
                if (!$.$srsf.SRS.SurrogateSelector.HasCycle(selector))
                {
                    throw new $.$$.S.ArgumentException().$ctor$13($.$srsf.S.SR.Serialization_SurrogateCycleInArgument, "selector");
                }
                /*ISurrogateSelector?*/ let tempCurr = selector.SRS$ISurrogateSelector$GetNextSelector();
                /*ISurrogateSelector*/ let tempEnd = selector;
                while(tempCurr !== null && tempCurr !== this)
                {
                    tempEnd = tempCurr;
                    tempCurr = tempCurr.SRS$ISurrogateSelector$GetNextSelector();
                }
                if (tempCurr === this)
                {
                    throw new $.$$.S.ArgumentException().$ctor$13($.$srsf.S.SR.Serialization_SurrogateCycle, "selector");
                }
                tempCurr = selector;
                /*ISurrogateSelector?*/ let tempPrev = selector;
                while(tempCurr !== null)
                {
                    if (tempCurr === tempEnd)
                    {
                        tempCurr = this.GetNextSelector();
                    }
                    else 
                    {
                        tempCurr = tempCurr.SRS$ISurrogateSelector$GetNextSelector();
                    }
                    if (tempCurr === null)
                    {
                        break;
                    }
                    if (tempCurr === tempPrev)
                    {
                        throw new $.$$.S.ArgumentException().$ctor$13($.$srsf.S.SR.Serialization_SurrogateCycle, "selector");
                    }
                    if (tempCurr === tempEnd)
                    {
                        tempCurr = this.GetNextSelector();
                    }
                    else 
                    {
                        tempCurr = tempCurr.SRS$ISurrogateSelector$GetNextSelector();
                    }
                    if (tempPrev === tempEnd)
                    {
                        tempPrev = this.GetNextSelector();
                    }
                    else 
                    {
                        $.$$.SD.Debug.Assert$4(tempPrev !== null, "tempPrev != null");
                        tempPrev = tempPrev.SRS$ISurrogateSelector$GetNextSelector();
                    }
                    if (tempCurr === tempPrev)
                    {
                        throw new $.$$.S.ArgumentException().$ctor$13($.$srsf.S.SR.Serialization_SurrogateCycle, "selector");
                    }
                }
                /*ISurrogateSelector?*/ let temp = this._nextSelector;
                this._nextSelector = selector;
                if (temp !== null)
                {
                    tempEnd.SRS$ISurrogateSelector$ChainSelector(temp);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(21477064731)
            
            //--TRIMMABLE-BOUNDARY-START(25772032027)
            /*ISurrogateSelector? */ GetNextSelector()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(25772032027);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return this._nextSelector;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(25772032027)
            
            //--TRIMMABLE-BOUNDARY-START(30066999323)
            /*ISerializationSurrogate? */ GetSurrogate(/*Type*/ type, /*StreamingContext*/ context, /*out ISurrogateSelector*/ selector)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(30066999323);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.S.ArgumentNullException.ThrowIfNull$2(type, "type");
                selector.$v = this;
                /*SurrogateKey*/ let key = new $.$srsf.SRS.SurrogateKey().$ctor$1(type, context);
                /*ISerializationSurrogate?*/ let temp = $.$cast(this._surrogates.get_Item(key), $.$srsf.SRS.ISerializationSurrogate);
                if (temp !== null)
                {
                    return temp;
                }
                if (this._nextSelector !== null)
                {
                    return this._nextSelector.SRS$ISurrogateSelector$GetSurrogate(type, context, selector);
                }
                return null;
            }
            //--TRIMMABLE-BOUNDARY-END(30066999323)
            
            //--TRIMMABLE-BOUNDARY-START(38656933915)
            /*void */ RemoveSurrogate(/*Type*/ type, /*StreamingContext*/ context)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(38656933915);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.S.ArgumentNullException.ThrowIfNull$2(type, "type");
                /*SurrogateKey*/ let key = new $.$srsf.SRS.SurrogateKey().$ctor$1(type, context);
                this._surrogates.Remove(key);
            }
            //--TRIMMABLE-BOUNDARY-END(38656933915)
            
            //--TRIMMABLE-BOUNDARY-START(4296015899)
            //Generated interface implemetation for System.Runtime.Serialization.ISurrogateSelector.ChainSelector(System.Runtime.Serialization.ISurrogateSelector)
            SRS$ISurrogateSelector$ChainSelector()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296015899);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.ChainSelector(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4296015899)
            
            //--TRIMMABLE-BOUNDARY-START(12885950491)
            //Generated interface implemetation for System.Runtime.Serialization.ISurrogateSelector.GetSurrogate(System.Type, System.Runtime.Serialization.StreamingContext, out System.Runtime.Serialization.ISurrogateSelector)
            SRS$ISurrogateSelector$GetSurrogate()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12885950491);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.GetSurrogate(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(12885950491)
            
            //--TRIMMABLE-BOUNDARY-START(8590983195)
            //Generated interface implemetation for System.Runtime.Serialization.ISurrogateSelector.GetNextSelector()
            SRS$ISurrogateSelector$GetNextSelector()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590983195);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.GetNextSelector(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(8590983195)
            
            //--TRIMMABLE-BOUNDARY-START(12887130139)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12887130139);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(12887130139)
            
            //--TRIMMABLE-BOUNDARY-START(12887130139)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(12887130139)
            
            //default member initializer
            constructor()
            {
                super();
                //--TRIMMABLE-BOUNDARY-START(8592162843)
                this._surrogates = new $.$srsf.SRS.SurrogateHashtable().$ctor$18(32);
                //--TRIMMABLE-BOUNDARY-END(8592162843)
                
            }
            static $h = 2228251;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(17182097435),
    {
      "r": 65537,
      "p": [
        {
          "n": "type",
          "p": 188547073
        },
        {
          "n": "context",
          "p": 158990337
        },
        {
          "n": "surrogate",
          "p": 983067
        }
      ],
      "n": "AddSurrogate",
      "d": 2228251,
      "h": 17182097435,
      "f": 16777345
    },
//--TRIMMABLE-BOUNDARY-END(17182097435),
//--TRIMMABLE-BOUNDARY-START(34361966619),
    {
      "r": 262145,
      "p": [
        {
          "n": "selector",
          "p": 1048603
        }
      ],
      "n": "HasCycle",
      "d": 2228251,
      "h": 34361966619,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(34361966619),
//--TRIMMABLE-BOUNDARY-START(21477064731),
    {
      "r": 65537,
      "p": [
        {
          "n": "selector",
          "p": 1048603
        }
      ],
      "n": "ChainSelector",
      "d": 2228251,
      "h": 21477064731,
      "f": 16777345
    },
//--TRIMMABLE-BOUNDARY-END(21477064731),
//--TRIMMABLE-BOUNDARY-START(25772032027),
    {
      "r": 1048603,
      "n": "GetNextSelector",
      "d": 2228251,
      "h": 25772032027,
      "f": 16777345
    },
//--TRIMMABLE-BOUNDARY-END(25772032027),
//--TRIMMABLE-BOUNDARY-START(30066999323),
    {
      "r": 983067,
      "p": [
        {
          "n": "type",
          "p": 188547073
        },
        {
          "n": "context",
          "p": 158990337
        },
        {
          "n": "selector",
          "p": 1048603,
          "f": 2
        }
      ],
      "n": "GetSurrogate",
      "d": 2228251,
      "h": 30066999323,
      "f": 16777345
    },
//--TRIMMABLE-BOUNDARY-END(30066999323),
//--TRIMMABLE-BOUNDARY-START(38656933915),
    {
      "r": 65537,
      "p": [
        {
          "n": "type",
          "p": 188547073
        },
        {
          "n": "context",
          "p": 158990337
        }
      ],
      "n": "RemoveSurrogate",
      "d": 2228251,
      "h": 38656933915,
      "f": 16777345
    },
//--TRIMMABLE-BOUNDARY-END(38656933915)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(8592162843),
    {
      "t": 2097179,
      "n": "_surrogates",
      "d": 2228251,
      "h": 8592162843,
      "f": 4194312
    },
//--TRIMMABLE-BOUNDARY-END(8592162843),
//--TRIMMABLE-BOUNDARY-START(4297195547),
    {
      "t": 1048603,
      "n": "_nextSelector",
      "d": 2228251,
      "h": 4297195547,
      "f": 4194312
    },
//--TRIMMABLE-BOUNDARY-END(4297195547)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(12887130139),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 2228251,
      "h": 12887130139,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(12887130139)
  ],
  "h": 2228251,
  "a": [
    {
      "t": 104464385,
      "c": 30169235457,
      "a": [
        {
          "v": "Formatter-based serialization is obsolete and should not be used.",
          "t": 1310721
        }
      ],
      "n": [
        {
          "n": "DiagnosticId",
          "v": "SYSLIB0050",
          "t": 1310721
        },
        {
          "n": "UrlFormat",
          "v": "https://aka.ms/dotnet-warnings/{0}",
          "t": 1310721
        }
      ]
    }
  ]
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$srsf.SRS.ISurrogateSelector ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `System.Runtime.Serialization.SurrogateSelector`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `System${separator}Runtime${separator}Serialization${separator}SurrogateSelector`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2228251)
        
        

        //--TRIMMABLE-BOUNDARY-START(2031643)
        $asm.$cls(`$srsf.SRS.SurrogateForCyclicalReference`, ($self) => class SurrogateForCyclicalReference extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(4296998939)
            /*ISerializationSurrogate*/ _innerSurrogate = null;
            //--TRIMMABLE-BOUNDARY-END(4296998939)
            
            //--TRIMMABLE-BOUNDARY-START(8591966235)
            $ctor$1(/*ISerializationSurrogate*/ innerSurrogate)
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(8591966235);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$$.SD.Debug.Assert$4(innerSurrogate !== null, "innerSurrogate != null");
                    this._innerSurrogate = innerSurrogate;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(8591966235)
            
            //--TRIMMABLE-BOUNDARY-START(12886933531)
            /*void */ GetObjectData(/*object*/ obj, /*SerializationInfo*/ info, /*StreamingContext*/ context)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12886933531);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this._innerSurrogate.SRS$ISerializationSurrogate$GetObjectData(obj, info, context);
            }
            //--TRIMMABLE-BOUNDARY-END(12886933531)
            
            //--TRIMMABLE-BOUNDARY-START(17181900827)
            /*object */ SetObjectData(/*object*/ obj, /*SerializationInfo*/ info, /*StreamingContext*/ context, /*ISurrogateSelector?*/ selector)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17181900827);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this._innerSurrogate.SRS$ISerializationSurrogate$SetObjectData(obj, info, context, selector);
            }
            //--TRIMMABLE-BOUNDARY-END(17181900827)
            
            //--TRIMMABLE-BOUNDARY-START(4295950363)
            //Generated interface implemetation for System.Runtime.Serialization.ISerializationSurrogate.GetObjectData(object, System.Runtime.Serialization.SerializationInfo, System.Runtime.Serialization.StreamingContext)
            SRS$ISerializationSurrogate$GetObjectData()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295950363);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.GetObjectData(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4295950363)
            
            //--TRIMMABLE-BOUNDARY-START(8590917659)
            //Generated interface implemetation for System.Runtime.Serialization.ISerializationSurrogate.SetObjectData(object, System.Runtime.Serialization.SerializationInfo, System.Runtime.Serialization.StreamingContext, System.Runtime.Serialization.ISurrogateSelector?)
            SRS$ISerializationSurrogate$SetObjectData()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590917659);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.SetObjectData(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(8590917659)
            
            static $h = 2031643;
            static $f = 0b10010000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(12886933531),
    {
      "r": 65537,
      "p": [
        {
          "n": "obj",
          "p": 131073
        },
        {
          "n": "info",
          "p": 158859265
        },
        {
          "n": "context",
          "p": 158990337
        }
      ],
      "n": "GetObjectData",
      "d": 2031643,
      "h": 12886933531,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(12886933531),
//--TRIMMABLE-BOUNDARY-START(17181900827),
    {
      "r": 131073,
      "p": [
        {
          "n": "obj",
          "p": 131073
        },
        {
          "n": "info",
          "p": 158859265
        },
        {
          "n": "context",
          "p": 158990337
        },
        {
          "n": "selector",
          "p": 1048603
        }
      ],
      "n": "SetObjectData",
      "d": 2031643,
      "h": 17181900827,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(17181900827)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(4296998939),
    {
      "t": 983067,
      "n": "_innerSurrogate",
      "d": 2031643,
      "h": 4296998939,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(4296998939)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(8591966235),
    {
      "p": [
        {
          "n": "innerSurrogate",
          "p": 983067
        }
      ],
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 2031643,
      "h": 8591966235,
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(8591966235)
  ],
  "h": 2031643
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$srsf.SRS.ISerializationSurrogate ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `System.Runtime.Serialization.SurrogateForCyclicalReference`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `System${separator}Runtime${separator}Serialization${separator}SurrogateForCyclicalReference`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2031643)
        
        

        //--TRIMMABLE-BOUNDARY-START(1835035)
        $asm.$cls(`$srsf.SRS.SerializationFieldInfo`, ($self) => class SerializationFieldInfo extends $.$$.SR.FieldInfo
        {
            //--TRIMMABLE-BOUNDARY-START(124555886619)
            /*FieldInfo*/ m_field = null;
            //--TRIMMABLE-BOUNDARY-END(124555886619)
            
            //--TRIMMABLE-BOUNDARY-START(128850853915)
            /*string*/ m_serializationName = null;
            //--TRIMMABLE-BOUNDARY-END(128850853915)
            
            //--TRIMMABLE-BOUNDARY-START(4296802331)
            $ctor$4(/*FieldInfo*/ field, /*string*/ namePrefix)
            {
                super.$ctor$3();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4296802331);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$$.SD.Debug.Assert$4($.$$.SR.FieldInfo.op_Inequality$1(field, null), "field != null");
                    $.$$.SD.Debug.Assert$4(namePrefix !== null, "namePrefix != null");
                    this.m_field = field;
                    this.m_serializationName = $.$strNN(namePrefix) + "+" + $.$strNN(this.m_field.Name);
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296802331)
            
            //--TRIMMABLE-BOUNDARY-START(21476671515)
            /*FieldInfo */ get FieldInfo()
            {
                return this.m_field;
            }
            //--TRIMMABLE-BOUNDARY-END(21476671515)
            
            //--TRIMMABLE-BOUNDARY-START(141735755803)
            /*string */ get Name()
            {
                return this.m_serializationName;
            }
            //--TRIMMABLE-BOUNDARY-END(141735755803)
            
            //--TRIMMABLE-BOUNDARY-START(137440788507)
            /*Module */ get Module()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(85901180955);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.m_field.Module;
            }
            //--TRIMMABLE-BOUNDARY-END(137440788507)
            
            //--TRIMMABLE-BOUNDARY-START(133145821211)
            /*int */ get MetadataToken()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(77311246363);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.m_field.MetadataToken;
            }
            //--TRIMMABLE-BOUNDARY-END(133145821211)
            
            //--TRIMMABLE-BOUNDARY-START(12886736923)
            /*Type? */ get DeclaringType()
            {
                return this.m_field.DeclaringType;
            }
            //--TRIMMABLE-BOUNDARY-END(12886736923)
            
            //--TRIMMABLE-BOUNDARY-START(146030723099)
            /*Type? */ get ReflectedType()
            {
                return this.m_field.ReflectedType;
            }
            //--TRIMMABLE-BOUNDARY-END(146030723099)
            
            //--TRIMMABLE-BOUNDARY-START(107376017435)
            /*object[] */ GetCustomAttributes(/*bool*/ inherit)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(107376017435);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return this.m_field.GetCustomAttributes(inherit);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(107376017435)
            
            //--TRIMMABLE-BOUNDARY-START(111670984731)
            /*object[] */ GetCustomAttributes$1(/*Type*/ attributeType, /*bool*/ inherit)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(111670984731);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return this.m_field.GetCustomAttributes$1(attributeType, inherit);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(111670984731)
            
            //--TRIMMABLE-BOUNDARY-START(120260919323)
            /*bool */ IsDefined(/*Type*/ attributeType, /*bool*/ inherit)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(120260919323);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return this.m_field.IsDefined(attributeType, inherit);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(120260919323)
            
            //--TRIMMABLE-BOUNDARY-START(25771638811)
            /*Type */ get FieldType()
            {
                return this.m_field.FieldType;
            }
            //--TRIMMABLE-BOUNDARY-END(25771638811)
            
            //--TRIMMABLE-BOUNDARY-START(115965952027)
            /*object? */ GetValue(/*object?*/ obj)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(115965952027);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return this.m_field.GetValue(obj);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(115965952027)
            
            //--TRIMMABLE-BOUNDARY-START(150325690395)
            /*void */ SetValue(/*object?*/ obj, /*object?*/ value, /*BindingFlags*/ invokeAttr, /*Binder?*/ binder, /*CultureInfo?*/ culture)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(150325690395);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return this.m_field.SetValue(obj, value, invokeAttr, binder, culture);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(150325690395)
            
            //--TRIMMABLE-BOUNDARY-START(17181704219)
            /*RuntimeFieldHandle */ get FieldHandle()
            {
                return this.m_field.FieldHandle;
            }
            //--TRIMMABLE-BOUNDARY-END(17181704219)
            
            //--TRIMMABLE-BOUNDARY-START(8591769627)
            /*FieldAttributes */ get Attributes()
            {
                return this.m_field.Attributes;
            }
            //--TRIMMABLE-BOUNDARY-END(8591769627)
            
            static $h = 1835035;
            static $f = 0b10010000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.SR.FieldInfo; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(21476671515),
    {
      "p": 114622465,
      "g": {
        "r": 0,
        "d": 0,
        "h": 60131377179,
        "f": 50331656
      },
      "n": "FieldInfo",
      "d": 1835035,
      "h": 21476671515,
      "f": 2097160
    },
//--TRIMMABLE-BOUNDARY-END(21476671515),
//--TRIMMABLE-BOUNDARY-START(141735755803),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 94491115547,
        "f": 50364417
      },
      "n": "Name",
      "d": 1835035,
      "h": 141735755803,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(141735755803),
//--TRIMMABLE-BOUNDARY-START(137440788507),
    {
      "p": 118161409,
      "g": {
        "r": 0,
        "d": 0,
        "h": 85901180955,
        "f": 50364417
      },
      "n": "Module",
      "d": 1835035,
      "h": 137440788507,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(137440788507),
//--TRIMMABLE-BOUNDARY-START(133145821211),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 77311246363,
        "f": 50364417
      },
      "n": "MetadataToken",
      "d": 1835035,
      "h": 133145821211,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(133145821211),
//--TRIMMABLE-BOUNDARY-START(12886736923),
    {
      "p": 188547073,
      "g": {
        "r": 0,
        "d": 0,
        "h": 42951507995,
        "f": 50364417
      },
      "n": "DeclaringType",
      "d": 1835035,
      "h": 12886736923,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(12886736923),
//--TRIMMABLE-BOUNDARY-START(146030723099),
    {
      "p": 188547073,
      "g": {
        "r": 0,
        "d": 0,
        "h": 103081050139,
        "f": 50364417
      },
      "n": "ReflectedType",
      "d": 1835035,
      "h": 146030723099,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(146030723099),
//--TRIMMABLE-BOUNDARY-START(25771638811),
    {
      "p": 188547073,
      "g": {
        "r": 0,
        "d": 0,
        "h": 68721311771,
        "f": 50364417
      },
      "n": "FieldType",
      "d": 1835035,
      "h": 25771638811,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(25771638811),
//--TRIMMABLE-BOUNDARY-START(17181704219),
    {
      "p": 160432129,
      "g": {
        "r": 0,
        "d": 0,
        "h": 51541442587,
        "f": 50364417
      },
      "n": "FieldHandle",
      "d": 1835035,
      "h": 17181704219,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(17181704219),
//--TRIMMABLE-BOUNDARY-START(8591769627),
    {
      "p": 114556929,
      "g": {
        "r": 0,
        "d": 0,
        "h": 34361573403,
        "f": 50364417
      },
      "n": "Attributes",
      "d": 1835035,
      "h": 8591769627,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(8591769627)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(107376017435),
    {
      "r": $.$typeArray($.$$.S.Object).$h,
      "p": [
        {
          "n": "inherit",
          "p": 262145
        }
      ],
      "n": "GetCustomAttributes",
      "d": 1835035,
      "h": 107376017435,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(107376017435),
//--TRIMMABLE-BOUNDARY-START(111670984731),
    {
      "r": $.$typeArray($.$$.S.Object).$h,
      "p": [
        {
          "n": "attributeType",
          "p": 188547073
        },
        {
          "n": "inherit",
          "p": 262145
        }
      ],
      "n": "GetCustomAttributes",
      "o": "@$1",
      "d": 1835035,
      "h": 111670984731,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(111670984731),
//--TRIMMABLE-BOUNDARY-START(120260919323),
    {
      "r": 262145,
      "p": [
        {
          "n": "attributeType",
          "p": 188547073
        },
        {
          "n": "inherit",
          "p": 262145
        }
      ],
      "n": "IsDefined",
      "d": 1835035,
      "h": 120260919323,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(120260919323),
//--TRIMMABLE-BOUNDARY-START(115965952027),
    {
      "r": 131073,
      "p": [
        {
          "n": "obj",
          "p": 131073
        }
      ],
      "n": "GetValue",
      "d": 1835035,
      "h": 115965952027,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(115965952027),
//--TRIMMABLE-BOUNDARY-START(150325690395),
    {
      "r": 65537,
      "p": [
        {
          "n": "obj",
          "p": 131073
        },
        {
          "n": "value",
          "p": 131073
        },
        {
          "n": "invokeAttr",
          "p": 109051905
        },
        {
          "n": "binder",
          "p": 108986369
        },
        {
          "n": "culture",
          "p": 84738049
        }
      ],
      "n": "SetValue",
      "d": 1835035,
      "h": 150325690395,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(150325690395)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(124555886619),
    {
      "t": 114622465,
      "n": "m_field",
      "d": 1835035,
      "h": 124555886619,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(124555886619),
//--TRIMMABLE-BOUNDARY-START(128850853915),
    {
      "t": 1310721,
      "n": "m_serializationName",
      "d": 1835035,
      "h": 128850853915,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(128850853915)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296802331),
    {
      "p": [
        {
          "n": "field",
          "p": 114622465
        },
        {
          "n": "namePrefix",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$4",
      "d": 1835035,
      "h": 4296802331,
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(4296802331)
  ],
  "h": 1835035
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.SR.ICustomAttributeProvider ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `System.Runtime.Serialization.SerializationFieldInfo`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `System${separator}Runtime${separator}Serialization${separator}SerializationFieldInfo`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1835035)
        
        

        //--TRIMMABLE-BOUNDARY-START(196635)
        $asm.$cls(`$srsf.SRS.DeserializationEventHandler`, ($self) => class DeserializationEventHandler extends $.$$.S.MulticastDelegate
        {
            $ctor(/*object*/ target, fn, anmodel)
            {
                this.$target = target;
                this.$nativeFunction = fn;
                if (anmodel) this.$nfmodel = anmodel;
                if (typeof(target) === 'object') this._target = target;
                return this;
            }
            /*void*/ Invoke(/*$.$$.S.Nullable$$*/ sender)
            {
                return this.$nativeFunction.call(this.$target, sender);
            }
            static $h = 196635;
            static $f = 0b10000000;
            static $k = 5;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.MulticastDelegate; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(17180065819),
    {
      "r": 65537,
      "p": [
        {
          "n": "sender",
          "p": 131073
        }
      ],
      "n": "Invoke",
      "d": 196635,
      "h": 17180065819,
      "f": 16777345
    },
//--TRIMMABLE-BOUNDARY-END(17180065819),
//--TRIMMABLE-BOUNDARY-START(8590131227),
    {
      "r": 90570753,
      "p": [
        {
          "n": "sender",
          "p": 131073
        },
        {
          "n": "callback",
          "p": 46006273
        },
        {
          "n": "object",
          "p": 131073
        }
      ],
      "n": "BeginInvoke",
      "d": 196635,
      "h": 8590131227,
      "f": 16777345
    },
//--TRIMMABLE-BOUNDARY-END(8590131227),
//--TRIMMABLE-BOUNDARY-START(12885098523),
    {
      "r": 65537,
      "p": [
        {
          "n": "result",
          "p": 90570753
        }
      ],
      "n": "EndInvoke",
      "d": 196635,
      "h": 12885098523,
      "f": 16777345
    },
//--TRIMMABLE-BOUNDARY-END(12885098523)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295163931),
    {
      "p": [
        {
          "n": "object",
          "p": 131073
        },
        {
          "n": "method",
          "p": 786433
        }
      ],
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 196635,
      "h": 4295163931,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295163931)
  ],
  "h": 196635
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.S.ICloneable, $.$$.SRS.ISerializable ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `System.Runtime.Serialization.DeserializationEventHandler`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `System${separator}Runtime${separator}Serialization${separator}DeserializationEventHandler`; }
        });
        //--TRIMMABLE-BOUNDARY-END(196635)
        
        

        //--TRIMMABLE-BOUNDARY-START(1638427)
        $asm.$cls(`$srsf.SRS.SerializationEventHandler`, ($self) => class SerializationEventHandler extends $.$$.S.MulticastDelegate
        {
            $ctor(/*object*/ target, fn, anmodel)
            {
                this.$target = target;
                this.$nativeFunction = fn;
                if (anmodel) this.$nfmodel = anmodel;
                if (typeof(target) === 'object') this._target = target;
                return this;
            }
            /*void*/ Invoke(/**/ context)
            {
                return this.$nativeFunction.call(this.$target, context);
            }
            static $h = 1638427;
            static $f = 0b10000001;
            static $k = 5;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.MulticastDelegate; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(17181507611),
    {
      "r": 65537,
      "p": [
        {
          "n": "context",
          "p": 158990337
        }
      ],
      "n": "Invoke",
      "d": 1638427,
      "h": 17181507611,
      "f": 16777345
    },
//--TRIMMABLE-BOUNDARY-END(17181507611),
//--TRIMMABLE-BOUNDARY-START(8591573019),
    {
      "r": 90570753,
      "p": [
        {
          "n": "context",
          "p": 158990337
        },
        {
          "n": "callback",
          "p": 46006273
        },
        {
          "n": "object",
          "p": 131073
        }
      ],
      "n": "BeginInvoke",
      "d": 1638427,
      "h": 8591573019,
      "f": 16777345
    },
//--TRIMMABLE-BOUNDARY-END(8591573019),
//--TRIMMABLE-BOUNDARY-START(12886540315),
    {
      "r": 65537,
      "p": [
        {
          "n": "result",
          "p": 90570753
        }
      ],
      "n": "EndInvoke",
      "d": 1638427,
      "h": 12886540315,
      "f": 16777345
    },
//--TRIMMABLE-BOUNDARY-END(12886540315)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296605723),
    {
      "p": [
        {
          "n": "object",
          "p": 131073
        },
        {
          "n": "method",
          "p": 786433
        }
      ],
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 1638427,
      "h": 4296605723,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296605723)
  ],
  "h": 1638427
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.S.ICloneable, $.$$.SRS.ISerializable ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `System.Runtime.Serialization.SerializationEventHandler`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `System${separator}Runtime${separator}Serialization${separator}SerializationEventHandler`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1638427)
        
        

        //--TRIMMABLE-BOUNDARY-START(655387)
        $asm.$str(`$srsf.SRSF.FormatterTypeStyle`, ($self) => class FormatterTypeStyle extends $.$$.S.Enum$$$($self, $.$$.S.UInt32)
        {
            static TypesWhenNeeded = 0;
            static TypesAlways = 1;
            static XsdString = 2;
            static $map;
            static get Map()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(655387);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.$map ??= 
                {
                    "TypesWhenNeeded": 0n,
                    "TypesAlways": 1n,
                    "XsdString": 2n
                };
            }
            //--TRIMMABLE-BOUNDARY-START(4295622683)
            //default constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295622683);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295622683)
            
            //--TRIMMABLE-BOUNDARY-START(4295622683)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$3();
            }
            //--TRIMMABLE-BOUNDARY-END(4295622683)
            
            static $h = 655387;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Enum; }
            static get $eut() { return $.$$.S.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "u": 655361,
  "l": [
//--TRIMMABLE-BOUNDARY-START(12885557275),
    {
      "t": 655387,
      "n": "TypesWhenNeeded",
      "d": 655387,
      "h": 12885557275,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(12885557275),
//--TRIMMABLE-BOUNDARY-START(8590589979),
    {
      "t": 655387,
      "n": "TypesAlways",
      "d": 655387,
      "h": 8590589979,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(8590589979),
//--TRIMMABLE-BOUNDARY-START(17180524571),
    {
      "t": 655387,
      "n": "XsdString",
      "d": 655387,
      "h": 17180524571,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(17180524571)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295622683),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 655387,
      "h": 4295622683,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295622683)
  ],
  "h": 655387,
  "a": [
    {
      "t": 104464385,
      "c": 30169235457,
      "a": [
        {
          "v": "Formatter-based serialization is obsolete and should not be used.",
          "t": 1310721
        }
      ],
      "n": [
        {
          "n": "DiagnosticId",
          "v": "SYSLIB0050",
          "t": 1310721
        },
        {
          "n": "UrlFormat",
          "v": "https://aka.ms/dotnet-warnings/{0}",
          "t": 1310721
        }
      ]
    }
  ]
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.S.IComparable, $.$$.S.ISpanFormattable, $.$$.S.IFormattable, $.$$.S.IConvertible ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `System.Runtime.Serialization.Formatters.FormatterTypeStyle`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `System${separator}Runtime${separator}Serialization${separator}Formatters${separator}FormatterTypeStyle`; }
        });
        //--TRIMMABLE-BOUNDARY-END(655387)
        
        

        //--TRIMMABLE-BOUNDARY-START(589851)
        $asm.$str(`$srsf.SRSF.FormatterAssemblyStyle`, ($self) => class FormatterAssemblyStyle extends $.$$.S.Enum$$$($self, $.$$.S.UInt32)
        {
            static Simple = 0;
            static Full = 1;
            static $map;
            static get Map()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(589851);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.$map ??= 
                {
                    "Simple": 0n,
                    "Full": 1n
                };
            }
            //--TRIMMABLE-BOUNDARY-START(4295557147)
            //default constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295557147);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295557147)
            
            //--TRIMMABLE-BOUNDARY-START(4295557147)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$3();
            }
            //--TRIMMABLE-BOUNDARY-END(4295557147)
            
            static $h = 589851;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Enum; }
            static get $eut() { return $.$$.S.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "u": 655361,
  "l": [
//--TRIMMABLE-BOUNDARY-START(12885491739),
    {
      "t": 589851,
      "n": "Simple",
      "d": 589851,
      "h": 12885491739,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(12885491739),
//--TRIMMABLE-BOUNDARY-START(8590524443),
    {
      "t": 589851,
      "n": "Full",
      "d": 589851,
      "h": 8590524443,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(8590524443)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295557147),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 589851,
      "h": 4295557147,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295557147)
  ],
  "h": 589851,
  "a": [
    {
      "t": 104464385,
      "c": 30169235457,
      "a": [
        {
          "v": "Formatter-based serialization is obsolete and should not be used.",
          "t": 1310721
        }
      ],
      "n": [
        {
          "n": "DiagnosticId",
          "v": "SYSLIB0050",
          "t": 1310721
        },
        {
          "n": "UrlFormat",
          "v": "https://aka.ms/dotnet-warnings/{0}",
          "t": 1310721
        }
      ]
    }
  ]
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.S.IComparable, $.$$.S.ISpanFormattable, $.$$.S.IFormattable, $.$$.S.IConvertible ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `System.Runtime.Serialization.Formatters.FormatterAssemblyStyle`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `System${separator}Runtime${separator}Serialization${separator}Formatters${separator}FormatterAssemblyStyle`; }
        });
        //--TRIMMABLE-BOUNDARY-END(589851)
        
        

        //--TRIMMABLE-BOUNDARY-START(786459)
        $asm.$str(`$srsf.SRSF.TypeFilterLevel`, ($self) => class TypeFilterLevel extends $.$$.S.Enum$$$($self, $.$$.S.UInt32)
        {
            static Low = 2;
            static Full = 3;
            static $map;
            static get Map()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(786459);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.$map ??= 
                {
                    "Low": 2n,
                    "Full": 3n
                };
            }
            //--TRIMMABLE-BOUNDARY-START(4295753755)
            //default constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295753755);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295753755)
            
            //--TRIMMABLE-BOUNDARY-START(4295753755)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$3();
            }
            //--TRIMMABLE-BOUNDARY-END(4295753755)
            
            static $h = 786459;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Enum; }
            static get $eut() { return $.$$.S.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "u": 655361,
  "l": [
//--TRIMMABLE-BOUNDARY-START(12885688347),
    {
      "t": 786459,
      "n": "Low",
      "d": 786459,
      "h": 12885688347,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(12885688347),
//--TRIMMABLE-BOUNDARY-START(8590721051),
    {
      "t": 786459,
      "n": "Full",
      "d": 786459,
      "h": 8590721051,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(8590721051)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295753755),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 786459,
      "h": 4295753755,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295753755)
  ],
  "h": 786459,
  "a": [
    {
      "t": 104464385,
      "c": 30169235457,
      "a": [
        {
          "v": "Formatter-based serialization is obsolete and should not be used.",
          "t": 1310721
        }
      ],
      "n": [
        {
          "n": "DiagnosticId",
          "v": "SYSLIB0050",
          "t": 1310721
        },
        {
          "n": "UrlFormat",
          "v": "https://aka.ms/dotnet-warnings/{0}",
          "t": 1310721
        }
      ]
    }
  ]
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.S.IComparable, $.$$.S.ISpanFormattable, $.$$.S.IFormattable, $.$$.S.IConvertible ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `System.Runtime.Serialization.Formatters.TypeFilterLevel`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `System${separator}Runtime${separator}Serialization${separator}Formatters${separator}TypeFilterLevel`; }
        });
        //--TRIMMABLE-BOUNDARY-END(786459)
        
        

        //--TRIMMABLE-BOUNDARY-START(2097179)
        $asm.$cls(`$srsf.SRS.SurrogateHashtable`, ($self) => class SurrogateHashtable extends $.$$.SC$1.Hashtable
        {
            //--TRIMMABLE-BOUNDARY-START(4297064475)
            $ctor$18(/*int*/ size)
            {
                super.$ctor$16(size);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4297064475);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4297064475)
            
            //--TRIMMABLE-BOUNDARY-START(8592031771)
            /*bool */ KeyEquals(/*object*/ key, /*object*/ item)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8592031771);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*SurrogateKey*/ let givenValue = $.$cast(item, $.$srsf.SRS.SurrogateKey);
                /*SurrogateKey*/ let presentValue = $.$cast(key, $.$srsf.SRS.SurrogateKey);
                return presentValue._type === givenValue._type && (presentValue._context.State & givenValue._context.State) === givenValue._context.State && presentValue._context.Context === givenValue._context.Context;
            }
            //--TRIMMABLE-BOUNDARY-END(8592031771)
            
            static $h = 2097179;
            static $f = 0b10010000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.SC$1.Hashtable; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8592031771),
    {
      "r": 262145,
      "p": [
        {
          "n": "key",
          "p": 131073
        },
        {
          "n": "item",
          "p": 131073
        }
      ],
      "n": "KeyEquals",
      "d": 2097179,
      "h": 8592031771,
      "f": 16809988
    },
//--TRIMMABLE-BOUNDARY-END(8592031771)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4297064475),
    {
      "p": [
        {
          "n": "size",
          "p": 655361
        }
      ],
      "n": ".ctor",
      "o": "$ctor$18",
      "d": 2097179,
      "h": 4297064475,
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(4297064475)
  ],
  "h": 2097179
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.SC$1.IDictionary, $.$$.SC$1.ICollection, $.$$.SC$1.IEnumerable, $.$$.SRS.ISerializable, $.$$.SRS.IDeserializationCallback, $.$$.S.ICloneable ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `System.Runtime.Serialization.SurrogateHashtable`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `System${separator}Runtime${separator}Serialization${separator}SurrogateHashtable`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2097179)
	});
})(window, window.NetJs.$boot(), ...await window.NetJs.$require("NetJs.System.Private.CoreLib", "NetJs.System.Collections", "NetJs.System.Diagnostics.Tracing", "NetJs.System.Threading", "NetJs.System.Collections.Concurrent", "NetJs.System.Memory", "NetJs.System.Private.Uri", "NetJs.System.Runtime", "NetJs.System.Collections.NonGeneric"));
})();
//--TRIMMABLE-BOUNDARY-END(27)
