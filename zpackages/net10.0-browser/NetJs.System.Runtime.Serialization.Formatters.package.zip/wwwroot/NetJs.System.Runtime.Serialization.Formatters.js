
(function ($global, $, $$, $sc, $sdt, $st, $scc, $sm, $spu, $sr, $scn) {
    "use strict";
    let _;
    
    
    
	$.$asm(
    "NetJs.System.Runtime.Serialization.Formatters", 
    {"h":51458,"f":"System.Runtime.Serialization.Formatters","v":"1.0.35.0","a":[{"t":96206849,"c":4391174145,"a":[{"v":66519041,"t":142475265}]},{"t":96206849,"c":4391174145,"a":[{"v":118095873,"t":142475265}]},{"t":96206849,"c":4391174145,"a":[{"v":112984065,"t":142475265}]},{"t":96206849,"c":4391174145,"a":[{"v":113049601,"t":142475265}]},{"t":96206849,"c":4391174145,"a":[{"v":113246209,"t":142475265}]},{"t":96206849,"c":4391174145,"a":[{"v":113704961,"t":142475265}]},{"t":96206849,"c":4391174145,"a":[{"v":113836033,"t":142475265}]},{"t":96206849,"c":4391174145,"a":[{"v":113901569,"t":142475265}]},{"t":73596929,"c":4368564225,"a":[{"v":"SIT","t":1310721}]},{"t":73662465,"c":4368629761,"a":[{"v":"Debug","t":1310721}]},{"t":74121217,"c":4369088513,"a":[{"v":"1.0.35.0","t":1310721}]},{"t":74252289,"c":4369219585,"a":[{"v":"1.0.35\u002Beff628fa5ab8bd29ec37e9c13a50148694bea088","t":1310721}]},{"t":75104257,"c":4370071553,"a":[{"v":"NetJs.System.Runtime.Serialization.Formatters","t":1310721}]},{"t":75235329,"c":4370202625,"a":[{"v":"NetJs.System.Runtime.Serialization.Formatters","t":1310721}]},{"t":75366401,"c":4370333697,"a":[{"v":"1.0.35.0","t":1310721}]},{"t":115081217,"c":4410048513,"a":[{"v":"browser1.0","t":1310721}]},{"t":114819073,"c":4409786369,"a":[{"v":"browser1.0","t":1310721}]},{"t":115015681,"c":12999917569,"a":[{"v":".NETCoreApp,Version=v10.0","t":1310721}],"n":[{"n":"FrameworkDisplayName","v":".NET 10.0","t":1310721}]}],"m":[]},
    function($asm)
	{
        
        
        $asm.$cls("$srsf.System.Runtime.Serialization.ISurrogateSelector", ($self) => class ISurrogateSelector
        {
            static $h = 1100034;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {"m":[{"r":65537,"p":[{"n":"selector","p":1100034}],"n":"ChainSelector","o":"System$Runtime$Serialization$ISurrogateSelector$ChainSelector","d":1100034,"h":4296067330,"f":16777473},{"r":1034498,"p":[{"n":"type","p":142475265},{"n":"context","p":113967105},{"n":"selector","p":1100034,"f":2}],"n":"GetSurrogate","o":"System$Runtime$Serialization$ISurrogateSelector$GetSurrogate","d":1100034,"h":8591034626,"f":16777473},{"r":1100034,"n":"GetNextSelector","o":"System$Runtime$Serialization$ISurrogateSelector$GetNextSelector","d":1100034,"h":12886001922,"f":16777473}],"h":1100034,"a":[{"t":70909953,"c":8660844545,"a":[{"v":"Formatter-based serialization is obsolete and should not be used.","t":1310721}],"n":[{"n":"DiagnosticId","v":"SYSLIB0050","t":1310721},{"n":"UrlFormat","v":"https://aka.ms/dotnet-warnings/{0}","t":1310721}]}]}; }
            static get $fullName() { return `System.Runtime.Serialization.ISurrogateSelector`; }
        });
        
        $asm.$cls("$srsf.System.Runtime.Serialization.ISerializationSurrogate", ($self) => class ISerializationSurrogate
        {
            static $h = 1034498;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {"m":[{"r":65537,"p":[{"n":"obj","p":131073},{"n":"info","p":113836033},{"n":"context","p":113967105}],"n":"GetObjectData","o":"System$Runtime$Serialization$ISerializationSurrogate$GetObjectData","d":1034498,"h":4296001794,"f":16777473},{"r":131073,"p":[{"n":"obj","p":131073},{"n":"info","p":113836033},{"n":"context","p":113967105},{"n":"selector","p":1100034}],"n":"SetObjectData","o":"System$Runtime$Serialization$ISerializationSurrogate$SetObjectData","d":1034498,"h":8590969090,"f":16777473}],"h":1034498,"a":[{"t":70909953,"c":8660844545,"a":[{"v":"Formatter-based serialization is obsolete and should not be used.","t":1310721}],"n":[{"n":"DiagnosticId","v":"SYSLIB0050","t":1310721},{"n":"UrlFormat","v":"https://aka.ms/dotnet-warnings/{0}","t":1310721}]}]}; }
            static get $fullName() { return `System.Runtime.Serialization.ISerializationSurrogate`; }
        });
        
        $asm.$cls("$srsf.System.Runtime.Serialization.IFormatter", ($self) => class IFormatter
        {
            /*string*/ static System$Runtime$Serialization$IFormatter$RequiresDynamicCodeMessage = null;
            /*string*/ static System$Runtime$Serialization$IFormatter$RequiresUnreferencedCodeMessage = null;
            //Static Initializer
            static $sinit()
            {
                {
                    this.System$Runtime$Serialization$IFormatter$RequiresDynamicCodeMessage = "BinaryFormatter serialization uses dynamic code generation, the type of objects being processed cannot be statically discovered.";
                }
                {
                    this.System$Runtime$Serialization$IFormatter$RequiresUnreferencedCodeMessage = "BinaryFormatter serialization is not trim compatible because the type of objects being processed cannot be statically discovered.";
                }
            }
            static $h = 968962;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {"p":[{"p":1100034,"g":{"r":0,"d":0,"h":25770772738,"f":50331905},"s":{"r":0,"d":0,"h":30065740034,"f":83886337},"n":"SurrogateSelector","o":"System$Runtime$Serialization$IFormatter$SurrogateSelector","d":968962,"h":21475805442,"f":2097409},{"p":1624322,"g":{"r":0,"d":0,"h":38655674626,"f":50331905},"s":{"r":0,"d":0,"h":42950641922,"f":83886337},"n":"Binder","o":"System$Runtime$Serialization$IFormatter$Binder","d":968962,"h":34360707330,"f":2097409},{"p":113967105,"g":{"r":0,"d":0,"h":51540576514,"f":50331905},"s":{"r":0,"d":0,"h":55835543810,"f":83886337},"n":"Context","o":"System$Runtime$Serialization$IFormatter$Context","d":968962,"h":47245609218,"f":2097409}],"m":[{"r":131073,"p":[{"n":"serializationStream","p":62193665}],"n":"Deserialize","o":"System$Runtime$Serialization$IFormatter$Deserialize","d":968962,"h":12885870850,"f":16777473},{"r":65537,"p":[{"n":"serializationStream","p":62193665},{"n":"graph","p":131073}],"n":"Serialize","o":"System$Runtime$Serialization$IFormatter$Serialize","d":968962,"h":17180838146,"f":16777473}],"l":[{"t":1310721,"n":"RequiresDynamicCodeMessage","o":"System$Runtime$Serialization$IFormatter$RequiresDynamicCodeMessage","d":968962,"h":4295936258,"f":4194344},{"t":1310721,"n":"RequiresUnreferencedCodeMessage","o":"System$Runtime$Serialization$IFormatter$RequiresUnreferencedCodeMessage","d":968962,"h":8590903554,"f":4194344}],"h":968962,"a":[{"t":70909953,"c":8660844545,"a":[{"v":"BinaryFormatter serialization is obsolete and should not be used. See https://aka.ms/binaryformatter for more information.","t":1310721}],"n":[{"n":"DiagnosticId","v":"SYSLIB0011","t":1310721},{"n":"UrlFormat","v":"https://aka.ms/dotnet-warnings/{0}","t":1310721}]}]}; }
            static get $fullName() { return `System.Runtime.Serialization.IFormatter`; }
        });
        
        $asm.$cls("$srsf.System.Runtime.Serialization.Formatters.IFieldInfo", ($self) => class IFieldInfo
        {
            static $h = 772354;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {"p":[{"p":$.$typeArray($.$$.System.String).$h,"g":{"r":0,"d":0,"h":8590706946,"f":50331905},"s":{"r":0,"d":0,"h":12885674242,"f":83886337},"n":"FieldNames","o":"System$Runtime$Serialization$Formatters$IFieldInfo$FieldNames","d":772354,"h":4295739650,"f":2097409},{"p":$.$typeArray($.$$.System.Type).$h,"g":{"r":0,"d":0,"h":21475608834,"f":50331905},"s":{"r":0,"d":0,"h":25770576130,"f":83886337},"n":"FieldTypes","o":"System$Runtime$Serialization$Formatters$IFieldInfo$FieldTypes","d":772354,"h":17180641538,"f":2097409}],"h":772354,"a":[{"t":70909953,"c":8660844545,"a":[{"v":"Formatter-based serialization is obsolete and should not be used.","t":1310721}],"n":[{"n":"DiagnosticId","v":"SYSLIB0050","t":1310721},{"n":"UrlFormat","v":"https://aka.ms/dotnet-warnings/{0}","t":1310721}]}]}; }
            static get $fullName() { return `System.Runtime.Serialization.Formatters.IFieldInfo`; }
        });
        
        $asm.$cls("$srsf.System.Runtime.Serialization.SerializationBinder", ($self) => class SerializationBinder extends $.$$.System.Object
        {
            /*void */ BindToName(/*Type*/ serializedType, /*out string?*/ assemblyName, /*out string?*/ typeName)
            {
                assemblyName.$v = null;
                typeName.$v = null;
            }
            //default reference type constructor overload
            $ctor$1()
            {
                super.$ctor();
                return this;
            }
            static $h = 1624322;
            static $f = 0b110001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"m":[{"r":65537,"p":[{"n":"serializedType","p":142475265},{"n":"assemblyName","p":1310721,"f":2},{"n":"typeName","p":1310721,"f":2}],"n":"BindToName","d":1624322,"h":4296591618,"f":16777345},{"r":142475265,"p":[{"n":"assemblyName","p":1310721},{"n":"typeName","p":1310721}],"n":"BindToType","d":1624322,"h":8591558914,"f":16777473}],"c":[{"n":".ctor","o":"$ctor$1","d":1624322,"h":12886526210,"f":16777220}],"h":1624322}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `System.Runtime.Serialization.SerializationBinder`; }
        });
        
        $asm.$cls("$srsf.System.Runtime.Serialization.Formatter", ($self) => class Formatter extends $.$$.System.Object
        {
            /*ObjectIDGenerator*/ m_idGenerator = null;
            /*Queue*/ m_objectQueue = null;
            $ctor$1()
            {
                super.$ctor();
                {
                    this.m_objectQueue = new $.$scn.System.Collections.Queue().$ctor$1();
                    this.m_idGenerator = new $.$srsf.System.Runtime.Serialization.ObjectIDGenerator().$ctor$1();
                }
                return this;
            }
            /*object? */ GetNext(/*out long*/ objID)
            {
                if (this.m_objectQueue.Count === 0)
                {
                    objID.$v = 0n;
                    return null;
                }
                /*object*/ let obj = this.m_objectQueue.Dequeue();
                /*bool*/ let isNew;
                objID.$v = this.m_idGenerator.HasId(obj, $.$ref(() => isNew, ($v) => isNew = $v, $.$$.System.Boolean));
                if (isNew)
                {
                    throw new $.$$.System.Runtime.Serialization.SerializationException().$ctor$12($.$srsf.System.SR.Serialization_NoID);
                }
                return obj;
            }
            /*long */ Schedule(/*object?*/ obj)
            {
                if (obj === null)
                {
                    return 0n;
                }
                /*bool*/ let isNew;
                /*long*/ let id = this.m_idGenerator.GetId(obj, $.$ref(() => isNew, ($v) => isNew = $v, $.$$.System.Boolean));
                if (isNew)
                {
                    this.m_objectQueue.Enqueue(obj);
                }
                return id;
            }
            /*void */ WriteMember(/*string*/ memberName, /*object?*/ data)
            {
                if (data === null)
                {
                    this.WriteObjectRef(data, memberName, $.$$.System.Object.$type);
                    return;
                }
                /*Type*/ let varType = $.$$.System.Object.GetType.call(data);
                if ($.$$.System.Type.op_Equality$1(varType, $.$$.System.Boolean.$type))
                {
                    this.WriteBoolean($.$$.System.Convert.ToBoolean$9(data, $.$$.System.Globalization.CultureInfo.InvariantCulture), memberName);
                }
                else if ($.$$.System.Type.op_Equality$1(varType, $.$$.System.Char.$type))
                {
                    this.WriteChar($.$$.System.Convert.ToChar$9(data, $.$$.System.Globalization.CultureInfo.InvariantCulture), memberName);
                }
                else if ($.$$.System.Type.op_Equality$1(varType, $.$$.System.SByte.$type))
                {
                    this.WriteSByte($.$$.System.Convert.ToSByte$9(data, $.$$.System.Globalization.CultureInfo.InvariantCulture), memberName);
                }
                else if ($.$$.System.Type.op_Equality$1(varType, $.$$.System.Byte.$type))
                {
                    this.WriteByte($.$$.System.Convert.ToByte$9(data, $.$$.System.Globalization.CultureInfo.InvariantCulture), memberName);
                }
                else if ($.$$.System.Type.op_Equality$1(varType, $.$$.System.Int16.$type))
                {
                    this.WriteInt16($.$$.System.Convert.ToInt16$9(data, $.$$.System.Globalization.CultureInfo.InvariantCulture), memberName);
                }
                else if ($.$$.System.Type.op_Equality$1(varType, $.$$.System.Int32.$type))
                {
                    this.WriteInt32($.$$.System.Convert.ToInt32$9(data, $.$$.System.Globalization.CultureInfo.InvariantCulture), memberName);
                }
                else if ($.$$.System.Type.op_Equality$1(varType, $.$$.System.Int64.$type))
                {
                    this.WriteInt64($.$$.System.Convert.ToInt64$9(data, $.$$.System.Globalization.CultureInfo.InvariantCulture), memberName);
                }
                else if ($.$$.System.Type.op_Equality$1(varType, $.$$.System.Single.$type))
                {
                    this.WriteSingle($.$$.System.Convert.ToSingle$9(data, $.$$.System.Globalization.CultureInfo.InvariantCulture), memberName);
                }
                else if ($.$$.System.Type.op_Equality$1(varType, $.$$.System.Double.$type))
                {
                    this.WriteDouble($.$$.System.Convert.ToDouble$9(data, $.$$.System.Globalization.CultureInfo.InvariantCulture), memberName);
                }
                else if ($.$$.System.Type.op_Equality$1(varType, $.$$.System.DateTime.$type))
                {
                    this.WriteDateTime($.$$.System.Convert.ToDateTime$9(data, $.$$.System.Globalization.CultureInfo.InvariantCulture), memberName);
                }
                else if ($.$$.System.Type.op_Equality$1(varType, $.$$.System.Decimal.$type))
                {
                    this.WriteDecimal($.$$.System.Convert.ToDecimal$9(data, $.$$.System.Globalization.CultureInfo.InvariantCulture), memberName);
                }
                else if ($.$$.System.Type.op_Equality$1(varType, $.$$.System.UInt16.$type))
                {
                    this.WriteUInt16($.$$.System.Convert.ToUInt16$9(data, $.$$.System.Globalization.CultureInfo.InvariantCulture), memberName);
                }
                else if ($.$$.System.Type.op_Equality$1(varType, $.$$.System.UInt32.$type))
                {
                    this.WriteUInt32($.$$.System.Convert.ToUInt32$9(data, $.$$.System.Globalization.CultureInfo.InvariantCulture), memberName);
                }
                else if ($.$$.System.Type.op_Equality$1(varType, $.$$.System.UInt64.$type))
                {
                    this.WriteUInt64($.$$.System.Convert.ToUInt64$9(data, $.$$.System.Globalization.CultureInfo.InvariantCulture), memberName);
                }
                else if (varType.IsArray)
                {
                    this.WriteArray(data, memberName, varType);
                }
                else if (varType.IsValueType)
                {
                    this.WriteValueType(data, memberName, varType);
                }
                else 
                {
                    this.WriteObjectRef(data, memberName, varType);
                }
            }
            //Generated interface implemetation for System.Runtime.Serialization.IFormatter.Deserialize(System.IO.Stream)
            System$Runtime$Serialization$IFormatter$Deserialize()
            {
                return this.Deserialize(...arguments);
            }
            //Generated interface implemetation for System.Runtime.Serialization.IFormatter.Serialize(System.IO.Stream, object)
            System$Runtime$Serialization$IFormatter$Serialize()
            {
                return this.Serialize(...arguments);
            }
            //Generated interface implemetation for System.Runtime.Serialization.IFormatter.SurrogateSelector.get
            get System$Runtime$Serialization$IFormatter$SurrogateSelector()
            {
                return this.SurrogateSelector;
            }
            //Generated interface implemetation for System.Runtime.Serialization.IFormatter.SurrogateSelector.set
            set System$Runtime$Serialization$IFormatter$SurrogateSelector(value)
            {
                this.SurrogateSelector = value;
            }
            //Generated interface implemetation for System.Runtime.Serialization.IFormatter.Binder.get
            get System$Runtime$Serialization$IFormatter$Binder()
            {
                return this.Binder;
            }
            //Generated interface implemetation for System.Runtime.Serialization.IFormatter.Binder.set
            set System$Runtime$Serialization$IFormatter$Binder(value)
            {
                this.Binder = value;
            }
            //Generated interface implemetation for System.Runtime.Serialization.IFormatter.Context.get
            get System$Runtime$Serialization$IFormatter$Context()
            {
                return this.Context;
            }
            //Generated interface implemetation for System.Runtime.Serialization.IFormatter.Context.set
            set System$Runtime$Serialization$IFormatter$Context(value)
            {
                this.Context = value;
            }
            static $h = 444674;
            static $f = 0b110001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":1100034,"g":{"r":0,"d":0,"h":120259528962,"f":50331905},"s":{"r":0,"d":0,"h":124554496258,"f":83886337},"n":"SurrogateSelector","d":444674,"h":115964561666,"f":2097409},{"p":1624322,"g":{"r":0,"d":0,"h":133144430850,"f":50331905},"s":{"r":0,"d":0,"h":137439398146,"f":83886337},"n":"Binder","d":444674,"h":128849463554,"f":2097409},{"p":113967105,"g":{"r":0,"d":0,"h":146029332738,"f":50331905},"s":{"r":0,"d":0,"h":150324300034,"f":83886337},"n":"Context","d":444674,"h":141734365442,"f":2097409}],"m":[{"r":131073,"p":[{"n":"serializationStream","p":62193665}],"n":"Deserialize","d":444674,"h":17180313858,"f":16777473},{"r":131073,"p":[{"n":"objID","p":917505,"f":2}],"n":"GetNext","d":444674,"h":21475281154,"f":16777348},{"r":917505,"p":[{"n":"obj","p":131073}],"n":"Schedule","d":444674,"h":25770248450,"f":16777348},{"r":65537,"p":[{"n":"serializationStream","p":62193665},{"n":"graph","p":131073}],"n":"Serialize","d":444674,"h":30065215746,"f":16777473},{"r":65537,"p":[{"n":"obj","p":131073},{"n":"name","p":1310721},{"n":"memberType","p":142475265}],"n":"WriteArray","d":444674,"h":34360183042,"f":16777476},{"r":65537,"p":[{"n":"val","p":262145},{"n":"name","p":1310721}],"n":"WriteBoolean","d":444674,"h":38655150338,"f":16777476},{"r":65537,"p":[{"n":"val","p":393217},{"n":"name","p":1310721}],"n":"WriteByte","d":444674,"h":42950117634,"f":16777476},{"r":65537,"p":[{"n":"val","p":458753},{"n":"name","p":1310721}],"n":"WriteChar","d":444674,"h":47245084930,"f":16777476},{"r":65537,"p":[{"n":"val","p":34275329},{"n":"name","p":1310721}],"n":"WriteDateTime","d":444674,"h":51540052226,"f":16777476},{"r":65537,"p":[{"n":"val","p":35127297},{"n":"name","p":1310721}],"n":"WriteDecimal","d":444674,"h":55835019522,"f":16777476},{"r":65537,"p":[{"n":"val","p":1179649},{"n":"name","p":1310721}],"n":"WriteDouble","d":444674,"h":60129986818,"f":16777476},{"r":65537,"p":[{"n":"val","p":524289},{"n":"name","p":1310721}],"n":"WriteInt16","d":444674,"h":64424954114,"f":16777476},{"r":65537,"p":[{"n":"val","p":655361},{"n":"name","p":1310721}],"n":"WriteInt32","d":444674,"h":68719921410,"f":16777476},{"r":65537,"p":[{"n":"val","p":917505},{"n":"name","p":1310721}],"n":"WriteInt64","d":444674,"h":73014888706,"f":16777476},{"r":65537,"p":[{"n":"obj","p":131073},{"n":"name","p":1310721},{"n":"memberType","p":142475265}],"n":"WriteObjectRef","d":444674,"h":77309856002,"f":16777476},{"r":65537,"p":[{"n":"memberName","p":1310721},{"n":"data","p":131073}],"n":"WriteMember","d":444674,"h":81604823298,"f":16777348},{"r":65537,"p":[{"n":"val","p":327681},{"n":"name","p":1310721}],"n":"WriteSByte","d":444674,"h":85899790594,"f":16777476,"a":[{"t":23527425,"c":8613462017,"a":[{"v":false,"t":262145}]}]},{"r":65537,"p":[{"n":"val","p":1114113},{"n":"name","p":1310721}],"n":"WriteSingle","d":444674,"h":90194757890,"f":16777476},{"r":65537,"p":[{"n":"val","p":140574721},{"n":"name","p":1310721}],"n":"WriteTimeSpan","d":444674,"h":94489725186,"f":16777476},{"r":65537,"p":[{"n":"val","p":589825},{"n":"name","p":1310721}],"n":"WriteUInt16","d":444674,"h":98784692482,"f":16777476,"a":[{"t":23527425,"c":8613462017,"a":[{"v":false,"t":262145}]}]},{"r":65537,"p":[{"n":"val","p":720897},{"n":"name","p":1310721}],"n":"WriteUInt32","d":444674,"h":103079659778,"f":16777476,"a":[{"t":23527425,"c":8613462017,"a":[{"v":false,"t":262145}]}]},{"r":65537,"p":[{"n":"val","p":983041},{"n":"name","p":1310721}],"n":"WriteUInt64","d":444674,"h":107374627074,"f":16777476,"a":[{"t":23527425,"c":8613462017,"a":[{"v":false,"t":262145}]}]},{"r":65537,"p":[{"n":"obj","p":131073},{"n":"name","p":1310721},{"n":"memberType","p":142475265}],"n":"WriteValueType","d":444674,"h":111669594370,"f":16777476}],"l":[{"t":1493250,"n":"m_idGenerator","d":444674,"h":4295411970,"f":4194308},{"t":393251,"n":"m_objectQueue","d":444674,"h":8590379266,"f":4194308}],"c":[{"n":".ctor","o":"$ctor$1","d":444674,"h":12885346562,"f":16777220}],"i":[968962],"h":444674,"a":[{"t":23527425,"c":8613462017,"a":[{"v":false,"t":262145}]},{"t":70909953,"c":8660844545,"a":[{"v":"BinaryFormatter serialization is obsolete and should not be used. See https://aka.ms/binaryformatter for more information.","t":1310721}],"n":[{"n":"DiagnosticId","v":"SYSLIB0011","t":1310721},{"n":"UrlFormat","v":"https://aka.ms/dotnet-warnings/{0}","t":1310721}]}]}; }
            static get $b() { return $.$$.System.Object; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$srsf.System.Runtime.Serialization.IFormatter ]; }
            static get $fullName() { return `System.Runtime.Serialization.Formatter`; }
        });
        
        $asm.$cls("$srsf.System.SR", ($self) => class SR
        {
            /*global::System.Resources.ResourceManager*/ static s_resourceManager = null;
            /*global::System.Globalization.CultureInfo*/ static resourceCulture = null;
            static /*global::System.Resources.ResourceManager */ get ResourceManager()
            {
                if ($.$$.System.Object.ReferenceEquals($.$srsf.System.SR.s_resourceManager, null))
                {
                    /*global::System.Resources.ResourceManager*/ let temp = new $.$$.System.Resources.ResourceManager().$ctor$3("System.Runtime.Serialization.Formatters", $.$srsf.System.SR.$type.Assembly);
                    $.$srsf.System.SR.s_resourceManager = temp;
                }
                return $.$srsf.System.SR.s_resourceManager;
            }
            static /*global::System.Globalization.CultureInfo */ get Culture()
            {
                return $.$srsf.System.SR.resourceCulture;
            }
            static /*global::System.Globalization.CultureInfo */ set Culture(value)
            {
                $.$srsf.System.SR.resourceCulture = value;
            }
            static /*string */ get Arg_HTCapacityOverflow()
            {
                return "Hashtable's capacity overflowed and went negative. Check load factor, capacity and the current size of the table.";
            }
            static /*string */ get Serialization_NonSerType()
            {
                return "Type '{0}' in Assembly '{1}' is not marked as serializable.";
            }
            static /*string */ FormatSerialization_NonSerType(/*object*/ arg1, /*object*/ arg2)
            {
                return $.$$.System.String.Format$8("Type '{0}' in Assembly '{1}' is not marked as serializable.", arg1, arg2);
            }
            static /*string */ get Argument_DataLengthDifferent()
            {
                return "Parameters 'members' and 'data' must have the same length.";
            }
            static /*string */ get ArgumentNull_NullMember()
            {
                return "Member at position {0} was null.";
            }
            static /*string */ FormatArgumentNull_NullMember(/*object*/ arg1)
            {
                return $.$$.System.String.Format$9("Member at position {0} was null.", arg1);
            }
            static /*string */ get Serialization_UnknownMemberInfo()
            {
                return "Only FieldInfo, PropertyInfo, and SerializationMemberInfo are recognized.";
            }
            static /*string */ get Serialization_NoID()
            {
                return "Object has never been assigned an objectID.";
            }
            static /*string */ get Serialization_TooManyElements()
            {
                return "The internal array cannot expand to greater than Int32.MaxValue elements.";
            }
            static /*string */ get Argument_InvalidFieldInfo()
            {
                return "The FieldInfo object is not valid.";
            }
            static /*string */ get Serialization_NeverSeen()
            {
                return "A fixup is registered to the object with ID {0}, but the object does not appear in the graph.";
            }
            static /*string */ FormatSerialization_NeverSeen(/*object*/ arg1)
            {
                return $.$$.System.String.Format$9("A fixup is registered to the object with ID {0}, but the object does not appear in the graph.", arg1);
            }
            static /*string */ get Serialization_IORIncomplete()
            {
                return "The object with ID {0} implements the IObjectReference interface for which all dependencies cannot be resolved. The likely cause is two instances of IObjectReference that have a mutual dependency on each other.";
            }
            static /*string */ FormatSerialization_IORIncomplete(/*object*/ arg1)
            {
                return $.$$.System.String.Format$9("The object with ID {0} implements the IObjectReference interface for which all dependencies cannot be resolved. The likely cause is two instances of IObjectReference that have a mutual dependency on each other.", arg1);
            }
            static /*string */ get Serialization_ObjectNotSupplied()
            {
                return "The object with ID {0} was referenced in a fixup but does not exist.";
            }
            static /*string */ FormatSerialization_ObjectNotSupplied(/*object*/ arg1)
            {
                return $.$$.System.String.Format$9("The object with ID {0} was referenced in a fixup but does not exist.", arg1);
            }
            static /*string */ get Serialization_NotCyclicallyReferenceableSurrogate()
            {
                return "{0}.SetObjectData returns a value that is neither null nor equal to the first parameter. Such Surrogates cannot be part of cyclical reference.";
            }
            static /*string */ FormatSerialization_NotCyclicallyReferenceableSurrogate(/*object*/ arg1)
            {
                return $.$$.System.String.Format$9("{0}.SetObjectData returns a value that is neither null nor equal to the first parameter. Such Surrogates cannot be part of cyclical reference.", arg1);
            }
            static /*string */ get Serialization_TooManyReferences()
            {
                return "The implementation of the IObjectReference interface returns too many nested references to other objects that implement IObjectReference.";
            }
            static /*string */ get Serialization_MissingObject()
            {
                return "The object with ID {0} was referenced in a fixup but has not been registered.";
            }
            static /*string */ FormatSerialization_MissingObject(/*object*/ arg1)
            {
                return $.$$.System.String.Format$9("The object with ID {0} was referenced in a fixup but has not been registered.", arg1);
            }
            static /*string */ get Serialization_InvalidFixupDiscovered()
            {
                return "A fixup on an object implementing ISerializable or having a surrogate was discovered for an object which does not have a SerializationInfo available.";
            }
            static /*string */ get Serialization_TypeLoadFailure()
            {
                return "Unable to load type {0} required for deserialization.";
            }
            static /*string */ FormatSerialization_TypeLoadFailure(/*object*/ arg1)
            {
                return $.$$.System.String.Format$9("Unable to load type {0} required for deserialization.", arg1);
            }
            static /*string */ get Serialization_ValueTypeFixup()
            {
                return "ValueType fixup on Arrays is not implemented.";
            }
            static /*string */ get Serialization_PartialValueTypeFixup()
            {
                return "Fixing up a partially available ValueType chain is not implemented.";
            }
            static /*string */ get Serialization_UnableToFixup()
            {
                return "Cannot perform fixup.";
            }
            static /*string */ get ArgumentOutOfRange_ObjectID()
            {
                return "objectID cannot be less than or equal to zero.";
            }
            static /*string */ get Serialization_RegisterTwice()
            {
                return "An object cannot be registered twice.";
            }
            static /*string */ get Serialization_NotISer()
            {
                return "The given object does not implement the ISerializable interface.";
            }
            static /*string */ get Serialization_ConstructorNotFound()
            {
                return "The constructor to deserialize an object of type '{0}' was not found.";
            }
            static /*string */ FormatSerialization_ConstructorNotFound(/*object*/ arg1)
            {
                return $.$$.System.String.Format$9("The constructor to deserialize an object of type '{0}' was not found.", arg1);
            }
            static /*string */ get Serialization_IncorrectNumberOfFixups()
            {
                return "The ObjectManager found an invalid number of fixups. This usually indicates a problem in the Formatter.";
            }
            static /*string */ get Serialization_InvalidFixupType()
            {
                return "A member fixup was registered for an object which implements ISerializable or has a surrogate. In this situation, a delayed fixup must be used.";
            }
            static /*string */ get Serialization_IdTooSmall()
            {
                return "Object IDs must be greater than zero.";
            }
            static /*string */ get Serialization_ParentChildIdentical()
            {
                return "The ID of the containing object cannot be the same as the object ID.";
            }
            static /*string */ get Serialization_InvalidType()
            {
                return "Only system-provided types can be passed to the GetUninitializedObject method. '{0}' is not a valid instance of a type.";
            }
            static /*string */ FormatSerialization_InvalidType(/*object*/ arg1)
            {
                return $.$$.System.String.Format$9("Only system-provided types can be passed to the GetUninitializedObject method. '{0}' is not a valid instance of a type.", arg1);
            }
            static /*string */ get Argument_MustSupplyParent()
            {
                return "When supplying the ID of a containing object, the FieldInfo that identifies the current field within that object must also be supplied.";
            }
            static /*string */ get Argument_MemberAndArray()
            {
                return "Cannot supply both a MemberInfo and an Array to indicate the parent of a value type.";
            }
            static /*string */ get Serialization_CorruptedStream()
            {
                return "Invalid BinaryFormatter stream.";
            }
            static /*string */ get Serialization_Stream()
            {
                return "Attempting to deserialize an empty stream.";
            }
            static /*string */ get Serialization_BinaryHeader()
            {
                return "Binary stream '{0}' does not contain a valid BinaryHeader. Possible causes are invalid stream or object version change between serialization and deserialization.";
            }
            static /*string */ FormatSerialization_BinaryHeader(/*object*/ arg1)
            {
                return $.$$.System.String.Format$9("Binary stream '{0}' does not contain a valid BinaryHeader. Possible causes are invalid stream or object version change between serialization and deserialization.", arg1);
            }
            static /*string */ get Serialization_TypeExpected()
            {
                return "Invalid expected type.";
            }
            static /*string */ get Serialization_StreamEnd()
            {
                return "End of Stream encountered before parsing was completed.";
            }
            static /*string */ get Serialization_CrossAppDomainError()
            {
                return "Cross-AppDomain BinaryFormatter error; expected '{0}' but received '{1}'.";
            }
            static /*string */ FormatSerialization_CrossAppDomainError(/*object*/ arg1, /*object*/ arg2)
            {
                return $.$$.System.String.Format$8("Cross-AppDomain BinaryFormatter error; expected '{0}' but received '{1}'.", arg1, arg2);
            }
            static /*string */ get Serialization_Map()
            {
                return "No map for object '{0}'.";
            }
            static /*string */ FormatSerialization_Map(/*object*/ arg1)
            {
                return $.$$.System.String.Format$9("No map for object '{0}'.", arg1);
            }
            static /*string */ get Serialization_Assembly()
            {
                return "No assembly information is available for object on the wire, '{0}'.";
            }
            static /*string */ FormatSerialization_Assembly(/*object*/ arg1)
            {
                return $.$$.System.String.Format$9("No assembly information is available for object on the wire, '{0}'.", arg1);
            }
            static /*string */ get Serialization_ObjectTypeEnum()
            {
                return "Invalid ObjectTypeEnum {0}.";
            }
            static /*string */ FormatSerialization_ObjectTypeEnum(/*object*/ arg1)
            {
                return $.$$.System.String.Format$9("Invalid ObjectTypeEnum {0}.", arg1);
            }
            static /*string */ get Serialization_AssemblyId()
            {
                return "No assembly ID for object type '{0}'.";
            }
            static /*string */ FormatSerialization_AssemblyId(/*object*/ arg1)
            {
                return $.$$.System.String.Format$9("No assembly ID for object type '{0}'.", arg1);
            }
            static /*string */ get Serialization_ArrayType()
            {
                return "Invalid array type '{0}'.";
            }
            static /*string */ FormatSerialization_ArrayType(/*object*/ arg1)
            {
                return $.$$.System.String.Format$9("Invalid array type '{0}'.", arg1);
            }
            static /*string */ get Serialization_TypeCode()
            {
                return "Invalid type code in stream '{0}'.";
            }
            static /*string */ FormatSerialization_TypeCode(/*object*/ arg1)
            {
                return $.$$.System.String.Format$9("Invalid type code in stream '{0}'.", arg1);
            }
            static /*string */ get Serialization_TypeWrite()
            {
                return "Invalid write type request '{0}'.";
            }
            static /*string */ FormatSerialization_TypeWrite(/*object*/ arg1)
            {
                return $.$$.System.String.Format$9("Invalid write type request '{0}'.", arg1);
            }
            static /*string */ get Serialization_TypeRead()
            {
                return "Invalid read type request '{0}'.";
            }
            static /*string */ FormatSerialization_TypeRead(/*object*/ arg1)
            {
                return $.$$.System.String.Format$9("Invalid read type request '{0}'.", arg1);
            }
            static /*string */ get Serialization_AssemblyNotFound()
            {
                return "Unable to find assembly '{0}'.";
            }
            static /*string */ FormatSerialization_AssemblyNotFound(/*object*/ arg1)
            {
                return $.$$.System.String.Format$9("Unable to find assembly '{0}'.", arg1);
            }
            static /*string */ get Serialization_InvalidFormat()
            {
                return "The input stream is not a valid binary format. The starting contents (in bytes) are: {0} ...";
            }
            static /*string */ FormatSerialization_InvalidFormat(/*object*/ arg1)
            {
                return $.$$.System.String.Format$9("The input stream is not a valid binary format. The starting contents (in bytes) are: {0} ...", arg1);
            }
            static /*string */ get Serialization_TopObject()
            {
                return "No top object.";
            }
            static /*string */ get Serialization_XMLElement()
            {
                return "Invalid element '{0}'.";
            }
            static /*string */ FormatSerialization_XMLElement(/*object*/ arg1)
            {
                return $.$$.System.String.Format$9("Invalid element '{0}'.", arg1);
            }
            static /*string */ get Serialization_TopObjectInstantiate()
            {
                return "Top object cannot be instantiated for element '{0}'.";
            }
            static /*string */ FormatSerialization_TopObjectInstantiate(/*object*/ arg1)
            {
                return $.$$.System.String.Format$9("Top object cannot be instantiated for element '{0}'.", arg1);
            }
            static /*string */ get Serialization_ArrayTypeObject()
            {
                return "Array element type is Object, 'dt' attribute is null.";
            }
            static /*string */ get Serialization_TypeMissing()
            {
                return "Type is missing for member of type Object '{0}'.";
            }
            static /*string */ FormatSerialization_TypeMissing(/*object*/ arg1)
            {
                return $.$$.System.String.Format$9("Type is missing for member of type Object '{0}'.", arg1);
            }
            static /*string */ get Serialization_ObjNoID()
            {
                return "Object {0} has never been assigned an objectID.";
            }
            static /*string */ FormatSerialization_ObjNoID(/*object*/ arg1)
            {
                return $.$$.System.String.Format$9("Object {0} has never been assigned an objectID.", arg1);
            }
            static /*string */ get Serialization_SerMemberInfo()
            {
                return "MemberInfo type {0} cannot be serialized.";
            }
            static /*string */ FormatSerialization_SerMemberInfo(/*object*/ arg1)
            {
                return $.$$.System.String.Format$9("MemberInfo type {0} cannot be serialized.", arg1);
            }
            static /*string */ get Argument_MustSupplyContainer()
            {
                return "When supplying a FieldInfo for fixing up a nested type, a valid ID for that containing object must also be supplied.";
            }
            static /*string */ get Serialization_ParseError()
            {
                return "Parse error. Current element is not compatible with the next element, {0}.";
            }
            static /*string */ FormatSerialization_ParseError(/*object*/ arg1)
            {
                return $.$$.System.String.Format$9("Parse error. Current element is not compatible with the next element, {0}.", arg1);
            }
            static /*string */ get Serialization_ISerializableMemberInfo()
            {
                return "MemberInfo requested for ISerializable type.";
            }
            static /*string */ get Serialization_MemberInfo()
            {
                return "MemberInfo cannot be obtained for ISerialized Object '{0}'.";
            }
            static /*string */ FormatSerialization_MemberInfo(/*object*/ arg1)
            {
                return $.$$.System.String.Format$9("MemberInfo cannot be obtained for ISerialized Object '{0}'.", arg1);
            }
            static /*string */ get Serialization_ISerializableTypes()
            {
                return "Types not available for ISerializable object '{0}'.";
            }
            static /*string */ FormatSerialization_ISerializableTypes(/*object*/ arg1)
            {
                return $.$$.System.String.Format$9("Types not available for ISerializable object '{0}'.", arg1);
            }
            static /*string */ get Serialization_MissingMember()
            {
                return "Member '{0}' in class '{1}' is not present in the serialized stream and is not marked with {2}.";
            }
            static /*string */ FormatSerialization_MissingMember(/*object*/ arg1, /*object*/ arg2, /*object*/ arg3)
            {
                return $.$$.System.String.Format$7("Member '{0}' in class '{1}' is not present in the serialized stream and is not marked with {2}.", arg1, arg2, arg3);
            }
            static /*string */ get Serialization_NoMemberInfo()
            {
                return "No MemberInfo for Object {0}.";
            }
            static /*string */ FormatSerialization_NoMemberInfo(/*object*/ arg1)
            {
                return $.$$.System.String.Format$9("No MemberInfo for Object {0}.", arg1);
            }
            static /*string */ get Serialization_SurrogateCycleInArgument()
            {
                return "Selector contained a cycle.";
            }
            static /*string */ get Serialization_SurrogateCycle()
            {
                return "Adding selector will introduce a cycle.";
            }
            static /*string */ get IO_EOF_ReadBeyondEOF()
            {
                return "Unable to read beyond the end of the stream.";
            }
            static /*string */ get BinaryFormatter_SerializationDisallowed()
            {
                return "BinaryFormatter serialization and deserialization are disabled within this application. See https://aka.ms/binaryformatter for more information.";
            }
            static /*string */ get BinaryFormatter_SerializationNotSupportedOnThisPlatform()
            {
                return "BinaryFormatter serialization and deserialization are not supported on this platform. See https://aka.ms/binaryformatter for more information.";
            }
            static /*string */ get BinaryFormatter_Removed()
            {
                return "BinaryFormatter serialization and deserialization have been removed. See https://aka.ms/binaryformatter for more information.";
            }
            /*bool*/ static s_usingResourceKeys = false;
            static /*bool */ GetUsingResourceKeysSwitchValue()
            {
                /*bool*/ let usingResourceKeys;
                return $.$$.System.AppContext.TryGetSwitch("System.Resources.UseSystemResourceKeys", $.$ref(() => usingResourceKeys, ($v) => usingResourceKeys = $v, $.$$.System.Boolean)) ? usingResourceKeys : false;
            }
            static /*bool */ UsingResourceKeys()
            {
                return $.$srsf.System.SR.s_usingResourceKeys;
            }
            static /*string */ GetResourceString$1(/*string*/ resourceKey)
            {
                if ($.$srsf.System.SR.UsingResourceKeys())
                {
                    return resourceKey;
                }
                /*string?*/ let resourceString = null;
                try
                {
                    resourceString = $.$srsf.System.SR.ResourceManager.GetString$1(resourceKey);
                }
                catch($e)
                {
                }
                return resourceString;
            }
            static /*string */ GetResourceString(/*string*/ resourceKey, /*string*/ defaultString)
            {
                /*string*/ let resourceString = $.$srsf.System.SR.GetResourceString$1(resourceKey);
                return $.$$.System.String.op_Equality(resourceKey, resourceString) || $.$$.System.String.op_Equality(resourceString, null) ? defaultString : resourceString;
            }
            static /*string */ Format$6(/*string*/ resourceFormat, /*object?*/ p1)
            {
                if ($.$srsf.System.SR.UsingResourceKeys())
                {
                    return $.$$.System.String.Join$7(", ", $.$$.System.ReadOnlySpan$$($.$$.System.Object).op_Implicit$1([ resourceFormat, p1 ]));
                }
                return $.$$.System.String.Format$9(resourceFormat, p1);
            }
            static /*string */ Format$5(/*string*/ resourceFormat, /*object?*/ p1, /*object?*/ p2)
            {
                if ($.$srsf.System.SR.UsingResourceKeys())
                {
                    return $.$$.System.String.Join$7(", ", $.$$.System.ReadOnlySpan$$($.$$.System.Object).op_Implicit$1([ resourceFormat, p1, p2 ]));
                }
                return $.$$.System.String.Format$8(resourceFormat, p1, p2);
            }
            static /*string */ Format$4(/*string*/ resourceFormat, /*object?*/ p1, /*object?*/ p2, /*object?*/ p3)
            {
                if ($.$srsf.System.SR.UsingResourceKeys())
                {
                    return $.$$.System.String.Join$7(", ", $.$$.System.ReadOnlySpan$$($.$$.System.Object).op_Implicit$1([ resourceFormat, p1, p2, p3 ]));
                }
                return $.$$.System.String.Format$7(resourceFormat, p1, p2, p3);
            }
            static /*string */ Format$7(/*string*/ resourceFormat, /*params object?[]?*/ args)
            {
                if (args !== null)
                {
                    if ($.$srsf.System.SR.UsingResourceKeys())
                    {
                        return resourceFormat + ", " + $.$$.System.String.Join$6(", ", args);
                    }
                    return $.$$.System.String.Format$10(resourceFormat, args);
                }
                return resourceFormat;
            }
            static /*string */ Format$2(/*IFormatProvider?*/ provider, /*string*/ resourceFormat, /*object?*/ p1)
            {
                if ($.$srsf.System.SR.UsingResourceKeys())
                {
                    return $.$$.System.String.Join$7(", ", $.$$.System.ReadOnlySpan$$($.$$.System.Object).op_Implicit$1([ resourceFormat, p1 ]));
                }
                return $.$$.System.String.Format$2(provider, resourceFormat, p1);
            }
            static /*string */ Format$1(/*IFormatProvider?*/ provider, /*string*/ resourceFormat, /*object?*/ p1, /*object?*/ p2)
            {
                if ($.$srsf.System.SR.UsingResourceKeys())
                {
                    return $.$$.System.String.Join$7(", ", $.$$.System.ReadOnlySpan$$($.$$.System.Object).op_Implicit$1([ resourceFormat, p1, p2 ]));
                }
                return $.$$.System.String.Format$1(provider, resourceFormat, p1, p2);
            }
            static /*string */ Format(/*IFormatProvider?*/ provider, /*string*/ resourceFormat, /*object?*/ p1, /*object?*/ p2, /*object?*/ p3)
            {
                if ($.$srsf.System.SR.UsingResourceKeys())
                {
                    return $.$$.System.String.Join$7(", ", $.$$.System.ReadOnlySpan$$($.$$.System.Object).op_Implicit$1([ resourceFormat, p1, p2, p3 ]));
                }
                return $.$$.System.String.Format(provider, resourceFormat, p1, p2, p3);
            }
            static /*string */ Format$3(/*IFormatProvider?*/ provider, /*string*/ resourceFormat, /*params object?[]?*/ args)
            {
                if (args !== null)
                {
                    if ($.$srsf.System.SR.UsingResourceKeys())
                    {
                        return resourceFormat + ", " + $.$$.System.String.Join$6(", ", args);
                    }
                    return $.$$.System.String.Format$3(provider, resourceFormat, args);
                }
                return resourceFormat;
            }
            //Static Initializer
            static $sinit()
            {
                {
                    this.s_usingResourceKeys = $.$srsf.System.SR.GetUsingResourceKeysSwitchValue();
                }
            }
            static $h = 2476290;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"h":2476290}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `System.SR`; }
        });
        
        $asm.$cls("$srsf.System.Runtime.Serialization.MemberHolder", ($self) => class MemberHolder extends $.$$.System.Object
        {
            /*Type*/ _memberType = null;
            /*StreamingContext*/ _context;
            $ctor$1(/*Type*/ type, /*StreamingContext*/ ctx)
            {
                super.$ctor();
                {
                    this._memberType = type;
                    this._context = ctx;
                }
                return this;
            }
            static/*conventional*/ /*int */ GetHashCode()
            {
                return $.$$.System.Type.GetHashCode.call(this._memberType);
            }
            //Static convention instance redirect
            /*int */ GetHashCode() { return $.$srsf.System.Runtime.Serialization.MemberHolder.GetHashCode.apply(this, arguments); }
            static/*conventional*/ /*bool */ Equals$1(/*object?*/ obj)
            {
                let mh;
                return $.$is(obj, $.$srsf.System.Runtime.Serialization.MemberHolder, { set $v(v){ mh = v; } }) && $.$$.System.Object.ReferenceEquals(mh._memberType, this._memberType) && mh._context.State === this._context.State;
            }
            //Static convention instance redirect
            /*bool */ Equals$1() { return $.$srsf.System.Runtime.Serialization.MemberHolder.Equals$1.apply(this, arguments); }
            //default member initializer
            constructor()
            {
                super();
                this._context = $.$default($.$$.System.Runtime.Serialization.StreamingContext);
            }
            static $h = 1231106;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"m":[{"r":655361,"n":"GetHashCode","d":1231106,"h":17181100290,"f":16809985},{"r":262145,"p":[{"n":"obj","p":131073}],"n":"Equals","o":"@$1","d":1231106,"h":21476067586,"f":16809985}],"l":[{"t":142475265,"n":"_memberType","d":1231106,"h":4296198402,"f":4194312},{"t":113967105,"n":"_context","d":1231106,"h":8591165698,"f":4194312}],"c":[{"p":[{"n":"type","p":142475265},{"n":"ctx","p":113967105}],"n":".ctor","o":"$ctor$1","d":1231106,"h":12886132994,"f":16777224}],"h":1231106}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `System.Runtime.Serialization.MemberHolder`; }
        });
        
        $asm.$cls("$srsf.System.Runtime.Serialization.ObjectIDGenerator", ($self) => class ObjectIDGenerator extends $.$$.System.Object
        {
            /*int*/ static NumBins = 4;
            /*int*/ _currentCount = 0;
            /*int*/ _currentSize = 0;
            /*long[]*/ _ids = null;
            /*object[]*/ _objs = null;
            $ctor$1()
            {
                super.$ctor();
                {
                    this._currentCount = 1;
                    this._currentSize = 3;
                    this._ids = $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$$.System.Int64), null, [((this._currentSize * 4/*NumBins*/) | 0)], null);
                    this._objs = $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$$.System.Object), null, [((this._currentSize * 4/*NumBins*/) | 0)], null);
                }
                return this;
            }
            /*int */ FindElement(/*object*/ obj, /*out bool*/ found)
            {
                /*int*/ let hashcode = $.$$.System.Runtime.CompilerServices.RuntimeHelpers.GetHashCode$1(obj);
                /*int*/ let hashIncrement = (((1 + ((hashcode & 2147483647) % (((this._currentSize - 2) | 0)))) | 0));
                do
                {
                    /*int*/ let pos = ((((hashcode & 2147483647) % this._currentSize) * 4/*NumBins*/) | 0);
                    for(/*int*/ let i = pos; i < ((pos + 4/*NumBins*/) | 0); i++)
                    {
                        if ($.$$.System.Array.$ReadT1.call(this._objs, i) === null)
                        {
                            found.$v = false;
                            return i;
                        }
                        if ($.$$.System.Array.$ReadT1.call(this._objs, i) === obj)
                        {
                            found.$v = true;
                            return i;
                        }
                    }
                    hashcode += hashIncrement;
                }
                while(true);
            }
            /*long */ GetId(/*object*/ obj, /*out bool*/ firstTime)
            {
                $.$$.System.ArgumentNullException.ThrowIfNull$2(obj, "obj");
                /*bool*/ let found;
                /*int*/ let pos = this.FindElement(obj, $.$ref(() => found, ($v) => found = $v, $.$$.System.Boolean));
                /*long*/ let foundID;
                if (!found)
                {
                    $.$$.System.Array.$WriteT1.call(this._objs, obj, pos);
                    $.$$.System.Array.$WriteT1.call(this._ids, BigInt(this._currentCount++), pos);
                    foundID = $.$$.System.Array.$ReadT1.call(this._ids, pos);
                    if (this._currentCount > $.trunc((((this._currentSize * 4/*NumBins*/) | 0)) / 2))
                    {
                        this.Rehash();
                    }
                }
                else 
                {
                    foundID = $.$$.System.Array.$ReadT1.call(this._ids, pos);
                }
                firstTime.$v = !found;
                return foundID;
            }
            /*long */ HasId(/*object*/ obj, /*out bool*/ firstTime)
            {
                $.$$.System.ArgumentNullException.ThrowIfNull$2(obj, "obj");
                /*bool*/ let found;
                /*int*/ let pos = this.FindElement(obj, $.$ref(() => found, ($v) => found = $v, $.$$.System.Boolean));
                if (found)
                {
                    firstTime.$v = false;
                    return $.$$.System.Array.$ReadT1.call(this._ids, pos);
                }
                firstTime.$v = true;
                return 0n;
            }
            /*void */ Rehash()
            {
                /*int*/ let currSize = this._currentSize;
                /*int*/ let newSize = $.$srsf.System.Collections.HashHelpers.ExpandPrime(currSize);
                if (newSize === currSize)
                {
                    throw new $.$$.System.Runtime.Serialization.SerializationException().$ctor$12($.$srsf.System.SR.Serialization_TooManyElements);
                }
                this._currentSize = newSize;
                /*long[]*/ let newIds = $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$$.System.Int64), null, [((this._currentSize * 4/*NumBins*/) | 0)], null);
                /*object[]*/ let newObjs = $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$$.System.Object), null, [((this._currentSize * 4/*NumBins*/) | 0)], null);
                /*long[]*/ let oldIds = this._ids;
                /*object[]*/ let oldObjs = this._objs;
                this._ids = newIds;
                this._objs = newObjs;
                for(/*int*/ let j = 0; j < oldObjs.length; j++)
                {
                    if ($.$$.System.Array.$ReadT1.call(oldObjs, j) !== null)
                    {
                        /*int*/ let pos = this.FindElement($.$$.System.Array.$ReadT1.call(oldObjs, j), $.$discardRef());
                        $.$$.System.Array.$WriteT1.call(this._objs, $.$$.System.Array.$ReadT1.call(oldObjs, j), pos);
                        $.$$.System.Array.$WriteT1.call(this._ids, $.$$.System.Array.$ReadT1.call(oldIds, j), pos);
                    }
                }
            }
            static $h = 1493250;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"m":[{"r":655361,"p":[{"n":"obj","p":131073},{"n":"found","p":262145,"f":2}],"n":"FindElement","d":1493250,"h":30066264322,"f":16777218},{"r":917505,"p":[{"n":"obj","p":131073},{"n":"firstTime","p":262145,"f":2}],"n":"GetId","d":1493250,"h":34361231618,"f":16777345},{"r":917505,"p":[{"n":"obj","p":131073},{"n":"firstTime","p":262145,"f":2}],"n":"HasId","d":1493250,"h":38656198914,"f":16777345},{"r":65537,"n":"Rehash","d":1493250,"h":42951166210,"f":16777218}],"l":[{"t":655361,"n":"NumBins","d":1493250,"h":4296460546,"f":4194338},{"t":655361,"n":"_currentCount","d":1493250,"h":8591427842,"f":4194312},{"t":655361,"n":"_currentSize","d":1493250,"h":12886395138,"f":4194306},{"t":$.$typeArray($.$$.System.Int64).$h,"n":"_ids","d":1493250,"h":17181362434,"f":4194306},{"t":$.$typeArray($.$$.System.Object).$h,"n":"_objs","d":1493250,"h":21476329730,"f":4194306}],"c":[{"n":".ctor","o":"$ctor$1","d":1493250,"h":25771297026,"f":16777217}],"h":1493250,"a":[{"t":70909953,"c":8660844545,"a":[{"v":"Formatter-based serialization is obsolete and should not be used.","t":1310721}],"n":[{"n":"DiagnosticId","v":"SYSLIB0050","t":1310721},{"n":"UrlFormat","v":"https://aka.ms/dotnet-warnings/{0}","t":1310721}]}]}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `System.Runtime.Serialization.ObjectIDGenerator`; }
        });
        
        $asm.$cls("$srsf.System.Obsoletions", ($self) => class Obsoletions
        {
            /*string*/ static SharedUrlFormat = null;
            /*string*/ static SystemTextEncodingUTF7Message = null;
            /*string*/ static SystemTextEncodingUTF7DiagId = null;
            /*string*/ static PrincipalPermissionAttributeMessage = null;
            /*string*/ static PrincipalPermissionAttributeDiagId = null;
            /*string*/ static CodeAccessSecurityMessage = null;
            /*string*/ static CodeAccessSecurityDiagId = null;
            /*string*/ static ConstrainedExecutionRegionMessage = null;
            /*string*/ static ConstrainedExecutionRegionDiagId = null;
            /*string*/ static GlobalAssemblyCacheMessage = null;
            /*string*/ static GlobalAssemblyCacheDiagId = null;
            /*string*/ static ThreadAbortMessage = null;
            /*string*/ static ThreadResetAbortMessage = null;
            /*string*/ static ThreadAbortDiagId = null;
            /*string*/ static DefaultCryptoAlgorithmsMessage = null;
            /*string*/ static DefaultCryptoAlgorithmsDiagId = null;
            /*string*/ static CreatePdbGeneratorMessage = null;
            /*string*/ static CreatePdbGeneratorDiagId = null;
            /*string*/ static AuthenticationManagerMessage = null;
            /*string*/ static AuthenticationManagerDiagId = null;
            /*string*/ static RemotingApisMessage = null;
            /*string*/ static RemotingApisDiagId = null;
            /*string*/ static BinaryFormatterMessage = null;
            /*string*/ static BinaryFormatterDiagId = null;
            /*string*/ static CodeBaseMessage = null;
            /*string*/ static CodeBaseDiagId = null;
            /*string*/ static EscapeUriStringMessage = null;
            /*string*/ static EscapeUriStringDiagId = null;
            /*string*/ static WebRequestMessage = null;
            /*string*/ static WebRequestDiagId = null;
            /*string*/ static DisablePrivateReflectionAttributeMessage = null;
            /*string*/ static DisablePrivateReflectionAttributeDiagId = null;
            /*string*/ static GetContextInfoMessage = null;
            /*string*/ static GetContextInfoDiagId = null;
            /*string*/ static StrongNameKeyPairMessage = null;
            /*string*/ static StrongNameKeyPairDiagId = null;
            /*string*/ static ReflectionOnlyLoadingMessage = null;
            /*string*/ static ReflectionOnlyLoadingDiagId = null;
            /*string*/ static RuntimeEnvironmentMessage = null;
            /*string*/ static RuntimeEnvironmentDiagId = null;
            /*string*/ static JsonSerializerOptionsIgnoreNullValuesMessage = null;
            /*string*/ static JsonSerializerOptionsIgnoreNullValuesDiagId = null;
            /*string*/ static DerivedCryptographicTypesMessage = null;
            /*string*/ static DerivedCryptographicTypesDiagId = null;
            /*string*/ static RijndaelMessage = null;
            /*string*/ static RijndaelDiagId = null;
            /*string*/ static RNGCryptoServiceProviderMessage = null;
            /*string*/ static RNGCryptoServiceProviderDiagId = null;
            /*string*/ static AppDomainCreateUnloadMessage = null;
            /*string*/ static AppDomainCreateUnloadDiagId = null;
            /*string*/ static SuppressIldasmAttributeMessage = null;
            /*string*/ static SuppressIldasmAttributeDiagId = null;
            /*string*/ static X509CertificateImmutableMessage = null;
            /*string*/ static X509CertificateImmutableDiagId = null;
            /*string*/ static PublicKeyPropertyMessage = null;
            /*string*/ static PublicKeyPropertyDiagId = null;
            /*string*/ static X509CertificatePrivateKeyMessage = null;
            /*string*/ static X509CertificatePrivateKeyDiagId = null;
            /*string*/ static ProduceLegacyHmacValuesMessage = null;
            /*string*/ static ProduceLegacyHmacValuesDiagId = null;
            /*string*/ static UseManagedSha1Message = null;
            /*string*/ static UseManagedSha1DiagId = null;
            /*string*/ static CryptoConfigEncodeOIDMessage = null;
            /*string*/ static CryptoConfigEncodeOIDDiagId = null;
            /*string*/ static CorruptedStateRecoveryMessage = null;
            /*string*/ static CorruptedStateRecoveryDiagId = null;
            /*string*/ static Rfc2898CryptDeriveKeyMessage = null;
            /*string*/ static Rfc2898CryptDeriveKeyDiagId = null;
            /*string*/ static CmsSignerCspParamsCtorMessage = null;
            /*string*/ static CmsSignerCspParamsCtorDiagId = null;
            /*string*/ static SignerInfoCounterSigMessage = null;
            /*string*/ static SignerInfoCounterSigDiagId = null;
            /*string*/ static RegexCompileToAssemblyMessage = null;
            /*string*/ static RegexCompileToAssemblyDiagId = null;
            /*string*/ static AssemblyNameMembersMessage = null;
            /*string*/ static AssemblyNameMembersDiagId = null;
            /*string*/ static SystemDataSerializationFormatBinaryMessage = null;
            /*string*/ static SystemDataSerializationFormatBinaryDiagId = null;
            /*string*/ static TlsVersion10and11Message = null;
            /*string*/ static TlsVersion10and11DiagId = null;
            /*string*/ static EncryptionPolicyMessage = null;
            /*string*/ static EncryptionPolicyDiagId = null;
            /*string*/ static EccXmlExportImportMessage = null;
            /*string*/ static EccXmlExportImportDiagId = null;
            /*string*/ static EcDhPublicKeyBlobMessage = null;
            /*string*/ static EcDhPublicKeyBlobDiagId = null;
            /*string*/ static AssemblyNameCodeBaseMessage = null;
            /*string*/ static AssemblyNameCodeBaseDiagId = null;
            /*string*/ static CryptoStringFactoryMessage = null;
            /*string*/ static CryptoStringFactoryDiagId = null;
            /*string*/ static ControlledExecutionRunMessage = null;
            /*string*/ static ControlledExecutionRunDiagId = null;
            /*string*/ static XmlSecureResolverMessage = null;
            /*string*/ static XmlSecureResolverDiagId = null;
            /*string*/ static RsaEncryptDecryptValueMessage = null;
            /*string*/ static RsaEncryptDecryptDiagId = null;
            /*string*/ static JsonSerializerOptionsAddContextMessage = null;
            /*string*/ static JsonSerializerOptionsAddContextDiagId = null;
            /*string*/ static LegacyFormatterMessage = null;
            /*string*/ static LegacyFormatterDiagId = null;
            /*string*/ static LegacyFormatterImplMessage = null;
            /*string*/ static LegacyFormatterImplDiagId = null;
            /*string*/ static RegexExtensibilityImplMessage = null;
            /*string*/ static RegexExtensibilityDiagId = null;
            /*string*/ static AesGcmTagConstructorMessage = null;
            /*string*/ static AesGcmTagConstructorDiagId = null;
            /*string*/ static ThreadVolatileReadWriteMessage = null;
            /*string*/ static ThreadVolatileReadWriteDiagId = null;
            /*string*/ static ArmIntrinsicPerformsUnsignedOperationMessage = null;
            /*string*/ static ArmIntrinsicPerformsUnsignedOperationDiagId = null;
            /*string*/ static LoadFromHashAlgorithmMessage = null;
            /*string*/ static LoadFromHashAlgorithmDiagId = null;
            /*string*/ static X509CtorCertDataObsoleteMessage = null;
            /*string*/ static X509CtorCertDataObsoleteDiagId = null;
            /*string*/ static TlsCipherAlgorithmEnumsMessage = null;
            /*string*/ static TlsCipherAlgorithmEnumsDiagId = null;
            /*string*/ static SystemEventsEventsThreadShutdownMessage = null;
            /*string*/ static SystemEventsEventsThreadShutdownDiagId = null;
            /*string*/ static Rfc2898DeriveBytesCtorMessage = null;
            /*string*/ static Rfc2898DeriveBytesCtorDiagId = null;
            /*string*/ static QueryableMinByMaxByTSourceObsoleteMessage = null;
            /*string*/ static QueryableMinByMaxByTSourceObsoleteDiagId = null;
            /*string*/ static XsltSettingsEnableScriptMessage = null;
            /*string*/ static XsltSettingsEnableScriptDiagId = null;
            //Static Initializer
            static $sinit()
            {
                {
                    this.SharedUrlFormat = "https://aka.ms/dotnet-warnings/{0}";
                }
                {
                    this.SystemTextEncodingUTF7Message = "The UTF-7 encoding is insecure and should not be used. Consider using UTF-8 instead.";
                }
                {
                    this.SystemTextEncodingUTF7DiagId = "SYSLIB0001";
                }
                {
                    this.PrincipalPermissionAttributeMessage = "PrincipalPermissionAttribute is not honored by the runtime and must not be used.";
                }
                {
                    this.PrincipalPermissionAttributeDiagId = "SYSLIB0002";
                }
                {
                    this.CodeAccessSecurityMessage = "Code Access Security is not supported or honored by the runtime.";
                }
                {
                    this.CodeAccessSecurityDiagId = "SYSLIB0003";
                }
                {
                    this.ConstrainedExecutionRegionMessage = "The Constrained Execution Region (CER) feature is not supported.";
                }
                {
                    this.ConstrainedExecutionRegionDiagId = "SYSLIB0004";
                }
                {
                    this.GlobalAssemblyCacheMessage = "The Global Assembly Cache is not supported.";
                }
                {
                    this.GlobalAssemblyCacheDiagId = "SYSLIB0005";
                }
                {
                    this.ThreadAbortMessage = "Thread.Abort is not supported and throws PlatformNotSupportedException.";
                }
                {
                    this.ThreadResetAbortMessage = "Thread.ResetAbort is not supported and throws PlatformNotSupportedException.";
                }
                {
                    this.ThreadAbortDiagId = "SYSLIB0006";
                }
                {
                    this.DefaultCryptoAlgorithmsMessage = "The default implementation of this cryptography algorithm is not supported.";
                }
                {
                    this.DefaultCryptoAlgorithmsDiagId = "SYSLIB0007";
                }
                {
                    this.CreatePdbGeneratorMessage = "The CreatePdbGenerator API is not supported and throws PlatformNotSupportedException.";
                }
                {
                    this.CreatePdbGeneratorDiagId = "SYSLIB0008";
                }
                {
                    this.AuthenticationManagerMessage = "AuthenticationManager is not supported. Methods will no-op or throw PlatformNotSupportedException.";
                }
                {
                    this.AuthenticationManagerDiagId = "SYSLIB0009";
                }
                {
                    this.RemotingApisMessage = "This Remoting API is not supported and throws PlatformNotSupportedException.";
                }
                {
                    this.RemotingApisDiagId = "SYSLIB0010";
                }
                {
                    this.BinaryFormatterMessage = "BinaryFormatter serialization is obsolete and should not be used. See https://aka.ms/binaryformatter for more information.";
                }
                {
                    this.BinaryFormatterDiagId = "SYSLIB0011";
                }
                {
                    this.CodeBaseMessage = "Assembly.CodeBase and Assembly.EscapedCodeBase are only included for .NET Framework compatibility. Use Assembly.Location instead.";
                }
                {
                    this.CodeBaseDiagId = "SYSLIB0012";
                }
                {
                    this.EscapeUriStringMessage = "Uri.EscapeUriString can corrupt the Uri string in some cases. Consider using Uri.EscapeDataString for query string components instead.";
                }
                {
                    this.EscapeUriStringDiagId = "SYSLIB0013";
                }
                {
                    this.WebRequestMessage = "WebRequest, HttpWebRequest, ServicePoint, and WebClient are obsolete. Use HttpClient instead.";
                }
                {
                    this.WebRequestDiagId = "SYSLIB0014";
                }
                {
                    this.DisablePrivateReflectionAttributeMessage = "DisablePrivateReflectionAttribute has no effect in .NET 6.0+.";
                }
                {
                    this.DisablePrivateReflectionAttributeDiagId = "SYSLIB0015";
                }
                {
                    this.GetContextInfoMessage = "Use the Graphics.GetContextInfo overloads that accept arguments for better performance and fewer allocations.";
                }
                {
                    this.GetContextInfoDiagId = "SYSLIB0016";
                }
                {
                    this.StrongNameKeyPairMessage = "Strong name signing is not supported and throws PlatformNotSupportedException.";
                }
                {
                    this.StrongNameKeyPairDiagId = "SYSLIB0017";
                }
                {
                    this.ReflectionOnlyLoadingMessage = "ReflectionOnly loading is not supported and throws PlatformNotSupportedException.";
                }
                {
                    this.ReflectionOnlyLoadingDiagId = "SYSLIB0018";
                }
                {
                    this.RuntimeEnvironmentMessage = "RuntimeEnvironment members SystemConfigurationFile, GetRuntimeInterfaceAsIntPtr, and GetRuntimeInterfaceAsObject are not supported and throw PlatformNotSupportedException.";
                }
                {
                    this.RuntimeEnvironmentDiagId = "SYSLIB0019";
                }
                {
                    this.JsonSerializerOptionsIgnoreNullValuesMessage = "JsonSerializerOptions.IgnoreNullValues is obsolete. To ignore null values when serializing, set DefaultIgnoreCondition to JsonIgnoreCondition.WhenWritingNull.";
                }
                {
                    this.JsonSerializerOptionsIgnoreNullValuesDiagId = "SYSLIB0020";
                }
                {
                    this.DerivedCryptographicTypesMessage = "Derived cryptographic types are obsolete. Use the Create method on the base type instead.";
                }
                {
                    this.DerivedCryptographicTypesDiagId = "SYSLIB0021";
                }
                {
                    this.RijndaelMessage = "The Rijndael and RijndaelManaged types are obsolete. Use Aes instead.";
                }
                {
                    this.RijndaelDiagId = "SYSLIB0022";
                }
                {
                    this.RNGCryptoServiceProviderMessage = "RNGCryptoServiceProvider is obsolete. To generate a random number, use one of the RandomNumberGenerator static methods instead.";
                }
                {
                    this.RNGCryptoServiceProviderDiagId = "SYSLIB0023";
                }
                {
                    this.AppDomainCreateUnloadMessage = "Creating and unloading AppDomains is not supported and throws an exception.";
                }
                {
                    this.AppDomainCreateUnloadDiagId = "SYSLIB0024";
                }
                {
                    this.SuppressIldasmAttributeMessage = "SuppressIldasmAttribute has no effect in .NET 6.0+.";
                }
                {
                    this.SuppressIldasmAttributeDiagId = "SYSLIB0025";
                }
                {
                    this.X509CertificateImmutableMessage = "X509Certificate and X509Certificate2 are immutable. Use X509CertificateLoader to create a new certificate.";
                }
                {
                    this.X509CertificateImmutableDiagId = "SYSLIB0026";
                }
                {
                    this.PublicKeyPropertyMessage = "PublicKey.Key is obsolete. Use the appropriate method to get the public key, such as GetRSAPublicKey.";
                }
                {
                    this.PublicKeyPropertyDiagId = "SYSLIB0027";
                }
                {
                    this.X509CertificatePrivateKeyMessage = "X509Certificate2.PrivateKey is obsolete. Use the appropriate method to get the private key, such as GetRSAPrivateKey, or use the CopyWithPrivateKey method to create a new instance with a private key.";
                }
                {
                    this.X509CertificatePrivateKeyDiagId = "SYSLIB0028";
                }
                {
                    this.ProduceLegacyHmacValuesMessage = "ProduceLegacyHmacValues is obsolete. Producing legacy HMAC values is not supported.";
                }
                {
                    this.ProduceLegacyHmacValuesDiagId = "SYSLIB0029";
                }
                {
                    this.UseManagedSha1Message = "HMACSHA1 always uses the algorithm implementation provided by the platform. Use a constructor without the useManagedSha1 parameter.";
                }
                {
                    this.UseManagedSha1DiagId = "SYSLIB0030";
                }
                {
                    this.CryptoConfigEncodeOIDMessage = "EncodeOID is obsolete. Use the ASN.1 functionality provided in System.Formats.Asn1.";
                }
                {
                    this.CryptoConfigEncodeOIDDiagId = "SYSLIB0031";
                }
                {
                    this.CorruptedStateRecoveryMessage = "Recovery from corrupted process state exceptions is not supported; HandleProcessCorruptedStateExceptionsAttribute is ignored.";
                }
                {
                    this.CorruptedStateRecoveryDiagId = "SYSLIB0032";
                }
                {
                    this.Rfc2898CryptDeriveKeyMessage = "Rfc2898DeriveBytes.CryptDeriveKey is obsolete and is not supported. Use PasswordDeriveBytes.CryptDeriveKey instead.";
                }
                {
                    this.Rfc2898CryptDeriveKeyDiagId = "SYSLIB0033";
                }
                {
                    this.CmsSignerCspParamsCtorMessage = "CmsSigner(CspParameters) is obsolete and is not supported. Use an alternative constructor instead.";
                }
                {
                    this.CmsSignerCspParamsCtorDiagId = "SYSLIB0034";
                }
                {
                    this.SignerInfoCounterSigMessage = "ComputeCounterSignature without specifying a CmsSigner is obsolete and is not supported. Use the overload that accepts a CmsSigner.";
                }
                {
                    this.SignerInfoCounterSigDiagId = "SYSLIB0035";
                }
                {
                    this.RegexCompileToAssemblyMessage = "Regex.CompileToAssembly is obsolete and not supported. Use the GeneratedRegexAttribute with the regular expression source generator instead.";
                }
                {
                    this.RegexCompileToAssemblyDiagId = "SYSLIB0036";
                }
                {
                    this.AssemblyNameMembersMessage = "AssemblyName members HashAlgorithm, ProcessorArchitecture, and VersionCompatibility are obsolete and not supported.";
                }
                {
                    this.AssemblyNameMembersDiagId = "SYSLIB0037";
                }
                {
                    this.SystemDataSerializationFormatBinaryMessage = "SerializationFormat.Binary is obsolete and should not be used. See https://aka.ms/serializationformat-binary-obsolete for more information.";
                }
                {
                    this.SystemDataSerializationFormatBinaryDiagId = "SYSLIB0038";
                }
                {
                    this.TlsVersion10and11Message = "TLS versions 1.0 and 1.1 have known vulnerabilities and are not recommended. Use a newer TLS version instead, or use SslProtocols.None to defer to OS defaults.";
                }
                {
                    this.TlsVersion10and11DiagId = "SYSLIB0039";
                }
                {
                    this.EncryptionPolicyMessage = "EncryptionPolicy.NoEncryption and AllowEncryption significantly reduce security and should not be used in production code.";
                }
                {
                    this.EncryptionPolicyDiagId = "SYSLIB0040";
                }
                {
                    this.EccXmlExportImportMessage = "ToXmlString and FromXmlString have no implementation for ECC types, and are obsolete. Use a standard import and export format such as ExportSubjectPublicKeyInfo or ImportSubjectPublicKeyInfo for public keys and ExportPkcs8PrivateKey or ImportPkcs8PrivateKey for private keys.";
                }
                {
                    this.EccXmlExportImportDiagId = "SYSLIB0042";
                }
                {
                    this.EcDhPublicKeyBlobMessage = "ECDiffieHellmanPublicKey.ToByteArray() and the associated constructor do not have a consistent and interoperable implementation on all platforms. Use ECDiffieHellmanPublicKey.ExportSubjectPublicKeyInfo() instead.";
                }
                {
                    this.EcDhPublicKeyBlobDiagId = "SYSLIB0043";
                }
                {
                    this.AssemblyNameCodeBaseMessage = "AssemblyName.CodeBase and AssemblyName.EscapedCodeBase are obsolete. Using them for loading an assembly is not supported.";
                }
                {
                    this.AssemblyNameCodeBaseDiagId = "SYSLIB0044";
                }
                {
                    this.CryptoStringFactoryMessage = "Cryptographic factory methods accepting an algorithm name are obsolete. Use the parameterless Create factory method on the algorithm type instead.";
                }
                {
                    this.CryptoStringFactoryDiagId = "SYSLIB0045";
                }
                {
                    this.ControlledExecutionRunMessage = "ControlledExecution.Run method may corrupt the process and should not be used in production code.";
                }
                {
                    this.ControlledExecutionRunDiagId = "SYSLIB0046";
                }
                {
                    this.XmlSecureResolverMessage = "XmlSecureResolver is obsolete. Use XmlResolver.ThrowingResolver instead when attempting to forbid XML external entity resolution.";
                }
                {
                    this.XmlSecureResolverDiagId = "SYSLIB0047";
                }
                {
                    this.RsaEncryptDecryptValueMessage = "RSA.EncryptValue and DecryptValue are not supported and throw NotSupportedException. Use RSA.Encrypt and RSA.Decrypt instead.";
                }
                {
                    this.RsaEncryptDecryptDiagId = "SYSLIB0048";
                }
                {
                    this.JsonSerializerOptionsAddContextMessage = "JsonSerializerOptions.AddContext is obsolete. To register a JsonSerializerContext, use either the TypeInfoResolver or TypeInfoResolverChain properties.";
                }
                {
                    this.JsonSerializerOptionsAddContextDiagId = "SYSLIB0049";
                }
                {
                    this.LegacyFormatterMessage = "Formatter-based serialization is obsolete and should not be used.";
                }
                {
                    this.LegacyFormatterDiagId = "SYSLIB0050";
                }
                {
                    this.LegacyFormatterImplMessage = "This API supports obsolete formatter-based serialization. It should not be called or extended by application code.";
                }
                {
                    this.LegacyFormatterImplDiagId = "SYSLIB0051";
                }
                {
                    this.RegexExtensibilityImplMessage = "This API supports obsolete mechanisms for Regex extensibility. It is not supported.";
                }
                {
                    this.RegexExtensibilityDiagId = "SYSLIB0052";
                }
                {
                    this.AesGcmTagConstructorMessage = "AesGcm should indicate the required tag size for encryption and decryption. Use a constructor that accepts the tag size.";
                }
                {
                    this.AesGcmTagConstructorDiagId = "SYSLIB0053";
                }
                {
                    this.ThreadVolatileReadWriteMessage = "Thread.VolatileRead and Thread.VolatileWrite are obsolete. Use Volatile.Read or Volatile.Write respectively instead.";
                }
                {
                    this.ThreadVolatileReadWriteDiagId = "SYSLIB0054";
                }
                {
                    this.ArmIntrinsicPerformsUnsignedOperationMessage = "The underlying hardware instruction does not perform a signed saturate narrowing operation, and it always returns an unsigned result. Use the unsigned overload instead.";
                }
                {
                    this.ArmIntrinsicPerformsUnsignedOperationDiagId = "SYSLIB0055";
                }
                {
                    this.LoadFromHashAlgorithmMessage = "LoadFrom with a custom AssemblyHashAlgorithm is obsolete. Use overloads without an AssemblyHashAlgorithm.";
                }
                {
                    this.LoadFromHashAlgorithmDiagId = "SYSLIB0056";
                }
                {
                    this.X509CtorCertDataObsoleteMessage = "Loading certificate data through the constructor or Import is obsolete. Use X509CertificateLoader instead to load certificates.";
                }
                {
                    this.X509CtorCertDataObsoleteDiagId = "SYSLIB0057";
                }
                {
                    this.TlsCipherAlgorithmEnumsMessage = "KeyExchangeAlgorithm, KeyExchangeStrength, CipherAlgorithm, CipherStrength, HashAlgorithm and HashStrength properties of SslStream are obsolete. Use NegotiatedCipherSuite instead.";
                }
                {
                    this.TlsCipherAlgorithmEnumsDiagId = "SYSLIB0058";
                }
                {
                    this.SystemEventsEventsThreadShutdownMessage = "SystemEvents.EventsThreadShutdown callbacks are not run before the process exits. Use AppDomain.ProcessExit instead.";
                }
                {
                    this.SystemEventsEventsThreadShutdownDiagId = "SYSLIB0059";
                }
                {
                    this.Rfc2898DeriveBytesCtorMessage = "The constructors on Rfc2898DeriveBytes are obsolete. Use the static Pbkdf2 method instead.";
                }
                {
                    this.Rfc2898DeriveBytesCtorDiagId = "SYSLIB0060";
                }
                {
                    this.QueryableMinByMaxByTSourceObsoleteMessage = "The Queryable MinBy and MaxBy taking an IComparer<TSource> are obsolete. Use the new ones that take an IComparer<TKey>.";
                }
                {
                    this.QueryableMinByMaxByTSourceObsoleteDiagId = "SYSLIB0061";
                }
                {
                    this.XsltSettingsEnableScriptMessage = "XSLT Script blocks are not supported.";
                }
                {
                    this.XsltSettingsEnableScriptDiagId = "SYSLIB0062";
                }
            }
            static $h = 182530;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"l":[{"t":1310721,"n":"SharedUrlFormat","d":182530,"h":4295149826,"f":4194344},{"t":1310721,"n":"SystemTextEncodingUTF7Message","d":182530,"h":8590117122,"f":4194344},{"t":1310721,"n":"SystemTextEncodingUTF7DiagId","d":182530,"h":12885084418,"f":4194344},{"t":1310721,"n":"PrincipalPermissionAttributeMessage","d":182530,"h":17180051714,"f":4194344},{"t":1310721,"n":"PrincipalPermissionAttributeDiagId","d":182530,"h":21475019010,"f":4194344},{"t":1310721,"n":"CodeAccessSecurityMessage","d":182530,"h":25769986306,"f":4194344},{"t":1310721,"n":"CodeAccessSecurityDiagId","d":182530,"h":30064953602,"f":4194344},{"t":1310721,"n":"ConstrainedExecutionRegionMessage","d":182530,"h":34359920898,"f":4194344},{"t":1310721,"n":"ConstrainedExecutionRegionDiagId","d":182530,"h":38654888194,"f":4194344},{"t":1310721,"n":"GlobalAssemblyCacheMessage","d":182530,"h":42949855490,"f":4194344},{"t":1310721,"n":"GlobalAssemblyCacheDiagId","d":182530,"h":47244822786,"f":4194344},{"t":1310721,"n":"ThreadAbortMessage","d":182530,"h":51539790082,"f":4194344},{"t":1310721,"n":"ThreadResetAbortMessage","d":182530,"h":55834757378,"f":4194344},{"t":1310721,"n":"ThreadAbortDiagId","d":182530,"h":60129724674,"f":4194344},{"t":1310721,"n":"DefaultCryptoAlgorithmsMessage","d":182530,"h":64424691970,"f":4194344},{"t":1310721,"n":"DefaultCryptoAlgorithmsDiagId","d":182530,"h":68719659266,"f":4194344},{"t":1310721,"n":"CreatePdbGeneratorMessage","d":182530,"h":73014626562,"f":4194344},{"t":1310721,"n":"CreatePdbGeneratorDiagId","d":182530,"h":77309593858,"f":4194344},{"t":1310721,"n":"AuthenticationManagerMessage","d":182530,"h":81604561154,"f":4194344},{"t":1310721,"n":"AuthenticationManagerDiagId","d":182530,"h":85899528450,"f":4194344},{"t":1310721,"n":"RemotingApisMessage","d":182530,"h":90194495746,"f":4194344},{"t":1310721,"n":"RemotingApisDiagId","d":182530,"h":94489463042,"f":4194344},{"t":1310721,"n":"BinaryFormatterMessage","d":182530,"h":98784430338,"f":4194344},{"t":1310721,"n":"BinaryFormatterDiagId","d":182530,"h":103079397634,"f":4194344},{"t":1310721,"n":"CodeBaseMessage","d":182530,"h":107374364930,"f":4194344},{"t":1310721,"n":"CodeBaseDiagId","d":182530,"h":111669332226,"f":4194344},{"t":1310721,"n":"EscapeUriStringMessage","d":182530,"h":115964299522,"f":4194344},{"t":1310721,"n":"EscapeUriStringDiagId","d":182530,"h":120259266818,"f":4194344},{"t":1310721,"n":"WebRequestMessage","d":182530,"h":124554234114,"f":4194344},{"t":1310721,"n":"WebRequestDiagId","d":182530,"h":128849201410,"f":4194344},{"t":1310721,"n":"DisablePrivateReflectionAttributeMessage","d":182530,"h":133144168706,"f":4194344},{"t":1310721,"n":"DisablePrivateReflectionAttributeDiagId","d":182530,"h":137439136002,"f":4194344},{"t":1310721,"n":"GetContextInfoMessage","d":182530,"h":141734103298,"f":4194344},{"t":1310721,"n":"GetContextInfoDiagId","d":182530,"h":146029070594,"f":4194344},{"t":1310721,"n":"StrongNameKeyPairMessage","d":182530,"h":150324037890,"f":4194344},{"t":1310721,"n":"StrongNameKeyPairDiagId","d":182530,"h":154619005186,"f":4194344},{"t":1310721,"n":"ReflectionOnlyLoadingMessage","d":182530,"h":158913972482,"f":4194344},{"t":1310721,"n":"ReflectionOnlyLoadingDiagId","d":182530,"h":163208939778,"f":4194344},{"t":1310721,"n":"RuntimeEnvironmentMessage","d":182530,"h":167503907074,"f":4194344},{"t":1310721,"n":"RuntimeEnvironmentDiagId","d":182530,"h":171798874370,"f":4194344},{"t":1310721,"n":"JsonSerializerOptionsIgnoreNullValuesMessage","d":182530,"h":176093841666,"f":4194344},{"t":1310721,"n":"JsonSerializerOptionsIgnoreNullValuesDiagId","d":182530,"h":180388808962,"f":4194344},{"t":1310721,"n":"DerivedCryptographicTypesMessage","d":182530,"h":184683776258,"f":4194344},{"t":1310721,"n":"DerivedCryptographicTypesDiagId","d":182530,"h":188978743554,"f":4194344},{"t":1310721,"n":"RijndaelMessage","d":182530,"h":193273710850,"f":4194344},{"t":1310721,"n":"RijndaelDiagId","d":182530,"h":197568678146,"f":4194344},{"t":1310721,"n":"RNGCryptoServiceProviderMessage","d":182530,"h":201863645442,"f":4194344},{"t":1310721,"n":"RNGCryptoServiceProviderDiagId","d":182530,"h":206158612738,"f":4194344},{"t":1310721,"n":"AppDomainCreateUnloadMessage","d":182530,"h":210453580034,"f":4194344},{"t":1310721,"n":"AppDomainCreateUnloadDiagId","d":182530,"h":214748547330,"f":4194344},{"t":1310721,"n":"SuppressIldasmAttributeMessage","d":182530,"h":219043514626,"f":4194344},{"t":1310721,"n":"SuppressIldasmAttributeDiagId","d":182530,"h":223338481922,"f":4194344},{"t":1310721,"n":"X509CertificateImmutableMessage","d":182530,"h":227633449218,"f":4194344},{"t":1310721,"n":"X509CertificateImmutableDiagId","d":182530,"h":231928416514,"f":4194344},{"t":1310721,"n":"PublicKeyPropertyMessage","d":182530,"h":236223383810,"f":4194344},{"t":1310721,"n":"PublicKeyPropertyDiagId","d":182530,"h":240518351106,"f":4194344},{"t":1310721,"n":"X509CertificatePrivateKeyMessage","d":182530,"h":244813318402,"f":4194344},{"t":1310721,"n":"X509CertificatePrivateKeyDiagId","d":182530,"h":249108285698,"f":4194344},{"t":1310721,"n":"ProduceLegacyHmacValuesMessage","d":182530,"h":253403252994,"f":4194344},{"t":1310721,"n":"ProduceLegacyHmacValuesDiagId","d":182530,"h":257698220290,"f":4194344},{"t":1310721,"n":"UseManagedSha1Message","d":182530,"h":261993187586,"f":4194344},{"t":1310721,"n":"UseManagedSha1DiagId","d":182530,"h":266288154882,"f":4194344},{"t":1310721,"n":"CryptoConfigEncodeOIDMessage","d":182530,"h":270583122178,"f":4194344},{"t":1310721,"n":"CryptoConfigEncodeOIDDiagId","d":182530,"h":274878089474,"f":4194344},{"t":1310721,"n":"CorruptedStateRecoveryMessage","d":182530,"h":279173056770,"f":4194344},{"t":1310721,"n":"CorruptedStateRecoveryDiagId","d":182530,"h":283468024066,"f":4194344},{"t":1310721,"n":"Rfc2898CryptDeriveKeyMessage","d":182530,"h":287762991362,"f":4194344},{"t":1310721,"n":"Rfc2898CryptDeriveKeyDiagId","d":182530,"h":292057958658,"f":4194344},{"t":1310721,"n":"CmsSignerCspParamsCtorMessage","d":182530,"h":296352925954,"f":4194344},{"t":1310721,"n":"CmsSignerCspParamsCtorDiagId","d":182530,"h":300647893250,"f":4194344},{"t":1310721,"n":"SignerInfoCounterSigMessage","d":182530,"h":304942860546,"f":4194344},{"t":1310721,"n":"SignerInfoCounterSigDiagId","d":182530,"h":309237827842,"f":4194344},{"t":1310721,"n":"RegexCompileToAssemblyMessage","d":182530,"h":313532795138,"f":4194344},{"t":1310721,"n":"RegexCompileToAssemblyDiagId","d":182530,"h":317827762434,"f":4194344},{"t":1310721,"n":"AssemblyNameMembersMessage","d":182530,"h":322122729730,"f":4194344},{"t":1310721,"n":"AssemblyNameMembersDiagId","d":182530,"h":326417697026,"f":4194344},{"t":1310721,"n":"SystemDataSerializationFormatBinaryMessage","d":182530,"h":330712664322,"f":4194344},{"t":1310721,"n":"SystemDataSerializationFormatBinaryDiagId","d":182530,"h":335007631618,"f":4194344},{"t":1310721,"n":"TlsVersion10and11Message","d":182530,"h":339302598914,"f":4194344},{"t":1310721,"n":"TlsVersion10and11DiagId","d":182530,"h":343597566210,"f":4194344},{"t":1310721,"n":"EncryptionPolicyMessage","d":182530,"h":347892533506,"f":4194344},{"t":1310721,"n":"EncryptionPolicyDiagId","d":182530,"h":352187500802,"f":4194344},{"t":1310721,"n":"EccXmlExportImportMessage","d":182530,"h":356482468098,"f":4194344},{"t":1310721,"n":"EccXmlExportImportDiagId","d":182530,"h":360777435394,"f":4194344},{"t":1310721,"n":"EcDhPublicKeyBlobMessage","d":182530,"h":365072402690,"f":4194344},{"t":1310721,"n":"EcDhPublicKeyBlobDiagId","d":182530,"h":369367369986,"f":4194344},{"t":1310721,"n":"AssemblyNameCodeBaseMessage","d":182530,"h":373662337282,"f":4194344},{"t":1310721,"n":"AssemblyNameCodeBaseDiagId","d":182530,"h":377957304578,"f":4194344},{"t":1310721,"n":"CryptoStringFactoryMessage","d":182530,"h":382252271874,"f":4194344},{"t":1310721,"n":"CryptoStringFactoryDiagId","d":182530,"h":386547239170,"f":4194344},{"t":1310721,"n":"ControlledExecutionRunMessage","d":182530,"h":390842206466,"f":4194344},{"t":1310721,"n":"ControlledExecutionRunDiagId","d":182530,"h":395137173762,"f":4194344},{"t":1310721,"n":"XmlSecureResolverMessage","d":182530,"h":399432141058,"f":4194344},{"t":1310721,"n":"XmlSecureResolverDiagId","d":182530,"h":403727108354,"f":4194344},{"t":1310721,"n":"RsaEncryptDecryptValueMessage","d":182530,"h":408022075650,"f":4194344},{"t":1310721,"n":"RsaEncryptDecryptDiagId","d":182530,"h":412317042946,"f":4194344},{"t":1310721,"n":"JsonSerializerOptionsAddContextMessage","d":182530,"h":416612010242,"f":4194344},{"t":1310721,"n":"JsonSerializerOptionsAddContextDiagId","d":182530,"h":420906977538,"f":4194344},{"t":1310721,"n":"LegacyFormatterMessage","d":182530,"h":425201944834,"f":4194344},{"t":1310721,"n":"LegacyFormatterDiagId","d":182530,"h":429496912130,"f":4194344},{"t":1310721,"n":"LegacyFormatterImplMessage","d":182530,"h":433791879426,"f":4194344},{"t":1310721,"n":"LegacyFormatterImplDiagId","d":182530,"h":438086846722,"f":4194344},{"t":1310721,"n":"RegexExtensibilityImplMessage","d":182530,"h":442381814018,"f":4194344},{"t":1310721,"n":"RegexExtensibilityDiagId","d":182530,"h":446676781314,"f":4194344},{"t":1310721,"n":"AesGcmTagConstructorMessage","d":182530,"h":450971748610,"f":4194344},{"t":1310721,"n":"AesGcmTagConstructorDiagId","d":182530,"h":455266715906,"f":4194344},{"t":1310721,"n":"ThreadVolatileReadWriteMessage","d":182530,"h":459561683202,"f":4194344},{"t":1310721,"n":"ThreadVolatileReadWriteDiagId","d":182530,"h":463856650498,"f":4194344},{"t":1310721,"n":"ArmIntrinsicPerformsUnsignedOperationMessage","d":182530,"h":468151617794,"f":4194344},{"t":1310721,"n":"ArmIntrinsicPerformsUnsignedOperationDiagId","d":182530,"h":472446585090,"f":4194344},{"t":1310721,"n":"LoadFromHashAlgorithmMessage","d":182530,"h":476741552386,"f":4194344},{"t":1310721,"n":"LoadFromHashAlgorithmDiagId","d":182530,"h":481036519682,"f":4194344},{"t":1310721,"n":"X509CtorCertDataObsoleteMessage","d":182530,"h":485331486978,"f":4194344},{"t":1310721,"n":"X509CtorCertDataObsoleteDiagId","d":182530,"h":489626454274,"f":4194344},{"t":1310721,"n":"TlsCipherAlgorithmEnumsMessage","d":182530,"h":493921421570,"f":4194344},{"t":1310721,"n":"TlsCipherAlgorithmEnumsDiagId","d":182530,"h":498216388866,"f":4194344},{"t":1310721,"n":"SystemEventsEventsThreadShutdownMessage","d":182530,"h":502511356162,"f":4194344},{"t":1310721,"n":"SystemEventsEventsThreadShutdownDiagId","d":182530,"h":506806323458,"f":4194344},{"t":1310721,"n":"Rfc2898DeriveBytesCtorMessage","d":182530,"h":511101290754,"f":4194344},{"t":1310721,"n":"Rfc2898DeriveBytesCtorDiagId","d":182530,"h":515396258050,"f":4194344},{"t":1310721,"n":"QueryableMinByMaxByTSourceObsoleteMessage","d":182530,"h":519691225346,"f":4194344},{"t":1310721,"n":"QueryableMinByMaxByTSourceObsoleteDiagId","d":182530,"h":523986192642,"f":4194344},{"t":1310721,"n":"XsltSettingsEnableScriptMessage","d":182530,"h":528281159938,"f":4194344},{"t":1310721,"n":"XsltSettingsEnableScriptDiagId","d":182530,"h":532576127234,"f":4194344}],"h":182530}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `System.Obsoletions`; }
        });
        
        $asm.$cls("$srsf.System.Collections.HashHelpers", ($self) => class HashHelpers
        {
            /*uint*/ static HashCollisionThreshold = 100;
            /*int*/ static MaxPrimeArrayLength = 2147483587;
            /*int*/ static HashPrime = 101;
            static /*ReadOnlySpan<int> */ get Primes()
            {
                return this.$cachePrimes ??= new ($.$$.System.ReadOnlySpan$$($.$$.System.Int32))().$ctor$4([ 3, 7, 11, 17, 23, 29, 37, 47, 59, 71, 89, 107, 131, 163, 197, 239, 293, 353, 431, 521, 631, 761, 919, 1103, 1327, 1597, 1931, 2333, 2801, 3371, 4049, 4861, 5839, 7013, 8419, 10103, 12143, 14591, 17519, 21023, 25229, 30293, 36353, 43627, 52361, 62851, 75431, 90523, 108631, 130363, 156437, 187751, 225307, 270371, 324449, 389357, 467237, 560689, 672827, 807403, 968897, 1162687, 1395263, 1674319, 2009191, 2411033, 2893249, 3471899, 4166287, 4999559, 5999471, 7199369 ]);
            }
            static /*bool */ IsPrime(/*int*/ candidate)
            {
                if ((candidate & 1) !== 0)
                {
                    /*int*/ let limit = $.$cast(Math.sqrt(candidate), $.$$.System.Int32);
                    for(/*int*/ let divisor = 3; divisor <= limit; divisor += 2)
                    {
                        if ((candidate % divisor) === 0)
                        {
                            return false;
                        }
                    }
                    return true;
                }
                return candidate === 2;
            }
            static /*int */ GetPrime(/*int*/ min)
            {
                if (min < 0)
                {
                    throw new $.$$.System.ArgumentException().$ctor$14($.$srsf.System.SR.Arg_HTCapacityOverflow);
                }
                var $en2 = $.$srsf.System.Collections.HashHelpers.Primes.GetEnumerator();
                while ($en2.MoveNext())
                {
                    var prime = $en2.Current.$v;
                    {
                        if (prime >= min)
                        {
                            return prime;
                        }
                    }
                }
                for(/*int*/ let i = (min | 1); i < 2147483647/*int.MaxValue*/; i += 2)
                {
                    if ($.$srsf.System.Collections.HashHelpers.IsPrime(i) && ((((i - 1) | 0)) % 101/*HashPrime*/ !== 0))
                    {
                        return i;
                    }
                }
                return min;
            }
            static /*int */ ExpandPrime(/*int*/ oldSize)
            {
                /*int*/ let newSize = ((2 * oldSize) | 0);
                if ((newSize >>> 0) > 2147483587/*MaxPrimeArrayLength*/ && 2147483587/*MaxPrimeArrayLength*/ > oldSize)
                {
                    $.$$.System.Diagnostics.Debug.Assert$2(2147483587/*MaxPrimeArrayLength*/ === $.$srsf.System.Collections.HashHelpers.GetPrime(2147483587/*MaxPrimeArrayLength*/), "Invalid MaxPrimeArrayLength");
                    return 2147483587/*MaxPrimeArrayLength*/;
                }
                return $.$srsf.System.Collections.HashHelpers.GetPrime(newSize);
            }
            static /*ulong */ GetFastModMultiplier(/*uint*/ divisor)
            {
                return 18446744073709551615n / BigInt(divisor) + 1n;
            }
            static /*uint */ FastMod(/*uint*/ value, /*uint*/ divisor, /*ulong*/ multiplier)
            {
                $.$$.System.Diagnostics.Debug.Assert$2(divisor <= 2147483647/*int.MaxValue*/, "divisor <= int.MaxValue");
                /*uint*/ let highbits = $.$cast((((((multiplier * BigInt(value)) >> 32n) + 1n) * BigInt(divisor)) >> 32n), $.$$.System.UInt32);
                $.$$.System.Diagnostics.Debug.Assert$2(highbits === value % divisor, "highbits == value % divisor");
                return highbits;
            }
            static $h = 116994;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":$.$$.System.ReadOnlySpan$$($.$$.System.Int32).$h,"g":{"r":0,"d":0,"h":21474953474,"f":50331688},"n":"Primes","d":116994,"h":17179986178,"f":2097192}],"m":[{"r":262145,"p":[{"n":"candidate","p":655361}],"n":"IsPrime","d":116994,"h":25769920770,"f":16777249},{"r":655361,"p":[{"n":"min","p":655361}],"n":"GetPrime","d":116994,"h":30064888066,"f":16777249},{"r":655361,"p":[{"n":"oldSize","p":655361}],"n":"ExpandPrime","d":116994,"h":34359855362,"f":16777249},{"r":983041,"p":[{"n":"divisor","p":720897}],"n":"GetFastModMultiplier","d":116994,"h":38654822658,"f":16777249},{"r":720897,"p":[{"n":"value","p":720897},{"n":"divisor","p":720897},{"n":"multiplier","p":983041}],"n":"FastMod","d":116994,"h":42949789954,"f":16777249}],"l":[{"t":720897,"n":"HashCollisionThreshold","d":116994,"h":4295084290,"f":4194337},{"t":655361,"n":"MaxPrimeArrayLength","d":116994,"h":8590051586,"f":4194337},{"t":655361,"n":"HashPrime","d":116994,"h":12885018882,"f":4194337}],"h":116994}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `System.Collections.HashHelpers`; }
        });
        
        $asm.$cls("$srsf.System.Runtime.Serialization.SerializationObjectManager", ($self) => class SerializationObjectManager extends $.$$.System.Object
        {
            /*string*/ static SerializationObjectManagerUnreferencedCodeMessage = null;
            /*Dictionary<object, object>*/ _objectSeenTable = null;
            /*StreamingContext*/ _context;
            /*SerializationEventHandler?*/ _onSerializedHandler = null;
            $ctor$1(/*StreamingContext*/ context)
            {
                super.$ctor();
                {
                    this._context = context;
                    this._objectSeenTable = new ($.$$.System.Collections.Generic.Dictionary$$$($.$$.System.Object, $.$$.System.Object))().$ctor$1();
                }
                return this;
            }
            /*void */ RegisterObject(/*object*/ obj)
            {
                /*SerializationEvents*/ let cache = $.$srsf.System.Runtime.Serialization.SerializationEventsCache.GetSerializationEventsForType($.$$.System.Object.GetType.call(obj));
                if (cache.HasOnSerializingEvents)
                {
                    if (this._objectSeenTable.TryAdd(obj, $.$box(true, $.$$.System.Boolean)))
                    {
                        cache.InvokeOnSerializing(obj, this._context);
                        this.AddOnSerialized(obj);
                    }
                }
            }
            /*void */ RaiseOnSerializedEvent()
            {
                return (this._onSerializedHandler?.Invoke(this._context) ?? null);
            }
            /*void */ AddOnSerialized(/*object*/ obj)
            {
                /*SerializationEvents*/ let cache = $.$srsf.System.Runtime.Serialization.SerializationEventsCache.GetSerializationEventsForType($.$$.System.Object.GetType.call(obj));
                this._onSerializedHandler = cache.AddOnSerialized(obj, this._onSerializedHandler);
            }
            //default member initializer
            constructor()
            {
                super();
                this._context = $.$default($.$$.System.Runtime.Serialization.StreamingContext);
            }
            //Static Initializer
            static $sinit()
            {
                {
                    this.SerializationObjectManagerUnreferencedCodeMessage = "SerializationObjectManager is not trim compatible because the type of objects being managed cannot be statically discovered.";
                }
            }
            static $h = 2017538;
            static $f = 0b10010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"m":[{"r":65537,"p":[{"n":"obj","p":131073}],"n":"RegisterObject","d":2017538,"h":25771821314,"f":16777217},{"r":65537,"n":"RaiseOnSerializedEvent","d":2017538,"h":30066788610,"f":16777217},{"r":65537,"p":[{"n":"obj","p":131073}],"n":"AddOnSerialized","d":2017538,"h":34361755906,"f":16777218}],"l":[{"t":1310721,"n":"SerializationObjectManagerUnreferencedCodeMessage","d":2017538,"h":4296984834,"f":4194338},{"t":$.$$.System.Collections.Generic.Dictionary$$$($.$$.System.Object, $.$$.System.Object).$h,"n":"_objectSeenTable","d":2017538,"h":8591952130,"f":4194306},{"t":113967105,"n":"_context","d":2017538,"h":12886919426,"f":4194306},{"t":1689858,"n":"_onSerializedHandler","d":2017538,"h":17181886722,"f":4194306}],"c":[{"p":[{"n":"context","p":113967105}],"n":".ctor","o":"$ctor$1","d":2017538,"h":21476854018,"f":16777217}],"h":2017538,"a":[{"t":70909953,"c":8660844545,"a":[{"v":"Formatter-based serialization is obsolete and should not be used.","t":1310721}],"n":[{"n":"DiagnosticId","v":"SYSLIB0050","t":1310721},{"n":"UrlFormat","v":"https://aka.ms/dotnet-warnings/{0}","t":1310721}]}]}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `System.Runtime.Serialization.SerializationObjectManager`; }
        });
        
        $asm.$cls("$srsf.System.Runtime.Serialization.SerializationEvents", ($self) => class SerializationEvents extends $.$$.System.Object
        {
            /*List<MethodInfo>?*/ _onSerializingMethods = null;
            /*List<MethodInfo>?*/ _onSerializedMethods = null;
            /*List<MethodInfo>?*/ _onDeserializingMethods = null;
            /*List<MethodInfo>?*/ _onDeserializedMethods = null;
            $ctor$1(/*Type?*/ t)
            {
                super.$ctor();
                {
                    this._onSerializingMethods = this.GetMethodsWithAttribute($.$$.System.Runtime.Serialization.OnSerializingAttribute.$type, t);
                    this._onSerializedMethods = this.GetMethodsWithAttribute($.$$.System.Runtime.Serialization.OnSerializedAttribute.$type, t);
                    this._onDeserializingMethods = this.GetMethodsWithAttribute($.$$.System.Runtime.Serialization.OnDeserializingAttribute.$type, t);
                    this._onDeserializedMethods = this.GetMethodsWithAttribute($.$$.System.Runtime.Serialization.OnDeserializedAttribute.$type, t);
                }
                return this;
            }
            /*List<MethodInfo>? */ GetMethodsWithAttribute(/*Type*/ attribute, /*Type?*/ t)
            {
                /*List<MethodInfo>?*/ let mi = null;
                /*Type?*/ let baseType = t;
                while($.$$.System.Type.op_Inequality$1(baseType, null) && $.$$.System.Type.op_Inequality$1(baseType, $.$$.System.Object.$type))
                {
                    /*MethodInfo[]*/ let mis = baseType.GetMethods$1(2/*BindingFlags.DeclaredOnly*/ | 4/*BindingFlags.Instance*/ | 32/*BindingFlags.NonPublic*/ | 16/*BindingFlags.Public*/);
                    let $i1 = 0;
                    let $arr1 = mis;
                    while ($i1 < $arr1.length)
                    {
                        let m = $arr1[$i1++];
                        if (m.IsDefined(attribute, false))
                        {
                            mi ??= new ($.$$.System.Collections.Generic.List$$($.$$.System.Reflection.MethodInfo))().$ctor$1();
                            mi.Add(m);
                        }
                    }
                    baseType = baseType.BaseType;
                }
                mi?.Reverse();
                return mi;
            }
            /*bool */ get HasOnSerializingEvents()
            {
                return this._onSerializingMethods !== null || this._onSerializedMethods !== null;
            }
            /*void */ InvokeOnSerializing(/*object*/ obj, /*StreamingContext*/ context)
            {
                return $.$srsf.System.Runtime.Serialization.SerializationEvents.InvokeOnDelegate(obj, context, this._onSerializingMethods);
            }
            /*void */ InvokeOnDeserializing(/*object*/ obj, /*StreamingContext*/ context)
            {
                return $.$srsf.System.Runtime.Serialization.SerializationEvents.InvokeOnDelegate(obj, context, this._onDeserializingMethods);
            }
            /*void */ InvokeOnDeserialized(/*object*/ obj, /*StreamingContext*/ context)
            {
                return $.$srsf.System.Runtime.Serialization.SerializationEvents.InvokeOnDelegate(obj, context, this._onDeserializedMethods);
            }
            /*SerializationEventHandler? */ AddOnSerialized(/*object*/ obj, /*SerializationEventHandler?*/ handler)
            {
                return $.$srsf.System.Runtime.Serialization.SerializationEvents.AddOnDelegate(obj, handler, this._onSerializedMethods);
            }
            /*SerializationEventHandler? */ AddOnDeserialized(/*object*/ obj, /*SerializationEventHandler?*/ handler)
            {
                return $.$srsf.System.Runtime.Serialization.SerializationEvents.AddOnDelegate(obj, handler, this._onDeserializedMethods);
            }
            static /*void */ InvokeOnDelegate(/*object*/ obj, /*StreamingContext*/ context, /*List<MethodInfo>?*/ methods)
            {
                $.$$.System.Diagnostics.Debug.Assert$2(obj !== null, "object should have been initialized");
                $.$srsf.System.Runtime.Serialization.SerializationEvents.AddOnDelegate(obj, null, methods)?.Invoke(context);
            }
            static /*SerializationEventHandler? */ AddOnDelegate(/*object*/ obj, /*SerializationEventHandler?*/ handler, /*List<MethodInfo>?*/ methods)
            {
                if (methods !== null)
                {
                    var $en3 = methods.GetEnumerator();
                    while ($en3.MoveNext())
                    {
                        var m = $en3.Current;
                        {
                            /*SerializationEventHandler*/ let onDeserialized = m.CreateDelegate$3($.$srsf.System.Runtime.Serialization.SerializationEventHandler, obj);
                            handler = $.$cast($.$$.System.Delegate.Combine(handler, onDeserialized), $.$srsf.System.Runtime.Serialization.SerializationEventHandler);
                        }
                    }
                }
                return handler;
            }
            static $h = 1755394;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":262145,"g":{"r":0,"d":0,"h":34361493762,"f":50331656},"n":"HasOnSerializingEvents","d":1755394,"h":30066526466,"f":2097160}],"m":[{"r":$.$$.System.Collections.Generic.List$$($.$$.System.Reflection.MethodInfo).$h,"p":[{"n":"attribute","p":142475265},{"n":"t","p":142475265}],"n":"GetMethodsWithAttribute","d":1755394,"h":25771559170,"f":16777218},{"r":65537,"p":[{"n":"obj","p":131073},{"n":"context","p":113967105}],"n":"InvokeOnSerializing","d":1755394,"h":38656461058,"f":16777224},{"r":65537,"p":[{"n":"obj","p":131073},{"n":"context","p":113967105}],"n":"InvokeOnDeserializing","d":1755394,"h":42951428354,"f":16777224},{"r":65537,"p":[{"n":"obj","p":131073},{"n":"context","p":113967105}],"n":"InvokeOnDeserialized","d":1755394,"h":47246395650,"f":16777224},{"r":1689858,"p":[{"n":"obj","p":131073},{"n":"handler","p":1689858}],"n":"AddOnSerialized","d":1755394,"h":51541362946,"f":16777224},{"r":1689858,"p":[{"n":"obj","p":131073},{"n":"handler","p":1689858}],"n":"AddOnDeserialized","d":1755394,"h":55836330242,"f":16777224},{"r":65537,"p":[{"n":"obj","p":131073},{"n":"context","p":113967105},{"n":"methods","p":$.$$.System.Collections.Generic.List$$($.$$.System.Reflection.MethodInfo).$h}],"n":"InvokeOnDelegate","d":1755394,"h":60131297538,"f":16777250},{"r":1689858,"p":[{"n":"obj","p":131073},{"n":"handler","p":1689858},{"n":"methods","p":$.$$.System.Collections.Generic.List$$($.$$.System.Reflection.MethodInfo).$h}],"n":"AddOnDelegate","d":1755394,"h":64426264834,"f":16777250}],"l":[{"t":$.$$.System.Collections.Generic.List$$($.$$.System.Reflection.MethodInfo).$h,"n":"_onSerializingMethods","d":1755394,"h":4296722690,"f":4194306},{"t":$.$$.System.Collections.Generic.List$$($.$$.System.Reflection.MethodInfo).$h,"n":"_onSerializedMethods","d":1755394,"h":8591689986,"f":4194306},{"t":$.$$.System.Collections.Generic.List$$($.$$.System.Reflection.MethodInfo).$h,"n":"_onDeserializingMethods","d":1755394,"h":12886657282,"f":4194306},{"t":$.$$.System.Collections.Generic.List$$($.$$.System.Reflection.MethodInfo).$h,"n":"_onDeserializedMethods","d":1755394,"h":17181624578,"f":4194306}],"c":[{"p":[{"n":"t","p":142475265}],"n":".ctor","o":"$ctor$1","d":1755394,"h":21476591874,"f":16777224}],"h":1755394}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `System.Runtime.Serialization.SerializationEvents`; }
        });
        
        $asm.$cls("$srsf.System.Runtime.Serialization.FormatterServices", ($self) => class FormatterServices
        {
            /*ConcurrentDictionary<MemberHolder, MemberInfo[]>*/ static s_memberInfoTable = null;
            static /*FieldInfo[] */ InternalGetSerializableMembers(/*Type*/ type)
            {
                $.$$.System.Diagnostics.Debug.Assert$2($.$$.System.Type.op_Inequality$1(type, null), "type != null");
                if (type.IsInterface)
                {
                    return $.$$.System.Array.Empty($.$$.System.Reflection.FieldInfo);
                }
                if (!type.IsSerializable)
                {
                    throw new $.$$.System.Runtime.Serialization.SerializationException().$ctor$12($.$srsf.System.SR.Format$5($.$srsf.System.SR.Serialization_NonSerType, type.FullName, type.Assembly.FullName));
                }
                /*FieldInfo[]*/ let typeMembers = $.$srsf.System.Runtime.Serialization.FormatterServices.GetSerializableFields(type);
                /*Type?*/ let parentType = type.BaseType;
                if ($.$$.System.Type.op_Inequality$1(parentType, null) && $.$$.System.Type.op_Inequality$1(parentType, $.$$.System.Object.$type))
                {
                    /*Type[]?*/ let parentTypes;
                    /*int*/ let parentTypeCount;
                    /*bool*/ let classNamesUnique = $.$srsf.System.Runtime.Serialization.FormatterServices.GetParentTypes(parentType, $.$ref(() => parentTypes, ($v) => parentTypes = $v, $.$typeArray($.$$.System.Type)), $.$ref(() => parentTypeCount, ($v) => parentTypeCount = $v, $.$$.System.Int32));
                    if (parentTypeCount > 0)
                    {
                        /*var*/ let allMembers = new ($.$$.System.Collections.Generic.List$$($.$$.System.Reflection.FieldInfo))().$ctor$1();
                        for(/*int*/ let i = 0; i < parentTypeCount; i++)
                        {
                            parentType = $.$$.System.Array.$ReadT1.call(parentTypes, i);
                            if (!parentType.IsSerializable)
                            {
                                throw new $.$$.System.Runtime.Serialization.SerializationException().$ctor$12($.$srsf.System.SR.Format$5($.$srsf.System.SR.Serialization_NonSerType, parentType.FullName, parentType.Module$1.Assembly.FullName));
                            }
                            /*FieldInfo[]*/ let typeFields = parentType.GetFields$1(32/*BindingFlags.NonPublic*/ | 4/*BindingFlags.Instance*/);
                            /*string*/ let typeName = classNamesUnique ? parentType.Name : parentType.FullName;
                            let $i3 = 0;
                            let $arr3 = typeFields;
                            while ($i3 < $arr3.length)
                            {
                                let field = $arr3[$i3++];
                                if (!field.IsNotSerialized)
                                {
                                    allMembers.Add(new $.$srsf.System.Runtime.Serialization.SerializationFieldInfo().$ctor$4(field, typeName));
                                }
                            }
                        }
                        if (allMembers !== null && allMembers.Count > 0)
                        {
                            /*var*/ let membersTemp = $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$$.System.Reflection.FieldInfo), null, [((allMembers.Count + typeMembers.length) | 0)], null);
                            $.$$.System.Array.Copy(typeMembers, membersTemp, typeMembers.length);
                            allMembers.CopyTo(membersTemp, typeMembers.length);
                            typeMembers = membersTemp;
                        }
                    }
                }
                return typeMembers;
            }
            static /*FieldInfo[] */ GetSerializableFields(/*Type*/ type)
            {
                /*FieldInfo[]*/ let fields = type.GetFields$1(16/*BindingFlags.Public*/ | 32/*BindingFlags.NonPublic*/ | 4/*BindingFlags.Instance*/);
                /*int*/ let countProper = 0;
                for(/*int*/ let i = 0; i < fields.length; i++)
                {
                    if (($.$$.System.Array.$ReadT1.call(fields, i).Attributes & 128/*FieldAttributes.NotSerialized*/) === 128/*FieldAttributes.NotSerialized*/)
                    {
                        continue;
                    }
                    countProper++;
                }
                if (countProper !== fields.length)
                {
                    /*var*/ let properFields = $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$$.System.Reflection.FieldInfo), null, [countProper], null);
                    countProper = 0;
                    for(/*int*/ let i = 0; i < fields.length; i++)
                    {
                        if (($.$$.System.Array.$ReadT1.call(fields, i).Attributes & 128/*FieldAttributes.NotSerialized*/) === 128/*FieldAttributes.NotSerialized*/)
                        {
                            continue;
                        }
                        $.$$.System.Array.$WriteT1.call(properFields, $.$$.System.Array.$ReadT1.call(fields, i), countProper);
                        countProper++;
                    }
                    return properFields;
                }
                else 
                {
                    return fields;
                }
            }
            static /*bool */ GetParentTypes(/*Type*/ parentType, /*out Type[]?*/ parentTypes, /*out int*/ parentTypeCount)
            {
                parentTypes.$v = null;
                parentTypeCount.$v = 0;
                /*bool*/ let unique = true;
                /*Type*/ let objectType = $.$$.System.Object.$type;
                for(/*Type*/ let t1 = parentType; $.$$.System.Type.op_Inequality$1(t1, objectType); t1 = t1.BaseType)
                {
                    if (t1.IsInterface)
                    {
                        continue;
                    }
                    /*string*/ let t1Name = t1.Name;
                    for(/*int*/ let i = 0; unique && i < parentTypeCount.$v; i++)
                    {
                        /*string*/ let t2Name = $.$$.System.Array.$ReadT1.call(parentTypes.$v, i).Name;
                        if (t2Name.length === t1Name.length && $.$$.System.String.get_Chars.call(t2Name, 0) === $.$$.System.String.get_Chars.call(t1Name, 0) && $.$$.System.String.op_Equality(t1Name, t2Name))
                        {
                            unique = false;
                            break;
                        }
                    }
                    if (parentTypes.$v === null || parentTypeCount.$v === parentTypes.$v.length)
                    {
                        $.$$.System.Array.Resize($.$$.System.Type, parentTypes, $.$$.System.Math.Max$4(((parentTypeCount.$v * 2) | 0), 12));
                    }
                    $.$$.System.Array.$WriteT1.call(parentTypes.$v, t1, parentTypeCount.$v++);
                }
                return unique;
            }
            static /*MemberInfo[] */ GetSerializableMembers$1(/*Type*/ type)
            {
                return $.$srsf.System.Runtime.Serialization.FormatterServices.GetSerializableMembers(type, new $.$$.System.Runtime.Serialization.StreamingContext().$ctor$4(255/*StreamingContextStates.All*/));
            }
            static /*MemberInfo[] */ GetSerializableMembers(/*Type*/ type, /*StreamingContext*/ context)
            {
                $.$$.System.ArgumentNullException.ThrowIfNull$2(type, "type");
                return $.$srsf.System.Runtime.Serialization.FormatterServices.s_memberInfoTable.GetOrAdd(new $.$srsf.System.Runtime.Serialization.MemberHolder().$ctor$1(type, context), new ($.$$.System.Func$$$($.$srsf.System.Runtime.Serialization.MemberHolder, $.$typeArray($.$$.System.Reflection.MemberInfo)))().$ctor(this,  (/*mh*/ mh) =>
                {
                    return $.$srsf.System.Runtime.Serialization.FormatterServices.InternalGetSerializableMembers(mh._memberType);
                }, {"r":$.$typeArray($.$$.System.Reflection.MemberInfo).$h,"p":[{"n":"mh","p":1231106}],"n":"","d":903426,"h":0,"f":17825794}));
            }
            static /*void */ CheckTypeSecurity(/*Type*/ t, /*TypeFilterLevel*/ securityLevel)
            {
            }
            static /*object */ GetUninitializedObject(/*Type*/ type)
            {
                return $.$$.System.Runtime.CompilerServices.RuntimeHelpers.GetUninitializedObject(type);
            }
            static /*object */ GetSafeUninitializedObject(/*Type*/ type)
            {
                return $.$$.System.Runtime.CompilerServices.RuntimeHelpers.GetUninitializedObject(type);
            }
            static /*void */ SerializationSetValue(/*MemberInfo*/ fi, /*object?*/ target, /*object?*/ value)
            {
                $.$$.System.Diagnostics.Debug.Assert$2($.$$.System.Reflection.MemberInfo.op_Inequality(fi, null), "fi != null");
                let serField;
                if ($.$is(fi, $.$$.System.Reflection.FieldInfo, { set $v(v){ serField = v; } }))
                {
                    serField.SetValue$1(target, value);
                    return;
                }
                throw new $.$$.System.ArgumentException().$ctor$14($.$srsf.System.SR.Argument_InvalidFieldInfo);
            }
            static /*object */ PopulateObjectMembers(/*object*/ obj, /*MemberInfo[]*/ members, /*object?[]*/ data)
            {
                $.$$.System.ArgumentNullException.ThrowIfNull$2(obj, "obj");
                $.$$.System.ArgumentNullException.ThrowIfNull$2(members, "members");
                $.$$.System.ArgumentNullException.ThrowIfNull$2(data, "data");
                if (members.length !== data.length)
                {
                    throw new $.$$.System.ArgumentException().$ctor$14($.$srsf.System.SR.Argument_DataLengthDifferent);
                }
                for(/*int*/ let i = 0; i < members.length; i++)
                {
                    /*MemberInfo*/ let member = $.$$.System.Array.$ReadT1.call(members, i);
                    if ($.$$.System.Reflection.MemberInfo.op_Equality(member, null))
                    {
                        throw new $.$$.System.ArgumentNullException().$ctor$18("members", $.$srsf.System.SR.Format$6($.$srsf.System.SR.ArgumentNull_NullMember, $.$box(i, $.$$.System.Int32)));
                    }
                    /*object?*/ let value = $.$$.System.Array.$ReadT1.call(data, i);
                    if (value === null)
                    {
                        continue;
                    }
                    let field;
                    if ($.$is(member, $.$$.System.Reflection.FieldInfo, { set $v(v){ field = v; } }))
                    {
                        field.SetValue$1(obj, $.$$.System.Array.$ReadT1.call(data, i));
                        continue;
                    }
                    throw new $.$$.System.Runtime.Serialization.SerializationException().$ctor$12($.$srsf.System.SR.Serialization_UnknownMemberInfo);
                }
                return obj;
            }
            static /*object?[] */ GetObjectData(/*object*/ obj, /*MemberInfo[]*/ members)
            {
                $.$$.System.ArgumentNullException.ThrowIfNull$2(obj, "obj");
                $.$$.System.ArgumentNullException.ThrowIfNull$2(members, "members");
                /*object?[]*/ let data = $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$$.System.Object), null, [members.length], null);
                for(/*int*/ let i = 0; i < members.length; i++)
                {
                    /*MemberInfo*/ let member = $.$$.System.Array.$ReadT1.call(members, i);
                    if ($.$$.System.Reflection.MemberInfo.op_Equality(member, null))
                    {
                        throw new $.$$.System.ArgumentNullException().$ctor$18("members", $.$srsf.System.SR.Format$6($.$srsf.System.SR.ArgumentNull_NullMember, $.$box(i, $.$$.System.Int32)));
                    }
                    /*FieldInfo?*/ let field = $.$as(member, $.$$.System.Reflection.FieldInfo);
                    if ($.$$.System.Reflection.FieldInfo.op_Equality$1(field, null))
                    {
                        throw new $.$$.System.Runtime.Serialization.SerializationException().$ctor$12($.$srsf.System.SR.Serialization_UnknownMemberInfo);
                    }
                    $.$$.System.Array.$WriteT1.call(data, field.GetValue(obj), i);
                }
                return data;
            }
            static /*ISerializationSurrogate */ GetSurrogateForCyclicalReference(/*ISerializationSurrogate*/ innerSurrogate)
            {
                $.$$.System.ArgumentNullException.ThrowIfNull$2(innerSurrogate, "innerSurrogate");
                return new $.$srsf.System.Runtime.Serialization.SurrogateForCyclicalReference().$ctor$1(innerSurrogate);
            }
            static /*Type? */ GetTypeFromAssembly(/*Assembly*/ assem, /*string*/ name)
            {
                $.$$.System.ArgumentNullException.ThrowIfNull$2(assem, "assem");
                return assem.GetType$1(name, false, false);
            }
            static /*Assembly */ LoadAssemblyFromString(/*string*/ assemblyName)
            {
                return $.$$.System.Reflection.Assembly.Load$3(new $.$$.System.Reflection.AssemblyName().$ctor$2(assemblyName));
            }
            static /*Assembly? */ LoadAssemblyFromStringNoThrow(/*string*/ assemblyName)
            {
                try
                {
                    return $.$srsf.System.Runtime.Serialization.FormatterServices.LoadAssemblyFromString(assemblyName);
                }
                catch($e)
                {
                }
                return null;
            }
            static /*string */ GetClrAssemblyName(/*Type*/ type, /*out bool*/ hasTypeForwardedFrom)
            {
                $.$$.System.ArgumentNullException.ThrowIfNull$2(type, "type");
                /*Type*/ let attributedType = type;
                while(attributedType.HasElementType)
                {
                    attributedType = attributedType.GetElementType();
                }
                let $i1 = 0;
                let $arr1 = attributedType.GetCustomAttributes$1($.$$.System.Runtime.CompilerServices.TypeForwardedFromAttribute.$type, false);
                while ($i1 < $arr1.length)
                {
                    let first = $arr1[$i1++];
                    hasTypeForwardedFrom.$v = true;
                    return ($.$cast(first, $.$$.System.Runtime.CompilerServices.TypeForwardedFromAttribute)).AssemblyFullName;
                }
                hasTypeForwardedFrom.$v = false;
                return type.Assembly.FullName;
            }
            static /*string */ GetClrTypeFullName(/*Type*/ type)
            {
                return type.IsArray ? $.$srsf.System.Runtime.Serialization.FormatterServices.GetClrTypeFullNameForArray(type) : $.$srsf.System.Runtime.Serialization.FormatterServices.GetClrTypeFullNameForNonArrayTypes(type);
            }
            static /*string */ GetClrTypeFullNameForArray(/*Type*/ type)
            {
                /*int*/ let rank = type.GetArrayRank();
                $.$$.System.Diagnostics.Debug.Assert$2(rank >= 1, "rank >= 1");
                /*string*/ let typeName = $.$srsf.System.Runtime.Serialization.FormatterServices.GetClrTypeFullName(type.GetElementType());
                return rank === 1 ? typeName + "[]" : typeName + "[" + $.$$.System.String.Create(/*,*/ 44, ((rank - 1) | 0)) + "]";
            }
            static /*string */ GetClrTypeFullNameForNonArrayTypes(/*Type*/ type)
            {
                if (!type.IsGenericType)
                {
                    return type.FullName;
                }
                /*var*/ let builder = new $.$$.System.Text.StringBuilder().$ctor$8(type.GetGenericTypeDefinition().FullName).Append$3(/*[*/ 91);
                /*bool*/ let hasTypeForwardedFrom;
                let $i1 = 0;
                let $arr1 = type.GetGenericArguments();
                while ($i1 < $arr1.length)
                {
                    let genericArgument = $arr1[$i1++];
                    builder.Append$3(/*[*/ 91).Append$19($.$srsf.System.Runtime.Serialization.FormatterServices.GetClrTypeFullName(genericArgument)).Append$19(", ");
                    builder.Append$19($.$srsf.System.Runtime.Serialization.FormatterServices.GetClrAssemblyName(genericArgument, $.$ref(() => hasTypeForwardedFrom, ($v) => hasTypeForwardedFrom = $v, $.$$.System.Boolean))).Append$19("],");
                }
                return $.$$.System.Text.StringBuilder.ToString.call(builder.Remove$1(((builder.Length - 1) | 0), 1).Append$3(/*]*/ 93));
            }
            //Static Initializer
            static $sinit()
            {
                {
                    this.s_memberInfoTable = new ($.$scc.System.Collections.Concurrent.ConcurrentDictionary$$$($.$srsf.System.Runtime.Serialization.MemberHolder, $.$typeArray($.$$.System.Reflection.MemberInfo)))().$ctor$1();
                }
            }
            static $h = 903426;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"m":[{"r":$.$typeArray($.$$.System.Reflection.FieldInfo).$h,"p":[{"n":"type","p":142475265}],"n":"InternalGetSerializableMembers","d":903426,"h":8590838018,"f":16777250},{"r":$.$typeArray($.$$.System.Reflection.FieldInfo).$h,"p":[{"n":"type","p":142475265}],"n":"GetSerializableFields","d":903426,"h":12885805314,"f":16777250},{"r":262145,"p":[{"n":"parentType","p":142475265},{"n":"parentTypes","p":$.$typeArray($.$$.System.Type).$h,"f":2},{"n":"parentTypeCount","p":655361,"f":2}],"n":"GetParentTypes","d":903426,"h":17180772610,"f":16777250},{"r":$.$typeArray($.$$.System.Reflection.MemberInfo).$h,"p":[{"n":"type","p":142475265}],"n":"GetSerializableMembers","o":"@$1","d":903426,"h":21475739906,"f":16777249},{"r":$.$typeArray($.$$.System.Reflection.MemberInfo).$h,"p":[{"n":"type","p":142475265},{"n":"context","p":113967105}],"n":"GetSerializableMembers","d":903426,"h":25770707202,"f":16777249},{"r":65537,"p":[{"n":"t","p":142475265},{"n":"securityLevel","p":837890}],"n":"CheckTypeSecurity","d":903426,"h":30065674498,"f":16777249},{"r":131073,"p":[{"n":"type","p":142475265}],"n":"GetUninitializedObject","d":903426,"h":34360641794,"f":16777249},{"r":131073,"p":[{"n":"type","p":142475265}],"n":"GetSafeUninitializedObject","d":903426,"h":38655609090,"f":16777249},{"r":65537,"p":[{"n":"fi","p":78249985},{"n":"target","p":131073},{"n":"value","p":131073}],"n":"SerializationSetValue","d":903426,"h":42950576386,"f":16777256},{"r":131073,"p":[{"n":"obj","p":131073},{"n":"members","p":$.$typeArray($.$$.System.Reflection.MemberInfo).$h},{"n":"data","p":$.$typeArray($.$$.System.Object).$h}],"n":"PopulateObjectMembers","d":903426,"h":47245543682,"f":16777249},{"r":$.$typeArray($.$$.System.Object).$h,"p":[{"n":"obj","p":131073},{"n":"members","p":$.$typeArray($.$$.System.Reflection.MemberInfo).$h}],"n":"GetObjectData","d":903426,"h":51540510978,"f":16777249},{"r":1034498,"p":[{"n":"innerSurrogate","p":1034498}],"n":"GetSurrogateForCyclicalReference","d":903426,"h":55835478274,"f":16777249},{"r":142475265,"p":[{"n":"assem","p":73465857},{"n":"name","p":1310721}],"n":"GetTypeFromAssembly","d":903426,"h":60130445570,"f":16777249},{"r":73465857,"p":[{"n":"assemblyName","p":1310721}],"n":"LoadAssemblyFromString","d":903426,"h":64425412866,"f":16777256},{"r":73465857,"p":[{"n":"assemblyName","p":1310721}],"n":"LoadAssemblyFromStringNoThrow","d":903426,"h":68720380162,"f":16777256},{"r":1310721,"p":[{"n":"type","p":142475265},{"n":"hasTypeForwardedFrom","p":262145,"f":2}],"n":"GetClrAssemblyName","d":903426,"h":73015347458,"f":16777256},{"r":1310721,"p":[{"n":"type","p":142475265}],"n":"GetClrTypeFullName","d":903426,"h":77310314754,"f":16777256},{"r":1310721,"p":[{"n":"type","p":142475265}],"n":"GetClrTypeFullNameForArray","d":903426,"h":81605282050,"f":16777250},{"r":1310721,"p":[{"n":"type","p":142475265}],"n":"GetClrTypeFullNameForNonArrayTypes","d":903426,"h":85900249346,"f":16777250}],"l":[{"t":$.$scc.System.Collections.Concurrent.ConcurrentDictionary$$$($.$srsf.System.Runtime.Serialization.MemberHolder, $.$typeArray($.$$.System.Reflection.MemberInfo)).$h,"n":"s_memberInfoTable","d":903426,"h":4295870722,"f":4194338}],"h":903426,"a":[{"t":70909953,"c":8660844545,"a":[{"v":"Formatter-based serialization is obsolete and should not be used.","t":1310721}],"n":[{"n":"DiagnosticId","v":"SYSLIB0050","t":1310721},{"n":"UrlFormat","v":"https://aka.ms/dotnet-warnings/{0}","t":1310721}]}]}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `System.Runtime.Serialization.FormatterServices`; }
        });
        
        $asm.$cls("$srsf.System.Runtime.Serialization.ObjectManager", ($self) => class ObjectManager extends $.$$.System.Object
        {
            /*int*/ static DefaultInitialSize = 16;
            /*int*/ static MaxArraySize = 1048576;
            /*int*/ static ArrayMask = 1048575;
            /*int*/ static MaxReferenceDepth = 100;
            /*string*/ static ObjectManagerUnreferencedCodeMessage = null;
            /*FieldInfo*/ static s_nullableValueField = null;
            /*DeserializationEventHandler?*/ _onDeserializationHandler = null;
            /*SerializationEventHandler?*/ _onDeserializedHandler = null;
            /*ObjectHolder[]*/ _objects = null;
            /*object?*/ _topObject = null;
            /*ObjectHolderList?*/ _specialFixupObjects = null;
            /*long*/ _fixupCount = 0n;
            /*ISurrogateSelector?*/ _selector = null;
            /*StreamingContext*/ _context;
            $ctor$1(/*ISurrogateSelector?*/ selector, /*StreamingContext*/ context)
            {
                super.$ctor();
                {
                    this._objects = $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$srsf.System.Runtime.Serialization.ObjectHolder), null, [16/*DefaultInitialSize*/], null);
                    this._selector = selector;
                    this._context = context;
                }
                return this;
            }
            /*bool */ CanCallGetType(/*object?*/ obj)
            {
                return true;
            }
            /*object? */ get TopObject()
            {
                return this._topObject;
            }
            /*object? */ set TopObject(value)
            {
                this._topObject = value;
            }
            /*ObjectHolderList */ get SpecialFixupObjects()
            {
                return this._specialFixupObjects ??= new $.$srsf.System.Runtime.Serialization.ObjectHolderList().$ctor$1();
            }
            /*ObjectHolder? */ FindObjectHolder(/*long*/ objectID)
            {
                /*int*/ let index = $.$cast((objectID & BigInt(1048575/*ArrayMask*/)), $.$$.System.Int32);
                if (index >= this._objects.length)
                {
                    return null;
                }
                /*ObjectHolder?*/ let temp = $.$$.System.Array.$ReadT1.call(this._objects, index);
                while(temp !== null)
                {
                    if (temp._id === objectID)
                    {
                        return temp;
                    }
                    temp = temp._next;
                }
                return temp;
            }
            /*ObjectHolder */ FindOrCreateObjectHolder(/*long*/ objectID)
            {
                /*ObjectHolder?*/ let holder = this.FindObjectHolder(objectID);
                if (holder === null)
                {
                    holder = new $.$srsf.System.Runtime.Serialization.ObjectHolder().$ctor$1(objectID);
                    this.AddObjectHolder(holder);
                }
                return holder;
            }
            /*void */ AddObjectHolder(/*ObjectHolder*/ holder)
            {
                $.$$.System.Diagnostics.Debug.Assert$2(holder !== null, "holder!=null");
                $.$$.System.Diagnostics.Debug.Assert$2(holder._id >= 0n, "holder.m_id>=0");
                if (holder._id >= BigInt(this._objects.length) && this._objects.length !== 1048576/*MaxArraySize*/)
                {
                    /*int*/ let newSize = 1048576/*MaxArraySize*/;
                    if (holder._id < (BigInt($.trunc(1048576/*MaxArraySize*/ / 2))))
                    {
                        newSize = (((this._objects.length * 2) | 0));
                        while(BigInt(newSize) <= holder._id && newSize < 1048576/*MaxArraySize*/)
                        {
                            newSize *= 2;
                        }
                        if (newSize > 1048576/*MaxArraySize*/)
                        {
                            newSize = 1048576/*MaxArraySize*/;
                        }
                    }
                    /*ObjectHolder[]*/ let temp = $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$srsf.System.Runtime.Serialization.ObjectHolder), null, [newSize], null);
                    $.$$.System.Array.Copy(this._objects, temp, this._objects.length);
                    this._objects = temp;
                }
                /*int*/ let index = $.$cast((holder._id & BigInt(1048575/*ArrayMask*/)), $.$$.System.Int32);
                /*ObjectHolder*/ let tempHolder = $.$$.System.Array.$ReadT1.call(this._objects, index);
                holder._next = tempHolder;
                $.$$.System.Array.$WriteT1.call(this._objects, holder, index);
            }
            /*bool */ GetCompletionInfo(/*FixupHolder*/ fixup, /*out ObjectHolder?*/ holder, /*out object*/ member, /*bool*/ bThrowIfMissing)
            {
                member.$v = fixup._fixupInfo;
                holder.$v = this.FindObjectHolder(fixup._id);
                if (holder.$v === null || holder.$v.CanObjectValueChange || holder.$v.ObjectValue === null)
                {
                    if (bThrowIfMissing)
                    {
                        if (holder.$v === null)
                        {
                            throw new $.$$.System.Runtime.Serialization.SerializationException().$ctor$12($.$srsf.System.SR.Format$6($.$srsf.System.SR.Serialization_NeverSeen, $.$box(fixup._id, $.$$.System.Int64)));
                        }
                        if (holder.$v.IsIncompleteObjectReference)
                        {
                            throw new $.$$.System.Runtime.Serialization.SerializationException().$ctor$12($.$srsf.System.SR.Format$6($.$srsf.System.SR.Serialization_IORIncomplete, $.$box(fixup._id, $.$$.System.Int64)));
                        }
                        throw new $.$$.System.Runtime.Serialization.SerializationException().$ctor$12($.$srsf.System.SR.Format$6($.$srsf.System.SR.Serialization_ObjectNotSupplied, $.$box(fixup._id, $.$$.System.Int64)));
                    }
                    return false;
                }
                if (!holder.$v.CompletelyFixed)
                {
                    if (holder.$v.ObjectValue !== null && $.$is(holder.$v.ObjectValue, $.$$.System.ValueType))
                    {
                        this.SpecialFixupObjects.Add(holder.$v);
                        return false;
                    }
                }
                return true;
            }
            /*void */ FixupSpecialObject(/*ObjectHolder*/ holder)
            {
                /*ISurrogateSelector?*/ let uselessSelector = null;
                $.$$.System.Diagnostics.Debug.Assert$2(holder.RequiresSerInfoFixup, "[ObjectManager.FixupSpecialObject]holder.HasSurrogate||holder.HasISerializable");
                if (holder.HasSurrogate)
                {
                    /*ISerializationSurrogate?*/ let surrogate = holder.Surrogate;
                    $.$$.System.Diagnostics.Debug.Assert$2(surrogate !== null, "surrogate!=null");
                    $.$$.System.Diagnostics.Debug.Assert$2(holder.SerializationInfo !== null, "holder.SerializationInfo != null");
                    /*object?*/ let returnValue = surrogate.System$Runtime$Serialization$ISerializationSurrogate$SetObjectData(holder.ObjectValue, holder.SerializationInfo, this._context, uselessSelector);
                    if (returnValue !== null)
                    {
                        if (!holder.CanSurrogatedObjectValueChange && returnValue !== holder.ObjectValue)
                        {
                            throw new $.$$.System.Runtime.Serialization.SerializationException().$ctor$12($.$srsf.System.SR.Format$6($.$srsf.System.SR.Serialization_NotCyclicallyReferenceableSurrogate, $.$$.System.Object.GetType.call(surrogate).FullName));
                        }
                        holder.SetObjectValue(returnValue, this);
                    }
                    holder._surrogate = null;
                    holder.SetFlags();
                }
                else 
                {
                    $.$$.System.Diagnostics.Debug.Assert$2($.$is(holder.ObjectValue, $.$$.System.Runtime.Serialization.ISerializable), "holder.m_object is ISerializable");
                    this.CompleteISerializableObject(holder.ObjectValue, holder.SerializationInfo, this._context);
                }
                holder.SerializationInfo = null;
                holder.RequiresSerInfoFixup = false;
                if (holder.RequiresValueTypeFixup && holder.ValueTypeFixupPerformed)
                {
                    this.DoValueTypeFixup(null, holder, holder.ObjectValue);
                }
                this.DoNewlyRegisteredObjectFixups(holder);
            }
            /*bool */ ResolveObjectReference(/*ObjectHolder*/ holder)
            {
                /*object?*/ let tempObject;
                $.$$.System.Diagnostics.Debug.Assert$2(holder.IsIncompleteObjectReference, "holder.IsIncompleteObjectReference");
                /*int*/ let depthCount = 0;
                try
                {
                    do
                    {
                        tempObject = holder.ObjectValue;
                        $.$$.System.Diagnostics.Debug.Assert$2(holder.ObjectValue !== null, "holder.ObjectValue != null");
                        holder.SetObjectValue(($.$cast((holder.ObjectValue), $.$$.System.Runtime.Serialization.IObjectReference)).System$Runtime$Serialization$IObjectReference$GetRealObject(this._context), this);
                        if (holder.ObjectValue === null)
                        {
                            holder.SetObjectValue(tempObject, this);
                            return false;
                        }
                        if (depthCount++ === 100/*MaxReferenceDepth*/)
                        {
                            throw new $.$$.System.Runtime.Serialization.SerializationException().$ctor$12($.$srsf.System.SR.Serialization_TooManyReferences);
                        }
                    }
                    while(($.$is(holder.ObjectValue, $.$$.System.Runtime.Serialization.IObjectReference)) && (tempObject !== holder.ObjectValue));
                }
                catch($e)
                {
                    return false;
                }
                holder.IsIncompleteObjectReference = false;
                this.DoNewlyRegisteredObjectFixups(holder);
                return true;
            }
            /*bool */ DoValueTypeFixup(/*FieldInfo?*/ memberToFix, /*ObjectHolder*/ holder, /*object?*/ value)
            {
                /*var*/ let fieldsTemp = $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$$.System.Reflection.FieldInfo), null, [4], null);
                /*FieldInfo[]*/ let fields;
                /*int*/ let currentFieldIndex = 0;
                /*int[]?*/ let arrayIndex = null;
                /*ValueTypeFixupInfo*/ let currFixup;
                /*object?*/ let fixupObj = holder.ObjectValue;
                $.$$.System.Diagnostics.Debug.Assert$2(holder !== null, "[TypedReferenceBuilder.ctor]holder!=null");
                $.$$.System.Diagnostics.Debug.Assert$2(holder.RequiresValueTypeFixup, "[TypedReferenceBuilder.ctor]holder.RequiresValueTypeFixup");
                while(holder.RequiresValueTypeFixup)
                {
                    if ((((currentFieldIndex + 1) | 0)) >= fieldsTemp.length)
                    {
                        /*var*/ let temp = $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$$.System.Reflection.FieldInfo), null, [((fieldsTemp.length * 2) | 0)], null);
                        $.$$.System.Array.Copy(fieldsTemp, temp, fieldsTemp.length);
                        fieldsTemp = temp;
                    }
                    currFixup = holder.ValueFixup;
                    fixupObj = holder.ObjectValue;
                    if ($.$$.System.Reflection.FieldInfo.op_Inequality$1(currFixup.ParentField, null))
                    {
                        /*FieldInfo*/ let parentField = currFixup.ParentField;
                        /*ObjectHolder?*/ let tempHolder = this.FindObjectHolder(currFixup.ContainerID);
                        $.$$.System.Diagnostics.Debug.Assert$2(tempHolder !== null, "tempHolder != null");
                        if (tempHolder.ObjectValue === null)
                        {
                            break;
                        }
                        /*FieldInfo?*/ let nullableValueField = $.$srsf.System.Runtime.Serialization.ObjectManager.GetNullableValueField(parentField.FieldType);
                        if ($.$$.System.Reflection.FieldInfo.op_Inequality$1(nullableValueField, null))
                        {
                            $.$$.System.Array.$WriteT1.call(fieldsTemp, nullableValueField, currentFieldIndex);
                            currentFieldIndex++;
                        }
                        $.$$.System.Array.$WriteT1.call(fieldsTemp, parentField, currentFieldIndex);
                        holder = tempHolder;
                        currentFieldIndex++;
                    }
                    else 
                    {
                        $.$$.System.Diagnostics.Debug.Assert$2(currFixup.ParentIndex !== null, "[ObjectManager.DoValueTypeFixup]currFixup.ParentIndex!=null");
                        holder = this.FindObjectHolder(currFixup.ContainerID);
                        arrayIndex = currFixup.ParentIndex;
                        break;
                    }
                }
                if (!($.$is(holder.ObjectValue, $.$$.System.Array)) && holder.ObjectValue !== null)
                {
                    fixupObj = holder.ObjectValue;
                    $.$$.System.Diagnostics.Debug.Assert$2(fixupObj !== null, "[ObjectManager.DoValueTypeFixup]FixupObj!=null");
                }
                if (currentFieldIndex !== 0)
                {
                    fields = $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$$.System.Reflection.FieldInfo), null, [currentFieldIndex], null);
                    for(/*int*/ let i = 0; i < currentFieldIndex; i++)
                    {
                        /*FieldInfo?*/ let fieldInfo = $.$$.System.Array.$ReadT1.call(fieldsTemp, (((((currentFieldIndex - 1) | 0) - i) | 0)));
                        /*SerializationFieldInfo?*/ let serInfo = $.$as(fieldInfo, $.$srsf.System.Runtime.Serialization.SerializationFieldInfo);
                        $.$$.System.Array.$WriteT1.call(fields, serInfo === null ? fieldInfo : serInfo.FieldInfo, i);
                    }
                    $.$$.System.Diagnostics.Debug.Assert$2(fixupObj !== null, "[ObjectManager.DoValueTypeFixup]fixupObj!=null");
                    /*TypedReference*/ let typedRef = $.$$.System.TypedReference.MakeTypedReference(fixupObj, fields);
                    if ($.$$.System.Reflection.FieldInfo.op_Inequality$1(memberToFix, null))
                    {
                        memberToFix.SetValueDirect(typedRef, value);
                    }
                    else 
                    {
                        $.$$.System.TypedReference.SetTypedReference(typedRef, value);
                    }
                }
                else if ($.$$.System.Reflection.FieldInfo.op_Inequality$1(memberToFix, null))
                {
                    $.$srsf.System.Runtime.Serialization.FormatterServices.SerializationSetValue(memberToFix, fixupObj, value);
                }
                if (arrayIndex !== null && holder.ObjectValue !== null)
                {
                    ($.$cast((holder.ObjectValue), $.$$.System.Array)).SetValue$3(fixupObj, arrayIndex);
                }
                return true;
            }
            static /*FieldInfo? */ GetNullableValueField(/*Type*/ type)
            {
                if ($.$$.System.Type.op_Inequality$1($.$$.System.Nullable.GetUnderlyingType(type), null))
                {
                    return $.$cast(type.GetMemberWithSameMetadataDefinitionAs($.$srsf.System.Runtime.Serialization.ObjectManager.s_nullableValueField), $.$$.System.Reflection.FieldInfo);
                }
                return null;
            }
            /*void */ CompleteObject(/*ObjectHolder*/ holder, /*bool*/ bObjectFullyComplete)
            {
                /*FixupHolderList?*/ let fixups = holder._missingElements;
                /*FixupHolder?*/ let currentFixup;
                /*SerializationInfo?*/ let si;
                /*object?*/ let fixupInfo;
                /*ObjectHolder?*/ let tempObjectHolder;
                /*int*/ let fixupsPerformed = 0;
                $.$$.System.Diagnostics.Debug.Assert$2(holder !== null, "[ObjectManager.CompleteObject]holder.m_object!=null");
                if (holder.ObjectValue === null)
                {
                    throw new $.$$.System.Runtime.Serialization.SerializationException().$ctor$12($.$srsf.System.SR.Format$6($.$srsf.System.SR.Serialization_MissingObject, $.$box(holder._id, $.$$.System.Int64)));
                }
                if (fixups === null)
                {
                    return;
                }
                if (holder.HasSurrogate || holder.HasISerializable)
                {
                    si = holder._serInfo;
                    if (si === null)
                    {
                        throw new $.$$.System.Runtime.Serialization.SerializationException().$ctor$12($.$srsf.System.SR.Serialization_InvalidFixupDiscovered);
                    }
                    if (fixups !== null)
                    {
                        for(/*int*/ let i = 0; i < fixups._count; i++)
                        {
                            if ($.$$.System.Array.$ReadT1.call(fixups._values, i) === null)
                            {
                                continue;
                            }
                            $.$$.System.Diagnostics.Debug.Assert$2($.$$.System.Array.$ReadT1.call(fixups._values, i)._fixupType === 4/*FixupHolder.DelayedFixup*/, "fixups.m_values[i].m_fixupType==FixupHolder.DelayedFixup");
                            if (this.GetCompletionInfo($.$$.System.Array.$ReadT1.call(fixups._values, i), $.$ref(() => tempObjectHolder, ($v) => tempObjectHolder = $v, $.$srsf.System.Runtime.Serialization.ObjectHolder), $.$ref(() => fixupInfo, ($v) => fixupInfo = $v, $.$$.System.Object), bObjectFullyComplete))
                            {
                                /*object?*/ let holderValue = tempObjectHolder.ObjectValue;
                                $.$$.System.Diagnostics.Debug.Assert$2(holderValue !== null, "holderValue != null");
                                if (this.CanCallGetType(holderValue))
                                {
                                    $.$srsf.System.Runtime.Serialization.SerializationInfoExtensions.UpdateValue(si, $.$cast(fixupInfo, $.$$.System.String), holderValue, $.$$.System.Object.GetType.call(holderValue));
                                }
                                else 
                                {
                                    $.$srsf.System.Runtime.Serialization.SerializationInfoExtensions.UpdateValue(si, $.$cast(fixupInfo, $.$$.System.String), holderValue, $.$$.System.MarshalByRefObject.$type);
                                }
                                fixupsPerformed++;
                                $.$$.System.Array.$WriteT1.call(fixups._values, null, i);
                                if (!bObjectFullyComplete)
                                {
                                    holder.DecrementFixupsRemaining(this);
                                    tempObjectHolder.RemoveDependency(holder._id);
                                }
                            }
                        }
                    }
                }
                else 
                {
                    for(/*int*/ let i = 0; i < fixups._count; i++)
                    {
                        currentFixup = $.$$.System.Array.$ReadT1.call(fixups._values, i);
                        if (currentFixup === null)
                        {
                            continue;
                        }
                        if (this.GetCompletionInfo(currentFixup, $.$ref(() => tempObjectHolder, ($v) => tempObjectHolder = $v, $.$srsf.System.Runtime.Serialization.ObjectHolder), $.$ref(() => fixupInfo, ($v) => fixupInfo = $v, $.$$.System.Object), bObjectFullyComplete))
                        {
                            if (tempObjectHolder.TypeLoadExceptionReachable)
                            {
                                holder.TypeLoadException = tempObjectHolder.TypeLoadException;
                                if (holder.Reachable)
                                {
                                    throw new $.$$.System.Runtime.Serialization.SerializationException().$ctor$12($.$srsf.System.SR.Format$6($.$srsf.System.SR.Serialization_TypeLoadFailure, holder.TypeLoadException.TypeName));
                                }
                            }
                            if (holder.Reachable)
                            {
                                tempObjectHolder.Reachable = true;
                            }
                            let $switch3 = currentFixup._fixupType;
                            switch($switch3)
                            {
                                case 1/*FixupHolder.ArrayFixup*/:
                                $.$$.System.Diagnostics.Debug.Assert$2($.$is(holder.ObjectValue, $.$$.System.Array), "holder.ObjectValue is Array");
                                if (holder.RequiresValueTypeFixup)
                                {
                                    throw new $.$$.System.Runtime.Serialization.SerializationException().$ctor$12($.$srsf.System.SR.Serialization_ValueTypeFixup);
                                }
                                else 
                                {
                                    ($.$cast((holder.ObjectValue), $.$$.System.Array)).SetValue$3(tempObjectHolder.ObjectValue, ($.$cast(fixupInfo, $.$typeArray($.$$.System.Int32))));
                                }
                                break;
                                case 2/*FixupHolder.MemberFixup*/:
                                $.$$.System.Diagnostics.Debug.Assert$2($.$is(fixupInfo, $.$$.System.Reflection.MemberInfo), "fixupInfo is MemberInfo");
                                /*MemberInfo*/ let tempMember = $.$cast(fixupInfo, $.$$.System.Reflection.MemberInfo);
                                if ($.$is(tempMember, $.$$.System.Reflection.FieldInfo))
                                {
                                    if (holder.RequiresValueTypeFixup && holder.ValueTypeFixupPerformed)
                                    {
                                        if (!this.DoValueTypeFixup($.$cast(tempMember, $.$$.System.Reflection.FieldInfo), holder, tempObjectHolder.ObjectValue))
                                        {
                                            throw new $.$$.System.Runtime.Serialization.SerializationException().$ctor$12($.$srsf.System.SR.Serialization_PartialValueTypeFixup);
                                        }
                                    }
                                    else 
                                    {
                                        $.$srsf.System.Runtime.Serialization.FormatterServices.SerializationSetValue(tempMember, holder.ObjectValue, tempObjectHolder.ObjectValue);
                                    }
                                    if (tempObjectHolder.RequiresValueTypeFixup)
                                    {
                                        tempObjectHolder.ValueTypeFixupPerformed = true;
                                    }
                                }
                                else 
                                {
                                    throw new $.$$.System.Runtime.Serialization.SerializationException().$ctor$12($.$srsf.System.SR.Serialization_UnableToFixup);
                                }
                                break;
                                default:
                                throw new $.$$.System.Runtime.Serialization.SerializationException().$ctor$12($.$srsf.System.SR.Serialization_UnableToFixup);
                            }
                            fixupsPerformed++;
                            $.$$.System.Array.$WriteT1.call(fixups._values, null, i);
                            if (!bObjectFullyComplete)
                            {
                                holder.DecrementFixupsRemaining(this);
                                tempObjectHolder.RemoveDependency(holder._id);
                            }
                        }
                    }
                }
                this._fixupCount -= BigInt(fixupsPerformed);
                if (fixups._count === fixupsPerformed)
                {
                    holder._missingElements = null;
                }
            }
            /*void */ DoNewlyRegisteredObjectFixups(/*ObjectHolder*/ holder)
            {
                if (holder.CanObjectValueChange)
                {
                    return;
                }
                /*LongList?*/ let dependencies = holder.DependentObjects;
                if (dependencies === null)
                {
                    return;
                }
                dependencies.StartEnumeration();
                while(dependencies.MoveNext())
                {
                    /*ObjectHolder?*/ let temp = this.FindObjectHolder(dependencies.Current);
                    $.$$.System.Diagnostics.Debug.Assert$2(temp !== null, "temp != null");
                    $.$$.System.Diagnostics.Debug.Assert$2(temp.DirectlyDependentObjects > 0, "temp.m_missingElementsRemaining>0");
                    temp.DecrementFixupsRemaining(this);
                    if (((temp.DirectlyDependentObjects)) === 0)
                    {
                        if (temp.ObjectValue !== null)
                        {
                            this.CompleteObject(temp, true);
                        }
                        else 
                        {
                            temp.MarkForCompletionWhenAvailable();
                        }
                    }
                }
            }
            /*object? */ GetObject(/*long*/ objectID)
            {
                if (objectID <= 0n)
                {
                    throw new $.$$.System.ArgumentOutOfRangeException().$ctor$19("objectID", $.$srsf.System.SR.ArgumentOutOfRange_ObjectID);
                }
                /*ObjectHolder?*/ let holder = this.FindObjectHolder(objectID);
                if (holder === null || holder.CanObjectValueChange)
                {
                    return null;
                }
                return holder.ObjectValue;
            }
            /*void */ RegisterObject$3(/*object*/ obj, /*long*/ objectID)
            {
                this.RegisterObject$1(obj, objectID, null, 0n, null);
            }
            /*void */ RegisterObject$2(/*object*/ obj, /*long*/ objectID, /*SerializationInfo*/ info)
            {
                this.RegisterObject$1(obj, objectID, info, 0n, null);
            }
            /*void */ RegisterObject$1(/*object*/ obj, /*long*/ objectID, /*SerializationInfo?*/ info, /*long*/ idOfContainingObj, /*MemberInfo?*/ member)
            {
                this.RegisterObject(obj, objectID, info, idOfContainingObj, member, null);
            }
            /*void */ RegisterString(/*string?*/ obj, /*long*/ objectID, /*SerializationInfo?*/ info, /*long*/ idOfContainingObj, /*MemberInfo?*/ member)
            {
                /*ObjectHolder*/ let temp;
                $.$$.System.Diagnostics.Debug.Assert$2($.$$.System.Reflection.MemberInfo.op_Equality(member, null) || $.$is(member, $.$$.System.Reflection.FieldInfo), "RegisterString - member is FieldInfo");
                temp = new $.$srsf.System.Runtime.Serialization.ObjectHolder().$ctor$3(obj, objectID, info, null, idOfContainingObj, $.$cast(member, $.$$.System.Reflection.FieldInfo), null);
                this.AddObjectHolder(temp);
                return;
            }
            /*void */ RegisterObject(/*object*/ obj, /*long*/ objectID, /*SerializationInfo?*/ info, /*long*/ idOfContainingObj, /*MemberInfo?*/ member, /*int[]?*/ arrayIndex)
            {
                $.$$.System.ArgumentNullException.ThrowIfNull$2(obj, "obj");
                if (objectID <= 0n)
                {
                    throw new $.$$.System.ArgumentOutOfRangeException().$ctor$19("objectID", $.$srsf.System.SR.ArgumentOutOfRange_ObjectID);
                }
                if ($.$$.System.Reflection.MemberInfo.op_Inequality(member, null) && !($.$is(member, $.$$.System.Reflection.FieldInfo)))
                {
                    throw new $.$$.System.Runtime.Serialization.SerializationException().$ctor$12($.$srsf.System.SR.Serialization_UnknownMemberInfo);
                }
                /*ObjectHolder?*/ let temp;
                /*ISerializationSurrogate?*/ let surrogate = null;
                /*ISurrogateSelector*/ let useless;
                if (this._selector !== null)
                {
                    /*Type*/ let selectorType = this.CanCallGetType(obj) ? $.$$.System.Object.GetType.call(obj) : $.$$.System.MarshalByRefObject.$type;
                    surrogate = this._selector.System$Runtime$Serialization$ISurrogateSelector$GetSurrogate(selectorType, this._context, $.$ref(() => useless, ($v) => useless = $v, $.$srsf.System.Runtime.Serialization.ISurrogateSelector));
                }
                if ($.$is(obj, $.$$.System.Runtime.Serialization.IDeserializationCallback))
                {
                    /*DeserializationEventHandler*/ let d = new $.$srsf.System.Runtime.Serialization.DeserializationEventHandler().$ctor(($.$cast(obj, $.$$.System.Runtime.Serialization.IDeserializationCallback)), ($.$cast(obj, $.$$.System.Runtime.Serialization.IDeserializationCallback)).System$Runtime$Serialization$IDeserializationCallback$OnDeserialization);
                    this.AddOnDeserialization(d);
                }
                if (arrayIndex !== null)
                {
                    arrayIndex = $.$cast(arrayIndex.Clone(), $.$typeArray($.$$.System.Int32));
                }
                temp = this.FindObjectHolder(objectID);
                if (temp === null)
                {
                    temp = new $.$srsf.System.Runtime.Serialization.ObjectHolder().$ctor$2(obj, objectID, info, surrogate, idOfContainingObj, $.$cast(member, $.$$.System.Reflection.FieldInfo), arrayIndex);
                    this.AddObjectHolder(temp);
                    if (temp.RequiresDelayedFixup)
                    {
                        this.SpecialFixupObjects.Add(temp);
                    }
                    this.AddOnDeserialized(obj);
                    return;
                }
                if (temp.ObjectValue !== null)
                {
                    throw new $.$$.System.Runtime.Serialization.SerializationException().$ctor$12($.$srsf.System.SR.Serialization_RegisterTwice);
                }
                temp.UpdateData(obj, info, surrogate, idOfContainingObj, $.$cast(member, $.$$.System.Reflection.FieldInfo), arrayIndex, this);
                if (temp.DirectlyDependentObjects > 0)
                {
                    this.CompleteObject(temp, false);
                }
                if (temp.RequiresDelayedFixup)
                {
                    this.SpecialFixupObjects.Add(temp);
                }
                if (temp.CompletelyFixed)
                {
                    this.DoNewlyRegisteredObjectFixups(temp);
                    temp.DependentObjects = null;
                }
                if (temp.TotalDependentObjects > 0)
                {
                    this.AddOnDeserialized(obj);
                }
                else 
                {
                    this.RaiseOnDeserializedEvent(obj);
                }
            }
            /*void */ CompleteISerializableObject(/*object*/ obj, /*SerializationInfo?*/ info, /*StreamingContext*/ context)
            {
                $.$$.System.ArgumentNullException.ThrowIfNull$2(obj, "obj");
                if (!($.$is(obj, $.$$.System.Runtime.Serialization.ISerializable)))
                {
                    throw new $.$$.System.ArgumentException().$ctor$14($.$srsf.System.SR.Serialization_NotISer);
                }
                /*ConstructorInfo*/ let constInfo;
                /*Type*/ let t = $.$$.System.Object.GetType.call(obj);
                try
                {
                    constInfo = $.$srsf.System.Runtime.Serialization.ObjectManager.GetDeserializationConstructor(t);
                }
                catch(e)
                {
                    throw new $.$$.System.Runtime.Serialization.SerializationException().$ctor$11($.$srsf.System.SR.Format$6($.$srsf.System.SR.Serialization_ConstructorNotFound, t), e);
                }
                constInfo.Invoke(obj, $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$$.System.Object), [info, context], [-1], null));
            }
            static /*ConstructorInfo */ GetDeserializationConstructor(/*Type*/ t)
            {
                let $i1 = 0;
                let $arr1 = t.GetConstructors$1(16/*BindingFlags.Public*/ | 32/*BindingFlags.NonPublic*/ | 4/*BindingFlags.Instance*/ | 2/*BindingFlags.DeclaredOnly*/);
                while ($i1 < $arr1.length)
                {
                    let ci = $arr1[$i1++];
                    /*ParameterInfo[]*/ let parameters = ci.GetParameters();
                    if (parameters.length === 2 && $.$$.System.Type.op_Equality$1($.$$.System.Array.$ReadT1.call(parameters, 0).ParameterType, $.$$.System.Runtime.Serialization.SerializationInfo.$type) && $.$$.System.Type.op_Equality$1($.$$.System.Array.$ReadT1.call(parameters, 1).ParameterType, $.$$.System.Runtime.Serialization.StreamingContext.$type))
                    {
                        return ci;
                    }
                }
                throw new $.$$.System.Runtime.Serialization.SerializationException().$ctor$12($.$srsf.System.SR.Format$6($.$srsf.System.SR.Serialization_ConstructorNotFound, t.FullName));
            }
            /*void */ DoFixups()
            {
                /*ObjectHolder?*/ let temp;
                /*int*/ let fixupCount = -1;
                while(fixupCount !== 0)
                {
                    fixupCount = 0;
                    /*ObjectHolderListEnumerator*/ let fixupObjectsEnum = this.SpecialFixupObjects.GetFixupEnumerator();
                    while(fixupObjectsEnum.MoveNext())
                    {
                        temp = fixupObjectsEnum.Current;
                        if (temp.ObjectValue === null)
                        {
                            throw new $.$$.System.Runtime.Serialization.SerializationException().$ctor$12($.$srsf.System.SR.Format$6($.$srsf.System.SR.Serialization_ObjectNotSupplied, $.$box(temp._id, $.$$.System.Int64)));
                        }
                        if (temp.TotalDependentObjects === 0)
                        {
                            if (temp.RequiresSerInfoFixup)
                            {
                                this.FixupSpecialObject(temp);
                                fixupCount++;
                            }
                            else if (!temp.IsIncompleteObjectReference)
                            {
                                this.CompleteObject(temp, true);
                            }
                            if (temp.IsIncompleteObjectReference && this.ResolveObjectReference(temp))
                            {
                                fixupCount++;
                            }
                        }
                    }
                }
                $.$$.System.Diagnostics.Debug.Assert$2(this._fixupCount >= 0n, "[ObjectManager.DoFixups]m_fixupCount>=0");
                if (this._fixupCount === 0n)
                {
                    if ($.$is(this.TopObject, $.$srsf.System.Runtime.Serialization.TypeLoadExceptionHolder))
                    {
                        throw new $.$$.System.Runtime.Serialization.SerializationException().$ctor$12($.$srsf.System.SR.Format$6($.$srsf.System.SR.Serialization_TypeLoadFailure, ($.$cast(this.TopObject, $.$srsf.System.Runtime.Serialization.TypeLoadExceptionHolder)).TypeName));
                    }
                    return;
                }
                for(/*int*/ let i = 0; i < this._objects.length; i++)
                {
                    temp = $.$$.System.Array.$ReadT1.call(this._objects, i);
                    while(temp !== null)
                    {
                        if (temp.TotalDependentObjects > 0)
                        {
                            this.CompleteObject(temp, true);
                        }
                        temp = temp._next;
                    }
                    if (this._fixupCount === 0n)
                    {
                        return;
                    }
                }
                throw new $.$$.System.Runtime.Serialization.SerializationException().$ctor$12($.$srsf.System.SR.Serialization_IncorrectNumberOfFixups);
            }
            /*void */ RegisterFixup(/*FixupHolder*/ fixup, /*long*/ objectToBeFixed, /*long*/ objectRequired)
            {
                /*ObjectHolder*/ let ohToBeFixed = this.FindOrCreateObjectHolder(objectToBeFixed);
                /*ObjectHolder*/ let ohRequired;
                if (ohToBeFixed.RequiresSerInfoFixup && fixup._fixupType === 2/*FixupHolder.MemberFixup*/)
                {
                    throw new $.$$.System.Runtime.Serialization.SerializationException().$ctor$12($.$srsf.System.SR.Serialization_InvalidFixupType);
                }
                ohToBeFixed.AddFixup(fixup, this);
                ohRequired = this.FindOrCreateObjectHolder(objectRequired);
                ohRequired.AddDependency(objectToBeFixed);
                this._fixupCount++;
            }
            /*void */ RecordFixup(/*long*/ objectToBeFixed, /*MemberInfo*/ member, /*long*/ objectRequired)
            {
                if (objectToBeFixed <= 0n || objectRequired <= 0n)
                {
                    throw new $.$$.System.ArgumentOutOfRangeException().$ctor$19(objectToBeFixed <= 0n ? "objectToBeFixed" : "objectRequired", $.$srsf.System.SR.Serialization_IdTooSmall);
                }
                $.$$.System.ArgumentNullException.ThrowIfNull$2(member, "member");
                if (!($.$is(member, $.$$.System.Reflection.FieldInfo)))
                {
                    throw new $.$$.System.Runtime.Serialization.SerializationException().$ctor$12($.$srsf.System.SR.Format$6($.$srsf.System.SR.Serialization_InvalidType, $.$$.System.Object.GetType.call(member)));
                }
                /*FixupHolder*/ let fixup = new $.$srsf.System.Runtime.Serialization.FixupHolder().$ctor$1(objectRequired, member, 2/*FixupHolder.MemberFixup*/);
                this.RegisterFixup(fixup, objectToBeFixed, objectRequired);
            }
            /*void */ RecordDelayedFixup(/*long*/ objectToBeFixed, /*string*/ memberName, /*long*/ objectRequired)
            {
                if (objectToBeFixed <= 0n || objectRequired <= 0n)
                {
                    throw new $.$$.System.ArgumentOutOfRangeException().$ctor$19(objectToBeFixed <= 0n ? "objectToBeFixed" : "objectRequired", $.$srsf.System.SR.Serialization_IdTooSmall);
                }
                $.$$.System.ArgumentNullException.ThrowIfNull$2(memberName, "memberName");
                /*FixupHolder*/ let fixup = new $.$srsf.System.Runtime.Serialization.FixupHolder().$ctor$1(objectRequired, memberName, 4/*FixupHolder.DelayedFixup*/);
                this.RegisterFixup(fixup, objectToBeFixed, objectRequired);
            }
            /*void */ RecordArrayElementFixup(/*long*/ arrayToBeFixed, /*int*/ index, /*long*/ objectRequired)
            {
                /*int[]*/ let indexArray = $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$$.System.Int32), null, [1], null);
                $.$$.System.Array.$WriteT1.call(indexArray, index, 0);
                this.RecordArrayElementFixup$1(arrayToBeFixed, indexArray, objectRequired);
            }
            /*void */ RecordArrayElementFixup$1(/*long*/ arrayToBeFixed, /*int[]*/ indices, /*long*/ objectRequired)
            {
                if (arrayToBeFixed <= 0n || objectRequired <= 0n)
                {
                    throw new $.$$.System.ArgumentOutOfRangeException().$ctor$19(arrayToBeFixed <= 0n ? "arrayToBeFixed" : "objectRequired", $.$srsf.System.SR.Serialization_IdTooSmall);
                }
                $.$$.System.ArgumentNullException.ThrowIfNull$2(indices, "indices");
                /*FixupHolder*/ let fixup = new $.$srsf.System.Runtime.Serialization.FixupHolder().$ctor$1(objectRequired, indices, 1/*FixupHolder.ArrayFixup*/);
                this.RegisterFixup(fixup, arrayToBeFixed, objectRequired);
            }
            /*void */ RaiseDeserializationEvent()
            {
                this._onDeserializedHandler?.Invoke(this._context);
                this._onDeserializationHandler?.Invoke(null);
            }
            /*void */ AddOnDeserialization(/*DeserializationEventHandler*/ handler)
            {
                this._onDeserializationHandler = $.$cast($.$$.System.Delegate.Combine(this._onDeserializationHandler, handler), $.$srsf.System.Runtime.Serialization.DeserializationEventHandler);
            }
            /*void */ AddOnDeserialized(/*object*/ obj)
            {
                /*SerializationEvents*/ let cache = $.$srsf.System.Runtime.Serialization.SerializationEventsCache.GetSerializationEventsForType($.$$.System.Object.GetType.call(obj));
                this._onDeserializedHandler = cache.AddOnDeserialized(obj, this._onDeserializedHandler);
            }
            /*void */ RaiseOnDeserializedEvent(/*object*/ obj)
            {
                /*SerializationEvents*/ let cache = $.$srsf.System.Runtime.Serialization.SerializationEventsCache.GetSerializationEventsForType($.$$.System.Object.GetType.call(obj));
                cache.InvokeOnDeserialized(obj, this._context);
            }
            /*void */ RaiseOnDeserializingEvent(/*object*/ obj)
            {
                /*SerializationEvents*/ let cache = $.$srsf.System.Runtime.Serialization.SerializationEventsCache.GetSerializationEventsForType($.$$.System.Object.GetType.call(obj));
                cache.InvokeOnDeserializing(obj, this._context);
            }
            //default member initializer
            constructor()
            {
                super();
                this._context = $.$default($.$$.System.Runtime.Serialization.StreamingContext);
            }
            //Static Initializer
            static $sinit()
            {
                {
                    this.ObjectManagerUnreferencedCodeMessage = "ObjectManager is not trim compatible because the type of objects being managed cannot be statically discovered.";
                }
                {
                    this.s_nullableValueField = $.$$.System.Nullable$$().$type.GetField$1("value", 32/*BindingFlags.NonPublic*/ | 4/*BindingFlags.Instance*/);
                }
            }
            static $h = 1558786;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":131073,"g":{"r":0,"d":0,"h":77310970114,"f":50331656},"s":{"r":0,"d":0,"h":81605937410,"f":83886088},"n":"TopObject","d":1558786,"h":73016002818,"f":2097160},{"p":1362178,"g":{"r":0,"d":0,"h":90195872002,"f":50331656},"n":"SpecialFixupObjects","d":1558786,"h":85900904706,"f":2097160}],"m":[{"r":262145,"p":[{"n":"obj","p":131073}],"n":"CanCallGetType","d":1558786,"h":68721035522,"f":16777218},{"r":1296642,"p":[{"n":"objectID","p":917505}],"n":"FindObjectHolder","d":1558786,"h":94490839298,"f":16777224},{"r":1296642,"p":[{"n":"objectID","p":917505}],"n":"FindOrCreateObjectHolder","d":1558786,"h":98785806594,"f":16777224},{"r":65537,"p":[{"n":"holder","p":1296642}],"n":"AddObjectHolder","d":1558786,"h":103080773890,"f":16777218},{"r":262145,"p":[{"n":"fixup","p":313602},{"n":"holder","p":1296642,"f":2},{"n":"member","p":131073,"f":2},{"n":"bThrowIfMissing","p":262145}],"n":"GetCompletionInfo","d":1558786,"h":107375741186,"f":16777218},{"r":65537,"p":[{"n":"holder","p":1296642}],"n":"FixupSpecialObject","d":1558786,"h":111670708482,"f":16777218},{"r":262145,"p":[{"n":"holder","p":1296642}],"n":"ResolveObjectReference","d":1558786,"h":115965675778,"f":16777218},{"r":262145,"p":[{"n":"memberToFix","p":76677121},{"n":"holder","p":1296642},{"n":"value","p":131073}],"n":"DoValueTypeFixup","d":1558786,"h":120260643074,"f":16777218},{"r":76677121,"p":[{"n":"type","p":142475265}],"n":"GetNullableValueField","d":1558786,"h":124555610370,"f":16777250},{"r":65537,"p":[{"n":"holder","p":1296642},{"n":"bObjectFullyComplete","p":262145}],"n":"CompleteObject","d":1558786,"h":128850577666,"f":16777224},{"r":65537,"p":[{"n":"holder","p":1296642}],"n":"DoNewlyRegisteredObjectFixups","d":1558786,"h":133145544962,"f":16777218},{"r":131073,"p":[{"n":"objectID","p":917505}],"n":"GetObject","d":1558786,"h":137440512258,"f":16777345},{"r":65537,"p":[{"n":"obj","p":131073},{"n":"objectID","p":917505}],"n":"RegisterObject","o":"@$3","d":1558786,"h":141735479554,"f":16777345},{"r":65537,"p":[{"n":"obj","p":131073},{"n":"objectID","p":917505},{"n":"info","p":113836033}],"n":"RegisterObject","o":"@$2","d":1558786,"h":146030446850,"f":16777217},{"r":65537,"p":[{"n":"obj","p":131073},{"n":"objectID","p":917505},{"n":"info","p":113836033},{"n":"idOfContainingObj","p":917505},{"n":"member","p":78249985}],"n":"RegisterObject","o":"@$1","d":1558786,"h":150325414146,"f":16777217},{"r":65537,"p":[{"n":"obj","p":1310721},{"n":"objectID","p":917505},{"n":"info","p":113836033},{"n":"idOfContainingObj","p":917505},{"n":"member","p":78249985}],"n":"RegisterString","d":1558786,"h":154620381442,"f":16777224},{"r":65537,"p":[{"n":"obj","p":131073},{"n":"objectID","p":917505},{"n":"info","p":113836033},{"n":"idOfContainingObj","p":917505},{"n":"member","p":78249985},{"n":"arrayIndex","p":$.$typeArray($.$$.System.Int32).$h}],"n":"RegisterObject","d":1558786,"h":158915348738,"f":16777217},{"r":65537,"p":[{"n":"obj","p":131073},{"n":"info","p":113836033},{"n":"context","p":113967105}],"n":"CompleteISerializableObject","d":1558786,"h":163210316034,"f":16777224},{"r":75628545,"p":[{"n":"t","p":142475265}],"n":"GetDeserializationConstructor","d":1558786,"h":167505283330,"f":16777256},{"r":65537,"n":"DoFixups","d":1558786,"h":171800250626,"f":16777345},{"r":65537,"p":[{"n":"fixup","p":313602},{"n":"objectToBeFixed","p":917505},{"n":"objectRequired","p":917505}],"n":"RegisterFixup","d":1558786,"h":176095217922,"f":16777218},{"r":65537,"p":[{"n":"objectToBeFixed","p":917505},{"n":"member","p":78249985},{"n":"objectRequired","p":917505}],"n":"RecordFixup","d":1558786,"h":180390185218,"f":16777345},{"r":65537,"p":[{"n":"objectToBeFixed","p":917505},{"n":"memberName","p":1310721},{"n":"objectRequired","p":917505}],"n":"RecordDelayedFixup","d":1558786,"h":184685152514,"f":16777345},{"r":65537,"p":[{"n":"arrayToBeFixed","p":917505},{"n":"index","p":655361},{"n":"objectRequired","p":917505}],"n":"RecordArrayElementFixup","d":1558786,"h":188980119810,"f":16777345},{"r":65537,"p":[{"n":"arrayToBeFixed","p":917505},{"n":"indices","p":$.$typeArray($.$$.System.Int32).$h},{"n":"objectRequired","p":917505}],"n":"RecordArrayElementFixup","o":"@$1","d":1558786,"h":193275087106,"f":16777345},{"r":65537,"n":"RaiseDeserializationEvent","d":1558786,"h":197570054402,"f":16777345},{"r":65537,"p":[{"n":"handler","p":248066}],"n":"AddOnDeserialization","d":1558786,"h":201865021698,"f":16777352},{"r":65537,"p":[{"n":"obj","p":131073}],"n":"AddOnDeserialized","d":1558786,"h":206159988994,"f":16777352},{"r":65537,"p":[{"n":"obj","p":131073}],"n":"RaiseOnDeserializedEvent","d":1558786,"h":210454956290,"f":16777352},{"r":65537,"p":[{"n":"obj","p":131073}],"n":"RaiseOnDeserializingEvent","d":1558786,"h":214749923586,"f":16777217}],"l":[{"t":655361,"n":"DefaultInitialSize","d":1558786,"h":4296526082,"f":4194338},{"t":655361,"n":"MaxArraySize","d":1558786,"h":8591493378,"f":4194338},{"t":655361,"n":"ArrayMask","d":1558786,"h":12886460674,"f":4194338},{"t":655361,"n":"MaxReferenceDepth","d":1558786,"h":17181427970,"f":4194338},{"t":1310721,"n":"ObjectManagerUnreferencedCodeMessage","d":1558786,"h":21476395266,"f":4194338},{"t":76677121,"n":"s_nullableValueField","d":1558786,"h":25771362562,"f":4194338},{"t":248066,"n":"_onDeserializationHandler","d":1558786,"h":30066329858,"f":4194306},{"t":1689858,"n":"_onDeserializedHandler","d":1558786,"h":34361297154,"f":4194306},{"t":$.$typeArray($.$srsf.System.Runtime.Serialization.ObjectHolder).$h,"n":"_objects","d":1558786,"h":38656264450,"f":4194312},{"t":131073,"n":"_topObject","d":1558786,"h":42951231746,"f":4194312},{"t":1362178,"n":"_specialFixupObjects","d":1558786,"h":47246199042,"f":4194312},{"t":917505,"n":"_fixupCount","d":1558786,"h":51541166338,"f":4194312},{"t":1100034,"n":"_selector","d":1558786,"h":55836133634,"f":4194312},{"t":113967105,"n":"_context","d":1558786,"h":60131100930,"f":4194312}],"c":[{"p":[{"n":"selector","p":1100034},{"n":"context","p":113967105}],"n":".ctor","o":"$ctor$1","d":1558786,"h":64426068226,"f":16777217}],"h":1558786,"a":[{"t":70909953,"c":8660844545,"a":[{"v":"Formatter-based serialization is obsolete and should not be used.","t":1310721}],"n":[{"n":"DiagnosticId","v":"SYSLIB0050","t":1310721},{"n":"UrlFormat","v":"https://aka.ms/dotnet-warnings/{0}","t":1310721}]}]}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `System.Runtime.Serialization.ObjectManager`; }
        });
        
        $asm.$cls("$srsf.System.Runtime.Serialization.SurrogateKey", ($self) => class SurrogateKey extends $.$$.System.Object
        {
            /*Type*/ _type = null;
            /*StreamingContext*/ _context;
            $ctor$1(/*Type*/ type, /*StreamingContext*/ context)
            {
                super.$ctor();
                {
                    $.$$.System.Diagnostics.Debug.Assert$2($.$$.System.Type.op_Inequality$1(type, null), "type != null");
                    this._type = type;
                    this._context = context;
                }
                return this;
            }
            static/*conventional*/ /*int */ GetHashCode()
            {
                return $.$$.System.Type.GetHashCode.call(this._type);
            }
            //Static convention instance redirect
            /*int */ GetHashCode() { return $.$srsf.System.Runtime.Serialization.SurrogateKey.GetHashCode.apply(this, arguments); }
            //default member initializer
            constructor()
            {
                super();
                this._context = $.$default($.$$.System.Runtime.Serialization.StreamingContext);
            }
            static $h = 2214146;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"m":[{"r":655361,"n":"GetHashCode","d":2214146,"h":17182083330,"f":16809985}],"l":[{"t":142475265,"n":"_type","d":2214146,"h":4297181442,"f":4194312},{"t":113967105,"n":"_context","d":2214146,"h":8592148738,"f":4194312}],"c":[{"p":[{"n":"type","p":142475265},{"n":"context","p":113967105}],"n":".ctor","o":"$ctor$1","d":2214146,"h":12887116034,"f":16777224}],"h":2214146}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `System.Runtime.Serialization.SurrogateKey`; }
        });
        
        $asm.$cls("$srsf.System.Runtime.Serialization.ValueTypeFixupInfo", ($self) => class ValueTypeFixupInfo extends $.$$.System.Object
        {
            /*long*/ _containerID = 0n;
            /*FieldInfo?*/ _parentField = null;
            /*int[]?*/ _parentIndex = null;
            $ctor$1(/*long*/ containerID, /*FieldInfo?*/ member, /*int[]?*/ parentIndex)
            {
                super.$ctor();
                {
                    if ($.$$.System.Reflection.FieldInfo.op_Equality$1(member, null) && parentIndex === null)
                    {
                        throw new $.$$.System.ArgumentException().$ctor$14($.$srsf.System.SR.Argument_MustSupplyParent);
                    }
                    if (containerID === 0n && $.$$.System.Reflection.FieldInfo.op_Equality$1(member, null))
                    {
                        this._containerID = containerID;
                        this._parentField = member;
                        this._parentIndex = parentIndex;
                    }
                    if ($.$$.System.Reflection.FieldInfo.op_Inequality$1(member, null))
                    {
                        if (parentIndex !== null)
                        {
                            throw new $.$$.System.ArgumentException().$ctor$14($.$srsf.System.SR.Argument_MemberAndArray);
                        }
                        if (member.FieldType.IsValueType && containerID === 0n)
                        {
                            throw new $.$$.System.ArgumentException().$ctor$14($.$srsf.System.SR.Argument_MustSupplyContainer);
                        }
                    }
                    this._containerID = containerID;
                    this._parentField = member;
                    this._parentIndex = parentIndex;
                }
                return this;
            }
            /*long */ get ContainerID()
            {
                return this._containerID;
            }
            /*FieldInfo? */ get ParentField()
            {
                return this._parentField;
            }
            /*int[]? */ get ParentIndex()
            {
                return this._parentIndex;
            }
            static $h = 2410754;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":917505,"g":{"r":0,"d":0,"h":25772214530,"f":50331649},"n":"ContainerID","d":2410754,"h":21477247234,"f":2097153},{"p":76677121,"g":{"r":0,"d":0,"h":34362149122,"f":50331649},"n":"ParentField","d":2410754,"h":30067181826,"f":2097153},{"p":$.$typeArray($.$$.System.Int32).$h,"g":{"r":0,"d":0,"h":42952083714,"f":50331649},"n":"ParentIndex","d":2410754,"h":38657116418,"f":2097153}],"l":[{"t":917505,"n":"_containerID","d":2410754,"h":4297378050,"f":4194306},{"t":76677121,"n":"_parentField","d":2410754,"h":8592345346,"f":4194306},{"t":$.$typeArray($.$$.System.Int32).$h,"n":"_parentIndex","d":2410754,"h":12887312642,"f":4194306}],"c":[{"p":[{"n":"containerID","p":917505},{"n":"member","p":76677121},{"n":"parentIndex","p":$.$typeArray($.$$.System.Int32).$h}],"n":".ctor","o":"$ctor$1","d":2410754,"h":17182279938,"f":16777217}],"h":2410754}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `System.Runtime.Serialization.ValueTypeFixupInfo`; }
        });
        
        $asm.$cls("$srsf.System.Runtime.Serialization.SerializationEventsCache", ($self) => class SerializationEventsCache
        {
            /*ConcurrentDictionary<Type, SerializationEvents>*/ static s_cache = null;
            static /*SerializationEvents */ GetSerializationEventsForType(/*Type*/ t)
            {
                return $.$srsf.System.Runtime.Serialization.SerializationEventsCache.s_cache.GetOrAdd(t, new ($.$$.System.Func$$$($.$$.System.Type, $.$srsf.System.Runtime.Serialization.SerializationEvents))().$ctor($.$srsf.System.Runtime.Serialization.SerializationEventsCache, $.$srsf.System.Runtime.Serialization.SerializationEventsCache.CreateSerializationEvents));
            }
            static /*SerializationEvents */ CreateSerializationEvents(/*Type*/ t)
            {
                return new $.$srsf.System.Runtime.Serialization.SerializationEvents().$ctor$1(t);
            }
            //Static Initializer
            static $sinit()
            {
                {
                    this.s_cache = new ($.$scc.System.Collections.Concurrent.ConcurrentDictionary$$$($.$$.System.Type, $.$srsf.System.Runtime.Serialization.SerializationEvents))().$ctor$1();
                }
            }
            static $h = 1820930;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"m":[{"r":1755394,"p":[{"n":"t","p":142475265}],"n":"GetSerializationEventsForType","d":1820930,"h":8591755522,"f":16777256},{"r":1755394,"p":[{"n":"t","p":142475265}],"n":"CreateSerializationEvents","d":1820930,"h":12886722818,"f":16777250}],"l":[{"t":$.$scc.System.Collections.Concurrent.ConcurrentDictionary$$$($.$$.System.Type, $.$srsf.System.Runtime.Serialization.SerializationEvents).$h,"n":"s_cache","d":1820930,"h":4296788226,"f":4194338}],"h":1820930}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `System.Runtime.Serialization.SerializationEventsCache`; }
        });
        
        $asm.$cls("$srsf.System.Runtime.Serialization.ObjectHolder", ($self) => class ObjectHolder extends $.$$.System.Object
        {
            /*int*/ static IncompleteObjectReference = 1;
            /*int*/ static HAS_ISERIALIZABLE = 2;
            /*int*/ static HAS_SURROGATE = 4;
            /*int*/ static REQUIRES_VALUETYPE_FIXUP = 8;
            /*int*/ static REQUIRES_DELAYED_FIXUP = 7;
            /*int*/ static SER_INFO_FIXED = 16384;
            /*int*/ static VALUETYPE_FIXUP_PERFORMED = 32768;
            /*object?*/ _object = null;
            /*long*/ _id = 0n;
            /*int*/ _missingElementsRemaining = 0;
            /*int*/ _missingDecendents = 0;
            /*SerializationInfo?*/ _serInfo = null;
            /*ISerializationSurrogate?*/ _surrogate = null;
            /*FixupHolderList?*/ _missingElements = null;
            /*LongList?*/ _dependentObjects = null;
            /*ObjectHolder?*/ _next = null;
            /*int*/ _flags = 0;
            /*bool*/ _markForFixupWhenAvailable = false;
            /*ValueTypeFixupInfo?*/ _valueFixup = null;
            /*TypeLoadExceptionHolder?*/ _typeLoad = null;
            /*bool*/ _reachable = false;
            $ctor$1(/*long*/ objID)
            {
                this.$ctor$3(null, objID, null, null, 0n, null, null);
                {
                }
                return this;
            }
            $ctor$2(/*object?*/ obj, /*long*/ objID, /*SerializationInfo?*/ info, /*ISerializationSurrogate?*/ surrogate, /*long*/ idOfContainingObj, /*FieldInfo?*/ field, /*int[]?*/ arrayIndex)
            {
                super.$ctor();
                {
                    $.$$.System.Diagnostics.Debug.Assert$2(objID >= 0n, "objID>=0");
                    this._object = obj;
                    this._id = objID;
                    this._flags = 0;
                    this._missingElementsRemaining = 0;
                    this._missingDecendents = 0;
                    this._dependentObjects = null;
                    this._next = null;
                    this._serInfo = info;
                    this._surrogate = surrogate;
                    this._markForFixupWhenAvailable = false;
                    if ($.$is(obj, $.$srsf.System.Runtime.Serialization.TypeLoadExceptionHolder))
                    {
                        this._typeLoad = $.$cast(obj, $.$srsf.System.Runtime.Serialization.TypeLoadExceptionHolder);
                    }
                    if (idOfContainingObj !== 0n && (($.$$.System.Reflection.FieldInfo.op_Inequality$1(field, null) && field.FieldType.IsValueType) || arrayIndex !== null))
                    {
                        if (idOfContainingObj === objID)
                        {
                            throw new $.$$.System.Runtime.Serialization.SerializationException().$ctor$12($.$srsf.System.SR.Serialization_ParentChildIdentical);
                        }
                        this._valueFixup = new $.$srsf.System.Runtime.Serialization.ValueTypeFixupInfo().$ctor$1(idOfContainingObj, field, arrayIndex);
                    }
                    this.SetFlags();
                }
                return this;
            }
            $ctor$3(/*string?*/ obj, /*long*/ objID, /*SerializationInfo?*/ info, /*ISerializationSurrogate?*/ surrogate, /*long*/ idOfContainingObj, /*FieldInfo?*/ field, /*int[]?*/ arrayIndex)
            {
                super.$ctor();
                {
                    $.$$.System.Diagnostics.Debug.Assert$2(objID >= 0n, "objID>=0");
                    this._object = obj;
                    this._id = objID;
                    this._flags = 0;
                    this._missingElementsRemaining = 0;
                    this._missingDecendents = 0;
                    this._dependentObjects = null;
                    this._next = null;
                    this._serInfo = info;
                    this._surrogate = surrogate;
                    this._markForFixupWhenAvailable = false;
                    if (idOfContainingObj !== 0n && arrayIndex !== null)
                    {
                        this._valueFixup = new $.$srsf.System.Runtime.Serialization.ValueTypeFixupInfo().$ctor$1(idOfContainingObj, field, arrayIndex);
                    }
                    if (this._valueFixup !== null)
                    {
                        this._flags |= 8/*REQUIRES_VALUETYPE_FIXUP*/;
                    }
                }
                return this;
            }
            /*void */ IncrementDescendentFixups(/*int*/ amount)
            {
                return this._missingDecendents += amount;
            }
            /*void */ DecrementFixupsRemaining(/*ObjectManager*/ manager)
            {
                this._missingElementsRemaining--;
                if (this.RequiresValueTypeFixup)
                {
                    this.UpdateDescendentDependencyChain(-1, manager);
                }
            }
            /*void */ RemoveDependency(/*long*/ id)
            {
                $.$$.System.Diagnostics.Debug.Assert$2(this._dependentObjects !== null, "[ObjectHolder.RemoveDependency]m_dependentObjects!=null");
                $.$$.System.Diagnostics.Debug.Assert$2(id >= 0n, "[ObjectHolder.RemoveDependency]id>=0");
                this._dependentObjects.RemoveElement(id);
            }
            /*void */ AddFixup(/*FixupHolder*/ fixup, /*ObjectManager*/ manager)
            {
                this._missingElements ??= new $.$srsf.System.Runtime.Serialization.FixupHolderList().$ctor$1();
                this._missingElements.Add(fixup);
                this._missingElementsRemaining++;
                if (this.RequiresValueTypeFixup)
                {
                    this.UpdateDescendentDependencyChain(1, manager);
                }
            }
            /*void */ UpdateDescendentDependencyChain(/*int*/ amount, /*ObjectManager*/ manager)
            {
                /*ObjectHolder*/ let holder = this;
                do
                {
                    holder = manager.FindOrCreateObjectHolder(holder.ContainerID);
                    $.$$.System.Diagnostics.Debug.Assert$2(holder !== null, "[ObjectHolder.UpdateTotalDependencyChain]holder!=null");
                    holder.IncrementDescendentFixups(amount);
                }
                while(holder.RequiresValueTypeFixup);
            }
            /*void */ AddDependency(/*long*/ dependentObject)
            {
                this._dependentObjects ??= new $.$srsf.System.Runtime.Serialization.LongList().$ctor$1();
                this._dependentObjects.Add(dependentObject);
            }
            /*void */ UpdateData(/*object*/ obj, /*SerializationInfo?*/ info, /*ISerializationSurrogate?*/ surrogate, /*long*/ idOfContainer, /*FieldInfo?*/ field, /*int[]?*/ arrayIndex, /*ObjectManager*/ manager)
            {
                $.$$.System.Diagnostics.Debug.Assert$2(obj !== null, "obj!=null");
                $.$$.System.Diagnostics.Debug.Assert$2(this._id > 0n, "m_id>0");
                this.SetObjectValue(obj, manager);
                this._serInfo = info;
                this._surrogate = surrogate;
                if (idOfContainer !== 0n && (($.$$.System.Reflection.FieldInfo.op_Inequality$1(field, null) && field.FieldType.IsValueType) || arrayIndex !== null))
                {
                    if (idOfContainer === this._id)
                    {
                        throw new $.$$.System.Runtime.Serialization.SerializationException().$ctor$12($.$srsf.System.SR.Serialization_ParentChildIdentical);
                    }
                    this._valueFixup = new $.$srsf.System.Runtime.Serialization.ValueTypeFixupInfo().$ctor$1(idOfContainer, field, arrayIndex);
                }
                this.SetFlags();
                if (this.RequiresValueTypeFixup)
                {
                    this.UpdateDescendentDependencyChain(this._missingElementsRemaining, manager);
                }
            }
            /*void */ MarkForCompletionWhenAvailable()
            {
                return this._markForFixupWhenAvailable = true;
            }
            /*void */ SetFlags()
            {
                if ($.$is(this._object, $.$$.System.Runtime.Serialization.IObjectReference))
                {
                    this._flags |= 1/*IncompleteObjectReference*/;
                }
                this._flags &= ~(2/*HAS_ISERIALIZABLE*/ | 4/*HAS_SURROGATE*/);
                if (this._surrogate !== null)
                {
                    this._flags |= 4/*HAS_SURROGATE*/;
                }
                else if ($.$is(this._object, $.$$.System.Runtime.Serialization.ISerializable))
                {
                    this._flags |= 2/*HAS_ISERIALIZABLE*/;
                }
                if (this._valueFixup !== null)
                {
                    this._flags |= 8/*REQUIRES_VALUETYPE_FIXUP*/;
                }
            }
            /*bool */ get IsIncompleteObjectReference()
            {
                return (this._flags & 1/*IncompleteObjectReference*/) !== 0;
            }
            /*bool */ set IsIncompleteObjectReference(value)
            {
                if (value)
                {
                    this._flags |= 1/*IncompleteObjectReference*/;
                }
                else 
                {
                    this._flags &= ~1/*IncompleteObjectReference*/;
                }
            }
            /*bool */ get RequiresDelayedFixup()
            {
                return (this._flags & 7/*REQUIRES_DELAYED_FIXUP*/) !== 0;
            }
            /*bool */ get RequiresValueTypeFixup()
            {
                return (this._flags & 8/*REQUIRES_VALUETYPE_FIXUP*/) !== 0;
            }
            /*bool */ get ValueTypeFixupPerformed()
            {
                return (((this._flags & 32768/*VALUETYPE_FIXUP_PERFORMED*/) !== 0) || (this._object !== null && ((this._dependentObjects === null) || this._dependentObjects.Count === 0)));
            }
            /*bool */ set ValueTypeFixupPerformed(value)
            {
                if (value)
                {
                    this._flags |= 32768/*VALUETYPE_FIXUP_PERFORMED*/;
                }
            }
            /*bool */ get HasISerializable()
            {
                return (this._flags & 2/*HAS_ISERIALIZABLE*/) !== 0;
            }
            /*bool */ get HasSurrogate()
            {
                return (this._flags & 4/*HAS_SURROGATE*/) !== 0;
            }
            /*bool */ get CanSurrogatedObjectValueChange()
            {
                return (this._surrogate === null || $.$$.System.Type.op_Inequality$1($.$$.System.Object.GetType.call(this._surrogate), $.$srsf.System.Runtime.Serialization.SurrogateForCyclicalReference.$type));
            }
            /*bool */ get CanObjectValueChange()
            {
                return this.IsIncompleteObjectReference ? true : this.HasSurrogate ? this.CanSurrogatedObjectValueChange : false;
            }
            /*int */ get DirectlyDependentObjects()
            {
                return this._missingElementsRemaining;
            }
            /*int */ get TotalDependentObjects()
            {
                return ((this._missingElementsRemaining + this._missingDecendents) | 0);
            }
            /*bool */ get Reachable()
            {
                return this._reachable;
            }
            /*bool */ set Reachable(value)
            {
                this._reachable = value;
            }
            /*bool */ get TypeLoadExceptionReachable()
            {
                return this._typeLoad !== null;
            }
            /*TypeLoadExceptionHolder? */ get TypeLoadException()
            {
                return this._typeLoad;
            }
            /*TypeLoadExceptionHolder? */ set TypeLoadException(value)
            {
                this._typeLoad = value;
            }
            /*object? */ get ObjectValue()
            {
                return this._object;
            }
            /*void */ SetObjectValue(/*object?*/ obj, /*ObjectManager*/ manager)
            {
                this._object = obj;
                if (obj === manager.TopObject)
                {
                    this._reachable = true;
                }
                if ($.$is(obj, $.$srsf.System.Runtime.Serialization.TypeLoadExceptionHolder))
                {
                    this._typeLoad = $.$cast(obj, $.$srsf.System.Runtime.Serialization.TypeLoadExceptionHolder);
                }
                if (this._markForFixupWhenAvailable)
                {
                    manager.CompleteObject(this, true);
                }
            }
            /*SerializationInfo? */ get SerializationInfo()
            {
                return this._serInfo;
            }
            /*SerializationInfo? */ set SerializationInfo(value)
            {
                this._serInfo = value;
            }
            /*ISerializationSurrogate? */ get Surrogate()
            {
                return this._surrogate;
            }
            /*LongList? */ get DependentObjects()
            {
                return this._dependentObjects;
            }
            /*LongList? */ set DependentObjects(value)
            {
                this._dependentObjects = value;
            }
            /*bool */ get RequiresSerInfoFixup()
            {
                if (((this._flags & 4/*HAS_SURROGATE*/) === 0) && ((this._flags & 2/*HAS_ISERIALIZABLE*/) === 0))
                {
                    return false;
                }
                return (this._flags & 16384/*SER_INFO_FIXED*/) === 0;
            }
            /*bool */ set RequiresSerInfoFixup(value)
            {
                if (!value)
                {
                    this._flags |= 16384/*SER_INFO_FIXED*/;
                }
                else 
                {
                    this._flags &= ~16384/*SER_INFO_FIXED*/;
                }
            }
            /*ValueTypeFixupInfo? */ get ValueFixup()
            {
                return this._valueFixup;
            }
            /*bool */ get CompletelyFixed()
            {
                return !this.RequiresSerInfoFixup && !this.IsIncompleteObjectReference;
            }
            /*long */ get ContainerID()
            {
                return this._valueFixup !== null ? this._valueFixup.ContainerID : 0n;
            }
            static $h = 1296642;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":262145,"g":{"r":0,"d":0,"h":150325152002,"f":50331656},"s":{"r":0,"d":0,"h":154620119298,"f":83886088},"n":"IsIncompleteObjectReference","d":1296642,"h":146030184706,"f":2097160},{"p":262145,"g":{"r":0,"d":0,"h":163210053890,"f":50331656},"n":"RequiresDelayedFixup","d":1296642,"h":158915086594,"f":2097160},{"p":262145,"g":{"r":0,"d":0,"h":171799988482,"f":50331656},"n":"RequiresValueTypeFixup","d":1296642,"h":167505021186,"f":2097160},{"p":262145,"g":{"r":0,"d":0,"h":180389923074,"f":50331656},"s":{"r":0,"d":0,"h":184684890370,"f":83886088},"n":"ValueTypeFixupPerformed","d":1296642,"h":176094955778,"f":2097160},{"p":262145,"g":{"r":0,"d":0,"h":193274824962,"f":50331656},"n":"HasISerializable","d":1296642,"h":188979857666,"f":2097160},{"p":262145,"g":{"r":0,"d":0,"h":201864759554,"f":50331656},"n":"HasSurrogate","d":1296642,"h":197569792258,"f":2097160},{"p":262145,"g":{"r":0,"d":0,"h":210454694146,"f":50331656},"n":"CanSurrogatedObjectValueChange","d":1296642,"h":206159726850,"f":2097160},{"p":262145,"g":{"r":0,"d":0,"h":219044628738,"f":50331656},"n":"CanObjectValueChange","d":1296642,"h":214749661442,"f":2097160},{"p":655361,"g":{"r":0,"d":0,"h":227634563330,"f":50331656},"n":"DirectlyDependentObjects","d":1296642,"h":223339596034,"f":2097160},{"p":655361,"g":{"r":0,"d":0,"h":236224497922,"f":50331656},"n":"TotalDependentObjects","d":1296642,"h":231929530626,"f":2097160},{"p":262145,"g":{"r":0,"d":0,"h":244814432514,"f":50331656},"s":{"r":0,"d":0,"h":249109399810,"f":83886088},"n":"Reachable","d":1296642,"h":240519465218,"f":2097160},{"p":262145,"g":{"r":0,"d":0,"h":257699334402,"f":50331656},"n":"TypeLoadExceptionReachable","d":1296642,"h":253404367106,"f":2097160},{"p":131073,"g":{"r":0,"d":0,"h":279174170882,"f":50331656},"n":"ObjectValue","d":1296642,"h":274879203586,"f":2097160},{"p":113836033,"g":{"r":0,"d":0,"h":292059072770,"f":50331656},"s":{"r":0,"d":0,"h":296354040066,"f":83886088},"n":"SerializationInfo","d":1296642,"h":287764105474,"f":2097160},{"p":1034498,"g":{"r":0,"d":0,"h":304943974658,"f":50331656},"n":"Surrogate","d":1296642,"h":300649007362,"f":2097160},{"p":1165570,"g":{"r":0,"d":0,"h":313533909250,"f":50331656},"s":{"r":0,"d":0,"h":317828876546,"f":83886088},"n":"DependentObjects","d":1296642,"h":309238941954,"f":2097160},{"p":262145,"g":{"r":0,"d":0,"h":326418811138,"f":50331656},"s":{"r":0,"d":0,"h":330713778434,"f":83886088},"n":"RequiresSerInfoFixup","d":1296642,"h":322123843842,"f":2097160},{"p":2410754,"g":{"r":0,"d":0,"h":339303713026,"f":50331656},"n":"ValueFixup","d":1296642,"h":335008745730,"f":2097160},{"p":262145,"g":{"r":0,"d":0,"h":347893647618,"f":50331656},"n":"CompletelyFixed","d":1296642,"h":343598680322,"f":2097160},{"p":917505,"g":{"r":0,"d":0,"h":356483582210,"f":50331656},"n":"ContainerID","d":1296642,"h":352188614914,"f":2097160}],"m":[{"r":65537,"p":[{"n":"amount","p":655361}],"n":"IncrementDescendentFixups","d":1296642,"h":107375479042,"f":16777218},{"r":65537,"p":[{"n":"manager","p":1558786}],"n":"DecrementFixupsRemaining","d":1296642,"h":111670446338,"f":16777224},{"r":65537,"p":[{"n":"id","p":917505}],"n":"RemoveDependency","d":1296642,"h":115965413634,"f":16777224},{"r":65537,"p":[{"n":"fixup","p":313602},{"n":"manager","p":1558786}],"n":"AddFixup","d":1296642,"h":120260380930,"f":16777224},{"r":65537,"p":[{"n":"amount","p":655361},{"n":"manager","p":1558786}],"n":"UpdateDescendentDependencyChain","d":1296642,"h":124555348226,"f":16777218},{"r":65537,"p":[{"n":"dependentObject","p":917505}],"n":"AddDependency","d":1296642,"h":128850315522,"f":16777224},{"r":65537,"p":[{"n":"obj","p":131073},{"n":"info","p":113836033},{"n":"surrogate","p":1034498},{"n":"idOfContainer","p":917505},{"n":"field","p":76677121},{"n":"arrayIndex","p":$.$typeArray($.$$.System.Int32).$h},{"n":"manager","p":1558786}],"n":"UpdateData","d":1296642,"h":133145282818,"f":16777224},{"r":65537,"n":"MarkForCompletionWhenAvailable","d":1296642,"h":137440250114,"f":16777224},{"r":65537,"n":"SetFlags","d":1296642,"h":141735217410,"f":16777224},{"r":65537,"p":[{"n":"obj","p":131073},{"n":"manager","p":1558786}],"n":"SetObjectValue","d":1296642,"h":283469138178,"f":16777224}],"l":[{"t":655361,"n":"IncompleteObjectReference","d":1296642,"h":4296263938,"f":4194344},{"t":655361,"n":"HAS_ISERIALIZABLE","d":1296642,"h":8591231234,"f":4194344},{"t":655361,"n":"HAS_SURROGATE","d":1296642,"h":12886198530,"f":4194344},{"t":655361,"n":"REQUIRES_VALUETYPE_FIXUP","d":1296642,"h":17181165826,"f":4194344},{"t":655361,"n":"REQUIRES_DELAYED_FIXUP","d":1296642,"h":21476133122,"f":4194344},{"t":655361,"n":"SER_INFO_FIXED","d":1296642,"h":25771100418,"f":4194344},{"t":655361,"n":"VALUETYPE_FIXUP_PERFORMED","d":1296642,"h":30066067714,"f":4194344},{"t":131073,"n":"_object","d":1296642,"h":34361035010,"f":4194306},{"t":917505,"n":"_id","d":1296642,"h":38656002306,"f":4194312},{"t":655361,"n":"_missingElementsRemaining","d":1296642,"h":42950969602,"f":4194306},{"t":655361,"n":"_missingDecendents","d":1296642,"h":47245936898,"f":4194306},{"t":113836033,"n":"_serInfo","d":1296642,"h":51540904194,"f":4194312},{"t":1034498,"n":"_surrogate","d":1296642,"h":55835871490,"f":4194312},{"t":379138,"n":"_missingElements","d":1296642,"h":60130838786,"f":4194312},{"t":1165570,"n":"_dependentObjects","d":1296642,"h":64425806082,"f":4194312},{"t":1296642,"n":"_next","d":1296642,"h":68720773378,"f":4194312},{"t":655361,"n":"_flags","d":1296642,"h":73015740674,"f":4194312},{"t":262145,"n":"_markForFixupWhenAvailable","d":1296642,"h":77310707970,"f":4194306},{"t":2410754,"n":"_valueFixup","d":1296642,"h":81605675266,"f":4194306},{"t":2345218,"n":"_typeLoad","d":1296642,"h":85900642562,"f":4194306},{"t":262145,"n":"_reachable","d":1296642,"h":90195609858,"f":4194306}],"c":[{"p":[{"n":"objID","p":917505}],"n":".ctor","o":"$ctor$1","d":1296642,"h":94490577154,"f":16777224},{"p":[{"n":"obj","p":131073},{"n":"objID","p":917505},{"n":"info","p":113836033},{"n":"surrogate","p":1034498},{"n":"idOfContainingObj","p":917505},{"n":"field","p":76677121},{"n":"arrayIndex","p":$.$typeArray($.$$.System.Int32).$h}],"n":".ctor","o":"$ctor$2","d":1296642,"h":98785544450,"f":16777224},{"p":[{"n":"obj","p":1310721},{"n":"objID","p":917505},{"n":"info","p":113836033},{"n":"surrogate","p":1034498},{"n":"idOfContainingObj","p":917505},{"n":"field","p":76677121},{"n":"arrayIndex","p":$.$typeArray($.$$.System.Int32).$h}],"n":".ctor","o":"$ctor$3","d":1296642,"h":103080511746,"f":16777224}],"h":1296642}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `System.Runtime.Serialization.ObjectHolder`; }
        });
        
        $asm.$cls("$srsf.System.Runtime.Serialization.FixupHolder", ($self) => class FixupHolder extends $.$$.System.Object
        {
            /*int*/ static ArrayFixup = 1;
            /*int*/ static MemberFixup = 2;
            /*int*/ static DelayedFixup = 4;
            /*long*/ _id = 0n;
            /*object*/ _fixupInfo = null;
            /*int*/ _fixupType = 0;
            $ctor$1(/*long*/ id, /*object*/ fixupInfo, /*int*/ fixupType)
            {
                super.$ctor();
                {
                    $.$$.System.Diagnostics.Debug.Assert$2(id > 0n, "id>0");
                    $.$$.System.Diagnostics.Debug.Assert$2(fixupInfo !== null, "fixupInfo!=null");
                    $.$$.System.Diagnostics.Debug.Assert$2(fixupType === 1/*ArrayFixup*/ || fixupType === 2/*MemberFixup*/ || fixupType === 4/*DelayedFixup*/, "fixupType==ArrayFixup || fixupType == MemberFixup || fixupType==DelayedFixup");
                    this._id = id;
                    this._fixupInfo = fixupInfo;
                    this._fixupType = fixupType;
                }
                return this;
            }
            static $h = 313602;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"l":[{"t":655361,"n":"ArrayFixup","d":313602,"h":4295280898,"f":4194344},{"t":655361,"n":"MemberFixup","d":313602,"h":8590248194,"f":4194344},{"t":655361,"n":"DelayedFixup","d":313602,"h":12885215490,"f":4194344},{"t":917505,"n":"_id","d":313602,"h":17180182786,"f":4194312},{"t":131073,"n":"_fixupInfo","d":313602,"h":21475150082,"f":4194312},{"t":655361,"n":"_fixupType","d":313602,"h":25770117378,"f":4194312}],"c":[{"p":[{"n":"id","p":917505},{"n":"fixupInfo","p":131073},{"n":"fixupType","p":655361}],"n":".ctor","o":"$ctor$1","d":313602,"h":30065084674,"f":16777224}],"h":313602}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `System.Runtime.Serialization.FixupHolder`; }
        });
        
        $asm.$cls("$srsf.System.Runtime.Serialization.FixupHolderList", ($self) => class FixupHolderList extends $.$$.System.Object
        {
            /*int*/ static InitialSize = 2;
            /*FixupHolder?[]*/ _values = null;
            /*int*/ _count = 0;
            $ctor$1()
            {
                this.$ctor$2(2/*InitialSize*/);
                {
                }
                return this;
            }
            $ctor$2(/*int*/ startingSize)
            {
                super.$ctor();
                {
                    this._count = 0;
                    this._values = $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$srsf.System.Runtime.Serialization.FixupHolder), null, [startingSize], null);
                }
                return this;
            }
            /*void */ Add(/*FixupHolder*/ fixup)
            {
                if (this._count === this._values.length)
                {
                    this.EnlargeArray();
                }
                $.$$.System.Array.$WriteT1.call(this._values, fixup, this._count++);
            }
            /*void */ EnlargeArray()
            {
                /*int*/ let newLength = ((this._values.length * 2) | 0);
                if (newLength < 0)
                {
                    newLength = 2147483647/*int.MaxValue*/;
                }
                /*FixupHolder[]*/ let temp = $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$srsf.System.Runtime.Serialization.FixupHolder), null, [newLength], null);
                $.$$.System.Array.Copy(this._values, temp, this._count);
                this._values = temp;
            }
            static $h = 379138;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"m":[{"r":65537,"p":[{"n":"fixup","p":313602}],"n":"Add","d":379138,"h":25770182914,"f":16777224},{"r":65537,"n":"EnlargeArray","d":379138,"h":30065150210,"f":16777218}],"l":[{"t":655361,"n":"InitialSize","d":379138,"h":4295346434,"f":4194344},{"t":$.$typeArray($.$srsf.System.Runtime.Serialization.FixupHolder).$h,"n":"_values","d":379138,"h":8590313730,"f":4194312},{"t":655361,"n":"_count","d":379138,"h":12885281026,"f":4194312}],"c":[{"n":".ctor","o":"$ctor$1","d":379138,"h":17180248322,"f":16777224},{"p":[{"n":"startingSize","p":655361}],"n":".ctor","o":"$ctor$2","d":379138,"h":21475215618,"f":16777224}],"h":379138}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `System.Runtime.Serialization.FixupHolderList`; }
        });
        
        $asm.$cls("$srsf.System.Runtime.Serialization.LongList", ($self) => class LongList extends $.$$.System.Object
        {
            /*int*/ static InitialSize = 2;
            /*long[]*/ _values = null;
            /*int*/ _count = 0;
            /*int*/ _totalItems = 0;
            /*int*/ _currentItem = 0;
            $ctor$1()
            {
                this.$ctor$2(2/*InitialSize*/);
                {
                }
                return this;
            }
            $ctor$2(/*int*/ startingSize)
            {
                super.$ctor();
                {
                    this._count = 0;
                    this._totalItems = 0;
                    this._values = $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$$.System.Int64), null, [startingSize], null);
                }
                return this;
            }
            /*void */ Add(/*long*/ value)
            {
                if (this._totalItems === this._values.length)
                {
                    this.EnlargeArray();
                }
                $.$$.System.Array.$WriteT1.call(this._values, value, this._totalItems++);
                this._count++;
            }
            /*int */ get Count()
            {
                return this._count;
            }
            /*void */ StartEnumeration()
            {
                return this._currentItem = -1;
            }
            /*bool */ MoveNext()
            {
                while(++this._currentItem < this._totalItems && $.$$.System.Array.$ReadT1.call(this._values, this._currentItem) === BigInt(-1))
                {
                }
                return this._currentItem !== this._totalItems;
            }
            /*long */ get Current()
            {
                $.$$.System.Diagnostics.Debug.Assert$2(this._currentItem !== -1, "[LongList.Current]m_currentItem!=-1");
                $.$$.System.Diagnostics.Debug.Assert$2($.$$.System.Array.$ReadT1.call(this._values, this._currentItem) !== BigInt(-1), "[LongList.Current]m_values[m_currentItem]!=-1");
                return $.$$.System.Array.$ReadT1.call(this._values, this._currentItem);
            }
            /*bool */ RemoveElement(/*long*/ value)
            {
                /*int*/ let i;
                for(i = 0; i < this._totalItems; i++)
                {
                    if ($.$$.System.Array.$ReadT1.call(this._values, i) === value)
                    {
                        break;
                    }
                }
                if (i === this._totalItems)
                {
                    return false;
                }
                $.$$.System.Array.$WriteT1.call(this._values, BigInt(-1), i);
                return true;
            }
            /*void */ EnlargeArray()
            {
                /*int*/ let newLength = ((this._values.length * 2) | 0);
                if (newLength < 0)
                {
                    newLength = 2147483647/*int.MaxValue*/;
                }
                /*long[]*/ let temp = $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$$.System.Int64), null, [newLength], null);
                $.$$.System.Array.Copy(this._values, temp, this._count);
                this._values = temp;
            }
            static $h = 1165570;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":655361,"g":{"r":0,"d":0,"h":42950838530,"f":50331656},"n":"Count","d":1165570,"h":38655871234,"f":2097160},{"p":917505,"g":{"r":0,"d":0,"h":60130707714,"f":50331656},"n":"Current","d":1165570,"h":55835740418,"f":2097160}],"m":[{"r":65537,"p":[{"n":"value","p":917505}],"n":"Add","d":1165570,"h":34360903938,"f":16777224},{"r":65537,"n":"StartEnumeration","d":1165570,"h":47245805826,"f":16777224},{"r":262145,"n":"MoveNext","d":1165570,"h":51540773122,"f":16777224},{"r":262145,"p":[{"n":"value","p":917505}],"n":"RemoveElement","d":1165570,"h":64425675010,"f":16777224},{"r":65537,"n":"EnlargeArray","d":1165570,"h":68720642306,"f":16777218}],"l":[{"t":655361,"n":"InitialSize","d":1165570,"h":4296132866,"f":4194338},{"t":$.$typeArray($.$$.System.Int64).$h,"n":"_values","d":1165570,"h":8591100162,"f":4194306},{"t":655361,"n":"_count","d":1165570,"h":12886067458,"f":4194306},{"t":655361,"n":"_totalItems","d":1165570,"h":17181034754,"f":4194306},{"t":655361,"n":"_currentItem","d":1165570,"h":21476002050,"f":4194306}],"c":[{"n":".ctor","o":"$ctor$1","d":1165570,"h":25770969346,"f":16777224},{"p":[{"n":"startingSize","p":655361}],"n":".ctor","o":"$ctor$2","d":1165570,"h":30065936642,"f":16777224}],"h":1165570}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `System.Runtime.Serialization.LongList`; }
        });
        
        $asm.$cls("$srsf.System.Runtime.Serialization.ObjectHolderList", ($self) => class ObjectHolderList extends $.$$.System.Object
        {
            /*int*/ static DefaultInitialSize = 8;
            /*ObjectHolder[]*/ _values = null;
            /*int*/ _count = 0;
            $ctor$1()
            {
                this.$ctor$2(8/*DefaultInitialSize*/);
                {
                }
                return this;
            }
            $ctor$2(/*int*/ startingSize)
            {
                super.$ctor();
                {
                    $.$$.System.Diagnostics.Debug.Assert$2(startingSize > 0 && startingSize < 4096, "startingSize>0 && startingSize<0x1000");
                    this._count = 0;
                    this._values = $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$srsf.System.Runtime.Serialization.ObjectHolder), null, [startingSize], null);
                }
                return this;
            }
            /*void */ Add(/*ObjectHolder*/ value)
            {
                if (this._count === this._values.length)
                {
                    this.EnlargeArray();
                }
                $.$$.System.Array.$WriteT1.call(this._values, value, this._count++);
            }
            /*ObjectHolderListEnumerator */ GetFixupEnumerator()
            {
                return new $.$srsf.System.Runtime.Serialization.ObjectHolderListEnumerator().$ctor$1(this, true);
            }
            /*void */ EnlargeArray()
            {
                /*int*/ let newLength = ((this._values.length * 2) | 0);
                if (newLength < 0)
                {
                    newLength = 2147483647/*int.MaxValue*/;
                }
                /*ObjectHolder[]*/ let temp = $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$srsf.System.Runtime.Serialization.ObjectHolder), null, [newLength], null);
                $.$$.System.Array.Copy(this._values, temp, this._count);
                this._values = temp;
            }
            /*int */ get Version()
            {
                return this._count;
            }
            /*int */ get Count()
            {
                return this._count;
            }
            static $h = 1362178;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":655361,"g":{"r":0,"d":0,"h":42951035138,"f":50331656},"n":"Version","d":1362178,"h":38656067842,"f":2097160},{"p":655361,"g":{"r":0,"d":0,"h":51540969730,"f":50331656},"n":"Count","d":1362178,"h":47246002434,"f":2097160}],"m":[{"r":65537,"p":[{"n":"value","p":1296642}],"n":"Add","d":1362178,"h":25771165954,"f":16777224},{"r":1427714,"n":"GetFixupEnumerator","d":1362178,"h":30066133250,"f":16777224},{"r":65537,"n":"EnlargeArray","d":1362178,"h":34361100546,"f":16777218}],"l":[{"t":655361,"n":"DefaultInitialSize","d":1362178,"h":4296329474,"f":4194344},{"t":$.$typeArray($.$srsf.System.Runtime.Serialization.ObjectHolder).$h,"n":"_values","d":1362178,"h":8591296770,"f":4194312},{"t":655361,"n":"_count","d":1362178,"h":12886264066,"f":4194312}],"c":[{"n":".ctor","o":"$ctor$1","d":1362178,"h":17181231362,"f":16777224},{"p":[{"n":"startingSize","p":655361}],"n":".ctor","o":"$ctor$2","d":1362178,"h":21476198658,"f":16777224}],"h":1362178}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `System.Runtime.Serialization.ObjectHolderList`; }
        });
        
        $asm.$cls("$srsf.System.Runtime.Serialization.ObjectHolderListEnumerator", ($self) => class ObjectHolderListEnumerator extends $.$$.System.Object
        {
            /*bool*/ _isFixupEnumerator = false;
            /*ObjectHolderList*/ _list = null;
            /*int*/ _startingVersion = 0;
            /*int*/ _currPos = 0;
            $ctor$1(/*ObjectHolderList*/ list, /*bool*/ isFixupEnumerator)
            {
                super.$ctor();
                {
                    $.$$.System.Diagnostics.Debug.Assert$2(list !== null, "[ObjectHolderListEnumerator.ctor]list!=null");
                    this._list = list;
                    this._startingVersion = this._list.Version;
                    this._currPos = -1;
                    this._isFixupEnumerator = isFixupEnumerator;
                }
                return this;
            }
            /*bool */ MoveNext()
            {
                $.$$.System.Diagnostics.Debug.Assert$2(this._startingVersion === this._list.Version, "[ObjectHolderListEnumerator.MoveNext]m_startingVersion==m_list.Version");
                if (this._isFixupEnumerator)
                {
                    while(++this._currPos < this._list.Count && $.$$.System.Array.$ReadT1.call(this._list._values, this._currPos).CompletelyFixed)
                    {
                    }
                    return this._currPos !== this._list.Count;
                }
                else 
                {
                    this._currPos++;
                    return this._currPos !== this._list.Count;
                }
            }
            /*ObjectHolder */ get Current()
            {
                $.$$.System.Diagnostics.Debug.Assert$2(this._currPos !== -1, "[ObjectHolderListEnumerator.Current]m_currPos!=-1");
                $.$$.System.Diagnostics.Debug.Assert$2(this._currPos < this._list.Count, "[ObjectHolderListEnumerator.Current]m_currPos<m_list.Count");
                $.$$.System.Diagnostics.Debug.Assert$2(this._startingVersion === this._list.Version, "[ObjectHolderListEnumerator.Current]m_startingVersion==m_list.Version");
                return $.$$.System.Array.$ReadT1.call(this._list._values, this._currPos);
            }
            static $h = 1427714;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":1296642,"g":{"r":0,"d":0,"h":34361166082,"f":50331656},"n":"Current","d":1427714,"h":30066198786,"f":2097160}],"m":[{"r":262145,"n":"MoveNext","d":1427714,"h":25771231490,"f":16777224}],"l":[{"t":262145,"n":"_isFixupEnumerator","d":1427714,"h":4296395010,"f":4194306},{"t":1362178,"n":"_list","d":1427714,"h":8591362306,"f":4194306},{"t":655361,"n":"_startingVersion","d":1427714,"h":12886329602,"f":4194306},{"t":655361,"n":"_currPos","d":1427714,"h":17181296898,"f":4194306}],"c":[{"p":[{"n":"list","p":1362178},{"n":"isFixupEnumerator","p":262145}],"n":".ctor","o":"$ctor$1","d":1427714,"h":21476264194,"f":16777224}],"h":1427714}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `System.Runtime.Serialization.ObjectHolderListEnumerator`; }
        });
        
        $asm.$cls("$srsf.System.Runtime.Serialization.TypeLoadExceptionHolder", ($self) => class TypeLoadExceptionHolder extends $.$$.System.Object
        {
            $ctor$1(/*string?*/ typeName)
            {
                super.$ctor();
                {
                    this.TypeName = typeName;
                }
                return this;
            }
            /*string?*/ TypeName = null;
            static $h = 2345218;
            static $f = 0b10010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":1310721,"g":{"r":0,"d":0,"h":17182214402,"f":50331656},"n":"TypeName","d":2345218,"h":12887247106,"f":2097160}],"c":[{"p":[{"n":"typeName","p":1310721}],"n":".ctor","o":"$ctor$1","d":2345218,"h":4297312514,"f":16777224}],"h":2345218}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `System.Runtime.Serialization.TypeLoadExceptionHolder`; }
        });
        
        $asm.$cls("$srsf.System.Runtime.Serialization.SerializationInfoExtensions", ($self) => class SerializationInfoExtensions
        {
            /*Action<SerializationInfo, string, object, Type>*/ static s_updateValue = null;
            static /*void */ UpdateValue(/*this SerializationInfo*/ si, /*string*/ name, /*object*/ value, /*Type*/ type)
            {
                return $.$srsf.System.Runtime.Serialization.SerializationInfoExtensions.s_updateValue.Invoke(si, name, value, type);
            }
            //Static Initializer
            static $sinit()
            {
                {
                    this.s_updateValue = $.$$.System.Runtime.Serialization.SerializationInfo.$type.GetMethod$9("UpdateValue", 16/*BindingFlags.Public*/ | 32/*BindingFlags.NonPublic*/ | 4/*BindingFlags.Instance*/).CreateDelegate$2($.$$.System.Action$$$$$($.$$.System.Runtime.Serialization.SerializationInfo, $.$$.System.String, $.$$.System.Object, $.$$.System.Type));
                }
            }
            static $h = 1952002;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"m":[{"r":65537,"p":[{"n":"si","p":113836033},{"n":"name","p":1310721},{"n":"value","p":131073},{"n":"type","p":142475265}],"n":"UpdateValue","d":1952002,"h":8591886594,"f":16777249}],"l":[{"t":$.$$.System.Action$$$$$($.$$.System.Runtime.Serialization.SerializationInfo, $.$$.System.String, $.$$.System.Object, $.$$.System.Type).$h,"n":"s_updateValue","d":1952002,"h":4296919298,"f":4194338}],"h":1952002}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `System.Runtime.Serialization.SerializationInfoExtensions`; }
        });
        
        $asm.$cls("$srsf.System.Runtime.Serialization.FormatterConverter", ($self) => class FormatterConverter extends $.$$.System.Object
        {
            /*object */ Convert(/*object*/ value, /*Type*/ type)
            {
                $.$$.System.ArgumentNullException.ThrowIfNull$2(value, "value");
                return $.$$.System.Convert.ChangeType(value, type, $.$$.System.Globalization.CultureInfo.InvariantCulture);
            }
            /*object */ Convert$1(/*object*/ value, /*TypeCode*/ typeCode)
            {
                $.$$.System.ArgumentNullException.ThrowIfNull$2(value, "value");
                return $.$$.System.Convert.ChangeType$2(value, typeCode, $.$$.System.Globalization.CultureInfo.InvariantCulture);
            }
            /*bool */ ToBoolean(/*object*/ value)
            {
                $.$$.System.ArgumentNullException.ThrowIfNull$2(value, "value");
                return $.$$.System.Convert.ToBoolean$9(value, $.$$.System.Globalization.CultureInfo.InvariantCulture);
            }
            /*char */ ToChar(/*object*/ value)
            {
                $.$$.System.ArgumentNullException.ThrowIfNull$2(value, "value");
                return $.$$.System.Convert.ToChar$9(value, $.$$.System.Globalization.CultureInfo.InvariantCulture);
            }
            /*sbyte */ ToSByte(/*object*/ value)
            {
                $.$$.System.ArgumentNullException.ThrowIfNull$2(value, "value");
                return $.$$.System.Convert.ToSByte$9(value, $.$$.System.Globalization.CultureInfo.InvariantCulture);
            }
            /*byte */ ToByte(/*object*/ value)
            {
                $.$$.System.ArgumentNullException.ThrowIfNull$2(value, "value");
                return $.$$.System.Convert.ToByte$9(value, $.$$.System.Globalization.CultureInfo.InvariantCulture);
            }
            /*short */ ToInt16(/*object*/ value)
            {
                $.$$.System.ArgumentNullException.ThrowIfNull$2(value, "value");
                return $.$$.System.Convert.ToInt16$9(value, $.$$.System.Globalization.CultureInfo.InvariantCulture);
            }
            /*ushort */ ToUInt16(/*object*/ value)
            {
                $.$$.System.ArgumentNullException.ThrowIfNull$2(value, "value");
                return $.$$.System.Convert.ToUInt16$9(value, $.$$.System.Globalization.CultureInfo.InvariantCulture);
            }
            /*int */ ToInt32(/*object*/ value)
            {
                $.$$.System.ArgumentNullException.ThrowIfNull$2(value, "value");
                return $.$$.System.Convert.ToInt32$9(value, $.$$.System.Globalization.CultureInfo.InvariantCulture);
            }
            /*uint */ ToUInt32(/*object*/ value)
            {
                $.$$.System.ArgumentNullException.ThrowIfNull$2(value, "value");
                return $.$$.System.Convert.ToUInt32$9(value, $.$$.System.Globalization.CultureInfo.InvariantCulture);
            }
            /*long */ ToInt64(/*object*/ value)
            {
                $.$$.System.ArgumentNullException.ThrowIfNull$2(value, "value");
                return $.$$.System.Convert.ToInt64$9(value, $.$$.System.Globalization.CultureInfo.InvariantCulture);
            }
            /*ulong */ ToUInt64(/*object*/ value)
            {
                $.$$.System.ArgumentNullException.ThrowIfNull$2(value, "value");
                return $.$$.System.Convert.ToUInt64$9(value, $.$$.System.Globalization.CultureInfo.InvariantCulture);
            }
            /*float */ ToSingle(/*object*/ value)
            {
                $.$$.System.ArgumentNullException.ThrowIfNull$2(value, "value");
                return $.$$.System.Convert.ToSingle$9(value, $.$$.System.Globalization.CultureInfo.InvariantCulture);
            }
            /*double */ ToDouble(/*object*/ value)
            {
                $.$$.System.ArgumentNullException.ThrowIfNull$2(value, "value");
                return $.$$.System.Convert.ToDouble$9(value, $.$$.System.Globalization.CultureInfo.InvariantCulture);
            }
            /*decimal */ ToDecimal(/*object*/ value)
            {
                $.$$.System.ArgumentNullException.ThrowIfNull$2(value, "value");
                return $.$$.System.Convert.ToDecimal$9(value, $.$$.System.Globalization.CultureInfo.InvariantCulture);
            }
            /*DateTime */ ToDateTime(/*object*/ value)
            {
                $.$$.System.ArgumentNullException.ThrowIfNull$2(value, "value");
                return $.$$.System.Convert.ToDateTime$9(value, $.$$.System.Globalization.CultureInfo.InvariantCulture);
            }
            /*string? */ ToString$1(/*object*/ value)
            {
                $.$$.System.ArgumentNullException.ThrowIfNull$2(value, "value");
                return $.$$.System.Convert.ToString$23(value, $.$$.System.Globalization.CultureInfo.InvariantCulture);
            }
            //Generated interface implemetation for System.Runtime.Serialization.IFormatterConverter.Convert(object, System.Type)
            System$Runtime$Serialization$IFormatterConverter$Convert()
            {
                return this.Convert(...arguments);
            }
            //Generated interface implemetation for System.Runtime.Serialization.IFormatterConverter.Convert(object, System.TypeCode)
            System$Runtime$Serialization$IFormatterConverter$Convert$1()
            {
                return this.Convert$1(...arguments);
            }
            //Generated interface implemetation for System.Runtime.Serialization.IFormatterConverter.ToBoolean(object)
            System$Runtime$Serialization$IFormatterConverter$ToBoolean()
            {
                return this.ToBoolean(...arguments);
            }
            //Generated interface implemetation for System.Runtime.Serialization.IFormatterConverter.ToChar(object)
            System$Runtime$Serialization$IFormatterConverter$ToChar()
            {
                return this.ToChar(...arguments);
            }
            //Generated interface implemetation for System.Runtime.Serialization.IFormatterConverter.ToSByte(object)
            System$Runtime$Serialization$IFormatterConverter$ToSByte()
            {
                return this.ToSByte(...arguments);
            }
            //Generated interface implemetation for System.Runtime.Serialization.IFormatterConverter.ToByte(object)
            System$Runtime$Serialization$IFormatterConverter$ToByte()
            {
                return this.ToByte(...arguments);
            }
            //Generated interface implemetation for System.Runtime.Serialization.IFormatterConverter.ToInt16(object)
            System$Runtime$Serialization$IFormatterConverter$ToInt16()
            {
                return this.ToInt16(...arguments);
            }
            //Generated interface implemetation for System.Runtime.Serialization.IFormatterConverter.ToUInt16(object)
            System$Runtime$Serialization$IFormatterConverter$ToUInt16()
            {
                return this.ToUInt16(...arguments);
            }
            //Generated interface implemetation for System.Runtime.Serialization.IFormatterConverter.ToInt32(object)
            System$Runtime$Serialization$IFormatterConverter$ToInt32()
            {
                return this.ToInt32(...arguments);
            }
            //Generated interface implemetation for System.Runtime.Serialization.IFormatterConverter.ToUInt32(object)
            System$Runtime$Serialization$IFormatterConverter$ToUInt32()
            {
                return this.ToUInt32(...arguments);
            }
            //Generated interface implemetation for System.Runtime.Serialization.IFormatterConverter.ToInt64(object)
            System$Runtime$Serialization$IFormatterConverter$ToInt64()
            {
                return this.ToInt64(...arguments);
            }
            //Generated interface implemetation for System.Runtime.Serialization.IFormatterConverter.ToUInt64(object)
            System$Runtime$Serialization$IFormatterConverter$ToUInt64()
            {
                return this.ToUInt64(...arguments);
            }
            //Generated interface implemetation for System.Runtime.Serialization.IFormatterConverter.ToSingle(object)
            System$Runtime$Serialization$IFormatterConverter$ToSingle()
            {
                return this.ToSingle(...arguments);
            }
            //Generated interface implemetation for System.Runtime.Serialization.IFormatterConverter.ToDouble(object)
            System$Runtime$Serialization$IFormatterConverter$ToDouble()
            {
                return this.ToDouble(...arguments);
            }
            //Generated interface implemetation for System.Runtime.Serialization.IFormatterConverter.ToDecimal(object)
            System$Runtime$Serialization$IFormatterConverter$ToDecimal()
            {
                return this.ToDecimal(...arguments);
            }
            //Generated interface implemetation for System.Runtime.Serialization.IFormatterConverter.ToDateTime(object)
            System$Runtime$Serialization$IFormatterConverter$ToDateTime()
            {
                return this.ToDateTime(...arguments);
            }
            //Generated interface implemetation for System.Runtime.Serialization.IFormatterConverter.ToString(object)
            System$Runtime$Serialization$IFormatterConverter$ToString()
            {
                return this.ToString$1(...arguments);
            }
            //default reference type constructor overload
            $ctor$1()
            {
                super.$ctor();
                return this;
            }
            static $h = 510210;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"m":[{"r":131073,"p":[{"n":"value","p":131073},{"n":"type","p":142475265}],"n":"Convert","d":510210,"h":4295477506,"f":16777217},{"r":131073,"p":[{"n":"value","p":131073},{"n":"typeCode","p":142606337}],"n":"Convert","o":"@$1","d":510210,"h":8590444802,"f":16777217},{"r":262145,"p":[{"n":"value","p":131073}],"n":"ToBoolean","d":510210,"h":12885412098,"f":16777217},{"r":458753,"p":[{"n":"value","p":131073}],"n":"ToChar","d":510210,"h":17180379394,"f":16777217},{"r":327681,"p":[{"n":"value","p":131073}],"n":"ToSByte","d":510210,"h":21475346690,"f":16777217,"a":[{"t":23527425,"c":8613462017,"a":[{"v":false,"t":262145}]}]},{"r":393217,"p":[{"n":"value","p":131073}],"n":"ToByte","d":510210,"h":25770313986,"f":16777217},{"r":524289,"p":[{"n":"value","p":131073}],"n":"ToInt16","d":510210,"h":30065281282,"f":16777217},{"r":589825,"p":[{"n":"value","p":131073}],"n":"ToUInt16","d":510210,"h":34360248578,"f":16777217,"a":[{"t":23527425,"c":8613462017,"a":[{"v":false,"t":262145}]}]},{"r":655361,"p":[{"n":"value","p":131073}],"n":"ToInt32","d":510210,"h":38655215874,"f":16777217},{"r":720897,"p":[{"n":"value","p":131073}],"n":"ToUInt32","d":510210,"h":42950183170,"f":16777217,"a":[{"t":23527425,"c":8613462017,"a":[{"v":false,"t":262145}]}]},{"r":917505,"p":[{"n":"value","p":131073}],"n":"ToInt64","d":510210,"h":47245150466,"f":16777217},{"r":983041,"p":[{"n":"value","p":131073}],"n":"ToUInt64","d":510210,"h":51540117762,"f":16777217,"a":[{"t":23527425,"c":8613462017,"a":[{"v":false,"t":262145}]}]},{"r":1114113,"p":[{"n":"value","p":131073}],"n":"ToSingle","d":510210,"h":55835085058,"f":16777217},{"r":1179649,"p":[{"n":"value","p":131073}],"n":"ToDouble","d":510210,"h":60130052354,"f":16777217},{"r":35127297,"p":[{"n":"value","p":131073}],"n":"ToDecimal","d":510210,"h":64425019650,"f":16777217},{"r":34275329,"p":[{"n":"value","p":131073}],"n":"ToDateTime","d":510210,"h":68719986946,"f":16777217},{"r":1310721,"p":[{"n":"value","p":131073}],"n":"ToString","o":"@$1","d":510210,"h":73014954242,"f":16777217}],"c":[{"n":".ctor","o":"$ctor$1","d":510210,"h":77309921538,"f":16777217}],"i":[113049601],"h":510210,"a":[{"t":70909953,"c":8660844545,"a":[{"v":"Formatter-based serialization is obsolete and should not be used.","t":1310721}],"n":[{"n":"DiagnosticId","v":"SYSLIB0050","t":1310721},{"n":"UrlFormat","v":"https://aka.ms/dotnet-warnings/{0}","t":1310721}]}]}; }
            static get $b() { return $.$$.System.Object; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.System.Runtime.Serialization.IFormatterConverter ]; }
            static get $fullName() { return `System.Runtime.Serialization.FormatterConverter`; }
        });
        
        $asm.$cls("$srsf.System.Runtime.Serialization.SurrogateSelector", ($self) => class SurrogateSelector extends $.$$.System.Object
        {
            /*SurrogateHashtable*/ _surrogates = null;
            /*ISurrogateSelector?*/ _nextSelector = null;
            /*void */ AddSurrogate(/*Type*/ type, /*StreamingContext*/ context, /*ISerializationSurrogate*/ surrogate)
            {
                $.$$.System.ArgumentNullException.ThrowIfNull$2(type, "type");
                $.$$.System.ArgumentNullException.ThrowIfNull$2(surrogate, "surrogate");
                /*var*/ let key = new $.$srsf.System.Runtime.Serialization.SurrogateKey().$ctor$1(type, context);
                this._surrogates.Add(key, surrogate);
            }
            static /*bool */ HasCycle(/*ISurrogateSelector*/ selector)
            {
                $.$$.System.Diagnostics.Debug.Assert$2(selector !== null, "[HasCycle]selector!=null");
                /*ISurrogateSelector?*/ let head = selector, tail = selector;
                while(head !== null)
                {
                    head = head.System$Runtime$Serialization$ISurrogateSelector$GetNextSelector();
                    if (head === null)
                    {
                        return true;
                    }
                    if (head === tail)
                    {
                        return false;
                    }
                    head = head.System$Runtime$Serialization$ISurrogateSelector$GetNextSelector();
                    tail = tail.System$Runtime$Serialization$ISurrogateSelector$GetNextSelector();
                    if (head === tail)
                    {
                        return false;
                    }
                }
                return true;
            }
            /*void */ ChainSelector(/*ISurrogateSelector*/ selector)
            {
                $.$$.System.ArgumentNullException.ThrowIfNull$2(selector, "selector");
                if (selector === this)
                {
                    throw new $.$$.System.Runtime.Serialization.SerializationException().$ctor$12($.$srsf.System.SR.Serialization_SurrogateCycle);
                }
                if (!$.$srsf.System.Runtime.Serialization.SurrogateSelector.HasCycle(selector))
                {
                    throw new $.$$.System.ArgumentException().$ctor$13($.$srsf.System.SR.Serialization_SurrogateCycleInArgument, "selector");
                }
                /*ISurrogateSelector?*/ let tempCurr = selector.System$Runtime$Serialization$ISurrogateSelector$GetNextSelector();
                /*ISurrogateSelector*/ let tempEnd = selector;
                while(tempCurr !== null && tempCurr !== this)
                {
                    tempEnd = tempCurr;
                    tempCurr = tempCurr.System$Runtime$Serialization$ISurrogateSelector$GetNextSelector();
                }
                if (tempCurr === this)
                {
                    throw new $.$$.System.ArgumentException().$ctor$13($.$srsf.System.SR.Serialization_SurrogateCycle, "selector");
                }
                tempCurr = selector;
                /*ISurrogateSelector?*/ let tempPrev = selector;
                while(tempCurr !== null)
                {
                    if (tempCurr === tempEnd)
                    {
                        tempCurr = this.GetNextSelector();
                    }
                    else 
                    {
                        tempCurr = tempCurr.System$Runtime$Serialization$ISurrogateSelector$GetNextSelector();
                    }
                    if (tempCurr === null)
                    {
                        break;
                    }
                    if (tempCurr === tempPrev)
                    {
                        throw new $.$$.System.ArgumentException().$ctor$13($.$srsf.System.SR.Serialization_SurrogateCycle, "selector");
                    }
                    if (tempCurr === tempEnd)
                    {
                        tempCurr = this.GetNextSelector();
                    }
                    else 
                    {
                        tempCurr = tempCurr.System$Runtime$Serialization$ISurrogateSelector$GetNextSelector();
                    }
                    if (tempPrev === tempEnd)
                    {
                        tempPrev = this.GetNextSelector();
                    }
                    else 
                    {
                        $.$$.System.Diagnostics.Debug.Assert$2(tempPrev !== null, "tempPrev != null");
                        tempPrev = tempPrev.System$Runtime$Serialization$ISurrogateSelector$GetNextSelector();
                    }
                    if (tempCurr === tempPrev)
                    {
                        throw new $.$$.System.ArgumentException().$ctor$13($.$srsf.System.SR.Serialization_SurrogateCycle, "selector");
                    }
                }
                /*ISurrogateSelector?*/ let temp = this._nextSelector;
                this._nextSelector = selector;
                if (temp !== null)
                {
                    tempEnd.System$Runtime$Serialization$ISurrogateSelector$ChainSelector(temp);
                }
            }
            /*ISurrogateSelector? */ GetNextSelector()
            {
                return this._nextSelector;
            }
            /*ISerializationSurrogate? */ GetSurrogate(/*Type*/ type, /*StreamingContext*/ context, /*out ISurrogateSelector*/ selector)
            {
                $.$$.System.ArgumentNullException.ThrowIfNull$2(type, "type");
                selector.$v = this;
                /*SurrogateKey*/ let key = new $.$srsf.System.Runtime.Serialization.SurrogateKey().$ctor$1(type, context);
                /*ISerializationSurrogate?*/ let temp = $.$cast(this._surrogates.get_Item(key), $.$srsf.System.Runtime.Serialization.ISerializationSurrogate);
                if (temp !== null)
                {
                    return temp;
                }
                if (this._nextSelector !== null)
                {
                    return this._nextSelector.System$Runtime$Serialization$ISurrogateSelector$GetSurrogate(type, context, selector);
                }
                return null;
            }
            /*void */ RemoveSurrogate(/*Type*/ type, /*StreamingContext*/ context)
            {
                $.$$.System.ArgumentNullException.ThrowIfNull$2(type, "type");
                /*SurrogateKey*/ let key = new $.$srsf.System.Runtime.Serialization.SurrogateKey().$ctor$1(type, context);
                this._surrogates.Remove(key);
            }
            //Generated interface implemetation for System.Runtime.Serialization.ISurrogateSelector.ChainSelector(System.Runtime.Serialization.ISurrogateSelector)
            System$Runtime$Serialization$ISurrogateSelector$ChainSelector()
            {
                return this.ChainSelector(...arguments);
            }
            //Generated interface implemetation for System.Runtime.Serialization.ISurrogateSelector.GetSurrogate(System.Type, System.Runtime.Serialization.StreamingContext, out System.Runtime.Serialization.ISurrogateSelector)
            System$Runtime$Serialization$ISurrogateSelector$GetSurrogate()
            {
                return this.GetSurrogate(...arguments);
            }
            //Generated interface implemetation for System.Runtime.Serialization.ISurrogateSelector.GetNextSelector()
            System$Runtime$Serialization$ISurrogateSelector$GetNextSelector()
            {
                return this.GetNextSelector(...arguments);
            }
            //default reference type constructor overload
            $ctor$1()
            {
                super.$ctor();
                return this;
            }
            //default member initializer
            constructor()
            {
                super();
                this._surrogates = new $.$srsf.System.Runtime.Serialization.SurrogateHashtable().$ctor$18(32);
            }
            static $h = 2279682;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"m":[{"r":65537,"p":[{"n":"type","p":142475265},{"n":"context","p":113967105},{"n":"surrogate","p":1034498}],"n":"AddSurrogate","d":2279682,"h":12887181570,"f":16777345},{"r":262145,"p":[{"n":"selector","p":1100034}],"n":"HasCycle","d":2279682,"h":17182148866,"f":16777250},{"r":65537,"p":[{"n":"selector","p":1100034}],"n":"ChainSelector","d":2279682,"h":21477116162,"f":16777345},{"r":1100034,"n":"GetNextSelector","d":2279682,"h":25772083458,"f":16777345},{"r":1034498,"p":[{"n":"type","p":142475265},{"n":"context","p":113967105},{"n":"selector","p":1100034,"f":2}],"n":"GetSurrogate","d":2279682,"h":30067050754,"f":16777345},{"r":65537,"p":[{"n":"type","p":142475265},{"n":"context","p":113967105}],"n":"RemoveSurrogate","d":2279682,"h":34362018050,"f":16777345}],"l":[{"t":2148610,"n":"_surrogates","d":2279682,"h":4297246978,"f":4194312},{"t":1100034,"n":"_nextSelector","d":2279682,"h":8592214274,"f":4194312}],"c":[{"n":".ctor","o":"$ctor$1","d":2279682,"h":38656985346,"f":16777217}],"i":[1100034],"h":2279682,"a":[{"t":70909953,"c":8660844545,"a":[{"v":"Formatter-based serialization is obsolete and should not be used.","t":1310721}],"n":[{"n":"DiagnosticId","v":"SYSLIB0050","t":1310721},{"n":"UrlFormat","v":"https://aka.ms/dotnet-warnings/{0}","t":1310721}]}]}; }
            static get $b() { return $.$$.System.Object; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$srsf.System.Runtime.Serialization.ISurrogateSelector ]; }
            static get $fullName() { return `System.Runtime.Serialization.SurrogateSelector`; }
        });
        
        $asm.$cls("$srsf.System.Runtime.Serialization.Formatters.Binary.BinaryFormatter", ($self) => class BinaryFormatter extends $.$$.System.Object
        {
            /*ISurrogateSelector?*/ _surrogates = null;
            /*StreamingContext*/ _context;
            /*SerializationBinder?*/ _binder = null;
            /*FormatterTypeStyle*/ _typeFormat = 1;
            /*FormatterAssemblyStyle*/ _assemblyFormat = 0;
            /*TypeFilterLevel*/ _securityLevel = 3;
            /*FormatterTypeStyle */ get TypeFormat()
            {
                return this._typeFormat;
            }
            /*FormatterTypeStyle */ set TypeFormat(value)
            {
                this._typeFormat = value;
            }
            /*FormatterAssemblyStyle */ get AssemblyFormat()
            {
                return this._assemblyFormat;
            }
            /*FormatterAssemblyStyle */ set AssemblyFormat(value)
            {
                this._assemblyFormat = value;
            }
            /*TypeFilterLevel */ get FilterLevel()
            {
                return this._securityLevel;
            }
            /*TypeFilterLevel */ set FilterLevel(value)
            {
                this._securityLevel = value;
            }
            /*ISurrogateSelector? */ get SurrogateSelector()
            {
                return this._surrogates;
            }
            /*ISurrogateSelector? */ set SurrogateSelector(value)
            {
                this._surrogates = value;
            }
            /*SerializationBinder? */ get Binder()
            {
                return this._binder;
            }
            /*SerializationBinder? */ set Binder(value)
            {
                this._binder = value;
            }
            /*StreamingContext */ get Context()
            {
                return this._context;
            }
            /*StreamingContext */ set Context(value)
            {
                this._context = value;
            }
            $ctor$1()
            {
                this.$ctor$2(null, new $.$$.System.Runtime.Serialization.StreamingContext().$ctor$4(255/*StreamingContextStates.All*/));
                {
                }
                return this;
            }
            $ctor$2(/*ISurrogateSelector?*/ selector, /*StreamingContext*/ context)
            {
                super.$ctor();
                {
                    this._surrogates = selector;
                    this._context = context;
                }
                return this;
            }
            /*object */ Deserialize(/*Stream*/ serializationStream)
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$16($.$srsf.System.SR.BinaryFormatter_Removed);
            }
            /*void */ Serialize(/*Stream*/ serializationStream, /*object*/ graph)
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$16($.$srsf.System.SR.BinaryFormatter_Removed);
            }
            //Generated interface implemetation for System.Runtime.Serialization.IFormatter.Deserialize(System.IO.Stream)
            System$Runtime$Serialization$IFormatter$Deserialize()
            {
                return this.Deserialize(...arguments);
            }
            //Generated interface implemetation for System.Runtime.Serialization.IFormatter.Serialize(System.IO.Stream, object)
            System$Runtime$Serialization$IFormatter$Serialize()
            {
                return this.Serialize(...arguments);
            }
            //Generated interface implemetation for System.Runtime.Serialization.IFormatter.SurrogateSelector.get
            get System$Runtime$Serialization$IFormatter$SurrogateSelector()
            {
                return this.SurrogateSelector;
            }
            //Generated interface implemetation for System.Runtime.Serialization.IFormatter.SurrogateSelector.set
            set System$Runtime$Serialization$IFormatter$SurrogateSelector(value)
            {
                this.SurrogateSelector = value;
            }
            //Generated interface implemetation for System.Runtime.Serialization.IFormatter.Binder.get
            get System$Runtime$Serialization$IFormatter$Binder()
            {
                return this.Binder;
            }
            //Generated interface implemetation for System.Runtime.Serialization.IFormatter.Binder.set
            set System$Runtime$Serialization$IFormatter$Binder(value)
            {
                this.Binder = value;
            }
            //Generated interface implemetation for System.Runtime.Serialization.IFormatter.Context.get
            get System$Runtime$Serialization$IFormatter$Context()
            {
                return this.Context;
            }
            //Generated interface implemetation for System.Runtime.Serialization.IFormatter.Context.set
            set System$Runtime$Serialization$IFormatter$Context(value)
            {
                this.Context = value;
            }
            //default member initializer
            constructor()
            {
                super();
                this._context = $.$default($.$$.System.Runtime.Serialization.StreamingContext);
            }
            static $h = 575746;
            static $f = 0b10010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":706818,"g":{"r":0,"d":0,"h":34360314114,"f":50331649},"s":{"r":0,"d":0,"h":38655281410,"f":83886081},"n":"TypeFormat","d":575746,"h":30065346818,"f":2097153},{"p":641282,"g":{"r":0,"d":0,"h":47245216002,"f":50331649},"s":{"r":0,"d":0,"h":51540183298,"f":83886081},"n":"AssemblyFormat","d":575746,"h":42950248706,"f":2097153},{"p":837890,"g":{"r":0,"d":0,"h":60130117890,"f":50331649},"s":{"r":0,"d":0,"h":64425085186,"f":83886081},"n":"FilterLevel","d":575746,"h":55835150594,"f":2097153},{"p":1100034,"g":{"r":0,"d":0,"h":73015019778,"f":50331649},"s":{"r":0,"d":0,"h":77309987074,"f":83886081},"n":"SurrogateSelector","d":575746,"h":68720052482,"f":2097153},{"p":1624322,"g":{"r":0,"d":0,"h":85899921666,"f":50331649},"s":{"r":0,"d":0,"h":90194888962,"f":83886081},"n":"Binder","d":575746,"h":81604954370,"f":2097153},{"p":113967105,"g":{"r":0,"d":0,"h":98784823554,"f":50331649},"s":{"r":0,"d":0,"h":103079790850,"f":83886081},"n":"Context","d":575746,"h":94489856258,"f":2097153}],"m":[{"r":131073,"p":[{"n":"serializationStream","p":62193665}],"n":"Deserialize","d":575746,"h":115964692738,"f":16777217},{"r":65537,"p":[{"n":"serializationStream","p":62193665},{"n":"graph","p":131073}],"n":"Serialize","d":575746,"h":120259660034,"f":16777217}],"l":[{"t":1100034,"n":"_surrogates","d":575746,"h":4295543042,"f":4194312},{"t":113967105,"n":"_context","d":575746,"h":8590510338,"f":4194312},{"t":1624322,"n":"_binder","d":575746,"h":12885477634,"f":4194312},{"t":706818,"n":"_typeFormat","d":575746,"h":17180444930,"f":4194312},{"t":641282,"n":"_assemblyFormat","d":575746,"h":21475412226,"f":4194312},{"t":837890,"n":"_securityLevel","d":575746,"h":25770379522,"f":4194312}],"c":[{"n":".ctor","o":"$ctor$1","d":575746,"h":107374758146,"f":16777217},{"p":[{"n":"selector","p":1100034},{"n":"context","p":113967105}],"n":".ctor","o":"$ctor$2","d":575746,"h":111669725442,"f":16777217}],"i":[968962],"h":575746,"a":[{"t":70909953,"c":8660844545,"a":[{"v":"BinaryFormatter serialization is obsolete and should not be used. See https://aka.ms/binaryformatter for more information.","t":1310721}],"n":[{"n":"DiagnosticId","v":"SYSLIB0011","t":1310721},{"n":"UrlFormat","v":"https://aka.ms/dotnet-warnings/{0}","t":1310721}]}]}; }
            static get $b() { return $.$$.System.Object; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$srsf.System.Runtime.Serialization.IFormatter ]; }
            static get $fullName() { return `System.Runtime.Serialization.Formatters.Binary.BinaryFormatter`; }
        });
        
        $asm.$cls("$srsf.System.Runtime.Serialization.SurrogateForCyclicalReference", ($self) => class SurrogateForCyclicalReference extends $.$$.System.Object
        {
            /*ISerializationSurrogate*/ _innerSurrogate = null;
            $ctor$1(/*ISerializationSurrogate*/ innerSurrogate)
            {
                super.$ctor();
                {
                    $.$$.System.Diagnostics.Debug.Assert$2(innerSurrogate !== null, "innerSurrogate != null");
                    this._innerSurrogate = innerSurrogate;
                }
                return this;
            }
            /*void */ GetObjectData(/*object*/ obj, /*SerializationInfo*/ info, /*StreamingContext*/ context)
            {
                this._innerSurrogate.System$Runtime$Serialization$ISerializationSurrogate$GetObjectData(obj, info, context);
            }
            /*object */ SetObjectData(/*object*/ obj, /*SerializationInfo*/ info, /*StreamingContext*/ context, /*ISurrogateSelector?*/ selector)
            {
                return this._innerSurrogate.System$Runtime$Serialization$ISerializationSurrogate$SetObjectData(obj, info, context, selector);
            }
            //Generated interface implemetation for System.Runtime.Serialization.ISerializationSurrogate.GetObjectData(object, System.Runtime.Serialization.SerializationInfo, System.Runtime.Serialization.StreamingContext)
            System$Runtime$Serialization$ISerializationSurrogate$GetObjectData()
            {
                return this.GetObjectData(...arguments);
            }
            //Generated interface implemetation for System.Runtime.Serialization.ISerializationSurrogate.SetObjectData(object, System.Runtime.Serialization.SerializationInfo, System.Runtime.Serialization.StreamingContext, System.Runtime.Serialization.ISurrogateSelector?)
            System$Runtime$Serialization$ISerializationSurrogate$SetObjectData()
            {
                return this.SetObjectData(...arguments);
            }
            static $h = 2083074;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"m":[{"r":65537,"p":[{"n":"obj","p":131073},{"n":"info","p":113836033},{"n":"context","p":113967105}],"n":"GetObjectData","d":2083074,"h":12886984962,"f":16777217},{"r":131073,"p":[{"n":"obj","p":131073},{"n":"info","p":113836033},{"n":"context","p":113967105},{"n":"selector","p":1100034}],"n":"SetObjectData","d":2083074,"h":17181952258,"f":16777217}],"l":[{"t":1034498,"n":"_innerSurrogate","d":2083074,"h":4297050370,"f":4194306}],"c":[{"p":[{"n":"innerSurrogate","p":1034498}],"n":".ctor","o":"$ctor$1","d":2083074,"h":8592017666,"f":16777224}],"i":[1034498],"h":2083074}; }
            static get $b() { return $.$$.System.Object; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$srsf.System.Runtime.Serialization.ISerializationSurrogate ]; }
            static get $fullName() { return `System.Runtime.Serialization.SurrogateForCyclicalReference`; }
        });
        
        $asm.$cls("$srsf.System.Runtime.Serialization.SerializationFieldInfo", ($self) => class SerializationFieldInfo extends $.$$.System.Reflection.FieldInfo
        {
            /*FieldInfo*/ m_field = null;
            /*string*/ m_serializationName = null;
            $ctor$4(/*FieldInfo*/ field, /*string*/ namePrefix)
            {
                super.$ctor$3();
                {
                    $.$$.System.Diagnostics.Debug.Assert$2($.$$.System.Reflection.FieldInfo.op_Inequality$1(field, null), "field != null");
                    $.$$.System.Diagnostics.Debug.Assert$2($.$$.System.String.op_Inequality(namePrefix, null), "namePrefix != null");
                    this.m_field = field;
                    this.m_serializationName = namePrefix + "+" + this.m_field.Name;
                }
                return this;
            }
            /*FieldInfo */ get FieldInfo()
            {
                return this.m_field;
            }
            /*string */ get Name()
            {
                return this.m_serializationName;
            }
            /*Module */ get Module()
            {
                return this.m_field.Module;
            }
            /*int */ get MetadataToken()
            {
                return this.m_field.MetadataToken;
            }
            /*Type? */ get DeclaringType()
            {
                return this.m_field.DeclaringType;
            }
            /*Type? */ get ReflectedType()
            {
                return this.m_field.ReflectedType;
            }
            /*object[] */ GetCustomAttributes(/*bool*/ inherit)
            {
                return this.m_field.GetCustomAttributes(inherit);
            }
            /*object[] */ GetCustomAttributes$1(/*Type*/ attributeType, /*bool*/ inherit)
            {
                return this.m_field.GetCustomAttributes$1(attributeType, inherit);
            }
            /*bool */ IsDefined(/*Type*/ attributeType, /*bool*/ inherit)
            {
                return this.m_field.IsDefined(attributeType, inherit);
            }
            /*Type */ get FieldType()
            {
                return this.m_field.FieldType;
            }
            /*object? */ GetValue(/*object?*/ obj)
            {
                return this.m_field.GetValue(obj);
            }
            /*void */ SetValue(/*object?*/ obj, /*object?*/ value, /*BindingFlags*/ invokeAttr, /*Binder?*/ binder, /*CultureInfo?*/ culture)
            {
                return this.m_field.SetValue(obj, value, invokeAttr, binder, culture);
            }
            /*RuntimeFieldHandle */ get FieldHandle()
            {
                return this.m_field.FieldHandle;
            }
            /*FieldAttributes */ get Attributes()
            {
                return this.m_field.Attributes;
            }
            static $h = 1886466;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":76677121,"p":[{"p":76677121,"g":{"r":0,"d":0,"h":21476722946,"f":50331656},"n":"FieldInfo","d":1886466,"h":17181755650,"f":2097160},{"p":1310721,"g":{"r":0,"d":0,"h":30066657538,"f":50364417},"n":"Name","d":1886466,"h":25771690242,"f":2129921},{"p":80216065,"g":{"r":0,"d":0,"h":38656592130,"f":50364417},"n":"Module","d":1886466,"h":34361624834,"f":2129921},{"p":655361,"g":{"r":0,"d":0,"h":47246526722,"f":50364417},"n":"MetadataToken","d":1886466,"h":42951559426,"f":2129921},{"p":142475265,"g":{"r":0,"d":0,"h":55836461314,"f":50364417},"n":"DeclaringType","d":1886466,"h":51541494018,"f":2129921},{"p":142475265,"g":{"r":0,"d":0,"h":64426395906,"f":50364417},"n":"ReflectedType","d":1886466,"h":60131428610,"f":2129921},{"p":142475265,"g":{"r":0,"d":0,"h":85901232386,"f":50364417},"n":"FieldType","d":1886466,"h":81606265090,"f":2129921},{"p":115408897,"g":{"r":0,"d":0,"h":103081101570,"f":50364417},"n":"FieldHandle","d":1886466,"h":98786134274,"f":2129921},{"p":76611585,"g":{"r":0,"d":0,"h":111671036162,"f":50364417},"n":"Attributes","d":1886466,"h":107376068866,"f":2129921}],"m":[{"r":$.$typeArray($.$$.System.Object).$h,"p":[{"n":"inherit","p":262145}],"n":"GetCustomAttributes","d":1886466,"h":68721363202,"f":16809985},{"r":$.$typeArray($.$$.System.Object).$h,"p":[{"n":"attributeType","p":142475265},{"n":"inherit","p":262145}],"n":"GetCustomAttributes","o":"@$1","d":1886466,"h":73016330498,"f":16809985},{"r":262145,"p":[{"n":"attributeType","p":142475265},{"n":"inherit","p":262145}],"n":"IsDefined","d":1886466,"h":77311297794,"f":16809985},{"r":131073,"p":[{"n":"obj","p":131073}],"n":"GetValue","d":1886466,"h":90196199682,"f":16809985},{"r":65537,"p":[{"n":"obj","p":131073},{"n":"value","p":131073},{"n":"invokeAttr","p":75497473},{"n":"binder","p":75431937},{"n":"culture","p":51183617}],"n":"SetValue","d":1886466,"h":94491166978,"f":16809985}],"l":[{"t":76677121,"n":"m_field","d":1886466,"h":4296853762,"f":4194306},{"t":1310721,"n":"m_serializationName","d":1886466,"h":8591821058,"f":4194306}],"c":[{"p":[{"n":"field","p":76677121},{"n":"namePrefix","p":1310721}],"n":".ctor","o":"$ctor$4","d":1886466,"h":12886788354,"f":16777224}],"i":[76939265],"h":1886466}; }
            static get $b() { return $.$$.System.Reflection.FieldInfo; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.System.Reflection.ICustomAttributeProvider ]; }
            static get $fullName() { return `System.Runtime.Serialization.SerializationFieldInfo`; }
        });
        
        $asm.$cls("$srsf.System.Runtime.Serialization.DeserializationEventHandler", ($self) => class DeserializationEventHandler extends $.$$.System.MulticastDelegate
        {
            $ctor(/*object*/ target, fn, anmodel)
            {
                this.$target = target;
                this.$nativeFunction = fn;
                if (anmodel) this.$nfmodel = anmodel;
                if (typeof(target) === 'object') this._target = target;
                return this;
            }
            /*void*/ Invoke(/*$.$$.System.Nullable$$*/ sender)
            {
                return this.$nativeFunction.call(this.$target, sender);
            }
            static $h = 248066;
            static $f = 0b10000000;
            static $k = 5;
            static $$md;
            static get $md() { return this.$$md ??= {"b":66191361,"m":[{"r":65537,"p":[{"n":"sender","p":131073}],"n":"Invoke","d":248066,"h":8590182658,"f":16777345},{"r":57016321,"p":[{"n":"sender","p":131073},{"n":"callback","p":14548993},{"n":"object","p":131073}],"n":"BeginInvoke","d":248066,"h":12885149954,"f":16777345},{"r":65537,"p":[{"n":"result","p":57016321}],"n":"EndInvoke","d":248066,"h":17180117250,"f":16777345}],"c":[{"p":[{"n":"object","p":131073},{"n":"method","p":786433}],"n":".ctor","o":"$ctor$5","d":248066,"h":4295215362,"f":16777217}],"i":[57212929,113246209],"h":248066}; }
            static get $b() { return $.$$.System.MulticastDelegate; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.System.ICloneable, $.$$.System.Runtime.Serialization.ISerializable ]; }
            static get $fullName() { return `System.Runtime.Serialization.DeserializationEventHandler`; }
        });
        
        $asm.$cls("$srsf.System.Runtime.Serialization.SerializationEventHandler", ($self) => class SerializationEventHandler extends $.$$.System.MulticastDelegate
        {
            $ctor(/*object*/ target, fn, anmodel)
            {
                this.$target = target;
                this.$nativeFunction = fn;
                if (anmodel) this.$nfmodel = anmodel;
                if (typeof(target) === 'object') this._target = target;
                return this;
            }
            /*void*/ Invoke(/**/ context)
            {
                return this.$nativeFunction.call(this.$target, context);
            }
            static $h = 1689858;
            static $f = 0b10000001;
            static $k = 5;
            static $$md;
            static get $md() { return this.$$md ??= {"b":66191361,"m":[{"r":65537,"p":[{"n":"context","p":113967105}],"n":"Invoke","d":1689858,"h":8591624450,"f":16777345},{"r":57016321,"p":[{"n":"context","p":113967105},{"n":"callback","p":14548993},{"n":"object","p":131073}],"n":"BeginInvoke","d":1689858,"h":12886591746,"f":16777345},{"r":65537,"p":[{"n":"result","p":57016321}],"n":"EndInvoke","d":1689858,"h":17181559042,"f":16777345}],"c":[{"p":[{"n":"object","p":131073},{"n":"method","p":786433}],"n":".ctor","o":"$ctor$5","d":1689858,"h":4296657154,"f":16777217}],"i":[57212929,113246209],"h":1689858}; }
            static get $b() { return $.$$.System.MulticastDelegate; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.System.ICloneable, $.$$.System.Runtime.Serialization.ISerializable ]; }
            static get $fullName() { return `System.Runtime.Serialization.SerializationEventHandler`; }
        });
        
        $asm.$str("$srsf.System.Runtime.Serialization.Formatters.FormatterTypeStyle", ($self) => class FormatterTypeStyle extends $.$$.System.Enum
        {
            static TypesWhenNeeded = 0;
            static TypesAlways = 1;
            static XsdString = 2;
            static $map;
            static get Map()
            {
                return this.$map ??= 
                {
                    "TypesWhenNeeded": 0n,
                    "TypesAlways": 1n,
                    "XsdString": 2n
                };
            }
            static $h = 706818;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static get $eut() { return $.$$.System.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {"b":1048577,"u":655361,"l":[{"t":706818,"n":"TypesWhenNeeded","d":706818,"h":4295674114,"f":4194337},{"t":706818,"n":"TypesAlways","d":706818,"h":8590641410,"f":4194337},{"t":706818,"n":"XsdString","d":706818,"h":12885608706,"f":4194337}],"c":[{"n":".ctor","o":"$ctor$3","d":706818,"h":17180576002,"f":16777217}],"i":[57278465,63832065,57737217,57409537],"h":706818,"a":[{"t":70909953,"c":8660844545,"a":[{"v":"Formatter-based serialization is obsolete and should not be used.","t":1310721}],"n":[{"n":"DiagnosticId","v":"SYSLIB0050","t":1310721},{"n":"UrlFormat","v":"https://aka.ms/dotnet-warnings/{0}","t":1310721}]}]}; }
            static get $b() { return $.$$.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.System.IComparable, $.$$.System.ISpanFormattable, $.$$.System.IFormattable, $.$$.System.IConvertible ]; }
            static get $fullName() { return `System.Runtime.Serialization.Formatters.FormatterTypeStyle`; }
        });
        
        $asm.$str("$srsf.System.Runtime.Serialization.Formatters.FormatterAssemblyStyle", ($self) => class FormatterAssemblyStyle extends $.$$.System.Enum
        {
            static Simple = 0;
            static Full = 1;
            static $map;
            static get Map()
            {
                return this.$map ??= 
                {
                    "Simple": 0n,
                    "Full": 1n
                };
            }
            static $h = 641282;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static get $eut() { return $.$$.System.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {"b":1048577,"u":655361,"l":[{"t":641282,"n":"Simple","d":641282,"h":4295608578,"f":4194337},{"t":641282,"n":"Full","d":641282,"h":8590575874,"f":4194337}],"c":[{"n":".ctor","o":"$ctor$3","d":641282,"h":12885543170,"f":16777217}],"i":[57278465,63832065,57737217,57409537],"h":641282,"a":[{"t":70909953,"c":8660844545,"a":[{"v":"Formatter-based serialization is obsolete and should not be used.","t":1310721}],"n":[{"n":"DiagnosticId","v":"SYSLIB0050","t":1310721},{"n":"UrlFormat","v":"https://aka.ms/dotnet-warnings/{0}","t":1310721}]}]}; }
            static get $b() { return $.$$.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.System.IComparable, $.$$.System.ISpanFormattable, $.$$.System.IFormattable, $.$$.System.IConvertible ]; }
            static get $fullName() { return `System.Runtime.Serialization.Formatters.FormatterAssemblyStyle`; }
        });
        
        $asm.$str("$srsf.System.Runtime.Serialization.Formatters.TypeFilterLevel", ($self) => class TypeFilterLevel extends $.$$.System.Enum
        {
            static Low = 2;
            static Full = 3;
            static $map;
            static get Map()
            {
                return this.$map ??= 
                {
                    "Low": 2n,
                    "Full": 3n
                };
            }
            static $h = 837890;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static get $eut() { return $.$$.System.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {"b":1048577,"u":655361,"l":[{"t":837890,"n":"Low","d":837890,"h":4295805186,"f":4194337},{"t":837890,"n":"Full","d":837890,"h":8590772482,"f":4194337}],"c":[{"n":".ctor","o":"$ctor$3","d":837890,"h":12885739778,"f":16777217}],"i":[57278465,63832065,57737217,57409537],"h":837890,"a":[{"t":70909953,"c":8660844545,"a":[{"v":"Formatter-based serialization is obsolete and should not be used.","t":1310721}],"n":[{"n":"DiagnosticId","v":"SYSLIB0050","t":1310721},{"n":"UrlFormat","v":"https://aka.ms/dotnet-warnings/{0}","t":1310721}]}]}; }
            static get $b() { return $.$$.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.System.IComparable, $.$$.System.ISpanFormattable, $.$$.System.IFormattable, $.$$.System.IConvertible ]; }
            static get $fullName() { return `System.Runtime.Serialization.Formatters.TypeFilterLevel`; }
        });
        
        $asm.$cls("$srsf.System.Runtime.Serialization.SurrogateHashtable", ($self) => class SurrogateHashtable extends $.$$.System.Collections.Hashtable
        {
            $ctor$18(/*int*/ size)
            {
                super.$ctor$16(size);
                {
                }
                return this;
            }
            /*bool */ KeyEquals(/*object*/ key, /*object*/ item)
            {
                /*SurrogateKey*/ let givenValue = $.$cast(item, $.$srsf.System.Runtime.Serialization.SurrogateKey);
                /*SurrogateKey*/ let presentValue = $.$cast(key, $.$srsf.System.Runtime.Serialization.SurrogateKey);
                return $.$$.System.Type.op_Equality$1(presentValue._type, givenValue._type) && (presentValue._context.State & givenValue._context.State) === givenValue._context.State && presentValue._context.Context === givenValue._context.Context;
            }
            static $h = 2148610;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":31064065,"m":[{"r":262145,"p":[{"n":"key","p":131073},{"n":"item","p":131073}],"n":"KeyEquals","d":2148610,"h":8592083202,"f":16809988}],"c":[{"p":[{"n":"size","p":655361}],"n":".ctor","o":"$ctor$18","d":2148610,"h":4297115906,"f":16777224}],"i":[31588353,31457281,31719425,113246209,112984065,57212929],"h":2148610}; }
            static get $b() { return $.$$.System.Collections.Hashtable; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.System.Collections.IDictionary, $.$$.System.Collections.ICollection, $.$$.System.Collections.IEnumerable, $.$$.System.Runtime.Serialization.ISerializable, $.$$.System.Runtime.Serialization.IDeserializationCallback, $.$$.System.ICloneable ]; }
            static get $fullName() { return `System.Runtime.Serialization.SurrogateHashtable`; }
        });
	});
})(window, window.NetJs.$boot(), ...window.NetJs.$require("NetJs.System.Private.CoreLib", "NetJs.System.Collections", "NetJs.System.Diagnostics.Tracing", "NetJs.System.Threading", "NetJs.System.Collections.Concurrent", "NetJs.System.Memory", "NetJs.System.Private.Uri", "NetJs.System.Runtime", "NetJs.System.Collections.NonGeneric"))