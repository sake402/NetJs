
(function ($global, $, $spc, $sc, $sdt, $st, $scc, $sm, $spu, $sr, $scn) {
    "use strict";
    let _;
    
    
    
	$.$asm(
    "NetJs.System.Runtime.Serialization.Formatters", 
    {"h":61210,"f":"System.Runtime.Serialization.Formatters","v":"1.0.35.0","a":[{"t":96337921,"c":4391305217,"a":[{"v":66519041,"t":142606337}]},{"t":96337921,"c":4391305217,"a":[{"v":118226945,"t":142606337}]},{"t":96337921,"c":4391305217,"a":[{"v":113115137,"t":142606337}]},{"t":96337921,"c":4391305217,"a":[{"v":113180673,"t":142606337}]},{"t":96337921,"c":4391305217,"a":[{"v":113377281,"t":142606337}]},{"t":96337921,"c":4391305217,"a":[{"v":113836033,"t":142606337}]},{"t":96337921,"c":4391305217,"a":[{"v":113967105,"t":142606337}]},{"t":96337921,"c":4391305217,"a":[{"v":114032641,"t":142606337}]},{"t":73596929,"c":4368564225,"a":[{"v":"SIT","t":1310721}]},{"t":73662465,"c":4368629761,"a":[{"v":"Debug","t":1310721}]},{"t":74121217,"c":4369088513,"a":[{"v":"1.0.35.0","t":1310721}]},{"t":74252289,"c":4369219585,"a":[{"v":"1.0.35\u002B99807a3edea449997cda60d38046fed69821a2f6","t":1310721}]},{"t":75104257,"c":4370071553,"a":[{"v":"NetJs.System.Runtime.Serialization.Formatters","t":1310721}]},{"t":75235329,"c":4370202625,"a":[{"v":"NetJs.System.Runtime.Serialization.Formatters","t":1310721}]},{"t":75366401,"c":4370333697,"a":[{"v":"1.0.35.0","t":1310721}]},{"t":115212289,"c":4410179585,"a":[{"v":"browser1.0","t":1310721}]},{"t":114950145,"c":4409917441,"a":[{"v":"browser1.0","t":1310721}]},{"t":115146753,"c":13000048641,"a":[{"v":".NETCoreApp,Version=v10.0","t":1310721}],"n":[{"n":"FrameworkDisplayName","v":".NET 10.0","t":1310721}]}],"m":[]},
    function($asm)
	{
        
        
        $asm.$cls("$srsf.System.Runtime.Serialization.ISerializationSurrogate", ($self) => class ISerializationSurrogate
        {
            static $h = 1044250;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {"m":[{"r":65537,"p":[{"n":"obj","p":131073},{"n":"info","p":113967105},{"n":"context","p":114098177}],"n":"GetObjectData","o":"System$Runtime$Serialization$ISerializationSurrogate$GetObjectData","d":1044250,"h":4296011546,"f":257},{"r":131073,"p":[{"n":"obj","p":131073},{"n":"info","p":113967105},{"n":"context","p":114098177},{"n":"selector","p":1109786}],"n":"SetObjectData","o":"System$Runtime$Serialization$ISerializationSurrogate$SetObjectData","d":1044250,"h":8590978842,"f":257}],"h":1044250,"a":[{"t":70909953,"c":8660844545,"a":[{"v":"Formatter-based serialization is obsolete and should not be used.","t":1310721}],"n":[{"n":"DiagnosticId","v":"SYSLIB0050","t":1310721},{"n":"UrlFormat","v":"https://aka.ms/dotnet-warnings/{0}","t":1310721}]}]}; }
            static get $fullName() { return `System.Runtime.Serialization.ISerializationSurrogate`; }
        });
        
        $asm.$cls("$srsf.System.Runtime.Serialization.ISurrogateSelector", ($self) => class ISurrogateSelector
        {
            static $h = 1109786;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {"m":[{"r":65537,"p":[{"n":"selector","p":1109786}],"n":"ChainSelector","o":"System$Runtime$Serialization$ISurrogateSelector$ChainSelector","d":1109786,"h":4296077082,"f":257},{"r":1044250,"p":[{"n":"type","p":142606337},{"n":"context","p":114098177},{"n":"selector","p":1109786,"f":2}],"n":"GetSurrogate","o":"System$Runtime$Serialization$ISurrogateSelector$GetSurrogate","d":1109786,"h":8591044378,"f":257},{"r":1109786,"n":"GetNextSelector","o":"System$Runtime$Serialization$ISurrogateSelector$GetNextSelector","d":1109786,"h":12886011674,"f":257}],"h":1109786,"a":[{"t":70909953,"c":8660844545,"a":[{"v":"Formatter-based serialization is obsolete and should not be used.","t":1310721}],"n":[{"n":"DiagnosticId","v":"SYSLIB0050","t":1310721},{"n":"UrlFormat","v":"https://aka.ms/dotnet-warnings/{0}","t":1310721}]}]}; }
            static get $fullName() { return `System.Runtime.Serialization.ISurrogateSelector`; }
        });
        
        $asm.$cls("$srsf.System.Runtime.Serialization.IFormatter", ($self) => class IFormatter
        {
            /*string*/ static System$Runtime$Serialization$IFormatter$RequiresDynamicCodeMessage = null;
            /*string*/ static System$Runtime$Serialization$IFormatter$RequiresUnreferencedCodeMessage = null;
            //Static Initializer
            static $sinit()
            {
                {
                    this.System$Runtime$Serialization$IFormatter$RequiresDynamicCodeMessage = "BinaryFormatter serialization uses dynamic code generation, the type of objects being processed cannot be statically discovered.";
                }
                {
                    this.System$Runtime$Serialization$IFormatter$RequiresUnreferencedCodeMessage = "BinaryFormatter serialization is not trim compatible because the type of objects being processed cannot be statically discovered.";
                }
            }
            static $h = 978714;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {"p":[{"p":1109786,"g":{"r":0,"d":0,"h":25770782490,"f":257},"s":{"r":0,"d":0,"h":30065749786,"f":257},"n":"SurrogateSelector","o":"System$Runtime$Serialization$IFormatter$SurrogateSelector","d":978714,"h":21475815194,"f":257},{"p":1634074,"g":{"r":0,"d":0,"h":38655684378,"f":257},"s":{"r":0,"d":0,"h":42950651674,"f":257},"n":"Binder","o":"System$Runtime$Serialization$IFormatter$Binder","d":978714,"h":34360717082,"f":257},{"p":114098177,"g":{"r":0,"d":0,"h":51540586266,"f":257},"s":{"r":0,"d":0,"h":55835553562,"f":257},"n":"Context","o":"System$Runtime$Serialization$IFormatter$Context","d":978714,"h":47245618970,"f":257}],"m":[{"r":131073,"p":[{"n":"serializationStream","p":62193665}],"n":"Deserialize","o":"System$Runtime$Serialization$IFormatter$Deserialize","d":978714,"h":12885880602,"f":257},{"r":65537,"p":[{"n":"serializationStream","p":62193665},{"n":"graph","p":131073}],"n":"Serialize","o":"System$Runtime$Serialization$IFormatter$Serialize","d":978714,"h":17180847898,"f":257}],"l":[{"t":1310721,"n":"RequiresDynamicCodeMessage","o":"System$Runtime$Serialization$IFormatter$RequiresDynamicCodeMessage","d":978714,"h":4295946010,"f":40},{"t":1310721,"n":"RequiresUnreferencedCodeMessage","o":"System$Runtime$Serialization$IFormatter$RequiresUnreferencedCodeMessage","d":978714,"h":8590913306,"f":40}],"h":978714,"a":[{"t":70909953,"c":8660844545,"a":[{"v":"BinaryFormatter serialization is obsolete and should not be used. See https://aka.ms/binaryformatter for more information.","t":1310721}],"n":[{"n":"DiagnosticId","v":"SYSLIB0011","t":1310721},{"n":"UrlFormat","v":"https://aka.ms/dotnet-warnings/{0}","t":1310721}]}]}; }
            static get $fullName() { return `System.Runtime.Serialization.IFormatter`; }
        });
        
        $asm.$cls("$srsf.System.Runtime.Serialization.Formatters.IFieldInfo", ($self) => class IFieldInfo
        {
            static $h = 782106;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {"p":[{"p":0,"g":{"r":0,"d":0,"h":8590716698,"f":257},"s":{"r":0,"d":0,"h":12885683994,"f":257},"n":"FieldNames","o":"System$Runtime$Serialization$Formatters$IFieldInfo$FieldNames","d":782106,"h":4295749402,"f":257},{"p":0,"g":{"r":0,"d":0,"h":21475618586,"f":257},"s":{"r":0,"d":0,"h":25770585882,"f":257},"n":"FieldTypes","o":"System$Runtime$Serialization$Formatters$IFieldInfo$FieldTypes","d":782106,"h":17180651290,"f":257}],"h":782106,"a":[{"t":70909953,"c":8660844545,"a":[{"v":"Formatter-based serialization is obsolete and should not be used.","t":1310721}],"n":[{"n":"DiagnosticId","v":"SYSLIB0050","t":1310721},{"n":"UrlFormat","v":"https://aka.ms/dotnet-warnings/{0}","t":1310721}]}]}; }
            static get $fullName() { return `System.Runtime.Serialization.Formatters.IFieldInfo`; }
        });
        
        $asm.$cls("$srsf.System.Runtime.Serialization.SerializationBinder", ($self) => class SerializationBinder extends $.$spc.System.Object
        {
            /*void */ BindToName(/*Type*/ serializedType, /*out string?*/ assemblyName, /*out string?*/ typeName)
            {
                assemblyName.$v = null;
                typeName.$v = null;
            }
            //default reference type constructor overload
            $ctor$1()
            {
                super.$ctor();
                return this;
            }
            static $h = 1634074;
            static $f = 0b110001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"m":[{"r":65537,"p":[{"n":"serializedType","p":142606337},{"n":"assemblyName","p":1310721,"f":2},{"n":"typeName","p":1310721,"f":2}],"n":"BindToName","d":1634074,"h":4296601370,"f":129},{"r":142606337,"p":[{"n":"assemblyName","p":1310721},{"n":"typeName","p":1310721}],"n":"BindToType","d":1634074,"h":8591568666,"f":257}],"c":[{"n":".ctor","o":"$ctor$1","d":1634074,"h":12886535962,"f":4}],"h":1634074}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.Runtime.Serialization.SerializationBinder`; }
        });
        
        $asm.$cls("$srsf.System.Runtime.Serialization.Formatter", ($self) => class Formatter extends $.$spc.System.Object
        {
            /*ObjectIDGenerator*/ m_idGenerator = null;
            /*Queue*/ m_objectQueue = null;
            $ctor$1()
            {
                super.$ctor();
                {
                    this.m_objectQueue = new $.$scn.System.Collections.Queue().$ctor$1();
                    this.m_idGenerator = new $.$srsf.System.Runtime.Serialization.ObjectIDGenerator().$ctor$1();
                }
                return this;
            }
            /*object? */ GetNext(/*out long*/ objID)
            {
                if (this.m_objectQueue.Count === 0)
                {
                    objID.$v = 0n;
                    return null;
                }
                /*object*/ let obj = this.m_objectQueue.Dequeue();
                /*bool*/ let isNew;
                objID.$v = this.m_idGenerator.HasId(obj, $.$ref(() => isNew, ($v) => isNew = $v, $.$spc.System.Boolean));
                if (isNew)
                {
                    throw new $.$spc.System.Runtime.Serialization.SerializationException().$ctor$10($.$srsf.System.SR.Serialization_NoID);
                }
                return obj;
            }
            /*long */ Schedule(/*object?*/ obj)
            {
                if (obj === null)
                {
                    return 0n;
                }
                /*bool*/ let isNew;
                /*long*/ let id = this.m_idGenerator.GetId(obj, $.$ref(() => isNew, ($v) => isNew = $v, $.$spc.System.Boolean));
                if (isNew)
                {
                    this.m_objectQueue.Enqueue(obj);
                }
                return id;
            }
            /*void */ WriteMember(/*string*/ memberName, /*object?*/ data)
            {
                if (data === null)
                {
                    this.WriteObjectRef(data, memberName, $.$spc.System.Object.$type);
                    return;
                }
                /*Type*/ let varType = $.$spc.System.Object.GetType.call(data);
                if ($.$spc.System.Type.op_Equality$1(varType, $.$spc.System.Boolean.$type))
                {
                    this.WriteBoolean($.$spc.System.Convert.ToBoolean$1(data, $.$spc.System.Globalization.CultureInfo.InvariantCulture), memberName);
                }
                else if ($.$spc.System.Type.op_Equality$1(varType, $.$spc.System.Char.$type))
                {
                    this.WriteChar($.$spc.System.Convert.ToChar$1(data, $.$spc.System.Globalization.CultureInfo.InvariantCulture), memberName);
                }
                else if ($.$spc.System.Type.op_Equality$1(varType, $.$spc.System.SByte.$type))
                {
                    this.WriteSByte($.$spc.System.Convert.ToSByte$1(data, $.$spc.System.Globalization.CultureInfo.InvariantCulture), memberName);
                }
                else if ($.$spc.System.Type.op_Equality$1(varType, $.$spc.System.Byte.$type))
                {
                    this.WriteByte($.$spc.System.Convert.ToByte$1(data, $.$spc.System.Globalization.CultureInfo.InvariantCulture), memberName);
                }
                else if ($.$spc.System.Type.op_Equality$1(varType, $.$spc.System.Int16.$type))
                {
                    this.WriteInt16($.$spc.System.Convert.ToInt16$1(data, $.$spc.System.Globalization.CultureInfo.InvariantCulture), memberName);
                }
                else if ($.$spc.System.Type.op_Equality$1(varType, $.$spc.System.Int32.$type))
                {
                    this.WriteInt32($.$spc.System.Convert.ToInt32$1(data, $.$spc.System.Globalization.CultureInfo.InvariantCulture), memberName);
                }
                else if ($.$spc.System.Type.op_Equality$1(varType, $.$spc.System.Int64.$type))
                {
                    this.WriteInt64($.$spc.System.Convert.ToInt64$1(data, $.$spc.System.Globalization.CultureInfo.InvariantCulture), memberName);
                }
                else if ($.$spc.System.Type.op_Equality$1(varType, $.$spc.System.Single.$type))
                {
                    this.WriteSingle($.$spc.System.Convert.ToSingle$1(data, $.$spc.System.Globalization.CultureInfo.InvariantCulture), memberName);
                }
                else if ($.$spc.System.Type.op_Equality$1(varType, $.$spc.System.Double.$type))
                {
                    this.WriteDouble($.$spc.System.Convert.ToDouble$1(data, $.$spc.System.Globalization.CultureInfo.InvariantCulture), memberName);
                }
                else if ($.$spc.System.Type.op_Equality$1(varType, $.$spc.System.DateTime.$type))
                {
                    this.WriteDateTime($.$spc.System.Convert.ToDateTime$2(data, $.$spc.System.Globalization.CultureInfo.InvariantCulture), memberName);
                }
                else if ($.$spc.System.Type.op_Equality$1(varType, $.$spc.System.Decimal.$type))
                {
                    this.WriteDecimal($.$spc.System.Convert.ToDecimal$1(data, $.$spc.System.Globalization.CultureInfo.InvariantCulture), memberName);
                }
                else if ($.$spc.System.Type.op_Equality$1(varType, $.$spc.System.UInt16.$type))
                {
                    this.WriteUInt16($.$spc.System.Convert.ToUInt16$1(data, $.$spc.System.Globalization.CultureInfo.InvariantCulture), memberName);
                }
                else if ($.$spc.System.Type.op_Equality$1(varType, $.$spc.System.UInt32.$type))
                {
                    this.WriteUInt32($.$spc.System.Convert.ToUInt32$1(data, $.$spc.System.Globalization.CultureInfo.InvariantCulture), memberName);
                }
                else if ($.$spc.System.Type.op_Equality$1(varType, $.$spc.System.UInt64.$type))
                {
                    this.WriteUInt64($.$spc.System.Convert.ToUInt64$1(data, $.$spc.System.Globalization.CultureInfo.InvariantCulture), memberName);
                }
                else if (varType.IsArray)
                {
                    this.WriteArray(data, memberName, varType);
                }
                else if (varType.IsValueType)
                {
                    this.WriteValueType(data, memberName, varType);
                }
                else 
                {
                    this.WriteObjectRef(data, memberName, varType);
                }
            }
            //Generated interface implemetation for System.Runtime.Serialization.IFormatter.Deserialize(System.IO.Stream)
            System$Runtime$Serialization$IFormatter$Deserialize()
            {
                return this.Deserialize(...arguments);
            }
            //Generated interface implemetation for System.Runtime.Serialization.IFormatter.Serialize(System.IO.Stream, object)
            System$Runtime$Serialization$IFormatter$Serialize()
            {
                return this.Serialize(...arguments);
            }
            //Generated interface implemetation for System.Runtime.Serialization.IFormatter.SurrogateSelector.get
            get System$Runtime$Serialization$IFormatter$SurrogateSelector()
            {
                return this.SurrogateSelector;
            }
            //Generated interface implemetation for System.Runtime.Serialization.IFormatter.SurrogateSelector.set
            set System$Runtime$Serialization$IFormatter$SurrogateSelector(value)
            {
                this.SurrogateSelector = value;
            }
            //Generated interface implemetation for System.Runtime.Serialization.IFormatter.Binder.get
            get System$Runtime$Serialization$IFormatter$Binder()
            {
                return this.Binder;
            }
            //Generated interface implemetation for System.Runtime.Serialization.IFormatter.Binder.set
            set System$Runtime$Serialization$IFormatter$Binder(value)
            {
                this.Binder = value;
            }
            //Generated interface implemetation for System.Runtime.Serialization.IFormatter.Context.get
            get System$Runtime$Serialization$IFormatter$Context()
            {
                return this.Context;
            }
            //Generated interface implemetation for System.Runtime.Serialization.IFormatter.Context.set
            set System$Runtime$Serialization$IFormatter$Context(value)
            {
                this.Context = value;
            }
            static $h = 454426;
            static $f = 0b110001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":1109786,"g":{"r":0,"d":0,"h":120259538714,"f":257},"s":{"r":0,"d":0,"h":124554506010,"f":257},"n":"SurrogateSelector","d":454426,"h":115964571418,"f":257},{"p":1634074,"g":{"r":0,"d":0,"h":133144440602,"f":257},"s":{"r":0,"d":0,"h":137439407898,"f":257},"n":"Binder","d":454426,"h":128849473306,"f":257},{"p":114098177,"g":{"r":0,"d":0,"h":146029342490,"f":257},"s":{"r":0,"d":0,"h":150324309786,"f":257},"n":"Context","d":454426,"h":141734375194,"f":257}],"m":[{"r":131073,"p":[{"n":"serializationStream","p":62193665}],"n":"Deserialize","d":454426,"h":17180323610,"f":257},{"r":131073,"p":[{"n":"objID","p":917505,"f":2}],"n":"GetNext","d":454426,"h":21475290906,"f":132},{"r":917505,"p":[{"n":"obj","p":131073}],"n":"Schedule","d":454426,"h":25770258202,"f":132},{"r":65537,"p":[{"n":"serializationStream","p":62193665},{"n":"graph","p":131073}],"n":"Serialize","d":454426,"h":30065225498,"f":257},{"r":65537,"p":[{"n":"obj","p":131073},{"n":"name","p":1310721},{"n":"memberType","p":142606337}],"n":"WriteArray","d":454426,"h":34360192794,"f":260},{"r":65537,"p":[{"n":"val","p":262145},{"n":"name","p":1310721}],"n":"WriteBoolean","d":454426,"h":38655160090,"f":260},{"r":65537,"p":[{"n":"val","p":393217},{"n":"name","p":1310721}],"n":"WriteByte","d":454426,"h":42950127386,"f":260},{"r":65537,"p":[{"n":"val","p":458753},{"n":"name","p":1310721}],"n":"WriteChar","d":454426,"h":47245094682,"f":260},{"r":65537,"p":[{"n":"val","p":34209793},{"n":"name","p":1310721}],"n":"WriteDateTime","d":454426,"h":51540061978,"f":260},{"r":65537,"p":[{"n":"val","p":35061761},{"n":"name","p":1310721}],"n":"WriteDecimal","d":454426,"h":55835029274,"f":260},{"r":65537,"p":[{"n":"val","p":1179649},{"n":"name","p":1310721}],"n":"WriteDouble","d":454426,"h":60129996570,"f":260},{"r":65537,"p":[{"n":"val","p":524289},{"n":"name","p":1310721}],"n":"WriteInt16","d":454426,"h":64424963866,"f":260},{"r":65537,"p":[{"n":"val","p":655361},{"n":"name","p":1310721}],"n":"WriteInt32","d":454426,"h":68719931162,"f":260},{"r":65537,"p":[{"n":"val","p":917505},{"n":"name","p":1310721}],"n":"WriteInt64","d":454426,"h":73014898458,"f":260},{"r":65537,"p":[{"n":"obj","p":131073},{"n":"name","p":1310721},{"n":"memberType","p":142606337}],"n":"WriteObjectRef","d":454426,"h":77309865754,"f":260},{"r":65537,"p":[{"n":"memberName","p":1310721},{"n":"data","p":131073}],"n":"WriteMember","d":454426,"h":81604833050,"f":132},{"r":65537,"p":[{"n":"val","p":327681},{"n":"name","p":1310721}],"n":"WriteSByte","d":454426,"h":85899800346,"f":260,"a":[{"t":23461889,"c":8613396481,"a":[{"v":false,"t":262145}]}]},{"r":65537,"p":[{"n":"val","p":1114113},{"n":"name","p":1310721}],"n":"WriteSingle","d":454426,"h":90194767642,"f":260},{"r":65537,"p":[{"n":"val","p":140705793},{"n":"name","p":1310721}],"n":"WriteTimeSpan","d":454426,"h":94489734938,"f":260},{"r":65537,"p":[{"n":"val","p":589825},{"n":"name","p":1310721}],"n":"WriteUInt16","d":454426,"h":98784702234,"f":260,"a":[{"t":23461889,"c":8613396481,"a":[{"v":false,"t":262145}]}]},{"r":65537,"p":[{"n":"val","p":720897},{"n":"name","p":1310721}],"n":"WriteUInt32","d":454426,"h":103079669530,"f":260,"a":[{"t":23461889,"c":8613396481,"a":[{"v":false,"t":262145}]}]},{"r":65537,"p":[{"n":"val","p":983041},{"n":"name","p":1310721}],"n":"WriteUInt64","d":454426,"h":107374636826,"f":260,"a":[{"t":23461889,"c":8613396481,"a":[{"v":false,"t":262145}]}]},{"r":65537,"p":[{"n":"obj","p":131073},{"n":"name","p":1310721},{"n":"memberType","p":142606337}],"n":"WriteValueType","d":454426,"h":111669604122,"f":260}],"l":[{"t":1503002,"n":"m_idGenerator","d":454426,"h":4295421722,"f":4},{"t":393251,"n":"m_objectQueue","d":454426,"h":8590389018,"f":4}],"c":[{"n":".ctor","o":"$ctor$1","d":454426,"h":12885356314,"f":4}],"i":[978714],"h":454426,"a":[{"t":23461889,"c":8613396481,"a":[{"v":false,"t":262145}]},{"t":70909953,"c":8660844545,"a":[{"v":"BinaryFormatter serialization is obsolete and should not be used. See https://aka.ms/binaryformatter for more information.","t":1310721}],"n":[{"n":"DiagnosticId","v":"SYSLIB0011","t":1310721},{"n":"UrlFormat","v":"https://aka.ms/dotnet-warnings/{0}","t":1310721}]}]}; }
            static get $b() { return $.$spc.System.Object; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$srsf.System.Runtime.Serialization.IFormatter ]; }
            static get $fullName() { return `System.Runtime.Serialization.Formatter`; }
        });
        
        $asm.$cls("$srsf.System.Runtime.Serialization.MemberHolder", ($self) => class MemberHolder extends $.$spc.System.Object
        {
            /*Type*/ _memberType = null;
            /*StreamingContext*/ _context;
            $ctor$1(/*Type*/ type, /*StreamingContext*/ ctx)
            {
                super.$ctor();
                {
                    this._memberType = type;
                    this._context = ctx;
                }
                return this;
            }
            static/*conventional*/ /*int */ GetHashCode()
            {
                return $.$spc.System.Type.GetHashCode.call(this._memberType);
            }
            //Static convention instance redirect
            /*int */ GetHashCode() { return $.$srsf.System.Runtime.Serialization.MemberHolder.GetHashCode.apply(this, arguments); }
            static/*conventional*/ /*bool */ Equals(/*object?*/ obj)
            {
                let mh;
                return $.$is(obj, $.$srsf.System.Runtime.Serialization.MemberHolder, { set $v(v){ mh = v; } }) && $.$spc.System.Object.ReferenceEquals(mh._memberType, this._memberType) && mh._context.State === this._context.State;
            }
            //Static convention instance redirect
            /*bool */ Equals() { return $.$srsf.System.Runtime.Serialization.MemberHolder.Equals.apply(this, arguments); }
            //default member initializer
            constructor()
            {
                super();
                this._context = $.$default($.$spc.System.Runtime.Serialization.StreamingContext);
            }
            static $h = 1240858;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"m":[{"r":655361,"n":"GetHashCode","d":1240858,"h":17181110042,"f":32769},{"r":262145,"p":[{"n":"obj","p":131073}],"n":"Equals","d":1240858,"h":21476077338,"f":32769}],"l":[{"t":142606337,"n":"_memberType","d":1240858,"h":4296208154,"f":8},{"t":114098177,"n":"_context","d":1240858,"h":8591175450,"f":8}],"c":[{"p":[{"n":"type","p":142606337},{"n":"ctx","p":114098177}],"n":".ctor","o":"$ctor$1","d":1240858,"h":12886142746,"f":8}],"h":1240858}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.Runtime.Serialization.MemberHolder`; }
        });
        
        $asm.$cls("$srsf.System.Runtime.Serialization.ObjectIDGenerator", ($self) => class ObjectIDGenerator extends $.$spc.System.Object
        {
            /*int*/ static NumBins = 4;
            /*int*/ _currentCount = 0;
            /*int*/ _currentSize = 0;
            /*long[]*/ _ids = null;
            /*object[]*/ _objs = null;
            $ctor$1()
            {
                super.$ctor();
                {
                    this._currentCount = 1;
                    this._currentSize = 3;
                    this._ids = $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$spc.System.Int64), null, [((this._currentSize * 4/*NumBins*/) | 0)], null);
                    this._objs = $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$spc.System.Object), null, [((this._currentSize * 4/*NumBins*/) | 0)], null);
                }
                return this;
            }
            /*int */ FindElement(/*object*/ obj, /*out bool*/ found)
            {
                /*int*/ let hashcode = $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.GetHashCode$1(obj);
                /*int*/ let hashIncrement = (((1 + ((hashcode & 2147483647) % (((this._currentSize - 2) | 0)))) | 0));
                do
                {
                    /*int*/ let pos = ((((hashcode & 2147483647) % this._currentSize) * 4/*NumBins*/) | 0);
                    for(/*int*/ let i = pos; i < ((pos + 4/*NumBins*/) | 0); i++)
                    {
                        if ($.$spc.System.Array.$ReadT1.call(this._objs, i) === null)
                        {
                            found.$v = false;
                            return i;
                        }
                        if ($.$spc.System.Array.$ReadT1.call(this._objs, i) === obj)
                        {
                            found.$v = true;
                            return i;
                        }
                    }
                    hashcode += hashIncrement;
                }
                while(true);
            }
            /*long */ GetId(/*object*/ obj, /*out bool*/ firstTime)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(obj, "obj");
                /*bool*/ let found;
                /*int*/ let pos = this.FindElement(obj, $.$ref(() => found, ($v) => found = $v, $.$spc.System.Boolean));
                /*long*/ let foundID;
                if (!found)
                {
                    $.$spc.System.Array.$WriteT1.call(this._objs, obj, pos);
                    $.$spc.System.Array.$WriteT1.call(this._ids, BigInt(this._currentCount++), pos);
                    foundID = $.$spc.System.Array.$ReadT1.call(this._ids, pos);
                    if (this._currentCount > $.trunc((((this._currentSize * 4/*NumBins*/) | 0)) / 2))
                    {
                        this.Rehash();
                    }
                }
                else 
                {
                    foundID = $.$spc.System.Array.$ReadT1.call(this._ids, pos);
                }
                firstTime.$v = !found;
                return foundID;
            }
            /*long */ HasId(/*object*/ obj, /*out bool*/ firstTime)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(obj, "obj");
                /*bool*/ let found;
                /*int*/ let pos = this.FindElement(obj, $.$ref(() => found, ($v) => found = $v, $.$spc.System.Boolean));
                if (found)
                {
                    firstTime.$v = false;
                    return $.$spc.System.Array.$ReadT1.call(this._ids, pos);
                }
                firstTime.$v = true;
                return 0n;
            }
            /*void */ Rehash()
            {
                /*int*/ let currSize = this._currentSize;
                /*int*/ let newSize = $.$srsf.System.Collections.HashHelpers.ExpandPrime(currSize);
                if (newSize === currSize)
                {
                    throw new $.$spc.System.Runtime.Serialization.SerializationException().$ctor$10($.$srsf.System.SR.Serialization_TooManyElements);
                }
                this._currentSize = newSize;
                /*long[]*/ let newIds = $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$spc.System.Int64), null, [((this._currentSize * 4/*NumBins*/) | 0)], null);
                /*object[]*/ let newObjs = $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$spc.System.Object), null, [((this._currentSize * 4/*NumBins*/) | 0)], null);
                /*long[]*/ let oldIds = this._ids;
                /*object[]*/ let oldObjs = this._objs;
                this._ids = newIds;
                this._objs = newObjs;
                for(/*int*/ let j = 0; j < oldObjs.length; j++)
                {
                    if ($.$spc.System.Array.$ReadT1.call(oldObjs, j) !== null)
                    {
                        /*int*/ let pos = this.FindElement($.$spc.System.Array.$ReadT1.call(oldObjs, j), $.$discardRef());
                        $.$spc.System.Array.$WriteT1.call(this._objs, $.$spc.System.Array.$ReadT1.call(oldObjs, j), pos);
                        $.$spc.System.Array.$WriteT1.call(this._ids, $.$spc.System.Array.$ReadT1.call(oldIds, j), pos);
                    }
                }
            }
            static $h = 1503002;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"m":[{"r":655361,"p":[{"n":"obj","p":131073},{"n":"found","p":262145,"f":2}],"n":"FindElement","d":1503002,"h":30066274074,"f":2},{"r":917505,"p":[{"n":"obj","p":131073},{"n":"firstTime","p":262145,"f":2}],"n":"GetId","d":1503002,"h":34361241370,"f":129},{"r":917505,"p":[{"n":"obj","p":131073},{"n":"firstTime","p":262145,"f":2}],"n":"HasId","d":1503002,"h":38656208666,"f":129},{"r":65537,"n":"Rehash","d":1503002,"h":42951175962,"f":2}],"l":[{"t":655361,"n":"NumBins","d":1503002,"h":4296470298,"f":34},{"t":655361,"n":"_currentCount","d":1503002,"h":8591437594,"f":8},{"t":655361,"n":"_currentSize","d":1503002,"h":12886404890,"f":2},{"t":0,"n":"_ids","d":1503002,"h":17181372186,"f":2},{"t":0,"n":"_objs","d":1503002,"h":21476339482,"f":2}],"c":[{"n":".ctor","o":"$ctor$1","d":1503002,"h":25771306778,"f":1}],"h":1503002,"a":[{"t":70909953,"c":8660844545,"a":[{"v":"Formatter-based serialization is obsolete and should not be used.","t":1310721}],"n":[{"n":"DiagnosticId","v":"SYSLIB0050","t":1310721},{"n":"UrlFormat","v":"https://aka.ms/dotnet-warnings/{0}","t":1310721}]}]}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.Runtime.Serialization.ObjectIDGenerator`; }
        });
        
        $asm.$cls("$srsf.System.SR", ($self) => class SR
        {
            /*global::System.Resources.ResourceManager*/ static s_resourceManager = null;
            /*global::System.Globalization.CultureInfo*/ static resourceCulture = null;
            static /*global::System.Resources.ResourceManager */ get ResourceManager()
            {
                if ($.$spc.System.Object.ReferenceEquals($.$srsf.System.SR.s_resourceManager, null))
                {
                    /*global::System.Resources.ResourceManager*/ let temp = new $.$spc.System.Resources.ResourceManager().$ctor$3("System.Runtime.Serialization.Formatters", $.$srsf.System.SR.$type.Assembly);
                    $.$srsf.System.SR.s_resourceManager = temp;
                }
                return $.$srsf.System.SR.s_resourceManager;
            }
            static /*global::System.Globalization.CultureInfo */ get Culture()
            {
                return $.$srsf.System.SR.resourceCulture;
            }
            static /*global::System.Globalization.CultureInfo */ set Culture(value)
            {
                $.$srsf.System.SR.resourceCulture = value;
            }
            static /*string */ get Arg_HTCapacityOverflow()
            {
                return "Hashtable's capacity overflowed and went negative. Check load factor, capacity and the current size of the table.";
            }
            static /*string */ get Serialization_NonSerType()
            {
                return "Type '{0}' in Assembly '{1}' is not marked as serializable.";
            }
            static /*string */ FormatSerialization_NonSerType(/*object*/ arg1, /*object*/ arg2)
            {
                return $.$spc.System.String.Format$1("Type '{0}' in Assembly '{1}' is not marked as serializable.", arg1, arg2);
            }
            static /*string */ get Argument_DataLengthDifferent()
            {
                return "Parameters 'members' and 'data' must have the same length.";
            }
            static /*string */ get ArgumentNull_NullMember()
            {
                return "Member at position {0} was null.";
            }
            static /*string */ FormatArgumentNull_NullMember(/*object*/ arg1)
            {
                return $.$spc.System.String.Format("Member at position {0} was null.", arg1);
            }
            static /*string */ get Serialization_UnknownMemberInfo()
            {
                return "Only FieldInfo, PropertyInfo, and SerializationMemberInfo are recognized.";
            }
            static /*string */ get Serialization_NoID()
            {
                return "Object has never been assigned an objectID.";
            }
            static /*string */ get Serialization_TooManyElements()
            {
                return "The internal array cannot expand to greater than Int32.MaxValue elements.";
            }
            static /*string */ get Argument_InvalidFieldInfo()
            {
                return "The FieldInfo object is not valid.";
            }
            static /*string */ get Serialization_NeverSeen()
            {
                return "A fixup is registered to the object with ID {0}, but the object does not appear in the graph.";
            }
            static /*string */ FormatSerialization_NeverSeen(/*object*/ arg1)
            {
                return $.$spc.System.String.Format("A fixup is registered to the object with ID {0}, but the object does not appear in the graph.", arg1);
            }
            static /*string */ get Serialization_IORIncomplete()
            {
                return "The object with ID {0} implements the IObjectReference interface for which all dependencies cannot be resolved. The likely cause is two instances of IObjectReference that have a mutual dependency on each other.";
            }
            static /*string */ FormatSerialization_IORIncomplete(/*object*/ arg1)
            {
                return $.$spc.System.String.Format("The object with ID {0} implements the IObjectReference interface for which all dependencies cannot be resolved. The likely cause is two instances of IObjectReference that have a mutual dependency on each other.", arg1);
            }
            static /*string */ get Serialization_ObjectNotSupplied()
            {
                return "The object with ID {0} was referenced in a fixup but does not exist.";
            }
            static /*string */ FormatSerialization_ObjectNotSupplied(/*object*/ arg1)
            {
                return $.$spc.System.String.Format("The object with ID {0} was referenced in a fixup but does not exist.", arg1);
            }
            static /*string */ get Serialization_NotCyclicallyReferenceableSurrogate()
            {
                return "{0}.SetObjectData returns a value that is neither null nor equal to the first parameter. Such Surrogates cannot be part of cyclical reference.";
            }
            static /*string */ FormatSerialization_NotCyclicallyReferenceableSurrogate(/*object*/ arg1)
            {
                return $.$spc.System.String.Format("{0}.SetObjectData returns a value that is neither null nor equal to the first parameter. Such Surrogates cannot be part of cyclical reference.", arg1);
            }
            static /*string */ get Serialization_TooManyReferences()
            {
                return "The implementation of the IObjectReference interface returns too many nested references to other objects that implement IObjectReference.";
            }
            static /*string */ get Serialization_MissingObject()
            {
                return "The object with ID {0} was referenced in a fixup but has not been registered.";
            }
            static /*string */ FormatSerialization_MissingObject(/*object*/ arg1)
            {
                return $.$spc.System.String.Format("The object with ID {0} was referenced in a fixup but has not been registered.", arg1);
            }
            static /*string */ get Serialization_InvalidFixupDiscovered()
            {
                return "A fixup on an object implementing ISerializable or having a surrogate was discovered for an object which does not have a SerializationInfo available.";
            }
            static /*string */ get Serialization_TypeLoadFailure()
            {
                return "Unable to load type {0} required for deserialization.";
            }
            static /*string */ FormatSerialization_TypeLoadFailure(/*object*/ arg1)
            {
                return $.$spc.System.String.Format("Unable to load type {0} required for deserialization.", arg1);
            }
            static /*string */ get Serialization_ValueTypeFixup()
            {
                return "ValueType fixup on Arrays is not implemented.";
            }
            static /*string */ get Serialization_PartialValueTypeFixup()
            {
                return "Fixing up a partially available ValueType chain is not implemented.";
            }
            static /*string */ get Serialization_UnableToFixup()
            {
                return "Cannot perform fixup.";
            }
            static /*string */ get ArgumentOutOfRange_ObjectID()
            {
                return "objectID cannot be less than or equal to zero.";
            }
            static /*string */ get Serialization_RegisterTwice()
            {
                return "An object cannot be registered twice.";
            }
            static /*string */ get Serialization_NotISer()
            {
                return "The given object does not implement the ISerializable interface.";
            }
            static /*string */ get Serialization_ConstructorNotFound()
            {
                return "The constructor to deserialize an object of type '{0}' was not found.";
            }
            static /*string */ FormatSerialization_ConstructorNotFound(/*object*/ arg1)
            {
                return $.$spc.System.String.Format("The constructor to deserialize an object of type '{0}' was not found.", arg1);
            }
            static /*string */ get Serialization_IncorrectNumberOfFixups()
            {
                return "The ObjectManager found an invalid number of fixups. This usually indicates a problem in the Formatter.";
            }
            static /*string */ get Serialization_InvalidFixupType()
            {
                return "A member fixup was registered for an object which implements ISerializable or has a surrogate. In this situation, a delayed fixup must be used.";
            }
            static /*string */ get Serialization_IdTooSmall()
            {
                return "Object IDs must be greater than zero.";
            }
            static /*string */ get Serialization_ParentChildIdentical()
            {
                return "The ID of the containing object cannot be the same as the object ID.";
            }
            static /*string */ get Serialization_InvalidType()
            {
                return "Only system-provided types can be passed to the GetUninitializedObject method. '{0}' is not a valid instance of a type.";
            }
            static /*string */ FormatSerialization_InvalidType(/*object*/ arg1)
            {
                return $.$spc.System.String.Format("Only system-provided types can be passed to the GetUninitializedObject method. '{0}' is not a valid instance of a type.", arg1);
            }
            static /*string */ get Argument_MustSupplyParent()
            {
                return "When supplying the ID of a containing object, the FieldInfo that identifies the current field within that object must also be supplied.";
            }
            static /*string */ get Argument_MemberAndArray()
            {
                return "Cannot supply both a MemberInfo and an Array to indicate the parent of a value type.";
            }
            static /*string */ get Serialization_CorruptedStream()
            {
                return "Invalid BinaryFormatter stream.";
            }
            static /*string */ get Serialization_Stream()
            {
                return "Attempting to deserialize an empty stream.";
            }
            static /*string */ get Serialization_BinaryHeader()
            {
                return "Binary stream '{0}' does not contain a valid BinaryHeader. Possible causes are invalid stream or object version change between serialization and deserialization.";
            }
            static /*string */ FormatSerialization_BinaryHeader(/*object*/ arg1)
            {
                return $.$spc.System.String.Format("Binary stream '{0}' does not contain a valid BinaryHeader. Possible causes are invalid stream or object version change between serialization and deserialization.", arg1);
            }
            static /*string */ get Serialization_TypeExpected()
            {
                return "Invalid expected type.";
            }
            static /*string */ get Serialization_StreamEnd()
            {
                return "End of Stream encountered before parsing was completed.";
            }
            static /*string */ get Serialization_CrossAppDomainError()
            {
                return "Cross-AppDomain BinaryFormatter error; expected '{0}' but received '{1}'.";
            }
            static /*string */ FormatSerialization_CrossAppDomainError(/*object*/ arg1, /*object*/ arg2)
            {
                return $.$spc.System.String.Format$1("Cross-AppDomain BinaryFormatter error; expected '{0}' but received '{1}'.", arg1, arg2);
            }
            static /*string */ get Serialization_Map()
            {
                return "No map for object '{0}'.";
            }
            static /*string */ FormatSerialization_Map(/*object*/ arg1)
            {
                return $.$spc.System.String.Format("No map for object '{0}'.", arg1);
            }
            static /*string */ get Serialization_Assembly()
            {
                return "No assembly information is available for object on the wire, '{0}'.";
            }
            static /*string */ FormatSerialization_Assembly(/*object*/ arg1)
            {
                return $.$spc.System.String.Format("No assembly information is available for object on the wire, '{0}'.", arg1);
            }
            static /*string */ get Serialization_ObjectTypeEnum()
            {
                return "Invalid ObjectTypeEnum {0}.";
            }
            static /*string */ FormatSerialization_ObjectTypeEnum(/*object*/ arg1)
            {
                return $.$spc.System.String.Format("Invalid ObjectTypeEnum {0}.", arg1);
            }
            static /*string */ get Serialization_AssemblyId()
            {
                return "No assembly ID for object type '{0}'.";
            }
            static /*string */ FormatSerialization_AssemblyId(/*object*/ arg1)
            {
                return $.$spc.System.String.Format("No assembly ID for object type '{0}'.", arg1);
            }
            static /*string */ get Serialization_ArrayType()
            {
                return "Invalid array type '{0}'.";
            }
            static /*string */ FormatSerialization_ArrayType(/*object*/ arg1)
            {
                return $.$spc.System.String.Format("Invalid array type '{0}'.", arg1);
            }
            static /*string */ get Serialization_TypeCode()
            {
                return "Invalid type code in stream '{0}'.";
            }
            static /*string */ FormatSerialization_TypeCode(/*object*/ arg1)
            {
                return $.$spc.System.String.Format("Invalid type code in stream '{0}'.", arg1);
            }
            static /*string */ get Serialization_TypeWrite()
            {
                return "Invalid write type request '{0}'.";
            }
            static /*string */ FormatSerialization_TypeWrite(/*object*/ arg1)
            {
                return $.$spc.System.String.Format("Invalid write type request '{0}'.", arg1);
            }
            static /*string */ get Serialization_TypeRead()
            {
                return "Invalid read type request '{0}'.";
            }
            static /*string */ FormatSerialization_TypeRead(/*object*/ arg1)
            {
                return $.$spc.System.String.Format("Invalid read type request '{0}'.", arg1);
            }
            static /*string */ get Serialization_AssemblyNotFound()
            {
                return "Unable to find assembly '{0}'.";
            }
            static /*string */ FormatSerialization_AssemblyNotFound(/*object*/ arg1)
            {
                return $.$spc.System.String.Format("Unable to find assembly '{0}'.", arg1);
            }
            static /*string */ get Serialization_InvalidFormat()
            {
                return "The input stream is not a valid binary format. The starting contents (in bytes) are: {0} ...";
            }
            static /*string */ FormatSerialization_InvalidFormat(/*object*/ arg1)
            {
                return $.$spc.System.String.Format("The input stream is not a valid binary format. The starting contents (in bytes) are: {0} ...", arg1);
            }
            static /*string */ get Serialization_TopObject()
            {
                return "No top object.";
            }
            static /*string */ get Serialization_XMLElement()
            {
                return "Invalid element '{0}'.";
            }
            static /*string */ FormatSerialization_XMLElement(/*object*/ arg1)
            {
                return $.$spc.System.String.Format("Invalid element '{0}'.", arg1);
            }
            static /*string */ get Serialization_TopObjectInstantiate()
            {
                return "Top object cannot be instantiated for element '{0}'.";
            }
            static /*string */ FormatSerialization_TopObjectInstantiate(/*object*/ arg1)
            {
                return $.$spc.System.String.Format("Top object cannot be instantiated for element '{0}'.", arg1);
            }
            static /*string */ get Serialization_ArrayTypeObject()
            {
                return "Array element type is Object, 'dt' attribute is null.";
            }
            static /*string */ get Serialization_TypeMissing()
            {
                return "Type is missing for member of type Object '{0}'.";
            }
            static /*string */ FormatSerialization_TypeMissing(/*object*/ arg1)
            {
                return $.$spc.System.String.Format("Type is missing for member of type Object '{0}'.", arg1);
            }
            static /*string */ get Serialization_ObjNoID()
            {
                return "Object {0} has never been assigned an objectID.";
            }
            static /*string */ FormatSerialization_ObjNoID(/*object*/ arg1)
            {
                return $.$spc.System.String.Format("Object {0} has never been assigned an objectID.", arg1);
            }
            static /*string */ get Serialization_SerMemberInfo()
            {
                return "MemberInfo type {0} cannot be serialized.";
            }
            static /*string */ FormatSerialization_SerMemberInfo(/*object*/ arg1)
            {
                return $.$spc.System.String.Format("MemberInfo type {0} cannot be serialized.", arg1);
            }
            static /*string */ get Argument_MustSupplyContainer()
            {
                return "When supplying a FieldInfo for fixing up a nested type, a valid ID for that containing object must also be supplied.";
            }
            static /*string */ get Serialization_ParseError()
            {
                return "Parse error. Current element is not compatible with the next element, {0}.";
            }
            static /*string */ FormatSerialization_ParseError(/*object*/ arg1)
            {
                return $.$spc.System.String.Format("Parse error. Current element is not compatible with the next element, {0}.", arg1);
            }
            static /*string */ get Serialization_ISerializableMemberInfo()
            {
                return "MemberInfo requested for ISerializable type.";
            }
            static /*string */ get Serialization_MemberInfo()
            {
                return "MemberInfo cannot be obtained for ISerialized Object '{0}'.";
            }
            static /*string */ FormatSerialization_MemberInfo(/*object*/ arg1)
            {
                return $.$spc.System.String.Format("MemberInfo cannot be obtained for ISerialized Object '{0}'.", arg1);
            }
            static /*string */ get Serialization_ISerializableTypes()
            {
                return "Types not available for ISerializable object '{0}'.";
            }
            static /*string */ FormatSerialization_ISerializableTypes(/*object*/ arg1)
            {
                return $.$spc.System.String.Format("Types not available for ISerializable object '{0}'.", arg1);
            }
            static /*string */ get Serialization_MissingMember()
            {
                return "Member '{0}' in class '{1}' is not present in the serialized stream and is not marked with {2}.";
            }
            static /*string */ FormatSerialization_MissingMember(/*object*/ arg1, /*object*/ arg2, /*object*/ arg3)
            {
                return $.$spc.System.String.Format$2("Member '{0}' in class '{1}' is not present in the serialized stream and is not marked with {2}.", arg1, arg2, arg3);
            }
            static /*string */ get Serialization_NoMemberInfo()
            {
                return "No MemberInfo for Object {0}.";
            }
            static /*string */ FormatSerialization_NoMemberInfo(/*object*/ arg1)
            {
                return $.$spc.System.String.Format("No MemberInfo for Object {0}.", arg1);
            }
            static /*string */ get Serialization_SurrogateCycleInArgument()
            {
                return "Selector contained a cycle.";
            }
            static /*string */ get Serialization_SurrogateCycle()
            {
                return "Adding selector will introduce a cycle.";
            }
            static /*string */ get IO_EOF_ReadBeyondEOF()
            {
                return "Unable to read beyond the end of the stream.";
            }
            static /*string */ get BinaryFormatter_SerializationDisallowed()
            {
                return "BinaryFormatter serialization and deserialization are disabled within this application. See https://aka.ms/binaryformatter for more information.";
            }
            static /*string */ get BinaryFormatter_SerializationNotSupportedOnThisPlatform()
            {
                return "BinaryFormatter serialization and deserialization are not supported on this platform. See https://aka.ms/binaryformatter for more information.";
            }
            static /*string */ get BinaryFormatter_Removed()
            {
                return "BinaryFormatter serialization and deserialization have been removed. See https://aka.ms/binaryformatter for more information.";
            }
            /*bool*/ static s_usingResourceKeys = false;
            static /*bool */ GetUsingResourceKeysSwitchValue()
            {
                /*bool*/ let usingResourceKeys;
                return $.$spc.System.AppContext.TryGetSwitch("System.Resources.UseSystemResourceKeys", $.$ref(() => usingResourceKeys, ($v) => usingResourceKeys = $v, $.$spc.System.Boolean)) ? usingResourceKeys : false;
            }
            static /*bool */ UsingResourceKeys()
            {
                return $.$srsf.System.SR.s_usingResourceKeys;
            }
            static /*string */ GetResourceString(/*string*/ resourceKey)
            {
                if ($.$srsf.System.SR.UsingResourceKeys())
                {
                    return resourceKey;
                }
                /*string?*/ let resourceString = null;
                try
                {
                    resourceString = $.$srsf.System.SR.ResourceManager.GetString(resourceKey);
                }
                catch($e)
                {
                }
                return resourceString;
            }
            static /*string */ GetResourceString$1(/*string*/ resourceKey, /*string*/ defaultString)
            {
                /*string*/ let resourceString = $.$srsf.System.SR.GetResourceString(resourceKey);
                return $.$spc.System.String.op_Equality(resourceKey, resourceString) || $.$spc.System.String.op_Equality(resourceString, null) ? defaultString : resourceString;
            }
            static /*string */ Format(/*string*/ resourceFormat, /*object?*/ p1)
            {
                if ($.$srsf.System.SR.UsingResourceKeys())
                {
                    return $.$spc.System.String.Join$10(", ", $.$spc.System.ReadOnlySpan$$($.$spc.System.Object).op_Implicit([ resourceFormat, p1 ]));
                }
                return $.$spc.System.String.Format(resourceFormat, p1);
            }
            static /*string */ Format$1(/*string*/ resourceFormat, /*object?*/ p1, /*object?*/ p2)
            {
                if ($.$srsf.System.SR.UsingResourceKeys())
                {
                    return $.$spc.System.String.Join$10(", ", $.$spc.System.ReadOnlySpan$$($.$spc.System.Object).op_Implicit([ resourceFormat, p1, p2 ]));
                }
                return $.$spc.System.String.Format$1(resourceFormat, p1, p2);
            }
            static /*string */ Format$2(/*string*/ resourceFormat, /*object?*/ p1, /*object?*/ p2, /*object?*/ p3)
            {
                if ($.$srsf.System.SR.UsingResourceKeys())
                {
                    return $.$spc.System.String.Join$10(", ", $.$spc.System.ReadOnlySpan$$($.$spc.System.Object).op_Implicit([ resourceFormat, p1, p2, p3 ]));
                }
                return $.$spc.System.String.Format$2(resourceFormat, p1, p2, p3);
            }
            static /*string */ Format$3(/*string*/ resourceFormat, /*params object?[]?*/ args)
            {
                if (args !== null)
                {
                    if ($.$srsf.System.SR.UsingResourceKeys())
                    {
                        return resourceFormat + ", " + $.$spc.System.String.Join$9(", ", args);
                    }
                    return $.$spc.System.String.Format$3(resourceFormat, args);
                }
                return resourceFormat;
            }
            static /*string */ Format$4(/*IFormatProvider?*/ provider, /*string*/ resourceFormat, /*object?*/ p1)
            {
                if ($.$srsf.System.SR.UsingResourceKeys())
                {
                    return $.$spc.System.String.Join$10(", ", $.$spc.System.ReadOnlySpan$$($.$spc.System.Object).op_Implicit([ resourceFormat, p1 ]));
                }
                return $.$spc.System.String.Format$5(provider, resourceFormat, p1);
            }
            static /*string */ Format$5(/*IFormatProvider?*/ provider, /*string*/ resourceFormat, /*object?*/ p1, /*object?*/ p2)
            {
                if ($.$srsf.System.SR.UsingResourceKeys())
                {
                    return $.$spc.System.String.Join$10(", ", $.$spc.System.ReadOnlySpan$$($.$spc.System.Object).op_Implicit([ resourceFormat, p1, p2 ]));
                }
                return $.$spc.System.String.Format$6(provider, resourceFormat, p1, p2);
            }
            static /*string */ Format$6(/*IFormatProvider?*/ provider, /*string*/ resourceFormat, /*object?*/ p1, /*object?*/ p2, /*object?*/ p3)
            {
                if ($.$srsf.System.SR.UsingResourceKeys())
                {
                    return $.$spc.System.String.Join$10(", ", $.$spc.System.ReadOnlySpan$$($.$spc.System.Object).op_Implicit([ resourceFormat, p1, p2, p3 ]));
                }
                return $.$spc.System.String.Format$7(provider, resourceFormat, p1, p2, p3);
            }
            static /*string */ Format$7(/*IFormatProvider?*/ provider, /*string*/ resourceFormat, /*params object?[]?*/ args)
            {
                if (args !== null)
                {
                    if ($.$srsf.System.SR.UsingResourceKeys())
                    {
                        return resourceFormat + ", " + $.$spc.System.String.Join$9(", ", args);
                    }
                    return $.$spc.System.String.Format$8(provider, resourceFormat, args);
                }
                return resourceFormat;
            }
            //Static Initializer
            static $sinit()
            {
                {
                    this.s_usingResourceKeys = $.$srsf.System.SR.GetUsingResourceKeysSwitchValue();
                }
            }
            static $h = 2486042;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"h":2486042}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.SR`; }
        });
        
        $asm.$cls("$srsf.System.Runtime.Serialization.ValueTypeFixupInfo", ($self) => class ValueTypeFixupInfo extends $.$spc.System.Object
        {
            /*long*/ _containerID = 0n;
            /*FieldInfo?*/ _parentField = null;
            /*int[]?*/ _parentIndex = null;
            $ctor$1(/*long*/ containerID, /*FieldInfo?*/ member, /*int[]?*/ parentIndex)
            {
                super.$ctor();
                {
                    if ($.$spc.System.Reflection.FieldInfo.op_Equality$1(member, null) && parentIndex === null)
                    {
                        throw new $.$spc.System.ArgumentException().$ctor$10($.$srsf.System.SR.Argument_MustSupplyParent);
                    }
                    if (containerID === 0n && $.$spc.System.Reflection.FieldInfo.op_Equality$1(member, null))
                    {
                        this._containerID = containerID;
                        this._parentField = member;
                        this._parentIndex = parentIndex;
                    }
                    if ($.$spc.System.Reflection.FieldInfo.op_Inequality$1(member, null))
                    {
                        if (parentIndex !== null)
                        {
                            throw new $.$spc.System.ArgumentException().$ctor$10($.$srsf.System.SR.Argument_MemberAndArray);
                        }
                        if (member.FieldType.IsValueType && containerID === 0n)
                        {
                            throw new $.$spc.System.ArgumentException().$ctor$10($.$srsf.System.SR.Argument_MustSupplyContainer);
                        }
                    }
                    this._containerID = containerID;
                    this._parentField = member;
                    this._parentIndex = parentIndex;
                }
                return this;
            }
            /*long */ get ContainerID()
            {
                return this._containerID;
            }
            /*FieldInfo? */ get ParentField()
            {
                return this._parentField;
            }
            /*int[]? */ get ParentIndex()
            {
                return this._parentIndex;
            }
            static $h = 2420506;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":917505,"g":{"r":0,"d":0,"h":25772224282,"f":1},"n":"ContainerID","d":2420506,"h":21477256986,"f":1},{"p":76677121,"g":{"r":0,"d":0,"h":34362158874,"f":1},"n":"ParentField","d":2420506,"h":30067191578,"f":1},{"p":0,"g":{"r":0,"d":0,"h":42952093466,"f":1},"n":"ParentIndex","d":2420506,"h":38657126170,"f":1}],"l":[{"t":917505,"n":"_containerID","d":2420506,"h":4297387802,"f":2},{"t":76677121,"n":"_parentField","d":2420506,"h":8592355098,"f":2},{"t":0,"n":"_parentIndex","d":2420506,"h":12887322394,"f":2}],"c":[{"p":[{"n":"containerID","p":917505},{"n":"member","p":76677121},{"n":"parentIndex","p":0}],"n":".ctor","o":"$ctor$1","d":2420506,"h":17182289690,"f":1}],"h":2420506}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.Runtime.Serialization.ValueTypeFixupInfo`; }
        });
        
        $asm.$cls("$srsf.System.Obsoletions", ($self) => class Obsoletions
        {
            /*string*/ static SharedUrlFormat = null;
            /*string*/ static SystemTextEncodingUTF7Message = null;
            /*string*/ static SystemTextEncodingUTF7DiagId = null;
            /*string*/ static PrincipalPermissionAttributeMessage = null;
            /*string*/ static PrincipalPermissionAttributeDiagId = null;
            /*string*/ static CodeAccessSecurityMessage = null;
            /*string*/ static CodeAccessSecurityDiagId = null;
            /*string*/ static ConstrainedExecutionRegionMessage = null;
            /*string*/ static ConstrainedExecutionRegionDiagId = null;
            /*string*/ static GlobalAssemblyCacheMessage = null;
            /*string*/ static GlobalAssemblyCacheDiagId = null;
            /*string*/ static ThreadAbortMessage = null;
            /*string*/ static ThreadResetAbortMessage = null;
            /*string*/ static ThreadAbortDiagId = null;
            /*string*/ static DefaultCryptoAlgorithmsMessage = null;
            /*string*/ static DefaultCryptoAlgorithmsDiagId = null;
            /*string*/ static CreatePdbGeneratorMessage = null;
            /*string*/ static CreatePdbGeneratorDiagId = null;
            /*string*/ static AuthenticationManagerMessage = null;
            /*string*/ static AuthenticationManagerDiagId = null;
            /*string*/ static RemotingApisMessage = null;
            /*string*/ static RemotingApisDiagId = null;
            /*string*/ static BinaryFormatterMessage = null;
            /*string*/ static BinaryFormatterDiagId = null;
            /*string*/ static CodeBaseMessage = null;
            /*string*/ static CodeBaseDiagId = null;
            /*string*/ static EscapeUriStringMessage = null;
            /*string*/ static EscapeUriStringDiagId = null;
            /*string*/ static WebRequestMessage = null;
            /*string*/ static WebRequestDiagId = null;
            /*string*/ static DisablePrivateReflectionAttributeMessage = null;
            /*string*/ static DisablePrivateReflectionAttributeDiagId = null;
            /*string*/ static GetContextInfoMessage = null;
            /*string*/ static GetContextInfoDiagId = null;
            /*string*/ static StrongNameKeyPairMessage = null;
            /*string*/ static StrongNameKeyPairDiagId = null;
            /*string*/ static ReflectionOnlyLoadingMessage = null;
            /*string*/ static ReflectionOnlyLoadingDiagId = null;
            /*string*/ static RuntimeEnvironmentMessage = null;
            /*string*/ static RuntimeEnvironmentDiagId = null;
            /*string*/ static JsonSerializerOptionsIgnoreNullValuesMessage = null;
            /*string*/ static JsonSerializerOptionsIgnoreNullValuesDiagId = null;
            /*string*/ static DerivedCryptographicTypesMessage = null;
            /*string*/ static DerivedCryptographicTypesDiagId = null;
            /*string*/ static RijndaelMessage = null;
            /*string*/ static RijndaelDiagId = null;
            /*string*/ static RNGCryptoServiceProviderMessage = null;
            /*string*/ static RNGCryptoServiceProviderDiagId = null;
            /*string*/ static AppDomainCreateUnloadMessage = null;
            /*string*/ static AppDomainCreateUnloadDiagId = null;
            /*string*/ static SuppressIldasmAttributeMessage = null;
            /*string*/ static SuppressIldasmAttributeDiagId = null;
            /*string*/ static X509CertificateImmutableMessage = null;
            /*string*/ static X509CertificateImmutableDiagId = null;
            /*string*/ static PublicKeyPropertyMessage = null;
            /*string*/ static PublicKeyPropertyDiagId = null;
            /*string*/ static X509CertificatePrivateKeyMessage = null;
            /*string*/ static X509CertificatePrivateKeyDiagId = null;
            /*string*/ static ProduceLegacyHmacValuesMessage = null;
            /*string*/ static ProduceLegacyHmacValuesDiagId = null;
            /*string*/ static UseManagedSha1Message = null;
            /*string*/ static UseManagedSha1DiagId = null;
            /*string*/ static CryptoConfigEncodeOIDMessage = null;
            /*string*/ static CryptoConfigEncodeOIDDiagId = null;
            /*string*/ static CorruptedStateRecoveryMessage = null;
            /*string*/ static CorruptedStateRecoveryDiagId = null;
            /*string*/ static Rfc2898CryptDeriveKeyMessage = null;
            /*string*/ static Rfc2898CryptDeriveKeyDiagId = null;
            /*string*/ static CmsSignerCspParamsCtorMessage = null;
            /*string*/ static CmsSignerCspParamsCtorDiagId = null;
            /*string*/ static SignerInfoCounterSigMessage = null;
            /*string*/ static SignerInfoCounterSigDiagId = null;
            /*string*/ static RegexCompileToAssemblyMessage = null;
            /*string*/ static RegexCompileToAssemblyDiagId = null;
            /*string*/ static AssemblyNameMembersMessage = null;
            /*string*/ static AssemblyNameMembersDiagId = null;
            /*string*/ static SystemDataSerializationFormatBinaryMessage = null;
            /*string*/ static SystemDataSerializationFormatBinaryDiagId = null;
            /*string*/ static TlsVersion10and11Message = null;
            /*string*/ static TlsVersion10and11DiagId = null;
            /*string*/ static EncryptionPolicyMessage = null;
            /*string*/ static EncryptionPolicyDiagId = null;
            /*string*/ static EccXmlExportImportMessage = null;
            /*string*/ static EccXmlExportImportDiagId = null;
            /*string*/ static EcDhPublicKeyBlobMessage = null;
            /*string*/ static EcDhPublicKeyBlobDiagId = null;
            /*string*/ static AssemblyNameCodeBaseMessage = null;
            /*string*/ static AssemblyNameCodeBaseDiagId = null;
            /*string*/ static CryptoStringFactoryMessage = null;
            /*string*/ static CryptoStringFactoryDiagId = null;
            /*string*/ static ControlledExecutionRunMessage = null;
            /*string*/ static ControlledExecutionRunDiagId = null;
            /*string*/ static XmlSecureResolverMessage = null;
            /*string*/ static XmlSecureResolverDiagId = null;
            /*string*/ static RsaEncryptDecryptValueMessage = null;
            /*string*/ static RsaEncryptDecryptDiagId = null;
            /*string*/ static JsonSerializerOptionsAddContextMessage = null;
            /*string*/ static JsonSerializerOptionsAddContextDiagId = null;
            /*string*/ static LegacyFormatterMessage = null;
            /*string*/ static LegacyFormatterDiagId = null;
            /*string*/ static LegacyFormatterImplMessage = null;
            /*string*/ static LegacyFormatterImplDiagId = null;
            /*string*/ static RegexExtensibilityImplMessage = null;
            /*string*/ static RegexExtensibilityDiagId = null;
            /*string*/ static AesGcmTagConstructorMessage = null;
            /*string*/ static AesGcmTagConstructorDiagId = null;
            /*string*/ static ThreadVolatileReadWriteMessage = null;
            /*string*/ static ThreadVolatileReadWriteDiagId = null;
            /*string*/ static ArmIntrinsicPerformsUnsignedOperationMessage = null;
            /*string*/ static ArmIntrinsicPerformsUnsignedOperationDiagId = null;
            /*string*/ static LoadFromHashAlgorithmMessage = null;
            /*string*/ static LoadFromHashAlgorithmDiagId = null;
            /*string*/ static X509CtorCertDataObsoleteMessage = null;
            /*string*/ static X509CtorCertDataObsoleteDiagId = null;
            /*string*/ static TlsCipherAlgorithmEnumsMessage = null;
            /*string*/ static TlsCipherAlgorithmEnumsDiagId = null;
            /*string*/ static SystemEventsEventsThreadShutdownMessage = null;
            /*string*/ static SystemEventsEventsThreadShutdownDiagId = null;
            /*string*/ static Rfc2898DeriveBytesCtorMessage = null;
            /*string*/ static Rfc2898DeriveBytesCtorDiagId = null;
            /*string*/ static QueryableMinByMaxByTSourceObsoleteMessage = null;
            /*string*/ static QueryableMinByMaxByTSourceObsoleteDiagId = null;
            /*string*/ static XsltSettingsEnableScriptMessage = null;
            /*string*/ static XsltSettingsEnableScriptDiagId = null;
            //Static Initializer
            static $sinit()
            {
                {
                    this.SharedUrlFormat = "https://aka.ms/dotnet-warnings/{0}";
                }
                {
                    this.SystemTextEncodingUTF7Message = "The UTF-7 encoding is insecure and should not be used. Consider using UTF-8 instead.";
                }
                {
                    this.SystemTextEncodingUTF7DiagId = "SYSLIB0001";
                }
                {
                    this.PrincipalPermissionAttributeMessage = "PrincipalPermissionAttribute is not honored by the runtime and must not be used.";
                }
                {
                    this.PrincipalPermissionAttributeDiagId = "SYSLIB0002";
                }
                {
                    this.CodeAccessSecurityMessage = "Code Access Security is not supported or honored by the runtime.";
                }
                {
                    this.CodeAccessSecurityDiagId = "SYSLIB0003";
                }
                {
                    this.ConstrainedExecutionRegionMessage = "The Constrained Execution Region (CER) feature is not supported.";
                }
                {
                    this.ConstrainedExecutionRegionDiagId = "SYSLIB0004";
                }
                {
                    this.GlobalAssemblyCacheMessage = "The Global Assembly Cache is not supported.";
                }
                {
                    this.GlobalAssemblyCacheDiagId = "SYSLIB0005";
                }
                {
                    this.ThreadAbortMessage = "Thread.Abort is not supported and throws PlatformNotSupportedException.";
                }
                {
                    this.ThreadResetAbortMessage = "Thread.ResetAbort is not supported and throws PlatformNotSupportedException.";
                }
                {
                    this.ThreadAbortDiagId = "SYSLIB0006";
                }
                {
                    this.DefaultCryptoAlgorithmsMessage = "The default implementation of this cryptography algorithm is not supported.";
                }
                {
                    this.DefaultCryptoAlgorithmsDiagId = "SYSLIB0007";
                }
                {
                    this.CreatePdbGeneratorMessage = "The CreatePdbGenerator API is not supported and throws PlatformNotSupportedException.";
                }
                {
                    this.CreatePdbGeneratorDiagId = "SYSLIB0008";
                }
                {
                    this.AuthenticationManagerMessage = "AuthenticationManager is not supported. Methods will no-op or throw PlatformNotSupportedException.";
                }
                {
                    this.AuthenticationManagerDiagId = "SYSLIB0009";
                }
                {
                    this.RemotingApisMessage = "This Remoting API is not supported and throws PlatformNotSupportedException.";
                }
                {
                    this.RemotingApisDiagId = "SYSLIB0010";
                }
                {
                    this.BinaryFormatterMessage = "BinaryFormatter serialization is obsolete and should not be used. See https://aka.ms/binaryformatter for more information.";
                }
                {
                    this.BinaryFormatterDiagId = "SYSLIB0011";
                }
                {
                    this.CodeBaseMessage = "Assembly.CodeBase and Assembly.EscapedCodeBase are only included for .NET Framework compatibility. Use Assembly.Location instead.";
                }
                {
                    this.CodeBaseDiagId = "SYSLIB0012";
                }
                {
                    this.EscapeUriStringMessage = "Uri.EscapeUriString can corrupt the Uri string in some cases. Consider using Uri.EscapeDataString for query string components instead.";
                }
                {
                    this.EscapeUriStringDiagId = "SYSLIB0013";
                }
                {
                    this.WebRequestMessage = "WebRequest, HttpWebRequest, ServicePoint, and WebClient are obsolete. Use HttpClient instead.";
                }
                {
                    this.WebRequestDiagId = "SYSLIB0014";
                }
                {
                    this.DisablePrivateReflectionAttributeMessage = "DisablePrivateReflectionAttribute has no effect in .NET 6.0+.";
                }
                {
                    this.DisablePrivateReflectionAttributeDiagId = "SYSLIB0015";
                }
                {
                    this.GetContextInfoMessage = "Use the Graphics.GetContextInfo overloads that accept arguments for better performance and fewer allocations.";
                }
                {
                    this.GetContextInfoDiagId = "SYSLIB0016";
                }
                {
                    this.StrongNameKeyPairMessage = "Strong name signing is not supported and throws PlatformNotSupportedException.";
                }
                {
                    this.StrongNameKeyPairDiagId = "SYSLIB0017";
                }
                {
                    this.ReflectionOnlyLoadingMessage = "ReflectionOnly loading is not supported and throws PlatformNotSupportedException.";
                }
                {
                    this.ReflectionOnlyLoadingDiagId = "SYSLIB0018";
                }
                {
                    this.RuntimeEnvironmentMessage = "RuntimeEnvironment members SystemConfigurationFile, GetRuntimeInterfaceAsIntPtr, and GetRuntimeInterfaceAsObject are not supported and throw PlatformNotSupportedException.";
                }
                {
                    this.RuntimeEnvironmentDiagId = "SYSLIB0019";
                }
                {
                    this.JsonSerializerOptionsIgnoreNullValuesMessage = "JsonSerializerOptions.IgnoreNullValues is obsolete. To ignore null values when serializing, set DefaultIgnoreCondition to JsonIgnoreCondition.WhenWritingNull.";
                }
                {
                    this.JsonSerializerOptionsIgnoreNullValuesDiagId = "SYSLIB0020";
                }
                {
                    this.DerivedCryptographicTypesMessage = "Derived cryptographic types are obsolete. Use the Create method on the base type instead.";
                }
                {
                    this.DerivedCryptographicTypesDiagId = "SYSLIB0021";
                }
                {
                    this.RijndaelMessage = "The Rijndael and RijndaelManaged types are obsolete. Use Aes instead.";
                }
                {
                    this.RijndaelDiagId = "SYSLIB0022";
                }
                {
                    this.RNGCryptoServiceProviderMessage = "RNGCryptoServiceProvider is obsolete. To generate a random number, use one of the RandomNumberGenerator static methods instead.";
                }
                {
                    this.RNGCryptoServiceProviderDiagId = "SYSLIB0023";
                }
                {
                    this.AppDomainCreateUnloadMessage = "Creating and unloading AppDomains is not supported and throws an exception.";
                }
                {
                    this.AppDomainCreateUnloadDiagId = "SYSLIB0024";
                }
                {
                    this.SuppressIldasmAttributeMessage = "SuppressIldasmAttribute has no effect in .NET 6.0+.";
                }
                {
                    this.SuppressIldasmAttributeDiagId = "SYSLIB0025";
                }
                {
                    this.X509CertificateImmutableMessage = "X509Certificate and X509Certificate2 are immutable. Use X509CertificateLoader to create a new certificate.";
                }
                {
                    this.X509CertificateImmutableDiagId = "SYSLIB0026";
                }
                {
                    this.PublicKeyPropertyMessage = "PublicKey.Key is obsolete. Use the appropriate method to get the public key, such as GetRSAPublicKey.";
                }
                {
                    this.PublicKeyPropertyDiagId = "SYSLIB0027";
                }
                {
                    this.X509CertificatePrivateKeyMessage = "X509Certificate2.PrivateKey is obsolete. Use the appropriate method to get the private key, such as GetRSAPrivateKey, or use the CopyWithPrivateKey method to create a new instance with a private key.";
                }
                {
                    this.X509CertificatePrivateKeyDiagId = "SYSLIB0028";
                }
                {
                    this.ProduceLegacyHmacValuesMessage = "ProduceLegacyHmacValues is obsolete. Producing legacy HMAC values is not supported.";
                }
                {
                    this.ProduceLegacyHmacValuesDiagId = "SYSLIB0029";
                }
                {
                    this.UseManagedSha1Message = "HMACSHA1 always uses the algorithm implementation provided by the platform. Use a constructor without the useManagedSha1 parameter.";
                }
                {
                    this.UseManagedSha1DiagId = "SYSLIB0030";
                }
                {
                    this.CryptoConfigEncodeOIDMessage = "EncodeOID is obsolete. Use the ASN.1 functionality provided in System.Formats.Asn1.";
                }
                {
                    this.CryptoConfigEncodeOIDDiagId = "SYSLIB0031";
                }
                {
                    this.CorruptedStateRecoveryMessage = "Recovery from corrupted process state exceptions is not supported; HandleProcessCorruptedStateExceptionsAttribute is ignored.";
                }
                {
                    this.CorruptedStateRecoveryDiagId = "SYSLIB0032";
                }
                {
                    this.Rfc2898CryptDeriveKeyMessage = "Rfc2898DeriveBytes.CryptDeriveKey is obsolete and is not supported. Use PasswordDeriveBytes.CryptDeriveKey instead.";
                }
                {
                    this.Rfc2898CryptDeriveKeyDiagId = "SYSLIB0033";
                }
                {
                    this.CmsSignerCspParamsCtorMessage = "CmsSigner(CspParameters) is obsolete and is not supported. Use an alternative constructor instead.";
                }
                {
                    this.CmsSignerCspParamsCtorDiagId = "SYSLIB0034";
                }
                {
                    this.SignerInfoCounterSigMessage = "ComputeCounterSignature without specifying a CmsSigner is obsolete and is not supported. Use the overload that accepts a CmsSigner.";
                }
                {
                    this.SignerInfoCounterSigDiagId = "SYSLIB0035";
                }
                {
                    this.RegexCompileToAssemblyMessage = "Regex.CompileToAssembly is obsolete and not supported. Use the GeneratedRegexAttribute with the regular expression source generator instead.";
                }
                {
                    this.RegexCompileToAssemblyDiagId = "SYSLIB0036";
                }
                {
                    this.AssemblyNameMembersMessage = "AssemblyName members HashAlgorithm, ProcessorArchitecture, and VersionCompatibility are obsolete and not supported.";
                }
                {
                    this.AssemblyNameMembersDiagId = "SYSLIB0037";
                }
                {
                    this.SystemDataSerializationFormatBinaryMessage = "SerializationFormat.Binary is obsolete and should not be used. See https://aka.ms/serializationformat-binary-obsolete for more information.";
                }
                {
                    this.SystemDataSerializationFormatBinaryDiagId = "SYSLIB0038";
                }
                {
                    this.TlsVersion10and11Message = "TLS versions 1.0 and 1.1 have known vulnerabilities and are not recommended. Use a newer TLS version instead, or use SslProtocols.None to defer to OS defaults.";
                }
                {
                    this.TlsVersion10and11DiagId = "SYSLIB0039";
                }
                {
                    this.EncryptionPolicyMessage = "EncryptionPolicy.NoEncryption and AllowEncryption significantly reduce security and should not be used in production code.";
                }
                {
                    this.EncryptionPolicyDiagId = "SYSLIB0040";
                }
                {
                    this.EccXmlExportImportMessage = "ToXmlString and FromXmlString have no implementation for ECC types, and are obsolete. Use a standard import and export format such as ExportSubjectPublicKeyInfo or ImportSubjectPublicKeyInfo for public keys and ExportPkcs8PrivateKey or ImportPkcs8PrivateKey for private keys.";
                }
                {
                    this.EccXmlExportImportDiagId = "SYSLIB0042";
                }
                {
                    this.EcDhPublicKeyBlobMessage = "ECDiffieHellmanPublicKey.ToByteArray() and the associated constructor do not have a consistent and interoperable implementation on all platforms. Use ECDiffieHellmanPublicKey.ExportSubjectPublicKeyInfo() instead.";
                }
                {
                    this.EcDhPublicKeyBlobDiagId = "SYSLIB0043";
                }
                {
                    this.AssemblyNameCodeBaseMessage = "AssemblyName.CodeBase and AssemblyName.EscapedCodeBase are obsolete. Using them for loading an assembly is not supported.";
                }
                {
                    this.AssemblyNameCodeBaseDiagId = "SYSLIB0044";
                }
                {
                    this.CryptoStringFactoryMessage = "Cryptographic factory methods accepting an algorithm name are obsolete. Use the parameterless Create factory method on the algorithm type instead.";
                }
                {
                    this.CryptoStringFactoryDiagId = "SYSLIB0045";
                }
                {
                    this.ControlledExecutionRunMessage = "ControlledExecution.Run method may corrupt the process and should not be used in production code.";
                }
                {
                    this.ControlledExecutionRunDiagId = "SYSLIB0046";
                }
                {
                    this.XmlSecureResolverMessage = "XmlSecureResolver is obsolete. Use XmlResolver.ThrowingResolver instead when attempting to forbid XML external entity resolution.";
                }
                {
                    this.XmlSecureResolverDiagId = "SYSLIB0047";
                }
                {
                    this.RsaEncryptDecryptValueMessage = "RSA.EncryptValue and DecryptValue are not supported and throw NotSupportedException. Use RSA.Encrypt and RSA.Decrypt instead.";
                }
                {
                    this.RsaEncryptDecryptDiagId = "SYSLIB0048";
                }
                {
                    this.JsonSerializerOptionsAddContextMessage = "JsonSerializerOptions.AddContext is obsolete. To register a JsonSerializerContext, use either the TypeInfoResolver or TypeInfoResolverChain properties.";
                }
                {
                    this.JsonSerializerOptionsAddContextDiagId = "SYSLIB0049";
                }
                {
                    this.LegacyFormatterMessage = "Formatter-based serialization is obsolete and should not be used.";
                }
                {
                    this.LegacyFormatterDiagId = "SYSLIB0050";
                }
                {
                    this.LegacyFormatterImplMessage = "This API supports obsolete formatter-based serialization. It should not be called or extended by application code.";
                }
                {
                    this.LegacyFormatterImplDiagId = "SYSLIB0051";
                }
                {
                    this.RegexExtensibilityImplMessage = "This API supports obsolete mechanisms for Regex extensibility. It is not supported.";
                }
                {
                    this.RegexExtensibilityDiagId = "SYSLIB0052";
                }
                {
                    this.AesGcmTagConstructorMessage = "AesGcm should indicate the required tag size for encryption and decryption. Use a constructor that accepts the tag size.";
                }
                {
                    this.AesGcmTagConstructorDiagId = "SYSLIB0053";
                }
                {
                    this.ThreadVolatileReadWriteMessage = "Thread.VolatileRead and Thread.VolatileWrite are obsolete. Use Volatile.Read or Volatile.Write respectively instead.";
                }
                {
                    this.ThreadVolatileReadWriteDiagId = "SYSLIB0054";
                }
                {
                    this.ArmIntrinsicPerformsUnsignedOperationMessage = "The underlying hardware instruction does not perform a signed saturate narrowing operation, and it always returns an unsigned result. Use the unsigned overload instead.";
                }
                {
                    this.ArmIntrinsicPerformsUnsignedOperationDiagId = "SYSLIB0055";
                }
                {
                    this.LoadFromHashAlgorithmMessage = "LoadFrom with a custom AssemblyHashAlgorithm is obsolete. Use overloads without an AssemblyHashAlgorithm.";
                }
                {
                    this.LoadFromHashAlgorithmDiagId = "SYSLIB0056";
                }
                {
                    this.X509CtorCertDataObsoleteMessage = "Loading certificate data through the constructor or Import is obsolete. Use X509CertificateLoader instead to load certificates.";
                }
                {
                    this.X509CtorCertDataObsoleteDiagId = "SYSLIB0057";
                }
                {
                    this.TlsCipherAlgorithmEnumsMessage = "KeyExchangeAlgorithm, KeyExchangeStrength, CipherAlgorithm, CipherStrength, HashAlgorithm and HashStrength properties of SslStream are obsolete. Use NegotiatedCipherSuite instead.";
                }
                {
                    this.TlsCipherAlgorithmEnumsDiagId = "SYSLIB0058";
                }
                {
                    this.SystemEventsEventsThreadShutdownMessage = "SystemEvents.EventsThreadShutdown callbacks are not run before the process exits. Use AppDomain.ProcessExit instead.";
                }
                {
                    this.SystemEventsEventsThreadShutdownDiagId = "SYSLIB0059";
                }
                {
                    this.Rfc2898DeriveBytesCtorMessage = "The constructors on Rfc2898DeriveBytes are obsolete. Use the static Pbkdf2 method instead.";
                }
                {
                    this.Rfc2898DeriveBytesCtorDiagId = "SYSLIB0060";
                }
                {
                    this.QueryableMinByMaxByTSourceObsoleteMessage = "The Queryable MinBy and MaxBy taking an IComparer<TSource> are obsolete. Use the new ones that take an IComparer<TKey>.";
                }
                {
                    this.QueryableMinByMaxByTSourceObsoleteDiagId = "SYSLIB0061";
                }
                {
                    this.XsltSettingsEnableScriptMessage = "XSLT Script blocks are not supported.";
                }
                {
                    this.XsltSettingsEnableScriptDiagId = "SYSLIB0062";
                }
            }
            static $h = 192282;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"l":[{"t":1310721,"n":"SharedUrlFormat","d":192282,"h":4295159578,"f":40},{"t":1310721,"n":"SystemTextEncodingUTF7Message","d":192282,"h":8590126874,"f":40},{"t":1310721,"n":"SystemTextEncodingUTF7DiagId","d":192282,"h":12885094170,"f":40},{"t":1310721,"n":"PrincipalPermissionAttributeMessage","d":192282,"h":17180061466,"f":40},{"t":1310721,"n":"PrincipalPermissionAttributeDiagId","d":192282,"h":21475028762,"f":40},{"t":1310721,"n":"CodeAccessSecurityMessage","d":192282,"h":25769996058,"f":40},{"t":1310721,"n":"CodeAccessSecurityDiagId","d":192282,"h":30064963354,"f":40},{"t":1310721,"n":"ConstrainedExecutionRegionMessage","d":192282,"h":34359930650,"f":40},{"t":1310721,"n":"ConstrainedExecutionRegionDiagId","d":192282,"h":38654897946,"f":40},{"t":1310721,"n":"GlobalAssemblyCacheMessage","d":192282,"h":42949865242,"f":40},{"t":1310721,"n":"GlobalAssemblyCacheDiagId","d":192282,"h":47244832538,"f":40},{"t":1310721,"n":"ThreadAbortMessage","d":192282,"h":51539799834,"f":40},{"t":1310721,"n":"ThreadResetAbortMessage","d":192282,"h":55834767130,"f":40},{"t":1310721,"n":"ThreadAbortDiagId","d":192282,"h":60129734426,"f":40},{"t":1310721,"n":"DefaultCryptoAlgorithmsMessage","d":192282,"h":64424701722,"f":40},{"t":1310721,"n":"DefaultCryptoAlgorithmsDiagId","d":192282,"h":68719669018,"f":40},{"t":1310721,"n":"CreatePdbGeneratorMessage","d":192282,"h":73014636314,"f":40},{"t":1310721,"n":"CreatePdbGeneratorDiagId","d":192282,"h":77309603610,"f":40},{"t":1310721,"n":"AuthenticationManagerMessage","d":192282,"h":81604570906,"f":40},{"t":1310721,"n":"AuthenticationManagerDiagId","d":192282,"h":85899538202,"f":40},{"t":1310721,"n":"RemotingApisMessage","d":192282,"h":90194505498,"f":40},{"t":1310721,"n":"RemotingApisDiagId","d":192282,"h":94489472794,"f":40},{"t":1310721,"n":"BinaryFormatterMessage","d":192282,"h":98784440090,"f":40},{"t":1310721,"n":"BinaryFormatterDiagId","d":192282,"h":103079407386,"f":40},{"t":1310721,"n":"CodeBaseMessage","d":192282,"h":107374374682,"f":40},{"t":1310721,"n":"CodeBaseDiagId","d":192282,"h":111669341978,"f":40},{"t":1310721,"n":"EscapeUriStringMessage","d":192282,"h":115964309274,"f":40},{"t":1310721,"n":"EscapeUriStringDiagId","d":192282,"h":120259276570,"f":40},{"t":1310721,"n":"WebRequestMessage","d":192282,"h":124554243866,"f":40},{"t":1310721,"n":"WebRequestDiagId","d":192282,"h":128849211162,"f":40},{"t":1310721,"n":"DisablePrivateReflectionAttributeMessage","d":192282,"h":133144178458,"f":40},{"t":1310721,"n":"DisablePrivateReflectionAttributeDiagId","d":192282,"h":137439145754,"f":40},{"t":1310721,"n":"GetContextInfoMessage","d":192282,"h":141734113050,"f":40},{"t":1310721,"n":"GetContextInfoDiagId","d":192282,"h":146029080346,"f":40},{"t":1310721,"n":"StrongNameKeyPairMessage","d":192282,"h":150324047642,"f":40},{"t":1310721,"n":"StrongNameKeyPairDiagId","d":192282,"h":154619014938,"f":40},{"t":1310721,"n":"ReflectionOnlyLoadingMessage","d":192282,"h":158913982234,"f":40},{"t":1310721,"n":"ReflectionOnlyLoadingDiagId","d":192282,"h":163208949530,"f":40},{"t":1310721,"n":"RuntimeEnvironmentMessage","d":192282,"h":167503916826,"f":40},{"t":1310721,"n":"RuntimeEnvironmentDiagId","d":192282,"h":171798884122,"f":40},{"t":1310721,"n":"JsonSerializerOptionsIgnoreNullValuesMessage","d":192282,"h":176093851418,"f":40},{"t":1310721,"n":"JsonSerializerOptionsIgnoreNullValuesDiagId","d":192282,"h":180388818714,"f":40},{"t":1310721,"n":"DerivedCryptographicTypesMessage","d":192282,"h":184683786010,"f":40},{"t":1310721,"n":"DerivedCryptographicTypesDiagId","d":192282,"h":188978753306,"f":40},{"t":1310721,"n":"RijndaelMessage","d":192282,"h":193273720602,"f":40},{"t":1310721,"n":"RijndaelDiagId","d":192282,"h":197568687898,"f":40},{"t":1310721,"n":"RNGCryptoServiceProviderMessage","d":192282,"h":201863655194,"f":40},{"t":1310721,"n":"RNGCryptoServiceProviderDiagId","d":192282,"h":206158622490,"f":40},{"t":1310721,"n":"AppDomainCreateUnloadMessage","d":192282,"h":210453589786,"f":40},{"t":1310721,"n":"AppDomainCreateUnloadDiagId","d":192282,"h":214748557082,"f":40},{"t":1310721,"n":"SuppressIldasmAttributeMessage","d":192282,"h":219043524378,"f":40},{"t":1310721,"n":"SuppressIldasmAttributeDiagId","d":192282,"h":223338491674,"f":40},{"t":1310721,"n":"X509CertificateImmutableMessage","d":192282,"h":227633458970,"f":40},{"t":1310721,"n":"X509CertificateImmutableDiagId","d":192282,"h":231928426266,"f":40},{"t":1310721,"n":"PublicKeyPropertyMessage","d":192282,"h":236223393562,"f":40},{"t":1310721,"n":"PublicKeyPropertyDiagId","d":192282,"h":240518360858,"f":40},{"t":1310721,"n":"X509CertificatePrivateKeyMessage","d":192282,"h":244813328154,"f":40},{"t":1310721,"n":"X509CertificatePrivateKeyDiagId","d":192282,"h":249108295450,"f":40},{"t":1310721,"n":"ProduceLegacyHmacValuesMessage","d":192282,"h":253403262746,"f":40},{"t":1310721,"n":"ProduceLegacyHmacValuesDiagId","d":192282,"h":257698230042,"f":40},{"t":1310721,"n":"UseManagedSha1Message","d":192282,"h":261993197338,"f":40},{"t":1310721,"n":"UseManagedSha1DiagId","d":192282,"h":266288164634,"f":40},{"t":1310721,"n":"CryptoConfigEncodeOIDMessage","d":192282,"h":270583131930,"f":40},{"t":1310721,"n":"CryptoConfigEncodeOIDDiagId","d":192282,"h":274878099226,"f":40},{"t":1310721,"n":"CorruptedStateRecoveryMessage","d":192282,"h":279173066522,"f":40},{"t":1310721,"n":"CorruptedStateRecoveryDiagId","d":192282,"h":283468033818,"f":40},{"t":1310721,"n":"Rfc2898CryptDeriveKeyMessage","d":192282,"h":287763001114,"f":40},{"t":1310721,"n":"Rfc2898CryptDeriveKeyDiagId","d":192282,"h":292057968410,"f":40},{"t":1310721,"n":"CmsSignerCspParamsCtorMessage","d":192282,"h":296352935706,"f":40},{"t":1310721,"n":"CmsSignerCspParamsCtorDiagId","d":192282,"h":300647903002,"f":40},{"t":1310721,"n":"SignerInfoCounterSigMessage","d":192282,"h":304942870298,"f":40},{"t":1310721,"n":"SignerInfoCounterSigDiagId","d":192282,"h":309237837594,"f":40},{"t":1310721,"n":"RegexCompileToAssemblyMessage","d":192282,"h":313532804890,"f":40},{"t":1310721,"n":"RegexCompileToAssemblyDiagId","d":192282,"h":317827772186,"f":40},{"t":1310721,"n":"AssemblyNameMembersMessage","d":192282,"h":322122739482,"f":40},{"t":1310721,"n":"AssemblyNameMembersDiagId","d":192282,"h":326417706778,"f":40},{"t":1310721,"n":"SystemDataSerializationFormatBinaryMessage","d":192282,"h":330712674074,"f":40},{"t":1310721,"n":"SystemDataSerializationFormatBinaryDiagId","d":192282,"h":335007641370,"f":40},{"t":1310721,"n":"TlsVersion10and11Message","d":192282,"h":339302608666,"f":40},{"t":1310721,"n":"TlsVersion10and11DiagId","d":192282,"h":343597575962,"f":40},{"t":1310721,"n":"EncryptionPolicyMessage","d":192282,"h":347892543258,"f":40},{"t":1310721,"n":"EncryptionPolicyDiagId","d":192282,"h":352187510554,"f":40},{"t":1310721,"n":"EccXmlExportImportMessage","d":192282,"h":356482477850,"f":40},{"t":1310721,"n":"EccXmlExportImportDiagId","d":192282,"h":360777445146,"f":40},{"t":1310721,"n":"EcDhPublicKeyBlobMessage","d":192282,"h":365072412442,"f":40},{"t":1310721,"n":"EcDhPublicKeyBlobDiagId","d":192282,"h":369367379738,"f":40},{"t":1310721,"n":"AssemblyNameCodeBaseMessage","d":192282,"h":373662347034,"f":40},{"t":1310721,"n":"AssemblyNameCodeBaseDiagId","d":192282,"h":377957314330,"f":40},{"t":1310721,"n":"CryptoStringFactoryMessage","d":192282,"h":382252281626,"f":40},{"t":1310721,"n":"CryptoStringFactoryDiagId","d":192282,"h":386547248922,"f":40},{"t":1310721,"n":"ControlledExecutionRunMessage","d":192282,"h":390842216218,"f":40},{"t":1310721,"n":"ControlledExecutionRunDiagId","d":192282,"h":395137183514,"f":40},{"t":1310721,"n":"XmlSecureResolverMessage","d":192282,"h":399432150810,"f":40},{"t":1310721,"n":"XmlSecureResolverDiagId","d":192282,"h":403727118106,"f":40},{"t":1310721,"n":"RsaEncryptDecryptValueMessage","d":192282,"h":408022085402,"f":40},{"t":1310721,"n":"RsaEncryptDecryptDiagId","d":192282,"h":412317052698,"f":40},{"t":1310721,"n":"JsonSerializerOptionsAddContextMessage","d":192282,"h":416612019994,"f":40},{"t":1310721,"n":"JsonSerializerOptionsAddContextDiagId","d":192282,"h":420906987290,"f":40},{"t":1310721,"n":"LegacyFormatterMessage","d":192282,"h":425201954586,"f":40},{"t":1310721,"n":"LegacyFormatterDiagId","d":192282,"h":429496921882,"f":40},{"t":1310721,"n":"LegacyFormatterImplMessage","d":192282,"h":433791889178,"f":40},{"t":1310721,"n":"LegacyFormatterImplDiagId","d":192282,"h":438086856474,"f":40},{"t":1310721,"n":"RegexExtensibilityImplMessage","d":192282,"h":442381823770,"f":40},{"t":1310721,"n":"RegexExtensibilityDiagId","d":192282,"h":446676791066,"f":40},{"t":1310721,"n":"AesGcmTagConstructorMessage","d":192282,"h":450971758362,"f":40},{"t":1310721,"n":"AesGcmTagConstructorDiagId","d":192282,"h":455266725658,"f":40},{"t":1310721,"n":"ThreadVolatileReadWriteMessage","d":192282,"h":459561692954,"f":40},{"t":1310721,"n":"ThreadVolatileReadWriteDiagId","d":192282,"h":463856660250,"f":40},{"t":1310721,"n":"ArmIntrinsicPerformsUnsignedOperationMessage","d":192282,"h":468151627546,"f":40},{"t":1310721,"n":"ArmIntrinsicPerformsUnsignedOperationDiagId","d":192282,"h":472446594842,"f":40},{"t":1310721,"n":"LoadFromHashAlgorithmMessage","d":192282,"h":476741562138,"f":40},{"t":1310721,"n":"LoadFromHashAlgorithmDiagId","d":192282,"h":481036529434,"f":40},{"t":1310721,"n":"X509CtorCertDataObsoleteMessage","d":192282,"h":485331496730,"f":40},{"t":1310721,"n":"X509CtorCertDataObsoleteDiagId","d":192282,"h":489626464026,"f":40},{"t":1310721,"n":"TlsCipherAlgorithmEnumsMessage","d":192282,"h":493921431322,"f":40},{"t":1310721,"n":"TlsCipherAlgorithmEnumsDiagId","d":192282,"h":498216398618,"f":40},{"t":1310721,"n":"SystemEventsEventsThreadShutdownMessage","d":192282,"h":502511365914,"f":40},{"t":1310721,"n":"SystemEventsEventsThreadShutdownDiagId","d":192282,"h":506806333210,"f":40},{"t":1310721,"n":"Rfc2898DeriveBytesCtorMessage","d":192282,"h":511101300506,"f":40},{"t":1310721,"n":"Rfc2898DeriveBytesCtorDiagId","d":192282,"h":515396267802,"f":40},{"t":1310721,"n":"QueryableMinByMaxByTSourceObsoleteMessage","d":192282,"h":519691235098,"f":40},{"t":1310721,"n":"QueryableMinByMaxByTSourceObsoleteDiagId","d":192282,"h":523986202394,"f":40},{"t":1310721,"n":"XsltSettingsEnableScriptMessage","d":192282,"h":528281169690,"f":40},{"t":1310721,"n":"XsltSettingsEnableScriptDiagId","d":192282,"h":532576136986,"f":40}],"h":192282}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.Obsoletions`; }
        });
        
        $asm.$cls("$srsf.System.Runtime.Serialization.SerializationEvents", ($self) => class SerializationEvents extends $.$spc.System.Object
        {
            /*List<MethodInfo>?*/ _onSerializingMethods = null;
            /*List<MethodInfo>?*/ _onSerializedMethods = null;
            /*List<MethodInfo>?*/ _onDeserializingMethods = null;
            /*List<MethodInfo>?*/ _onDeserializedMethods = null;
            $ctor$1(/*Type?*/ t)
            {
                super.$ctor();
                {
                    this._onSerializingMethods = this.GetMethodsWithAttribute($.$spc.System.Runtime.Serialization.OnSerializingAttribute.$type, t);
                    this._onSerializedMethods = this.GetMethodsWithAttribute($.$spc.System.Runtime.Serialization.OnSerializedAttribute.$type, t);
                    this._onDeserializingMethods = this.GetMethodsWithAttribute($.$spc.System.Runtime.Serialization.OnDeserializingAttribute.$type, t);
                    this._onDeserializedMethods = this.GetMethodsWithAttribute($.$spc.System.Runtime.Serialization.OnDeserializedAttribute.$type, t);
                }
                return this;
            }
            /*List<MethodInfo>? */ GetMethodsWithAttribute(/*Type*/ attribute, /*Type?*/ t)
            {
                /*List<MethodInfo>?*/ let mi = null;
                /*Type?*/ let baseType = t;
                while($.$spc.System.Type.op_Inequality$1(baseType, null) && $.$spc.System.Type.op_Inequality$1(baseType, $.$spc.System.Object.$type))
                {
                    /*MethodInfo[]*/ let mis = baseType.GetMethods$1(2/*BindingFlags.DeclaredOnly*/ | 4/*BindingFlags.Instance*/ | 32/*BindingFlags.NonPublic*/ | 16/*BindingFlags.Public*/);
                    let $i1 = 0;
                    let $arr1 = mis;
                    while ($i1 < $arr1.length)
                    {
                        let m = $arr1[$i1++];
                        if (m.IsDefined(attribute, false))
                        {
                            mi ??= new ($.$spc.System.Collections.Generic.List$$($.$spc.System.Reflection.MethodInfo))().$ctor$1();
                            mi.Add(m);
                        }
                    }
                    baseType = baseType.BaseType;
                }
                mi?.Reverse();
                return mi;
            }
            /*bool */ get HasOnSerializingEvents()
            {
                return this._onSerializingMethods !== null || this._onSerializedMethods !== null;
            }
            /*void */ InvokeOnSerializing(/*object*/ obj, /*StreamingContext*/ context)
            {
                return $.$srsf.System.Runtime.Serialization.SerializationEvents.InvokeOnDelegate(obj, context, this._onSerializingMethods);
            }
            /*void */ InvokeOnDeserializing(/*object*/ obj, /*StreamingContext*/ context)
            {
                return $.$srsf.System.Runtime.Serialization.SerializationEvents.InvokeOnDelegate(obj, context, this._onDeserializingMethods);
            }
            /*void */ InvokeOnDeserialized(/*object*/ obj, /*StreamingContext*/ context)
            {
                return $.$srsf.System.Runtime.Serialization.SerializationEvents.InvokeOnDelegate(obj, context, this._onDeserializedMethods);
            }
            /*SerializationEventHandler? */ AddOnSerialized(/*object*/ obj, /*SerializationEventHandler?*/ handler)
            {
                return $.$srsf.System.Runtime.Serialization.SerializationEvents.AddOnDelegate(obj, handler, this._onSerializedMethods);
            }
            /*SerializationEventHandler? */ AddOnDeserialized(/*object*/ obj, /*SerializationEventHandler?*/ handler)
            {
                return $.$srsf.System.Runtime.Serialization.SerializationEvents.AddOnDelegate(obj, handler, this._onDeserializedMethods);
            }
            static /*void */ InvokeOnDelegate(/*object*/ obj, /*StreamingContext*/ context, /*List<MethodInfo>?*/ methods)
            {
                $.$spc.System.Diagnostics.Debug.Assert$1(obj !== null, "object should have been initialized");
                $.$srsf.System.Runtime.Serialization.SerializationEvents.AddOnDelegate(obj, null, methods)?.Invoke(context);
            }
            static /*SerializationEventHandler? */ AddOnDelegate(/*object*/ obj, /*SerializationEventHandler?*/ handler, /*List<MethodInfo>?*/ methods)
            {
                if (methods !== null)
                {
                    var $en3 = methods.GetEnumerator();
                    while ($en3.MoveNext())
                    {
                        var m = $en3.Current;
                        {
                            /*SerializationEventHandler*/ let onDeserialized = m.CreateDelegate$3($.$srsf.System.Runtime.Serialization.SerializationEventHandler, obj);
                            handler = $.$cast($.$spc.System.Delegate.Combine(handler, onDeserialized), $.$srsf.System.Runtime.Serialization.SerializationEventHandler);
                        }
                    }
                }
                return handler;
            }
            static $h = 1765146;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":262145,"g":{"r":0,"d":0,"h":34361503514,"f":8},"n":"HasOnSerializingEvents","d":1765146,"h":30066536218,"f":8}],"m":[{"r":$.$spc.System.Collections.Generic.List$$($.$spc.System.Reflection.MethodInfo).$h,"p":[{"n":"attribute","p":142606337},{"n":"t","p":142606337}],"n":"GetMethodsWithAttribute","d":1765146,"h":25771568922,"f":2},{"r":65537,"p":[{"n":"obj","p":131073},{"n":"context","p":114098177}],"n":"InvokeOnSerializing","d":1765146,"h":38656470810,"f":8},{"r":65537,"p":[{"n":"obj","p":131073},{"n":"context","p":114098177}],"n":"InvokeOnDeserializing","d":1765146,"h":42951438106,"f":8},{"r":65537,"p":[{"n":"obj","p":131073},{"n":"context","p":114098177}],"n":"InvokeOnDeserialized","d":1765146,"h":47246405402,"f":8},{"r":1699610,"p":[{"n":"obj","p":131073},{"n":"handler","p":1699610}],"n":"AddOnSerialized","d":1765146,"h":51541372698,"f":8},{"r":1699610,"p":[{"n":"obj","p":131073},{"n":"handler","p":1699610}],"n":"AddOnDeserialized","d":1765146,"h":55836339994,"f":8},{"r":65537,"p":[{"n":"obj","p":131073},{"n":"context","p":114098177},{"n":"methods","p":$.$spc.System.Collections.Generic.List$$($.$spc.System.Reflection.MethodInfo).$h}],"n":"InvokeOnDelegate","d":1765146,"h":60131307290,"f":34},{"r":1699610,"p":[{"n":"obj","p":131073},{"n":"handler","p":1699610},{"n":"methods","p":$.$spc.System.Collections.Generic.List$$($.$spc.System.Reflection.MethodInfo).$h}],"n":"AddOnDelegate","d":1765146,"h":64426274586,"f":34}],"l":[{"t":$.$spc.System.Collections.Generic.List$$($.$spc.System.Reflection.MethodInfo).$h,"n":"_onSerializingMethods","d":1765146,"h":4296732442,"f":2},{"t":$.$spc.System.Collections.Generic.List$$($.$spc.System.Reflection.MethodInfo).$h,"n":"_onSerializedMethods","d":1765146,"h":8591699738,"f":2},{"t":$.$spc.System.Collections.Generic.List$$($.$spc.System.Reflection.MethodInfo).$h,"n":"_onDeserializingMethods","d":1765146,"h":12886667034,"f":2},{"t":$.$spc.System.Collections.Generic.List$$($.$spc.System.Reflection.MethodInfo).$h,"n":"_onDeserializedMethods","d":1765146,"h":17181634330,"f":2}],"c":[{"p":[{"n":"t","p":142606337}],"n":".ctor","o":"$ctor$1","d":1765146,"h":21476601626,"f":8}],"h":1765146}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.Runtime.Serialization.SerializationEvents`; }
        });
        
        $asm.$cls("$srsf.System.Runtime.Serialization.ObjectManager", ($self) => class ObjectManager extends $.$spc.System.Object
        {
            /*int*/ static DefaultInitialSize = 16;
            /*int*/ static MaxArraySize = 1048576;
            /*int*/ static ArrayMask = 1048575;
            /*int*/ static MaxReferenceDepth = 100;
            /*string*/ static ObjectManagerUnreferencedCodeMessage = null;
            /*FieldInfo*/ static s_nullableValueField = null;
            /*DeserializationEventHandler?*/ _onDeserializationHandler = null;
            /*SerializationEventHandler?*/ _onDeserializedHandler = null;
            /*ObjectHolder[]*/ _objects = null;
            /*object?*/ _topObject = null;
            /*ObjectHolderList?*/ _specialFixupObjects = null;
            /*long*/ _fixupCount = 0n;
            /*ISurrogateSelector?*/ _selector = null;
            /*StreamingContext*/ _context;
            $ctor$1(/*ISurrogateSelector?*/ selector, /*StreamingContext*/ context)
            {
                super.$ctor();
                {
                    this._objects = $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$srsf.System.Runtime.Serialization.ObjectHolder), null, [16/*DefaultInitialSize*/], null);
                    this._selector = selector;
                    this._context = context;
                }
                return this;
            }
            /*bool */ CanCallGetType(/*object?*/ obj)
            {
                return true;
            }
            /*object? */ get TopObject()
            {
                return this._topObject;
            }
            /*object? */ set TopObject(value)
            {
                this._topObject = value;
            }
            /*ObjectHolderList */ get SpecialFixupObjects()
            {
                return this._specialFixupObjects ??= new $.$srsf.System.Runtime.Serialization.ObjectHolderList().$ctor$1();
            }
            /*ObjectHolder? */ FindObjectHolder(/*long*/ objectID)
            {
                /*int*/ let index = $.$cast((objectID & BigInt(1048575/*ArrayMask*/)), $.$spc.System.Int32);
                if (index >= this._objects.length)
                {
                    return null;
                }
                /*ObjectHolder?*/ let temp = $.$spc.System.Array.$ReadT1.call(this._objects, index);
                while(temp !== null)
                {
                    if (temp._id === objectID)
                    {
                        return temp;
                    }
                    temp = temp._next;
                }
                return temp;
            }
            /*ObjectHolder */ FindOrCreateObjectHolder(/*long*/ objectID)
            {
                /*ObjectHolder?*/ let holder = this.FindObjectHolder(objectID);
                if (holder === null)
                {
                    holder = new $.$srsf.System.Runtime.Serialization.ObjectHolder().$ctor$1(objectID);
                    this.AddObjectHolder(holder);
                }
                return holder;
            }
            /*void */ AddObjectHolder(/*ObjectHolder*/ holder)
            {
                $.$spc.System.Diagnostics.Debug.Assert$1(holder !== null, "holder!=null");
                $.$spc.System.Diagnostics.Debug.Assert$1(holder._id >= 0n, "holder.m_id>=0");
                if (holder._id >= BigInt(this._objects.length) && this._objects.length !== 1048576/*MaxArraySize*/)
                {
                    /*int*/ let newSize = 1048576/*MaxArraySize*/;
                    if (holder._id < (BigInt($.trunc(1048576/*MaxArraySize*/ / 2))))
                    {
                        newSize = (((this._objects.length * 2) | 0));
                        while(BigInt(newSize) <= holder._id && newSize < 1048576/*MaxArraySize*/)
                        {
                            newSize *= 2;
                        }
                        if (newSize > 1048576/*MaxArraySize*/)
                        {
                            newSize = 1048576/*MaxArraySize*/;
                        }
                    }
                    /*ObjectHolder[]*/ let temp = $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$srsf.System.Runtime.Serialization.ObjectHolder), null, [newSize], null);
                    $.$spc.System.Array.Copy(this._objects, temp, this._objects.length);
                    this._objects = temp;
                }
                /*int*/ let index = $.$cast((holder._id & BigInt(1048575/*ArrayMask*/)), $.$spc.System.Int32);
                /*ObjectHolder*/ let tempHolder = $.$spc.System.Array.$ReadT1.call(this._objects, index);
                holder._next = tempHolder;
                $.$spc.System.Array.$WriteT1.call(this._objects, holder, index);
            }
            /*bool */ GetCompletionInfo(/*FixupHolder*/ fixup, /*out ObjectHolder?*/ holder, /*out object*/ member, /*bool*/ bThrowIfMissing)
            {
                member.$v = fixup._fixupInfo;
                holder.$v = this.FindObjectHolder(fixup._id);
                if (holder.$v === null || holder.$v.CanObjectValueChange || holder.$v.ObjectValue === null)
                {
                    if (bThrowIfMissing)
                    {
                        if (holder.$v === null)
                        {
                            throw new $.$spc.System.Runtime.Serialization.SerializationException().$ctor$10($.$srsf.System.SR.Format($.$srsf.System.SR.Serialization_NeverSeen, $.$box(fixup._id, $.$spc.System.Int64)));
                        }
                        if (holder.$v.IsIncompleteObjectReference)
                        {
                            throw new $.$spc.System.Runtime.Serialization.SerializationException().$ctor$10($.$srsf.System.SR.Format($.$srsf.System.SR.Serialization_IORIncomplete, $.$box(fixup._id, $.$spc.System.Int64)));
                        }
                        throw new $.$spc.System.Runtime.Serialization.SerializationException().$ctor$10($.$srsf.System.SR.Format($.$srsf.System.SR.Serialization_ObjectNotSupplied, $.$box(fixup._id, $.$spc.System.Int64)));
                    }
                    return false;
                }
                if (!holder.$v.CompletelyFixed)
                {
                    if (holder.$v.ObjectValue !== null && $.$is(holder.$v.ObjectValue, $.$spc.System.ValueType))
                    {
                        this.SpecialFixupObjects.Add(holder.$v);
                        return false;
                    }
                }
                return true;
            }
            /*void */ FixupSpecialObject(/*ObjectHolder*/ holder)
            {
                /*ISurrogateSelector?*/ let uselessSelector = null;
                $.$spc.System.Diagnostics.Debug.Assert$1(holder.RequiresSerInfoFixup, "[ObjectManager.FixupSpecialObject]holder.HasSurrogate||holder.HasISerializable");
                if (holder.HasSurrogate)
                {
                    /*ISerializationSurrogate?*/ let surrogate = holder.Surrogate;
                    $.$spc.System.Diagnostics.Debug.Assert$1(surrogate !== null, "surrogate!=null");
                    $.$spc.System.Diagnostics.Debug.Assert$1(holder.SerializationInfo !== null, "holder.SerializationInfo != null");
                    /*object?*/ let returnValue = surrogate.System$Runtime$Serialization$ISerializationSurrogate$SetObjectData(holder.ObjectValue, holder.SerializationInfo, this._context, uselessSelector);
                    if (returnValue !== null)
                    {
                        if (!holder.CanSurrogatedObjectValueChange && returnValue !== holder.ObjectValue)
                        {
                            throw new $.$spc.System.Runtime.Serialization.SerializationException().$ctor$10($.$srsf.System.SR.Format($.$srsf.System.SR.Serialization_NotCyclicallyReferenceableSurrogate, $.$spc.System.Object.GetType.call(surrogate).FullName));
                        }
                        holder.SetObjectValue(returnValue, this);
                    }
                    holder._surrogate = null;
                    holder.SetFlags();
                }
                else 
                {
                    $.$spc.System.Diagnostics.Debug.Assert$1($.$is(holder.ObjectValue, $.$spc.System.Runtime.Serialization.ISerializable), "holder.m_object is ISerializable");
                    this.CompleteISerializableObject(holder.ObjectValue, holder.SerializationInfo, this._context);
                }
                holder.SerializationInfo = null;
                holder.RequiresSerInfoFixup = false;
                if (holder.RequiresValueTypeFixup && holder.ValueTypeFixupPerformed)
                {
                    this.DoValueTypeFixup(null, holder, holder.ObjectValue);
                }
                this.DoNewlyRegisteredObjectFixups(holder);
            }
            /*bool */ ResolveObjectReference(/*ObjectHolder*/ holder)
            {
                /*object?*/ let tempObject;
                $.$spc.System.Diagnostics.Debug.Assert$1(holder.IsIncompleteObjectReference, "holder.IsIncompleteObjectReference");
                /*int*/ let depthCount = 0;
                try
                {
                    do
                    {
                        tempObject = holder.ObjectValue;
                        $.$spc.System.Diagnostics.Debug.Assert$1(holder.ObjectValue !== null, "holder.ObjectValue != null");
                        holder.SetObjectValue(($.$cast((holder.ObjectValue), $.$spc.System.Runtime.Serialization.IObjectReference)).System$Runtime$Serialization$IObjectReference$GetRealObject(this._context), this);
                        if (holder.ObjectValue === null)
                        {
                            holder.SetObjectValue(tempObject, this);
                            return false;
                        }
                        if (depthCount++ === 100/*MaxReferenceDepth*/)
                        {
                            throw new $.$spc.System.Runtime.Serialization.SerializationException().$ctor$10($.$srsf.System.SR.Serialization_TooManyReferences);
                        }
                    }
                    while(($.$is(holder.ObjectValue, $.$spc.System.Runtime.Serialization.IObjectReference)) && (tempObject !== holder.ObjectValue));
                }
                catch($e)
                {
                    return false;
                }
                holder.IsIncompleteObjectReference = false;
                this.DoNewlyRegisteredObjectFixups(holder);
                return true;
            }
            /*bool */ DoValueTypeFixup(/*FieldInfo?*/ memberToFix, /*ObjectHolder*/ holder, /*object?*/ value)
            {
                /*var*/ let fieldsTemp = $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$spc.System.Reflection.FieldInfo), null, [4], null);
                /*FieldInfo[]*/ let fields;
                /*int*/ let currentFieldIndex = 0;
                /*int[]?*/ let arrayIndex = null;
                /*ValueTypeFixupInfo*/ let currFixup;
                /*object?*/ let fixupObj = holder.ObjectValue;
                $.$spc.System.Diagnostics.Debug.Assert$1(holder !== null, "[TypedReferenceBuilder.ctor]holder!=null");
                $.$spc.System.Diagnostics.Debug.Assert$1(holder.RequiresValueTypeFixup, "[TypedReferenceBuilder.ctor]holder.RequiresValueTypeFixup");
                while(holder.RequiresValueTypeFixup)
                {
                    if ((((currentFieldIndex + 1) | 0)) >= fieldsTemp.length)
                    {
                        /*var*/ let temp = $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$spc.System.Reflection.FieldInfo), null, [((fieldsTemp.length * 2) | 0)], null);
                        $.$spc.System.Array.Copy(fieldsTemp, temp, fieldsTemp.length);
                        fieldsTemp = temp;
                    }
                    currFixup = holder.ValueFixup;
                    fixupObj = holder.ObjectValue;
                    if ($.$spc.System.Reflection.FieldInfo.op_Inequality$1(currFixup.ParentField, null))
                    {
                        /*FieldInfo*/ let parentField = currFixup.ParentField;
                        /*ObjectHolder?*/ let tempHolder = this.FindObjectHolder(currFixup.ContainerID);
                        $.$spc.System.Diagnostics.Debug.Assert$1(tempHolder !== null, "tempHolder != null");
                        if (tempHolder.ObjectValue === null)
                        {
                            break;
                        }
                        /*FieldInfo?*/ let nullableValueField = $.$srsf.System.Runtime.Serialization.ObjectManager.GetNullableValueField(parentField.FieldType);
                        if ($.$spc.System.Reflection.FieldInfo.op_Inequality$1(nullableValueField, null))
                        {
                            $.$spc.System.Array.$WriteT1.call(fieldsTemp, nullableValueField, currentFieldIndex);
                            currentFieldIndex++;
                        }
                        $.$spc.System.Array.$WriteT1.call(fieldsTemp, parentField, currentFieldIndex);
                        holder = tempHolder;
                        currentFieldIndex++;
                    }
                    else 
                    {
                        $.$spc.System.Diagnostics.Debug.Assert$1(currFixup.ParentIndex !== null, "[ObjectManager.DoValueTypeFixup]currFixup.ParentIndex!=null");
                        holder = this.FindObjectHolder(currFixup.ContainerID);
                        arrayIndex = currFixup.ParentIndex;
                        break;
                    }
                }
                if (!($.$is(holder.ObjectValue, $.$spc.System.Array)) && holder.ObjectValue !== null)
                {
                    fixupObj = holder.ObjectValue;
                    $.$spc.System.Diagnostics.Debug.Assert$1(fixupObj !== null, "[ObjectManager.DoValueTypeFixup]FixupObj!=null");
                }
                if (currentFieldIndex !== 0)
                {
                    fields = $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$spc.System.Reflection.FieldInfo), null, [currentFieldIndex], null);
                    for(/*int*/ let i = 0; i < currentFieldIndex; i++)
                    {
                        /*FieldInfo?*/ let fieldInfo = $.$spc.System.Array.$ReadT1.call(fieldsTemp, (((((currentFieldIndex - 1) | 0) - i) | 0)));
                        /*SerializationFieldInfo?*/ let serInfo = $.$as(fieldInfo, $.$srsf.System.Runtime.Serialization.SerializationFieldInfo);
                        $.$spc.System.Array.$WriteT1.call(fields, serInfo === null ? fieldInfo : serInfo.FieldInfo, i);
                    }
                    $.$spc.System.Diagnostics.Debug.Assert$1(fixupObj !== null, "[ObjectManager.DoValueTypeFixup]fixupObj!=null");
                    /*TypedReference*/ let typedRef = $.$spc.System.TypedReference.MakeTypedReference(fixupObj, fields);
                    if ($.$spc.System.Reflection.FieldInfo.op_Inequality$1(memberToFix, null))
                    {
                        memberToFix.SetValueDirect(typedRef, value);
                    }
                    else 
                    {
                        $.$spc.System.TypedReference.SetTypedReference(typedRef, value);
                    }
                }
                else if ($.$spc.System.Reflection.FieldInfo.op_Inequality$1(memberToFix, null))
                {
                    $.$srsf.System.Runtime.Serialization.FormatterServices.SerializationSetValue(memberToFix, fixupObj, value);
                }
                if (arrayIndex !== null && holder.ObjectValue !== null)
                {
                    ($.$cast((holder.ObjectValue), $.$spc.System.Array)).SetValue$3(fixupObj, arrayIndex);
                }
                return true;
            }
            static /*FieldInfo? */ GetNullableValueField(/*Type*/ type)
            {
                if ($.$spc.System.Type.op_Inequality$1($.$spc.System.Nullable.GetUnderlyingType(type), null))
                {
                    return $.$cast(type.GetMemberWithSameMetadataDefinitionAs($.$srsf.System.Runtime.Serialization.ObjectManager.s_nullableValueField), $.$spc.System.Reflection.FieldInfo);
                }
                return null;
            }
            /*void */ CompleteObject(/*ObjectHolder*/ holder, /*bool*/ bObjectFullyComplete)
            {
                /*FixupHolderList?*/ let fixups = holder._missingElements;
                /*FixupHolder?*/ let currentFixup;
                /*SerializationInfo?*/ let si;
                /*object?*/ let fixupInfo;
                /*ObjectHolder?*/ let tempObjectHolder;
                /*int*/ let fixupsPerformed = 0;
                $.$spc.System.Diagnostics.Debug.Assert$1(holder !== null, "[ObjectManager.CompleteObject]holder.m_object!=null");
                if (holder.ObjectValue === null)
                {
                    throw new $.$spc.System.Runtime.Serialization.SerializationException().$ctor$10($.$srsf.System.SR.Format($.$srsf.System.SR.Serialization_MissingObject, $.$box(holder._id, $.$spc.System.Int64)));
                }
                if (fixups === null)
                {
                    return;
                }
                if (holder.HasSurrogate || holder.HasISerializable)
                {
                    si = holder._serInfo;
                    if (si === null)
                    {
                        throw new $.$spc.System.Runtime.Serialization.SerializationException().$ctor$10($.$srsf.System.SR.Serialization_InvalidFixupDiscovered);
                    }
                    if (fixups !== null)
                    {
                        for(/*int*/ let i = 0; i < fixups._count; i++)
                        {
                            if ($.$spc.System.Array.$ReadT1.call(fixups._values, i) === null)
                            {
                                continue;
                            }
                            $.$spc.System.Diagnostics.Debug.Assert$1($.$spc.System.Array.$ReadT1.call(fixups._values, i)._fixupType === 4/*FixupHolder.DelayedFixup*/, "fixups.m_values[i].m_fixupType==FixupHolder.DelayedFixup");
                            if (this.GetCompletionInfo($.$spc.System.Array.$ReadT1.call(fixups._values, i), $.$ref(() => tempObjectHolder, ($v) => tempObjectHolder = $v, $.$srsf.System.Runtime.Serialization.ObjectHolder), $.$ref(() => fixupInfo, ($v) => fixupInfo = $v, $.$spc.System.Object), bObjectFullyComplete))
                            {
                                /*object?*/ let holderValue = tempObjectHolder.ObjectValue;
                                $.$spc.System.Diagnostics.Debug.Assert$1(holderValue !== null, "holderValue != null");
                                if (this.CanCallGetType(holderValue))
                                {
                                    $.$srsf.System.Runtime.Serialization.SerializationInfoExtensions.UpdateValue(si, $.$cast(fixupInfo, $.$spc.System.String), holderValue, $.$spc.System.Object.GetType.call(holderValue));
                                }
                                else 
                                {
                                    $.$srsf.System.Runtime.Serialization.SerializationInfoExtensions.UpdateValue(si, $.$cast(fixupInfo, $.$spc.System.String), holderValue, $.$spc.System.MarshalByRefObject.$type);
                                }
                                fixupsPerformed++;
                                $.$spc.System.Array.$WriteT1.call(fixups._values, null, i);
                                if (!bObjectFullyComplete)
                                {
                                    holder.DecrementFixupsRemaining(this);
                                    tempObjectHolder.RemoveDependency(holder._id);
                                }
                            }
                        }
                    }
                }
                else 
                {
                    for(/*int*/ let i = 0; i < fixups._count; i++)
                    {
                        currentFixup = $.$spc.System.Array.$ReadT1.call(fixups._values, i);
                        if (currentFixup === null)
                        {
                            continue;
                        }
                        if (this.GetCompletionInfo(currentFixup, $.$ref(() => tempObjectHolder, ($v) => tempObjectHolder = $v, $.$srsf.System.Runtime.Serialization.ObjectHolder), $.$ref(() => fixupInfo, ($v) => fixupInfo = $v, $.$spc.System.Object), bObjectFullyComplete))
                        {
                            if (tempObjectHolder.TypeLoadExceptionReachable)
                            {
                                holder.TypeLoadException = tempObjectHolder.TypeLoadException;
                                if (holder.Reachable)
                                {
                                    throw new $.$spc.System.Runtime.Serialization.SerializationException().$ctor$10($.$srsf.System.SR.Format($.$srsf.System.SR.Serialization_TypeLoadFailure, holder.TypeLoadException.TypeName));
                                }
                            }
                            if (holder.Reachable)
                            {
                                tempObjectHolder.Reachable = true;
                            }
                            let $switch3 = currentFixup._fixupType;
                            switch($switch3)
                            {
                                case 1/*FixupHolder.ArrayFixup*/:
                                $.$spc.System.Diagnostics.Debug.Assert$1($.$is(holder.ObjectValue, $.$spc.System.Array), "holder.ObjectValue is Array");
                                if (holder.RequiresValueTypeFixup)
                                {
                                    throw new $.$spc.System.Runtime.Serialization.SerializationException().$ctor$10($.$srsf.System.SR.Serialization_ValueTypeFixup);
                                }
                                else 
                                {
                                    ($.$cast((holder.ObjectValue), $.$spc.System.Array)).SetValue$3(tempObjectHolder.ObjectValue, ($.$cast(fixupInfo, $.$typeArray($.$spc.System.Int32))));
                                }
                                break;
                                case 2/*FixupHolder.MemberFixup*/:
                                $.$spc.System.Diagnostics.Debug.Assert$1($.$is(fixupInfo, $.$spc.System.Reflection.MemberInfo), "fixupInfo is MemberInfo");
                                /*MemberInfo*/ let tempMember = $.$cast(fixupInfo, $.$spc.System.Reflection.MemberInfo);
                                if ($.$is(tempMember, $.$spc.System.Reflection.FieldInfo))
                                {
                                    if (holder.RequiresValueTypeFixup && holder.ValueTypeFixupPerformed)
                                    {
                                        if (!this.DoValueTypeFixup($.$cast(tempMember, $.$spc.System.Reflection.FieldInfo), holder, tempObjectHolder.ObjectValue))
                                        {
                                            throw new $.$spc.System.Runtime.Serialization.SerializationException().$ctor$10($.$srsf.System.SR.Serialization_PartialValueTypeFixup);
                                        }
                                    }
                                    else 
                                    {
                                        $.$srsf.System.Runtime.Serialization.FormatterServices.SerializationSetValue(tempMember, holder.ObjectValue, tempObjectHolder.ObjectValue);
                                    }
                                    if (tempObjectHolder.RequiresValueTypeFixup)
                                    {
                                        tempObjectHolder.ValueTypeFixupPerformed = true;
                                    }
                                }
                                else 
                                {
                                    throw new $.$spc.System.Runtime.Serialization.SerializationException().$ctor$10($.$srsf.System.SR.Serialization_UnableToFixup);
                                }
                                break;
                                default:
                                throw new $.$spc.System.Runtime.Serialization.SerializationException().$ctor$10($.$srsf.System.SR.Serialization_UnableToFixup);
                            }
                            fixupsPerformed++;
                            $.$spc.System.Array.$WriteT1.call(fixups._values, null, i);
                            if (!bObjectFullyComplete)
                            {
                                holder.DecrementFixupsRemaining(this);
                                tempObjectHolder.RemoveDependency(holder._id);
                            }
                        }
                    }
                }
                this._fixupCount -= BigInt(fixupsPerformed);
                if (fixups._count === fixupsPerformed)
                {
                    holder._missingElements = null;
                }
            }
            /*void */ DoNewlyRegisteredObjectFixups(/*ObjectHolder*/ holder)
            {
                if (holder.CanObjectValueChange)
                {
                    return;
                }
                /*LongList?*/ let dependencies = holder.DependentObjects;
                if (dependencies === null)
                {
                    return;
                }
                dependencies.StartEnumeration();
                while(dependencies.MoveNext())
                {
                    /*ObjectHolder?*/ let temp = this.FindObjectHolder(dependencies.Current);
                    $.$spc.System.Diagnostics.Debug.Assert$1(temp !== null, "temp != null");
                    $.$spc.System.Diagnostics.Debug.Assert$1(temp.DirectlyDependentObjects > 0, "temp.m_missingElementsRemaining>0");
                    temp.DecrementFixupsRemaining(this);
                    if (((temp.DirectlyDependentObjects)) === 0)
                    {
                        if (temp.ObjectValue !== null)
                        {
                            this.CompleteObject(temp, true);
                        }
                        else 
                        {
                            temp.MarkForCompletionWhenAvailable();
                        }
                    }
                }
            }
            /*object? */ GetObject(/*long*/ objectID)
            {
                if (objectID <= 0n)
                {
                    throw new $.$spc.System.ArgumentOutOfRangeException().$ctor$17("objectID", $.$srsf.System.SR.ArgumentOutOfRange_ObjectID);
                }
                /*ObjectHolder?*/ let holder = this.FindObjectHolder(objectID);
                if (holder === null || holder.CanObjectValueChange)
                {
                    return null;
                }
                return holder.ObjectValue;
            }
            /*void */ RegisterObject(/*object*/ obj, /*long*/ objectID)
            {
                this.RegisterObject$2(obj, objectID, null, 0n, null);
            }
            /*void */ RegisterObject$1(/*object*/ obj, /*long*/ objectID, /*SerializationInfo*/ info)
            {
                this.RegisterObject$2(obj, objectID, info, 0n, null);
            }
            /*void */ RegisterObject$2(/*object*/ obj, /*long*/ objectID, /*SerializationInfo?*/ info, /*long*/ idOfContainingObj, /*MemberInfo?*/ member)
            {
                this.RegisterObject$3(obj, objectID, info, idOfContainingObj, member, null);
            }
            /*void */ RegisterString(/*string?*/ obj, /*long*/ objectID, /*SerializationInfo?*/ info, /*long*/ idOfContainingObj, /*MemberInfo?*/ member)
            {
                /*ObjectHolder*/ let temp;
                $.$spc.System.Diagnostics.Debug.Assert$1($.$spc.System.Reflection.MemberInfo.op_Equality(member, null) || $.$is(member, $.$spc.System.Reflection.FieldInfo), "RegisterString - member is FieldInfo");
                temp = new $.$srsf.System.Runtime.Serialization.ObjectHolder().$ctor$3(obj, objectID, info, null, idOfContainingObj, $.$cast(member, $.$spc.System.Reflection.FieldInfo), null);
                this.AddObjectHolder(temp);
                return;
            }
            /*void */ RegisterObject$3(/*object*/ obj, /*long*/ objectID, /*SerializationInfo?*/ info, /*long*/ idOfContainingObj, /*MemberInfo?*/ member, /*int[]?*/ arrayIndex)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(obj, "obj");
                if (objectID <= 0n)
                {
                    throw new $.$spc.System.ArgumentOutOfRangeException().$ctor$17("objectID", $.$srsf.System.SR.ArgumentOutOfRange_ObjectID);
                }
                if ($.$spc.System.Reflection.MemberInfo.op_Inequality(member, null) && !($.$is(member, $.$spc.System.Reflection.FieldInfo)))
                {
                    throw new $.$spc.System.Runtime.Serialization.SerializationException().$ctor$10($.$srsf.System.SR.Serialization_UnknownMemberInfo);
                }
                /*ObjectHolder?*/ let temp;
                /*ISerializationSurrogate?*/ let surrogate = null;
                /*ISurrogateSelector*/ let useless;
                if (this._selector !== null)
                {
                    /*Type*/ let selectorType = this.CanCallGetType(obj) ? $.$spc.System.Object.GetType.call(obj) : $.$spc.System.MarshalByRefObject.$type;
                    surrogate = this._selector.System$Runtime$Serialization$ISurrogateSelector$GetSurrogate(selectorType, this._context, $.$ref(() => useless, ($v) => useless = $v, $.$srsf.System.Runtime.Serialization.ISurrogateSelector));
                }
                if ($.$is(obj, $.$spc.System.Runtime.Serialization.IDeserializationCallback))
                {
                    /*DeserializationEventHandler*/ let d = new $.$srsf.System.Runtime.Serialization.DeserializationEventHandler().$ctor(($.$cast(obj, $.$spc.System.Runtime.Serialization.IDeserializationCallback)), ($.$cast(obj, $.$spc.System.Runtime.Serialization.IDeserializationCallback)).System$Runtime$Serialization$IDeserializationCallback$OnDeserialization);
                    this.AddOnDeserialization(d);
                }
                if (arrayIndex !== null)
                {
                    arrayIndex = $.$cast(arrayIndex.Clone(), $.$typeArray($.$spc.System.Int32));
                }
                temp = this.FindObjectHolder(objectID);
                if (temp === null)
                {
                    temp = new $.$srsf.System.Runtime.Serialization.ObjectHolder().$ctor$2(obj, objectID, info, surrogate, idOfContainingObj, $.$cast(member, $.$spc.System.Reflection.FieldInfo), arrayIndex);
                    this.AddObjectHolder(temp);
                    if (temp.RequiresDelayedFixup)
                    {
                        this.SpecialFixupObjects.Add(temp);
                    }
                    this.AddOnDeserialized(obj);
                    return;
                }
                if (temp.ObjectValue !== null)
                {
                    throw new $.$spc.System.Runtime.Serialization.SerializationException().$ctor$10($.$srsf.System.SR.Serialization_RegisterTwice);
                }
                temp.UpdateData(obj, info, surrogate, idOfContainingObj, $.$cast(member, $.$spc.System.Reflection.FieldInfo), arrayIndex, this);
                if (temp.DirectlyDependentObjects > 0)
                {
                    this.CompleteObject(temp, false);
                }
                if (temp.RequiresDelayedFixup)
                {
                    this.SpecialFixupObjects.Add(temp);
                }
                if (temp.CompletelyFixed)
                {
                    this.DoNewlyRegisteredObjectFixups(temp);
                    temp.DependentObjects = null;
                }
                if (temp.TotalDependentObjects > 0)
                {
                    this.AddOnDeserialized(obj);
                }
                else 
                {
                    this.RaiseOnDeserializedEvent(obj);
                }
            }
            /*void */ CompleteISerializableObject(/*object*/ obj, /*SerializationInfo?*/ info, /*StreamingContext*/ context)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(obj, "obj");
                if (!($.$is(obj, $.$spc.System.Runtime.Serialization.ISerializable)))
                {
                    throw new $.$spc.System.ArgumentException().$ctor$10($.$srsf.System.SR.Serialization_NotISer);
                }
                /*ConstructorInfo*/ let constInfo;
                /*Type*/ let t = $.$spc.System.Object.GetType.call(obj);
                try
                {
                    constInfo = $.$srsf.System.Runtime.Serialization.ObjectManager.GetDeserializationConstructor(t);
                }
                catch(e)
                {
                    throw new $.$spc.System.Runtime.Serialization.SerializationException().$ctor$11($.$srsf.System.SR.Format($.$srsf.System.SR.Serialization_ConstructorNotFound, t), e);
                }
                constInfo.Invoke(obj, $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$spc.System.Object), [info, context], [-1], null));
            }
            static /*ConstructorInfo */ GetDeserializationConstructor(/*Type*/ t)
            {
                let $i1 = 0;
                let $arr1 = t.GetConstructors$1(16/*BindingFlags.Public*/ | 32/*BindingFlags.NonPublic*/ | 4/*BindingFlags.Instance*/ | 2/*BindingFlags.DeclaredOnly*/);
                while ($i1 < $arr1.length)
                {
                    let ci = $arr1[$i1++];
                    /*ParameterInfo[]*/ let parameters = ci.GetParameters();
                    if (parameters.length === 2 && $.$spc.System.Type.op_Equality$1($.$spc.System.Array.$ReadT1.call(parameters, 0).ParameterType, $.$spc.System.Runtime.Serialization.SerializationInfo.$type) && $.$spc.System.Type.op_Equality$1($.$spc.System.Array.$ReadT1.call(parameters, 1).ParameterType, $.$spc.System.Runtime.Serialization.StreamingContext.$type))
                    {
                        return ci;
                    }
                }
                throw new $.$spc.System.Runtime.Serialization.SerializationException().$ctor$10($.$srsf.System.SR.Format($.$srsf.System.SR.Serialization_ConstructorNotFound, t.FullName));
            }
            /*void */ DoFixups()
            {
                /*ObjectHolder?*/ let temp;
                /*int*/ let fixupCount = -1;
                while(fixupCount !== 0)
                {
                    fixupCount = 0;
                    /*ObjectHolderListEnumerator*/ let fixupObjectsEnum = this.SpecialFixupObjects.GetFixupEnumerator();
                    while(fixupObjectsEnum.MoveNext())
                    {
                        temp = fixupObjectsEnum.Current;
                        if (temp.ObjectValue === null)
                        {
                            throw new $.$spc.System.Runtime.Serialization.SerializationException().$ctor$10($.$srsf.System.SR.Format($.$srsf.System.SR.Serialization_ObjectNotSupplied, $.$box(temp._id, $.$spc.System.Int64)));
                        }
                        if (temp.TotalDependentObjects === 0)
                        {
                            if (temp.RequiresSerInfoFixup)
                            {
                                this.FixupSpecialObject(temp);
                                fixupCount++;
                            }
                            else if (!temp.IsIncompleteObjectReference)
                            {
                                this.CompleteObject(temp, true);
                            }
                            if (temp.IsIncompleteObjectReference && this.ResolveObjectReference(temp))
                            {
                                fixupCount++;
                            }
                        }
                    }
                }
                $.$spc.System.Diagnostics.Debug.Assert$1(this._fixupCount >= 0n, "[ObjectManager.DoFixups]m_fixupCount>=0");
                if (this._fixupCount === 0n)
                {
                    if ($.$is(this.TopObject, $.$srsf.System.Runtime.Serialization.TypeLoadExceptionHolder))
                    {
                        throw new $.$spc.System.Runtime.Serialization.SerializationException().$ctor$10($.$srsf.System.SR.Format($.$srsf.System.SR.Serialization_TypeLoadFailure, ($.$cast(this.TopObject, $.$srsf.System.Runtime.Serialization.TypeLoadExceptionHolder)).TypeName));
                    }
                    return;
                }
                for(/*int*/ let i = 0; i < this._objects.length; i++)
                {
                    temp = $.$spc.System.Array.$ReadT1.call(this._objects, i);
                    while(temp !== null)
                    {
                        if (temp.TotalDependentObjects > 0)
                        {
                            this.CompleteObject(temp, true);
                        }
                        temp = temp._next;
                    }
                    if (this._fixupCount === 0n)
                    {
                        return;
                    }
                }
                throw new $.$spc.System.Runtime.Serialization.SerializationException().$ctor$10($.$srsf.System.SR.Serialization_IncorrectNumberOfFixups);
            }
            /*void */ RegisterFixup(/*FixupHolder*/ fixup, /*long*/ objectToBeFixed, /*long*/ objectRequired)
            {
                /*ObjectHolder*/ let ohToBeFixed = this.FindOrCreateObjectHolder(objectToBeFixed);
                /*ObjectHolder*/ let ohRequired;
                if (ohToBeFixed.RequiresSerInfoFixup && fixup._fixupType === 2/*FixupHolder.MemberFixup*/)
                {
                    throw new $.$spc.System.Runtime.Serialization.SerializationException().$ctor$10($.$srsf.System.SR.Serialization_InvalidFixupType);
                }
                ohToBeFixed.AddFixup(fixup, this);
                ohRequired = this.FindOrCreateObjectHolder(objectRequired);
                ohRequired.AddDependency(objectToBeFixed);
                this._fixupCount++;
            }
            /*void */ RecordFixup(/*long*/ objectToBeFixed, /*MemberInfo*/ member, /*long*/ objectRequired)
            {
                if (objectToBeFixed <= 0n || objectRequired <= 0n)
                {
                    throw new $.$spc.System.ArgumentOutOfRangeException().$ctor$17(objectToBeFixed <= 0n ? "objectToBeFixed" : "objectRequired", $.$srsf.System.SR.Serialization_IdTooSmall);
                }
                $.$spc.System.ArgumentNullException.ThrowIfNull(member, "member");
                if (!($.$is(member, $.$spc.System.Reflection.FieldInfo)))
                {
                    throw new $.$spc.System.Runtime.Serialization.SerializationException().$ctor$10($.$srsf.System.SR.Format($.$srsf.System.SR.Serialization_InvalidType, $.$spc.System.Object.GetType.call(member)));
                }
                /*FixupHolder*/ let fixup = new $.$srsf.System.Runtime.Serialization.FixupHolder().$ctor$1(objectRequired, member, 2/*FixupHolder.MemberFixup*/);
                this.RegisterFixup(fixup, objectToBeFixed, objectRequired);
            }
            /*void */ RecordDelayedFixup(/*long*/ objectToBeFixed, /*string*/ memberName, /*long*/ objectRequired)
            {
                if (objectToBeFixed <= 0n || objectRequired <= 0n)
                {
                    throw new $.$spc.System.ArgumentOutOfRangeException().$ctor$17(objectToBeFixed <= 0n ? "objectToBeFixed" : "objectRequired", $.$srsf.System.SR.Serialization_IdTooSmall);
                }
                $.$spc.System.ArgumentNullException.ThrowIfNull(memberName, "memberName");
                /*FixupHolder*/ let fixup = new $.$srsf.System.Runtime.Serialization.FixupHolder().$ctor$1(objectRequired, memberName, 4/*FixupHolder.DelayedFixup*/);
                this.RegisterFixup(fixup, objectToBeFixed, objectRequired);
            }
            /*void */ RecordArrayElementFixup(/*long*/ arrayToBeFixed, /*int*/ index, /*long*/ objectRequired)
            {
                /*int[]*/ let indexArray = $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$spc.System.Int32), null, [1], null);
                $.$spc.System.Array.$WriteT1.call(indexArray, index, 0);
                this.RecordArrayElementFixup$1(arrayToBeFixed, indexArray, objectRequired);
            }
            /*void */ RecordArrayElementFixup$1(/*long*/ arrayToBeFixed, /*int[]*/ indices, /*long*/ objectRequired)
            {
                if (arrayToBeFixed <= 0n || objectRequired <= 0n)
                {
                    throw new $.$spc.System.ArgumentOutOfRangeException().$ctor$17(arrayToBeFixed <= 0n ? "arrayToBeFixed" : "objectRequired", $.$srsf.System.SR.Serialization_IdTooSmall);
                }
                $.$spc.System.ArgumentNullException.ThrowIfNull(indices, "indices");
                /*FixupHolder*/ let fixup = new $.$srsf.System.Runtime.Serialization.FixupHolder().$ctor$1(objectRequired, indices, 1/*FixupHolder.ArrayFixup*/);
                this.RegisterFixup(fixup, arrayToBeFixed, objectRequired);
            }
            /*void */ RaiseDeserializationEvent()
            {
                this._onDeserializedHandler?.Invoke(this._context);
                this._onDeserializationHandler?.Invoke(null);
            }
            /*void */ AddOnDeserialization(/*DeserializationEventHandler*/ handler)
            {
                this._onDeserializationHandler = $.$cast($.$spc.System.Delegate.Combine(this._onDeserializationHandler, handler), $.$srsf.System.Runtime.Serialization.DeserializationEventHandler);
            }
            /*void */ AddOnDeserialized(/*object*/ obj)
            {
                /*SerializationEvents*/ let cache = $.$srsf.System.Runtime.Serialization.SerializationEventsCache.GetSerializationEventsForType($.$spc.System.Object.GetType.call(obj));
                this._onDeserializedHandler = cache.AddOnDeserialized(obj, this._onDeserializedHandler);
            }
            /*void */ RaiseOnDeserializedEvent(/*object*/ obj)
            {
                /*SerializationEvents*/ let cache = $.$srsf.System.Runtime.Serialization.SerializationEventsCache.GetSerializationEventsForType($.$spc.System.Object.GetType.call(obj));
                cache.InvokeOnDeserialized(obj, this._context);
            }
            /*void */ RaiseOnDeserializingEvent(/*object*/ obj)
            {
                /*SerializationEvents*/ let cache = $.$srsf.System.Runtime.Serialization.SerializationEventsCache.GetSerializationEventsForType($.$spc.System.Object.GetType.call(obj));
                cache.InvokeOnDeserializing(obj, this._context);
            }
            //default member initializer
            constructor()
            {
                super();
                this._context = $.$default($.$spc.System.Runtime.Serialization.StreamingContext);
            }
            //Static Initializer
            static $sinit()
            {
                {
                    this.ObjectManagerUnreferencedCodeMessage = "ObjectManager is not trim compatible because the type of objects being managed cannot be statically discovered.";
                }
                {
                    this.s_nullableValueField = $.$spc.System.Nullable$$().$type.GetField$2("value", 32/*BindingFlags.NonPublic*/ | 4/*BindingFlags.Instance*/);
                }
            }
            static $h = 1568538;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":131073,"g":{"r":0,"d":0,"h":77310979866,"f":8},"s":{"r":0,"d":0,"h":81605947162,"f":8},"n":"TopObject","d":1568538,"h":73016012570,"f":8},{"p":1371930,"g":{"r":0,"d":0,"h":90195881754,"f":8},"n":"SpecialFixupObjects","d":1568538,"h":85900914458,"f":8}],"m":[{"r":262145,"p":[{"n":"obj","p":131073}],"n":"CanCallGetType","d":1568538,"h":68721045274,"f":2},{"r":1306394,"p":[{"n":"objectID","p":917505}],"n":"FindObjectHolder","d":1568538,"h":94490849050,"f":8},{"r":1306394,"p":[{"n":"objectID","p":917505}],"n":"FindOrCreateObjectHolder","d":1568538,"h":98785816346,"f":8},{"r":65537,"p":[{"n":"holder","p":1306394}],"n":"AddObjectHolder","d":1568538,"h":103080783642,"f":2},{"r":262145,"p":[{"n":"fixup","p":323354},{"n":"holder","p":1306394,"f":2},{"n":"member","p":131073,"f":2},{"n":"bThrowIfMissing","p":262145}],"n":"GetCompletionInfo","d":1568538,"h":107375750938,"f":2},{"r":65537,"p":[{"n":"holder","p":1306394}],"n":"FixupSpecialObject","d":1568538,"h":111670718234,"f":2},{"r":262145,"p":[{"n":"holder","p":1306394}],"n":"ResolveObjectReference","d":1568538,"h":115965685530,"f":2},{"r":262145,"p":[{"n":"memberToFix","p":76677121},{"n":"holder","p":1306394},{"n":"value","p":131073}],"n":"DoValueTypeFixup","d":1568538,"h":120260652826,"f":2},{"r":76677121,"p":[{"n":"type","p":142606337}],"n":"GetNullableValueField","d":1568538,"h":124555620122,"f":34},{"r":65537,"p":[{"n":"holder","p":1306394},{"n":"bObjectFullyComplete","p":262145}],"n":"CompleteObject","d":1568538,"h":128850587418,"f":8},{"r":65537,"p":[{"n":"holder","p":1306394}],"n":"DoNewlyRegisteredObjectFixups","d":1568538,"h":133145554714,"f":2},{"r":131073,"p":[{"n":"objectID","p":917505}],"n":"GetObject","d":1568538,"h":137440522010,"f":129},{"r":65537,"p":[{"n":"obj","p":131073},{"n":"objectID","p":917505}],"n":"RegisterObject","d":1568538,"h":141735489306,"f":129},{"r":65537,"p":[{"n":"obj","p":131073},{"n":"objectID","p":917505},{"n":"info","p":113967105}],"n":"RegisterObject","o":"@$1","d":1568538,"h":146030456602,"f":1},{"r":65537,"p":[{"n":"obj","p":131073},{"n":"objectID","p":917505},{"n":"info","p":113967105},{"n":"idOfContainingObj","p":917505},{"n":"member","p":78249985}],"n":"RegisterObject","o":"@$2","d":1568538,"h":150325423898,"f":1},{"r":65537,"p":[{"n":"obj","p":1310721},{"n":"objectID","p":917505},{"n":"info","p":113967105},{"n":"idOfContainingObj","p":917505},{"n":"member","p":78249985}],"n":"RegisterString","d":1568538,"h":154620391194,"f":8},{"r":65537,"p":[{"n":"obj","p":131073},{"n":"objectID","p":917505},{"n":"info","p":113967105},{"n":"idOfContainingObj","p":917505},{"n":"member","p":78249985},{"n":"arrayIndex","p":0}],"n":"RegisterObject","o":"@$3","d":1568538,"h":158915358490,"f":1},{"r":65537,"p":[{"n":"obj","p":131073},{"n":"info","p":113967105},{"n":"context","p":114098177}],"n":"CompleteISerializableObject","d":1568538,"h":163210325786,"f":8},{"r":75628545,"p":[{"n":"t","p":142606337}],"n":"GetDeserializationConstructor","d":1568538,"h":167505293082,"f":40},{"r":65537,"n":"DoFixups","d":1568538,"h":171800260378,"f":129},{"r":65537,"p":[{"n":"fixup","p":323354},{"n":"objectToBeFixed","p":917505},{"n":"objectRequired","p":917505}],"n":"RegisterFixup","d":1568538,"h":176095227674,"f":2},{"r":65537,"p":[{"n":"objectToBeFixed","p":917505},{"n":"member","p":78249985},{"n":"objectRequired","p":917505}],"n":"RecordFixup","d":1568538,"h":180390194970,"f":129},{"r":65537,"p":[{"n":"objectToBeFixed","p":917505},{"n":"memberName","p":1310721},{"n":"objectRequired","p":917505}],"n":"RecordDelayedFixup","d":1568538,"h":184685162266,"f":129},{"r":65537,"p":[{"n":"arrayToBeFixed","p":917505},{"n":"index","p":655361},{"n":"objectRequired","p":917505}],"n":"RecordArrayElementFixup","d":1568538,"h":188980129562,"f":129},{"r":65537,"p":[{"n":"arrayToBeFixed","p":917505},{"n":"indices","p":0},{"n":"objectRequired","p":917505}],"n":"RecordArrayElementFixup","o":"@$1","d":1568538,"h":193275096858,"f":129},{"r":65537,"n":"RaiseDeserializationEvent","d":1568538,"h":197570064154,"f":129},{"r":65537,"p":[{"n":"handler","p":257818}],"n":"AddOnDeserialization","d":1568538,"h":201865031450,"f":136},{"r":65537,"p":[{"n":"obj","p":131073}],"n":"AddOnDeserialized","d":1568538,"h":206159998746,"f":136},{"r":65537,"p":[{"n":"obj","p":131073}],"n":"RaiseOnDeserializedEvent","d":1568538,"h":210454966042,"f":136},{"r":65537,"p":[{"n":"obj","p":131073}],"n":"RaiseOnDeserializingEvent","d":1568538,"h":214749933338,"f":1}],"l":[{"t":655361,"n":"DefaultInitialSize","d":1568538,"h":4296535834,"f":34},{"t":655361,"n":"MaxArraySize","d":1568538,"h":8591503130,"f":34},{"t":655361,"n":"ArrayMask","d":1568538,"h":12886470426,"f":34},{"t":655361,"n":"MaxReferenceDepth","d":1568538,"h":17181437722,"f":34},{"t":1310721,"n":"ObjectManagerUnreferencedCodeMessage","d":1568538,"h":21476405018,"f":34},{"t":76677121,"n":"s_nullableValueField","d":1568538,"h":25771372314,"f":34},{"t":257818,"n":"_onDeserializationHandler","d":1568538,"h":30066339610,"f":2},{"t":1699610,"n":"_onDeserializedHandler","d":1568538,"h":34361306906,"f":2},{"t":0,"n":"_objects","d":1568538,"h":38656274202,"f":8},{"t":131073,"n":"_topObject","d":1568538,"h":42951241498,"f":8},{"t":1371930,"n":"_specialFixupObjects","d":1568538,"h":47246208794,"f":8},{"t":917505,"n":"_fixupCount","d":1568538,"h":51541176090,"f":8},{"t":1109786,"n":"_selector","d":1568538,"h":55836143386,"f":8},{"t":114098177,"n":"_context","d":1568538,"h":60131110682,"f":8}],"c":[{"p":[{"n":"selector","p":1109786},{"n":"context","p":114098177}],"n":".ctor","o":"$ctor$1","d":1568538,"h":64426077978,"f":1}],"h":1568538,"a":[{"t":70909953,"c":8660844545,"a":[{"v":"Formatter-based serialization is obsolete and should not be used.","t":1310721}],"n":[{"n":"DiagnosticId","v":"SYSLIB0050","t":1310721},{"n":"UrlFormat","v":"https://aka.ms/dotnet-warnings/{0}","t":1310721}]}]}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.Runtime.Serialization.ObjectManager`; }
        });
        
        $asm.$cls("$srsf.System.Collections.HashHelpers", ($self) => class HashHelpers
        {
            /*uint*/ static HashCollisionThreshold = 100;
            /*int*/ static MaxPrimeArrayLength = 2147483587;
            /*int*/ static HashPrime = 101;
            static /*ReadOnlySpan<int> */ get Primes()
            {
                return this.$cachePrimes ??= new ($.$spc.System.ReadOnlySpan$$($.$spc.System.Int32))().$ctor$2([ 3, 7, 11, 17, 23, 29, 37, 47, 59, 71, 89, 107, 131, 163, 197, 239, 293, 353, 431, 521, 631, 761, 919, 1103, 1327, 1597, 1931, 2333, 2801, 3371, 4049, 4861, 5839, 7013, 8419, 10103, 12143, 14591, 17519, 21023, 25229, 30293, 36353, 43627, 52361, 62851, 75431, 90523, 108631, 130363, 156437, 187751, 225307, 270371, 324449, 389357, 467237, 560689, 672827, 807403, 968897, 1162687, 1395263, 1674319, 2009191, 2411033, 2893249, 3471899, 4166287, 4999559, 5999471, 7199369 ]);
            }
            static /*bool */ IsPrime(/*int*/ candidate)
            {
                if ((candidate & 1) !== 0)
                {
                    /*int*/ let limit = $.$cast(Math.sqrt(candidate), $.$spc.System.Int32);
                    for(/*int*/ let divisor = 3; divisor <= limit; divisor += 2)
                    {
                        if ((candidate % divisor) === 0)
                        {
                            return false;
                        }
                    }
                    return true;
                }
                return candidate === 2;
            }
            static /*int */ GetPrime(/*int*/ min)
            {
                if (min < 0)
                {
                    throw new $.$spc.System.ArgumentException().$ctor$10($.$srsf.System.SR.Arg_HTCapacityOverflow);
                }
                var $en2 = $.$srsf.System.Collections.HashHelpers.Primes.GetEnumerator();
                while ($en2.MoveNext())
                {
                    var prime = $en2.Current.$v;
                    {
                        if (prime >= min)
                        {
                            return prime;
                        }
                    }
                }
                for(/*int*/ let i = (min | 1); i < 2147483647/*int.MaxValue*/; i += 2)
                {
                    if ($.$srsf.System.Collections.HashHelpers.IsPrime(i) && ((((i - 1) | 0)) % 101/*HashPrime*/ !== 0))
                    {
                        return i;
                    }
                }
                return min;
            }
            static /*int */ ExpandPrime(/*int*/ oldSize)
            {
                /*int*/ let newSize = ((2 * oldSize) | 0);
                if ((newSize >>> 0) > 2147483587/*MaxPrimeArrayLength*/ && 2147483587/*MaxPrimeArrayLength*/ > oldSize)
                {
                    $.$spc.System.Diagnostics.Debug.Assert$1(2147483587/*MaxPrimeArrayLength*/ === $.$srsf.System.Collections.HashHelpers.GetPrime(2147483587/*MaxPrimeArrayLength*/), "Invalid MaxPrimeArrayLength");
                    return 2147483587/*MaxPrimeArrayLength*/;
                }
                return $.$srsf.System.Collections.HashHelpers.GetPrime(newSize);
            }
            static /*ulong */ GetFastModMultiplier(/*uint*/ divisor)
            {
                return 18446744073709551615n / BigInt(divisor) + 1n;
            }
            static /*uint */ FastMod(/*uint*/ value, /*uint*/ divisor, /*ulong*/ multiplier)
            {
                $.$spc.System.Diagnostics.Debug.Assert$1(divisor <= 2147483647/*int.MaxValue*/, "divisor <= int.MaxValue");
                /*uint*/ let highbits = $.$cast((((((multiplier * BigInt(value)) >> 32n) + 1n) * BigInt(divisor)) >> 32n), $.$spc.System.UInt32);
                $.$spc.System.Diagnostics.Debug.Assert$1(highbits === value % divisor, "highbits == value % divisor");
                return highbits;
            }
            static $h = 126746;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":$.$spc.System.ReadOnlySpan$$($.$spc.System.Int32).$h,"g":{"r":0,"d":0,"h":21474963226,"f":40},"n":"Primes","d":126746,"h":17179995930,"f":40}],"m":[{"r":262145,"p":[{"n":"candidate","p":655361}],"n":"IsPrime","d":126746,"h":25769930522,"f":33},{"r":655361,"p":[{"n":"min","p":655361}],"n":"GetPrime","d":126746,"h":30064897818,"f":33},{"r":655361,"p":[{"n":"oldSize","p":655361}],"n":"ExpandPrime","d":126746,"h":34359865114,"f":33},{"r":983041,"p":[{"n":"divisor","p":720897}],"n":"GetFastModMultiplier","d":126746,"h":38654832410,"f":33},{"r":720897,"p":[{"n":"value","p":720897},{"n":"divisor","p":720897},{"n":"multiplier","p":983041}],"n":"FastMod","d":126746,"h":42949799706,"f":33}],"l":[{"t":720897,"n":"HashCollisionThreshold","d":126746,"h":4295094042,"f":33},{"t":655361,"n":"MaxPrimeArrayLength","d":126746,"h":8590061338,"f":33},{"t":655361,"n":"HashPrime","d":126746,"h":12885028634,"f":33}],"h":126746}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.Collections.HashHelpers`; }
        });
        
        $asm.$cls("$srsf.System.Runtime.Serialization.FormatterServices", ($self) => class FormatterServices
        {
            /*ConcurrentDictionary<MemberHolder, MemberInfo[]>*/ static s_memberInfoTable = null;
            static /*FieldInfo[] */ InternalGetSerializableMembers(/*Type*/ type)
            {
                $.$spc.System.Diagnostics.Debug.Assert$1($.$spc.System.Type.op_Inequality$1(type, null), "type != null");
                if (type.IsInterface)
                {
                    return $.$spc.System.Array.Empty($.$spc.System.Reflection.FieldInfo);
                }
                if (!type.IsSerializable)
                {
                    throw new $.$spc.System.Runtime.Serialization.SerializationException().$ctor$10($.$srsf.System.SR.Format$1($.$srsf.System.SR.Serialization_NonSerType, type.FullName, type.Assembly.FullName));
                }
                /*FieldInfo[]*/ let typeMembers = $.$srsf.System.Runtime.Serialization.FormatterServices.GetSerializableFields(type);
                /*Type?*/ let parentType = type.BaseType;
                if ($.$spc.System.Type.op_Inequality$1(parentType, null) && $.$spc.System.Type.op_Inequality$1(parentType, $.$spc.System.Object.$type))
                {
                    /*Type[]?*/ let parentTypes;
                    /*int*/ let parentTypeCount;
                    /*bool*/ let classNamesUnique = $.$srsf.System.Runtime.Serialization.FormatterServices.GetParentTypes(parentType, $.$ref(() => parentTypes, ($v) => parentTypes = $v, $.$typeArray($.$spc.System.Type)), $.$ref(() => parentTypeCount, ($v) => parentTypeCount = $v, $.$spc.System.Int32));
                    if (parentTypeCount > 0)
                    {
                        /*var*/ let allMembers = new ($.$spc.System.Collections.Generic.List$$($.$spc.System.Reflection.FieldInfo))().$ctor$1();
                        for(/*int*/ let i = 0; i < parentTypeCount; i++)
                        {
                            parentType = $.$spc.System.Array.$ReadT1.call(parentTypes, i);
                            if (!parentType.IsSerializable)
                            {
                                throw new $.$spc.System.Runtime.Serialization.SerializationException().$ctor$10($.$srsf.System.SR.Format$1($.$srsf.System.SR.Serialization_NonSerType, parentType.FullName, parentType.Module$1.Assembly.FullName));
                            }
                            /*FieldInfo[]*/ let typeFields = parentType.GetFields$1(32/*BindingFlags.NonPublic*/ | 4/*BindingFlags.Instance*/);
                            /*string*/ let typeName = classNamesUnique ? parentType.Name : parentType.FullName;
                            let $i3 = 0;
                            let $arr3 = typeFields;
                            while ($i3 < $arr3.length)
                            {
                                let field = $arr3[$i3++];
                                if (!field.IsNotSerialized)
                                {
                                    allMembers.Add(new $.$srsf.System.Runtime.Serialization.SerializationFieldInfo().$ctor$4(field, typeName));
                                }
                            }
                        }
                        if (allMembers !== null && allMembers.Count > 0)
                        {
                            /*var*/ let membersTemp = $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$spc.System.Reflection.FieldInfo), null, [((allMembers.Count + typeMembers.length) | 0)], null);
                            $.$spc.System.Array.Copy(typeMembers, membersTemp, typeMembers.length);
                            allMembers.CopyTo$2(membersTemp, typeMembers.length);
                            typeMembers = membersTemp;
                        }
                    }
                }
                return typeMembers;
            }
            static /*FieldInfo[] */ GetSerializableFields(/*Type*/ type)
            {
                /*FieldInfo[]*/ let fields = type.GetFields$1(16/*BindingFlags.Public*/ | 32/*BindingFlags.NonPublic*/ | 4/*BindingFlags.Instance*/);
                /*int*/ let countProper = 0;
                for(/*int*/ let i = 0; i < fields.length; i++)
                {
                    if (($.$spc.System.Array.$ReadT1.call(fields, i).Attributes & 128/*FieldAttributes.NotSerialized*/) === 128/*FieldAttributes.NotSerialized*/)
                    {
                        continue;
                    }
                    countProper++;
                }
                if (countProper !== fields.length)
                {
                    /*var*/ let properFields = $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$spc.System.Reflection.FieldInfo), null, [countProper], null);
                    countProper = 0;
                    for(/*int*/ let i = 0; i < fields.length; i++)
                    {
                        if (($.$spc.System.Array.$ReadT1.call(fields, i).Attributes & 128/*FieldAttributes.NotSerialized*/) === 128/*FieldAttributes.NotSerialized*/)
                        {
                            continue;
                        }
                        $.$spc.System.Array.$WriteT1.call(properFields, $.$spc.System.Array.$ReadT1.call(fields, i), countProper);
                        countProper++;
                    }
                    return properFields;
                }
                else 
                {
                    return fields;
                }
            }
            static /*bool */ GetParentTypes(/*Type*/ parentType, /*out Type[]?*/ parentTypes, /*out int*/ parentTypeCount)
            {
                parentTypes.$v = null;
                parentTypeCount.$v = 0;
                /*bool*/ let unique = true;
                /*Type*/ let objectType = $.$spc.System.Object.$type;
                for(/*Type*/ let t1 = parentType; $.$spc.System.Type.op_Inequality$1(t1, objectType); t1 = t1.BaseType)
                {
                    if (t1.IsInterface)
                    {
                        continue;
                    }
                    /*string*/ let t1Name = t1.Name;
                    for(/*int*/ let i = 0; unique && i < parentTypeCount.$v; i++)
                    {
                        /*string*/ let t2Name = $.$spc.System.Array.$ReadT1.call(parentTypes.$v, i).Name;
                        if (t2Name.length === t1Name.length && $.$spc.System.String.get_Chars.call(t2Name, 0) === $.$spc.System.String.get_Chars.call(t1Name, 0) && $.$spc.System.String.op_Equality(t1Name, t2Name))
                        {
                            unique = false;
                            break;
                        }
                    }
                    if (parentTypes.$v === null || parentTypeCount.$v === parentTypes.$v.length)
                    {
                        $.$spc.System.Array.Resize($.$spc.System.Type, parentTypes, $.$spc.System.Math.Max$4(((parentTypeCount.$v * 2) | 0), 12));
                    }
                    $.$spc.System.Array.$WriteT1.call(parentTypes.$v, t1, parentTypeCount.$v++);
                }
                return unique;
            }
            static /*MemberInfo[] */ GetSerializableMembers(/*Type*/ type)
            {
                return $.$srsf.System.Runtime.Serialization.FormatterServices.GetSerializableMembers$1(type, new $.$spc.System.Runtime.Serialization.StreamingContext().$ctor$2(255/*StreamingContextStates.All*/));
            }
            static /*MemberInfo[] */ GetSerializableMembers$1(/*Type*/ type, /*StreamingContext*/ context)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(type, "type");
                return $.$srsf.System.Runtime.Serialization.FormatterServices.s_memberInfoTable.GetOrAdd(new $.$srsf.System.Runtime.Serialization.MemberHolder().$ctor$1(type, context), new ($.$spc.System.Func$$$($.$srsf.System.Runtime.Serialization.MemberHolder, $.$typeArray($.$spc.System.Reflection.MemberInfo)))().$ctor(this,  (/**/ mh) =>
                {
                    return $.$srsf.System.Runtime.Serialization.FormatterServices.InternalGetSerializableMembers(mh._memberType);
                }, {"r":0,"p":[{"n":"mh","p":1240858}],"n":"","d":913178,"h":0,"f":1048578}));
            }
            static /*void */ CheckTypeSecurity(/*Type*/ t, /*TypeFilterLevel*/ securityLevel)
            {
            }
            static /*object */ GetUninitializedObject(/*Type*/ type)
            {
                return $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.GetUninitializedObject(type);
            }
            static /*object */ GetSafeUninitializedObject(/*Type*/ type)
            {
                return $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.GetUninitializedObject(type);
            }
            static /*void */ SerializationSetValue(/*MemberInfo*/ fi, /*object?*/ target, /*object?*/ value)
            {
                $.$spc.System.Diagnostics.Debug.Assert$1($.$spc.System.Reflection.MemberInfo.op_Inequality(fi, null), "fi != null");
                let serField;
                if ($.$is(fi, $.$spc.System.Reflection.FieldInfo, { set $v(v){ serField = v; } }))
                {
                    serField.SetValue(target, value);
                    return;
                }
                throw new $.$spc.System.ArgumentException().$ctor$10($.$srsf.System.SR.Argument_InvalidFieldInfo);
            }
            static /*object */ PopulateObjectMembers(/*object*/ obj, /*MemberInfo[]*/ members, /*object?[]*/ data)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(obj, "obj");
                $.$spc.System.ArgumentNullException.ThrowIfNull(members, "members");
                $.$spc.System.ArgumentNullException.ThrowIfNull(data, "data");
                if (members.length !== data.length)
                {
                    throw new $.$spc.System.ArgumentException().$ctor$10($.$srsf.System.SR.Argument_DataLengthDifferent);
                }
                for(/*int*/ let i = 0; i < members.length; i++)
                {
                    /*MemberInfo*/ let member = $.$spc.System.Array.$ReadT1.call(members, i);
                    if ($.$spc.System.Reflection.MemberInfo.op_Equality(member, null))
                    {
                        throw new $.$spc.System.ArgumentNullException().$ctor$18("members", $.$srsf.System.SR.Format($.$srsf.System.SR.ArgumentNull_NullMember, $.$box(i, $.$spc.System.Int32)));
                    }
                    /*object?*/ let value = $.$spc.System.Array.$ReadT1.call(data, i);
                    if (value === null)
                    {
                        continue;
                    }
                    let field;
                    if ($.$is(member, $.$spc.System.Reflection.FieldInfo, { set $v(v){ field = v; } }))
                    {
                        field.SetValue(obj, $.$spc.System.Array.$ReadT1.call(data, i));
                        continue;
                    }
                    throw new $.$spc.System.Runtime.Serialization.SerializationException().$ctor$10($.$srsf.System.SR.Serialization_UnknownMemberInfo);
                }
                return obj;
            }
            static /*object?[] */ GetObjectData(/*object*/ obj, /*MemberInfo[]*/ members)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(obj, "obj");
                $.$spc.System.ArgumentNullException.ThrowIfNull(members, "members");
                /*object?[]*/ let data = $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$spc.System.Object), null, [members.length], null);
                for(/*int*/ let i = 0; i < members.length; i++)
                {
                    /*MemberInfo*/ let member = $.$spc.System.Array.$ReadT1.call(members, i);
                    if ($.$spc.System.Reflection.MemberInfo.op_Equality(member, null))
                    {
                        throw new $.$spc.System.ArgumentNullException().$ctor$18("members", $.$srsf.System.SR.Format($.$srsf.System.SR.ArgumentNull_NullMember, $.$box(i, $.$spc.System.Int32)));
                    }
                    /*FieldInfo?*/ let field = $.$as(member, $.$spc.System.Reflection.FieldInfo);
                    if ($.$spc.System.Reflection.FieldInfo.op_Equality$1(field, null))
                    {
                        throw new $.$spc.System.Runtime.Serialization.SerializationException().$ctor$10($.$srsf.System.SR.Serialization_UnknownMemberInfo);
                    }
                    $.$spc.System.Array.$WriteT1.call(data, field.GetValue(obj), i);
                }
                return data;
            }
            static /*ISerializationSurrogate */ GetSurrogateForCyclicalReference(/*ISerializationSurrogate*/ innerSurrogate)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(innerSurrogate, "innerSurrogate");
                return new $.$srsf.System.Runtime.Serialization.SurrogateForCyclicalReference().$ctor$1(innerSurrogate);
            }
            static /*Type? */ GetTypeFromAssembly(/*Assembly*/ assem, /*string*/ name)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(assem, "assem");
                return assem.GetType$3(name, false, false);
            }
            static /*Assembly */ LoadAssemblyFromString(/*string*/ assemblyName)
            {
                return $.$spc.System.Reflection.Assembly.Load$1(new $.$spc.System.Reflection.AssemblyName().$ctor$1(assemblyName));
            }
            static /*Assembly? */ LoadAssemblyFromStringNoThrow(/*string*/ assemblyName)
            {
                try
                {
                    return $.$srsf.System.Runtime.Serialization.FormatterServices.LoadAssemblyFromString(assemblyName);
                }
                catch($e)
                {
                }
                return null;
            }
            static /*string */ GetClrAssemblyName(/*Type*/ type, /*out bool*/ hasTypeForwardedFrom)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(type, "type");
                /*Type*/ let attributedType = type;
                while(attributedType.HasElementType)
                {
                    attributedType = attributedType.GetElementType();
                }
                let $i1 = 0;
                let $arr1 = attributedType.GetCustomAttributes$1($.$spc.System.Runtime.CompilerServices.TypeForwardedFromAttribute.$type, false);
                while ($i1 < $arr1.length)
                {
                    let first = $arr1[$i1++];
                    hasTypeForwardedFrom.$v = true;
                    return ($.$cast(first, $.$spc.System.Runtime.CompilerServices.TypeForwardedFromAttribute)).AssemblyFullName;
                }
                hasTypeForwardedFrom.$v = false;
                return type.Assembly.FullName;
            }
            static /*string */ GetClrTypeFullName(/*Type*/ type)
            {
                return type.IsArray ? $.$srsf.System.Runtime.Serialization.FormatterServices.GetClrTypeFullNameForArray(type) : $.$srsf.System.Runtime.Serialization.FormatterServices.GetClrTypeFullNameForNonArrayTypes(type);
            }
            static /*string */ GetClrTypeFullNameForArray(/*Type*/ type)
            {
                /*int*/ let rank = type.GetArrayRank();
                $.$spc.System.Diagnostics.Debug.Assert$1(rank >= 1, "rank >= 1");
                /*string*/ let typeName = $.$srsf.System.Runtime.Serialization.FormatterServices.GetClrTypeFullName(type.GetElementType());
                return rank === 1 ? typeName + "[]" : typeName + "[" + $.$spc.System.String.Create$6(/*,*/ 44, ((rank - 1) | 0)) + "]";
            }
            static /*string */ GetClrTypeFullNameForNonArrayTypes(/*Type*/ type)
            {
                if (!type.IsGenericType)
                {
                    return type.FullName;
                }
                /*var*/ let builder = new $.$spc.System.Text.StringBuilder().$ctor$3(type.GetGenericTypeDefinition().FullName).Append$7(/*[*/ 91);
                /*bool*/ let hasTypeForwardedFrom;
                let $i1 = 0;
                let $arr1 = type.GetGenericArguments();
                while ($i1 < $arr1.length)
                {
                    let genericArgument = $arr1[$i1++];
                    builder.Append$7(/*[*/ 91).Append$2($.$srsf.System.Runtime.Serialization.FormatterServices.GetClrTypeFullName(genericArgument)).Append$2(", ");
                    builder.Append$2($.$srsf.System.Runtime.Serialization.FormatterServices.GetClrAssemblyName(genericArgument, $.$ref(() => hasTypeForwardedFrom, ($v) => hasTypeForwardedFrom = $v, $.$spc.System.Boolean))).Append$2("],");
                }
                return $.$spc.System.Text.StringBuilder.ToString.call(builder.Remove(((builder.Length - 1) | 0), 1).Append$7(/*]*/ 93));
            }
            //Static Initializer
            static $sinit()
            {
                {
                    this.s_memberInfoTable = new ($.$scc.System.Collections.Concurrent.ConcurrentDictionary$$$($.$srsf.System.Runtime.Serialization.MemberHolder, $.$typeArray($.$spc.System.Reflection.MemberInfo)))().$ctor$1();
                }
            }
            static $h = 913178;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"m":[{"r":0,"p":[{"n":"type","p":142606337}],"n":"InternalGetSerializableMembers","d":913178,"h":8590847770,"f":34},{"r":0,"p":[{"n":"type","p":142606337}],"n":"GetSerializableFields","d":913178,"h":12885815066,"f":34},{"r":262145,"p":[{"n":"parentType","p":142606337},{"n":"parentTypes","p":0,"f":2},{"n":"parentTypeCount","p":655361,"f":2}],"n":"GetParentTypes","d":913178,"h":17180782362,"f":34},{"r":0,"p":[{"n":"type","p":142606337}],"n":"GetSerializableMembers","d":913178,"h":21475749658,"f":33},{"r":0,"p":[{"n":"type","p":142606337},{"n":"context","p":114098177}],"n":"GetSerializableMembers","o":"@$1","d":913178,"h":25770716954,"f":33},{"r":65537,"p":[{"n":"t","p":142606337},{"n":"securityLevel","p":847642}],"n":"CheckTypeSecurity","d":913178,"h":30065684250,"f":33},{"r":131073,"p":[{"n":"type","p":142606337}],"n":"GetUninitializedObject","d":913178,"h":34360651546,"f":33},{"r":131073,"p":[{"n":"type","p":142606337}],"n":"GetSafeUninitializedObject","d":913178,"h":38655618842,"f":33},{"r":65537,"p":[{"n":"fi","p":78249985},{"n":"target","p":131073},{"n":"value","p":131073}],"n":"SerializationSetValue","d":913178,"h":42950586138,"f":40},{"r":131073,"p":[{"n":"obj","p":131073},{"n":"members","p":0},{"n":"data","p":0}],"n":"PopulateObjectMembers","d":913178,"h":47245553434,"f":33},{"r":0,"p":[{"n":"obj","p":131073},{"n":"members","p":0}],"n":"GetObjectData","d":913178,"h":51540520730,"f":33},{"r":1044250,"p":[{"n":"innerSurrogate","p":1044250}],"n":"GetSurrogateForCyclicalReference","d":913178,"h":55835488026,"f":33},{"r":142606337,"p":[{"n":"assem","p":73465857},{"n":"name","p":1310721}],"n":"GetTypeFromAssembly","d":913178,"h":60130455322,"f":33},{"r":73465857,"p":[{"n":"assemblyName","p":1310721}],"n":"LoadAssemblyFromString","d":913178,"h":64425422618,"f":40},{"r":73465857,"p":[{"n":"assemblyName","p":1310721}],"n":"LoadAssemblyFromStringNoThrow","d":913178,"h":68720389914,"f":40},{"r":1310721,"p":[{"n":"type","p":142606337},{"n":"hasTypeForwardedFrom","p":262145,"f":2}],"n":"GetClrAssemblyName","d":913178,"h":73015357210,"f":40},{"r":1310721,"p":[{"n":"type","p":142606337}],"n":"GetClrTypeFullName","d":913178,"h":77310324506,"f":40},{"r":1310721,"p":[{"n":"type","p":142606337}],"n":"GetClrTypeFullNameForArray","d":913178,"h":81605291802,"f":34},{"r":1310721,"p":[{"n":"type","p":142606337}],"n":"GetClrTypeFullNameForNonArrayTypes","d":913178,"h":85900259098,"f":34}],"l":[{"t":$.$scc.System.Collections.Concurrent.ConcurrentDictionary$$$($.$srsf.System.Runtime.Serialization.MemberHolder, $.$typeArray($.$spc.System.Reflection.MemberInfo)).$h,"n":"s_memberInfoTable","d":913178,"h":4295880474,"f":34}],"h":913178,"a":[{"t":70909953,"c":8660844545,"a":[{"v":"Formatter-based serialization is obsolete and should not be used.","t":1310721}],"n":[{"n":"DiagnosticId","v":"SYSLIB0050","t":1310721},{"n":"UrlFormat","v":"https://aka.ms/dotnet-warnings/{0}","t":1310721}]}]}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.Runtime.Serialization.FormatterServices`; }
        });
        
        $asm.$cls("$srsf.System.Runtime.Serialization.SurrogateKey", ($self) => class SurrogateKey extends $.$spc.System.Object
        {
            /*Type*/ _type = null;
            /*StreamingContext*/ _context;
            $ctor$1(/*Type*/ type, /*StreamingContext*/ context)
            {
                super.$ctor();
                {
                    $.$spc.System.Diagnostics.Debug.Assert$1($.$spc.System.Type.op_Inequality$1(type, null), "type != null");
                    this._type = type;
                    this._context = context;
                }
                return this;
            }
            static/*conventional*/ /*int */ GetHashCode()
            {
                return $.$spc.System.Type.GetHashCode.call(this._type);
            }
            //Static convention instance redirect
            /*int */ GetHashCode() { return $.$srsf.System.Runtime.Serialization.SurrogateKey.GetHashCode.apply(this, arguments); }
            //default member initializer
            constructor()
            {
                super();
                this._context = $.$default($.$spc.System.Runtime.Serialization.StreamingContext);
            }
            static $h = 2223898;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"m":[{"r":655361,"n":"GetHashCode","d":2223898,"h":17182093082,"f":32769}],"l":[{"t":142606337,"n":"_type","d":2223898,"h":4297191194,"f":8},{"t":114098177,"n":"_context","d":2223898,"h":8592158490,"f":8}],"c":[{"p":[{"n":"type","p":142606337},{"n":"context","p":114098177}],"n":".ctor","o":"$ctor$1","d":2223898,"h":12887125786,"f":8}],"h":2223898}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.Runtime.Serialization.SurrogateKey`; }
        });
        
        $asm.$cls("$srsf.System.Runtime.Serialization.SerializationEventsCache", ($self) => class SerializationEventsCache
        {
            /*ConcurrentDictionary<Type, SerializationEvents>*/ static s_cache = null;
            static /*SerializationEvents */ GetSerializationEventsForType(/*Type*/ t)
            {
                return $.$srsf.System.Runtime.Serialization.SerializationEventsCache.s_cache.GetOrAdd(t, new ($.$spc.System.Func$$$($.$spc.System.Type, $.$srsf.System.Runtime.Serialization.SerializationEvents))().$ctor($.$srsf.System.Runtime.Serialization.SerializationEventsCache, $.$srsf.System.Runtime.Serialization.SerializationEventsCache.CreateSerializationEvents));
            }
            static /*SerializationEvents */ CreateSerializationEvents(/*Type*/ t)
            {
                return new $.$srsf.System.Runtime.Serialization.SerializationEvents().$ctor$1(t);
            }
            //Static Initializer
            static $sinit()
            {
                {
                    this.s_cache = new ($.$scc.System.Collections.Concurrent.ConcurrentDictionary$$$($.$spc.System.Type, $.$srsf.System.Runtime.Serialization.SerializationEvents))().$ctor$1();
                }
            }
            static $h = 1830682;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"m":[{"r":1765146,"p":[{"n":"t","p":142606337}],"n":"GetSerializationEventsForType","d":1830682,"h":8591765274,"f":40},{"r":1765146,"p":[{"n":"t","p":142606337}],"n":"CreateSerializationEvents","d":1830682,"h":12886732570,"f":34}],"l":[{"t":$.$scc.System.Collections.Concurrent.ConcurrentDictionary$$$($.$spc.System.Type, $.$srsf.System.Runtime.Serialization.SerializationEvents).$h,"n":"s_cache","d":1830682,"h":4296797978,"f":34}],"h":1830682}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.Runtime.Serialization.SerializationEventsCache`; }
        });
        
        $asm.$cls("$srsf.System.Runtime.Serialization.SerializationObjectManager", ($self) => class SerializationObjectManager extends $.$spc.System.Object
        {
            /*string*/ static SerializationObjectManagerUnreferencedCodeMessage = null;
            /*Dictionary<object, object>*/ _objectSeenTable = null;
            /*StreamingContext*/ _context;
            /*SerializationEventHandler?*/ _onSerializedHandler = null;
            $ctor$1(/*StreamingContext*/ context)
            {
                super.$ctor();
                {
                    this._context = context;
                    this._objectSeenTable = new ($.$spc.System.Collections.Generic.Dictionary$$$($.$spc.System.Object, $.$spc.System.Object))().$ctor$1();
                }
                return this;
            }
            /*void */ RegisterObject(/*object*/ obj)
            {
                /*SerializationEvents*/ let cache = $.$srsf.System.Runtime.Serialization.SerializationEventsCache.GetSerializationEventsForType($.$spc.System.Object.GetType.call(obj));
                if (cache.HasOnSerializingEvents)
                {
                    if (this._objectSeenTable.TryAdd(obj, $.$box(true, $.$spc.System.Boolean)))
                    {
                        cache.InvokeOnSerializing(obj, this._context);
                        this.AddOnSerialized(obj);
                    }
                }
            }
            /*void */ RaiseOnSerializedEvent()
            {
                return (this._onSerializedHandler?.Invoke(this._context) ?? null);
            }
            /*void */ AddOnSerialized(/*object*/ obj)
            {
                /*SerializationEvents*/ let cache = $.$srsf.System.Runtime.Serialization.SerializationEventsCache.GetSerializationEventsForType($.$spc.System.Object.GetType.call(obj));
                this._onSerializedHandler = cache.AddOnSerialized(obj, this._onSerializedHandler);
            }
            //default member initializer
            constructor()
            {
                super();
                this._context = $.$default($.$spc.System.Runtime.Serialization.StreamingContext);
            }
            //Static Initializer
            static $sinit()
            {
                {
                    this.SerializationObjectManagerUnreferencedCodeMessage = "SerializationObjectManager is not trim compatible because the type of objects being managed cannot be statically discovered.";
                }
            }
            static $h = 2027290;
            static $f = 0b10010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"m":[{"r":65537,"p":[{"n":"obj","p":131073}],"n":"RegisterObject","d":2027290,"h":25771831066,"f":1},{"r":65537,"n":"RaiseOnSerializedEvent","d":2027290,"h":30066798362,"f":1},{"r":65537,"p":[{"n":"obj","p":131073}],"n":"AddOnSerialized","d":2027290,"h":34361765658,"f":2}],"l":[{"t":1310721,"n":"SerializationObjectManagerUnreferencedCodeMessage","d":2027290,"h":4296994586,"f":34},{"t":$.$spc.System.Collections.Generic.Dictionary$$$($.$spc.System.Object, $.$spc.System.Object).$h,"n":"_objectSeenTable","d":2027290,"h":8591961882,"f":2},{"t":114098177,"n":"_context","d":2027290,"h":12886929178,"f":2},{"t":1699610,"n":"_onSerializedHandler","d":2027290,"h":17181896474,"f":2}],"c":[{"p":[{"n":"context","p":114098177}],"n":".ctor","o":"$ctor$1","d":2027290,"h":21476863770,"f":1}],"h":2027290,"a":[{"t":70909953,"c":8660844545,"a":[{"v":"Formatter-based serialization is obsolete and should not be used.","t":1310721}],"n":[{"n":"DiagnosticId","v":"SYSLIB0050","t":1310721},{"n":"UrlFormat","v":"https://aka.ms/dotnet-warnings/{0}","t":1310721}]}]}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.Runtime.Serialization.SerializationObjectManager`; }
        });
        
        $asm.$cls("$srsf.System.Runtime.Serialization.ObjectHolder", ($self) => class ObjectHolder extends $.$spc.System.Object
        {
            /*int*/ static IncompleteObjectReference = 1;
            /*int*/ static HAS_ISERIALIZABLE = 2;
            /*int*/ static HAS_SURROGATE = 4;
            /*int*/ static REQUIRES_VALUETYPE_FIXUP = 8;
            /*int*/ static REQUIRES_DELAYED_FIXUP = 7;
            /*int*/ static SER_INFO_FIXED = 16384;
            /*int*/ static VALUETYPE_FIXUP_PERFORMED = 32768;
            /*object?*/ _object = null;
            /*long*/ _id = 0n;
            /*int*/ _missingElementsRemaining = 0;
            /*int*/ _missingDecendents = 0;
            /*SerializationInfo?*/ _serInfo = null;
            /*ISerializationSurrogate?*/ _surrogate = null;
            /*FixupHolderList?*/ _missingElements = null;
            /*LongList?*/ _dependentObjects = null;
            /*ObjectHolder?*/ _next = null;
            /*int*/ _flags = 0;
            /*bool*/ _markForFixupWhenAvailable = false;
            /*ValueTypeFixupInfo?*/ _valueFixup = null;
            /*TypeLoadExceptionHolder?*/ _typeLoad = null;
            /*bool*/ _reachable = false;
            $ctor$1(/*long*/ objID)
            {
                this.$ctor$3(null, objID, null, null, 0n, null, null);
                {
                }
                return this;
            }
            $ctor$2(/*object?*/ obj, /*long*/ objID, /*SerializationInfo?*/ info, /*ISerializationSurrogate?*/ surrogate, /*long*/ idOfContainingObj, /*FieldInfo?*/ field, /*int[]?*/ arrayIndex)
            {
                super.$ctor();
                {
                    $.$spc.System.Diagnostics.Debug.Assert$1(objID >= 0n, "objID>=0");
                    this._object = obj;
                    this._id = objID;
                    this._flags = 0;
                    this._missingElementsRemaining = 0;
                    this._missingDecendents = 0;
                    this._dependentObjects = null;
                    this._next = null;
                    this._serInfo = info;
                    this._surrogate = surrogate;
                    this._markForFixupWhenAvailable = false;
                    if ($.$is(obj, $.$srsf.System.Runtime.Serialization.TypeLoadExceptionHolder))
                    {
                        this._typeLoad = $.$cast(obj, $.$srsf.System.Runtime.Serialization.TypeLoadExceptionHolder);
                    }
                    if (idOfContainingObj !== 0n && (($.$spc.System.Reflection.FieldInfo.op_Inequality$1(field, null) && field.FieldType.IsValueType) || arrayIndex !== null))
                    {
                        if (idOfContainingObj === objID)
                        {
                            throw new $.$spc.System.Runtime.Serialization.SerializationException().$ctor$10($.$srsf.System.SR.Serialization_ParentChildIdentical);
                        }
                        this._valueFixup = new $.$srsf.System.Runtime.Serialization.ValueTypeFixupInfo().$ctor$1(idOfContainingObj, field, arrayIndex);
                    }
                    this.SetFlags();
                }
                return this;
            }
            $ctor$3(/*string?*/ obj, /*long*/ objID, /*SerializationInfo?*/ info, /*ISerializationSurrogate?*/ surrogate, /*long*/ idOfContainingObj, /*FieldInfo?*/ field, /*int[]?*/ arrayIndex)
            {
                super.$ctor();
                {
                    $.$spc.System.Diagnostics.Debug.Assert$1(objID >= 0n, "objID>=0");
                    this._object = obj;
                    this._id = objID;
                    this._flags = 0;
                    this._missingElementsRemaining = 0;
                    this._missingDecendents = 0;
                    this._dependentObjects = null;
                    this._next = null;
                    this._serInfo = info;
                    this._surrogate = surrogate;
                    this._markForFixupWhenAvailable = false;
                    if (idOfContainingObj !== 0n && arrayIndex !== null)
                    {
                        this._valueFixup = new $.$srsf.System.Runtime.Serialization.ValueTypeFixupInfo().$ctor$1(idOfContainingObj, field, arrayIndex);
                    }
                    if (this._valueFixup !== null)
                    {
                        this._flags |= 8/*REQUIRES_VALUETYPE_FIXUP*/;
                    }
                }
                return this;
            }
            /*void */ IncrementDescendentFixups(/*int*/ amount)
            {
                return this._missingDecendents += amount;
            }
            /*void */ DecrementFixupsRemaining(/*ObjectManager*/ manager)
            {
                this._missingElementsRemaining--;
                if (this.RequiresValueTypeFixup)
                {
                    this.UpdateDescendentDependencyChain(-1, manager);
                }
            }
            /*void */ RemoveDependency(/*long*/ id)
            {
                $.$spc.System.Diagnostics.Debug.Assert$1(this._dependentObjects !== null, "[ObjectHolder.RemoveDependency]m_dependentObjects!=null");
                $.$spc.System.Diagnostics.Debug.Assert$1(id >= 0n, "[ObjectHolder.RemoveDependency]id>=0");
                this._dependentObjects.RemoveElement(id);
            }
            /*void */ AddFixup(/*FixupHolder*/ fixup, /*ObjectManager*/ manager)
            {
                this._missingElements ??= new $.$srsf.System.Runtime.Serialization.FixupHolderList().$ctor$1();
                this._missingElements.Add(fixup);
                this._missingElementsRemaining++;
                if (this.RequiresValueTypeFixup)
                {
                    this.UpdateDescendentDependencyChain(1, manager);
                }
            }
            /*void */ UpdateDescendentDependencyChain(/*int*/ amount, /*ObjectManager*/ manager)
            {
                /*ObjectHolder*/ let holder = this;
                do
                {
                    holder = manager.FindOrCreateObjectHolder(holder.ContainerID);
                    $.$spc.System.Diagnostics.Debug.Assert$1(holder !== null, "[ObjectHolder.UpdateTotalDependencyChain]holder!=null");
                    holder.IncrementDescendentFixups(amount);
                }
                while(holder.RequiresValueTypeFixup);
            }
            /*void */ AddDependency(/*long*/ dependentObject)
            {
                this._dependentObjects ??= new $.$srsf.System.Runtime.Serialization.LongList().$ctor$1();
                this._dependentObjects.Add(dependentObject);
            }
            /*void */ UpdateData(/*object*/ obj, /*SerializationInfo?*/ info, /*ISerializationSurrogate?*/ surrogate, /*long*/ idOfContainer, /*FieldInfo?*/ field, /*int[]?*/ arrayIndex, /*ObjectManager*/ manager)
            {
                $.$spc.System.Diagnostics.Debug.Assert$1(obj !== null, "obj!=null");
                $.$spc.System.Diagnostics.Debug.Assert$1(this._id > 0n, "m_id>0");
                this.SetObjectValue(obj, manager);
                this._serInfo = info;
                this._surrogate = surrogate;
                if (idOfContainer !== 0n && (($.$spc.System.Reflection.FieldInfo.op_Inequality$1(field, null) && field.FieldType.IsValueType) || arrayIndex !== null))
                {
                    if (idOfContainer === this._id)
                    {
                        throw new $.$spc.System.Runtime.Serialization.SerializationException().$ctor$10($.$srsf.System.SR.Serialization_ParentChildIdentical);
                    }
                    this._valueFixup = new $.$srsf.System.Runtime.Serialization.ValueTypeFixupInfo().$ctor$1(idOfContainer, field, arrayIndex);
                }
                this.SetFlags();
                if (this.RequiresValueTypeFixup)
                {
                    this.UpdateDescendentDependencyChain(this._missingElementsRemaining, manager);
                }
            }
            /*void */ MarkForCompletionWhenAvailable()
            {
                return this._markForFixupWhenAvailable = true;
            }
            /*void */ SetFlags()
            {
                if ($.$is(this._object, $.$spc.System.Runtime.Serialization.IObjectReference))
                {
                    this._flags |= 1/*IncompleteObjectReference*/;
                }
                this._flags &= ~(2/*HAS_ISERIALIZABLE*/ | 4/*HAS_SURROGATE*/);
                if (this._surrogate !== null)
                {
                    this._flags |= 4/*HAS_SURROGATE*/;
                }
                else if ($.$is(this._object, $.$spc.System.Runtime.Serialization.ISerializable))
                {
                    this._flags |= 2/*HAS_ISERIALIZABLE*/;
                }
                if (this._valueFixup !== null)
                {
                    this._flags |= 8/*REQUIRES_VALUETYPE_FIXUP*/;
                }
            }
            /*bool */ get IsIncompleteObjectReference()
            {
                return (this._flags & 1/*IncompleteObjectReference*/) !== 0;
            }
            /*bool */ set IsIncompleteObjectReference(value)
            {
                if (value)
                {
                    this._flags |= 1/*IncompleteObjectReference*/;
                }
                else 
                {
                    this._flags &= ~1/*IncompleteObjectReference*/;
                }
            }
            /*bool */ get RequiresDelayedFixup()
            {
                return (this._flags & 7/*REQUIRES_DELAYED_FIXUP*/) !== 0;
            }
            /*bool */ get RequiresValueTypeFixup()
            {
                return (this._flags & 8/*REQUIRES_VALUETYPE_FIXUP*/) !== 0;
            }
            /*bool */ get ValueTypeFixupPerformed()
            {
                return (((this._flags & 32768/*VALUETYPE_FIXUP_PERFORMED*/) !== 0) || (this._object !== null && ((this._dependentObjects === null) || this._dependentObjects.Count === 0)));
            }
            /*bool */ set ValueTypeFixupPerformed(value)
            {
                if (value)
                {
                    this._flags |= 32768/*VALUETYPE_FIXUP_PERFORMED*/;
                }
            }
            /*bool */ get HasISerializable()
            {
                return (this._flags & 2/*HAS_ISERIALIZABLE*/) !== 0;
            }
            /*bool */ get HasSurrogate()
            {
                return (this._flags & 4/*HAS_SURROGATE*/) !== 0;
            }
            /*bool */ get CanSurrogatedObjectValueChange()
            {
                return (this._surrogate === null || $.$spc.System.Type.op_Inequality$1($.$spc.System.Object.GetType.call(this._surrogate), $.$srsf.System.Runtime.Serialization.SurrogateForCyclicalReference.$type));
            }
            /*bool */ get CanObjectValueChange()
            {
                return this.IsIncompleteObjectReference ? true : this.HasSurrogate ? this.CanSurrogatedObjectValueChange : false;
            }
            /*int */ get DirectlyDependentObjects()
            {
                return this._missingElementsRemaining;
            }
            /*int */ get TotalDependentObjects()
            {
                return ((this._missingElementsRemaining + this._missingDecendents) | 0);
            }
            /*bool */ get Reachable()
            {
                return this._reachable;
            }
            /*bool */ set Reachable(value)
            {
                this._reachable = value;
            }
            /*bool */ get TypeLoadExceptionReachable()
            {
                return this._typeLoad !== null;
            }
            /*TypeLoadExceptionHolder? */ get TypeLoadException()
            {
                return this._typeLoad;
            }
            /*TypeLoadExceptionHolder? */ set TypeLoadException(value)
            {
                this._typeLoad = value;
            }
            /*object? */ get ObjectValue()
            {
                return this._object;
            }
            /*void */ SetObjectValue(/*object?*/ obj, /*ObjectManager*/ manager)
            {
                this._object = obj;
                if (obj === manager.TopObject)
                {
                    this._reachable = true;
                }
                if ($.$is(obj, $.$srsf.System.Runtime.Serialization.TypeLoadExceptionHolder))
                {
                    this._typeLoad = $.$cast(obj, $.$srsf.System.Runtime.Serialization.TypeLoadExceptionHolder);
                }
                if (this._markForFixupWhenAvailable)
                {
                    manager.CompleteObject(this, true);
                }
            }
            /*SerializationInfo? */ get SerializationInfo()
            {
                return this._serInfo;
            }
            /*SerializationInfo? */ set SerializationInfo(value)
            {
                this._serInfo = value;
            }
            /*ISerializationSurrogate? */ get Surrogate()
            {
                return this._surrogate;
            }
            /*LongList? */ get DependentObjects()
            {
                return this._dependentObjects;
            }
            /*LongList? */ set DependentObjects(value)
            {
                this._dependentObjects = value;
            }
            /*bool */ get RequiresSerInfoFixup()
            {
                if (((this._flags & 4/*HAS_SURROGATE*/) === 0) && ((this._flags & 2/*HAS_ISERIALIZABLE*/) === 0))
                {
                    return false;
                }
                return (this._flags & 16384/*SER_INFO_FIXED*/) === 0;
            }
            /*bool */ set RequiresSerInfoFixup(value)
            {
                if (!value)
                {
                    this._flags |= 16384/*SER_INFO_FIXED*/;
                }
                else 
                {
                    this._flags &= ~16384/*SER_INFO_FIXED*/;
                }
            }
            /*ValueTypeFixupInfo? */ get ValueFixup()
            {
                return this._valueFixup;
            }
            /*bool */ get CompletelyFixed()
            {
                return !this.RequiresSerInfoFixup && !this.IsIncompleteObjectReference;
            }
            /*long */ get ContainerID()
            {
                return this._valueFixup !== null ? this._valueFixup.ContainerID : 0n;
            }
            static $h = 1306394;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":262145,"g":{"r":0,"d":0,"h":150325161754,"f":8},"s":{"r":0,"d":0,"h":154620129050,"f":8},"n":"IsIncompleteObjectReference","d":1306394,"h":146030194458,"f":8},{"p":262145,"g":{"r":0,"d":0,"h":163210063642,"f":8},"n":"RequiresDelayedFixup","d":1306394,"h":158915096346,"f":8},{"p":262145,"g":{"r":0,"d":0,"h":171799998234,"f":8},"n":"RequiresValueTypeFixup","d":1306394,"h":167505030938,"f":8},{"p":262145,"g":{"r":0,"d":0,"h":180389932826,"f":8},"s":{"r":0,"d":0,"h":184684900122,"f":8},"n":"ValueTypeFixupPerformed","d":1306394,"h":176094965530,"f":8},{"p":262145,"g":{"r":0,"d":0,"h":193274834714,"f":8},"n":"HasISerializable","d":1306394,"h":188979867418,"f":8},{"p":262145,"g":{"r":0,"d":0,"h":201864769306,"f":8},"n":"HasSurrogate","d":1306394,"h":197569802010,"f":8},{"p":262145,"g":{"r":0,"d":0,"h":210454703898,"f":8},"n":"CanSurrogatedObjectValueChange","d":1306394,"h":206159736602,"f":8},{"p":262145,"g":{"r":0,"d":0,"h":219044638490,"f":8},"n":"CanObjectValueChange","d":1306394,"h":214749671194,"f":8},{"p":655361,"g":{"r":0,"d":0,"h":227634573082,"f":8},"n":"DirectlyDependentObjects","d":1306394,"h":223339605786,"f":8},{"p":655361,"g":{"r":0,"d":0,"h":236224507674,"f":8},"n":"TotalDependentObjects","d":1306394,"h":231929540378,"f":8},{"p":262145,"g":{"r":0,"d":0,"h":244814442266,"f":8},"s":{"r":0,"d":0,"h":249109409562,"f":8},"n":"Reachable","d":1306394,"h":240519474970,"f":8},{"p":262145,"g":{"r":0,"d":0,"h":257699344154,"f":8},"n":"TypeLoadExceptionReachable","d":1306394,"h":253404376858,"f":8},{"p":131073,"g":{"r":0,"d":0,"h":279174180634,"f":8},"n":"ObjectValue","d":1306394,"h":274879213338,"f":8},{"p":113967105,"g":{"r":0,"d":0,"h":292059082522,"f":8},"s":{"r":0,"d":0,"h":296354049818,"f":8},"n":"SerializationInfo","d":1306394,"h":287764115226,"f":8},{"p":1044250,"g":{"r":0,"d":0,"h":304943984410,"f":8},"n":"Surrogate","d":1306394,"h":300649017114,"f":8},{"p":1175322,"g":{"r":0,"d":0,"h":313533919002,"f":8},"s":{"r":0,"d":0,"h":317828886298,"f":8},"n":"DependentObjects","d":1306394,"h":309238951706,"f":8},{"p":262145,"g":{"r":0,"d":0,"h":326418820890,"f":8},"s":{"r":0,"d":0,"h":330713788186,"f":8},"n":"RequiresSerInfoFixup","d":1306394,"h":322123853594,"f":8},{"p":2420506,"g":{"r":0,"d":0,"h":339303722778,"f":8},"n":"ValueFixup","d":1306394,"h":335008755482,"f":8},{"p":262145,"g":{"r":0,"d":0,"h":347893657370,"f":8},"n":"CompletelyFixed","d":1306394,"h":343598690074,"f":8},{"p":917505,"g":{"r":0,"d":0,"h":356483591962,"f":8},"n":"ContainerID","d":1306394,"h":352188624666,"f":8}],"m":[{"r":65537,"p":[{"n":"amount","p":655361}],"n":"IncrementDescendentFixups","d":1306394,"h":107375488794,"f":2},{"r":65537,"p":[{"n":"manager","p":1568538}],"n":"DecrementFixupsRemaining","d":1306394,"h":111670456090,"f":8},{"r":65537,"p":[{"n":"id","p":917505}],"n":"RemoveDependency","d":1306394,"h":115965423386,"f":8},{"r":65537,"p":[{"n":"fixup","p":323354},{"n":"manager","p":1568538}],"n":"AddFixup","d":1306394,"h":120260390682,"f":8},{"r":65537,"p":[{"n":"amount","p":655361},{"n":"manager","p":1568538}],"n":"UpdateDescendentDependencyChain","d":1306394,"h":124555357978,"f":2},{"r":65537,"p":[{"n":"dependentObject","p":917505}],"n":"AddDependency","d":1306394,"h":128850325274,"f":8},{"r":65537,"p":[{"n":"obj","p":131073},{"n":"info","p":113967105},{"n":"surrogate","p":1044250},{"n":"idOfContainer","p":917505},{"n":"field","p":76677121},{"n":"arrayIndex","p":0},{"n":"manager","p":1568538}],"n":"UpdateData","d":1306394,"h":133145292570,"f":8},{"r":65537,"n":"MarkForCompletionWhenAvailable","d":1306394,"h":137440259866,"f":8},{"r":65537,"n":"SetFlags","d":1306394,"h":141735227162,"f":8},{"r":65537,"p":[{"n":"obj","p":131073},{"n":"manager","p":1568538}],"n":"SetObjectValue","d":1306394,"h":283469147930,"f":8}],"l":[{"t":655361,"n":"IncompleteObjectReference","d":1306394,"h":4296273690,"f":40},{"t":655361,"n":"HAS_ISERIALIZABLE","d":1306394,"h":8591240986,"f":40},{"t":655361,"n":"HAS_SURROGATE","d":1306394,"h":12886208282,"f":40},{"t":655361,"n":"REQUIRES_VALUETYPE_FIXUP","d":1306394,"h":17181175578,"f":40},{"t":655361,"n":"REQUIRES_DELAYED_FIXUP","d":1306394,"h":21476142874,"f":40},{"t":655361,"n":"SER_INFO_FIXED","d":1306394,"h":25771110170,"f":40},{"t":655361,"n":"VALUETYPE_FIXUP_PERFORMED","d":1306394,"h":30066077466,"f":40},{"t":131073,"n":"_object","d":1306394,"h":34361044762,"f":2},{"t":917505,"n":"_id","d":1306394,"h":38656012058,"f":8},{"t":655361,"n":"_missingElementsRemaining","d":1306394,"h":42950979354,"f":2},{"t":655361,"n":"_missingDecendents","d":1306394,"h":47245946650,"f":2},{"t":113967105,"n":"_serInfo","d":1306394,"h":51540913946,"f":8},{"t":1044250,"n":"_surrogate","d":1306394,"h":55835881242,"f":8},{"t":388890,"n":"_missingElements","d":1306394,"h":60130848538,"f":8},{"t":1175322,"n":"_dependentObjects","d":1306394,"h":64425815834,"f":8},{"t":1306394,"n":"_next","d":1306394,"h":68720783130,"f":8},{"t":655361,"n":"_flags","d":1306394,"h":73015750426,"f":8},{"t":262145,"n":"_markForFixupWhenAvailable","d":1306394,"h":77310717722,"f":2},{"t":2420506,"n":"_valueFixup","d":1306394,"h":81605685018,"f":2},{"t":2354970,"n":"_typeLoad","d":1306394,"h":85900652314,"f":2},{"t":262145,"n":"_reachable","d":1306394,"h":90195619610,"f":2}],"c":[{"p":[{"n":"objID","p":917505}],"n":".ctor","o":"$ctor$1","d":1306394,"h":94490586906,"f":8},{"p":[{"n":"obj","p":131073},{"n":"objID","p":917505},{"n":"info","p":113967105},{"n":"surrogate","p":1044250},{"n":"idOfContainingObj","p":917505},{"n":"field","p":76677121},{"n":"arrayIndex","p":0}],"n":".ctor","o":"$ctor$2","d":1306394,"h":98785554202,"f":8},{"p":[{"n":"obj","p":1310721},{"n":"objID","p":917505},{"n":"info","p":113967105},{"n":"surrogate","p":1044250},{"n":"idOfContainingObj","p":917505},{"n":"field","p":76677121},{"n":"arrayIndex","p":0}],"n":".ctor","o":"$ctor$3","d":1306394,"h":103080521498,"f":8}],"h":1306394}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.Runtime.Serialization.ObjectHolder`; }
        });
        
        $asm.$cls("$srsf.System.Runtime.Serialization.FixupHolder", ($self) => class FixupHolder extends $.$spc.System.Object
        {
            /*int*/ static ArrayFixup = 1;
            /*int*/ static MemberFixup = 2;
            /*int*/ static DelayedFixup = 4;
            /*long*/ _id = 0n;
            /*object*/ _fixupInfo = null;
            /*int*/ _fixupType = 0;
            $ctor$1(/*long*/ id, /*object*/ fixupInfo, /*int*/ fixupType)
            {
                super.$ctor();
                {
                    $.$spc.System.Diagnostics.Debug.Assert$1(id > 0n, "id>0");
                    $.$spc.System.Diagnostics.Debug.Assert$1(fixupInfo !== null, "fixupInfo!=null");
                    $.$spc.System.Diagnostics.Debug.Assert$1(fixupType === 1/*ArrayFixup*/ || fixupType === 2/*MemberFixup*/ || fixupType === 4/*DelayedFixup*/, "fixupType==ArrayFixup || fixupType == MemberFixup || fixupType==DelayedFixup");
                    this._id = id;
                    this._fixupInfo = fixupInfo;
                    this._fixupType = fixupType;
                }
                return this;
            }
            static $h = 323354;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"l":[{"t":655361,"n":"ArrayFixup","d":323354,"h":4295290650,"f":40},{"t":655361,"n":"MemberFixup","d":323354,"h":8590257946,"f":40},{"t":655361,"n":"DelayedFixup","d":323354,"h":12885225242,"f":40},{"t":917505,"n":"_id","d":323354,"h":17180192538,"f":8},{"t":131073,"n":"_fixupInfo","d":323354,"h":21475159834,"f":8},{"t":655361,"n":"_fixupType","d":323354,"h":25770127130,"f":8}],"c":[{"p":[{"n":"id","p":917505},{"n":"fixupInfo","p":131073},{"n":"fixupType","p":655361}],"n":".ctor","o":"$ctor$1","d":323354,"h":30065094426,"f":8}],"h":323354}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.Runtime.Serialization.FixupHolder`; }
        });
        
        $asm.$cls("$srsf.System.Runtime.Serialization.FixupHolderList", ($self) => class FixupHolderList extends $.$spc.System.Object
        {
            /*int*/ static InitialSize = 2;
            /*FixupHolder?[]*/ _values = null;
            /*int*/ _count = 0;
            $ctor$1()
            {
                this.$ctor$2(2/*InitialSize*/);
                {
                }
                return this;
            }
            $ctor$2(/*int*/ startingSize)
            {
                super.$ctor();
                {
                    this._count = 0;
                    this._values = $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$srsf.System.Runtime.Serialization.FixupHolder), null, [startingSize], null);
                }
                return this;
            }
            /*void */ Add(/*FixupHolder*/ fixup)
            {
                if (this._count === this._values.length)
                {
                    this.EnlargeArray();
                }
                $.$spc.System.Array.$WriteT1.call(this._values, fixup, this._count++);
            }
            /*void */ EnlargeArray()
            {
                /*int*/ let newLength = ((this._values.length * 2) | 0);
                if (newLength < 0)
                {
                    newLength = 2147483647/*int.MaxValue*/;
                }
                /*FixupHolder[]*/ let temp = $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$srsf.System.Runtime.Serialization.FixupHolder), null, [newLength], null);
                $.$spc.System.Array.Copy(this._values, temp, this._count);
                this._values = temp;
            }
            static $h = 388890;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"m":[{"r":65537,"p":[{"n":"fixup","p":323354}],"n":"Add","d":388890,"h":25770192666,"f":8},{"r":65537,"n":"EnlargeArray","d":388890,"h":30065159962,"f":2}],"l":[{"t":655361,"n":"InitialSize","d":388890,"h":4295356186,"f":40},{"t":0,"n":"_values","d":388890,"h":8590323482,"f":8},{"t":655361,"n":"_count","d":388890,"h":12885290778,"f":8}],"c":[{"n":".ctor","o":"$ctor$1","d":388890,"h":17180258074,"f":8},{"p":[{"n":"startingSize","p":655361}],"n":".ctor","o":"$ctor$2","d":388890,"h":21475225370,"f":8}],"h":388890}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.Runtime.Serialization.FixupHolderList`; }
        });
        
        $asm.$cls("$srsf.System.Runtime.Serialization.LongList", ($self) => class LongList extends $.$spc.System.Object
        {
            /*int*/ static InitialSize = 2;
            /*long[]*/ _values = null;
            /*int*/ _count = 0;
            /*int*/ _totalItems = 0;
            /*int*/ _currentItem = 0;
            $ctor$1()
            {
                this.$ctor$2(2/*InitialSize*/);
                {
                }
                return this;
            }
            $ctor$2(/*int*/ startingSize)
            {
                super.$ctor();
                {
                    this._count = 0;
                    this._totalItems = 0;
                    this._values = $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$spc.System.Int64), null, [startingSize], null);
                }
                return this;
            }
            /*void */ Add(/*long*/ value)
            {
                if (this._totalItems === this._values.length)
                {
                    this.EnlargeArray();
                }
                $.$spc.System.Array.$WriteT1.call(this._values, value, this._totalItems++);
                this._count++;
            }
            /*int */ get Count()
            {
                return this._count;
            }
            /*void */ StartEnumeration()
            {
                return this._currentItem = -1;
            }
            /*bool */ MoveNext()
            {
                while(++this._currentItem < this._totalItems && $.$spc.System.Array.$ReadT1.call(this._values, this._currentItem) === BigInt(-1))
                {
                }
                return this._currentItem !== this._totalItems;
            }
            /*long */ get Current()
            {
                $.$spc.System.Diagnostics.Debug.Assert$1(this._currentItem !== -1, "[LongList.Current]m_currentItem!=-1");
                $.$spc.System.Diagnostics.Debug.Assert$1($.$spc.System.Array.$ReadT1.call(this._values, this._currentItem) !== BigInt(-1), "[LongList.Current]m_values[m_currentItem]!=-1");
                return $.$spc.System.Array.$ReadT1.call(this._values, this._currentItem);
            }
            /*bool */ RemoveElement(/*long*/ value)
            {
                /*int*/ let i;
                for(i = 0; i < this._totalItems; i++)
                {
                    if ($.$spc.System.Array.$ReadT1.call(this._values, i) === value)
                    {
                        break;
                    }
                }
                if (i === this._totalItems)
                {
                    return false;
                }
                $.$spc.System.Array.$WriteT1.call(this._values, BigInt(-1), i);
                return true;
            }
            /*void */ EnlargeArray()
            {
                /*int*/ let newLength = ((this._values.length * 2) | 0);
                if (newLength < 0)
                {
                    newLength = 2147483647/*int.MaxValue*/;
                }
                /*long[]*/ let temp = $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$spc.System.Int64), null, [newLength], null);
                $.$spc.System.Array.Copy(this._values, temp, this._count);
                this._values = temp;
            }
            static $h = 1175322;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":655361,"g":{"r":0,"d":0,"h":42950848282,"f":8},"n":"Count","d":1175322,"h":38655880986,"f":8},{"p":917505,"g":{"r":0,"d":0,"h":60130717466,"f":8},"n":"Current","d":1175322,"h":55835750170,"f":8}],"m":[{"r":65537,"p":[{"n":"value","p":917505}],"n":"Add","d":1175322,"h":34360913690,"f":8},{"r":65537,"n":"StartEnumeration","d":1175322,"h":47245815578,"f":8},{"r":262145,"n":"MoveNext","d":1175322,"h":51540782874,"f":8},{"r":262145,"p":[{"n":"value","p":917505}],"n":"RemoveElement","d":1175322,"h":64425684762,"f":8},{"r":65537,"n":"EnlargeArray","d":1175322,"h":68720652058,"f":2}],"l":[{"t":655361,"n":"InitialSize","d":1175322,"h":4296142618,"f":34},{"t":0,"n":"_values","d":1175322,"h":8591109914,"f":2},{"t":655361,"n":"_count","d":1175322,"h":12886077210,"f":2},{"t":655361,"n":"_totalItems","d":1175322,"h":17181044506,"f":2},{"t":655361,"n":"_currentItem","d":1175322,"h":21476011802,"f":2}],"c":[{"n":".ctor","o":"$ctor$1","d":1175322,"h":25770979098,"f":8},{"p":[{"n":"startingSize","p":655361}],"n":".ctor","o":"$ctor$2","d":1175322,"h":30065946394,"f":8}],"h":1175322}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.Runtime.Serialization.LongList`; }
        });
        
        $asm.$cls("$srsf.System.Runtime.Serialization.ObjectHolderList", ($self) => class ObjectHolderList extends $.$spc.System.Object
        {
            /*int*/ static DefaultInitialSize = 8;
            /*ObjectHolder[]*/ _values = null;
            /*int*/ _count = 0;
            $ctor$1()
            {
                this.$ctor$2(8/*DefaultInitialSize*/);
                {
                }
                return this;
            }
            $ctor$2(/*int*/ startingSize)
            {
                super.$ctor();
                {
                    $.$spc.System.Diagnostics.Debug.Assert$1(startingSize > 0 && startingSize < 4096, "startingSize>0 && startingSize<0x1000");
                    this._count = 0;
                    this._values = $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$srsf.System.Runtime.Serialization.ObjectHolder), null, [startingSize], null);
                }
                return this;
            }
            /*void */ Add(/*ObjectHolder*/ value)
            {
                if (this._count === this._values.length)
                {
                    this.EnlargeArray();
                }
                $.$spc.System.Array.$WriteT1.call(this._values, value, this._count++);
            }
            /*ObjectHolderListEnumerator */ GetFixupEnumerator()
            {
                return new $.$srsf.System.Runtime.Serialization.ObjectHolderListEnumerator().$ctor$1(this, true);
            }
            /*void */ EnlargeArray()
            {
                /*int*/ let newLength = ((this._values.length * 2) | 0);
                if (newLength < 0)
                {
                    newLength = 2147483647/*int.MaxValue*/;
                }
                /*ObjectHolder[]*/ let temp = $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$srsf.System.Runtime.Serialization.ObjectHolder), null, [newLength], null);
                $.$spc.System.Array.Copy(this._values, temp, this._count);
                this._values = temp;
            }
            /*int */ get Version()
            {
                return this._count;
            }
            /*int */ get Count()
            {
                return this._count;
            }
            static $h = 1371930;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":655361,"g":{"r":0,"d":0,"h":42951044890,"f":8},"n":"Version","d":1371930,"h":38656077594,"f":8},{"p":655361,"g":{"r":0,"d":0,"h":51540979482,"f":8},"n":"Count","d":1371930,"h":47246012186,"f":8}],"m":[{"r":65537,"p":[{"n":"value","p":1306394}],"n":"Add","d":1371930,"h":25771175706,"f":8},{"r":1437466,"n":"GetFixupEnumerator","d":1371930,"h":30066143002,"f":8},{"r":65537,"n":"EnlargeArray","d":1371930,"h":34361110298,"f":2}],"l":[{"t":655361,"n":"DefaultInitialSize","d":1371930,"h":4296339226,"f":40},{"t":0,"n":"_values","d":1371930,"h":8591306522,"f":8},{"t":655361,"n":"_count","d":1371930,"h":12886273818,"f":8}],"c":[{"n":".ctor","o":"$ctor$1","d":1371930,"h":17181241114,"f":8},{"p":[{"n":"startingSize","p":655361}],"n":".ctor","o":"$ctor$2","d":1371930,"h":21476208410,"f":8}],"h":1371930}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.Runtime.Serialization.ObjectHolderList`; }
        });
        
        $asm.$cls("$srsf.System.Runtime.Serialization.ObjectHolderListEnumerator", ($self) => class ObjectHolderListEnumerator extends $.$spc.System.Object
        {
            /*bool*/ _isFixupEnumerator = false;
            /*ObjectHolderList*/ _list = null;
            /*int*/ _startingVersion = 0;
            /*int*/ _currPos = 0;
            $ctor$1(/*ObjectHolderList*/ list, /*bool*/ isFixupEnumerator)
            {
                super.$ctor();
                {
                    $.$spc.System.Diagnostics.Debug.Assert$1(list !== null, "[ObjectHolderListEnumerator.ctor]list!=null");
                    this._list = list;
                    this._startingVersion = this._list.Version;
                    this._currPos = -1;
                    this._isFixupEnumerator = isFixupEnumerator;
                }
                return this;
            }
            /*bool */ MoveNext()
            {
                $.$spc.System.Diagnostics.Debug.Assert$1(this._startingVersion === this._list.Version, "[ObjectHolderListEnumerator.MoveNext]m_startingVersion==m_list.Version");
                if (this._isFixupEnumerator)
                {
                    while(++this._currPos < this._list.Count && $.$spc.System.Array.$ReadT1.call(this._list._values, this._currPos).CompletelyFixed)
                    {
                    }
                    return this._currPos !== this._list.Count;
                }
                else 
                {
                    this._currPos++;
                    return this._currPos !== this._list.Count;
                }
            }
            /*ObjectHolder */ get Current()
            {
                $.$spc.System.Diagnostics.Debug.Assert$1(this._currPos !== -1, "[ObjectHolderListEnumerator.Current]m_currPos!=-1");
                $.$spc.System.Diagnostics.Debug.Assert$1(this._currPos < this._list.Count, "[ObjectHolderListEnumerator.Current]m_currPos<m_list.Count");
                $.$spc.System.Diagnostics.Debug.Assert$1(this._startingVersion === this._list.Version, "[ObjectHolderListEnumerator.Current]m_startingVersion==m_list.Version");
                return $.$spc.System.Array.$ReadT1.call(this._list._values, this._currPos);
            }
            static $h = 1437466;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":1306394,"g":{"r":0,"d":0,"h":34361175834,"f":8},"n":"Current","d":1437466,"h":30066208538,"f":8}],"m":[{"r":262145,"n":"MoveNext","d":1437466,"h":25771241242,"f":8}],"l":[{"t":262145,"n":"_isFixupEnumerator","d":1437466,"h":4296404762,"f":2},{"t":1371930,"n":"_list","d":1437466,"h":8591372058,"f":2},{"t":655361,"n":"_startingVersion","d":1437466,"h":12886339354,"f":2},{"t":655361,"n":"_currPos","d":1437466,"h":17181306650,"f":2}],"c":[{"p":[{"n":"list","p":1371930},{"n":"isFixupEnumerator","p":262145}],"n":".ctor","o":"$ctor$1","d":1437466,"h":21476273946,"f":8}],"h":1437466}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.Runtime.Serialization.ObjectHolderListEnumerator`; }
        });
        
        $asm.$cls("$srsf.System.Runtime.Serialization.TypeLoadExceptionHolder", ($self) => class TypeLoadExceptionHolder extends $.$spc.System.Object
        {
            $ctor$1(/*string?*/ typeName)
            {
                super.$ctor();
                {
                    this.TypeName = typeName;
                }
                return this;
            }
            /*string?*/ TypeName = null;
            static $h = 2354970;
            static $f = 0b10010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":1310721,"g":{"r":0,"d":0,"h":17182224154,"f":8},"n":"TypeName","d":2354970,"h":12887256858,"f":8}],"c":[{"p":[{"n":"typeName","p":1310721}],"n":".ctor","o":"$ctor$1","d":2354970,"h":4297322266,"f":8}],"h":2354970}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.Runtime.Serialization.TypeLoadExceptionHolder`; }
        });
        
        $asm.$cls("$srsf.System.Runtime.Serialization.SerializationInfoExtensions", ($self) => class SerializationInfoExtensions
        {
            /*Action<SerializationInfo, string, object, Type>*/ static s_updateValue = null;
            static /*void */ UpdateValue(/*this SerializationInfo*/ si, /*string*/ name, /*object*/ value, /*Type*/ type)
            {
                return $.$srsf.System.Runtime.Serialization.SerializationInfoExtensions.s_updateValue.Invoke(si, name, value, type);
            }
            //Static Initializer
            static $sinit()
            {
                {
                    this.s_updateValue = $.$spc.System.Runtime.Serialization.SerializationInfo.$type.GetMethod$2("UpdateValue", 16/*BindingFlags.Public*/ | 32/*BindingFlags.NonPublic*/ | 4/*BindingFlags.Instance*/).CreateDelegate$2($.$spc.System.Action$$$$$($.$spc.System.Runtime.Serialization.SerializationInfo, $.$spc.System.String, $.$spc.System.Object, $.$spc.System.Type));
                }
            }
            static $h = 1961754;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"m":[{"r":65537,"p":[{"n":"si","p":113967105},{"n":"name","p":1310721},{"n":"value","p":131073},{"n":"type","p":142606337}],"n":"UpdateValue","d":1961754,"h":8591896346,"f":33}],"l":[{"t":$.$spc.System.Action$$$$$($.$spc.System.Runtime.Serialization.SerializationInfo, $.$spc.System.String, $.$spc.System.Object, $.$spc.System.Type).$h,"n":"s_updateValue","d":1961754,"h":4296929050,"f":34}],"h":1961754}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.Runtime.Serialization.SerializationInfoExtensions`; }
        });
        
        $asm.$cls("$srsf.System.Runtime.Serialization.FormatterConverter", ($self) => class FormatterConverter extends $.$spc.System.Object
        {
            /*object */ Convert(/*object*/ value, /*Type*/ type)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(value, "value");
                return $.$spc.System.Convert.ChangeType$3(value, type, $.$spc.System.Globalization.CultureInfo.InvariantCulture);
            }
            /*object */ Convert$1(/*object*/ value, /*TypeCode*/ typeCode)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(value, "value");
                return $.$spc.System.Convert.ChangeType$1(value, typeCode, $.$spc.System.Globalization.CultureInfo.InvariantCulture);
            }
            /*bool */ ToBoolean(/*object*/ value)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(value, "value");
                return $.$spc.System.Convert.ToBoolean$1(value, $.$spc.System.Globalization.CultureInfo.InvariantCulture);
            }
            /*char */ ToChar(/*object*/ value)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(value, "value");
                return $.$spc.System.Convert.ToChar$1(value, $.$spc.System.Globalization.CultureInfo.InvariantCulture);
            }
            /*sbyte */ ToSByte(/*object*/ value)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(value, "value");
                return $.$spc.System.Convert.ToSByte$1(value, $.$spc.System.Globalization.CultureInfo.InvariantCulture);
            }
            /*byte */ ToByte(/*object*/ value)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(value, "value");
                return $.$spc.System.Convert.ToByte$1(value, $.$spc.System.Globalization.CultureInfo.InvariantCulture);
            }
            /*short */ ToInt16(/*object*/ value)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(value, "value");
                return $.$spc.System.Convert.ToInt16$1(value, $.$spc.System.Globalization.CultureInfo.InvariantCulture);
            }
            /*ushort */ ToUInt16(/*object*/ value)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(value, "value");
                return $.$spc.System.Convert.ToUInt16$1(value, $.$spc.System.Globalization.CultureInfo.InvariantCulture);
            }
            /*int */ ToInt32(/*object*/ value)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(value, "value");
                return $.$spc.System.Convert.ToInt32$1(value, $.$spc.System.Globalization.CultureInfo.InvariantCulture);
            }
            /*uint */ ToUInt32(/*object*/ value)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(value, "value");
                return $.$spc.System.Convert.ToUInt32$1(value, $.$spc.System.Globalization.CultureInfo.InvariantCulture);
            }
            /*long */ ToInt64(/*object*/ value)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(value, "value");
                return $.$spc.System.Convert.ToInt64$1(value, $.$spc.System.Globalization.CultureInfo.InvariantCulture);
            }
            /*ulong */ ToUInt64(/*object*/ value)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(value, "value");
                return $.$spc.System.Convert.ToUInt64$1(value, $.$spc.System.Globalization.CultureInfo.InvariantCulture);
            }
            /*float */ ToSingle(/*object*/ value)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(value, "value");
                return $.$spc.System.Convert.ToSingle$1(value, $.$spc.System.Globalization.CultureInfo.InvariantCulture);
            }
            /*double */ ToDouble(/*object*/ value)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(value, "value");
                return $.$spc.System.Convert.ToDouble$1(value, $.$spc.System.Globalization.CultureInfo.InvariantCulture);
            }
            /*decimal */ ToDecimal(/*object*/ value)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(value, "value");
                return $.$spc.System.Convert.ToDecimal$1(value, $.$spc.System.Globalization.CultureInfo.InvariantCulture);
            }
            /*DateTime */ ToDateTime(/*object*/ value)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(value, "value");
                return $.$spc.System.Convert.ToDateTime$2(value, $.$spc.System.Globalization.CultureInfo.InvariantCulture);
            }
            /*string? */ ToString$1(/*object*/ value)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(value, "value");
                return $.$spc.System.Convert.ToString$2(value, $.$spc.System.Globalization.CultureInfo.InvariantCulture);
            }
            //Generated interface implemetation for System.Runtime.Serialization.IFormatterConverter.Convert(object, System.Type)
            System$Runtime$Serialization$IFormatterConverter$Convert()
            {
                return this.Convert(...arguments);
            }
            //Generated interface implemetation for System.Runtime.Serialization.IFormatterConverter.Convert(object, System.TypeCode)
            System$Runtime$Serialization$IFormatterConverter$Convert$1()
            {
                return this.Convert$1(...arguments);
            }
            //Generated interface implemetation for System.Runtime.Serialization.IFormatterConverter.ToBoolean(object)
            System$Runtime$Serialization$IFormatterConverter$ToBoolean()
            {
                return this.ToBoolean(...arguments);
            }
            //Generated interface implemetation for System.Runtime.Serialization.IFormatterConverter.ToChar(object)
            System$Runtime$Serialization$IFormatterConverter$ToChar()
            {
                return this.ToChar(...arguments);
            }
            //Generated interface implemetation for System.Runtime.Serialization.IFormatterConverter.ToSByte(object)
            System$Runtime$Serialization$IFormatterConverter$ToSByte()
            {
                return this.ToSByte(...arguments);
            }
            //Generated interface implemetation for System.Runtime.Serialization.IFormatterConverter.ToByte(object)
            System$Runtime$Serialization$IFormatterConverter$ToByte()
            {
                return this.ToByte(...arguments);
            }
            //Generated interface implemetation for System.Runtime.Serialization.IFormatterConverter.ToInt16(object)
            System$Runtime$Serialization$IFormatterConverter$ToInt16()
            {
                return this.ToInt16(...arguments);
            }
            //Generated interface implemetation for System.Runtime.Serialization.IFormatterConverter.ToUInt16(object)
            System$Runtime$Serialization$IFormatterConverter$ToUInt16()
            {
                return this.ToUInt16(...arguments);
            }
            //Generated interface implemetation for System.Runtime.Serialization.IFormatterConverter.ToInt32(object)
            System$Runtime$Serialization$IFormatterConverter$ToInt32()
            {
                return this.ToInt32(...arguments);
            }
            //Generated interface implemetation for System.Runtime.Serialization.IFormatterConverter.ToUInt32(object)
            System$Runtime$Serialization$IFormatterConverter$ToUInt32()
            {
                return this.ToUInt32(...arguments);
            }
            //Generated interface implemetation for System.Runtime.Serialization.IFormatterConverter.ToInt64(object)
            System$Runtime$Serialization$IFormatterConverter$ToInt64()
            {
                return this.ToInt64(...arguments);
            }
            //Generated interface implemetation for System.Runtime.Serialization.IFormatterConverter.ToUInt64(object)
            System$Runtime$Serialization$IFormatterConverter$ToUInt64()
            {
                return this.ToUInt64(...arguments);
            }
            //Generated interface implemetation for System.Runtime.Serialization.IFormatterConverter.ToSingle(object)
            System$Runtime$Serialization$IFormatterConverter$ToSingle()
            {
                return this.ToSingle(...arguments);
            }
            //Generated interface implemetation for System.Runtime.Serialization.IFormatterConverter.ToDouble(object)
            System$Runtime$Serialization$IFormatterConverter$ToDouble()
            {
                return this.ToDouble(...arguments);
            }
            //Generated interface implemetation for System.Runtime.Serialization.IFormatterConverter.ToDecimal(object)
            System$Runtime$Serialization$IFormatterConverter$ToDecimal()
            {
                return this.ToDecimal(...arguments);
            }
            //Generated interface implemetation for System.Runtime.Serialization.IFormatterConverter.ToDateTime(object)
            System$Runtime$Serialization$IFormatterConverter$ToDateTime()
            {
                return this.ToDateTime(...arguments);
            }
            //Generated interface implemetation for System.Runtime.Serialization.IFormatterConverter.ToString(object)
            System$Runtime$Serialization$IFormatterConverter$ToString()
            {
                return this.ToString$1(...arguments);
            }
            //default reference type constructor overload
            $ctor$1()
            {
                super.$ctor();
                return this;
            }
            static $h = 519962;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"m":[{"r":131073,"p":[{"n":"value","p":131073},{"n":"type","p":142606337}],"n":"Convert","d":519962,"h":4295487258,"f":1},{"r":131073,"p":[{"n":"value","p":131073},{"n":"typeCode","p":142737409}],"n":"Convert","o":"@$1","d":519962,"h":8590454554,"f":1},{"r":262145,"p":[{"n":"value","p":131073}],"n":"ToBoolean","d":519962,"h":12885421850,"f":1},{"r":458753,"p":[{"n":"value","p":131073}],"n":"ToChar","d":519962,"h":17180389146,"f":1},{"r":327681,"p":[{"n":"value","p":131073}],"n":"ToSByte","d":519962,"h":21475356442,"f":1,"a":[{"t":23461889,"c":8613396481,"a":[{"v":false,"t":262145}]}]},{"r":393217,"p":[{"n":"value","p":131073}],"n":"ToByte","d":519962,"h":25770323738,"f":1},{"r":524289,"p":[{"n":"value","p":131073}],"n":"ToInt16","d":519962,"h":30065291034,"f":1},{"r":589825,"p":[{"n":"value","p":131073}],"n":"ToUInt16","d":519962,"h":34360258330,"f":1,"a":[{"t":23461889,"c":8613396481,"a":[{"v":false,"t":262145}]}]},{"r":655361,"p":[{"n":"value","p":131073}],"n":"ToInt32","d":519962,"h":38655225626,"f":1},{"r":720897,"p":[{"n":"value","p":131073}],"n":"ToUInt32","d":519962,"h":42950192922,"f":1,"a":[{"t":23461889,"c":8613396481,"a":[{"v":false,"t":262145}]}]},{"r":917505,"p":[{"n":"value","p":131073}],"n":"ToInt64","d":519962,"h":47245160218,"f":1},{"r":983041,"p":[{"n":"value","p":131073}],"n":"ToUInt64","d":519962,"h":51540127514,"f":1,"a":[{"t":23461889,"c":8613396481,"a":[{"v":false,"t":262145}]}]},{"r":1114113,"p":[{"n":"value","p":131073}],"n":"ToSingle","d":519962,"h":55835094810,"f":1},{"r":1179649,"p":[{"n":"value","p":131073}],"n":"ToDouble","d":519962,"h":60130062106,"f":1},{"r":35061761,"p":[{"n":"value","p":131073}],"n":"ToDecimal","d":519962,"h":64425029402,"f":1},{"r":34209793,"p":[{"n":"value","p":131073}],"n":"ToDateTime","d":519962,"h":68719996698,"f":1},{"r":1310721,"p":[{"n":"value","p":131073}],"n":"ToString","o":"@$1","d":519962,"h":73014963994,"f":1}],"c":[{"n":".ctor","o":"$ctor$1","d":519962,"h":77309931290,"f":1}],"i":[113180673],"h":519962,"a":[{"t":70909953,"c":8660844545,"a":[{"v":"Formatter-based serialization is obsolete and should not be used.","t":1310721}],"n":[{"n":"DiagnosticId","v":"SYSLIB0050","t":1310721},{"n":"UrlFormat","v":"https://aka.ms/dotnet-warnings/{0}","t":1310721}]}]}; }
            static get $b() { return $.$spc.System.Object; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.Runtime.Serialization.IFormatterConverter ]; }
            static get $fullName() { return `System.Runtime.Serialization.FormatterConverter`; }
        });
        
        $asm.$cls("$srsf.System.Runtime.Serialization.SurrogateSelector", ($self) => class SurrogateSelector extends $.$spc.System.Object
        {
            /*SurrogateHashtable*/ _surrogates = null;
            /*ISurrogateSelector?*/ _nextSelector = null;
            /*void */ AddSurrogate(/*Type*/ type, /*StreamingContext*/ context, /*ISerializationSurrogate*/ surrogate)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(type, "type");
                $.$spc.System.ArgumentNullException.ThrowIfNull(surrogate, "surrogate");
                /*var*/ let key = new $.$srsf.System.Runtime.Serialization.SurrogateKey().$ctor$1(type, context);
                this._surrogates.Add(key, surrogate);
            }
            static /*bool */ HasCycle(/*ISurrogateSelector*/ selector)
            {
                $.$spc.System.Diagnostics.Debug.Assert$1(selector !== null, "[HasCycle]selector!=null");
                /*ISurrogateSelector?*/ let head = selector, tail = selector;
                while(head !== null)
                {
                    head = head.System$Runtime$Serialization$ISurrogateSelector$GetNextSelector();
                    if (head === null)
                    {
                        return true;
                    }
                    if (head === tail)
                    {
                        return false;
                    }
                    head = head.System$Runtime$Serialization$ISurrogateSelector$GetNextSelector();
                    tail = tail.System$Runtime$Serialization$ISurrogateSelector$GetNextSelector();
                    if (head === tail)
                    {
                        return false;
                    }
                }
                return true;
            }
            /*void */ ChainSelector(/*ISurrogateSelector*/ selector)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(selector, "selector");
                if (selector === this)
                {
                    throw new $.$spc.System.Runtime.Serialization.SerializationException().$ctor$10($.$srsf.System.SR.Serialization_SurrogateCycle);
                }
                if (!$.$srsf.System.Runtime.Serialization.SurrogateSelector.HasCycle(selector))
                {
                    throw new $.$spc.System.ArgumentException().$ctor$13($.$srsf.System.SR.Serialization_SurrogateCycleInArgument, "selector");
                }
                /*ISurrogateSelector?*/ let tempCurr = selector.System$Runtime$Serialization$ISurrogateSelector$GetNextSelector();
                /*ISurrogateSelector*/ let tempEnd = selector;
                while(tempCurr !== null && tempCurr !== this)
                {
                    tempEnd = tempCurr;
                    tempCurr = tempCurr.System$Runtime$Serialization$ISurrogateSelector$GetNextSelector();
                }
                if (tempCurr === this)
                {
                    throw new $.$spc.System.ArgumentException().$ctor$13($.$srsf.System.SR.Serialization_SurrogateCycle, "selector");
                }
                tempCurr = selector;
                /*ISurrogateSelector?*/ let tempPrev = selector;
                while(tempCurr !== null)
                {
                    if (tempCurr === tempEnd)
                    {
                        tempCurr = this.GetNextSelector();
                    }
                    else 
                    {
                        tempCurr = tempCurr.System$Runtime$Serialization$ISurrogateSelector$GetNextSelector();
                    }
                    if (tempCurr === null)
                    {
                        break;
                    }
                    if (tempCurr === tempPrev)
                    {
                        throw new $.$spc.System.ArgumentException().$ctor$13($.$srsf.System.SR.Serialization_SurrogateCycle, "selector");
                    }
                    if (tempCurr === tempEnd)
                    {
                        tempCurr = this.GetNextSelector();
                    }
                    else 
                    {
                        tempCurr = tempCurr.System$Runtime$Serialization$ISurrogateSelector$GetNextSelector();
                    }
                    if (tempPrev === tempEnd)
                    {
                        tempPrev = this.GetNextSelector();
                    }
                    else 
                    {
                        $.$spc.System.Diagnostics.Debug.Assert$1(tempPrev !== null, "tempPrev != null");
                        tempPrev = tempPrev.System$Runtime$Serialization$ISurrogateSelector$GetNextSelector();
                    }
                    if (tempCurr === tempPrev)
                    {
                        throw new $.$spc.System.ArgumentException().$ctor$13($.$srsf.System.SR.Serialization_SurrogateCycle, "selector");
                    }
                }
                /*ISurrogateSelector?*/ let temp = this._nextSelector;
                this._nextSelector = selector;
                if (temp !== null)
                {
                    tempEnd.System$Runtime$Serialization$ISurrogateSelector$ChainSelector(temp);
                }
            }
            /*ISurrogateSelector? */ GetNextSelector()
            {
                return this._nextSelector;
            }
            /*ISerializationSurrogate? */ GetSurrogate(/*Type*/ type, /*StreamingContext*/ context, /*out ISurrogateSelector*/ selector)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(type, "type");
                selector.$v = this;
                /*SurrogateKey*/ let key = new $.$srsf.System.Runtime.Serialization.SurrogateKey().$ctor$1(type, context);
                /*ISerializationSurrogate?*/ let temp = $.$cast(this._surrogates.get_Item(key), $.$srsf.System.Runtime.Serialization.ISerializationSurrogate);
                if (temp !== null)
                {
                    return temp;
                }
                if (this._nextSelector !== null)
                {
                    return this._nextSelector.System$Runtime$Serialization$ISurrogateSelector$GetSurrogate(type, context, selector);
                }
                return null;
            }
            /*void */ RemoveSurrogate(/*Type*/ type, /*StreamingContext*/ context)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(type, "type");
                /*SurrogateKey*/ let key = new $.$srsf.System.Runtime.Serialization.SurrogateKey().$ctor$1(type, context);
                this._surrogates.Remove(key);
            }
            //Generated interface implemetation for System.Runtime.Serialization.ISurrogateSelector.ChainSelector(System.Runtime.Serialization.ISurrogateSelector)
            System$Runtime$Serialization$ISurrogateSelector$ChainSelector()
            {
                return this.ChainSelector(...arguments);
            }
            //Generated interface implemetation for System.Runtime.Serialization.ISurrogateSelector.GetSurrogate(System.Type, System.Runtime.Serialization.StreamingContext, out System.Runtime.Serialization.ISurrogateSelector)
            System$Runtime$Serialization$ISurrogateSelector$GetSurrogate()
            {
                return this.GetSurrogate(...arguments);
            }
            //Generated interface implemetation for System.Runtime.Serialization.ISurrogateSelector.GetNextSelector()
            System$Runtime$Serialization$ISurrogateSelector$GetNextSelector()
            {
                return this.GetNextSelector(...arguments);
            }
            //default reference type constructor overload
            $ctor$1()
            {
                super.$ctor();
                return this;
            }
            //default member initializer
            constructor()
            {
                super();
                this._surrogates = new $.$srsf.System.Runtime.Serialization.SurrogateHashtable().$ctor$1(32);
            }
            static $h = 2289434;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"m":[{"r":65537,"p":[{"n":"type","p":142606337},{"n":"context","p":114098177},{"n":"surrogate","p":1044250}],"n":"AddSurrogate","d":2289434,"h":12887191322,"f":129},{"r":262145,"p":[{"n":"selector","p":1109786}],"n":"HasCycle","d":2289434,"h":17182158618,"f":34},{"r":65537,"p":[{"n":"selector","p":1109786}],"n":"ChainSelector","d":2289434,"h":21477125914,"f":129},{"r":1109786,"n":"GetNextSelector","d":2289434,"h":25772093210,"f":129},{"r":1044250,"p":[{"n":"type","p":142606337},{"n":"context","p":114098177},{"n":"selector","p":1109786,"f":2}],"n":"GetSurrogate","d":2289434,"h":30067060506,"f":129},{"r":65537,"p":[{"n":"type","p":142606337},{"n":"context","p":114098177}],"n":"RemoveSurrogate","d":2289434,"h":34362027802,"f":129}],"l":[{"t":2158362,"n":"_surrogates","d":2289434,"h":4297256730,"f":8},{"t":1109786,"n":"_nextSelector","d":2289434,"h":8592224026,"f":8}],"c":[{"n":".ctor","o":"$ctor$1","d":2289434,"h":38656995098,"f":1}],"i":[1109786],"h":2289434,"a":[{"t":70909953,"c":8660844545,"a":[{"v":"Formatter-based serialization is obsolete and should not be used.","t":1310721}],"n":[{"n":"DiagnosticId","v":"SYSLIB0050","t":1310721},{"n":"UrlFormat","v":"https://aka.ms/dotnet-warnings/{0}","t":1310721}]}]}; }
            static get $b() { return $.$spc.System.Object; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$srsf.System.Runtime.Serialization.ISurrogateSelector ]; }
            static get $fullName() { return `System.Runtime.Serialization.SurrogateSelector`; }
        });
        
        $asm.$cls("$srsf.System.Runtime.Serialization.Formatters.Binary.BinaryFormatter", ($self) => class BinaryFormatter extends $.$spc.System.Object
        {
            /*ISurrogateSelector?*/ _surrogates = null;
            /*StreamingContext*/ _context;
            /*SerializationBinder?*/ _binder = null;
            /*FormatterTypeStyle*/ _typeFormat = 1;
            /*FormatterAssemblyStyle*/ _assemblyFormat = 0;
            /*TypeFilterLevel*/ _securityLevel = 3;
            /*FormatterTypeStyle */ get TypeFormat()
            {
                return this._typeFormat;
            }
            /*FormatterTypeStyle */ set TypeFormat(value)
            {
                this._typeFormat = value;
            }
            /*FormatterAssemblyStyle */ get AssemblyFormat()
            {
                return this._assemblyFormat;
            }
            /*FormatterAssemblyStyle */ set AssemblyFormat(value)
            {
                this._assemblyFormat = value;
            }
            /*TypeFilterLevel */ get FilterLevel()
            {
                return this._securityLevel;
            }
            /*TypeFilterLevel */ set FilterLevel(value)
            {
                this._securityLevel = value;
            }
            /*ISurrogateSelector? */ get SurrogateSelector()
            {
                return this._surrogates;
            }
            /*ISurrogateSelector? */ set SurrogateSelector(value)
            {
                this._surrogates = value;
            }
            /*SerializationBinder? */ get Binder()
            {
                return this._binder;
            }
            /*SerializationBinder? */ set Binder(value)
            {
                this._binder = value;
            }
            /*StreamingContext */ get Context()
            {
                return this._context;
            }
            /*StreamingContext */ set Context(value)
            {
                this._context = value;
            }
            $ctor$1()
            {
                this.$ctor$2(null, new $.$spc.System.Runtime.Serialization.StreamingContext().$ctor$2(255/*StreamingContextStates.All*/));
                {
                }
                return this;
            }
            $ctor$2(/*ISurrogateSelector?*/ selector, /*StreamingContext*/ context)
            {
                super.$ctor();
                {
                    this._surrogates = selector;
                    this._context = context;
                }
                return this;
            }
            /*object */ Deserialize(/*Stream*/ serializationStream)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$14($.$srsf.System.SR.BinaryFormatter_Removed);
            }
            /*void */ Serialize(/*Stream*/ serializationStream, /*object*/ graph)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$14($.$srsf.System.SR.BinaryFormatter_Removed);
            }
            //Generated interface implemetation for System.Runtime.Serialization.IFormatter.Deserialize(System.IO.Stream)
            System$Runtime$Serialization$IFormatter$Deserialize()
            {
                return this.Deserialize(...arguments);
            }
            //Generated interface implemetation for System.Runtime.Serialization.IFormatter.Serialize(System.IO.Stream, object)
            System$Runtime$Serialization$IFormatter$Serialize()
            {
                return this.Serialize(...arguments);
            }
            //Generated interface implemetation for System.Runtime.Serialization.IFormatter.SurrogateSelector.get
            get System$Runtime$Serialization$IFormatter$SurrogateSelector()
            {
                return this.SurrogateSelector;
            }
            //Generated interface implemetation for System.Runtime.Serialization.IFormatter.SurrogateSelector.set
            set System$Runtime$Serialization$IFormatter$SurrogateSelector(value)
            {
                this.SurrogateSelector = value;
            }
            //Generated interface implemetation for System.Runtime.Serialization.IFormatter.Binder.get
            get System$Runtime$Serialization$IFormatter$Binder()
            {
                return this.Binder;
            }
            //Generated interface implemetation for System.Runtime.Serialization.IFormatter.Binder.set
            set System$Runtime$Serialization$IFormatter$Binder(value)
            {
                this.Binder = value;
            }
            //Generated interface implemetation for System.Runtime.Serialization.IFormatter.Context.get
            get System$Runtime$Serialization$IFormatter$Context()
            {
                return this.Context;
            }
            //Generated interface implemetation for System.Runtime.Serialization.IFormatter.Context.set
            set System$Runtime$Serialization$IFormatter$Context(value)
            {
                this.Context = value;
            }
            //default member initializer
            constructor()
            {
                super();
                this._context = $.$default($.$spc.System.Runtime.Serialization.StreamingContext);
            }
            static $h = 585498;
            static $f = 0b10010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":716570,"g":{"r":0,"d":0,"h":34360323866,"f":1},"s":{"r":0,"d":0,"h":38655291162,"f":1},"n":"TypeFormat","d":585498,"h":30065356570,"f":1},{"p":651034,"g":{"r":0,"d":0,"h":47245225754,"f":1},"s":{"r":0,"d":0,"h":51540193050,"f":1},"n":"AssemblyFormat","d":585498,"h":42950258458,"f":1},{"p":847642,"g":{"r":0,"d":0,"h":60130127642,"f":1},"s":{"r":0,"d":0,"h":64425094938,"f":1},"n":"FilterLevel","d":585498,"h":55835160346,"f":1},{"p":1109786,"g":{"r":0,"d":0,"h":73015029530,"f":1},"s":{"r":0,"d":0,"h":77309996826,"f":1},"n":"SurrogateSelector","d":585498,"h":68720062234,"f":1},{"p":1634074,"g":{"r":0,"d":0,"h":85899931418,"f":1},"s":{"r":0,"d":0,"h":90194898714,"f":1},"n":"Binder","d":585498,"h":81604964122,"f":1},{"p":114098177,"g":{"r":0,"d":0,"h":98784833306,"f":1},"s":{"r":0,"d":0,"h":103079800602,"f":1},"n":"Context","d":585498,"h":94489866010,"f":1}],"m":[{"r":131073,"p":[{"n":"serializationStream","p":62193665}],"n":"Deserialize","d":585498,"h":115964702490,"f":1},{"r":65537,"p":[{"n":"serializationStream","p":62193665},{"n":"graph","p":131073}],"n":"Serialize","d":585498,"h":120259669786,"f":1}],"l":[{"t":1109786,"n":"_surrogates","d":585498,"h":4295552794,"f":8},{"t":114098177,"n":"_context","d":585498,"h":8590520090,"f":8},{"t":1634074,"n":"_binder","d":585498,"h":12885487386,"f":8},{"t":716570,"n":"_typeFormat","d":585498,"h":17180454682,"f":8},{"t":651034,"n":"_assemblyFormat","d":585498,"h":21475421978,"f":8},{"t":847642,"n":"_securityLevel","d":585498,"h":25770389274,"f":8}],"c":[{"n":".ctor","o":"$ctor$1","d":585498,"h":107374767898,"f":1},{"p":[{"n":"selector","p":1109786},{"n":"context","p":114098177}],"n":".ctor","o":"$ctor$2","d":585498,"h":111669735194,"f":1}],"i":[978714],"h":585498,"a":[{"t":70909953,"c":8660844545,"a":[{"v":"BinaryFormatter serialization is obsolete and should not be used. See https://aka.ms/binaryformatter for more information.","t":1310721}],"n":[{"n":"DiagnosticId","v":"SYSLIB0011","t":1310721},{"n":"UrlFormat","v":"https://aka.ms/dotnet-warnings/{0}","t":1310721}]}]}; }
            static get $b() { return $.$spc.System.Object; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$srsf.System.Runtime.Serialization.IFormatter ]; }
            static get $fullName() { return `System.Runtime.Serialization.Formatters.Binary.BinaryFormatter`; }
        });
        
        $asm.$cls("$srsf.System.Runtime.Serialization.SurrogateForCyclicalReference", ($self) => class SurrogateForCyclicalReference extends $.$spc.System.Object
        {
            /*ISerializationSurrogate*/ _innerSurrogate = null;
            $ctor$1(/*ISerializationSurrogate*/ innerSurrogate)
            {
                super.$ctor();
                {
                    $.$spc.System.Diagnostics.Debug.Assert$1(innerSurrogate !== null, "innerSurrogate != null");
                    this._innerSurrogate = innerSurrogate;
                }
                return this;
            }
            /*void */ GetObjectData(/*object*/ obj, /*SerializationInfo*/ info, /*StreamingContext*/ context)
            {
                this._innerSurrogate.System$Runtime$Serialization$ISerializationSurrogate$GetObjectData(obj, info, context);
            }
            /*object */ SetObjectData(/*object*/ obj, /*SerializationInfo*/ info, /*StreamingContext*/ context, /*ISurrogateSelector?*/ selector)
            {
                return this._innerSurrogate.System$Runtime$Serialization$ISerializationSurrogate$SetObjectData(obj, info, context, selector);
            }
            //Generated interface implemetation for System.Runtime.Serialization.ISerializationSurrogate.GetObjectData(object, System.Runtime.Serialization.SerializationInfo, System.Runtime.Serialization.StreamingContext)
            System$Runtime$Serialization$ISerializationSurrogate$GetObjectData()
            {
                return this.GetObjectData(...arguments);
            }
            //Generated interface implemetation for System.Runtime.Serialization.ISerializationSurrogate.SetObjectData(object, System.Runtime.Serialization.SerializationInfo, System.Runtime.Serialization.StreamingContext, System.Runtime.Serialization.ISurrogateSelector?)
            System$Runtime$Serialization$ISerializationSurrogate$SetObjectData()
            {
                return this.SetObjectData(...arguments);
            }
            static $h = 2092826;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"m":[{"r":65537,"p":[{"n":"obj","p":131073},{"n":"info","p":113967105},{"n":"context","p":114098177}],"n":"GetObjectData","d":2092826,"h":12886994714,"f":1},{"r":131073,"p":[{"n":"obj","p":131073},{"n":"info","p":113967105},{"n":"context","p":114098177},{"n":"selector","p":1109786}],"n":"SetObjectData","d":2092826,"h":17181962010,"f":1}],"l":[{"t":1044250,"n":"_innerSurrogate","d":2092826,"h":4297060122,"f":2}],"c":[{"p":[{"n":"innerSurrogate","p":1044250}],"n":".ctor","o":"$ctor$1","d":2092826,"h":8592027418,"f":8}],"i":[1044250],"h":2092826}; }
            static get $b() { return $.$spc.System.Object; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$srsf.System.Runtime.Serialization.ISerializationSurrogate ]; }
            static get $fullName() { return `System.Runtime.Serialization.SurrogateForCyclicalReference`; }
        });
        
        $asm.$cls("$srsf.System.Runtime.Serialization.SerializationFieldInfo", ($self) => class SerializationFieldInfo extends $.$spc.System.Reflection.FieldInfo
        {
            /*FieldInfo*/ m_field = null;
            /*string*/ m_serializationName = null;
            $ctor$4(/*FieldInfo*/ field, /*string*/ namePrefix)
            {
                super.$ctor$3();
                {
                    $.$spc.System.Diagnostics.Debug.Assert$1($.$spc.System.Reflection.FieldInfo.op_Inequality$1(field, null), "field != null");
                    $.$spc.System.Diagnostics.Debug.Assert$1($.$spc.System.String.op_Inequality(namePrefix, null), "namePrefix != null");
                    this.m_field = field;
                    this.m_serializationName = namePrefix + "+" + this.m_field.Name;
                }
                return this;
            }
            /*FieldInfo */ get FieldInfo()
            {
                return this.m_field;
            }
            /*string */ get Name()
            {
                return this.m_serializationName;
            }
            /*Module */ get Module()
            {
                return this.m_field.Module;
            }
            /*int */ get MetadataToken()
            {
                return this.m_field.MetadataToken;
            }
            /*Type? */ get DeclaringType()
            {
                return this.m_field.DeclaringType;
            }
            /*Type? */ get ReflectedType()
            {
                return this.m_field.ReflectedType;
            }
            /*object[] */ GetCustomAttributes(/*bool*/ inherit)
            {
                return this.m_field.GetCustomAttributes(inherit);
            }
            /*object[] */ GetCustomAttributes$1(/*Type*/ attributeType, /*bool*/ inherit)
            {
                return this.m_field.GetCustomAttributes$1(attributeType, inherit);
            }
            /*bool */ IsDefined(/*Type*/ attributeType, /*bool*/ inherit)
            {
                return this.m_field.IsDefined(attributeType, inherit);
            }
            /*Type */ get FieldType()
            {
                return this.m_field.FieldType;
            }
            /*object? */ GetValue(/*object?*/ obj)
            {
                return this.m_field.GetValue(obj);
            }
            /*void */ SetValue$1(/*object?*/ obj, /*object?*/ value, /*BindingFlags*/ invokeAttr, /*Binder?*/ binder, /*CultureInfo?*/ culture)
            {
                return this.m_field.SetValue$1(obj, value, invokeAttr, binder, culture);
            }
            /*RuntimeFieldHandle */ get FieldHandle()
            {
                return this.m_field.FieldHandle;
            }
            /*FieldAttributes */ get Attributes()
            {
                return this.m_field.Attributes;
            }
            static $h = 1896218;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":76677121,"p":[{"p":76677121,"g":{"r":0,"d":0,"h":21476732698,"f":8},"n":"FieldInfo","d":1896218,"h":17181765402,"f":8},{"p":1310721,"g":{"r":0,"d":0,"h":30066667290,"f":32769},"n":"Name","d":1896218,"h":25771699994,"f":32769},{"p":80216065,"g":{"r":0,"d":0,"h":38656601882,"f":32769},"n":"Module","d":1896218,"h":34361634586,"f":32769},{"p":655361,"g":{"r":0,"d":0,"h":47246536474,"f":32769},"n":"MetadataToken","d":1896218,"h":42951569178,"f":32769},{"p":142606337,"g":{"r":0,"d":0,"h":55836471066,"f":32769},"n":"DeclaringType","d":1896218,"h":51541503770,"f":32769},{"p":142606337,"g":{"r":0,"d":0,"h":64426405658,"f":32769},"n":"ReflectedType","d":1896218,"h":60131438362,"f":32769},{"p":142606337,"g":{"r":0,"d":0,"h":85901242138,"f":32769},"n":"FieldType","d":1896218,"h":81606274842,"f":32769},{"p":115539969,"g":{"r":0,"d":0,"h":103081111322,"f":32769},"n":"FieldHandle","d":1896218,"h":98786144026,"f":32769},{"p":76611585,"g":{"r":0,"d":0,"h":111671045914,"f":32769},"n":"Attributes","d":1896218,"h":107376078618,"f":32769}],"m":[{"r":0,"p":[{"n":"inherit","p":262145}],"n":"GetCustomAttributes","d":1896218,"h":68721372954,"f":32769},{"r":0,"p":[{"n":"attributeType","p":142606337},{"n":"inherit","p":262145}],"n":"GetCustomAttributes","o":"@$1","d":1896218,"h":73016340250,"f":32769},{"r":262145,"p":[{"n":"attributeType","p":142606337},{"n":"inherit","p":262145}],"n":"IsDefined","d":1896218,"h":77311307546,"f":32769},{"r":131073,"p":[{"n":"obj","p":131073}],"n":"GetValue","d":1896218,"h":90196209434,"f":32769},{"r":65537,"p":[{"n":"obj","p":131073},{"n":"value","p":131073},{"n":"invokeAttr","p":75497473},{"n":"binder","p":75431937},{"n":"culture","p":51183617}],"n":"SetValue","o":"@$1","d":1896218,"h":94491176730,"f":32769}],"l":[{"t":76677121,"n":"m_field","d":1896218,"h":4296863514,"f":2},{"t":1310721,"n":"m_serializationName","d":1896218,"h":8591830810,"f":2}],"c":[{"p":[{"n":"field","p":76677121},{"n":"namePrefix","p":1310721}],"n":".ctor","o":"$ctor$4","d":1896218,"h":12886798106,"f":8}],"i":[76939265],"h":1896218}; }
            static get $b() { return $.$spc.System.Reflection.FieldInfo; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.Reflection.ICustomAttributeProvider ]; }
            static get $fullName() { return `System.Runtime.Serialization.SerializationFieldInfo`; }
        });
        
        $asm.$cls("$srsf.System.Runtime.Serialization.DeserializationEventHandler", ($self) => class DeserializationEventHandler extends $.$spc.System.MulticastDelegate
        {
            $ctor(/*object*/ target, fn, anmodel)
            {
                this.$target = target;
                this.$nativeFunction = fn;
                if (anmodel) this.$nfmodel = anmodel;
                if (typeof(target) === 'object') this._target = target;
                return this;
            }
            /*void*/ Invoke(/*$.$spc.System.Nullable$$*/ sender)
            {
                return this.$nativeFunction.call(this.$target, sender);
            }
            static $h = 257818;
            static $f = 0b10000000;
            static $k = 5;
            static $$md;
            static get $md() { return this.$$md ??= {"b":66191361,"m":[{"r":65537,"p":[{"n":"sender","p":131073}],"n":"Invoke","d":257818,"h":8590192410,"f":129},{"r":57016321,"p":[{"n":"sender","p":131073},{"n":"callback","p":14483457},{"n":"object","p":131073}],"n":"BeginInvoke","d":257818,"h":12885159706,"f":129},{"r":65537,"p":[{"n":"result","p":57016321}],"n":"EndInvoke","d":257818,"h":17180127002,"f":129}],"c":[{"p":[{"n":"object","p":131073},{"n":"method","p":786433}],"n":".ctor","o":"$ctor$5","d":257818,"h":4295225114,"f":1}],"i":[57212929,113377281],"h":257818}; }
            static get $b() { return $.$spc.System.MulticastDelegate; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.ICloneable, $.$spc.System.Runtime.Serialization.ISerializable ]; }
            static get $fullName() { return `System.Runtime.Serialization.DeserializationEventHandler`; }
        });
        
        $asm.$cls("$srsf.System.Runtime.Serialization.SerializationEventHandler", ($self) => class SerializationEventHandler extends $.$spc.System.MulticastDelegate
        {
            $ctor(/*object*/ target, fn, anmodel)
            {
                this.$target = target;
                this.$nativeFunction = fn;
                if (anmodel) this.$nfmodel = anmodel;
                if (typeof(target) === 'object') this._target = target;
                return this;
            }
            /*void*/ Invoke(/**/ context)
            {
                return this.$nativeFunction.call(this.$target, context);
            }
            static $h = 1699610;
            static $f = 0b10000001;
            static $k = 5;
            static $$md;
            static get $md() { return this.$$md ??= {"b":66191361,"m":[{"r":65537,"p":[{"n":"context","p":114098177}],"n":"Invoke","d":1699610,"h":8591634202,"f":129},{"r":57016321,"p":[{"n":"context","p":114098177},{"n":"callback","p":14483457},{"n":"object","p":131073}],"n":"BeginInvoke","d":1699610,"h":12886601498,"f":129},{"r":65537,"p":[{"n":"result","p":57016321}],"n":"EndInvoke","d":1699610,"h":17181568794,"f":129}],"c":[{"p":[{"n":"object","p":131073},{"n":"method","p":786433}],"n":".ctor","o":"$ctor$5","d":1699610,"h":4296666906,"f":1}],"i":[57212929,113377281],"h":1699610}; }
            static get $b() { return $.$spc.System.MulticastDelegate; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.ICloneable, $.$spc.System.Runtime.Serialization.ISerializable ]; }
            static get $fullName() { return `System.Runtime.Serialization.SerializationEventHandler`; }
        });
        
        $asm.$str("$srsf.System.Runtime.Serialization.Formatters.FormatterTypeStyle", ($self) => class FormatterTypeStyle extends $.$spc.System.Enum
        {
            static TypesWhenNeeded = 0;
            static TypesAlways = 1;
            static XsdString = 2;
            static $map;
            static get Map()
            {
                return this.$map ??= 
                {
                    "TypesWhenNeeded": 0n,
                    "TypesAlways": 1n,
                    "XsdString": 2n
                };
            }
            static $h = 716570;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static get $eut() { return $.$spc.System.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {"b":1048577,"u":655361,"l":[{"t":716570,"n":"TypesWhenNeeded","d":716570,"h":4295683866,"f":33},{"t":716570,"n":"TypesAlways","d":716570,"h":8590651162,"f":33},{"t":716570,"n":"XsdString","d":716570,"h":12885618458,"f":33}],"c":[{"n":".ctor","o":"$ctor$3","d":716570,"h":17180585754,"f":1}],"i":[57278465,63832065,57737217,57409537],"h":716570,"a":[{"t":70909953,"c":8660844545,"a":[{"v":"Formatter-based serialization is obsolete and should not be used.","t":1310721}],"n":[{"n":"DiagnosticId","v":"SYSLIB0050","t":1310721},{"n":"UrlFormat","v":"https://aka.ms/dotnet-warnings/{0}","t":1310721}]}]}; }
            static get $b() { return $.$spc.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IComparable, $.$spc.System.ISpanFormattable, $.$spc.System.IFormattable, $.$spc.System.IConvertible ]; }
            static get $fullName() { return `System.Runtime.Serialization.Formatters.FormatterTypeStyle`; }
        });
        
        $asm.$str("$srsf.System.Runtime.Serialization.Formatters.FormatterAssemblyStyle", ($self) => class FormatterAssemblyStyle extends $.$spc.System.Enum
        {
            static Simple = 0;
            static Full = 1;
            static $map;
            static get Map()
            {
                return this.$map ??= 
                {
                    "Simple": 0n,
                    "Full": 1n
                };
            }
            static $h = 651034;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static get $eut() { return $.$spc.System.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {"b":1048577,"u":655361,"l":[{"t":651034,"n":"Simple","d":651034,"h":4295618330,"f":33},{"t":651034,"n":"Full","d":651034,"h":8590585626,"f":33}],"c":[{"n":".ctor","o":"$ctor$3","d":651034,"h":12885552922,"f":1}],"i":[57278465,63832065,57737217,57409537],"h":651034,"a":[{"t":70909953,"c":8660844545,"a":[{"v":"Formatter-based serialization is obsolete and should not be used.","t":1310721}],"n":[{"n":"DiagnosticId","v":"SYSLIB0050","t":1310721},{"n":"UrlFormat","v":"https://aka.ms/dotnet-warnings/{0}","t":1310721}]}]}; }
            static get $b() { return $.$spc.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IComparable, $.$spc.System.ISpanFormattable, $.$spc.System.IFormattable, $.$spc.System.IConvertible ]; }
            static get $fullName() { return `System.Runtime.Serialization.Formatters.FormatterAssemblyStyle`; }
        });
        
        $asm.$str("$srsf.System.Runtime.Serialization.Formatters.TypeFilterLevel", ($self) => class TypeFilterLevel extends $.$spc.System.Enum
        {
            static Low = 2;
            static Full = 3;
            static $map;
            static get Map()
            {
                return this.$map ??= 
                {
                    "Low": 2n,
                    "Full": 3n
                };
            }
            static $h = 847642;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static get $eut() { return $.$spc.System.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {"b":1048577,"u":655361,"l":[{"t":847642,"n":"Low","d":847642,"h":4295814938,"f":33},{"t":847642,"n":"Full","d":847642,"h":8590782234,"f":33}],"c":[{"n":".ctor","o":"$ctor$3","d":847642,"h":12885749530,"f":1}],"i":[57278465,63832065,57737217,57409537],"h":847642,"a":[{"t":70909953,"c":8660844545,"a":[{"v":"Formatter-based serialization is obsolete and should not be used.","t":1310721}],"n":[{"n":"DiagnosticId","v":"SYSLIB0050","t":1310721},{"n":"UrlFormat","v":"https://aka.ms/dotnet-warnings/{0}","t":1310721}]}]}; }
            static get $b() { return $.$spc.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IComparable, $.$spc.System.ISpanFormattable, $.$spc.System.IFormattable, $.$spc.System.IConvertible ]; }
            static get $fullName() { return `System.Runtime.Serialization.Formatters.TypeFilterLevel`; }
        });
        
        $asm.$cls("$srsf.System.Runtime.Serialization.SurrogateHashtable", ($self) => class SurrogateHashtable extends $.$spc.System.Collections.Hashtable
        {
            $ctor$1(/*int*/ size)
            {
                super.$ctor$3(size);
                {
                }
                return this;
            }
            /*bool */ KeyEquals(/*object*/ key, /*object*/ item)
            {
                /*SurrogateKey*/ let givenValue = $.$cast(item, $.$srsf.System.Runtime.Serialization.SurrogateKey);
                /*SurrogateKey*/ let presentValue = $.$cast(key, $.$srsf.System.Runtime.Serialization.SurrogateKey);
                return $.$spc.System.Type.op_Equality$1(presentValue._type, givenValue._type) && (presentValue._context.State & givenValue._context.State) === givenValue._context.State && presentValue._context.Context === givenValue._context.Context;
            }
            static $h = 2158362;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":30998529,"m":[{"r":262145,"p":[{"n":"key","p":131073},{"n":"item","p":131073}],"n":"KeyEquals","d":2158362,"h":8592092954,"f":32772}],"c":[{"p":[{"n":"size","p":655361}],"n":".ctor","o":"$ctor$1","d":2158362,"h":4297125658,"f":8}],"i":[31522817,31391745,31653889,113377281,113115137,57212929],"h":2158362}; }
            static get $b() { return $.$spc.System.Collections.Hashtable; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.Collections.IDictionary, $.$spc.System.Collections.ICollection, $.$spc.System.Collections.IEnumerable, $.$spc.System.Runtime.Serialization.ISerializable, $.$spc.System.Runtime.Serialization.IDeserializationCallback, $.$spc.System.ICloneable ]; }
            static get $fullName() { return `System.Runtime.Serialization.SurrogateHashtable`; }
        });
	});
})(window, window.NetJs.$boot(), ...window.NetJs.$require("NetJs.System.Private.CoreLib", "NetJs.System.Collections", "NetJs.System.Diagnostics.Tracing", "NetJs.System.Threading", "NetJs.System.Collections.Concurrent", "NetJs.System.Memory", "NetJs.System.Private.Uri", "NetJs.System.Runtime", "NetJs.System.Collections.NonGeneric"))