
(function ($global, $, $spc, $sc, $sdt, $sm, $spu, $st, $sr, $scc, $scn) {
    "use strict";
    let _;
    
    
    
	$.$asm(
    "NetJs.System.Runtime.Serialization.Formatters", 
    {"h":42511,"f":"System.Runtime.Serialization.Formatters","v":"1.0.35.0","a":[{"t":96337921,"c":4391305217,"a":[{"v":66519041,"t":142606337}]},{"t":96337921,"c":4391305217,"a":[{"v":118226945,"t":142606337}]},{"t":96337921,"c":4391305217,"a":[{"v":113115137,"t":142606337}]},{"t":96337921,"c":4391305217,"a":[{"v":113180673,"t":142606337}]},{"t":96337921,"c":4391305217,"a":[{"v":113377281,"t":142606337}]},{"t":96337921,"c":4391305217,"a":[{"v":113836033,"t":142606337}]},{"t":96337921,"c":4391305217,"a":[{"v":113967105,"t":142606337}]},{"t":96337921,"c":4391305217,"a":[{"v":114032641,"t":142606337}]},{"t":115146753,"c":13000048641,"a":[{"v":".NETCoreApp,Version=v10.0","t":1310721}],"n":[{"n":"FrameworkDisplayName","v":".NET 10.0","t":1310721}]},{"t":73596929,"c":4368564225,"a":[{"v":"SIT","t":1310721}]},{"t":73662465,"c":4368629761,"a":[{"v":"Debug","t":1310721}]},{"t":74121217,"c":4369088513,"a":[{"v":"1.0.35.0","t":1310721}]},{"t":74252289,"c":4369219585,"a":[{"v":"1.0.35\u002B760b8187d87d291733fdcda9f4d484d24d61a938","t":1310721}]},{"t":75104257,"c":4370071553,"a":[{"v":"NetJs.System.Runtime.Serialization.Formatters","t":1310721}]},{"t":75235329,"c":4370202625,"a":[{"v":"NetJs.System.Runtime.Serialization.Formatters","t":1310721}]},{"t":75366401,"c":4370333697,"a":[{"v":"1.0.35.0","t":1310721}]},{"t":115212289,"c":4410179585,"a":[{"v":"browser1.0","t":1310721}]},{"t":114950145,"c":4409917441,"a":[{"v":"browser1.0","t":1310721}]}],"m":[]},
    function($asm)
	{
        
        
        $asm.$cls("$srsf.System.Runtime.Serialization.ISurrogateSelector", ($self) => class ISurrogateSelector
        {
            static $h = 1091087;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {"m":[{"r":65537,"p":[{"n":"selector","p":1091087}],"n":"ChainSelector","o":"System$Runtime$Serialization$ISurrogateSelector$ChainSelector","d":1091087,"h":4296058383,"f":257},{"r":1025551,"p":[{"n":"type","p":142606337},{"n":"context","p":114098177},{"n":"selector","p":1091087,"f":2}],"n":"GetSurrogate","o":"System$Runtime$Serialization$ISurrogateSelector$GetSurrogate","d":1091087,"h":8591025679,"f":257},{"r":1091087,"n":"GetNextSelector","o":"System$Runtime$Serialization$ISurrogateSelector$GetNextSelector","d":1091087,"h":12885992975,"f":257}],"h":1091087,"a":[{"t":70909953,"c":8660844545,"a":[{"v":"Formatter-based serialization is obsolete and should not be used.","t":1310721}],"n":[{"n":"DiagnosticId","v":"SYSLIB0050","t":1310721},{"n":"UrlFormat","v":"https://aka.ms/dotnet-warnings/{0}","t":1310721}]}]}; }
            static get $fullName() { return `System.Runtime.Serialization.ISurrogateSelector`; }
        });
        
        $asm.$cls("$srsf.System.Runtime.Serialization.IFormatter", ($self) => class IFormatter
        {
            /*string*/ static System$Runtime$Serialization$IFormatter$RequiresDynamicCodeMessage = null;
            /*string*/ static System$Runtime$Serialization$IFormatter$RequiresUnreferencedCodeMessage = null;
            //Static Initializer
            static $sinit()
            {
                {
                    this.System$Runtime$Serialization$IFormatter$RequiresDynamicCodeMessage = "BinaryFormatter serialization uses dynamic code generation, the type of objects being processed cannot be statically discovered.";
                }
                {
                    this.System$Runtime$Serialization$IFormatter$RequiresUnreferencedCodeMessage = "BinaryFormatter serialization is not trim compatible because the type of objects being processed cannot be statically discovered.";
                }
            }
            static $h = 960015;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {"p":[{"p":1091087,"g":{"r":0,"d":0,"h":25770763791,"f":257},"s":{"r":0,"d":0,"h":30065731087,"f":257},"n":"SurrogateSelector","o":"System$Runtime$Serialization$IFormatter$SurrogateSelector","d":960015,"h":21475796495,"f":257},{"p":1615375,"g":{"r":0,"d":0,"h":38655665679,"f":257},"s":{"r":0,"d":0,"h":42950632975,"f":257},"n":"Binder","o":"System$Runtime$Serialization$IFormatter$Binder","d":960015,"h":34360698383,"f":257},{"p":114098177,"g":{"r":0,"d":0,"h":51540567567,"f":257},"s":{"r":0,"d":0,"h":55835534863,"f":257},"n":"Context","o":"System$Runtime$Serialization$IFormatter$Context","d":960015,"h":47245600271,"f":257}],"m":[{"r":131073,"p":[{"n":"serializationStream","p":62128129}],"n":"Deserialize","o":"System$Runtime$Serialization$IFormatter$Deserialize","d":960015,"h":12885861903,"f":257},{"r":65537,"p":[{"n":"serializationStream","p":62128129},{"n":"graph","p":131073}],"n":"Serialize","o":"System$Runtime$Serialization$IFormatter$Serialize","d":960015,"h":17180829199,"f":257}],"l":[{"t":1310721,"n":"RequiresDynamicCodeMessage","o":"System$Runtime$Serialization$IFormatter$RequiresDynamicCodeMessage","d":960015,"h":4295927311,"f":40},{"t":1310721,"n":"RequiresUnreferencedCodeMessage","o":"System$Runtime$Serialization$IFormatter$RequiresUnreferencedCodeMessage","d":960015,"h":8590894607,"f":40}],"h":960015,"a":[{"t":70909953,"c":8660844545,"a":[{"v":"BinaryFormatter serialization is obsolete and should not be used. See https://aka.ms/binaryformatter for more information.","t":1310721}],"n":[{"n":"DiagnosticId","v":"SYSLIB0011","t":1310721},{"n":"UrlFormat","v":"https://aka.ms/dotnet-warnings/{0}","t":1310721}]}]}; }
            static get $fullName() { return `System.Runtime.Serialization.IFormatter`; }
        });
        
        $asm.$cls("$srsf.System.Runtime.Serialization.ISerializationSurrogate", ($self) => class ISerializationSurrogate
        {
            static $h = 1025551;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {"m":[{"r":65537,"p":[{"n":"obj","p":131073},{"n":"info","p":113967105},{"n":"context","p":114098177}],"n":"GetObjectData","o":"System$Runtime$Serialization$ISerializationSurrogate$GetObjectData","d":1025551,"h":4295992847,"f":257},{"r":131073,"p":[{"n":"obj","p":131073},{"n":"info","p":113967105},{"n":"context","p":114098177},{"n":"selector","p":1091087}],"n":"SetObjectData","o":"System$Runtime$Serialization$ISerializationSurrogate$SetObjectData","d":1025551,"h":8590960143,"f":257}],"h":1025551,"a":[{"t":70909953,"c":8660844545,"a":[{"v":"Formatter-based serialization is obsolete and should not be used.","t":1310721}],"n":[{"n":"DiagnosticId","v":"SYSLIB0050","t":1310721},{"n":"UrlFormat","v":"https://aka.ms/dotnet-warnings/{0}","t":1310721}]}]}; }
            static get $fullName() { return `System.Runtime.Serialization.ISerializationSurrogate`; }
        });
        
        $asm.$cls("$srsf.System.Runtime.Serialization.Formatters.IFieldInfo", ($self) => class IFieldInfo
        {
            static $h = 763407;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {"p":[{"p":0,"g":{"r":0,"d":0,"h":8590697999,"f":257},"s":{"r":0,"d":0,"h":12885665295,"f":257},"n":"FieldNames","o":"System$Runtime$Serialization$Formatters$IFieldInfo$FieldNames","d":763407,"h":4295730703,"f":257},{"p":0,"g":{"r":0,"d":0,"h":21475599887,"f":257},"s":{"r":0,"d":0,"h":25770567183,"f":257},"n":"FieldTypes","o":"System$Runtime$Serialization$Formatters$IFieldInfo$FieldTypes","d":763407,"h":17180632591,"f":257}],"h":763407,"a":[{"t":70909953,"c":8660844545,"a":[{"v":"Formatter-based serialization is obsolete and should not be used.","t":1310721}],"n":[{"n":"DiagnosticId","v":"SYSLIB0050","t":1310721},{"n":"UrlFormat","v":"https://aka.ms/dotnet-warnings/{0}","t":1310721}]}]}; }
            static get $fullName() { return `System.Runtime.Serialization.Formatters.IFieldInfo`; }
        });
        
        $asm.$cls("$srsf.System.Runtime.Serialization.SerializationBinder", ($self) => class SerializationBinder extends $.$spc.System.Object
        {
            /*void */ BindToName(/*Type*/ serializedType, /*out string?*/ assemblyName, /*out string?*/ typeName)
            {
                assemblyName.$v = null;
                typeName.$v = null;
            }
            //default reference type constructor overload
            $ctor$1()
            {
                super.$ctor();
                return this;
            }
            static $h = 1615375;
            static $f = 0b110001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"m":[{"r":65537,"p":[{"n":"serializedType","p":142606337},{"n":"assemblyName","p":1310721,"f":2},{"n":"typeName","p":1310721,"f":2}],"n":"BindToName","d":1615375,"h":4296582671,"f":129},{"r":142606337,"p":[{"n":"assemblyName","p":1310721},{"n":"typeName","p":1310721}],"n":"BindToType","d":1615375,"h":8591549967,"f":257}],"c":[{"n":".ctor","o":"$ctor$1","d":1615375,"h":12886517263,"f":4}],"h":1615375}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.Runtime.Serialization.SerializationBinder`; }
        });
        
        $asm.$cls("$srsf.System.Runtime.Serialization.Formatter", ($self) => class Formatter extends $.$spc.System.Object
        {
            /*ObjectIDGenerator*/ m_idGenerator = null;
            /*Queue*/ m_objectQueue = null;
            $ctor$1()
            {
                super.$ctor();
                {
                    this.m_objectQueue = new $.$scn.System.Collections.Queue().$ctor$1();
                    this.m_idGenerator = new $.$srsf.System.Runtime.Serialization.ObjectIDGenerator().$ctor$1();
                }
                return this;
            }
            /*object? */ GetNext(/*out long*/ objID)
            {
                if (this.m_objectQueue.Count === 0)
                {
                    objID.$v = 0n;
                    return null;
                }
                /*object*/ let obj = this.m_objectQueue.Dequeue();
                /*bool*/ let isNew;
                objID.$v = this.m_idGenerator.HasId(obj, $.$ref(() => isNew, ($v) => isNew = $v, $.$spc.System.Boolean));
                if (isNew)
                {
                    throw new $.$spc.System.Runtime.Serialization.SerializationException().$ctor$10($.$srsf.System.SR.Serialization_NoID);
                }
                return obj;
            }
            /*long */ Schedule(/*object?*/ obj)
            {
                if (obj === null)
                {
                    return 0n;
                }
                /*bool*/ let isNew;
                /*long*/ let id = this.m_idGenerator.GetId(obj, $.$ref(() => isNew, ($v) => isNew = $v, $.$spc.System.Boolean));
                if (isNew)
                {
                    this.m_objectQueue.Enqueue(obj);
                }
                return id;
            }
            /*void */ WriteMember(/*string*/ memberName, /*object?*/ data)
            {
                if (data === null)
                {
                    this.WriteObjectRef(data, memberName, $.$spc.System.Object.$type);
                    return;
                }
                /*Type*/ let varType = $.$spc.System.Object.GetType.call(data);
                if ($.$spc.System.Type.op_Equality$1(varType, $.$spc.System.Boolean.$type))
                {
                    this.WriteBoolean($.$spc.System.Convert.ToBoolean$1(data, $.$spc.System.Globalization.CultureInfo.InvariantCulture), memberName);
                }
                else if ($.$spc.System.Type.op_Equality$1(varType, $.$spc.System.Char.$type))
                {
                    this.WriteChar($.$spc.System.Convert.ToChar$1(data, $.$spc.System.Globalization.CultureInfo.InvariantCulture), memberName);
                }
                else if ($.$spc.System.Type.op_Equality$1(varType, $.$spc.System.SByte.$type))
                {
                    this.WriteSByte($.$spc.System.Convert.ToSByte$1(data, $.$spc.System.Globalization.CultureInfo.InvariantCulture), memberName);
                }
                else if ($.$spc.System.Type.op_Equality$1(varType, $.$spc.System.Byte.$type))
                {
                    this.WriteByte($.$spc.System.Convert.ToByte$1(data, $.$spc.System.Globalization.CultureInfo.InvariantCulture), memberName);
                }
                else if ($.$spc.System.Type.op_Equality$1(varType, $.$spc.System.Int16.$type))
                {
                    this.WriteInt16($.$spc.System.Convert.ToInt16$1(data, $.$spc.System.Globalization.CultureInfo.InvariantCulture), memberName);
                }
                else if ($.$spc.System.Type.op_Equality$1(varType, $.$spc.System.Int32.$type))
                {
                    this.WriteInt32($.$spc.System.Convert.ToInt32$1(data, $.$spc.System.Globalization.CultureInfo.InvariantCulture), memberName);
                }
                else if ($.$spc.System.Type.op_Equality$1(varType, $.$spc.System.Int64.$type))
                {
                    this.WriteInt64($.$spc.System.Convert.ToInt64$1(data, $.$spc.System.Globalization.CultureInfo.InvariantCulture), memberName);
                }
                else if ($.$spc.System.Type.op_Equality$1(varType, $.$spc.System.Single.$type))
                {
                    this.WriteSingle($.$spc.System.Convert.ToSingle$1(data, $.$spc.System.Globalization.CultureInfo.InvariantCulture), memberName);
                }
                else if ($.$spc.System.Type.op_Equality$1(varType, $.$spc.System.Double.$type))
                {
                    this.WriteDouble($.$spc.System.Convert.ToDouble$1(data, $.$spc.System.Globalization.CultureInfo.InvariantCulture), memberName);
                }
                else if ($.$spc.System.Type.op_Equality$1(varType, $.$spc.System.DateTime.$type))
                {
                    this.WriteDateTime($.$spc.System.Convert.ToDateTime$2(data, $.$spc.System.Globalization.CultureInfo.InvariantCulture), memberName);
                }
                else if ($.$spc.System.Type.op_Equality$1(varType, $.$spc.System.Decimal.$type))
                {
                    this.WriteDecimal($.$spc.System.Convert.ToDecimal$1(data, $.$spc.System.Globalization.CultureInfo.InvariantCulture), memberName);
                }
                else if ($.$spc.System.Type.op_Equality$1(varType, $.$spc.System.UInt16.$type))
                {
                    this.WriteUInt16($.$spc.System.Convert.ToUInt16$1(data, $.$spc.System.Globalization.CultureInfo.InvariantCulture), memberName);
                }
                else if ($.$spc.System.Type.op_Equality$1(varType, $.$spc.System.UInt32.$type))
                {
                    this.WriteUInt32($.$spc.System.Convert.ToUInt32$1(data, $.$spc.System.Globalization.CultureInfo.InvariantCulture), memberName);
                }
                else if ($.$spc.System.Type.op_Equality$1(varType, $.$spc.System.UInt64.$type))
                {
                    this.WriteUInt64($.$spc.System.Convert.ToUInt64$1(data, $.$spc.System.Globalization.CultureInfo.InvariantCulture), memberName);
                }
                else if (varType.IsArray)
                {
                    this.WriteArray(data, memberName, varType);
                }
                else if (varType.IsValueType)
                {
                    this.WriteValueType(data, memberName, varType);
                }
                else 
                {
                    this.WriteObjectRef(data, memberName, varType);
                }
            }
            //Generated interface implemetation for System.Runtime.Serialization.IFormatter.Deserialize(System.IO.Stream)
            System$Runtime$Serialization$IFormatter$Deserialize()
            {
                return this.Deserialize(...arguments);
            }
            //Generated interface implemetation for System.Runtime.Serialization.IFormatter.Serialize(System.IO.Stream, object)
            System$Runtime$Serialization$IFormatter$Serialize()
            {
                return this.Serialize(...arguments);
            }
            //Generated interface implemetation for System.Runtime.Serialization.IFormatter.SurrogateSelector.get
            get System$Runtime$Serialization$IFormatter$SurrogateSelector()
            {
                return this.SurrogateSelector;
            }
            //Generated interface implemetation for System.Runtime.Serialization.IFormatter.SurrogateSelector.set
            set System$Runtime$Serialization$IFormatter$SurrogateSelector(value)
            {
                this.SurrogateSelector = value;
            }
            //Generated interface implemetation for System.Runtime.Serialization.IFormatter.Binder.get
            get System$Runtime$Serialization$IFormatter$Binder()
            {
                return this.Binder;
            }
            //Generated interface implemetation for System.Runtime.Serialization.IFormatter.Binder.set
            set System$Runtime$Serialization$IFormatter$Binder(value)
            {
                this.Binder = value;
            }
            //Generated interface implemetation for System.Runtime.Serialization.IFormatter.Context.get
            get System$Runtime$Serialization$IFormatter$Context()
            {
                return this.Context;
            }
            //Generated interface implemetation for System.Runtime.Serialization.IFormatter.Context.set
            set System$Runtime$Serialization$IFormatter$Context(value)
            {
                this.Context = value;
            }
            static $h = 435727;
            static $f = 0b110001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":1091087,"g":{"r":0,"d":0,"h":120259520015,"f":257},"s":{"r":0,"d":0,"h":124554487311,"f":257},"n":"SurrogateSelector","d":435727,"h":115964552719,"f":257},{"p":1615375,"g":{"r":0,"d":0,"h":133144421903,"f":257},"s":{"r":0,"d":0,"h":137439389199,"f":257},"n":"Binder","d":435727,"h":128849454607,"f":257},{"p":114098177,"g":{"r":0,"d":0,"h":146029323791,"f":257},"s":{"r":0,"d":0,"h":150324291087,"f":257},"n":"Context","d":435727,"h":141734356495,"f":257}],"m":[{"r":131073,"p":[{"n":"serializationStream","p":62128129}],"n":"Deserialize","d":435727,"h":17180304911,"f":257},{"r":131073,"p":[{"n":"objID","p":917505,"f":2}],"n":"GetNext","d":435727,"h":21475272207,"f":132},{"r":917505,"p":[{"n":"obj","p":131073}],"n":"Schedule","d":435727,"h":25770239503,"f":132},{"r":65537,"p":[{"n":"serializationStream","p":62128129},{"n":"graph","p":131073}],"n":"Serialize","d":435727,"h":30065206799,"f":257},{"r":65537,"p":[{"n":"obj","p":131073},{"n":"name","p":1310721},{"n":"memberType","p":142606337}],"n":"WriteArray","d":435727,"h":34360174095,"f":260},{"r":65537,"p":[{"n":"val","p":262145},{"n":"name","p":1310721}],"n":"WriteBoolean","d":435727,"h":38655141391,"f":260},{"r":65537,"p":[{"n":"val","p":393217},{"n":"name","p":1310721}],"n":"WriteByte","d":435727,"h":42950108687,"f":260},{"r":65537,"p":[{"n":"val","p":458753},{"n":"name","p":1310721}],"n":"WriteChar","d":435727,"h":47245075983,"f":260},{"r":65537,"p":[{"n":"val","p":34144257},{"n":"name","p":1310721}],"n":"WriteDateTime","d":435727,"h":51540043279,"f":260},{"r":65537,"p":[{"n":"val","p":34996225},{"n":"name","p":1310721}],"n":"WriteDecimal","d":435727,"h":55835010575,"f":260},{"r":65537,"p":[{"n":"val","p":1179649},{"n":"name","p":1310721}],"n":"WriteDouble","d":435727,"h":60129977871,"f":260},{"r":65537,"p":[{"n":"val","p":524289},{"n":"name","p":1310721}],"n":"WriteInt16","d":435727,"h":64424945167,"f":260},{"r":65537,"p":[{"n":"val","p":655361},{"n":"name","p":1310721}],"n":"WriteInt32","d":435727,"h":68719912463,"f":260},{"r":65537,"p":[{"n":"val","p":917505},{"n":"name","p":1310721}],"n":"WriteInt64","d":435727,"h":73014879759,"f":260},{"r":65537,"p":[{"n":"obj","p":131073},{"n":"name","p":1310721},{"n":"memberType","p":142606337}],"n":"WriteObjectRef","d":435727,"h":77309847055,"f":260},{"r":65537,"p":[{"n":"memberName","p":1310721},{"n":"data","p":131073}],"n":"WriteMember","d":435727,"h":81604814351,"f":132},{"r":65537,"p":[{"n":"val","p":327681},{"n":"name","p":1310721}],"n":"WriteSByte","d":435727,"h":85899781647,"f":260,"a":[{"t":23396353,"c":8613330945,"a":[{"v":false,"t":262145}]}]},{"r":65537,"p":[{"n":"val","p":1114113},{"n":"name","p":1310721}],"n":"WriteSingle","d":435727,"h":90194748943,"f":260},{"r":65537,"p":[{"n":"val","p":140705793},{"n":"name","p":1310721}],"n":"WriteTimeSpan","d":435727,"h":94489716239,"f":260},{"r":65537,"p":[{"n":"val","p":589825},{"n":"name","p":1310721}],"n":"WriteUInt16","d":435727,"h":98784683535,"f":260,"a":[{"t":23396353,"c":8613330945,"a":[{"v":false,"t":262145}]}]},{"r":65537,"p":[{"n":"val","p":720897},{"n":"name","p":1310721}],"n":"WriteUInt32","d":435727,"h":103079650831,"f":260,"a":[{"t":23396353,"c":8613330945,"a":[{"v":false,"t":262145}]}]},{"r":65537,"p":[{"n":"val","p":983041},{"n":"name","p":1310721}],"n":"WriteUInt64","d":435727,"h":107374618127,"f":260,"a":[{"t":23396353,"c":8613330945,"a":[{"v":false,"t":262145}]}]},{"r":65537,"p":[{"n":"obj","p":131073},{"n":"name","p":1310721},{"n":"memberType","p":142606337}],"n":"WriteValueType","d":435727,"h":111669585423,"f":260}],"l":[{"t":1484303,"n":"m_idGenerator","d":435727,"h":4295403023,"f":4},{"t":393251,"n":"m_objectQueue","d":435727,"h":8590370319,"f":4}],"c":[{"n":".ctor","o":"$ctor$1","d":435727,"h":12885337615,"f":4}],"i":[960015],"h":435727,"a":[{"t":23396353,"c":8613330945,"a":[{"v":false,"t":262145}]},{"t":70909953,"c":8660844545,"a":[{"v":"BinaryFormatter serialization is obsolete and should not be used. See https://aka.ms/binaryformatter for more information.","t":1310721}],"n":[{"n":"DiagnosticId","v":"SYSLIB0011","t":1310721},{"n":"UrlFormat","v":"https://aka.ms/dotnet-warnings/{0}","t":1310721}]}]}; }
            static get $b() { return $.$spc.System.Object; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$srsf.System.Runtime.Serialization.IFormatter ]; }
            static get $fullName() { return `System.Runtime.Serialization.Formatter`; }
        });
        
        $asm.$cls("$srsf.System.Runtime.Serialization.FormatterServices", ($self) => class FormatterServices
        {
            /*ConcurrentDictionary<MemberHolder, MemberInfo[]>*/ static s_memberInfoTable = null;
            static /*FieldInfo[] */ InternalGetSerializableMembers(/*Type*/ type)
            {
                $.$spc.System.Diagnostics.Debug.Assert$1($.$spc.System.Type.op_Inequality$1(type, null), "type != null");
                if (type.IsInterface)
                {
                    return $.$spc.System.Array.Empty($.$spc.System.Reflection.FieldInfo);
                }
                if (!type.IsSerializable)
                {
                    throw new $.$spc.System.Runtime.Serialization.SerializationException().$ctor$10($.$srsf.System.SR.Format$1($.$srsf.System.SR.Serialization_NonSerType, type.FullName, type.Assembly.FullName));
                }
                /*FieldInfo[]*/ let typeMembers = $.$srsf.System.Runtime.Serialization.FormatterServices.GetSerializableFields(type);
                /*Type?*/ let parentType = type.BaseType;
                if ($.$spc.System.Type.op_Inequality$1(parentType, null) && $.$spc.System.Type.op_Inequality$1(parentType, $.$spc.System.Object.$type))
                {
                    /*Type[]?*/ let parentTypes;
                    /*int*/ let parentTypeCount;
                    /*bool*/ let classNamesUnique = $.$srsf.System.Runtime.Serialization.FormatterServices.GetParentTypes(parentType, $.$ref(() => parentTypes, ($v) => parentTypes = $v, $.$typeArray($.$spc.System.Type)), $.$ref(() => parentTypeCount, ($v) => parentTypeCount = $v, $.$spc.System.Int32));
                    if (parentTypeCount > 0)
                    {
                        /*var*/ let allMembers = new ($.$spc.System.Collections.Generic.List$$($.$spc.System.Reflection.FieldInfo))().$ctor$1();
                        for(/*int*/ let i = 0; i < parentTypeCount; i++)
                        {
                            parentType = $.$spc.System.Array.$ReadT1.call(parentTypes, i);
                            if (!parentType.IsSerializable)
                            {
                                throw new $.$spc.System.Runtime.Serialization.SerializationException().$ctor$10($.$srsf.System.SR.Format$1($.$srsf.System.SR.Serialization_NonSerType, parentType.FullName, parentType.Module$1.Assembly.FullName));
                            }
                            /*FieldInfo[]*/ let typeFields = parentType.GetFields$1(32/*BindingFlags.NonPublic*/ | 4/*BindingFlags.Instance*/);
                            /*string*/ let typeName = classNamesUnique ? parentType.Name : parentType.FullName;
                            let $i3 = 0;
                            let $arr3 = typeFields;
                            while ($i3 < $arr3.length)
                            {
                                let field = $arr3[$i3++];
                                if (!field.IsNotSerialized)
                                {
                                    allMembers.Add(new $.$srsf.System.Runtime.Serialization.SerializationFieldInfo().$ctor$4(field, typeName));
                                }
                            }
                        }
                        if (allMembers !== null && allMembers.Count > 0)
                        {
                            /*var*/ let membersTemp = $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$spc.System.Reflection.FieldInfo), null, [((allMembers.Count + typeMembers.length) | 0)], null);
                            $.$spc.System.Array.Copy(typeMembers, membersTemp, typeMembers.length);
                            allMembers.CopyTo$2(membersTemp, typeMembers.length);
                            typeMembers = membersTemp;
                        }
                    }
                }
                return typeMembers;
            }
            static /*FieldInfo[] */ GetSerializableFields(/*Type*/ type)
            {
                /*FieldInfo[]*/ let fields = type.GetFields$1(16/*BindingFlags.Public*/ | 32/*BindingFlags.NonPublic*/ | 4/*BindingFlags.Instance*/);
                /*int*/ let countProper = 0;
                for(/*int*/ let i = 0; i < fields.length; i++)
                {
                    if (($.$spc.System.Array.$ReadT1.call(fields, i).Attributes & 128/*FieldAttributes.NotSerialized*/) === 128/*FieldAttributes.NotSerialized*/)
                    {
                        continue;
                    }
                    countProper++;
                }
                if (countProper !== fields.length)
                {
                    /*var*/ let properFields = $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$spc.System.Reflection.FieldInfo), null, [countProper], null);
                    countProper = 0;
                    for(/*int*/ let i = 0; i < fields.length; i++)
                    {
                        if (($.$spc.System.Array.$ReadT1.call(fields, i).Attributes & 128/*FieldAttributes.NotSerialized*/) === 128/*FieldAttributes.NotSerialized*/)
                        {
                            continue;
                        }
                        $.$spc.System.Array.$WriteT1.call(properFields, $.$spc.System.Array.$ReadT1.call(fields, i), countProper);
                        countProper++;
                    }
                    return properFields;
                }
                else 
                {
                    return fields;
                }
            }
            static /*bool */ GetParentTypes(/*Type*/ parentType, /*out Type[]?*/ parentTypes, /*out int*/ parentTypeCount)
            {
                parentTypes.$v = null;
                parentTypeCount.$v = 0;
                /*bool*/ let unique = true;
                /*Type*/ let objectType = $.$spc.System.Object.$type;
                for(/*Type*/ let t1 = parentType; $.$spc.System.Type.op_Inequality$1(t1, objectType); t1 = t1.BaseType)
                {
                    if (t1.IsInterface)
                    {
                        continue;
                    }
                    /*string*/ let t1Name = t1.Name;
                    for(/*int*/ let i = 0; unique && i < parentTypeCount.$v; i++)
                    {
                        /*string*/ let t2Name = $.$spc.System.Array.$ReadT1.call(parentTypes.$v, i).Name;
                        if (t2Name.length === t1Name.length && $.$spc.System.String.get_Chars.call(t2Name, 0) === $.$spc.System.String.get_Chars.call(t1Name, 0) && $.$spc.System.String.op_Equality(t1Name, t2Name))
                        {
                            unique = false;
                            break;
                        }
                    }
                    if (parentTypes.$v === null || parentTypeCount.$v === parentTypes.$v.length)
                    {
                        $.$spc.System.Array.Resize($.$spc.System.Type, parentTypes, $.$spc.System.Math.Max$4(((parentTypeCount.$v * 2) | 0), 12));
                    }
                    $.$spc.System.Array.$WriteT1.call(parentTypes.$v, t1, parentTypeCount.$v++);
                }
                return unique;
            }
            static /*MemberInfo[] */ GetSerializableMembers(/*Type*/ type)
            {
                return $.$srsf.System.Runtime.Serialization.FormatterServices.GetSerializableMembers$1(type, new $.$spc.System.Runtime.Serialization.StreamingContext().$ctor$2(255/*StreamingContextStates.All*/));
            }
            static /*MemberInfo[] */ GetSerializableMembers$1(/*Type*/ type, /*StreamingContext*/ context)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(type, "type");
                return $.$srsf.System.Runtime.Serialization.FormatterServices.s_memberInfoTable.GetOrAdd(new $.$srsf.System.Runtime.Serialization.MemberHolder().$ctor$1(type, context), new ($.$spc.System.Func$$$($.$srsf.System.Runtime.Serialization.MemberHolder, $.$typeArray($.$spc.System.Reflection.MemberInfo)))().$ctor(this,  (/*mh*/ mh) =>
                {
                    return $.$srsf.System.Runtime.Serialization.FormatterServices.InternalGetSerializableMembers(mh._memberType);
                }));
            }
            static /*void */ CheckTypeSecurity(/*Type*/ t, /*TypeFilterLevel*/ securityLevel)
            {
            }
            static /*object */ GetUninitializedObject(/*Type*/ type)
            {
                return $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.GetUninitializedObject(type);
            }
            static /*object */ GetSafeUninitializedObject(/*Type*/ type)
            {
                return $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.GetUninitializedObject(type);
            }
            static /*void */ SerializationSetValue(/*MemberInfo*/ fi, /*object?*/ target, /*object?*/ value)
            {
                $.$spc.System.Diagnostics.Debug.Assert$1($.$spc.System.Reflection.MemberInfo.op_Inequality(fi, null), "fi != null");
                let serField;
                if ($.$is(fi, $.$spc.System.Reflection.FieldInfo, { set $v(v){ serField = v; } }))
                {
                    serField.SetValue(target, value);
                    return;
                }
                throw new $.$spc.System.ArgumentException().$ctor$10($.$srsf.System.SR.Argument_InvalidFieldInfo);
            }
            static /*object */ PopulateObjectMembers(/*object*/ obj, /*MemberInfo[]*/ members, /*object?[]*/ data)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(obj, "obj");
                $.$spc.System.ArgumentNullException.ThrowIfNull(members, "members");
                $.$spc.System.ArgumentNullException.ThrowIfNull(data, "data");
                if (members.length !== data.length)
                {
                    throw new $.$spc.System.ArgumentException().$ctor$10($.$srsf.System.SR.Argument_DataLengthDifferent);
                }
                for(/*int*/ let i = 0; i < members.length; i++)
                {
                    /*MemberInfo*/ let member = $.$spc.System.Array.$ReadT1.call(members, i);
                    if ($.$spc.System.Reflection.MemberInfo.op_Equality(member, null))
                    {
                        throw new $.$spc.System.ArgumentNullException().$ctor$18("members", $.$srsf.System.SR.Format($.$srsf.System.SR.ArgumentNull_NullMember, $.$box(i, $.$spc.System.Int32)));
                    }
                    /*object?*/ let value = $.$spc.System.Array.$ReadT1.call(data, i);
                    if (value === null)
                    {
                        continue;
                    }
                    let field;
                    if ($.$is(member, $.$spc.System.Reflection.FieldInfo, { set $v(v){ field = v; } }))
                    {
                        field.SetValue(obj, $.$spc.System.Array.$ReadT1.call(data, i));
                        continue;
                    }
                    throw new $.$spc.System.Runtime.Serialization.SerializationException().$ctor$10($.$srsf.System.SR.Serialization_UnknownMemberInfo);
                }
                return obj;
            }
            static /*object?[] */ GetObjectData(/*object*/ obj, /*MemberInfo[]*/ members)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(obj, "obj");
                $.$spc.System.ArgumentNullException.ThrowIfNull(members, "members");
                /*object?[]*/ let data = $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$spc.System.Object), null, [members.length], null);
                for(/*int*/ let i = 0; i < members.length; i++)
                {
                    /*MemberInfo*/ let member = $.$spc.System.Array.$ReadT1.call(members, i);
                    if ($.$spc.System.Reflection.MemberInfo.op_Equality(member, null))
                    {
                        throw new $.$spc.System.ArgumentNullException().$ctor$18("members", $.$srsf.System.SR.Format($.$srsf.System.SR.ArgumentNull_NullMember, $.$box(i, $.$spc.System.Int32)));
                    }
                    /*FieldInfo?*/ let field = $.$as(member, $.$spc.System.Reflection.FieldInfo);
                    if ($.$spc.System.Reflection.FieldInfo.op_Equality$1(field, null))
                    {
                        throw new $.$spc.System.Runtime.Serialization.SerializationException().$ctor$10($.$srsf.System.SR.Serialization_UnknownMemberInfo);
                    }
                    $.$spc.System.Array.$WriteT1.call(data, field.GetValue(obj), i);
                }
                return data;
            }
            static /*ISerializationSurrogate */ GetSurrogateForCyclicalReference(/*ISerializationSurrogate*/ innerSurrogate)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(innerSurrogate, "innerSurrogate");
                return new $.$srsf.System.Runtime.Serialization.SurrogateForCyclicalReference().$ctor$1(innerSurrogate);
            }
            static /*Type? */ GetTypeFromAssembly(/*Assembly*/ assem, /*string*/ name)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(assem, "assem");
                return assem.GetType$3(name, false, false);
            }
            static /*Assembly */ LoadAssemblyFromString(/*string*/ assemblyName)
            {
                return $.$spc.System.Reflection.Assembly.Load$1(new $.$spc.System.Reflection.AssemblyName().$ctor$1(assemblyName));
            }
            static /*Assembly? */ LoadAssemblyFromStringNoThrow(/*string*/ assemblyName)
            {
                try
                {
                    return $.$srsf.System.Runtime.Serialization.FormatterServices.LoadAssemblyFromString(assemblyName);
                }
                catch($e)
                {
                }
                return null;
            }
            static /*string */ GetClrAssemblyName(/*Type*/ type, /*out bool*/ hasTypeForwardedFrom)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(type, "type");
                /*Type*/ let attributedType = type;
                while(attributedType.HasElementType)
                {
                    attributedType = attributedType.GetElementType();
                }
                let $i1 = 0;
                let $arr1 = attributedType.GetCustomAttributes$1($.$spc.System.Runtime.CompilerServices.TypeForwardedFromAttribute.$type, false);
                while ($i1 < $arr1.length)
                {
                    let first = $arr1[$i1++];
                    hasTypeForwardedFrom.$v = true;
                    return ($.$cast(first, $.$spc.System.Runtime.CompilerServices.TypeForwardedFromAttribute)).AssemblyFullName;
                }
                hasTypeForwardedFrom.$v = false;
                return type.Assembly.FullName;
            }
            static /*string */ GetClrTypeFullName(/*Type*/ type)
            {
                return type.IsArray ? $.$srsf.System.Runtime.Serialization.FormatterServices.GetClrTypeFullNameForArray(type) : $.$srsf.System.Runtime.Serialization.FormatterServices.GetClrTypeFullNameForNonArrayTypes(type);
            }
            static /*string */ GetClrTypeFullNameForArray(/*Type*/ type)
            {
                /*int*/ let rank = type.GetArrayRank();
                $.$spc.System.Diagnostics.Debug.Assert$1(rank >= 1, "rank >= 1");
                /*string*/ let typeName = $.$srsf.System.Runtime.Serialization.FormatterServices.GetClrTypeFullName(type.GetElementType());
                return rank === 1 ? typeName + "[]" : typeName + "[" + $.$spc.System.String.Create$6(/*,*/ 44, ((rank - 1) | 0)) + "]";
            }
            static /*string */ GetClrTypeFullNameForNonArrayTypes(/*Type*/ type)
            {
                if (!type.IsGenericType)
                {
                    return type.FullName;
                }
                /*var*/ let builder = new $.$spc.System.Text.StringBuilder().$ctor$3(type.GetGenericTypeDefinition().FullName).Append$7(/*[*/ 91);
                /*bool*/ let hasTypeForwardedFrom;
                let $i1 = 0;
                let $arr1 = type.GetGenericArguments();
                while ($i1 < $arr1.length)
                {
                    let genericArgument = $arr1[$i1++];
                    builder.Append$7(/*[*/ 91).Append$2($.$srsf.System.Runtime.Serialization.FormatterServices.GetClrTypeFullName(genericArgument)).Append$2(", ");
                    builder.Append$2($.$srsf.System.Runtime.Serialization.FormatterServices.GetClrAssemblyName(genericArgument, $.$ref(() => hasTypeForwardedFrom, ($v) => hasTypeForwardedFrom = $v, $.$spc.System.Boolean))).Append$2("],");
                }
                return $.$spc.System.Text.StringBuilder.ToString.call(builder.Remove(((builder.Length - 1) | 0), 1).Append$7(/*]*/ 93));
            }
            //Static Initializer
            static $sinit()
            {
                {
                    this.s_memberInfoTable = new ($.$scc.System.Collections.Concurrent.ConcurrentDictionary$$$($.$srsf.System.Runtime.Serialization.MemberHolder, $.$typeArray($.$spc.System.Reflection.MemberInfo)))().$ctor$1();
                }
            }
            static $h = 894479;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"m":[{"r":0,"p":[{"n":"type","p":142606337}],"n":"InternalGetSerializableMembers","d":894479,"h":8590829071,"f":34},{"r":0,"p":[{"n":"type","p":142606337}],"n":"GetSerializableFields","d":894479,"h":12885796367,"f":34},{"r":262145,"p":[{"n":"parentType","p":142606337},{"n":"parentTypes","p":0,"f":2},{"n":"parentTypeCount","p":655361,"f":2}],"n":"GetParentTypes","d":894479,"h":17180763663,"f":34},{"r":0,"p":[{"n":"type","p":142606337}],"n":"GetSerializableMembers","d":894479,"h":21475730959,"f":33},{"r":0,"p":[{"n":"type","p":142606337},{"n":"context","p":114098177}],"n":"GetSerializableMembers","o":"@$1","d":894479,"h":25770698255,"f":33},{"r":65537,"p":[{"n":"t","p":142606337},{"n":"securityLevel","p":828943}],"n":"CheckTypeSecurity","d":894479,"h":30065665551,"f":33},{"r":131073,"p":[{"n":"type","p":142606337}],"n":"GetUninitializedObject","d":894479,"h":34360632847,"f":33},{"r":131073,"p":[{"n":"type","p":142606337}],"n":"GetSafeUninitializedObject","d":894479,"h":38655600143,"f":33},{"r":65537,"p":[{"n":"fi","p":78249985},{"n":"target","p":131073},{"n":"value","p":131073}],"n":"SerializationSetValue","d":894479,"h":42950567439,"f":40},{"r":131073,"p":[{"n":"obj","p":131073},{"n":"members","p":0},{"n":"data","p":0}],"n":"PopulateObjectMembers","d":894479,"h":47245534735,"f":33},{"r":0,"p":[{"n":"obj","p":131073},{"n":"members","p":0}],"n":"GetObjectData","d":894479,"h":51540502031,"f":33},{"r":1025551,"p":[{"n":"innerSurrogate","p":1025551}],"n":"GetSurrogateForCyclicalReference","d":894479,"h":55835469327,"f":33},{"r":142606337,"p":[{"n":"assem","p":73465857},{"n":"name","p":1310721}],"n":"GetTypeFromAssembly","d":894479,"h":60130436623,"f":33},{"r":73465857,"p":[{"n":"assemblyName","p":1310721}],"n":"LoadAssemblyFromString","d":894479,"h":64425403919,"f":40},{"r":73465857,"p":[{"n":"assemblyName","p":1310721}],"n":"LoadAssemblyFromStringNoThrow","d":894479,"h":68720371215,"f":40},{"r":1310721,"p":[{"n":"type","p":142606337},{"n":"hasTypeForwardedFrom","p":262145,"f":2}],"n":"GetClrAssemblyName","d":894479,"h":73015338511,"f":40},{"r":1310721,"p":[{"n":"type","p":142606337}],"n":"GetClrTypeFullName","d":894479,"h":77310305807,"f":40},{"r":1310721,"p":[{"n":"type","p":142606337}],"n":"GetClrTypeFullNameForArray","d":894479,"h":81605273103,"f":34},{"r":1310721,"p":[{"n":"type","p":142606337}],"n":"GetClrTypeFullNameForNonArrayTypes","d":894479,"h":85900240399,"f":34}],"l":[{"t":$.$scc.System.Collections.Concurrent.ConcurrentDictionary$$$($.$srsf.System.Runtime.Serialization.MemberHolder, $.$typeArray($.$spc.System.Reflection.MemberInfo)).$h,"n":"s_memberInfoTable","d":894479,"h":4295861775,"f":34}],"h":894479,"a":[{"t":70909953,"c":8660844545,"a":[{"v":"Formatter-based serialization is obsolete and should not be used.","t":1310721}],"n":[{"n":"DiagnosticId","v":"SYSLIB0050","t":1310721},{"n":"UrlFormat","v":"https://aka.ms/dotnet-warnings/{0}","t":1310721}]}]}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.Runtime.Serialization.FormatterServices`; }
        });
        
        $asm.$cls("$srsf.System.SR", ($self) => class SR
        {
            /*global::System.Resources.ResourceManager*/ static s_resourceManager = null;
            /*global::System.Globalization.CultureInfo*/ static resourceCulture = null;
            static /*global::System.Resources.ResourceManager */ get ResourceManager()
            {
                if ($.$spc.System.Object.ReferenceEquals($.$srsf.System.SR.s_resourceManager, null))
                {
                    /*global::System.Resources.ResourceManager*/ let temp = new $.$spc.System.Resources.ResourceManager().$ctor$3("System.Runtime.Serialization.Formatters", $.$srsf.System.SR.$type.Assembly);
                    $.$srsf.System.SR.s_resourceManager = temp;
                }
                return $.$srsf.System.SR.s_resourceManager;
            }
            static /*global::System.Globalization.CultureInfo */ get Culture()
            {
                return $.$srsf.System.SR.resourceCulture;
            }
            static /*global::System.Globalization.CultureInfo */ set Culture(value)
            {
                $.$srsf.System.SR.resourceCulture = value;
            }
            static /*string */ get Arg_HTCapacityOverflow()
            {
                return "Hashtable's capacity overflowed and went negative. Check load factor, capacity and the current size of the table.";
            }
            static /*string */ get Serialization_NonSerType()
            {
                return "Type '{0}' in Assembly '{1}' is not marked as serializable.";
            }
            static /*string */ FormatSerialization_NonSerType(/*object*/ arg1, /*object*/ arg2)
            {
                return $.$spc.System.String.Format$1("Type '{0}' in Assembly '{1}' is not marked as serializable.", arg1, arg2);
            }
            static /*string */ get Argument_DataLengthDifferent()
            {
                return "Parameters 'members' and 'data' must have the same length.";
            }
            static /*string */ get ArgumentNull_NullMember()
            {
                return "Member at position {0} was null.";
            }
            static /*string */ FormatArgumentNull_NullMember(/*object*/ arg1)
            {
                return $.$spc.System.String.Format("Member at position {0} was null.", arg1);
            }
            static /*string */ get Serialization_UnknownMemberInfo()
            {
                return "Only FieldInfo, PropertyInfo, and SerializationMemberInfo are recognized.";
            }
            static /*string */ get Serialization_NoID()
            {
                return "Object has never been assigned an objectID.";
            }
            static /*string */ get Serialization_TooManyElements()
            {
                return "The internal array cannot expand to greater than Int32.MaxValue elements.";
            }
            static /*string */ get Argument_InvalidFieldInfo()
            {
                return "The FieldInfo object is not valid.";
            }
            static /*string */ get Serialization_NeverSeen()
            {
                return "A fixup is registered to the object with ID {0}, but the object does not appear in the graph.";
            }
            static /*string */ FormatSerialization_NeverSeen(/*object*/ arg1)
            {
                return $.$spc.System.String.Format("A fixup is registered to the object with ID {0}, but the object does not appear in the graph.", arg1);
            }
            static /*string */ get Serialization_IORIncomplete()
            {
                return "The object with ID {0} implements the IObjectReference interface for which all dependencies cannot be resolved. The likely cause is two instances of IObjectReference that have a mutual dependency on each other.";
            }
            static /*string */ FormatSerialization_IORIncomplete(/*object*/ arg1)
            {
                return $.$spc.System.String.Format("The object with ID {0} implements the IObjectReference interface for which all dependencies cannot be resolved. The likely cause is two instances of IObjectReference that have a mutual dependency on each other.", arg1);
            }
            static /*string */ get Serialization_ObjectNotSupplied()
            {
                return "The object with ID {0} was referenced in a fixup but does not exist.";
            }
            static /*string */ FormatSerialization_ObjectNotSupplied(/*object*/ arg1)
            {
                return $.$spc.System.String.Format("The object with ID {0} was referenced in a fixup but does not exist.", arg1);
            }
            static /*string */ get Serialization_NotCyclicallyReferenceableSurrogate()
            {
                return "{0}.SetObjectData returns a value that is neither null nor equal to the first parameter. Such Surrogates cannot be part of cyclical reference.";
            }
            static /*string */ FormatSerialization_NotCyclicallyReferenceableSurrogate(/*object*/ arg1)
            {
                return $.$spc.System.String.Format("{0}.SetObjectData returns a value that is neither null nor equal to the first parameter. Such Surrogates cannot be part of cyclical reference.", arg1);
            }
            static /*string */ get Serialization_TooManyReferences()
            {
                return "The implementation of the IObjectReference interface returns too many nested references to other objects that implement IObjectReference.";
            }
            static /*string */ get Serialization_MissingObject()
            {
                return "The object with ID {0} was referenced in a fixup but has not been registered.";
            }
            static /*string */ FormatSerialization_MissingObject(/*object*/ arg1)
            {
                return $.$spc.System.String.Format("The object with ID {0} was referenced in a fixup but has not been registered.", arg1);
            }
            static /*string */ get Serialization_InvalidFixupDiscovered()
            {
                return "A fixup on an object implementing ISerializable or having a surrogate was discovered for an object which does not have a SerializationInfo available.";
            }
            static /*string */ get Serialization_TypeLoadFailure()
            {
                return "Unable to load type {0} required for deserialization.";
            }
            static /*string */ FormatSerialization_TypeLoadFailure(/*object*/ arg1)
            {
                return $.$spc.System.String.Format("Unable to load type {0} required for deserialization.", arg1);
            }
            static /*string */ get Serialization_ValueTypeFixup()
            {
                return "ValueType fixup on Arrays is not implemented.";
            }
            static /*string */ get Serialization_PartialValueTypeFixup()
            {
                return "Fixing up a partially available ValueType chain is not implemented.";
            }
            static /*string */ get Serialization_UnableToFixup()
            {
                return "Cannot perform fixup.";
            }
            static /*string */ get ArgumentOutOfRange_ObjectID()
            {
                return "objectID cannot be less than or equal to zero.";
            }
            static /*string */ get Serialization_RegisterTwice()
            {
                return "An object cannot be registered twice.";
            }
            static /*string */ get Serialization_NotISer()
            {
                return "The given object does not implement the ISerializable interface.";
            }
            static /*string */ get Serialization_ConstructorNotFound()
            {
                return "The constructor to deserialize an object of type '{0}' was not found.";
            }
            static /*string */ FormatSerialization_ConstructorNotFound(/*object*/ arg1)
            {
                return $.$spc.System.String.Format("The constructor to deserialize an object of type '{0}' was not found.", arg1);
            }
            static /*string */ get Serialization_IncorrectNumberOfFixups()
            {
                return "The ObjectManager found an invalid number of fixups. This usually indicates a problem in the Formatter.";
            }
            static /*string */ get Serialization_InvalidFixupType()
            {
                return "A member fixup was registered for an object which implements ISerializable or has a surrogate. In this situation, a delayed fixup must be used.";
            }
            static /*string */ get Serialization_IdTooSmall()
            {
                return "Object IDs must be greater than zero.";
            }
            static /*string */ get Serialization_ParentChildIdentical()
            {
                return "The ID of the containing object cannot be the same as the object ID.";
            }
            static /*string */ get Serialization_InvalidType()
            {
                return "Only system-provided types can be passed to the GetUninitializedObject method. '{0}' is not a valid instance of a type.";
            }
            static /*string */ FormatSerialization_InvalidType(/*object*/ arg1)
            {
                return $.$spc.System.String.Format("Only system-provided types can be passed to the GetUninitializedObject method. '{0}' is not a valid instance of a type.", arg1);
            }
            static /*string */ get Argument_MustSupplyParent()
            {
                return "When supplying the ID of a containing object, the FieldInfo that identifies the current field within that object must also be supplied.";
            }
            static /*string */ get Argument_MemberAndArray()
            {
                return "Cannot supply both a MemberInfo and an Array to indicate the parent of a value type.";
            }
            static /*string */ get Serialization_CorruptedStream()
            {
                return "Invalid BinaryFormatter stream.";
            }
            static /*string */ get Serialization_Stream()
            {
                return "Attempting to deserialize an empty stream.";
            }
            static /*string */ get Serialization_BinaryHeader()
            {
                return "Binary stream '{0}' does not contain a valid BinaryHeader. Possible causes are invalid stream or object version change between serialization and deserialization.";
            }
            static /*string */ FormatSerialization_BinaryHeader(/*object*/ arg1)
            {
                return $.$spc.System.String.Format("Binary stream '{0}' does not contain a valid BinaryHeader. Possible causes are invalid stream or object version change between serialization and deserialization.", arg1);
            }
            static /*string */ get Serialization_TypeExpected()
            {
                return "Invalid expected type.";
            }
            static /*string */ get Serialization_StreamEnd()
            {
                return "End of Stream encountered before parsing was completed.";
            }
            static /*string */ get Serialization_CrossAppDomainError()
            {
                return "Cross-AppDomain BinaryFormatter error; expected '{0}' but received '{1}'.";
            }
            static /*string */ FormatSerialization_CrossAppDomainError(/*object*/ arg1, /*object*/ arg2)
            {
                return $.$spc.System.String.Format$1("Cross-AppDomain BinaryFormatter error; expected '{0}' but received '{1}'.", arg1, arg2);
            }
            static /*string */ get Serialization_Map()
            {
                return "No map for object '{0}'.";
            }
            static /*string */ FormatSerialization_Map(/*object*/ arg1)
            {
                return $.$spc.System.String.Format("No map for object '{0}'.", arg1);
            }
            static /*string */ get Serialization_Assembly()
            {
                return "No assembly information is available for object on the wire, '{0}'.";
            }
            static /*string */ FormatSerialization_Assembly(/*object*/ arg1)
            {
                return $.$spc.System.String.Format("No assembly information is available for object on the wire, '{0}'.", arg1);
            }
            static /*string */ get Serialization_ObjectTypeEnum()
            {
                return "Invalid ObjectTypeEnum {0}.";
            }
            static /*string */ FormatSerialization_ObjectTypeEnum(/*object*/ arg1)
            {
                return $.$spc.System.String.Format("Invalid ObjectTypeEnum {0}.", arg1);
            }
            static /*string */ get Serialization_AssemblyId()
            {
                return "No assembly ID for object type '{0}'.";
            }
            static /*string */ FormatSerialization_AssemblyId(/*object*/ arg1)
            {
                return $.$spc.System.String.Format("No assembly ID for object type '{0}'.", arg1);
            }
            static /*string */ get Serialization_ArrayType()
            {
                return "Invalid array type '{0}'.";
            }
            static /*string */ FormatSerialization_ArrayType(/*object*/ arg1)
            {
                return $.$spc.System.String.Format("Invalid array type '{0}'.", arg1);
            }
            static /*string */ get Serialization_TypeCode()
            {
                return "Invalid type code in stream '{0}'.";
            }
            static /*string */ FormatSerialization_TypeCode(/*object*/ arg1)
            {
                return $.$spc.System.String.Format("Invalid type code in stream '{0}'.", arg1);
            }
            static /*string */ get Serialization_TypeWrite()
            {
                return "Invalid write type request '{0}'.";
            }
            static /*string */ FormatSerialization_TypeWrite(/*object*/ arg1)
            {
                return $.$spc.System.String.Format("Invalid write type request '{0}'.", arg1);
            }
            static /*string */ get Serialization_TypeRead()
            {
                return "Invalid read type request '{0}'.";
            }
            static /*string */ FormatSerialization_TypeRead(/*object*/ arg1)
            {
                return $.$spc.System.String.Format("Invalid read type request '{0}'.", arg1);
            }
            static /*string */ get Serialization_AssemblyNotFound()
            {
                return "Unable to find assembly '{0}'.";
            }
            static /*string */ FormatSerialization_AssemblyNotFound(/*object*/ arg1)
            {
                return $.$spc.System.String.Format("Unable to find assembly '{0}'.", arg1);
            }
            static /*string */ get Serialization_InvalidFormat()
            {
                return "The input stream is not a valid binary format. The starting contents (in bytes) are: {0} ...";
            }
            static /*string */ FormatSerialization_InvalidFormat(/*object*/ arg1)
            {
                return $.$spc.System.String.Format("The input stream is not a valid binary format. The starting contents (in bytes) are: {0} ...", arg1);
            }
            static /*string */ get Serialization_TopObject()
            {
                return "No top object.";
            }
            static /*string */ get Serialization_XMLElement()
            {
                return "Invalid element '{0}'.";
            }
            static /*string */ FormatSerialization_XMLElement(/*object*/ arg1)
            {
                return $.$spc.System.String.Format("Invalid element '{0}'.", arg1);
            }
            static /*string */ get Serialization_TopObjectInstantiate()
            {
                return "Top object cannot be instantiated for element '{0}'.";
            }
            static /*string */ FormatSerialization_TopObjectInstantiate(/*object*/ arg1)
            {
                return $.$spc.System.String.Format("Top object cannot be instantiated for element '{0}'.", arg1);
            }
            static /*string */ get Serialization_ArrayTypeObject()
            {
                return "Array element type is Object, 'dt' attribute is null.";
            }
            static /*string */ get Serialization_TypeMissing()
            {
                return "Type is missing for member of type Object '{0}'.";
            }
            static /*string */ FormatSerialization_TypeMissing(/*object*/ arg1)
            {
                return $.$spc.System.String.Format("Type is missing for member of type Object '{0}'.", arg1);
            }
            static /*string */ get Serialization_ObjNoID()
            {
                return "Object {0} has never been assigned an objectID.";
            }
            static /*string */ FormatSerialization_ObjNoID(/*object*/ arg1)
            {
                return $.$spc.System.String.Format("Object {0} has never been assigned an objectID.", arg1);
            }
            static /*string */ get Serialization_SerMemberInfo()
            {
                return "MemberInfo type {0} cannot be serialized.";
            }
            static /*string */ FormatSerialization_SerMemberInfo(/*object*/ arg1)
            {
                return $.$spc.System.String.Format("MemberInfo type {0} cannot be serialized.", arg1);
            }
            static /*string */ get Argument_MustSupplyContainer()
            {
                return "When supplying a FieldInfo for fixing up a nested type, a valid ID for that containing object must also be supplied.";
            }
            static /*string */ get Serialization_ParseError()
            {
                return "Parse error. Current element is not compatible with the next element, {0}.";
            }
            static /*string */ FormatSerialization_ParseError(/*object*/ arg1)
            {
                return $.$spc.System.String.Format("Parse error. Current element is not compatible with the next element, {0}.", arg1);
            }
            static /*string */ get Serialization_ISerializableMemberInfo()
            {
                return "MemberInfo requested for ISerializable type.";
            }
            static /*string */ get Serialization_MemberInfo()
            {
                return "MemberInfo cannot be obtained for ISerialized Object '{0}'.";
            }
            static /*string */ FormatSerialization_MemberInfo(/*object*/ arg1)
            {
                return $.$spc.System.String.Format("MemberInfo cannot be obtained for ISerialized Object '{0}'.", arg1);
            }
            static /*string */ get Serialization_ISerializableTypes()
            {
                return "Types not available for ISerializable object '{0}'.";
            }
            static /*string */ FormatSerialization_ISerializableTypes(/*object*/ arg1)
            {
                return $.$spc.System.String.Format("Types not available for ISerializable object '{0}'.", arg1);
            }
            static /*string */ get Serialization_MissingMember()
            {
                return "Member '{0}' in class '{1}' is not present in the serialized stream and is not marked with {2}.";
            }
            static /*string */ FormatSerialization_MissingMember(/*object*/ arg1, /*object*/ arg2, /*object*/ arg3)
            {
                return $.$spc.System.String.Format$2("Member '{0}' in class '{1}' is not present in the serialized stream and is not marked with {2}.", arg1, arg2, arg3);
            }
            static /*string */ get Serialization_NoMemberInfo()
            {
                return "No MemberInfo for Object {0}.";
            }
            static /*string */ FormatSerialization_NoMemberInfo(/*object*/ arg1)
            {
                return $.$spc.System.String.Format("No MemberInfo for Object {0}.", arg1);
            }
            static /*string */ get Serialization_SurrogateCycleInArgument()
            {
                return "Selector contained a cycle.";
            }
            static /*string */ get Serialization_SurrogateCycle()
            {
                return "Adding selector will introduce a cycle.";
            }
            static /*string */ get IO_EOF_ReadBeyondEOF()
            {
                return "Unable to read beyond the end of the stream.";
            }
            static /*string */ get BinaryFormatter_SerializationDisallowed()
            {
                return "BinaryFormatter serialization and deserialization are disabled within this application. See https://aka.ms/binaryformatter for more information.";
            }
            static /*string */ get BinaryFormatter_SerializationNotSupportedOnThisPlatform()
            {
                return "BinaryFormatter serialization and deserialization are not supported on this platform. See https://aka.ms/binaryformatter for more information.";
            }
            static /*string */ get BinaryFormatter_Removed()
            {
                return "BinaryFormatter serialization and deserialization have been removed. See https://aka.ms/binaryformatter for more information.";
            }
            /*bool*/ static s_usingResourceKeys = false;
            static /*bool */ GetUsingResourceKeysSwitchValue()
            {
                /*bool*/ let usingResourceKeys;
                return $.$spc.System.AppContext.TryGetSwitch("System.Resources.UseSystemResourceKeys", $.$ref(() => usingResourceKeys, ($v) => usingResourceKeys = $v, $.$spc.System.Boolean)) ? usingResourceKeys : false;
            }
            static /*bool */ UsingResourceKeys()
            {
                return $.$srsf.System.SR.s_usingResourceKeys;
            }
            static /*string */ GetResourceString(/*string*/ resourceKey)
            {
                if ($.$srsf.System.SR.UsingResourceKeys())
                {
                    return resourceKey;
                }
                /*string?*/ let resourceString = null;
                try
                {
                    resourceString = $.$srsf.System.SR.ResourceManager.GetString(resourceKey);
                }
                catch($e)
                {
                }
                return resourceString;
            }
            static /*string */ GetResourceString$1(/*string*/ resourceKey, /*string*/ defaultString)
            {
                /*string*/ let resourceString = $.$srsf.System.SR.GetResourceString(resourceKey);
                return $.$spc.System.String.op_Equality(resourceKey, resourceString) || $.$spc.System.String.op_Equality(resourceString, null) ? defaultString : resourceString;
            }
            static /*string */ Format(/*string*/ resourceFormat, /*object?*/ p1)
            {
                if ($.$srsf.System.SR.UsingResourceKeys())
                {
                    return $.$spc.System.String.Join$10(", ", $.$spc.System.ReadOnlySpan$$($.$spc.System.Object).op_Implicit([ resourceFormat, p1 ]));
                }
                return $.$spc.System.String.Format(resourceFormat, p1);
            }
            static /*string */ Format$1(/*string*/ resourceFormat, /*object?*/ p1, /*object?*/ p2)
            {
                if ($.$srsf.System.SR.UsingResourceKeys())
                {
                    return $.$spc.System.String.Join$10(", ", $.$spc.System.ReadOnlySpan$$($.$spc.System.Object).op_Implicit([ resourceFormat, p1, p2 ]));
                }
                return $.$spc.System.String.Format$1(resourceFormat, p1, p2);
            }
            static /*string */ Format$2(/*string*/ resourceFormat, /*object?*/ p1, /*object?*/ p2, /*object?*/ p3)
            {
                if ($.$srsf.System.SR.UsingResourceKeys())
                {
                    return $.$spc.System.String.Join$10(", ", $.$spc.System.ReadOnlySpan$$($.$spc.System.Object).op_Implicit([ resourceFormat, p1, p2, p3 ]));
                }
                return $.$spc.System.String.Format$2(resourceFormat, p1, p2, p3);
            }
            static /*string */ Format$3(/*string*/ resourceFormat, /*params object?[]?*/ args)
            {
                if (args !== null)
                {
                    if ($.$srsf.System.SR.UsingResourceKeys())
                    {
                        return resourceFormat + ", " + $.$spc.System.String.Join$9(", ", args);
                    }
                    return $.$spc.System.String.Format$3(resourceFormat, args);
                }
                return resourceFormat;
            }
            static /*string */ Format$4(/*IFormatProvider?*/ provider, /*string*/ resourceFormat, /*object?*/ p1)
            {
                if ($.$srsf.System.SR.UsingResourceKeys())
                {
                    return $.$spc.System.String.Join$10(", ", $.$spc.System.ReadOnlySpan$$($.$spc.System.Object).op_Implicit([ resourceFormat, p1 ]));
                }
                return $.$spc.System.String.Format$5(provider, resourceFormat, p1);
            }
            static /*string */ Format$5(/*IFormatProvider?*/ provider, /*string*/ resourceFormat, /*object?*/ p1, /*object?*/ p2)
            {
                if ($.$srsf.System.SR.UsingResourceKeys())
                {
                    return $.$spc.System.String.Join$10(", ", $.$spc.System.ReadOnlySpan$$($.$spc.System.Object).op_Implicit([ resourceFormat, p1, p2 ]));
                }
                return $.$spc.System.String.Format$6(provider, resourceFormat, p1, p2);
            }
            static /*string */ Format$6(/*IFormatProvider?*/ provider, /*string*/ resourceFormat, /*object?*/ p1, /*object?*/ p2, /*object?*/ p3)
            {
                if ($.$srsf.System.SR.UsingResourceKeys())
                {
                    return $.$spc.System.String.Join$10(", ", $.$spc.System.ReadOnlySpan$$($.$spc.System.Object).op_Implicit([ resourceFormat, p1, p2, p3 ]));
                }
                return $.$spc.System.String.Format$7(provider, resourceFormat, p1, p2, p3);
            }
            static /*string */ Format$7(/*IFormatProvider?*/ provider, /*string*/ resourceFormat, /*params object?[]?*/ args)
            {
                if (args !== null)
                {
                    if ($.$srsf.System.SR.UsingResourceKeys())
                    {
                        return resourceFormat + ", " + $.$spc.System.String.Join$9(", ", args);
                    }
                    return $.$spc.System.String.Format$8(provider, resourceFormat, args);
                }
                return resourceFormat;
            }
            //Static Initializer
            static $sinit()
            {
                {
                    this.s_usingResourceKeys = $.$srsf.System.SR.GetUsingResourceKeysSwitchValue();
                }
            }
            static $h = 2467343;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"h":2467343}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.SR`; }
        });
        
        $asm.$cls("$srsf.System.Runtime.Serialization.ObjectIDGenerator", ($self) => class ObjectIDGenerator extends $.$spc.System.Object
        {
            /*int*/ static NumBins = 4;
            /*int*/ _currentCount = 0;
            /*int*/ _currentSize = 0;
            /*long[]*/ _ids = null;
            /*object[]*/ _objs = null;
            $ctor$1()
            {
                super.$ctor();
                {
                    this._currentCount = 1;
                    this._currentSize = 3;
                    this._ids = $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$spc.System.Int64), null, [((this._currentSize * 4/*NumBins*/) | 0)], null);
                    this._objs = $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$spc.System.Object), null, [((this._currentSize * 4/*NumBins*/) | 0)], null);
                }
                return this;
            }
            /*int */ FindElement(/*object*/ obj, /*out bool*/ found)
            {
                /*int*/ let hashcode = $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.GetHashCode$1(obj);
                /*int*/ let hashIncrement = (((1 + ((hashcode & 2147483647) % (((this._currentSize - 2) | 0)))) | 0));
                do
                {
                    /*int*/ let pos = ((((hashcode & 2147483647) % this._currentSize) * 4/*NumBins*/) | 0);
                    for(/*int*/ let i = pos; i < ((pos + 4/*NumBins*/) | 0); i++)
                    {
                        if ($.$spc.System.Array.$ReadT1.call(this._objs, i) === null)
                        {
                            found.$v = false;
                            return i;
                        }
                        if ($.$spc.System.Array.$ReadT1.call(this._objs, i) === obj)
                        {
                            found.$v = true;
                            return i;
                        }
                    }
                    hashcode += hashIncrement;
                }
                while(true);
            }
            /*long */ GetId(/*object*/ obj, /*out bool*/ firstTime)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(obj, "obj");
                /*bool*/ let found;
                /*int*/ let pos = this.FindElement(obj, $.$ref(() => found, ($v) => found = $v, $.$spc.System.Boolean));
                /*long*/ let foundID;
                if (!found)
                {
                    $.$spc.System.Array.$WriteT1.call(this._objs, obj, pos);
                    $.$spc.System.Array.$WriteT1.call(this._ids, BigInt(this._currentCount++), pos);
                    foundID = $.$spc.System.Array.$ReadT1.call(this._ids, pos);
                    if (this._currentCount > $.trunc((((this._currentSize * 4/*NumBins*/) | 0)) / 2))
                    {
                        this.Rehash();
                    }
                }
                else 
                {
                    foundID = $.$spc.System.Array.$ReadT1.call(this._ids, pos);
                }
                firstTime.$v = !found;
                return foundID;
            }
            /*long */ HasId(/*object*/ obj, /*out bool*/ firstTime)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(obj, "obj");
                /*bool*/ let found;
                /*int*/ let pos = this.FindElement(obj, $.$ref(() => found, ($v) => found = $v, $.$spc.System.Boolean));
                if (found)
                {
                    firstTime.$v = false;
                    return $.$spc.System.Array.$ReadT1.call(this._ids, pos);
                }
                firstTime.$v = true;
                return 0n;
            }
            /*void */ Rehash()
            {
                /*int*/ let currSize = this._currentSize;
                /*int*/ let newSize = $.$srsf.System.Collections.HashHelpers.ExpandPrime(currSize);
                if (newSize === currSize)
                {
                    throw new $.$spc.System.Runtime.Serialization.SerializationException().$ctor$10($.$srsf.System.SR.Serialization_TooManyElements);
                }
                this._currentSize = newSize;
                /*long[]*/ let newIds = $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$spc.System.Int64), null, [((this._currentSize * 4/*NumBins*/) | 0)], null);
                /*object[]*/ let newObjs = $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$spc.System.Object), null, [((this._currentSize * 4/*NumBins*/) | 0)], null);
                /*long[]*/ let oldIds = this._ids;
                /*object[]*/ let oldObjs = this._objs;
                this._ids = newIds;
                this._objs = newObjs;
                for(/*int*/ let j = 0; j < oldObjs.length; j++)
                {
                    if ($.$spc.System.Array.$ReadT1.call(oldObjs, j) !== null)
                    {
                        /*int*/ let pos = this.FindElement($.$spc.System.Array.$ReadT1.call(oldObjs, j), $.$discardRef());
                        $.$spc.System.Array.$WriteT1.call(this._objs, $.$spc.System.Array.$ReadT1.call(oldObjs, j), pos);
                        $.$spc.System.Array.$WriteT1.call(this._ids, $.$spc.System.Array.$ReadT1.call(oldIds, j), pos);
                    }
                }
            }
            static $h = 1484303;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"m":[{"r":655361,"p":[{"n":"obj","p":131073},{"n":"found","p":262145,"f":2}],"n":"FindElement","d":1484303,"h":30066255375,"f":2},{"r":917505,"p":[{"n":"obj","p":131073},{"n":"firstTime","p":262145,"f":2}],"n":"GetId","d":1484303,"h":34361222671,"f":129},{"r":917505,"p":[{"n":"obj","p":131073},{"n":"firstTime","p":262145,"f":2}],"n":"HasId","d":1484303,"h":38656189967,"f":129},{"r":65537,"n":"Rehash","d":1484303,"h":42951157263,"f":2}],"l":[{"t":655361,"n":"NumBins","d":1484303,"h":4296451599,"f":34},{"t":655361,"n":"_currentCount","d":1484303,"h":8591418895,"f":8},{"t":655361,"n":"_currentSize","d":1484303,"h":12886386191,"f":2},{"t":0,"n":"_ids","d":1484303,"h":17181353487,"f":2},{"t":0,"n":"_objs","d":1484303,"h":21476320783,"f":2}],"c":[{"n":".ctor","o":"$ctor$1","d":1484303,"h":25771288079,"f":1}],"h":1484303,"a":[{"t":70909953,"c":8660844545,"a":[{"v":"Formatter-based serialization is obsolete and should not be used.","t":1310721}],"n":[{"n":"DiagnosticId","v":"SYSLIB0050","t":1310721},{"n":"UrlFormat","v":"https://aka.ms/dotnet-warnings/{0}","t":1310721}]}]}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.Runtime.Serialization.ObjectIDGenerator`; }
        });
        
        $asm.$cls("$srsf.System.Runtime.Serialization.MemberHolder", ($self) => class MemberHolder extends $.$spc.System.Object
        {
            /*Type*/ _memberType = null;
            /*StreamingContext*/ _context;
            $ctor$1(/*Type*/ type, /*StreamingContext*/ ctx)
            {
                super.$ctor();
                {
                    this._memberType = type;
                    this._context = ctx;
                }
                return this;
            }
            static/*conventional*/ /*int */ GetHashCode()
            {
                return $.$spc.System.Type.GetHashCode.call(this._memberType);
            }
            //Static convention instance redirect
            /*int */ GetHashCode() { return $.$srsf.System.Runtime.Serialization.MemberHolder.GetHashCode.apply(this, arguments); }
            static/*conventional*/ /*bool */ Equals(/*object?*/ obj)
            {
                let mh;
                return $.$is(obj, $.$srsf.System.Runtime.Serialization.MemberHolder, { set $v(v){ mh = v; } }) && $.$spc.System.Object.ReferenceEquals(mh._memberType, this._memberType) && mh._context.State === this._context.State;
            }
            //Static convention instance redirect
            /*bool */ Equals() { return $.$srsf.System.Runtime.Serialization.MemberHolder.Equals.apply(this, arguments); }
            //default member initializer
            constructor()
            {
                super();
                this._context = $.$default($.$spc.System.Runtime.Serialization.StreamingContext);
            }
            static $h = 1222159;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"m":[{"r":655361,"n":"GetHashCode","d":1222159,"h":17181091343,"f":32769},{"r":262145,"p":[{"n":"obj","p":131073}],"n":"Equals","d":1222159,"h":21476058639,"f":32769}],"l":[{"t":142606337,"n":"_memberType","d":1222159,"h":4296189455,"f":8},{"t":114098177,"n":"_context","d":1222159,"h":8591156751,"f":8}],"c":[{"p":[{"n":"type","p":142606337},{"n":"ctx","p":114098177}],"n":".ctor","o":"$ctor$1","d":1222159,"h":12886124047,"f":8}],"h":1222159}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.Runtime.Serialization.MemberHolder`; }
        });
        
        $asm.$cls("$srsf.System.Runtime.Serialization.ObjectManager", ($self) => class ObjectManager extends $.$spc.System.Object
        {
            /*int*/ static DefaultInitialSize = 16;
            /*int*/ static MaxArraySize = 1048576;
            /*int*/ static ArrayMask = 1048575;
            /*int*/ static MaxReferenceDepth = 100;
            /*string*/ static ObjectManagerUnreferencedCodeMessage = null;
            /*FieldInfo*/ static s_nullableValueField = null;
            /*DeserializationEventHandler?*/ _onDeserializationHandler = null;
            /*SerializationEventHandler?*/ _onDeserializedHandler = null;
            /*ObjectHolder[]*/ _objects = null;
            /*object?*/ _topObject = null;
            /*ObjectHolderList?*/ _specialFixupObjects = null;
            /*long*/ _fixupCount = 0n;
            /*ISurrogateSelector?*/ _selector = null;
            /*StreamingContext*/ _context;
            $ctor$1(/*ISurrogateSelector?*/ selector, /*StreamingContext*/ context)
            {
                super.$ctor();
                {
                    this._objects = $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$srsf.System.Runtime.Serialization.ObjectHolder), null, [16/*DefaultInitialSize*/], null);
                    this._selector = selector;
                    this._context = context;
                }
                return this;
            }
            /*bool */ CanCallGetType(/*object?*/ obj)
            {
                return true;
            }
            /*object? */ get TopObject()
            {
                return this._topObject;
            }
            /*object? */ set TopObject(value)
            {
                this._topObject = value;
            }
            /*ObjectHolderList */ get SpecialFixupObjects()
            {
                return this._specialFixupObjects ??= new $.$srsf.System.Runtime.Serialization.ObjectHolderList().$ctor$1();
            }
            /*ObjectHolder? */ FindObjectHolder(/*long*/ objectID)
            {
                /*int*/ let index = $.$cast((objectID & BigInt(1048575/*ArrayMask*/)), $.$spc.System.Int32);
                if (index >= this._objects.length)
                {
                    return null;
                }
                /*ObjectHolder?*/ let temp = $.$spc.System.Array.$ReadT1.call(this._objects, index);
                while(temp !== null)
                {
                    if (temp._id === objectID)
                    {
                        return temp;
                    }
                    temp = temp._next;
                }
                return temp;
            }
            /*ObjectHolder */ FindOrCreateObjectHolder(/*long*/ objectID)
            {
                /*ObjectHolder?*/ let holder = this.FindObjectHolder(objectID);
                if (holder === null)
                {
                    holder = new $.$srsf.System.Runtime.Serialization.ObjectHolder().$ctor$1(objectID);
                    this.AddObjectHolder(holder);
                }
                return holder;
            }
            /*void */ AddObjectHolder(/*ObjectHolder*/ holder)
            {
                $.$spc.System.Diagnostics.Debug.Assert$1(holder !== null, "holder!=null");
                $.$spc.System.Diagnostics.Debug.Assert$1(holder._id >= 0n, "holder.m_id>=0");
                if (holder._id >= BigInt(this._objects.length) && this._objects.length !== 1048576/*MaxArraySize*/)
                {
                    /*int*/ let newSize = 1048576/*MaxArraySize*/;
                    if (holder._id < (BigInt($.trunc(1048576/*MaxArraySize*/ / 2))))
                    {
                        newSize = (((this._objects.length * 2) | 0));
                        while(BigInt(newSize) <= holder._id && newSize < 1048576/*MaxArraySize*/)
                        {
                            newSize *= 2;
                        }
                        if (newSize > 1048576/*MaxArraySize*/)
                        {
                            newSize = 1048576/*MaxArraySize*/;
                        }
                    }
                    /*ObjectHolder[]*/ let temp = $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$srsf.System.Runtime.Serialization.ObjectHolder), null, [newSize], null);
                    $.$spc.System.Array.Copy(this._objects, temp, this._objects.length);
                    this._objects = temp;
                }
                /*int*/ let index = $.$cast((holder._id & BigInt(1048575/*ArrayMask*/)), $.$spc.System.Int32);
                /*ObjectHolder*/ let tempHolder = $.$spc.System.Array.$ReadT1.call(this._objects, index);
                holder._next = tempHolder;
                $.$spc.System.Array.$WriteT1.call(this._objects, holder, index);
            }
            /*bool */ GetCompletionInfo(/*FixupHolder*/ fixup, /*out ObjectHolder?*/ holder, /*out object*/ member, /*bool*/ bThrowIfMissing)
            {
                member.$v = fixup._fixupInfo;
                holder.$v = this.FindObjectHolder(fixup._id);
                if (holder.$v === null || holder.$v.CanObjectValueChange || holder.$v.ObjectValue === null)
                {
                    if (bThrowIfMissing)
                    {
                        if (holder.$v === null)
                        {
                            throw new $.$spc.System.Runtime.Serialization.SerializationException().$ctor$10($.$srsf.System.SR.Format($.$srsf.System.SR.Serialization_NeverSeen, $.$box(fixup._id, $.$spc.System.Int64)));
                        }
                        if (holder.$v.IsIncompleteObjectReference)
                        {
                            throw new $.$spc.System.Runtime.Serialization.SerializationException().$ctor$10($.$srsf.System.SR.Format($.$srsf.System.SR.Serialization_IORIncomplete, $.$box(fixup._id, $.$spc.System.Int64)));
                        }
                        throw new $.$spc.System.Runtime.Serialization.SerializationException().$ctor$10($.$srsf.System.SR.Format($.$srsf.System.SR.Serialization_ObjectNotSupplied, $.$box(fixup._id, $.$spc.System.Int64)));
                    }
                    return false;
                }
                if (!holder.$v.CompletelyFixed)
                {
                    if (holder.$v.ObjectValue !== null && $.$is(holder.$v.ObjectValue, $.$spc.System.ValueType))
                    {
                        this.SpecialFixupObjects.Add(holder.$v);
                        return false;
                    }
                }
                return true;
            }
            /*void */ FixupSpecialObject(/*ObjectHolder*/ holder)
            {
                /*ISurrogateSelector?*/ let uselessSelector = null;
                $.$spc.System.Diagnostics.Debug.Assert$1(holder.RequiresSerInfoFixup, "[ObjectManager.FixupSpecialObject]holder.HasSurrogate||holder.HasISerializable");
                if (holder.HasSurrogate)
                {
                    /*ISerializationSurrogate?*/ let surrogate = holder.Surrogate;
                    $.$spc.System.Diagnostics.Debug.Assert$1(surrogate !== null, "surrogate!=null");
                    $.$spc.System.Diagnostics.Debug.Assert$1(holder.SerializationInfo !== null, "holder.SerializationInfo != null");
                    /*object?*/ let returnValue = surrogate.System$Runtime$Serialization$ISerializationSurrogate$SetObjectData(holder.ObjectValue, holder.SerializationInfo, this._context, uselessSelector);
                    if (returnValue !== null)
                    {
                        if (!holder.CanSurrogatedObjectValueChange && returnValue !== holder.ObjectValue)
                        {
                            throw new $.$spc.System.Runtime.Serialization.SerializationException().$ctor$10($.$srsf.System.SR.Format($.$srsf.System.SR.Serialization_NotCyclicallyReferenceableSurrogate, $.$spc.System.Object.GetType.call(surrogate).FullName));
                        }
                        holder.SetObjectValue(returnValue, this);
                    }
                    holder._surrogate = null;
                    holder.SetFlags();
                }
                else 
                {
                    $.$spc.System.Diagnostics.Debug.Assert$1($.$is(holder.ObjectValue, $.$spc.System.Runtime.Serialization.ISerializable), "holder.m_object is ISerializable");
                    this.CompleteISerializableObject(holder.ObjectValue, holder.SerializationInfo, this._context);
                }
                holder.SerializationInfo = null;
                holder.RequiresSerInfoFixup = false;
                if (holder.RequiresValueTypeFixup && holder.ValueTypeFixupPerformed)
                {
                    this.DoValueTypeFixup(null, holder, holder.ObjectValue);
                }
                this.DoNewlyRegisteredObjectFixups(holder);
            }
            /*bool */ ResolveObjectReference(/*ObjectHolder*/ holder)
            {
                /*object?*/ let tempObject;
                $.$spc.System.Diagnostics.Debug.Assert$1(holder.IsIncompleteObjectReference, "holder.IsIncompleteObjectReference");
                /*int*/ let depthCount = 0;
                try
                {
                    do
                    {
                        tempObject = holder.ObjectValue;
                        $.$spc.System.Diagnostics.Debug.Assert$1(holder.ObjectValue !== null, "holder.ObjectValue != null");
                        holder.SetObjectValue(($.$cast((holder.ObjectValue), $.$spc.System.Runtime.Serialization.IObjectReference)).System$Runtime$Serialization$IObjectReference$GetRealObject(this._context), this);
                        if (holder.ObjectValue === null)
                        {
                            holder.SetObjectValue(tempObject, this);
                            return false;
                        }
                        if (depthCount++ === 100/*MaxReferenceDepth*/)
                        {
                            throw new $.$spc.System.Runtime.Serialization.SerializationException().$ctor$10($.$srsf.System.SR.Serialization_TooManyReferences);
                        }
                    }
                    while(($.$is(holder.ObjectValue, $.$spc.System.Runtime.Serialization.IObjectReference)) && (tempObject !== holder.ObjectValue));
                }
                catch($e)
                {
                    return false;
                }
                holder.IsIncompleteObjectReference = false;
                this.DoNewlyRegisteredObjectFixups(holder);
                return true;
            }
            /*bool */ DoValueTypeFixup(/*FieldInfo?*/ memberToFix, /*ObjectHolder*/ holder, /*object?*/ value)
            {
                /*var*/ let fieldsTemp = $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$spc.System.Reflection.FieldInfo), null, [4], null);
                /*FieldInfo[]*/ let fields;
                /*int*/ let currentFieldIndex = 0;
                /*int[]?*/ let arrayIndex = null;
                /*ValueTypeFixupInfo*/ let currFixup;
                /*object?*/ let fixupObj = holder.ObjectValue;
                $.$spc.System.Diagnostics.Debug.Assert$1(holder !== null, "[TypedReferenceBuilder.ctor]holder!=null");
                $.$spc.System.Diagnostics.Debug.Assert$1(holder.RequiresValueTypeFixup, "[TypedReferenceBuilder.ctor]holder.RequiresValueTypeFixup");
                while(holder.RequiresValueTypeFixup)
                {
                    if ((((currentFieldIndex + 1) | 0)) >= fieldsTemp.length)
                    {
                        /*var*/ let temp = $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$spc.System.Reflection.FieldInfo), null, [((fieldsTemp.length * 2) | 0)], null);
                        $.$spc.System.Array.Copy(fieldsTemp, temp, fieldsTemp.length);
                        fieldsTemp = temp;
                    }
                    currFixup = holder.ValueFixup;
                    fixupObj = holder.ObjectValue;
                    if ($.$spc.System.Reflection.FieldInfo.op_Inequality$1(currFixup.ParentField, null))
                    {
                        /*FieldInfo*/ let parentField = currFixup.ParentField;
                        /*ObjectHolder?*/ let tempHolder = this.FindObjectHolder(currFixup.ContainerID);
                        $.$spc.System.Diagnostics.Debug.Assert$1(tempHolder !== null, "tempHolder != null");
                        if (tempHolder.ObjectValue === null)
                        {
                            break;
                        }
                        /*FieldInfo?*/ let nullableValueField = $.$srsf.System.Runtime.Serialization.ObjectManager.GetNullableValueField(parentField.FieldType);
                        if ($.$spc.System.Reflection.FieldInfo.op_Inequality$1(nullableValueField, null))
                        {
                            $.$spc.System.Array.$WriteT1.call(fieldsTemp, nullableValueField, currentFieldIndex);
                            currentFieldIndex++;
                        }
                        $.$spc.System.Array.$WriteT1.call(fieldsTemp, parentField, currentFieldIndex);
                        holder = tempHolder;
                        currentFieldIndex++;
                    }
                    else 
                    {
                        $.$spc.System.Diagnostics.Debug.Assert$1(currFixup.ParentIndex !== null, "[ObjectManager.DoValueTypeFixup]currFixup.ParentIndex!=null");
                        holder = this.FindObjectHolder(currFixup.ContainerID);
                        arrayIndex = currFixup.ParentIndex;
                        break;
                    }
                }
                if (!($.$is(holder.ObjectValue, $.$spc.System.Array)) && holder.ObjectValue !== null)
                {
                    fixupObj = holder.ObjectValue;
                    $.$spc.System.Diagnostics.Debug.Assert$1(fixupObj !== null, "[ObjectManager.DoValueTypeFixup]FixupObj!=null");
                }
                if (currentFieldIndex !== 0)
                {
                    fields = $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$spc.System.Reflection.FieldInfo), null, [currentFieldIndex], null);
                    for(/*int*/ let i = 0; i < currentFieldIndex; i++)
                    {
                        /*FieldInfo?*/ let fieldInfo = $.$spc.System.Array.$ReadT1.call(fieldsTemp, (((((currentFieldIndex - 1) | 0) - i) | 0)));
                        /*SerializationFieldInfo?*/ let serInfo = $.$as(fieldInfo, $.$srsf.System.Runtime.Serialization.SerializationFieldInfo);
                        $.$spc.System.Array.$WriteT1.call(fields, serInfo === null ? fieldInfo : serInfo.FieldInfo, i);
                    }
                    $.$spc.System.Diagnostics.Debug.Assert$1(fixupObj !== null, "[ObjectManager.DoValueTypeFixup]fixupObj!=null");
                    /*TypedReference*/ let typedRef = $.$spc.System.TypedReference.MakeTypedReference(fixupObj, fields);
                    if ($.$spc.System.Reflection.FieldInfo.op_Inequality$1(memberToFix, null))
                    {
                        memberToFix.SetValueDirect(typedRef, value);
                    }
                    else 
                    {
                        $.$spc.System.TypedReference.SetTypedReference(typedRef, value);
                    }
                }
                else if ($.$spc.System.Reflection.FieldInfo.op_Inequality$1(memberToFix, null))
                {
                    $.$srsf.System.Runtime.Serialization.FormatterServices.SerializationSetValue(memberToFix, fixupObj, value);
                }
                if (arrayIndex !== null && holder.ObjectValue !== null)
                {
                    ($.$cast((holder.ObjectValue), $.$spc.System.Array)).SetValue$3(fixupObj, arrayIndex);
                }
                return true;
            }
            static /*FieldInfo? */ GetNullableValueField(/*Type*/ type)
            {
                if ($.$spc.System.Type.op_Inequality$1($.$spc.System.Nullable.GetUnderlyingType(type), null))
                {
                    return $.$cast(type.GetMemberWithSameMetadataDefinitionAs($.$srsf.System.Runtime.Serialization.ObjectManager.s_nullableValueField), $.$spc.System.Reflection.FieldInfo);
                }
                return null;
            }
            /*void */ CompleteObject(/*ObjectHolder*/ holder, /*bool*/ bObjectFullyComplete)
            {
                /*FixupHolderList?*/ let fixups = holder._missingElements;
                /*FixupHolder?*/ let currentFixup;
                /*SerializationInfo?*/ let si;
                /*object?*/ let fixupInfo;
                /*ObjectHolder?*/ let tempObjectHolder;
                /*int*/ let fixupsPerformed = 0;
                $.$spc.System.Diagnostics.Debug.Assert$1(holder !== null, "[ObjectManager.CompleteObject]holder.m_object!=null");
                if (holder.ObjectValue === null)
                {
                    throw new $.$spc.System.Runtime.Serialization.SerializationException().$ctor$10($.$srsf.System.SR.Format($.$srsf.System.SR.Serialization_MissingObject, $.$box(holder._id, $.$spc.System.Int64)));
                }
                if (fixups === null)
                {
                    return;
                }
                if (holder.HasSurrogate || holder.HasISerializable)
                {
                    si = holder._serInfo;
                    if (si === null)
                    {
                        throw new $.$spc.System.Runtime.Serialization.SerializationException().$ctor$10($.$srsf.System.SR.Serialization_InvalidFixupDiscovered);
                    }
                    if (fixups !== null)
                    {
                        for(/*int*/ let i = 0; i < fixups._count; i++)
                        {
                            if ($.$spc.System.Array.$ReadT1.call(fixups._values, i) === null)
                            {
                                continue;
                            }
                            $.$spc.System.Diagnostics.Debug.Assert$1($.$spc.System.Array.$ReadT1.call(fixups._values, i)._fixupType === 4/*FixupHolder.DelayedFixup*/, "fixups.m_values[i].m_fixupType==FixupHolder.DelayedFixup");
                            if (this.GetCompletionInfo($.$spc.System.Array.$ReadT1.call(fixups._values, i), $.$ref(() => tempObjectHolder, ($v) => tempObjectHolder = $v, $.$srsf.System.Runtime.Serialization.ObjectHolder), $.$ref(() => fixupInfo, ($v) => fixupInfo = $v, $.$spc.System.Object), bObjectFullyComplete))
                            {
                                /*object?*/ let holderValue = tempObjectHolder.ObjectValue;
                                $.$spc.System.Diagnostics.Debug.Assert$1(holderValue !== null, "holderValue != null");
                                if (this.CanCallGetType(holderValue))
                                {
                                    $.$srsf.System.Runtime.Serialization.SerializationInfoExtensions.UpdateValue(si, $.$cast(fixupInfo, $.$spc.System.String), holderValue, $.$spc.System.Object.GetType.call(holderValue));
                                }
                                else 
                                {
                                    $.$srsf.System.Runtime.Serialization.SerializationInfoExtensions.UpdateValue(si, $.$cast(fixupInfo, $.$spc.System.String), holderValue, $.$spc.System.MarshalByRefObject.$type);
                                }
                                fixupsPerformed++;
                                $.$spc.System.Array.$WriteT1.call(fixups._values, null, i);
                                if (!bObjectFullyComplete)
                                {
                                    holder.DecrementFixupsRemaining(this);
                                    tempObjectHolder.RemoveDependency(holder._id);
                                }
                            }
                        }
                    }
                }
                else 
                {
                    for(/*int*/ let i = 0; i < fixups._count; i++)
                    {
                        currentFixup = $.$spc.System.Array.$ReadT1.call(fixups._values, i);
                        if (currentFixup === null)
                        {
                            continue;
                        }
                        if (this.GetCompletionInfo(currentFixup, $.$ref(() => tempObjectHolder, ($v) => tempObjectHolder = $v, $.$srsf.System.Runtime.Serialization.ObjectHolder), $.$ref(() => fixupInfo, ($v) => fixupInfo = $v, $.$spc.System.Object), bObjectFullyComplete))
                        {
                            if (tempObjectHolder.TypeLoadExceptionReachable)
                            {
                                holder.TypeLoadException = tempObjectHolder.TypeLoadException;
                                if (holder.Reachable)
                                {
                                    throw new $.$spc.System.Runtime.Serialization.SerializationException().$ctor$10($.$srsf.System.SR.Format($.$srsf.System.SR.Serialization_TypeLoadFailure, holder.TypeLoadException.TypeName));
                                }
                            }
                            if (holder.Reachable)
                            {
                                tempObjectHolder.Reachable = true;
                            }
                            let $switch3 = currentFixup._fixupType;
                            switch($switch3)
                            {
                                case 1/*FixupHolder.ArrayFixup*/:
                                $.$spc.System.Diagnostics.Debug.Assert$1($.$is(holder.ObjectValue, $.$spc.System.Array), "holder.ObjectValue is Array");
                                if (holder.RequiresValueTypeFixup)
                                {
                                    throw new $.$spc.System.Runtime.Serialization.SerializationException().$ctor$10($.$srsf.System.SR.Serialization_ValueTypeFixup);
                                }
                                else 
                                {
                                    ($.$cast((holder.ObjectValue), $.$spc.System.Array)).SetValue$3(tempObjectHolder.ObjectValue, ($.$cast(fixupInfo, $.$typeArray($.$spc.System.Int32))));
                                }
                                break;
                                case 2/*FixupHolder.MemberFixup*/:
                                $.$spc.System.Diagnostics.Debug.Assert$1($.$is(fixupInfo, $.$spc.System.Reflection.MemberInfo), "fixupInfo is MemberInfo");
                                /*MemberInfo*/ let tempMember = $.$cast(fixupInfo, $.$spc.System.Reflection.MemberInfo);
                                if ($.$is(tempMember, $.$spc.System.Reflection.FieldInfo))
                                {
                                    if (holder.RequiresValueTypeFixup && holder.ValueTypeFixupPerformed)
                                    {
                                        if (!this.DoValueTypeFixup($.$cast(tempMember, $.$spc.System.Reflection.FieldInfo), holder, tempObjectHolder.ObjectValue))
                                        {
                                            throw new $.$spc.System.Runtime.Serialization.SerializationException().$ctor$10($.$srsf.System.SR.Serialization_PartialValueTypeFixup);
                                        }
                                    }
                                    else 
                                    {
                                        $.$srsf.System.Runtime.Serialization.FormatterServices.SerializationSetValue(tempMember, holder.ObjectValue, tempObjectHolder.ObjectValue);
                                    }
                                    if (tempObjectHolder.RequiresValueTypeFixup)
                                    {
                                        tempObjectHolder.ValueTypeFixupPerformed = true;
                                    }
                                }
                                else 
                                {
                                    throw new $.$spc.System.Runtime.Serialization.SerializationException().$ctor$10($.$srsf.System.SR.Serialization_UnableToFixup);
                                }
                                break;
                                default:
                                throw new $.$spc.System.Runtime.Serialization.SerializationException().$ctor$10($.$srsf.System.SR.Serialization_UnableToFixup);
                            }
                            fixupsPerformed++;
                            $.$spc.System.Array.$WriteT1.call(fixups._values, null, i);
                            if (!bObjectFullyComplete)
                            {
                                holder.DecrementFixupsRemaining(this);
                                tempObjectHolder.RemoveDependency(holder._id);
                            }
                        }
                    }
                }
                this._fixupCount -= BigInt(fixupsPerformed);
                if (fixups._count === fixupsPerformed)
                {
                    holder._missingElements = null;
                }
            }
            /*void */ DoNewlyRegisteredObjectFixups(/*ObjectHolder*/ holder)
            {
                if (holder.CanObjectValueChange)
                {
                    return;
                }
                /*LongList?*/ let dependencies = holder.DependentObjects;
                if (dependencies === null)
                {
                    return;
                }
                dependencies.StartEnumeration();
                while(dependencies.MoveNext())
                {
                    /*ObjectHolder?*/ let temp = this.FindObjectHolder(dependencies.Current);
                    $.$spc.System.Diagnostics.Debug.Assert$1(temp !== null, "temp != null");
                    $.$spc.System.Diagnostics.Debug.Assert$1(temp.DirectlyDependentObjects > 0, "temp.m_missingElementsRemaining>0");
                    temp.DecrementFixupsRemaining(this);
                    if (((temp.DirectlyDependentObjects)) === 0)
                    {
                        if (temp.ObjectValue !== null)
                        {
                            this.CompleteObject(temp, true);
                        }
                        else 
                        {
                            temp.MarkForCompletionWhenAvailable();
                        }
                    }
                }
            }
            /*object? */ GetObject(/*long*/ objectID)
            {
                if (objectID <= 0n)
                {
                    throw new $.$spc.System.ArgumentOutOfRangeException().$ctor$17("objectID", $.$srsf.System.SR.ArgumentOutOfRange_ObjectID);
                }
                /*ObjectHolder?*/ let holder = this.FindObjectHolder(objectID);
                if (holder === null || holder.CanObjectValueChange)
                {
                    return null;
                }
                return holder.ObjectValue;
            }
            /*void */ RegisterObject(/*object*/ obj, /*long*/ objectID)
            {
                this.RegisterObject$2(obj, objectID, null, 0n, null);
            }
            /*void */ RegisterObject$1(/*object*/ obj, /*long*/ objectID, /*SerializationInfo*/ info)
            {
                this.RegisterObject$2(obj, objectID, info, 0n, null);
            }
            /*void */ RegisterObject$2(/*object*/ obj, /*long*/ objectID, /*SerializationInfo?*/ info, /*long*/ idOfContainingObj, /*MemberInfo?*/ member)
            {
                this.RegisterObject$3(obj, objectID, info, idOfContainingObj, member, null);
            }
            /*void */ RegisterString(/*string?*/ obj, /*long*/ objectID, /*SerializationInfo?*/ info, /*long*/ idOfContainingObj, /*MemberInfo?*/ member)
            {
                /*ObjectHolder*/ let temp;
                $.$spc.System.Diagnostics.Debug.Assert$1($.$spc.System.Reflection.MemberInfo.op_Equality(member, null) || $.$is(member, $.$spc.System.Reflection.FieldInfo), "RegisterString - member is FieldInfo");
                temp = new $.$srsf.System.Runtime.Serialization.ObjectHolder().$ctor$3(obj, objectID, info, null, idOfContainingObj, $.$cast(member, $.$spc.System.Reflection.FieldInfo), null);
                this.AddObjectHolder(temp);
                return;
            }
            /*void */ RegisterObject$3(/*object*/ obj, /*long*/ objectID, /*SerializationInfo?*/ info, /*long*/ idOfContainingObj, /*MemberInfo?*/ member, /*int[]?*/ arrayIndex)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(obj, "obj");
                if (objectID <= 0n)
                {
                    throw new $.$spc.System.ArgumentOutOfRangeException().$ctor$17("objectID", $.$srsf.System.SR.ArgumentOutOfRange_ObjectID);
                }
                if ($.$spc.System.Reflection.MemberInfo.op_Inequality(member, null) && !($.$is(member, $.$spc.System.Reflection.FieldInfo)))
                {
                    throw new $.$spc.System.Runtime.Serialization.SerializationException().$ctor$10($.$srsf.System.SR.Serialization_UnknownMemberInfo);
                }
                /*ObjectHolder?*/ let temp;
                /*ISerializationSurrogate?*/ let surrogate = null;
                /*ISurrogateSelector*/ let useless;
                if (this._selector !== null)
                {
                    /*Type*/ let selectorType = this.CanCallGetType(obj) ? $.$spc.System.Object.GetType.call(obj) : $.$spc.System.MarshalByRefObject.$type;
                    surrogate = this._selector.System$Runtime$Serialization$ISurrogateSelector$GetSurrogate(selectorType, this._context, $.$ref(() => useless, ($v) => useless = $v, $.$srsf.System.Runtime.Serialization.ISurrogateSelector));
                }
                if ($.$is(obj, $.$spc.System.Runtime.Serialization.IDeserializationCallback))
                {
                    /*DeserializationEventHandler*/ let d = new $.$srsf.System.Runtime.Serialization.DeserializationEventHandler().$ctor(($.$cast(obj, $.$spc.System.Runtime.Serialization.IDeserializationCallback)), ($.$cast(obj, $.$spc.System.Runtime.Serialization.IDeserializationCallback)).System$Runtime$Serialization$IDeserializationCallback$OnDeserialization);
                    this.AddOnDeserialization(d);
                }
                if (arrayIndex !== null)
                {
                    arrayIndex = $.$cast(arrayIndex.Clone(), $.$typeArray($.$spc.System.Int32));
                }
                temp = this.FindObjectHolder(objectID);
                if (temp === null)
                {
                    temp = new $.$srsf.System.Runtime.Serialization.ObjectHolder().$ctor$2(obj, objectID, info, surrogate, idOfContainingObj, $.$cast(member, $.$spc.System.Reflection.FieldInfo), arrayIndex);
                    this.AddObjectHolder(temp);
                    if (temp.RequiresDelayedFixup)
                    {
                        this.SpecialFixupObjects.Add(temp);
                    }
                    this.AddOnDeserialized(obj);
                    return;
                }
                if (temp.ObjectValue !== null)
                {
                    throw new $.$spc.System.Runtime.Serialization.SerializationException().$ctor$10($.$srsf.System.SR.Serialization_RegisterTwice);
                }
                temp.UpdateData(obj, info, surrogate, idOfContainingObj, $.$cast(member, $.$spc.System.Reflection.FieldInfo), arrayIndex, this);
                if (temp.DirectlyDependentObjects > 0)
                {
                    this.CompleteObject(temp, false);
                }
                if (temp.RequiresDelayedFixup)
                {
                    this.SpecialFixupObjects.Add(temp);
                }
                if (temp.CompletelyFixed)
                {
                    this.DoNewlyRegisteredObjectFixups(temp);
                    temp.DependentObjects = null;
                }
                if (temp.TotalDependentObjects > 0)
                {
                    this.AddOnDeserialized(obj);
                }
                else 
                {
                    this.RaiseOnDeserializedEvent(obj);
                }
            }
            /*void */ CompleteISerializableObject(/*object*/ obj, /*SerializationInfo?*/ info, /*StreamingContext*/ context)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(obj, "obj");
                if (!($.$is(obj, $.$spc.System.Runtime.Serialization.ISerializable)))
                {
                    throw new $.$spc.System.ArgumentException().$ctor$10($.$srsf.System.SR.Serialization_NotISer);
                }
                /*ConstructorInfo*/ let constInfo;
                /*Type*/ let t = $.$spc.System.Object.GetType.call(obj);
                try
                {
                    constInfo = $.$srsf.System.Runtime.Serialization.ObjectManager.GetDeserializationConstructor(t);
                }
                catch(e)
                {
                    throw new $.$spc.System.Runtime.Serialization.SerializationException().$ctor$11($.$srsf.System.SR.Format($.$srsf.System.SR.Serialization_ConstructorNotFound, t), e);
                }
                constInfo.Invoke(obj, $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$spc.System.Object), [info, context], [-1], null));
            }
            static /*ConstructorInfo */ GetDeserializationConstructor(/*Type*/ t)
            {
                let $i1 = 0;
                let $arr1 = t.GetConstructors$1(16/*BindingFlags.Public*/ | 32/*BindingFlags.NonPublic*/ | 4/*BindingFlags.Instance*/ | 2/*BindingFlags.DeclaredOnly*/);
                while ($i1 < $arr1.length)
                {
                    let ci = $arr1[$i1++];
                    /*ParameterInfo[]*/ let parameters = ci.GetParameters();
                    if (parameters.length === 2 && $.$spc.System.Type.op_Equality$1($.$spc.System.Array.$ReadT1.call(parameters, 0).ParameterType, $.$spc.System.Runtime.Serialization.SerializationInfo.$type) && $.$spc.System.Type.op_Equality$1($.$spc.System.Array.$ReadT1.call(parameters, 1).ParameterType, $.$spc.System.Runtime.Serialization.StreamingContext.$type))
                    {
                        return ci;
                    }
                }
                throw new $.$spc.System.Runtime.Serialization.SerializationException().$ctor$10($.$srsf.System.SR.Format($.$srsf.System.SR.Serialization_ConstructorNotFound, t.FullName));
            }
            /*void */ DoFixups()
            {
                /*ObjectHolder?*/ let temp;
                /*int*/ let fixupCount = -1;
                while(fixupCount !== 0)
                {
                    fixupCount = 0;
                    /*ObjectHolderListEnumerator*/ let fixupObjectsEnum = this.SpecialFixupObjects.GetFixupEnumerator();
                    while(fixupObjectsEnum.MoveNext())
                    {
                        temp = fixupObjectsEnum.Current;
                        if (temp.ObjectValue === null)
                        {
                            throw new $.$spc.System.Runtime.Serialization.SerializationException().$ctor$10($.$srsf.System.SR.Format($.$srsf.System.SR.Serialization_ObjectNotSupplied, $.$box(temp._id, $.$spc.System.Int64)));
                        }
                        if (temp.TotalDependentObjects === 0)
                        {
                            if (temp.RequiresSerInfoFixup)
                            {
                                this.FixupSpecialObject(temp);
                                fixupCount++;
                            }
                            else if (!temp.IsIncompleteObjectReference)
                            {
                                this.CompleteObject(temp, true);
                            }
                            if (temp.IsIncompleteObjectReference && this.ResolveObjectReference(temp))
                            {
                                fixupCount++;
                            }
                        }
                    }
                }
                $.$spc.System.Diagnostics.Debug.Assert$1(this._fixupCount >= 0n, "[ObjectManager.DoFixups]m_fixupCount>=0");
                if (this._fixupCount === 0n)
                {
                    if ($.$is(this.TopObject, $.$srsf.System.Runtime.Serialization.TypeLoadExceptionHolder))
                    {
                        throw new $.$spc.System.Runtime.Serialization.SerializationException().$ctor$10($.$srsf.System.SR.Format($.$srsf.System.SR.Serialization_TypeLoadFailure, ($.$cast(this.TopObject, $.$srsf.System.Runtime.Serialization.TypeLoadExceptionHolder)).TypeName));
                    }
                    return;
                }
                for(/*int*/ let i = 0; i < this._objects.length; i++)
                {
                    temp = $.$spc.System.Array.$ReadT1.call(this._objects, i);
                    while(temp !== null)
                    {
                        if (temp.TotalDependentObjects > 0)
                        {
                            this.CompleteObject(temp, true);
                        }
                        temp = temp._next;
                    }
                    if (this._fixupCount === 0n)
                    {
                        return;
                    }
                }
                throw new $.$spc.System.Runtime.Serialization.SerializationException().$ctor$10($.$srsf.System.SR.Serialization_IncorrectNumberOfFixups);
            }
            /*void */ RegisterFixup(/*FixupHolder*/ fixup, /*long*/ objectToBeFixed, /*long*/ objectRequired)
            {
                /*ObjectHolder*/ let ohToBeFixed = this.FindOrCreateObjectHolder(objectToBeFixed);
                /*ObjectHolder*/ let ohRequired;
                if (ohToBeFixed.RequiresSerInfoFixup && fixup._fixupType === 2/*FixupHolder.MemberFixup*/)
                {
                    throw new $.$spc.System.Runtime.Serialization.SerializationException().$ctor$10($.$srsf.System.SR.Serialization_InvalidFixupType);
                }
                ohToBeFixed.AddFixup(fixup, this);
                ohRequired = this.FindOrCreateObjectHolder(objectRequired);
                ohRequired.AddDependency(objectToBeFixed);
                this._fixupCount++;
            }
            /*void */ RecordFixup(/*long*/ objectToBeFixed, /*MemberInfo*/ member, /*long*/ objectRequired)
            {
                if (objectToBeFixed <= 0n || objectRequired <= 0n)
                {
                    throw new $.$spc.System.ArgumentOutOfRangeException().$ctor$17(objectToBeFixed <= 0n ? "objectToBeFixed" : "objectRequired", $.$srsf.System.SR.Serialization_IdTooSmall);
                }
                $.$spc.System.ArgumentNullException.ThrowIfNull(member, "member");
                if (!($.$is(member, $.$spc.System.Reflection.FieldInfo)))
                {
                    throw new $.$spc.System.Runtime.Serialization.SerializationException().$ctor$10($.$srsf.System.SR.Format($.$srsf.System.SR.Serialization_InvalidType, $.$spc.System.Object.GetType.call(member)));
                }
                /*FixupHolder*/ let fixup = new $.$srsf.System.Runtime.Serialization.FixupHolder().$ctor$1(objectRequired, member, 2/*FixupHolder.MemberFixup*/);
                this.RegisterFixup(fixup, objectToBeFixed, objectRequired);
            }
            /*void */ RecordDelayedFixup(/*long*/ objectToBeFixed, /*string*/ memberName, /*long*/ objectRequired)
            {
                if (objectToBeFixed <= 0n || objectRequired <= 0n)
                {
                    throw new $.$spc.System.ArgumentOutOfRangeException().$ctor$17(objectToBeFixed <= 0n ? "objectToBeFixed" : "objectRequired", $.$srsf.System.SR.Serialization_IdTooSmall);
                }
                $.$spc.System.ArgumentNullException.ThrowIfNull(memberName, "memberName");
                /*FixupHolder*/ let fixup = new $.$srsf.System.Runtime.Serialization.FixupHolder().$ctor$1(objectRequired, memberName, 4/*FixupHolder.DelayedFixup*/);
                this.RegisterFixup(fixup, objectToBeFixed, objectRequired);
            }
            /*void */ RecordArrayElementFixup(/*long*/ arrayToBeFixed, /*int*/ index, /*long*/ objectRequired)
            {
                /*int[]*/ let indexArray = $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$spc.System.Int32), null, [1], null);
                $.$spc.System.Array.$WriteT1.call(indexArray, index, 0);
                this.RecordArrayElementFixup$1(arrayToBeFixed, indexArray, objectRequired);
            }
            /*void */ RecordArrayElementFixup$1(/*long*/ arrayToBeFixed, /*int[]*/ indices, /*long*/ objectRequired)
            {
                if (arrayToBeFixed <= 0n || objectRequired <= 0n)
                {
                    throw new $.$spc.System.ArgumentOutOfRangeException().$ctor$17(arrayToBeFixed <= 0n ? "arrayToBeFixed" : "objectRequired", $.$srsf.System.SR.Serialization_IdTooSmall);
                }
                $.$spc.System.ArgumentNullException.ThrowIfNull(indices, "indices");
                /*FixupHolder*/ let fixup = new $.$srsf.System.Runtime.Serialization.FixupHolder().$ctor$1(objectRequired, indices, 1/*FixupHolder.ArrayFixup*/);
                this.RegisterFixup(fixup, arrayToBeFixed, objectRequired);
            }
            /*void */ RaiseDeserializationEvent()
            {
                this._onDeserializedHandler?.Invoke(this._context);
                this._onDeserializationHandler?.Invoke(null);
            }
            /*void */ AddOnDeserialization(/*DeserializationEventHandler*/ handler)
            {
                this._onDeserializationHandler = $.$cast($.$spc.System.Delegate.Combine(this._onDeserializationHandler, handler), $.$srsf.System.Runtime.Serialization.DeserializationEventHandler);
            }
            /*void */ AddOnDeserialized(/*object*/ obj)
            {
                /*SerializationEvents*/ let cache = $.$srsf.System.Runtime.Serialization.SerializationEventsCache.GetSerializationEventsForType($.$spc.System.Object.GetType.call(obj));
                this._onDeserializedHandler = cache.AddOnDeserialized(obj, this._onDeserializedHandler);
            }
            /*void */ RaiseOnDeserializedEvent(/*object*/ obj)
            {
                /*SerializationEvents*/ let cache = $.$srsf.System.Runtime.Serialization.SerializationEventsCache.GetSerializationEventsForType($.$spc.System.Object.GetType.call(obj));
                cache.InvokeOnDeserialized(obj, this._context);
            }
            /*void */ RaiseOnDeserializingEvent(/*object*/ obj)
            {
                /*SerializationEvents*/ let cache = $.$srsf.System.Runtime.Serialization.SerializationEventsCache.GetSerializationEventsForType($.$spc.System.Object.GetType.call(obj));
                cache.InvokeOnDeserializing(obj, this._context);
            }
            //default member initializer
            constructor()
            {
                super();
                this._context = $.$default($.$spc.System.Runtime.Serialization.StreamingContext);
            }
            //Static Initializer
            static $sinit()
            {
                {
                    this.ObjectManagerUnreferencedCodeMessage = "ObjectManager is not trim compatible because the type of objects being managed cannot be statically discovered.";
                }
                {
                    this.s_nullableValueField = $.$spc.System.Nullable$$().$type.GetField$2("value", 32/*BindingFlags.NonPublic*/ | 4/*BindingFlags.Instance*/);
                }
            }
            static $h = 1549839;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":131073,"g":{"r":0,"d":0,"h":77310961167,"f":8},"s":{"r":0,"d":0,"h":81605928463,"f":8},"n":"TopObject","d":1549839,"h":73015993871,"f":8},{"p":1353231,"g":{"r":0,"d":0,"h":90195863055,"f":8},"n":"SpecialFixupObjects","d":1549839,"h":85900895759,"f":8}],"m":[{"r":262145,"p":[{"n":"obj","p":131073}],"n":"CanCallGetType","d":1549839,"h":68721026575,"f":2},{"r":1287695,"p":[{"n":"objectID","p":917505}],"n":"FindObjectHolder","d":1549839,"h":94490830351,"f":8},{"r":1287695,"p":[{"n":"objectID","p":917505}],"n":"FindOrCreateObjectHolder","d":1549839,"h":98785797647,"f":8},{"r":65537,"p":[{"n":"holder","p":1287695}],"n":"AddObjectHolder","d":1549839,"h":103080764943,"f":2},{"r":262145,"p":[{"n":"fixup","p":304655},{"n":"holder","p":1287695,"f":2},{"n":"member","p":131073,"f":2},{"n":"bThrowIfMissing","p":262145}],"n":"GetCompletionInfo","d":1549839,"h":107375732239,"f":2},{"r":65537,"p":[{"n":"holder","p":1287695}],"n":"FixupSpecialObject","d":1549839,"h":111670699535,"f":2},{"r":262145,"p":[{"n":"holder","p":1287695}],"n":"ResolveObjectReference","d":1549839,"h":115965666831,"f":2},{"r":262145,"p":[{"n":"memberToFix","p":76677121},{"n":"holder","p":1287695},{"n":"value","p":131073}],"n":"DoValueTypeFixup","d":1549839,"h":120260634127,"f":2},{"r":76677121,"p":[{"n":"type","p":142606337}],"n":"GetNullableValueField","d":1549839,"h":124555601423,"f":34},{"r":65537,"p":[{"n":"holder","p":1287695},{"n":"bObjectFullyComplete","p":262145}],"n":"CompleteObject","d":1549839,"h":128850568719,"f":8},{"r":65537,"p":[{"n":"holder","p":1287695}],"n":"DoNewlyRegisteredObjectFixups","d":1549839,"h":133145536015,"f":2},{"r":131073,"p":[{"n":"objectID","p":917505}],"n":"GetObject","d":1549839,"h":137440503311,"f":129},{"r":65537,"p":[{"n":"obj","p":131073},{"n":"objectID","p":917505}],"n":"RegisterObject","d":1549839,"h":141735470607,"f":129},{"r":65537,"p":[{"n":"obj","p":131073},{"n":"objectID","p":917505},{"n":"info","p":113967105}],"n":"RegisterObject","o":"@$1","d":1549839,"h":146030437903,"f":1},{"r":65537,"p":[{"n":"obj","p":131073},{"n":"objectID","p":917505},{"n":"info","p":113967105},{"n":"idOfContainingObj","p":917505},{"n":"member","p":78249985}],"n":"RegisterObject","o":"@$2","d":1549839,"h":150325405199,"f":1},{"r":65537,"p":[{"n":"obj","p":1310721},{"n":"objectID","p":917505},{"n":"info","p":113967105},{"n":"idOfContainingObj","p":917505},{"n":"member","p":78249985}],"n":"RegisterString","d":1549839,"h":154620372495,"f":8},{"r":65537,"p":[{"n":"obj","p":131073},{"n":"objectID","p":917505},{"n":"info","p":113967105},{"n":"idOfContainingObj","p":917505},{"n":"member","p":78249985},{"n":"arrayIndex","p":0}],"n":"RegisterObject","o":"@$3","d":1549839,"h":158915339791,"f":1},{"r":65537,"p":[{"n":"obj","p":131073},{"n":"info","p":113967105},{"n":"context","p":114098177}],"n":"CompleteISerializableObject","d":1549839,"h":163210307087,"f":8},{"r":75628545,"p":[{"n":"t","p":142606337}],"n":"GetDeserializationConstructor","d":1549839,"h":167505274383,"f":40},{"r":65537,"n":"DoFixups","d":1549839,"h":171800241679,"f":129},{"r":65537,"p":[{"n":"fixup","p":304655},{"n":"objectToBeFixed","p":917505},{"n":"objectRequired","p":917505}],"n":"RegisterFixup","d":1549839,"h":176095208975,"f":2},{"r":65537,"p":[{"n":"objectToBeFixed","p":917505},{"n":"member","p":78249985},{"n":"objectRequired","p":917505}],"n":"RecordFixup","d":1549839,"h":180390176271,"f":129},{"r":65537,"p":[{"n":"objectToBeFixed","p":917505},{"n":"memberName","p":1310721},{"n":"objectRequired","p":917505}],"n":"RecordDelayedFixup","d":1549839,"h":184685143567,"f":129},{"r":65537,"p":[{"n":"arrayToBeFixed","p":917505},{"n":"index","p":655361},{"n":"objectRequired","p":917505}],"n":"RecordArrayElementFixup","d":1549839,"h":188980110863,"f":129},{"r":65537,"p":[{"n":"arrayToBeFixed","p":917505},{"n":"indices","p":0},{"n":"objectRequired","p":917505}],"n":"RecordArrayElementFixup","o":"@$1","d":1549839,"h":193275078159,"f":129},{"r":65537,"n":"RaiseDeserializationEvent","d":1549839,"h":197570045455,"f":129},{"r":65537,"p":[{"n":"handler","p":239119}],"n":"AddOnDeserialization","d":1549839,"h":201865012751,"f":136},{"r":65537,"p":[{"n":"obj","p":131073}],"n":"AddOnDeserialized","d":1549839,"h":206159980047,"f":136},{"r":65537,"p":[{"n":"obj","p":131073}],"n":"RaiseOnDeserializedEvent","d":1549839,"h":210454947343,"f":136},{"r":65537,"p":[{"n":"obj","p":131073}],"n":"RaiseOnDeserializingEvent","d":1549839,"h":214749914639,"f":1}],"l":[{"t":655361,"n":"DefaultInitialSize","d":1549839,"h":4296517135,"f":34},{"t":655361,"n":"MaxArraySize","d":1549839,"h":8591484431,"f":34},{"t":655361,"n":"ArrayMask","d":1549839,"h":12886451727,"f":34},{"t":655361,"n":"MaxReferenceDepth","d":1549839,"h":17181419023,"f":34},{"t":1310721,"n":"ObjectManagerUnreferencedCodeMessage","d":1549839,"h":21476386319,"f":34},{"t":76677121,"n":"s_nullableValueField","d":1549839,"h":25771353615,"f":34},{"t":239119,"n":"_onDeserializationHandler","d":1549839,"h":30066320911,"f":2},{"t":1680911,"n":"_onDeserializedHandler","d":1549839,"h":34361288207,"f":2},{"t":0,"n":"_objects","d":1549839,"h":38656255503,"f":8},{"t":131073,"n":"_topObject","d":1549839,"h":42951222799,"f":8},{"t":1353231,"n":"_specialFixupObjects","d":1549839,"h":47246190095,"f":8},{"t":917505,"n":"_fixupCount","d":1549839,"h":51541157391,"f":8},{"t":1091087,"n":"_selector","d":1549839,"h":55836124687,"f":8},{"t":114098177,"n":"_context","d":1549839,"h":60131091983,"f":8}],"c":[{"p":[{"n":"selector","p":1091087},{"n":"context","p":114098177}],"n":".ctor","o":"$ctor$1","d":1549839,"h":64426059279,"f":1}],"h":1549839,"a":[{"t":70909953,"c":8660844545,"a":[{"v":"Formatter-based serialization is obsolete and should not be used.","t":1310721}],"n":[{"n":"DiagnosticId","v":"SYSLIB0050","t":1310721},{"n":"UrlFormat","v":"https://aka.ms/dotnet-warnings/{0}","t":1310721}]}]}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.Runtime.Serialization.ObjectManager`; }
        });
        
        $asm.$cls("$srsf.System.Runtime.Serialization.SerializationObjectManager", ($self) => class SerializationObjectManager extends $.$spc.System.Object
        {
            /*string*/ static SerializationObjectManagerUnreferencedCodeMessage = null;
            /*Dictionary<object, object>*/ _objectSeenTable = null;
            /*StreamingContext*/ _context;
            /*SerializationEventHandler?*/ _onSerializedHandler = null;
            $ctor$1(/*StreamingContext*/ context)
            {
                super.$ctor();
                {
                    this._context = context;
                    this._objectSeenTable = new ($.$spc.System.Collections.Generic.Dictionary$$$($.$spc.System.Object, $.$spc.System.Object))().$ctor$1();
                }
                return this;
            }
            /*void */ RegisterObject(/*object*/ obj)
            {
                /*SerializationEvents*/ let cache = $.$srsf.System.Runtime.Serialization.SerializationEventsCache.GetSerializationEventsForType($.$spc.System.Object.GetType.call(obj));
                if (cache.HasOnSerializingEvents)
                {
                    if (this._objectSeenTable.TryAdd(obj, $.$box(true, $.$spc.System.Boolean)))
                    {
                        cache.InvokeOnSerializing(obj, this._context);
                        this.AddOnSerialized(obj);
                    }
                }
            }
            /*void */ RaiseOnSerializedEvent()
            {
                return (this._onSerializedHandler?.Invoke(this._context) ?? null);
            }
            /*void */ AddOnSerialized(/*object*/ obj)
            {
                /*SerializationEvents*/ let cache = $.$srsf.System.Runtime.Serialization.SerializationEventsCache.GetSerializationEventsForType($.$spc.System.Object.GetType.call(obj));
                this._onSerializedHandler = cache.AddOnSerialized(obj, this._onSerializedHandler);
            }
            //default member initializer
            constructor()
            {
                super();
                this._context = $.$default($.$spc.System.Runtime.Serialization.StreamingContext);
            }
            //Static Initializer
            static $sinit()
            {
                {
                    this.SerializationObjectManagerUnreferencedCodeMessage = "SerializationObjectManager is not trim compatible because the type of objects being managed cannot be statically discovered.";
                }
            }
            static $h = 2008591;
            static $f = 0b10010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"m":[{"r":65537,"p":[{"n":"obj","p":131073}],"n":"RegisterObject","d":2008591,"h":25771812367,"f":1},{"r":65537,"n":"RaiseOnSerializedEvent","d":2008591,"h":30066779663,"f":1},{"r":65537,"p":[{"n":"obj","p":131073}],"n":"AddOnSerialized","d":2008591,"h":34361746959,"f":2}],"l":[{"t":1310721,"n":"SerializationObjectManagerUnreferencedCodeMessage","d":2008591,"h":4296975887,"f":34},{"t":$.$spc.System.Collections.Generic.Dictionary$$$($.$spc.System.Object, $.$spc.System.Object).$h,"n":"_objectSeenTable","d":2008591,"h":8591943183,"f":2},{"t":114098177,"n":"_context","d":2008591,"h":12886910479,"f":2},{"t":1680911,"n":"_onSerializedHandler","d":2008591,"h":17181877775,"f":2}],"c":[{"p":[{"n":"context","p":114098177}],"n":".ctor","o":"$ctor$1","d":2008591,"h":21476845071,"f":1}],"h":2008591,"a":[{"t":70909953,"c":8660844545,"a":[{"v":"Formatter-based serialization is obsolete and should not be used.","t":1310721}],"n":[{"n":"DiagnosticId","v":"SYSLIB0050","t":1310721},{"n":"UrlFormat","v":"https://aka.ms/dotnet-warnings/{0}","t":1310721}]}]}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.Runtime.Serialization.SerializationObjectManager`; }
        });
        
        $asm.$cls("$srsf.System.Runtime.Serialization.SerializationEvents", ($self) => class SerializationEvents extends $.$spc.System.Object
        {
            /*List<MethodInfo>?*/ _onSerializingMethods = null;
            /*List<MethodInfo>?*/ _onSerializedMethods = null;
            /*List<MethodInfo>?*/ _onDeserializingMethods = null;
            /*List<MethodInfo>?*/ _onDeserializedMethods = null;
            $ctor$1(/*Type?*/ t)
            {
                super.$ctor();
                {
                    this._onSerializingMethods = this.GetMethodsWithAttribute($.$spc.System.Runtime.Serialization.OnSerializingAttribute.$type, t);
                    this._onSerializedMethods = this.GetMethodsWithAttribute($.$spc.System.Runtime.Serialization.OnSerializedAttribute.$type, t);
                    this._onDeserializingMethods = this.GetMethodsWithAttribute($.$spc.System.Runtime.Serialization.OnDeserializingAttribute.$type, t);
                    this._onDeserializedMethods = this.GetMethodsWithAttribute($.$spc.System.Runtime.Serialization.OnDeserializedAttribute.$type, t);
                }
                return this;
            }
            /*List<MethodInfo>? */ GetMethodsWithAttribute(/*Type*/ attribute, /*Type?*/ t)
            {
                /*List<MethodInfo>?*/ let mi = null;
                /*Type?*/ let baseType = t;
                while($.$spc.System.Type.op_Inequality$1(baseType, null) && $.$spc.System.Type.op_Inequality$1(baseType, $.$spc.System.Object.$type))
                {
                    /*MethodInfo[]*/ let mis = baseType.GetMethods$1(2/*BindingFlags.DeclaredOnly*/ | 4/*BindingFlags.Instance*/ | 32/*BindingFlags.NonPublic*/ | 16/*BindingFlags.Public*/);
                    let $i1 = 0;
                    let $arr1 = mis;
                    while ($i1 < $arr1.length)
                    {
                        let m = $arr1[$i1++];
                        if (m.IsDefined(attribute, false))
                        {
                            mi ??= new ($.$spc.System.Collections.Generic.List$$($.$spc.System.Reflection.MethodInfo))().$ctor$1();
                            mi.Add(m);
                        }
                    }
                    baseType = baseType.BaseType;
                }
                mi?.Reverse();
                return mi;
            }
            /*bool */ get HasOnSerializingEvents()
            {
                return this._onSerializingMethods !== null || this._onSerializedMethods !== null;
            }
            /*void */ InvokeOnSerializing(/*object*/ obj, /*StreamingContext*/ context)
            {
                return $.$srsf.System.Runtime.Serialization.SerializationEvents.InvokeOnDelegate(obj, context, this._onSerializingMethods);
            }
            /*void */ InvokeOnDeserializing(/*object*/ obj, /*StreamingContext*/ context)
            {
                return $.$srsf.System.Runtime.Serialization.SerializationEvents.InvokeOnDelegate(obj, context, this._onDeserializingMethods);
            }
            /*void */ InvokeOnDeserialized(/*object*/ obj, /*StreamingContext*/ context)
            {
                return $.$srsf.System.Runtime.Serialization.SerializationEvents.InvokeOnDelegate(obj, context, this._onDeserializedMethods);
            }
            /*SerializationEventHandler? */ AddOnSerialized(/*object*/ obj, /*SerializationEventHandler?*/ handler)
            {
                return $.$srsf.System.Runtime.Serialization.SerializationEvents.AddOnDelegate(obj, handler, this._onSerializedMethods);
            }
            /*SerializationEventHandler? */ AddOnDeserialized(/*object*/ obj, /*SerializationEventHandler?*/ handler)
            {
                return $.$srsf.System.Runtime.Serialization.SerializationEvents.AddOnDelegate(obj, handler, this._onDeserializedMethods);
            }
            static /*void */ InvokeOnDelegate(/*object*/ obj, /*StreamingContext*/ context, /*List<MethodInfo>?*/ methods)
            {
                $.$spc.System.Diagnostics.Debug.Assert$1(obj !== null, "object should have been initialized");
                $.$srsf.System.Runtime.Serialization.SerializationEvents.AddOnDelegate(obj, null, methods)?.Invoke(context);
            }
            static /*SerializationEventHandler? */ AddOnDelegate(/*object*/ obj, /*SerializationEventHandler?*/ handler, /*List<MethodInfo>?*/ methods)
            {
                if (methods !== null)
                {
                    var $en3 = methods.GetEnumerator();
                    while ($en3.MoveNext())
                    {
                        var m = $en3.Current;
                        {
                            /*SerializationEventHandler*/ let onDeserialized = m.CreateDelegate$3($.$srsf.System.Runtime.Serialization.SerializationEventHandler, obj);
                            handler = $.$cast($.$spc.System.Delegate.Combine(handler, onDeserialized), $.$srsf.System.Runtime.Serialization.SerializationEventHandler);
                        }
                    }
                }
                return handler;
            }
            static $h = 1746447;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":262145,"g":{"r":0,"d":0,"h":34361484815,"f":8},"n":"HasOnSerializingEvents","d":1746447,"h":30066517519,"f":8}],"m":[{"r":$.$spc.System.Collections.Generic.List$$($.$spc.System.Reflection.MethodInfo).$h,"p":[{"n":"attribute","p":142606337},{"n":"t","p":142606337}],"n":"GetMethodsWithAttribute","d":1746447,"h":25771550223,"f":2},{"r":65537,"p":[{"n":"obj","p":131073},{"n":"context","p":114098177}],"n":"InvokeOnSerializing","d":1746447,"h":38656452111,"f":8},{"r":65537,"p":[{"n":"obj","p":131073},{"n":"context","p":114098177}],"n":"InvokeOnDeserializing","d":1746447,"h":42951419407,"f":8},{"r":65537,"p":[{"n":"obj","p":131073},{"n":"context","p":114098177}],"n":"InvokeOnDeserialized","d":1746447,"h":47246386703,"f":8},{"r":1680911,"p":[{"n":"obj","p":131073},{"n":"handler","p":1680911}],"n":"AddOnSerialized","d":1746447,"h":51541353999,"f":8},{"r":1680911,"p":[{"n":"obj","p":131073},{"n":"handler","p":1680911}],"n":"AddOnDeserialized","d":1746447,"h":55836321295,"f":8},{"r":65537,"p":[{"n":"obj","p":131073},{"n":"context","p":114098177},{"n":"methods","p":$.$spc.System.Collections.Generic.List$$($.$spc.System.Reflection.MethodInfo).$h}],"n":"InvokeOnDelegate","d":1746447,"h":60131288591,"f":34},{"r":1680911,"p":[{"n":"obj","p":131073},{"n":"handler","p":1680911},{"n":"methods","p":$.$spc.System.Collections.Generic.List$$($.$spc.System.Reflection.MethodInfo).$h}],"n":"AddOnDelegate","d":1746447,"h":64426255887,"f":34}],"l":[{"t":$.$spc.System.Collections.Generic.List$$($.$spc.System.Reflection.MethodInfo).$h,"n":"_onSerializingMethods","d":1746447,"h":4296713743,"f":2},{"t":$.$spc.System.Collections.Generic.List$$($.$spc.System.Reflection.MethodInfo).$h,"n":"_onSerializedMethods","d":1746447,"h":8591681039,"f":2},{"t":$.$spc.System.Collections.Generic.List$$($.$spc.System.Reflection.MethodInfo).$h,"n":"_onDeserializingMethods","d":1746447,"h":12886648335,"f":2},{"t":$.$spc.System.Collections.Generic.List$$($.$spc.System.Reflection.MethodInfo).$h,"n":"_onDeserializedMethods","d":1746447,"h":17181615631,"f":2}],"c":[{"p":[{"n":"t","p":142606337}],"n":".ctor","o":"$ctor$1","d":1746447,"h":21476582927,"f":8}],"h":1746447}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.Runtime.Serialization.SerializationEvents`; }
        });
        
        $asm.$cls("$srsf.System.Runtime.Serialization.ValueTypeFixupInfo", ($self) => class ValueTypeFixupInfo extends $.$spc.System.Object
        {
            /*long*/ _containerID = 0n;
            /*FieldInfo?*/ _parentField = null;
            /*int[]?*/ _parentIndex = null;
            $ctor$1(/*long*/ containerID, /*FieldInfo?*/ member, /*int[]?*/ parentIndex)
            {
                super.$ctor();
                {
                    if ($.$spc.System.Reflection.FieldInfo.op_Equality$1(member, null) && parentIndex === null)
                    {
                        throw new $.$spc.System.ArgumentException().$ctor$10($.$srsf.System.SR.Argument_MustSupplyParent);
                    }
                    if (containerID === 0n && $.$spc.System.Reflection.FieldInfo.op_Equality$1(member, null))
                    {
                        this._containerID = containerID;
                        this._parentField = member;
                        this._parentIndex = parentIndex;
                    }
                    if ($.$spc.System.Reflection.FieldInfo.op_Inequality$1(member, null))
                    {
                        if (parentIndex !== null)
                        {
                            throw new $.$spc.System.ArgumentException().$ctor$10($.$srsf.System.SR.Argument_MemberAndArray);
                        }
                        if (member.FieldType.IsValueType && containerID === 0n)
                        {
                            throw new $.$spc.System.ArgumentException().$ctor$10($.$srsf.System.SR.Argument_MustSupplyContainer);
                        }
                    }
                    this._containerID = containerID;
                    this._parentField = member;
                    this._parentIndex = parentIndex;
                }
                return this;
            }
            /*long */ get ContainerID()
            {
                return this._containerID;
            }
            /*FieldInfo? */ get ParentField()
            {
                return this._parentField;
            }
            /*int[]? */ get ParentIndex()
            {
                return this._parentIndex;
            }
            static $h = 2401807;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":917505,"g":{"r":0,"d":0,"h":25772205583,"f":1},"n":"ContainerID","d":2401807,"h":21477238287,"f":1},{"p":76677121,"g":{"r":0,"d":0,"h":34362140175,"f":1},"n":"ParentField","d":2401807,"h":30067172879,"f":1},{"p":0,"g":{"r":0,"d":0,"h":42952074767,"f":1},"n":"ParentIndex","d":2401807,"h":38657107471,"f":1}],"l":[{"t":917505,"n":"_containerID","d":2401807,"h":4297369103,"f":2},{"t":76677121,"n":"_parentField","d":2401807,"h":8592336399,"f":2},{"t":0,"n":"_parentIndex","d":2401807,"h":12887303695,"f":2}],"c":[{"p":[{"n":"containerID","p":917505},{"n":"member","p":76677121},{"n":"parentIndex","p":0}],"n":".ctor","o":"$ctor$1","d":2401807,"h":17182270991,"f":1}],"h":2401807}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.Runtime.Serialization.ValueTypeFixupInfo`; }
        });
        
        $asm.$cls("$srsf.System.Collections.HashHelpers", ($self) => class HashHelpers
        {
            /*uint*/ static HashCollisionThreshold = 100;
            /*int*/ static MaxPrimeArrayLength = 2147483587;
            /*int*/ static HashPrime = 101;
            static /*ReadOnlySpan<int> */ get Primes()
            {
                return this.$cachePrimes ??= new ($.$spc.System.ReadOnlySpan$$($.$spc.System.Int32))().$ctor$2([ 3, 7, 11, 17, 23, 29, 37, 47, 59, 71, 89, 107, 131, 163, 197, 239, 293, 353, 431, 521, 631, 761, 919, 1103, 1327, 1597, 1931, 2333, 2801, 3371, 4049, 4861, 5839, 7013, 8419, 10103, 12143, 14591, 17519, 21023, 25229, 30293, 36353, 43627, 52361, 62851, 75431, 90523, 108631, 130363, 156437, 187751, 225307, 270371, 324449, 389357, 467237, 560689, 672827, 807403, 968897, 1162687, 1395263, 1674319, 2009191, 2411033, 2893249, 3471899, 4166287, 4999559, 5999471, 7199369 ]);
            }
            static /*bool */ IsPrime(/*int*/ candidate)
            {
                if ((candidate & 1) !== 0)
                {
                    /*int*/ let limit = $.$cast(Math.sqrt(candidate), $.$spc.System.Int32);
                    for(/*int*/ let divisor = 3; divisor <= limit; divisor += 2)
                    {
                        if ((candidate % divisor) === 0)
                        {
                            return false;
                        }
                    }
                    return true;
                }
                return candidate === 2;
            }
            static /*int */ GetPrime(/*int*/ min)
            {
                if (min < 0)
                {
                    throw new $.$spc.System.ArgumentException().$ctor$10($.$srsf.System.SR.Arg_HTCapacityOverflow);
                }
                var $en2 = $.$srsf.System.Collections.HashHelpers.Primes.GetEnumerator();
                while ($en2.MoveNext())
                {
                    var prime = $en2.Current.$v;
                    {
                        if (prime >= min)
                        {
                            return prime;
                        }
                    }
                }
                for(/*int*/ let i = (min | 1); i < 2147483647/*int.MaxValue*/; i += 2)
                {
                    if ($.$srsf.System.Collections.HashHelpers.IsPrime(i) && ((((i - 1) | 0)) % 101/*HashPrime*/ !== 0))
                    {
                        return i;
                    }
                }
                return min;
            }
            static /*int */ ExpandPrime(/*int*/ oldSize)
            {
                /*int*/ let newSize = ((2 * oldSize) | 0);
                if ((newSize >>> 0) > 2147483587/*MaxPrimeArrayLength*/ && 2147483587/*MaxPrimeArrayLength*/ > oldSize)
                {
                    $.$spc.System.Diagnostics.Debug.Assert$1(2147483587/*MaxPrimeArrayLength*/ === $.$srsf.System.Collections.HashHelpers.GetPrime(2147483587/*MaxPrimeArrayLength*/), "Invalid MaxPrimeArrayLength");
                    return 2147483587/*MaxPrimeArrayLength*/;
                }
                return $.$srsf.System.Collections.HashHelpers.GetPrime(newSize);
            }
            static /*ulong */ GetFastModMultiplier(/*uint*/ divisor)
            {
                return 18446744073709551615n / BigInt(divisor) + 1n;
            }
            static /*uint */ FastMod(/*uint*/ value, /*uint*/ divisor, /*ulong*/ multiplier)
            {
                $.$spc.System.Diagnostics.Debug.Assert$1(divisor <= 2147483647/*int.MaxValue*/, "divisor <= int.MaxValue");
                /*uint*/ let highbits = $.$cast((((((multiplier * BigInt(value)) >> 32n) + 1n) * BigInt(divisor)) >> 32n), $.$spc.System.UInt32);
                $.$spc.System.Diagnostics.Debug.Assert$1(highbits === value % divisor, "highbits == value % divisor");
                return highbits;
            }
            static $h = 108047;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":$.$spc.System.ReadOnlySpan$$($.$spc.System.Int32).$h,"g":{"r":0,"d":0,"h":21474944527,"f":40},"n":"Primes","d":108047,"h":17179977231,"f":40}],"m":[{"r":262145,"p":[{"n":"candidate","p":655361}],"n":"IsPrime","d":108047,"h":25769911823,"f":33},{"r":655361,"p":[{"n":"min","p":655361}],"n":"GetPrime","d":108047,"h":30064879119,"f":33},{"r":655361,"p":[{"n":"oldSize","p":655361}],"n":"ExpandPrime","d":108047,"h":34359846415,"f":33},{"r":983041,"p":[{"n":"divisor","p":720897}],"n":"GetFastModMultiplier","d":108047,"h":38654813711,"f":33},{"r":720897,"p":[{"n":"value","p":720897},{"n":"divisor","p":720897},{"n":"multiplier","p":983041}],"n":"FastMod","d":108047,"h":42949781007,"f":33}],"l":[{"t":720897,"n":"HashCollisionThreshold","d":108047,"h":4295075343,"f":33},{"t":655361,"n":"MaxPrimeArrayLength","d":108047,"h":8590042639,"f":33},{"t":655361,"n":"HashPrime","d":108047,"h":12885009935,"f":33}],"h":108047}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.Collections.HashHelpers`; }
        });
        
        $asm.$cls("$srsf.System.Runtime.Serialization.SerializationEventsCache", ($self) => class SerializationEventsCache
        {
            /*ConcurrentDictionary<Type, SerializationEvents>*/ static s_cache = null;
            static /*SerializationEvents */ GetSerializationEventsForType(/*Type*/ t)
            {
                return $.$srsf.System.Runtime.Serialization.SerializationEventsCache.s_cache.GetOrAdd(t, new ($.$spc.System.Func$$$($.$spc.System.Type, $.$srsf.System.Runtime.Serialization.SerializationEvents))().$ctor(null, $.$srsf.System.Runtime.Serialization.SerializationEventsCache.CreateSerializationEvents));
            }
            static /*SerializationEvents */ CreateSerializationEvents(/*Type*/ t)
            {
                return new $.$srsf.System.Runtime.Serialization.SerializationEvents().$ctor$1(t);
            }
            //Static Initializer
            static $sinit()
            {
                {
                    this.s_cache = new ($.$scc.System.Collections.Concurrent.ConcurrentDictionary$$$($.$spc.System.Type, $.$srsf.System.Runtime.Serialization.SerializationEvents))().$ctor$1();
                }
            }
            static $h = 1811983;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"m":[{"r":1746447,"p":[{"n":"t","p":142606337}],"n":"GetSerializationEventsForType","d":1811983,"h":8591746575,"f":40},{"r":1746447,"p":[{"n":"t","p":142606337}],"n":"CreateSerializationEvents","d":1811983,"h":12886713871,"f":34}],"l":[{"t":$.$scc.System.Collections.Concurrent.ConcurrentDictionary$$$($.$spc.System.Type, $.$srsf.System.Runtime.Serialization.SerializationEvents).$h,"n":"s_cache","d":1811983,"h":4296779279,"f":34}],"h":1811983}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.Runtime.Serialization.SerializationEventsCache`; }
        });
        
        $asm.$cls("$srsf.System.Obsoletions", ($self) => class Obsoletions
        {
            /*string*/ static SharedUrlFormat = null;
            /*string*/ static SystemTextEncodingUTF7Message = null;
            /*string*/ static SystemTextEncodingUTF7DiagId = null;
            /*string*/ static PrincipalPermissionAttributeMessage = null;
            /*string*/ static PrincipalPermissionAttributeDiagId = null;
            /*string*/ static CodeAccessSecurityMessage = null;
            /*string*/ static CodeAccessSecurityDiagId = null;
            /*string*/ static ConstrainedExecutionRegionMessage = null;
            /*string*/ static ConstrainedExecutionRegionDiagId = null;
            /*string*/ static GlobalAssemblyCacheMessage = null;
            /*string*/ static GlobalAssemblyCacheDiagId = null;
            /*string*/ static ThreadAbortMessage = null;
            /*string*/ static ThreadResetAbortMessage = null;
            /*string*/ static ThreadAbortDiagId = null;
            /*string*/ static DefaultCryptoAlgorithmsMessage = null;
            /*string*/ static DefaultCryptoAlgorithmsDiagId = null;
            /*string*/ static CreatePdbGeneratorMessage = null;
            /*string*/ static CreatePdbGeneratorDiagId = null;
            /*string*/ static AuthenticationManagerMessage = null;
            /*string*/ static AuthenticationManagerDiagId = null;
            /*string*/ static RemotingApisMessage = null;
            /*string*/ static RemotingApisDiagId = null;
            /*string*/ static BinaryFormatterMessage = null;
            /*string*/ static BinaryFormatterDiagId = null;
            /*string*/ static CodeBaseMessage = null;
            /*string*/ static CodeBaseDiagId = null;
            /*string*/ static EscapeUriStringMessage = null;
            /*string*/ static EscapeUriStringDiagId = null;
            /*string*/ static WebRequestMessage = null;
            /*string*/ static WebRequestDiagId = null;
            /*string*/ static DisablePrivateReflectionAttributeMessage = null;
            /*string*/ static DisablePrivateReflectionAttributeDiagId = null;
            /*string*/ static GetContextInfoMessage = null;
            /*string*/ static GetContextInfoDiagId = null;
            /*string*/ static StrongNameKeyPairMessage = null;
            /*string*/ static StrongNameKeyPairDiagId = null;
            /*string*/ static ReflectionOnlyLoadingMessage = null;
            /*string*/ static ReflectionOnlyLoadingDiagId = null;
            /*string*/ static RuntimeEnvironmentMessage = null;
            /*string*/ static RuntimeEnvironmentDiagId = null;
            /*string*/ static JsonSerializerOptionsIgnoreNullValuesMessage = null;
            /*string*/ static JsonSerializerOptionsIgnoreNullValuesDiagId = null;
            /*string*/ static DerivedCryptographicTypesMessage = null;
            /*string*/ static DerivedCryptographicTypesDiagId = null;
            /*string*/ static RijndaelMessage = null;
            /*string*/ static RijndaelDiagId = null;
            /*string*/ static RNGCryptoServiceProviderMessage = null;
            /*string*/ static RNGCryptoServiceProviderDiagId = null;
            /*string*/ static AppDomainCreateUnloadMessage = null;
            /*string*/ static AppDomainCreateUnloadDiagId = null;
            /*string*/ static SuppressIldasmAttributeMessage = null;
            /*string*/ static SuppressIldasmAttributeDiagId = null;
            /*string*/ static X509CertificateImmutableMessage = null;
            /*string*/ static X509CertificateImmutableDiagId = null;
            /*string*/ static PublicKeyPropertyMessage = null;
            /*string*/ static PublicKeyPropertyDiagId = null;
            /*string*/ static X509CertificatePrivateKeyMessage = null;
            /*string*/ static X509CertificatePrivateKeyDiagId = null;
            /*string*/ static ProduceLegacyHmacValuesMessage = null;
            /*string*/ static ProduceLegacyHmacValuesDiagId = null;
            /*string*/ static UseManagedSha1Message = null;
            /*string*/ static UseManagedSha1DiagId = null;
            /*string*/ static CryptoConfigEncodeOIDMessage = null;
            /*string*/ static CryptoConfigEncodeOIDDiagId = null;
            /*string*/ static CorruptedStateRecoveryMessage = null;
            /*string*/ static CorruptedStateRecoveryDiagId = null;
            /*string*/ static Rfc2898CryptDeriveKeyMessage = null;
            /*string*/ static Rfc2898CryptDeriveKeyDiagId = null;
            /*string*/ static CmsSignerCspParamsCtorMessage = null;
            /*string*/ static CmsSignerCspParamsCtorDiagId = null;
            /*string*/ static SignerInfoCounterSigMessage = null;
            /*string*/ static SignerInfoCounterSigDiagId = null;
            /*string*/ static RegexCompileToAssemblyMessage = null;
            /*string*/ static RegexCompileToAssemblyDiagId = null;
            /*string*/ static AssemblyNameMembersMessage = null;
            /*string*/ static AssemblyNameMembersDiagId = null;
            /*string*/ static SystemDataSerializationFormatBinaryMessage = null;
            /*string*/ static SystemDataSerializationFormatBinaryDiagId = null;
            /*string*/ static TlsVersion10and11Message = null;
            /*string*/ static TlsVersion10and11DiagId = null;
            /*string*/ static EncryptionPolicyMessage = null;
            /*string*/ static EncryptionPolicyDiagId = null;
            /*string*/ static EccXmlExportImportMessage = null;
            /*string*/ static EccXmlExportImportDiagId = null;
            /*string*/ static EcDhPublicKeyBlobMessage = null;
            /*string*/ static EcDhPublicKeyBlobDiagId = null;
            /*string*/ static AssemblyNameCodeBaseMessage = null;
            /*string*/ static AssemblyNameCodeBaseDiagId = null;
            /*string*/ static CryptoStringFactoryMessage = null;
            /*string*/ static CryptoStringFactoryDiagId = null;
            /*string*/ static ControlledExecutionRunMessage = null;
            /*string*/ static ControlledExecutionRunDiagId = null;
            /*string*/ static XmlSecureResolverMessage = null;
            /*string*/ static XmlSecureResolverDiagId = null;
            /*string*/ static RsaEncryptDecryptValueMessage = null;
            /*string*/ static RsaEncryptDecryptDiagId = null;
            /*string*/ static JsonSerializerOptionsAddContextMessage = null;
            /*string*/ static JsonSerializerOptionsAddContextDiagId = null;
            /*string*/ static LegacyFormatterMessage = null;
            /*string*/ static LegacyFormatterDiagId = null;
            /*string*/ static LegacyFormatterImplMessage = null;
            /*string*/ static LegacyFormatterImplDiagId = null;
            /*string*/ static RegexExtensibilityImplMessage = null;
            /*string*/ static RegexExtensibilityDiagId = null;
            /*string*/ static AesGcmTagConstructorMessage = null;
            /*string*/ static AesGcmTagConstructorDiagId = null;
            /*string*/ static ThreadVolatileReadWriteMessage = null;
            /*string*/ static ThreadVolatileReadWriteDiagId = null;
            /*string*/ static ArmIntrinsicPerformsUnsignedOperationMessage = null;
            /*string*/ static ArmIntrinsicPerformsUnsignedOperationDiagId = null;
            /*string*/ static LoadFromHashAlgorithmMessage = null;
            /*string*/ static LoadFromHashAlgorithmDiagId = null;
            /*string*/ static X509CtorCertDataObsoleteMessage = null;
            /*string*/ static X509CtorCertDataObsoleteDiagId = null;
            /*string*/ static TlsCipherAlgorithmEnumsMessage = null;
            /*string*/ static TlsCipherAlgorithmEnumsDiagId = null;
            /*string*/ static SystemEventsEventsThreadShutdownMessage = null;
            /*string*/ static SystemEventsEventsThreadShutdownDiagId = null;
            /*string*/ static Rfc2898DeriveBytesCtorMessage = null;
            /*string*/ static Rfc2898DeriveBytesCtorDiagId = null;
            /*string*/ static QueryableMinByMaxByTSourceObsoleteMessage = null;
            /*string*/ static QueryableMinByMaxByTSourceObsoleteDiagId = null;
            /*string*/ static XsltSettingsEnableScriptMessage = null;
            /*string*/ static XsltSettingsEnableScriptDiagId = null;
            //Static Initializer
            static $sinit()
            {
                {
                    this.SharedUrlFormat = "https://aka.ms/dotnet-warnings/{0}";
                }
                {
                    this.SystemTextEncodingUTF7Message = "The UTF-7 encoding is insecure and should not be used. Consider using UTF-8 instead.";
                }
                {
                    this.SystemTextEncodingUTF7DiagId = "SYSLIB0001";
                }
                {
                    this.PrincipalPermissionAttributeMessage = "PrincipalPermissionAttribute is not honored by the runtime and must not be used.";
                }
                {
                    this.PrincipalPermissionAttributeDiagId = "SYSLIB0002";
                }
                {
                    this.CodeAccessSecurityMessage = "Code Access Security is not supported or honored by the runtime.";
                }
                {
                    this.CodeAccessSecurityDiagId = "SYSLIB0003";
                }
                {
                    this.ConstrainedExecutionRegionMessage = "The Constrained Execution Region (CER) feature is not supported.";
                }
                {
                    this.ConstrainedExecutionRegionDiagId = "SYSLIB0004";
                }
                {
                    this.GlobalAssemblyCacheMessage = "The Global Assembly Cache is not supported.";
                }
                {
                    this.GlobalAssemblyCacheDiagId = "SYSLIB0005";
                }
                {
                    this.ThreadAbortMessage = "Thread.Abort is not supported and throws PlatformNotSupportedException.";
                }
                {
                    this.ThreadResetAbortMessage = "Thread.ResetAbort is not supported and throws PlatformNotSupportedException.";
                }
                {
                    this.ThreadAbortDiagId = "SYSLIB0006";
                }
                {
                    this.DefaultCryptoAlgorithmsMessage = "The default implementation of this cryptography algorithm is not supported.";
                }
                {
                    this.DefaultCryptoAlgorithmsDiagId = "SYSLIB0007";
                }
                {
                    this.CreatePdbGeneratorMessage = "The CreatePdbGenerator API is not supported and throws PlatformNotSupportedException.";
                }
                {
                    this.CreatePdbGeneratorDiagId = "SYSLIB0008";
                }
                {
                    this.AuthenticationManagerMessage = "AuthenticationManager is not supported. Methods will no-op or throw PlatformNotSupportedException.";
                }
                {
                    this.AuthenticationManagerDiagId = "SYSLIB0009";
                }
                {
                    this.RemotingApisMessage = "This Remoting API is not supported and throws PlatformNotSupportedException.";
                }
                {
                    this.RemotingApisDiagId = "SYSLIB0010";
                }
                {
                    this.BinaryFormatterMessage = "BinaryFormatter serialization is obsolete and should not be used. See https://aka.ms/binaryformatter for more information.";
                }
                {
                    this.BinaryFormatterDiagId = "SYSLIB0011";
                }
                {
                    this.CodeBaseMessage = "Assembly.CodeBase and Assembly.EscapedCodeBase are only included for .NET Framework compatibility. Use Assembly.Location instead.";
                }
                {
                    this.CodeBaseDiagId = "SYSLIB0012";
                }
                {
                    this.EscapeUriStringMessage = "Uri.EscapeUriString can corrupt the Uri string in some cases. Consider using Uri.EscapeDataString for query string components instead.";
                }
                {
                    this.EscapeUriStringDiagId = "SYSLIB0013";
                }
                {
                    this.WebRequestMessage = "WebRequest, HttpWebRequest, ServicePoint, and WebClient are obsolete. Use HttpClient instead.";
                }
                {
                    this.WebRequestDiagId = "SYSLIB0014";
                }
                {
                    this.DisablePrivateReflectionAttributeMessage = "DisablePrivateReflectionAttribute has no effect in .NET 6.0+.";
                }
                {
                    this.DisablePrivateReflectionAttributeDiagId = "SYSLIB0015";
                }
                {
                    this.GetContextInfoMessage = "Use the Graphics.GetContextInfo overloads that accept arguments for better performance and fewer allocations.";
                }
                {
                    this.GetContextInfoDiagId = "SYSLIB0016";
                }
                {
                    this.StrongNameKeyPairMessage = "Strong name signing is not supported and throws PlatformNotSupportedException.";
                }
                {
                    this.StrongNameKeyPairDiagId = "SYSLIB0017";
                }
                {
                    this.ReflectionOnlyLoadingMessage = "ReflectionOnly loading is not supported and throws PlatformNotSupportedException.";
                }
                {
                    this.ReflectionOnlyLoadingDiagId = "SYSLIB0018";
                }
                {
                    this.RuntimeEnvironmentMessage = "RuntimeEnvironment members SystemConfigurationFile, GetRuntimeInterfaceAsIntPtr, and GetRuntimeInterfaceAsObject are not supported and throw PlatformNotSupportedException.";
                }
                {
                    this.RuntimeEnvironmentDiagId = "SYSLIB0019";
                }
                {
                    this.JsonSerializerOptionsIgnoreNullValuesMessage = "JsonSerializerOptions.IgnoreNullValues is obsolete. To ignore null values when serializing, set DefaultIgnoreCondition to JsonIgnoreCondition.WhenWritingNull.";
                }
                {
                    this.JsonSerializerOptionsIgnoreNullValuesDiagId = "SYSLIB0020";
                }
                {
                    this.DerivedCryptographicTypesMessage = "Derived cryptographic types are obsolete. Use the Create method on the base type instead.";
                }
                {
                    this.DerivedCryptographicTypesDiagId = "SYSLIB0021";
                }
                {
                    this.RijndaelMessage = "The Rijndael and RijndaelManaged types are obsolete. Use Aes instead.";
                }
                {
                    this.RijndaelDiagId = "SYSLIB0022";
                }
                {
                    this.RNGCryptoServiceProviderMessage = "RNGCryptoServiceProvider is obsolete. To generate a random number, use one of the RandomNumberGenerator static methods instead.";
                }
                {
                    this.RNGCryptoServiceProviderDiagId = "SYSLIB0023";
                }
                {
                    this.AppDomainCreateUnloadMessage = "Creating and unloading AppDomains is not supported and throws an exception.";
                }
                {
                    this.AppDomainCreateUnloadDiagId = "SYSLIB0024";
                }
                {
                    this.SuppressIldasmAttributeMessage = "SuppressIldasmAttribute has no effect in .NET 6.0+.";
                }
                {
                    this.SuppressIldasmAttributeDiagId = "SYSLIB0025";
                }
                {
                    this.X509CertificateImmutableMessage = "X509Certificate and X509Certificate2 are immutable. Use X509CertificateLoader to create a new certificate.";
                }
                {
                    this.X509CertificateImmutableDiagId = "SYSLIB0026";
                }
                {
                    this.PublicKeyPropertyMessage = "PublicKey.Key is obsolete. Use the appropriate method to get the public key, such as GetRSAPublicKey.";
                }
                {
                    this.PublicKeyPropertyDiagId = "SYSLIB0027";
                }
                {
                    this.X509CertificatePrivateKeyMessage = "X509Certificate2.PrivateKey is obsolete. Use the appropriate method to get the private key, such as GetRSAPrivateKey, or use the CopyWithPrivateKey method to create a new instance with a private key.";
                }
                {
                    this.X509CertificatePrivateKeyDiagId = "SYSLIB0028";
                }
                {
                    this.ProduceLegacyHmacValuesMessage = "ProduceLegacyHmacValues is obsolete. Producing legacy HMAC values is not supported.";
                }
                {
                    this.ProduceLegacyHmacValuesDiagId = "SYSLIB0029";
                }
                {
                    this.UseManagedSha1Message = "HMACSHA1 always uses the algorithm implementation provided by the platform. Use a constructor without the useManagedSha1 parameter.";
                }
                {
                    this.UseManagedSha1DiagId = "SYSLIB0030";
                }
                {
                    this.CryptoConfigEncodeOIDMessage = "EncodeOID is obsolete. Use the ASN.1 functionality provided in System.Formats.Asn1.";
                }
                {
                    this.CryptoConfigEncodeOIDDiagId = "SYSLIB0031";
                }
                {
                    this.CorruptedStateRecoveryMessage = "Recovery from corrupted process state exceptions is not supported; HandleProcessCorruptedStateExceptionsAttribute is ignored.";
                }
                {
                    this.CorruptedStateRecoveryDiagId = "SYSLIB0032";
                }
                {
                    this.Rfc2898CryptDeriveKeyMessage = "Rfc2898DeriveBytes.CryptDeriveKey is obsolete and is not supported. Use PasswordDeriveBytes.CryptDeriveKey instead.";
                }
                {
                    this.Rfc2898CryptDeriveKeyDiagId = "SYSLIB0033";
                }
                {
                    this.CmsSignerCspParamsCtorMessage = "CmsSigner(CspParameters) is obsolete and is not supported. Use an alternative constructor instead.";
                }
                {
                    this.CmsSignerCspParamsCtorDiagId = "SYSLIB0034";
                }
                {
                    this.SignerInfoCounterSigMessage = "ComputeCounterSignature without specifying a CmsSigner is obsolete and is not supported. Use the overload that accepts a CmsSigner.";
                }
                {
                    this.SignerInfoCounterSigDiagId = "SYSLIB0035";
                }
                {
                    this.RegexCompileToAssemblyMessage = "Regex.CompileToAssembly is obsolete and not supported. Use the GeneratedRegexAttribute with the regular expression source generator instead.";
                }
                {
                    this.RegexCompileToAssemblyDiagId = "SYSLIB0036";
                }
                {
                    this.AssemblyNameMembersMessage = "AssemblyName members HashAlgorithm, ProcessorArchitecture, and VersionCompatibility are obsolete and not supported.";
                }
                {
                    this.AssemblyNameMembersDiagId = "SYSLIB0037";
                }
                {
                    this.SystemDataSerializationFormatBinaryMessage = "SerializationFormat.Binary is obsolete and should not be used. See https://aka.ms/serializationformat-binary-obsolete for more information.";
                }
                {
                    this.SystemDataSerializationFormatBinaryDiagId = "SYSLIB0038";
                }
                {
                    this.TlsVersion10and11Message = "TLS versions 1.0 and 1.1 have known vulnerabilities and are not recommended. Use a newer TLS version instead, or use SslProtocols.None to defer to OS defaults.";
                }
                {
                    this.TlsVersion10and11DiagId = "SYSLIB0039";
                }
                {
                    this.EncryptionPolicyMessage = "EncryptionPolicy.NoEncryption and AllowEncryption significantly reduce security and should not be used in production code.";
                }
                {
                    this.EncryptionPolicyDiagId = "SYSLIB0040";
                }
                {
                    this.EccXmlExportImportMessage = "ToXmlString and FromXmlString have no implementation for ECC types, and are obsolete. Use a standard import and export format such as ExportSubjectPublicKeyInfo or ImportSubjectPublicKeyInfo for public keys and ExportPkcs8PrivateKey or ImportPkcs8PrivateKey for private keys.";
                }
                {
                    this.EccXmlExportImportDiagId = "SYSLIB0042";
                }
                {
                    this.EcDhPublicKeyBlobMessage = "ECDiffieHellmanPublicKey.ToByteArray() and the associated constructor do not have a consistent and interoperable implementation on all platforms. Use ECDiffieHellmanPublicKey.ExportSubjectPublicKeyInfo() instead.";
                }
                {
                    this.EcDhPublicKeyBlobDiagId = "SYSLIB0043";
                }
                {
                    this.AssemblyNameCodeBaseMessage = "AssemblyName.CodeBase and AssemblyName.EscapedCodeBase are obsolete. Using them for loading an assembly is not supported.";
                }
                {
                    this.AssemblyNameCodeBaseDiagId = "SYSLIB0044";
                }
                {
                    this.CryptoStringFactoryMessage = "Cryptographic factory methods accepting an algorithm name are obsolete. Use the parameterless Create factory method on the algorithm type instead.";
                }
                {
                    this.CryptoStringFactoryDiagId = "SYSLIB0045";
                }
                {
                    this.ControlledExecutionRunMessage = "ControlledExecution.Run method may corrupt the process and should not be used in production code.";
                }
                {
                    this.ControlledExecutionRunDiagId = "SYSLIB0046";
                }
                {
                    this.XmlSecureResolverMessage = "XmlSecureResolver is obsolete. Use XmlResolver.ThrowingResolver instead when attempting to forbid XML external entity resolution.";
                }
                {
                    this.XmlSecureResolverDiagId = "SYSLIB0047";
                }
                {
                    this.RsaEncryptDecryptValueMessage = "RSA.EncryptValue and DecryptValue are not supported and throw NotSupportedException. Use RSA.Encrypt and RSA.Decrypt instead.";
                }
                {
                    this.RsaEncryptDecryptDiagId = "SYSLIB0048";
                }
                {
                    this.JsonSerializerOptionsAddContextMessage = "JsonSerializerOptions.AddContext is obsolete. To register a JsonSerializerContext, use either the TypeInfoResolver or TypeInfoResolverChain properties.";
                }
                {
                    this.JsonSerializerOptionsAddContextDiagId = "SYSLIB0049";
                }
                {
                    this.LegacyFormatterMessage = "Formatter-based serialization is obsolete and should not be used.";
                }
                {
                    this.LegacyFormatterDiagId = "SYSLIB0050";
                }
                {
                    this.LegacyFormatterImplMessage = "This API supports obsolete formatter-based serialization. It should not be called or extended by application code.";
                }
                {
                    this.LegacyFormatterImplDiagId = "SYSLIB0051";
                }
                {
                    this.RegexExtensibilityImplMessage = "This API supports obsolete mechanisms for Regex extensibility. It is not supported.";
                }
                {
                    this.RegexExtensibilityDiagId = "SYSLIB0052";
                }
                {
                    this.AesGcmTagConstructorMessage = "AesGcm should indicate the required tag size for encryption and decryption. Use a constructor that accepts the tag size.";
                }
                {
                    this.AesGcmTagConstructorDiagId = "SYSLIB0053";
                }
                {
                    this.ThreadVolatileReadWriteMessage = "Thread.VolatileRead and Thread.VolatileWrite are obsolete. Use Volatile.Read or Volatile.Write respectively instead.";
                }
                {
                    this.ThreadVolatileReadWriteDiagId = "SYSLIB0054";
                }
                {
                    this.ArmIntrinsicPerformsUnsignedOperationMessage = "The underlying hardware instruction does not perform a signed saturate narrowing operation, and it always returns an unsigned result. Use the unsigned overload instead.";
                }
                {
                    this.ArmIntrinsicPerformsUnsignedOperationDiagId = "SYSLIB0055";
                }
                {
                    this.LoadFromHashAlgorithmMessage = "LoadFrom with a custom AssemblyHashAlgorithm is obsolete. Use overloads without an AssemblyHashAlgorithm.";
                }
                {
                    this.LoadFromHashAlgorithmDiagId = "SYSLIB0056";
                }
                {
                    this.X509CtorCertDataObsoleteMessage = "Loading certificate data through the constructor or Import is obsolete. Use X509CertificateLoader instead to load certificates.";
                }
                {
                    this.X509CtorCertDataObsoleteDiagId = "SYSLIB0057";
                }
                {
                    this.TlsCipherAlgorithmEnumsMessage = "KeyExchangeAlgorithm, KeyExchangeStrength, CipherAlgorithm, CipherStrength, HashAlgorithm and HashStrength properties of SslStream are obsolete. Use NegotiatedCipherSuite instead.";
                }
                {
                    this.TlsCipherAlgorithmEnumsDiagId = "SYSLIB0058";
                }
                {
                    this.SystemEventsEventsThreadShutdownMessage = "SystemEvents.EventsThreadShutdown callbacks are not run before the process exits. Use AppDomain.ProcessExit instead.";
                }
                {
                    this.SystemEventsEventsThreadShutdownDiagId = "SYSLIB0059";
                }
                {
                    this.Rfc2898DeriveBytesCtorMessage = "The constructors on Rfc2898DeriveBytes are obsolete. Use the static Pbkdf2 method instead.";
                }
                {
                    this.Rfc2898DeriveBytesCtorDiagId = "SYSLIB0060";
                }
                {
                    this.QueryableMinByMaxByTSourceObsoleteMessage = "The Queryable MinBy and MaxBy taking an IComparer<TSource> are obsolete. Use the new ones that take an IComparer<TKey>.";
                }
                {
                    this.QueryableMinByMaxByTSourceObsoleteDiagId = "SYSLIB0061";
                }
                {
                    this.XsltSettingsEnableScriptMessage = "XSLT Script blocks are not supported.";
                }
                {
                    this.XsltSettingsEnableScriptDiagId = "SYSLIB0062";
                }
            }
            static $h = 173583;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"l":[{"t":1310721,"n":"SharedUrlFormat","d":173583,"h":4295140879,"f":40},{"t":1310721,"n":"SystemTextEncodingUTF7Message","d":173583,"h":8590108175,"f":40},{"t":1310721,"n":"SystemTextEncodingUTF7DiagId","d":173583,"h":12885075471,"f":40},{"t":1310721,"n":"PrincipalPermissionAttributeMessage","d":173583,"h":17180042767,"f":40},{"t":1310721,"n":"PrincipalPermissionAttributeDiagId","d":173583,"h":21475010063,"f":40},{"t":1310721,"n":"CodeAccessSecurityMessage","d":173583,"h":25769977359,"f":40},{"t":1310721,"n":"CodeAccessSecurityDiagId","d":173583,"h":30064944655,"f":40},{"t":1310721,"n":"ConstrainedExecutionRegionMessage","d":173583,"h":34359911951,"f":40},{"t":1310721,"n":"ConstrainedExecutionRegionDiagId","d":173583,"h":38654879247,"f":40},{"t":1310721,"n":"GlobalAssemblyCacheMessage","d":173583,"h":42949846543,"f":40},{"t":1310721,"n":"GlobalAssemblyCacheDiagId","d":173583,"h":47244813839,"f":40},{"t":1310721,"n":"ThreadAbortMessage","d":173583,"h":51539781135,"f":40},{"t":1310721,"n":"ThreadResetAbortMessage","d":173583,"h":55834748431,"f":40},{"t":1310721,"n":"ThreadAbortDiagId","d":173583,"h":60129715727,"f":40},{"t":1310721,"n":"DefaultCryptoAlgorithmsMessage","d":173583,"h":64424683023,"f":40},{"t":1310721,"n":"DefaultCryptoAlgorithmsDiagId","d":173583,"h":68719650319,"f":40},{"t":1310721,"n":"CreatePdbGeneratorMessage","d":173583,"h":73014617615,"f":40},{"t":1310721,"n":"CreatePdbGeneratorDiagId","d":173583,"h":77309584911,"f":40},{"t":1310721,"n":"AuthenticationManagerMessage","d":173583,"h":81604552207,"f":40},{"t":1310721,"n":"AuthenticationManagerDiagId","d":173583,"h":85899519503,"f":40},{"t":1310721,"n":"RemotingApisMessage","d":173583,"h":90194486799,"f":40},{"t":1310721,"n":"RemotingApisDiagId","d":173583,"h":94489454095,"f":40},{"t":1310721,"n":"BinaryFormatterMessage","d":173583,"h":98784421391,"f":40},{"t":1310721,"n":"BinaryFormatterDiagId","d":173583,"h":103079388687,"f":40},{"t":1310721,"n":"CodeBaseMessage","d":173583,"h":107374355983,"f":40},{"t":1310721,"n":"CodeBaseDiagId","d":173583,"h":111669323279,"f":40},{"t":1310721,"n":"EscapeUriStringMessage","d":173583,"h":115964290575,"f":40},{"t":1310721,"n":"EscapeUriStringDiagId","d":173583,"h":120259257871,"f":40},{"t":1310721,"n":"WebRequestMessage","d":173583,"h":124554225167,"f":40},{"t":1310721,"n":"WebRequestDiagId","d":173583,"h":128849192463,"f":40},{"t":1310721,"n":"DisablePrivateReflectionAttributeMessage","d":173583,"h":133144159759,"f":40},{"t":1310721,"n":"DisablePrivateReflectionAttributeDiagId","d":173583,"h":137439127055,"f":40},{"t":1310721,"n":"GetContextInfoMessage","d":173583,"h":141734094351,"f":40},{"t":1310721,"n":"GetContextInfoDiagId","d":173583,"h":146029061647,"f":40},{"t":1310721,"n":"StrongNameKeyPairMessage","d":173583,"h":150324028943,"f":40},{"t":1310721,"n":"StrongNameKeyPairDiagId","d":173583,"h":154618996239,"f":40},{"t":1310721,"n":"ReflectionOnlyLoadingMessage","d":173583,"h":158913963535,"f":40},{"t":1310721,"n":"ReflectionOnlyLoadingDiagId","d":173583,"h":163208930831,"f":40},{"t":1310721,"n":"RuntimeEnvironmentMessage","d":173583,"h":167503898127,"f":40},{"t":1310721,"n":"RuntimeEnvironmentDiagId","d":173583,"h":171798865423,"f":40},{"t":1310721,"n":"JsonSerializerOptionsIgnoreNullValuesMessage","d":173583,"h":176093832719,"f":40},{"t":1310721,"n":"JsonSerializerOptionsIgnoreNullValuesDiagId","d":173583,"h":180388800015,"f":40},{"t":1310721,"n":"DerivedCryptographicTypesMessage","d":173583,"h":184683767311,"f":40},{"t":1310721,"n":"DerivedCryptographicTypesDiagId","d":173583,"h":188978734607,"f":40},{"t":1310721,"n":"RijndaelMessage","d":173583,"h":193273701903,"f":40},{"t":1310721,"n":"RijndaelDiagId","d":173583,"h":197568669199,"f":40},{"t":1310721,"n":"RNGCryptoServiceProviderMessage","d":173583,"h":201863636495,"f":40},{"t":1310721,"n":"RNGCryptoServiceProviderDiagId","d":173583,"h":206158603791,"f":40},{"t":1310721,"n":"AppDomainCreateUnloadMessage","d":173583,"h":210453571087,"f":40},{"t":1310721,"n":"AppDomainCreateUnloadDiagId","d":173583,"h":214748538383,"f":40},{"t":1310721,"n":"SuppressIldasmAttributeMessage","d":173583,"h":219043505679,"f":40},{"t":1310721,"n":"SuppressIldasmAttributeDiagId","d":173583,"h":223338472975,"f":40},{"t":1310721,"n":"X509CertificateImmutableMessage","d":173583,"h":227633440271,"f":40},{"t":1310721,"n":"X509CertificateImmutableDiagId","d":173583,"h":231928407567,"f":40},{"t":1310721,"n":"PublicKeyPropertyMessage","d":173583,"h":236223374863,"f":40},{"t":1310721,"n":"PublicKeyPropertyDiagId","d":173583,"h":240518342159,"f":40},{"t":1310721,"n":"X509CertificatePrivateKeyMessage","d":173583,"h":244813309455,"f":40},{"t":1310721,"n":"X509CertificatePrivateKeyDiagId","d":173583,"h":249108276751,"f":40},{"t":1310721,"n":"ProduceLegacyHmacValuesMessage","d":173583,"h":253403244047,"f":40},{"t":1310721,"n":"ProduceLegacyHmacValuesDiagId","d":173583,"h":257698211343,"f":40},{"t":1310721,"n":"UseManagedSha1Message","d":173583,"h":261993178639,"f":40},{"t":1310721,"n":"UseManagedSha1DiagId","d":173583,"h":266288145935,"f":40},{"t":1310721,"n":"CryptoConfigEncodeOIDMessage","d":173583,"h":270583113231,"f":40},{"t":1310721,"n":"CryptoConfigEncodeOIDDiagId","d":173583,"h":274878080527,"f":40},{"t":1310721,"n":"CorruptedStateRecoveryMessage","d":173583,"h":279173047823,"f":40},{"t":1310721,"n":"CorruptedStateRecoveryDiagId","d":173583,"h":283468015119,"f":40},{"t":1310721,"n":"Rfc2898CryptDeriveKeyMessage","d":173583,"h":287762982415,"f":40},{"t":1310721,"n":"Rfc2898CryptDeriveKeyDiagId","d":173583,"h":292057949711,"f":40},{"t":1310721,"n":"CmsSignerCspParamsCtorMessage","d":173583,"h":296352917007,"f":40},{"t":1310721,"n":"CmsSignerCspParamsCtorDiagId","d":173583,"h":300647884303,"f":40},{"t":1310721,"n":"SignerInfoCounterSigMessage","d":173583,"h":304942851599,"f":40},{"t":1310721,"n":"SignerInfoCounterSigDiagId","d":173583,"h":309237818895,"f":40},{"t":1310721,"n":"RegexCompileToAssemblyMessage","d":173583,"h":313532786191,"f":40},{"t":1310721,"n":"RegexCompileToAssemblyDiagId","d":173583,"h":317827753487,"f":40},{"t":1310721,"n":"AssemblyNameMembersMessage","d":173583,"h":322122720783,"f":40},{"t":1310721,"n":"AssemblyNameMembersDiagId","d":173583,"h":326417688079,"f":40},{"t":1310721,"n":"SystemDataSerializationFormatBinaryMessage","d":173583,"h":330712655375,"f":40},{"t":1310721,"n":"SystemDataSerializationFormatBinaryDiagId","d":173583,"h":335007622671,"f":40},{"t":1310721,"n":"TlsVersion10and11Message","d":173583,"h":339302589967,"f":40},{"t":1310721,"n":"TlsVersion10and11DiagId","d":173583,"h":343597557263,"f":40},{"t":1310721,"n":"EncryptionPolicyMessage","d":173583,"h":347892524559,"f":40},{"t":1310721,"n":"EncryptionPolicyDiagId","d":173583,"h":352187491855,"f":40},{"t":1310721,"n":"EccXmlExportImportMessage","d":173583,"h":356482459151,"f":40},{"t":1310721,"n":"EccXmlExportImportDiagId","d":173583,"h":360777426447,"f":40},{"t":1310721,"n":"EcDhPublicKeyBlobMessage","d":173583,"h":365072393743,"f":40},{"t":1310721,"n":"EcDhPublicKeyBlobDiagId","d":173583,"h":369367361039,"f":40},{"t":1310721,"n":"AssemblyNameCodeBaseMessage","d":173583,"h":373662328335,"f":40},{"t":1310721,"n":"AssemblyNameCodeBaseDiagId","d":173583,"h":377957295631,"f":40},{"t":1310721,"n":"CryptoStringFactoryMessage","d":173583,"h":382252262927,"f":40},{"t":1310721,"n":"CryptoStringFactoryDiagId","d":173583,"h":386547230223,"f":40},{"t":1310721,"n":"ControlledExecutionRunMessage","d":173583,"h":390842197519,"f":40},{"t":1310721,"n":"ControlledExecutionRunDiagId","d":173583,"h":395137164815,"f":40},{"t":1310721,"n":"XmlSecureResolverMessage","d":173583,"h":399432132111,"f":40},{"t":1310721,"n":"XmlSecureResolverDiagId","d":173583,"h":403727099407,"f":40},{"t":1310721,"n":"RsaEncryptDecryptValueMessage","d":173583,"h":408022066703,"f":40},{"t":1310721,"n":"RsaEncryptDecryptDiagId","d":173583,"h":412317033999,"f":40},{"t":1310721,"n":"JsonSerializerOptionsAddContextMessage","d":173583,"h":416612001295,"f":40},{"t":1310721,"n":"JsonSerializerOptionsAddContextDiagId","d":173583,"h":420906968591,"f":40},{"t":1310721,"n":"LegacyFormatterMessage","d":173583,"h":425201935887,"f":40},{"t":1310721,"n":"LegacyFormatterDiagId","d":173583,"h":429496903183,"f":40},{"t":1310721,"n":"LegacyFormatterImplMessage","d":173583,"h":433791870479,"f":40},{"t":1310721,"n":"LegacyFormatterImplDiagId","d":173583,"h":438086837775,"f":40},{"t":1310721,"n":"RegexExtensibilityImplMessage","d":173583,"h":442381805071,"f":40},{"t":1310721,"n":"RegexExtensibilityDiagId","d":173583,"h":446676772367,"f":40},{"t":1310721,"n":"AesGcmTagConstructorMessage","d":173583,"h":450971739663,"f":40},{"t":1310721,"n":"AesGcmTagConstructorDiagId","d":173583,"h":455266706959,"f":40},{"t":1310721,"n":"ThreadVolatileReadWriteMessage","d":173583,"h":459561674255,"f":40},{"t":1310721,"n":"ThreadVolatileReadWriteDiagId","d":173583,"h":463856641551,"f":40},{"t":1310721,"n":"ArmIntrinsicPerformsUnsignedOperationMessage","d":173583,"h":468151608847,"f":40},{"t":1310721,"n":"ArmIntrinsicPerformsUnsignedOperationDiagId","d":173583,"h":472446576143,"f":40},{"t":1310721,"n":"LoadFromHashAlgorithmMessage","d":173583,"h":476741543439,"f":40},{"t":1310721,"n":"LoadFromHashAlgorithmDiagId","d":173583,"h":481036510735,"f":40},{"t":1310721,"n":"X509CtorCertDataObsoleteMessage","d":173583,"h":485331478031,"f":40},{"t":1310721,"n":"X509CtorCertDataObsoleteDiagId","d":173583,"h":489626445327,"f":40},{"t":1310721,"n":"TlsCipherAlgorithmEnumsMessage","d":173583,"h":493921412623,"f":40},{"t":1310721,"n":"TlsCipherAlgorithmEnumsDiagId","d":173583,"h":498216379919,"f":40},{"t":1310721,"n":"SystemEventsEventsThreadShutdownMessage","d":173583,"h":502511347215,"f":40},{"t":1310721,"n":"SystemEventsEventsThreadShutdownDiagId","d":173583,"h":506806314511,"f":40},{"t":1310721,"n":"Rfc2898DeriveBytesCtorMessage","d":173583,"h":511101281807,"f":40},{"t":1310721,"n":"Rfc2898DeriveBytesCtorDiagId","d":173583,"h":515396249103,"f":40},{"t":1310721,"n":"QueryableMinByMaxByTSourceObsoleteMessage","d":173583,"h":519691216399,"f":40},{"t":1310721,"n":"QueryableMinByMaxByTSourceObsoleteDiagId","d":173583,"h":523986183695,"f":40},{"t":1310721,"n":"XsltSettingsEnableScriptMessage","d":173583,"h":528281150991,"f":40},{"t":1310721,"n":"XsltSettingsEnableScriptDiagId","d":173583,"h":532576118287,"f":40}],"h":173583}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.Obsoletions`; }
        });
        
        $asm.$cls("$srsf.System.Runtime.Serialization.SurrogateKey", ($self) => class SurrogateKey extends $.$spc.System.Object
        {
            /*Type*/ _type = null;
            /*StreamingContext*/ _context;
            $ctor$1(/*Type*/ type, /*StreamingContext*/ context)
            {
                super.$ctor();
                {
                    $.$spc.System.Diagnostics.Debug.Assert$1($.$spc.System.Type.op_Inequality$1(type, null), "type != null");
                    this._type = type;
                    this._context = context;
                }
                return this;
            }
            static/*conventional*/ /*int */ GetHashCode()
            {
                return $.$spc.System.Type.GetHashCode.call(this._type);
            }
            //Static convention instance redirect
            /*int */ GetHashCode() { return $.$srsf.System.Runtime.Serialization.SurrogateKey.GetHashCode.apply(this, arguments); }
            //default member initializer
            constructor()
            {
                super();
                this._context = $.$default($.$spc.System.Runtime.Serialization.StreamingContext);
            }
            static $h = 2205199;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"m":[{"r":655361,"n":"GetHashCode","d":2205199,"h":17182074383,"f":32769}],"l":[{"t":142606337,"n":"_type","d":2205199,"h":4297172495,"f":8},{"t":114098177,"n":"_context","d":2205199,"h":8592139791,"f":8}],"c":[{"p":[{"n":"type","p":142606337},{"n":"context","p":114098177}],"n":".ctor","o":"$ctor$1","d":2205199,"h":12887107087,"f":8}],"h":2205199}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.Runtime.Serialization.SurrogateKey`; }
        });
        
        $asm.$cls("$srsf.System.Runtime.Serialization.ObjectHolder", ($self) => class ObjectHolder extends $.$spc.System.Object
        {
            /*int*/ static IncompleteObjectReference = 1;
            /*int*/ static HAS_ISERIALIZABLE = 2;
            /*int*/ static HAS_SURROGATE = 4;
            /*int*/ static REQUIRES_VALUETYPE_FIXUP = 8;
            /*int*/ static REQUIRES_DELAYED_FIXUP = 7;
            /*int*/ static SER_INFO_FIXED = 16384;
            /*int*/ static VALUETYPE_FIXUP_PERFORMED = 32768;
            /*object?*/ _object = null;
            /*long*/ _id = 0n;
            /*int*/ _missingElementsRemaining = 0;
            /*int*/ _missingDecendents = 0;
            /*SerializationInfo?*/ _serInfo = null;
            /*ISerializationSurrogate?*/ _surrogate = null;
            /*FixupHolderList?*/ _missingElements = null;
            /*LongList?*/ _dependentObjects = null;
            /*ObjectHolder?*/ _next = null;
            /*int*/ _flags = 0;
            /*bool*/ _markForFixupWhenAvailable = false;
            /*ValueTypeFixupInfo?*/ _valueFixup = null;
            /*TypeLoadExceptionHolder?*/ _typeLoad = null;
            /*bool*/ _reachable = false;
            $ctor$1(/*long*/ objID)
            {
                this.$ctor$3(null, objID, null, null, 0n, null, null);
                {
                }
                return this;
            }
            $ctor$2(/*object?*/ obj, /*long*/ objID, /*SerializationInfo?*/ info, /*ISerializationSurrogate?*/ surrogate, /*long*/ idOfContainingObj, /*FieldInfo?*/ field, /*int[]?*/ arrayIndex)
            {
                super.$ctor();
                {
                    $.$spc.System.Diagnostics.Debug.Assert$1(objID >= 0n, "objID>=0");
                    this._object = obj;
                    this._id = objID;
                    this._flags = 0;
                    this._missingElementsRemaining = 0;
                    this._missingDecendents = 0;
                    this._dependentObjects = null;
                    this._next = null;
                    this._serInfo = info;
                    this._surrogate = surrogate;
                    this._markForFixupWhenAvailable = false;
                    if ($.$is(obj, $.$srsf.System.Runtime.Serialization.TypeLoadExceptionHolder))
                    {
                        this._typeLoad = $.$cast(obj, $.$srsf.System.Runtime.Serialization.TypeLoadExceptionHolder);
                    }
                    if (idOfContainingObj !== 0n && (($.$spc.System.Reflection.FieldInfo.op_Inequality$1(field, null) && field.FieldType.IsValueType) || arrayIndex !== null))
                    {
                        if (idOfContainingObj === objID)
                        {
                            throw new $.$spc.System.Runtime.Serialization.SerializationException().$ctor$10($.$srsf.System.SR.Serialization_ParentChildIdentical);
                        }
                        this._valueFixup = new $.$srsf.System.Runtime.Serialization.ValueTypeFixupInfo().$ctor$1(idOfContainingObj, field, arrayIndex);
                    }
                    this.SetFlags();
                }
                return this;
            }
            $ctor$3(/*string?*/ obj, /*long*/ objID, /*SerializationInfo?*/ info, /*ISerializationSurrogate?*/ surrogate, /*long*/ idOfContainingObj, /*FieldInfo?*/ field, /*int[]?*/ arrayIndex)
            {
                super.$ctor();
                {
                    $.$spc.System.Diagnostics.Debug.Assert$1(objID >= 0n, "objID>=0");
                    this._object = obj;
                    this._id = objID;
                    this._flags = 0;
                    this._missingElementsRemaining = 0;
                    this._missingDecendents = 0;
                    this._dependentObjects = null;
                    this._next = null;
                    this._serInfo = info;
                    this._surrogate = surrogate;
                    this._markForFixupWhenAvailable = false;
                    if (idOfContainingObj !== 0n && arrayIndex !== null)
                    {
                        this._valueFixup = new $.$srsf.System.Runtime.Serialization.ValueTypeFixupInfo().$ctor$1(idOfContainingObj, field, arrayIndex);
                    }
                    if (this._valueFixup !== null)
                    {
                        this._flags |= 8/*REQUIRES_VALUETYPE_FIXUP*/;
                    }
                }
                return this;
            }
            /*void */ IncrementDescendentFixups(/*int*/ amount)
            {
                return this._missingDecendents += amount;
            }
            /*void */ DecrementFixupsRemaining(/*ObjectManager*/ manager)
            {
                this._missingElementsRemaining--;
                if (this.RequiresValueTypeFixup)
                {
                    this.UpdateDescendentDependencyChain(-1, manager);
                }
            }
            /*void */ RemoveDependency(/*long*/ id)
            {
                $.$spc.System.Diagnostics.Debug.Assert$1(this._dependentObjects !== null, "[ObjectHolder.RemoveDependency]m_dependentObjects!=null");
                $.$spc.System.Diagnostics.Debug.Assert$1(id >= 0n, "[ObjectHolder.RemoveDependency]id>=0");
                this._dependentObjects.RemoveElement(id);
            }
            /*void */ AddFixup(/*FixupHolder*/ fixup, /*ObjectManager*/ manager)
            {
                this._missingElements ??= new $.$srsf.System.Runtime.Serialization.FixupHolderList().$ctor$1();
                this._missingElements.Add(fixup);
                this._missingElementsRemaining++;
                if (this.RequiresValueTypeFixup)
                {
                    this.UpdateDescendentDependencyChain(1, manager);
                }
            }
            /*void */ UpdateDescendentDependencyChain(/*int*/ amount, /*ObjectManager*/ manager)
            {
                /*ObjectHolder*/ let holder = this;
                do
                {
                    holder = manager.FindOrCreateObjectHolder(holder.ContainerID);
                    $.$spc.System.Diagnostics.Debug.Assert$1(holder !== null, "[ObjectHolder.UpdateTotalDependencyChain]holder!=null");
                    holder.IncrementDescendentFixups(amount);
                }
                while(holder.RequiresValueTypeFixup);
            }
            /*void */ AddDependency(/*long*/ dependentObject)
            {
                this._dependentObjects ??= new $.$srsf.System.Runtime.Serialization.LongList().$ctor$1();
                this._dependentObjects.Add(dependentObject);
            }
            /*void */ UpdateData(/*object*/ obj, /*SerializationInfo?*/ info, /*ISerializationSurrogate?*/ surrogate, /*long*/ idOfContainer, /*FieldInfo?*/ field, /*int[]?*/ arrayIndex, /*ObjectManager*/ manager)
            {
                $.$spc.System.Diagnostics.Debug.Assert$1(obj !== null, "obj!=null");
                $.$spc.System.Diagnostics.Debug.Assert$1(this._id > 0n, "m_id>0");
                this.SetObjectValue(obj, manager);
                this._serInfo = info;
                this._surrogate = surrogate;
                if (idOfContainer !== 0n && (($.$spc.System.Reflection.FieldInfo.op_Inequality$1(field, null) && field.FieldType.IsValueType) || arrayIndex !== null))
                {
                    if (idOfContainer === this._id)
                    {
                        throw new $.$spc.System.Runtime.Serialization.SerializationException().$ctor$10($.$srsf.System.SR.Serialization_ParentChildIdentical);
                    }
                    this._valueFixup = new $.$srsf.System.Runtime.Serialization.ValueTypeFixupInfo().$ctor$1(idOfContainer, field, arrayIndex);
                }
                this.SetFlags();
                if (this.RequiresValueTypeFixup)
                {
                    this.UpdateDescendentDependencyChain(this._missingElementsRemaining, manager);
                }
            }
            /*void */ MarkForCompletionWhenAvailable()
            {
                return this._markForFixupWhenAvailable = true;
            }
            /*void */ SetFlags()
            {
                if ($.$is(this._object, $.$spc.System.Runtime.Serialization.IObjectReference))
                {
                    this._flags |= 1/*IncompleteObjectReference*/;
                }
                this._flags &= ~(2/*HAS_ISERIALIZABLE*/ | 4/*HAS_SURROGATE*/);
                if (this._surrogate !== null)
                {
                    this._flags |= 4/*HAS_SURROGATE*/;
                }
                else if ($.$is(this._object, $.$spc.System.Runtime.Serialization.ISerializable))
                {
                    this._flags |= 2/*HAS_ISERIALIZABLE*/;
                }
                if (this._valueFixup !== null)
                {
                    this._flags |= 8/*REQUIRES_VALUETYPE_FIXUP*/;
                }
            }
            /*bool */ get IsIncompleteObjectReference()
            {
                return (this._flags & 1/*IncompleteObjectReference*/) !== 0;
            }
            /*bool */ set IsIncompleteObjectReference(value)
            {
                if (value)
                {
                    this._flags |= 1/*IncompleteObjectReference*/;
                }
                else 
                {
                    this._flags &= ~1/*IncompleteObjectReference*/;
                }
            }
            /*bool */ get RequiresDelayedFixup()
            {
                return (this._flags & 7/*REQUIRES_DELAYED_FIXUP*/) !== 0;
            }
            /*bool */ get RequiresValueTypeFixup()
            {
                return (this._flags & 8/*REQUIRES_VALUETYPE_FIXUP*/) !== 0;
            }
            /*bool */ get ValueTypeFixupPerformed()
            {
                return (((this._flags & 32768/*VALUETYPE_FIXUP_PERFORMED*/) !== 0) || (this._object !== null && ((this._dependentObjects === null) || this._dependentObjects.Count === 0)));
            }
            /*bool */ set ValueTypeFixupPerformed(value)
            {
                if (value)
                {
                    this._flags |= 32768/*VALUETYPE_FIXUP_PERFORMED*/;
                }
            }
            /*bool */ get HasISerializable()
            {
                return (this._flags & 2/*HAS_ISERIALIZABLE*/) !== 0;
            }
            /*bool */ get HasSurrogate()
            {
                return (this._flags & 4/*HAS_SURROGATE*/) !== 0;
            }
            /*bool */ get CanSurrogatedObjectValueChange()
            {
                return (this._surrogate === null || $.$spc.System.Type.op_Inequality$1($.$spc.System.Object.GetType.call(this._surrogate), $.$srsf.System.Runtime.Serialization.SurrogateForCyclicalReference.$type));
            }
            /*bool */ get CanObjectValueChange()
            {
                return this.IsIncompleteObjectReference ? true : this.HasSurrogate ? this.CanSurrogatedObjectValueChange : false;
            }
            /*int */ get DirectlyDependentObjects()
            {
                return this._missingElementsRemaining;
            }
            /*int */ get TotalDependentObjects()
            {
                return ((this._missingElementsRemaining + this._missingDecendents) | 0);
            }
            /*bool */ get Reachable()
            {
                return this._reachable;
            }
            /*bool */ set Reachable(value)
            {
                this._reachable = value;
            }
            /*bool */ get TypeLoadExceptionReachable()
            {
                return this._typeLoad !== null;
            }
            /*TypeLoadExceptionHolder? */ get TypeLoadException()
            {
                return this._typeLoad;
            }
            /*TypeLoadExceptionHolder? */ set TypeLoadException(value)
            {
                this._typeLoad = value;
            }
            /*object? */ get ObjectValue()
            {
                return this._object;
            }
            /*void */ SetObjectValue(/*object?*/ obj, /*ObjectManager*/ manager)
            {
                this._object = obj;
                if (obj === manager.TopObject)
                {
                    this._reachable = true;
                }
                if ($.$is(obj, $.$srsf.System.Runtime.Serialization.TypeLoadExceptionHolder))
                {
                    this._typeLoad = $.$cast(obj, $.$srsf.System.Runtime.Serialization.TypeLoadExceptionHolder);
                }
                if (this._markForFixupWhenAvailable)
                {
                    manager.CompleteObject(this, true);
                }
            }
            /*SerializationInfo? */ get SerializationInfo()
            {
                return this._serInfo;
            }
            /*SerializationInfo? */ set SerializationInfo(value)
            {
                this._serInfo = value;
            }
            /*ISerializationSurrogate? */ get Surrogate()
            {
                return this._surrogate;
            }
            /*LongList? */ get DependentObjects()
            {
                return this._dependentObjects;
            }
            /*LongList? */ set DependentObjects(value)
            {
                this._dependentObjects = value;
            }
            /*bool */ get RequiresSerInfoFixup()
            {
                if (((this._flags & 4/*HAS_SURROGATE*/) === 0) && ((this._flags & 2/*HAS_ISERIALIZABLE*/) === 0))
                {
                    return false;
                }
                return (this._flags & 16384/*SER_INFO_FIXED*/) === 0;
            }
            /*bool */ set RequiresSerInfoFixup(value)
            {
                if (!value)
                {
                    this._flags |= 16384/*SER_INFO_FIXED*/;
                }
                else 
                {
                    this._flags &= ~16384/*SER_INFO_FIXED*/;
                }
            }
            /*ValueTypeFixupInfo? */ get ValueFixup()
            {
                return this._valueFixup;
            }
            /*bool */ get CompletelyFixed()
            {
                return !this.RequiresSerInfoFixup && !this.IsIncompleteObjectReference;
            }
            /*long */ get ContainerID()
            {
                return this._valueFixup !== null ? this._valueFixup.ContainerID : 0n;
            }
            static $h = 1287695;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":262145,"g":{"r":0,"d":0,"h":150325143055,"f":8},"s":{"r":0,"d":0,"h":154620110351,"f":8},"n":"IsIncompleteObjectReference","d":1287695,"h":146030175759,"f":8},{"p":262145,"g":{"r":0,"d":0,"h":163210044943,"f":8},"n":"RequiresDelayedFixup","d":1287695,"h":158915077647,"f":8},{"p":262145,"g":{"r":0,"d":0,"h":171799979535,"f":8},"n":"RequiresValueTypeFixup","d":1287695,"h":167505012239,"f":8},{"p":262145,"g":{"r":0,"d":0,"h":180389914127,"f":8},"s":{"r":0,"d":0,"h":184684881423,"f":8},"n":"ValueTypeFixupPerformed","d":1287695,"h":176094946831,"f":8},{"p":262145,"g":{"r":0,"d":0,"h":193274816015,"f":8},"n":"HasISerializable","d":1287695,"h":188979848719,"f":8},{"p":262145,"g":{"r":0,"d":0,"h":201864750607,"f":8},"n":"HasSurrogate","d":1287695,"h":197569783311,"f":8},{"p":262145,"g":{"r":0,"d":0,"h":210454685199,"f":8},"n":"CanSurrogatedObjectValueChange","d":1287695,"h":206159717903,"f":8},{"p":262145,"g":{"r":0,"d":0,"h":219044619791,"f":8},"n":"CanObjectValueChange","d":1287695,"h":214749652495,"f":8},{"p":655361,"g":{"r":0,"d":0,"h":227634554383,"f":8},"n":"DirectlyDependentObjects","d":1287695,"h":223339587087,"f":8},{"p":655361,"g":{"r":0,"d":0,"h":236224488975,"f":8},"n":"TotalDependentObjects","d":1287695,"h":231929521679,"f":8},{"p":262145,"g":{"r":0,"d":0,"h":244814423567,"f":8},"s":{"r":0,"d":0,"h":249109390863,"f":8},"n":"Reachable","d":1287695,"h":240519456271,"f":8},{"p":262145,"g":{"r":0,"d":0,"h":257699325455,"f":8},"n":"TypeLoadExceptionReachable","d":1287695,"h":253404358159,"f":8},{"p":131073,"g":{"r":0,"d":0,"h":279174161935,"f":8},"n":"ObjectValue","d":1287695,"h":274879194639,"f":8},{"p":113967105,"g":{"r":0,"d":0,"h":292059063823,"f":8},"s":{"r":0,"d":0,"h":296354031119,"f":8},"n":"SerializationInfo","d":1287695,"h":287764096527,"f":8},{"p":1025551,"g":{"r":0,"d":0,"h":304943965711,"f":8},"n":"Surrogate","d":1287695,"h":300648998415,"f":8},{"p":1156623,"g":{"r":0,"d":0,"h":313533900303,"f":8},"s":{"r":0,"d":0,"h":317828867599,"f":8},"n":"DependentObjects","d":1287695,"h":309238933007,"f":8},{"p":262145,"g":{"r":0,"d":0,"h":326418802191,"f":8},"s":{"r":0,"d":0,"h":330713769487,"f":8},"n":"RequiresSerInfoFixup","d":1287695,"h":322123834895,"f":8},{"p":2401807,"g":{"r":0,"d":0,"h":339303704079,"f":8},"n":"ValueFixup","d":1287695,"h":335008736783,"f":8},{"p":262145,"g":{"r":0,"d":0,"h":347893638671,"f":8},"n":"CompletelyFixed","d":1287695,"h":343598671375,"f":8},{"p":917505,"g":{"r":0,"d":0,"h":356483573263,"f":8},"n":"ContainerID","d":1287695,"h":352188605967,"f":8}],"m":[{"r":65537,"p":[{"n":"amount","p":655361}],"n":"IncrementDescendentFixups","d":1287695,"h":107375470095,"f":2},{"r":65537,"p":[{"n":"manager","p":1549839}],"n":"DecrementFixupsRemaining","d":1287695,"h":111670437391,"f":8},{"r":65537,"p":[{"n":"id","p":917505}],"n":"RemoveDependency","d":1287695,"h":115965404687,"f":8},{"r":65537,"p":[{"n":"fixup","p":304655},{"n":"manager","p":1549839}],"n":"AddFixup","d":1287695,"h":120260371983,"f":8},{"r":65537,"p":[{"n":"amount","p":655361},{"n":"manager","p":1549839}],"n":"UpdateDescendentDependencyChain","d":1287695,"h":124555339279,"f":2},{"r":65537,"p":[{"n":"dependentObject","p":917505}],"n":"AddDependency","d":1287695,"h":128850306575,"f":8},{"r":65537,"p":[{"n":"obj","p":131073},{"n":"info","p":113967105},{"n":"surrogate","p":1025551},{"n":"idOfContainer","p":917505},{"n":"field","p":76677121},{"n":"arrayIndex","p":0},{"n":"manager","p":1549839}],"n":"UpdateData","d":1287695,"h":133145273871,"f":8},{"r":65537,"n":"MarkForCompletionWhenAvailable","d":1287695,"h":137440241167,"f":8},{"r":65537,"n":"SetFlags","d":1287695,"h":141735208463,"f":8},{"r":65537,"p":[{"n":"obj","p":131073},{"n":"manager","p":1549839}],"n":"SetObjectValue","d":1287695,"h":283469129231,"f":8}],"l":[{"t":655361,"n":"IncompleteObjectReference","d":1287695,"h":4296254991,"f":40},{"t":655361,"n":"HAS_ISERIALIZABLE","d":1287695,"h":8591222287,"f":40},{"t":655361,"n":"HAS_SURROGATE","d":1287695,"h":12886189583,"f":40},{"t":655361,"n":"REQUIRES_VALUETYPE_FIXUP","d":1287695,"h":17181156879,"f":40},{"t":655361,"n":"REQUIRES_DELAYED_FIXUP","d":1287695,"h":21476124175,"f":40},{"t":655361,"n":"SER_INFO_FIXED","d":1287695,"h":25771091471,"f":40},{"t":655361,"n":"VALUETYPE_FIXUP_PERFORMED","d":1287695,"h":30066058767,"f":40},{"t":131073,"n":"_object","d":1287695,"h":34361026063,"f":2},{"t":917505,"n":"_id","d":1287695,"h":38655993359,"f":8},{"t":655361,"n":"_missingElementsRemaining","d":1287695,"h":42950960655,"f":2},{"t":655361,"n":"_missingDecendents","d":1287695,"h":47245927951,"f":2},{"t":113967105,"n":"_serInfo","d":1287695,"h":51540895247,"f":8},{"t":1025551,"n":"_surrogate","d":1287695,"h":55835862543,"f":8},{"t":370191,"n":"_missingElements","d":1287695,"h":60130829839,"f":8},{"t":1156623,"n":"_dependentObjects","d":1287695,"h":64425797135,"f":8},{"t":1287695,"n":"_next","d":1287695,"h":68720764431,"f":8},{"t":655361,"n":"_flags","d":1287695,"h":73015731727,"f":8},{"t":262145,"n":"_markForFixupWhenAvailable","d":1287695,"h":77310699023,"f":2},{"t":2401807,"n":"_valueFixup","d":1287695,"h":81605666319,"f":2},{"t":2336271,"n":"_typeLoad","d":1287695,"h":85900633615,"f":2},{"t":262145,"n":"_reachable","d":1287695,"h":90195600911,"f":2}],"c":[{"p":[{"n":"objID","p":917505}],"n":".ctor","o":"$ctor$1","d":1287695,"h":94490568207,"f":8},{"p":[{"n":"obj","p":131073},{"n":"objID","p":917505},{"n":"info","p":113967105},{"n":"surrogate","p":1025551},{"n":"idOfContainingObj","p":917505},{"n":"field","p":76677121},{"n":"arrayIndex","p":0}],"n":".ctor","o":"$ctor$2","d":1287695,"h":98785535503,"f":8},{"p":[{"n":"obj","p":1310721},{"n":"objID","p":917505},{"n":"info","p":113967105},{"n":"surrogate","p":1025551},{"n":"idOfContainingObj","p":917505},{"n":"field","p":76677121},{"n":"arrayIndex","p":0}],"n":".ctor","o":"$ctor$3","d":1287695,"h":103080502799,"f":8}],"h":1287695}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.Runtime.Serialization.ObjectHolder`; }
        });
        
        $asm.$cls("$srsf.System.Runtime.Serialization.FixupHolder", ($self) => class FixupHolder extends $.$spc.System.Object
        {
            /*int*/ static ArrayFixup = 1;
            /*int*/ static MemberFixup = 2;
            /*int*/ static DelayedFixup = 4;
            /*long*/ _id = 0n;
            /*object*/ _fixupInfo = null;
            /*int*/ _fixupType = 0;
            $ctor$1(/*long*/ id, /*object*/ fixupInfo, /*int*/ fixupType)
            {
                super.$ctor();
                {
                    $.$spc.System.Diagnostics.Debug.Assert$1(id > 0n, "id>0");
                    $.$spc.System.Diagnostics.Debug.Assert$1(fixupInfo !== null, "fixupInfo!=null");
                    $.$spc.System.Diagnostics.Debug.Assert$1(fixupType === 1/*ArrayFixup*/ || fixupType === 2/*MemberFixup*/ || fixupType === 4/*DelayedFixup*/, "fixupType==ArrayFixup || fixupType == MemberFixup || fixupType==DelayedFixup");
                    this._id = id;
                    this._fixupInfo = fixupInfo;
                    this._fixupType = fixupType;
                }
                return this;
            }
            static $h = 304655;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"l":[{"t":655361,"n":"ArrayFixup","d":304655,"h":4295271951,"f":40},{"t":655361,"n":"MemberFixup","d":304655,"h":8590239247,"f":40},{"t":655361,"n":"DelayedFixup","d":304655,"h":12885206543,"f":40},{"t":917505,"n":"_id","d":304655,"h":17180173839,"f":8},{"t":131073,"n":"_fixupInfo","d":304655,"h":21475141135,"f":8},{"t":655361,"n":"_fixupType","d":304655,"h":25770108431,"f":8}],"c":[{"p":[{"n":"id","p":917505},{"n":"fixupInfo","p":131073},{"n":"fixupType","p":655361}],"n":".ctor","o":"$ctor$1","d":304655,"h":30065075727,"f":8}],"h":304655}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.Runtime.Serialization.FixupHolder`; }
        });
        
        $asm.$cls("$srsf.System.Runtime.Serialization.FixupHolderList", ($self) => class FixupHolderList extends $.$spc.System.Object
        {
            /*int*/ static InitialSize = 2;
            /*FixupHolder?[]*/ _values = null;
            /*int*/ _count = 0;
            $ctor$1()
            {
                this.$ctor$2(2/*InitialSize*/);
                {
                }
                return this;
            }
            $ctor$2(/*int*/ startingSize)
            {
                super.$ctor();
                {
                    this._count = 0;
                    this._values = $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$srsf.System.Runtime.Serialization.FixupHolder), null, [startingSize], null);
                }
                return this;
            }
            /*void */ Add(/*FixupHolder*/ fixup)
            {
                if (this._count === this._values.length)
                {
                    this.EnlargeArray();
                }
                $.$spc.System.Array.$WriteT1.call(this._values, fixup, this._count++);
            }
            /*void */ EnlargeArray()
            {
                /*int*/ let newLength = ((this._values.length * 2) | 0);
                if (newLength < 0)
                {
                    newLength = 2147483647/*int.MaxValue*/;
                }
                /*FixupHolder[]*/ let temp = $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$srsf.System.Runtime.Serialization.FixupHolder), null, [newLength], null);
                $.$spc.System.Array.Copy(this._values, temp, this._count);
                this._values = temp;
            }
            static $h = 370191;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"m":[{"r":65537,"p":[{"n":"fixup","p":304655}],"n":"Add","d":370191,"h":25770173967,"f":8},{"r":65537,"n":"EnlargeArray","d":370191,"h":30065141263,"f":2}],"l":[{"t":655361,"n":"InitialSize","d":370191,"h":4295337487,"f":40},{"t":0,"n":"_values","d":370191,"h":8590304783,"f":8},{"t":655361,"n":"_count","d":370191,"h":12885272079,"f":8}],"c":[{"n":".ctor","o":"$ctor$1","d":370191,"h":17180239375,"f":8},{"p":[{"n":"startingSize","p":655361}],"n":".ctor","o":"$ctor$2","d":370191,"h":21475206671,"f":8}],"h":370191}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.Runtime.Serialization.FixupHolderList`; }
        });
        
        $asm.$cls("$srsf.System.Runtime.Serialization.LongList", ($self) => class LongList extends $.$spc.System.Object
        {
            /*int*/ static InitialSize = 2;
            /*long[]*/ _values = null;
            /*int*/ _count = 0;
            /*int*/ _totalItems = 0;
            /*int*/ _currentItem = 0;
            $ctor$1()
            {
                this.$ctor$2(2/*InitialSize*/);
                {
                }
                return this;
            }
            $ctor$2(/*int*/ startingSize)
            {
                super.$ctor();
                {
                    this._count = 0;
                    this._totalItems = 0;
                    this._values = $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$spc.System.Int64), null, [startingSize], null);
                }
                return this;
            }
            /*void */ Add(/*long*/ value)
            {
                if (this._totalItems === this._values.length)
                {
                    this.EnlargeArray();
                }
                $.$spc.System.Array.$WriteT1.call(this._values, value, this._totalItems++);
                this._count++;
            }
            /*int */ get Count()
            {
                return this._count;
            }
            /*void */ StartEnumeration()
            {
                return this._currentItem = -1;
            }
            /*bool */ MoveNext()
            {
                while(++this._currentItem < this._totalItems && $.$spc.System.Array.$ReadT1.call(this._values, this._currentItem) === BigInt(-1))
                {
                }
                return this._currentItem !== this._totalItems;
            }
            /*long */ get Current()
            {
                $.$spc.System.Diagnostics.Debug.Assert$1(this._currentItem !== -1, "[LongList.Current]m_currentItem!=-1");
                $.$spc.System.Diagnostics.Debug.Assert$1($.$spc.System.Array.$ReadT1.call(this._values, this._currentItem) !== BigInt(-1), "[LongList.Current]m_values[m_currentItem]!=-1");
                return $.$spc.System.Array.$ReadT1.call(this._values, this._currentItem);
            }
            /*bool */ RemoveElement(/*long*/ value)
            {
                /*int*/ let i;
                for(i = 0; i < this._totalItems; i++)
                {
                    if ($.$spc.System.Array.$ReadT1.call(this._values, i) === value)
                    {
                        break;
                    }
                }
                if (i === this._totalItems)
                {
                    return false;
                }
                $.$spc.System.Array.$WriteT1.call(this._values, BigInt(-1), i);
                return true;
            }
            /*void */ EnlargeArray()
            {
                /*int*/ let newLength = ((this._values.length * 2) | 0);
                if (newLength < 0)
                {
                    newLength = 2147483647/*int.MaxValue*/;
                }
                /*long[]*/ let temp = $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$spc.System.Int64), null, [newLength], null);
                $.$spc.System.Array.Copy(this._values, temp, this._count);
                this._values = temp;
            }
            static $h = 1156623;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":655361,"g":{"r":0,"d":0,"h":42950829583,"f":8},"n":"Count","d":1156623,"h":38655862287,"f":8},{"p":917505,"g":{"r":0,"d":0,"h":60130698767,"f":8},"n":"Current","d":1156623,"h":55835731471,"f":8}],"m":[{"r":65537,"p":[{"n":"value","p":917505}],"n":"Add","d":1156623,"h":34360894991,"f":8},{"r":65537,"n":"StartEnumeration","d":1156623,"h":47245796879,"f":8},{"r":262145,"n":"MoveNext","d":1156623,"h":51540764175,"f":8},{"r":262145,"p":[{"n":"value","p":917505}],"n":"RemoveElement","d":1156623,"h":64425666063,"f":8},{"r":65537,"n":"EnlargeArray","d":1156623,"h":68720633359,"f":2}],"l":[{"t":655361,"n":"InitialSize","d":1156623,"h":4296123919,"f":34},{"t":0,"n":"_values","d":1156623,"h":8591091215,"f":2},{"t":655361,"n":"_count","d":1156623,"h":12886058511,"f":2},{"t":655361,"n":"_totalItems","d":1156623,"h":17181025807,"f":2},{"t":655361,"n":"_currentItem","d":1156623,"h":21475993103,"f":2}],"c":[{"n":".ctor","o":"$ctor$1","d":1156623,"h":25770960399,"f":8},{"p":[{"n":"startingSize","p":655361}],"n":".ctor","o":"$ctor$2","d":1156623,"h":30065927695,"f":8}],"h":1156623}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.Runtime.Serialization.LongList`; }
        });
        
        $asm.$cls("$srsf.System.Runtime.Serialization.ObjectHolderList", ($self) => class ObjectHolderList extends $.$spc.System.Object
        {
            /*int*/ static DefaultInitialSize = 8;
            /*ObjectHolder[]*/ _values = null;
            /*int*/ _count = 0;
            $ctor$1()
            {
                this.$ctor$2(8/*DefaultInitialSize*/);
                {
                }
                return this;
            }
            $ctor$2(/*int*/ startingSize)
            {
                super.$ctor();
                {
                    $.$spc.System.Diagnostics.Debug.Assert$1(startingSize > 0 && startingSize < 4096, "startingSize>0 && startingSize<0x1000");
                    this._count = 0;
                    this._values = $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$srsf.System.Runtime.Serialization.ObjectHolder), null, [startingSize], null);
                }
                return this;
            }
            /*void */ Add(/*ObjectHolder*/ value)
            {
                if (this._count === this._values.length)
                {
                    this.EnlargeArray();
                }
                $.$spc.System.Array.$WriteT1.call(this._values, value, this._count++);
            }
            /*ObjectHolderListEnumerator */ GetFixupEnumerator()
            {
                return new $.$srsf.System.Runtime.Serialization.ObjectHolderListEnumerator().$ctor$1(this, true);
            }
            /*void */ EnlargeArray()
            {
                /*int*/ let newLength = ((this._values.length * 2) | 0);
                if (newLength < 0)
                {
                    newLength = 2147483647/*int.MaxValue*/;
                }
                /*ObjectHolder[]*/ let temp = $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$srsf.System.Runtime.Serialization.ObjectHolder), null, [newLength], null);
                $.$spc.System.Array.Copy(this._values, temp, this._count);
                this._values = temp;
            }
            /*int */ get Version()
            {
                return this._count;
            }
            /*int */ get Count()
            {
                return this._count;
            }
            static $h = 1353231;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":655361,"g":{"r":0,"d":0,"h":42951026191,"f":8},"n":"Version","d":1353231,"h":38656058895,"f":8},{"p":655361,"g":{"r":0,"d":0,"h":51540960783,"f":8},"n":"Count","d":1353231,"h":47245993487,"f":8}],"m":[{"r":65537,"p":[{"n":"value","p":1287695}],"n":"Add","d":1353231,"h":25771157007,"f":8},{"r":1418767,"n":"GetFixupEnumerator","d":1353231,"h":30066124303,"f":8},{"r":65537,"n":"EnlargeArray","d":1353231,"h":34361091599,"f":2}],"l":[{"t":655361,"n":"DefaultInitialSize","d":1353231,"h":4296320527,"f":40},{"t":0,"n":"_values","d":1353231,"h":8591287823,"f":8},{"t":655361,"n":"_count","d":1353231,"h":12886255119,"f":8}],"c":[{"n":".ctor","o":"$ctor$1","d":1353231,"h":17181222415,"f":8},{"p":[{"n":"startingSize","p":655361}],"n":".ctor","o":"$ctor$2","d":1353231,"h":21476189711,"f":8}],"h":1353231}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.Runtime.Serialization.ObjectHolderList`; }
        });
        
        $asm.$cls("$srsf.System.Runtime.Serialization.ObjectHolderListEnumerator", ($self) => class ObjectHolderListEnumerator extends $.$spc.System.Object
        {
            /*bool*/ _isFixupEnumerator = false;
            /*ObjectHolderList*/ _list = null;
            /*int*/ _startingVersion = 0;
            /*int*/ _currPos = 0;
            $ctor$1(/*ObjectHolderList*/ list, /*bool*/ isFixupEnumerator)
            {
                super.$ctor();
                {
                    $.$spc.System.Diagnostics.Debug.Assert$1(list !== null, "[ObjectHolderListEnumerator.ctor]list!=null");
                    this._list = list;
                    this._startingVersion = this._list.Version;
                    this._currPos = -1;
                    this._isFixupEnumerator = isFixupEnumerator;
                }
                return this;
            }
            /*bool */ MoveNext()
            {
                $.$spc.System.Diagnostics.Debug.Assert$1(this._startingVersion === this._list.Version, "[ObjectHolderListEnumerator.MoveNext]m_startingVersion==m_list.Version");
                if (this._isFixupEnumerator)
                {
                    while(++this._currPos < this._list.Count && $.$spc.System.Array.$ReadT1.call(this._list._values, this._currPos).CompletelyFixed)
                    {
                    }
                    return this._currPos !== this._list.Count;
                }
                else 
                {
                    this._currPos++;
                    return this._currPos !== this._list.Count;
                }
            }
            /*ObjectHolder */ get Current()
            {
                $.$spc.System.Diagnostics.Debug.Assert$1(this._currPos !== -1, "[ObjectHolderListEnumerator.Current]m_currPos!=-1");
                $.$spc.System.Diagnostics.Debug.Assert$1(this._currPos < this._list.Count, "[ObjectHolderListEnumerator.Current]m_currPos<m_list.Count");
                $.$spc.System.Diagnostics.Debug.Assert$1(this._startingVersion === this._list.Version, "[ObjectHolderListEnumerator.Current]m_startingVersion==m_list.Version");
                return $.$spc.System.Array.$ReadT1.call(this._list._values, this._currPos);
            }
            static $h = 1418767;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":1287695,"g":{"r":0,"d":0,"h":34361157135,"f":8},"n":"Current","d":1418767,"h":30066189839,"f":8}],"m":[{"r":262145,"n":"MoveNext","d":1418767,"h":25771222543,"f":8}],"l":[{"t":262145,"n":"_isFixupEnumerator","d":1418767,"h":4296386063,"f":2},{"t":1353231,"n":"_list","d":1418767,"h":8591353359,"f":2},{"t":655361,"n":"_startingVersion","d":1418767,"h":12886320655,"f":2},{"t":655361,"n":"_currPos","d":1418767,"h":17181287951,"f":2}],"c":[{"p":[{"n":"list","p":1353231},{"n":"isFixupEnumerator","p":262145}],"n":".ctor","o":"$ctor$1","d":1418767,"h":21476255247,"f":8}],"h":1418767}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.Runtime.Serialization.ObjectHolderListEnumerator`; }
        });
        
        $asm.$cls("$srsf.System.Runtime.Serialization.TypeLoadExceptionHolder", ($self) => class TypeLoadExceptionHolder extends $.$spc.System.Object
        {
            $ctor$1(/*string?*/ typeName)
            {
                super.$ctor();
                {
                    this.TypeName = typeName;
                }
                return this;
            }
            /*string?*/ TypeName = null;
            static $h = 2336271;
            static $f = 0b10010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":1310721,"g":{"r":0,"d":0,"h":17182205455,"f":8},"n":"TypeName","d":2336271,"h":12887238159,"f":8}],"c":[{"p":[{"n":"typeName","p":1310721}],"n":".ctor","o":"$ctor$1","d":2336271,"h":4297303567,"f":8}],"h":2336271}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.Runtime.Serialization.TypeLoadExceptionHolder`; }
        });
        
        $asm.$cls("$srsf.System.Runtime.Serialization.SerializationInfoExtensions", ($self) => class SerializationInfoExtensions
        {
            /*Action<SerializationInfo, string, object, Type>*/ static s_updateValue = null;
            static /*void */ UpdateValue(/*this SerializationInfo*/ si, /*string*/ name, /*object*/ value, /*Type*/ type)
            {
                return $.$srsf.System.Runtime.Serialization.SerializationInfoExtensions.s_updateValue.Invoke(si, name, value, type);
            }
            //Static Initializer
            static $sinit()
            {
                {
                    this.s_updateValue = $.$spc.System.Runtime.Serialization.SerializationInfo.$type.GetMethod$2("UpdateValue", 16/*BindingFlags.Public*/ | 32/*BindingFlags.NonPublic*/ | 4/*BindingFlags.Instance*/).CreateDelegate$2($.$spc.System.Action$$$$$($.$spc.System.Runtime.Serialization.SerializationInfo, $.$spc.System.String, $.$spc.System.Object, $.$spc.System.Type));
                }
            }
            static $h = 1943055;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"m":[{"r":65537,"p":[{"n":"si","p":113967105},{"n":"name","p":1310721},{"n":"value","p":131073},{"n":"type","p":142606337}],"n":"UpdateValue","d":1943055,"h":8591877647,"f":33}],"l":[{"t":$.$spc.System.Action$$$$$($.$spc.System.Runtime.Serialization.SerializationInfo, $.$spc.System.String, $.$spc.System.Object, $.$spc.System.Type).$h,"n":"s_updateValue","d":1943055,"h":4296910351,"f":34}],"h":1943055}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.Runtime.Serialization.SerializationInfoExtensions`; }
        });
        
        $asm.$cls("$srsf.System.Runtime.Serialization.FormatterConverter", ($self) => class FormatterConverter extends $.$spc.System.Object
        {
            /*object */ Convert(/*object*/ value, /*Type*/ type)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(value, "value");
                return $.$spc.System.Convert.ChangeType$3(value, type, $.$spc.System.Globalization.CultureInfo.InvariantCulture);
            }
            /*object */ Convert$1(/*object*/ value, /*TypeCode*/ typeCode)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(value, "value");
                return $.$spc.System.Convert.ChangeType$1(value, typeCode, $.$spc.System.Globalization.CultureInfo.InvariantCulture);
            }
            /*bool */ ToBoolean(/*object*/ value)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(value, "value");
                return $.$spc.System.Convert.ToBoolean$1(value, $.$spc.System.Globalization.CultureInfo.InvariantCulture);
            }
            /*char */ ToChar(/*object*/ value)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(value, "value");
                return $.$spc.System.Convert.ToChar$1(value, $.$spc.System.Globalization.CultureInfo.InvariantCulture);
            }
            /*sbyte */ ToSByte(/*object*/ value)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(value, "value");
                return $.$spc.System.Convert.ToSByte$1(value, $.$spc.System.Globalization.CultureInfo.InvariantCulture);
            }
            /*byte */ ToByte(/*object*/ value)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(value, "value");
                return $.$spc.System.Convert.ToByte$1(value, $.$spc.System.Globalization.CultureInfo.InvariantCulture);
            }
            /*short */ ToInt16(/*object*/ value)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(value, "value");
                return $.$spc.System.Convert.ToInt16$1(value, $.$spc.System.Globalization.CultureInfo.InvariantCulture);
            }
            /*ushort */ ToUInt16(/*object*/ value)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(value, "value");
                return $.$spc.System.Convert.ToUInt16$1(value, $.$spc.System.Globalization.CultureInfo.InvariantCulture);
            }
            /*int */ ToInt32(/*object*/ value)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(value, "value");
                return $.$spc.System.Convert.ToInt32$1(value, $.$spc.System.Globalization.CultureInfo.InvariantCulture);
            }
            /*uint */ ToUInt32(/*object*/ value)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(value, "value");
                return $.$spc.System.Convert.ToUInt32$1(value, $.$spc.System.Globalization.CultureInfo.InvariantCulture);
            }
            /*long */ ToInt64(/*object*/ value)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(value, "value");
                return $.$spc.System.Convert.ToInt64$1(value, $.$spc.System.Globalization.CultureInfo.InvariantCulture);
            }
            /*ulong */ ToUInt64(/*object*/ value)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(value, "value");
                return $.$spc.System.Convert.ToUInt64$1(value, $.$spc.System.Globalization.CultureInfo.InvariantCulture);
            }
            /*float */ ToSingle(/*object*/ value)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(value, "value");
                return $.$spc.System.Convert.ToSingle$1(value, $.$spc.System.Globalization.CultureInfo.InvariantCulture);
            }
            /*double */ ToDouble(/*object*/ value)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(value, "value");
                return $.$spc.System.Convert.ToDouble$1(value, $.$spc.System.Globalization.CultureInfo.InvariantCulture);
            }
            /*decimal */ ToDecimal(/*object*/ value)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(value, "value");
                return $.$spc.System.Convert.ToDecimal$1(value, $.$spc.System.Globalization.CultureInfo.InvariantCulture);
            }
            /*DateTime */ ToDateTime(/*object*/ value)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(value, "value");
                return $.$spc.System.Convert.ToDateTime$2(value, $.$spc.System.Globalization.CultureInfo.InvariantCulture);
            }
            /*string? */ ToString$1(/*object*/ value)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(value, "value");
                return $.$spc.System.Convert.ToString$2(value, $.$spc.System.Globalization.CultureInfo.InvariantCulture);
            }
            //Generated interface implemetation for System.Runtime.Serialization.IFormatterConverter.Convert(object, System.Type)
            System$Runtime$Serialization$IFormatterConverter$Convert()
            {
                return this.Convert(...arguments);
            }
            //Generated interface implemetation for System.Runtime.Serialization.IFormatterConverter.Convert(object, System.TypeCode)
            System$Runtime$Serialization$IFormatterConverter$Convert$1()
            {
                return this.Convert$1(...arguments);
            }
            //Generated interface implemetation for System.Runtime.Serialization.IFormatterConverter.ToBoolean(object)
            System$Runtime$Serialization$IFormatterConverter$ToBoolean()
            {
                return this.ToBoolean(...arguments);
            }
            //Generated interface implemetation for System.Runtime.Serialization.IFormatterConverter.ToChar(object)
            System$Runtime$Serialization$IFormatterConverter$ToChar()
            {
                return this.ToChar(...arguments);
            }
            //Generated interface implemetation for System.Runtime.Serialization.IFormatterConverter.ToSByte(object)
            System$Runtime$Serialization$IFormatterConverter$ToSByte()
            {
                return this.ToSByte(...arguments);
            }
            //Generated interface implemetation for System.Runtime.Serialization.IFormatterConverter.ToByte(object)
            System$Runtime$Serialization$IFormatterConverter$ToByte()
            {
                return this.ToByte(...arguments);
            }
            //Generated interface implemetation for System.Runtime.Serialization.IFormatterConverter.ToInt16(object)
            System$Runtime$Serialization$IFormatterConverter$ToInt16()
            {
                return this.ToInt16(...arguments);
            }
            //Generated interface implemetation for System.Runtime.Serialization.IFormatterConverter.ToUInt16(object)
            System$Runtime$Serialization$IFormatterConverter$ToUInt16()
            {
                return this.ToUInt16(...arguments);
            }
            //Generated interface implemetation for System.Runtime.Serialization.IFormatterConverter.ToInt32(object)
            System$Runtime$Serialization$IFormatterConverter$ToInt32()
            {
                return this.ToInt32(...arguments);
            }
            //Generated interface implemetation for System.Runtime.Serialization.IFormatterConverter.ToUInt32(object)
            System$Runtime$Serialization$IFormatterConverter$ToUInt32()
            {
                return this.ToUInt32(...arguments);
            }
            //Generated interface implemetation for System.Runtime.Serialization.IFormatterConverter.ToInt64(object)
            System$Runtime$Serialization$IFormatterConverter$ToInt64()
            {
                return this.ToInt64(...arguments);
            }
            //Generated interface implemetation for System.Runtime.Serialization.IFormatterConverter.ToUInt64(object)
            System$Runtime$Serialization$IFormatterConverter$ToUInt64()
            {
                return this.ToUInt64(...arguments);
            }
            //Generated interface implemetation for System.Runtime.Serialization.IFormatterConverter.ToSingle(object)
            System$Runtime$Serialization$IFormatterConverter$ToSingle()
            {
                return this.ToSingle(...arguments);
            }
            //Generated interface implemetation for System.Runtime.Serialization.IFormatterConverter.ToDouble(object)
            System$Runtime$Serialization$IFormatterConverter$ToDouble()
            {
                return this.ToDouble(...arguments);
            }
            //Generated interface implemetation for System.Runtime.Serialization.IFormatterConverter.ToDecimal(object)
            System$Runtime$Serialization$IFormatterConverter$ToDecimal()
            {
                return this.ToDecimal(...arguments);
            }
            //Generated interface implemetation for System.Runtime.Serialization.IFormatterConverter.ToDateTime(object)
            System$Runtime$Serialization$IFormatterConverter$ToDateTime()
            {
                return this.ToDateTime(...arguments);
            }
            //Generated interface implemetation for System.Runtime.Serialization.IFormatterConverter.ToString(object)
            System$Runtime$Serialization$IFormatterConverter$ToString()
            {
                return this.ToString$1(...arguments);
            }
            //default reference type constructor overload
            $ctor$1()
            {
                super.$ctor();
                return this;
            }
            static $h = 501263;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"m":[{"r":131073,"p":[{"n":"value","p":131073},{"n":"type","p":142606337}],"n":"Convert","d":501263,"h":4295468559,"f":1},{"r":131073,"p":[{"n":"value","p":131073},{"n":"typeCode","p":142737409}],"n":"Convert","o":"@$1","d":501263,"h":8590435855,"f":1},{"r":262145,"p":[{"n":"value","p":131073}],"n":"ToBoolean","d":501263,"h":12885403151,"f":1},{"r":458753,"p":[{"n":"value","p":131073}],"n":"ToChar","d":501263,"h":17180370447,"f":1},{"r":327681,"p":[{"n":"value","p":131073}],"n":"ToSByte","d":501263,"h":21475337743,"f":1,"a":[{"t":23396353,"c":8613330945,"a":[{"v":false,"t":262145}]}]},{"r":393217,"p":[{"n":"value","p":131073}],"n":"ToByte","d":501263,"h":25770305039,"f":1},{"r":524289,"p":[{"n":"value","p":131073}],"n":"ToInt16","d":501263,"h":30065272335,"f":1},{"r":589825,"p":[{"n":"value","p":131073}],"n":"ToUInt16","d":501263,"h":34360239631,"f":1,"a":[{"t":23396353,"c":8613330945,"a":[{"v":false,"t":262145}]}]},{"r":655361,"p":[{"n":"value","p":131073}],"n":"ToInt32","d":501263,"h":38655206927,"f":1},{"r":720897,"p":[{"n":"value","p":131073}],"n":"ToUInt32","d":501263,"h":42950174223,"f":1,"a":[{"t":23396353,"c":8613330945,"a":[{"v":false,"t":262145}]}]},{"r":917505,"p":[{"n":"value","p":131073}],"n":"ToInt64","d":501263,"h":47245141519,"f":1},{"r":983041,"p":[{"n":"value","p":131073}],"n":"ToUInt64","d":501263,"h":51540108815,"f":1,"a":[{"t":23396353,"c":8613330945,"a":[{"v":false,"t":262145}]}]},{"r":1114113,"p":[{"n":"value","p":131073}],"n":"ToSingle","d":501263,"h":55835076111,"f":1},{"r":1179649,"p":[{"n":"value","p":131073}],"n":"ToDouble","d":501263,"h":60130043407,"f":1},{"r":34996225,"p":[{"n":"value","p":131073}],"n":"ToDecimal","d":501263,"h":64425010703,"f":1},{"r":34144257,"p":[{"n":"value","p":131073}],"n":"ToDateTime","d":501263,"h":68719977999,"f":1},{"r":1310721,"p":[{"n":"value","p":131073}],"n":"ToString","o":"@$1","d":501263,"h":73014945295,"f":1}],"c":[{"n":".ctor","o":"$ctor$1","d":501263,"h":77309912591,"f":1}],"i":[113180673],"h":501263,"a":[{"t":70909953,"c":8660844545,"a":[{"v":"Formatter-based serialization is obsolete and should not be used.","t":1310721}],"n":[{"n":"DiagnosticId","v":"SYSLIB0050","t":1310721},{"n":"UrlFormat","v":"https://aka.ms/dotnet-warnings/{0}","t":1310721}]}]}; }
            static get $b() { return $.$spc.System.Object; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.Runtime.Serialization.IFormatterConverter ]; }
            static get $fullName() { return `System.Runtime.Serialization.FormatterConverter`; }
        });
        
        $asm.$cls("$srsf.System.Runtime.Serialization.SurrogateSelector", ($self) => class SurrogateSelector extends $.$spc.System.Object
        {
            /*SurrogateHashtable*/ _surrogates = null;
            /*ISurrogateSelector?*/ _nextSelector = null;
            /*void */ AddSurrogate(/*Type*/ type, /*StreamingContext*/ context, /*ISerializationSurrogate*/ surrogate)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(type, "type");
                $.$spc.System.ArgumentNullException.ThrowIfNull(surrogate, "surrogate");
                /*var*/ let key = new $.$srsf.System.Runtime.Serialization.SurrogateKey().$ctor$1(type, context);
                this._surrogates.Add(key, surrogate);
            }
            static /*bool */ HasCycle(/*ISurrogateSelector*/ selector)
            {
                $.$spc.System.Diagnostics.Debug.Assert$1(selector !== null, "[HasCycle]selector!=null");
                /*ISurrogateSelector?*/ let head = selector, tail = selector;
                while(head !== null)
                {
                    head = head.System$Runtime$Serialization$ISurrogateSelector$GetNextSelector();
                    if (head === null)
                    {
                        return true;
                    }
                    if (head === tail)
                    {
                        return false;
                    }
                    head = head.System$Runtime$Serialization$ISurrogateSelector$GetNextSelector();
                    tail = tail.System$Runtime$Serialization$ISurrogateSelector$GetNextSelector();
                    if (head === tail)
                    {
                        return false;
                    }
                }
                return true;
            }
            /*void */ ChainSelector(/*ISurrogateSelector*/ selector)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(selector, "selector");
                if (selector === this)
                {
                    throw new $.$spc.System.Runtime.Serialization.SerializationException().$ctor$10($.$srsf.System.SR.Serialization_SurrogateCycle);
                }
                if (!$.$srsf.System.Runtime.Serialization.SurrogateSelector.HasCycle(selector))
                {
                    throw new $.$spc.System.ArgumentException().$ctor$13($.$srsf.System.SR.Serialization_SurrogateCycleInArgument, "selector");
                }
                /*ISurrogateSelector?*/ let tempCurr = selector.System$Runtime$Serialization$ISurrogateSelector$GetNextSelector();
                /*ISurrogateSelector*/ let tempEnd = selector;
                while(tempCurr !== null && tempCurr !== this)
                {
                    tempEnd = tempCurr;
                    tempCurr = tempCurr.System$Runtime$Serialization$ISurrogateSelector$GetNextSelector();
                }
                if (tempCurr === this)
                {
                    throw new $.$spc.System.ArgumentException().$ctor$13($.$srsf.System.SR.Serialization_SurrogateCycle, "selector");
                }
                tempCurr = selector;
                /*ISurrogateSelector?*/ let tempPrev = selector;
                while(tempCurr !== null)
                {
                    if (tempCurr === tempEnd)
                    {
                        tempCurr = this.GetNextSelector();
                    }
                    else 
                    {
                        tempCurr = tempCurr.System$Runtime$Serialization$ISurrogateSelector$GetNextSelector();
                    }
                    if (tempCurr === null)
                    {
                        break;
                    }
                    if (tempCurr === tempPrev)
                    {
                        throw new $.$spc.System.ArgumentException().$ctor$13($.$srsf.System.SR.Serialization_SurrogateCycle, "selector");
                    }
                    if (tempCurr === tempEnd)
                    {
                        tempCurr = this.GetNextSelector();
                    }
                    else 
                    {
                        tempCurr = tempCurr.System$Runtime$Serialization$ISurrogateSelector$GetNextSelector();
                    }
                    if (tempPrev === tempEnd)
                    {
                        tempPrev = this.GetNextSelector();
                    }
                    else 
                    {
                        $.$spc.System.Diagnostics.Debug.Assert$1(tempPrev !== null, "tempPrev != null");
                        tempPrev = tempPrev.System$Runtime$Serialization$ISurrogateSelector$GetNextSelector();
                    }
                    if (tempCurr === tempPrev)
                    {
                        throw new $.$spc.System.ArgumentException().$ctor$13($.$srsf.System.SR.Serialization_SurrogateCycle, "selector");
                    }
                }
                /*ISurrogateSelector?*/ let temp = this._nextSelector;
                this._nextSelector = selector;
                if (temp !== null)
                {
                    tempEnd.System$Runtime$Serialization$ISurrogateSelector$ChainSelector(temp);
                }
            }
            /*ISurrogateSelector? */ GetNextSelector()
            {
                return this._nextSelector;
            }
            /*ISerializationSurrogate? */ GetSurrogate(/*Type*/ type, /*StreamingContext*/ context, /*out ISurrogateSelector*/ selector)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(type, "type");
                selector.$v = this;
                /*SurrogateKey*/ let key = new $.$srsf.System.Runtime.Serialization.SurrogateKey().$ctor$1(type, context);
                /*ISerializationSurrogate?*/ let temp = $.$cast(this._surrogates.get_Item(key), $.$srsf.System.Runtime.Serialization.ISerializationSurrogate);
                if (temp !== null)
                {
                    return temp;
                }
                if (this._nextSelector !== null)
                {
                    return this._nextSelector.System$Runtime$Serialization$ISurrogateSelector$GetSurrogate(type, context, selector);
                }
                return null;
            }
            /*void */ RemoveSurrogate(/*Type*/ type, /*StreamingContext*/ context)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(type, "type");
                /*SurrogateKey*/ let key = new $.$srsf.System.Runtime.Serialization.SurrogateKey().$ctor$1(type, context);
                this._surrogates.Remove(key);
            }
            //Generated interface implemetation for System.Runtime.Serialization.ISurrogateSelector.ChainSelector(System.Runtime.Serialization.ISurrogateSelector)
            System$Runtime$Serialization$ISurrogateSelector$ChainSelector()
            {
                return this.ChainSelector(...arguments);
            }
            //Generated interface implemetation for System.Runtime.Serialization.ISurrogateSelector.GetSurrogate(System.Type, System.Runtime.Serialization.StreamingContext, out System.Runtime.Serialization.ISurrogateSelector)
            System$Runtime$Serialization$ISurrogateSelector$GetSurrogate()
            {
                return this.GetSurrogate(...arguments);
            }
            //Generated interface implemetation for System.Runtime.Serialization.ISurrogateSelector.GetNextSelector()
            System$Runtime$Serialization$ISurrogateSelector$GetNextSelector()
            {
                return this.GetNextSelector(...arguments);
            }
            //default reference type constructor overload
            $ctor$1()
            {
                super.$ctor();
                return this;
            }
            //default member initializer
            constructor()
            {
                super();
                this._surrogates = new $.$srsf.System.Runtime.Serialization.SurrogateHashtable().$ctor$1(32);
            }
            static $h = 2270735;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"m":[{"r":65537,"p":[{"n":"type","p":142606337},{"n":"context","p":114098177},{"n":"surrogate","p":1025551}],"n":"AddSurrogate","d":2270735,"h":12887172623,"f":129},{"r":262145,"p":[{"n":"selector","p":1091087}],"n":"HasCycle","d":2270735,"h":17182139919,"f":34},{"r":65537,"p":[{"n":"selector","p":1091087}],"n":"ChainSelector","d":2270735,"h":21477107215,"f":129},{"r":1091087,"n":"GetNextSelector","d":2270735,"h":25772074511,"f":129},{"r":1025551,"p":[{"n":"type","p":142606337},{"n":"context","p":114098177},{"n":"selector","p":1091087,"f":2}],"n":"GetSurrogate","d":2270735,"h":30067041807,"f":129},{"r":65537,"p":[{"n":"type","p":142606337},{"n":"context","p":114098177}],"n":"RemoveSurrogate","d":2270735,"h":34362009103,"f":129}],"l":[{"t":2139663,"n":"_surrogates","d":2270735,"h":4297238031,"f":8},{"t":1091087,"n":"_nextSelector","d":2270735,"h":8592205327,"f":8}],"c":[{"n":".ctor","o":"$ctor$1","d":2270735,"h":38656976399,"f":1}],"i":[1091087],"h":2270735,"a":[{"t":70909953,"c":8660844545,"a":[{"v":"Formatter-based serialization is obsolete and should not be used.","t":1310721}],"n":[{"n":"DiagnosticId","v":"SYSLIB0050","t":1310721},{"n":"UrlFormat","v":"https://aka.ms/dotnet-warnings/{0}","t":1310721}]}]}; }
            static get $b() { return $.$spc.System.Object; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$srsf.System.Runtime.Serialization.ISurrogateSelector ]; }
            static get $fullName() { return `System.Runtime.Serialization.SurrogateSelector`; }
        });
        
        $asm.$cls("$srsf.System.Runtime.Serialization.Formatters.Binary.BinaryFormatter", ($self) => class BinaryFormatter extends $.$spc.System.Object
        {
            /*ISurrogateSelector?*/ _surrogates = null;
            /*StreamingContext*/ _context;
            /*SerializationBinder?*/ _binder = null;
            /*FormatterTypeStyle*/ _typeFormat = 1;
            /*FormatterAssemblyStyle*/ _assemblyFormat = 0;
            /*TypeFilterLevel*/ _securityLevel = 3;
            /*FormatterTypeStyle */ get TypeFormat()
            {
                return this._typeFormat;
            }
            /*FormatterTypeStyle */ set TypeFormat(value)
            {
                this._typeFormat = value;
            }
            /*FormatterAssemblyStyle */ get AssemblyFormat()
            {
                return this._assemblyFormat;
            }
            /*FormatterAssemblyStyle */ set AssemblyFormat(value)
            {
                this._assemblyFormat = value;
            }
            /*TypeFilterLevel */ get FilterLevel()
            {
                return this._securityLevel;
            }
            /*TypeFilterLevel */ set FilterLevel(value)
            {
                this._securityLevel = value;
            }
            /*ISurrogateSelector? */ get SurrogateSelector()
            {
                return this._surrogates;
            }
            /*ISurrogateSelector? */ set SurrogateSelector(value)
            {
                this._surrogates = value;
            }
            /*SerializationBinder? */ get Binder()
            {
                return this._binder;
            }
            /*SerializationBinder? */ set Binder(value)
            {
                this._binder = value;
            }
            /*StreamingContext */ get Context()
            {
                return this._context;
            }
            /*StreamingContext */ set Context(value)
            {
                this._context = value;
            }
            $ctor$1()
            {
                this.$ctor$2(null, new $.$spc.System.Runtime.Serialization.StreamingContext().$ctor$2(255/*StreamingContextStates.All*/));
                {
                }
                return this;
            }
            $ctor$2(/*ISurrogateSelector?*/ selector, /*StreamingContext*/ context)
            {
                super.$ctor();
                {
                    this._surrogates = selector;
                    this._context = context;
                }
                return this;
            }
            /*object */ Deserialize(/*Stream*/ serializationStream)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$14($.$srsf.System.SR.BinaryFormatter_Removed);
            }
            /*void */ Serialize(/*Stream*/ serializationStream, /*object*/ graph)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$14($.$srsf.System.SR.BinaryFormatter_Removed);
            }
            //Generated interface implemetation for System.Runtime.Serialization.IFormatter.Deserialize(System.IO.Stream)
            System$Runtime$Serialization$IFormatter$Deserialize()
            {
                return this.Deserialize(...arguments);
            }
            //Generated interface implemetation for System.Runtime.Serialization.IFormatter.Serialize(System.IO.Stream, object)
            System$Runtime$Serialization$IFormatter$Serialize()
            {
                return this.Serialize(...arguments);
            }
            //Generated interface implemetation for System.Runtime.Serialization.IFormatter.SurrogateSelector.get
            get System$Runtime$Serialization$IFormatter$SurrogateSelector()
            {
                return this.SurrogateSelector;
            }
            //Generated interface implemetation for System.Runtime.Serialization.IFormatter.SurrogateSelector.set
            set System$Runtime$Serialization$IFormatter$SurrogateSelector(value)
            {
                this.SurrogateSelector = value;
            }
            //Generated interface implemetation for System.Runtime.Serialization.IFormatter.Binder.get
            get System$Runtime$Serialization$IFormatter$Binder()
            {
                return this.Binder;
            }
            //Generated interface implemetation for System.Runtime.Serialization.IFormatter.Binder.set
            set System$Runtime$Serialization$IFormatter$Binder(value)
            {
                this.Binder = value;
            }
            //Generated interface implemetation for System.Runtime.Serialization.IFormatter.Context.get
            get System$Runtime$Serialization$IFormatter$Context()
            {
                return this.Context;
            }
            //Generated interface implemetation for System.Runtime.Serialization.IFormatter.Context.set
            set System$Runtime$Serialization$IFormatter$Context(value)
            {
                this.Context = value;
            }
            //default member initializer
            constructor()
            {
                super();
                this._context = $.$default($.$spc.System.Runtime.Serialization.StreamingContext);
            }
            static $h = 566799;
            static $f = 0b10010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":697871,"g":{"r":0,"d":0,"h":34360305167,"f":1},"s":{"r":0,"d":0,"h":38655272463,"f":1},"n":"TypeFormat","d":566799,"h":30065337871,"f":1},{"p":632335,"g":{"r":0,"d":0,"h":47245207055,"f":1},"s":{"r":0,"d":0,"h":51540174351,"f":1},"n":"AssemblyFormat","d":566799,"h":42950239759,"f":1},{"p":828943,"g":{"r":0,"d":0,"h":60130108943,"f":1},"s":{"r":0,"d":0,"h":64425076239,"f":1},"n":"FilterLevel","d":566799,"h":55835141647,"f":1},{"p":1091087,"g":{"r":0,"d":0,"h":73015010831,"f":1},"s":{"r":0,"d":0,"h":77309978127,"f":1},"n":"SurrogateSelector","d":566799,"h":68720043535,"f":1},{"p":1615375,"g":{"r":0,"d":0,"h":85899912719,"f":1},"s":{"r":0,"d":0,"h":90194880015,"f":1},"n":"Binder","d":566799,"h":81604945423,"f":1},{"p":114098177,"g":{"r":0,"d":0,"h":98784814607,"f":1},"s":{"r":0,"d":0,"h":103079781903,"f":1},"n":"Context","d":566799,"h":94489847311,"f":1}],"m":[{"r":131073,"p":[{"n":"serializationStream","p":62128129}],"n":"Deserialize","d":566799,"h":115964683791,"f":1},{"r":65537,"p":[{"n":"serializationStream","p":62128129},{"n":"graph","p":131073}],"n":"Serialize","d":566799,"h":120259651087,"f":1}],"l":[{"t":1091087,"n":"_surrogates","d":566799,"h":4295534095,"f":8},{"t":114098177,"n":"_context","d":566799,"h":8590501391,"f":8},{"t":1615375,"n":"_binder","d":566799,"h":12885468687,"f":8},{"t":697871,"n":"_typeFormat","d":566799,"h":17180435983,"f":8},{"t":632335,"n":"_assemblyFormat","d":566799,"h":21475403279,"f":8},{"t":828943,"n":"_securityLevel","d":566799,"h":25770370575,"f":8}],"c":[{"n":".ctor","o":"$ctor$1","d":566799,"h":107374749199,"f":1},{"p":[{"n":"selector","p":1091087},{"n":"context","p":114098177}],"n":".ctor","o":"$ctor$2","d":566799,"h":111669716495,"f":1}],"i":[960015],"h":566799,"a":[{"t":70909953,"c":8660844545,"a":[{"v":"BinaryFormatter serialization is obsolete and should not be used. See https://aka.ms/binaryformatter for more information.","t":1310721}],"n":[{"n":"DiagnosticId","v":"SYSLIB0011","t":1310721},{"n":"UrlFormat","v":"https://aka.ms/dotnet-warnings/{0}","t":1310721}]}]}; }
            static get $b() { return $.$spc.System.Object; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$srsf.System.Runtime.Serialization.IFormatter ]; }
            static get $fullName() { return `System.Runtime.Serialization.Formatters.Binary.BinaryFormatter`; }
        });
        
        $asm.$cls("$srsf.System.Runtime.Serialization.SurrogateForCyclicalReference", ($self) => class SurrogateForCyclicalReference extends $.$spc.System.Object
        {
            /*ISerializationSurrogate*/ _innerSurrogate = null;
            $ctor$1(/*ISerializationSurrogate*/ innerSurrogate)
            {
                super.$ctor();
                {
                    $.$spc.System.Diagnostics.Debug.Assert$1(innerSurrogate !== null, "innerSurrogate != null");
                    this._innerSurrogate = innerSurrogate;
                }
                return this;
            }
            /*void */ GetObjectData(/*object*/ obj, /*SerializationInfo*/ info, /*StreamingContext*/ context)
            {
                this._innerSurrogate.System$Runtime$Serialization$ISerializationSurrogate$GetObjectData(obj, info, context);
            }
            /*object */ SetObjectData(/*object*/ obj, /*SerializationInfo*/ info, /*StreamingContext*/ context, /*ISurrogateSelector?*/ selector)
            {
                return this._innerSurrogate.System$Runtime$Serialization$ISerializationSurrogate$SetObjectData(obj, info, context, selector);
            }
            //Generated interface implemetation for System.Runtime.Serialization.ISerializationSurrogate.GetObjectData(object, System.Runtime.Serialization.SerializationInfo, System.Runtime.Serialization.StreamingContext)
            System$Runtime$Serialization$ISerializationSurrogate$GetObjectData()
            {
                return this.GetObjectData(...arguments);
            }
            //Generated interface implemetation for System.Runtime.Serialization.ISerializationSurrogate.SetObjectData(object, System.Runtime.Serialization.SerializationInfo, System.Runtime.Serialization.StreamingContext, System.Runtime.Serialization.ISurrogateSelector?)
            System$Runtime$Serialization$ISerializationSurrogate$SetObjectData()
            {
                return this.SetObjectData(...arguments);
            }
            static $h = 2074127;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"m":[{"r":65537,"p":[{"n":"obj","p":131073},{"n":"info","p":113967105},{"n":"context","p":114098177}],"n":"GetObjectData","d":2074127,"h":12886976015,"f":1},{"r":131073,"p":[{"n":"obj","p":131073},{"n":"info","p":113967105},{"n":"context","p":114098177},{"n":"selector","p":1091087}],"n":"SetObjectData","d":2074127,"h":17181943311,"f":1}],"l":[{"t":1025551,"n":"_innerSurrogate","d":2074127,"h":4297041423,"f":2}],"c":[{"p":[{"n":"innerSurrogate","p":1025551}],"n":".ctor","o":"$ctor$1","d":2074127,"h":8592008719,"f":8}],"i":[1025551],"h":2074127}; }
            static get $b() { return $.$spc.System.Object; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$srsf.System.Runtime.Serialization.ISerializationSurrogate ]; }
            static get $fullName() { return `System.Runtime.Serialization.SurrogateForCyclicalReference`; }
        });
        
        $asm.$cls("$srsf.System.Runtime.Serialization.SerializationFieldInfo", ($self) => class SerializationFieldInfo extends $.$spc.System.Reflection.FieldInfo
        {
            /*FieldInfo*/ m_field = null;
            /*string*/ m_serializationName = null;
            $ctor$4(/*FieldInfo*/ field, /*string*/ namePrefix)
            {
                super.$ctor$3();
                {
                    $.$spc.System.Diagnostics.Debug.Assert$1($.$spc.System.Reflection.FieldInfo.op_Inequality$1(field, null), "field != null");
                    $.$spc.System.Diagnostics.Debug.Assert$1($.$spc.System.String.op_Inequality(namePrefix, null), "namePrefix != null");
                    this.m_field = field;
                    this.m_serializationName = namePrefix + "+" + this.m_field.Name;
                }
                return this;
            }
            /*FieldInfo */ get FieldInfo()
            {
                return this.m_field;
            }
            /*string */ get Name()
            {
                return this.m_serializationName;
            }
            /*Module */ get Module()
            {
                return this.m_field.Module;
            }
            /*int */ get MetadataToken()
            {
                return this.m_field.MetadataToken;
            }
            /*Type? */ get DeclaringType()
            {
                return this.m_field.DeclaringType;
            }
            /*Type? */ get ReflectedType()
            {
                return this.m_field.ReflectedType;
            }
            /*object[] */ GetCustomAttributes(/*bool*/ inherit)
            {
                return this.m_field.GetCustomAttributes(inherit);
            }
            /*object[] */ GetCustomAttributes$1(/*Type*/ attributeType, /*bool*/ inherit)
            {
                return this.m_field.GetCustomAttributes$1(attributeType, inherit);
            }
            /*bool */ IsDefined(/*Type*/ attributeType, /*bool*/ inherit)
            {
                return this.m_field.IsDefined(attributeType, inherit);
            }
            /*Type */ get FieldType()
            {
                return this.m_field.FieldType;
            }
            /*object? */ GetValue(/*object?*/ obj)
            {
                return this.m_field.GetValue(obj);
            }
            /*void */ SetValue$1(/*object?*/ obj, /*object?*/ value, /*BindingFlags*/ invokeAttr, /*Binder?*/ binder, /*CultureInfo?*/ culture)
            {
                return this.m_field.SetValue$1(obj, value, invokeAttr, binder, culture);
            }
            /*RuntimeFieldHandle */ get FieldHandle()
            {
                return this.m_field.FieldHandle;
            }
            /*FieldAttributes */ get Attributes()
            {
                return this.m_field.Attributes;
            }
            static $h = 1877519;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":76677121,"p":[{"p":76677121,"g":{"r":0,"d":0,"h":21476713999,"f":8},"n":"FieldInfo","d":1877519,"h":17181746703,"f":8},{"p":1310721,"g":{"r":0,"d":0,"h":30066648591,"f":32769},"n":"Name","d":1877519,"h":25771681295,"f":32769},{"p":80216065,"g":{"r":0,"d":0,"h":38656583183,"f":32769},"n":"Module","d":1877519,"h":34361615887,"f":32769},{"p":655361,"g":{"r":0,"d":0,"h":47246517775,"f":32769},"n":"MetadataToken","d":1877519,"h":42951550479,"f":32769},{"p":142606337,"g":{"r":0,"d":0,"h":55836452367,"f":32769},"n":"DeclaringType","d":1877519,"h":51541485071,"f":32769},{"p":142606337,"g":{"r":0,"d":0,"h":64426386959,"f":32769},"n":"ReflectedType","d":1877519,"h":60131419663,"f":32769},{"p":142606337,"g":{"r":0,"d":0,"h":85901223439,"f":32769},"n":"FieldType","d":1877519,"h":81606256143,"f":32769},{"p":115539969,"g":{"r":0,"d":0,"h":103081092623,"f":32769},"n":"FieldHandle","d":1877519,"h":98786125327,"f":32769},{"p":76611585,"g":{"r":0,"d":0,"h":111671027215,"f":32769},"n":"Attributes","d":1877519,"h":107376059919,"f":32769}],"m":[{"r":0,"p":[{"n":"inherit","p":262145}],"n":"GetCustomAttributes","d":1877519,"h":68721354255,"f":32769},{"r":0,"p":[{"n":"attributeType","p":142606337},{"n":"inherit","p":262145}],"n":"GetCustomAttributes","o":"@$1","d":1877519,"h":73016321551,"f":32769},{"r":262145,"p":[{"n":"attributeType","p":142606337},{"n":"inherit","p":262145}],"n":"IsDefined","d":1877519,"h":77311288847,"f":32769},{"r":131073,"p":[{"n":"obj","p":131073}],"n":"GetValue","d":1877519,"h":90196190735,"f":32769},{"r":65537,"p":[{"n":"obj","p":131073},{"n":"value","p":131073},{"n":"invokeAttr","p":75497473},{"n":"binder","p":75431937},{"n":"culture","p":51118081}],"n":"SetValue","o":"@$1","d":1877519,"h":94491158031,"f":32769}],"l":[{"t":76677121,"n":"m_field","d":1877519,"h":4296844815,"f":2},{"t":1310721,"n":"m_serializationName","d":1877519,"h":8591812111,"f":2}],"c":[{"p":[{"n":"field","p":76677121},{"n":"namePrefix","p":1310721}],"n":".ctor","o":"$ctor$4","d":1877519,"h":12886779407,"f":8}],"i":[76939265],"h":1877519}; }
            static get $b() { return $.$spc.System.Reflection.FieldInfo; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.Reflection.ICustomAttributeProvider ]; }
            static get $fullName() { return `System.Runtime.Serialization.SerializationFieldInfo`; }
        });
        
        $asm.$str("$srsf.System.Runtime.Serialization.Formatters.FormatterTypeStyle", ($self) => class FormatterTypeStyle extends $.$spc.System.Enum
        {
            static TypesWhenNeeded = 0;
            static TypesAlways = 1;
            static XsdString = 2;
            static $map;
            static get Map()
            {
                return this.$map ??= 
                {
                    "TypesWhenNeeded": 0n,
                    "TypesAlways": 1n,
                    "XsdString": 2n
                };
            }
            static $h = 697871;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static get $eut() { return $.$spc.System.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {"b":1048577,"u":655361,"l":[{"t":697871,"n":"TypesWhenNeeded","d":697871,"h":4295665167,"f":33},{"t":697871,"n":"TypesAlways","d":697871,"h":8590632463,"f":33},{"t":697871,"n":"XsdString","d":697871,"h":12885599759,"f":33}],"c":[{"n":".ctor","o":"$ctor$3","d":697871,"h":17180567055,"f":1}],"i":[57212929,63766529,57671681,57344001],"h":697871,"a":[{"t":70909953,"c":8660844545,"a":[{"v":"Formatter-based serialization is obsolete and should not be used.","t":1310721}],"n":[{"n":"DiagnosticId","v":"SYSLIB0050","t":1310721},{"n":"UrlFormat","v":"https://aka.ms/dotnet-warnings/{0}","t":1310721}]}]}; }
            static get $b() { return $.$spc.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IComparable, $.$spc.System.ISpanFormattable, $.$spc.System.IFormattable, $.$spc.System.IConvertible ]; }
            static get $fullName() { return `System.Runtime.Serialization.Formatters.FormatterTypeStyle`; }
        });
        
        $asm.$str("$srsf.System.Runtime.Serialization.Formatters.FormatterAssemblyStyle", ($self) => class FormatterAssemblyStyle extends $.$spc.System.Enum
        {
            static Simple = 0;
            static Full = 1;
            static $map;
            static get Map()
            {
                return this.$map ??= 
                {
                    "Simple": 0n,
                    "Full": 1n
                };
            }
            static $h = 632335;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static get $eut() { return $.$spc.System.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {"b":1048577,"u":655361,"l":[{"t":632335,"n":"Simple","d":632335,"h":4295599631,"f":33},{"t":632335,"n":"Full","d":632335,"h":8590566927,"f":33}],"c":[{"n":".ctor","o":"$ctor$3","d":632335,"h":12885534223,"f":1}],"i":[57212929,63766529,57671681,57344001],"h":632335,"a":[{"t":70909953,"c":8660844545,"a":[{"v":"Formatter-based serialization is obsolete and should not be used.","t":1310721}],"n":[{"n":"DiagnosticId","v":"SYSLIB0050","t":1310721},{"n":"UrlFormat","v":"https://aka.ms/dotnet-warnings/{0}","t":1310721}]}]}; }
            static get $b() { return $.$spc.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IComparable, $.$spc.System.ISpanFormattable, $.$spc.System.IFormattable, $.$spc.System.IConvertible ]; }
            static get $fullName() { return `System.Runtime.Serialization.Formatters.FormatterAssemblyStyle`; }
        });
        
        $asm.$str("$srsf.System.Runtime.Serialization.Formatters.TypeFilterLevel", ($self) => class TypeFilterLevel extends $.$spc.System.Enum
        {
            static Low = 2;
            static Full = 3;
            static $map;
            static get Map()
            {
                return this.$map ??= 
                {
                    "Low": 2n,
                    "Full": 3n
                };
            }
            static $h = 828943;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static get $eut() { return $.$spc.System.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {"b":1048577,"u":655361,"l":[{"t":828943,"n":"Low","d":828943,"h":4295796239,"f":33},{"t":828943,"n":"Full","d":828943,"h":8590763535,"f":33}],"c":[{"n":".ctor","o":"$ctor$3","d":828943,"h":12885730831,"f":1}],"i":[57212929,63766529,57671681,57344001],"h":828943,"a":[{"t":70909953,"c":8660844545,"a":[{"v":"Formatter-based serialization is obsolete and should not be used.","t":1310721}],"n":[{"n":"DiagnosticId","v":"SYSLIB0050","t":1310721},{"n":"UrlFormat","v":"https://aka.ms/dotnet-warnings/{0}","t":1310721}]}]}; }
            static get $b() { return $.$spc.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IComparable, $.$spc.System.ISpanFormattable, $.$spc.System.IFormattable, $.$spc.System.IConvertible ]; }
            static get $fullName() { return `System.Runtime.Serialization.Formatters.TypeFilterLevel`; }
        });
        
        $asm.$cls("$srsf.System.Runtime.Serialization.SurrogateHashtable", ($self) => class SurrogateHashtable extends $.$spc.System.Collections.Hashtable
        {
            $ctor$1(/*int*/ size)
            {
                super.$ctor$3(size);
                {
                }
                return this;
            }
            /*bool */ KeyEquals(/*object*/ key, /*object*/ item)
            {
                /*SurrogateKey*/ let givenValue = $.$cast(item, $.$srsf.System.Runtime.Serialization.SurrogateKey);
                /*SurrogateKey*/ let presentValue = $.$cast(key, $.$srsf.System.Runtime.Serialization.SurrogateKey);
                return $.$spc.System.Type.op_Equality$1(presentValue._type, givenValue._type) && (presentValue._context.State & givenValue._context.State) === givenValue._context.State && presentValue._context.Context === givenValue._context.Context;
            }
            static $h = 2139663;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":30932993,"m":[{"r":262145,"p":[{"n":"key","p":131073},{"n":"item","p":131073}],"n":"KeyEquals","d":2139663,"h":8592074255,"f":32772}],"c":[{"p":[{"n":"size","p":655361}],"n":".ctor","o":"$ctor$1","d":2139663,"h":4297106959,"f":8}],"i":[31457281,31326209,31588353,113377281,113115137,57147393],"h":2139663}; }
            static get $b() { return $.$spc.System.Collections.Hashtable; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.Collections.IDictionary, $.$spc.System.Collections.ICollection, $.$spc.System.Collections.IEnumerable, $.$spc.System.Runtime.Serialization.ISerializable, $.$spc.System.Runtime.Serialization.IDeserializationCallback, $.$spc.System.ICloneable ]; }
            static get $fullName() { return `System.Runtime.Serialization.SurrogateHashtable`; }
        });
        
        $asm.$cls("$srsf.System.Runtime.Serialization.DeserializationEventHandler", ($self) => class DeserializationEventHandler extends $.$spc.System.MulticastDelegate
        {
            $ctor(/*object*/ target, fn)
            {
                this._target = target;
                this.$nativeFunction = fn;
                return this;
            }
            /*void*/ Invoke(/*$.$spc.System.Nullable$$*/ $sender)
            {
                return this.$nativeFunction.apply(this._target, arguments);
            }
            static $h = 239119;
            static $f = 0b10000000;
            static $k = 5;
            static $$md;
            static get $md() { return this.$$md ??= {"b":66191361,"m":[{"r":65537,"p":[{"n":"sender","p":131073}],"n":"Invoke","d":239119,"h":8590173711,"f":129},{"r":56950785,"p":[{"n":"sender","p":131073},{"n":"callback","p":14417921},{"n":"object","p":131073}],"n":"BeginInvoke","d":239119,"h":12885141007,"f":129},{"r":65537,"p":[{"n":"result","p":56950785}],"n":"EndInvoke","d":239119,"h":17180108303,"f":129}],"c":[{"p":[{"n":"object","p":131073},{"n":"method","p":786433}],"n":".ctor","o":"$ctor$5","d":239119,"h":4295206415,"f":1}],"i":[57147393,113377281],"h":239119}; }
            static get $b() { return $.$spc.System.MulticastDelegate; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.ICloneable, $.$spc.System.Runtime.Serialization.ISerializable ]; }
            static get $fullName() { return `System.Runtime.Serialization.DeserializationEventHandler`; }
        });
        
        $asm.$cls("$srsf.System.Runtime.Serialization.SerializationEventHandler", ($self) => class SerializationEventHandler extends $.$spc.System.MulticastDelegate
        {
            $ctor(/*object*/ target, fn)
            {
                this._target = target;
                this.$nativeFunction = fn;
                return this;
            }
            /*void*/ Invoke(/**/ $context)
            {
                return this.$nativeFunction.apply(this._target, arguments);
            }
            static $h = 1680911;
            static $f = 0b10000001;
            static $k = 5;
            static $$md;
            static get $md() { return this.$$md ??= {"b":66191361,"m":[{"r":65537,"p":[{"n":"context","p":114098177}],"n":"Invoke","d":1680911,"h":8591615503,"f":129},{"r":56950785,"p":[{"n":"context","p":114098177},{"n":"callback","p":14417921},{"n":"object","p":131073}],"n":"BeginInvoke","d":1680911,"h":12886582799,"f":129},{"r":65537,"p":[{"n":"result","p":56950785}],"n":"EndInvoke","d":1680911,"h":17181550095,"f":129}],"c":[{"p":[{"n":"object","p":131073},{"n":"method","p":786433}],"n":".ctor","o":"$ctor$5","d":1680911,"h":4296648207,"f":1}],"i":[57147393,113377281],"h":1680911}; }
            static get $b() { return $.$spc.System.MulticastDelegate; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.ICloneable, $.$spc.System.Runtime.Serialization.ISerializable ]; }
            static get $fullName() { return `System.Runtime.Serialization.SerializationEventHandler`; }
        });
	});
})(window, window.NetJs.$boot(), ...window.NetJs.$require("NetJs.System.Private.CoreLib", "NetJs.System.Collections", "NetJs.System.Diagnostics.Tracing", "NetJs.System.Memory", "NetJs.System.Private.Uri", "NetJs.System.Threading", "NetJs.System.Runtime", "NetJs.System.Collections.Concurrent", "NetJs.System.Collections.NonGeneric"))