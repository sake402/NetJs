
//--TRIMMABLE-BOUNDARY-START(28)
(function ($global, $, $$, $sm, $spu, $sr) {
    "use strict";
    let _;
    
    
    
	$.$asm(
    "NetJs.System.Runtime.Serialization.Primitives", 
    {
  "h": 28,
  "f": "System.Runtime.Serialization.Primitives",
  "v": "1.0.35.0",
  "a": [
    {
      "t": 133824513,
      "c": 8723759105,
      "a": [
        {
          "v": 157548545,
          "t": 187760641
        }
      ]
    },
    {
      "t": 133824513,
      "c": 8723759105,
      "a": [
        {
          "v": 157614081,
          "t": 187760641
        }
      ]
    },
    {
      "t": 133824513,
      "c": 8723759105,
      "a": [
        {
          "v": 157679617,
          "t": 187760641
        }
      ]
    },
    {
      "t": 133824513,
      "c": 8723759105,
      "a": [
        {
          "v": 157745153,
          "t": 187760641
        }
      ]
    },
    {
      "t": 133824513,
      "c": 8723759105,
      "a": [
        {
          "v": 158007297,
          "t": 187760641
        }
      ]
    },
    {
      "t": 133824513,
      "c": 8723759105,
      "a": [
        {
          "v": 158203905,
          "t": 187760641
        }
      ]
    },
    {
      "t": 133824513,
      "c": 8723759105,
      "a": [
        {
          "v": 158269441,
          "t": 187760641
        }
      ]
    },
    {
      "t": 159252481,
      "c": 13044154369,
      "a": [
        {
          "v": ".NETCoreApp,Version=v10.0",
          "t": 1310721
        }
      ],
      "n": [
        {
          "n": "FrameworkDisplayName",
          "v": ".NET 10.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 106430465,
      "c": 8696365057,
      "a": [
        {
          "v": "SIT",
          "t": 1310721
        }
      ]
    },
    {
      "t": 106496001,
      "c": 8696430593,
      "a": [
        {
          "v": "Debug",
          "t": 1310721
        }
      ]
    },
    {
      "t": 106954753,
      "c": 8696889345,
      "a": [
        {
          "v": "1.0.35.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107085825,
      "c": 8697020417,
      "a": [
        {
          "v": "1.0.35\u002Bdf6f45b09d58f65c84d384efc8772929a0c6464b",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107937793,
      "c": 8697872385,
      "a": [
        {
          "v": "NetJs.System.Runtime.Serialization.Primitives",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108068865,
      "c": 8698003457,
      "a": [
        {
          "v": "NetJs.System.Runtime.Serialization.Primitives",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108199937,
      "c": 8698134529,
      "a": [
        {
          "v": "1.0.35.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 159318017,
      "c": 4454285313,
      "a": [
        {
          "v": "browser1.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 159055873,
      "c": 4454023169,
      "a": [
        {
          "v": "browser1.0",
          "t": 1310721
        }
      ]
    }
  ],
  "m": []
},
    function($asm)
	{
        
        
        //--TRIMMABLE-BOUNDARY-START(589852)
        $asm.$cls("$srsp.System.Runtime.Serialization.ISerializationSurrogateProvider", ($self) => class ISerializationSurrogateProvider
        {
            static $h = 589852;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(12885491740),
    {
      "r": 187760641,
      "p": [
        {
          "n": "type",
          "p": 187760641
        }
      ],
      "n": "GetSurrogateType",
      "o": "System$Runtime$Serialization$ISerializationSurrogateProvider$GetSurrogateType",
      "d": 589852,
      "h": 12885491740,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(12885491740),
//--TRIMMABLE-BOUNDARY-START(8590524444),
    {
      "r": 131073,
      "p": [
        {
          "n": "obj",
          "p": 131073
        },
        {
          "n": "targetType",
          "p": 187760641
        }
      ],
      "n": "GetObjectToSerialize",
      "o": "System$Runtime$Serialization$ISerializationSurrogateProvider$GetObjectToSerialize",
      "d": 589852,
      "h": 8590524444,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(8590524444),
//--TRIMMABLE-BOUNDARY-START(4295557148),
    {
      "r": 131073,
      "p": [
        {
          "n": "obj",
          "p": 131073
        },
        {
          "n": "targetType",
          "p": 187760641
        }
      ],
      "n": "GetDeserializedObject",
      "o": "System$Runtime$Serialization$ISerializationSurrogateProvider$GetDeserializedObject",
      "d": 589852,
      "h": 4295557148,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(4295557148)
  ],
  "h": 589852
}; }
            static get $fullName() { return `System.Runtime.Serialization.ISerializationSurrogateProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(589852)
        
        
        //--TRIMMABLE-BOUNDARY-START(655388)
        $asm.$cls("$srsp.System.Runtime.Serialization.ISerializationSurrogateProvider2", ($self) => class ISerializationSurrogateProvider2
        {
            static $h = 655388;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4295622684),
    {
      "r": 131073,
      "p": [
        {
          "n": "memberInfo",
          "p": 115474433
        },
        {
          "n": "dataContractType",
          "p": 187760641
        }
      ],
      "n": "GetCustomDataToExport",
      "o": "System$Runtime$Serialization$ISerializationSurrogateProvider2$GetCustomDataToExport",
      "d": 655388,
      "h": 4295622684,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(4295622684),
//--TRIMMABLE-BOUNDARY-START(8590589980),
    {
      "r": 131073,
      "p": [
        {
          "n": "runtimeType",
          "p": 187760641
        },
        {
          "n": "dataContractType",
          "p": 187760641
        }
      ],
      "n": "GetCustomDataToExport",
      "o": "System$Runtime$Serialization$ISerializationSurrogateProvider2$GetCustomDataToExport$1",
      "d": 655388,
      "h": 8590589980,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(8590589980),
//--TRIMMABLE-BOUNDARY-START(12885557276),
    {
      "r": 65537,
      "p": [
        {
          "n": "customDataTypes",
          "p": $.$$.System.Collections.ObjectModel.Collection$$($.$$.System.Type).$h
        }
      ],
      "n": "GetKnownCustomDataTypes",
      "o": "System$Runtime$Serialization$ISerializationSurrogateProvider2$GetKnownCustomDataTypes",
      "d": 655388,
      "h": 12885557276,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(12885557276),
//--TRIMMABLE-BOUNDARY-START(17180524572),
    {
      "r": 187760641,
      "p": [
        {
          "n": "typeName",
          "p": 1310721
        },
        {
          "n": "typeNamespace",
          "p": 1310721
        },
        {
          "n": "customData",
          "p": 131073
        }
      ],
      "n": "GetReferencedTypeOnImport",
      "o": "System$Runtime$Serialization$ISerializationSurrogateProvider2$GetReferencedTypeOnImport",
      "d": 655388,
      "h": 17180524572,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(17180524572)
  ],
  "i": [589852
  ],
  "h": 655388
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$srsp.System.Runtime.Serialization.ISerializationSurrogateProvider ]; }
            static get $fullName() { return `System.Runtime.Serialization.ISerializationSurrogateProvider2`; }
        });
        //--TRIMMABLE-BOUNDARY-END(655388)
        
        
        //--TRIMMABLE-BOUNDARY-START(65564)
        $asm.$cls("$srsp.System.Obsoletions", ($self) => class Obsoletions
        {
            //--TRIMMABLE-BOUNDARY-START(382252154908)
            /*string*/ static SharedUrlFormat = null;
            //--TRIMMABLE-BOUNDARY-END(382252154908)
            
            //--TRIMMABLE-BOUNDARY-START(433791762460)
            /*string*/ static SystemTextEncodingUTF7Message = null;
            //--TRIMMABLE-BOUNDARY-END(433791762460)
            
            //--TRIMMABLE-BOUNDARY-START(429496795164)
            /*string*/ static SystemTextEncodingUTF7DiagId = null;
            //--TRIMMABLE-BOUNDARY-END(429496795164)
            
            //--TRIMMABLE-BOUNDARY-START(266288037916)
            /*string*/ static PrincipalPermissionAttributeMessage = null;
            //--TRIMMABLE-BOUNDARY-END(266288037916)
            
            //--TRIMMABLE-BOUNDARY-START(261993070620)
            /*string*/ static PrincipalPermissionAttributeDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(261993070620)
            
            //--TRIMMABLE-BOUNDARY-START(77309476892)
            /*string*/ static CodeAccessSecurityMessage = null;
            //--TRIMMABLE-BOUNDARY-END(77309476892)
            
            //--TRIMMABLE-BOUNDARY-START(73014509596)
            /*string*/ static CodeAccessSecurityDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(73014509596)
            
            //--TRIMMABLE-BOUNDARY-START(94489346076)
            /*string*/ static ConstrainedExecutionRegionMessage = null;
            //--TRIMMABLE-BOUNDARY-END(94489346076)
            
            //--TRIMMABLE-BOUNDARY-START(90194378780)
            /*string*/ static ConstrainedExecutionRegionDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(90194378780)
            
            //--TRIMMABLE-BOUNDARY-START(214748430364)
            /*string*/ static GlobalAssemblyCacheMessage = null;
            //--TRIMMABLE-BOUNDARY-END(214748430364)
            
            //--TRIMMABLE-BOUNDARY-START(210453463068)
            /*string*/ static GlobalAssemblyCacheDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(210453463068)
            
            //--TRIMMABLE-BOUNDARY-START(442381697052)
            /*string*/ static ThreadAbortMessage = null;
            //--TRIMMABLE-BOUNDARY-END(442381697052)
            
            //--TRIMMABLE-BOUNDARY-START(446676664348)
            /*string*/ static ThreadResetAbortMessage = null;
            //--TRIMMABLE-BOUNDARY-END(446676664348)
            
            //--TRIMMABLE-BOUNDARY-START(438086729756)
            /*string*/ static ThreadAbortDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(438086729756)
            
            //--TRIMMABLE-BOUNDARY-START(146028953628)
            /*string*/ static DefaultCryptoAlgorithmsMessage = null;
            //--TRIMMABLE-BOUNDARY-END(146028953628)
            
            //--TRIMMABLE-BOUNDARY-START(141733986332)
            /*string*/ static DefaultCryptoAlgorithmsDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(141733986332)
            
            //--TRIMMABLE-BOUNDARY-START(120259149852)
            /*string*/ static CreatePdbGeneratorMessage = null;
            //--TRIMMABLE-BOUNDARY-END(120259149852)
            
            //--TRIMMABLE-BOUNDARY-START(115964182556)
            /*string*/ static CreatePdbGeneratorDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(115964182556)
            
            //--TRIMMABLE-BOUNDARY-START(51539673116)
            /*string*/ static AuthenticationManagerMessage = null;
            //--TRIMMABLE-BOUNDARY-END(51539673116)
            
            //--TRIMMABLE-BOUNDARY-START(47244705820)
            /*string*/ static AuthenticationManagerDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(47244705820)
            
            //--TRIMMABLE-BOUNDARY-START(326417580060)
            /*string*/ static RemotingApisMessage = null;
            //--TRIMMABLE-BOUNDARY-END(326417580060)
            
            //--TRIMMABLE-BOUNDARY-START(322122612764)
            /*string*/ static RemotingApisDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(322122612764)
            
            //--TRIMMABLE-BOUNDARY-START(60129607708)
            /*string*/ static BinaryFormatterMessage = null;
            //--TRIMMABLE-BOUNDARY-END(60129607708)
            
            //--TRIMMABLE-BOUNDARY-START(55834640412)
            /*string*/ static BinaryFormatterDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(55834640412)
            
            //--TRIMMABLE-BOUNDARY-START(85899411484)
            /*string*/ static CodeBaseMessage = null;
            //--TRIMMABLE-BOUNDARY-END(85899411484)
            
            //--TRIMMABLE-BOUNDARY-START(81604444188)
            /*string*/ static CodeBaseDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(81604444188)
            
            //--TRIMMABLE-BOUNDARY-START(197568561180)
            /*string*/ static EscapeUriStringMessage = null;
            //--TRIMMABLE-BOUNDARY-END(197568561180)
            
            //--TRIMMABLE-BOUNDARY-START(193273593884)
            /*string*/ static EscapeUriStringDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(193273593884)
            
            //--TRIMMABLE-BOUNDARY-START(489626337308)
            /*string*/ static WebRequestMessage = null;
            //--TRIMMABLE-BOUNDARY-END(489626337308)
            
            //--TRIMMABLE-BOUNDARY-START(485331370012)
            /*string*/ static WebRequestDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(485331370012)
            
            //--TRIMMABLE-BOUNDARY-START(163208822812)
            /*string*/ static DisablePrivateReflectionAttributeMessage = null;
            //--TRIMMABLE-BOUNDARY-END(163208822812)
            
            //--TRIMMABLE-BOUNDARY-START(158913855516)
            /*string*/ static DisablePrivateReflectionAttributeDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(158913855516)
            
            //--TRIMMABLE-BOUNDARY-START(206158495772)
            /*string*/ static GetContextInfoMessage = null;
            //--TRIMMABLE-BOUNDARY-END(206158495772)
            
            //--TRIMMABLE-BOUNDARY-START(201863528476)
            /*string*/ static GetContextInfoDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(201863528476)
            
            //--TRIMMABLE-BOUNDARY-START(399432024092)
            /*string*/ static StrongNameKeyPairMessage = null;
            //--TRIMMABLE-BOUNDARY-END(399432024092)
            
            //--TRIMMABLE-BOUNDARY-START(395137056796)
            /*string*/ static StrongNameKeyPairDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(395137056796)
            
            //--TRIMMABLE-BOUNDARY-START(300647776284)
            /*string*/ static ReflectionOnlyLoadingMessage = null;
            //--TRIMMABLE-BOUNDARY-END(300647776284)
            
            //--TRIMMABLE-BOUNDARY-START(296352808988)
            /*string*/ static ReflectionOnlyLoadingDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(296352808988)
            
            //--TRIMMABLE-BOUNDARY-START(377957187612)
            /*string*/ static RuntimeEnvironmentMessage = null;
            //--TRIMMABLE-BOUNDARY-END(377957187612)
            
            //--TRIMMABLE-BOUNDARY-START(373662220316)
            /*string*/ static RuntimeEnvironmentDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(373662220316)
            
            //--TRIMMABLE-BOUNDARY-START(231928299548)
            /*string*/ static JsonSerializerOptionsIgnoreNullValuesMessage = null;
            //--TRIMMABLE-BOUNDARY-END(231928299548)
            
            //--TRIMMABLE-BOUNDARY-START(227633332252)
            /*string*/ static JsonSerializerOptionsIgnoreNullValuesDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(227633332252)
            
            //--TRIMMABLE-BOUNDARY-START(154618888220)
            /*string*/ static DerivedCryptographicTypesMessage = null;
            //--TRIMMABLE-BOUNDARY-END(154618888220)
            
            //--TRIMMABLE-BOUNDARY-START(150323920924)
            /*string*/ static DerivedCryptographicTypesDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(150323920924)
            
            //--TRIMMABLE-BOUNDARY-START(352187383836)
            /*string*/ static RijndaelMessage = null;
            //--TRIMMABLE-BOUNDARY-END(352187383836)
            
            //--TRIMMABLE-BOUNDARY-START(347892416540)
            /*string*/ static RijndaelDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(347892416540)
            
            //--TRIMMABLE-BOUNDARY-START(360777318428)
            /*string*/ static RNGCryptoServiceProviderMessage = null;
            //--TRIMMABLE-BOUNDARY-END(360777318428)
            
            //--TRIMMABLE-BOUNDARY-START(356482351132)
            /*string*/ static RNGCryptoServiceProviderDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(356482351132)
            
            //--TRIMMABLE-BOUNDARY-START(17179934748)
            /*string*/ static AppDomainCreateUnloadMessage = null;
            //--TRIMMABLE-BOUNDARY-END(17179934748)
            
            //--TRIMMABLE-BOUNDARY-START(12884967452)
            /*string*/ static AppDomainCreateUnloadDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(12884967452)
            
            //--TRIMMABLE-BOUNDARY-START(408021958684)
            /*string*/ static SuppressIldasmAttributeMessage = null;
            //--TRIMMABLE-BOUNDARY-END(408021958684)
            
            //--TRIMMABLE-BOUNDARY-START(403726991388)
            /*string*/ static SuppressIldasmAttributeDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(403726991388)
            
            //--TRIMMABLE-BOUNDARY-START(498216271900)
            /*string*/ static X509CertificateImmutableMessage = null;
            //--TRIMMABLE-BOUNDARY-END(498216271900)
            
            //--TRIMMABLE-BOUNDARY-START(493921304604)
            /*string*/ static X509CertificateImmutableDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(493921304604)
            
            //--TRIMMABLE-BOUNDARY-START(283467907100)
            /*string*/ static PublicKeyPropertyMessage = null;
            //--TRIMMABLE-BOUNDARY-END(283467907100)
            
            //--TRIMMABLE-BOUNDARY-START(279172939804)
            /*string*/ static PublicKeyPropertyDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(279172939804)
            
            //--TRIMMABLE-BOUNDARY-START(506806206492)
            /*string*/ static X509CertificatePrivateKeyMessage = null;
            //--TRIMMABLE-BOUNDARY-END(506806206492)
            
            //--TRIMMABLE-BOUNDARY-START(502511239196)
            /*string*/ static X509CertificatePrivateKeyDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(502511239196)
            
            //--TRIMMABLE-BOUNDARY-START(274877972508)
            /*string*/ static ProduceLegacyHmacValuesMessage = null;
            //--TRIMMABLE-BOUNDARY-END(274877972508)
            
            //--TRIMMABLE-BOUNDARY-START(270583005212)
            /*string*/ static ProduceLegacyHmacValuesDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(270583005212)
            
            //--TRIMMABLE-BOUNDARY-START(481036402716)
            /*string*/ static UseManagedSha1Message = null;
            //--TRIMMABLE-BOUNDARY-END(481036402716)
            
            //--TRIMMABLE-BOUNDARY-START(476741435420)
            /*string*/ static UseManagedSha1DiagId = null;
            //--TRIMMABLE-BOUNDARY-END(476741435420)
            
            //--TRIMMABLE-BOUNDARY-START(128849084444)
            /*string*/ static CryptoConfigEncodeOIDMessage = null;
            //--TRIMMABLE-BOUNDARY-END(128849084444)
            
            //--TRIMMABLE-BOUNDARY-START(124554117148)
            /*string*/ static CryptoConfigEncodeOIDDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(124554117148)
            
            //--TRIMMABLE-BOUNDARY-START(111669215260)
            /*string*/ static CorruptedStateRecoveryMessage = null;
            //--TRIMMABLE-BOUNDARY-END(111669215260)
            
            //--TRIMMABLE-BOUNDARY-START(107374247964)
            /*string*/ static CorruptedStateRecoveryDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(107374247964)
            
            //--TRIMMABLE-BOUNDARY-START(335007514652)
            /*string*/ static Rfc2898CryptDeriveKeyMessage = null;
            //--TRIMMABLE-BOUNDARY-END(335007514652)
            
            //--TRIMMABLE-BOUNDARY-START(330712547356)
            /*string*/ static Rfc2898CryptDeriveKeyDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(330712547356)
            
            //--TRIMMABLE-BOUNDARY-START(68719542300)
            /*string*/ static CmsSignerCspParamsCtorMessage = null;
            //--TRIMMABLE-BOUNDARY-END(68719542300)
            
            //--TRIMMABLE-BOUNDARY-START(64424575004)
            /*string*/ static CmsSignerCspParamsCtorDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(64424575004)
            
            //--TRIMMABLE-BOUNDARY-START(390842089500)
            /*string*/ static SignerInfoCounterSigMessage = null;
            //--TRIMMABLE-BOUNDARY-END(390842089500)
            
            //--TRIMMABLE-BOUNDARY-START(386547122204)
            /*string*/ static SignerInfoCounterSigDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(386547122204)
            
            //--TRIMMABLE-BOUNDARY-START(309237710876)
            /*string*/ static RegexCompileToAssemblyMessage = null;
            //--TRIMMABLE-BOUNDARY-END(309237710876)
            
            //--TRIMMABLE-BOUNDARY-START(304942743580)
            /*string*/ static RegexCompileToAssemblyDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(304942743580)
            
            //--TRIMMABLE-BOUNDARY-START(42949738524)
            /*string*/ static AssemblyNameMembersMessage = null;
            //--TRIMMABLE-BOUNDARY-END(42949738524)
            
            //--TRIMMABLE-BOUNDARY-START(38654771228)
            /*string*/ static AssemblyNameMembersDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(38654771228)
            
            //--TRIMMABLE-BOUNDARY-START(416611893276)
            /*string*/ static SystemDataSerializationFormatBinaryMessage = null;
            //--TRIMMABLE-BOUNDARY-END(416611893276)
            
            //--TRIMMABLE-BOUNDARY-START(412316925980)
            /*string*/ static SystemDataSerializationFormatBinaryDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(412316925980)
            
            //--TRIMMABLE-BOUNDARY-START(472446468124)
            /*string*/ static TlsVersion10and11Message = null;
            //--TRIMMABLE-BOUNDARY-END(472446468124)
            
            //--TRIMMABLE-BOUNDARY-START(468151500828)
            /*string*/ static TlsVersion10and11DiagId = null;
            //--TRIMMABLE-BOUNDARY-END(468151500828)
            
            //--TRIMMABLE-BOUNDARY-START(188978626588)
            /*string*/ static EncryptionPolicyMessage = null;
            //--TRIMMABLE-BOUNDARY-END(188978626588)
            
            //--TRIMMABLE-BOUNDARY-START(184683659292)
            /*string*/ static EncryptionPolicyDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(184683659292)
            
            //--TRIMMABLE-BOUNDARY-START(171798757404)
            /*string*/ static EccXmlExportImportMessage = null;
            //--TRIMMABLE-BOUNDARY-END(171798757404)
            
            //--TRIMMABLE-BOUNDARY-START(167503790108)
            /*string*/ static EccXmlExportImportDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(167503790108)
            
            //--TRIMMABLE-BOUNDARY-START(180388691996)
            /*string*/ static EcDhPublicKeyBlobMessage = null;
            //--TRIMMABLE-BOUNDARY-END(180388691996)
            
            //--TRIMMABLE-BOUNDARY-START(176093724700)
            /*string*/ static EcDhPublicKeyBlobDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(176093724700)
            
            //--TRIMMABLE-BOUNDARY-START(34359803932)
            /*string*/ static AssemblyNameCodeBaseMessage = null;
            //--TRIMMABLE-BOUNDARY-END(34359803932)
            
            //--TRIMMABLE-BOUNDARY-START(30064836636)
            /*string*/ static AssemblyNameCodeBaseDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(30064836636)
            
            //--TRIMMABLE-BOUNDARY-START(137439019036)
            /*string*/ static CryptoStringFactoryMessage = null;
            //--TRIMMABLE-BOUNDARY-END(137439019036)
            
            //--TRIMMABLE-BOUNDARY-START(133144051740)
            /*string*/ static CryptoStringFactoryDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(133144051740)
            
            //--TRIMMABLE-BOUNDARY-START(103079280668)
            /*string*/ static ControlledExecutionRunMessage = null;
            //--TRIMMABLE-BOUNDARY-END(103079280668)
            
            //--TRIMMABLE-BOUNDARY-START(98784313372)
            /*string*/ static ControlledExecutionRunDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(98784313372)
            
            //--TRIMMABLE-BOUNDARY-START(523986075676)
            /*string*/ static XmlSecureResolverMessage = null;
            //--TRIMMABLE-BOUNDARY-END(523986075676)
            
            //--TRIMMABLE-BOUNDARY-START(519691108380)
            /*string*/ static XmlSecureResolverDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(519691108380)
            
            //--TRIMMABLE-BOUNDARY-START(369367253020)
            /*string*/ static RsaEncryptDecryptValueMessage = null;
            //--TRIMMABLE-BOUNDARY-END(369367253020)
            
            //--TRIMMABLE-BOUNDARY-START(365072285724)
            /*string*/ static RsaEncryptDecryptDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(365072285724)
            
            //--TRIMMABLE-BOUNDARY-START(223338364956)
            /*string*/ static JsonSerializerOptionsAddContextMessage = null;
            //--TRIMMABLE-BOUNDARY-END(223338364956)
            
            //--TRIMMABLE-BOUNDARY-START(219043397660)
            /*string*/ static JsonSerializerOptionsAddContextDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(219043397660)
            
            //--TRIMMABLE-BOUNDARY-START(249108168732)
            /*string*/ static LegacyFormatterMessage = null;
            //--TRIMMABLE-BOUNDARY-END(249108168732)
            
            //--TRIMMABLE-BOUNDARY-START(236223266844)
            /*string*/ static LegacyFormatterDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(236223266844)
            
            //--TRIMMABLE-BOUNDARY-START(244813201436)
            /*string*/ static LegacyFormatterImplMessage = null;
            //--TRIMMABLE-BOUNDARY-END(244813201436)
            
            //--TRIMMABLE-BOUNDARY-START(240518234140)
            /*string*/ static LegacyFormatterImplDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(240518234140)
            
            //--TRIMMABLE-BOUNDARY-START(317827645468)
            /*string*/ static RegexExtensibilityImplMessage = null;
            //--TRIMMABLE-BOUNDARY-END(317827645468)
            
            //--TRIMMABLE-BOUNDARY-START(313532678172)
            /*string*/ static RegexExtensibilityDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(313532678172)
            
            //--TRIMMABLE-BOUNDARY-START(8590000156)
            /*string*/ static AesGcmTagConstructorMessage = null;
            //--TRIMMABLE-BOUNDARY-END(8590000156)
            
            //--TRIMMABLE-BOUNDARY-START(4295032860)
            /*string*/ static AesGcmTagConstructorDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(4295032860)
            
            //--TRIMMABLE-BOUNDARY-START(455266598940)
            /*string*/ static ThreadVolatileReadWriteMessage = null;
            //--TRIMMABLE-BOUNDARY-END(455266598940)
            
            //--TRIMMABLE-BOUNDARY-START(450971631644)
            /*string*/ static ThreadVolatileReadWriteDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(450971631644)
            
            //--TRIMMABLE-BOUNDARY-START(25769869340)
            /*string*/ static ArmIntrinsicPerformsUnsignedOperationMessage = null;
            //--TRIMMABLE-BOUNDARY-END(25769869340)
            
            //--TRIMMABLE-BOUNDARY-START(21474902044)
            /*string*/ static ArmIntrinsicPerformsUnsignedOperationDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(21474902044)
            
            //--TRIMMABLE-BOUNDARY-START(257698103324)
            /*string*/ static LoadFromHashAlgorithmMessage = null;
            //--TRIMMABLE-BOUNDARY-END(257698103324)
            
            //--TRIMMABLE-BOUNDARY-START(253403136028)
            /*string*/ static LoadFromHashAlgorithmDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(253403136028)
            
            //--TRIMMABLE-BOUNDARY-START(515396141084)
            /*string*/ static X509CtorCertDataObsoleteMessage = null;
            //--TRIMMABLE-BOUNDARY-END(515396141084)
            
            //--TRIMMABLE-BOUNDARY-START(511101173788)
            /*string*/ static X509CtorCertDataObsoleteDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(511101173788)
            
            //--TRIMMABLE-BOUNDARY-START(463856533532)
            /*string*/ static TlsCipherAlgorithmEnumsMessage = null;
            //--TRIMMABLE-BOUNDARY-END(463856533532)
            
            //--TRIMMABLE-BOUNDARY-START(459561566236)
            /*string*/ static TlsCipherAlgorithmEnumsDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(459561566236)
            
            //--TRIMMABLE-BOUNDARY-START(425201827868)
            /*string*/ static SystemEventsEventsThreadShutdownMessage = null;
            //--TRIMMABLE-BOUNDARY-END(425201827868)
            
            //--TRIMMABLE-BOUNDARY-START(420906860572)
            /*string*/ static SystemEventsEventsThreadShutdownDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(420906860572)
            
            //--TRIMMABLE-BOUNDARY-START(343597449244)
            /*string*/ static Rfc2898DeriveBytesCtorMessage = null;
            //--TRIMMABLE-BOUNDARY-END(343597449244)
            
            //--TRIMMABLE-BOUNDARY-START(339302481948)
            /*string*/ static Rfc2898DeriveBytesCtorDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(339302481948)
            
            //--TRIMMABLE-BOUNDARY-START(292057841692)
            /*string*/ static QueryableMinByMaxByTSourceObsoleteMessage = null;
            //--TRIMMABLE-BOUNDARY-END(292057841692)
            
            //--TRIMMABLE-BOUNDARY-START(287762874396)
            /*string*/ static QueryableMinByMaxByTSourceObsoleteDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(287762874396)
            
            //--TRIMMABLE-BOUNDARY-START(532576010268)
            /*string*/ static XsltSettingsEnableScriptMessage = null;
            //--TRIMMABLE-BOUNDARY-END(532576010268)
            
            //--TRIMMABLE-BOUNDARY-START(528281042972)
            /*string*/ static XsltSettingsEnableScriptDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(528281042972)
            
            //--TRIMMABLE-BOUNDARY-START(SINIT)
            //Static Initializer
            static $sinit()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(382252154908)
                    this.SharedUrlFormat = "https://aka.ms/dotnet-warnings/{0}";
                    //--TRIMMABLE-BOUNDARY-END(382252154908)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(433791762460)
                    this.SystemTextEncodingUTF7Message = "The UTF-7 encoding is insecure and should not be used. Consider using UTF-8 instead.";
                    //--TRIMMABLE-BOUNDARY-END(433791762460)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(429496795164)
                    this.SystemTextEncodingUTF7DiagId = "SYSLIB0001";
                    //--TRIMMABLE-BOUNDARY-END(429496795164)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(266288037916)
                    this.PrincipalPermissionAttributeMessage = "PrincipalPermissionAttribute is not honored by the runtime and must not be used.";
                    //--TRIMMABLE-BOUNDARY-END(266288037916)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(261993070620)
                    this.PrincipalPermissionAttributeDiagId = "SYSLIB0002";
                    //--TRIMMABLE-BOUNDARY-END(261993070620)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(77309476892)
                    this.CodeAccessSecurityMessage = "Code Access Security is not supported or honored by the runtime.";
                    //--TRIMMABLE-BOUNDARY-END(77309476892)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(73014509596)
                    this.CodeAccessSecurityDiagId = "SYSLIB0003";
                    //--TRIMMABLE-BOUNDARY-END(73014509596)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(94489346076)
                    this.ConstrainedExecutionRegionMessage = "The Constrained Execution Region (CER) feature is not supported.";
                    //--TRIMMABLE-BOUNDARY-END(94489346076)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(90194378780)
                    this.ConstrainedExecutionRegionDiagId = "SYSLIB0004";
                    //--TRIMMABLE-BOUNDARY-END(90194378780)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(214748430364)
                    this.GlobalAssemblyCacheMessage = "The Global Assembly Cache is not supported.";
                    //--TRIMMABLE-BOUNDARY-END(214748430364)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(210453463068)
                    this.GlobalAssemblyCacheDiagId = "SYSLIB0005";
                    //--TRIMMABLE-BOUNDARY-END(210453463068)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(442381697052)
                    this.ThreadAbortMessage = "Thread.Abort is not supported and throws PlatformNotSupportedException.";
                    //--TRIMMABLE-BOUNDARY-END(442381697052)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(446676664348)
                    this.ThreadResetAbortMessage = "Thread.ResetAbort is not supported and throws PlatformNotSupportedException.";
                    //--TRIMMABLE-BOUNDARY-END(446676664348)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(438086729756)
                    this.ThreadAbortDiagId = "SYSLIB0006";
                    //--TRIMMABLE-BOUNDARY-END(438086729756)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(146028953628)
                    this.DefaultCryptoAlgorithmsMessage = "The default implementation of this cryptography algorithm is not supported.";
                    //--TRIMMABLE-BOUNDARY-END(146028953628)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(141733986332)
                    this.DefaultCryptoAlgorithmsDiagId = "SYSLIB0007";
                    //--TRIMMABLE-BOUNDARY-END(141733986332)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(120259149852)
                    this.CreatePdbGeneratorMessage = "The CreatePdbGenerator API is not supported and throws PlatformNotSupportedException.";
                    //--TRIMMABLE-BOUNDARY-END(120259149852)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(115964182556)
                    this.CreatePdbGeneratorDiagId = "SYSLIB0008";
                    //--TRIMMABLE-BOUNDARY-END(115964182556)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(51539673116)
                    this.AuthenticationManagerMessage = "AuthenticationManager is not supported. Methods will no-op or throw PlatformNotSupportedException.";
                    //--TRIMMABLE-BOUNDARY-END(51539673116)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(47244705820)
                    this.AuthenticationManagerDiagId = "SYSLIB0009";
                    //--TRIMMABLE-BOUNDARY-END(47244705820)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(326417580060)
                    this.RemotingApisMessage = "This Remoting API is not supported and throws PlatformNotSupportedException.";
                    //--TRIMMABLE-BOUNDARY-END(326417580060)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(322122612764)
                    this.RemotingApisDiagId = "SYSLIB0010";
                    //--TRIMMABLE-BOUNDARY-END(322122612764)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(60129607708)
                    this.BinaryFormatterMessage = "BinaryFormatter serialization is obsolete and should not be used. See https://aka.ms/binaryformatter for more information.";
                    //--TRIMMABLE-BOUNDARY-END(60129607708)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(55834640412)
                    this.BinaryFormatterDiagId = "SYSLIB0011";
                    //--TRIMMABLE-BOUNDARY-END(55834640412)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(85899411484)
                    this.CodeBaseMessage = "Assembly.CodeBase and Assembly.EscapedCodeBase are only included for .NET Framework compatibility. Use Assembly.Location instead.";
                    //--TRIMMABLE-BOUNDARY-END(85899411484)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(81604444188)
                    this.CodeBaseDiagId = "SYSLIB0012";
                    //--TRIMMABLE-BOUNDARY-END(81604444188)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(197568561180)
                    this.EscapeUriStringMessage = "Uri.EscapeUriString can corrupt the Uri string in some cases. Consider using Uri.EscapeDataString for query string components instead.";
                    //--TRIMMABLE-BOUNDARY-END(197568561180)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(193273593884)
                    this.EscapeUriStringDiagId = "SYSLIB0013";
                    //--TRIMMABLE-BOUNDARY-END(193273593884)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(489626337308)
                    this.WebRequestMessage = "WebRequest, HttpWebRequest, ServicePoint, and WebClient are obsolete. Use HttpClient instead.";
                    //--TRIMMABLE-BOUNDARY-END(489626337308)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(485331370012)
                    this.WebRequestDiagId = "SYSLIB0014";
                    //--TRIMMABLE-BOUNDARY-END(485331370012)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(163208822812)
                    this.DisablePrivateReflectionAttributeMessage = "DisablePrivateReflectionAttribute has no effect in .NET 6.0+.";
                    //--TRIMMABLE-BOUNDARY-END(163208822812)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(158913855516)
                    this.DisablePrivateReflectionAttributeDiagId = "SYSLIB0015";
                    //--TRIMMABLE-BOUNDARY-END(158913855516)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(206158495772)
                    this.GetContextInfoMessage = "Use the Graphics.GetContextInfo overloads that accept arguments for better performance and fewer allocations.";
                    //--TRIMMABLE-BOUNDARY-END(206158495772)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(201863528476)
                    this.GetContextInfoDiagId = "SYSLIB0016";
                    //--TRIMMABLE-BOUNDARY-END(201863528476)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(399432024092)
                    this.StrongNameKeyPairMessage = "Strong name signing is not supported and throws PlatformNotSupportedException.";
                    //--TRIMMABLE-BOUNDARY-END(399432024092)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(395137056796)
                    this.StrongNameKeyPairDiagId = "SYSLIB0017";
                    //--TRIMMABLE-BOUNDARY-END(395137056796)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(300647776284)
                    this.ReflectionOnlyLoadingMessage = "ReflectionOnly loading is not supported and throws PlatformNotSupportedException.";
                    //--TRIMMABLE-BOUNDARY-END(300647776284)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(296352808988)
                    this.ReflectionOnlyLoadingDiagId = "SYSLIB0018";
                    //--TRIMMABLE-BOUNDARY-END(296352808988)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(377957187612)
                    this.RuntimeEnvironmentMessage = "RuntimeEnvironment members SystemConfigurationFile, GetRuntimeInterfaceAsIntPtr, and GetRuntimeInterfaceAsObject are not supported and throw PlatformNotSupportedException.";
                    //--TRIMMABLE-BOUNDARY-END(377957187612)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(373662220316)
                    this.RuntimeEnvironmentDiagId = "SYSLIB0019";
                    //--TRIMMABLE-BOUNDARY-END(373662220316)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(231928299548)
                    this.JsonSerializerOptionsIgnoreNullValuesMessage = "JsonSerializerOptions.IgnoreNullValues is obsolete. To ignore null values when serializing, set DefaultIgnoreCondition to JsonIgnoreCondition.WhenWritingNull.";
                    //--TRIMMABLE-BOUNDARY-END(231928299548)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(227633332252)
                    this.JsonSerializerOptionsIgnoreNullValuesDiagId = "SYSLIB0020";
                    //--TRIMMABLE-BOUNDARY-END(227633332252)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(154618888220)
                    this.DerivedCryptographicTypesMessage = "Derived cryptographic types are obsolete. Use the Create method on the base type instead.";
                    //--TRIMMABLE-BOUNDARY-END(154618888220)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(150323920924)
                    this.DerivedCryptographicTypesDiagId = "SYSLIB0021";
                    //--TRIMMABLE-BOUNDARY-END(150323920924)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(352187383836)
                    this.RijndaelMessage = "The Rijndael and RijndaelManaged types are obsolete. Use Aes instead.";
                    //--TRIMMABLE-BOUNDARY-END(352187383836)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(347892416540)
                    this.RijndaelDiagId = "SYSLIB0022";
                    //--TRIMMABLE-BOUNDARY-END(347892416540)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(360777318428)
                    this.RNGCryptoServiceProviderMessage = "RNGCryptoServiceProvider is obsolete. To generate a random number, use one of the RandomNumberGenerator static methods instead.";
                    //--TRIMMABLE-BOUNDARY-END(360777318428)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(356482351132)
                    this.RNGCryptoServiceProviderDiagId = "SYSLIB0023";
                    //--TRIMMABLE-BOUNDARY-END(356482351132)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(17179934748)
                    this.AppDomainCreateUnloadMessage = "Creating and unloading AppDomains is not supported and throws an exception.";
                    //--TRIMMABLE-BOUNDARY-END(17179934748)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(12884967452)
                    this.AppDomainCreateUnloadDiagId = "SYSLIB0024";
                    //--TRIMMABLE-BOUNDARY-END(12884967452)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(408021958684)
                    this.SuppressIldasmAttributeMessage = "SuppressIldasmAttribute has no effect in .NET 6.0+.";
                    //--TRIMMABLE-BOUNDARY-END(408021958684)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(403726991388)
                    this.SuppressIldasmAttributeDiagId = "SYSLIB0025";
                    //--TRIMMABLE-BOUNDARY-END(403726991388)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(498216271900)
                    this.X509CertificateImmutableMessage = "X509Certificate and X509Certificate2 are immutable. Use X509CertificateLoader to create a new certificate.";
                    //--TRIMMABLE-BOUNDARY-END(498216271900)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(493921304604)
                    this.X509CertificateImmutableDiagId = "SYSLIB0026";
                    //--TRIMMABLE-BOUNDARY-END(493921304604)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(283467907100)
                    this.PublicKeyPropertyMessage = "PublicKey.Key is obsolete. Use the appropriate method to get the public key, such as GetRSAPublicKey.";
                    //--TRIMMABLE-BOUNDARY-END(283467907100)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(279172939804)
                    this.PublicKeyPropertyDiagId = "SYSLIB0027";
                    //--TRIMMABLE-BOUNDARY-END(279172939804)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(506806206492)
                    this.X509CertificatePrivateKeyMessage = "X509Certificate2.PrivateKey is obsolete. Use the appropriate method to get the private key, such as GetRSAPrivateKey, or use the CopyWithPrivateKey method to create a new instance with a private key.";
                    //--TRIMMABLE-BOUNDARY-END(506806206492)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(502511239196)
                    this.X509CertificatePrivateKeyDiagId = "SYSLIB0028";
                    //--TRIMMABLE-BOUNDARY-END(502511239196)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(274877972508)
                    this.ProduceLegacyHmacValuesMessage = "ProduceLegacyHmacValues is obsolete. Producing legacy HMAC values is not supported.";
                    //--TRIMMABLE-BOUNDARY-END(274877972508)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(270583005212)
                    this.ProduceLegacyHmacValuesDiagId = "SYSLIB0029";
                    //--TRIMMABLE-BOUNDARY-END(270583005212)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(481036402716)
                    this.UseManagedSha1Message = "HMACSHA1 always uses the algorithm implementation provided by the platform. Use a constructor without the useManagedSha1 parameter.";
                    //--TRIMMABLE-BOUNDARY-END(481036402716)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(476741435420)
                    this.UseManagedSha1DiagId = "SYSLIB0030";
                    //--TRIMMABLE-BOUNDARY-END(476741435420)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(128849084444)
                    this.CryptoConfigEncodeOIDMessage = "EncodeOID is obsolete. Use the ASN.1 functionality provided in System.Formats.Asn1.";
                    //--TRIMMABLE-BOUNDARY-END(128849084444)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(124554117148)
                    this.CryptoConfigEncodeOIDDiagId = "SYSLIB0031";
                    //--TRIMMABLE-BOUNDARY-END(124554117148)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(111669215260)
                    this.CorruptedStateRecoveryMessage = "Recovery from corrupted process state exceptions is not supported; HandleProcessCorruptedStateExceptionsAttribute is ignored.";
                    //--TRIMMABLE-BOUNDARY-END(111669215260)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(107374247964)
                    this.CorruptedStateRecoveryDiagId = "SYSLIB0032";
                    //--TRIMMABLE-BOUNDARY-END(107374247964)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(335007514652)
                    this.Rfc2898CryptDeriveKeyMessage = "Rfc2898DeriveBytes.CryptDeriveKey is obsolete and is not supported. Use PasswordDeriveBytes.CryptDeriveKey instead.";
                    //--TRIMMABLE-BOUNDARY-END(335007514652)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(330712547356)
                    this.Rfc2898CryptDeriveKeyDiagId = "SYSLIB0033";
                    //--TRIMMABLE-BOUNDARY-END(330712547356)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(68719542300)
                    this.CmsSignerCspParamsCtorMessage = "CmsSigner(CspParameters) is obsolete and is not supported. Use an alternative constructor instead.";
                    //--TRIMMABLE-BOUNDARY-END(68719542300)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(64424575004)
                    this.CmsSignerCspParamsCtorDiagId = "SYSLIB0034";
                    //--TRIMMABLE-BOUNDARY-END(64424575004)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(390842089500)
                    this.SignerInfoCounterSigMessage = "ComputeCounterSignature without specifying a CmsSigner is obsolete and is not supported. Use the overload that accepts a CmsSigner.";
                    //--TRIMMABLE-BOUNDARY-END(390842089500)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(386547122204)
                    this.SignerInfoCounterSigDiagId = "SYSLIB0035";
                    //--TRIMMABLE-BOUNDARY-END(386547122204)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(309237710876)
                    this.RegexCompileToAssemblyMessage = "Regex.CompileToAssembly is obsolete and not supported. Use the GeneratedRegexAttribute with the regular expression source generator instead.";
                    //--TRIMMABLE-BOUNDARY-END(309237710876)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(304942743580)
                    this.RegexCompileToAssemblyDiagId = "SYSLIB0036";
                    //--TRIMMABLE-BOUNDARY-END(304942743580)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(42949738524)
                    this.AssemblyNameMembersMessage = "AssemblyName members HashAlgorithm, ProcessorArchitecture, and VersionCompatibility are obsolete and not supported.";
                    //--TRIMMABLE-BOUNDARY-END(42949738524)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(38654771228)
                    this.AssemblyNameMembersDiagId = "SYSLIB0037";
                    //--TRIMMABLE-BOUNDARY-END(38654771228)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(416611893276)
                    this.SystemDataSerializationFormatBinaryMessage = "SerializationFormat.Binary is obsolete and should not be used. See https://aka.ms/serializationformat-binary-obsolete for more information.";
                    //--TRIMMABLE-BOUNDARY-END(416611893276)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(412316925980)
                    this.SystemDataSerializationFormatBinaryDiagId = "SYSLIB0038";
                    //--TRIMMABLE-BOUNDARY-END(412316925980)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(472446468124)
                    this.TlsVersion10and11Message = "TLS versions 1.0 and 1.1 have known vulnerabilities and are not recommended. Use a newer TLS version instead, or use SslProtocols.None to defer to OS defaults.";
                    //--TRIMMABLE-BOUNDARY-END(472446468124)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(468151500828)
                    this.TlsVersion10and11DiagId = "SYSLIB0039";
                    //--TRIMMABLE-BOUNDARY-END(468151500828)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(188978626588)
                    this.EncryptionPolicyMessage = "EncryptionPolicy.NoEncryption and AllowEncryption significantly reduce security and should not be used in production code.";
                    //--TRIMMABLE-BOUNDARY-END(188978626588)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(184683659292)
                    this.EncryptionPolicyDiagId = "SYSLIB0040";
                    //--TRIMMABLE-BOUNDARY-END(184683659292)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(171798757404)
                    this.EccXmlExportImportMessage = "ToXmlString and FromXmlString have no implementation for ECC types, and are obsolete. Use a standard import and export format such as ExportSubjectPublicKeyInfo or ImportSubjectPublicKeyInfo for public keys and ExportPkcs8PrivateKey or ImportPkcs8PrivateKey for private keys.";
                    //--TRIMMABLE-BOUNDARY-END(171798757404)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(167503790108)
                    this.EccXmlExportImportDiagId = "SYSLIB0042";
                    //--TRIMMABLE-BOUNDARY-END(167503790108)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(180388691996)
                    this.EcDhPublicKeyBlobMessage = "ECDiffieHellmanPublicKey.ToByteArray() and the associated constructor do not have a consistent and interoperable implementation on all platforms. Use ECDiffieHellmanPublicKey.ExportSubjectPublicKeyInfo() instead.";
                    //--TRIMMABLE-BOUNDARY-END(180388691996)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(176093724700)
                    this.EcDhPublicKeyBlobDiagId = "SYSLIB0043";
                    //--TRIMMABLE-BOUNDARY-END(176093724700)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(34359803932)
                    this.AssemblyNameCodeBaseMessage = "AssemblyName.CodeBase and AssemblyName.EscapedCodeBase are obsolete. Using them for loading an assembly is not supported.";
                    //--TRIMMABLE-BOUNDARY-END(34359803932)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(30064836636)
                    this.AssemblyNameCodeBaseDiagId = "SYSLIB0044";
                    //--TRIMMABLE-BOUNDARY-END(30064836636)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(137439019036)
                    this.CryptoStringFactoryMessage = "Cryptographic factory methods accepting an algorithm name are obsolete. Use the parameterless Create factory method on the algorithm type instead.";
                    //--TRIMMABLE-BOUNDARY-END(137439019036)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(133144051740)
                    this.CryptoStringFactoryDiagId = "SYSLIB0045";
                    //--TRIMMABLE-BOUNDARY-END(133144051740)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(103079280668)
                    this.ControlledExecutionRunMessage = "ControlledExecution.Run method may corrupt the process and should not be used in production code.";
                    //--TRIMMABLE-BOUNDARY-END(103079280668)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(98784313372)
                    this.ControlledExecutionRunDiagId = "SYSLIB0046";
                    //--TRIMMABLE-BOUNDARY-END(98784313372)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(523986075676)
                    this.XmlSecureResolverMessage = "XmlSecureResolver is obsolete. Use XmlResolver.ThrowingResolver instead when attempting to forbid XML external entity resolution.";
                    //--TRIMMABLE-BOUNDARY-END(523986075676)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(519691108380)
                    this.XmlSecureResolverDiagId = "SYSLIB0047";
                    //--TRIMMABLE-BOUNDARY-END(519691108380)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(369367253020)
                    this.RsaEncryptDecryptValueMessage = "RSA.EncryptValue and DecryptValue are not supported and throw NotSupportedException. Use RSA.Encrypt and RSA.Decrypt instead.";
                    //--TRIMMABLE-BOUNDARY-END(369367253020)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(365072285724)
                    this.RsaEncryptDecryptDiagId = "SYSLIB0048";
                    //--TRIMMABLE-BOUNDARY-END(365072285724)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(223338364956)
                    this.JsonSerializerOptionsAddContextMessage = "JsonSerializerOptions.AddContext is obsolete. To register a JsonSerializerContext, use either the TypeInfoResolver or TypeInfoResolverChain properties.";
                    //--TRIMMABLE-BOUNDARY-END(223338364956)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(219043397660)
                    this.JsonSerializerOptionsAddContextDiagId = "SYSLIB0049";
                    //--TRIMMABLE-BOUNDARY-END(219043397660)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(249108168732)
                    this.LegacyFormatterMessage = "Formatter-based serialization is obsolete and should not be used.";
                    //--TRIMMABLE-BOUNDARY-END(249108168732)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(236223266844)
                    this.LegacyFormatterDiagId = "SYSLIB0050";
                    //--TRIMMABLE-BOUNDARY-END(236223266844)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(244813201436)
                    this.LegacyFormatterImplMessage = "This API supports obsolete formatter-based serialization. It should not be called or extended by application code.";
                    //--TRIMMABLE-BOUNDARY-END(244813201436)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(240518234140)
                    this.LegacyFormatterImplDiagId = "SYSLIB0051";
                    //--TRIMMABLE-BOUNDARY-END(240518234140)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(317827645468)
                    this.RegexExtensibilityImplMessage = "This API supports obsolete mechanisms for Regex extensibility. It is not supported.";
                    //--TRIMMABLE-BOUNDARY-END(317827645468)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(313532678172)
                    this.RegexExtensibilityDiagId = "SYSLIB0052";
                    //--TRIMMABLE-BOUNDARY-END(313532678172)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(8590000156)
                    this.AesGcmTagConstructorMessage = "AesGcm should indicate the required tag size for encryption and decryption. Use a constructor that accepts the tag size.";
                    //--TRIMMABLE-BOUNDARY-END(8590000156)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(4295032860)
                    this.AesGcmTagConstructorDiagId = "SYSLIB0053";
                    //--TRIMMABLE-BOUNDARY-END(4295032860)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(455266598940)
                    this.ThreadVolatileReadWriteMessage = "Thread.VolatileRead and Thread.VolatileWrite are obsolete. Use Volatile.Read or Volatile.Write respectively instead.";
                    //--TRIMMABLE-BOUNDARY-END(455266598940)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(450971631644)
                    this.ThreadVolatileReadWriteDiagId = "SYSLIB0054";
                    //--TRIMMABLE-BOUNDARY-END(450971631644)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(25769869340)
                    this.ArmIntrinsicPerformsUnsignedOperationMessage = "The underlying hardware instruction does not perform a signed saturate narrowing operation, and it always returns an unsigned result. Use the unsigned overload instead.";
                    //--TRIMMABLE-BOUNDARY-END(25769869340)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(21474902044)
                    this.ArmIntrinsicPerformsUnsignedOperationDiagId = "SYSLIB0055";
                    //--TRIMMABLE-BOUNDARY-END(21474902044)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(257698103324)
                    this.LoadFromHashAlgorithmMessage = "LoadFrom with a custom AssemblyHashAlgorithm is obsolete. Use overloads without an AssemblyHashAlgorithm.";
                    //--TRIMMABLE-BOUNDARY-END(257698103324)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(253403136028)
                    this.LoadFromHashAlgorithmDiagId = "SYSLIB0056";
                    //--TRIMMABLE-BOUNDARY-END(253403136028)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(515396141084)
                    this.X509CtorCertDataObsoleteMessage = "Loading certificate data through the constructor or Import is obsolete. Use X509CertificateLoader instead to load certificates.";
                    //--TRIMMABLE-BOUNDARY-END(515396141084)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(511101173788)
                    this.X509CtorCertDataObsoleteDiagId = "SYSLIB0057";
                    //--TRIMMABLE-BOUNDARY-END(511101173788)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(463856533532)
                    this.TlsCipherAlgorithmEnumsMessage = "KeyExchangeAlgorithm, KeyExchangeStrength, CipherAlgorithm, CipherStrength, HashAlgorithm and HashStrength properties of SslStream are obsolete. Use NegotiatedCipherSuite instead.";
                    //--TRIMMABLE-BOUNDARY-END(463856533532)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(459561566236)
                    this.TlsCipherAlgorithmEnumsDiagId = "SYSLIB0058";
                    //--TRIMMABLE-BOUNDARY-END(459561566236)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(425201827868)
                    this.SystemEventsEventsThreadShutdownMessage = "SystemEvents.EventsThreadShutdown callbacks are not run before the process exits. Use AppDomain.ProcessExit instead.";
                    //--TRIMMABLE-BOUNDARY-END(425201827868)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(420906860572)
                    this.SystemEventsEventsThreadShutdownDiagId = "SYSLIB0059";
                    //--TRIMMABLE-BOUNDARY-END(420906860572)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(343597449244)
                    this.Rfc2898DeriveBytesCtorMessage = "The constructors on Rfc2898DeriveBytes are obsolete. Use the static Pbkdf2 method instead.";
                    //--TRIMMABLE-BOUNDARY-END(343597449244)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(339302481948)
                    this.Rfc2898DeriveBytesCtorDiagId = "SYSLIB0060";
                    //--TRIMMABLE-BOUNDARY-END(339302481948)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(292057841692)
                    this.QueryableMinByMaxByTSourceObsoleteMessage = "The Queryable MinBy and MaxBy taking an IComparer<TSource> are obsolete. Use the new ones that take an IComparer<TKey>.";
                    //--TRIMMABLE-BOUNDARY-END(292057841692)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(287762874396)
                    this.QueryableMinByMaxByTSourceObsoleteDiagId = "SYSLIB0061";
                    //--TRIMMABLE-BOUNDARY-END(287762874396)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(532576010268)
                    this.XsltSettingsEnableScriptMessage = "XSLT Script blocks are not supported.";
                    //--TRIMMABLE-BOUNDARY-END(532576010268)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(528281042972)
                    this.XsltSettingsEnableScriptDiagId = "SYSLIB0062";
                    //--TRIMMABLE-BOUNDARY-END(528281042972)
                    
                }
            }
            //--TRIMMABLE-BOUNDARY-END(SINIT)
            
            static $h = 65564;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 131073,
  "l": [
//--TRIMMABLE-BOUNDARY-START(382252154908),
    {
      "t": 1310721,
      "n": "SharedUrlFormat",
      "d": 65564,
      "h": 382252154908,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(382252154908),
//--TRIMMABLE-BOUNDARY-START(433791762460),
    {
      "t": 1310721,
      "n": "SystemTextEncodingUTF7Message",
      "d": 65564,
      "h": 433791762460,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(433791762460),
//--TRIMMABLE-BOUNDARY-START(429496795164),
    {
      "t": 1310721,
      "n": "SystemTextEncodingUTF7DiagId",
      "d": 65564,
      "h": 429496795164,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(429496795164),
//--TRIMMABLE-BOUNDARY-START(266288037916),
    {
      "t": 1310721,
      "n": "PrincipalPermissionAttributeMessage",
      "d": 65564,
      "h": 266288037916,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(266288037916),
//--TRIMMABLE-BOUNDARY-START(261993070620),
    {
      "t": 1310721,
      "n": "PrincipalPermissionAttributeDiagId",
      "d": 65564,
      "h": 261993070620,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(261993070620),
//--TRIMMABLE-BOUNDARY-START(77309476892),
    {
      "t": 1310721,
      "n": "CodeAccessSecurityMessage",
      "d": 65564,
      "h": 77309476892,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(77309476892),
//--TRIMMABLE-BOUNDARY-START(73014509596),
    {
      "t": 1310721,
      "n": "CodeAccessSecurityDiagId",
      "d": 65564,
      "h": 73014509596,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(73014509596),
//--TRIMMABLE-BOUNDARY-START(94489346076),
    {
      "t": 1310721,
      "n": "ConstrainedExecutionRegionMessage",
      "d": 65564,
      "h": 94489346076,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(94489346076),
//--TRIMMABLE-BOUNDARY-START(90194378780),
    {
      "t": 1310721,
      "n": "ConstrainedExecutionRegionDiagId",
      "d": 65564,
      "h": 90194378780,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(90194378780),
//--TRIMMABLE-BOUNDARY-START(214748430364),
    {
      "t": 1310721,
      "n": "GlobalAssemblyCacheMessage",
      "d": 65564,
      "h": 214748430364,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(214748430364),
//--TRIMMABLE-BOUNDARY-START(210453463068),
    {
      "t": 1310721,
      "n": "GlobalAssemblyCacheDiagId",
      "d": 65564,
      "h": 210453463068,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(210453463068),
//--TRIMMABLE-BOUNDARY-START(442381697052),
    {
      "t": 1310721,
      "n": "ThreadAbortMessage",
      "d": 65564,
      "h": 442381697052,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(442381697052),
//--TRIMMABLE-BOUNDARY-START(446676664348),
    {
      "t": 1310721,
      "n": "ThreadResetAbortMessage",
      "d": 65564,
      "h": 446676664348,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(446676664348),
//--TRIMMABLE-BOUNDARY-START(438086729756),
    {
      "t": 1310721,
      "n": "ThreadAbortDiagId",
      "d": 65564,
      "h": 438086729756,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(438086729756),
//--TRIMMABLE-BOUNDARY-START(146028953628),
    {
      "t": 1310721,
      "n": "DefaultCryptoAlgorithmsMessage",
      "d": 65564,
      "h": 146028953628,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(146028953628),
//--TRIMMABLE-BOUNDARY-START(141733986332),
    {
      "t": 1310721,
      "n": "DefaultCryptoAlgorithmsDiagId",
      "d": 65564,
      "h": 141733986332,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(141733986332),
//--TRIMMABLE-BOUNDARY-START(120259149852),
    {
      "t": 1310721,
      "n": "CreatePdbGeneratorMessage",
      "d": 65564,
      "h": 120259149852,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(120259149852),
//--TRIMMABLE-BOUNDARY-START(115964182556),
    {
      "t": 1310721,
      "n": "CreatePdbGeneratorDiagId",
      "d": 65564,
      "h": 115964182556,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(115964182556),
//--TRIMMABLE-BOUNDARY-START(51539673116),
    {
      "t": 1310721,
      "n": "AuthenticationManagerMessage",
      "d": 65564,
      "h": 51539673116,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(51539673116),
//--TRIMMABLE-BOUNDARY-START(47244705820),
    {
      "t": 1310721,
      "n": "AuthenticationManagerDiagId",
      "d": 65564,
      "h": 47244705820,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(47244705820),
//--TRIMMABLE-BOUNDARY-START(326417580060),
    {
      "t": 1310721,
      "n": "RemotingApisMessage",
      "d": 65564,
      "h": 326417580060,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(326417580060),
//--TRIMMABLE-BOUNDARY-START(322122612764),
    {
      "t": 1310721,
      "n": "RemotingApisDiagId",
      "d": 65564,
      "h": 322122612764,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(322122612764),
//--TRIMMABLE-BOUNDARY-START(60129607708),
    {
      "t": 1310721,
      "n": "BinaryFormatterMessage",
      "d": 65564,
      "h": 60129607708,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(60129607708),
//--TRIMMABLE-BOUNDARY-START(55834640412),
    {
      "t": 1310721,
      "n": "BinaryFormatterDiagId",
      "d": 65564,
      "h": 55834640412,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(55834640412),
//--TRIMMABLE-BOUNDARY-START(85899411484),
    {
      "t": 1310721,
      "n": "CodeBaseMessage",
      "d": 65564,
      "h": 85899411484,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(85899411484),
//--TRIMMABLE-BOUNDARY-START(81604444188),
    {
      "t": 1310721,
      "n": "CodeBaseDiagId",
      "d": 65564,
      "h": 81604444188,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(81604444188),
//--TRIMMABLE-BOUNDARY-START(197568561180),
    {
      "t": 1310721,
      "n": "EscapeUriStringMessage",
      "d": 65564,
      "h": 197568561180,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(197568561180),
//--TRIMMABLE-BOUNDARY-START(193273593884),
    {
      "t": 1310721,
      "n": "EscapeUriStringDiagId",
      "d": 65564,
      "h": 193273593884,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(193273593884),
//--TRIMMABLE-BOUNDARY-START(489626337308),
    {
      "t": 1310721,
      "n": "WebRequestMessage",
      "d": 65564,
      "h": 489626337308,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(489626337308),
//--TRIMMABLE-BOUNDARY-START(485331370012),
    {
      "t": 1310721,
      "n": "WebRequestDiagId",
      "d": 65564,
      "h": 485331370012,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(485331370012),
//--TRIMMABLE-BOUNDARY-START(163208822812),
    {
      "t": 1310721,
      "n": "DisablePrivateReflectionAttributeMessage",
      "d": 65564,
      "h": 163208822812,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(163208822812),
//--TRIMMABLE-BOUNDARY-START(158913855516),
    {
      "t": 1310721,
      "n": "DisablePrivateReflectionAttributeDiagId",
      "d": 65564,
      "h": 158913855516,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(158913855516),
//--TRIMMABLE-BOUNDARY-START(206158495772),
    {
      "t": 1310721,
      "n": "GetContextInfoMessage",
      "d": 65564,
      "h": 206158495772,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(206158495772),
//--TRIMMABLE-BOUNDARY-START(201863528476),
    {
      "t": 1310721,
      "n": "GetContextInfoDiagId",
      "d": 65564,
      "h": 201863528476,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(201863528476),
//--TRIMMABLE-BOUNDARY-START(399432024092),
    {
      "t": 1310721,
      "n": "StrongNameKeyPairMessage",
      "d": 65564,
      "h": 399432024092,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(399432024092),
//--TRIMMABLE-BOUNDARY-START(395137056796),
    {
      "t": 1310721,
      "n": "StrongNameKeyPairDiagId",
      "d": 65564,
      "h": 395137056796,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(395137056796),
//--TRIMMABLE-BOUNDARY-START(300647776284),
    {
      "t": 1310721,
      "n": "ReflectionOnlyLoadingMessage",
      "d": 65564,
      "h": 300647776284,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(300647776284),
//--TRIMMABLE-BOUNDARY-START(296352808988),
    {
      "t": 1310721,
      "n": "ReflectionOnlyLoadingDiagId",
      "d": 65564,
      "h": 296352808988,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(296352808988),
//--TRIMMABLE-BOUNDARY-START(377957187612),
    {
      "t": 1310721,
      "n": "RuntimeEnvironmentMessage",
      "d": 65564,
      "h": 377957187612,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(377957187612),
//--TRIMMABLE-BOUNDARY-START(373662220316),
    {
      "t": 1310721,
      "n": "RuntimeEnvironmentDiagId",
      "d": 65564,
      "h": 373662220316,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(373662220316),
//--TRIMMABLE-BOUNDARY-START(231928299548),
    {
      "t": 1310721,
      "n": "JsonSerializerOptionsIgnoreNullValuesMessage",
      "d": 65564,
      "h": 231928299548,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(231928299548),
//--TRIMMABLE-BOUNDARY-START(227633332252),
    {
      "t": 1310721,
      "n": "JsonSerializerOptionsIgnoreNullValuesDiagId",
      "d": 65564,
      "h": 227633332252,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(227633332252),
//--TRIMMABLE-BOUNDARY-START(154618888220),
    {
      "t": 1310721,
      "n": "DerivedCryptographicTypesMessage",
      "d": 65564,
      "h": 154618888220,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(154618888220),
//--TRIMMABLE-BOUNDARY-START(150323920924),
    {
      "t": 1310721,
      "n": "DerivedCryptographicTypesDiagId",
      "d": 65564,
      "h": 150323920924,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(150323920924),
//--TRIMMABLE-BOUNDARY-START(352187383836),
    {
      "t": 1310721,
      "n": "RijndaelMessage",
      "d": 65564,
      "h": 352187383836,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(352187383836),
//--TRIMMABLE-BOUNDARY-START(347892416540),
    {
      "t": 1310721,
      "n": "RijndaelDiagId",
      "d": 65564,
      "h": 347892416540,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(347892416540),
//--TRIMMABLE-BOUNDARY-START(360777318428),
    {
      "t": 1310721,
      "n": "RNGCryptoServiceProviderMessage",
      "d": 65564,
      "h": 360777318428,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(360777318428),
//--TRIMMABLE-BOUNDARY-START(356482351132),
    {
      "t": 1310721,
      "n": "RNGCryptoServiceProviderDiagId",
      "d": 65564,
      "h": 356482351132,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(356482351132),
//--TRIMMABLE-BOUNDARY-START(17179934748),
    {
      "t": 1310721,
      "n": "AppDomainCreateUnloadMessage",
      "d": 65564,
      "h": 17179934748,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(17179934748),
//--TRIMMABLE-BOUNDARY-START(12884967452),
    {
      "t": 1310721,
      "n": "AppDomainCreateUnloadDiagId",
      "d": 65564,
      "h": 12884967452,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(12884967452),
//--TRIMMABLE-BOUNDARY-START(408021958684),
    {
      "t": 1310721,
      "n": "SuppressIldasmAttributeMessage",
      "d": 65564,
      "h": 408021958684,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(408021958684),
//--TRIMMABLE-BOUNDARY-START(403726991388),
    {
      "t": 1310721,
      "n": "SuppressIldasmAttributeDiagId",
      "d": 65564,
      "h": 403726991388,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(403726991388),
//--TRIMMABLE-BOUNDARY-START(498216271900),
    {
      "t": 1310721,
      "n": "X509CertificateImmutableMessage",
      "d": 65564,
      "h": 498216271900,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(498216271900),
//--TRIMMABLE-BOUNDARY-START(493921304604),
    {
      "t": 1310721,
      "n": "X509CertificateImmutableDiagId",
      "d": 65564,
      "h": 493921304604,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(493921304604),
//--TRIMMABLE-BOUNDARY-START(283467907100),
    {
      "t": 1310721,
      "n": "PublicKeyPropertyMessage",
      "d": 65564,
      "h": 283467907100,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(283467907100),
//--TRIMMABLE-BOUNDARY-START(279172939804),
    {
      "t": 1310721,
      "n": "PublicKeyPropertyDiagId",
      "d": 65564,
      "h": 279172939804,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(279172939804),
//--TRIMMABLE-BOUNDARY-START(506806206492),
    {
      "t": 1310721,
      "n": "X509CertificatePrivateKeyMessage",
      "d": 65564,
      "h": 506806206492,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(506806206492),
//--TRIMMABLE-BOUNDARY-START(502511239196),
    {
      "t": 1310721,
      "n": "X509CertificatePrivateKeyDiagId",
      "d": 65564,
      "h": 502511239196,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(502511239196),
//--TRIMMABLE-BOUNDARY-START(274877972508),
    {
      "t": 1310721,
      "n": "ProduceLegacyHmacValuesMessage",
      "d": 65564,
      "h": 274877972508,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(274877972508),
//--TRIMMABLE-BOUNDARY-START(270583005212),
    {
      "t": 1310721,
      "n": "ProduceLegacyHmacValuesDiagId",
      "d": 65564,
      "h": 270583005212,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(270583005212),
//--TRIMMABLE-BOUNDARY-START(481036402716),
    {
      "t": 1310721,
      "n": "UseManagedSha1Message",
      "d": 65564,
      "h": 481036402716,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(481036402716),
//--TRIMMABLE-BOUNDARY-START(476741435420),
    {
      "t": 1310721,
      "n": "UseManagedSha1DiagId",
      "d": 65564,
      "h": 476741435420,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(476741435420),
//--TRIMMABLE-BOUNDARY-START(128849084444),
    {
      "t": 1310721,
      "n": "CryptoConfigEncodeOIDMessage",
      "d": 65564,
      "h": 128849084444,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(128849084444),
//--TRIMMABLE-BOUNDARY-START(124554117148),
    {
      "t": 1310721,
      "n": "CryptoConfigEncodeOIDDiagId",
      "d": 65564,
      "h": 124554117148,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(124554117148),
//--TRIMMABLE-BOUNDARY-START(111669215260),
    {
      "t": 1310721,
      "n": "CorruptedStateRecoveryMessage",
      "d": 65564,
      "h": 111669215260,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(111669215260),
//--TRIMMABLE-BOUNDARY-START(107374247964),
    {
      "t": 1310721,
      "n": "CorruptedStateRecoveryDiagId",
      "d": 65564,
      "h": 107374247964,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(107374247964),
//--TRIMMABLE-BOUNDARY-START(335007514652),
    {
      "t": 1310721,
      "n": "Rfc2898CryptDeriveKeyMessage",
      "d": 65564,
      "h": 335007514652,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(335007514652),
//--TRIMMABLE-BOUNDARY-START(330712547356),
    {
      "t": 1310721,
      "n": "Rfc2898CryptDeriveKeyDiagId",
      "d": 65564,
      "h": 330712547356,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(330712547356),
//--TRIMMABLE-BOUNDARY-START(68719542300),
    {
      "t": 1310721,
      "n": "CmsSignerCspParamsCtorMessage",
      "d": 65564,
      "h": 68719542300,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(68719542300),
//--TRIMMABLE-BOUNDARY-START(64424575004),
    {
      "t": 1310721,
      "n": "CmsSignerCspParamsCtorDiagId",
      "d": 65564,
      "h": 64424575004,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(64424575004),
//--TRIMMABLE-BOUNDARY-START(390842089500),
    {
      "t": 1310721,
      "n": "SignerInfoCounterSigMessage",
      "d": 65564,
      "h": 390842089500,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(390842089500),
//--TRIMMABLE-BOUNDARY-START(386547122204),
    {
      "t": 1310721,
      "n": "SignerInfoCounterSigDiagId",
      "d": 65564,
      "h": 386547122204,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(386547122204),
//--TRIMMABLE-BOUNDARY-START(309237710876),
    {
      "t": 1310721,
      "n": "RegexCompileToAssemblyMessage",
      "d": 65564,
      "h": 309237710876,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(309237710876),
//--TRIMMABLE-BOUNDARY-START(304942743580),
    {
      "t": 1310721,
      "n": "RegexCompileToAssemblyDiagId",
      "d": 65564,
      "h": 304942743580,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(304942743580),
//--TRIMMABLE-BOUNDARY-START(42949738524),
    {
      "t": 1310721,
      "n": "AssemblyNameMembersMessage",
      "d": 65564,
      "h": 42949738524,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(42949738524),
//--TRIMMABLE-BOUNDARY-START(38654771228),
    {
      "t": 1310721,
      "n": "AssemblyNameMembersDiagId",
      "d": 65564,
      "h": 38654771228,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(38654771228),
//--TRIMMABLE-BOUNDARY-START(416611893276),
    {
      "t": 1310721,
      "n": "SystemDataSerializationFormatBinaryMessage",
      "d": 65564,
      "h": 416611893276,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(416611893276),
//--TRIMMABLE-BOUNDARY-START(412316925980),
    {
      "t": 1310721,
      "n": "SystemDataSerializationFormatBinaryDiagId",
      "d": 65564,
      "h": 412316925980,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(412316925980),
//--TRIMMABLE-BOUNDARY-START(472446468124),
    {
      "t": 1310721,
      "n": "TlsVersion10and11Message",
      "d": 65564,
      "h": 472446468124,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(472446468124),
//--TRIMMABLE-BOUNDARY-START(468151500828),
    {
      "t": 1310721,
      "n": "TlsVersion10and11DiagId",
      "d": 65564,
      "h": 468151500828,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(468151500828),
//--TRIMMABLE-BOUNDARY-START(188978626588),
    {
      "t": 1310721,
      "n": "EncryptionPolicyMessage",
      "d": 65564,
      "h": 188978626588,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(188978626588),
//--TRIMMABLE-BOUNDARY-START(184683659292),
    {
      "t": 1310721,
      "n": "EncryptionPolicyDiagId",
      "d": 65564,
      "h": 184683659292,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(184683659292),
//--TRIMMABLE-BOUNDARY-START(171798757404),
    {
      "t": 1310721,
      "n": "EccXmlExportImportMessage",
      "d": 65564,
      "h": 171798757404,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(171798757404),
//--TRIMMABLE-BOUNDARY-START(167503790108),
    {
      "t": 1310721,
      "n": "EccXmlExportImportDiagId",
      "d": 65564,
      "h": 167503790108,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(167503790108),
//--TRIMMABLE-BOUNDARY-START(180388691996),
    {
      "t": 1310721,
      "n": "EcDhPublicKeyBlobMessage",
      "d": 65564,
      "h": 180388691996,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(180388691996),
//--TRIMMABLE-BOUNDARY-START(176093724700),
    {
      "t": 1310721,
      "n": "EcDhPublicKeyBlobDiagId",
      "d": 65564,
      "h": 176093724700,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(176093724700),
//--TRIMMABLE-BOUNDARY-START(34359803932),
    {
      "t": 1310721,
      "n": "AssemblyNameCodeBaseMessage",
      "d": 65564,
      "h": 34359803932,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(34359803932),
//--TRIMMABLE-BOUNDARY-START(30064836636),
    {
      "t": 1310721,
      "n": "AssemblyNameCodeBaseDiagId",
      "d": 65564,
      "h": 30064836636,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(30064836636),
//--TRIMMABLE-BOUNDARY-START(137439019036),
    {
      "t": 1310721,
      "n": "CryptoStringFactoryMessage",
      "d": 65564,
      "h": 137439019036,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(137439019036),
//--TRIMMABLE-BOUNDARY-START(133144051740),
    {
      "t": 1310721,
      "n": "CryptoStringFactoryDiagId",
      "d": 65564,
      "h": 133144051740,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(133144051740),
//--TRIMMABLE-BOUNDARY-START(103079280668),
    {
      "t": 1310721,
      "n": "ControlledExecutionRunMessage",
      "d": 65564,
      "h": 103079280668,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(103079280668),
//--TRIMMABLE-BOUNDARY-START(98784313372),
    {
      "t": 1310721,
      "n": "ControlledExecutionRunDiagId",
      "d": 65564,
      "h": 98784313372,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(98784313372),
//--TRIMMABLE-BOUNDARY-START(523986075676),
    {
      "t": 1310721,
      "n": "XmlSecureResolverMessage",
      "d": 65564,
      "h": 523986075676,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(523986075676),
//--TRIMMABLE-BOUNDARY-START(519691108380),
    {
      "t": 1310721,
      "n": "XmlSecureResolverDiagId",
      "d": 65564,
      "h": 519691108380,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(519691108380),
//--TRIMMABLE-BOUNDARY-START(369367253020),
    {
      "t": 1310721,
      "n": "RsaEncryptDecryptValueMessage",
      "d": 65564,
      "h": 369367253020,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(369367253020),
//--TRIMMABLE-BOUNDARY-START(365072285724),
    {
      "t": 1310721,
      "n": "RsaEncryptDecryptDiagId",
      "d": 65564,
      "h": 365072285724,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(365072285724),
//--TRIMMABLE-BOUNDARY-START(223338364956),
    {
      "t": 1310721,
      "n": "JsonSerializerOptionsAddContextMessage",
      "d": 65564,
      "h": 223338364956,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(223338364956),
//--TRIMMABLE-BOUNDARY-START(219043397660),
    {
      "t": 1310721,
      "n": "JsonSerializerOptionsAddContextDiagId",
      "d": 65564,
      "h": 219043397660,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(219043397660),
//--TRIMMABLE-BOUNDARY-START(249108168732),
    {
      "t": 1310721,
      "n": "LegacyFormatterMessage",
      "d": 65564,
      "h": 249108168732,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(249108168732),
//--TRIMMABLE-BOUNDARY-START(236223266844),
    {
      "t": 1310721,
      "n": "LegacyFormatterDiagId",
      "d": 65564,
      "h": 236223266844,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(236223266844),
//--TRIMMABLE-BOUNDARY-START(244813201436),
    {
      "t": 1310721,
      "n": "LegacyFormatterImplMessage",
      "d": 65564,
      "h": 244813201436,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(244813201436),
//--TRIMMABLE-BOUNDARY-START(240518234140),
    {
      "t": 1310721,
      "n": "LegacyFormatterImplDiagId",
      "d": 65564,
      "h": 240518234140,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(240518234140),
//--TRIMMABLE-BOUNDARY-START(317827645468),
    {
      "t": 1310721,
      "n": "RegexExtensibilityImplMessage",
      "d": 65564,
      "h": 317827645468,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(317827645468),
//--TRIMMABLE-BOUNDARY-START(313532678172),
    {
      "t": 1310721,
      "n": "RegexExtensibilityDiagId",
      "d": 65564,
      "h": 313532678172,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(313532678172),
//--TRIMMABLE-BOUNDARY-START(8590000156),
    {
      "t": 1310721,
      "n": "AesGcmTagConstructorMessage",
      "d": 65564,
      "h": 8590000156,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(8590000156),
//--TRIMMABLE-BOUNDARY-START(4295032860),
    {
      "t": 1310721,
      "n": "AesGcmTagConstructorDiagId",
      "d": 65564,
      "h": 4295032860,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(4295032860),
//--TRIMMABLE-BOUNDARY-START(455266598940),
    {
      "t": 1310721,
      "n": "ThreadVolatileReadWriteMessage",
      "d": 65564,
      "h": 455266598940,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(455266598940),
//--TRIMMABLE-BOUNDARY-START(450971631644),
    {
      "t": 1310721,
      "n": "ThreadVolatileReadWriteDiagId",
      "d": 65564,
      "h": 450971631644,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(450971631644),
//--TRIMMABLE-BOUNDARY-START(25769869340),
    {
      "t": 1310721,
      "n": "ArmIntrinsicPerformsUnsignedOperationMessage",
      "d": 65564,
      "h": 25769869340,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(25769869340),
//--TRIMMABLE-BOUNDARY-START(21474902044),
    {
      "t": 1310721,
      "n": "ArmIntrinsicPerformsUnsignedOperationDiagId",
      "d": 65564,
      "h": 21474902044,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(21474902044),
//--TRIMMABLE-BOUNDARY-START(257698103324),
    {
      "t": 1310721,
      "n": "LoadFromHashAlgorithmMessage",
      "d": 65564,
      "h": 257698103324,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(257698103324),
//--TRIMMABLE-BOUNDARY-START(253403136028),
    {
      "t": 1310721,
      "n": "LoadFromHashAlgorithmDiagId",
      "d": 65564,
      "h": 253403136028,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(253403136028),
//--TRIMMABLE-BOUNDARY-START(515396141084),
    {
      "t": 1310721,
      "n": "X509CtorCertDataObsoleteMessage",
      "d": 65564,
      "h": 515396141084,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(515396141084),
//--TRIMMABLE-BOUNDARY-START(511101173788),
    {
      "t": 1310721,
      "n": "X509CtorCertDataObsoleteDiagId",
      "d": 65564,
      "h": 511101173788,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(511101173788),
//--TRIMMABLE-BOUNDARY-START(463856533532),
    {
      "t": 1310721,
      "n": "TlsCipherAlgorithmEnumsMessage",
      "d": 65564,
      "h": 463856533532,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(463856533532),
//--TRIMMABLE-BOUNDARY-START(459561566236),
    {
      "t": 1310721,
      "n": "TlsCipherAlgorithmEnumsDiagId",
      "d": 65564,
      "h": 459561566236,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(459561566236),
//--TRIMMABLE-BOUNDARY-START(425201827868),
    {
      "t": 1310721,
      "n": "SystemEventsEventsThreadShutdownMessage",
      "d": 65564,
      "h": 425201827868,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(425201827868),
//--TRIMMABLE-BOUNDARY-START(420906860572),
    {
      "t": 1310721,
      "n": "SystemEventsEventsThreadShutdownDiagId",
      "d": 65564,
      "h": 420906860572,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(420906860572),
//--TRIMMABLE-BOUNDARY-START(343597449244),
    {
      "t": 1310721,
      "n": "Rfc2898DeriveBytesCtorMessage",
      "d": 65564,
      "h": 343597449244,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(343597449244),
//--TRIMMABLE-BOUNDARY-START(339302481948),
    {
      "t": 1310721,
      "n": "Rfc2898DeriveBytesCtorDiagId",
      "d": 65564,
      "h": 339302481948,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(339302481948),
//--TRIMMABLE-BOUNDARY-START(292057841692),
    {
      "t": 1310721,
      "n": "QueryableMinByMaxByTSourceObsoleteMessage",
      "d": 65564,
      "h": 292057841692,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(292057841692),
//--TRIMMABLE-BOUNDARY-START(287762874396),
    {
      "t": 1310721,
      "n": "QueryableMinByMaxByTSourceObsoleteDiagId",
      "d": 65564,
      "h": 287762874396,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(287762874396),
//--TRIMMABLE-BOUNDARY-START(532576010268),
    {
      "t": 1310721,
      "n": "XsltSettingsEnableScriptMessage",
      "d": 65564,
      "h": 532576010268,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(532576010268),
//--TRIMMABLE-BOUNDARY-START(528281042972),
    {
      "t": 1310721,
      "n": "XsltSettingsEnableScriptDiagId",
      "d": 65564,
      "h": 528281042972,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(528281042972)
  ],
  "h": 65564
}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `System.Obsoletions`; }
        });
        //--TRIMMABLE-BOUNDARY-END(65564)
        
        
        //--TRIMMABLE-BOUNDARY-START(786460)
        $asm.$cls("$srsp.System.SR", ($self) => class SR
        {
            //--TRIMMABLE-BOUNDARY-START(103080001564)
            /*bool*/ static s_usingResourceKeys = false;
            //--TRIMMABLE-BOUNDARY-END(103080001564)
            
            //--TRIMMABLE-BOUNDARY-START(81605165084)
            static /*bool */ GetUsingResourceKeysSwitchValue()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(81605165084);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    /*bool*/ let usingResourceKeys;
                    return $.$$.System.AppContext.TryGetSwitch("System.Resources.UseSystemResourceKeys", $.$ref(() => usingResourceKeys, ($v) => usingResourceKeys = $v, $.$$.System.Boolean)) ? usingResourceKeys : false;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(81605165084)
            
            //--TRIMMABLE-BOUNDARY-START(115964903452)
            static /*bool */ UsingResourceKeys()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(115964903452);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return $.$srsp.System.SR.s_usingResourceKeys;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(115964903452)
            
            //--TRIMMABLE-BOUNDARY-START(77310197788)
            static /*string */ GetResourceString$1(/*string*/ resourceKey)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(77310197788);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$srsp.System.SR.UsingResourceKeys())
                {
                    return resourceKey;
                }
                /*string?*/ let resourceString = null;
                try
                {
                    resourceString = $.$srsp.System.SR.ResourceManager.GetString$1(resourceKey);
                }
                catch($e)
                {
                }
                return resourceString;
            }
            //--TRIMMABLE-BOUNDARY-END(77310197788)
            
            //--TRIMMABLE-BOUNDARY-START(73015230492)
            static /*string */ GetResourceString(/*string*/ resourceKey, /*string*/ defaultString)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(73015230492);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*string*/ let resourceString = $.$srsp.System.SR.GetResourceString$1(resourceKey);
                return $.$$.System.String.op_Equality(resourceKey, resourceString) || $.$$.System.String.op_Equality(resourceString, null) ? defaultString : resourceString;
            }
            //--TRIMMABLE-BOUNDARY-END(73015230492)
            
            //--TRIMMABLE-BOUNDARY-START(38655492124)
            static /*string */ Format$6(/*string*/ resourceFormat, /*object?*/ p1)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(38655492124);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$srsp.System.SR.UsingResourceKeys())
                {
                    return $.$$.System.String.Join$7(", ", $.$$.System.ReadOnlySpan$$($.$$.System.Object).op_Implicit$1([ resourceFormat, p1 ]));
                }
                return $.$$.System.String.Format$9(resourceFormat, p1);
            }
            //--TRIMMABLE-BOUNDARY-END(38655492124)
            
            //--TRIMMABLE-BOUNDARY-START(34360524828)
            static /*string */ Format$5(/*string*/ resourceFormat, /*object?*/ p1, /*object?*/ p2)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(34360524828);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$srsp.System.SR.UsingResourceKeys())
                {
                    return $.$$.System.String.Join$7(", ", $.$$.System.ReadOnlySpan$$($.$$.System.Object).op_Implicit$1([ resourceFormat, p1, p2 ]));
                }
                return $.$$.System.String.Format$8(resourceFormat, p1, p2);
            }
            //--TRIMMABLE-BOUNDARY-END(34360524828)
            
            //--TRIMMABLE-BOUNDARY-START(30065557532)
            static /*string */ Format$4(/*string*/ resourceFormat, /*object?*/ p1, /*object?*/ p2, /*object?*/ p3)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(30065557532);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$srsp.System.SR.UsingResourceKeys())
                {
                    return $.$$.System.String.Join$7(", ", $.$$.System.ReadOnlySpan$$($.$$.System.Object).op_Implicit$1([ resourceFormat, p1, p2, p3 ]));
                }
                return $.$$.System.String.Format$7(resourceFormat, p1, p2, p3);
            }
            //--TRIMMABLE-BOUNDARY-END(30065557532)
            
            //--TRIMMABLE-BOUNDARY-START(42950459420)
            static /*string */ Format$7(/*string*/ resourceFormat, /*params object?[]?*/ args)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(42950459420);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (args !== null)
                {
                    if ($.$srsp.System.SR.UsingResourceKeys())
                    {
                        return resourceFormat + ", " + $.$$.System.String.Join$6(", ", args);
                    }
                    return $.$$.System.String.Format$10(resourceFormat, args);
                }
                return resourceFormat;
            }
            //--TRIMMABLE-BOUNDARY-END(42950459420)
            
            //--TRIMMABLE-BOUNDARY-START(21475622940)
            static /*string */ Format$2(/*IFormatProvider?*/ provider, /*string*/ resourceFormat, /*object?*/ p1)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21475622940);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$srsp.System.SR.UsingResourceKeys())
                {
                    return $.$$.System.String.Join$7(", ", $.$$.System.ReadOnlySpan$$($.$$.System.Object).op_Implicit$1([ resourceFormat, p1 ]));
                }
                return $.$$.System.String.Format$2(provider, resourceFormat, p1);
            }
            //--TRIMMABLE-BOUNDARY-END(21475622940)
            
            //--TRIMMABLE-BOUNDARY-START(17180655644)
            static /*string */ Format$1(/*IFormatProvider?*/ provider, /*string*/ resourceFormat, /*object?*/ p1, /*object?*/ p2)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17180655644);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$srsp.System.SR.UsingResourceKeys())
                {
                    return $.$$.System.String.Join$7(", ", $.$$.System.ReadOnlySpan$$($.$$.System.Object).op_Implicit$1([ resourceFormat, p1, p2 ]));
                }
                return $.$$.System.String.Format$1(provider, resourceFormat, p1, p2);
            }
            //--TRIMMABLE-BOUNDARY-END(17180655644)
            
            //--TRIMMABLE-BOUNDARY-START(12885688348)
            static /*string */ Format(/*IFormatProvider?*/ provider, /*string*/ resourceFormat, /*object?*/ p1, /*object?*/ p2, /*object?*/ p3)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12885688348);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$srsp.System.SR.UsingResourceKeys())
                {
                    return $.$$.System.String.Join$7(", ", $.$$.System.ReadOnlySpan$$($.$$.System.Object).op_Implicit$1([ resourceFormat, p1, p2, p3 ]));
                }
                return $.$$.System.String.Format(provider, resourceFormat, p1, p2, p3);
            }
            //--TRIMMABLE-BOUNDARY-END(12885688348)
            
            //--TRIMMABLE-BOUNDARY-START(25770590236)
            static /*string */ Format$3(/*IFormatProvider?*/ provider, /*string*/ resourceFormat, /*params object?[]?*/ args)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25770590236);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (args !== null)
                {
                    if ($.$srsp.System.SR.UsingResourceKeys())
                    {
                        return resourceFormat + ", " + $.$$.System.String.Join$6(", ", args);
                    }
                    return $.$$.System.String.Format$3(provider, resourceFormat, args);
                }
                return resourceFormat;
            }
            //--TRIMMABLE-BOUNDARY-END(25770590236)
            
            //--TRIMMABLE-BOUNDARY-START(98785034268)
            /*global::System.Resources.ResourceManager*/ static s_resourceManager = null;
            //--TRIMMABLE-BOUNDARY-END(98785034268)
            
            //--TRIMMABLE-BOUNDARY-START(90195099676)
            /*global::System.Globalization.CultureInfo*/ static resourceCulture = null;
            //--TRIMMABLE-BOUNDARY-END(90195099676)
            
            //--TRIMMABLE-BOUNDARY-START(94490066972)
            static /*global::System.Resources.ResourceManager */ get ResourceManager()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(68720263196);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$$.System.Object.ReferenceEquals($.$srsp.System.SR.s_resourceManager, null))
                {
                    /*global::System.Resources.ResourceManager*/ let temp = new $.$$.System.Resources.ResourceManager().$ctor$3("System.Runtime.Serialization.Primitives", $.$srsp.System.SR.$type.Assembly);
                    $.$srsp.System.SR.s_resourceManager = temp;
                }
                return $.$srsp.System.SR.s_resourceManager;
            }
            //--TRIMMABLE-BOUNDARY-END(94490066972)
            
            //--TRIMMABLE-BOUNDARY-START(8590721052)
            static /*global::System.Globalization.CultureInfo */ get Culture()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(51540394012);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$srsp.System.SR.resourceCulture;
            }
            static /*global::System.Globalization.CultureInfo */ set Culture(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(111669936156);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$srsp.System.SR.resourceCulture = value;
            }
            //--TRIMMABLE-BOUNDARY-END(8590721052)
            
            //--TRIMMABLE-BOUNDARY-START(85900132380)
            static /*string */ get OrderCannotBeNegative()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(60130328604);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "Property 'Order' in DataMemberAttribute attribute cannot be a negative number.";
            }
            //--TRIMMABLE-BOUNDARY-END(85900132380)
            
            //--TRIMMABLE-BOUNDARY-START(4295753756)
            //Static Initializer
            static $sinit()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(103080001564)
                    this.s_usingResourceKeys = $.$srsp.System.SR.GetUsingResourceKeysSwitchValue();
                    //--TRIMMABLE-BOUNDARY-END(103080001564)
                    
                }
            }
            //--TRIMMABLE-BOUNDARY-END(4295753756)
            
            static $h = 786460;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 131073,
  "h": 786460
}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `System.SR`; }
        });
        //--TRIMMABLE-BOUNDARY-END(786460)
        
        
        //--TRIMMABLE-BOUNDARY-START(458780)
        $asm.$cls("$srsp.System.Runtime.Serialization.IgnoreDataMemberAttribute", ($self) => class IgnoreDataMemberAttribute extends $.$$.System.Attribute
        {
            //--TRIMMABLE-BOUNDARY-START(4295426076)
            $ctor$2()
            {
                super.$ctor$1();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4295426076);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295426076)
            
            static $h = 458780;
            static $f = 0b10010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 45350913,
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295426076),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 458780,
      "h": 4295426076,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295426076)
  ],
  "h": 458780,
  "a": [
    {
      "t": 45481985,
      "c": 25815285761,
      "a": [
        {
          "v": 384,
          "t": 45416449
        }
      ],
      "n": [
        {
          "n": "Inherited",
          "v": false,
          "t": 262145
        },
        {
          "n": "AllowMultiple",
          "v": false,
          "t": 262145
        }
      ]
    }
  ]
}; }
            static get $b() { return $.$$.System.Attribute; }
            static get $fullName() { return `System.Runtime.Serialization.IgnoreDataMemberAttribute`; }
        });
        //--TRIMMABLE-BOUNDARY-END(458780)
        
        
        //--TRIMMABLE-BOUNDARY-START(720924)
        $asm.$cls("$srsp.System.Runtime.Serialization.KnownTypeAttribute", ($self) => class KnownTypeAttribute extends $.$$.System.Attribute
        {
            //--TRIMMABLE-BOUNDARY-START(17180590108)
            $ctor$3(/*Type*/ type)
            {
                super.$ctor$1();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(17180590108);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this.Type = type;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(17180590108)
            
            //--TRIMMABLE-BOUNDARY-START(12885622812)
            $ctor$2(/*string*/ methodName)
            {
                super.$ctor$1();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(12885622812);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this.MethodName = methodName;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(12885622812)
            
            //--TRIMMABLE-BOUNDARY-START(38655426588)
            /*string?*/ MethodName = null;
            //--TRIMMABLE-BOUNDARY-END(38655426588)
            
            //--TRIMMABLE-BOUNDARY-START(42950393884)
            /*Type?*/ Type = null;
            //--TRIMMABLE-BOUNDARY-END(42950393884)
            
            static $h = 720924;
            static $f = 0b10010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 45350913,
  "p": [
//--TRIMMABLE-BOUNDARY-START(38655426588),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 25770524700,
        "f": 50331649
      },
      "n": "MethodName",
      "d": 720924,
      "h": 38655426588,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(38655426588),
//--TRIMMABLE-BOUNDARY-START(42950393884),
    {
      "p": 187760641,
      "g": {
        "r": 0,
        "d": 0,
        "h": 34360459292,
        "f": 50331649
      },
      "n": "Type",
      "d": 720924,
      "h": 42950393884,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(42950393884)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(17180590108),
    {
      "p": [
        {
          "n": "type",
          "p": 187760641
        }
      ],
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 720924,
      "h": 17180590108,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(17180590108),
//--TRIMMABLE-BOUNDARY-START(12885622812),
    {
      "p": [
        {
          "n": "methodName",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 720924,
      "h": 12885622812,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(12885622812)
  ],
  "h": 720924,
  "a": [
    {
      "t": 45481985,
      "c": 25815285761,
      "a": [
        {
          "v": 12,
          "t": 45416449
        }
      ],
      "n": [
        {
          "n": "Inherited",
          "v": true,
          "t": 262145
        },
        {
          "n": "AllowMultiple",
          "v": true,
          "t": 262145
        }
      ]
    }
  ]
}; }
            static get $b() { return $.$$.System.Attribute; }
            static get $fullName() { return `System.Runtime.Serialization.KnownTypeAttribute`; }
        });
        //--TRIMMABLE-BOUNDARY-END(720924)
        
        
        //--TRIMMABLE-BOUNDARY-START(327708)
        $asm.$cls("$srsp.System.Runtime.Serialization.DataMemberAttribute", ($self) => class DataMemberAttribute extends $.$$.System.Attribute
        {
            //--TRIMMABLE-BOUNDARY-START(8590262300)
            /*string?*/ _name = null;
            //--TRIMMABLE-BOUNDARY-END(8590262300)
            
            //--TRIMMABLE-BOUNDARY-START(4295295004)
            /*bool*/ _isNameSetExplicitly = false;
            //--TRIMMABLE-BOUNDARY-END(4295295004)
            
            //--TRIMMABLE-BOUNDARY-START(12885229596)
            /*int*/ _order = -1;
            //--TRIMMABLE-BOUNDARY-END(12885229596)
            
            //--TRIMMABLE-BOUNDARY-START(25770131484)
            $ctor$2()
            {
                super.$ctor$1();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(25770131484);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(25770131484)
            
            //--TRIMMABLE-BOUNDARY-START(85899673628)
            /*string? */ get Name()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(64424837148);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this._name;
            }
            /*string? */ set Name(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(115964444700);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this._name = value;
                this._isNameSetExplicitly = true;
            }
            //--TRIMMABLE-BOUNDARY-END(85899673628)
            
            //--TRIMMABLE-BOUNDARY-START(77309739036)
            /*bool */ get IsNameSetExplicitly()
            {
                return this._isNameSetExplicitly;
            }
            //--TRIMMABLE-BOUNDARY-END(77309739036)
            
            //--TRIMMABLE-BOUNDARY-START(90194640924)
            /*int */ get Order()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(73014771740);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this._order;
            }
            /*int */ set Order(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(124554379292);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (value < 0)
                {
                    throw new $.$srsp.System.Runtime.Serialization.InvalidDataContractException().$ctor$8($.$srsp.System.SR.OrderCannotBeNegative);
                }
                this._order = value;
            }
            //--TRIMMABLE-BOUNDARY-END(90194640924)
            
            //--TRIMMABLE-BOUNDARY-START(81604706332)
            /*bool*/ IsRequired = false;
            //--TRIMMABLE-BOUNDARY-END(81604706332)
            
            //--TRIMMABLE-BOUNDARY-START(30065098780)
            /*bool*/ EmitDefaultValue = false;
            //--TRIMMABLE-BOUNDARY-END(30065098780)
            
            //default member initializer
            constructor()
            {
                super();
                this.EmitDefaultValue = true;
            }
            static $h = 327708;
            static $f = 0b10010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 45350913,
  "p": [
//--TRIMMABLE-BOUNDARY-START(85899673628),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 64424837148,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 115964444700,
        "f": 83886081
      },
      "n": "Name",
      "d": 327708,
      "h": 85899673628,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(85899673628),
//--TRIMMABLE-BOUNDARY-START(77309739036),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 47244967964,
        "f": 50331649
      },
      "n": "IsNameSetExplicitly",
      "d": 327708,
      "h": 77309739036,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(77309739036),
//--TRIMMABLE-BOUNDARY-START(90194640924),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 73014771740,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 124554379292,
        "f": 83886081
      },
      "n": "Order",
      "d": 327708,
      "h": 90194640924,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(90194640924),
//--TRIMMABLE-BOUNDARY-START(81604706332),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 55834902556,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 107374510108,
        "f": 83886081
      },
      "n": "IsRequired",
      "d": 327708,
      "h": 81604706332,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(81604706332),
//--TRIMMABLE-BOUNDARY-START(30065098780),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 38655033372,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 98784575516,
        "f": 83886081
      },
      "n": "EmitDefaultValue",
      "d": 327708,
      "h": 30065098780,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(30065098780)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(8590262300),
    {
      "t": 1310721,
      "n": "_name",
      "d": 327708,
      "h": 8590262300,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(8590262300),
//--TRIMMABLE-BOUNDARY-START(4295295004),
    {
      "t": 262145,
      "n": "_isNameSetExplicitly",
      "d": 327708,
      "h": 4295295004,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(4295295004),
//--TRIMMABLE-BOUNDARY-START(12885229596),
    {
      "t": 655361,
      "n": "_order",
      "d": 327708,
      "h": 12885229596,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(12885229596)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(25770131484),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 327708,
      "h": 25770131484,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(25770131484)
  ],
  "h": 327708,
  "a": [
    {
      "t": 45481985,
      "c": 25815285761,
      "a": [
        {
          "v": 384,
          "t": 45416449
        }
      ],
      "n": [
        {
          "n": "Inherited",
          "v": false,
          "t": 262145
        },
        {
          "n": "AllowMultiple",
          "v": false,
          "t": 262145
        }
      ]
    }
  ]
}; }
            static get $b() { return $.$$.System.Attribute; }
            static get $fullName() { return `System.Runtime.Serialization.DataMemberAttribute`; }
        });
        //--TRIMMABLE-BOUNDARY-END(327708)
        
        
        //--TRIMMABLE-BOUNDARY-START(393244)
        $asm.$cls("$srsp.System.Runtime.Serialization.EnumMemberAttribute", ($self) => class EnumMemberAttribute extends $.$$.System.Attribute
        {
            //--TRIMMABLE-BOUNDARY-START(8590327836)
            /*string?*/ _value = null;
            //--TRIMMABLE-BOUNDARY-END(8590327836)
            
            //--TRIMMABLE-BOUNDARY-START(4295360540)
            /*bool*/ _isValueSetExplicitly = false;
            //--TRIMMABLE-BOUNDARY-END(4295360540)
            
            //--TRIMMABLE-BOUNDARY-START(12885295132)
            $ctor$2()
            {
                super.$ctor$1();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(12885295132);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(12885295132)
            
            //--TRIMMABLE-BOUNDARY-START(47245033500)
            /*string? */ get Value()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(30065164316);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this._value;
            }
            /*string? */ set Value(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(42950066204);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this._value = value;
                this._isValueSetExplicitly = true;
            }
            //--TRIMMABLE-BOUNDARY-END(47245033500)
            
            //--TRIMMABLE-BOUNDARY-START(34360131612)
            /*bool */ get IsValueSetExplicitly()
            {
                return this._isValueSetExplicitly;
            }
            //--TRIMMABLE-BOUNDARY-END(34360131612)
            
            static $h = 393244;
            static $f = 0b10010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 45350913,
  "p": [
//--TRIMMABLE-BOUNDARY-START(47245033500),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 30065164316,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 42950066204,
        "f": 83886081
      },
      "n": "Value",
      "d": 393244,
      "h": 47245033500,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(47245033500),
//--TRIMMABLE-BOUNDARY-START(34360131612),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 21475229724,
        "f": 50331649
      },
      "n": "IsValueSetExplicitly",
      "d": 393244,
      "h": 34360131612,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(34360131612)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(8590327836),
    {
      "t": 1310721,
      "n": "_value",
      "d": 393244,
      "h": 8590327836,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(8590327836),
//--TRIMMABLE-BOUNDARY-START(4295360540),
    {
      "t": 262145,
      "n": "_isValueSetExplicitly",
      "d": 393244,
      "h": 4295360540,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(4295360540)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(12885295132),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 393244,
      "h": 12885295132,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(12885295132)
  ],
  "h": 393244,
  "a": [
    {
      "t": 45481985,
      "c": 25815285761,
      "a": [
        {
          "v": 256,
          "t": 45416449
        }
      ],
      "n": [
        {
          "n": "Inherited",
          "v": false,
          "t": 262145
        },
        {
          "n": "AllowMultiple",
          "v": false,
          "t": 262145
        }
      ]
    }
  ]
}; }
            static get $b() { return $.$$.System.Attribute; }
            static get $fullName() { return `System.Runtime.Serialization.EnumMemberAttribute`; }
        });
        //--TRIMMABLE-BOUNDARY-END(393244)
        
        
        //--TRIMMABLE-BOUNDARY-START(131100)
        $asm.$cls("$srsp.System.Runtime.Serialization.CollectionDataContractAttribute", ($self) => class CollectionDataContractAttribute extends $.$$.System.Attribute
        {
            //--TRIMMABLE-BOUNDARY-START(42949804060)
            /*string?*/ _name = null;
            //--TRIMMABLE-BOUNDARY-END(42949804060)
            
            //--TRIMMABLE-BOUNDARY-START(47244771356)
            /*string?*/ _ns = null;
            //--TRIMMABLE-BOUNDARY-END(47244771356)
            
            //--TRIMMABLE-BOUNDARY-START(34359869468)
            /*string?*/ _itemName = null;
            //--TRIMMABLE-BOUNDARY-END(34359869468)
            
            //--TRIMMABLE-BOUNDARY-START(38654836764)
            /*string?*/ _keyName = null;
            //--TRIMMABLE-BOUNDARY-END(38654836764)
            
            //--TRIMMABLE-BOUNDARY-START(51539738652)
            /*string?*/ _valueName = null;
            //--TRIMMABLE-BOUNDARY-END(51539738652)
            
            //--TRIMMABLE-BOUNDARY-START(21474967580)
            /*bool*/ _isReference = false;
            //--TRIMMABLE-BOUNDARY-END(21474967580)
            
            //--TRIMMABLE-BOUNDARY-START(12885032988)
            /*bool*/ _isNameSetExplicitly = false;
            //--TRIMMABLE-BOUNDARY-END(12885032988)
            
            //--TRIMMABLE-BOUNDARY-START(17180000284)
            /*bool*/ _isNamespaceSetExplicitly = false;
            //--TRIMMABLE-BOUNDARY-END(17180000284)
            
            //--TRIMMABLE-BOUNDARY-START(25769934876)
            /*bool*/ _isReferenceSetExplicitly = false;
            //--TRIMMABLE-BOUNDARY-END(25769934876)
            
            //--TRIMMABLE-BOUNDARY-START(4295098396)
            /*bool*/ _isItemNameSetExplicitly = false;
            //--TRIMMABLE-BOUNDARY-END(4295098396)
            
            //--TRIMMABLE-BOUNDARY-START(8590065692)
            /*bool*/ _isKeyNameSetExplicitly = false;
            //--TRIMMABLE-BOUNDARY-END(8590065692)
            
            //--TRIMMABLE-BOUNDARY-START(30064902172)
            /*bool*/ _isValueNameSetExplicitly = false;
            //--TRIMMABLE-BOUNDARY-END(30064902172)
            
            //--TRIMMABLE-BOUNDARY-START(55834705948)
            $ctor$2()
            {
                super.$ctor$1();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(55834705948);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(55834705948)
            
            //--TRIMMABLE-BOUNDARY-START(206158561308)
            /*string? */ get Namespace()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(150323986460);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this._ns;
            }
            /*string? */ set Namespace(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(249108234268);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this._ns = value;
                this._isNamespaceSetExplicitly = true;
            }
            //--TRIMMABLE-BOUNDARY-END(206158561308)
            
            //--TRIMMABLE-BOUNDARY-START(176093790236)
            /*bool */ get IsNamespaceSetExplicitly()
            {
                return this._isNamespaceSetExplicitly;
            }
            //--TRIMMABLE-BOUNDARY-END(176093790236)
            
            //--TRIMMABLE-BOUNDARY-START(201863594012)
            /*string? */ get Name()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(141734051868);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this._name;
            }
            /*string? */ set Name(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(240518299676);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this._name = value;
                this._isNameSetExplicitly = true;
            }
            //--TRIMMABLE-BOUNDARY-END(201863594012)
            
            //--TRIMMABLE-BOUNDARY-START(171798822940)
            /*bool */ get IsNameSetExplicitly()
            {
                return this._isNameSetExplicitly;
            }
            //--TRIMMABLE-BOUNDARY-END(171798822940)
            
            //--TRIMMABLE-BOUNDARY-START(193273659420)
            /*string? */ get ItemName()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(124554182684);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this._itemName;
            }
            /*string? */ set ItemName(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(223338430492);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this._itemName = value;
                this._isItemNameSetExplicitly = true;
            }
            //--TRIMMABLE-BOUNDARY-END(193273659420)
            
            //--TRIMMABLE-BOUNDARY-START(163208888348)
            /*bool */ get IsItemNameSetExplicitly()
            {
                return this._isItemNameSetExplicitly;
            }
            //--TRIMMABLE-BOUNDARY-END(163208888348)
            
            //--TRIMMABLE-BOUNDARY-START(197568626716)
            /*string? */ get KeyName()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(133144117276);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this._keyName;
            }
            /*string? */ set KeyName(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(231928365084);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this._keyName = value;
                this._isKeyNameSetExplicitly = true;
            }
            //--TRIMMABLE-BOUNDARY-END(197568626716)
            
            //--TRIMMABLE-BOUNDARY-START(167503855644)
            /*bool */ get IsKeyNameSetExplicitly()
            {
                return this._isKeyNameSetExplicitly;
            }
            //--TRIMMABLE-BOUNDARY-END(167503855644)
            
            //--TRIMMABLE-BOUNDARY-START(180388757532)
            /*bool */ get IsReference()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(98784378908);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this._isReference;
            }
            /*bool */ set IsReference(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(214748495900);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this._isReference = value;
                this._isReferenceSetExplicitly = true;
            }
            //--TRIMMABLE-BOUNDARY-END(180388757532)
            
            //--TRIMMABLE-BOUNDARY-START(184683724828)
            /*bool */ get IsReferenceSetExplicitly()
            {
                return this._isReferenceSetExplicitly;
            }
            //--TRIMMABLE-BOUNDARY-END(184683724828)
            
            //--TRIMMABLE-BOUNDARY-START(261993136156)
            /*string? */ get ValueName()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(158913921052);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this._valueName;
            }
            /*string? */ set ValueName(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(257698168860);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this._valueName = value;
                this._isValueNameSetExplicitly = true;
            }
            //--TRIMMABLE-BOUNDARY-END(261993136156)
            
            //--TRIMMABLE-BOUNDARY-START(188978692124)
            /*bool */ get IsValueNameSetExplicitly()
            {
                return this._isValueNameSetExplicitly;
            }
            //--TRIMMABLE-BOUNDARY-END(188978692124)
            
            static $h = 131100;
            static $f = 0b10010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 45350913,
  "p": [
//--TRIMMABLE-BOUNDARY-START(206158561308),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 150323986460,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 249108234268,
        "f": 83886081
      },
      "n": "Namespace",
      "d": 131100,
      "h": 206158561308,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(206158561308),
//--TRIMMABLE-BOUNDARY-START(176093790236),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 90194444316,
        "f": 50331649
      },
      "n": "IsNamespaceSetExplicitly",
      "d": 131100,
      "h": 176093790236,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(176093790236),
//--TRIMMABLE-BOUNDARY-START(201863594012),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 141734051868,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 240518299676,
        "f": 83886081
      },
      "n": "Name",
      "d": 131100,
      "h": 201863594012,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(201863594012),
//--TRIMMABLE-BOUNDARY-START(171798822940),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 81604509724,
        "f": 50331649
      },
      "n": "IsNameSetExplicitly",
      "d": 131100,
      "h": 171798822940,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(171798822940),
//--TRIMMABLE-BOUNDARY-START(193273659420),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 124554182684,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 223338430492,
        "f": 83886081
      },
      "n": "ItemName",
      "d": 131100,
      "h": 193273659420,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(193273659420),
//--TRIMMABLE-BOUNDARY-START(163208888348),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 64424640540,
        "f": 50331649
      },
      "n": "IsItemNameSetExplicitly",
      "d": 131100,
      "h": 163208888348,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(163208888348),
//--TRIMMABLE-BOUNDARY-START(197568626716),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 133144117276,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 231928365084,
        "f": 83886081
      },
      "n": "KeyName",
      "d": 131100,
      "h": 197568626716,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(197568626716),
//--TRIMMABLE-BOUNDARY-START(167503855644),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 73014575132,
        "f": 50331649
      },
      "n": "IsKeyNameSetExplicitly",
      "d": 131100,
      "h": 167503855644,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(167503855644),
//--TRIMMABLE-BOUNDARY-START(180388757532),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 98784378908,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 214748495900,
        "f": 83886081
      },
      "n": "IsReference",
      "d": 131100,
      "h": 180388757532,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(180388757532),
//--TRIMMABLE-BOUNDARY-START(184683724828),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 107374313500,
        "f": 50331649
      },
      "n": "IsReferenceSetExplicitly",
      "d": 131100,
      "h": 184683724828,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(184683724828),
//--TRIMMABLE-BOUNDARY-START(261993136156),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 158913921052,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 257698168860,
        "f": 83886081
      },
      "n": "ValueName",
      "d": 131100,
      "h": 261993136156,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(261993136156),
//--TRIMMABLE-BOUNDARY-START(188978692124),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 115964248092,
        "f": 50331649
      },
      "n": "IsValueNameSetExplicitly",
      "d": 131100,
      "h": 188978692124,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(188978692124)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(42949804060),
    {
      "t": 1310721,
      "n": "_name",
      "d": 131100,
      "h": 42949804060,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(42949804060),
//--TRIMMABLE-BOUNDARY-START(47244771356),
    {
      "t": 1310721,
      "n": "_ns",
      "d": 131100,
      "h": 47244771356,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(47244771356),
//--TRIMMABLE-BOUNDARY-START(34359869468),
    {
      "t": 1310721,
      "n": "_itemName",
      "d": 131100,
      "h": 34359869468,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(34359869468),
//--TRIMMABLE-BOUNDARY-START(38654836764),
    {
      "t": 1310721,
      "n": "_keyName",
      "d": 131100,
      "h": 38654836764,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(38654836764),
//--TRIMMABLE-BOUNDARY-START(51539738652),
    {
      "t": 1310721,
      "n": "_valueName",
      "d": 131100,
      "h": 51539738652,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(51539738652),
//--TRIMMABLE-BOUNDARY-START(21474967580),
    {
      "t": 262145,
      "n": "_isReference",
      "d": 131100,
      "h": 21474967580,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(21474967580),
//--TRIMMABLE-BOUNDARY-START(12885032988),
    {
      "t": 262145,
      "n": "_isNameSetExplicitly",
      "d": 131100,
      "h": 12885032988,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(12885032988),
//--TRIMMABLE-BOUNDARY-START(17180000284),
    {
      "t": 262145,
      "n": "_isNamespaceSetExplicitly",
      "d": 131100,
      "h": 17180000284,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(17180000284),
//--TRIMMABLE-BOUNDARY-START(25769934876),
    {
      "t": 262145,
      "n": "_isReferenceSetExplicitly",
      "d": 131100,
      "h": 25769934876,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(25769934876),
//--TRIMMABLE-BOUNDARY-START(4295098396),
    {
      "t": 262145,
      "n": "_isItemNameSetExplicitly",
      "d": 131100,
      "h": 4295098396,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(4295098396),
//--TRIMMABLE-BOUNDARY-START(8590065692),
    {
      "t": 262145,
      "n": "_isKeyNameSetExplicitly",
      "d": 131100,
      "h": 8590065692,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(8590065692),
//--TRIMMABLE-BOUNDARY-START(30064902172),
    {
      "t": 262145,
      "n": "_isValueNameSetExplicitly",
      "d": 131100,
      "h": 30064902172,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(30064902172)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(55834705948),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 131100,
      "h": 55834705948,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(55834705948)
  ],
  "h": 131100,
  "a": [
    {
      "t": 45481985,
      "c": 25815285761,
      "a": [
        {
          "v": 12,
          "t": 45416449
        }
      ],
      "n": [
        {
          "n": "Inherited",
          "v": false,
          "t": 262145
        },
        {
          "n": "AllowMultiple",
          "v": false,
          "t": 262145
        }
      ]
    }
  ]
}; }
            static get $b() { return $.$$.System.Attribute; }
            static get $fullName() { return `System.Runtime.Serialization.CollectionDataContractAttribute`; }
        });
        //--TRIMMABLE-BOUNDARY-END(131100)
        
        
        //--TRIMMABLE-BOUNDARY-START(262172)
        $asm.$cls("$srsp.System.Runtime.Serialization.DataContractAttribute", ($self) => class DataContractAttribute extends $.$$.System.Attribute
        {
            //--TRIMMABLE-BOUNDARY-START(21475098652)
            /*string?*/ _name = null;
            //--TRIMMABLE-BOUNDARY-END(21475098652)
            
            //--TRIMMABLE-BOUNDARY-START(25770065948)
            /*string?*/ _ns = null;
            //--TRIMMABLE-BOUNDARY-END(25770065948)
            
            //--TRIMMABLE-BOUNDARY-START(4295229468)
            /*bool*/ _isNameSetExplicitly = false;
            //--TRIMMABLE-BOUNDARY-END(4295229468)
            
            //--TRIMMABLE-BOUNDARY-START(8590196764)
            /*bool*/ _isNamespaceSetExplicitly = false;
            //--TRIMMABLE-BOUNDARY-END(8590196764)
            
            //--TRIMMABLE-BOUNDARY-START(12885164060)
            /*bool*/ _isReference = false;
            //--TRIMMABLE-BOUNDARY-END(12885164060)
            
            //--TRIMMABLE-BOUNDARY-START(17180131356)
            /*bool*/ _isReferenceSetExplicitly = false;
            //--TRIMMABLE-BOUNDARY-END(17180131356)
            
            //--TRIMMABLE-BOUNDARY-START(30065033244)
            $ctor$2()
            {
                super.$ctor$1();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(30065033244);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(30065033244)
            
            //--TRIMMABLE-BOUNDARY-START(94489542684)
            /*bool */ get IsReference()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(55834837020);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this._isReference;
            }
            /*bool */ set IsReference(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(115964379164);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this._isReference = value;
                this._isReferenceSetExplicitly = true;
            }
            //--TRIMMABLE-BOUNDARY-END(94489542684)
            
            //--TRIMMABLE-BOUNDARY-START(98784509980)
            /*bool */ get IsReferenceSetExplicitly()
            {
                return this._isReferenceSetExplicitly;
            }
            //--TRIMMABLE-BOUNDARY-END(98784509980)
            
            //--TRIMMABLE-BOUNDARY-START(107374444572)
            /*string? */ get Namespace()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(81604640796);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this._ns;
            }
            /*string? */ set Namespace(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(133144248348);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this._ns = value;
                this._isNamespaceSetExplicitly = true;
            }
            //--TRIMMABLE-BOUNDARY-END(107374444572)
            
            //--TRIMMABLE-BOUNDARY-START(90194575388)
            /*bool */ get IsNamespaceSetExplicitly()
            {
                return this._isNamespaceSetExplicitly;
            }
            //--TRIMMABLE-BOUNDARY-END(90194575388)
            
            //--TRIMMABLE-BOUNDARY-START(103079477276)
            /*string? */ get Name()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(73014706204);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this._name;
            }
            /*string? */ set Name(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(124554313756);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this._name = value;
                this._isNameSetExplicitly = true;
            }
            //--TRIMMABLE-BOUNDARY-END(103079477276)
            
            //--TRIMMABLE-BOUNDARY-START(85899608092)
            /*bool */ get IsNameSetExplicitly()
            {
                return this._isNameSetExplicitly;
            }
            //--TRIMMABLE-BOUNDARY-END(85899608092)
            
            static $h = 262172;
            static $f = 0b10010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 45350913,
  "p": [
//--TRIMMABLE-BOUNDARY-START(94489542684),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 55834837020,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 115964379164,
        "f": 83886081
      },
      "n": "IsReference",
      "d": 262172,
      "h": 94489542684,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(94489542684),
//--TRIMMABLE-BOUNDARY-START(98784509980),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 64424771612,
        "f": 50331649
      },
      "n": "IsReferenceSetExplicitly",
      "d": 262172,
      "h": 98784509980,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(98784509980),
//--TRIMMABLE-BOUNDARY-START(107374444572),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 81604640796,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 133144248348,
        "f": 83886081
      },
      "n": "Namespace",
      "d": 262172,
      "h": 107374444572,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(107374444572),
//--TRIMMABLE-BOUNDARY-START(90194575388),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 47244902428,
        "f": 50331649
      },
      "n": "IsNamespaceSetExplicitly",
      "d": 262172,
      "h": 90194575388,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(90194575388),
//--TRIMMABLE-BOUNDARY-START(103079477276),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 73014706204,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 124554313756,
        "f": 83886081
      },
      "n": "Name",
      "d": 262172,
      "h": 103079477276,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(103079477276),
//--TRIMMABLE-BOUNDARY-START(85899608092),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 38654967836,
        "f": 50331649
      },
      "n": "IsNameSetExplicitly",
      "d": 262172,
      "h": 85899608092,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(85899608092)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(21475098652),
    {
      "t": 1310721,
      "n": "_name",
      "d": 262172,
      "h": 21475098652,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(21475098652),
//--TRIMMABLE-BOUNDARY-START(25770065948),
    {
      "t": 1310721,
      "n": "_ns",
      "d": 262172,
      "h": 25770065948,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(25770065948),
//--TRIMMABLE-BOUNDARY-START(4295229468),
    {
      "t": 262145,
      "n": "_isNameSetExplicitly",
      "d": 262172,
      "h": 4295229468,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(4295229468),
//--TRIMMABLE-BOUNDARY-START(8590196764),
    {
      "t": 262145,
      "n": "_isNamespaceSetExplicitly",
      "d": 262172,
      "h": 8590196764,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(8590196764),
//--TRIMMABLE-BOUNDARY-START(12885164060),
    {
      "t": 262145,
      "n": "_isReference",
      "d": 262172,
      "h": 12885164060,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(12885164060),
//--TRIMMABLE-BOUNDARY-START(17180131356),
    {
      "t": 262145,
      "n": "_isReferenceSetExplicitly",
      "d": 262172,
      "h": 17180131356,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(17180131356)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(30065033244),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 262172,
      "h": 30065033244,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(30065033244)
  ],
  "h": 262172,
  "a": [
    {
      "t": 45481985,
      "c": 25815285761,
      "a": [
        {
          "v": 28,
          "t": 45416449
        }
      ],
      "n": [
        {
          "n": "Inherited",
          "v": false,
          "t": 262145
        },
        {
          "n": "AllowMultiple",
          "v": false,
          "t": 262145
        }
      ]
    }
  ]
}; }
            static get $b() { return $.$$.System.Attribute; }
            static get $fullName() { return `System.Runtime.Serialization.DataContractAttribute`; }
        });
        //--TRIMMABLE-BOUNDARY-END(262172)
        
        
        //--TRIMMABLE-BOUNDARY-START(196636)
        $asm.$cls("$srsp.System.Runtime.Serialization.ContractNamespaceAttribute", ($self) => class ContractNamespaceAttribute extends $.$$.System.Attribute
        {
            //--TRIMMABLE-BOUNDARY-START(12885098524)
            $ctor$2(/*string*/ contractNamespace)
            {
                super.$ctor$1();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(12885098524);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this.ContractNamespace = contractNamespace;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(12885098524)
            
            //--TRIMMABLE-BOUNDARY-START(17180065820)
            /*string?*/ ClrNamespace = null;
            //--TRIMMABLE-BOUNDARY-END(17180065820)
            
            //--TRIMMABLE-BOUNDARY-START(21475033116)
            /*string*/ ContractNamespace = null;
            //--TRIMMABLE-BOUNDARY-END(21475033116)
            
            static $h = 196636;
            static $f = 0b10010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 45350913,
  "p": [
//--TRIMMABLE-BOUNDARY-START(17180065820),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 30064967708,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 47244836892,
        "f": 83886081
      },
      "n": "ClrNamespace",
      "d": 196636,
      "h": 17180065820,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(17180065820),
//--TRIMMABLE-BOUNDARY-START(21475033116),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 38654902300,
        "f": 50331649
      },
      "n": "ContractNamespace",
      "d": 196636,
      "h": 21475033116,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(21475033116)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(12885098524),
    {
      "p": [
        {
          "n": "contractNamespace",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 196636,
      "h": 12885098524,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(12885098524)
  ],
  "h": 196636,
  "a": [
    {
      "t": 45481985,
      "c": 25815285761,
      "a": [
        {
          "v": 3,
          "t": 45416449
        }
      ],
      "n": [
        {
          "n": "Inherited",
          "v": false,
          "t": 262145
        },
        {
          "n": "AllowMultiple",
          "v": true,
          "t": 262145
        }
      ]
    }
  ]
}; }
            static get $b() { return $.$$.System.Attribute; }
            static get $fullName() { return `System.Runtime.Serialization.ContractNamespaceAttribute`; }
        });
        //--TRIMMABLE-BOUNDARY-END(196636)
        
        
        //--TRIMMABLE-BOUNDARY-START(524316)
        $asm.$cls("$srsp.System.Runtime.Serialization.InvalidDataContractException", ($self) => class InvalidDataContractException extends $.$$.System.Exception
        {
            //--TRIMMABLE-BOUNDARY-START(4295491612)
            $ctor$5()
            {
                super.$ctor$1();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4295491612);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295491612)
            
            //--TRIMMABLE-BOUNDARY-START(17180393500)
            $ctor$8(/*string?*/ message)
            {
                super.$ctor$4(message);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(17180393500);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(17180393500)
            
            //--TRIMMABLE-BOUNDARY-START(12885426204)
            $ctor$7(/*string?*/ message, /*Exception?*/ innerException)
            {
                super.$ctor$3(message, innerException);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(12885426204);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(12885426204)
            
            //--TRIMMABLE-BOUNDARY-START(8590458908)
            $ctor$6(/*SerializationInfo*/ info, /*StreamingContext*/ context)
            {
                super.$ctor$2(info, context);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(8590458908);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(8590458908)
            
            static $h = 524316;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 80019457,
  "h": 524316
}; }
            static get $b() { return $.$$.System.Exception; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.System.Runtime.Serialization.ISerializable ]; }
            static get $fullName() { return `System.Runtime.Serialization.InvalidDataContractException`; }
        });
        //--TRIMMABLE-BOUNDARY-END(524316)
	});
})(window, window.NetJs.$boot(), ...window.NetJs.$require("NetJs.System.Private.CoreLib", "NetJs.System.Memory", "NetJs.System.Private.Uri", "NetJs.System.Runtime"))
//--TRIMMABLE-BOUNDARY-END(28)
