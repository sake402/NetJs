
(function ($global, $, $spc, $sm, $spu, $sr) {
    "use strict";
    let _;
    
    
    
	$.$asm(
    "NetJs.System.Runtime.Serialization.Primitives", 
    {"h":36711,"f":"System.Runtime.Serialization.Primitives","v":"1.0.35.0","a":[{"t":115146753,"c":13000048641,"a":[{"v":".NETCoreApp,Version=v10.0","t":1310721}],"n":[{"n":"FrameworkDisplayName","v":".NET 10.0","t":1310721}]},{"t":73596929,"c":4368564225,"a":[{"v":"SIT","t":1310721}]},{"t":73662465,"c":4368629761,"a":[{"v":"Debug","t":1310721}]},{"t":74121217,"c":4369088513,"a":[{"v":"1.0.35.0","t":1310721}]},{"t":74252289,"c":4369219585,"a":[{"v":"1.0.35\u002B99807a3edea449997cda60d38046fed69821a2f6","t":1310721}]},{"t":75104257,"c":4370071553,"a":[{"v":"NetJs.System.Runtime.Serialization.Primitives","t":1310721}]},{"t":75235329,"c":4370202625,"a":[{"v":"NetJs.System.Runtime.Serialization.Primitives","t":1310721}]},{"t":75366401,"c":4370333697,"a":[{"v":"1.0.35.0","t":1310721}]},{"t":115212289,"c":4410179585,"a":[{"v":"browser1.0","t":1310721}]},{"t":114950145,"c":4409917441,"a":[{"v":"browser1.0","t":1310721}]},{"t":96337921,"c":4391305217,"a":[{"v":113442817,"t":142606337}]},{"t":96337921,"c":4391305217,"a":[{"v":113508353,"t":142606337}]},{"t":96337921,"c":4391305217,"a":[{"v":113573889,"t":142606337}]},{"t":96337921,"c":4391305217,"a":[{"v":113639425,"t":142606337}]},{"t":96337921,"c":4391305217,"a":[{"v":113901569,"t":142606337}]},{"t":96337921,"c":4391305217,"a":[{"v":114098177,"t":142606337}]},{"t":96337921,"c":4391305217,"a":[{"v":114163713,"t":142606337}]}],"m":[]},
    function($asm)
	{
        
        
        $asm.$cls("$srsp.System.Runtime.Serialization.ISerializationSurrogateProvider", ($self) => class ISerializationSurrogateProvider
        {
            static $h = 626535;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {"m":[{"r":142606337,"p":[{"n":"type","p":142606337}],"n":"GetSurrogateType","o":"System$Runtime$Serialization$ISerializationSurrogateProvider$GetSurrogateType","d":626535,"h":4295593831,"f":257},{"r":131073,"p":[{"n":"obj","p":131073},{"n":"targetType","p":142606337}],"n":"GetObjectToSerialize","o":"System$Runtime$Serialization$ISerializationSurrogateProvider$GetObjectToSerialize","d":626535,"h":8590561127,"f":257},{"r":131073,"p":[{"n":"obj","p":131073},{"n":"targetType","p":142606337}],"n":"GetDeserializedObject","o":"System$Runtime$Serialization$ISerializationSurrogateProvider$GetDeserializedObject","d":626535,"h":12885528423,"f":257}],"h":626535}; }
            static get $fullName() { return `System.Runtime.Serialization.ISerializationSurrogateProvider`; }
        });
        
        $asm.$cls("$srsp.System.Runtime.Serialization.ISerializationSurrogateProvider2", ($self) => class ISerializationSurrogateProvider2
        {
            static $h = 692071;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {"m":[{"r":131073,"p":[{"n":"memberInfo","p":78249985},{"n":"dataContractType","p":142606337}],"n":"GetCustomDataToExport","o":"System$Runtime$Serialization$ISerializationSurrogateProvider2$GetCustomDataToExport","d":692071,"h":4295659367,"f":257},{"r":131073,"p":[{"n":"runtimeType","p":142606337},{"n":"dataContractType","p":142606337}],"n":"GetCustomDataToExport","o":"System$Runtime$Serialization$ISerializationSurrogateProvider2$GetCustomDataToExport$1","d":692071,"h":8590626663,"f":257},{"r":65537,"p":[{"n":"customDataTypes","p":$.$spc.System.Collections.ObjectModel.Collection$$($.$spc.System.Type).$h}],"n":"GetKnownCustomDataTypes","o":"System$Runtime$Serialization$ISerializationSurrogateProvider2$GetKnownCustomDataTypes","d":692071,"h":12885593959,"f":257},{"r":142606337,"p":[{"n":"typeName","p":1310721},{"n":"typeNamespace","p":1310721},{"n":"customData","p":131073}],"n":"GetReferencedTypeOnImport","o":"System$Runtime$Serialization$ISerializationSurrogateProvider2$GetReferencedTypeOnImport","d":692071,"h":17180561255,"f":257}],"i":[626535],"h":692071}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$srsp.System.Runtime.Serialization.ISerializationSurrogateProvider ]; }
            static get $fullName() { return `System.Runtime.Serialization.ISerializationSurrogateProvider2`; }
        });
        
        $asm.$cls("$srsp.System.Obsoletions", ($self) => class Obsoletions
        {
            /*string*/ static SharedUrlFormat = null;
            /*string*/ static SystemTextEncodingUTF7Message = null;
            /*string*/ static SystemTextEncodingUTF7DiagId = null;
            /*string*/ static PrincipalPermissionAttributeMessage = null;
            /*string*/ static PrincipalPermissionAttributeDiagId = null;
            /*string*/ static CodeAccessSecurityMessage = null;
            /*string*/ static CodeAccessSecurityDiagId = null;
            /*string*/ static ConstrainedExecutionRegionMessage = null;
            /*string*/ static ConstrainedExecutionRegionDiagId = null;
            /*string*/ static GlobalAssemblyCacheMessage = null;
            /*string*/ static GlobalAssemblyCacheDiagId = null;
            /*string*/ static ThreadAbortMessage = null;
            /*string*/ static ThreadResetAbortMessage = null;
            /*string*/ static ThreadAbortDiagId = null;
            /*string*/ static DefaultCryptoAlgorithmsMessage = null;
            /*string*/ static DefaultCryptoAlgorithmsDiagId = null;
            /*string*/ static CreatePdbGeneratorMessage = null;
            /*string*/ static CreatePdbGeneratorDiagId = null;
            /*string*/ static AuthenticationManagerMessage = null;
            /*string*/ static AuthenticationManagerDiagId = null;
            /*string*/ static RemotingApisMessage = null;
            /*string*/ static RemotingApisDiagId = null;
            /*string*/ static BinaryFormatterMessage = null;
            /*string*/ static BinaryFormatterDiagId = null;
            /*string*/ static CodeBaseMessage = null;
            /*string*/ static CodeBaseDiagId = null;
            /*string*/ static EscapeUriStringMessage = null;
            /*string*/ static EscapeUriStringDiagId = null;
            /*string*/ static WebRequestMessage = null;
            /*string*/ static WebRequestDiagId = null;
            /*string*/ static DisablePrivateReflectionAttributeMessage = null;
            /*string*/ static DisablePrivateReflectionAttributeDiagId = null;
            /*string*/ static GetContextInfoMessage = null;
            /*string*/ static GetContextInfoDiagId = null;
            /*string*/ static StrongNameKeyPairMessage = null;
            /*string*/ static StrongNameKeyPairDiagId = null;
            /*string*/ static ReflectionOnlyLoadingMessage = null;
            /*string*/ static ReflectionOnlyLoadingDiagId = null;
            /*string*/ static RuntimeEnvironmentMessage = null;
            /*string*/ static RuntimeEnvironmentDiagId = null;
            /*string*/ static JsonSerializerOptionsIgnoreNullValuesMessage = null;
            /*string*/ static JsonSerializerOptionsIgnoreNullValuesDiagId = null;
            /*string*/ static DerivedCryptographicTypesMessage = null;
            /*string*/ static DerivedCryptographicTypesDiagId = null;
            /*string*/ static RijndaelMessage = null;
            /*string*/ static RijndaelDiagId = null;
            /*string*/ static RNGCryptoServiceProviderMessage = null;
            /*string*/ static RNGCryptoServiceProviderDiagId = null;
            /*string*/ static AppDomainCreateUnloadMessage = null;
            /*string*/ static AppDomainCreateUnloadDiagId = null;
            /*string*/ static SuppressIldasmAttributeMessage = null;
            /*string*/ static SuppressIldasmAttributeDiagId = null;
            /*string*/ static X509CertificateImmutableMessage = null;
            /*string*/ static X509CertificateImmutableDiagId = null;
            /*string*/ static PublicKeyPropertyMessage = null;
            /*string*/ static PublicKeyPropertyDiagId = null;
            /*string*/ static X509CertificatePrivateKeyMessage = null;
            /*string*/ static X509CertificatePrivateKeyDiagId = null;
            /*string*/ static ProduceLegacyHmacValuesMessage = null;
            /*string*/ static ProduceLegacyHmacValuesDiagId = null;
            /*string*/ static UseManagedSha1Message = null;
            /*string*/ static UseManagedSha1DiagId = null;
            /*string*/ static CryptoConfigEncodeOIDMessage = null;
            /*string*/ static CryptoConfigEncodeOIDDiagId = null;
            /*string*/ static CorruptedStateRecoveryMessage = null;
            /*string*/ static CorruptedStateRecoveryDiagId = null;
            /*string*/ static Rfc2898CryptDeriveKeyMessage = null;
            /*string*/ static Rfc2898CryptDeriveKeyDiagId = null;
            /*string*/ static CmsSignerCspParamsCtorMessage = null;
            /*string*/ static CmsSignerCspParamsCtorDiagId = null;
            /*string*/ static SignerInfoCounterSigMessage = null;
            /*string*/ static SignerInfoCounterSigDiagId = null;
            /*string*/ static RegexCompileToAssemblyMessage = null;
            /*string*/ static RegexCompileToAssemblyDiagId = null;
            /*string*/ static AssemblyNameMembersMessage = null;
            /*string*/ static AssemblyNameMembersDiagId = null;
            /*string*/ static SystemDataSerializationFormatBinaryMessage = null;
            /*string*/ static SystemDataSerializationFormatBinaryDiagId = null;
            /*string*/ static TlsVersion10and11Message = null;
            /*string*/ static TlsVersion10and11DiagId = null;
            /*string*/ static EncryptionPolicyMessage = null;
            /*string*/ static EncryptionPolicyDiagId = null;
            /*string*/ static EccXmlExportImportMessage = null;
            /*string*/ static EccXmlExportImportDiagId = null;
            /*string*/ static EcDhPublicKeyBlobMessage = null;
            /*string*/ static EcDhPublicKeyBlobDiagId = null;
            /*string*/ static AssemblyNameCodeBaseMessage = null;
            /*string*/ static AssemblyNameCodeBaseDiagId = null;
            /*string*/ static CryptoStringFactoryMessage = null;
            /*string*/ static CryptoStringFactoryDiagId = null;
            /*string*/ static ControlledExecutionRunMessage = null;
            /*string*/ static ControlledExecutionRunDiagId = null;
            /*string*/ static XmlSecureResolverMessage = null;
            /*string*/ static XmlSecureResolverDiagId = null;
            /*string*/ static RsaEncryptDecryptValueMessage = null;
            /*string*/ static RsaEncryptDecryptDiagId = null;
            /*string*/ static JsonSerializerOptionsAddContextMessage = null;
            /*string*/ static JsonSerializerOptionsAddContextDiagId = null;
            /*string*/ static LegacyFormatterMessage = null;
            /*string*/ static LegacyFormatterDiagId = null;
            /*string*/ static LegacyFormatterImplMessage = null;
            /*string*/ static LegacyFormatterImplDiagId = null;
            /*string*/ static RegexExtensibilityImplMessage = null;
            /*string*/ static RegexExtensibilityDiagId = null;
            /*string*/ static AesGcmTagConstructorMessage = null;
            /*string*/ static AesGcmTagConstructorDiagId = null;
            /*string*/ static ThreadVolatileReadWriteMessage = null;
            /*string*/ static ThreadVolatileReadWriteDiagId = null;
            /*string*/ static ArmIntrinsicPerformsUnsignedOperationMessage = null;
            /*string*/ static ArmIntrinsicPerformsUnsignedOperationDiagId = null;
            /*string*/ static LoadFromHashAlgorithmMessage = null;
            /*string*/ static LoadFromHashAlgorithmDiagId = null;
            /*string*/ static X509CtorCertDataObsoleteMessage = null;
            /*string*/ static X509CtorCertDataObsoleteDiagId = null;
            /*string*/ static TlsCipherAlgorithmEnumsMessage = null;
            /*string*/ static TlsCipherAlgorithmEnumsDiagId = null;
            /*string*/ static SystemEventsEventsThreadShutdownMessage = null;
            /*string*/ static SystemEventsEventsThreadShutdownDiagId = null;
            /*string*/ static Rfc2898DeriveBytesCtorMessage = null;
            /*string*/ static Rfc2898DeriveBytesCtorDiagId = null;
            /*string*/ static QueryableMinByMaxByTSourceObsoleteMessage = null;
            /*string*/ static QueryableMinByMaxByTSourceObsoleteDiagId = null;
            /*string*/ static XsltSettingsEnableScriptMessage = null;
            /*string*/ static XsltSettingsEnableScriptDiagId = null;
            //Static Initializer
            static $sinit()
            {
                {
                    this.SharedUrlFormat = "https://aka.ms/dotnet-warnings/{0}";
                }
                {
                    this.SystemTextEncodingUTF7Message = "The UTF-7 encoding is insecure and should not be used. Consider using UTF-8 instead.";
                }
                {
                    this.SystemTextEncodingUTF7DiagId = "SYSLIB0001";
                }
                {
                    this.PrincipalPermissionAttributeMessage = "PrincipalPermissionAttribute is not honored by the runtime and must not be used.";
                }
                {
                    this.PrincipalPermissionAttributeDiagId = "SYSLIB0002";
                }
                {
                    this.CodeAccessSecurityMessage = "Code Access Security is not supported or honored by the runtime.";
                }
                {
                    this.CodeAccessSecurityDiagId = "SYSLIB0003";
                }
                {
                    this.ConstrainedExecutionRegionMessage = "The Constrained Execution Region (CER) feature is not supported.";
                }
                {
                    this.ConstrainedExecutionRegionDiagId = "SYSLIB0004";
                }
                {
                    this.GlobalAssemblyCacheMessage = "The Global Assembly Cache is not supported.";
                }
                {
                    this.GlobalAssemblyCacheDiagId = "SYSLIB0005";
                }
                {
                    this.ThreadAbortMessage = "Thread.Abort is not supported and throws PlatformNotSupportedException.";
                }
                {
                    this.ThreadResetAbortMessage = "Thread.ResetAbort is not supported and throws PlatformNotSupportedException.";
                }
                {
                    this.ThreadAbortDiagId = "SYSLIB0006";
                }
                {
                    this.DefaultCryptoAlgorithmsMessage = "The default implementation of this cryptography algorithm is not supported.";
                }
                {
                    this.DefaultCryptoAlgorithmsDiagId = "SYSLIB0007";
                }
                {
                    this.CreatePdbGeneratorMessage = "The CreatePdbGenerator API is not supported and throws PlatformNotSupportedException.";
                }
                {
                    this.CreatePdbGeneratorDiagId = "SYSLIB0008";
                }
                {
                    this.AuthenticationManagerMessage = "AuthenticationManager is not supported. Methods will no-op or throw PlatformNotSupportedException.";
                }
                {
                    this.AuthenticationManagerDiagId = "SYSLIB0009";
                }
                {
                    this.RemotingApisMessage = "This Remoting API is not supported and throws PlatformNotSupportedException.";
                }
                {
                    this.RemotingApisDiagId = "SYSLIB0010";
                }
                {
                    this.BinaryFormatterMessage = "BinaryFormatter serialization is obsolete and should not be used. See https://aka.ms/binaryformatter for more information.";
                }
                {
                    this.BinaryFormatterDiagId = "SYSLIB0011";
                }
                {
                    this.CodeBaseMessage = "Assembly.CodeBase and Assembly.EscapedCodeBase are only included for .NET Framework compatibility. Use Assembly.Location instead.";
                }
                {
                    this.CodeBaseDiagId = "SYSLIB0012";
                }
                {
                    this.EscapeUriStringMessage = "Uri.EscapeUriString can corrupt the Uri string in some cases. Consider using Uri.EscapeDataString for query string components instead.";
                }
                {
                    this.EscapeUriStringDiagId = "SYSLIB0013";
                }
                {
                    this.WebRequestMessage = "WebRequest, HttpWebRequest, ServicePoint, and WebClient are obsolete. Use HttpClient instead.";
                }
                {
                    this.WebRequestDiagId = "SYSLIB0014";
                }
                {
                    this.DisablePrivateReflectionAttributeMessage = "DisablePrivateReflectionAttribute has no effect in .NET 6.0+.";
                }
                {
                    this.DisablePrivateReflectionAttributeDiagId = "SYSLIB0015";
                }
                {
                    this.GetContextInfoMessage = "Use the Graphics.GetContextInfo overloads that accept arguments for better performance and fewer allocations.";
                }
                {
                    this.GetContextInfoDiagId = "SYSLIB0016";
                }
                {
                    this.StrongNameKeyPairMessage = "Strong name signing is not supported and throws PlatformNotSupportedException.";
                }
                {
                    this.StrongNameKeyPairDiagId = "SYSLIB0017";
                }
                {
                    this.ReflectionOnlyLoadingMessage = "ReflectionOnly loading is not supported and throws PlatformNotSupportedException.";
                }
                {
                    this.ReflectionOnlyLoadingDiagId = "SYSLIB0018";
                }
                {
                    this.RuntimeEnvironmentMessage = "RuntimeEnvironment members SystemConfigurationFile, GetRuntimeInterfaceAsIntPtr, and GetRuntimeInterfaceAsObject are not supported and throw PlatformNotSupportedException.";
                }
                {
                    this.RuntimeEnvironmentDiagId = "SYSLIB0019";
                }
                {
                    this.JsonSerializerOptionsIgnoreNullValuesMessage = "JsonSerializerOptions.IgnoreNullValues is obsolete. To ignore null values when serializing, set DefaultIgnoreCondition to JsonIgnoreCondition.WhenWritingNull.";
                }
                {
                    this.JsonSerializerOptionsIgnoreNullValuesDiagId = "SYSLIB0020";
                }
                {
                    this.DerivedCryptographicTypesMessage = "Derived cryptographic types are obsolete. Use the Create method on the base type instead.";
                }
                {
                    this.DerivedCryptographicTypesDiagId = "SYSLIB0021";
                }
                {
                    this.RijndaelMessage = "The Rijndael and RijndaelManaged types are obsolete. Use Aes instead.";
                }
                {
                    this.RijndaelDiagId = "SYSLIB0022";
                }
                {
                    this.RNGCryptoServiceProviderMessage = "RNGCryptoServiceProvider is obsolete. To generate a random number, use one of the RandomNumberGenerator static methods instead.";
                }
                {
                    this.RNGCryptoServiceProviderDiagId = "SYSLIB0023";
                }
                {
                    this.AppDomainCreateUnloadMessage = "Creating and unloading AppDomains is not supported and throws an exception.";
                }
                {
                    this.AppDomainCreateUnloadDiagId = "SYSLIB0024";
                }
                {
                    this.SuppressIldasmAttributeMessage = "SuppressIldasmAttribute has no effect in .NET 6.0+.";
                }
                {
                    this.SuppressIldasmAttributeDiagId = "SYSLIB0025";
                }
                {
                    this.X509CertificateImmutableMessage = "X509Certificate and X509Certificate2 are immutable. Use X509CertificateLoader to create a new certificate.";
                }
                {
                    this.X509CertificateImmutableDiagId = "SYSLIB0026";
                }
                {
                    this.PublicKeyPropertyMessage = "PublicKey.Key is obsolete. Use the appropriate method to get the public key, such as GetRSAPublicKey.";
                }
                {
                    this.PublicKeyPropertyDiagId = "SYSLIB0027";
                }
                {
                    this.X509CertificatePrivateKeyMessage = "X509Certificate2.PrivateKey is obsolete. Use the appropriate method to get the private key, such as GetRSAPrivateKey, or use the CopyWithPrivateKey method to create a new instance with a private key.";
                }
                {
                    this.X509CertificatePrivateKeyDiagId = "SYSLIB0028";
                }
                {
                    this.ProduceLegacyHmacValuesMessage = "ProduceLegacyHmacValues is obsolete. Producing legacy HMAC values is not supported.";
                }
                {
                    this.ProduceLegacyHmacValuesDiagId = "SYSLIB0029";
                }
                {
                    this.UseManagedSha1Message = "HMACSHA1 always uses the algorithm implementation provided by the platform. Use a constructor without the useManagedSha1 parameter.";
                }
                {
                    this.UseManagedSha1DiagId = "SYSLIB0030";
                }
                {
                    this.CryptoConfigEncodeOIDMessage = "EncodeOID is obsolete. Use the ASN.1 functionality provided in System.Formats.Asn1.";
                }
                {
                    this.CryptoConfigEncodeOIDDiagId = "SYSLIB0031";
                }
                {
                    this.CorruptedStateRecoveryMessage = "Recovery from corrupted process state exceptions is not supported; HandleProcessCorruptedStateExceptionsAttribute is ignored.";
                }
                {
                    this.CorruptedStateRecoveryDiagId = "SYSLIB0032";
                }
                {
                    this.Rfc2898CryptDeriveKeyMessage = "Rfc2898DeriveBytes.CryptDeriveKey is obsolete and is not supported. Use PasswordDeriveBytes.CryptDeriveKey instead.";
                }
                {
                    this.Rfc2898CryptDeriveKeyDiagId = "SYSLIB0033";
                }
                {
                    this.CmsSignerCspParamsCtorMessage = "CmsSigner(CspParameters) is obsolete and is not supported. Use an alternative constructor instead.";
                }
                {
                    this.CmsSignerCspParamsCtorDiagId = "SYSLIB0034";
                }
                {
                    this.SignerInfoCounterSigMessage = "ComputeCounterSignature without specifying a CmsSigner is obsolete and is not supported. Use the overload that accepts a CmsSigner.";
                }
                {
                    this.SignerInfoCounterSigDiagId = "SYSLIB0035";
                }
                {
                    this.RegexCompileToAssemblyMessage = "Regex.CompileToAssembly is obsolete and not supported. Use the GeneratedRegexAttribute with the regular expression source generator instead.";
                }
                {
                    this.RegexCompileToAssemblyDiagId = "SYSLIB0036";
                }
                {
                    this.AssemblyNameMembersMessage = "AssemblyName members HashAlgorithm, ProcessorArchitecture, and VersionCompatibility are obsolete and not supported.";
                }
                {
                    this.AssemblyNameMembersDiagId = "SYSLIB0037";
                }
                {
                    this.SystemDataSerializationFormatBinaryMessage = "SerializationFormat.Binary is obsolete and should not be used. See https://aka.ms/serializationformat-binary-obsolete for more information.";
                }
                {
                    this.SystemDataSerializationFormatBinaryDiagId = "SYSLIB0038";
                }
                {
                    this.TlsVersion10and11Message = "TLS versions 1.0 and 1.1 have known vulnerabilities and are not recommended. Use a newer TLS version instead, or use SslProtocols.None to defer to OS defaults.";
                }
                {
                    this.TlsVersion10and11DiagId = "SYSLIB0039";
                }
                {
                    this.EncryptionPolicyMessage = "EncryptionPolicy.NoEncryption and AllowEncryption significantly reduce security and should not be used in production code.";
                }
                {
                    this.EncryptionPolicyDiagId = "SYSLIB0040";
                }
                {
                    this.EccXmlExportImportMessage = "ToXmlString and FromXmlString have no implementation for ECC types, and are obsolete. Use a standard import and export format such as ExportSubjectPublicKeyInfo or ImportSubjectPublicKeyInfo for public keys and ExportPkcs8PrivateKey or ImportPkcs8PrivateKey for private keys.";
                }
                {
                    this.EccXmlExportImportDiagId = "SYSLIB0042";
                }
                {
                    this.EcDhPublicKeyBlobMessage = "ECDiffieHellmanPublicKey.ToByteArray() and the associated constructor do not have a consistent and interoperable implementation on all platforms. Use ECDiffieHellmanPublicKey.ExportSubjectPublicKeyInfo() instead.";
                }
                {
                    this.EcDhPublicKeyBlobDiagId = "SYSLIB0043";
                }
                {
                    this.AssemblyNameCodeBaseMessage = "AssemblyName.CodeBase and AssemblyName.EscapedCodeBase are obsolete. Using them for loading an assembly is not supported.";
                }
                {
                    this.AssemblyNameCodeBaseDiagId = "SYSLIB0044";
                }
                {
                    this.CryptoStringFactoryMessage = "Cryptographic factory methods accepting an algorithm name are obsolete. Use the parameterless Create factory method on the algorithm type instead.";
                }
                {
                    this.CryptoStringFactoryDiagId = "SYSLIB0045";
                }
                {
                    this.ControlledExecutionRunMessage = "ControlledExecution.Run method may corrupt the process and should not be used in production code.";
                }
                {
                    this.ControlledExecutionRunDiagId = "SYSLIB0046";
                }
                {
                    this.XmlSecureResolverMessage = "XmlSecureResolver is obsolete. Use XmlResolver.ThrowingResolver instead when attempting to forbid XML external entity resolution.";
                }
                {
                    this.XmlSecureResolverDiagId = "SYSLIB0047";
                }
                {
                    this.RsaEncryptDecryptValueMessage = "RSA.EncryptValue and DecryptValue are not supported and throw NotSupportedException. Use RSA.Encrypt and RSA.Decrypt instead.";
                }
                {
                    this.RsaEncryptDecryptDiagId = "SYSLIB0048";
                }
                {
                    this.JsonSerializerOptionsAddContextMessage = "JsonSerializerOptions.AddContext is obsolete. To register a JsonSerializerContext, use either the TypeInfoResolver or TypeInfoResolverChain properties.";
                }
                {
                    this.JsonSerializerOptionsAddContextDiagId = "SYSLIB0049";
                }
                {
                    this.LegacyFormatterMessage = "Formatter-based serialization is obsolete and should not be used.";
                }
                {
                    this.LegacyFormatterDiagId = "SYSLIB0050";
                }
                {
                    this.LegacyFormatterImplMessage = "This API supports obsolete formatter-based serialization. It should not be called or extended by application code.";
                }
                {
                    this.LegacyFormatterImplDiagId = "SYSLIB0051";
                }
                {
                    this.RegexExtensibilityImplMessage = "This API supports obsolete mechanisms for Regex extensibility. It is not supported.";
                }
                {
                    this.RegexExtensibilityDiagId = "SYSLIB0052";
                }
                {
                    this.AesGcmTagConstructorMessage = "AesGcm should indicate the required tag size for encryption and decryption. Use a constructor that accepts the tag size.";
                }
                {
                    this.AesGcmTagConstructorDiagId = "SYSLIB0053";
                }
                {
                    this.ThreadVolatileReadWriteMessage = "Thread.VolatileRead and Thread.VolatileWrite are obsolete. Use Volatile.Read or Volatile.Write respectively instead.";
                }
                {
                    this.ThreadVolatileReadWriteDiagId = "SYSLIB0054";
                }
                {
                    this.ArmIntrinsicPerformsUnsignedOperationMessage = "The underlying hardware instruction does not perform a signed saturate narrowing operation, and it always returns an unsigned result. Use the unsigned overload instead.";
                }
                {
                    this.ArmIntrinsicPerformsUnsignedOperationDiagId = "SYSLIB0055";
                }
                {
                    this.LoadFromHashAlgorithmMessage = "LoadFrom with a custom AssemblyHashAlgorithm is obsolete. Use overloads without an AssemblyHashAlgorithm.";
                }
                {
                    this.LoadFromHashAlgorithmDiagId = "SYSLIB0056";
                }
                {
                    this.X509CtorCertDataObsoleteMessage = "Loading certificate data through the constructor or Import is obsolete. Use X509CertificateLoader instead to load certificates.";
                }
                {
                    this.X509CtorCertDataObsoleteDiagId = "SYSLIB0057";
                }
                {
                    this.TlsCipherAlgorithmEnumsMessage = "KeyExchangeAlgorithm, KeyExchangeStrength, CipherAlgorithm, CipherStrength, HashAlgorithm and HashStrength properties of SslStream are obsolete. Use NegotiatedCipherSuite instead.";
                }
                {
                    this.TlsCipherAlgorithmEnumsDiagId = "SYSLIB0058";
                }
                {
                    this.SystemEventsEventsThreadShutdownMessage = "SystemEvents.EventsThreadShutdown callbacks are not run before the process exits. Use AppDomain.ProcessExit instead.";
                }
                {
                    this.SystemEventsEventsThreadShutdownDiagId = "SYSLIB0059";
                }
                {
                    this.Rfc2898DeriveBytesCtorMessage = "The constructors on Rfc2898DeriveBytes are obsolete. Use the static Pbkdf2 method instead.";
                }
                {
                    this.Rfc2898DeriveBytesCtorDiagId = "SYSLIB0060";
                }
                {
                    this.QueryableMinByMaxByTSourceObsoleteMessage = "The Queryable MinBy and MaxBy taking an IComparer<TSource> are obsolete. Use the new ones that take an IComparer<TKey>.";
                }
                {
                    this.QueryableMinByMaxByTSourceObsoleteDiagId = "SYSLIB0061";
                }
                {
                    this.XsltSettingsEnableScriptMessage = "XSLT Script blocks are not supported.";
                }
                {
                    this.XsltSettingsEnableScriptDiagId = "SYSLIB0062";
                }
            }
            static $h = 102247;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"l":[{"t":1310721,"n":"SharedUrlFormat","d":102247,"h":4295069543,"f":40},{"t":1310721,"n":"SystemTextEncodingUTF7Message","d":102247,"h":8590036839,"f":40},{"t":1310721,"n":"SystemTextEncodingUTF7DiagId","d":102247,"h":12885004135,"f":40},{"t":1310721,"n":"PrincipalPermissionAttributeMessage","d":102247,"h":17179971431,"f":40},{"t":1310721,"n":"PrincipalPermissionAttributeDiagId","d":102247,"h":21474938727,"f":40},{"t":1310721,"n":"CodeAccessSecurityMessage","d":102247,"h":25769906023,"f":40},{"t":1310721,"n":"CodeAccessSecurityDiagId","d":102247,"h":30064873319,"f":40},{"t":1310721,"n":"ConstrainedExecutionRegionMessage","d":102247,"h":34359840615,"f":40},{"t":1310721,"n":"ConstrainedExecutionRegionDiagId","d":102247,"h":38654807911,"f":40},{"t":1310721,"n":"GlobalAssemblyCacheMessage","d":102247,"h":42949775207,"f":40},{"t":1310721,"n":"GlobalAssemblyCacheDiagId","d":102247,"h":47244742503,"f":40},{"t":1310721,"n":"ThreadAbortMessage","d":102247,"h":51539709799,"f":40},{"t":1310721,"n":"ThreadResetAbortMessage","d":102247,"h":55834677095,"f":40},{"t":1310721,"n":"ThreadAbortDiagId","d":102247,"h":60129644391,"f":40},{"t":1310721,"n":"DefaultCryptoAlgorithmsMessage","d":102247,"h":64424611687,"f":40},{"t":1310721,"n":"DefaultCryptoAlgorithmsDiagId","d":102247,"h":68719578983,"f":40},{"t":1310721,"n":"CreatePdbGeneratorMessage","d":102247,"h":73014546279,"f":40},{"t":1310721,"n":"CreatePdbGeneratorDiagId","d":102247,"h":77309513575,"f":40},{"t":1310721,"n":"AuthenticationManagerMessage","d":102247,"h":81604480871,"f":40},{"t":1310721,"n":"AuthenticationManagerDiagId","d":102247,"h":85899448167,"f":40},{"t":1310721,"n":"RemotingApisMessage","d":102247,"h":90194415463,"f":40},{"t":1310721,"n":"RemotingApisDiagId","d":102247,"h":94489382759,"f":40},{"t":1310721,"n":"BinaryFormatterMessage","d":102247,"h":98784350055,"f":40},{"t":1310721,"n":"BinaryFormatterDiagId","d":102247,"h":103079317351,"f":40},{"t":1310721,"n":"CodeBaseMessage","d":102247,"h":107374284647,"f":40},{"t":1310721,"n":"CodeBaseDiagId","d":102247,"h":111669251943,"f":40},{"t":1310721,"n":"EscapeUriStringMessage","d":102247,"h":115964219239,"f":40},{"t":1310721,"n":"EscapeUriStringDiagId","d":102247,"h":120259186535,"f":40},{"t":1310721,"n":"WebRequestMessage","d":102247,"h":124554153831,"f":40},{"t":1310721,"n":"WebRequestDiagId","d":102247,"h":128849121127,"f":40},{"t":1310721,"n":"DisablePrivateReflectionAttributeMessage","d":102247,"h":133144088423,"f":40},{"t":1310721,"n":"DisablePrivateReflectionAttributeDiagId","d":102247,"h":137439055719,"f":40},{"t":1310721,"n":"GetContextInfoMessage","d":102247,"h":141734023015,"f":40},{"t":1310721,"n":"GetContextInfoDiagId","d":102247,"h":146028990311,"f":40},{"t":1310721,"n":"StrongNameKeyPairMessage","d":102247,"h":150323957607,"f":40},{"t":1310721,"n":"StrongNameKeyPairDiagId","d":102247,"h":154618924903,"f":40},{"t":1310721,"n":"ReflectionOnlyLoadingMessage","d":102247,"h":158913892199,"f":40},{"t":1310721,"n":"ReflectionOnlyLoadingDiagId","d":102247,"h":163208859495,"f":40},{"t":1310721,"n":"RuntimeEnvironmentMessage","d":102247,"h":167503826791,"f":40},{"t":1310721,"n":"RuntimeEnvironmentDiagId","d":102247,"h":171798794087,"f":40},{"t":1310721,"n":"JsonSerializerOptionsIgnoreNullValuesMessage","d":102247,"h":176093761383,"f":40},{"t":1310721,"n":"JsonSerializerOptionsIgnoreNullValuesDiagId","d":102247,"h":180388728679,"f":40},{"t":1310721,"n":"DerivedCryptographicTypesMessage","d":102247,"h":184683695975,"f":40},{"t":1310721,"n":"DerivedCryptographicTypesDiagId","d":102247,"h":188978663271,"f":40},{"t":1310721,"n":"RijndaelMessage","d":102247,"h":193273630567,"f":40},{"t":1310721,"n":"RijndaelDiagId","d":102247,"h":197568597863,"f":40},{"t":1310721,"n":"RNGCryptoServiceProviderMessage","d":102247,"h":201863565159,"f":40},{"t":1310721,"n":"RNGCryptoServiceProviderDiagId","d":102247,"h":206158532455,"f":40},{"t":1310721,"n":"AppDomainCreateUnloadMessage","d":102247,"h":210453499751,"f":40},{"t":1310721,"n":"AppDomainCreateUnloadDiagId","d":102247,"h":214748467047,"f":40},{"t":1310721,"n":"SuppressIldasmAttributeMessage","d":102247,"h":219043434343,"f":40},{"t":1310721,"n":"SuppressIldasmAttributeDiagId","d":102247,"h":223338401639,"f":40},{"t":1310721,"n":"X509CertificateImmutableMessage","d":102247,"h":227633368935,"f":40},{"t":1310721,"n":"X509CertificateImmutableDiagId","d":102247,"h":231928336231,"f":40},{"t":1310721,"n":"PublicKeyPropertyMessage","d":102247,"h":236223303527,"f":40},{"t":1310721,"n":"PublicKeyPropertyDiagId","d":102247,"h":240518270823,"f":40},{"t":1310721,"n":"X509CertificatePrivateKeyMessage","d":102247,"h":244813238119,"f":40},{"t":1310721,"n":"X509CertificatePrivateKeyDiagId","d":102247,"h":249108205415,"f":40},{"t":1310721,"n":"ProduceLegacyHmacValuesMessage","d":102247,"h":253403172711,"f":40},{"t":1310721,"n":"ProduceLegacyHmacValuesDiagId","d":102247,"h":257698140007,"f":40},{"t":1310721,"n":"UseManagedSha1Message","d":102247,"h":261993107303,"f":40},{"t":1310721,"n":"UseManagedSha1DiagId","d":102247,"h":266288074599,"f":40},{"t":1310721,"n":"CryptoConfigEncodeOIDMessage","d":102247,"h":270583041895,"f":40},{"t":1310721,"n":"CryptoConfigEncodeOIDDiagId","d":102247,"h":274878009191,"f":40},{"t":1310721,"n":"CorruptedStateRecoveryMessage","d":102247,"h":279172976487,"f":40},{"t":1310721,"n":"CorruptedStateRecoveryDiagId","d":102247,"h":283467943783,"f":40},{"t":1310721,"n":"Rfc2898CryptDeriveKeyMessage","d":102247,"h":287762911079,"f":40},{"t":1310721,"n":"Rfc2898CryptDeriveKeyDiagId","d":102247,"h":292057878375,"f":40},{"t":1310721,"n":"CmsSignerCspParamsCtorMessage","d":102247,"h":296352845671,"f":40},{"t":1310721,"n":"CmsSignerCspParamsCtorDiagId","d":102247,"h":300647812967,"f":40},{"t":1310721,"n":"SignerInfoCounterSigMessage","d":102247,"h":304942780263,"f":40},{"t":1310721,"n":"SignerInfoCounterSigDiagId","d":102247,"h":309237747559,"f":40},{"t":1310721,"n":"RegexCompileToAssemblyMessage","d":102247,"h":313532714855,"f":40},{"t":1310721,"n":"RegexCompileToAssemblyDiagId","d":102247,"h":317827682151,"f":40},{"t":1310721,"n":"AssemblyNameMembersMessage","d":102247,"h":322122649447,"f":40},{"t":1310721,"n":"AssemblyNameMembersDiagId","d":102247,"h":326417616743,"f":40},{"t":1310721,"n":"SystemDataSerializationFormatBinaryMessage","d":102247,"h":330712584039,"f":40},{"t":1310721,"n":"SystemDataSerializationFormatBinaryDiagId","d":102247,"h":335007551335,"f":40},{"t":1310721,"n":"TlsVersion10and11Message","d":102247,"h":339302518631,"f":40},{"t":1310721,"n":"TlsVersion10and11DiagId","d":102247,"h":343597485927,"f":40},{"t":1310721,"n":"EncryptionPolicyMessage","d":102247,"h":347892453223,"f":40},{"t":1310721,"n":"EncryptionPolicyDiagId","d":102247,"h":352187420519,"f":40},{"t":1310721,"n":"EccXmlExportImportMessage","d":102247,"h":356482387815,"f":40},{"t":1310721,"n":"EccXmlExportImportDiagId","d":102247,"h":360777355111,"f":40},{"t":1310721,"n":"EcDhPublicKeyBlobMessage","d":102247,"h":365072322407,"f":40},{"t":1310721,"n":"EcDhPublicKeyBlobDiagId","d":102247,"h":369367289703,"f":40},{"t":1310721,"n":"AssemblyNameCodeBaseMessage","d":102247,"h":373662256999,"f":40},{"t":1310721,"n":"AssemblyNameCodeBaseDiagId","d":102247,"h":377957224295,"f":40},{"t":1310721,"n":"CryptoStringFactoryMessage","d":102247,"h":382252191591,"f":40},{"t":1310721,"n":"CryptoStringFactoryDiagId","d":102247,"h":386547158887,"f":40},{"t":1310721,"n":"ControlledExecutionRunMessage","d":102247,"h":390842126183,"f":40},{"t":1310721,"n":"ControlledExecutionRunDiagId","d":102247,"h":395137093479,"f":40},{"t":1310721,"n":"XmlSecureResolverMessage","d":102247,"h":399432060775,"f":40},{"t":1310721,"n":"XmlSecureResolverDiagId","d":102247,"h":403727028071,"f":40},{"t":1310721,"n":"RsaEncryptDecryptValueMessage","d":102247,"h":408021995367,"f":40},{"t":1310721,"n":"RsaEncryptDecryptDiagId","d":102247,"h":412316962663,"f":40},{"t":1310721,"n":"JsonSerializerOptionsAddContextMessage","d":102247,"h":416611929959,"f":40},{"t":1310721,"n":"JsonSerializerOptionsAddContextDiagId","d":102247,"h":420906897255,"f":40},{"t":1310721,"n":"LegacyFormatterMessage","d":102247,"h":425201864551,"f":40},{"t":1310721,"n":"LegacyFormatterDiagId","d":102247,"h":429496831847,"f":40},{"t":1310721,"n":"LegacyFormatterImplMessage","d":102247,"h":433791799143,"f":40},{"t":1310721,"n":"LegacyFormatterImplDiagId","d":102247,"h":438086766439,"f":40},{"t":1310721,"n":"RegexExtensibilityImplMessage","d":102247,"h":442381733735,"f":40},{"t":1310721,"n":"RegexExtensibilityDiagId","d":102247,"h":446676701031,"f":40},{"t":1310721,"n":"AesGcmTagConstructorMessage","d":102247,"h":450971668327,"f":40},{"t":1310721,"n":"AesGcmTagConstructorDiagId","d":102247,"h":455266635623,"f":40},{"t":1310721,"n":"ThreadVolatileReadWriteMessage","d":102247,"h":459561602919,"f":40},{"t":1310721,"n":"ThreadVolatileReadWriteDiagId","d":102247,"h":463856570215,"f":40},{"t":1310721,"n":"ArmIntrinsicPerformsUnsignedOperationMessage","d":102247,"h":468151537511,"f":40},{"t":1310721,"n":"ArmIntrinsicPerformsUnsignedOperationDiagId","d":102247,"h":472446504807,"f":40},{"t":1310721,"n":"LoadFromHashAlgorithmMessage","d":102247,"h":476741472103,"f":40},{"t":1310721,"n":"LoadFromHashAlgorithmDiagId","d":102247,"h":481036439399,"f":40},{"t":1310721,"n":"X509CtorCertDataObsoleteMessage","d":102247,"h":485331406695,"f":40},{"t":1310721,"n":"X509CtorCertDataObsoleteDiagId","d":102247,"h":489626373991,"f":40},{"t":1310721,"n":"TlsCipherAlgorithmEnumsMessage","d":102247,"h":493921341287,"f":40},{"t":1310721,"n":"TlsCipherAlgorithmEnumsDiagId","d":102247,"h":498216308583,"f":40},{"t":1310721,"n":"SystemEventsEventsThreadShutdownMessage","d":102247,"h":502511275879,"f":40},{"t":1310721,"n":"SystemEventsEventsThreadShutdownDiagId","d":102247,"h":506806243175,"f":40},{"t":1310721,"n":"Rfc2898DeriveBytesCtorMessage","d":102247,"h":511101210471,"f":40},{"t":1310721,"n":"Rfc2898DeriveBytesCtorDiagId","d":102247,"h":515396177767,"f":40},{"t":1310721,"n":"QueryableMinByMaxByTSourceObsoleteMessage","d":102247,"h":519691145063,"f":40},{"t":1310721,"n":"QueryableMinByMaxByTSourceObsoleteDiagId","d":102247,"h":523986112359,"f":40},{"t":1310721,"n":"XsltSettingsEnableScriptMessage","d":102247,"h":528281079655,"f":40},{"t":1310721,"n":"XsltSettingsEnableScriptDiagId","d":102247,"h":532576046951,"f":40}],"h":102247}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.Obsoletions`; }
        });
        
        $asm.$cls("$srsp.System.SR", ($self) => class SR
        {
            /*global::System.Resources.ResourceManager*/ static s_resourceManager = null;
            /*global::System.Globalization.CultureInfo*/ static resourceCulture = null;
            static /*global::System.Resources.ResourceManager */ get ResourceManager()
            {
                if ($.$spc.System.Object.ReferenceEquals($.$srsp.System.SR.s_resourceManager, null))
                {
                    /*global::System.Resources.ResourceManager*/ let temp = new $.$spc.System.Resources.ResourceManager().$ctor$3("System.Runtime.Serialization.Primitives", $.$srsp.System.SR.$type.Assembly);
                    $.$srsp.System.SR.s_resourceManager = temp;
                }
                return $.$srsp.System.SR.s_resourceManager;
            }
            static /*global::System.Globalization.CultureInfo */ get Culture()
            {
                return $.$srsp.System.SR.resourceCulture;
            }
            static /*global::System.Globalization.CultureInfo */ set Culture(value)
            {
                $.$srsp.System.SR.resourceCulture = value;
            }
            static /*string */ get OrderCannotBeNegative()
            {
                return "Property 'Order' in DataMemberAttribute attribute cannot be a negative number.";
            }
            /*bool*/ static s_usingResourceKeys = false;
            static /*bool */ GetUsingResourceKeysSwitchValue()
            {
                /*bool*/ let usingResourceKeys;
                return $.$spc.System.AppContext.TryGetSwitch("System.Resources.UseSystemResourceKeys", $.$ref(() => usingResourceKeys, ($v) => usingResourceKeys = $v, $.$spc.System.Boolean)) ? usingResourceKeys : false;
            }
            static /*bool */ UsingResourceKeys()
            {
                return $.$srsp.System.SR.s_usingResourceKeys;
            }
            static /*string */ GetResourceString(/*string*/ resourceKey)
            {
                if ($.$srsp.System.SR.UsingResourceKeys())
                {
                    return resourceKey;
                }
                /*string?*/ let resourceString = null;
                try
                {
                    resourceString = $.$srsp.System.SR.ResourceManager.GetString(resourceKey);
                }
                catch($e)
                {
                }
                return resourceString;
            }
            static /*string */ GetResourceString$1(/*string*/ resourceKey, /*string*/ defaultString)
            {
                /*string*/ let resourceString = $.$srsp.System.SR.GetResourceString(resourceKey);
                return $.$spc.System.String.op_Equality(resourceKey, resourceString) || $.$spc.System.String.op_Equality(resourceString, null) ? defaultString : resourceString;
            }
            static /*string */ Format(/*string*/ resourceFormat, /*object?*/ p1)
            {
                if ($.$srsp.System.SR.UsingResourceKeys())
                {
                    return $.$spc.System.String.Join$10(", ", $.$spc.System.ReadOnlySpan$$($.$spc.System.Object).op_Implicit([ resourceFormat, p1 ]));
                }
                return $.$spc.System.String.Format(resourceFormat, p1);
            }
            static /*string */ Format$1(/*string*/ resourceFormat, /*object?*/ p1, /*object?*/ p2)
            {
                if ($.$srsp.System.SR.UsingResourceKeys())
                {
                    return $.$spc.System.String.Join$10(", ", $.$spc.System.ReadOnlySpan$$($.$spc.System.Object).op_Implicit([ resourceFormat, p1, p2 ]));
                }
                return $.$spc.System.String.Format$1(resourceFormat, p1, p2);
            }
            static /*string */ Format$2(/*string*/ resourceFormat, /*object?*/ p1, /*object?*/ p2, /*object?*/ p3)
            {
                if ($.$srsp.System.SR.UsingResourceKeys())
                {
                    return $.$spc.System.String.Join$10(", ", $.$spc.System.ReadOnlySpan$$($.$spc.System.Object).op_Implicit([ resourceFormat, p1, p2, p3 ]));
                }
                return $.$spc.System.String.Format$2(resourceFormat, p1, p2, p3);
            }
            static /*string */ Format$3(/*string*/ resourceFormat, /*params object?[]?*/ args)
            {
                if (args !== null)
                {
                    if ($.$srsp.System.SR.UsingResourceKeys())
                    {
                        return resourceFormat + ", " + $.$spc.System.String.Join$9(", ", args);
                    }
                    return $.$spc.System.String.Format$3(resourceFormat, args);
                }
                return resourceFormat;
            }
            static /*string */ Format$4(/*IFormatProvider?*/ provider, /*string*/ resourceFormat, /*object?*/ p1)
            {
                if ($.$srsp.System.SR.UsingResourceKeys())
                {
                    return $.$spc.System.String.Join$10(", ", $.$spc.System.ReadOnlySpan$$($.$spc.System.Object).op_Implicit([ resourceFormat, p1 ]));
                }
                return $.$spc.System.String.Format$5(provider, resourceFormat, p1);
            }
            static /*string */ Format$5(/*IFormatProvider?*/ provider, /*string*/ resourceFormat, /*object?*/ p1, /*object?*/ p2)
            {
                if ($.$srsp.System.SR.UsingResourceKeys())
                {
                    return $.$spc.System.String.Join$10(", ", $.$spc.System.ReadOnlySpan$$($.$spc.System.Object).op_Implicit([ resourceFormat, p1, p2 ]));
                }
                return $.$spc.System.String.Format$6(provider, resourceFormat, p1, p2);
            }
            static /*string */ Format$6(/*IFormatProvider?*/ provider, /*string*/ resourceFormat, /*object?*/ p1, /*object?*/ p2, /*object?*/ p3)
            {
                if ($.$srsp.System.SR.UsingResourceKeys())
                {
                    return $.$spc.System.String.Join$10(", ", $.$spc.System.ReadOnlySpan$$($.$spc.System.Object).op_Implicit([ resourceFormat, p1, p2, p3 ]));
                }
                return $.$spc.System.String.Format$7(provider, resourceFormat, p1, p2, p3);
            }
            static /*string */ Format$7(/*IFormatProvider?*/ provider, /*string*/ resourceFormat, /*params object?[]?*/ args)
            {
                if (args !== null)
                {
                    if ($.$srsp.System.SR.UsingResourceKeys())
                    {
                        return resourceFormat + ", " + $.$spc.System.String.Join$9(", ", args);
                    }
                    return $.$spc.System.String.Format$8(provider, resourceFormat, args);
                }
                return resourceFormat;
            }
            //Static Initializer
            static $sinit()
            {
                {
                    this.s_usingResourceKeys = $.$srsp.System.SR.GetUsingResourceKeysSwitchValue();
                }
            }
            static $h = 823143;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"h":823143}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.SR`; }
        });
        
        $asm.$cls("$srsp.System.Runtime.Serialization.IgnoreDataMemberAttribute", ($self) => class IgnoreDataMemberAttribute extends $.$spc.System.Attribute
        {
            $ctor$2()
            {
                super.$ctor$1();
                {
                }
                return this;
            }
            static $h = 495463;
            static $f = 0b10010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":14548993,"c":[{"n":".ctor","o":"$ctor$2","d":495463,"h":4295462759,"f":1}],"h":495463,"a":[{"t":14680065,"c":21489516545,"a":[{"v":384,"t":14614529}],"n":[{"n":"Inherited","v":false,"t":262145},{"n":"AllowMultiple","v":false,"t":262145}]}]}; }
            static get $b() { return $.$spc.System.Attribute; }
            static get $fullName() { return `System.Runtime.Serialization.IgnoreDataMemberAttribute`; }
        });
        
        $asm.$cls("$srsp.System.Runtime.Serialization.ContractNamespaceAttribute", ($self) => class ContractNamespaceAttribute extends $.$spc.System.Attribute
        {
            $ctor$2(/*string*/ contractNamespace)
            {
                super.$ctor$1();
                {
                    this.ContractNamespace = contractNamespace;
                }
                return this;
            }
            /*string?*/ ClrNamespace = null;
            /*string*/ ContractNamespace = null;
            static $h = 233319;
            static $f = 0b10010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":14548993,"p":[{"p":1310721,"g":{"r":0,"d":0,"h":17180102503,"f":1},"s":{"r":0,"d":0,"h":21475069799,"f":1},"n":"ClrNamespace","d":233319,"h":12885135207,"f":1},{"p":1310721,"g":{"r":0,"d":0,"h":34359971687,"f":1},"n":"ContractNamespace","d":233319,"h":30065004391,"f":1}],"c":[{"p":[{"n":"contractNamespace","p":1310721}],"n":".ctor","o":"$ctor$2","d":233319,"h":4295200615,"f":1}],"h":233319,"a":[{"t":14680065,"c":21489516545,"a":[{"v":3,"t":14614529}],"n":[{"n":"Inherited","v":false,"t":262145},{"n":"AllowMultiple","v":true,"t":262145}]}]}; }
            static get $b() { return $.$spc.System.Attribute; }
            static get $fullName() { return `System.Runtime.Serialization.ContractNamespaceAttribute`; }
        });
        
        $asm.$cls("$srsp.System.Runtime.Serialization.KnownTypeAttribute", ($self) => class KnownTypeAttribute extends $.$spc.System.Attribute
        {
            $ctor$2(/*Type*/ type)
            {
                super.$ctor$1();
                {
                    this.Type = type;
                }
                return this;
            }
            $ctor$3(/*string*/ methodName)
            {
                super.$ctor$1();
                {
                    this.MethodName = methodName;
                }
                return this;
            }
            /*string?*/ MethodName = null;
            /*Type?*/ Type = null;
            static $h = 757607;
            static $f = 0b10010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":14548993,"p":[{"p":1310721,"g":{"r":0,"d":0,"h":21475594087,"f":1},"n":"MethodName","d":757607,"h":17180626791,"f":1},{"p":142606337,"g":{"r":0,"d":0,"h":34360495975,"f":1},"n":"Type","d":757607,"h":30065528679,"f":1}],"c":[{"p":[{"n":"type","p":142606337}],"n":".ctor","o":"$ctor$2","d":757607,"h":4295724903,"f":1},{"p":[{"n":"methodName","p":1310721}],"n":".ctor","o":"$ctor$3","d":757607,"h":8590692199,"f":1}],"h":757607,"a":[{"t":14680065,"c":21489516545,"a":[{"v":12,"t":14614529}],"n":[{"n":"Inherited","v":true,"t":262145},{"n":"AllowMultiple","v":true,"t":262145}]}]}; }
            static get $b() { return $.$spc.System.Attribute; }
            static get $fullName() { return `System.Runtime.Serialization.KnownTypeAttribute`; }
        });
        
        $asm.$cls("$srsp.System.Runtime.Serialization.CollectionDataContractAttribute", ($self) => class CollectionDataContractAttribute extends $.$spc.System.Attribute
        {
            /*string?*/ _name = null;
            /*string?*/ _ns = null;
            /*string?*/ _itemName = null;
            /*string?*/ _keyName = null;
            /*string?*/ _valueName = null;
            /*bool*/ _isReference = false;
            /*bool*/ _isNameSetExplicitly = false;
            /*bool*/ _isNamespaceSetExplicitly = false;
            /*bool*/ _isReferenceSetExplicitly = false;
            /*bool*/ _isItemNameSetExplicitly = false;
            /*bool*/ _isKeyNameSetExplicitly = false;
            /*bool*/ _isValueNameSetExplicitly = false;
            $ctor$2()
            {
                super.$ctor$1();
                {
                }
                return this;
            }
            /*string? */ get Namespace()
            {
                return this._ns;
            }
            /*string? */ set Namespace(value)
            {
                this._ns = value;
                this._isNamespaceSetExplicitly = true;
            }
            /*bool */ get IsNamespaceSetExplicitly()
            {
                return this._isNamespaceSetExplicitly;
            }
            /*string? */ get Name()
            {
                return this._name;
            }
            /*string? */ set Name(value)
            {
                this._name = value;
                this._isNameSetExplicitly = true;
            }
            /*bool */ get IsNameSetExplicitly()
            {
                return this._isNameSetExplicitly;
            }
            /*string? */ get ItemName()
            {
                return this._itemName;
            }
            /*string? */ set ItemName(value)
            {
                this._itemName = value;
                this._isItemNameSetExplicitly = true;
            }
            /*bool */ get IsItemNameSetExplicitly()
            {
                return this._isItemNameSetExplicitly;
            }
            /*string? */ get KeyName()
            {
                return this._keyName;
            }
            /*string? */ set KeyName(value)
            {
                this._keyName = value;
                this._isKeyNameSetExplicitly = true;
            }
            /*bool */ get IsKeyNameSetExplicitly()
            {
                return this._isKeyNameSetExplicitly;
            }
            /*bool */ get IsReference()
            {
                return this._isReference;
            }
            /*bool */ set IsReference(value)
            {
                this._isReference = value;
                this._isReferenceSetExplicitly = true;
            }
            /*bool */ get IsReferenceSetExplicitly()
            {
                return this._isReferenceSetExplicitly;
            }
            /*string? */ get ValueName()
            {
                return this._valueName;
            }
            /*string? */ set ValueName(value)
            {
                this._valueName = value;
                this._isValueNameSetExplicitly = true;
            }
            /*bool */ get IsValueNameSetExplicitly()
            {
                return this._isValueNameSetExplicitly;
            }
            static $h = 167783;
            static $f = 0b10010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":14548993,"p":[{"p":1310721,"g":{"r":0,"d":0,"h":64424677223,"f":1},"s":{"r":0,"d":0,"h":68719644519,"f":1},"n":"Namespace","d":167783,"h":60129709927,"f":1},{"p":262145,"g":{"r":0,"d":0,"h":77309579111,"f":1},"n":"IsNamespaceSetExplicitly","d":167783,"h":73014611815,"f":1},{"p":1310721,"g":{"r":0,"d":0,"h":85899513703,"f":1},"s":{"r":0,"d":0,"h":90194480999,"f":1},"n":"Name","d":167783,"h":81604546407,"f":1},{"p":262145,"g":{"r":0,"d":0,"h":98784415591,"f":1},"n":"IsNameSetExplicitly","d":167783,"h":94489448295,"f":1},{"p":1310721,"g":{"r":0,"d":0,"h":107374350183,"f":1},"s":{"r":0,"d":0,"h":111669317479,"f":1},"n":"ItemName","d":167783,"h":103079382887,"f":1},{"p":262145,"g":{"r":0,"d":0,"h":120259252071,"f":1},"n":"IsItemNameSetExplicitly","d":167783,"h":115964284775,"f":1},{"p":1310721,"g":{"r":0,"d":0,"h":128849186663,"f":1},"s":{"r":0,"d":0,"h":133144153959,"f":1},"n":"KeyName","d":167783,"h":124554219367,"f":1},{"p":262145,"g":{"r":0,"d":0,"h":141734088551,"f":1},"n":"IsKeyNameSetExplicitly","d":167783,"h":137439121255,"f":1},{"p":262145,"g":{"r":0,"d":0,"h":150324023143,"f":1},"s":{"r":0,"d":0,"h":154618990439,"f":1},"n":"IsReference","d":167783,"h":146029055847,"f":1},{"p":262145,"g":{"r":0,"d":0,"h":163208925031,"f":1},"n":"IsReferenceSetExplicitly","d":167783,"h":158913957735,"f":1},{"p":1310721,"g":{"r":0,"d":0,"h":171798859623,"f":1},"s":{"r":0,"d":0,"h":176093826919,"f":1},"n":"ValueName","d":167783,"h":167503892327,"f":1},{"p":262145,"g":{"r":0,"d":0,"h":184683761511,"f":1},"n":"IsValueNameSetExplicitly","d":167783,"h":180388794215,"f":1}],"l":[{"t":1310721,"n":"_name","d":167783,"h":4295135079,"f":2},{"t":1310721,"n":"_ns","d":167783,"h":8590102375,"f":2},{"t":1310721,"n":"_itemName","d":167783,"h":12885069671,"f":2},{"t":1310721,"n":"_keyName","d":167783,"h":17180036967,"f":2},{"t":1310721,"n":"_valueName","d":167783,"h":21475004263,"f":2},{"t":262145,"n":"_isReference","d":167783,"h":25769971559,"f":2},{"t":262145,"n":"_isNameSetExplicitly","d":167783,"h":30064938855,"f":2},{"t":262145,"n":"_isNamespaceSetExplicitly","d":167783,"h":34359906151,"f":2},{"t":262145,"n":"_isReferenceSetExplicitly","d":167783,"h":38654873447,"f":2},{"t":262145,"n":"_isItemNameSetExplicitly","d":167783,"h":42949840743,"f":2},{"t":262145,"n":"_isKeyNameSetExplicitly","d":167783,"h":47244808039,"f":2},{"t":262145,"n":"_isValueNameSetExplicitly","d":167783,"h":51539775335,"f":2}],"c":[{"n":".ctor","o":"$ctor$2","d":167783,"h":55834742631,"f":1}],"h":167783,"a":[{"t":14680065,"c":21489516545,"a":[{"v":12,"t":14614529}],"n":[{"n":"Inherited","v":false,"t":262145},{"n":"AllowMultiple","v":false,"t":262145}]}]}; }
            static get $b() { return $.$spc.System.Attribute; }
            static get $fullName() { return `System.Runtime.Serialization.CollectionDataContractAttribute`; }
        });
        
        $asm.$cls("$srsp.System.Runtime.Serialization.EnumMemberAttribute", ($self) => class EnumMemberAttribute extends $.$spc.System.Attribute
        {
            /*string?*/ _value = null;
            /*bool*/ _isValueSetExplicitly = false;
            $ctor$2()
            {
                super.$ctor$1();
                {
                }
                return this;
            }
            /*string? */ get Value()
            {
                return this._value;
            }
            /*string? */ set Value(value)
            {
                this._value = value;
                this._isValueSetExplicitly = true;
            }
            /*bool */ get IsValueSetExplicitly()
            {
                return this._isValueSetExplicitly;
            }
            static $h = 429927;
            static $f = 0b10010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":14548993,"p":[{"p":1310721,"g":{"r":0,"d":0,"h":21475266407,"f":1},"s":{"r":0,"d":0,"h":25770233703,"f":1},"n":"Value","d":429927,"h":17180299111,"f":1},{"p":262145,"g":{"r":0,"d":0,"h":34360168295,"f":1},"n":"IsValueSetExplicitly","d":429927,"h":30065200999,"f":1}],"l":[{"t":1310721,"n":"_value","d":429927,"h":4295397223,"f":2},{"t":262145,"n":"_isValueSetExplicitly","d":429927,"h":8590364519,"f":2}],"c":[{"n":".ctor","o":"$ctor$2","d":429927,"h":12885331815,"f":1}],"h":429927,"a":[{"t":14680065,"c":21489516545,"a":[{"v":256,"t":14614529}],"n":[{"n":"Inherited","v":false,"t":262145},{"n":"AllowMultiple","v":false,"t":262145}]}]}; }
            static get $b() { return $.$spc.System.Attribute; }
            static get $fullName() { return `System.Runtime.Serialization.EnumMemberAttribute`; }
        });
        
        $asm.$cls("$srsp.System.Runtime.Serialization.DataMemberAttribute", ($self) => class DataMemberAttribute extends $.$spc.System.Attribute
        {
            /*string?*/ _name = null;
            /*bool*/ _isNameSetExplicitly = false;
            /*int*/ _order = -1;
            $ctor$2()
            {
                super.$ctor$1();
                {
                }
                return this;
            }
            /*string? */ get Name()
            {
                return this._name;
            }
            /*string? */ set Name(value)
            {
                this._name = value;
                this._isNameSetExplicitly = true;
            }
            /*bool */ get IsNameSetExplicitly()
            {
                return this._isNameSetExplicitly;
            }
            /*int */ get Order()
            {
                return this._order;
            }
            /*int */ set Order(value)
            {
                if (value < 0)
                {
                    throw new $.$srsp.System.Runtime.Serialization.InvalidDataContractException().$ctor$6($.$srsp.System.SR.OrderCannotBeNegative);
                }
                this._order = value;
            }
            /*bool*/ IsRequired = false;
            /*bool*/ EmitDefaultValue = false;
            //default member initializer
            constructor()
            {
                super();
                this.IsRequired = false;
                this.EmitDefaultValue = true;
            }
            static $h = 364391;
            static $f = 0b10010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":14548993,"p":[{"p":1310721,"g":{"r":0,"d":0,"h":25770168167,"f":1},"s":{"r":0,"d":0,"h":30065135463,"f":1},"n":"Name","d":364391,"h":21475200871,"f":1},{"p":262145,"g":{"r":0,"d":0,"h":38655070055,"f":1},"n":"IsNameSetExplicitly","d":364391,"h":34360102759,"f":1},{"p":655361,"g":{"r":0,"d":0,"h":47245004647,"f":1},"s":{"r":0,"d":0,"h":51539971943,"f":1},"n":"Order","d":364391,"h":42950037351,"f":1},{"p":262145,"g":{"r":0,"d":0,"h":64424873831,"f":1},"s":{"r":0,"d":0,"h":68719841127,"f":1},"n":"IsRequired","d":364391,"h":60129906535,"f":1},{"p":262145,"g":{"r":0,"d":0,"h":81604743015,"f":1},"s":{"r":0,"d":0,"h":85899710311,"f":1},"n":"EmitDefaultValue","d":364391,"h":77309775719,"f":1}],"l":[{"t":1310721,"n":"_name","d":364391,"h":4295331687,"f":2},{"t":262145,"n":"_isNameSetExplicitly","d":364391,"h":8590298983,"f":2},{"t":655361,"n":"_order","d":364391,"h":12885266279,"f":2}],"c":[{"n":".ctor","o":"$ctor$2","d":364391,"h":17180233575,"f":1}],"h":364391,"a":[{"t":14680065,"c":21489516545,"a":[{"v":384,"t":14614529}],"n":[{"n":"Inherited","v":false,"t":262145},{"n":"AllowMultiple","v":false,"t":262145}]}]}; }
            static get $b() { return $.$spc.System.Attribute; }
            static get $fullName() { return `System.Runtime.Serialization.DataMemberAttribute`; }
        });
        
        $asm.$cls("$srsp.System.Runtime.Serialization.DataContractAttribute", ($self) => class DataContractAttribute extends $.$spc.System.Attribute
        {
            /*string?*/ _name = null;
            /*string?*/ _ns = null;
            /*bool*/ _isNameSetExplicitly = false;
            /*bool*/ _isNamespaceSetExplicitly = false;
            /*bool*/ _isReference = false;
            /*bool*/ _isReferenceSetExplicitly = false;
            $ctor$2()
            {
                super.$ctor$1();
                {
                }
                return this;
            }
            /*bool */ get IsReference()
            {
                return this._isReference;
            }
            /*bool */ set IsReference(value)
            {
                this._isReference = value;
                this._isReferenceSetExplicitly = true;
            }
            /*bool */ get IsReferenceSetExplicitly()
            {
                return this._isReferenceSetExplicitly;
            }
            /*string? */ get Namespace()
            {
                return this._ns;
            }
            /*string? */ set Namespace(value)
            {
                this._ns = value;
                this._isNamespaceSetExplicitly = true;
            }
            /*bool */ get IsNamespaceSetExplicitly()
            {
                return this._isNamespaceSetExplicitly;
            }
            /*string? */ get Name()
            {
                return this._name;
            }
            /*string? */ set Name(value)
            {
                this._name = value;
                this._isNameSetExplicitly = true;
            }
            /*bool */ get IsNameSetExplicitly()
            {
                return this._isNameSetExplicitly;
            }
            static $h = 298855;
            static $f = 0b10010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":14548993,"p":[{"p":262145,"g":{"r":0,"d":0,"h":38655004519,"f":1},"s":{"r":0,"d":0,"h":42949971815,"f":1},"n":"IsReference","d":298855,"h":34360037223,"f":1},{"p":262145,"g":{"r":0,"d":0,"h":51539906407,"f":1},"n":"IsReferenceSetExplicitly","d":298855,"h":47244939111,"f":1},{"p":1310721,"g":{"r":0,"d":0,"h":60129840999,"f":1},"s":{"r":0,"d":0,"h":64424808295,"f":1},"n":"Namespace","d":298855,"h":55834873703,"f":1},{"p":262145,"g":{"r":0,"d":0,"h":73014742887,"f":1},"n":"IsNamespaceSetExplicitly","d":298855,"h":68719775591,"f":1},{"p":1310721,"g":{"r":0,"d":0,"h":81604677479,"f":1},"s":{"r":0,"d":0,"h":85899644775,"f":1},"n":"Name","d":298855,"h":77309710183,"f":1},{"p":262145,"g":{"r":0,"d":0,"h":94489579367,"f":1},"n":"IsNameSetExplicitly","d":298855,"h":90194612071,"f":1}],"l":[{"t":1310721,"n":"_name","d":298855,"h":4295266151,"f":2},{"t":1310721,"n":"_ns","d":298855,"h":8590233447,"f":2},{"t":262145,"n":"_isNameSetExplicitly","d":298855,"h":12885200743,"f":2},{"t":262145,"n":"_isNamespaceSetExplicitly","d":298855,"h":17180168039,"f":2},{"t":262145,"n":"_isReference","d":298855,"h":21475135335,"f":2},{"t":262145,"n":"_isReferenceSetExplicitly","d":298855,"h":25770102631,"f":2}],"c":[{"n":".ctor","o":"$ctor$2","d":298855,"h":30065069927,"f":1}],"h":298855,"a":[{"t":14680065,"c":21489516545,"a":[{"v":28,"t":14614529}],"n":[{"n":"Inherited","v":false,"t":262145},{"n":"AllowMultiple","v":false,"t":262145}]}]}; }
            static get $b() { return $.$spc.System.Attribute; }
            static get $fullName() { return `System.Runtime.Serialization.DataContractAttribute`; }
        });
        
        $asm.$cls("$srsp.System.Runtime.Serialization.InvalidDataContractException", ($self) => class InvalidDataContractException extends $.$spc.System.Exception
        {
            $ctor$5()
            {
                super.$ctor$1();
                {
                }
                return this;
            }
            $ctor$6(/*string?*/ message)
            {
                super.$ctor$2(message);
                {
                }
                return this;
            }
            $ctor$7(/*string?*/ message, /*Exception?*/ innerException)
            {
                super.$ctor$3(message, innerException);
                {
                }
                return this;
            }
            $ctor$8(/*SerializationInfo*/ info, /*StreamingContext*/ context)
            {
                super.$ctor$4(info, context);
                {
                }
                return this;
            }
            static $h = 560999;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":47251457,"h":560999}; }
            static get $b() { return $.$spc.System.Exception; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.Runtime.Serialization.ISerializable ]; }
            static get $fullName() { return `System.Runtime.Serialization.InvalidDataContractException`; }
        });
	});
})(window, window.NetJs.$boot(), ...window.NetJs.$require("NetJs.System.Private.CoreLib", "NetJs.System.Memory", "NetJs.System.Private.Uri", "NetJs.System.Runtime"))