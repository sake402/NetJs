
(function ($global, $, $$, $sm, $spu, $sr) {
    "use strict";
    let _;
    
    
    
	$.$asm(
    "NetJs.System.Runtime.Serialization.Primitives", 
    {"h":64361,"f":"System.Runtime.Serialization.Primitives","v":"1.0.35.0","a":[{"t":73596929,"c":4368564225,"a":[{"v":"SIT","t":1310721}]},{"t":73662465,"c":4368629761,"a":[{"v":"Debug","t":1310721}]},{"t":74121217,"c":4369088513,"a":[{"v":"1.0.35.0","t":1310721}]},{"t":74252289,"c":4369219585,"a":[{"v":"1.0.35\u002Beff628fa5ab8bd29ec37e9c13a50148694bea088","t":1310721}]},{"t":75104257,"c":4370071553,"a":[{"v":"NetJs.System.Runtime.Serialization.Primitives","t":1310721}]},{"t":75235329,"c":4370202625,"a":[{"v":"NetJs.System.Runtime.Serialization.Primitives","t":1310721}]},{"t":75366401,"c":4370333697,"a":[{"v":"1.0.35.0","t":1310721}]},{"t":115081217,"c":4410048513,"a":[{"v":"browser1.0","t":1310721}]},{"t":114819073,"c":4409786369,"a":[{"v":"browser1.0","t":1310721}]},{"t":115015681,"c":12999917569,"a":[{"v":".NETCoreApp,Version=v10.0","t":1310721}],"n":[{"n":"FrameworkDisplayName","v":".NET 10.0","t":1310721}]},{"t":96206849,"c":4391174145,"a":[{"v":113311745,"t":142475265}]},{"t":96206849,"c":4391174145,"a":[{"v":113377281,"t":142475265}]},{"t":96206849,"c":4391174145,"a":[{"v":113442817,"t":142475265}]},{"t":96206849,"c":4391174145,"a":[{"v":113508353,"t":142475265}]},{"t":96206849,"c":4391174145,"a":[{"v":113770497,"t":142475265}]},{"t":96206849,"c":4391174145,"a":[{"v":113967105,"t":142475265}]},{"t":96206849,"c":4391174145,"a":[{"v":114032641,"t":142475265}]}],"m":[]},
    function($asm)
	{
        
        
        $asm.$cls("$srsp.System.Runtime.Serialization.ISerializationSurrogateProvider", ($self) => class ISerializationSurrogateProvider
        {
            static $h = 654185;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {"m":[{"r":142475265,"p":[{"n":"type","p":142475265}],"n":"GetSurrogateType","o":"System$Runtime$Serialization$ISerializationSurrogateProvider$GetSurrogateType","d":654185,"h":4295621481,"f":16777473},{"r":131073,"p":[{"n":"obj","p":131073},{"n":"targetType","p":142475265}],"n":"GetObjectToSerialize","o":"System$Runtime$Serialization$ISerializationSurrogateProvider$GetObjectToSerialize","d":654185,"h":8590588777,"f":16777473},{"r":131073,"p":[{"n":"obj","p":131073},{"n":"targetType","p":142475265}],"n":"GetDeserializedObject","o":"System$Runtime$Serialization$ISerializationSurrogateProvider$GetDeserializedObject","d":654185,"h":12885556073,"f":16777473}],"h":654185}; }
            static get $fullName() { return `System.Runtime.Serialization.ISerializationSurrogateProvider`; }
        });
        
        $asm.$cls("$srsp.System.Runtime.Serialization.ISerializationSurrogateProvider2", ($self) => class ISerializationSurrogateProvider2
        {
            static $h = 719721;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {"m":[{"r":131073,"p":[{"n":"memberInfo","p":78249985},{"n":"dataContractType","p":142475265}],"n":"GetCustomDataToExport","o":"System$Runtime$Serialization$ISerializationSurrogateProvider2$GetCustomDataToExport","d":719721,"h":4295687017,"f":16777473},{"r":131073,"p":[{"n":"runtimeType","p":142475265},{"n":"dataContractType","p":142475265}],"n":"GetCustomDataToExport","o":"System$Runtime$Serialization$ISerializationSurrogateProvider2$GetCustomDataToExport$1","d":719721,"h":8590654313,"f":16777473},{"r":65537,"p":[{"n":"customDataTypes","p":$.$$.System.Collections.ObjectModel.Collection$$($.$$.System.Type).$h}],"n":"GetKnownCustomDataTypes","o":"System$Runtime$Serialization$ISerializationSurrogateProvider2$GetKnownCustomDataTypes","d":719721,"h":12885621609,"f":16777473},{"r":142475265,"p":[{"n":"typeName","p":1310721},{"n":"typeNamespace","p":1310721},{"n":"customData","p":131073}],"n":"GetReferencedTypeOnImport","o":"System$Runtime$Serialization$ISerializationSurrogateProvider2$GetReferencedTypeOnImport","d":719721,"h":17180588905,"f":16777473}],"i":[654185],"h":719721}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$srsp.System.Runtime.Serialization.ISerializationSurrogateProvider ]; }
            static get $fullName() { return `System.Runtime.Serialization.ISerializationSurrogateProvider2`; }
        });
        
        $asm.$cls("$srsp.System.SR", ($self) => class SR
        {
            /*global::System.Resources.ResourceManager*/ static s_resourceManager = null;
            /*global::System.Globalization.CultureInfo*/ static resourceCulture = null;
            static /*global::System.Resources.ResourceManager */ get ResourceManager()
            {
                if ($.$$.System.Object.ReferenceEquals($.$srsp.System.SR.s_resourceManager, null))
                {
                    /*global::System.Resources.ResourceManager*/ let temp = new $.$$.System.Resources.ResourceManager().$ctor$3("System.Runtime.Serialization.Primitives", $.$srsp.System.SR.$type.Assembly);
                    $.$srsp.System.SR.s_resourceManager = temp;
                }
                return $.$srsp.System.SR.s_resourceManager;
            }
            static /*global::System.Globalization.CultureInfo */ get Culture()
            {
                return $.$srsp.System.SR.resourceCulture;
            }
            static /*global::System.Globalization.CultureInfo */ set Culture(value)
            {
                $.$srsp.System.SR.resourceCulture = value;
            }
            static /*string */ get OrderCannotBeNegative()
            {
                return "Property 'Order' in DataMemberAttribute attribute cannot be a negative number.";
            }
            /*bool*/ static s_usingResourceKeys = false;
            static /*bool */ GetUsingResourceKeysSwitchValue()
            {
                /*bool*/ let usingResourceKeys;
                return $.$$.System.AppContext.TryGetSwitch("System.Resources.UseSystemResourceKeys", $.$ref(() => usingResourceKeys, ($v) => usingResourceKeys = $v, $.$$.System.Boolean)) ? usingResourceKeys : false;
            }
            static /*bool */ UsingResourceKeys()
            {
                return $.$srsp.System.SR.s_usingResourceKeys;
            }
            static /*string */ GetResourceString$1(/*string*/ resourceKey)
            {
                if ($.$srsp.System.SR.UsingResourceKeys())
                {
                    return resourceKey;
                }
                /*string?*/ let resourceString = null;
                try
                {
                    resourceString = $.$srsp.System.SR.ResourceManager.GetString$1(resourceKey);
                }
                catch($e)
                {
                }
                return resourceString;
            }
            static /*string */ GetResourceString(/*string*/ resourceKey, /*string*/ defaultString)
            {
                /*string*/ let resourceString = $.$srsp.System.SR.GetResourceString$1(resourceKey);
                return $.$$.System.String.op_Equality(resourceKey, resourceString) || $.$$.System.String.op_Equality(resourceString, null) ? defaultString : resourceString;
            }
            static /*string */ Format$6(/*string*/ resourceFormat, /*object?*/ p1)
            {
                if ($.$srsp.System.SR.UsingResourceKeys())
                {
                    return $.$$.System.String.Join$7(", ", $.$$.System.ReadOnlySpan$$($.$$.System.Object).op_Implicit$1([ resourceFormat, p1 ]));
                }
                return $.$$.System.String.Format$9(resourceFormat, p1);
            }
            static /*string */ Format$5(/*string*/ resourceFormat, /*object?*/ p1, /*object?*/ p2)
            {
                if ($.$srsp.System.SR.UsingResourceKeys())
                {
                    return $.$$.System.String.Join$7(", ", $.$$.System.ReadOnlySpan$$($.$$.System.Object).op_Implicit$1([ resourceFormat, p1, p2 ]));
                }
                return $.$$.System.String.Format$8(resourceFormat, p1, p2);
            }
            static /*string */ Format$4(/*string*/ resourceFormat, /*object?*/ p1, /*object?*/ p2, /*object?*/ p3)
            {
                if ($.$srsp.System.SR.UsingResourceKeys())
                {
                    return $.$$.System.String.Join$7(", ", $.$$.System.ReadOnlySpan$$($.$$.System.Object).op_Implicit$1([ resourceFormat, p1, p2, p3 ]));
                }
                return $.$$.System.String.Format$7(resourceFormat, p1, p2, p3);
            }
            static /*string */ Format$7(/*string*/ resourceFormat, /*params object?[]?*/ args)
            {
                if (args !== null)
                {
                    if ($.$srsp.System.SR.UsingResourceKeys())
                    {
                        return resourceFormat + ", " + $.$$.System.String.Join$6(", ", args);
                    }
                    return $.$$.System.String.Format$10(resourceFormat, args);
                }
                return resourceFormat;
            }
            static /*string */ Format$2(/*IFormatProvider?*/ provider, /*string*/ resourceFormat, /*object?*/ p1)
            {
                if ($.$srsp.System.SR.UsingResourceKeys())
                {
                    return $.$$.System.String.Join$7(", ", $.$$.System.ReadOnlySpan$$($.$$.System.Object).op_Implicit$1([ resourceFormat, p1 ]));
                }
                return $.$$.System.String.Format$2(provider, resourceFormat, p1);
            }
            static /*string */ Format$1(/*IFormatProvider?*/ provider, /*string*/ resourceFormat, /*object?*/ p1, /*object?*/ p2)
            {
                if ($.$srsp.System.SR.UsingResourceKeys())
                {
                    return $.$$.System.String.Join$7(", ", $.$$.System.ReadOnlySpan$$($.$$.System.Object).op_Implicit$1([ resourceFormat, p1, p2 ]));
                }
                return $.$$.System.String.Format$1(provider, resourceFormat, p1, p2);
            }
            static /*string */ Format(/*IFormatProvider?*/ provider, /*string*/ resourceFormat, /*object?*/ p1, /*object?*/ p2, /*object?*/ p3)
            {
                if ($.$srsp.System.SR.UsingResourceKeys())
                {
                    return $.$$.System.String.Join$7(", ", $.$$.System.ReadOnlySpan$$($.$$.System.Object).op_Implicit$1([ resourceFormat, p1, p2, p3 ]));
                }
                return $.$$.System.String.Format(provider, resourceFormat, p1, p2, p3);
            }
            static /*string */ Format$3(/*IFormatProvider?*/ provider, /*string*/ resourceFormat, /*params object?[]?*/ args)
            {
                if (args !== null)
                {
                    if ($.$srsp.System.SR.UsingResourceKeys())
                    {
                        return resourceFormat + ", " + $.$$.System.String.Join$6(", ", args);
                    }
                    return $.$$.System.String.Format$3(provider, resourceFormat, args);
                }
                return resourceFormat;
            }
            //Static Initializer
            static $sinit()
            {
                {
                    this.s_usingResourceKeys = $.$srsp.System.SR.GetUsingResourceKeysSwitchValue();
                }
            }
            static $h = 850793;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"h":850793}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `System.SR`; }
        });
        
        $asm.$cls("$srsp.System.Obsoletions", ($self) => class Obsoletions
        {
            /*string*/ static SharedUrlFormat = null;
            /*string*/ static SystemTextEncodingUTF7Message = null;
            /*string*/ static SystemTextEncodingUTF7DiagId = null;
            /*string*/ static PrincipalPermissionAttributeMessage = null;
            /*string*/ static PrincipalPermissionAttributeDiagId = null;
            /*string*/ static CodeAccessSecurityMessage = null;
            /*string*/ static CodeAccessSecurityDiagId = null;
            /*string*/ static ConstrainedExecutionRegionMessage = null;
            /*string*/ static ConstrainedExecutionRegionDiagId = null;
            /*string*/ static GlobalAssemblyCacheMessage = null;
            /*string*/ static GlobalAssemblyCacheDiagId = null;
            /*string*/ static ThreadAbortMessage = null;
            /*string*/ static ThreadResetAbortMessage = null;
            /*string*/ static ThreadAbortDiagId = null;
            /*string*/ static DefaultCryptoAlgorithmsMessage = null;
            /*string*/ static DefaultCryptoAlgorithmsDiagId = null;
            /*string*/ static CreatePdbGeneratorMessage = null;
            /*string*/ static CreatePdbGeneratorDiagId = null;
            /*string*/ static AuthenticationManagerMessage = null;
            /*string*/ static AuthenticationManagerDiagId = null;
            /*string*/ static RemotingApisMessage = null;
            /*string*/ static RemotingApisDiagId = null;
            /*string*/ static BinaryFormatterMessage = null;
            /*string*/ static BinaryFormatterDiagId = null;
            /*string*/ static CodeBaseMessage = null;
            /*string*/ static CodeBaseDiagId = null;
            /*string*/ static EscapeUriStringMessage = null;
            /*string*/ static EscapeUriStringDiagId = null;
            /*string*/ static WebRequestMessage = null;
            /*string*/ static WebRequestDiagId = null;
            /*string*/ static DisablePrivateReflectionAttributeMessage = null;
            /*string*/ static DisablePrivateReflectionAttributeDiagId = null;
            /*string*/ static GetContextInfoMessage = null;
            /*string*/ static GetContextInfoDiagId = null;
            /*string*/ static StrongNameKeyPairMessage = null;
            /*string*/ static StrongNameKeyPairDiagId = null;
            /*string*/ static ReflectionOnlyLoadingMessage = null;
            /*string*/ static ReflectionOnlyLoadingDiagId = null;
            /*string*/ static RuntimeEnvironmentMessage = null;
            /*string*/ static RuntimeEnvironmentDiagId = null;
            /*string*/ static JsonSerializerOptionsIgnoreNullValuesMessage = null;
            /*string*/ static JsonSerializerOptionsIgnoreNullValuesDiagId = null;
            /*string*/ static DerivedCryptographicTypesMessage = null;
            /*string*/ static DerivedCryptographicTypesDiagId = null;
            /*string*/ static RijndaelMessage = null;
            /*string*/ static RijndaelDiagId = null;
            /*string*/ static RNGCryptoServiceProviderMessage = null;
            /*string*/ static RNGCryptoServiceProviderDiagId = null;
            /*string*/ static AppDomainCreateUnloadMessage = null;
            /*string*/ static AppDomainCreateUnloadDiagId = null;
            /*string*/ static SuppressIldasmAttributeMessage = null;
            /*string*/ static SuppressIldasmAttributeDiagId = null;
            /*string*/ static X509CertificateImmutableMessage = null;
            /*string*/ static X509CertificateImmutableDiagId = null;
            /*string*/ static PublicKeyPropertyMessage = null;
            /*string*/ static PublicKeyPropertyDiagId = null;
            /*string*/ static X509CertificatePrivateKeyMessage = null;
            /*string*/ static X509CertificatePrivateKeyDiagId = null;
            /*string*/ static ProduceLegacyHmacValuesMessage = null;
            /*string*/ static ProduceLegacyHmacValuesDiagId = null;
            /*string*/ static UseManagedSha1Message = null;
            /*string*/ static UseManagedSha1DiagId = null;
            /*string*/ static CryptoConfigEncodeOIDMessage = null;
            /*string*/ static CryptoConfigEncodeOIDDiagId = null;
            /*string*/ static CorruptedStateRecoveryMessage = null;
            /*string*/ static CorruptedStateRecoveryDiagId = null;
            /*string*/ static Rfc2898CryptDeriveKeyMessage = null;
            /*string*/ static Rfc2898CryptDeriveKeyDiagId = null;
            /*string*/ static CmsSignerCspParamsCtorMessage = null;
            /*string*/ static CmsSignerCspParamsCtorDiagId = null;
            /*string*/ static SignerInfoCounterSigMessage = null;
            /*string*/ static SignerInfoCounterSigDiagId = null;
            /*string*/ static RegexCompileToAssemblyMessage = null;
            /*string*/ static RegexCompileToAssemblyDiagId = null;
            /*string*/ static AssemblyNameMembersMessage = null;
            /*string*/ static AssemblyNameMembersDiagId = null;
            /*string*/ static SystemDataSerializationFormatBinaryMessage = null;
            /*string*/ static SystemDataSerializationFormatBinaryDiagId = null;
            /*string*/ static TlsVersion10and11Message = null;
            /*string*/ static TlsVersion10and11DiagId = null;
            /*string*/ static EncryptionPolicyMessage = null;
            /*string*/ static EncryptionPolicyDiagId = null;
            /*string*/ static EccXmlExportImportMessage = null;
            /*string*/ static EccXmlExportImportDiagId = null;
            /*string*/ static EcDhPublicKeyBlobMessage = null;
            /*string*/ static EcDhPublicKeyBlobDiagId = null;
            /*string*/ static AssemblyNameCodeBaseMessage = null;
            /*string*/ static AssemblyNameCodeBaseDiagId = null;
            /*string*/ static CryptoStringFactoryMessage = null;
            /*string*/ static CryptoStringFactoryDiagId = null;
            /*string*/ static ControlledExecutionRunMessage = null;
            /*string*/ static ControlledExecutionRunDiagId = null;
            /*string*/ static XmlSecureResolverMessage = null;
            /*string*/ static XmlSecureResolverDiagId = null;
            /*string*/ static RsaEncryptDecryptValueMessage = null;
            /*string*/ static RsaEncryptDecryptDiagId = null;
            /*string*/ static JsonSerializerOptionsAddContextMessage = null;
            /*string*/ static JsonSerializerOptionsAddContextDiagId = null;
            /*string*/ static LegacyFormatterMessage = null;
            /*string*/ static LegacyFormatterDiagId = null;
            /*string*/ static LegacyFormatterImplMessage = null;
            /*string*/ static LegacyFormatterImplDiagId = null;
            /*string*/ static RegexExtensibilityImplMessage = null;
            /*string*/ static RegexExtensibilityDiagId = null;
            /*string*/ static AesGcmTagConstructorMessage = null;
            /*string*/ static AesGcmTagConstructorDiagId = null;
            /*string*/ static ThreadVolatileReadWriteMessage = null;
            /*string*/ static ThreadVolatileReadWriteDiagId = null;
            /*string*/ static ArmIntrinsicPerformsUnsignedOperationMessage = null;
            /*string*/ static ArmIntrinsicPerformsUnsignedOperationDiagId = null;
            /*string*/ static LoadFromHashAlgorithmMessage = null;
            /*string*/ static LoadFromHashAlgorithmDiagId = null;
            /*string*/ static X509CtorCertDataObsoleteMessage = null;
            /*string*/ static X509CtorCertDataObsoleteDiagId = null;
            /*string*/ static TlsCipherAlgorithmEnumsMessage = null;
            /*string*/ static TlsCipherAlgorithmEnumsDiagId = null;
            /*string*/ static SystemEventsEventsThreadShutdownMessage = null;
            /*string*/ static SystemEventsEventsThreadShutdownDiagId = null;
            /*string*/ static Rfc2898DeriveBytesCtorMessage = null;
            /*string*/ static Rfc2898DeriveBytesCtorDiagId = null;
            /*string*/ static QueryableMinByMaxByTSourceObsoleteMessage = null;
            /*string*/ static QueryableMinByMaxByTSourceObsoleteDiagId = null;
            /*string*/ static XsltSettingsEnableScriptMessage = null;
            /*string*/ static XsltSettingsEnableScriptDiagId = null;
            //Static Initializer
            static $sinit()
            {
                {
                    this.SharedUrlFormat = "https://aka.ms/dotnet-warnings/{0}";
                }
                {
                    this.SystemTextEncodingUTF7Message = "The UTF-7 encoding is insecure and should not be used. Consider using UTF-8 instead.";
                }
                {
                    this.SystemTextEncodingUTF7DiagId = "SYSLIB0001";
                }
                {
                    this.PrincipalPermissionAttributeMessage = "PrincipalPermissionAttribute is not honored by the runtime and must not be used.";
                }
                {
                    this.PrincipalPermissionAttributeDiagId = "SYSLIB0002";
                }
                {
                    this.CodeAccessSecurityMessage = "Code Access Security is not supported or honored by the runtime.";
                }
                {
                    this.CodeAccessSecurityDiagId = "SYSLIB0003";
                }
                {
                    this.ConstrainedExecutionRegionMessage = "The Constrained Execution Region (CER) feature is not supported.";
                }
                {
                    this.ConstrainedExecutionRegionDiagId = "SYSLIB0004";
                }
                {
                    this.GlobalAssemblyCacheMessage = "The Global Assembly Cache is not supported.";
                }
                {
                    this.GlobalAssemblyCacheDiagId = "SYSLIB0005";
                }
                {
                    this.ThreadAbortMessage = "Thread.Abort is not supported and throws PlatformNotSupportedException.";
                }
                {
                    this.ThreadResetAbortMessage = "Thread.ResetAbort is not supported and throws PlatformNotSupportedException.";
                }
                {
                    this.ThreadAbortDiagId = "SYSLIB0006";
                }
                {
                    this.DefaultCryptoAlgorithmsMessage = "The default implementation of this cryptography algorithm is not supported.";
                }
                {
                    this.DefaultCryptoAlgorithmsDiagId = "SYSLIB0007";
                }
                {
                    this.CreatePdbGeneratorMessage = "The CreatePdbGenerator API is not supported and throws PlatformNotSupportedException.";
                }
                {
                    this.CreatePdbGeneratorDiagId = "SYSLIB0008";
                }
                {
                    this.AuthenticationManagerMessage = "AuthenticationManager is not supported. Methods will no-op or throw PlatformNotSupportedException.";
                }
                {
                    this.AuthenticationManagerDiagId = "SYSLIB0009";
                }
                {
                    this.RemotingApisMessage = "This Remoting API is not supported and throws PlatformNotSupportedException.";
                }
                {
                    this.RemotingApisDiagId = "SYSLIB0010";
                }
                {
                    this.BinaryFormatterMessage = "BinaryFormatter serialization is obsolete and should not be used. See https://aka.ms/binaryformatter for more information.";
                }
                {
                    this.BinaryFormatterDiagId = "SYSLIB0011";
                }
                {
                    this.CodeBaseMessage = "Assembly.CodeBase and Assembly.EscapedCodeBase are only included for .NET Framework compatibility. Use Assembly.Location instead.";
                }
                {
                    this.CodeBaseDiagId = "SYSLIB0012";
                }
                {
                    this.EscapeUriStringMessage = "Uri.EscapeUriString can corrupt the Uri string in some cases. Consider using Uri.EscapeDataString for query string components instead.";
                }
                {
                    this.EscapeUriStringDiagId = "SYSLIB0013";
                }
                {
                    this.WebRequestMessage = "WebRequest, HttpWebRequest, ServicePoint, and WebClient are obsolete. Use HttpClient instead.";
                }
                {
                    this.WebRequestDiagId = "SYSLIB0014";
                }
                {
                    this.DisablePrivateReflectionAttributeMessage = "DisablePrivateReflectionAttribute has no effect in .NET 6.0+.";
                }
                {
                    this.DisablePrivateReflectionAttributeDiagId = "SYSLIB0015";
                }
                {
                    this.GetContextInfoMessage = "Use the Graphics.GetContextInfo overloads that accept arguments for better performance and fewer allocations.";
                }
                {
                    this.GetContextInfoDiagId = "SYSLIB0016";
                }
                {
                    this.StrongNameKeyPairMessage = "Strong name signing is not supported and throws PlatformNotSupportedException.";
                }
                {
                    this.StrongNameKeyPairDiagId = "SYSLIB0017";
                }
                {
                    this.ReflectionOnlyLoadingMessage = "ReflectionOnly loading is not supported and throws PlatformNotSupportedException.";
                }
                {
                    this.ReflectionOnlyLoadingDiagId = "SYSLIB0018";
                }
                {
                    this.RuntimeEnvironmentMessage = "RuntimeEnvironment members SystemConfigurationFile, GetRuntimeInterfaceAsIntPtr, and GetRuntimeInterfaceAsObject are not supported and throw PlatformNotSupportedException.";
                }
                {
                    this.RuntimeEnvironmentDiagId = "SYSLIB0019";
                }
                {
                    this.JsonSerializerOptionsIgnoreNullValuesMessage = "JsonSerializerOptions.IgnoreNullValues is obsolete. To ignore null values when serializing, set DefaultIgnoreCondition to JsonIgnoreCondition.WhenWritingNull.";
                }
                {
                    this.JsonSerializerOptionsIgnoreNullValuesDiagId = "SYSLIB0020";
                }
                {
                    this.DerivedCryptographicTypesMessage = "Derived cryptographic types are obsolete. Use the Create method on the base type instead.";
                }
                {
                    this.DerivedCryptographicTypesDiagId = "SYSLIB0021";
                }
                {
                    this.RijndaelMessage = "The Rijndael and RijndaelManaged types are obsolete. Use Aes instead.";
                }
                {
                    this.RijndaelDiagId = "SYSLIB0022";
                }
                {
                    this.RNGCryptoServiceProviderMessage = "RNGCryptoServiceProvider is obsolete. To generate a random number, use one of the RandomNumberGenerator static methods instead.";
                }
                {
                    this.RNGCryptoServiceProviderDiagId = "SYSLIB0023";
                }
                {
                    this.AppDomainCreateUnloadMessage = "Creating and unloading AppDomains is not supported and throws an exception.";
                }
                {
                    this.AppDomainCreateUnloadDiagId = "SYSLIB0024";
                }
                {
                    this.SuppressIldasmAttributeMessage = "SuppressIldasmAttribute has no effect in .NET 6.0+.";
                }
                {
                    this.SuppressIldasmAttributeDiagId = "SYSLIB0025";
                }
                {
                    this.X509CertificateImmutableMessage = "X509Certificate and X509Certificate2 are immutable. Use X509CertificateLoader to create a new certificate.";
                }
                {
                    this.X509CertificateImmutableDiagId = "SYSLIB0026";
                }
                {
                    this.PublicKeyPropertyMessage = "PublicKey.Key is obsolete. Use the appropriate method to get the public key, such as GetRSAPublicKey.";
                }
                {
                    this.PublicKeyPropertyDiagId = "SYSLIB0027";
                }
                {
                    this.X509CertificatePrivateKeyMessage = "X509Certificate2.PrivateKey is obsolete. Use the appropriate method to get the private key, such as GetRSAPrivateKey, or use the CopyWithPrivateKey method to create a new instance with a private key.";
                }
                {
                    this.X509CertificatePrivateKeyDiagId = "SYSLIB0028";
                }
                {
                    this.ProduceLegacyHmacValuesMessage = "ProduceLegacyHmacValues is obsolete. Producing legacy HMAC values is not supported.";
                }
                {
                    this.ProduceLegacyHmacValuesDiagId = "SYSLIB0029";
                }
                {
                    this.UseManagedSha1Message = "HMACSHA1 always uses the algorithm implementation provided by the platform. Use a constructor without the useManagedSha1 parameter.";
                }
                {
                    this.UseManagedSha1DiagId = "SYSLIB0030";
                }
                {
                    this.CryptoConfigEncodeOIDMessage = "EncodeOID is obsolete. Use the ASN.1 functionality provided in System.Formats.Asn1.";
                }
                {
                    this.CryptoConfigEncodeOIDDiagId = "SYSLIB0031";
                }
                {
                    this.CorruptedStateRecoveryMessage = "Recovery from corrupted process state exceptions is not supported; HandleProcessCorruptedStateExceptionsAttribute is ignored.";
                }
                {
                    this.CorruptedStateRecoveryDiagId = "SYSLIB0032";
                }
                {
                    this.Rfc2898CryptDeriveKeyMessage = "Rfc2898DeriveBytes.CryptDeriveKey is obsolete and is not supported. Use PasswordDeriveBytes.CryptDeriveKey instead.";
                }
                {
                    this.Rfc2898CryptDeriveKeyDiagId = "SYSLIB0033";
                }
                {
                    this.CmsSignerCspParamsCtorMessage = "CmsSigner(CspParameters) is obsolete and is not supported. Use an alternative constructor instead.";
                }
                {
                    this.CmsSignerCspParamsCtorDiagId = "SYSLIB0034";
                }
                {
                    this.SignerInfoCounterSigMessage = "ComputeCounterSignature without specifying a CmsSigner is obsolete and is not supported. Use the overload that accepts a CmsSigner.";
                }
                {
                    this.SignerInfoCounterSigDiagId = "SYSLIB0035";
                }
                {
                    this.RegexCompileToAssemblyMessage = "Regex.CompileToAssembly is obsolete and not supported. Use the GeneratedRegexAttribute with the regular expression source generator instead.";
                }
                {
                    this.RegexCompileToAssemblyDiagId = "SYSLIB0036";
                }
                {
                    this.AssemblyNameMembersMessage = "AssemblyName members HashAlgorithm, ProcessorArchitecture, and VersionCompatibility are obsolete and not supported.";
                }
                {
                    this.AssemblyNameMembersDiagId = "SYSLIB0037";
                }
                {
                    this.SystemDataSerializationFormatBinaryMessage = "SerializationFormat.Binary is obsolete and should not be used. See https://aka.ms/serializationformat-binary-obsolete for more information.";
                }
                {
                    this.SystemDataSerializationFormatBinaryDiagId = "SYSLIB0038";
                }
                {
                    this.TlsVersion10and11Message = "TLS versions 1.0 and 1.1 have known vulnerabilities and are not recommended. Use a newer TLS version instead, or use SslProtocols.None to defer to OS defaults.";
                }
                {
                    this.TlsVersion10and11DiagId = "SYSLIB0039";
                }
                {
                    this.EncryptionPolicyMessage = "EncryptionPolicy.NoEncryption and AllowEncryption significantly reduce security and should not be used in production code.";
                }
                {
                    this.EncryptionPolicyDiagId = "SYSLIB0040";
                }
                {
                    this.EccXmlExportImportMessage = "ToXmlString and FromXmlString have no implementation for ECC types, and are obsolete. Use a standard import and export format such as ExportSubjectPublicKeyInfo or ImportSubjectPublicKeyInfo for public keys and ExportPkcs8PrivateKey or ImportPkcs8PrivateKey for private keys.";
                }
                {
                    this.EccXmlExportImportDiagId = "SYSLIB0042";
                }
                {
                    this.EcDhPublicKeyBlobMessage = "ECDiffieHellmanPublicKey.ToByteArray() and the associated constructor do not have a consistent and interoperable implementation on all platforms. Use ECDiffieHellmanPublicKey.ExportSubjectPublicKeyInfo() instead.";
                }
                {
                    this.EcDhPublicKeyBlobDiagId = "SYSLIB0043";
                }
                {
                    this.AssemblyNameCodeBaseMessage = "AssemblyName.CodeBase and AssemblyName.EscapedCodeBase are obsolete. Using them for loading an assembly is not supported.";
                }
                {
                    this.AssemblyNameCodeBaseDiagId = "SYSLIB0044";
                }
                {
                    this.CryptoStringFactoryMessage = "Cryptographic factory methods accepting an algorithm name are obsolete. Use the parameterless Create factory method on the algorithm type instead.";
                }
                {
                    this.CryptoStringFactoryDiagId = "SYSLIB0045";
                }
                {
                    this.ControlledExecutionRunMessage = "ControlledExecution.Run method may corrupt the process and should not be used in production code.";
                }
                {
                    this.ControlledExecutionRunDiagId = "SYSLIB0046";
                }
                {
                    this.XmlSecureResolverMessage = "XmlSecureResolver is obsolete. Use XmlResolver.ThrowingResolver instead when attempting to forbid XML external entity resolution.";
                }
                {
                    this.XmlSecureResolverDiagId = "SYSLIB0047";
                }
                {
                    this.RsaEncryptDecryptValueMessage = "RSA.EncryptValue and DecryptValue are not supported and throw NotSupportedException. Use RSA.Encrypt and RSA.Decrypt instead.";
                }
                {
                    this.RsaEncryptDecryptDiagId = "SYSLIB0048";
                }
                {
                    this.JsonSerializerOptionsAddContextMessage = "JsonSerializerOptions.AddContext is obsolete. To register a JsonSerializerContext, use either the TypeInfoResolver or TypeInfoResolverChain properties.";
                }
                {
                    this.JsonSerializerOptionsAddContextDiagId = "SYSLIB0049";
                }
                {
                    this.LegacyFormatterMessage = "Formatter-based serialization is obsolete and should not be used.";
                }
                {
                    this.LegacyFormatterDiagId = "SYSLIB0050";
                }
                {
                    this.LegacyFormatterImplMessage = "This API supports obsolete formatter-based serialization. It should not be called or extended by application code.";
                }
                {
                    this.LegacyFormatterImplDiagId = "SYSLIB0051";
                }
                {
                    this.RegexExtensibilityImplMessage = "This API supports obsolete mechanisms for Regex extensibility. It is not supported.";
                }
                {
                    this.RegexExtensibilityDiagId = "SYSLIB0052";
                }
                {
                    this.AesGcmTagConstructorMessage = "AesGcm should indicate the required tag size for encryption and decryption. Use a constructor that accepts the tag size.";
                }
                {
                    this.AesGcmTagConstructorDiagId = "SYSLIB0053";
                }
                {
                    this.ThreadVolatileReadWriteMessage = "Thread.VolatileRead and Thread.VolatileWrite are obsolete. Use Volatile.Read or Volatile.Write respectively instead.";
                }
                {
                    this.ThreadVolatileReadWriteDiagId = "SYSLIB0054";
                }
                {
                    this.ArmIntrinsicPerformsUnsignedOperationMessage = "The underlying hardware instruction does not perform a signed saturate narrowing operation, and it always returns an unsigned result. Use the unsigned overload instead.";
                }
                {
                    this.ArmIntrinsicPerformsUnsignedOperationDiagId = "SYSLIB0055";
                }
                {
                    this.LoadFromHashAlgorithmMessage = "LoadFrom with a custom AssemblyHashAlgorithm is obsolete. Use overloads without an AssemblyHashAlgorithm.";
                }
                {
                    this.LoadFromHashAlgorithmDiagId = "SYSLIB0056";
                }
                {
                    this.X509CtorCertDataObsoleteMessage = "Loading certificate data through the constructor or Import is obsolete. Use X509CertificateLoader instead to load certificates.";
                }
                {
                    this.X509CtorCertDataObsoleteDiagId = "SYSLIB0057";
                }
                {
                    this.TlsCipherAlgorithmEnumsMessage = "KeyExchangeAlgorithm, KeyExchangeStrength, CipherAlgorithm, CipherStrength, HashAlgorithm and HashStrength properties of SslStream are obsolete. Use NegotiatedCipherSuite instead.";
                }
                {
                    this.TlsCipherAlgorithmEnumsDiagId = "SYSLIB0058";
                }
                {
                    this.SystemEventsEventsThreadShutdownMessage = "SystemEvents.EventsThreadShutdown callbacks are not run before the process exits. Use AppDomain.ProcessExit instead.";
                }
                {
                    this.SystemEventsEventsThreadShutdownDiagId = "SYSLIB0059";
                }
                {
                    this.Rfc2898DeriveBytesCtorMessage = "The constructors on Rfc2898DeriveBytes are obsolete. Use the static Pbkdf2 method instead.";
                }
                {
                    this.Rfc2898DeriveBytesCtorDiagId = "SYSLIB0060";
                }
                {
                    this.QueryableMinByMaxByTSourceObsoleteMessage = "The Queryable MinBy and MaxBy taking an IComparer<TSource> are obsolete. Use the new ones that take an IComparer<TKey>.";
                }
                {
                    this.QueryableMinByMaxByTSourceObsoleteDiagId = "SYSLIB0061";
                }
                {
                    this.XsltSettingsEnableScriptMessage = "XSLT Script blocks are not supported.";
                }
                {
                    this.XsltSettingsEnableScriptDiagId = "SYSLIB0062";
                }
            }
            static $h = 129897;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"l":[{"t":1310721,"n":"SharedUrlFormat","d":129897,"h":4295097193,"f":4194344},{"t":1310721,"n":"SystemTextEncodingUTF7Message","d":129897,"h":8590064489,"f":4194344},{"t":1310721,"n":"SystemTextEncodingUTF7DiagId","d":129897,"h":12885031785,"f":4194344},{"t":1310721,"n":"PrincipalPermissionAttributeMessage","d":129897,"h":17179999081,"f":4194344},{"t":1310721,"n":"PrincipalPermissionAttributeDiagId","d":129897,"h":21474966377,"f":4194344},{"t":1310721,"n":"CodeAccessSecurityMessage","d":129897,"h":25769933673,"f":4194344},{"t":1310721,"n":"CodeAccessSecurityDiagId","d":129897,"h":30064900969,"f":4194344},{"t":1310721,"n":"ConstrainedExecutionRegionMessage","d":129897,"h":34359868265,"f":4194344},{"t":1310721,"n":"ConstrainedExecutionRegionDiagId","d":129897,"h":38654835561,"f":4194344},{"t":1310721,"n":"GlobalAssemblyCacheMessage","d":129897,"h":42949802857,"f":4194344},{"t":1310721,"n":"GlobalAssemblyCacheDiagId","d":129897,"h":47244770153,"f":4194344},{"t":1310721,"n":"ThreadAbortMessage","d":129897,"h":51539737449,"f":4194344},{"t":1310721,"n":"ThreadResetAbortMessage","d":129897,"h":55834704745,"f":4194344},{"t":1310721,"n":"ThreadAbortDiagId","d":129897,"h":60129672041,"f":4194344},{"t":1310721,"n":"DefaultCryptoAlgorithmsMessage","d":129897,"h":64424639337,"f":4194344},{"t":1310721,"n":"DefaultCryptoAlgorithmsDiagId","d":129897,"h":68719606633,"f":4194344},{"t":1310721,"n":"CreatePdbGeneratorMessage","d":129897,"h":73014573929,"f":4194344},{"t":1310721,"n":"CreatePdbGeneratorDiagId","d":129897,"h":77309541225,"f":4194344},{"t":1310721,"n":"AuthenticationManagerMessage","d":129897,"h":81604508521,"f":4194344},{"t":1310721,"n":"AuthenticationManagerDiagId","d":129897,"h":85899475817,"f":4194344},{"t":1310721,"n":"RemotingApisMessage","d":129897,"h":90194443113,"f":4194344},{"t":1310721,"n":"RemotingApisDiagId","d":129897,"h":94489410409,"f":4194344},{"t":1310721,"n":"BinaryFormatterMessage","d":129897,"h":98784377705,"f":4194344},{"t":1310721,"n":"BinaryFormatterDiagId","d":129897,"h":103079345001,"f":4194344},{"t":1310721,"n":"CodeBaseMessage","d":129897,"h":107374312297,"f":4194344},{"t":1310721,"n":"CodeBaseDiagId","d":129897,"h":111669279593,"f":4194344},{"t":1310721,"n":"EscapeUriStringMessage","d":129897,"h":115964246889,"f":4194344},{"t":1310721,"n":"EscapeUriStringDiagId","d":129897,"h":120259214185,"f":4194344},{"t":1310721,"n":"WebRequestMessage","d":129897,"h":124554181481,"f":4194344},{"t":1310721,"n":"WebRequestDiagId","d":129897,"h":128849148777,"f":4194344},{"t":1310721,"n":"DisablePrivateReflectionAttributeMessage","d":129897,"h":133144116073,"f":4194344},{"t":1310721,"n":"DisablePrivateReflectionAttributeDiagId","d":129897,"h":137439083369,"f":4194344},{"t":1310721,"n":"GetContextInfoMessage","d":129897,"h":141734050665,"f":4194344},{"t":1310721,"n":"GetContextInfoDiagId","d":129897,"h":146029017961,"f":4194344},{"t":1310721,"n":"StrongNameKeyPairMessage","d":129897,"h":150323985257,"f":4194344},{"t":1310721,"n":"StrongNameKeyPairDiagId","d":129897,"h":154618952553,"f":4194344},{"t":1310721,"n":"ReflectionOnlyLoadingMessage","d":129897,"h":158913919849,"f":4194344},{"t":1310721,"n":"ReflectionOnlyLoadingDiagId","d":129897,"h":163208887145,"f":4194344},{"t":1310721,"n":"RuntimeEnvironmentMessage","d":129897,"h":167503854441,"f":4194344},{"t":1310721,"n":"RuntimeEnvironmentDiagId","d":129897,"h":171798821737,"f":4194344},{"t":1310721,"n":"JsonSerializerOptionsIgnoreNullValuesMessage","d":129897,"h":176093789033,"f":4194344},{"t":1310721,"n":"JsonSerializerOptionsIgnoreNullValuesDiagId","d":129897,"h":180388756329,"f":4194344},{"t":1310721,"n":"DerivedCryptographicTypesMessage","d":129897,"h":184683723625,"f":4194344},{"t":1310721,"n":"DerivedCryptographicTypesDiagId","d":129897,"h":188978690921,"f":4194344},{"t":1310721,"n":"RijndaelMessage","d":129897,"h":193273658217,"f":4194344},{"t":1310721,"n":"RijndaelDiagId","d":129897,"h":197568625513,"f":4194344},{"t":1310721,"n":"RNGCryptoServiceProviderMessage","d":129897,"h":201863592809,"f":4194344},{"t":1310721,"n":"RNGCryptoServiceProviderDiagId","d":129897,"h":206158560105,"f":4194344},{"t":1310721,"n":"AppDomainCreateUnloadMessage","d":129897,"h":210453527401,"f":4194344},{"t":1310721,"n":"AppDomainCreateUnloadDiagId","d":129897,"h":214748494697,"f":4194344},{"t":1310721,"n":"SuppressIldasmAttributeMessage","d":129897,"h":219043461993,"f":4194344},{"t":1310721,"n":"SuppressIldasmAttributeDiagId","d":129897,"h":223338429289,"f":4194344},{"t":1310721,"n":"X509CertificateImmutableMessage","d":129897,"h":227633396585,"f":4194344},{"t":1310721,"n":"X509CertificateImmutableDiagId","d":129897,"h":231928363881,"f":4194344},{"t":1310721,"n":"PublicKeyPropertyMessage","d":129897,"h":236223331177,"f":4194344},{"t":1310721,"n":"PublicKeyPropertyDiagId","d":129897,"h":240518298473,"f":4194344},{"t":1310721,"n":"X509CertificatePrivateKeyMessage","d":129897,"h":244813265769,"f":4194344},{"t":1310721,"n":"X509CertificatePrivateKeyDiagId","d":129897,"h":249108233065,"f":4194344},{"t":1310721,"n":"ProduceLegacyHmacValuesMessage","d":129897,"h":253403200361,"f":4194344},{"t":1310721,"n":"ProduceLegacyHmacValuesDiagId","d":129897,"h":257698167657,"f":4194344},{"t":1310721,"n":"UseManagedSha1Message","d":129897,"h":261993134953,"f":4194344},{"t":1310721,"n":"UseManagedSha1DiagId","d":129897,"h":266288102249,"f":4194344},{"t":1310721,"n":"CryptoConfigEncodeOIDMessage","d":129897,"h":270583069545,"f":4194344},{"t":1310721,"n":"CryptoConfigEncodeOIDDiagId","d":129897,"h":274878036841,"f":4194344},{"t":1310721,"n":"CorruptedStateRecoveryMessage","d":129897,"h":279173004137,"f":4194344},{"t":1310721,"n":"CorruptedStateRecoveryDiagId","d":129897,"h":283467971433,"f":4194344},{"t":1310721,"n":"Rfc2898CryptDeriveKeyMessage","d":129897,"h":287762938729,"f":4194344},{"t":1310721,"n":"Rfc2898CryptDeriveKeyDiagId","d":129897,"h":292057906025,"f":4194344},{"t":1310721,"n":"CmsSignerCspParamsCtorMessage","d":129897,"h":296352873321,"f":4194344},{"t":1310721,"n":"CmsSignerCspParamsCtorDiagId","d":129897,"h":300647840617,"f":4194344},{"t":1310721,"n":"SignerInfoCounterSigMessage","d":129897,"h":304942807913,"f":4194344},{"t":1310721,"n":"SignerInfoCounterSigDiagId","d":129897,"h":309237775209,"f":4194344},{"t":1310721,"n":"RegexCompileToAssemblyMessage","d":129897,"h":313532742505,"f":4194344},{"t":1310721,"n":"RegexCompileToAssemblyDiagId","d":129897,"h":317827709801,"f":4194344},{"t":1310721,"n":"AssemblyNameMembersMessage","d":129897,"h":322122677097,"f":4194344},{"t":1310721,"n":"AssemblyNameMembersDiagId","d":129897,"h":326417644393,"f":4194344},{"t":1310721,"n":"SystemDataSerializationFormatBinaryMessage","d":129897,"h":330712611689,"f":4194344},{"t":1310721,"n":"SystemDataSerializationFormatBinaryDiagId","d":129897,"h":335007578985,"f":4194344},{"t":1310721,"n":"TlsVersion10and11Message","d":129897,"h":339302546281,"f":4194344},{"t":1310721,"n":"TlsVersion10and11DiagId","d":129897,"h":343597513577,"f":4194344},{"t":1310721,"n":"EncryptionPolicyMessage","d":129897,"h":347892480873,"f":4194344},{"t":1310721,"n":"EncryptionPolicyDiagId","d":129897,"h":352187448169,"f":4194344},{"t":1310721,"n":"EccXmlExportImportMessage","d":129897,"h":356482415465,"f":4194344},{"t":1310721,"n":"EccXmlExportImportDiagId","d":129897,"h":360777382761,"f":4194344},{"t":1310721,"n":"EcDhPublicKeyBlobMessage","d":129897,"h":365072350057,"f":4194344},{"t":1310721,"n":"EcDhPublicKeyBlobDiagId","d":129897,"h":369367317353,"f":4194344},{"t":1310721,"n":"AssemblyNameCodeBaseMessage","d":129897,"h":373662284649,"f":4194344},{"t":1310721,"n":"AssemblyNameCodeBaseDiagId","d":129897,"h":377957251945,"f":4194344},{"t":1310721,"n":"CryptoStringFactoryMessage","d":129897,"h":382252219241,"f":4194344},{"t":1310721,"n":"CryptoStringFactoryDiagId","d":129897,"h":386547186537,"f":4194344},{"t":1310721,"n":"ControlledExecutionRunMessage","d":129897,"h":390842153833,"f":4194344},{"t":1310721,"n":"ControlledExecutionRunDiagId","d":129897,"h":395137121129,"f":4194344},{"t":1310721,"n":"XmlSecureResolverMessage","d":129897,"h":399432088425,"f":4194344},{"t":1310721,"n":"XmlSecureResolverDiagId","d":129897,"h":403727055721,"f":4194344},{"t":1310721,"n":"RsaEncryptDecryptValueMessage","d":129897,"h":408022023017,"f":4194344},{"t":1310721,"n":"RsaEncryptDecryptDiagId","d":129897,"h":412316990313,"f":4194344},{"t":1310721,"n":"JsonSerializerOptionsAddContextMessage","d":129897,"h":416611957609,"f":4194344},{"t":1310721,"n":"JsonSerializerOptionsAddContextDiagId","d":129897,"h":420906924905,"f":4194344},{"t":1310721,"n":"LegacyFormatterMessage","d":129897,"h":425201892201,"f":4194344},{"t":1310721,"n":"LegacyFormatterDiagId","d":129897,"h":429496859497,"f":4194344},{"t":1310721,"n":"LegacyFormatterImplMessage","d":129897,"h":433791826793,"f":4194344},{"t":1310721,"n":"LegacyFormatterImplDiagId","d":129897,"h":438086794089,"f":4194344},{"t":1310721,"n":"RegexExtensibilityImplMessage","d":129897,"h":442381761385,"f":4194344},{"t":1310721,"n":"RegexExtensibilityDiagId","d":129897,"h":446676728681,"f":4194344},{"t":1310721,"n":"AesGcmTagConstructorMessage","d":129897,"h":450971695977,"f":4194344},{"t":1310721,"n":"AesGcmTagConstructorDiagId","d":129897,"h":455266663273,"f":4194344},{"t":1310721,"n":"ThreadVolatileReadWriteMessage","d":129897,"h":459561630569,"f":4194344},{"t":1310721,"n":"ThreadVolatileReadWriteDiagId","d":129897,"h":463856597865,"f":4194344},{"t":1310721,"n":"ArmIntrinsicPerformsUnsignedOperationMessage","d":129897,"h":468151565161,"f":4194344},{"t":1310721,"n":"ArmIntrinsicPerformsUnsignedOperationDiagId","d":129897,"h":472446532457,"f":4194344},{"t":1310721,"n":"LoadFromHashAlgorithmMessage","d":129897,"h":476741499753,"f":4194344},{"t":1310721,"n":"LoadFromHashAlgorithmDiagId","d":129897,"h":481036467049,"f":4194344},{"t":1310721,"n":"X509CtorCertDataObsoleteMessage","d":129897,"h":485331434345,"f":4194344},{"t":1310721,"n":"X509CtorCertDataObsoleteDiagId","d":129897,"h":489626401641,"f":4194344},{"t":1310721,"n":"TlsCipherAlgorithmEnumsMessage","d":129897,"h":493921368937,"f":4194344},{"t":1310721,"n":"TlsCipherAlgorithmEnumsDiagId","d":129897,"h":498216336233,"f":4194344},{"t":1310721,"n":"SystemEventsEventsThreadShutdownMessage","d":129897,"h":502511303529,"f":4194344},{"t":1310721,"n":"SystemEventsEventsThreadShutdownDiagId","d":129897,"h":506806270825,"f":4194344},{"t":1310721,"n":"Rfc2898DeriveBytesCtorMessage","d":129897,"h":511101238121,"f":4194344},{"t":1310721,"n":"Rfc2898DeriveBytesCtorDiagId","d":129897,"h":515396205417,"f":4194344},{"t":1310721,"n":"QueryableMinByMaxByTSourceObsoleteMessage","d":129897,"h":519691172713,"f":4194344},{"t":1310721,"n":"QueryableMinByMaxByTSourceObsoleteDiagId","d":129897,"h":523986140009,"f":4194344},{"t":1310721,"n":"XsltSettingsEnableScriptMessage","d":129897,"h":528281107305,"f":4194344},{"t":1310721,"n":"XsltSettingsEnableScriptDiagId","d":129897,"h":532576074601,"f":4194344}],"h":129897}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `System.Obsoletions`; }
        });
        
        $asm.$cls("$srsp.System.Runtime.Serialization.ContractNamespaceAttribute", ($self) => class ContractNamespaceAttribute extends $.$$.System.Attribute
        {
            $ctor$2(/*string*/ contractNamespace)
            {
                super.$ctor$1();
                {
                    this.ContractNamespace = contractNamespace;
                }
                return this;
            }
            /*string?*/ ClrNamespace = null;
            /*string*/ ContractNamespace = null;
            static $h = 260969;
            static $f = 0b10010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":14614529,"p":[{"p":1310721,"g":{"r":0,"d":0,"h":17180130153,"f":50331649},"s":{"r":0,"d":0,"h":21475097449,"f":83886081},"n":"ClrNamespace","d":260969,"h":12885162857,"f":2097153},{"p":1310721,"g":{"r":0,"d":0,"h":34359999337,"f":50331649},"n":"ContractNamespace","d":260969,"h":30065032041,"f":2097153}],"c":[{"p":[{"n":"contractNamespace","p":1310721}],"n":".ctor","o":"$ctor$2","d":260969,"h":4295228265,"f":16777217}],"h":260969,"a":[{"t":14745601,"c":21489582081,"a":[{"v":3,"t":14680065}],"n":[{"n":"Inherited","v":false,"t":262145},{"n":"AllowMultiple","v":true,"t":262145}]}]}; }
            static get $b() { return $.$$.System.Attribute; }
            static get $fullName() { return `System.Runtime.Serialization.ContractNamespaceAttribute`; }
        });
        
        $asm.$cls("$srsp.System.Runtime.Serialization.EnumMemberAttribute", ($self) => class EnumMemberAttribute extends $.$$.System.Attribute
        {
            /*string?*/ _value = null;
            /*bool*/ _isValueSetExplicitly = false;
            $ctor$2()
            {
                super.$ctor$1();
                {
                }
                return this;
            }
            /*string? */ get Value()
            {
                return this._value;
            }
            /*string? */ set Value(value)
            {
                this._value = value;
                this._isValueSetExplicitly = true;
            }
            /*bool */ get IsValueSetExplicitly()
            {
                return this._isValueSetExplicitly;
            }
            static $h = 457577;
            static $f = 0b10010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":14614529,"p":[{"p":1310721,"g":{"r":0,"d":0,"h":21475294057,"f":50331649},"s":{"r":0,"d":0,"h":25770261353,"f":83886081},"n":"Value","d":457577,"h":17180326761,"f":2097153},{"p":262145,"g":{"r":0,"d":0,"h":34360195945,"f":50331649},"n":"IsValueSetExplicitly","d":457577,"h":30065228649,"f":2097153}],"l":[{"t":1310721,"n":"_value","d":457577,"h":4295424873,"f":4194306},{"t":262145,"n":"_isValueSetExplicitly","d":457577,"h":8590392169,"f":4194306}],"c":[{"n":".ctor","o":"$ctor$2","d":457577,"h":12885359465,"f":16777217}],"h":457577,"a":[{"t":14745601,"c":21489582081,"a":[{"v":256,"t":14680065}],"n":[{"n":"Inherited","v":false,"t":262145},{"n":"AllowMultiple","v":false,"t":262145}]}]}; }
            static get $b() { return $.$$.System.Attribute; }
            static get $fullName() { return `System.Runtime.Serialization.EnumMemberAttribute`; }
        });
        
        $asm.$cls("$srsp.System.Runtime.Serialization.DataMemberAttribute", ($self) => class DataMemberAttribute extends $.$$.System.Attribute
        {
            /*string?*/ _name = null;
            /*bool*/ _isNameSetExplicitly = false;
            /*int*/ _order = -1;
            $ctor$2()
            {
                super.$ctor$1();
                {
                }
                return this;
            }
            /*string? */ get Name()
            {
                return this._name;
            }
            /*string? */ set Name(value)
            {
                this._name = value;
                this._isNameSetExplicitly = true;
            }
            /*bool */ get IsNameSetExplicitly()
            {
                return this._isNameSetExplicitly;
            }
            /*int */ get Order()
            {
                return this._order;
            }
            /*int */ set Order(value)
            {
                if (value < 0)
                {
                    throw new $.$srsp.System.Runtime.Serialization.InvalidDataContractException().$ctor$8($.$srsp.System.SR.OrderCannotBeNegative);
                }
                this._order = value;
            }
            /*bool*/ IsRequired = false;
            /*bool*/ EmitDefaultValue = false;
            //default member initializer
            constructor()
            {
                super();
                this.IsRequired = false;
                this.EmitDefaultValue = true;
            }
            static $h = 392041;
            static $f = 0b10010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":14614529,"p":[{"p":1310721,"g":{"r":0,"d":0,"h":25770195817,"f":50331649},"s":{"r":0,"d":0,"h":30065163113,"f":83886081},"n":"Name","d":392041,"h":21475228521,"f":2097153},{"p":262145,"g":{"r":0,"d":0,"h":38655097705,"f":50331649},"n":"IsNameSetExplicitly","d":392041,"h":34360130409,"f":2097153},{"p":655361,"g":{"r":0,"d":0,"h":47245032297,"f":50331649},"s":{"r":0,"d":0,"h":51539999593,"f":83886081},"n":"Order","d":392041,"h":42950065001,"f":2097153},{"p":262145,"g":{"r":0,"d":0,"h":64424901481,"f":50331649},"s":{"r":0,"d":0,"h":68719868777,"f":83886081},"n":"IsRequired","d":392041,"h":60129934185,"f":2097153},{"p":262145,"g":{"r":0,"d":0,"h":81604770665,"f":50331649},"s":{"r":0,"d":0,"h":85899737961,"f":83886081},"n":"EmitDefaultValue","d":392041,"h":77309803369,"f":2097153}],"l":[{"t":1310721,"n":"_name","d":392041,"h":4295359337,"f":4194306},{"t":262145,"n":"_isNameSetExplicitly","d":392041,"h":8590326633,"f":4194306},{"t":655361,"n":"_order","d":392041,"h":12885293929,"f":4194306}],"c":[{"n":".ctor","o":"$ctor$2","d":392041,"h":17180261225,"f":16777217}],"h":392041,"a":[{"t":14745601,"c":21489582081,"a":[{"v":384,"t":14680065}],"n":[{"n":"Inherited","v":false,"t":262145},{"n":"AllowMultiple","v":false,"t":262145}]}]}; }
            static get $b() { return $.$$.System.Attribute; }
            static get $fullName() { return `System.Runtime.Serialization.DataMemberAttribute`; }
        });
        
        $asm.$cls("$srsp.System.Runtime.Serialization.DataContractAttribute", ($self) => class DataContractAttribute extends $.$$.System.Attribute
        {
            /*string?*/ _name = null;
            /*string?*/ _ns = null;
            /*bool*/ _isNameSetExplicitly = false;
            /*bool*/ _isNamespaceSetExplicitly = false;
            /*bool*/ _isReference = false;
            /*bool*/ _isReferenceSetExplicitly = false;
            $ctor$2()
            {
                super.$ctor$1();
                {
                }
                return this;
            }
            /*bool */ get IsReference()
            {
                return this._isReference;
            }
            /*bool */ set IsReference(value)
            {
                this._isReference = value;
                this._isReferenceSetExplicitly = true;
            }
            /*bool */ get IsReferenceSetExplicitly()
            {
                return this._isReferenceSetExplicitly;
            }
            /*string? */ get Namespace()
            {
                return this._ns;
            }
            /*string? */ set Namespace(value)
            {
                this._ns = value;
                this._isNamespaceSetExplicitly = true;
            }
            /*bool */ get IsNamespaceSetExplicitly()
            {
                return this._isNamespaceSetExplicitly;
            }
            /*string? */ get Name()
            {
                return this._name;
            }
            /*string? */ set Name(value)
            {
                this._name = value;
                this._isNameSetExplicitly = true;
            }
            /*bool */ get IsNameSetExplicitly()
            {
                return this._isNameSetExplicitly;
            }
            static $h = 326505;
            static $f = 0b10010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":14614529,"p":[{"p":262145,"g":{"r":0,"d":0,"h":38655032169,"f":50331649},"s":{"r":0,"d":0,"h":42949999465,"f":83886081},"n":"IsReference","d":326505,"h":34360064873,"f":2097153},{"p":262145,"g":{"r":0,"d":0,"h":51539934057,"f":50331649},"n":"IsReferenceSetExplicitly","d":326505,"h":47244966761,"f":2097153},{"p":1310721,"g":{"r":0,"d":0,"h":60129868649,"f":50331649},"s":{"r":0,"d":0,"h":64424835945,"f":83886081},"n":"Namespace","d":326505,"h":55834901353,"f":2097153},{"p":262145,"g":{"r":0,"d":0,"h":73014770537,"f":50331649},"n":"IsNamespaceSetExplicitly","d":326505,"h":68719803241,"f":2097153},{"p":1310721,"g":{"r":0,"d":0,"h":81604705129,"f":50331649},"s":{"r":0,"d":0,"h":85899672425,"f":83886081},"n":"Name","d":326505,"h":77309737833,"f":2097153},{"p":262145,"g":{"r":0,"d":0,"h":94489607017,"f":50331649},"n":"IsNameSetExplicitly","d":326505,"h":90194639721,"f":2097153}],"l":[{"t":1310721,"n":"_name","d":326505,"h":4295293801,"f":4194306},{"t":1310721,"n":"_ns","d":326505,"h":8590261097,"f":4194306},{"t":262145,"n":"_isNameSetExplicitly","d":326505,"h":12885228393,"f":4194306},{"t":262145,"n":"_isNamespaceSetExplicitly","d":326505,"h":17180195689,"f":4194306},{"t":262145,"n":"_isReference","d":326505,"h":21475162985,"f":4194306},{"t":262145,"n":"_isReferenceSetExplicitly","d":326505,"h":25770130281,"f":4194306}],"c":[{"n":".ctor","o":"$ctor$2","d":326505,"h":30065097577,"f":16777217}],"h":326505,"a":[{"t":14745601,"c":21489582081,"a":[{"v":28,"t":14680065}],"n":[{"n":"Inherited","v":false,"t":262145},{"n":"AllowMultiple","v":false,"t":262145}]}]}; }
            static get $b() { return $.$$.System.Attribute; }
            static get $fullName() { return `System.Runtime.Serialization.DataContractAttribute`; }
        });
        
        $asm.$cls("$srsp.System.Runtime.Serialization.IgnoreDataMemberAttribute", ($self) => class IgnoreDataMemberAttribute extends $.$$.System.Attribute
        {
            $ctor$2()
            {
                super.$ctor$1();
                {
                }
                return this;
            }
            static $h = 523113;
            static $f = 0b10010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":14614529,"c":[{"n":".ctor","o":"$ctor$2","d":523113,"h":4295490409,"f":16777217}],"h":523113,"a":[{"t":14745601,"c":21489582081,"a":[{"v":384,"t":14680065}],"n":[{"n":"Inherited","v":false,"t":262145},{"n":"AllowMultiple","v":false,"t":262145}]}]}; }
            static get $b() { return $.$$.System.Attribute; }
            static get $fullName() { return `System.Runtime.Serialization.IgnoreDataMemberAttribute`; }
        });
        
        $asm.$cls("$srsp.System.Runtime.Serialization.KnownTypeAttribute", ($self) => class KnownTypeAttribute extends $.$$.System.Attribute
        {
            $ctor$3(/*Type*/ type)
            {
                super.$ctor$1();
                {
                    this.Type = type;
                }
                return this;
            }
            $ctor$2(/*string*/ methodName)
            {
                super.$ctor$1();
                {
                    this.MethodName = methodName;
                }
                return this;
            }
            /*string?*/ MethodName = null;
            /*Type?*/ Type = null;
            static $h = 785257;
            static $f = 0b10010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":14614529,"p":[{"p":1310721,"g":{"r":0,"d":0,"h":21475621737,"f":50331649},"n":"MethodName","d":785257,"h":17180654441,"f":2097153},{"p":142475265,"g":{"r":0,"d":0,"h":34360523625,"f":50331649},"n":"Type","d":785257,"h":30065556329,"f":2097153}],"c":[{"p":[{"n":"type","p":142475265}],"n":".ctor","o":"$ctor$3","d":785257,"h":4295752553,"f":16777217},{"p":[{"n":"methodName","p":1310721}],"n":".ctor","o":"$ctor$2","d":785257,"h":8590719849,"f":16777217}],"h":785257,"a":[{"t":14745601,"c":21489582081,"a":[{"v":12,"t":14680065}],"n":[{"n":"Inherited","v":true,"t":262145},{"n":"AllowMultiple","v":true,"t":262145}]}]}; }
            static get $b() { return $.$$.System.Attribute; }
            static get $fullName() { return `System.Runtime.Serialization.KnownTypeAttribute`; }
        });
        
        $asm.$cls("$srsp.System.Runtime.Serialization.CollectionDataContractAttribute", ($self) => class CollectionDataContractAttribute extends $.$$.System.Attribute
        {
            /*string?*/ _name = null;
            /*string?*/ _ns = null;
            /*string?*/ _itemName = null;
            /*string?*/ _keyName = null;
            /*string?*/ _valueName = null;
            /*bool*/ _isReference = false;
            /*bool*/ _isNameSetExplicitly = false;
            /*bool*/ _isNamespaceSetExplicitly = false;
            /*bool*/ _isReferenceSetExplicitly = false;
            /*bool*/ _isItemNameSetExplicitly = false;
            /*bool*/ _isKeyNameSetExplicitly = false;
            /*bool*/ _isValueNameSetExplicitly = false;
            $ctor$2()
            {
                super.$ctor$1();
                {
                }
                return this;
            }
            /*string? */ get Namespace()
            {
                return this._ns;
            }
            /*string? */ set Namespace(value)
            {
                this._ns = value;
                this._isNamespaceSetExplicitly = true;
            }
            /*bool */ get IsNamespaceSetExplicitly()
            {
                return this._isNamespaceSetExplicitly;
            }
            /*string? */ get Name()
            {
                return this._name;
            }
            /*string? */ set Name(value)
            {
                this._name = value;
                this._isNameSetExplicitly = true;
            }
            /*bool */ get IsNameSetExplicitly()
            {
                return this._isNameSetExplicitly;
            }
            /*string? */ get ItemName()
            {
                return this._itemName;
            }
            /*string? */ set ItemName(value)
            {
                this._itemName = value;
                this._isItemNameSetExplicitly = true;
            }
            /*bool */ get IsItemNameSetExplicitly()
            {
                return this._isItemNameSetExplicitly;
            }
            /*string? */ get KeyName()
            {
                return this._keyName;
            }
            /*string? */ set KeyName(value)
            {
                this._keyName = value;
                this._isKeyNameSetExplicitly = true;
            }
            /*bool */ get IsKeyNameSetExplicitly()
            {
                return this._isKeyNameSetExplicitly;
            }
            /*bool */ get IsReference()
            {
                return this._isReference;
            }
            /*bool */ set IsReference(value)
            {
                this._isReference = value;
                this._isReferenceSetExplicitly = true;
            }
            /*bool */ get IsReferenceSetExplicitly()
            {
                return this._isReferenceSetExplicitly;
            }
            /*string? */ get ValueName()
            {
                return this._valueName;
            }
            /*string? */ set ValueName(value)
            {
                this._valueName = value;
                this._isValueNameSetExplicitly = true;
            }
            /*bool */ get IsValueNameSetExplicitly()
            {
                return this._isValueNameSetExplicitly;
            }
            static $h = 195433;
            static $f = 0b10010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":14614529,"p":[{"p":1310721,"g":{"r":0,"d":0,"h":64424704873,"f":50331649},"s":{"r":0,"d":0,"h":68719672169,"f":83886081},"n":"Namespace","d":195433,"h":60129737577,"f":2097153},{"p":262145,"g":{"r":0,"d":0,"h":77309606761,"f":50331649},"n":"IsNamespaceSetExplicitly","d":195433,"h":73014639465,"f":2097153},{"p":1310721,"g":{"r":0,"d":0,"h":85899541353,"f":50331649},"s":{"r":0,"d":0,"h":90194508649,"f":83886081},"n":"Name","d":195433,"h":81604574057,"f":2097153},{"p":262145,"g":{"r":0,"d":0,"h":98784443241,"f":50331649},"n":"IsNameSetExplicitly","d":195433,"h":94489475945,"f":2097153},{"p":1310721,"g":{"r":0,"d":0,"h":107374377833,"f":50331649},"s":{"r":0,"d":0,"h":111669345129,"f":83886081},"n":"ItemName","d":195433,"h":103079410537,"f":2097153},{"p":262145,"g":{"r":0,"d":0,"h":120259279721,"f":50331649},"n":"IsItemNameSetExplicitly","d":195433,"h":115964312425,"f":2097153},{"p":1310721,"g":{"r":0,"d":0,"h":128849214313,"f":50331649},"s":{"r":0,"d":0,"h":133144181609,"f":83886081},"n":"KeyName","d":195433,"h":124554247017,"f":2097153},{"p":262145,"g":{"r":0,"d":0,"h":141734116201,"f":50331649},"n":"IsKeyNameSetExplicitly","d":195433,"h":137439148905,"f":2097153},{"p":262145,"g":{"r":0,"d":0,"h":150324050793,"f":50331649},"s":{"r":0,"d":0,"h":154619018089,"f":83886081},"n":"IsReference","d":195433,"h":146029083497,"f":2097153},{"p":262145,"g":{"r":0,"d":0,"h":163208952681,"f":50331649},"n":"IsReferenceSetExplicitly","d":195433,"h":158913985385,"f":2097153},{"p":1310721,"g":{"r":0,"d":0,"h":171798887273,"f":50331649},"s":{"r":0,"d":0,"h":176093854569,"f":83886081},"n":"ValueName","d":195433,"h":167503919977,"f":2097153},{"p":262145,"g":{"r":0,"d":0,"h":184683789161,"f":50331649},"n":"IsValueNameSetExplicitly","d":195433,"h":180388821865,"f":2097153}],"l":[{"t":1310721,"n":"_name","d":195433,"h":4295162729,"f":4194306},{"t":1310721,"n":"_ns","d":195433,"h":8590130025,"f":4194306},{"t":1310721,"n":"_itemName","d":195433,"h":12885097321,"f":4194306},{"t":1310721,"n":"_keyName","d":195433,"h":17180064617,"f":4194306},{"t":1310721,"n":"_valueName","d":195433,"h":21475031913,"f":4194306},{"t":262145,"n":"_isReference","d":195433,"h":25769999209,"f":4194306},{"t":262145,"n":"_isNameSetExplicitly","d":195433,"h":30064966505,"f":4194306},{"t":262145,"n":"_isNamespaceSetExplicitly","d":195433,"h":34359933801,"f":4194306},{"t":262145,"n":"_isReferenceSetExplicitly","d":195433,"h":38654901097,"f":4194306},{"t":262145,"n":"_isItemNameSetExplicitly","d":195433,"h":42949868393,"f":4194306},{"t":262145,"n":"_isKeyNameSetExplicitly","d":195433,"h":47244835689,"f":4194306},{"t":262145,"n":"_isValueNameSetExplicitly","d":195433,"h":51539802985,"f":4194306}],"c":[{"n":".ctor","o":"$ctor$2","d":195433,"h":55834770281,"f":16777217}],"h":195433,"a":[{"t":14745601,"c":21489582081,"a":[{"v":12,"t":14680065}],"n":[{"n":"Inherited","v":false,"t":262145},{"n":"AllowMultiple","v":false,"t":262145}]}]}; }
            static get $b() { return $.$$.System.Attribute; }
            static get $fullName() { return `System.Runtime.Serialization.CollectionDataContractAttribute`; }
        });
        
        $asm.$cls("$srsp.System.Runtime.Serialization.InvalidDataContractException", ($self) => class InvalidDataContractException extends $.$$.System.Exception
        {
            $ctor$5()
            {
                super.$ctor$1();
                {
                }
                return this;
            }
            $ctor$8(/*string?*/ message)
            {
                super.$ctor$4(message);
                {
                }
                return this;
            }
            $ctor$7(/*string?*/ message, /*Exception?*/ innerException)
            {
                super.$ctor$3(message, innerException);
                {
                }
                return this;
            }
            $ctor$6(/*SerializationInfo*/ info, /*StreamingContext*/ context)
            {
                super.$ctor$2(info, context);
                {
                }
                return this;
            }
            static $h = 588649;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":47251457,"h":588649}; }
            static get $b() { return $.$$.System.Exception; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.System.Runtime.Serialization.ISerializable ]; }
            static get $fullName() { return `System.Runtime.Serialization.InvalidDataContractException`; }
        });
	});
})(window, window.NetJs.$boot(), ...window.NetJs.$require("NetJs.System.Private.CoreLib", "NetJs.System.Memory", "NetJs.System.Private.Uri", "NetJs.System.Runtime"))