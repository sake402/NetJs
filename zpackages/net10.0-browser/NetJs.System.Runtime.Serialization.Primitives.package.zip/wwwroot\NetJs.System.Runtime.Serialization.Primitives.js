
(function ($global, $, $spc, $sm, $spu, $sr) {
    "use strict";
    let _;
    
    
    
	$.$asm(
    "NetJs.System.Runtime.Serialization.Primitives", 
    {"h":58267,"f":"System.Runtime.Serialization.Primitives","v":"1.0.35.0","a":[{"t":96337921,"c":4391305217,"a":[{"v":113442817,"t":142606337}]},{"t":96337921,"c":4391305217,"a":[{"v":113508353,"t":142606337}]},{"t":96337921,"c":4391305217,"a":[{"v":113573889,"t":142606337}]},{"t":96337921,"c":4391305217,"a":[{"v":113639425,"t":142606337}]},{"t":96337921,"c":4391305217,"a":[{"v":113901569,"t":142606337}]},{"t":96337921,"c":4391305217,"a":[{"v":114098177,"t":142606337}]},{"t":96337921,"c":4391305217,"a":[{"v":114163713,"t":142606337}]},{"t":115146753,"c":13000048641,"a":[{"v":".NETCoreApp,Version=v10.0","t":1310721}],"n":[{"n":"FrameworkDisplayName","v":".NET 10.0","t":1310721}]},{"t":73596929,"c":4368564225,"a":[{"v":"SIT","t":1310721}]},{"t":73662465,"c":4368629761,"a":[{"v":"Debug","t":1310721}]},{"t":74121217,"c":4369088513,"a":[{"v":"1.0.35.0","t":1310721}]},{"t":74252289,"c":4369219585,"a":[{"v":"1.0.35\u002Bbeaaf5d41a0179d1ed930cf3efa03ea73d37a2ca","t":1310721}]},{"t":75104257,"c":4370071553,"a":[{"v":"NetJs.System.Runtime.Serialization.Primitives","t":1310721}]},{"t":75235329,"c":4370202625,"a":[{"v":"NetJs.System.Runtime.Serialization.Primitives","t":1310721}]},{"t":75366401,"c":4370333697,"a":[{"v":"1.0.35.0","t":1310721}]},{"t":115212289,"c":4410179585,"a":[{"v":"browser1.0","t":1310721}]},{"t":114950145,"c":4409917441,"a":[{"v":"browser1.0","t":1310721}]}],"m":[]},
    function($asm)
	{
        
        
        $asm.$cls("$srsp.System.Runtime.Serialization.ISerializationSurrogateProvider", ($self) => class ISerializationSurrogateProvider
        {
            static $h = 648091;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {"m":[{"r":142606337,"p":[{"n":"type","p":142606337}],"n":"GetSurrogateType","o":"System$Runtime$Serialization$ISerializationSurrogateProvider$GetSurrogateType","d":648091,"h":4295615387,"f":257},{"r":131073,"p":[{"n":"obj","p":131073},{"n":"targetType","p":142606337}],"n":"GetObjectToSerialize","o":"System$Runtime$Serialization$ISerializationSurrogateProvider$GetObjectToSerialize","d":648091,"h":8590582683,"f":257},{"r":131073,"p":[{"n":"obj","p":131073},{"n":"targetType","p":142606337}],"n":"GetDeserializedObject","o":"System$Runtime$Serialization$ISerializationSurrogateProvider$GetDeserializedObject","d":648091,"h":12885549979,"f":257}],"h":648091}; }
            static get $fullName() { return `System.Runtime.Serialization.ISerializationSurrogateProvider`; }
        });
        
        $asm.$cls("$srsp.System.Runtime.Serialization.ISerializationSurrogateProvider2", ($self) => class ISerializationSurrogateProvider2
        {
            static $h = 713627;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {"m":[{"r":131073,"p":[{"n":"memberInfo","p":78249985},{"n":"dataContractType","p":142606337}],"n":"GetCustomDataToExport","o":"System$Runtime$Serialization$ISerializationSurrogateProvider2$GetCustomDataToExport","d":713627,"h":4295680923,"f":257},{"r":131073,"p":[{"n":"runtimeType","p":142606337},{"n":"dataContractType","p":142606337}],"n":"GetCustomDataToExport","o":"System$Runtime$Serialization$ISerializationSurrogateProvider2$GetCustomDataToExport$1","d":713627,"h":8590648219,"f":257},{"r":65537,"p":[{"n":"customDataTypes","p":$.$spc.System.Collections.ObjectModel.Collection$$($.$spc.System.Type).$h}],"n":"GetKnownCustomDataTypes","o":"System$Runtime$Serialization$ISerializationSurrogateProvider2$GetKnownCustomDataTypes","d":713627,"h":12885615515,"f":257},{"r":142606337,"p":[{"n":"typeName","p":1310721},{"n":"typeNamespace","p":1310721},{"n":"customData","p":131073}],"n":"GetReferencedTypeOnImport","o":"System$Runtime$Serialization$ISerializationSurrogateProvider2$GetReferencedTypeOnImport","d":713627,"h":17180582811,"f":257}],"i":[648091],"h":713627}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$srsp.System.Runtime.Serialization.ISerializationSurrogateProvider ]; }
            static get $fullName() { return `System.Runtime.Serialization.ISerializationSurrogateProvider2`; }
        });
        
        $asm.$cls("$srsp.System.SR", ($self) => class SR
        {
            /*global::System.Resources.ResourceManager*/ static s_resourceManager = null;
            /*global::System.Globalization.CultureInfo*/ static resourceCulture = null;
            static /*global::System.Resources.ResourceManager */ get ResourceManager()
            {
                if ($.$spc.System.Object.ReferenceEquals($.$srsp.System.SR.s_resourceManager, null))
                {
                    /*global::System.Resources.ResourceManager*/ let temp = new $.$spc.System.Resources.ResourceManager().$ctor$3("System.Runtime.Serialization.Primitives", $.$srsp.System.SR.$type.Assembly);
                    $.$srsp.System.SR.s_resourceManager = temp;
                }
                return $.$srsp.System.SR.s_resourceManager;
            }
            static /*global::System.Globalization.CultureInfo */ get Culture()
            {
                return $.$srsp.System.SR.resourceCulture;
            }
            static /*global::System.Globalization.CultureInfo */ set Culture(value)
            {
                $.$srsp.System.SR.resourceCulture = value;
            }
            static /*string */ get OrderCannotBeNegative()
            {
                return "Property 'Order' in DataMemberAttribute attribute cannot be a negative number.";
            }
            /*bool*/ static s_usingResourceKeys = false;
            static /*bool */ GetUsingResourceKeysSwitchValue()
            {
                /*bool*/ let usingResourceKeys;
                return $.$spc.System.AppContext.TryGetSwitch("System.Resources.UseSystemResourceKeys", $.$ref(() => usingResourceKeys, ($v) => usingResourceKeys = $v, $.$spc.System.Boolean)) ? usingResourceKeys : false;
            }
            static /*bool */ UsingResourceKeys()
            {
                return $.$srsp.System.SR.s_usingResourceKeys;
            }
            static /*string */ GetResourceString(/*string*/ resourceKey)
            {
                if ($.$srsp.System.SR.UsingResourceKeys())
                {
                    return resourceKey;
                }
                /*string?*/ let resourceString = null;
                try
                {
                    resourceString = $.$srsp.System.SR.ResourceManager.GetString(resourceKey);
                }
                catch($e)
                {
                }
                return resourceString;
            }
            static /*string */ GetResourceString$1(/*string*/ resourceKey, /*string*/ defaultString)
            {
                /*string*/ let resourceString = $.$srsp.System.SR.GetResourceString(resourceKey);
                return $.$spc.System.String.op_Equality(resourceKey, resourceString) || $.$spc.System.String.op_Equality(resourceString, null) ? defaultString : resourceString;
            }
            static /*string */ Format(/*string*/ resourceFormat, /*object?*/ p1)
            {
                if ($.$srsp.System.SR.UsingResourceKeys())
                {
                    return $.$spc.System.String.Join$10(", ", $.$spc.System.ReadOnlySpan$$($.$spc.System.Object).op_Implicit([ resourceFormat, p1 ]));
                }
                return $.$spc.System.String.Format(resourceFormat, p1);
            }
            static /*string */ Format$1(/*string*/ resourceFormat, /*object?*/ p1, /*object?*/ p2)
            {
                if ($.$srsp.System.SR.UsingResourceKeys())
                {
                    return $.$spc.System.String.Join$10(", ", $.$spc.System.ReadOnlySpan$$($.$spc.System.Object).op_Implicit([ resourceFormat, p1, p2 ]));
                }
                return $.$spc.System.String.Format$1(resourceFormat, p1, p2);
            }
            static /*string */ Format$2(/*string*/ resourceFormat, /*object?*/ p1, /*object?*/ p2, /*object?*/ p3)
            {
                if ($.$srsp.System.SR.UsingResourceKeys())
                {
                    return $.$spc.System.String.Join$10(", ", $.$spc.System.ReadOnlySpan$$($.$spc.System.Object).op_Implicit([ resourceFormat, p1, p2, p3 ]));
                }
                return $.$spc.System.String.Format$2(resourceFormat, p1, p2, p3);
            }
            static /*string */ Format$3(/*string*/ resourceFormat, /*params object?[]?*/ args)
            {
                if (args !== null)
                {
                    if ($.$srsp.System.SR.UsingResourceKeys())
                    {
                        return resourceFormat + ", " + $.$spc.System.String.Join$9(", ", args);
                    }
                    return $.$spc.System.String.Format$3(resourceFormat, args);
                }
                return resourceFormat;
            }
            static /*string */ Format$4(/*IFormatProvider?*/ provider, /*string*/ resourceFormat, /*object?*/ p1)
            {
                if ($.$srsp.System.SR.UsingResourceKeys())
                {
                    return $.$spc.System.String.Join$10(", ", $.$spc.System.ReadOnlySpan$$($.$spc.System.Object).op_Implicit([ resourceFormat, p1 ]));
                }
                return $.$spc.System.String.Format$5(provider, resourceFormat, p1);
            }
            static /*string */ Format$5(/*IFormatProvider?*/ provider, /*string*/ resourceFormat, /*object?*/ p1, /*object?*/ p2)
            {
                if ($.$srsp.System.SR.UsingResourceKeys())
                {
                    return $.$spc.System.String.Join$10(", ", $.$spc.System.ReadOnlySpan$$($.$spc.System.Object).op_Implicit([ resourceFormat, p1, p2 ]));
                }
                return $.$spc.System.String.Format$6(provider, resourceFormat, p1, p2);
            }
            static /*string */ Format$6(/*IFormatProvider?*/ provider, /*string*/ resourceFormat, /*object?*/ p1, /*object?*/ p2, /*object?*/ p3)
            {
                if ($.$srsp.System.SR.UsingResourceKeys())
                {
                    return $.$spc.System.String.Join$10(", ", $.$spc.System.ReadOnlySpan$$($.$spc.System.Object).op_Implicit([ resourceFormat, p1, p2, p3 ]));
                }
                return $.$spc.System.String.Format$7(provider, resourceFormat, p1, p2, p3);
            }
            static /*string */ Format$7(/*IFormatProvider?*/ provider, /*string*/ resourceFormat, /*params object?[]?*/ args)
            {
                if (args !== null)
                {
                    if ($.$srsp.System.SR.UsingResourceKeys())
                    {
                        return resourceFormat + ", " + $.$spc.System.String.Join$9(", ", args);
                    }
                    return $.$spc.System.String.Format$8(provider, resourceFormat, args);
                }
                return resourceFormat;
            }
            //Static Initializer
            static $sinit()
            {
                {
                    this.s_usingResourceKeys = $.$srsp.System.SR.GetUsingResourceKeysSwitchValue();
                }
            }
            static $h = 844699;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"h":844699}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.SR`; }
        });
        
        $asm.$cls("$srsp.System.Obsoletions", ($self) => class Obsoletions
        {
            /*string*/ static SharedUrlFormat = null;
            /*string*/ static SystemTextEncodingUTF7Message = null;
            /*string*/ static SystemTextEncodingUTF7DiagId = null;
            /*string*/ static PrincipalPermissionAttributeMessage = null;
            /*string*/ static PrincipalPermissionAttributeDiagId = null;
            /*string*/ static CodeAccessSecurityMessage = null;
            /*string*/ static CodeAccessSecurityDiagId = null;
            /*string*/ static ConstrainedExecutionRegionMessage = null;
            /*string*/ static ConstrainedExecutionRegionDiagId = null;
            /*string*/ static GlobalAssemblyCacheMessage = null;
            /*string*/ static GlobalAssemblyCacheDiagId = null;
            /*string*/ static ThreadAbortMessage = null;
            /*string*/ static ThreadResetAbortMessage = null;
            /*string*/ static ThreadAbortDiagId = null;
            /*string*/ static DefaultCryptoAlgorithmsMessage = null;
            /*string*/ static DefaultCryptoAlgorithmsDiagId = null;
            /*string*/ static CreatePdbGeneratorMessage = null;
            /*string*/ static CreatePdbGeneratorDiagId = null;
            /*string*/ static AuthenticationManagerMessage = null;
            /*string*/ static AuthenticationManagerDiagId = null;
            /*string*/ static RemotingApisMessage = null;
            /*string*/ static RemotingApisDiagId = null;
            /*string*/ static BinaryFormatterMessage = null;
            /*string*/ static BinaryFormatterDiagId = null;
            /*string*/ static CodeBaseMessage = null;
            /*string*/ static CodeBaseDiagId = null;
            /*string*/ static EscapeUriStringMessage = null;
            /*string*/ static EscapeUriStringDiagId = null;
            /*string*/ static WebRequestMessage = null;
            /*string*/ static WebRequestDiagId = null;
            /*string*/ static DisablePrivateReflectionAttributeMessage = null;
            /*string*/ static DisablePrivateReflectionAttributeDiagId = null;
            /*string*/ static GetContextInfoMessage = null;
            /*string*/ static GetContextInfoDiagId = null;
            /*string*/ static StrongNameKeyPairMessage = null;
            /*string*/ static StrongNameKeyPairDiagId = null;
            /*string*/ static ReflectionOnlyLoadingMessage = null;
            /*string*/ static ReflectionOnlyLoadingDiagId = null;
            /*string*/ static RuntimeEnvironmentMessage = null;
            /*string*/ static RuntimeEnvironmentDiagId = null;
            /*string*/ static JsonSerializerOptionsIgnoreNullValuesMessage = null;
            /*string*/ static JsonSerializerOptionsIgnoreNullValuesDiagId = null;
            /*string*/ static DerivedCryptographicTypesMessage = null;
            /*string*/ static DerivedCryptographicTypesDiagId = null;
            /*string*/ static RijndaelMessage = null;
            /*string*/ static RijndaelDiagId = null;
            /*string*/ static RNGCryptoServiceProviderMessage = null;
            /*string*/ static RNGCryptoServiceProviderDiagId = null;
            /*string*/ static AppDomainCreateUnloadMessage = null;
            /*string*/ static AppDomainCreateUnloadDiagId = null;
            /*string*/ static SuppressIldasmAttributeMessage = null;
            /*string*/ static SuppressIldasmAttributeDiagId = null;
            /*string*/ static X509CertificateImmutableMessage = null;
            /*string*/ static X509CertificateImmutableDiagId = null;
            /*string*/ static PublicKeyPropertyMessage = null;
            /*string*/ static PublicKeyPropertyDiagId = null;
            /*string*/ static X509CertificatePrivateKeyMessage = null;
            /*string*/ static X509CertificatePrivateKeyDiagId = null;
            /*string*/ static ProduceLegacyHmacValuesMessage = null;
            /*string*/ static ProduceLegacyHmacValuesDiagId = null;
            /*string*/ static UseManagedSha1Message = null;
            /*string*/ static UseManagedSha1DiagId = null;
            /*string*/ static CryptoConfigEncodeOIDMessage = null;
            /*string*/ static CryptoConfigEncodeOIDDiagId = null;
            /*string*/ static CorruptedStateRecoveryMessage = null;
            /*string*/ static CorruptedStateRecoveryDiagId = null;
            /*string*/ static Rfc2898CryptDeriveKeyMessage = null;
            /*string*/ static Rfc2898CryptDeriveKeyDiagId = null;
            /*string*/ static CmsSignerCspParamsCtorMessage = null;
            /*string*/ static CmsSignerCspParamsCtorDiagId = null;
            /*string*/ static SignerInfoCounterSigMessage = null;
            /*string*/ static SignerInfoCounterSigDiagId = null;
            /*string*/ static RegexCompileToAssemblyMessage = null;
            /*string*/ static RegexCompileToAssemblyDiagId = null;
            /*string*/ static AssemblyNameMembersMessage = null;
            /*string*/ static AssemblyNameMembersDiagId = null;
            /*string*/ static SystemDataSerializationFormatBinaryMessage = null;
            /*string*/ static SystemDataSerializationFormatBinaryDiagId = null;
            /*string*/ static TlsVersion10and11Message = null;
            /*string*/ static TlsVersion10and11DiagId = null;
            /*string*/ static EncryptionPolicyMessage = null;
            /*string*/ static EncryptionPolicyDiagId = null;
            /*string*/ static EccXmlExportImportMessage = null;
            /*string*/ static EccXmlExportImportDiagId = null;
            /*string*/ static EcDhPublicKeyBlobMessage = null;
            /*string*/ static EcDhPublicKeyBlobDiagId = null;
            /*string*/ static AssemblyNameCodeBaseMessage = null;
            /*string*/ static AssemblyNameCodeBaseDiagId = null;
            /*string*/ static CryptoStringFactoryMessage = null;
            /*string*/ static CryptoStringFactoryDiagId = null;
            /*string*/ static ControlledExecutionRunMessage = null;
            /*string*/ static ControlledExecutionRunDiagId = null;
            /*string*/ static XmlSecureResolverMessage = null;
            /*string*/ static XmlSecureResolverDiagId = null;
            /*string*/ static RsaEncryptDecryptValueMessage = null;
            /*string*/ static RsaEncryptDecryptDiagId = null;
            /*string*/ static JsonSerializerOptionsAddContextMessage = null;
            /*string*/ static JsonSerializerOptionsAddContextDiagId = null;
            /*string*/ static LegacyFormatterMessage = null;
            /*string*/ static LegacyFormatterDiagId = null;
            /*string*/ static LegacyFormatterImplMessage = null;
            /*string*/ static LegacyFormatterImplDiagId = null;
            /*string*/ static RegexExtensibilityImplMessage = null;
            /*string*/ static RegexExtensibilityDiagId = null;
            /*string*/ static AesGcmTagConstructorMessage = null;
            /*string*/ static AesGcmTagConstructorDiagId = null;
            /*string*/ static ThreadVolatileReadWriteMessage = null;
            /*string*/ static ThreadVolatileReadWriteDiagId = null;
            /*string*/ static ArmIntrinsicPerformsUnsignedOperationMessage = null;
            /*string*/ static ArmIntrinsicPerformsUnsignedOperationDiagId = null;
            /*string*/ static LoadFromHashAlgorithmMessage = null;
            /*string*/ static LoadFromHashAlgorithmDiagId = null;
            /*string*/ static X509CtorCertDataObsoleteMessage = null;
            /*string*/ static X509CtorCertDataObsoleteDiagId = null;
            /*string*/ static TlsCipherAlgorithmEnumsMessage = null;
            /*string*/ static TlsCipherAlgorithmEnumsDiagId = null;
            /*string*/ static SystemEventsEventsThreadShutdownMessage = null;
            /*string*/ static SystemEventsEventsThreadShutdownDiagId = null;
            /*string*/ static Rfc2898DeriveBytesCtorMessage = null;
            /*string*/ static Rfc2898DeriveBytesCtorDiagId = null;
            /*string*/ static QueryableMinByMaxByTSourceObsoleteMessage = null;
            /*string*/ static QueryableMinByMaxByTSourceObsoleteDiagId = null;
            /*string*/ static XsltSettingsEnableScriptMessage = null;
            /*string*/ static XsltSettingsEnableScriptDiagId = null;
            //Static Initializer
            static $sinit()
            {
                {
                    this.SharedUrlFormat = "https://aka.ms/dotnet-warnings/{0}";
                }
                {
                    this.SystemTextEncodingUTF7Message = "The UTF-7 encoding is insecure and should not be used. Consider using UTF-8 instead.";
                }
                {
                    this.SystemTextEncodingUTF7DiagId = "SYSLIB0001";
                }
                {
                    this.PrincipalPermissionAttributeMessage = "PrincipalPermissionAttribute is not honored by the runtime and must not be used.";
                }
                {
                    this.PrincipalPermissionAttributeDiagId = "SYSLIB0002";
                }
                {
                    this.CodeAccessSecurityMessage = "Code Access Security is not supported or honored by the runtime.";
                }
                {
                    this.CodeAccessSecurityDiagId = "SYSLIB0003";
                }
                {
                    this.ConstrainedExecutionRegionMessage = "The Constrained Execution Region (CER) feature is not supported.";
                }
                {
                    this.ConstrainedExecutionRegionDiagId = "SYSLIB0004";
                }
                {
                    this.GlobalAssemblyCacheMessage = "The Global Assembly Cache is not supported.";
                }
                {
                    this.GlobalAssemblyCacheDiagId = "SYSLIB0005";
                }
                {
                    this.ThreadAbortMessage = "Thread.Abort is not supported and throws PlatformNotSupportedException.";
                }
                {
                    this.ThreadResetAbortMessage = "Thread.ResetAbort is not supported and throws PlatformNotSupportedException.";
                }
                {
                    this.ThreadAbortDiagId = "SYSLIB0006";
                }
                {
                    this.DefaultCryptoAlgorithmsMessage = "The default implementation of this cryptography algorithm is not supported.";
                }
                {
                    this.DefaultCryptoAlgorithmsDiagId = "SYSLIB0007";
                }
                {
                    this.CreatePdbGeneratorMessage = "The CreatePdbGenerator API is not supported and throws PlatformNotSupportedException.";
                }
                {
                    this.CreatePdbGeneratorDiagId = "SYSLIB0008";
                }
                {
                    this.AuthenticationManagerMessage = "AuthenticationManager is not supported. Methods will no-op or throw PlatformNotSupportedException.";
                }
                {
                    this.AuthenticationManagerDiagId = "SYSLIB0009";
                }
                {
                    this.RemotingApisMessage = "This Remoting API is not supported and throws PlatformNotSupportedException.";
                }
                {
                    this.RemotingApisDiagId = "SYSLIB0010";
                }
                {
                    this.BinaryFormatterMessage = "BinaryFormatter serialization is obsolete and should not be used. See https://aka.ms/binaryformatter for more information.";
                }
                {
                    this.BinaryFormatterDiagId = "SYSLIB0011";
                }
                {
                    this.CodeBaseMessage = "Assembly.CodeBase and Assembly.EscapedCodeBase are only included for .NET Framework compatibility. Use Assembly.Location instead.";
                }
                {
                    this.CodeBaseDiagId = "SYSLIB0012";
                }
                {
                    this.EscapeUriStringMessage = "Uri.EscapeUriString can corrupt the Uri string in some cases. Consider using Uri.EscapeDataString for query string components instead.";
                }
                {
                    this.EscapeUriStringDiagId = "SYSLIB0013";
                }
                {
                    this.WebRequestMessage = "WebRequest, HttpWebRequest, ServicePoint, and WebClient are obsolete. Use HttpClient instead.";
                }
                {
                    this.WebRequestDiagId = "SYSLIB0014";
                }
                {
                    this.DisablePrivateReflectionAttributeMessage = "DisablePrivateReflectionAttribute has no effect in .NET 6.0+.";
                }
                {
                    this.DisablePrivateReflectionAttributeDiagId = "SYSLIB0015";
                }
                {
                    this.GetContextInfoMessage = "Use the Graphics.GetContextInfo overloads that accept arguments for better performance and fewer allocations.";
                }
                {
                    this.GetContextInfoDiagId = "SYSLIB0016";
                }
                {
                    this.StrongNameKeyPairMessage = "Strong name signing is not supported and throws PlatformNotSupportedException.";
                }
                {
                    this.StrongNameKeyPairDiagId = "SYSLIB0017";
                }
                {
                    this.ReflectionOnlyLoadingMessage = "ReflectionOnly loading is not supported and throws PlatformNotSupportedException.";
                }
                {
                    this.ReflectionOnlyLoadingDiagId = "SYSLIB0018";
                }
                {
                    this.RuntimeEnvironmentMessage = "RuntimeEnvironment members SystemConfigurationFile, GetRuntimeInterfaceAsIntPtr, and GetRuntimeInterfaceAsObject are not supported and throw PlatformNotSupportedException.";
                }
                {
                    this.RuntimeEnvironmentDiagId = "SYSLIB0019";
                }
                {
                    this.JsonSerializerOptionsIgnoreNullValuesMessage = "JsonSerializerOptions.IgnoreNullValues is obsolete. To ignore null values when serializing, set DefaultIgnoreCondition to JsonIgnoreCondition.WhenWritingNull.";
                }
                {
                    this.JsonSerializerOptionsIgnoreNullValuesDiagId = "SYSLIB0020";
                }
                {
                    this.DerivedCryptographicTypesMessage = "Derived cryptographic types are obsolete. Use the Create method on the base type instead.";
                }
                {
                    this.DerivedCryptographicTypesDiagId = "SYSLIB0021";
                }
                {
                    this.RijndaelMessage = "The Rijndael and RijndaelManaged types are obsolete. Use Aes instead.";
                }
                {
                    this.RijndaelDiagId = "SYSLIB0022";
                }
                {
                    this.RNGCryptoServiceProviderMessage = "RNGCryptoServiceProvider is obsolete. To generate a random number, use one of the RandomNumberGenerator static methods instead.";
                }
                {
                    this.RNGCryptoServiceProviderDiagId = "SYSLIB0023";
                }
                {
                    this.AppDomainCreateUnloadMessage = "Creating and unloading AppDomains is not supported and throws an exception.";
                }
                {
                    this.AppDomainCreateUnloadDiagId = "SYSLIB0024";
                }
                {
                    this.SuppressIldasmAttributeMessage = "SuppressIldasmAttribute has no effect in .NET 6.0+.";
                }
                {
                    this.SuppressIldasmAttributeDiagId = "SYSLIB0025";
                }
                {
                    this.X509CertificateImmutableMessage = "X509Certificate and X509Certificate2 are immutable. Use X509CertificateLoader to create a new certificate.";
                }
                {
                    this.X509CertificateImmutableDiagId = "SYSLIB0026";
                }
                {
                    this.PublicKeyPropertyMessage = "PublicKey.Key is obsolete. Use the appropriate method to get the public key, such as GetRSAPublicKey.";
                }
                {
                    this.PublicKeyPropertyDiagId = "SYSLIB0027";
                }
                {
                    this.X509CertificatePrivateKeyMessage = "X509Certificate2.PrivateKey is obsolete. Use the appropriate method to get the private key, such as GetRSAPrivateKey, or use the CopyWithPrivateKey method to create a new instance with a private key.";
                }
                {
                    this.X509CertificatePrivateKeyDiagId = "SYSLIB0028";
                }
                {
                    this.ProduceLegacyHmacValuesMessage = "ProduceLegacyHmacValues is obsolete. Producing legacy HMAC values is not supported.";
                }
                {
                    this.ProduceLegacyHmacValuesDiagId = "SYSLIB0029";
                }
                {
                    this.UseManagedSha1Message = "HMACSHA1 always uses the algorithm implementation provided by the platform. Use a constructor without the useManagedSha1 parameter.";
                }
                {
                    this.UseManagedSha1DiagId = "SYSLIB0030";
                }
                {
                    this.CryptoConfigEncodeOIDMessage = "EncodeOID is obsolete. Use the ASN.1 functionality provided in System.Formats.Asn1.";
                }
                {
                    this.CryptoConfigEncodeOIDDiagId = "SYSLIB0031";
                }
                {
                    this.CorruptedStateRecoveryMessage = "Recovery from corrupted process state exceptions is not supported; HandleProcessCorruptedStateExceptionsAttribute is ignored.";
                }
                {
                    this.CorruptedStateRecoveryDiagId = "SYSLIB0032";
                }
                {
                    this.Rfc2898CryptDeriveKeyMessage = "Rfc2898DeriveBytes.CryptDeriveKey is obsolete and is not supported. Use PasswordDeriveBytes.CryptDeriveKey instead.";
                }
                {
                    this.Rfc2898CryptDeriveKeyDiagId = "SYSLIB0033";
                }
                {
                    this.CmsSignerCspParamsCtorMessage = "CmsSigner(CspParameters) is obsolete and is not supported. Use an alternative constructor instead.";
                }
                {
                    this.CmsSignerCspParamsCtorDiagId = "SYSLIB0034";
                }
                {
                    this.SignerInfoCounterSigMessage = "ComputeCounterSignature without specifying a CmsSigner is obsolete and is not supported. Use the overload that accepts a CmsSigner.";
                }
                {
                    this.SignerInfoCounterSigDiagId = "SYSLIB0035";
                }
                {
                    this.RegexCompileToAssemblyMessage = "Regex.CompileToAssembly is obsolete and not supported. Use the GeneratedRegexAttribute with the regular expression source generator instead.";
                }
                {
                    this.RegexCompileToAssemblyDiagId = "SYSLIB0036";
                }
                {
                    this.AssemblyNameMembersMessage = "AssemblyName members HashAlgorithm, ProcessorArchitecture, and VersionCompatibility are obsolete and not supported.";
                }
                {
                    this.AssemblyNameMembersDiagId = "SYSLIB0037";
                }
                {
                    this.SystemDataSerializationFormatBinaryMessage = "SerializationFormat.Binary is obsolete and should not be used. See https://aka.ms/serializationformat-binary-obsolete for more information.";
                }
                {
                    this.SystemDataSerializationFormatBinaryDiagId = "SYSLIB0038";
                }
                {
                    this.TlsVersion10and11Message = "TLS versions 1.0 and 1.1 have known vulnerabilities and are not recommended. Use a newer TLS version instead, or use SslProtocols.None to defer to OS defaults.";
                }
                {
                    this.TlsVersion10and11DiagId = "SYSLIB0039";
                }
                {
                    this.EncryptionPolicyMessage = "EncryptionPolicy.NoEncryption and AllowEncryption significantly reduce security and should not be used in production code.";
                }
                {
                    this.EncryptionPolicyDiagId = "SYSLIB0040";
                }
                {
                    this.EccXmlExportImportMessage = "ToXmlString and FromXmlString have no implementation for ECC types, and are obsolete. Use a standard import and export format such as ExportSubjectPublicKeyInfo or ImportSubjectPublicKeyInfo for public keys and ExportPkcs8PrivateKey or ImportPkcs8PrivateKey for private keys.";
                }
                {
                    this.EccXmlExportImportDiagId = "SYSLIB0042";
                }
                {
                    this.EcDhPublicKeyBlobMessage = "ECDiffieHellmanPublicKey.ToByteArray() and the associated constructor do not have a consistent and interoperable implementation on all platforms. Use ECDiffieHellmanPublicKey.ExportSubjectPublicKeyInfo() instead.";
                }
                {
                    this.EcDhPublicKeyBlobDiagId = "SYSLIB0043";
                }
                {
                    this.AssemblyNameCodeBaseMessage = "AssemblyName.CodeBase and AssemblyName.EscapedCodeBase are obsolete. Using them for loading an assembly is not supported.";
                }
                {
                    this.AssemblyNameCodeBaseDiagId = "SYSLIB0044";
                }
                {
                    this.CryptoStringFactoryMessage = "Cryptographic factory methods accepting an algorithm name are obsolete. Use the parameterless Create factory method on the algorithm type instead.";
                }
                {
                    this.CryptoStringFactoryDiagId = "SYSLIB0045";
                }
                {
                    this.ControlledExecutionRunMessage = "ControlledExecution.Run method may corrupt the process and should not be used in production code.";
                }
                {
                    this.ControlledExecutionRunDiagId = "SYSLIB0046";
                }
                {
                    this.XmlSecureResolverMessage = "XmlSecureResolver is obsolete. Use XmlResolver.ThrowingResolver instead when attempting to forbid XML external entity resolution.";
                }
                {
                    this.XmlSecureResolverDiagId = "SYSLIB0047";
                }
                {
                    this.RsaEncryptDecryptValueMessage = "RSA.EncryptValue and DecryptValue are not supported and throw NotSupportedException. Use RSA.Encrypt and RSA.Decrypt instead.";
                }
                {
                    this.RsaEncryptDecryptDiagId = "SYSLIB0048";
                }
                {
                    this.JsonSerializerOptionsAddContextMessage = "JsonSerializerOptions.AddContext is obsolete. To register a JsonSerializerContext, use either the TypeInfoResolver or TypeInfoResolverChain properties.";
                }
                {
                    this.JsonSerializerOptionsAddContextDiagId = "SYSLIB0049";
                }
                {
                    this.LegacyFormatterMessage = "Formatter-based serialization is obsolete and should not be used.";
                }
                {
                    this.LegacyFormatterDiagId = "SYSLIB0050";
                }
                {
                    this.LegacyFormatterImplMessage = "This API supports obsolete formatter-based serialization. It should not be called or extended by application code.";
                }
                {
                    this.LegacyFormatterImplDiagId = "SYSLIB0051";
                }
                {
                    this.RegexExtensibilityImplMessage = "This API supports obsolete mechanisms for Regex extensibility. It is not supported.";
                }
                {
                    this.RegexExtensibilityDiagId = "SYSLIB0052";
                }
                {
                    this.AesGcmTagConstructorMessage = "AesGcm should indicate the required tag size for encryption and decryption. Use a constructor that accepts the tag size.";
                }
                {
                    this.AesGcmTagConstructorDiagId = "SYSLIB0053";
                }
                {
                    this.ThreadVolatileReadWriteMessage = "Thread.VolatileRead and Thread.VolatileWrite are obsolete. Use Volatile.Read or Volatile.Write respectively instead.";
                }
                {
                    this.ThreadVolatileReadWriteDiagId = "SYSLIB0054";
                }
                {
                    this.ArmIntrinsicPerformsUnsignedOperationMessage = "The underlying hardware instruction does not perform a signed saturate narrowing operation, and it always returns an unsigned result. Use the unsigned overload instead.";
                }
                {
                    this.ArmIntrinsicPerformsUnsignedOperationDiagId = "SYSLIB0055";
                }
                {
                    this.LoadFromHashAlgorithmMessage = "LoadFrom with a custom AssemblyHashAlgorithm is obsolete. Use overloads without an AssemblyHashAlgorithm.";
                }
                {
                    this.LoadFromHashAlgorithmDiagId = "SYSLIB0056";
                }
                {
                    this.X509CtorCertDataObsoleteMessage = "Loading certificate data through the constructor or Import is obsolete. Use X509CertificateLoader instead to load certificates.";
                }
                {
                    this.X509CtorCertDataObsoleteDiagId = "SYSLIB0057";
                }
                {
                    this.TlsCipherAlgorithmEnumsMessage = "KeyExchangeAlgorithm, KeyExchangeStrength, CipherAlgorithm, CipherStrength, HashAlgorithm and HashStrength properties of SslStream are obsolete. Use NegotiatedCipherSuite instead.";
                }
                {
                    this.TlsCipherAlgorithmEnumsDiagId = "SYSLIB0058";
                }
                {
                    this.SystemEventsEventsThreadShutdownMessage = "SystemEvents.EventsThreadShutdown callbacks are not run before the process exits. Use AppDomain.ProcessExit instead.";
                }
                {
                    this.SystemEventsEventsThreadShutdownDiagId = "SYSLIB0059";
                }
                {
                    this.Rfc2898DeriveBytesCtorMessage = "The constructors on Rfc2898DeriveBytes are obsolete. Use the static Pbkdf2 method instead.";
                }
                {
                    this.Rfc2898DeriveBytesCtorDiagId = "SYSLIB0060";
                }
                {
                    this.QueryableMinByMaxByTSourceObsoleteMessage = "The Queryable MinBy and MaxBy taking an IComparer<TSource> are obsolete. Use the new ones that take an IComparer<TKey>.";
                }
                {
                    this.QueryableMinByMaxByTSourceObsoleteDiagId = "SYSLIB0061";
                }
                {
                    this.XsltSettingsEnableScriptMessage = "XSLT Script blocks are not supported.";
                }
                {
                    this.XsltSettingsEnableScriptDiagId = "SYSLIB0062";
                }
            }
            static $h = 123803;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"l":[{"t":1310721,"n":"SharedUrlFormat","d":123803,"h":4295091099,"f":40},{"t":1310721,"n":"SystemTextEncodingUTF7Message","d":123803,"h":8590058395,"f":40},{"t":1310721,"n":"SystemTextEncodingUTF7DiagId","d":123803,"h":12885025691,"f":40},{"t":1310721,"n":"PrincipalPermissionAttributeMessage","d":123803,"h":17179992987,"f":40},{"t":1310721,"n":"PrincipalPermissionAttributeDiagId","d":123803,"h":21474960283,"f":40},{"t":1310721,"n":"CodeAccessSecurityMessage","d":123803,"h":25769927579,"f":40},{"t":1310721,"n":"CodeAccessSecurityDiagId","d":123803,"h":30064894875,"f":40},{"t":1310721,"n":"ConstrainedExecutionRegionMessage","d":123803,"h":34359862171,"f":40},{"t":1310721,"n":"ConstrainedExecutionRegionDiagId","d":123803,"h":38654829467,"f":40},{"t":1310721,"n":"GlobalAssemblyCacheMessage","d":123803,"h":42949796763,"f":40},{"t":1310721,"n":"GlobalAssemblyCacheDiagId","d":123803,"h":47244764059,"f":40},{"t":1310721,"n":"ThreadAbortMessage","d":123803,"h":51539731355,"f":40},{"t":1310721,"n":"ThreadResetAbortMessage","d":123803,"h":55834698651,"f":40},{"t":1310721,"n":"ThreadAbortDiagId","d":123803,"h":60129665947,"f":40},{"t":1310721,"n":"DefaultCryptoAlgorithmsMessage","d":123803,"h":64424633243,"f":40},{"t":1310721,"n":"DefaultCryptoAlgorithmsDiagId","d":123803,"h":68719600539,"f":40},{"t":1310721,"n":"CreatePdbGeneratorMessage","d":123803,"h":73014567835,"f":40},{"t":1310721,"n":"CreatePdbGeneratorDiagId","d":123803,"h":77309535131,"f":40},{"t":1310721,"n":"AuthenticationManagerMessage","d":123803,"h":81604502427,"f":40},{"t":1310721,"n":"AuthenticationManagerDiagId","d":123803,"h":85899469723,"f":40},{"t":1310721,"n":"RemotingApisMessage","d":123803,"h":90194437019,"f":40},{"t":1310721,"n":"RemotingApisDiagId","d":123803,"h":94489404315,"f":40},{"t":1310721,"n":"BinaryFormatterMessage","d":123803,"h":98784371611,"f":40},{"t":1310721,"n":"BinaryFormatterDiagId","d":123803,"h":103079338907,"f":40},{"t":1310721,"n":"CodeBaseMessage","d":123803,"h":107374306203,"f":40},{"t":1310721,"n":"CodeBaseDiagId","d":123803,"h":111669273499,"f":40},{"t":1310721,"n":"EscapeUriStringMessage","d":123803,"h":115964240795,"f":40},{"t":1310721,"n":"EscapeUriStringDiagId","d":123803,"h":120259208091,"f":40},{"t":1310721,"n":"WebRequestMessage","d":123803,"h":124554175387,"f":40},{"t":1310721,"n":"WebRequestDiagId","d":123803,"h":128849142683,"f":40},{"t":1310721,"n":"DisablePrivateReflectionAttributeMessage","d":123803,"h":133144109979,"f":40},{"t":1310721,"n":"DisablePrivateReflectionAttributeDiagId","d":123803,"h":137439077275,"f":40},{"t":1310721,"n":"GetContextInfoMessage","d":123803,"h":141734044571,"f":40},{"t":1310721,"n":"GetContextInfoDiagId","d":123803,"h":146029011867,"f":40},{"t":1310721,"n":"StrongNameKeyPairMessage","d":123803,"h":150323979163,"f":40},{"t":1310721,"n":"StrongNameKeyPairDiagId","d":123803,"h":154618946459,"f":40},{"t":1310721,"n":"ReflectionOnlyLoadingMessage","d":123803,"h":158913913755,"f":40},{"t":1310721,"n":"ReflectionOnlyLoadingDiagId","d":123803,"h":163208881051,"f":40},{"t":1310721,"n":"RuntimeEnvironmentMessage","d":123803,"h":167503848347,"f":40},{"t":1310721,"n":"RuntimeEnvironmentDiagId","d":123803,"h":171798815643,"f":40},{"t":1310721,"n":"JsonSerializerOptionsIgnoreNullValuesMessage","d":123803,"h":176093782939,"f":40},{"t":1310721,"n":"JsonSerializerOptionsIgnoreNullValuesDiagId","d":123803,"h":180388750235,"f":40},{"t":1310721,"n":"DerivedCryptographicTypesMessage","d":123803,"h":184683717531,"f":40},{"t":1310721,"n":"DerivedCryptographicTypesDiagId","d":123803,"h":188978684827,"f":40},{"t":1310721,"n":"RijndaelMessage","d":123803,"h":193273652123,"f":40},{"t":1310721,"n":"RijndaelDiagId","d":123803,"h":197568619419,"f":40},{"t":1310721,"n":"RNGCryptoServiceProviderMessage","d":123803,"h":201863586715,"f":40},{"t":1310721,"n":"RNGCryptoServiceProviderDiagId","d":123803,"h":206158554011,"f":40},{"t":1310721,"n":"AppDomainCreateUnloadMessage","d":123803,"h":210453521307,"f":40},{"t":1310721,"n":"AppDomainCreateUnloadDiagId","d":123803,"h":214748488603,"f":40},{"t":1310721,"n":"SuppressIldasmAttributeMessage","d":123803,"h":219043455899,"f":40},{"t":1310721,"n":"SuppressIldasmAttributeDiagId","d":123803,"h":223338423195,"f":40},{"t":1310721,"n":"X509CertificateImmutableMessage","d":123803,"h":227633390491,"f":40},{"t":1310721,"n":"X509CertificateImmutableDiagId","d":123803,"h":231928357787,"f":40},{"t":1310721,"n":"PublicKeyPropertyMessage","d":123803,"h":236223325083,"f":40},{"t":1310721,"n":"PublicKeyPropertyDiagId","d":123803,"h":240518292379,"f":40},{"t":1310721,"n":"X509CertificatePrivateKeyMessage","d":123803,"h":244813259675,"f":40},{"t":1310721,"n":"X509CertificatePrivateKeyDiagId","d":123803,"h":249108226971,"f":40},{"t":1310721,"n":"ProduceLegacyHmacValuesMessage","d":123803,"h":253403194267,"f":40},{"t":1310721,"n":"ProduceLegacyHmacValuesDiagId","d":123803,"h":257698161563,"f":40},{"t":1310721,"n":"UseManagedSha1Message","d":123803,"h":261993128859,"f":40},{"t":1310721,"n":"UseManagedSha1DiagId","d":123803,"h":266288096155,"f":40},{"t":1310721,"n":"CryptoConfigEncodeOIDMessage","d":123803,"h":270583063451,"f":40},{"t":1310721,"n":"CryptoConfigEncodeOIDDiagId","d":123803,"h":274878030747,"f":40},{"t":1310721,"n":"CorruptedStateRecoveryMessage","d":123803,"h":279172998043,"f":40},{"t":1310721,"n":"CorruptedStateRecoveryDiagId","d":123803,"h":283467965339,"f":40},{"t":1310721,"n":"Rfc2898CryptDeriveKeyMessage","d":123803,"h":287762932635,"f":40},{"t":1310721,"n":"Rfc2898CryptDeriveKeyDiagId","d":123803,"h":292057899931,"f":40},{"t":1310721,"n":"CmsSignerCspParamsCtorMessage","d":123803,"h":296352867227,"f":40},{"t":1310721,"n":"CmsSignerCspParamsCtorDiagId","d":123803,"h":300647834523,"f":40},{"t":1310721,"n":"SignerInfoCounterSigMessage","d":123803,"h":304942801819,"f":40},{"t":1310721,"n":"SignerInfoCounterSigDiagId","d":123803,"h":309237769115,"f":40},{"t":1310721,"n":"RegexCompileToAssemblyMessage","d":123803,"h":313532736411,"f":40},{"t":1310721,"n":"RegexCompileToAssemblyDiagId","d":123803,"h":317827703707,"f":40},{"t":1310721,"n":"AssemblyNameMembersMessage","d":123803,"h":322122671003,"f":40},{"t":1310721,"n":"AssemblyNameMembersDiagId","d":123803,"h":326417638299,"f":40},{"t":1310721,"n":"SystemDataSerializationFormatBinaryMessage","d":123803,"h":330712605595,"f":40},{"t":1310721,"n":"SystemDataSerializationFormatBinaryDiagId","d":123803,"h":335007572891,"f":40},{"t":1310721,"n":"TlsVersion10and11Message","d":123803,"h":339302540187,"f":40},{"t":1310721,"n":"TlsVersion10and11DiagId","d":123803,"h":343597507483,"f":40},{"t":1310721,"n":"EncryptionPolicyMessage","d":123803,"h":347892474779,"f":40},{"t":1310721,"n":"EncryptionPolicyDiagId","d":123803,"h":352187442075,"f":40},{"t":1310721,"n":"EccXmlExportImportMessage","d":123803,"h":356482409371,"f":40},{"t":1310721,"n":"EccXmlExportImportDiagId","d":123803,"h":360777376667,"f":40},{"t":1310721,"n":"EcDhPublicKeyBlobMessage","d":123803,"h":365072343963,"f":40},{"t":1310721,"n":"EcDhPublicKeyBlobDiagId","d":123803,"h":369367311259,"f":40},{"t":1310721,"n":"AssemblyNameCodeBaseMessage","d":123803,"h":373662278555,"f":40},{"t":1310721,"n":"AssemblyNameCodeBaseDiagId","d":123803,"h":377957245851,"f":40},{"t":1310721,"n":"CryptoStringFactoryMessage","d":123803,"h":382252213147,"f":40},{"t":1310721,"n":"CryptoStringFactoryDiagId","d":123803,"h":386547180443,"f":40},{"t":1310721,"n":"ControlledExecutionRunMessage","d":123803,"h":390842147739,"f":40},{"t":1310721,"n":"ControlledExecutionRunDiagId","d":123803,"h":395137115035,"f":40},{"t":1310721,"n":"XmlSecureResolverMessage","d":123803,"h":399432082331,"f":40},{"t":1310721,"n":"XmlSecureResolverDiagId","d":123803,"h":403727049627,"f":40},{"t":1310721,"n":"RsaEncryptDecryptValueMessage","d":123803,"h":408022016923,"f":40},{"t":1310721,"n":"RsaEncryptDecryptDiagId","d":123803,"h":412316984219,"f":40},{"t":1310721,"n":"JsonSerializerOptionsAddContextMessage","d":123803,"h":416611951515,"f":40},{"t":1310721,"n":"JsonSerializerOptionsAddContextDiagId","d":123803,"h":420906918811,"f":40},{"t":1310721,"n":"LegacyFormatterMessage","d":123803,"h":425201886107,"f":40},{"t":1310721,"n":"LegacyFormatterDiagId","d":123803,"h":429496853403,"f":40},{"t":1310721,"n":"LegacyFormatterImplMessage","d":123803,"h":433791820699,"f":40},{"t":1310721,"n":"LegacyFormatterImplDiagId","d":123803,"h":438086787995,"f":40},{"t":1310721,"n":"RegexExtensibilityImplMessage","d":123803,"h":442381755291,"f":40},{"t":1310721,"n":"RegexExtensibilityDiagId","d":123803,"h":446676722587,"f":40},{"t":1310721,"n":"AesGcmTagConstructorMessage","d":123803,"h":450971689883,"f":40},{"t":1310721,"n":"AesGcmTagConstructorDiagId","d":123803,"h":455266657179,"f":40},{"t":1310721,"n":"ThreadVolatileReadWriteMessage","d":123803,"h":459561624475,"f":40},{"t":1310721,"n":"ThreadVolatileReadWriteDiagId","d":123803,"h":463856591771,"f":40},{"t":1310721,"n":"ArmIntrinsicPerformsUnsignedOperationMessage","d":123803,"h":468151559067,"f":40},{"t":1310721,"n":"ArmIntrinsicPerformsUnsignedOperationDiagId","d":123803,"h":472446526363,"f":40},{"t":1310721,"n":"LoadFromHashAlgorithmMessage","d":123803,"h":476741493659,"f":40},{"t":1310721,"n":"LoadFromHashAlgorithmDiagId","d":123803,"h":481036460955,"f":40},{"t":1310721,"n":"X509CtorCertDataObsoleteMessage","d":123803,"h":485331428251,"f":40},{"t":1310721,"n":"X509CtorCertDataObsoleteDiagId","d":123803,"h":489626395547,"f":40},{"t":1310721,"n":"TlsCipherAlgorithmEnumsMessage","d":123803,"h":493921362843,"f":40},{"t":1310721,"n":"TlsCipherAlgorithmEnumsDiagId","d":123803,"h":498216330139,"f":40},{"t":1310721,"n":"SystemEventsEventsThreadShutdownMessage","d":123803,"h":502511297435,"f":40},{"t":1310721,"n":"SystemEventsEventsThreadShutdownDiagId","d":123803,"h":506806264731,"f":40},{"t":1310721,"n":"Rfc2898DeriveBytesCtorMessage","d":123803,"h":511101232027,"f":40},{"t":1310721,"n":"Rfc2898DeriveBytesCtorDiagId","d":123803,"h":515396199323,"f":40},{"t":1310721,"n":"QueryableMinByMaxByTSourceObsoleteMessage","d":123803,"h":519691166619,"f":40},{"t":1310721,"n":"QueryableMinByMaxByTSourceObsoleteDiagId","d":123803,"h":523986133915,"f":40},{"t":1310721,"n":"XsltSettingsEnableScriptMessage","d":123803,"h":528281101211,"f":40},{"t":1310721,"n":"XsltSettingsEnableScriptDiagId","d":123803,"h":532576068507,"f":40}],"h":123803}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.Obsoletions`; }
        });
        
        $asm.$cls("$srsp.System.Runtime.Serialization.ContractNamespaceAttribute", ($self) => class ContractNamespaceAttribute extends $.$spc.System.Attribute
        {
            $ctor$2(/*string*/ contractNamespace)
            {
                super.$ctor$1();
                {
                    this.ContractNamespace = contractNamespace;
                }
                return this;
            }
            /*string?*/ ClrNamespace = null;
            /*string*/ ContractNamespace = null;
            static $h = 254875;
            static $f = 0b10010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":14483457,"p":[{"p":1310721,"g":{"r":0,"d":0,"h":17180124059,"f":1},"s":{"r":0,"d":0,"h":21475091355,"f":1},"n":"ClrNamespace","d":254875,"h":12885156763,"f":1},{"p":1310721,"g":{"r":0,"d":0,"h":34359993243,"f":1},"n":"ContractNamespace","d":254875,"h":30065025947,"f":1}],"c":[{"p":[{"n":"contractNamespace","p":1310721}],"n":".ctor","o":"$ctor$2","d":254875,"h":4295222171,"f":1}],"h":254875,"a":[{"t":14614529,"c":21489451009,"a":[{"v":3,"t":14548993}],"n":[{"n":"Inherited","v":false,"t":262145},{"n":"AllowMultiple","v":true,"t":262145}]}]}; }
            static get $b() { return $.$spc.System.Attribute; }
            static get $fullName() { return `System.Runtime.Serialization.ContractNamespaceAttribute`; }
        });
        
        $asm.$cls("$srsp.System.Runtime.Serialization.KnownTypeAttribute", ($self) => class KnownTypeAttribute extends $.$spc.System.Attribute
        {
            $ctor$2(/*Type*/ type)
            {
                super.$ctor$1();
                {
                    this.Type = type;
                }
                return this;
            }
            $ctor$3(/*string*/ methodName)
            {
                super.$ctor$1();
                {
                    this.MethodName = methodName;
                }
                return this;
            }
            /*string?*/ MethodName = null;
            /*Type?*/ Type = null;
            static $h = 779163;
            static $f = 0b10010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":14483457,"p":[{"p":1310721,"g":{"r":0,"d":0,"h":21475615643,"f":1},"n":"MethodName","d":779163,"h":17180648347,"f":1},{"p":142606337,"g":{"r":0,"d":0,"h":34360517531,"f":1},"n":"Type","d":779163,"h":30065550235,"f":1}],"c":[{"p":[{"n":"type","p":142606337}],"n":".ctor","o":"$ctor$2","d":779163,"h":4295746459,"f":1},{"p":[{"n":"methodName","p":1310721}],"n":".ctor","o":"$ctor$3","d":779163,"h":8590713755,"f":1}],"h":779163,"a":[{"t":14614529,"c":21489451009,"a":[{"v":12,"t":14548993}],"n":[{"n":"Inherited","v":true,"t":262145},{"n":"AllowMultiple","v":true,"t":262145}]}]}; }
            static get $b() { return $.$spc.System.Attribute; }
            static get $fullName() { return `System.Runtime.Serialization.KnownTypeAttribute`; }
        });
        
        $asm.$cls("$srsp.System.Runtime.Serialization.EnumMemberAttribute", ($self) => class EnumMemberAttribute extends $.$spc.System.Attribute
        {
            /*string?*/ _value = null;
            /*bool*/ _isValueSetExplicitly = false;
            $ctor$2()
            {
                super.$ctor$1();
                {
                }
                return this;
            }
            /*string? */ get Value()
            {
                return this._value;
            }
            /*string? */ set Value(value)
            {
                this._value = value;
                this._isValueSetExplicitly = true;
            }
            /*bool */ get IsValueSetExplicitly()
            {
                return this._isValueSetExplicitly;
            }
            static $h = 451483;
            static $f = 0b10010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":14483457,"p":[{"p":1310721,"g":{"r":0,"d":0,"h":21475287963,"f":1},"s":{"r":0,"d":0,"h":25770255259,"f":1},"n":"Value","d":451483,"h":17180320667,"f":1},{"p":262145,"g":{"r":0,"d":0,"h":34360189851,"f":1},"n":"IsValueSetExplicitly","d":451483,"h":30065222555,"f":1}],"l":[{"t":1310721,"n":"_value","d":451483,"h":4295418779,"f":2},{"t":262145,"n":"_isValueSetExplicitly","d":451483,"h":8590386075,"f":2}],"c":[{"n":".ctor","o":"$ctor$2","d":451483,"h":12885353371,"f":1}],"h":451483,"a":[{"t":14614529,"c":21489451009,"a":[{"v":256,"t":14548993}],"n":[{"n":"Inherited","v":false,"t":262145},{"n":"AllowMultiple","v":false,"t":262145}]}]}; }
            static get $b() { return $.$spc.System.Attribute; }
            static get $fullName() { return `System.Runtime.Serialization.EnumMemberAttribute`; }
        });
        
        $asm.$cls("$srsp.System.Runtime.Serialization.DataMemberAttribute", ($self) => class DataMemberAttribute extends $.$spc.System.Attribute
        {
            /*string?*/ _name = null;
            /*bool*/ _isNameSetExplicitly = false;
            /*int*/ _order = -1;
            $ctor$2()
            {
                super.$ctor$1();
                {
                }
                return this;
            }
            /*string? */ get Name()
            {
                return this._name;
            }
            /*string? */ set Name(value)
            {
                this._name = value;
                this._isNameSetExplicitly = true;
            }
            /*bool */ get IsNameSetExplicitly()
            {
                return this._isNameSetExplicitly;
            }
            /*int */ get Order()
            {
                return this._order;
            }
            /*int */ set Order(value)
            {
                if (value < 0)
                {
                    throw new $.$srsp.System.Runtime.Serialization.InvalidDataContractException().$ctor$6($.$srsp.System.SR.OrderCannotBeNegative);
                }
                this._order = value;
            }
            /*bool*/ IsRequired = false;
            /*bool*/ EmitDefaultValue = false;
            //default member initializer
            constructor()
            {
                super();
                this.IsRequired = false;
                this.EmitDefaultValue = true;
            }
            static $h = 385947;
            static $f = 0b10010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":14483457,"p":[{"p":1310721,"g":{"r":0,"d":0,"h":25770189723,"f":1},"s":{"r":0,"d":0,"h":30065157019,"f":1},"n":"Name","d":385947,"h":21475222427,"f":1},{"p":262145,"g":{"r":0,"d":0,"h":38655091611,"f":1},"n":"IsNameSetExplicitly","d":385947,"h":34360124315,"f":1},{"p":655361,"g":{"r":0,"d":0,"h":47245026203,"f":1},"s":{"r":0,"d":0,"h":51539993499,"f":1},"n":"Order","d":385947,"h":42950058907,"f":1},{"p":262145,"g":{"r":0,"d":0,"h":64424895387,"f":1},"s":{"r":0,"d":0,"h":68719862683,"f":1},"n":"IsRequired","d":385947,"h":60129928091,"f":1},{"p":262145,"g":{"r":0,"d":0,"h":81604764571,"f":1},"s":{"r":0,"d":0,"h":85899731867,"f":1},"n":"EmitDefaultValue","d":385947,"h":77309797275,"f":1}],"l":[{"t":1310721,"n":"_name","d":385947,"h":4295353243,"f":2},{"t":262145,"n":"_isNameSetExplicitly","d":385947,"h":8590320539,"f":2},{"t":655361,"n":"_order","d":385947,"h":12885287835,"f":2}],"c":[{"n":".ctor","o":"$ctor$2","d":385947,"h":17180255131,"f":1}],"h":385947,"a":[{"t":14614529,"c":21489451009,"a":[{"v":384,"t":14548993}],"n":[{"n":"Inherited","v":false,"t":262145},{"n":"AllowMultiple","v":false,"t":262145}]}]}; }
            static get $b() { return $.$spc.System.Attribute; }
            static get $fullName() { return `System.Runtime.Serialization.DataMemberAttribute`; }
        });
        
        $asm.$cls("$srsp.System.Runtime.Serialization.DataContractAttribute", ($self) => class DataContractAttribute extends $.$spc.System.Attribute
        {
            /*string?*/ _name = null;
            /*string?*/ _ns = null;
            /*bool*/ _isNameSetExplicitly = false;
            /*bool*/ _isNamespaceSetExplicitly = false;
            /*bool*/ _isReference = false;
            /*bool*/ _isReferenceSetExplicitly = false;
            $ctor$2()
            {
                super.$ctor$1();
                {
                }
                return this;
            }
            /*bool */ get IsReference()
            {
                return this._isReference;
            }
            /*bool */ set IsReference(value)
            {
                this._isReference = value;
                this._isReferenceSetExplicitly = true;
            }
            /*bool */ get IsReferenceSetExplicitly()
            {
                return this._isReferenceSetExplicitly;
            }
            /*string? */ get Namespace()
            {
                return this._ns;
            }
            /*string? */ set Namespace(value)
            {
                this._ns = value;
                this._isNamespaceSetExplicitly = true;
            }
            /*bool */ get IsNamespaceSetExplicitly()
            {
                return this._isNamespaceSetExplicitly;
            }
            /*string? */ get Name()
            {
                return this._name;
            }
            /*string? */ set Name(value)
            {
                this._name = value;
                this._isNameSetExplicitly = true;
            }
            /*bool */ get IsNameSetExplicitly()
            {
                return this._isNameSetExplicitly;
            }
            static $h = 320411;
            static $f = 0b10010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":14483457,"p":[{"p":262145,"g":{"r":0,"d":0,"h":38655026075,"f":1},"s":{"r":0,"d":0,"h":42949993371,"f":1},"n":"IsReference","d":320411,"h":34360058779,"f":1},{"p":262145,"g":{"r":0,"d":0,"h":51539927963,"f":1},"n":"IsReferenceSetExplicitly","d":320411,"h":47244960667,"f":1},{"p":1310721,"g":{"r":0,"d":0,"h":60129862555,"f":1},"s":{"r":0,"d":0,"h":64424829851,"f":1},"n":"Namespace","d":320411,"h":55834895259,"f":1},{"p":262145,"g":{"r":0,"d":0,"h":73014764443,"f":1},"n":"IsNamespaceSetExplicitly","d":320411,"h":68719797147,"f":1},{"p":1310721,"g":{"r":0,"d":0,"h":81604699035,"f":1},"s":{"r":0,"d":0,"h":85899666331,"f":1},"n":"Name","d":320411,"h":77309731739,"f":1},{"p":262145,"g":{"r":0,"d":0,"h":94489600923,"f":1},"n":"IsNameSetExplicitly","d":320411,"h":90194633627,"f":1}],"l":[{"t":1310721,"n":"_name","d":320411,"h":4295287707,"f":2},{"t":1310721,"n":"_ns","d":320411,"h":8590255003,"f":2},{"t":262145,"n":"_isNameSetExplicitly","d":320411,"h":12885222299,"f":2},{"t":262145,"n":"_isNamespaceSetExplicitly","d":320411,"h":17180189595,"f":2},{"t":262145,"n":"_isReference","d":320411,"h":21475156891,"f":2},{"t":262145,"n":"_isReferenceSetExplicitly","d":320411,"h":25770124187,"f":2}],"c":[{"n":".ctor","o":"$ctor$2","d":320411,"h":30065091483,"f":1}],"h":320411,"a":[{"t":14614529,"c":21489451009,"a":[{"v":28,"t":14548993}],"n":[{"n":"Inherited","v":false,"t":262145},{"n":"AllowMultiple","v":false,"t":262145}]}]}; }
            static get $b() { return $.$spc.System.Attribute; }
            static get $fullName() { return `System.Runtime.Serialization.DataContractAttribute`; }
        });
        
        $asm.$cls("$srsp.System.Runtime.Serialization.CollectionDataContractAttribute", ($self) => class CollectionDataContractAttribute extends $.$spc.System.Attribute
        {
            /*string?*/ _name = null;
            /*string?*/ _ns = null;
            /*string?*/ _itemName = null;
            /*string?*/ _keyName = null;
            /*string?*/ _valueName = null;
            /*bool*/ _isReference = false;
            /*bool*/ _isNameSetExplicitly = false;
            /*bool*/ _isNamespaceSetExplicitly = false;
            /*bool*/ _isReferenceSetExplicitly = false;
            /*bool*/ _isItemNameSetExplicitly = false;
            /*bool*/ _isKeyNameSetExplicitly = false;
            /*bool*/ _isValueNameSetExplicitly = false;
            $ctor$2()
            {
                super.$ctor$1();
                {
                }
                return this;
            }
            /*string? */ get Namespace()
            {
                return this._ns;
            }
            /*string? */ set Namespace(value)
            {
                this._ns = value;
                this._isNamespaceSetExplicitly = true;
            }
            /*bool */ get IsNamespaceSetExplicitly()
            {
                return this._isNamespaceSetExplicitly;
            }
            /*string? */ get Name()
            {
                return this._name;
            }
            /*string? */ set Name(value)
            {
                this._name = value;
                this._isNameSetExplicitly = true;
            }
            /*bool */ get IsNameSetExplicitly()
            {
                return this._isNameSetExplicitly;
            }
            /*string? */ get ItemName()
            {
                return this._itemName;
            }
            /*string? */ set ItemName(value)
            {
                this._itemName = value;
                this._isItemNameSetExplicitly = true;
            }
            /*bool */ get IsItemNameSetExplicitly()
            {
                return this._isItemNameSetExplicitly;
            }
            /*string? */ get KeyName()
            {
                return this._keyName;
            }
            /*string? */ set KeyName(value)
            {
                this._keyName = value;
                this._isKeyNameSetExplicitly = true;
            }
            /*bool */ get IsKeyNameSetExplicitly()
            {
                return this._isKeyNameSetExplicitly;
            }
            /*bool */ get IsReference()
            {
                return this._isReference;
            }
            /*bool */ set IsReference(value)
            {
                this._isReference = value;
                this._isReferenceSetExplicitly = true;
            }
            /*bool */ get IsReferenceSetExplicitly()
            {
                return this._isReferenceSetExplicitly;
            }
            /*string? */ get ValueName()
            {
                return this._valueName;
            }
            /*string? */ set ValueName(value)
            {
                this._valueName = value;
                this._isValueNameSetExplicitly = true;
            }
            /*bool */ get IsValueNameSetExplicitly()
            {
                return this._isValueNameSetExplicitly;
            }
            static $h = 189339;
            static $f = 0b10010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":14483457,"p":[{"p":1310721,"g":{"r":0,"d":0,"h":64424698779,"f":1},"s":{"r":0,"d":0,"h":68719666075,"f":1},"n":"Namespace","d":189339,"h":60129731483,"f":1},{"p":262145,"g":{"r":0,"d":0,"h":77309600667,"f":1},"n":"IsNamespaceSetExplicitly","d":189339,"h":73014633371,"f":1},{"p":1310721,"g":{"r":0,"d":0,"h":85899535259,"f":1},"s":{"r":0,"d":0,"h":90194502555,"f":1},"n":"Name","d":189339,"h":81604567963,"f":1},{"p":262145,"g":{"r":0,"d":0,"h":98784437147,"f":1},"n":"IsNameSetExplicitly","d":189339,"h":94489469851,"f":1},{"p":1310721,"g":{"r":0,"d":0,"h":107374371739,"f":1},"s":{"r":0,"d":0,"h":111669339035,"f":1},"n":"ItemName","d":189339,"h":103079404443,"f":1},{"p":262145,"g":{"r":0,"d":0,"h":120259273627,"f":1},"n":"IsItemNameSetExplicitly","d":189339,"h":115964306331,"f":1},{"p":1310721,"g":{"r":0,"d":0,"h":128849208219,"f":1},"s":{"r":0,"d":0,"h":133144175515,"f":1},"n":"KeyName","d":189339,"h":124554240923,"f":1},{"p":262145,"g":{"r":0,"d":0,"h":141734110107,"f":1},"n":"IsKeyNameSetExplicitly","d":189339,"h":137439142811,"f":1},{"p":262145,"g":{"r":0,"d":0,"h":150324044699,"f":1},"s":{"r":0,"d":0,"h":154619011995,"f":1},"n":"IsReference","d":189339,"h":146029077403,"f":1},{"p":262145,"g":{"r":0,"d":0,"h":163208946587,"f":1},"n":"IsReferenceSetExplicitly","d":189339,"h":158913979291,"f":1},{"p":1310721,"g":{"r":0,"d":0,"h":171798881179,"f":1},"s":{"r":0,"d":0,"h":176093848475,"f":1},"n":"ValueName","d":189339,"h":167503913883,"f":1},{"p":262145,"g":{"r":0,"d":0,"h":184683783067,"f":1},"n":"IsValueNameSetExplicitly","d":189339,"h":180388815771,"f":1}],"l":[{"t":1310721,"n":"_name","d":189339,"h":4295156635,"f":2},{"t":1310721,"n":"_ns","d":189339,"h":8590123931,"f":2},{"t":1310721,"n":"_itemName","d":189339,"h":12885091227,"f":2},{"t":1310721,"n":"_keyName","d":189339,"h":17180058523,"f":2},{"t":1310721,"n":"_valueName","d":189339,"h":21475025819,"f":2},{"t":262145,"n":"_isReference","d":189339,"h":25769993115,"f":2},{"t":262145,"n":"_isNameSetExplicitly","d":189339,"h":30064960411,"f":2},{"t":262145,"n":"_isNamespaceSetExplicitly","d":189339,"h":34359927707,"f":2},{"t":262145,"n":"_isReferenceSetExplicitly","d":189339,"h":38654895003,"f":2},{"t":262145,"n":"_isItemNameSetExplicitly","d":189339,"h":42949862299,"f":2},{"t":262145,"n":"_isKeyNameSetExplicitly","d":189339,"h":47244829595,"f":2},{"t":262145,"n":"_isValueNameSetExplicitly","d":189339,"h":51539796891,"f":2}],"c":[{"n":".ctor","o":"$ctor$2","d":189339,"h":55834764187,"f":1}],"h":189339,"a":[{"t":14614529,"c":21489451009,"a":[{"v":12,"t":14548993}],"n":[{"n":"Inherited","v":false,"t":262145},{"n":"AllowMultiple","v":false,"t":262145}]}]}; }
            static get $b() { return $.$spc.System.Attribute; }
            static get $fullName() { return `System.Runtime.Serialization.CollectionDataContractAttribute`; }
        });
        
        $asm.$cls("$srsp.System.Runtime.Serialization.IgnoreDataMemberAttribute", ($self) => class IgnoreDataMemberAttribute extends $.$spc.System.Attribute
        {
            $ctor$2()
            {
                super.$ctor$1();
                {
                }
                return this;
            }
            static $h = 517019;
            static $f = 0b10010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":14483457,"c":[{"n":".ctor","o":"$ctor$2","d":517019,"h":4295484315,"f":1}],"h":517019,"a":[{"t":14614529,"c":21489451009,"a":[{"v":384,"t":14548993}],"n":[{"n":"Inherited","v":false,"t":262145},{"n":"AllowMultiple","v":false,"t":262145}]}]}; }
            static get $b() { return $.$spc.System.Attribute; }
            static get $fullName() { return `System.Runtime.Serialization.IgnoreDataMemberAttribute`; }
        });
        
        $asm.$cls("$srsp.System.Runtime.Serialization.InvalidDataContractException", ($self) => class InvalidDataContractException extends $.$spc.System.Exception
        {
            $ctor$5()
            {
                super.$ctor$1();
                {
                }
                return this;
            }
            $ctor$6(/*string?*/ message)
            {
                super.$ctor$2(message);
                {
                }
                return this;
            }
            $ctor$7(/*string?*/ message, /*Exception?*/ innerException)
            {
                super.$ctor$3(message, innerException);
                {
                }
                return this;
            }
            $ctor$8(/*SerializationInfo*/ info, /*StreamingContext*/ context)
            {
                super.$ctor$4(info, context);
                {
                }
                return this;
            }
            static $h = 582555;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":47185921,"h":582555}; }
            static get $b() { return $.$spc.System.Exception; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.Runtime.Serialization.ISerializable ]; }
            static get $fullName() { return `System.Runtime.Serialization.InvalidDataContractException`; }
        });
	});
})(window, window.NetJs.$boot(), ...window.NetJs.$require("NetJs.System.Private.CoreLib", "NetJs.System.Memory", "NetJs.System.Private.Uri", "NetJs.System.Runtime"))