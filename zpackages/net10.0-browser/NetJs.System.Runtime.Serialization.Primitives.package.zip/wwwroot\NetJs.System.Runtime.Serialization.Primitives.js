
(function ($global, $, $spc, $sm, $spu, $sr) {
    "use strict";
    let _;
    
    
    
	$.$asm(
    "NetJs.System.Runtime.Serialization.Primitives", 
    {"h":39050,"f":"System.Runtime.Serialization.Primitives","v":"1.0.35.0","a":[{"t":96337921,"c":4391305217,"a":[{"v":113442817,"t":142606337}]},{"t":96337921,"c":4391305217,"a":[{"v":113508353,"t":142606337}]},{"t":96337921,"c":4391305217,"a":[{"v":113573889,"t":142606337}]},{"t":96337921,"c":4391305217,"a":[{"v":113639425,"t":142606337}]},{"t":96337921,"c":4391305217,"a":[{"v":113901569,"t":142606337}]},{"t":96337921,"c":4391305217,"a":[{"v":114098177,"t":142606337}]},{"t":96337921,"c":4391305217,"a":[{"v":114163713,"t":142606337}]},{"t":115146753,"c":13000048641,"a":[{"v":".NETCoreApp,Version=v10.0","t":1310721}],"n":[{"n":"FrameworkDisplayName","v":".NET 10.0","t":1310721}]},{"t":73596929,"c":4368564225,"a":[{"v":"SIT","t":1310721}]},{"t":73662465,"c":4368629761,"a":[{"v":"Debug","t":1310721}]},{"t":74121217,"c":4369088513,"a":[{"v":"1.0.35.0","t":1310721}]},{"t":74252289,"c":4369219585,"a":[{"v":"1.0.35\u002B5b8aaafb3aebad7fc7141c6e509af03c92d8b793","t":1310721}]},{"t":75104257,"c":4370071553,"a":[{"v":"NetJs.System.Runtime.Serialization.Primitives","t":1310721}]},{"t":75235329,"c":4370202625,"a":[{"v":"NetJs.System.Runtime.Serialization.Primitives","t":1310721}]},{"t":75366401,"c":4370333697,"a":[{"v":"1.0.35.0","t":1310721}]},{"t":115212289,"c":4410179585,"a":[{"v":"browser1.0","t":1310721}]},{"t":114950145,"c":4409917441,"a":[{"v":"browser1.0","t":1310721}]}],"m":[]},
    function($asm)
	{
        
        
        $asm.$cls("$srsp.System.Runtime.Serialization.ISerializationSurrogateProvider", ($self) => class ISerializationSurrogateProvider
        {
            static $h = 628874;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {"m":[{"r":142606337,"p":[{"n":"type","p":142606337}],"n":"GetSurrogateType","o":"System$Runtime$Serialization$ISerializationSurrogateProvider$GetSurrogateType","d":628874,"h":4295596170,"f":257},{"r":131073,"p":[{"n":"obj","p":131073},{"n":"targetType","p":142606337}],"n":"GetObjectToSerialize","o":"System$Runtime$Serialization$ISerializationSurrogateProvider$GetObjectToSerialize","d":628874,"h":8590563466,"f":257},{"r":131073,"p":[{"n":"obj","p":131073},{"n":"targetType","p":142606337}],"n":"GetDeserializedObject","o":"System$Runtime$Serialization$ISerializationSurrogateProvider$GetDeserializedObject","d":628874,"h":12885530762,"f":257}],"h":628874}; }
            static get $fullName() { return `System.Runtime.Serialization.ISerializationSurrogateProvider`; }
        });
        
        $asm.$cls("$srsp.System.Runtime.Serialization.ISerializationSurrogateProvider2", ($self) => class ISerializationSurrogateProvider2
        {
            static $h = 694410;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {"m":[{"r":131073,"p":[{"n":"memberInfo","p":78249985},{"n":"dataContractType","p":142606337}],"n":"GetCustomDataToExport","o":"System$Runtime$Serialization$ISerializationSurrogateProvider2$GetCustomDataToExport","d":694410,"h":4295661706,"f":257},{"r":131073,"p":[{"n":"runtimeType","p":142606337},{"n":"dataContractType","p":142606337}],"n":"GetCustomDataToExport","o":"System$Runtime$Serialization$ISerializationSurrogateProvider2$GetCustomDataToExport$1","d":694410,"h":8590629002,"f":257},{"r":65537,"p":[{"n":"customDataTypes","p":$.$spc.System.Collections.ObjectModel.Collection$$($.$spc.System.Type).$h}],"n":"GetKnownCustomDataTypes","o":"System$Runtime$Serialization$ISerializationSurrogateProvider2$GetKnownCustomDataTypes","d":694410,"h":12885596298,"f":257},{"r":142606337,"p":[{"n":"typeName","p":1310721},{"n":"typeNamespace","p":1310721},{"n":"customData","p":131073}],"n":"GetReferencedTypeOnImport","o":"System$Runtime$Serialization$ISerializationSurrogateProvider2$GetReferencedTypeOnImport","d":694410,"h":17180563594,"f":257}],"i":[628874],"h":694410}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$srsp.System.Runtime.Serialization.ISerializationSurrogateProvider ]; }
            static get $fullName() { return `System.Runtime.Serialization.ISerializationSurrogateProvider2`; }
        });
        
        $asm.$cls("$srsp.System.SR", ($self) => class SR
        {
            /*global::System.Resources.ResourceManager*/ static s_resourceManager = null;
            /*global::System.Globalization.CultureInfo*/ static resourceCulture = null;
            static /*global::System.Resources.ResourceManager */ get ResourceManager()
            {
                if ($.$spc.System.Object.ReferenceEquals($.$srsp.System.SR.s_resourceManager, null))
                {
                    /*global::System.Resources.ResourceManager*/ let temp = new $.$spc.System.Resources.ResourceManager().$ctor$3("System.Runtime.Serialization.Primitives", $.$srsp.System.SR.$type.Assembly);
                    $.$srsp.System.SR.s_resourceManager = temp;
                }
                return $.$srsp.System.SR.s_resourceManager;
            }
            static /*global::System.Globalization.CultureInfo */ get Culture()
            {
                return $.$srsp.System.SR.resourceCulture;
            }
            static /*global::System.Globalization.CultureInfo */ set Culture(value)
            {
                $.$srsp.System.SR.resourceCulture = value;
            }
            static /*string */ get OrderCannotBeNegative()
            {
                return "Property 'Order' in DataMemberAttribute attribute cannot be a negative number.";
            }
            /*bool*/ static s_usingResourceKeys = false;
            static /*bool */ GetUsingResourceKeysSwitchValue()
            {
                /*bool*/ let usingResourceKeys;
                return $.$spc.System.AppContext.TryGetSwitch("System.Resources.UseSystemResourceKeys", $.$ref(() => usingResourceKeys, ($v) => usingResourceKeys = $v, $.$spc.System.Boolean)) ? usingResourceKeys : false;
            }
            static /*bool */ UsingResourceKeys()
            {
                return $.$srsp.System.SR.s_usingResourceKeys;
            }
            static /*string */ GetResourceString(/*string*/ resourceKey)
            {
                if ($.$srsp.System.SR.UsingResourceKeys())
                {
                    return resourceKey;
                }
                /*string?*/ let resourceString = null;
                try
                {
                    resourceString = $.$srsp.System.SR.ResourceManager.GetString(resourceKey);
                }
                catch($e)
                {
                }
                return resourceString;
            }
            static /*string */ GetResourceString$1(/*string*/ resourceKey, /*string*/ defaultString)
            {
                /*string*/ let resourceString = $.$srsp.System.SR.GetResourceString(resourceKey);
                return $.$spc.System.String.op_Equality(resourceKey, resourceString) || $.$spc.System.String.op_Equality(resourceString, null) ? defaultString : resourceString;
            }
            static /*string */ Format(/*string*/ resourceFormat, /*object?*/ p1)
            {
                if ($.$srsp.System.SR.UsingResourceKeys())
                {
                    return $.$spc.System.String.Join$10(", ", $.$spc.System.ReadOnlySpan$$($.$spc.System.Object).op_Implicit([ resourceFormat, p1 ]));
                }
                return $.$spc.System.String.Format(resourceFormat, p1);
            }
            static /*string */ Format$1(/*string*/ resourceFormat, /*object?*/ p1, /*object?*/ p2)
            {
                if ($.$srsp.System.SR.UsingResourceKeys())
                {
                    return $.$spc.System.String.Join$10(", ", $.$spc.System.ReadOnlySpan$$($.$spc.System.Object).op_Implicit([ resourceFormat, p1, p2 ]));
                }
                return $.$spc.System.String.Format$1(resourceFormat, p1, p2);
            }
            static /*string */ Format$2(/*string*/ resourceFormat, /*object?*/ p1, /*object?*/ p2, /*object?*/ p3)
            {
                if ($.$srsp.System.SR.UsingResourceKeys())
                {
                    return $.$spc.System.String.Join$10(", ", $.$spc.System.ReadOnlySpan$$($.$spc.System.Object).op_Implicit([ resourceFormat, p1, p2, p3 ]));
                }
                return $.$spc.System.String.Format$2(resourceFormat, p1, p2, p3);
            }
            static /*string */ Format$3(/*string*/ resourceFormat, /*params object?[]?*/ args)
            {
                if (args !== null)
                {
                    if ($.$srsp.System.SR.UsingResourceKeys())
                    {
                        return resourceFormat + ", " + $.$spc.System.String.Join$9(", ", args);
                    }
                    return $.$spc.System.String.Format$3(resourceFormat, args);
                }
                return resourceFormat;
            }
            static /*string */ Format$4(/*IFormatProvider?*/ provider, /*string*/ resourceFormat, /*object?*/ p1)
            {
                if ($.$srsp.System.SR.UsingResourceKeys())
                {
                    return $.$spc.System.String.Join$10(", ", $.$spc.System.ReadOnlySpan$$($.$spc.System.Object).op_Implicit([ resourceFormat, p1 ]));
                }
                return $.$spc.System.String.Format$5(provider, resourceFormat, p1);
            }
            static /*string */ Format$5(/*IFormatProvider?*/ provider, /*string*/ resourceFormat, /*object?*/ p1, /*object?*/ p2)
            {
                if ($.$srsp.System.SR.UsingResourceKeys())
                {
                    return $.$spc.System.String.Join$10(", ", $.$spc.System.ReadOnlySpan$$($.$spc.System.Object).op_Implicit([ resourceFormat, p1, p2 ]));
                }
                return $.$spc.System.String.Format$6(provider, resourceFormat, p1, p2);
            }
            static /*string */ Format$6(/*IFormatProvider?*/ provider, /*string*/ resourceFormat, /*object?*/ p1, /*object?*/ p2, /*object?*/ p3)
            {
                if ($.$srsp.System.SR.UsingResourceKeys())
                {
                    return $.$spc.System.String.Join$10(", ", $.$spc.System.ReadOnlySpan$$($.$spc.System.Object).op_Implicit([ resourceFormat, p1, p2, p3 ]));
                }
                return $.$spc.System.String.Format$7(provider, resourceFormat, p1, p2, p3);
            }
            static /*string */ Format$7(/*IFormatProvider?*/ provider, /*string*/ resourceFormat, /*params object?[]?*/ args)
            {
                if (args !== null)
                {
                    if ($.$srsp.System.SR.UsingResourceKeys())
                    {
                        return resourceFormat + ", " + $.$spc.System.String.Join$9(", ", args);
                    }
                    return $.$spc.System.String.Format$8(provider, resourceFormat, args);
                }
                return resourceFormat;
            }
            //Static Initializer
            static $sinit()
            {
                {
                    this.s_usingResourceKeys = $.$srsp.System.SR.GetUsingResourceKeysSwitchValue();
                }
            }
            static $h = 825482;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"h":825482}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.SR`; }
        });
        
        $asm.$cls("$srsp.System.Obsoletions", ($self) => class Obsoletions
        {
            /*string*/ static SharedUrlFormat = null;
            /*string*/ static SystemTextEncodingUTF7Message = null;
            /*string*/ static SystemTextEncodingUTF7DiagId = null;
            /*string*/ static PrincipalPermissionAttributeMessage = null;
            /*string*/ static PrincipalPermissionAttributeDiagId = null;
            /*string*/ static CodeAccessSecurityMessage = null;
            /*string*/ static CodeAccessSecurityDiagId = null;
            /*string*/ static ConstrainedExecutionRegionMessage = null;
            /*string*/ static ConstrainedExecutionRegionDiagId = null;
            /*string*/ static GlobalAssemblyCacheMessage = null;
            /*string*/ static GlobalAssemblyCacheDiagId = null;
            /*string*/ static ThreadAbortMessage = null;
            /*string*/ static ThreadResetAbortMessage = null;
            /*string*/ static ThreadAbortDiagId = null;
            /*string*/ static DefaultCryptoAlgorithmsMessage = null;
            /*string*/ static DefaultCryptoAlgorithmsDiagId = null;
            /*string*/ static CreatePdbGeneratorMessage = null;
            /*string*/ static CreatePdbGeneratorDiagId = null;
            /*string*/ static AuthenticationManagerMessage = null;
            /*string*/ static AuthenticationManagerDiagId = null;
            /*string*/ static RemotingApisMessage = null;
            /*string*/ static RemotingApisDiagId = null;
            /*string*/ static BinaryFormatterMessage = null;
            /*string*/ static BinaryFormatterDiagId = null;
            /*string*/ static CodeBaseMessage = null;
            /*string*/ static CodeBaseDiagId = null;
            /*string*/ static EscapeUriStringMessage = null;
            /*string*/ static EscapeUriStringDiagId = null;
            /*string*/ static WebRequestMessage = null;
            /*string*/ static WebRequestDiagId = null;
            /*string*/ static DisablePrivateReflectionAttributeMessage = null;
            /*string*/ static DisablePrivateReflectionAttributeDiagId = null;
            /*string*/ static GetContextInfoMessage = null;
            /*string*/ static GetContextInfoDiagId = null;
            /*string*/ static StrongNameKeyPairMessage = null;
            /*string*/ static StrongNameKeyPairDiagId = null;
            /*string*/ static ReflectionOnlyLoadingMessage = null;
            /*string*/ static ReflectionOnlyLoadingDiagId = null;
            /*string*/ static RuntimeEnvironmentMessage = null;
            /*string*/ static RuntimeEnvironmentDiagId = null;
            /*string*/ static JsonSerializerOptionsIgnoreNullValuesMessage = null;
            /*string*/ static JsonSerializerOptionsIgnoreNullValuesDiagId = null;
            /*string*/ static DerivedCryptographicTypesMessage = null;
            /*string*/ static DerivedCryptographicTypesDiagId = null;
            /*string*/ static RijndaelMessage = null;
            /*string*/ static RijndaelDiagId = null;
            /*string*/ static RNGCryptoServiceProviderMessage = null;
            /*string*/ static RNGCryptoServiceProviderDiagId = null;
            /*string*/ static AppDomainCreateUnloadMessage = null;
            /*string*/ static AppDomainCreateUnloadDiagId = null;
            /*string*/ static SuppressIldasmAttributeMessage = null;
            /*string*/ static SuppressIldasmAttributeDiagId = null;
            /*string*/ static X509CertificateImmutableMessage = null;
            /*string*/ static X509CertificateImmutableDiagId = null;
            /*string*/ static PublicKeyPropertyMessage = null;
            /*string*/ static PublicKeyPropertyDiagId = null;
            /*string*/ static X509CertificatePrivateKeyMessage = null;
            /*string*/ static X509CertificatePrivateKeyDiagId = null;
            /*string*/ static ProduceLegacyHmacValuesMessage = null;
            /*string*/ static ProduceLegacyHmacValuesDiagId = null;
            /*string*/ static UseManagedSha1Message = null;
            /*string*/ static UseManagedSha1DiagId = null;
            /*string*/ static CryptoConfigEncodeOIDMessage = null;
            /*string*/ static CryptoConfigEncodeOIDDiagId = null;
            /*string*/ static CorruptedStateRecoveryMessage = null;
            /*string*/ static CorruptedStateRecoveryDiagId = null;
            /*string*/ static Rfc2898CryptDeriveKeyMessage = null;
            /*string*/ static Rfc2898CryptDeriveKeyDiagId = null;
            /*string*/ static CmsSignerCspParamsCtorMessage = null;
            /*string*/ static CmsSignerCspParamsCtorDiagId = null;
            /*string*/ static SignerInfoCounterSigMessage = null;
            /*string*/ static SignerInfoCounterSigDiagId = null;
            /*string*/ static RegexCompileToAssemblyMessage = null;
            /*string*/ static RegexCompileToAssemblyDiagId = null;
            /*string*/ static AssemblyNameMembersMessage = null;
            /*string*/ static AssemblyNameMembersDiagId = null;
            /*string*/ static SystemDataSerializationFormatBinaryMessage = null;
            /*string*/ static SystemDataSerializationFormatBinaryDiagId = null;
            /*string*/ static TlsVersion10and11Message = null;
            /*string*/ static TlsVersion10and11DiagId = null;
            /*string*/ static EncryptionPolicyMessage = null;
            /*string*/ static EncryptionPolicyDiagId = null;
            /*string*/ static EccXmlExportImportMessage = null;
            /*string*/ static EccXmlExportImportDiagId = null;
            /*string*/ static EcDhPublicKeyBlobMessage = null;
            /*string*/ static EcDhPublicKeyBlobDiagId = null;
            /*string*/ static AssemblyNameCodeBaseMessage = null;
            /*string*/ static AssemblyNameCodeBaseDiagId = null;
            /*string*/ static CryptoStringFactoryMessage = null;
            /*string*/ static CryptoStringFactoryDiagId = null;
            /*string*/ static ControlledExecutionRunMessage = null;
            /*string*/ static ControlledExecutionRunDiagId = null;
            /*string*/ static XmlSecureResolverMessage = null;
            /*string*/ static XmlSecureResolverDiagId = null;
            /*string*/ static RsaEncryptDecryptValueMessage = null;
            /*string*/ static RsaEncryptDecryptDiagId = null;
            /*string*/ static JsonSerializerOptionsAddContextMessage = null;
            /*string*/ static JsonSerializerOptionsAddContextDiagId = null;
            /*string*/ static LegacyFormatterMessage = null;
            /*string*/ static LegacyFormatterDiagId = null;
            /*string*/ static LegacyFormatterImplMessage = null;
            /*string*/ static LegacyFormatterImplDiagId = null;
            /*string*/ static RegexExtensibilityImplMessage = null;
            /*string*/ static RegexExtensibilityDiagId = null;
            /*string*/ static AesGcmTagConstructorMessage = null;
            /*string*/ static AesGcmTagConstructorDiagId = null;
            /*string*/ static ThreadVolatileReadWriteMessage = null;
            /*string*/ static ThreadVolatileReadWriteDiagId = null;
            /*string*/ static ArmIntrinsicPerformsUnsignedOperationMessage = null;
            /*string*/ static ArmIntrinsicPerformsUnsignedOperationDiagId = null;
            /*string*/ static LoadFromHashAlgorithmMessage = null;
            /*string*/ static LoadFromHashAlgorithmDiagId = null;
            /*string*/ static X509CtorCertDataObsoleteMessage = null;
            /*string*/ static X509CtorCertDataObsoleteDiagId = null;
            /*string*/ static TlsCipherAlgorithmEnumsMessage = null;
            /*string*/ static TlsCipherAlgorithmEnumsDiagId = null;
            /*string*/ static SystemEventsEventsThreadShutdownMessage = null;
            /*string*/ static SystemEventsEventsThreadShutdownDiagId = null;
            /*string*/ static Rfc2898DeriveBytesCtorMessage = null;
            /*string*/ static Rfc2898DeriveBytesCtorDiagId = null;
            /*string*/ static QueryableMinByMaxByTSourceObsoleteMessage = null;
            /*string*/ static QueryableMinByMaxByTSourceObsoleteDiagId = null;
            /*string*/ static XsltSettingsEnableScriptMessage = null;
            /*string*/ static XsltSettingsEnableScriptDiagId = null;
            //Static Initializer
            static $sinit()
            {
                {
                    this.SharedUrlFormat = "https://aka.ms/dotnet-warnings/{0}";
                }
                {
                    this.SystemTextEncodingUTF7Message = "The UTF-7 encoding is insecure and should not be used. Consider using UTF-8 instead.";
                }
                {
                    this.SystemTextEncodingUTF7DiagId = "SYSLIB0001";
                }
                {
                    this.PrincipalPermissionAttributeMessage = "PrincipalPermissionAttribute is not honored by the runtime and must not be used.";
                }
                {
                    this.PrincipalPermissionAttributeDiagId = "SYSLIB0002";
                }
                {
                    this.CodeAccessSecurityMessage = "Code Access Security is not supported or honored by the runtime.";
                }
                {
                    this.CodeAccessSecurityDiagId = "SYSLIB0003";
                }
                {
                    this.ConstrainedExecutionRegionMessage = "The Constrained Execution Region (CER) feature is not supported.";
                }
                {
                    this.ConstrainedExecutionRegionDiagId = "SYSLIB0004";
                }
                {
                    this.GlobalAssemblyCacheMessage = "The Global Assembly Cache is not supported.";
                }
                {
                    this.GlobalAssemblyCacheDiagId = "SYSLIB0005";
                }
                {
                    this.ThreadAbortMessage = "Thread.Abort is not supported and throws PlatformNotSupportedException.";
                }
                {
                    this.ThreadResetAbortMessage = "Thread.ResetAbort is not supported and throws PlatformNotSupportedException.";
                }
                {
                    this.ThreadAbortDiagId = "SYSLIB0006";
                }
                {
                    this.DefaultCryptoAlgorithmsMessage = "The default implementation of this cryptography algorithm is not supported.";
                }
                {
                    this.DefaultCryptoAlgorithmsDiagId = "SYSLIB0007";
                }
                {
                    this.CreatePdbGeneratorMessage = "The CreatePdbGenerator API is not supported and throws PlatformNotSupportedException.";
                }
                {
                    this.CreatePdbGeneratorDiagId = "SYSLIB0008";
                }
                {
                    this.AuthenticationManagerMessage = "AuthenticationManager is not supported. Methods will no-op or throw PlatformNotSupportedException.";
                }
                {
                    this.AuthenticationManagerDiagId = "SYSLIB0009";
                }
                {
                    this.RemotingApisMessage = "This Remoting API is not supported and throws PlatformNotSupportedException.";
                }
                {
                    this.RemotingApisDiagId = "SYSLIB0010";
                }
                {
                    this.BinaryFormatterMessage = "BinaryFormatter serialization is obsolete and should not be used. See https://aka.ms/binaryformatter for more information.";
                }
                {
                    this.BinaryFormatterDiagId = "SYSLIB0011";
                }
                {
                    this.CodeBaseMessage = "Assembly.CodeBase and Assembly.EscapedCodeBase are only included for .NET Framework compatibility. Use Assembly.Location instead.";
                }
                {
                    this.CodeBaseDiagId = "SYSLIB0012";
                }
                {
                    this.EscapeUriStringMessage = "Uri.EscapeUriString can corrupt the Uri string in some cases. Consider using Uri.EscapeDataString for query string components instead.";
                }
                {
                    this.EscapeUriStringDiagId = "SYSLIB0013";
                }
                {
                    this.WebRequestMessage = "WebRequest, HttpWebRequest, ServicePoint, and WebClient are obsolete. Use HttpClient instead.";
                }
                {
                    this.WebRequestDiagId = "SYSLIB0014";
                }
                {
                    this.DisablePrivateReflectionAttributeMessage = "DisablePrivateReflectionAttribute has no effect in .NET 6.0+.";
                }
                {
                    this.DisablePrivateReflectionAttributeDiagId = "SYSLIB0015";
                }
                {
                    this.GetContextInfoMessage = "Use the Graphics.GetContextInfo overloads that accept arguments for better performance and fewer allocations.";
                }
                {
                    this.GetContextInfoDiagId = "SYSLIB0016";
                }
                {
                    this.StrongNameKeyPairMessage = "Strong name signing is not supported and throws PlatformNotSupportedException.";
                }
                {
                    this.StrongNameKeyPairDiagId = "SYSLIB0017";
                }
                {
                    this.ReflectionOnlyLoadingMessage = "ReflectionOnly loading is not supported and throws PlatformNotSupportedException.";
                }
                {
                    this.ReflectionOnlyLoadingDiagId = "SYSLIB0018";
                }
                {
                    this.RuntimeEnvironmentMessage = "RuntimeEnvironment members SystemConfigurationFile, GetRuntimeInterfaceAsIntPtr, and GetRuntimeInterfaceAsObject are not supported and throw PlatformNotSupportedException.";
                }
                {
                    this.RuntimeEnvironmentDiagId = "SYSLIB0019";
                }
                {
                    this.JsonSerializerOptionsIgnoreNullValuesMessage = "JsonSerializerOptions.IgnoreNullValues is obsolete. To ignore null values when serializing, set DefaultIgnoreCondition to JsonIgnoreCondition.WhenWritingNull.";
                }
                {
                    this.JsonSerializerOptionsIgnoreNullValuesDiagId = "SYSLIB0020";
                }
                {
                    this.DerivedCryptographicTypesMessage = "Derived cryptographic types are obsolete. Use the Create method on the base type instead.";
                }
                {
                    this.DerivedCryptographicTypesDiagId = "SYSLIB0021";
                }
                {
                    this.RijndaelMessage = "The Rijndael and RijndaelManaged types are obsolete. Use Aes instead.";
                }
                {
                    this.RijndaelDiagId = "SYSLIB0022";
                }
                {
                    this.RNGCryptoServiceProviderMessage = "RNGCryptoServiceProvider is obsolete. To generate a random number, use one of the RandomNumberGenerator static methods instead.";
                }
                {
                    this.RNGCryptoServiceProviderDiagId = "SYSLIB0023";
                }
                {
                    this.AppDomainCreateUnloadMessage = "Creating and unloading AppDomains is not supported and throws an exception.";
                }
                {
                    this.AppDomainCreateUnloadDiagId = "SYSLIB0024";
                }
                {
                    this.SuppressIldasmAttributeMessage = "SuppressIldasmAttribute has no effect in .NET 6.0+.";
                }
                {
                    this.SuppressIldasmAttributeDiagId = "SYSLIB0025";
                }
                {
                    this.X509CertificateImmutableMessage = "X509Certificate and X509Certificate2 are immutable. Use X509CertificateLoader to create a new certificate.";
                }
                {
                    this.X509CertificateImmutableDiagId = "SYSLIB0026";
                }
                {
                    this.PublicKeyPropertyMessage = "PublicKey.Key is obsolete. Use the appropriate method to get the public key, such as GetRSAPublicKey.";
                }
                {
                    this.PublicKeyPropertyDiagId = "SYSLIB0027";
                }
                {
                    this.X509CertificatePrivateKeyMessage = "X509Certificate2.PrivateKey is obsolete. Use the appropriate method to get the private key, such as GetRSAPrivateKey, or use the CopyWithPrivateKey method to create a new instance with a private key.";
                }
                {
                    this.X509CertificatePrivateKeyDiagId = "SYSLIB0028";
                }
                {
                    this.ProduceLegacyHmacValuesMessage = "ProduceLegacyHmacValues is obsolete. Producing legacy HMAC values is not supported.";
                }
                {
                    this.ProduceLegacyHmacValuesDiagId = "SYSLIB0029";
                }
                {
                    this.UseManagedSha1Message = "HMACSHA1 always uses the algorithm implementation provided by the platform. Use a constructor without the useManagedSha1 parameter.";
                }
                {
                    this.UseManagedSha1DiagId = "SYSLIB0030";
                }
                {
                    this.CryptoConfigEncodeOIDMessage = "EncodeOID is obsolete. Use the ASN.1 functionality provided in System.Formats.Asn1.";
                }
                {
                    this.CryptoConfigEncodeOIDDiagId = "SYSLIB0031";
                }
                {
                    this.CorruptedStateRecoveryMessage = "Recovery from corrupted process state exceptions is not supported; HandleProcessCorruptedStateExceptionsAttribute is ignored.";
                }
                {
                    this.CorruptedStateRecoveryDiagId = "SYSLIB0032";
                }
                {
                    this.Rfc2898CryptDeriveKeyMessage = "Rfc2898DeriveBytes.CryptDeriveKey is obsolete and is not supported. Use PasswordDeriveBytes.CryptDeriveKey instead.";
                }
                {
                    this.Rfc2898CryptDeriveKeyDiagId = "SYSLIB0033";
                }
                {
                    this.CmsSignerCspParamsCtorMessage = "CmsSigner(CspParameters) is obsolete and is not supported. Use an alternative constructor instead.";
                }
                {
                    this.CmsSignerCspParamsCtorDiagId = "SYSLIB0034";
                }
                {
                    this.SignerInfoCounterSigMessage = "ComputeCounterSignature without specifying a CmsSigner is obsolete and is not supported. Use the overload that accepts a CmsSigner.";
                }
                {
                    this.SignerInfoCounterSigDiagId = "SYSLIB0035";
                }
                {
                    this.RegexCompileToAssemblyMessage = "Regex.CompileToAssembly is obsolete and not supported. Use the GeneratedRegexAttribute with the regular expression source generator instead.";
                }
                {
                    this.RegexCompileToAssemblyDiagId = "SYSLIB0036";
                }
                {
                    this.AssemblyNameMembersMessage = "AssemblyName members HashAlgorithm, ProcessorArchitecture, and VersionCompatibility are obsolete and not supported.";
                }
                {
                    this.AssemblyNameMembersDiagId = "SYSLIB0037";
                }
                {
                    this.SystemDataSerializationFormatBinaryMessage = "SerializationFormat.Binary is obsolete and should not be used. See https://aka.ms/serializationformat-binary-obsolete for more information.";
                }
                {
                    this.SystemDataSerializationFormatBinaryDiagId = "SYSLIB0038";
                }
                {
                    this.TlsVersion10and11Message = "TLS versions 1.0 and 1.1 have known vulnerabilities and are not recommended. Use a newer TLS version instead, or use SslProtocols.None to defer to OS defaults.";
                }
                {
                    this.TlsVersion10and11DiagId = "SYSLIB0039";
                }
                {
                    this.EncryptionPolicyMessage = "EncryptionPolicy.NoEncryption and AllowEncryption significantly reduce security and should not be used in production code.";
                }
                {
                    this.EncryptionPolicyDiagId = "SYSLIB0040";
                }
                {
                    this.EccXmlExportImportMessage = "ToXmlString and FromXmlString have no implementation for ECC types, and are obsolete. Use a standard import and export format such as ExportSubjectPublicKeyInfo or ImportSubjectPublicKeyInfo for public keys and ExportPkcs8PrivateKey or ImportPkcs8PrivateKey for private keys.";
                }
                {
                    this.EccXmlExportImportDiagId = "SYSLIB0042";
                }
                {
                    this.EcDhPublicKeyBlobMessage = "ECDiffieHellmanPublicKey.ToByteArray() and the associated constructor do not have a consistent and interoperable implementation on all platforms. Use ECDiffieHellmanPublicKey.ExportSubjectPublicKeyInfo() instead.";
                }
                {
                    this.EcDhPublicKeyBlobDiagId = "SYSLIB0043";
                }
                {
                    this.AssemblyNameCodeBaseMessage = "AssemblyName.CodeBase and AssemblyName.EscapedCodeBase are obsolete. Using them for loading an assembly is not supported.";
                }
                {
                    this.AssemblyNameCodeBaseDiagId = "SYSLIB0044";
                }
                {
                    this.CryptoStringFactoryMessage = "Cryptographic factory methods accepting an algorithm name are obsolete. Use the parameterless Create factory method on the algorithm type instead.";
                }
                {
                    this.CryptoStringFactoryDiagId = "SYSLIB0045";
                }
                {
                    this.ControlledExecutionRunMessage = "ControlledExecution.Run method may corrupt the process and should not be used in production code.";
                }
                {
                    this.ControlledExecutionRunDiagId = "SYSLIB0046";
                }
                {
                    this.XmlSecureResolverMessage = "XmlSecureResolver is obsolete. Use XmlResolver.ThrowingResolver instead when attempting to forbid XML external entity resolution.";
                }
                {
                    this.XmlSecureResolverDiagId = "SYSLIB0047";
                }
                {
                    this.RsaEncryptDecryptValueMessage = "RSA.EncryptValue and DecryptValue are not supported and throw NotSupportedException. Use RSA.Encrypt and RSA.Decrypt instead.";
                }
                {
                    this.RsaEncryptDecryptDiagId = "SYSLIB0048";
                }
                {
                    this.JsonSerializerOptionsAddContextMessage = "JsonSerializerOptions.AddContext is obsolete. To register a JsonSerializerContext, use either the TypeInfoResolver or TypeInfoResolverChain properties.";
                }
                {
                    this.JsonSerializerOptionsAddContextDiagId = "SYSLIB0049";
                }
                {
                    this.LegacyFormatterMessage = "Formatter-based serialization is obsolete and should not be used.";
                }
                {
                    this.LegacyFormatterDiagId = "SYSLIB0050";
                }
                {
                    this.LegacyFormatterImplMessage = "This API supports obsolete formatter-based serialization. It should not be called or extended by application code.";
                }
                {
                    this.LegacyFormatterImplDiagId = "SYSLIB0051";
                }
                {
                    this.RegexExtensibilityImplMessage = "This API supports obsolete mechanisms for Regex extensibility. It is not supported.";
                }
                {
                    this.RegexExtensibilityDiagId = "SYSLIB0052";
                }
                {
                    this.AesGcmTagConstructorMessage = "AesGcm should indicate the required tag size for encryption and decryption. Use a constructor that accepts the tag size.";
                }
                {
                    this.AesGcmTagConstructorDiagId = "SYSLIB0053";
                }
                {
                    this.ThreadVolatileReadWriteMessage = "Thread.VolatileRead and Thread.VolatileWrite are obsolete. Use Volatile.Read or Volatile.Write respectively instead.";
                }
                {
                    this.ThreadVolatileReadWriteDiagId = "SYSLIB0054";
                }
                {
                    this.ArmIntrinsicPerformsUnsignedOperationMessage = "The underlying hardware instruction does not perform a signed saturate narrowing operation, and it always returns an unsigned result. Use the unsigned overload instead.";
                }
                {
                    this.ArmIntrinsicPerformsUnsignedOperationDiagId = "SYSLIB0055";
                }
                {
                    this.LoadFromHashAlgorithmMessage = "LoadFrom with a custom AssemblyHashAlgorithm is obsolete. Use overloads without an AssemblyHashAlgorithm.";
                }
                {
                    this.LoadFromHashAlgorithmDiagId = "SYSLIB0056";
                }
                {
                    this.X509CtorCertDataObsoleteMessage = "Loading certificate data through the constructor or Import is obsolete. Use X509CertificateLoader instead to load certificates.";
                }
                {
                    this.X509CtorCertDataObsoleteDiagId = "SYSLIB0057";
                }
                {
                    this.TlsCipherAlgorithmEnumsMessage = "KeyExchangeAlgorithm, KeyExchangeStrength, CipherAlgorithm, CipherStrength, HashAlgorithm and HashStrength properties of SslStream are obsolete. Use NegotiatedCipherSuite instead.";
                }
                {
                    this.TlsCipherAlgorithmEnumsDiagId = "SYSLIB0058";
                }
                {
                    this.SystemEventsEventsThreadShutdownMessage = "SystemEvents.EventsThreadShutdown callbacks are not run before the process exits. Use AppDomain.ProcessExit instead.";
                }
                {
                    this.SystemEventsEventsThreadShutdownDiagId = "SYSLIB0059";
                }
                {
                    this.Rfc2898DeriveBytesCtorMessage = "The constructors on Rfc2898DeriveBytes are obsolete. Use the static Pbkdf2 method instead.";
                }
                {
                    this.Rfc2898DeriveBytesCtorDiagId = "SYSLIB0060";
                }
                {
                    this.QueryableMinByMaxByTSourceObsoleteMessage = "The Queryable MinBy and MaxBy taking an IComparer<TSource> are obsolete. Use the new ones that take an IComparer<TKey>.";
                }
                {
                    this.QueryableMinByMaxByTSourceObsoleteDiagId = "SYSLIB0061";
                }
                {
                    this.XsltSettingsEnableScriptMessage = "XSLT Script blocks are not supported.";
                }
                {
                    this.XsltSettingsEnableScriptDiagId = "SYSLIB0062";
                }
            }
            static $h = 104586;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"l":[{"t":1310721,"n":"SharedUrlFormat","d":104586,"h":4295071882,"f":40},{"t":1310721,"n":"SystemTextEncodingUTF7Message","d":104586,"h":8590039178,"f":40},{"t":1310721,"n":"SystemTextEncodingUTF7DiagId","d":104586,"h":12885006474,"f":40},{"t":1310721,"n":"PrincipalPermissionAttributeMessage","d":104586,"h":17179973770,"f":40},{"t":1310721,"n":"PrincipalPermissionAttributeDiagId","d":104586,"h":21474941066,"f":40},{"t":1310721,"n":"CodeAccessSecurityMessage","d":104586,"h":25769908362,"f":40},{"t":1310721,"n":"CodeAccessSecurityDiagId","d":104586,"h":30064875658,"f":40},{"t":1310721,"n":"ConstrainedExecutionRegionMessage","d":104586,"h":34359842954,"f":40},{"t":1310721,"n":"ConstrainedExecutionRegionDiagId","d":104586,"h":38654810250,"f":40},{"t":1310721,"n":"GlobalAssemblyCacheMessage","d":104586,"h":42949777546,"f":40},{"t":1310721,"n":"GlobalAssemblyCacheDiagId","d":104586,"h":47244744842,"f":40},{"t":1310721,"n":"ThreadAbortMessage","d":104586,"h":51539712138,"f":40},{"t":1310721,"n":"ThreadResetAbortMessage","d":104586,"h":55834679434,"f":40},{"t":1310721,"n":"ThreadAbortDiagId","d":104586,"h":60129646730,"f":40},{"t":1310721,"n":"DefaultCryptoAlgorithmsMessage","d":104586,"h":64424614026,"f":40},{"t":1310721,"n":"DefaultCryptoAlgorithmsDiagId","d":104586,"h":68719581322,"f":40},{"t":1310721,"n":"CreatePdbGeneratorMessage","d":104586,"h":73014548618,"f":40},{"t":1310721,"n":"CreatePdbGeneratorDiagId","d":104586,"h":77309515914,"f":40},{"t":1310721,"n":"AuthenticationManagerMessage","d":104586,"h":81604483210,"f":40},{"t":1310721,"n":"AuthenticationManagerDiagId","d":104586,"h":85899450506,"f":40},{"t":1310721,"n":"RemotingApisMessage","d":104586,"h":90194417802,"f":40},{"t":1310721,"n":"RemotingApisDiagId","d":104586,"h":94489385098,"f":40},{"t":1310721,"n":"BinaryFormatterMessage","d":104586,"h":98784352394,"f":40},{"t":1310721,"n":"BinaryFormatterDiagId","d":104586,"h":103079319690,"f":40},{"t":1310721,"n":"CodeBaseMessage","d":104586,"h":107374286986,"f":40},{"t":1310721,"n":"CodeBaseDiagId","d":104586,"h":111669254282,"f":40},{"t":1310721,"n":"EscapeUriStringMessage","d":104586,"h":115964221578,"f":40},{"t":1310721,"n":"EscapeUriStringDiagId","d":104586,"h":120259188874,"f":40},{"t":1310721,"n":"WebRequestMessage","d":104586,"h":124554156170,"f":40},{"t":1310721,"n":"WebRequestDiagId","d":104586,"h":128849123466,"f":40},{"t":1310721,"n":"DisablePrivateReflectionAttributeMessage","d":104586,"h":133144090762,"f":40},{"t":1310721,"n":"DisablePrivateReflectionAttributeDiagId","d":104586,"h":137439058058,"f":40},{"t":1310721,"n":"GetContextInfoMessage","d":104586,"h":141734025354,"f":40},{"t":1310721,"n":"GetContextInfoDiagId","d":104586,"h":146028992650,"f":40},{"t":1310721,"n":"StrongNameKeyPairMessage","d":104586,"h":150323959946,"f":40},{"t":1310721,"n":"StrongNameKeyPairDiagId","d":104586,"h":154618927242,"f":40},{"t":1310721,"n":"ReflectionOnlyLoadingMessage","d":104586,"h":158913894538,"f":40},{"t":1310721,"n":"ReflectionOnlyLoadingDiagId","d":104586,"h":163208861834,"f":40},{"t":1310721,"n":"RuntimeEnvironmentMessage","d":104586,"h":167503829130,"f":40},{"t":1310721,"n":"RuntimeEnvironmentDiagId","d":104586,"h":171798796426,"f":40},{"t":1310721,"n":"JsonSerializerOptionsIgnoreNullValuesMessage","d":104586,"h":176093763722,"f":40},{"t":1310721,"n":"JsonSerializerOptionsIgnoreNullValuesDiagId","d":104586,"h":180388731018,"f":40},{"t":1310721,"n":"DerivedCryptographicTypesMessage","d":104586,"h":184683698314,"f":40},{"t":1310721,"n":"DerivedCryptographicTypesDiagId","d":104586,"h":188978665610,"f":40},{"t":1310721,"n":"RijndaelMessage","d":104586,"h":193273632906,"f":40},{"t":1310721,"n":"RijndaelDiagId","d":104586,"h":197568600202,"f":40},{"t":1310721,"n":"RNGCryptoServiceProviderMessage","d":104586,"h":201863567498,"f":40},{"t":1310721,"n":"RNGCryptoServiceProviderDiagId","d":104586,"h":206158534794,"f":40},{"t":1310721,"n":"AppDomainCreateUnloadMessage","d":104586,"h":210453502090,"f":40},{"t":1310721,"n":"AppDomainCreateUnloadDiagId","d":104586,"h":214748469386,"f":40},{"t":1310721,"n":"SuppressIldasmAttributeMessage","d":104586,"h":219043436682,"f":40},{"t":1310721,"n":"SuppressIldasmAttributeDiagId","d":104586,"h":223338403978,"f":40},{"t":1310721,"n":"X509CertificateImmutableMessage","d":104586,"h":227633371274,"f":40},{"t":1310721,"n":"X509CertificateImmutableDiagId","d":104586,"h":231928338570,"f":40},{"t":1310721,"n":"PublicKeyPropertyMessage","d":104586,"h":236223305866,"f":40},{"t":1310721,"n":"PublicKeyPropertyDiagId","d":104586,"h":240518273162,"f":40},{"t":1310721,"n":"X509CertificatePrivateKeyMessage","d":104586,"h":244813240458,"f":40},{"t":1310721,"n":"X509CertificatePrivateKeyDiagId","d":104586,"h":249108207754,"f":40},{"t":1310721,"n":"ProduceLegacyHmacValuesMessage","d":104586,"h":253403175050,"f":40},{"t":1310721,"n":"ProduceLegacyHmacValuesDiagId","d":104586,"h":257698142346,"f":40},{"t":1310721,"n":"UseManagedSha1Message","d":104586,"h":261993109642,"f":40},{"t":1310721,"n":"UseManagedSha1DiagId","d":104586,"h":266288076938,"f":40},{"t":1310721,"n":"CryptoConfigEncodeOIDMessage","d":104586,"h":270583044234,"f":40},{"t":1310721,"n":"CryptoConfigEncodeOIDDiagId","d":104586,"h":274878011530,"f":40},{"t":1310721,"n":"CorruptedStateRecoveryMessage","d":104586,"h":279172978826,"f":40},{"t":1310721,"n":"CorruptedStateRecoveryDiagId","d":104586,"h":283467946122,"f":40},{"t":1310721,"n":"Rfc2898CryptDeriveKeyMessage","d":104586,"h":287762913418,"f":40},{"t":1310721,"n":"Rfc2898CryptDeriveKeyDiagId","d":104586,"h":292057880714,"f":40},{"t":1310721,"n":"CmsSignerCspParamsCtorMessage","d":104586,"h":296352848010,"f":40},{"t":1310721,"n":"CmsSignerCspParamsCtorDiagId","d":104586,"h":300647815306,"f":40},{"t":1310721,"n":"SignerInfoCounterSigMessage","d":104586,"h":304942782602,"f":40},{"t":1310721,"n":"SignerInfoCounterSigDiagId","d":104586,"h":309237749898,"f":40},{"t":1310721,"n":"RegexCompileToAssemblyMessage","d":104586,"h":313532717194,"f":40},{"t":1310721,"n":"RegexCompileToAssemblyDiagId","d":104586,"h":317827684490,"f":40},{"t":1310721,"n":"AssemblyNameMembersMessage","d":104586,"h":322122651786,"f":40},{"t":1310721,"n":"AssemblyNameMembersDiagId","d":104586,"h":326417619082,"f":40},{"t":1310721,"n":"SystemDataSerializationFormatBinaryMessage","d":104586,"h":330712586378,"f":40},{"t":1310721,"n":"SystemDataSerializationFormatBinaryDiagId","d":104586,"h":335007553674,"f":40},{"t":1310721,"n":"TlsVersion10and11Message","d":104586,"h":339302520970,"f":40},{"t":1310721,"n":"TlsVersion10and11DiagId","d":104586,"h":343597488266,"f":40},{"t":1310721,"n":"EncryptionPolicyMessage","d":104586,"h":347892455562,"f":40},{"t":1310721,"n":"EncryptionPolicyDiagId","d":104586,"h":352187422858,"f":40},{"t":1310721,"n":"EccXmlExportImportMessage","d":104586,"h":356482390154,"f":40},{"t":1310721,"n":"EccXmlExportImportDiagId","d":104586,"h":360777357450,"f":40},{"t":1310721,"n":"EcDhPublicKeyBlobMessage","d":104586,"h":365072324746,"f":40},{"t":1310721,"n":"EcDhPublicKeyBlobDiagId","d":104586,"h":369367292042,"f":40},{"t":1310721,"n":"AssemblyNameCodeBaseMessage","d":104586,"h":373662259338,"f":40},{"t":1310721,"n":"AssemblyNameCodeBaseDiagId","d":104586,"h":377957226634,"f":40},{"t":1310721,"n":"CryptoStringFactoryMessage","d":104586,"h":382252193930,"f":40},{"t":1310721,"n":"CryptoStringFactoryDiagId","d":104586,"h":386547161226,"f":40},{"t":1310721,"n":"ControlledExecutionRunMessage","d":104586,"h":390842128522,"f":40},{"t":1310721,"n":"ControlledExecutionRunDiagId","d":104586,"h":395137095818,"f":40},{"t":1310721,"n":"XmlSecureResolverMessage","d":104586,"h":399432063114,"f":40},{"t":1310721,"n":"XmlSecureResolverDiagId","d":104586,"h":403727030410,"f":40},{"t":1310721,"n":"RsaEncryptDecryptValueMessage","d":104586,"h":408021997706,"f":40},{"t":1310721,"n":"RsaEncryptDecryptDiagId","d":104586,"h":412316965002,"f":40},{"t":1310721,"n":"JsonSerializerOptionsAddContextMessage","d":104586,"h":416611932298,"f":40},{"t":1310721,"n":"JsonSerializerOptionsAddContextDiagId","d":104586,"h":420906899594,"f":40},{"t":1310721,"n":"LegacyFormatterMessage","d":104586,"h":425201866890,"f":40},{"t":1310721,"n":"LegacyFormatterDiagId","d":104586,"h":429496834186,"f":40},{"t":1310721,"n":"LegacyFormatterImplMessage","d":104586,"h":433791801482,"f":40},{"t":1310721,"n":"LegacyFormatterImplDiagId","d":104586,"h":438086768778,"f":40},{"t":1310721,"n":"RegexExtensibilityImplMessage","d":104586,"h":442381736074,"f":40},{"t":1310721,"n":"RegexExtensibilityDiagId","d":104586,"h":446676703370,"f":40},{"t":1310721,"n":"AesGcmTagConstructorMessage","d":104586,"h":450971670666,"f":40},{"t":1310721,"n":"AesGcmTagConstructorDiagId","d":104586,"h":455266637962,"f":40},{"t":1310721,"n":"ThreadVolatileReadWriteMessage","d":104586,"h":459561605258,"f":40},{"t":1310721,"n":"ThreadVolatileReadWriteDiagId","d":104586,"h":463856572554,"f":40},{"t":1310721,"n":"ArmIntrinsicPerformsUnsignedOperationMessage","d":104586,"h":468151539850,"f":40},{"t":1310721,"n":"ArmIntrinsicPerformsUnsignedOperationDiagId","d":104586,"h":472446507146,"f":40},{"t":1310721,"n":"LoadFromHashAlgorithmMessage","d":104586,"h":476741474442,"f":40},{"t":1310721,"n":"LoadFromHashAlgorithmDiagId","d":104586,"h":481036441738,"f":40},{"t":1310721,"n":"X509CtorCertDataObsoleteMessage","d":104586,"h":485331409034,"f":40},{"t":1310721,"n":"X509CtorCertDataObsoleteDiagId","d":104586,"h":489626376330,"f":40},{"t":1310721,"n":"TlsCipherAlgorithmEnumsMessage","d":104586,"h":493921343626,"f":40},{"t":1310721,"n":"TlsCipherAlgorithmEnumsDiagId","d":104586,"h":498216310922,"f":40},{"t":1310721,"n":"SystemEventsEventsThreadShutdownMessage","d":104586,"h":502511278218,"f":40},{"t":1310721,"n":"SystemEventsEventsThreadShutdownDiagId","d":104586,"h":506806245514,"f":40},{"t":1310721,"n":"Rfc2898DeriveBytesCtorMessage","d":104586,"h":511101212810,"f":40},{"t":1310721,"n":"Rfc2898DeriveBytesCtorDiagId","d":104586,"h":515396180106,"f":40},{"t":1310721,"n":"QueryableMinByMaxByTSourceObsoleteMessage","d":104586,"h":519691147402,"f":40},{"t":1310721,"n":"QueryableMinByMaxByTSourceObsoleteDiagId","d":104586,"h":523986114698,"f":40},{"t":1310721,"n":"XsltSettingsEnableScriptMessage","d":104586,"h":528281081994,"f":40},{"t":1310721,"n":"XsltSettingsEnableScriptDiagId","d":104586,"h":532576049290,"f":40}],"h":104586}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.Obsoletions`; }
        });
        
        $asm.$cls("$srsp.System.Runtime.Serialization.ContractNamespaceAttribute", ($self) => class ContractNamespaceAttribute extends $.$spc.System.Attribute
        {
            $ctor$2(/*string*/ contractNamespace)
            {
                super.$ctor$1();
                {
                    this.ContractNamespace = contractNamespace;
                }
                return this;
            }
            /*string?*/ ClrNamespace = null;
            /*string*/ ContractNamespace = null;
            static $h = 235658;
            static $f = 0b10010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":14483457,"p":[{"p":1310721,"g":{"r":0,"d":0,"h":17180104842,"f":1},"s":{"r":0,"d":0,"h":21475072138,"f":1},"n":"ClrNamespace","d":235658,"h":12885137546,"f":1},{"p":1310721,"g":{"r":0,"d":0,"h":34359974026,"f":1},"n":"ContractNamespace","d":235658,"h":30065006730,"f":1}],"c":[{"p":[{"n":"contractNamespace","p":1310721}],"n":".ctor","o":"$ctor$2","d":235658,"h":4295202954,"f":1}],"h":235658,"a":[{"t":14614529,"c":21489451009,"a":[{"v":3,"t":14548993}],"n":[{"n":"Inherited","v":false,"t":262145},{"n":"AllowMultiple","v":true,"t":262145}]}]}; }
            static get $b() { return $.$spc.System.Attribute; }
            static get $fullName() { return `System.Runtime.Serialization.ContractNamespaceAttribute`; }
        });
        
        $asm.$cls("$srsp.System.Runtime.Serialization.DataMemberAttribute", ($self) => class DataMemberAttribute extends $.$spc.System.Attribute
        {
            /*string?*/ _name = null;
            /*bool*/ _isNameSetExplicitly = false;
            /*int*/ _order = -1;
            $ctor$2()
            {
                super.$ctor$1();
                {
                }
                return this;
            }
            /*string? */ get Name()
            {
                return this._name;
            }
            /*string? */ set Name(value)
            {
                this._name = value;
                this._isNameSetExplicitly = true;
            }
            /*bool */ get IsNameSetExplicitly()
            {
                return this._isNameSetExplicitly;
            }
            /*int */ get Order()
            {
                return this._order;
            }
            /*int */ set Order(value)
            {
                if (value < 0)
                {
                    throw new $.$srsp.System.Runtime.Serialization.InvalidDataContractException().$ctor$6($.$srsp.System.SR.OrderCannotBeNegative);
                }
                this._order = value;
            }
            /*bool*/ IsRequired = false;
            /*bool*/ EmitDefaultValue = false;
            //default member initializer
            constructor()
            {
                super();
                this.IsRequired = false;
                this.EmitDefaultValue = true;
            }
            static $h = 366730;
            static $f = 0b10010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":14483457,"p":[{"p":1310721,"g":{"r":0,"d":0,"h":25770170506,"f":1},"s":{"r":0,"d":0,"h":30065137802,"f":1},"n":"Name","d":366730,"h":21475203210,"f":1},{"p":262145,"g":{"r":0,"d":0,"h":38655072394,"f":1},"n":"IsNameSetExplicitly","d":366730,"h":34360105098,"f":1},{"p":655361,"g":{"r":0,"d":0,"h":47245006986,"f":1},"s":{"r":0,"d":0,"h":51539974282,"f":1},"n":"Order","d":366730,"h":42950039690,"f":1},{"p":262145,"g":{"r":0,"d":0,"h":64424876170,"f":1},"s":{"r":0,"d":0,"h":68719843466,"f":1},"n":"IsRequired","d":366730,"h":60129908874,"f":1},{"p":262145,"g":{"r":0,"d":0,"h":81604745354,"f":1},"s":{"r":0,"d":0,"h":85899712650,"f":1},"n":"EmitDefaultValue","d":366730,"h":77309778058,"f":1}],"l":[{"t":1310721,"n":"_name","d":366730,"h":4295334026,"f":2},{"t":262145,"n":"_isNameSetExplicitly","d":366730,"h":8590301322,"f":2},{"t":655361,"n":"_order","d":366730,"h":12885268618,"f":2}],"c":[{"n":".ctor","o":"$ctor$2","d":366730,"h":17180235914,"f":1}],"h":366730,"a":[{"t":14614529,"c":21489451009,"a":[{"v":384,"t":14548993}],"n":[{"n":"Inherited","v":false,"t":262145},{"n":"AllowMultiple","v":false,"t":262145}]}]}; }
            static get $b() { return $.$spc.System.Attribute; }
            static get $fullName() { return `System.Runtime.Serialization.DataMemberAttribute`; }
        });
        
        $asm.$cls("$srsp.System.Runtime.Serialization.DataContractAttribute", ($self) => class DataContractAttribute extends $.$spc.System.Attribute
        {
            /*string?*/ _name = null;
            /*string?*/ _ns = null;
            /*bool*/ _isNameSetExplicitly = false;
            /*bool*/ _isNamespaceSetExplicitly = false;
            /*bool*/ _isReference = false;
            /*bool*/ _isReferenceSetExplicitly = false;
            $ctor$2()
            {
                super.$ctor$1();
                {
                }
                return this;
            }
            /*bool */ get IsReference()
            {
                return this._isReference;
            }
            /*bool */ set IsReference(value)
            {
                this._isReference = value;
                this._isReferenceSetExplicitly = true;
            }
            /*bool */ get IsReferenceSetExplicitly()
            {
                return this._isReferenceSetExplicitly;
            }
            /*string? */ get Namespace()
            {
                return this._ns;
            }
            /*string? */ set Namespace(value)
            {
                this._ns = value;
                this._isNamespaceSetExplicitly = true;
            }
            /*bool */ get IsNamespaceSetExplicitly()
            {
                return this._isNamespaceSetExplicitly;
            }
            /*string? */ get Name()
            {
                return this._name;
            }
            /*string? */ set Name(value)
            {
                this._name = value;
                this._isNameSetExplicitly = true;
            }
            /*bool */ get IsNameSetExplicitly()
            {
                return this._isNameSetExplicitly;
            }
            static $h = 301194;
            static $f = 0b10010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":14483457,"p":[{"p":262145,"g":{"r":0,"d":0,"h":38655006858,"f":1},"s":{"r":0,"d":0,"h":42949974154,"f":1},"n":"IsReference","d":301194,"h":34360039562,"f":1},{"p":262145,"g":{"r":0,"d":0,"h":51539908746,"f":1},"n":"IsReferenceSetExplicitly","d":301194,"h":47244941450,"f":1},{"p":1310721,"g":{"r":0,"d":0,"h":60129843338,"f":1},"s":{"r":0,"d":0,"h":64424810634,"f":1},"n":"Namespace","d":301194,"h":55834876042,"f":1},{"p":262145,"g":{"r":0,"d":0,"h":73014745226,"f":1},"n":"IsNamespaceSetExplicitly","d":301194,"h":68719777930,"f":1},{"p":1310721,"g":{"r":0,"d":0,"h":81604679818,"f":1},"s":{"r":0,"d":0,"h":85899647114,"f":1},"n":"Name","d":301194,"h":77309712522,"f":1},{"p":262145,"g":{"r":0,"d":0,"h":94489581706,"f":1},"n":"IsNameSetExplicitly","d":301194,"h":90194614410,"f":1}],"l":[{"t":1310721,"n":"_name","d":301194,"h":4295268490,"f":2},{"t":1310721,"n":"_ns","d":301194,"h":8590235786,"f":2},{"t":262145,"n":"_isNameSetExplicitly","d":301194,"h":12885203082,"f":2},{"t":262145,"n":"_isNamespaceSetExplicitly","d":301194,"h":17180170378,"f":2},{"t":262145,"n":"_isReference","d":301194,"h":21475137674,"f":2},{"t":262145,"n":"_isReferenceSetExplicitly","d":301194,"h":25770104970,"f":2}],"c":[{"n":".ctor","o":"$ctor$2","d":301194,"h":30065072266,"f":1}],"h":301194,"a":[{"t":14614529,"c":21489451009,"a":[{"v":28,"t":14548993}],"n":[{"n":"Inherited","v":false,"t":262145},{"n":"AllowMultiple","v":false,"t":262145}]}]}; }
            static get $b() { return $.$spc.System.Attribute; }
            static get $fullName() { return `System.Runtime.Serialization.DataContractAttribute`; }
        });
        
        $asm.$cls("$srsp.System.Runtime.Serialization.CollectionDataContractAttribute", ($self) => class CollectionDataContractAttribute extends $.$spc.System.Attribute
        {
            /*string?*/ _name = null;
            /*string?*/ _ns = null;
            /*string?*/ _itemName = null;
            /*string?*/ _keyName = null;
            /*string?*/ _valueName = null;
            /*bool*/ _isReference = false;
            /*bool*/ _isNameSetExplicitly = false;
            /*bool*/ _isNamespaceSetExplicitly = false;
            /*bool*/ _isReferenceSetExplicitly = false;
            /*bool*/ _isItemNameSetExplicitly = false;
            /*bool*/ _isKeyNameSetExplicitly = false;
            /*bool*/ _isValueNameSetExplicitly = false;
            $ctor$2()
            {
                super.$ctor$1();
                {
                }
                return this;
            }
            /*string? */ get Namespace()
            {
                return this._ns;
            }
            /*string? */ set Namespace(value)
            {
                this._ns = value;
                this._isNamespaceSetExplicitly = true;
            }
            /*bool */ get IsNamespaceSetExplicitly()
            {
                return this._isNamespaceSetExplicitly;
            }
            /*string? */ get Name()
            {
                return this._name;
            }
            /*string? */ set Name(value)
            {
                this._name = value;
                this._isNameSetExplicitly = true;
            }
            /*bool */ get IsNameSetExplicitly()
            {
                return this._isNameSetExplicitly;
            }
            /*string? */ get ItemName()
            {
                return this._itemName;
            }
            /*string? */ set ItemName(value)
            {
                this._itemName = value;
                this._isItemNameSetExplicitly = true;
            }
            /*bool */ get IsItemNameSetExplicitly()
            {
                return this._isItemNameSetExplicitly;
            }
            /*string? */ get KeyName()
            {
                return this._keyName;
            }
            /*string? */ set KeyName(value)
            {
                this._keyName = value;
                this._isKeyNameSetExplicitly = true;
            }
            /*bool */ get IsKeyNameSetExplicitly()
            {
                return this._isKeyNameSetExplicitly;
            }
            /*bool */ get IsReference()
            {
                return this._isReference;
            }
            /*bool */ set IsReference(value)
            {
                this._isReference = value;
                this._isReferenceSetExplicitly = true;
            }
            /*bool */ get IsReferenceSetExplicitly()
            {
                return this._isReferenceSetExplicitly;
            }
            /*string? */ get ValueName()
            {
                return this._valueName;
            }
            /*string? */ set ValueName(value)
            {
                this._valueName = value;
                this._isValueNameSetExplicitly = true;
            }
            /*bool */ get IsValueNameSetExplicitly()
            {
                return this._isValueNameSetExplicitly;
            }
            static $h = 170122;
            static $f = 0b10010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":14483457,"p":[{"p":1310721,"g":{"r":0,"d":0,"h":64424679562,"f":1},"s":{"r":0,"d":0,"h":68719646858,"f":1},"n":"Namespace","d":170122,"h":60129712266,"f":1},{"p":262145,"g":{"r":0,"d":0,"h":77309581450,"f":1},"n":"IsNamespaceSetExplicitly","d":170122,"h":73014614154,"f":1},{"p":1310721,"g":{"r":0,"d":0,"h":85899516042,"f":1},"s":{"r":0,"d":0,"h":90194483338,"f":1},"n":"Name","d":170122,"h":81604548746,"f":1},{"p":262145,"g":{"r":0,"d":0,"h":98784417930,"f":1},"n":"IsNameSetExplicitly","d":170122,"h":94489450634,"f":1},{"p":1310721,"g":{"r":0,"d":0,"h":107374352522,"f":1},"s":{"r":0,"d":0,"h":111669319818,"f":1},"n":"ItemName","d":170122,"h":103079385226,"f":1},{"p":262145,"g":{"r":0,"d":0,"h":120259254410,"f":1},"n":"IsItemNameSetExplicitly","d":170122,"h":115964287114,"f":1},{"p":1310721,"g":{"r":0,"d":0,"h":128849189002,"f":1},"s":{"r":0,"d":0,"h":133144156298,"f":1},"n":"KeyName","d":170122,"h":124554221706,"f":1},{"p":262145,"g":{"r":0,"d":0,"h":141734090890,"f":1},"n":"IsKeyNameSetExplicitly","d":170122,"h":137439123594,"f":1},{"p":262145,"g":{"r":0,"d":0,"h":150324025482,"f":1},"s":{"r":0,"d":0,"h":154618992778,"f":1},"n":"IsReference","d":170122,"h":146029058186,"f":1},{"p":262145,"g":{"r":0,"d":0,"h":163208927370,"f":1},"n":"IsReferenceSetExplicitly","d":170122,"h":158913960074,"f":1},{"p":1310721,"g":{"r":0,"d":0,"h":171798861962,"f":1},"s":{"r":0,"d":0,"h":176093829258,"f":1},"n":"ValueName","d":170122,"h":167503894666,"f":1},{"p":262145,"g":{"r":0,"d":0,"h":184683763850,"f":1},"n":"IsValueNameSetExplicitly","d":170122,"h":180388796554,"f":1}],"l":[{"t":1310721,"n":"_name","d":170122,"h":4295137418,"f":2},{"t":1310721,"n":"_ns","d":170122,"h":8590104714,"f":2},{"t":1310721,"n":"_itemName","d":170122,"h":12885072010,"f":2},{"t":1310721,"n":"_keyName","d":170122,"h":17180039306,"f":2},{"t":1310721,"n":"_valueName","d":170122,"h":21475006602,"f":2},{"t":262145,"n":"_isReference","d":170122,"h":25769973898,"f":2},{"t":262145,"n":"_isNameSetExplicitly","d":170122,"h":30064941194,"f":2},{"t":262145,"n":"_isNamespaceSetExplicitly","d":170122,"h":34359908490,"f":2},{"t":262145,"n":"_isReferenceSetExplicitly","d":170122,"h":38654875786,"f":2},{"t":262145,"n":"_isItemNameSetExplicitly","d":170122,"h":42949843082,"f":2},{"t":262145,"n":"_isKeyNameSetExplicitly","d":170122,"h":47244810378,"f":2},{"t":262145,"n":"_isValueNameSetExplicitly","d":170122,"h":51539777674,"f":2}],"c":[{"n":".ctor","o":"$ctor$2","d":170122,"h":55834744970,"f":1}],"h":170122,"a":[{"t":14614529,"c":21489451009,"a":[{"v":12,"t":14548993}],"n":[{"n":"Inherited","v":false,"t":262145},{"n":"AllowMultiple","v":false,"t":262145}]}]}; }
            static get $b() { return $.$spc.System.Attribute; }
            static get $fullName() { return `System.Runtime.Serialization.CollectionDataContractAttribute`; }
        });
        
        $asm.$cls("$srsp.System.Runtime.Serialization.EnumMemberAttribute", ($self) => class EnumMemberAttribute extends $.$spc.System.Attribute
        {
            /*string?*/ _value = null;
            /*bool*/ _isValueSetExplicitly = false;
            $ctor$2()
            {
                super.$ctor$1();
                {
                }
                return this;
            }
            /*string? */ get Value()
            {
                return this._value;
            }
            /*string? */ set Value(value)
            {
                this._value = value;
                this._isValueSetExplicitly = true;
            }
            /*bool */ get IsValueSetExplicitly()
            {
                return this._isValueSetExplicitly;
            }
            static $h = 432266;
            static $f = 0b10010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":14483457,"p":[{"p":1310721,"g":{"r":0,"d":0,"h":21475268746,"f":1},"s":{"r":0,"d":0,"h":25770236042,"f":1},"n":"Value","d":432266,"h":17180301450,"f":1},{"p":262145,"g":{"r":0,"d":0,"h":34360170634,"f":1},"n":"IsValueSetExplicitly","d":432266,"h":30065203338,"f":1}],"l":[{"t":1310721,"n":"_value","d":432266,"h":4295399562,"f":2},{"t":262145,"n":"_isValueSetExplicitly","d":432266,"h":8590366858,"f":2}],"c":[{"n":".ctor","o":"$ctor$2","d":432266,"h":12885334154,"f":1}],"h":432266,"a":[{"t":14614529,"c":21489451009,"a":[{"v":256,"t":14548993}],"n":[{"n":"Inherited","v":false,"t":262145},{"n":"AllowMultiple","v":false,"t":262145}]}]}; }
            static get $b() { return $.$spc.System.Attribute; }
            static get $fullName() { return `System.Runtime.Serialization.EnumMemberAttribute`; }
        });
        
        $asm.$cls("$srsp.System.Runtime.Serialization.IgnoreDataMemberAttribute", ($self) => class IgnoreDataMemberAttribute extends $.$spc.System.Attribute
        {
            $ctor$2()
            {
                super.$ctor$1();
                {
                }
                return this;
            }
            static $h = 497802;
            static $f = 0b10010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":14483457,"c":[{"n":".ctor","o":"$ctor$2","d":497802,"h":4295465098,"f":1}],"h":497802,"a":[{"t":14614529,"c":21489451009,"a":[{"v":384,"t":14548993}],"n":[{"n":"Inherited","v":false,"t":262145},{"n":"AllowMultiple","v":false,"t":262145}]}]}; }
            static get $b() { return $.$spc.System.Attribute; }
            static get $fullName() { return `System.Runtime.Serialization.IgnoreDataMemberAttribute`; }
        });
        
        $asm.$cls("$srsp.System.Runtime.Serialization.KnownTypeAttribute", ($self) => class KnownTypeAttribute extends $.$spc.System.Attribute
        {
            $ctor$2(/*Type*/ type)
            {
                super.$ctor$1();
                {
                    this.Type = type;
                }
                return this;
            }
            $ctor$3(/*string*/ methodName)
            {
                super.$ctor$1();
                {
                    this.MethodName = methodName;
                }
                return this;
            }
            /*string?*/ MethodName = null;
            /*Type?*/ Type = null;
            static $h = 759946;
            static $f = 0b10010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":14483457,"p":[{"p":1310721,"g":{"r":0,"d":0,"h":21475596426,"f":1},"n":"MethodName","d":759946,"h":17180629130,"f":1},{"p":142606337,"g":{"r":0,"d":0,"h":34360498314,"f":1},"n":"Type","d":759946,"h":30065531018,"f":1}],"c":[{"p":[{"n":"type","p":142606337}],"n":".ctor","o":"$ctor$2","d":759946,"h":4295727242,"f":1},{"p":[{"n":"methodName","p":1310721}],"n":".ctor","o":"$ctor$3","d":759946,"h":8590694538,"f":1}],"h":759946,"a":[{"t":14614529,"c":21489451009,"a":[{"v":12,"t":14548993}],"n":[{"n":"Inherited","v":true,"t":262145},{"n":"AllowMultiple","v":true,"t":262145}]}]}; }
            static get $b() { return $.$spc.System.Attribute; }
            static get $fullName() { return `System.Runtime.Serialization.KnownTypeAttribute`; }
        });
        
        $asm.$cls("$srsp.System.Runtime.Serialization.InvalidDataContractException", ($self) => class InvalidDataContractException extends $.$spc.System.Exception
        {
            $ctor$5()
            {
                super.$ctor$1();
                {
                }
                return this;
            }
            $ctor$6(/*string?*/ message)
            {
                super.$ctor$2(message);
                {
                }
                return this;
            }
            $ctor$7(/*string?*/ message, /*Exception?*/ innerException)
            {
                super.$ctor$3(message, innerException);
                {
                }
                return this;
            }
            $ctor$8(/*SerializationInfo*/ info, /*StreamingContext*/ context)
            {
                super.$ctor$4(info, context);
                {
                }
                return this;
            }
            static $h = 563338;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":47185921,"h":563338}; }
            static get $b() { return $.$spc.System.Exception; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.Runtime.Serialization.ISerializable ]; }
            static get $fullName() { return `System.Runtime.Serialization.InvalidDataContractException`; }
        });
	});
})(window, window.NetJs.$boot(), ...window.NetJs.$require("NetJs.System.Private.CoreLib", "NetJs.System.Memory", "NetJs.System.Private.Uri", "NetJs.System.Runtime"))