
(function ($global, $, $spc, $sm, $spu, $sr) {
    "use strict";
    let _;
    
    
    
	$.$asm(
    "NetJs.System.Runtime.Serialization.Primitives", 
    {"h":46565,"f":"System.Runtime.Serialization.Primitives","v":"1.0.35.0","a":[{"t":96337921,"c":4391305217,"a":[{"v":113442817,"t":142606337}]},{"t":96337921,"c":4391305217,"a":[{"v":113508353,"t":142606337}]},{"t":96337921,"c":4391305217,"a":[{"v":113573889,"t":142606337}]},{"t":96337921,"c":4391305217,"a":[{"v":113639425,"t":142606337}]},{"t":96337921,"c":4391305217,"a":[{"v":113901569,"t":142606337}]},{"t":96337921,"c":4391305217,"a":[{"v":114098177,"t":142606337}]},{"t":96337921,"c":4391305217,"a":[{"v":114163713,"t":142606337}]},{"t":115146753,"c":13000048641,"a":[{"v":".NETCoreApp,Version=v10.0","t":1310721}],"n":[{"n":"FrameworkDisplayName","v":".NET 10.0","t":1310721}]},{"t":73596929,"c":4368564225,"a":[{"v":"SIT","t":1310721}]},{"t":73662465,"c":4368629761,"a":[{"v":"Debug","t":1310721}]},{"t":74121217,"c":4369088513,"a":[{"v":"1.0.35.0","t":1310721}]},{"t":74252289,"c":4369219585,"a":[{"v":"1.0.35\u002Bf7a34a6f78fee11131301a9f55ca16a968616013","t":1310721}]},{"t":75104257,"c":4370071553,"a":[{"v":"NetJs.System.Runtime.Serialization.Primitives","t":1310721}]},{"t":75235329,"c":4370202625,"a":[{"v":"NetJs.System.Runtime.Serialization.Primitives","t":1310721}]},{"t":75366401,"c":4370333697,"a":[{"v":"1.0.35.0","t":1310721}]},{"t":115212289,"c":4410179585,"a":[{"v":"browser1.0","t":1310721}]},{"t":114950145,"c":4409917441,"a":[{"v":"browser1.0","t":1310721}]}],"m":[]},
    function($asm)
	{
        
        
        $asm.$cls("$srsp.System.Runtime.Serialization.ISerializationSurrogateProvider", ($self) => class ISerializationSurrogateProvider
        {
            static $h = 636389;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {"m":[{"r":142606337,"p":[{"n":"type","p":142606337}],"n":"GetSurrogateType","o":"System$Runtime$Serialization$ISerializationSurrogateProvider$GetSurrogateType","d":636389,"h":4295603685,"f":257},{"r":131073,"p":[{"n":"obj","p":131073},{"n":"targetType","p":142606337}],"n":"GetObjectToSerialize","o":"System$Runtime$Serialization$ISerializationSurrogateProvider$GetObjectToSerialize","d":636389,"h":8590570981,"f":257},{"r":131073,"p":[{"n":"obj","p":131073},{"n":"targetType","p":142606337}],"n":"GetDeserializedObject","o":"System$Runtime$Serialization$ISerializationSurrogateProvider$GetDeserializedObject","d":636389,"h":12885538277,"f":257}],"h":636389}; }
            static get $fullName() { return `System.Runtime.Serialization.ISerializationSurrogateProvider`; }
        });
        
        $asm.$cls("$srsp.System.Runtime.Serialization.ISerializationSurrogateProvider2", ($self) => class ISerializationSurrogateProvider2
        {
            static $h = 701925;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {"m":[{"r":131073,"p":[{"n":"memberInfo","p":78249985},{"n":"dataContractType","p":142606337}],"n":"GetCustomDataToExport","o":"System$Runtime$Serialization$ISerializationSurrogateProvider2$GetCustomDataToExport","d":701925,"h":4295669221,"f":257},{"r":131073,"p":[{"n":"runtimeType","p":142606337},{"n":"dataContractType","p":142606337}],"n":"GetCustomDataToExport","o":"System$Runtime$Serialization$ISerializationSurrogateProvider2$GetCustomDataToExport$1","d":701925,"h":8590636517,"f":257},{"r":65537,"p":[{"n":"customDataTypes","p":$.$spc.System.Collections.ObjectModel.Collection$$($.$spc.System.Type).$h}],"n":"GetKnownCustomDataTypes","o":"System$Runtime$Serialization$ISerializationSurrogateProvider2$GetKnownCustomDataTypes","d":701925,"h":12885603813,"f":257},{"r":142606337,"p":[{"n":"typeName","p":1310721},{"n":"typeNamespace","p":1310721},{"n":"customData","p":131073}],"n":"GetReferencedTypeOnImport","o":"System$Runtime$Serialization$ISerializationSurrogateProvider2$GetReferencedTypeOnImport","d":701925,"h":17180571109,"f":257}],"i":[636389],"h":701925}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$srsp.System.Runtime.Serialization.ISerializationSurrogateProvider ]; }
            static get $fullName() { return `System.Runtime.Serialization.ISerializationSurrogateProvider2`; }
        });
        
        $asm.$cls("$srsp.System.Obsoletions", ($self) => class Obsoletions
        {
            /*string*/ static SharedUrlFormat = null;
            /*string*/ static SystemTextEncodingUTF7Message = null;
            /*string*/ static SystemTextEncodingUTF7DiagId = null;
            /*string*/ static PrincipalPermissionAttributeMessage = null;
            /*string*/ static PrincipalPermissionAttributeDiagId = null;
            /*string*/ static CodeAccessSecurityMessage = null;
            /*string*/ static CodeAccessSecurityDiagId = null;
            /*string*/ static ConstrainedExecutionRegionMessage = null;
            /*string*/ static ConstrainedExecutionRegionDiagId = null;
            /*string*/ static GlobalAssemblyCacheMessage = null;
            /*string*/ static GlobalAssemblyCacheDiagId = null;
            /*string*/ static ThreadAbortMessage = null;
            /*string*/ static ThreadResetAbortMessage = null;
            /*string*/ static ThreadAbortDiagId = null;
            /*string*/ static DefaultCryptoAlgorithmsMessage = null;
            /*string*/ static DefaultCryptoAlgorithmsDiagId = null;
            /*string*/ static CreatePdbGeneratorMessage = null;
            /*string*/ static CreatePdbGeneratorDiagId = null;
            /*string*/ static AuthenticationManagerMessage = null;
            /*string*/ static AuthenticationManagerDiagId = null;
            /*string*/ static RemotingApisMessage = null;
            /*string*/ static RemotingApisDiagId = null;
            /*string*/ static BinaryFormatterMessage = null;
            /*string*/ static BinaryFormatterDiagId = null;
            /*string*/ static CodeBaseMessage = null;
            /*string*/ static CodeBaseDiagId = null;
            /*string*/ static EscapeUriStringMessage = null;
            /*string*/ static EscapeUriStringDiagId = null;
            /*string*/ static WebRequestMessage = null;
            /*string*/ static WebRequestDiagId = null;
            /*string*/ static DisablePrivateReflectionAttributeMessage = null;
            /*string*/ static DisablePrivateReflectionAttributeDiagId = null;
            /*string*/ static GetContextInfoMessage = null;
            /*string*/ static GetContextInfoDiagId = null;
            /*string*/ static StrongNameKeyPairMessage = null;
            /*string*/ static StrongNameKeyPairDiagId = null;
            /*string*/ static ReflectionOnlyLoadingMessage = null;
            /*string*/ static ReflectionOnlyLoadingDiagId = null;
            /*string*/ static RuntimeEnvironmentMessage = null;
            /*string*/ static RuntimeEnvironmentDiagId = null;
            /*string*/ static JsonSerializerOptionsIgnoreNullValuesMessage = null;
            /*string*/ static JsonSerializerOptionsIgnoreNullValuesDiagId = null;
            /*string*/ static DerivedCryptographicTypesMessage = null;
            /*string*/ static DerivedCryptographicTypesDiagId = null;
            /*string*/ static RijndaelMessage = null;
            /*string*/ static RijndaelDiagId = null;
            /*string*/ static RNGCryptoServiceProviderMessage = null;
            /*string*/ static RNGCryptoServiceProviderDiagId = null;
            /*string*/ static AppDomainCreateUnloadMessage = null;
            /*string*/ static AppDomainCreateUnloadDiagId = null;
            /*string*/ static SuppressIldasmAttributeMessage = null;
            /*string*/ static SuppressIldasmAttributeDiagId = null;
            /*string*/ static X509CertificateImmutableMessage = null;
            /*string*/ static X509CertificateImmutableDiagId = null;
            /*string*/ static PublicKeyPropertyMessage = null;
            /*string*/ static PublicKeyPropertyDiagId = null;
            /*string*/ static X509CertificatePrivateKeyMessage = null;
            /*string*/ static X509CertificatePrivateKeyDiagId = null;
            /*string*/ static ProduceLegacyHmacValuesMessage = null;
            /*string*/ static ProduceLegacyHmacValuesDiagId = null;
            /*string*/ static UseManagedSha1Message = null;
            /*string*/ static UseManagedSha1DiagId = null;
            /*string*/ static CryptoConfigEncodeOIDMessage = null;
            /*string*/ static CryptoConfigEncodeOIDDiagId = null;
            /*string*/ static CorruptedStateRecoveryMessage = null;
            /*string*/ static CorruptedStateRecoveryDiagId = null;
            /*string*/ static Rfc2898CryptDeriveKeyMessage = null;
            /*string*/ static Rfc2898CryptDeriveKeyDiagId = null;
            /*string*/ static CmsSignerCspParamsCtorMessage = null;
            /*string*/ static CmsSignerCspParamsCtorDiagId = null;
            /*string*/ static SignerInfoCounterSigMessage = null;
            /*string*/ static SignerInfoCounterSigDiagId = null;
            /*string*/ static RegexCompileToAssemblyMessage = null;
            /*string*/ static RegexCompileToAssemblyDiagId = null;
            /*string*/ static AssemblyNameMembersMessage = null;
            /*string*/ static AssemblyNameMembersDiagId = null;
            /*string*/ static SystemDataSerializationFormatBinaryMessage = null;
            /*string*/ static SystemDataSerializationFormatBinaryDiagId = null;
            /*string*/ static TlsVersion10and11Message = null;
            /*string*/ static TlsVersion10and11DiagId = null;
            /*string*/ static EncryptionPolicyMessage = null;
            /*string*/ static EncryptionPolicyDiagId = null;
            /*string*/ static EccXmlExportImportMessage = null;
            /*string*/ static EccXmlExportImportDiagId = null;
            /*string*/ static EcDhPublicKeyBlobMessage = null;
            /*string*/ static EcDhPublicKeyBlobDiagId = null;
            /*string*/ static AssemblyNameCodeBaseMessage = null;
            /*string*/ static AssemblyNameCodeBaseDiagId = null;
            /*string*/ static CryptoStringFactoryMessage = null;
            /*string*/ static CryptoStringFactoryDiagId = null;
            /*string*/ static ControlledExecutionRunMessage = null;
            /*string*/ static ControlledExecutionRunDiagId = null;
            /*string*/ static XmlSecureResolverMessage = null;
            /*string*/ static XmlSecureResolverDiagId = null;
            /*string*/ static RsaEncryptDecryptValueMessage = null;
            /*string*/ static RsaEncryptDecryptDiagId = null;
            /*string*/ static JsonSerializerOptionsAddContextMessage = null;
            /*string*/ static JsonSerializerOptionsAddContextDiagId = null;
            /*string*/ static LegacyFormatterMessage = null;
            /*string*/ static LegacyFormatterDiagId = null;
            /*string*/ static LegacyFormatterImplMessage = null;
            /*string*/ static LegacyFormatterImplDiagId = null;
            /*string*/ static RegexExtensibilityImplMessage = null;
            /*string*/ static RegexExtensibilityDiagId = null;
            /*string*/ static AesGcmTagConstructorMessage = null;
            /*string*/ static AesGcmTagConstructorDiagId = null;
            /*string*/ static ThreadVolatileReadWriteMessage = null;
            /*string*/ static ThreadVolatileReadWriteDiagId = null;
            /*string*/ static ArmIntrinsicPerformsUnsignedOperationMessage = null;
            /*string*/ static ArmIntrinsicPerformsUnsignedOperationDiagId = null;
            /*string*/ static LoadFromHashAlgorithmMessage = null;
            /*string*/ static LoadFromHashAlgorithmDiagId = null;
            /*string*/ static X509CtorCertDataObsoleteMessage = null;
            /*string*/ static X509CtorCertDataObsoleteDiagId = null;
            /*string*/ static TlsCipherAlgorithmEnumsMessage = null;
            /*string*/ static TlsCipherAlgorithmEnumsDiagId = null;
            /*string*/ static SystemEventsEventsThreadShutdownMessage = null;
            /*string*/ static SystemEventsEventsThreadShutdownDiagId = null;
            /*string*/ static Rfc2898DeriveBytesCtorMessage = null;
            /*string*/ static Rfc2898DeriveBytesCtorDiagId = null;
            /*string*/ static QueryableMinByMaxByTSourceObsoleteMessage = null;
            /*string*/ static QueryableMinByMaxByTSourceObsoleteDiagId = null;
            /*string*/ static XsltSettingsEnableScriptMessage = null;
            /*string*/ static XsltSettingsEnableScriptDiagId = null;
            //Static Initializer
            static $sinit()
            {
                {
                    this.SharedUrlFormat = "https://aka.ms/dotnet-warnings/{0}";
                }
                {
                    this.SystemTextEncodingUTF7Message = "The UTF-7 encoding is insecure and should not be used. Consider using UTF-8 instead.";
                }
                {
                    this.SystemTextEncodingUTF7DiagId = "SYSLIB0001";
                }
                {
                    this.PrincipalPermissionAttributeMessage = "PrincipalPermissionAttribute is not honored by the runtime and must not be used.";
                }
                {
                    this.PrincipalPermissionAttributeDiagId = "SYSLIB0002";
                }
                {
                    this.CodeAccessSecurityMessage = "Code Access Security is not supported or honored by the runtime.";
                }
                {
                    this.CodeAccessSecurityDiagId = "SYSLIB0003";
                }
                {
                    this.ConstrainedExecutionRegionMessage = "The Constrained Execution Region (CER) feature is not supported.";
                }
                {
                    this.ConstrainedExecutionRegionDiagId = "SYSLIB0004";
                }
                {
                    this.GlobalAssemblyCacheMessage = "The Global Assembly Cache is not supported.";
                }
                {
                    this.GlobalAssemblyCacheDiagId = "SYSLIB0005";
                }
                {
                    this.ThreadAbortMessage = "Thread.Abort is not supported and throws PlatformNotSupportedException.";
                }
                {
                    this.ThreadResetAbortMessage = "Thread.ResetAbort is not supported and throws PlatformNotSupportedException.";
                }
                {
                    this.ThreadAbortDiagId = "SYSLIB0006";
                }
                {
                    this.DefaultCryptoAlgorithmsMessage = "The default implementation of this cryptography algorithm is not supported.";
                }
                {
                    this.DefaultCryptoAlgorithmsDiagId = "SYSLIB0007";
                }
                {
                    this.CreatePdbGeneratorMessage = "The CreatePdbGenerator API is not supported and throws PlatformNotSupportedException.";
                }
                {
                    this.CreatePdbGeneratorDiagId = "SYSLIB0008";
                }
                {
                    this.AuthenticationManagerMessage = "AuthenticationManager is not supported. Methods will no-op or throw PlatformNotSupportedException.";
                }
                {
                    this.AuthenticationManagerDiagId = "SYSLIB0009";
                }
                {
                    this.RemotingApisMessage = "This Remoting API is not supported and throws PlatformNotSupportedException.";
                }
                {
                    this.RemotingApisDiagId = "SYSLIB0010";
                }
                {
                    this.BinaryFormatterMessage = "BinaryFormatter serialization is obsolete and should not be used. See https://aka.ms/binaryformatter for more information.";
                }
                {
                    this.BinaryFormatterDiagId = "SYSLIB0011";
                }
                {
                    this.CodeBaseMessage = "Assembly.CodeBase and Assembly.EscapedCodeBase are only included for .NET Framework compatibility. Use Assembly.Location instead.";
                }
                {
                    this.CodeBaseDiagId = "SYSLIB0012";
                }
                {
                    this.EscapeUriStringMessage = "Uri.EscapeUriString can corrupt the Uri string in some cases. Consider using Uri.EscapeDataString for query string components instead.";
                }
                {
                    this.EscapeUriStringDiagId = "SYSLIB0013";
                }
                {
                    this.WebRequestMessage = "WebRequest, HttpWebRequest, ServicePoint, and WebClient are obsolete. Use HttpClient instead.";
                }
                {
                    this.WebRequestDiagId = "SYSLIB0014";
                }
                {
                    this.DisablePrivateReflectionAttributeMessage = "DisablePrivateReflectionAttribute has no effect in .NET 6.0+.";
                }
                {
                    this.DisablePrivateReflectionAttributeDiagId = "SYSLIB0015";
                }
                {
                    this.GetContextInfoMessage = "Use the Graphics.GetContextInfo overloads that accept arguments for better performance and fewer allocations.";
                }
                {
                    this.GetContextInfoDiagId = "SYSLIB0016";
                }
                {
                    this.StrongNameKeyPairMessage = "Strong name signing is not supported and throws PlatformNotSupportedException.";
                }
                {
                    this.StrongNameKeyPairDiagId = "SYSLIB0017";
                }
                {
                    this.ReflectionOnlyLoadingMessage = "ReflectionOnly loading is not supported and throws PlatformNotSupportedException.";
                }
                {
                    this.ReflectionOnlyLoadingDiagId = "SYSLIB0018";
                }
                {
                    this.RuntimeEnvironmentMessage = "RuntimeEnvironment members SystemConfigurationFile, GetRuntimeInterfaceAsIntPtr, and GetRuntimeInterfaceAsObject are not supported and throw PlatformNotSupportedException.";
                }
                {
                    this.RuntimeEnvironmentDiagId = "SYSLIB0019";
                }
                {
                    this.JsonSerializerOptionsIgnoreNullValuesMessage = "JsonSerializerOptions.IgnoreNullValues is obsolete. To ignore null values when serializing, set DefaultIgnoreCondition to JsonIgnoreCondition.WhenWritingNull.";
                }
                {
                    this.JsonSerializerOptionsIgnoreNullValuesDiagId = "SYSLIB0020";
                }
                {
                    this.DerivedCryptographicTypesMessage = "Derived cryptographic types are obsolete. Use the Create method on the base type instead.";
                }
                {
                    this.DerivedCryptographicTypesDiagId = "SYSLIB0021";
                }
                {
                    this.RijndaelMessage = "The Rijndael and RijndaelManaged types are obsolete. Use Aes instead.";
                }
                {
                    this.RijndaelDiagId = "SYSLIB0022";
                }
                {
                    this.RNGCryptoServiceProviderMessage = "RNGCryptoServiceProvider is obsolete. To generate a random number, use one of the RandomNumberGenerator static methods instead.";
                }
                {
                    this.RNGCryptoServiceProviderDiagId = "SYSLIB0023";
                }
                {
                    this.AppDomainCreateUnloadMessage = "Creating and unloading AppDomains is not supported and throws an exception.";
                }
                {
                    this.AppDomainCreateUnloadDiagId = "SYSLIB0024";
                }
                {
                    this.SuppressIldasmAttributeMessage = "SuppressIldasmAttribute has no effect in .NET 6.0+.";
                }
                {
                    this.SuppressIldasmAttributeDiagId = "SYSLIB0025";
                }
                {
                    this.X509CertificateImmutableMessage = "X509Certificate and X509Certificate2 are immutable. Use X509CertificateLoader to create a new certificate.";
                }
                {
                    this.X509CertificateImmutableDiagId = "SYSLIB0026";
                }
                {
                    this.PublicKeyPropertyMessage = "PublicKey.Key is obsolete. Use the appropriate method to get the public key, such as GetRSAPublicKey.";
                }
                {
                    this.PublicKeyPropertyDiagId = "SYSLIB0027";
                }
                {
                    this.X509CertificatePrivateKeyMessage = "X509Certificate2.PrivateKey is obsolete. Use the appropriate method to get the private key, such as GetRSAPrivateKey, or use the CopyWithPrivateKey method to create a new instance with a private key.";
                }
                {
                    this.X509CertificatePrivateKeyDiagId = "SYSLIB0028";
                }
                {
                    this.ProduceLegacyHmacValuesMessage = "ProduceLegacyHmacValues is obsolete. Producing legacy HMAC values is not supported.";
                }
                {
                    this.ProduceLegacyHmacValuesDiagId = "SYSLIB0029";
                }
                {
                    this.UseManagedSha1Message = "HMACSHA1 always uses the algorithm implementation provided by the platform. Use a constructor without the useManagedSha1 parameter.";
                }
                {
                    this.UseManagedSha1DiagId = "SYSLIB0030";
                }
                {
                    this.CryptoConfigEncodeOIDMessage = "EncodeOID is obsolete. Use the ASN.1 functionality provided in System.Formats.Asn1.";
                }
                {
                    this.CryptoConfigEncodeOIDDiagId = "SYSLIB0031";
                }
                {
                    this.CorruptedStateRecoveryMessage = "Recovery from corrupted process state exceptions is not supported; HandleProcessCorruptedStateExceptionsAttribute is ignored.";
                }
                {
                    this.CorruptedStateRecoveryDiagId = "SYSLIB0032";
                }
                {
                    this.Rfc2898CryptDeriveKeyMessage = "Rfc2898DeriveBytes.CryptDeriveKey is obsolete and is not supported. Use PasswordDeriveBytes.CryptDeriveKey instead.";
                }
                {
                    this.Rfc2898CryptDeriveKeyDiagId = "SYSLIB0033";
                }
                {
                    this.CmsSignerCspParamsCtorMessage = "CmsSigner(CspParameters) is obsolete and is not supported. Use an alternative constructor instead.";
                }
                {
                    this.CmsSignerCspParamsCtorDiagId = "SYSLIB0034";
                }
                {
                    this.SignerInfoCounterSigMessage = "ComputeCounterSignature without specifying a CmsSigner is obsolete and is not supported. Use the overload that accepts a CmsSigner.";
                }
                {
                    this.SignerInfoCounterSigDiagId = "SYSLIB0035";
                }
                {
                    this.RegexCompileToAssemblyMessage = "Regex.CompileToAssembly is obsolete and not supported. Use the GeneratedRegexAttribute with the regular expression source generator instead.";
                }
                {
                    this.RegexCompileToAssemblyDiagId = "SYSLIB0036";
                }
                {
                    this.AssemblyNameMembersMessage = "AssemblyName members HashAlgorithm, ProcessorArchitecture, and VersionCompatibility are obsolete and not supported.";
                }
                {
                    this.AssemblyNameMembersDiagId = "SYSLIB0037";
                }
                {
                    this.SystemDataSerializationFormatBinaryMessage = "SerializationFormat.Binary is obsolete and should not be used. See https://aka.ms/serializationformat-binary-obsolete for more information.";
                }
                {
                    this.SystemDataSerializationFormatBinaryDiagId = "SYSLIB0038";
                }
                {
                    this.TlsVersion10and11Message = "TLS versions 1.0 and 1.1 have known vulnerabilities and are not recommended. Use a newer TLS version instead, or use SslProtocols.None to defer to OS defaults.";
                }
                {
                    this.TlsVersion10and11DiagId = "SYSLIB0039";
                }
                {
                    this.EncryptionPolicyMessage = "EncryptionPolicy.NoEncryption and AllowEncryption significantly reduce security and should not be used in production code.";
                }
                {
                    this.EncryptionPolicyDiagId = "SYSLIB0040";
                }
                {
                    this.EccXmlExportImportMessage = "ToXmlString and FromXmlString have no implementation for ECC types, and are obsolete. Use a standard import and export format such as ExportSubjectPublicKeyInfo or ImportSubjectPublicKeyInfo for public keys and ExportPkcs8PrivateKey or ImportPkcs8PrivateKey for private keys.";
                }
                {
                    this.EccXmlExportImportDiagId = "SYSLIB0042";
                }
                {
                    this.EcDhPublicKeyBlobMessage = "ECDiffieHellmanPublicKey.ToByteArray() and the associated constructor do not have a consistent and interoperable implementation on all platforms. Use ECDiffieHellmanPublicKey.ExportSubjectPublicKeyInfo() instead.";
                }
                {
                    this.EcDhPublicKeyBlobDiagId = "SYSLIB0043";
                }
                {
                    this.AssemblyNameCodeBaseMessage = "AssemblyName.CodeBase and AssemblyName.EscapedCodeBase are obsolete. Using them for loading an assembly is not supported.";
                }
                {
                    this.AssemblyNameCodeBaseDiagId = "SYSLIB0044";
                }
                {
                    this.CryptoStringFactoryMessage = "Cryptographic factory methods accepting an algorithm name are obsolete. Use the parameterless Create factory method on the algorithm type instead.";
                }
                {
                    this.CryptoStringFactoryDiagId = "SYSLIB0045";
                }
                {
                    this.ControlledExecutionRunMessage = "ControlledExecution.Run method may corrupt the process and should not be used in production code.";
                }
                {
                    this.ControlledExecutionRunDiagId = "SYSLIB0046";
                }
                {
                    this.XmlSecureResolverMessage = "XmlSecureResolver is obsolete. Use XmlResolver.ThrowingResolver instead when attempting to forbid XML external entity resolution.";
                }
                {
                    this.XmlSecureResolverDiagId = "SYSLIB0047";
                }
                {
                    this.RsaEncryptDecryptValueMessage = "RSA.EncryptValue and DecryptValue are not supported and throw NotSupportedException. Use RSA.Encrypt and RSA.Decrypt instead.";
                }
                {
                    this.RsaEncryptDecryptDiagId = "SYSLIB0048";
                }
                {
                    this.JsonSerializerOptionsAddContextMessage = "JsonSerializerOptions.AddContext is obsolete. To register a JsonSerializerContext, use either the TypeInfoResolver or TypeInfoResolverChain properties.";
                }
                {
                    this.JsonSerializerOptionsAddContextDiagId = "SYSLIB0049";
                }
                {
                    this.LegacyFormatterMessage = "Formatter-based serialization is obsolete and should not be used.";
                }
                {
                    this.LegacyFormatterDiagId = "SYSLIB0050";
                }
                {
                    this.LegacyFormatterImplMessage = "This API supports obsolete formatter-based serialization. It should not be called or extended by application code.";
                }
                {
                    this.LegacyFormatterImplDiagId = "SYSLIB0051";
                }
                {
                    this.RegexExtensibilityImplMessage = "This API supports obsolete mechanisms for Regex extensibility. It is not supported.";
                }
                {
                    this.RegexExtensibilityDiagId = "SYSLIB0052";
                }
                {
                    this.AesGcmTagConstructorMessage = "AesGcm should indicate the required tag size for encryption and decryption. Use a constructor that accepts the tag size.";
                }
                {
                    this.AesGcmTagConstructorDiagId = "SYSLIB0053";
                }
                {
                    this.ThreadVolatileReadWriteMessage = "Thread.VolatileRead and Thread.VolatileWrite are obsolete. Use Volatile.Read or Volatile.Write respectively instead.";
                }
                {
                    this.ThreadVolatileReadWriteDiagId = "SYSLIB0054";
                }
                {
                    this.ArmIntrinsicPerformsUnsignedOperationMessage = "The underlying hardware instruction does not perform a signed saturate narrowing operation, and it always returns an unsigned result. Use the unsigned overload instead.";
                }
                {
                    this.ArmIntrinsicPerformsUnsignedOperationDiagId = "SYSLIB0055";
                }
                {
                    this.LoadFromHashAlgorithmMessage = "LoadFrom with a custom AssemblyHashAlgorithm is obsolete. Use overloads without an AssemblyHashAlgorithm.";
                }
                {
                    this.LoadFromHashAlgorithmDiagId = "SYSLIB0056";
                }
                {
                    this.X509CtorCertDataObsoleteMessage = "Loading certificate data through the constructor or Import is obsolete. Use X509CertificateLoader instead to load certificates.";
                }
                {
                    this.X509CtorCertDataObsoleteDiagId = "SYSLIB0057";
                }
                {
                    this.TlsCipherAlgorithmEnumsMessage = "KeyExchangeAlgorithm, KeyExchangeStrength, CipherAlgorithm, CipherStrength, HashAlgorithm and HashStrength properties of SslStream are obsolete. Use NegotiatedCipherSuite instead.";
                }
                {
                    this.TlsCipherAlgorithmEnumsDiagId = "SYSLIB0058";
                }
                {
                    this.SystemEventsEventsThreadShutdownMessage = "SystemEvents.EventsThreadShutdown callbacks are not run before the process exits. Use AppDomain.ProcessExit instead.";
                }
                {
                    this.SystemEventsEventsThreadShutdownDiagId = "SYSLIB0059";
                }
                {
                    this.Rfc2898DeriveBytesCtorMessage = "The constructors on Rfc2898DeriveBytes are obsolete. Use the static Pbkdf2 method instead.";
                }
                {
                    this.Rfc2898DeriveBytesCtorDiagId = "SYSLIB0060";
                }
                {
                    this.QueryableMinByMaxByTSourceObsoleteMessage = "The Queryable MinBy and MaxBy taking an IComparer<TSource> are obsolete. Use the new ones that take an IComparer<TKey>.";
                }
                {
                    this.QueryableMinByMaxByTSourceObsoleteDiagId = "SYSLIB0061";
                }
                {
                    this.XsltSettingsEnableScriptMessage = "XSLT Script blocks are not supported.";
                }
                {
                    this.XsltSettingsEnableScriptDiagId = "SYSLIB0062";
                }
            }
            static $h = 112101;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"l":[{"t":1310721,"n":"SharedUrlFormat","d":112101,"h":4295079397,"f":40},{"t":1310721,"n":"SystemTextEncodingUTF7Message","d":112101,"h":8590046693,"f":40},{"t":1310721,"n":"SystemTextEncodingUTF7DiagId","d":112101,"h":12885013989,"f":40},{"t":1310721,"n":"PrincipalPermissionAttributeMessage","d":112101,"h":17179981285,"f":40},{"t":1310721,"n":"PrincipalPermissionAttributeDiagId","d":112101,"h":21474948581,"f":40},{"t":1310721,"n":"CodeAccessSecurityMessage","d":112101,"h":25769915877,"f":40},{"t":1310721,"n":"CodeAccessSecurityDiagId","d":112101,"h":30064883173,"f":40},{"t":1310721,"n":"ConstrainedExecutionRegionMessage","d":112101,"h":34359850469,"f":40},{"t":1310721,"n":"ConstrainedExecutionRegionDiagId","d":112101,"h":38654817765,"f":40},{"t":1310721,"n":"GlobalAssemblyCacheMessage","d":112101,"h":42949785061,"f":40},{"t":1310721,"n":"GlobalAssemblyCacheDiagId","d":112101,"h":47244752357,"f":40},{"t":1310721,"n":"ThreadAbortMessage","d":112101,"h":51539719653,"f":40},{"t":1310721,"n":"ThreadResetAbortMessage","d":112101,"h":55834686949,"f":40},{"t":1310721,"n":"ThreadAbortDiagId","d":112101,"h":60129654245,"f":40},{"t":1310721,"n":"DefaultCryptoAlgorithmsMessage","d":112101,"h":64424621541,"f":40},{"t":1310721,"n":"DefaultCryptoAlgorithmsDiagId","d":112101,"h":68719588837,"f":40},{"t":1310721,"n":"CreatePdbGeneratorMessage","d":112101,"h":73014556133,"f":40},{"t":1310721,"n":"CreatePdbGeneratorDiagId","d":112101,"h":77309523429,"f":40},{"t":1310721,"n":"AuthenticationManagerMessage","d":112101,"h":81604490725,"f":40},{"t":1310721,"n":"AuthenticationManagerDiagId","d":112101,"h":85899458021,"f":40},{"t":1310721,"n":"RemotingApisMessage","d":112101,"h":90194425317,"f":40},{"t":1310721,"n":"RemotingApisDiagId","d":112101,"h":94489392613,"f":40},{"t":1310721,"n":"BinaryFormatterMessage","d":112101,"h":98784359909,"f":40},{"t":1310721,"n":"BinaryFormatterDiagId","d":112101,"h":103079327205,"f":40},{"t":1310721,"n":"CodeBaseMessage","d":112101,"h":107374294501,"f":40},{"t":1310721,"n":"CodeBaseDiagId","d":112101,"h":111669261797,"f":40},{"t":1310721,"n":"EscapeUriStringMessage","d":112101,"h":115964229093,"f":40},{"t":1310721,"n":"EscapeUriStringDiagId","d":112101,"h":120259196389,"f":40},{"t":1310721,"n":"WebRequestMessage","d":112101,"h":124554163685,"f":40},{"t":1310721,"n":"WebRequestDiagId","d":112101,"h":128849130981,"f":40},{"t":1310721,"n":"DisablePrivateReflectionAttributeMessage","d":112101,"h":133144098277,"f":40},{"t":1310721,"n":"DisablePrivateReflectionAttributeDiagId","d":112101,"h":137439065573,"f":40},{"t":1310721,"n":"GetContextInfoMessage","d":112101,"h":141734032869,"f":40},{"t":1310721,"n":"GetContextInfoDiagId","d":112101,"h":146029000165,"f":40},{"t":1310721,"n":"StrongNameKeyPairMessage","d":112101,"h":150323967461,"f":40},{"t":1310721,"n":"StrongNameKeyPairDiagId","d":112101,"h":154618934757,"f":40},{"t":1310721,"n":"ReflectionOnlyLoadingMessage","d":112101,"h":158913902053,"f":40},{"t":1310721,"n":"ReflectionOnlyLoadingDiagId","d":112101,"h":163208869349,"f":40},{"t":1310721,"n":"RuntimeEnvironmentMessage","d":112101,"h":167503836645,"f":40},{"t":1310721,"n":"RuntimeEnvironmentDiagId","d":112101,"h":171798803941,"f":40},{"t":1310721,"n":"JsonSerializerOptionsIgnoreNullValuesMessage","d":112101,"h":176093771237,"f":40},{"t":1310721,"n":"JsonSerializerOptionsIgnoreNullValuesDiagId","d":112101,"h":180388738533,"f":40},{"t":1310721,"n":"DerivedCryptographicTypesMessage","d":112101,"h":184683705829,"f":40},{"t":1310721,"n":"DerivedCryptographicTypesDiagId","d":112101,"h":188978673125,"f":40},{"t":1310721,"n":"RijndaelMessage","d":112101,"h":193273640421,"f":40},{"t":1310721,"n":"RijndaelDiagId","d":112101,"h":197568607717,"f":40},{"t":1310721,"n":"RNGCryptoServiceProviderMessage","d":112101,"h":201863575013,"f":40},{"t":1310721,"n":"RNGCryptoServiceProviderDiagId","d":112101,"h":206158542309,"f":40},{"t":1310721,"n":"AppDomainCreateUnloadMessage","d":112101,"h":210453509605,"f":40},{"t":1310721,"n":"AppDomainCreateUnloadDiagId","d":112101,"h":214748476901,"f":40},{"t":1310721,"n":"SuppressIldasmAttributeMessage","d":112101,"h":219043444197,"f":40},{"t":1310721,"n":"SuppressIldasmAttributeDiagId","d":112101,"h":223338411493,"f":40},{"t":1310721,"n":"X509CertificateImmutableMessage","d":112101,"h":227633378789,"f":40},{"t":1310721,"n":"X509CertificateImmutableDiagId","d":112101,"h":231928346085,"f":40},{"t":1310721,"n":"PublicKeyPropertyMessage","d":112101,"h":236223313381,"f":40},{"t":1310721,"n":"PublicKeyPropertyDiagId","d":112101,"h":240518280677,"f":40},{"t":1310721,"n":"X509CertificatePrivateKeyMessage","d":112101,"h":244813247973,"f":40},{"t":1310721,"n":"X509CertificatePrivateKeyDiagId","d":112101,"h":249108215269,"f":40},{"t":1310721,"n":"ProduceLegacyHmacValuesMessage","d":112101,"h":253403182565,"f":40},{"t":1310721,"n":"ProduceLegacyHmacValuesDiagId","d":112101,"h":257698149861,"f":40},{"t":1310721,"n":"UseManagedSha1Message","d":112101,"h":261993117157,"f":40},{"t":1310721,"n":"UseManagedSha1DiagId","d":112101,"h":266288084453,"f":40},{"t":1310721,"n":"CryptoConfigEncodeOIDMessage","d":112101,"h":270583051749,"f":40},{"t":1310721,"n":"CryptoConfigEncodeOIDDiagId","d":112101,"h":274878019045,"f":40},{"t":1310721,"n":"CorruptedStateRecoveryMessage","d":112101,"h":279172986341,"f":40},{"t":1310721,"n":"CorruptedStateRecoveryDiagId","d":112101,"h":283467953637,"f":40},{"t":1310721,"n":"Rfc2898CryptDeriveKeyMessage","d":112101,"h":287762920933,"f":40},{"t":1310721,"n":"Rfc2898CryptDeriveKeyDiagId","d":112101,"h":292057888229,"f":40},{"t":1310721,"n":"CmsSignerCspParamsCtorMessage","d":112101,"h":296352855525,"f":40},{"t":1310721,"n":"CmsSignerCspParamsCtorDiagId","d":112101,"h":300647822821,"f":40},{"t":1310721,"n":"SignerInfoCounterSigMessage","d":112101,"h":304942790117,"f":40},{"t":1310721,"n":"SignerInfoCounterSigDiagId","d":112101,"h":309237757413,"f":40},{"t":1310721,"n":"RegexCompileToAssemblyMessage","d":112101,"h":313532724709,"f":40},{"t":1310721,"n":"RegexCompileToAssemblyDiagId","d":112101,"h":317827692005,"f":40},{"t":1310721,"n":"AssemblyNameMembersMessage","d":112101,"h":322122659301,"f":40},{"t":1310721,"n":"AssemblyNameMembersDiagId","d":112101,"h":326417626597,"f":40},{"t":1310721,"n":"SystemDataSerializationFormatBinaryMessage","d":112101,"h":330712593893,"f":40},{"t":1310721,"n":"SystemDataSerializationFormatBinaryDiagId","d":112101,"h":335007561189,"f":40},{"t":1310721,"n":"TlsVersion10and11Message","d":112101,"h":339302528485,"f":40},{"t":1310721,"n":"TlsVersion10and11DiagId","d":112101,"h":343597495781,"f":40},{"t":1310721,"n":"EncryptionPolicyMessage","d":112101,"h":347892463077,"f":40},{"t":1310721,"n":"EncryptionPolicyDiagId","d":112101,"h":352187430373,"f":40},{"t":1310721,"n":"EccXmlExportImportMessage","d":112101,"h":356482397669,"f":40},{"t":1310721,"n":"EccXmlExportImportDiagId","d":112101,"h":360777364965,"f":40},{"t":1310721,"n":"EcDhPublicKeyBlobMessage","d":112101,"h":365072332261,"f":40},{"t":1310721,"n":"EcDhPublicKeyBlobDiagId","d":112101,"h":369367299557,"f":40},{"t":1310721,"n":"AssemblyNameCodeBaseMessage","d":112101,"h":373662266853,"f":40},{"t":1310721,"n":"AssemblyNameCodeBaseDiagId","d":112101,"h":377957234149,"f":40},{"t":1310721,"n":"CryptoStringFactoryMessage","d":112101,"h":382252201445,"f":40},{"t":1310721,"n":"CryptoStringFactoryDiagId","d":112101,"h":386547168741,"f":40},{"t":1310721,"n":"ControlledExecutionRunMessage","d":112101,"h":390842136037,"f":40},{"t":1310721,"n":"ControlledExecutionRunDiagId","d":112101,"h":395137103333,"f":40},{"t":1310721,"n":"XmlSecureResolverMessage","d":112101,"h":399432070629,"f":40},{"t":1310721,"n":"XmlSecureResolverDiagId","d":112101,"h":403727037925,"f":40},{"t":1310721,"n":"RsaEncryptDecryptValueMessage","d":112101,"h":408022005221,"f":40},{"t":1310721,"n":"RsaEncryptDecryptDiagId","d":112101,"h":412316972517,"f":40},{"t":1310721,"n":"JsonSerializerOptionsAddContextMessage","d":112101,"h":416611939813,"f":40},{"t":1310721,"n":"JsonSerializerOptionsAddContextDiagId","d":112101,"h":420906907109,"f":40},{"t":1310721,"n":"LegacyFormatterMessage","d":112101,"h":425201874405,"f":40},{"t":1310721,"n":"LegacyFormatterDiagId","d":112101,"h":429496841701,"f":40},{"t":1310721,"n":"LegacyFormatterImplMessage","d":112101,"h":433791808997,"f":40},{"t":1310721,"n":"LegacyFormatterImplDiagId","d":112101,"h":438086776293,"f":40},{"t":1310721,"n":"RegexExtensibilityImplMessage","d":112101,"h":442381743589,"f":40},{"t":1310721,"n":"RegexExtensibilityDiagId","d":112101,"h":446676710885,"f":40},{"t":1310721,"n":"AesGcmTagConstructorMessage","d":112101,"h":450971678181,"f":40},{"t":1310721,"n":"AesGcmTagConstructorDiagId","d":112101,"h":455266645477,"f":40},{"t":1310721,"n":"ThreadVolatileReadWriteMessage","d":112101,"h":459561612773,"f":40},{"t":1310721,"n":"ThreadVolatileReadWriteDiagId","d":112101,"h":463856580069,"f":40},{"t":1310721,"n":"ArmIntrinsicPerformsUnsignedOperationMessage","d":112101,"h":468151547365,"f":40},{"t":1310721,"n":"ArmIntrinsicPerformsUnsignedOperationDiagId","d":112101,"h":472446514661,"f":40},{"t":1310721,"n":"LoadFromHashAlgorithmMessage","d":112101,"h":476741481957,"f":40},{"t":1310721,"n":"LoadFromHashAlgorithmDiagId","d":112101,"h":481036449253,"f":40},{"t":1310721,"n":"X509CtorCertDataObsoleteMessage","d":112101,"h":485331416549,"f":40},{"t":1310721,"n":"X509CtorCertDataObsoleteDiagId","d":112101,"h":489626383845,"f":40},{"t":1310721,"n":"TlsCipherAlgorithmEnumsMessage","d":112101,"h":493921351141,"f":40},{"t":1310721,"n":"TlsCipherAlgorithmEnumsDiagId","d":112101,"h":498216318437,"f":40},{"t":1310721,"n":"SystemEventsEventsThreadShutdownMessage","d":112101,"h":502511285733,"f":40},{"t":1310721,"n":"SystemEventsEventsThreadShutdownDiagId","d":112101,"h":506806253029,"f":40},{"t":1310721,"n":"Rfc2898DeriveBytesCtorMessage","d":112101,"h":511101220325,"f":40},{"t":1310721,"n":"Rfc2898DeriveBytesCtorDiagId","d":112101,"h":515396187621,"f":40},{"t":1310721,"n":"QueryableMinByMaxByTSourceObsoleteMessage","d":112101,"h":519691154917,"f":40},{"t":1310721,"n":"QueryableMinByMaxByTSourceObsoleteDiagId","d":112101,"h":523986122213,"f":40},{"t":1310721,"n":"XsltSettingsEnableScriptMessage","d":112101,"h":528281089509,"f":40},{"t":1310721,"n":"XsltSettingsEnableScriptDiagId","d":112101,"h":532576056805,"f":40}],"h":112101}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.Obsoletions`; }
        });
        
        $asm.$cls("$srsp.System.SR", ($self) => class SR
        {
            /*global::System.Resources.ResourceManager*/ static s_resourceManager = null;
            /*global::System.Globalization.CultureInfo*/ static resourceCulture = null;
            static /*global::System.Resources.ResourceManager */ get ResourceManager()
            {
                if ($.$spc.System.Object.ReferenceEquals($.$srsp.System.SR.s_resourceManager, null))
                {
                    /*global::System.Resources.ResourceManager*/ let temp = new $.$spc.System.Resources.ResourceManager().$ctor$3("System.Runtime.Serialization.Primitives", $.$srsp.System.SR.$type.Assembly);
                    $.$srsp.System.SR.s_resourceManager = temp;
                }
                return $.$srsp.System.SR.s_resourceManager;
            }
            static /*global::System.Globalization.CultureInfo */ get Culture()
            {
                return $.$srsp.System.SR.resourceCulture;
            }
            static /*global::System.Globalization.CultureInfo */ set Culture(value)
            {
                $.$srsp.System.SR.resourceCulture = value;
            }
            static /*string */ get OrderCannotBeNegative()
            {
                return "Property 'Order' in DataMemberAttribute attribute cannot be a negative number.";
            }
            /*bool*/ static s_usingResourceKeys = false;
            static /*bool */ GetUsingResourceKeysSwitchValue()
            {
                /*bool*/ let usingResourceKeys;
                return $.$spc.System.AppContext.TryGetSwitch("System.Resources.UseSystemResourceKeys", $.$ref(() => usingResourceKeys, ($v) => usingResourceKeys = $v, $.$spc.System.Boolean)) ? usingResourceKeys : false;
            }
            static /*bool */ UsingResourceKeys()
            {
                return $.$srsp.System.SR.s_usingResourceKeys;
            }
            static /*string */ GetResourceString(/*string*/ resourceKey)
            {
                if ($.$srsp.System.SR.UsingResourceKeys())
                {
                    return resourceKey;
                }
                /*string?*/ let resourceString = null;
                try
                {
                    resourceString = $.$srsp.System.SR.ResourceManager.GetString(resourceKey);
                }
                catch($e)
                {
                }
                return resourceString;
            }
            static /*string */ GetResourceString$1(/*string*/ resourceKey, /*string*/ defaultString)
            {
                /*string*/ let resourceString = $.$srsp.System.SR.GetResourceString(resourceKey);
                return $.$spc.System.String.op_Equality(resourceKey, resourceString) || $.$spc.System.String.op_Equality(resourceString, null) ? defaultString : resourceString;
            }
            static /*string */ Format(/*string*/ resourceFormat, /*object?*/ p1)
            {
                if ($.$srsp.System.SR.UsingResourceKeys())
                {
                    return $.$spc.System.String.Join$10(", ", $.$spc.System.ReadOnlySpan$$($.$spc.System.Object).op_Implicit([ resourceFormat, p1 ]));
                }
                return $.$spc.System.String.Format(resourceFormat, p1);
            }
            static /*string */ Format$1(/*string*/ resourceFormat, /*object?*/ p1, /*object?*/ p2)
            {
                if ($.$srsp.System.SR.UsingResourceKeys())
                {
                    return $.$spc.System.String.Join$10(", ", $.$spc.System.ReadOnlySpan$$($.$spc.System.Object).op_Implicit([ resourceFormat, p1, p2 ]));
                }
                return $.$spc.System.String.Format$1(resourceFormat, p1, p2);
            }
            static /*string */ Format$2(/*string*/ resourceFormat, /*object?*/ p1, /*object?*/ p2, /*object?*/ p3)
            {
                if ($.$srsp.System.SR.UsingResourceKeys())
                {
                    return $.$spc.System.String.Join$10(", ", $.$spc.System.ReadOnlySpan$$($.$spc.System.Object).op_Implicit([ resourceFormat, p1, p2, p3 ]));
                }
                return $.$spc.System.String.Format$2(resourceFormat, p1, p2, p3);
            }
            static /*string */ Format$3(/*string*/ resourceFormat, /*params object?[]?*/ args)
            {
                if (args !== null)
                {
                    if ($.$srsp.System.SR.UsingResourceKeys())
                    {
                        return resourceFormat + ", " + $.$spc.System.String.Join$9(", ", args);
                    }
                    return $.$spc.System.String.Format$3(resourceFormat, args);
                }
                return resourceFormat;
            }
            static /*string */ Format$4(/*IFormatProvider?*/ provider, /*string*/ resourceFormat, /*object?*/ p1)
            {
                if ($.$srsp.System.SR.UsingResourceKeys())
                {
                    return $.$spc.System.String.Join$10(", ", $.$spc.System.ReadOnlySpan$$($.$spc.System.Object).op_Implicit([ resourceFormat, p1 ]));
                }
                return $.$spc.System.String.Format$5(provider, resourceFormat, p1);
            }
            static /*string */ Format$5(/*IFormatProvider?*/ provider, /*string*/ resourceFormat, /*object?*/ p1, /*object?*/ p2)
            {
                if ($.$srsp.System.SR.UsingResourceKeys())
                {
                    return $.$spc.System.String.Join$10(", ", $.$spc.System.ReadOnlySpan$$($.$spc.System.Object).op_Implicit([ resourceFormat, p1, p2 ]));
                }
                return $.$spc.System.String.Format$6(provider, resourceFormat, p1, p2);
            }
            static /*string */ Format$6(/*IFormatProvider?*/ provider, /*string*/ resourceFormat, /*object?*/ p1, /*object?*/ p2, /*object?*/ p3)
            {
                if ($.$srsp.System.SR.UsingResourceKeys())
                {
                    return $.$spc.System.String.Join$10(", ", $.$spc.System.ReadOnlySpan$$($.$spc.System.Object).op_Implicit([ resourceFormat, p1, p2, p3 ]));
                }
                return $.$spc.System.String.Format$7(provider, resourceFormat, p1, p2, p3);
            }
            static /*string */ Format$7(/*IFormatProvider?*/ provider, /*string*/ resourceFormat, /*params object?[]?*/ args)
            {
                if (args !== null)
                {
                    if ($.$srsp.System.SR.UsingResourceKeys())
                    {
                        return resourceFormat + ", " + $.$spc.System.String.Join$9(", ", args);
                    }
                    return $.$spc.System.String.Format$8(provider, resourceFormat, args);
                }
                return resourceFormat;
            }
            //Static Initializer
            static $sinit()
            {
                {
                    this.s_usingResourceKeys = $.$srsp.System.SR.GetUsingResourceKeysSwitchValue();
                }
            }
            static $h = 832997;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"h":832997}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.SR`; }
        });
        
        $asm.$cls("$srsp.System.Runtime.Serialization.ContractNamespaceAttribute", ($self) => class ContractNamespaceAttribute extends $.$spc.System.Attribute
        {
            $ctor$2(/*string*/ contractNamespace)
            {
                super.$ctor$1();
                {
                    this.ContractNamespace = contractNamespace;
                }
                return this;
            }
            /*string?*/ ClrNamespace = null;
            /*string*/ ContractNamespace = null;
            static $h = 243173;
            static $f = 0b10010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":14548993,"p":[{"p":1310721,"g":{"r":0,"d":0,"h":17180112357,"f":1},"s":{"r":0,"d":0,"h":21475079653,"f":1},"n":"ClrNamespace","d":243173,"h":12885145061,"f":1},{"p":1310721,"g":{"r":0,"d":0,"h":34359981541,"f":1},"n":"ContractNamespace","d":243173,"h":30065014245,"f":1}],"c":[{"p":[{"n":"contractNamespace","p":1310721}],"n":".ctor","o":"$ctor$2","d":243173,"h":4295210469,"f":1}],"h":243173,"a":[{"t":14680065,"c":21489516545,"a":[{"v":3,"t":14614529}],"n":[{"n":"Inherited","v":false,"t":262145},{"n":"AllowMultiple","v":true,"t":262145}]}]}; }
            static get $b() { return $.$spc.System.Attribute; }
            static get $fullName() { return `System.Runtime.Serialization.ContractNamespaceAttribute`; }
        });
        
        $asm.$cls("$srsp.System.Runtime.Serialization.EnumMemberAttribute", ($self) => class EnumMemberAttribute extends $.$spc.System.Attribute
        {
            /*string?*/ _value = null;
            /*bool*/ _isValueSetExplicitly = false;
            $ctor$2()
            {
                super.$ctor$1();
                {
                }
                return this;
            }
            /*string? */ get Value()
            {
                return this._value;
            }
            /*string? */ set Value(value)
            {
                this._value = value;
                this._isValueSetExplicitly = true;
            }
            /*bool */ get IsValueSetExplicitly()
            {
                return this._isValueSetExplicitly;
            }
            static $h = 439781;
            static $f = 0b10010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":14548993,"p":[{"p":1310721,"g":{"r":0,"d":0,"h":21475276261,"f":1},"s":{"r":0,"d":0,"h":25770243557,"f":1},"n":"Value","d":439781,"h":17180308965,"f":1},{"p":262145,"g":{"r":0,"d":0,"h":34360178149,"f":1},"n":"IsValueSetExplicitly","d":439781,"h":30065210853,"f":1}],"l":[{"t":1310721,"n":"_value","d":439781,"h":4295407077,"f":2},{"t":262145,"n":"_isValueSetExplicitly","d":439781,"h":8590374373,"f":2}],"c":[{"n":".ctor","o":"$ctor$2","d":439781,"h":12885341669,"f":1}],"h":439781,"a":[{"t":14680065,"c":21489516545,"a":[{"v":256,"t":14614529}],"n":[{"n":"Inherited","v":false,"t":262145},{"n":"AllowMultiple","v":false,"t":262145}]}]}; }
            static get $b() { return $.$spc.System.Attribute; }
            static get $fullName() { return `System.Runtime.Serialization.EnumMemberAttribute`; }
        });
        
        $asm.$cls("$srsp.System.Runtime.Serialization.DataMemberAttribute", ($self) => class DataMemberAttribute extends $.$spc.System.Attribute
        {
            /*string?*/ _name = null;
            /*bool*/ _isNameSetExplicitly = false;
            /*int*/ _order = -1;
            $ctor$2()
            {
                super.$ctor$1();
                {
                }
                return this;
            }
            /*string? */ get Name()
            {
                return this._name;
            }
            /*string? */ set Name(value)
            {
                this._name = value;
                this._isNameSetExplicitly = true;
            }
            /*bool */ get IsNameSetExplicitly()
            {
                return this._isNameSetExplicitly;
            }
            /*int */ get Order()
            {
                return this._order;
            }
            /*int */ set Order(value)
            {
                if (value < 0)
                {
                    throw new $.$srsp.System.Runtime.Serialization.InvalidDataContractException().$ctor$6($.$srsp.System.SR.OrderCannotBeNegative);
                }
                this._order = value;
            }
            /*bool*/ IsRequired = false;
            /*bool*/ EmitDefaultValue = false;
            //default member initializer
            constructor()
            {
                super();
                this.IsRequired = false;
                this.EmitDefaultValue = true;
            }
            static $h = 374245;
            static $f = 0b10010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":14548993,"p":[{"p":1310721,"g":{"r":0,"d":0,"h":25770178021,"f":1},"s":{"r":0,"d":0,"h":30065145317,"f":1},"n":"Name","d":374245,"h":21475210725,"f":1},{"p":262145,"g":{"r":0,"d":0,"h":38655079909,"f":1},"n":"IsNameSetExplicitly","d":374245,"h":34360112613,"f":1},{"p":655361,"g":{"r":0,"d":0,"h":47245014501,"f":1},"s":{"r":0,"d":0,"h":51539981797,"f":1},"n":"Order","d":374245,"h":42950047205,"f":1},{"p":262145,"g":{"r":0,"d":0,"h":64424883685,"f":1},"s":{"r":0,"d":0,"h":68719850981,"f":1},"n":"IsRequired","d":374245,"h":60129916389,"f":1},{"p":262145,"g":{"r":0,"d":0,"h":81604752869,"f":1},"s":{"r":0,"d":0,"h":85899720165,"f":1},"n":"EmitDefaultValue","d":374245,"h":77309785573,"f":1}],"l":[{"t":1310721,"n":"_name","d":374245,"h":4295341541,"f":2},{"t":262145,"n":"_isNameSetExplicitly","d":374245,"h":8590308837,"f":2},{"t":655361,"n":"_order","d":374245,"h":12885276133,"f":2}],"c":[{"n":".ctor","o":"$ctor$2","d":374245,"h":17180243429,"f":1}],"h":374245,"a":[{"t":14680065,"c":21489516545,"a":[{"v":384,"t":14614529}],"n":[{"n":"Inherited","v":false,"t":262145},{"n":"AllowMultiple","v":false,"t":262145}]}]}; }
            static get $b() { return $.$spc.System.Attribute; }
            static get $fullName() { return `System.Runtime.Serialization.DataMemberAttribute`; }
        });
        
        $asm.$cls("$srsp.System.Runtime.Serialization.IgnoreDataMemberAttribute", ($self) => class IgnoreDataMemberAttribute extends $.$spc.System.Attribute
        {
            $ctor$2()
            {
                super.$ctor$1();
                {
                }
                return this;
            }
            static $h = 505317;
            static $f = 0b10010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":14548993,"c":[{"n":".ctor","o":"$ctor$2","d":505317,"h":4295472613,"f":1}],"h":505317,"a":[{"t":14680065,"c":21489516545,"a":[{"v":384,"t":14614529}],"n":[{"n":"Inherited","v":false,"t":262145},{"n":"AllowMultiple","v":false,"t":262145}]}]}; }
            static get $b() { return $.$spc.System.Attribute; }
            static get $fullName() { return `System.Runtime.Serialization.IgnoreDataMemberAttribute`; }
        });
        
        $asm.$cls("$srsp.System.Runtime.Serialization.CollectionDataContractAttribute", ($self) => class CollectionDataContractAttribute extends $.$spc.System.Attribute
        {
            /*string?*/ _name = null;
            /*string?*/ _ns = null;
            /*string?*/ _itemName = null;
            /*string?*/ _keyName = null;
            /*string?*/ _valueName = null;
            /*bool*/ _isReference = false;
            /*bool*/ _isNameSetExplicitly = false;
            /*bool*/ _isNamespaceSetExplicitly = false;
            /*bool*/ _isReferenceSetExplicitly = false;
            /*bool*/ _isItemNameSetExplicitly = false;
            /*bool*/ _isKeyNameSetExplicitly = false;
            /*bool*/ _isValueNameSetExplicitly = false;
            $ctor$2()
            {
                super.$ctor$1();
                {
                }
                return this;
            }
            /*string? */ get Namespace()
            {
                return this._ns;
            }
            /*string? */ set Namespace(value)
            {
                this._ns = value;
                this._isNamespaceSetExplicitly = true;
            }
            /*bool */ get IsNamespaceSetExplicitly()
            {
                return this._isNamespaceSetExplicitly;
            }
            /*string? */ get Name()
            {
                return this._name;
            }
            /*string? */ set Name(value)
            {
                this._name = value;
                this._isNameSetExplicitly = true;
            }
            /*bool */ get IsNameSetExplicitly()
            {
                return this._isNameSetExplicitly;
            }
            /*string? */ get ItemName()
            {
                return this._itemName;
            }
            /*string? */ set ItemName(value)
            {
                this._itemName = value;
                this._isItemNameSetExplicitly = true;
            }
            /*bool */ get IsItemNameSetExplicitly()
            {
                return this._isItemNameSetExplicitly;
            }
            /*string? */ get KeyName()
            {
                return this._keyName;
            }
            /*string? */ set KeyName(value)
            {
                this._keyName = value;
                this._isKeyNameSetExplicitly = true;
            }
            /*bool */ get IsKeyNameSetExplicitly()
            {
                return this._isKeyNameSetExplicitly;
            }
            /*bool */ get IsReference()
            {
                return this._isReference;
            }
            /*bool */ set IsReference(value)
            {
                this._isReference = value;
                this._isReferenceSetExplicitly = true;
            }
            /*bool */ get IsReferenceSetExplicitly()
            {
                return this._isReferenceSetExplicitly;
            }
            /*string? */ get ValueName()
            {
                return this._valueName;
            }
            /*string? */ set ValueName(value)
            {
                this._valueName = value;
                this._isValueNameSetExplicitly = true;
            }
            /*bool */ get IsValueNameSetExplicitly()
            {
                return this._isValueNameSetExplicitly;
            }
            static $h = 177637;
            static $f = 0b10010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":14548993,"p":[{"p":1310721,"g":{"r":0,"d":0,"h":64424687077,"f":1},"s":{"r":0,"d":0,"h":68719654373,"f":1},"n":"Namespace","d":177637,"h":60129719781,"f":1},{"p":262145,"g":{"r":0,"d":0,"h":77309588965,"f":1},"n":"IsNamespaceSetExplicitly","d":177637,"h":73014621669,"f":1},{"p":1310721,"g":{"r":0,"d":0,"h":85899523557,"f":1},"s":{"r":0,"d":0,"h":90194490853,"f":1},"n":"Name","d":177637,"h":81604556261,"f":1},{"p":262145,"g":{"r":0,"d":0,"h":98784425445,"f":1},"n":"IsNameSetExplicitly","d":177637,"h":94489458149,"f":1},{"p":1310721,"g":{"r":0,"d":0,"h":107374360037,"f":1},"s":{"r":0,"d":0,"h":111669327333,"f":1},"n":"ItemName","d":177637,"h":103079392741,"f":1},{"p":262145,"g":{"r":0,"d":0,"h":120259261925,"f":1},"n":"IsItemNameSetExplicitly","d":177637,"h":115964294629,"f":1},{"p":1310721,"g":{"r":0,"d":0,"h":128849196517,"f":1},"s":{"r":0,"d":0,"h":133144163813,"f":1},"n":"KeyName","d":177637,"h":124554229221,"f":1},{"p":262145,"g":{"r":0,"d":0,"h":141734098405,"f":1},"n":"IsKeyNameSetExplicitly","d":177637,"h":137439131109,"f":1},{"p":262145,"g":{"r":0,"d":0,"h":150324032997,"f":1},"s":{"r":0,"d":0,"h":154619000293,"f":1},"n":"IsReference","d":177637,"h":146029065701,"f":1},{"p":262145,"g":{"r":0,"d":0,"h":163208934885,"f":1},"n":"IsReferenceSetExplicitly","d":177637,"h":158913967589,"f":1},{"p":1310721,"g":{"r":0,"d":0,"h":171798869477,"f":1},"s":{"r":0,"d":0,"h":176093836773,"f":1},"n":"ValueName","d":177637,"h":167503902181,"f":1},{"p":262145,"g":{"r":0,"d":0,"h":184683771365,"f":1},"n":"IsValueNameSetExplicitly","d":177637,"h":180388804069,"f":1}],"l":[{"t":1310721,"n":"_name","d":177637,"h":4295144933,"f":2},{"t":1310721,"n":"_ns","d":177637,"h":8590112229,"f":2},{"t":1310721,"n":"_itemName","d":177637,"h":12885079525,"f":2},{"t":1310721,"n":"_keyName","d":177637,"h":17180046821,"f":2},{"t":1310721,"n":"_valueName","d":177637,"h":21475014117,"f":2},{"t":262145,"n":"_isReference","d":177637,"h":25769981413,"f":2},{"t":262145,"n":"_isNameSetExplicitly","d":177637,"h":30064948709,"f":2},{"t":262145,"n":"_isNamespaceSetExplicitly","d":177637,"h":34359916005,"f":2},{"t":262145,"n":"_isReferenceSetExplicitly","d":177637,"h":38654883301,"f":2},{"t":262145,"n":"_isItemNameSetExplicitly","d":177637,"h":42949850597,"f":2},{"t":262145,"n":"_isKeyNameSetExplicitly","d":177637,"h":47244817893,"f":2},{"t":262145,"n":"_isValueNameSetExplicitly","d":177637,"h":51539785189,"f":2}],"c":[{"n":".ctor","o":"$ctor$2","d":177637,"h":55834752485,"f":1}],"h":177637,"a":[{"t":14680065,"c":21489516545,"a":[{"v":12,"t":14614529}],"n":[{"n":"Inherited","v":false,"t":262145},{"n":"AllowMultiple","v":false,"t":262145}]}]}; }
            static get $b() { return $.$spc.System.Attribute; }
            static get $fullName() { return `System.Runtime.Serialization.CollectionDataContractAttribute`; }
        });
        
        $asm.$cls("$srsp.System.Runtime.Serialization.DataContractAttribute", ($self) => class DataContractAttribute extends $.$spc.System.Attribute
        {
            /*string?*/ _name = null;
            /*string?*/ _ns = null;
            /*bool*/ _isNameSetExplicitly = false;
            /*bool*/ _isNamespaceSetExplicitly = false;
            /*bool*/ _isReference = false;
            /*bool*/ _isReferenceSetExplicitly = false;
            $ctor$2()
            {
                super.$ctor$1();
                {
                }
                return this;
            }
            /*bool */ get IsReference()
            {
                return this._isReference;
            }
            /*bool */ set IsReference(value)
            {
                this._isReference = value;
                this._isReferenceSetExplicitly = true;
            }
            /*bool */ get IsReferenceSetExplicitly()
            {
                return this._isReferenceSetExplicitly;
            }
            /*string? */ get Namespace()
            {
                return this._ns;
            }
            /*string? */ set Namespace(value)
            {
                this._ns = value;
                this._isNamespaceSetExplicitly = true;
            }
            /*bool */ get IsNamespaceSetExplicitly()
            {
                return this._isNamespaceSetExplicitly;
            }
            /*string? */ get Name()
            {
                return this._name;
            }
            /*string? */ set Name(value)
            {
                this._name = value;
                this._isNameSetExplicitly = true;
            }
            /*bool */ get IsNameSetExplicitly()
            {
                return this._isNameSetExplicitly;
            }
            static $h = 308709;
            static $f = 0b10010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":14548993,"p":[{"p":262145,"g":{"r":0,"d":0,"h":38655014373,"f":1},"s":{"r":0,"d":0,"h":42949981669,"f":1},"n":"IsReference","d":308709,"h":34360047077,"f":1},{"p":262145,"g":{"r":0,"d":0,"h":51539916261,"f":1},"n":"IsReferenceSetExplicitly","d":308709,"h":47244948965,"f":1},{"p":1310721,"g":{"r":0,"d":0,"h":60129850853,"f":1},"s":{"r":0,"d":0,"h":64424818149,"f":1},"n":"Namespace","d":308709,"h":55834883557,"f":1},{"p":262145,"g":{"r":0,"d":0,"h":73014752741,"f":1},"n":"IsNamespaceSetExplicitly","d":308709,"h":68719785445,"f":1},{"p":1310721,"g":{"r":0,"d":0,"h":81604687333,"f":1},"s":{"r":0,"d":0,"h":85899654629,"f":1},"n":"Name","d":308709,"h":77309720037,"f":1},{"p":262145,"g":{"r":0,"d":0,"h":94489589221,"f":1},"n":"IsNameSetExplicitly","d":308709,"h":90194621925,"f":1}],"l":[{"t":1310721,"n":"_name","d":308709,"h":4295276005,"f":2},{"t":1310721,"n":"_ns","d":308709,"h":8590243301,"f":2},{"t":262145,"n":"_isNameSetExplicitly","d":308709,"h":12885210597,"f":2},{"t":262145,"n":"_isNamespaceSetExplicitly","d":308709,"h":17180177893,"f":2},{"t":262145,"n":"_isReference","d":308709,"h":21475145189,"f":2},{"t":262145,"n":"_isReferenceSetExplicitly","d":308709,"h":25770112485,"f":2}],"c":[{"n":".ctor","o":"$ctor$2","d":308709,"h":30065079781,"f":1}],"h":308709,"a":[{"t":14680065,"c":21489516545,"a":[{"v":28,"t":14614529}],"n":[{"n":"Inherited","v":false,"t":262145},{"n":"AllowMultiple","v":false,"t":262145}]}]}; }
            static get $b() { return $.$spc.System.Attribute; }
            static get $fullName() { return `System.Runtime.Serialization.DataContractAttribute`; }
        });
        
        $asm.$cls("$srsp.System.Runtime.Serialization.KnownTypeAttribute", ($self) => class KnownTypeAttribute extends $.$spc.System.Attribute
        {
            $ctor$2(/*Type*/ type)
            {
                super.$ctor$1();
                {
                    this.Type = type;
                }
                return this;
            }
            $ctor$3(/*string*/ methodName)
            {
                super.$ctor$1();
                {
                    this.MethodName = methodName;
                }
                return this;
            }
            /*string?*/ MethodName = null;
            /*Type?*/ Type = null;
            static $h = 767461;
            static $f = 0b10010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":14548993,"p":[{"p":1310721,"g":{"r":0,"d":0,"h":21475603941,"f":1},"n":"MethodName","d":767461,"h":17180636645,"f":1},{"p":142606337,"g":{"r":0,"d":0,"h":34360505829,"f":1},"n":"Type","d":767461,"h":30065538533,"f":1}],"c":[{"p":[{"n":"type","p":142606337}],"n":".ctor","o":"$ctor$2","d":767461,"h":4295734757,"f":1},{"p":[{"n":"methodName","p":1310721}],"n":".ctor","o":"$ctor$3","d":767461,"h":8590702053,"f":1}],"h":767461,"a":[{"t":14680065,"c":21489516545,"a":[{"v":12,"t":14614529}],"n":[{"n":"Inherited","v":true,"t":262145},{"n":"AllowMultiple","v":true,"t":262145}]}]}; }
            static get $b() { return $.$spc.System.Attribute; }
            static get $fullName() { return `System.Runtime.Serialization.KnownTypeAttribute`; }
        });
        
        $asm.$cls("$srsp.System.Runtime.Serialization.InvalidDataContractException", ($self) => class InvalidDataContractException extends $.$spc.System.Exception
        {
            $ctor$5()
            {
                super.$ctor$1();
                {
                }
                return this;
            }
            $ctor$6(/*string?*/ message)
            {
                super.$ctor$2(message);
                {
                }
                return this;
            }
            $ctor$7(/*string?*/ message, /*Exception?*/ innerException)
            {
                super.$ctor$3(message, innerException);
                {
                }
                return this;
            }
            $ctor$8(/*SerializationInfo*/ info, /*StreamingContext*/ context)
            {
                super.$ctor$4(info, context);
                {
                }
                return this;
            }
            static $h = 570853;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":47251457,"h":570853}; }
            static get $b() { return $.$spc.System.Exception; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.Runtime.Serialization.ISerializable ]; }
            static get $fullName() { return `System.Runtime.Serialization.InvalidDataContractException`; }
        });
	});
})(window, window.NetJs.$boot(), ...window.NetJs.$require("NetJs.System.Private.CoreLib", "NetJs.System.Memory", "NetJs.System.Private.Uri", "NetJs.System.Runtime"))