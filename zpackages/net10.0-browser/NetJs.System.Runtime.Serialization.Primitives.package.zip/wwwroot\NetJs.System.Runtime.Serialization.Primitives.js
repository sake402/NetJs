
(function ($global, $, $spc, $sm, $spu, $sr) {
    "use strict";
    let _;
    
    
    
	$.$asm(
    "NetJs.System.Runtime.Serialization.Primitives", 
    {"h":46038,"f":"System.Runtime.Serialization.Primitives","v":"1.0.35.0","a":[{"t":96337921,"c":4391305217,"a":[{"v":113442817,"t":142606337}]},{"t":96337921,"c":4391305217,"a":[{"v":113508353,"t":142606337}]},{"t":96337921,"c":4391305217,"a":[{"v":113573889,"t":142606337}]},{"t":96337921,"c":4391305217,"a":[{"v":113639425,"t":142606337}]},{"t":96337921,"c":4391305217,"a":[{"v":113901569,"t":142606337}]},{"t":96337921,"c":4391305217,"a":[{"v":114098177,"t":142606337}]},{"t":96337921,"c":4391305217,"a":[{"v":114163713,"t":142606337}]},{"t":115146753,"c":13000048641,"a":[{"v":".NETCoreApp,Version=v10.0","t":1310721}],"n":[{"n":"FrameworkDisplayName","v":".NET 10.0","t":1310721}]},{"t":73596929,"c":4368564225,"a":[{"v":"SIT","t":1310721}]},{"t":73662465,"c":4368629761,"a":[{"v":"Debug","t":1310721}]},{"t":74121217,"c":4369088513,"a":[{"v":"1.0.35.0","t":1310721}]},{"t":74252289,"c":4369219585,"a":[{"v":"1.0.35\u002B760b8187d87d291733fdcda9f4d484d24d61a938","t":1310721}]},{"t":75104257,"c":4370071553,"a":[{"v":"NetJs.System.Runtime.Serialization.Primitives","t":1310721}]},{"t":75235329,"c":4370202625,"a":[{"v":"NetJs.System.Runtime.Serialization.Primitives","t":1310721}]},{"t":75366401,"c":4370333697,"a":[{"v":"1.0.35.0","t":1310721}]},{"t":115212289,"c":4410179585,"a":[{"v":"browser1.0","t":1310721}]},{"t":114950145,"c":4409917441,"a":[{"v":"browser1.0","t":1310721}]}],"m":[]},
    function($asm)
	{
        
        
        $asm.$cls("$srsp.System.Runtime.Serialization.ISerializationSurrogateProvider", ($self) => class ISerializationSurrogateProvider
        {
            static $h = 635862;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {"m":[{"r":142606337,"p":[{"n":"type","p":142606337}],"n":"GetSurrogateType","o":"System$Runtime$Serialization$ISerializationSurrogateProvider$GetSurrogateType","d":635862,"h":4295603158,"f":257},{"r":131073,"p":[{"n":"obj","p":131073},{"n":"targetType","p":142606337}],"n":"GetObjectToSerialize","o":"System$Runtime$Serialization$ISerializationSurrogateProvider$GetObjectToSerialize","d":635862,"h":8590570454,"f":257},{"r":131073,"p":[{"n":"obj","p":131073},{"n":"targetType","p":142606337}],"n":"GetDeserializedObject","o":"System$Runtime$Serialization$ISerializationSurrogateProvider$GetDeserializedObject","d":635862,"h":12885537750,"f":257}],"h":635862}; }
            static get $fullName() { return `System.Runtime.Serialization.ISerializationSurrogateProvider`; }
        });
        
        $asm.$cls("$srsp.System.Runtime.Serialization.ISerializationSurrogateProvider2", ($self) => class ISerializationSurrogateProvider2
        {
            static $h = 701398;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {"m":[{"r":131073,"p":[{"n":"memberInfo","p":78249985},{"n":"dataContractType","p":142606337}],"n":"GetCustomDataToExport","o":"System$Runtime$Serialization$ISerializationSurrogateProvider2$GetCustomDataToExport","d":701398,"h":4295668694,"f":257},{"r":131073,"p":[{"n":"runtimeType","p":142606337},{"n":"dataContractType","p":142606337}],"n":"GetCustomDataToExport","o":"System$Runtime$Serialization$ISerializationSurrogateProvider2$GetCustomDataToExport$1","d":701398,"h":8590635990,"f":257},{"r":65537,"p":[{"n":"customDataTypes","p":$.$spc.System.Collections.ObjectModel.Collection$$($.$spc.System.Type).$h}],"n":"GetKnownCustomDataTypes","o":"System$Runtime$Serialization$ISerializationSurrogateProvider2$GetKnownCustomDataTypes","d":701398,"h":12885603286,"f":257},{"r":142606337,"p":[{"n":"typeName","p":1310721},{"n":"typeNamespace","p":1310721},{"n":"customData","p":131073}],"n":"GetReferencedTypeOnImport","o":"System$Runtime$Serialization$ISerializationSurrogateProvider2$GetReferencedTypeOnImport","d":701398,"h":17180570582,"f":257}],"i":[635862],"h":701398}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$srsp.System.Runtime.Serialization.ISerializationSurrogateProvider ]; }
            static get $fullName() { return `System.Runtime.Serialization.ISerializationSurrogateProvider2`; }
        });
        
        $asm.$cls("$srsp.System.SR", ($self) => class SR
        {
            /*global::System.Resources.ResourceManager*/ static s_resourceManager = null;
            /*global::System.Globalization.CultureInfo*/ static resourceCulture = null;
            static /*global::System.Resources.ResourceManager */ get ResourceManager()
            {
                if ($.$spc.System.Object.ReferenceEquals($.$srsp.System.SR.s_resourceManager, null))
                {
                    /*global::System.Resources.ResourceManager*/ let temp = new $.$spc.System.Resources.ResourceManager().$ctor$3("System.Runtime.Serialization.Primitives", $.$srsp.System.SR.$type.Assembly);
                    $.$srsp.System.SR.s_resourceManager = temp;
                }
                return $.$srsp.System.SR.s_resourceManager;
            }
            static /*global::System.Globalization.CultureInfo */ get Culture()
            {
                return $.$srsp.System.SR.resourceCulture;
            }
            static /*global::System.Globalization.CultureInfo */ set Culture(value)
            {
                $.$srsp.System.SR.resourceCulture = value;
            }
            static /*string */ get OrderCannotBeNegative()
            {
                return "Property 'Order' in DataMemberAttribute attribute cannot be a negative number.";
            }
            /*bool*/ static s_usingResourceKeys = false;
            static /*bool */ GetUsingResourceKeysSwitchValue()
            {
                /*bool*/ let usingResourceKeys;
                return $.$spc.System.AppContext.TryGetSwitch("System.Resources.UseSystemResourceKeys", $.$ref(() => usingResourceKeys, ($v) => usingResourceKeys = $v, $.$spc.System.Boolean)) ? usingResourceKeys : false;
            }
            static /*bool */ UsingResourceKeys()
            {
                return $.$srsp.System.SR.s_usingResourceKeys;
            }
            static /*string */ GetResourceString(/*string*/ resourceKey)
            {
                if ($.$srsp.System.SR.UsingResourceKeys())
                {
                    return resourceKey;
                }
                /*string?*/ let resourceString = null;
                try
                {
                    resourceString = $.$srsp.System.SR.ResourceManager.GetString(resourceKey);
                }
                catch($e)
                {
                }
                return resourceString;
            }
            static /*string */ GetResourceString$1(/*string*/ resourceKey, /*string*/ defaultString)
            {
                /*string*/ let resourceString = $.$srsp.System.SR.GetResourceString(resourceKey);
                return $.$spc.System.String.op_Equality(resourceKey, resourceString) || $.$spc.System.String.op_Equality(resourceString, null) ? defaultString : resourceString;
            }
            static /*string */ Format(/*string*/ resourceFormat, /*object?*/ p1)
            {
                if ($.$srsp.System.SR.UsingResourceKeys())
                {
                    return $.$spc.System.String.Join$10(", ", $.$spc.System.ReadOnlySpan$$($.$spc.System.Object).op_Implicit([ resourceFormat, p1 ]));
                }
                return $.$spc.System.String.Format(resourceFormat, p1);
            }
            static /*string */ Format$1(/*string*/ resourceFormat, /*object?*/ p1, /*object?*/ p2)
            {
                if ($.$srsp.System.SR.UsingResourceKeys())
                {
                    return $.$spc.System.String.Join$10(", ", $.$spc.System.ReadOnlySpan$$($.$spc.System.Object).op_Implicit([ resourceFormat, p1, p2 ]));
                }
                return $.$spc.System.String.Format$1(resourceFormat, p1, p2);
            }
            static /*string */ Format$2(/*string*/ resourceFormat, /*object?*/ p1, /*object?*/ p2, /*object?*/ p3)
            {
                if ($.$srsp.System.SR.UsingResourceKeys())
                {
                    return $.$spc.System.String.Join$10(", ", $.$spc.System.ReadOnlySpan$$($.$spc.System.Object).op_Implicit([ resourceFormat, p1, p2, p3 ]));
                }
                return $.$spc.System.String.Format$2(resourceFormat, p1, p2, p3);
            }
            static /*string */ Format$3(/*string*/ resourceFormat, /*params object?[]?*/ args)
            {
                if (args !== null)
                {
                    if ($.$srsp.System.SR.UsingResourceKeys())
                    {
                        return resourceFormat + ", " + $.$spc.System.String.Join$9(", ", args);
                    }
                    return $.$spc.System.String.Format$3(resourceFormat, args);
                }
                return resourceFormat;
            }
            static /*string */ Format$4(/*IFormatProvider?*/ provider, /*string*/ resourceFormat, /*object?*/ p1)
            {
                if ($.$srsp.System.SR.UsingResourceKeys())
                {
                    return $.$spc.System.String.Join$10(", ", $.$spc.System.ReadOnlySpan$$($.$spc.System.Object).op_Implicit([ resourceFormat, p1 ]));
                }
                return $.$spc.System.String.Format$5(provider, resourceFormat, p1);
            }
            static /*string */ Format$5(/*IFormatProvider?*/ provider, /*string*/ resourceFormat, /*object?*/ p1, /*object?*/ p2)
            {
                if ($.$srsp.System.SR.UsingResourceKeys())
                {
                    return $.$spc.System.String.Join$10(", ", $.$spc.System.ReadOnlySpan$$($.$spc.System.Object).op_Implicit([ resourceFormat, p1, p2 ]));
                }
                return $.$spc.System.String.Format$6(provider, resourceFormat, p1, p2);
            }
            static /*string */ Format$6(/*IFormatProvider?*/ provider, /*string*/ resourceFormat, /*object?*/ p1, /*object?*/ p2, /*object?*/ p3)
            {
                if ($.$srsp.System.SR.UsingResourceKeys())
                {
                    return $.$spc.System.String.Join$10(", ", $.$spc.System.ReadOnlySpan$$($.$spc.System.Object).op_Implicit([ resourceFormat, p1, p2, p3 ]));
                }
                return $.$spc.System.String.Format$7(provider, resourceFormat, p1, p2, p3);
            }
            static /*string */ Format$7(/*IFormatProvider?*/ provider, /*string*/ resourceFormat, /*params object?[]?*/ args)
            {
                if (args !== null)
                {
                    if ($.$srsp.System.SR.UsingResourceKeys())
                    {
                        return resourceFormat + ", " + $.$spc.System.String.Join$9(", ", args);
                    }
                    return $.$spc.System.String.Format$8(provider, resourceFormat, args);
                }
                return resourceFormat;
            }
            //Static Initializer
            static $sinit()
            {
                {
                    this.s_usingResourceKeys = $.$srsp.System.SR.GetUsingResourceKeysSwitchValue();
                }
            }
            static $h = 832470;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"h":832470}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.SR`; }
        });
        
        $asm.$cls("$srsp.System.Obsoletions", ($self) => class Obsoletions
        {
            /*string*/ static SharedUrlFormat = null;
            /*string*/ static SystemTextEncodingUTF7Message = null;
            /*string*/ static SystemTextEncodingUTF7DiagId = null;
            /*string*/ static PrincipalPermissionAttributeMessage = null;
            /*string*/ static PrincipalPermissionAttributeDiagId = null;
            /*string*/ static CodeAccessSecurityMessage = null;
            /*string*/ static CodeAccessSecurityDiagId = null;
            /*string*/ static ConstrainedExecutionRegionMessage = null;
            /*string*/ static ConstrainedExecutionRegionDiagId = null;
            /*string*/ static GlobalAssemblyCacheMessage = null;
            /*string*/ static GlobalAssemblyCacheDiagId = null;
            /*string*/ static ThreadAbortMessage = null;
            /*string*/ static ThreadResetAbortMessage = null;
            /*string*/ static ThreadAbortDiagId = null;
            /*string*/ static DefaultCryptoAlgorithmsMessage = null;
            /*string*/ static DefaultCryptoAlgorithmsDiagId = null;
            /*string*/ static CreatePdbGeneratorMessage = null;
            /*string*/ static CreatePdbGeneratorDiagId = null;
            /*string*/ static AuthenticationManagerMessage = null;
            /*string*/ static AuthenticationManagerDiagId = null;
            /*string*/ static RemotingApisMessage = null;
            /*string*/ static RemotingApisDiagId = null;
            /*string*/ static BinaryFormatterMessage = null;
            /*string*/ static BinaryFormatterDiagId = null;
            /*string*/ static CodeBaseMessage = null;
            /*string*/ static CodeBaseDiagId = null;
            /*string*/ static EscapeUriStringMessage = null;
            /*string*/ static EscapeUriStringDiagId = null;
            /*string*/ static WebRequestMessage = null;
            /*string*/ static WebRequestDiagId = null;
            /*string*/ static DisablePrivateReflectionAttributeMessage = null;
            /*string*/ static DisablePrivateReflectionAttributeDiagId = null;
            /*string*/ static GetContextInfoMessage = null;
            /*string*/ static GetContextInfoDiagId = null;
            /*string*/ static StrongNameKeyPairMessage = null;
            /*string*/ static StrongNameKeyPairDiagId = null;
            /*string*/ static ReflectionOnlyLoadingMessage = null;
            /*string*/ static ReflectionOnlyLoadingDiagId = null;
            /*string*/ static RuntimeEnvironmentMessage = null;
            /*string*/ static RuntimeEnvironmentDiagId = null;
            /*string*/ static JsonSerializerOptionsIgnoreNullValuesMessage = null;
            /*string*/ static JsonSerializerOptionsIgnoreNullValuesDiagId = null;
            /*string*/ static DerivedCryptographicTypesMessage = null;
            /*string*/ static DerivedCryptographicTypesDiagId = null;
            /*string*/ static RijndaelMessage = null;
            /*string*/ static RijndaelDiagId = null;
            /*string*/ static RNGCryptoServiceProviderMessage = null;
            /*string*/ static RNGCryptoServiceProviderDiagId = null;
            /*string*/ static AppDomainCreateUnloadMessage = null;
            /*string*/ static AppDomainCreateUnloadDiagId = null;
            /*string*/ static SuppressIldasmAttributeMessage = null;
            /*string*/ static SuppressIldasmAttributeDiagId = null;
            /*string*/ static X509CertificateImmutableMessage = null;
            /*string*/ static X509CertificateImmutableDiagId = null;
            /*string*/ static PublicKeyPropertyMessage = null;
            /*string*/ static PublicKeyPropertyDiagId = null;
            /*string*/ static X509CertificatePrivateKeyMessage = null;
            /*string*/ static X509CertificatePrivateKeyDiagId = null;
            /*string*/ static ProduceLegacyHmacValuesMessage = null;
            /*string*/ static ProduceLegacyHmacValuesDiagId = null;
            /*string*/ static UseManagedSha1Message = null;
            /*string*/ static UseManagedSha1DiagId = null;
            /*string*/ static CryptoConfigEncodeOIDMessage = null;
            /*string*/ static CryptoConfigEncodeOIDDiagId = null;
            /*string*/ static CorruptedStateRecoveryMessage = null;
            /*string*/ static CorruptedStateRecoveryDiagId = null;
            /*string*/ static Rfc2898CryptDeriveKeyMessage = null;
            /*string*/ static Rfc2898CryptDeriveKeyDiagId = null;
            /*string*/ static CmsSignerCspParamsCtorMessage = null;
            /*string*/ static CmsSignerCspParamsCtorDiagId = null;
            /*string*/ static SignerInfoCounterSigMessage = null;
            /*string*/ static SignerInfoCounterSigDiagId = null;
            /*string*/ static RegexCompileToAssemblyMessage = null;
            /*string*/ static RegexCompileToAssemblyDiagId = null;
            /*string*/ static AssemblyNameMembersMessage = null;
            /*string*/ static AssemblyNameMembersDiagId = null;
            /*string*/ static SystemDataSerializationFormatBinaryMessage = null;
            /*string*/ static SystemDataSerializationFormatBinaryDiagId = null;
            /*string*/ static TlsVersion10and11Message = null;
            /*string*/ static TlsVersion10and11DiagId = null;
            /*string*/ static EncryptionPolicyMessage = null;
            /*string*/ static EncryptionPolicyDiagId = null;
            /*string*/ static EccXmlExportImportMessage = null;
            /*string*/ static EccXmlExportImportDiagId = null;
            /*string*/ static EcDhPublicKeyBlobMessage = null;
            /*string*/ static EcDhPublicKeyBlobDiagId = null;
            /*string*/ static AssemblyNameCodeBaseMessage = null;
            /*string*/ static AssemblyNameCodeBaseDiagId = null;
            /*string*/ static CryptoStringFactoryMessage = null;
            /*string*/ static CryptoStringFactoryDiagId = null;
            /*string*/ static ControlledExecutionRunMessage = null;
            /*string*/ static ControlledExecutionRunDiagId = null;
            /*string*/ static XmlSecureResolverMessage = null;
            /*string*/ static XmlSecureResolverDiagId = null;
            /*string*/ static RsaEncryptDecryptValueMessage = null;
            /*string*/ static RsaEncryptDecryptDiagId = null;
            /*string*/ static JsonSerializerOptionsAddContextMessage = null;
            /*string*/ static JsonSerializerOptionsAddContextDiagId = null;
            /*string*/ static LegacyFormatterMessage = null;
            /*string*/ static LegacyFormatterDiagId = null;
            /*string*/ static LegacyFormatterImplMessage = null;
            /*string*/ static LegacyFormatterImplDiagId = null;
            /*string*/ static RegexExtensibilityImplMessage = null;
            /*string*/ static RegexExtensibilityDiagId = null;
            /*string*/ static AesGcmTagConstructorMessage = null;
            /*string*/ static AesGcmTagConstructorDiagId = null;
            /*string*/ static ThreadVolatileReadWriteMessage = null;
            /*string*/ static ThreadVolatileReadWriteDiagId = null;
            /*string*/ static ArmIntrinsicPerformsUnsignedOperationMessage = null;
            /*string*/ static ArmIntrinsicPerformsUnsignedOperationDiagId = null;
            /*string*/ static LoadFromHashAlgorithmMessage = null;
            /*string*/ static LoadFromHashAlgorithmDiagId = null;
            /*string*/ static X509CtorCertDataObsoleteMessage = null;
            /*string*/ static X509CtorCertDataObsoleteDiagId = null;
            /*string*/ static TlsCipherAlgorithmEnumsMessage = null;
            /*string*/ static TlsCipherAlgorithmEnumsDiagId = null;
            /*string*/ static SystemEventsEventsThreadShutdownMessage = null;
            /*string*/ static SystemEventsEventsThreadShutdownDiagId = null;
            /*string*/ static Rfc2898DeriveBytesCtorMessage = null;
            /*string*/ static Rfc2898DeriveBytesCtorDiagId = null;
            /*string*/ static QueryableMinByMaxByTSourceObsoleteMessage = null;
            /*string*/ static QueryableMinByMaxByTSourceObsoleteDiagId = null;
            /*string*/ static XsltSettingsEnableScriptMessage = null;
            /*string*/ static XsltSettingsEnableScriptDiagId = null;
            //Static Initializer
            static $sinit()
            {
                {
                    this.SharedUrlFormat = "https://aka.ms/dotnet-warnings/{0}";
                }
                {
                    this.SystemTextEncodingUTF7Message = "The UTF-7 encoding is insecure and should not be used. Consider using UTF-8 instead.";
                }
                {
                    this.SystemTextEncodingUTF7DiagId = "SYSLIB0001";
                }
                {
                    this.PrincipalPermissionAttributeMessage = "PrincipalPermissionAttribute is not honored by the runtime and must not be used.";
                }
                {
                    this.PrincipalPermissionAttributeDiagId = "SYSLIB0002";
                }
                {
                    this.CodeAccessSecurityMessage = "Code Access Security is not supported or honored by the runtime.";
                }
                {
                    this.CodeAccessSecurityDiagId = "SYSLIB0003";
                }
                {
                    this.ConstrainedExecutionRegionMessage = "The Constrained Execution Region (CER) feature is not supported.";
                }
                {
                    this.ConstrainedExecutionRegionDiagId = "SYSLIB0004";
                }
                {
                    this.GlobalAssemblyCacheMessage = "The Global Assembly Cache is not supported.";
                }
                {
                    this.GlobalAssemblyCacheDiagId = "SYSLIB0005";
                }
                {
                    this.ThreadAbortMessage = "Thread.Abort is not supported and throws PlatformNotSupportedException.";
                }
                {
                    this.ThreadResetAbortMessage = "Thread.ResetAbort is not supported and throws PlatformNotSupportedException.";
                }
                {
                    this.ThreadAbortDiagId = "SYSLIB0006";
                }
                {
                    this.DefaultCryptoAlgorithmsMessage = "The default implementation of this cryptography algorithm is not supported.";
                }
                {
                    this.DefaultCryptoAlgorithmsDiagId = "SYSLIB0007";
                }
                {
                    this.CreatePdbGeneratorMessage = "The CreatePdbGenerator API is not supported and throws PlatformNotSupportedException.";
                }
                {
                    this.CreatePdbGeneratorDiagId = "SYSLIB0008";
                }
                {
                    this.AuthenticationManagerMessage = "AuthenticationManager is not supported. Methods will no-op or throw PlatformNotSupportedException.";
                }
                {
                    this.AuthenticationManagerDiagId = "SYSLIB0009";
                }
                {
                    this.RemotingApisMessage = "This Remoting API is not supported and throws PlatformNotSupportedException.";
                }
                {
                    this.RemotingApisDiagId = "SYSLIB0010";
                }
                {
                    this.BinaryFormatterMessage = "BinaryFormatter serialization is obsolete and should not be used. See https://aka.ms/binaryformatter for more information.";
                }
                {
                    this.BinaryFormatterDiagId = "SYSLIB0011";
                }
                {
                    this.CodeBaseMessage = "Assembly.CodeBase and Assembly.EscapedCodeBase are only included for .NET Framework compatibility. Use Assembly.Location instead.";
                }
                {
                    this.CodeBaseDiagId = "SYSLIB0012";
                }
                {
                    this.EscapeUriStringMessage = "Uri.EscapeUriString can corrupt the Uri string in some cases. Consider using Uri.EscapeDataString for query string components instead.";
                }
                {
                    this.EscapeUriStringDiagId = "SYSLIB0013";
                }
                {
                    this.WebRequestMessage = "WebRequest, HttpWebRequest, ServicePoint, and WebClient are obsolete. Use HttpClient instead.";
                }
                {
                    this.WebRequestDiagId = "SYSLIB0014";
                }
                {
                    this.DisablePrivateReflectionAttributeMessage = "DisablePrivateReflectionAttribute has no effect in .NET 6.0+.";
                }
                {
                    this.DisablePrivateReflectionAttributeDiagId = "SYSLIB0015";
                }
                {
                    this.GetContextInfoMessage = "Use the Graphics.GetContextInfo overloads that accept arguments for better performance and fewer allocations.";
                }
                {
                    this.GetContextInfoDiagId = "SYSLIB0016";
                }
                {
                    this.StrongNameKeyPairMessage = "Strong name signing is not supported and throws PlatformNotSupportedException.";
                }
                {
                    this.StrongNameKeyPairDiagId = "SYSLIB0017";
                }
                {
                    this.ReflectionOnlyLoadingMessage = "ReflectionOnly loading is not supported and throws PlatformNotSupportedException.";
                }
                {
                    this.ReflectionOnlyLoadingDiagId = "SYSLIB0018";
                }
                {
                    this.RuntimeEnvironmentMessage = "RuntimeEnvironment members SystemConfigurationFile, GetRuntimeInterfaceAsIntPtr, and GetRuntimeInterfaceAsObject are not supported and throw PlatformNotSupportedException.";
                }
                {
                    this.RuntimeEnvironmentDiagId = "SYSLIB0019";
                }
                {
                    this.JsonSerializerOptionsIgnoreNullValuesMessage = "JsonSerializerOptions.IgnoreNullValues is obsolete. To ignore null values when serializing, set DefaultIgnoreCondition to JsonIgnoreCondition.WhenWritingNull.";
                }
                {
                    this.JsonSerializerOptionsIgnoreNullValuesDiagId = "SYSLIB0020";
                }
                {
                    this.DerivedCryptographicTypesMessage = "Derived cryptographic types are obsolete. Use the Create method on the base type instead.";
                }
                {
                    this.DerivedCryptographicTypesDiagId = "SYSLIB0021";
                }
                {
                    this.RijndaelMessage = "The Rijndael and RijndaelManaged types are obsolete. Use Aes instead.";
                }
                {
                    this.RijndaelDiagId = "SYSLIB0022";
                }
                {
                    this.RNGCryptoServiceProviderMessage = "RNGCryptoServiceProvider is obsolete. To generate a random number, use one of the RandomNumberGenerator static methods instead.";
                }
                {
                    this.RNGCryptoServiceProviderDiagId = "SYSLIB0023";
                }
                {
                    this.AppDomainCreateUnloadMessage = "Creating and unloading AppDomains is not supported and throws an exception.";
                }
                {
                    this.AppDomainCreateUnloadDiagId = "SYSLIB0024";
                }
                {
                    this.SuppressIldasmAttributeMessage = "SuppressIldasmAttribute has no effect in .NET 6.0+.";
                }
                {
                    this.SuppressIldasmAttributeDiagId = "SYSLIB0025";
                }
                {
                    this.X509CertificateImmutableMessage = "X509Certificate and X509Certificate2 are immutable. Use X509CertificateLoader to create a new certificate.";
                }
                {
                    this.X509CertificateImmutableDiagId = "SYSLIB0026";
                }
                {
                    this.PublicKeyPropertyMessage = "PublicKey.Key is obsolete. Use the appropriate method to get the public key, such as GetRSAPublicKey.";
                }
                {
                    this.PublicKeyPropertyDiagId = "SYSLIB0027";
                }
                {
                    this.X509CertificatePrivateKeyMessage = "X509Certificate2.PrivateKey is obsolete. Use the appropriate method to get the private key, such as GetRSAPrivateKey, or use the CopyWithPrivateKey method to create a new instance with a private key.";
                }
                {
                    this.X509CertificatePrivateKeyDiagId = "SYSLIB0028";
                }
                {
                    this.ProduceLegacyHmacValuesMessage = "ProduceLegacyHmacValues is obsolete. Producing legacy HMAC values is not supported.";
                }
                {
                    this.ProduceLegacyHmacValuesDiagId = "SYSLIB0029";
                }
                {
                    this.UseManagedSha1Message = "HMACSHA1 always uses the algorithm implementation provided by the platform. Use a constructor without the useManagedSha1 parameter.";
                }
                {
                    this.UseManagedSha1DiagId = "SYSLIB0030";
                }
                {
                    this.CryptoConfigEncodeOIDMessage = "EncodeOID is obsolete. Use the ASN.1 functionality provided in System.Formats.Asn1.";
                }
                {
                    this.CryptoConfigEncodeOIDDiagId = "SYSLIB0031";
                }
                {
                    this.CorruptedStateRecoveryMessage = "Recovery from corrupted process state exceptions is not supported; HandleProcessCorruptedStateExceptionsAttribute is ignored.";
                }
                {
                    this.CorruptedStateRecoveryDiagId = "SYSLIB0032";
                }
                {
                    this.Rfc2898CryptDeriveKeyMessage = "Rfc2898DeriveBytes.CryptDeriveKey is obsolete and is not supported. Use PasswordDeriveBytes.CryptDeriveKey instead.";
                }
                {
                    this.Rfc2898CryptDeriveKeyDiagId = "SYSLIB0033";
                }
                {
                    this.CmsSignerCspParamsCtorMessage = "CmsSigner(CspParameters) is obsolete and is not supported. Use an alternative constructor instead.";
                }
                {
                    this.CmsSignerCspParamsCtorDiagId = "SYSLIB0034";
                }
                {
                    this.SignerInfoCounterSigMessage = "ComputeCounterSignature without specifying a CmsSigner is obsolete and is not supported. Use the overload that accepts a CmsSigner.";
                }
                {
                    this.SignerInfoCounterSigDiagId = "SYSLIB0035";
                }
                {
                    this.RegexCompileToAssemblyMessage = "Regex.CompileToAssembly is obsolete and not supported. Use the GeneratedRegexAttribute with the regular expression source generator instead.";
                }
                {
                    this.RegexCompileToAssemblyDiagId = "SYSLIB0036";
                }
                {
                    this.AssemblyNameMembersMessage = "AssemblyName members HashAlgorithm, ProcessorArchitecture, and VersionCompatibility are obsolete and not supported.";
                }
                {
                    this.AssemblyNameMembersDiagId = "SYSLIB0037";
                }
                {
                    this.SystemDataSerializationFormatBinaryMessage = "SerializationFormat.Binary is obsolete and should not be used. See https://aka.ms/serializationformat-binary-obsolete for more information.";
                }
                {
                    this.SystemDataSerializationFormatBinaryDiagId = "SYSLIB0038";
                }
                {
                    this.TlsVersion10and11Message = "TLS versions 1.0 and 1.1 have known vulnerabilities and are not recommended. Use a newer TLS version instead, or use SslProtocols.None to defer to OS defaults.";
                }
                {
                    this.TlsVersion10and11DiagId = "SYSLIB0039";
                }
                {
                    this.EncryptionPolicyMessage = "EncryptionPolicy.NoEncryption and AllowEncryption significantly reduce security and should not be used in production code.";
                }
                {
                    this.EncryptionPolicyDiagId = "SYSLIB0040";
                }
                {
                    this.EccXmlExportImportMessage = "ToXmlString and FromXmlString have no implementation for ECC types, and are obsolete. Use a standard import and export format such as ExportSubjectPublicKeyInfo or ImportSubjectPublicKeyInfo for public keys and ExportPkcs8PrivateKey or ImportPkcs8PrivateKey for private keys.";
                }
                {
                    this.EccXmlExportImportDiagId = "SYSLIB0042";
                }
                {
                    this.EcDhPublicKeyBlobMessage = "ECDiffieHellmanPublicKey.ToByteArray() and the associated constructor do not have a consistent and interoperable implementation on all platforms. Use ECDiffieHellmanPublicKey.ExportSubjectPublicKeyInfo() instead.";
                }
                {
                    this.EcDhPublicKeyBlobDiagId = "SYSLIB0043";
                }
                {
                    this.AssemblyNameCodeBaseMessage = "AssemblyName.CodeBase and AssemblyName.EscapedCodeBase are obsolete. Using them for loading an assembly is not supported.";
                }
                {
                    this.AssemblyNameCodeBaseDiagId = "SYSLIB0044";
                }
                {
                    this.CryptoStringFactoryMessage = "Cryptographic factory methods accepting an algorithm name are obsolete. Use the parameterless Create factory method on the algorithm type instead.";
                }
                {
                    this.CryptoStringFactoryDiagId = "SYSLIB0045";
                }
                {
                    this.ControlledExecutionRunMessage = "ControlledExecution.Run method may corrupt the process and should not be used in production code.";
                }
                {
                    this.ControlledExecutionRunDiagId = "SYSLIB0046";
                }
                {
                    this.XmlSecureResolverMessage = "XmlSecureResolver is obsolete. Use XmlResolver.ThrowingResolver instead when attempting to forbid XML external entity resolution.";
                }
                {
                    this.XmlSecureResolverDiagId = "SYSLIB0047";
                }
                {
                    this.RsaEncryptDecryptValueMessage = "RSA.EncryptValue and DecryptValue are not supported and throw NotSupportedException. Use RSA.Encrypt and RSA.Decrypt instead.";
                }
                {
                    this.RsaEncryptDecryptDiagId = "SYSLIB0048";
                }
                {
                    this.JsonSerializerOptionsAddContextMessage = "JsonSerializerOptions.AddContext is obsolete. To register a JsonSerializerContext, use either the TypeInfoResolver or TypeInfoResolverChain properties.";
                }
                {
                    this.JsonSerializerOptionsAddContextDiagId = "SYSLIB0049";
                }
                {
                    this.LegacyFormatterMessage = "Formatter-based serialization is obsolete and should not be used.";
                }
                {
                    this.LegacyFormatterDiagId = "SYSLIB0050";
                }
                {
                    this.LegacyFormatterImplMessage = "This API supports obsolete formatter-based serialization. It should not be called or extended by application code.";
                }
                {
                    this.LegacyFormatterImplDiagId = "SYSLIB0051";
                }
                {
                    this.RegexExtensibilityImplMessage = "This API supports obsolete mechanisms for Regex extensibility. It is not supported.";
                }
                {
                    this.RegexExtensibilityDiagId = "SYSLIB0052";
                }
                {
                    this.AesGcmTagConstructorMessage = "AesGcm should indicate the required tag size for encryption and decryption. Use a constructor that accepts the tag size.";
                }
                {
                    this.AesGcmTagConstructorDiagId = "SYSLIB0053";
                }
                {
                    this.ThreadVolatileReadWriteMessage = "Thread.VolatileRead and Thread.VolatileWrite are obsolete. Use Volatile.Read or Volatile.Write respectively instead.";
                }
                {
                    this.ThreadVolatileReadWriteDiagId = "SYSLIB0054";
                }
                {
                    this.ArmIntrinsicPerformsUnsignedOperationMessage = "The underlying hardware instruction does not perform a signed saturate narrowing operation, and it always returns an unsigned result. Use the unsigned overload instead.";
                }
                {
                    this.ArmIntrinsicPerformsUnsignedOperationDiagId = "SYSLIB0055";
                }
                {
                    this.LoadFromHashAlgorithmMessage = "LoadFrom with a custom AssemblyHashAlgorithm is obsolete. Use overloads without an AssemblyHashAlgorithm.";
                }
                {
                    this.LoadFromHashAlgorithmDiagId = "SYSLIB0056";
                }
                {
                    this.X509CtorCertDataObsoleteMessage = "Loading certificate data through the constructor or Import is obsolete. Use X509CertificateLoader instead to load certificates.";
                }
                {
                    this.X509CtorCertDataObsoleteDiagId = "SYSLIB0057";
                }
                {
                    this.TlsCipherAlgorithmEnumsMessage = "KeyExchangeAlgorithm, KeyExchangeStrength, CipherAlgorithm, CipherStrength, HashAlgorithm and HashStrength properties of SslStream are obsolete. Use NegotiatedCipherSuite instead.";
                }
                {
                    this.TlsCipherAlgorithmEnumsDiagId = "SYSLIB0058";
                }
                {
                    this.SystemEventsEventsThreadShutdownMessage = "SystemEvents.EventsThreadShutdown callbacks are not run before the process exits. Use AppDomain.ProcessExit instead.";
                }
                {
                    this.SystemEventsEventsThreadShutdownDiagId = "SYSLIB0059";
                }
                {
                    this.Rfc2898DeriveBytesCtorMessage = "The constructors on Rfc2898DeriveBytes are obsolete. Use the static Pbkdf2 method instead.";
                }
                {
                    this.Rfc2898DeriveBytesCtorDiagId = "SYSLIB0060";
                }
                {
                    this.QueryableMinByMaxByTSourceObsoleteMessage = "The Queryable MinBy and MaxBy taking an IComparer<TSource> are obsolete. Use the new ones that take an IComparer<TKey>.";
                }
                {
                    this.QueryableMinByMaxByTSourceObsoleteDiagId = "SYSLIB0061";
                }
                {
                    this.XsltSettingsEnableScriptMessage = "XSLT Script blocks are not supported.";
                }
                {
                    this.XsltSettingsEnableScriptDiagId = "SYSLIB0062";
                }
            }
            static $h = 111574;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"l":[{"t":1310721,"n":"SharedUrlFormat","d":111574,"h":4295078870,"f":40},{"t":1310721,"n":"SystemTextEncodingUTF7Message","d":111574,"h":8590046166,"f":40},{"t":1310721,"n":"SystemTextEncodingUTF7DiagId","d":111574,"h":12885013462,"f":40},{"t":1310721,"n":"PrincipalPermissionAttributeMessage","d":111574,"h":17179980758,"f":40},{"t":1310721,"n":"PrincipalPermissionAttributeDiagId","d":111574,"h":21474948054,"f":40},{"t":1310721,"n":"CodeAccessSecurityMessage","d":111574,"h":25769915350,"f":40},{"t":1310721,"n":"CodeAccessSecurityDiagId","d":111574,"h":30064882646,"f":40},{"t":1310721,"n":"ConstrainedExecutionRegionMessage","d":111574,"h":34359849942,"f":40},{"t":1310721,"n":"ConstrainedExecutionRegionDiagId","d":111574,"h":38654817238,"f":40},{"t":1310721,"n":"GlobalAssemblyCacheMessage","d":111574,"h":42949784534,"f":40},{"t":1310721,"n":"GlobalAssemblyCacheDiagId","d":111574,"h":47244751830,"f":40},{"t":1310721,"n":"ThreadAbortMessage","d":111574,"h":51539719126,"f":40},{"t":1310721,"n":"ThreadResetAbortMessage","d":111574,"h":55834686422,"f":40},{"t":1310721,"n":"ThreadAbortDiagId","d":111574,"h":60129653718,"f":40},{"t":1310721,"n":"DefaultCryptoAlgorithmsMessage","d":111574,"h":64424621014,"f":40},{"t":1310721,"n":"DefaultCryptoAlgorithmsDiagId","d":111574,"h":68719588310,"f":40},{"t":1310721,"n":"CreatePdbGeneratorMessage","d":111574,"h":73014555606,"f":40},{"t":1310721,"n":"CreatePdbGeneratorDiagId","d":111574,"h":77309522902,"f":40},{"t":1310721,"n":"AuthenticationManagerMessage","d":111574,"h":81604490198,"f":40},{"t":1310721,"n":"AuthenticationManagerDiagId","d":111574,"h":85899457494,"f":40},{"t":1310721,"n":"RemotingApisMessage","d":111574,"h":90194424790,"f":40},{"t":1310721,"n":"RemotingApisDiagId","d":111574,"h":94489392086,"f":40},{"t":1310721,"n":"BinaryFormatterMessage","d":111574,"h":98784359382,"f":40},{"t":1310721,"n":"BinaryFormatterDiagId","d":111574,"h":103079326678,"f":40},{"t":1310721,"n":"CodeBaseMessage","d":111574,"h":107374293974,"f":40},{"t":1310721,"n":"CodeBaseDiagId","d":111574,"h":111669261270,"f":40},{"t":1310721,"n":"EscapeUriStringMessage","d":111574,"h":115964228566,"f":40},{"t":1310721,"n":"EscapeUriStringDiagId","d":111574,"h":120259195862,"f":40},{"t":1310721,"n":"WebRequestMessage","d":111574,"h":124554163158,"f":40},{"t":1310721,"n":"WebRequestDiagId","d":111574,"h":128849130454,"f":40},{"t":1310721,"n":"DisablePrivateReflectionAttributeMessage","d":111574,"h":133144097750,"f":40},{"t":1310721,"n":"DisablePrivateReflectionAttributeDiagId","d":111574,"h":137439065046,"f":40},{"t":1310721,"n":"GetContextInfoMessage","d":111574,"h":141734032342,"f":40},{"t":1310721,"n":"GetContextInfoDiagId","d":111574,"h":146028999638,"f":40},{"t":1310721,"n":"StrongNameKeyPairMessage","d":111574,"h":150323966934,"f":40},{"t":1310721,"n":"StrongNameKeyPairDiagId","d":111574,"h":154618934230,"f":40},{"t":1310721,"n":"ReflectionOnlyLoadingMessage","d":111574,"h":158913901526,"f":40},{"t":1310721,"n":"ReflectionOnlyLoadingDiagId","d":111574,"h":163208868822,"f":40},{"t":1310721,"n":"RuntimeEnvironmentMessage","d":111574,"h":167503836118,"f":40},{"t":1310721,"n":"RuntimeEnvironmentDiagId","d":111574,"h":171798803414,"f":40},{"t":1310721,"n":"JsonSerializerOptionsIgnoreNullValuesMessage","d":111574,"h":176093770710,"f":40},{"t":1310721,"n":"JsonSerializerOptionsIgnoreNullValuesDiagId","d":111574,"h":180388738006,"f":40},{"t":1310721,"n":"DerivedCryptographicTypesMessage","d":111574,"h":184683705302,"f":40},{"t":1310721,"n":"DerivedCryptographicTypesDiagId","d":111574,"h":188978672598,"f":40},{"t":1310721,"n":"RijndaelMessage","d":111574,"h":193273639894,"f":40},{"t":1310721,"n":"RijndaelDiagId","d":111574,"h":197568607190,"f":40},{"t":1310721,"n":"RNGCryptoServiceProviderMessage","d":111574,"h":201863574486,"f":40},{"t":1310721,"n":"RNGCryptoServiceProviderDiagId","d":111574,"h":206158541782,"f":40},{"t":1310721,"n":"AppDomainCreateUnloadMessage","d":111574,"h":210453509078,"f":40},{"t":1310721,"n":"AppDomainCreateUnloadDiagId","d":111574,"h":214748476374,"f":40},{"t":1310721,"n":"SuppressIldasmAttributeMessage","d":111574,"h":219043443670,"f":40},{"t":1310721,"n":"SuppressIldasmAttributeDiagId","d":111574,"h":223338410966,"f":40},{"t":1310721,"n":"X509CertificateImmutableMessage","d":111574,"h":227633378262,"f":40},{"t":1310721,"n":"X509CertificateImmutableDiagId","d":111574,"h":231928345558,"f":40},{"t":1310721,"n":"PublicKeyPropertyMessage","d":111574,"h":236223312854,"f":40},{"t":1310721,"n":"PublicKeyPropertyDiagId","d":111574,"h":240518280150,"f":40},{"t":1310721,"n":"X509CertificatePrivateKeyMessage","d":111574,"h":244813247446,"f":40},{"t":1310721,"n":"X509CertificatePrivateKeyDiagId","d":111574,"h":249108214742,"f":40},{"t":1310721,"n":"ProduceLegacyHmacValuesMessage","d":111574,"h":253403182038,"f":40},{"t":1310721,"n":"ProduceLegacyHmacValuesDiagId","d":111574,"h":257698149334,"f":40},{"t":1310721,"n":"UseManagedSha1Message","d":111574,"h":261993116630,"f":40},{"t":1310721,"n":"UseManagedSha1DiagId","d":111574,"h":266288083926,"f":40},{"t":1310721,"n":"CryptoConfigEncodeOIDMessage","d":111574,"h":270583051222,"f":40},{"t":1310721,"n":"CryptoConfigEncodeOIDDiagId","d":111574,"h":274878018518,"f":40},{"t":1310721,"n":"CorruptedStateRecoveryMessage","d":111574,"h":279172985814,"f":40},{"t":1310721,"n":"CorruptedStateRecoveryDiagId","d":111574,"h":283467953110,"f":40},{"t":1310721,"n":"Rfc2898CryptDeriveKeyMessage","d":111574,"h":287762920406,"f":40},{"t":1310721,"n":"Rfc2898CryptDeriveKeyDiagId","d":111574,"h":292057887702,"f":40},{"t":1310721,"n":"CmsSignerCspParamsCtorMessage","d":111574,"h":296352854998,"f":40},{"t":1310721,"n":"CmsSignerCspParamsCtorDiagId","d":111574,"h":300647822294,"f":40},{"t":1310721,"n":"SignerInfoCounterSigMessage","d":111574,"h":304942789590,"f":40},{"t":1310721,"n":"SignerInfoCounterSigDiagId","d":111574,"h":309237756886,"f":40},{"t":1310721,"n":"RegexCompileToAssemblyMessage","d":111574,"h":313532724182,"f":40},{"t":1310721,"n":"RegexCompileToAssemblyDiagId","d":111574,"h":317827691478,"f":40},{"t":1310721,"n":"AssemblyNameMembersMessage","d":111574,"h":322122658774,"f":40},{"t":1310721,"n":"AssemblyNameMembersDiagId","d":111574,"h":326417626070,"f":40},{"t":1310721,"n":"SystemDataSerializationFormatBinaryMessage","d":111574,"h":330712593366,"f":40},{"t":1310721,"n":"SystemDataSerializationFormatBinaryDiagId","d":111574,"h":335007560662,"f":40},{"t":1310721,"n":"TlsVersion10and11Message","d":111574,"h":339302527958,"f":40},{"t":1310721,"n":"TlsVersion10and11DiagId","d":111574,"h":343597495254,"f":40},{"t":1310721,"n":"EncryptionPolicyMessage","d":111574,"h":347892462550,"f":40},{"t":1310721,"n":"EncryptionPolicyDiagId","d":111574,"h":352187429846,"f":40},{"t":1310721,"n":"EccXmlExportImportMessage","d":111574,"h":356482397142,"f":40},{"t":1310721,"n":"EccXmlExportImportDiagId","d":111574,"h":360777364438,"f":40},{"t":1310721,"n":"EcDhPublicKeyBlobMessage","d":111574,"h":365072331734,"f":40},{"t":1310721,"n":"EcDhPublicKeyBlobDiagId","d":111574,"h":369367299030,"f":40},{"t":1310721,"n":"AssemblyNameCodeBaseMessage","d":111574,"h":373662266326,"f":40},{"t":1310721,"n":"AssemblyNameCodeBaseDiagId","d":111574,"h":377957233622,"f":40},{"t":1310721,"n":"CryptoStringFactoryMessage","d":111574,"h":382252200918,"f":40},{"t":1310721,"n":"CryptoStringFactoryDiagId","d":111574,"h":386547168214,"f":40},{"t":1310721,"n":"ControlledExecutionRunMessage","d":111574,"h":390842135510,"f":40},{"t":1310721,"n":"ControlledExecutionRunDiagId","d":111574,"h":395137102806,"f":40},{"t":1310721,"n":"XmlSecureResolverMessage","d":111574,"h":399432070102,"f":40},{"t":1310721,"n":"XmlSecureResolverDiagId","d":111574,"h":403727037398,"f":40},{"t":1310721,"n":"RsaEncryptDecryptValueMessage","d":111574,"h":408022004694,"f":40},{"t":1310721,"n":"RsaEncryptDecryptDiagId","d":111574,"h":412316971990,"f":40},{"t":1310721,"n":"JsonSerializerOptionsAddContextMessage","d":111574,"h":416611939286,"f":40},{"t":1310721,"n":"JsonSerializerOptionsAddContextDiagId","d":111574,"h":420906906582,"f":40},{"t":1310721,"n":"LegacyFormatterMessage","d":111574,"h":425201873878,"f":40},{"t":1310721,"n":"LegacyFormatterDiagId","d":111574,"h":429496841174,"f":40},{"t":1310721,"n":"LegacyFormatterImplMessage","d":111574,"h":433791808470,"f":40},{"t":1310721,"n":"LegacyFormatterImplDiagId","d":111574,"h":438086775766,"f":40},{"t":1310721,"n":"RegexExtensibilityImplMessage","d":111574,"h":442381743062,"f":40},{"t":1310721,"n":"RegexExtensibilityDiagId","d":111574,"h":446676710358,"f":40},{"t":1310721,"n":"AesGcmTagConstructorMessage","d":111574,"h":450971677654,"f":40},{"t":1310721,"n":"AesGcmTagConstructorDiagId","d":111574,"h":455266644950,"f":40},{"t":1310721,"n":"ThreadVolatileReadWriteMessage","d":111574,"h":459561612246,"f":40},{"t":1310721,"n":"ThreadVolatileReadWriteDiagId","d":111574,"h":463856579542,"f":40},{"t":1310721,"n":"ArmIntrinsicPerformsUnsignedOperationMessage","d":111574,"h":468151546838,"f":40},{"t":1310721,"n":"ArmIntrinsicPerformsUnsignedOperationDiagId","d":111574,"h":472446514134,"f":40},{"t":1310721,"n":"LoadFromHashAlgorithmMessage","d":111574,"h":476741481430,"f":40},{"t":1310721,"n":"LoadFromHashAlgorithmDiagId","d":111574,"h":481036448726,"f":40},{"t":1310721,"n":"X509CtorCertDataObsoleteMessage","d":111574,"h":485331416022,"f":40},{"t":1310721,"n":"X509CtorCertDataObsoleteDiagId","d":111574,"h":489626383318,"f":40},{"t":1310721,"n":"TlsCipherAlgorithmEnumsMessage","d":111574,"h":493921350614,"f":40},{"t":1310721,"n":"TlsCipherAlgorithmEnumsDiagId","d":111574,"h":498216317910,"f":40},{"t":1310721,"n":"SystemEventsEventsThreadShutdownMessage","d":111574,"h":502511285206,"f":40},{"t":1310721,"n":"SystemEventsEventsThreadShutdownDiagId","d":111574,"h":506806252502,"f":40},{"t":1310721,"n":"Rfc2898DeriveBytesCtorMessage","d":111574,"h":511101219798,"f":40},{"t":1310721,"n":"Rfc2898DeriveBytesCtorDiagId","d":111574,"h":515396187094,"f":40},{"t":1310721,"n":"QueryableMinByMaxByTSourceObsoleteMessage","d":111574,"h":519691154390,"f":40},{"t":1310721,"n":"QueryableMinByMaxByTSourceObsoleteDiagId","d":111574,"h":523986121686,"f":40},{"t":1310721,"n":"XsltSettingsEnableScriptMessage","d":111574,"h":528281088982,"f":40},{"t":1310721,"n":"XsltSettingsEnableScriptDiagId","d":111574,"h":532576056278,"f":40}],"h":111574}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.Obsoletions`; }
        });
        
        $asm.$cls("$srsp.System.Runtime.Serialization.IgnoreDataMemberAttribute", ($self) => class IgnoreDataMemberAttribute extends $.$spc.System.Attribute
        {
            $ctor$2()
            {
                super.$ctor$1();
                {
                }
                return this;
            }
            static $h = 504790;
            static $f = 0b10010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":14483457,"c":[{"n":".ctor","o":"$ctor$2","d":504790,"h":4295472086,"f":1}],"h":504790,"a":[{"t":14614529,"c":21489451009,"a":[{"v":384,"t":14548993}],"n":[{"n":"Inherited","v":false,"t":262145},{"n":"AllowMultiple","v":false,"t":262145}]}]}; }
            static get $b() { return $.$spc.System.Attribute; }
            static get $fullName() { return `System.Runtime.Serialization.IgnoreDataMemberAttribute`; }
        });
        
        $asm.$cls("$srsp.System.Runtime.Serialization.DataContractAttribute", ($self) => class DataContractAttribute extends $.$spc.System.Attribute
        {
            /*string?*/ _name = null;
            /*string?*/ _ns = null;
            /*bool*/ _isNameSetExplicitly = false;
            /*bool*/ _isNamespaceSetExplicitly = false;
            /*bool*/ _isReference = false;
            /*bool*/ _isReferenceSetExplicitly = false;
            $ctor$2()
            {
                super.$ctor$1();
                {
                }
                return this;
            }
            /*bool */ get IsReference()
            {
                return this._isReference;
            }
            /*bool */ set IsReference(value)
            {
                this._isReference = value;
                this._isReferenceSetExplicitly = true;
            }
            /*bool */ get IsReferenceSetExplicitly()
            {
                return this._isReferenceSetExplicitly;
            }
            /*string? */ get Namespace()
            {
                return this._ns;
            }
            /*string? */ set Namespace(value)
            {
                this._ns = value;
                this._isNamespaceSetExplicitly = true;
            }
            /*bool */ get IsNamespaceSetExplicitly()
            {
                return this._isNamespaceSetExplicitly;
            }
            /*string? */ get Name()
            {
                return this._name;
            }
            /*string? */ set Name(value)
            {
                this._name = value;
                this._isNameSetExplicitly = true;
            }
            /*bool */ get IsNameSetExplicitly()
            {
                return this._isNameSetExplicitly;
            }
            static $h = 308182;
            static $f = 0b10010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":14483457,"p":[{"p":262145,"g":{"r":0,"d":0,"h":38655013846,"f":1},"s":{"r":0,"d":0,"h":42949981142,"f":1},"n":"IsReference","d":308182,"h":34360046550,"f":1},{"p":262145,"g":{"r":0,"d":0,"h":51539915734,"f":1},"n":"IsReferenceSetExplicitly","d":308182,"h":47244948438,"f":1},{"p":1310721,"g":{"r":0,"d":0,"h":60129850326,"f":1},"s":{"r":0,"d":0,"h":64424817622,"f":1},"n":"Namespace","d":308182,"h":55834883030,"f":1},{"p":262145,"g":{"r":0,"d":0,"h":73014752214,"f":1},"n":"IsNamespaceSetExplicitly","d":308182,"h":68719784918,"f":1},{"p":1310721,"g":{"r":0,"d":0,"h":81604686806,"f":1},"s":{"r":0,"d":0,"h":85899654102,"f":1},"n":"Name","d":308182,"h":77309719510,"f":1},{"p":262145,"g":{"r":0,"d":0,"h":94489588694,"f":1},"n":"IsNameSetExplicitly","d":308182,"h":90194621398,"f":1}],"l":[{"t":1310721,"n":"_name","d":308182,"h":4295275478,"f":2},{"t":1310721,"n":"_ns","d":308182,"h":8590242774,"f":2},{"t":262145,"n":"_isNameSetExplicitly","d":308182,"h":12885210070,"f":2},{"t":262145,"n":"_isNamespaceSetExplicitly","d":308182,"h":17180177366,"f":2},{"t":262145,"n":"_isReference","d":308182,"h":21475144662,"f":2},{"t":262145,"n":"_isReferenceSetExplicitly","d":308182,"h":25770111958,"f":2}],"c":[{"n":".ctor","o":"$ctor$2","d":308182,"h":30065079254,"f":1}],"h":308182,"a":[{"t":14614529,"c":21489451009,"a":[{"v":28,"t":14548993}],"n":[{"n":"Inherited","v":false,"t":262145},{"n":"AllowMultiple","v":false,"t":262145}]}]}; }
            static get $b() { return $.$spc.System.Attribute; }
            static get $fullName() { return `System.Runtime.Serialization.DataContractAttribute`; }
        });
        
        $asm.$cls("$srsp.System.Runtime.Serialization.ContractNamespaceAttribute", ($self) => class ContractNamespaceAttribute extends $.$spc.System.Attribute
        {
            $ctor$2(/*string*/ contractNamespace)
            {
                super.$ctor$1();
                {
                    this.ContractNamespace = contractNamespace;
                }
                return this;
            }
            /*string?*/ ClrNamespace = null;
            /*string*/ ContractNamespace = null;
            static $h = 242646;
            static $f = 0b10010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":14483457,"p":[{"p":1310721,"g":{"r":0,"d":0,"h":17180111830,"f":1},"s":{"r":0,"d":0,"h":21475079126,"f":1},"n":"ClrNamespace","d":242646,"h":12885144534,"f":1},{"p":1310721,"g":{"r":0,"d":0,"h":34359981014,"f":1},"n":"ContractNamespace","d":242646,"h":30065013718,"f":1}],"c":[{"p":[{"n":"contractNamespace","p":1310721}],"n":".ctor","o":"$ctor$2","d":242646,"h":4295209942,"f":1}],"h":242646,"a":[{"t":14614529,"c":21489451009,"a":[{"v":3,"t":14548993}],"n":[{"n":"Inherited","v":false,"t":262145},{"n":"AllowMultiple","v":true,"t":262145}]}]}; }
            static get $b() { return $.$spc.System.Attribute; }
            static get $fullName() { return `System.Runtime.Serialization.ContractNamespaceAttribute`; }
        });
        
        $asm.$cls("$srsp.System.Runtime.Serialization.EnumMemberAttribute", ($self) => class EnumMemberAttribute extends $.$spc.System.Attribute
        {
            /*string?*/ _value = null;
            /*bool*/ _isValueSetExplicitly = false;
            $ctor$2()
            {
                super.$ctor$1();
                {
                }
                return this;
            }
            /*string? */ get Value()
            {
                return this._value;
            }
            /*string? */ set Value(value)
            {
                this._value = value;
                this._isValueSetExplicitly = true;
            }
            /*bool */ get IsValueSetExplicitly()
            {
                return this._isValueSetExplicitly;
            }
            static $h = 439254;
            static $f = 0b10010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":14483457,"p":[{"p":1310721,"g":{"r":0,"d":0,"h":21475275734,"f":1},"s":{"r":0,"d":0,"h":25770243030,"f":1},"n":"Value","d":439254,"h":17180308438,"f":1},{"p":262145,"g":{"r":0,"d":0,"h":34360177622,"f":1},"n":"IsValueSetExplicitly","d":439254,"h":30065210326,"f":1}],"l":[{"t":1310721,"n":"_value","d":439254,"h":4295406550,"f":2},{"t":262145,"n":"_isValueSetExplicitly","d":439254,"h":8590373846,"f":2}],"c":[{"n":".ctor","o":"$ctor$2","d":439254,"h":12885341142,"f":1}],"h":439254,"a":[{"t":14614529,"c":21489451009,"a":[{"v":256,"t":14548993}],"n":[{"n":"Inherited","v":false,"t":262145},{"n":"AllowMultiple","v":false,"t":262145}]}]}; }
            static get $b() { return $.$spc.System.Attribute; }
            static get $fullName() { return `System.Runtime.Serialization.EnumMemberAttribute`; }
        });
        
        $asm.$cls("$srsp.System.Runtime.Serialization.CollectionDataContractAttribute", ($self) => class CollectionDataContractAttribute extends $.$spc.System.Attribute
        {
            /*string?*/ _name = null;
            /*string?*/ _ns = null;
            /*string?*/ _itemName = null;
            /*string?*/ _keyName = null;
            /*string?*/ _valueName = null;
            /*bool*/ _isReference = false;
            /*bool*/ _isNameSetExplicitly = false;
            /*bool*/ _isNamespaceSetExplicitly = false;
            /*bool*/ _isReferenceSetExplicitly = false;
            /*bool*/ _isItemNameSetExplicitly = false;
            /*bool*/ _isKeyNameSetExplicitly = false;
            /*bool*/ _isValueNameSetExplicitly = false;
            $ctor$2()
            {
                super.$ctor$1();
                {
                }
                return this;
            }
            /*string? */ get Namespace()
            {
                return this._ns;
            }
            /*string? */ set Namespace(value)
            {
                this._ns = value;
                this._isNamespaceSetExplicitly = true;
            }
            /*bool */ get IsNamespaceSetExplicitly()
            {
                return this._isNamespaceSetExplicitly;
            }
            /*string? */ get Name()
            {
                return this._name;
            }
            /*string? */ set Name(value)
            {
                this._name = value;
                this._isNameSetExplicitly = true;
            }
            /*bool */ get IsNameSetExplicitly()
            {
                return this._isNameSetExplicitly;
            }
            /*string? */ get ItemName()
            {
                return this._itemName;
            }
            /*string? */ set ItemName(value)
            {
                this._itemName = value;
                this._isItemNameSetExplicitly = true;
            }
            /*bool */ get IsItemNameSetExplicitly()
            {
                return this._isItemNameSetExplicitly;
            }
            /*string? */ get KeyName()
            {
                return this._keyName;
            }
            /*string? */ set KeyName(value)
            {
                this._keyName = value;
                this._isKeyNameSetExplicitly = true;
            }
            /*bool */ get IsKeyNameSetExplicitly()
            {
                return this._isKeyNameSetExplicitly;
            }
            /*bool */ get IsReference()
            {
                return this._isReference;
            }
            /*bool */ set IsReference(value)
            {
                this._isReference = value;
                this._isReferenceSetExplicitly = true;
            }
            /*bool */ get IsReferenceSetExplicitly()
            {
                return this._isReferenceSetExplicitly;
            }
            /*string? */ get ValueName()
            {
                return this._valueName;
            }
            /*string? */ set ValueName(value)
            {
                this._valueName = value;
                this._isValueNameSetExplicitly = true;
            }
            /*bool */ get IsValueNameSetExplicitly()
            {
                return this._isValueNameSetExplicitly;
            }
            static $h = 177110;
            static $f = 0b10010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":14483457,"p":[{"p":1310721,"g":{"r":0,"d":0,"h":64424686550,"f":1},"s":{"r":0,"d":0,"h":68719653846,"f":1},"n":"Namespace","d":177110,"h":60129719254,"f":1},{"p":262145,"g":{"r":0,"d":0,"h":77309588438,"f":1},"n":"IsNamespaceSetExplicitly","d":177110,"h":73014621142,"f":1},{"p":1310721,"g":{"r":0,"d":0,"h":85899523030,"f":1},"s":{"r":0,"d":0,"h":90194490326,"f":1},"n":"Name","d":177110,"h":81604555734,"f":1},{"p":262145,"g":{"r":0,"d":0,"h":98784424918,"f":1},"n":"IsNameSetExplicitly","d":177110,"h":94489457622,"f":1},{"p":1310721,"g":{"r":0,"d":0,"h":107374359510,"f":1},"s":{"r":0,"d":0,"h":111669326806,"f":1},"n":"ItemName","d":177110,"h":103079392214,"f":1},{"p":262145,"g":{"r":0,"d":0,"h":120259261398,"f":1},"n":"IsItemNameSetExplicitly","d":177110,"h":115964294102,"f":1},{"p":1310721,"g":{"r":0,"d":0,"h":128849195990,"f":1},"s":{"r":0,"d":0,"h":133144163286,"f":1},"n":"KeyName","d":177110,"h":124554228694,"f":1},{"p":262145,"g":{"r":0,"d":0,"h":141734097878,"f":1},"n":"IsKeyNameSetExplicitly","d":177110,"h":137439130582,"f":1},{"p":262145,"g":{"r":0,"d":0,"h":150324032470,"f":1},"s":{"r":0,"d":0,"h":154618999766,"f":1},"n":"IsReference","d":177110,"h":146029065174,"f":1},{"p":262145,"g":{"r":0,"d":0,"h":163208934358,"f":1},"n":"IsReferenceSetExplicitly","d":177110,"h":158913967062,"f":1},{"p":1310721,"g":{"r":0,"d":0,"h":171798868950,"f":1},"s":{"r":0,"d":0,"h":176093836246,"f":1},"n":"ValueName","d":177110,"h":167503901654,"f":1},{"p":262145,"g":{"r":0,"d":0,"h":184683770838,"f":1},"n":"IsValueNameSetExplicitly","d":177110,"h":180388803542,"f":1}],"l":[{"t":1310721,"n":"_name","d":177110,"h":4295144406,"f":2},{"t":1310721,"n":"_ns","d":177110,"h":8590111702,"f":2},{"t":1310721,"n":"_itemName","d":177110,"h":12885078998,"f":2},{"t":1310721,"n":"_keyName","d":177110,"h":17180046294,"f":2},{"t":1310721,"n":"_valueName","d":177110,"h":21475013590,"f":2},{"t":262145,"n":"_isReference","d":177110,"h":25769980886,"f":2},{"t":262145,"n":"_isNameSetExplicitly","d":177110,"h":30064948182,"f":2},{"t":262145,"n":"_isNamespaceSetExplicitly","d":177110,"h":34359915478,"f":2},{"t":262145,"n":"_isReferenceSetExplicitly","d":177110,"h":38654882774,"f":2},{"t":262145,"n":"_isItemNameSetExplicitly","d":177110,"h":42949850070,"f":2},{"t":262145,"n":"_isKeyNameSetExplicitly","d":177110,"h":47244817366,"f":2},{"t":262145,"n":"_isValueNameSetExplicitly","d":177110,"h":51539784662,"f":2}],"c":[{"n":".ctor","o":"$ctor$2","d":177110,"h":55834751958,"f":1}],"h":177110,"a":[{"t":14614529,"c":21489451009,"a":[{"v":12,"t":14548993}],"n":[{"n":"Inherited","v":false,"t":262145},{"n":"AllowMultiple","v":false,"t":262145}]}]}; }
            static get $b() { return $.$spc.System.Attribute; }
            static get $fullName() { return `System.Runtime.Serialization.CollectionDataContractAttribute`; }
        });
        
        $asm.$cls("$srsp.System.Runtime.Serialization.KnownTypeAttribute", ($self) => class KnownTypeAttribute extends $.$spc.System.Attribute
        {
            $ctor$2(/*Type*/ type)
            {
                super.$ctor$1();
                {
                    this.Type = type;
                }
                return this;
            }
            $ctor$3(/*string*/ methodName)
            {
                super.$ctor$1();
                {
                    this.MethodName = methodName;
                }
                return this;
            }
            /*string?*/ MethodName = null;
            /*Type?*/ Type = null;
            static $h = 766934;
            static $f = 0b10010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":14483457,"p":[{"p":1310721,"g":{"r":0,"d":0,"h":21475603414,"f":1},"n":"MethodName","d":766934,"h":17180636118,"f":1},{"p":142606337,"g":{"r":0,"d":0,"h":34360505302,"f":1},"n":"Type","d":766934,"h":30065538006,"f":1}],"c":[{"p":[{"n":"type","p":142606337}],"n":".ctor","o":"$ctor$2","d":766934,"h":4295734230,"f":1},{"p":[{"n":"methodName","p":1310721}],"n":".ctor","o":"$ctor$3","d":766934,"h":8590701526,"f":1}],"h":766934,"a":[{"t":14614529,"c":21489451009,"a":[{"v":12,"t":14548993}],"n":[{"n":"Inherited","v":true,"t":262145},{"n":"AllowMultiple","v":true,"t":262145}]}]}; }
            static get $b() { return $.$spc.System.Attribute; }
            static get $fullName() { return `System.Runtime.Serialization.KnownTypeAttribute`; }
        });
        
        $asm.$cls("$srsp.System.Runtime.Serialization.DataMemberAttribute", ($self) => class DataMemberAttribute extends $.$spc.System.Attribute
        {
            /*string?*/ _name = null;
            /*bool*/ _isNameSetExplicitly = false;
            /*int*/ _order = -1;
            $ctor$2()
            {
                super.$ctor$1();
                {
                }
                return this;
            }
            /*string? */ get Name()
            {
                return this._name;
            }
            /*string? */ set Name(value)
            {
                this._name = value;
                this._isNameSetExplicitly = true;
            }
            /*bool */ get IsNameSetExplicitly()
            {
                return this._isNameSetExplicitly;
            }
            /*int */ get Order()
            {
                return this._order;
            }
            /*int */ set Order(value)
            {
                if (value < 0)
                {
                    throw new $.$srsp.System.Runtime.Serialization.InvalidDataContractException().$ctor$6($.$srsp.System.SR.OrderCannotBeNegative);
                }
                this._order = value;
            }
            /*bool*/ IsRequired = false;
            /*bool*/ EmitDefaultValue = false;
            //default member initializer
            constructor()
            {
                super();
                this.IsRequired = false;
                this.EmitDefaultValue = true;
            }
            static $h = 373718;
            static $f = 0b10010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":14483457,"p":[{"p":1310721,"g":{"r":0,"d":0,"h":25770177494,"f":1},"s":{"r":0,"d":0,"h":30065144790,"f":1},"n":"Name","d":373718,"h":21475210198,"f":1},{"p":262145,"g":{"r":0,"d":0,"h":38655079382,"f":1},"n":"IsNameSetExplicitly","d":373718,"h":34360112086,"f":1},{"p":655361,"g":{"r":0,"d":0,"h":47245013974,"f":1},"s":{"r":0,"d":0,"h":51539981270,"f":1},"n":"Order","d":373718,"h":42950046678,"f":1},{"p":262145,"g":{"r":0,"d":0,"h":64424883158,"f":1},"s":{"r":0,"d":0,"h":68719850454,"f":1},"n":"IsRequired","d":373718,"h":60129915862,"f":1},{"p":262145,"g":{"r":0,"d":0,"h":81604752342,"f":1},"s":{"r":0,"d":0,"h":85899719638,"f":1},"n":"EmitDefaultValue","d":373718,"h":77309785046,"f":1}],"l":[{"t":1310721,"n":"_name","d":373718,"h":4295341014,"f":2},{"t":262145,"n":"_isNameSetExplicitly","d":373718,"h":8590308310,"f":2},{"t":655361,"n":"_order","d":373718,"h":12885275606,"f":2}],"c":[{"n":".ctor","o":"$ctor$2","d":373718,"h":17180242902,"f":1}],"h":373718,"a":[{"t":14614529,"c":21489451009,"a":[{"v":384,"t":14548993}],"n":[{"n":"Inherited","v":false,"t":262145},{"n":"AllowMultiple","v":false,"t":262145}]}]}; }
            static get $b() { return $.$spc.System.Attribute; }
            static get $fullName() { return `System.Runtime.Serialization.DataMemberAttribute`; }
        });
        
        $asm.$cls("$srsp.System.Runtime.Serialization.InvalidDataContractException", ($self) => class InvalidDataContractException extends $.$spc.System.Exception
        {
            $ctor$5()
            {
                super.$ctor$1();
                {
                }
                return this;
            }
            $ctor$6(/*string?*/ message)
            {
                super.$ctor$2(message);
                {
                }
                return this;
            }
            $ctor$7(/*string?*/ message, /*Exception?*/ innerException)
            {
                super.$ctor$3(message, innerException);
                {
                }
                return this;
            }
            $ctor$8(/*SerializationInfo*/ info, /*StreamingContext*/ context)
            {
                super.$ctor$4(info, context);
                {
                }
                return this;
            }
            static $h = 570326;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":47185921,"h":570326}; }
            static get $b() { return $.$spc.System.Exception; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.Runtime.Serialization.ISerializable ]; }
            static get $fullName() { return `System.Runtime.Serialization.InvalidDataContractException`; }
        });
	});
})(window, window.NetJs.$boot(), ...window.NetJs.$require("NetJs.System.Private.CoreLib", "NetJs.System.Memory", "NetJs.System.Private.Uri", "NetJs.System.Runtime"))