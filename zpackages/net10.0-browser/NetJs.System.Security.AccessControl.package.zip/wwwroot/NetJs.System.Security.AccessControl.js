
(function ($global, $, $spc, $mwp, $sc, $sdt, $st, $scc, $sm, $spu, $sr, $scn, $sris, $stt, $ssc, $sspw) {
    "use strict";
    let _;
    
    
    
	$.$asm(
    "NetJs.System.Security.AccessControl", 
    {"h":48066,"f":"System.Security.AccessControl","v":"1.0.35.0","a":[{"t":115146753,"c":13000048641,"a":[{"v":".NETCoreApp,Version=v10.0","t":1310721}],"n":[{"n":"FrameworkDisplayName","v":".NET 10.0","t":1310721}]},{"t":73596929,"c":4368564225,"a":[{"v":"SIT","t":1310721}]},{"t":73662465,"c":4368629761,"a":[{"v":"Debug","t":1310721}]},{"t":74121217,"c":4369088513,"a":[{"v":"1.0.35.0","t":1310721}]},{"t":74252289,"c":4369219585,"a":[{"v":"1.0.35\u002B99807a3edea449997cda60d38046fed69821a2f6","t":1310721}]},{"t":75104257,"c":4370071553,"a":[{"v":"NetJs.System.Security.AccessControl","t":1310721}]},{"t":75235329,"c":4370202625,"a":[{"v":"NetJs.System.Security.AccessControl","t":1310721}]},{"t":75366401,"c":4370333697,"a":[{"v":"1.0.35.0","t":1310721}]},{"t":115212289,"c":4410179585,"a":[{"v":"browser1.0","t":1310721}]},{"t":114950145,"c":4409917441,"a":[{"v":"browser1.0","t":1310721}]}],"m":[]},
    function($asm)
	{
        
        
        $asm.$cls("$ssa.System.Security.AccessControl.AuthorizationRule", ($self) => class AuthorizationRule extends $.$spc.System.Object
        {
            $ctor$1(/*System.Security.Principal.IdentityReference*/ identity, /*int*/ accessMask, /*bool*/ isInherited, /*System.Security.AccessControl.InheritanceFlags*/ inheritanceFlags, /*System.Security.AccessControl.PropagationFlags*/ propagationFlags)
            {
                super.$ctor();
                {
                }
                return this;
            }
            /*int */ get AccessMask()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Security.Principal.IdentityReference */ get IdentityReference()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Security.AccessControl.InheritanceFlags */ get InheritanceFlags()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get IsInherited()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Security.AccessControl.PropagationFlags */ get PropagationFlags()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static $h = 965570;
            static $f = 0b110001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":655361,"g":{"r":0,"d":0,"h":12885867458,"f":16},"n":"AccessMask","d":965570,"h":8590900162,"f":16},{"p":232830,"g":{"r":0,"d":0,"h":21475802050,"f":1},"n":"IdentityReference","d":965570,"h":17180834754,"f":1},{"p":1883074,"g":{"r":0,"d":0,"h":30065736642,"f":1},"n":"InheritanceFlags","d":965570,"h":25770769346,"f":1},{"p":262145,"g":{"r":0,"d":0,"h":38655671234,"f":1},"n":"IsInherited","d":965570,"h":34360703938,"f":1},{"p":2603970,"g":{"r":0,"d":0,"h":47245605826,"f":1},"n":"PropagationFlags","d":965570,"h":42950638530,"f":1}],"c":[{"p":[{"n":"identity","p":232830},{"n":"accessMask","p":655361},{"n":"isInherited","p":262145},{"n":"inheritanceFlags","p":1883074},{"n":"propagationFlags","p":2603970}],"n":".ctor","o":"$ctor$1","d":965570,"h":4295932866,"f":16}],"h":965570}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.Security.AccessControl.AuthorizationRule`; }
        });
        
        $asm.$cls("$ssa.System.Security.AccessControl.GenericAce", ($self) => class GenericAce extends $.$spc.System.Object
        {
            $ctor$1()
            {
                super.$ctor();
                {
                }
                return this;
            }
            /*System.Security.AccessControl.AceFlags */ get AceFlags()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Security.AccessControl.AceFlags */ set AceFlags(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Security.AccessControl.AceType */ get AceType()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Security.AccessControl.AuditFlags */ get AuditFlags()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Security.AccessControl.InheritanceFlags */ get InheritanceFlags()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get IsInherited()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Security.AccessControl.PropagationFlags */ get PropagationFlags()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Security.AccessControl.GenericAce */ Copy()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static /*System.Security.AccessControl.GenericAce */ CreateFromBinaryForm(/*byte[]*/ binaryForm, /*int*/ offset)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static/*conventional*/ /*bool */ Equals(/*object?*/ o)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            //Static convention instance redirect
            /*bool */ Equals() { return $.$ssa.System.Security.AccessControl.GenericAce.Equals.apply(this, arguments); }
            static/*conventional*/ /*int */ GetHashCode()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            //Static convention instance redirect
            /*int */ GetHashCode() { return $.$ssa.System.Security.AccessControl.GenericAce.GetHashCode.apply(this, arguments); }
            static /*bool */ op_Equality(/*System.Security.AccessControl.GenericAce?*/ left, /*System.Security.AccessControl.GenericAce?*/ right)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static /*bool */ op_Inequality(/*System.Security.AccessControl.GenericAce?*/ left, /*System.Security.AccessControl.GenericAce?*/ right)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static $h = 1686466;
            static $f = 0b110001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":572354,"g":{"r":0,"d":0,"h":12886588354,"f":1},"s":{"r":0,"d":0,"h":17181555650,"f":1},"n":"AceFlags","d":1686466,"h":8591621058,"f":1},{"p":703426,"g":{"r":0,"d":0,"h":25771490242,"f":1},"n":"AceType","d":1686466,"h":21476522946,"f":1},{"p":768962,"g":{"r":0,"d":0,"h":34361424834,"f":1},"n":"AuditFlags","d":1686466,"h":30066457538,"f":1},{"p":655361,"g":{"r":0,"d":0,"h":42951359426,"f":257},"n":"BinaryLength","d":1686466,"h":38656392130,"f":257},{"p":1883074,"g":{"r":0,"d":0,"h":51541294018,"f":1},"n":"InheritanceFlags","d":1686466,"h":47246326722,"f":1},{"p":262145,"g":{"r":0,"d":0,"h":60131228610,"f":1},"n":"IsInherited","d":1686466,"h":55836261314,"f":1},{"p":2603970,"g":{"r":0,"d":0,"h":68721163202,"f":1},"n":"PropagationFlags","d":1686466,"h":64426195906,"f":1}],"m":[{"r":1686466,"n":"Copy","d":1686466,"h":73016130498,"f":1},{"r":1686466,"p":[{"n":"binaryForm","p":0},{"n":"offset","p":655361}],"n":"CreateFromBinaryForm","d":1686466,"h":77311097794,"f":33},{"r":262145,"p":[{"n":"o","p":131073}],"n":"Equals","d":1686466,"h":81606065090,"f":98305},{"r":65537,"p":[{"n":"binaryForm","p":0},{"n":"offset","p":655361}],"n":"GetBinaryForm","d":1686466,"h":85901032386,"f":257},{"r":655361,"n":"GetHashCode","d":1686466,"h":90195999682,"f":98305}],"c":[{"n":".ctor","o":"$ctor$1","d":1686466,"h":4296653762,"f":8}],"h":1686466}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.Security.AccessControl.GenericAce`; }
        });
        
        $asm.$cls("$ssa.System.Security.AccessControl.GenericSecurityDescriptor", ($self) => class GenericSecurityDescriptor extends $.$spc.System.Object
        {
            $ctor$1()
            {
                super.$ctor();
                {
                }
                return this;
            }
            /*int */ get BinaryLength()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static /*byte */ get Revision()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*void */ GetBinaryForm(/*byte[]*/ binaryForm, /*int*/ offset)
            {
            }
            /*string */ GetSddlForm(/*System.Security.AccessControl.AccessControlSections*/ includeSections)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static /*bool */ IsSddlConversionSupported()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static $h = 1817538;
            static $f = 0b110001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":655361,"g":{"r":0,"d":0,"h":12886719426,"f":1},"n":"BinaryLength","d":1817538,"h":8591752130,"f":1},{"p":1489858,"g":{"r":0,"d":0,"h":21476654018,"f":257},"n":"ControlFlags","d":1817538,"h":17181686722,"f":257},{"p":429438,"g":{"r":0,"d":0,"h":30066588610,"f":257},"s":{"r":0,"d":0,"h":34361555906,"f":257},"n":"Group","d":1817538,"h":25771621314,"f":257},{"p":429438,"g":{"r":0,"d":0,"h":42951490498,"f":257},"s":{"r":0,"d":0,"h":47246457794,"f":257},"n":"Owner","d":1817538,"h":38656523202,"f":257},{"p":393217,"g":{"r":0,"d":0,"h":55836392386,"f":33},"n":"Revision","d":1817538,"h":51541425090,"f":33}],"m":[{"r":65537,"p":[{"n":"binaryForm","p":0},{"n":"offset","p":655361}],"n":"GetBinaryForm","d":1817538,"h":60131359682,"f":1},{"r":1310721,"p":[{"n":"includeSections","p":244674}],"n":"GetSddlForm","d":1817538,"h":64426326978,"f":1},{"r":262145,"n":"IsSddlConversionSupported","d":1817538,"h":68721294274,"f":33}],"c":[{"n":".ctor","o":"$ctor$1","d":1817538,"h":4296784834,"f":8}],"h":1817538}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.Security.AccessControl.GenericSecurityDescriptor`; }
        });
        
        $asm.$cls("$ssa.System.Security.AccessControl.ObjectSecurity", ($self) => class ObjectSecurity extends $.$spc.System.Object
        {
            $ctor$1()
            {
                super.$ctor();
                {
                }
                return this;
            }
            $ctor$2(/*bool*/ isContainer, /*bool*/ isDS)
            {
                super.$ctor();
                {
                }
                return this;
            }
            $ctor$3(/*System.Security.AccessControl.CommonSecurityDescriptor*/ securityDescriptor)
            {
                super.$ctor();
                {
                }
                return this;
            }
            /*bool */ get AccessRulesModified()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ set AccessRulesModified(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get AreAccessRulesCanonical()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get AreAccessRulesProtected()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get AreAuditRulesCanonical()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get AreAuditRulesProtected()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get AuditRulesModified()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ set AuditRulesModified(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get GroupModified()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ set GroupModified(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get IsContainer()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get IsDS()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get OwnerModified()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ set OwnerModified(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Security.AccessControl.CommonSecurityDescriptor */ get SecurityDescriptor()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Security.Principal.IdentityReference? */ GetGroup(/*System.Type*/ targetType)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Security.Principal.IdentityReference? */ GetOwner(/*System.Type*/ targetType)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*byte[] */ GetSecurityDescriptorBinaryForm()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*string */ GetSecurityDescriptorSddlForm(/*System.Security.AccessControl.AccessControlSections*/ includeSections)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static /*bool */ IsSddlConversionSupported()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ ModifyAccessRule(/*System.Security.AccessControl.AccessControlModification*/ modification, /*System.Security.AccessControl.AccessRule*/ rule, /*out bool*/ modified)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ ModifyAuditRule(/*System.Security.AccessControl.AccessControlModification*/ modification, /*System.Security.AccessControl.AuditRule*/ rule, /*out bool*/ modified)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*void */ Persist(/*bool*/ enableOwnershipPrivilege, /*string*/ name, /*System.Security.AccessControl.AccessControlSections*/ includeSections)
            {
            }
            /*void */ Persist$1(/*System.Runtime.InteropServices.SafeHandle*/ handle, /*System.Security.AccessControl.AccessControlSections*/ includeSections)
            {
            }
            /*void */ Persist$2(/*string*/ name, /*System.Security.AccessControl.AccessControlSections*/ includeSections)
            {
            }
            /*void */ PurgeAccessRules(/*System.Security.Principal.IdentityReference*/ identity)
            {
            }
            /*void */ PurgeAuditRules(/*System.Security.Principal.IdentityReference*/ identity)
            {
            }
            /*void */ ReadLock()
            {
            }
            /*void */ ReadUnlock()
            {
            }
            /*void */ SetAccessRuleProtection(/*bool*/ isProtected, /*bool*/ preserveInheritance)
            {
            }
            /*void */ SetAuditRuleProtection(/*bool*/ isProtected, /*bool*/ preserveInheritance)
            {
            }
            /*void */ SetGroup(/*System.Security.Principal.IdentityReference*/ identity)
            {
            }
            /*void */ SetOwner(/*System.Security.Principal.IdentityReference*/ identity)
            {
            }
            /*void */ SetSecurityDescriptorBinaryForm(/*byte[]*/ binaryForm)
            {
            }
            /*void */ SetSecurityDescriptorBinaryForm$1(/*byte[]*/ binaryForm, /*System.Security.AccessControl.AccessControlSections*/ includeSections)
            {
            }
            /*void */ SetSecurityDescriptorSddlForm(/*string*/ sddlForm)
            {
            }
            /*void */ SetSecurityDescriptorSddlForm$1(/*string*/ sddlForm, /*System.Security.AccessControl.AccessControlSections*/ includeSections)
            {
            }
            /*void */ WriteLock()
            {
            }
            /*void */ WriteUnlock()
            {
            }
            static $h = 2407362;
            static $f = 0b110001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":142606337,"g":{"r":0,"d":0,"h":21477243842,"f":257},"n":"AccessRightType","d":2407362,"h":17182276546,"f":257},{"p":262145,"g":{"r":0,"d":0,"h":30067178434,"f":4},"s":{"r":0,"d":0,"h":34362145730,"f":4},"n":"AccessRulesModified","d":2407362,"h":25772211138,"f":4},{"p":142606337,"g":{"r":0,"d":0,"h":42952080322,"f":257},"n":"AccessRuleType","d":2407362,"h":38657113026,"f":257},{"p":262145,"g":{"r":0,"d":0,"h":51542014914,"f":1},"n":"AreAccessRulesCanonical","d":2407362,"h":47247047618,"f":1},{"p":262145,"g":{"r":0,"d":0,"h":60131949506,"f":1},"n":"AreAccessRulesProtected","d":2407362,"h":55836982210,"f":1},{"p":262145,"g":{"r":0,"d":0,"h":68721884098,"f":1},"n":"AreAuditRulesCanonical","d":2407362,"h":64426916802,"f":1},{"p":262145,"g":{"r":0,"d":0,"h":77311818690,"f":1},"n":"AreAuditRulesProtected","d":2407362,"h":73016851394,"f":1},{"p":262145,"g":{"r":0,"d":0,"h":85901753282,"f":4},"s":{"r":0,"d":0,"h":90196720578,"f":4},"n":"AuditRulesModified","d":2407362,"h":81606785986,"f":4},{"p":142606337,"g":{"r":0,"d":0,"h":98786655170,"f":257},"n":"AuditRuleType","d":2407362,"h":94491687874,"f":257},{"p":262145,"g":{"r":0,"d":0,"h":107376589762,"f":4},"s":{"r":0,"d":0,"h":111671557058,"f":4},"n":"GroupModified","d":2407362,"h":103081622466,"f":4},{"p":262145,"g":{"r":0,"d":0,"h":120261491650,"f":4},"n":"IsContainer","d":2407362,"h":115966524354,"f":4},{"p":262145,"g":{"r":0,"d":0,"h":128851426242,"f":4},"n":"IsDS","d":2407362,"h":124556458946,"f":4},{"p":262145,"g":{"r":0,"d":0,"h":137441360834,"f":4},"s":{"r":0,"d":0,"h":141736328130,"f":4},"n":"OwnerModified","d":2407362,"h":133146393538,"f":4},{"p":1293250,"g":{"r":0,"d":0,"h":150326262722,"f":4},"n":"SecurityDescriptor","d":2407362,"h":146031295426,"f":4}],"m":[{"r":375746,"p":[{"n":"identityReference","p":232830},{"n":"accessMask","p":655361},{"n":"isInherited","p":262145},{"n":"inheritanceFlags","p":1883074},{"n":"propagationFlags","p":2603970},{"n":"type","p":310210}],"n":"AccessRuleFactory","d":2407362,"h":154621230018,"f":257},{"r":834498,"p":[{"n":"identityReference","p":232830},{"n":"accessMask","p":655361},{"n":"isInherited","p":262145},{"n":"inheritanceFlags","p":1883074},{"n":"propagationFlags","p":2603970},{"n":"flags","p":768962}],"n":"AuditRuleFactory","d":2407362,"h":158916197314,"f":257},{"r":232830,"p":[{"n":"targetType","p":142606337}],"n":"GetGroup","d":2407362,"h":163211164610,"f":1},{"r":232830,"p":[{"n":"targetType","p":142606337}],"n":"GetOwner","d":2407362,"h":167506131906,"f":1},{"r":0,"n":"GetSecurityDescriptorBinaryForm","d":2407362,"h":171801099202,"f":1},{"r":1310721,"p":[{"n":"includeSections","p":244674}],"n":"GetSecurityDescriptorSddlForm","d":2407362,"h":176096066498,"f":1},{"r":262145,"n":"IsSddlConversionSupported","d":2407362,"h":180391033794,"f":33},{"r":262145,"p":[{"n":"modification","p":179138},{"n":"rule","p":375746},{"n":"modified","p":262145,"f":2}],"n":"ModifyAccess","d":2407362,"h":184686001090,"f":260},{"r":262145,"p":[{"n":"modification","p":179138},{"n":"rule","p":375746},{"n":"modified","p":262145,"f":2}],"n":"ModifyAccessRule","d":2407362,"h":188980968386,"f":129},{"r":262145,"p":[{"n":"modification","p":179138},{"n":"rule","p":834498},{"n":"modified","p":262145,"f":2}],"n":"ModifyAudit","d":2407362,"h":193275935682,"f":260},{"r":262145,"p":[{"n":"modification","p":179138},{"n":"rule","p":834498},{"n":"modified","p":262145,"f":2}],"n":"ModifyAuditRule","d":2407362,"h":197570902978,"f":129},{"r":65537,"p":[{"n":"enableOwnershipPrivilege","p":262145},{"n":"name","p":1310721},{"n":"includeSections","p":244674}],"n":"Persist","d":2407362,"h":201865870274,"f":132},{"r":65537,"p":[{"n":"handle","p":109576193},{"n":"includeSections","p":244674}],"n":"Persist","o":"@$1","d":2407362,"h":206160837570,"f":132},{"r":65537,"p":[{"n":"name","p":1310721},{"n":"includeSections","p":244674}],"n":"Persist","o":"@$2","d":2407362,"h":210455804866,"f":132},{"r":65537,"p":[{"n":"identity","p":232830}],"n":"PurgeAccessRules","d":2407362,"h":214750772162,"f":129},{"r":65537,"p":[{"n":"identity","p":232830}],"n":"PurgeAuditRules","d":2407362,"h":219045739458,"f":129},{"r":65537,"n":"ReadLock","d":2407362,"h":223340706754,"f":4},{"r":65537,"n":"ReadUnlock","d":2407362,"h":227635674050,"f":4},{"r":65537,"p":[{"n":"isProtected","p":262145},{"n":"preserveInheritance","p":262145}],"n":"SetAccessRuleProtection","d":2407362,"h":231930641346,"f":1},{"r":65537,"p":[{"n":"isProtected","p":262145},{"n":"preserveInheritance","p":262145}],"n":"SetAuditRuleProtection","d":2407362,"h":236225608642,"f":1},{"r":65537,"p":[{"n":"identity","p":232830}],"n":"SetGroup","d":2407362,"h":240520575938,"f":1},{"r":65537,"p":[{"n":"identity","p":232830}],"n":"SetOwner","d":2407362,"h":244815543234,"f":1},{"r":65537,"p":[{"n":"binaryForm","p":0}],"n":"SetSecurityDescriptorBinaryForm","d":2407362,"h":249110510530,"f":1},{"r":65537,"p":[{"n":"binaryForm","p":0},{"n":"includeSections","p":244674}],"n":"SetSecurityDescriptorBinaryForm","o":"@$1","d":2407362,"h":253405477826,"f":1},{"r":65537,"p":[{"n":"sddlForm","p":1310721}],"n":"SetSecurityDescriptorSddlForm","d":2407362,"h":257700445122,"f":1},{"r":65537,"p":[{"n":"sddlForm","p":1310721},{"n":"includeSections","p":244674}],"n":"SetSecurityDescriptorSddlForm","o":"@$1","d":2407362,"h":261995412418,"f":1},{"r":65537,"n":"WriteLock","d":2407362,"h":266290379714,"f":4},{"r":65537,"n":"WriteUnlock","d":2407362,"h":270585347010,"f":4}],"c":[{"n":".ctor","o":"$ctor$1","d":2407362,"h":4297374658,"f":4},{"p":[{"n":"isContainer","p":262145},{"n":"isDS","p":262145}],"n":".ctor","o":"$ctor$2","d":2407362,"h":8592341954,"f":4},{"p":[{"n":"securityDescriptor","p":1293250}],"n":".ctor","o":"$ctor$3","d":2407362,"h":12887309250,"f":4}],"h":2407362}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.Security.AccessControl.ObjectSecurity`; }
        });
        
        $asm.$cls("$ssa.System.Security.Policy.EvidenceBase", ($self) => class EvidenceBase extends $.$spc.System.Object
        {
            $ctor$1()
            {
                super.$ctor();
                {
                }
                return this;
            }
            /*System.Security.Policy.EvidenceBase? */ Clone()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static $h = 3128258;
            static $f = 0b110001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"m":[{"r":3128258,"n":"Clone","d":3128258,"h":8593062850,"f":129}],"c":[{"n":".ctor","o":"$ctor$1","d":3128258,"h":4298095554,"f":4}],"h":3128258}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.Security.Policy.EvidenceBase`; }
        });
        
        $asm.$cls("$ssa.System.Security.AccessControl.GenericAcl", ($self) => class GenericAcl extends $.$spc.System.Object
        {
            /*byte*/ static AclRevision = 0;
            /*byte*/ static AclRevisionDS = 0;
            /*int*/ static MaxBinaryLength = 0;
            $ctor$1()
            {
                super.$ctor();
                {
                }
                return this;
            }
            /*bool */ get IsSynchronized()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*object */ get SyncRoot()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*void */ CopyTo(/*System.Security.AccessControl.GenericAce[]*/ array, /*int*/ index)
            {
            }
            /*System.Security.AccessControl.AceEnumerator */ GetEnumerator()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*void */ System$Collections$ICollection$CopyTo(/*System.Array*/ array, /*int*/ index)
            {
            }
            /*System.Collections.IEnumerator */ System$Collections$IEnumerable$GetEnumerator()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            //Generated interface implemetation for System.Collections.ICollection.Count.get
            get System$Collections$ICollection$Count()
            {
                return this.Count;
            }
            //Generated interface implemetation for System.Collections.ICollection.SyncRoot.get
            get System$Collections$ICollection$SyncRoot()
            {
                return this.SyncRoot;
            }
            //Generated interface implemetation for System.Collections.ICollection.IsSynchronized.get
            get System$Collections$ICollection$IsSynchronized()
            {
                return this.IsSynchronized;
            }
            static $h = 1752002;
            static $f = 0b110001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":655361,"g":{"r":0,"d":0,"h":25771555778,"f":257},"n":"BinaryLength","d":1752002,"h":21476588482,"f":257},{"p":655361,"g":{"r":0,"d":0,"h":34361490370,"f":257},"n":"Count","d":1752002,"h":30066523074,"f":257},{"p":262145,"g":{"r":0,"d":0,"h":42951424962,"f":1},"n":"IsSynchronized","d":1752002,"h":38656457666,"f":1},{"p":1686466,"i":[{"n":"index","p":655361}],"g":{"r":0,"d":0,"h":51541359554,"f":257},"s":{"r":0,"d":0,"h":55836326850,"f":257},"n":"Item","o":"@$2","d":1752002,"h":47246392258,"f":257},{"p":393217,"g":{"r":0,"d":0,"h":64426261442,"f":257},"n":"Revision","d":1752002,"h":60131294146,"f":257},{"p":131073,"g":{"r":0,"d":0,"h":73016196034,"f":129},"n":"SyncRoot","d":1752002,"h":68721228738,"f":129}],"m":[{"r":65537,"p":[{"n":"array","p":0},{"n":"index","p":655361}],"n":"CopyTo","d":1752002,"h":77311163330,"f":1},{"r":65537,"p":[{"n":"binaryForm","p":0},{"n":"offset","p":655361}],"n":"GetBinaryForm","d":1752002,"h":81606130626,"f":257},{"r":506818,"n":"GetEnumerator","d":1752002,"h":85901097922,"f":1}],"l":[{"t":393217,"n":"AclRevision","d":1752002,"h":4296719298,"f":33},{"t":393217,"n":"AclRevisionDS","d":1752002,"h":8591686594,"f":33},{"t":655361,"n":"MaxBinaryLength","d":1752002,"h":12886653890,"f":33}],"c":[{"n":".ctor","o":"$ctor$1","d":1752002,"h":17181621186,"f":4}],"i":[31391745,31653889],"h":1752002}; }
            static get $b() { return $.$spc.System.Object; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.Collections.ICollection, $.$spc.System.Collections.IEnumerable ]; }
            static get $fullName() { return `System.Security.AccessControl.GenericAcl`; }
        });
        
        $asm.$cls("$ssa.System.Security.AccessControl.AccessRule", ($self) => class AccessRule extends $.$ssa.System.Security.AccessControl.AuthorizationRule
        {
            $ctor$2(/*System.Security.Principal.IdentityReference*/ identity, /*int*/ accessMask, /*bool*/ isInherited, /*System.Security.AccessControl.InheritanceFlags*/ inheritanceFlags, /*System.Security.AccessControl.PropagationFlags*/ propagationFlags, /*System.Security.AccessControl.AccessControlType*/ type)
            {
                super.$ctor$1(null, 0, false, 0, 0);
                {
                }
                return this;
            }
            /*System.Security.AccessControl.AccessControlType */ get AccessControlType()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static $h = 375746;
            static $f = 0b110001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":965570,"p":[{"p":310210,"g":{"r":0,"d":0,"h":12885277634,"f":1},"n":"AccessControlType","d":375746,"h":8590310338,"f":1}],"c":[{"p":[{"n":"identity","p":232830},{"n":"accessMask","p":655361},{"n":"isInherited","p":262145},{"n":"inheritanceFlags","p":1883074},{"n":"propagationFlags","p":2603970},{"n":"type","p":310210}],"n":".ctor","o":"$ctor$2","d":375746,"h":4295343042,"f":4}],"h":375746}; }
            static get $b() { return $.$ssa.System.Security.AccessControl.AuthorizationRule; }
            static get $fullName() { return `System.Security.AccessControl.AccessRule`; }
        });
        
        $asm.$cls("$ssa.System.Security.AccessControl.AuditRule", ($self) => class AuditRule extends $.$ssa.System.Security.AccessControl.AuthorizationRule
        {
            $ctor$2(/*System.Security.Principal.IdentityReference*/ identity, /*int*/ accessMask, /*bool*/ isInherited, /*System.Security.AccessControl.InheritanceFlags*/ inheritanceFlags, /*System.Security.AccessControl.PropagationFlags*/ propagationFlags, /*System.Security.AccessControl.AuditFlags*/ auditFlags)
            {
                super.$ctor$1(null, 0, false, 0, 0);
                {
                }
                return this;
            }
            /*System.Security.AccessControl.AuditFlags */ get AuditFlags()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static $h = 834498;
            static $f = 0b110001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":965570,"p":[{"p":768962,"g":{"r":0,"d":0,"h":12885736386,"f":1},"n":"AuditFlags","d":834498,"h":8590769090,"f":1}],"c":[{"p":[{"n":"identity","p":232830},{"n":"accessMask","p":655361},{"n":"isInherited","p":262145},{"n":"inheritanceFlags","p":1883074},{"n":"propagationFlags","p":2603970},{"n":"auditFlags","p":768962}],"n":".ctor","o":"$ctor$2","d":834498,"h":4295801794,"f":4}],"h":834498}; }
            static get $b() { return $.$ssa.System.Security.AccessControl.AuthorizationRule; }
            static get $fullName() { return `System.Security.AccessControl.AuditRule`; }
        });
        
        $asm.$cls("$ssa.System.Security.AccessControl.CommonObjectSecurity", ($self) => class CommonObjectSecurity extends $.$ssa.System.Security.AccessControl.ObjectSecurity
        {
            $ctor$4(/*bool*/ isContainer)
            {
                super.$ctor$1();
                {
                }
                return this;
            }
            /*void */ AddAccessRule(/*System.Security.AccessControl.AccessRule*/ rule)
            {
            }
            /*void */ AddAuditRule(/*System.Security.AccessControl.AuditRule*/ rule)
            {
            }
            /*System.Security.AccessControl.AuthorizationRuleCollection */ GetAccessRules(/*bool*/ includeExplicit, /*bool*/ includeInherited, /*System.Type*/ targetType)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Security.AccessControl.AuthorizationRuleCollection */ GetAuditRules(/*bool*/ includeExplicit, /*bool*/ includeInherited, /*System.Type*/ targetType)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ ModifyAccess(/*System.Security.AccessControl.AccessControlModification*/ modification, /*System.Security.AccessControl.AccessRule*/ rule, /*out bool*/ modified)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ ModifyAudit(/*System.Security.AccessControl.AccessControlModification*/ modification, /*System.Security.AccessControl.AuditRule*/ rule, /*out bool*/ modified)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ RemoveAccessRule(/*System.Security.AccessControl.AccessRule*/ rule)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*void */ RemoveAccessRuleAll(/*System.Security.AccessControl.AccessRule*/ rule)
            {
            }
            /*void */ RemoveAccessRuleSpecific(/*System.Security.AccessControl.AccessRule*/ rule)
            {
            }
            /*bool */ RemoveAuditRule(/*System.Security.AccessControl.AuditRule*/ rule)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*void */ RemoveAuditRuleAll(/*System.Security.AccessControl.AuditRule*/ rule)
            {
            }
            /*void */ RemoveAuditRuleSpecific(/*System.Security.AccessControl.AuditRule*/ rule)
            {
            }
            /*void */ ResetAccessRule(/*System.Security.AccessControl.AccessRule*/ rule)
            {
            }
            /*void */ SetAccessRule(/*System.Security.AccessControl.AccessRule*/ rule)
            {
            }
            /*void */ SetAuditRule(/*System.Security.AccessControl.AuditRule*/ rule)
            {
            }
            static $h = 1227714;
            static $f = 0b110001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":2407362,"m":[{"r":65537,"p":[{"n":"rule","p":375746}],"n":"AddAccessRule","d":1227714,"h":8591162306,"f":4},{"r":65537,"p":[{"n":"rule","p":834498}],"n":"AddAuditRule","d":1227714,"h":12886129602,"f":4},{"r":1031106,"p":[{"n":"includeExplicit","p":262145},{"n":"includeInherited","p":262145},{"n":"targetType","p":142606337}],"n":"GetAccessRules","d":1227714,"h":17181096898,"f":1},{"r":1031106,"p":[{"n":"includeExplicit","p":262145},{"n":"includeInherited","p":262145},{"n":"targetType","p":142606337}],"n":"GetAuditRules","d":1227714,"h":21476064194,"f":1},{"r":262145,"p":[{"n":"modification","p":179138},{"n":"rule","p":375746},{"n":"modified","p":262145,"f":2}],"n":"ModifyAccess","d":1227714,"h":25771031490,"f":32772},{"r":262145,"p":[{"n":"modification","p":179138},{"n":"rule","p":834498},{"n":"modified","p":262145,"f":2}],"n":"ModifyAudit","d":1227714,"h":30065998786,"f":32772},{"r":262145,"p":[{"n":"rule","p":375746}],"n":"RemoveAccessRule","d":1227714,"h":34360966082,"f":4},{"r":65537,"p":[{"n":"rule","p":375746}],"n":"RemoveAccessRuleAll","d":1227714,"h":38655933378,"f":4},{"r":65537,"p":[{"n":"rule","p":375746}],"n":"RemoveAccessRuleSpecific","d":1227714,"h":42950900674,"f":4},{"r":262145,"p":[{"n":"rule","p":834498}],"n":"RemoveAuditRule","d":1227714,"h":47245867970,"f":4},{"r":65537,"p":[{"n":"rule","p":834498}],"n":"RemoveAuditRuleAll","d":1227714,"h":51540835266,"f":4},{"r":65537,"p":[{"n":"rule","p":834498}],"n":"RemoveAuditRuleSpecific","d":1227714,"h":55835802562,"f":4},{"r":65537,"p":[{"n":"rule","p":375746}],"n":"ResetAccessRule","d":1227714,"h":60130769858,"f":4},{"r":65537,"p":[{"n":"rule","p":375746}],"n":"SetAccessRule","d":1227714,"h":64425737154,"f":4},{"r":65537,"p":[{"n":"rule","p":834498}],"n":"SetAuditRule","d":1227714,"h":68720704450,"f":4}],"c":[{"p":[{"n":"isContainer","p":262145}],"n":".ctor","o":"$ctor$4","d":1227714,"h":4296195010,"f":4}],"h":1227714}; }
            static get $b() { return $.$ssa.System.Security.AccessControl.ObjectSecurity; }
            static get $fullName() { return `System.Security.AccessControl.CommonObjectSecurity`; }
        });
        
        $asm.$cls("$ssa.System.Security.AccessControl.KnownAce", ($self) => class KnownAce extends $.$ssa.System.Security.AccessControl.GenericAce
        {
            $ctor$2()
            {
                super.$ctor$1();
                {
                }
                return this;
            }
            /*int */ get AccessMask()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ set AccessMask(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Security.Principal.SecurityIdentifier */ get SecurityIdentifier()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Security.Principal.SecurityIdentifier */ set SecurityIdentifier(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static $h = 1948610;
            static $f = 0b110001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":1686466,"p":[{"p":655361,"g":{"r":0,"d":0,"h":12886850498,"f":1},"s":{"r":0,"d":0,"h":17181817794,"f":1},"n":"AccessMask","d":1948610,"h":8591883202,"f":1},{"p":429438,"g":{"r":0,"d":0,"h":25771752386,"f":1},"s":{"r":0,"d":0,"h":30066719682,"f":1},"n":"SecurityIdentifier","d":1948610,"h":21476785090,"f":1}],"c":[{"n":".ctor","o":"$ctor$2","d":1948610,"h":4296915906,"f":8}],"h":1948610}; }
            static get $b() { return $.$ssa.System.Security.AccessControl.GenericAce; }
            static get $fullName() { return `System.Security.AccessControl.KnownAce`; }
        });
        
        $asm.$cls("$ssa.System.Security.AccessControl.CommonAcl", ($self) => class CommonAcl extends $.$ssa.System.Security.AccessControl.GenericAcl
        {
            $ctor$2()
            {
                super.$ctor$1();
                {
                }
                return this;
            }
            /*int */ get BinaryLength()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ get Count()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get IsCanonical()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get IsContainer()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get IsDS()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Security.AccessControl.GenericAce*/ get_Item(/*int*/ index)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*void*/ set_Item(/*int*/ index, /*System.Security.AccessControl.GenericAce*/ value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*byte */ get Revision()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*void */ GetBinaryForm(/*byte[]*/ binaryForm, /*int*/ offset)
            {
            }
            /*void */ Purge(/*System.Security.Principal.SecurityIdentifier*/ sid)
            {
            }
            /*void */ RemoveInheritedAces()
            {
            }
            static $h = 1162178;
            static $f = 0b110001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":1752002,"p":[{"p":655361,"g":{"r":0,"d":0,"h":12886064066,"f":98305},"n":"BinaryLength","d":1162178,"h":8591096770,"f":98305},{"p":655361,"g":{"r":0,"d":0,"h":21475998658,"f":98305},"n":"Count","d":1162178,"h":17181031362,"f":98305},{"p":262145,"g":{"r":0,"d":0,"h":30065933250,"f":1},"n":"IsCanonical","d":1162178,"h":25770965954,"f":1},{"p":262145,"g":{"r":0,"d":0,"h":38655867842,"f":1},"n":"IsContainer","d":1162178,"h":34360900546,"f":1},{"p":262145,"g":{"r":0,"d":0,"h":47245802434,"f":1},"n":"IsDS","d":1162178,"h":42950835138,"f":1},{"p":1686466,"i":[{"n":"index","p":655361}],"g":{"r":0,"d":0,"h":55835737026,"f":98305},"s":{"r":0,"d":0,"h":60130704322,"f":98305},"n":"Item","o":"@$2","d":1162178,"h":51540769730,"f":98305},{"p":393217,"g":{"r":0,"d":0,"h":68720638914,"f":98305},"n":"Revision","d":1162178,"h":64425671618,"f":98305}],"m":[{"r":65537,"p":[{"n":"binaryForm","p":0},{"n":"offset","p":655361}],"n":"GetBinaryForm","d":1162178,"h":73015606210,"f":98305},{"r":65537,"p":[{"n":"sid","p":429438}],"n":"Purge","d":1162178,"h":77310573506,"f":1},{"r":65537,"n":"RemoveInheritedAces","d":1162178,"h":81605540802,"f":1}],"c":[{"n":".ctor","o":"$ctor$2","d":1162178,"h":4296129474,"f":8}],"i":[31391745,31653889],"h":1162178}; }
            static get $b() { return $.$ssa.System.Security.AccessControl.GenericAcl; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.Collections.ICollection, $.$spc.System.Collections.IEnumerable ]; }
            static get $fullName() { return `System.Security.AccessControl.CommonAcl`; }
        });
        
        $asm.$cls("$ssa.System.Security.AccessControl.NativeObjectSecurity", ($self) => class NativeObjectSecurity extends $.$ssa.System.Security.AccessControl.CommonObjectSecurity
        {
            $ctor$5(/*bool*/ isContainer, /*System.Security.AccessControl.ResourceType*/ resourceType)
            {
                super.$ctor$4(false);
                {
                }
                return this;
            }
            $ctor$6(/*bool*/ isContainer, /*System.Security.AccessControl.ResourceType*/ resourceType, /*System.Runtime.InteropServices.SafeHandle?*/ handle, /*System.Security.AccessControl.AccessControlSections*/ includeSections)
            {
                super.$ctor$4(false);
                {
                }
                return this;
            }
            $ctor$7(/*bool*/ isContainer, /*System.Security.AccessControl.ResourceType*/ resourceType, /*System.Runtime.InteropServices.SafeHandle?*/ handle, /*System.Security.AccessControl.AccessControlSections*/ includeSections, /*System.Security.AccessControl.NativeObjectSecurity.ExceptionFromErrorCode?*/ exceptionFromErrorCode, /*object?*/ exceptionContext)
            {
                super.$ctor$4(false);
                {
                }
                return this;
            }
            $ctor$8(/*bool*/ isContainer, /*System.Security.AccessControl.ResourceType*/ resourceType, /*System.Security.AccessControl.NativeObjectSecurity.ExceptionFromErrorCode?*/ exceptionFromErrorCode, /*object?*/ exceptionContext)
            {
                super.$ctor$4(false);
                {
                }
                return this;
            }
            $ctor$9(/*bool*/ isContainer, /*System.Security.AccessControl.ResourceType*/ resourceType, /*string?*/ name, /*System.Security.AccessControl.AccessControlSections*/ includeSections)
            {
                super.$ctor$4(false);
                {
                }
                return this;
            }
            $ctor$10(/*bool*/ isContainer, /*System.Security.AccessControl.ResourceType*/ resourceType, /*string?*/ name, /*System.Security.AccessControl.AccessControlSections*/ includeSections, /*System.Security.AccessControl.NativeObjectSecurity.ExceptionFromErrorCode?*/ exceptionFromErrorCode, /*object?*/ exceptionContext)
            {
                super.$ctor$4(false);
                {
                }
                return this;
            }
            /*void */ Persist$1(/*System.Runtime.InteropServices.SafeHandle*/ handle, /*System.Security.AccessControl.AccessControlSections*/ includeSections)
            {
            }
            /*void */ Persist$3(/*System.Runtime.InteropServices.SafeHandle*/ handle, /*System.Security.AccessControl.AccessControlSections*/ includeSections, /*object?*/ exceptionContext)
            {
            }
            /*void */ Persist$2(/*string*/ name, /*System.Security.AccessControl.AccessControlSections*/ includeSections)
            {
            }
            /*void */ Persist$4(/*string*/ name, /*System.Security.AccessControl.AccessControlSections*/ includeSections, /*object?*/ exceptionContext)
            {
            }
            static $_ExceptionFromErrorCode;
            static get ExceptionFromErrorCode()
            {
                let $cls = $.$ssa.System.Security.AccessControl.NativeObjectSecurity;
                return $cls.$_ExceptionFromErrorCode ??= $asm.$ncls("$ssa.System.Security.AccessControl.NativeObjectSecurity.ExceptionFromErrorCode", ($self) => class ExceptionFromErrorCode extends $.$spc.System.MulticastDelegate
                {
                    $ctor(/*object*/ target, fn, anmodel)
                    {
                        this.$target = target;
                        this.$nativeFunction = fn;
                        if (anmodel) this.$nfmodel = anmodel;
                        if (typeof(target) === 'object') this._target = target;
                        return this;
                    }
                    /*System.Exception?*/ Invoke(/*$.$spc.System.Int32*/ errorCode, /*$.$spc.System.Nullable$$*/ name, /*$.$spc.System.Nullable$$*/ handle, /*$.$spc.System.Nullable$$*/ context)
                    {
                        return this.$nativeFunction.call(this.$target, errorCode, name, handle, context);
                    }
                    static $h = 2079682;
                    static $f = 0b10000000010000000;
                    static $k = 5;
                    static $$md;
                    static get $md() { return this.$$md ??= {"b":66191361,"m":[{"r":47251457,"p":[{"n":"errorCode","p":655361},{"n":"name","p":1310721},{"n":"handle","p":109576193},{"n":"context","p":131073}],"n":"Invoke","d":2079682,"h":8592014274,"f":129},{"r":57016321,"p":[{"n":"errorCode","p":655361},{"n":"name","p":1310721},{"n":"handle","p":109576193},{"n":"context","p":131073},{"n":"callback","p":14483457},{"n":"object","p":131073}],"n":"BeginInvoke","d":2079682,"h":12886981570,"f":129},{"r":47251457,"p":[{"n":"result","p":57016321}],"n":"EndInvoke","d":2079682,"h":17181948866,"f":129}],"c":[{"p":[{"n":"object","p":131073},{"n":"method","p":786433}],"n":".ctor","o":"$ctor$5","d":2079682,"h":4297046978,"f":1}],"i":[57212929,113377281],"d":2014146,"h":2079682}; }
                    static get $b() { return $.$spc.System.MulticastDelegate; }
                    static $$i;
                    static get $i() { return this.$$i ??= [ $.$spc.System.ICloneable, $.$spc.System.Runtime.Serialization.ISerializable ]; }
                    static get $fullName() { return `System.Security.AccessControl.NativeObjectSecurity.ExceptionFromErrorCode`; }
                }, $cls, ($v) => $cls.$_ExceptionFromErrorCode = $v);
            }
            static $h = 2014146;
            static $f = 0b110001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":1227714,"m":[{"r":65537,"p":[{"n":"handle","p":109576193},{"n":"includeSections","p":244674}],"n":"Persist","o":"@$1","d":2014146,"h":30066785218,"f":98308},{"r":65537,"p":[{"n":"handle","p":109576193},{"n":"includeSections","p":244674},{"n":"exceptionContext","p":131073}],"n":"Persist","o":"@$3","d":2014146,"h":34361752514,"f":4},{"r":65537,"p":[{"n":"name","p":1310721},{"n":"includeSections","p":244674}],"n":"Persist","o":"@$2","d":2014146,"h":38656719810,"f":98308},{"r":65537,"p":[{"n":"name","p":1310721},{"n":"includeSections","p":244674},{"n":"exceptionContext","p":131073}],"n":"Persist","o":"@$4","d":2014146,"h":42951687106,"f":4}],"c":[{"p":[{"n":"isContainer","p":262145},{"n":"resourceType","p":2866114}],"n":".ctor","o":"$ctor$5","d":2014146,"h":4296981442,"f":4},{"p":[{"n":"isContainer","p":262145},{"n":"resourceType","p":2866114},{"n":"handle","p":109576193},{"n":"includeSections","p":244674}],"n":".ctor","o":"$ctor$6","d":2014146,"h":8591948738,"f":4},{"p":[{"n":"isContainer","p":262145},{"n":"resourceType","p":2866114},{"n":"handle","p":109576193},{"n":"includeSections","p":244674},{"n":"exceptionFromErrorCode","p":2079682},{"n":"exceptionContext","p":131073}],"n":".ctor","o":"$ctor$7","d":2014146,"h":12886916034,"f":4},{"p":[{"n":"isContainer","p":262145},{"n":"resourceType","p":2866114},{"n":"exceptionFromErrorCode","p":2079682},{"n":"exceptionContext","p":131073}],"n":".ctor","o":"$ctor$8","d":2014146,"h":17181883330,"f":4},{"p":[{"n":"isContainer","p":262145},{"n":"resourceType","p":2866114},{"n":"name","p":1310721},{"n":"includeSections","p":244674}],"n":".ctor","o":"$ctor$9","d":2014146,"h":21476850626,"f":4},{"p":[{"n":"isContainer","p":262145},{"n":"resourceType","p":2866114},{"n":"name","p":1310721},{"n":"includeSections","p":244674},{"n":"exceptionFromErrorCode","p":2079682},{"n":"exceptionContext","p":131073}],"n":".ctor","o":"$ctor$10","d":2014146,"h":25771817922,"f":4}],"j":[2079682],"h":2014146}; }
            static get $b() { return $.$ssa.System.Security.AccessControl.CommonObjectSecurity; }
            static get $fullName() { return `System.Security.AccessControl.NativeObjectSecurity`; }
        });
        
        $asm.$cls("$ssa.System.Security.AccessControl.ObjectAccessRule", ($self) => class ObjectAccessRule extends $.$ssa.System.Security.AccessControl.AccessRule
        {
            $ctor$3(/*System.Security.Principal.IdentityReference*/ identity, /*int*/ accessMask, /*bool*/ isInherited, /*System.Security.AccessControl.InheritanceFlags*/ inheritanceFlags, /*System.Security.AccessControl.PropagationFlags*/ propagationFlags, /*System.Guid*/ objectType, /*System.Guid*/ inheritedObjectType, /*System.Security.AccessControl.AccessControlType*/ type)
            {
                super.$ctor$2(null, 0, false, 0, 0, 0);
                {
                }
                return this;
            }
            /*System.Guid */ get InheritedObjectType()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Security.AccessControl.ObjectAceFlags */ get ObjectFlags()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Guid */ get ObjectType()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static $h = 2145218;
            static $f = 0b110001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":375746,"p":[{"p":56229889,"g":{"r":0,"d":0,"h":12887047106,"f":1},"n":"InheritedObjectType","d":2145218,"h":8592079810,"f":1},{"p":2276290,"g":{"r":0,"d":0,"h":21476981698,"f":1},"n":"ObjectFlags","d":2145218,"h":17182014402,"f":1},{"p":56229889,"g":{"r":0,"d":0,"h":30066916290,"f":1},"n":"ObjectType","d":2145218,"h":25771948994,"f":1}],"c":[{"p":[{"n":"identity","p":232830},{"n":"accessMask","p":655361},{"n":"isInherited","p":262145},{"n":"inheritanceFlags","p":1883074},{"n":"propagationFlags","p":2603970},{"n":"objectType","p":56229889},{"n":"inheritedObjectType","p":56229889},{"n":"type","p":310210}],"n":".ctor","o":"$ctor$3","d":2145218,"h":4297112514,"f":4}],"h":2145218}; }
            static get $b() { return $.$ssa.System.Security.AccessControl.AccessRule; }
            static get $fullName() { return `System.Security.AccessControl.ObjectAccessRule`; }
        });
        
        $asm.$cls("$ssa.System.Security.AccessControl.ObjectAuditRule", ($self) => class ObjectAuditRule extends $.$ssa.System.Security.AccessControl.AuditRule
        {
            $ctor$3(/*System.Security.Principal.IdentityReference*/ identity, /*int*/ accessMask, /*bool*/ isInherited, /*System.Security.AccessControl.InheritanceFlags*/ inheritanceFlags, /*System.Security.AccessControl.PropagationFlags*/ propagationFlags, /*System.Guid*/ objectType, /*System.Guid*/ inheritedObjectType, /*System.Security.AccessControl.AuditFlags*/ auditFlags)
            {
                super.$ctor$2(null, 0, false, 0, 0, 0);
                {
                }
                return this;
            }
            /*System.Guid */ get InheritedObjectType()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Security.AccessControl.ObjectAceFlags */ get ObjectFlags()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Guid */ get ObjectType()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static $h = 2341826;
            static $f = 0b110001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":834498,"p":[{"p":56229889,"g":{"r":0,"d":0,"h":12887243714,"f":1},"n":"InheritedObjectType","d":2341826,"h":8592276418,"f":1},{"p":2276290,"g":{"r":0,"d":0,"h":21477178306,"f":1},"n":"ObjectFlags","d":2341826,"h":17182211010,"f":1},{"p":56229889,"g":{"r":0,"d":0,"h":30067112898,"f":1},"n":"ObjectType","d":2341826,"h":25772145602,"f":1}],"c":[{"p":[{"n":"identity","p":232830},{"n":"accessMask","p":655361},{"n":"isInherited","p":262145},{"n":"inheritanceFlags","p":1883074},{"n":"propagationFlags","p":2603970},{"n":"objectType","p":56229889},{"n":"inheritedObjectType","p":56229889},{"n":"auditFlags","p":768962}],"n":".ctor","o":"$ctor$3","d":2341826,"h":4297309122,"f":4}],"h":2341826}; }
            static get $b() { return $.$ssa.System.Security.AccessControl.AuditRule; }
            static get $fullName() { return `System.Security.AccessControl.ObjectAuditRule`; }
        });
        
        $asm.$cls("$ssa.System.Security.AccessControl.QualifiedAce", ($self) => class QualifiedAce extends $.$ssa.System.Security.AccessControl.KnownAce
        {
            $ctor$3()
            {
                super.$ctor$2();
                {
                }
                return this;
            }
            /*System.Security.AccessControl.AceQualifier */ get AceQualifier()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get IsCallback()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ get OpaqueLength()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*byte[]? */ GetOpaque()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*void */ SetOpaque(/*byte[]?*/ opaque)
            {
            }
            static $h = 2669506;
            static $f = 0b110001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":1948610,"p":[{"p":637890,"g":{"r":0,"d":0,"h":12887571394,"f":1},"n":"AceQualifier","d":2669506,"h":8592604098,"f":1},{"p":262145,"g":{"r":0,"d":0,"h":21477505986,"f":1},"n":"IsCallback","d":2669506,"h":17182538690,"f":1},{"p":655361,"g":{"r":0,"d":0,"h":30067440578,"f":1},"n":"OpaqueLength","d":2669506,"h":25772473282,"f":1}],"m":[{"r":0,"n":"GetOpaque","d":2669506,"h":34362407874,"f":1},{"r":65537,"p":[{"n":"opaque","p":0}],"n":"SetOpaque","d":2669506,"h":38657375170,"f":1}],"c":[{"n":".ctor","o":"$ctor$3","d":2669506,"h":4297636802,"f":8}],"h":2669506}; }
            static get $b() { return $.$ssa.System.Security.AccessControl.KnownAce; }
            static get $fullName() { return `System.Security.AccessControl.QualifiedAce`; }
        });
        
        $asm.$cls("$ssa.System.Security.AccessControl.ObjectSecurity<>", (T) => $asm.$gt("$ssa.System.Security.AccessControl.ObjectSecurity<>", [T], ($self) => class ObjectSecurity$$ extends $.$ssa.System.Security.AccessControl.NativeObjectSecurity
        {
            $ctor$11(/*bool*/ isContainer, /*System.Security.AccessControl.ResourceType*/ resourceType)
            {
                super.$ctor$5(false, 0);
                {
                }
                return this;
            }
            $ctor$12(/*bool*/ isContainer, /*System.Security.AccessControl.ResourceType*/ resourceType, /*System.Runtime.InteropServices.SafeHandle?*/ safeHandle, /*System.Security.AccessControl.AccessControlSections*/ includeSections)
            {
                super.$ctor$5(false, 0);
                {
                }
                return this;
            }
            $ctor$13(/*bool*/ isContainer, /*System.Security.AccessControl.ResourceType*/ resourceType, /*System.Runtime.InteropServices.SafeHandle?*/ safeHandle, /*System.Security.AccessControl.AccessControlSections*/ includeSections, /*System.Security.AccessControl.NativeObjectSecurity.ExceptionFromErrorCode?*/ exceptionFromErrorCode, /*object?*/ exceptionContext)
            {
                super.$ctor$5(false, 0);
                {
                }
                return this;
            }
            $ctor$14(/*bool*/ isContainer, /*System.Security.AccessControl.ResourceType*/ resourceType, /*string?*/ name, /*System.Security.AccessControl.AccessControlSections*/ includeSections)
            {
                super.$ctor$5(false, 0);
                {
                }
                return this;
            }
            $ctor$15(/*bool*/ isContainer, /*System.Security.AccessControl.ResourceType*/ resourceType, /*string?*/ name, /*System.Security.AccessControl.AccessControlSections*/ includeSections, /*System.Security.AccessControl.NativeObjectSecurity.ExceptionFromErrorCode?*/ exceptionFromErrorCode, /*object?*/ exceptionContext)
            {
                super.$ctor$5(false, 0);
                {
                }
                return this;
            }
            /*System.Type */ get AccessRightType()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Type */ get AccessRuleType()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Type */ get AuditRuleType()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Security.AccessControl.AccessRule */ AccessRuleFactory(/*System.Security.Principal.IdentityReference*/ identityReference, /*int*/ accessMask, /*bool*/ isInherited, /*System.Security.AccessControl.InheritanceFlags*/ inheritanceFlags, /*System.Security.AccessControl.PropagationFlags*/ propagationFlags, /*System.Security.AccessControl.AccessControlType*/ type)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*void */ AddAccessRule$1(/*System.Security.AccessControl.AccessRule<T>*/ rule)
            {
            }
            /*void */ AddAuditRule$1(/*System.Security.AccessControl.AuditRule<T>*/ rule)
            {
            }
            /*System.Security.AccessControl.AuditRule */ AuditRuleFactory(/*System.Security.Principal.IdentityReference*/ identityReference, /*int*/ accessMask, /*bool*/ isInherited, /*System.Security.AccessControl.InheritanceFlags*/ inheritanceFlags, /*System.Security.AccessControl.PropagationFlags*/ propagationFlags, /*System.Security.AccessControl.AuditFlags*/ flags)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*void */ Persist$5(/*System.Runtime.InteropServices.SafeHandle*/ handle)
            {
            }
            /*void */ Persist$6(/*string*/ name)
            {
            }
            /*bool */ RemoveAccessRule$1(/*System.Security.AccessControl.AccessRule<T>*/ rule)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*void */ RemoveAccessRuleAll$1(/*System.Security.AccessControl.AccessRule<T>*/ rule)
            {
            }
            /*void */ RemoveAccessRuleSpecific$1(/*System.Security.AccessControl.AccessRule<T>*/ rule)
            {
            }
            /*bool */ RemoveAuditRule$1(/*System.Security.AccessControl.AuditRule<T>*/ rule)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*void */ RemoveAuditRuleAll$1(/*System.Security.AccessControl.AuditRule<T>*/ rule)
            {
            }
            /*void */ RemoveAuditRuleSpecific$1(/*System.Security.AccessControl.AuditRule<T>*/ rule)
            {
            }
            /*void */ ResetAccessRule$1(/*System.Security.AccessControl.AccessRule<T>*/ rule)
            {
            }
            /*void */ SetAccessRule$1(/*System.Security.AccessControl.AccessRule<T>*/ rule)
            {
            }
            /*void */ SetAuditRule$1(/*System.Security.AccessControl.AuditRule<T>*/ rule)
            {
            }
            static $h = 2472898;
            static $g = 1;
            static $f = 0b1110001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":2014146,"p":[{"p":142606337,"g":{"r":0,"d":0,"h":Number(BigInt(this.$h)|0x700000000n),"f":32769},"n":"AccessRightType","d":this.$h,"h":Number(BigInt(this.$h)|0x600000000n),"f":32769},{"p":142606337,"g":{"r":0,"d":0,"h":Number(BigInt(this.$h)|0x900000000n),"f":32769},"n":"AccessRuleType","d":this.$h,"h":Number(BigInt(this.$h)|0x800000000n),"f":32769},{"p":142606337,"g":{"r":0,"d":0,"h":Number(BigInt(this.$h)|0xB00000000n),"f":32769},"n":"AuditRuleType","d":this.$h,"h":Number(BigInt(this.$h)|0xA00000000n),"f":32769}],"m":[{"r":375746,"p":[{"n":"identityReference","p":232830},{"n":"accessMask","p":655361},{"n":"isInherited","p":262145},{"n":"inheritanceFlags","p":1883074},{"n":"propagationFlags","p":2603970},{"n":"type","p":310210}],"n":"AccessRuleFactory","d":this.$h,"h":Number(BigInt(this.$h)|0xC00000000n),"f":32769},{"r":65537,"p":[{"n":"rule","p":$.$ssa.System.Security.AccessControl.AccessRule$$(T).$h}],"n":"AddAccessRule","o":"@$1","d":this.$h,"h":Number(BigInt(this.$h)|0xD00000000n),"f":129},{"r":65537,"p":[{"n":"rule","p":$.$ssa.System.Security.AccessControl.AuditRule$$(T).$h}],"n":"AddAuditRule","o":"@$1","d":this.$h,"h":Number(BigInt(this.$h)|0xE00000000n),"f":129},{"r":834498,"p":[{"n":"identityReference","p":232830},{"n":"accessMask","p":655361},{"n":"isInherited","p":262145},{"n":"inheritanceFlags","p":1883074},{"n":"propagationFlags","p":2603970},{"n":"flags","p":768962}],"n":"AuditRuleFactory","d":this.$h,"h":Number(BigInt(this.$h)|0xF00000000n),"f":32769},{"r":65537,"p":[{"n":"handle","p":109576193}],"n":"Persist","o":"@$5","d":this.$h,"h":Number(BigInt(this.$h)|0x1000000000n),"f":16},{"r":65537,"p":[{"n":"name","p":1310721}],"n":"Persist","o":"@$6","d":this.$h,"h":Number(BigInt(this.$h)|0x1100000000n),"f":16},{"r":262145,"p":[{"n":"rule","p":$.$ssa.System.Security.AccessControl.AccessRule$$(T).$h}],"n":"RemoveAccessRule","o":"@$1","d":this.$h,"h":Number(BigInt(this.$h)|0x1200000000n),"f":129},{"r":65537,"p":[{"n":"rule","p":$.$ssa.System.Security.AccessControl.AccessRule$$(T).$h}],"n":"RemoveAccessRuleAll","o":"@$1","d":this.$h,"h":Number(BigInt(this.$h)|0x1300000000n),"f":129},{"r":65537,"p":[{"n":"rule","p":$.$ssa.System.Security.AccessControl.AccessRule$$(T).$h}],"n":"RemoveAccessRuleSpecific","o":"@$1","d":this.$h,"h":Number(BigInt(this.$h)|0x1400000000n),"f":129},{"r":262145,"p":[{"n":"rule","p":$.$ssa.System.Security.AccessControl.AuditRule$$(T).$h}],"n":"RemoveAuditRule","o":"@$1","d":this.$h,"h":Number(BigInt(this.$h)|0x1500000000n),"f":129},{"r":65537,"p":[{"n":"rule","p":$.$ssa.System.Security.AccessControl.AuditRule$$(T).$h}],"n":"RemoveAuditRuleAll","o":"@$1","d":this.$h,"h":Number(BigInt(this.$h)|0x1600000000n),"f":129},{"r":65537,"p":[{"n":"rule","p":$.$ssa.System.Security.AccessControl.AuditRule$$(T).$h}],"n":"RemoveAuditRuleSpecific","o":"@$1","d":this.$h,"h":Number(BigInt(this.$h)|0x1700000000n),"f":129},{"r":65537,"p":[{"n":"rule","p":$.$ssa.System.Security.AccessControl.AccessRule$$(T).$h}],"n":"ResetAccessRule","o":"@$1","d":this.$h,"h":Number(BigInt(this.$h)|0x1800000000n),"f":129},{"r":65537,"p":[{"n":"rule","p":$.$ssa.System.Security.AccessControl.AccessRule$$(T).$h}],"n":"SetAccessRule","o":"@$1","d":this.$h,"h":Number(BigInt(this.$h)|0x1900000000n),"f":129},{"r":65537,"p":[{"n":"rule","p":$.$ssa.System.Security.AccessControl.AuditRule$$(T).$h}],"n":"SetAuditRule","o":"@$1","d":this.$h,"h":Number(BigInt(this.$h)|0x1A00000000n),"f":129}],"c":[{"p":[{"n":"isContainer","p":262145},{"n":"resourceType","p":2866114}],"n":".ctor","o":"$ctor$11","d":this.$h,"h":Number(BigInt(this.$h)|0x100000000n),"f":4},{"p":[{"n":"isContainer","p":262145},{"n":"resourceType","p":2866114},{"n":"safeHandle","p":109576193},{"n":"includeSections","p":244674}],"n":".ctor","o":"$ctor$12","d":this.$h,"h":Number(BigInt(this.$h)|0x200000000n),"f":4},{"p":[{"n":"isContainer","p":262145},{"n":"resourceType","p":2866114},{"n":"safeHandle","p":109576193},{"n":"includeSections","p":244674},{"n":"exceptionFromErrorCode","p":2079682},{"n":"exceptionContext","p":131073}],"n":".ctor","o":"$ctor$13","d":this.$h,"h":Number(BigInt(this.$h)|0x300000000n),"f":4},{"p":[{"n":"isContainer","p":262145},{"n":"resourceType","p":2866114},{"n":"name","p":1310721},{"n":"includeSections","p":244674}],"n":".ctor","o":"$ctor$14","d":this.$h,"h":Number(BigInt(this.$h)|0x400000000n),"f":4},{"p":[{"n":"isContainer","p":262145},{"n":"resourceType","p":2866114},{"n":"name","p":1310721},{"n":"includeSections","p":244674},{"n":"exceptionFromErrorCode","p":2079682},{"n":"exceptionContext","p":131073}],"n":".ctor","o":"$ctor$15","d":this.$h,"h":Number(BigInt(this.$h)|0x500000000n),"f":4}],"g":[T?.$h??1507328],"s":[{"n":"T","f":2}],"r":1,"h":this.$h}; }
            static get $b() { return $.$ssa.System.Security.AccessControl.NativeObjectSecurity; }
            static get $fullName() { return `System.Security.AccessControl.ObjectSecurity<${T?.$fullName}>`; }
        }));
        
        $asm.$cls("$ssa.System.Security.AccessControl.AceEnumerator", ($self) => class AceEnumerator extends $.$spc.System.Object
        {
            $ctor$1()
            {
                super.$ctor();
                {
                }
                return this;
            }
            /*System.Security.AccessControl.GenericAce */ get Current()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*object */ get System$Collections$IEnumerator$Current()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ MoveNext()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*void */ Reset()
            {
            }
            //Generated interface implemetation for System.Collections.IEnumerator.MoveNext()
            System$Collections$IEnumerator$MoveNext()
            {
                return this.MoveNext(...arguments);
            }
            //Generated interface implemetation for System.Collections.IEnumerator.Reset()
            System$Collections$IEnumerator$Reset()
            {
                return this.Reset(...arguments);
            }
            static $h = 506818;
            static $f = 0b10010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":1686466,"g":{"r":0,"d":0,"h":12885408706,"f":1},"n":"Current","d":506818,"h":8590441410,"f":1},{"p":131073,"g":{"r":0,"d":0,"h":21475343298,"f":2},"n":"{31784961}.Current","o":"System$Collections$IEnumerator$Current","d":506818,"h":17180376002,"f":2}],"m":[{"r":262145,"n":"MoveNext","d":506818,"h":25770310594,"f":1},{"r":65537,"n":"Reset","d":506818,"h":30065277890,"f":1}],"c":[{"n":".ctor","o":"$ctor$1","d":506818,"h":4295474114,"f":8}],"i":[31784961],"h":506818}; }
            static get $b() { return $.$spc.System.Object; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.Collections.IEnumerator ]; }
            static get $fullName() { return `System.Security.AccessControl.AceEnumerator`; }
        });
        
        $asm.$cls("$ssa.System.Security.Policy.Evidence", ($self) => class Evidence extends $.$spc.System.Object
        {
            $ctor$1()
            {
                super.$ctor();
                {
                }
                return this;
            }
            $ctor$2(/*object[]*/ hostEvidence, /*object[]*/ assemblyEvidence)
            {
                super.$ctor();
                {
                }
                return this;
            }
            $ctor$3(/*System.Security.Policy.Evidence*/ evidence)
            {
                super.$ctor();
                {
                }
                return this;
            }
            $ctor$4(/*System.Security.Policy.EvidenceBase[]*/ hostEvidence, /*System.Security.Policy.EvidenceBase[]*/ assemblyEvidence)
            {
                super.$ctor();
                {
                }
                return this;
            }
            /*int */ get Count()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get IsReadOnly()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get IsSynchronized()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get Locked()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ set Locked(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*object */ get SyncRoot()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*void */ AddAssembly(/*object*/ id)
            {
            }
            /*void */ AddAssemblyEvidence(T, /*T*/ evidence)
            {
            }
            /*void */ AddHost(/*object*/ id)
            {
            }
            /*void */ AddHostEvidence(T, /*T*/ evidence)
            {
            }
            /*void */ Clear()
            {
            }
            /*System.Security.Policy.Evidence? */ Clone()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*void */ CopyTo(/*System.Array*/ array, /*int*/ index)
            {
            }
            /*System.Collections.IEnumerator */ GetAssemblyEnumerator()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*T? */ GetAssemblyEvidence(T)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Collections.IEnumerator */ GetEnumerator()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Collections.IEnumerator */ GetHostEnumerator()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*T? */ GetHostEvidence(T)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*void */ Merge(/*System.Security.Policy.Evidence*/ evidence)
            {
            }
            /*void */ RemoveType(/*System.Type*/ t)
            {
            }
            //Generated interface implemetation for System.Collections.ICollection.CopyTo(System.Array, int)
            System$Collections$ICollection$CopyTo()
            {
                return this.CopyTo(...arguments);
            }
            //Generated interface implemetation for System.Collections.ICollection.Count.get
            get System$Collections$ICollection$Count()
            {
                return this.Count;
            }
            //Generated interface implemetation for System.Collections.ICollection.SyncRoot.get
            get System$Collections$ICollection$SyncRoot()
            {
                return this.SyncRoot;
            }
            //Generated interface implemetation for System.Collections.ICollection.IsSynchronized.get
            get System$Collections$ICollection$IsSynchronized()
            {
                return this.IsSynchronized;
            }
            //Generated interface implemetation for System.Collections.IEnumerable.GetEnumerator()
            System$Collections$IEnumerable$GetEnumerator()
            {
                return this.GetEnumerator(...arguments);
            }
            static $h = 3062722;
            static $f = 0b10010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":655361,"g":{"r":0,"d":0,"h":25772866498,"f":1},"n":"Count","d":3062722,"h":21477899202,"f":1,"a":[{"t":70909953,"c":8660844545,"a":[{"v":"Evidence should not be treated as an ICollection. Use GetHostEnumerator and GetAssemblyEnumerator to iterate over the evidence to collect a count.","t":1310721}]}]},{"p":262145,"g":{"r":0,"d":0,"h":34362801090,"f":1},"n":"IsReadOnly","d":3062722,"h":30067833794,"f":1},{"p":262145,"g":{"r":0,"d":0,"h":42952735682,"f":1},"n":"IsSynchronized","d":3062722,"h":38657768386,"f":1},{"p":262145,"g":{"r":0,"d":0,"h":51542670274,"f":1},"s":{"r":0,"d":0,"h":55837637570,"f":1},"n":"Locked","d":3062722,"h":47247702978,"f":1},{"p":131073,"g":{"r":0,"d":0,"h":64427572162,"f":1},"n":"SyncRoot","d":3062722,"h":60132604866,"f":1}],"m":[{"r":65537,"p":[{"n":"id","p":131073}],"n":"AddAssembly","d":3062722,"h":68722539458,"f":1,"a":[{"t":70909953,"c":8660844545,"a":[{"v":"Evidence.AddAssembly has been deprecated. Use AddAssemblyEvidence instead.","t":1310721}]}]},{"r":65537,"p":[{"n":"evidence","p":(T) => T.$h}],"g":["T"],"n":"AddAssemblyEvidence","d":3062722,"h":73017506754,"f":131073},{"r":65537,"p":[{"n":"id","p":131073}],"n":"AddHost","d":3062722,"h":77312474050,"f":1,"a":[{"t":70909953,"c":8660844545,"a":[{"v":"Evidence.AddHost has been deprecated. Use AddHostEvidence instead.","t":1310721}]}]},{"r":65537,"p":[{"n":"evidence","p":(T) => T.$h}],"g":["T"],"n":"AddHostEvidence","d":3062722,"h":81607441346,"f":131073},{"r":65537,"n":"Clear","d":3062722,"h":85902408642,"f":1},{"r":3062722,"n":"Clone","d":3062722,"h":90197375938,"f":1},{"r":65537,"p":[{"n":"array","p":1245185},{"n":"index","p":655361}],"n":"CopyTo","d":3062722,"h":94492343234,"f":1,"a":[{"t":70909953,"c":8660844545,"a":[{"v":"Evidence should not be treated as an ICollection. Use the GetHostEnumerator and GetAssemblyEnumerator methods rather than using CopyTo.","t":1310721}]}]},{"r":31784961,"n":"GetAssemblyEnumerator","d":3062722,"h":98787310530,"f":1},{"r":(T) => T.$h,"g":["T"],"n":"GetAssemblyEvidence","d":3062722,"h":103082277826,"f":131073},{"r":31784961,"n":"GetEnumerator","d":3062722,"h":107377245122,"f":1,"a":[{"t":70909953,"c":8660844545,"a":[{"v":"GetEnumerator is obsolete. Use GetAssemblyEnumerator and GetHostEnumerator instead.","t":1310721}]}]},{"r":31784961,"n":"GetHostEnumerator","d":3062722,"h":111672212418,"f":1},{"r":(T) => T.$h,"g":["T"],"n":"GetHostEvidence","d":3062722,"h":115967179714,"f":131073},{"r":65537,"p":[{"n":"evidence","p":3062722}],"n":"Merge","d":3062722,"h":120262147010,"f":1},{"r":65537,"p":[{"n":"t","p":142606337}],"n":"RemoveType","d":3062722,"h":124557114306,"f":1}],"c":[{"n":".ctor","o":"$ctor$1","d":3062722,"h":4298030018,"f":1},{"p":[{"n":"hostEvidence","p":0},{"n":"assemblyEvidence","p":0}],"n":".ctor","o":"$ctor$2","d":3062722,"h":8592997314,"f":1,"a":[{"t":70909953,"c":8660844545,"a":[{"v":"This constructor is obsolete. Use the constructor which accepts arrays of EvidenceBase instead.","t":1310721}]}]},{"p":[{"n":"evidence","p":3062722}],"n":".ctor","o":"$ctor$3","d":3062722,"h":12887964610,"f":1},{"p":[{"n":"hostEvidence","p":0},{"n":"assemblyEvidence","p":0}],"n":".ctor","o":"$ctor$4","d":3062722,"h":17182931906,"f":1}],"i":[31391745,31653889],"h":3062722}; }
            static get $b() { return $.$spc.System.Object; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.Collections.ICollection, $.$spc.System.Collections.IEnumerable ]; }
            static get $fullName() { return `System.Security.Policy.Evidence`; }
        });
        
        $asm.$cls("$ssa.System.Security.AccessControl.CommonSecurityDescriptor", ($self) => class CommonSecurityDescriptor extends $.$ssa.System.Security.AccessControl.GenericSecurityDescriptor
        {
            $ctor$2(/*bool*/ isContainer, /*bool*/ isDS, /*byte[]*/ binaryForm, /*int*/ offset)
            {
                super.$ctor$1();
                {
                }
                return this;
            }
            $ctor$3(/*bool*/ isContainer, /*bool*/ isDS, /*System.Security.AccessControl.ControlFlags*/ flags, /*System.Security.Principal.SecurityIdentifier?*/ owner, /*System.Security.Principal.SecurityIdentifier?*/ group, /*System.Security.AccessControl.SystemAcl?*/ systemAcl, /*System.Security.AccessControl.DiscretionaryAcl?*/ discretionaryAcl)
            {
                super.$ctor$1();
                {
                }
                return this;
            }
            $ctor$4(/*bool*/ isContainer, /*bool*/ isDS, /*System.Security.AccessControl.RawSecurityDescriptor*/ rawSecurityDescriptor)
            {
                super.$ctor$1();
                {
                }
                return this;
            }
            $ctor$5(/*bool*/ isContainer, /*bool*/ isDS, /*string*/ sddlForm)
            {
                super.$ctor$1();
                {
                }
                return this;
            }
            /*System.Security.AccessControl.ControlFlags */ get ControlFlags()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Security.AccessControl.DiscretionaryAcl? */ get DiscretionaryAcl()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Security.AccessControl.DiscretionaryAcl? */ set DiscretionaryAcl(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Security.Principal.SecurityIdentifier? */ get Group()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Security.Principal.SecurityIdentifier? */ set Group(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get IsContainer()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get IsDiscretionaryAclCanonical()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get IsDS()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get IsSystemAclCanonical()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Security.Principal.SecurityIdentifier? */ get Owner()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Security.Principal.SecurityIdentifier? */ set Owner(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Security.AccessControl.SystemAcl? */ get SystemAcl()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Security.AccessControl.SystemAcl? */ set SystemAcl(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*void */ AddDiscretionaryAcl(/*byte*/ revision, /*int*/ trusted)
            {
            }
            /*void */ AddSystemAcl(/*byte*/ revision, /*int*/ trusted)
            {
            }
            /*void */ PurgeAccessControl(/*System.Security.Principal.SecurityIdentifier*/ sid)
            {
            }
            /*void */ PurgeAudit(/*System.Security.Principal.SecurityIdentifier*/ sid)
            {
            }
            /*void */ SetDiscretionaryAclProtection(/*bool*/ isProtected, /*bool*/ preserveInheritance)
            {
            }
            /*void */ SetSystemAclProtection(/*bool*/ isProtected, /*bool*/ preserveInheritance)
            {
            }
            static $h = 1293250;
            static $f = 0b10010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":1817538,"p":[{"p":1489858,"g":{"r":0,"d":0,"h":25771097026,"f":32769},"n":"ControlFlags","d":1293250,"h":21476129730,"f":32769},{"p":1620930,"g":{"r":0,"d":0,"h":34361031618,"f":1},"s":{"r":0,"d":0,"h":38655998914,"f":1},"n":"DiscretionaryAcl","d":1293250,"h":30066064322,"f":1},{"p":429438,"g":{"r":0,"d":0,"h":47245933506,"f":32769},"s":{"r":0,"d":0,"h":51540900802,"f":32769},"n":"Group","d":1293250,"h":42950966210,"f":32769},{"p":262145,"g":{"r":0,"d":0,"h":60130835394,"f":1},"n":"IsContainer","d":1293250,"h":55835868098,"f":1},{"p":262145,"g":{"r":0,"d":0,"h":68720769986,"f":1},"n":"IsDiscretionaryAclCanonical","d":1293250,"h":64425802690,"f":1},{"p":262145,"g":{"r":0,"d":0,"h":77310704578,"f":1},"n":"IsDS","d":1293250,"h":73015737282,"f":1},{"p":262145,"g":{"r":0,"d":0,"h":85900639170,"f":1},"n":"IsSystemAclCanonical","d":1293250,"h":81605671874,"f":1},{"p":429438,"g":{"r":0,"d":0,"h":94490573762,"f":32769},"s":{"r":0,"d":0,"h":98785541058,"f":32769},"n":"Owner","d":1293250,"h":90195606466,"f":32769},{"p":2997186,"g":{"r":0,"d":0,"h":107375475650,"f":1},"s":{"r":0,"d":0,"h":111670442946,"f":1},"n":"SystemAcl","d":1293250,"h":103080508354,"f":1}],"m":[{"r":65537,"p":[{"n":"revision","p":393217},{"n":"trusted","p":655361}],"n":"AddDiscretionaryAcl","d":1293250,"h":115965410242,"f":1},{"r":65537,"p":[{"n":"revision","p":393217},{"n":"trusted","p":655361}],"n":"AddSystemAcl","d":1293250,"h":120260377538,"f":1},{"r":65537,"p":[{"n":"sid","p":429438}],"n":"PurgeAccessControl","d":1293250,"h":124555344834,"f":1},{"r":65537,"p":[{"n":"sid","p":429438}],"n":"PurgeAudit","d":1293250,"h":128850312130,"f":1},{"r":65537,"p":[{"n":"isProtected","p":262145},{"n":"preserveInheritance","p":262145}],"n":"SetDiscretionaryAclProtection","d":1293250,"h":133145279426,"f":1},{"r":65537,"p":[{"n":"isProtected","p":262145},{"n":"preserveInheritance","p":262145}],"n":"SetSystemAclProtection","d":1293250,"h":137440246722,"f":1}],"c":[{"p":[{"n":"isContainer","p":262145},{"n":"isDS","p":262145},{"n":"binaryForm","p":0},{"n":"offset","p":655361}],"n":".ctor","o":"$ctor$2","d":1293250,"h":4296260546,"f":1},{"p":[{"n":"isContainer","p":262145},{"n":"isDS","p":262145},{"n":"flags","p":1489858},{"n":"owner","p":429438},{"n":"group","p":429438},{"n":"systemAcl","p":2997186},{"n":"discretionaryAcl","p":1620930}],"n":".ctor","o":"$ctor$3","d":1293250,"h":8591227842,"f":1},{"p":[{"n":"isContainer","p":262145},{"n":"isDS","p":262145},{"n":"rawSecurityDescriptor","p":2800578}],"n":".ctor","o":"$ctor$4","d":1293250,"h":12886195138,"f":1},{"p":[{"n":"isContainer","p":262145},{"n":"isDS","p":262145},{"n":"sddlForm","p":1310721}],"n":".ctor","o":"$ctor$5","d":1293250,"h":17181162434,"f":1}],"h":1293250}; }
            static get $b() { return $.$ssa.System.Security.AccessControl.GenericSecurityDescriptor; }
            static get $fullName() { return `System.Security.AccessControl.CommonSecurityDescriptor`; }
        });
        
        $asm.$cls("$ssa.System.Security.AccessControl.CustomAce", ($self) => class CustomAce extends $.$ssa.System.Security.AccessControl.GenericAce
        {
            /*int*/ static MaxOpaqueLength = 0;
            $ctor$2(/*System.Security.AccessControl.AceType*/ type, /*System.Security.AccessControl.AceFlags*/ flags, /*byte[]?*/ opaque)
            {
                super.$ctor$1();
                {
                }
                return this;
            }
            /*int */ get BinaryLength()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ get OpaqueLength()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*void */ GetBinaryForm(/*byte[]*/ binaryForm, /*int*/ offset)
            {
            }
            /*byte[]? */ GetOpaque()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*void */ SetOpaque(/*byte[]?*/ opaque)
            {
            }
            static $h = 1555394;
            static $f = 0b10010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":1686466,"p":[{"p":655361,"g":{"r":0,"d":0,"h":17181424578,"f":32769},"n":"BinaryLength","d":1555394,"h":12886457282,"f":32769},{"p":655361,"g":{"r":0,"d":0,"h":25771359170,"f":1},"n":"OpaqueLength","d":1555394,"h":21476391874,"f":1}],"m":[{"r":65537,"p":[{"n":"binaryForm","p":0},{"n":"offset","p":655361}],"n":"GetBinaryForm","d":1555394,"h":30066326466,"f":32769},{"r":0,"n":"GetOpaque","d":1555394,"h":34361293762,"f":1},{"r":65537,"p":[{"n":"opaque","p":0}],"n":"SetOpaque","d":1555394,"h":38656261058,"f":1}],"l":[{"t":655361,"n":"MaxOpaqueLength","d":1555394,"h":4296522690,"f":33}],"c":[{"p":[{"n":"type","p":703426},{"n":"flags","p":572354},{"n":"opaque","p":0}],"n":".ctor","o":"$ctor$2","d":1555394,"h":8591489986,"f":1}],"h":1555394}; }
            static get $b() { return $.$ssa.System.Security.AccessControl.GenericAce; }
            static get $fullName() { return `System.Security.AccessControl.CustomAce`; }
        });
        
        $asm.$cls("$ssa.System.Security.AccessControl.RawSecurityDescriptor", ($self) => class RawSecurityDescriptor extends $.$ssa.System.Security.AccessControl.GenericSecurityDescriptor
        {
            $ctor$2(/*byte[]*/ binaryForm, /*int*/ offset)
            {
                super.$ctor$1();
                {
                }
                return this;
            }
            $ctor$3(/*System.Security.AccessControl.ControlFlags*/ flags, /*System.Security.Principal.SecurityIdentifier?*/ owner, /*System.Security.Principal.SecurityIdentifier?*/ group, /*System.Security.AccessControl.RawAcl?*/ systemAcl, /*System.Security.AccessControl.RawAcl?*/ discretionaryAcl)
            {
                super.$ctor$1();
                {
                }
                return this;
            }
            $ctor$4(/*string*/ sddlForm)
            {
                super.$ctor$1();
                {
                }
                return this;
            }
            /*System.Security.AccessControl.ControlFlags */ get ControlFlags()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Security.AccessControl.RawAcl? */ get DiscretionaryAcl()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Security.AccessControl.RawAcl? */ set DiscretionaryAcl(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Security.Principal.SecurityIdentifier? */ get Group()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Security.Principal.SecurityIdentifier? */ set Group(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Security.Principal.SecurityIdentifier? */ get Owner()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Security.Principal.SecurityIdentifier? */ set Owner(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*byte */ get ResourceManagerControl()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*byte */ set ResourceManagerControl(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Security.AccessControl.RawAcl? */ get SystemAcl()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Security.AccessControl.RawAcl? */ set SystemAcl(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*void */ SetFlags(/*System.Security.AccessControl.ControlFlags*/ flags)
            {
            }
            static $h = 2800578;
            static $f = 0b10010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":1817538,"p":[{"p":1489858,"g":{"r":0,"d":0,"h":21477637058,"f":32769},"n":"ControlFlags","d":2800578,"h":17182669762,"f":32769},{"p":2735042,"g":{"r":0,"d":0,"h":30067571650,"f":1},"s":{"r":0,"d":0,"h":34362538946,"f":1},"n":"DiscretionaryAcl","d":2800578,"h":25772604354,"f":1},{"p":429438,"g":{"r":0,"d":0,"h":42952473538,"f":32769},"s":{"r":0,"d":0,"h":47247440834,"f":32769},"n":"Group","d":2800578,"h":38657506242,"f":32769},{"p":429438,"g":{"r":0,"d":0,"h":55837375426,"f":32769},"s":{"r":0,"d":0,"h":60132342722,"f":32769},"n":"Owner","d":2800578,"h":51542408130,"f":32769},{"p":393217,"g":{"r":0,"d":0,"h":68722277314,"f":1},"s":{"r":0,"d":0,"h":73017244610,"f":1},"n":"ResourceManagerControl","d":2800578,"h":64427310018,"f":1},{"p":2735042,"g":{"r":0,"d":0,"h":81607179202,"f":1},"s":{"r":0,"d":0,"h":85902146498,"f":1},"n":"SystemAcl","d":2800578,"h":77312211906,"f":1}],"m":[{"r":65537,"p":[{"n":"flags","p":1489858}],"n":"SetFlags","d":2800578,"h":90197113794,"f":1}],"c":[{"p":[{"n":"binaryForm","p":0},{"n":"offset","p":655361}],"n":".ctor","o":"$ctor$2","d":2800578,"h":4297767874,"f":1},{"p":[{"n":"flags","p":1489858},{"n":"owner","p":429438},{"n":"group","p":429438},{"n":"systemAcl","p":2735042},{"n":"discretionaryAcl","p":2735042}],"n":".ctor","o":"$ctor$3","d":2800578,"h":8592735170,"f":1},{"p":[{"n":"sddlForm","p":1310721}],"n":".ctor","o":"$ctor$4","d":2800578,"h":12887702466,"f":1}],"h":2800578}; }
            static get $b() { return $.$ssa.System.Security.AccessControl.GenericSecurityDescriptor; }
            static get $fullName() { return `System.Security.AccessControl.RawSecurityDescriptor`; }
        });
        
        $asm.$cls("$ssa.System.Security.AccessControl.AuthorizationRuleCollection", ($self) => class AuthorizationRuleCollection extends $.$scn.System.Collections.ReadOnlyCollectionBase
        {
            $ctor$2()
            {
                super.$ctor$1();
                {
                }
                return this;
            }
            /*System.Security.AccessControl.AuthorizationRule?*/ get_Item(/*int*/ index)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*void */ AddRule(/*System.Security.AccessControl.AuthorizationRule?*/ rule)
            {
            }
            /*void */ CopyTo(/*System.Security.AccessControl.AuthorizationRule[]*/ rules, /*int*/ index)
            {
            }
            static $h = 1031106;
            static $f = 0b10010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":589859,"p":[{"p":965570,"i":[{"n":"index","p":655361}],"g":{"r":0,"d":0,"h":12885932994,"f":1},"n":"Item","o":"@$2","d":1031106,"h":8590965698,"f":1}],"m":[{"r":65537,"p":[{"n":"rule","p":965570}],"n":"AddRule","d":1031106,"h":17180900290,"f":1},{"r":65537,"p":[{"n":"rules","p":0},{"n":"index","p":655361}],"n":"CopyTo","d":1031106,"h":21475867586,"f":1}],"c":[{"n":".ctor","o":"$ctor$2","d":1031106,"h":4295998402,"f":1}],"i":[31391745,31653889],"h":1031106}; }
            static get $b() { return $.$scn.System.Collections.ReadOnlyCollectionBase; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.Collections.ICollection, $.$spc.System.Collections.IEnumerable ]; }
            static get $fullName() { return `System.Security.AccessControl.AuthorizationRuleCollection`; }
        });
        
        $asm.$cls("$ssa.System.Security.AccessControl.RawAcl", ($self) => class RawAcl extends $.$ssa.System.Security.AccessControl.GenericAcl
        {
            $ctor$2(/*byte*/ revision, /*int*/ capacity)
            {
                super.$ctor$1();
                {
                }
                return this;
            }
            $ctor$3(/*byte[]*/ binaryForm, /*int*/ offset)
            {
                super.$ctor$1();
                {
                }
                return this;
            }
            /*int */ get BinaryLength()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ get Count()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Security.AccessControl.GenericAce*/ get_Item(/*int*/ index)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*void*/ set_Item(/*int*/ index, /*System.Security.AccessControl.GenericAce*/ value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*byte */ get Revision()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*void */ GetBinaryForm(/*byte[]*/ binaryForm, /*int*/ offset)
            {
            }
            /*void */ InsertAce(/*int*/ index, /*System.Security.AccessControl.GenericAce*/ ace)
            {
            }
            /*void */ RemoveAce(/*int*/ index)
            {
            }
            static $h = 2735042;
            static $f = 0b10010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":1752002,"p":[{"p":655361,"g":{"r":0,"d":0,"h":17182604226,"f":32769},"n":"BinaryLength","d":2735042,"h":12887636930,"f":32769},{"p":655361,"g":{"r":0,"d":0,"h":25772538818,"f":32769},"n":"Count","d":2735042,"h":21477571522,"f":32769},{"p":1686466,"i":[{"n":"index","p":655361}],"g":{"r":0,"d":0,"h":34362473410,"f":32769},"s":{"r":0,"d":0,"h":38657440706,"f":32769},"n":"Item","o":"@$2","d":2735042,"h":30067506114,"f":32769},{"p":393217,"g":{"r":0,"d":0,"h":47247375298,"f":32769},"n":"Revision","d":2735042,"h":42952408002,"f":32769}],"m":[{"r":65537,"p":[{"n":"binaryForm","p":0},{"n":"offset","p":655361}],"n":"GetBinaryForm","d":2735042,"h":51542342594,"f":32769},{"r":65537,"p":[{"n":"index","p":655361},{"n":"ace","p":1686466}],"n":"InsertAce","d":2735042,"h":55837309890,"f":1},{"r":65537,"p":[{"n":"index","p":655361}],"n":"RemoveAce","d":2735042,"h":60132277186,"f":1}],"c":[{"p":[{"n":"revision","p":393217},{"n":"capacity","p":655361}],"n":".ctor","o":"$ctor$2","d":2735042,"h":4297702338,"f":1},{"p":[{"n":"binaryForm","p":0},{"n":"offset","p":655361}],"n":".ctor","o":"$ctor$3","d":2735042,"h":8592669634,"f":1}],"i":[31391745,31653889],"h":2735042}; }
            static get $b() { return $.$ssa.System.Security.AccessControl.GenericAcl; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.Collections.ICollection, $.$spc.System.Collections.IEnumerable ]; }
            static get $fullName() { return `System.Security.AccessControl.RawAcl`; }
        });
        
        $asm.$cls("$ssa.System.Security.AccessControl.AccessRule<>", (T) => $asm.$gt("$ssa.System.Security.AccessControl.AccessRule<>", [T], ($self) => class AccessRule$$ extends $.$ssa.System.Security.AccessControl.AccessRule
        {
            $ctor$3(/*System.Security.Principal.IdentityReference*/ identity, /*T*/ rights, /*System.Security.AccessControl.AccessControlType*/ type)
            {
                super.$ctor$2(null, 0, false, 0, 0, 0);
                {
                }
                return this;
            }
            $ctor$4(/*System.Security.Principal.IdentityReference*/ identity, /*T*/ rights, /*System.Security.AccessControl.InheritanceFlags*/ inheritanceFlags, /*System.Security.AccessControl.PropagationFlags*/ propagationFlags, /*System.Security.AccessControl.AccessControlType*/ type)
            {
                super.$ctor$2(null, 0, false, 0, 0, 0);
                {
                }
                return this;
            }
            $ctor$5(/*string*/ identity, /*T*/ rights, /*System.Security.AccessControl.AccessControlType*/ type)
            {
                super.$ctor$2(null, 0, false, 0, 0, 0);
                {
                }
                return this;
            }
            $ctor$6(/*string*/ identity, /*T*/ rights, /*System.Security.AccessControl.InheritanceFlags*/ inheritanceFlags, /*System.Security.AccessControl.PropagationFlags*/ propagationFlags, /*System.Security.AccessControl.AccessControlType*/ type)
            {
                super.$ctor$2(null, 0, false, 0, 0, 0);
                {
                }
                return this;
            }
            /*T */ get Rights()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static $h = 441282;
            static $g = 1;
            static $f = 0b1010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":375746,"p":[{"p":T?.$h??1507328,"g":{"r":0,"d":0,"h":Number(BigInt(this.$h)|0x600000000n),"f":1},"n":"Rights","d":this.$h,"h":Number(BigInt(this.$h)|0x500000000n),"f":1}],"c":[{"p":[{"n":"identity","p":232830},{"n":"rights","p":T?.$h??1507328},{"n":"type","p":310210}],"n":".ctor","o":"$ctor$3","d":this.$h,"h":Number(BigInt(this.$h)|0x100000000n),"f":1},{"p":[{"n":"identity","p":232830},{"n":"rights","p":T?.$h??1507328},{"n":"inheritanceFlags","p":1883074},{"n":"propagationFlags","p":2603970},{"n":"type","p":310210}],"n":".ctor","o":"$ctor$4","d":this.$h,"h":Number(BigInt(this.$h)|0x200000000n),"f":1},{"p":[{"n":"identity","p":1310721},{"n":"rights","p":T?.$h??1507328},{"n":"type","p":310210}],"n":".ctor","o":"$ctor$5","d":this.$h,"h":Number(BigInt(this.$h)|0x300000000n),"f":1},{"p":[{"n":"identity","p":1310721},{"n":"rights","p":T?.$h??1507328},{"n":"inheritanceFlags","p":1883074},{"n":"propagationFlags","p":2603970},{"n":"type","p":310210}],"n":".ctor","o":"$ctor$6","d":this.$h,"h":Number(BigInt(this.$h)|0x400000000n),"f":1}],"g":[T?.$h??1507328],"s":[{"n":"T","f":2}],"r":1,"h":this.$h}; }
            static get $b() { return $.$ssa.System.Security.AccessControl.AccessRule; }
            static get $fullName() { return `System.Security.AccessControl.AccessRule<${T?.$fullName}>`; }
        }));
        
        $asm.$cls("$ssa.System.Security.AccessControl.AuditRule<>", (T) => $asm.$gt("$ssa.System.Security.AccessControl.AuditRule<>", [T], ($self) => class AuditRule$$ extends $.$ssa.System.Security.AccessControl.AuditRule
        {
            $ctor$3(/*System.Security.Principal.IdentityReference*/ identity, /*T*/ rights, /*System.Security.AccessControl.AuditFlags*/ flags)
            {
                super.$ctor$2(null, 0, false, 0, 0, 0);
                {
                }
                return this;
            }
            $ctor$4(/*System.Security.Principal.IdentityReference*/ identity, /*T*/ rights, /*System.Security.AccessControl.InheritanceFlags*/ inheritanceFlags, /*System.Security.AccessControl.PropagationFlags*/ propagationFlags, /*System.Security.AccessControl.AuditFlags*/ flags)
            {
                super.$ctor$2(null, 0, false, 0, 0, 0);
                {
                }
                return this;
            }
            $ctor$5(/*string*/ identity, /*T*/ rights, /*System.Security.AccessControl.AuditFlags*/ flags)
            {
                super.$ctor$2(null, 0, false, 0, 0, 0);
                {
                }
                return this;
            }
            $ctor$6(/*string*/ identity, /*T*/ rights, /*System.Security.AccessControl.InheritanceFlags*/ inheritanceFlags, /*System.Security.AccessControl.PropagationFlags*/ propagationFlags, /*System.Security.AccessControl.AuditFlags*/ flags)
            {
                super.$ctor$2(null, 0, false, 0, 0, 0);
                {
                }
                return this;
            }
            /*T */ get Rights()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static $h = 900034;
            static $g = 1;
            static $f = 0b1010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":834498,"p":[{"p":T?.$h??1507328,"g":{"r":0,"d":0,"h":Number(BigInt(this.$h)|0x600000000n),"f":1},"n":"Rights","d":this.$h,"h":Number(BigInt(this.$h)|0x500000000n),"f":1}],"c":[{"p":[{"n":"identity","p":232830},{"n":"rights","p":T?.$h??1507328},{"n":"flags","p":768962}],"n":".ctor","o":"$ctor$3","d":this.$h,"h":Number(BigInt(this.$h)|0x100000000n),"f":1},{"p":[{"n":"identity","p":232830},{"n":"rights","p":T?.$h??1507328},{"n":"inheritanceFlags","p":1883074},{"n":"propagationFlags","p":2603970},{"n":"flags","p":768962}],"n":".ctor","o":"$ctor$4","d":this.$h,"h":Number(BigInt(this.$h)|0x200000000n),"f":1},{"p":[{"n":"identity","p":1310721},{"n":"rights","p":T?.$h??1507328},{"n":"flags","p":768962}],"n":".ctor","o":"$ctor$5","d":this.$h,"h":Number(BigInt(this.$h)|0x300000000n),"f":1},{"p":[{"n":"identity","p":1310721},{"n":"rights","p":T?.$h??1507328},{"n":"inheritanceFlags","p":1883074},{"n":"propagationFlags","p":2603970},{"n":"flags","p":768962}],"n":".ctor","o":"$ctor$6","d":this.$h,"h":Number(BigInt(this.$h)|0x400000000n),"f":1}],"g":[T?.$h??1507328],"s":[{"n":"T","f":2}],"r":1,"h":this.$h}; }
            static get $b() { return $.$ssa.System.Security.AccessControl.AuditRule; }
            static get $fullName() { return `System.Security.AccessControl.AuditRule<${T?.$fullName}>`; }
        }));
        
        $asm.$cls("$ssa.System.Security.AccessControl.CompoundAce", ($self) => class CompoundAce extends $.$ssa.System.Security.AccessControl.KnownAce
        {
            $ctor$3(/*System.Security.AccessControl.AceFlags*/ flags, /*int*/ accessMask, /*System.Security.AccessControl.CompoundAceType*/ compoundAceType, /*System.Security.Principal.SecurityIdentifier*/ sid)
            {
                super.$ctor$2();
                {
                }
                return this;
            }
            /*int */ get BinaryLength()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Security.AccessControl.CompoundAceType */ get CompoundAceType()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Security.AccessControl.CompoundAceType */ set CompoundAceType(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*void */ GetBinaryForm(/*byte[]*/ binaryForm, /*int*/ offset)
            {
            }
            static $h = 1358786;
            static $f = 0b10010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":1948610,"p":[{"p":655361,"g":{"r":0,"d":0,"h":12886260674,"f":32769},"n":"BinaryLength","d":1358786,"h":8591293378,"f":32769},{"p":1424322,"g":{"r":0,"d":0,"h":21476195266,"f":1},"s":{"r":0,"d":0,"h":25771162562,"f":1},"n":"CompoundAceType","d":1358786,"h":17181227970,"f":1}],"m":[{"r":65537,"p":[{"n":"binaryForm","p":0},{"n":"offset","p":655361}],"n":"GetBinaryForm","d":1358786,"h":30066129858,"f":32769}],"c":[{"p":[{"n":"flags","p":572354},{"n":"accessMask","p":655361},{"n":"compoundAceType","p":1424322},{"n":"sid","p":429438}],"n":".ctor","o":"$ctor$3","d":1358786,"h":4296326082,"f":1}],"h":1358786}; }
            static get $b() { return $.$ssa.System.Security.AccessControl.KnownAce; }
            static get $fullName() { return `System.Security.AccessControl.CompoundAce`; }
        });
        
        $asm.$cls("$ssa.System.Security.AccessControl.DiscretionaryAcl", ($self) => class DiscretionaryAcl extends $.$ssa.System.Security.AccessControl.CommonAcl
        {
            $ctor$3(/*bool*/ isContainer, /*bool*/ isDS, /*byte*/ revision, /*int*/ capacity)
            {
                super.$ctor$2();
                {
                }
                return this;
            }
            $ctor$4(/*bool*/ isContainer, /*bool*/ isDS, /*int*/ capacity)
            {
                super.$ctor$2();
                {
                }
                return this;
            }
            $ctor$5(/*bool*/ isContainer, /*bool*/ isDS, /*System.Security.AccessControl.RawAcl?*/ rawAcl)
            {
                super.$ctor$2();
                {
                }
                return this;
            }
            /*void */ AddAccess(/*System.Security.AccessControl.AccessControlType*/ accessType, /*System.Security.Principal.SecurityIdentifier*/ sid, /*int*/ accessMask, /*System.Security.AccessControl.InheritanceFlags*/ inheritanceFlags, /*System.Security.AccessControl.PropagationFlags*/ propagationFlags)
            {
            }
            /*void */ AddAccess$1(/*System.Security.AccessControl.AccessControlType*/ accessType, /*System.Security.Principal.SecurityIdentifier*/ sid, /*int*/ accessMask, /*System.Security.AccessControl.InheritanceFlags*/ inheritanceFlags, /*System.Security.AccessControl.PropagationFlags*/ propagationFlags, /*System.Security.AccessControl.ObjectAceFlags*/ objectFlags, /*System.Guid*/ objectType, /*System.Guid*/ inheritedObjectType)
            {
            }
            /*void */ AddAccess$2(/*System.Security.AccessControl.AccessControlType*/ accessType, /*System.Security.Principal.SecurityIdentifier*/ sid, /*System.Security.AccessControl.ObjectAccessRule*/ rule)
            {
            }
            /*bool */ RemoveAccess(/*System.Security.AccessControl.AccessControlType*/ accessType, /*System.Security.Principal.SecurityIdentifier*/ sid, /*int*/ accessMask, /*System.Security.AccessControl.InheritanceFlags*/ inheritanceFlags, /*System.Security.AccessControl.PropagationFlags*/ propagationFlags)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ RemoveAccess$1(/*System.Security.AccessControl.AccessControlType*/ accessType, /*System.Security.Principal.SecurityIdentifier*/ sid, /*int*/ accessMask, /*System.Security.AccessControl.InheritanceFlags*/ inheritanceFlags, /*System.Security.AccessControl.PropagationFlags*/ propagationFlags, /*System.Security.AccessControl.ObjectAceFlags*/ objectFlags, /*System.Guid*/ objectType, /*System.Guid*/ inheritedObjectType)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ RemoveAccess$2(/*System.Security.AccessControl.AccessControlType*/ accessType, /*System.Security.Principal.SecurityIdentifier*/ sid, /*System.Security.AccessControl.ObjectAccessRule*/ rule)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*void */ RemoveAccessSpecific(/*System.Security.AccessControl.AccessControlType*/ accessType, /*System.Security.Principal.SecurityIdentifier*/ sid, /*int*/ accessMask, /*System.Security.AccessControl.InheritanceFlags*/ inheritanceFlags, /*System.Security.AccessControl.PropagationFlags*/ propagationFlags)
            {
            }
            /*void */ RemoveAccessSpecific$1(/*System.Security.AccessControl.AccessControlType*/ accessType, /*System.Security.Principal.SecurityIdentifier*/ sid, /*int*/ accessMask, /*System.Security.AccessControl.InheritanceFlags*/ inheritanceFlags, /*System.Security.AccessControl.PropagationFlags*/ propagationFlags, /*System.Security.AccessControl.ObjectAceFlags*/ objectFlags, /*System.Guid*/ objectType, /*System.Guid*/ inheritedObjectType)
            {
            }
            /*void */ RemoveAccessSpecific$2(/*System.Security.AccessControl.AccessControlType*/ accessType, /*System.Security.Principal.SecurityIdentifier*/ sid, /*System.Security.AccessControl.ObjectAccessRule*/ rule)
            {
            }
            /*void */ SetAccess(/*System.Security.AccessControl.AccessControlType*/ accessType, /*System.Security.Principal.SecurityIdentifier*/ sid, /*int*/ accessMask, /*System.Security.AccessControl.InheritanceFlags*/ inheritanceFlags, /*System.Security.AccessControl.PropagationFlags*/ propagationFlags)
            {
            }
            /*void */ SetAccess$1(/*System.Security.AccessControl.AccessControlType*/ accessType, /*System.Security.Principal.SecurityIdentifier*/ sid, /*int*/ accessMask, /*System.Security.AccessControl.InheritanceFlags*/ inheritanceFlags, /*System.Security.AccessControl.PropagationFlags*/ propagationFlags, /*System.Security.AccessControl.ObjectAceFlags*/ objectFlags, /*System.Guid*/ objectType, /*System.Guid*/ inheritedObjectType)
            {
            }
            /*void */ SetAccess$2(/*System.Security.AccessControl.AccessControlType*/ accessType, /*System.Security.Principal.SecurityIdentifier*/ sid, /*System.Security.AccessControl.ObjectAccessRule*/ rule)
            {
            }
            static $h = 1620930;
            static $f = 0b10010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":1162178,"m":[{"r":65537,"p":[{"n":"accessType","p":310210},{"n":"sid","p":429438},{"n":"accessMask","p":655361},{"n":"inheritanceFlags","p":1883074},{"n":"propagationFlags","p":2603970}],"n":"AddAccess","d":1620930,"h":17181490114,"f":1},{"r":65537,"p":[{"n":"accessType","p":310210},{"n":"sid","p":429438},{"n":"accessMask","p":655361},{"n":"inheritanceFlags","p":1883074},{"n":"propagationFlags","p":2603970},{"n":"objectFlags","p":2276290},{"n":"objectType","p":56229889},{"n":"inheritedObjectType","p":56229889}],"n":"AddAccess","o":"@$1","d":1620930,"h":21476457410,"f":1},{"r":65537,"p":[{"n":"accessType","p":310210},{"n":"sid","p":429438},{"n":"rule","p":2145218}],"n":"AddAccess","o":"@$2","d":1620930,"h":25771424706,"f":1},{"r":262145,"p":[{"n":"accessType","p":310210},{"n":"sid","p":429438},{"n":"accessMask","p":655361},{"n":"inheritanceFlags","p":1883074},{"n":"propagationFlags","p":2603970}],"n":"RemoveAccess","d":1620930,"h":30066392002,"f":1},{"r":262145,"p":[{"n":"accessType","p":310210},{"n":"sid","p":429438},{"n":"accessMask","p":655361},{"n":"inheritanceFlags","p":1883074},{"n":"propagationFlags","p":2603970},{"n":"objectFlags","p":2276290},{"n":"objectType","p":56229889},{"n":"inheritedObjectType","p":56229889}],"n":"RemoveAccess","o":"@$1","d":1620930,"h":34361359298,"f":1},{"r":262145,"p":[{"n":"accessType","p":310210},{"n":"sid","p":429438},{"n":"rule","p":2145218}],"n":"RemoveAccess","o":"@$2","d":1620930,"h":38656326594,"f":1},{"r":65537,"p":[{"n":"accessType","p":310210},{"n":"sid","p":429438},{"n":"accessMask","p":655361},{"n":"inheritanceFlags","p":1883074},{"n":"propagationFlags","p":2603970}],"n":"RemoveAccessSpecific","d":1620930,"h":42951293890,"f":1},{"r":65537,"p":[{"n":"accessType","p":310210},{"n":"sid","p":429438},{"n":"accessMask","p":655361},{"n":"inheritanceFlags","p":1883074},{"n":"propagationFlags","p":2603970},{"n":"objectFlags","p":2276290},{"n":"objectType","p":56229889},{"n":"inheritedObjectType","p":56229889}],"n":"RemoveAccessSpecific","o":"@$1","d":1620930,"h":47246261186,"f":1},{"r":65537,"p":[{"n":"accessType","p":310210},{"n":"sid","p":429438},{"n":"rule","p":2145218}],"n":"RemoveAccessSpecific","o":"@$2","d":1620930,"h":51541228482,"f":1},{"r":65537,"p":[{"n":"accessType","p":310210},{"n":"sid","p":429438},{"n":"accessMask","p":655361},{"n":"inheritanceFlags","p":1883074},{"n":"propagationFlags","p":2603970}],"n":"SetAccess","d":1620930,"h":55836195778,"f":1},{"r":65537,"p":[{"n":"accessType","p":310210},{"n":"sid","p":429438},{"n":"accessMask","p":655361},{"n":"inheritanceFlags","p":1883074},{"n":"propagationFlags","p":2603970},{"n":"objectFlags","p":2276290},{"n":"objectType","p":56229889},{"n":"inheritedObjectType","p":56229889}],"n":"SetAccess","o":"@$1","d":1620930,"h":60131163074,"f":1},{"r":65537,"p":[{"n":"accessType","p":310210},{"n":"sid","p":429438},{"n":"rule","p":2145218}],"n":"SetAccess","o":"@$2","d":1620930,"h":64426130370,"f":1}],"c":[{"p":[{"n":"isContainer","p":262145},{"n":"isDS","p":262145},{"n":"revision","p":393217},{"n":"capacity","p":655361}],"n":".ctor","o":"$ctor$3","d":1620930,"h":4296588226,"f":1},{"p":[{"n":"isContainer","p":262145},{"n":"isDS","p":262145},{"n":"capacity","p":655361}],"n":".ctor","o":"$ctor$4","d":1620930,"h":8591555522,"f":1},{"p":[{"n":"isContainer","p":262145},{"n":"isDS","p":262145},{"n":"rawAcl","p":2735042}],"n":".ctor","o":"$ctor$5","d":1620930,"h":12886522818,"f":1}],"i":[31391745,31653889],"h":1620930}; }
            static get $b() { return $.$ssa.System.Security.AccessControl.CommonAcl; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.Collections.ICollection, $.$spc.System.Collections.IEnumerable ]; }
            static get $fullName() { return `System.Security.AccessControl.DiscretionaryAcl`; }
        });
        
        $asm.$cls("$ssa.System.Security.AccessControl.SystemAcl", ($self) => class SystemAcl extends $.$ssa.System.Security.AccessControl.CommonAcl
        {
            $ctor$3(/*bool*/ isContainer, /*bool*/ isDS, /*byte*/ revision, /*int*/ capacity)
            {
                super.$ctor$2();
                {
                }
                return this;
            }
            $ctor$4(/*bool*/ isContainer, /*bool*/ isDS, /*int*/ capacity)
            {
                super.$ctor$2();
                {
                }
                return this;
            }
            $ctor$5(/*bool*/ isContainer, /*bool*/ isDS, /*System.Security.AccessControl.RawAcl*/ rawAcl)
            {
                super.$ctor$2();
                {
                }
                return this;
            }
            /*void */ AddAudit(/*System.Security.AccessControl.AuditFlags*/ auditFlags, /*System.Security.Principal.SecurityIdentifier*/ sid, /*int*/ accessMask, /*System.Security.AccessControl.InheritanceFlags*/ inheritanceFlags, /*System.Security.AccessControl.PropagationFlags*/ propagationFlags)
            {
            }
            /*void */ AddAudit$1(/*System.Security.AccessControl.AuditFlags*/ auditFlags, /*System.Security.Principal.SecurityIdentifier*/ sid, /*int*/ accessMask, /*System.Security.AccessControl.InheritanceFlags*/ inheritanceFlags, /*System.Security.AccessControl.PropagationFlags*/ propagationFlags, /*System.Security.AccessControl.ObjectAceFlags*/ objectFlags, /*System.Guid*/ objectType, /*System.Guid*/ inheritedObjectType)
            {
            }
            /*void */ AddAudit$2(/*System.Security.Principal.SecurityIdentifier*/ sid, /*System.Security.AccessControl.ObjectAuditRule*/ rule)
            {
            }
            /*bool */ RemoveAudit(/*System.Security.AccessControl.AuditFlags*/ auditFlags, /*System.Security.Principal.SecurityIdentifier*/ sid, /*int*/ accessMask, /*System.Security.AccessControl.InheritanceFlags*/ inheritanceFlags, /*System.Security.AccessControl.PropagationFlags*/ propagationFlags)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ RemoveAudit$1(/*System.Security.AccessControl.AuditFlags*/ auditFlags, /*System.Security.Principal.SecurityIdentifier*/ sid, /*int*/ accessMask, /*System.Security.AccessControl.InheritanceFlags*/ inheritanceFlags, /*System.Security.AccessControl.PropagationFlags*/ propagationFlags, /*System.Security.AccessControl.ObjectAceFlags*/ objectFlags, /*System.Guid*/ objectType, /*System.Guid*/ inheritedObjectType)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ RemoveAudit$2(/*System.Security.Principal.SecurityIdentifier*/ sid, /*System.Security.AccessControl.ObjectAuditRule*/ rule)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*void */ RemoveAuditSpecific(/*System.Security.AccessControl.AuditFlags*/ auditFlags, /*System.Security.Principal.SecurityIdentifier*/ sid, /*int*/ accessMask, /*System.Security.AccessControl.InheritanceFlags*/ inheritanceFlags, /*System.Security.AccessControl.PropagationFlags*/ propagationFlags)
            {
            }
            /*void */ RemoveAuditSpecific$1(/*System.Security.AccessControl.AuditFlags*/ auditFlags, /*System.Security.Principal.SecurityIdentifier*/ sid, /*int*/ accessMask, /*System.Security.AccessControl.InheritanceFlags*/ inheritanceFlags, /*System.Security.AccessControl.PropagationFlags*/ propagationFlags, /*System.Security.AccessControl.ObjectAceFlags*/ objectFlags, /*System.Guid*/ objectType, /*System.Guid*/ inheritedObjectType)
            {
            }
            /*void */ RemoveAuditSpecific$2(/*System.Security.Principal.SecurityIdentifier*/ sid, /*System.Security.AccessControl.ObjectAuditRule*/ rule)
            {
            }
            /*void */ SetAudit(/*System.Security.AccessControl.AuditFlags*/ auditFlags, /*System.Security.Principal.SecurityIdentifier*/ sid, /*int*/ accessMask, /*System.Security.AccessControl.InheritanceFlags*/ inheritanceFlags, /*System.Security.AccessControl.PropagationFlags*/ propagationFlags)
            {
            }
            /*void */ SetAudit$1(/*System.Security.AccessControl.AuditFlags*/ auditFlags, /*System.Security.Principal.SecurityIdentifier*/ sid, /*int*/ accessMask, /*System.Security.AccessControl.InheritanceFlags*/ inheritanceFlags, /*System.Security.AccessControl.PropagationFlags*/ propagationFlags, /*System.Security.AccessControl.ObjectAceFlags*/ objectFlags, /*System.Guid*/ objectType, /*System.Guid*/ inheritedObjectType)
            {
            }
            /*void */ SetAudit$2(/*System.Security.Principal.SecurityIdentifier*/ sid, /*System.Security.AccessControl.ObjectAuditRule*/ rule)
            {
            }
            static $h = 2997186;
            static $f = 0b10010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":1162178,"m":[{"r":65537,"p":[{"n":"auditFlags","p":768962},{"n":"sid","p":429438},{"n":"accessMask","p":655361},{"n":"inheritanceFlags","p":1883074},{"n":"propagationFlags","p":2603970}],"n":"AddAudit","d":2997186,"h":17182866370,"f":1},{"r":65537,"p":[{"n":"auditFlags","p":768962},{"n":"sid","p":429438},{"n":"accessMask","p":655361},{"n":"inheritanceFlags","p":1883074},{"n":"propagationFlags","p":2603970},{"n":"objectFlags","p":2276290},{"n":"objectType","p":56229889},{"n":"inheritedObjectType","p":56229889}],"n":"AddAudit","o":"@$1","d":2997186,"h":21477833666,"f":1},{"r":65537,"p":[{"n":"sid","p":429438},{"n":"rule","p":2341826}],"n":"AddAudit","o":"@$2","d":2997186,"h":25772800962,"f":1},{"r":262145,"p":[{"n":"auditFlags","p":768962},{"n":"sid","p":429438},{"n":"accessMask","p":655361},{"n":"inheritanceFlags","p":1883074},{"n":"propagationFlags","p":2603970}],"n":"RemoveAudit","d":2997186,"h":30067768258,"f":1},{"r":262145,"p":[{"n":"auditFlags","p":768962},{"n":"sid","p":429438},{"n":"accessMask","p":655361},{"n":"inheritanceFlags","p":1883074},{"n":"propagationFlags","p":2603970},{"n":"objectFlags","p":2276290},{"n":"objectType","p":56229889},{"n":"inheritedObjectType","p":56229889}],"n":"RemoveAudit","o":"@$1","d":2997186,"h":34362735554,"f":1},{"r":262145,"p":[{"n":"sid","p":429438},{"n":"rule","p":2341826}],"n":"RemoveAudit","o":"@$2","d":2997186,"h":38657702850,"f":1},{"r":65537,"p":[{"n":"auditFlags","p":768962},{"n":"sid","p":429438},{"n":"accessMask","p":655361},{"n":"inheritanceFlags","p":1883074},{"n":"propagationFlags","p":2603970}],"n":"RemoveAuditSpecific","d":2997186,"h":42952670146,"f":1},{"r":65537,"p":[{"n":"auditFlags","p":768962},{"n":"sid","p":429438},{"n":"accessMask","p":655361},{"n":"inheritanceFlags","p":1883074},{"n":"propagationFlags","p":2603970},{"n":"objectFlags","p":2276290},{"n":"objectType","p":56229889},{"n":"inheritedObjectType","p":56229889}],"n":"RemoveAuditSpecific","o":"@$1","d":2997186,"h":47247637442,"f":1},{"r":65537,"p":[{"n":"sid","p":429438},{"n":"rule","p":2341826}],"n":"RemoveAuditSpecific","o":"@$2","d":2997186,"h":51542604738,"f":1},{"r":65537,"p":[{"n":"auditFlags","p":768962},{"n":"sid","p":429438},{"n":"accessMask","p":655361},{"n":"inheritanceFlags","p":1883074},{"n":"propagationFlags","p":2603970}],"n":"SetAudit","d":2997186,"h":55837572034,"f":1},{"r":65537,"p":[{"n":"auditFlags","p":768962},{"n":"sid","p":429438},{"n":"accessMask","p":655361},{"n":"inheritanceFlags","p":1883074},{"n":"propagationFlags","p":2603970},{"n":"objectFlags","p":2276290},{"n":"objectType","p":56229889},{"n":"inheritedObjectType","p":56229889}],"n":"SetAudit","o":"@$1","d":2997186,"h":60132539330,"f":1},{"r":65537,"p":[{"n":"sid","p":429438},{"n":"rule","p":2341826}],"n":"SetAudit","o":"@$2","d":2997186,"h":64427506626,"f":1}],"c":[{"p":[{"n":"isContainer","p":262145},{"n":"isDS","p":262145},{"n":"revision","p":393217},{"n":"capacity","p":655361}],"n":".ctor","o":"$ctor$3","d":2997186,"h":4297964482,"f":1},{"p":[{"n":"isContainer","p":262145},{"n":"isDS","p":262145},{"n":"capacity","p":655361}],"n":".ctor","o":"$ctor$4","d":2997186,"h":8592931778,"f":1},{"p":[{"n":"isContainer","p":262145},{"n":"isDS","p":262145},{"n":"rawAcl","p":2735042}],"n":".ctor","o":"$ctor$5","d":2997186,"h":12887899074,"f":1}],"i":[31391745,31653889],"h":2997186}; }
            static get $b() { return $.$ssa.System.Security.AccessControl.CommonAcl; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.Collections.ICollection, $.$spc.System.Collections.IEnumerable ]; }
            static get $fullName() { return `System.Security.AccessControl.SystemAcl`; }
        });
        
        $asm.$str("$ssa.System.Security.AccessControl.AccessControlActions", ($self) => class AccessControlActions extends $.$spc.System.Enum
        {
            static None = 0;
            static View = 1;
            static Change = 2;
            static $map;
            static get Map()
            {
                return this.$map ??= 
                {
                    "None": 0n,
                    "View": 1n,
                    "Change": 2n
                };
            }
            static $h = 113602;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static get $eut() { return $.$spc.System.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {"b":1048577,"u":655361,"l":[{"t":113602,"n":"None","d":113602,"h":4295080898,"f":33},{"t":113602,"n":"View","d":113602,"h":8590048194,"f":33},{"t":113602,"n":"Change","d":113602,"h":12885015490,"f":33}],"c":[{"n":".ctor","o":"$ctor$3","d":113602,"h":17179982786,"f":1}],"i":[57278465,63832065,57737217,57409537],"h":113602,"a":[{"t":47710209,"c":4342677505}]}; }
            static get $b() { return $.$spc.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IComparable, $.$spc.System.ISpanFormattable, $.$spc.System.IFormattable, $.$spc.System.IConvertible ]; }
            static get $fullName() { return `System.Security.AccessControl.AccessControlActions`; }
        });
        
        $asm.$str("$ssa.System.Security.AccessControl.AccessControlModification", ($self) => class AccessControlModification extends $.$spc.System.Enum
        {
            static Add = 0;
            static Set = 1;
            static Reset = 2;
            static Remove = 3;
            static RemoveAll = 4;
            static RemoveSpecific = 5;
            static $map;
            static get Map()
            {
                return this.$map ??= 
                {
                    "Add": 0n,
                    "Set": 1n,
                    "Reset": 2n,
                    "Remove": 3n,
                    "RemoveAll": 4n,
                    "RemoveSpecific": 5n
                };
            }
            static $h = 179138;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static get $eut() { return $.$spc.System.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {"b":1048577,"u":655361,"l":[{"t":179138,"n":"Add","d":179138,"h":4295146434,"f":33},{"t":179138,"n":"Set","d":179138,"h":8590113730,"f":33},{"t":179138,"n":"Reset","d":179138,"h":12885081026,"f":33},{"t":179138,"n":"Remove","d":179138,"h":17180048322,"f":33},{"t":179138,"n":"RemoveAll","d":179138,"h":21475015618,"f":33},{"t":179138,"n":"RemoveSpecific","d":179138,"h":25769982914,"f":33}],"c":[{"n":".ctor","o":"$ctor$3","d":179138,"h":30064950210,"f":1}],"i":[57278465,63832065,57737217,57409537],"h":179138}; }
            static get $b() { return $.$spc.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IComparable, $.$spc.System.ISpanFormattable, $.$spc.System.IFormattable, $.$spc.System.IConvertible ]; }
            static get $fullName() { return `System.Security.AccessControl.AccessControlModification`; }
        });
        
        $asm.$str("$ssa.System.Security.AccessControl.AccessControlSections", ($self) => class AccessControlSections extends $.$spc.System.Enum
        {
            static None = 0;
            static Audit = 1;
            static Access = 2;
            static Owner = 4;
            static Group = 8;
            static All = 15;
            static $map;
            static get Map()
            {
                return this.$map ??= 
                {
                    "None": 0n,
                    "Audit": 1n,
                    "Access": 2n,
                    "Owner": 4n,
                    "Group": 8n,
                    "All": 15n
                };
            }
            static $h = 244674;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static get $eut() { return $.$spc.System.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {"b":1048577,"u":655361,"l":[{"t":244674,"n":"None","d":244674,"h":4295211970,"f":33},{"t":244674,"n":"Audit","d":244674,"h":8590179266,"f":33},{"t":244674,"n":"Access","d":244674,"h":12885146562,"f":33},{"t":244674,"n":"Owner","d":244674,"h":17180113858,"f":33},{"t":244674,"n":"Group","d":244674,"h":21475081154,"f":33},{"t":244674,"n":"All","d":244674,"h":25770048450,"f":33}],"c":[{"n":".ctor","o":"$ctor$3","d":244674,"h":30065015746,"f":1}],"i":[57278465,63832065,57737217,57409537],"h":244674,"a":[{"t":47710209,"c":4342677505}]}; }
            static get $b() { return $.$spc.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IComparable, $.$spc.System.ISpanFormattable, $.$spc.System.IFormattable, $.$spc.System.IConvertible ]; }
            static get $fullName() { return `System.Security.AccessControl.AccessControlSections`; }
        });
        
        $asm.$str("$ssa.System.Security.AccessControl.AccessControlType", ($self) => class AccessControlType extends $.$spc.System.Enum
        {
            static Allow = 0;
            static Deny = 1;
            static $map;
            static get Map()
            {
                return this.$map ??= 
                {
                    "Allow": 0n,
                    "Deny": 1n
                };
            }
            static $h = 310210;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static get $eut() { return $.$spc.System.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {"b":1048577,"u":655361,"l":[{"t":310210,"n":"Allow","d":310210,"h":4295277506,"f":33},{"t":310210,"n":"Deny","d":310210,"h":8590244802,"f":33}],"c":[{"n":".ctor","o":"$ctor$3","d":310210,"h":12885212098,"f":1}],"i":[57278465,63832065,57737217,57409537],"h":310210}; }
            static get $b() { return $.$spc.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IComparable, $.$spc.System.ISpanFormattable, $.$spc.System.IFormattable, $.$spc.System.IConvertible ]; }
            static get $fullName() { return `System.Security.AccessControl.AccessControlType`; }
        });
        
        $asm.$str("$ssa.System.Security.AccessControl.AceFlags", ($self) => class AceFlags extends $.$spc.System.Enum
        {
            static None = 0;
            static ObjectInherit = 1;
            static ContainerInherit = 2;
            static NoPropagateInherit = 4;
            static InheritOnly = 8;
            static InheritanceFlags = 15;
            static Inherited = 16;
            static SuccessfulAccess = 64;
            static FailedAccess = 128;
            static AuditFlags = 192;
            static $map;
            static get Map()
            {
                return this.$map ??= 
                {
                    "None": 0n,
                    "ObjectInherit": 1n,
                    "ContainerInherit": 2n,
                    "NoPropagateInherit": 4n,
                    "InheritOnly": 8n,
                    "InheritanceFlags": 15n,
                    "Inherited": 16n,
                    "SuccessfulAccess": 64n,
                    "FailedAccess": 128n,
                    "AuditFlags": 192n
                };
            }
            static $h = 572354;
            static $z = 1;
            static $f = 0b100000011010001001;
            static $k = 4;
            static get $eut() { return $.$spc.System.Byte; }
            static $$md;
            static get $md() { return this.$$md ??= {"b":1048577,"u":393217,"l":[{"t":572354,"n":"None","d":572354,"h":4295539650,"f":33},{"t":572354,"n":"ObjectInherit","d":572354,"h":8590506946,"f":33},{"t":572354,"n":"ContainerInherit","d":572354,"h":12885474242,"f":33},{"t":572354,"n":"NoPropagateInherit","d":572354,"h":17180441538,"f":33},{"t":572354,"n":"InheritOnly","d":572354,"h":21475408834,"f":33},{"t":572354,"n":"InheritanceFlags","d":572354,"h":25770376130,"f":33},{"t":572354,"n":"Inherited","d":572354,"h":30065343426,"f":33},{"t":572354,"n":"SuccessfulAccess","d":572354,"h":34360310722,"f":33},{"t":572354,"n":"FailedAccess","d":572354,"h":38655278018,"f":33},{"t":572354,"n":"AuditFlags","d":572354,"h":42950245314,"f":33}],"c":[{"n":".ctor","o":"$ctor$3","d":572354,"h":47245212610,"f":1}],"i":[57278465,63832065,57737217,57409537],"h":572354,"a":[{"t":47710209,"c":4342677505}]}; }
            static get $b() { return $.$spc.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IComparable, $.$spc.System.ISpanFormattable, $.$spc.System.IFormattable, $.$spc.System.IConvertible ]; }
            static get $fullName() { return `System.Security.AccessControl.AceFlags`; }
        });
        
        $asm.$str("$ssa.System.Security.AccessControl.AceQualifier", ($self) => class AceQualifier extends $.$spc.System.Enum
        {
            static AccessAllowed = 0;
            static AccessDenied = 1;
            static SystemAudit = 2;
            static SystemAlarm = 3;
            static $map;
            static get Map()
            {
                return this.$map ??= 
                {
                    "AccessAllowed": 0n,
                    "AccessDenied": 1n,
                    "SystemAudit": 2n,
                    "SystemAlarm": 3n
                };
            }
            static $h = 637890;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static get $eut() { return $.$spc.System.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {"b":1048577,"u":655361,"l":[{"t":637890,"n":"AccessAllowed","d":637890,"h":4295605186,"f":33},{"t":637890,"n":"AccessDenied","d":637890,"h":8590572482,"f":33},{"t":637890,"n":"SystemAudit","d":637890,"h":12885539778,"f":33},{"t":637890,"n":"SystemAlarm","d":637890,"h":17180507074,"f":33}],"c":[{"n":".ctor","o":"$ctor$3","d":637890,"h":21475474370,"f":1}],"i":[57278465,63832065,57737217,57409537],"h":637890}; }
            static get $b() { return $.$spc.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IComparable, $.$spc.System.ISpanFormattable, $.$spc.System.IFormattable, $.$spc.System.IConvertible ]; }
            static get $fullName() { return `System.Security.AccessControl.AceQualifier`; }
        });
        
        $asm.$str("$ssa.System.Security.AccessControl.AceType", ($self) => class AceType extends $.$spc.System.Enum
        {
            static AccessAllowed = 0;
            static AccessDenied = 1;
            static SystemAudit = 2;
            static SystemAlarm = 3;
            static AccessAllowedCompound = 4;
            static AccessAllowedObject = 5;
            static AccessDeniedObject = 6;
            static SystemAuditObject = 7;
            static SystemAlarmObject = 8;
            static AccessAllowedCallback = 9;
            static AccessDeniedCallback = 10;
            static AccessAllowedCallbackObject = 11;
            static AccessDeniedCallbackObject = 12;
            static SystemAuditCallback = 13;
            static SystemAlarmCallback = 14;
            static SystemAuditCallbackObject = 15;
            static MaxDefinedAceType = 16;
            static SystemAlarmCallbackObject = 16;
            static $map;
            static get Map()
            {
                return this.$map ??= 
                {
                    "AccessAllowed": 0n,
                    "AccessDenied": 1n,
                    "SystemAudit": 2n,
                    "SystemAlarm": 3n,
                    "AccessAllowedCompound": 4n,
                    "AccessAllowedObject": 5n,
                    "AccessDeniedObject": 6n,
                    "SystemAuditObject": 7n,
                    "SystemAlarmObject": 8n,
                    "AccessAllowedCallback": 9n,
                    "AccessDeniedCallback": 10n,
                    "AccessAllowedCallbackObject": 11n,
                    "AccessDeniedCallbackObject": 12n,
                    "SystemAuditCallback": 13n,
                    "SystemAlarmCallback": 14n,
                    "SystemAuditCallbackObject": 15n,
                    "MaxDefinedAceType": 16n,
                    "SystemAlarmCallbackObject": 16n
                };
            }
            static $h = 703426;
            static $z = 1;
            static $f = 0b100000011010001001;
            static $k = 4;
            static get $eut() { return $.$spc.System.Byte; }
            static $$md;
            static get $md() { return this.$$md ??= {"b":1048577,"u":393217,"l":[{"t":703426,"n":"AccessAllowed","d":703426,"h":4295670722,"f":33},{"t":703426,"n":"AccessDenied","d":703426,"h":8590638018,"f":33},{"t":703426,"n":"SystemAudit","d":703426,"h":12885605314,"f":33},{"t":703426,"n":"SystemAlarm","d":703426,"h":17180572610,"f":33},{"t":703426,"n":"AccessAllowedCompound","d":703426,"h":21475539906,"f":33},{"t":703426,"n":"AccessAllowedObject","d":703426,"h":25770507202,"f":33},{"t":703426,"n":"AccessDeniedObject","d":703426,"h":30065474498,"f":33},{"t":703426,"n":"SystemAuditObject","d":703426,"h":34360441794,"f":33},{"t":703426,"n":"SystemAlarmObject","d":703426,"h":38655409090,"f":33},{"t":703426,"n":"AccessAllowedCallback","d":703426,"h":42950376386,"f":33},{"t":703426,"n":"AccessDeniedCallback","d":703426,"h":47245343682,"f":33},{"t":703426,"n":"AccessAllowedCallbackObject","d":703426,"h":51540310978,"f":33},{"t":703426,"n":"AccessDeniedCallbackObject","d":703426,"h":55835278274,"f":33},{"t":703426,"n":"SystemAuditCallback","d":703426,"h":60130245570,"f":33},{"t":703426,"n":"SystemAlarmCallback","d":703426,"h":64425212866,"f":33},{"t":703426,"n":"SystemAuditCallbackObject","d":703426,"h":68720180162,"f":33},{"t":703426,"n":"MaxDefinedAceType","d":703426,"h":73015147458,"f":33},{"t":703426,"n":"SystemAlarmCallbackObject","d":703426,"h":77310114754,"f":33}],"c":[{"n":".ctor","o":"$ctor$3","d":703426,"h":81605082050,"f":1}],"i":[57278465,63832065,57737217,57409537],"h":703426}; }
            static get $b() { return $.$spc.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IComparable, $.$spc.System.ISpanFormattable, $.$spc.System.IFormattable, $.$spc.System.IConvertible ]; }
            static get $fullName() { return `System.Security.AccessControl.AceType`; }
        });
        
        $asm.$str("$ssa.System.Security.AccessControl.AuditFlags", ($self) => class AuditFlags extends $.$spc.System.Enum
        {
            static None = 0;
            static Success = 1;
            static Failure = 2;
            static $map;
            static get Map()
            {
                return this.$map ??= 
                {
                    "None": 0n,
                    "Success": 1n,
                    "Failure": 2n
                };
            }
            static $h = 768962;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static get $eut() { return $.$spc.System.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {"b":1048577,"u":655361,"l":[{"t":768962,"n":"None","d":768962,"h":4295736258,"f":33},{"t":768962,"n":"Success","d":768962,"h":8590703554,"f":33},{"t":768962,"n":"Failure","d":768962,"h":12885670850,"f":33}],"c":[{"n":".ctor","o":"$ctor$3","d":768962,"h":17180638146,"f":1}],"i":[57278465,63832065,57737217,57409537],"h":768962,"a":[{"t":47710209,"c":4342677505}]}; }
            static get $b() { return $.$spc.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IComparable, $.$spc.System.ISpanFormattable, $.$spc.System.IFormattable, $.$spc.System.IConvertible ]; }
            static get $fullName() { return `System.Security.AccessControl.AuditFlags`; }
        });
        
        $asm.$str("$ssa.System.Security.AccessControl.CompoundAceType", ($self) => class CompoundAceType extends $.$spc.System.Enum
        {
            static Impersonation = 1;
            static $map;
            static get Map()
            {
                return this.$map ??= 
                {
                    "Impersonation": 1n
                };
            }
            static $h = 1424322;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static get $eut() { return $.$spc.System.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {"b":1048577,"u":655361,"l":[{"t":1424322,"n":"Impersonation","d":1424322,"h":4296391618,"f":33}],"c":[{"n":".ctor","o":"$ctor$3","d":1424322,"h":8591358914,"f":1}],"i":[57278465,63832065,57737217,57409537],"h":1424322}; }
            static get $b() { return $.$spc.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IComparable, $.$spc.System.ISpanFormattable, $.$spc.System.IFormattable, $.$spc.System.IConvertible ]; }
            static get $fullName() { return `System.Security.AccessControl.CompoundAceType`; }
        });
        
        $asm.$str("$ssa.System.Security.AccessControl.ControlFlags", ($self) => class ControlFlags extends $.$spc.System.Enum
        {
            static None = 0;
            static OwnerDefaulted = 1;
            static GroupDefaulted = 2;
            static DiscretionaryAclPresent = 4;
            static DiscretionaryAclDefaulted = 8;
            static SystemAclPresent = 16;
            static SystemAclDefaulted = 32;
            static DiscretionaryAclUntrusted = 64;
            static ServerSecurity = 128;
            static DiscretionaryAclAutoInheritRequired = 256;
            static SystemAclAutoInheritRequired = 512;
            static DiscretionaryAclAutoInherited = 1024;
            static SystemAclAutoInherited = 2048;
            static DiscretionaryAclProtected = 4096;
            static SystemAclProtected = 8192;
            static RMControlValid = 16384;
            static SelfRelative = 32768;
            static $map;
            static get Map()
            {
                return this.$map ??= 
                {
                    "None": 0n,
                    "OwnerDefaulted": 1n,
                    "GroupDefaulted": 2n,
                    "DiscretionaryAclPresent": 4n,
                    "DiscretionaryAclDefaulted": 8n,
                    "SystemAclPresent": 16n,
                    "SystemAclDefaulted": 32n,
                    "DiscretionaryAclUntrusted": 64n,
                    "ServerSecurity": 128n,
                    "DiscretionaryAclAutoInheritRequired": 256n,
                    "SystemAclAutoInheritRequired": 512n,
                    "DiscretionaryAclAutoInherited": 1024n,
                    "SystemAclAutoInherited": 2048n,
                    "DiscretionaryAclProtected": 4096n,
                    "SystemAclProtected": 8192n,
                    "RMControlValid": 16384n,
                    "SelfRelative": 32768n
                };
            }
            static $h = 1489858;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static get $eut() { return $.$spc.System.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {"b":1048577,"u":655361,"l":[{"t":1489858,"n":"None","d":1489858,"h":4296457154,"f":33},{"t":1489858,"n":"OwnerDefaulted","d":1489858,"h":8591424450,"f":33},{"t":1489858,"n":"GroupDefaulted","d":1489858,"h":12886391746,"f":33},{"t":1489858,"n":"DiscretionaryAclPresent","d":1489858,"h":17181359042,"f":33},{"t":1489858,"n":"DiscretionaryAclDefaulted","d":1489858,"h":21476326338,"f":33},{"t":1489858,"n":"SystemAclPresent","d":1489858,"h":25771293634,"f":33},{"t":1489858,"n":"SystemAclDefaulted","d":1489858,"h":30066260930,"f":33},{"t":1489858,"n":"DiscretionaryAclUntrusted","d":1489858,"h":34361228226,"f":33},{"t":1489858,"n":"ServerSecurity","d":1489858,"h":38656195522,"f":33},{"t":1489858,"n":"DiscretionaryAclAutoInheritRequired","d":1489858,"h":42951162818,"f":33},{"t":1489858,"n":"SystemAclAutoInheritRequired","d":1489858,"h":47246130114,"f":33},{"t":1489858,"n":"DiscretionaryAclAutoInherited","d":1489858,"h":51541097410,"f":33},{"t":1489858,"n":"SystemAclAutoInherited","d":1489858,"h":55836064706,"f":33},{"t":1489858,"n":"DiscretionaryAclProtected","d":1489858,"h":60131032002,"f":33},{"t":1489858,"n":"SystemAclProtected","d":1489858,"h":64425999298,"f":33},{"t":1489858,"n":"RMControlValid","d":1489858,"h":68720966594,"f":33},{"t":1489858,"n":"SelfRelative","d":1489858,"h":73015933890,"f":33}],"c":[{"n":".ctor","o":"$ctor$3","d":1489858,"h":77310901186,"f":1}],"i":[57278465,63832065,57737217,57409537],"h":1489858,"a":[{"t":47710209,"c":4342677505}]}; }
            static get $b() { return $.$spc.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IComparable, $.$spc.System.ISpanFormattable, $.$spc.System.IFormattable, $.$spc.System.IConvertible ]; }
            static get $fullName() { return `System.Security.AccessControl.ControlFlags`; }
        });
        
        $asm.$str("$ssa.System.Security.AccessControl.InheritanceFlags", ($self) => class InheritanceFlags extends $.$spc.System.Enum
        {
            static None = 0;
            static ContainerInherit = 1;
            static ObjectInherit = 2;
            static $map;
            static get Map()
            {
                return this.$map ??= 
                {
                    "None": 0n,
                    "ContainerInherit": 1n,
                    "ObjectInherit": 2n
                };
            }
            static $h = 1883074;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static get $eut() { return $.$spc.System.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {"b":1048577,"u":655361,"l":[{"t":1883074,"n":"None","d":1883074,"h":4296850370,"f":33},{"t":1883074,"n":"ContainerInherit","d":1883074,"h":8591817666,"f":33},{"t":1883074,"n":"ObjectInherit","d":1883074,"h":12886784962,"f":33}],"c":[{"n":".ctor","o":"$ctor$3","d":1883074,"h":17181752258,"f":1}],"i":[57278465,63832065,57737217,57409537],"h":1883074,"a":[{"t":47710209,"c":4342677505}]}; }
            static get $b() { return $.$spc.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IComparable, $.$spc.System.ISpanFormattable, $.$spc.System.IFormattable, $.$spc.System.IConvertible ]; }
            static get $fullName() { return `System.Security.AccessControl.InheritanceFlags`; }
        });
        
        $asm.$str("$ssa.System.Security.AccessControl.ObjectAceFlags", ($self) => class ObjectAceFlags extends $.$spc.System.Enum
        {
            static None = 0;
            static ObjectAceTypePresent = 1;
            static InheritedObjectAceTypePresent = 2;
            static $map;
            static get Map()
            {
                return this.$map ??= 
                {
                    "None": 0n,
                    "ObjectAceTypePresent": 1n,
                    "InheritedObjectAceTypePresent": 2n
                };
            }
            static $h = 2276290;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static get $eut() { return $.$spc.System.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {"b":1048577,"u":655361,"l":[{"t":2276290,"n":"None","d":2276290,"h":4297243586,"f":33},{"t":2276290,"n":"ObjectAceTypePresent","d":2276290,"h":8592210882,"f":33},{"t":2276290,"n":"InheritedObjectAceTypePresent","d":2276290,"h":12887178178,"f":33}],"c":[{"n":".ctor","o":"$ctor$3","d":2276290,"h":17182145474,"f":1}],"i":[57278465,63832065,57737217,57409537],"h":2276290,"a":[{"t":47710209,"c":4342677505}]}; }
            static get $b() { return $.$spc.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IComparable, $.$spc.System.ISpanFormattable, $.$spc.System.IFormattable, $.$spc.System.IConvertible ]; }
            static get $fullName() { return `System.Security.AccessControl.ObjectAceFlags`; }
        });
        
        $asm.$str("$ssa.System.Security.AccessControl.PropagationFlags", ($self) => class PropagationFlags extends $.$spc.System.Enum
        {
            static None = 0;
            static NoPropagateInherit = 1;
            static InheritOnly = 2;
            static $map;
            static get Map()
            {
                return this.$map ??= 
                {
                    "None": 0n,
                    "NoPropagateInherit": 1n,
                    "InheritOnly": 2n
                };
            }
            static $h = 2603970;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static get $eut() { return $.$spc.System.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {"b":1048577,"u":655361,"l":[{"t":2603970,"n":"None","d":2603970,"h":4297571266,"f":33},{"t":2603970,"n":"NoPropagateInherit","d":2603970,"h":8592538562,"f":33},{"t":2603970,"n":"InheritOnly","d":2603970,"h":12887505858,"f":33}],"c":[{"n":".ctor","o":"$ctor$3","d":2603970,"h":17182473154,"f":1}],"i":[57278465,63832065,57737217,57409537],"h":2603970,"a":[{"t":47710209,"c":4342677505}]}; }
            static get $b() { return $.$spc.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IComparable, $.$spc.System.ISpanFormattable, $.$spc.System.IFormattable, $.$spc.System.IConvertible ]; }
            static get $fullName() { return `System.Security.AccessControl.PropagationFlags`; }
        });
        
        $asm.$str("$ssa.System.Security.AccessControl.ResourceType", ($self) => class ResourceType extends $.$spc.System.Enum
        {
            static Unknown = 0;
            static FileObject = 1;
            static Service = 2;
            static Printer = 3;
            static RegistryKey = 4;
            static LMShare = 5;
            static KernelObject = 6;
            static WindowObject = 7;
            static DSObject = 8;
            static DSObjectAll = 9;
            static ProviderDefined = 10;
            static WmiGuidObject = 11;
            static RegistryWow6432Key = 12;
            static $map;
            static get Map()
            {
                return this.$map ??= 
                {
                    "Unknown": 0n,
                    "FileObject": 1n,
                    "Service": 2n,
                    "Printer": 3n,
                    "RegistryKey": 4n,
                    "LMShare": 5n,
                    "KernelObject": 6n,
                    "WindowObject": 7n,
                    "DSObject": 8n,
                    "DSObjectAll": 9n,
                    "ProviderDefined": 10n,
                    "WmiGuidObject": 11n,
                    "RegistryWow6432Key": 12n
                };
            }
            static $h = 2866114;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static get $eut() { return $.$spc.System.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {"b":1048577,"u":655361,"l":[{"t":2866114,"n":"Unknown","d":2866114,"h":4297833410,"f":33},{"t":2866114,"n":"FileObject","d":2866114,"h":8592800706,"f":33},{"t":2866114,"n":"Service","d":2866114,"h":12887768002,"f":33},{"t":2866114,"n":"Printer","d":2866114,"h":17182735298,"f":33},{"t":2866114,"n":"RegistryKey","d":2866114,"h":21477702594,"f":33},{"t":2866114,"n":"LMShare","d":2866114,"h":25772669890,"f":33},{"t":2866114,"n":"KernelObject","d":2866114,"h":30067637186,"f":33},{"t":2866114,"n":"WindowObject","d":2866114,"h":34362604482,"f":33},{"t":2866114,"n":"DSObject","d":2866114,"h":38657571778,"f":33},{"t":2866114,"n":"DSObjectAll","d":2866114,"h":42952539074,"f":33},{"t":2866114,"n":"ProviderDefined","d":2866114,"h":47247506370,"f":33},{"t":2866114,"n":"WmiGuidObject","d":2866114,"h":51542473666,"f":33},{"t":2866114,"n":"RegistryWow6432Key","d":2866114,"h":55837440962,"f":33}],"c":[{"n":".ctor","o":"$ctor$3","d":2866114,"h":60132408258,"f":1}],"i":[57278465,63832065,57737217,57409537],"h":2866114}; }
            static get $b() { return $.$spc.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IComparable, $.$spc.System.ISpanFormattable, $.$spc.System.IFormattable, $.$spc.System.IConvertible ]; }
            static get $fullName() { return `System.Security.AccessControl.ResourceType`; }
        });
        
        $asm.$str("$ssa.System.Security.AccessControl.SecurityInfos", ($self) => class SecurityInfos extends $.$spc.System.Enum
        {
            static Owner = 1;
            static Group = 2;
            static DiscretionaryAcl = 4;
            static SystemAcl = 8;
            static $map;
            static get Map()
            {
                return this.$map ??= 
                {
                    "Owner": 1n,
                    "Group": 2n,
                    "DiscretionaryAcl": 4n,
                    "SystemAcl": 8n
                };
            }
            static $h = 2931650;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static get $eut() { return $.$spc.System.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {"b":1048577,"u":655361,"l":[{"t":2931650,"n":"Owner","d":2931650,"h":4297898946,"f":33},{"t":2931650,"n":"Group","d":2931650,"h":8592866242,"f":33},{"t":2931650,"n":"DiscretionaryAcl","d":2931650,"h":12887833538,"f":33},{"t":2931650,"n":"SystemAcl","d":2931650,"h":17182800834,"f":33}],"c":[{"n":".ctor","o":"$ctor$3","d":2931650,"h":21477768130,"f":1}],"i":[57278465,63832065,57737217,57409537],"h":2931650,"a":[{"t":47710209,"c":4342677505}]}; }
            static get $b() { return $.$spc.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IComparable, $.$spc.System.ISpanFormattable, $.$spc.System.IFormattable, $.$spc.System.IConvertible ]; }
            static get $fullName() { return `System.Security.AccessControl.SecurityInfos`; }
        });
        
        $asm.$cls("$ssa.System.Security.AccessControl.CommonAce", ($self) => class CommonAce extends $.$ssa.System.Security.AccessControl.QualifiedAce
        {
            $ctor$4(/*System.Security.AccessControl.AceFlags*/ flags, /*System.Security.AccessControl.AceQualifier*/ qualifier, /*int*/ accessMask, /*System.Security.Principal.SecurityIdentifier*/ sid, /*bool*/ isCallback, /*byte[]?*/ opaque)
            {
                super.$ctor$3();
                {
                }
                return this;
            }
            /*int */ get BinaryLength()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*void */ GetBinaryForm(/*byte[]*/ binaryForm, /*int*/ offset)
            {
            }
            static /*int */ MaxOpaqueLength(/*bool*/ isCallback)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static $h = 1096642;
            static $f = 0b10010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":2669506,"p":[{"p":655361,"g":{"r":0,"d":0,"h":12885998530,"f":32769},"n":"BinaryLength","d":1096642,"h":8591031234,"f":32769}],"m":[{"r":65537,"p":[{"n":"binaryForm","p":0},{"n":"offset","p":655361}],"n":"GetBinaryForm","d":1096642,"h":17180965826,"f":32769},{"r":655361,"p":[{"n":"isCallback","p":262145}],"n":"MaxOpaqueLength","d":1096642,"h":21475933122,"f":33}],"c":[{"p":[{"n":"flags","p":572354},{"n":"qualifier","p":637890},{"n":"accessMask","p":655361},{"n":"sid","p":429438},{"n":"isCallback","p":262145},{"n":"opaque","p":0}],"n":".ctor","o":"$ctor$4","d":1096642,"h":4296063938,"f":1}],"h":1096642}; }
            static get $b() { return $.$ssa.System.Security.AccessControl.QualifiedAce; }
            static get $fullName() { return `System.Security.AccessControl.CommonAce`; }
        });
        
        $asm.$cls("$ssa.System.Security.AccessControl.ObjectAce", ($self) => class ObjectAce extends $.$ssa.System.Security.AccessControl.QualifiedAce
        {
            $ctor$4(/*System.Security.AccessControl.AceFlags*/ aceFlags, /*System.Security.AccessControl.AceQualifier*/ qualifier, /*int*/ accessMask, /*System.Security.Principal.SecurityIdentifier*/ sid, /*System.Security.AccessControl.ObjectAceFlags*/ flags, /*System.Guid*/ type, /*System.Guid*/ inheritedType, /*bool*/ isCallback, /*byte[]?*/ opaque)
            {
                super.$ctor$3();
                {
                }
                return this;
            }
            /*int */ get BinaryLength()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Guid */ get InheritedObjectAceType()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Guid */ set InheritedObjectAceType(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Security.AccessControl.ObjectAceFlags */ get ObjectAceFlags()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Security.AccessControl.ObjectAceFlags */ set ObjectAceFlags(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Guid */ get ObjectAceType()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Guid */ set ObjectAceType(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*void */ GetBinaryForm(/*byte[]*/ binaryForm, /*int*/ offset)
            {
            }
            static /*int */ MaxOpaqueLength(/*bool*/ isCallback)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static $h = 2210754;
            static $f = 0b10010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":2669506,"p":[{"p":655361,"g":{"r":0,"d":0,"h":12887112642,"f":32769},"n":"BinaryLength","d":2210754,"h":8592145346,"f":32769},{"p":56229889,"g":{"r":0,"d":0,"h":21477047234,"f":1},"s":{"r":0,"d":0,"h":25772014530,"f":1},"n":"InheritedObjectAceType","d":2210754,"h":17182079938,"f":1},{"p":2276290,"g":{"r":0,"d":0,"h":34361949122,"f":1},"s":{"r":0,"d":0,"h":38656916418,"f":1},"n":"ObjectAceFlags","d":2210754,"h":30066981826,"f":1},{"p":56229889,"g":{"r":0,"d":0,"h":47246851010,"f":1},"s":{"r":0,"d":0,"h":51541818306,"f":1},"n":"ObjectAceType","d":2210754,"h":42951883714,"f":1}],"m":[{"r":65537,"p":[{"n":"binaryForm","p":0},{"n":"offset","p":655361}],"n":"GetBinaryForm","d":2210754,"h":55836785602,"f":32769},{"r":655361,"p":[{"n":"isCallback","p":262145}],"n":"MaxOpaqueLength","d":2210754,"h":60131752898,"f":33}],"c":[{"p":[{"n":"aceFlags","p":572354},{"n":"qualifier","p":637890},{"n":"accessMask","p":655361},{"n":"sid","p":429438},{"n":"flags","p":2276290},{"n":"type","p":56229889},{"n":"inheritedType","p":56229889},{"n":"isCallback","p":262145},{"n":"opaque","p":0}],"n":".ctor","o":"$ctor$4","d":2210754,"h":4297178050,"f":1}],"h":2210754}; }
            static get $b() { return $.$ssa.System.Security.AccessControl.QualifiedAce; }
            static get $fullName() { return `System.Security.AccessControl.ObjectAce`; }
        });
        
        $asm.$cls("$ssa.System.Security.AccessControl.PrivilegeNotHeldException", ($self) => class PrivilegeNotHeldException extends $.$spc.System.UnauthorizedAccessException
        {
            $ctor$13()
            {
                super.$ctor$9();
                {
                }
                return this;
            }
            $ctor$14(/*string?*/ privilege)
            {
                super.$ctor$9();
                {
                }
                return this;
            }
            $ctor$15(/*string?*/ privilege, /*System.Exception?*/ inner)
            {
                super.$ctor$9();
                {
                }
                return this;
            }
            /*string? */ get PrivilegeName()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*void */ GetObjectData(/*System.Runtime.Serialization.SerializationInfo*/ info, /*System.Runtime.Serialization.StreamingContext*/ context)
            {
            }
            static $h = 2538434;
            static $f = 0b10010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":143851521,"h":2538434}; }
            static get $b() { return $.$spc.System.UnauthorizedAccessException; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.Runtime.Serialization.ISerializable ]; }
            static get $fullName() { return `System.Security.AccessControl.PrivilegeNotHeldException`; }
        });
	});
})(window, window.NetJs.$boot(), ...window.NetJs.$require("NetJs.System.Private.CoreLib", "NetJs.Microsoft.Win32.Primitives", "NetJs.System.Collections", "NetJs.System.Diagnostics.Tracing", "NetJs.System.Threading", "NetJs.System.Collections.Concurrent", "NetJs.System.Memory", "NetJs.System.Private.Uri", "NetJs.System.Runtime", "NetJs.System.Collections.NonGeneric", "NetJs.System.Runtime.InteropServices", "NetJs.System.Threading.Thread", "NetJs.System.Security.Claims", "NetJs.System.Security.Principal.Windows"))