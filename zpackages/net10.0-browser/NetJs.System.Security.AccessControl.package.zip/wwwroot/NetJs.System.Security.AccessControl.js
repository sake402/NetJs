
(function ($global, $, $$, $mwp, $sc, $sdt, $st, $scc, $sm, $spu, $sr, $scn, $sris, $stt, $ssc, $sspw) {
    "use strict";
    let _;
    
    
    
	$.$asm(
    "NetJs.System.Security.AccessControl", 
    {"h":55602,"f":"System.Security.AccessControl","v":"1.0.35.0","a":[{"t":115015681,"c":12999917569,"a":[{"v":".NETCoreApp,Version=v10.0","t":1310721}],"n":[{"n":"FrameworkDisplayName","v":".NET 10.0","t":1310721}]},{"t":73596929,"c":4368564225,"a":[{"v":"SIT","t":1310721}]},{"t":73662465,"c":4368629761,"a":[{"v":"Debug","t":1310721}]},{"t":74121217,"c":4369088513,"a":[{"v":"1.0.35.0","t":1310721}]},{"t":74252289,"c":4369219585,"a":[{"v":"1.0.35\u002Beff628fa5ab8bd29ec37e9c13a50148694bea088","t":1310721}]},{"t":75104257,"c":4370071553,"a":[{"v":"NetJs.System.Security.AccessControl","t":1310721}]},{"t":75235329,"c":4370202625,"a":[{"v":"NetJs.System.Security.AccessControl","t":1310721}]},{"t":75366401,"c":4370333697,"a":[{"v":"1.0.35.0","t":1310721}]},{"t":115081217,"c":4410048513,"a":[{"v":"browser1.0","t":1310721}]},{"t":114819073,"c":4409786369,"a":[{"v":"browser1.0","t":1310721}]}],"m":[]},
    function($asm)
	{
        
        
        $asm.$cls("$ssa.System.Security.AccessControl.AuthorizationRule", ($self) => class AuthorizationRule extends $.$$.System.Object
        {
            $ctor$1(/*System.Security.Principal.IdentityReference*/ identity, /*int*/ accessMask, /*bool*/ isInherited, /*System.Security.AccessControl.InheritanceFlags*/ inheritanceFlags, /*System.Security.AccessControl.PropagationFlags*/ propagationFlags)
            {
                super.$ctor();
                {
                }
                return this;
            }
            /*int */ get AccessMask()
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Security.Principal.IdentityReference */ get IdentityReference()
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Security.AccessControl.InheritanceFlags */ get InheritanceFlags()
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get IsInherited()
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Security.AccessControl.PropagationFlags */ get PropagationFlags()
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            static $h = 973106;
            static $f = 0b110001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":655361,"g":{"r":0,"d":0,"h":12885874994,"f":50331664},"n":"AccessMask","d":973106,"h":8590907698,"f":2097168},{"p":248526,"g":{"r":0,"d":0,"h":21475809586,"f":50331649},"n":"IdentityReference","d":973106,"h":17180842290,"f":2097153},{"p":1890610,"g":{"r":0,"d":0,"h":30065744178,"f":50331649},"n":"InheritanceFlags","d":973106,"h":25770776882,"f":2097153},{"p":262145,"g":{"r":0,"d":0,"h":38655678770,"f":50331649},"n":"IsInherited","d":973106,"h":34360711474,"f":2097153},{"p":2611506,"g":{"r":0,"d":0,"h":47245613362,"f":50331649},"n":"PropagationFlags","d":973106,"h":42950646066,"f":2097153}],"c":[{"p":[{"n":"identity","p":248526},{"n":"accessMask","p":655361},{"n":"isInherited","p":262145},{"n":"inheritanceFlags","p":1890610},{"n":"propagationFlags","p":2611506}],"n":".ctor","o":"$ctor$1","d":973106,"h":4295940402,"f":16777232}],"h":973106}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `System.Security.AccessControl.AuthorizationRule`; }
        });
        
        $asm.$cls("$ssa.System.Security.AccessControl.GenericAce", ($self) => class GenericAce extends $.$$.System.Object
        {
            $ctor$1()
            {
                super.$ctor();
                {
                }
                return this;
            }
            /*System.Security.AccessControl.AceFlags */ get AceFlags()
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Security.AccessControl.AceFlags */ set AceFlags(value)
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Security.AccessControl.AceType */ get AceType()
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Security.AccessControl.AuditFlags */ get AuditFlags()
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Security.AccessControl.InheritanceFlags */ get InheritanceFlags()
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get IsInherited()
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Security.AccessControl.PropagationFlags */ get PropagationFlags()
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Security.AccessControl.GenericAce */ Copy()
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            static /*System.Security.AccessControl.GenericAce */ CreateFromBinaryForm(/*byte[]*/ binaryForm, /*int*/ offset)
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            static/*conventional*/ /*bool */ Equals$1(/*object?*/ o)
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            //Static convention instance redirect
            /*bool */ Equals$1() { return $.$ssa.System.Security.AccessControl.GenericAce.Equals$1.apply(this, arguments); }
            static/*conventional*/ /*int */ GetHashCode()
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            //Static convention instance redirect
            /*int */ GetHashCode() { return $.$ssa.System.Security.AccessControl.GenericAce.GetHashCode.apply(this, arguments); }
            static /*bool */ op_Equality(/*System.Security.AccessControl.GenericAce?*/ left, /*System.Security.AccessControl.GenericAce?*/ right)
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            static /*bool */ op_Inequality(/*System.Security.AccessControl.GenericAce?*/ left, /*System.Security.AccessControl.GenericAce?*/ right)
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            static $h = 1694002;
            static $f = 0b110001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":579890,"g":{"r":0,"d":0,"h":12886595890,"f":50331649},"s":{"r":0,"d":0,"h":17181563186,"f":83886081},"n":"AceFlags","d":1694002,"h":8591628594,"f":2097153},{"p":710962,"g":{"r":0,"d":0,"h":25771497778,"f":50331649},"n":"AceType","d":1694002,"h":21476530482,"f":2097153},{"p":776498,"g":{"r":0,"d":0,"h":34361432370,"f":50331649},"n":"AuditFlags","d":1694002,"h":30066465074,"f":2097153},{"p":655361,"g":{"r":0,"d":0,"h":42951366962,"f":50331905},"n":"BinaryLength","d":1694002,"h":38656399666,"f":2097409},{"p":1890610,"g":{"r":0,"d":0,"h":51541301554,"f":50331649},"n":"InheritanceFlags","d":1694002,"h":47246334258,"f":2097153},{"p":262145,"g":{"r":0,"d":0,"h":60131236146,"f":50331649},"n":"IsInherited","d":1694002,"h":55836268850,"f":2097153},{"p":2611506,"g":{"r":0,"d":0,"h":68721170738,"f":50331649},"n":"PropagationFlags","d":1694002,"h":64426203442,"f":2097153}],"m":[{"r":1694002,"n":"Copy","d":1694002,"h":73016138034,"f":16777217},{"r":1694002,"p":[{"n":"binaryForm","p":$.$typeArray($.$$.System.Byte).$h},{"n":"offset","p":655361}],"n":"CreateFromBinaryForm","d":1694002,"h":77311105330,"f":16777249},{"r":262145,"p":[{"n":"o","p":131073}],"n":"Equals","o":"@$1","d":1694002,"h":81606072626,"f":16875521},{"r":65537,"p":[{"n":"binaryForm","p":$.$typeArray($.$$.System.Byte).$h},{"n":"offset","p":655361}],"n":"GetBinaryForm","d":1694002,"h":85901039922,"f":16777473},{"r":655361,"n":"GetHashCode","d":1694002,"h":90196007218,"f":16875521}],"c":[{"n":".ctor","o":"$ctor$1","d":1694002,"h":4296661298,"f":16777224}],"h":1694002}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `System.Security.AccessControl.GenericAce`; }
        });
        
        $asm.$cls("$ssa.System.Security.AccessControl.GenericSecurityDescriptor", ($self) => class GenericSecurityDescriptor extends $.$$.System.Object
        {
            $ctor$1()
            {
                super.$ctor();
                {
                }
                return this;
            }
            /*int */ get BinaryLength()
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            static /*byte */ get Revision()
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*void */ GetBinaryForm(/*byte[]*/ binaryForm, /*int*/ offset)
            {
            }
            /*string */ GetSddlForm(/*System.Security.AccessControl.AccessControlSections*/ includeSections)
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            static /*bool */ IsSddlConversionSupported()
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            static $h = 1825074;
            static $f = 0b110001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":655361,"g":{"r":0,"d":0,"h":12886726962,"f":50331649},"n":"BinaryLength","d":1825074,"h":8591759666,"f":2097153},{"p":1497394,"g":{"r":0,"d":0,"h":21476661554,"f":50331905},"n":"ControlFlags","d":1825074,"h":17181694258,"f":2097409},{"p":445134,"g":{"r":0,"d":0,"h":30066596146,"f":50331905},"s":{"r":0,"d":0,"h":34361563442,"f":83886337},"n":"Group","d":1825074,"h":25771628850,"f":2097409},{"p":445134,"g":{"r":0,"d":0,"h":42951498034,"f":50331905},"s":{"r":0,"d":0,"h":47246465330,"f":83886337},"n":"Owner","d":1825074,"h":38656530738,"f":2097409},{"p":393217,"g":{"r":0,"d":0,"h":55836399922,"f":50331681},"n":"Revision","d":1825074,"h":51541432626,"f":2097185}],"m":[{"r":65537,"p":[{"n":"binaryForm","p":$.$typeArray($.$$.System.Byte).$h},{"n":"offset","p":655361}],"n":"GetBinaryForm","d":1825074,"h":60131367218,"f":16777217},{"r":1310721,"p":[{"n":"includeSections","p":252210}],"n":"GetSddlForm","d":1825074,"h":64426334514,"f":16777217},{"r":262145,"n":"IsSddlConversionSupported","d":1825074,"h":68721301810,"f":16777249}],"c":[{"n":".ctor","o":"$ctor$1","d":1825074,"h":4296792370,"f":16777224}],"h":1825074}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `System.Security.AccessControl.GenericSecurityDescriptor`; }
        });
        
        $asm.$cls("$ssa.System.Security.AccessControl.ObjectSecurity", ($self) => class ObjectSecurity extends $.$$.System.Object
        {
            $ctor$1()
            {
                super.$ctor();
                {
                }
                return this;
            }
            $ctor$2(/*bool*/ isContainer, /*bool*/ isDS)
            {
                super.$ctor();
                {
                }
                return this;
            }
            $ctor$3(/*System.Security.AccessControl.CommonSecurityDescriptor*/ securityDescriptor)
            {
                super.$ctor();
                {
                }
                return this;
            }
            /*bool */ get AccessRulesModified()
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ set AccessRulesModified(value)
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get AreAccessRulesCanonical()
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get AreAccessRulesProtected()
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get AreAuditRulesCanonical()
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get AreAuditRulesProtected()
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get AuditRulesModified()
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ set AuditRulesModified(value)
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get GroupModified()
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ set GroupModified(value)
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get IsContainer()
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get IsDS()
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get OwnerModified()
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ set OwnerModified(value)
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Security.AccessControl.CommonSecurityDescriptor */ get SecurityDescriptor()
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Security.Principal.IdentityReference? */ GetGroup(/*System.Type*/ targetType)
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Security.Principal.IdentityReference? */ GetOwner(/*System.Type*/ targetType)
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*byte[] */ GetSecurityDescriptorBinaryForm()
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*string */ GetSecurityDescriptorSddlForm(/*System.Security.AccessControl.AccessControlSections*/ includeSections)
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            static /*bool */ IsSddlConversionSupported()
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ ModifyAccessRule(/*System.Security.AccessControl.AccessControlModification*/ modification, /*System.Security.AccessControl.AccessRule*/ rule, /*out bool*/ modified)
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ ModifyAuditRule(/*System.Security.AccessControl.AccessControlModification*/ modification, /*System.Security.AccessControl.AuditRule*/ rule, /*out bool*/ modified)
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*void */ Persist(/*bool*/ enableOwnershipPrivilege, /*string*/ name, /*System.Security.AccessControl.AccessControlSections*/ includeSections)
            {
            }
            /*void */ Persist$1(/*System.Runtime.InteropServices.SafeHandle*/ handle, /*System.Security.AccessControl.AccessControlSections*/ includeSections)
            {
            }
            /*void */ Persist$2(/*string*/ name, /*System.Security.AccessControl.AccessControlSections*/ includeSections)
            {
            }
            /*void */ PurgeAccessRules(/*System.Security.Principal.IdentityReference*/ identity)
            {
            }
            /*void */ PurgeAuditRules(/*System.Security.Principal.IdentityReference*/ identity)
            {
            }
            /*void */ ReadLock()
            {
            }
            /*void */ ReadUnlock()
            {
            }
            /*void */ SetAccessRuleProtection(/*bool*/ isProtected, /*bool*/ preserveInheritance)
            {
            }
            /*void */ SetAuditRuleProtection(/*bool*/ isProtected, /*bool*/ preserveInheritance)
            {
            }
            /*void */ SetGroup(/*System.Security.Principal.IdentityReference*/ identity)
            {
            }
            /*void */ SetOwner(/*System.Security.Principal.IdentityReference*/ identity)
            {
            }
            /*void */ SetSecurityDescriptorBinaryForm$1(/*byte[]*/ binaryForm)
            {
            }
            /*void */ SetSecurityDescriptorBinaryForm(/*byte[]*/ binaryForm, /*System.Security.AccessControl.AccessControlSections*/ includeSections)
            {
            }
            /*void */ SetSecurityDescriptorSddlForm$1(/*string*/ sddlForm)
            {
            }
            /*void */ SetSecurityDescriptorSddlForm(/*string*/ sddlForm, /*System.Security.AccessControl.AccessControlSections*/ includeSections)
            {
            }
            /*void */ WriteLock()
            {
            }
            /*void */ WriteUnlock()
            {
            }
            static $h = 2414898;
            static $f = 0b110001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":142475265,"g":{"r":0,"d":0,"h":21477251378,"f":50331905},"n":"AccessRightType","d":2414898,"h":17182284082,"f":2097409},{"p":262145,"g":{"r":0,"d":0,"h":30067185970,"f":50331652},"s":{"r":0,"d":0,"h":34362153266,"f":83886084},"n":"AccessRulesModified","d":2414898,"h":25772218674,"f":2097156},{"p":142475265,"g":{"r":0,"d":0,"h":42952087858,"f":50331905},"n":"AccessRuleType","d":2414898,"h":38657120562,"f":2097409},{"p":262145,"g":{"r":0,"d":0,"h":51542022450,"f":50331649},"n":"AreAccessRulesCanonical","d":2414898,"h":47247055154,"f":2097153},{"p":262145,"g":{"r":0,"d":0,"h":60131957042,"f":50331649},"n":"AreAccessRulesProtected","d":2414898,"h":55836989746,"f":2097153},{"p":262145,"g":{"r":0,"d":0,"h":68721891634,"f":50331649},"n":"AreAuditRulesCanonical","d":2414898,"h":64426924338,"f":2097153},{"p":262145,"g":{"r":0,"d":0,"h":77311826226,"f":50331649},"n":"AreAuditRulesProtected","d":2414898,"h":73016858930,"f":2097153},{"p":262145,"g":{"r":0,"d":0,"h":85901760818,"f":50331652},"s":{"r":0,"d":0,"h":90196728114,"f":83886084},"n":"AuditRulesModified","d":2414898,"h":81606793522,"f":2097156},{"p":142475265,"g":{"r":0,"d":0,"h":98786662706,"f":50331905},"n":"AuditRuleType","d":2414898,"h":94491695410,"f":2097409},{"p":262145,"g":{"r":0,"d":0,"h":107376597298,"f":50331652},"s":{"r":0,"d":0,"h":111671564594,"f":83886084},"n":"GroupModified","d":2414898,"h":103081630002,"f":2097156},{"p":262145,"g":{"r":0,"d":0,"h":120261499186,"f":50331652},"n":"IsContainer","d":2414898,"h":115966531890,"f":2097156},{"p":262145,"g":{"r":0,"d":0,"h":128851433778,"f":50331652},"n":"IsDS","d":2414898,"h":124556466482,"f":2097156},{"p":262145,"g":{"r":0,"d":0,"h":137441368370,"f":50331652},"s":{"r":0,"d":0,"h":141736335666,"f":83886084},"n":"OwnerModified","d":2414898,"h":133146401074,"f":2097156},{"p":1300786,"g":{"r":0,"d":0,"h":150326270258,"f":50331652},"n":"SecurityDescriptor","d":2414898,"h":146031302962,"f":2097156}],"m":[{"r":383282,"p":[{"n":"identityReference","p":248526},{"n":"accessMask","p":655361},{"n":"isInherited","p":262145},{"n":"inheritanceFlags","p":1890610},{"n":"propagationFlags","p":2611506},{"n":"type","p":317746}],"n":"AccessRuleFactory","d":2414898,"h":154621237554,"f":16777473},{"r":842034,"p":[{"n":"identityReference","p":248526},{"n":"accessMask","p":655361},{"n":"isInherited","p":262145},{"n":"inheritanceFlags","p":1890610},{"n":"propagationFlags","p":2611506},{"n":"flags","p":776498}],"n":"AuditRuleFactory","d":2414898,"h":158916204850,"f":16777473},{"r":248526,"p":[{"n":"targetType","p":142475265}],"n":"GetGroup","d":2414898,"h":163211172146,"f":16777217},{"r":248526,"p":[{"n":"targetType","p":142475265}],"n":"GetOwner","d":2414898,"h":167506139442,"f":16777217},{"r":$.$typeArray($.$$.System.Byte).$h,"n":"GetSecurityDescriptorBinaryForm","d":2414898,"h":171801106738,"f":16777217},{"r":1310721,"p":[{"n":"includeSections","p":252210}],"n":"GetSecurityDescriptorSddlForm","d":2414898,"h":176096074034,"f":16777217},{"r":262145,"n":"IsSddlConversionSupported","d":2414898,"h":180391041330,"f":16777249},{"r":262145,"p":[{"n":"modification","p":186674},{"n":"rule","p":383282},{"n":"modified","p":262145,"f":2}],"n":"ModifyAccess","d":2414898,"h":184686008626,"f":16777476},{"r":262145,"p":[{"n":"modification","p":186674},{"n":"rule","p":383282},{"n":"modified","p":262145,"f":2}],"n":"ModifyAccessRule","d":2414898,"h":188980975922,"f":16777345},{"r":262145,"p":[{"n":"modification","p":186674},{"n":"rule","p":842034},{"n":"modified","p":262145,"f":2}],"n":"ModifyAudit","d":2414898,"h":193275943218,"f":16777476},{"r":262145,"p":[{"n":"modification","p":186674},{"n":"rule","p":842034},{"n":"modified","p":262145,"f":2}],"n":"ModifyAuditRule","d":2414898,"h":197570910514,"f":16777345},{"r":65537,"p":[{"n":"enableOwnershipPrivilege","p":262145},{"n":"name","p":1310721},{"n":"includeSections","p":252210}],"n":"Persist","d":2414898,"h":201865877810,"f":16777348},{"r":65537,"p":[{"n":"handle","p":109445121},{"n":"includeSections","p":252210}],"n":"Persist","o":"@$1","d":2414898,"h":206160845106,"f":16777348},{"r":65537,"p":[{"n":"name","p":1310721},{"n":"includeSections","p":252210}],"n":"Persist","o":"@$2","d":2414898,"h":210455812402,"f":16777348},{"r":65537,"p":[{"n":"identity","p":248526}],"n":"PurgeAccessRules","d":2414898,"h":214750779698,"f":16777345},{"r":65537,"p":[{"n":"identity","p":248526}],"n":"PurgeAuditRules","d":2414898,"h":219045746994,"f":16777345},{"r":65537,"n":"ReadLock","d":2414898,"h":223340714290,"f":16777220},{"r":65537,"n":"ReadUnlock","d":2414898,"h":227635681586,"f":16777220},{"r":65537,"p":[{"n":"isProtected","p":262145},{"n":"preserveInheritance","p":262145}],"n":"SetAccessRuleProtection","d":2414898,"h":231930648882,"f":16777217},{"r":65537,"p":[{"n":"isProtected","p":262145},{"n":"preserveInheritance","p":262145}],"n":"SetAuditRuleProtection","d":2414898,"h":236225616178,"f":16777217},{"r":65537,"p":[{"n":"identity","p":248526}],"n":"SetGroup","d":2414898,"h":240520583474,"f":16777217},{"r":65537,"p":[{"n":"identity","p":248526}],"n":"SetOwner","d":2414898,"h":244815550770,"f":16777217},{"r":65537,"p":[{"n":"binaryForm","p":$.$typeArray($.$$.System.Byte).$h}],"n":"SetSecurityDescriptorBinaryForm","o":"@$1","d":2414898,"h":249110518066,"f":16777217},{"r":65537,"p":[{"n":"binaryForm","p":$.$typeArray($.$$.System.Byte).$h},{"n":"includeSections","p":252210}],"n":"SetSecurityDescriptorBinaryForm","d":2414898,"h":253405485362,"f":16777217},{"r":65537,"p":[{"n":"sddlForm","p":1310721}],"n":"SetSecurityDescriptorSddlForm","o":"@$1","d":2414898,"h":257700452658,"f":16777217},{"r":65537,"p":[{"n":"sddlForm","p":1310721},{"n":"includeSections","p":252210}],"n":"SetSecurityDescriptorSddlForm","d":2414898,"h":261995419954,"f":16777217},{"r":65537,"n":"WriteLock","d":2414898,"h":266290387250,"f":16777220},{"r":65537,"n":"WriteUnlock","d":2414898,"h":270585354546,"f":16777220}],"c":[{"n":".ctor","o":"$ctor$1","d":2414898,"h":4297382194,"f":16777220},{"p":[{"n":"isContainer","p":262145},{"n":"isDS","p":262145}],"n":".ctor","o":"$ctor$2","d":2414898,"h":8592349490,"f":16777220},{"p":[{"n":"securityDescriptor","p":1300786}],"n":".ctor","o":"$ctor$3","d":2414898,"h":12887316786,"f":16777220}],"h":2414898}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `System.Security.AccessControl.ObjectSecurity`; }
        });
        
        $asm.$cls("$ssa.System.Security.Policy.EvidenceBase", ($self) => class EvidenceBase extends $.$$.System.Object
        {
            $ctor$1()
            {
                super.$ctor();
                {
                }
                return this;
            }
            /*System.Security.Policy.EvidenceBase? */ Clone()
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            static $h = 3135794;
            static $f = 0b110001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"m":[{"r":3135794,"n":"Clone","d":3135794,"h":8593070386,"f":16777345}],"c":[{"n":".ctor","o":"$ctor$1","d":3135794,"h":4298103090,"f":16777220}],"h":3135794}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `System.Security.Policy.EvidenceBase`; }
        });
        
        $asm.$cls("$ssa.System.Security.AccessControl.GenericAcl", ($self) => class GenericAcl extends $.$$.System.Object
        {
            /*byte*/ static AclRevision = 0;
            /*byte*/ static AclRevisionDS = 0;
            /*int*/ static MaxBinaryLength = 0;
            $ctor$1()
            {
                super.$ctor();
                {
                }
                return this;
            }
            /*bool */ get IsSynchronized()
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*object */ get SyncRoot()
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*void */ CopyTo(/*System.Security.AccessControl.GenericAce[]*/ array, /*int*/ index)
            {
            }
            /*System.Security.AccessControl.AceEnumerator */ GetEnumerator()
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*void */ System$Collections$ICollection$CopyTo(/*System.Array*/ array, /*int*/ index)
            {
            }
            /*System.Collections.IEnumerator */ System$Collections$IEnumerable$GetEnumerator()
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            //Generated interface implemetation for System.Collections.ICollection.Count.get
            get System$Collections$ICollection$Count()
            {
                return this.Count;
            }
            //Generated interface implemetation for System.Collections.ICollection.SyncRoot.get
            get System$Collections$ICollection$SyncRoot()
            {
                return this.SyncRoot;
            }
            //Generated interface implemetation for System.Collections.ICollection.IsSynchronized.get
            get System$Collections$ICollection$IsSynchronized()
            {
                return this.IsSynchronized;
            }
            static $h = 1759538;
            static $f = 0b110001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":655361,"g":{"r":0,"d":0,"h":25771563314,"f":50331905},"n":"BinaryLength","d":1759538,"h":21476596018,"f":2097409},{"p":655361,"g":{"r":0,"d":0,"h":34361497906,"f":50331905},"n":"Count","d":1759538,"h":30066530610,"f":2097409},{"p":262145,"g":{"r":0,"d":0,"h":42951432498,"f":50331649},"n":"IsSynchronized","d":1759538,"h":38656465202,"f":2097153},{"p":1694002,"i":[{"n":"index","p":655361}],"g":{"r":0,"d":0,"h":51541367090,"f":50331905},"s":{"r":0,"d":0,"h":55836334386,"f":83886337},"n":"Item","o":"@$2","d":1759538,"h":47246399794,"f":2097409},{"p":393217,"g":{"r":0,"d":0,"h":64426268978,"f":50331905},"n":"Revision","d":1759538,"h":60131301682,"f":2097409},{"p":131073,"g":{"r":0,"d":0,"h":73016203570,"f":50331777},"n":"SyncRoot","d":1759538,"h":68721236274,"f":2097281}],"m":[{"r":65537,"p":[{"n":"array","p":$.$typeArray($.$ssa.System.Security.AccessControl.GenericAce).$h},{"n":"index","p":655361}],"n":"CopyTo","d":1759538,"h":77311170866,"f":16777217},{"r":65537,"p":[{"n":"binaryForm","p":$.$typeArray($.$$.System.Byte).$h},{"n":"offset","p":655361}],"n":"GetBinaryForm","d":1759538,"h":81606138162,"f":16777473},{"r":514354,"n":"GetEnumerator","d":1759538,"h":85901105458,"f":16777217}],"l":[{"t":393217,"n":"AclRevision","d":1759538,"h":4296726834,"f":4194337},{"t":393217,"n":"AclRevisionDS","d":1759538,"h":8591694130,"f":4194337},{"t":655361,"n":"MaxBinaryLength","d":1759538,"h":12886661426,"f":4194337}],"c":[{"n":".ctor","o":"$ctor$1","d":1759538,"h":17181628722,"f":16777220}],"i":[31457281,31719425],"h":1759538}; }
            static get $b() { return $.$$.System.Object; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.System.Collections.ICollection, $.$$.System.Collections.IEnumerable ]; }
            static get $fullName() { return `System.Security.AccessControl.GenericAcl`; }
        });
        
        $asm.$cls("$ssa.System.Security.AccessControl.AccessRule", ($self) => class AccessRule extends $.$ssa.System.Security.AccessControl.AuthorizationRule
        {
            $ctor$2(/*System.Security.Principal.IdentityReference*/ identity, /*int*/ accessMask, /*bool*/ isInherited, /*System.Security.AccessControl.InheritanceFlags*/ inheritanceFlags, /*System.Security.AccessControl.PropagationFlags*/ propagationFlags, /*System.Security.AccessControl.AccessControlType*/ type)
            {
                super.$ctor$1(null, 0, false, 0, 0);
                {
                }
                return this;
            }
            /*System.Security.AccessControl.AccessControlType */ get AccessControlType()
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            static $h = 383282;
            static $f = 0b110001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":973106,"p":[{"p":317746,"g":{"r":0,"d":0,"h":12885285170,"f":50331649},"n":"AccessControlType","d":383282,"h":8590317874,"f":2097153}],"c":[{"p":[{"n":"identity","p":248526},{"n":"accessMask","p":655361},{"n":"isInherited","p":262145},{"n":"inheritanceFlags","p":1890610},{"n":"propagationFlags","p":2611506},{"n":"type","p":317746}],"n":".ctor","o":"$ctor$2","d":383282,"h":4295350578,"f":16777220}],"h":383282}; }
            static get $b() { return $.$ssa.System.Security.AccessControl.AuthorizationRule; }
            static get $fullName() { return `System.Security.AccessControl.AccessRule`; }
        });
        
        $asm.$cls("$ssa.System.Security.AccessControl.AuditRule", ($self) => class AuditRule extends $.$ssa.System.Security.AccessControl.AuthorizationRule
        {
            $ctor$2(/*System.Security.Principal.IdentityReference*/ identity, /*int*/ accessMask, /*bool*/ isInherited, /*System.Security.AccessControl.InheritanceFlags*/ inheritanceFlags, /*System.Security.AccessControl.PropagationFlags*/ propagationFlags, /*System.Security.AccessControl.AuditFlags*/ auditFlags)
            {
                super.$ctor$1(null, 0, false, 0, 0);
                {
                }
                return this;
            }
            /*System.Security.AccessControl.AuditFlags */ get AuditFlags()
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            static $h = 842034;
            static $f = 0b110001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":973106,"p":[{"p":776498,"g":{"r":0,"d":0,"h":12885743922,"f":50331649},"n":"AuditFlags","d":842034,"h":8590776626,"f":2097153}],"c":[{"p":[{"n":"identity","p":248526},{"n":"accessMask","p":655361},{"n":"isInherited","p":262145},{"n":"inheritanceFlags","p":1890610},{"n":"propagationFlags","p":2611506},{"n":"auditFlags","p":776498}],"n":".ctor","o":"$ctor$2","d":842034,"h":4295809330,"f":16777220}],"h":842034}; }
            static get $b() { return $.$ssa.System.Security.AccessControl.AuthorizationRule; }
            static get $fullName() { return `System.Security.AccessControl.AuditRule`; }
        });
        
        $asm.$cls("$ssa.System.Security.AccessControl.CommonObjectSecurity", ($self) => class CommonObjectSecurity extends $.$ssa.System.Security.AccessControl.ObjectSecurity
        {
            $ctor$4(/*bool*/ isContainer)
            {
                super.$ctor$1();
                {
                }
                return this;
            }
            /*void */ AddAccessRule(/*System.Security.AccessControl.AccessRule*/ rule)
            {
            }
            /*void */ AddAuditRule(/*System.Security.AccessControl.AuditRule*/ rule)
            {
            }
            /*System.Security.AccessControl.AuthorizationRuleCollection */ GetAccessRules(/*bool*/ includeExplicit, /*bool*/ includeInherited, /*System.Type*/ targetType)
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Security.AccessControl.AuthorizationRuleCollection */ GetAuditRules(/*bool*/ includeExplicit, /*bool*/ includeInherited, /*System.Type*/ targetType)
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ ModifyAccess(/*System.Security.AccessControl.AccessControlModification*/ modification, /*System.Security.AccessControl.AccessRule*/ rule, /*out bool*/ modified)
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ ModifyAudit(/*System.Security.AccessControl.AccessControlModification*/ modification, /*System.Security.AccessControl.AuditRule*/ rule, /*out bool*/ modified)
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ RemoveAccessRule(/*System.Security.AccessControl.AccessRule*/ rule)
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*void */ RemoveAccessRuleAll(/*System.Security.AccessControl.AccessRule*/ rule)
            {
            }
            /*void */ RemoveAccessRuleSpecific(/*System.Security.AccessControl.AccessRule*/ rule)
            {
            }
            /*bool */ RemoveAuditRule(/*System.Security.AccessControl.AuditRule*/ rule)
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*void */ RemoveAuditRuleAll(/*System.Security.AccessControl.AuditRule*/ rule)
            {
            }
            /*void */ RemoveAuditRuleSpecific(/*System.Security.AccessControl.AuditRule*/ rule)
            {
            }
            /*void */ ResetAccessRule(/*System.Security.AccessControl.AccessRule*/ rule)
            {
            }
            /*void */ SetAccessRule(/*System.Security.AccessControl.AccessRule*/ rule)
            {
            }
            /*void */ SetAuditRule(/*System.Security.AccessControl.AuditRule*/ rule)
            {
            }
            static $h = 1235250;
            static $f = 0b110001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":2414898,"m":[{"r":65537,"p":[{"n":"rule","p":383282}],"n":"AddAccessRule","d":1235250,"h":8591169842,"f":16777220},{"r":65537,"p":[{"n":"rule","p":842034}],"n":"AddAuditRule","d":1235250,"h":12886137138,"f":16777220},{"r":1038642,"p":[{"n":"includeExplicit","p":262145},{"n":"includeInherited","p":262145},{"n":"targetType","p":142475265}],"n":"GetAccessRules","d":1235250,"h":17181104434,"f":16777217},{"r":1038642,"p":[{"n":"includeExplicit","p":262145},{"n":"includeInherited","p":262145},{"n":"targetType","p":142475265}],"n":"GetAuditRules","d":1235250,"h":21476071730,"f":16777217},{"r":262145,"p":[{"n":"modification","p":186674},{"n":"rule","p":383282},{"n":"modified","p":262145,"f":2}],"n":"ModifyAccess","d":1235250,"h":25771039026,"f":16809988},{"r":262145,"p":[{"n":"modification","p":186674},{"n":"rule","p":842034},{"n":"modified","p":262145,"f":2}],"n":"ModifyAudit","d":1235250,"h":30066006322,"f":16809988},{"r":262145,"p":[{"n":"rule","p":383282}],"n":"RemoveAccessRule","d":1235250,"h":34360973618,"f":16777220},{"r":65537,"p":[{"n":"rule","p":383282}],"n":"RemoveAccessRuleAll","d":1235250,"h":38655940914,"f":16777220},{"r":65537,"p":[{"n":"rule","p":383282}],"n":"RemoveAccessRuleSpecific","d":1235250,"h":42950908210,"f":16777220},{"r":262145,"p":[{"n":"rule","p":842034}],"n":"RemoveAuditRule","d":1235250,"h":47245875506,"f":16777220},{"r":65537,"p":[{"n":"rule","p":842034}],"n":"RemoveAuditRuleAll","d":1235250,"h":51540842802,"f":16777220},{"r":65537,"p":[{"n":"rule","p":842034}],"n":"RemoveAuditRuleSpecific","d":1235250,"h":55835810098,"f":16777220},{"r":65537,"p":[{"n":"rule","p":383282}],"n":"ResetAccessRule","d":1235250,"h":60130777394,"f":16777220},{"r":65537,"p":[{"n":"rule","p":383282}],"n":"SetAccessRule","d":1235250,"h":64425744690,"f":16777220},{"r":65537,"p":[{"n":"rule","p":842034}],"n":"SetAuditRule","d":1235250,"h":68720711986,"f":16777220}],"c":[{"p":[{"n":"isContainer","p":262145}],"n":".ctor","o":"$ctor$4","d":1235250,"h":4296202546,"f":16777220}],"h":1235250}; }
            static get $b() { return $.$ssa.System.Security.AccessControl.ObjectSecurity; }
            static get $fullName() { return `System.Security.AccessControl.CommonObjectSecurity`; }
        });
        
        $asm.$cls("$ssa.System.Security.AccessControl.KnownAce", ($self) => class KnownAce extends $.$ssa.System.Security.AccessControl.GenericAce
        {
            $ctor$2()
            {
                super.$ctor$1();
                {
                }
                return this;
            }
            /*int */ get AccessMask()
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ set AccessMask(value)
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Security.Principal.SecurityIdentifier */ get SecurityIdentifier()
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Security.Principal.SecurityIdentifier */ set SecurityIdentifier(value)
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            static $h = 1956146;
            static $f = 0b110001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":1694002,"p":[{"p":655361,"g":{"r":0,"d":0,"h":12886858034,"f":50331649},"s":{"r":0,"d":0,"h":17181825330,"f":83886081},"n":"AccessMask","d":1956146,"h":8591890738,"f":2097153},{"p":445134,"g":{"r":0,"d":0,"h":25771759922,"f":50331649},"s":{"r":0,"d":0,"h":30066727218,"f":83886081},"n":"SecurityIdentifier","d":1956146,"h":21476792626,"f":2097153}],"c":[{"n":".ctor","o":"$ctor$2","d":1956146,"h":4296923442,"f":16777224}],"h":1956146}; }
            static get $b() { return $.$ssa.System.Security.AccessControl.GenericAce; }
            static get $fullName() { return `System.Security.AccessControl.KnownAce`; }
        });
        
        $asm.$cls("$ssa.System.Security.AccessControl.CommonAcl", ($self) => class CommonAcl extends $.$ssa.System.Security.AccessControl.GenericAcl
        {
            $ctor$2()
            {
                super.$ctor$1();
                {
                }
                return this;
            }
            /*int */ get BinaryLength()
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ get Count()
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get IsCanonical()
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get IsContainer()
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get IsDS()
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Security.AccessControl.GenericAce*/ get_Item(/*int*/ index)
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*void*/ set_Item(/*int*/ index, /*System.Security.AccessControl.GenericAce*/ value)
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*byte */ get Revision()
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*void */ GetBinaryForm(/*byte[]*/ binaryForm, /*int*/ offset)
            {
            }
            /*void */ Purge(/*System.Security.Principal.SecurityIdentifier*/ sid)
            {
            }
            /*void */ RemoveInheritedAces()
            {
            }
            static $h = 1169714;
            static $f = 0b110001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":1759538,"p":[{"p":655361,"g":{"r":0,"d":0,"h":12886071602,"f":50429953},"n":"BinaryLength","d":1169714,"h":8591104306,"f":2195457},{"p":655361,"g":{"r":0,"d":0,"h":21476006194,"f":50429953},"n":"Count","d":1169714,"h":17181038898,"f":2195457},{"p":262145,"g":{"r":0,"d":0,"h":30065940786,"f":50331649},"n":"IsCanonical","d":1169714,"h":25770973490,"f":2097153},{"p":262145,"g":{"r":0,"d":0,"h":38655875378,"f":50331649},"n":"IsContainer","d":1169714,"h":34360908082,"f":2097153},{"p":262145,"g":{"r":0,"d":0,"h":47245809970,"f":50331649},"n":"IsDS","d":1169714,"h":42950842674,"f":2097153},{"p":1694002,"i":[{"n":"index","p":655361}],"g":{"r":0,"d":0,"h":55835744562,"f":50429953},"s":{"r":0,"d":0,"h":60130711858,"f":83984385},"n":"Item","o":"@$2","d":1169714,"h":51540777266,"f":2195457},{"p":393217,"g":{"r":0,"d":0,"h":68720646450,"f":50429953},"n":"Revision","d":1169714,"h":64425679154,"f":2195457}],"m":[{"r":65537,"p":[{"n":"binaryForm","p":$.$typeArray($.$$.System.Byte).$h},{"n":"offset","p":655361}],"n":"GetBinaryForm","d":1169714,"h":73015613746,"f":16875521},{"r":65537,"p":[{"n":"sid","p":445134}],"n":"Purge","d":1169714,"h":77310581042,"f":16777217},{"r":65537,"n":"RemoveInheritedAces","d":1169714,"h":81605548338,"f":16777217}],"c":[{"n":".ctor","o":"$ctor$2","d":1169714,"h":4296137010,"f":16777224}],"i":[31457281,31719425],"h":1169714}; }
            static get $b() { return $.$ssa.System.Security.AccessControl.GenericAcl; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.System.Collections.ICollection, $.$$.System.Collections.IEnumerable ]; }
            static get $fullName() { return `System.Security.AccessControl.CommonAcl`; }
        });
        
        $asm.$cls("$ssa.System.Security.AccessControl.NativeObjectSecurity", ($self) => class NativeObjectSecurity extends $.$ssa.System.Security.AccessControl.CommonObjectSecurity
        {
            $ctor$10(/*bool*/ isContainer, /*System.Security.AccessControl.ResourceType*/ resourceType)
            {
                super.$ctor$4(false);
                {
                }
                return this;
            }
            $ctor$6(/*bool*/ isContainer, /*System.Security.AccessControl.ResourceType*/ resourceType, /*System.Runtime.InteropServices.SafeHandle?*/ handle, /*System.Security.AccessControl.AccessControlSections*/ includeSections)
            {
                super.$ctor$4(false);
                {
                }
                return this;
            }
            $ctor$5(/*bool*/ isContainer, /*System.Security.AccessControl.ResourceType*/ resourceType, /*System.Runtime.InteropServices.SafeHandle?*/ handle, /*System.Security.AccessControl.AccessControlSections*/ includeSections, /*System.Security.AccessControl.NativeObjectSecurity.ExceptionFromErrorCode?*/ exceptionFromErrorCode, /*object?*/ exceptionContext)
            {
                super.$ctor$4(false);
                {
                }
                return this;
            }
            $ctor$9(/*bool*/ isContainer, /*System.Security.AccessControl.ResourceType*/ resourceType, /*System.Security.AccessControl.NativeObjectSecurity.ExceptionFromErrorCode?*/ exceptionFromErrorCode, /*object?*/ exceptionContext)
            {
                super.$ctor$4(false);
                {
                }
                return this;
            }
            $ctor$8(/*bool*/ isContainer, /*System.Security.AccessControl.ResourceType*/ resourceType, /*string?*/ name, /*System.Security.AccessControl.AccessControlSections*/ includeSections)
            {
                super.$ctor$4(false);
                {
                }
                return this;
            }
            $ctor$7(/*bool*/ isContainer, /*System.Security.AccessControl.ResourceType*/ resourceType, /*string?*/ name, /*System.Security.AccessControl.AccessControlSections*/ includeSections, /*System.Security.AccessControl.NativeObjectSecurity.ExceptionFromErrorCode?*/ exceptionFromErrorCode, /*object?*/ exceptionContext)
            {
                super.$ctor$4(false);
                {
                }
                return this;
            }
            /*void */ Persist$1(/*System.Runtime.InteropServices.SafeHandle*/ handle, /*System.Security.AccessControl.AccessControlSections*/ includeSections)
            {
            }
            /*void */ Persist$3(/*System.Runtime.InteropServices.SafeHandle*/ handle, /*System.Security.AccessControl.AccessControlSections*/ includeSections, /*object?*/ exceptionContext)
            {
            }
            /*void */ Persist$2(/*string*/ name, /*System.Security.AccessControl.AccessControlSections*/ includeSections)
            {
            }
            /*void */ Persist$4(/*string*/ name, /*System.Security.AccessControl.AccessControlSections*/ includeSections, /*object?*/ exceptionContext)
            {
            }
            static $_ExceptionFromErrorCode;
            static get ExceptionFromErrorCode()
            {
                let $cls = $.$ssa.System.Security.AccessControl.NativeObjectSecurity;
                return $cls.$_ExceptionFromErrorCode ??= $asm.$ncls("$ssa.System.Security.AccessControl.NativeObjectSecurity.ExceptionFromErrorCode", ($self) => class ExceptionFromErrorCode extends $.$$.System.MulticastDelegate
                {
                    $ctor(/*object*/ target, fn, anmodel)
                    {
                        this.$target = target;
                        this.$nativeFunction = fn;
                        if (anmodel) this.$nfmodel = anmodel;
                        if (typeof(target) === 'object') this._target = target;
                        return this;
                    }
                    /*System.Exception?*/ Invoke(/*$.$$.System.Int32*/ errorCode, /*$.$$.System.Nullable$$*/ name, /*$.$$.System.Nullable$$*/ handle, /*$.$$.System.Nullable$$*/ context)
                    {
                        return this.$nativeFunction.call(this.$target, errorCode, name, handle, context);
                    }
                    static $h = 2087218;
                    static $f = 0b10000000010000000;
                    static $k = 5;
                    static $$md;
                    static get $md() { return this.$$md ??= {"b":66191361,"m":[{"r":47251457,"p":[{"n":"errorCode","p":655361},{"n":"name","p":1310721},{"n":"handle","p":109445121},{"n":"context","p":131073}],"n":"Invoke","d":2087218,"h":8592021810,"f":16777345},{"r":57016321,"p":[{"n":"errorCode","p":655361},{"n":"name","p":1310721},{"n":"handle","p":109445121},{"n":"context","p":131073},{"n":"callback","p":14548993},{"n":"object","p":131073}],"n":"BeginInvoke","d":2087218,"h":12886989106,"f":16777345},{"r":47251457,"p":[{"n":"result","p":57016321}],"n":"EndInvoke","d":2087218,"h":17181956402,"f":16777345}],"c":[{"p":[{"n":"object","p":131073},{"n":"method","p":786433}],"n":".ctor","o":"$ctor$5","d":2087218,"h":4297054514,"f":16777217}],"i":[57212929,113246209],"d":2021682,"h":2087218}; }
                    static get $b() { return $.$$.System.MulticastDelegate; }
                    static $$i;
                    static get $i() { return this.$$i ??= [ $.$$.System.ICloneable, $.$$.System.Runtime.Serialization.ISerializable ]; }
                    static get $fullName() { return `System.Security.AccessControl.NativeObjectSecurity.ExceptionFromErrorCode`; }
                }, $cls, ($v) => $cls.$_ExceptionFromErrorCode = $v);
            }
            static $h = 2021682;
            static $f = 0b110001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":1235250,"m":[{"r":65537,"p":[{"n":"handle","p":109445121},{"n":"includeSections","p":252210}],"n":"Persist","o":"@$1","d":2021682,"h":30066792754,"f":16875524},{"r":65537,"p":[{"n":"handle","p":109445121},{"n":"includeSections","p":252210},{"n":"exceptionContext","p":131073}],"n":"Persist","o":"@$3","d":2021682,"h":34361760050,"f":16777220},{"r":65537,"p":[{"n":"name","p":1310721},{"n":"includeSections","p":252210}],"n":"Persist","o":"@$2","d":2021682,"h":38656727346,"f":16875524},{"r":65537,"p":[{"n":"name","p":1310721},{"n":"includeSections","p":252210},{"n":"exceptionContext","p":131073}],"n":"Persist","o":"@$4","d":2021682,"h":42951694642,"f":16777220}],"c":[{"p":[{"n":"isContainer","p":262145},{"n":"resourceType","p":2873650}],"n":".ctor","o":"$ctor$10","d":2021682,"h":4296988978,"f":16777220},{"p":[{"n":"isContainer","p":262145},{"n":"resourceType","p":2873650},{"n":"handle","p":109445121},{"n":"includeSections","p":252210}],"n":".ctor","o":"$ctor$6","d":2021682,"h":8591956274,"f":16777220},{"p":[{"n":"isContainer","p":262145},{"n":"resourceType","p":2873650},{"n":"handle","p":109445121},{"n":"includeSections","p":252210},{"n":"exceptionFromErrorCode","p":2087218},{"n":"exceptionContext","p":131073}],"n":".ctor","o":"$ctor$5","d":2021682,"h":12886923570,"f":16777220},{"p":[{"n":"isContainer","p":262145},{"n":"resourceType","p":2873650},{"n":"exceptionFromErrorCode","p":2087218},{"n":"exceptionContext","p":131073}],"n":".ctor","o":"$ctor$9","d":2021682,"h":17181890866,"f":16777220},{"p":[{"n":"isContainer","p":262145},{"n":"resourceType","p":2873650},{"n":"name","p":1310721},{"n":"includeSections","p":252210}],"n":".ctor","o":"$ctor$8","d":2021682,"h":21476858162,"f":16777220},{"p":[{"n":"isContainer","p":262145},{"n":"resourceType","p":2873650},{"n":"name","p":1310721},{"n":"includeSections","p":252210},{"n":"exceptionFromErrorCode","p":2087218},{"n":"exceptionContext","p":131073}],"n":".ctor","o":"$ctor$7","d":2021682,"h":25771825458,"f":16777220}],"j":[2087218],"h":2021682}; }
            static get $b() { return $.$ssa.System.Security.AccessControl.CommonObjectSecurity; }
            static get $fullName() { return `System.Security.AccessControl.NativeObjectSecurity`; }
        });
        
        $asm.$cls("$ssa.System.Security.AccessControl.ObjectAccessRule", ($self) => class ObjectAccessRule extends $.$ssa.System.Security.AccessControl.AccessRule
        {
            $ctor$3(/*System.Security.Principal.IdentityReference*/ identity, /*int*/ accessMask, /*bool*/ isInherited, /*System.Security.AccessControl.InheritanceFlags*/ inheritanceFlags, /*System.Security.AccessControl.PropagationFlags*/ propagationFlags, /*System.Guid*/ objectType, /*System.Guid*/ inheritedObjectType, /*System.Security.AccessControl.AccessControlType*/ type)
            {
                super.$ctor$2(null, 0, false, 0, 0, 0);
                {
                }
                return this;
            }
            /*System.Guid */ get InheritedObjectType()
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Security.AccessControl.ObjectAceFlags */ get ObjectFlags()
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Guid */ get ObjectType()
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            static $h = 2152754;
            static $f = 0b110001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":383282,"p":[{"p":56229889,"g":{"r":0,"d":0,"h":12887054642,"f":50331649},"n":"InheritedObjectType","d":2152754,"h":8592087346,"f":2097153},{"p":2283826,"g":{"r":0,"d":0,"h":21476989234,"f":50331649},"n":"ObjectFlags","d":2152754,"h":17182021938,"f":2097153},{"p":56229889,"g":{"r":0,"d":0,"h":30066923826,"f":50331649},"n":"ObjectType","d":2152754,"h":25771956530,"f":2097153}],"c":[{"p":[{"n":"identity","p":248526},{"n":"accessMask","p":655361},{"n":"isInherited","p":262145},{"n":"inheritanceFlags","p":1890610},{"n":"propagationFlags","p":2611506},{"n":"objectType","p":56229889},{"n":"inheritedObjectType","p":56229889},{"n":"type","p":317746}],"n":".ctor","o":"$ctor$3","d":2152754,"h":4297120050,"f":16777220}],"h":2152754}; }
            static get $b() { return $.$ssa.System.Security.AccessControl.AccessRule; }
            static get $fullName() { return `System.Security.AccessControl.ObjectAccessRule`; }
        });
        
        $asm.$cls("$ssa.System.Security.AccessControl.ObjectAuditRule", ($self) => class ObjectAuditRule extends $.$ssa.System.Security.AccessControl.AuditRule
        {
            $ctor$3(/*System.Security.Principal.IdentityReference*/ identity, /*int*/ accessMask, /*bool*/ isInherited, /*System.Security.AccessControl.InheritanceFlags*/ inheritanceFlags, /*System.Security.AccessControl.PropagationFlags*/ propagationFlags, /*System.Guid*/ objectType, /*System.Guid*/ inheritedObjectType, /*System.Security.AccessControl.AuditFlags*/ auditFlags)
            {
                super.$ctor$2(null, 0, false, 0, 0, 0);
                {
                }
                return this;
            }
            /*System.Guid */ get InheritedObjectType()
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Security.AccessControl.ObjectAceFlags */ get ObjectFlags()
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Guid */ get ObjectType()
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            static $h = 2349362;
            static $f = 0b110001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":842034,"p":[{"p":56229889,"g":{"r":0,"d":0,"h":12887251250,"f":50331649},"n":"InheritedObjectType","d":2349362,"h":8592283954,"f":2097153},{"p":2283826,"g":{"r":0,"d":0,"h":21477185842,"f":50331649},"n":"ObjectFlags","d":2349362,"h":17182218546,"f":2097153},{"p":56229889,"g":{"r":0,"d":0,"h":30067120434,"f":50331649},"n":"ObjectType","d":2349362,"h":25772153138,"f":2097153}],"c":[{"p":[{"n":"identity","p":248526},{"n":"accessMask","p":655361},{"n":"isInherited","p":262145},{"n":"inheritanceFlags","p":1890610},{"n":"propagationFlags","p":2611506},{"n":"objectType","p":56229889},{"n":"inheritedObjectType","p":56229889},{"n":"auditFlags","p":776498}],"n":".ctor","o":"$ctor$3","d":2349362,"h":4297316658,"f":16777220}],"h":2349362}; }
            static get $b() { return $.$ssa.System.Security.AccessControl.AuditRule; }
            static get $fullName() { return `System.Security.AccessControl.ObjectAuditRule`; }
        });
        
        $asm.$cls("$ssa.System.Security.AccessControl.QualifiedAce", ($self) => class QualifiedAce extends $.$ssa.System.Security.AccessControl.KnownAce
        {
            $ctor$3()
            {
                super.$ctor$2();
                {
                }
                return this;
            }
            /*System.Security.AccessControl.AceQualifier */ get AceQualifier()
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get IsCallback()
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ get OpaqueLength()
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*byte[]? */ GetOpaque()
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*void */ SetOpaque(/*byte[]?*/ opaque)
            {
            }
            static $h = 2677042;
            static $f = 0b110001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":1956146,"p":[{"p":645426,"g":{"r":0,"d":0,"h":12887578930,"f":50331649},"n":"AceQualifier","d":2677042,"h":8592611634,"f":2097153},{"p":262145,"g":{"r":0,"d":0,"h":21477513522,"f":50331649},"n":"IsCallback","d":2677042,"h":17182546226,"f":2097153},{"p":655361,"g":{"r":0,"d":0,"h":30067448114,"f":50331649},"n":"OpaqueLength","d":2677042,"h":25772480818,"f":2097153}],"m":[{"r":$.$typeArray($.$$.System.Byte).$h,"n":"GetOpaque","d":2677042,"h":34362415410,"f":16777217},{"r":65537,"p":[{"n":"opaque","p":$.$typeArray($.$$.System.Byte).$h}],"n":"SetOpaque","d":2677042,"h":38657382706,"f":16777217}],"c":[{"n":".ctor","o":"$ctor$3","d":2677042,"h":4297644338,"f":16777224}],"h":2677042}; }
            static get $b() { return $.$ssa.System.Security.AccessControl.KnownAce; }
            static get $fullName() { return `System.Security.AccessControl.QualifiedAce`; }
        });
        
        $asm.$cls("$ssa.System.Security.AccessControl.ObjectSecurity<>", (T) => $asm.$gt("$ssa.System.Security.AccessControl.ObjectSecurity<>", [T], ($self) => class ObjectSecurity$$ extends $.$ssa.System.Security.AccessControl.NativeObjectSecurity
        {
            $ctor$15(/*bool*/ isContainer, /*System.Security.AccessControl.ResourceType*/ resourceType)
            {
                super.$ctor$10(false, 0);
                {
                }
                return this;
            }
            $ctor$12(/*bool*/ isContainer, /*System.Security.AccessControl.ResourceType*/ resourceType, /*System.Runtime.InteropServices.SafeHandle?*/ safeHandle, /*System.Security.AccessControl.AccessControlSections*/ includeSections)
            {
                super.$ctor$10(false, 0);
                {
                }
                return this;
            }
            $ctor$11(/*bool*/ isContainer, /*System.Security.AccessControl.ResourceType*/ resourceType, /*System.Runtime.InteropServices.SafeHandle?*/ safeHandle, /*System.Security.AccessControl.AccessControlSections*/ includeSections, /*System.Security.AccessControl.NativeObjectSecurity.ExceptionFromErrorCode?*/ exceptionFromErrorCode, /*object?*/ exceptionContext)
            {
                super.$ctor$10(false, 0);
                {
                }
                return this;
            }
            $ctor$14(/*bool*/ isContainer, /*System.Security.AccessControl.ResourceType*/ resourceType, /*string?*/ name, /*System.Security.AccessControl.AccessControlSections*/ includeSections)
            {
                super.$ctor$10(false, 0);
                {
                }
                return this;
            }
            $ctor$13(/*bool*/ isContainer, /*System.Security.AccessControl.ResourceType*/ resourceType, /*string?*/ name, /*System.Security.AccessControl.AccessControlSections*/ includeSections, /*System.Security.AccessControl.NativeObjectSecurity.ExceptionFromErrorCode?*/ exceptionFromErrorCode, /*object?*/ exceptionContext)
            {
                super.$ctor$10(false, 0);
                {
                }
                return this;
            }
            /*System.Type */ get AccessRightType()
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Type */ get AccessRuleType()
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Type */ get AuditRuleType()
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Security.AccessControl.AccessRule */ AccessRuleFactory(/*System.Security.Principal.IdentityReference*/ identityReference, /*int*/ accessMask, /*bool*/ isInherited, /*System.Security.AccessControl.InheritanceFlags*/ inheritanceFlags, /*System.Security.AccessControl.PropagationFlags*/ propagationFlags, /*System.Security.AccessControl.AccessControlType*/ type)
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*void */ AddAccessRule$1(/*System.Security.AccessControl.AccessRule<T>*/ rule)
            {
            }
            /*void */ AddAuditRule$1(/*System.Security.AccessControl.AuditRule<T>*/ rule)
            {
            }
            /*System.Security.AccessControl.AuditRule */ AuditRuleFactory(/*System.Security.Principal.IdentityReference*/ identityReference, /*int*/ accessMask, /*bool*/ isInherited, /*System.Security.AccessControl.InheritanceFlags*/ inheritanceFlags, /*System.Security.AccessControl.PropagationFlags*/ propagationFlags, /*System.Security.AccessControl.AuditFlags*/ flags)
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*void */ Persist$5(/*System.Runtime.InteropServices.SafeHandle*/ handle)
            {
            }
            /*void */ Persist$6(/*string*/ name)
            {
            }
            /*bool */ RemoveAccessRule$1(/*System.Security.AccessControl.AccessRule<T>*/ rule)
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*void */ RemoveAccessRuleAll$1(/*System.Security.AccessControl.AccessRule<T>*/ rule)
            {
            }
            /*void */ RemoveAccessRuleSpecific$1(/*System.Security.AccessControl.AccessRule<T>*/ rule)
            {
            }
            /*bool */ RemoveAuditRule$1(/*System.Security.AccessControl.AuditRule<T>*/ rule)
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*void */ RemoveAuditRuleAll$1(/*System.Security.AccessControl.AuditRule<T>*/ rule)
            {
            }
            /*void */ RemoveAuditRuleSpecific$1(/*System.Security.AccessControl.AuditRule<T>*/ rule)
            {
            }
            /*void */ ResetAccessRule$1(/*System.Security.AccessControl.AccessRule<T>*/ rule)
            {
            }
            /*void */ SetAccessRule$1(/*System.Security.AccessControl.AccessRule<T>*/ rule)
            {
            }
            /*void */ SetAuditRule$1(/*System.Security.AccessControl.AuditRule<T>*/ rule)
            {
            }
            static $h = 2480434;
            static $g = 1;
            static $f = 0b1110001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":2021682,"p":[{"p":142475265,"g":{"r":0,"d":0,"h":Number(BigInt(this.$h)|0x700000000n),"f":50364417},"n":"AccessRightType","d":this.$h,"h":Number(BigInt(this.$h)|0x600000000n),"f":2129921},{"p":142475265,"g":{"r":0,"d":0,"h":Number(BigInt(this.$h)|0x900000000n),"f":50364417},"n":"AccessRuleType","d":this.$h,"h":Number(BigInt(this.$h)|0x800000000n),"f":2129921},{"p":142475265,"g":{"r":0,"d":0,"h":Number(BigInt(this.$h)|0xB00000000n),"f":50364417},"n":"AuditRuleType","d":this.$h,"h":Number(BigInt(this.$h)|0xA00000000n),"f":2129921}],"m":[{"r":383282,"p":[{"n":"identityReference","p":248526},{"n":"accessMask","p":655361},{"n":"isInherited","p":262145},{"n":"inheritanceFlags","p":1890610},{"n":"propagationFlags","p":2611506},{"n":"type","p":317746}],"n":"AccessRuleFactory","d":this.$h,"h":Number(BigInt(this.$h)|0xC00000000n),"f":16809985},{"r":65537,"p":[{"n":"rule","p":$.$ssa.System.Security.AccessControl.AccessRule$$(T).$h}],"n":"AddAccessRule","o":"@$1","d":this.$h,"h":Number(BigInt(this.$h)|0xD00000000n),"f":16777345},{"r":65537,"p":[{"n":"rule","p":$.$ssa.System.Security.AccessControl.AuditRule$$(T).$h}],"n":"AddAuditRule","o":"@$1","d":this.$h,"h":Number(BigInt(this.$h)|0xE00000000n),"f":16777345},{"r":842034,"p":[{"n":"identityReference","p":248526},{"n":"accessMask","p":655361},{"n":"isInherited","p":262145},{"n":"inheritanceFlags","p":1890610},{"n":"propagationFlags","p":2611506},{"n":"flags","p":776498}],"n":"AuditRuleFactory","d":this.$h,"h":Number(BigInt(this.$h)|0xF00000000n),"f":16809985},{"r":65537,"p":[{"n":"handle","p":109445121}],"n":"Persist","o":"@$5","d":this.$h,"h":Number(BigInt(this.$h)|0x1000000000n),"f":16777232},{"r":65537,"p":[{"n":"name","p":1310721}],"n":"Persist","o":"@$6","d":this.$h,"h":Number(BigInt(this.$h)|0x1100000000n),"f":16777232},{"r":262145,"p":[{"n":"rule","p":$.$ssa.System.Security.AccessControl.AccessRule$$(T).$h}],"n":"RemoveAccessRule","o":"@$1","d":this.$h,"h":Number(BigInt(this.$h)|0x1200000000n),"f":16777345},{"r":65537,"p":[{"n":"rule","p":$.$ssa.System.Security.AccessControl.AccessRule$$(T).$h}],"n":"RemoveAccessRuleAll","o":"@$1","d":this.$h,"h":Number(BigInt(this.$h)|0x1300000000n),"f":16777345},{"r":65537,"p":[{"n":"rule","p":$.$ssa.System.Security.AccessControl.AccessRule$$(T).$h}],"n":"RemoveAccessRuleSpecific","o":"@$1","d":this.$h,"h":Number(BigInt(this.$h)|0x1400000000n),"f":16777345},{"r":262145,"p":[{"n":"rule","p":$.$ssa.System.Security.AccessControl.AuditRule$$(T).$h}],"n":"RemoveAuditRule","o":"@$1","d":this.$h,"h":Number(BigInt(this.$h)|0x1500000000n),"f":16777345},{"r":65537,"p":[{"n":"rule","p":$.$ssa.System.Security.AccessControl.AuditRule$$(T).$h}],"n":"RemoveAuditRuleAll","o":"@$1","d":this.$h,"h":Number(BigInt(this.$h)|0x1600000000n),"f":16777345},{"r":65537,"p":[{"n":"rule","p":$.$ssa.System.Security.AccessControl.AuditRule$$(T).$h}],"n":"RemoveAuditRuleSpecific","o":"@$1","d":this.$h,"h":Number(BigInt(this.$h)|0x1700000000n),"f":16777345},{"r":65537,"p":[{"n":"rule","p":$.$ssa.System.Security.AccessControl.AccessRule$$(T).$h}],"n":"ResetAccessRule","o":"@$1","d":this.$h,"h":Number(BigInt(this.$h)|0x1800000000n),"f":16777345},{"r":65537,"p":[{"n":"rule","p":$.$ssa.System.Security.AccessControl.AccessRule$$(T).$h}],"n":"SetAccessRule","o":"@$1","d":this.$h,"h":Number(BigInt(this.$h)|0x1900000000n),"f":16777345},{"r":65537,"p":[{"n":"rule","p":$.$ssa.System.Security.AccessControl.AuditRule$$(T).$h}],"n":"SetAuditRule","o":"@$1","d":this.$h,"h":Number(BigInt(this.$h)|0x1A00000000n),"f":16777345}],"c":[{"p":[{"n":"isContainer","p":262145},{"n":"resourceType","p":2873650}],"n":".ctor","o":"$ctor$15","d":this.$h,"h":Number(BigInt(this.$h)|0x100000000n),"f":16777220},{"p":[{"n":"isContainer","p":262145},{"n":"resourceType","p":2873650},{"n":"safeHandle","p":109445121},{"n":"includeSections","p":252210}],"n":".ctor","o":"$ctor$12","d":this.$h,"h":Number(BigInt(this.$h)|0x200000000n),"f":16777220},{"p":[{"n":"isContainer","p":262145},{"n":"resourceType","p":2873650},{"n":"safeHandle","p":109445121},{"n":"includeSections","p":252210},{"n":"exceptionFromErrorCode","p":2087218},{"n":"exceptionContext","p":131073}],"n":".ctor","o":"$ctor$11","d":this.$h,"h":Number(BigInt(this.$h)|0x300000000n),"f":16777220},{"p":[{"n":"isContainer","p":262145},{"n":"resourceType","p":2873650},{"n":"name","p":1310721},{"n":"includeSections","p":252210}],"n":".ctor","o":"$ctor$14","d":this.$h,"h":Number(BigInt(this.$h)|0x400000000n),"f":16777220},{"p":[{"n":"isContainer","p":262145},{"n":"resourceType","p":2873650},{"n":"name","p":1310721},{"n":"includeSections","p":252210},{"n":"exceptionFromErrorCode","p":2087218},{"n":"exceptionContext","p":131073}],"n":".ctor","o":"$ctor$13","d":this.$h,"h":Number(BigInt(this.$h)|0x500000000n),"f":16777220}],"g":[T?.$h??1507328],"s":[{"n":"T","f":2}],"r":1,"h":this.$h}; }
            static get $b() { return $.$ssa.System.Security.AccessControl.NativeObjectSecurity; }
            static get $fullName() { return `System.Security.AccessControl.ObjectSecurity<${T?.$fullName}>`; }
        }));
        
        $asm.$cls("$ssa.System.Security.AccessControl.AceEnumerator", ($self) => class AceEnumerator extends $.$$.System.Object
        {
            $ctor$1()
            {
                super.$ctor();
                {
                }
                return this;
            }
            /*System.Security.AccessControl.GenericAce */ get Current()
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*object */ get System$Collections$IEnumerator$Current()
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ MoveNext()
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*void */ Reset()
            {
            }
            //Generated interface implemetation for System.Collections.IEnumerator.MoveNext()
            System$Collections$IEnumerator$MoveNext()
            {
                return this.MoveNext(...arguments);
            }
            //Generated interface implemetation for System.Collections.IEnumerator.Reset()
            System$Collections$IEnumerator$Reset()
            {
                return this.Reset(...arguments);
            }
            static $h = 514354;
            static $f = 0b10010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":1694002,"g":{"r":0,"d":0,"h":12885416242,"f":50331649},"n":"Current","d":514354,"h":8590448946,"f":2097153},{"p":131073,"g":{"r":0,"d":0,"h":21475350834,"f":50331650},"n":"{31850497}.Current","o":"System$Collections$IEnumerator$Current","d":514354,"h":17180383538,"f":2097154}],"m":[{"r":262145,"n":"MoveNext","d":514354,"h":25770318130,"f":16777217},{"r":65537,"n":"Reset","d":514354,"h":30065285426,"f":16777217}],"c":[{"n":".ctor","o":"$ctor$1","d":514354,"h":4295481650,"f":16777224}],"i":[31850497],"h":514354}; }
            static get $b() { return $.$$.System.Object; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.System.Collections.IEnumerator ]; }
            static get $fullName() { return `System.Security.AccessControl.AceEnumerator`; }
        });
        
        $asm.$cls("$ssa.System.Security.Policy.Evidence", ($self) => class Evidence extends $.$$.System.Object
        {
            $ctor$1()
            {
                super.$ctor();
                {
                }
                return this;
            }
            $ctor$2(/*object[]*/ hostEvidence, /*object[]*/ assemblyEvidence)
            {
                super.$ctor();
                {
                }
                return this;
            }
            $ctor$3(/*System.Security.Policy.Evidence*/ evidence)
            {
                super.$ctor();
                {
                }
                return this;
            }
            $ctor$4(/*System.Security.Policy.EvidenceBase[]*/ hostEvidence, /*System.Security.Policy.EvidenceBase[]*/ assemblyEvidence)
            {
                super.$ctor();
                {
                }
                return this;
            }
            /*int */ get Count()
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get IsReadOnly()
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get IsSynchronized()
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get Locked()
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ set Locked(value)
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*object */ get SyncRoot()
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*void */ AddAssembly(/*object*/ id)
            {
            }
            /*void */ AddAssemblyEvidence(T, /*T*/ evidence)
            {
            }
            /*void */ AddHost(/*object*/ id)
            {
            }
            /*void */ AddHostEvidence(T, /*T*/ evidence)
            {
            }
            /*void */ Clear()
            {
            }
            /*System.Security.Policy.Evidence? */ Clone()
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*void */ CopyTo(/*System.Array*/ array, /*int*/ index)
            {
            }
            /*System.Collections.IEnumerator */ GetAssemblyEnumerator()
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*T? */ GetAssemblyEvidence(T)
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Collections.IEnumerator */ GetEnumerator()
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Collections.IEnumerator */ GetHostEnumerator()
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*T? */ GetHostEvidence(T)
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*void */ Merge(/*System.Security.Policy.Evidence*/ evidence)
            {
            }
            /*void */ RemoveType(/*System.Type*/ t)
            {
            }
            //Generated interface implemetation for System.Collections.ICollection.CopyTo(System.Array, int)
            System$Collections$ICollection$CopyTo()
            {
                return this.CopyTo(...arguments);
            }
            //Generated interface implemetation for System.Collections.ICollection.Count.get
            get System$Collections$ICollection$Count()
            {
                return this.Count;
            }
            //Generated interface implemetation for System.Collections.ICollection.SyncRoot.get
            get System$Collections$ICollection$SyncRoot()
            {
                return this.SyncRoot;
            }
            //Generated interface implemetation for System.Collections.ICollection.IsSynchronized.get
            get System$Collections$ICollection$IsSynchronized()
            {
                return this.IsSynchronized;
            }
            //Generated interface implemetation for System.Collections.IEnumerable.GetEnumerator()
            System$Collections$IEnumerable$GetEnumerator()
            {
                return this.GetEnumerator(...arguments);
            }
            static $h = 3070258;
            static $f = 0b10010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":655361,"g":{"r":0,"d":0,"h":25772874034,"f":50331649},"n":"Count","d":3070258,"h":21477906738,"f":2097153,"a":[{"t":70909953,"c":8660844545,"a":[{"v":"Evidence should not be treated as an ICollection. Use GetHostEnumerator and GetAssemblyEnumerator to iterate over the evidence to collect a count.","t":1310721}]}]},{"p":262145,"g":{"r":0,"d":0,"h":34362808626,"f":50331649},"n":"IsReadOnly","d":3070258,"h":30067841330,"f":2097153},{"p":262145,"g":{"r":0,"d":0,"h":42952743218,"f":50331649},"n":"IsSynchronized","d":3070258,"h":38657775922,"f":2097153},{"p":262145,"g":{"r":0,"d":0,"h":51542677810,"f":50331649},"s":{"r":0,"d":0,"h":55837645106,"f":83886081},"n":"Locked","d":3070258,"h":47247710514,"f":2097153},{"p":131073,"g":{"r":0,"d":0,"h":64427579698,"f":50331649},"n":"SyncRoot","d":3070258,"h":60132612402,"f":2097153}],"m":[{"r":65537,"p":[{"n":"id","p":131073}],"n":"AddAssembly","d":3070258,"h":68722546994,"f":16777217,"a":[{"t":70909953,"c":8660844545,"a":[{"v":"Evidence.AddAssembly has been deprecated. Use AddAssemblyEvidence instead.","t":1310721}]}]},{"r":65537,"p":[{"n":"evidence","p":(T) => T.$h}],"g":["T"],"n":"AddAssemblyEvidence","d":3070258,"h":73017514290,"f":16908289},{"r":65537,"p":[{"n":"id","p":131073}],"n":"AddHost","d":3070258,"h":77312481586,"f":16777217,"a":[{"t":70909953,"c":8660844545,"a":[{"v":"Evidence.AddHost has been deprecated. Use AddHostEvidence instead.","t":1310721}]}]},{"r":65537,"p":[{"n":"evidence","p":(T) => T.$h}],"g":["T"],"n":"AddHostEvidence","d":3070258,"h":81607448882,"f":16908289},{"r":65537,"n":"Clear","d":3070258,"h":85902416178,"f":16777217},{"r":3070258,"n":"Clone","d":3070258,"h":90197383474,"f":16777217},{"r":65537,"p":[{"n":"array","p":1245185},{"n":"index","p":655361}],"n":"CopyTo","d":3070258,"h":94492350770,"f":16777217,"a":[{"t":70909953,"c":8660844545,"a":[{"v":"Evidence should not be treated as an ICollection. Use the GetHostEnumerator and GetAssemblyEnumerator methods rather than using CopyTo.","t":1310721}]}]},{"r":31850497,"n":"GetAssemblyEnumerator","d":3070258,"h":98787318066,"f":16777217},{"r":(T) => T.$h,"g":["T"],"n":"GetAssemblyEvidence","d":3070258,"h":103082285362,"f":16908289},{"r":31850497,"n":"GetEnumerator","d":3070258,"h":107377252658,"f":16777217,"a":[{"t":70909953,"c":8660844545,"a":[{"v":"GetEnumerator is obsolete. Use GetAssemblyEnumerator and GetHostEnumerator instead.","t":1310721}]}]},{"r":31850497,"n":"GetHostEnumerator","d":3070258,"h":111672219954,"f":16777217},{"r":(T) => T.$h,"g":["T"],"n":"GetHostEvidence","d":3070258,"h":115967187250,"f":16908289},{"r":65537,"p":[{"n":"evidence","p":3070258}],"n":"Merge","d":3070258,"h":120262154546,"f":16777217},{"r":65537,"p":[{"n":"t","p":142475265}],"n":"RemoveType","d":3070258,"h":124557121842,"f":16777217}],"c":[{"n":".ctor","o":"$ctor$1","d":3070258,"h":4298037554,"f":16777217},{"p":[{"n":"hostEvidence","p":$.$typeArray($.$$.System.Object).$h},{"n":"assemblyEvidence","p":$.$typeArray($.$$.System.Object).$h}],"n":".ctor","o":"$ctor$2","d":3070258,"h":8593004850,"f":16777217,"a":[{"t":70909953,"c":8660844545,"a":[{"v":"This constructor is obsolete. Use the constructor which accepts arrays of EvidenceBase instead.","t":1310721}]}]},{"p":[{"n":"evidence","p":3070258}],"n":".ctor","o":"$ctor$3","d":3070258,"h":12887972146,"f":16777217},{"p":[{"n":"hostEvidence","p":$.$typeArray($.$ssa.System.Security.Policy.EvidenceBase).$h},{"n":"assemblyEvidence","p":$.$typeArray($.$ssa.System.Security.Policy.EvidenceBase).$h}],"n":".ctor","o":"$ctor$4","d":3070258,"h":17182939442,"f":16777217}],"i":[31457281,31719425],"h":3070258}; }
            static get $b() { return $.$$.System.Object; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.System.Collections.ICollection, $.$$.System.Collections.IEnumerable ]; }
            static get $fullName() { return `System.Security.Policy.Evidence`; }
        });
        
        $asm.$cls("$ssa.System.Security.AccessControl.CommonSecurityDescriptor", ($self) => class CommonSecurityDescriptor extends $.$ssa.System.Security.AccessControl.GenericSecurityDescriptor
        {
            $ctor$2(/*bool*/ isContainer, /*bool*/ isDS, /*byte[]*/ binaryForm, /*int*/ offset)
            {
                super.$ctor$1();
                {
                }
                return this;
            }
            $ctor$4(/*bool*/ isContainer, /*bool*/ isDS, /*System.Security.AccessControl.ControlFlags*/ flags, /*System.Security.Principal.SecurityIdentifier?*/ owner, /*System.Security.Principal.SecurityIdentifier?*/ group, /*System.Security.AccessControl.SystemAcl?*/ systemAcl, /*System.Security.AccessControl.DiscretionaryAcl?*/ discretionaryAcl)
            {
                super.$ctor$1();
                {
                }
                return this;
            }
            $ctor$5(/*bool*/ isContainer, /*bool*/ isDS, /*System.Security.AccessControl.RawSecurityDescriptor*/ rawSecurityDescriptor)
            {
                super.$ctor$1();
                {
                }
                return this;
            }
            $ctor$3(/*bool*/ isContainer, /*bool*/ isDS, /*string*/ sddlForm)
            {
                super.$ctor$1();
                {
                }
                return this;
            }
            /*System.Security.AccessControl.ControlFlags */ get ControlFlags()
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Security.AccessControl.DiscretionaryAcl? */ get DiscretionaryAcl()
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Security.AccessControl.DiscretionaryAcl? */ set DiscretionaryAcl(value)
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Security.Principal.SecurityIdentifier? */ get Group()
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Security.Principal.SecurityIdentifier? */ set Group(value)
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get IsContainer()
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get IsDiscretionaryAclCanonical()
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get IsDS()
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get IsSystemAclCanonical()
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Security.Principal.SecurityIdentifier? */ get Owner()
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Security.Principal.SecurityIdentifier? */ set Owner(value)
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Security.AccessControl.SystemAcl? */ get SystemAcl()
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Security.AccessControl.SystemAcl? */ set SystemAcl(value)
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*void */ AddDiscretionaryAcl(/*byte*/ revision, /*int*/ trusted)
            {
            }
            /*void */ AddSystemAcl(/*byte*/ revision, /*int*/ trusted)
            {
            }
            /*void */ PurgeAccessControl(/*System.Security.Principal.SecurityIdentifier*/ sid)
            {
            }
            /*void */ PurgeAudit(/*System.Security.Principal.SecurityIdentifier*/ sid)
            {
            }
            /*void */ SetDiscretionaryAclProtection(/*bool*/ isProtected, /*bool*/ preserveInheritance)
            {
            }
            /*void */ SetSystemAclProtection(/*bool*/ isProtected, /*bool*/ preserveInheritance)
            {
            }
            static $h = 1300786;
            static $f = 0b10010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":1825074,"p":[{"p":1497394,"g":{"r":0,"d":0,"h":25771104562,"f":50364417},"n":"ControlFlags","d":1300786,"h":21476137266,"f":2129921},{"p":1628466,"g":{"r":0,"d":0,"h":34361039154,"f":50331649},"s":{"r":0,"d":0,"h":38656006450,"f":83886081},"n":"DiscretionaryAcl","d":1300786,"h":30066071858,"f":2097153},{"p":445134,"g":{"r":0,"d":0,"h":47245941042,"f":50364417},"s":{"r":0,"d":0,"h":51540908338,"f":83918849},"n":"Group","d":1300786,"h":42950973746,"f":2129921},{"p":262145,"g":{"r":0,"d":0,"h":60130842930,"f":50331649},"n":"IsContainer","d":1300786,"h":55835875634,"f":2097153},{"p":262145,"g":{"r":0,"d":0,"h":68720777522,"f":50331649},"n":"IsDiscretionaryAclCanonical","d":1300786,"h":64425810226,"f":2097153},{"p":262145,"g":{"r":0,"d":0,"h":77310712114,"f":50331649},"n":"IsDS","d":1300786,"h":73015744818,"f":2097153},{"p":262145,"g":{"r":0,"d":0,"h":85900646706,"f":50331649},"n":"IsSystemAclCanonical","d":1300786,"h":81605679410,"f":2097153},{"p":445134,"g":{"r":0,"d":0,"h":94490581298,"f":50364417},"s":{"r":0,"d":0,"h":98785548594,"f":83918849},"n":"Owner","d":1300786,"h":90195614002,"f":2129921},{"p":3004722,"g":{"r":0,"d":0,"h":107375483186,"f":50331649},"s":{"r":0,"d":0,"h":111670450482,"f":83886081},"n":"SystemAcl","d":1300786,"h":103080515890,"f":2097153}],"m":[{"r":65537,"p":[{"n":"revision","p":393217},{"n":"trusted","p":655361}],"n":"AddDiscretionaryAcl","d":1300786,"h":115965417778,"f":16777217},{"r":65537,"p":[{"n":"revision","p":393217},{"n":"trusted","p":655361}],"n":"AddSystemAcl","d":1300786,"h":120260385074,"f":16777217},{"r":65537,"p":[{"n":"sid","p":445134}],"n":"PurgeAccessControl","d":1300786,"h":124555352370,"f":16777217},{"r":65537,"p":[{"n":"sid","p":445134}],"n":"PurgeAudit","d":1300786,"h":128850319666,"f":16777217},{"r":65537,"p":[{"n":"isProtected","p":262145},{"n":"preserveInheritance","p":262145}],"n":"SetDiscretionaryAclProtection","d":1300786,"h":133145286962,"f":16777217},{"r":65537,"p":[{"n":"isProtected","p":262145},{"n":"preserveInheritance","p":262145}],"n":"SetSystemAclProtection","d":1300786,"h":137440254258,"f":16777217}],"c":[{"p":[{"n":"isContainer","p":262145},{"n":"isDS","p":262145},{"n":"binaryForm","p":$.$typeArray($.$$.System.Byte).$h},{"n":"offset","p":655361}],"n":".ctor","o":"$ctor$2","d":1300786,"h":4296268082,"f":16777217},{"p":[{"n":"isContainer","p":262145},{"n":"isDS","p":262145},{"n":"flags","p":1497394},{"n":"owner","p":445134},{"n":"group","p":445134},{"n":"systemAcl","p":3004722},{"n":"discretionaryAcl","p":1628466}],"n":".ctor","o":"$ctor$4","d":1300786,"h":8591235378,"f":16777217},{"p":[{"n":"isContainer","p":262145},{"n":"isDS","p":262145},{"n":"rawSecurityDescriptor","p":2808114}],"n":".ctor","o":"$ctor$5","d":1300786,"h":12886202674,"f":16777217},{"p":[{"n":"isContainer","p":262145},{"n":"isDS","p":262145},{"n":"sddlForm","p":1310721}],"n":".ctor","o":"$ctor$3","d":1300786,"h":17181169970,"f":16777217}],"h":1300786}; }
            static get $b() { return $.$ssa.System.Security.AccessControl.GenericSecurityDescriptor; }
            static get $fullName() { return `System.Security.AccessControl.CommonSecurityDescriptor`; }
        });
        
        $asm.$cls("$ssa.System.Security.AccessControl.CustomAce", ($self) => class CustomAce extends $.$ssa.System.Security.AccessControl.GenericAce
        {
            /*int*/ static MaxOpaqueLength = 0;
            $ctor$2(/*System.Security.AccessControl.AceType*/ type, /*System.Security.AccessControl.AceFlags*/ flags, /*byte[]?*/ opaque)
            {
                super.$ctor$1();
                {
                }
                return this;
            }
            /*int */ get BinaryLength()
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ get OpaqueLength()
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*void */ GetBinaryForm(/*byte[]*/ binaryForm, /*int*/ offset)
            {
            }
            /*byte[]? */ GetOpaque()
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*void */ SetOpaque(/*byte[]?*/ opaque)
            {
            }
            static $h = 1562930;
            static $f = 0b10010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":1694002,"p":[{"p":655361,"g":{"r":0,"d":0,"h":17181432114,"f":50364417},"n":"BinaryLength","d":1562930,"h":12886464818,"f":2129921},{"p":655361,"g":{"r":0,"d":0,"h":25771366706,"f":50331649},"n":"OpaqueLength","d":1562930,"h":21476399410,"f":2097153}],"m":[{"r":65537,"p":[{"n":"binaryForm","p":$.$typeArray($.$$.System.Byte).$h},{"n":"offset","p":655361}],"n":"GetBinaryForm","d":1562930,"h":30066334002,"f":16809985},{"r":$.$typeArray($.$$.System.Byte).$h,"n":"GetOpaque","d":1562930,"h":34361301298,"f":16777217},{"r":65537,"p":[{"n":"opaque","p":$.$typeArray($.$$.System.Byte).$h}],"n":"SetOpaque","d":1562930,"h":38656268594,"f":16777217}],"l":[{"t":655361,"n":"MaxOpaqueLength","d":1562930,"h":4296530226,"f":4194337}],"c":[{"p":[{"n":"type","p":710962},{"n":"flags","p":579890},{"n":"opaque","p":$.$typeArray($.$$.System.Byte).$h}],"n":".ctor","o":"$ctor$2","d":1562930,"h":8591497522,"f":16777217}],"h":1562930}; }
            static get $b() { return $.$ssa.System.Security.AccessControl.GenericAce; }
            static get $fullName() { return `System.Security.AccessControl.CustomAce`; }
        });
        
        $asm.$cls("$ssa.System.Security.AccessControl.RawSecurityDescriptor", ($self) => class RawSecurityDescriptor extends $.$ssa.System.Security.AccessControl.GenericSecurityDescriptor
        {
            $ctor$2(/*byte[]*/ binaryForm, /*int*/ offset)
            {
                super.$ctor$1();
                {
                }
                return this;
            }
            $ctor$4(/*System.Security.AccessControl.ControlFlags*/ flags, /*System.Security.Principal.SecurityIdentifier?*/ owner, /*System.Security.Principal.SecurityIdentifier?*/ group, /*System.Security.AccessControl.RawAcl?*/ systemAcl, /*System.Security.AccessControl.RawAcl?*/ discretionaryAcl)
            {
                super.$ctor$1();
                {
                }
                return this;
            }
            $ctor$3(/*string*/ sddlForm)
            {
                super.$ctor$1();
                {
                }
                return this;
            }
            /*System.Security.AccessControl.ControlFlags */ get ControlFlags()
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Security.AccessControl.RawAcl? */ get DiscretionaryAcl()
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Security.AccessControl.RawAcl? */ set DiscretionaryAcl(value)
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Security.Principal.SecurityIdentifier? */ get Group()
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Security.Principal.SecurityIdentifier? */ set Group(value)
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Security.Principal.SecurityIdentifier? */ get Owner()
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Security.Principal.SecurityIdentifier? */ set Owner(value)
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*byte */ get ResourceManagerControl()
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*byte */ set ResourceManagerControl(value)
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Security.AccessControl.RawAcl? */ get SystemAcl()
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Security.AccessControl.RawAcl? */ set SystemAcl(value)
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*void */ SetFlags(/*System.Security.AccessControl.ControlFlags*/ flags)
            {
            }
            static $h = 2808114;
            static $f = 0b10010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":1825074,"p":[{"p":1497394,"g":{"r":0,"d":0,"h":21477644594,"f":50364417},"n":"ControlFlags","d":2808114,"h":17182677298,"f":2129921},{"p":2742578,"g":{"r":0,"d":0,"h":30067579186,"f":50331649},"s":{"r":0,"d":0,"h":34362546482,"f":83886081},"n":"DiscretionaryAcl","d":2808114,"h":25772611890,"f":2097153},{"p":445134,"g":{"r":0,"d":0,"h":42952481074,"f":50364417},"s":{"r":0,"d":0,"h":47247448370,"f":83918849},"n":"Group","d":2808114,"h":38657513778,"f":2129921},{"p":445134,"g":{"r":0,"d":0,"h":55837382962,"f":50364417},"s":{"r":0,"d":0,"h":60132350258,"f":83918849},"n":"Owner","d":2808114,"h":51542415666,"f":2129921},{"p":393217,"g":{"r":0,"d":0,"h":68722284850,"f":50331649},"s":{"r":0,"d":0,"h":73017252146,"f":83886081},"n":"ResourceManagerControl","d":2808114,"h":64427317554,"f":2097153},{"p":2742578,"g":{"r":0,"d":0,"h":81607186738,"f":50331649},"s":{"r":0,"d":0,"h":85902154034,"f":83886081},"n":"SystemAcl","d":2808114,"h":77312219442,"f":2097153}],"m":[{"r":65537,"p":[{"n":"flags","p":1497394}],"n":"SetFlags","d":2808114,"h":90197121330,"f":16777217}],"c":[{"p":[{"n":"binaryForm","p":$.$typeArray($.$$.System.Byte).$h},{"n":"offset","p":655361}],"n":".ctor","o":"$ctor$2","d":2808114,"h":4297775410,"f":16777217},{"p":[{"n":"flags","p":1497394},{"n":"owner","p":445134},{"n":"group","p":445134},{"n":"systemAcl","p":2742578},{"n":"discretionaryAcl","p":2742578}],"n":".ctor","o":"$ctor$4","d":2808114,"h":8592742706,"f":16777217},{"p":[{"n":"sddlForm","p":1310721}],"n":".ctor","o":"$ctor$3","d":2808114,"h":12887710002,"f":16777217}],"h":2808114}; }
            static get $b() { return $.$ssa.System.Security.AccessControl.GenericSecurityDescriptor; }
            static get $fullName() { return `System.Security.AccessControl.RawSecurityDescriptor`; }
        });
        
        $asm.$cls("$ssa.System.Security.AccessControl.AuthorizationRuleCollection", ($self) => class AuthorizationRuleCollection extends $.$scn.System.Collections.ReadOnlyCollectionBase
        {
            $ctor$2()
            {
                super.$ctor$1();
                {
                }
                return this;
            }
            /*System.Security.AccessControl.AuthorizationRule?*/ get_Item(/*int*/ index)
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*void */ AddRule(/*System.Security.AccessControl.AuthorizationRule?*/ rule)
            {
            }
            /*void */ CopyTo(/*System.Security.AccessControl.AuthorizationRule[]*/ rules, /*int*/ index)
            {
            }
            static $h = 1038642;
            static $f = 0b10010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":589859,"p":[{"p":973106,"i":[{"n":"index","p":655361}],"g":{"r":0,"d":0,"h":12885940530,"f":50331649},"n":"Item","o":"@$2","d":1038642,"h":8590973234,"f":2097153}],"m":[{"r":65537,"p":[{"n":"rule","p":973106}],"n":"AddRule","d":1038642,"h":17180907826,"f":16777217},{"r":65537,"p":[{"n":"rules","p":$.$typeArray($.$ssa.System.Security.AccessControl.AuthorizationRule).$h},{"n":"index","p":655361}],"n":"CopyTo","d":1038642,"h":21475875122,"f":16777217}],"c":[{"n":".ctor","o":"$ctor$2","d":1038642,"h":4296005938,"f":16777217}],"i":[31457281,31719425],"h":1038642}; }
            static get $b() { return $.$scn.System.Collections.ReadOnlyCollectionBase; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.System.Collections.ICollection, $.$$.System.Collections.IEnumerable ]; }
            static get $fullName() { return `System.Security.AccessControl.AuthorizationRuleCollection`; }
        });
        
        $asm.$cls("$ssa.System.Security.AccessControl.RawAcl", ($self) => class RawAcl extends $.$ssa.System.Security.AccessControl.GenericAcl
        {
            $ctor$2(/*byte*/ revision, /*int*/ capacity)
            {
                super.$ctor$1();
                {
                }
                return this;
            }
            $ctor$3(/*byte[]*/ binaryForm, /*int*/ offset)
            {
                super.$ctor$1();
                {
                }
                return this;
            }
            /*int */ get BinaryLength()
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ get Count()
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Security.AccessControl.GenericAce*/ get_Item(/*int*/ index)
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*void*/ set_Item(/*int*/ index, /*System.Security.AccessControl.GenericAce*/ value)
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*byte */ get Revision()
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*void */ GetBinaryForm(/*byte[]*/ binaryForm, /*int*/ offset)
            {
            }
            /*void */ InsertAce(/*int*/ index, /*System.Security.AccessControl.GenericAce*/ ace)
            {
            }
            /*void */ RemoveAce(/*int*/ index)
            {
            }
            static $h = 2742578;
            static $f = 0b10010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":1759538,"p":[{"p":655361,"g":{"r":0,"d":0,"h":17182611762,"f":50364417},"n":"BinaryLength","d":2742578,"h":12887644466,"f":2129921},{"p":655361,"g":{"r":0,"d":0,"h":25772546354,"f":50364417},"n":"Count","d":2742578,"h":21477579058,"f":2129921},{"p":1694002,"i":[{"n":"index","p":655361}],"g":{"r":0,"d":0,"h":34362480946,"f":50364417},"s":{"r":0,"d":0,"h":38657448242,"f":83918849},"n":"Item","o":"@$2","d":2742578,"h":30067513650,"f":2129921},{"p":393217,"g":{"r":0,"d":0,"h":47247382834,"f":50364417},"n":"Revision","d":2742578,"h":42952415538,"f":2129921}],"m":[{"r":65537,"p":[{"n":"binaryForm","p":$.$typeArray($.$$.System.Byte).$h},{"n":"offset","p":655361}],"n":"GetBinaryForm","d":2742578,"h":51542350130,"f":16809985},{"r":65537,"p":[{"n":"index","p":655361},{"n":"ace","p":1694002}],"n":"InsertAce","d":2742578,"h":55837317426,"f":16777217},{"r":65537,"p":[{"n":"index","p":655361}],"n":"RemoveAce","d":2742578,"h":60132284722,"f":16777217}],"c":[{"p":[{"n":"revision","p":393217},{"n":"capacity","p":655361}],"n":".ctor","o":"$ctor$2","d":2742578,"h":4297709874,"f":16777217},{"p":[{"n":"binaryForm","p":$.$typeArray($.$$.System.Byte).$h},{"n":"offset","p":655361}],"n":".ctor","o":"$ctor$3","d":2742578,"h":8592677170,"f":16777217}],"i":[31457281,31719425],"h":2742578}; }
            static get $b() { return $.$ssa.System.Security.AccessControl.GenericAcl; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.System.Collections.ICollection, $.$$.System.Collections.IEnumerable ]; }
            static get $fullName() { return `System.Security.AccessControl.RawAcl`; }
        });
        
        $asm.$cls("$ssa.System.Security.AccessControl.AccessRule<>", (T) => $asm.$gt("$ssa.System.Security.AccessControl.AccessRule<>", [T], ($self) => class AccessRule$$ extends $.$ssa.System.Security.AccessControl.AccessRule
        {
            $ctor$5(/*System.Security.Principal.IdentityReference*/ identity, /*T*/ rights, /*System.Security.AccessControl.AccessControlType*/ type)
            {
                super.$ctor$2(null, 0, false, 0, 0, 0);
                {
                }
                return this;
            }
            $ctor$6(/*System.Security.Principal.IdentityReference*/ identity, /*T*/ rights, /*System.Security.AccessControl.InheritanceFlags*/ inheritanceFlags, /*System.Security.AccessControl.PropagationFlags*/ propagationFlags, /*System.Security.AccessControl.AccessControlType*/ type)
            {
                super.$ctor$2(null, 0, false, 0, 0, 0);
                {
                }
                return this;
            }
            $ctor$3(/*string*/ identity, /*T*/ rights, /*System.Security.AccessControl.AccessControlType*/ type)
            {
                super.$ctor$2(null, 0, false, 0, 0, 0);
                {
                }
                return this;
            }
            $ctor$4(/*string*/ identity, /*T*/ rights, /*System.Security.AccessControl.InheritanceFlags*/ inheritanceFlags, /*System.Security.AccessControl.PropagationFlags*/ propagationFlags, /*System.Security.AccessControl.AccessControlType*/ type)
            {
                super.$ctor$2(null, 0, false, 0, 0, 0);
                {
                }
                return this;
            }
            /*T */ get Rights()
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            static $h = 448818;
            static $g = 1;
            static $f = 0b1010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":383282,"p":[{"p":T?.$h??1507328,"g":{"r":0,"d":0,"h":Number(BigInt(this.$h)|0x600000000n),"f":50331649},"n":"Rights","d":this.$h,"h":Number(BigInt(this.$h)|0x500000000n),"f":2097153}],"c":[{"p":[{"n":"identity","p":248526},{"n":"rights","p":T?.$h??1507328},{"n":"type","p":317746}],"n":".ctor","o":"$ctor$5","d":this.$h,"h":Number(BigInt(this.$h)|0x100000000n),"f":16777217},{"p":[{"n":"identity","p":248526},{"n":"rights","p":T?.$h??1507328},{"n":"inheritanceFlags","p":1890610},{"n":"propagationFlags","p":2611506},{"n":"type","p":317746}],"n":".ctor","o":"$ctor$6","d":this.$h,"h":Number(BigInt(this.$h)|0x200000000n),"f":16777217},{"p":[{"n":"identity","p":1310721},{"n":"rights","p":T?.$h??1507328},{"n":"type","p":317746}],"n":".ctor","o":"$ctor$3","d":this.$h,"h":Number(BigInt(this.$h)|0x300000000n),"f":16777217},{"p":[{"n":"identity","p":1310721},{"n":"rights","p":T?.$h??1507328},{"n":"inheritanceFlags","p":1890610},{"n":"propagationFlags","p":2611506},{"n":"type","p":317746}],"n":".ctor","o":"$ctor$4","d":this.$h,"h":Number(BigInt(this.$h)|0x400000000n),"f":16777217}],"g":[T?.$h??1507328],"s":[{"n":"T","f":2}],"r":1,"h":this.$h}; }
            static get $b() { return $.$ssa.System.Security.AccessControl.AccessRule; }
            static get $fullName() { return `System.Security.AccessControl.AccessRule<${T?.$fullName}>`; }
        }));
        
        $asm.$cls("$ssa.System.Security.AccessControl.AuditRule<>", (T) => $asm.$gt("$ssa.System.Security.AccessControl.AuditRule<>", [T], ($self) => class AuditRule$$ extends $.$ssa.System.Security.AccessControl.AuditRule
        {
            $ctor$5(/*System.Security.Principal.IdentityReference*/ identity, /*T*/ rights, /*System.Security.AccessControl.AuditFlags*/ flags)
            {
                super.$ctor$2(null, 0, false, 0, 0, 0);
                {
                }
                return this;
            }
            $ctor$6(/*System.Security.Principal.IdentityReference*/ identity, /*T*/ rights, /*System.Security.AccessControl.InheritanceFlags*/ inheritanceFlags, /*System.Security.AccessControl.PropagationFlags*/ propagationFlags, /*System.Security.AccessControl.AuditFlags*/ flags)
            {
                super.$ctor$2(null, 0, false, 0, 0, 0);
                {
                }
                return this;
            }
            $ctor$3(/*string*/ identity, /*T*/ rights, /*System.Security.AccessControl.AuditFlags*/ flags)
            {
                super.$ctor$2(null, 0, false, 0, 0, 0);
                {
                }
                return this;
            }
            $ctor$4(/*string*/ identity, /*T*/ rights, /*System.Security.AccessControl.InheritanceFlags*/ inheritanceFlags, /*System.Security.AccessControl.PropagationFlags*/ propagationFlags, /*System.Security.AccessControl.AuditFlags*/ flags)
            {
                super.$ctor$2(null, 0, false, 0, 0, 0);
                {
                }
                return this;
            }
            /*T */ get Rights()
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            static $h = 907570;
            static $g = 1;
            static $f = 0b1010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":842034,"p":[{"p":T?.$h??1507328,"g":{"r":0,"d":0,"h":Number(BigInt(this.$h)|0x600000000n),"f":50331649},"n":"Rights","d":this.$h,"h":Number(BigInt(this.$h)|0x500000000n),"f":2097153}],"c":[{"p":[{"n":"identity","p":248526},{"n":"rights","p":T?.$h??1507328},{"n":"flags","p":776498}],"n":".ctor","o":"$ctor$5","d":this.$h,"h":Number(BigInt(this.$h)|0x100000000n),"f":16777217},{"p":[{"n":"identity","p":248526},{"n":"rights","p":T?.$h??1507328},{"n":"inheritanceFlags","p":1890610},{"n":"propagationFlags","p":2611506},{"n":"flags","p":776498}],"n":".ctor","o":"$ctor$6","d":this.$h,"h":Number(BigInt(this.$h)|0x200000000n),"f":16777217},{"p":[{"n":"identity","p":1310721},{"n":"rights","p":T?.$h??1507328},{"n":"flags","p":776498}],"n":".ctor","o":"$ctor$3","d":this.$h,"h":Number(BigInt(this.$h)|0x300000000n),"f":16777217},{"p":[{"n":"identity","p":1310721},{"n":"rights","p":T?.$h??1507328},{"n":"inheritanceFlags","p":1890610},{"n":"propagationFlags","p":2611506},{"n":"flags","p":776498}],"n":".ctor","o":"$ctor$4","d":this.$h,"h":Number(BigInt(this.$h)|0x400000000n),"f":16777217}],"g":[T?.$h??1507328],"s":[{"n":"T","f":2}],"r":1,"h":this.$h}; }
            static get $b() { return $.$ssa.System.Security.AccessControl.AuditRule; }
            static get $fullName() { return `System.Security.AccessControl.AuditRule<${T?.$fullName}>`; }
        }));
        
        $asm.$cls("$ssa.System.Security.AccessControl.CompoundAce", ($self) => class CompoundAce extends $.$ssa.System.Security.AccessControl.KnownAce
        {
            $ctor$3(/*System.Security.AccessControl.AceFlags*/ flags, /*int*/ accessMask, /*System.Security.AccessControl.CompoundAceType*/ compoundAceType, /*System.Security.Principal.SecurityIdentifier*/ sid)
            {
                super.$ctor$2();
                {
                }
                return this;
            }
            /*int */ get BinaryLength()
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Security.AccessControl.CompoundAceType */ get CompoundAceType()
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Security.AccessControl.CompoundAceType */ set CompoundAceType(value)
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*void */ GetBinaryForm(/*byte[]*/ binaryForm, /*int*/ offset)
            {
            }
            static $h = 1366322;
            static $f = 0b10010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":1956146,"p":[{"p":655361,"g":{"r":0,"d":0,"h":12886268210,"f":50364417},"n":"BinaryLength","d":1366322,"h":8591300914,"f":2129921},{"p":1431858,"g":{"r":0,"d":0,"h":21476202802,"f":50331649},"s":{"r":0,"d":0,"h":25771170098,"f":83886081},"n":"CompoundAceType","d":1366322,"h":17181235506,"f":2097153}],"m":[{"r":65537,"p":[{"n":"binaryForm","p":$.$typeArray($.$$.System.Byte).$h},{"n":"offset","p":655361}],"n":"GetBinaryForm","d":1366322,"h":30066137394,"f":16809985}],"c":[{"p":[{"n":"flags","p":579890},{"n":"accessMask","p":655361},{"n":"compoundAceType","p":1431858},{"n":"sid","p":445134}],"n":".ctor","o":"$ctor$3","d":1366322,"h":4296333618,"f":16777217}],"h":1366322}; }
            static get $b() { return $.$ssa.System.Security.AccessControl.KnownAce; }
            static get $fullName() { return `System.Security.AccessControl.CompoundAce`; }
        });
        
        $asm.$cls("$ssa.System.Security.AccessControl.DiscretionaryAcl", ($self) => class DiscretionaryAcl extends $.$ssa.System.Security.AccessControl.CommonAcl
        {
            $ctor$3(/*bool*/ isContainer, /*bool*/ isDS, /*byte*/ revision, /*int*/ capacity)
            {
                super.$ctor$2();
                {
                }
                return this;
            }
            $ctor$4(/*bool*/ isContainer, /*bool*/ isDS, /*int*/ capacity)
            {
                super.$ctor$2();
                {
                }
                return this;
            }
            $ctor$5(/*bool*/ isContainer, /*bool*/ isDS, /*System.Security.AccessControl.RawAcl?*/ rawAcl)
            {
                super.$ctor$2();
                {
                }
                return this;
            }
            /*void */ AddAccess$1(/*System.Security.AccessControl.AccessControlType*/ accessType, /*System.Security.Principal.SecurityIdentifier*/ sid, /*int*/ accessMask, /*System.Security.AccessControl.InheritanceFlags*/ inheritanceFlags, /*System.Security.AccessControl.PropagationFlags*/ propagationFlags)
            {
            }
            /*void */ AddAccess(/*System.Security.AccessControl.AccessControlType*/ accessType, /*System.Security.Principal.SecurityIdentifier*/ sid, /*int*/ accessMask, /*System.Security.AccessControl.InheritanceFlags*/ inheritanceFlags, /*System.Security.AccessControl.PropagationFlags*/ propagationFlags, /*System.Security.AccessControl.ObjectAceFlags*/ objectFlags, /*System.Guid*/ objectType, /*System.Guid*/ inheritedObjectType)
            {
            }
            /*void */ AddAccess$2(/*System.Security.AccessControl.AccessControlType*/ accessType, /*System.Security.Principal.SecurityIdentifier*/ sid, /*System.Security.AccessControl.ObjectAccessRule*/ rule)
            {
            }
            /*bool */ RemoveAccess$1(/*System.Security.AccessControl.AccessControlType*/ accessType, /*System.Security.Principal.SecurityIdentifier*/ sid, /*int*/ accessMask, /*System.Security.AccessControl.InheritanceFlags*/ inheritanceFlags, /*System.Security.AccessControl.PropagationFlags*/ propagationFlags)
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ RemoveAccess(/*System.Security.AccessControl.AccessControlType*/ accessType, /*System.Security.Principal.SecurityIdentifier*/ sid, /*int*/ accessMask, /*System.Security.AccessControl.InheritanceFlags*/ inheritanceFlags, /*System.Security.AccessControl.PropagationFlags*/ propagationFlags, /*System.Security.AccessControl.ObjectAceFlags*/ objectFlags, /*System.Guid*/ objectType, /*System.Guid*/ inheritedObjectType)
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ RemoveAccess$2(/*System.Security.AccessControl.AccessControlType*/ accessType, /*System.Security.Principal.SecurityIdentifier*/ sid, /*System.Security.AccessControl.ObjectAccessRule*/ rule)
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*void */ RemoveAccessSpecific$1(/*System.Security.AccessControl.AccessControlType*/ accessType, /*System.Security.Principal.SecurityIdentifier*/ sid, /*int*/ accessMask, /*System.Security.AccessControl.InheritanceFlags*/ inheritanceFlags, /*System.Security.AccessControl.PropagationFlags*/ propagationFlags)
            {
            }
            /*void */ RemoveAccessSpecific(/*System.Security.AccessControl.AccessControlType*/ accessType, /*System.Security.Principal.SecurityIdentifier*/ sid, /*int*/ accessMask, /*System.Security.AccessControl.InheritanceFlags*/ inheritanceFlags, /*System.Security.AccessControl.PropagationFlags*/ propagationFlags, /*System.Security.AccessControl.ObjectAceFlags*/ objectFlags, /*System.Guid*/ objectType, /*System.Guid*/ inheritedObjectType)
            {
            }
            /*void */ RemoveAccessSpecific$2(/*System.Security.AccessControl.AccessControlType*/ accessType, /*System.Security.Principal.SecurityIdentifier*/ sid, /*System.Security.AccessControl.ObjectAccessRule*/ rule)
            {
            }
            /*void */ SetAccess$1(/*System.Security.AccessControl.AccessControlType*/ accessType, /*System.Security.Principal.SecurityIdentifier*/ sid, /*int*/ accessMask, /*System.Security.AccessControl.InheritanceFlags*/ inheritanceFlags, /*System.Security.AccessControl.PropagationFlags*/ propagationFlags)
            {
            }
            /*void */ SetAccess(/*System.Security.AccessControl.AccessControlType*/ accessType, /*System.Security.Principal.SecurityIdentifier*/ sid, /*int*/ accessMask, /*System.Security.AccessControl.InheritanceFlags*/ inheritanceFlags, /*System.Security.AccessControl.PropagationFlags*/ propagationFlags, /*System.Security.AccessControl.ObjectAceFlags*/ objectFlags, /*System.Guid*/ objectType, /*System.Guid*/ inheritedObjectType)
            {
            }
            /*void */ SetAccess$2(/*System.Security.AccessControl.AccessControlType*/ accessType, /*System.Security.Principal.SecurityIdentifier*/ sid, /*System.Security.AccessControl.ObjectAccessRule*/ rule)
            {
            }
            static $h = 1628466;
            static $f = 0b10010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":1169714,"m":[{"r":65537,"p":[{"n":"accessType","p":317746},{"n":"sid","p":445134},{"n":"accessMask","p":655361},{"n":"inheritanceFlags","p":1890610},{"n":"propagationFlags","p":2611506}],"n":"AddAccess","o":"@$1","d":1628466,"h":17181497650,"f":16777217},{"r":65537,"p":[{"n":"accessType","p":317746},{"n":"sid","p":445134},{"n":"accessMask","p":655361},{"n":"inheritanceFlags","p":1890610},{"n":"propagationFlags","p":2611506},{"n":"objectFlags","p":2283826},{"n":"objectType","p":56229889},{"n":"inheritedObjectType","p":56229889}],"n":"AddAccess","d":1628466,"h":21476464946,"f":16777217},{"r":65537,"p":[{"n":"accessType","p":317746},{"n":"sid","p":445134},{"n":"rule","p":2152754}],"n":"AddAccess","o":"@$2","d":1628466,"h":25771432242,"f":16777217},{"r":262145,"p":[{"n":"accessType","p":317746},{"n":"sid","p":445134},{"n":"accessMask","p":655361},{"n":"inheritanceFlags","p":1890610},{"n":"propagationFlags","p":2611506}],"n":"RemoveAccess","o":"@$1","d":1628466,"h":30066399538,"f":16777217},{"r":262145,"p":[{"n":"accessType","p":317746},{"n":"sid","p":445134},{"n":"accessMask","p":655361},{"n":"inheritanceFlags","p":1890610},{"n":"propagationFlags","p":2611506},{"n":"objectFlags","p":2283826},{"n":"objectType","p":56229889},{"n":"inheritedObjectType","p":56229889}],"n":"RemoveAccess","d":1628466,"h":34361366834,"f":16777217},{"r":262145,"p":[{"n":"accessType","p":317746},{"n":"sid","p":445134},{"n":"rule","p":2152754}],"n":"RemoveAccess","o":"@$2","d":1628466,"h":38656334130,"f":16777217},{"r":65537,"p":[{"n":"accessType","p":317746},{"n":"sid","p":445134},{"n":"accessMask","p":655361},{"n":"inheritanceFlags","p":1890610},{"n":"propagationFlags","p":2611506}],"n":"RemoveAccessSpecific","o":"@$1","d":1628466,"h":42951301426,"f":16777217},{"r":65537,"p":[{"n":"accessType","p":317746},{"n":"sid","p":445134},{"n":"accessMask","p":655361},{"n":"inheritanceFlags","p":1890610},{"n":"propagationFlags","p":2611506},{"n":"objectFlags","p":2283826},{"n":"objectType","p":56229889},{"n":"inheritedObjectType","p":56229889}],"n":"RemoveAccessSpecific","d":1628466,"h":47246268722,"f":16777217},{"r":65537,"p":[{"n":"accessType","p":317746},{"n":"sid","p":445134},{"n":"rule","p":2152754}],"n":"RemoveAccessSpecific","o":"@$2","d":1628466,"h":51541236018,"f":16777217},{"r":65537,"p":[{"n":"accessType","p":317746},{"n":"sid","p":445134},{"n":"accessMask","p":655361},{"n":"inheritanceFlags","p":1890610},{"n":"propagationFlags","p":2611506}],"n":"SetAccess","o":"@$1","d":1628466,"h":55836203314,"f":16777217},{"r":65537,"p":[{"n":"accessType","p":317746},{"n":"sid","p":445134},{"n":"accessMask","p":655361},{"n":"inheritanceFlags","p":1890610},{"n":"propagationFlags","p":2611506},{"n":"objectFlags","p":2283826},{"n":"objectType","p":56229889},{"n":"inheritedObjectType","p":56229889}],"n":"SetAccess","d":1628466,"h":60131170610,"f":16777217},{"r":65537,"p":[{"n":"accessType","p":317746},{"n":"sid","p":445134},{"n":"rule","p":2152754}],"n":"SetAccess","o":"@$2","d":1628466,"h":64426137906,"f":16777217}],"c":[{"p":[{"n":"isContainer","p":262145},{"n":"isDS","p":262145},{"n":"revision","p":393217},{"n":"capacity","p":655361}],"n":".ctor","o":"$ctor$3","d":1628466,"h":4296595762,"f":16777217},{"p":[{"n":"isContainer","p":262145},{"n":"isDS","p":262145},{"n":"capacity","p":655361}],"n":".ctor","o":"$ctor$4","d":1628466,"h":8591563058,"f":16777217},{"p":[{"n":"isContainer","p":262145},{"n":"isDS","p":262145},{"n":"rawAcl","p":2742578}],"n":".ctor","o":"$ctor$5","d":1628466,"h":12886530354,"f":16777217}],"i":[31457281,31719425],"h":1628466}; }
            static get $b() { return $.$ssa.System.Security.AccessControl.CommonAcl; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.System.Collections.ICollection, $.$$.System.Collections.IEnumerable ]; }
            static get $fullName() { return `System.Security.AccessControl.DiscretionaryAcl`; }
        });
        
        $asm.$cls("$ssa.System.Security.AccessControl.SystemAcl", ($self) => class SystemAcl extends $.$ssa.System.Security.AccessControl.CommonAcl
        {
            $ctor$3(/*bool*/ isContainer, /*bool*/ isDS, /*byte*/ revision, /*int*/ capacity)
            {
                super.$ctor$2();
                {
                }
                return this;
            }
            $ctor$4(/*bool*/ isContainer, /*bool*/ isDS, /*int*/ capacity)
            {
                super.$ctor$2();
                {
                }
                return this;
            }
            $ctor$5(/*bool*/ isContainer, /*bool*/ isDS, /*System.Security.AccessControl.RawAcl*/ rawAcl)
            {
                super.$ctor$2();
                {
                }
                return this;
            }
            /*void */ AddAudit$1(/*System.Security.AccessControl.AuditFlags*/ auditFlags, /*System.Security.Principal.SecurityIdentifier*/ sid, /*int*/ accessMask, /*System.Security.AccessControl.InheritanceFlags*/ inheritanceFlags, /*System.Security.AccessControl.PropagationFlags*/ propagationFlags)
            {
            }
            /*void */ AddAudit(/*System.Security.AccessControl.AuditFlags*/ auditFlags, /*System.Security.Principal.SecurityIdentifier*/ sid, /*int*/ accessMask, /*System.Security.AccessControl.InheritanceFlags*/ inheritanceFlags, /*System.Security.AccessControl.PropagationFlags*/ propagationFlags, /*System.Security.AccessControl.ObjectAceFlags*/ objectFlags, /*System.Guid*/ objectType, /*System.Guid*/ inheritedObjectType)
            {
            }
            /*void */ AddAudit$2(/*System.Security.Principal.SecurityIdentifier*/ sid, /*System.Security.AccessControl.ObjectAuditRule*/ rule)
            {
            }
            /*bool */ RemoveAudit$1(/*System.Security.AccessControl.AuditFlags*/ auditFlags, /*System.Security.Principal.SecurityIdentifier*/ sid, /*int*/ accessMask, /*System.Security.AccessControl.InheritanceFlags*/ inheritanceFlags, /*System.Security.AccessControl.PropagationFlags*/ propagationFlags)
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ RemoveAudit(/*System.Security.AccessControl.AuditFlags*/ auditFlags, /*System.Security.Principal.SecurityIdentifier*/ sid, /*int*/ accessMask, /*System.Security.AccessControl.InheritanceFlags*/ inheritanceFlags, /*System.Security.AccessControl.PropagationFlags*/ propagationFlags, /*System.Security.AccessControl.ObjectAceFlags*/ objectFlags, /*System.Guid*/ objectType, /*System.Guid*/ inheritedObjectType)
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ RemoveAudit$2(/*System.Security.Principal.SecurityIdentifier*/ sid, /*System.Security.AccessControl.ObjectAuditRule*/ rule)
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*void */ RemoveAuditSpecific$1(/*System.Security.AccessControl.AuditFlags*/ auditFlags, /*System.Security.Principal.SecurityIdentifier*/ sid, /*int*/ accessMask, /*System.Security.AccessControl.InheritanceFlags*/ inheritanceFlags, /*System.Security.AccessControl.PropagationFlags*/ propagationFlags)
            {
            }
            /*void */ RemoveAuditSpecific(/*System.Security.AccessControl.AuditFlags*/ auditFlags, /*System.Security.Principal.SecurityIdentifier*/ sid, /*int*/ accessMask, /*System.Security.AccessControl.InheritanceFlags*/ inheritanceFlags, /*System.Security.AccessControl.PropagationFlags*/ propagationFlags, /*System.Security.AccessControl.ObjectAceFlags*/ objectFlags, /*System.Guid*/ objectType, /*System.Guid*/ inheritedObjectType)
            {
            }
            /*void */ RemoveAuditSpecific$2(/*System.Security.Principal.SecurityIdentifier*/ sid, /*System.Security.AccessControl.ObjectAuditRule*/ rule)
            {
            }
            /*void */ SetAudit$1(/*System.Security.AccessControl.AuditFlags*/ auditFlags, /*System.Security.Principal.SecurityIdentifier*/ sid, /*int*/ accessMask, /*System.Security.AccessControl.InheritanceFlags*/ inheritanceFlags, /*System.Security.AccessControl.PropagationFlags*/ propagationFlags)
            {
            }
            /*void */ SetAudit(/*System.Security.AccessControl.AuditFlags*/ auditFlags, /*System.Security.Principal.SecurityIdentifier*/ sid, /*int*/ accessMask, /*System.Security.AccessControl.InheritanceFlags*/ inheritanceFlags, /*System.Security.AccessControl.PropagationFlags*/ propagationFlags, /*System.Security.AccessControl.ObjectAceFlags*/ objectFlags, /*System.Guid*/ objectType, /*System.Guid*/ inheritedObjectType)
            {
            }
            /*void */ SetAudit$2(/*System.Security.Principal.SecurityIdentifier*/ sid, /*System.Security.AccessControl.ObjectAuditRule*/ rule)
            {
            }
            static $h = 3004722;
            static $f = 0b10010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":1169714,"m":[{"r":65537,"p":[{"n":"auditFlags","p":776498},{"n":"sid","p":445134},{"n":"accessMask","p":655361},{"n":"inheritanceFlags","p":1890610},{"n":"propagationFlags","p":2611506}],"n":"AddAudit","o":"@$1","d":3004722,"h":17182873906,"f":16777217},{"r":65537,"p":[{"n":"auditFlags","p":776498},{"n":"sid","p":445134},{"n":"accessMask","p":655361},{"n":"inheritanceFlags","p":1890610},{"n":"propagationFlags","p":2611506},{"n":"objectFlags","p":2283826},{"n":"objectType","p":56229889},{"n":"inheritedObjectType","p":56229889}],"n":"AddAudit","d":3004722,"h":21477841202,"f":16777217},{"r":65537,"p":[{"n":"sid","p":445134},{"n":"rule","p":2349362}],"n":"AddAudit","o":"@$2","d":3004722,"h":25772808498,"f":16777217},{"r":262145,"p":[{"n":"auditFlags","p":776498},{"n":"sid","p":445134},{"n":"accessMask","p":655361},{"n":"inheritanceFlags","p":1890610},{"n":"propagationFlags","p":2611506}],"n":"RemoveAudit","o":"@$1","d":3004722,"h":30067775794,"f":16777217},{"r":262145,"p":[{"n":"auditFlags","p":776498},{"n":"sid","p":445134},{"n":"accessMask","p":655361},{"n":"inheritanceFlags","p":1890610},{"n":"propagationFlags","p":2611506},{"n":"objectFlags","p":2283826},{"n":"objectType","p":56229889},{"n":"inheritedObjectType","p":56229889}],"n":"RemoveAudit","d":3004722,"h":34362743090,"f":16777217},{"r":262145,"p":[{"n":"sid","p":445134},{"n":"rule","p":2349362}],"n":"RemoveAudit","o":"@$2","d":3004722,"h":38657710386,"f":16777217},{"r":65537,"p":[{"n":"auditFlags","p":776498},{"n":"sid","p":445134},{"n":"accessMask","p":655361},{"n":"inheritanceFlags","p":1890610},{"n":"propagationFlags","p":2611506}],"n":"RemoveAuditSpecific","o":"@$1","d":3004722,"h":42952677682,"f":16777217},{"r":65537,"p":[{"n":"auditFlags","p":776498},{"n":"sid","p":445134},{"n":"accessMask","p":655361},{"n":"inheritanceFlags","p":1890610},{"n":"propagationFlags","p":2611506},{"n":"objectFlags","p":2283826},{"n":"objectType","p":56229889},{"n":"inheritedObjectType","p":56229889}],"n":"RemoveAuditSpecific","d":3004722,"h":47247644978,"f":16777217},{"r":65537,"p":[{"n":"sid","p":445134},{"n":"rule","p":2349362}],"n":"RemoveAuditSpecific","o":"@$2","d":3004722,"h":51542612274,"f":16777217},{"r":65537,"p":[{"n":"auditFlags","p":776498},{"n":"sid","p":445134},{"n":"accessMask","p":655361},{"n":"inheritanceFlags","p":1890610},{"n":"propagationFlags","p":2611506}],"n":"SetAudit","o":"@$1","d":3004722,"h":55837579570,"f":16777217},{"r":65537,"p":[{"n":"auditFlags","p":776498},{"n":"sid","p":445134},{"n":"accessMask","p":655361},{"n":"inheritanceFlags","p":1890610},{"n":"propagationFlags","p":2611506},{"n":"objectFlags","p":2283826},{"n":"objectType","p":56229889},{"n":"inheritedObjectType","p":56229889}],"n":"SetAudit","d":3004722,"h":60132546866,"f":16777217},{"r":65537,"p":[{"n":"sid","p":445134},{"n":"rule","p":2349362}],"n":"SetAudit","o":"@$2","d":3004722,"h":64427514162,"f":16777217}],"c":[{"p":[{"n":"isContainer","p":262145},{"n":"isDS","p":262145},{"n":"revision","p":393217},{"n":"capacity","p":655361}],"n":".ctor","o":"$ctor$3","d":3004722,"h":4297972018,"f":16777217},{"p":[{"n":"isContainer","p":262145},{"n":"isDS","p":262145},{"n":"capacity","p":655361}],"n":".ctor","o":"$ctor$4","d":3004722,"h":8592939314,"f":16777217},{"p":[{"n":"isContainer","p":262145},{"n":"isDS","p":262145},{"n":"rawAcl","p":2742578}],"n":".ctor","o":"$ctor$5","d":3004722,"h":12887906610,"f":16777217}],"i":[31457281,31719425],"h":3004722}; }
            static get $b() { return $.$ssa.System.Security.AccessControl.CommonAcl; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.System.Collections.ICollection, $.$$.System.Collections.IEnumerable ]; }
            static get $fullName() { return `System.Security.AccessControl.SystemAcl`; }
        });
        
        $asm.$str("$ssa.System.Security.AccessControl.AccessControlActions", ($self) => class AccessControlActions extends $.$$.System.Enum
        {
            static None = 0;
            static View = 1;
            static Change = 2;
            static $map;
            static get Map()
            {
                return this.$map ??= 
                {
                    "None": 0n,
                    "View": 1n,
                    "Change": 2n
                };
            }
            static $h = 121138;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static get $eut() { return $.$$.System.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {"b":1048577,"u":655361,"l":[{"t":121138,"n":"None","d":121138,"h":4295088434,"f":4194337},{"t":121138,"n":"View","d":121138,"h":8590055730,"f":4194337},{"t":121138,"n":"Change","d":121138,"h":12885023026,"f":4194337}],"c":[{"n":".ctor","o":"$ctor$3","d":121138,"h":17179990322,"f":16777217}],"i":[57278465,63832065,57737217,57409537],"h":121138,"a":[{"t":47710209,"c":4342677505}]}; }
            static get $b() { return $.$$.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.System.IComparable, $.$$.System.ISpanFormattable, $.$$.System.IFormattable, $.$$.System.IConvertible ]; }
            static get $fullName() { return `System.Security.AccessControl.AccessControlActions`; }
        });
        
        $asm.$str("$ssa.System.Security.AccessControl.AccessControlModification", ($self) => class AccessControlModification extends $.$$.System.Enum
        {
            static Add = 0;
            static Set = 1;
            static Reset = 2;
            static Remove = 3;
            static RemoveAll = 4;
            static RemoveSpecific = 5;
            static $map;
            static get Map()
            {
                return this.$map ??= 
                {
                    "Add": 0n,
                    "Set": 1n,
                    "Reset": 2n,
                    "Remove": 3n,
                    "RemoveAll": 4n,
                    "RemoveSpecific": 5n
                };
            }
            static $h = 186674;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static get $eut() { return $.$$.System.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {"b":1048577,"u":655361,"l":[{"t":186674,"n":"Add","d":186674,"h":4295153970,"f":4194337},{"t":186674,"n":"Set","d":186674,"h":8590121266,"f":4194337},{"t":186674,"n":"Reset","d":186674,"h":12885088562,"f":4194337},{"t":186674,"n":"Remove","d":186674,"h":17180055858,"f":4194337},{"t":186674,"n":"RemoveAll","d":186674,"h":21475023154,"f":4194337},{"t":186674,"n":"RemoveSpecific","d":186674,"h":25769990450,"f":4194337}],"c":[{"n":".ctor","o":"$ctor$3","d":186674,"h":30064957746,"f":16777217}],"i":[57278465,63832065,57737217,57409537],"h":186674}; }
            static get $b() { return $.$$.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.System.IComparable, $.$$.System.ISpanFormattable, $.$$.System.IFormattable, $.$$.System.IConvertible ]; }
            static get $fullName() { return `System.Security.AccessControl.AccessControlModification`; }
        });
        
        $asm.$str("$ssa.System.Security.AccessControl.AccessControlSections", ($self) => class AccessControlSections extends $.$$.System.Enum
        {
            static None = 0;
            static Audit = 1;
            static Access = 2;
            static Owner = 4;
            static Group = 8;
            static All = 15;
            static $map;
            static get Map()
            {
                return this.$map ??= 
                {
                    "None": 0n,
                    "Audit": 1n,
                    "Access": 2n,
                    "Owner": 4n,
                    "Group": 8n,
                    "All": 15n
                };
            }
            static $h = 252210;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static get $eut() { return $.$$.System.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {"b":1048577,"u":655361,"l":[{"t":252210,"n":"None","d":252210,"h":4295219506,"f":4194337},{"t":252210,"n":"Audit","d":252210,"h":8590186802,"f":4194337},{"t":252210,"n":"Access","d":252210,"h":12885154098,"f":4194337},{"t":252210,"n":"Owner","d":252210,"h":17180121394,"f":4194337},{"t":252210,"n":"Group","d":252210,"h":21475088690,"f":4194337},{"t":252210,"n":"All","d":252210,"h":25770055986,"f":4194337}],"c":[{"n":".ctor","o":"$ctor$3","d":252210,"h":30065023282,"f":16777217}],"i":[57278465,63832065,57737217,57409537],"h":252210,"a":[{"t":47710209,"c":4342677505}]}; }
            static get $b() { return $.$$.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.System.IComparable, $.$$.System.ISpanFormattable, $.$$.System.IFormattable, $.$$.System.IConvertible ]; }
            static get $fullName() { return `System.Security.AccessControl.AccessControlSections`; }
        });
        
        $asm.$str("$ssa.System.Security.AccessControl.AccessControlType", ($self) => class AccessControlType extends $.$$.System.Enum
        {
            static Allow = 0;
            static Deny = 1;
            static $map;
            static get Map()
            {
                return this.$map ??= 
                {
                    "Allow": 0n,
                    "Deny": 1n
                };
            }
            static $h = 317746;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static get $eut() { return $.$$.System.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {"b":1048577,"u":655361,"l":[{"t":317746,"n":"Allow","d":317746,"h":4295285042,"f":4194337},{"t":317746,"n":"Deny","d":317746,"h":8590252338,"f":4194337}],"c":[{"n":".ctor","o":"$ctor$3","d":317746,"h":12885219634,"f":16777217}],"i":[57278465,63832065,57737217,57409537],"h":317746}; }
            static get $b() { return $.$$.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.System.IComparable, $.$$.System.ISpanFormattable, $.$$.System.IFormattable, $.$$.System.IConvertible ]; }
            static get $fullName() { return `System.Security.AccessControl.AccessControlType`; }
        });
        
        $asm.$str("$ssa.System.Security.AccessControl.AceFlags", ($self) => class AceFlags extends $.$$.System.Enum
        {
            static None = 0;
            static ObjectInherit = 1;
            static ContainerInherit = 2;
            static NoPropagateInherit = 4;
            static InheritOnly = 8;
            static InheritanceFlags = 15;
            static Inherited = 16;
            static SuccessfulAccess = 64;
            static FailedAccess = 128;
            static AuditFlags = 192;
            static $map;
            static get Map()
            {
                return this.$map ??= 
                {
                    "None": 0n,
                    "ObjectInherit": 1n,
                    "ContainerInherit": 2n,
                    "NoPropagateInherit": 4n,
                    "InheritOnly": 8n,
                    "InheritanceFlags": 15n,
                    "Inherited": 16n,
                    "SuccessfulAccess": 64n,
                    "FailedAccess": 128n,
                    "AuditFlags": 192n
                };
            }
            static $h = 579890;
            static $z = 1;
            static $f = 0b100000011010001001;
            static $k = 4;
            static get $eut() { return $.$$.System.Byte; }
            static $$md;
            static get $md() { return this.$$md ??= {"b":1048577,"u":393217,"l":[{"t":579890,"n":"None","d":579890,"h":4295547186,"f":4194337},{"t":579890,"n":"ObjectInherit","d":579890,"h":8590514482,"f":4194337},{"t":579890,"n":"ContainerInherit","d":579890,"h":12885481778,"f":4194337},{"t":579890,"n":"NoPropagateInherit","d":579890,"h":17180449074,"f":4194337},{"t":579890,"n":"InheritOnly","d":579890,"h":21475416370,"f":4194337},{"t":579890,"n":"InheritanceFlags","d":579890,"h":25770383666,"f":4194337},{"t":579890,"n":"Inherited","d":579890,"h":30065350962,"f":4194337},{"t":579890,"n":"SuccessfulAccess","d":579890,"h":34360318258,"f":4194337},{"t":579890,"n":"FailedAccess","d":579890,"h":38655285554,"f":4194337},{"t":579890,"n":"AuditFlags","d":579890,"h":42950252850,"f":4194337}],"c":[{"n":".ctor","o":"$ctor$3","d":579890,"h":47245220146,"f":16777217}],"i":[57278465,63832065,57737217,57409537],"h":579890,"a":[{"t":47710209,"c":4342677505}]}; }
            static get $b() { return $.$$.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.System.IComparable, $.$$.System.ISpanFormattable, $.$$.System.IFormattable, $.$$.System.IConvertible ]; }
            static get $fullName() { return `System.Security.AccessControl.AceFlags`; }
        });
        
        $asm.$str("$ssa.System.Security.AccessControl.AceQualifier", ($self) => class AceQualifier extends $.$$.System.Enum
        {
            static AccessAllowed = 0;
            static AccessDenied = 1;
            static SystemAudit = 2;
            static SystemAlarm = 3;
            static $map;
            static get Map()
            {
                return this.$map ??= 
                {
                    "AccessAllowed": 0n,
                    "AccessDenied": 1n,
                    "SystemAudit": 2n,
                    "SystemAlarm": 3n
                };
            }
            static $h = 645426;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static get $eut() { return $.$$.System.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {"b":1048577,"u":655361,"l":[{"t":645426,"n":"AccessAllowed","d":645426,"h":4295612722,"f":4194337},{"t":645426,"n":"AccessDenied","d":645426,"h":8590580018,"f":4194337},{"t":645426,"n":"SystemAudit","d":645426,"h":12885547314,"f":4194337},{"t":645426,"n":"SystemAlarm","d":645426,"h":17180514610,"f":4194337}],"c":[{"n":".ctor","o":"$ctor$3","d":645426,"h":21475481906,"f":16777217}],"i":[57278465,63832065,57737217,57409537],"h":645426}; }
            static get $b() { return $.$$.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.System.IComparable, $.$$.System.ISpanFormattable, $.$$.System.IFormattable, $.$$.System.IConvertible ]; }
            static get $fullName() { return `System.Security.AccessControl.AceQualifier`; }
        });
        
        $asm.$str("$ssa.System.Security.AccessControl.AceType", ($self) => class AceType extends $.$$.System.Enum
        {
            static AccessAllowed = 0;
            static AccessDenied = 1;
            static SystemAudit = 2;
            static SystemAlarm = 3;
            static AccessAllowedCompound = 4;
            static AccessAllowedObject = 5;
            static AccessDeniedObject = 6;
            static SystemAuditObject = 7;
            static SystemAlarmObject = 8;
            static AccessAllowedCallback = 9;
            static AccessDeniedCallback = 10;
            static AccessAllowedCallbackObject = 11;
            static AccessDeniedCallbackObject = 12;
            static SystemAuditCallback = 13;
            static SystemAlarmCallback = 14;
            static SystemAuditCallbackObject = 15;
            static MaxDefinedAceType = 16;
            static SystemAlarmCallbackObject = 16;
            static $map;
            static get Map()
            {
                return this.$map ??= 
                {
                    "AccessAllowed": 0n,
                    "AccessDenied": 1n,
                    "SystemAudit": 2n,
                    "SystemAlarm": 3n,
                    "AccessAllowedCompound": 4n,
                    "AccessAllowedObject": 5n,
                    "AccessDeniedObject": 6n,
                    "SystemAuditObject": 7n,
                    "SystemAlarmObject": 8n,
                    "AccessAllowedCallback": 9n,
                    "AccessDeniedCallback": 10n,
                    "AccessAllowedCallbackObject": 11n,
                    "AccessDeniedCallbackObject": 12n,
                    "SystemAuditCallback": 13n,
                    "SystemAlarmCallback": 14n,
                    "SystemAuditCallbackObject": 15n,
                    "MaxDefinedAceType": 16n,
                    "SystemAlarmCallbackObject": 16n
                };
            }
            static $h = 710962;
            static $z = 1;
            static $f = 0b100000011010001001;
            static $k = 4;
            static get $eut() { return $.$$.System.Byte; }
            static $$md;
            static get $md() { return this.$$md ??= {"b":1048577,"u":393217,"l":[{"t":710962,"n":"AccessAllowed","d":710962,"h":4295678258,"f":4194337},{"t":710962,"n":"AccessDenied","d":710962,"h":8590645554,"f":4194337},{"t":710962,"n":"SystemAudit","d":710962,"h":12885612850,"f":4194337},{"t":710962,"n":"SystemAlarm","d":710962,"h":17180580146,"f":4194337},{"t":710962,"n":"AccessAllowedCompound","d":710962,"h":21475547442,"f":4194337},{"t":710962,"n":"AccessAllowedObject","d":710962,"h":25770514738,"f":4194337},{"t":710962,"n":"AccessDeniedObject","d":710962,"h":30065482034,"f":4194337},{"t":710962,"n":"SystemAuditObject","d":710962,"h":34360449330,"f":4194337},{"t":710962,"n":"SystemAlarmObject","d":710962,"h":38655416626,"f":4194337},{"t":710962,"n":"AccessAllowedCallback","d":710962,"h":42950383922,"f":4194337},{"t":710962,"n":"AccessDeniedCallback","d":710962,"h":47245351218,"f":4194337},{"t":710962,"n":"AccessAllowedCallbackObject","d":710962,"h":51540318514,"f":4194337},{"t":710962,"n":"AccessDeniedCallbackObject","d":710962,"h":55835285810,"f":4194337},{"t":710962,"n":"SystemAuditCallback","d":710962,"h":60130253106,"f":4194337},{"t":710962,"n":"SystemAlarmCallback","d":710962,"h":64425220402,"f":4194337},{"t":710962,"n":"SystemAuditCallbackObject","d":710962,"h":68720187698,"f":4194337},{"t":710962,"n":"MaxDefinedAceType","d":710962,"h":73015154994,"f":4194337},{"t":710962,"n":"SystemAlarmCallbackObject","d":710962,"h":77310122290,"f":4194337}],"c":[{"n":".ctor","o":"$ctor$3","d":710962,"h":81605089586,"f":16777217}],"i":[57278465,63832065,57737217,57409537],"h":710962}; }
            static get $b() { return $.$$.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.System.IComparable, $.$$.System.ISpanFormattable, $.$$.System.IFormattable, $.$$.System.IConvertible ]; }
            static get $fullName() { return `System.Security.AccessControl.AceType`; }
        });
        
        $asm.$str("$ssa.System.Security.AccessControl.AuditFlags", ($self) => class AuditFlags extends $.$$.System.Enum
        {
            static None = 0;
            static Success = 1;
            static Failure = 2;
            static $map;
            static get Map()
            {
                return this.$map ??= 
                {
                    "None": 0n,
                    "Success": 1n,
                    "Failure": 2n
                };
            }
            static $h = 776498;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static get $eut() { return $.$$.System.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {"b":1048577,"u":655361,"l":[{"t":776498,"n":"None","d":776498,"h":4295743794,"f":4194337},{"t":776498,"n":"Success","d":776498,"h":8590711090,"f":4194337},{"t":776498,"n":"Failure","d":776498,"h":12885678386,"f":4194337}],"c":[{"n":".ctor","o":"$ctor$3","d":776498,"h":17180645682,"f":16777217}],"i":[57278465,63832065,57737217,57409537],"h":776498,"a":[{"t":47710209,"c":4342677505}]}; }
            static get $b() { return $.$$.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.System.IComparable, $.$$.System.ISpanFormattable, $.$$.System.IFormattable, $.$$.System.IConvertible ]; }
            static get $fullName() { return `System.Security.AccessControl.AuditFlags`; }
        });
        
        $asm.$str("$ssa.System.Security.AccessControl.CompoundAceType", ($self) => class CompoundAceType extends $.$$.System.Enum
        {
            static Impersonation = 1;
            static $map;
            static get Map()
            {
                return this.$map ??= 
                {
                    "Impersonation": 1n
                };
            }
            static $h = 1431858;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static get $eut() { return $.$$.System.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {"b":1048577,"u":655361,"l":[{"t":1431858,"n":"Impersonation","d":1431858,"h":4296399154,"f":4194337}],"c":[{"n":".ctor","o":"$ctor$3","d":1431858,"h":8591366450,"f":16777217}],"i":[57278465,63832065,57737217,57409537],"h":1431858}; }
            static get $b() { return $.$$.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.System.IComparable, $.$$.System.ISpanFormattable, $.$$.System.IFormattable, $.$$.System.IConvertible ]; }
            static get $fullName() { return `System.Security.AccessControl.CompoundAceType`; }
        });
        
        $asm.$str("$ssa.System.Security.AccessControl.ControlFlags", ($self) => class ControlFlags extends $.$$.System.Enum
        {
            static None = 0;
            static OwnerDefaulted = 1;
            static GroupDefaulted = 2;
            static DiscretionaryAclPresent = 4;
            static DiscretionaryAclDefaulted = 8;
            static SystemAclPresent = 16;
            static SystemAclDefaulted = 32;
            static DiscretionaryAclUntrusted = 64;
            static ServerSecurity = 128;
            static DiscretionaryAclAutoInheritRequired = 256;
            static SystemAclAutoInheritRequired = 512;
            static DiscretionaryAclAutoInherited = 1024;
            static SystemAclAutoInherited = 2048;
            static DiscretionaryAclProtected = 4096;
            static SystemAclProtected = 8192;
            static RMControlValid = 16384;
            static SelfRelative = 32768;
            static $map;
            static get Map()
            {
                return this.$map ??= 
                {
                    "None": 0n,
                    "OwnerDefaulted": 1n,
                    "GroupDefaulted": 2n,
                    "DiscretionaryAclPresent": 4n,
                    "DiscretionaryAclDefaulted": 8n,
                    "SystemAclPresent": 16n,
                    "SystemAclDefaulted": 32n,
                    "DiscretionaryAclUntrusted": 64n,
                    "ServerSecurity": 128n,
                    "DiscretionaryAclAutoInheritRequired": 256n,
                    "SystemAclAutoInheritRequired": 512n,
                    "DiscretionaryAclAutoInherited": 1024n,
                    "SystemAclAutoInherited": 2048n,
                    "DiscretionaryAclProtected": 4096n,
                    "SystemAclProtected": 8192n,
                    "RMControlValid": 16384n,
                    "SelfRelative": 32768n
                };
            }
            static $h = 1497394;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static get $eut() { return $.$$.System.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {"b":1048577,"u":655361,"l":[{"t":1497394,"n":"None","d":1497394,"h":4296464690,"f":4194337},{"t":1497394,"n":"OwnerDefaulted","d":1497394,"h":8591431986,"f":4194337},{"t":1497394,"n":"GroupDefaulted","d":1497394,"h":12886399282,"f":4194337},{"t":1497394,"n":"DiscretionaryAclPresent","d":1497394,"h":17181366578,"f":4194337},{"t":1497394,"n":"DiscretionaryAclDefaulted","d":1497394,"h":21476333874,"f":4194337},{"t":1497394,"n":"SystemAclPresent","d":1497394,"h":25771301170,"f":4194337},{"t":1497394,"n":"SystemAclDefaulted","d":1497394,"h":30066268466,"f":4194337},{"t":1497394,"n":"DiscretionaryAclUntrusted","d":1497394,"h":34361235762,"f":4194337},{"t":1497394,"n":"ServerSecurity","d":1497394,"h":38656203058,"f":4194337},{"t":1497394,"n":"DiscretionaryAclAutoInheritRequired","d":1497394,"h":42951170354,"f":4194337},{"t":1497394,"n":"SystemAclAutoInheritRequired","d":1497394,"h":47246137650,"f":4194337},{"t":1497394,"n":"DiscretionaryAclAutoInherited","d":1497394,"h":51541104946,"f":4194337},{"t":1497394,"n":"SystemAclAutoInherited","d":1497394,"h":55836072242,"f":4194337},{"t":1497394,"n":"DiscretionaryAclProtected","d":1497394,"h":60131039538,"f":4194337},{"t":1497394,"n":"SystemAclProtected","d":1497394,"h":64426006834,"f":4194337},{"t":1497394,"n":"RMControlValid","d":1497394,"h":68720974130,"f":4194337},{"t":1497394,"n":"SelfRelative","d":1497394,"h":73015941426,"f":4194337}],"c":[{"n":".ctor","o":"$ctor$3","d":1497394,"h":77310908722,"f":16777217}],"i":[57278465,63832065,57737217,57409537],"h":1497394,"a":[{"t":47710209,"c":4342677505}]}; }
            static get $b() { return $.$$.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.System.IComparable, $.$$.System.ISpanFormattable, $.$$.System.IFormattable, $.$$.System.IConvertible ]; }
            static get $fullName() { return `System.Security.AccessControl.ControlFlags`; }
        });
        
        $asm.$str("$ssa.System.Security.AccessControl.InheritanceFlags", ($self) => class InheritanceFlags extends $.$$.System.Enum
        {
            static None = 0;
            static ContainerInherit = 1;
            static ObjectInherit = 2;
            static $map;
            static get Map()
            {
                return this.$map ??= 
                {
                    "None": 0n,
                    "ContainerInherit": 1n,
                    "ObjectInherit": 2n
                };
            }
            static $h = 1890610;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static get $eut() { return $.$$.System.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {"b":1048577,"u":655361,"l":[{"t":1890610,"n":"None","d":1890610,"h":4296857906,"f":4194337},{"t":1890610,"n":"ContainerInherit","d":1890610,"h":8591825202,"f":4194337},{"t":1890610,"n":"ObjectInherit","d":1890610,"h":12886792498,"f":4194337}],"c":[{"n":".ctor","o":"$ctor$3","d":1890610,"h":17181759794,"f":16777217}],"i":[57278465,63832065,57737217,57409537],"h":1890610,"a":[{"t":47710209,"c":4342677505}]}; }
            static get $b() { return $.$$.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.System.IComparable, $.$$.System.ISpanFormattable, $.$$.System.IFormattable, $.$$.System.IConvertible ]; }
            static get $fullName() { return `System.Security.AccessControl.InheritanceFlags`; }
        });
        
        $asm.$str("$ssa.System.Security.AccessControl.ObjectAceFlags", ($self) => class ObjectAceFlags extends $.$$.System.Enum
        {
            static None = 0;
            static ObjectAceTypePresent = 1;
            static InheritedObjectAceTypePresent = 2;
            static $map;
            static get Map()
            {
                return this.$map ??= 
                {
                    "None": 0n,
                    "ObjectAceTypePresent": 1n,
                    "InheritedObjectAceTypePresent": 2n
                };
            }
            static $h = 2283826;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static get $eut() { return $.$$.System.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {"b":1048577,"u":655361,"l":[{"t":2283826,"n":"None","d":2283826,"h":4297251122,"f":4194337},{"t":2283826,"n":"ObjectAceTypePresent","d":2283826,"h":8592218418,"f":4194337},{"t":2283826,"n":"InheritedObjectAceTypePresent","d":2283826,"h":12887185714,"f":4194337}],"c":[{"n":".ctor","o":"$ctor$3","d":2283826,"h":17182153010,"f":16777217}],"i":[57278465,63832065,57737217,57409537],"h":2283826,"a":[{"t":47710209,"c":4342677505}]}; }
            static get $b() { return $.$$.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.System.IComparable, $.$$.System.ISpanFormattable, $.$$.System.IFormattable, $.$$.System.IConvertible ]; }
            static get $fullName() { return `System.Security.AccessControl.ObjectAceFlags`; }
        });
        
        $asm.$str("$ssa.System.Security.AccessControl.PropagationFlags", ($self) => class PropagationFlags extends $.$$.System.Enum
        {
            static None = 0;
            static NoPropagateInherit = 1;
            static InheritOnly = 2;
            static $map;
            static get Map()
            {
                return this.$map ??= 
                {
                    "None": 0n,
                    "NoPropagateInherit": 1n,
                    "InheritOnly": 2n
                };
            }
            static $h = 2611506;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static get $eut() { return $.$$.System.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {"b":1048577,"u":655361,"l":[{"t":2611506,"n":"None","d":2611506,"h":4297578802,"f":4194337},{"t":2611506,"n":"NoPropagateInherit","d":2611506,"h":8592546098,"f":4194337},{"t":2611506,"n":"InheritOnly","d":2611506,"h":12887513394,"f":4194337}],"c":[{"n":".ctor","o":"$ctor$3","d":2611506,"h":17182480690,"f":16777217}],"i":[57278465,63832065,57737217,57409537],"h":2611506,"a":[{"t":47710209,"c":4342677505}]}; }
            static get $b() { return $.$$.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.System.IComparable, $.$$.System.ISpanFormattable, $.$$.System.IFormattable, $.$$.System.IConvertible ]; }
            static get $fullName() { return `System.Security.AccessControl.PropagationFlags`; }
        });
        
        $asm.$str("$ssa.System.Security.AccessControl.ResourceType", ($self) => class ResourceType extends $.$$.System.Enum
        {
            static Unknown = 0;
            static FileObject = 1;
            static Service = 2;
            static Printer = 3;
            static RegistryKey = 4;
            static LMShare = 5;
            static KernelObject = 6;
            static WindowObject = 7;
            static DSObject = 8;
            static DSObjectAll = 9;
            static ProviderDefined = 10;
            static WmiGuidObject = 11;
            static RegistryWow6432Key = 12;
            static $map;
            static get Map()
            {
                return this.$map ??= 
                {
                    "Unknown": 0n,
                    "FileObject": 1n,
                    "Service": 2n,
                    "Printer": 3n,
                    "RegistryKey": 4n,
                    "LMShare": 5n,
                    "KernelObject": 6n,
                    "WindowObject": 7n,
                    "DSObject": 8n,
                    "DSObjectAll": 9n,
                    "ProviderDefined": 10n,
                    "WmiGuidObject": 11n,
                    "RegistryWow6432Key": 12n
                };
            }
            static $h = 2873650;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static get $eut() { return $.$$.System.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {"b":1048577,"u":655361,"l":[{"t":2873650,"n":"Unknown","d":2873650,"h":4297840946,"f":4194337},{"t":2873650,"n":"FileObject","d":2873650,"h":8592808242,"f":4194337},{"t":2873650,"n":"Service","d":2873650,"h":12887775538,"f":4194337},{"t":2873650,"n":"Printer","d":2873650,"h":17182742834,"f":4194337},{"t":2873650,"n":"RegistryKey","d":2873650,"h":21477710130,"f":4194337},{"t":2873650,"n":"LMShare","d":2873650,"h":25772677426,"f":4194337},{"t":2873650,"n":"KernelObject","d":2873650,"h":30067644722,"f":4194337},{"t":2873650,"n":"WindowObject","d":2873650,"h":34362612018,"f":4194337},{"t":2873650,"n":"DSObject","d":2873650,"h":38657579314,"f":4194337},{"t":2873650,"n":"DSObjectAll","d":2873650,"h":42952546610,"f":4194337},{"t":2873650,"n":"ProviderDefined","d":2873650,"h":47247513906,"f":4194337},{"t":2873650,"n":"WmiGuidObject","d":2873650,"h":51542481202,"f":4194337},{"t":2873650,"n":"RegistryWow6432Key","d":2873650,"h":55837448498,"f":4194337}],"c":[{"n":".ctor","o":"$ctor$3","d":2873650,"h":60132415794,"f":16777217}],"i":[57278465,63832065,57737217,57409537],"h":2873650}; }
            static get $b() { return $.$$.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.System.IComparable, $.$$.System.ISpanFormattable, $.$$.System.IFormattable, $.$$.System.IConvertible ]; }
            static get $fullName() { return `System.Security.AccessControl.ResourceType`; }
        });
        
        $asm.$str("$ssa.System.Security.AccessControl.SecurityInfos", ($self) => class SecurityInfos extends $.$$.System.Enum
        {
            static Owner = 1;
            static Group = 2;
            static DiscretionaryAcl = 4;
            static SystemAcl = 8;
            static $map;
            static get Map()
            {
                return this.$map ??= 
                {
                    "Owner": 1n,
                    "Group": 2n,
                    "DiscretionaryAcl": 4n,
                    "SystemAcl": 8n
                };
            }
            static $h = 2939186;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static get $eut() { return $.$$.System.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {"b":1048577,"u":655361,"l":[{"t":2939186,"n":"Owner","d":2939186,"h":4297906482,"f":4194337},{"t":2939186,"n":"Group","d":2939186,"h":8592873778,"f":4194337},{"t":2939186,"n":"DiscretionaryAcl","d":2939186,"h":12887841074,"f":4194337},{"t":2939186,"n":"SystemAcl","d":2939186,"h":17182808370,"f":4194337}],"c":[{"n":".ctor","o":"$ctor$3","d":2939186,"h":21477775666,"f":16777217}],"i":[57278465,63832065,57737217,57409537],"h":2939186,"a":[{"t":47710209,"c":4342677505}]}; }
            static get $b() { return $.$$.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.System.IComparable, $.$$.System.ISpanFormattable, $.$$.System.IFormattable, $.$$.System.IConvertible ]; }
            static get $fullName() { return `System.Security.AccessControl.SecurityInfos`; }
        });
        
        $asm.$cls("$ssa.System.Security.AccessControl.CommonAce", ($self) => class CommonAce extends $.$ssa.System.Security.AccessControl.QualifiedAce
        {
            $ctor$4(/*System.Security.AccessControl.AceFlags*/ flags, /*System.Security.AccessControl.AceQualifier*/ qualifier, /*int*/ accessMask, /*System.Security.Principal.SecurityIdentifier*/ sid, /*bool*/ isCallback, /*byte[]?*/ opaque)
            {
                super.$ctor$3();
                {
                }
                return this;
            }
            /*int */ get BinaryLength()
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*void */ GetBinaryForm(/*byte[]*/ binaryForm, /*int*/ offset)
            {
            }
            static /*int */ MaxOpaqueLength(/*bool*/ isCallback)
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            static $h = 1104178;
            static $f = 0b10010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":2677042,"p":[{"p":655361,"g":{"r":0,"d":0,"h":12886006066,"f":50364417},"n":"BinaryLength","d":1104178,"h":8591038770,"f":2129921}],"m":[{"r":65537,"p":[{"n":"binaryForm","p":$.$typeArray($.$$.System.Byte).$h},{"n":"offset","p":655361}],"n":"GetBinaryForm","d":1104178,"h":17180973362,"f":16809985},{"r":655361,"p":[{"n":"isCallback","p":262145}],"n":"MaxOpaqueLength","d":1104178,"h":21475940658,"f":16777249}],"c":[{"p":[{"n":"flags","p":579890},{"n":"qualifier","p":645426},{"n":"accessMask","p":655361},{"n":"sid","p":445134},{"n":"isCallback","p":262145},{"n":"opaque","p":$.$typeArray($.$$.System.Byte).$h}],"n":".ctor","o":"$ctor$4","d":1104178,"h":4296071474,"f":16777217}],"h":1104178}; }
            static get $b() { return $.$ssa.System.Security.AccessControl.QualifiedAce; }
            static get $fullName() { return `System.Security.AccessControl.CommonAce`; }
        });
        
        $asm.$cls("$ssa.System.Security.AccessControl.ObjectAce", ($self) => class ObjectAce extends $.$ssa.System.Security.AccessControl.QualifiedAce
        {
            $ctor$4(/*System.Security.AccessControl.AceFlags*/ aceFlags, /*System.Security.AccessControl.AceQualifier*/ qualifier, /*int*/ accessMask, /*System.Security.Principal.SecurityIdentifier*/ sid, /*System.Security.AccessControl.ObjectAceFlags*/ flags, /*System.Guid*/ type, /*System.Guid*/ inheritedType, /*bool*/ isCallback, /*byte[]?*/ opaque)
            {
                super.$ctor$3();
                {
                }
                return this;
            }
            /*int */ get BinaryLength()
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Guid */ get InheritedObjectAceType()
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Guid */ set InheritedObjectAceType(value)
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Security.AccessControl.ObjectAceFlags */ get ObjectAceFlags()
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Security.AccessControl.ObjectAceFlags */ set ObjectAceFlags(value)
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Guid */ get ObjectAceType()
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Guid */ set ObjectAceType(value)
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*void */ GetBinaryForm(/*byte[]*/ binaryForm, /*int*/ offset)
            {
            }
            static /*int */ MaxOpaqueLength(/*bool*/ isCallback)
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            static $h = 2218290;
            static $f = 0b10010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":2677042,"p":[{"p":655361,"g":{"r":0,"d":0,"h":12887120178,"f":50364417},"n":"BinaryLength","d":2218290,"h":8592152882,"f":2129921},{"p":56229889,"g":{"r":0,"d":0,"h":21477054770,"f":50331649},"s":{"r":0,"d":0,"h":25772022066,"f":83886081},"n":"InheritedObjectAceType","d":2218290,"h":17182087474,"f":2097153},{"p":2283826,"g":{"r":0,"d":0,"h":34361956658,"f":50331649},"s":{"r":0,"d":0,"h":38656923954,"f":83886081},"n":"ObjectAceFlags","d":2218290,"h":30066989362,"f":2097153},{"p":56229889,"g":{"r":0,"d":0,"h":47246858546,"f":50331649},"s":{"r":0,"d":0,"h":51541825842,"f":83886081},"n":"ObjectAceType","d":2218290,"h":42951891250,"f":2097153}],"m":[{"r":65537,"p":[{"n":"binaryForm","p":$.$typeArray($.$$.System.Byte).$h},{"n":"offset","p":655361}],"n":"GetBinaryForm","d":2218290,"h":55836793138,"f":16809985},{"r":655361,"p":[{"n":"isCallback","p":262145}],"n":"MaxOpaqueLength","d":2218290,"h":60131760434,"f":16777249}],"c":[{"p":[{"n":"aceFlags","p":579890},{"n":"qualifier","p":645426},{"n":"accessMask","p":655361},{"n":"sid","p":445134},{"n":"flags","p":2283826},{"n":"type","p":56229889},{"n":"inheritedType","p":56229889},{"n":"isCallback","p":262145},{"n":"opaque","p":$.$typeArray($.$$.System.Byte).$h}],"n":".ctor","o":"$ctor$4","d":2218290,"h":4297185586,"f":16777217}],"h":2218290}; }
            static get $b() { return $.$ssa.System.Security.AccessControl.QualifiedAce; }
            static get $fullName() { return `System.Security.AccessControl.ObjectAce`; }
        });
        
        $asm.$cls("$ssa.System.Security.AccessControl.PrivilegeNotHeldException", ($self) => class PrivilegeNotHeldException extends $.$$.System.UnauthorizedAccessException
        {
            $ctor$13()
            {
                super.$ctor$9();
                {
                }
                return this;
            }
            $ctor$15(/*string?*/ privilege)
            {
                super.$ctor$9();
                {
                }
                return this;
            }
            $ctor$14(/*string?*/ privilege, /*System.Exception?*/ inner)
            {
                super.$ctor$9();
                {
                }
                return this;
            }
            /*string? */ get PrivilegeName()
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*void */ GetObjectData(/*System.Runtime.Serialization.SerializationInfo*/ info, /*System.Runtime.Serialization.StreamingContext*/ context)
            {
            }
            static $h = 2545970;
            static $f = 0b10010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":143720449,"h":2545970}; }
            static get $b() { return $.$$.System.UnauthorizedAccessException; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.System.Runtime.Serialization.ISerializable ]; }
            static get $fullName() { return `System.Security.AccessControl.PrivilegeNotHeldException`; }
        });
	});
})(window, window.NetJs.$boot(), ...window.NetJs.$require("NetJs.System.Private.CoreLib", "NetJs.Microsoft.Win32.Primitives", "NetJs.System.Collections", "NetJs.System.Diagnostics.Tracing", "NetJs.System.Threading", "NetJs.System.Collections.Concurrent", "NetJs.System.Memory", "NetJs.System.Private.Uri", "NetJs.System.Runtime", "NetJs.System.Collections.NonGeneric", "NetJs.System.Runtime.InteropServices", "NetJs.System.Threading.Thread", "NetJs.System.Security.Claims", "NetJs.System.Security.Principal.Windows"))