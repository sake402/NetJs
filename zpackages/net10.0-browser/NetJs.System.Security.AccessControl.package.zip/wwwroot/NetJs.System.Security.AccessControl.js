
//--TRIMMABLE-BOUNDARY-START(83)
(async function () {
(function ($global, $, $$, $mwp, $sc, $sdt, $st, $scc, $sm, $spu, $sr, $scn, $sris, $stt, $ssc, $sspw) {
    "use strict";
    let _;

    
    
    
	$.$asm(
    "NetJs.System.Security.AccessControl", 
    {
  "h": 83,
  "f": "System.Security.AccessControl",
  "v": "1.0.35.0",
  "a": [
    {
      "t": 107151361,
      "c": 8697085953,
      "a": [
        {
          "v": "SIT",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107216897,
      "c": 8697151489,
      "a": [
        {
          "v": "Debug",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107675649,
      "c": 8697610241,
      "a": [
        {
          "v": "1.0.35.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107806721,
      "c": 8697741313,
      "a": [
        {
          "v": "1.0.35\u002B96771abe2820045936210554b19d0578b9bc2b1c",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108658689,
      "c": 8698593281,
      "a": [
        {
          "v": "NetJs.System.Security.AccessControl",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108789761,
      "c": 8698724353,
      "a": [
        {
          "v": "NetJs.System.Security.AccessControl",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108920833,
      "c": 8698855425,
      "a": [
        {
          "v": "1.0.35.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 160104449,
      "c": 4455071745,
      "a": [
        {
          "v": "browser1.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 159842305,
      "c": 4454809601,
      "a": [
        {
          "v": "browser1.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 160038913,
      "c": 13044940801,
      "a": [
        {
          "v": ".NETCoreApp,Version=v10.0",
          "t": 1310721
        }
      ],
      "n": [
        {
          "n": "FrameworkDisplayName",
          "v": ".NET 10.0",
          "t": 1310721
        }
      ]
    }
  ],
  "m": []
},
    function($asm)
	{
        
        
        //--TRIMMABLE-BOUNDARY-START(917587)
        $asm.$cls(`$ssa.SSA.AuthorizationRule`, ($self) => class AuthorizationRule extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(4295884883)
            $ctor$1(/*System.Security.Principal.IdentityReference*/ identity, /*int*/ accessMask, /*bool*/ isInherited, /*System.Security.AccessControl.InheritanceFlags*/ inheritanceFlags, /*System.Security.AccessControl.PropagationFlags*/ propagationFlags)
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4295884883);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295884883)
            
            //--TRIMMABLE-BOUNDARY-START(8590852179)
            /*int */ get AccessMask()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17180786771);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(8590852179)
            
            //--TRIMMABLE-BOUNDARY-START(55835492435)
            /*System.Security.Principal.IdentityReference */ get IdentityReference()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25770721363);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(55835492435)
            
            //--TRIMMABLE-BOUNDARY-START(60130459731)
            /*System.Security.AccessControl.InheritanceFlags */ get InheritanceFlags()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(34360655955);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(60130459731)
            
            //--TRIMMABLE-BOUNDARY-START(64425427027)
            /*bool */ get IsInherited()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(42950590547);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(64425427027)
            
            //--TRIMMABLE-BOUNDARY-START(68720394323)
            /*System.Security.AccessControl.PropagationFlags */ get PropagationFlags()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(51540525139);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(68720394323)
            
            static $h = 917587;
            static $f = 0b110001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(8590852179),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 17180786771,
        "f": 50331664
      },
      "n": "AccessMask",
      "d": 917587,
      "h": 8590852179,
      "f": 2097168
    },
//--TRIMMABLE-BOUNDARY-END(8590852179),
//--TRIMMABLE-BOUNDARY-START(55835492435),
    {
      "p": 196678,
      "g": {
        "r": 0,
        "d": 0,
        "h": 25770721363,
        "f": 50331649
      },
      "n": "IdentityReference",
      "d": 917587,
      "h": 55835492435,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(55835492435),
//--TRIMMABLE-BOUNDARY-START(60130459731),
    {
      "p": 1835091,
      "g": {
        "r": 0,
        "d": 0,
        "h": 34360655955,
        "f": 50331649
      },
      "n": "InheritanceFlags",
      "d": 917587,
      "h": 60130459731,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(60130459731),
//--TRIMMABLE-BOUNDARY-START(64425427027),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 42950590547,
        "f": 50331649
      },
      "n": "IsInherited",
      "d": 917587,
      "h": 64425427027,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(64425427027),
//--TRIMMABLE-BOUNDARY-START(68720394323),
    {
      "p": 2555987,
      "g": {
        "r": 0,
        "d": 0,
        "h": 51540525139,
        "f": 50331649
      },
      "n": "PropagationFlags",
      "d": 917587,
      "h": 68720394323,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(68720394323)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295884883),
    {
      "p": [
        {
          "n": "identity",
          "p": 196678
        },
        {
          "n": "accessMask",
          "p": 655361
        },
        {
          "n": "isInherited",
          "p": 262145
        },
        {
          "n": "inheritanceFlags",
          "p": 1835091
        },
        {
          "n": "propagationFlags",
          "p": 2555987
        }
      ],
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 917587,
      "h": 4295884883,
      "f": 16777232
    },
//--TRIMMABLE-BOUNDARY-END(4295884883)
  ],
  "h": 917587
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `System.Security.AccessControl.AuthorizationRule`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `System${separator}Security${separator}AccessControl${separator}AuthorizationRule`; }
        });
        //--TRIMMABLE-BOUNDARY-END(917587)
        
        

        //--TRIMMABLE-BOUNDARY-START(1638483)
        $asm.$cls(`$ssa.SSA.GenericAce`, ($self) => class GenericAce extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(4296605779)
            $ctor$1()
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4296605779);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296605779)
            
            //--TRIMMABLE-BOUNDARY-START(8591573075)
            /*System.Security.AccessControl.AceFlags */ get AceFlags()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(42951311443);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Security.AccessControl.AceFlags */ set AceFlags(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(133145624659);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(8591573075)
            
            //--TRIMMABLE-BOUNDARY-START(12886540371)
            /*System.Security.AccessControl.AceType */ get AceType()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(51541246035);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(12886540371)
            
            //--TRIMMABLE-BOUNDARY-START(17181507667)
            /*System.Security.AccessControl.AuditFlags */ get AuditFlags()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(60131180627);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(17181507667)
            
            //--TRIMMABLE-BOUNDARY-START(107375820883)
            /*System.Security.AccessControl.InheritanceFlags */ get InheritanceFlags()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(77311049811);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(107375820883)
            
            //--TRIMMABLE-BOUNDARY-START(111670788179)
            /*bool */ get IsInherited()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(85900984403);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(111670788179)
            
            //--TRIMMABLE-BOUNDARY-START(124555690067)
            /*System.Security.AccessControl.PropagationFlags */ get PropagationFlags()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(94490918995);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(124555690067)
            
            //--TRIMMABLE-BOUNDARY-START(25771442259)
            /*System.Security.AccessControl.GenericAce */ Copy()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25771442259);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(25771442259)
            
            //--TRIMMABLE-BOUNDARY-START(30066409555)
            static /*System.Security.AccessControl.GenericAce */ CreateFromBinaryForm(/*byte[]*/ binaryForm, /*int*/ offset)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(30066409555);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(30066409555)
            
            //--TRIMMABLE-BOUNDARY-START(34361376851)
            /*bool */ Equals$1(/*object?*/ o)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(34361376851);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(34361376851)
            
            //--TRIMMABLE-BOUNDARY-START(103080853587)
            /*int */ GetHashCode()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(103080853587);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(103080853587)
            
            //--TRIMMABLE-BOUNDARY-START(115965755475)
            static /*bool */ op_Equality(/*System.Security.AccessControl.GenericAce?*/ left, /*System.Security.AccessControl.GenericAce?*/ right)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(115965755475);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(115965755475)
            
            //--TRIMMABLE-BOUNDARY-START(120260722771)
            static /*bool */ op_Inequality(/*System.Security.AccessControl.GenericAce?*/ left, /*System.Security.AccessControl.GenericAce?*/ right)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(120260722771);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(120260722771)
            
            //--TRIMMABLE-BOUNDARY-START(4296605779)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4296605779)
            
            static $h = 1638483;
            static $f = 0b110001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(8591573075),
    {
      "p": 524371,
      "g": {
        "r": 0,
        "d": 0,
        "h": 42951311443,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 133145624659,
        "f": 83886081
      },
      "n": "AceFlags",
      "d": 1638483,
      "h": 8591573075,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(8591573075),
//--TRIMMABLE-BOUNDARY-START(12886540371),
    {
      "p": 655443,
      "g": {
        "r": 0,
        "d": 0,
        "h": 51541246035,
        "f": 50331649
      },
      "n": "AceType",
      "d": 1638483,
      "h": 12886540371,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(12886540371),
//--TRIMMABLE-BOUNDARY-START(17181507667),
    {
      "p": 720979,
      "g": {
        "r": 0,
        "d": 0,
        "h": 60131180627,
        "f": 50331649
      },
      "n": "AuditFlags",
      "d": 1638483,
      "h": 17181507667,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(17181507667),
//--TRIMMABLE-BOUNDARY-START(21476474963),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 68721115219,
        "f": 50331905
      },
      "n": "BinaryLength",
      "d": 1638483,
      "h": 21476474963,
      "f": 2097409
    },
//--TRIMMABLE-BOUNDARY-END(21476474963),
//--TRIMMABLE-BOUNDARY-START(107375820883),
    {
      "p": 1835091,
      "g": {
        "r": 0,
        "d": 0,
        "h": 77311049811,
        "f": 50331649
      },
      "n": "InheritanceFlags",
      "d": 1638483,
      "h": 107375820883,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(107375820883),
//--TRIMMABLE-BOUNDARY-START(111670788179),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 85900984403,
        "f": 50331649
      },
      "n": "IsInherited",
      "d": 1638483,
      "h": 111670788179,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(111670788179),
//--TRIMMABLE-BOUNDARY-START(124555690067),
    {
      "p": 2555987,
      "g": {
        "r": 0,
        "d": 0,
        "h": 94490918995,
        "f": 50331649
      },
      "n": "PropagationFlags",
      "d": 1638483,
      "h": 124555690067,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(124555690067)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(25771442259),
    {
      "r": 1638483,
      "n": "Copy",
      "d": 1638483,
      "h": 25771442259,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(25771442259),
//--TRIMMABLE-BOUNDARY-START(30066409555),
    {
      "r": 1638483,
      "p": [
        {
          "n": "binaryForm",
          "p": $.$typeArray($.$$.S.Byte).$h
        },
        {
          "n": "offset",
          "p": 655361
        }
      ],
      "n": "CreateFromBinaryForm",
      "d": 1638483,
      "h": 30066409555,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(30066409555),
//--TRIMMABLE-BOUNDARY-START(34361376851),
    {
      "r": 262145,
      "p": [
        {
          "n": "o",
          "p": 131073
        }
      ],
      "n": "Equals",
      "o": "@$1",
      "d": 1638483,
      "h": 34361376851,
      "f": 16875521
    },
//--TRIMMABLE-BOUNDARY-END(34361376851),
//--TRIMMABLE-BOUNDARY-START(98785886291),
    {
      "r": 65537,
      "p": [
        {
          "n": "binaryForm",
          "p": $.$typeArray($.$$.S.Byte).$h
        },
        {
          "n": "offset",
          "p": 655361
        }
      ],
      "n": "GetBinaryForm",
      "d": 1638483,
      "h": 98785886291,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(98785886291),
//--TRIMMABLE-BOUNDARY-START(103080853587),
    {
      "r": 655361,
      "n": "GetHashCode",
      "d": 1638483,
      "h": 103080853587,
      "f": 16875521
    },
//--TRIMMABLE-BOUNDARY-END(103080853587)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296605779),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 1638483,
      "h": 4296605779,
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(4296605779)
  ],
  "h": 1638483
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `System.Security.AccessControl.GenericAce`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `System${separator}Security${separator}AccessControl${separator}GenericAce`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1638483)
        
        

        //--TRIMMABLE-BOUNDARY-START(1769555)
        $asm.$cls(`$ssa.SSA.GenericSecurityDescriptor`, ($self) => class GenericSecurityDescriptor extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(4296736851)
            $ctor$1()
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4296736851);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296736851)
            
            //--TRIMMABLE-BOUNDARY-START(8591704147)
            /*int */ get BinaryLength()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21476606035);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(8591704147)
            
            //--TRIMMABLE-BOUNDARY-START(81606148179)
            static /*byte */ get Revision()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(55836344403);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(81606148179)
            
            //--TRIMMABLE-BOUNDARY-START(60131311699)
            /*void */ GetBinaryForm(/*byte[]*/ binaryForm, /*int*/ offset)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(60131311699);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
            }
            //--TRIMMABLE-BOUNDARY-END(60131311699)
            
            //--TRIMMABLE-BOUNDARY-START(64426278995)
            /*string */ GetSddlForm(/*System.Security.AccessControl.AccessControlSections*/ includeSections)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(64426278995);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(64426278995)
            
            //--TRIMMABLE-BOUNDARY-START(73016213587)
            static /*bool */ IsSddlConversionSupported()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(73016213587);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(73016213587)
            
            //--TRIMMABLE-BOUNDARY-START(4296736851)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4296736851)
            
            static $h = 1769555;
            static $f = 0b110001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(8591704147),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 21476606035,
        "f": 50331649
      },
      "n": "BinaryLength",
      "d": 1769555,
      "h": 8591704147,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(8591704147),
//--TRIMMABLE-BOUNDARY-START(12886671443),
    {
      "p": 1441875,
      "g": {
        "r": 0,
        "d": 0,
        "h": 30066540627,
        "f": 50331905
      },
      "n": "ControlFlags",
      "d": 1769555,
      "h": 12886671443,
      "f": 2097409
    },
//--TRIMMABLE-BOUNDARY-END(12886671443),
//--TRIMMABLE-BOUNDARY-START(68721246291),
    {
      "p": 393286,
      "g": {
        "r": 0,
        "d": 0,
        "h": 38656475219,
        "f": 50331905
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 90196082771,
        "f": 83886337
      },
      "n": "Group",
      "d": 1769555,
      "h": 68721246291,
      "f": 2097409
    },
//--TRIMMABLE-BOUNDARY-END(68721246291),
//--TRIMMABLE-BOUNDARY-START(77311180883),
    {
      "p": 393286,
      "g": {
        "r": 0,
        "d": 0,
        "h": 47246409811,
        "f": 50331905
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 98786017363,
        "f": 83886337
      },
      "n": "Owner",
      "d": 1769555,
      "h": 77311180883,
      "f": 2097409
    },
//--TRIMMABLE-BOUNDARY-END(77311180883),
//--TRIMMABLE-BOUNDARY-START(81606148179),
    {
      "p": 393217,
      "g": {
        "r": 0,
        "d": 0,
        "h": 55836344403,
        "f": 50331681
      },
      "n": "Revision",
      "d": 1769555,
      "h": 81606148179,
      "f": 2097185
    },
//--TRIMMABLE-BOUNDARY-END(81606148179)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(60131311699),
    {
      "r": 65537,
      "p": [
        {
          "n": "binaryForm",
          "p": $.$typeArray($.$$.S.Byte).$h
        },
        {
          "n": "offset",
          "p": 655361
        }
      ],
      "n": "GetBinaryForm",
      "d": 1769555,
      "h": 60131311699,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(60131311699),
//--TRIMMABLE-BOUNDARY-START(64426278995),
    {
      "r": 1310721,
      "p": [
        {
          "n": "includeSections",
          "p": 196691
        }
      ],
      "n": "GetSddlForm",
      "d": 1769555,
      "h": 64426278995,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(64426278995),
//--TRIMMABLE-BOUNDARY-START(73016213587),
    {
      "r": 262145,
      "n": "IsSddlConversionSupported",
      "d": 1769555,
      "h": 73016213587,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(73016213587)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296736851),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 1769555,
      "h": 4296736851,
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(4296736851)
  ],
  "h": 1769555
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `System.Security.AccessControl.GenericSecurityDescriptor`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `System${separator}Security${separator}AccessControl${separator}GenericSecurityDescriptor`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1769555)
        
        

        //--TRIMMABLE-BOUNDARY-START(2359379)
        $asm.$cls(`$ssa.SSA.ObjectSecurity`, ($self) => class ObjectSecurity extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(4297326675)
            $ctor$1()
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4297326675);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4297326675)
            
            //--TRIMMABLE-BOUNDARY-START(8592293971)
            $ctor$2(/*bool*/ isContainer, /*bool*/ isDS)
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(8592293971);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(8592293971)
            
            //--TRIMMABLE-BOUNDARY-START(12887261267)
            $ctor$3(/*System.Security.AccessControl.CommonSecurityDescriptor*/ securityDescriptor)
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(12887261267);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(12887261267)
            
            //--TRIMMABLE-BOUNDARY-START(25772163155)
            /*bool */ get AccessRulesModified()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(77311770707);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ set AccessRulesModified(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(279175233619);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(25772163155)
            
            //--TRIMMABLE-BOUNDARY-START(34362097747)
            /*bool */ get AreAccessRulesCanonical()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(94491639891);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(34362097747)
            
            //--TRIMMABLE-BOUNDARY-START(38657065043)
            /*bool */ get AreAccessRulesProtected()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(103081574483);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(38657065043)
            
            //--TRIMMABLE-BOUNDARY-START(42952032339)
            /*bool */ get AreAuditRulesCanonical()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(111671509075);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(42952032339)
            
            //--TRIMMABLE-BOUNDARY-START(47246999635)
            /*bool */ get AreAuditRulesProtected()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(120261443667);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(47246999635)
            
            //--TRIMMABLE-BOUNDARY-START(55836934227)
            /*bool */ get AuditRulesModified()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(128851378259);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ set AuditRulesModified(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(287765168211);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(55836934227)
            
            //--TRIMMABLE-BOUNDARY-START(201865822291)
            /*bool */ get GroupModified()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(146031247443);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ set GroupModified(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(296355102803);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(201865822291)
            
            //--TRIMMABLE-BOUNDARY-START(206160789587)
            /*bool */ get IsContainer()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(154621182035);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(206160789587)
            
            //--TRIMMABLE-BOUNDARY-START(210455756883)
            /*bool */ get IsDS()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(163211116627);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(210455756883)
            
            //--TRIMMABLE-BOUNDARY-START(236225560659)
            /*bool */ get OwnerModified()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(171801051219);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ set OwnerModified(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(304945037395);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(236225560659)
            
            //--TRIMMABLE-BOUNDARY-START(270585299027)
            /*System.Security.AccessControl.CommonSecurityDescriptor */ get SecurityDescriptor()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(180390985811);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(270585299027)
            
            //--TRIMMABLE-BOUNDARY-START(184685953107)
            /*System.Security.Principal.IdentityReference? */ GetGroup(/*System.Type*/ targetType)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(184685953107);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(184685953107)
            
            //--TRIMMABLE-BOUNDARY-START(188980920403)
            /*System.Security.Principal.IdentityReference? */ GetOwner(/*System.Type*/ targetType)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(188980920403);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(188980920403)
            
            //--TRIMMABLE-BOUNDARY-START(193275887699)
            /*byte[] */ GetSecurityDescriptorBinaryForm()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(193275887699);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(193275887699)
            
            //--TRIMMABLE-BOUNDARY-START(197570854995)
            /*string */ GetSecurityDescriptorSddlForm(/*System.Security.AccessControl.AccessControlSections*/ includeSections)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(197570854995);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(197570854995)
            
            //--TRIMMABLE-BOUNDARY-START(214750724179)
            static /*bool */ IsSddlConversionSupported()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(214750724179);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(214750724179)
            
            //--TRIMMABLE-BOUNDARY-START(223340658771)
            /*bool */ ModifyAccessRule(/*System.Security.AccessControl.AccessControlModification*/ modification, /*System.Security.AccessControl.AccessRule*/ rule, /*out bool*/ modified)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(223340658771);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(223340658771)
            
            //--TRIMMABLE-BOUNDARY-START(231930593363)
            /*bool */ ModifyAuditRule(/*System.Security.AccessControl.AccessControlModification*/ modification, /*System.Security.AccessControl.AuditRule*/ rule, /*out bool*/ modified)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(231930593363);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(231930593363)
            
            //--TRIMMABLE-BOUNDARY-START(240520527955)
            /*void */ Persist(/*bool*/ enableOwnershipPrivilege, /*string*/ name, /*System.Security.AccessControl.AccessControlSections*/ includeSections)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(240520527955);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
            }
            //--TRIMMABLE-BOUNDARY-END(240520527955)
            
            //--TRIMMABLE-BOUNDARY-START(244815495251)
            /*void */ Persist$1(/*System.Runtime.InteropServices.SafeHandle*/ handle, /*System.Security.AccessControl.AccessControlSections*/ includeSections)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(244815495251);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
            }
            //--TRIMMABLE-BOUNDARY-END(244815495251)
            
            //--TRIMMABLE-BOUNDARY-START(249110462547)
            /*void */ Persist$2(/*string*/ name, /*System.Security.AccessControl.AccessControlSections*/ includeSections)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(249110462547);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
            }
            //--TRIMMABLE-BOUNDARY-END(249110462547)
            
            //--TRIMMABLE-BOUNDARY-START(253405429843)
            /*void */ PurgeAccessRules(/*System.Security.Principal.IdentityReference*/ identity)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(253405429843);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
            }
            //--TRIMMABLE-BOUNDARY-END(253405429843)
            
            //--TRIMMABLE-BOUNDARY-START(257700397139)
            /*void */ PurgeAuditRules(/*System.Security.Principal.IdentityReference*/ identity)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(257700397139);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
            }
            //--TRIMMABLE-BOUNDARY-END(257700397139)
            
            //--TRIMMABLE-BOUNDARY-START(261995364435)
            /*void */ ReadLock()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(261995364435);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
            }
            //--TRIMMABLE-BOUNDARY-END(261995364435)
            
            //--TRIMMABLE-BOUNDARY-START(266290331731)
            /*void */ ReadUnlock()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(266290331731);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
            }
            //--TRIMMABLE-BOUNDARY-END(266290331731)
            
            //--TRIMMABLE-BOUNDARY-START(309240004691)
            /*void */ SetAccessRuleProtection(/*bool*/ isProtected, /*bool*/ preserveInheritance)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(309240004691);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
            }
            //--TRIMMABLE-BOUNDARY-END(309240004691)
            
            //--TRIMMABLE-BOUNDARY-START(313534971987)
            /*void */ SetAuditRuleProtection(/*bool*/ isProtected, /*bool*/ preserveInheritance)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(313534971987);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
            }
            //--TRIMMABLE-BOUNDARY-END(313534971987)
            
            //--TRIMMABLE-BOUNDARY-START(317829939283)
            /*void */ SetGroup(/*System.Security.Principal.IdentityReference*/ identity)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(317829939283);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
            }
            //--TRIMMABLE-BOUNDARY-END(317829939283)
            
            //--TRIMMABLE-BOUNDARY-START(322124906579)
            /*void */ SetOwner(/*System.Security.Principal.IdentityReference*/ identity)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(322124906579);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
            }
            //--TRIMMABLE-BOUNDARY-END(322124906579)
            
            //--TRIMMABLE-BOUNDARY-START(330714841171)
            /*void */ SetSecurityDescriptorBinaryForm$1(/*byte[]*/ binaryForm)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(330714841171);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
            }
            //--TRIMMABLE-BOUNDARY-END(330714841171)
            
            //--TRIMMABLE-BOUNDARY-START(326419873875)
            /*void */ SetSecurityDescriptorBinaryForm(/*byte[]*/ binaryForm, /*System.Security.AccessControl.AccessControlSections*/ includeSections)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(326419873875);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
            }
            //--TRIMMABLE-BOUNDARY-END(326419873875)
            
            //--TRIMMABLE-BOUNDARY-START(339304775763)
            /*void */ SetSecurityDescriptorSddlForm$1(/*string*/ sddlForm)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(339304775763);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
            }
            //--TRIMMABLE-BOUNDARY-END(339304775763)
            
            //--TRIMMABLE-BOUNDARY-START(335009808467)
            /*void */ SetSecurityDescriptorSddlForm(/*string*/ sddlForm, /*System.Security.AccessControl.AccessControlSections*/ includeSections)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(335009808467);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
            }
            //--TRIMMABLE-BOUNDARY-END(335009808467)
            
            //--TRIMMABLE-BOUNDARY-START(343599743059)
            /*void */ WriteLock()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(343599743059);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
            }
            //--TRIMMABLE-BOUNDARY-END(343599743059)
            
            //--TRIMMABLE-BOUNDARY-START(347894710355)
            /*void */ WriteUnlock()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(347894710355);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
            }
            //--TRIMMABLE-BOUNDARY-END(347894710355)
            
            //--TRIMMABLE-BOUNDARY-START(4297326675)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4297326675)
            
            static $h = 2359379;
            static $f = 0b110001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(17182228563),
    {
      "p": 188547073,
      "g": {
        "r": 0,
        "d": 0,
        "h": 68721836115,
        "f": 50331905
      },
      "n": "AccessRightType",
      "d": 2359379,
      "h": 17182228563,
      "f": 2097409
    },
//--TRIMMABLE-BOUNDARY-END(17182228563),
//--TRIMMABLE-BOUNDARY-START(25772163155),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 77311770707,
        "f": 50331652
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 279175233619,
        "f": 83886084
      },
      "n": "AccessRulesModified",
      "d": 2359379,
      "h": 25772163155,
      "f": 2097156
    },
//--TRIMMABLE-BOUNDARY-END(25772163155),
//--TRIMMABLE-BOUNDARY-START(30067130451),
    {
      "p": 188547073,
      "g": {
        "r": 0,
        "d": 0,
        "h": 85901705299,
        "f": 50331905
      },
      "n": "AccessRuleType",
      "d": 2359379,
      "h": 30067130451,
      "f": 2097409
    },
//--TRIMMABLE-BOUNDARY-END(30067130451),
//--TRIMMABLE-BOUNDARY-START(34362097747),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 94491639891,
        "f": 50331649
      },
      "n": "AreAccessRulesCanonical",
      "d": 2359379,
      "h": 34362097747,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(34362097747),
//--TRIMMABLE-BOUNDARY-START(38657065043),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 103081574483,
        "f": 50331649
      },
      "n": "AreAccessRulesProtected",
      "d": 2359379,
      "h": 38657065043,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(38657065043),
//--TRIMMABLE-BOUNDARY-START(42952032339),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 111671509075,
        "f": 50331649
      },
      "n": "AreAuditRulesCanonical",
      "d": 2359379,
      "h": 42952032339,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(42952032339),
//--TRIMMABLE-BOUNDARY-START(47246999635),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 120261443667,
        "f": 50331649
      },
      "n": "AreAuditRulesProtected",
      "d": 2359379,
      "h": 47246999635,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(47246999635),
//--TRIMMABLE-BOUNDARY-START(55836934227),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 128851378259,
        "f": 50331652
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 287765168211,
        "f": 83886084
      },
      "n": "AuditRulesModified",
      "d": 2359379,
      "h": 55836934227,
      "f": 2097156
    },
//--TRIMMABLE-BOUNDARY-END(55836934227),
//--TRIMMABLE-BOUNDARY-START(60131901523),
    {
      "p": 188547073,
      "g": {
        "r": 0,
        "d": 0,
        "h": 137441312851,
        "f": 50331905
      },
      "n": "AuditRuleType",
      "d": 2359379,
      "h": 60131901523,
      "f": 2097409
    },
//--TRIMMABLE-BOUNDARY-END(60131901523),
//--TRIMMABLE-BOUNDARY-START(201865822291),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 146031247443,
        "f": 50331652
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 296355102803,
        "f": 83886084
      },
      "n": "GroupModified",
      "d": 2359379,
      "h": 201865822291,
      "f": 2097156
    },
//--TRIMMABLE-BOUNDARY-END(201865822291),
//--TRIMMABLE-BOUNDARY-START(206160789587),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 154621182035,
        "f": 50331652
      },
      "n": "IsContainer",
      "d": 2359379,
      "h": 206160789587,
      "f": 2097156
    },
//--TRIMMABLE-BOUNDARY-END(206160789587),
//--TRIMMABLE-BOUNDARY-START(210455756883),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 163211116627,
        "f": 50331652
      },
      "n": "IsDS",
      "d": 2359379,
      "h": 210455756883,
      "f": 2097156
    },
//--TRIMMABLE-BOUNDARY-END(210455756883),
//--TRIMMABLE-BOUNDARY-START(236225560659),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 171801051219,
        "f": 50331652
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 304945037395,
        "f": 83886084
      },
      "n": "OwnerModified",
      "d": 2359379,
      "h": 236225560659,
      "f": 2097156
    },
//--TRIMMABLE-BOUNDARY-END(236225560659),
//--TRIMMABLE-BOUNDARY-START(270585299027),
    {
      "p": 1245267,
      "g": {
        "r": 0,
        "d": 0,
        "h": 180390985811,
        "f": 50331652
      },
      "n": "SecurityDescriptor",
      "d": 2359379,
      "h": 270585299027,
      "f": 2097156
    },
//--TRIMMABLE-BOUNDARY-END(270585299027)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(21477195859),
    {
      "r": 327763,
      "p": [
        {
          "n": "identityReference",
          "p": 196678
        },
        {
          "n": "accessMask",
          "p": 655361
        },
        {
          "n": "isInherited",
          "p": 262145
        },
        {
          "n": "inheritanceFlags",
          "p": 1835091
        },
        {
          "n": "propagationFlags",
          "p": 2555987
        },
        {
          "n": "type",
          "p": 262227
        }
      ],
      "n": "AccessRuleFactory",
      "d": 2359379,
      "h": 21477195859,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(21477195859),
//--TRIMMABLE-BOUNDARY-START(51541966931),
    {
      "r": 786515,
      "p": [
        {
          "n": "identityReference",
          "p": 196678
        },
        {
          "n": "accessMask",
          "p": 655361
        },
        {
          "n": "isInherited",
          "p": 262145
        },
        {
          "n": "inheritanceFlags",
          "p": 1835091
        },
        {
          "n": "propagationFlags",
          "p": 2555987
        },
        {
          "n": "flags",
          "p": 720979
        }
      ],
      "n": "AuditRuleFactory",
      "d": 2359379,
      "h": 51541966931,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(51541966931),
//--TRIMMABLE-BOUNDARY-START(184685953107),
    {
      "r": 196678,
      "p": [
        {
          "n": "targetType",
          "p": 188547073
        }
      ],
      "n": "GetGroup",
      "d": 2359379,
      "h": 184685953107,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(184685953107),
//--TRIMMABLE-BOUNDARY-START(188980920403),
    {
      "r": 196678,
      "p": [
        {
          "n": "targetType",
          "p": 188547073
        }
      ],
      "n": "GetOwner",
      "d": 2359379,
      "h": 188980920403,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(188980920403),
//--TRIMMABLE-BOUNDARY-START(193275887699),
    {
      "r": $.$typeArray($.$$.S.Byte).$h,
      "n": "GetSecurityDescriptorBinaryForm",
      "d": 2359379,
      "h": 193275887699,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(193275887699),
//--TRIMMABLE-BOUNDARY-START(197570854995),
    {
      "r": 1310721,
      "p": [
        {
          "n": "includeSections",
          "p": 196691
        }
      ],
      "n": "GetSecurityDescriptorSddlForm",
      "d": 2359379,
      "h": 197570854995,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(197570854995),
//--TRIMMABLE-BOUNDARY-START(214750724179),
    {
      "r": 262145,
      "n": "IsSddlConversionSupported",
      "d": 2359379,
      "h": 214750724179,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(214750724179),
//--TRIMMABLE-BOUNDARY-START(219045691475),
    {
      "r": 262145,
      "p": [
        {
          "n": "modification",
          "p": 131155
        },
        {
          "n": "rule",
          "p": 327763
        },
        {
          "n": "modified",
          "p": 262145,
          "f": 2
        }
      ],
      "n": "ModifyAccess",
      "d": 2359379,
      "h": 219045691475,
      "f": 16777476
    },
//--TRIMMABLE-BOUNDARY-END(219045691475),
//--TRIMMABLE-BOUNDARY-START(223340658771),
    {
      "r": 262145,
      "p": [
        {
          "n": "modification",
          "p": 131155
        },
        {
          "n": "rule",
          "p": 327763
        },
        {
          "n": "modified",
          "p": 262145,
          "f": 2
        }
      ],
      "n": "ModifyAccessRule",
      "d": 2359379,
      "h": 223340658771,
      "f": 16777345
    },
//--TRIMMABLE-BOUNDARY-END(223340658771),
//--TRIMMABLE-BOUNDARY-START(227635626067),
    {
      "r": 262145,
      "p": [
        {
          "n": "modification",
          "p": 131155
        },
        {
          "n": "rule",
          "p": 786515
        },
        {
          "n": "modified",
          "p": 262145,
          "f": 2
        }
      ],
      "n": "ModifyAudit",
      "d": 2359379,
      "h": 227635626067,
      "f": 16777476
    },
//--TRIMMABLE-BOUNDARY-END(227635626067),
//--TRIMMABLE-BOUNDARY-START(231930593363),
    {
      "r": 262145,
      "p": [
        {
          "n": "modification",
          "p": 131155
        },
        {
          "n": "rule",
          "p": 786515
        },
        {
          "n": "modified",
          "p": 262145,
          "f": 2
        }
      ],
      "n": "ModifyAuditRule",
      "d": 2359379,
      "h": 231930593363,
      "f": 16777345
    },
//--TRIMMABLE-BOUNDARY-END(231930593363),
//--TRIMMABLE-BOUNDARY-START(240520527955),
    {
      "r": 65537,
      "p": [
        {
          "n": "enableOwnershipPrivilege",
          "p": 262145
        },
        {
          "n": "name",
          "p": 1310721
        },
        {
          "n": "includeSections",
          "p": 196691
        }
      ],
      "n": "Persist",
      "d": 2359379,
      "h": 240520527955,
      "f": 16777348
    },
//--TRIMMABLE-BOUNDARY-END(240520527955),
//--TRIMMABLE-BOUNDARY-START(244815495251),
    {
      "r": 65537,
      "p": [
        {
          "n": "handle",
          "p": 147849217
        },
        {
          "n": "includeSections",
          "p": 196691
        }
      ],
      "n": "Persist",
      "o": "@$1",
      "d": 2359379,
      "h": 244815495251,
      "f": 16777348
    },
//--TRIMMABLE-BOUNDARY-END(244815495251),
//--TRIMMABLE-BOUNDARY-START(249110462547),
    {
      "r": 65537,
      "p": [
        {
          "n": "name",
          "p": 1310721
        },
        {
          "n": "includeSections",
          "p": 196691
        }
      ],
      "n": "Persist",
      "o": "@$2",
      "d": 2359379,
      "h": 249110462547,
      "f": 16777348
    },
//--TRIMMABLE-BOUNDARY-END(249110462547),
//--TRIMMABLE-BOUNDARY-START(253405429843),
    {
      "r": 65537,
      "p": [
        {
          "n": "identity",
          "p": 196678
        }
      ],
      "n": "PurgeAccessRules",
      "d": 2359379,
      "h": 253405429843,
      "f": 16777345
    },
//--TRIMMABLE-BOUNDARY-END(253405429843),
//--TRIMMABLE-BOUNDARY-START(257700397139),
    {
      "r": 65537,
      "p": [
        {
          "n": "identity",
          "p": 196678
        }
      ],
      "n": "PurgeAuditRules",
      "d": 2359379,
      "h": 257700397139,
      "f": 16777345
    },
//--TRIMMABLE-BOUNDARY-END(257700397139),
//--TRIMMABLE-BOUNDARY-START(261995364435),
    {
      "r": 65537,
      "n": "ReadLock",
      "d": 2359379,
      "h": 261995364435,
      "f": 16777220
    },
//--TRIMMABLE-BOUNDARY-END(261995364435),
//--TRIMMABLE-BOUNDARY-START(266290331731),
    {
      "r": 65537,
      "n": "ReadUnlock",
      "d": 2359379,
      "h": 266290331731,
      "f": 16777220
    },
//--TRIMMABLE-BOUNDARY-END(266290331731),
//--TRIMMABLE-BOUNDARY-START(309240004691),
    {
      "r": 65537,
      "p": [
        {
          "n": "isProtected",
          "p": 262145
        },
        {
          "n": "preserveInheritance",
          "p": 262145
        }
      ],
      "n": "SetAccessRuleProtection",
      "d": 2359379,
      "h": 309240004691,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(309240004691),
//--TRIMMABLE-BOUNDARY-START(313534971987),
    {
      "r": 65537,
      "p": [
        {
          "n": "isProtected",
          "p": 262145
        },
        {
          "n": "preserveInheritance",
          "p": 262145
        }
      ],
      "n": "SetAuditRuleProtection",
      "d": 2359379,
      "h": 313534971987,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(313534971987),
//--TRIMMABLE-BOUNDARY-START(317829939283),
    {
      "r": 65537,
      "p": [
        {
          "n": "identity",
          "p": 196678
        }
      ],
      "n": "SetGroup",
      "d": 2359379,
      "h": 317829939283,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(317829939283),
//--TRIMMABLE-BOUNDARY-START(322124906579),
    {
      "r": 65537,
      "p": [
        {
          "n": "identity",
          "p": 196678
        }
      ],
      "n": "SetOwner",
      "d": 2359379,
      "h": 322124906579,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(322124906579),
//--TRIMMABLE-BOUNDARY-START(330714841171),
    {
      "r": 65537,
      "p": [
        {
          "n": "binaryForm",
          "p": $.$typeArray($.$$.S.Byte).$h
        }
      ],
      "n": "SetSecurityDescriptorBinaryForm",
      "o": "@$1",
      "d": 2359379,
      "h": 330714841171,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(330714841171),
//--TRIMMABLE-BOUNDARY-START(326419873875),
    {
      "r": 65537,
      "p": [
        {
          "n": "binaryForm",
          "p": $.$typeArray($.$$.S.Byte).$h
        },
        {
          "n": "includeSections",
          "p": 196691
        }
      ],
      "n": "SetSecurityDescriptorBinaryForm",
      "d": 2359379,
      "h": 326419873875,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(326419873875),
//--TRIMMABLE-BOUNDARY-START(339304775763),
    {
      "r": 65537,
      "p": [
        {
          "n": "sddlForm",
          "p": 1310721
        }
      ],
      "n": "SetSecurityDescriptorSddlForm",
      "o": "@$1",
      "d": 2359379,
      "h": 339304775763,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(339304775763),
//--TRIMMABLE-BOUNDARY-START(335009808467),
    {
      "r": 65537,
      "p": [
        {
          "n": "sddlForm",
          "p": 1310721
        },
        {
          "n": "includeSections",
          "p": 196691
        }
      ],
      "n": "SetSecurityDescriptorSddlForm",
      "d": 2359379,
      "h": 335009808467,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(335009808467),
//--TRIMMABLE-BOUNDARY-START(343599743059),
    {
      "r": 65537,
      "n": "WriteLock",
      "d": 2359379,
      "h": 343599743059,
      "f": 16777220
    },
//--TRIMMABLE-BOUNDARY-END(343599743059),
//--TRIMMABLE-BOUNDARY-START(347894710355),
    {
      "r": 65537,
      "n": "WriteUnlock",
      "d": 2359379,
      "h": 347894710355,
      "f": 16777220
    },
//--TRIMMABLE-BOUNDARY-END(347894710355)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4297326675),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 2359379,
      "h": 4297326675,
      "f": 16777220
    },
//--TRIMMABLE-BOUNDARY-END(4297326675),
//--TRIMMABLE-BOUNDARY-START(8592293971),
    {
      "p": [
        {
          "n": "isContainer",
          "p": 262145
        },
        {
          "n": "isDS",
          "p": 262145
        }
      ],
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 2359379,
      "h": 8592293971,
      "f": 16777220
    },
//--TRIMMABLE-BOUNDARY-END(8592293971),
//--TRIMMABLE-BOUNDARY-START(12887261267),
    {
      "p": [
        {
          "n": "securityDescriptor",
          "p": 1245267
        }
      ],
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 2359379,
      "h": 12887261267,
      "f": 16777220
    },
//--TRIMMABLE-BOUNDARY-END(12887261267)
  ],
  "h": 2359379
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `System.Security.AccessControl.ObjectSecurity`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `System${separator}Security${separator}AccessControl${separator}ObjectSecurity`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2359379)
        
        

        //--TRIMMABLE-BOUNDARY-START(3080275)
        $asm.$cls(`$ssa.SSP.EvidenceBase`, ($self) => class EvidenceBase extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(4298047571)
            $ctor$1()
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4298047571);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4298047571)
            
            //--TRIMMABLE-BOUNDARY-START(8593014867)
            /*System.Security.Policy.EvidenceBase? */ Clone()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8593014867);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(8593014867)
            
            //--TRIMMABLE-BOUNDARY-START(4298047571)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4298047571)
            
            static $h = 3080275;
            static $f = 0b110001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8593014867),
    {
      "r": 3080275,
      "n": "Clone",
      "d": 3080275,
      "h": 8593014867,
      "f": 16777345
    },
//--TRIMMABLE-BOUNDARY-END(8593014867)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4298047571),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 3080275,
      "h": 4298047571,
      "f": 16777220
    },
//--TRIMMABLE-BOUNDARY-END(4298047571)
  ],
  "h": 3080275
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `System.Security.Policy.EvidenceBase`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `System${separator}Security${separator}Policy${separator}EvidenceBase`; }
        });
        //--TRIMMABLE-BOUNDARY-END(3080275)
        
        

        //--TRIMMABLE-BOUNDARY-START(1704019)
        $asm.$cls(`$ssa.SSA.GenericAcl`, ($self) => class GenericAcl extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8591638611)
            /*byte*/ static AclRevision = 0;
            //--TRIMMABLE-BOUNDARY-END(8591638611)
            
            //--TRIMMABLE-BOUNDARY-START(12886605907)
            /*byte*/ static AclRevisionDS = 0;
            //--TRIMMABLE-BOUNDARY-END(12886605907)
            
            //--TRIMMABLE-BOUNDARY-START(94490984531)
            /*int*/ static MaxBinaryLength = 0;
            //--TRIMMABLE-BOUNDARY-END(94490984531)
            
            //--TRIMMABLE-BOUNDARY-START(4296671315)
            $ctor$1()
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4296671315);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296671315)
            
            //--TRIMMABLE-BOUNDARY-START(90196017235)
            /*bool */ get IsSynchronized()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(51541311571);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(90196017235)
            
            //--TRIMMABLE-BOUNDARY-START(111670853715)
            /*object */ get SyncRoot()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(77311115347);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(111670853715)
            
            //--TRIMMABLE-BOUNDARY-START(21476540499)
            /*void */ CopyTo(/*System.Security.AccessControl.GenericAce[]*/ array, /*int*/ index)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21476540499);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
            }
            //--TRIMMABLE-BOUNDARY-END(21476540499)
            
            //--TRIMMABLE-BOUNDARY-START(85901049939)
            /*System.Security.AccessControl.AceEnumerator */ GetEnumerator()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(85901049939);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(85901049939)
            
            //--TRIMMABLE-BOUNDARY-START(115965821011)
            /*void */ SC$1$ICollection$CopyTo(/*System.Array*/ array, /*int*/ index)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(115965821011);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
            }
            //--TRIMMABLE-BOUNDARY-END(115965821011)
            
            //--TRIMMABLE-BOUNDARY-START(120260788307)
            /*System.Collections.IEnumerator */ SC$1$IEnumerable$GetEnumerator()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(120260788307);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(120260788307)
            
            //--TRIMMABLE-BOUNDARY-START(17242980353)
            //Generated interface implemetation for System.Collections.ICollection.Count.get
            get SC$1$ICollection$Count()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8653045761);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Count;
            }
            //--TRIMMABLE-BOUNDARY-END(17242980353)
            
            //--TRIMMABLE-BOUNDARY-START(34422849537)
            //Generated interface implemetation for System.Collections.ICollection.SyncRoot.get
            get SC$1$ICollection$SyncRoot()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(43012784129);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.SyncRoot;
            }
            //--TRIMMABLE-BOUNDARY-END(34422849537)
            
            //--TRIMMABLE-BOUNDARY-START(25832914945)
            //Generated interface implemetation for System.Collections.ICollection.IsSynchronized.get
            get SC$1$ICollection$IsSynchronized()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(38717816833);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.IsSynchronized;
            }
            //--TRIMMABLE-BOUNDARY-END(25832914945)
            
            //--TRIMMABLE-BOUNDARY-START(4296671315)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4296671315)
            
            static $h = 1704019;
            static $f = 0b110001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(17181573203),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 34361442387,
        "f": 50331905
      },
      "n": "BinaryLength",
      "d": 1704019,
      "h": 17181573203,
      "f": 2097409
    },
//--TRIMMABLE-BOUNDARY-END(17181573203),
//--TRIMMABLE-BOUNDARY-START(25771507795),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 42951376979,
        "f": 50331905
      },
      "n": "Count",
      "d": 1704019,
      "h": 25771507795,
      "f": 2097409
    },
//--TRIMMABLE-BOUNDARY-END(25771507795),
//--TRIMMABLE-BOUNDARY-START(90196017235),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 51541311571,
        "f": 50331649
      },
      "n": "IsSynchronized",
      "d": 1704019,
      "h": 90196017235,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(90196017235),
//--TRIMMABLE-BOUNDARY-START(124555755603),
    {
      "p": 1638483,
      "i": [
        {
          "n": "index",
          "p": 655361
        }
      ],
      "g": {
        "r": 0,
        "d": 0,
        "h": 60131246163,
        "f": 50331905
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 107375886419,
        "f": 83886337
      },
      "n": "Item",
      "o": "@$1",
      "d": 1704019,
      "h": 124555755603,
      "f": 538968321
    },
//--TRIMMABLE-BOUNDARY-END(124555755603),
//--TRIMMABLE-BOUNDARY-START(98785951827),
    {
      "p": 393217,
      "g": {
        "r": 0,
        "d": 0,
        "h": 68721180755,
        "f": 50331905
      },
      "n": "Revision",
      "d": 1704019,
      "h": 98785951827,
      "f": 2097409
    },
//--TRIMMABLE-BOUNDARY-END(98785951827),
//--TRIMMABLE-BOUNDARY-START(111670853715),
    {
      "p": 131073,
      "g": {
        "r": 0,
        "d": 0,
        "h": 77311115347,
        "f": 50331777
      },
      "n": "SyncRoot",
      "d": 1704019,
      "h": 111670853715,
      "f": 2097281
    },
//--TRIMMABLE-BOUNDARY-END(111670853715)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(21476540499),
    {
      "r": 65537,
      "p": [
        {
          "n": "array",
          "p": $.$typeArray($.$ssa.SSA.GenericAce).$h
        },
        {
          "n": "index",
          "p": 655361
        }
      ],
      "n": "CopyTo",
      "d": 1704019,
      "h": 21476540499,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(21476540499),
//--TRIMMABLE-BOUNDARY-START(81606082643),
    {
      "r": 65537,
      "p": [
        {
          "n": "binaryForm",
          "p": $.$typeArray($.$$.S.Byte).$h
        },
        {
          "n": "offset",
          "p": 655361
        }
      ],
      "n": "GetBinaryForm",
      "d": 1704019,
      "h": 81606082643,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(81606082643),
//--TRIMMABLE-BOUNDARY-START(85901049939),
    {
      "r": 458835,
      "n": "GetEnumerator",
      "d": 1704019,
      "h": 85901049939,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(85901049939)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(8591638611),
    {
      "t": 393217,
      "n": "AclRevision",
      "d": 1704019,
      "h": 8591638611,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(8591638611),
//--TRIMMABLE-BOUNDARY-START(12886605907),
    {
      "t": 393217,
      "n": "AclRevisionDS",
      "d": 1704019,
      "h": 12886605907,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(12886605907),
//--TRIMMABLE-BOUNDARY-START(94490984531),
    {
      "t": 655361,
      "n": "MaxBinaryLength",
      "d": 1704019,
      "h": 94490984531,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(94490984531)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296671315),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 1704019,
      "h": 4296671315,
      "f": 16777220
    },
//--TRIMMABLE-BOUNDARY-END(4296671315)
  ],
  "h": 1704019
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.SC$1.ICollection, $.$$.SC$1.IEnumerable ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `System.Security.AccessControl.GenericAcl`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `System${separator}Security${separator}AccessControl${separator}GenericAcl`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1704019)
        
        

        //--TRIMMABLE-BOUNDARY-START(327763)
        $asm.$cls(`$ssa.SSA.AccessRule`, ($self) => class AccessRule extends $.$ssa.SSA.AuthorizationRule
        {
            //--TRIMMABLE-BOUNDARY-START(4295295059)
            $ctor$2(/*System.Security.Principal.IdentityReference*/ identity, /*int*/ accessMask, /*bool*/ isInherited, /*System.Security.AccessControl.InheritanceFlags*/ inheritanceFlags, /*System.Security.AccessControl.PropagationFlags*/ propagationFlags, /*System.Security.AccessControl.AccessControlType*/ type)
            {
                super.$ctor$1(null, 0, false, 0, 0);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4295295059);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295295059)
            
            //--TRIMMABLE-BOUNDARY-START(8590262355)
            /*System.Security.AccessControl.AccessControlType */ get AccessControlType()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17180196947);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(8590262355)
            
            static $h = 327763;
            static $f = 0b110001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$ssa.SSA.AuthorizationRule; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(8590262355),
    {
      "p": 262227,
      "g": {
        "r": 0,
        "d": 0,
        "h": 17180196947,
        "f": 50331649
      },
      "n": "AccessControlType",
      "d": 327763,
      "h": 8590262355,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(8590262355)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295295059),
    {
      "p": [
        {
          "n": "identity",
          "p": 196678
        },
        {
          "n": "accessMask",
          "p": 655361
        },
        {
          "n": "isInherited",
          "p": 262145
        },
        {
          "n": "inheritanceFlags",
          "p": 1835091
        },
        {
          "n": "propagationFlags",
          "p": 2555987
        },
        {
          "n": "type",
          "p": 262227
        }
      ],
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 327763,
      "h": 4295295059,
      "f": 16777220
    },
//--TRIMMABLE-BOUNDARY-END(4295295059)
  ],
  "h": 327763
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `System.Security.AccessControl.AccessRule`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `System${separator}Security${separator}AccessControl${separator}AccessRule`; }
        });
        //--TRIMMABLE-BOUNDARY-END(327763)
        
        

        //--TRIMMABLE-BOUNDARY-START(786515)
        $asm.$cls(`$ssa.SSA.AuditRule`, ($self) => class AuditRule extends $.$ssa.SSA.AuthorizationRule
        {
            //--TRIMMABLE-BOUNDARY-START(4295753811)
            $ctor$2(/*System.Security.Principal.IdentityReference*/ identity, /*int*/ accessMask, /*bool*/ isInherited, /*System.Security.AccessControl.InheritanceFlags*/ inheritanceFlags, /*System.Security.AccessControl.PropagationFlags*/ propagationFlags, /*System.Security.AccessControl.AuditFlags*/ auditFlags)
            {
                super.$ctor$1(null, 0, false, 0, 0);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4295753811);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295753811)
            
            //--TRIMMABLE-BOUNDARY-START(8590721107)
            /*System.Security.AccessControl.AuditFlags */ get AuditFlags()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17180655699);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(8590721107)
            
            static $h = 786515;
            static $f = 0b110001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$ssa.SSA.AuthorizationRule; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(8590721107),
    {
      "p": 720979,
      "g": {
        "r": 0,
        "d": 0,
        "h": 17180655699,
        "f": 50331649
      },
      "n": "AuditFlags",
      "d": 786515,
      "h": 8590721107,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(8590721107)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295753811),
    {
      "p": [
        {
          "n": "identity",
          "p": 196678
        },
        {
          "n": "accessMask",
          "p": 655361
        },
        {
          "n": "isInherited",
          "p": 262145
        },
        {
          "n": "inheritanceFlags",
          "p": 1835091
        },
        {
          "n": "propagationFlags",
          "p": 2555987
        },
        {
          "n": "auditFlags",
          "p": 720979
        }
      ],
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 786515,
      "h": 4295753811,
      "f": 16777220
    },
//--TRIMMABLE-BOUNDARY-END(4295753811)
  ],
  "h": 786515
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `System.Security.AccessControl.AuditRule`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `System${separator}Security${separator}AccessControl${separator}AuditRule`; }
        });
        //--TRIMMABLE-BOUNDARY-END(786515)
        
        

        //--TRIMMABLE-BOUNDARY-START(1179731)
        $asm.$cls(`$ssa.SSA.CommonObjectSecurity`, ($self) => class CommonObjectSecurity extends $.$ssa.SSA.ObjectSecurity
        {
            //--TRIMMABLE-BOUNDARY-START(4296147027)
            $ctor$4(/*bool*/ isContainer)
            {
                super.$ctor$1();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4296147027);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296147027)
            
            //--TRIMMABLE-BOUNDARY-START(8591114323)
            /*void */ AddAccessRule(/*System.Security.AccessControl.AccessRule*/ rule)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591114323);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
            }
            //--TRIMMABLE-BOUNDARY-END(8591114323)
            
            //--TRIMMABLE-BOUNDARY-START(12886081619)
            /*void */ AddAuditRule(/*System.Security.AccessControl.AuditRule*/ rule)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12886081619);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
            }
            //--TRIMMABLE-BOUNDARY-END(12886081619)
            
            //--TRIMMABLE-BOUNDARY-START(17181048915)
            /*System.Security.AccessControl.AuthorizationRuleCollection */ GetAccessRules(/*bool*/ includeExplicit, /*bool*/ includeInherited, /*System.Type*/ targetType)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17181048915);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(17181048915)
            
            //--TRIMMABLE-BOUNDARY-START(21476016211)
            /*System.Security.AccessControl.AuthorizationRuleCollection */ GetAuditRules(/*bool*/ includeExplicit, /*bool*/ includeInherited, /*System.Type*/ targetType)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21476016211);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(21476016211)
            
            //--TRIMMABLE-BOUNDARY-START(25770983507)
            /*bool */ ModifyAccess(/*System.Security.AccessControl.AccessControlModification*/ modification, /*System.Security.AccessControl.AccessRule*/ rule, /*out bool*/ modified)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25770983507);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(25770983507)
            
            //--TRIMMABLE-BOUNDARY-START(30065950803)
            /*bool */ ModifyAudit(/*System.Security.AccessControl.AccessControlModification*/ modification, /*System.Security.AccessControl.AuditRule*/ rule, /*out bool*/ modified)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(30065950803);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(30065950803)
            
            //--TRIMMABLE-BOUNDARY-START(34360918099)
            /*bool */ RemoveAccessRule(/*System.Security.AccessControl.AccessRule*/ rule)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(34360918099);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(34360918099)
            
            //--TRIMMABLE-BOUNDARY-START(38655885395)
            /*void */ RemoveAccessRuleAll(/*System.Security.AccessControl.AccessRule*/ rule)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(38655885395);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
            }
            //--TRIMMABLE-BOUNDARY-END(38655885395)
            
            //--TRIMMABLE-BOUNDARY-START(42950852691)
            /*void */ RemoveAccessRuleSpecific(/*System.Security.AccessControl.AccessRule*/ rule)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(42950852691);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
            }
            //--TRIMMABLE-BOUNDARY-END(42950852691)
            
            //--TRIMMABLE-BOUNDARY-START(47245819987)
            /*bool */ RemoveAuditRule(/*System.Security.AccessControl.AuditRule*/ rule)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(47245819987);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(47245819987)
            
            //--TRIMMABLE-BOUNDARY-START(51540787283)
            /*void */ RemoveAuditRuleAll(/*System.Security.AccessControl.AuditRule*/ rule)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(51540787283);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
            }
            //--TRIMMABLE-BOUNDARY-END(51540787283)
            
            //--TRIMMABLE-BOUNDARY-START(55835754579)
            /*void */ RemoveAuditRuleSpecific(/*System.Security.AccessControl.AuditRule*/ rule)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(55835754579);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
            }
            //--TRIMMABLE-BOUNDARY-END(55835754579)
            
            //--TRIMMABLE-BOUNDARY-START(60130721875)
            /*void */ ResetAccessRule(/*System.Security.AccessControl.AccessRule*/ rule)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(60130721875);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
            }
            //--TRIMMABLE-BOUNDARY-END(60130721875)
            
            //--TRIMMABLE-BOUNDARY-START(64425689171)
            /*void */ SetAccessRule(/*System.Security.AccessControl.AccessRule*/ rule)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(64425689171);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
            }
            //--TRIMMABLE-BOUNDARY-END(64425689171)
            
            //--TRIMMABLE-BOUNDARY-START(68720656467)
            /*void */ SetAuditRule(/*System.Security.AccessControl.AuditRule*/ rule)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(68720656467);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
            }
            //--TRIMMABLE-BOUNDARY-END(68720656467)
            
            static $h = 1179731;
            static $f = 0b110001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$ssa.SSA.ObjectSecurity; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8591114323),
    {
      "r": 65537,
      "p": [
        {
          "n": "rule",
          "p": 327763
        }
      ],
      "n": "AddAccessRule",
      "d": 1179731,
      "h": 8591114323,
      "f": 16777220
    },
//--TRIMMABLE-BOUNDARY-END(8591114323),
//--TRIMMABLE-BOUNDARY-START(12886081619),
    {
      "r": 65537,
      "p": [
        {
          "n": "rule",
          "p": 786515
        }
      ],
      "n": "AddAuditRule",
      "d": 1179731,
      "h": 12886081619,
      "f": 16777220
    },
//--TRIMMABLE-BOUNDARY-END(12886081619),
//--TRIMMABLE-BOUNDARY-START(17181048915),
    {
      "r": 983123,
      "p": [
        {
          "n": "includeExplicit",
          "p": 262145
        },
        {
          "n": "includeInherited",
          "p": 262145
        },
        {
          "n": "targetType",
          "p": 188547073
        }
      ],
      "n": "GetAccessRules",
      "d": 1179731,
      "h": 17181048915,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(17181048915),
//--TRIMMABLE-BOUNDARY-START(21476016211),
    {
      "r": 983123,
      "p": [
        {
          "n": "includeExplicit",
          "p": 262145
        },
        {
          "n": "includeInherited",
          "p": 262145
        },
        {
          "n": "targetType",
          "p": 188547073
        }
      ],
      "n": "GetAuditRules",
      "d": 1179731,
      "h": 21476016211,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(21476016211),
//--TRIMMABLE-BOUNDARY-START(25770983507),
    {
      "r": 262145,
      "p": [
        {
          "n": "modification",
          "p": 131155
        },
        {
          "n": "rule",
          "p": 327763
        },
        {
          "n": "modified",
          "p": 262145,
          "f": 2
        }
      ],
      "n": "ModifyAccess",
      "d": 1179731,
      "h": 25770983507,
      "f": 16809988
    },
//--TRIMMABLE-BOUNDARY-END(25770983507),
//--TRIMMABLE-BOUNDARY-START(30065950803),
    {
      "r": 262145,
      "p": [
        {
          "n": "modification",
          "p": 131155
        },
        {
          "n": "rule",
          "p": 786515
        },
        {
          "n": "modified",
          "p": 262145,
          "f": 2
        }
      ],
      "n": "ModifyAudit",
      "d": 1179731,
      "h": 30065950803,
      "f": 16809988
    },
//--TRIMMABLE-BOUNDARY-END(30065950803),
//--TRIMMABLE-BOUNDARY-START(34360918099),
    {
      "r": 262145,
      "p": [
        {
          "n": "rule",
          "p": 327763
        }
      ],
      "n": "RemoveAccessRule",
      "d": 1179731,
      "h": 34360918099,
      "f": 16777220
    },
//--TRIMMABLE-BOUNDARY-END(34360918099),
//--TRIMMABLE-BOUNDARY-START(38655885395),
    {
      "r": 65537,
      "p": [
        {
          "n": "rule",
          "p": 327763
        }
      ],
      "n": "RemoveAccessRuleAll",
      "d": 1179731,
      "h": 38655885395,
      "f": 16777220
    },
//--TRIMMABLE-BOUNDARY-END(38655885395),
//--TRIMMABLE-BOUNDARY-START(42950852691),
    {
      "r": 65537,
      "p": [
        {
          "n": "rule",
          "p": 327763
        }
      ],
      "n": "RemoveAccessRuleSpecific",
      "d": 1179731,
      "h": 42950852691,
      "f": 16777220
    },
//--TRIMMABLE-BOUNDARY-END(42950852691),
//--TRIMMABLE-BOUNDARY-START(47245819987),
    {
      "r": 262145,
      "p": [
        {
          "n": "rule",
          "p": 786515
        }
      ],
      "n": "RemoveAuditRule",
      "d": 1179731,
      "h": 47245819987,
      "f": 16777220
    },
//--TRIMMABLE-BOUNDARY-END(47245819987),
//--TRIMMABLE-BOUNDARY-START(51540787283),
    {
      "r": 65537,
      "p": [
        {
          "n": "rule",
          "p": 786515
        }
      ],
      "n": "RemoveAuditRuleAll",
      "d": 1179731,
      "h": 51540787283,
      "f": 16777220
    },
//--TRIMMABLE-BOUNDARY-END(51540787283),
//--TRIMMABLE-BOUNDARY-START(55835754579),
    {
      "r": 65537,
      "p": [
        {
          "n": "rule",
          "p": 786515
        }
      ],
      "n": "RemoveAuditRuleSpecific",
      "d": 1179731,
      "h": 55835754579,
      "f": 16777220
    },
//--TRIMMABLE-BOUNDARY-END(55835754579),
//--TRIMMABLE-BOUNDARY-START(60130721875),
    {
      "r": 65537,
      "p": [
        {
          "n": "rule",
          "p": 327763
        }
      ],
      "n": "ResetAccessRule",
      "d": 1179731,
      "h": 60130721875,
      "f": 16777220
    },
//--TRIMMABLE-BOUNDARY-END(60130721875),
//--TRIMMABLE-BOUNDARY-START(64425689171),
    {
      "r": 65537,
      "p": [
        {
          "n": "rule",
          "p": 327763
        }
      ],
      "n": "SetAccessRule",
      "d": 1179731,
      "h": 64425689171,
      "f": 16777220
    },
//--TRIMMABLE-BOUNDARY-END(64425689171),
//--TRIMMABLE-BOUNDARY-START(68720656467),
    {
      "r": 65537,
      "p": [
        {
          "n": "rule",
          "p": 786515
        }
      ],
      "n": "SetAuditRule",
      "d": 1179731,
      "h": 68720656467,
      "f": 16777220
    },
//--TRIMMABLE-BOUNDARY-END(68720656467)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296147027),
    {
      "p": [
        {
          "n": "isContainer",
          "p": 262145
        }
      ],
      "n": ".ctor",
      "o": "$ctor$4",
      "d": 1179731,
      "h": 4296147027,
      "f": 16777220
    },
//--TRIMMABLE-BOUNDARY-END(4296147027)
  ],
  "h": 1179731
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `System.Security.AccessControl.CommonObjectSecurity`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `System${separator}Security${separator}AccessControl${separator}CommonObjectSecurity`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1179731)
        
        

        //--TRIMMABLE-BOUNDARY-START(1900627)
        $asm.$cls(`$ssa.SSA.KnownAce`, ($self) => class KnownAce extends $.$ssa.SSA.GenericAce
        {
            //--TRIMMABLE-BOUNDARY-START(4296867923)
            $ctor$2()
            {
                super.$ctor$1();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4296867923);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296867923)
            
            //--TRIMMABLE-BOUNDARY-START(8591835219)
            /*int */ get AccessMask()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17181769811);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ set AccessMask(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(38656606291);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(8591835219)
            
            //--TRIMMABLE-BOUNDARY-START(30066671699)
            /*System.Security.Principal.SecurityIdentifier */ get SecurityIdentifier()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25771704403);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Security.Principal.SecurityIdentifier */ set SecurityIdentifier(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(47246540883);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(30066671699)
            
            //--TRIMMABLE-BOUNDARY-START(4296867923)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$2();
            }
            //--TRIMMABLE-BOUNDARY-END(4296867923)
            
            static $h = 1900627;
            static $f = 0b110001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$ssa.SSA.GenericAce; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(8591835219),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 17181769811,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 38656606291,
        "f": 83886081
      },
      "n": "AccessMask",
      "d": 1900627,
      "h": 8591835219,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(8591835219),
//--TRIMMABLE-BOUNDARY-START(30066671699),
    {
      "p": 393286,
      "g": {
        "r": 0,
        "d": 0,
        "h": 25771704403,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 47246540883,
        "f": 83886081
      },
      "n": "SecurityIdentifier",
      "d": 1900627,
      "h": 30066671699,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(30066671699)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296867923),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 1900627,
      "h": 4296867923,
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(4296867923)
  ],
  "h": 1900627
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `System.Security.AccessControl.KnownAce`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `System${separator}Security${separator}AccessControl${separator}KnownAce`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1900627)
        
        

        //--TRIMMABLE-BOUNDARY-START(1114195)
        $asm.$cls(`$ssa.SSA.CommonAcl`, ($self) => class CommonAcl extends $.$ssa.SSA.GenericAcl
        {
            //--TRIMMABLE-BOUNDARY-START(4296081491)
            $ctor$2()
            {
                super.$ctor$1();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4296081491);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296081491)
            
            //--TRIMMABLE-BOUNDARY-START(8591048787)
            /*int */ get BinaryLength()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21475950675);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(8591048787)
            
            //--TRIMMABLE-BOUNDARY-START(12886016083)
            /*int */ get Count()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(30065885267);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(12886016083)
            
            //--TRIMMABLE-BOUNDARY-START(81605492819)
            /*bool */ get IsCanonical()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(38655819859);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(81605492819)
            
            //--TRIMMABLE-BOUNDARY-START(85900460115)
            /*bool */ get IsContainer()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(47245754451);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(85900460115)
            
            //--TRIMMABLE-BOUNDARY-START(90195427411)
            /*bool */ get IsDS()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(55835689043);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(90195427411)
            
            //--TRIMMABLE-BOUNDARY-START(115965231187)
            /*System.Security.AccessControl.GenericAce*/ get_Item$1(/*int*/ index)
            {
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            /*void*/ set_Item$1(/*int*/ index, /*System.Security.AccessControl.GenericAce*/ value)
            {
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(115965231187)
            
            //--TRIMMABLE-BOUNDARY-START(103080329299)
            /*byte */ get Revision()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(73015558227);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(103080329299)
            
            //--TRIMMABLE-BOUNDARY-START(77310525523)
            /*void */ GetBinaryForm(/*byte[]*/ binaryForm, /*int*/ offset)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(77310525523);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
            }
            //--TRIMMABLE-BOUNDARY-END(77310525523)
            
            //--TRIMMABLE-BOUNDARY-START(94490394707)
            /*void */ Purge(/*System.Security.Principal.SecurityIdentifier*/ sid)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(94490394707);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
            }
            //--TRIMMABLE-BOUNDARY-END(94490394707)
            
            //--TRIMMABLE-BOUNDARY-START(98785362003)
            /*void */ RemoveInheritedAces()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(98785362003);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
            }
            //--TRIMMABLE-BOUNDARY-END(98785362003)
            
            //--TRIMMABLE-BOUNDARY-START(4296081491)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$2();
            }
            //--TRIMMABLE-BOUNDARY-END(4296081491)
            
            static $h = 1114195;
            static $f = 0b110001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$ssa.SSA.GenericAcl; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(8591048787),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 21475950675,
        "f": 50429953
      },
      "n": "BinaryLength",
      "d": 1114195,
      "h": 8591048787,
      "f": 2195457
    },
//--TRIMMABLE-BOUNDARY-END(8591048787),
//--TRIMMABLE-BOUNDARY-START(12886016083),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 30065885267,
        "f": 50429953
      },
      "n": "Count",
      "d": 1114195,
      "h": 12886016083,
      "f": 2195457
    },
//--TRIMMABLE-BOUNDARY-END(12886016083),
//--TRIMMABLE-BOUNDARY-START(81605492819),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 38655819859,
        "f": 50331649
      },
      "n": "IsCanonical",
      "d": 1114195,
      "h": 81605492819,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(81605492819),
//--TRIMMABLE-BOUNDARY-START(85900460115),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 47245754451,
        "f": 50331649
      },
      "n": "IsContainer",
      "d": 1114195,
      "h": 85900460115,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(85900460115),
//--TRIMMABLE-BOUNDARY-START(90195427411),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 55835689043,
        "f": 50331649
      },
      "n": "IsDS",
      "d": 1114195,
      "h": 90195427411,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(90195427411),
//--TRIMMABLE-BOUNDARY-START(115965231187),
    {
      "p": 1638483,
      "i": [
        {
          "n": "index",
          "p": 655361
        }
      ],
      "g": {
        "r": 0,
        "d": 0,
        "h": 64425623635,
        "f": 50429953
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 111670263891,
        "f": 83984385
      },
      "n": "Item",
      "o": "@$1",
      "d": 1114195,
      "h": 115965231187,
      "f": 2195457
    },
//--TRIMMABLE-BOUNDARY-END(115965231187),
//--TRIMMABLE-BOUNDARY-START(103080329299),
    {
      "p": 393217,
      "g": {
        "r": 0,
        "d": 0,
        "h": 73015558227,
        "f": 50429953
      },
      "n": "Revision",
      "d": 1114195,
      "h": 103080329299,
      "f": 2195457
    },
//--TRIMMABLE-BOUNDARY-END(103080329299)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(77310525523),
    {
      "r": 65537,
      "p": [
        {
          "n": "binaryForm",
          "p": $.$typeArray($.$$.S.Byte).$h
        },
        {
          "n": "offset",
          "p": 655361
        }
      ],
      "n": "GetBinaryForm",
      "d": 1114195,
      "h": 77310525523,
      "f": 16875521
    },
//--TRIMMABLE-BOUNDARY-END(77310525523),
//--TRIMMABLE-BOUNDARY-START(94490394707),
    {
      "r": 65537,
      "p": [
        {
          "n": "sid",
          "p": 393286
        }
      ],
      "n": "Purge",
      "d": 1114195,
      "h": 94490394707,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(94490394707),
//--TRIMMABLE-BOUNDARY-START(98785362003),
    {
      "r": 65537,
      "n": "RemoveInheritedAces",
      "d": 1114195,
      "h": 98785362003,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(98785362003)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296081491),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 1114195,
      "h": 4296081491,
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(4296081491)
  ],
  "h": 1114195
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.SC$1.ICollection, $.$$.SC$1.IEnumerable ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `System.Security.AccessControl.CommonAcl`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `System${separator}Security${separator}AccessControl${separator}CommonAcl`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1114195)
        
        

        //--TRIMMABLE-BOUNDARY-START(1966163)
        $asm.$cls(`$ssa.SSA.NativeObjectSecurity`, ($self) => class NativeObjectSecurity extends $.$ssa.SSA.CommonObjectSecurity
        {
            //--TRIMMABLE-BOUNDARY-START(25771769939)
            $ctor$10(/*bool*/ isContainer, /*System.Security.AccessControl.ResourceType*/ resourceType)
            {
                super.$ctor$4(false);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(25771769939);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(25771769939)
            
            //--TRIMMABLE-BOUNDARY-START(8591900755)
            $ctor$6(/*bool*/ isContainer, /*System.Security.AccessControl.ResourceType*/ resourceType, /*System.Runtime.InteropServices.SafeHandle?*/ handle, /*System.Security.AccessControl.AccessControlSections*/ includeSections)
            {
                super.$ctor$4(false);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(8591900755);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(8591900755)
            
            //--TRIMMABLE-BOUNDARY-START(4296933459)
            $ctor$5(/*bool*/ isContainer, /*System.Security.AccessControl.ResourceType*/ resourceType, /*System.Runtime.InteropServices.SafeHandle?*/ handle, /*System.Security.AccessControl.AccessControlSections*/ includeSections, /*System.Security.AccessControl.NativeObjectSecurity.ExceptionFromErrorCode?*/ exceptionFromErrorCode, /*object?*/ exceptionContext)
            {
                super.$ctor$4(false);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4296933459);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296933459)
            
            //--TRIMMABLE-BOUNDARY-START(12886868051)
            $ctor$7(/*bool*/ isContainer, /*System.Security.AccessControl.ResourceType*/ resourceType, /*System.Security.AccessControl.NativeObjectSecurity.ExceptionFromErrorCode?*/ exceptionFromErrorCode, /*object?*/ exceptionContext)
            {
                super.$ctor$4(false);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(12886868051);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(12886868051)
            
            //--TRIMMABLE-BOUNDARY-START(21476802643)
            $ctor$9(/*bool*/ isContainer, /*System.Security.AccessControl.ResourceType*/ resourceType, /*string?*/ name, /*System.Security.AccessControl.AccessControlSections*/ includeSections)
            {
                super.$ctor$4(false);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(21476802643);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(21476802643)
            
            //--TRIMMABLE-BOUNDARY-START(17181835347)
            $ctor$8(/*bool*/ isContainer, /*System.Security.AccessControl.ResourceType*/ resourceType, /*string?*/ name, /*System.Security.AccessControl.AccessControlSections*/ includeSections, /*System.Security.AccessControl.NativeObjectSecurity.ExceptionFromErrorCode?*/ exceptionFromErrorCode, /*object?*/ exceptionContext)
            {
                super.$ctor$4(false);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(17181835347);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(17181835347)
            
            //--TRIMMABLE-BOUNDARY-START(34361704531)
            /*void */ Persist$1(/*System.Runtime.InteropServices.SafeHandle*/ handle, /*System.Security.AccessControl.AccessControlSections*/ includeSections)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(34361704531);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
            }
            //--TRIMMABLE-BOUNDARY-END(34361704531)
            
            //--TRIMMABLE-BOUNDARY-START(30066737235)
            /*void */ Persist$3(/*System.Runtime.InteropServices.SafeHandle*/ handle, /*System.Security.AccessControl.AccessControlSections*/ includeSections, /*object?*/ exceptionContext)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(30066737235);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
            }
            //--TRIMMABLE-BOUNDARY-END(30066737235)
            
            //--TRIMMABLE-BOUNDARY-START(42951639123)
            /*void */ Persist$2(/*string*/ name, /*System.Security.AccessControl.AccessControlSections*/ includeSections)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(42951639123);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
            }
            //--TRIMMABLE-BOUNDARY-END(42951639123)
            
            //--TRIMMABLE-BOUNDARY-START(38656671827)
            /*void */ Persist$4(/*string*/ name, /*System.Security.AccessControl.AccessControlSections*/ includeSections, /*object?*/ exceptionContext)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(38656671827);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
            }
            //--TRIMMABLE-BOUNDARY-END(38656671827)
            
            //--TRIMMABLE-BOUNDARY-START(2031699)
            static $_ExceptionFromErrorCode;
            static get ExceptionFromErrorCode()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(2031699);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                let $cls = $.$ssa.SSA.NativeObjectSecurity;
                return $cls.$_ExceptionFromErrorCode ??= $asm.$ncls(`$ssa.SSA.NativeObjectSecurity.ExceptionFromErrorCode`, ($self) => class ExceptionFromErrorCode extends $.$$.S.MulticastDelegate
                {
                    $ctor(/*object*/ target, fn, anmodel)
                    {
                        this.$target = target;
                        this.$nativeFunction = fn;
                        if (anmodel) this.$nfmodel = anmodel;
                        if (typeof(target) === 'object') this._target = target;
                        return this;
                    }
                    /*System.Exception?*/ Invoke(/*$.$$.S.Int32*/ errorCode, /*$.$$.S.Nullable$$*/ name, /*$.$$.S.Nullable$$*/ handle, /*$.$$.S.Nullable$$*/ context)
                    {
                        return this.$nativeFunction.call(this.$target, errorCode, name, handle, context);
                    }
                    static $h = 2031699;
                    static $f = 0b10000000010000000;
                    static $k = 5;
                    static $$b;
                    static get $b() { return this.$$b ??= $.$$.S.MulticastDelegate; }
                    static $$md;
                    static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(17181900883),
    {
      "r": 80805889,
      "p": [
        {
          "n": "errorCode",
          "p": 655361
        },
        {
          "n": "name",
          "p": 1310721
        },
        {
          "n": "handle",
          "p": 147849217
        },
        {
          "n": "context",
          "p": 131073
        }
      ],
      "n": "Invoke",
      "d": 2031699,
      "h": 17181900883,
      "f": 16777345
    },
//--TRIMMABLE-BOUNDARY-END(17181900883),
//--TRIMMABLE-BOUNDARY-START(8591966291),
    {
      "r": 90570753,
      "p": [
        {
          "n": "errorCode",
          "p": 655361
        },
        {
          "n": "name",
          "p": 1310721
        },
        {
          "n": "handle",
          "p": 147849217
        },
        {
          "n": "context",
          "p": 131073
        },
        {
          "n": "callback",
          "p": 46006273
        },
        {
          "n": "object",
          "p": 131073
        }
      ],
      "n": "BeginInvoke",
      "d": 2031699,
      "h": 8591966291,
      "f": 16777345
    },
//--TRIMMABLE-BOUNDARY-END(8591966291),
//--TRIMMABLE-BOUNDARY-START(12886933587),
    {
      "r": 80805889,
      "p": [
        {
          "n": "result",
          "p": 90570753
        }
      ],
      "n": "EndInvoke",
      "d": 2031699,
      "h": 12886933587,
      "f": 16777345
    },
//--TRIMMABLE-BOUNDARY-END(12886933587)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296998995),
    {
      "p": [
        {
          "n": "object",
          "p": 131073
        },
        {
          "n": "method",
          "p": 786433
        }
      ],
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 2031699,
      "h": 4296998995,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296998995)
  ],
  "d": 1966163,
  "h": 2031699
}; }
                    static $$i;
                    static get $i() { return this.$$i ??= [ $.$$.S.ICloneable, $.$$.SRS.ISerializable ]; }
                    static $$fullName;
                    static get $fullName() { return this.$$fullName ??= `System.Security.AccessControl.NativeObjectSecurity+ExceptionFromErrorCode`; }
                    static $$getFullName = {};
                    static $getFullName(separator) { return this.$$getFullName[separator] ??= `System${separator}Security${separator}AccessControl${separator}NativeObjectSecurity${separator}ExceptionFromErrorCode`; }
                }, $cls, ($v) => $cls.$_ExceptionFromErrorCode = $v);
            }
            //--TRIMMABLE-BOUNDARY-END(2031699)
            
            static $h = 1966163;
            static $f = 0b110001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$ssa.SSA.CommonObjectSecurity; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(34361704531),
    {
      "r": 65537,
      "p": [
        {
          "n": "handle",
          "p": 147849217
        },
        {
          "n": "includeSections",
          "p": 196691
        }
      ],
      "n": "Persist",
      "o": "@$1",
      "d": 1966163,
      "h": 34361704531,
      "f": 16875524
    },
//--TRIMMABLE-BOUNDARY-END(34361704531),
//--TRIMMABLE-BOUNDARY-START(30066737235),
    {
      "r": 65537,
      "p": [
        {
          "n": "handle",
          "p": 147849217
        },
        {
          "n": "includeSections",
          "p": 196691
        },
        {
          "n": "exceptionContext",
          "p": 131073
        }
      ],
      "n": "Persist",
      "o": "@$3",
      "d": 1966163,
      "h": 30066737235,
      "f": 16777220
    },
//--TRIMMABLE-BOUNDARY-END(30066737235),
//--TRIMMABLE-BOUNDARY-START(42951639123),
    {
      "r": 65537,
      "p": [
        {
          "n": "name",
          "p": 1310721
        },
        {
          "n": "includeSections",
          "p": 196691
        }
      ],
      "n": "Persist",
      "o": "@$2",
      "d": 1966163,
      "h": 42951639123,
      "f": 16875524
    },
//--TRIMMABLE-BOUNDARY-END(42951639123),
//--TRIMMABLE-BOUNDARY-START(38656671827),
    {
      "r": 65537,
      "p": [
        {
          "n": "name",
          "p": 1310721
        },
        {
          "n": "includeSections",
          "p": 196691
        },
        {
          "n": "exceptionContext",
          "p": 131073
        }
      ],
      "n": "Persist",
      "o": "@$4",
      "d": 1966163,
      "h": 38656671827,
      "f": 16777220
    },
//--TRIMMABLE-BOUNDARY-END(38656671827)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(25771769939),
    {
      "p": [
        {
          "n": "isContainer",
          "p": 262145
        },
        {
          "n": "resourceType",
          "p": 2818131
        }
      ],
      "n": ".ctor",
      "o": "$ctor$10",
      "d": 1966163,
      "h": 25771769939,
      "f": 16777220
    },
//--TRIMMABLE-BOUNDARY-END(25771769939),
//--TRIMMABLE-BOUNDARY-START(8591900755),
    {
      "p": [
        {
          "n": "isContainer",
          "p": 262145
        },
        {
          "n": "resourceType",
          "p": 2818131
        },
        {
          "n": "handle",
          "p": 147849217
        },
        {
          "n": "includeSections",
          "p": 196691
        }
      ],
      "n": ".ctor",
      "o": "$ctor$6",
      "d": 1966163,
      "h": 8591900755,
      "f": 16777220
    },
//--TRIMMABLE-BOUNDARY-END(8591900755),
//--TRIMMABLE-BOUNDARY-START(4296933459),
    {
      "p": [
        {
          "n": "isContainer",
          "p": 262145
        },
        {
          "n": "resourceType",
          "p": 2818131
        },
        {
          "n": "handle",
          "p": 147849217
        },
        {
          "n": "includeSections",
          "p": 196691
        },
        {
          "n": "exceptionFromErrorCode",
          "p": 2031699
        },
        {
          "n": "exceptionContext",
          "p": 131073
        }
      ],
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 1966163,
      "h": 4296933459,
      "f": 16777220
    },
//--TRIMMABLE-BOUNDARY-END(4296933459),
//--TRIMMABLE-BOUNDARY-START(12886868051),
    {
      "p": [
        {
          "n": "isContainer",
          "p": 262145
        },
        {
          "n": "resourceType",
          "p": 2818131
        },
        {
          "n": "exceptionFromErrorCode",
          "p": 2031699
        },
        {
          "n": "exceptionContext",
          "p": 131073
        }
      ],
      "n": ".ctor",
      "o": "$ctor$7",
      "d": 1966163,
      "h": 12886868051,
      "f": 16777220
    },
//--TRIMMABLE-BOUNDARY-END(12886868051),
//--TRIMMABLE-BOUNDARY-START(21476802643),
    {
      "p": [
        {
          "n": "isContainer",
          "p": 262145
        },
        {
          "n": "resourceType",
          "p": 2818131
        },
        {
          "n": "name",
          "p": 1310721
        },
        {
          "n": "includeSections",
          "p": 196691
        }
      ],
      "n": ".ctor",
      "o": "$ctor$9",
      "d": 1966163,
      "h": 21476802643,
      "f": 16777220
    },
//--TRIMMABLE-BOUNDARY-END(21476802643),
//--TRIMMABLE-BOUNDARY-START(17181835347),
    {
      "p": [
        {
          "n": "isContainer",
          "p": 262145
        },
        {
          "n": "resourceType",
          "p": 2818131
        },
        {
          "n": "name",
          "p": 1310721
        },
        {
          "n": "includeSections",
          "p": 196691
        },
        {
          "n": "exceptionFromErrorCode",
          "p": 2031699
        },
        {
          "n": "exceptionContext",
          "p": 131073
        }
      ],
      "n": ".ctor",
      "o": "$ctor$8",
      "d": 1966163,
      "h": 17181835347,
      "f": 16777220
    },
//--TRIMMABLE-BOUNDARY-END(17181835347)
  ],
  "h": 1966163
}; }
            static $$n;
            static get $n() { return this.$$n ??= [ $.$ssa.SSA.NativeObjectSecurity.ExceptionFromErrorCode ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `System.Security.AccessControl.NativeObjectSecurity`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `System${separator}Security${separator}AccessControl${separator}NativeObjectSecurity`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1966163)
        
        

        //--TRIMMABLE-BOUNDARY-START(2097235)
        $asm.$cls(`$ssa.SSA.ObjectAccessRule`, ($self) => class ObjectAccessRule extends $.$ssa.SSA.AccessRule
        {
            //--TRIMMABLE-BOUNDARY-START(4297064531)
            $ctor$3(/*System.Security.Principal.IdentityReference*/ identity, /*int*/ accessMask, /*bool*/ isInherited, /*System.Security.AccessControl.InheritanceFlags*/ inheritanceFlags, /*System.Security.AccessControl.PropagationFlags*/ propagationFlags, /*System.Guid*/ objectType, /*System.Guid*/ inheritedObjectType, /*System.Security.AccessControl.AccessControlType*/ type)
            {
                super.$ctor$2(null, 0, false, 0, 0, 0);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4297064531);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4297064531)
            
            //--TRIMMABLE-BOUNDARY-START(34361835603)
            /*System.Guid */ get InheritedObjectType()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12886999123);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(34361835603)
            
            //--TRIMMABLE-BOUNDARY-START(38656802899)
            /*System.Security.AccessControl.ObjectAceFlags */ get ObjectFlags()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21476933715);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(38656802899)
            
            //--TRIMMABLE-BOUNDARY-START(42951770195)
            /*System.Guid */ get ObjectType()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(30066868307);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(42951770195)
            
            static $h = 2097235;
            static $f = 0b110001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$ssa.SSA.AccessRule; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(34361835603),
    {
      "p": 89784321,
      "g": {
        "r": 0,
        "d": 0,
        "h": 12886999123,
        "f": 50331649
      },
      "n": "InheritedObjectType",
      "d": 2097235,
      "h": 34361835603,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(34361835603),
//--TRIMMABLE-BOUNDARY-START(38656802899),
    {
      "p": 2228307,
      "g": {
        "r": 0,
        "d": 0,
        "h": 21476933715,
        "f": 50331649
      },
      "n": "ObjectFlags",
      "d": 2097235,
      "h": 38656802899,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(38656802899),
//--TRIMMABLE-BOUNDARY-START(42951770195),
    {
      "p": 89784321,
      "g": {
        "r": 0,
        "d": 0,
        "h": 30066868307,
        "f": 50331649
      },
      "n": "ObjectType",
      "d": 2097235,
      "h": 42951770195,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(42951770195)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4297064531),
    {
      "p": [
        {
          "n": "identity",
          "p": 196678
        },
        {
          "n": "accessMask",
          "p": 655361
        },
        {
          "n": "isInherited",
          "p": 262145
        },
        {
          "n": "inheritanceFlags",
          "p": 1835091
        },
        {
          "n": "propagationFlags",
          "p": 2555987
        },
        {
          "n": "objectType",
          "p": 89784321
        },
        {
          "n": "inheritedObjectType",
          "p": 89784321
        },
        {
          "n": "type",
          "p": 262227
        }
      ],
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 2097235,
      "h": 4297064531,
      "f": 16777220
    },
//--TRIMMABLE-BOUNDARY-END(4297064531)
  ],
  "h": 2097235
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `System.Security.AccessControl.ObjectAccessRule`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `System${separator}Security${separator}AccessControl${separator}ObjectAccessRule`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2097235)
        
        

        //--TRIMMABLE-BOUNDARY-START(2293843)
        $asm.$cls(`$ssa.SSA.ObjectAuditRule`, ($self) => class ObjectAuditRule extends $.$ssa.SSA.AuditRule
        {
            //--TRIMMABLE-BOUNDARY-START(4297261139)
            $ctor$3(/*System.Security.Principal.IdentityReference*/ identity, /*int*/ accessMask, /*bool*/ isInherited, /*System.Security.AccessControl.InheritanceFlags*/ inheritanceFlags, /*System.Security.AccessControl.PropagationFlags*/ propagationFlags, /*System.Guid*/ objectType, /*System.Guid*/ inheritedObjectType, /*System.Security.AccessControl.AuditFlags*/ auditFlags)
            {
                super.$ctor$2(null, 0, false, 0, 0, 0);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4297261139);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4297261139)
            
            //--TRIMMABLE-BOUNDARY-START(34362032211)
            /*System.Guid */ get InheritedObjectType()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12887195731);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(34362032211)
            
            //--TRIMMABLE-BOUNDARY-START(38656999507)
            /*System.Security.AccessControl.ObjectAceFlags */ get ObjectFlags()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21477130323);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(38656999507)
            
            //--TRIMMABLE-BOUNDARY-START(42951966803)
            /*System.Guid */ get ObjectType()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(30067064915);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(42951966803)
            
            static $h = 2293843;
            static $f = 0b110001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$ssa.SSA.AuditRule; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(34362032211),
    {
      "p": 89784321,
      "g": {
        "r": 0,
        "d": 0,
        "h": 12887195731,
        "f": 50331649
      },
      "n": "InheritedObjectType",
      "d": 2293843,
      "h": 34362032211,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(34362032211),
//--TRIMMABLE-BOUNDARY-START(38656999507),
    {
      "p": 2228307,
      "g": {
        "r": 0,
        "d": 0,
        "h": 21477130323,
        "f": 50331649
      },
      "n": "ObjectFlags",
      "d": 2293843,
      "h": 38656999507,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(38656999507),
//--TRIMMABLE-BOUNDARY-START(42951966803),
    {
      "p": 89784321,
      "g": {
        "r": 0,
        "d": 0,
        "h": 30067064915,
        "f": 50331649
      },
      "n": "ObjectType",
      "d": 2293843,
      "h": 42951966803,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(42951966803)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4297261139),
    {
      "p": [
        {
          "n": "identity",
          "p": 196678
        },
        {
          "n": "accessMask",
          "p": 655361
        },
        {
          "n": "isInherited",
          "p": 262145
        },
        {
          "n": "inheritanceFlags",
          "p": 1835091
        },
        {
          "n": "propagationFlags",
          "p": 2555987
        },
        {
          "n": "objectType",
          "p": 89784321
        },
        {
          "n": "inheritedObjectType",
          "p": 89784321
        },
        {
          "n": "auditFlags",
          "p": 720979
        }
      ],
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 2293843,
      "h": 4297261139,
      "f": 16777220
    },
//--TRIMMABLE-BOUNDARY-END(4297261139)
  ],
  "h": 2293843
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `System.Security.AccessControl.ObjectAuditRule`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `System${separator}Security${separator}AccessControl${separator}ObjectAuditRule`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2293843)
        
        

        //--TRIMMABLE-BOUNDARY-START(2621523)
        $asm.$cls(`$ssa.SSA.QualifiedAce`, ($self) => class QualifiedAce extends $.$ssa.SSA.KnownAce
        {
            //--TRIMMABLE-BOUNDARY-START(4297588819)
            $ctor$3()
            {
                super.$ctor$2();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4297588819);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4297588819)
            
            //--TRIMMABLE-BOUNDARY-START(8592556115)
            /*System.Security.AccessControl.AceQualifier */ get AceQualifier()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17182490707);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(8592556115)
            
            //--TRIMMABLE-BOUNDARY-START(42952294483)
            /*bool */ get IsCallback()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25772425299);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(42952294483)
            
            //--TRIMMABLE-BOUNDARY-START(47247261779)
            /*int */ get OpaqueLength()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(34362359891);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(47247261779)
            
            //--TRIMMABLE-BOUNDARY-START(38657327187)
            /*byte[]? */ GetOpaque()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(38657327187);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(38657327187)
            
            //--TRIMMABLE-BOUNDARY-START(51542229075)
            /*void */ SetOpaque(/*byte[]?*/ opaque)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(51542229075);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
            }
            //--TRIMMABLE-BOUNDARY-END(51542229075)
            
            //--TRIMMABLE-BOUNDARY-START(4297588819)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$3();
            }
            //--TRIMMABLE-BOUNDARY-END(4297588819)
            
            static $h = 2621523;
            static $f = 0b110001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$ssa.SSA.KnownAce; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(8592556115),
    {
      "p": 589907,
      "g": {
        "r": 0,
        "d": 0,
        "h": 17182490707,
        "f": 50331649
      },
      "n": "AceQualifier",
      "d": 2621523,
      "h": 8592556115,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(8592556115),
//--TRIMMABLE-BOUNDARY-START(42952294483),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 25772425299,
        "f": 50331649
      },
      "n": "IsCallback",
      "d": 2621523,
      "h": 42952294483,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(42952294483),
//--TRIMMABLE-BOUNDARY-START(47247261779),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 34362359891,
        "f": 50331649
      },
      "n": "OpaqueLength",
      "d": 2621523,
      "h": 47247261779,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(47247261779)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(38657327187),
    {
      "r": $.$typeArray($.$$.S.Byte).$h,
      "n": "GetOpaque",
      "d": 2621523,
      "h": 38657327187,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(38657327187),
//--TRIMMABLE-BOUNDARY-START(51542229075),
    {
      "r": 65537,
      "p": [
        {
          "n": "opaque",
          "p": $.$typeArray($.$$.S.Byte).$h
        }
      ],
      "n": "SetOpaque",
      "d": 2621523,
      "h": 51542229075,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(51542229075)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4297588819),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 2621523,
      "h": 4297588819,
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(4297588819)
  ],
  "h": 2621523
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `System.Security.AccessControl.QualifiedAce`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `System${separator}Security${separator}AccessControl${separator}QualifiedAce`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2621523)
        
        

        //--TRIMMABLE-BOUNDARY-START(2424915)
        $asm.$cls(`$ssa.SSA.ObjectSecurity<>`, (T) => $asm.$gt(`$ssa.SSA.ObjectSecurity<>`, [T], ($self) => class ObjectSecurity$$ extends $.$ssa.SSA.NativeObjectSecurity
        {
            //--TRIMMABLE-BOUNDARY-START(21477261395)
            $ctor$15(/*bool*/ isContainer, /*System.Security.AccessControl.ResourceType*/ resourceType)
            {
                super.$ctor$10(false, 0);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(21477261395);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(21477261395)
            
            //--TRIMMABLE-BOUNDARY-START(8592359507)
            $ctor$12(/*bool*/ isContainer, /*System.Security.AccessControl.ResourceType*/ resourceType, /*System.Runtime.InteropServices.SafeHandle?*/ safeHandle, /*System.Security.AccessControl.AccessControlSections*/ includeSections)
            {
                super.$ctor$10(false, 0);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(8592359507);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(8592359507)
            
            //--TRIMMABLE-BOUNDARY-START(4297392211)
            $ctor$11(/*bool*/ isContainer, /*System.Security.AccessControl.ResourceType*/ resourceType, /*System.Runtime.InteropServices.SafeHandle?*/ safeHandle, /*System.Security.AccessControl.AccessControlSections*/ includeSections, /*System.Security.AccessControl.NativeObjectSecurity.ExceptionFromErrorCode?*/ exceptionFromErrorCode, /*object?*/ exceptionContext)
            {
                super.$ctor$10(false, 0);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4297392211);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4297392211)
            
            //--TRIMMABLE-BOUNDARY-START(17182294099)
            $ctor$14(/*bool*/ isContainer, /*System.Security.AccessControl.ResourceType*/ resourceType, /*string?*/ name, /*System.Security.AccessControl.AccessControlSections*/ includeSections)
            {
                super.$ctor$10(false, 0);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(17182294099);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(17182294099)
            
            //--TRIMMABLE-BOUNDARY-START(12887326803)
            $ctor$13(/*bool*/ isContainer, /*System.Security.AccessControl.ResourceType*/ resourceType, /*string?*/ name, /*System.Security.AccessControl.AccessControlSections*/ includeSections, /*System.Security.AccessControl.NativeObjectSecurity.ExceptionFromErrorCode?*/ exceptionFromErrorCode, /*object?*/ exceptionContext)
            {
                super.$ctor$10(false, 0);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(12887326803);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(12887326803)
            
            //--TRIMMABLE-BOUNDARY-START(25772228691)
            /*System.Type */ get AccessRightType()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(60131967059);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(25772228691)
            
            //--TRIMMABLE-BOUNDARY-START(34362163283)
            /*System.Type */ get AccessRuleType()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(68721901651);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(34362163283)
            
            //--TRIMMABLE-BOUNDARY-START(51542032467)
            /*System.Type */ get AuditRuleType()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(77311836243);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(51542032467)
            
            //--TRIMMABLE-BOUNDARY-START(30067195987)
            /*System.Security.AccessControl.AccessRule */ AccessRuleFactory(/*System.Security.Principal.IdentityReference*/ identityReference, /*int*/ accessMask, /*bool*/ isInherited, /*System.Security.AccessControl.InheritanceFlags*/ inheritanceFlags, /*System.Security.AccessControl.PropagationFlags*/ propagationFlags, /*System.Security.AccessControl.AccessControlType*/ type)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(30067195987);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(30067195987)
            
            //--TRIMMABLE-BOUNDARY-START(38657130579)
            /*void */ AddAccessRule$1(/*System.Security.AccessControl.AccessRule<T>*/ rule)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(38657130579);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
            }
            //--TRIMMABLE-BOUNDARY-END(38657130579)
            
            //--TRIMMABLE-BOUNDARY-START(42952097875)
            /*void */ AddAuditRule$1(/*System.Security.AccessControl.AuditRule<T>*/ rule)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(42952097875);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
            }
            //--TRIMMABLE-BOUNDARY-END(42952097875)
            
            //--TRIMMABLE-BOUNDARY-START(47247065171)
            /*System.Security.AccessControl.AuditRule */ AuditRuleFactory(/*System.Security.Principal.IdentityReference*/ identityReference, /*int*/ accessMask, /*bool*/ isInherited, /*System.Security.AccessControl.InheritanceFlags*/ inheritanceFlags, /*System.Security.AccessControl.PropagationFlags*/ propagationFlags, /*System.Security.AccessControl.AuditFlags*/ flags)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(47247065171);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(47247065171)
            
            //--TRIMMABLE-BOUNDARY-START(81606803539)
            /*void */ Persist$5(/*System.Runtime.InteropServices.SafeHandle*/ handle)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(81606803539);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
            }
            //--TRIMMABLE-BOUNDARY-END(81606803539)
            
            //--TRIMMABLE-BOUNDARY-START(85901770835)
            /*void */ Persist$6(/*string*/ name)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(85901770835);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
            }
            //--TRIMMABLE-BOUNDARY-END(85901770835)
            
            //--TRIMMABLE-BOUNDARY-START(90196738131)
            /*bool */ RemoveAccessRule$1(/*System.Security.AccessControl.AccessRule<T>*/ rule)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(90196738131);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(90196738131)
            
            //--TRIMMABLE-BOUNDARY-START(94491705427)
            /*void */ RemoveAccessRuleAll$1(/*System.Security.AccessControl.AccessRule<T>*/ rule)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(94491705427);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
            }
            //--TRIMMABLE-BOUNDARY-END(94491705427)
            
            //--TRIMMABLE-BOUNDARY-START(98786672723)
            /*void */ RemoveAccessRuleSpecific$1(/*System.Security.AccessControl.AccessRule<T>*/ rule)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(98786672723);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
            }
            //--TRIMMABLE-BOUNDARY-END(98786672723)
            
            //--TRIMMABLE-BOUNDARY-START(103081640019)
            /*bool */ RemoveAuditRule$1(/*System.Security.AccessControl.AuditRule<T>*/ rule)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(103081640019);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(103081640019)
            
            //--TRIMMABLE-BOUNDARY-START(107376607315)
            /*void */ RemoveAuditRuleAll$1(/*System.Security.AccessControl.AuditRule<T>*/ rule)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(107376607315);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
            }
            //--TRIMMABLE-BOUNDARY-END(107376607315)
            
            //--TRIMMABLE-BOUNDARY-START(111671574611)
            /*void */ RemoveAuditRuleSpecific$1(/*System.Security.AccessControl.AuditRule<T>*/ rule)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(111671574611);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
            }
            //--TRIMMABLE-BOUNDARY-END(111671574611)
            
            //--TRIMMABLE-BOUNDARY-START(115966541907)
            /*void */ ResetAccessRule$1(/*System.Security.AccessControl.AccessRule<T>*/ rule)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(115966541907);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
            }
            //--TRIMMABLE-BOUNDARY-END(115966541907)
            
            //--TRIMMABLE-BOUNDARY-START(120261509203)
            /*void */ SetAccessRule$1(/*System.Security.AccessControl.AccessRule<T>*/ rule)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(120261509203);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
            }
            //--TRIMMABLE-BOUNDARY-END(120261509203)
            
            //--TRIMMABLE-BOUNDARY-START(124556476499)
            /*void */ SetAuditRule$1(/*System.Security.AccessControl.AuditRule<T>*/ rule)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(124556476499);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
            }
            //--TRIMMABLE-BOUNDARY-END(124556476499)
            
            static $H = 2424915;
            static $h = 2424915;
            static $g = 1;
            static $f = 0b1110001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$ssa.SSA.NativeObjectSecurity; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(25772228691),
    {
      "p": 188547073,
      "g": {
        "r": 0,
        "d": 0,
        "H": 60131967059,
        "h": Number(BigInt(this.$h)|0xE00000000n),
        "f": 50364417
      },
      "n": "AccessRightType",
      "d": this.$h,
      "H": 25772228691,
      "h": Number(BigInt(this.$h)|0x600000000n),
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(25772228691),
//--TRIMMABLE-BOUNDARY-START(34362163283),
    {
      "p": 188547073,
      "g": {
        "r": 0,
        "d": 0,
        "H": 68721901651,
        "h": Number(BigInt(this.$h)|0x1000000000n),
        "f": 50364417
      },
      "n": "AccessRuleType",
      "d": this.$h,
      "H": 34362163283,
      "h": Number(BigInt(this.$h)|0x800000000n),
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(34362163283),
//--TRIMMABLE-BOUNDARY-START(51542032467),
    {
      "p": 188547073,
      "g": {
        "r": 0,
        "d": 0,
        "H": 77311836243,
        "h": Number(BigInt(this.$h)|0x1200000000n),
        "f": 50364417
      },
      "n": "AuditRuleType",
      "d": this.$h,
      "H": 51542032467,
      "h": Number(BigInt(this.$h)|0xC00000000n),
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(51542032467)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(30067195987),
    {
      "r": 327763,
      "p": [
        {
          "n": "identityReference",
          "p": 196678
        },
        {
          "n": "accessMask",
          "p": 655361
        },
        {
          "n": "isInherited",
          "p": 262145
        },
        {
          "n": "inheritanceFlags",
          "p": 1835091
        },
        {
          "n": "propagationFlags",
          "p": 2555987
        },
        {
          "n": "type",
          "p": 262227
        }
      ],
      "n": "AccessRuleFactory",
      "d": this.$h,
      "H": 30067195987,
      "h": Number(BigInt(this.$h)|0x700000000n),
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(30067195987),
//--TRIMMABLE-BOUNDARY-START(38657130579),
    {
      "r": 65537,
      "p": [
        {
          "n": "rule",
          "p": $.$ssa.SSA.AccessRule$$(T).$h
        }
      ],
      "n": "AddAccessRule",
      "o": "@$1",
      "d": this.$h,
      "H": 38657130579,
      "h": Number(BigInt(this.$h)|0x900000000n),
      "f": 16777345
    },
//--TRIMMABLE-BOUNDARY-END(38657130579),
//--TRIMMABLE-BOUNDARY-START(42952097875),
    {
      "r": 65537,
      "p": [
        {
          "n": "rule",
          "p": $.$ssa.SSA.AuditRule$$(T).$h
        }
      ],
      "n": "AddAuditRule",
      "o": "@$1",
      "d": this.$h,
      "H": 42952097875,
      "h": Number(BigInt(this.$h)|0xA00000000n),
      "f": 16777345
    },
//--TRIMMABLE-BOUNDARY-END(42952097875),
//--TRIMMABLE-BOUNDARY-START(47247065171),
    {
      "r": 786515,
      "p": [
        {
          "n": "identityReference",
          "p": 196678
        },
        {
          "n": "accessMask",
          "p": 655361
        },
        {
          "n": "isInherited",
          "p": 262145
        },
        {
          "n": "inheritanceFlags",
          "p": 1835091
        },
        {
          "n": "propagationFlags",
          "p": 2555987
        },
        {
          "n": "flags",
          "p": 720979
        }
      ],
      "n": "AuditRuleFactory",
      "d": this.$h,
      "H": 47247065171,
      "h": Number(BigInt(this.$h)|0xB00000000n),
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(47247065171),
//--TRIMMABLE-BOUNDARY-START(81606803539),
    {
      "r": 65537,
      "p": [
        {
          "n": "handle",
          "p": 147849217
        }
      ],
      "n": "Persist",
      "o": "@$5",
      "d": this.$h,
      "H": 81606803539,
      "h": Number(BigInt(this.$h)|0x1300000000n),
      "f": 16777232
    },
//--TRIMMABLE-BOUNDARY-END(81606803539),
//--TRIMMABLE-BOUNDARY-START(85901770835),
    {
      "r": 65537,
      "p": [
        {
          "n": "name",
          "p": 1310721
        }
      ],
      "n": "Persist",
      "o": "@$6",
      "d": this.$h,
      "H": 85901770835,
      "h": Number(BigInt(this.$h)|0x1400000000n),
      "f": 16777232
    },
//--TRIMMABLE-BOUNDARY-END(85901770835),
//--TRIMMABLE-BOUNDARY-START(90196738131),
    {
      "r": 262145,
      "p": [
        {
          "n": "rule",
          "p": $.$ssa.SSA.AccessRule$$(T).$h
        }
      ],
      "n": "RemoveAccessRule",
      "o": "@$1",
      "d": this.$h,
      "H": 90196738131,
      "h": Number(BigInt(this.$h)|0x1500000000n),
      "f": 16777345
    },
//--TRIMMABLE-BOUNDARY-END(90196738131),
//--TRIMMABLE-BOUNDARY-START(94491705427),
    {
      "r": 65537,
      "p": [
        {
          "n": "rule",
          "p": $.$ssa.SSA.AccessRule$$(T).$h
        }
      ],
      "n": "RemoveAccessRuleAll",
      "o": "@$1",
      "d": this.$h,
      "H": 94491705427,
      "h": Number(BigInt(this.$h)|0x1600000000n),
      "f": 16777345
    },
//--TRIMMABLE-BOUNDARY-END(94491705427),
//--TRIMMABLE-BOUNDARY-START(98786672723),
    {
      "r": 65537,
      "p": [
        {
          "n": "rule",
          "p": $.$ssa.SSA.AccessRule$$(T).$h
        }
      ],
      "n": "RemoveAccessRuleSpecific",
      "o": "@$1",
      "d": this.$h,
      "H": 98786672723,
      "h": Number(BigInt(this.$h)|0x1700000000n),
      "f": 16777345
    },
//--TRIMMABLE-BOUNDARY-END(98786672723),
//--TRIMMABLE-BOUNDARY-START(103081640019),
    {
      "r": 262145,
      "p": [
        {
          "n": "rule",
          "p": $.$ssa.SSA.AuditRule$$(T).$h
        }
      ],
      "n": "RemoveAuditRule",
      "o": "@$1",
      "d": this.$h,
      "H": 103081640019,
      "h": Number(BigInt(this.$h)|0x1800000000n),
      "f": 16777345
    },
//--TRIMMABLE-BOUNDARY-END(103081640019),
//--TRIMMABLE-BOUNDARY-START(107376607315),
    {
      "r": 65537,
      "p": [
        {
          "n": "rule",
          "p": $.$ssa.SSA.AuditRule$$(T).$h
        }
      ],
      "n": "RemoveAuditRuleAll",
      "o": "@$1",
      "d": this.$h,
      "H": 107376607315,
      "h": Number(BigInt(this.$h)|0x1900000000n),
      "f": 16777345
    },
//--TRIMMABLE-BOUNDARY-END(107376607315),
//--TRIMMABLE-BOUNDARY-START(111671574611),
    {
      "r": 65537,
      "p": [
        {
          "n": "rule",
          "p": $.$ssa.SSA.AuditRule$$(T).$h
        }
      ],
      "n": "RemoveAuditRuleSpecific",
      "o": "@$1",
      "d": this.$h,
      "H": 111671574611,
      "h": Number(BigInt(this.$h)|0x1A00000000n),
      "f": 16777345
    },
//--TRIMMABLE-BOUNDARY-END(111671574611),
//--TRIMMABLE-BOUNDARY-START(115966541907),
    {
      "r": 65537,
      "p": [
        {
          "n": "rule",
          "p": $.$ssa.SSA.AccessRule$$(T).$h
        }
      ],
      "n": "ResetAccessRule",
      "o": "@$1",
      "d": this.$h,
      "H": 115966541907,
      "h": Number(BigInt(this.$h)|0x1B00000000n),
      "f": 16777345
    },
//--TRIMMABLE-BOUNDARY-END(115966541907),
//--TRIMMABLE-BOUNDARY-START(120261509203),
    {
      "r": 65537,
      "p": [
        {
          "n": "rule",
          "p": $.$ssa.SSA.AccessRule$$(T).$h
        }
      ],
      "n": "SetAccessRule",
      "o": "@$1",
      "d": this.$h,
      "H": 120261509203,
      "h": Number(BigInt(this.$h)|0x1C00000000n),
      "f": 16777345
    },
//--TRIMMABLE-BOUNDARY-END(120261509203),
//--TRIMMABLE-BOUNDARY-START(124556476499),
    {
      "r": 65537,
      "p": [
        {
          "n": "rule",
          "p": $.$ssa.SSA.AuditRule$$(T).$h
        }
      ],
      "n": "SetAuditRule",
      "o": "@$1",
      "d": this.$h,
      "H": 124556476499,
      "h": Number(BigInt(this.$h)|0x1D00000000n),
      "f": 16777345
    },
//--TRIMMABLE-BOUNDARY-END(124556476499)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(21477261395),
    {
      "p": [
        {
          "n": "isContainer",
          "p": 262145
        },
        {
          "n": "resourceType",
          "p": 2818131
        }
      ],
      "n": ".ctor",
      "o": "$ctor$15",
      "d": this.$h,
      "H": 21477261395,
      "h": Number(BigInt(this.$h)|0x500000000n),
      "f": 16777220
    },
//--TRIMMABLE-BOUNDARY-END(21477261395),
//--TRIMMABLE-BOUNDARY-START(8592359507),
    {
      "p": [
        {
          "n": "isContainer",
          "p": 262145
        },
        {
          "n": "resourceType",
          "p": 2818131
        },
        {
          "n": "safeHandle",
          "p": 147849217
        },
        {
          "n": "includeSections",
          "p": 196691
        }
      ],
      "n": ".ctor",
      "o": "$ctor$12",
      "d": this.$h,
      "H": 8592359507,
      "h": Number(BigInt(this.$h)|0x200000000n),
      "f": 16777220
    },
//--TRIMMABLE-BOUNDARY-END(8592359507),
//--TRIMMABLE-BOUNDARY-START(4297392211),
    {
      "p": [
        {
          "n": "isContainer",
          "p": 262145
        },
        {
          "n": "resourceType",
          "p": 2818131
        },
        {
          "n": "safeHandle",
          "p": 147849217
        },
        {
          "n": "includeSections",
          "p": 196691
        },
        {
          "n": "exceptionFromErrorCode",
          "p": 2031699
        },
        {
          "n": "exceptionContext",
          "p": 131073
        }
      ],
      "n": ".ctor",
      "o": "$ctor$11",
      "d": this.$h,
      "H": 4297392211,
      "h": Number(BigInt(this.$h)|0x100000000n),
      "f": 16777220
    },
//--TRIMMABLE-BOUNDARY-END(4297392211),
//--TRIMMABLE-BOUNDARY-START(17182294099),
    {
      "p": [
        {
          "n": "isContainer",
          "p": 262145
        },
        {
          "n": "resourceType",
          "p": 2818131
        },
        {
          "n": "name",
          "p": 1310721
        },
        {
          "n": "includeSections",
          "p": 196691
        }
      ],
      "n": ".ctor",
      "o": "$ctor$14",
      "d": this.$h,
      "H": 17182294099,
      "h": Number(BigInt(this.$h)|0x400000000n),
      "f": 16777220
    },
//--TRIMMABLE-BOUNDARY-END(17182294099),
//--TRIMMABLE-BOUNDARY-START(12887326803),
    {
      "p": [
        {
          "n": "isContainer",
          "p": 262145
        },
        {
          "n": "resourceType",
          "p": 2818131
        },
        {
          "n": "name",
          "p": 1310721
        },
        {
          "n": "includeSections",
          "p": 196691
        },
        {
          "n": "exceptionFromErrorCode",
          "p": 2031699
        },
        {
          "n": "exceptionContext",
          "p": 131073
        }
      ],
      "n": ".ctor",
      "o": "$ctor$13",
      "d": this.$h,
      "H": 12887326803,
      "h": Number(BigInt(this.$h)|0x300000000n),
      "f": 16777220
    },
//--TRIMMABLE-BOUNDARY-END(12887326803)
  ],
  "s": [
    {
      "h": T?.$h??1572864,
      "n": "T",
      "f": 2
    }
  ],
  "r": 1,
  "H": 2424915,
  "h": this.$h
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `System.Security.AccessControl.ObjectSecurity<${T?.$fullName}>`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `System${separator}Security${separator}AccessControl${separator}ObjectSecurity$${T?.$getFullName(separator)}$`; }
        }));
        //--TRIMMABLE-BOUNDARY-END(2424915)
        
        

        //--TRIMMABLE-BOUNDARY-START(458835)
        $asm.$cls(`$ssa.SSA.AceEnumerator`, ($self) => class AceEnumerator extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(4295426131)
            $ctor$1()
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4295426131);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295426131)
            
            //--TRIMMABLE-BOUNDARY-START(8590393427)
            /*System.Security.AccessControl.GenericAce */ get Current()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17180328019);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(8590393427)
            
            //--TRIMMABLE-BOUNDARY-START(30065229907)
            /*object */ get SC$1$IEnumerator$Current()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(38655164499);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(30065229907)
            
            //--TRIMMABLE-BOUNDARY-START(21475295315)
            /*bool */ MoveNext()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21475295315);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(21475295315)
            
            //--TRIMMABLE-BOUNDARY-START(25770262611)
            /*void */ Reset()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25770262611);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
            }
            //--TRIMMABLE-BOUNDARY-END(25770262611)
            
            //--TRIMMABLE-BOUNDARY-START(17243373569)
            //Generated interface implemetation for System.Collections.IEnumerator.MoveNext()
            SC$1$IEnumerator$MoveNext()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17243373569);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.MoveNext(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(17243373569)
            
            //--TRIMMABLE-BOUNDARY-START(21538340865)
            //Generated interface implemetation for System.Collections.IEnumerator.Reset()
            SC$1$IEnumerator$Reset()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21538340865);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Reset(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(21538340865)
            
            //--TRIMMABLE-BOUNDARY-START(4295426131)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4295426131)
            
            static $h = 458835;
            static $f = 0b10010001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(8590393427),
    {
      "p": 1638483,
      "g": {
        "r": 0,
        "d": 0,
        "h": 17180328019,
        "f": 50331649
      },
      "n": "Current",
      "d": 458835,
      "h": 8590393427,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(8590393427),
//--TRIMMABLE-BOUNDARY-START(30065229907),
    {
      "p": 131073,
      "g": {
        "r": 0,
        "d": 0,
        "h": 38655164499,
        "f": 50331650
      },
      "n": "{63504385}.Current",
      "o": "SC$1$IEnumerator$Current",
      "d": 458835,
      "h": 30065229907,
      "f": 2097154
    },
//--TRIMMABLE-BOUNDARY-END(30065229907)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(21475295315),
    {
      "r": 262145,
      "n": "MoveNext",
      "d": 458835,
      "h": 21475295315,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(21475295315),
//--TRIMMABLE-BOUNDARY-START(25770262611),
    {
      "r": 65537,
      "n": "Reset",
      "d": 458835,
      "h": 25770262611,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(25770262611)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295426131),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 458835,
      "h": 4295426131,
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(4295426131)
  ],
  "h": 458835
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.SC$1.IEnumerator ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `System.Security.AccessControl.AceEnumerator`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `System${separator}Security${separator}AccessControl${separator}AceEnumerator`; }
        });
        //--TRIMMABLE-BOUNDARY-END(458835)
        
        

        //--TRIMMABLE-BOUNDARY-START(3014739)
        $asm.$cls(`$ssa.SSP.Evidence`, ($self) => class Evidence extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(4297982035)
            $ctor$1()
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4297982035);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4297982035)
            
            //--TRIMMABLE-BOUNDARY-START(8592949331)
            $ctor$2(/*object[]*/ hostEvidence, /*object[]*/ assemblyEvidence)
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(8592949331);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(8592949331)
            
            //--TRIMMABLE-BOUNDARY-START(17182883923)
            $ctor$4(/*System.Security.Policy.Evidence*/ evidence)
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(17182883923);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(17182883923)
            
            //--TRIMMABLE-BOUNDARY-START(12887916627)
            $ctor$3(/*System.Security.Policy.EvidenceBase[]*/ hostEvidence, /*System.Security.Policy.EvidenceBase[]*/ assemblyEvidence)
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(12887916627);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(12887916627)
            
            //--TRIMMABLE-BOUNDARY-START(51542622291)
            /*int */ get Count()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(60132556883);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(51542622291)
            
            //--TRIMMABLE-BOUNDARY-START(120262099027)
            /*bool */ get IsReadOnly()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(68722491475);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(120262099027)
            
            //--TRIMMABLE-BOUNDARY-START(124557066323)
            /*bool */ get IsSynchronized()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(77312426067);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(124557066323)
            
            //--TRIMMABLE-BOUNDARY-START(128852033619)
            /*bool */ get Locked()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(85902360659);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ set Locked(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(146031902803);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(128852033619)
            
            //--TRIMMABLE-BOUNDARY-START(150326870099)
            /*object */ get SyncRoot()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(94492295251);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(150326870099)
            
            //--TRIMMABLE-BOUNDARY-START(21477851219)
            /*void */ AddAssembly(/*object*/ id)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21477851219);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
            }
            //--TRIMMABLE-BOUNDARY-END(21477851219)
            
            //--TRIMMABLE-BOUNDARY-START(25772818515)
            /*void */ AddAssemblyEvidence(T, /*T*/ evidence)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25772818515);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
            }
            //--TRIMMABLE-BOUNDARY-END(25772818515)
            
            //--TRIMMABLE-BOUNDARY-START(30067785811)
            /*void */ AddHost(/*object*/ id)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(30067785811);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
            }
            //--TRIMMABLE-BOUNDARY-END(30067785811)
            
            //--TRIMMABLE-BOUNDARY-START(34362753107)
            /*void */ AddHostEvidence(T, /*T*/ evidence)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(34362753107);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
            }
            //--TRIMMABLE-BOUNDARY-END(34362753107)
            
            //--TRIMMABLE-BOUNDARY-START(38657720403)
            /*void */ Clear()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(38657720403);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
            }
            //--TRIMMABLE-BOUNDARY-END(38657720403)
            
            //--TRIMMABLE-BOUNDARY-START(42952687699)
            /*System.Security.Policy.Evidence? */ Clone()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(42952687699);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(42952687699)
            
            //--TRIMMABLE-BOUNDARY-START(47247654995)
            /*void */ CopyTo(/*System.Array*/ array, /*int*/ index)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(47247654995);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
            }
            //--TRIMMABLE-BOUNDARY-END(47247654995)
            
            //--TRIMMABLE-BOUNDARY-START(98787262547)
            /*System.Collections.IEnumerator */ GetAssemblyEnumerator()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(98787262547);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(98787262547)
            
            //--TRIMMABLE-BOUNDARY-START(103082229843)
            /*T? */ GetAssemblyEvidence(T)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(103082229843);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(103082229843)
            
            //--TRIMMABLE-BOUNDARY-START(107377197139)
            /*System.Collections.IEnumerator */ GetEnumerator()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(107377197139);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(107377197139)
            
            //--TRIMMABLE-BOUNDARY-START(111672164435)
            /*System.Collections.IEnumerator */ GetHostEnumerator()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(111672164435);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(111672164435)
            
            //--TRIMMABLE-BOUNDARY-START(115967131731)
            /*T? */ GetHostEvidence(T)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(115967131731);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(115967131731)
            
            //--TRIMMABLE-BOUNDARY-START(133147000915)
            /*void */ Merge(/*System.Security.Policy.Evidence*/ evidence)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(133147000915);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
            }
            //--TRIMMABLE-BOUNDARY-END(133147000915)
            
            //--TRIMMABLE-BOUNDARY-START(137441968211)
            /*void */ RemoveType(/*System.Type*/ t)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(137441968211);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
            }
            //--TRIMMABLE-BOUNDARY-END(137441968211)
            
            //--TRIMMABLE-BOUNDARY-START(4358078465)
            //Generated interface implemetation for System.Collections.ICollection.CopyTo(System.Array, int)
            SC$1$ICollection$CopyTo()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4358078465);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.CopyTo(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4358078465)
            
            //--TRIMMABLE-BOUNDARY-START(17242980353)
            //Generated interface implemetation for System.Collections.ICollection.Count.get
            get SC$1$ICollection$Count()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8653045761);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Count;
            }
            //--TRIMMABLE-BOUNDARY-END(17242980353)
            
            //--TRIMMABLE-BOUNDARY-START(34422849537)
            //Generated interface implemetation for System.Collections.ICollection.SyncRoot.get
            get SC$1$ICollection$SyncRoot()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(43012784129);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.SyncRoot;
            }
            //--TRIMMABLE-BOUNDARY-END(34422849537)
            
            //--TRIMMABLE-BOUNDARY-START(25832914945)
            //Generated interface implemetation for System.Collections.ICollection.IsSynchronized.get
            get SC$1$ICollection$IsSynchronized()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(38717816833);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.IsSynchronized;
            }
            //--TRIMMABLE-BOUNDARY-END(25832914945)
            
            //--TRIMMABLE-BOUNDARY-START(4358340609)
            //Generated interface implemetation for System.Collections.IEnumerable.GetEnumerator()
            SC$1$IEnumerable$GetEnumerator()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4358340609);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.GetEnumerator(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4358340609)
            
            //--TRIMMABLE-BOUNDARY-START(4297982035)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4297982035)
            
            static $h = 3014739;
            static $f = 0b10010001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(51542622291),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 60132556883,
        "f": 50331649
      },
      "n": "Count",
      "d": 3014739,
      "h": 51542622291,
      "f": 2097153,
      "a": [
        {
          "t": 104464385,
          "c": 30169235457,
          "a": [
            {
              "v": "Evidence should not be treated as an ICollection. Use GetHostEnumerator and GetAssemblyEnumerator to iterate over the evidence to collect a count.",
              "t": 1310721
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(51542622291),
//--TRIMMABLE-BOUNDARY-START(120262099027),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 68722491475,
        "f": 50331649
      },
      "n": "IsReadOnly",
      "d": 3014739,
      "h": 120262099027,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(120262099027),
//--TRIMMABLE-BOUNDARY-START(124557066323),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 77312426067,
        "f": 50331649
      },
      "n": "IsSynchronized",
      "d": 3014739,
      "h": 124557066323,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(124557066323),
//--TRIMMABLE-BOUNDARY-START(128852033619),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 85902360659,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 146031902803,
        "f": 83886081
      },
      "n": "Locked",
      "d": 3014739,
      "h": 128852033619,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(128852033619),
//--TRIMMABLE-BOUNDARY-START(150326870099),
    {
      "p": 131073,
      "g": {
        "r": 0,
        "d": 0,
        "h": 94492295251,
        "f": 50331649
      },
      "n": "SyncRoot",
      "d": 3014739,
      "h": 150326870099,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(150326870099)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(21477851219),
    {
      "r": 65537,
      "p": [
        {
          "n": "id",
          "p": 131073
        }
      ],
      "n": "AddAssembly",
      "d": 3014739,
      "h": 21477851219,
      "f": 16777217,
      "a": [
        {
          "t": 104464385,
          "c": 30169235457,
          "a": [
            {
              "v": "Evidence.AddAssembly has been deprecated. Use AddAssemblyEvidence instead.",
              "t": 1310721
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(21477851219),
//--TRIMMABLE-BOUNDARY-START(25772818515),
    {
      "r": 65537,
      "p": [
        {
          "n": "evidence",
          "p": (T) => T.$h
        }
      ],
      "g": [
        "T"
      ],
      "n": "AddAssemblyEvidence",
      "d": 3014739,
      "h": 25772818515,
      "f": 16908289
    },
//--TRIMMABLE-BOUNDARY-END(25772818515),
//--TRIMMABLE-BOUNDARY-START(30067785811),
    {
      "r": 65537,
      "p": [
        {
          "n": "id",
          "p": 131073
        }
      ],
      "n": "AddHost",
      "d": 3014739,
      "h": 30067785811,
      "f": 16777217,
      "a": [
        {
          "t": 104464385,
          "c": 30169235457,
          "a": [
            {
              "v": "Evidence.AddHost has been deprecated. Use AddHostEvidence instead.",
              "t": 1310721
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(30067785811),
//--TRIMMABLE-BOUNDARY-START(34362753107),
    {
      "r": 65537,
      "p": [
        {
          "n": "evidence",
          "p": (T) => T.$h
        }
      ],
      "g": [
        "T"
      ],
      "n": "AddHostEvidence",
      "d": 3014739,
      "h": 34362753107,
      "f": 16908289
    },
//--TRIMMABLE-BOUNDARY-END(34362753107),
//--TRIMMABLE-BOUNDARY-START(38657720403),
    {
      "r": 65537,
      "n": "Clear",
      "d": 3014739,
      "h": 38657720403,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(38657720403),
//--TRIMMABLE-BOUNDARY-START(42952687699),
    {
      "r": 3014739,
      "n": "Clone",
      "d": 3014739,
      "h": 42952687699,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(42952687699),
//--TRIMMABLE-BOUNDARY-START(47247654995),
    {
      "r": 65537,
      "p": [
        {
          "n": "array",
          "p": 1245185
        },
        {
          "n": "index",
          "p": 655361
        }
      ],
      "n": "CopyTo",
      "d": 3014739,
      "h": 47247654995,
      "f": 16777217,
      "a": [
        {
          "t": 104464385,
          "c": 30169235457,
          "a": [
            {
              "v": "Evidence should not be treated as an ICollection. Use the GetHostEnumerator and GetAssemblyEnumerator methods rather than using CopyTo.",
              "t": 1310721
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(47247654995),
//--TRIMMABLE-BOUNDARY-START(98787262547),
    {
      "r": 63504385,
      "n": "GetAssemblyEnumerator",
      "d": 3014739,
      "h": 98787262547,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(98787262547),
//--TRIMMABLE-BOUNDARY-START(103082229843),
    {
      "r": (T) => T.$h,
      "g": [
        "T"
      ],
      "n": "GetAssemblyEvidence",
      "d": 3014739,
      "h": 103082229843,
      "f": 16908289
    },
//--TRIMMABLE-BOUNDARY-END(103082229843),
//--TRIMMABLE-BOUNDARY-START(107377197139),
    {
      "r": 63504385,
      "n": "GetEnumerator",
      "d": 3014739,
      "h": 107377197139,
      "f": 16777217,
      "a": [
        {
          "t": 104464385,
          "c": 30169235457,
          "a": [
            {
              "v": "GetEnumerator is obsolete. Use GetAssemblyEnumerator and GetHostEnumerator instead.",
              "t": 1310721
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(107377197139),
//--TRIMMABLE-BOUNDARY-START(111672164435),
    {
      "r": 63504385,
      "n": "GetHostEnumerator",
      "d": 3014739,
      "h": 111672164435,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(111672164435),
//--TRIMMABLE-BOUNDARY-START(115967131731),
    {
      "r": (T) => T.$h,
      "g": [
        "T"
      ],
      "n": "GetHostEvidence",
      "d": 3014739,
      "h": 115967131731,
      "f": 16908289
    },
//--TRIMMABLE-BOUNDARY-END(115967131731),
//--TRIMMABLE-BOUNDARY-START(133147000915),
    {
      "r": 65537,
      "p": [
        {
          "n": "evidence",
          "p": 3014739
        }
      ],
      "n": "Merge",
      "d": 3014739,
      "h": 133147000915,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(133147000915),
//--TRIMMABLE-BOUNDARY-START(137441968211),
    {
      "r": 65537,
      "p": [
        {
          "n": "t",
          "p": 188547073
        }
      ],
      "n": "RemoveType",
      "d": 3014739,
      "h": 137441968211,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(137441968211)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4297982035),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 3014739,
      "h": 4297982035,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4297982035),
//--TRIMMABLE-BOUNDARY-START(8592949331),
    {
      "p": [
        {
          "n": "hostEvidence",
          "p": $.$typeArray($.$$.S.Object).$h
        },
        {
          "n": "assemblyEvidence",
          "p": $.$typeArray($.$$.S.Object).$h
        }
      ],
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 3014739,
      "h": 8592949331,
      "f": 16777217,
      "a": [
        {
          "t": 104464385,
          "c": 30169235457,
          "a": [
            {
              "v": "This constructor is obsolete. Use the constructor which accepts arrays of EvidenceBase instead.",
              "t": 1310721
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(8592949331),
//--TRIMMABLE-BOUNDARY-START(17182883923),
    {
      "p": [
        {
          "n": "evidence",
          "p": 3014739
        }
      ],
      "n": ".ctor",
      "o": "$ctor$4",
      "d": 3014739,
      "h": 17182883923,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(17182883923),
//--TRIMMABLE-BOUNDARY-START(12887916627),
    {
      "p": [
        {
          "n": "hostEvidence",
          "p": $.$typeArray($.$ssa.SSP.EvidenceBase).$h
        },
        {
          "n": "assemblyEvidence",
          "p": $.$typeArray($.$ssa.SSP.EvidenceBase).$h
        }
      ],
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 3014739,
      "h": 12887916627,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(12887916627)
  ],
  "h": 3014739
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.SC$1.ICollection, $.$$.SC$1.IEnumerable ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `System.Security.Policy.Evidence`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `System${separator}Security${separator}Policy${separator}Evidence`; }
        });
        //--TRIMMABLE-BOUNDARY-END(3014739)
        
        

        //--TRIMMABLE-BOUNDARY-START(1245267)
        $asm.$cls(`$ssa.SSA.CommonSecurityDescriptor`, ($self) => class CommonSecurityDescriptor extends $.$ssa.SSA.GenericSecurityDescriptor
        {
            //--TRIMMABLE-BOUNDARY-START(4296212563)
            $ctor$2(/*bool*/ isContainer, /*bool*/ isDS, /*byte[]*/ binaryForm, /*int*/ offset)
            {
                super.$ctor$1();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4296212563);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296212563)
            
            //--TRIMMABLE-BOUNDARY-START(8591179859)
            $ctor$3(/*bool*/ isContainer, /*bool*/ isDS, /*System.Security.AccessControl.ControlFlags*/ flags, /*System.Security.Principal.SecurityIdentifier?*/ owner, /*System.Security.Principal.SecurityIdentifier?*/ group, /*System.Security.AccessControl.SystemAcl?*/ systemAcl, /*System.Security.AccessControl.DiscretionaryAcl?*/ discretionaryAcl)
            {
                super.$ctor$1();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(8591179859);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(8591179859)
            
            //--TRIMMABLE-BOUNDARY-START(12886147155)
            $ctor$4(/*bool*/ isContainer, /*bool*/ isDS, /*System.Security.AccessControl.RawSecurityDescriptor*/ rawSecurityDescriptor)
            {
                super.$ctor$1();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(12886147155);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(12886147155)
            
            //--TRIMMABLE-BOUNDARY-START(17181114451)
            $ctor$5(/*bool*/ isContainer, /*bool*/ isDS, /*string*/ sddlForm)
            {
                super.$ctor$1();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(17181114451);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(17181114451)
            
            //--TRIMMABLE-BOUNDARY-START(30066016339)
            /*System.Security.AccessControl.ControlFlags */ get ControlFlags()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(42950918227);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(30066016339)
            
            //--TRIMMABLE-BOUNDARY-START(34360983635)
            /*System.Security.AccessControl.DiscretionaryAcl? */ get DiscretionaryAcl()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(51540852819);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Security.AccessControl.DiscretionaryAcl? */ set DiscretionaryAcl(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(154620067923);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(34360983635)
            
            //--TRIMMABLE-BOUNDARY-START(115965362259)
            /*System.Security.Principal.SecurityIdentifier? */ get Group()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(60130787411);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Security.Principal.SecurityIdentifier? */ set Group(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(163210002515);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(115965362259)
            
            //--TRIMMABLE-BOUNDARY-START(120260329555)
            /*bool */ get IsContainer()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(68720722003);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(120260329555)
            
            //--TRIMMABLE-BOUNDARY-START(124555296851)
            /*bool */ get IsDiscretionaryAclCanonical()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(77310656595);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(124555296851)
            
            //--TRIMMABLE-BOUNDARY-START(128850264147)
            /*bool */ get IsDS()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(85900591187);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(128850264147)
            
            //--TRIMMABLE-BOUNDARY-START(133145231443)
            /*bool */ get IsSystemAclCanonical()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(94490525779);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(133145231443)
            
            //--TRIMMABLE-BOUNDARY-START(137440198739)
            /*System.Security.Principal.SecurityIdentifier? */ get Owner()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(103080460371);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Security.Principal.SecurityIdentifier? */ set Owner(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(171799937107);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(137440198739)
            
            //--TRIMMABLE-BOUNDARY-START(193274773587)
            /*System.Security.AccessControl.SystemAcl? */ get SystemAcl()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(111670394963);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Security.AccessControl.SystemAcl? */ set SystemAcl(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(180389871699);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(193274773587)
            
            //--TRIMMABLE-BOUNDARY-START(21476081747)
            /*void */ AddDiscretionaryAcl(/*byte*/ revision, /*int*/ trusted)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21476081747);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
            }
            //--TRIMMABLE-BOUNDARY-END(21476081747)
            
            //--TRIMMABLE-BOUNDARY-START(25771049043)
            /*void */ AddSystemAcl(/*byte*/ revision, /*int*/ trusted)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25771049043);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
            }
            //--TRIMMABLE-BOUNDARY-END(25771049043)
            
            //--TRIMMABLE-BOUNDARY-START(141735166035)
            /*void */ PurgeAccessControl(/*System.Security.Principal.SecurityIdentifier*/ sid)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(141735166035);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
            }
            //--TRIMMABLE-BOUNDARY-END(141735166035)
            
            //--TRIMMABLE-BOUNDARY-START(146030133331)
            /*void */ PurgeAudit(/*System.Security.Principal.SecurityIdentifier*/ sid)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(146030133331);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
            }
            //--TRIMMABLE-BOUNDARY-END(146030133331)
            
            //--TRIMMABLE-BOUNDARY-START(184684838995)
            /*void */ SetDiscretionaryAclProtection(/*bool*/ isProtected, /*bool*/ preserveInheritance)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(184684838995);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
            }
            //--TRIMMABLE-BOUNDARY-END(184684838995)
            
            //--TRIMMABLE-BOUNDARY-START(188979806291)
            /*void */ SetSystemAclProtection(/*bool*/ isProtected, /*bool*/ preserveInheritance)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(188979806291);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
            }
            //--TRIMMABLE-BOUNDARY-END(188979806291)
            
            static $h = 1245267;
            static $f = 0b10010001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$ssa.SSA.GenericSecurityDescriptor; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(30066016339),
    {
      "p": 1441875,
      "g": {
        "r": 0,
        "d": 0,
        "h": 42950918227,
        "f": 50364417
      },
      "n": "ControlFlags",
      "d": 1245267,
      "h": 30066016339,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(30066016339),
//--TRIMMABLE-BOUNDARY-START(34360983635),
    {
      "p": 1572947,
      "g": {
        "r": 0,
        "d": 0,
        "h": 51540852819,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 154620067923,
        "f": 83886081
      },
      "n": "DiscretionaryAcl",
      "d": 1245267,
      "h": 34360983635,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(34360983635),
//--TRIMMABLE-BOUNDARY-START(115965362259),
    {
      "p": 393286,
      "g": {
        "r": 0,
        "d": 0,
        "h": 60130787411,
        "f": 50364417
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 163210002515,
        "f": 83918849
      },
      "n": "Group",
      "d": 1245267,
      "h": 115965362259,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(115965362259),
//--TRIMMABLE-BOUNDARY-START(120260329555),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 68720722003,
        "f": 50331649
      },
      "n": "IsContainer",
      "d": 1245267,
      "h": 120260329555,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(120260329555),
//--TRIMMABLE-BOUNDARY-START(124555296851),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 77310656595,
        "f": 50331649
      },
      "n": "IsDiscretionaryAclCanonical",
      "d": 1245267,
      "h": 124555296851,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(124555296851),
//--TRIMMABLE-BOUNDARY-START(128850264147),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 85900591187,
        "f": 50331649
      },
      "n": "IsDS",
      "d": 1245267,
      "h": 128850264147,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(128850264147),
//--TRIMMABLE-BOUNDARY-START(133145231443),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 94490525779,
        "f": 50331649
      },
      "n": "IsSystemAclCanonical",
      "d": 1245267,
      "h": 133145231443,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(133145231443),
//--TRIMMABLE-BOUNDARY-START(137440198739),
    {
      "p": 393286,
      "g": {
        "r": 0,
        "d": 0,
        "h": 103080460371,
        "f": 50364417
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 171799937107,
        "f": 83918849
      },
      "n": "Owner",
      "d": 1245267,
      "h": 137440198739,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(137440198739),
//--TRIMMABLE-BOUNDARY-START(193274773587),
    {
      "p": 2949203,
      "g": {
        "r": 0,
        "d": 0,
        "h": 111670394963,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 180389871699,
        "f": 83886081
      },
      "n": "SystemAcl",
      "d": 1245267,
      "h": 193274773587,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(193274773587)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(21476081747),
    {
      "r": 65537,
      "p": [
        {
          "n": "revision",
          "p": 393217
        },
        {
          "n": "trusted",
          "p": 655361
        }
      ],
      "n": "AddDiscretionaryAcl",
      "d": 1245267,
      "h": 21476081747,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(21476081747),
//--TRIMMABLE-BOUNDARY-START(25771049043),
    {
      "r": 65537,
      "p": [
        {
          "n": "revision",
          "p": 393217
        },
        {
          "n": "trusted",
          "p": 655361
        }
      ],
      "n": "AddSystemAcl",
      "d": 1245267,
      "h": 25771049043,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(25771049043),
//--TRIMMABLE-BOUNDARY-START(141735166035),
    {
      "r": 65537,
      "p": [
        {
          "n": "sid",
          "p": 393286
        }
      ],
      "n": "PurgeAccessControl",
      "d": 1245267,
      "h": 141735166035,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(141735166035),
//--TRIMMABLE-BOUNDARY-START(146030133331),
    {
      "r": 65537,
      "p": [
        {
          "n": "sid",
          "p": 393286
        }
      ],
      "n": "PurgeAudit",
      "d": 1245267,
      "h": 146030133331,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(146030133331),
//--TRIMMABLE-BOUNDARY-START(184684838995),
    {
      "r": 65537,
      "p": [
        {
          "n": "isProtected",
          "p": 262145
        },
        {
          "n": "preserveInheritance",
          "p": 262145
        }
      ],
      "n": "SetDiscretionaryAclProtection",
      "d": 1245267,
      "h": 184684838995,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(184684838995),
//--TRIMMABLE-BOUNDARY-START(188979806291),
    {
      "r": 65537,
      "p": [
        {
          "n": "isProtected",
          "p": 262145
        },
        {
          "n": "preserveInheritance",
          "p": 262145
        }
      ],
      "n": "SetSystemAclProtection",
      "d": 1245267,
      "h": 188979806291,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(188979806291)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296212563),
    {
      "p": [
        {
          "n": "isContainer",
          "p": 262145
        },
        {
          "n": "isDS",
          "p": 262145
        },
        {
          "n": "binaryForm",
          "p": $.$typeArray($.$$.S.Byte).$h
        },
        {
          "n": "offset",
          "p": 655361
        }
      ],
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 1245267,
      "h": 4296212563,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296212563),
//--TRIMMABLE-BOUNDARY-START(8591179859),
    {
      "p": [
        {
          "n": "isContainer",
          "p": 262145
        },
        {
          "n": "isDS",
          "p": 262145
        },
        {
          "n": "flags",
          "p": 1441875
        },
        {
          "n": "owner",
          "p": 393286
        },
        {
          "n": "group",
          "p": 393286
        },
        {
          "n": "systemAcl",
          "p": 2949203
        },
        {
          "n": "discretionaryAcl",
          "p": 1572947
        }
      ],
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 1245267,
      "h": 8591179859,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8591179859),
//--TRIMMABLE-BOUNDARY-START(12886147155),
    {
      "p": [
        {
          "n": "isContainer",
          "p": 262145
        },
        {
          "n": "isDS",
          "p": 262145
        },
        {
          "n": "rawSecurityDescriptor",
          "p": 2752595
        }
      ],
      "n": ".ctor",
      "o": "$ctor$4",
      "d": 1245267,
      "h": 12886147155,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(12886147155),
//--TRIMMABLE-BOUNDARY-START(17181114451),
    {
      "p": [
        {
          "n": "isContainer",
          "p": 262145
        },
        {
          "n": "isDS",
          "p": 262145
        },
        {
          "n": "sddlForm",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 1245267,
      "h": 17181114451,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(17181114451)
  ],
  "h": 1245267
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `System.Security.AccessControl.CommonSecurityDescriptor`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `System${separator}Security${separator}AccessControl${separator}CommonSecurityDescriptor`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1245267)
        
        

        //--TRIMMABLE-BOUNDARY-START(1507411)
        $asm.$cls(`$ssa.SSA.CustomAce`, ($self) => class CustomAce extends $.$ssa.SSA.GenericAce
        {
            //--TRIMMABLE-BOUNDARY-START(38656213075)
            /*int*/ static MaxOpaqueLength = 0;
            //--TRIMMABLE-BOUNDARY-END(38656213075)
            
            //--TRIMMABLE-BOUNDARY-START(4296474707)
            $ctor$2(/*System.Security.AccessControl.AceType*/ type, /*System.Security.AccessControl.AceFlags*/ flags, /*byte[]?*/ opaque)
            {
                super.$ctor$1();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4296474707);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296474707)
            
            //--TRIMMABLE-BOUNDARY-START(8591442003)
            /*int */ get BinaryLength()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17181376595);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(8591442003)
            
            //--TRIMMABLE-BOUNDARY-START(42951180371)
            /*int */ get OpaqueLength()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25771311187);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(42951180371)
            
            //--TRIMMABLE-BOUNDARY-START(30066278483)
            /*void */ GetBinaryForm(/*byte[]*/ binaryForm, /*int*/ offset)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(30066278483);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
            }
            //--TRIMMABLE-BOUNDARY-END(30066278483)
            
            //--TRIMMABLE-BOUNDARY-START(34361245779)
            /*byte[]? */ GetOpaque()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(34361245779);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(34361245779)
            
            //--TRIMMABLE-BOUNDARY-START(47246147667)
            /*void */ SetOpaque(/*byte[]?*/ opaque)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(47246147667);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
            }
            //--TRIMMABLE-BOUNDARY-END(47246147667)
            
            static $h = 1507411;
            static $f = 0b10010001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$ssa.SSA.GenericAce; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(8591442003),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 17181376595,
        "f": 50364417
      },
      "n": "BinaryLength",
      "d": 1507411,
      "h": 8591442003,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(8591442003),
//--TRIMMABLE-BOUNDARY-START(42951180371),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 25771311187,
        "f": 50331649
      },
      "n": "OpaqueLength",
      "d": 1507411,
      "h": 42951180371,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(42951180371)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(30066278483),
    {
      "r": 65537,
      "p": [
        {
          "n": "binaryForm",
          "p": $.$typeArray($.$$.S.Byte).$h
        },
        {
          "n": "offset",
          "p": 655361
        }
      ],
      "n": "GetBinaryForm",
      "d": 1507411,
      "h": 30066278483,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(30066278483),
//--TRIMMABLE-BOUNDARY-START(34361245779),
    {
      "r": $.$typeArray($.$$.S.Byte).$h,
      "n": "GetOpaque",
      "d": 1507411,
      "h": 34361245779,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(34361245779),
//--TRIMMABLE-BOUNDARY-START(47246147667),
    {
      "r": 65537,
      "p": [
        {
          "n": "opaque",
          "p": $.$typeArray($.$$.S.Byte).$h
        }
      ],
      "n": "SetOpaque",
      "d": 1507411,
      "h": 47246147667,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(47246147667)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(38656213075),
    {
      "t": 655361,
      "n": "MaxOpaqueLength",
      "d": 1507411,
      "h": 38656213075,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(38656213075)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296474707),
    {
      "p": [
        {
          "n": "type",
          "p": 655443
        },
        {
          "n": "flags",
          "p": 524371
        },
        {
          "n": "opaque",
          "p": $.$typeArray($.$$.S.Byte).$h
        }
      ],
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 1507411,
      "h": 4296474707,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296474707)
  ],
  "h": 1507411
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `System.Security.AccessControl.CustomAce`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `System${separator}Security${separator}AccessControl${separator}CustomAce`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1507411)
        
        

        //--TRIMMABLE-BOUNDARY-START(2752595)
        $asm.$cls(`$ssa.SSA.RawSecurityDescriptor`, ($self) => class RawSecurityDescriptor extends $.$ssa.SSA.GenericSecurityDescriptor
        {
            //--TRIMMABLE-BOUNDARY-START(4297719891)
            $ctor$2(/*byte[]*/ binaryForm, /*int*/ offset)
            {
                super.$ctor$1();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4297719891);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4297719891)
            
            //--TRIMMABLE-BOUNDARY-START(8592687187)
            $ctor$3(/*System.Security.AccessControl.ControlFlags*/ flags, /*System.Security.Principal.SecurityIdentifier?*/ owner, /*System.Security.Principal.SecurityIdentifier?*/ group, /*System.Security.AccessControl.RawAcl?*/ systemAcl, /*System.Security.AccessControl.RawAcl?*/ discretionaryAcl)
            {
                super.$ctor$1();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(8592687187);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(8592687187)
            
            //--TRIMMABLE-BOUNDARY-START(12887654483)
            $ctor$4(/*string*/ sddlForm)
            {
                super.$ctor$1();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(12887654483);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(12887654483)
            
            //--TRIMMABLE-BOUNDARY-START(17182621779)
            /*System.Security.AccessControl.ControlFlags */ get ControlFlags()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(30067523667);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(17182621779)
            
            //--TRIMMABLE-BOUNDARY-START(21477589075)
            /*System.Security.AccessControl.RawAcl? */ get DiscretionaryAcl()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(38657458259);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Security.AccessControl.RawAcl? */ set DiscretionaryAcl(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(94492033107);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(21477589075)
            
            //--TRIMMABLE-BOUNDARY-START(77312163923)
            /*System.Security.Principal.SecurityIdentifier? */ get Group()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(47247392851);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Security.Principal.SecurityIdentifier? */ set Group(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(103081967699);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(77312163923)
            
            //--TRIMMABLE-BOUNDARY-START(81607131219)
            /*System.Security.Principal.SecurityIdentifier? */ get Owner()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(55837327443);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Security.Principal.SecurityIdentifier? */ set Owner(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(111671902291);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(81607131219)
            
            //--TRIMMABLE-BOUNDARY-START(85902098515)
            /*byte */ get ResourceManagerControl()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(64427262035);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            /*byte */ set ResourceManagerControl(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(120261836883);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(85902098515)
            
            //--TRIMMABLE-BOUNDARY-START(137441706067)
            /*System.Security.AccessControl.RawAcl? */ get SystemAcl()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(73017196627);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Security.AccessControl.RawAcl? */ set SystemAcl(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(128851771475);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(137441706067)
            
            //--TRIMMABLE-BOUNDARY-START(133146738771)
            /*void */ SetFlags(/*System.Security.AccessControl.ControlFlags*/ flags)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(133146738771);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
            }
            //--TRIMMABLE-BOUNDARY-END(133146738771)
            
            static $h = 2752595;
            static $f = 0b10010001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$ssa.SSA.GenericSecurityDescriptor; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(17182621779),
    {
      "p": 1441875,
      "g": {
        "r": 0,
        "d": 0,
        "h": 30067523667,
        "f": 50364417
      },
      "n": "ControlFlags",
      "d": 2752595,
      "h": 17182621779,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(17182621779),
//--TRIMMABLE-BOUNDARY-START(21477589075),
    {
      "p": 2687059,
      "g": {
        "r": 0,
        "d": 0,
        "h": 38657458259,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 94492033107,
        "f": 83886081
      },
      "n": "DiscretionaryAcl",
      "d": 2752595,
      "h": 21477589075,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(21477589075),
//--TRIMMABLE-BOUNDARY-START(77312163923),
    {
      "p": 393286,
      "g": {
        "r": 0,
        "d": 0,
        "h": 47247392851,
        "f": 50364417
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 103081967699,
        "f": 83918849
      },
      "n": "Group",
      "d": 2752595,
      "h": 77312163923,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(77312163923),
//--TRIMMABLE-BOUNDARY-START(81607131219),
    {
      "p": 393286,
      "g": {
        "r": 0,
        "d": 0,
        "h": 55837327443,
        "f": 50364417
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 111671902291,
        "f": 83918849
      },
      "n": "Owner",
      "d": 2752595,
      "h": 81607131219,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(81607131219),
//--TRIMMABLE-BOUNDARY-START(85902098515),
    {
      "p": 393217,
      "g": {
        "r": 0,
        "d": 0,
        "h": 64427262035,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 120261836883,
        "f": 83886081
      },
      "n": "ResourceManagerControl",
      "d": 2752595,
      "h": 85902098515,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(85902098515),
//--TRIMMABLE-BOUNDARY-START(137441706067),
    {
      "p": 2687059,
      "g": {
        "r": 0,
        "d": 0,
        "h": 73017196627,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 128851771475,
        "f": 83886081
      },
      "n": "SystemAcl",
      "d": 2752595,
      "h": 137441706067,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(137441706067)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(133146738771),
    {
      "r": 65537,
      "p": [
        {
          "n": "flags",
          "p": 1441875
        }
      ],
      "n": "SetFlags",
      "d": 2752595,
      "h": 133146738771,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(133146738771)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4297719891),
    {
      "p": [
        {
          "n": "binaryForm",
          "p": $.$typeArray($.$$.S.Byte).$h
        },
        {
          "n": "offset",
          "p": 655361
        }
      ],
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 2752595,
      "h": 4297719891,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4297719891),
//--TRIMMABLE-BOUNDARY-START(8592687187),
    {
      "p": [
        {
          "n": "flags",
          "p": 1441875
        },
        {
          "n": "owner",
          "p": 393286
        },
        {
          "n": "group",
          "p": 393286
        },
        {
          "n": "systemAcl",
          "p": 2687059
        },
        {
          "n": "discretionaryAcl",
          "p": 2687059
        }
      ],
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 2752595,
      "h": 8592687187,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8592687187),
//--TRIMMABLE-BOUNDARY-START(12887654483),
    {
      "p": [
        {
          "n": "sddlForm",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$4",
      "d": 2752595,
      "h": 12887654483,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(12887654483)
  ],
  "h": 2752595
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `System.Security.AccessControl.RawSecurityDescriptor`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `System${separator}Security${separator}AccessControl${separator}RawSecurityDescriptor`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2752595)
        
        

        //--TRIMMABLE-BOUNDARY-START(983123)
        $asm.$cls(`$ssa.SSA.AuthorizationRuleCollection`, ($self) => class AuthorizationRuleCollection extends $.$scn.SC.ReadOnlyCollectionBase
        {
            //--TRIMMABLE-BOUNDARY-START(4295950419)
            $ctor$2()
            {
                super.$ctor$1();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4295950419);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295950419)
            
            //--TRIMMABLE-BOUNDARY-START(25770786899)
            /*System.Security.AccessControl.AuthorizationRule?*/ get_Item$1(/*int*/ index)
            {
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(25770786899)
            
            //--TRIMMABLE-BOUNDARY-START(8590917715)
            /*void */ AddRule(/*System.Security.AccessControl.AuthorizationRule?*/ rule)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590917715);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
            }
            //--TRIMMABLE-BOUNDARY-END(8590917715)
            
            //--TRIMMABLE-BOUNDARY-START(12885885011)
            /*void */ CopyTo(/*System.Security.AccessControl.AuthorizationRule[]*/ rules, /*int*/ index)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12885885011);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
            }
            //--TRIMMABLE-BOUNDARY-END(12885885011)
            
            //--TRIMMABLE-BOUNDARY-START(4295950419)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$2();
            }
            //--TRIMMABLE-BOUNDARY-END(4295950419)
            
            static $h = 983123;
            static $f = 0b10010001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$scn.SC.ReadOnlyCollectionBase; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(25770786899),
    {
      "p": 917587,
      "i": [
        {
          "n": "index",
          "p": 655361
        }
      ],
      "g": {
        "r": 0,
        "d": 0,
        "h": 21475819603,
        "f": 50331649
      },
      "n": "Item",
      "o": "@$1",
      "d": 983123,
      "h": 25770786899,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(25770786899)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(8590917715),
    {
      "r": 65537,
      "p": [
        {
          "n": "rule",
          "p": 917587
        }
      ],
      "n": "AddRule",
      "d": 983123,
      "h": 8590917715,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8590917715),
//--TRIMMABLE-BOUNDARY-START(12885885011),
    {
      "r": 65537,
      "p": [
        {
          "n": "rules",
          "p": $.$typeArray($.$ssa.SSA.AuthorizationRule).$h
        },
        {
          "n": "index",
          "p": 655361
        }
      ],
      "n": "CopyTo",
      "d": 983123,
      "h": 12885885011,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(12885885011)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295950419),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 983123,
      "h": 4295950419,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295950419)
  ],
  "h": 983123
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.SC$1.ICollection, $.$$.SC$1.IEnumerable ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `System.Security.AccessControl.AuthorizationRuleCollection`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `System${separator}Security${separator}AccessControl${separator}AuthorizationRuleCollection`; }
        });
        //--TRIMMABLE-BOUNDARY-END(983123)
        
        

        //--TRIMMABLE-BOUNDARY-START(2687059)
        $asm.$cls(`$ssa.SSA.RawAcl`, ($self) => class RawAcl extends $.$ssa.SSA.GenericAcl
        {
            //--TRIMMABLE-BOUNDARY-START(4297654355)
            $ctor$2(/*byte*/ revision, /*int*/ capacity)
            {
                super.$ctor$1();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4297654355);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4297654355)
            
            //--TRIMMABLE-BOUNDARY-START(8592621651)
            $ctor$3(/*byte[]*/ binaryForm, /*int*/ offset)
            {
                super.$ctor$1();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(8592621651);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(8592621651)
            
            //--TRIMMABLE-BOUNDARY-START(12887588947)
            /*int */ get BinaryLength()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25772490835);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(12887588947)
            
            //--TRIMMABLE-BOUNDARY-START(17182556243)
            /*int */ get Count()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(34362425427);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(17182556243)
            
            //--TRIMMABLE-BOUNDARY-START(81607065683)
            /*System.Security.AccessControl.GenericAce*/ get_Item$1(/*int*/ index)
            {
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            /*void*/ set_Item$1(/*int*/ index, /*System.Security.AccessControl.GenericAce*/ value)
            {
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(81607065683)
            
            //--TRIMMABLE-BOUNDARY-START(68722163795)
            /*byte */ get Revision()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(51542294611);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(68722163795)
            
            //--TRIMMABLE-BOUNDARY-START(55837261907)
            /*void */ GetBinaryForm(/*byte[]*/ binaryForm, /*int*/ offset)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(55837261907);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
            }
            //--TRIMMABLE-BOUNDARY-END(55837261907)
            
            //--TRIMMABLE-BOUNDARY-START(60132229203)
            /*void */ InsertAce(/*int*/ index, /*System.Security.AccessControl.GenericAce*/ ace)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(60132229203);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
            }
            //--TRIMMABLE-BOUNDARY-END(60132229203)
            
            //--TRIMMABLE-BOUNDARY-START(64427196499)
            /*void */ RemoveAce(/*int*/ index)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(64427196499);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
            }
            //--TRIMMABLE-BOUNDARY-END(64427196499)
            
            static $h = 2687059;
            static $f = 0b10010001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$ssa.SSA.GenericAcl; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(12887588947),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 25772490835,
        "f": 50364417
      },
      "n": "BinaryLength",
      "d": 2687059,
      "h": 12887588947,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(12887588947),
//--TRIMMABLE-BOUNDARY-START(17182556243),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 34362425427,
        "f": 50364417
      },
      "n": "Count",
      "d": 2687059,
      "h": 17182556243,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(17182556243),
//--TRIMMABLE-BOUNDARY-START(81607065683),
    {
      "p": 1638483,
      "i": [
        {
          "n": "index",
          "p": 655361
        }
      ],
      "g": {
        "r": 0,
        "d": 0,
        "h": 42952360019,
        "f": 50364417
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 77312098387,
        "f": 83918849
      },
      "n": "Item",
      "o": "@$1",
      "d": 2687059,
      "h": 81607065683,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(81607065683),
//--TRIMMABLE-BOUNDARY-START(68722163795),
    {
      "p": 393217,
      "g": {
        "r": 0,
        "d": 0,
        "h": 51542294611,
        "f": 50364417
      },
      "n": "Revision",
      "d": 2687059,
      "h": 68722163795,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(68722163795)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(55837261907),
    {
      "r": 65537,
      "p": [
        {
          "n": "binaryForm",
          "p": $.$typeArray($.$$.S.Byte).$h
        },
        {
          "n": "offset",
          "p": 655361
        }
      ],
      "n": "GetBinaryForm",
      "d": 2687059,
      "h": 55837261907,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(55837261907),
//--TRIMMABLE-BOUNDARY-START(60132229203),
    {
      "r": 65537,
      "p": [
        {
          "n": "index",
          "p": 655361
        },
        {
          "n": "ace",
          "p": 1638483
        }
      ],
      "n": "InsertAce",
      "d": 2687059,
      "h": 60132229203,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(60132229203),
//--TRIMMABLE-BOUNDARY-START(64427196499),
    {
      "r": 65537,
      "p": [
        {
          "n": "index",
          "p": 655361
        }
      ],
      "n": "RemoveAce",
      "d": 2687059,
      "h": 64427196499,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(64427196499)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4297654355),
    {
      "p": [
        {
          "n": "revision",
          "p": 393217
        },
        {
          "n": "capacity",
          "p": 655361
        }
      ],
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 2687059,
      "h": 4297654355,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4297654355),
//--TRIMMABLE-BOUNDARY-START(8592621651),
    {
      "p": [
        {
          "n": "binaryForm",
          "p": $.$typeArray($.$$.S.Byte).$h
        },
        {
          "n": "offset",
          "p": 655361
        }
      ],
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 2687059,
      "h": 8592621651,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8592621651)
  ],
  "h": 2687059
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.SC$1.ICollection, $.$$.SC$1.IEnumerable ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `System.Security.AccessControl.RawAcl`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `System${separator}Security${separator}AccessControl${separator}RawAcl`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2687059)
        
        

        //--TRIMMABLE-BOUNDARY-START(393299)
        $asm.$cls(`$ssa.SSA.AccessRule<>`, (T) => $asm.$gt(`$ssa.SSA.AccessRule<>`, [T], ($self) => class AccessRule$$ extends $.$ssa.SSA.AccessRule
        {
            //--TRIMMABLE-BOUNDARY-START(4295360595)
            $ctor$3(/*System.Security.Principal.IdentityReference*/ identity, /*T*/ rights, /*System.Security.AccessControl.AccessControlType*/ type)
            {
                super.$ctor$2(null, 0, false, 0, 0, 0);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4295360595);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295360595)
            
            //--TRIMMABLE-BOUNDARY-START(8590327891)
            $ctor$4(/*System.Security.Principal.IdentityReference*/ identity, /*T*/ rights, /*System.Security.AccessControl.InheritanceFlags*/ inheritanceFlags, /*System.Security.AccessControl.PropagationFlags*/ propagationFlags, /*System.Security.AccessControl.AccessControlType*/ type)
            {
                super.$ctor$2(null, 0, false, 0, 0, 0);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(8590327891);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(8590327891)
            
            //--TRIMMABLE-BOUNDARY-START(12885295187)
            $ctor$5(/*string*/ identity, /*T*/ rights, /*System.Security.AccessControl.AccessControlType*/ type)
            {
                super.$ctor$2(null, 0, false, 0, 0, 0);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(12885295187);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(12885295187)
            
            //--TRIMMABLE-BOUNDARY-START(17180262483)
            $ctor$6(/*string*/ identity, /*T*/ rights, /*System.Security.AccessControl.InheritanceFlags*/ inheritanceFlags, /*System.Security.AccessControl.PropagationFlags*/ propagationFlags, /*System.Security.AccessControl.AccessControlType*/ type)
            {
                super.$ctor$2(null, 0, false, 0, 0, 0);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(17180262483);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(17180262483)
            
            //--TRIMMABLE-BOUNDARY-START(30065164371)
            /*T */ get Rights()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25770197075);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(30065164371)
            
            static $H = 393299;
            static $h = 393299;
            static $g = 1;
            static $f = 0b1010001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$ssa.SSA.AccessRule; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(30065164371),
    {
      "p": T?.$h??1572864,
      "g": {
        "r": 0,
        "d": 0,
        "H": 25770197075,
        "h": Number(BigInt(this.$h)|0x600000000n),
        "f": 50331649
      },
      "n": "Rights",
      "d": this.$h,
      "H": 30065164371,
      "h": Number(BigInt(this.$h)|0x700000000n),
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(30065164371)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295360595),
    {
      "p": [
        {
          "n": "identity",
          "p": 196678
        },
        {
          "n": "rights",
          "p": T?.$h??1572864
        },
        {
          "n": "type",
          "p": 262227
        }
      ],
      "n": ".ctor",
      "o": "$ctor$3",
      "d": this.$h,
      "H": 4295360595,
      "h": Number(BigInt(this.$h)|0x100000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295360595),
//--TRIMMABLE-BOUNDARY-START(8590327891),
    {
      "p": [
        {
          "n": "identity",
          "p": 196678
        },
        {
          "n": "rights",
          "p": T?.$h??1572864
        },
        {
          "n": "inheritanceFlags",
          "p": 1835091
        },
        {
          "n": "propagationFlags",
          "p": 2555987
        },
        {
          "n": "type",
          "p": 262227
        }
      ],
      "n": ".ctor",
      "o": "$ctor$4",
      "d": this.$h,
      "H": 8590327891,
      "h": Number(BigInt(this.$h)|0x200000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8590327891),
//--TRIMMABLE-BOUNDARY-START(12885295187),
    {
      "p": [
        {
          "n": "identity",
          "p": 1310721
        },
        {
          "n": "rights",
          "p": T?.$h??1572864
        },
        {
          "n": "type",
          "p": 262227
        }
      ],
      "n": ".ctor",
      "o": "$ctor$5",
      "d": this.$h,
      "H": 12885295187,
      "h": Number(BigInt(this.$h)|0x300000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(12885295187),
//--TRIMMABLE-BOUNDARY-START(17180262483),
    {
      "p": [
        {
          "n": "identity",
          "p": 1310721
        },
        {
          "n": "rights",
          "p": T?.$h??1572864
        },
        {
          "n": "inheritanceFlags",
          "p": 1835091
        },
        {
          "n": "propagationFlags",
          "p": 2555987
        },
        {
          "n": "type",
          "p": 262227
        }
      ],
      "n": ".ctor",
      "o": "$ctor$6",
      "d": this.$h,
      "H": 17180262483,
      "h": Number(BigInt(this.$h)|0x400000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(17180262483)
  ],
  "s": [
    {
      "h": T?.$h??1572864,
      "n": "T",
      "f": 2
    }
  ],
  "r": 1,
  "H": 393299,
  "h": this.$h
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `System.Security.AccessControl.AccessRule<${T?.$fullName}>`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `System${separator}Security${separator}AccessControl${separator}AccessRule$${T?.$getFullName(separator)}$`; }
        }));
        //--TRIMMABLE-BOUNDARY-END(393299)
        
        

        //--TRIMMABLE-BOUNDARY-START(852051)
        $asm.$cls(`$ssa.SSA.AuditRule<>`, (T) => $asm.$gt(`$ssa.SSA.AuditRule<>`, [T], ($self) => class AuditRule$$ extends $.$ssa.SSA.AuditRule
        {
            //--TRIMMABLE-BOUNDARY-START(4295819347)
            $ctor$3(/*System.Security.Principal.IdentityReference*/ identity, /*T*/ rights, /*System.Security.AccessControl.AuditFlags*/ flags)
            {
                super.$ctor$2(null, 0, false, 0, 0, 0);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4295819347);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295819347)
            
            //--TRIMMABLE-BOUNDARY-START(8590786643)
            $ctor$4(/*System.Security.Principal.IdentityReference*/ identity, /*T*/ rights, /*System.Security.AccessControl.InheritanceFlags*/ inheritanceFlags, /*System.Security.AccessControl.PropagationFlags*/ propagationFlags, /*System.Security.AccessControl.AuditFlags*/ flags)
            {
                super.$ctor$2(null, 0, false, 0, 0, 0);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(8590786643);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(8590786643)
            
            //--TRIMMABLE-BOUNDARY-START(12885753939)
            $ctor$5(/*string*/ identity, /*T*/ rights, /*System.Security.AccessControl.AuditFlags*/ flags)
            {
                super.$ctor$2(null, 0, false, 0, 0, 0);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(12885753939);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(12885753939)
            
            //--TRIMMABLE-BOUNDARY-START(17180721235)
            $ctor$6(/*string*/ identity, /*T*/ rights, /*System.Security.AccessControl.InheritanceFlags*/ inheritanceFlags, /*System.Security.AccessControl.PropagationFlags*/ propagationFlags, /*System.Security.AccessControl.AuditFlags*/ flags)
            {
                super.$ctor$2(null, 0, false, 0, 0, 0);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(17180721235);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(17180721235)
            
            //--TRIMMABLE-BOUNDARY-START(30065623123)
            /*T */ get Rights()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25770655827);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(30065623123)
            
            static $H = 852051;
            static $h = 852051;
            static $g = 1;
            static $f = 0b1010001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$ssa.SSA.AuditRule; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(30065623123),
    {
      "p": T?.$h??1572864,
      "g": {
        "r": 0,
        "d": 0,
        "H": 25770655827,
        "h": Number(BigInt(this.$h)|0x600000000n),
        "f": 50331649
      },
      "n": "Rights",
      "d": this.$h,
      "H": 30065623123,
      "h": Number(BigInt(this.$h)|0x700000000n),
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(30065623123)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295819347),
    {
      "p": [
        {
          "n": "identity",
          "p": 196678
        },
        {
          "n": "rights",
          "p": T?.$h??1572864
        },
        {
          "n": "flags",
          "p": 720979
        }
      ],
      "n": ".ctor",
      "o": "$ctor$3",
      "d": this.$h,
      "H": 4295819347,
      "h": Number(BigInt(this.$h)|0x100000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295819347),
//--TRIMMABLE-BOUNDARY-START(8590786643),
    {
      "p": [
        {
          "n": "identity",
          "p": 196678
        },
        {
          "n": "rights",
          "p": T?.$h??1572864
        },
        {
          "n": "inheritanceFlags",
          "p": 1835091
        },
        {
          "n": "propagationFlags",
          "p": 2555987
        },
        {
          "n": "flags",
          "p": 720979
        }
      ],
      "n": ".ctor",
      "o": "$ctor$4",
      "d": this.$h,
      "H": 8590786643,
      "h": Number(BigInt(this.$h)|0x200000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8590786643),
//--TRIMMABLE-BOUNDARY-START(12885753939),
    {
      "p": [
        {
          "n": "identity",
          "p": 1310721
        },
        {
          "n": "rights",
          "p": T?.$h??1572864
        },
        {
          "n": "flags",
          "p": 720979
        }
      ],
      "n": ".ctor",
      "o": "$ctor$5",
      "d": this.$h,
      "H": 12885753939,
      "h": Number(BigInt(this.$h)|0x300000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(12885753939),
//--TRIMMABLE-BOUNDARY-START(17180721235),
    {
      "p": [
        {
          "n": "identity",
          "p": 1310721
        },
        {
          "n": "rights",
          "p": T?.$h??1572864
        },
        {
          "n": "inheritanceFlags",
          "p": 1835091
        },
        {
          "n": "propagationFlags",
          "p": 2555987
        },
        {
          "n": "flags",
          "p": 720979
        }
      ],
      "n": ".ctor",
      "o": "$ctor$6",
      "d": this.$h,
      "H": 17180721235,
      "h": Number(BigInt(this.$h)|0x400000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(17180721235)
  ],
  "s": [
    {
      "h": T?.$h??1572864,
      "n": "T",
      "f": 2
    }
  ],
  "r": 1,
  "H": 852051,
  "h": this.$h
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `System.Security.AccessControl.AuditRule<${T?.$fullName}>`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `System${separator}Security${separator}AccessControl${separator}AuditRule$${T?.$getFullName(separator)}$`; }
        }));
        //--TRIMMABLE-BOUNDARY-END(852051)
        
        

        //--TRIMMABLE-BOUNDARY-START(1310803)
        $asm.$cls(`$ssa.SSA.CompoundAce`, ($self) => class CompoundAce extends $.$ssa.SSA.KnownAce
        {
            //--TRIMMABLE-BOUNDARY-START(4296278099)
            $ctor$3(/*System.Security.AccessControl.AceFlags*/ flags, /*int*/ accessMask, /*System.Security.AccessControl.CompoundAceType*/ compoundAceType, /*System.Security.Principal.SecurityIdentifier*/ sid)
            {
                super.$ctor$2();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4296278099);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296278099)
            
            //--TRIMMABLE-BOUNDARY-START(8591245395)
            /*int */ get BinaryLength()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21476147283);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(8591245395)
            
            //--TRIMMABLE-BOUNDARY-START(12886212691)
            /*System.Security.AccessControl.CompoundAceType */ get CompoundAceType()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(30066081875);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Security.AccessControl.CompoundAceType */ set CompoundAceType(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(42950983763);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(12886212691)
            
            //--TRIMMABLE-BOUNDARY-START(34361049171)
            /*void */ GetBinaryForm(/*byte[]*/ binaryForm, /*int*/ offset)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(34361049171);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
            }
            //--TRIMMABLE-BOUNDARY-END(34361049171)
            
            static $h = 1310803;
            static $f = 0b10010001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$ssa.SSA.KnownAce; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(8591245395),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 21476147283,
        "f": 50364417
      },
      "n": "BinaryLength",
      "d": 1310803,
      "h": 8591245395,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(8591245395),
//--TRIMMABLE-BOUNDARY-START(12886212691),
    {
      "p": 1376339,
      "g": {
        "r": 0,
        "d": 0,
        "h": 30066081875,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 42950983763,
        "f": 83886081
      },
      "n": "CompoundAceType",
      "d": 1310803,
      "h": 12886212691,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(12886212691)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(34361049171),
    {
      "r": 65537,
      "p": [
        {
          "n": "binaryForm",
          "p": $.$typeArray($.$$.S.Byte).$h
        },
        {
          "n": "offset",
          "p": 655361
        }
      ],
      "n": "GetBinaryForm",
      "d": 1310803,
      "h": 34361049171,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(34361049171)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296278099),
    {
      "p": [
        {
          "n": "flags",
          "p": 524371
        },
        {
          "n": "accessMask",
          "p": 655361
        },
        {
          "n": "compoundAceType",
          "p": 1376339
        },
        {
          "n": "sid",
          "p": 393286
        }
      ],
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 1310803,
      "h": 4296278099,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296278099)
  ],
  "h": 1310803
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `System.Security.AccessControl.CompoundAce`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `System${separator}Security${separator}AccessControl${separator}CompoundAce`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1310803)
        
        

        //--TRIMMABLE-BOUNDARY-START(1572947)
        $asm.$cls(`$ssa.SSA.DiscretionaryAcl`, ($self) => class DiscretionaryAcl extends $.$ssa.SSA.CommonAcl
        {
            //--TRIMMABLE-BOUNDARY-START(4296540243)
            $ctor$3(/*bool*/ isContainer, /*bool*/ isDS, /*byte*/ revision, /*int*/ capacity)
            {
                super.$ctor$2();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4296540243);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296540243)
            
            //--TRIMMABLE-BOUNDARY-START(8591507539)
            $ctor$4(/*bool*/ isContainer, /*bool*/ isDS, /*int*/ capacity)
            {
                super.$ctor$2();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(8591507539);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(8591507539)
            
            //--TRIMMABLE-BOUNDARY-START(12886474835)
            $ctor$5(/*bool*/ isContainer, /*bool*/ isDS, /*System.Security.AccessControl.RawAcl?*/ rawAcl)
            {
                super.$ctor$2();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(12886474835);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(12886474835)
            
            //--TRIMMABLE-BOUNDARY-START(21476409427)
            /*void */ AddAccess$1(/*System.Security.AccessControl.AccessControlType*/ accessType, /*System.Security.Principal.SecurityIdentifier*/ sid, /*int*/ accessMask, /*System.Security.AccessControl.InheritanceFlags*/ inheritanceFlags, /*System.Security.AccessControl.PropagationFlags*/ propagationFlags)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21476409427);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
            }
            //--TRIMMABLE-BOUNDARY-END(21476409427)
            
            //--TRIMMABLE-BOUNDARY-START(17181442131)
            /*void */ AddAccess(/*System.Security.AccessControl.AccessControlType*/ accessType, /*System.Security.Principal.SecurityIdentifier*/ sid, /*int*/ accessMask, /*System.Security.AccessControl.InheritanceFlags*/ inheritanceFlags, /*System.Security.AccessControl.PropagationFlags*/ propagationFlags, /*System.Security.AccessControl.ObjectAceFlags*/ objectFlags, /*System.Guid*/ objectType, /*System.Guid*/ inheritedObjectType)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17181442131);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
            }
            //--TRIMMABLE-BOUNDARY-END(17181442131)
            
            //--TRIMMABLE-BOUNDARY-START(25771376723)
            /*void */ AddAccess$2(/*System.Security.AccessControl.AccessControlType*/ accessType, /*System.Security.Principal.SecurityIdentifier*/ sid, /*System.Security.AccessControl.ObjectAccessRule*/ rule)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25771376723);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
            }
            //--TRIMMABLE-BOUNDARY-END(25771376723)
            
            //--TRIMMABLE-BOUNDARY-START(34361311315)
            /*bool */ RemoveAccess$1(/*System.Security.AccessControl.AccessControlType*/ accessType, /*System.Security.Principal.SecurityIdentifier*/ sid, /*int*/ accessMask, /*System.Security.AccessControl.InheritanceFlags*/ inheritanceFlags, /*System.Security.AccessControl.PropagationFlags*/ propagationFlags)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(34361311315);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(34361311315)
            
            //--TRIMMABLE-BOUNDARY-START(30066344019)
            /*bool */ RemoveAccess(/*System.Security.AccessControl.AccessControlType*/ accessType, /*System.Security.Principal.SecurityIdentifier*/ sid, /*int*/ accessMask, /*System.Security.AccessControl.InheritanceFlags*/ inheritanceFlags, /*System.Security.AccessControl.PropagationFlags*/ propagationFlags, /*System.Security.AccessControl.ObjectAceFlags*/ objectFlags, /*System.Guid*/ objectType, /*System.Guid*/ inheritedObjectType)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(30066344019);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(30066344019)
            
            //--TRIMMABLE-BOUNDARY-START(38656278611)
            /*bool */ RemoveAccess$2(/*System.Security.AccessControl.AccessControlType*/ accessType, /*System.Security.Principal.SecurityIdentifier*/ sid, /*System.Security.AccessControl.ObjectAccessRule*/ rule)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(38656278611);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(38656278611)
            
            //--TRIMMABLE-BOUNDARY-START(47246213203)
            /*void */ RemoveAccessSpecific$1(/*System.Security.AccessControl.AccessControlType*/ accessType, /*System.Security.Principal.SecurityIdentifier*/ sid, /*int*/ accessMask, /*System.Security.AccessControl.InheritanceFlags*/ inheritanceFlags, /*System.Security.AccessControl.PropagationFlags*/ propagationFlags)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(47246213203);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
            }
            //--TRIMMABLE-BOUNDARY-END(47246213203)
            
            //--TRIMMABLE-BOUNDARY-START(42951245907)
            /*void */ RemoveAccessSpecific(/*System.Security.AccessControl.AccessControlType*/ accessType, /*System.Security.Principal.SecurityIdentifier*/ sid, /*int*/ accessMask, /*System.Security.AccessControl.InheritanceFlags*/ inheritanceFlags, /*System.Security.AccessControl.PropagationFlags*/ propagationFlags, /*System.Security.AccessControl.ObjectAceFlags*/ objectFlags, /*System.Guid*/ objectType, /*System.Guid*/ inheritedObjectType)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(42951245907);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
            }
            //--TRIMMABLE-BOUNDARY-END(42951245907)
            
            //--TRIMMABLE-BOUNDARY-START(51541180499)
            /*void */ RemoveAccessSpecific$2(/*System.Security.AccessControl.AccessControlType*/ accessType, /*System.Security.Principal.SecurityIdentifier*/ sid, /*System.Security.AccessControl.ObjectAccessRule*/ rule)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(51541180499);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
            }
            //--TRIMMABLE-BOUNDARY-END(51541180499)
            
            //--TRIMMABLE-BOUNDARY-START(60131115091)
            /*void */ SetAccess$1(/*System.Security.AccessControl.AccessControlType*/ accessType, /*System.Security.Principal.SecurityIdentifier*/ sid, /*int*/ accessMask, /*System.Security.AccessControl.InheritanceFlags*/ inheritanceFlags, /*System.Security.AccessControl.PropagationFlags*/ propagationFlags)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(60131115091);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
            }
            //--TRIMMABLE-BOUNDARY-END(60131115091)
            
            //--TRIMMABLE-BOUNDARY-START(55836147795)
            /*void */ SetAccess(/*System.Security.AccessControl.AccessControlType*/ accessType, /*System.Security.Principal.SecurityIdentifier*/ sid, /*int*/ accessMask, /*System.Security.AccessControl.InheritanceFlags*/ inheritanceFlags, /*System.Security.AccessControl.PropagationFlags*/ propagationFlags, /*System.Security.AccessControl.ObjectAceFlags*/ objectFlags, /*System.Guid*/ objectType, /*System.Guid*/ inheritedObjectType)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(55836147795);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
            }
            //--TRIMMABLE-BOUNDARY-END(55836147795)
            
            //--TRIMMABLE-BOUNDARY-START(64426082387)
            /*void */ SetAccess$2(/*System.Security.AccessControl.AccessControlType*/ accessType, /*System.Security.Principal.SecurityIdentifier*/ sid, /*System.Security.AccessControl.ObjectAccessRule*/ rule)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(64426082387);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
            }
            //--TRIMMABLE-BOUNDARY-END(64426082387)
            
            static $h = 1572947;
            static $f = 0b10010001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$ssa.SSA.CommonAcl; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(21476409427),
    {
      "r": 65537,
      "p": [
        {
          "n": "accessType",
          "p": 262227
        },
        {
          "n": "sid",
          "p": 393286
        },
        {
          "n": "accessMask",
          "p": 655361
        },
        {
          "n": "inheritanceFlags",
          "p": 1835091
        },
        {
          "n": "propagationFlags",
          "p": 2555987
        }
      ],
      "n": "AddAccess",
      "o": "@$1",
      "d": 1572947,
      "h": 21476409427,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(21476409427),
//--TRIMMABLE-BOUNDARY-START(17181442131),
    {
      "r": 65537,
      "p": [
        {
          "n": "accessType",
          "p": 262227
        },
        {
          "n": "sid",
          "p": 393286
        },
        {
          "n": "accessMask",
          "p": 655361
        },
        {
          "n": "inheritanceFlags",
          "p": 1835091
        },
        {
          "n": "propagationFlags",
          "p": 2555987
        },
        {
          "n": "objectFlags",
          "p": 2228307
        },
        {
          "n": "objectType",
          "p": 89784321
        },
        {
          "n": "inheritedObjectType",
          "p": 89784321
        }
      ],
      "n": "AddAccess",
      "d": 1572947,
      "h": 17181442131,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(17181442131),
//--TRIMMABLE-BOUNDARY-START(25771376723),
    {
      "r": 65537,
      "p": [
        {
          "n": "accessType",
          "p": 262227
        },
        {
          "n": "sid",
          "p": 393286
        },
        {
          "n": "rule",
          "p": 2097235
        }
      ],
      "n": "AddAccess",
      "o": "@$2",
      "d": 1572947,
      "h": 25771376723,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(25771376723),
//--TRIMMABLE-BOUNDARY-START(34361311315),
    {
      "r": 262145,
      "p": [
        {
          "n": "accessType",
          "p": 262227
        },
        {
          "n": "sid",
          "p": 393286
        },
        {
          "n": "accessMask",
          "p": 655361
        },
        {
          "n": "inheritanceFlags",
          "p": 1835091
        },
        {
          "n": "propagationFlags",
          "p": 2555987
        }
      ],
      "n": "RemoveAccess",
      "o": "@$1",
      "d": 1572947,
      "h": 34361311315,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(34361311315),
//--TRIMMABLE-BOUNDARY-START(30066344019),
    {
      "r": 262145,
      "p": [
        {
          "n": "accessType",
          "p": 262227
        },
        {
          "n": "sid",
          "p": 393286
        },
        {
          "n": "accessMask",
          "p": 655361
        },
        {
          "n": "inheritanceFlags",
          "p": 1835091
        },
        {
          "n": "propagationFlags",
          "p": 2555987
        },
        {
          "n": "objectFlags",
          "p": 2228307
        },
        {
          "n": "objectType",
          "p": 89784321
        },
        {
          "n": "inheritedObjectType",
          "p": 89784321
        }
      ],
      "n": "RemoveAccess",
      "d": 1572947,
      "h": 30066344019,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(30066344019),
//--TRIMMABLE-BOUNDARY-START(38656278611),
    {
      "r": 262145,
      "p": [
        {
          "n": "accessType",
          "p": 262227
        },
        {
          "n": "sid",
          "p": 393286
        },
        {
          "n": "rule",
          "p": 2097235
        }
      ],
      "n": "RemoveAccess",
      "o": "@$2",
      "d": 1572947,
      "h": 38656278611,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(38656278611),
//--TRIMMABLE-BOUNDARY-START(47246213203),
    {
      "r": 65537,
      "p": [
        {
          "n": "accessType",
          "p": 262227
        },
        {
          "n": "sid",
          "p": 393286
        },
        {
          "n": "accessMask",
          "p": 655361
        },
        {
          "n": "inheritanceFlags",
          "p": 1835091
        },
        {
          "n": "propagationFlags",
          "p": 2555987
        }
      ],
      "n": "RemoveAccessSpecific",
      "o": "@$1",
      "d": 1572947,
      "h": 47246213203,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(47246213203),
//--TRIMMABLE-BOUNDARY-START(42951245907),
    {
      "r": 65537,
      "p": [
        {
          "n": "accessType",
          "p": 262227
        },
        {
          "n": "sid",
          "p": 393286
        },
        {
          "n": "accessMask",
          "p": 655361
        },
        {
          "n": "inheritanceFlags",
          "p": 1835091
        },
        {
          "n": "propagationFlags",
          "p": 2555987
        },
        {
          "n": "objectFlags",
          "p": 2228307
        },
        {
          "n": "objectType",
          "p": 89784321
        },
        {
          "n": "inheritedObjectType",
          "p": 89784321
        }
      ],
      "n": "RemoveAccessSpecific",
      "d": 1572947,
      "h": 42951245907,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(42951245907),
//--TRIMMABLE-BOUNDARY-START(51541180499),
    {
      "r": 65537,
      "p": [
        {
          "n": "accessType",
          "p": 262227
        },
        {
          "n": "sid",
          "p": 393286
        },
        {
          "n": "rule",
          "p": 2097235
        }
      ],
      "n": "RemoveAccessSpecific",
      "o": "@$2",
      "d": 1572947,
      "h": 51541180499,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(51541180499),
//--TRIMMABLE-BOUNDARY-START(60131115091),
    {
      "r": 65537,
      "p": [
        {
          "n": "accessType",
          "p": 262227
        },
        {
          "n": "sid",
          "p": 393286
        },
        {
          "n": "accessMask",
          "p": 655361
        },
        {
          "n": "inheritanceFlags",
          "p": 1835091
        },
        {
          "n": "propagationFlags",
          "p": 2555987
        }
      ],
      "n": "SetAccess",
      "o": "@$1",
      "d": 1572947,
      "h": 60131115091,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(60131115091),
//--TRIMMABLE-BOUNDARY-START(55836147795),
    {
      "r": 65537,
      "p": [
        {
          "n": "accessType",
          "p": 262227
        },
        {
          "n": "sid",
          "p": 393286
        },
        {
          "n": "accessMask",
          "p": 655361
        },
        {
          "n": "inheritanceFlags",
          "p": 1835091
        },
        {
          "n": "propagationFlags",
          "p": 2555987
        },
        {
          "n": "objectFlags",
          "p": 2228307
        },
        {
          "n": "objectType",
          "p": 89784321
        },
        {
          "n": "inheritedObjectType",
          "p": 89784321
        }
      ],
      "n": "SetAccess",
      "d": 1572947,
      "h": 55836147795,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(55836147795),
//--TRIMMABLE-BOUNDARY-START(64426082387),
    {
      "r": 65537,
      "p": [
        {
          "n": "accessType",
          "p": 262227
        },
        {
          "n": "sid",
          "p": 393286
        },
        {
          "n": "rule",
          "p": 2097235
        }
      ],
      "n": "SetAccess",
      "o": "@$2",
      "d": 1572947,
      "h": 64426082387,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(64426082387)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296540243),
    {
      "p": [
        {
          "n": "isContainer",
          "p": 262145
        },
        {
          "n": "isDS",
          "p": 262145
        },
        {
          "n": "revision",
          "p": 393217
        },
        {
          "n": "capacity",
          "p": 655361
        }
      ],
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 1572947,
      "h": 4296540243,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296540243),
//--TRIMMABLE-BOUNDARY-START(8591507539),
    {
      "p": [
        {
          "n": "isContainer",
          "p": 262145
        },
        {
          "n": "isDS",
          "p": 262145
        },
        {
          "n": "capacity",
          "p": 655361
        }
      ],
      "n": ".ctor",
      "o": "$ctor$4",
      "d": 1572947,
      "h": 8591507539,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8591507539),
//--TRIMMABLE-BOUNDARY-START(12886474835),
    {
      "p": [
        {
          "n": "isContainer",
          "p": 262145
        },
        {
          "n": "isDS",
          "p": 262145
        },
        {
          "n": "rawAcl",
          "p": 2687059
        }
      ],
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 1572947,
      "h": 12886474835,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(12886474835)
  ],
  "h": 1572947
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.SC$1.ICollection, $.$$.SC$1.IEnumerable ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `System.Security.AccessControl.DiscretionaryAcl`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `System${separator}Security${separator}AccessControl${separator}DiscretionaryAcl`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1572947)
        
        

        //--TRIMMABLE-BOUNDARY-START(2949203)
        $asm.$cls(`$ssa.SSA.SystemAcl`, ($self) => class SystemAcl extends $.$ssa.SSA.CommonAcl
        {
            //--TRIMMABLE-BOUNDARY-START(4297916499)
            $ctor$3(/*bool*/ isContainer, /*bool*/ isDS, /*byte*/ revision, /*int*/ capacity)
            {
                super.$ctor$2();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4297916499);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4297916499)
            
            //--TRIMMABLE-BOUNDARY-START(8592883795)
            $ctor$4(/*bool*/ isContainer, /*bool*/ isDS, /*int*/ capacity)
            {
                super.$ctor$2();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(8592883795);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(8592883795)
            
            //--TRIMMABLE-BOUNDARY-START(12887851091)
            $ctor$5(/*bool*/ isContainer, /*bool*/ isDS, /*System.Security.AccessControl.RawAcl*/ rawAcl)
            {
                super.$ctor$2();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(12887851091);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(12887851091)
            
            //--TRIMMABLE-BOUNDARY-START(21477785683)
            /*void */ AddAudit$1(/*System.Security.AccessControl.AuditFlags*/ auditFlags, /*System.Security.Principal.SecurityIdentifier*/ sid, /*int*/ accessMask, /*System.Security.AccessControl.InheritanceFlags*/ inheritanceFlags, /*System.Security.AccessControl.PropagationFlags*/ propagationFlags)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21477785683);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
            }
            //--TRIMMABLE-BOUNDARY-END(21477785683)
            
            //--TRIMMABLE-BOUNDARY-START(17182818387)
            /*void */ AddAudit(/*System.Security.AccessControl.AuditFlags*/ auditFlags, /*System.Security.Principal.SecurityIdentifier*/ sid, /*int*/ accessMask, /*System.Security.AccessControl.InheritanceFlags*/ inheritanceFlags, /*System.Security.AccessControl.PropagationFlags*/ propagationFlags, /*System.Security.AccessControl.ObjectAceFlags*/ objectFlags, /*System.Guid*/ objectType, /*System.Guid*/ inheritedObjectType)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17182818387);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
            }
            //--TRIMMABLE-BOUNDARY-END(17182818387)
            
            //--TRIMMABLE-BOUNDARY-START(25772752979)
            /*void */ AddAudit$2(/*System.Security.Principal.SecurityIdentifier*/ sid, /*System.Security.AccessControl.ObjectAuditRule*/ rule)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25772752979);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
            }
            //--TRIMMABLE-BOUNDARY-END(25772752979)
            
            //--TRIMMABLE-BOUNDARY-START(34362687571)
            /*bool */ RemoveAudit$1(/*System.Security.AccessControl.AuditFlags*/ auditFlags, /*System.Security.Principal.SecurityIdentifier*/ sid, /*int*/ accessMask, /*System.Security.AccessControl.InheritanceFlags*/ inheritanceFlags, /*System.Security.AccessControl.PropagationFlags*/ propagationFlags)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(34362687571);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(34362687571)
            
            //--TRIMMABLE-BOUNDARY-START(30067720275)
            /*bool */ RemoveAudit(/*System.Security.AccessControl.AuditFlags*/ auditFlags, /*System.Security.Principal.SecurityIdentifier*/ sid, /*int*/ accessMask, /*System.Security.AccessControl.InheritanceFlags*/ inheritanceFlags, /*System.Security.AccessControl.PropagationFlags*/ propagationFlags, /*System.Security.AccessControl.ObjectAceFlags*/ objectFlags, /*System.Guid*/ objectType, /*System.Guid*/ inheritedObjectType)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(30067720275);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(30067720275)
            
            //--TRIMMABLE-BOUNDARY-START(38657654867)
            /*bool */ RemoveAudit$2(/*System.Security.Principal.SecurityIdentifier*/ sid, /*System.Security.AccessControl.ObjectAuditRule*/ rule)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(38657654867);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(38657654867)
            
            //--TRIMMABLE-BOUNDARY-START(47247589459)
            /*void */ RemoveAuditSpecific$1(/*System.Security.AccessControl.AuditFlags*/ auditFlags, /*System.Security.Principal.SecurityIdentifier*/ sid, /*int*/ accessMask, /*System.Security.AccessControl.InheritanceFlags*/ inheritanceFlags, /*System.Security.AccessControl.PropagationFlags*/ propagationFlags)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(47247589459);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
            }
            //--TRIMMABLE-BOUNDARY-END(47247589459)
            
            //--TRIMMABLE-BOUNDARY-START(42952622163)
            /*void */ RemoveAuditSpecific(/*System.Security.AccessControl.AuditFlags*/ auditFlags, /*System.Security.Principal.SecurityIdentifier*/ sid, /*int*/ accessMask, /*System.Security.AccessControl.InheritanceFlags*/ inheritanceFlags, /*System.Security.AccessControl.PropagationFlags*/ propagationFlags, /*System.Security.AccessControl.ObjectAceFlags*/ objectFlags, /*System.Guid*/ objectType, /*System.Guid*/ inheritedObjectType)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(42952622163);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
            }
            //--TRIMMABLE-BOUNDARY-END(42952622163)
            
            //--TRIMMABLE-BOUNDARY-START(51542556755)
            /*void */ RemoveAuditSpecific$2(/*System.Security.Principal.SecurityIdentifier*/ sid, /*System.Security.AccessControl.ObjectAuditRule*/ rule)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(51542556755);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
            }
            //--TRIMMABLE-BOUNDARY-END(51542556755)
            
            //--TRIMMABLE-BOUNDARY-START(60132491347)
            /*void */ SetAudit$1(/*System.Security.AccessControl.AuditFlags*/ auditFlags, /*System.Security.Principal.SecurityIdentifier*/ sid, /*int*/ accessMask, /*System.Security.AccessControl.InheritanceFlags*/ inheritanceFlags, /*System.Security.AccessControl.PropagationFlags*/ propagationFlags)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(60132491347);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
            }
            //--TRIMMABLE-BOUNDARY-END(60132491347)
            
            //--TRIMMABLE-BOUNDARY-START(55837524051)
            /*void */ SetAudit(/*System.Security.AccessControl.AuditFlags*/ auditFlags, /*System.Security.Principal.SecurityIdentifier*/ sid, /*int*/ accessMask, /*System.Security.AccessControl.InheritanceFlags*/ inheritanceFlags, /*System.Security.AccessControl.PropagationFlags*/ propagationFlags, /*System.Security.AccessControl.ObjectAceFlags*/ objectFlags, /*System.Guid*/ objectType, /*System.Guid*/ inheritedObjectType)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(55837524051);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
            }
            //--TRIMMABLE-BOUNDARY-END(55837524051)
            
            //--TRIMMABLE-BOUNDARY-START(64427458643)
            /*void */ SetAudit$2(/*System.Security.Principal.SecurityIdentifier*/ sid, /*System.Security.AccessControl.ObjectAuditRule*/ rule)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(64427458643);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
            }
            //--TRIMMABLE-BOUNDARY-END(64427458643)
            
            static $h = 2949203;
            static $f = 0b10010001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$ssa.SSA.CommonAcl; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(21477785683),
    {
      "r": 65537,
      "p": [
        {
          "n": "auditFlags",
          "p": 720979
        },
        {
          "n": "sid",
          "p": 393286
        },
        {
          "n": "accessMask",
          "p": 655361
        },
        {
          "n": "inheritanceFlags",
          "p": 1835091
        },
        {
          "n": "propagationFlags",
          "p": 2555987
        }
      ],
      "n": "AddAudit",
      "o": "@$1",
      "d": 2949203,
      "h": 21477785683,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(21477785683),
//--TRIMMABLE-BOUNDARY-START(17182818387),
    {
      "r": 65537,
      "p": [
        {
          "n": "auditFlags",
          "p": 720979
        },
        {
          "n": "sid",
          "p": 393286
        },
        {
          "n": "accessMask",
          "p": 655361
        },
        {
          "n": "inheritanceFlags",
          "p": 1835091
        },
        {
          "n": "propagationFlags",
          "p": 2555987
        },
        {
          "n": "objectFlags",
          "p": 2228307
        },
        {
          "n": "objectType",
          "p": 89784321
        },
        {
          "n": "inheritedObjectType",
          "p": 89784321
        }
      ],
      "n": "AddAudit",
      "d": 2949203,
      "h": 17182818387,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(17182818387),
//--TRIMMABLE-BOUNDARY-START(25772752979),
    {
      "r": 65537,
      "p": [
        {
          "n": "sid",
          "p": 393286
        },
        {
          "n": "rule",
          "p": 2293843
        }
      ],
      "n": "AddAudit",
      "o": "@$2",
      "d": 2949203,
      "h": 25772752979,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(25772752979),
//--TRIMMABLE-BOUNDARY-START(34362687571),
    {
      "r": 262145,
      "p": [
        {
          "n": "auditFlags",
          "p": 720979
        },
        {
          "n": "sid",
          "p": 393286
        },
        {
          "n": "accessMask",
          "p": 655361
        },
        {
          "n": "inheritanceFlags",
          "p": 1835091
        },
        {
          "n": "propagationFlags",
          "p": 2555987
        }
      ],
      "n": "RemoveAudit",
      "o": "@$1",
      "d": 2949203,
      "h": 34362687571,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(34362687571),
//--TRIMMABLE-BOUNDARY-START(30067720275),
    {
      "r": 262145,
      "p": [
        {
          "n": "auditFlags",
          "p": 720979
        },
        {
          "n": "sid",
          "p": 393286
        },
        {
          "n": "accessMask",
          "p": 655361
        },
        {
          "n": "inheritanceFlags",
          "p": 1835091
        },
        {
          "n": "propagationFlags",
          "p": 2555987
        },
        {
          "n": "objectFlags",
          "p": 2228307
        },
        {
          "n": "objectType",
          "p": 89784321
        },
        {
          "n": "inheritedObjectType",
          "p": 89784321
        }
      ],
      "n": "RemoveAudit",
      "d": 2949203,
      "h": 30067720275,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(30067720275),
//--TRIMMABLE-BOUNDARY-START(38657654867),
    {
      "r": 262145,
      "p": [
        {
          "n": "sid",
          "p": 393286
        },
        {
          "n": "rule",
          "p": 2293843
        }
      ],
      "n": "RemoveAudit",
      "o": "@$2",
      "d": 2949203,
      "h": 38657654867,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(38657654867),
//--TRIMMABLE-BOUNDARY-START(47247589459),
    {
      "r": 65537,
      "p": [
        {
          "n": "auditFlags",
          "p": 720979
        },
        {
          "n": "sid",
          "p": 393286
        },
        {
          "n": "accessMask",
          "p": 655361
        },
        {
          "n": "inheritanceFlags",
          "p": 1835091
        },
        {
          "n": "propagationFlags",
          "p": 2555987
        }
      ],
      "n": "RemoveAuditSpecific",
      "o": "@$1",
      "d": 2949203,
      "h": 47247589459,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(47247589459),
//--TRIMMABLE-BOUNDARY-START(42952622163),
    {
      "r": 65537,
      "p": [
        {
          "n": "auditFlags",
          "p": 720979
        },
        {
          "n": "sid",
          "p": 393286
        },
        {
          "n": "accessMask",
          "p": 655361
        },
        {
          "n": "inheritanceFlags",
          "p": 1835091
        },
        {
          "n": "propagationFlags",
          "p": 2555987
        },
        {
          "n": "objectFlags",
          "p": 2228307
        },
        {
          "n": "objectType",
          "p": 89784321
        },
        {
          "n": "inheritedObjectType",
          "p": 89784321
        }
      ],
      "n": "RemoveAuditSpecific",
      "d": 2949203,
      "h": 42952622163,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(42952622163),
//--TRIMMABLE-BOUNDARY-START(51542556755),
    {
      "r": 65537,
      "p": [
        {
          "n": "sid",
          "p": 393286
        },
        {
          "n": "rule",
          "p": 2293843
        }
      ],
      "n": "RemoveAuditSpecific",
      "o": "@$2",
      "d": 2949203,
      "h": 51542556755,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(51542556755),
//--TRIMMABLE-BOUNDARY-START(60132491347),
    {
      "r": 65537,
      "p": [
        {
          "n": "auditFlags",
          "p": 720979
        },
        {
          "n": "sid",
          "p": 393286
        },
        {
          "n": "accessMask",
          "p": 655361
        },
        {
          "n": "inheritanceFlags",
          "p": 1835091
        },
        {
          "n": "propagationFlags",
          "p": 2555987
        }
      ],
      "n": "SetAudit",
      "o": "@$1",
      "d": 2949203,
      "h": 60132491347,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(60132491347),
//--TRIMMABLE-BOUNDARY-START(55837524051),
    {
      "r": 65537,
      "p": [
        {
          "n": "auditFlags",
          "p": 720979
        },
        {
          "n": "sid",
          "p": 393286
        },
        {
          "n": "accessMask",
          "p": 655361
        },
        {
          "n": "inheritanceFlags",
          "p": 1835091
        },
        {
          "n": "propagationFlags",
          "p": 2555987
        },
        {
          "n": "objectFlags",
          "p": 2228307
        },
        {
          "n": "objectType",
          "p": 89784321
        },
        {
          "n": "inheritedObjectType",
          "p": 89784321
        }
      ],
      "n": "SetAudit",
      "d": 2949203,
      "h": 55837524051,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(55837524051),
//--TRIMMABLE-BOUNDARY-START(64427458643),
    {
      "r": 65537,
      "p": [
        {
          "n": "sid",
          "p": 393286
        },
        {
          "n": "rule",
          "p": 2293843
        }
      ],
      "n": "SetAudit",
      "o": "@$2",
      "d": 2949203,
      "h": 64427458643,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(64427458643)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4297916499),
    {
      "p": [
        {
          "n": "isContainer",
          "p": 262145
        },
        {
          "n": "isDS",
          "p": 262145
        },
        {
          "n": "revision",
          "p": 393217
        },
        {
          "n": "capacity",
          "p": 655361
        }
      ],
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 2949203,
      "h": 4297916499,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4297916499),
//--TRIMMABLE-BOUNDARY-START(8592883795),
    {
      "p": [
        {
          "n": "isContainer",
          "p": 262145
        },
        {
          "n": "isDS",
          "p": 262145
        },
        {
          "n": "capacity",
          "p": 655361
        }
      ],
      "n": ".ctor",
      "o": "$ctor$4",
      "d": 2949203,
      "h": 8592883795,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8592883795),
//--TRIMMABLE-BOUNDARY-START(12887851091),
    {
      "p": [
        {
          "n": "isContainer",
          "p": 262145
        },
        {
          "n": "isDS",
          "p": 262145
        },
        {
          "n": "rawAcl",
          "p": 2687059
        }
      ],
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 2949203,
      "h": 12887851091,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(12887851091)
  ],
  "h": 2949203
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.SC$1.ICollection, $.$$.SC$1.IEnumerable ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `System.Security.AccessControl.SystemAcl`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `System${separator}Security${separator}AccessControl${separator}SystemAcl`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2949203)
        
        

        //--TRIMMABLE-BOUNDARY-START(65619)
        $asm.$str(`$ssa.SSA.AccessControlActions`, ($self) => class AccessControlActions extends $.$$.S.Enum$$$($self, $.$$.S.UInt32)
        {
            static None = 0;
            static View = 1;
            static Change = 2;
            static $map;
            static get Map()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(65619);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.$map ??= 
                {
                    "None": 0n,
                    "View": 1n,
                    "Change": 2n
                };
            }
            //--TRIMMABLE-BOUNDARY-START(4295032915)
            //default constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295032915);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295032915)
            
            //--TRIMMABLE-BOUNDARY-START(4295032915)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$3();
            }
            //--TRIMMABLE-BOUNDARY-END(4295032915)
            
            static $h = 65619;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Enum; }
            static get $eut() { return $.$$.S.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "u": 655361,
  "l": [
//--TRIMMABLE-BOUNDARY-START(12884967507),
    {
      "t": 65619,
      "n": "None",
      "d": 65619,
      "h": 12884967507,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(12884967507),
//--TRIMMABLE-BOUNDARY-START(17179934803),
    {
      "t": 65619,
      "n": "View",
      "d": 65619,
      "h": 17179934803,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(17179934803),
//--TRIMMABLE-BOUNDARY-START(8590000211),
    {
      "t": 65619,
      "n": "Change",
      "d": 65619,
      "h": 8590000211,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(8590000211)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295032915),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 65619,
      "h": 4295032915,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295032915)
  ],
  "h": 65619,
  "a": [
    {
      "t": 81264641,
      "c": 4376231937
    }
  ]
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.S.IComparable, $.$$.S.ISpanFormattable, $.$$.S.IFormattable, $.$$.S.IConvertible ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `System.Security.AccessControl.AccessControlActions`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `System${separator}Security${separator}AccessControl${separator}AccessControlActions`; }
        });
        //--TRIMMABLE-BOUNDARY-END(65619)
        
        

        //--TRIMMABLE-BOUNDARY-START(131155)
        $asm.$str(`$ssa.SSA.AccessControlModification`, ($self) => class AccessControlModification extends $.$$.S.Enum$$$($self, $.$$.S.UInt32)
        {
            static Add = 0;
            static Set = 1;
            static Reset = 2;
            static Remove = 3;
            static RemoveAll = 4;
            static RemoveSpecific = 5;
            static $map;
            static get Map()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(131155);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.$map ??= 
                {
                    "Add": 0n,
                    "Set": 1n,
                    "Reset": 2n,
                    "Remove": 3n,
                    "RemoveAll": 4n,
                    "RemoveSpecific": 5n
                };
            }
            //--TRIMMABLE-BOUNDARY-START(4295098451)
            //default constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295098451);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295098451)
            
            //--TRIMMABLE-BOUNDARY-START(4295098451)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$3();
            }
            //--TRIMMABLE-BOUNDARY-END(4295098451)
            
            static $h = 131155;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Enum; }
            static get $eut() { return $.$$.S.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "u": 655361,
  "l": [
//--TRIMMABLE-BOUNDARY-START(8590065747),
    {
      "t": 131155,
      "n": "Add",
      "d": 131155,
      "h": 8590065747,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(8590065747),
//--TRIMMABLE-BOUNDARY-START(30064902227),
    {
      "t": 131155,
      "n": "Set",
      "d": 131155,
      "h": 30064902227,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(30064902227),
//--TRIMMABLE-BOUNDARY-START(25769934931),
    {
      "t": 131155,
      "n": "Reset",
      "d": 131155,
      "h": 25769934931,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(25769934931),
//--TRIMMABLE-BOUNDARY-START(12885033043),
    {
      "t": 131155,
      "n": "Remove",
      "d": 131155,
      "h": 12885033043,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(12885033043),
//--TRIMMABLE-BOUNDARY-START(17180000339),
    {
      "t": 131155,
      "n": "RemoveAll",
      "d": 131155,
      "h": 17180000339,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(17180000339),
//--TRIMMABLE-BOUNDARY-START(21474967635),
    {
      "t": 131155,
      "n": "RemoveSpecific",
      "d": 131155,
      "h": 21474967635,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(21474967635)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295098451),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 131155,
      "h": 4295098451,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295098451)
  ],
  "h": 131155
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.S.IComparable, $.$$.S.ISpanFormattable, $.$$.S.IFormattable, $.$$.S.IConvertible ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `System.Security.AccessControl.AccessControlModification`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `System${separator}Security${separator}AccessControl${separator}AccessControlModification`; }
        });
        //--TRIMMABLE-BOUNDARY-END(131155)
        
        

        //--TRIMMABLE-BOUNDARY-START(196691)
        $asm.$str(`$ssa.SSA.AccessControlSections`, ($self) => class AccessControlSections extends $.$$.S.Enum$$$($self, $.$$.S.UInt32)
        {
            static None = 0;
            static Audit = 1;
            static Access = 2;
            static Owner = 4;
            static Group = 8;
            static All = 15;
            static $map;
            static get Map()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(196691);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.$map ??= 
                {
                    "None": 0n,
                    "Audit": 1n,
                    "Access": 2n,
                    "Owner": 4n,
                    "Group": 8n,
                    "All": 15n
                };
            }
            //--TRIMMABLE-BOUNDARY-START(4295163987)
            //default constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295163987);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295163987)
            
            //--TRIMMABLE-BOUNDARY-START(4295163987)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$3();
            }
            //--TRIMMABLE-BOUNDARY-END(4295163987)
            
            static $h = 196691;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Enum; }
            static get $eut() { return $.$$.S.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "u": 655361,
  "l": [
//--TRIMMABLE-BOUNDARY-START(25770000467),
    {
      "t": 196691,
      "n": "None",
      "d": 196691,
      "h": 25770000467,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(25770000467),
//--TRIMMABLE-BOUNDARY-START(17180065875),
    {
      "t": 196691,
      "n": "Audit",
      "d": 196691,
      "h": 17180065875,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(17180065875),
//--TRIMMABLE-BOUNDARY-START(8590131283),
    {
      "t": 196691,
      "n": "Access",
      "d": 196691,
      "h": 8590131283,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(8590131283),
//--TRIMMABLE-BOUNDARY-START(30064967763),
    {
      "t": 196691,
      "n": "Owner",
      "d": 196691,
      "h": 30064967763,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(30064967763),
//--TRIMMABLE-BOUNDARY-START(21475033171),
    {
      "t": 196691,
      "n": "Group",
      "d": 196691,
      "h": 21475033171,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(21475033171),
//--TRIMMABLE-BOUNDARY-START(12885098579),
    {
      "t": 196691,
      "n": "All",
      "d": 196691,
      "h": 12885098579,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(12885098579)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295163987),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 196691,
      "h": 4295163987,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295163987)
  ],
  "h": 196691,
  "a": [
    {
      "t": 81264641,
      "c": 4376231937
    }
  ]
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.S.IComparable, $.$$.S.ISpanFormattable, $.$$.S.IFormattable, $.$$.S.IConvertible ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `System.Security.AccessControl.AccessControlSections`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `System${separator}Security${separator}AccessControl${separator}AccessControlSections`; }
        });
        //--TRIMMABLE-BOUNDARY-END(196691)
        
        

        //--TRIMMABLE-BOUNDARY-START(262227)
        $asm.$str(`$ssa.SSA.AccessControlType`, ($self) => class AccessControlType extends $.$$.S.Enum$$$($self, $.$$.S.UInt32)
        {
            static Allow = 0;
            static Deny = 1;
            static $map;
            static get Map()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(262227);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.$map ??= 
                {
                    "Allow": 0n,
                    "Deny": 1n
                };
            }
            //--TRIMMABLE-BOUNDARY-START(4295229523)
            //default constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295229523);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295229523)
            
            //--TRIMMABLE-BOUNDARY-START(4295229523)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$3();
            }
            //--TRIMMABLE-BOUNDARY-END(4295229523)
            
            static $h = 262227;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Enum; }
            static get $eut() { return $.$$.S.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "u": 655361,
  "l": [
//--TRIMMABLE-BOUNDARY-START(8590196819),
    {
      "t": 262227,
      "n": "Allow",
      "d": 262227,
      "h": 8590196819,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(8590196819),
//--TRIMMABLE-BOUNDARY-START(12885164115),
    {
      "t": 262227,
      "n": "Deny",
      "d": 262227,
      "h": 12885164115,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(12885164115)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295229523),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 262227,
      "h": 4295229523,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295229523)
  ],
  "h": 262227
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.S.IComparable, $.$$.S.ISpanFormattable, $.$$.S.IFormattable, $.$$.S.IConvertible ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `System.Security.AccessControl.AccessControlType`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `System${separator}Security${separator}AccessControl${separator}AccessControlType`; }
        });
        //--TRIMMABLE-BOUNDARY-END(262227)
        
        

        //--TRIMMABLE-BOUNDARY-START(524371)
        $asm.$str(`$ssa.SSA.AceFlags`, ($self) => class AceFlags extends $.$$.S.Enum$$$($self, $.$$.S.Byte)
        {
            static None = 0;
            static ObjectInherit = 1;
            static ContainerInherit = 2;
            static NoPropagateInherit = 4;
            static InheritOnly = 8;
            static InheritanceFlags = 15;
            static Inherited = 16;
            static SuccessfulAccess = 64;
            static FailedAccess = 128;
            static AuditFlags = 192;
            static $map;
            static get Map()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(524371);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.$map ??= 
                {
                    "None": 0n,
                    "ObjectInherit": 1n,
                    "ContainerInherit": 2n,
                    "NoPropagateInherit": 4n,
                    "InheritOnly": 8n,
                    "InheritanceFlags": 15n,
                    "Inherited": 16n,
                    "SuccessfulAccess": 64n,
                    "FailedAccess": 128n,
                    "AuditFlags": 192n
                };
            }
            //--TRIMMABLE-BOUNDARY-START(4295491667)
            //default constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295491667);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295491667)
            
            //--TRIMMABLE-BOUNDARY-START(4295491667)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$3();
            }
            //--TRIMMABLE-BOUNDARY-END(4295491667)
            
            static $h = 524371;
            static $z = 1;
            static $f = 0b100000011010001001;
            static $k = 4;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Enum; }
            static get $eut() { return $.$$.S.Byte; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "u": 393217,
  "l": [
//--TRIMMABLE-BOUNDARY-START(34360262739),
    {
      "t": 524371,
      "n": "None",
      "d": 524371,
      "h": 34360262739,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(34360262739),
//--TRIMMABLE-BOUNDARY-START(42950197331),
    {
      "t": 524371,
      "n": "ObjectInherit",
      "d": 524371,
      "h": 42950197331,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(42950197331),
//--TRIMMABLE-BOUNDARY-START(12885426259),
    {
      "t": 524371,
      "n": "ContainerInherit",
      "d": 524371,
      "h": 12885426259,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(12885426259),
//--TRIMMABLE-BOUNDARY-START(38655230035),
    {
      "t": 524371,
      "n": "NoPropagateInherit",
      "d": 524371,
      "h": 38655230035,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(38655230035),
//--TRIMMABLE-BOUNDARY-START(30065295443),
    {
      "t": 524371,
      "n": "InheritOnly",
      "d": 524371,
      "h": 30065295443,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(30065295443),
//--TRIMMABLE-BOUNDARY-START(21475360851),
    {
      "t": 524371,
      "n": "InheritanceFlags",
      "d": 524371,
      "h": 21475360851,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(21475360851),
//--TRIMMABLE-BOUNDARY-START(25770328147),
    {
      "t": 524371,
      "n": "Inherited",
      "d": 524371,
      "h": 25770328147,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(25770328147),
//--TRIMMABLE-BOUNDARY-START(47245164627),
    {
      "t": 524371,
      "n": "SuccessfulAccess",
      "d": 524371,
      "h": 47245164627,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(47245164627),
//--TRIMMABLE-BOUNDARY-START(17180393555),
    {
      "t": 524371,
      "n": "FailedAccess",
      "d": 524371,
      "h": 17180393555,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(17180393555),
//--TRIMMABLE-BOUNDARY-START(8590458963),
    {
      "t": 524371,
      "n": "AuditFlags",
      "d": 524371,
      "h": 8590458963,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(8590458963)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295491667),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 524371,
      "h": 4295491667,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295491667)
  ],
  "h": 524371,
  "a": [
    {
      "t": 81264641,
      "c": 4376231937
    }
  ]
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.S.IComparable, $.$$.S.ISpanFormattable, $.$$.S.IFormattable, $.$$.S.IConvertible ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `System.Security.AccessControl.AceFlags`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `System${separator}Security${separator}AccessControl${separator}AceFlags`; }
        });
        //--TRIMMABLE-BOUNDARY-END(524371)
        
        

        //--TRIMMABLE-BOUNDARY-START(589907)
        $asm.$str(`$ssa.SSA.AceQualifier`, ($self) => class AceQualifier extends $.$$.S.Enum$$$($self, $.$$.S.UInt32)
        {
            static AccessAllowed = 0;
            static AccessDenied = 1;
            static SystemAudit = 2;
            static SystemAlarm = 3;
            static $map;
            static get Map()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(589907);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.$map ??= 
                {
                    "AccessAllowed": 0n,
                    "AccessDenied": 1n,
                    "SystemAudit": 2n,
                    "SystemAlarm": 3n
                };
            }
            //--TRIMMABLE-BOUNDARY-START(4295557203)
            //default constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295557203);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295557203)
            
            //--TRIMMABLE-BOUNDARY-START(4295557203)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$3();
            }
            //--TRIMMABLE-BOUNDARY-END(4295557203)
            
            static $h = 589907;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Enum; }
            static get $eut() { return $.$$.S.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "u": 655361,
  "l": [
//--TRIMMABLE-BOUNDARY-START(8590524499),
    {
      "t": 589907,
      "n": "AccessAllowed",
      "d": 589907,
      "h": 8590524499,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(8590524499),
//--TRIMMABLE-BOUNDARY-START(12885491795),
    {
      "t": 589907,
      "n": "AccessDenied",
      "d": 589907,
      "h": 12885491795,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(12885491795),
//--TRIMMABLE-BOUNDARY-START(21475426387),
    {
      "t": 589907,
      "n": "SystemAudit",
      "d": 589907,
      "h": 21475426387,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(21475426387),
//--TRIMMABLE-BOUNDARY-START(17180459091),
    {
      "t": 589907,
      "n": "SystemAlarm",
      "d": 589907,
      "h": 17180459091,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(17180459091)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295557203),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 589907,
      "h": 4295557203,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295557203)
  ],
  "h": 589907
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.S.IComparable, $.$$.S.ISpanFormattable, $.$$.S.IFormattable, $.$$.S.IConvertible ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `System.Security.AccessControl.AceQualifier`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `System${separator}Security${separator}AccessControl${separator}AceQualifier`; }
        });
        //--TRIMMABLE-BOUNDARY-END(589907)
        
        

        //--TRIMMABLE-BOUNDARY-START(655443)
        $asm.$str(`$ssa.SSA.AceType`, ($self) => class AceType extends $.$$.S.Enum$$$($self, $.$$.S.Byte)
        {
            static AccessAllowed = 0;
            static AccessDenied = 1;
            static SystemAudit = 2;
            static SystemAlarm = 3;
            static AccessAllowedCompound = 4;
            static AccessAllowedObject = 5;
            static AccessDeniedObject = 6;
            static SystemAuditObject = 7;
            static SystemAlarmObject = 8;
            static AccessAllowedCallback = 9;
            static AccessDeniedCallback = 10;
            static AccessAllowedCallbackObject = 11;
            static AccessDeniedCallbackObject = 12;
            static SystemAuditCallback = 13;
            static SystemAlarmCallback = 14;
            static SystemAuditCallbackObject = 15;
            static MaxDefinedAceType = 16;
            static SystemAlarmCallbackObject = 16;
            static $map;
            static get Map()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(655443);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.$map ??= 
                {
                    "AccessAllowed": 0n,
                    "AccessDenied": 1n,
                    "SystemAudit": 2n,
                    "SystemAlarm": 3n,
                    "AccessAllowedCompound": 4n,
                    "AccessAllowedObject": 5n,
                    "AccessDeniedObject": 6n,
                    "SystemAuditObject": 7n,
                    "SystemAlarmObject": 8n,
                    "AccessAllowedCallback": 9n,
                    "AccessDeniedCallback": 10n,
                    "AccessAllowedCallbackObject": 11n,
                    "AccessDeniedCallbackObject": 12n,
                    "SystemAuditCallback": 13n,
                    "SystemAlarmCallback": 14n,
                    "SystemAuditCallbackObject": 15n,
                    "MaxDefinedAceType": 16n,
                    "SystemAlarmCallbackObject": 16n
                };
            }
            //--TRIMMABLE-BOUNDARY-START(4295622739)
            //default constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295622739);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295622739)
            
            //--TRIMMABLE-BOUNDARY-START(4295622739)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$3();
            }
            //--TRIMMABLE-BOUNDARY-END(4295622739)
            
            static $h = 655443;
            static $z = 1;
            static $f = 0b100000011010001001;
            static $k = 4;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Enum; }
            static get $eut() { return $.$$.S.Byte; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "u": 393217,
  "l": [
//--TRIMMABLE-BOUNDARY-START(8590590035),
    {
      "t": 655443,
      "n": "AccessAllowed",
      "d": 655443,
      "h": 8590590035,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(8590590035),
//--TRIMMABLE-BOUNDARY-START(30065426515),
    {
      "t": 655443,
      "n": "AccessDenied",
      "d": 655443,
      "h": 30065426515,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(30065426515),
//--TRIMMABLE-BOUNDARY-START(68720132179),
    {
      "t": 655443,
      "n": "SystemAudit",
      "d": 655443,
      "h": 68720132179,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(68720132179),
//--TRIMMABLE-BOUNDARY-START(51540262995),
    {
      "t": 655443,
      "n": "SystemAlarm",
      "d": 655443,
      "h": 51540262995,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(51540262995),
//--TRIMMABLE-BOUNDARY-START(21475491923),
    {
      "t": 655443,
      "n": "AccessAllowedCompound",
      "d": 655443,
      "h": 21475491923,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(21475491923),
//--TRIMMABLE-BOUNDARY-START(25770459219),
    {
      "t": 655443,
      "n": "AccessAllowedObject",
      "d": 655443,
      "h": 25770459219,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(25770459219),
//--TRIMMABLE-BOUNDARY-START(42950328403),
    {
      "t": 655443,
      "n": "AccessDeniedObject",
      "d": 655443,
      "h": 42950328403,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(42950328403),
//--TRIMMABLE-BOUNDARY-START(81605034067),
    {
      "t": 655443,
      "n": "SystemAuditObject",
      "d": 655443,
      "h": 81605034067,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(81605034067),
//--TRIMMABLE-BOUNDARY-START(64425164883),
    {
      "t": 655443,
      "n": "SystemAlarmObject",
      "d": 655443,
      "h": 64425164883,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(64425164883),
//--TRIMMABLE-BOUNDARY-START(12885557331),
    {
      "t": 655443,
      "n": "AccessAllowedCallback",
      "d": 655443,
      "h": 12885557331,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(12885557331),
//--TRIMMABLE-BOUNDARY-START(34360393811),
    {
      "t": 655443,
      "n": "AccessDeniedCallback",
      "d": 655443,
      "h": 34360393811,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(34360393811),
//--TRIMMABLE-BOUNDARY-START(17180524627),
    {
      "t": 655443,
      "n": "AccessAllowedCallbackObject",
      "d": 655443,
      "h": 17180524627,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(17180524627),
//--TRIMMABLE-BOUNDARY-START(38655361107),
    {
      "t": 655443,
      "n": "AccessDeniedCallbackObject",
      "d": 655443,
      "h": 38655361107,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(38655361107),
//--TRIMMABLE-BOUNDARY-START(73015099475),
    {
      "t": 655443,
      "n": "SystemAuditCallback",
      "d": 655443,
      "h": 73015099475,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(73015099475),
//--TRIMMABLE-BOUNDARY-START(55835230291),
    {
      "t": 655443,
      "n": "SystemAlarmCallback",
      "d": 655443,
      "h": 55835230291,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(55835230291),
//--TRIMMABLE-BOUNDARY-START(77310066771),
    {
      "t": 655443,
      "n": "SystemAuditCallbackObject",
      "d": 655443,
      "h": 77310066771,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(77310066771),
//--TRIMMABLE-BOUNDARY-START(47245295699),
    {
      "t": 655443,
      "n": "MaxDefinedAceType",
      "d": 655443,
      "h": 47245295699,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(47245295699),
//--TRIMMABLE-BOUNDARY-START(60130197587),
    {
      "t": 655443,
      "n": "SystemAlarmCallbackObject",
      "d": 655443,
      "h": 60130197587,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(60130197587)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295622739),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 655443,
      "h": 4295622739,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295622739)
  ],
  "h": 655443
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.S.IComparable, $.$$.S.ISpanFormattable, $.$$.S.IFormattable, $.$$.S.IConvertible ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `System.Security.AccessControl.AceType`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `System${separator}Security${separator}AccessControl${separator}AceType`; }
        });
        //--TRIMMABLE-BOUNDARY-END(655443)
        
        

        //--TRIMMABLE-BOUNDARY-START(720979)
        $asm.$str(`$ssa.SSA.AuditFlags`, ($self) => class AuditFlags extends $.$$.S.Enum$$$($self, $.$$.S.UInt32)
        {
            static None = 0;
            static Success = 1;
            static Failure = 2;
            static $map;
            static get Map()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(720979);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.$map ??= 
                {
                    "None": 0n,
                    "Success": 1n,
                    "Failure": 2n
                };
            }
            //--TRIMMABLE-BOUNDARY-START(4295688275)
            //default constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295688275);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295688275)
            
            //--TRIMMABLE-BOUNDARY-START(4295688275)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$3();
            }
            //--TRIMMABLE-BOUNDARY-END(4295688275)
            
            static $h = 720979;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Enum; }
            static get $eut() { return $.$$.S.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "u": 655361,
  "l": [
//--TRIMMABLE-BOUNDARY-START(12885622867),
    {
      "t": 720979,
      "n": "None",
      "d": 720979,
      "h": 12885622867,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(12885622867),
//--TRIMMABLE-BOUNDARY-START(17180590163),
    {
      "t": 720979,
      "n": "Success",
      "d": 720979,
      "h": 17180590163,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(17180590163),
//--TRIMMABLE-BOUNDARY-START(8590655571),
    {
      "t": 720979,
      "n": "Failure",
      "d": 720979,
      "h": 8590655571,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(8590655571)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295688275),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 720979,
      "h": 4295688275,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295688275)
  ],
  "h": 720979,
  "a": [
    {
      "t": 81264641,
      "c": 4376231937
    }
  ]
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.S.IComparable, $.$$.S.ISpanFormattable, $.$$.S.IFormattable, $.$$.S.IConvertible ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `System.Security.AccessControl.AuditFlags`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `System${separator}Security${separator}AccessControl${separator}AuditFlags`; }
        });
        //--TRIMMABLE-BOUNDARY-END(720979)
        
        

        //--TRIMMABLE-BOUNDARY-START(1376339)
        $asm.$str(`$ssa.SSA.CompoundAceType`, ($self) => class CompoundAceType extends $.$$.S.Enum$$$($self, $.$$.S.UInt32)
        {
            static Impersonation = 1;
            static $map;
            static get Map()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(1376339);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.$map ??= 
                {
                    "Impersonation": 1n
                };
            }
            //--TRIMMABLE-BOUNDARY-START(4296343635)
            //default constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296343635);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296343635)
            
            //--TRIMMABLE-BOUNDARY-START(4296343635)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$3();
            }
            //--TRIMMABLE-BOUNDARY-END(4296343635)
            
            static $h = 1376339;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Enum; }
            static get $eut() { return $.$$.S.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "u": 655361,
  "l": [
//--TRIMMABLE-BOUNDARY-START(8591310931),
    {
      "t": 1376339,
      "n": "Impersonation",
      "d": 1376339,
      "h": 8591310931,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(8591310931)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296343635),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 1376339,
      "h": 4296343635,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296343635)
  ],
  "h": 1376339
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.S.IComparable, $.$$.S.ISpanFormattable, $.$$.S.IFormattable, $.$$.S.IConvertible ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `System.Security.AccessControl.CompoundAceType`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `System${separator}Security${separator}AccessControl${separator}CompoundAceType`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1376339)
        
        

        //--TRIMMABLE-BOUNDARY-START(1441875)
        $asm.$str(`$ssa.SSA.ControlFlags`, ($self) => class ControlFlags extends $.$$.S.Enum$$$($self, $.$$.S.UInt32)
        {
            static None = 0;
            static OwnerDefaulted = 1;
            static GroupDefaulted = 2;
            static DiscretionaryAclPresent = 4;
            static DiscretionaryAclDefaulted = 8;
            static SystemAclPresent = 16;
            static SystemAclDefaulted = 32;
            static DiscretionaryAclUntrusted = 64;
            static ServerSecurity = 128;
            static DiscretionaryAclAutoInheritRequired = 256;
            static SystemAclAutoInheritRequired = 512;
            static DiscretionaryAclAutoInherited = 1024;
            static SystemAclAutoInherited = 2048;
            static DiscretionaryAclProtected = 4096;
            static SystemAclProtected = 8192;
            static RMControlValid = 16384;
            static SelfRelative = 32768;
            static $map;
            static get Map()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(1441875);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.$map ??= 
                {
                    "None": 0n,
                    "OwnerDefaulted": 1n,
                    "GroupDefaulted": 2n,
                    "DiscretionaryAclPresent": 4n,
                    "DiscretionaryAclDefaulted": 8n,
                    "SystemAclPresent": 16n,
                    "SystemAclDefaulted": 32n,
                    "DiscretionaryAclUntrusted": 64n,
                    "ServerSecurity": 128n,
                    "DiscretionaryAclAutoInheritRequired": 256n,
                    "SystemAclAutoInheritRequired": 512n,
                    "DiscretionaryAclAutoInherited": 1024n,
                    "SystemAclAutoInherited": 2048n,
                    "DiscretionaryAclProtected": 4096n,
                    "SystemAclProtected": 8192n,
                    "RMControlValid": 16384n,
                    "SelfRelative": 32768n
                };
            }
            //--TRIMMABLE-BOUNDARY-START(4296409171)
            //default constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296409171);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296409171)
            
            //--TRIMMABLE-BOUNDARY-START(4296409171)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$3();
            }
            //--TRIMMABLE-BOUNDARY-END(4296409171)
            
            static $h = 1441875;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Enum; }
            static get $eut() { return $.$$.S.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "u": 655361,
  "l": [
//--TRIMMABLE-BOUNDARY-START(38656147539),
    {
      "t": 1441875,
      "n": "None",
      "d": 1441875,
      "h": 38656147539,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(38656147539),
//--TRIMMABLE-BOUNDARY-START(42951114835),
    {
      "t": 1441875,
      "n": "OwnerDefaulted",
      "d": 1441875,
      "h": 42951114835,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(42951114835),
//--TRIMMABLE-BOUNDARY-START(34361180243),
    {
      "t": 1441875,
      "n": "GroupDefaulted",
      "d": 1441875,
      "h": 34361180243,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(34361180243),
//--TRIMMABLE-BOUNDARY-START(21476278355),
    {
      "t": 1441875,
      "n": "DiscretionaryAclPresent",
      "d": 1441875,
      "h": 21476278355,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(21476278355),
//--TRIMMABLE-BOUNDARY-START(17181311059),
    {
      "t": 1441875,
      "n": "DiscretionaryAclDefaulted",
      "d": 1441875,
      "h": 17181311059,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(17181311059),
//--TRIMMABLE-BOUNDARY-START(73015885907),
    {
      "t": 1441875,
      "n": "SystemAclPresent",
      "d": 1441875,
      "h": 73015885907,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(73015885907),
//--TRIMMABLE-BOUNDARY-START(68720918611),
    {
      "t": 1441875,
      "n": "SystemAclDefaulted",
      "d": 1441875,
      "h": 68720918611,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(68720918611),
//--TRIMMABLE-BOUNDARY-START(30066212947),
    {
      "t": 1441875,
      "n": "DiscretionaryAclUntrusted",
      "d": 1441875,
      "h": 30066212947,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(30066212947),
//--TRIMMABLE-BOUNDARY-START(55836016723),
    {
      "t": 1441875,
      "n": "ServerSecurity",
      "d": 1441875,
      "h": 55836016723,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(55836016723),
//--TRIMMABLE-BOUNDARY-START(12886343763),
    {
      "t": 1441875,
      "n": "DiscretionaryAclAutoInheritRequired",
      "d": 1441875,
      "h": 12886343763,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(12886343763),
//--TRIMMABLE-BOUNDARY-START(64425951315),
    {
      "t": 1441875,
      "n": "SystemAclAutoInheritRequired",
      "d": 1441875,
      "h": 64425951315,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(64425951315),
//--TRIMMABLE-BOUNDARY-START(8591376467),
    {
      "t": 1441875,
      "n": "DiscretionaryAclAutoInherited",
      "d": 1441875,
      "h": 8591376467,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(8591376467),
//--TRIMMABLE-BOUNDARY-START(60130984019),
    {
      "t": 1441875,
      "n": "SystemAclAutoInherited",
      "d": 1441875,
      "h": 60130984019,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(60130984019),
//--TRIMMABLE-BOUNDARY-START(25771245651),
    {
      "t": 1441875,
      "n": "DiscretionaryAclProtected",
      "d": 1441875,
      "h": 25771245651,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(25771245651),
//--TRIMMABLE-BOUNDARY-START(77310853203),
    {
      "t": 1441875,
      "n": "SystemAclProtected",
      "d": 1441875,
      "h": 77310853203,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(77310853203),
//--TRIMMABLE-BOUNDARY-START(47246082131),
    {
      "t": 1441875,
      "n": "RMControlValid",
      "d": 1441875,
      "h": 47246082131,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(47246082131),
//--TRIMMABLE-BOUNDARY-START(51541049427),
    {
      "t": 1441875,
      "n": "SelfRelative",
      "d": 1441875,
      "h": 51541049427,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(51541049427)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296409171),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 1441875,
      "h": 4296409171,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296409171)
  ],
  "h": 1441875,
  "a": [
    {
      "t": 81264641,
      "c": 4376231937
    }
  ]
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.S.IComparable, $.$$.S.ISpanFormattable, $.$$.S.IFormattable, $.$$.S.IConvertible ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `System.Security.AccessControl.ControlFlags`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `System${separator}Security${separator}AccessControl${separator}ControlFlags`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1441875)
        
        

        //--TRIMMABLE-BOUNDARY-START(1835091)
        $asm.$str(`$ssa.SSA.InheritanceFlags`, ($self) => class InheritanceFlags extends $.$$.S.Enum$$$($self, $.$$.S.UInt32)
        {
            static None = 0;
            static ContainerInherit = 1;
            static ObjectInherit = 2;
            static $map;
            static get Map()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(1835091);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.$map ??= 
                {
                    "None": 0n,
                    "ContainerInherit": 1n,
                    "ObjectInherit": 2n
                };
            }
            //--TRIMMABLE-BOUNDARY-START(4296802387)
            //default constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296802387);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296802387)
            
            //--TRIMMABLE-BOUNDARY-START(4296802387)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$3();
            }
            //--TRIMMABLE-BOUNDARY-END(4296802387)
            
            static $h = 1835091;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Enum; }
            static get $eut() { return $.$$.S.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "u": 655361,
  "l": [
//--TRIMMABLE-BOUNDARY-START(12886736979),
    {
      "t": 1835091,
      "n": "None",
      "d": 1835091,
      "h": 12886736979,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(12886736979),
//--TRIMMABLE-BOUNDARY-START(8591769683),
    {
      "t": 1835091,
      "n": "ContainerInherit",
      "d": 1835091,
      "h": 8591769683,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(8591769683),
//--TRIMMABLE-BOUNDARY-START(17181704275),
    {
      "t": 1835091,
      "n": "ObjectInherit",
      "d": 1835091,
      "h": 17181704275,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(17181704275)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296802387),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 1835091,
      "h": 4296802387,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296802387)
  ],
  "h": 1835091,
  "a": [
    {
      "t": 81264641,
      "c": 4376231937
    }
  ]
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.S.IComparable, $.$$.S.ISpanFormattable, $.$$.S.IFormattable, $.$$.S.IConvertible ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `System.Security.AccessControl.InheritanceFlags`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `System${separator}Security${separator}AccessControl${separator}InheritanceFlags`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1835091)
        
        

        //--TRIMMABLE-BOUNDARY-START(2228307)
        $asm.$str(`$ssa.SSA.ObjectAceFlags`, ($self) => class ObjectAceFlags extends $.$$.S.Enum$$$($self, $.$$.S.UInt32)
        {
            static None = 0;
            static ObjectAceTypePresent = 1;
            static InheritedObjectAceTypePresent = 2;
            static $map;
            static get Map()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(2228307);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.$map ??= 
                {
                    "None": 0n,
                    "ObjectAceTypePresent": 1n,
                    "InheritedObjectAceTypePresent": 2n
                };
            }
            //--TRIMMABLE-BOUNDARY-START(4297195603)
            //default constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4297195603);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4297195603)
            
            //--TRIMMABLE-BOUNDARY-START(4297195603)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$3();
            }
            //--TRIMMABLE-BOUNDARY-END(4297195603)
            
            static $h = 2228307;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Enum; }
            static get $eut() { return $.$$.S.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "u": 655361,
  "l": [
//--TRIMMABLE-BOUNDARY-START(12887130195),
    {
      "t": 2228307,
      "n": "None",
      "d": 2228307,
      "h": 12887130195,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(12887130195),
//--TRIMMABLE-BOUNDARY-START(17182097491),
    {
      "t": 2228307,
      "n": "ObjectAceTypePresent",
      "d": 2228307,
      "h": 17182097491,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(17182097491),
//--TRIMMABLE-BOUNDARY-START(8592162899),
    {
      "t": 2228307,
      "n": "InheritedObjectAceTypePresent",
      "d": 2228307,
      "h": 8592162899,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(8592162899)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4297195603),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 2228307,
      "h": 4297195603,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4297195603)
  ],
  "h": 2228307,
  "a": [
    {
      "t": 81264641,
      "c": 4376231937
    }
  ]
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.S.IComparable, $.$$.S.ISpanFormattable, $.$$.S.IFormattable, $.$$.S.IConvertible ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `System.Security.AccessControl.ObjectAceFlags`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `System${separator}Security${separator}AccessControl${separator}ObjectAceFlags`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2228307)
        
        

        //--TRIMMABLE-BOUNDARY-START(2555987)
        $asm.$str(`$ssa.SSA.PropagationFlags`, ($self) => class PropagationFlags extends $.$$.S.Enum$$$($self, $.$$.S.UInt32)
        {
            static None = 0;
            static NoPropagateInherit = 1;
            static InheritOnly = 2;
            static $map;
            static get Map()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(2555987);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.$map ??= 
                {
                    "None": 0n,
                    "NoPropagateInherit": 1n,
                    "InheritOnly": 2n
                };
            }
            //--TRIMMABLE-BOUNDARY-START(4297523283)
            //default constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4297523283);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4297523283)
            
            //--TRIMMABLE-BOUNDARY-START(4297523283)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$3();
            }
            //--TRIMMABLE-BOUNDARY-END(4297523283)
            
            static $h = 2555987;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Enum; }
            static get $eut() { return $.$$.S.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "u": 655361,
  "l": [
//--TRIMMABLE-BOUNDARY-START(12887457875),
    {
      "t": 2555987,
      "n": "None",
      "d": 2555987,
      "h": 12887457875,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(12887457875),
//--TRIMMABLE-BOUNDARY-START(17182425171),
    {
      "t": 2555987,
      "n": "NoPropagateInherit",
      "d": 2555987,
      "h": 17182425171,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(17182425171),
//--TRIMMABLE-BOUNDARY-START(8592490579),
    {
      "t": 2555987,
      "n": "InheritOnly",
      "d": 2555987,
      "h": 8592490579,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(8592490579)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4297523283),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 2555987,
      "h": 4297523283,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4297523283)
  ],
  "h": 2555987,
  "a": [
    {
      "t": 81264641,
      "c": 4376231937
    }
  ]
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.S.IComparable, $.$$.S.ISpanFormattable, $.$$.S.IFormattable, $.$$.S.IConvertible ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `System.Security.AccessControl.PropagationFlags`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `System${separator}Security${separator}AccessControl${separator}PropagationFlags`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2555987)
        
        

        //--TRIMMABLE-BOUNDARY-START(2818131)
        $asm.$str(`$ssa.SSA.ResourceType`, ($self) => class ResourceType extends $.$$.S.Enum$$$($self, $.$$.S.UInt32)
        {
            static Unknown = 0;
            static FileObject = 1;
            static Service = 2;
            static Printer = 3;
            static RegistryKey = 4;
            static LMShare = 5;
            static KernelObject = 6;
            static WindowObject = 7;
            static DSObject = 8;
            static DSObjectAll = 9;
            static ProviderDefined = 10;
            static WmiGuidObject = 11;
            static RegistryWow6432Key = 12;
            static $map;
            static get Map()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(2818131);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.$map ??= 
                {
                    "Unknown": 0n,
                    "FileObject": 1n,
                    "Service": 2n,
                    "Printer": 3n,
                    "RegistryKey": 4n,
                    "LMShare": 5n,
                    "KernelObject": 6n,
                    "WindowObject": 7n,
                    "DSObject": 8n,
                    "DSObjectAll": 9n,
                    "ProviderDefined": 10n,
                    "WmiGuidObject": 11n,
                    "RegistryWow6432Key": 12n
                };
            }
            //--TRIMMABLE-BOUNDARY-START(4297785427)
            //default constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4297785427);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4297785427)
            
            //--TRIMMABLE-BOUNDARY-START(4297785427)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$3();
            }
            //--TRIMMABLE-BOUNDARY-END(4297785427)
            
            static $h = 2818131;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Enum; }
            static get $eut() { return $.$$.S.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "u": 655361,
  "l": [
//--TRIMMABLE-BOUNDARY-START(51542425683),
    {
      "t": 2818131,
      "n": "Unknown",
      "d": 2818131,
      "h": 51542425683,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(51542425683),
//--TRIMMABLE-BOUNDARY-START(17182687315),
    {
      "t": 2818131,
      "n": "FileObject",
      "d": 2818131,
      "h": 17182687315,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(17182687315),
//--TRIMMABLE-BOUNDARY-START(47247458387),
    {
      "t": 2818131,
      "n": "Service",
      "d": 2818131,
      "h": 47247458387,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(47247458387),
//--TRIMMABLE-BOUNDARY-START(30067589203),
    {
      "t": 2818131,
      "n": "Printer",
      "d": 2818131,
      "h": 30067589203,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(30067589203),
//--TRIMMABLE-BOUNDARY-START(38657523795),
    {
      "t": 2818131,
      "n": "RegistryKey",
      "d": 2818131,
      "h": 38657523795,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(38657523795),
//--TRIMMABLE-BOUNDARY-START(25772621907),
    {
      "t": 2818131,
      "n": "LMShare",
      "d": 2818131,
      "h": 25772621907,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(25772621907),
//--TRIMMABLE-BOUNDARY-START(21477654611),
    {
      "t": 2818131,
      "n": "KernelObject",
      "d": 2818131,
      "h": 21477654611,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(21477654611),
//--TRIMMABLE-BOUNDARY-START(55837392979),
    {
      "t": 2818131,
      "n": "WindowObject",
      "d": 2818131,
      "h": 55837392979,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(55837392979),
//--TRIMMABLE-BOUNDARY-START(8592752723),
    {
      "t": 2818131,
      "n": "DSObject",
      "d": 2818131,
      "h": 8592752723,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(8592752723),
//--TRIMMABLE-BOUNDARY-START(12887720019),
    {
      "t": 2818131,
      "n": "DSObjectAll",
      "d": 2818131,
      "h": 12887720019,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(12887720019),
//--TRIMMABLE-BOUNDARY-START(34362556499),
    {
      "t": 2818131,
      "n": "ProviderDefined",
      "d": 2818131,
      "h": 34362556499,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(34362556499),
//--TRIMMABLE-BOUNDARY-START(60132360275),
    {
      "t": 2818131,
      "n": "WmiGuidObject",
      "d": 2818131,
      "h": 60132360275,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(60132360275),
//--TRIMMABLE-BOUNDARY-START(42952491091),
    {
      "t": 2818131,
      "n": "RegistryWow6432Key",
      "d": 2818131,
      "h": 42952491091,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(42952491091)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4297785427),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 2818131,
      "h": 4297785427,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4297785427)
  ],
  "h": 2818131
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.S.IComparable, $.$$.S.ISpanFormattable, $.$$.S.IFormattable, $.$$.S.IConvertible ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `System.Security.AccessControl.ResourceType`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `System${separator}Security${separator}AccessControl${separator}ResourceType`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2818131)
        
        

        //--TRIMMABLE-BOUNDARY-START(2883667)
        $asm.$str(`$ssa.SSA.SecurityInfos`, ($self) => class SecurityInfos extends $.$$.S.Enum$$$($self, $.$$.S.UInt32)
        {
            static Owner = 1;
            static Group = 2;
            static DiscretionaryAcl = 4;
            static SystemAcl = 8;
            static $map;
            static get Map()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(2883667);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.$map ??= 
                {
                    "Owner": 1n,
                    "Group": 2n,
                    "DiscretionaryAcl": 4n,
                    "SystemAcl": 8n
                };
            }
            //--TRIMMABLE-BOUNDARY-START(4297850963)
            //default constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4297850963);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4297850963)
            
            //--TRIMMABLE-BOUNDARY-START(4297850963)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$3();
            }
            //--TRIMMABLE-BOUNDARY-END(4297850963)
            
            static $h = 2883667;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Enum; }
            static get $eut() { return $.$$.S.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "u": 655361,
  "l": [
//--TRIMMABLE-BOUNDARY-START(17182752851),
    {
      "t": 2883667,
      "n": "Owner",
      "d": 2883667,
      "h": 17182752851,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(17182752851),
//--TRIMMABLE-BOUNDARY-START(12887785555),
    {
      "t": 2883667,
      "n": "Group",
      "d": 2883667,
      "h": 12887785555,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(12887785555),
//--TRIMMABLE-BOUNDARY-START(8592818259),
    {
      "t": 2883667,
      "n": "DiscretionaryAcl",
      "d": 2883667,
      "h": 8592818259,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(8592818259),
//--TRIMMABLE-BOUNDARY-START(21477720147),
    {
      "t": 2883667,
      "n": "SystemAcl",
      "d": 2883667,
      "h": 21477720147,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(21477720147)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4297850963),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 2883667,
      "h": 4297850963,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4297850963)
  ],
  "h": 2883667,
  "a": [
    {
      "t": 81264641,
      "c": 4376231937
    }
  ]
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.S.IComparable, $.$$.S.ISpanFormattable, $.$$.S.IFormattable, $.$$.S.IConvertible ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `System.Security.AccessControl.SecurityInfos`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `System${separator}Security${separator}AccessControl${separator}SecurityInfos`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2883667)
        
        

        //--TRIMMABLE-BOUNDARY-START(1048659)
        $asm.$cls(`$ssa.SSA.CommonAce`, ($self) => class CommonAce extends $.$ssa.SSA.QualifiedAce
        {
            //--TRIMMABLE-BOUNDARY-START(4296015955)
            $ctor$4(/*System.Security.AccessControl.AceFlags*/ flags, /*System.Security.AccessControl.AceQualifier*/ qualifier, /*int*/ accessMask, /*System.Security.Principal.SecurityIdentifier*/ sid, /*bool*/ isCallback, /*byte[]?*/ opaque)
            {
                super.$ctor$3();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4296015955);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296015955)
            
            //--TRIMMABLE-BOUNDARY-START(8590983251)
            /*int */ get BinaryLength()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17180917843);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(8590983251)
            
            //--TRIMMABLE-BOUNDARY-START(21475885139)
            /*void */ GetBinaryForm(/*byte[]*/ binaryForm, /*int*/ offset)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21475885139);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
            }
            //--TRIMMABLE-BOUNDARY-END(21475885139)
            
            //--TRIMMABLE-BOUNDARY-START(25770852435)
            static /*int */ MaxOpaqueLength(/*bool*/ isCallback)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25770852435);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(25770852435)
            
            static $h = 1048659;
            static $f = 0b10010001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$ssa.SSA.QualifiedAce; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(8590983251),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 17180917843,
        "f": 50364417
      },
      "n": "BinaryLength",
      "d": 1048659,
      "h": 8590983251,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(8590983251)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(21475885139),
    {
      "r": 65537,
      "p": [
        {
          "n": "binaryForm",
          "p": $.$typeArray($.$$.S.Byte).$h
        },
        {
          "n": "offset",
          "p": 655361
        }
      ],
      "n": "GetBinaryForm",
      "d": 1048659,
      "h": 21475885139,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(21475885139),
//--TRIMMABLE-BOUNDARY-START(25770852435),
    {
      "r": 655361,
      "p": [
        {
          "n": "isCallback",
          "p": 262145
        }
      ],
      "n": "MaxOpaqueLength",
      "d": 1048659,
      "h": 25770852435,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(25770852435)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296015955),
    {
      "p": [
        {
          "n": "flags",
          "p": 524371
        },
        {
          "n": "qualifier",
          "p": 589907
        },
        {
          "n": "accessMask",
          "p": 655361
        },
        {
          "n": "sid",
          "p": 393286
        },
        {
          "n": "isCallback",
          "p": 262145
        },
        {
          "n": "opaque",
          "p": $.$typeArray($.$$.S.Byte).$h
        }
      ],
      "n": ".ctor",
      "o": "$ctor$4",
      "d": 1048659,
      "h": 4296015955,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296015955)
  ],
  "h": 1048659
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `System.Security.AccessControl.CommonAce`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `System${separator}Security${separator}AccessControl${separator}CommonAce`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1048659)
        
        

        //--TRIMMABLE-BOUNDARY-START(2162771)
        $asm.$cls(`$ssa.SSA.ObjectAce`, ($self) => class ObjectAce extends $.$ssa.SSA.QualifiedAce
        {
            //--TRIMMABLE-BOUNDARY-START(4297130067)
            $ctor$4(/*System.Security.AccessControl.AceFlags*/ aceFlags, /*System.Security.AccessControl.AceQualifier*/ qualifier, /*int*/ accessMask, /*System.Security.Principal.SecurityIdentifier*/ sid, /*System.Security.AccessControl.ObjectAceFlags*/ flags, /*System.Guid*/ type, /*System.Guid*/ inheritedType, /*bool*/ isCallback, /*byte[]?*/ opaque)
            {
                super.$ctor$3();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4297130067);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4297130067)
            
            //--TRIMMABLE-BOUNDARY-START(8592097363)
            /*int */ get BinaryLength()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17182031955);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(8592097363)
            
            //--TRIMMABLE-BOUNDARY-START(51541770323)
            /*System.Guid */ get InheritedObjectAceType()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25771966547);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Guid */ set InheritedObjectAceType(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(73016606803);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(51541770323)
            
            //--TRIMMABLE-BOUNDARY-START(60131704915)
            /*System.Security.AccessControl.ObjectAceFlags */ get ObjectAceFlags()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(34361901139);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Security.AccessControl.ObjectAceFlags */ set ObjectAceFlags(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(81606541395);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(60131704915)
            
            //--TRIMMABLE-BOUNDARY-START(64426672211)
            /*System.Guid */ get ObjectAceType()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(42951835731);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Guid */ set ObjectAceType(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(90196475987);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(64426672211)
            
            //--TRIMMABLE-BOUNDARY-START(47246803027)
            /*void */ GetBinaryForm(/*byte[]*/ binaryForm, /*int*/ offset)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(47246803027);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
            }
            //--TRIMMABLE-BOUNDARY-END(47246803027)
            
            //--TRIMMABLE-BOUNDARY-START(55836737619)
            static /*int */ MaxOpaqueLength(/*bool*/ isCallback)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(55836737619);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(55836737619)
            
            static $h = 2162771;
            static $f = 0b10010001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$ssa.SSA.QualifiedAce; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(8592097363),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 17182031955,
        "f": 50364417
      },
      "n": "BinaryLength",
      "d": 2162771,
      "h": 8592097363,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(8592097363),
//--TRIMMABLE-BOUNDARY-START(51541770323),
    {
      "p": 89784321,
      "g": {
        "r": 0,
        "d": 0,
        "h": 25771966547,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 73016606803,
        "f": 83886081
      },
      "n": "InheritedObjectAceType",
      "d": 2162771,
      "h": 51541770323,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(51541770323),
//--TRIMMABLE-BOUNDARY-START(60131704915),
    {
      "p": 2228307,
      "g": {
        "r": 0,
        "d": 0,
        "h": 34361901139,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 81606541395,
        "f": 83886081
      },
      "n": "ObjectAceFlags",
      "d": 2162771,
      "h": 60131704915,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(60131704915),
//--TRIMMABLE-BOUNDARY-START(64426672211),
    {
      "p": 89784321,
      "g": {
        "r": 0,
        "d": 0,
        "h": 42951835731,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 90196475987,
        "f": 83886081
      },
      "n": "ObjectAceType",
      "d": 2162771,
      "h": 64426672211,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(64426672211)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(47246803027),
    {
      "r": 65537,
      "p": [
        {
          "n": "binaryForm",
          "p": $.$typeArray($.$$.S.Byte).$h
        },
        {
          "n": "offset",
          "p": 655361
        }
      ],
      "n": "GetBinaryForm",
      "d": 2162771,
      "h": 47246803027,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(47246803027),
//--TRIMMABLE-BOUNDARY-START(55836737619),
    {
      "r": 655361,
      "p": [
        {
          "n": "isCallback",
          "p": 262145
        }
      ],
      "n": "MaxOpaqueLength",
      "d": 2162771,
      "h": 55836737619,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(55836737619)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4297130067),
    {
      "p": [
        {
          "n": "aceFlags",
          "p": 524371
        },
        {
          "n": "qualifier",
          "p": 589907
        },
        {
          "n": "accessMask",
          "p": 655361
        },
        {
          "n": "sid",
          "p": 393286
        },
        {
          "n": "flags",
          "p": 2228307
        },
        {
          "n": "type",
          "p": 89784321
        },
        {
          "n": "inheritedType",
          "p": 89784321
        },
        {
          "n": "isCallback",
          "p": 262145
        },
        {
          "n": "opaque",
          "p": $.$typeArray($.$$.S.Byte).$h
        }
      ],
      "n": ".ctor",
      "o": "$ctor$4",
      "d": 2162771,
      "h": 4297130067,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4297130067)
  ],
  "h": 2162771
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `System.Security.AccessControl.ObjectAce`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `System${separator}Security${separator}AccessControl${separator}ObjectAce`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2162771)
        
        

        //--TRIMMABLE-BOUNDARY-START(2490451)
        $asm.$cls(`$ssa.SSA.PrivilegeNotHeldException`, ($self) => class PrivilegeNotHeldException extends $.$$.S.UnauthorizedAccessException
        {
            //--TRIMMABLE-BOUNDARY-START(4297457747)
            $ctor$13()
            {
                super.$ctor$9();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4297457747);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4297457747)
            
            //--TRIMMABLE-BOUNDARY-START(12887392339)
            $ctor$15(/*string?*/ privilege)
            {
                super.$ctor$9();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(12887392339);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(12887392339)
            
            //--TRIMMABLE-BOUNDARY-START(8592425043)
            $ctor$14(/*string?*/ privilege, /*System.Exception?*/ inner)
            {
                super.$ctor$9();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(8592425043);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(8592425043)
            
            //--TRIMMABLE-BOUNDARY-START(30067261523)
            /*string? */ get PrivilegeName()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21477326931);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(30067261523)
            
            //--TRIMMABLE-BOUNDARY-START(25772294227)
            /*void */ GetObjectData(/*System.Runtime.Serialization.SerializationInfo*/ info, /*System.Runtime.Serialization.StreamingContext*/ context)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25772294227);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
            }
            //--TRIMMABLE-BOUNDARY-END(25772294227)
            
            //--TRIMMABLE-BOUNDARY-START(4297457747)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(4297457747)
            
            static $h = 2490451;
            static $f = 0b10010001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.UnauthorizedAccessException; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "h": 2490451
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.SRS.ISerializable ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `System.Security.AccessControl.PrivilegeNotHeldException`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `System${separator}Security${separator}AccessControl${separator}PrivilegeNotHeldException`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2490451)
	});
})(window, window.NetJs.$boot(), ...await window.NetJs.$require("NetJs.System.Private.CoreLib", "NetJs.Microsoft.Win32.Primitives", "NetJs.System.Collections", "NetJs.System.Diagnostics.Tracing", "NetJs.System.Threading", "NetJs.System.Collections.Concurrent", "NetJs.System.Memory", "NetJs.System.Private.Uri", "NetJs.System.Runtime", "NetJs.System.Collections.NonGeneric", "NetJs.System.Runtime.InteropServices", "NetJs.System.Threading.Thread", "NetJs.System.Security.Claims", "NetJs.System.Security.Principal.Windows"));
})();
//--TRIMMABLE-BOUNDARY-END(83)
