
(function ($global, $, $spc, $mwp, $sc, $sdt, $sm, $spu, $st, $stt, $sr, $scc, $scn, $ssc, $sris, $sspw) {
    "use strict";
    let _;
    
    
    
	$.$asm(
    "NetJs.System.Security.AccessControl", 
    {"h":48981,"f":"System.Security.AccessControl","v":"1.0.35.0","a":[{"t":115146753,"c":13000048641,"a":[{"v":".NETCoreApp,Version=v10.0","t":1310721}],"n":[{"n":"FrameworkDisplayName","v":".NET 10.0","t":1310721}]},{"t":73596929,"c":4368564225,"a":[{"v":"SIT","t":1310721}]},{"t":73662465,"c":4368629761,"a":[{"v":"Debug","t":1310721}]},{"t":74121217,"c":4369088513,"a":[{"v":"1.0.35.0","t":1310721}]},{"t":74252289,"c":4369219585,"a":[{"v":"1.0.35\u002B760b8187d87d291733fdcda9f4d484d24d61a938","t":1310721}]},{"t":75104257,"c":4370071553,"a":[{"v":"NetJs.System.Security.AccessControl","t":1310721}]},{"t":75235329,"c":4370202625,"a":[{"v":"NetJs.System.Security.AccessControl","t":1310721}]},{"t":75366401,"c":4370333697,"a":[{"v":"1.0.35.0","t":1310721}]},{"t":115212289,"c":4410179585,"a":[{"v":"browser1.0","t":1310721}]},{"t":114950145,"c":4409917441,"a":[{"v":"browser1.0","t":1310721}]}],"m":[]},
    function($asm)
	{
        
        
        $asm.$cls("$ssa.System.Security.AccessControl.AuthorizationRule", ($self) => class AuthorizationRule extends $.$spc.System.Object
        {
            $ctor$1(/*System.Security.Principal.IdentityReference*/ identity, /*int*/ accessMask, /*bool*/ isInherited, /*System.Security.AccessControl.InheritanceFlags*/ inheritanceFlags, /*System.Security.AccessControl.PropagationFlags*/ propagationFlags)
            {
                super.$ctor();
                {
                }
                return this;
            }
            /*int */ get AccessMask()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Security.Principal.IdentityReference */ get IdentityReference()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Security.AccessControl.InheritanceFlags */ get InheritanceFlags()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get IsInherited()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Security.AccessControl.PropagationFlags */ get PropagationFlags()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static $h = 966485;
            static $f = 0b110001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":655361,"g":{"r":0,"d":0,"h":12885868373,"f":16},"n":"AccessMask","d":966485,"h":8590901077,"f":16},{"p":255816,"g":{"r":0,"d":0,"h":21475802965,"f":1},"n":"IdentityReference","d":966485,"h":17180835669,"f":1},{"p":1883989,"g":{"r":0,"d":0,"h":30065737557,"f":1},"n":"InheritanceFlags","d":966485,"h":25770770261,"f":1},{"p":262145,"g":{"r":0,"d":0,"h":38655672149,"f":1},"n":"IsInherited","d":966485,"h":34360704853,"f":1},{"p":2604885,"g":{"r":0,"d":0,"h":47245606741,"f":1},"n":"PropagationFlags","d":966485,"h":42950639445,"f":1}],"c":[{"p":[{"n":"identity","p":255816},{"n":"accessMask","p":655361},{"n":"isInherited","p":262145},{"n":"inheritanceFlags","p":1883989},{"n":"propagationFlags","p":2604885}],"n":".ctor","o":"$ctor$1","d":966485,"h":4295933781,"f":16}],"h":966485}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.Security.AccessControl.AuthorizationRule`; }
        });
        
        $asm.$cls("$ssa.System.Security.AccessControl.GenericAce", ($self) => class GenericAce extends $.$spc.System.Object
        {
            $ctor$1()
            {
                super.$ctor();
                {
                }
                return this;
            }
            /*System.Security.AccessControl.AceFlags */ get AceFlags()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Security.AccessControl.AceFlags */ set AceFlags(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Security.AccessControl.AceType */ get AceType()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Security.AccessControl.AuditFlags */ get AuditFlags()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Security.AccessControl.InheritanceFlags */ get InheritanceFlags()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get IsInherited()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Security.AccessControl.PropagationFlags */ get PropagationFlags()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Security.AccessControl.GenericAce */ Copy()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static /*System.Security.AccessControl.GenericAce */ CreateFromBinaryForm(/*byte[]*/ binaryForm, /*int*/ offset)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static/*conventional*/ /*bool */ Equals(/*object?*/ o)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            //Static convention instance redirect
            /*bool */ Equals() { return $.$ssa.System.Security.AccessControl.GenericAce.Equals.apply(this, arguments); }
            static/*conventional*/ /*int */ GetHashCode()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            //Static convention instance redirect
            /*int */ GetHashCode() { return $.$ssa.System.Security.AccessControl.GenericAce.GetHashCode.apply(this, arguments); }
            static /*bool */ op_Equality(/*System.Security.AccessControl.GenericAce?*/ left, /*System.Security.AccessControl.GenericAce?*/ right)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static /*bool */ op_Inequality(/*System.Security.AccessControl.GenericAce?*/ left, /*System.Security.AccessControl.GenericAce?*/ right)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static $h = 1687381;
            static $f = 0b110001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":573269,"g":{"r":0,"d":0,"h":12886589269,"f":1},"s":{"r":0,"d":0,"h":17181556565,"f":1},"n":"AceFlags","d":1687381,"h":8591621973,"f":1},{"p":704341,"g":{"r":0,"d":0,"h":25771491157,"f":1},"n":"AceType","d":1687381,"h":21476523861,"f":1},{"p":769877,"g":{"r":0,"d":0,"h":34361425749,"f":1},"n":"AuditFlags","d":1687381,"h":30066458453,"f":1},{"p":655361,"g":{"r":0,"d":0,"h":42951360341,"f":257},"n":"BinaryLength","d":1687381,"h":38656393045,"f":257},{"p":1883989,"g":{"r":0,"d":0,"h":51541294933,"f":1},"n":"InheritanceFlags","d":1687381,"h":47246327637,"f":1},{"p":262145,"g":{"r":0,"d":0,"h":60131229525,"f":1},"n":"IsInherited","d":1687381,"h":55836262229,"f":1},{"p":2604885,"g":{"r":0,"d":0,"h":68721164117,"f":1},"n":"PropagationFlags","d":1687381,"h":64426196821,"f":1}],"m":[{"r":1687381,"n":"Copy","d":1687381,"h":73016131413,"f":1},{"r":1687381,"p":[{"n":"binaryForm","p":0},{"n":"offset","p":655361}],"n":"CreateFromBinaryForm","d":1687381,"h":77311098709,"f":33},{"r":262145,"p":[{"n":"o","p":131073}],"n":"Equals","d":1687381,"h":81606066005,"f":98305},{"r":65537,"p":[{"n":"binaryForm","p":0},{"n":"offset","p":655361}],"n":"GetBinaryForm","d":1687381,"h":85901033301,"f":257},{"r":655361,"n":"GetHashCode","d":1687381,"h":90196000597,"f":98305}],"c":[{"n":".ctor","o":"$ctor$1","d":1687381,"h":4296654677,"f":8}],"h":1687381}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.Security.AccessControl.GenericAce`; }
        });
        
        $asm.$cls("$ssa.System.Security.AccessControl.GenericSecurityDescriptor", ($self) => class GenericSecurityDescriptor extends $.$spc.System.Object
        {
            $ctor$1()
            {
                super.$ctor();
                {
                }
                return this;
            }
            /*int */ get BinaryLength()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static /*byte */ get Revision()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*void */ GetBinaryForm(/*byte[]*/ binaryForm, /*int*/ offset)
            {
            }
            /*string */ GetSddlForm(/*System.Security.AccessControl.AccessControlSections*/ includeSections)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static /*bool */ IsSddlConversionSupported()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static $h = 1818453;
            static $f = 0b110001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":655361,"g":{"r":0,"d":0,"h":12886720341,"f":1},"n":"BinaryLength","d":1818453,"h":8591753045,"f":1},{"p":1490773,"g":{"r":0,"d":0,"h":21476654933,"f":257},"n":"ControlFlags","d":1818453,"h":17181687637,"f":257},{"p":452424,"g":{"r":0,"d":0,"h":30066589525,"f":257},"s":{"r":0,"d":0,"h":34361556821,"f":257},"n":"Group","d":1818453,"h":25771622229,"f":257},{"p":452424,"g":{"r":0,"d":0,"h":42951491413,"f":257},"s":{"r":0,"d":0,"h":47246458709,"f":257},"n":"Owner","d":1818453,"h":38656524117,"f":257},{"p":393217,"g":{"r":0,"d":0,"h":55836393301,"f":33},"n":"Revision","d":1818453,"h":51541426005,"f":33}],"m":[{"r":65537,"p":[{"n":"binaryForm","p":0},{"n":"offset","p":655361}],"n":"GetBinaryForm","d":1818453,"h":60131360597,"f":1},{"r":1310721,"p":[{"n":"includeSections","p":245589}],"n":"GetSddlForm","d":1818453,"h":64426327893,"f":1},{"r":262145,"n":"IsSddlConversionSupported","d":1818453,"h":68721295189,"f":33}],"c":[{"n":".ctor","o":"$ctor$1","d":1818453,"h":4296785749,"f":8}],"h":1818453}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.Security.AccessControl.GenericSecurityDescriptor`; }
        });
        
        $asm.$cls("$ssa.System.Security.AccessControl.ObjectSecurity", ($self) => class ObjectSecurity extends $.$spc.System.Object
        {
            $ctor$1()
            {
                super.$ctor();
                {
                }
                return this;
            }
            $ctor$2(/*bool*/ isContainer, /*bool*/ isDS)
            {
                super.$ctor();
                {
                }
                return this;
            }
            $ctor$3(/*System.Security.AccessControl.CommonSecurityDescriptor*/ securityDescriptor)
            {
                super.$ctor();
                {
                }
                return this;
            }
            /*bool */ get AccessRulesModified()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ set AccessRulesModified(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get AreAccessRulesCanonical()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get AreAccessRulesProtected()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get AreAuditRulesCanonical()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get AreAuditRulesProtected()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get AuditRulesModified()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ set AuditRulesModified(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get GroupModified()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ set GroupModified(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get IsContainer()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get IsDS()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get OwnerModified()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ set OwnerModified(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Security.AccessControl.CommonSecurityDescriptor */ get SecurityDescriptor()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Security.Principal.IdentityReference? */ GetGroup(/*System.Type*/ targetType)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Security.Principal.IdentityReference? */ GetOwner(/*System.Type*/ targetType)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*byte[] */ GetSecurityDescriptorBinaryForm()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*string */ GetSecurityDescriptorSddlForm(/*System.Security.AccessControl.AccessControlSections*/ includeSections)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static /*bool */ IsSddlConversionSupported()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ ModifyAccessRule(/*System.Security.AccessControl.AccessControlModification*/ modification, /*System.Security.AccessControl.AccessRule*/ rule, /*out bool*/ modified)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ ModifyAuditRule(/*System.Security.AccessControl.AccessControlModification*/ modification, /*System.Security.AccessControl.AuditRule*/ rule, /*out bool*/ modified)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*void */ Persist(/*bool*/ enableOwnershipPrivilege, /*string*/ name, /*System.Security.AccessControl.AccessControlSections*/ includeSections)
            {
            }
            /*void */ Persist$1(/*System.Runtime.InteropServices.SafeHandle*/ handle, /*System.Security.AccessControl.AccessControlSections*/ includeSections)
            {
            }
            /*void */ Persist$2(/*string*/ name, /*System.Security.AccessControl.AccessControlSections*/ includeSections)
            {
            }
            /*void */ PurgeAccessRules(/*System.Security.Principal.IdentityReference*/ identity)
            {
            }
            /*void */ PurgeAuditRules(/*System.Security.Principal.IdentityReference*/ identity)
            {
            }
            /*void */ ReadLock()
            {
            }
            /*void */ ReadUnlock()
            {
            }
            /*void */ SetAccessRuleProtection(/*bool*/ isProtected, /*bool*/ preserveInheritance)
            {
            }
            /*void */ SetAuditRuleProtection(/*bool*/ isProtected, /*bool*/ preserveInheritance)
            {
            }
            /*void */ SetGroup(/*System.Security.Principal.IdentityReference*/ identity)
            {
            }
            /*void */ SetOwner(/*System.Security.Principal.IdentityReference*/ identity)
            {
            }
            /*void */ SetSecurityDescriptorBinaryForm(/*byte[]*/ binaryForm)
            {
            }
            /*void */ SetSecurityDescriptorBinaryForm$1(/*byte[]*/ binaryForm, /*System.Security.AccessControl.AccessControlSections*/ includeSections)
            {
            }
            /*void */ SetSecurityDescriptorSddlForm(/*string*/ sddlForm)
            {
            }
            /*void */ SetSecurityDescriptorSddlForm$1(/*string*/ sddlForm, /*System.Security.AccessControl.AccessControlSections*/ includeSections)
            {
            }
            /*void */ WriteLock()
            {
            }
            /*void */ WriteUnlock()
            {
            }
            static $h = 2408277;
            static $f = 0b110001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":142606337,"g":{"r":0,"d":0,"h":21477244757,"f":257},"n":"AccessRightType","d":2408277,"h":17182277461,"f":257},{"p":262145,"g":{"r":0,"d":0,"h":30067179349,"f":4},"s":{"r":0,"d":0,"h":34362146645,"f":4},"n":"AccessRulesModified","d":2408277,"h":25772212053,"f":4},{"p":142606337,"g":{"r":0,"d":0,"h":42952081237,"f":257},"n":"AccessRuleType","d":2408277,"h":38657113941,"f":257},{"p":262145,"g":{"r":0,"d":0,"h":51542015829,"f":1},"n":"AreAccessRulesCanonical","d":2408277,"h":47247048533,"f":1},{"p":262145,"g":{"r":0,"d":0,"h":60131950421,"f":1},"n":"AreAccessRulesProtected","d":2408277,"h":55836983125,"f":1},{"p":262145,"g":{"r":0,"d":0,"h":68721885013,"f":1},"n":"AreAuditRulesCanonical","d":2408277,"h":64426917717,"f":1},{"p":262145,"g":{"r":0,"d":0,"h":77311819605,"f":1},"n":"AreAuditRulesProtected","d":2408277,"h":73016852309,"f":1},{"p":262145,"g":{"r":0,"d":0,"h":85901754197,"f":4},"s":{"r":0,"d":0,"h":90196721493,"f":4},"n":"AuditRulesModified","d":2408277,"h":81606786901,"f":4},{"p":142606337,"g":{"r":0,"d":0,"h":98786656085,"f":257},"n":"AuditRuleType","d":2408277,"h":94491688789,"f":257},{"p":262145,"g":{"r":0,"d":0,"h":107376590677,"f":4},"s":{"r":0,"d":0,"h":111671557973,"f":4},"n":"GroupModified","d":2408277,"h":103081623381,"f":4},{"p":262145,"g":{"r":0,"d":0,"h":120261492565,"f":4},"n":"IsContainer","d":2408277,"h":115966525269,"f":4},{"p":262145,"g":{"r":0,"d":0,"h":128851427157,"f":4},"n":"IsDS","d":2408277,"h":124556459861,"f":4},{"p":262145,"g":{"r":0,"d":0,"h":137441361749,"f":4},"s":{"r":0,"d":0,"h":141736329045,"f":4},"n":"OwnerModified","d":2408277,"h":133146394453,"f":4},{"p":1294165,"g":{"r":0,"d":0,"h":150326263637,"f":4},"n":"SecurityDescriptor","d":2408277,"h":146031296341,"f":4}],"m":[{"r":376661,"p":[{"n":"identityReference","p":255816},{"n":"accessMask","p":655361},{"n":"isInherited","p":262145},{"n":"inheritanceFlags","p":1883989},{"n":"propagationFlags","p":2604885},{"n":"type","p":311125}],"n":"AccessRuleFactory","d":2408277,"h":154621230933,"f":257},{"r":835413,"p":[{"n":"identityReference","p":255816},{"n":"accessMask","p":655361},{"n":"isInherited","p":262145},{"n":"inheritanceFlags","p":1883989},{"n":"propagationFlags","p":2604885},{"n":"flags","p":769877}],"n":"AuditRuleFactory","d":2408277,"h":158916198229,"f":257},{"r":255816,"p":[{"n":"targetType","p":142606337}],"n":"GetGroup","d":2408277,"h":163211165525,"f":1},{"r":255816,"p":[{"n":"targetType","p":142606337}],"n":"GetOwner","d":2408277,"h":167506132821,"f":1},{"r":0,"n":"GetSecurityDescriptorBinaryForm","d":2408277,"h":171801100117,"f":1},{"r":1310721,"p":[{"n":"includeSections","p":245589}],"n":"GetSecurityDescriptorSddlForm","d":2408277,"h":176096067413,"f":1},{"r":262145,"n":"IsSddlConversionSupported","d":2408277,"h":180391034709,"f":33},{"r":262145,"p":[{"n":"modification","p":180053},{"n":"rule","p":376661},{"n":"modified","p":262145,"f":2}],"n":"ModifyAccess","d":2408277,"h":184686002005,"f":260},{"r":262145,"p":[{"n":"modification","p":180053},{"n":"rule","p":376661},{"n":"modified","p":262145,"f":2}],"n":"ModifyAccessRule","d":2408277,"h":188980969301,"f":129},{"r":262145,"p":[{"n":"modification","p":180053},{"n":"rule","p":835413},{"n":"modified","p":262145,"f":2}],"n":"ModifyAudit","d":2408277,"h":193275936597,"f":260},{"r":262145,"p":[{"n":"modification","p":180053},{"n":"rule","p":835413},{"n":"modified","p":262145,"f":2}],"n":"ModifyAuditRule","d":2408277,"h":197570903893,"f":129},{"r":65537,"p":[{"n":"enableOwnershipPrivilege","p":262145},{"n":"name","p":1310721},{"n":"includeSections","p":245589}],"n":"Persist","d":2408277,"h":201865871189,"f":132},{"r":65537,"p":[{"n":"handle","p":109576193},{"n":"includeSections","p":245589}],"n":"Persist","o":"@$1","d":2408277,"h":206160838485,"f":132},{"r":65537,"p":[{"n":"name","p":1310721},{"n":"includeSections","p":245589}],"n":"Persist","o":"@$2","d":2408277,"h":210455805781,"f":132},{"r":65537,"p":[{"n":"identity","p":255816}],"n":"PurgeAccessRules","d":2408277,"h":214750773077,"f":129},{"r":65537,"p":[{"n":"identity","p":255816}],"n":"PurgeAuditRules","d":2408277,"h":219045740373,"f":129},{"r":65537,"n":"ReadLock","d":2408277,"h":223340707669,"f":4},{"r":65537,"n":"ReadUnlock","d":2408277,"h":227635674965,"f":4},{"r":65537,"p":[{"n":"isProtected","p":262145},{"n":"preserveInheritance","p":262145}],"n":"SetAccessRuleProtection","d":2408277,"h":231930642261,"f":1},{"r":65537,"p":[{"n":"isProtected","p":262145},{"n":"preserveInheritance","p":262145}],"n":"SetAuditRuleProtection","d":2408277,"h":236225609557,"f":1},{"r":65537,"p":[{"n":"identity","p":255816}],"n":"SetGroup","d":2408277,"h":240520576853,"f":1},{"r":65537,"p":[{"n":"identity","p":255816}],"n":"SetOwner","d":2408277,"h":244815544149,"f":1},{"r":65537,"p":[{"n":"binaryForm","p":0}],"n":"SetSecurityDescriptorBinaryForm","d":2408277,"h":249110511445,"f":1},{"r":65537,"p":[{"n":"binaryForm","p":0},{"n":"includeSections","p":245589}],"n":"SetSecurityDescriptorBinaryForm","o":"@$1","d":2408277,"h":253405478741,"f":1},{"r":65537,"p":[{"n":"sddlForm","p":1310721}],"n":"SetSecurityDescriptorSddlForm","d":2408277,"h":257700446037,"f":1},{"r":65537,"p":[{"n":"sddlForm","p":1310721},{"n":"includeSections","p":245589}],"n":"SetSecurityDescriptorSddlForm","o":"@$1","d":2408277,"h":261995413333,"f":1},{"r":65537,"n":"WriteLock","d":2408277,"h":266290380629,"f":4},{"r":65537,"n":"WriteUnlock","d":2408277,"h":270585347925,"f":4}],"c":[{"n":".ctor","o":"$ctor$1","d":2408277,"h":4297375573,"f":4},{"p":[{"n":"isContainer","p":262145},{"n":"isDS","p":262145}],"n":".ctor","o":"$ctor$2","d":2408277,"h":8592342869,"f":4},{"p":[{"n":"securityDescriptor","p":1294165}],"n":".ctor","o":"$ctor$3","d":2408277,"h":12887310165,"f":4}],"h":2408277}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.Security.AccessControl.ObjectSecurity`; }
        });
        
        $asm.$cls("$ssa.System.Security.Policy.EvidenceBase", ($self) => class EvidenceBase extends $.$spc.System.Object
        {
            $ctor$1()
            {
                super.$ctor();
                {
                }
                return this;
            }
            /*System.Security.Policy.EvidenceBase? */ Clone()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static $h = 3129173;
            static $f = 0b110001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"m":[{"r":3129173,"n":"Clone","d":3129173,"h":8593063765,"f":129}],"c":[{"n":".ctor","o":"$ctor$1","d":3129173,"h":4298096469,"f":4}],"h":3129173}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.Security.Policy.EvidenceBase`; }
        });
        
        $asm.$cls("$ssa.System.Security.AccessControl.GenericAcl", ($self) => class GenericAcl extends $.$spc.System.Object
        {
            /*byte*/ static AclRevision = 0;
            /*byte*/ static AclRevisionDS = 0;
            /*int*/ static MaxBinaryLength = 0;
            $ctor$1()
            {
                super.$ctor();
                {
                }
                return this;
            }
            /*bool */ get IsSynchronized()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*object */ get SyncRoot()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*void */ CopyTo(/*System.Security.AccessControl.GenericAce[]*/ array, /*int*/ index)
            {
            }
            /*System.Security.AccessControl.AceEnumerator */ GetEnumerator()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*void */ System$Collections$ICollection$CopyTo(/*System.Array*/ array, /*int*/ index)
            {
            }
            /*System.Collections.IEnumerator */ System$Collections$IEnumerable$GetEnumerator()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            //Generated interface implemetation for System.Collections.ICollection.Count.get
            get System$Collections$ICollection$Count()
            {
                return this.Count;
            }
            //Generated interface implemetation for System.Collections.ICollection.SyncRoot.get
            get System$Collections$ICollection$SyncRoot()
            {
                return this.SyncRoot;
            }
            //Generated interface implemetation for System.Collections.ICollection.IsSynchronized.get
            get System$Collections$ICollection$IsSynchronized()
            {
                return this.IsSynchronized;
            }
            static $h = 1752917;
            static $f = 0b110001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":655361,"g":{"r":0,"d":0,"h":25771556693,"f":257},"n":"BinaryLength","d":1752917,"h":21476589397,"f":257},{"p":655361,"g":{"r":0,"d":0,"h":34361491285,"f":257},"n":"Count","d":1752917,"h":30066523989,"f":257},{"p":262145,"g":{"r":0,"d":0,"h":42951425877,"f":1},"n":"IsSynchronized","d":1752917,"h":38656458581,"f":1},{"p":1687381,"i":[{"n":"index","p":655361}],"g":{"r":0,"d":0,"h":51541360469,"f":257},"s":{"r":0,"d":0,"h":55836327765,"f":257},"n":"Item","o":"@$2","d":1752917,"h":47246393173,"f":257},{"p":393217,"g":{"r":0,"d":0,"h":64426262357,"f":257},"n":"Revision","d":1752917,"h":60131295061,"f":257},{"p":131073,"g":{"r":0,"d":0,"h":73016196949,"f":129},"n":"SyncRoot","d":1752917,"h":68721229653,"f":129}],"m":[{"r":65537,"p":[{"n":"array","p":0},{"n":"index","p":655361}],"n":"CopyTo","d":1752917,"h":77311164245,"f":1},{"r":65537,"p":[{"n":"binaryForm","p":0},{"n":"offset","p":655361}],"n":"GetBinaryForm","d":1752917,"h":81606131541,"f":257},{"r":507733,"n":"GetEnumerator","d":1752917,"h":85901098837,"f":1}],"l":[{"t":393217,"n":"AclRevision","d":1752917,"h":4296720213,"f":33},{"t":393217,"n":"AclRevisionDS","d":1752917,"h":8591687509,"f":33},{"t":655361,"n":"MaxBinaryLength","d":1752917,"h":12886654805,"f":33}],"c":[{"n":".ctor","o":"$ctor$1","d":1752917,"h":17181622101,"f":4}],"i":[31326209,31588353],"h":1752917}; }
            static get $b() { return $.$spc.System.Object; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.Collections.ICollection, $.$spc.System.Collections.IEnumerable ]; }
            static get $fullName() { return `System.Security.AccessControl.GenericAcl`; }
        });
        
        $asm.$cls("$ssa.System.Security.AccessControl.AccessRule", ($self) => class AccessRule extends $.$ssa.System.Security.AccessControl.AuthorizationRule
        {
            $ctor$2(/*System.Security.Principal.IdentityReference*/ identity, /*int*/ accessMask, /*bool*/ isInherited, /*System.Security.AccessControl.InheritanceFlags*/ inheritanceFlags, /*System.Security.AccessControl.PropagationFlags*/ propagationFlags, /*System.Security.AccessControl.AccessControlType*/ type)
            {
                super.$ctor$1(null, 0, false, 0, 0);
                {
                }
                return this;
            }
            /*System.Security.AccessControl.AccessControlType */ get AccessControlType()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static $h = 376661;
            static $f = 0b110001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":966485,"p":[{"p":311125,"g":{"r":0,"d":0,"h":12885278549,"f":1},"n":"AccessControlType","d":376661,"h":8590311253,"f":1}],"c":[{"p":[{"n":"identity","p":255816},{"n":"accessMask","p":655361},{"n":"isInherited","p":262145},{"n":"inheritanceFlags","p":1883989},{"n":"propagationFlags","p":2604885},{"n":"type","p":311125}],"n":".ctor","o":"$ctor$2","d":376661,"h":4295343957,"f":4}],"h":376661}; }
            static get $b() { return $.$ssa.System.Security.AccessControl.AuthorizationRule; }
            static get $fullName() { return `System.Security.AccessControl.AccessRule`; }
        });
        
        $asm.$cls("$ssa.System.Security.AccessControl.AuditRule", ($self) => class AuditRule extends $.$ssa.System.Security.AccessControl.AuthorizationRule
        {
            $ctor$2(/*System.Security.Principal.IdentityReference*/ identity, /*int*/ accessMask, /*bool*/ isInherited, /*System.Security.AccessControl.InheritanceFlags*/ inheritanceFlags, /*System.Security.AccessControl.PropagationFlags*/ propagationFlags, /*System.Security.AccessControl.AuditFlags*/ auditFlags)
            {
                super.$ctor$1(null, 0, false, 0, 0);
                {
                }
                return this;
            }
            /*System.Security.AccessControl.AuditFlags */ get AuditFlags()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static $h = 835413;
            static $f = 0b110001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":966485,"p":[{"p":769877,"g":{"r":0,"d":0,"h":12885737301,"f":1},"n":"AuditFlags","d":835413,"h":8590770005,"f":1}],"c":[{"p":[{"n":"identity","p":255816},{"n":"accessMask","p":655361},{"n":"isInherited","p":262145},{"n":"inheritanceFlags","p":1883989},{"n":"propagationFlags","p":2604885},{"n":"auditFlags","p":769877}],"n":".ctor","o":"$ctor$2","d":835413,"h":4295802709,"f":4}],"h":835413}; }
            static get $b() { return $.$ssa.System.Security.AccessControl.AuthorizationRule; }
            static get $fullName() { return `System.Security.AccessControl.AuditRule`; }
        });
        
        $asm.$cls("$ssa.System.Security.AccessControl.CommonObjectSecurity", ($self) => class CommonObjectSecurity extends $.$ssa.System.Security.AccessControl.ObjectSecurity
        {
            $ctor$4(/*bool*/ isContainer)
            {
                super.$ctor$1();
                {
                }
                return this;
            }
            /*void */ AddAccessRule(/*System.Security.AccessControl.AccessRule*/ rule)
            {
            }
            /*void */ AddAuditRule(/*System.Security.AccessControl.AuditRule*/ rule)
            {
            }
            /*System.Security.AccessControl.AuthorizationRuleCollection */ GetAccessRules(/*bool*/ includeExplicit, /*bool*/ includeInherited, /*System.Type*/ targetType)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Security.AccessControl.AuthorizationRuleCollection */ GetAuditRules(/*bool*/ includeExplicit, /*bool*/ includeInherited, /*System.Type*/ targetType)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ ModifyAccess(/*System.Security.AccessControl.AccessControlModification*/ modification, /*System.Security.AccessControl.AccessRule*/ rule, /*out bool*/ modified)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ ModifyAudit(/*System.Security.AccessControl.AccessControlModification*/ modification, /*System.Security.AccessControl.AuditRule*/ rule, /*out bool*/ modified)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ RemoveAccessRule(/*System.Security.AccessControl.AccessRule*/ rule)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*void */ RemoveAccessRuleAll(/*System.Security.AccessControl.AccessRule*/ rule)
            {
            }
            /*void */ RemoveAccessRuleSpecific(/*System.Security.AccessControl.AccessRule*/ rule)
            {
            }
            /*bool */ RemoveAuditRule(/*System.Security.AccessControl.AuditRule*/ rule)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*void */ RemoveAuditRuleAll(/*System.Security.AccessControl.AuditRule*/ rule)
            {
            }
            /*void */ RemoveAuditRuleSpecific(/*System.Security.AccessControl.AuditRule*/ rule)
            {
            }
            /*void */ ResetAccessRule(/*System.Security.AccessControl.AccessRule*/ rule)
            {
            }
            /*void */ SetAccessRule(/*System.Security.AccessControl.AccessRule*/ rule)
            {
            }
            /*void */ SetAuditRule(/*System.Security.AccessControl.AuditRule*/ rule)
            {
            }
            static $h = 1228629;
            static $f = 0b110001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":2408277,"m":[{"r":65537,"p":[{"n":"rule","p":376661}],"n":"AddAccessRule","d":1228629,"h":8591163221,"f":4},{"r":65537,"p":[{"n":"rule","p":835413}],"n":"AddAuditRule","d":1228629,"h":12886130517,"f":4},{"r":1032021,"p":[{"n":"includeExplicit","p":262145},{"n":"includeInherited","p":262145},{"n":"targetType","p":142606337}],"n":"GetAccessRules","d":1228629,"h":17181097813,"f":1},{"r":1032021,"p":[{"n":"includeExplicit","p":262145},{"n":"includeInherited","p":262145},{"n":"targetType","p":142606337}],"n":"GetAuditRules","d":1228629,"h":21476065109,"f":1},{"r":262145,"p":[{"n":"modification","p":180053},{"n":"rule","p":376661},{"n":"modified","p":262145,"f":2}],"n":"ModifyAccess","d":1228629,"h":25771032405,"f":32772},{"r":262145,"p":[{"n":"modification","p":180053},{"n":"rule","p":835413},{"n":"modified","p":262145,"f":2}],"n":"ModifyAudit","d":1228629,"h":30065999701,"f":32772},{"r":262145,"p":[{"n":"rule","p":376661}],"n":"RemoveAccessRule","d":1228629,"h":34360966997,"f":4},{"r":65537,"p":[{"n":"rule","p":376661}],"n":"RemoveAccessRuleAll","d":1228629,"h":38655934293,"f":4},{"r":65537,"p":[{"n":"rule","p":376661}],"n":"RemoveAccessRuleSpecific","d":1228629,"h":42950901589,"f":4},{"r":262145,"p":[{"n":"rule","p":835413}],"n":"RemoveAuditRule","d":1228629,"h":47245868885,"f":4},{"r":65537,"p":[{"n":"rule","p":835413}],"n":"RemoveAuditRuleAll","d":1228629,"h":51540836181,"f":4},{"r":65537,"p":[{"n":"rule","p":835413}],"n":"RemoveAuditRuleSpecific","d":1228629,"h":55835803477,"f":4},{"r":65537,"p":[{"n":"rule","p":376661}],"n":"ResetAccessRule","d":1228629,"h":60130770773,"f":4},{"r":65537,"p":[{"n":"rule","p":376661}],"n":"SetAccessRule","d":1228629,"h":64425738069,"f":4},{"r":65537,"p":[{"n":"rule","p":835413}],"n":"SetAuditRule","d":1228629,"h":68720705365,"f":4}],"c":[{"p":[{"n":"isContainer","p":262145}],"n":".ctor","o":"$ctor$4","d":1228629,"h":4296195925,"f":4}],"h":1228629}; }
            static get $b() { return $.$ssa.System.Security.AccessControl.ObjectSecurity; }
            static get $fullName() { return `System.Security.AccessControl.CommonObjectSecurity`; }
        });
        
        $asm.$cls("$ssa.System.Security.AccessControl.KnownAce", ($self) => class KnownAce extends $.$ssa.System.Security.AccessControl.GenericAce
        {
            $ctor$2()
            {
                super.$ctor$1();
                {
                }
                return this;
            }
            /*int */ get AccessMask()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ set AccessMask(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Security.Principal.SecurityIdentifier */ get SecurityIdentifier()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Security.Principal.SecurityIdentifier */ set SecurityIdentifier(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static $h = 1949525;
            static $f = 0b110001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":1687381,"p":[{"p":655361,"g":{"r":0,"d":0,"h":12886851413,"f":1},"s":{"r":0,"d":0,"h":17181818709,"f":1},"n":"AccessMask","d":1949525,"h":8591884117,"f":1},{"p":452424,"g":{"r":0,"d":0,"h":25771753301,"f":1},"s":{"r":0,"d":0,"h":30066720597,"f":1},"n":"SecurityIdentifier","d":1949525,"h":21476786005,"f":1}],"c":[{"n":".ctor","o":"$ctor$2","d":1949525,"h":4296916821,"f":8}],"h":1949525}; }
            static get $b() { return $.$ssa.System.Security.AccessControl.GenericAce; }
            static get $fullName() { return `System.Security.AccessControl.KnownAce`; }
        });
        
        $asm.$cls("$ssa.System.Security.AccessControl.CommonAcl", ($self) => class CommonAcl extends $.$ssa.System.Security.AccessControl.GenericAcl
        {
            $ctor$2()
            {
                super.$ctor$1();
                {
                }
                return this;
            }
            /*int */ get BinaryLength()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ get Count()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get IsCanonical()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get IsContainer()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get IsDS()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Security.AccessControl.GenericAce*/ get_Item(/*int*/ index)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*void*/ set_Item(/*int*/ index, /*System.Security.AccessControl.GenericAce*/ value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*byte */ get Revision()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*void */ GetBinaryForm(/*byte[]*/ binaryForm, /*int*/ offset)
            {
            }
            /*void */ Purge(/*System.Security.Principal.SecurityIdentifier*/ sid)
            {
            }
            /*void */ RemoveInheritedAces()
            {
            }
            static $h = 1163093;
            static $f = 0b110001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":1752917,"p":[{"p":655361,"g":{"r":0,"d":0,"h":12886064981,"f":98305},"n":"BinaryLength","d":1163093,"h":8591097685,"f":98305},{"p":655361,"g":{"r":0,"d":0,"h":21475999573,"f":98305},"n":"Count","d":1163093,"h":17181032277,"f":98305},{"p":262145,"g":{"r":0,"d":0,"h":30065934165,"f":1},"n":"IsCanonical","d":1163093,"h":25770966869,"f":1},{"p":262145,"g":{"r":0,"d":0,"h":38655868757,"f":1},"n":"IsContainer","d":1163093,"h":34360901461,"f":1},{"p":262145,"g":{"r":0,"d":0,"h":47245803349,"f":1},"n":"IsDS","d":1163093,"h":42950836053,"f":1},{"p":1687381,"i":[{"n":"index","p":655361}],"g":{"r":0,"d":0,"h":55835737941,"f":98305},"s":{"r":0,"d":0,"h":60130705237,"f":98305},"n":"Item","o":"@$2","d":1163093,"h":51540770645,"f":98305},{"p":393217,"g":{"r":0,"d":0,"h":68720639829,"f":98305},"n":"Revision","d":1163093,"h":64425672533,"f":98305}],"m":[{"r":65537,"p":[{"n":"binaryForm","p":0},{"n":"offset","p":655361}],"n":"GetBinaryForm","d":1163093,"h":73015607125,"f":98305},{"r":65537,"p":[{"n":"sid","p":452424}],"n":"Purge","d":1163093,"h":77310574421,"f":1},{"r":65537,"n":"RemoveInheritedAces","d":1163093,"h":81605541717,"f":1}],"c":[{"n":".ctor","o":"$ctor$2","d":1163093,"h":4296130389,"f":8}],"i":[31326209,31588353],"h":1163093}; }
            static get $b() { return $.$ssa.System.Security.AccessControl.GenericAcl; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.Collections.ICollection, $.$spc.System.Collections.IEnumerable ]; }
            static get $fullName() { return `System.Security.AccessControl.CommonAcl`; }
        });
        
        $asm.$cls("$ssa.System.Security.AccessControl.NativeObjectSecurity", ($self) => class NativeObjectSecurity extends $.$ssa.System.Security.AccessControl.CommonObjectSecurity
        {
            $ctor$5(/*bool*/ isContainer, /*System.Security.AccessControl.ResourceType*/ resourceType)
            {
                super.$ctor$4(false);
                {
                }
                return this;
            }
            $ctor$6(/*bool*/ isContainer, /*System.Security.AccessControl.ResourceType*/ resourceType, /*System.Runtime.InteropServices.SafeHandle?*/ handle, /*System.Security.AccessControl.AccessControlSections*/ includeSections)
            {
                super.$ctor$4(false);
                {
                }
                return this;
            }
            $ctor$7(/*bool*/ isContainer, /*System.Security.AccessControl.ResourceType*/ resourceType, /*System.Runtime.InteropServices.SafeHandle?*/ handle, /*System.Security.AccessControl.AccessControlSections*/ includeSections, /*System.Security.AccessControl.NativeObjectSecurity.ExceptionFromErrorCode?*/ exceptionFromErrorCode, /*object?*/ exceptionContext)
            {
                super.$ctor$4(false);
                {
                }
                return this;
            }
            $ctor$8(/*bool*/ isContainer, /*System.Security.AccessControl.ResourceType*/ resourceType, /*System.Security.AccessControl.NativeObjectSecurity.ExceptionFromErrorCode?*/ exceptionFromErrorCode, /*object?*/ exceptionContext)
            {
                super.$ctor$4(false);
                {
                }
                return this;
            }
            $ctor$9(/*bool*/ isContainer, /*System.Security.AccessControl.ResourceType*/ resourceType, /*string?*/ name, /*System.Security.AccessControl.AccessControlSections*/ includeSections)
            {
                super.$ctor$4(false);
                {
                }
                return this;
            }
            $ctor$10(/*bool*/ isContainer, /*System.Security.AccessControl.ResourceType*/ resourceType, /*string?*/ name, /*System.Security.AccessControl.AccessControlSections*/ includeSections, /*System.Security.AccessControl.NativeObjectSecurity.ExceptionFromErrorCode?*/ exceptionFromErrorCode, /*object?*/ exceptionContext)
            {
                super.$ctor$4(false);
                {
                }
                return this;
            }
            /*void */ Persist$1(/*System.Runtime.InteropServices.SafeHandle*/ handle, /*System.Security.AccessControl.AccessControlSections*/ includeSections)
            {
            }
            /*void */ Persist$3(/*System.Runtime.InteropServices.SafeHandle*/ handle, /*System.Security.AccessControl.AccessControlSections*/ includeSections, /*object?*/ exceptionContext)
            {
            }
            /*void */ Persist$2(/*string*/ name, /*System.Security.AccessControl.AccessControlSections*/ includeSections)
            {
            }
            /*void */ Persist$4(/*string*/ name, /*System.Security.AccessControl.AccessControlSections*/ includeSections, /*object?*/ exceptionContext)
            {
            }
            static $_ExceptionFromErrorCode;
            static get ExceptionFromErrorCode()
            {
                let $cls = $.$ssa.System.Security.AccessControl.NativeObjectSecurity;
                return $cls.$_ExceptionFromErrorCode ??= $asm.$ncls("$ssa.System.Security.AccessControl.NativeObjectSecurity.ExceptionFromErrorCode", ($self) => class ExceptionFromErrorCode extends $.$spc.System.MulticastDelegate
                {
                    $ctor(/*object*/ target, fn)
                    {
                        this._target = target;
                        this.$nativeFunction = fn;
                        return this;
                    }
                    /*System.Exception?*/ Invoke(/*$.$spc.System.Int32*/ $errorCode, /*$.$spc.System.Nullable$$*/ $name, /*$.$spc.System.Nullable$$*/ $handle, /*$.$spc.System.Nullable$$*/ $context)
                    {
                        return this.$nativeFunction.apply(this._target, arguments);
                    }
                    static $h = 2080597;
                    static $f = 0b10000000010000000;
                    static $k = 5;
                    static $$md;
                    static get $md() { return this.$$md ??= {"b":66191361,"m":[{"r":47185921,"p":[{"n":"errorCode","p":655361},{"n":"name","p":1310721},{"n":"handle","p":109576193},{"n":"context","p":131073}],"n":"Invoke","d":2080597,"h":8592015189,"f":129},{"r":56950785,"p":[{"n":"errorCode","p":655361},{"n":"name","p":1310721},{"n":"handle","p":109576193},{"n":"context","p":131073},{"n":"callback","p":14417921},{"n":"object","p":131073}],"n":"BeginInvoke","d":2080597,"h":12886982485,"f":129},{"r":47185921,"p":[{"n":"result","p":56950785}],"n":"EndInvoke","d":2080597,"h":17181949781,"f":129}],"c":[{"p":[{"n":"object","p":131073},{"n":"method","p":786433}],"n":".ctor","o":"$ctor$5","d":2080597,"h":4297047893,"f":1}],"i":[57147393,113377281],"d":2015061,"h":2080597}; }
                    static get $b() { return $.$spc.System.MulticastDelegate; }
                    static $$i;
                    static get $i() { return this.$$i ??= [ $.$spc.System.ICloneable, $.$spc.System.Runtime.Serialization.ISerializable ]; }
                    static get $fullName() { return `System.Security.AccessControl.NativeObjectSecurity.ExceptionFromErrorCode`; }
                }, $cls, ($v) => $cls.$_ExceptionFromErrorCode = $v);
            }
            static $h = 2015061;
            static $f = 0b110001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":1228629,"m":[{"r":65537,"p":[{"n":"handle","p":109576193},{"n":"includeSections","p":245589}],"n":"Persist","o":"@$1","d":2015061,"h":30066786133,"f":98308},{"r":65537,"p":[{"n":"handle","p":109576193},{"n":"includeSections","p":245589},{"n":"exceptionContext","p":131073}],"n":"Persist","o":"@$3","d":2015061,"h":34361753429,"f":4},{"r":65537,"p":[{"n":"name","p":1310721},{"n":"includeSections","p":245589}],"n":"Persist","o":"@$2","d":2015061,"h":38656720725,"f":98308},{"r":65537,"p":[{"n":"name","p":1310721},{"n":"includeSections","p":245589},{"n":"exceptionContext","p":131073}],"n":"Persist","o":"@$4","d":2015061,"h":42951688021,"f":4}],"c":[{"p":[{"n":"isContainer","p":262145},{"n":"resourceType","p":2867029}],"n":".ctor","o":"$ctor$5","d":2015061,"h":4296982357,"f":4},{"p":[{"n":"isContainer","p":262145},{"n":"resourceType","p":2867029},{"n":"handle","p":109576193},{"n":"includeSections","p":245589}],"n":".ctor","o":"$ctor$6","d":2015061,"h":8591949653,"f":4},{"p":[{"n":"isContainer","p":262145},{"n":"resourceType","p":2867029},{"n":"handle","p":109576193},{"n":"includeSections","p":245589},{"n":"exceptionFromErrorCode","p":2080597},{"n":"exceptionContext","p":131073}],"n":".ctor","o":"$ctor$7","d":2015061,"h":12886916949,"f":4},{"p":[{"n":"isContainer","p":262145},{"n":"resourceType","p":2867029},{"n":"exceptionFromErrorCode","p":2080597},{"n":"exceptionContext","p":131073}],"n":".ctor","o":"$ctor$8","d":2015061,"h":17181884245,"f":4},{"p":[{"n":"isContainer","p":262145},{"n":"resourceType","p":2867029},{"n":"name","p":1310721},{"n":"includeSections","p":245589}],"n":".ctor","o":"$ctor$9","d":2015061,"h":21476851541,"f":4},{"p":[{"n":"isContainer","p":262145},{"n":"resourceType","p":2867029},{"n":"name","p":1310721},{"n":"includeSections","p":245589},{"n":"exceptionFromErrorCode","p":2080597},{"n":"exceptionContext","p":131073}],"n":".ctor","o":"$ctor$10","d":2015061,"h":25771818837,"f":4}],"j":[2080597],"h":2015061}; }
            static get $b() { return $.$ssa.System.Security.AccessControl.CommonObjectSecurity; }
            static get $fullName() { return `System.Security.AccessControl.NativeObjectSecurity`; }
        });
        
        $asm.$cls("$ssa.System.Security.AccessControl.ObjectAccessRule", ($self) => class ObjectAccessRule extends $.$ssa.System.Security.AccessControl.AccessRule
        {
            $ctor$3(/*System.Security.Principal.IdentityReference*/ identity, /*int*/ accessMask, /*bool*/ isInherited, /*System.Security.AccessControl.InheritanceFlags*/ inheritanceFlags, /*System.Security.AccessControl.PropagationFlags*/ propagationFlags, /*System.Guid*/ objectType, /*System.Guid*/ inheritedObjectType, /*System.Security.AccessControl.AccessControlType*/ type)
            {
                super.$ctor$2(null, 0, false, 0, 0, 0);
                {
                }
                return this;
            }
            /*System.Guid */ get InheritedObjectType()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Security.AccessControl.ObjectAceFlags */ get ObjectFlags()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Guid */ get ObjectType()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static $h = 2146133;
            static $f = 0b110001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":376661,"p":[{"p":56164353,"g":{"r":0,"d":0,"h":12887048021,"f":1},"n":"InheritedObjectType","d":2146133,"h":8592080725,"f":1},{"p":2277205,"g":{"r":0,"d":0,"h":21476982613,"f":1},"n":"ObjectFlags","d":2146133,"h":17182015317,"f":1},{"p":56164353,"g":{"r":0,"d":0,"h":30066917205,"f":1},"n":"ObjectType","d":2146133,"h":25771949909,"f":1}],"c":[{"p":[{"n":"identity","p":255816},{"n":"accessMask","p":655361},{"n":"isInherited","p":262145},{"n":"inheritanceFlags","p":1883989},{"n":"propagationFlags","p":2604885},{"n":"objectType","p":56164353},{"n":"inheritedObjectType","p":56164353},{"n":"type","p":311125}],"n":".ctor","o":"$ctor$3","d":2146133,"h":4297113429,"f":4}],"h":2146133}; }
            static get $b() { return $.$ssa.System.Security.AccessControl.AccessRule; }
            static get $fullName() { return `System.Security.AccessControl.ObjectAccessRule`; }
        });
        
        $asm.$cls("$ssa.System.Security.AccessControl.ObjectAuditRule", ($self) => class ObjectAuditRule extends $.$ssa.System.Security.AccessControl.AuditRule
        {
            $ctor$3(/*System.Security.Principal.IdentityReference*/ identity, /*int*/ accessMask, /*bool*/ isInherited, /*System.Security.AccessControl.InheritanceFlags*/ inheritanceFlags, /*System.Security.AccessControl.PropagationFlags*/ propagationFlags, /*System.Guid*/ objectType, /*System.Guid*/ inheritedObjectType, /*System.Security.AccessControl.AuditFlags*/ auditFlags)
            {
                super.$ctor$2(null, 0, false, 0, 0, 0);
                {
                }
                return this;
            }
            /*System.Guid */ get InheritedObjectType()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Security.AccessControl.ObjectAceFlags */ get ObjectFlags()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Guid */ get ObjectType()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static $h = 2342741;
            static $f = 0b110001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":835413,"p":[{"p":56164353,"g":{"r":0,"d":0,"h":12887244629,"f":1},"n":"InheritedObjectType","d":2342741,"h":8592277333,"f":1},{"p":2277205,"g":{"r":0,"d":0,"h":21477179221,"f":1},"n":"ObjectFlags","d":2342741,"h":17182211925,"f":1},{"p":56164353,"g":{"r":0,"d":0,"h":30067113813,"f":1},"n":"ObjectType","d":2342741,"h":25772146517,"f":1}],"c":[{"p":[{"n":"identity","p":255816},{"n":"accessMask","p":655361},{"n":"isInherited","p":262145},{"n":"inheritanceFlags","p":1883989},{"n":"propagationFlags","p":2604885},{"n":"objectType","p":56164353},{"n":"inheritedObjectType","p":56164353},{"n":"auditFlags","p":769877}],"n":".ctor","o":"$ctor$3","d":2342741,"h":4297310037,"f":4}],"h":2342741}; }
            static get $b() { return $.$ssa.System.Security.AccessControl.AuditRule; }
            static get $fullName() { return `System.Security.AccessControl.ObjectAuditRule`; }
        });
        
        $asm.$cls("$ssa.System.Security.AccessControl.QualifiedAce", ($self) => class QualifiedAce extends $.$ssa.System.Security.AccessControl.KnownAce
        {
            $ctor$3()
            {
                super.$ctor$2();
                {
                }
                return this;
            }
            /*System.Security.AccessControl.AceQualifier */ get AceQualifier()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get IsCallback()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ get OpaqueLength()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*byte[]? */ GetOpaque()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*void */ SetOpaque(/*byte[]?*/ opaque)
            {
            }
            static $h = 2670421;
            static $f = 0b110001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":1949525,"p":[{"p":638805,"g":{"r":0,"d":0,"h":12887572309,"f":1},"n":"AceQualifier","d":2670421,"h":8592605013,"f":1},{"p":262145,"g":{"r":0,"d":0,"h":21477506901,"f":1},"n":"IsCallback","d":2670421,"h":17182539605,"f":1},{"p":655361,"g":{"r":0,"d":0,"h":30067441493,"f":1},"n":"OpaqueLength","d":2670421,"h":25772474197,"f":1}],"m":[{"r":0,"n":"GetOpaque","d":2670421,"h":34362408789,"f":1},{"r":65537,"p":[{"n":"opaque","p":0}],"n":"SetOpaque","d":2670421,"h":38657376085,"f":1}],"c":[{"n":".ctor","o":"$ctor$3","d":2670421,"h":4297637717,"f":8}],"h":2670421}; }
            static get $b() { return $.$ssa.System.Security.AccessControl.KnownAce; }
            static get $fullName() { return `System.Security.AccessControl.QualifiedAce`; }
        });
        
        $asm.$cls("$ssa.System.Security.AccessControl.ObjectSecurity<>", (T) => $asm.$gt("$ssa.System.Security.AccessControl.ObjectSecurity<>", [T], ($self) => class ObjectSecurity$$ extends $.$ssa.System.Security.AccessControl.NativeObjectSecurity
        {
            $ctor$11(/*bool*/ isContainer, /*System.Security.AccessControl.ResourceType*/ resourceType)
            {
                super.$ctor$5(false, 0);
                {
                }
                return this;
            }
            $ctor$12(/*bool*/ isContainer, /*System.Security.AccessControl.ResourceType*/ resourceType, /*System.Runtime.InteropServices.SafeHandle?*/ safeHandle, /*System.Security.AccessControl.AccessControlSections*/ includeSections)
            {
                super.$ctor$5(false, 0);
                {
                }
                return this;
            }
            $ctor$13(/*bool*/ isContainer, /*System.Security.AccessControl.ResourceType*/ resourceType, /*System.Runtime.InteropServices.SafeHandle?*/ safeHandle, /*System.Security.AccessControl.AccessControlSections*/ includeSections, /*System.Security.AccessControl.NativeObjectSecurity.ExceptionFromErrorCode?*/ exceptionFromErrorCode, /*object?*/ exceptionContext)
            {
                super.$ctor$5(false, 0);
                {
                }
                return this;
            }
            $ctor$14(/*bool*/ isContainer, /*System.Security.AccessControl.ResourceType*/ resourceType, /*string?*/ name, /*System.Security.AccessControl.AccessControlSections*/ includeSections)
            {
                super.$ctor$5(false, 0);
                {
                }
                return this;
            }
            $ctor$15(/*bool*/ isContainer, /*System.Security.AccessControl.ResourceType*/ resourceType, /*string?*/ name, /*System.Security.AccessControl.AccessControlSections*/ includeSections, /*System.Security.AccessControl.NativeObjectSecurity.ExceptionFromErrorCode?*/ exceptionFromErrorCode, /*object?*/ exceptionContext)
            {
                super.$ctor$5(false, 0);
                {
                }
                return this;
            }
            /*System.Type */ get AccessRightType()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Type */ get AccessRuleType()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Type */ get AuditRuleType()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Security.AccessControl.AccessRule */ AccessRuleFactory(/*System.Security.Principal.IdentityReference*/ identityReference, /*int*/ accessMask, /*bool*/ isInherited, /*System.Security.AccessControl.InheritanceFlags*/ inheritanceFlags, /*System.Security.AccessControl.PropagationFlags*/ propagationFlags, /*System.Security.AccessControl.AccessControlType*/ type)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*void */ AddAccessRule$1(/*System.Security.AccessControl.AccessRule<T>*/ rule)
            {
            }
            /*void */ AddAuditRule$1(/*System.Security.AccessControl.AuditRule<T>*/ rule)
            {
            }
            /*System.Security.AccessControl.AuditRule */ AuditRuleFactory(/*System.Security.Principal.IdentityReference*/ identityReference, /*int*/ accessMask, /*bool*/ isInherited, /*System.Security.AccessControl.InheritanceFlags*/ inheritanceFlags, /*System.Security.AccessControl.PropagationFlags*/ propagationFlags, /*System.Security.AccessControl.AuditFlags*/ flags)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*void */ Persist$5(/*System.Runtime.InteropServices.SafeHandle*/ handle)
            {
            }
            /*void */ Persist$6(/*string*/ name)
            {
            }
            /*bool */ RemoveAccessRule$1(/*System.Security.AccessControl.AccessRule<T>*/ rule)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*void */ RemoveAccessRuleAll$1(/*System.Security.AccessControl.AccessRule<T>*/ rule)
            {
            }
            /*void */ RemoveAccessRuleSpecific$1(/*System.Security.AccessControl.AccessRule<T>*/ rule)
            {
            }
            /*bool */ RemoveAuditRule$1(/*System.Security.AccessControl.AuditRule<T>*/ rule)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*void */ RemoveAuditRuleAll$1(/*System.Security.AccessControl.AuditRule<T>*/ rule)
            {
            }
            /*void */ RemoveAuditRuleSpecific$1(/*System.Security.AccessControl.AuditRule<T>*/ rule)
            {
            }
            /*void */ ResetAccessRule$1(/*System.Security.AccessControl.AccessRule<T>*/ rule)
            {
            }
            /*void */ SetAccessRule$1(/*System.Security.AccessControl.AccessRule<T>*/ rule)
            {
            }
            /*void */ SetAuditRule$1(/*System.Security.AccessControl.AuditRule<T>*/ rule)
            {
            }
            static $h = 2473813;
            static $g = 1;
            static $f = 0b1110001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":2015061,"p":[{"p":142606337,"g":{"r":0,"d":0,"h":Number(BigInt(this.$h)|0x700000000n),"f":32769},"n":"AccessRightType","d":this.$h,"h":Number(BigInt(this.$h)|0x600000000n),"f":32769},{"p":142606337,"g":{"r":0,"d":0,"h":Number(BigInt(this.$h)|0x900000000n),"f":32769},"n":"AccessRuleType","d":this.$h,"h":Number(BigInt(this.$h)|0x800000000n),"f":32769},{"p":142606337,"g":{"r":0,"d":0,"h":Number(BigInt(this.$h)|0xB00000000n),"f":32769},"n":"AuditRuleType","d":this.$h,"h":Number(BigInt(this.$h)|0xA00000000n),"f":32769}],"m":[{"r":376661,"p":[{"n":"identityReference","p":255816},{"n":"accessMask","p":655361},{"n":"isInherited","p":262145},{"n":"inheritanceFlags","p":1883989},{"n":"propagationFlags","p":2604885},{"n":"type","p":311125}],"n":"AccessRuleFactory","d":this.$h,"h":Number(BigInt(this.$h)|0xC00000000n),"f":32769},{"r":65537,"p":[{"n":"rule","p":$.$ssa.System.Security.AccessControl.AccessRule$$(T).$h}],"n":"AddAccessRule","o":"@$1","d":this.$h,"h":Number(BigInt(this.$h)|0xD00000000n),"f":129},{"r":65537,"p":[{"n":"rule","p":$.$ssa.System.Security.AccessControl.AuditRule$$(T).$h}],"n":"AddAuditRule","o":"@$1","d":this.$h,"h":Number(BigInt(this.$h)|0xE00000000n),"f":129},{"r":835413,"p":[{"n":"identityReference","p":255816},{"n":"accessMask","p":655361},{"n":"isInherited","p":262145},{"n":"inheritanceFlags","p":1883989},{"n":"propagationFlags","p":2604885},{"n":"flags","p":769877}],"n":"AuditRuleFactory","d":this.$h,"h":Number(BigInt(this.$h)|0xF00000000n),"f":32769},{"r":65537,"p":[{"n":"handle","p":109576193}],"n":"Persist","o":"@$5","d":this.$h,"h":Number(BigInt(this.$h)|0x1000000000n),"f":16},{"r":65537,"p":[{"n":"name","p":1310721}],"n":"Persist","o":"@$6","d":this.$h,"h":Number(BigInt(this.$h)|0x1100000000n),"f":16},{"r":262145,"p":[{"n":"rule","p":$.$ssa.System.Security.AccessControl.AccessRule$$(T).$h}],"n":"RemoveAccessRule","o":"@$1","d":this.$h,"h":Number(BigInt(this.$h)|0x1200000000n),"f":129},{"r":65537,"p":[{"n":"rule","p":$.$ssa.System.Security.AccessControl.AccessRule$$(T).$h}],"n":"RemoveAccessRuleAll","o":"@$1","d":this.$h,"h":Number(BigInt(this.$h)|0x1300000000n),"f":129},{"r":65537,"p":[{"n":"rule","p":$.$ssa.System.Security.AccessControl.AccessRule$$(T).$h}],"n":"RemoveAccessRuleSpecific","o":"@$1","d":this.$h,"h":Number(BigInt(this.$h)|0x1400000000n),"f":129},{"r":262145,"p":[{"n":"rule","p":$.$ssa.System.Security.AccessControl.AuditRule$$(T).$h}],"n":"RemoveAuditRule","o":"@$1","d":this.$h,"h":Number(BigInt(this.$h)|0x1500000000n),"f":129},{"r":65537,"p":[{"n":"rule","p":$.$ssa.System.Security.AccessControl.AuditRule$$(T).$h}],"n":"RemoveAuditRuleAll","o":"@$1","d":this.$h,"h":Number(BigInt(this.$h)|0x1600000000n),"f":129},{"r":65537,"p":[{"n":"rule","p":$.$ssa.System.Security.AccessControl.AuditRule$$(T).$h}],"n":"RemoveAuditRuleSpecific","o":"@$1","d":this.$h,"h":Number(BigInt(this.$h)|0x1700000000n),"f":129},{"r":65537,"p":[{"n":"rule","p":$.$ssa.System.Security.AccessControl.AccessRule$$(T).$h}],"n":"ResetAccessRule","o":"@$1","d":this.$h,"h":Number(BigInt(this.$h)|0x1800000000n),"f":129},{"r":65537,"p":[{"n":"rule","p":$.$ssa.System.Security.AccessControl.AccessRule$$(T).$h}],"n":"SetAccessRule","o":"@$1","d":this.$h,"h":Number(BigInt(this.$h)|0x1900000000n),"f":129},{"r":65537,"p":[{"n":"rule","p":$.$ssa.System.Security.AccessControl.AuditRule$$(T).$h}],"n":"SetAuditRule","o":"@$1","d":this.$h,"h":Number(BigInt(this.$h)|0x1A00000000n),"f":129}],"c":[{"p":[{"n":"isContainer","p":262145},{"n":"resourceType","p":2867029}],"n":".ctor","o":"$ctor$11","d":this.$h,"h":Number(BigInt(this.$h)|0x100000000n),"f":4},{"p":[{"n":"isContainer","p":262145},{"n":"resourceType","p":2867029},{"n":"safeHandle","p":109576193},{"n":"includeSections","p":245589}],"n":".ctor","o":"$ctor$12","d":this.$h,"h":Number(BigInt(this.$h)|0x200000000n),"f":4},{"p":[{"n":"isContainer","p":262145},{"n":"resourceType","p":2867029},{"n":"safeHandle","p":109576193},{"n":"includeSections","p":245589},{"n":"exceptionFromErrorCode","p":2080597},{"n":"exceptionContext","p":131073}],"n":".ctor","o":"$ctor$13","d":this.$h,"h":Number(BigInt(this.$h)|0x300000000n),"f":4},{"p":[{"n":"isContainer","p":262145},{"n":"resourceType","p":2867029},{"n":"name","p":1310721},{"n":"includeSections","p":245589}],"n":".ctor","o":"$ctor$14","d":this.$h,"h":Number(BigInt(this.$h)|0x400000000n),"f":4},{"p":[{"n":"isContainer","p":262145},{"n":"resourceType","p":2867029},{"n":"name","p":1310721},{"n":"includeSections","p":245589},{"n":"exceptionFromErrorCode","p":2080597},{"n":"exceptionContext","p":131073}],"n":".ctor","o":"$ctor$15","d":this.$h,"h":Number(BigInt(this.$h)|0x500000000n),"f":4}],"g":[T?.$h??1507328],"s":[{"n":"T","f":2}],"r":1,"h":this.$h}; }
            static get $b() { return $.$ssa.System.Security.AccessControl.NativeObjectSecurity; }
            static get $fullName() { return `System.Security.AccessControl.ObjectSecurity<${T?.$fullName}>`; }
        }));
        
        $asm.$cls("$ssa.System.Security.AccessControl.AceEnumerator", ($self) => class AceEnumerator extends $.$spc.System.Object
        {
            $ctor$1()
            {
                super.$ctor();
                {
                }
                return this;
            }
            /*System.Security.AccessControl.GenericAce */ get Current()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*object */ get System$Collections$IEnumerator$Current()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ MoveNext()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*void */ Reset()
            {
            }
            //Generated interface implemetation for System.Collections.IEnumerator.MoveNext()
            System$Collections$IEnumerator$MoveNext()
            {
                return this.MoveNext(...arguments);
            }
            //Generated interface implemetation for System.Collections.IEnumerator.Reset()
            System$Collections$IEnumerator$Reset()
            {
                return this.Reset(...arguments);
            }
            static $h = 507733;
            static $f = 0b10010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":1687381,"g":{"r":0,"d":0,"h":12885409621,"f":1},"n":"Current","d":507733,"h":8590442325,"f":1},{"p":131073,"g":{"r":0,"d":0,"h":21475344213,"f":2},"n":"{31719425}.Current","o":"System$Collections$IEnumerator$Current","d":507733,"h":17180376917,"f":2}],"m":[{"r":262145,"n":"MoveNext","d":507733,"h":25770311509,"f":1},{"r":65537,"n":"Reset","d":507733,"h":30065278805,"f":1}],"c":[{"n":".ctor","o":"$ctor$1","d":507733,"h":4295475029,"f":8}],"i":[31719425],"h":507733}; }
            static get $b() { return $.$spc.System.Object; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.Collections.IEnumerator ]; }
            static get $fullName() { return `System.Security.AccessControl.AceEnumerator`; }
        });
        
        $asm.$cls("$ssa.System.Security.Policy.Evidence", ($self) => class Evidence extends $.$spc.System.Object
        {
            $ctor$1()
            {
                super.$ctor();
                {
                }
                return this;
            }
            $ctor$2(/*object[]*/ hostEvidence, /*object[]*/ assemblyEvidence)
            {
                super.$ctor();
                {
                }
                return this;
            }
            $ctor$3(/*System.Security.Policy.Evidence*/ evidence)
            {
                super.$ctor();
                {
                }
                return this;
            }
            $ctor$4(/*System.Security.Policy.EvidenceBase[]*/ hostEvidence, /*System.Security.Policy.EvidenceBase[]*/ assemblyEvidence)
            {
                super.$ctor();
                {
                }
                return this;
            }
            /*int */ get Count()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get IsReadOnly()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get IsSynchronized()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get Locked()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ set Locked(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*object */ get SyncRoot()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*void */ AddAssembly(/*object*/ id)
            {
            }
            /*void */ AddAssemblyEvidence(T, /*T*/ evidence)
            {
            }
            /*void */ AddHost(/*object*/ id)
            {
            }
            /*void */ AddHostEvidence(T, /*T*/ evidence)
            {
            }
            /*void */ Clear()
            {
            }
            /*System.Security.Policy.Evidence? */ Clone()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*void */ CopyTo(/*System.Array*/ array, /*int*/ index)
            {
            }
            /*System.Collections.IEnumerator */ GetAssemblyEnumerator()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*T? */ GetAssemblyEvidence(T, )
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Collections.IEnumerator */ GetEnumerator()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Collections.IEnumerator */ GetHostEnumerator()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*T? */ GetHostEvidence(T, )
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*void */ Merge(/*System.Security.Policy.Evidence*/ evidence)
            {
            }
            /*void */ RemoveType(/*System.Type*/ t)
            {
            }
            //Generated interface implemetation for System.Collections.ICollection.CopyTo(System.Array, int)
            System$Collections$ICollection$CopyTo()
            {
                return this.CopyTo(...arguments);
            }
            //Generated interface implemetation for System.Collections.ICollection.Count.get
            get System$Collections$ICollection$Count()
            {
                return this.Count;
            }
            //Generated interface implemetation for System.Collections.ICollection.SyncRoot.get
            get System$Collections$ICollection$SyncRoot()
            {
                return this.SyncRoot;
            }
            //Generated interface implemetation for System.Collections.ICollection.IsSynchronized.get
            get System$Collections$ICollection$IsSynchronized()
            {
                return this.IsSynchronized;
            }
            //Generated interface implemetation for System.Collections.IEnumerable.GetEnumerator()
            System$Collections$IEnumerable$GetEnumerator()
            {
                return this.GetEnumerator(...arguments);
            }
            static $h = 3063637;
            static $f = 0b10010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":655361,"g":{"r":0,"d":0,"h":25772867413,"f":1},"n":"Count","d":3063637,"h":21477900117,"f":1,"a":[{"t":70909953,"c":8660844545,"a":[{"v":"Evidence should not be treated as an ICollection. Use GetHostEnumerator and GetAssemblyEnumerator to iterate over the evidence to collect a count.","t":1310721}]}]},{"p":262145,"g":{"r":0,"d":0,"h":34362802005,"f":1},"n":"IsReadOnly","d":3063637,"h":30067834709,"f":1},{"p":262145,"g":{"r":0,"d":0,"h":42952736597,"f":1},"n":"IsSynchronized","d":3063637,"h":38657769301,"f":1},{"p":262145,"g":{"r":0,"d":0,"h":51542671189,"f":1},"s":{"r":0,"d":0,"h":55837638485,"f":1},"n":"Locked","d":3063637,"h":47247703893,"f":1},{"p":131073,"g":{"r":0,"d":0,"h":64427573077,"f":1},"n":"SyncRoot","d":3063637,"h":60132605781,"f":1}],"m":[{"r":65537,"p":[{"n":"id","p":131073}],"n":"AddAssembly","d":3063637,"h":68722540373,"f":1,"a":[{"t":70909953,"c":8660844545,"a":[{"v":"Evidence.AddAssembly has been deprecated. Use AddAssemblyEvidence instead.","t":1310721}]}]},{"r":65537,"p":[{"n":"evidence","p":(T) => T.$h}],"g":["T"],"n":"AddAssemblyEvidence","d":3063637,"h":73017507669,"f":131073},{"r":65537,"p":[{"n":"id","p":131073}],"n":"AddHost","d":3063637,"h":77312474965,"f":1,"a":[{"t":70909953,"c":8660844545,"a":[{"v":"Evidence.AddHost has been deprecated. Use AddHostEvidence instead.","t":1310721}]}]},{"r":65537,"p":[{"n":"evidence","p":(T) => T.$h}],"g":["T"],"n":"AddHostEvidence","d":3063637,"h":81607442261,"f":131073},{"r":65537,"n":"Clear","d":3063637,"h":85902409557,"f":1},{"r":3063637,"n":"Clone","d":3063637,"h":90197376853,"f":1},{"r":65537,"p":[{"n":"array","p":1245185},{"n":"index","p":655361}],"n":"CopyTo","d":3063637,"h":94492344149,"f":1,"a":[{"t":70909953,"c":8660844545,"a":[{"v":"Evidence should not be treated as an ICollection. Use the GetHostEnumerator and GetAssemblyEnumerator methods rather than using CopyTo.","t":1310721}]}]},{"r":31719425,"n":"GetAssemblyEnumerator","d":3063637,"h":98787311445,"f":1},{"r":(T) => T.$h,"g":["T"],"n":"GetAssemblyEvidence","d":3063637,"h":103082278741,"f":131073},{"r":31719425,"n":"GetEnumerator","d":3063637,"h":107377246037,"f":1,"a":[{"t":70909953,"c":8660844545,"a":[{"v":"GetEnumerator is obsolete. Use GetAssemblyEnumerator and GetHostEnumerator instead.","t":1310721}]}]},{"r":31719425,"n":"GetHostEnumerator","d":3063637,"h":111672213333,"f":1},{"r":(T) => T.$h,"g":["T"],"n":"GetHostEvidence","d":3063637,"h":115967180629,"f":131073},{"r":65537,"p":[{"n":"evidence","p":3063637}],"n":"Merge","d":3063637,"h":120262147925,"f":1},{"r":65537,"p":[{"n":"t","p":142606337}],"n":"RemoveType","d":3063637,"h":124557115221,"f":1}],"c":[{"n":".ctor","o":"$ctor$1","d":3063637,"h":4298030933,"f":1},{"p":[{"n":"hostEvidence","p":0},{"n":"assemblyEvidence","p":0}],"n":".ctor","o":"$ctor$2","d":3063637,"h":8592998229,"f":1,"a":[{"t":70909953,"c":8660844545,"a":[{"v":"This constructor is obsolete. Use the constructor which accepts arrays of EvidenceBase instead.","t":1310721}]}]},{"p":[{"n":"evidence","p":3063637}],"n":".ctor","o":"$ctor$3","d":3063637,"h":12887965525,"f":1},{"p":[{"n":"hostEvidence","p":0},{"n":"assemblyEvidence","p":0}],"n":".ctor","o":"$ctor$4","d":3063637,"h":17182932821,"f":1}],"i":[31326209,31588353],"h":3063637}; }
            static get $b() { return $.$spc.System.Object; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.Collections.ICollection, $.$spc.System.Collections.IEnumerable ]; }
            static get $fullName() { return `System.Security.Policy.Evidence`; }
        });
        
        $asm.$cls("$ssa.System.Security.AccessControl.CommonSecurityDescriptor", ($self) => class CommonSecurityDescriptor extends $.$ssa.System.Security.AccessControl.GenericSecurityDescriptor
        {
            $ctor$2(/*bool*/ isContainer, /*bool*/ isDS, /*byte[]*/ binaryForm, /*int*/ offset)
            {
                super.$ctor$1();
                {
                }
                return this;
            }
            $ctor$3(/*bool*/ isContainer, /*bool*/ isDS, /*System.Security.AccessControl.ControlFlags*/ flags, /*System.Security.Principal.SecurityIdentifier?*/ owner, /*System.Security.Principal.SecurityIdentifier?*/ group, /*System.Security.AccessControl.SystemAcl?*/ systemAcl, /*System.Security.AccessControl.DiscretionaryAcl?*/ discretionaryAcl)
            {
                super.$ctor$1();
                {
                }
                return this;
            }
            $ctor$4(/*bool*/ isContainer, /*bool*/ isDS, /*System.Security.AccessControl.RawSecurityDescriptor*/ rawSecurityDescriptor)
            {
                super.$ctor$1();
                {
                }
                return this;
            }
            $ctor$5(/*bool*/ isContainer, /*bool*/ isDS, /*string*/ sddlForm)
            {
                super.$ctor$1();
                {
                }
                return this;
            }
            /*System.Security.AccessControl.ControlFlags */ get ControlFlags()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Security.AccessControl.DiscretionaryAcl? */ get DiscretionaryAcl()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Security.AccessControl.DiscretionaryAcl? */ set DiscretionaryAcl(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Security.Principal.SecurityIdentifier? */ get Group()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Security.Principal.SecurityIdentifier? */ set Group(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get IsContainer()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get IsDiscretionaryAclCanonical()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get IsDS()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get IsSystemAclCanonical()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Security.Principal.SecurityIdentifier? */ get Owner()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Security.Principal.SecurityIdentifier? */ set Owner(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Security.AccessControl.SystemAcl? */ get SystemAcl()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Security.AccessControl.SystemAcl? */ set SystemAcl(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*void */ AddDiscretionaryAcl(/*byte*/ revision, /*int*/ trusted)
            {
            }
            /*void */ AddSystemAcl(/*byte*/ revision, /*int*/ trusted)
            {
            }
            /*void */ PurgeAccessControl(/*System.Security.Principal.SecurityIdentifier*/ sid)
            {
            }
            /*void */ PurgeAudit(/*System.Security.Principal.SecurityIdentifier*/ sid)
            {
            }
            /*void */ SetDiscretionaryAclProtection(/*bool*/ isProtected, /*bool*/ preserveInheritance)
            {
            }
            /*void */ SetSystemAclProtection(/*bool*/ isProtected, /*bool*/ preserveInheritance)
            {
            }
            static $h = 1294165;
            static $f = 0b10010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":1818453,"p":[{"p":1490773,"g":{"r":0,"d":0,"h":25771097941,"f":32769},"n":"ControlFlags","d":1294165,"h":21476130645,"f":32769},{"p":1621845,"g":{"r":0,"d":0,"h":34361032533,"f":1},"s":{"r":0,"d":0,"h":38655999829,"f":1},"n":"DiscretionaryAcl","d":1294165,"h":30066065237,"f":1},{"p":452424,"g":{"r":0,"d":0,"h":47245934421,"f":32769},"s":{"r":0,"d":0,"h":51540901717,"f":32769},"n":"Group","d":1294165,"h":42950967125,"f":32769},{"p":262145,"g":{"r":0,"d":0,"h":60130836309,"f":1},"n":"IsContainer","d":1294165,"h":55835869013,"f":1},{"p":262145,"g":{"r":0,"d":0,"h":68720770901,"f":1},"n":"IsDiscretionaryAclCanonical","d":1294165,"h":64425803605,"f":1},{"p":262145,"g":{"r":0,"d":0,"h":77310705493,"f":1},"n":"IsDS","d":1294165,"h":73015738197,"f":1},{"p":262145,"g":{"r":0,"d":0,"h":85900640085,"f":1},"n":"IsSystemAclCanonical","d":1294165,"h":81605672789,"f":1},{"p":452424,"g":{"r":0,"d":0,"h":94490574677,"f":32769},"s":{"r":0,"d":0,"h":98785541973,"f":32769},"n":"Owner","d":1294165,"h":90195607381,"f":32769},{"p":2998101,"g":{"r":0,"d":0,"h":107375476565,"f":1},"s":{"r":0,"d":0,"h":111670443861,"f":1},"n":"SystemAcl","d":1294165,"h":103080509269,"f":1}],"m":[{"r":65537,"p":[{"n":"revision","p":393217},{"n":"trusted","p":655361}],"n":"AddDiscretionaryAcl","d":1294165,"h":115965411157,"f":1},{"r":65537,"p":[{"n":"revision","p":393217},{"n":"trusted","p":655361}],"n":"AddSystemAcl","d":1294165,"h":120260378453,"f":1},{"r":65537,"p":[{"n":"sid","p":452424}],"n":"PurgeAccessControl","d":1294165,"h":124555345749,"f":1},{"r":65537,"p":[{"n":"sid","p":452424}],"n":"PurgeAudit","d":1294165,"h":128850313045,"f":1},{"r":65537,"p":[{"n":"isProtected","p":262145},{"n":"preserveInheritance","p":262145}],"n":"SetDiscretionaryAclProtection","d":1294165,"h":133145280341,"f":1},{"r":65537,"p":[{"n":"isProtected","p":262145},{"n":"preserveInheritance","p":262145}],"n":"SetSystemAclProtection","d":1294165,"h":137440247637,"f":1}],"c":[{"p":[{"n":"isContainer","p":262145},{"n":"isDS","p":262145},{"n":"binaryForm","p":0},{"n":"offset","p":655361}],"n":".ctor","o":"$ctor$2","d":1294165,"h":4296261461,"f":1},{"p":[{"n":"isContainer","p":262145},{"n":"isDS","p":262145},{"n":"flags","p":1490773},{"n":"owner","p":452424},{"n":"group","p":452424},{"n":"systemAcl","p":2998101},{"n":"discretionaryAcl","p":1621845}],"n":".ctor","o":"$ctor$3","d":1294165,"h":8591228757,"f":1},{"p":[{"n":"isContainer","p":262145},{"n":"isDS","p":262145},{"n":"rawSecurityDescriptor","p":2801493}],"n":".ctor","o":"$ctor$4","d":1294165,"h":12886196053,"f":1},{"p":[{"n":"isContainer","p":262145},{"n":"isDS","p":262145},{"n":"sddlForm","p":1310721}],"n":".ctor","o":"$ctor$5","d":1294165,"h":17181163349,"f":1}],"h":1294165}; }
            static get $b() { return $.$ssa.System.Security.AccessControl.GenericSecurityDescriptor; }
            static get $fullName() { return `System.Security.AccessControl.CommonSecurityDescriptor`; }
        });
        
        $asm.$cls("$ssa.System.Security.AccessControl.CustomAce", ($self) => class CustomAce extends $.$ssa.System.Security.AccessControl.GenericAce
        {
            /*int*/ static MaxOpaqueLength = 0;
            $ctor$2(/*System.Security.AccessControl.AceType*/ type, /*System.Security.AccessControl.AceFlags*/ flags, /*byte[]?*/ opaque)
            {
                super.$ctor$1();
                {
                }
                return this;
            }
            /*int */ get BinaryLength()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ get OpaqueLength()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*void */ GetBinaryForm(/*byte[]*/ binaryForm, /*int*/ offset)
            {
            }
            /*byte[]? */ GetOpaque()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*void */ SetOpaque(/*byte[]?*/ opaque)
            {
            }
            static $h = 1556309;
            static $f = 0b10010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":1687381,"p":[{"p":655361,"g":{"r":0,"d":0,"h":17181425493,"f":32769},"n":"BinaryLength","d":1556309,"h":12886458197,"f":32769},{"p":655361,"g":{"r":0,"d":0,"h":25771360085,"f":1},"n":"OpaqueLength","d":1556309,"h":21476392789,"f":1}],"m":[{"r":65537,"p":[{"n":"binaryForm","p":0},{"n":"offset","p":655361}],"n":"GetBinaryForm","d":1556309,"h":30066327381,"f":32769},{"r":0,"n":"GetOpaque","d":1556309,"h":34361294677,"f":1},{"r":65537,"p":[{"n":"opaque","p":0}],"n":"SetOpaque","d":1556309,"h":38656261973,"f":1}],"l":[{"t":655361,"n":"MaxOpaqueLength","d":1556309,"h":4296523605,"f":33}],"c":[{"p":[{"n":"type","p":704341},{"n":"flags","p":573269},{"n":"opaque","p":0}],"n":".ctor","o":"$ctor$2","d":1556309,"h":8591490901,"f":1}],"h":1556309}; }
            static get $b() { return $.$ssa.System.Security.AccessControl.GenericAce; }
            static get $fullName() { return `System.Security.AccessControl.CustomAce`; }
        });
        
        $asm.$cls("$ssa.System.Security.AccessControl.RawSecurityDescriptor", ($self) => class RawSecurityDescriptor extends $.$ssa.System.Security.AccessControl.GenericSecurityDescriptor
        {
            $ctor$2(/*byte[]*/ binaryForm, /*int*/ offset)
            {
                super.$ctor$1();
                {
                }
                return this;
            }
            $ctor$3(/*System.Security.AccessControl.ControlFlags*/ flags, /*System.Security.Principal.SecurityIdentifier?*/ owner, /*System.Security.Principal.SecurityIdentifier?*/ group, /*System.Security.AccessControl.RawAcl?*/ systemAcl, /*System.Security.AccessControl.RawAcl?*/ discretionaryAcl)
            {
                super.$ctor$1();
                {
                }
                return this;
            }
            $ctor$4(/*string*/ sddlForm)
            {
                super.$ctor$1();
                {
                }
                return this;
            }
            /*System.Security.AccessControl.ControlFlags */ get ControlFlags()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Security.AccessControl.RawAcl? */ get DiscretionaryAcl()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Security.AccessControl.RawAcl? */ set DiscretionaryAcl(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Security.Principal.SecurityIdentifier? */ get Group()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Security.Principal.SecurityIdentifier? */ set Group(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Security.Principal.SecurityIdentifier? */ get Owner()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Security.Principal.SecurityIdentifier? */ set Owner(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*byte */ get ResourceManagerControl()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*byte */ set ResourceManagerControl(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Security.AccessControl.RawAcl? */ get SystemAcl()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Security.AccessControl.RawAcl? */ set SystemAcl(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*void */ SetFlags(/*System.Security.AccessControl.ControlFlags*/ flags)
            {
            }
            static $h = 2801493;
            static $f = 0b10010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":1818453,"p":[{"p":1490773,"g":{"r":0,"d":0,"h":21477637973,"f":32769},"n":"ControlFlags","d":2801493,"h":17182670677,"f":32769},{"p":2735957,"g":{"r":0,"d":0,"h":30067572565,"f":1},"s":{"r":0,"d":0,"h":34362539861,"f":1},"n":"DiscretionaryAcl","d":2801493,"h":25772605269,"f":1},{"p":452424,"g":{"r":0,"d":0,"h":42952474453,"f":32769},"s":{"r":0,"d":0,"h":47247441749,"f":32769},"n":"Group","d":2801493,"h":38657507157,"f":32769},{"p":452424,"g":{"r":0,"d":0,"h":55837376341,"f":32769},"s":{"r":0,"d":0,"h":60132343637,"f":32769},"n":"Owner","d":2801493,"h":51542409045,"f":32769},{"p":393217,"g":{"r":0,"d":0,"h":68722278229,"f":1},"s":{"r":0,"d":0,"h":73017245525,"f":1},"n":"ResourceManagerControl","d":2801493,"h":64427310933,"f":1},{"p":2735957,"g":{"r":0,"d":0,"h":81607180117,"f":1},"s":{"r":0,"d":0,"h":85902147413,"f":1},"n":"SystemAcl","d":2801493,"h":77312212821,"f":1}],"m":[{"r":65537,"p":[{"n":"flags","p":1490773}],"n":"SetFlags","d":2801493,"h":90197114709,"f":1}],"c":[{"p":[{"n":"binaryForm","p":0},{"n":"offset","p":655361}],"n":".ctor","o":"$ctor$2","d":2801493,"h":4297768789,"f":1},{"p":[{"n":"flags","p":1490773},{"n":"owner","p":452424},{"n":"group","p":452424},{"n":"systemAcl","p":2735957},{"n":"discretionaryAcl","p":2735957}],"n":".ctor","o":"$ctor$3","d":2801493,"h":8592736085,"f":1},{"p":[{"n":"sddlForm","p":1310721}],"n":".ctor","o":"$ctor$4","d":2801493,"h":12887703381,"f":1}],"h":2801493}; }
            static get $b() { return $.$ssa.System.Security.AccessControl.GenericSecurityDescriptor; }
            static get $fullName() { return `System.Security.AccessControl.RawSecurityDescriptor`; }
        });
        
        $asm.$cls("$ssa.System.Security.AccessControl.AuthorizationRuleCollection", ($self) => class AuthorizationRuleCollection extends $.$scn.System.Collections.ReadOnlyCollectionBase
        {
            $ctor$2()
            {
                super.$ctor$1();
                {
                }
                return this;
            }
            /*System.Security.AccessControl.AuthorizationRule?*/ get_Item(/*int*/ index)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*void */ AddRule(/*System.Security.AccessControl.AuthorizationRule?*/ rule)
            {
            }
            /*void */ CopyTo(/*System.Security.AccessControl.AuthorizationRule[]*/ rules, /*int*/ index)
            {
            }
            static $h = 1032021;
            static $f = 0b10010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":589859,"p":[{"p":966485,"i":[{"n":"index","p":655361}],"g":{"r":0,"d":0,"h":12885933909,"f":1},"n":"Item","o":"@$2","d":1032021,"h":8590966613,"f":1}],"m":[{"r":65537,"p":[{"n":"rule","p":966485}],"n":"AddRule","d":1032021,"h":17180901205,"f":1},{"r":65537,"p":[{"n":"rules","p":0},{"n":"index","p":655361}],"n":"CopyTo","d":1032021,"h":21475868501,"f":1}],"c":[{"n":".ctor","o":"$ctor$2","d":1032021,"h":4295999317,"f":1}],"i":[31326209,31588353],"h":1032021}; }
            static get $b() { return $.$scn.System.Collections.ReadOnlyCollectionBase; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.Collections.ICollection, $.$spc.System.Collections.IEnumerable ]; }
            static get $fullName() { return `System.Security.AccessControl.AuthorizationRuleCollection`; }
        });
        
        $asm.$cls("$ssa.System.Security.AccessControl.RawAcl", ($self) => class RawAcl extends $.$ssa.System.Security.AccessControl.GenericAcl
        {
            $ctor$2(/*byte*/ revision, /*int*/ capacity)
            {
                super.$ctor$1();
                {
                }
                return this;
            }
            $ctor$3(/*byte[]*/ binaryForm, /*int*/ offset)
            {
                super.$ctor$1();
                {
                }
                return this;
            }
            /*int */ get BinaryLength()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ get Count()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Security.AccessControl.GenericAce*/ get_Item(/*int*/ index)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*void*/ set_Item(/*int*/ index, /*System.Security.AccessControl.GenericAce*/ value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*byte */ get Revision()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*void */ GetBinaryForm(/*byte[]*/ binaryForm, /*int*/ offset)
            {
            }
            /*void */ InsertAce(/*int*/ index, /*System.Security.AccessControl.GenericAce*/ ace)
            {
            }
            /*void */ RemoveAce(/*int*/ index)
            {
            }
            static $h = 2735957;
            static $f = 0b10010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":1752917,"p":[{"p":655361,"g":{"r":0,"d":0,"h":17182605141,"f":32769},"n":"BinaryLength","d":2735957,"h":12887637845,"f":32769},{"p":655361,"g":{"r":0,"d":0,"h":25772539733,"f":32769},"n":"Count","d":2735957,"h":21477572437,"f":32769},{"p":1687381,"i":[{"n":"index","p":655361}],"g":{"r":0,"d":0,"h":34362474325,"f":32769},"s":{"r":0,"d":0,"h":38657441621,"f":32769},"n":"Item","o":"@$2","d":2735957,"h":30067507029,"f":32769},{"p":393217,"g":{"r":0,"d":0,"h":47247376213,"f":32769},"n":"Revision","d":2735957,"h":42952408917,"f":32769}],"m":[{"r":65537,"p":[{"n":"binaryForm","p":0},{"n":"offset","p":655361}],"n":"GetBinaryForm","d":2735957,"h":51542343509,"f":32769},{"r":65537,"p":[{"n":"index","p":655361},{"n":"ace","p":1687381}],"n":"InsertAce","d":2735957,"h":55837310805,"f":1},{"r":65537,"p":[{"n":"index","p":655361}],"n":"RemoveAce","d":2735957,"h":60132278101,"f":1}],"c":[{"p":[{"n":"revision","p":393217},{"n":"capacity","p":655361}],"n":".ctor","o":"$ctor$2","d":2735957,"h":4297703253,"f":1},{"p":[{"n":"binaryForm","p":0},{"n":"offset","p":655361}],"n":".ctor","o":"$ctor$3","d":2735957,"h":8592670549,"f":1}],"i":[31326209,31588353],"h":2735957}; }
            static get $b() { return $.$ssa.System.Security.AccessControl.GenericAcl; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.Collections.ICollection, $.$spc.System.Collections.IEnumerable ]; }
            static get $fullName() { return `System.Security.AccessControl.RawAcl`; }
        });
        
        $asm.$cls("$ssa.System.Security.AccessControl.AccessRule<>", (T) => $asm.$gt("$ssa.System.Security.AccessControl.AccessRule<>", [T], ($self) => class AccessRule$$ extends $.$ssa.System.Security.AccessControl.AccessRule
        {
            $ctor$3(/*System.Security.Principal.IdentityReference*/ identity, /*T*/ rights, /*System.Security.AccessControl.AccessControlType*/ type)
            {
                super.$ctor$2(null, 0, false, 0, 0, 0);
                {
                }
                return this;
            }
            $ctor$4(/*System.Security.Principal.IdentityReference*/ identity, /*T*/ rights, /*System.Security.AccessControl.InheritanceFlags*/ inheritanceFlags, /*System.Security.AccessControl.PropagationFlags*/ propagationFlags, /*System.Security.AccessControl.AccessControlType*/ type)
            {
                super.$ctor$2(null, 0, false, 0, 0, 0);
                {
                }
                return this;
            }
            $ctor$5(/*string*/ identity, /*T*/ rights, /*System.Security.AccessControl.AccessControlType*/ type)
            {
                super.$ctor$2(null, 0, false, 0, 0, 0);
                {
                }
                return this;
            }
            $ctor$6(/*string*/ identity, /*T*/ rights, /*System.Security.AccessControl.InheritanceFlags*/ inheritanceFlags, /*System.Security.AccessControl.PropagationFlags*/ propagationFlags, /*System.Security.AccessControl.AccessControlType*/ type)
            {
                super.$ctor$2(null, 0, false, 0, 0, 0);
                {
                }
                return this;
            }
            /*T */ get Rights()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static $h = 442197;
            static $g = 1;
            static $f = 0b1010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":376661,"p":[{"p":T?.$h??1507328,"g":{"r":0,"d":0,"h":Number(BigInt(this.$h)|0x600000000n),"f":1},"n":"Rights","d":this.$h,"h":Number(BigInt(this.$h)|0x500000000n),"f":1}],"c":[{"p":[{"n":"identity","p":255816},{"n":"rights","p":T?.$h??1507328},{"n":"type","p":311125}],"n":".ctor","o":"$ctor$3","d":this.$h,"h":Number(BigInt(this.$h)|0x100000000n),"f":1},{"p":[{"n":"identity","p":255816},{"n":"rights","p":T?.$h??1507328},{"n":"inheritanceFlags","p":1883989},{"n":"propagationFlags","p":2604885},{"n":"type","p":311125}],"n":".ctor","o":"$ctor$4","d":this.$h,"h":Number(BigInt(this.$h)|0x200000000n),"f":1},{"p":[{"n":"identity","p":1310721},{"n":"rights","p":T?.$h??1507328},{"n":"type","p":311125}],"n":".ctor","o":"$ctor$5","d":this.$h,"h":Number(BigInt(this.$h)|0x300000000n),"f":1},{"p":[{"n":"identity","p":1310721},{"n":"rights","p":T?.$h??1507328},{"n":"inheritanceFlags","p":1883989},{"n":"propagationFlags","p":2604885},{"n":"type","p":311125}],"n":".ctor","o":"$ctor$6","d":this.$h,"h":Number(BigInt(this.$h)|0x400000000n),"f":1}],"g":[T?.$h??1507328],"s":[{"n":"T","f":2}],"r":1,"h":this.$h}; }
            static get $b() { return $.$ssa.System.Security.AccessControl.AccessRule; }
            static get $fullName() { return `System.Security.AccessControl.AccessRule<${T?.$fullName}>`; }
        }));
        
        $asm.$cls("$ssa.System.Security.AccessControl.AuditRule<>", (T) => $asm.$gt("$ssa.System.Security.AccessControl.AuditRule<>", [T], ($self) => class AuditRule$$ extends $.$ssa.System.Security.AccessControl.AuditRule
        {
            $ctor$3(/*System.Security.Principal.IdentityReference*/ identity, /*T*/ rights, /*System.Security.AccessControl.AuditFlags*/ flags)
            {
                super.$ctor$2(null, 0, false, 0, 0, 0);
                {
                }
                return this;
            }
            $ctor$4(/*System.Security.Principal.IdentityReference*/ identity, /*T*/ rights, /*System.Security.AccessControl.InheritanceFlags*/ inheritanceFlags, /*System.Security.AccessControl.PropagationFlags*/ propagationFlags, /*System.Security.AccessControl.AuditFlags*/ flags)
            {
                super.$ctor$2(null, 0, false, 0, 0, 0);
                {
                }
                return this;
            }
            $ctor$5(/*string*/ identity, /*T*/ rights, /*System.Security.AccessControl.AuditFlags*/ flags)
            {
                super.$ctor$2(null, 0, false, 0, 0, 0);
                {
                }
                return this;
            }
            $ctor$6(/*string*/ identity, /*T*/ rights, /*System.Security.AccessControl.InheritanceFlags*/ inheritanceFlags, /*System.Security.AccessControl.PropagationFlags*/ propagationFlags, /*System.Security.AccessControl.AuditFlags*/ flags)
            {
                super.$ctor$2(null, 0, false, 0, 0, 0);
                {
                }
                return this;
            }
            /*T */ get Rights()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static $h = 900949;
            static $g = 1;
            static $f = 0b1010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":835413,"p":[{"p":T?.$h??1507328,"g":{"r":0,"d":0,"h":Number(BigInt(this.$h)|0x600000000n),"f":1},"n":"Rights","d":this.$h,"h":Number(BigInt(this.$h)|0x500000000n),"f":1}],"c":[{"p":[{"n":"identity","p":255816},{"n":"rights","p":T?.$h??1507328},{"n":"flags","p":769877}],"n":".ctor","o":"$ctor$3","d":this.$h,"h":Number(BigInt(this.$h)|0x100000000n),"f":1},{"p":[{"n":"identity","p":255816},{"n":"rights","p":T?.$h??1507328},{"n":"inheritanceFlags","p":1883989},{"n":"propagationFlags","p":2604885},{"n":"flags","p":769877}],"n":".ctor","o":"$ctor$4","d":this.$h,"h":Number(BigInt(this.$h)|0x200000000n),"f":1},{"p":[{"n":"identity","p":1310721},{"n":"rights","p":T?.$h??1507328},{"n":"flags","p":769877}],"n":".ctor","o":"$ctor$5","d":this.$h,"h":Number(BigInt(this.$h)|0x300000000n),"f":1},{"p":[{"n":"identity","p":1310721},{"n":"rights","p":T?.$h??1507328},{"n":"inheritanceFlags","p":1883989},{"n":"propagationFlags","p":2604885},{"n":"flags","p":769877}],"n":".ctor","o":"$ctor$6","d":this.$h,"h":Number(BigInt(this.$h)|0x400000000n),"f":1}],"g":[T?.$h??1507328],"s":[{"n":"T","f":2}],"r":1,"h":this.$h}; }
            static get $b() { return $.$ssa.System.Security.AccessControl.AuditRule; }
            static get $fullName() { return `System.Security.AccessControl.AuditRule<${T?.$fullName}>`; }
        }));
        
        $asm.$cls("$ssa.System.Security.AccessControl.CompoundAce", ($self) => class CompoundAce extends $.$ssa.System.Security.AccessControl.KnownAce
        {
            $ctor$3(/*System.Security.AccessControl.AceFlags*/ flags, /*int*/ accessMask, /*System.Security.AccessControl.CompoundAceType*/ compoundAceType, /*System.Security.Principal.SecurityIdentifier*/ sid)
            {
                super.$ctor$2();
                {
                }
                return this;
            }
            /*int */ get BinaryLength()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Security.AccessControl.CompoundAceType */ get CompoundAceType()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Security.AccessControl.CompoundAceType */ set CompoundAceType(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*void */ GetBinaryForm(/*byte[]*/ binaryForm, /*int*/ offset)
            {
            }
            static $h = 1359701;
            static $f = 0b10010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":1949525,"p":[{"p":655361,"g":{"r":0,"d":0,"h":12886261589,"f":32769},"n":"BinaryLength","d":1359701,"h":8591294293,"f":32769},{"p":1425237,"g":{"r":0,"d":0,"h":21476196181,"f":1},"s":{"r":0,"d":0,"h":25771163477,"f":1},"n":"CompoundAceType","d":1359701,"h":17181228885,"f":1}],"m":[{"r":65537,"p":[{"n":"binaryForm","p":0},{"n":"offset","p":655361}],"n":"GetBinaryForm","d":1359701,"h":30066130773,"f":32769}],"c":[{"p":[{"n":"flags","p":573269},{"n":"accessMask","p":655361},{"n":"compoundAceType","p":1425237},{"n":"sid","p":452424}],"n":".ctor","o":"$ctor$3","d":1359701,"h":4296326997,"f":1}],"h":1359701}; }
            static get $b() { return $.$ssa.System.Security.AccessControl.KnownAce; }
            static get $fullName() { return `System.Security.AccessControl.CompoundAce`; }
        });
        
        $asm.$cls("$ssa.System.Security.AccessControl.DiscretionaryAcl", ($self) => class DiscretionaryAcl extends $.$ssa.System.Security.AccessControl.CommonAcl
        {
            $ctor$3(/*bool*/ isContainer, /*bool*/ isDS, /*byte*/ revision, /*int*/ capacity)
            {
                super.$ctor$2();
                {
                }
                return this;
            }
            $ctor$4(/*bool*/ isContainer, /*bool*/ isDS, /*int*/ capacity)
            {
                super.$ctor$2();
                {
                }
                return this;
            }
            $ctor$5(/*bool*/ isContainer, /*bool*/ isDS, /*System.Security.AccessControl.RawAcl?*/ rawAcl)
            {
                super.$ctor$2();
                {
                }
                return this;
            }
            /*void */ AddAccess(/*System.Security.AccessControl.AccessControlType*/ accessType, /*System.Security.Principal.SecurityIdentifier*/ sid, /*int*/ accessMask, /*System.Security.AccessControl.InheritanceFlags*/ inheritanceFlags, /*System.Security.AccessControl.PropagationFlags*/ propagationFlags)
            {
            }
            /*void */ AddAccess$1(/*System.Security.AccessControl.AccessControlType*/ accessType, /*System.Security.Principal.SecurityIdentifier*/ sid, /*int*/ accessMask, /*System.Security.AccessControl.InheritanceFlags*/ inheritanceFlags, /*System.Security.AccessControl.PropagationFlags*/ propagationFlags, /*System.Security.AccessControl.ObjectAceFlags*/ objectFlags, /*System.Guid*/ objectType, /*System.Guid*/ inheritedObjectType)
            {
            }
            /*void */ AddAccess$2(/*System.Security.AccessControl.AccessControlType*/ accessType, /*System.Security.Principal.SecurityIdentifier*/ sid, /*System.Security.AccessControl.ObjectAccessRule*/ rule)
            {
            }
            /*bool */ RemoveAccess(/*System.Security.AccessControl.AccessControlType*/ accessType, /*System.Security.Principal.SecurityIdentifier*/ sid, /*int*/ accessMask, /*System.Security.AccessControl.InheritanceFlags*/ inheritanceFlags, /*System.Security.AccessControl.PropagationFlags*/ propagationFlags)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ RemoveAccess$1(/*System.Security.AccessControl.AccessControlType*/ accessType, /*System.Security.Principal.SecurityIdentifier*/ sid, /*int*/ accessMask, /*System.Security.AccessControl.InheritanceFlags*/ inheritanceFlags, /*System.Security.AccessControl.PropagationFlags*/ propagationFlags, /*System.Security.AccessControl.ObjectAceFlags*/ objectFlags, /*System.Guid*/ objectType, /*System.Guid*/ inheritedObjectType)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ RemoveAccess$2(/*System.Security.AccessControl.AccessControlType*/ accessType, /*System.Security.Principal.SecurityIdentifier*/ sid, /*System.Security.AccessControl.ObjectAccessRule*/ rule)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*void */ RemoveAccessSpecific(/*System.Security.AccessControl.AccessControlType*/ accessType, /*System.Security.Principal.SecurityIdentifier*/ sid, /*int*/ accessMask, /*System.Security.AccessControl.InheritanceFlags*/ inheritanceFlags, /*System.Security.AccessControl.PropagationFlags*/ propagationFlags)
            {
            }
            /*void */ RemoveAccessSpecific$1(/*System.Security.AccessControl.AccessControlType*/ accessType, /*System.Security.Principal.SecurityIdentifier*/ sid, /*int*/ accessMask, /*System.Security.AccessControl.InheritanceFlags*/ inheritanceFlags, /*System.Security.AccessControl.PropagationFlags*/ propagationFlags, /*System.Security.AccessControl.ObjectAceFlags*/ objectFlags, /*System.Guid*/ objectType, /*System.Guid*/ inheritedObjectType)
            {
            }
            /*void */ RemoveAccessSpecific$2(/*System.Security.AccessControl.AccessControlType*/ accessType, /*System.Security.Principal.SecurityIdentifier*/ sid, /*System.Security.AccessControl.ObjectAccessRule*/ rule)
            {
            }
            /*void */ SetAccess(/*System.Security.AccessControl.AccessControlType*/ accessType, /*System.Security.Principal.SecurityIdentifier*/ sid, /*int*/ accessMask, /*System.Security.AccessControl.InheritanceFlags*/ inheritanceFlags, /*System.Security.AccessControl.PropagationFlags*/ propagationFlags)
            {
            }
            /*void */ SetAccess$1(/*System.Security.AccessControl.AccessControlType*/ accessType, /*System.Security.Principal.SecurityIdentifier*/ sid, /*int*/ accessMask, /*System.Security.AccessControl.InheritanceFlags*/ inheritanceFlags, /*System.Security.AccessControl.PropagationFlags*/ propagationFlags, /*System.Security.AccessControl.ObjectAceFlags*/ objectFlags, /*System.Guid*/ objectType, /*System.Guid*/ inheritedObjectType)
            {
            }
            /*void */ SetAccess$2(/*System.Security.AccessControl.AccessControlType*/ accessType, /*System.Security.Principal.SecurityIdentifier*/ sid, /*System.Security.AccessControl.ObjectAccessRule*/ rule)
            {
            }
            static $h = 1621845;
            static $f = 0b10010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":1163093,"m":[{"r":65537,"p":[{"n":"accessType","p":311125},{"n":"sid","p":452424},{"n":"accessMask","p":655361},{"n":"inheritanceFlags","p":1883989},{"n":"propagationFlags","p":2604885}],"n":"AddAccess","d":1621845,"h":17181491029,"f":1},{"r":65537,"p":[{"n":"accessType","p":311125},{"n":"sid","p":452424},{"n":"accessMask","p":655361},{"n":"inheritanceFlags","p":1883989},{"n":"propagationFlags","p":2604885},{"n":"objectFlags","p":2277205},{"n":"objectType","p":56164353},{"n":"inheritedObjectType","p":56164353}],"n":"AddAccess","o":"@$1","d":1621845,"h":21476458325,"f":1},{"r":65537,"p":[{"n":"accessType","p":311125},{"n":"sid","p":452424},{"n":"rule","p":2146133}],"n":"AddAccess","o":"@$2","d":1621845,"h":25771425621,"f":1},{"r":262145,"p":[{"n":"accessType","p":311125},{"n":"sid","p":452424},{"n":"accessMask","p":655361},{"n":"inheritanceFlags","p":1883989},{"n":"propagationFlags","p":2604885}],"n":"RemoveAccess","d":1621845,"h":30066392917,"f":1},{"r":262145,"p":[{"n":"accessType","p":311125},{"n":"sid","p":452424},{"n":"accessMask","p":655361},{"n":"inheritanceFlags","p":1883989},{"n":"propagationFlags","p":2604885},{"n":"objectFlags","p":2277205},{"n":"objectType","p":56164353},{"n":"inheritedObjectType","p":56164353}],"n":"RemoveAccess","o":"@$1","d":1621845,"h":34361360213,"f":1},{"r":262145,"p":[{"n":"accessType","p":311125},{"n":"sid","p":452424},{"n":"rule","p":2146133}],"n":"RemoveAccess","o":"@$2","d":1621845,"h":38656327509,"f":1},{"r":65537,"p":[{"n":"accessType","p":311125},{"n":"sid","p":452424},{"n":"accessMask","p":655361},{"n":"inheritanceFlags","p":1883989},{"n":"propagationFlags","p":2604885}],"n":"RemoveAccessSpecific","d":1621845,"h":42951294805,"f":1},{"r":65537,"p":[{"n":"accessType","p":311125},{"n":"sid","p":452424},{"n":"accessMask","p":655361},{"n":"inheritanceFlags","p":1883989},{"n":"propagationFlags","p":2604885},{"n":"objectFlags","p":2277205},{"n":"objectType","p":56164353},{"n":"inheritedObjectType","p":56164353}],"n":"RemoveAccessSpecific","o":"@$1","d":1621845,"h":47246262101,"f":1},{"r":65537,"p":[{"n":"accessType","p":311125},{"n":"sid","p":452424},{"n":"rule","p":2146133}],"n":"RemoveAccessSpecific","o":"@$2","d":1621845,"h":51541229397,"f":1},{"r":65537,"p":[{"n":"accessType","p":311125},{"n":"sid","p":452424},{"n":"accessMask","p":655361},{"n":"inheritanceFlags","p":1883989},{"n":"propagationFlags","p":2604885}],"n":"SetAccess","d":1621845,"h":55836196693,"f":1},{"r":65537,"p":[{"n":"accessType","p":311125},{"n":"sid","p":452424},{"n":"accessMask","p":655361},{"n":"inheritanceFlags","p":1883989},{"n":"propagationFlags","p":2604885},{"n":"objectFlags","p":2277205},{"n":"objectType","p":56164353},{"n":"inheritedObjectType","p":56164353}],"n":"SetAccess","o":"@$1","d":1621845,"h":60131163989,"f":1},{"r":65537,"p":[{"n":"accessType","p":311125},{"n":"sid","p":452424},{"n":"rule","p":2146133}],"n":"SetAccess","o":"@$2","d":1621845,"h":64426131285,"f":1}],"c":[{"p":[{"n":"isContainer","p":262145},{"n":"isDS","p":262145},{"n":"revision","p":393217},{"n":"capacity","p":655361}],"n":".ctor","o":"$ctor$3","d":1621845,"h":4296589141,"f":1},{"p":[{"n":"isContainer","p":262145},{"n":"isDS","p":262145},{"n":"capacity","p":655361}],"n":".ctor","o":"$ctor$4","d":1621845,"h":8591556437,"f":1},{"p":[{"n":"isContainer","p":262145},{"n":"isDS","p":262145},{"n":"rawAcl","p":2735957}],"n":".ctor","o":"$ctor$5","d":1621845,"h":12886523733,"f":1}],"i":[31326209,31588353],"h":1621845}; }
            static get $b() { return $.$ssa.System.Security.AccessControl.CommonAcl; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.Collections.ICollection, $.$spc.System.Collections.IEnumerable ]; }
            static get $fullName() { return `System.Security.AccessControl.DiscretionaryAcl`; }
        });
        
        $asm.$cls("$ssa.System.Security.AccessControl.SystemAcl", ($self) => class SystemAcl extends $.$ssa.System.Security.AccessControl.CommonAcl
        {
            $ctor$3(/*bool*/ isContainer, /*bool*/ isDS, /*byte*/ revision, /*int*/ capacity)
            {
                super.$ctor$2();
                {
                }
                return this;
            }
            $ctor$4(/*bool*/ isContainer, /*bool*/ isDS, /*int*/ capacity)
            {
                super.$ctor$2();
                {
                }
                return this;
            }
            $ctor$5(/*bool*/ isContainer, /*bool*/ isDS, /*System.Security.AccessControl.RawAcl*/ rawAcl)
            {
                super.$ctor$2();
                {
                }
                return this;
            }
            /*void */ AddAudit(/*System.Security.AccessControl.AuditFlags*/ auditFlags, /*System.Security.Principal.SecurityIdentifier*/ sid, /*int*/ accessMask, /*System.Security.AccessControl.InheritanceFlags*/ inheritanceFlags, /*System.Security.AccessControl.PropagationFlags*/ propagationFlags)
            {
            }
            /*void */ AddAudit$1(/*System.Security.AccessControl.AuditFlags*/ auditFlags, /*System.Security.Principal.SecurityIdentifier*/ sid, /*int*/ accessMask, /*System.Security.AccessControl.InheritanceFlags*/ inheritanceFlags, /*System.Security.AccessControl.PropagationFlags*/ propagationFlags, /*System.Security.AccessControl.ObjectAceFlags*/ objectFlags, /*System.Guid*/ objectType, /*System.Guid*/ inheritedObjectType)
            {
            }
            /*void */ AddAudit$2(/*System.Security.Principal.SecurityIdentifier*/ sid, /*System.Security.AccessControl.ObjectAuditRule*/ rule)
            {
            }
            /*bool */ RemoveAudit(/*System.Security.AccessControl.AuditFlags*/ auditFlags, /*System.Security.Principal.SecurityIdentifier*/ sid, /*int*/ accessMask, /*System.Security.AccessControl.InheritanceFlags*/ inheritanceFlags, /*System.Security.AccessControl.PropagationFlags*/ propagationFlags)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ RemoveAudit$1(/*System.Security.AccessControl.AuditFlags*/ auditFlags, /*System.Security.Principal.SecurityIdentifier*/ sid, /*int*/ accessMask, /*System.Security.AccessControl.InheritanceFlags*/ inheritanceFlags, /*System.Security.AccessControl.PropagationFlags*/ propagationFlags, /*System.Security.AccessControl.ObjectAceFlags*/ objectFlags, /*System.Guid*/ objectType, /*System.Guid*/ inheritedObjectType)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ RemoveAudit$2(/*System.Security.Principal.SecurityIdentifier*/ sid, /*System.Security.AccessControl.ObjectAuditRule*/ rule)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*void */ RemoveAuditSpecific(/*System.Security.AccessControl.AuditFlags*/ auditFlags, /*System.Security.Principal.SecurityIdentifier*/ sid, /*int*/ accessMask, /*System.Security.AccessControl.InheritanceFlags*/ inheritanceFlags, /*System.Security.AccessControl.PropagationFlags*/ propagationFlags)
            {
            }
            /*void */ RemoveAuditSpecific$1(/*System.Security.AccessControl.AuditFlags*/ auditFlags, /*System.Security.Principal.SecurityIdentifier*/ sid, /*int*/ accessMask, /*System.Security.AccessControl.InheritanceFlags*/ inheritanceFlags, /*System.Security.AccessControl.PropagationFlags*/ propagationFlags, /*System.Security.AccessControl.ObjectAceFlags*/ objectFlags, /*System.Guid*/ objectType, /*System.Guid*/ inheritedObjectType)
            {
            }
            /*void */ RemoveAuditSpecific$2(/*System.Security.Principal.SecurityIdentifier*/ sid, /*System.Security.AccessControl.ObjectAuditRule*/ rule)
            {
            }
            /*void */ SetAudit(/*System.Security.AccessControl.AuditFlags*/ auditFlags, /*System.Security.Principal.SecurityIdentifier*/ sid, /*int*/ accessMask, /*System.Security.AccessControl.InheritanceFlags*/ inheritanceFlags, /*System.Security.AccessControl.PropagationFlags*/ propagationFlags)
            {
            }
            /*void */ SetAudit$1(/*System.Security.AccessControl.AuditFlags*/ auditFlags, /*System.Security.Principal.SecurityIdentifier*/ sid, /*int*/ accessMask, /*System.Security.AccessControl.InheritanceFlags*/ inheritanceFlags, /*System.Security.AccessControl.PropagationFlags*/ propagationFlags, /*System.Security.AccessControl.ObjectAceFlags*/ objectFlags, /*System.Guid*/ objectType, /*System.Guid*/ inheritedObjectType)
            {
            }
            /*void */ SetAudit$2(/*System.Security.Principal.SecurityIdentifier*/ sid, /*System.Security.AccessControl.ObjectAuditRule*/ rule)
            {
            }
            static $h = 2998101;
            static $f = 0b10010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":1163093,"m":[{"r":65537,"p":[{"n":"auditFlags","p":769877},{"n":"sid","p":452424},{"n":"accessMask","p":655361},{"n":"inheritanceFlags","p":1883989},{"n":"propagationFlags","p":2604885}],"n":"AddAudit","d":2998101,"h":17182867285,"f":1},{"r":65537,"p":[{"n":"auditFlags","p":769877},{"n":"sid","p":452424},{"n":"accessMask","p":655361},{"n":"inheritanceFlags","p":1883989},{"n":"propagationFlags","p":2604885},{"n":"objectFlags","p":2277205},{"n":"objectType","p":56164353},{"n":"inheritedObjectType","p":56164353}],"n":"AddAudit","o":"@$1","d":2998101,"h":21477834581,"f":1},{"r":65537,"p":[{"n":"sid","p":452424},{"n":"rule","p":2342741}],"n":"AddAudit","o":"@$2","d":2998101,"h":25772801877,"f":1},{"r":262145,"p":[{"n":"auditFlags","p":769877},{"n":"sid","p":452424},{"n":"accessMask","p":655361},{"n":"inheritanceFlags","p":1883989},{"n":"propagationFlags","p":2604885}],"n":"RemoveAudit","d":2998101,"h":30067769173,"f":1},{"r":262145,"p":[{"n":"auditFlags","p":769877},{"n":"sid","p":452424},{"n":"accessMask","p":655361},{"n":"inheritanceFlags","p":1883989},{"n":"propagationFlags","p":2604885},{"n":"objectFlags","p":2277205},{"n":"objectType","p":56164353},{"n":"inheritedObjectType","p":56164353}],"n":"RemoveAudit","o":"@$1","d":2998101,"h":34362736469,"f":1},{"r":262145,"p":[{"n":"sid","p":452424},{"n":"rule","p":2342741}],"n":"RemoveAudit","o":"@$2","d":2998101,"h":38657703765,"f":1},{"r":65537,"p":[{"n":"auditFlags","p":769877},{"n":"sid","p":452424},{"n":"accessMask","p":655361},{"n":"inheritanceFlags","p":1883989},{"n":"propagationFlags","p":2604885}],"n":"RemoveAuditSpecific","d":2998101,"h":42952671061,"f":1},{"r":65537,"p":[{"n":"auditFlags","p":769877},{"n":"sid","p":452424},{"n":"accessMask","p":655361},{"n":"inheritanceFlags","p":1883989},{"n":"propagationFlags","p":2604885},{"n":"objectFlags","p":2277205},{"n":"objectType","p":56164353},{"n":"inheritedObjectType","p":56164353}],"n":"RemoveAuditSpecific","o":"@$1","d":2998101,"h":47247638357,"f":1},{"r":65537,"p":[{"n":"sid","p":452424},{"n":"rule","p":2342741}],"n":"RemoveAuditSpecific","o":"@$2","d":2998101,"h":51542605653,"f":1},{"r":65537,"p":[{"n":"auditFlags","p":769877},{"n":"sid","p":452424},{"n":"accessMask","p":655361},{"n":"inheritanceFlags","p":1883989},{"n":"propagationFlags","p":2604885}],"n":"SetAudit","d":2998101,"h":55837572949,"f":1},{"r":65537,"p":[{"n":"auditFlags","p":769877},{"n":"sid","p":452424},{"n":"accessMask","p":655361},{"n":"inheritanceFlags","p":1883989},{"n":"propagationFlags","p":2604885},{"n":"objectFlags","p":2277205},{"n":"objectType","p":56164353},{"n":"inheritedObjectType","p":56164353}],"n":"SetAudit","o":"@$1","d":2998101,"h":60132540245,"f":1},{"r":65537,"p":[{"n":"sid","p":452424},{"n":"rule","p":2342741}],"n":"SetAudit","o":"@$2","d":2998101,"h":64427507541,"f":1}],"c":[{"p":[{"n":"isContainer","p":262145},{"n":"isDS","p":262145},{"n":"revision","p":393217},{"n":"capacity","p":655361}],"n":".ctor","o":"$ctor$3","d":2998101,"h":4297965397,"f":1},{"p":[{"n":"isContainer","p":262145},{"n":"isDS","p":262145},{"n":"capacity","p":655361}],"n":".ctor","o":"$ctor$4","d":2998101,"h":8592932693,"f":1},{"p":[{"n":"isContainer","p":262145},{"n":"isDS","p":262145},{"n":"rawAcl","p":2735957}],"n":".ctor","o":"$ctor$5","d":2998101,"h":12887899989,"f":1}],"i":[31326209,31588353],"h":2998101}; }
            static get $b() { return $.$ssa.System.Security.AccessControl.CommonAcl; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.Collections.ICollection, $.$spc.System.Collections.IEnumerable ]; }
            static get $fullName() { return `System.Security.AccessControl.SystemAcl`; }
        });
        
        $asm.$str("$ssa.System.Security.AccessControl.AccessControlActions", ($self) => class AccessControlActions extends $.$spc.System.Enum
        {
            static None = 0;
            static View = 1;
            static Change = 2;
            static $map;
            static get Map()
            {
                return this.$map ??= 
                {
                    "None": 0n,
                    "View": 1n,
                    "Change": 2n
                };
            }
            static $h = 114517;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static get $eut() { return $.$spc.System.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {"b":1048577,"u":655361,"l":[{"t":114517,"n":"None","d":114517,"h":4295081813,"f":33},{"t":114517,"n":"View","d":114517,"h":8590049109,"f":33},{"t":114517,"n":"Change","d":114517,"h":12885016405,"f":33}],"c":[{"n":".ctor","o":"$ctor$3","d":114517,"h":17179983701,"f":1}],"i":[57212929,63766529,57671681,57344001],"h":114517,"a":[{"t":47644673,"c":4342611969}]}; }
            static get $b() { return $.$spc.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IComparable, $.$spc.System.ISpanFormattable, $.$spc.System.IFormattable, $.$spc.System.IConvertible ]; }
            static get $fullName() { return `System.Security.AccessControl.AccessControlActions`; }
        });
        
        $asm.$str("$ssa.System.Security.AccessControl.AccessControlModification", ($self) => class AccessControlModification extends $.$spc.System.Enum
        {
            static Add = 0;
            static Set = 1;
            static Reset = 2;
            static Remove = 3;
            static RemoveAll = 4;
            static RemoveSpecific = 5;
            static $map;
            static get Map()
            {
                return this.$map ??= 
                {
                    "Add": 0n,
                    "Set": 1n,
                    "Reset": 2n,
                    "Remove": 3n,
                    "RemoveAll": 4n,
                    "RemoveSpecific": 5n
                };
            }
            static $h = 180053;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static get $eut() { return $.$spc.System.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {"b":1048577,"u":655361,"l":[{"t":180053,"n":"Add","d":180053,"h":4295147349,"f":33},{"t":180053,"n":"Set","d":180053,"h":8590114645,"f":33},{"t":180053,"n":"Reset","d":180053,"h":12885081941,"f":33},{"t":180053,"n":"Remove","d":180053,"h":17180049237,"f":33},{"t":180053,"n":"RemoveAll","d":180053,"h":21475016533,"f":33},{"t":180053,"n":"RemoveSpecific","d":180053,"h":25769983829,"f":33}],"c":[{"n":".ctor","o":"$ctor$3","d":180053,"h":30064951125,"f":1}],"i":[57212929,63766529,57671681,57344001],"h":180053}; }
            static get $b() { return $.$spc.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IComparable, $.$spc.System.ISpanFormattable, $.$spc.System.IFormattable, $.$spc.System.IConvertible ]; }
            static get $fullName() { return `System.Security.AccessControl.AccessControlModification`; }
        });
        
        $asm.$str("$ssa.System.Security.AccessControl.AccessControlSections", ($self) => class AccessControlSections extends $.$spc.System.Enum
        {
            static None = 0;
            static Audit = 1;
            static Access = 2;
            static Owner = 4;
            static Group = 8;
            static All = 15;
            static $map;
            static get Map()
            {
                return this.$map ??= 
                {
                    "None": 0n,
                    "Audit": 1n,
                    "Access": 2n,
                    "Owner": 4n,
                    "Group": 8n,
                    "All": 15n
                };
            }
            static $h = 245589;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static get $eut() { return $.$spc.System.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {"b":1048577,"u":655361,"l":[{"t":245589,"n":"None","d":245589,"h":4295212885,"f":33},{"t":245589,"n":"Audit","d":245589,"h":8590180181,"f":33},{"t":245589,"n":"Access","d":245589,"h":12885147477,"f":33},{"t":245589,"n":"Owner","d":245589,"h":17180114773,"f":33},{"t":245589,"n":"Group","d":245589,"h":21475082069,"f":33},{"t":245589,"n":"All","d":245589,"h":25770049365,"f":33}],"c":[{"n":".ctor","o":"$ctor$3","d":245589,"h":30065016661,"f":1}],"i":[57212929,63766529,57671681,57344001],"h":245589,"a":[{"t":47644673,"c":4342611969}]}; }
            static get $b() { return $.$spc.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IComparable, $.$spc.System.ISpanFormattable, $.$spc.System.IFormattable, $.$spc.System.IConvertible ]; }
            static get $fullName() { return `System.Security.AccessControl.AccessControlSections`; }
        });
        
        $asm.$str("$ssa.System.Security.AccessControl.AccessControlType", ($self) => class AccessControlType extends $.$spc.System.Enum
        {
            static Allow = 0;
            static Deny = 1;
            static $map;
            static get Map()
            {
                return this.$map ??= 
                {
                    "Allow": 0n,
                    "Deny": 1n
                };
            }
            static $h = 311125;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static get $eut() { return $.$spc.System.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {"b":1048577,"u":655361,"l":[{"t":311125,"n":"Allow","d":311125,"h":4295278421,"f":33},{"t":311125,"n":"Deny","d":311125,"h":8590245717,"f":33}],"c":[{"n":".ctor","o":"$ctor$3","d":311125,"h":12885213013,"f":1}],"i":[57212929,63766529,57671681,57344001],"h":311125}; }
            static get $b() { return $.$spc.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IComparable, $.$spc.System.ISpanFormattable, $.$spc.System.IFormattable, $.$spc.System.IConvertible ]; }
            static get $fullName() { return `System.Security.AccessControl.AccessControlType`; }
        });
        
        $asm.$str("$ssa.System.Security.AccessControl.AceFlags", ($self) => class AceFlags extends $.$spc.System.Enum
        {
            static None = 0;
            static ObjectInherit = 1;
            static ContainerInherit = 2;
            static NoPropagateInherit = 4;
            static InheritOnly = 8;
            static InheritanceFlags = 15;
            static Inherited = 16;
            static SuccessfulAccess = 64;
            static FailedAccess = 128;
            static AuditFlags = 192;
            static $map;
            static get Map()
            {
                return this.$map ??= 
                {
                    "None": 0n,
                    "ObjectInherit": 1n,
                    "ContainerInherit": 2n,
                    "NoPropagateInherit": 4n,
                    "InheritOnly": 8n,
                    "InheritanceFlags": 15n,
                    "Inherited": 16n,
                    "SuccessfulAccess": 64n,
                    "FailedAccess": 128n,
                    "AuditFlags": 192n
                };
            }
            static $h = 573269;
            static $z = 1;
            static $f = 0b100000011010001001;
            static $k = 4;
            static get $eut() { return $.$spc.System.Byte; }
            static $$md;
            static get $md() { return this.$$md ??= {"b":1048577,"u":393217,"l":[{"t":573269,"n":"None","d":573269,"h":4295540565,"f":33},{"t":573269,"n":"ObjectInherit","d":573269,"h":8590507861,"f":33},{"t":573269,"n":"ContainerInherit","d":573269,"h":12885475157,"f":33},{"t":573269,"n":"NoPropagateInherit","d":573269,"h":17180442453,"f":33},{"t":573269,"n":"InheritOnly","d":573269,"h":21475409749,"f":33},{"t":573269,"n":"InheritanceFlags","d":573269,"h":25770377045,"f":33},{"t":573269,"n":"Inherited","d":573269,"h":30065344341,"f":33},{"t":573269,"n":"SuccessfulAccess","d":573269,"h":34360311637,"f":33},{"t":573269,"n":"FailedAccess","d":573269,"h":38655278933,"f":33},{"t":573269,"n":"AuditFlags","d":573269,"h":42950246229,"f":33}],"c":[{"n":".ctor","o":"$ctor$3","d":573269,"h":47245213525,"f":1}],"i":[57212929,63766529,57671681,57344001],"h":573269,"a":[{"t":47644673,"c":4342611969}]}; }
            static get $b() { return $.$spc.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IComparable, $.$spc.System.ISpanFormattable, $.$spc.System.IFormattable, $.$spc.System.IConvertible ]; }
            static get $fullName() { return `System.Security.AccessControl.AceFlags`; }
        });
        
        $asm.$str("$ssa.System.Security.AccessControl.AceQualifier", ($self) => class AceQualifier extends $.$spc.System.Enum
        {
            static AccessAllowed = 0;
            static AccessDenied = 1;
            static SystemAudit = 2;
            static SystemAlarm = 3;
            static $map;
            static get Map()
            {
                return this.$map ??= 
                {
                    "AccessAllowed": 0n,
                    "AccessDenied": 1n,
                    "SystemAudit": 2n,
                    "SystemAlarm": 3n
                };
            }
            static $h = 638805;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static get $eut() { return $.$spc.System.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {"b":1048577,"u":655361,"l":[{"t":638805,"n":"AccessAllowed","d":638805,"h":4295606101,"f":33},{"t":638805,"n":"AccessDenied","d":638805,"h":8590573397,"f":33},{"t":638805,"n":"SystemAudit","d":638805,"h":12885540693,"f":33},{"t":638805,"n":"SystemAlarm","d":638805,"h":17180507989,"f":33}],"c":[{"n":".ctor","o":"$ctor$3","d":638805,"h":21475475285,"f":1}],"i":[57212929,63766529,57671681,57344001],"h":638805}; }
            static get $b() { return $.$spc.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IComparable, $.$spc.System.ISpanFormattable, $.$spc.System.IFormattable, $.$spc.System.IConvertible ]; }
            static get $fullName() { return `System.Security.AccessControl.AceQualifier`; }
        });
        
        $asm.$str("$ssa.System.Security.AccessControl.AceType", ($self) => class AceType extends $.$spc.System.Enum
        {
            static AccessAllowed = 0;
            static AccessDenied = 1;
            static SystemAudit = 2;
            static SystemAlarm = 3;
            static AccessAllowedCompound = 4;
            static AccessAllowedObject = 5;
            static AccessDeniedObject = 6;
            static SystemAuditObject = 7;
            static SystemAlarmObject = 8;
            static AccessAllowedCallback = 9;
            static AccessDeniedCallback = 10;
            static AccessAllowedCallbackObject = 11;
            static AccessDeniedCallbackObject = 12;
            static SystemAuditCallback = 13;
            static SystemAlarmCallback = 14;
            static SystemAuditCallbackObject = 15;
            static MaxDefinedAceType = 16;
            static SystemAlarmCallbackObject = 16;
            static $map;
            static get Map()
            {
                return this.$map ??= 
                {
                    "AccessAllowed": 0n,
                    "AccessDenied": 1n,
                    "SystemAudit": 2n,
                    "SystemAlarm": 3n,
                    "AccessAllowedCompound": 4n,
                    "AccessAllowedObject": 5n,
                    "AccessDeniedObject": 6n,
                    "SystemAuditObject": 7n,
                    "SystemAlarmObject": 8n,
                    "AccessAllowedCallback": 9n,
                    "AccessDeniedCallback": 10n,
                    "AccessAllowedCallbackObject": 11n,
                    "AccessDeniedCallbackObject": 12n,
                    "SystemAuditCallback": 13n,
                    "SystemAlarmCallback": 14n,
                    "SystemAuditCallbackObject": 15n,
                    "MaxDefinedAceType": 16n,
                    "SystemAlarmCallbackObject": 16n
                };
            }
            static $h = 704341;
            static $z = 1;
            static $f = 0b100000011010001001;
            static $k = 4;
            static get $eut() { return $.$spc.System.Byte; }
            static $$md;
            static get $md() { return this.$$md ??= {"b":1048577,"u":393217,"l":[{"t":704341,"n":"AccessAllowed","d":704341,"h":4295671637,"f":33},{"t":704341,"n":"AccessDenied","d":704341,"h":8590638933,"f":33},{"t":704341,"n":"SystemAudit","d":704341,"h":12885606229,"f":33},{"t":704341,"n":"SystemAlarm","d":704341,"h":17180573525,"f":33},{"t":704341,"n":"AccessAllowedCompound","d":704341,"h":21475540821,"f":33},{"t":704341,"n":"AccessAllowedObject","d":704341,"h":25770508117,"f":33},{"t":704341,"n":"AccessDeniedObject","d":704341,"h":30065475413,"f":33},{"t":704341,"n":"SystemAuditObject","d":704341,"h":34360442709,"f":33},{"t":704341,"n":"SystemAlarmObject","d":704341,"h":38655410005,"f":33},{"t":704341,"n":"AccessAllowedCallback","d":704341,"h":42950377301,"f":33},{"t":704341,"n":"AccessDeniedCallback","d":704341,"h":47245344597,"f":33},{"t":704341,"n":"AccessAllowedCallbackObject","d":704341,"h":51540311893,"f":33},{"t":704341,"n":"AccessDeniedCallbackObject","d":704341,"h":55835279189,"f":33},{"t":704341,"n":"SystemAuditCallback","d":704341,"h":60130246485,"f":33},{"t":704341,"n":"SystemAlarmCallback","d":704341,"h":64425213781,"f":33},{"t":704341,"n":"SystemAuditCallbackObject","d":704341,"h":68720181077,"f":33},{"t":704341,"n":"MaxDefinedAceType","d":704341,"h":73015148373,"f":33},{"t":704341,"n":"SystemAlarmCallbackObject","d":704341,"h":77310115669,"f":33}],"c":[{"n":".ctor","o":"$ctor$3","d":704341,"h":81605082965,"f":1}],"i":[57212929,63766529,57671681,57344001],"h":704341}; }
            static get $b() { return $.$spc.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IComparable, $.$spc.System.ISpanFormattable, $.$spc.System.IFormattable, $.$spc.System.IConvertible ]; }
            static get $fullName() { return `System.Security.AccessControl.AceType`; }
        });
        
        $asm.$str("$ssa.System.Security.AccessControl.AuditFlags", ($self) => class AuditFlags extends $.$spc.System.Enum
        {
            static None = 0;
            static Success = 1;
            static Failure = 2;
            static $map;
            static get Map()
            {
                return this.$map ??= 
                {
                    "None": 0n,
                    "Success": 1n,
                    "Failure": 2n
                };
            }
            static $h = 769877;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static get $eut() { return $.$spc.System.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {"b":1048577,"u":655361,"l":[{"t":769877,"n":"None","d":769877,"h":4295737173,"f":33},{"t":769877,"n":"Success","d":769877,"h":8590704469,"f":33},{"t":769877,"n":"Failure","d":769877,"h":12885671765,"f":33}],"c":[{"n":".ctor","o":"$ctor$3","d":769877,"h":17180639061,"f":1}],"i":[57212929,63766529,57671681,57344001],"h":769877,"a":[{"t":47644673,"c":4342611969}]}; }
            static get $b() { return $.$spc.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IComparable, $.$spc.System.ISpanFormattable, $.$spc.System.IFormattable, $.$spc.System.IConvertible ]; }
            static get $fullName() { return `System.Security.AccessControl.AuditFlags`; }
        });
        
        $asm.$str("$ssa.System.Security.AccessControl.CompoundAceType", ($self) => class CompoundAceType extends $.$spc.System.Enum
        {
            static Impersonation = 1;
            static $map;
            static get Map()
            {
                return this.$map ??= 
                {
                    "Impersonation": 1n
                };
            }
            static $h = 1425237;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static get $eut() { return $.$spc.System.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {"b":1048577,"u":655361,"l":[{"t":1425237,"n":"Impersonation","d":1425237,"h":4296392533,"f":33}],"c":[{"n":".ctor","o":"$ctor$3","d":1425237,"h":8591359829,"f":1}],"i":[57212929,63766529,57671681,57344001],"h":1425237}; }
            static get $b() { return $.$spc.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IComparable, $.$spc.System.ISpanFormattable, $.$spc.System.IFormattable, $.$spc.System.IConvertible ]; }
            static get $fullName() { return `System.Security.AccessControl.CompoundAceType`; }
        });
        
        $asm.$str("$ssa.System.Security.AccessControl.ControlFlags", ($self) => class ControlFlags extends $.$spc.System.Enum
        {
            static None = 0;
            static OwnerDefaulted = 1;
            static GroupDefaulted = 2;
            static DiscretionaryAclPresent = 4;
            static DiscretionaryAclDefaulted = 8;
            static SystemAclPresent = 16;
            static SystemAclDefaulted = 32;
            static DiscretionaryAclUntrusted = 64;
            static ServerSecurity = 128;
            static DiscretionaryAclAutoInheritRequired = 256;
            static SystemAclAutoInheritRequired = 512;
            static DiscretionaryAclAutoInherited = 1024;
            static SystemAclAutoInherited = 2048;
            static DiscretionaryAclProtected = 4096;
            static SystemAclProtected = 8192;
            static RMControlValid = 16384;
            static SelfRelative = 32768;
            static $map;
            static get Map()
            {
                return this.$map ??= 
                {
                    "None": 0n,
                    "OwnerDefaulted": 1n,
                    "GroupDefaulted": 2n,
                    "DiscretionaryAclPresent": 4n,
                    "DiscretionaryAclDefaulted": 8n,
                    "SystemAclPresent": 16n,
                    "SystemAclDefaulted": 32n,
                    "DiscretionaryAclUntrusted": 64n,
                    "ServerSecurity": 128n,
                    "DiscretionaryAclAutoInheritRequired": 256n,
                    "SystemAclAutoInheritRequired": 512n,
                    "DiscretionaryAclAutoInherited": 1024n,
                    "SystemAclAutoInherited": 2048n,
                    "DiscretionaryAclProtected": 4096n,
                    "SystemAclProtected": 8192n,
                    "RMControlValid": 16384n,
                    "SelfRelative": 32768n
                };
            }
            static $h = 1490773;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static get $eut() { return $.$spc.System.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {"b":1048577,"u":655361,"l":[{"t":1490773,"n":"None","d":1490773,"h":4296458069,"f":33},{"t":1490773,"n":"OwnerDefaulted","d":1490773,"h":8591425365,"f":33},{"t":1490773,"n":"GroupDefaulted","d":1490773,"h":12886392661,"f":33},{"t":1490773,"n":"DiscretionaryAclPresent","d":1490773,"h":17181359957,"f":33},{"t":1490773,"n":"DiscretionaryAclDefaulted","d":1490773,"h":21476327253,"f":33},{"t":1490773,"n":"SystemAclPresent","d":1490773,"h":25771294549,"f":33},{"t":1490773,"n":"SystemAclDefaulted","d":1490773,"h":30066261845,"f":33},{"t":1490773,"n":"DiscretionaryAclUntrusted","d":1490773,"h":34361229141,"f":33},{"t":1490773,"n":"ServerSecurity","d":1490773,"h":38656196437,"f":33},{"t":1490773,"n":"DiscretionaryAclAutoInheritRequired","d":1490773,"h":42951163733,"f":33},{"t":1490773,"n":"SystemAclAutoInheritRequired","d":1490773,"h":47246131029,"f":33},{"t":1490773,"n":"DiscretionaryAclAutoInherited","d":1490773,"h":51541098325,"f":33},{"t":1490773,"n":"SystemAclAutoInherited","d":1490773,"h":55836065621,"f":33},{"t":1490773,"n":"DiscretionaryAclProtected","d":1490773,"h":60131032917,"f":33},{"t":1490773,"n":"SystemAclProtected","d":1490773,"h":64426000213,"f":33},{"t":1490773,"n":"RMControlValid","d":1490773,"h":68720967509,"f":33},{"t":1490773,"n":"SelfRelative","d":1490773,"h":73015934805,"f":33}],"c":[{"n":".ctor","o":"$ctor$3","d":1490773,"h":77310902101,"f":1}],"i":[57212929,63766529,57671681,57344001],"h":1490773,"a":[{"t":47644673,"c":4342611969}]}; }
            static get $b() { return $.$spc.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IComparable, $.$spc.System.ISpanFormattable, $.$spc.System.IFormattable, $.$spc.System.IConvertible ]; }
            static get $fullName() { return `System.Security.AccessControl.ControlFlags`; }
        });
        
        $asm.$str("$ssa.System.Security.AccessControl.InheritanceFlags", ($self) => class InheritanceFlags extends $.$spc.System.Enum
        {
            static None = 0;
            static ContainerInherit = 1;
            static ObjectInherit = 2;
            static $map;
            static get Map()
            {
                return this.$map ??= 
                {
                    "None": 0n,
                    "ContainerInherit": 1n,
                    "ObjectInherit": 2n
                };
            }
            static $h = 1883989;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static get $eut() { return $.$spc.System.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {"b":1048577,"u":655361,"l":[{"t":1883989,"n":"None","d":1883989,"h":4296851285,"f":33},{"t":1883989,"n":"ContainerInherit","d":1883989,"h":8591818581,"f":33},{"t":1883989,"n":"ObjectInherit","d":1883989,"h":12886785877,"f":33}],"c":[{"n":".ctor","o":"$ctor$3","d":1883989,"h":17181753173,"f":1}],"i":[57212929,63766529,57671681,57344001],"h":1883989,"a":[{"t":47644673,"c":4342611969}]}; }
            static get $b() { return $.$spc.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IComparable, $.$spc.System.ISpanFormattable, $.$spc.System.IFormattable, $.$spc.System.IConvertible ]; }
            static get $fullName() { return `System.Security.AccessControl.InheritanceFlags`; }
        });
        
        $asm.$str("$ssa.System.Security.AccessControl.ObjectAceFlags", ($self) => class ObjectAceFlags extends $.$spc.System.Enum
        {
            static None = 0;
            static ObjectAceTypePresent = 1;
            static InheritedObjectAceTypePresent = 2;
            static $map;
            static get Map()
            {
                return this.$map ??= 
                {
                    "None": 0n,
                    "ObjectAceTypePresent": 1n,
                    "InheritedObjectAceTypePresent": 2n
                };
            }
            static $h = 2277205;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static get $eut() { return $.$spc.System.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {"b":1048577,"u":655361,"l":[{"t":2277205,"n":"None","d":2277205,"h":4297244501,"f":33},{"t":2277205,"n":"ObjectAceTypePresent","d":2277205,"h":8592211797,"f":33},{"t":2277205,"n":"InheritedObjectAceTypePresent","d":2277205,"h":12887179093,"f":33}],"c":[{"n":".ctor","o":"$ctor$3","d":2277205,"h":17182146389,"f":1}],"i":[57212929,63766529,57671681,57344001],"h":2277205,"a":[{"t":47644673,"c":4342611969}]}; }
            static get $b() { return $.$spc.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IComparable, $.$spc.System.ISpanFormattable, $.$spc.System.IFormattable, $.$spc.System.IConvertible ]; }
            static get $fullName() { return `System.Security.AccessControl.ObjectAceFlags`; }
        });
        
        $asm.$str("$ssa.System.Security.AccessControl.PropagationFlags", ($self) => class PropagationFlags extends $.$spc.System.Enum
        {
            static None = 0;
            static NoPropagateInherit = 1;
            static InheritOnly = 2;
            static $map;
            static get Map()
            {
                return this.$map ??= 
                {
                    "None": 0n,
                    "NoPropagateInherit": 1n,
                    "InheritOnly": 2n
                };
            }
            static $h = 2604885;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static get $eut() { return $.$spc.System.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {"b":1048577,"u":655361,"l":[{"t":2604885,"n":"None","d":2604885,"h":4297572181,"f":33},{"t":2604885,"n":"NoPropagateInherit","d":2604885,"h":8592539477,"f":33},{"t":2604885,"n":"InheritOnly","d":2604885,"h":12887506773,"f":33}],"c":[{"n":".ctor","o":"$ctor$3","d":2604885,"h":17182474069,"f":1}],"i":[57212929,63766529,57671681,57344001],"h":2604885,"a":[{"t":47644673,"c":4342611969}]}; }
            static get $b() { return $.$spc.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IComparable, $.$spc.System.ISpanFormattable, $.$spc.System.IFormattable, $.$spc.System.IConvertible ]; }
            static get $fullName() { return `System.Security.AccessControl.PropagationFlags`; }
        });
        
        $asm.$str("$ssa.System.Security.AccessControl.ResourceType", ($self) => class ResourceType extends $.$spc.System.Enum
        {
            static Unknown = 0;
            static FileObject = 1;
            static Service = 2;
            static Printer = 3;
            static RegistryKey = 4;
            static LMShare = 5;
            static KernelObject = 6;
            static WindowObject = 7;
            static DSObject = 8;
            static DSObjectAll = 9;
            static ProviderDefined = 10;
            static WmiGuidObject = 11;
            static RegistryWow6432Key = 12;
            static $map;
            static get Map()
            {
                return this.$map ??= 
                {
                    "Unknown": 0n,
                    "FileObject": 1n,
                    "Service": 2n,
                    "Printer": 3n,
                    "RegistryKey": 4n,
                    "LMShare": 5n,
                    "KernelObject": 6n,
                    "WindowObject": 7n,
                    "DSObject": 8n,
                    "DSObjectAll": 9n,
                    "ProviderDefined": 10n,
                    "WmiGuidObject": 11n,
                    "RegistryWow6432Key": 12n
                };
            }
            static $h = 2867029;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static get $eut() { return $.$spc.System.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {"b":1048577,"u":655361,"l":[{"t":2867029,"n":"Unknown","d":2867029,"h":4297834325,"f":33},{"t":2867029,"n":"FileObject","d":2867029,"h":8592801621,"f":33},{"t":2867029,"n":"Service","d":2867029,"h":12887768917,"f":33},{"t":2867029,"n":"Printer","d":2867029,"h":17182736213,"f":33},{"t":2867029,"n":"RegistryKey","d":2867029,"h":21477703509,"f":33},{"t":2867029,"n":"LMShare","d":2867029,"h":25772670805,"f":33},{"t":2867029,"n":"KernelObject","d":2867029,"h":30067638101,"f":33},{"t":2867029,"n":"WindowObject","d":2867029,"h":34362605397,"f":33},{"t":2867029,"n":"DSObject","d":2867029,"h":38657572693,"f":33},{"t":2867029,"n":"DSObjectAll","d":2867029,"h":42952539989,"f":33},{"t":2867029,"n":"ProviderDefined","d":2867029,"h":47247507285,"f":33},{"t":2867029,"n":"WmiGuidObject","d":2867029,"h":51542474581,"f":33},{"t":2867029,"n":"RegistryWow6432Key","d":2867029,"h":55837441877,"f":33}],"c":[{"n":".ctor","o":"$ctor$3","d":2867029,"h":60132409173,"f":1}],"i":[57212929,63766529,57671681,57344001],"h":2867029}; }
            static get $b() { return $.$spc.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IComparable, $.$spc.System.ISpanFormattable, $.$spc.System.IFormattable, $.$spc.System.IConvertible ]; }
            static get $fullName() { return `System.Security.AccessControl.ResourceType`; }
        });
        
        $asm.$str("$ssa.System.Security.AccessControl.SecurityInfos", ($self) => class SecurityInfos extends $.$spc.System.Enum
        {
            static Owner = 1;
            static Group = 2;
            static DiscretionaryAcl = 4;
            static SystemAcl = 8;
            static $map;
            static get Map()
            {
                return this.$map ??= 
                {
                    "Owner": 1n,
                    "Group": 2n,
                    "DiscretionaryAcl": 4n,
                    "SystemAcl": 8n
                };
            }
            static $h = 2932565;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static get $eut() { return $.$spc.System.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {"b":1048577,"u":655361,"l":[{"t":2932565,"n":"Owner","d":2932565,"h":4297899861,"f":33},{"t":2932565,"n":"Group","d":2932565,"h":8592867157,"f":33},{"t":2932565,"n":"DiscretionaryAcl","d":2932565,"h":12887834453,"f":33},{"t":2932565,"n":"SystemAcl","d":2932565,"h":17182801749,"f":33}],"c":[{"n":".ctor","o":"$ctor$3","d":2932565,"h":21477769045,"f":1}],"i":[57212929,63766529,57671681,57344001],"h":2932565,"a":[{"t":47644673,"c":4342611969}]}; }
            static get $b() { return $.$spc.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IComparable, $.$spc.System.ISpanFormattable, $.$spc.System.IFormattable, $.$spc.System.IConvertible ]; }
            static get $fullName() { return `System.Security.AccessControl.SecurityInfos`; }
        });
        
        $asm.$cls("$ssa.System.Security.AccessControl.CommonAce", ($self) => class CommonAce extends $.$ssa.System.Security.AccessControl.QualifiedAce
        {
            $ctor$4(/*System.Security.AccessControl.AceFlags*/ flags, /*System.Security.AccessControl.AceQualifier*/ qualifier, /*int*/ accessMask, /*System.Security.Principal.SecurityIdentifier*/ sid, /*bool*/ isCallback, /*byte[]?*/ opaque)
            {
                super.$ctor$3();
                {
                }
                return this;
            }
            /*int */ get BinaryLength()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*void */ GetBinaryForm(/*byte[]*/ binaryForm, /*int*/ offset)
            {
            }
            static /*int */ MaxOpaqueLength(/*bool*/ isCallback)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static $h = 1097557;
            static $f = 0b10010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":2670421,"p":[{"p":655361,"g":{"r":0,"d":0,"h":12885999445,"f":32769},"n":"BinaryLength","d":1097557,"h":8591032149,"f":32769}],"m":[{"r":65537,"p":[{"n":"binaryForm","p":0},{"n":"offset","p":655361}],"n":"GetBinaryForm","d":1097557,"h":17180966741,"f":32769},{"r":655361,"p":[{"n":"isCallback","p":262145}],"n":"MaxOpaqueLength","d":1097557,"h":21475934037,"f":33}],"c":[{"p":[{"n":"flags","p":573269},{"n":"qualifier","p":638805},{"n":"accessMask","p":655361},{"n":"sid","p":452424},{"n":"isCallback","p":262145},{"n":"opaque","p":0}],"n":".ctor","o":"$ctor$4","d":1097557,"h":4296064853,"f":1}],"h":1097557}; }
            static get $b() { return $.$ssa.System.Security.AccessControl.QualifiedAce; }
            static get $fullName() { return `System.Security.AccessControl.CommonAce`; }
        });
        
        $asm.$cls("$ssa.System.Security.AccessControl.ObjectAce", ($self) => class ObjectAce extends $.$ssa.System.Security.AccessControl.QualifiedAce
        {
            $ctor$4(/*System.Security.AccessControl.AceFlags*/ aceFlags, /*System.Security.AccessControl.AceQualifier*/ qualifier, /*int*/ accessMask, /*System.Security.Principal.SecurityIdentifier*/ sid, /*System.Security.AccessControl.ObjectAceFlags*/ flags, /*System.Guid*/ type, /*System.Guid*/ inheritedType, /*bool*/ isCallback, /*byte[]?*/ opaque)
            {
                super.$ctor$3();
                {
                }
                return this;
            }
            /*int */ get BinaryLength()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Guid */ get InheritedObjectAceType()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Guid */ set InheritedObjectAceType(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Security.AccessControl.ObjectAceFlags */ get ObjectAceFlags()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Security.AccessControl.ObjectAceFlags */ set ObjectAceFlags(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Guid */ get ObjectAceType()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Guid */ set ObjectAceType(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*void */ GetBinaryForm(/*byte[]*/ binaryForm, /*int*/ offset)
            {
            }
            static /*int */ MaxOpaqueLength(/*bool*/ isCallback)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static $h = 2211669;
            static $f = 0b10010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":2670421,"p":[{"p":655361,"g":{"r":0,"d":0,"h":12887113557,"f":32769},"n":"BinaryLength","d":2211669,"h":8592146261,"f":32769},{"p":56164353,"g":{"r":0,"d":0,"h":21477048149,"f":1},"s":{"r":0,"d":0,"h":25772015445,"f":1},"n":"InheritedObjectAceType","d":2211669,"h":17182080853,"f":1},{"p":2277205,"g":{"r":0,"d":0,"h":34361950037,"f":1},"s":{"r":0,"d":0,"h":38656917333,"f":1},"n":"ObjectAceFlags","d":2211669,"h":30066982741,"f":1},{"p":56164353,"g":{"r":0,"d":0,"h":47246851925,"f":1},"s":{"r":0,"d":0,"h":51541819221,"f":1},"n":"ObjectAceType","d":2211669,"h":42951884629,"f":1}],"m":[{"r":65537,"p":[{"n":"binaryForm","p":0},{"n":"offset","p":655361}],"n":"GetBinaryForm","d":2211669,"h":55836786517,"f":32769},{"r":655361,"p":[{"n":"isCallback","p":262145}],"n":"MaxOpaqueLength","d":2211669,"h":60131753813,"f":33}],"c":[{"p":[{"n":"aceFlags","p":573269},{"n":"qualifier","p":638805},{"n":"accessMask","p":655361},{"n":"sid","p":452424},{"n":"flags","p":2277205},{"n":"type","p":56164353},{"n":"inheritedType","p":56164353},{"n":"isCallback","p":262145},{"n":"opaque","p":0}],"n":".ctor","o":"$ctor$4","d":2211669,"h":4297178965,"f":1}],"h":2211669}; }
            static get $b() { return $.$ssa.System.Security.AccessControl.QualifiedAce; }
            static get $fullName() { return `System.Security.AccessControl.ObjectAce`; }
        });
        
        $asm.$cls("$ssa.System.Security.AccessControl.PrivilegeNotHeldException", ($self) => class PrivilegeNotHeldException extends $.$spc.System.UnauthorizedAccessException
        {
            $ctor$13()
            {
                super.$ctor$9();
                {
                }
                return this;
            }
            $ctor$14(/*string?*/ privilege)
            {
                super.$ctor$9();
                {
                }
                return this;
            }
            $ctor$15(/*string?*/ privilege, /*System.Exception?*/ inner)
            {
                super.$ctor$9();
                {
                }
                return this;
            }
            /*string? */ get PrivilegeName()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*void */ GetObjectData(/*System.Runtime.Serialization.SerializationInfo*/ info, /*System.Runtime.Serialization.StreamingContext*/ context)
            {
            }
            static $h = 2539349;
            static $f = 0b10010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":143851521,"h":2539349}; }
            static get $b() { return $.$spc.System.UnauthorizedAccessException; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.Runtime.Serialization.ISerializable ]; }
            static get $fullName() { return `System.Security.AccessControl.PrivilegeNotHeldException`; }
        });
	});
})(window, window.NetJs.$boot(), ...window.NetJs.$require("NetJs.System.Private.CoreLib", "NetJs.Microsoft.Win32.Primitives", "NetJs.System.Collections", "NetJs.System.Diagnostics.Tracing", "NetJs.System.Memory", "NetJs.System.Private.Uri", "NetJs.System.Threading", "NetJs.System.Threading.Thread", "NetJs.System.Runtime", "NetJs.System.Collections.Concurrent", "NetJs.System.Collections.NonGeneric", "NetJs.System.Security.Claims", "NetJs.System.Runtime.InteropServices", "NetJs.System.Security.Principal.Windows"))