
(function ($global, $, $spc, $mwp, $sc, $sdt, $sm, $spu, $st, $stt, $sr, $scc, $scn, $ssc, $sris, $sspw) {
    "use strict";
    let _;
    
    
    
	$.$asm(
    "NetJs.System.Security.AccessControl", 
    {"h":50882,"f":"System.Security.AccessControl","v":"1.0.35.0","a":[{"t":115146753,"c":13000048641,"a":[{"v":".NETCoreApp,Version=v10.0","t":1310721}],"n":[{"n":"FrameworkDisplayName","v":".NET 10.0","t":1310721}]},{"t":73596929,"c":4368564225,"a":[{"v":"SIT","t":1310721}]},{"t":73662465,"c":4368629761,"a":[{"v":"Debug","t":1310721}]},{"t":74121217,"c":4369088513,"a":[{"v":"1.0.35.0","t":1310721}]},{"t":74252289,"c":4369219585,"a":[{"v":"1.0.35\u002Bb2f64e36cd2325469603c9f9f7251f0c62e9b41f","t":1310721}]},{"t":75104257,"c":4370071553,"a":[{"v":"NetJs.System.Security.AccessControl","t":1310721}]},{"t":75235329,"c":4370202625,"a":[{"v":"NetJs.System.Security.AccessControl","t":1310721}]},{"t":75366401,"c":4370333697,"a":[{"v":"1.0.35.0","t":1310721}]},{"t":115212289,"c":4410179585,"a":[{"v":"browser1.0","t":1310721}]},{"t":114950145,"c":4409917441,"a":[{"v":"browser1.0","t":1310721}]}],"m":[]},
    function($asm)
	{
        
        
        $asm.$cls("$ssa.System.Security.AccessControl.AuthorizationRule", ($self) => class AuthorizationRule extends $.$spc.System.Object
        {
            $ctor$1(/*System.Security.Principal.IdentityReference*/ identity, /*int*/ accessMask, /*bool*/ isInherited, /*System.Security.AccessControl.InheritanceFlags*/ inheritanceFlags, /*System.Security.AccessControl.PropagationFlags*/ propagationFlags)
            {
                super.$ctor();
                {
                }
                return this;
            }
            /*int */ get AccessMask()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Security.Principal.IdentityReference */ get IdentityReference()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Security.AccessControl.InheritanceFlags */ get InheritanceFlags()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get IsInherited()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Security.AccessControl.PropagationFlags */ get PropagationFlags()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static $h = 968386;
            static $f = 0b110001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":655361,"g":{"r":0,"d":0,"h":12885870274,"f":16},"n":"AccessMask","d":968386,"h":8590902978,"f":16},{"p":240041,"g":{"r":0,"d":0,"h":21475804866,"f":1},"n":"IdentityReference","d":968386,"h":17180837570,"f":1},{"p":1885890,"g":{"r":0,"d":0,"h":30065739458,"f":1},"n":"InheritanceFlags","d":968386,"h":25770772162,"f":1},{"p":262145,"g":{"r":0,"d":0,"h":38655674050,"f":1},"n":"IsInherited","d":968386,"h":34360706754,"f":1},{"p":2606786,"g":{"r":0,"d":0,"h":47245608642,"f":1},"n":"PropagationFlags","d":968386,"h":42950641346,"f":1}],"c":[{"p":[{"n":"identity","p":240041},{"n":"accessMask","p":655361},{"n":"isInherited","p":262145},{"n":"inheritanceFlags","p":1885890},{"n":"propagationFlags","p":2606786}],"n":".ctor","o":"$ctor$1","d":968386,"h":4295935682,"f":16}],"h":968386}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.Security.AccessControl.AuthorizationRule`; }
        });
        
        $asm.$cls("$ssa.System.Security.AccessControl.GenericAce", ($self) => class GenericAce extends $.$spc.System.Object
        {
            $ctor$1()
            {
                super.$ctor();
                {
                }
                return this;
            }
            /*System.Security.AccessControl.AceFlags */ get AceFlags()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Security.AccessControl.AceFlags */ set AceFlags(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Security.AccessControl.AceType */ get AceType()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Security.AccessControl.AuditFlags */ get AuditFlags()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Security.AccessControl.InheritanceFlags */ get InheritanceFlags()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get IsInherited()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Security.AccessControl.PropagationFlags */ get PropagationFlags()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Security.AccessControl.GenericAce */ Copy()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static /*System.Security.AccessControl.GenericAce */ CreateFromBinaryForm(/*byte[]*/ binaryForm, /*int*/ offset)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static/*conventional*/ /*bool */ Equals(/*object?*/ o)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            //Static convention instance redirect
            /*bool */ Equals() { return $.$ssa.System.Security.AccessControl.GenericAce.Equals.apply(this, arguments); }
            static/*conventional*/ /*int */ GetHashCode()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            //Static convention instance redirect
            /*int */ GetHashCode() { return $.$ssa.System.Security.AccessControl.GenericAce.GetHashCode.apply(this, arguments); }
            static /*bool */ op_Equality(/*System.Security.AccessControl.GenericAce?*/ left, /*System.Security.AccessControl.GenericAce?*/ right)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static /*bool */ op_Inequality(/*System.Security.AccessControl.GenericAce?*/ left, /*System.Security.AccessControl.GenericAce?*/ right)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static $h = 1689282;
            static $f = 0b110001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":575170,"g":{"r":0,"d":0,"h":12886591170,"f":1},"s":{"r":0,"d":0,"h":17181558466,"f":1},"n":"AceFlags","d":1689282,"h":8591623874,"f":1},{"p":706242,"g":{"r":0,"d":0,"h":25771493058,"f":1},"n":"AceType","d":1689282,"h":21476525762,"f":1},{"p":771778,"g":{"r":0,"d":0,"h":34361427650,"f":1},"n":"AuditFlags","d":1689282,"h":30066460354,"f":1},{"p":655361,"g":{"r":0,"d":0,"h":42951362242,"f":257},"n":"BinaryLength","d":1689282,"h":38656394946,"f":257},{"p":1885890,"g":{"r":0,"d":0,"h":51541296834,"f":1},"n":"InheritanceFlags","d":1689282,"h":47246329538,"f":1},{"p":262145,"g":{"r":0,"d":0,"h":60131231426,"f":1},"n":"IsInherited","d":1689282,"h":55836264130,"f":1},{"p":2606786,"g":{"r":0,"d":0,"h":68721166018,"f":1},"n":"PropagationFlags","d":1689282,"h":64426198722,"f":1}],"m":[{"r":1689282,"n":"Copy","d":1689282,"h":73016133314,"f":1},{"r":1689282,"p":[{"n":"binaryForm","p":0},{"n":"offset","p":655361}],"n":"CreateFromBinaryForm","d":1689282,"h":77311100610,"f":33},{"r":262145,"p":[{"n":"o","p":131073}],"n":"Equals","d":1689282,"h":81606067906,"f":98305},{"r":65537,"p":[{"n":"binaryForm","p":0},{"n":"offset","p":655361}],"n":"GetBinaryForm","d":1689282,"h":85901035202,"f":257},{"r":655361,"n":"GetHashCode","d":1689282,"h":90196002498,"f":98305}],"c":[{"n":".ctor","o":"$ctor$1","d":1689282,"h":4296656578,"f":8}],"h":1689282}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.Security.AccessControl.GenericAce`; }
        });
        
        $asm.$cls("$ssa.System.Security.AccessControl.GenericSecurityDescriptor", ($self) => class GenericSecurityDescriptor extends $.$spc.System.Object
        {
            $ctor$1()
            {
                super.$ctor();
                {
                }
                return this;
            }
            /*int */ get BinaryLength()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static /*byte */ get Revision()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*void */ GetBinaryForm(/*byte[]*/ binaryForm, /*int*/ offset)
            {
            }
            /*string */ GetSddlForm(/*System.Security.AccessControl.AccessControlSections*/ includeSections)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static /*bool */ IsSddlConversionSupported()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static $h = 1820354;
            static $f = 0b110001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":655361,"g":{"r":0,"d":0,"h":12886722242,"f":1},"n":"BinaryLength","d":1820354,"h":8591754946,"f":1},{"p":1492674,"g":{"r":0,"d":0,"h":21476656834,"f":257},"n":"ControlFlags","d":1820354,"h":17181689538,"f":257},{"p":436649,"g":{"r":0,"d":0,"h":30066591426,"f":257},"s":{"r":0,"d":0,"h":34361558722,"f":257},"n":"Group","d":1820354,"h":25771624130,"f":257},{"p":436649,"g":{"r":0,"d":0,"h":42951493314,"f":257},"s":{"r":0,"d":0,"h":47246460610,"f":257},"n":"Owner","d":1820354,"h":38656526018,"f":257},{"p":393217,"g":{"r":0,"d":0,"h":55836395202,"f":33},"n":"Revision","d":1820354,"h":51541427906,"f":33}],"m":[{"r":65537,"p":[{"n":"binaryForm","p":0},{"n":"offset","p":655361}],"n":"GetBinaryForm","d":1820354,"h":60131362498,"f":1},{"r":1310721,"p":[{"n":"includeSections","p":247490}],"n":"GetSddlForm","d":1820354,"h":64426329794,"f":1},{"r":262145,"n":"IsSddlConversionSupported","d":1820354,"h":68721297090,"f":33}],"c":[{"n":".ctor","o":"$ctor$1","d":1820354,"h":4296787650,"f":8}],"h":1820354}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.Security.AccessControl.GenericSecurityDescriptor`; }
        });
        
        $asm.$cls("$ssa.System.Security.AccessControl.ObjectSecurity", ($self) => class ObjectSecurity extends $.$spc.System.Object
        {
            $ctor$1()
            {
                super.$ctor();
                {
                }
                return this;
            }
            $ctor$2(/*bool*/ isContainer, /*bool*/ isDS)
            {
                super.$ctor();
                {
                }
                return this;
            }
            $ctor$3(/*System.Security.AccessControl.CommonSecurityDescriptor*/ securityDescriptor)
            {
                super.$ctor();
                {
                }
                return this;
            }
            /*bool */ get AccessRulesModified()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ set AccessRulesModified(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get AreAccessRulesCanonical()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get AreAccessRulesProtected()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get AreAuditRulesCanonical()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get AreAuditRulesProtected()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get AuditRulesModified()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ set AuditRulesModified(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get GroupModified()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ set GroupModified(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get IsContainer()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get IsDS()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get OwnerModified()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ set OwnerModified(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Security.AccessControl.CommonSecurityDescriptor */ get SecurityDescriptor()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Security.Principal.IdentityReference? */ GetGroup(/*System.Type*/ targetType)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Security.Principal.IdentityReference? */ GetOwner(/*System.Type*/ targetType)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*byte[] */ GetSecurityDescriptorBinaryForm()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*string */ GetSecurityDescriptorSddlForm(/*System.Security.AccessControl.AccessControlSections*/ includeSections)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static /*bool */ IsSddlConversionSupported()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ ModifyAccessRule(/*System.Security.AccessControl.AccessControlModification*/ modification, /*System.Security.AccessControl.AccessRule*/ rule, /*out bool*/ modified)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ ModifyAuditRule(/*System.Security.AccessControl.AccessControlModification*/ modification, /*System.Security.AccessControl.AuditRule*/ rule, /*out bool*/ modified)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*void */ Persist(/*bool*/ enableOwnershipPrivilege, /*string*/ name, /*System.Security.AccessControl.AccessControlSections*/ includeSections)
            {
            }
            /*void */ Persist$1(/*System.Runtime.InteropServices.SafeHandle*/ handle, /*System.Security.AccessControl.AccessControlSections*/ includeSections)
            {
            }
            /*void */ Persist$2(/*string*/ name, /*System.Security.AccessControl.AccessControlSections*/ includeSections)
            {
            }
            /*void */ PurgeAccessRules(/*System.Security.Principal.IdentityReference*/ identity)
            {
            }
            /*void */ PurgeAuditRules(/*System.Security.Principal.IdentityReference*/ identity)
            {
            }
            /*void */ ReadLock()
            {
            }
            /*void */ ReadUnlock()
            {
            }
            /*void */ SetAccessRuleProtection(/*bool*/ isProtected, /*bool*/ preserveInheritance)
            {
            }
            /*void */ SetAuditRuleProtection(/*bool*/ isProtected, /*bool*/ preserveInheritance)
            {
            }
            /*void */ SetGroup(/*System.Security.Principal.IdentityReference*/ identity)
            {
            }
            /*void */ SetOwner(/*System.Security.Principal.IdentityReference*/ identity)
            {
            }
            /*void */ SetSecurityDescriptorBinaryForm(/*byte[]*/ binaryForm)
            {
            }
            /*void */ SetSecurityDescriptorBinaryForm$1(/*byte[]*/ binaryForm, /*System.Security.AccessControl.AccessControlSections*/ includeSections)
            {
            }
            /*void */ SetSecurityDescriptorSddlForm(/*string*/ sddlForm)
            {
            }
            /*void */ SetSecurityDescriptorSddlForm$1(/*string*/ sddlForm, /*System.Security.AccessControl.AccessControlSections*/ includeSections)
            {
            }
            /*void */ WriteLock()
            {
            }
            /*void */ WriteUnlock()
            {
            }
            static $h = 2410178;
            static $f = 0b110001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":142606337,"g":{"r":0,"d":0,"h":21477246658,"f":257},"n":"AccessRightType","d":2410178,"h":17182279362,"f":257},{"p":262145,"g":{"r":0,"d":0,"h":30067181250,"f":4},"s":{"r":0,"d":0,"h":34362148546,"f":4},"n":"AccessRulesModified","d":2410178,"h":25772213954,"f":4},{"p":142606337,"g":{"r":0,"d":0,"h":42952083138,"f":257},"n":"AccessRuleType","d":2410178,"h":38657115842,"f":257},{"p":262145,"g":{"r":0,"d":0,"h":51542017730,"f":1},"n":"AreAccessRulesCanonical","d":2410178,"h":47247050434,"f":1},{"p":262145,"g":{"r":0,"d":0,"h":60131952322,"f":1},"n":"AreAccessRulesProtected","d":2410178,"h":55836985026,"f":1},{"p":262145,"g":{"r":0,"d":0,"h":68721886914,"f":1},"n":"AreAuditRulesCanonical","d":2410178,"h":64426919618,"f":1},{"p":262145,"g":{"r":0,"d":0,"h":77311821506,"f":1},"n":"AreAuditRulesProtected","d":2410178,"h":73016854210,"f":1},{"p":262145,"g":{"r":0,"d":0,"h":85901756098,"f":4},"s":{"r":0,"d":0,"h":90196723394,"f":4},"n":"AuditRulesModified","d":2410178,"h":81606788802,"f":4},{"p":142606337,"g":{"r":0,"d":0,"h":98786657986,"f":257},"n":"AuditRuleType","d":2410178,"h":94491690690,"f":257},{"p":262145,"g":{"r":0,"d":0,"h":107376592578,"f":4},"s":{"r":0,"d":0,"h":111671559874,"f":4},"n":"GroupModified","d":2410178,"h":103081625282,"f":4},{"p":262145,"g":{"r":0,"d":0,"h":120261494466,"f":4},"n":"IsContainer","d":2410178,"h":115966527170,"f":4},{"p":262145,"g":{"r":0,"d":0,"h":128851429058,"f":4},"n":"IsDS","d":2410178,"h":124556461762,"f":4},{"p":262145,"g":{"r":0,"d":0,"h":137441363650,"f":4},"s":{"r":0,"d":0,"h":141736330946,"f":4},"n":"OwnerModified","d":2410178,"h":133146396354,"f":4},{"p":1296066,"g":{"r":0,"d":0,"h":150326265538,"f":4},"n":"SecurityDescriptor","d":2410178,"h":146031298242,"f":4}],"m":[{"r":378562,"p":[{"n":"identityReference","p":240041},{"n":"accessMask","p":655361},{"n":"isInherited","p":262145},{"n":"inheritanceFlags","p":1885890},{"n":"propagationFlags","p":2606786},{"n":"type","p":313026}],"n":"AccessRuleFactory","d":2410178,"h":154621232834,"f":257},{"r":837314,"p":[{"n":"identityReference","p":240041},{"n":"accessMask","p":655361},{"n":"isInherited","p":262145},{"n":"inheritanceFlags","p":1885890},{"n":"propagationFlags","p":2606786},{"n":"flags","p":771778}],"n":"AuditRuleFactory","d":2410178,"h":158916200130,"f":257},{"r":240041,"p":[{"n":"targetType","p":142606337}],"n":"GetGroup","d":2410178,"h":163211167426,"f":1},{"r":240041,"p":[{"n":"targetType","p":142606337}],"n":"GetOwner","d":2410178,"h":167506134722,"f":1},{"r":0,"n":"GetSecurityDescriptorBinaryForm","d":2410178,"h":171801102018,"f":1},{"r":1310721,"p":[{"n":"includeSections","p":247490}],"n":"GetSecurityDescriptorSddlForm","d":2410178,"h":176096069314,"f":1},{"r":262145,"n":"IsSddlConversionSupported","d":2410178,"h":180391036610,"f":33},{"r":262145,"p":[{"n":"modification","p":181954},{"n":"rule","p":378562},{"n":"modified","p":262145,"f":2}],"n":"ModifyAccess","d":2410178,"h":184686003906,"f":260},{"r":262145,"p":[{"n":"modification","p":181954},{"n":"rule","p":378562},{"n":"modified","p":262145,"f":2}],"n":"ModifyAccessRule","d":2410178,"h":188980971202,"f":129},{"r":262145,"p":[{"n":"modification","p":181954},{"n":"rule","p":837314},{"n":"modified","p":262145,"f":2}],"n":"ModifyAudit","d":2410178,"h":193275938498,"f":260},{"r":262145,"p":[{"n":"modification","p":181954},{"n":"rule","p":837314},{"n":"modified","p":262145,"f":2}],"n":"ModifyAuditRule","d":2410178,"h":197570905794,"f":129},{"r":65537,"p":[{"n":"enableOwnershipPrivilege","p":262145},{"n":"name","p":1310721},{"n":"includeSections","p":247490}],"n":"Persist","d":2410178,"h":201865873090,"f":132},{"r":65537,"p":[{"n":"handle","p":109576193},{"n":"includeSections","p":247490}],"n":"Persist","o":"@$1","d":2410178,"h":206160840386,"f":132},{"r":65537,"p":[{"n":"name","p":1310721},{"n":"includeSections","p":247490}],"n":"Persist","o":"@$2","d":2410178,"h":210455807682,"f":132},{"r":65537,"p":[{"n":"identity","p":240041}],"n":"PurgeAccessRules","d":2410178,"h":214750774978,"f":129},{"r":65537,"p":[{"n":"identity","p":240041}],"n":"PurgeAuditRules","d":2410178,"h":219045742274,"f":129},{"r":65537,"n":"ReadLock","d":2410178,"h":223340709570,"f":4},{"r":65537,"n":"ReadUnlock","d":2410178,"h":227635676866,"f":4},{"r":65537,"p":[{"n":"isProtected","p":262145},{"n":"preserveInheritance","p":262145}],"n":"SetAccessRuleProtection","d":2410178,"h":231930644162,"f":1},{"r":65537,"p":[{"n":"isProtected","p":262145},{"n":"preserveInheritance","p":262145}],"n":"SetAuditRuleProtection","d":2410178,"h":236225611458,"f":1},{"r":65537,"p":[{"n":"identity","p":240041}],"n":"SetGroup","d":2410178,"h":240520578754,"f":1},{"r":65537,"p":[{"n":"identity","p":240041}],"n":"SetOwner","d":2410178,"h":244815546050,"f":1},{"r":65537,"p":[{"n":"binaryForm","p":0}],"n":"SetSecurityDescriptorBinaryForm","d":2410178,"h":249110513346,"f":1},{"r":65537,"p":[{"n":"binaryForm","p":0},{"n":"includeSections","p":247490}],"n":"SetSecurityDescriptorBinaryForm","o":"@$1","d":2410178,"h":253405480642,"f":1},{"r":65537,"p":[{"n":"sddlForm","p":1310721}],"n":"SetSecurityDescriptorSddlForm","d":2410178,"h":257700447938,"f":1},{"r":65537,"p":[{"n":"sddlForm","p":1310721},{"n":"includeSections","p":247490}],"n":"SetSecurityDescriptorSddlForm","o":"@$1","d":2410178,"h":261995415234,"f":1},{"r":65537,"n":"WriteLock","d":2410178,"h":266290382530,"f":4},{"r":65537,"n":"WriteUnlock","d":2410178,"h":270585349826,"f":4}],"c":[{"n":".ctor","o":"$ctor$1","d":2410178,"h":4297377474,"f":4},{"p":[{"n":"isContainer","p":262145},{"n":"isDS","p":262145}],"n":".ctor","o":"$ctor$2","d":2410178,"h":8592344770,"f":4},{"p":[{"n":"securityDescriptor","p":1296066}],"n":".ctor","o":"$ctor$3","d":2410178,"h":12887312066,"f":4}],"h":2410178}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.Security.AccessControl.ObjectSecurity`; }
        });
        
        $asm.$cls("$ssa.System.Security.Policy.EvidenceBase", ($self) => class EvidenceBase extends $.$spc.System.Object
        {
            $ctor$1()
            {
                super.$ctor();
                {
                }
                return this;
            }
            /*System.Security.Policy.EvidenceBase? */ Clone()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static $h = 3131074;
            static $f = 0b110001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"m":[{"r":3131074,"n":"Clone","d":3131074,"h":8593065666,"f":129}],"c":[{"n":".ctor","o":"$ctor$1","d":3131074,"h":4298098370,"f":4}],"h":3131074}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.Security.Policy.EvidenceBase`; }
        });
        
        $asm.$cls("$ssa.System.Security.AccessControl.GenericAcl", ($self) => class GenericAcl extends $.$spc.System.Object
        {
            /*byte*/ static AclRevision = 0;
            /*byte*/ static AclRevisionDS = 0;
            /*int*/ static MaxBinaryLength = 0;
            $ctor$1()
            {
                super.$ctor();
                {
                }
                return this;
            }
            /*bool */ get IsSynchronized()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*object */ get SyncRoot()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*void */ CopyTo(/*System.Security.AccessControl.GenericAce[]*/ array, /*int*/ index)
            {
            }
            /*System.Security.AccessControl.AceEnumerator */ GetEnumerator()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*void */ System$Collections$ICollection$CopyTo(/*System.Array*/ array, /*int*/ index)
            {
            }
            /*System.Collections.IEnumerator */ System$Collections$IEnumerable$GetEnumerator()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            //Generated interface implemetation for System.Collections.ICollection.Count.get
            get System$Collections$ICollection$Count()
            {
                return this.Count;
            }
            //Generated interface implemetation for System.Collections.ICollection.SyncRoot.get
            get System$Collections$ICollection$SyncRoot()
            {
                return this.SyncRoot;
            }
            //Generated interface implemetation for System.Collections.ICollection.IsSynchronized.get
            get System$Collections$ICollection$IsSynchronized()
            {
                return this.IsSynchronized;
            }
            static $h = 1754818;
            static $f = 0b110001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":655361,"g":{"r":0,"d":0,"h":25771558594,"f":257},"n":"BinaryLength","d":1754818,"h":21476591298,"f":257},{"p":655361,"g":{"r":0,"d":0,"h":34361493186,"f":257},"n":"Count","d":1754818,"h":30066525890,"f":257},{"p":262145,"g":{"r":0,"d":0,"h":42951427778,"f":1},"n":"IsSynchronized","d":1754818,"h":38656460482,"f":1},{"p":1689282,"i":[{"n":"index","p":655361}],"g":{"r":0,"d":0,"h":51541362370,"f":257},"s":{"r":0,"d":0,"h":55836329666,"f":257},"n":"Item","o":"@$2","d":1754818,"h":47246395074,"f":257},{"p":393217,"g":{"r":0,"d":0,"h":64426264258,"f":257},"n":"Revision","d":1754818,"h":60131296962,"f":257},{"p":131073,"g":{"r":0,"d":0,"h":73016198850,"f":129},"n":"SyncRoot","d":1754818,"h":68721231554,"f":129}],"m":[{"r":65537,"p":[{"n":"array","p":0},{"n":"index","p":655361}],"n":"CopyTo","d":1754818,"h":77311166146,"f":1},{"r":65537,"p":[{"n":"binaryForm","p":0},{"n":"offset","p":655361}],"n":"GetBinaryForm","d":1754818,"h":81606133442,"f":257},{"r":509634,"n":"GetEnumerator","d":1754818,"h":85901100738,"f":1}],"l":[{"t":393217,"n":"AclRevision","d":1754818,"h":4296722114,"f":33},{"t":393217,"n":"AclRevisionDS","d":1754818,"h":8591689410,"f":33},{"t":655361,"n":"MaxBinaryLength","d":1754818,"h":12886656706,"f":33}],"c":[{"n":".ctor","o":"$ctor$1","d":1754818,"h":17181624002,"f":4}],"i":[31326209,31588353],"h":1754818}; }
            static get $b() { return $.$spc.System.Object; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.Collections.ICollection, $.$spc.System.Collections.IEnumerable ]; }
            static get $fullName() { return `System.Security.AccessControl.GenericAcl`; }
        });
        
        $asm.$cls("$ssa.System.Security.AccessControl.AccessRule", ($self) => class AccessRule extends $.$ssa.System.Security.AccessControl.AuthorizationRule
        {
            $ctor$2(/*System.Security.Principal.IdentityReference*/ identity, /*int*/ accessMask, /*bool*/ isInherited, /*System.Security.AccessControl.InheritanceFlags*/ inheritanceFlags, /*System.Security.AccessControl.PropagationFlags*/ propagationFlags, /*System.Security.AccessControl.AccessControlType*/ type)
            {
                super.$ctor$1(null, 0, false, 0, 0);
                {
                }
                return this;
            }
            /*System.Security.AccessControl.AccessControlType */ get AccessControlType()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static $h = 378562;
            static $f = 0b110001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":968386,"p":[{"p":313026,"g":{"r":0,"d":0,"h":12885280450,"f":1},"n":"AccessControlType","d":378562,"h":8590313154,"f":1}],"c":[{"p":[{"n":"identity","p":240041},{"n":"accessMask","p":655361},{"n":"isInherited","p":262145},{"n":"inheritanceFlags","p":1885890},{"n":"propagationFlags","p":2606786},{"n":"type","p":313026}],"n":".ctor","o":"$ctor$2","d":378562,"h":4295345858,"f":4}],"h":378562}; }
            static get $b() { return $.$ssa.System.Security.AccessControl.AuthorizationRule; }
            static get $fullName() { return `System.Security.AccessControl.AccessRule`; }
        });
        
        $asm.$cls("$ssa.System.Security.AccessControl.AuditRule", ($self) => class AuditRule extends $.$ssa.System.Security.AccessControl.AuthorizationRule
        {
            $ctor$2(/*System.Security.Principal.IdentityReference*/ identity, /*int*/ accessMask, /*bool*/ isInherited, /*System.Security.AccessControl.InheritanceFlags*/ inheritanceFlags, /*System.Security.AccessControl.PropagationFlags*/ propagationFlags, /*System.Security.AccessControl.AuditFlags*/ auditFlags)
            {
                super.$ctor$1(null, 0, false, 0, 0);
                {
                }
                return this;
            }
            /*System.Security.AccessControl.AuditFlags */ get AuditFlags()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static $h = 837314;
            static $f = 0b110001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":968386,"p":[{"p":771778,"g":{"r":0,"d":0,"h":12885739202,"f":1},"n":"AuditFlags","d":837314,"h":8590771906,"f":1}],"c":[{"p":[{"n":"identity","p":240041},{"n":"accessMask","p":655361},{"n":"isInherited","p":262145},{"n":"inheritanceFlags","p":1885890},{"n":"propagationFlags","p":2606786},{"n":"auditFlags","p":771778}],"n":".ctor","o":"$ctor$2","d":837314,"h":4295804610,"f":4}],"h":837314}; }
            static get $b() { return $.$ssa.System.Security.AccessControl.AuthorizationRule; }
            static get $fullName() { return `System.Security.AccessControl.AuditRule`; }
        });
        
        $asm.$cls("$ssa.System.Security.AccessControl.CommonObjectSecurity", ($self) => class CommonObjectSecurity extends $.$ssa.System.Security.AccessControl.ObjectSecurity
        {
            $ctor$4(/*bool*/ isContainer)
            {
                super.$ctor$1();
                {
                }
                return this;
            }
            /*void */ AddAccessRule(/*System.Security.AccessControl.AccessRule*/ rule)
            {
            }
            /*void */ AddAuditRule(/*System.Security.AccessControl.AuditRule*/ rule)
            {
            }
            /*System.Security.AccessControl.AuthorizationRuleCollection */ GetAccessRules(/*bool*/ includeExplicit, /*bool*/ includeInherited, /*System.Type*/ targetType)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Security.AccessControl.AuthorizationRuleCollection */ GetAuditRules(/*bool*/ includeExplicit, /*bool*/ includeInherited, /*System.Type*/ targetType)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ ModifyAccess(/*System.Security.AccessControl.AccessControlModification*/ modification, /*System.Security.AccessControl.AccessRule*/ rule, /*out bool*/ modified)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ ModifyAudit(/*System.Security.AccessControl.AccessControlModification*/ modification, /*System.Security.AccessControl.AuditRule*/ rule, /*out bool*/ modified)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ RemoveAccessRule(/*System.Security.AccessControl.AccessRule*/ rule)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*void */ RemoveAccessRuleAll(/*System.Security.AccessControl.AccessRule*/ rule)
            {
            }
            /*void */ RemoveAccessRuleSpecific(/*System.Security.AccessControl.AccessRule*/ rule)
            {
            }
            /*bool */ RemoveAuditRule(/*System.Security.AccessControl.AuditRule*/ rule)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*void */ RemoveAuditRuleAll(/*System.Security.AccessControl.AuditRule*/ rule)
            {
            }
            /*void */ RemoveAuditRuleSpecific(/*System.Security.AccessControl.AuditRule*/ rule)
            {
            }
            /*void */ ResetAccessRule(/*System.Security.AccessControl.AccessRule*/ rule)
            {
            }
            /*void */ SetAccessRule(/*System.Security.AccessControl.AccessRule*/ rule)
            {
            }
            /*void */ SetAuditRule(/*System.Security.AccessControl.AuditRule*/ rule)
            {
            }
            static $h = 1230530;
            static $f = 0b110001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":2410178,"m":[{"r":65537,"p":[{"n":"rule","p":378562}],"n":"AddAccessRule","d":1230530,"h":8591165122,"f":4},{"r":65537,"p":[{"n":"rule","p":837314}],"n":"AddAuditRule","d":1230530,"h":12886132418,"f":4},{"r":1033922,"p":[{"n":"includeExplicit","p":262145},{"n":"includeInherited","p":262145},{"n":"targetType","p":142606337}],"n":"GetAccessRules","d":1230530,"h":17181099714,"f":1},{"r":1033922,"p":[{"n":"includeExplicit","p":262145},{"n":"includeInherited","p":262145},{"n":"targetType","p":142606337}],"n":"GetAuditRules","d":1230530,"h":21476067010,"f":1},{"r":262145,"p":[{"n":"modification","p":181954},{"n":"rule","p":378562},{"n":"modified","p":262145,"f":2}],"n":"ModifyAccess","d":1230530,"h":25771034306,"f":32772},{"r":262145,"p":[{"n":"modification","p":181954},{"n":"rule","p":837314},{"n":"modified","p":262145,"f":2}],"n":"ModifyAudit","d":1230530,"h":30066001602,"f":32772},{"r":262145,"p":[{"n":"rule","p":378562}],"n":"RemoveAccessRule","d":1230530,"h":34360968898,"f":4},{"r":65537,"p":[{"n":"rule","p":378562}],"n":"RemoveAccessRuleAll","d":1230530,"h":38655936194,"f":4},{"r":65537,"p":[{"n":"rule","p":378562}],"n":"RemoveAccessRuleSpecific","d":1230530,"h":42950903490,"f":4},{"r":262145,"p":[{"n":"rule","p":837314}],"n":"RemoveAuditRule","d":1230530,"h":47245870786,"f":4},{"r":65537,"p":[{"n":"rule","p":837314}],"n":"RemoveAuditRuleAll","d":1230530,"h":51540838082,"f":4},{"r":65537,"p":[{"n":"rule","p":837314}],"n":"RemoveAuditRuleSpecific","d":1230530,"h":55835805378,"f":4},{"r":65537,"p":[{"n":"rule","p":378562}],"n":"ResetAccessRule","d":1230530,"h":60130772674,"f":4},{"r":65537,"p":[{"n":"rule","p":378562}],"n":"SetAccessRule","d":1230530,"h":64425739970,"f":4},{"r":65537,"p":[{"n":"rule","p":837314}],"n":"SetAuditRule","d":1230530,"h":68720707266,"f":4}],"c":[{"p":[{"n":"isContainer","p":262145}],"n":".ctor","o":"$ctor$4","d":1230530,"h":4296197826,"f":4}],"h":1230530}; }
            static get $b() { return $.$ssa.System.Security.AccessControl.ObjectSecurity; }
            static get $fullName() { return `System.Security.AccessControl.CommonObjectSecurity`; }
        });
        
        $asm.$cls("$ssa.System.Security.AccessControl.KnownAce", ($self) => class KnownAce extends $.$ssa.System.Security.AccessControl.GenericAce
        {
            $ctor$2()
            {
                super.$ctor$1();
                {
                }
                return this;
            }
            /*int */ get AccessMask()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ set AccessMask(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Security.Principal.SecurityIdentifier */ get SecurityIdentifier()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Security.Principal.SecurityIdentifier */ set SecurityIdentifier(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static $h = 1951426;
            static $f = 0b110001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":1689282,"p":[{"p":655361,"g":{"r":0,"d":0,"h":12886853314,"f":1},"s":{"r":0,"d":0,"h":17181820610,"f":1},"n":"AccessMask","d":1951426,"h":8591886018,"f":1},{"p":436649,"g":{"r":0,"d":0,"h":25771755202,"f":1},"s":{"r":0,"d":0,"h":30066722498,"f":1},"n":"SecurityIdentifier","d":1951426,"h":21476787906,"f":1}],"c":[{"n":".ctor","o":"$ctor$2","d":1951426,"h":4296918722,"f":8}],"h":1951426}; }
            static get $b() { return $.$ssa.System.Security.AccessControl.GenericAce; }
            static get $fullName() { return `System.Security.AccessControl.KnownAce`; }
        });
        
        $asm.$cls("$ssa.System.Security.AccessControl.CommonAcl", ($self) => class CommonAcl extends $.$ssa.System.Security.AccessControl.GenericAcl
        {
            $ctor$2()
            {
                super.$ctor$1();
                {
                }
                return this;
            }
            /*int */ get BinaryLength()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ get Count()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get IsCanonical()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get IsContainer()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get IsDS()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Security.AccessControl.GenericAce*/ get_Item(/*int*/ index)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*void*/ set_Item(/*int*/ index, /*System.Security.AccessControl.GenericAce*/ value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*byte */ get Revision()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*void */ GetBinaryForm(/*byte[]*/ binaryForm, /*int*/ offset)
            {
            }
            /*void */ Purge(/*System.Security.Principal.SecurityIdentifier*/ sid)
            {
            }
            /*void */ RemoveInheritedAces()
            {
            }
            static $h = 1164994;
            static $f = 0b110001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":1754818,"p":[{"p":655361,"g":{"r":0,"d":0,"h":12886066882,"f":98305},"n":"BinaryLength","d":1164994,"h":8591099586,"f":98305},{"p":655361,"g":{"r":0,"d":0,"h":21476001474,"f":98305},"n":"Count","d":1164994,"h":17181034178,"f":98305},{"p":262145,"g":{"r":0,"d":0,"h":30065936066,"f":1},"n":"IsCanonical","d":1164994,"h":25770968770,"f":1},{"p":262145,"g":{"r":0,"d":0,"h":38655870658,"f":1},"n":"IsContainer","d":1164994,"h":34360903362,"f":1},{"p":262145,"g":{"r":0,"d":0,"h":47245805250,"f":1},"n":"IsDS","d":1164994,"h":42950837954,"f":1},{"p":1689282,"i":[{"n":"index","p":655361}],"g":{"r":0,"d":0,"h":55835739842,"f":98305},"s":{"r":0,"d":0,"h":60130707138,"f":98305},"n":"Item","o":"@$2","d":1164994,"h":51540772546,"f":98305},{"p":393217,"g":{"r":0,"d":0,"h":68720641730,"f":98305},"n":"Revision","d":1164994,"h":64425674434,"f":98305}],"m":[{"r":65537,"p":[{"n":"binaryForm","p":0},{"n":"offset","p":655361}],"n":"GetBinaryForm","d":1164994,"h":73015609026,"f":98305},{"r":65537,"p":[{"n":"sid","p":436649}],"n":"Purge","d":1164994,"h":77310576322,"f":1},{"r":65537,"n":"RemoveInheritedAces","d":1164994,"h":81605543618,"f":1}],"c":[{"n":".ctor","o":"$ctor$2","d":1164994,"h":4296132290,"f":8}],"i":[31326209,31588353],"h":1164994}; }
            static get $b() { return $.$ssa.System.Security.AccessControl.GenericAcl; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.Collections.ICollection, $.$spc.System.Collections.IEnumerable ]; }
            static get $fullName() { return `System.Security.AccessControl.CommonAcl`; }
        });
        
        $asm.$cls("$ssa.System.Security.AccessControl.NativeObjectSecurity", ($self) => class NativeObjectSecurity extends $.$ssa.System.Security.AccessControl.CommonObjectSecurity
        {
            $ctor$5(/*bool*/ isContainer, /*System.Security.AccessControl.ResourceType*/ resourceType)
            {
                super.$ctor$4(false);
                {
                }
                return this;
            }
            $ctor$6(/*bool*/ isContainer, /*System.Security.AccessControl.ResourceType*/ resourceType, /*System.Runtime.InteropServices.SafeHandle?*/ handle, /*System.Security.AccessControl.AccessControlSections*/ includeSections)
            {
                super.$ctor$4(false);
                {
                }
                return this;
            }
            $ctor$7(/*bool*/ isContainer, /*System.Security.AccessControl.ResourceType*/ resourceType, /*System.Runtime.InteropServices.SafeHandle?*/ handle, /*System.Security.AccessControl.AccessControlSections*/ includeSections, /*System.Security.AccessControl.NativeObjectSecurity.ExceptionFromErrorCode?*/ exceptionFromErrorCode, /*object?*/ exceptionContext)
            {
                super.$ctor$4(false);
                {
                }
                return this;
            }
            $ctor$8(/*bool*/ isContainer, /*System.Security.AccessControl.ResourceType*/ resourceType, /*System.Security.AccessControl.NativeObjectSecurity.ExceptionFromErrorCode?*/ exceptionFromErrorCode, /*object?*/ exceptionContext)
            {
                super.$ctor$4(false);
                {
                }
                return this;
            }
            $ctor$9(/*bool*/ isContainer, /*System.Security.AccessControl.ResourceType*/ resourceType, /*string?*/ name, /*System.Security.AccessControl.AccessControlSections*/ includeSections)
            {
                super.$ctor$4(false);
                {
                }
                return this;
            }
            $ctor$10(/*bool*/ isContainer, /*System.Security.AccessControl.ResourceType*/ resourceType, /*string?*/ name, /*System.Security.AccessControl.AccessControlSections*/ includeSections, /*System.Security.AccessControl.NativeObjectSecurity.ExceptionFromErrorCode?*/ exceptionFromErrorCode, /*object?*/ exceptionContext)
            {
                super.$ctor$4(false);
                {
                }
                return this;
            }
            /*void */ Persist$1(/*System.Runtime.InteropServices.SafeHandle*/ handle, /*System.Security.AccessControl.AccessControlSections*/ includeSections)
            {
            }
            /*void */ Persist$3(/*System.Runtime.InteropServices.SafeHandle*/ handle, /*System.Security.AccessControl.AccessControlSections*/ includeSections, /*object?*/ exceptionContext)
            {
            }
            /*void */ Persist$2(/*string*/ name, /*System.Security.AccessControl.AccessControlSections*/ includeSections)
            {
            }
            /*void */ Persist$4(/*string*/ name, /*System.Security.AccessControl.AccessControlSections*/ includeSections, /*object?*/ exceptionContext)
            {
            }
            static $_ExceptionFromErrorCode;
            static get ExceptionFromErrorCode()
            {
                let $cls = $.$ssa.System.Security.AccessControl.NativeObjectSecurity;
                return $cls.$_ExceptionFromErrorCode ??= $asm.$ncls("$ssa.System.Security.AccessControl.NativeObjectSecurity.ExceptionFromErrorCode", ($self) => class ExceptionFromErrorCode extends $.$spc.System.MulticastDelegate
                {
                    $ctor(/*object*/ target, fn)
                    {
                        this._target = target;
                        this.$nativeFunction = fn;
                        return this;
                    }
                    /*System.Exception?*/ Invoke(/*$.$spc.System.Int32*/ $errorCode, /*$.$spc.System.Nullable$$*/ $name, /*$.$spc.System.Nullable$$*/ $handle, /*$.$spc.System.Nullable$$*/ $context)
                    {
                        return this.$nativeFunction.apply(this._target, arguments);
                    }
                    static $h = 2082498;
                    static $f = 0b10000000010000000;
                    static $k = 5;
                    static $$md;
                    static get $md() { return this.$$md ??= {"b":66191361,"m":[{"r":47185921,"p":[{"n":"errorCode","p":655361},{"n":"name","p":1310721},{"n":"handle","p":109576193},{"n":"context","p":131073}],"n":"Invoke","d":2082498,"h":8592017090,"f":129},{"r":56950785,"p":[{"n":"errorCode","p":655361},{"n":"name","p":1310721},{"n":"handle","p":109576193},{"n":"context","p":131073},{"n":"callback","p":14417921},{"n":"object","p":131073}],"n":"BeginInvoke","d":2082498,"h":12886984386,"f":129},{"r":47185921,"p":[{"n":"result","p":56950785}],"n":"EndInvoke","d":2082498,"h":17181951682,"f":129}],"c":[{"p":[{"n":"object","p":131073},{"n":"method","p":786433}],"n":".ctor","o":"$ctor$5","d":2082498,"h":4297049794,"f":1}],"i":[57147393,113377281],"d":2016962,"h":2082498}; }
                    static get $b() { return $.$spc.System.MulticastDelegate; }
                    static $$i;
                    static get $i() { return this.$$i ??= [ $.$spc.System.ICloneable, $.$spc.System.Runtime.Serialization.ISerializable ]; }
                    static get $fullName() { return `System.Security.AccessControl.NativeObjectSecurity.ExceptionFromErrorCode`; }
                }, $cls, ($v) => $cls.$_ExceptionFromErrorCode = $v);
            }
            static $h = 2016962;
            static $f = 0b110001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":1230530,"m":[{"r":65537,"p":[{"n":"handle","p":109576193},{"n":"includeSections","p":247490}],"n":"Persist","o":"@$1","d":2016962,"h":30066788034,"f":98308},{"r":65537,"p":[{"n":"handle","p":109576193},{"n":"includeSections","p":247490},{"n":"exceptionContext","p":131073}],"n":"Persist","o":"@$3","d":2016962,"h":34361755330,"f":4},{"r":65537,"p":[{"n":"name","p":1310721},{"n":"includeSections","p":247490}],"n":"Persist","o":"@$2","d":2016962,"h":38656722626,"f":98308},{"r":65537,"p":[{"n":"name","p":1310721},{"n":"includeSections","p":247490},{"n":"exceptionContext","p":131073}],"n":"Persist","o":"@$4","d":2016962,"h":42951689922,"f":4}],"c":[{"p":[{"n":"isContainer","p":262145},{"n":"resourceType","p":2868930}],"n":".ctor","o":"$ctor$5","d":2016962,"h":4296984258,"f":4},{"p":[{"n":"isContainer","p":262145},{"n":"resourceType","p":2868930},{"n":"handle","p":109576193},{"n":"includeSections","p":247490}],"n":".ctor","o":"$ctor$6","d":2016962,"h":8591951554,"f":4},{"p":[{"n":"isContainer","p":262145},{"n":"resourceType","p":2868930},{"n":"handle","p":109576193},{"n":"includeSections","p":247490},{"n":"exceptionFromErrorCode","p":2082498},{"n":"exceptionContext","p":131073}],"n":".ctor","o":"$ctor$7","d":2016962,"h":12886918850,"f":4},{"p":[{"n":"isContainer","p":262145},{"n":"resourceType","p":2868930},{"n":"exceptionFromErrorCode","p":2082498},{"n":"exceptionContext","p":131073}],"n":".ctor","o":"$ctor$8","d":2016962,"h":17181886146,"f":4},{"p":[{"n":"isContainer","p":262145},{"n":"resourceType","p":2868930},{"n":"name","p":1310721},{"n":"includeSections","p":247490}],"n":".ctor","o":"$ctor$9","d":2016962,"h":21476853442,"f":4},{"p":[{"n":"isContainer","p":262145},{"n":"resourceType","p":2868930},{"n":"name","p":1310721},{"n":"includeSections","p":247490},{"n":"exceptionFromErrorCode","p":2082498},{"n":"exceptionContext","p":131073}],"n":".ctor","o":"$ctor$10","d":2016962,"h":25771820738,"f":4}],"j":[2082498],"h":2016962}; }
            static get $b() { return $.$ssa.System.Security.AccessControl.CommonObjectSecurity; }
            static get $fullName() { return `System.Security.AccessControl.NativeObjectSecurity`; }
        });
        
        $asm.$cls("$ssa.System.Security.AccessControl.ObjectAccessRule", ($self) => class ObjectAccessRule extends $.$ssa.System.Security.AccessControl.AccessRule
        {
            $ctor$3(/*System.Security.Principal.IdentityReference*/ identity, /*int*/ accessMask, /*bool*/ isInherited, /*System.Security.AccessControl.InheritanceFlags*/ inheritanceFlags, /*System.Security.AccessControl.PropagationFlags*/ propagationFlags, /*System.Guid*/ objectType, /*System.Guid*/ inheritedObjectType, /*System.Security.AccessControl.AccessControlType*/ type)
            {
                super.$ctor$2(null, 0, false, 0, 0, 0);
                {
                }
                return this;
            }
            /*System.Guid */ get InheritedObjectType()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Security.AccessControl.ObjectAceFlags */ get ObjectFlags()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Guid */ get ObjectType()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static $h = 2148034;
            static $f = 0b110001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":378562,"p":[{"p":56164353,"g":{"r":0,"d":0,"h":12887049922,"f":1},"n":"InheritedObjectType","d":2148034,"h":8592082626,"f":1},{"p":2279106,"g":{"r":0,"d":0,"h":21476984514,"f":1},"n":"ObjectFlags","d":2148034,"h":17182017218,"f":1},{"p":56164353,"g":{"r":0,"d":0,"h":30066919106,"f":1},"n":"ObjectType","d":2148034,"h":25771951810,"f":1}],"c":[{"p":[{"n":"identity","p":240041},{"n":"accessMask","p":655361},{"n":"isInherited","p":262145},{"n":"inheritanceFlags","p":1885890},{"n":"propagationFlags","p":2606786},{"n":"objectType","p":56164353},{"n":"inheritedObjectType","p":56164353},{"n":"type","p":313026}],"n":".ctor","o":"$ctor$3","d":2148034,"h":4297115330,"f":4}],"h":2148034}; }
            static get $b() { return $.$ssa.System.Security.AccessControl.AccessRule; }
            static get $fullName() { return `System.Security.AccessControl.ObjectAccessRule`; }
        });
        
        $asm.$cls("$ssa.System.Security.AccessControl.ObjectAuditRule", ($self) => class ObjectAuditRule extends $.$ssa.System.Security.AccessControl.AuditRule
        {
            $ctor$3(/*System.Security.Principal.IdentityReference*/ identity, /*int*/ accessMask, /*bool*/ isInherited, /*System.Security.AccessControl.InheritanceFlags*/ inheritanceFlags, /*System.Security.AccessControl.PropagationFlags*/ propagationFlags, /*System.Guid*/ objectType, /*System.Guid*/ inheritedObjectType, /*System.Security.AccessControl.AuditFlags*/ auditFlags)
            {
                super.$ctor$2(null, 0, false, 0, 0, 0);
                {
                }
                return this;
            }
            /*System.Guid */ get InheritedObjectType()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Security.AccessControl.ObjectAceFlags */ get ObjectFlags()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Guid */ get ObjectType()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static $h = 2344642;
            static $f = 0b110001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":837314,"p":[{"p":56164353,"g":{"r":0,"d":0,"h":12887246530,"f":1},"n":"InheritedObjectType","d":2344642,"h":8592279234,"f":1},{"p":2279106,"g":{"r":0,"d":0,"h":21477181122,"f":1},"n":"ObjectFlags","d":2344642,"h":17182213826,"f":1},{"p":56164353,"g":{"r":0,"d":0,"h":30067115714,"f":1},"n":"ObjectType","d":2344642,"h":25772148418,"f":1}],"c":[{"p":[{"n":"identity","p":240041},{"n":"accessMask","p":655361},{"n":"isInherited","p":262145},{"n":"inheritanceFlags","p":1885890},{"n":"propagationFlags","p":2606786},{"n":"objectType","p":56164353},{"n":"inheritedObjectType","p":56164353},{"n":"auditFlags","p":771778}],"n":".ctor","o":"$ctor$3","d":2344642,"h":4297311938,"f":4}],"h":2344642}; }
            static get $b() { return $.$ssa.System.Security.AccessControl.AuditRule; }
            static get $fullName() { return `System.Security.AccessControl.ObjectAuditRule`; }
        });
        
        $asm.$cls("$ssa.System.Security.AccessControl.QualifiedAce", ($self) => class QualifiedAce extends $.$ssa.System.Security.AccessControl.KnownAce
        {
            $ctor$3()
            {
                super.$ctor$2();
                {
                }
                return this;
            }
            /*System.Security.AccessControl.AceQualifier */ get AceQualifier()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get IsCallback()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ get OpaqueLength()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*byte[]? */ GetOpaque()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*void */ SetOpaque(/*byte[]?*/ opaque)
            {
            }
            static $h = 2672322;
            static $f = 0b110001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":1951426,"p":[{"p":640706,"g":{"r":0,"d":0,"h":12887574210,"f":1},"n":"AceQualifier","d":2672322,"h":8592606914,"f":1},{"p":262145,"g":{"r":0,"d":0,"h":21477508802,"f":1},"n":"IsCallback","d":2672322,"h":17182541506,"f":1},{"p":655361,"g":{"r":0,"d":0,"h":30067443394,"f":1},"n":"OpaqueLength","d":2672322,"h":25772476098,"f":1}],"m":[{"r":0,"n":"GetOpaque","d":2672322,"h":34362410690,"f":1},{"r":65537,"p":[{"n":"opaque","p":0}],"n":"SetOpaque","d":2672322,"h":38657377986,"f":1}],"c":[{"n":".ctor","o":"$ctor$3","d":2672322,"h":4297639618,"f":8}],"h":2672322}; }
            static get $b() { return $.$ssa.System.Security.AccessControl.KnownAce; }
            static get $fullName() { return `System.Security.AccessControl.QualifiedAce`; }
        });
        
        $asm.$cls("$ssa.System.Security.AccessControl.ObjectSecurity<>", (T) => $asm.$gt("$ssa.System.Security.AccessControl.ObjectSecurity<>", [T], ($self) => class ObjectSecurity$$ extends $.$ssa.System.Security.AccessControl.NativeObjectSecurity
        {
            $ctor$11(/*bool*/ isContainer, /*System.Security.AccessControl.ResourceType*/ resourceType)
            {
                super.$ctor$5(false, 0);
                {
                }
                return this;
            }
            $ctor$12(/*bool*/ isContainer, /*System.Security.AccessControl.ResourceType*/ resourceType, /*System.Runtime.InteropServices.SafeHandle?*/ safeHandle, /*System.Security.AccessControl.AccessControlSections*/ includeSections)
            {
                super.$ctor$5(false, 0);
                {
                }
                return this;
            }
            $ctor$13(/*bool*/ isContainer, /*System.Security.AccessControl.ResourceType*/ resourceType, /*System.Runtime.InteropServices.SafeHandle?*/ safeHandle, /*System.Security.AccessControl.AccessControlSections*/ includeSections, /*System.Security.AccessControl.NativeObjectSecurity.ExceptionFromErrorCode?*/ exceptionFromErrorCode, /*object?*/ exceptionContext)
            {
                super.$ctor$5(false, 0);
                {
                }
                return this;
            }
            $ctor$14(/*bool*/ isContainer, /*System.Security.AccessControl.ResourceType*/ resourceType, /*string?*/ name, /*System.Security.AccessControl.AccessControlSections*/ includeSections)
            {
                super.$ctor$5(false, 0);
                {
                }
                return this;
            }
            $ctor$15(/*bool*/ isContainer, /*System.Security.AccessControl.ResourceType*/ resourceType, /*string?*/ name, /*System.Security.AccessControl.AccessControlSections*/ includeSections, /*System.Security.AccessControl.NativeObjectSecurity.ExceptionFromErrorCode?*/ exceptionFromErrorCode, /*object?*/ exceptionContext)
            {
                super.$ctor$5(false, 0);
                {
                }
                return this;
            }
            /*System.Type */ get AccessRightType()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Type */ get AccessRuleType()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Type */ get AuditRuleType()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Security.AccessControl.AccessRule */ AccessRuleFactory(/*System.Security.Principal.IdentityReference*/ identityReference, /*int*/ accessMask, /*bool*/ isInherited, /*System.Security.AccessControl.InheritanceFlags*/ inheritanceFlags, /*System.Security.AccessControl.PropagationFlags*/ propagationFlags, /*System.Security.AccessControl.AccessControlType*/ type)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*void */ AddAccessRule$1(/*System.Security.AccessControl.AccessRule<T>*/ rule)
            {
            }
            /*void */ AddAuditRule$1(/*System.Security.AccessControl.AuditRule<T>*/ rule)
            {
            }
            /*System.Security.AccessControl.AuditRule */ AuditRuleFactory(/*System.Security.Principal.IdentityReference*/ identityReference, /*int*/ accessMask, /*bool*/ isInherited, /*System.Security.AccessControl.InheritanceFlags*/ inheritanceFlags, /*System.Security.AccessControl.PropagationFlags*/ propagationFlags, /*System.Security.AccessControl.AuditFlags*/ flags)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*void */ Persist$5(/*System.Runtime.InteropServices.SafeHandle*/ handle)
            {
            }
            /*void */ Persist$6(/*string*/ name)
            {
            }
            /*bool */ RemoveAccessRule$1(/*System.Security.AccessControl.AccessRule<T>*/ rule)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*void */ RemoveAccessRuleAll$1(/*System.Security.AccessControl.AccessRule<T>*/ rule)
            {
            }
            /*void */ RemoveAccessRuleSpecific$1(/*System.Security.AccessControl.AccessRule<T>*/ rule)
            {
            }
            /*bool */ RemoveAuditRule$1(/*System.Security.AccessControl.AuditRule<T>*/ rule)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*void */ RemoveAuditRuleAll$1(/*System.Security.AccessControl.AuditRule<T>*/ rule)
            {
            }
            /*void */ RemoveAuditRuleSpecific$1(/*System.Security.AccessControl.AuditRule<T>*/ rule)
            {
            }
            /*void */ ResetAccessRule$1(/*System.Security.AccessControl.AccessRule<T>*/ rule)
            {
            }
            /*void */ SetAccessRule$1(/*System.Security.AccessControl.AccessRule<T>*/ rule)
            {
            }
            /*void */ SetAuditRule$1(/*System.Security.AccessControl.AuditRule<T>*/ rule)
            {
            }
            static $h = 2475714;
            static $g = 1;
            static $f = 0b1110001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":2016962,"p":[{"p":142606337,"g":{"r":0,"d":0,"h":Number(BigInt(this.$h)|0x700000000n),"f":32769},"n":"AccessRightType","d":this.$h,"h":Number(BigInt(this.$h)|0x600000000n),"f":32769},{"p":142606337,"g":{"r":0,"d":0,"h":Number(BigInt(this.$h)|0x900000000n),"f":32769},"n":"AccessRuleType","d":this.$h,"h":Number(BigInt(this.$h)|0x800000000n),"f":32769},{"p":142606337,"g":{"r":0,"d":0,"h":Number(BigInt(this.$h)|0xB00000000n),"f":32769},"n":"AuditRuleType","d":this.$h,"h":Number(BigInt(this.$h)|0xA00000000n),"f":32769}],"m":[{"r":378562,"p":[{"n":"identityReference","p":240041},{"n":"accessMask","p":655361},{"n":"isInherited","p":262145},{"n":"inheritanceFlags","p":1885890},{"n":"propagationFlags","p":2606786},{"n":"type","p":313026}],"n":"AccessRuleFactory","d":this.$h,"h":Number(BigInt(this.$h)|0xC00000000n),"f":32769},{"r":65537,"p":[{"n":"rule","p":$.$ssa.System.Security.AccessControl.AccessRule$$(T).$h}],"n":"AddAccessRule","o":"@$1","d":this.$h,"h":Number(BigInt(this.$h)|0xD00000000n),"f":129},{"r":65537,"p":[{"n":"rule","p":$.$ssa.System.Security.AccessControl.AuditRule$$(T).$h}],"n":"AddAuditRule","o":"@$1","d":this.$h,"h":Number(BigInt(this.$h)|0xE00000000n),"f":129},{"r":837314,"p":[{"n":"identityReference","p":240041},{"n":"accessMask","p":655361},{"n":"isInherited","p":262145},{"n":"inheritanceFlags","p":1885890},{"n":"propagationFlags","p":2606786},{"n":"flags","p":771778}],"n":"AuditRuleFactory","d":this.$h,"h":Number(BigInt(this.$h)|0xF00000000n),"f":32769},{"r":65537,"p":[{"n":"handle","p":109576193}],"n":"Persist","o":"@$5","d":this.$h,"h":Number(BigInt(this.$h)|0x1000000000n),"f":16},{"r":65537,"p":[{"n":"name","p":1310721}],"n":"Persist","o":"@$6","d":this.$h,"h":Number(BigInt(this.$h)|0x1100000000n),"f":16},{"r":262145,"p":[{"n":"rule","p":$.$ssa.System.Security.AccessControl.AccessRule$$(T).$h}],"n":"RemoveAccessRule","o":"@$1","d":this.$h,"h":Number(BigInt(this.$h)|0x1200000000n),"f":129},{"r":65537,"p":[{"n":"rule","p":$.$ssa.System.Security.AccessControl.AccessRule$$(T).$h}],"n":"RemoveAccessRuleAll","o":"@$1","d":this.$h,"h":Number(BigInt(this.$h)|0x1300000000n),"f":129},{"r":65537,"p":[{"n":"rule","p":$.$ssa.System.Security.AccessControl.AccessRule$$(T).$h}],"n":"RemoveAccessRuleSpecific","o":"@$1","d":this.$h,"h":Number(BigInt(this.$h)|0x1400000000n),"f":129},{"r":262145,"p":[{"n":"rule","p":$.$ssa.System.Security.AccessControl.AuditRule$$(T).$h}],"n":"RemoveAuditRule","o":"@$1","d":this.$h,"h":Number(BigInt(this.$h)|0x1500000000n),"f":129},{"r":65537,"p":[{"n":"rule","p":$.$ssa.System.Security.AccessControl.AuditRule$$(T).$h}],"n":"RemoveAuditRuleAll","o":"@$1","d":this.$h,"h":Number(BigInt(this.$h)|0x1600000000n),"f":129},{"r":65537,"p":[{"n":"rule","p":$.$ssa.System.Security.AccessControl.AuditRule$$(T).$h}],"n":"RemoveAuditRuleSpecific","o":"@$1","d":this.$h,"h":Number(BigInt(this.$h)|0x1700000000n),"f":129},{"r":65537,"p":[{"n":"rule","p":$.$ssa.System.Security.AccessControl.AccessRule$$(T).$h}],"n":"ResetAccessRule","o":"@$1","d":this.$h,"h":Number(BigInt(this.$h)|0x1800000000n),"f":129},{"r":65537,"p":[{"n":"rule","p":$.$ssa.System.Security.AccessControl.AccessRule$$(T).$h}],"n":"SetAccessRule","o":"@$1","d":this.$h,"h":Number(BigInt(this.$h)|0x1900000000n),"f":129},{"r":65537,"p":[{"n":"rule","p":$.$ssa.System.Security.AccessControl.AuditRule$$(T).$h}],"n":"SetAuditRule","o":"@$1","d":this.$h,"h":Number(BigInt(this.$h)|0x1A00000000n),"f":129}],"c":[{"p":[{"n":"isContainer","p":262145},{"n":"resourceType","p":2868930}],"n":".ctor","o":"$ctor$11","d":this.$h,"h":Number(BigInt(this.$h)|0x100000000n),"f":4},{"p":[{"n":"isContainer","p":262145},{"n":"resourceType","p":2868930},{"n":"safeHandle","p":109576193},{"n":"includeSections","p":247490}],"n":".ctor","o":"$ctor$12","d":this.$h,"h":Number(BigInt(this.$h)|0x200000000n),"f":4},{"p":[{"n":"isContainer","p":262145},{"n":"resourceType","p":2868930},{"n":"safeHandle","p":109576193},{"n":"includeSections","p":247490},{"n":"exceptionFromErrorCode","p":2082498},{"n":"exceptionContext","p":131073}],"n":".ctor","o":"$ctor$13","d":this.$h,"h":Number(BigInt(this.$h)|0x300000000n),"f":4},{"p":[{"n":"isContainer","p":262145},{"n":"resourceType","p":2868930},{"n":"name","p":1310721},{"n":"includeSections","p":247490}],"n":".ctor","o":"$ctor$14","d":this.$h,"h":Number(BigInt(this.$h)|0x400000000n),"f":4},{"p":[{"n":"isContainer","p":262145},{"n":"resourceType","p":2868930},{"n":"name","p":1310721},{"n":"includeSections","p":247490},{"n":"exceptionFromErrorCode","p":2082498},{"n":"exceptionContext","p":131073}],"n":".ctor","o":"$ctor$15","d":this.$h,"h":Number(BigInt(this.$h)|0x500000000n),"f":4}],"g":[T?.$h??1507328],"s":[{"n":"T","f":2}],"r":1,"h":this.$h}; }
            static get $b() { return $.$ssa.System.Security.AccessControl.NativeObjectSecurity; }
            static get $fullName() { return `System.Security.AccessControl.ObjectSecurity<${T?.$fullName}>`; }
        }));
        
        $asm.$cls("$ssa.System.Security.AccessControl.AceEnumerator", ($self) => class AceEnumerator extends $.$spc.System.Object
        {
            $ctor$1()
            {
                super.$ctor();
                {
                }
                return this;
            }
            /*System.Security.AccessControl.GenericAce */ get Current()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*object */ get System$Collections$IEnumerator$Current()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ MoveNext()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*void */ Reset()
            {
            }
            //Generated interface implemetation for System.Collections.IEnumerator.MoveNext()
            System$Collections$IEnumerator$MoveNext()
            {
                return this.MoveNext(...arguments);
            }
            //Generated interface implemetation for System.Collections.IEnumerator.Reset()
            System$Collections$IEnumerator$Reset()
            {
                return this.Reset(...arguments);
            }
            static $h = 509634;
            static $f = 0b10010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":1689282,"g":{"r":0,"d":0,"h":12885411522,"f":1},"n":"Current","d":509634,"h":8590444226,"f":1},{"p":131073,"g":{"r":0,"d":0,"h":21475346114,"f":2},"n":"{31719425}.Current","o":"System$Collections$IEnumerator$Current","d":509634,"h":17180378818,"f":2}],"m":[{"r":262145,"n":"MoveNext","d":509634,"h":25770313410,"f":1},{"r":65537,"n":"Reset","d":509634,"h":30065280706,"f":1}],"c":[{"n":".ctor","o":"$ctor$1","d":509634,"h":4295476930,"f":8}],"i":[31719425],"h":509634}; }
            static get $b() { return $.$spc.System.Object; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.Collections.IEnumerator ]; }
            static get $fullName() { return `System.Security.AccessControl.AceEnumerator`; }
        });
        
        $asm.$cls("$ssa.System.Security.Policy.Evidence", ($self) => class Evidence extends $.$spc.System.Object
        {
            $ctor$1()
            {
                super.$ctor();
                {
                }
                return this;
            }
            $ctor$2(/*object[]*/ hostEvidence, /*object[]*/ assemblyEvidence)
            {
                super.$ctor();
                {
                }
                return this;
            }
            $ctor$3(/*System.Security.Policy.Evidence*/ evidence)
            {
                super.$ctor();
                {
                }
                return this;
            }
            $ctor$4(/*System.Security.Policy.EvidenceBase[]*/ hostEvidence, /*System.Security.Policy.EvidenceBase[]*/ assemblyEvidence)
            {
                super.$ctor();
                {
                }
                return this;
            }
            /*int */ get Count()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get IsReadOnly()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get IsSynchronized()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get Locked()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ set Locked(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*object */ get SyncRoot()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*void */ AddAssembly(/*object*/ id)
            {
            }
            /*void */ AddAssemblyEvidence(T, /*T*/ evidence)
            {
            }
            /*void */ AddHost(/*object*/ id)
            {
            }
            /*void */ AddHostEvidence(T, /*T*/ evidence)
            {
            }
            /*void */ Clear()
            {
            }
            /*System.Security.Policy.Evidence? */ Clone()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*void */ CopyTo(/*System.Array*/ array, /*int*/ index)
            {
            }
            /*System.Collections.IEnumerator */ GetAssemblyEnumerator()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*T? */ GetAssemblyEvidence(T, )
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Collections.IEnumerator */ GetEnumerator()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Collections.IEnumerator */ GetHostEnumerator()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*T? */ GetHostEvidence(T, )
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*void */ Merge(/*System.Security.Policy.Evidence*/ evidence)
            {
            }
            /*void */ RemoveType(/*System.Type*/ t)
            {
            }
            //Generated interface implemetation for System.Collections.ICollection.CopyTo(System.Array, int)
            System$Collections$ICollection$CopyTo()
            {
                return this.CopyTo(...arguments);
            }
            //Generated interface implemetation for System.Collections.ICollection.Count.get
            get System$Collections$ICollection$Count()
            {
                return this.Count;
            }
            //Generated interface implemetation for System.Collections.ICollection.SyncRoot.get
            get System$Collections$ICollection$SyncRoot()
            {
                return this.SyncRoot;
            }
            //Generated interface implemetation for System.Collections.ICollection.IsSynchronized.get
            get System$Collections$ICollection$IsSynchronized()
            {
                return this.IsSynchronized;
            }
            //Generated interface implemetation for System.Collections.IEnumerable.GetEnumerator()
            System$Collections$IEnumerable$GetEnumerator()
            {
                return this.GetEnumerator(...arguments);
            }
            static $h = 3065538;
            static $f = 0b10010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":655361,"g":{"r":0,"d":0,"h":25772869314,"f":1},"n":"Count","d":3065538,"h":21477902018,"f":1,"a":[{"t":70909953,"c":8660844545,"a":[{"v":"Evidence should not be treated as an ICollection. Use GetHostEnumerator and GetAssemblyEnumerator to iterate over the evidence to collect a count.","t":1310721}]}]},{"p":262145,"g":{"r":0,"d":0,"h":34362803906,"f":1},"n":"IsReadOnly","d":3065538,"h":30067836610,"f":1},{"p":262145,"g":{"r":0,"d":0,"h":42952738498,"f":1},"n":"IsSynchronized","d":3065538,"h":38657771202,"f":1},{"p":262145,"g":{"r":0,"d":0,"h":51542673090,"f":1},"s":{"r":0,"d":0,"h":55837640386,"f":1},"n":"Locked","d":3065538,"h":47247705794,"f":1},{"p":131073,"g":{"r":0,"d":0,"h":64427574978,"f":1},"n":"SyncRoot","d":3065538,"h":60132607682,"f":1}],"m":[{"r":65537,"p":[{"n":"id","p":131073}],"n":"AddAssembly","d":3065538,"h":68722542274,"f":1,"a":[{"t":70909953,"c":8660844545,"a":[{"v":"Evidence.AddAssembly has been deprecated. Use AddAssemblyEvidence instead.","t":1310721}]}]},{"r":65537,"p":[{"n":"evidence","p":68723081216}],"g":["T"],"n":"AddAssemblyEvidence","d":3065538,"h":73017509570,"f":131073},{"r":65537,"p":[{"n":"id","p":131073}],"n":"AddHost","d":3065538,"h":77312476866,"f":1,"a":[{"t":70909953,"c":8660844545,"a":[{"v":"Evidence.AddHost has been deprecated. Use AddHostEvidence instead.","t":1310721}]}]},{"r":65537,"p":[{"n":"evidence","p":77313015808}],"g":["T"],"n":"AddHostEvidence","d":3065538,"h":81607444162,"f":131073},{"r":65537,"n":"Clear","d":3065538,"h":85902411458,"f":1},{"r":3065538,"n":"Clone","d":3065538,"h":90197378754,"f":1},{"r":65537,"p":[{"n":"array","p":1245185},{"n":"index","p":655361}],"n":"CopyTo","d":3065538,"h":94492346050,"f":1,"a":[{"t":70909953,"c":8660844545,"a":[{"v":"Evidence should not be treated as an ICollection. Use the GetHostEnumerator and GetAssemblyEnumerator methods rather than using CopyTo.","t":1310721}]}]},{"r":31719425,"n":"GetAssemblyEnumerator","d":3065538,"h":98787313346,"f":1},{"r":98787852288,"g":["T"],"n":"GetAssemblyEvidence","d":3065538,"h":103082280642,"f":131073},{"r":31719425,"n":"GetEnumerator","d":3065538,"h":107377247938,"f":1,"a":[{"t":70909953,"c":8660844545,"a":[{"v":"GetEnumerator is obsolete. Use GetAssemblyEnumerator and GetHostEnumerator instead.","t":1310721}]}]},{"r":31719425,"n":"GetHostEnumerator","d":3065538,"h":111672215234,"f":1},{"r":111672754176,"g":["T"],"n":"GetHostEvidence","d":3065538,"h":115967182530,"f":131073},{"r":65537,"p":[{"n":"evidence","p":3065538}],"n":"Merge","d":3065538,"h":120262149826,"f":1},{"r":65537,"p":[{"n":"t","p":142606337}],"n":"RemoveType","d":3065538,"h":124557117122,"f":1}],"c":[{"n":".ctor","o":"$ctor$1","d":3065538,"h":4298032834,"f":1},{"p":[{"n":"hostEvidence","p":0},{"n":"assemblyEvidence","p":0}],"n":".ctor","o":"$ctor$2","d":3065538,"h":8593000130,"f":1,"a":[{"t":70909953,"c":8660844545,"a":[{"v":"This constructor is obsolete. Use the constructor which accepts arrays of EvidenceBase instead.","t":1310721}]}]},{"p":[{"n":"evidence","p":3065538}],"n":".ctor","o":"$ctor$3","d":3065538,"h":12887967426,"f":1},{"p":[{"n":"hostEvidence","p":0},{"n":"assemblyEvidence","p":0}],"n":".ctor","o":"$ctor$4","d":3065538,"h":17182934722,"f":1}],"i":[31326209,31588353],"h":3065538}; }
            static get $b() { return $.$spc.System.Object; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.Collections.ICollection, $.$spc.System.Collections.IEnumerable ]; }
            static get $fullName() { return `System.Security.Policy.Evidence`; }
        });
        
        $asm.$cls("$ssa.System.Security.AccessControl.CommonSecurityDescriptor", ($self) => class CommonSecurityDescriptor extends $.$ssa.System.Security.AccessControl.GenericSecurityDescriptor
        {
            $ctor$2(/*bool*/ isContainer, /*bool*/ isDS, /*byte[]*/ binaryForm, /*int*/ offset)
            {
                super.$ctor$1();
                {
                }
                return this;
            }
            $ctor$3(/*bool*/ isContainer, /*bool*/ isDS, /*System.Security.AccessControl.ControlFlags*/ flags, /*System.Security.Principal.SecurityIdentifier?*/ owner, /*System.Security.Principal.SecurityIdentifier?*/ group, /*System.Security.AccessControl.SystemAcl?*/ systemAcl, /*System.Security.AccessControl.DiscretionaryAcl?*/ discretionaryAcl)
            {
                super.$ctor$1();
                {
                }
                return this;
            }
            $ctor$4(/*bool*/ isContainer, /*bool*/ isDS, /*System.Security.AccessControl.RawSecurityDescriptor*/ rawSecurityDescriptor)
            {
                super.$ctor$1();
                {
                }
                return this;
            }
            $ctor$5(/*bool*/ isContainer, /*bool*/ isDS, /*string*/ sddlForm)
            {
                super.$ctor$1();
                {
                }
                return this;
            }
            /*System.Security.AccessControl.ControlFlags */ get ControlFlags()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Security.AccessControl.DiscretionaryAcl? */ get DiscretionaryAcl()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Security.AccessControl.DiscretionaryAcl? */ set DiscretionaryAcl(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Security.Principal.SecurityIdentifier? */ get Group()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Security.Principal.SecurityIdentifier? */ set Group(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get IsContainer()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get IsDiscretionaryAclCanonical()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get IsDS()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get IsSystemAclCanonical()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Security.Principal.SecurityIdentifier? */ get Owner()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Security.Principal.SecurityIdentifier? */ set Owner(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Security.AccessControl.SystemAcl? */ get SystemAcl()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Security.AccessControl.SystemAcl? */ set SystemAcl(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*void */ AddDiscretionaryAcl(/*byte*/ revision, /*int*/ trusted)
            {
            }
            /*void */ AddSystemAcl(/*byte*/ revision, /*int*/ trusted)
            {
            }
            /*void */ PurgeAccessControl(/*System.Security.Principal.SecurityIdentifier*/ sid)
            {
            }
            /*void */ PurgeAudit(/*System.Security.Principal.SecurityIdentifier*/ sid)
            {
            }
            /*void */ SetDiscretionaryAclProtection(/*bool*/ isProtected, /*bool*/ preserveInheritance)
            {
            }
            /*void */ SetSystemAclProtection(/*bool*/ isProtected, /*bool*/ preserveInheritance)
            {
            }
            static $h = 1296066;
            static $f = 0b10010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":1820354,"p":[{"p":1492674,"g":{"r":0,"d":0,"h":25771099842,"f":32769},"n":"ControlFlags","d":1296066,"h":21476132546,"f":32769},{"p":1623746,"g":{"r":0,"d":0,"h":34361034434,"f":1},"s":{"r":0,"d":0,"h":38656001730,"f":1},"n":"DiscretionaryAcl","d":1296066,"h":30066067138,"f":1},{"p":436649,"g":{"r":0,"d":0,"h":47245936322,"f":32769},"s":{"r":0,"d":0,"h":51540903618,"f":32769},"n":"Group","d":1296066,"h":42950969026,"f":32769},{"p":262145,"g":{"r":0,"d":0,"h":60130838210,"f":1},"n":"IsContainer","d":1296066,"h":55835870914,"f":1},{"p":262145,"g":{"r":0,"d":0,"h":68720772802,"f":1},"n":"IsDiscretionaryAclCanonical","d":1296066,"h":64425805506,"f":1},{"p":262145,"g":{"r":0,"d":0,"h":77310707394,"f":1},"n":"IsDS","d":1296066,"h":73015740098,"f":1},{"p":262145,"g":{"r":0,"d":0,"h":85900641986,"f":1},"n":"IsSystemAclCanonical","d":1296066,"h":81605674690,"f":1},{"p":436649,"g":{"r":0,"d":0,"h":94490576578,"f":32769},"s":{"r":0,"d":0,"h":98785543874,"f":32769},"n":"Owner","d":1296066,"h":90195609282,"f":32769},{"p":3000002,"g":{"r":0,"d":0,"h":107375478466,"f":1},"s":{"r":0,"d":0,"h":111670445762,"f":1},"n":"SystemAcl","d":1296066,"h":103080511170,"f":1}],"m":[{"r":65537,"p":[{"n":"revision","p":393217},{"n":"trusted","p":655361}],"n":"AddDiscretionaryAcl","d":1296066,"h":115965413058,"f":1},{"r":65537,"p":[{"n":"revision","p":393217},{"n":"trusted","p":655361}],"n":"AddSystemAcl","d":1296066,"h":120260380354,"f":1},{"r":65537,"p":[{"n":"sid","p":436649}],"n":"PurgeAccessControl","d":1296066,"h":124555347650,"f":1},{"r":65537,"p":[{"n":"sid","p":436649}],"n":"PurgeAudit","d":1296066,"h":128850314946,"f":1},{"r":65537,"p":[{"n":"isProtected","p":262145},{"n":"preserveInheritance","p":262145}],"n":"SetDiscretionaryAclProtection","d":1296066,"h":133145282242,"f":1},{"r":65537,"p":[{"n":"isProtected","p":262145},{"n":"preserveInheritance","p":262145}],"n":"SetSystemAclProtection","d":1296066,"h":137440249538,"f":1}],"c":[{"p":[{"n":"isContainer","p":262145},{"n":"isDS","p":262145},{"n":"binaryForm","p":0},{"n":"offset","p":655361}],"n":".ctor","o":"$ctor$2","d":1296066,"h":4296263362,"f":1},{"p":[{"n":"isContainer","p":262145},{"n":"isDS","p":262145},{"n":"flags","p":1492674},{"n":"owner","p":436649},{"n":"group","p":436649},{"n":"systemAcl","p":3000002},{"n":"discretionaryAcl","p":1623746}],"n":".ctor","o":"$ctor$3","d":1296066,"h":8591230658,"f":1},{"p":[{"n":"isContainer","p":262145},{"n":"isDS","p":262145},{"n":"rawSecurityDescriptor","p":2803394}],"n":".ctor","o":"$ctor$4","d":1296066,"h":12886197954,"f":1},{"p":[{"n":"isContainer","p":262145},{"n":"isDS","p":262145},{"n":"sddlForm","p":1310721}],"n":".ctor","o":"$ctor$5","d":1296066,"h":17181165250,"f":1}],"h":1296066}; }
            static get $b() { return $.$ssa.System.Security.AccessControl.GenericSecurityDescriptor; }
            static get $fullName() { return `System.Security.AccessControl.CommonSecurityDescriptor`; }
        });
        
        $asm.$cls("$ssa.System.Security.AccessControl.CustomAce", ($self) => class CustomAce extends $.$ssa.System.Security.AccessControl.GenericAce
        {
            /*int*/ static MaxOpaqueLength = 0;
            $ctor$2(/*System.Security.AccessControl.AceType*/ type, /*System.Security.AccessControl.AceFlags*/ flags, /*byte[]?*/ opaque)
            {
                super.$ctor$1();
                {
                }
                return this;
            }
            /*int */ get BinaryLength()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ get OpaqueLength()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*void */ GetBinaryForm(/*byte[]*/ binaryForm, /*int*/ offset)
            {
            }
            /*byte[]? */ GetOpaque()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*void */ SetOpaque(/*byte[]?*/ opaque)
            {
            }
            static $h = 1558210;
            static $f = 0b10010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":1689282,"p":[{"p":655361,"g":{"r":0,"d":0,"h":17181427394,"f":32769},"n":"BinaryLength","d":1558210,"h":12886460098,"f":32769},{"p":655361,"g":{"r":0,"d":0,"h":25771361986,"f":1},"n":"OpaqueLength","d":1558210,"h":21476394690,"f":1}],"m":[{"r":65537,"p":[{"n":"binaryForm","p":0},{"n":"offset","p":655361}],"n":"GetBinaryForm","d":1558210,"h":30066329282,"f":32769},{"r":0,"n":"GetOpaque","d":1558210,"h":34361296578,"f":1},{"r":65537,"p":[{"n":"opaque","p":0}],"n":"SetOpaque","d":1558210,"h":38656263874,"f":1}],"l":[{"t":655361,"n":"MaxOpaqueLength","d":1558210,"h":4296525506,"f":33}],"c":[{"p":[{"n":"type","p":706242},{"n":"flags","p":575170},{"n":"opaque","p":0}],"n":".ctor","o":"$ctor$2","d":1558210,"h":8591492802,"f":1}],"h":1558210}; }
            static get $b() { return $.$ssa.System.Security.AccessControl.GenericAce; }
            static get $fullName() { return `System.Security.AccessControl.CustomAce`; }
        });
        
        $asm.$cls("$ssa.System.Security.AccessControl.RawSecurityDescriptor", ($self) => class RawSecurityDescriptor extends $.$ssa.System.Security.AccessControl.GenericSecurityDescriptor
        {
            $ctor$2(/*byte[]*/ binaryForm, /*int*/ offset)
            {
                super.$ctor$1();
                {
                }
                return this;
            }
            $ctor$3(/*System.Security.AccessControl.ControlFlags*/ flags, /*System.Security.Principal.SecurityIdentifier?*/ owner, /*System.Security.Principal.SecurityIdentifier?*/ group, /*System.Security.AccessControl.RawAcl?*/ systemAcl, /*System.Security.AccessControl.RawAcl?*/ discretionaryAcl)
            {
                super.$ctor$1();
                {
                }
                return this;
            }
            $ctor$4(/*string*/ sddlForm)
            {
                super.$ctor$1();
                {
                }
                return this;
            }
            /*System.Security.AccessControl.ControlFlags */ get ControlFlags()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Security.AccessControl.RawAcl? */ get DiscretionaryAcl()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Security.AccessControl.RawAcl? */ set DiscretionaryAcl(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Security.Principal.SecurityIdentifier? */ get Group()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Security.Principal.SecurityIdentifier? */ set Group(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Security.Principal.SecurityIdentifier? */ get Owner()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Security.Principal.SecurityIdentifier? */ set Owner(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*byte */ get ResourceManagerControl()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*byte */ set ResourceManagerControl(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Security.AccessControl.RawAcl? */ get SystemAcl()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Security.AccessControl.RawAcl? */ set SystemAcl(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*void */ SetFlags(/*System.Security.AccessControl.ControlFlags*/ flags)
            {
            }
            static $h = 2803394;
            static $f = 0b10010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":1820354,"p":[{"p":1492674,"g":{"r":0,"d":0,"h":21477639874,"f":32769},"n":"ControlFlags","d":2803394,"h":17182672578,"f":32769},{"p":2737858,"g":{"r":0,"d":0,"h":30067574466,"f":1},"s":{"r":0,"d":0,"h":34362541762,"f":1},"n":"DiscretionaryAcl","d":2803394,"h":25772607170,"f":1},{"p":436649,"g":{"r":0,"d":0,"h":42952476354,"f":32769},"s":{"r":0,"d":0,"h":47247443650,"f":32769},"n":"Group","d":2803394,"h":38657509058,"f":32769},{"p":436649,"g":{"r":0,"d":0,"h":55837378242,"f":32769},"s":{"r":0,"d":0,"h":60132345538,"f":32769},"n":"Owner","d":2803394,"h":51542410946,"f":32769},{"p":393217,"g":{"r":0,"d":0,"h":68722280130,"f":1},"s":{"r":0,"d":0,"h":73017247426,"f":1},"n":"ResourceManagerControl","d":2803394,"h":64427312834,"f":1},{"p":2737858,"g":{"r":0,"d":0,"h":81607182018,"f":1},"s":{"r":0,"d":0,"h":85902149314,"f":1},"n":"SystemAcl","d":2803394,"h":77312214722,"f":1}],"m":[{"r":65537,"p":[{"n":"flags","p":1492674}],"n":"SetFlags","d":2803394,"h":90197116610,"f":1}],"c":[{"p":[{"n":"binaryForm","p":0},{"n":"offset","p":655361}],"n":".ctor","o":"$ctor$2","d":2803394,"h":4297770690,"f":1},{"p":[{"n":"flags","p":1492674},{"n":"owner","p":436649},{"n":"group","p":436649},{"n":"systemAcl","p":2737858},{"n":"discretionaryAcl","p":2737858}],"n":".ctor","o":"$ctor$3","d":2803394,"h":8592737986,"f":1},{"p":[{"n":"sddlForm","p":1310721}],"n":".ctor","o":"$ctor$4","d":2803394,"h":12887705282,"f":1}],"h":2803394}; }
            static get $b() { return $.$ssa.System.Security.AccessControl.GenericSecurityDescriptor; }
            static get $fullName() { return `System.Security.AccessControl.RawSecurityDescriptor`; }
        });
        
        $asm.$cls("$ssa.System.Security.AccessControl.AuthorizationRuleCollection", ($self) => class AuthorizationRuleCollection extends $.$scn.System.Collections.ReadOnlyCollectionBase
        {
            $ctor$2()
            {
                super.$ctor$1();
                {
                }
                return this;
            }
            /*System.Security.AccessControl.AuthorizationRule?*/ get_Item(/*int*/ index)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*void */ AddRule(/*System.Security.AccessControl.AuthorizationRule?*/ rule)
            {
            }
            /*void */ CopyTo(/*System.Security.AccessControl.AuthorizationRule[]*/ rules, /*int*/ index)
            {
            }
            static $h = 1033922;
            static $f = 0b10010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":589859,"p":[{"p":968386,"i":[{"n":"index","p":655361}],"g":{"r":0,"d":0,"h":12885935810,"f":1},"n":"Item","o":"@$2","d":1033922,"h":8590968514,"f":1}],"m":[{"r":65537,"p":[{"n":"rule","p":968386}],"n":"AddRule","d":1033922,"h":17180903106,"f":1},{"r":65537,"p":[{"n":"rules","p":0},{"n":"index","p":655361}],"n":"CopyTo","d":1033922,"h":21475870402,"f":1}],"c":[{"n":".ctor","o":"$ctor$2","d":1033922,"h":4296001218,"f":1}],"i":[31326209,31588353],"h":1033922}; }
            static get $b() { return $.$scn.System.Collections.ReadOnlyCollectionBase; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.Collections.ICollection, $.$spc.System.Collections.IEnumerable ]; }
            static get $fullName() { return `System.Security.AccessControl.AuthorizationRuleCollection`; }
        });
        
        $asm.$cls("$ssa.System.Security.AccessControl.RawAcl", ($self) => class RawAcl extends $.$ssa.System.Security.AccessControl.GenericAcl
        {
            $ctor$2(/*byte*/ revision, /*int*/ capacity)
            {
                super.$ctor$1();
                {
                }
                return this;
            }
            $ctor$3(/*byte[]*/ binaryForm, /*int*/ offset)
            {
                super.$ctor$1();
                {
                }
                return this;
            }
            /*int */ get BinaryLength()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ get Count()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Security.AccessControl.GenericAce*/ get_Item(/*int*/ index)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*void*/ set_Item(/*int*/ index, /*System.Security.AccessControl.GenericAce*/ value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*byte */ get Revision()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*void */ GetBinaryForm(/*byte[]*/ binaryForm, /*int*/ offset)
            {
            }
            /*void */ InsertAce(/*int*/ index, /*System.Security.AccessControl.GenericAce*/ ace)
            {
            }
            /*void */ RemoveAce(/*int*/ index)
            {
            }
            static $h = 2737858;
            static $f = 0b10010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":1754818,"p":[{"p":655361,"g":{"r":0,"d":0,"h":17182607042,"f":32769},"n":"BinaryLength","d":2737858,"h":12887639746,"f":32769},{"p":655361,"g":{"r":0,"d":0,"h":25772541634,"f":32769},"n":"Count","d":2737858,"h":21477574338,"f":32769},{"p":1689282,"i":[{"n":"index","p":655361}],"g":{"r":0,"d":0,"h":34362476226,"f":32769},"s":{"r":0,"d":0,"h":38657443522,"f":32769},"n":"Item","o":"@$2","d":2737858,"h":30067508930,"f":32769},{"p":393217,"g":{"r":0,"d":0,"h":47247378114,"f":32769},"n":"Revision","d":2737858,"h":42952410818,"f":32769}],"m":[{"r":65537,"p":[{"n":"binaryForm","p":0},{"n":"offset","p":655361}],"n":"GetBinaryForm","d":2737858,"h":51542345410,"f":32769},{"r":65537,"p":[{"n":"index","p":655361},{"n":"ace","p":1689282}],"n":"InsertAce","d":2737858,"h":55837312706,"f":1},{"r":65537,"p":[{"n":"index","p":655361}],"n":"RemoveAce","d":2737858,"h":60132280002,"f":1}],"c":[{"p":[{"n":"revision","p":393217},{"n":"capacity","p":655361}],"n":".ctor","o":"$ctor$2","d":2737858,"h":4297705154,"f":1},{"p":[{"n":"binaryForm","p":0},{"n":"offset","p":655361}],"n":".ctor","o":"$ctor$3","d":2737858,"h":8592672450,"f":1}],"i":[31326209,31588353],"h":2737858}; }
            static get $b() { return $.$ssa.System.Security.AccessControl.GenericAcl; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.Collections.ICollection, $.$spc.System.Collections.IEnumerable ]; }
            static get $fullName() { return `System.Security.AccessControl.RawAcl`; }
        });
        
        $asm.$cls("$ssa.System.Security.AccessControl.AccessRule<>", (T) => $asm.$gt("$ssa.System.Security.AccessControl.AccessRule<>", [T], ($self) => class AccessRule$$ extends $.$ssa.System.Security.AccessControl.AccessRule
        {
            $ctor$3(/*System.Security.Principal.IdentityReference*/ identity, /*T*/ rights, /*System.Security.AccessControl.AccessControlType*/ type)
            {
                super.$ctor$2(null, 0, false, 0, 0, 0);
                {
                }
                return this;
            }
            $ctor$4(/*System.Security.Principal.IdentityReference*/ identity, /*T*/ rights, /*System.Security.AccessControl.InheritanceFlags*/ inheritanceFlags, /*System.Security.AccessControl.PropagationFlags*/ propagationFlags, /*System.Security.AccessControl.AccessControlType*/ type)
            {
                super.$ctor$2(null, 0, false, 0, 0, 0);
                {
                }
                return this;
            }
            $ctor$5(/*string*/ identity, /*T*/ rights, /*System.Security.AccessControl.AccessControlType*/ type)
            {
                super.$ctor$2(null, 0, false, 0, 0, 0);
                {
                }
                return this;
            }
            $ctor$6(/*string*/ identity, /*T*/ rights, /*System.Security.AccessControl.InheritanceFlags*/ inheritanceFlags, /*System.Security.AccessControl.PropagationFlags*/ propagationFlags, /*System.Security.AccessControl.AccessControlType*/ type)
            {
                super.$ctor$2(null, 0, false, 0, 0, 0);
                {
                }
                return this;
            }
            /*T */ get Rights()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static $h = 444098;
            static $g = 1;
            static $f = 0b1010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":378562,"p":[{"p":T?.$h??1507328,"g":{"r":0,"d":0,"h":Number(BigInt(this.$h)|0x600000000n),"f":1},"n":"Rights","d":this.$h,"h":Number(BigInt(this.$h)|0x500000000n),"f":1}],"c":[{"p":[{"n":"identity","p":240041},{"n":"rights","p":T?.$h??1507328},{"n":"type","p":313026}],"n":".ctor","o":"$ctor$3","d":this.$h,"h":Number(BigInt(this.$h)|0x100000000n),"f":1},{"p":[{"n":"identity","p":240041},{"n":"rights","p":T?.$h??1507328},{"n":"inheritanceFlags","p":1885890},{"n":"propagationFlags","p":2606786},{"n":"type","p":313026}],"n":".ctor","o":"$ctor$4","d":this.$h,"h":Number(BigInt(this.$h)|0x200000000n),"f":1},{"p":[{"n":"identity","p":1310721},{"n":"rights","p":T?.$h??1507328},{"n":"type","p":313026}],"n":".ctor","o":"$ctor$5","d":this.$h,"h":Number(BigInt(this.$h)|0x300000000n),"f":1},{"p":[{"n":"identity","p":1310721},{"n":"rights","p":T?.$h??1507328},{"n":"inheritanceFlags","p":1885890},{"n":"propagationFlags","p":2606786},{"n":"type","p":313026}],"n":".ctor","o":"$ctor$6","d":this.$h,"h":Number(BigInt(this.$h)|0x400000000n),"f":1}],"g":[T?.$h??1507328],"s":[{"n":"T","f":2}],"r":1,"h":this.$h}; }
            static get $b() { return $.$ssa.System.Security.AccessControl.AccessRule; }
            static get $fullName() { return `System.Security.AccessControl.AccessRule<${T?.$fullName}>`; }
        }));
        
        $asm.$cls("$ssa.System.Security.AccessControl.AuditRule<>", (T) => $asm.$gt("$ssa.System.Security.AccessControl.AuditRule<>", [T], ($self) => class AuditRule$$ extends $.$ssa.System.Security.AccessControl.AuditRule
        {
            $ctor$3(/*System.Security.Principal.IdentityReference*/ identity, /*T*/ rights, /*System.Security.AccessControl.AuditFlags*/ flags)
            {
                super.$ctor$2(null, 0, false, 0, 0, 0);
                {
                }
                return this;
            }
            $ctor$4(/*System.Security.Principal.IdentityReference*/ identity, /*T*/ rights, /*System.Security.AccessControl.InheritanceFlags*/ inheritanceFlags, /*System.Security.AccessControl.PropagationFlags*/ propagationFlags, /*System.Security.AccessControl.AuditFlags*/ flags)
            {
                super.$ctor$2(null, 0, false, 0, 0, 0);
                {
                }
                return this;
            }
            $ctor$5(/*string*/ identity, /*T*/ rights, /*System.Security.AccessControl.AuditFlags*/ flags)
            {
                super.$ctor$2(null, 0, false, 0, 0, 0);
                {
                }
                return this;
            }
            $ctor$6(/*string*/ identity, /*T*/ rights, /*System.Security.AccessControl.InheritanceFlags*/ inheritanceFlags, /*System.Security.AccessControl.PropagationFlags*/ propagationFlags, /*System.Security.AccessControl.AuditFlags*/ flags)
            {
                super.$ctor$2(null, 0, false, 0, 0, 0);
                {
                }
                return this;
            }
            /*T */ get Rights()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static $h = 902850;
            static $g = 1;
            static $f = 0b1010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":837314,"p":[{"p":T?.$h??1507328,"g":{"r":0,"d":0,"h":Number(BigInt(this.$h)|0x600000000n),"f":1},"n":"Rights","d":this.$h,"h":Number(BigInt(this.$h)|0x500000000n),"f":1}],"c":[{"p":[{"n":"identity","p":240041},{"n":"rights","p":T?.$h??1507328},{"n":"flags","p":771778}],"n":".ctor","o":"$ctor$3","d":this.$h,"h":Number(BigInt(this.$h)|0x100000000n),"f":1},{"p":[{"n":"identity","p":240041},{"n":"rights","p":T?.$h??1507328},{"n":"inheritanceFlags","p":1885890},{"n":"propagationFlags","p":2606786},{"n":"flags","p":771778}],"n":".ctor","o":"$ctor$4","d":this.$h,"h":Number(BigInt(this.$h)|0x200000000n),"f":1},{"p":[{"n":"identity","p":1310721},{"n":"rights","p":T?.$h??1507328},{"n":"flags","p":771778}],"n":".ctor","o":"$ctor$5","d":this.$h,"h":Number(BigInt(this.$h)|0x300000000n),"f":1},{"p":[{"n":"identity","p":1310721},{"n":"rights","p":T?.$h??1507328},{"n":"inheritanceFlags","p":1885890},{"n":"propagationFlags","p":2606786},{"n":"flags","p":771778}],"n":".ctor","o":"$ctor$6","d":this.$h,"h":Number(BigInt(this.$h)|0x400000000n),"f":1}],"g":[T?.$h??1507328],"s":[{"n":"T","f":2}],"r":1,"h":this.$h}; }
            static get $b() { return $.$ssa.System.Security.AccessControl.AuditRule; }
            static get $fullName() { return `System.Security.AccessControl.AuditRule<${T?.$fullName}>`; }
        }));
        
        $asm.$cls("$ssa.System.Security.AccessControl.CompoundAce", ($self) => class CompoundAce extends $.$ssa.System.Security.AccessControl.KnownAce
        {
            $ctor$3(/*System.Security.AccessControl.AceFlags*/ flags, /*int*/ accessMask, /*System.Security.AccessControl.CompoundAceType*/ compoundAceType, /*System.Security.Principal.SecurityIdentifier*/ sid)
            {
                super.$ctor$2();
                {
                }
                return this;
            }
            /*int */ get BinaryLength()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Security.AccessControl.CompoundAceType */ get CompoundAceType()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Security.AccessControl.CompoundAceType */ set CompoundAceType(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*void */ GetBinaryForm(/*byte[]*/ binaryForm, /*int*/ offset)
            {
            }
            static $h = 1361602;
            static $f = 0b10010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":1951426,"p":[{"p":655361,"g":{"r":0,"d":0,"h":12886263490,"f":32769},"n":"BinaryLength","d":1361602,"h":8591296194,"f":32769},{"p":1427138,"g":{"r":0,"d":0,"h":21476198082,"f":1},"s":{"r":0,"d":0,"h":25771165378,"f":1},"n":"CompoundAceType","d":1361602,"h":17181230786,"f":1}],"m":[{"r":65537,"p":[{"n":"binaryForm","p":0},{"n":"offset","p":655361}],"n":"GetBinaryForm","d":1361602,"h":30066132674,"f":32769}],"c":[{"p":[{"n":"flags","p":575170},{"n":"accessMask","p":655361},{"n":"compoundAceType","p":1427138},{"n":"sid","p":436649}],"n":".ctor","o":"$ctor$3","d":1361602,"h":4296328898,"f":1}],"h":1361602}; }
            static get $b() { return $.$ssa.System.Security.AccessControl.KnownAce; }
            static get $fullName() { return `System.Security.AccessControl.CompoundAce`; }
        });
        
        $asm.$cls("$ssa.System.Security.AccessControl.DiscretionaryAcl", ($self) => class DiscretionaryAcl extends $.$ssa.System.Security.AccessControl.CommonAcl
        {
            $ctor$3(/*bool*/ isContainer, /*bool*/ isDS, /*byte*/ revision, /*int*/ capacity)
            {
                super.$ctor$2();
                {
                }
                return this;
            }
            $ctor$4(/*bool*/ isContainer, /*bool*/ isDS, /*int*/ capacity)
            {
                super.$ctor$2();
                {
                }
                return this;
            }
            $ctor$5(/*bool*/ isContainer, /*bool*/ isDS, /*System.Security.AccessControl.RawAcl?*/ rawAcl)
            {
                super.$ctor$2();
                {
                }
                return this;
            }
            /*void */ AddAccess(/*System.Security.AccessControl.AccessControlType*/ accessType, /*System.Security.Principal.SecurityIdentifier*/ sid, /*int*/ accessMask, /*System.Security.AccessControl.InheritanceFlags*/ inheritanceFlags, /*System.Security.AccessControl.PropagationFlags*/ propagationFlags)
            {
            }
            /*void */ AddAccess$1(/*System.Security.AccessControl.AccessControlType*/ accessType, /*System.Security.Principal.SecurityIdentifier*/ sid, /*int*/ accessMask, /*System.Security.AccessControl.InheritanceFlags*/ inheritanceFlags, /*System.Security.AccessControl.PropagationFlags*/ propagationFlags, /*System.Security.AccessControl.ObjectAceFlags*/ objectFlags, /*System.Guid*/ objectType, /*System.Guid*/ inheritedObjectType)
            {
            }
            /*void */ AddAccess$2(/*System.Security.AccessControl.AccessControlType*/ accessType, /*System.Security.Principal.SecurityIdentifier*/ sid, /*System.Security.AccessControl.ObjectAccessRule*/ rule)
            {
            }
            /*bool */ RemoveAccess(/*System.Security.AccessControl.AccessControlType*/ accessType, /*System.Security.Principal.SecurityIdentifier*/ sid, /*int*/ accessMask, /*System.Security.AccessControl.InheritanceFlags*/ inheritanceFlags, /*System.Security.AccessControl.PropagationFlags*/ propagationFlags)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ RemoveAccess$1(/*System.Security.AccessControl.AccessControlType*/ accessType, /*System.Security.Principal.SecurityIdentifier*/ sid, /*int*/ accessMask, /*System.Security.AccessControl.InheritanceFlags*/ inheritanceFlags, /*System.Security.AccessControl.PropagationFlags*/ propagationFlags, /*System.Security.AccessControl.ObjectAceFlags*/ objectFlags, /*System.Guid*/ objectType, /*System.Guid*/ inheritedObjectType)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ RemoveAccess$2(/*System.Security.AccessControl.AccessControlType*/ accessType, /*System.Security.Principal.SecurityIdentifier*/ sid, /*System.Security.AccessControl.ObjectAccessRule*/ rule)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*void */ RemoveAccessSpecific(/*System.Security.AccessControl.AccessControlType*/ accessType, /*System.Security.Principal.SecurityIdentifier*/ sid, /*int*/ accessMask, /*System.Security.AccessControl.InheritanceFlags*/ inheritanceFlags, /*System.Security.AccessControl.PropagationFlags*/ propagationFlags)
            {
            }
            /*void */ RemoveAccessSpecific$1(/*System.Security.AccessControl.AccessControlType*/ accessType, /*System.Security.Principal.SecurityIdentifier*/ sid, /*int*/ accessMask, /*System.Security.AccessControl.InheritanceFlags*/ inheritanceFlags, /*System.Security.AccessControl.PropagationFlags*/ propagationFlags, /*System.Security.AccessControl.ObjectAceFlags*/ objectFlags, /*System.Guid*/ objectType, /*System.Guid*/ inheritedObjectType)
            {
            }
            /*void */ RemoveAccessSpecific$2(/*System.Security.AccessControl.AccessControlType*/ accessType, /*System.Security.Principal.SecurityIdentifier*/ sid, /*System.Security.AccessControl.ObjectAccessRule*/ rule)
            {
            }
            /*void */ SetAccess(/*System.Security.AccessControl.AccessControlType*/ accessType, /*System.Security.Principal.SecurityIdentifier*/ sid, /*int*/ accessMask, /*System.Security.AccessControl.InheritanceFlags*/ inheritanceFlags, /*System.Security.AccessControl.PropagationFlags*/ propagationFlags)
            {
            }
            /*void */ SetAccess$1(/*System.Security.AccessControl.AccessControlType*/ accessType, /*System.Security.Principal.SecurityIdentifier*/ sid, /*int*/ accessMask, /*System.Security.AccessControl.InheritanceFlags*/ inheritanceFlags, /*System.Security.AccessControl.PropagationFlags*/ propagationFlags, /*System.Security.AccessControl.ObjectAceFlags*/ objectFlags, /*System.Guid*/ objectType, /*System.Guid*/ inheritedObjectType)
            {
            }
            /*void */ SetAccess$2(/*System.Security.AccessControl.AccessControlType*/ accessType, /*System.Security.Principal.SecurityIdentifier*/ sid, /*System.Security.AccessControl.ObjectAccessRule*/ rule)
            {
            }
            static $h = 1623746;
            static $f = 0b10010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":1164994,"m":[{"r":65537,"p":[{"n":"accessType","p":313026},{"n":"sid","p":436649},{"n":"accessMask","p":655361},{"n":"inheritanceFlags","p":1885890},{"n":"propagationFlags","p":2606786}],"n":"AddAccess","d":1623746,"h":17181492930,"f":1},{"r":65537,"p":[{"n":"accessType","p":313026},{"n":"sid","p":436649},{"n":"accessMask","p":655361},{"n":"inheritanceFlags","p":1885890},{"n":"propagationFlags","p":2606786},{"n":"objectFlags","p":2279106},{"n":"objectType","p":56164353},{"n":"inheritedObjectType","p":56164353}],"n":"AddAccess","o":"@$1","d":1623746,"h":21476460226,"f":1},{"r":65537,"p":[{"n":"accessType","p":313026},{"n":"sid","p":436649},{"n":"rule","p":2148034}],"n":"AddAccess","o":"@$2","d":1623746,"h":25771427522,"f":1},{"r":262145,"p":[{"n":"accessType","p":313026},{"n":"sid","p":436649},{"n":"accessMask","p":655361},{"n":"inheritanceFlags","p":1885890},{"n":"propagationFlags","p":2606786}],"n":"RemoveAccess","d":1623746,"h":30066394818,"f":1},{"r":262145,"p":[{"n":"accessType","p":313026},{"n":"sid","p":436649},{"n":"accessMask","p":655361},{"n":"inheritanceFlags","p":1885890},{"n":"propagationFlags","p":2606786},{"n":"objectFlags","p":2279106},{"n":"objectType","p":56164353},{"n":"inheritedObjectType","p":56164353}],"n":"RemoveAccess","o":"@$1","d":1623746,"h":34361362114,"f":1},{"r":262145,"p":[{"n":"accessType","p":313026},{"n":"sid","p":436649},{"n":"rule","p":2148034}],"n":"RemoveAccess","o":"@$2","d":1623746,"h":38656329410,"f":1},{"r":65537,"p":[{"n":"accessType","p":313026},{"n":"sid","p":436649},{"n":"accessMask","p":655361},{"n":"inheritanceFlags","p":1885890},{"n":"propagationFlags","p":2606786}],"n":"RemoveAccessSpecific","d":1623746,"h":42951296706,"f":1},{"r":65537,"p":[{"n":"accessType","p":313026},{"n":"sid","p":436649},{"n":"accessMask","p":655361},{"n":"inheritanceFlags","p":1885890},{"n":"propagationFlags","p":2606786},{"n":"objectFlags","p":2279106},{"n":"objectType","p":56164353},{"n":"inheritedObjectType","p":56164353}],"n":"RemoveAccessSpecific","o":"@$1","d":1623746,"h":47246264002,"f":1},{"r":65537,"p":[{"n":"accessType","p":313026},{"n":"sid","p":436649},{"n":"rule","p":2148034}],"n":"RemoveAccessSpecific","o":"@$2","d":1623746,"h":51541231298,"f":1},{"r":65537,"p":[{"n":"accessType","p":313026},{"n":"sid","p":436649},{"n":"accessMask","p":655361},{"n":"inheritanceFlags","p":1885890},{"n":"propagationFlags","p":2606786}],"n":"SetAccess","d":1623746,"h":55836198594,"f":1},{"r":65537,"p":[{"n":"accessType","p":313026},{"n":"sid","p":436649},{"n":"accessMask","p":655361},{"n":"inheritanceFlags","p":1885890},{"n":"propagationFlags","p":2606786},{"n":"objectFlags","p":2279106},{"n":"objectType","p":56164353},{"n":"inheritedObjectType","p":56164353}],"n":"SetAccess","o":"@$1","d":1623746,"h":60131165890,"f":1},{"r":65537,"p":[{"n":"accessType","p":313026},{"n":"sid","p":436649},{"n":"rule","p":2148034}],"n":"SetAccess","o":"@$2","d":1623746,"h":64426133186,"f":1}],"c":[{"p":[{"n":"isContainer","p":262145},{"n":"isDS","p":262145},{"n":"revision","p":393217},{"n":"capacity","p":655361}],"n":".ctor","o":"$ctor$3","d":1623746,"h":4296591042,"f":1},{"p":[{"n":"isContainer","p":262145},{"n":"isDS","p":262145},{"n":"capacity","p":655361}],"n":".ctor","o":"$ctor$4","d":1623746,"h":8591558338,"f":1},{"p":[{"n":"isContainer","p":262145},{"n":"isDS","p":262145},{"n":"rawAcl","p":2737858}],"n":".ctor","o":"$ctor$5","d":1623746,"h":12886525634,"f":1}],"i":[31326209,31588353],"h":1623746}; }
            static get $b() { return $.$ssa.System.Security.AccessControl.CommonAcl; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.Collections.ICollection, $.$spc.System.Collections.IEnumerable ]; }
            static get $fullName() { return `System.Security.AccessControl.DiscretionaryAcl`; }
        });
        
        $asm.$cls("$ssa.System.Security.AccessControl.SystemAcl", ($self) => class SystemAcl extends $.$ssa.System.Security.AccessControl.CommonAcl
        {
            $ctor$3(/*bool*/ isContainer, /*bool*/ isDS, /*byte*/ revision, /*int*/ capacity)
            {
                super.$ctor$2();
                {
                }
                return this;
            }
            $ctor$4(/*bool*/ isContainer, /*bool*/ isDS, /*int*/ capacity)
            {
                super.$ctor$2();
                {
                }
                return this;
            }
            $ctor$5(/*bool*/ isContainer, /*bool*/ isDS, /*System.Security.AccessControl.RawAcl*/ rawAcl)
            {
                super.$ctor$2();
                {
                }
                return this;
            }
            /*void */ AddAudit(/*System.Security.AccessControl.AuditFlags*/ auditFlags, /*System.Security.Principal.SecurityIdentifier*/ sid, /*int*/ accessMask, /*System.Security.AccessControl.InheritanceFlags*/ inheritanceFlags, /*System.Security.AccessControl.PropagationFlags*/ propagationFlags)
            {
            }
            /*void */ AddAudit$1(/*System.Security.AccessControl.AuditFlags*/ auditFlags, /*System.Security.Principal.SecurityIdentifier*/ sid, /*int*/ accessMask, /*System.Security.AccessControl.InheritanceFlags*/ inheritanceFlags, /*System.Security.AccessControl.PropagationFlags*/ propagationFlags, /*System.Security.AccessControl.ObjectAceFlags*/ objectFlags, /*System.Guid*/ objectType, /*System.Guid*/ inheritedObjectType)
            {
            }
            /*void */ AddAudit$2(/*System.Security.Principal.SecurityIdentifier*/ sid, /*System.Security.AccessControl.ObjectAuditRule*/ rule)
            {
            }
            /*bool */ RemoveAudit(/*System.Security.AccessControl.AuditFlags*/ auditFlags, /*System.Security.Principal.SecurityIdentifier*/ sid, /*int*/ accessMask, /*System.Security.AccessControl.InheritanceFlags*/ inheritanceFlags, /*System.Security.AccessControl.PropagationFlags*/ propagationFlags)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ RemoveAudit$1(/*System.Security.AccessControl.AuditFlags*/ auditFlags, /*System.Security.Principal.SecurityIdentifier*/ sid, /*int*/ accessMask, /*System.Security.AccessControl.InheritanceFlags*/ inheritanceFlags, /*System.Security.AccessControl.PropagationFlags*/ propagationFlags, /*System.Security.AccessControl.ObjectAceFlags*/ objectFlags, /*System.Guid*/ objectType, /*System.Guid*/ inheritedObjectType)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ RemoveAudit$2(/*System.Security.Principal.SecurityIdentifier*/ sid, /*System.Security.AccessControl.ObjectAuditRule*/ rule)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*void */ RemoveAuditSpecific(/*System.Security.AccessControl.AuditFlags*/ auditFlags, /*System.Security.Principal.SecurityIdentifier*/ sid, /*int*/ accessMask, /*System.Security.AccessControl.InheritanceFlags*/ inheritanceFlags, /*System.Security.AccessControl.PropagationFlags*/ propagationFlags)
            {
            }
            /*void */ RemoveAuditSpecific$1(/*System.Security.AccessControl.AuditFlags*/ auditFlags, /*System.Security.Principal.SecurityIdentifier*/ sid, /*int*/ accessMask, /*System.Security.AccessControl.InheritanceFlags*/ inheritanceFlags, /*System.Security.AccessControl.PropagationFlags*/ propagationFlags, /*System.Security.AccessControl.ObjectAceFlags*/ objectFlags, /*System.Guid*/ objectType, /*System.Guid*/ inheritedObjectType)
            {
            }
            /*void */ RemoveAuditSpecific$2(/*System.Security.Principal.SecurityIdentifier*/ sid, /*System.Security.AccessControl.ObjectAuditRule*/ rule)
            {
            }
            /*void */ SetAudit(/*System.Security.AccessControl.AuditFlags*/ auditFlags, /*System.Security.Principal.SecurityIdentifier*/ sid, /*int*/ accessMask, /*System.Security.AccessControl.InheritanceFlags*/ inheritanceFlags, /*System.Security.AccessControl.PropagationFlags*/ propagationFlags)
            {
            }
            /*void */ SetAudit$1(/*System.Security.AccessControl.AuditFlags*/ auditFlags, /*System.Security.Principal.SecurityIdentifier*/ sid, /*int*/ accessMask, /*System.Security.AccessControl.InheritanceFlags*/ inheritanceFlags, /*System.Security.AccessControl.PropagationFlags*/ propagationFlags, /*System.Security.AccessControl.ObjectAceFlags*/ objectFlags, /*System.Guid*/ objectType, /*System.Guid*/ inheritedObjectType)
            {
            }
            /*void */ SetAudit$2(/*System.Security.Principal.SecurityIdentifier*/ sid, /*System.Security.AccessControl.ObjectAuditRule*/ rule)
            {
            }
            static $h = 3000002;
            static $f = 0b10010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":1164994,"m":[{"r":65537,"p":[{"n":"auditFlags","p":771778},{"n":"sid","p":436649},{"n":"accessMask","p":655361},{"n":"inheritanceFlags","p":1885890},{"n":"propagationFlags","p":2606786}],"n":"AddAudit","d":3000002,"h":17182869186,"f":1},{"r":65537,"p":[{"n":"auditFlags","p":771778},{"n":"sid","p":436649},{"n":"accessMask","p":655361},{"n":"inheritanceFlags","p":1885890},{"n":"propagationFlags","p":2606786},{"n":"objectFlags","p":2279106},{"n":"objectType","p":56164353},{"n":"inheritedObjectType","p":56164353}],"n":"AddAudit","o":"@$1","d":3000002,"h":21477836482,"f":1},{"r":65537,"p":[{"n":"sid","p":436649},{"n":"rule","p":2344642}],"n":"AddAudit","o":"@$2","d":3000002,"h":25772803778,"f":1},{"r":262145,"p":[{"n":"auditFlags","p":771778},{"n":"sid","p":436649},{"n":"accessMask","p":655361},{"n":"inheritanceFlags","p":1885890},{"n":"propagationFlags","p":2606786}],"n":"RemoveAudit","d":3000002,"h":30067771074,"f":1},{"r":262145,"p":[{"n":"auditFlags","p":771778},{"n":"sid","p":436649},{"n":"accessMask","p":655361},{"n":"inheritanceFlags","p":1885890},{"n":"propagationFlags","p":2606786},{"n":"objectFlags","p":2279106},{"n":"objectType","p":56164353},{"n":"inheritedObjectType","p":56164353}],"n":"RemoveAudit","o":"@$1","d":3000002,"h":34362738370,"f":1},{"r":262145,"p":[{"n":"sid","p":436649},{"n":"rule","p":2344642}],"n":"RemoveAudit","o":"@$2","d":3000002,"h":38657705666,"f":1},{"r":65537,"p":[{"n":"auditFlags","p":771778},{"n":"sid","p":436649},{"n":"accessMask","p":655361},{"n":"inheritanceFlags","p":1885890},{"n":"propagationFlags","p":2606786}],"n":"RemoveAuditSpecific","d":3000002,"h":42952672962,"f":1},{"r":65537,"p":[{"n":"auditFlags","p":771778},{"n":"sid","p":436649},{"n":"accessMask","p":655361},{"n":"inheritanceFlags","p":1885890},{"n":"propagationFlags","p":2606786},{"n":"objectFlags","p":2279106},{"n":"objectType","p":56164353},{"n":"inheritedObjectType","p":56164353}],"n":"RemoveAuditSpecific","o":"@$1","d":3000002,"h":47247640258,"f":1},{"r":65537,"p":[{"n":"sid","p":436649},{"n":"rule","p":2344642}],"n":"RemoveAuditSpecific","o":"@$2","d":3000002,"h":51542607554,"f":1},{"r":65537,"p":[{"n":"auditFlags","p":771778},{"n":"sid","p":436649},{"n":"accessMask","p":655361},{"n":"inheritanceFlags","p":1885890},{"n":"propagationFlags","p":2606786}],"n":"SetAudit","d":3000002,"h":55837574850,"f":1},{"r":65537,"p":[{"n":"auditFlags","p":771778},{"n":"sid","p":436649},{"n":"accessMask","p":655361},{"n":"inheritanceFlags","p":1885890},{"n":"propagationFlags","p":2606786},{"n":"objectFlags","p":2279106},{"n":"objectType","p":56164353},{"n":"inheritedObjectType","p":56164353}],"n":"SetAudit","o":"@$1","d":3000002,"h":60132542146,"f":1},{"r":65537,"p":[{"n":"sid","p":436649},{"n":"rule","p":2344642}],"n":"SetAudit","o":"@$2","d":3000002,"h":64427509442,"f":1}],"c":[{"p":[{"n":"isContainer","p":262145},{"n":"isDS","p":262145},{"n":"revision","p":393217},{"n":"capacity","p":655361}],"n":".ctor","o":"$ctor$3","d":3000002,"h":4297967298,"f":1},{"p":[{"n":"isContainer","p":262145},{"n":"isDS","p":262145},{"n":"capacity","p":655361}],"n":".ctor","o":"$ctor$4","d":3000002,"h":8592934594,"f":1},{"p":[{"n":"isContainer","p":262145},{"n":"isDS","p":262145},{"n":"rawAcl","p":2737858}],"n":".ctor","o":"$ctor$5","d":3000002,"h":12887901890,"f":1}],"i":[31326209,31588353],"h":3000002}; }
            static get $b() { return $.$ssa.System.Security.AccessControl.CommonAcl; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.Collections.ICollection, $.$spc.System.Collections.IEnumerable ]; }
            static get $fullName() { return `System.Security.AccessControl.SystemAcl`; }
        });
        
        $asm.$str("$ssa.System.Security.AccessControl.AccessControlActions", ($self) => class AccessControlActions extends $.$spc.System.Enum
        {
            static None = 0;
            static View = 1;
            static Change = 2;
            static $map;
            static get Map()
            {
                return this.$map ??= 
                {
                    "None": 0n,
                    "View": 1n,
                    "Change": 2n
                };
            }
            static $h = 116418;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static get $eut() { return $.$spc.System.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {"b":1048577,"u":655361,"l":[{"t":116418,"n":"None","d":116418,"h":4295083714,"f":33},{"t":116418,"n":"View","d":116418,"h":8590051010,"f":33},{"t":116418,"n":"Change","d":116418,"h":12885018306,"f":33}],"c":[{"n":".ctor","o":"$ctor$3","d":116418,"h":17179985602,"f":1}],"i":[57212929,63766529,57671681,57344001],"h":116418,"a":[{"t":47644673,"c":4342611969}]}; }
            static get $b() { return $.$spc.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IComparable, $.$spc.System.ISpanFormattable, $.$spc.System.IFormattable, $.$spc.System.IConvertible ]; }
            static get $fullName() { return `System.Security.AccessControl.AccessControlActions`; }
        });
        
        $asm.$str("$ssa.System.Security.AccessControl.AccessControlModification", ($self) => class AccessControlModification extends $.$spc.System.Enum
        {
            static Add = 0;
            static Set = 1;
            static Reset = 2;
            static Remove = 3;
            static RemoveAll = 4;
            static RemoveSpecific = 5;
            static $map;
            static get Map()
            {
                return this.$map ??= 
                {
                    "Add": 0n,
                    "Set": 1n,
                    "Reset": 2n,
                    "Remove": 3n,
                    "RemoveAll": 4n,
                    "RemoveSpecific": 5n
                };
            }
            static $h = 181954;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static get $eut() { return $.$spc.System.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {"b":1048577,"u":655361,"l":[{"t":181954,"n":"Add","d":181954,"h":4295149250,"f":33},{"t":181954,"n":"Set","d":181954,"h":8590116546,"f":33},{"t":181954,"n":"Reset","d":181954,"h":12885083842,"f":33},{"t":181954,"n":"Remove","d":181954,"h":17180051138,"f":33},{"t":181954,"n":"RemoveAll","d":181954,"h":21475018434,"f":33},{"t":181954,"n":"RemoveSpecific","d":181954,"h":25769985730,"f":33}],"c":[{"n":".ctor","o":"$ctor$3","d":181954,"h":30064953026,"f":1}],"i":[57212929,63766529,57671681,57344001],"h":181954}; }
            static get $b() { return $.$spc.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IComparable, $.$spc.System.ISpanFormattable, $.$spc.System.IFormattable, $.$spc.System.IConvertible ]; }
            static get $fullName() { return `System.Security.AccessControl.AccessControlModification`; }
        });
        
        $asm.$str("$ssa.System.Security.AccessControl.AccessControlSections", ($self) => class AccessControlSections extends $.$spc.System.Enum
        {
            static None = 0;
            static Audit = 1;
            static Access = 2;
            static Owner = 4;
            static Group = 8;
            static All = 15;
            static $map;
            static get Map()
            {
                return this.$map ??= 
                {
                    "None": 0n,
                    "Audit": 1n,
                    "Access": 2n,
                    "Owner": 4n,
                    "Group": 8n,
                    "All": 15n
                };
            }
            static $h = 247490;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static get $eut() { return $.$spc.System.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {"b":1048577,"u":655361,"l":[{"t":247490,"n":"None","d":247490,"h":4295214786,"f":33},{"t":247490,"n":"Audit","d":247490,"h":8590182082,"f":33},{"t":247490,"n":"Access","d":247490,"h":12885149378,"f":33},{"t":247490,"n":"Owner","d":247490,"h":17180116674,"f":33},{"t":247490,"n":"Group","d":247490,"h":21475083970,"f":33},{"t":247490,"n":"All","d":247490,"h":25770051266,"f":33}],"c":[{"n":".ctor","o":"$ctor$3","d":247490,"h":30065018562,"f":1}],"i":[57212929,63766529,57671681,57344001],"h":247490,"a":[{"t":47644673,"c":4342611969}]}; }
            static get $b() { return $.$spc.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IComparable, $.$spc.System.ISpanFormattable, $.$spc.System.IFormattable, $.$spc.System.IConvertible ]; }
            static get $fullName() { return `System.Security.AccessControl.AccessControlSections`; }
        });
        
        $asm.$str("$ssa.System.Security.AccessControl.AccessControlType", ($self) => class AccessControlType extends $.$spc.System.Enum
        {
            static Allow = 0;
            static Deny = 1;
            static $map;
            static get Map()
            {
                return this.$map ??= 
                {
                    "Allow": 0n,
                    "Deny": 1n
                };
            }
            static $h = 313026;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static get $eut() { return $.$spc.System.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {"b":1048577,"u":655361,"l":[{"t":313026,"n":"Allow","d":313026,"h":4295280322,"f":33},{"t":313026,"n":"Deny","d":313026,"h":8590247618,"f":33}],"c":[{"n":".ctor","o":"$ctor$3","d":313026,"h":12885214914,"f":1}],"i":[57212929,63766529,57671681,57344001],"h":313026}; }
            static get $b() { return $.$spc.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IComparable, $.$spc.System.ISpanFormattable, $.$spc.System.IFormattable, $.$spc.System.IConvertible ]; }
            static get $fullName() { return `System.Security.AccessControl.AccessControlType`; }
        });
        
        $asm.$str("$ssa.System.Security.AccessControl.AceFlags", ($self) => class AceFlags extends $.$spc.System.Enum
        {
            static None = 0;
            static ObjectInherit = 1;
            static ContainerInherit = 2;
            static NoPropagateInherit = 4;
            static InheritOnly = 8;
            static InheritanceFlags = 15;
            static Inherited = 16;
            static SuccessfulAccess = 64;
            static FailedAccess = 128;
            static AuditFlags = 192;
            static $map;
            static get Map()
            {
                return this.$map ??= 
                {
                    "None": 0n,
                    "ObjectInherit": 1n,
                    "ContainerInherit": 2n,
                    "NoPropagateInherit": 4n,
                    "InheritOnly": 8n,
                    "InheritanceFlags": 15n,
                    "Inherited": 16n,
                    "SuccessfulAccess": 64n,
                    "FailedAccess": 128n,
                    "AuditFlags": 192n
                };
            }
            static $h = 575170;
            static $z = 1;
            static $f = 0b100000011010001001;
            static $k = 4;
            static get $eut() { return $.$spc.System.Byte; }
            static $$md;
            static get $md() { return this.$$md ??= {"b":1048577,"u":393217,"l":[{"t":575170,"n":"None","d":575170,"h":4295542466,"f":33},{"t":575170,"n":"ObjectInherit","d":575170,"h":8590509762,"f":33},{"t":575170,"n":"ContainerInherit","d":575170,"h":12885477058,"f":33},{"t":575170,"n":"NoPropagateInherit","d":575170,"h":17180444354,"f":33},{"t":575170,"n":"InheritOnly","d":575170,"h":21475411650,"f":33},{"t":575170,"n":"InheritanceFlags","d":575170,"h":25770378946,"f":33},{"t":575170,"n":"Inherited","d":575170,"h":30065346242,"f":33},{"t":575170,"n":"SuccessfulAccess","d":575170,"h":34360313538,"f":33},{"t":575170,"n":"FailedAccess","d":575170,"h":38655280834,"f":33},{"t":575170,"n":"AuditFlags","d":575170,"h":42950248130,"f":33}],"c":[{"n":".ctor","o":"$ctor$3","d":575170,"h":47245215426,"f":1}],"i":[57212929,63766529,57671681,57344001],"h":575170,"a":[{"t":47644673,"c":4342611969}]}; }
            static get $b() { return $.$spc.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IComparable, $.$spc.System.ISpanFormattable, $.$spc.System.IFormattable, $.$spc.System.IConvertible ]; }
            static get $fullName() { return `System.Security.AccessControl.AceFlags`; }
        });
        
        $asm.$str("$ssa.System.Security.AccessControl.AceQualifier", ($self) => class AceQualifier extends $.$spc.System.Enum
        {
            static AccessAllowed = 0;
            static AccessDenied = 1;
            static SystemAudit = 2;
            static SystemAlarm = 3;
            static $map;
            static get Map()
            {
                return this.$map ??= 
                {
                    "AccessAllowed": 0n,
                    "AccessDenied": 1n,
                    "SystemAudit": 2n,
                    "SystemAlarm": 3n
                };
            }
            static $h = 640706;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static get $eut() { return $.$spc.System.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {"b":1048577,"u":655361,"l":[{"t":640706,"n":"AccessAllowed","d":640706,"h":4295608002,"f":33},{"t":640706,"n":"AccessDenied","d":640706,"h":8590575298,"f":33},{"t":640706,"n":"SystemAudit","d":640706,"h":12885542594,"f":33},{"t":640706,"n":"SystemAlarm","d":640706,"h":17180509890,"f":33}],"c":[{"n":".ctor","o":"$ctor$3","d":640706,"h":21475477186,"f":1}],"i":[57212929,63766529,57671681,57344001],"h":640706}; }
            static get $b() { return $.$spc.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IComparable, $.$spc.System.ISpanFormattable, $.$spc.System.IFormattable, $.$spc.System.IConvertible ]; }
            static get $fullName() { return `System.Security.AccessControl.AceQualifier`; }
        });
        
        $asm.$str("$ssa.System.Security.AccessControl.AceType", ($self) => class AceType extends $.$spc.System.Enum
        {
            static AccessAllowed = 0;
            static AccessDenied = 1;
            static SystemAudit = 2;
            static SystemAlarm = 3;
            static AccessAllowedCompound = 4;
            static AccessAllowedObject = 5;
            static AccessDeniedObject = 6;
            static SystemAuditObject = 7;
            static SystemAlarmObject = 8;
            static AccessAllowedCallback = 9;
            static AccessDeniedCallback = 10;
            static AccessAllowedCallbackObject = 11;
            static AccessDeniedCallbackObject = 12;
            static SystemAuditCallback = 13;
            static SystemAlarmCallback = 14;
            static SystemAuditCallbackObject = 15;
            static MaxDefinedAceType = 16;
            static SystemAlarmCallbackObject = 16;
            static $map;
            static get Map()
            {
                return this.$map ??= 
                {
                    "AccessAllowed": 0n,
                    "AccessDenied": 1n,
                    "SystemAudit": 2n,
                    "SystemAlarm": 3n,
                    "AccessAllowedCompound": 4n,
                    "AccessAllowedObject": 5n,
                    "AccessDeniedObject": 6n,
                    "SystemAuditObject": 7n,
                    "SystemAlarmObject": 8n,
                    "AccessAllowedCallback": 9n,
                    "AccessDeniedCallback": 10n,
                    "AccessAllowedCallbackObject": 11n,
                    "AccessDeniedCallbackObject": 12n,
                    "SystemAuditCallback": 13n,
                    "SystemAlarmCallback": 14n,
                    "SystemAuditCallbackObject": 15n,
                    "MaxDefinedAceType": 16n,
                    "SystemAlarmCallbackObject": 16n
                };
            }
            static $h = 706242;
            static $z = 1;
            static $f = 0b100000011010001001;
            static $k = 4;
            static get $eut() { return $.$spc.System.Byte; }
            static $$md;
            static get $md() { return this.$$md ??= {"b":1048577,"u":393217,"l":[{"t":706242,"n":"AccessAllowed","d":706242,"h":4295673538,"f":33},{"t":706242,"n":"AccessDenied","d":706242,"h":8590640834,"f":33},{"t":706242,"n":"SystemAudit","d":706242,"h":12885608130,"f":33},{"t":706242,"n":"SystemAlarm","d":706242,"h":17180575426,"f":33},{"t":706242,"n":"AccessAllowedCompound","d":706242,"h":21475542722,"f":33},{"t":706242,"n":"AccessAllowedObject","d":706242,"h":25770510018,"f":33},{"t":706242,"n":"AccessDeniedObject","d":706242,"h":30065477314,"f":33},{"t":706242,"n":"SystemAuditObject","d":706242,"h":34360444610,"f":33},{"t":706242,"n":"SystemAlarmObject","d":706242,"h":38655411906,"f":33},{"t":706242,"n":"AccessAllowedCallback","d":706242,"h":42950379202,"f":33},{"t":706242,"n":"AccessDeniedCallback","d":706242,"h":47245346498,"f":33},{"t":706242,"n":"AccessAllowedCallbackObject","d":706242,"h":51540313794,"f":33},{"t":706242,"n":"AccessDeniedCallbackObject","d":706242,"h":55835281090,"f":33},{"t":706242,"n":"SystemAuditCallback","d":706242,"h":60130248386,"f":33},{"t":706242,"n":"SystemAlarmCallback","d":706242,"h":64425215682,"f":33},{"t":706242,"n":"SystemAuditCallbackObject","d":706242,"h":68720182978,"f":33},{"t":706242,"n":"MaxDefinedAceType","d":706242,"h":73015150274,"f":33},{"t":706242,"n":"SystemAlarmCallbackObject","d":706242,"h":77310117570,"f":33}],"c":[{"n":".ctor","o":"$ctor$3","d":706242,"h":81605084866,"f":1}],"i":[57212929,63766529,57671681,57344001],"h":706242}; }
            static get $b() { return $.$spc.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IComparable, $.$spc.System.ISpanFormattable, $.$spc.System.IFormattable, $.$spc.System.IConvertible ]; }
            static get $fullName() { return `System.Security.AccessControl.AceType`; }
        });
        
        $asm.$str("$ssa.System.Security.AccessControl.AuditFlags", ($self) => class AuditFlags extends $.$spc.System.Enum
        {
            static None = 0;
            static Success = 1;
            static Failure = 2;
            static $map;
            static get Map()
            {
                return this.$map ??= 
                {
                    "None": 0n,
                    "Success": 1n,
                    "Failure": 2n
                };
            }
            static $h = 771778;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static get $eut() { return $.$spc.System.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {"b":1048577,"u":655361,"l":[{"t":771778,"n":"None","d":771778,"h":4295739074,"f":33},{"t":771778,"n":"Success","d":771778,"h":8590706370,"f":33},{"t":771778,"n":"Failure","d":771778,"h":12885673666,"f":33}],"c":[{"n":".ctor","o":"$ctor$3","d":771778,"h":17180640962,"f":1}],"i":[57212929,63766529,57671681,57344001],"h":771778,"a":[{"t":47644673,"c":4342611969}]}; }
            static get $b() { return $.$spc.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IComparable, $.$spc.System.ISpanFormattable, $.$spc.System.IFormattable, $.$spc.System.IConvertible ]; }
            static get $fullName() { return `System.Security.AccessControl.AuditFlags`; }
        });
        
        $asm.$str("$ssa.System.Security.AccessControl.CompoundAceType", ($self) => class CompoundAceType extends $.$spc.System.Enum
        {
            static Impersonation = 1;
            static $map;
            static get Map()
            {
                return this.$map ??= 
                {
                    "Impersonation": 1n
                };
            }
            static $h = 1427138;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static get $eut() { return $.$spc.System.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {"b":1048577,"u":655361,"l":[{"t":1427138,"n":"Impersonation","d":1427138,"h":4296394434,"f":33}],"c":[{"n":".ctor","o":"$ctor$3","d":1427138,"h":8591361730,"f":1}],"i":[57212929,63766529,57671681,57344001],"h":1427138}; }
            static get $b() { return $.$spc.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IComparable, $.$spc.System.ISpanFormattable, $.$spc.System.IFormattable, $.$spc.System.IConvertible ]; }
            static get $fullName() { return `System.Security.AccessControl.CompoundAceType`; }
        });
        
        $asm.$str("$ssa.System.Security.AccessControl.ControlFlags", ($self) => class ControlFlags extends $.$spc.System.Enum
        {
            static None = 0;
            static OwnerDefaulted = 1;
            static GroupDefaulted = 2;
            static DiscretionaryAclPresent = 4;
            static DiscretionaryAclDefaulted = 8;
            static SystemAclPresent = 16;
            static SystemAclDefaulted = 32;
            static DiscretionaryAclUntrusted = 64;
            static ServerSecurity = 128;
            static DiscretionaryAclAutoInheritRequired = 256;
            static SystemAclAutoInheritRequired = 512;
            static DiscretionaryAclAutoInherited = 1024;
            static SystemAclAutoInherited = 2048;
            static DiscretionaryAclProtected = 4096;
            static SystemAclProtected = 8192;
            static RMControlValid = 16384;
            static SelfRelative = 32768;
            static $map;
            static get Map()
            {
                return this.$map ??= 
                {
                    "None": 0n,
                    "OwnerDefaulted": 1n,
                    "GroupDefaulted": 2n,
                    "DiscretionaryAclPresent": 4n,
                    "DiscretionaryAclDefaulted": 8n,
                    "SystemAclPresent": 16n,
                    "SystemAclDefaulted": 32n,
                    "DiscretionaryAclUntrusted": 64n,
                    "ServerSecurity": 128n,
                    "DiscretionaryAclAutoInheritRequired": 256n,
                    "SystemAclAutoInheritRequired": 512n,
                    "DiscretionaryAclAutoInherited": 1024n,
                    "SystemAclAutoInherited": 2048n,
                    "DiscretionaryAclProtected": 4096n,
                    "SystemAclProtected": 8192n,
                    "RMControlValid": 16384n,
                    "SelfRelative": 32768n
                };
            }
            static $h = 1492674;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static get $eut() { return $.$spc.System.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {"b":1048577,"u":655361,"l":[{"t":1492674,"n":"None","d":1492674,"h":4296459970,"f":33},{"t":1492674,"n":"OwnerDefaulted","d":1492674,"h":8591427266,"f":33},{"t":1492674,"n":"GroupDefaulted","d":1492674,"h":12886394562,"f":33},{"t":1492674,"n":"DiscretionaryAclPresent","d":1492674,"h":17181361858,"f":33},{"t":1492674,"n":"DiscretionaryAclDefaulted","d":1492674,"h":21476329154,"f":33},{"t":1492674,"n":"SystemAclPresent","d":1492674,"h":25771296450,"f":33},{"t":1492674,"n":"SystemAclDefaulted","d":1492674,"h":30066263746,"f":33},{"t":1492674,"n":"DiscretionaryAclUntrusted","d":1492674,"h":34361231042,"f":33},{"t":1492674,"n":"ServerSecurity","d":1492674,"h":38656198338,"f":33},{"t":1492674,"n":"DiscretionaryAclAutoInheritRequired","d":1492674,"h":42951165634,"f":33},{"t":1492674,"n":"SystemAclAutoInheritRequired","d":1492674,"h":47246132930,"f":33},{"t":1492674,"n":"DiscretionaryAclAutoInherited","d":1492674,"h":51541100226,"f":33},{"t":1492674,"n":"SystemAclAutoInherited","d":1492674,"h":55836067522,"f":33},{"t":1492674,"n":"DiscretionaryAclProtected","d":1492674,"h":60131034818,"f":33},{"t":1492674,"n":"SystemAclProtected","d":1492674,"h":64426002114,"f":33},{"t":1492674,"n":"RMControlValid","d":1492674,"h":68720969410,"f":33},{"t":1492674,"n":"SelfRelative","d":1492674,"h":73015936706,"f":33}],"c":[{"n":".ctor","o":"$ctor$3","d":1492674,"h":77310904002,"f":1}],"i":[57212929,63766529,57671681,57344001],"h":1492674,"a":[{"t":47644673,"c":4342611969}]}; }
            static get $b() { return $.$spc.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IComparable, $.$spc.System.ISpanFormattable, $.$spc.System.IFormattable, $.$spc.System.IConvertible ]; }
            static get $fullName() { return `System.Security.AccessControl.ControlFlags`; }
        });
        
        $asm.$str("$ssa.System.Security.AccessControl.InheritanceFlags", ($self) => class InheritanceFlags extends $.$spc.System.Enum
        {
            static None = 0;
            static ContainerInherit = 1;
            static ObjectInherit = 2;
            static $map;
            static get Map()
            {
                return this.$map ??= 
                {
                    "None": 0n,
                    "ContainerInherit": 1n,
                    "ObjectInherit": 2n
                };
            }
            static $h = 1885890;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static get $eut() { return $.$spc.System.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {"b":1048577,"u":655361,"l":[{"t":1885890,"n":"None","d":1885890,"h":4296853186,"f":33},{"t":1885890,"n":"ContainerInherit","d":1885890,"h":8591820482,"f":33},{"t":1885890,"n":"ObjectInherit","d":1885890,"h":12886787778,"f":33}],"c":[{"n":".ctor","o":"$ctor$3","d":1885890,"h":17181755074,"f":1}],"i":[57212929,63766529,57671681,57344001],"h":1885890,"a":[{"t":47644673,"c":4342611969}]}; }
            static get $b() { return $.$spc.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IComparable, $.$spc.System.ISpanFormattable, $.$spc.System.IFormattable, $.$spc.System.IConvertible ]; }
            static get $fullName() { return `System.Security.AccessControl.InheritanceFlags`; }
        });
        
        $asm.$str("$ssa.System.Security.AccessControl.ObjectAceFlags", ($self) => class ObjectAceFlags extends $.$spc.System.Enum
        {
            static None = 0;
            static ObjectAceTypePresent = 1;
            static InheritedObjectAceTypePresent = 2;
            static $map;
            static get Map()
            {
                return this.$map ??= 
                {
                    "None": 0n,
                    "ObjectAceTypePresent": 1n,
                    "InheritedObjectAceTypePresent": 2n
                };
            }
            static $h = 2279106;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static get $eut() { return $.$spc.System.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {"b":1048577,"u":655361,"l":[{"t":2279106,"n":"None","d":2279106,"h":4297246402,"f":33},{"t":2279106,"n":"ObjectAceTypePresent","d":2279106,"h":8592213698,"f":33},{"t":2279106,"n":"InheritedObjectAceTypePresent","d":2279106,"h":12887180994,"f":33}],"c":[{"n":".ctor","o":"$ctor$3","d":2279106,"h":17182148290,"f":1}],"i":[57212929,63766529,57671681,57344001],"h":2279106,"a":[{"t":47644673,"c":4342611969}]}; }
            static get $b() { return $.$spc.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IComparable, $.$spc.System.ISpanFormattable, $.$spc.System.IFormattable, $.$spc.System.IConvertible ]; }
            static get $fullName() { return `System.Security.AccessControl.ObjectAceFlags`; }
        });
        
        $asm.$str("$ssa.System.Security.AccessControl.PropagationFlags", ($self) => class PropagationFlags extends $.$spc.System.Enum
        {
            static None = 0;
            static NoPropagateInherit = 1;
            static InheritOnly = 2;
            static $map;
            static get Map()
            {
                return this.$map ??= 
                {
                    "None": 0n,
                    "NoPropagateInherit": 1n,
                    "InheritOnly": 2n
                };
            }
            static $h = 2606786;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static get $eut() { return $.$spc.System.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {"b":1048577,"u":655361,"l":[{"t":2606786,"n":"None","d":2606786,"h":4297574082,"f":33},{"t":2606786,"n":"NoPropagateInherit","d":2606786,"h":8592541378,"f":33},{"t":2606786,"n":"InheritOnly","d":2606786,"h":12887508674,"f":33}],"c":[{"n":".ctor","o":"$ctor$3","d":2606786,"h":17182475970,"f":1}],"i":[57212929,63766529,57671681,57344001],"h":2606786,"a":[{"t":47644673,"c":4342611969}]}; }
            static get $b() { return $.$spc.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IComparable, $.$spc.System.ISpanFormattable, $.$spc.System.IFormattable, $.$spc.System.IConvertible ]; }
            static get $fullName() { return `System.Security.AccessControl.PropagationFlags`; }
        });
        
        $asm.$str("$ssa.System.Security.AccessControl.ResourceType", ($self) => class ResourceType extends $.$spc.System.Enum
        {
            static Unknown = 0;
            static FileObject = 1;
            static Service = 2;
            static Printer = 3;
            static RegistryKey = 4;
            static LMShare = 5;
            static KernelObject = 6;
            static WindowObject = 7;
            static DSObject = 8;
            static DSObjectAll = 9;
            static ProviderDefined = 10;
            static WmiGuidObject = 11;
            static RegistryWow6432Key = 12;
            static $map;
            static get Map()
            {
                return this.$map ??= 
                {
                    "Unknown": 0n,
                    "FileObject": 1n,
                    "Service": 2n,
                    "Printer": 3n,
                    "RegistryKey": 4n,
                    "LMShare": 5n,
                    "KernelObject": 6n,
                    "WindowObject": 7n,
                    "DSObject": 8n,
                    "DSObjectAll": 9n,
                    "ProviderDefined": 10n,
                    "WmiGuidObject": 11n,
                    "RegistryWow6432Key": 12n
                };
            }
            static $h = 2868930;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static get $eut() { return $.$spc.System.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {"b":1048577,"u":655361,"l":[{"t":2868930,"n":"Unknown","d":2868930,"h":4297836226,"f":33},{"t":2868930,"n":"FileObject","d":2868930,"h":8592803522,"f":33},{"t":2868930,"n":"Service","d":2868930,"h":12887770818,"f":33},{"t":2868930,"n":"Printer","d":2868930,"h":17182738114,"f":33},{"t":2868930,"n":"RegistryKey","d":2868930,"h":21477705410,"f":33},{"t":2868930,"n":"LMShare","d":2868930,"h":25772672706,"f":33},{"t":2868930,"n":"KernelObject","d":2868930,"h":30067640002,"f":33},{"t":2868930,"n":"WindowObject","d":2868930,"h":34362607298,"f":33},{"t":2868930,"n":"DSObject","d":2868930,"h":38657574594,"f":33},{"t":2868930,"n":"DSObjectAll","d":2868930,"h":42952541890,"f":33},{"t":2868930,"n":"ProviderDefined","d":2868930,"h":47247509186,"f":33},{"t":2868930,"n":"WmiGuidObject","d":2868930,"h":51542476482,"f":33},{"t":2868930,"n":"RegistryWow6432Key","d":2868930,"h":55837443778,"f":33}],"c":[{"n":".ctor","o":"$ctor$3","d":2868930,"h":60132411074,"f":1}],"i":[57212929,63766529,57671681,57344001],"h":2868930}; }
            static get $b() { return $.$spc.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IComparable, $.$spc.System.ISpanFormattable, $.$spc.System.IFormattable, $.$spc.System.IConvertible ]; }
            static get $fullName() { return `System.Security.AccessControl.ResourceType`; }
        });
        
        $asm.$str("$ssa.System.Security.AccessControl.SecurityInfos", ($self) => class SecurityInfos extends $.$spc.System.Enum
        {
            static Owner = 1;
            static Group = 2;
            static DiscretionaryAcl = 4;
            static SystemAcl = 8;
            static $map;
            static get Map()
            {
                return this.$map ??= 
                {
                    "Owner": 1n,
                    "Group": 2n,
                    "DiscretionaryAcl": 4n,
                    "SystemAcl": 8n
                };
            }
            static $h = 2934466;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static get $eut() { return $.$spc.System.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {"b":1048577,"u":655361,"l":[{"t":2934466,"n":"Owner","d":2934466,"h":4297901762,"f":33},{"t":2934466,"n":"Group","d":2934466,"h":8592869058,"f":33},{"t":2934466,"n":"DiscretionaryAcl","d":2934466,"h":12887836354,"f":33},{"t":2934466,"n":"SystemAcl","d":2934466,"h":17182803650,"f":33}],"c":[{"n":".ctor","o":"$ctor$3","d":2934466,"h":21477770946,"f":1}],"i":[57212929,63766529,57671681,57344001],"h":2934466,"a":[{"t":47644673,"c":4342611969}]}; }
            static get $b() { return $.$spc.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IComparable, $.$spc.System.ISpanFormattable, $.$spc.System.IFormattable, $.$spc.System.IConvertible ]; }
            static get $fullName() { return `System.Security.AccessControl.SecurityInfos`; }
        });
        
        $asm.$cls("$ssa.System.Security.AccessControl.CommonAce", ($self) => class CommonAce extends $.$ssa.System.Security.AccessControl.QualifiedAce
        {
            $ctor$4(/*System.Security.AccessControl.AceFlags*/ flags, /*System.Security.AccessControl.AceQualifier*/ qualifier, /*int*/ accessMask, /*System.Security.Principal.SecurityIdentifier*/ sid, /*bool*/ isCallback, /*byte[]?*/ opaque)
            {
                super.$ctor$3();
                {
                }
                return this;
            }
            /*int */ get BinaryLength()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*void */ GetBinaryForm(/*byte[]*/ binaryForm, /*int*/ offset)
            {
            }
            static /*int */ MaxOpaqueLength(/*bool*/ isCallback)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static $h = 1099458;
            static $f = 0b10010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":2672322,"p":[{"p":655361,"g":{"r":0,"d":0,"h":12886001346,"f":32769},"n":"BinaryLength","d":1099458,"h":8591034050,"f":32769}],"m":[{"r":65537,"p":[{"n":"binaryForm","p":0},{"n":"offset","p":655361}],"n":"GetBinaryForm","d":1099458,"h":17180968642,"f":32769},{"r":655361,"p":[{"n":"isCallback","p":262145}],"n":"MaxOpaqueLength","d":1099458,"h":21475935938,"f":33}],"c":[{"p":[{"n":"flags","p":575170},{"n":"qualifier","p":640706},{"n":"accessMask","p":655361},{"n":"sid","p":436649},{"n":"isCallback","p":262145},{"n":"opaque","p":0}],"n":".ctor","o":"$ctor$4","d":1099458,"h":4296066754,"f":1}],"h":1099458}; }
            static get $b() { return $.$ssa.System.Security.AccessControl.QualifiedAce; }
            static get $fullName() { return `System.Security.AccessControl.CommonAce`; }
        });
        
        $asm.$cls("$ssa.System.Security.AccessControl.ObjectAce", ($self) => class ObjectAce extends $.$ssa.System.Security.AccessControl.QualifiedAce
        {
            $ctor$4(/*System.Security.AccessControl.AceFlags*/ aceFlags, /*System.Security.AccessControl.AceQualifier*/ qualifier, /*int*/ accessMask, /*System.Security.Principal.SecurityIdentifier*/ sid, /*System.Security.AccessControl.ObjectAceFlags*/ flags, /*System.Guid*/ type, /*System.Guid*/ inheritedType, /*bool*/ isCallback, /*byte[]?*/ opaque)
            {
                super.$ctor$3();
                {
                }
                return this;
            }
            /*int */ get BinaryLength()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Guid */ get InheritedObjectAceType()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Guid */ set InheritedObjectAceType(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Security.AccessControl.ObjectAceFlags */ get ObjectAceFlags()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Security.AccessControl.ObjectAceFlags */ set ObjectAceFlags(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Guid */ get ObjectAceType()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Guid */ set ObjectAceType(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*void */ GetBinaryForm(/*byte[]*/ binaryForm, /*int*/ offset)
            {
            }
            static /*int */ MaxOpaqueLength(/*bool*/ isCallback)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static $h = 2213570;
            static $f = 0b10010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":2672322,"p":[{"p":655361,"g":{"r":0,"d":0,"h":12887115458,"f":32769},"n":"BinaryLength","d":2213570,"h":8592148162,"f":32769},{"p":56164353,"g":{"r":0,"d":0,"h":21477050050,"f":1},"s":{"r":0,"d":0,"h":25772017346,"f":1},"n":"InheritedObjectAceType","d":2213570,"h":17182082754,"f":1},{"p":2279106,"g":{"r":0,"d":0,"h":34361951938,"f":1},"s":{"r":0,"d":0,"h":38656919234,"f":1},"n":"ObjectAceFlags","d":2213570,"h":30066984642,"f":1},{"p":56164353,"g":{"r":0,"d":0,"h":47246853826,"f":1},"s":{"r":0,"d":0,"h":51541821122,"f":1},"n":"ObjectAceType","d":2213570,"h":42951886530,"f":1}],"m":[{"r":65537,"p":[{"n":"binaryForm","p":0},{"n":"offset","p":655361}],"n":"GetBinaryForm","d":2213570,"h":55836788418,"f":32769},{"r":655361,"p":[{"n":"isCallback","p":262145}],"n":"MaxOpaqueLength","d":2213570,"h":60131755714,"f":33}],"c":[{"p":[{"n":"aceFlags","p":575170},{"n":"qualifier","p":640706},{"n":"accessMask","p":655361},{"n":"sid","p":436649},{"n":"flags","p":2279106},{"n":"type","p":56164353},{"n":"inheritedType","p":56164353},{"n":"isCallback","p":262145},{"n":"opaque","p":0}],"n":".ctor","o":"$ctor$4","d":2213570,"h":4297180866,"f":1}],"h":2213570}; }
            static get $b() { return $.$ssa.System.Security.AccessControl.QualifiedAce; }
            static get $fullName() { return `System.Security.AccessControl.ObjectAce`; }
        });
        
        $asm.$cls("$ssa.System.Security.AccessControl.PrivilegeNotHeldException", ($self) => class PrivilegeNotHeldException extends $.$spc.System.UnauthorizedAccessException
        {
            $ctor$13()
            {
                super.$ctor$9();
                {
                }
                return this;
            }
            $ctor$14(/*string?*/ privilege)
            {
                super.$ctor$9();
                {
                }
                return this;
            }
            $ctor$15(/*string?*/ privilege, /*System.Exception?*/ inner)
            {
                super.$ctor$9();
                {
                }
                return this;
            }
            /*string? */ get PrivilegeName()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*void */ GetObjectData(/*System.Runtime.Serialization.SerializationInfo*/ info, /*System.Runtime.Serialization.StreamingContext*/ context)
            {
            }
            static $h = 2541250;
            static $f = 0b10010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":143851521,"h":2541250}; }
            static get $b() { return $.$spc.System.UnauthorizedAccessException; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.Runtime.Serialization.ISerializable ]; }
            static get $fullName() { return `System.Security.AccessControl.PrivilegeNotHeldException`; }
        });
	});
})(window, window.NetJs.$boot(), ...window.NetJs.$require("NetJs.System.Private.CoreLib", "NetJs.Microsoft.Win32.Primitives", "NetJs.System.Collections", "NetJs.System.Diagnostics.Tracing", "NetJs.System.Memory", "NetJs.System.Private.Uri", "NetJs.System.Threading", "NetJs.System.Threading.Thread", "NetJs.System.Runtime", "NetJs.System.Collections.Concurrent", "NetJs.System.Collections.NonGeneric", "NetJs.System.Security.Claims", "NetJs.System.Runtime.InteropServices", "NetJs.System.Security.Principal.Windows"))