
(function ($global, $, $spc, $mwp, $sc, $sdt, $sm, $spu, $st, $stt, $sr, $scc, $scn, $ssc, $sris, $sspw) {
    "use strict";
    let _;
    
    
    
	$.$asm(
    "NetJs.System.Security.AccessControl", 
    {"h":36935,"f":"System.Security.AccessControl","v":"1.0.35.0","a":[{"t":115146753,"c":13000048641,"a":[{"v":".NETCoreApp,Version=v10.0","t":1310721}],"n":[{"n":"FrameworkDisplayName","v":".NET 10.0","t":1310721}]},{"t":73596929,"c":4368564225,"a":[{"v":"SIT","t":1310721}]},{"t":73662465,"c":4368629761,"a":[{"v":"Debug","t":1310721}]},{"t":74121217,"c":4369088513,"a":[{"v":"1.0.35.0","t":1310721}]},{"t":74252289,"c":4369219585,"a":[{"v":"1.0.35\u002Bbeaaf5d41a0179d1ed930cf3efa03ea73d37a2ca","t":1310721}]},{"t":75104257,"c":4370071553,"a":[{"v":"NetJs.System.Security.AccessControl","t":1310721}]},{"t":75235329,"c":4370202625,"a":[{"v":"NetJs.System.Security.AccessControl","t":1310721}]},{"t":75366401,"c":4370333697,"a":[{"v":"1.0.35.0","t":1310721}]},{"t":115212289,"c":4410179585,"a":[{"v":"browser1.0","t":1310721}]},{"t":114950145,"c":4409917441,"a":[{"v":"browser1.0","t":1310721}]}],"m":[]},
    function($asm)
	{
        
        
        $asm.$cls("$ssa.System.Security.AccessControl.AuthorizationRule", ($self) => class AuthorizationRule extends $.$spc.System.Object
        {
            $ctor$1(/*System.Security.Principal.IdentityReference*/ identity, /*int*/ accessMask, /*bool*/ isInherited, /*System.Security.AccessControl.InheritanceFlags*/ inheritanceFlags, /*System.Security.AccessControl.PropagationFlags*/ propagationFlags)
            {
                super.$ctor();
                {
                }
                return this;
            }
            /*int */ get AccessMask()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Security.Principal.IdentityReference */ get IdentityReference()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Security.AccessControl.InheritanceFlags */ get InheritanceFlags()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get IsInherited()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Security.AccessControl.PropagationFlags */ get PropagationFlags()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static $h = 954439;
            static $f = 0b110001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":655361,"g":{"r":0,"d":0,"h":12885856327,"f":16},"n":"AccessMask","d":954439,"h":8590889031,"f":16},{"p":238468,"g":{"r":0,"d":0,"h":21475790919,"f":1},"n":"IdentityReference","d":954439,"h":17180823623,"f":1},{"p":1871943,"g":{"r":0,"d":0,"h":30065725511,"f":1},"n":"InheritanceFlags","d":954439,"h":25770758215,"f":1},{"p":262145,"g":{"r":0,"d":0,"h":38655660103,"f":1},"n":"IsInherited","d":954439,"h":34360692807,"f":1},{"p":2592839,"g":{"r":0,"d":0,"h":47245594695,"f":1},"n":"PropagationFlags","d":954439,"h":42950627399,"f":1}],"c":[{"p":[{"n":"identity","p":238468},{"n":"accessMask","p":655361},{"n":"isInherited","p":262145},{"n":"inheritanceFlags","p":1871943},{"n":"propagationFlags","p":2592839}],"n":".ctor","o":"$ctor$1","d":954439,"h":4295921735,"f":16}],"h":954439}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.Security.AccessControl.AuthorizationRule`; }
        });
        
        $asm.$cls("$ssa.System.Security.AccessControl.GenericAce", ($self) => class GenericAce extends $.$spc.System.Object
        {
            $ctor$1()
            {
                super.$ctor();
                {
                }
                return this;
            }
            /*System.Security.AccessControl.AceFlags */ get AceFlags()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Security.AccessControl.AceFlags */ set AceFlags(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Security.AccessControl.AceType */ get AceType()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Security.AccessControl.AuditFlags */ get AuditFlags()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Security.AccessControl.InheritanceFlags */ get InheritanceFlags()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get IsInherited()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Security.AccessControl.PropagationFlags */ get PropagationFlags()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Security.AccessControl.GenericAce */ Copy()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static /*System.Security.AccessControl.GenericAce */ CreateFromBinaryForm(/*byte[]*/ binaryForm, /*int*/ offset)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static/*conventional*/ /*bool */ Equals(/*object?*/ o)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            //Static convention instance redirect
            /*bool */ Equals() { return $.$ssa.System.Security.AccessControl.GenericAce.Equals.apply(this, arguments); }
            static/*conventional*/ /*int */ GetHashCode()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            //Static convention instance redirect
            /*int */ GetHashCode() { return $.$ssa.System.Security.AccessControl.GenericAce.GetHashCode.apply(this, arguments); }
            static /*bool */ op_Equality(/*System.Security.AccessControl.GenericAce?*/ left, /*System.Security.AccessControl.GenericAce?*/ right)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static /*bool */ op_Inequality(/*System.Security.AccessControl.GenericAce?*/ left, /*System.Security.AccessControl.GenericAce?*/ right)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static $h = 1675335;
            static $f = 0b110001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":561223,"g":{"r":0,"d":0,"h":12886577223,"f":1},"s":{"r":0,"d":0,"h":17181544519,"f":1},"n":"AceFlags","d":1675335,"h":8591609927,"f":1},{"p":692295,"g":{"r":0,"d":0,"h":25771479111,"f":1},"n":"AceType","d":1675335,"h":21476511815,"f":1},{"p":757831,"g":{"r":0,"d":0,"h":34361413703,"f":1},"n":"AuditFlags","d":1675335,"h":30066446407,"f":1},{"p":655361,"g":{"r":0,"d":0,"h":42951348295,"f":257},"n":"BinaryLength","d":1675335,"h":38656380999,"f":257},{"p":1871943,"g":{"r":0,"d":0,"h":51541282887,"f":1},"n":"InheritanceFlags","d":1675335,"h":47246315591,"f":1},{"p":262145,"g":{"r":0,"d":0,"h":60131217479,"f":1},"n":"IsInherited","d":1675335,"h":55836250183,"f":1},{"p":2592839,"g":{"r":0,"d":0,"h":68721152071,"f":1},"n":"PropagationFlags","d":1675335,"h":64426184775,"f":1}],"m":[{"r":1675335,"n":"Copy","d":1675335,"h":73016119367,"f":1},{"r":1675335,"p":[{"n":"binaryForm","p":0},{"n":"offset","p":655361}],"n":"CreateFromBinaryForm","d":1675335,"h":77311086663,"f":33},{"r":262145,"p":[{"n":"o","p":131073}],"n":"Equals","d":1675335,"h":81606053959,"f":98305},{"r":65537,"p":[{"n":"binaryForm","p":0},{"n":"offset","p":655361}],"n":"GetBinaryForm","d":1675335,"h":85901021255,"f":257},{"r":655361,"n":"GetHashCode","d":1675335,"h":90195988551,"f":98305}],"c":[{"n":".ctor","o":"$ctor$1","d":1675335,"h":4296642631,"f":8}],"h":1675335}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.Security.AccessControl.GenericAce`; }
        });
        
        $asm.$cls("$ssa.System.Security.AccessControl.GenericSecurityDescriptor", ($self) => class GenericSecurityDescriptor extends $.$spc.System.Object
        {
            $ctor$1()
            {
                super.$ctor();
                {
                }
                return this;
            }
            /*int */ get BinaryLength()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static /*byte */ get Revision()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*void */ GetBinaryForm(/*byte[]*/ binaryForm, /*int*/ offset)
            {
            }
            /*string */ GetSddlForm(/*System.Security.AccessControl.AccessControlSections*/ includeSections)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static /*bool */ IsSddlConversionSupported()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static $h = 1806407;
            static $f = 0b110001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":655361,"g":{"r":0,"d":0,"h":12886708295,"f":1},"n":"BinaryLength","d":1806407,"h":8591740999,"f":1},{"p":1478727,"g":{"r":0,"d":0,"h":21476642887,"f":257},"n":"ControlFlags","d":1806407,"h":17181675591,"f":257},{"p":435076,"g":{"r":0,"d":0,"h":30066577479,"f":257},"s":{"r":0,"d":0,"h":34361544775,"f":257},"n":"Group","d":1806407,"h":25771610183,"f":257},{"p":435076,"g":{"r":0,"d":0,"h":42951479367,"f":257},"s":{"r":0,"d":0,"h":47246446663,"f":257},"n":"Owner","d":1806407,"h":38656512071,"f":257},{"p":393217,"g":{"r":0,"d":0,"h":55836381255,"f":33},"n":"Revision","d":1806407,"h":51541413959,"f":33}],"m":[{"r":65537,"p":[{"n":"binaryForm","p":0},{"n":"offset","p":655361}],"n":"GetBinaryForm","d":1806407,"h":60131348551,"f":1},{"r":1310721,"p":[{"n":"includeSections","p":233543}],"n":"GetSddlForm","d":1806407,"h":64426315847,"f":1},{"r":262145,"n":"IsSddlConversionSupported","d":1806407,"h":68721283143,"f":33}],"c":[{"n":".ctor","o":"$ctor$1","d":1806407,"h":4296773703,"f":8}],"h":1806407}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.Security.AccessControl.GenericSecurityDescriptor`; }
        });
        
        $asm.$cls("$ssa.System.Security.AccessControl.ObjectSecurity", ($self) => class ObjectSecurity extends $.$spc.System.Object
        {
            $ctor$1()
            {
                super.$ctor();
                {
                }
                return this;
            }
            $ctor$2(/*bool*/ isContainer, /*bool*/ isDS)
            {
                super.$ctor();
                {
                }
                return this;
            }
            $ctor$3(/*System.Security.AccessControl.CommonSecurityDescriptor*/ securityDescriptor)
            {
                super.$ctor();
                {
                }
                return this;
            }
            /*bool */ get AccessRulesModified()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ set AccessRulesModified(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get AreAccessRulesCanonical()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get AreAccessRulesProtected()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get AreAuditRulesCanonical()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get AreAuditRulesProtected()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get AuditRulesModified()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ set AuditRulesModified(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get GroupModified()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ set GroupModified(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get IsContainer()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get IsDS()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get OwnerModified()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ set OwnerModified(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Security.AccessControl.CommonSecurityDescriptor */ get SecurityDescriptor()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Security.Principal.IdentityReference? */ GetGroup(/*System.Type*/ targetType)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Security.Principal.IdentityReference? */ GetOwner(/*System.Type*/ targetType)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*byte[] */ GetSecurityDescriptorBinaryForm()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*string */ GetSecurityDescriptorSddlForm(/*System.Security.AccessControl.AccessControlSections*/ includeSections)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static /*bool */ IsSddlConversionSupported()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ ModifyAccessRule(/*System.Security.AccessControl.AccessControlModification*/ modification, /*System.Security.AccessControl.AccessRule*/ rule, /*out bool*/ modified)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ ModifyAuditRule(/*System.Security.AccessControl.AccessControlModification*/ modification, /*System.Security.AccessControl.AuditRule*/ rule, /*out bool*/ modified)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*void */ Persist(/*bool*/ enableOwnershipPrivilege, /*string*/ name, /*System.Security.AccessControl.AccessControlSections*/ includeSections)
            {
            }
            /*void */ Persist$1(/*System.Runtime.InteropServices.SafeHandle*/ handle, /*System.Security.AccessControl.AccessControlSections*/ includeSections)
            {
            }
            /*void */ Persist$2(/*string*/ name, /*System.Security.AccessControl.AccessControlSections*/ includeSections)
            {
            }
            /*void */ PurgeAccessRules(/*System.Security.Principal.IdentityReference*/ identity)
            {
            }
            /*void */ PurgeAuditRules(/*System.Security.Principal.IdentityReference*/ identity)
            {
            }
            /*void */ ReadLock()
            {
            }
            /*void */ ReadUnlock()
            {
            }
            /*void */ SetAccessRuleProtection(/*bool*/ isProtected, /*bool*/ preserveInheritance)
            {
            }
            /*void */ SetAuditRuleProtection(/*bool*/ isProtected, /*bool*/ preserveInheritance)
            {
            }
            /*void */ SetGroup(/*System.Security.Principal.IdentityReference*/ identity)
            {
            }
            /*void */ SetOwner(/*System.Security.Principal.IdentityReference*/ identity)
            {
            }
            /*void */ SetSecurityDescriptorBinaryForm(/*byte[]*/ binaryForm)
            {
            }
            /*void */ SetSecurityDescriptorBinaryForm$1(/*byte[]*/ binaryForm, /*System.Security.AccessControl.AccessControlSections*/ includeSections)
            {
            }
            /*void */ SetSecurityDescriptorSddlForm(/*string*/ sddlForm)
            {
            }
            /*void */ SetSecurityDescriptorSddlForm$1(/*string*/ sddlForm, /*System.Security.AccessControl.AccessControlSections*/ includeSections)
            {
            }
            /*void */ WriteLock()
            {
            }
            /*void */ WriteUnlock()
            {
            }
            static $h = 2396231;
            static $f = 0b110001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":142606337,"g":{"r":0,"d":0,"h":21477232711,"f":257},"n":"AccessRightType","d":2396231,"h":17182265415,"f":257},{"p":262145,"g":{"r":0,"d":0,"h":30067167303,"f":4},"s":{"r":0,"d":0,"h":34362134599,"f":4},"n":"AccessRulesModified","d":2396231,"h":25772200007,"f":4},{"p":142606337,"g":{"r":0,"d":0,"h":42952069191,"f":257},"n":"AccessRuleType","d":2396231,"h":38657101895,"f":257},{"p":262145,"g":{"r":0,"d":0,"h":51542003783,"f":1},"n":"AreAccessRulesCanonical","d":2396231,"h":47247036487,"f":1},{"p":262145,"g":{"r":0,"d":0,"h":60131938375,"f":1},"n":"AreAccessRulesProtected","d":2396231,"h":55836971079,"f":1},{"p":262145,"g":{"r":0,"d":0,"h":68721872967,"f":1},"n":"AreAuditRulesCanonical","d":2396231,"h":64426905671,"f":1},{"p":262145,"g":{"r":0,"d":0,"h":77311807559,"f":1},"n":"AreAuditRulesProtected","d":2396231,"h":73016840263,"f":1},{"p":262145,"g":{"r":0,"d":0,"h":85901742151,"f":4},"s":{"r":0,"d":0,"h":90196709447,"f":4},"n":"AuditRulesModified","d":2396231,"h":81606774855,"f":4},{"p":142606337,"g":{"r":0,"d":0,"h":98786644039,"f":257},"n":"AuditRuleType","d":2396231,"h":94491676743,"f":257},{"p":262145,"g":{"r":0,"d":0,"h":107376578631,"f":4},"s":{"r":0,"d":0,"h":111671545927,"f":4},"n":"GroupModified","d":2396231,"h":103081611335,"f":4},{"p":262145,"g":{"r":0,"d":0,"h":120261480519,"f":4},"n":"IsContainer","d":2396231,"h":115966513223,"f":4},{"p":262145,"g":{"r":0,"d":0,"h":128851415111,"f":4},"n":"IsDS","d":2396231,"h":124556447815,"f":4},{"p":262145,"g":{"r":0,"d":0,"h":137441349703,"f":4},"s":{"r":0,"d":0,"h":141736316999,"f":4},"n":"OwnerModified","d":2396231,"h":133146382407,"f":4},{"p":1282119,"g":{"r":0,"d":0,"h":150326251591,"f":4},"n":"SecurityDescriptor","d":2396231,"h":146031284295,"f":4}],"m":[{"r":364615,"p":[{"n":"identityReference","p":238468},{"n":"accessMask","p":655361},{"n":"isInherited","p":262145},{"n":"inheritanceFlags","p":1871943},{"n":"propagationFlags","p":2592839},{"n":"type","p":299079}],"n":"AccessRuleFactory","d":2396231,"h":154621218887,"f":257},{"r":823367,"p":[{"n":"identityReference","p":238468},{"n":"accessMask","p":655361},{"n":"isInherited","p":262145},{"n":"inheritanceFlags","p":1871943},{"n":"propagationFlags","p":2592839},{"n":"flags","p":757831}],"n":"AuditRuleFactory","d":2396231,"h":158916186183,"f":257},{"r":238468,"p":[{"n":"targetType","p":142606337}],"n":"GetGroup","d":2396231,"h":163211153479,"f":1},{"r":238468,"p":[{"n":"targetType","p":142606337}],"n":"GetOwner","d":2396231,"h":167506120775,"f":1},{"r":0,"n":"GetSecurityDescriptorBinaryForm","d":2396231,"h":171801088071,"f":1},{"r":1310721,"p":[{"n":"includeSections","p":233543}],"n":"GetSecurityDescriptorSddlForm","d":2396231,"h":176096055367,"f":1},{"r":262145,"n":"IsSddlConversionSupported","d":2396231,"h":180391022663,"f":33},{"r":262145,"p":[{"n":"modification","p":168007},{"n":"rule","p":364615},{"n":"modified","p":262145,"f":2}],"n":"ModifyAccess","d":2396231,"h":184685989959,"f":260},{"r":262145,"p":[{"n":"modification","p":168007},{"n":"rule","p":364615},{"n":"modified","p":262145,"f":2}],"n":"ModifyAccessRule","d":2396231,"h":188980957255,"f":129},{"r":262145,"p":[{"n":"modification","p":168007},{"n":"rule","p":823367},{"n":"modified","p":262145,"f":2}],"n":"ModifyAudit","d":2396231,"h":193275924551,"f":260},{"r":262145,"p":[{"n":"modification","p":168007},{"n":"rule","p":823367},{"n":"modified","p":262145,"f":2}],"n":"ModifyAuditRule","d":2396231,"h":197570891847,"f":129},{"r":65537,"p":[{"n":"enableOwnershipPrivilege","p":262145},{"n":"name","p":1310721},{"n":"includeSections","p":233543}],"n":"Persist","d":2396231,"h":201865859143,"f":132},{"r":65537,"p":[{"n":"handle","p":109576193},{"n":"includeSections","p":233543}],"n":"Persist","o":"@$1","d":2396231,"h":206160826439,"f":132},{"r":65537,"p":[{"n":"name","p":1310721},{"n":"includeSections","p":233543}],"n":"Persist","o":"@$2","d":2396231,"h":210455793735,"f":132},{"r":65537,"p":[{"n":"identity","p":238468}],"n":"PurgeAccessRules","d":2396231,"h":214750761031,"f":129},{"r":65537,"p":[{"n":"identity","p":238468}],"n":"PurgeAuditRules","d":2396231,"h":219045728327,"f":129},{"r":65537,"n":"ReadLock","d":2396231,"h":223340695623,"f":4},{"r":65537,"n":"ReadUnlock","d":2396231,"h":227635662919,"f":4},{"r":65537,"p":[{"n":"isProtected","p":262145},{"n":"preserveInheritance","p":262145}],"n":"SetAccessRuleProtection","d":2396231,"h":231930630215,"f":1},{"r":65537,"p":[{"n":"isProtected","p":262145},{"n":"preserveInheritance","p":262145}],"n":"SetAuditRuleProtection","d":2396231,"h":236225597511,"f":1},{"r":65537,"p":[{"n":"identity","p":238468}],"n":"SetGroup","d":2396231,"h":240520564807,"f":1},{"r":65537,"p":[{"n":"identity","p":238468}],"n":"SetOwner","d":2396231,"h":244815532103,"f":1},{"r":65537,"p":[{"n":"binaryForm","p":0}],"n":"SetSecurityDescriptorBinaryForm","d":2396231,"h":249110499399,"f":1},{"r":65537,"p":[{"n":"binaryForm","p":0},{"n":"includeSections","p":233543}],"n":"SetSecurityDescriptorBinaryForm","o":"@$1","d":2396231,"h":253405466695,"f":1},{"r":65537,"p":[{"n":"sddlForm","p":1310721}],"n":"SetSecurityDescriptorSddlForm","d":2396231,"h":257700433991,"f":1},{"r":65537,"p":[{"n":"sddlForm","p":1310721},{"n":"includeSections","p":233543}],"n":"SetSecurityDescriptorSddlForm","o":"@$1","d":2396231,"h":261995401287,"f":1},{"r":65537,"n":"WriteLock","d":2396231,"h":266290368583,"f":4},{"r":65537,"n":"WriteUnlock","d":2396231,"h":270585335879,"f":4}],"c":[{"n":".ctor","o":"$ctor$1","d":2396231,"h":4297363527,"f":4},{"p":[{"n":"isContainer","p":262145},{"n":"isDS","p":262145}],"n":".ctor","o":"$ctor$2","d":2396231,"h":8592330823,"f":4},{"p":[{"n":"securityDescriptor","p":1282119}],"n":".ctor","o":"$ctor$3","d":2396231,"h":12887298119,"f":4}],"h":2396231}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.Security.AccessControl.ObjectSecurity`; }
        });
        
        $asm.$cls("$ssa.System.Security.Policy.EvidenceBase", ($self) => class EvidenceBase extends $.$spc.System.Object
        {
            $ctor$1()
            {
                super.$ctor();
                {
                }
                return this;
            }
            /*System.Security.Policy.EvidenceBase? */ Clone()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static $h = 3117127;
            static $f = 0b110001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"m":[{"r":3117127,"n":"Clone","d":3117127,"h":8593051719,"f":129}],"c":[{"n":".ctor","o":"$ctor$1","d":3117127,"h":4298084423,"f":4}],"h":3117127}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.Security.Policy.EvidenceBase`; }
        });
        
        $asm.$cls("$ssa.System.Security.AccessControl.GenericAcl", ($self) => class GenericAcl extends $.$spc.System.Object
        {
            /*byte*/ static AclRevision = 0;
            /*byte*/ static AclRevisionDS = 0;
            /*int*/ static MaxBinaryLength = 0;
            $ctor$1()
            {
                super.$ctor();
                {
                }
                return this;
            }
            /*bool */ get IsSynchronized()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*object */ get SyncRoot()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*void */ CopyTo(/*System.Security.AccessControl.GenericAce[]*/ array, /*int*/ index)
            {
            }
            /*System.Security.AccessControl.AceEnumerator */ GetEnumerator()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*void */ System$Collections$ICollection$CopyTo(/*System.Array*/ array, /*int*/ index)
            {
            }
            /*System.Collections.IEnumerator */ System$Collections$IEnumerable$GetEnumerator()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            //Generated interface implemetation for System.Collections.ICollection.Count.get
            get System$Collections$ICollection$Count()
            {
                return this.Count;
            }
            //Generated interface implemetation for System.Collections.ICollection.SyncRoot.get
            get System$Collections$ICollection$SyncRoot()
            {
                return this.SyncRoot;
            }
            //Generated interface implemetation for System.Collections.ICollection.IsSynchronized.get
            get System$Collections$ICollection$IsSynchronized()
            {
                return this.IsSynchronized;
            }
            static $h = 1740871;
            static $f = 0b110001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":655361,"g":{"r":0,"d":0,"h":25771544647,"f":257},"n":"BinaryLength","d":1740871,"h":21476577351,"f":257},{"p":655361,"g":{"r":0,"d":0,"h":34361479239,"f":257},"n":"Count","d":1740871,"h":30066511943,"f":257},{"p":262145,"g":{"r":0,"d":0,"h":42951413831,"f":1},"n":"IsSynchronized","d":1740871,"h":38656446535,"f":1},{"p":1675335,"i":[{"n":"index","p":655361}],"g":{"r":0,"d":0,"h":51541348423,"f":257},"s":{"r":0,"d":0,"h":55836315719,"f":257},"n":"Item","o":"@$2","d":1740871,"h":47246381127,"f":257},{"p":393217,"g":{"r":0,"d":0,"h":64426250311,"f":257},"n":"Revision","d":1740871,"h":60131283015,"f":257},{"p":131073,"g":{"r":0,"d":0,"h":73016184903,"f":129},"n":"SyncRoot","d":1740871,"h":68721217607,"f":129}],"m":[{"r":65537,"p":[{"n":"array","p":0},{"n":"index","p":655361}],"n":"CopyTo","d":1740871,"h":77311152199,"f":1},{"r":65537,"p":[{"n":"binaryForm","p":0},{"n":"offset","p":655361}],"n":"GetBinaryForm","d":1740871,"h":81606119495,"f":257},{"r":495687,"n":"GetEnumerator","d":1740871,"h":85901086791,"f":1}],"l":[{"t":393217,"n":"AclRevision","d":1740871,"h":4296708167,"f":33},{"t":393217,"n":"AclRevisionDS","d":1740871,"h":8591675463,"f":33},{"t":655361,"n":"MaxBinaryLength","d":1740871,"h":12886642759,"f":33}],"c":[{"n":".ctor","o":"$ctor$1","d":1740871,"h":17181610055,"f":4}],"i":[31326209,31588353],"h":1740871}; }
            static get $b() { return $.$spc.System.Object; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.Collections.ICollection, $.$spc.System.Collections.IEnumerable ]; }
            static get $fullName() { return `System.Security.AccessControl.GenericAcl`; }
        });
        
        $asm.$cls("$ssa.System.Security.AccessControl.AccessRule", ($self) => class AccessRule extends $.$ssa.System.Security.AccessControl.AuthorizationRule
        {
            $ctor$2(/*System.Security.Principal.IdentityReference*/ identity, /*int*/ accessMask, /*bool*/ isInherited, /*System.Security.AccessControl.InheritanceFlags*/ inheritanceFlags, /*System.Security.AccessControl.PropagationFlags*/ propagationFlags, /*System.Security.AccessControl.AccessControlType*/ type)
            {
                super.$ctor$1(null, 0, false, 0, 0);
                {
                }
                return this;
            }
            /*System.Security.AccessControl.AccessControlType */ get AccessControlType()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static $h = 364615;
            static $f = 0b110001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":954439,"p":[{"p":299079,"g":{"r":0,"d":0,"h":12885266503,"f":1},"n":"AccessControlType","d":364615,"h":8590299207,"f":1}],"c":[{"p":[{"n":"identity","p":238468},{"n":"accessMask","p":655361},{"n":"isInherited","p":262145},{"n":"inheritanceFlags","p":1871943},{"n":"propagationFlags","p":2592839},{"n":"type","p":299079}],"n":".ctor","o":"$ctor$2","d":364615,"h":4295331911,"f":4}],"h":364615}; }
            static get $b() { return $.$ssa.System.Security.AccessControl.AuthorizationRule; }
            static get $fullName() { return `System.Security.AccessControl.AccessRule`; }
        });
        
        $asm.$cls("$ssa.System.Security.AccessControl.AuditRule", ($self) => class AuditRule extends $.$ssa.System.Security.AccessControl.AuthorizationRule
        {
            $ctor$2(/*System.Security.Principal.IdentityReference*/ identity, /*int*/ accessMask, /*bool*/ isInherited, /*System.Security.AccessControl.InheritanceFlags*/ inheritanceFlags, /*System.Security.AccessControl.PropagationFlags*/ propagationFlags, /*System.Security.AccessControl.AuditFlags*/ auditFlags)
            {
                super.$ctor$1(null, 0, false, 0, 0);
                {
                }
                return this;
            }
            /*System.Security.AccessControl.AuditFlags */ get AuditFlags()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static $h = 823367;
            static $f = 0b110001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":954439,"p":[{"p":757831,"g":{"r":0,"d":0,"h":12885725255,"f":1},"n":"AuditFlags","d":823367,"h":8590757959,"f":1}],"c":[{"p":[{"n":"identity","p":238468},{"n":"accessMask","p":655361},{"n":"isInherited","p":262145},{"n":"inheritanceFlags","p":1871943},{"n":"propagationFlags","p":2592839},{"n":"auditFlags","p":757831}],"n":".ctor","o":"$ctor$2","d":823367,"h":4295790663,"f":4}],"h":823367}; }
            static get $b() { return $.$ssa.System.Security.AccessControl.AuthorizationRule; }
            static get $fullName() { return `System.Security.AccessControl.AuditRule`; }
        });
        
        $asm.$cls("$ssa.System.Security.AccessControl.CommonObjectSecurity", ($self) => class CommonObjectSecurity extends $.$ssa.System.Security.AccessControl.ObjectSecurity
        {
            $ctor$4(/*bool*/ isContainer)
            {
                super.$ctor$1();
                {
                }
                return this;
            }
            /*void */ AddAccessRule(/*System.Security.AccessControl.AccessRule*/ rule)
            {
            }
            /*void */ AddAuditRule(/*System.Security.AccessControl.AuditRule*/ rule)
            {
            }
            /*System.Security.AccessControl.AuthorizationRuleCollection */ GetAccessRules(/*bool*/ includeExplicit, /*bool*/ includeInherited, /*System.Type*/ targetType)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Security.AccessControl.AuthorizationRuleCollection */ GetAuditRules(/*bool*/ includeExplicit, /*bool*/ includeInherited, /*System.Type*/ targetType)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ ModifyAccess(/*System.Security.AccessControl.AccessControlModification*/ modification, /*System.Security.AccessControl.AccessRule*/ rule, /*out bool*/ modified)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ ModifyAudit(/*System.Security.AccessControl.AccessControlModification*/ modification, /*System.Security.AccessControl.AuditRule*/ rule, /*out bool*/ modified)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ RemoveAccessRule(/*System.Security.AccessControl.AccessRule*/ rule)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*void */ RemoveAccessRuleAll(/*System.Security.AccessControl.AccessRule*/ rule)
            {
            }
            /*void */ RemoveAccessRuleSpecific(/*System.Security.AccessControl.AccessRule*/ rule)
            {
            }
            /*bool */ RemoveAuditRule(/*System.Security.AccessControl.AuditRule*/ rule)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*void */ RemoveAuditRuleAll(/*System.Security.AccessControl.AuditRule*/ rule)
            {
            }
            /*void */ RemoveAuditRuleSpecific(/*System.Security.AccessControl.AuditRule*/ rule)
            {
            }
            /*void */ ResetAccessRule(/*System.Security.AccessControl.AccessRule*/ rule)
            {
            }
            /*void */ SetAccessRule(/*System.Security.AccessControl.AccessRule*/ rule)
            {
            }
            /*void */ SetAuditRule(/*System.Security.AccessControl.AuditRule*/ rule)
            {
            }
            static $h = 1216583;
            static $f = 0b110001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":2396231,"m":[{"r":65537,"p":[{"n":"rule","p":364615}],"n":"AddAccessRule","d":1216583,"h":8591151175,"f":4},{"r":65537,"p":[{"n":"rule","p":823367}],"n":"AddAuditRule","d":1216583,"h":12886118471,"f":4},{"r":1019975,"p":[{"n":"includeExplicit","p":262145},{"n":"includeInherited","p":262145},{"n":"targetType","p":142606337}],"n":"GetAccessRules","d":1216583,"h":17181085767,"f":1},{"r":1019975,"p":[{"n":"includeExplicit","p":262145},{"n":"includeInherited","p":262145},{"n":"targetType","p":142606337}],"n":"GetAuditRules","d":1216583,"h":21476053063,"f":1},{"r":262145,"p":[{"n":"modification","p":168007},{"n":"rule","p":364615},{"n":"modified","p":262145,"f":2}],"n":"ModifyAccess","d":1216583,"h":25771020359,"f":32772},{"r":262145,"p":[{"n":"modification","p":168007},{"n":"rule","p":823367},{"n":"modified","p":262145,"f":2}],"n":"ModifyAudit","d":1216583,"h":30065987655,"f":32772},{"r":262145,"p":[{"n":"rule","p":364615}],"n":"RemoveAccessRule","d":1216583,"h":34360954951,"f":4},{"r":65537,"p":[{"n":"rule","p":364615}],"n":"RemoveAccessRuleAll","d":1216583,"h":38655922247,"f":4},{"r":65537,"p":[{"n":"rule","p":364615}],"n":"RemoveAccessRuleSpecific","d":1216583,"h":42950889543,"f":4},{"r":262145,"p":[{"n":"rule","p":823367}],"n":"RemoveAuditRule","d":1216583,"h":47245856839,"f":4},{"r":65537,"p":[{"n":"rule","p":823367}],"n":"RemoveAuditRuleAll","d":1216583,"h":51540824135,"f":4},{"r":65537,"p":[{"n":"rule","p":823367}],"n":"RemoveAuditRuleSpecific","d":1216583,"h":55835791431,"f":4},{"r":65537,"p":[{"n":"rule","p":364615}],"n":"ResetAccessRule","d":1216583,"h":60130758727,"f":4},{"r":65537,"p":[{"n":"rule","p":364615}],"n":"SetAccessRule","d":1216583,"h":64425726023,"f":4},{"r":65537,"p":[{"n":"rule","p":823367}],"n":"SetAuditRule","d":1216583,"h":68720693319,"f":4}],"c":[{"p":[{"n":"isContainer","p":262145}],"n":".ctor","o":"$ctor$4","d":1216583,"h":4296183879,"f":4}],"h":1216583}; }
            static get $b() { return $.$ssa.System.Security.AccessControl.ObjectSecurity; }
            static get $fullName() { return `System.Security.AccessControl.CommonObjectSecurity`; }
        });
        
        $asm.$cls("$ssa.System.Security.AccessControl.KnownAce", ($self) => class KnownAce extends $.$ssa.System.Security.AccessControl.GenericAce
        {
            $ctor$2()
            {
                super.$ctor$1();
                {
                }
                return this;
            }
            /*int */ get AccessMask()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ set AccessMask(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Security.Principal.SecurityIdentifier */ get SecurityIdentifier()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Security.Principal.SecurityIdentifier */ set SecurityIdentifier(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static $h = 1937479;
            static $f = 0b110001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":1675335,"p":[{"p":655361,"g":{"r":0,"d":0,"h":12886839367,"f":1},"s":{"r":0,"d":0,"h":17181806663,"f":1},"n":"AccessMask","d":1937479,"h":8591872071,"f":1},{"p":435076,"g":{"r":0,"d":0,"h":25771741255,"f":1},"s":{"r":0,"d":0,"h":30066708551,"f":1},"n":"SecurityIdentifier","d":1937479,"h":21476773959,"f":1}],"c":[{"n":".ctor","o":"$ctor$2","d":1937479,"h":4296904775,"f":8}],"h":1937479}; }
            static get $b() { return $.$ssa.System.Security.AccessControl.GenericAce; }
            static get $fullName() { return `System.Security.AccessControl.KnownAce`; }
        });
        
        $asm.$cls("$ssa.System.Security.AccessControl.CommonAcl", ($self) => class CommonAcl extends $.$ssa.System.Security.AccessControl.GenericAcl
        {
            $ctor$2()
            {
                super.$ctor$1();
                {
                }
                return this;
            }
            /*int */ get BinaryLength()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ get Count()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get IsCanonical()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get IsContainer()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get IsDS()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Security.AccessControl.GenericAce*/ get_Item(/*int*/ index)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*void*/ set_Item(/*int*/ index, /*System.Security.AccessControl.GenericAce*/ value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*byte */ get Revision()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*void */ GetBinaryForm(/*byte[]*/ binaryForm, /*int*/ offset)
            {
            }
            /*void */ Purge(/*System.Security.Principal.SecurityIdentifier*/ sid)
            {
            }
            /*void */ RemoveInheritedAces()
            {
            }
            static $h = 1151047;
            static $f = 0b110001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":1740871,"p":[{"p":655361,"g":{"r":0,"d":0,"h":12886052935,"f":98305},"n":"BinaryLength","d":1151047,"h":8591085639,"f":98305},{"p":655361,"g":{"r":0,"d":0,"h":21475987527,"f":98305},"n":"Count","d":1151047,"h":17181020231,"f":98305},{"p":262145,"g":{"r":0,"d":0,"h":30065922119,"f":1},"n":"IsCanonical","d":1151047,"h":25770954823,"f":1},{"p":262145,"g":{"r":0,"d":0,"h":38655856711,"f":1},"n":"IsContainer","d":1151047,"h":34360889415,"f":1},{"p":262145,"g":{"r":0,"d":0,"h":47245791303,"f":1},"n":"IsDS","d":1151047,"h":42950824007,"f":1},{"p":1675335,"i":[{"n":"index","p":655361}],"g":{"r":0,"d":0,"h":55835725895,"f":98305},"s":{"r":0,"d":0,"h":60130693191,"f":98305},"n":"Item","o":"@$2","d":1151047,"h":51540758599,"f":98305},{"p":393217,"g":{"r":0,"d":0,"h":68720627783,"f":98305},"n":"Revision","d":1151047,"h":64425660487,"f":98305}],"m":[{"r":65537,"p":[{"n":"binaryForm","p":0},{"n":"offset","p":655361}],"n":"GetBinaryForm","d":1151047,"h":73015595079,"f":98305},{"r":65537,"p":[{"n":"sid","p":435076}],"n":"Purge","d":1151047,"h":77310562375,"f":1},{"r":65537,"n":"RemoveInheritedAces","d":1151047,"h":81605529671,"f":1}],"c":[{"n":".ctor","o":"$ctor$2","d":1151047,"h":4296118343,"f":8}],"i":[31326209,31588353],"h":1151047}; }
            static get $b() { return $.$ssa.System.Security.AccessControl.GenericAcl; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.Collections.ICollection, $.$spc.System.Collections.IEnumerable ]; }
            static get $fullName() { return `System.Security.AccessControl.CommonAcl`; }
        });
        
        $asm.$cls("$ssa.System.Security.AccessControl.NativeObjectSecurity", ($self) => class NativeObjectSecurity extends $.$ssa.System.Security.AccessControl.CommonObjectSecurity
        {
            $ctor$5(/*bool*/ isContainer, /*System.Security.AccessControl.ResourceType*/ resourceType)
            {
                super.$ctor$4(false);
                {
                }
                return this;
            }
            $ctor$6(/*bool*/ isContainer, /*System.Security.AccessControl.ResourceType*/ resourceType, /*System.Runtime.InteropServices.SafeHandle?*/ handle, /*System.Security.AccessControl.AccessControlSections*/ includeSections)
            {
                super.$ctor$4(false);
                {
                }
                return this;
            }
            $ctor$7(/*bool*/ isContainer, /*System.Security.AccessControl.ResourceType*/ resourceType, /*System.Runtime.InteropServices.SafeHandle?*/ handle, /*System.Security.AccessControl.AccessControlSections*/ includeSections, /*System.Security.AccessControl.NativeObjectSecurity.ExceptionFromErrorCode?*/ exceptionFromErrorCode, /*object?*/ exceptionContext)
            {
                super.$ctor$4(false);
                {
                }
                return this;
            }
            $ctor$8(/*bool*/ isContainer, /*System.Security.AccessControl.ResourceType*/ resourceType, /*System.Security.AccessControl.NativeObjectSecurity.ExceptionFromErrorCode?*/ exceptionFromErrorCode, /*object?*/ exceptionContext)
            {
                super.$ctor$4(false);
                {
                }
                return this;
            }
            $ctor$9(/*bool*/ isContainer, /*System.Security.AccessControl.ResourceType*/ resourceType, /*string?*/ name, /*System.Security.AccessControl.AccessControlSections*/ includeSections)
            {
                super.$ctor$4(false);
                {
                }
                return this;
            }
            $ctor$10(/*bool*/ isContainer, /*System.Security.AccessControl.ResourceType*/ resourceType, /*string?*/ name, /*System.Security.AccessControl.AccessControlSections*/ includeSections, /*System.Security.AccessControl.NativeObjectSecurity.ExceptionFromErrorCode?*/ exceptionFromErrorCode, /*object?*/ exceptionContext)
            {
                super.$ctor$4(false);
                {
                }
                return this;
            }
            /*void */ Persist$1(/*System.Runtime.InteropServices.SafeHandle*/ handle, /*System.Security.AccessControl.AccessControlSections*/ includeSections)
            {
            }
            /*void */ Persist$3(/*System.Runtime.InteropServices.SafeHandle*/ handle, /*System.Security.AccessControl.AccessControlSections*/ includeSections, /*object?*/ exceptionContext)
            {
            }
            /*void */ Persist$2(/*string*/ name, /*System.Security.AccessControl.AccessControlSections*/ includeSections)
            {
            }
            /*void */ Persist$4(/*string*/ name, /*System.Security.AccessControl.AccessControlSections*/ includeSections, /*object?*/ exceptionContext)
            {
            }
            static $_ExceptionFromErrorCode;
            static get ExceptionFromErrorCode()
            {
                let $cls = $.$ssa.System.Security.AccessControl.NativeObjectSecurity;
                return $cls.$_ExceptionFromErrorCode ??= $asm.$ncls("$ssa.System.Security.AccessControl.NativeObjectSecurity.ExceptionFromErrorCode", ($self) => class ExceptionFromErrorCode extends $.$spc.System.MulticastDelegate
                {
                    $ctor(/*object*/ target, fn)
                    {
                        this._target = target;
                        this.$nativeFunction = fn;
                        return this;
                    }
                    /*System.Exception?*/ Invoke(/*$.$spc.System.Int32*/ $errorCode, /*$.$spc.System.Nullable$$*/ $name, /*$.$spc.System.Nullable$$*/ $handle, /*$.$spc.System.Nullable$$*/ $context)
                    {
                        return this.$nativeFunction.apply(this._target, arguments);
                    }
                    static $h = 2068551;
                    static $f = 0b10000000010000000;
                    static $k = 5;
                    static $$md;
                    static get $md() { return this.$$md ??= {"b":66191361,"m":[{"r":47185921,"p":[{"n":"errorCode","p":655361},{"n":"name","p":1310721},{"n":"handle","p":109576193},{"n":"context","p":131073}],"n":"Invoke","d":2068551,"h":8592003143,"f":129},{"r":56950785,"p":[{"n":"errorCode","p":655361},{"n":"name","p":1310721},{"n":"handle","p":109576193},{"n":"context","p":131073},{"n":"callback","p":14417921},{"n":"object","p":131073}],"n":"BeginInvoke","d":2068551,"h":12886970439,"f":129},{"r":47185921,"p":[{"n":"result","p":56950785}],"n":"EndInvoke","d":2068551,"h":17181937735,"f":129}],"c":[{"p":[{"n":"object","p":131073},{"n":"method","p":786433}],"n":".ctor","o":"$ctor$5","d":2068551,"h":4297035847,"f":1}],"i":[57147393,113377281],"d":2003015,"h":2068551}; }
                    static get $b() { return $.$spc.System.MulticastDelegate; }
                    static $$i;
                    static get $i() { return this.$$i ??= [ $.$spc.System.ICloneable, $.$spc.System.Runtime.Serialization.ISerializable ]; }
                    static get $fullName() { return `System.Security.AccessControl.NativeObjectSecurity.ExceptionFromErrorCode`; }
                }, $cls, ($v) => $cls.$_ExceptionFromErrorCode = $v);
            }
            static $h = 2003015;
            static $f = 0b110001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":1216583,"m":[{"r":65537,"p":[{"n":"handle","p":109576193},{"n":"includeSections","p":233543}],"n":"Persist","o":"@$1","d":2003015,"h":30066774087,"f":98308},{"r":65537,"p":[{"n":"handle","p":109576193},{"n":"includeSections","p":233543},{"n":"exceptionContext","p":131073}],"n":"Persist","o":"@$3","d":2003015,"h":34361741383,"f":4},{"r":65537,"p":[{"n":"name","p":1310721},{"n":"includeSections","p":233543}],"n":"Persist","o":"@$2","d":2003015,"h":38656708679,"f":98308},{"r":65537,"p":[{"n":"name","p":1310721},{"n":"includeSections","p":233543},{"n":"exceptionContext","p":131073}],"n":"Persist","o":"@$4","d":2003015,"h":42951675975,"f":4}],"c":[{"p":[{"n":"isContainer","p":262145},{"n":"resourceType","p":2854983}],"n":".ctor","o":"$ctor$5","d":2003015,"h":4296970311,"f":4},{"p":[{"n":"isContainer","p":262145},{"n":"resourceType","p":2854983},{"n":"handle","p":109576193},{"n":"includeSections","p":233543}],"n":".ctor","o":"$ctor$6","d":2003015,"h":8591937607,"f":4},{"p":[{"n":"isContainer","p":262145},{"n":"resourceType","p":2854983},{"n":"handle","p":109576193},{"n":"includeSections","p":233543},{"n":"exceptionFromErrorCode","p":2068551},{"n":"exceptionContext","p":131073}],"n":".ctor","o":"$ctor$7","d":2003015,"h":12886904903,"f":4},{"p":[{"n":"isContainer","p":262145},{"n":"resourceType","p":2854983},{"n":"exceptionFromErrorCode","p":2068551},{"n":"exceptionContext","p":131073}],"n":".ctor","o":"$ctor$8","d":2003015,"h":17181872199,"f":4},{"p":[{"n":"isContainer","p":262145},{"n":"resourceType","p":2854983},{"n":"name","p":1310721},{"n":"includeSections","p":233543}],"n":".ctor","o":"$ctor$9","d":2003015,"h":21476839495,"f":4},{"p":[{"n":"isContainer","p":262145},{"n":"resourceType","p":2854983},{"n":"name","p":1310721},{"n":"includeSections","p":233543},{"n":"exceptionFromErrorCode","p":2068551},{"n":"exceptionContext","p":131073}],"n":".ctor","o":"$ctor$10","d":2003015,"h":25771806791,"f":4}],"j":[2068551],"h":2003015}; }
            static get $b() { return $.$ssa.System.Security.AccessControl.CommonObjectSecurity; }
            static get $fullName() { return `System.Security.AccessControl.NativeObjectSecurity`; }
        });
        
        $asm.$cls("$ssa.System.Security.AccessControl.ObjectAccessRule", ($self) => class ObjectAccessRule extends $.$ssa.System.Security.AccessControl.AccessRule
        {
            $ctor$3(/*System.Security.Principal.IdentityReference*/ identity, /*int*/ accessMask, /*bool*/ isInherited, /*System.Security.AccessControl.InheritanceFlags*/ inheritanceFlags, /*System.Security.AccessControl.PropagationFlags*/ propagationFlags, /*System.Guid*/ objectType, /*System.Guid*/ inheritedObjectType, /*System.Security.AccessControl.AccessControlType*/ type)
            {
                super.$ctor$2(null, 0, false, 0, 0, 0);
                {
                }
                return this;
            }
            /*System.Guid */ get InheritedObjectType()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Security.AccessControl.ObjectAceFlags */ get ObjectFlags()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Guid */ get ObjectType()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static $h = 2134087;
            static $f = 0b110001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":364615,"p":[{"p":56164353,"g":{"r":0,"d":0,"h":12887035975,"f":1},"n":"InheritedObjectType","d":2134087,"h":8592068679,"f":1},{"p":2265159,"g":{"r":0,"d":0,"h":21476970567,"f":1},"n":"ObjectFlags","d":2134087,"h":17182003271,"f":1},{"p":56164353,"g":{"r":0,"d":0,"h":30066905159,"f":1},"n":"ObjectType","d":2134087,"h":25771937863,"f":1}],"c":[{"p":[{"n":"identity","p":238468},{"n":"accessMask","p":655361},{"n":"isInherited","p":262145},{"n":"inheritanceFlags","p":1871943},{"n":"propagationFlags","p":2592839},{"n":"objectType","p":56164353},{"n":"inheritedObjectType","p":56164353},{"n":"type","p":299079}],"n":".ctor","o":"$ctor$3","d":2134087,"h":4297101383,"f":4}],"h":2134087}; }
            static get $b() { return $.$ssa.System.Security.AccessControl.AccessRule; }
            static get $fullName() { return `System.Security.AccessControl.ObjectAccessRule`; }
        });
        
        $asm.$cls("$ssa.System.Security.AccessControl.ObjectAuditRule", ($self) => class ObjectAuditRule extends $.$ssa.System.Security.AccessControl.AuditRule
        {
            $ctor$3(/*System.Security.Principal.IdentityReference*/ identity, /*int*/ accessMask, /*bool*/ isInherited, /*System.Security.AccessControl.InheritanceFlags*/ inheritanceFlags, /*System.Security.AccessControl.PropagationFlags*/ propagationFlags, /*System.Guid*/ objectType, /*System.Guid*/ inheritedObjectType, /*System.Security.AccessControl.AuditFlags*/ auditFlags)
            {
                super.$ctor$2(null, 0, false, 0, 0, 0);
                {
                }
                return this;
            }
            /*System.Guid */ get InheritedObjectType()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Security.AccessControl.ObjectAceFlags */ get ObjectFlags()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Guid */ get ObjectType()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static $h = 2330695;
            static $f = 0b110001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":823367,"p":[{"p":56164353,"g":{"r":0,"d":0,"h":12887232583,"f":1},"n":"InheritedObjectType","d":2330695,"h":8592265287,"f":1},{"p":2265159,"g":{"r":0,"d":0,"h":21477167175,"f":1},"n":"ObjectFlags","d":2330695,"h":17182199879,"f":1},{"p":56164353,"g":{"r":0,"d":0,"h":30067101767,"f":1},"n":"ObjectType","d":2330695,"h":25772134471,"f":1}],"c":[{"p":[{"n":"identity","p":238468},{"n":"accessMask","p":655361},{"n":"isInherited","p":262145},{"n":"inheritanceFlags","p":1871943},{"n":"propagationFlags","p":2592839},{"n":"objectType","p":56164353},{"n":"inheritedObjectType","p":56164353},{"n":"auditFlags","p":757831}],"n":".ctor","o":"$ctor$3","d":2330695,"h":4297297991,"f":4}],"h":2330695}; }
            static get $b() { return $.$ssa.System.Security.AccessControl.AuditRule; }
            static get $fullName() { return `System.Security.AccessControl.ObjectAuditRule`; }
        });
        
        $asm.$cls("$ssa.System.Security.AccessControl.QualifiedAce", ($self) => class QualifiedAce extends $.$ssa.System.Security.AccessControl.KnownAce
        {
            $ctor$3()
            {
                super.$ctor$2();
                {
                }
                return this;
            }
            /*System.Security.AccessControl.AceQualifier */ get AceQualifier()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get IsCallback()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ get OpaqueLength()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*byte[]? */ GetOpaque()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*void */ SetOpaque(/*byte[]?*/ opaque)
            {
            }
            static $h = 2658375;
            static $f = 0b110001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":1937479,"p":[{"p":626759,"g":{"r":0,"d":0,"h":12887560263,"f":1},"n":"AceQualifier","d":2658375,"h":8592592967,"f":1},{"p":262145,"g":{"r":0,"d":0,"h":21477494855,"f":1},"n":"IsCallback","d":2658375,"h":17182527559,"f":1},{"p":655361,"g":{"r":0,"d":0,"h":30067429447,"f":1},"n":"OpaqueLength","d":2658375,"h":25772462151,"f":1}],"m":[{"r":0,"n":"GetOpaque","d":2658375,"h":34362396743,"f":1},{"r":65537,"p":[{"n":"opaque","p":0}],"n":"SetOpaque","d":2658375,"h":38657364039,"f":1}],"c":[{"n":".ctor","o":"$ctor$3","d":2658375,"h":4297625671,"f":8}],"h":2658375}; }
            static get $b() { return $.$ssa.System.Security.AccessControl.KnownAce; }
            static get $fullName() { return `System.Security.AccessControl.QualifiedAce`; }
        });
        
        $asm.$cls("$ssa.System.Security.AccessControl.ObjectSecurity<>", (T) => $asm.$gt("$ssa.System.Security.AccessControl.ObjectSecurity<>", [T], ($self) => class ObjectSecurity$$ extends $.$ssa.System.Security.AccessControl.NativeObjectSecurity
        {
            $ctor$11(/*bool*/ isContainer, /*System.Security.AccessControl.ResourceType*/ resourceType)
            {
                super.$ctor$5(false, 0);
                {
                }
                return this;
            }
            $ctor$12(/*bool*/ isContainer, /*System.Security.AccessControl.ResourceType*/ resourceType, /*System.Runtime.InteropServices.SafeHandle?*/ safeHandle, /*System.Security.AccessControl.AccessControlSections*/ includeSections)
            {
                super.$ctor$5(false, 0);
                {
                }
                return this;
            }
            $ctor$13(/*bool*/ isContainer, /*System.Security.AccessControl.ResourceType*/ resourceType, /*System.Runtime.InteropServices.SafeHandle?*/ safeHandle, /*System.Security.AccessControl.AccessControlSections*/ includeSections, /*System.Security.AccessControl.NativeObjectSecurity.ExceptionFromErrorCode?*/ exceptionFromErrorCode, /*object?*/ exceptionContext)
            {
                super.$ctor$5(false, 0);
                {
                }
                return this;
            }
            $ctor$14(/*bool*/ isContainer, /*System.Security.AccessControl.ResourceType*/ resourceType, /*string?*/ name, /*System.Security.AccessControl.AccessControlSections*/ includeSections)
            {
                super.$ctor$5(false, 0);
                {
                }
                return this;
            }
            $ctor$15(/*bool*/ isContainer, /*System.Security.AccessControl.ResourceType*/ resourceType, /*string?*/ name, /*System.Security.AccessControl.AccessControlSections*/ includeSections, /*System.Security.AccessControl.NativeObjectSecurity.ExceptionFromErrorCode?*/ exceptionFromErrorCode, /*object?*/ exceptionContext)
            {
                super.$ctor$5(false, 0);
                {
                }
                return this;
            }
            /*System.Type */ get AccessRightType()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Type */ get AccessRuleType()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Type */ get AuditRuleType()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Security.AccessControl.AccessRule */ AccessRuleFactory(/*System.Security.Principal.IdentityReference*/ identityReference, /*int*/ accessMask, /*bool*/ isInherited, /*System.Security.AccessControl.InheritanceFlags*/ inheritanceFlags, /*System.Security.AccessControl.PropagationFlags*/ propagationFlags, /*System.Security.AccessControl.AccessControlType*/ type)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*void */ AddAccessRule$1(/*System.Security.AccessControl.AccessRule<T>*/ rule)
            {
            }
            /*void */ AddAuditRule$1(/*System.Security.AccessControl.AuditRule<T>*/ rule)
            {
            }
            /*System.Security.AccessControl.AuditRule */ AuditRuleFactory(/*System.Security.Principal.IdentityReference*/ identityReference, /*int*/ accessMask, /*bool*/ isInherited, /*System.Security.AccessControl.InheritanceFlags*/ inheritanceFlags, /*System.Security.AccessControl.PropagationFlags*/ propagationFlags, /*System.Security.AccessControl.AuditFlags*/ flags)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*void */ Persist$5(/*System.Runtime.InteropServices.SafeHandle*/ handle)
            {
            }
            /*void */ Persist$6(/*string*/ name)
            {
            }
            /*bool */ RemoveAccessRule$1(/*System.Security.AccessControl.AccessRule<T>*/ rule)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*void */ RemoveAccessRuleAll$1(/*System.Security.AccessControl.AccessRule<T>*/ rule)
            {
            }
            /*void */ RemoveAccessRuleSpecific$1(/*System.Security.AccessControl.AccessRule<T>*/ rule)
            {
            }
            /*bool */ RemoveAuditRule$1(/*System.Security.AccessControl.AuditRule<T>*/ rule)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*void */ RemoveAuditRuleAll$1(/*System.Security.AccessControl.AuditRule<T>*/ rule)
            {
            }
            /*void */ RemoveAuditRuleSpecific$1(/*System.Security.AccessControl.AuditRule<T>*/ rule)
            {
            }
            /*void */ ResetAccessRule$1(/*System.Security.AccessControl.AccessRule<T>*/ rule)
            {
            }
            /*void */ SetAccessRule$1(/*System.Security.AccessControl.AccessRule<T>*/ rule)
            {
            }
            /*void */ SetAuditRule$1(/*System.Security.AccessControl.AuditRule<T>*/ rule)
            {
            }
            static $h = 2461767;
            static $g = 1;
            static $f = 0b1110001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":2003015,"p":[{"p":142606337,"g":{"r":0,"d":0,"h":Number(BigInt(this.$h)|0x700000000n),"f":32769},"n":"AccessRightType","d":this.$h,"h":Number(BigInt(this.$h)|0x600000000n),"f":32769},{"p":142606337,"g":{"r":0,"d":0,"h":Number(BigInt(this.$h)|0x900000000n),"f":32769},"n":"AccessRuleType","d":this.$h,"h":Number(BigInt(this.$h)|0x800000000n),"f":32769},{"p":142606337,"g":{"r":0,"d":0,"h":Number(BigInt(this.$h)|0xB00000000n),"f":32769},"n":"AuditRuleType","d":this.$h,"h":Number(BigInt(this.$h)|0xA00000000n),"f":32769}],"m":[{"r":364615,"p":[{"n":"identityReference","p":238468},{"n":"accessMask","p":655361},{"n":"isInherited","p":262145},{"n":"inheritanceFlags","p":1871943},{"n":"propagationFlags","p":2592839},{"n":"type","p":299079}],"n":"AccessRuleFactory","d":this.$h,"h":Number(BigInt(this.$h)|0xC00000000n),"f":32769},{"r":65537,"p":[{"n":"rule","p":$.$ssa.System.Security.AccessControl.AccessRule$$(T).$h}],"n":"AddAccessRule","o":"@$1","d":this.$h,"h":Number(BigInt(this.$h)|0xD00000000n),"f":129},{"r":65537,"p":[{"n":"rule","p":$.$ssa.System.Security.AccessControl.AuditRule$$(T).$h}],"n":"AddAuditRule","o":"@$1","d":this.$h,"h":Number(BigInt(this.$h)|0xE00000000n),"f":129},{"r":823367,"p":[{"n":"identityReference","p":238468},{"n":"accessMask","p":655361},{"n":"isInherited","p":262145},{"n":"inheritanceFlags","p":1871943},{"n":"propagationFlags","p":2592839},{"n":"flags","p":757831}],"n":"AuditRuleFactory","d":this.$h,"h":Number(BigInt(this.$h)|0xF00000000n),"f":32769},{"r":65537,"p":[{"n":"handle","p":109576193}],"n":"Persist","o":"@$5","d":this.$h,"h":Number(BigInt(this.$h)|0x1000000000n),"f":16},{"r":65537,"p":[{"n":"name","p":1310721}],"n":"Persist","o":"@$6","d":this.$h,"h":Number(BigInt(this.$h)|0x1100000000n),"f":16},{"r":262145,"p":[{"n":"rule","p":$.$ssa.System.Security.AccessControl.AccessRule$$(T).$h}],"n":"RemoveAccessRule","o":"@$1","d":this.$h,"h":Number(BigInt(this.$h)|0x1200000000n),"f":129},{"r":65537,"p":[{"n":"rule","p":$.$ssa.System.Security.AccessControl.AccessRule$$(T).$h}],"n":"RemoveAccessRuleAll","o":"@$1","d":this.$h,"h":Number(BigInt(this.$h)|0x1300000000n),"f":129},{"r":65537,"p":[{"n":"rule","p":$.$ssa.System.Security.AccessControl.AccessRule$$(T).$h}],"n":"RemoveAccessRuleSpecific","o":"@$1","d":this.$h,"h":Number(BigInt(this.$h)|0x1400000000n),"f":129},{"r":262145,"p":[{"n":"rule","p":$.$ssa.System.Security.AccessControl.AuditRule$$(T).$h}],"n":"RemoveAuditRule","o":"@$1","d":this.$h,"h":Number(BigInt(this.$h)|0x1500000000n),"f":129},{"r":65537,"p":[{"n":"rule","p":$.$ssa.System.Security.AccessControl.AuditRule$$(T).$h}],"n":"RemoveAuditRuleAll","o":"@$1","d":this.$h,"h":Number(BigInt(this.$h)|0x1600000000n),"f":129},{"r":65537,"p":[{"n":"rule","p":$.$ssa.System.Security.AccessControl.AuditRule$$(T).$h}],"n":"RemoveAuditRuleSpecific","o":"@$1","d":this.$h,"h":Number(BigInt(this.$h)|0x1700000000n),"f":129},{"r":65537,"p":[{"n":"rule","p":$.$ssa.System.Security.AccessControl.AccessRule$$(T).$h}],"n":"ResetAccessRule","o":"@$1","d":this.$h,"h":Number(BigInt(this.$h)|0x1800000000n),"f":129},{"r":65537,"p":[{"n":"rule","p":$.$ssa.System.Security.AccessControl.AccessRule$$(T).$h}],"n":"SetAccessRule","o":"@$1","d":this.$h,"h":Number(BigInt(this.$h)|0x1900000000n),"f":129},{"r":65537,"p":[{"n":"rule","p":$.$ssa.System.Security.AccessControl.AuditRule$$(T).$h}],"n":"SetAuditRule","o":"@$1","d":this.$h,"h":Number(BigInt(this.$h)|0x1A00000000n),"f":129}],"c":[{"p":[{"n":"isContainer","p":262145},{"n":"resourceType","p":2854983}],"n":".ctor","o":"$ctor$11","d":this.$h,"h":Number(BigInt(this.$h)|0x100000000n),"f":4},{"p":[{"n":"isContainer","p":262145},{"n":"resourceType","p":2854983},{"n":"safeHandle","p":109576193},{"n":"includeSections","p":233543}],"n":".ctor","o":"$ctor$12","d":this.$h,"h":Number(BigInt(this.$h)|0x200000000n),"f":4},{"p":[{"n":"isContainer","p":262145},{"n":"resourceType","p":2854983},{"n":"safeHandle","p":109576193},{"n":"includeSections","p":233543},{"n":"exceptionFromErrorCode","p":2068551},{"n":"exceptionContext","p":131073}],"n":".ctor","o":"$ctor$13","d":this.$h,"h":Number(BigInt(this.$h)|0x300000000n),"f":4},{"p":[{"n":"isContainer","p":262145},{"n":"resourceType","p":2854983},{"n":"name","p":1310721},{"n":"includeSections","p":233543}],"n":".ctor","o":"$ctor$14","d":this.$h,"h":Number(BigInt(this.$h)|0x400000000n),"f":4},{"p":[{"n":"isContainer","p":262145},{"n":"resourceType","p":2854983},{"n":"name","p":1310721},{"n":"includeSections","p":233543},{"n":"exceptionFromErrorCode","p":2068551},{"n":"exceptionContext","p":131073}],"n":".ctor","o":"$ctor$15","d":this.$h,"h":Number(BigInt(this.$h)|0x500000000n),"f":4}],"g":[T?.$h??1507328],"s":[{"n":"T","f":2}],"r":1,"h":this.$h}; }
            static get $b() { return $.$ssa.System.Security.AccessControl.NativeObjectSecurity; }
            static get $fullName() { return `System.Security.AccessControl.ObjectSecurity<${T?.$fullName}>`; }
        }));
        
        $asm.$cls("$ssa.System.Security.AccessControl.AceEnumerator", ($self) => class AceEnumerator extends $.$spc.System.Object
        {
            $ctor$1()
            {
                super.$ctor();
                {
                }
                return this;
            }
            /*System.Security.AccessControl.GenericAce */ get Current()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*object */ get System$Collections$IEnumerator$Current()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ MoveNext()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*void */ Reset()
            {
            }
            //Generated interface implemetation for System.Collections.IEnumerator.MoveNext()
            System$Collections$IEnumerator$MoveNext()
            {
                return this.MoveNext(...arguments);
            }
            //Generated interface implemetation for System.Collections.IEnumerator.Reset()
            System$Collections$IEnumerator$Reset()
            {
                return this.Reset(...arguments);
            }
            static $h = 495687;
            static $f = 0b10010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":1675335,"g":{"r":0,"d":0,"h":12885397575,"f":1},"n":"Current","d":495687,"h":8590430279,"f":1},{"p":131073,"g":{"r":0,"d":0,"h":21475332167,"f":2},"n":"{31719425}.Current","o":"System$Collections$IEnumerator$Current","d":495687,"h":17180364871,"f":2}],"m":[{"r":262145,"n":"MoveNext","d":495687,"h":25770299463,"f":1},{"r":65537,"n":"Reset","d":495687,"h":30065266759,"f":1}],"c":[{"n":".ctor","o":"$ctor$1","d":495687,"h":4295462983,"f":8}],"i":[31719425],"h":495687}; }
            static get $b() { return $.$spc.System.Object; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.Collections.IEnumerator ]; }
            static get $fullName() { return `System.Security.AccessControl.AceEnumerator`; }
        });
        
        $asm.$cls("$ssa.System.Security.Policy.Evidence", ($self) => class Evidence extends $.$spc.System.Object
        {
            $ctor$1()
            {
                super.$ctor();
                {
                }
                return this;
            }
            $ctor$2(/*object[]*/ hostEvidence, /*object[]*/ assemblyEvidence)
            {
                super.$ctor();
                {
                }
                return this;
            }
            $ctor$3(/*System.Security.Policy.Evidence*/ evidence)
            {
                super.$ctor();
                {
                }
                return this;
            }
            $ctor$4(/*System.Security.Policy.EvidenceBase[]*/ hostEvidence, /*System.Security.Policy.EvidenceBase[]*/ assemblyEvidence)
            {
                super.$ctor();
                {
                }
                return this;
            }
            /*int */ get Count()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get IsReadOnly()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get IsSynchronized()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get Locked()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ set Locked(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*object */ get SyncRoot()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*void */ AddAssembly(/*object*/ id)
            {
            }
            /*void */ AddAssemblyEvidence(T, /*T*/ evidence)
            {
            }
            /*void */ AddHost(/*object*/ id)
            {
            }
            /*void */ AddHostEvidence(T, /*T*/ evidence)
            {
            }
            /*void */ Clear()
            {
            }
            /*System.Security.Policy.Evidence? */ Clone()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*void */ CopyTo(/*System.Array*/ array, /*int*/ index)
            {
            }
            /*System.Collections.IEnumerator */ GetAssemblyEnumerator()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*T? */ GetAssemblyEvidence(T, )
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Collections.IEnumerator */ GetEnumerator()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Collections.IEnumerator */ GetHostEnumerator()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*T? */ GetHostEvidence(T, )
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*void */ Merge(/*System.Security.Policy.Evidence*/ evidence)
            {
            }
            /*void */ RemoveType(/*System.Type*/ t)
            {
            }
            //Generated interface implemetation for System.Collections.ICollection.CopyTo(System.Array, int)
            System$Collections$ICollection$CopyTo()
            {
                return this.CopyTo(...arguments);
            }
            //Generated interface implemetation for System.Collections.ICollection.Count.get
            get System$Collections$ICollection$Count()
            {
                return this.Count;
            }
            //Generated interface implemetation for System.Collections.ICollection.SyncRoot.get
            get System$Collections$ICollection$SyncRoot()
            {
                return this.SyncRoot;
            }
            //Generated interface implemetation for System.Collections.ICollection.IsSynchronized.get
            get System$Collections$ICollection$IsSynchronized()
            {
                return this.IsSynchronized;
            }
            //Generated interface implemetation for System.Collections.IEnumerable.GetEnumerator()
            System$Collections$IEnumerable$GetEnumerator()
            {
                return this.GetEnumerator(...arguments);
            }
            static $h = 3051591;
            static $f = 0b10010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":655361,"g":{"r":0,"d":0,"h":25772855367,"f":1},"n":"Count","d":3051591,"h":21477888071,"f":1,"a":[{"t":70909953,"c":8660844545,"a":[{"v":"Evidence should not be treated as an ICollection. Use GetHostEnumerator and GetAssemblyEnumerator to iterate over the evidence to collect a count.","t":1310721}]}]},{"p":262145,"g":{"r":0,"d":0,"h":34362789959,"f":1},"n":"IsReadOnly","d":3051591,"h":30067822663,"f":1},{"p":262145,"g":{"r":0,"d":0,"h":42952724551,"f":1},"n":"IsSynchronized","d":3051591,"h":38657757255,"f":1},{"p":262145,"g":{"r":0,"d":0,"h":51542659143,"f":1},"s":{"r":0,"d":0,"h":55837626439,"f":1},"n":"Locked","d":3051591,"h":47247691847,"f":1},{"p":131073,"g":{"r":0,"d":0,"h":64427561031,"f":1},"n":"SyncRoot","d":3051591,"h":60132593735,"f":1}],"m":[{"r":65537,"p":[{"n":"id","p":131073}],"n":"AddAssembly","d":3051591,"h":68722528327,"f":1,"a":[{"t":70909953,"c":8660844545,"a":[{"v":"Evidence.AddAssembly has been deprecated. Use AddAssemblyEvidence instead.","t":1310721}]}]},{"r":65537,"p":[{"n":"evidence","p":68723081216}],"g":["T"],"n":"AddAssemblyEvidence","d":3051591,"h":73017495623,"f":131073},{"r":65537,"p":[{"n":"id","p":131073}],"n":"AddHost","d":3051591,"h":77312462919,"f":1,"a":[{"t":70909953,"c":8660844545,"a":[{"v":"Evidence.AddHost has been deprecated. Use AddHostEvidence instead.","t":1310721}]}]},{"r":65537,"p":[{"n":"evidence","p":77313015808}],"g":["T"],"n":"AddHostEvidence","d":3051591,"h":81607430215,"f":131073},{"r":65537,"n":"Clear","d":3051591,"h":85902397511,"f":1},{"r":3051591,"n":"Clone","d":3051591,"h":90197364807,"f":1},{"r":65537,"p":[{"n":"array","p":1245185},{"n":"index","p":655361}],"n":"CopyTo","d":3051591,"h":94492332103,"f":1,"a":[{"t":70909953,"c":8660844545,"a":[{"v":"Evidence should not be treated as an ICollection. Use the GetHostEnumerator and GetAssemblyEnumerator methods rather than using CopyTo.","t":1310721}]}]},{"r":31719425,"n":"GetAssemblyEnumerator","d":3051591,"h":98787299399,"f":1},{"r":98787852288,"g":["T"],"n":"GetAssemblyEvidence","d":3051591,"h":103082266695,"f":131073},{"r":31719425,"n":"GetEnumerator","d":3051591,"h":107377233991,"f":1,"a":[{"t":70909953,"c":8660844545,"a":[{"v":"GetEnumerator is obsolete. Use GetAssemblyEnumerator and GetHostEnumerator instead.","t":1310721}]}]},{"r":31719425,"n":"GetHostEnumerator","d":3051591,"h":111672201287,"f":1},{"r":111672754176,"g":["T"],"n":"GetHostEvidence","d":3051591,"h":115967168583,"f":131073},{"r":65537,"p":[{"n":"evidence","p":3051591}],"n":"Merge","d":3051591,"h":120262135879,"f":1},{"r":65537,"p":[{"n":"t","p":142606337}],"n":"RemoveType","d":3051591,"h":124557103175,"f":1}],"c":[{"n":".ctor","o":"$ctor$1","d":3051591,"h":4298018887,"f":1},{"p":[{"n":"hostEvidence","p":0},{"n":"assemblyEvidence","p":0}],"n":".ctor","o":"$ctor$2","d":3051591,"h":8592986183,"f":1,"a":[{"t":70909953,"c":8660844545,"a":[{"v":"This constructor is obsolete. Use the constructor which accepts arrays of EvidenceBase instead.","t":1310721}]}]},{"p":[{"n":"evidence","p":3051591}],"n":".ctor","o":"$ctor$3","d":3051591,"h":12887953479,"f":1},{"p":[{"n":"hostEvidence","p":0},{"n":"assemblyEvidence","p":0}],"n":".ctor","o":"$ctor$4","d":3051591,"h":17182920775,"f":1}],"i":[31326209,31588353],"h":3051591}; }
            static get $b() { return $.$spc.System.Object; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.Collections.ICollection, $.$spc.System.Collections.IEnumerable ]; }
            static get $fullName() { return `System.Security.Policy.Evidence`; }
        });
        
        $asm.$cls("$ssa.System.Security.AccessControl.CommonSecurityDescriptor", ($self) => class CommonSecurityDescriptor extends $.$ssa.System.Security.AccessControl.GenericSecurityDescriptor
        {
            $ctor$2(/*bool*/ isContainer, /*bool*/ isDS, /*byte[]*/ binaryForm, /*int*/ offset)
            {
                super.$ctor$1();
                {
                }
                return this;
            }
            $ctor$3(/*bool*/ isContainer, /*bool*/ isDS, /*System.Security.AccessControl.ControlFlags*/ flags, /*System.Security.Principal.SecurityIdentifier?*/ owner, /*System.Security.Principal.SecurityIdentifier?*/ group, /*System.Security.AccessControl.SystemAcl?*/ systemAcl, /*System.Security.AccessControl.DiscretionaryAcl?*/ discretionaryAcl)
            {
                super.$ctor$1();
                {
                }
                return this;
            }
            $ctor$4(/*bool*/ isContainer, /*bool*/ isDS, /*System.Security.AccessControl.RawSecurityDescriptor*/ rawSecurityDescriptor)
            {
                super.$ctor$1();
                {
                }
                return this;
            }
            $ctor$5(/*bool*/ isContainer, /*bool*/ isDS, /*string*/ sddlForm)
            {
                super.$ctor$1();
                {
                }
                return this;
            }
            /*System.Security.AccessControl.ControlFlags */ get ControlFlags()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Security.AccessControl.DiscretionaryAcl? */ get DiscretionaryAcl()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Security.AccessControl.DiscretionaryAcl? */ set DiscretionaryAcl(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Security.Principal.SecurityIdentifier? */ get Group()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Security.Principal.SecurityIdentifier? */ set Group(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get IsContainer()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get IsDiscretionaryAclCanonical()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get IsDS()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get IsSystemAclCanonical()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Security.Principal.SecurityIdentifier? */ get Owner()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Security.Principal.SecurityIdentifier? */ set Owner(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Security.AccessControl.SystemAcl? */ get SystemAcl()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Security.AccessControl.SystemAcl? */ set SystemAcl(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*void */ AddDiscretionaryAcl(/*byte*/ revision, /*int*/ trusted)
            {
            }
            /*void */ AddSystemAcl(/*byte*/ revision, /*int*/ trusted)
            {
            }
            /*void */ PurgeAccessControl(/*System.Security.Principal.SecurityIdentifier*/ sid)
            {
            }
            /*void */ PurgeAudit(/*System.Security.Principal.SecurityIdentifier*/ sid)
            {
            }
            /*void */ SetDiscretionaryAclProtection(/*bool*/ isProtected, /*bool*/ preserveInheritance)
            {
            }
            /*void */ SetSystemAclProtection(/*bool*/ isProtected, /*bool*/ preserveInheritance)
            {
            }
            static $h = 1282119;
            static $f = 0b10010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":1806407,"p":[{"p":1478727,"g":{"r":0,"d":0,"h":25771085895,"f":32769},"n":"ControlFlags","d":1282119,"h":21476118599,"f":32769},{"p":1609799,"g":{"r":0,"d":0,"h":34361020487,"f":1},"s":{"r":0,"d":0,"h":38655987783,"f":1},"n":"DiscretionaryAcl","d":1282119,"h":30066053191,"f":1},{"p":435076,"g":{"r":0,"d":0,"h":47245922375,"f":32769},"s":{"r":0,"d":0,"h":51540889671,"f":32769},"n":"Group","d":1282119,"h":42950955079,"f":32769},{"p":262145,"g":{"r":0,"d":0,"h":60130824263,"f":1},"n":"IsContainer","d":1282119,"h":55835856967,"f":1},{"p":262145,"g":{"r":0,"d":0,"h":68720758855,"f":1},"n":"IsDiscretionaryAclCanonical","d":1282119,"h":64425791559,"f":1},{"p":262145,"g":{"r":0,"d":0,"h":77310693447,"f":1},"n":"IsDS","d":1282119,"h":73015726151,"f":1},{"p":262145,"g":{"r":0,"d":0,"h":85900628039,"f":1},"n":"IsSystemAclCanonical","d":1282119,"h":81605660743,"f":1},{"p":435076,"g":{"r":0,"d":0,"h":94490562631,"f":32769},"s":{"r":0,"d":0,"h":98785529927,"f":32769},"n":"Owner","d":1282119,"h":90195595335,"f":32769},{"p":2986055,"g":{"r":0,"d":0,"h":107375464519,"f":1},"s":{"r":0,"d":0,"h":111670431815,"f":1},"n":"SystemAcl","d":1282119,"h":103080497223,"f":1}],"m":[{"r":65537,"p":[{"n":"revision","p":393217},{"n":"trusted","p":655361}],"n":"AddDiscretionaryAcl","d":1282119,"h":115965399111,"f":1},{"r":65537,"p":[{"n":"revision","p":393217},{"n":"trusted","p":655361}],"n":"AddSystemAcl","d":1282119,"h":120260366407,"f":1},{"r":65537,"p":[{"n":"sid","p":435076}],"n":"PurgeAccessControl","d":1282119,"h":124555333703,"f":1},{"r":65537,"p":[{"n":"sid","p":435076}],"n":"PurgeAudit","d":1282119,"h":128850300999,"f":1},{"r":65537,"p":[{"n":"isProtected","p":262145},{"n":"preserveInheritance","p":262145}],"n":"SetDiscretionaryAclProtection","d":1282119,"h":133145268295,"f":1},{"r":65537,"p":[{"n":"isProtected","p":262145},{"n":"preserveInheritance","p":262145}],"n":"SetSystemAclProtection","d":1282119,"h":137440235591,"f":1}],"c":[{"p":[{"n":"isContainer","p":262145},{"n":"isDS","p":262145},{"n":"binaryForm","p":0},{"n":"offset","p":655361}],"n":".ctor","o":"$ctor$2","d":1282119,"h":4296249415,"f":1},{"p":[{"n":"isContainer","p":262145},{"n":"isDS","p":262145},{"n":"flags","p":1478727},{"n":"owner","p":435076},{"n":"group","p":435076},{"n":"systemAcl","p":2986055},{"n":"discretionaryAcl","p":1609799}],"n":".ctor","o":"$ctor$3","d":1282119,"h":8591216711,"f":1},{"p":[{"n":"isContainer","p":262145},{"n":"isDS","p":262145},{"n":"rawSecurityDescriptor","p":2789447}],"n":".ctor","o":"$ctor$4","d":1282119,"h":12886184007,"f":1},{"p":[{"n":"isContainer","p":262145},{"n":"isDS","p":262145},{"n":"sddlForm","p":1310721}],"n":".ctor","o":"$ctor$5","d":1282119,"h":17181151303,"f":1}],"h":1282119}; }
            static get $b() { return $.$ssa.System.Security.AccessControl.GenericSecurityDescriptor; }
            static get $fullName() { return `System.Security.AccessControl.CommonSecurityDescriptor`; }
        });
        
        $asm.$cls("$ssa.System.Security.AccessControl.CustomAce", ($self) => class CustomAce extends $.$ssa.System.Security.AccessControl.GenericAce
        {
            /*int*/ static MaxOpaqueLength = 0;
            $ctor$2(/*System.Security.AccessControl.AceType*/ type, /*System.Security.AccessControl.AceFlags*/ flags, /*byte[]?*/ opaque)
            {
                super.$ctor$1();
                {
                }
                return this;
            }
            /*int */ get BinaryLength()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ get OpaqueLength()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*void */ GetBinaryForm(/*byte[]*/ binaryForm, /*int*/ offset)
            {
            }
            /*byte[]? */ GetOpaque()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*void */ SetOpaque(/*byte[]?*/ opaque)
            {
            }
            static $h = 1544263;
            static $f = 0b10010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":1675335,"p":[{"p":655361,"g":{"r":0,"d":0,"h":17181413447,"f":32769},"n":"BinaryLength","d":1544263,"h":12886446151,"f":32769},{"p":655361,"g":{"r":0,"d":0,"h":25771348039,"f":1},"n":"OpaqueLength","d":1544263,"h":21476380743,"f":1}],"m":[{"r":65537,"p":[{"n":"binaryForm","p":0},{"n":"offset","p":655361}],"n":"GetBinaryForm","d":1544263,"h":30066315335,"f":32769},{"r":0,"n":"GetOpaque","d":1544263,"h":34361282631,"f":1},{"r":65537,"p":[{"n":"opaque","p":0}],"n":"SetOpaque","d":1544263,"h":38656249927,"f":1}],"l":[{"t":655361,"n":"MaxOpaqueLength","d":1544263,"h":4296511559,"f":33}],"c":[{"p":[{"n":"type","p":692295},{"n":"flags","p":561223},{"n":"opaque","p":0}],"n":".ctor","o":"$ctor$2","d":1544263,"h":8591478855,"f":1}],"h":1544263}; }
            static get $b() { return $.$ssa.System.Security.AccessControl.GenericAce; }
            static get $fullName() { return `System.Security.AccessControl.CustomAce`; }
        });
        
        $asm.$cls("$ssa.System.Security.AccessControl.RawSecurityDescriptor", ($self) => class RawSecurityDescriptor extends $.$ssa.System.Security.AccessControl.GenericSecurityDescriptor
        {
            $ctor$2(/*byte[]*/ binaryForm, /*int*/ offset)
            {
                super.$ctor$1();
                {
                }
                return this;
            }
            $ctor$3(/*System.Security.AccessControl.ControlFlags*/ flags, /*System.Security.Principal.SecurityIdentifier?*/ owner, /*System.Security.Principal.SecurityIdentifier?*/ group, /*System.Security.AccessControl.RawAcl?*/ systemAcl, /*System.Security.AccessControl.RawAcl?*/ discretionaryAcl)
            {
                super.$ctor$1();
                {
                }
                return this;
            }
            $ctor$4(/*string*/ sddlForm)
            {
                super.$ctor$1();
                {
                }
                return this;
            }
            /*System.Security.AccessControl.ControlFlags */ get ControlFlags()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Security.AccessControl.RawAcl? */ get DiscretionaryAcl()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Security.AccessControl.RawAcl? */ set DiscretionaryAcl(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Security.Principal.SecurityIdentifier? */ get Group()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Security.Principal.SecurityIdentifier? */ set Group(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Security.Principal.SecurityIdentifier? */ get Owner()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Security.Principal.SecurityIdentifier? */ set Owner(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*byte */ get ResourceManagerControl()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*byte */ set ResourceManagerControl(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Security.AccessControl.RawAcl? */ get SystemAcl()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Security.AccessControl.RawAcl? */ set SystemAcl(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*void */ SetFlags(/*System.Security.AccessControl.ControlFlags*/ flags)
            {
            }
            static $h = 2789447;
            static $f = 0b10010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":1806407,"p":[{"p":1478727,"g":{"r":0,"d":0,"h":21477625927,"f":32769},"n":"ControlFlags","d":2789447,"h":17182658631,"f":32769},{"p":2723911,"g":{"r":0,"d":0,"h":30067560519,"f":1},"s":{"r":0,"d":0,"h":34362527815,"f":1},"n":"DiscretionaryAcl","d":2789447,"h":25772593223,"f":1},{"p":435076,"g":{"r":0,"d":0,"h":42952462407,"f":32769},"s":{"r":0,"d":0,"h":47247429703,"f":32769},"n":"Group","d":2789447,"h":38657495111,"f":32769},{"p":435076,"g":{"r":0,"d":0,"h":55837364295,"f":32769},"s":{"r":0,"d":0,"h":60132331591,"f":32769},"n":"Owner","d":2789447,"h":51542396999,"f":32769},{"p":393217,"g":{"r":0,"d":0,"h":68722266183,"f":1},"s":{"r":0,"d":0,"h":73017233479,"f":1},"n":"ResourceManagerControl","d":2789447,"h":64427298887,"f":1},{"p":2723911,"g":{"r":0,"d":0,"h":81607168071,"f":1},"s":{"r":0,"d":0,"h":85902135367,"f":1},"n":"SystemAcl","d":2789447,"h":77312200775,"f":1}],"m":[{"r":65537,"p":[{"n":"flags","p":1478727}],"n":"SetFlags","d":2789447,"h":90197102663,"f":1}],"c":[{"p":[{"n":"binaryForm","p":0},{"n":"offset","p":655361}],"n":".ctor","o":"$ctor$2","d":2789447,"h":4297756743,"f":1},{"p":[{"n":"flags","p":1478727},{"n":"owner","p":435076},{"n":"group","p":435076},{"n":"systemAcl","p":2723911},{"n":"discretionaryAcl","p":2723911}],"n":".ctor","o":"$ctor$3","d":2789447,"h":8592724039,"f":1},{"p":[{"n":"sddlForm","p":1310721}],"n":".ctor","o":"$ctor$4","d":2789447,"h":12887691335,"f":1}],"h":2789447}; }
            static get $b() { return $.$ssa.System.Security.AccessControl.GenericSecurityDescriptor; }
            static get $fullName() { return `System.Security.AccessControl.RawSecurityDescriptor`; }
        });
        
        $asm.$cls("$ssa.System.Security.AccessControl.AuthorizationRuleCollection", ($self) => class AuthorizationRuleCollection extends $.$scn.System.Collections.ReadOnlyCollectionBase
        {
            $ctor$2()
            {
                super.$ctor$1();
                {
                }
                return this;
            }
            /*System.Security.AccessControl.AuthorizationRule?*/ get_Item(/*int*/ index)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*void */ AddRule(/*System.Security.AccessControl.AuthorizationRule?*/ rule)
            {
            }
            /*void */ CopyTo(/*System.Security.AccessControl.AuthorizationRule[]*/ rules, /*int*/ index)
            {
            }
            static $h = 1019975;
            static $f = 0b10010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":589859,"p":[{"p":954439,"i":[{"n":"index","p":655361}],"g":{"r":0,"d":0,"h":12885921863,"f":1},"n":"Item","o":"@$2","d":1019975,"h":8590954567,"f":1}],"m":[{"r":65537,"p":[{"n":"rule","p":954439}],"n":"AddRule","d":1019975,"h":17180889159,"f":1},{"r":65537,"p":[{"n":"rules","p":0},{"n":"index","p":655361}],"n":"CopyTo","d":1019975,"h":21475856455,"f":1}],"c":[{"n":".ctor","o":"$ctor$2","d":1019975,"h":4295987271,"f":1}],"i":[31326209,31588353],"h":1019975}; }
            static get $b() { return $.$scn.System.Collections.ReadOnlyCollectionBase; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.Collections.ICollection, $.$spc.System.Collections.IEnumerable ]; }
            static get $fullName() { return `System.Security.AccessControl.AuthorizationRuleCollection`; }
        });
        
        $asm.$cls("$ssa.System.Security.AccessControl.RawAcl", ($self) => class RawAcl extends $.$ssa.System.Security.AccessControl.GenericAcl
        {
            $ctor$2(/*byte*/ revision, /*int*/ capacity)
            {
                super.$ctor$1();
                {
                }
                return this;
            }
            $ctor$3(/*byte[]*/ binaryForm, /*int*/ offset)
            {
                super.$ctor$1();
                {
                }
                return this;
            }
            /*int */ get BinaryLength()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ get Count()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Security.AccessControl.GenericAce*/ get_Item(/*int*/ index)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*void*/ set_Item(/*int*/ index, /*System.Security.AccessControl.GenericAce*/ value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*byte */ get Revision()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*void */ GetBinaryForm(/*byte[]*/ binaryForm, /*int*/ offset)
            {
            }
            /*void */ InsertAce(/*int*/ index, /*System.Security.AccessControl.GenericAce*/ ace)
            {
            }
            /*void */ RemoveAce(/*int*/ index)
            {
            }
            static $h = 2723911;
            static $f = 0b10010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":1740871,"p":[{"p":655361,"g":{"r":0,"d":0,"h":17182593095,"f":32769},"n":"BinaryLength","d":2723911,"h":12887625799,"f":32769},{"p":655361,"g":{"r":0,"d":0,"h":25772527687,"f":32769},"n":"Count","d":2723911,"h":21477560391,"f":32769},{"p":1675335,"i":[{"n":"index","p":655361}],"g":{"r":0,"d":0,"h":34362462279,"f":32769},"s":{"r":0,"d":0,"h":38657429575,"f":32769},"n":"Item","o":"@$2","d":2723911,"h":30067494983,"f":32769},{"p":393217,"g":{"r":0,"d":0,"h":47247364167,"f":32769},"n":"Revision","d":2723911,"h":42952396871,"f":32769}],"m":[{"r":65537,"p":[{"n":"binaryForm","p":0},{"n":"offset","p":655361}],"n":"GetBinaryForm","d":2723911,"h":51542331463,"f":32769},{"r":65537,"p":[{"n":"index","p":655361},{"n":"ace","p":1675335}],"n":"InsertAce","d":2723911,"h":55837298759,"f":1},{"r":65537,"p":[{"n":"index","p":655361}],"n":"RemoveAce","d":2723911,"h":60132266055,"f":1}],"c":[{"p":[{"n":"revision","p":393217},{"n":"capacity","p":655361}],"n":".ctor","o":"$ctor$2","d":2723911,"h":4297691207,"f":1},{"p":[{"n":"binaryForm","p":0},{"n":"offset","p":655361}],"n":".ctor","o":"$ctor$3","d":2723911,"h":8592658503,"f":1}],"i":[31326209,31588353],"h":2723911}; }
            static get $b() { return $.$ssa.System.Security.AccessControl.GenericAcl; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.Collections.ICollection, $.$spc.System.Collections.IEnumerable ]; }
            static get $fullName() { return `System.Security.AccessControl.RawAcl`; }
        });
        
        $asm.$cls("$ssa.System.Security.AccessControl.AccessRule<>", (T) => $asm.$gt("$ssa.System.Security.AccessControl.AccessRule<>", [T], ($self) => class AccessRule$$ extends $.$ssa.System.Security.AccessControl.AccessRule
        {
            $ctor$3(/*System.Security.Principal.IdentityReference*/ identity, /*T*/ rights, /*System.Security.AccessControl.AccessControlType*/ type)
            {
                super.$ctor$2(null, 0, false, 0, 0, 0);
                {
                }
                return this;
            }
            $ctor$4(/*System.Security.Principal.IdentityReference*/ identity, /*T*/ rights, /*System.Security.AccessControl.InheritanceFlags*/ inheritanceFlags, /*System.Security.AccessControl.PropagationFlags*/ propagationFlags, /*System.Security.AccessControl.AccessControlType*/ type)
            {
                super.$ctor$2(null, 0, false, 0, 0, 0);
                {
                }
                return this;
            }
            $ctor$5(/*string*/ identity, /*T*/ rights, /*System.Security.AccessControl.AccessControlType*/ type)
            {
                super.$ctor$2(null, 0, false, 0, 0, 0);
                {
                }
                return this;
            }
            $ctor$6(/*string*/ identity, /*T*/ rights, /*System.Security.AccessControl.InheritanceFlags*/ inheritanceFlags, /*System.Security.AccessControl.PropagationFlags*/ propagationFlags, /*System.Security.AccessControl.AccessControlType*/ type)
            {
                super.$ctor$2(null, 0, false, 0, 0, 0);
                {
                }
                return this;
            }
            /*T */ get Rights()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static $h = 430151;
            static $g = 1;
            static $f = 0b1010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":364615,"p":[{"p":T?.$h??1507328,"g":{"r":0,"d":0,"h":Number(BigInt(this.$h)|0x600000000n),"f":1},"n":"Rights","d":this.$h,"h":Number(BigInt(this.$h)|0x500000000n),"f":1}],"c":[{"p":[{"n":"identity","p":238468},{"n":"rights","p":T?.$h??1507328},{"n":"type","p":299079}],"n":".ctor","o":"$ctor$3","d":this.$h,"h":Number(BigInt(this.$h)|0x100000000n),"f":1},{"p":[{"n":"identity","p":238468},{"n":"rights","p":T?.$h??1507328},{"n":"inheritanceFlags","p":1871943},{"n":"propagationFlags","p":2592839},{"n":"type","p":299079}],"n":".ctor","o":"$ctor$4","d":this.$h,"h":Number(BigInt(this.$h)|0x200000000n),"f":1},{"p":[{"n":"identity","p":1310721},{"n":"rights","p":T?.$h??1507328},{"n":"type","p":299079}],"n":".ctor","o":"$ctor$5","d":this.$h,"h":Number(BigInt(this.$h)|0x300000000n),"f":1},{"p":[{"n":"identity","p":1310721},{"n":"rights","p":T?.$h??1507328},{"n":"inheritanceFlags","p":1871943},{"n":"propagationFlags","p":2592839},{"n":"type","p":299079}],"n":".ctor","o":"$ctor$6","d":this.$h,"h":Number(BigInt(this.$h)|0x400000000n),"f":1}],"g":[T?.$h??1507328],"s":[{"n":"T","f":2}],"r":1,"h":this.$h}; }
            static get $b() { return $.$ssa.System.Security.AccessControl.AccessRule; }
            static get $fullName() { return `System.Security.AccessControl.AccessRule<${T?.$fullName}>`; }
        }));
        
        $asm.$cls("$ssa.System.Security.AccessControl.AuditRule<>", (T) => $asm.$gt("$ssa.System.Security.AccessControl.AuditRule<>", [T], ($self) => class AuditRule$$ extends $.$ssa.System.Security.AccessControl.AuditRule
        {
            $ctor$3(/*System.Security.Principal.IdentityReference*/ identity, /*T*/ rights, /*System.Security.AccessControl.AuditFlags*/ flags)
            {
                super.$ctor$2(null, 0, false, 0, 0, 0);
                {
                }
                return this;
            }
            $ctor$4(/*System.Security.Principal.IdentityReference*/ identity, /*T*/ rights, /*System.Security.AccessControl.InheritanceFlags*/ inheritanceFlags, /*System.Security.AccessControl.PropagationFlags*/ propagationFlags, /*System.Security.AccessControl.AuditFlags*/ flags)
            {
                super.$ctor$2(null, 0, false, 0, 0, 0);
                {
                }
                return this;
            }
            $ctor$5(/*string*/ identity, /*T*/ rights, /*System.Security.AccessControl.AuditFlags*/ flags)
            {
                super.$ctor$2(null, 0, false, 0, 0, 0);
                {
                }
                return this;
            }
            $ctor$6(/*string*/ identity, /*T*/ rights, /*System.Security.AccessControl.InheritanceFlags*/ inheritanceFlags, /*System.Security.AccessControl.PropagationFlags*/ propagationFlags, /*System.Security.AccessControl.AuditFlags*/ flags)
            {
                super.$ctor$2(null, 0, false, 0, 0, 0);
                {
                }
                return this;
            }
            /*T */ get Rights()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static $h = 888903;
            static $g = 1;
            static $f = 0b1010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":823367,"p":[{"p":T?.$h??1507328,"g":{"r":0,"d":0,"h":Number(BigInt(this.$h)|0x600000000n),"f":1},"n":"Rights","d":this.$h,"h":Number(BigInt(this.$h)|0x500000000n),"f":1}],"c":[{"p":[{"n":"identity","p":238468},{"n":"rights","p":T?.$h??1507328},{"n":"flags","p":757831}],"n":".ctor","o":"$ctor$3","d":this.$h,"h":Number(BigInt(this.$h)|0x100000000n),"f":1},{"p":[{"n":"identity","p":238468},{"n":"rights","p":T?.$h??1507328},{"n":"inheritanceFlags","p":1871943},{"n":"propagationFlags","p":2592839},{"n":"flags","p":757831}],"n":".ctor","o":"$ctor$4","d":this.$h,"h":Number(BigInt(this.$h)|0x200000000n),"f":1},{"p":[{"n":"identity","p":1310721},{"n":"rights","p":T?.$h??1507328},{"n":"flags","p":757831}],"n":".ctor","o":"$ctor$5","d":this.$h,"h":Number(BigInt(this.$h)|0x300000000n),"f":1},{"p":[{"n":"identity","p":1310721},{"n":"rights","p":T?.$h??1507328},{"n":"inheritanceFlags","p":1871943},{"n":"propagationFlags","p":2592839},{"n":"flags","p":757831}],"n":".ctor","o":"$ctor$6","d":this.$h,"h":Number(BigInt(this.$h)|0x400000000n),"f":1}],"g":[T?.$h??1507328],"s":[{"n":"T","f":2}],"r":1,"h":this.$h}; }
            static get $b() { return $.$ssa.System.Security.AccessControl.AuditRule; }
            static get $fullName() { return `System.Security.AccessControl.AuditRule<${T?.$fullName}>`; }
        }));
        
        $asm.$cls("$ssa.System.Security.AccessControl.CompoundAce", ($self) => class CompoundAce extends $.$ssa.System.Security.AccessControl.KnownAce
        {
            $ctor$3(/*System.Security.AccessControl.AceFlags*/ flags, /*int*/ accessMask, /*System.Security.AccessControl.CompoundAceType*/ compoundAceType, /*System.Security.Principal.SecurityIdentifier*/ sid)
            {
                super.$ctor$2();
                {
                }
                return this;
            }
            /*int */ get BinaryLength()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Security.AccessControl.CompoundAceType */ get CompoundAceType()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Security.AccessControl.CompoundAceType */ set CompoundAceType(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*void */ GetBinaryForm(/*byte[]*/ binaryForm, /*int*/ offset)
            {
            }
            static $h = 1347655;
            static $f = 0b10010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":1937479,"p":[{"p":655361,"g":{"r":0,"d":0,"h":12886249543,"f":32769},"n":"BinaryLength","d":1347655,"h":8591282247,"f":32769},{"p":1413191,"g":{"r":0,"d":0,"h":21476184135,"f":1},"s":{"r":0,"d":0,"h":25771151431,"f":1},"n":"CompoundAceType","d":1347655,"h":17181216839,"f":1}],"m":[{"r":65537,"p":[{"n":"binaryForm","p":0},{"n":"offset","p":655361}],"n":"GetBinaryForm","d":1347655,"h":30066118727,"f":32769}],"c":[{"p":[{"n":"flags","p":561223},{"n":"accessMask","p":655361},{"n":"compoundAceType","p":1413191},{"n":"sid","p":435076}],"n":".ctor","o":"$ctor$3","d":1347655,"h":4296314951,"f":1}],"h":1347655}; }
            static get $b() { return $.$ssa.System.Security.AccessControl.KnownAce; }
            static get $fullName() { return `System.Security.AccessControl.CompoundAce`; }
        });
        
        $asm.$cls("$ssa.System.Security.AccessControl.DiscretionaryAcl", ($self) => class DiscretionaryAcl extends $.$ssa.System.Security.AccessControl.CommonAcl
        {
            $ctor$3(/*bool*/ isContainer, /*bool*/ isDS, /*byte*/ revision, /*int*/ capacity)
            {
                super.$ctor$2();
                {
                }
                return this;
            }
            $ctor$4(/*bool*/ isContainer, /*bool*/ isDS, /*int*/ capacity)
            {
                super.$ctor$2();
                {
                }
                return this;
            }
            $ctor$5(/*bool*/ isContainer, /*bool*/ isDS, /*System.Security.AccessControl.RawAcl?*/ rawAcl)
            {
                super.$ctor$2();
                {
                }
                return this;
            }
            /*void */ AddAccess(/*System.Security.AccessControl.AccessControlType*/ accessType, /*System.Security.Principal.SecurityIdentifier*/ sid, /*int*/ accessMask, /*System.Security.AccessControl.InheritanceFlags*/ inheritanceFlags, /*System.Security.AccessControl.PropagationFlags*/ propagationFlags)
            {
            }
            /*void */ AddAccess$1(/*System.Security.AccessControl.AccessControlType*/ accessType, /*System.Security.Principal.SecurityIdentifier*/ sid, /*int*/ accessMask, /*System.Security.AccessControl.InheritanceFlags*/ inheritanceFlags, /*System.Security.AccessControl.PropagationFlags*/ propagationFlags, /*System.Security.AccessControl.ObjectAceFlags*/ objectFlags, /*System.Guid*/ objectType, /*System.Guid*/ inheritedObjectType)
            {
            }
            /*void */ AddAccess$2(/*System.Security.AccessControl.AccessControlType*/ accessType, /*System.Security.Principal.SecurityIdentifier*/ sid, /*System.Security.AccessControl.ObjectAccessRule*/ rule)
            {
            }
            /*bool */ RemoveAccess(/*System.Security.AccessControl.AccessControlType*/ accessType, /*System.Security.Principal.SecurityIdentifier*/ sid, /*int*/ accessMask, /*System.Security.AccessControl.InheritanceFlags*/ inheritanceFlags, /*System.Security.AccessControl.PropagationFlags*/ propagationFlags)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ RemoveAccess$1(/*System.Security.AccessControl.AccessControlType*/ accessType, /*System.Security.Principal.SecurityIdentifier*/ sid, /*int*/ accessMask, /*System.Security.AccessControl.InheritanceFlags*/ inheritanceFlags, /*System.Security.AccessControl.PropagationFlags*/ propagationFlags, /*System.Security.AccessControl.ObjectAceFlags*/ objectFlags, /*System.Guid*/ objectType, /*System.Guid*/ inheritedObjectType)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ RemoveAccess$2(/*System.Security.AccessControl.AccessControlType*/ accessType, /*System.Security.Principal.SecurityIdentifier*/ sid, /*System.Security.AccessControl.ObjectAccessRule*/ rule)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*void */ RemoveAccessSpecific(/*System.Security.AccessControl.AccessControlType*/ accessType, /*System.Security.Principal.SecurityIdentifier*/ sid, /*int*/ accessMask, /*System.Security.AccessControl.InheritanceFlags*/ inheritanceFlags, /*System.Security.AccessControl.PropagationFlags*/ propagationFlags)
            {
            }
            /*void */ RemoveAccessSpecific$1(/*System.Security.AccessControl.AccessControlType*/ accessType, /*System.Security.Principal.SecurityIdentifier*/ sid, /*int*/ accessMask, /*System.Security.AccessControl.InheritanceFlags*/ inheritanceFlags, /*System.Security.AccessControl.PropagationFlags*/ propagationFlags, /*System.Security.AccessControl.ObjectAceFlags*/ objectFlags, /*System.Guid*/ objectType, /*System.Guid*/ inheritedObjectType)
            {
            }
            /*void */ RemoveAccessSpecific$2(/*System.Security.AccessControl.AccessControlType*/ accessType, /*System.Security.Principal.SecurityIdentifier*/ sid, /*System.Security.AccessControl.ObjectAccessRule*/ rule)
            {
            }
            /*void */ SetAccess(/*System.Security.AccessControl.AccessControlType*/ accessType, /*System.Security.Principal.SecurityIdentifier*/ sid, /*int*/ accessMask, /*System.Security.AccessControl.InheritanceFlags*/ inheritanceFlags, /*System.Security.AccessControl.PropagationFlags*/ propagationFlags)
            {
            }
            /*void */ SetAccess$1(/*System.Security.AccessControl.AccessControlType*/ accessType, /*System.Security.Principal.SecurityIdentifier*/ sid, /*int*/ accessMask, /*System.Security.AccessControl.InheritanceFlags*/ inheritanceFlags, /*System.Security.AccessControl.PropagationFlags*/ propagationFlags, /*System.Security.AccessControl.ObjectAceFlags*/ objectFlags, /*System.Guid*/ objectType, /*System.Guid*/ inheritedObjectType)
            {
            }
            /*void */ SetAccess$2(/*System.Security.AccessControl.AccessControlType*/ accessType, /*System.Security.Principal.SecurityIdentifier*/ sid, /*System.Security.AccessControl.ObjectAccessRule*/ rule)
            {
            }
            static $h = 1609799;
            static $f = 0b10010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":1151047,"m":[{"r":65537,"p":[{"n":"accessType","p":299079},{"n":"sid","p":435076},{"n":"accessMask","p":655361},{"n":"inheritanceFlags","p":1871943},{"n":"propagationFlags","p":2592839}],"n":"AddAccess","d":1609799,"h":17181478983,"f":1},{"r":65537,"p":[{"n":"accessType","p":299079},{"n":"sid","p":435076},{"n":"accessMask","p":655361},{"n":"inheritanceFlags","p":1871943},{"n":"propagationFlags","p":2592839},{"n":"objectFlags","p":2265159},{"n":"objectType","p":56164353},{"n":"inheritedObjectType","p":56164353}],"n":"AddAccess","o":"@$1","d":1609799,"h":21476446279,"f":1},{"r":65537,"p":[{"n":"accessType","p":299079},{"n":"sid","p":435076},{"n":"rule","p":2134087}],"n":"AddAccess","o":"@$2","d":1609799,"h":25771413575,"f":1},{"r":262145,"p":[{"n":"accessType","p":299079},{"n":"sid","p":435076},{"n":"accessMask","p":655361},{"n":"inheritanceFlags","p":1871943},{"n":"propagationFlags","p":2592839}],"n":"RemoveAccess","d":1609799,"h":30066380871,"f":1},{"r":262145,"p":[{"n":"accessType","p":299079},{"n":"sid","p":435076},{"n":"accessMask","p":655361},{"n":"inheritanceFlags","p":1871943},{"n":"propagationFlags","p":2592839},{"n":"objectFlags","p":2265159},{"n":"objectType","p":56164353},{"n":"inheritedObjectType","p":56164353}],"n":"RemoveAccess","o":"@$1","d":1609799,"h":34361348167,"f":1},{"r":262145,"p":[{"n":"accessType","p":299079},{"n":"sid","p":435076},{"n":"rule","p":2134087}],"n":"RemoveAccess","o":"@$2","d":1609799,"h":38656315463,"f":1},{"r":65537,"p":[{"n":"accessType","p":299079},{"n":"sid","p":435076},{"n":"accessMask","p":655361},{"n":"inheritanceFlags","p":1871943},{"n":"propagationFlags","p":2592839}],"n":"RemoveAccessSpecific","d":1609799,"h":42951282759,"f":1},{"r":65537,"p":[{"n":"accessType","p":299079},{"n":"sid","p":435076},{"n":"accessMask","p":655361},{"n":"inheritanceFlags","p":1871943},{"n":"propagationFlags","p":2592839},{"n":"objectFlags","p":2265159},{"n":"objectType","p":56164353},{"n":"inheritedObjectType","p":56164353}],"n":"RemoveAccessSpecific","o":"@$1","d":1609799,"h":47246250055,"f":1},{"r":65537,"p":[{"n":"accessType","p":299079},{"n":"sid","p":435076},{"n":"rule","p":2134087}],"n":"RemoveAccessSpecific","o":"@$2","d":1609799,"h":51541217351,"f":1},{"r":65537,"p":[{"n":"accessType","p":299079},{"n":"sid","p":435076},{"n":"accessMask","p":655361},{"n":"inheritanceFlags","p":1871943},{"n":"propagationFlags","p":2592839}],"n":"SetAccess","d":1609799,"h":55836184647,"f":1},{"r":65537,"p":[{"n":"accessType","p":299079},{"n":"sid","p":435076},{"n":"accessMask","p":655361},{"n":"inheritanceFlags","p":1871943},{"n":"propagationFlags","p":2592839},{"n":"objectFlags","p":2265159},{"n":"objectType","p":56164353},{"n":"inheritedObjectType","p":56164353}],"n":"SetAccess","o":"@$1","d":1609799,"h":60131151943,"f":1},{"r":65537,"p":[{"n":"accessType","p":299079},{"n":"sid","p":435076},{"n":"rule","p":2134087}],"n":"SetAccess","o":"@$2","d":1609799,"h":64426119239,"f":1}],"c":[{"p":[{"n":"isContainer","p":262145},{"n":"isDS","p":262145},{"n":"revision","p":393217},{"n":"capacity","p":655361}],"n":".ctor","o":"$ctor$3","d":1609799,"h":4296577095,"f":1},{"p":[{"n":"isContainer","p":262145},{"n":"isDS","p":262145},{"n":"capacity","p":655361}],"n":".ctor","o":"$ctor$4","d":1609799,"h":8591544391,"f":1},{"p":[{"n":"isContainer","p":262145},{"n":"isDS","p":262145},{"n":"rawAcl","p":2723911}],"n":".ctor","o":"$ctor$5","d":1609799,"h":12886511687,"f":1}],"i":[31326209,31588353],"h":1609799}; }
            static get $b() { return $.$ssa.System.Security.AccessControl.CommonAcl; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.Collections.ICollection, $.$spc.System.Collections.IEnumerable ]; }
            static get $fullName() { return `System.Security.AccessControl.DiscretionaryAcl`; }
        });
        
        $asm.$cls("$ssa.System.Security.AccessControl.SystemAcl", ($self) => class SystemAcl extends $.$ssa.System.Security.AccessControl.CommonAcl
        {
            $ctor$3(/*bool*/ isContainer, /*bool*/ isDS, /*byte*/ revision, /*int*/ capacity)
            {
                super.$ctor$2();
                {
                }
                return this;
            }
            $ctor$4(/*bool*/ isContainer, /*bool*/ isDS, /*int*/ capacity)
            {
                super.$ctor$2();
                {
                }
                return this;
            }
            $ctor$5(/*bool*/ isContainer, /*bool*/ isDS, /*System.Security.AccessControl.RawAcl*/ rawAcl)
            {
                super.$ctor$2();
                {
                }
                return this;
            }
            /*void */ AddAudit(/*System.Security.AccessControl.AuditFlags*/ auditFlags, /*System.Security.Principal.SecurityIdentifier*/ sid, /*int*/ accessMask, /*System.Security.AccessControl.InheritanceFlags*/ inheritanceFlags, /*System.Security.AccessControl.PropagationFlags*/ propagationFlags)
            {
            }
            /*void */ AddAudit$1(/*System.Security.AccessControl.AuditFlags*/ auditFlags, /*System.Security.Principal.SecurityIdentifier*/ sid, /*int*/ accessMask, /*System.Security.AccessControl.InheritanceFlags*/ inheritanceFlags, /*System.Security.AccessControl.PropagationFlags*/ propagationFlags, /*System.Security.AccessControl.ObjectAceFlags*/ objectFlags, /*System.Guid*/ objectType, /*System.Guid*/ inheritedObjectType)
            {
            }
            /*void */ AddAudit$2(/*System.Security.Principal.SecurityIdentifier*/ sid, /*System.Security.AccessControl.ObjectAuditRule*/ rule)
            {
            }
            /*bool */ RemoveAudit(/*System.Security.AccessControl.AuditFlags*/ auditFlags, /*System.Security.Principal.SecurityIdentifier*/ sid, /*int*/ accessMask, /*System.Security.AccessControl.InheritanceFlags*/ inheritanceFlags, /*System.Security.AccessControl.PropagationFlags*/ propagationFlags)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ RemoveAudit$1(/*System.Security.AccessControl.AuditFlags*/ auditFlags, /*System.Security.Principal.SecurityIdentifier*/ sid, /*int*/ accessMask, /*System.Security.AccessControl.InheritanceFlags*/ inheritanceFlags, /*System.Security.AccessControl.PropagationFlags*/ propagationFlags, /*System.Security.AccessControl.ObjectAceFlags*/ objectFlags, /*System.Guid*/ objectType, /*System.Guid*/ inheritedObjectType)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ RemoveAudit$2(/*System.Security.Principal.SecurityIdentifier*/ sid, /*System.Security.AccessControl.ObjectAuditRule*/ rule)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*void */ RemoveAuditSpecific(/*System.Security.AccessControl.AuditFlags*/ auditFlags, /*System.Security.Principal.SecurityIdentifier*/ sid, /*int*/ accessMask, /*System.Security.AccessControl.InheritanceFlags*/ inheritanceFlags, /*System.Security.AccessControl.PropagationFlags*/ propagationFlags)
            {
            }
            /*void */ RemoveAuditSpecific$1(/*System.Security.AccessControl.AuditFlags*/ auditFlags, /*System.Security.Principal.SecurityIdentifier*/ sid, /*int*/ accessMask, /*System.Security.AccessControl.InheritanceFlags*/ inheritanceFlags, /*System.Security.AccessControl.PropagationFlags*/ propagationFlags, /*System.Security.AccessControl.ObjectAceFlags*/ objectFlags, /*System.Guid*/ objectType, /*System.Guid*/ inheritedObjectType)
            {
            }
            /*void */ RemoveAuditSpecific$2(/*System.Security.Principal.SecurityIdentifier*/ sid, /*System.Security.AccessControl.ObjectAuditRule*/ rule)
            {
            }
            /*void */ SetAudit(/*System.Security.AccessControl.AuditFlags*/ auditFlags, /*System.Security.Principal.SecurityIdentifier*/ sid, /*int*/ accessMask, /*System.Security.AccessControl.InheritanceFlags*/ inheritanceFlags, /*System.Security.AccessControl.PropagationFlags*/ propagationFlags)
            {
            }
            /*void */ SetAudit$1(/*System.Security.AccessControl.AuditFlags*/ auditFlags, /*System.Security.Principal.SecurityIdentifier*/ sid, /*int*/ accessMask, /*System.Security.AccessControl.InheritanceFlags*/ inheritanceFlags, /*System.Security.AccessControl.PropagationFlags*/ propagationFlags, /*System.Security.AccessControl.ObjectAceFlags*/ objectFlags, /*System.Guid*/ objectType, /*System.Guid*/ inheritedObjectType)
            {
            }
            /*void */ SetAudit$2(/*System.Security.Principal.SecurityIdentifier*/ sid, /*System.Security.AccessControl.ObjectAuditRule*/ rule)
            {
            }
            static $h = 2986055;
            static $f = 0b10010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":1151047,"m":[{"r":65537,"p":[{"n":"auditFlags","p":757831},{"n":"sid","p":435076},{"n":"accessMask","p":655361},{"n":"inheritanceFlags","p":1871943},{"n":"propagationFlags","p":2592839}],"n":"AddAudit","d":2986055,"h":17182855239,"f":1},{"r":65537,"p":[{"n":"auditFlags","p":757831},{"n":"sid","p":435076},{"n":"accessMask","p":655361},{"n":"inheritanceFlags","p":1871943},{"n":"propagationFlags","p":2592839},{"n":"objectFlags","p":2265159},{"n":"objectType","p":56164353},{"n":"inheritedObjectType","p":56164353}],"n":"AddAudit","o":"@$1","d":2986055,"h":21477822535,"f":1},{"r":65537,"p":[{"n":"sid","p":435076},{"n":"rule","p":2330695}],"n":"AddAudit","o":"@$2","d":2986055,"h":25772789831,"f":1},{"r":262145,"p":[{"n":"auditFlags","p":757831},{"n":"sid","p":435076},{"n":"accessMask","p":655361},{"n":"inheritanceFlags","p":1871943},{"n":"propagationFlags","p":2592839}],"n":"RemoveAudit","d":2986055,"h":30067757127,"f":1},{"r":262145,"p":[{"n":"auditFlags","p":757831},{"n":"sid","p":435076},{"n":"accessMask","p":655361},{"n":"inheritanceFlags","p":1871943},{"n":"propagationFlags","p":2592839},{"n":"objectFlags","p":2265159},{"n":"objectType","p":56164353},{"n":"inheritedObjectType","p":56164353}],"n":"RemoveAudit","o":"@$1","d":2986055,"h":34362724423,"f":1},{"r":262145,"p":[{"n":"sid","p":435076},{"n":"rule","p":2330695}],"n":"RemoveAudit","o":"@$2","d":2986055,"h":38657691719,"f":1},{"r":65537,"p":[{"n":"auditFlags","p":757831},{"n":"sid","p":435076},{"n":"accessMask","p":655361},{"n":"inheritanceFlags","p":1871943},{"n":"propagationFlags","p":2592839}],"n":"RemoveAuditSpecific","d":2986055,"h":42952659015,"f":1},{"r":65537,"p":[{"n":"auditFlags","p":757831},{"n":"sid","p":435076},{"n":"accessMask","p":655361},{"n":"inheritanceFlags","p":1871943},{"n":"propagationFlags","p":2592839},{"n":"objectFlags","p":2265159},{"n":"objectType","p":56164353},{"n":"inheritedObjectType","p":56164353}],"n":"RemoveAuditSpecific","o":"@$1","d":2986055,"h":47247626311,"f":1},{"r":65537,"p":[{"n":"sid","p":435076},{"n":"rule","p":2330695}],"n":"RemoveAuditSpecific","o":"@$2","d":2986055,"h":51542593607,"f":1},{"r":65537,"p":[{"n":"auditFlags","p":757831},{"n":"sid","p":435076},{"n":"accessMask","p":655361},{"n":"inheritanceFlags","p":1871943},{"n":"propagationFlags","p":2592839}],"n":"SetAudit","d":2986055,"h":55837560903,"f":1},{"r":65537,"p":[{"n":"auditFlags","p":757831},{"n":"sid","p":435076},{"n":"accessMask","p":655361},{"n":"inheritanceFlags","p":1871943},{"n":"propagationFlags","p":2592839},{"n":"objectFlags","p":2265159},{"n":"objectType","p":56164353},{"n":"inheritedObjectType","p":56164353}],"n":"SetAudit","o":"@$1","d":2986055,"h":60132528199,"f":1},{"r":65537,"p":[{"n":"sid","p":435076},{"n":"rule","p":2330695}],"n":"SetAudit","o":"@$2","d":2986055,"h":64427495495,"f":1}],"c":[{"p":[{"n":"isContainer","p":262145},{"n":"isDS","p":262145},{"n":"revision","p":393217},{"n":"capacity","p":655361}],"n":".ctor","o":"$ctor$3","d":2986055,"h":4297953351,"f":1},{"p":[{"n":"isContainer","p":262145},{"n":"isDS","p":262145},{"n":"capacity","p":655361}],"n":".ctor","o":"$ctor$4","d":2986055,"h":8592920647,"f":1},{"p":[{"n":"isContainer","p":262145},{"n":"isDS","p":262145},{"n":"rawAcl","p":2723911}],"n":".ctor","o":"$ctor$5","d":2986055,"h":12887887943,"f":1}],"i":[31326209,31588353],"h":2986055}; }
            static get $b() { return $.$ssa.System.Security.AccessControl.CommonAcl; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.Collections.ICollection, $.$spc.System.Collections.IEnumerable ]; }
            static get $fullName() { return `System.Security.AccessControl.SystemAcl`; }
        });
        
        $asm.$str("$ssa.System.Security.AccessControl.AccessControlActions", ($self) => class AccessControlActions extends $.$spc.System.Enum
        {
            static None = 0;
            static View = 1;
            static Change = 2;
            static $map;
            static get Map()
            {
                return this.$map ??= 
                {
                    "None": 0n,
                    "View": 1n,
                    "Change": 2n
                };
            }
            static $h = 102471;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static get $eut() { return $.$spc.System.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {"b":1048577,"u":655361,"l":[{"t":102471,"n":"None","d":102471,"h":4295069767,"f":33},{"t":102471,"n":"View","d":102471,"h":8590037063,"f":33},{"t":102471,"n":"Change","d":102471,"h":12885004359,"f":33}],"c":[{"n":".ctor","o":"$ctor$3","d":102471,"h":17179971655,"f":1}],"i":[57212929,63766529,57671681,57344001],"h":102471,"a":[{"t":47644673,"c":4342611969}]}; }
            static get $b() { return $.$spc.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IComparable, $.$spc.System.ISpanFormattable, $.$spc.System.IFormattable, $.$spc.System.IConvertible ]; }
            static get $fullName() { return `System.Security.AccessControl.AccessControlActions`; }
        });
        
        $asm.$str("$ssa.System.Security.AccessControl.AccessControlModification", ($self) => class AccessControlModification extends $.$spc.System.Enum
        {
            static Add = 0;
            static Set = 1;
            static Reset = 2;
            static Remove = 3;
            static RemoveAll = 4;
            static RemoveSpecific = 5;
            static $map;
            static get Map()
            {
                return this.$map ??= 
                {
                    "Add": 0n,
                    "Set": 1n,
                    "Reset": 2n,
                    "Remove": 3n,
                    "RemoveAll": 4n,
                    "RemoveSpecific": 5n
                };
            }
            static $h = 168007;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static get $eut() { return $.$spc.System.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {"b":1048577,"u":655361,"l":[{"t":168007,"n":"Add","d":168007,"h":4295135303,"f":33},{"t":168007,"n":"Set","d":168007,"h":8590102599,"f":33},{"t":168007,"n":"Reset","d":168007,"h":12885069895,"f":33},{"t":168007,"n":"Remove","d":168007,"h":17180037191,"f":33},{"t":168007,"n":"RemoveAll","d":168007,"h":21475004487,"f":33},{"t":168007,"n":"RemoveSpecific","d":168007,"h":25769971783,"f":33}],"c":[{"n":".ctor","o":"$ctor$3","d":168007,"h":30064939079,"f":1}],"i":[57212929,63766529,57671681,57344001],"h":168007}; }
            static get $b() { return $.$spc.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IComparable, $.$spc.System.ISpanFormattable, $.$spc.System.IFormattable, $.$spc.System.IConvertible ]; }
            static get $fullName() { return `System.Security.AccessControl.AccessControlModification`; }
        });
        
        $asm.$str("$ssa.System.Security.AccessControl.AccessControlSections", ($self) => class AccessControlSections extends $.$spc.System.Enum
        {
            static None = 0;
            static Audit = 1;
            static Access = 2;
            static Owner = 4;
            static Group = 8;
            static All = 15;
            static $map;
            static get Map()
            {
                return this.$map ??= 
                {
                    "None": 0n,
                    "Audit": 1n,
                    "Access": 2n,
                    "Owner": 4n,
                    "Group": 8n,
                    "All": 15n
                };
            }
            static $h = 233543;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static get $eut() { return $.$spc.System.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {"b":1048577,"u":655361,"l":[{"t":233543,"n":"None","d":233543,"h":4295200839,"f":33},{"t":233543,"n":"Audit","d":233543,"h":8590168135,"f":33},{"t":233543,"n":"Access","d":233543,"h":12885135431,"f":33},{"t":233543,"n":"Owner","d":233543,"h":17180102727,"f":33},{"t":233543,"n":"Group","d":233543,"h":21475070023,"f":33},{"t":233543,"n":"All","d":233543,"h":25770037319,"f":33}],"c":[{"n":".ctor","o":"$ctor$3","d":233543,"h":30065004615,"f":1}],"i":[57212929,63766529,57671681,57344001],"h":233543,"a":[{"t":47644673,"c":4342611969}]}; }
            static get $b() { return $.$spc.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IComparable, $.$spc.System.ISpanFormattable, $.$spc.System.IFormattable, $.$spc.System.IConvertible ]; }
            static get $fullName() { return `System.Security.AccessControl.AccessControlSections`; }
        });
        
        $asm.$str("$ssa.System.Security.AccessControl.AccessControlType", ($self) => class AccessControlType extends $.$spc.System.Enum
        {
            static Allow = 0;
            static Deny = 1;
            static $map;
            static get Map()
            {
                return this.$map ??= 
                {
                    "Allow": 0n,
                    "Deny": 1n
                };
            }
            static $h = 299079;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static get $eut() { return $.$spc.System.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {"b":1048577,"u":655361,"l":[{"t":299079,"n":"Allow","d":299079,"h":4295266375,"f":33},{"t":299079,"n":"Deny","d":299079,"h":8590233671,"f":33}],"c":[{"n":".ctor","o":"$ctor$3","d":299079,"h":12885200967,"f":1}],"i":[57212929,63766529,57671681,57344001],"h":299079}; }
            static get $b() { return $.$spc.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IComparable, $.$spc.System.ISpanFormattable, $.$spc.System.IFormattable, $.$spc.System.IConvertible ]; }
            static get $fullName() { return `System.Security.AccessControl.AccessControlType`; }
        });
        
        $asm.$str("$ssa.System.Security.AccessControl.AceFlags", ($self) => class AceFlags extends $.$spc.System.Enum
        {
            static None = 0;
            static ObjectInherit = 1;
            static ContainerInherit = 2;
            static NoPropagateInherit = 4;
            static InheritOnly = 8;
            static InheritanceFlags = 15;
            static Inherited = 16;
            static SuccessfulAccess = 64;
            static FailedAccess = 128;
            static AuditFlags = 192;
            static $map;
            static get Map()
            {
                return this.$map ??= 
                {
                    "None": 0n,
                    "ObjectInherit": 1n,
                    "ContainerInherit": 2n,
                    "NoPropagateInherit": 4n,
                    "InheritOnly": 8n,
                    "InheritanceFlags": 15n,
                    "Inherited": 16n,
                    "SuccessfulAccess": 64n,
                    "FailedAccess": 128n,
                    "AuditFlags": 192n
                };
            }
            static $h = 561223;
            static $z = 1;
            static $f = 0b100000011010001001;
            static $k = 4;
            static get $eut() { return $.$spc.System.Byte; }
            static $$md;
            static get $md() { return this.$$md ??= {"b":1048577,"u":393217,"l":[{"t":561223,"n":"None","d":561223,"h":4295528519,"f":33},{"t":561223,"n":"ObjectInherit","d":561223,"h":8590495815,"f":33},{"t":561223,"n":"ContainerInherit","d":561223,"h":12885463111,"f":33},{"t":561223,"n":"NoPropagateInherit","d":561223,"h":17180430407,"f":33},{"t":561223,"n":"InheritOnly","d":561223,"h":21475397703,"f":33},{"t":561223,"n":"InheritanceFlags","d":561223,"h":25770364999,"f":33},{"t":561223,"n":"Inherited","d":561223,"h":30065332295,"f":33},{"t":561223,"n":"SuccessfulAccess","d":561223,"h":34360299591,"f":33},{"t":561223,"n":"FailedAccess","d":561223,"h":38655266887,"f":33},{"t":561223,"n":"AuditFlags","d":561223,"h":42950234183,"f":33}],"c":[{"n":".ctor","o":"$ctor$3","d":561223,"h":47245201479,"f":1}],"i":[57212929,63766529,57671681,57344001],"h":561223,"a":[{"t":47644673,"c":4342611969}]}; }
            static get $b() { return $.$spc.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IComparable, $.$spc.System.ISpanFormattable, $.$spc.System.IFormattable, $.$spc.System.IConvertible ]; }
            static get $fullName() { return `System.Security.AccessControl.AceFlags`; }
        });
        
        $asm.$str("$ssa.System.Security.AccessControl.AceQualifier", ($self) => class AceQualifier extends $.$spc.System.Enum
        {
            static AccessAllowed = 0;
            static AccessDenied = 1;
            static SystemAudit = 2;
            static SystemAlarm = 3;
            static $map;
            static get Map()
            {
                return this.$map ??= 
                {
                    "AccessAllowed": 0n,
                    "AccessDenied": 1n,
                    "SystemAudit": 2n,
                    "SystemAlarm": 3n
                };
            }
            static $h = 626759;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static get $eut() { return $.$spc.System.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {"b":1048577,"u":655361,"l":[{"t":626759,"n":"AccessAllowed","d":626759,"h":4295594055,"f":33},{"t":626759,"n":"AccessDenied","d":626759,"h":8590561351,"f":33},{"t":626759,"n":"SystemAudit","d":626759,"h":12885528647,"f":33},{"t":626759,"n":"SystemAlarm","d":626759,"h":17180495943,"f":33}],"c":[{"n":".ctor","o":"$ctor$3","d":626759,"h":21475463239,"f":1}],"i":[57212929,63766529,57671681,57344001],"h":626759}; }
            static get $b() { return $.$spc.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IComparable, $.$spc.System.ISpanFormattable, $.$spc.System.IFormattable, $.$spc.System.IConvertible ]; }
            static get $fullName() { return `System.Security.AccessControl.AceQualifier`; }
        });
        
        $asm.$str("$ssa.System.Security.AccessControl.AceType", ($self) => class AceType extends $.$spc.System.Enum
        {
            static AccessAllowed = 0;
            static AccessDenied = 1;
            static SystemAudit = 2;
            static SystemAlarm = 3;
            static AccessAllowedCompound = 4;
            static AccessAllowedObject = 5;
            static AccessDeniedObject = 6;
            static SystemAuditObject = 7;
            static SystemAlarmObject = 8;
            static AccessAllowedCallback = 9;
            static AccessDeniedCallback = 10;
            static AccessAllowedCallbackObject = 11;
            static AccessDeniedCallbackObject = 12;
            static SystemAuditCallback = 13;
            static SystemAlarmCallback = 14;
            static SystemAuditCallbackObject = 15;
            static MaxDefinedAceType = 16;
            static SystemAlarmCallbackObject = 16;
            static $map;
            static get Map()
            {
                return this.$map ??= 
                {
                    "AccessAllowed": 0n,
                    "AccessDenied": 1n,
                    "SystemAudit": 2n,
                    "SystemAlarm": 3n,
                    "AccessAllowedCompound": 4n,
                    "AccessAllowedObject": 5n,
                    "AccessDeniedObject": 6n,
                    "SystemAuditObject": 7n,
                    "SystemAlarmObject": 8n,
                    "AccessAllowedCallback": 9n,
                    "AccessDeniedCallback": 10n,
                    "AccessAllowedCallbackObject": 11n,
                    "AccessDeniedCallbackObject": 12n,
                    "SystemAuditCallback": 13n,
                    "SystemAlarmCallback": 14n,
                    "SystemAuditCallbackObject": 15n,
                    "MaxDefinedAceType": 16n,
                    "SystemAlarmCallbackObject": 16n
                };
            }
            static $h = 692295;
            static $z = 1;
            static $f = 0b100000011010001001;
            static $k = 4;
            static get $eut() { return $.$spc.System.Byte; }
            static $$md;
            static get $md() { return this.$$md ??= {"b":1048577,"u":393217,"l":[{"t":692295,"n":"AccessAllowed","d":692295,"h":4295659591,"f":33},{"t":692295,"n":"AccessDenied","d":692295,"h":8590626887,"f":33},{"t":692295,"n":"SystemAudit","d":692295,"h":12885594183,"f":33},{"t":692295,"n":"SystemAlarm","d":692295,"h":17180561479,"f":33},{"t":692295,"n":"AccessAllowedCompound","d":692295,"h":21475528775,"f":33},{"t":692295,"n":"AccessAllowedObject","d":692295,"h":25770496071,"f":33},{"t":692295,"n":"AccessDeniedObject","d":692295,"h":30065463367,"f":33},{"t":692295,"n":"SystemAuditObject","d":692295,"h":34360430663,"f":33},{"t":692295,"n":"SystemAlarmObject","d":692295,"h":38655397959,"f":33},{"t":692295,"n":"AccessAllowedCallback","d":692295,"h":42950365255,"f":33},{"t":692295,"n":"AccessDeniedCallback","d":692295,"h":47245332551,"f":33},{"t":692295,"n":"AccessAllowedCallbackObject","d":692295,"h":51540299847,"f":33},{"t":692295,"n":"AccessDeniedCallbackObject","d":692295,"h":55835267143,"f":33},{"t":692295,"n":"SystemAuditCallback","d":692295,"h":60130234439,"f":33},{"t":692295,"n":"SystemAlarmCallback","d":692295,"h":64425201735,"f":33},{"t":692295,"n":"SystemAuditCallbackObject","d":692295,"h":68720169031,"f":33},{"t":692295,"n":"MaxDefinedAceType","d":692295,"h":73015136327,"f":33},{"t":692295,"n":"SystemAlarmCallbackObject","d":692295,"h":77310103623,"f":33}],"c":[{"n":".ctor","o":"$ctor$3","d":692295,"h":81605070919,"f":1}],"i":[57212929,63766529,57671681,57344001],"h":692295}; }
            static get $b() { return $.$spc.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IComparable, $.$spc.System.ISpanFormattable, $.$spc.System.IFormattable, $.$spc.System.IConvertible ]; }
            static get $fullName() { return `System.Security.AccessControl.AceType`; }
        });
        
        $asm.$str("$ssa.System.Security.AccessControl.AuditFlags", ($self) => class AuditFlags extends $.$spc.System.Enum
        {
            static None = 0;
            static Success = 1;
            static Failure = 2;
            static $map;
            static get Map()
            {
                return this.$map ??= 
                {
                    "None": 0n,
                    "Success": 1n,
                    "Failure": 2n
                };
            }
            static $h = 757831;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static get $eut() { return $.$spc.System.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {"b":1048577,"u":655361,"l":[{"t":757831,"n":"None","d":757831,"h":4295725127,"f":33},{"t":757831,"n":"Success","d":757831,"h":8590692423,"f":33},{"t":757831,"n":"Failure","d":757831,"h":12885659719,"f":33}],"c":[{"n":".ctor","o":"$ctor$3","d":757831,"h":17180627015,"f":1}],"i":[57212929,63766529,57671681,57344001],"h":757831,"a":[{"t":47644673,"c":4342611969}]}; }
            static get $b() { return $.$spc.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IComparable, $.$spc.System.ISpanFormattable, $.$spc.System.IFormattable, $.$spc.System.IConvertible ]; }
            static get $fullName() { return `System.Security.AccessControl.AuditFlags`; }
        });
        
        $asm.$str("$ssa.System.Security.AccessControl.CompoundAceType", ($self) => class CompoundAceType extends $.$spc.System.Enum
        {
            static Impersonation = 1;
            static $map;
            static get Map()
            {
                return this.$map ??= 
                {
                    "Impersonation": 1n
                };
            }
            static $h = 1413191;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static get $eut() { return $.$spc.System.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {"b":1048577,"u":655361,"l":[{"t":1413191,"n":"Impersonation","d":1413191,"h":4296380487,"f":33}],"c":[{"n":".ctor","o":"$ctor$3","d":1413191,"h":8591347783,"f":1}],"i":[57212929,63766529,57671681,57344001],"h":1413191}; }
            static get $b() { return $.$spc.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IComparable, $.$spc.System.ISpanFormattable, $.$spc.System.IFormattable, $.$spc.System.IConvertible ]; }
            static get $fullName() { return `System.Security.AccessControl.CompoundAceType`; }
        });
        
        $asm.$str("$ssa.System.Security.AccessControl.ControlFlags", ($self) => class ControlFlags extends $.$spc.System.Enum
        {
            static None = 0;
            static OwnerDefaulted = 1;
            static GroupDefaulted = 2;
            static DiscretionaryAclPresent = 4;
            static DiscretionaryAclDefaulted = 8;
            static SystemAclPresent = 16;
            static SystemAclDefaulted = 32;
            static DiscretionaryAclUntrusted = 64;
            static ServerSecurity = 128;
            static DiscretionaryAclAutoInheritRequired = 256;
            static SystemAclAutoInheritRequired = 512;
            static DiscretionaryAclAutoInherited = 1024;
            static SystemAclAutoInherited = 2048;
            static DiscretionaryAclProtected = 4096;
            static SystemAclProtected = 8192;
            static RMControlValid = 16384;
            static SelfRelative = 32768;
            static $map;
            static get Map()
            {
                return this.$map ??= 
                {
                    "None": 0n,
                    "OwnerDefaulted": 1n,
                    "GroupDefaulted": 2n,
                    "DiscretionaryAclPresent": 4n,
                    "DiscretionaryAclDefaulted": 8n,
                    "SystemAclPresent": 16n,
                    "SystemAclDefaulted": 32n,
                    "DiscretionaryAclUntrusted": 64n,
                    "ServerSecurity": 128n,
                    "DiscretionaryAclAutoInheritRequired": 256n,
                    "SystemAclAutoInheritRequired": 512n,
                    "DiscretionaryAclAutoInherited": 1024n,
                    "SystemAclAutoInherited": 2048n,
                    "DiscretionaryAclProtected": 4096n,
                    "SystemAclProtected": 8192n,
                    "RMControlValid": 16384n,
                    "SelfRelative": 32768n
                };
            }
            static $h = 1478727;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static get $eut() { return $.$spc.System.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {"b":1048577,"u":655361,"l":[{"t":1478727,"n":"None","d":1478727,"h":4296446023,"f":33},{"t":1478727,"n":"OwnerDefaulted","d":1478727,"h":8591413319,"f":33},{"t":1478727,"n":"GroupDefaulted","d":1478727,"h":12886380615,"f":33},{"t":1478727,"n":"DiscretionaryAclPresent","d":1478727,"h":17181347911,"f":33},{"t":1478727,"n":"DiscretionaryAclDefaulted","d":1478727,"h":21476315207,"f":33},{"t":1478727,"n":"SystemAclPresent","d":1478727,"h":25771282503,"f":33},{"t":1478727,"n":"SystemAclDefaulted","d":1478727,"h":30066249799,"f":33},{"t":1478727,"n":"DiscretionaryAclUntrusted","d":1478727,"h":34361217095,"f":33},{"t":1478727,"n":"ServerSecurity","d":1478727,"h":38656184391,"f":33},{"t":1478727,"n":"DiscretionaryAclAutoInheritRequired","d":1478727,"h":42951151687,"f":33},{"t":1478727,"n":"SystemAclAutoInheritRequired","d":1478727,"h":47246118983,"f":33},{"t":1478727,"n":"DiscretionaryAclAutoInherited","d":1478727,"h":51541086279,"f":33},{"t":1478727,"n":"SystemAclAutoInherited","d":1478727,"h":55836053575,"f":33},{"t":1478727,"n":"DiscretionaryAclProtected","d":1478727,"h":60131020871,"f":33},{"t":1478727,"n":"SystemAclProtected","d":1478727,"h":64425988167,"f":33},{"t":1478727,"n":"RMControlValid","d":1478727,"h":68720955463,"f":33},{"t":1478727,"n":"SelfRelative","d":1478727,"h":73015922759,"f":33}],"c":[{"n":".ctor","o":"$ctor$3","d":1478727,"h":77310890055,"f":1}],"i":[57212929,63766529,57671681,57344001],"h":1478727,"a":[{"t":47644673,"c":4342611969}]}; }
            static get $b() { return $.$spc.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IComparable, $.$spc.System.ISpanFormattable, $.$spc.System.IFormattable, $.$spc.System.IConvertible ]; }
            static get $fullName() { return `System.Security.AccessControl.ControlFlags`; }
        });
        
        $asm.$str("$ssa.System.Security.AccessControl.InheritanceFlags", ($self) => class InheritanceFlags extends $.$spc.System.Enum
        {
            static None = 0;
            static ContainerInherit = 1;
            static ObjectInherit = 2;
            static $map;
            static get Map()
            {
                return this.$map ??= 
                {
                    "None": 0n,
                    "ContainerInherit": 1n,
                    "ObjectInherit": 2n
                };
            }
            static $h = 1871943;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static get $eut() { return $.$spc.System.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {"b":1048577,"u":655361,"l":[{"t":1871943,"n":"None","d":1871943,"h":4296839239,"f":33},{"t":1871943,"n":"ContainerInherit","d":1871943,"h":8591806535,"f":33},{"t":1871943,"n":"ObjectInherit","d":1871943,"h":12886773831,"f":33}],"c":[{"n":".ctor","o":"$ctor$3","d":1871943,"h":17181741127,"f":1}],"i":[57212929,63766529,57671681,57344001],"h":1871943,"a":[{"t":47644673,"c":4342611969}]}; }
            static get $b() { return $.$spc.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IComparable, $.$spc.System.ISpanFormattable, $.$spc.System.IFormattable, $.$spc.System.IConvertible ]; }
            static get $fullName() { return `System.Security.AccessControl.InheritanceFlags`; }
        });
        
        $asm.$str("$ssa.System.Security.AccessControl.ObjectAceFlags", ($self) => class ObjectAceFlags extends $.$spc.System.Enum
        {
            static None = 0;
            static ObjectAceTypePresent = 1;
            static InheritedObjectAceTypePresent = 2;
            static $map;
            static get Map()
            {
                return this.$map ??= 
                {
                    "None": 0n,
                    "ObjectAceTypePresent": 1n,
                    "InheritedObjectAceTypePresent": 2n
                };
            }
            static $h = 2265159;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static get $eut() { return $.$spc.System.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {"b":1048577,"u":655361,"l":[{"t":2265159,"n":"None","d":2265159,"h":4297232455,"f":33},{"t":2265159,"n":"ObjectAceTypePresent","d":2265159,"h":8592199751,"f":33},{"t":2265159,"n":"InheritedObjectAceTypePresent","d":2265159,"h":12887167047,"f":33}],"c":[{"n":".ctor","o":"$ctor$3","d":2265159,"h":17182134343,"f":1}],"i":[57212929,63766529,57671681,57344001],"h":2265159,"a":[{"t":47644673,"c":4342611969}]}; }
            static get $b() { return $.$spc.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IComparable, $.$spc.System.ISpanFormattable, $.$spc.System.IFormattable, $.$spc.System.IConvertible ]; }
            static get $fullName() { return `System.Security.AccessControl.ObjectAceFlags`; }
        });
        
        $asm.$str("$ssa.System.Security.AccessControl.PropagationFlags", ($self) => class PropagationFlags extends $.$spc.System.Enum
        {
            static None = 0;
            static NoPropagateInherit = 1;
            static InheritOnly = 2;
            static $map;
            static get Map()
            {
                return this.$map ??= 
                {
                    "None": 0n,
                    "NoPropagateInherit": 1n,
                    "InheritOnly": 2n
                };
            }
            static $h = 2592839;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static get $eut() { return $.$spc.System.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {"b":1048577,"u":655361,"l":[{"t":2592839,"n":"None","d":2592839,"h":4297560135,"f":33},{"t":2592839,"n":"NoPropagateInherit","d":2592839,"h":8592527431,"f":33},{"t":2592839,"n":"InheritOnly","d":2592839,"h":12887494727,"f":33}],"c":[{"n":".ctor","o":"$ctor$3","d":2592839,"h":17182462023,"f":1}],"i":[57212929,63766529,57671681,57344001],"h":2592839,"a":[{"t":47644673,"c":4342611969}]}; }
            static get $b() { return $.$spc.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IComparable, $.$spc.System.ISpanFormattable, $.$spc.System.IFormattable, $.$spc.System.IConvertible ]; }
            static get $fullName() { return `System.Security.AccessControl.PropagationFlags`; }
        });
        
        $asm.$str("$ssa.System.Security.AccessControl.ResourceType", ($self) => class ResourceType extends $.$spc.System.Enum
        {
            static Unknown = 0;
            static FileObject = 1;
            static Service = 2;
            static Printer = 3;
            static RegistryKey = 4;
            static LMShare = 5;
            static KernelObject = 6;
            static WindowObject = 7;
            static DSObject = 8;
            static DSObjectAll = 9;
            static ProviderDefined = 10;
            static WmiGuidObject = 11;
            static RegistryWow6432Key = 12;
            static $map;
            static get Map()
            {
                return this.$map ??= 
                {
                    "Unknown": 0n,
                    "FileObject": 1n,
                    "Service": 2n,
                    "Printer": 3n,
                    "RegistryKey": 4n,
                    "LMShare": 5n,
                    "KernelObject": 6n,
                    "WindowObject": 7n,
                    "DSObject": 8n,
                    "DSObjectAll": 9n,
                    "ProviderDefined": 10n,
                    "WmiGuidObject": 11n,
                    "RegistryWow6432Key": 12n
                };
            }
            static $h = 2854983;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static get $eut() { return $.$spc.System.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {"b":1048577,"u":655361,"l":[{"t":2854983,"n":"Unknown","d":2854983,"h":4297822279,"f":33},{"t":2854983,"n":"FileObject","d":2854983,"h":8592789575,"f":33},{"t":2854983,"n":"Service","d":2854983,"h":12887756871,"f":33},{"t":2854983,"n":"Printer","d":2854983,"h":17182724167,"f":33},{"t":2854983,"n":"RegistryKey","d":2854983,"h":21477691463,"f":33},{"t":2854983,"n":"LMShare","d":2854983,"h":25772658759,"f":33},{"t":2854983,"n":"KernelObject","d":2854983,"h":30067626055,"f":33},{"t":2854983,"n":"WindowObject","d":2854983,"h":34362593351,"f":33},{"t":2854983,"n":"DSObject","d":2854983,"h":38657560647,"f":33},{"t":2854983,"n":"DSObjectAll","d":2854983,"h":42952527943,"f":33},{"t":2854983,"n":"ProviderDefined","d":2854983,"h":47247495239,"f":33},{"t":2854983,"n":"WmiGuidObject","d":2854983,"h":51542462535,"f":33},{"t":2854983,"n":"RegistryWow6432Key","d":2854983,"h":55837429831,"f":33}],"c":[{"n":".ctor","o":"$ctor$3","d":2854983,"h":60132397127,"f":1}],"i":[57212929,63766529,57671681,57344001],"h":2854983}; }
            static get $b() { return $.$spc.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IComparable, $.$spc.System.ISpanFormattable, $.$spc.System.IFormattable, $.$spc.System.IConvertible ]; }
            static get $fullName() { return `System.Security.AccessControl.ResourceType`; }
        });
        
        $asm.$str("$ssa.System.Security.AccessControl.SecurityInfos", ($self) => class SecurityInfos extends $.$spc.System.Enum
        {
            static Owner = 1;
            static Group = 2;
            static DiscretionaryAcl = 4;
            static SystemAcl = 8;
            static $map;
            static get Map()
            {
                return this.$map ??= 
                {
                    "Owner": 1n,
                    "Group": 2n,
                    "DiscretionaryAcl": 4n,
                    "SystemAcl": 8n
                };
            }
            static $h = 2920519;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static get $eut() { return $.$spc.System.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {"b":1048577,"u":655361,"l":[{"t":2920519,"n":"Owner","d":2920519,"h":4297887815,"f":33},{"t":2920519,"n":"Group","d":2920519,"h":8592855111,"f":33},{"t":2920519,"n":"DiscretionaryAcl","d":2920519,"h":12887822407,"f":33},{"t":2920519,"n":"SystemAcl","d":2920519,"h":17182789703,"f":33}],"c":[{"n":".ctor","o":"$ctor$3","d":2920519,"h":21477756999,"f":1}],"i":[57212929,63766529,57671681,57344001],"h":2920519,"a":[{"t":47644673,"c":4342611969}]}; }
            static get $b() { return $.$spc.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IComparable, $.$spc.System.ISpanFormattable, $.$spc.System.IFormattable, $.$spc.System.IConvertible ]; }
            static get $fullName() { return `System.Security.AccessControl.SecurityInfos`; }
        });
        
        $asm.$cls("$ssa.System.Security.AccessControl.CommonAce", ($self) => class CommonAce extends $.$ssa.System.Security.AccessControl.QualifiedAce
        {
            $ctor$4(/*System.Security.AccessControl.AceFlags*/ flags, /*System.Security.AccessControl.AceQualifier*/ qualifier, /*int*/ accessMask, /*System.Security.Principal.SecurityIdentifier*/ sid, /*bool*/ isCallback, /*byte[]?*/ opaque)
            {
                super.$ctor$3();
                {
                }
                return this;
            }
            /*int */ get BinaryLength()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*void */ GetBinaryForm(/*byte[]*/ binaryForm, /*int*/ offset)
            {
            }
            static /*int */ MaxOpaqueLength(/*bool*/ isCallback)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static $h = 1085511;
            static $f = 0b10010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":2658375,"p":[{"p":655361,"g":{"r":0,"d":0,"h":12885987399,"f":32769},"n":"BinaryLength","d":1085511,"h":8591020103,"f":32769}],"m":[{"r":65537,"p":[{"n":"binaryForm","p":0},{"n":"offset","p":655361}],"n":"GetBinaryForm","d":1085511,"h":17180954695,"f":32769},{"r":655361,"p":[{"n":"isCallback","p":262145}],"n":"MaxOpaqueLength","d":1085511,"h":21475921991,"f":33}],"c":[{"p":[{"n":"flags","p":561223},{"n":"qualifier","p":626759},{"n":"accessMask","p":655361},{"n":"sid","p":435076},{"n":"isCallback","p":262145},{"n":"opaque","p":0}],"n":".ctor","o":"$ctor$4","d":1085511,"h":4296052807,"f":1}],"h":1085511}; }
            static get $b() { return $.$ssa.System.Security.AccessControl.QualifiedAce; }
            static get $fullName() { return `System.Security.AccessControl.CommonAce`; }
        });
        
        $asm.$cls("$ssa.System.Security.AccessControl.ObjectAce", ($self) => class ObjectAce extends $.$ssa.System.Security.AccessControl.QualifiedAce
        {
            $ctor$4(/*System.Security.AccessControl.AceFlags*/ aceFlags, /*System.Security.AccessControl.AceQualifier*/ qualifier, /*int*/ accessMask, /*System.Security.Principal.SecurityIdentifier*/ sid, /*System.Security.AccessControl.ObjectAceFlags*/ flags, /*System.Guid*/ type, /*System.Guid*/ inheritedType, /*bool*/ isCallback, /*byte[]?*/ opaque)
            {
                super.$ctor$3();
                {
                }
                return this;
            }
            /*int */ get BinaryLength()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Guid */ get InheritedObjectAceType()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Guid */ set InheritedObjectAceType(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Security.AccessControl.ObjectAceFlags */ get ObjectAceFlags()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Security.AccessControl.ObjectAceFlags */ set ObjectAceFlags(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Guid */ get ObjectAceType()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Guid */ set ObjectAceType(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*void */ GetBinaryForm(/*byte[]*/ binaryForm, /*int*/ offset)
            {
            }
            static /*int */ MaxOpaqueLength(/*bool*/ isCallback)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static $h = 2199623;
            static $f = 0b10010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":2658375,"p":[{"p":655361,"g":{"r":0,"d":0,"h":12887101511,"f":32769},"n":"BinaryLength","d":2199623,"h":8592134215,"f":32769},{"p":56164353,"g":{"r":0,"d":0,"h":21477036103,"f":1},"s":{"r":0,"d":0,"h":25772003399,"f":1},"n":"InheritedObjectAceType","d":2199623,"h":17182068807,"f":1},{"p":2265159,"g":{"r":0,"d":0,"h":34361937991,"f":1},"s":{"r":0,"d":0,"h":38656905287,"f":1},"n":"ObjectAceFlags","d":2199623,"h":30066970695,"f":1},{"p":56164353,"g":{"r":0,"d":0,"h":47246839879,"f":1},"s":{"r":0,"d":0,"h":51541807175,"f":1},"n":"ObjectAceType","d":2199623,"h":42951872583,"f":1}],"m":[{"r":65537,"p":[{"n":"binaryForm","p":0},{"n":"offset","p":655361}],"n":"GetBinaryForm","d":2199623,"h":55836774471,"f":32769},{"r":655361,"p":[{"n":"isCallback","p":262145}],"n":"MaxOpaqueLength","d":2199623,"h":60131741767,"f":33}],"c":[{"p":[{"n":"aceFlags","p":561223},{"n":"qualifier","p":626759},{"n":"accessMask","p":655361},{"n":"sid","p":435076},{"n":"flags","p":2265159},{"n":"type","p":56164353},{"n":"inheritedType","p":56164353},{"n":"isCallback","p":262145},{"n":"opaque","p":0}],"n":".ctor","o":"$ctor$4","d":2199623,"h":4297166919,"f":1}],"h":2199623}; }
            static get $b() { return $.$ssa.System.Security.AccessControl.QualifiedAce; }
            static get $fullName() { return `System.Security.AccessControl.ObjectAce`; }
        });
        
        $asm.$cls("$ssa.System.Security.AccessControl.PrivilegeNotHeldException", ($self) => class PrivilegeNotHeldException extends $.$spc.System.UnauthorizedAccessException
        {
            $ctor$13()
            {
                super.$ctor$9();
                {
                }
                return this;
            }
            $ctor$14(/*string?*/ privilege)
            {
                super.$ctor$9();
                {
                }
                return this;
            }
            $ctor$15(/*string?*/ privilege, /*System.Exception?*/ inner)
            {
                super.$ctor$9();
                {
                }
                return this;
            }
            /*string? */ get PrivilegeName()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*void */ GetObjectData(/*System.Runtime.Serialization.SerializationInfo*/ info, /*System.Runtime.Serialization.StreamingContext*/ context)
            {
            }
            static $h = 2527303;
            static $f = 0b10010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":143851521,"h":2527303}; }
            static get $b() { return $.$spc.System.UnauthorizedAccessException; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.Runtime.Serialization.ISerializable ]; }
            static get $fullName() { return `System.Security.AccessControl.PrivilegeNotHeldException`; }
        });
	});
})(window, window.NetJs.$boot(), ...window.NetJs.$require("NetJs.System.Private.CoreLib", "NetJs.Microsoft.Win32.Primitives", "NetJs.System.Collections", "NetJs.System.Diagnostics.Tracing", "NetJs.System.Memory", "NetJs.System.Private.Uri", "NetJs.System.Threading", "NetJs.System.Threading.Thread", "NetJs.System.Runtime", "NetJs.System.Collections.Concurrent", "NetJs.System.Collections.NonGeneric", "NetJs.System.Security.Claims", "NetJs.System.Runtime.InteropServices", "NetJs.System.Security.Principal.Windows"))