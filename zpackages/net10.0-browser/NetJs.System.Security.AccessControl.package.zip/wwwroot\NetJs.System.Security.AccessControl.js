
(function ($global, $, $spc, $mwp, $sc, $sdt, $sm, $spu, $st, $stt, $sr, $scc, $scn, $ssc, $sris, $sspw) {
    "use strict";
    let _;
    
    
    
	$.$asm(
    "NetJs.System.Security.AccessControl", 
    {"h":55639,"f":"System.Security.AccessControl","v":"1.0.35.0","a":[{"t":115146753,"c":13000048641,"a":[{"v":".NETCoreApp,Version=v10.0","t":1310721}],"n":[{"n":"FrameworkDisplayName","v":".NET 10.0","t":1310721}]},{"t":73596929,"c":4368564225,"a":[{"v":"SIT","t":1310721}]},{"t":73662465,"c":4368629761,"a":[{"v":"Debug","t":1310721}]},{"t":74121217,"c":4369088513,"a":[{"v":"1.0.35.0","t":1310721}]},{"t":74252289,"c":4369219585,"a":[{"v":"1.0.35\u002B5b8aaafb3aebad7fc7141c6e509af03c92d8b793","t":1310721}]},{"t":75104257,"c":4370071553,"a":[{"v":"NetJs.System.Security.AccessControl","t":1310721}]},{"t":75235329,"c":4370202625,"a":[{"v":"NetJs.System.Security.AccessControl","t":1310721}]},{"t":75366401,"c":4370333697,"a":[{"v":"1.0.35.0","t":1310721}]},{"t":115212289,"c":4410179585,"a":[{"v":"browser1.0","t":1310721}]},{"t":114950145,"c":4409917441,"a":[{"v":"browser1.0","t":1310721}]}],"m":[]},
    function($asm)
	{
        
        
        $asm.$cls("$ssa.System.Security.AccessControl.AuthorizationRule", ($self) => class AuthorizationRule extends $.$spc.System.Object
        {
            $ctor$1(/*System.Security.Principal.IdentityReference*/ identity, /*int*/ accessMask, /*bool*/ isInherited, /*System.Security.AccessControl.InheritanceFlags*/ inheritanceFlags, /*System.Security.AccessControl.PropagationFlags*/ propagationFlags)
            {
                super.$ctor();
                {
                }
                return this;
            }
            /*int */ get AccessMask()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Security.Principal.IdentityReference */ get IdentityReference()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Security.AccessControl.InheritanceFlags */ get InheritanceFlags()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get IsInherited()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Security.AccessControl.PropagationFlags */ get PropagationFlags()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static $h = 973143;
            static $f = 0b110001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":655361,"g":{"r":0,"d":0,"h":12885875031,"f":16},"n":"AccessMask","d":973143,"h":8590907735,"f":16},{"p":247007,"g":{"r":0,"d":0,"h":21475809623,"f":1},"n":"IdentityReference","d":973143,"h":17180842327,"f":1},{"p":1890647,"g":{"r":0,"d":0,"h":30065744215,"f":1},"n":"InheritanceFlags","d":973143,"h":25770776919,"f":1},{"p":262145,"g":{"r":0,"d":0,"h":38655678807,"f":1},"n":"IsInherited","d":973143,"h":34360711511,"f":1},{"p":2611543,"g":{"r":0,"d":0,"h":47245613399,"f":1},"n":"PropagationFlags","d":973143,"h":42950646103,"f":1}],"c":[{"p":[{"n":"identity","p":247007},{"n":"accessMask","p":655361},{"n":"isInherited","p":262145},{"n":"inheritanceFlags","p":1890647},{"n":"propagationFlags","p":2611543}],"n":".ctor","o":"$ctor$1","d":973143,"h":4295940439,"f":16}],"h":973143}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.Security.AccessControl.AuthorizationRule`; }
        });
        
        $asm.$cls("$ssa.System.Security.AccessControl.GenericAce", ($self) => class GenericAce extends $.$spc.System.Object
        {
            $ctor$1()
            {
                super.$ctor();
                {
                }
                return this;
            }
            /*System.Security.AccessControl.AceFlags */ get AceFlags()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Security.AccessControl.AceFlags */ set AceFlags(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Security.AccessControl.AceType */ get AceType()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Security.AccessControl.AuditFlags */ get AuditFlags()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Security.AccessControl.InheritanceFlags */ get InheritanceFlags()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get IsInherited()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Security.AccessControl.PropagationFlags */ get PropagationFlags()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Security.AccessControl.GenericAce */ Copy()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static /*System.Security.AccessControl.GenericAce */ CreateFromBinaryForm(/*byte[]*/ binaryForm, /*int*/ offset)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static/*conventional*/ /*bool */ Equals(/*object?*/ o)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            //Static convention instance redirect
            /*bool */ Equals() { return $.$ssa.System.Security.AccessControl.GenericAce.Equals.apply(this, arguments); }
            static/*conventional*/ /*int */ GetHashCode()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            //Static convention instance redirect
            /*int */ GetHashCode() { return $.$ssa.System.Security.AccessControl.GenericAce.GetHashCode.apply(this, arguments); }
            static /*bool */ op_Equality(/*System.Security.AccessControl.GenericAce?*/ left, /*System.Security.AccessControl.GenericAce?*/ right)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static /*bool */ op_Inequality(/*System.Security.AccessControl.GenericAce?*/ left, /*System.Security.AccessControl.GenericAce?*/ right)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static $h = 1694039;
            static $f = 0b110001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":579927,"g":{"r":0,"d":0,"h":12886595927,"f":1},"s":{"r":0,"d":0,"h":17181563223,"f":1},"n":"AceFlags","d":1694039,"h":8591628631,"f":1},{"p":710999,"g":{"r":0,"d":0,"h":25771497815,"f":1},"n":"AceType","d":1694039,"h":21476530519,"f":1},{"p":776535,"g":{"r":0,"d":0,"h":34361432407,"f":1},"n":"AuditFlags","d":1694039,"h":30066465111,"f":1},{"p":655361,"g":{"r":0,"d":0,"h":42951366999,"f":257},"n":"BinaryLength","d":1694039,"h":38656399703,"f":257},{"p":1890647,"g":{"r":0,"d":0,"h":51541301591,"f":1},"n":"InheritanceFlags","d":1694039,"h":47246334295,"f":1},{"p":262145,"g":{"r":0,"d":0,"h":60131236183,"f":1},"n":"IsInherited","d":1694039,"h":55836268887,"f":1},{"p":2611543,"g":{"r":0,"d":0,"h":68721170775,"f":1},"n":"PropagationFlags","d":1694039,"h":64426203479,"f":1}],"m":[{"r":1694039,"n":"Copy","d":1694039,"h":73016138071,"f":1},{"r":1694039,"p":[{"n":"binaryForm","p":0},{"n":"offset","p":655361}],"n":"CreateFromBinaryForm","d":1694039,"h":77311105367,"f":33},{"r":262145,"p":[{"n":"o","p":131073}],"n":"Equals","d":1694039,"h":81606072663,"f":98305},{"r":65537,"p":[{"n":"binaryForm","p":0},{"n":"offset","p":655361}],"n":"GetBinaryForm","d":1694039,"h":85901039959,"f":257},{"r":655361,"n":"GetHashCode","d":1694039,"h":90196007255,"f":98305}],"c":[{"n":".ctor","o":"$ctor$1","d":1694039,"h":4296661335,"f":8}],"h":1694039}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.Security.AccessControl.GenericAce`; }
        });
        
        $asm.$cls("$ssa.System.Security.AccessControl.GenericSecurityDescriptor", ($self) => class GenericSecurityDescriptor extends $.$spc.System.Object
        {
            $ctor$1()
            {
                super.$ctor();
                {
                }
                return this;
            }
            /*int */ get BinaryLength()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static /*byte */ get Revision()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*void */ GetBinaryForm(/*byte[]*/ binaryForm, /*int*/ offset)
            {
            }
            /*string */ GetSddlForm(/*System.Security.AccessControl.AccessControlSections*/ includeSections)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static /*bool */ IsSddlConversionSupported()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static $h = 1825111;
            static $f = 0b110001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":655361,"g":{"r":0,"d":0,"h":12886726999,"f":1},"n":"BinaryLength","d":1825111,"h":8591759703,"f":1},{"p":1497431,"g":{"r":0,"d":0,"h":21476661591,"f":257},"n":"ControlFlags","d":1825111,"h":17181694295,"f":257},{"p":443615,"g":{"r":0,"d":0,"h":30066596183,"f":257},"s":{"r":0,"d":0,"h":34361563479,"f":257},"n":"Group","d":1825111,"h":25771628887,"f":257},{"p":443615,"g":{"r":0,"d":0,"h":42951498071,"f":257},"s":{"r":0,"d":0,"h":47246465367,"f":257},"n":"Owner","d":1825111,"h":38656530775,"f":257},{"p":393217,"g":{"r":0,"d":0,"h":55836399959,"f":33},"n":"Revision","d":1825111,"h":51541432663,"f":33}],"m":[{"r":65537,"p":[{"n":"binaryForm","p":0},{"n":"offset","p":655361}],"n":"GetBinaryForm","d":1825111,"h":60131367255,"f":1},{"r":1310721,"p":[{"n":"includeSections","p":252247}],"n":"GetSddlForm","d":1825111,"h":64426334551,"f":1},{"r":262145,"n":"IsSddlConversionSupported","d":1825111,"h":68721301847,"f":33}],"c":[{"n":".ctor","o":"$ctor$1","d":1825111,"h":4296792407,"f":8}],"h":1825111}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.Security.AccessControl.GenericSecurityDescriptor`; }
        });
        
        $asm.$cls("$ssa.System.Security.AccessControl.ObjectSecurity", ($self) => class ObjectSecurity extends $.$spc.System.Object
        {
            $ctor$1()
            {
                super.$ctor();
                {
                }
                return this;
            }
            $ctor$2(/*bool*/ isContainer, /*bool*/ isDS)
            {
                super.$ctor();
                {
                }
                return this;
            }
            $ctor$3(/*System.Security.AccessControl.CommonSecurityDescriptor*/ securityDescriptor)
            {
                super.$ctor();
                {
                }
                return this;
            }
            /*bool */ get AccessRulesModified()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ set AccessRulesModified(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get AreAccessRulesCanonical()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get AreAccessRulesProtected()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get AreAuditRulesCanonical()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get AreAuditRulesProtected()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get AuditRulesModified()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ set AuditRulesModified(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get GroupModified()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ set GroupModified(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get IsContainer()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get IsDS()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get OwnerModified()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ set OwnerModified(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Security.AccessControl.CommonSecurityDescriptor */ get SecurityDescriptor()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Security.Principal.IdentityReference? */ GetGroup(/*System.Type*/ targetType)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Security.Principal.IdentityReference? */ GetOwner(/*System.Type*/ targetType)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*byte[] */ GetSecurityDescriptorBinaryForm()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*string */ GetSecurityDescriptorSddlForm(/*System.Security.AccessControl.AccessControlSections*/ includeSections)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static /*bool */ IsSddlConversionSupported()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ ModifyAccessRule(/*System.Security.AccessControl.AccessControlModification*/ modification, /*System.Security.AccessControl.AccessRule*/ rule, /*out bool*/ modified)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ ModifyAuditRule(/*System.Security.AccessControl.AccessControlModification*/ modification, /*System.Security.AccessControl.AuditRule*/ rule, /*out bool*/ modified)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*void */ Persist(/*bool*/ enableOwnershipPrivilege, /*string*/ name, /*System.Security.AccessControl.AccessControlSections*/ includeSections)
            {
            }
            /*void */ Persist$1(/*System.Runtime.InteropServices.SafeHandle*/ handle, /*System.Security.AccessControl.AccessControlSections*/ includeSections)
            {
            }
            /*void */ Persist$2(/*string*/ name, /*System.Security.AccessControl.AccessControlSections*/ includeSections)
            {
            }
            /*void */ PurgeAccessRules(/*System.Security.Principal.IdentityReference*/ identity)
            {
            }
            /*void */ PurgeAuditRules(/*System.Security.Principal.IdentityReference*/ identity)
            {
            }
            /*void */ ReadLock()
            {
            }
            /*void */ ReadUnlock()
            {
            }
            /*void */ SetAccessRuleProtection(/*bool*/ isProtected, /*bool*/ preserveInheritance)
            {
            }
            /*void */ SetAuditRuleProtection(/*bool*/ isProtected, /*bool*/ preserveInheritance)
            {
            }
            /*void */ SetGroup(/*System.Security.Principal.IdentityReference*/ identity)
            {
            }
            /*void */ SetOwner(/*System.Security.Principal.IdentityReference*/ identity)
            {
            }
            /*void */ SetSecurityDescriptorBinaryForm(/*byte[]*/ binaryForm)
            {
            }
            /*void */ SetSecurityDescriptorBinaryForm$1(/*byte[]*/ binaryForm, /*System.Security.AccessControl.AccessControlSections*/ includeSections)
            {
            }
            /*void */ SetSecurityDescriptorSddlForm(/*string*/ sddlForm)
            {
            }
            /*void */ SetSecurityDescriptorSddlForm$1(/*string*/ sddlForm, /*System.Security.AccessControl.AccessControlSections*/ includeSections)
            {
            }
            /*void */ WriteLock()
            {
            }
            /*void */ WriteUnlock()
            {
            }
            static $h = 2414935;
            static $f = 0b110001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":142606337,"g":{"r":0,"d":0,"h":21477251415,"f":257},"n":"AccessRightType","d":2414935,"h":17182284119,"f":257},{"p":262145,"g":{"r":0,"d":0,"h":30067186007,"f":4},"s":{"r":0,"d":0,"h":34362153303,"f":4},"n":"AccessRulesModified","d":2414935,"h":25772218711,"f":4},{"p":142606337,"g":{"r":0,"d":0,"h":42952087895,"f":257},"n":"AccessRuleType","d":2414935,"h":38657120599,"f":257},{"p":262145,"g":{"r":0,"d":0,"h":51542022487,"f":1},"n":"AreAccessRulesCanonical","d":2414935,"h":47247055191,"f":1},{"p":262145,"g":{"r":0,"d":0,"h":60131957079,"f":1},"n":"AreAccessRulesProtected","d":2414935,"h":55836989783,"f":1},{"p":262145,"g":{"r":0,"d":0,"h":68721891671,"f":1},"n":"AreAuditRulesCanonical","d":2414935,"h":64426924375,"f":1},{"p":262145,"g":{"r":0,"d":0,"h":77311826263,"f":1},"n":"AreAuditRulesProtected","d":2414935,"h":73016858967,"f":1},{"p":262145,"g":{"r":0,"d":0,"h":85901760855,"f":4},"s":{"r":0,"d":0,"h":90196728151,"f":4},"n":"AuditRulesModified","d":2414935,"h":81606793559,"f":4},{"p":142606337,"g":{"r":0,"d":0,"h":98786662743,"f":257},"n":"AuditRuleType","d":2414935,"h":94491695447,"f":257},{"p":262145,"g":{"r":0,"d":0,"h":107376597335,"f":4},"s":{"r":0,"d":0,"h":111671564631,"f":4},"n":"GroupModified","d":2414935,"h":103081630039,"f":4},{"p":262145,"g":{"r":0,"d":0,"h":120261499223,"f":4},"n":"IsContainer","d":2414935,"h":115966531927,"f":4},{"p":262145,"g":{"r":0,"d":0,"h":128851433815,"f":4},"n":"IsDS","d":2414935,"h":124556466519,"f":4},{"p":262145,"g":{"r":0,"d":0,"h":137441368407,"f":4},"s":{"r":0,"d":0,"h":141736335703,"f":4},"n":"OwnerModified","d":2414935,"h":133146401111,"f":4},{"p":1300823,"g":{"r":0,"d":0,"h":150326270295,"f":4},"n":"SecurityDescriptor","d":2414935,"h":146031302999,"f":4}],"m":[{"r":383319,"p":[{"n":"identityReference","p":247007},{"n":"accessMask","p":655361},{"n":"isInherited","p":262145},{"n":"inheritanceFlags","p":1890647},{"n":"propagationFlags","p":2611543},{"n":"type","p":317783}],"n":"AccessRuleFactory","d":2414935,"h":154621237591,"f":257},{"r":842071,"p":[{"n":"identityReference","p":247007},{"n":"accessMask","p":655361},{"n":"isInherited","p":262145},{"n":"inheritanceFlags","p":1890647},{"n":"propagationFlags","p":2611543},{"n":"flags","p":776535}],"n":"AuditRuleFactory","d":2414935,"h":158916204887,"f":257},{"r":247007,"p":[{"n":"targetType","p":142606337}],"n":"GetGroup","d":2414935,"h":163211172183,"f":1},{"r":247007,"p":[{"n":"targetType","p":142606337}],"n":"GetOwner","d":2414935,"h":167506139479,"f":1},{"r":0,"n":"GetSecurityDescriptorBinaryForm","d":2414935,"h":171801106775,"f":1},{"r":1310721,"p":[{"n":"includeSections","p":252247}],"n":"GetSecurityDescriptorSddlForm","d":2414935,"h":176096074071,"f":1},{"r":262145,"n":"IsSddlConversionSupported","d":2414935,"h":180391041367,"f":33},{"r":262145,"p":[{"n":"modification","p":186711},{"n":"rule","p":383319},{"n":"modified","p":262145,"f":2}],"n":"ModifyAccess","d":2414935,"h":184686008663,"f":260},{"r":262145,"p":[{"n":"modification","p":186711},{"n":"rule","p":383319},{"n":"modified","p":262145,"f":2}],"n":"ModifyAccessRule","d":2414935,"h":188980975959,"f":129},{"r":262145,"p":[{"n":"modification","p":186711},{"n":"rule","p":842071},{"n":"modified","p":262145,"f":2}],"n":"ModifyAudit","d":2414935,"h":193275943255,"f":260},{"r":262145,"p":[{"n":"modification","p":186711},{"n":"rule","p":842071},{"n":"modified","p":262145,"f":2}],"n":"ModifyAuditRule","d":2414935,"h":197570910551,"f":129},{"r":65537,"p":[{"n":"enableOwnershipPrivilege","p":262145},{"n":"name","p":1310721},{"n":"includeSections","p":252247}],"n":"Persist","d":2414935,"h":201865877847,"f":132},{"r":65537,"p":[{"n":"handle","p":109576193},{"n":"includeSections","p":252247}],"n":"Persist","o":"@$1","d":2414935,"h":206160845143,"f":132},{"r":65537,"p":[{"n":"name","p":1310721},{"n":"includeSections","p":252247}],"n":"Persist","o":"@$2","d":2414935,"h":210455812439,"f":132},{"r":65537,"p":[{"n":"identity","p":247007}],"n":"PurgeAccessRules","d":2414935,"h":214750779735,"f":129},{"r":65537,"p":[{"n":"identity","p":247007}],"n":"PurgeAuditRules","d":2414935,"h":219045747031,"f":129},{"r":65537,"n":"ReadLock","d":2414935,"h":223340714327,"f":4},{"r":65537,"n":"ReadUnlock","d":2414935,"h":227635681623,"f":4},{"r":65537,"p":[{"n":"isProtected","p":262145},{"n":"preserveInheritance","p":262145}],"n":"SetAccessRuleProtection","d":2414935,"h":231930648919,"f":1},{"r":65537,"p":[{"n":"isProtected","p":262145},{"n":"preserveInheritance","p":262145}],"n":"SetAuditRuleProtection","d":2414935,"h":236225616215,"f":1},{"r":65537,"p":[{"n":"identity","p":247007}],"n":"SetGroup","d":2414935,"h":240520583511,"f":1},{"r":65537,"p":[{"n":"identity","p":247007}],"n":"SetOwner","d":2414935,"h":244815550807,"f":1},{"r":65537,"p":[{"n":"binaryForm","p":0}],"n":"SetSecurityDescriptorBinaryForm","d":2414935,"h":249110518103,"f":1},{"r":65537,"p":[{"n":"binaryForm","p":0},{"n":"includeSections","p":252247}],"n":"SetSecurityDescriptorBinaryForm","o":"@$1","d":2414935,"h":253405485399,"f":1},{"r":65537,"p":[{"n":"sddlForm","p":1310721}],"n":"SetSecurityDescriptorSddlForm","d":2414935,"h":257700452695,"f":1},{"r":65537,"p":[{"n":"sddlForm","p":1310721},{"n":"includeSections","p":252247}],"n":"SetSecurityDescriptorSddlForm","o":"@$1","d":2414935,"h":261995419991,"f":1},{"r":65537,"n":"WriteLock","d":2414935,"h":266290387287,"f":4},{"r":65537,"n":"WriteUnlock","d":2414935,"h":270585354583,"f":4}],"c":[{"n":".ctor","o":"$ctor$1","d":2414935,"h":4297382231,"f":4},{"p":[{"n":"isContainer","p":262145},{"n":"isDS","p":262145}],"n":".ctor","o":"$ctor$2","d":2414935,"h":8592349527,"f":4},{"p":[{"n":"securityDescriptor","p":1300823}],"n":".ctor","o":"$ctor$3","d":2414935,"h":12887316823,"f":4}],"h":2414935}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.Security.AccessControl.ObjectSecurity`; }
        });
        
        $asm.$cls("$ssa.System.Security.Policy.EvidenceBase", ($self) => class EvidenceBase extends $.$spc.System.Object
        {
            $ctor$1()
            {
                super.$ctor();
                {
                }
                return this;
            }
            /*System.Security.Policy.EvidenceBase? */ Clone()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static $h = 3135831;
            static $f = 0b110001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"m":[{"r":3135831,"n":"Clone","d":3135831,"h":8593070423,"f":129}],"c":[{"n":".ctor","o":"$ctor$1","d":3135831,"h":4298103127,"f":4}],"h":3135831}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.Security.Policy.EvidenceBase`; }
        });
        
        $asm.$cls("$ssa.System.Security.AccessControl.GenericAcl", ($self) => class GenericAcl extends $.$spc.System.Object
        {
            /*byte*/ static AclRevision = 0;
            /*byte*/ static AclRevisionDS = 0;
            /*int*/ static MaxBinaryLength = 0;
            $ctor$1()
            {
                super.$ctor();
                {
                }
                return this;
            }
            /*bool */ get IsSynchronized()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*object */ get SyncRoot()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*void */ CopyTo(/*System.Security.AccessControl.GenericAce[]*/ array, /*int*/ index)
            {
            }
            /*System.Security.AccessControl.AceEnumerator */ GetEnumerator()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*void */ System$Collections$ICollection$CopyTo(/*System.Array*/ array, /*int*/ index)
            {
            }
            /*System.Collections.IEnumerator */ System$Collections$IEnumerable$GetEnumerator()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            //Generated interface implemetation for System.Collections.ICollection.Count.get
            get System$Collections$ICollection$Count()
            {
                return this.Count;
            }
            //Generated interface implemetation for System.Collections.ICollection.SyncRoot.get
            get System$Collections$ICollection$SyncRoot()
            {
                return this.SyncRoot;
            }
            //Generated interface implemetation for System.Collections.ICollection.IsSynchronized.get
            get System$Collections$ICollection$IsSynchronized()
            {
                return this.IsSynchronized;
            }
            static $h = 1759575;
            static $f = 0b110001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":655361,"g":{"r":0,"d":0,"h":25771563351,"f":257},"n":"BinaryLength","d":1759575,"h":21476596055,"f":257},{"p":655361,"g":{"r":0,"d":0,"h":34361497943,"f":257},"n":"Count","d":1759575,"h":30066530647,"f":257},{"p":262145,"g":{"r":0,"d":0,"h":42951432535,"f":1},"n":"IsSynchronized","d":1759575,"h":38656465239,"f":1},{"p":1694039,"i":[{"n":"index","p":655361}],"g":{"r":0,"d":0,"h":51541367127,"f":257},"s":{"r":0,"d":0,"h":55836334423,"f":257},"n":"Item","o":"@$2","d":1759575,"h":47246399831,"f":257},{"p":393217,"g":{"r":0,"d":0,"h":64426269015,"f":257},"n":"Revision","d":1759575,"h":60131301719,"f":257},{"p":131073,"g":{"r":0,"d":0,"h":73016203607,"f":129},"n":"SyncRoot","d":1759575,"h":68721236311,"f":129}],"m":[{"r":65537,"p":[{"n":"array","p":0},{"n":"index","p":655361}],"n":"CopyTo","d":1759575,"h":77311170903,"f":1},{"r":65537,"p":[{"n":"binaryForm","p":0},{"n":"offset","p":655361}],"n":"GetBinaryForm","d":1759575,"h":81606138199,"f":257},{"r":514391,"n":"GetEnumerator","d":1759575,"h":85901105495,"f":1}],"l":[{"t":393217,"n":"AclRevision","d":1759575,"h":4296726871,"f":33},{"t":393217,"n":"AclRevisionDS","d":1759575,"h":8591694167,"f":33},{"t":655361,"n":"MaxBinaryLength","d":1759575,"h":12886661463,"f":33}],"c":[{"n":".ctor","o":"$ctor$1","d":1759575,"h":17181628759,"f":4}],"i":[31326209,31588353],"h":1759575}; }
            static get $b() { return $.$spc.System.Object; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.Collections.ICollection, $.$spc.System.Collections.IEnumerable ]; }
            static get $fullName() { return `System.Security.AccessControl.GenericAcl`; }
        });
        
        $asm.$cls("$ssa.System.Security.AccessControl.AccessRule", ($self) => class AccessRule extends $.$ssa.System.Security.AccessControl.AuthorizationRule
        {
            $ctor$2(/*System.Security.Principal.IdentityReference*/ identity, /*int*/ accessMask, /*bool*/ isInherited, /*System.Security.AccessControl.InheritanceFlags*/ inheritanceFlags, /*System.Security.AccessControl.PropagationFlags*/ propagationFlags, /*System.Security.AccessControl.AccessControlType*/ type)
            {
                super.$ctor$1(null, 0, false, 0, 0);
                {
                }
                return this;
            }
            /*System.Security.AccessControl.AccessControlType */ get AccessControlType()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static $h = 383319;
            static $f = 0b110001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":973143,"p":[{"p":317783,"g":{"r":0,"d":0,"h":12885285207,"f":1},"n":"AccessControlType","d":383319,"h":8590317911,"f":1}],"c":[{"p":[{"n":"identity","p":247007},{"n":"accessMask","p":655361},{"n":"isInherited","p":262145},{"n":"inheritanceFlags","p":1890647},{"n":"propagationFlags","p":2611543},{"n":"type","p":317783}],"n":".ctor","o":"$ctor$2","d":383319,"h":4295350615,"f":4}],"h":383319}; }
            static get $b() { return $.$ssa.System.Security.AccessControl.AuthorizationRule; }
            static get $fullName() { return `System.Security.AccessControl.AccessRule`; }
        });
        
        $asm.$cls("$ssa.System.Security.AccessControl.AuditRule", ($self) => class AuditRule extends $.$ssa.System.Security.AccessControl.AuthorizationRule
        {
            $ctor$2(/*System.Security.Principal.IdentityReference*/ identity, /*int*/ accessMask, /*bool*/ isInherited, /*System.Security.AccessControl.InheritanceFlags*/ inheritanceFlags, /*System.Security.AccessControl.PropagationFlags*/ propagationFlags, /*System.Security.AccessControl.AuditFlags*/ auditFlags)
            {
                super.$ctor$1(null, 0, false, 0, 0);
                {
                }
                return this;
            }
            /*System.Security.AccessControl.AuditFlags */ get AuditFlags()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static $h = 842071;
            static $f = 0b110001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":973143,"p":[{"p":776535,"g":{"r":0,"d":0,"h":12885743959,"f":1},"n":"AuditFlags","d":842071,"h":8590776663,"f":1}],"c":[{"p":[{"n":"identity","p":247007},{"n":"accessMask","p":655361},{"n":"isInherited","p":262145},{"n":"inheritanceFlags","p":1890647},{"n":"propagationFlags","p":2611543},{"n":"auditFlags","p":776535}],"n":".ctor","o":"$ctor$2","d":842071,"h":4295809367,"f":4}],"h":842071}; }
            static get $b() { return $.$ssa.System.Security.AccessControl.AuthorizationRule; }
            static get $fullName() { return `System.Security.AccessControl.AuditRule`; }
        });
        
        $asm.$cls("$ssa.System.Security.AccessControl.CommonObjectSecurity", ($self) => class CommonObjectSecurity extends $.$ssa.System.Security.AccessControl.ObjectSecurity
        {
            $ctor$4(/*bool*/ isContainer)
            {
                super.$ctor$1();
                {
                }
                return this;
            }
            /*void */ AddAccessRule(/*System.Security.AccessControl.AccessRule*/ rule)
            {
            }
            /*void */ AddAuditRule(/*System.Security.AccessControl.AuditRule*/ rule)
            {
            }
            /*System.Security.AccessControl.AuthorizationRuleCollection */ GetAccessRules(/*bool*/ includeExplicit, /*bool*/ includeInherited, /*System.Type*/ targetType)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Security.AccessControl.AuthorizationRuleCollection */ GetAuditRules(/*bool*/ includeExplicit, /*bool*/ includeInherited, /*System.Type*/ targetType)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ ModifyAccess(/*System.Security.AccessControl.AccessControlModification*/ modification, /*System.Security.AccessControl.AccessRule*/ rule, /*out bool*/ modified)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ ModifyAudit(/*System.Security.AccessControl.AccessControlModification*/ modification, /*System.Security.AccessControl.AuditRule*/ rule, /*out bool*/ modified)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ RemoveAccessRule(/*System.Security.AccessControl.AccessRule*/ rule)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*void */ RemoveAccessRuleAll(/*System.Security.AccessControl.AccessRule*/ rule)
            {
            }
            /*void */ RemoveAccessRuleSpecific(/*System.Security.AccessControl.AccessRule*/ rule)
            {
            }
            /*bool */ RemoveAuditRule(/*System.Security.AccessControl.AuditRule*/ rule)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*void */ RemoveAuditRuleAll(/*System.Security.AccessControl.AuditRule*/ rule)
            {
            }
            /*void */ RemoveAuditRuleSpecific(/*System.Security.AccessControl.AuditRule*/ rule)
            {
            }
            /*void */ ResetAccessRule(/*System.Security.AccessControl.AccessRule*/ rule)
            {
            }
            /*void */ SetAccessRule(/*System.Security.AccessControl.AccessRule*/ rule)
            {
            }
            /*void */ SetAuditRule(/*System.Security.AccessControl.AuditRule*/ rule)
            {
            }
            static $h = 1235287;
            static $f = 0b110001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":2414935,"m":[{"r":65537,"p":[{"n":"rule","p":383319}],"n":"AddAccessRule","d":1235287,"h":8591169879,"f":4},{"r":65537,"p":[{"n":"rule","p":842071}],"n":"AddAuditRule","d":1235287,"h":12886137175,"f":4},{"r":1038679,"p":[{"n":"includeExplicit","p":262145},{"n":"includeInherited","p":262145},{"n":"targetType","p":142606337}],"n":"GetAccessRules","d":1235287,"h":17181104471,"f":1},{"r":1038679,"p":[{"n":"includeExplicit","p":262145},{"n":"includeInherited","p":262145},{"n":"targetType","p":142606337}],"n":"GetAuditRules","d":1235287,"h":21476071767,"f":1},{"r":262145,"p":[{"n":"modification","p":186711},{"n":"rule","p":383319},{"n":"modified","p":262145,"f":2}],"n":"ModifyAccess","d":1235287,"h":25771039063,"f":32772},{"r":262145,"p":[{"n":"modification","p":186711},{"n":"rule","p":842071},{"n":"modified","p":262145,"f":2}],"n":"ModifyAudit","d":1235287,"h":30066006359,"f":32772},{"r":262145,"p":[{"n":"rule","p":383319}],"n":"RemoveAccessRule","d":1235287,"h":34360973655,"f":4},{"r":65537,"p":[{"n":"rule","p":383319}],"n":"RemoveAccessRuleAll","d":1235287,"h":38655940951,"f":4},{"r":65537,"p":[{"n":"rule","p":383319}],"n":"RemoveAccessRuleSpecific","d":1235287,"h":42950908247,"f":4},{"r":262145,"p":[{"n":"rule","p":842071}],"n":"RemoveAuditRule","d":1235287,"h":47245875543,"f":4},{"r":65537,"p":[{"n":"rule","p":842071}],"n":"RemoveAuditRuleAll","d":1235287,"h":51540842839,"f":4},{"r":65537,"p":[{"n":"rule","p":842071}],"n":"RemoveAuditRuleSpecific","d":1235287,"h":55835810135,"f":4},{"r":65537,"p":[{"n":"rule","p":383319}],"n":"ResetAccessRule","d":1235287,"h":60130777431,"f":4},{"r":65537,"p":[{"n":"rule","p":383319}],"n":"SetAccessRule","d":1235287,"h":64425744727,"f":4},{"r":65537,"p":[{"n":"rule","p":842071}],"n":"SetAuditRule","d":1235287,"h":68720712023,"f":4}],"c":[{"p":[{"n":"isContainer","p":262145}],"n":".ctor","o":"$ctor$4","d":1235287,"h":4296202583,"f":4}],"h":1235287}; }
            static get $b() { return $.$ssa.System.Security.AccessControl.ObjectSecurity; }
            static get $fullName() { return `System.Security.AccessControl.CommonObjectSecurity`; }
        });
        
        $asm.$cls("$ssa.System.Security.AccessControl.KnownAce", ($self) => class KnownAce extends $.$ssa.System.Security.AccessControl.GenericAce
        {
            $ctor$2()
            {
                super.$ctor$1();
                {
                }
                return this;
            }
            /*int */ get AccessMask()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ set AccessMask(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Security.Principal.SecurityIdentifier */ get SecurityIdentifier()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Security.Principal.SecurityIdentifier */ set SecurityIdentifier(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static $h = 1956183;
            static $f = 0b110001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":1694039,"p":[{"p":655361,"g":{"r":0,"d":0,"h":12886858071,"f":1},"s":{"r":0,"d":0,"h":17181825367,"f":1},"n":"AccessMask","d":1956183,"h":8591890775,"f":1},{"p":443615,"g":{"r":0,"d":0,"h":25771759959,"f":1},"s":{"r":0,"d":0,"h":30066727255,"f":1},"n":"SecurityIdentifier","d":1956183,"h":21476792663,"f":1}],"c":[{"n":".ctor","o":"$ctor$2","d":1956183,"h":4296923479,"f":8}],"h":1956183}; }
            static get $b() { return $.$ssa.System.Security.AccessControl.GenericAce; }
            static get $fullName() { return `System.Security.AccessControl.KnownAce`; }
        });
        
        $asm.$cls("$ssa.System.Security.AccessControl.CommonAcl", ($self) => class CommonAcl extends $.$ssa.System.Security.AccessControl.GenericAcl
        {
            $ctor$2()
            {
                super.$ctor$1();
                {
                }
                return this;
            }
            /*int */ get BinaryLength()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ get Count()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get IsCanonical()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get IsContainer()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get IsDS()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Security.AccessControl.GenericAce*/ get_Item(/*int*/ index)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*void*/ set_Item(/*int*/ index, /*System.Security.AccessControl.GenericAce*/ value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*byte */ get Revision()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*void */ GetBinaryForm(/*byte[]*/ binaryForm, /*int*/ offset)
            {
            }
            /*void */ Purge(/*System.Security.Principal.SecurityIdentifier*/ sid)
            {
            }
            /*void */ RemoveInheritedAces()
            {
            }
            static $h = 1169751;
            static $f = 0b110001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":1759575,"p":[{"p":655361,"g":{"r":0,"d":0,"h":12886071639,"f":98305},"n":"BinaryLength","d":1169751,"h":8591104343,"f":98305},{"p":655361,"g":{"r":0,"d":0,"h":21476006231,"f":98305},"n":"Count","d":1169751,"h":17181038935,"f":98305},{"p":262145,"g":{"r":0,"d":0,"h":30065940823,"f":1},"n":"IsCanonical","d":1169751,"h":25770973527,"f":1},{"p":262145,"g":{"r":0,"d":0,"h":38655875415,"f":1},"n":"IsContainer","d":1169751,"h":34360908119,"f":1},{"p":262145,"g":{"r":0,"d":0,"h":47245810007,"f":1},"n":"IsDS","d":1169751,"h":42950842711,"f":1},{"p":1694039,"i":[{"n":"index","p":655361}],"g":{"r":0,"d":0,"h":55835744599,"f":98305},"s":{"r":0,"d":0,"h":60130711895,"f":98305},"n":"Item","o":"@$2","d":1169751,"h":51540777303,"f":98305},{"p":393217,"g":{"r":0,"d":0,"h":68720646487,"f":98305},"n":"Revision","d":1169751,"h":64425679191,"f":98305}],"m":[{"r":65537,"p":[{"n":"binaryForm","p":0},{"n":"offset","p":655361}],"n":"GetBinaryForm","d":1169751,"h":73015613783,"f":98305},{"r":65537,"p":[{"n":"sid","p":443615}],"n":"Purge","d":1169751,"h":77310581079,"f":1},{"r":65537,"n":"RemoveInheritedAces","d":1169751,"h":81605548375,"f":1}],"c":[{"n":".ctor","o":"$ctor$2","d":1169751,"h":4296137047,"f":8}],"i":[31326209,31588353],"h":1169751}; }
            static get $b() { return $.$ssa.System.Security.AccessControl.GenericAcl; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.Collections.ICollection, $.$spc.System.Collections.IEnumerable ]; }
            static get $fullName() { return `System.Security.AccessControl.CommonAcl`; }
        });
        
        $asm.$cls("$ssa.System.Security.AccessControl.NativeObjectSecurity", ($self) => class NativeObjectSecurity extends $.$ssa.System.Security.AccessControl.CommonObjectSecurity
        {
            $ctor$5(/*bool*/ isContainer, /*System.Security.AccessControl.ResourceType*/ resourceType)
            {
                super.$ctor$4(false);
                {
                }
                return this;
            }
            $ctor$6(/*bool*/ isContainer, /*System.Security.AccessControl.ResourceType*/ resourceType, /*System.Runtime.InteropServices.SafeHandle?*/ handle, /*System.Security.AccessControl.AccessControlSections*/ includeSections)
            {
                super.$ctor$4(false);
                {
                }
                return this;
            }
            $ctor$7(/*bool*/ isContainer, /*System.Security.AccessControl.ResourceType*/ resourceType, /*System.Runtime.InteropServices.SafeHandle?*/ handle, /*System.Security.AccessControl.AccessControlSections*/ includeSections, /*System.Security.AccessControl.NativeObjectSecurity.ExceptionFromErrorCode?*/ exceptionFromErrorCode, /*object?*/ exceptionContext)
            {
                super.$ctor$4(false);
                {
                }
                return this;
            }
            $ctor$8(/*bool*/ isContainer, /*System.Security.AccessControl.ResourceType*/ resourceType, /*System.Security.AccessControl.NativeObjectSecurity.ExceptionFromErrorCode?*/ exceptionFromErrorCode, /*object?*/ exceptionContext)
            {
                super.$ctor$4(false);
                {
                }
                return this;
            }
            $ctor$9(/*bool*/ isContainer, /*System.Security.AccessControl.ResourceType*/ resourceType, /*string?*/ name, /*System.Security.AccessControl.AccessControlSections*/ includeSections)
            {
                super.$ctor$4(false);
                {
                }
                return this;
            }
            $ctor$10(/*bool*/ isContainer, /*System.Security.AccessControl.ResourceType*/ resourceType, /*string?*/ name, /*System.Security.AccessControl.AccessControlSections*/ includeSections, /*System.Security.AccessControl.NativeObjectSecurity.ExceptionFromErrorCode?*/ exceptionFromErrorCode, /*object?*/ exceptionContext)
            {
                super.$ctor$4(false);
                {
                }
                return this;
            }
            /*void */ Persist$1(/*System.Runtime.InteropServices.SafeHandle*/ handle, /*System.Security.AccessControl.AccessControlSections*/ includeSections)
            {
            }
            /*void */ Persist$3(/*System.Runtime.InteropServices.SafeHandle*/ handle, /*System.Security.AccessControl.AccessControlSections*/ includeSections, /*object?*/ exceptionContext)
            {
            }
            /*void */ Persist$2(/*string*/ name, /*System.Security.AccessControl.AccessControlSections*/ includeSections)
            {
            }
            /*void */ Persist$4(/*string*/ name, /*System.Security.AccessControl.AccessControlSections*/ includeSections, /*object?*/ exceptionContext)
            {
            }
            static $_ExceptionFromErrorCode;
            static get ExceptionFromErrorCode()
            {
                let $cls = $.$ssa.System.Security.AccessControl.NativeObjectSecurity;
                return $cls.$_ExceptionFromErrorCode ??= $asm.$ncls("$ssa.System.Security.AccessControl.NativeObjectSecurity.ExceptionFromErrorCode", ($self) => class ExceptionFromErrorCode extends $.$spc.System.MulticastDelegate
                {
                    $ctor(/*object*/ target, fn)
                    {
                        this._target = target;
                        this.$nativeFunction = fn;
                        return this;
                    }
                    /*System.Exception?*/ Invoke(/*$.$spc.System.Int32*/ $errorCode, /*$.$spc.System.Nullable$$*/ $name, /*$.$spc.System.Nullable$$*/ $handle, /*$.$spc.System.Nullable$$*/ $context)
                    {
                        return this.$nativeFunction.apply(this._target, arguments);
                    }
                    static $h = 2087255;
                    static $f = 0b10000000010000000;
                    static $k = 5;
                    static $$md;
                    static get $md() { return this.$$md ??= {"b":66191361,"m":[{"r":47185921,"p":[{"n":"errorCode","p":655361},{"n":"name","p":1310721},{"n":"handle","p":109576193},{"n":"context","p":131073}],"n":"Invoke","d":2087255,"h":8592021847,"f":129},{"r":56950785,"p":[{"n":"errorCode","p":655361},{"n":"name","p":1310721},{"n":"handle","p":109576193},{"n":"context","p":131073},{"n":"callback","p":14417921},{"n":"object","p":131073}],"n":"BeginInvoke","d":2087255,"h":12886989143,"f":129},{"r":47185921,"p":[{"n":"result","p":56950785}],"n":"EndInvoke","d":2087255,"h":17181956439,"f":129}],"c":[{"p":[{"n":"object","p":131073},{"n":"method","p":786433}],"n":".ctor","o":"$ctor$5","d":2087255,"h":4297054551,"f":1}],"i":[57147393,113377281],"d":2021719,"h":2087255}; }
                    static get $b() { return $.$spc.System.MulticastDelegate; }
                    static $$i;
                    static get $i() { return this.$$i ??= [ $.$spc.System.ICloneable, $.$spc.System.Runtime.Serialization.ISerializable ]; }
                    static get $fullName() { return `System.Security.AccessControl.NativeObjectSecurity.ExceptionFromErrorCode`; }
                }, $cls, ($v) => $cls.$_ExceptionFromErrorCode = $v);
            }
            static $h = 2021719;
            static $f = 0b110001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":1235287,"m":[{"r":65537,"p":[{"n":"handle","p":109576193},{"n":"includeSections","p":252247}],"n":"Persist","o":"@$1","d":2021719,"h":30066792791,"f":98308},{"r":65537,"p":[{"n":"handle","p":109576193},{"n":"includeSections","p":252247},{"n":"exceptionContext","p":131073}],"n":"Persist","o":"@$3","d":2021719,"h":34361760087,"f":4},{"r":65537,"p":[{"n":"name","p":1310721},{"n":"includeSections","p":252247}],"n":"Persist","o":"@$2","d":2021719,"h":38656727383,"f":98308},{"r":65537,"p":[{"n":"name","p":1310721},{"n":"includeSections","p":252247},{"n":"exceptionContext","p":131073}],"n":"Persist","o":"@$4","d":2021719,"h":42951694679,"f":4}],"c":[{"p":[{"n":"isContainer","p":262145},{"n":"resourceType","p":2873687}],"n":".ctor","o":"$ctor$5","d":2021719,"h":4296989015,"f":4},{"p":[{"n":"isContainer","p":262145},{"n":"resourceType","p":2873687},{"n":"handle","p":109576193},{"n":"includeSections","p":252247}],"n":".ctor","o":"$ctor$6","d":2021719,"h":8591956311,"f":4},{"p":[{"n":"isContainer","p":262145},{"n":"resourceType","p":2873687},{"n":"handle","p":109576193},{"n":"includeSections","p":252247},{"n":"exceptionFromErrorCode","p":2087255},{"n":"exceptionContext","p":131073}],"n":".ctor","o":"$ctor$7","d":2021719,"h":12886923607,"f":4},{"p":[{"n":"isContainer","p":262145},{"n":"resourceType","p":2873687},{"n":"exceptionFromErrorCode","p":2087255},{"n":"exceptionContext","p":131073}],"n":".ctor","o":"$ctor$8","d":2021719,"h":17181890903,"f":4},{"p":[{"n":"isContainer","p":262145},{"n":"resourceType","p":2873687},{"n":"name","p":1310721},{"n":"includeSections","p":252247}],"n":".ctor","o":"$ctor$9","d":2021719,"h":21476858199,"f":4},{"p":[{"n":"isContainer","p":262145},{"n":"resourceType","p":2873687},{"n":"name","p":1310721},{"n":"includeSections","p":252247},{"n":"exceptionFromErrorCode","p":2087255},{"n":"exceptionContext","p":131073}],"n":".ctor","o":"$ctor$10","d":2021719,"h":25771825495,"f":4}],"j":[2087255],"h":2021719}; }
            static get $b() { return $.$ssa.System.Security.AccessControl.CommonObjectSecurity; }
            static get $fullName() { return `System.Security.AccessControl.NativeObjectSecurity`; }
        });
        
        $asm.$cls("$ssa.System.Security.AccessControl.ObjectAccessRule", ($self) => class ObjectAccessRule extends $.$ssa.System.Security.AccessControl.AccessRule
        {
            $ctor$3(/*System.Security.Principal.IdentityReference*/ identity, /*int*/ accessMask, /*bool*/ isInherited, /*System.Security.AccessControl.InheritanceFlags*/ inheritanceFlags, /*System.Security.AccessControl.PropagationFlags*/ propagationFlags, /*System.Guid*/ objectType, /*System.Guid*/ inheritedObjectType, /*System.Security.AccessControl.AccessControlType*/ type)
            {
                super.$ctor$2(null, 0, false, 0, 0, 0);
                {
                }
                return this;
            }
            /*System.Guid */ get InheritedObjectType()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Security.AccessControl.ObjectAceFlags */ get ObjectFlags()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Guid */ get ObjectType()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static $h = 2152791;
            static $f = 0b110001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":383319,"p":[{"p":56164353,"g":{"r":0,"d":0,"h":12887054679,"f":1},"n":"InheritedObjectType","d":2152791,"h":8592087383,"f":1},{"p":2283863,"g":{"r":0,"d":0,"h":21476989271,"f":1},"n":"ObjectFlags","d":2152791,"h":17182021975,"f":1},{"p":56164353,"g":{"r":0,"d":0,"h":30066923863,"f":1},"n":"ObjectType","d":2152791,"h":25771956567,"f":1}],"c":[{"p":[{"n":"identity","p":247007},{"n":"accessMask","p":655361},{"n":"isInherited","p":262145},{"n":"inheritanceFlags","p":1890647},{"n":"propagationFlags","p":2611543},{"n":"objectType","p":56164353},{"n":"inheritedObjectType","p":56164353},{"n":"type","p":317783}],"n":".ctor","o":"$ctor$3","d":2152791,"h":4297120087,"f":4}],"h":2152791}; }
            static get $b() { return $.$ssa.System.Security.AccessControl.AccessRule; }
            static get $fullName() { return `System.Security.AccessControl.ObjectAccessRule`; }
        });
        
        $asm.$cls("$ssa.System.Security.AccessControl.ObjectAuditRule", ($self) => class ObjectAuditRule extends $.$ssa.System.Security.AccessControl.AuditRule
        {
            $ctor$3(/*System.Security.Principal.IdentityReference*/ identity, /*int*/ accessMask, /*bool*/ isInherited, /*System.Security.AccessControl.InheritanceFlags*/ inheritanceFlags, /*System.Security.AccessControl.PropagationFlags*/ propagationFlags, /*System.Guid*/ objectType, /*System.Guid*/ inheritedObjectType, /*System.Security.AccessControl.AuditFlags*/ auditFlags)
            {
                super.$ctor$2(null, 0, false, 0, 0, 0);
                {
                }
                return this;
            }
            /*System.Guid */ get InheritedObjectType()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Security.AccessControl.ObjectAceFlags */ get ObjectFlags()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Guid */ get ObjectType()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static $h = 2349399;
            static $f = 0b110001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":842071,"p":[{"p":56164353,"g":{"r":0,"d":0,"h":12887251287,"f":1},"n":"InheritedObjectType","d":2349399,"h":8592283991,"f":1},{"p":2283863,"g":{"r":0,"d":0,"h":21477185879,"f":1},"n":"ObjectFlags","d":2349399,"h":17182218583,"f":1},{"p":56164353,"g":{"r":0,"d":0,"h":30067120471,"f":1},"n":"ObjectType","d":2349399,"h":25772153175,"f":1}],"c":[{"p":[{"n":"identity","p":247007},{"n":"accessMask","p":655361},{"n":"isInherited","p":262145},{"n":"inheritanceFlags","p":1890647},{"n":"propagationFlags","p":2611543},{"n":"objectType","p":56164353},{"n":"inheritedObjectType","p":56164353},{"n":"auditFlags","p":776535}],"n":".ctor","o":"$ctor$3","d":2349399,"h":4297316695,"f":4}],"h":2349399}; }
            static get $b() { return $.$ssa.System.Security.AccessControl.AuditRule; }
            static get $fullName() { return `System.Security.AccessControl.ObjectAuditRule`; }
        });
        
        $asm.$cls("$ssa.System.Security.AccessControl.QualifiedAce", ($self) => class QualifiedAce extends $.$ssa.System.Security.AccessControl.KnownAce
        {
            $ctor$3()
            {
                super.$ctor$2();
                {
                }
                return this;
            }
            /*System.Security.AccessControl.AceQualifier */ get AceQualifier()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get IsCallback()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ get OpaqueLength()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*byte[]? */ GetOpaque()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*void */ SetOpaque(/*byte[]?*/ opaque)
            {
            }
            static $h = 2677079;
            static $f = 0b110001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":1956183,"p":[{"p":645463,"g":{"r":0,"d":0,"h":12887578967,"f":1},"n":"AceQualifier","d":2677079,"h":8592611671,"f":1},{"p":262145,"g":{"r":0,"d":0,"h":21477513559,"f":1},"n":"IsCallback","d":2677079,"h":17182546263,"f":1},{"p":655361,"g":{"r":0,"d":0,"h":30067448151,"f":1},"n":"OpaqueLength","d":2677079,"h":25772480855,"f":1}],"m":[{"r":0,"n":"GetOpaque","d":2677079,"h":34362415447,"f":1},{"r":65537,"p":[{"n":"opaque","p":0}],"n":"SetOpaque","d":2677079,"h":38657382743,"f":1}],"c":[{"n":".ctor","o":"$ctor$3","d":2677079,"h":4297644375,"f":8}],"h":2677079}; }
            static get $b() { return $.$ssa.System.Security.AccessControl.KnownAce; }
            static get $fullName() { return `System.Security.AccessControl.QualifiedAce`; }
        });
        
        $asm.$cls("$ssa.System.Security.AccessControl.ObjectSecurity<>", (T) => $asm.$gt("$ssa.System.Security.AccessControl.ObjectSecurity<>", [T], ($self) => class ObjectSecurity$$ extends $.$ssa.System.Security.AccessControl.NativeObjectSecurity
        {
            $ctor$11(/*bool*/ isContainer, /*System.Security.AccessControl.ResourceType*/ resourceType)
            {
                super.$ctor$5(false, 0);
                {
                }
                return this;
            }
            $ctor$12(/*bool*/ isContainer, /*System.Security.AccessControl.ResourceType*/ resourceType, /*System.Runtime.InteropServices.SafeHandle?*/ safeHandle, /*System.Security.AccessControl.AccessControlSections*/ includeSections)
            {
                super.$ctor$5(false, 0);
                {
                }
                return this;
            }
            $ctor$13(/*bool*/ isContainer, /*System.Security.AccessControl.ResourceType*/ resourceType, /*System.Runtime.InteropServices.SafeHandle?*/ safeHandle, /*System.Security.AccessControl.AccessControlSections*/ includeSections, /*System.Security.AccessControl.NativeObjectSecurity.ExceptionFromErrorCode?*/ exceptionFromErrorCode, /*object?*/ exceptionContext)
            {
                super.$ctor$5(false, 0);
                {
                }
                return this;
            }
            $ctor$14(/*bool*/ isContainer, /*System.Security.AccessControl.ResourceType*/ resourceType, /*string?*/ name, /*System.Security.AccessControl.AccessControlSections*/ includeSections)
            {
                super.$ctor$5(false, 0);
                {
                }
                return this;
            }
            $ctor$15(/*bool*/ isContainer, /*System.Security.AccessControl.ResourceType*/ resourceType, /*string?*/ name, /*System.Security.AccessControl.AccessControlSections*/ includeSections, /*System.Security.AccessControl.NativeObjectSecurity.ExceptionFromErrorCode?*/ exceptionFromErrorCode, /*object?*/ exceptionContext)
            {
                super.$ctor$5(false, 0);
                {
                }
                return this;
            }
            /*System.Type */ get AccessRightType()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Type */ get AccessRuleType()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Type */ get AuditRuleType()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Security.AccessControl.AccessRule */ AccessRuleFactory(/*System.Security.Principal.IdentityReference*/ identityReference, /*int*/ accessMask, /*bool*/ isInherited, /*System.Security.AccessControl.InheritanceFlags*/ inheritanceFlags, /*System.Security.AccessControl.PropagationFlags*/ propagationFlags, /*System.Security.AccessControl.AccessControlType*/ type)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*void */ AddAccessRule$1(/*System.Security.AccessControl.AccessRule<T>*/ rule)
            {
            }
            /*void */ AddAuditRule$1(/*System.Security.AccessControl.AuditRule<T>*/ rule)
            {
            }
            /*System.Security.AccessControl.AuditRule */ AuditRuleFactory(/*System.Security.Principal.IdentityReference*/ identityReference, /*int*/ accessMask, /*bool*/ isInherited, /*System.Security.AccessControl.InheritanceFlags*/ inheritanceFlags, /*System.Security.AccessControl.PropagationFlags*/ propagationFlags, /*System.Security.AccessControl.AuditFlags*/ flags)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*void */ Persist$5(/*System.Runtime.InteropServices.SafeHandle*/ handle)
            {
            }
            /*void */ Persist$6(/*string*/ name)
            {
            }
            /*bool */ RemoveAccessRule$1(/*System.Security.AccessControl.AccessRule<T>*/ rule)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*void */ RemoveAccessRuleAll$1(/*System.Security.AccessControl.AccessRule<T>*/ rule)
            {
            }
            /*void */ RemoveAccessRuleSpecific$1(/*System.Security.AccessControl.AccessRule<T>*/ rule)
            {
            }
            /*bool */ RemoveAuditRule$1(/*System.Security.AccessControl.AuditRule<T>*/ rule)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*void */ RemoveAuditRuleAll$1(/*System.Security.AccessControl.AuditRule<T>*/ rule)
            {
            }
            /*void */ RemoveAuditRuleSpecific$1(/*System.Security.AccessControl.AuditRule<T>*/ rule)
            {
            }
            /*void */ ResetAccessRule$1(/*System.Security.AccessControl.AccessRule<T>*/ rule)
            {
            }
            /*void */ SetAccessRule$1(/*System.Security.AccessControl.AccessRule<T>*/ rule)
            {
            }
            /*void */ SetAuditRule$1(/*System.Security.AccessControl.AuditRule<T>*/ rule)
            {
            }
            static $h = 2480471;
            static $g = 1;
            static $f = 0b1110001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":2021719,"p":[{"p":142606337,"g":{"r":0,"d":0,"h":Number(BigInt(this.$h)|0x700000000n),"f":32769},"n":"AccessRightType","d":this.$h,"h":Number(BigInt(this.$h)|0x600000000n),"f":32769},{"p":142606337,"g":{"r":0,"d":0,"h":Number(BigInt(this.$h)|0x900000000n),"f":32769},"n":"AccessRuleType","d":this.$h,"h":Number(BigInt(this.$h)|0x800000000n),"f":32769},{"p":142606337,"g":{"r":0,"d":0,"h":Number(BigInt(this.$h)|0xB00000000n),"f":32769},"n":"AuditRuleType","d":this.$h,"h":Number(BigInt(this.$h)|0xA00000000n),"f":32769}],"m":[{"r":383319,"p":[{"n":"identityReference","p":247007},{"n":"accessMask","p":655361},{"n":"isInherited","p":262145},{"n":"inheritanceFlags","p":1890647},{"n":"propagationFlags","p":2611543},{"n":"type","p":317783}],"n":"AccessRuleFactory","d":this.$h,"h":Number(BigInt(this.$h)|0xC00000000n),"f":32769},{"r":65537,"p":[{"n":"rule","p":$.$ssa.System.Security.AccessControl.AccessRule$$(T).$h}],"n":"AddAccessRule","o":"@$1","d":this.$h,"h":Number(BigInt(this.$h)|0xD00000000n),"f":129},{"r":65537,"p":[{"n":"rule","p":$.$ssa.System.Security.AccessControl.AuditRule$$(T).$h}],"n":"AddAuditRule","o":"@$1","d":this.$h,"h":Number(BigInt(this.$h)|0xE00000000n),"f":129},{"r":842071,"p":[{"n":"identityReference","p":247007},{"n":"accessMask","p":655361},{"n":"isInherited","p":262145},{"n":"inheritanceFlags","p":1890647},{"n":"propagationFlags","p":2611543},{"n":"flags","p":776535}],"n":"AuditRuleFactory","d":this.$h,"h":Number(BigInt(this.$h)|0xF00000000n),"f":32769},{"r":65537,"p":[{"n":"handle","p":109576193}],"n":"Persist","o":"@$5","d":this.$h,"h":Number(BigInt(this.$h)|0x1000000000n),"f":16},{"r":65537,"p":[{"n":"name","p":1310721}],"n":"Persist","o":"@$6","d":this.$h,"h":Number(BigInt(this.$h)|0x1100000000n),"f":16},{"r":262145,"p":[{"n":"rule","p":$.$ssa.System.Security.AccessControl.AccessRule$$(T).$h}],"n":"RemoveAccessRule","o":"@$1","d":this.$h,"h":Number(BigInt(this.$h)|0x1200000000n),"f":129},{"r":65537,"p":[{"n":"rule","p":$.$ssa.System.Security.AccessControl.AccessRule$$(T).$h}],"n":"RemoveAccessRuleAll","o":"@$1","d":this.$h,"h":Number(BigInt(this.$h)|0x1300000000n),"f":129},{"r":65537,"p":[{"n":"rule","p":$.$ssa.System.Security.AccessControl.AccessRule$$(T).$h}],"n":"RemoveAccessRuleSpecific","o":"@$1","d":this.$h,"h":Number(BigInt(this.$h)|0x1400000000n),"f":129},{"r":262145,"p":[{"n":"rule","p":$.$ssa.System.Security.AccessControl.AuditRule$$(T).$h}],"n":"RemoveAuditRule","o":"@$1","d":this.$h,"h":Number(BigInt(this.$h)|0x1500000000n),"f":129},{"r":65537,"p":[{"n":"rule","p":$.$ssa.System.Security.AccessControl.AuditRule$$(T).$h}],"n":"RemoveAuditRuleAll","o":"@$1","d":this.$h,"h":Number(BigInt(this.$h)|0x1600000000n),"f":129},{"r":65537,"p":[{"n":"rule","p":$.$ssa.System.Security.AccessControl.AuditRule$$(T).$h}],"n":"RemoveAuditRuleSpecific","o":"@$1","d":this.$h,"h":Number(BigInt(this.$h)|0x1700000000n),"f":129},{"r":65537,"p":[{"n":"rule","p":$.$ssa.System.Security.AccessControl.AccessRule$$(T).$h}],"n":"ResetAccessRule","o":"@$1","d":this.$h,"h":Number(BigInt(this.$h)|0x1800000000n),"f":129},{"r":65537,"p":[{"n":"rule","p":$.$ssa.System.Security.AccessControl.AccessRule$$(T).$h}],"n":"SetAccessRule","o":"@$1","d":this.$h,"h":Number(BigInt(this.$h)|0x1900000000n),"f":129},{"r":65537,"p":[{"n":"rule","p":$.$ssa.System.Security.AccessControl.AuditRule$$(T).$h}],"n":"SetAuditRule","o":"@$1","d":this.$h,"h":Number(BigInt(this.$h)|0x1A00000000n),"f":129}],"c":[{"p":[{"n":"isContainer","p":262145},{"n":"resourceType","p":2873687}],"n":".ctor","o":"$ctor$11","d":this.$h,"h":Number(BigInt(this.$h)|0x100000000n),"f":4},{"p":[{"n":"isContainer","p":262145},{"n":"resourceType","p":2873687},{"n":"safeHandle","p":109576193},{"n":"includeSections","p":252247}],"n":".ctor","o":"$ctor$12","d":this.$h,"h":Number(BigInt(this.$h)|0x200000000n),"f":4},{"p":[{"n":"isContainer","p":262145},{"n":"resourceType","p":2873687},{"n":"safeHandle","p":109576193},{"n":"includeSections","p":252247},{"n":"exceptionFromErrorCode","p":2087255},{"n":"exceptionContext","p":131073}],"n":".ctor","o":"$ctor$13","d":this.$h,"h":Number(BigInt(this.$h)|0x300000000n),"f":4},{"p":[{"n":"isContainer","p":262145},{"n":"resourceType","p":2873687},{"n":"name","p":1310721},{"n":"includeSections","p":252247}],"n":".ctor","o":"$ctor$14","d":this.$h,"h":Number(BigInt(this.$h)|0x400000000n),"f":4},{"p":[{"n":"isContainer","p":262145},{"n":"resourceType","p":2873687},{"n":"name","p":1310721},{"n":"includeSections","p":252247},{"n":"exceptionFromErrorCode","p":2087255},{"n":"exceptionContext","p":131073}],"n":".ctor","o":"$ctor$15","d":this.$h,"h":Number(BigInt(this.$h)|0x500000000n),"f":4}],"g":[T?.$h??1507328],"s":[{"n":"T","f":2}],"r":1,"h":this.$h}; }
            static get $b() { return $.$ssa.System.Security.AccessControl.NativeObjectSecurity; }
            static get $fullName() { return `System.Security.AccessControl.ObjectSecurity<${T?.$fullName}>`; }
        }));
        
        $asm.$cls("$ssa.System.Security.AccessControl.AceEnumerator", ($self) => class AceEnumerator extends $.$spc.System.Object
        {
            $ctor$1()
            {
                super.$ctor();
                {
                }
                return this;
            }
            /*System.Security.AccessControl.GenericAce */ get Current()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*object */ get System$Collections$IEnumerator$Current()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ MoveNext()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*void */ Reset()
            {
            }
            //Generated interface implemetation for System.Collections.IEnumerator.MoveNext()
            System$Collections$IEnumerator$MoveNext()
            {
                return this.MoveNext(...arguments);
            }
            //Generated interface implemetation for System.Collections.IEnumerator.Reset()
            System$Collections$IEnumerator$Reset()
            {
                return this.Reset(...arguments);
            }
            static $h = 514391;
            static $f = 0b10010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":1694039,"g":{"r":0,"d":0,"h":12885416279,"f":1},"n":"Current","d":514391,"h":8590448983,"f":1},{"p":131073,"g":{"r":0,"d":0,"h":21475350871,"f":2},"n":"{31719425}.Current","o":"System$Collections$IEnumerator$Current","d":514391,"h":17180383575,"f":2}],"m":[{"r":262145,"n":"MoveNext","d":514391,"h":25770318167,"f":1},{"r":65537,"n":"Reset","d":514391,"h":30065285463,"f":1}],"c":[{"n":".ctor","o":"$ctor$1","d":514391,"h":4295481687,"f":8}],"i":[31719425],"h":514391}; }
            static get $b() { return $.$spc.System.Object; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.Collections.IEnumerator ]; }
            static get $fullName() { return `System.Security.AccessControl.AceEnumerator`; }
        });
        
        $asm.$cls("$ssa.System.Security.Policy.Evidence", ($self) => class Evidence extends $.$spc.System.Object
        {
            $ctor$1()
            {
                super.$ctor();
                {
                }
                return this;
            }
            $ctor$2(/*object[]*/ hostEvidence, /*object[]*/ assemblyEvidence)
            {
                super.$ctor();
                {
                }
                return this;
            }
            $ctor$3(/*System.Security.Policy.Evidence*/ evidence)
            {
                super.$ctor();
                {
                }
                return this;
            }
            $ctor$4(/*System.Security.Policy.EvidenceBase[]*/ hostEvidence, /*System.Security.Policy.EvidenceBase[]*/ assemblyEvidence)
            {
                super.$ctor();
                {
                }
                return this;
            }
            /*int */ get Count()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get IsReadOnly()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get IsSynchronized()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get Locked()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ set Locked(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*object */ get SyncRoot()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*void */ AddAssembly(/*object*/ id)
            {
            }
            /*void */ AddAssemblyEvidence(T, /*T*/ evidence)
            {
            }
            /*void */ AddHost(/*object*/ id)
            {
            }
            /*void */ AddHostEvidence(T, /*T*/ evidence)
            {
            }
            /*void */ Clear()
            {
            }
            /*System.Security.Policy.Evidence? */ Clone()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*void */ CopyTo(/*System.Array*/ array, /*int*/ index)
            {
            }
            /*System.Collections.IEnumerator */ GetAssemblyEnumerator()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*T? */ GetAssemblyEvidence(T, )
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Collections.IEnumerator */ GetEnumerator()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Collections.IEnumerator */ GetHostEnumerator()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*T? */ GetHostEvidence(T, )
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*void */ Merge(/*System.Security.Policy.Evidence*/ evidence)
            {
            }
            /*void */ RemoveType(/*System.Type*/ t)
            {
            }
            //Generated interface implemetation for System.Collections.ICollection.CopyTo(System.Array, int)
            System$Collections$ICollection$CopyTo()
            {
                return this.CopyTo(...arguments);
            }
            //Generated interface implemetation for System.Collections.ICollection.Count.get
            get System$Collections$ICollection$Count()
            {
                return this.Count;
            }
            //Generated interface implemetation for System.Collections.ICollection.SyncRoot.get
            get System$Collections$ICollection$SyncRoot()
            {
                return this.SyncRoot;
            }
            //Generated interface implemetation for System.Collections.ICollection.IsSynchronized.get
            get System$Collections$ICollection$IsSynchronized()
            {
                return this.IsSynchronized;
            }
            //Generated interface implemetation for System.Collections.IEnumerable.GetEnumerator()
            System$Collections$IEnumerable$GetEnumerator()
            {
                return this.GetEnumerator(...arguments);
            }
            static $h = 3070295;
            static $f = 0b10010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":655361,"g":{"r":0,"d":0,"h":25772874071,"f":1},"n":"Count","d":3070295,"h":21477906775,"f":1,"a":[{"t":70909953,"c":8660844545,"a":[{"v":"Evidence should not be treated as an ICollection. Use GetHostEnumerator and GetAssemblyEnumerator to iterate over the evidence to collect a count.","t":1310721}]}]},{"p":262145,"g":{"r":0,"d":0,"h":34362808663,"f":1},"n":"IsReadOnly","d":3070295,"h":30067841367,"f":1},{"p":262145,"g":{"r":0,"d":0,"h":42952743255,"f":1},"n":"IsSynchronized","d":3070295,"h":38657775959,"f":1},{"p":262145,"g":{"r":0,"d":0,"h":51542677847,"f":1},"s":{"r":0,"d":0,"h":55837645143,"f":1},"n":"Locked","d":3070295,"h":47247710551,"f":1},{"p":131073,"g":{"r":0,"d":0,"h":64427579735,"f":1},"n":"SyncRoot","d":3070295,"h":60132612439,"f":1}],"m":[{"r":65537,"p":[{"n":"id","p":131073}],"n":"AddAssembly","d":3070295,"h":68722547031,"f":1,"a":[{"t":70909953,"c":8660844545,"a":[{"v":"Evidence.AddAssembly has been deprecated. Use AddAssemblyEvidence instead.","t":1310721}]}]},{"r":65537,"p":[{"n":"evidence","p":68723081216}],"g":["T"],"n":"AddAssemblyEvidence","d":3070295,"h":73017514327,"f":131073},{"r":65537,"p":[{"n":"id","p":131073}],"n":"AddHost","d":3070295,"h":77312481623,"f":1,"a":[{"t":70909953,"c":8660844545,"a":[{"v":"Evidence.AddHost has been deprecated. Use AddHostEvidence instead.","t":1310721}]}]},{"r":65537,"p":[{"n":"evidence","p":77313015808}],"g":["T"],"n":"AddHostEvidence","d":3070295,"h":81607448919,"f":131073},{"r":65537,"n":"Clear","d":3070295,"h":85902416215,"f":1},{"r":3070295,"n":"Clone","d":3070295,"h":90197383511,"f":1},{"r":65537,"p":[{"n":"array","p":1245185},{"n":"index","p":655361}],"n":"CopyTo","d":3070295,"h":94492350807,"f":1,"a":[{"t":70909953,"c":8660844545,"a":[{"v":"Evidence should not be treated as an ICollection. Use the GetHostEnumerator and GetAssemblyEnumerator methods rather than using CopyTo.","t":1310721}]}]},{"r":31719425,"n":"GetAssemblyEnumerator","d":3070295,"h":98787318103,"f":1},{"r":98787852288,"g":["T"],"n":"GetAssemblyEvidence","d":3070295,"h":103082285399,"f":131073},{"r":31719425,"n":"GetEnumerator","d":3070295,"h":107377252695,"f":1,"a":[{"t":70909953,"c":8660844545,"a":[{"v":"GetEnumerator is obsolete. Use GetAssemblyEnumerator and GetHostEnumerator instead.","t":1310721}]}]},{"r":31719425,"n":"GetHostEnumerator","d":3070295,"h":111672219991,"f":1},{"r":111672754176,"g":["T"],"n":"GetHostEvidence","d":3070295,"h":115967187287,"f":131073},{"r":65537,"p":[{"n":"evidence","p":3070295}],"n":"Merge","d":3070295,"h":120262154583,"f":1},{"r":65537,"p":[{"n":"t","p":142606337}],"n":"RemoveType","d":3070295,"h":124557121879,"f":1}],"c":[{"n":".ctor","o":"$ctor$1","d":3070295,"h":4298037591,"f":1},{"p":[{"n":"hostEvidence","p":0},{"n":"assemblyEvidence","p":0}],"n":".ctor","o":"$ctor$2","d":3070295,"h":8593004887,"f":1,"a":[{"t":70909953,"c":8660844545,"a":[{"v":"This constructor is obsolete. Use the constructor which accepts arrays of EvidenceBase instead.","t":1310721}]}]},{"p":[{"n":"evidence","p":3070295}],"n":".ctor","o":"$ctor$3","d":3070295,"h":12887972183,"f":1},{"p":[{"n":"hostEvidence","p":0},{"n":"assemblyEvidence","p":0}],"n":".ctor","o":"$ctor$4","d":3070295,"h":17182939479,"f":1}],"i":[31326209,31588353],"h":3070295}; }
            static get $b() { return $.$spc.System.Object; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.Collections.ICollection, $.$spc.System.Collections.IEnumerable ]; }
            static get $fullName() { return `System.Security.Policy.Evidence`; }
        });
        
        $asm.$cls("$ssa.System.Security.AccessControl.CommonSecurityDescriptor", ($self) => class CommonSecurityDescriptor extends $.$ssa.System.Security.AccessControl.GenericSecurityDescriptor
        {
            $ctor$2(/*bool*/ isContainer, /*bool*/ isDS, /*byte[]*/ binaryForm, /*int*/ offset)
            {
                super.$ctor$1();
                {
                }
                return this;
            }
            $ctor$3(/*bool*/ isContainer, /*bool*/ isDS, /*System.Security.AccessControl.ControlFlags*/ flags, /*System.Security.Principal.SecurityIdentifier?*/ owner, /*System.Security.Principal.SecurityIdentifier?*/ group, /*System.Security.AccessControl.SystemAcl?*/ systemAcl, /*System.Security.AccessControl.DiscretionaryAcl?*/ discretionaryAcl)
            {
                super.$ctor$1();
                {
                }
                return this;
            }
            $ctor$4(/*bool*/ isContainer, /*bool*/ isDS, /*System.Security.AccessControl.RawSecurityDescriptor*/ rawSecurityDescriptor)
            {
                super.$ctor$1();
                {
                }
                return this;
            }
            $ctor$5(/*bool*/ isContainer, /*bool*/ isDS, /*string*/ sddlForm)
            {
                super.$ctor$1();
                {
                }
                return this;
            }
            /*System.Security.AccessControl.ControlFlags */ get ControlFlags()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Security.AccessControl.DiscretionaryAcl? */ get DiscretionaryAcl()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Security.AccessControl.DiscretionaryAcl? */ set DiscretionaryAcl(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Security.Principal.SecurityIdentifier? */ get Group()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Security.Principal.SecurityIdentifier? */ set Group(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get IsContainer()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get IsDiscretionaryAclCanonical()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get IsDS()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get IsSystemAclCanonical()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Security.Principal.SecurityIdentifier? */ get Owner()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Security.Principal.SecurityIdentifier? */ set Owner(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Security.AccessControl.SystemAcl? */ get SystemAcl()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Security.AccessControl.SystemAcl? */ set SystemAcl(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*void */ AddDiscretionaryAcl(/*byte*/ revision, /*int*/ trusted)
            {
            }
            /*void */ AddSystemAcl(/*byte*/ revision, /*int*/ trusted)
            {
            }
            /*void */ PurgeAccessControl(/*System.Security.Principal.SecurityIdentifier*/ sid)
            {
            }
            /*void */ PurgeAudit(/*System.Security.Principal.SecurityIdentifier*/ sid)
            {
            }
            /*void */ SetDiscretionaryAclProtection(/*bool*/ isProtected, /*bool*/ preserveInheritance)
            {
            }
            /*void */ SetSystemAclProtection(/*bool*/ isProtected, /*bool*/ preserveInheritance)
            {
            }
            static $h = 1300823;
            static $f = 0b10010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":1825111,"p":[{"p":1497431,"g":{"r":0,"d":0,"h":25771104599,"f":32769},"n":"ControlFlags","d":1300823,"h":21476137303,"f":32769},{"p":1628503,"g":{"r":0,"d":0,"h":34361039191,"f":1},"s":{"r":0,"d":0,"h":38656006487,"f":1},"n":"DiscretionaryAcl","d":1300823,"h":30066071895,"f":1},{"p":443615,"g":{"r":0,"d":0,"h":47245941079,"f":32769},"s":{"r":0,"d":0,"h":51540908375,"f":32769},"n":"Group","d":1300823,"h":42950973783,"f":32769},{"p":262145,"g":{"r":0,"d":0,"h":60130842967,"f":1},"n":"IsContainer","d":1300823,"h":55835875671,"f":1},{"p":262145,"g":{"r":0,"d":0,"h":68720777559,"f":1},"n":"IsDiscretionaryAclCanonical","d":1300823,"h":64425810263,"f":1},{"p":262145,"g":{"r":0,"d":0,"h":77310712151,"f":1},"n":"IsDS","d":1300823,"h":73015744855,"f":1},{"p":262145,"g":{"r":0,"d":0,"h":85900646743,"f":1},"n":"IsSystemAclCanonical","d":1300823,"h":81605679447,"f":1},{"p":443615,"g":{"r":0,"d":0,"h":94490581335,"f":32769},"s":{"r":0,"d":0,"h":98785548631,"f":32769},"n":"Owner","d":1300823,"h":90195614039,"f":32769},{"p":3004759,"g":{"r":0,"d":0,"h":107375483223,"f":1},"s":{"r":0,"d":0,"h":111670450519,"f":1},"n":"SystemAcl","d":1300823,"h":103080515927,"f":1}],"m":[{"r":65537,"p":[{"n":"revision","p":393217},{"n":"trusted","p":655361}],"n":"AddDiscretionaryAcl","d":1300823,"h":115965417815,"f":1},{"r":65537,"p":[{"n":"revision","p":393217},{"n":"trusted","p":655361}],"n":"AddSystemAcl","d":1300823,"h":120260385111,"f":1},{"r":65537,"p":[{"n":"sid","p":443615}],"n":"PurgeAccessControl","d":1300823,"h":124555352407,"f":1},{"r":65537,"p":[{"n":"sid","p":443615}],"n":"PurgeAudit","d":1300823,"h":128850319703,"f":1},{"r":65537,"p":[{"n":"isProtected","p":262145},{"n":"preserveInheritance","p":262145}],"n":"SetDiscretionaryAclProtection","d":1300823,"h":133145286999,"f":1},{"r":65537,"p":[{"n":"isProtected","p":262145},{"n":"preserveInheritance","p":262145}],"n":"SetSystemAclProtection","d":1300823,"h":137440254295,"f":1}],"c":[{"p":[{"n":"isContainer","p":262145},{"n":"isDS","p":262145},{"n":"binaryForm","p":0},{"n":"offset","p":655361}],"n":".ctor","o":"$ctor$2","d":1300823,"h":4296268119,"f":1},{"p":[{"n":"isContainer","p":262145},{"n":"isDS","p":262145},{"n":"flags","p":1497431},{"n":"owner","p":443615},{"n":"group","p":443615},{"n":"systemAcl","p":3004759},{"n":"discretionaryAcl","p":1628503}],"n":".ctor","o":"$ctor$3","d":1300823,"h":8591235415,"f":1},{"p":[{"n":"isContainer","p":262145},{"n":"isDS","p":262145},{"n":"rawSecurityDescriptor","p":2808151}],"n":".ctor","o":"$ctor$4","d":1300823,"h":12886202711,"f":1},{"p":[{"n":"isContainer","p":262145},{"n":"isDS","p":262145},{"n":"sddlForm","p":1310721}],"n":".ctor","o":"$ctor$5","d":1300823,"h":17181170007,"f":1}],"h":1300823}; }
            static get $b() { return $.$ssa.System.Security.AccessControl.GenericSecurityDescriptor; }
            static get $fullName() { return `System.Security.AccessControl.CommonSecurityDescriptor`; }
        });
        
        $asm.$cls("$ssa.System.Security.AccessControl.CustomAce", ($self) => class CustomAce extends $.$ssa.System.Security.AccessControl.GenericAce
        {
            /*int*/ static MaxOpaqueLength = 0;
            $ctor$2(/*System.Security.AccessControl.AceType*/ type, /*System.Security.AccessControl.AceFlags*/ flags, /*byte[]?*/ opaque)
            {
                super.$ctor$1();
                {
                }
                return this;
            }
            /*int */ get BinaryLength()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ get OpaqueLength()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*void */ GetBinaryForm(/*byte[]*/ binaryForm, /*int*/ offset)
            {
            }
            /*byte[]? */ GetOpaque()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*void */ SetOpaque(/*byte[]?*/ opaque)
            {
            }
            static $h = 1562967;
            static $f = 0b10010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":1694039,"p":[{"p":655361,"g":{"r":0,"d":0,"h":17181432151,"f":32769},"n":"BinaryLength","d":1562967,"h":12886464855,"f":32769},{"p":655361,"g":{"r":0,"d":0,"h":25771366743,"f":1},"n":"OpaqueLength","d":1562967,"h":21476399447,"f":1}],"m":[{"r":65537,"p":[{"n":"binaryForm","p":0},{"n":"offset","p":655361}],"n":"GetBinaryForm","d":1562967,"h":30066334039,"f":32769},{"r":0,"n":"GetOpaque","d":1562967,"h":34361301335,"f":1},{"r":65537,"p":[{"n":"opaque","p":0}],"n":"SetOpaque","d":1562967,"h":38656268631,"f":1}],"l":[{"t":655361,"n":"MaxOpaqueLength","d":1562967,"h":4296530263,"f":33}],"c":[{"p":[{"n":"type","p":710999},{"n":"flags","p":579927},{"n":"opaque","p":0}],"n":".ctor","o":"$ctor$2","d":1562967,"h":8591497559,"f":1}],"h":1562967}; }
            static get $b() { return $.$ssa.System.Security.AccessControl.GenericAce; }
            static get $fullName() { return `System.Security.AccessControl.CustomAce`; }
        });
        
        $asm.$cls("$ssa.System.Security.AccessControl.RawSecurityDescriptor", ($self) => class RawSecurityDescriptor extends $.$ssa.System.Security.AccessControl.GenericSecurityDescriptor
        {
            $ctor$2(/*byte[]*/ binaryForm, /*int*/ offset)
            {
                super.$ctor$1();
                {
                }
                return this;
            }
            $ctor$3(/*System.Security.AccessControl.ControlFlags*/ flags, /*System.Security.Principal.SecurityIdentifier?*/ owner, /*System.Security.Principal.SecurityIdentifier?*/ group, /*System.Security.AccessControl.RawAcl?*/ systemAcl, /*System.Security.AccessControl.RawAcl?*/ discretionaryAcl)
            {
                super.$ctor$1();
                {
                }
                return this;
            }
            $ctor$4(/*string*/ sddlForm)
            {
                super.$ctor$1();
                {
                }
                return this;
            }
            /*System.Security.AccessControl.ControlFlags */ get ControlFlags()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Security.AccessControl.RawAcl? */ get DiscretionaryAcl()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Security.AccessControl.RawAcl? */ set DiscretionaryAcl(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Security.Principal.SecurityIdentifier? */ get Group()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Security.Principal.SecurityIdentifier? */ set Group(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Security.Principal.SecurityIdentifier? */ get Owner()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Security.Principal.SecurityIdentifier? */ set Owner(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*byte */ get ResourceManagerControl()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*byte */ set ResourceManagerControl(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Security.AccessControl.RawAcl? */ get SystemAcl()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Security.AccessControl.RawAcl? */ set SystemAcl(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*void */ SetFlags(/*System.Security.AccessControl.ControlFlags*/ flags)
            {
            }
            static $h = 2808151;
            static $f = 0b10010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":1825111,"p":[{"p":1497431,"g":{"r":0,"d":0,"h":21477644631,"f":32769},"n":"ControlFlags","d":2808151,"h":17182677335,"f":32769},{"p":2742615,"g":{"r":0,"d":0,"h":30067579223,"f":1},"s":{"r":0,"d":0,"h":34362546519,"f":1},"n":"DiscretionaryAcl","d":2808151,"h":25772611927,"f":1},{"p":443615,"g":{"r":0,"d":0,"h":42952481111,"f":32769},"s":{"r":0,"d":0,"h":47247448407,"f":32769},"n":"Group","d":2808151,"h":38657513815,"f":32769},{"p":443615,"g":{"r":0,"d":0,"h":55837382999,"f":32769},"s":{"r":0,"d":0,"h":60132350295,"f":32769},"n":"Owner","d":2808151,"h":51542415703,"f":32769},{"p":393217,"g":{"r":0,"d":0,"h":68722284887,"f":1},"s":{"r":0,"d":0,"h":73017252183,"f":1},"n":"ResourceManagerControl","d":2808151,"h":64427317591,"f":1},{"p":2742615,"g":{"r":0,"d":0,"h":81607186775,"f":1},"s":{"r":0,"d":0,"h":85902154071,"f":1},"n":"SystemAcl","d":2808151,"h":77312219479,"f":1}],"m":[{"r":65537,"p":[{"n":"flags","p":1497431}],"n":"SetFlags","d":2808151,"h":90197121367,"f":1}],"c":[{"p":[{"n":"binaryForm","p":0},{"n":"offset","p":655361}],"n":".ctor","o":"$ctor$2","d":2808151,"h":4297775447,"f":1},{"p":[{"n":"flags","p":1497431},{"n":"owner","p":443615},{"n":"group","p":443615},{"n":"systemAcl","p":2742615},{"n":"discretionaryAcl","p":2742615}],"n":".ctor","o":"$ctor$3","d":2808151,"h":8592742743,"f":1},{"p":[{"n":"sddlForm","p":1310721}],"n":".ctor","o":"$ctor$4","d":2808151,"h":12887710039,"f":1}],"h":2808151}; }
            static get $b() { return $.$ssa.System.Security.AccessControl.GenericSecurityDescriptor; }
            static get $fullName() { return `System.Security.AccessControl.RawSecurityDescriptor`; }
        });
        
        $asm.$cls("$ssa.System.Security.AccessControl.AuthorizationRuleCollection", ($self) => class AuthorizationRuleCollection extends $.$scn.System.Collections.ReadOnlyCollectionBase
        {
            $ctor$2()
            {
                super.$ctor$1();
                {
                }
                return this;
            }
            /*System.Security.AccessControl.AuthorizationRule?*/ get_Item(/*int*/ index)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*void */ AddRule(/*System.Security.AccessControl.AuthorizationRule?*/ rule)
            {
            }
            /*void */ CopyTo(/*System.Security.AccessControl.AuthorizationRule[]*/ rules, /*int*/ index)
            {
            }
            static $h = 1038679;
            static $f = 0b10010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":589859,"p":[{"p":973143,"i":[{"n":"index","p":655361}],"g":{"r":0,"d":0,"h":12885940567,"f":1},"n":"Item","o":"@$2","d":1038679,"h":8590973271,"f":1}],"m":[{"r":65537,"p":[{"n":"rule","p":973143}],"n":"AddRule","d":1038679,"h":17180907863,"f":1},{"r":65537,"p":[{"n":"rules","p":0},{"n":"index","p":655361}],"n":"CopyTo","d":1038679,"h":21475875159,"f":1}],"c":[{"n":".ctor","o":"$ctor$2","d":1038679,"h":4296005975,"f":1}],"i":[31326209,31588353],"h":1038679}; }
            static get $b() { return $.$scn.System.Collections.ReadOnlyCollectionBase; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.Collections.ICollection, $.$spc.System.Collections.IEnumerable ]; }
            static get $fullName() { return `System.Security.AccessControl.AuthorizationRuleCollection`; }
        });
        
        $asm.$cls("$ssa.System.Security.AccessControl.RawAcl", ($self) => class RawAcl extends $.$ssa.System.Security.AccessControl.GenericAcl
        {
            $ctor$2(/*byte*/ revision, /*int*/ capacity)
            {
                super.$ctor$1();
                {
                }
                return this;
            }
            $ctor$3(/*byte[]*/ binaryForm, /*int*/ offset)
            {
                super.$ctor$1();
                {
                }
                return this;
            }
            /*int */ get BinaryLength()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ get Count()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Security.AccessControl.GenericAce*/ get_Item(/*int*/ index)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*void*/ set_Item(/*int*/ index, /*System.Security.AccessControl.GenericAce*/ value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*byte */ get Revision()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*void */ GetBinaryForm(/*byte[]*/ binaryForm, /*int*/ offset)
            {
            }
            /*void */ InsertAce(/*int*/ index, /*System.Security.AccessControl.GenericAce*/ ace)
            {
            }
            /*void */ RemoveAce(/*int*/ index)
            {
            }
            static $h = 2742615;
            static $f = 0b10010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":1759575,"p":[{"p":655361,"g":{"r":0,"d":0,"h":17182611799,"f":32769},"n":"BinaryLength","d":2742615,"h":12887644503,"f":32769},{"p":655361,"g":{"r":0,"d":0,"h":25772546391,"f":32769},"n":"Count","d":2742615,"h":21477579095,"f":32769},{"p":1694039,"i":[{"n":"index","p":655361}],"g":{"r":0,"d":0,"h":34362480983,"f":32769},"s":{"r":0,"d":0,"h":38657448279,"f":32769},"n":"Item","o":"@$2","d":2742615,"h":30067513687,"f":32769},{"p":393217,"g":{"r":0,"d":0,"h":47247382871,"f":32769},"n":"Revision","d":2742615,"h":42952415575,"f":32769}],"m":[{"r":65537,"p":[{"n":"binaryForm","p":0},{"n":"offset","p":655361}],"n":"GetBinaryForm","d":2742615,"h":51542350167,"f":32769},{"r":65537,"p":[{"n":"index","p":655361},{"n":"ace","p":1694039}],"n":"InsertAce","d":2742615,"h":55837317463,"f":1},{"r":65537,"p":[{"n":"index","p":655361}],"n":"RemoveAce","d":2742615,"h":60132284759,"f":1}],"c":[{"p":[{"n":"revision","p":393217},{"n":"capacity","p":655361}],"n":".ctor","o":"$ctor$2","d":2742615,"h":4297709911,"f":1},{"p":[{"n":"binaryForm","p":0},{"n":"offset","p":655361}],"n":".ctor","o":"$ctor$3","d":2742615,"h":8592677207,"f":1}],"i":[31326209,31588353],"h":2742615}; }
            static get $b() { return $.$ssa.System.Security.AccessControl.GenericAcl; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.Collections.ICollection, $.$spc.System.Collections.IEnumerable ]; }
            static get $fullName() { return `System.Security.AccessControl.RawAcl`; }
        });
        
        $asm.$cls("$ssa.System.Security.AccessControl.AccessRule<>", (T) => $asm.$gt("$ssa.System.Security.AccessControl.AccessRule<>", [T], ($self) => class AccessRule$$ extends $.$ssa.System.Security.AccessControl.AccessRule
        {
            $ctor$3(/*System.Security.Principal.IdentityReference*/ identity, /*T*/ rights, /*System.Security.AccessControl.AccessControlType*/ type)
            {
                super.$ctor$2(null, 0, false, 0, 0, 0);
                {
                }
                return this;
            }
            $ctor$4(/*System.Security.Principal.IdentityReference*/ identity, /*T*/ rights, /*System.Security.AccessControl.InheritanceFlags*/ inheritanceFlags, /*System.Security.AccessControl.PropagationFlags*/ propagationFlags, /*System.Security.AccessControl.AccessControlType*/ type)
            {
                super.$ctor$2(null, 0, false, 0, 0, 0);
                {
                }
                return this;
            }
            $ctor$5(/*string*/ identity, /*T*/ rights, /*System.Security.AccessControl.AccessControlType*/ type)
            {
                super.$ctor$2(null, 0, false, 0, 0, 0);
                {
                }
                return this;
            }
            $ctor$6(/*string*/ identity, /*T*/ rights, /*System.Security.AccessControl.InheritanceFlags*/ inheritanceFlags, /*System.Security.AccessControl.PropagationFlags*/ propagationFlags, /*System.Security.AccessControl.AccessControlType*/ type)
            {
                super.$ctor$2(null, 0, false, 0, 0, 0);
                {
                }
                return this;
            }
            /*T */ get Rights()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static $h = 448855;
            static $g = 1;
            static $f = 0b1010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":383319,"p":[{"p":T?.$h??1507328,"g":{"r":0,"d":0,"h":Number(BigInt(this.$h)|0x600000000n),"f":1},"n":"Rights","d":this.$h,"h":Number(BigInt(this.$h)|0x500000000n),"f":1}],"c":[{"p":[{"n":"identity","p":247007},{"n":"rights","p":T?.$h??1507328},{"n":"type","p":317783}],"n":".ctor","o":"$ctor$3","d":this.$h,"h":Number(BigInt(this.$h)|0x100000000n),"f":1},{"p":[{"n":"identity","p":247007},{"n":"rights","p":T?.$h??1507328},{"n":"inheritanceFlags","p":1890647},{"n":"propagationFlags","p":2611543},{"n":"type","p":317783}],"n":".ctor","o":"$ctor$4","d":this.$h,"h":Number(BigInt(this.$h)|0x200000000n),"f":1},{"p":[{"n":"identity","p":1310721},{"n":"rights","p":T?.$h??1507328},{"n":"type","p":317783}],"n":".ctor","o":"$ctor$5","d":this.$h,"h":Number(BigInt(this.$h)|0x300000000n),"f":1},{"p":[{"n":"identity","p":1310721},{"n":"rights","p":T?.$h??1507328},{"n":"inheritanceFlags","p":1890647},{"n":"propagationFlags","p":2611543},{"n":"type","p":317783}],"n":".ctor","o":"$ctor$6","d":this.$h,"h":Number(BigInt(this.$h)|0x400000000n),"f":1}],"g":[T?.$h??1507328],"s":[{"n":"T","f":2}],"r":1,"h":this.$h}; }
            static get $b() { return $.$ssa.System.Security.AccessControl.AccessRule; }
            static get $fullName() { return `System.Security.AccessControl.AccessRule<${T?.$fullName}>`; }
        }));
        
        $asm.$cls("$ssa.System.Security.AccessControl.AuditRule<>", (T) => $asm.$gt("$ssa.System.Security.AccessControl.AuditRule<>", [T], ($self) => class AuditRule$$ extends $.$ssa.System.Security.AccessControl.AuditRule
        {
            $ctor$3(/*System.Security.Principal.IdentityReference*/ identity, /*T*/ rights, /*System.Security.AccessControl.AuditFlags*/ flags)
            {
                super.$ctor$2(null, 0, false, 0, 0, 0);
                {
                }
                return this;
            }
            $ctor$4(/*System.Security.Principal.IdentityReference*/ identity, /*T*/ rights, /*System.Security.AccessControl.InheritanceFlags*/ inheritanceFlags, /*System.Security.AccessControl.PropagationFlags*/ propagationFlags, /*System.Security.AccessControl.AuditFlags*/ flags)
            {
                super.$ctor$2(null, 0, false, 0, 0, 0);
                {
                }
                return this;
            }
            $ctor$5(/*string*/ identity, /*T*/ rights, /*System.Security.AccessControl.AuditFlags*/ flags)
            {
                super.$ctor$2(null, 0, false, 0, 0, 0);
                {
                }
                return this;
            }
            $ctor$6(/*string*/ identity, /*T*/ rights, /*System.Security.AccessControl.InheritanceFlags*/ inheritanceFlags, /*System.Security.AccessControl.PropagationFlags*/ propagationFlags, /*System.Security.AccessControl.AuditFlags*/ flags)
            {
                super.$ctor$2(null, 0, false, 0, 0, 0);
                {
                }
                return this;
            }
            /*T */ get Rights()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static $h = 907607;
            static $g = 1;
            static $f = 0b1010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":842071,"p":[{"p":T?.$h??1507328,"g":{"r":0,"d":0,"h":Number(BigInt(this.$h)|0x600000000n),"f":1},"n":"Rights","d":this.$h,"h":Number(BigInt(this.$h)|0x500000000n),"f":1}],"c":[{"p":[{"n":"identity","p":247007},{"n":"rights","p":T?.$h??1507328},{"n":"flags","p":776535}],"n":".ctor","o":"$ctor$3","d":this.$h,"h":Number(BigInt(this.$h)|0x100000000n),"f":1},{"p":[{"n":"identity","p":247007},{"n":"rights","p":T?.$h??1507328},{"n":"inheritanceFlags","p":1890647},{"n":"propagationFlags","p":2611543},{"n":"flags","p":776535}],"n":".ctor","o":"$ctor$4","d":this.$h,"h":Number(BigInt(this.$h)|0x200000000n),"f":1},{"p":[{"n":"identity","p":1310721},{"n":"rights","p":T?.$h??1507328},{"n":"flags","p":776535}],"n":".ctor","o":"$ctor$5","d":this.$h,"h":Number(BigInt(this.$h)|0x300000000n),"f":1},{"p":[{"n":"identity","p":1310721},{"n":"rights","p":T?.$h??1507328},{"n":"inheritanceFlags","p":1890647},{"n":"propagationFlags","p":2611543},{"n":"flags","p":776535}],"n":".ctor","o":"$ctor$6","d":this.$h,"h":Number(BigInt(this.$h)|0x400000000n),"f":1}],"g":[T?.$h??1507328],"s":[{"n":"T","f":2}],"r":1,"h":this.$h}; }
            static get $b() { return $.$ssa.System.Security.AccessControl.AuditRule; }
            static get $fullName() { return `System.Security.AccessControl.AuditRule<${T?.$fullName}>`; }
        }));
        
        $asm.$cls("$ssa.System.Security.AccessControl.CompoundAce", ($self) => class CompoundAce extends $.$ssa.System.Security.AccessControl.KnownAce
        {
            $ctor$3(/*System.Security.AccessControl.AceFlags*/ flags, /*int*/ accessMask, /*System.Security.AccessControl.CompoundAceType*/ compoundAceType, /*System.Security.Principal.SecurityIdentifier*/ sid)
            {
                super.$ctor$2();
                {
                }
                return this;
            }
            /*int */ get BinaryLength()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Security.AccessControl.CompoundAceType */ get CompoundAceType()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Security.AccessControl.CompoundAceType */ set CompoundAceType(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*void */ GetBinaryForm(/*byte[]*/ binaryForm, /*int*/ offset)
            {
            }
            static $h = 1366359;
            static $f = 0b10010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":1956183,"p":[{"p":655361,"g":{"r":0,"d":0,"h":12886268247,"f":32769},"n":"BinaryLength","d":1366359,"h":8591300951,"f":32769},{"p":1431895,"g":{"r":0,"d":0,"h":21476202839,"f":1},"s":{"r":0,"d":0,"h":25771170135,"f":1},"n":"CompoundAceType","d":1366359,"h":17181235543,"f":1}],"m":[{"r":65537,"p":[{"n":"binaryForm","p":0},{"n":"offset","p":655361}],"n":"GetBinaryForm","d":1366359,"h":30066137431,"f":32769}],"c":[{"p":[{"n":"flags","p":579927},{"n":"accessMask","p":655361},{"n":"compoundAceType","p":1431895},{"n":"sid","p":443615}],"n":".ctor","o":"$ctor$3","d":1366359,"h":4296333655,"f":1}],"h":1366359}; }
            static get $b() { return $.$ssa.System.Security.AccessControl.KnownAce; }
            static get $fullName() { return `System.Security.AccessControl.CompoundAce`; }
        });
        
        $asm.$cls("$ssa.System.Security.AccessControl.DiscretionaryAcl", ($self) => class DiscretionaryAcl extends $.$ssa.System.Security.AccessControl.CommonAcl
        {
            $ctor$3(/*bool*/ isContainer, /*bool*/ isDS, /*byte*/ revision, /*int*/ capacity)
            {
                super.$ctor$2();
                {
                }
                return this;
            }
            $ctor$4(/*bool*/ isContainer, /*bool*/ isDS, /*int*/ capacity)
            {
                super.$ctor$2();
                {
                }
                return this;
            }
            $ctor$5(/*bool*/ isContainer, /*bool*/ isDS, /*System.Security.AccessControl.RawAcl?*/ rawAcl)
            {
                super.$ctor$2();
                {
                }
                return this;
            }
            /*void */ AddAccess(/*System.Security.AccessControl.AccessControlType*/ accessType, /*System.Security.Principal.SecurityIdentifier*/ sid, /*int*/ accessMask, /*System.Security.AccessControl.InheritanceFlags*/ inheritanceFlags, /*System.Security.AccessControl.PropagationFlags*/ propagationFlags)
            {
            }
            /*void */ AddAccess$1(/*System.Security.AccessControl.AccessControlType*/ accessType, /*System.Security.Principal.SecurityIdentifier*/ sid, /*int*/ accessMask, /*System.Security.AccessControl.InheritanceFlags*/ inheritanceFlags, /*System.Security.AccessControl.PropagationFlags*/ propagationFlags, /*System.Security.AccessControl.ObjectAceFlags*/ objectFlags, /*System.Guid*/ objectType, /*System.Guid*/ inheritedObjectType)
            {
            }
            /*void */ AddAccess$2(/*System.Security.AccessControl.AccessControlType*/ accessType, /*System.Security.Principal.SecurityIdentifier*/ sid, /*System.Security.AccessControl.ObjectAccessRule*/ rule)
            {
            }
            /*bool */ RemoveAccess(/*System.Security.AccessControl.AccessControlType*/ accessType, /*System.Security.Principal.SecurityIdentifier*/ sid, /*int*/ accessMask, /*System.Security.AccessControl.InheritanceFlags*/ inheritanceFlags, /*System.Security.AccessControl.PropagationFlags*/ propagationFlags)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ RemoveAccess$1(/*System.Security.AccessControl.AccessControlType*/ accessType, /*System.Security.Principal.SecurityIdentifier*/ sid, /*int*/ accessMask, /*System.Security.AccessControl.InheritanceFlags*/ inheritanceFlags, /*System.Security.AccessControl.PropagationFlags*/ propagationFlags, /*System.Security.AccessControl.ObjectAceFlags*/ objectFlags, /*System.Guid*/ objectType, /*System.Guid*/ inheritedObjectType)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ RemoveAccess$2(/*System.Security.AccessControl.AccessControlType*/ accessType, /*System.Security.Principal.SecurityIdentifier*/ sid, /*System.Security.AccessControl.ObjectAccessRule*/ rule)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*void */ RemoveAccessSpecific(/*System.Security.AccessControl.AccessControlType*/ accessType, /*System.Security.Principal.SecurityIdentifier*/ sid, /*int*/ accessMask, /*System.Security.AccessControl.InheritanceFlags*/ inheritanceFlags, /*System.Security.AccessControl.PropagationFlags*/ propagationFlags)
            {
            }
            /*void */ RemoveAccessSpecific$1(/*System.Security.AccessControl.AccessControlType*/ accessType, /*System.Security.Principal.SecurityIdentifier*/ sid, /*int*/ accessMask, /*System.Security.AccessControl.InheritanceFlags*/ inheritanceFlags, /*System.Security.AccessControl.PropagationFlags*/ propagationFlags, /*System.Security.AccessControl.ObjectAceFlags*/ objectFlags, /*System.Guid*/ objectType, /*System.Guid*/ inheritedObjectType)
            {
            }
            /*void */ RemoveAccessSpecific$2(/*System.Security.AccessControl.AccessControlType*/ accessType, /*System.Security.Principal.SecurityIdentifier*/ sid, /*System.Security.AccessControl.ObjectAccessRule*/ rule)
            {
            }
            /*void */ SetAccess(/*System.Security.AccessControl.AccessControlType*/ accessType, /*System.Security.Principal.SecurityIdentifier*/ sid, /*int*/ accessMask, /*System.Security.AccessControl.InheritanceFlags*/ inheritanceFlags, /*System.Security.AccessControl.PropagationFlags*/ propagationFlags)
            {
            }
            /*void */ SetAccess$1(/*System.Security.AccessControl.AccessControlType*/ accessType, /*System.Security.Principal.SecurityIdentifier*/ sid, /*int*/ accessMask, /*System.Security.AccessControl.InheritanceFlags*/ inheritanceFlags, /*System.Security.AccessControl.PropagationFlags*/ propagationFlags, /*System.Security.AccessControl.ObjectAceFlags*/ objectFlags, /*System.Guid*/ objectType, /*System.Guid*/ inheritedObjectType)
            {
            }
            /*void */ SetAccess$2(/*System.Security.AccessControl.AccessControlType*/ accessType, /*System.Security.Principal.SecurityIdentifier*/ sid, /*System.Security.AccessControl.ObjectAccessRule*/ rule)
            {
            }
            static $h = 1628503;
            static $f = 0b10010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":1169751,"m":[{"r":65537,"p":[{"n":"accessType","p":317783},{"n":"sid","p":443615},{"n":"accessMask","p":655361},{"n":"inheritanceFlags","p":1890647},{"n":"propagationFlags","p":2611543}],"n":"AddAccess","d":1628503,"h":17181497687,"f":1},{"r":65537,"p":[{"n":"accessType","p":317783},{"n":"sid","p":443615},{"n":"accessMask","p":655361},{"n":"inheritanceFlags","p":1890647},{"n":"propagationFlags","p":2611543},{"n":"objectFlags","p":2283863},{"n":"objectType","p":56164353},{"n":"inheritedObjectType","p":56164353}],"n":"AddAccess","o":"@$1","d":1628503,"h":21476464983,"f":1},{"r":65537,"p":[{"n":"accessType","p":317783},{"n":"sid","p":443615},{"n":"rule","p":2152791}],"n":"AddAccess","o":"@$2","d":1628503,"h":25771432279,"f":1},{"r":262145,"p":[{"n":"accessType","p":317783},{"n":"sid","p":443615},{"n":"accessMask","p":655361},{"n":"inheritanceFlags","p":1890647},{"n":"propagationFlags","p":2611543}],"n":"RemoveAccess","d":1628503,"h":30066399575,"f":1},{"r":262145,"p":[{"n":"accessType","p":317783},{"n":"sid","p":443615},{"n":"accessMask","p":655361},{"n":"inheritanceFlags","p":1890647},{"n":"propagationFlags","p":2611543},{"n":"objectFlags","p":2283863},{"n":"objectType","p":56164353},{"n":"inheritedObjectType","p":56164353}],"n":"RemoveAccess","o":"@$1","d":1628503,"h":34361366871,"f":1},{"r":262145,"p":[{"n":"accessType","p":317783},{"n":"sid","p":443615},{"n":"rule","p":2152791}],"n":"RemoveAccess","o":"@$2","d":1628503,"h":38656334167,"f":1},{"r":65537,"p":[{"n":"accessType","p":317783},{"n":"sid","p":443615},{"n":"accessMask","p":655361},{"n":"inheritanceFlags","p":1890647},{"n":"propagationFlags","p":2611543}],"n":"RemoveAccessSpecific","d":1628503,"h":42951301463,"f":1},{"r":65537,"p":[{"n":"accessType","p":317783},{"n":"sid","p":443615},{"n":"accessMask","p":655361},{"n":"inheritanceFlags","p":1890647},{"n":"propagationFlags","p":2611543},{"n":"objectFlags","p":2283863},{"n":"objectType","p":56164353},{"n":"inheritedObjectType","p":56164353}],"n":"RemoveAccessSpecific","o":"@$1","d":1628503,"h":47246268759,"f":1},{"r":65537,"p":[{"n":"accessType","p":317783},{"n":"sid","p":443615},{"n":"rule","p":2152791}],"n":"RemoveAccessSpecific","o":"@$2","d":1628503,"h":51541236055,"f":1},{"r":65537,"p":[{"n":"accessType","p":317783},{"n":"sid","p":443615},{"n":"accessMask","p":655361},{"n":"inheritanceFlags","p":1890647},{"n":"propagationFlags","p":2611543}],"n":"SetAccess","d":1628503,"h":55836203351,"f":1},{"r":65537,"p":[{"n":"accessType","p":317783},{"n":"sid","p":443615},{"n":"accessMask","p":655361},{"n":"inheritanceFlags","p":1890647},{"n":"propagationFlags","p":2611543},{"n":"objectFlags","p":2283863},{"n":"objectType","p":56164353},{"n":"inheritedObjectType","p":56164353}],"n":"SetAccess","o":"@$1","d":1628503,"h":60131170647,"f":1},{"r":65537,"p":[{"n":"accessType","p":317783},{"n":"sid","p":443615},{"n":"rule","p":2152791}],"n":"SetAccess","o":"@$2","d":1628503,"h":64426137943,"f":1}],"c":[{"p":[{"n":"isContainer","p":262145},{"n":"isDS","p":262145},{"n":"revision","p":393217},{"n":"capacity","p":655361}],"n":".ctor","o":"$ctor$3","d":1628503,"h":4296595799,"f":1},{"p":[{"n":"isContainer","p":262145},{"n":"isDS","p":262145},{"n":"capacity","p":655361}],"n":".ctor","o":"$ctor$4","d":1628503,"h":8591563095,"f":1},{"p":[{"n":"isContainer","p":262145},{"n":"isDS","p":262145},{"n":"rawAcl","p":2742615}],"n":".ctor","o":"$ctor$5","d":1628503,"h":12886530391,"f":1}],"i":[31326209,31588353],"h":1628503}; }
            static get $b() { return $.$ssa.System.Security.AccessControl.CommonAcl; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.Collections.ICollection, $.$spc.System.Collections.IEnumerable ]; }
            static get $fullName() { return `System.Security.AccessControl.DiscretionaryAcl`; }
        });
        
        $asm.$cls("$ssa.System.Security.AccessControl.SystemAcl", ($self) => class SystemAcl extends $.$ssa.System.Security.AccessControl.CommonAcl
        {
            $ctor$3(/*bool*/ isContainer, /*bool*/ isDS, /*byte*/ revision, /*int*/ capacity)
            {
                super.$ctor$2();
                {
                }
                return this;
            }
            $ctor$4(/*bool*/ isContainer, /*bool*/ isDS, /*int*/ capacity)
            {
                super.$ctor$2();
                {
                }
                return this;
            }
            $ctor$5(/*bool*/ isContainer, /*bool*/ isDS, /*System.Security.AccessControl.RawAcl*/ rawAcl)
            {
                super.$ctor$2();
                {
                }
                return this;
            }
            /*void */ AddAudit(/*System.Security.AccessControl.AuditFlags*/ auditFlags, /*System.Security.Principal.SecurityIdentifier*/ sid, /*int*/ accessMask, /*System.Security.AccessControl.InheritanceFlags*/ inheritanceFlags, /*System.Security.AccessControl.PropagationFlags*/ propagationFlags)
            {
            }
            /*void */ AddAudit$1(/*System.Security.AccessControl.AuditFlags*/ auditFlags, /*System.Security.Principal.SecurityIdentifier*/ sid, /*int*/ accessMask, /*System.Security.AccessControl.InheritanceFlags*/ inheritanceFlags, /*System.Security.AccessControl.PropagationFlags*/ propagationFlags, /*System.Security.AccessControl.ObjectAceFlags*/ objectFlags, /*System.Guid*/ objectType, /*System.Guid*/ inheritedObjectType)
            {
            }
            /*void */ AddAudit$2(/*System.Security.Principal.SecurityIdentifier*/ sid, /*System.Security.AccessControl.ObjectAuditRule*/ rule)
            {
            }
            /*bool */ RemoveAudit(/*System.Security.AccessControl.AuditFlags*/ auditFlags, /*System.Security.Principal.SecurityIdentifier*/ sid, /*int*/ accessMask, /*System.Security.AccessControl.InheritanceFlags*/ inheritanceFlags, /*System.Security.AccessControl.PropagationFlags*/ propagationFlags)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ RemoveAudit$1(/*System.Security.AccessControl.AuditFlags*/ auditFlags, /*System.Security.Principal.SecurityIdentifier*/ sid, /*int*/ accessMask, /*System.Security.AccessControl.InheritanceFlags*/ inheritanceFlags, /*System.Security.AccessControl.PropagationFlags*/ propagationFlags, /*System.Security.AccessControl.ObjectAceFlags*/ objectFlags, /*System.Guid*/ objectType, /*System.Guid*/ inheritedObjectType)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ RemoveAudit$2(/*System.Security.Principal.SecurityIdentifier*/ sid, /*System.Security.AccessControl.ObjectAuditRule*/ rule)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*void */ RemoveAuditSpecific(/*System.Security.AccessControl.AuditFlags*/ auditFlags, /*System.Security.Principal.SecurityIdentifier*/ sid, /*int*/ accessMask, /*System.Security.AccessControl.InheritanceFlags*/ inheritanceFlags, /*System.Security.AccessControl.PropagationFlags*/ propagationFlags)
            {
            }
            /*void */ RemoveAuditSpecific$1(/*System.Security.AccessControl.AuditFlags*/ auditFlags, /*System.Security.Principal.SecurityIdentifier*/ sid, /*int*/ accessMask, /*System.Security.AccessControl.InheritanceFlags*/ inheritanceFlags, /*System.Security.AccessControl.PropagationFlags*/ propagationFlags, /*System.Security.AccessControl.ObjectAceFlags*/ objectFlags, /*System.Guid*/ objectType, /*System.Guid*/ inheritedObjectType)
            {
            }
            /*void */ RemoveAuditSpecific$2(/*System.Security.Principal.SecurityIdentifier*/ sid, /*System.Security.AccessControl.ObjectAuditRule*/ rule)
            {
            }
            /*void */ SetAudit(/*System.Security.AccessControl.AuditFlags*/ auditFlags, /*System.Security.Principal.SecurityIdentifier*/ sid, /*int*/ accessMask, /*System.Security.AccessControl.InheritanceFlags*/ inheritanceFlags, /*System.Security.AccessControl.PropagationFlags*/ propagationFlags)
            {
            }
            /*void */ SetAudit$1(/*System.Security.AccessControl.AuditFlags*/ auditFlags, /*System.Security.Principal.SecurityIdentifier*/ sid, /*int*/ accessMask, /*System.Security.AccessControl.InheritanceFlags*/ inheritanceFlags, /*System.Security.AccessControl.PropagationFlags*/ propagationFlags, /*System.Security.AccessControl.ObjectAceFlags*/ objectFlags, /*System.Guid*/ objectType, /*System.Guid*/ inheritedObjectType)
            {
            }
            /*void */ SetAudit$2(/*System.Security.Principal.SecurityIdentifier*/ sid, /*System.Security.AccessControl.ObjectAuditRule*/ rule)
            {
            }
            static $h = 3004759;
            static $f = 0b10010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":1169751,"m":[{"r":65537,"p":[{"n":"auditFlags","p":776535},{"n":"sid","p":443615},{"n":"accessMask","p":655361},{"n":"inheritanceFlags","p":1890647},{"n":"propagationFlags","p":2611543}],"n":"AddAudit","d":3004759,"h":17182873943,"f":1},{"r":65537,"p":[{"n":"auditFlags","p":776535},{"n":"sid","p":443615},{"n":"accessMask","p":655361},{"n":"inheritanceFlags","p":1890647},{"n":"propagationFlags","p":2611543},{"n":"objectFlags","p":2283863},{"n":"objectType","p":56164353},{"n":"inheritedObjectType","p":56164353}],"n":"AddAudit","o":"@$1","d":3004759,"h":21477841239,"f":1},{"r":65537,"p":[{"n":"sid","p":443615},{"n":"rule","p":2349399}],"n":"AddAudit","o":"@$2","d":3004759,"h":25772808535,"f":1},{"r":262145,"p":[{"n":"auditFlags","p":776535},{"n":"sid","p":443615},{"n":"accessMask","p":655361},{"n":"inheritanceFlags","p":1890647},{"n":"propagationFlags","p":2611543}],"n":"RemoveAudit","d":3004759,"h":30067775831,"f":1},{"r":262145,"p":[{"n":"auditFlags","p":776535},{"n":"sid","p":443615},{"n":"accessMask","p":655361},{"n":"inheritanceFlags","p":1890647},{"n":"propagationFlags","p":2611543},{"n":"objectFlags","p":2283863},{"n":"objectType","p":56164353},{"n":"inheritedObjectType","p":56164353}],"n":"RemoveAudit","o":"@$1","d":3004759,"h":34362743127,"f":1},{"r":262145,"p":[{"n":"sid","p":443615},{"n":"rule","p":2349399}],"n":"RemoveAudit","o":"@$2","d":3004759,"h":38657710423,"f":1},{"r":65537,"p":[{"n":"auditFlags","p":776535},{"n":"sid","p":443615},{"n":"accessMask","p":655361},{"n":"inheritanceFlags","p":1890647},{"n":"propagationFlags","p":2611543}],"n":"RemoveAuditSpecific","d":3004759,"h":42952677719,"f":1},{"r":65537,"p":[{"n":"auditFlags","p":776535},{"n":"sid","p":443615},{"n":"accessMask","p":655361},{"n":"inheritanceFlags","p":1890647},{"n":"propagationFlags","p":2611543},{"n":"objectFlags","p":2283863},{"n":"objectType","p":56164353},{"n":"inheritedObjectType","p":56164353}],"n":"RemoveAuditSpecific","o":"@$1","d":3004759,"h":47247645015,"f":1},{"r":65537,"p":[{"n":"sid","p":443615},{"n":"rule","p":2349399}],"n":"RemoveAuditSpecific","o":"@$2","d":3004759,"h":51542612311,"f":1},{"r":65537,"p":[{"n":"auditFlags","p":776535},{"n":"sid","p":443615},{"n":"accessMask","p":655361},{"n":"inheritanceFlags","p":1890647},{"n":"propagationFlags","p":2611543}],"n":"SetAudit","d":3004759,"h":55837579607,"f":1},{"r":65537,"p":[{"n":"auditFlags","p":776535},{"n":"sid","p":443615},{"n":"accessMask","p":655361},{"n":"inheritanceFlags","p":1890647},{"n":"propagationFlags","p":2611543},{"n":"objectFlags","p":2283863},{"n":"objectType","p":56164353},{"n":"inheritedObjectType","p":56164353}],"n":"SetAudit","o":"@$1","d":3004759,"h":60132546903,"f":1},{"r":65537,"p":[{"n":"sid","p":443615},{"n":"rule","p":2349399}],"n":"SetAudit","o":"@$2","d":3004759,"h":64427514199,"f":1}],"c":[{"p":[{"n":"isContainer","p":262145},{"n":"isDS","p":262145},{"n":"revision","p":393217},{"n":"capacity","p":655361}],"n":".ctor","o":"$ctor$3","d":3004759,"h":4297972055,"f":1},{"p":[{"n":"isContainer","p":262145},{"n":"isDS","p":262145},{"n":"capacity","p":655361}],"n":".ctor","o":"$ctor$4","d":3004759,"h":8592939351,"f":1},{"p":[{"n":"isContainer","p":262145},{"n":"isDS","p":262145},{"n":"rawAcl","p":2742615}],"n":".ctor","o":"$ctor$5","d":3004759,"h":12887906647,"f":1}],"i":[31326209,31588353],"h":3004759}; }
            static get $b() { return $.$ssa.System.Security.AccessControl.CommonAcl; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.Collections.ICollection, $.$spc.System.Collections.IEnumerable ]; }
            static get $fullName() { return `System.Security.AccessControl.SystemAcl`; }
        });
        
        $asm.$str("$ssa.System.Security.AccessControl.AccessControlActions", ($self) => class AccessControlActions extends $.$spc.System.Enum
        {
            static None = 0;
            static View = 1;
            static Change = 2;
            static $map;
            static get Map()
            {
                return this.$map ??= 
                {
                    "None": 0n,
                    "View": 1n,
                    "Change": 2n
                };
            }
            static $h = 121175;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static get $eut() { return $.$spc.System.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {"b":1048577,"u":655361,"l":[{"t":121175,"n":"None","d":121175,"h":4295088471,"f":33},{"t":121175,"n":"View","d":121175,"h":8590055767,"f":33},{"t":121175,"n":"Change","d":121175,"h":12885023063,"f":33}],"c":[{"n":".ctor","o":"$ctor$3","d":121175,"h":17179990359,"f":1}],"i":[57212929,63766529,57671681,57344001],"h":121175,"a":[{"t":47644673,"c":4342611969}]}; }
            static get $b() { return $.$spc.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IComparable, $.$spc.System.ISpanFormattable, $.$spc.System.IFormattable, $.$spc.System.IConvertible ]; }
            static get $fullName() { return `System.Security.AccessControl.AccessControlActions`; }
        });
        
        $asm.$str("$ssa.System.Security.AccessControl.AccessControlModification", ($self) => class AccessControlModification extends $.$spc.System.Enum
        {
            static Add = 0;
            static Set = 1;
            static Reset = 2;
            static Remove = 3;
            static RemoveAll = 4;
            static RemoveSpecific = 5;
            static $map;
            static get Map()
            {
                return this.$map ??= 
                {
                    "Add": 0n,
                    "Set": 1n,
                    "Reset": 2n,
                    "Remove": 3n,
                    "RemoveAll": 4n,
                    "RemoveSpecific": 5n
                };
            }
            static $h = 186711;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static get $eut() { return $.$spc.System.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {"b":1048577,"u":655361,"l":[{"t":186711,"n":"Add","d":186711,"h":4295154007,"f":33},{"t":186711,"n":"Set","d":186711,"h":8590121303,"f":33},{"t":186711,"n":"Reset","d":186711,"h":12885088599,"f":33},{"t":186711,"n":"Remove","d":186711,"h":17180055895,"f":33},{"t":186711,"n":"RemoveAll","d":186711,"h":21475023191,"f":33},{"t":186711,"n":"RemoveSpecific","d":186711,"h":25769990487,"f":33}],"c":[{"n":".ctor","o":"$ctor$3","d":186711,"h":30064957783,"f":1}],"i":[57212929,63766529,57671681,57344001],"h":186711}; }
            static get $b() { return $.$spc.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IComparable, $.$spc.System.ISpanFormattable, $.$spc.System.IFormattable, $.$spc.System.IConvertible ]; }
            static get $fullName() { return `System.Security.AccessControl.AccessControlModification`; }
        });
        
        $asm.$str("$ssa.System.Security.AccessControl.AccessControlSections", ($self) => class AccessControlSections extends $.$spc.System.Enum
        {
            static None = 0;
            static Audit = 1;
            static Access = 2;
            static Owner = 4;
            static Group = 8;
            static All = 15;
            static $map;
            static get Map()
            {
                return this.$map ??= 
                {
                    "None": 0n,
                    "Audit": 1n,
                    "Access": 2n,
                    "Owner": 4n,
                    "Group": 8n,
                    "All": 15n
                };
            }
            static $h = 252247;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static get $eut() { return $.$spc.System.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {"b":1048577,"u":655361,"l":[{"t":252247,"n":"None","d":252247,"h":4295219543,"f":33},{"t":252247,"n":"Audit","d":252247,"h":8590186839,"f":33},{"t":252247,"n":"Access","d":252247,"h":12885154135,"f":33},{"t":252247,"n":"Owner","d":252247,"h":17180121431,"f":33},{"t":252247,"n":"Group","d":252247,"h":21475088727,"f":33},{"t":252247,"n":"All","d":252247,"h":25770056023,"f":33}],"c":[{"n":".ctor","o":"$ctor$3","d":252247,"h":30065023319,"f":1}],"i":[57212929,63766529,57671681,57344001],"h":252247,"a":[{"t":47644673,"c":4342611969}]}; }
            static get $b() { return $.$spc.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IComparable, $.$spc.System.ISpanFormattable, $.$spc.System.IFormattable, $.$spc.System.IConvertible ]; }
            static get $fullName() { return `System.Security.AccessControl.AccessControlSections`; }
        });
        
        $asm.$str("$ssa.System.Security.AccessControl.AccessControlType", ($self) => class AccessControlType extends $.$spc.System.Enum
        {
            static Allow = 0;
            static Deny = 1;
            static $map;
            static get Map()
            {
                return this.$map ??= 
                {
                    "Allow": 0n,
                    "Deny": 1n
                };
            }
            static $h = 317783;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static get $eut() { return $.$spc.System.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {"b":1048577,"u":655361,"l":[{"t":317783,"n":"Allow","d":317783,"h":4295285079,"f":33},{"t":317783,"n":"Deny","d":317783,"h":8590252375,"f":33}],"c":[{"n":".ctor","o":"$ctor$3","d":317783,"h":12885219671,"f":1}],"i":[57212929,63766529,57671681,57344001],"h":317783}; }
            static get $b() { return $.$spc.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IComparable, $.$spc.System.ISpanFormattable, $.$spc.System.IFormattable, $.$spc.System.IConvertible ]; }
            static get $fullName() { return `System.Security.AccessControl.AccessControlType`; }
        });
        
        $asm.$str("$ssa.System.Security.AccessControl.AceFlags", ($self) => class AceFlags extends $.$spc.System.Enum
        {
            static None = 0;
            static ObjectInherit = 1;
            static ContainerInherit = 2;
            static NoPropagateInherit = 4;
            static InheritOnly = 8;
            static InheritanceFlags = 15;
            static Inherited = 16;
            static SuccessfulAccess = 64;
            static FailedAccess = 128;
            static AuditFlags = 192;
            static $map;
            static get Map()
            {
                return this.$map ??= 
                {
                    "None": 0n,
                    "ObjectInherit": 1n,
                    "ContainerInherit": 2n,
                    "NoPropagateInherit": 4n,
                    "InheritOnly": 8n,
                    "InheritanceFlags": 15n,
                    "Inherited": 16n,
                    "SuccessfulAccess": 64n,
                    "FailedAccess": 128n,
                    "AuditFlags": 192n
                };
            }
            static $h = 579927;
            static $z = 1;
            static $f = 0b100000011010001001;
            static $k = 4;
            static get $eut() { return $.$spc.System.Byte; }
            static $$md;
            static get $md() { return this.$$md ??= {"b":1048577,"u":393217,"l":[{"t":579927,"n":"None","d":579927,"h":4295547223,"f":33},{"t":579927,"n":"ObjectInherit","d":579927,"h":8590514519,"f":33},{"t":579927,"n":"ContainerInherit","d":579927,"h":12885481815,"f":33},{"t":579927,"n":"NoPropagateInherit","d":579927,"h":17180449111,"f":33},{"t":579927,"n":"InheritOnly","d":579927,"h":21475416407,"f":33},{"t":579927,"n":"InheritanceFlags","d":579927,"h":25770383703,"f":33},{"t":579927,"n":"Inherited","d":579927,"h":30065350999,"f":33},{"t":579927,"n":"SuccessfulAccess","d":579927,"h":34360318295,"f":33},{"t":579927,"n":"FailedAccess","d":579927,"h":38655285591,"f":33},{"t":579927,"n":"AuditFlags","d":579927,"h":42950252887,"f":33}],"c":[{"n":".ctor","o":"$ctor$3","d":579927,"h":47245220183,"f":1}],"i":[57212929,63766529,57671681,57344001],"h":579927,"a":[{"t":47644673,"c":4342611969}]}; }
            static get $b() { return $.$spc.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IComparable, $.$spc.System.ISpanFormattable, $.$spc.System.IFormattable, $.$spc.System.IConvertible ]; }
            static get $fullName() { return `System.Security.AccessControl.AceFlags`; }
        });
        
        $asm.$str("$ssa.System.Security.AccessControl.AceQualifier", ($self) => class AceQualifier extends $.$spc.System.Enum
        {
            static AccessAllowed = 0;
            static AccessDenied = 1;
            static SystemAudit = 2;
            static SystemAlarm = 3;
            static $map;
            static get Map()
            {
                return this.$map ??= 
                {
                    "AccessAllowed": 0n,
                    "AccessDenied": 1n,
                    "SystemAudit": 2n,
                    "SystemAlarm": 3n
                };
            }
            static $h = 645463;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static get $eut() { return $.$spc.System.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {"b":1048577,"u":655361,"l":[{"t":645463,"n":"AccessAllowed","d":645463,"h":4295612759,"f":33},{"t":645463,"n":"AccessDenied","d":645463,"h":8590580055,"f":33},{"t":645463,"n":"SystemAudit","d":645463,"h":12885547351,"f":33},{"t":645463,"n":"SystemAlarm","d":645463,"h":17180514647,"f":33}],"c":[{"n":".ctor","o":"$ctor$3","d":645463,"h":21475481943,"f":1}],"i":[57212929,63766529,57671681,57344001],"h":645463}; }
            static get $b() { return $.$spc.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IComparable, $.$spc.System.ISpanFormattable, $.$spc.System.IFormattable, $.$spc.System.IConvertible ]; }
            static get $fullName() { return `System.Security.AccessControl.AceQualifier`; }
        });
        
        $asm.$str("$ssa.System.Security.AccessControl.AceType", ($self) => class AceType extends $.$spc.System.Enum
        {
            static AccessAllowed = 0;
            static AccessDenied = 1;
            static SystemAudit = 2;
            static SystemAlarm = 3;
            static AccessAllowedCompound = 4;
            static AccessAllowedObject = 5;
            static AccessDeniedObject = 6;
            static SystemAuditObject = 7;
            static SystemAlarmObject = 8;
            static AccessAllowedCallback = 9;
            static AccessDeniedCallback = 10;
            static AccessAllowedCallbackObject = 11;
            static AccessDeniedCallbackObject = 12;
            static SystemAuditCallback = 13;
            static SystemAlarmCallback = 14;
            static SystemAuditCallbackObject = 15;
            static MaxDefinedAceType = 16;
            static SystemAlarmCallbackObject = 16;
            static $map;
            static get Map()
            {
                return this.$map ??= 
                {
                    "AccessAllowed": 0n,
                    "AccessDenied": 1n,
                    "SystemAudit": 2n,
                    "SystemAlarm": 3n,
                    "AccessAllowedCompound": 4n,
                    "AccessAllowedObject": 5n,
                    "AccessDeniedObject": 6n,
                    "SystemAuditObject": 7n,
                    "SystemAlarmObject": 8n,
                    "AccessAllowedCallback": 9n,
                    "AccessDeniedCallback": 10n,
                    "AccessAllowedCallbackObject": 11n,
                    "AccessDeniedCallbackObject": 12n,
                    "SystemAuditCallback": 13n,
                    "SystemAlarmCallback": 14n,
                    "SystemAuditCallbackObject": 15n,
                    "MaxDefinedAceType": 16n,
                    "SystemAlarmCallbackObject": 16n
                };
            }
            static $h = 710999;
            static $z = 1;
            static $f = 0b100000011010001001;
            static $k = 4;
            static get $eut() { return $.$spc.System.Byte; }
            static $$md;
            static get $md() { return this.$$md ??= {"b":1048577,"u":393217,"l":[{"t":710999,"n":"AccessAllowed","d":710999,"h":4295678295,"f":33},{"t":710999,"n":"AccessDenied","d":710999,"h":8590645591,"f":33},{"t":710999,"n":"SystemAudit","d":710999,"h":12885612887,"f":33},{"t":710999,"n":"SystemAlarm","d":710999,"h":17180580183,"f":33},{"t":710999,"n":"AccessAllowedCompound","d":710999,"h":21475547479,"f":33},{"t":710999,"n":"AccessAllowedObject","d":710999,"h":25770514775,"f":33},{"t":710999,"n":"AccessDeniedObject","d":710999,"h":30065482071,"f":33},{"t":710999,"n":"SystemAuditObject","d":710999,"h":34360449367,"f":33},{"t":710999,"n":"SystemAlarmObject","d":710999,"h":38655416663,"f":33},{"t":710999,"n":"AccessAllowedCallback","d":710999,"h":42950383959,"f":33},{"t":710999,"n":"AccessDeniedCallback","d":710999,"h":47245351255,"f":33},{"t":710999,"n":"AccessAllowedCallbackObject","d":710999,"h":51540318551,"f":33},{"t":710999,"n":"AccessDeniedCallbackObject","d":710999,"h":55835285847,"f":33},{"t":710999,"n":"SystemAuditCallback","d":710999,"h":60130253143,"f":33},{"t":710999,"n":"SystemAlarmCallback","d":710999,"h":64425220439,"f":33},{"t":710999,"n":"SystemAuditCallbackObject","d":710999,"h":68720187735,"f":33},{"t":710999,"n":"MaxDefinedAceType","d":710999,"h":73015155031,"f":33},{"t":710999,"n":"SystemAlarmCallbackObject","d":710999,"h":77310122327,"f":33}],"c":[{"n":".ctor","o":"$ctor$3","d":710999,"h":81605089623,"f":1}],"i":[57212929,63766529,57671681,57344001],"h":710999}; }
            static get $b() { return $.$spc.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IComparable, $.$spc.System.ISpanFormattable, $.$spc.System.IFormattable, $.$spc.System.IConvertible ]; }
            static get $fullName() { return `System.Security.AccessControl.AceType`; }
        });
        
        $asm.$str("$ssa.System.Security.AccessControl.AuditFlags", ($self) => class AuditFlags extends $.$spc.System.Enum
        {
            static None = 0;
            static Success = 1;
            static Failure = 2;
            static $map;
            static get Map()
            {
                return this.$map ??= 
                {
                    "None": 0n,
                    "Success": 1n,
                    "Failure": 2n
                };
            }
            static $h = 776535;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static get $eut() { return $.$spc.System.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {"b":1048577,"u":655361,"l":[{"t":776535,"n":"None","d":776535,"h":4295743831,"f":33},{"t":776535,"n":"Success","d":776535,"h":8590711127,"f":33},{"t":776535,"n":"Failure","d":776535,"h":12885678423,"f":33}],"c":[{"n":".ctor","o":"$ctor$3","d":776535,"h":17180645719,"f":1}],"i":[57212929,63766529,57671681,57344001],"h":776535,"a":[{"t":47644673,"c":4342611969}]}; }
            static get $b() { return $.$spc.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IComparable, $.$spc.System.ISpanFormattable, $.$spc.System.IFormattable, $.$spc.System.IConvertible ]; }
            static get $fullName() { return `System.Security.AccessControl.AuditFlags`; }
        });
        
        $asm.$str("$ssa.System.Security.AccessControl.CompoundAceType", ($self) => class CompoundAceType extends $.$spc.System.Enum
        {
            static Impersonation = 1;
            static $map;
            static get Map()
            {
                return this.$map ??= 
                {
                    "Impersonation": 1n
                };
            }
            static $h = 1431895;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static get $eut() { return $.$spc.System.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {"b":1048577,"u":655361,"l":[{"t":1431895,"n":"Impersonation","d":1431895,"h":4296399191,"f":33}],"c":[{"n":".ctor","o":"$ctor$3","d":1431895,"h":8591366487,"f":1}],"i":[57212929,63766529,57671681,57344001],"h":1431895}; }
            static get $b() { return $.$spc.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IComparable, $.$spc.System.ISpanFormattable, $.$spc.System.IFormattable, $.$spc.System.IConvertible ]; }
            static get $fullName() { return `System.Security.AccessControl.CompoundAceType`; }
        });
        
        $asm.$str("$ssa.System.Security.AccessControl.ControlFlags", ($self) => class ControlFlags extends $.$spc.System.Enum
        {
            static None = 0;
            static OwnerDefaulted = 1;
            static GroupDefaulted = 2;
            static DiscretionaryAclPresent = 4;
            static DiscretionaryAclDefaulted = 8;
            static SystemAclPresent = 16;
            static SystemAclDefaulted = 32;
            static DiscretionaryAclUntrusted = 64;
            static ServerSecurity = 128;
            static DiscretionaryAclAutoInheritRequired = 256;
            static SystemAclAutoInheritRequired = 512;
            static DiscretionaryAclAutoInherited = 1024;
            static SystemAclAutoInherited = 2048;
            static DiscretionaryAclProtected = 4096;
            static SystemAclProtected = 8192;
            static RMControlValid = 16384;
            static SelfRelative = 32768;
            static $map;
            static get Map()
            {
                return this.$map ??= 
                {
                    "None": 0n,
                    "OwnerDefaulted": 1n,
                    "GroupDefaulted": 2n,
                    "DiscretionaryAclPresent": 4n,
                    "DiscretionaryAclDefaulted": 8n,
                    "SystemAclPresent": 16n,
                    "SystemAclDefaulted": 32n,
                    "DiscretionaryAclUntrusted": 64n,
                    "ServerSecurity": 128n,
                    "DiscretionaryAclAutoInheritRequired": 256n,
                    "SystemAclAutoInheritRequired": 512n,
                    "DiscretionaryAclAutoInherited": 1024n,
                    "SystemAclAutoInherited": 2048n,
                    "DiscretionaryAclProtected": 4096n,
                    "SystemAclProtected": 8192n,
                    "RMControlValid": 16384n,
                    "SelfRelative": 32768n
                };
            }
            static $h = 1497431;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static get $eut() { return $.$spc.System.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {"b":1048577,"u":655361,"l":[{"t":1497431,"n":"None","d":1497431,"h":4296464727,"f":33},{"t":1497431,"n":"OwnerDefaulted","d":1497431,"h":8591432023,"f":33},{"t":1497431,"n":"GroupDefaulted","d":1497431,"h":12886399319,"f":33},{"t":1497431,"n":"DiscretionaryAclPresent","d":1497431,"h":17181366615,"f":33},{"t":1497431,"n":"DiscretionaryAclDefaulted","d":1497431,"h":21476333911,"f":33},{"t":1497431,"n":"SystemAclPresent","d":1497431,"h":25771301207,"f":33},{"t":1497431,"n":"SystemAclDefaulted","d":1497431,"h":30066268503,"f":33},{"t":1497431,"n":"DiscretionaryAclUntrusted","d":1497431,"h":34361235799,"f":33},{"t":1497431,"n":"ServerSecurity","d":1497431,"h":38656203095,"f":33},{"t":1497431,"n":"DiscretionaryAclAutoInheritRequired","d":1497431,"h":42951170391,"f":33},{"t":1497431,"n":"SystemAclAutoInheritRequired","d":1497431,"h":47246137687,"f":33},{"t":1497431,"n":"DiscretionaryAclAutoInherited","d":1497431,"h":51541104983,"f":33},{"t":1497431,"n":"SystemAclAutoInherited","d":1497431,"h":55836072279,"f":33},{"t":1497431,"n":"DiscretionaryAclProtected","d":1497431,"h":60131039575,"f":33},{"t":1497431,"n":"SystemAclProtected","d":1497431,"h":64426006871,"f":33},{"t":1497431,"n":"RMControlValid","d":1497431,"h":68720974167,"f":33},{"t":1497431,"n":"SelfRelative","d":1497431,"h":73015941463,"f":33}],"c":[{"n":".ctor","o":"$ctor$3","d":1497431,"h":77310908759,"f":1}],"i":[57212929,63766529,57671681,57344001],"h":1497431,"a":[{"t":47644673,"c":4342611969}]}; }
            static get $b() { return $.$spc.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IComparable, $.$spc.System.ISpanFormattable, $.$spc.System.IFormattable, $.$spc.System.IConvertible ]; }
            static get $fullName() { return `System.Security.AccessControl.ControlFlags`; }
        });
        
        $asm.$str("$ssa.System.Security.AccessControl.InheritanceFlags", ($self) => class InheritanceFlags extends $.$spc.System.Enum
        {
            static None = 0;
            static ContainerInherit = 1;
            static ObjectInherit = 2;
            static $map;
            static get Map()
            {
                return this.$map ??= 
                {
                    "None": 0n,
                    "ContainerInherit": 1n,
                    "ObjectInherit": 2n
                };
            }
            static $h = 1890647;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static get $eut() { return $.$spc.System.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {"b":1048577,"u":655361,"l":[{"t":1890647,"n":"None","d":1890647,"h":4296857943,"f":33},{"t":1890647,"n":"ContainerInherit","d":1890647,"h":8591825239,"f":33},{"t":1890647,"n":"ObjectInherit","d":1890647,"h":12886792535,"f":33}],"c":[{"n":".ctor","o":"$ctor$3","d":1890647,"h":17181759831,"f":1}],"i":[57212929,63766529,57671681,57344001],"h":1890647,"a":[{"t":47644673,"c":4342611969}]}; }
            static get $b() { return $.$spc.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IComparable, $.$spc.System.ISpanFormattable, $.$spc.System.IFormattable, $.$spc.System.IConvertible ]; }
            static get $fullName() { return `System.Security.AccessControl.InheritanceFlags`; }
        });
        
        $asm.$str("$ssa.System.Security.AccessControl.ObjectAceFlags", ($self) => class ObjectAceFlags extends $.$spc.System.Enum
        {
            static None = 0;
            static ObjectAceTypePresent = 1;
            static InheritedObjectAceTypePresent = 2;
            static $map;
            static get Map()
            {
                return this.$map ??= 
                {
                    "None": 0n,
                    "ObjectAceTypePresent": 1n,
                    "InheritedObjectAceTypePresent": 2n
                };
            }
            static $h = 2283863;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static get $eut() { return $.$spc.System.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {"b":1048577,"u":655361,"l":[{"t":2283863,"n":"None","d":2283863,"h":4297251159,"f":33},{"t":2283863,"n":"ObjectAceTypePresent","d":2283863,"h":8592218455,"f":33},{"t":2283863,"n":"InheritedObjectAceTypePresent","d":2283863,"h":12887185751,"f":33}],"c":[{"n":".ctor","o":"$ctor$3","d":2283863,"h":17182153047,"f":1}],"i":[57212929,63766529,57671681,57344001],"h":2283863,"a":[{"t":47644673,"c":4342611969}]}; }
            static get $b() { return $.$spc.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IComparable, $.$spc.System.ISpanFormattable, $.$spc.System.IFormattable, $.$spc.System.IConvertible ]; }
            static get $fullName() { return `System.Security.AccessControl.ObjectAceFlags`; }
        });
        
        $asm.$str("$ssa.System.Security.AccessControl.PropagationFlags", ($self) => class PropagationFlags extends $.$spc.System.Enum
        {
            static None = 0;
            static NoPropagateInherit = 1;
            static InheritOnly = 2;
            static $map;
            static get Map()
            {
                return this.$map ??= 
                {
                    "None": 0n,
                    "NoPropagateInherit": 1n,
                    "InheritOnly": 2n
                };
            }
            static $h = 2611543;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static get $eut() { return $.$spc.System.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {"b":1048577,"u":655361,"l":[{"t":2611543,"n":"None","d":2611543,"h":4297578839,"f":33},{"t":2611543,"n":"NoPropagateInherit","d":2611543,"h":8592546135,"f":33},{"t":2611543,"n":"InheritOnly","d":2611543,"h":12887513431,"f":33}],"c":[{"n":".ctor","o":"$ctor$3","d":2611543,"h":17182480727,"f":1}],"i":[57212929,63766529,57671681,57344001],"h":2611543,"a":[{"t":47644673,"c":4342611969}]}; }
            static get $b() { return $.$spc.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IComparable, $.$spc.System.ISpanFormattable, $.$spc.System.IFormattable, $.$spc.System.IConvertible ]; }
            static get $fullName() { return `System.Security.AccessControl.PropagationFlags`; }
        });
        
        $asm.$str("$ssa.System.Security.AccessControl.ResourceType", ($self) => class ResourceType extends $.$spc.System.Enum
        {
            static Unknown = 0;
            static FileObject = 1;
            static Service = 2;
            static Printer = 3;
            static RegistryKey = 4;
            static LMShare = 5;
            static KernelObject = 6;
            static WindowObject = 7;
            static DSObject = 8;
            static DSObjectAll = 9;
            static ProviderDefined = 10;
            static WmiGuidObject = 11;
            static RegistryWow6432Key = 12;
            static $map;
            static get Map()
            {
                return this.$map ??= 
                {
                    "Unknown": 0n,
                    "FileObject": 1n,
                    "Service": 2n,
                    "Printer": 3n,
                    "RegistryKey": 4n,
                    "LMShare": 5n,
                    "KernelObject": 6n,
                    "WindowObject": 7n,
                    "DSObject": 8n,
                    "DSObjectAll": 9n,
                    "ProviderDefined": 10n,
                    "WmiGuidObject": 11n,
                    "RegistryWow6432Key": 12n
                };
            }
            static $h = 2873687;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static get $eut() { return $.$spc.System.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {"b":1048577,"u":655361,"l":[{"t":2873687,"n":"Unknown","d":2873687,"h":4297840983,"f":33},{"t":2873687,"n":"FileObject","d":2873687,"h":8592808279,"f":33},{"t":2873687,"n":"Service","d":2873687,"h":12887775575,"f":33},{"t":2873687,"n":"Printer","d":2873687,"h":17182742871,"f":33},{"t":2873687,"n":"RegistryKey","d":2873687,"h":21477710167,"f":33},{"t":2873687,"n":"LMShare","d":2873687,"h":25772677463,"f":33},{"t":2873687,"n":"KernelObject","d":2873687,"h":30067644759,"f":33},{"t":2873687,"n":"WindowObject","d":2873687,"h":34362612055,"f":33},{"t":2873687,"n":"DSObject","d":2873687,"h":38657579351,"f":33},{"t":2873687,"n":"DSObjectAll","d":2873687,"h":42952546647,"f":33},{"t":2873687,"n":"ProviderDefined","d":2873687,"h":47247513943,"f":33},{"t":2873687,"n":"WmiGuidObject","d":2873687,"h":51542481239,"f":33},{"t":2873687,"n":"RegistryWow6432Key","d":2873687,"h":55837448535,"f":33}],"c":[{"n":".ctor","o":"$ctor$3","d":2873687,"h":60132415831,"f":1}],"i":[57212929,63766529,57671681,57344001],"h":2873687}; }
            static get $b() { return $.$spc.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IComparable, $.$spc.System.ISpanFormattable, $.$spc.System.IFormattable, $.$spc.System.IConvertible ]; }
            static get $fullName() { return `System.Security.AccessControl.ResourceType`; }
        });
        
        $asm.$str("$ssa.System.Security.AccessControl.SecurityInfos", ($self) => class SecurityInfos extends $.$spc.System.Enum
        {
            static Owner = 1;
            static Group = 2;
            static DiscretionaryAcl = 4;
            static SystemAcl = 8;
            static $map;
            static get Map()
            {
                return this.$map ??= 
                {
                    "Owner": 1n,
                    "Group": 2n,
                    "DiscretionaryAcl": 4n,
                    "SystemAcl": 8n
                };
            }
            static $h = 2939223;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static get $eut() { return $.$spc.System.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {"b":1048577,"u":655361,"l":[{"t":2939223,"n":"Owner","d":2939223,"h":4297906519,"f":33},{"t":2939223,"n":"Group","d":2939223,"h":8592873815,"f":33},{"t":2939223,"n":"DiscretionaryAcl","d":2939223,"h":12887841111,"f":33},{"t":2939223,"n":"SystemAcl","d":2939223,"h":17182808407,"f":33}],"c":[{"n":".ctor","o":"$ctor$3","d":2939223,"h":21477775703,"f":1}],"i":[57212929,63766529,57671681,57344001],"h":2939223,"a":[{"t":47644673,"c":4342611969}]}; }
            static get $b() { return $.$spc.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IComparable, $.$spc.System.ISpanFormattable, $.$spc.System.IFormattable, $.$spc.System.IConvertible ]; }
            static get $fullName() { return `System.Security.AccessControl.SecurityInfos`; }
        });
        
        $asm.$cls("$ssa.System.Security.AccessControl.CommonAce", ($self) => class CommonAce extends $.$ssa.System.Security.AccessControl.QualifiedAce
        {
            $ctor$4(/*System.Security.AccessControl.AceFlags*/ flags, /*System.Security.AccessControl.AceQualifier*/ qualifier, /*int*/ accessMask, /*System.Security.Principal.SecurityIdentifier*/ sid, /*bool*/ isCallback, /*byte[]?*/ opaque)
            {
                super.$ctor$3();
                {
                }
                return this;
            }
            /*int */ get BinaryLength()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*void */ GetBinaryForm(/*byte[]*/ binaryForm, /*int*/ offset)
            {
            }
            static /*int */ MaxOpaqueLength(/*bool*/ isCallback)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static $h = 1104215;
            static $f = 0b10010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":2677079,"p":[{"p":655361,"g":{"r":0,"d":0,"h":12886006103,"f":32769},"n":"BinaryLength","d":1104215,"h":8591038807,"f":32769}],"m":[{"r":65537,"p":[{"n":"binaryForm","p":0},{"n":"offset","p":655361}],"n":"GetBinaryForm","d":1104215,"h":17180973399,"f":32769},{"r":655361,"p":[{"n":"isCallback","p":262145}],"n":"MaxOpaqueLength","d":1104215,"h":21475940695,"f":33}],"c":[{"p":[{"n":"flags","p":579927},{"n":"qualifier","p":645463},{"n":"accessMask","p":655361},{"n":"sid","p":443615},{"n":"isCallback","p":262145},{"n":"opaque","p":0}],"n":".ctor","o":"$ctor$4","d":1104215,"h":4296071511,"f":1}],"h":1104215}; }
            static get $b() { return $.$ssa.System.Security.AccessControl.QualifiedAce; }
            static get $fullName() { return `System.Security.AccessControl.CommonAce`; }
        });
        
        $asm.$cls("$ssa.System.Security.AccessControl.ObjectAce", ($self) => class ObjectAce extends $.$ssa.System.Security.AccessControl.QualifiedAce
        {
            $ctor$4(/*System.Security.AccessControl.AceFlags*/ aceFlags, /*System.Security.AccessControl.AceQualifier*/ qualifier, /*int*/ accessMask, /*System.Security.Principal.SecurityIdentifier*/ sid, /*System.Security.AccessControl.ObjectAceFlags*/ flags, /*System.Guid*/ type, /*System.Guid*/ inheritedType, /*bool*/ isCallback, /*byte[]?*/ opaque)
            {
                super.$ctor$3();
                {
                }
                return this;
            }
            /*int */ get BinaryLength()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Guid */ get InheritedObjectAceType()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Guid */ set InheritedObjectAceType(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Security.AccessControl.ObjectAceFlags */ get ObjectAceFlags()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Security.AccessControl.ObjectAceFlags */ set ObjectAceFlags(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Guid */ get ObjectAceType()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Guid */ set ObjectAceType(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*void */ GetBinaryForm(/*byte[]*/ binaryForm, /*int*/ offset)
            {
            }
            static /*int */ MaxOpaqueLength(/*bool*/ isCallback)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static $h = 2218327;
            static $f = 0b10010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":2677079,"p":[{"p":655361,"g":{"r":0,"d":0,"h":12887120215,"f":32769},"n":"BinaryLength","d":2218327,"h":8592152919,"f":32769},{"p":56164353,"g":{"r":0,"d":0,"h":21477054807,"f":1},"s":{"r":0,"d":0,"h":25772022103,"f":1},"n":"InheritedObjectAceType","d":2218327,"h":17182087511,"f":1},{"p":2283863,"g":{"r":0,"d":0,"h":34361956695,"f":1},"s":{"r":0,"d":0,"h":38656923991,"f":1},"n":"ObjectAceFlags","d":2218327,"h":30066989399,"f":1},{"p":56164353,"g":{"r":0,"d":0,"h":47246858583,"f":1},"s":{"r":0,"d":0,"h":51541825879,"f":1},"n":"ObjectAceType","d":2218327,"h":42951891287,"f":1}],"m":[{"r":65537,"p":[{"n":"binaryForm","p":0},{"n":"offset","p":655361}],"n":"GetBinaryForm","d":2218327,"h":55836793175,"f":32769},{"r":655361,"p":[{"n":"isCallback","p":262145}],"n":"MaxOpaqueLength","d":2218327,"h":60131760471,"f":33}],"c":[{"p":[{"n":"aceFlags","p":579927},{"n":"qualifier","p":645463},{"n":"accessMask","p":655361},{"n":"sid","p":443615},{"n":"flags","p":2283863},{"n":"type","p":56164353},{"n":"inheritedType","p":56164353},{"n":"isCallback","p":262145},{"n":"opaque","p":0}],"n":".ctor","o":"$ctor$4","d":2218327,"h":4297185623,"f":1}],"h":2218327}; }
            static get $b() { return $.$ssa.System.Security.AccessControl.QualifiedAce; }
            static get $fullName() { return `System.Security.AccessControl.ObjectAce`; }
        });
        
        $asm.$cls("$ssa.System.Security.AccessControl.PrivilegeNotHeldException", ($self) => class PrivilegeNotHeldException extends $.$spc.System.UnauthorizedAccessException
        {
            $ctor$13()
            {
                super.$ctor$9();
                {
                }
                return this;
            }
            $ctor$14(/*string?*/ privilege)
            {
                super.$ctor$9();
                {
                }
                return this;
            }
            $ctor$15(/*string?*/ privilege, /*System.Exception?*/ inner)
            {
                super.$ctor$9();
                {
                }
                return this;
            }
            /*string? */ get PrivilegeName()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*void */ GetObjectData(/*System.Runtime.Serialization.SerializationInfo*/ info, /*System.Runtime.Serialization.StreamingContext*/ context)
            {
            }
            static $h = 2546007;
            static $f = 0b10010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":143851521,"h":2546007}; }
            static get $b() { return $.$spc.System.UnauthorizedAccessException; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.Runtime.Serialization.ISerializable ]; }
            static get $fullName() { return `System.Security.AccessControl.PrivilegeNotHeldException`; }
        });
	});
})(window, window.NetJs.$boot(), ...window.NetJs.$require("NetJs.System.Private.CoreLib", "NetJs.Microsoft.Win32.Primitives", "NetJs.System.Collections", "NetJs.System.Diagnostics.Tracing", "NetJs.System.Memory", "NetJs.System.Private.Uri", "NetJs.System.Threading", "NetJs.System.Threading.Thread", "NetJs.System.Runtime", "NetJs.System.Collections.Concurrent", "NetJs.System.Collections.NonGeneric", "NetJs.System.Security.Claims", "NetJs.System.Runtime.InteropServices", "NetJs.System.Security.Principal.Windows"))