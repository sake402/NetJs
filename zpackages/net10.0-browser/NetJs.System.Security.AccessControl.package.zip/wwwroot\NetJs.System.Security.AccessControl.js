
(function ($global, $, $spc, $mwp, $sc, $sdt, $st, $scc, $sm, $spu, $sr, $scn, $sris, $stt, $ssc, $sspw) {
    "use strict";
    let _;
    
    
    
	$.$asm(
    "NetJs.System.Security.AccessControl", 
    {"h":37217,"f":"System.Security.AccessControl","v":"1.0.35.0","a":[{"t":115146753,"c":13000048641,"a":[{"v":".NETCoreApp,Version=v10.0","t":1310721}],"n":[{"n":"FrameworkDisplayName","v":".NET 10.0","t":1310721}]},{"t":73596929,"c":4368564225,"a":[{"v":"SIT","t":1310721}]},{"t":73662465,"c":4368629761,"a":[{"v":"Debug","t":1310721}]},{"t":74121217,"c":4369088513,"a":[{"v":"1.0.35.0","t":1310721}]},{"t":74252289,"c":4369219585,"a":[{"v":"1.0.35\u002Bf7a34a6f78fee11131301a9f55ca16a968616013","t":1310721}]},{"t":75104257,"c":4370071553,"a":[{"v":"NetJs.System.Security.AccessControl","t":1310721}]},{"t":75235329,"c":4370202625,"a":[{"v":"NetJs.System.Security.AccessControl","t":1310721}]},{"t":75366401,"c":4370333697,"a":[{"v":"1.0.35.0","t":1310721}]},{"t":115212289,"c":4410179585,"a":[{"v":"browser1.0","t":1310721}]},{"t":114950145,"c":4409917441,"a":[{"v":"browser1.0","t":1310721}]}],"m":[]},
    function($asm)
	{
        
        
        $asm.$cls("$ssa.System.Security.AccessControl.AuthorizationRule", ($self) => class AuthorizationRule extends $.$spc.System.Object
        {
            $ctor$1(/*System.Security.Principal.IdentityReference*/ identity, /*int*/ accessMask, /*bool*/ isInherited, /*System.Security.AccessControl.InheritanceFlags*/ inheritanceFlags, /*System.Security.AccessControl.PropagationFlags*/ propagationFlags)
            {
                super.$ctor();
                {
                }
                return this;
            }
            /*int */ get AccessMask()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Security.Principal.IdentityReference */ get IdentityReference()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Security.AccessControl.InheritanceFlags */ get InheritanceFlags()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get IsInherited()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Security.AccessControl.PropagationFlags */ get PropagationFlags()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static $h = 954721;
            static $f = 0b110001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":655361,"g":{"r":0,"d":0,"h":12885856609,"f":16},"n":"AccessMask","d":954721,"h":8590889313,"f":16},{"p":249887,"g":{"r":0,"d":0,"h":21475791201,"f":1},"n":"IdentityReference","d":954721,"h":17180823905,"f":1},{"p":1872225,"g":{"r":0,"d":0,"h":30065725793,"f":1},"n":"InheritanceFlags","d":954721,"h":25770758497,"f":1},{"p":262145,"g":{"r":0,"d":0,"h":38655660385,"f":1},"n":"IsInherited","d":954721,"h":34360693089,"f":1},{"p":2593121,"g":{"r":0,"d":0,"h":47245594977,"f":1},"n":"PropagationFlags","d":954721,"h":42950627681,"f":1}],"c":[{"p":[{"n":"identity","p":249887},{"n":"accessMask","p":655361},{"n":"isInherited","p":262145},{"n":"inheritanceFlags","p":1872225},{"n":"propagationFlags","p":2593121}],"n":".ctor","o":"$ctor$1","d":954721,"h":4295922017,"f":16}],"h":954721}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.Security.AccessControl.AuthorizationRule`; }
        });
        
        $asm.$cls("$ssa.System.Security.AccessControl.GenericAce", ($self) => class GenericAce extends $.$spc.System.Object
        {
            $ctor$1()
            {
                super.$ctor();
                {
                }
                return this;
            }
            /*System.Security.AccessControl.AceFlags */ get AceFlags()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Security.AccessControl.AceFlags */ set AceFlags(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Security.AccessControl.AceType */ get AceType()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Security.AccessControl.AuditFlags */ get AuditFlags()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Security.AccessControl.InheritanceFlags */ get InheritanceFlags()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get IsInherited()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Security.AccessControl.PropagationFlags */ get PropagationFlags()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Security.AccessControl.GenericAce */ Copy()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static /*System.Security.AccessControl.GenericAce */ CreateFromBinaryForm(/*byte[]*/ binaryForm, /*int*/ offset)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static/*conventional*/ /*bool */ Equals(/*object?*/ o)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            //Static convention instance redirect
            /*bool */ Equals() { return $.$ssa.System.Security.AccessControl.GenericAce.Equals.apply(this, arguments); }
            static/*conventional*/ /*int */ GetHashCode()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            //Static convention instance redirect
            /*int */ GetHashCode() { return $.$ssa.System.Security.AccessControl.GenericAce.GetHashCode.apply(this, arguments); }
            static /*bool */ op_Equality(/*System.Security.AccessControl.GenericAce?*/ left, /*System.Security.AccessControl.GenericAce?*/ right)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static /*bool */ op_Inequality(/*System.Security.AccessControl.GenericAce?*/ left, /*System.Security.AccessControl.GenericAce?*/ right)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static $h = 1675617;
            static $f = 0b110001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":561505,"g":{"r":0,"d":0,"h":12886577505,"f":1},"s":{"r":0,"d":0,"h":17181544801,"f":1},"n":"AceFlags","d":1675617,"h":8591610209,"f":1},{"p":692577,"g":{"r":0,"d":0,"h":25771479393,"f":1},"n":"AceType","d":1675617,"h":21476512097,"f":1},{"p":758113,"g":{"r":0,"d":0,"h":34361413985,"f":1},"n":"AuditFlags","d":1675617,"h":30066446689,"f":1},{"p":655361,"g":{"r":0,"d":0,"h":42951348577,"f":257},"n":"BinaryLength","d":1675617,"h":38656381281,"f":257},{"p":1872225,"g":{"r":0,"d":0,"h":51541283169,"f":1},"n":"InheritanceFlags","d":1675617,"h":47246315873,"f":1},{"p":262145,"g":{"r":0,"d":0,"h":60131217761,"f":1},"n":"IsInherited","d":1675617,"h":55836250465,"f":1},{"p":2593121,"g":{"r":0,"d":0,"h":68721152353,"f":1},"n":"PropagationFlags","d":1675617,"h":64426185057,"f":1}],"m":[{"r":1675617,"n":"Copy","d":1675617,"h":73016119649,"f":1},{"r":1675617,"p":[{"n":"binaryForm","p":0},{"n":"offset","p":655361}],"n":"CreateFromBinaryForm","d":1675617,"h":77311086945,"f":33},{"r":262145,"p":[{"n":"o","p":131073}],"n":"Equals","d":1675617,"h":81606054241,"f":98305},{"r":65537,"p":[{"n":"binaryForm","p":0},{"n":"offset","p":655361}],"n":"GetBinaryForm","d":1675617,"h":85901021537,"f":257},{"r":655361,"n":"GetHashCode","d":1675617,"h":90195988833,"f":98305}],"c":[{"n":".ctor","o":"$ctor$1","d":1675617,"h":4296642913,"f":8}],"h":1675617}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.Security.AccessControl.GenericAce`; }
        });
        
        $asm.$cls("$ssa.System.Security.AccessControl.GenericSecurityDescriptor", ($self) => class GenericSecurityDescriptor extends $.$spc.System.Object
        {
            $ctor$1()
            {
                super.$ctor();
                {
                }
                return this;
            }
            /*int */ get BinaryLength()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static /*byte */ get Revision()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*void */ GetBinaryForm(/*byte[]*/ binaryForm, /*int*/ offset)
            {
            }
            /*string */ GetSddlForm(/*System.Security.AccessControl.AccessControlSections*/ includeSections)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static /*bool */ IsSddlConversionSupported()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static $h = 1806689;
            static $f = 0b110001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":655361,"g":{"r":0,"d":0,"h":12886708577,"f":1},"n":"BinaryLength","d":1806689,"h":8591741281,"f":1},{"p":1479009,"g":{"r":0,"d":0,"h":21476643169,"f":257},"n":"ControlFlags","d":1806689,"h":17181675873,"f":257},{"p":446495,"g":{"r":0,"d":0,"h":30066577761,"f":257},"s":{"r":0,"d":0,"h":34361545057,"f":257},"n":"Group","d":1806689,"h":25771610465,"f":257},{"p":446495,"g":{"r":0,"d":0,"h":42951479649,"f":257},"s":{"r":0,"d":0,"h":47246446945,"f":257},"n":"Owner","d":1806689,"h":38656512353,"f":257},{"p":393217,"g":{"r":0,"d":0,"h":55836381537,"f":33},"n":"Revision","d":1806689,"h":51541414241,"f":33}],"m":[{"r":65537,"p":[{"n":"binaryForm","p":0},{"n":"offset","p":655361}],"n":"GetBinaryForm","d":1806689,"h":60131348833,"f":1},{"r":1310721,"p":[{"n":"includeSections","p":233825}],"n":"GetSddlForm","d":1806689,"h":64426316129,"f":1},{"r":262145,"n":"IsSddlConversionSupported","d":1806689,"h":68721283425,"f":33}],"c":[{"n":".ctor","o":"$ctor$1","d":1806689,"h":4296773985,"f":8}],"h":1806689}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.Security.AccessControl.GenericSecurityDescriptor`; }
        });
        
        $asm.$cls("$ssa.System.Security.AccessControl.ObjectSecurity", ($self) => class ObjectSecurity extends $.$spc.System.Object
        {
            $ctor$1()
            {
                super.$ctor();
                {
                }
                return this;
            }
            $ctor$2(/*bool*/ isContainer, /*bool*/ isDS)
            {
                super.$ctor();
                {
                }
                return this;
            }
            $ctor$3(/*System.Security.AccessControl.CommonSecurityDescriptor*/ securityDescriptor)
            {
                super.$ctor();
                {
                }
                return this;
            }
            /*bool */ get AccessRulesModified()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ set AccessRulesModified(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get AreAccessRulesCanonical()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get AreAccessRulesProtected()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get AreAuditRulesCanonical()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get AreAuditRulesProtected()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get AuditRulesModified()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ set AuditRulesModified(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get GroupModified()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ set GroupModified(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get IsContainer()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get IsDS()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get OwnerModified()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ set OwnerModified(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Security.AccessControl.CommonSecurityDescriptor */ get SecurityDescriptor()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Security.Principal.IdentityReference? */ GetGroup(/*System.Type*/ targetType)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Security.Principal.IdentityReference? */ GetOwner(/*System.Type*/ targetType)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*byte[] */ GetSecurityDescriptorBinaryForm()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*string */ GetSecurityDescriptorSddlForm(/*System.Security.AccessControl.AccessControlSections*/ includeSections)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static /*bool */ IsSddlConversionSupported()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ ModifyAccessRule(/*System.Security.AccessControl.AccessControlModification*/ modification, /*System.Security.AccessControl.AccessRule*/ rule, /*out bool*/ modified)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ ModifyAuditRule(/*System.Security.AccessControl.AccessControlModification*/ modification, /*System.Security.AccessControl.AuditRule*/ rule, /*out bool*/ modified)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*void */ Persist(/*bool*/ enableOwnershipPrivilege, /*string*/ name, /*System.Security.AccessControl.AccessControlSections*/ includeSections)
            {
            }
            /*void */ Persist$1(/*System.Runtime.InteropServices.SafeHandle*/ handle, /*System.Security.AccessControl.AccessControlSections*/ includeSections)
            {
            }
            /*void */ Persist$2(/*string*/ name, /*System.Security.AccessControl.AccessControlSections*/ includeSections)
            {
            }
            /*void */ PurgeAccessRules(/*System.Security.Principal.IdentityReference*/ identity)
            {
            }
            /*void */ PurgeAuditRules(/*System.Security.Principal.IdentityReference*/ identity)
            {
            }
            /*void */ ReadLock()
            {
            }
            /*void */ ReadUnlock()
            {
            }
            /*void */ SetAccessRuleProtection(/*bool*/ isProtected, /*bool*/ preserveInheritance)
            {
            }
            /*void */ SetAuditRuleProtection(/*bool*/ isProtected, /*bool*/ preserveInheritance)
            {
            }
            /*void */ SetGroup(/*System.Security.Principal.IdentityReference*/ identity)
            {
            }
            /*void */ SetOwner(/*System.Security.Principal.IdentityReference*/ identity)
            {
            }
            /*void */ SetSecurityDescriptorBinaryForm(/*byte[]*/ binaryForm)
            {
            }
            /*void */ SetSecurityDescriptorBinaryForm$1(/*byte[]*/ binaryForm, /*System.Security.AccessControl.AccessControlSections*/ includeSections)
            {
            }
            /*void */ SetSecurityDescriptorSddlForm(/*string*/ sddlForm)
            {
            }
            /*void */ SetSecurityDescriptorSddlForm$1(/*string*/ sddlForm, /*System.Security.AccessControl.AccessControlSections*/ includeSections)
            {
            }
            /*void */ WriteLock()
            {
            }
            /*void */ WriteUnlock()
            {
            }
            static $h = 2396513;
            static $f = 0b110001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":142606337,"g":{"r":0,"d":0,"h":21477232993,"f":257},"n":"AccessRightType","d":2396513,"h":17182265697,"f":257},{"p":262145,"g":{"r":0,"d":0,"h":30067167585,"f":4},"s":{"r":0,"d":0,"h":34362134881,"f":4},"n":"AccessRulesModified","d":2396513,"h":25772200289,"f":4},{"p":142606337,"g":{"r":0,"d":0,"h":42952069473,"f":257},"n":"AccessRuleType","d":2396513,"h":38657102177,"f":257},{"p":262145,"g":{"r":0,"d":0,"h":51542004065,"f":1},"n":"AreAccessRulesCanonical","d":2396513,"h":47247036769,"f":1},{"p":262145,"g":{"r":0,"d":0,"h":60131938657,"f":1},"n":"AreAccessRulesProtected","d":2396513,"h":55836971361,"f":1},{"p":262145,"g":{"r":0,"d":0,"h":68721873249,"f":1},"n":"AreAuditRulesCanonical","d":2396513,"h":64426905953,"f":1},{"p":262145,"g":{"r":0,"d":0,"h":77311807841,"f":1},"n":"AreAuditRulesProtected","d":2396513,"h":73016840545,"f":1},{"p":262145,"g":{"r":0,"d":0,"h":85901742433,"f":4},"s":{"r":0,"d":0,"h":90196709729,"f":4},"n":"AuditRulesModified","d":2396513,"h":81606775137,"f":4},{"p":142606337,"g":{"r":0,"d":0,"h":98786644321,"f":257},"n":"AuditRuleType","d":2396513,"h":94491677025,"f":257},{"p":262145,"g":{"r":0,"d":0,"h":107376578913,"f":4},"s":{"r":0,"d":0,"h":111671546209,"f":4},"n":"GroupModified","d":2396513,"h":103081611617,"f":4},{"p":262145,"g":{"r":0,"d":0,"h":120261480801,"f":4},"n":"IsContainer","d":2396513,"h":115966513505,"f":4},{"p":262145,"g":{"r":0,"d":0,"h":128851415393,"f":4},"n":"IsDS","d":2396513,"h":124556448097,"f":4},{"p":262145,"g":{"r":0,"d":0,"h":137441349985,"f":4},"s":{"r":0,"d":0,"h":141736317281,"f":4},"n":"OwnerModified","d":2396513,"h":133146382689,"f":4},{"p":1282401,"g":{"r":0,"d":0,"h":150326251873,"f":4},"n":"SecurityDescriptor","d":2396513,"h":146031284577,"f":4}],"m":[{"r":364897,"p":[{"n":"identityReference","p":249887},{"n":"accessMask","p":655361},{"n":"isInherited","p":262145},{"n":"inheritanceFlags","p":1872225},{"n":"propagationFlags","p":2593121},{"n":"type","p":299361}],"n":"AccessRuleFactory","d":2396513,"h":154621219169,"f":257},{"r":823649,"p":[{"n":"identityReference","p":249887},{"n":"accessMask","p":655361},{"n":"isInherited","p":262145},{"n":"inheritanceFlags","p":1872225},{"n":"propagationFlags","p":2593121},{"n":"flags","p":758113}],"n":"AuditRuleFactory","d":2396513,"h":158916186465,"f":257},{"r":249887,"p":[{"n":"targetType","p":142606337}],"n":"GetGroup","d":2396513,"h":163211153761,"f":1},{"r":249887,"p":[{"n":"targetType","p":142606337}],"n":"GetOwner","d":2396513,"h":167506121057,"f":1},{"r":0,"n":"GetSecurityDescriptorBinaryForm","d":2396513,"h":171801088353,"f":1},{"r":1310721,"p":[{"n":"includeSections","p":233825}],"n":"GetSecurityDescriptorSddlForm","d":2396513,"h":176096055649,"f":1},{"r":262145,"n":"IsSddlConversionSupported","d":2396513,"h":180391022945,"f":33},{"r":262145,"p":[{"n":"modification","p":168289},{"n":"rule","p":364897},{"n":"modified","p":262145,"f":2}],"n":"ModifyAccess","d":2396513,"h":184685990241,"f":260},{"r":262145,"p":[{"n":"modification","p":168289},{"n":"rule","p":364897},{"n":"modified","p":262145,"f":2}],"n":"ModifyAccessRule","d":2396513,"h":188980957537,"f":129},{"r":262145,"p":[{"n":"modification","p":168289},{"n":"rule","p":823649},{"n":"modified","p":262145,"f":2}],"n":"ModifyAudit","d":2396513,"h":193275924833,"f":260},{"r":262145,"p":[{"n":"modification","p":168289},{"n":"rule","p":823649},{"n":"modified","p":262145,"f":2}],"n":"ModifyAuditRule","d":2396513,"h":197570892129,"f":129},{"r":65537,"p":[{"n":"enableOwnershipPrivilege","p":262145},{"n":"name","p":1310721},{"n":"includeSections","p":233825}],"n":"Persist","d":2396513,"h":201865859425,"f":132},{"r":65537,"p":[{"n":"handle","p":109576193},{"n":"includeSections","p":233825}],"n":"Persist","o":"@$1","d":2396513,"h":206160826721,"f":132},{"r":65537,"p":[{"n":"name","p":1310721},{"n":"includeSections","p":233825}],"n":"Persist","o":"@$2","d":2396513,"h":210455794017,"f":132},{"r":65537,"p":[{"n":"identity","p":249887}],"n":"PurgeAccessRules","d":2396513,"h":214750761313,"f":129},{"r":65537,"p":[{"n":"identity","p":249887}],"n":"PurgeAuditRules","d":2396513,"h":219045728609,"f":129},{"r":65537,"n":"ReadLock","d":2396513,"h":223340695905,"f":4},{"r":65537,"n":"ReadUnlock","d":2396513,"h":227635663201,"f":4},{"r":65537,"p":[{"n":"isProtected","p":262145},{"n":"preserveInheritance","p":262145}],"n":"SetAccessRuleProtection","d":2396513,"h":231930630497,"f":1},{"r":65537,"p":[{"n":"isProtected","p":262145},{"n":"preserveInheritance","p":262145}],"n":"SetAuditRuleProtection","d":2396513,"h":236225597793,"f":1},{"r":65537,"p":[{"n":"identity","p":249887}],"n":"SetGroup","d":2396513,"h":240520565089,"f":1},{"r":65537,"p":[{"n":"identity","p":249887}],"n":"SetOwner","d":2396513,"h":244815532385,"f":1},{"r":65537,"p":[{"n":"binaryForm","p":0}],"n":"SetSecurityDescriptorBinaryForm","d":2396513,"h":249110499681,"f":1},{"r":65537,"p":[{"n":"binaryForm","p":0},{"n":"includeSections","p":233825}],"n":"SetSecurityDescriptorBinaryForm","o":"@$1","d":2396513,"h":253405466977,"f":1},{"r":65537,"p":[{"n":"sddlForm","p":1310721}],"n":"SetSecurityDescriptorSddlForm","d":2396513,"h":257700434273,"f":1},{"r":65537,"p":[{"n":"sddlForm","p":1310721},{"n":"includeSections","p":233825}],"n":"SetSecurityDescriptorSddlForm","o":"@$1","d":2396513,"h":261995401569,"f":1},{"r":65537,"n":"WriteLock","d":2396513,"h":266290368865,"f":4},{"r":65537,"n":"WriteUnlock","d":2396513,"h":270585336161,"f":4}],"c":[{"n":".ctor","o":"$ctor$1","d":2396513,"h":4297363809,"f":4},{"p":[{"n":"isContainer","p":262145},{"n":"isDS","p":262145}],"n":".ctor","o":"$ctor$2","d":2396513,"h":8592331105,"f":4},{"p":[{"n":"securityDescriptor","p":1282401}],"n":".ctor","o":"$ctor$3","d":2396513,"h":12887298401,"f":4}],"h":2396513}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.Security.AccessControl.ObjectSecurity`; }
        });
        
        $asm.$cls("$ssa.System.Security.Policy.EvidenceBase", ($self) => class EvidenceBase extends $.$spc.System.Object
        {
            $ctor$1()
            {
                super.$ctor();
                {
                }
                return this;
            }
            /*System.Security.Policy.EvidenceBase? */ Clone()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static $h = 3117409;
            static $f = 0b110001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"m":[{"r":3117409,"n":"Clone","d":3117409,"h":8593052001,"f":129}],"c":[{"n":".ctor","o":"$ctor$1","d":3117409,"h":4298084705,"f":4}],"h":3117409}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.Security.Policy.EvidenceBase`; }
        });
        
        $asm.$cls("$ssa.System.Security.AccessControl.GenericAcl", ($self) => class GenericAcl extends $.$spc.System.Object
        {
            /*byte*/ static AclRevision = 0;
            /*byte*/ static AclRevisionDS = 0;
            /*int*/ static MaxBinaryLength = 0;
            $ctor$1()
            {
                super.$ctor();
                {
                }
                return this;
            }
            /*bool */ get IsSynchronized()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*object */ get SyncRoot()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*void */ CopyTo(/*System.Security.AccessControl.GenericAce[]*/ array, /*int*/ index)
            {
            }
            /*System.Security.AccessControl.AceEnumerator */ GetEnumerator()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*void */ System$Collections$ICollection$CopyTo(/*System.Array*/ array, /*int*/ index)
            {
            }
            /*System.Collections.IEnumerator */ System$Collections$IEnumerable$GetEnumerator()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            //Generated interface implemetation for System.Collections.ICollection.Count.get
            get System$Collections$ICollection$Count()
            {
                return this.Count;
            }
            //Generated interface implemetation for System.Collections.ICollection.SyncRoot.get
            get System$Collections$ICollection$SyncRoot()
            {
                return this.SyncRoot;
            }
            //Generated interface implemetation for System.Collections.ICollection.IsSynchronized.get
            get System$Collections$ICollection$IsSynchronized()
            {
                return this.IsSynchronized;
            }
            static $h = 1741153;
            static $f = 0b110001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":655361,"g":{"r":0,"d":0,"h":25771544929,"f":257},"n":"BinaryLength","d":1741153,"h":21476577633,"f":257},{"p":655361,"g":{"r":0,"d":0,"h":34361479521,"f":257},"n":"Count","d":1741153,"h":30066512225,"f":257},{"p":262145,"g":{"r":0,"d":0,"h":42951414113,"f":1},"n":"IsSynchronized","d":1741153,"h":38656446817,"f":1},{"p":1675617,"i":[{"n":"index","p":655361}],"g":{"r":0,"d":0,"h":51541348705,"f":257},"s":{"r":0,"d":0,"h":55836316001,"f":257},"n":"Item","o":"@$2","d":1741153,"h":47246381409,"f":257},{"p":393217,"g":{"r":0,"d":0,"h":64426250593,"f":257},"n":"Revision","d":1741153,"h":60131283297,"f":257},{"p":131073,"g":{"r":0,"d":0,"h":73016185185,"f":129},"n":"SyncRoot","d":1741153,"h":68721217889,"f":129}],"m":[{"r":65537,"p":[{"n":"array","p":0},{"n":"index","p":655361}],"n":"CopyTo","d":1741153,"h":77311152481,"f":1},{"r":65537,"p":[{"n":"binaryForm","p":0},{"n":"offset","p":655361}],"n":"GetBinaryForm","d":1741153,"h":81606119777,"f":257},{"r":495969,"n":"GetEnumerator","d":1741153,"h":85901087073,"f":1}],"l":[{"t":393217,"n":"AclRevision","d":1741153,"h":4296708449,"f":33},{"t":393217,"n":"AclRevisionDS","d":1741153,"h":8591675745,"f":33},{"t":655361,"n":"MaxBinaryLength","d":1741153,"h":12886643041,"f":33}],"c":[{"n":".ctor","o":"$ctor$1","d":1741153,"h":17181610337,"f":4}],"i":[31391745,31653889],"h":1741153}; }
            static get $b() { return $.$spc.System.Object; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.Collections.ICollection, $.$spc.System.Collections.IEnumerable ]; }
            static get $fullName() { return `System.Security.AccessControl.GenericAcl`; }
        });
        
        $asm.$cls("$ssa.System.Security.AccessControl.AccessRule", ($self) => class AccessRule extends $.$ssa.System.Security.AccessControl.AuthorizationRule
        {
            $ctor$2(/*System.Security.Principal.IdentityReference*/ identity, /*int*/ accessMask, /*bool*/ isInherited, /*System.Security.AccessControl.InheritanceFlags*/ inheritanceFlags, /*System.Security.AccessControl.PropagationFlags*/ propagationFlags, /*System.Security.AccessControl.AccessControlType*/ type)
            {
                super.$ctor$1(null, 0, false, 0, 0);
                {
                }
                return this;
            }
            /*System.Security.AccessControl.AccessControlType */ get AccessControlType()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static $h = 364897;
            static $f = 0b110001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":954721,"p":[{"p":299361,"g":{"r":0,"d":0,"h":12885266785,"f":1},"n":"AccessControlType","d":364897,"h":8590299489,"f":1}],"c":[{"p":[{"n":"identity","p":249887},{"n":"accessMask","p":655361},{"n":"isInherited","p":262145},{"n":"inheritanceFlags","p":1872225},{"n":"propagationFlags","p":2593121},{"n":"type","p":299361}],"n":".ctor","o":"$ctor$2","d":364897,"h":4295332193,"f":4}],"h":364897}; }
            static get $b() { return $.$ssa.System.Security.AccessControl.AuthorizationRule; }
            static get $fullName() { return `System.Security.AccessControl.AccessRule`; }
        });
        
        $asm.$cls("$ssa.System.Security.AccessControl.AuditRule", ($self) => class AuditRule extends $.$ssa.System.Security.AccessControl.AuthorizationRule
        {
            $ctor$2(/*System.Security.Principal.IdentityReference*/ identity, /*int*/ accessMask, /*bool*/ isInherited, /*System.Security.AccessControl.InheritanceFlags*/ inheritanceFlags, /*System.Security.AccessControl.PropagationFlags*/ propagationFlags, /*System.Security.AccessControl.AuditFlags*/ auditFlags)
            {
                super.$ctor$1(null, 0, false, 0, 0);
                {
                }
                return this;
            }
            /*System.Security.AccessControl.AuditFlags */ get AuditFlags()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static $h = 823649;
            static $f = 0b110001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":954721,"p":[{"p":758113,"g":{"r":0,"d":0,"h":12885725537,"f":1},"n":"AuditFlags","d":823649,"h":8590758241,"f":1}],"c":[{"p":[{"n":"identity","p":249887},{"n":"accessMask","p":655361},{"n":"isInherited","p":262145},{"n":"inheritanceFlags","p":1872225},{"n":"propagationFlags","p":2593121},{"n":"auditFlags","p":758113}],"n":".ctor","o":"$ctor$2","d":823649,"h":4295790945,"f":4}],"h":823649}; }
            static get $b() { return $.$ssa.System.Security.AccessControl.AuthorizationRule; }
            static get $fullName() { return `System.Security.AccessControl.AuditRule`; }
        });
        
        $asm.$cls("$ssa.System.Security.AccessControl.CommonObjectSecurity", ($self) => class CommonObjectSecurity extends $.$ssa.System.Security.AccessControl.ObjectSecurity
        {
            $ctor$4(/*bool*/ isContainer)
            {
                super.$ctor$1();
                {
                }
                return this;
            }
            /*void */ AddAccessRule(/*System.Security.AccessControl.AccessRule*/ rule)
            {
            }
            /*void */ AddAuditRule(/*System.Security.AccessControl.AuditRule*/ rule)
            {
            }
            /*System.Security.AccessControl.AuthorizationRuleCollection */ GetAccessRules(/*bool*/ includeExplicit, /*bool*/ includeInherited, /*System.Type*/ targetType)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Security.AccessControl.AuthorizationRuleCollection */ GetAuditRules(/*bool*/ includeExplicit, /*bool*/ includeInherited, /*System.Type*/ targetType)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ ModifyAccess(/*System.Security.AccessControl.AccessControlModification*/ modification, /*System.Security.AccessControl.AccessRule*/ rule, /*out bool*/ modified)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ ModifyAudit(/*System.Security.AccessControl.AccessControlModification*/ modification, /*System.Security.AccessControl.AuditRule*/ rule, /*out bool*/ modified)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ RemoveAccessRule(/*System.Security.AccessControl.AccessRule*/ rule)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*void */ RemoveAccessRuleAll(/*System.Security.AccessControl.AccessRule*/ rule)
            {
            }
            /*void */ RemoveAccessRuleSpecific(/*System.Security.AccessControl.AccessRule*/ rule)
            {
            }
            /*bool */ RemoveAuditRule(/*System.Security.AccessControl.AuditRule*/ rule)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*void */ RemoveAuditRuleAll(/*System.Security.AccessControl.AuditRule*/ rule)
            {
            }
            /*void */ RemoveAuditRuleSpecific(/*System.Security.AccessControl.AuditRule*/ rule)
            {
            }
            /*void */ ResetAccessRule(/*System.Security.AccessControl.AccessRule*/ rule)
            {
            }
            /*void */ SetAccessRule(/*System.Security.AccessControl.AccessRule*/ rule)
            {
            }
            /*void */ SetAuditRule(/*System.Security.AccessControl.AuditRule*/ rule)
            {
            }
            static $h = 1216865;
            static $f = 0b110001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":2396513,"m":[{"r":65537,"p":[{"n":"rule","p":364897}],"n":"AddAccessRule","d":1216865,"h":8591151457,"f":4},{"r":65537,"p":[{"n":"rule","p":823649}],"n":"AddAuditRule","d":1216865,"h":12886118753,"f":4},{"r":1020257,"p":[{"n":"includeExplicit","p":262145},{"n":"includeInherited","p":262145},{"n":"targetType","p":142606337}],"n":"GetAccessRules","d":1216865,"h":17181086049,"f":1},{"r":1020257,"p":[{"n":"includeExplicit","p":262145},{"n":"includeInherited","p":262145},{"n":"targetType","p":142606337}],"n":"GetAuditRules","d":1216865,"h":21476053345,"f":1},{"r":262145,"p":[{"n":"modification","p":168289},{"n":"rule","p":364897},{"n":"modified","p":262145,"f":2}],"n":"ModifyAccess","d":1216865,"h":25771020641,"f":32772},{"r":262145,"p":[{"n":"modification","p":168289},{"n":"rule","p":823649},{"n":"modified","p":262145,"f":2}],"n":"ModifyAudit","d":1216865,"h":30065987937,"f":32772},{"r":262145,"p":[{"n":"rule","p":364897}],"n":"RemoveAccessRule","d":1216865,"h":34360955233,"f":4},{"r":65537,"p":[{"n":"rule","p":364897}],"n":"RemoveAccessRuleAll","d":1216865,"h":38655922529,"f":4},{"r":65537,"p":[{"n":"rule","p":364897}],"n":"RemoveAccessRuleSpecific","d":1216865,"h":42950889825,"f":4},{"r":262145,"p":[{"n":"rule","p":823649}],"n":"RemoveAuditRule","d":1216865,"h":47245857121,"f":4},{"r":65537,"p":[{"n":"rule","p":823649}],"n":"RemoveAuditRuleAll","d":1216865,"h":51540824417,"f":4},{"r":65537,"p":[{"n":"rule","p":823649}],"n":"RemoveAuditRuleSpecific","d":1216865,"h":55835791713,"f":4},{"r":65537,"p":[{"n":"rule","p":364897}],"n":"ResetAccessRule","d":1216865,"h":60130759009,"f":4},{"r":65537,"p":[{"n":"rule","p":364897}],"n":"SetAccessRule","d":1216865,"h":64425726305,"f":4},{"r":65537,"p":[{"n":"rule","p":823649}],"n":"SetAuditRule","d":1216865,"h":68720693601,"f":4}],"c":[{"p":[{"n":"isContainer","p":262145}],"n":".ctor","o":"$ctor$4","d":1216865,"h":4296184161,"f":4}],"h":1216865}; }
            static get $b() { return $.$ssa.System.Security.AccessControl.ObjectSecurity; }
            static get $fullName() { return `System.Security.AccessControl.CommonObjectSecurity`; }
        });
        
        $asm.$cls("$ssa.System.Security.AccessControl.KnownAce", ($self) => class KnownAce extends $.$ssa.System.Security.AccessControl.GenericAce
        {
            $ctor$2()
            {
                super.$ctor$1();
                {
                }
                return this;
            }
            /*int */ get AccessMask()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ set AccessMask(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Security.Principal.SecurityIdentifier */ get SecurityIdentifier()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Security.Principal.SecurityIdentifier */ set SecurityIdentifier(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static $h = 1937761;
            static $f = 0b110001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":1675617,"p":[{"p":655361,"g":{"r":0,"d":0,"h":12886839649,"f":1},"s":{"r":0,"d":0,"h":17181806945,"f":1},"n":"AccessMask","d":1937761,"h":8591872353,"f":1},{"p":446495,"g":{"r":0,"d":0,"h":25771741537,"f":1},"s":{"r":0,"d":0,"h":30066708833,"f":1},"n":"SecurityIdentifier","d":1937761,"h":21476774241,"f":1}],"c":[{"n":".ctor","o":"$ctor$2","d":1937761,"h":4296905057,"f":8}],"h":1937761}; }
            static get $b() { return $.$ssa.System.Security.AccessControl.GenericAce; }
            static get $fullName() { return `System.Security.AccessControl.KnownAce`; }
        });
        
        $asm.$cls("$ssa.System.Security.AccessControl.CommonAcl", ($self) => class CommonAcl extends $.$ssa.System.Security.AccessControl.GenericAcl
        {
            $ctor$2()
            {
                super.$ctor$1();
                {
                }
                return this;
            }
            /*int */ get BinaryLength()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ get Count()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get IsCanonical()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get IsContainer()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get IsDS()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Security.AccessControl.GenericAce*/ get_Item(/*int*/ index)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*void*/ set_Item(/*int*/ index, /*System.Security.AccessControl.GenericAce*/ value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*byte */ get Revision()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*void */ GetBinaryForm(/*byte[]*/ binaryForm, /*int*/ offset)
            {
            }
            /*void */ Purge(/*System.Security.Principal.SecurityIdentifier*/ sid)
            {
            }
            /*void */ RemoveInheritedAces()
            {
            }
            static $h = 1151329;
            static $f = 0b110001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":1741153,"p":[{"p":655361,"g":{"r":0,"d":0,"h":12886053217,"f":98305},"n":"BinaryLength","d":1151329,"h":8591085921,"f":98305},{"p":655361,"g":{"r":0,"d":0,"h":21475987809,"f":98305},"n":"Count","d":1151329,"h":17181020513,"f":98305},{"p":262145,"g":{"r":0,"d":0,"h":30065922401,"f":1},"n":"IsCanonical","d":1151329,"h":25770955105,"f":1},{"p":262145,"g":{"r":0,"d":0,"h":38655856993,"f":1},"n":"IsContainer","d":1151329,"h":34360889697,"f":1},{"p":262145,"g":{"r":0,"d":0,"h":47245791585,"f":1},"n":"IsDS","d":1151329,"h":42950824289,"f":1},{"p":1675617,"i":[{"n":"index","p":655361}],"g":{"r":0,"d":0,"h":55835726177,"f":98305},"s":{"r":0,"d":0,"h":60130693473,"f":98305},"n":"Item","o":"@$2","d":1151329,"h":51540758881,"f":98305},{"p":393217,"g":{"r":0,"d":0,"h":68720628065,"f":98305},"n":"Revision","d":1151329,"h":64425660769,"f":98305}],"m":[{"r":65537,"p":[{"n":"binaryForm","p":0},{"n":"offset","p":655361}],"n":"GetBinaryForm","d":1151329,"h":73015595361,"f":98305},{"r":65537,"p":[{"n":"sid","p":446495}],"n":"Purge","d":1151329,"h":77310562657,"f":1},{"r":65537,"n":"RemoveInheritedAces","d":1151329,"h":81605529953,"f":1}],"c":[{"n":".ctor","o":"$ctor$2","d":1151329,"h":4296118625,"f":8}],"i":[31391745,31653889],"h":1151329}; }
            static get $b() { return $.$ssa.System.Security.AccessControl.GenericAcl; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.Collections.ICollection, $.$spc.System.Collections.IEnumerable ]; }
            static get $fullName() { return `System.Security.AccessControl.CommonAcl`; }
        });
        
        $asm.$cls("$ssa.System.Security.AccessControl.NativeObjectSecurity", ($self) => class NativeObjectSecurity extends $.$ssa.System.Security.AccessControl.CommonObjectSecurity
        {
            $ctor$5(/*bool*/ isContainer, /*System.Security.AccessControl.ResourceType*/ resourceType)
            {
                super.$ctor$4(false);
                {
                }
                return this;
            }
            $ctor$6(/*bool*/ isContainer, /*System.Security.AccessControl.ResourceType*/ resourceType, /*System.Runtime.InteropServices.SafeHandle?*/ handle, /*System.Security.AccessControl.AccessControlSections*/ includeSections)
            {
                super.$ctor$4(false);
                {
                }
                return this;
            }
            $ctor$7(/*bool*/ isContainer, /*System.Security.AccessControl.ResourceType*/ resourceType, /*System.Runtime.InteropServices.SafeHandle?*/ handle, /*System.Security.AccessControl.AccessControlSections*/ includeSections, /*System.Security.AccessControl.NativeObjectSecurity.ExceptionFromErrorCode?*/ exceptionFromErrorCode, /*object?*/ exceptionContext)
            {
                super.$ctor$4(false);
                {
                }
                return this;
            }
            $ctor$8(/*bool*/ isContainer, /*System.Security.AccessControl.ResourceType*/ resourceType, /*System.Security.AccessControl.NativeObjectSecurity.ExceptionFromErrorCode?*/ exceptionFromErrorCode, /*object?*/ exceptionContext)
            {
                super.$ctor$4(false);
                {
                }
                return this;
            }
            $ctor$9(/*bool*/ isContainer, /*System.Security.AccessControl.ResourceType*/ resourceType, /*string?*/ name, /*System.Security.AccessControl.AccessControlSections*/ includeSections)
            {
                super.$ctor$4(false);
                {
                }
                return this;
            }
            $ctor$10(/*bool*/ isContainer, /*System.Security.AccessControl.ResourceType*/ resourceType, /*string?*/ name, /*System.Security.AccessControl.AccessControlSections*/ includeSections, /*System.Security.AccessControl.NativeObjectSecurity.ExceptionFromErrorCode?*/ exceptionFromErrorCode, /*object?*/ exceptionContext)
            {
                super.$ctor$4(false);
                {
                }
                return this;
            }
            /*void */ Persist$1(/*System.Runtime.InteropServices.SafeHandle*/ handle, /*System.Security.AccessControl.AccessControlSections*/ includeSections)
            {
            }
            /*void */ Persist$3(/*System.Runtime.InteropServices.SafeHandle*/ handle, /*System.Security.AccessControl.AccessControlSections*/ includeSections, /*object?*/ exceptionContext)
            {
            }
            /*void */ Persist$2(/*string*/ name, /*System.Security.AccessControl.AccessControlSections*/ includeSections)
            {
            }
            /*void */ Persist$4(/*string*/ name, /*System.Security.AccessControl.AccessControlSections*/ includeSections, /*object?*/ exceptionContext)
            {
            }
            static $_ExceptionFromErrorCode;
            static get ExceptionFromErrorCode()
            {
                let $cls = $.$ssa.System.Security.AccessControl.NativeObjectSecurity;
                return $cls.$_ExceptionFromErrorCode ??= $asm.$ncls("$ssa.System.Security.AccessControl.NativeObjectSecurity.ExceptionFromErrorCode", ($self) => class ExceptionFromErrorCode extends $.$spc.System.MulticastDelegate
                {
                    $ctor(/*object*/ target, fn, anmodel)
                    {
                        this.$target = target;
                        this.$nativeFunction = fn;
                        if (anmodel) this.$nfmodel = anmodel;
                        if (typeof(target) === 'object') this._target = target;
                        return this;
                    }
                    /*System.Exception?*/ Invoke(/*$.$spc.System.Int32*/ errorCode, /*$.$spc.System.Nullable$$*/ name, /*$.$spc.System.Nullable$$*/ handle, /*$.$spc.System.Nullable$$*/ context)
                    {
                        return this.$nativeFunction.call(this.$target, errorCode, name, handle, context);
                    }
                    static $h = 2068833;
                    static $f = 0b10000000010000000;
                    static $k = 5;
                    static $$md;
                    static get $md() { return this.$$md ??= {"b":66191361,"m":[{"r":47251457,"p":[{"n":"errorCode","p":655361},{"n":"name","p":1310721},{"n":"handle","p":109576193},{"n":"context","p":131073}],"n":"Invoke","d":2068833,"h":8592003425,"f":129},{"r":57016321,"p":[{"n":"errorCode","p":655361},{"n":"name","p":1310721},{"n":"handle","p":109576193},{"n":"context","p":131073},{"n":"callback","p":14483457},{"n":"object","p":131073}],"n":"BeginInvoke","d":2068833,"h":12886970721,"f":129},{"r":47251457,"p":[{"n":"result","p":57016321}],"n":"EndInvoke","d":2068833,"h":17181938017,"f":129}],"c":[{"p":[{"n":"object","p":131073},{"n":"method","p":786433}],"n":".ctor","o":"$ctor$5","d":2068833,"h":4297036129,"f":1}],"i":[57212929,113377281],"d":2003297,"h":2068833}; }
                    static get $b() { return $.$spc.System.MulticastDelegate; }
                    static $$i;
                    static get $i() { return this.$$i ??= [ $.$spc.System.ICloneable, $.$spc.System.Runtime.Serialization.ISerializable ]; }
                    static get $fullName() { return `System.Security.AccessControl.NativeObjectSecurity.ExceptionFromErrorCode`; }
                }, $cls, ($v) => $cls.$_ExceptionFromErrorCode = $v);
            }
            static $h = 2003297;
            static $f = 0b110001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":1216865,"m":[{"r":65537,"p":[{"n":"handle","p":109576193},{"n":"includeSections","p":233825}],"n":"Persist","o":"@$1","d":2003297,"h":30066774369,"f":98308},{"r":65537,"p":[{"n":"handle","p":109576193},{"n":"includeSections","p":233825},{"n":"exceptionContext","p":131073}],"n":"Persist","o":"@$3","d":2003297,"h":34361741665,"f":4},{"r":65537,"p":[{"n":"name","p":1310721},{"n":"includeSections","p":233825}],"n":"Persist","o":"@$2","d":2003297,"h":38656708961,"f":98308},{"r":65537,"p":[{"n":"name","p":1310721},{"n":"includeSections","p":233825},{"n":"exceptionContext","p":131073}],"n":"Persist","o":"@$4","d":2003297,"h":42951676257,"f":4}],"c":[{"p":[{"n":"isContainer","p":262145},{"n":"resourceType","p":2855265}],"n":".ctor","o":"$ctor$5","d":2003297,"h":4296970593,"f":4},{"p":[{"n":"isContainer","p":262145},{"n":"resourceType","p":2855265},{"n":"handle","p":109576193},{"n":"includeSections","p":233825}],"n":".ctor","o":"$ctor$6","d":2003297,"h":8591937889,"f":4},{"p":[{"n":"isContainer","p":262145},{"n":"resourceType","p":2855265},{"n":"handle","p":109576193},{"n":"includeSections","p":233825},{"n":"exceptionFromErrorCode","p":2068833},{"n":"exceptionContext","p":131073}],"n":".ctor","o":"$ctor$7","d":2003297,"h":12886905185,"f":4},{"p":[{"n":"isContainer","p":262145},{"n":"resourceType","p":2855265},{"n":"exceptionFromErrorCode","p":2068833},{"n":"exceptionContext","p":131073}],"n":".ctor","o":"$ctor$8","d":2003297,"h":17181872481,"f":4},{"p":[{"n":"isContainer","p":262145},{"n":"resourceType","p":2855265},{"n":"name","p":1310721},{"n":"includeSections","p":233825}],"n":".ctor","o":"$ctor$9","d":2003297,"h":21476839777,"f":4},{"p":[{"n":"isContainer","p":262145},{"n":"resourceType","p":2855265},{"n":"name","p":1310721},{"n":"includeSections","p":233825},{"n":"exceptionFromErrorCode","p":2068833},{"n":"exceptionContext","p":131073}],"n":".ctor","o":"$ctor$10","d":2003297,"h":25771807073,"f":4}],"j":[2068833],"h":2003297}; }
            static get $b() { return $.$ssa.System.Security.AccessControl.CommonObjectSecurity; }
            static get $fullName() { return `System.Security.AccessControl.NativeObjectSecurity`; }
        });
        
        $asm.$cls("$ssa.System.Security.AccessControl.ObjectAccessRule", ($self) => class ObjectAccessRule extends $.$ssa.System.Security.AccessControl.AccessRule
        {
            $ctor$3(/*System.Security.Principal.IdentityReference*/ identity, /*int*/ accessMask, /*bool*/ isInherited, /*System.Security.AccessControl.InheritanceFlags*/ inheritanceFlags, /*System.Security.AccessControl.PropagationFlags*/ propagationFlags, /*System.Guid*/ objectType, /*System.Guid*/ inheritedObjectType, /*System.Security.AccessControl.AccessControlType*/ type)
            {
                super.$ctor$2(null, 0, false, 0, 0, 0);
                {
                }
                return this;
            }
            /*System.Guid */ get InheritedObjectType()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Security.AccessControl.ObjectAceFlags */ get ObjectFlags()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Guid */ get ObjectType()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static $h = 2134369;
            static $f = 0b110001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":364897,"p":[{"p":56229889,"g":{"r":0,"d":0,"h":12887036257,"f":1},"n":"InheritedObjectType","d":2134369,"h":8592068961,"f":1},{"p":2265441,"g":{"r":0,"d":0,"h":21476970849,"f":1},"n":"ObjectFlags","d":2134369,"h":17182003553,"f":1},{"p":56229889,"g":{"r":0,"d":0,"h":30066905441,"f":1},"n":"ObjectType","d":2134369,"h":25771938145,"f":1}],"c":[{"p":[{"n":"identity","p":249887},{"n":"accessMask","p":655361},{"n":"isInherited","p":262145},{"n":"inheritanceFlags","p":1872225},{"n":"propagationFlags","p":2593121},{"n":"objectType","p":56229889},{"n":"inheritedObjectType","p":56229889},{"n":"type","p":299361}],"n":".ctor","o":"$ctor$3","d":2134369,"h":4297101665,"f":4}],"h":2134369}; }
            static get $b() { return $.$ssa.System.Security.AccessControl.AccessRule; }
            static get $fullName() { return `System.Security.AccessControl.ObjectAccessRule`; }
        });
        
        $asm.$cls("$ssa.System.Security.AccessControl.ObjectAuditRule", ($self) => class ObjectAuditRule extends $.$ssa.System.Security.AccessControl.AuditRule
        {
            $ctor$3(/*System.Security.Principal.IdentityReference*/ identity, /*int*/ accessMask, /*bool*/ isInherited, /*System.Security.AccessControl.InheritanceFlags*/ inheritanceFlags, /*System.Security.AccessControl.PropagationFlags*/ propagationFlags, /*System.Guid*/ objectType, /*System.Guid*/ inheritedObjectType, /*System.Security.AccessControl.AuditFlags*/ auditFlags)
            {
                super.$ctor$2(null, 0, false, 0, 0, 0);
                {
                }
                return this;
            }
            /*System.Guid */ get InheritedObjectType()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Security.AccessControl.ObjectAceFlags */ get ObjectFlags()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Guid */ get ObjectType()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static $h = 2330977;
            static $f = 0b110001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":823649,"p":[{"p":56229889,"g":{"r":0,"d":0,"h":12887232865,"f":1},"n":"InheritedObjectType","d":2330977,"h":8592265569,"f":1},{"p":2265441,"g":{"r":0,"d":0,"h":21477167457,"f":1},"n":"ObjectFlags","d":2330977,"h":17182200161,"f":1},{"p":56229889,"g":{"r":0,"d":0,"h":30067102049,"f":1},"n":"ObjectType","d":2330977,"h":25772134753,"f":1}],"c":[{"p":[{"n":"identity","p":249887},{"n":"accessMask","p":655361},{"n":"isInherited","p":262145},{"n":"inheritanceFlags","p":1872225},{"n":"propagationFlags","p":2593121},{"n":"objectType","p":56229889},{"n":"inheritedObjectType","p":56229889},{"n":"auditFlags","p":758113}],"n":".ctor","o":"$ctor$3","d":2330977,"h":4297298273,"f":4}],"h":2330977}; }
            static get $b() { return $.$ssa.System.Security.AccessControl.AuditRule; }
            static get $fullName() { return `System.Security.AccessControl.ObjectAuditRule`; }
        });
        
        $asm.$cls("$ssa.System.Security.AccessControl.QualifiedAce", ($self) => class QualifiedAce extends $.$ssa.System.Security.AccessControl.KnownAce
        {
            $ctor$3()
            {
                super.$ctor$2();
                {
                }
                return this;
            }
            /*System.Security.AccessControl.AceQualifier */ get AceQualifier()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get IsCallback()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ get OpaqueLength()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*byte[]? */ GetOpaque()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*void */ SetOpaque(/*byte[]?*/ opaque)
            {
            }
            static $h = 2658657;
            static $f = 0b110001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":1937761,"p":[{"p":627041,"g":{"r":0,"d":0,"h":12887560545,"f":1},"n":"AceQualifier","d":2658657,"h":8592593249,"f":1},{"p":262145,"g":{"r":0,"d":0,"h":21477495137,"f":1},"n":"IsCallback","d":2658657,"h":17182527841,"f":1},{"p":655361,"g":{"r":0,"d":0,"h":30067429729,"f":1},"n":"OpaqueLength","d":2658657,"h":25772462433,"f":1}],"m":[{"r":0,"n":"GetOpaque","d":2658657,"h":34362397025,"f":1},{"r":65537,"p":[{"n":"opaque","p":0}],"n":"SetOpaque","d":2658657,"h":38657364321,"f":1}],"c":[{"n":".ctor","o":"$ctor$3","d":2658657,"h":4297625953,"f":8}],"h":2658657}; }
            static get $b() { return $.$ssa.System.Security.AccessControl.KnownAce; }
            static get $fullName() { return `System.Security.AccessControl.QualifiedAce`; }
        });
        
        $asm.$cls("$ssa.System.Security.AccessControl.ObjectSecurity<>", (T) => $asm.$gt("$ssa.System.Security.AccessControl.ObjectSecurity<>", [T], ($self) => class ObjectSecurity$$ extends $.$ssa.System.Security.AccessControl.NativeObjectSecurity
        {
            $ctor$11(/*bool*/ isContainer, /*System.Security.AccessControl.ResourceType*/ resourceType)
            {
                super.$ctor$5(false, 0);
                {
                }
                return this;
            }
            $ctor$12(/*bool*/ isContainer, /*System.Security.AccessControl.ResourceType*/ resourceType, /*System.Runtime.InteropServices.SafeHandle?*/ safeHandle, /*System.Security.AccessControl.AccessControlSections*/ includeSections)
            {
                super.$ctor$5(false, 0);
                {
                }
                return this;
            }
            $ctor$13(/*bool*/ isContainer, /*System.Security.AccessControl.ResourceType*/ resourceType, /*System.Runtime.InteropServices.SafeHandle?*/ safeHandle, /*System.Security.AccessControl.AccessControlSections*/ includeSections, /*System.Security.AccessControl.NativeObjectSecurity.ExceptionFromErrorCode?*/ exceptionFromErrorCode, /*object?*/ exceptionContext)
            {
                super.$ctor$5(false, 0);
                {
                }
                return this;
            }
            $ctor$14(/*bool*/ isContainer, /*System.Security.AccessControl.ResourceType*/ resourceType, /*string?*/ name, /*System.Security.AccessControl.AccessControlSections*/ includeSections)
            {
                super.$ctor$5(false, 0);
                {
                }
                return this;
            }
            $ctor$15(/*bool*/ isContainer, /*System.Security.AccessControl.ResourceType*/ resourceType, /*string?*/ name, /*System.Security.AccessControl.AccessControlSections*/ includeSections, /*System.Security.AccessControl.NativeObjectSecurity.ExceptionFromErrorCode?*/ exceptionFromErrorCode, /*object?*/ exceptionContext)
            {
                super.$ctor$5(false, 0);
                {
                }
                return this;
            }
            /*System.Type */ get AccessRightType()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Type */ get AccessRuleType()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Type */ get AuditRuleType()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Security.AccessControl.AccessRule */ AccessRuleFactory(/*System.Security.Principal.IdentityReference*/ identityReference, /*int*/ accessMask, /*bool*/ isInherited, /*System.Security.AccessControl.InheritanceFlags*/ inheritanceFlags, /*System.Security.AccessControl.PropagationFlags*/ propagationFlags, /*System.Security.AccessControl.AccessControlType*/ type)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*void */ AddAccessRule$1(/*System.Security.AccessControl.AccessRule<T>*/ rule)
            {
            }
            /*void */ AddAuditRule$1(/*System.Security.AccessControl.AuditRule<T>*/ rule)
            {
            }
            /*System.Security.AccessControl.AuditRule */ AuditRuleFactory(/*System.Security.Principal.IdentityReference*/ identityReference, /*int*/ accessMask, /*bool*/ isInherited, /*System.Security.AccessControl.InheritanceFlags*/ inheritanceFlags, /*System.Security.AccessControl.PropagationFlags*/ propagationFlags, /*System.Security.AccessControl.AuditFlags*/ flags)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*void */ Persist$5(/*System.Runtime.InteropServices.SafeHandle*/ handle)
            {
            }
            /*void */ Persist$6(/*string*/ name)
            {
            }
            /*bool */ RemoveAccessRule$1(/*System.Security.AccessControl.AccessRule<T>*/ rule)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*void */ RemoveAccessRuleAll$1(/*System.Security.AccessControl.AccessRule<T>*/ rule)
            {
            }
            /*void */ RemoveAccessRuleSpecific$1(/*System.Security.AccessControl.AccessRule<T>*/ rule)
            {
            }
            /*bool */ RemoveAuditRule$1(/*System.Security.AccessControl.AuditRule<T>*/ rule)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*void */ RemoveAuditRuleAll$1(/*System.Security.AccessControl.AuditRule<T>*/ rule)
            {
            }
            /*void */ RemoveAuditRuleSpecific$1(/*System.Security.AccessControl.AuditRule<T>*/ rule)
            {
            }
            /*void */ ResetAccessRule$1(/*System.Security.AccessControl.AccessRule<T>*/ rule)
            {
            }
            /*void */ SetAccessRule$1(/*System.Security.AccessControl.AccessRule<T>*/ rule)
            {
            }
            /*void */ SetAuditRule$1(/*System.Security.AccessControl.AuditRule<T>*/ rule)
            {
            }
            static $h = 2462049;
            static $g = 1;
            static $f = 0b1110001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":2003297,"p":[{"p":142606337,"g":{"r":0,"d":0,"h":Number(BigInt(this.$h)|0x700000000n),"f":32769},"n":"AccessRightType","d":this.$h,"h":Number(BigInt(this.$h)|0x600000000n),"f":32769},{"p":142606337,"g":{"r":0,"d":0,"h":Number(BigInt(this.$h)|0x900000000n),"f":32769},"n":"AccessRuleType","d":this.$h,"h":Number(BigInt(this.$h)|0x800000000n),"f":32769},{"p":142606337,"g":{"r":0,"d":0,"h":Number(BigInt(this.$h)|0xB00000000n),"f":32769},"n":"AuditRuleType","d":this.$h,"h":Number(BigInt(this.$h)|0xA00000000n),"f":32769}],"m":[{"r":364897,"p":[{"n":"identityReference","p":249887},{"n":"accessMask","p":655361},{"n":"isInherited","p":262145},{"n":"inheritanceFlags","p":1872225},{"n":"propagationFlags","p":2593121},{"n":"type","p":299361}],"n":"AccessRuleFactory","d":this.$h,"h":Number(BigInt(this.$h)|0xC00000000n),"f":32769},{"r":65537,"p":[{"n":"rule","p":$.$ssa.System.Security.AccessControl.AccessRule$$(T).$h}],"n":"AddAccessRule","o":"@$1","d":this.$h,"h":Number(BigInt(this.$h)|0xD00000000n),"f":129},{"r":65537,"p":[{"n":"rule","p":$.$ssa.System.Security.AccessControl.AuditRule$$(T).$h}],"n":"AddAuditRule","o":"@$1","d":this.$h,"h":Number(BigInt(this.$h)|0xE00000000n),"f":129},{"r":823649,"p":[{"n":"identityReference","p":249887},{"n":"accessMask","p":655361},{"n":"isInherited","p":262145},{"n":"inheritanceFlags","p":1872225},{"n":"propagationFlags","p":2593121},{"n":"flags","p":758113}],"n":"AuditRuleFactory","d":this.$h,"h":Number(BigInt(this.$h)|0xF00000000n),"f":32769},{"r":65537,"p":[{"n":"handle","p":109576193}],"n":"Persist","o":"@$5","d":this.$h,"h":Number(BigInt(this.$h)|0x1000000000n),"f":16},{"r":65537,"p":[{"n":"name","p":1310721}],"n":"Persist","o":"@$6","d":this.$h,"h":Number(BigInt(this.$h)|0x1100000000n),"f":16},{"r":262145,"p":[{"n":"rule","p":$.$ssa.System.Security.AccessControl.AccessRule$$(T).$h}],"n":"RemoveAccessRule","o":"@$1","d":this.$h,"h":Number(BigInt(this.$h)|0x1200000000n),"f":129},{"r":65537,"p":[{"n":"rule","p":$.$ssa.System.Security.AccessControl.AccessRule$$(T).$h}],"n":"RemoveAccessRuleAll","o":"@$1","d":this.$h,"h":Number(BigInt(this.$h)|0x1300000000n),"f":129},{"r":65537,"p":[{"n":"rule","p":$.$ssa.System.Security.AccessControl.AccessRule$$(T).$h}],"n":"RemoveAccessRuleSpecific","o":"@$1","d":this.$h,"h":Number(BigInt(this.$h)|0x1400000000n),"f":129},{"r":262145,"p":[{"n":"rule","p":$.$ssa.System.Security.AccessControl.AuditRule$$(T).$h}],"n":"RemoveAuditRule","o":"@$1","d":this.$h,"h":Number(BigInt(this.$h)|0x1500000000n),"f":129},{"r":65537,"p":[{"n":"rule","p":$.$ssa.System.Security.AccessControl.AuditRule$$(T).$h}],"n":"RemoveAuditRuleAll","o":"@$1","d":this.$h,"h":Number(BigInt(this.$h)|0x1600000000n),"f":129},{"r":65537,"p":[{"n":"rule","p":$.$ssa.System.Security.AccessControl.AuditRule$$(T).$h}],"n":"RemoveAuditRuleSpecific","o":"@$1","d":this.$h,"h":Number(BigInt(this.$h)|0x1700000000n),"f":129},{"r":65537,"p":[{"n":"rule","p":$.$ssa.System.Security.AccessControl.AccessRule$$(T).$h}],"n":"ResetAccessRule","o":"@$1","d":this.$h,"h":Number(BigInt(this.$h)|0x1800000000n),"f":129},{"r":65537,"p":[{"n":"rule","p":$.$ssa.System.Security.AccessControl.AccessRule$$(T).$h}],"n":"SetAccessRule","o":"@$1","d":this.$h,"h":Number(BigInt(this.$h)|0x1900000000n),"f":129},{"r":65537,"p":[{"n":"rule","p":$.$ssa.System.Security.AccessControl.AuditRule$$(T).$h}],"n":"SetAuditRule","o":"@$1","d":this.$h,"h":Number(BigInt(this.$h)|0x1A00000000n),"f":129}],"c":[{"p":[{"n":"isContainer","p":262145},{"n":"resourceType","p":2855265}],"n":".ctor","o":"$ctor$11","d":this.$h,"h":Number(BigInt(this.$h)|0x100000000n),"f":4},{"p":[{"n":"isContainer","p":262145},{"n":"resourceType","p":2855265},{"n":"safeHandle","p":109576193},{"n":"includeSections","p":233825}],"n":".ctor","o":"$ctor$12","d":this.$h,"h":Number(BigInt(this.$h)|0x200000000n),"f":4},{"p":[{"n":"isContainer","p":262145},{"n":"resourceType","p":2855265},{"n":"safeHandle","p":109576193},{"n":"includeSections","p":233825},{"n":"exceptionFromErrorCode","p":2068833},{"n":"exceptionContext","p":131073}],"n":".ctor","o":"$ctor$13","d":this.$h,"h":Number(BigInt(this.$h)|0x300000000n),"f":4},{"p":[{"n":"isContainer","p":262145},{"n":"resourceType","p":2855265},{"n":"name","p":1310721},{"n":"includeSections","p":233825}],"n":".ctor","o":"$ctor$14","d":this.$h,"h":Number(BigInt(this.$h)|0x400000000n),"f":4},{"p":[{"n":"isContainer","p":262145},{"n":"resourceType","p":2855265},{"n":"name","p":1310721},{"n":"includeSections","p":233825},{"n":"exceptionFromErrorCode","p":2068833},{"n":"exceptionContext","p":131073}],"n":".ctor","o":"$ctor$15","d":this.$h,"h":Number(BigInt(this.$h)|0x500000000n),"f":4}],"g":[T?.$h??1507328],"s":[{"n":"T","f":2}],"r":1,"h":this.$h}; }
            static get $b() { return $.$ssa.System.Security.AccessControl.NativeObjectSecurity; }
            static get $fullName() { return `System.Security.AccessControl.ObjectSecurity<${T?.$fullName}>`; }
        }));
        
        $asm.$cls("$ssa.System.Security.AccessControl.AceEnumerator", ($self) => class AceEnumerator extends $.$spc.System.Object
        {
            $ctor$1()
            {
                super.$ctor();
                {
                }
                return this;
            }
            /*System.Security.AccessControl.GenericAce */ get Current()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*object */ get System$Collections$IEnumerator$Current()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ MoveNext()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*void */ Reset()
            {
            }
            //Generated interface implemetation for System.Collections.IEnumerator.MoveNext()
            System$Collections$IEnumerator$MoveNext()
            {
                return this.MoveNext(...arguments);
            }
            //Generated interface implemetation for System.Collections.IEnumerator.Reset()
            System$Collections$IEnumerator$Reset()
            {
                return this.Reset(...arguments);
            }
            static $h = 495969;
            static $f = 0b10010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":1675617,"g":{"r":0,"d":0,"h":12885397857,"f":1},"n":"Current","d":495969,"h":8590430561,"f":1},{"p":131073,"g":{"r":0,"d":0,"h":21475332449,"f":2},"n":"{31784961}.Current","o":"System$Collections$IEnumerator$Current","d":495969,"h":17180365153,"f":2}],"m":[{"r":262145,"n":"MoveNext","d":495969,"h":25770299745,"f":1},{"r":65537,"n":"Reset","d":495969,"h":30065267041,"f":1}],"c":[{"n":".ctor","o":"$ctor$1","d":495969,"h":4295463265,"f":8}],"i":[31784961],"h":495969}; }
            static get $b() { return $.$spc.System.Object; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.Collections.IEnumerator ]; }
            static get $fullName() { return `System.Security.AccessControl.AceEnumerator`; }
        });
        
        $asm.$cls("$ssa.System.Security.Policy.Evidence", ($self) => class Evidence extends $.$spc.System.Object
        {
            $ctor$1()
            {
                super.$ctor();
                {
                }
                return this;
            }
            $ctor$2(/*object[]*/ hostEvidence, /*object[]*/ assemblyEvidence)
            {
                super.$ctor();
                {
                }
                return this;
            }
            $ctor$3(/*System.Security.Policy.Evidence*/ evidence)
            {
                super.$ctor();
                {
                }
                return this;
            }
            $ctor$4(/*System.Security.Policy.EvidenceBase[]*/ hostEvidence, /*System.Security.Policy.EvidenceBase[]*/ assemblyEvidence)
            {
                super.$ctor();
                {
                }
                return this;
            }
            /*int */ get Count()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get IsReadOnly()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get IsSynchronized()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get Locked()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ set Locked(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*object */ get SyncRoot()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*void */ AddAssembly(/*object*/ id)
            {
            }
            /*void */ AddAssemblyEvidence(T, /*T*/ evidence)
            {
            }
            /*void */ AddHost(/*object*/ id)
            {
            }
            /*void */ AddHostEvidence(T, /*T*/ evidence)
            {
            }
            /*void */ Clear()
            {
            }
            /*System.Security.Policy.Evidence? */ Clone()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*void */ CopyTo(/*System.Array*/ array, /*int*/ index)
            {
            }
            /*System.Collections.IEnumerator */ GetAssemblyEnumerator()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*T? */ GetAssemblyEvidence(T)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Collections.IEnumerator */ GetEnumerator()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Collections.IEnumerator */ GetHostEnumerator()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*T? */ GetHostEvidence(T)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*void */ Merge(/*System.Security.Policy.Evidence*/ evidence)
            {
            }
            /*void */ RemoveType(/*System.Type*/ t)
            {
            }
            //Generated interface implemetation for System.Collections.ICollection.CopyTo(System.Array, int)
            System$Collections$ICollection$CopyTo()
            {
                return this.CopyTo(...arguments);
            }
            //Generated interface implemetation for System.Collections.ICollection.Count.get
            get System$Collections$ICollection$Count()
            {
                return this.Count;
            }
            //Generated interface implemetation for System.Collections.ICollection.SyncRoot.get
            get System$Collections$ICollection$SyncRoot()
            {
                return this.SyncRoot;
            }
            //Generated interface implemetation for System.Collections.ICollection.IsSynchronized.get
            get System$Collections$ICollection$IsSynchronized()
            {
                return this.IsSynchronized;
            }
            //Generated interface implemetation for System.Collections.IEnumerable.GetEnumerator()
            System$Collections$IEnumerable$GetEnumerator()
            {
                return this.GetEnumerator(...arguments);
            }
            static $h = 3051873;
            static $f = 0b10010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":655361,"g":{"r":0,"d":0,"h":25772855649,"f":1},"n":"Count","d":3051873,"h":21477888353,"f":1,"a":[{"t":70909953,"c":8660844545,"a":[{"v":"Evidence should not be treated as an ICollection. Use GetHostEnumerator and GetAssemblyEnumerator to iterate over the evidence to collect a count.","t":1310721}]}]},{"p":262145,"g":{"r":0,"d":0,"h":34362790241,"f":1},"n":"IsReadOnly","d":3051873,"h":30067822945,"f":1},{"p":262145,"g":{"r":0,"d":0,"h":42952724833,"f":1},"n":"IsSynchronized","d":3051873,"h":38657757537,"f":1},{"p":262145,"g":{"r":0,"d":0,"h":51542659425,"f":1},"s":{"r":0,"d":0,"h":55837626721,"f":1},"n":"Locked","d":3051873,"h":47247692129,"f":1},{"p":131073,"g":{"r":0,"d":0,"h":64427561313,"f":1},"n":"SyncRoot","d":3051873,"h":60132594017,"f":1}],"m":[{"r":65537,"p":[{"n":"id","p":131073}],"n":"AddAssembly","d":3051873,"h":68722528609,"f":1,"a":[{"t":70909953,"c":8660844545,"a":[{"v":"Evidence.AddAssembly has been deprecated. Use AddAssemblyEvidence instead.","t":1310721}]}]},{"r":65537,"p":[{"n":"evidence","p":(T) => T.$h}],"g":["T"],"n":"AddAssemblyEvidence","d":3051873,"h":73017495905,"f":131073},{"r":65537,"p":[{"n":"id","p":131073}],"n":"AddHost","d":3051873,"h":77312463201,"f":1,"a":[{"t":70909953,"c":8660844545,"a":[{"v":"Evidence.AddHost has been deprecated. Use AddHostEvidence instead.","t":1310721}]}]},{"r":65537,"p":[{"n":"evidence","p":(T) => T.$h}],"g":["T"],"n":"AddHostEvidence","d":3051873,"h":81607430497,"f":131073},{"r":65537,"n":"Clear","d":3051873,"h":85902397793,"f":1},{"r":3051873,"n":"Clone","d":3051873,"h":90197365089,"f":1},{"r":65537,"p":[{"n":"array","p":1245185},{"n":"index","p":655361}],"n":"CopyTo","d":3051873,"h":94492332385,"f":1,"a":[{"t":70909953,"c":8660844545,"a":[{"v":"Evidence should not be treated as an ICollection. Use the GetHostEnumerator and GetAssemblyEnumerator methods rather than using CopyTo.","t":1310721}]}]},{"r":31784961,"n":"GetAssemblyEnumerator","d":3051873,"h":98787299681,"f":1},{"r":(T) => T.$h,"g":["T"],"n":"GetAssemblyEvidence","d":3051873,"h":103082266977,"f":131073},{"r":31784961,"n":"GetEnumerator","d":3051873,"h":107377234273,"f":1,"a":[{"t":70909953,"c":8660844545,"a":[{"v":"GetEnumerator is obsolete. Use GetAssemblyEnumerator and GetHostEnumerator instead.","t":1310721}]}]},{"r":31784961,"n":"GetHostEnumerator","d":3051873,"h":111672201569,"f":1},{"r":(T) => T.$h,"g":["T"],"n":"GetHostEvidence","d":3051873,"h":115967168865,"f":131073},{"r":65537,"p":[{"n":"evidence","p":3051873}],"n":"Merge","d":3051873,"h":120262136161,"f":1},{"r":65537,"p":[{"n":"t","p":142606337}],"n":"RemoveType","d":3051873,"h":124557103457,"f":1}],"c":[{"n":".ctor","o":"$ctor$1","d":3051873,"h":4298019169,"f":1},{"p":[{"n":"hostEvidence","p":0},{"n":"assemblyEvidence","p":0}],"n":".ctor","o":"$ctor$2","d":3051873,"h":8592986465,"f":1,"a":[{"t":70909953,"c":8660844545,"a":[{"v":"This constructor is obsolete. Use the constructor which accepts arrays of EvidenceBase instead.","t":1310721}]}]},{"p":[{"n":"evidence","p":3051873}],"n":".ctor","o":"$ctor$3","d":3051873,"h":12887953761,"f":1},{"p":[{"n":"hostEvidence","p":0},{"n":"assemblyEvidence","p":0}],"n":".ctor","o":"$ctor$4","d":3051873,"h":17182921057,"f":1}],"i":[31391745,31653889],"h":3051873}; }
            static get $b() { return $.$spc.System.Object; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.Collections.ICollection, $.$spc.System.Collections.IEnumerable ]; }
            static get $fullName() { return `System.Security.Policy.Evidence`; }
        });
        
        $asm.$cls("$ssa.System.Security.AccessControl.CommonSecurityDescriptor", ($self) => class CommonSecurityDescriptor extends $.$ssa.System.Security.AccessControl.GenericSecurityDescriptor
        {
            $ctor$2(/*bool*/ isContainer, /*bool*/ isDS, /*byte[]*/ binaryForm, /*int*/ offset)
            {
                super.$ctor$1();
                {
                }
                return this;
            }
            $ctor$3(/*bool*/ isContainer, /*bool*/ isDS, /*System.Security.AccessControl.ControlFlags*/ flags, /*System.Security.Principal.SecurityIdentifier?*/ owner, /*System.Security.Principal.SecurityIdentifier?*/ group, /*System.Security.AccessControl.SystemAcl?*/ systemAcl, /*System.Security.AccessControl.DiscretionaryAcl?*/ discretionaryAcl)
            {
                super.$ctor$1();
                {
                }
                return this;
            }
            $ctor$4(/*bool*/ isContainer, /*bool*/ isDS, /*System.Security.AccessControl.RawSecurityDescriptor*/ rawSecurityDescriptor)
            {
                super.$ctor$1();
                {
                }
                return this;
            }
            $ctor$5(/*bool*/ isContainer, /*bool*/ isDS, /*string*/ sddlForm)
            {
                super.$ctor$1();
                {
                }
                return this;
            }
            /*System.Security.AccessControl.ControlFlags */ get ControlFlags()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Security.AccessControl.DiscretionaryAcl? */ get DiscretionaryAcl()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Security.AccessControl.DiscretionaryAcl? */ set DiscretionaryAcl(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Security.Principal.SecurityIdentifier? */ get Group()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Security.Principal.SecurityIdentifier? */ set Group(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get IsContainer()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get IsDiscretionaryAclCanonical()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get IsDS()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get IsSystemAclCanonical()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Security.Principal.SecurityIdentifier? */ get Owner()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Security.Principal.SecurityIdentifier? */ set Owner(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Security.AccessControl.SystemAcl? */ get SystemAcl()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Security.AccessControl.SystemAcl? */ set SystemAcl(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*void */ AddDiscretionaryAcl(/*byte*/ revision, /*int*/ trusted)
            {
            }
            /*void */ AddSystemAcl(/*byte*/ revision, /*int*/ trusted)
            {
            }
            /*void */ PurgeAccessControl(/*System.Security.Principal.SecurityIdentifier*/ sid)
            {
            }
            /*void */ PurgeAudit(/*System.Security.Principal.SecurityIdentifier*/ sid)
            {
            }
            /*void */ SetDiscretionaryAclProtection(/*bool*/ isProtected, /*bool*/ preserveInheritance)
            {
            }
            /*void */ SetSystemAclProtection(/*bool*/ isProtected, /*bool*/ preserveInheritance)
            {
            }
            static $h = 1282401;
            static $f = 0b10010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":1806689,"p":[{"p":1479009,"g":{"r":0,"d":0,"h":25771086177,"f":32769},"n":"ControlFlags","d":1282401,"h":21476118881,"f":32769},{"p":1610081,"g":{"r":0,"d":0,"h":34361020769,"f":1},"s":{"r":0,"d":0,"h":38655988065,"f":1},"n":"DiscretionaryAcl","d":1282401,"h":30066053473,"f":1},{"p":446495,"g":{"r":0,"d":0,"h":47245922657,"f":32769},"s":{"r":0,"d":0,"h":51540889953,"f":32769},"n":"Group","d":1282401,"h":42950955361,"f":32769},{"p":262145,"g":{"r":0,"d":0,"h":60130824545,"f":1},"n":"IsContainer","d":1282401,"h":55835857249,"f":1},{"p":262145,"g":{"r":0,"d":0,"h":68720759137,"f":1},"n":"IsDiscretionaryAclCanonical","d":1282401,"h":64425791841,"f":1},{"p":262145,"g":{"r":0,"d":0,"h":77310693729,"f":1},"n":"IsDS","d":1282401,"h":73015726433,"f":1},{"p":262145,"g":{"r":0,"d":0,"h":85900628321,"f":1},"n":"IsSystemAclCanonical","d":1282401,"h":81605661025,"f":1},{"p":446495,"g":{"r":0,"d":0,"h":94490562913,"f":32769},"s":{"r":0,"d":0,"h":98785530209,"f":32769},"n":"Owner","d":1282401,"h":90195595617,"f":32769},{"p":2986337,"g":{"r":0,"d":0,"h":107375464801,"f":1},"s":{"r":0,"d":0,"h":111670432097,"f":1},"n":"SystemAcl","d":1282401,"h":103080497505,"f":1}],"m":[{"r":65537,"p":[{"n":"revision","p":393217},{"n":"trusted","p":655361}],"n":"AddDiscretionaryAcl","d":1282401,"h":115965399393,"f":1},{"r":65537,"p":[{"n":"revision","p":393217},{"n":"trusted","p":655361}],"n":"AddSystemAcl","d":1282401,"h":120260366689,"f":1},{"r":65537,"p":[{"n":"sid","p":446495}],"n":"PurgeAccessControl","d":1282401,"h":124555333985,"f":1},{"r":65537,"p":[{"n":"sid","p":446495}],"n":"PurgeAudit","d":1282401,"h":128850301281,"f":1},{"r":65537,"p":[{"n":"isProtected","p":262145},{"n":"preserveInheritance","p":262145}],"n":"SetDiscretionaryAclProtection","d":1282401,"h":133145268577,"f":1},{"r":65537,"p":[{"n":"isProtected","p":262145},{"n":"preserveInheritance","p":262145}],"n":"SetSystemAclProtection","d":1282401,"h":137440235873,"f":1}],"c":[{"p":[{"n":"isContainer","p":262145},{"n":"isDS","p":262145},{"n":"binaryForm","p":0},{"n":"offset","p":655361}],"n":".ctor","o":"$ctor$2","d":1282401,"h":4296249697,"f":1},{"p":[{"n":"isContainer","p":262145},{"n":"isDS","p":262145},{"n":"flags","p":1479009},{"n":"owner","p":446495},{"n":"group","p":446495},{"n":"systemAcl","p":2986337},{"n":"discretionaryAcl","p":1610081}],"n":".ctor","o":"$ctor$3","d":1282401,"h":8591216993,"f":1},{"p":[{"n":"isContainer","p":262145},{"n":"isDS","p":262145},{"n":"rawSecurityDescriptor","p":2789729}],"n":".ctor","o":"$ctor$4","d":1282401,"h":12886184289,"f":1},{"p":[{"n":"isContainer","p":262145},{"n":"isDS","p":262145},{"n":"sddlForm","p":1310721}],"n":".ctor","o":"$ctor$5","d":1282401,"h":17181151585,"f":1}],"h":1282401}; }
            static get $b() { return $.$ssa.System.Security.AccessControl.GenericSecurityDescriptor; }
            static get $fullName() { return `System.Security.AccessControl.CommonSecurityDescriptor`; }
        });
        
        $asm.$cls("$ssa.System.Security.AccessControl.CustomAce", ($self) => class CustomAce extends $.$ssa.System.Security.AccessControl.GenericAce
        {
            /*int*/ static MaxOpaqueLength = 0;
            $ctor$2(/*System.Security.AccessControl.AceType*/ type, /*System.Security.AccessControl.AceFlags*/ flags, /*byte[]?*/ opaque)
            {
                super.$ctor$1();
                {
                }
                return this;
            }
            /*int */ get BinaryLength()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ get OpaqueLength()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*void */ GetBinaryForm(/*byte[]*/ binaryForm, /*int*/ offset)
            {
            }
            /*byte[]? */ GetOpaque()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*void */ SetOpaque(/*byte[]?*/ opaque)
            {
            }
            static $h = 1544545;
            static $f = 0b10010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":1675617,"p":[{"p":655361,"g":{"r":0,"d":0,"h":17181413729,"f":32769},"n":"BinaryLength","d":1544545,"h":12886446433,"f":32769},{"p":655361,"g":{"r":0,"d":0,"h":25771348321,"f":1},"n":"OpaqueLength","d":1544545,"h":21476381025,"f":1}],"m":[{"r":65537,"p":[{"n":"binaryForm","p":0},{"n":"offset","p":655361}],"n":"GetBinaryForm","d":1544545,"h":30066315617,"f":32769},{"r":0,"n":"GetOpaque","d":1544545,"h":34361282913,"f":1},{"r":65537,"p":[{"n":"opaque","p":0}],"n":"SetOpaque","d":1544545,"h":38656250209,"f":1}],"l":[{"t":655361,"n":"MaxOpaqueLength","d":1544545,"h":4296511841,"f":33}],"c":[{"p":[{"n":"type","p":692577},{"n":"flags","p":561505},{"n":"opaque","p":0}],"n":".ctor","o":"$ctor$2","d":1544545,"h":8591479137,"f":1}],"h":1544545}; }
            static get $b() { return $.$ssa.System.Security.AccessControl.GenericAce; }
            static get $fullName() { return `System.Security.AccessControl.CustomAce`; }
        });
        
        $asm.$cls("$ssa.System.Security.AccessControl.RawSecurityDescriptor", ($self) => class RawSecurityDescriptor extends $.$ssa.System.Security.AccessControl.GenericSecurityDescriptor
        {
            $ctor$2(/*byte[]*/ binaryForm, /*int*/ offset)
            {
                super.$ctor$1();
                {
                }
                return this;
            }
            $ctor$3(/*System.Security.AccessControl.ControlFlags*/ flags, /*System.Security.Principal.SecurityIdentifier?*/ owner, /*System.Security.Principal.SecurityIdentifier?*/ group, /*System.Security.AccessControl.RawAcl?*/ systemAcl, /*System.Security.AccessControl.RawAcl?*/ discretionaryAcl)
            {
                super.$ctor$1();
                {
                }
                return this;
            }
            $ctor$4(/*string*/ sddlForm)
            {
                super.$ctor$1();
                {
                }
                return this;
            }
            /*System.Security.AccessControl.ControlFlags */ get ControlFlags()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Security.AccessControl.RawAcl? */ get DiscretionaryAcl()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Security.AccessControl.RawAcl? */ set DiscretionaryAcl(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Security.Principal.SecurityIdentifier? */ get Group()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Security.Principal.SecurityIdentifier? */ set Group(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Security.Principal.SecurityIdentifier? */ get Owner()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Security.Principal.SecurityIdentifier? */ set Owner(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*byte */ get ResourceManagerControl()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*byte */ set ResourceManagerControl(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Security.AccessControl.RawAcl? */ get SystemAcl()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Security.AccessControl.RawAcl? */ set SystemAcl(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*void */ SetFlags(/*System.Security.AccessControl.ControlFlags*/ flags)
            {
            }
            static $h = 2789729;
            static $f = 0b10010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":1806689,"p":[{"p":1479009,"g":{"r":0,"d":0,"h":21477626209,"f":32769},"n":"ControlFlags","d":2789729,"h":17182658913,"f":32769},{"p":2724193,"g":{"r":0,"d":0,"h":30067560801,"f":1},"s":{"r":0,"d":0,"h":34362528097,"f":1},"n":"DiscretionaryAcl","d":2789729,"h":25772593505,"f":1},{"p":446495,"g":{"r":0,"d":0,"h":42952462689,"f":32769},"s":{"r":0,"d":0,"h":47247429985,"f":32769},"n":"Group","d":2789729,"h":38657495393,"f":32769},{"p":446495,"g":{"r":0,"d":0,"h":55837364577,"f":32769},"s":{"r":0,"d":0,"h":60132331873,"f":32769},"n":"Owner","d":2789729,"h":51542397281,"f":32769},{"p":393217,"g":{"r":0,"d":0,"h":68722266465,"f":1},"s":{"r":0,"d":0,"h":73017233761,"f":1},"n":"ResourceManagerControl","d":2789729,"h":64427299169,"f":1},{"p":2724193,"g":{"r":0,"d":0,"h":81607168353,"f":1},"s":{"r":0,"d":0,"h":85902135649,"f":1},"n":"SystemAcl","d":2789729,"h":77312201057,"f":1}],"m":[{"r":65537,"p":[{"n":"flags","p":1479009}],"n":"SetFlags","d":2789729,"h":90197102945,"f":1}],"c":[{"p":[{"n":"binaryForm","p":0},{"n":"offset","p":655361}],"n":".ctor","o":"$ctor$2","d":2789729,"h":4297757025,"f":1},{"p":[{"n":"flags","p":1479009},{"n":"owner","p":446495},{"n":"group","p":446495},{"n":"systemAcl","p":2724193},{"n":"discretionaryAcl","p":2724193}],"n":".ctor","o":"$ctor$3","d":2789729,"h":8592724321,"f":1},{"p":[{"n":"sddlForm","p":1310721}],"n":".ctor","o":"$ctor$4","d":2789729,"h":12887691617,"f":1}],"h":2789729}; }
            static get $b() { return $.$ssa.System.Security.AccessControl.GenericSecurityDescriptor; }
            static get $fullName() { return `System.Security.AccessControl.RawSecurityDescriptor`; }
        });
        
        $asm.$cls("$ssa.System.Security.AccessControl.AuthorizationRuleCollection", ($self) => class AuthorizationRuleCollection extends $.$scn.System.Collections.ReadOnlyCollectionBase
        {
            $ctor$2()
            {
                super.$ctor$1();
                {
                }
                return this;
            }
            /*System.Security.AccessControl.AuthorizationRule?*/ get_Item(/*int*/ index)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*void */ AddRule(/*System.Security.AccessControl.AuthorizationRule?*/ rule)
            {
            }
            /*void */ CopyTo(/*System.Security.AccessControl.AuthorizationRule[]*/ rules, /*int*/ index)
            {
            }
            static $h = 1020257;
            static $f = 0b10010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":589859,"p":[{"p":954721,"i":[{"n":"index","p":655361}],"g":{"r":0,"d":0,"h":12885922145,"f":1},"n":"Item","o":"@$2","d":1020257,"h":8590954849,"f":1}],"m":[{"r":65537,"p":[{"n":"rule","p":954721}],"n":"AddRule","d":1020257,"h":17180889441,"f":1},{"r":65537,"p":[{"n":"rules","p":0},{"n":"index","p":655361}],"n":"CopyTo","d":1020257,"h":21475856737,"f":1}],"c":[{"n":".ctor","o":"$ctor$2","d":1020257,"h":4295987553,"f":1}],"i":[31391745,31653889],"h":1020257}; }
            static get $b() { return $.$scn.System.Collections.ReadOnlyCollectionBase; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.Collections.ICollection, $.$spc.System.Collections.IEnumerable ]; }
            static get $fullName() { return `System.Security.AccessControl.AuthorizationRuleCollection`; }
        });
        
        $asm.$cls("$ssa.System.Security.AccessControl.RawAcl", ($self) => class RawAcl extends $.$ssa.System.Security.AccessControl.GenericAcl
        {
            $ctor$2(/*byte*/ revision, /*int*/ capacity)
            {
                super.$ctor$1();
                {
                }
                return this;
            }
            $ctor$3(/*byte[]*/ binaryForm, /*int*/ offset)
            {
                super.$ctor$1();
                {
                }
                return this;
            }
            /*int */ get BinaryLength()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ get Count()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Security.AccessControl.GenericAce*/ get_Item(/*int*/ index)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*void*/ set_Item(/*int*/ index, /*System.Security.AccessControl.GenericAce*/ value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*byte */ get Revision()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*void */ GetBinaryForm(/*byte[]*/ binaryForm, /*int*/ offset)
            {
            }
            /*void */ InsertAce(/*int*/ index, /*System.Security.AccessControl.GenericAce*/ ace)
            {
            }
            /*void */ RemoveAce(/*int*/ index)
            {
            }
            static $h = 2724193;
            static $f = 0b10010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":1741153,"p":[{"p":655361,"g":{"r":0,"d":0,"h":17182593377,"f":32769},"n":"BinaryLength","d":2724193,"h":12887626081,"f":32769},{"p":655361,"g":{"r":0,"d":0,"h":25772527969,"f":32769},"n":"Count","d":2724193,"h":21477560673,"f":32769},{"p":1675617,"i":[{"n":"index","p":655361}],"g":{"r":0,"d":0,"h":34362462561,"f":32769},"s":{"r":0,"d":0,"h":38657429857,"f":32769},"n":"Item","o":"@$2","d":2724193,"h":30067495265,"f":32769},{"p":393217,"g":{"r":0,"d":0,"h":47247364449,"f":32769},"n":"Revision","d":2724193,"h":42952397153,"f":32769}],"m":[{"r":65537,"p":[{"n":"binaryForm","p":0},{"n":"offset","p":655361}],"n":"GetBinaryForm","d":2724193,"h":51542331745,"f":32769},{"r":65537,"p":[{"n":"index","p":655361},{"n":"ace","p":1675617}],"n":"InsertAce","d":2724193,"h":55837299041,"f":1},{"r":65537,"p":[{"n":"index","p":655361}],"n":"RemoveAce","d":2724193,"h":60132266337,"f":1}],"c":[{"p":[{"n":"revision","p":393217},{"n":"capacity","p":655361}],"n":".ctor","o":"$ctor$2","d":2724193,"h":4297691489,"f":1},{"p":[{"n":"binaryForm","p":0},{"n":"offset","p":655361}],"n":".ctor","o":"$ctor$3","d":2724193,"h":8592658785,"f":1}],"i":[31391745,31653889],"h":2724193}; }
            static get $b() { return $.$ssa.System.Security.AccessControl.GenericAcl; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.Collections.ICollection, $.$spc.System.Collections.IEnumerable ]; }
            static get $fullName() { return `System.Security.AccessControl.RawAcl`; }
        });
        
        $asm.$cls("$ssa.System.Security.AccessControl.AccessRule<>", (T) => $asm.$gt("$ssa.System.Security.AccessControl.AccessRule<>", [T], ($self) => class AccessRule$$ extends $.$ssa.System.Security.AccessControl.AccessRule
        {
            $ctor$3(/*System.Security.Principal.IdentityReference*/ identity, /*T*/ rights, /*System.Security.AccessControl.AccessControlType*/ type)
            {
                super.$ctor$2(null, 0, false, 0, 0, 0);
                {
                }
                return this;
            }
            $ctor$4(/*System.Security.Principal.IdentityReference*/ identity, /*T*/ rights, /*System.Security.AccessControl.InheritanceFlags*/ inheritanceFlags, /*System.Security.AccessControl.PropagationFlags*/ propagationFlags, /*System.Security.AccessControl.AccessControlType*/ type)
            {
                super.$ctor$2(null, 0, false, 0, 0, 0);
                {
                }
                return this;
            }
            $ctor$5(/*string*/ identity, /*T*/ rights, /*System.Security.AccessControl.AccessControlType*/ type)
            {
                super.$ctor$2(null, 0, false, 0, 0, 0);
                {
                }
                return this;
            }
            $ctor$6(/*string*/ identity, /*T*/ rights, /*System.Security.AccessControl.InheritanceFlags*/ inheritanceFlags, /*System.Security.AccessControl.PropagationFlags*/ propagationFlags, /*System.Security.AccessControl.AccessControlType*/ type)
            {
                super.$ctor$2(null, 0, false, 0, 0, 0);
                {
                }
                return this;
            }
            /*T */ get Rights()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static $h = 430433;
            static $g = 1;
            static $f = 0b1010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":364897,"p":[{"p":T?.$h??1507328,"g":{"r":0,"d":0,"h":Number(BigInt(this.$h)|0x600000000n),"f":1},"n":"Rights","d":this.$h,"h":Number(BigInt(this.$h)|0x500000000n),"f":1}],"c":[{"p":[{"n":"identity","p":249887},{"n":"rights","p":T?.$h??1507328},{"n":"type","p":299361}],"n":".ctor","o":"$ctor$3","d":this.$h,"h":Number(BigInt(this.$h)|0x100000000n),"f":1},{"p":[{"n":"identity","p":249887},{"n":"rights","p":T?.$h??1507328},{"n":"inheritanceFlags","p":1872225},{"n":"propagationFlags","p":2593121},{"n":"type","p":299361}],"n":".ctor","o":"$ctor$4","d":this.$h,"h":Number(BigInt(this.$h)|0x200000000n),"f":1},{"p":[{"n":"identity","p":1310721},{"n":"rights","p":T?.$h??1507328},{"n":"type","p":299361}],"n":".ctor","o":"$ctor$5","d":this.$h,"h":Number(BigInt(this.$h)|0x300000000n),"f":1},{"p":[{"n":"identity","p":1310721},{"n":"rights","p":T?.$h??1507328},{"n":"inheritanceFlags","p":1872225},{"n":"propagationFlags","p":2593121},{"n":"type","p":299361}],"n":".ctor","o":"$ctor$6","d":this.$h,"h":Number(BigInt(this.$h)|0x400000000n),"f":1}],"g":[T?.$h??1507328],"s":[{"n":"T","f":2}],"r":1,"h":this.$h}; }
            static get $b() { return $.$ssa.System.Security.AccessControl.AccessRule; }
            static get $fullName() { return `System.Security.AccessControl.AccessRule<${T?.$fullName}>`; }
        }));
        
        $asm.$cls("$ssa.System.Security.AccessControl.AuditRule<>", (T) => $asm.$gt("$ssa.System.Security.AccessControl.AuditRule<>", [T], ($self) => class AuditRule$$ extends $.$ssa.System.Security.AccessControl.AuditRule
        {
            $ctor$3(/*System.Security.Principal.IdentityReference*/ identity, /*T*/ rights, /*System.Security.AccessControl.AuditFlags*/ flags)
            {
                super.$ctor$2(null, 0, false, 0, 0, 0);
                {
                }
                return this;
            }
            $ctor$4(/*System.Security.Principal.IdentityReference*/ identity, /*T*/ rights, /*System.Security.AccessControl.InheritanceFlags*/ inheritanceFlags, /*System.Security.AccessControl.PropagationFlags*/ propagationFlags, /*System.Security.AccessControl.AuditFlags*/ flags)
            {
                super.$ctor$2(null, 0, false, 0, 0, 0);
                {
                }
                return this;
            }
            $ctor$5(/*string*/ identity, /*T*/ rights, /*System.Security.AccessControl.AuditFlags*/ flags)
            {
                super.$ctor$2(null, 0, false, 0, 0, 0);
                {
                }
                return this;
            }
            $ctor$6(/*string*/ identity, /*T*/ rights, /*System.Security.AccessControl.InheritanceFlags*/ inheritanceFlags, /*System.Security.AccessControl.PropagationFlags*/ propagationFlags, /*System.Security.AccessControl.AuditFlags*/ flags)
            {
                super.$ctor$2(null, 0, false, 0, 0, 0);
                {
                }
                return this;
            }
            /*T */ get Rights()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static $h = 889185;
            static $g = 1;
            static $f = 0b1010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":823649,"p":[{"p":T?.$h??1507328,"g":{"r":0,"d":0,"h":Number(BigInt(this.$h)|0x600000000n),"f":1},"n":"Rights","d":this.$h,"h":Number(BigInt(this.$h)|0x500000000n),"f":1}],"c":[{"p":[{"n":"identity","p":249887},{"n":"rights","p":T?.$h??1507328},{"n":"flags","p":758113}],"n":".ctor","o":"$ctor$3","d":this.$h,"h":Number(BigInt(this.$h)|0x100000000n),"f":1},{"p":[{"n":"identity","p":249887},{"n":"rights","p":T?.$h??1507328},{"n":"inheritanceFlags","p":1872225},{"n":"propagationFlags","p":2593121},{"n":"flags","p":758113}],"n":".ctor","o":"$ctor$4","d":this.$h,"h":Number(BigInt(this.$h)|0x200000000n),"f":1},{"p":[{"n":"identity","p":1310721},{"n":"rights","p":T?.$h??1507328},{"n":"flags","p":758113}],"n":".ctor","o":"$ctor$5","d":this.$h,"h":Number(BigInt(this.$h)|0x300000000n),"f":1},{"p":[{"n":"identity","p":1310721},{"n":"rights","p":T?.$h??1507328},{"n":"inheritanceFlags","p":1872225},{"n":"propagationFlags","p":2593121},{"n":"flags","p":758113}],"n":".ctor","o":"$ctor$6","d":this.$h,"h":Number(BigInt(this.$h)|0x400000000n),"f":1}],"g":[T?.$h??1507328],"s":[{"n":"T","f":2}],"r":1,"h":this.$h}; }
            static get $b() { return $.$ssa.System.Security.AccessControl.AuditRule; }
            static get $fullName() { return `System.Security.AccessControl.AuditRule<${T?.$fullName}>`; }
        }));
        
        $asm.$cls("$ssa.System.Security.AccessControl.CompoundAce", ($self) => class CompoundAce extends $.$ssa.System.Security.AccessControl.KnownAce
        {
            $ctor$3(/*System.Security.AccessControl.AceFlags*/ flags, /*int*/ accessMask, /*System.Security.AccessControl.CompoundAceType*/ compoundAceType, /*System.Security.Principal.SecurityIdentifier*/ sid)
            {
                super.$ctor$2();
                {
                }
                return this;
            }
            /*int */ get BinaryLength()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Security.AccessControl.CompoundAceType */ get CompoundAceType()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Security.AccessControl.CompoundAceType */ set CompoundAceType(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*void */ GetBinaryForm(/*byte[]*/ binaryForm, /*int*/ offset)
            {
            }
            static $h = 1347937;
            static $f = 0b10010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":1937761,"p":[{"p":655361,"g":{"r":0,"d":0,"h":12886249825,"f":32769},"n":"BinaryLength","d":1347937,"h":8591282529,"f":32769},{"p":1413473,"g":{"r":0,"d":0,"h":21476184417,"f":1},"s":{"r":0,"d":0,"h":25771151713,"f":1},"n":"CompoundAceType","d":1347937,"h":17181217121,"f":1}],"m":[{"r":65537,"p":[{"n":"binaryForm","p":0},{"n":"offset","p":655361}],"n":"GetBinaryForm","d":1347937,"h":30066119009,"f":32769}],"c":[{"p":[{"n":"flags","p":561505},{"n":"accessMask","p":655361},{"n":"compoundAceType","p":1413473},{"n":"sid","p":446495}],"n":".ctor","o":"$ctor$3","d":1347937,"h":4296315233,"f":1}],"h":1347937}; }
            static get $b() { return $.$ssa.System.Security.AccessControl.KnownAce; }
            static get $fullName() { return `System.Security.AccessControl.CompoundAce`; }
        });
        
        $asm.$cls("$ssa.System.Security.AccessControl.DiscretionaryAcl", ($self) => class DiscretionaryAcl extends $.$ssa.System.Security.AccessControl.CommonAcl
        {
            $ctor$3(/*bool*/ isContainer, /*bool*/ isDS, /*byte*/ revision, /*int*/ capacity)
            {
                super.$ctor$2();
                {
                }
                return this;
            }
            $ctor$4(/*bool*/ isContainer, /*bool*/ isDS, /*int*/ capacity)
            {
                super.$ctor$2();
                {
                }
                return this;
            }
            $ctor$5(/*bool*/ isContainer, /*bool*/ isDS, /*System.Security.AccessControl.RawAcl?*/ rawAcl)
            {
                super.$ctor$2();
                {
                }
                return this;
            }
            /*void */ AddAccess(/*System.Security.AccessControl.AccessControlType*/ accessType, /*System.Security.Principal.SecurityIdentifier*/ sid, /*int*/ accessMask, /*System.Security.AccessControl.InheritanceFlags*/ inheritanceFlags, /*System.Security.AccessControl.PropagationFlags*/ propagationFlags)
            {
            }
            /*void */ AddAccess$1(/*System.Security.AccessControl.AccessControlType*/ accessType, /*System.Security.Principal.SecurityIdentifier*/ sid, /*int*/ accessMask, /*System.Security.AccessControl.InheritanceFlags*/ inheritanceFlags, /*System.Security.AccessControl.PropagationFlags*/ propagationFlags, /*System.Security.AccessControl.ObjectAceFlags*/ objectFlags, /*System.Guid*/ objectType, /*System.Guid*/ inheritedObjectType)
            {
            }
            /*void */ AddAccess$2(/*System.Security.AccessControl.AccessControlType*/ accessType, /*System.Security.Principal.SecurityIdentifier*/ sid, /*System.Security.AccessControl.ObjectAccessRule*/ rule)
            {
            }
            /*bool */ RemoveAccess(/*System.Security.AccessControl.AccessControlType*/ accessType, /*System.Security.Principal.SecurityIdentifier*/ sid, /*int*/ accessMask, /*System.Security.AccessControl.InheritanceFlags*/ inheritanceFlags, /*System.Security.AccessControl.PropagationFlags*/ propagationFlags)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ RemoveAccess$1(/*System.Security.AccessControl.AccessControlType*/ accessType, /*System.Security.Principal.SecurityIdentifier*/ sid, /*int*/ accessMask, /*System.Security.AccessControl.InheritanceFlags*/ inheritanceFlags, /*System.Security.AccessControl.PropagationFlags*/ propagationFlags, /*System.Security.AccessControl.ObjectAceFlags*/ objectFlags, /*System.Guid*/ objectType, /*System.Guid*/ inheritedObjectType)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ RemoveAccess$2(/*System.Security.AccessControl.AccessControlType*/ accessType, /*System.Security.Principal.SecurityIdentifier*/ sid, /*System.Security.AccessControl.ObjectAccessRule*/ rule)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*void */ RemoveAccessSpecific(/*System.Security.AccessControl.AccessControlType*/ accessType, /*System.Security.Principal.SecurityIdentifier*/ sid, /*int*/ accessMask, /*System.Security.AccessControl.InheritanceFlags*/ inheritanceFlags, /*System.Security.AccessControl.PropagationFlags*/ propagationFlags)
            {
            }
            /*void */ RemoveAccessSpecific$1(/*System.Security.AccessControl.AccessControlType*/ accessType, /*System.Security.Principal.SecurityIdentifier*/ sid, /*int*/ accessMask, /*System.Security.AccessControl.InheritanceFlags*/ inheritanceFlags, /*System.Security.AccessControl.PropagationFlags*/ propagationFlags, /*System.Security.AccessControl.ObjectAceFlags*/ objectFlags, /*System.Guid*/ objectType, /*System.Guid*/ inheritedObjectType)
            {
            }
            /*void */ RemoveAccessSpecific$2(/*System.Security.AccessControl.AccessControlType*/ accessType, /*System.Security.Principal.SecurityIdentifier*/ sid, /*System.Security.AccessControl.ObjectAccessRule*/ rule)
            {
            }
            /*void */ SetAccess(/*System.Security.AccessControl.AccessControlType*/ accessType, /*System.Security.Principal.SecurityIdentifier*/ sid, /*int*/ accessMask, /*System.Security.AccessControl.InheritanceFlags*/ inheritanceFlags, /*System.Security.AccessControl.PropagationFlags*/ propagationFlags)
            {
            }
            /*void */ SetAccess$1(/*System.Security.AccessControl.AccessControlType*/ accessType, /*System.Security.Principal.SecurityIdentifier*/ sid, /*int*/ accessMask, /*System.Security.AccessControl.InheritanceFlags*/ inheritanceFlags, /*System.Security.AccessControl.PropagationFlags*/ propagationFlags, /*System.Security.AccessControl.ObjectAceFlags*/ objectFlags, /*System.Guid*/ objectType, /*System.Guid*/ inheritedObjectType)
            {
            }
            /*void */ SetAccess$2(/*System.Security.AccessControl.AccessControlType*/ accessType, /*System.Security.Principal.SecurityIdentifier*/ sid, /*System.Security.AccessControl.ObjectAccessRule*/ rule)
            {
            }
            static $h = 1610081;
            static $f = 0b10010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":1151329,"m":[{"r":65537,"p":[{"n":"accessType","p":299361},{"n":"sid","p":446495},{"n":"accessMask","p":655361},{"n":"inheritanceFlags","p":1872225},{"n":"propagationFlags","p":2593121}],"n":"AddAccess","d":1610081,"h":17181479265,"f":1},{"r":65537,"p":[{"n":"accessType","p":299361},{"n":"sid","p":446495},{"n":"accessMask","p":655361},{"n":"inheritanceFlags","p":1872225},{"n":"propagationFlags","p":2593121},{"n":"objectFlags","p":2265441},{"n":"objectType","p":56229889},{"n":"inheritedObjectType","p":56229889}],"n":"AddAccess","o":"@$1","d":1610081,"h":21476446561,"f":1},{"r":65537,"p":[{"n":"accessType","p":299361},{"n":"sid","p":446495},{"n":"rule","p":2134369}],"n":"AddAccess","o":"@$2","d":1610081,"h":25771413857,"f":1},{"r":262145,"p":[{"n":"accessType","p":299361},{"n":"sid","p":446495},{"n":"accessMask","p":655361},{"n":"inheritanceFlags","p":1872225},{"n":"propagationFlags","p":2593121}],"n":"RemoveAccess","d":1610081,"h":30066381153,"f":1},{"r":262145,"p":[{"n":"accessType","p":299361},{"n":"sid","p":446495},{"n":"accessMask","p":655361},{"n":"inheritanceFlags","p":1872225},{"n":"propagationFlags","p":2593121},{"n":"objectFlags","p":2265441},{"n":"objectType","p":56229889},{"n":"inheritedObjectType","p":56229889}],"n":"RemoveAccess","o":"@$1","d":1610081,"h":34361348449,"f":1},{"r":262145,"p":[{"n":"accessType","p":299361},{"n":"sid","p":446495},{"n":"rule","p":2134369}],"n":"RemoveAccess","o":"@$2","d":1610081,"h":38656315745,"f":1},{"r":65537,"p":[{"n":"accessType","p":299361},{"n":"sid","p":446495},{"n":"accessMask","p":655361},{"n":"inheritanceFlags","p":1872225},{"n":"propagationFlags","p":2593121}],"n":"RemoveAccessSpecific","d":1610081,"h":42951283041,"f":1},{"r":65537,"p":[{"n":"accessType","p":299361},{"n":"sid","p":446495},{"n":"accessMask","p":655361},{"n":"inheritanceFlags","p":1872225},{"n":"propagationFlags","p":2593121},{"n":"objectFlags","p":2265441},{"n":"objectType","p":56229889},{"n":"inheritedObjectType","p":56229889}],"n":"RemoveAccessSpecific","o":"@$1","d":1610081,"h":47246250337,"f":1},{"r":65537,"p":[{"n":"accessType","p":299361},{"n":"sid","p":446495},{"n":"rule","p":2134369}],"n":"RemoveAccessSpecific","o":"@$2","d":1610081,"h":51541217633,"f":1},{"r":65537,"p":[{"n":"accessType","p":299361},{"n":"sid","p":446495},{"n":"accessMask","p":655361},{"n":"inheritanceFlags","p":1872225},{"n":"propagationFlags","p":2593121}],"n":"SetAccess","d":1610081,"h":55836184929,"f":1},{"r":65537,"p":[{"n":"accessType","p":299361},{"n":"sid","p":446495},{"n":"accessMask","p":655361},{"n":"inheritanceFlags","p":1872225},{"n":"propagationFlags","p":2593121},{"n":"objectFlags","p":2265441},{"n":"objectType","p":56229889},{"n":"inheritedObjectType","p":56229889}],"n":"SetAccess","o":"@$1","d":1610081,"h":60131152225,"f":1},{"r":65537,"p":[{"n":"accessType","p":299361},{"n":"sid","p":446495},{"n":"rule","p":2134369}],"n":"SetAccess","o":"@$2","d":1610081,"h":64426119521,"f":1}],"c":[{"p":[{"n":"isContainer","p":262145},{"n":"isDS","p":262145},{"n":"revision","p":393217},{"n":"capacity","p":655361}],"n":".ctor","o":"$ctor$3","d":1610081,"h":4296577377,"f":1},{"p":[{"n":"isContainer","p":262145},{"n":"isDS","p":262145},{"n":"capacity","p":655361}],"n":".ctor","o":"$ctor$4","d":1610081,"h":8591544673,"f":1},{"p":[{"n":"isContainer","p":262145},{"n":"isDS","p":262145},{"n":"rawAcl","p":2724193}],"n":".ctor","o":"$ctor$5","d":1610081,"h":12886511969,"f":1}],"i":[31391745,31653889],"h":1610081}; }
            static get $b() { return $.$ssa.System.Security.AccessControl.CommonAcl; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.Collections.ICollection, $.$spc.System.Collections.IEnumerable ]; }
            static get $fullName() { return `System.Security.AccessControl.DiscretionaryAcl`; }
        });
        
        $asm.$cls("$ssa.System.Security.AccessControl.SystemAcl", ($self) => class SystemAcl extends $.$ssa.System.Security.AccessControl.CommonAcl
        {
            $ctor$3(/*bool*/ isContainer, /*bool*/ isDS, /*byte*/ revision, /*int*/ capacity)
            {
                super.$ctor$2();
                {
                }
                return this;
            }
            $ctor$4(/*bool*/ isContainer, /*bool*/ isDS, /*int*/ capacity)
            {
                super.$ctor$2();
                {
                }
                return this;
            }
            $ctor$5(/*bool*/ isContainer, /*bool*/ isDS, /*System.Security.AccessControl.RawAcl*/ rawAcl)
            {
                super.$ctor$2();
                {
                }
                return this;
            }
            /*void */ AddAudit(/*System.Security.AccessControl.AuditFlags*/ auditFlags, /*System.Security.Principal.SecurityIdentifier*/ sid, /*int*/ accessMask, /*System.Security.AccessControl.InheritanceFlags*/ inheritanceFlags, /*System.Security.AccessControl.PropagationFlags*/ propagationFlags)
            {
            }
            /*void */ AddAudit$1(/*System.Security.AccessControl.AuditFlags*/ auditFlags, /*System.Security.Principal.SecurityIdentifier*/ sid, /*int*/ accessMask, /*System.Security.AccessControl.InheritanceFlags*/ inheritanceFlags, /*System.Security.AccessControl.PropagationFlags*/ propagationFlags, /*System.Security.AccessControl.ObjectAceFlags*/ objectFlags, /*System.Guid*/ objectType, /*System.Guid*/ inheritedObjectType)
            {
            }
            /*void */ AddAudit$2(/*System.Security.Principal.SecurityIdentifier*/ sid, /*System.Security.AccessControl.ObjectAuditRule*/ rule)
            {
            }
            /*bool */ RemoveAudit(/*System.Security.AccessControl.AuditFlags*/ auditFlags, /*System.Security.Principal.SecurityIdentifier*/ sid, /*int*/ accessMask, /*System.Security.AccessControl.InheritanceFlags*/ inheritanceFlags, /*System.Security.AccessControl.PropagationFlags*/ propagationFlags)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ RemoveAudit$1(/*System.Security.AccessControl.AuditFlags*/ auditFlags, /*System.Security.Principal.SecurityIdentifier*/ sid, /*int*/ accessMask, /*System.Security.AccessControl.InheritanceFlags*/ inheritanceFlags, /*System.Security.AccessControl.PropagationFlags*/ propagationFlags, /*System.Security.AccessControl.ObjectAceFlags*/ objectFlags, /*System.Guid*/ objectType, /*System.Guid*/ inheritedObjectType)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ RemoveAudit$2(/*System.Security.Principal.SecurityIdentifier*/ sid, /*System.Security.AccessControl.ObjectAuditRule*/ rule)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*void */ RemoveAuditSpecific(/*System.Security.AccessControl.AuditFlags*/ auditFlags, /*System.Security.Principal.SecurityIdentifier*/ sid, /*int*/ accessMask, /*System.Security.AccessControl.InheritanceFlags*/ inheritanceFlags, /*System.Security.AccessControl.PropagationFlags*/ propagationFlags)
            {
            }
            /*void */ RemoveAuditSpecific$1(/*System.Security.AccessControl.AuditFlags*/ auditFlags, /*System.Security.Principal.SecurityIdentifier*/ sid, /*int*/ accessMask, /*System.Security.AccessControl.InheritanceFlags*/ inheritanceFlags, /*System.Security.AccessControl.PropagationFlags*/ propagationFlags, /*System.Security.AccessControl.ObjectAceFlags*/ objectFlags, /*System.Guid*/ objectType, /*System.Guid*/ inheritedObjectType)
            {
            }
            /*void */ RemoveAuditSpecific$2(/*System.Security.Principal.SecurityIdentifier*/ sid, /*System.Security.AccessControl.ObjectAuditRule*/ rule)
            {
            }
            /*void */ SetAudit(/*System.Security.AccessControl.AuditFlags*/ auditFlags, /*System.Security.Principal.SecurityIdentifier*/ sid, /*int*/ accessMask, /*System.Security.AccessControl.InheritanceFlags*/ inheritanceFlags, /*System.Security.AccessControl.PropagationFlags*/ propagationFlags)
            {
            }
            /*void */ SetAudit$1(/*System.Security.AccessControl.AuditFlags*/ auditFlags, /*System.Security.Principal.SecurityIdentifier*/ sid, /*int*/ accessMask, /*System.Security.AccessControl.InheritanceFlags*/ inheritanceFlags, /*System.Security.AccessControl.PropagationFlags*/ propagationFlags, /*System.Security.AccessControl.ObjectAceFlags*/ objectFlags, /*System.Guid*/ objectType, /*System.Guid*/ inheritedObjectType)
            {
            }
            /*void */ SetAudit$2(/*System.Security.Principal.SecurityIdentifier*/ sid, /*System.Security.AccessControl.ObjectAuditRule*/ rule)
            {
            }
            static $h = 2986337;
            static $f = 0b10010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":1151329,"m":[{"r":65537,"p":[{"n":"auditFlags","p":758113},{"n":"sid","p":446495},{"n":"accessMask","p":655361},{"n":"inheritanceFlags","p":1872225},{"n":"propagationFlags","p":2593121}],"n":"AddAudit","d":2986337,"h":17182855521,"f":1},{"r":65537,"p":[{"n":"auditFlags","p":758113},{"n":"sid","p":446495},{"n":"accessMask","p":655361},{"n":"inheritanceFlags","p":1872225},{"n":"propagationFlags","p":2593121},{"n":"objectFlags","p":2265441},{"n":"objectType","p":56229889},{"n":"inheritedObjectType","p":56229889}],"n":"AddAudit","o":"@$1","d":2986337,"h":21477822817,"f":1},{"r":65537,"p":[{"n":"sid","p":446495},{"n":"rule","p":2330977}],"n":"AddAudit","o":"@$2","d":2986337,"h":25772790113,"f":1},{"r":262145,"p":[{"n":"auditFlags","p":758113},{"n":"sid","p":446495},{"n":"accessMask","p":655361},{"n":"inheritanceFlags","p":1872225},{"n":"propagationFlags","p":2593121}],"n":"RemoveAudit","d":2986337,"h":30067757409,"f":1},{"r":262145,"p":[{"n":"auditFlags","p":758113},{"n":"sid","p":446495},{"n":"accessMask","p":655361},{"n":"inheritanceFlags","p":1872225},{"n":"propagationFlags","p":2593121},{"n":"objectFlags","p":2265441},{"n":"objectType","p":56229889},{"n":"inheritedObjectType","p":56229889}],"n":"RemoveAudit","o":"@$1","d":2986337,"h":34362724705,"f":1},{"r":262145,"p":[{"n":"sid","p":446495},{"n":"rule","p":2330977}],"n":"RemoveAudit","o":"@$2","d":2986337,"h":38657692001,"f":1},{"r":65537,"p":[{"n":"auditFlags","p":758113},{"n":"sid","p":446495},{"n":"accessMask","p":655361},{"n":"inheritanceFlags","p":1872225},{"n":"propagationFlags","p":2593121}],"n":"RemoveAuditSpecific","d":2986337,"h":42952659297,"f":1},{"r":65537,"p":[{"n":"auditFlags","p":758113},{"n":"sid","p":446495},{"n":"accessMask","p":655361},{"n":"inheritanceFlags","p":1872225},{"n":"propagationFlags","p":2593121},{"n":"objectFlags","p":2265441},{"n":"objectType","p":56229889},{"n":"inheritedObjectType","p":56229889}],"n":"RemoveAuditSpecific","o":"@$1","d":2986337,"h":47247626593,"f":1},{"r":65537,"p":[{"n":"sid","p":446495},{"n":"rule","p":2330977}],"n":"RemoveAuditSpecific","o":"@$2","d":2986337,"h":51542593889,"f":1},{"r":65537,"p":[{"n":"auditFlags","p":758113},{"n":"sid","p":446495},{"n":"accessMask","p":655361},{"n":"inheritanceFlags","p":1872225},{"n":"propagationFlags","p":2593121}],"n":"SetAudit","d":2986337,"h":55837561185,"f":1},{"r":65537,"p":[{"n":"auditFlags","p":758113},{"n":"sid","p":446495},{"n":"accessMask","p":655361},{"n":"inheritanceFlags","p":1872225},{"n":"propagationFlags","p":2593121},{"n":"objectFlags","p":2265441},{"n":"objectType","p":56229889},{"n":"inheritedObjectType","p":56229889}],"n":"SetAudit","o":"@$1","d":2986337,"h":60132528481,"f":1},{"r":65537,"p":[{"n":"sid","p":446495},{"n":"rule","p":2330977}],"n":"SetAudit","o":"@$2","d":2986337,"h":64427495777,"f":1}],"c":[{"p":[{"n":"isContainer","p":262145},{"n":"isDS","p":262145},{"n":"revision","p":393217},{"n":"capacity","p":655361}],"n":".ctor","o":"$ctor$3","d":2986337,"h":4297953633,"f":1},{"p":[{"n":"isContainer","p":262145},{"n":"isDS","p":262145},{"n":"capacity","p":655361}],"n":".ctor","o":"$ctor$4","d":2986337,"h":8592920929,"f":1},{"p":[{"n":"isContainer","p":262145},{"n":"isDS","p":262145},{"n":"rawAcl","p":2724193}],"n":".ctor","o":"$ctor$5","d":2986337,"h":12887888225,"f":1}],"i":[31391745,31653889],"h":2986337}; }
            static get $b() { return $.$ssa.System.Security.AccessControl.CommonAcl; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.Collections.ICollection, $.$spc.System.Collections.IEnumerable ]; }
            static get $fullName() { return `System.Security.AccessControl.SystemAcl`; }
        });
        
        $asm.$str("$ssa.System.Security.AccessControl.AccessControlActions", ($self) => class AccessControlActions extends $.$spc.System.Enum
        {
            static None = 0;
            static View = 1;
            static Change = 2;
            static $map;
            static get Map()
            {
                return this.$map ??= 
                {
                    "None": 0n,
                    "View": 1n,
                    "Change": 2n
                };
            }
            static $h = 102753;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static get $eut() { return $.$spc.System.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {"b":1048577,"u":655361,"l":[{"t":102753,"n":"None","d":102753,"h":4295070049,"f":33},{"t":102753,"n":"View","d":102753,"h":8590037345,"f":33},{"t":102753,"n":"Change","d":102753,"h":12885004641,"f":33}],"c":[{"n":".ctor","o":"$ctor$3","d":102753,"h":17179971937,"f":1}],"i":[57278465,63832065,57737217,57409537],"h":102753,"a":[{"t":47710209,"c":4342677505}]}; }
            static get $b() { return $.$spc.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IComparable, $.$spc.System.ISpanFormattable, $.$spc.System.IFormattable, $.$spc.System.IConvertible ]; }
            static get $fullName() { return `System.Security.AccessControl.AccessControlActions`; }
        });
        
        $asm.$str("$ssa.System.Security.AccessControl.AccessControlModification", ($self) => class AccessControlModification extends $.$spc.System.Enum
        {
            static Add = 0;
            static Set = 1;
            static Reset = 2;
            static Remove = 3;
            static RemoveAll = 4;
            static RemoveSpecific = 5;
            static $map;
            static get Map()
            {
                return this.$map ??= 
                {
                    "Add": 0n,
                    "Set": 1n,
                    "Reset": 2n,
                    "Remove": 3n,
                    "RemoveAll": 4n,
                    "RemoveSpecific": 5n
                };
            }
            static $h = 168289;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static get $eut() { return $.$spc.System.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {"b":1048577,"u":655361,"l":[{"t":168289,"n":"Add","d":168289,"h":4295135585,"f":33},{"t":168289,"n":"Set","d":168289,"h":8590102881,"f":33},{"t":168289,"n":"Reset","d":168289,"h":12885070177,"f":33},{"t":168289,"n":"Remove","d":168289,"h":17180037473,"f":33},{"t":168289,"n":"RemoveAll","d":168289,"h":21475004769,"f":33},{"t":168289,"n":"RemoveSpecific","d":168289,"h":25769972065,"f":33}],"c":[{"n":".ctor","o":"$ctor$3","d":168289,"h":30064939361,"f":1}],"i":[57278465,63832065,57737217,57409537],"h":168289}; }
            static get $b() { return $.$spc.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IComparable, $.$spc.System.ISpanFormattable, $.$spc.System.IFormattable, $.$spc.System.IConvertible ]; }
            static get $fullName() { return `System.Security.AccessControl.AccessControlModification`; }
        });
        
        $asm.$str("$ssa.System.Security.AccessControl.AccessControlSections", ($self) => class AccessControlSections extends $.$spc.System.Enum
        {
            static None = 0;
            static Audit = 1;
            static Access = 2;
            static Owner = 4;
            static Group = 8;
            static All = 15;
            static $map;
            static get Map()
            {
                return this.$map ??= 
                {
                    "None": 0n,
                    "Audit": 1n,
                    "Access": 2n,
                    "Owner": 4n,
                    "Group": 8n,
                    "All": 15n
                };
            }
            static $h = 233825;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static get $eut() { return $.$spc.System.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {"b":1048577,"u":655361,"l":[{"t":233825,"n":"None","d":233825,"h":4295201121,"f":33},{"t":233825,"n":"Audit","d":233825,"h":8590168417,"f":33},{"t":233825,"n":"Access","d":233825,"h":12885135713,"f":33},{"t":233825,"n":"Owner","d":233825,"h":17180103009,"f":33},{"t":233825,"n":"Group","d":233825,"h":21475070305,"f":33},{"t":233825,"n":"All","d":233825,"h":25770037601,"f":33}],"c":[{"n":".ctor","o":"$ctor$3","d":233825,"h":30065004897,"f":1}],"i":[57278465,63832065,57737217,57409537],"h":233825,"a":[{"t":47710209,"c":4342677505}]}; }
            static get $b() { return $.$spc.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IComparable, $.$spc.System.ISpanFormattable, $.$spc.System.IFormattable, $.$spc.System.IConvertible ]; }
            static get $fullName() { return `System.Security.AccessControl.AccessControlSections`; }
        });
        
        $asm.$str("$ssa.System.Security.AccessControl.AccessControlType", ($self) => class AccessControlType extends $.$spc.System.Enum
        {
            static Allow = 0;
            static Deny = 1;
            static $map;
            static get Map()
            {
                return this.$map ??= 
                {
                    "Allow": 0n,
                    "Deny": 1n
                };
            }
            static $h = 299361;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static get $eut() { return $.$spc.System.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {"b":1048577,"u":655361,"l":[{"t":299361,"n":"Allow","d":299361,"h":4295266657,"f":33},{"t":299361,"n":"Deny","d":299361,"h":8590233953,"f":33}],"c":[{"n":".ctor","o":"$ctor$3","d":299361,"h":12885201249,"f":1}],"i":[57278465,63832065,57737217,57409537],"h":299361}; }
            static get $b() { return $.$spc.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IComparable, $.$spc.System.ISpanFormattable, $.$spc.System.IFormattable, $.$spc.System.IConvertible ]; }
            static get $fullName() { return `System.Security.AccessControl.AccessControlType`; }
        });
        
        $asm.$str("$ssa.System.Security.AccessControl.AceFlags", ($self) => class AceFlags extends $.$spc.System.Enum
        {
            static None = 0;
            static ObjectInherit = 1;
            static ContainerInherit = 2;
            static NoPropagateInherit = 4;
            static InheritOnly = 8;
            static InheritanceFlags = 15;
            static Inherited = 16;
            static SuccessfulAccess = 64;
            static FailedAccess = 128;
            static AuditFlags = 192;
            static $map;
            static get Map()
            {
                return this.$map ??= 
                {
                    "None": 0n,
                    "ObjectInherit": 1n,
                    "ContainerInherit": 2n,
                    "NoPropagateInherit": 4n,
                    "InheritOnly": 8n,
                    "InheritanceFlags": 15n,
                    "Inherited": 16n,
                    "SuccessfulAccess": 64n,
                    "FailedAccess": 128n,
                    "AuditFlags": 192n
                };
            }
            static $h = 561505;
            static $z = 1;
            static $f = 0b100000011010001001;
            static $k = 4;
            static get $eut() { return $.$spc.System.Byte; }
            static $$md;
            static get $md() { return this.$$md ??= {"b":1048577,"u":393217,"l":[{"t":561505,"n":"None","d":561505,"h":4295528801,"f":33},{"t":561505,"n":"ObjectInherit","d":561505,"h":8590496097,"f":33},{"t":561505,"n":"ContainerInherit","d":561505,"h":12885463393,"f":33},{"t":561505,"n":"NoPropagateInherit","d":561505,"h":17180430689,"f":33},{"t":561505,"n":"InheritOnly","d":561505,"h":21475397985,"f":33},{"t":561505,"n":"InheritanceFlags","d":561505,"h":25770365281,"f":33},{"t":561505,"n":"Inherited","d":561505,"h":30065332577,"f":33},{"t":561505,"n":"SuccessfulAccess","d":561505,"h":34360299873,"f":33},{"t":561505,"n":"FailedAccess","d":561505,"h":38655267169,"f":33},{"t":561505,"n":"AuditFlags","d":561505,"h":42950234465,"f":33}],"c":[{"n":".ctor","o":"$ctor$3","d":561505,"h":47245201761,"f":1}],"i":[57278465,63832065,57737217,57409537],"h":561505,"a":[{"t":47710209,"c":4342677505}]}; }
            static get $b() { return $.$spc.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IComparable, $.$spc.System.ISpanFormattable, $.$spc.System.IFormattable, $.$spc.System.IConvertible ]; }
            static get $fullName() { return `System.Security.AccessControl.AceFlags`; }
        });
        
        $asm.$str("$ssa.System.Security.AccessControl.AceQualifier", ($self) => class AceQualifier extends $.$spc.System.Enum
        {
            static AccessAllowed = 0;
            static AccessDenied = 1;
            static SystemAudit = 2;
            static SystemAlarm = 3;
            static $map;
            static get Map()
            {
                return this.$map ??= 
                {
                    "AccessAllowed": 0n,
                    "AccessDenied": 1n,
                    "SystemAudit": 2n,
                    "SystemAlarm": 3n
                };
            }
            static $h = 627041;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static get $eut() { return $.$spc.System.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {"b":1048577,"u":655361,"l":[{"t":627041,"n":"AccessAllowed","d":627041,"h":4295594337,"f":33},{"t":627041,"n":"AccessDenied","d":627041,"h":8590561633,"f":33},{"t":627041,"n":"SystemAudit","d":627041,"h":12885528929,"f":33},{"t":627041,"n":"SystemAlarm","d":627041,"h":17180496225,"f":33}],"c":[{"n":".ctor","o":"$ctor$3","d":627041,"h":21475463521,"f":1}],"i":[57278465,63832065,57737217,57409537],"h":627041}; }
            static get $b() { return $.$spc.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IComparable, $.$spc.System.ISpanFormattable, $.$spc.System.IFormattable, $.$spc.System.IConvertible ]; }
            static get $fullName() { return `System.Security.AccessControl.AceQualifier`; }
        });
        
        $asm.$str("$ssa.System.Security.AccessControl.AceType", ($self) => class AceType extends $.$spc.System.Enum
        {
            static AccessAllowed = 0;
            static AccessDenied = 1;
            static SystemAudit = 2;
            static SystemAlarm = 3;
            static AccessAllowedCompound = 4;
            static AccessAllowedObject = 5;
            static AccessDeniedObject = 6;
            static SystemAuditObject = 7;
            static SystemAlarmObject = 8;
            static AccessAllowedCallback = 9;
            static AccessDeniedCallback = 10;
            static AccessAllowedCallbackObject = 11;
            static AccessDeniedCallbackObject = 12;
            static SystemAuditCallback = 13;
            static SystemAlarmCallback = 14;
            static SystemAuditCallbackObject = 15;
            static MaxDefinedAceType = 16;
            static SystemAlarmCallbackObject = 16;
            static $map;
            static get Map()
            {
                return this.$map ??= 
                {
                    "AccessAllowed": 0n,
                    "AccessDenied": 1n,
                    "SystemAudit": 2n,
                    "SystemAlarm": 3n,
                    "AccessAllowedCompound": 4n,
                    "AccessAllowedObject": 5n,
                    "AccessDeniedObject": 6n,
                    "SystemAuditObject": 7n,
                    "SystemAlarmObject": 8n,
                    "AccessAllowedCallback": 9n,
                    "AccessDeniedCallback": 10n,
                    "AccessAllowedCallbackObject": 11n,
                    "AccessDeniedCallbackObject": 12n,
                    "SystemAuditCallback": 13n,
                    "SystemAlarmCallback": 14n,
                    "SystemAuditCallbackObject": 15n,
                    "MaxDefinedAceType": 16n,
                    "SystemAlarmCallbackObject": 16n
                };
            }
            static $h = 692577;
            static $z = 1;
            static $f = 0b100000011010001001;
            static $k = 4;
            static get $eut() { return $.$spc.System.Byte; }
            static $$md;
            static get $md() { return this.$$md ??= {"b":1048577,"u":393217,"l":[{"t":692577,"n":"AccessAllowed","d":692577,"h":4295659873,"f":33},{"t":692577,"n":"AccessDenied","d":692577,"h":8590627169,"f":33},{"t":692577,"n":"SystemAudit","d":692577,"h":12885594465,"f":33},{"t":692577,"n":"SystemAlarm","d":692577,"h":17180561761,"f":33},{"t":692577,"n":"AccessAllowedCompound","d":692577,"h":21475529057,"f":33},{"t":692577,"n":"AccessAllowedObject","d":692577,"h":25770496353,"f":33},{"t":692577,"n":"AccessDeniedObject","d":692577,"h":30065463649,"f":33},{"t":692577,"n":"SystemAuditObject","d":692577,"h":34360430945,"f":33},{"t":692577,"n":"SystemAlarmObject","d":692577,"h":38655398241,"f":33},{"t":692577,"n":"AccessAllowedCallback","d":692577,"h":42950365537,"f":33},{"t":692577,"n":"AccessDeniedCallback","d":692577,"h":47245332833,"f":33},{"t":692577,"n":"AccessAllowedCallbackObject","d":692577,"h":51540300129,"f":33},{"t":692577,"n":"AccessDeniedCallbackObject","d":692577,"h":55835267425,"f":33},{"t":692577,"n":"SystemAuditCallback","d":692577,"h":60130234721,"f":33},{"t":692577,"n":"SystemAlarmCallback","d":692577,"h":64425202017,"f":33},{"t":692577,"n":"SystemAuditCallbackObject","d":692577,"h":68720169313,"f":33},{"t":692577,"n":"MaxDefinedAceType","d":692577,"h":73015136609,"f":33},{"t":692577,"n":"SystemAlarmCallbackObject","d":692577,"h":77310103905,"f":33}],"c":[{"n":".ctor","o":"$ctor$3","d":692577,"h":81605071201,"f":1}],"i":[57278465,63832065,57737217,57409537],"h":692577}; }
            static get $b() { return $.$spc.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IComparable, $.$spc.System.ISpanFormattable, $.$spc.System.IFormattable, $.$spc.System.IConvertible ]; }
            static get $fullName() { return `System.Security.AccessControl.AceType`; }
        });
        
        $asm.$str("$ssa.System.Security.AccessControl.AuditFlags", ($self) => class AuditFlags extends $.$spc.System.Enum
        {
            static None = 0;
            static Success = 1;
            static Failure = 2;
            static $map;
            static get Map()
            {
                return this.$map ??= 
                {
                    "None": 0n,
                    "Success": 1n,
                    "Failure": 2n
                };
            }
            static $h = 758113;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static get $eut() { return $.$spc.System.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {"b":1048577,"u":655361,"l":[{"t":758113,"n":"None","d":758113,"h":4295725409,"f":33},{"t":758113,"n":"Success","d":758113,"h":8590692705,"f":33},{"t":758113,"n":"Failure","d":758113,"h":12885660001,"f":33}],"c":[{"n":".ctor","o":"$ctor$3","d":758113,"h":17180627297,"f":1}],"i":[57278465,63832065,57737217,57409537],"h":758113,"a":[{"t":47710209,"c":4342677505}]}; }
            static get $b() { return $.$spc.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IComparable, $.$spc.System.ISpanFormattable, $.$spc.System.IFormattable, $.$spc.System.IConvertible ]; }
            static get $fullName() { return `System.Security.AccessControl.AuditFlags`; }
        });
        
        $asm.$str("$ssa.System.Security.AccessControl.CompoundAceType", ($self) => class CompoundAceType extends $.$spc.System.Enum
        {
            static Impersonation = 1;
            static $map;
            static get Map()
            {
                return this.$map ??= 
                {
                    "Impersonation": 1n
                };
            }
            static $h = 1413473;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static get $eut() { return $.$spc.System.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {"b":1048577,"u":655361,"l":[{"t":1413473,"n":"Impersonation","d":1413473,"h":4296380769,"f":33}],"c":[{"n":".ctor","o":"$ctor$3","d":1413473,"h":8591348065,"f":1}],"i":[57278465,63832065,57737217,57409537],"h":1413473}; }
            static get $b() { return $.$spc.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IComparable, $.$spc.System.ISpanFormattable, $.$spc.System.IFormattable, $.$spc.System.IConvertible ]; }
            static get $fullName() { return `System.Security.AccessControl.CompoundAceType`; }
        });
        
        $asm.$str("$ssa.System.Security.AccessControl.ControlFlags", ($self) => class ControlFlags extends $.$spc.System.Enum
        {
            static None = 0;
            static OwnerDefaulted = 1;
            static GroupDefaulted = 2;
            static DiscretionaryAclPresent = 4;
            static DiscretionaryAclDefaulted = 8;
            static SystemAclPresent = 16;
            static SystemAclDefaulted = 32;
            static DiscretionaryAclUntrusted = 64;
            static ServerSecurity = 128;
            static DiscretionaryAclAutoInheritRequired = 256;
            static SystemAclAutoInheritRequired = 512;
            static DiscretionaryAclAutoInherited = 1024;
            static SystemAclAutoInherited = 2048;
            static DiscretionaryAclProtected = 4096;
            static SystemAclProtected = 8192;
            static RMControlValid = 16384;
            static SelfRelative = 32768;
            static $map;
            static get Map()
            {
                return this.$map ??= 
                {
                    "None": 0n,
                    "OwnerDefaulted": 1n,
                    "GroupDefaulted": 2n,
                    "DiscretionaryAclPresent": 4n,
                    "DiscretionaryAclDefaulted": 8n,
                    "SystemAclPresent": 16n,
                    "SystemAclDefaulted": 32n,
                    "DiscretionaryAclUntrusted": 64n,
                    "ServerSecurity": 128n,
                    "DiscretionaryAclAutoInheritRequired": 256n,
                    "SystemAclAutoInheritRequired": 512n,
                    "DiscretionaryAclAutoInherited": 1024n,
                    "SystemAclAutoInherited": 2048n,
                    "DiscretionaryAclProtected": 4096n,
                    "SystemAclProtected": 8192n,
                    "RMControlValid": 16384n,
                    "SelfRelative": 32768n
                };
            }
            static $h = 1479009;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static get $eut() { return $.$spc.System.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {"b":1048577,"u":655361,"l":[{"t":1479009,"n":"None","d":1479009,"h":4296446305,"f":33},{"t":1479009,"n":"OwnerDefaulted","d":1479009,"h":8591413601,"f":33},{"t":1479009,"n":"GroupDefaulted","d":1479009,"h":12886380897,"f":33},{"t":1479009,"n":"DiscretionaryAclPresent","d":1479009,"h":17181348193,"f":33},{"t":1479009,"n":"DiscretionaryAclDefaulted","d":1479009,"h":21476315489,"f":33},{"t":1479009,"n":"SystemAclPresent","d":1479009,"h":25771282785,"f":33},{"t":1479009,"n":"SystemAclDefaulted","d":1479009,"h":30066250081,"f":33},{"t":1479009,"n":"DiscretionaryAclUntrusted","d":1479009,"h":34361217377,"f":33},{"t":1479009,"n":"ServerSecurity","d":1479009,"h":38656184673,"f":33},{"t":1479009,"n":"DiscretionaryAclAutoInheritRequired","d":1479009,"h":42951151969,"f":33},{"t":1479009,"n":"SystemAclAutoInheritRequired","d":1479009,"h":47246119265,"f":33},{"t":1479009,"n":"DiscretionaryAclAutoInherited","d":1479009,"h":51541086561,"f":33},{"t":1479009,"n":"SystemAclAutoInherited","d":1479009,"h":55836053857,"f":33},{"t":1479009,"n":"DiscretionaryAclProtected","d":1479009,"h":60131021153,"f":33},{"t":1479009,"n":"SystemAclProtected","d":1479009,"h":64425988449,"f":33},{"t":1479009,"n":"RMControlValid","d":1479009,"h":68720955745,"f":33},{"t":1479009,"n":"SelfRelative","d":1479009,"h":73015923041,"f":33}],"c":[{"n":".ctor","o":"$ctor$3","d":1479009,"h":77310890337,"f":1}],"i":[57278465,63832065,57737217,57409537],"h":1479009,"a":[{"t":47710209,"c":4342677505}]}; }
            static get $b() { return $.$spc.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IComparable, $.$spc.System.ISpanFormattable, $.$spc.System.IFormattable, $.$spc.System.IConvertible ]; }
            static get $fullName() { return `System.Security.AccessControl.ControlFlags`; }
        });
        
        $asm.$str("$ssa.System.Security.AccessControl.InheritanceFlags", ($self) => class InheritanceFlags extends $.$spc.System.Enum
        {
            static None = 0;
            static ContainerInherit = 1;
            static ObjectInherit = 2;
            static $map;
            static get Map()
            {
                return this.$map ??= 
                {
                    "None": 0n,
                    "ContainerInherit": 1n,
                    "ObjectInherit": 2n
                };
            }
            static $h = 1872225;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static get $eut() { return $.$spc.System.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {"b":1048577,"u":655361,"l":[{"t":1872225,"n":"None","d":1872225,"h":4296839521,"f":33},{"t":1872225,"n":"ContainerInherit","d":1872225,"h":8591806817,"f":33},{"t":1872225,"n":"ObjectInherit","d":1872225,"h":12886774113,"f":33}],"c":[{"n":".ctor","o":"$ctor$3","d":1872225,"h":17181741409,"f":1}],"i":[57278465,63832065,57737217,57409537],"h":1872225,"a":[{"t":47710209,"c":4342677505}]}; }
            static get $b() { return $.$spc.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IComparable, $.$spc.System.ISpanFormattable, $.$spc.System.IFormattable, $.$spc.System.IConvertible ]; }
            static get $fullName() { return `System.Security.AccessControl.InheritanceFlags`; }
        });
        
        $asm.$str("$ssa.System.Security.AccessControl.ObjectAceFlags", ($self) => class ObjectAceFlags extends $.$spc.System.Enum
        {
            static None = 0;
            static ObjectAceTypePresent = 1;
            static InheritedObjectAceTypePresent = 2;
            static $map;
            static get Map()
            {
                return this.$map ??= 
                {
                    "None": 0n,
                    "ObjectAceTypePresent": 1n,
                    "InheritedObjectAceTypePresent": 2n
                };
            }
            static $h = 2265441;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static get $eut() { return $.$spc.System.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {"b":1048577,"u":655361,"l":[{"t":2265441,"n":"None","d":2265441,"h":4297232737,"f":33},{"t":2265441,"n":"ObjectAceTypePresent","d":2265441,"h":8592200033,"f":33},{"t":2265441,"n":"InheritedObjectAceTypePresent","d":2265441,"h":12887167329,"f":33}],"c":[{"n":".ctor","o":"$ctor$3","d":2265441,"h":17182134625,"f":1}],"i":[57278465,63832065,57737217,57409537],"h":2265441,"a":[{"t":47710209,"c":4342677505}]}; }
            static get $b() { return $.$spc.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IComparable, $.$spc.System.ISpanFormattable, $.$spc.System.IFormattable, $.$spc.System.IConvertible ]; }
            static get $fullName() { return `System.Security.AccessControl.ObjectAceFlags`; }
        });
        
        $asm.$str("$ssa.System.Security.AccessControl.PropagationFlags", ($self) => class PropagationFlags extends $.$spc.System.Enum
        {
            static None = 0;
            static NoPropagateInherit = 1;
            static InheritOnly = 2;
            static $map;
            static get Map()
            {
                return this.$map ??= 
                {
                    "None": 0n,
                    "NoPropagateInherit": 1n,
                    "InheritOnly": 2n
                };
            }
            static $h = 2593121;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static get $eut() { return $.$spc.System.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {"b":1048577,"u":655361,"l":[{"t":2593121,"n":"None","d":2593121,"h":4297560417,"f":33},{"t":2593121,"n":"NoPropagateInherit","d":2593121,"h":8592527713,"f":33},{"t":2593121,"n":"InheritOnly","d":2593121,"h":12887495009,"f":33}],"c":[{"n":".ctor","o":"$ctor$3","d":2593121,"h":17182462305,"f":1}],"i":[57278465,63832065,57737217,57409537],"h":2593121,"a":[{"t":47710209,"c":4342677505}]}; }
            static get $b() { return $.$spc.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IComparable, $.$spc.System.ISpanFormattable, $.$spc.System.IFormattable, $.$spc.System.IConvertible ]; }
            static get $fullName() { return `System.Security.AccessControl.PropagationFlags`; }
        });
        
        $asm.$str("$ssa.System.Security.AccessControl.ResourceType", ($self) => class ResourceType extends $.$spc.System.Enum
        {
            static Unknown = 0;
            static FileObject = 1;
            static Service = 2;
            static Printer = 3;
            static RegistryKey = 4;
            static LMShare = 5;
            static KernelObject = 6;
            static WindowObject = 7;
            static DSObject = 8;
            static DSObjectAll = 9;
            static ProviderDefined = 10;
            static WmiGuidObject = 11;
            static RegistryWow6432Key = 12;
            static $map;
            static get Map()
            {
                return this.$map ??= 
                {
                    "Unknown": 0n,
                    "FileObject": 1n,
                    "Service": 2n,
                    "Printer": 3n,
                    "RegistryKey": 4n,
                    "LMShare": 5n,
                    "KernelObject": 6n,
                    "WindowObject": 7n,
                    "DSObject": 8n,
                    "DSObjectAll": 9n,
                    "ProviderDefined": 10n,
                    "WmiGuidObject": 11n,
                    "RegistryWow6432Key": 12n
                };
            }
            static $h = 2855265;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static get $eut() { return $.$spc.System.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {"b":1048577,"u":655361,"l":[{"t":2855265,"n":"Unknown","d":2855265,"h":4297822561,"f":33},{"t":2855265,"n":"FileObject","d":2855265,"h":8592789857,"f":33},{"t":2855265,"n":"Service","d":2855265,"h":12887757153,"f":33},{"t":2855265,"n":"Printer","d":2855265,"h":17182724449,"f":33},{"t":2855265,"n":"RegistryKey","d":2855265,"h":21477691745,"f":33},{"t":2855265,"n":"LMShare","d":2855265,"h":25772659041,"f":33},{"t":2855265,"n":"KernelObject","d":2855265,"h":30067626337,"f":33},{"t":2855265,"n":"WindowObject","d":2855265,"h":34362593633,"f":33},{"t":2855265,"n":"DSObject","d":2855265,"h":38657560929,"f":33},{"t":2855265,"n":"DSObjectAll","d":2855265,"h":42952528225,"f":33},{"t":2855265,"n":"ProviderDefined","d":2855265,"h":47247495521,"f":33},{"t":2855265,"n":"WmiGuidObject","d":2855265,"h":51542462817,"f":33},{"t":2855265,"n":"RegistryWow6432Key","d":2855265,"h":55837430113,"f":33}],"c":[{"n":".ctor","o":"$ctor$3","d":2855265,"h":60132397409,"f":1}],"i":[57278465,63832065,57737217,57409537],"h":2855265}; }
            static get $b() { return $.$spc.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IComparable, $.$spc.System.ISpanFormattable, $.$spc.System.IFormattable, $.$spc.System.IConvertible ]; }
            static get $fullName() { return `System.Security.AccessControl.ResourceType`; }
        });
        
        $asm.$str("$ssa.System.Security.AccessControl.SecurityInfos", ($self) => class SecurityInfos extends $.$spc.System.Enum
        {
            static Owner = 1;
            static Group = 2;
            static DiscretionaryAcl = 4;
            static SystemAcl = 8;
            static $map;
            static get Map()
            {
                return this.$map ??= 
                {
                    "Owner": 1n,
                    "Group": 2n,
                    "DiscretionaryAcl": 4n,
                    "SystemAcl": 8n
                };
            }
            static $h = 2920801;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static get $eut() { return $.$spc.System.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {"b":1048577,"u":655361,"l":[{"t":2920801,"n":"Owner","d":2920801,"h":4297888097,"f":33},{"t":2920801,"n":"Group","d":2920801,"h":8592855393,"f":33},{"t":2920801,"n":"DiscretionaryAcl","d":2920801,"h":12887822689,"f":33},{"t":2920801,"n":"SystemAcl","d":2920801,"h":17182789985,"f":33}],"c":[{"n":".ctor","o":"$ctor$3","d":2920801,"h":21477757281,"f":1}],"i":[57278465,63832065,57737217,57409537],"h":2920801,"a":[{"t":47710209,"c":4342677505}]}; }
            static get $b() { return $.$spc.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IComparable, $.$spc.System.ISpanFormattable, $.$spc.System.IFormattable, $.$spc.System.IConvertible ]; }
            static get $fullName() { return `System.Security.AccessControl.SecurityInfos`; }
        });
        
        $asm.$cls("$ssa.System.Security.AccessControl.CommonAce", ($self) => class CommonAce extends $.$ssa.System.Security.AccessControl.QualifiedAce
        {
            $ctor$4(/*System.Security.AccessControl.AceFlags*/ flags, /*System.Security.AccessControl.AceQualifier*/ qualifier, /*int*/ accessMask, /*System.Security.Principal.SecurityIdentifier*/ sid, /*bool*/ isCallback, /*byte[]?*/ opaque)
            {
                super.$ctor$3();
                {
                }
                return this;
            }
            /*int */ get BinaryLength()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*void */ GetBinaryForm(/*byte[]*/ binaryForm, /*int*/ offset)
            {
            }
            static /*int */ MaxOpaqueLength(/*bool*/ isCallback)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static $h = 1085793;
            static $f = 0b10010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":2658657,"p":[{"p":655361,"g":{"r":0,"d":0,"h":12885987681,"f":32769},"n":"BinaryLength","d":1085793,"h":8591020385,"f":32769}],"m":[{"r":65537,"p":[{"n":"binaryForm","p":0},{"n":"offset","p":655361}],"n":"GetBinaryForm","d":1085793,"h":17180954977,"f":32769},{"r":655361,"p":[{"n":"isCallback","p":262145}],"n":"MaxOpaqueLength","d":1085793,"h":21475922273,"f":33}],"c":[{"p":[{"n":"flags","p":561505},{"n":"qualifier","p":627041},{"n":"accessMask","p":655361},{"n":"sid","p":446495},{"n":"isCallback","p":262145},{"n":"opaque","p":0}],"n":".ctor","o":"$ctor$4","d":1085793,"h":4296053089,"f":1}],"h":1085793}; }
            static get $b() { return $.$ssa.System.Security.AccessControl.QualifiedAce; }
            static get $fullName() { return `System.Security.AccessControl.CommonAce`; }
        });
        
        $asm.$cls("$ssa.System.Security.AccessControl.ObjectAce", ($self) => class ObjectAce extends $.$ssa.System.Security.AccessControl.QualifiedAce
        {
            $ctor$4(/*System.Security.AccessControl.AceFlags*/ aceFlags, /*System.Security.AccessControl.AceQualifier*/ qualifier, /*int*/ accessMask, /*System.Security.Principal.SecurityIdentifier*/ sid, /*System.Security.AccessControl.ObjectAceFlags*/ flags, /*System.Guid*/ type, /*System.Guid*/ inheritedType, /*bool*/ isCallback, /*byte[]?*/ opaque)
            {
                super.$ctor$3();
                {
                }
                return this;
            }
            /*int */ get BinaryLength()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Guid */ get InheritedObjectAceType()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Guid */ set InheritedObjectAceType(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Security.AccessControl.ObjectAceFlags */ get ObjectAceFlags()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Security.AccessControl.ObjectAceFlags */ set ObjectAceFlags(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Guid */ get ObjectAceType()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Guid */ set ObjectAceType(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*void */ GetBinaryForm(/*byte[]*/ binaryForm, /*int*/ offset)
            {
            }
            static /*int */ MaxOpaqueLength(/*bool*/ isCallback)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static $h = 2199905;
            static $f = 0b10010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":2658657,"p":[{"p":655361,"g":{"r":0,"d":0,"h":12887101793,"f":32769},"n":"BinaryLength","d":2199905,"h":8592134497,"f":32769},{"p":56229889,"g":{"r":0,"d":0,"h":21477036385,"f":1},"s":{"r":0,"d":0,"h":25772003681,"f":1},"n":"InheritedObjectAceType","d":2199905,"h":17182069089,"f":1},{"p":2265441,"g":{"r":0,"d":0,"h":34361938273,"f":1},"s":{"r":0,"d":0,"h":38656905569,"f":1},"n":"ObjectAceFlags","d":2199905,"h":30066970977,"f":1},{"p":56229889,"g":{"r":0,"d":0,"h":47246840161,"f":1},"s":{"r":0,"d":0,"h":51541807457,"f":1},"n":"ObjectAceType","d":2199905,"h":42951872865,"f":1}],"m":[{"r":65537,"p":[{"n":"binaryForm","p":0},{"n":"offset","p":655361}],"n":"GetBinaryForm","d":2199905,"h":55836774753,"f":32769},{"r":655361,"p":[{"n":"isCallback","p":262145}],"n":"MaxOpaqueLength","d":2199905,"h":60131742049,"f":33}],"c":[{"p":[{"n":"aceFlags","p":561505},{"n":"qualifier","p":627041},{"n":"accessMask","p":655361},{"n":"sid","p":446495},{"n":"flags","p":2265441},{"n":"type","p":56229889},{"n":"inheritedType","p":56229889},{"n":"isCallback","p":262145},{"n":"opaque","p":0}],"n":".ctor","o":"$ctor$4","d":2199905,"h":4297167201,"f":1}],"h":2199905}; }
            static get $b() { return $.$ssa.System.Security.AccessControl.QualifiedAce; }
            static get $fullName() { return `System.Security.AccessControl.ObjectAce`; }
        });
        
        $asm.$cls("$ssa.System.Security.AccessControl.PrivilegeNotHeldException", ($self) => class PrivilegeNotHeldException extends $.$spc.System.UnauthorizedAccessException
        {
            $ctor$13()
            {
                super.$ctor$9();
                {
                }
                return this;
            }
            $ctor$14(/*string?*/ privilege)
            {
                super.$ctor$9();
                {
                }
                return this;
            }
            $ctor$15(/*string?*/ privilege, /*System.Exception?*/ inner)
            {
                super.$ctor$9();
                {
                }
                return this;
            }
            /*string? */ get PrivilegeName()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*void */ GetObjectData(/*System.Runtime.Serialization.SerializationInfo*/ info, /*System.Runtime.Serialization.StreamingContext*/ context)
            {
            }
            static $h = 2527585;
            static $f = 0b10010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":143851521,"h":2527585}; }
            static get $b() { return $.$spc.System.UnauthorizedAccessException; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.Runtime.Serialization.ISerializable ]; }
            static get $fullName() { return `System.Security.AccessControl.PrivilegeNotHeldException`; }
        });
	});
})(window, window.NetJs.$boot(), ...window.NetJs.$require("NetJs.System.Private.CoreLib", "NetJs.Microsoft.Win32.Primitives", "NetJs.System.Collections", "NetJs.System.Diagnostics.Tracing", "NetJs.System.Threading", "NetJs.System.Collections.Concurrent", "NetJs.System.Memory", "NetJs.System.Private.Uri", "NetJs.System.Runtime", "NetJs.System.Collections.NonGeneric", "NetJs.System.Runtime.InteropServices", "NetJs.System.Threading.Thread", "NetJs.System.Security.Claims", "NetJs.System.Security.Principal.Windows"))