
(function ($global, $, $$, $sc, $sm, $spu, $sr, $stt) {
    "use strict";
    let _;
    
    
    
	$.$asm(
    "NetJs.System.Security.Claims", 
    {"h":33246,"f":"System.Security.Claims","v":"1.0.35.0","a":[{"t":115015681,"c":12999917569,"a":[{"v":".NETCoreApp,Version=v10.0","t":1310721}],"n":[{"n":"FrameworkDisplayName","v":".NET 10.0","t":1310721}]},{"t":73596929,"c":4368564225,"a":[{"v":"SIT","t":1310721}]},{"t":73662465,"c":4368629761,"a":[{"v":"Debug","t":1310721}]},{"t":74121217,"c":4369088513,"a":[{"v":"1.0.35.0","t":1310721}]},{"t":74252289,"c":4369219585,"a":[{"v":"1.0.35\u002Beff628fa5ab8bd29ec37e9c13a50148694bea088","t":1310721}]},{"t":75104257,"c":4370071553,"a":[{"v":"NetJs.System.Security.Claims","t":1310721}]},{"t":75235329,"c":4370202625,"a":[{"v":"NetJs.System.Security.Claims","t":1310721}]},{"t":75366401,"c":4370333697,"a":[{"v":"1.0.35.0","t":1310721}]},{"t":115081217,"c":4410048513,"a":[{"v":"browser1.0","t":1310721}]},{"t":114819073,"c":4409786369,"a":[{"v":"browser1.0","t":1310721}]}],"m":[]},
    function($asm)
	{
        
        
        $asm.$cls("$ssc.System.Security.Claims.ClaimTypes", ($self) => class ClaimTypes
        {
            /*string*/ static ClaimTypeNamespace = null;
            /*string*/ static AuthenticationInstant = null;
            /*string*/ static AuthenticationMethod = null;
            /*string*/ static CookiePath = null;
            /*string*/ static DenyOnlyPrimarySid = null;
            /*string*/ static DenyOnlyPrimaryGroupSid = null;
            /*string*/ static DenyOnlyWindowsDeviceGroup = null;
            /*string*/ static Dsa = null;
            /*string*/ static Expiration = null;
            /*string*/ static Expired = null;
            /*string*/ static GroupSid = null;
            /*string*/ static IsPersistent = null;
            /*string*/ static PrimaryGroupSid = null;
            /*string*/ static PrimarySid = null;
            /*string*/ static Role = null;
            /*string*/ static SerialNumber = null;
            /*string*/ static UserData = null;
            /*string*/ static Version = null;
            /*string*/ static WindowsAccountName = null;
            /*string*/ static WindowsDeviceClaim = null;
            /*string*/ static WindowsDeviceGroup = null;
            /*string*/ static WindowsUserClaim = null;
            /*string*/ static WindowsFqbnVersion = null;
            /*string*/ static WindowsSubAuthority = null;
            /*string*/ static ClaimType2005Namespace = null;
            /*string*/ static Anonymous = null;
            /*string*/ static Authentication = null;
            /*string*/ static AuthorizationDecision = null;
            /*string*/ static Country = null;
            /*string*/ static DateOfBirth = null;
            /*string*/ static Dns = null;
            /*string*/ static DenyOnlySid = null;
            /*string*/ static Email = null;
            /*string*/ static Gender = null;
            /*string*/ static GivenName = null;
            /*string*/ static Hash = null;
            /*string*/ static HomePhone = null;
            /*string*/ static Locality = null;
            /*string*/ static MobilePhone = null;
            /*string*/ static Name = null;
            /*string*/ static NameIdentifier = null;
            /*string*/ static OtherPhone = null;
            /*string*/ static PostalCode = null;
            /*string*/ static Rsa = null;
            /*string*/ static Sid = null;
            /*string*/ static Spn = null;
            /*string*/ static StateOrProvince = null;
            /*string*/ static StreetAddress = null;
            /*string*/ static Surname = null;
            /*string*/ static System = null;
            /*string*/ static Thumbprint = null;
            /*string*/ static Upn = null;
            /*string*/ static Uri = null;
            /*string*/ static Webpage = null;
            /*string*/ static X500DistinguishedName = null;
            /*string*/ static ClaimType2009Namespace = null;
            /*string*/ static Actor = null;
            //Static Initializer
            static $sinit()
            {
                {
                    this.ClaimTypeNamespace = "http://schemas.microsoft.com/ws/2008/06/identity/claims";
                }
                {
                    this.AuthenticationInstant = "http://schemas.microsoft.com/ws/2008/06/identity/claims/authenticationinstant";
                }
                {
                    this.AuthenticationMethod = "http://schemas.microsoft.com/ws/2008/06/identity/claims/authenticationmethod";
                }
                {
                    this.CookiePath = "http://schemas.microsoft.com/ws/2008/06/identity/claims/cookiepath";
                }
                {
                    this.DenyOnlyPrimarySid = "http://schemas.microsoft.com/ws/2008/06/identity/claims/denyonlyprimarysid";
                }
                {
                    this.DenyOnlyPrimaryGroupSid = "http://schemas.microsoft.com/ws/2008/06/identity/claims/denyonlyprimarygroupsid";
                }
                {
                    this.DenyOnlyWindowsDeviceGroup = "http://schemas.microsoft.com/ws/2008/06/identity/claims/denyonlywindowsdevicegroup";
                }
                {
                    this.Dsa = "http://schemas.microsoft.com/ws/2008/06/identity/claims/dsa";
                }
                {
                    this.Expiration = "http://schemas.microsoft.com/ws/2008/06/identity/claims/expiration";
                }
                {
                    this.Expired = "http://schemas.microsoft.com/ws/2008/06/identity/claims/expired";
                }
                {
                    this.GroupSid = "http://schemas.microsoft.com/ws/2008/06/identity/claims/groupsid";
                }
                {
                    this.IsPersistent = "http://schemas.microsoft.com/ws/2008/06/identity/claims/ispersistent";
                }
                {
                    this.PrimaryGroupSid = "http://schemas.microsoft.com/ws/2008/06/identity/claims/primarygroupsid";
                }
                {
                    this.PrimarySid = "http://schemas.microsoft.com/ws/2008/06/identity/claims/primarysid";
                }
                {
                    this.Role = "http://schemas.microsoft.com/ws/2008/06/identity/claims/role";
                }
                {
                    this.SerialNumber = "http://schemas.microsoft.com/ws/2008/06/identity/claims/serialnumber";
                }
                {
                    this.UserData = "http://schemas.microsoft.com/ws/2008/06/identity/claims/userdata";
                }
                {
                    this.Version = "http://schemas.microsoft.com/ws/2008/06/identity/claims/version";
                }
                {
                    this.WindowsAccountName = "http://schemas.microsoft.com/ws/2008/06/identity/claims/windowsaccountname";
                }
                {
                    this.WindowsDeviceClaim = "http://schemas.microsoft.com/ws/2008/06/identity/claims/windowsdeviceclaim";
                }
                {
                    this.WindowsDeviceGroup = "http://schemas.microsoft.com/ws/2008/06/identity/claims/windowsdevicegroup";
                }
                {
                    this.WindowsUserClaim = "http://schemas.microsoft.com/ws/2008/06/identity/claims/windowsuserclaim";
                }
                {
                    this.WindowsFqbnVersion = "http://schemas.microsoft.com/ws/2008/06/identity/claims/windowsfqbnversion";
                }
                {
                    this.WindowsSubAuthority = "http://schemas.microsoft.com/ws/2008/06/identity/claims/windowssubauthority";
                }
                {
                    this.ClaimType2005Namespace = "http://schemas.xmlsoap.org/ws/2005/05/identity/claims";
                }
                {
                    this.Anonymous = "http://schemas.xmlsoap.org/ws/2005/05/identity/claims/anonymous";
                }
                {
                    this.Authentication = "http://schemas.xmlsoap.org/ws/2005/05/identity/claims/authentication";
                }
                {
                    this.AuthorizationDecision = "http://schemas.xmlsoap.org/ws/2005/05/identity/claims/authorizationdecision";
                }
                {
                    this.Country = "http://schemas.xmlsoap.org/ws/2005/05/identity/claims/country";
                }
                {
                    this.DateOfBirth = "http://schemas.xmlsoap.org/ws/2005/05/identity/claims/dateofbirth";
                }
                {
                    this.Dns = "http://schemas.xmlsoap.org/ws/2005/05/identity/claims/dns";
                }
                {
                    this.DenyOnlySid = "http://schemas.xmlsoap.org/ws/2005/05/identity/claims/denyonlysid";
                }
                {
                    this.Email = "http://schemas.xmlsoap.org/ws/2005/05/identity/claims/emailaddress";
                }
                {
                    this.Gender = "http://schemas.xmlsoap.org/ws/2005/05/identity/claims/gender";
                }
                {
                    this.GivenName = "http://schemas.xmlsoap.org/ws/2005/05/identity/claims/givenname";
                }
                {
                    this.Hash = "http://schemas.xmlsoap.org/ws/2005/05/identity/claims/hash";
                }
                {
                    this.HomePhone = "http://schemas.xmlsoap.org/ws/2005/05/identity/claims/homephone";
                }
                {
                    this.Locality = "http://schemas.xmlsoap.org/ws/2005/05/identity/claims/locality";
                }
                {
                    this.MobilePhone = "http://schemas.xmlsoap.org/ws/2005/05/identity/claims/mobilephone";
                }
                {
                    this.Name = "http://schemas.xmlsoap.org/ws/2005/05/identity/claims/name";
                }
                {
                    this.NameIdentifier = "http://schemas.xmlsoap.org/ws/2005/05/identity/claims/nameidentifier";
                }
                {
                    this.OtherPhone = "http://schemas.xmlsoap.org/ws/2005/05/identity/claims/otherphone";
                }
                {
                    this.PostalCode = "http://schemas.xmlsoap.org/ws/2005/05/identity/claims/postalcode";
                }
                {
                    this.Rsa = "http://schemas.xmlsoap.org/ws/2005/05/identity/claims/rsa";
                }
                {
                    this.Sid = "http://schemas.xmlsoap.org/ws/2005/05/identity/claims/sid";
                }
                {
                    this.Spn = "http://schemas.xmlsoap.org/ws/2005/05/identity/claims/spn";
                }
                {
                    this.StateOrProvince = "http://schemas.xmlsoap.org/ws/2005/05/identity/claims/stateorprovince";
                }
                {
                    this.StreetAddress = "http://schemas.xmlsoap.org/ws/2005/05/identity/claims/streetaddress";
                }
                {
                    this.Surname = "http://schemas.xmlsoap.org/ws/2005/05/identity/claims/surname";
                }
                {
                    this.System = "http://schemas.xmlsoap.org/ws/2005/05/identity/claims/system";
                }
                {
                    this.Thumbprint = "http://schemas.xmlsoap.org/ws/2005/05/identity/claims/thumbprint";
                }
                {
                    this.Upn = "http://schemas.xmlsoap.org/ws/2005/05/identity/claims/upn";
                }
                {
                    this.Uri = "http://schemas.xmlsoap.org/ws/2005/05/identity/claims/uri";
                }
                {
                    this.Webpage = "http://schemas.xmlsoap.org/ws/2005/05/identity/claims/webpage";
                }
                {
                    this.X500DistinguishedName = "http://schemas.xmlsoap.org/ws/2005/05/identity/claims/x500distinguishedname";
                }
                {
                    this.ClaimType2009Namespace = "http://schemas.xmlsoap.org/ws/2009/09/identity/claims";
                }
                {
                    this.Actor = "http://schemas.xmlsoap.org/ws/2009/09/identity/claims/actor";
                }
            }
            static $h = 557534;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"l":[{"t":1310721,"n":"ClaimTypeNamespace","d":557534,"h":4295524830,"f":4194344},{"t":1310721,"n":"AuthenticationInstant","d":557534,"h":8590492126,"f":4194337},{"t":1310721,"n":"AuthenticationMethod","d":557534,"h":12885459422,"f":4194337},{"t":1310721,"n":"CookiePath","d":557534,"h":17180426718,"f":4194337},{"t":1310721,"n":"DenyOnlyPrimarySid","d":557534,"h":21475394014,"f":4194337},{"t":1310721,"n":"DenyOnlyPrimaryGroupSid","d":557534,"h":25770361310,"f":4194337},{"t":1310721,"n":"DenyOnlyWindowsDeviceGroup","d":557534,"h":30065328606,"f":4194337},{"t":1310721,"n":"Dsa","d":557534,"h":34360295902,"f":4194337},{"t":1310721,"n":"Expiration","d":557534,"h":38655263198,"f":4194337},{"t":1310721,"n":"Expired","d":557534,"h":42950230494,"f":4194337},{"t":1310721,"n":"GroupSid","d":557534,"h":47245197790,"f":4194337},{"t":1310721,"n":"IsPersistent","d":557534,"h":51540165086,"f":4194337},{"t":1310721,"n":"PrimaryGroupSid","d":557534,"h":55835132382,"f":4194337},{"t":1310721,"n":"PrimarySid","d":557534,"h":60130099678,"f":4194337},{"t":1310721,"n":"Role","d":557534,"h":64425066974,"f":4194337},{"t":1310721,"n":"SerialNumber","d":557534,"h":68720034270,"f":4194337},{"t":1310721,"n":"UserData","d":557534,"h":73015001566,"f":4194337},{"t":1310721,"n":"Version","d":557534,"h":77309968862,"f":4194337},{"t":1310721,"n":"WindowsAccountName","d":557534,"h":81604936158,"f":4194337},{"t":1310721,"n":"WindowsDeviceClaim","d":557534,"h":85899903454,"f":4194337},{"t":1310721,"n":"WindowsDeviceGroup","d":557534,"h":90194870750,"f":4194337},{"t":1310721,"n":"WindowsUserClaim","d":557534,"h":94489838046,"f":4194337},{"t":1310721,"n":"WindowsFqbnVersion","d":557534,"h":98784805342,"f":4194337},{"t":1310721,"n":"WindowsSubAuthority","d":557534,"h":103079772638,"f":4194337},{"t":1310721,"n":"ClaimType2005Namespace","d":557534,"h":107374739934,"f":4194344},{"t":1310721,"n":"Anonymous","d":557534,"h":111669707230,"f":4194337},{"t":1310721,"n":"Authentication","d":557534,"h":115964674526,"f":4194337},{"t":1310721,"n":"AuthorizationDecision","d":557534,"h":120259641822,"f":4194337},{"t":1310721,"n":"Country","d":557534,"h":124554609118,"f":4194337},{"t":1310721,"n":"DateOfBirth","d":557534,"h":128849576414,"f":4194337},{"t":1310721,"n":"Dns","d":557534,"h":133144543710,"f":4194337},{"t":1310721,"n":"DenyOnlySid","d":557534,"h":137439511006,"f":4194337},{"t":1310721,"n":"Email","d":557534,"h":141734478302,"f":4194337},{"t":1310721,"n":"Gender","d":557534,"h":146029445598,"f":4194337},{"t":1310721,"n":"GivenName","d":557534,"h":150324412894,"f":4194337},{"t":1310721,"n":"Hash","d":557534,"h":154619380190,"f":4194337},{"t":1310721,"n":"HomePhone","d":557534,"h":158914347486,"f":4194337},{"t":1310721,"n":"Locality","d":557534,"h":163209314782,"f":4194337},{"t":1310721,"n":"MobilePhone","d":557534,"h":167504282078,"f":4194337},{"t":1310721,"n":"Name","d":557534,"h":171799249374,"f":4194337},{"t":1310721,"n":"NameIdentifier","d":557534,"h":176094216670,"f":4194337},{"t":1310721,"n":"OtherPhone","d":557534,"h":180389183966,"f":4194337},{"t":1310721,"n":"PostalCode","d":557534,"h":184684151262,"f":4194337},{"t":1310721,"n":"Rsa","d":557534,"h":188979118558,"f":4194337},{"t":1310721,"n":"Sid","d":557534,"h":193274085854,"f":4194337},{"t":1310721,"n":"Spn","d":557534,"h":197569053150,"f":4194337},{"t":1310721,"n":"StateOrProvince","d":557534,"h":201864020446,"f":4194337},{"t":1310721,"n":"StreetAddress","d":557534,"h":206158987742,"f":4194337},{"t":1310721,"n":"Surname","d":557534,"h":210453955038,"f":4194337},{"t":1310721,"n":"System","d":557534,"h":214748922334,"f":4194337},{"t":1310721,"n":"Thumbprint","d":557534,"h":219043889630,"f":4194337},{"t":1310721,"n":"Upn","d":557534,"h":223338856926,"f":4194337},{"t":1310721,"n":"Uri","d":557534,"h":227633824222,"f":4194337},{"t":1310721,"n":"Webpage","d":557534,"h":231928791518,"f":4194337},{"t":1310721,"n":"X500DistinguishedName","d":557534,"h":236223758814,"f":4194337},{"t":1310721,"n":"ClaimType2009Namespace","d":557534,"h":240518726110,"f":4194344},{"t":1310721,"n":"Actor","d":557534,"h":244813693406,"f":4194337}],"h":557534}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `System.Security.Claims.ClaimTypes`; }
        });
        
        $asm.$cls("$ssc.System.SR", ($self) => class SR
        {
            /*global::System.Resources.ResourceManager*/ static s_resourceManager = null;
            /*global::System.Globalization.CultureInfo*/ static resourceCulture = null;
            static /*global::System.Resources.ResourceManager */ get ResourceManager()
            {
                if ($.$$.System.Object.ReferenceEquals($.$ssc.System.SR.s_resourceManager, null))
                {
                    /*global::System.Resources.ResourceManager*/ let temp = new $.$$.System.Resources.ResourceManager().$ctor$3("System.Security.Claims", $.$ssc.System.SR.$type.Assembly);
                    $.$ssc.System.SR.s_resourceManager = temp;
                }
                return $.$ssc.System.SR.s_resourceManager;
            }
            static /*global::System.Globalization.CultureInfo */ get Culture()
            {
                return $.$ssc.System.SR.resourceCulture;
            }
            static /*global::System.Globalization.CultureInfo */ set Culture(value)
            {
                $.$ssc.System.SR.resourceCulture = value;
            }
            static /*string */ get ArgumentException_StringComparisonCultureAware()
            {
                return "The StringComparison must be one of Ordinal, OrdinalIgnoreCase, InvariantCulture, InvariantCultureIgnoreCase.";
            }
            static /*string */ get InvalidOperation_ClaimCannotBeRemoved()
            {
                return "The Claim '{0}' was not able to be removed.  It is either not part of this Identity or it is a Claim that is owned by the Principal that contains this Identity. For example, the Principal will own the Claim when creating a GenericPrincipal with roles. The roles will be exposed through the Identity that is passed in the constructor, but not actually owned by the Identity.  Similar logic exists for a RolePrincipal.";
            }
            static /*string */ FormatInvalidOperation_ClaimCannotBeRemoved(/*object*/ arg1)
            {
                return $.$$.System.String.Format$9("The Claim '{0}' was not able to be removed.  It is either not part of this Identity or it is a Claim that is owned by the Principal that contains this Identity. For example, the Principal will own the Claim when creating a GenericPrincipal with roles. The roles will be exposed through the Identity that is passed in the constructor, but not actually owned by the Identity.  Similar logic exists for a RolePrincipal.", arg1);
            }
            static /*string */ get InvalidOperationException_ActorGraphCircular()
            {
                return "An Actor must not create a circular reference between itself (or one of its child Actors) and one of its parents.";
            }
            static /*string */ get PlatformNotSupported_Serialization()
            {
                return "This instance contains state that cannot be serialized and deserialized on this platform.";
            }
            /*bool*/ static s_usingResourceKeys = false;
            static /*bool */ GetUsingResourceKeysSwitchValue()
            {
                /*bool*/ let usingResourceKeys;
                return $.$$.System.AppContext.TryGetSwitch("System.Resources.UseSystemResourceKeys", $.$ref(() => usingResourceKeys, ($v) => usingResourceKeys = $v, $.$$.System.Boolean)) ? usingResourceKeys : false;
            }
            static /*bool */ UsingResourceKeys()
            {
                return $.$ssc.System.SR.s_usingResourceKeys;
            }
            static /*string */ GetResourceString$1(/*string*/ resourceKey)
            {
                if ($.$ssc.System.SR.UsingResourceKeys())
                {
                    return resourceKey;
                }
                /*string?*/ let resourceString = null;
                try
                {
                    resourceString = $.$ssc.System.SR.ResourceManager.GetString$1(resourceKey);
                }
                catch($e)
                {
                }
                return resourceString;
            }
            static /*string */ GetResourceString(/*string*/ resourceKey, /*string*/ defaultString)
            {
                /*string*/ let resourceString = $.$ssc.System.SR.GetResourceString$1(resourceKey);
                return $.$$.System.String.op_Equality(resourceKey, resourceString) || $.$$.System.String.op_Equality(resourceString, null) ? defaultString : resourceString;
            }
            static /*string */ Format$6(/*string*/ resourceFormat, /*object?*/ p1)
            {
                if ($.$ssc.System.SR.UsingResourceKeys())
                {
                    return $.$$.System.String.Join$7(", ", $.$$.System.ReadOnlySpan$$($.$$.System.Object).op_Implicit$1([ resourceFormat, p1 ]));
                }
                return $.$$.System.String.Format$9(resourceFormat, p1);
            }
            static /*string */ Format$5(/*string*/ resourceFormat, /*object?*/ p1, /*object?*/ p2)
            {
                if ($.$ssc.System.SR.UsingResourceKeys())
                {
                    return $.$$.System.String.Join$7(", ", $.$$.System.ReadOnlySpan$$($.$$.System.Object).op_Implicit$1([ resourceFormat, p1, p2 ]));
                }
                return $.$$.System.String.Format$8(resourceFormat, p1, p2);
            }
            static /*string */ Format$4(/*string*/ resourceFormat, /*object?*/ p1, /*object?*/ p2, /*object?*/ p3)
            {
                if ($.$ssc.System.SR.UsingResourceKeys())
                {
                    return $.$$.System.String.Join$7(", ", $.$$.System.ReadOnlySpan$$($.$$.System.Object).op_Implicit$1([ resourceFormat, p1, p2, p3 ]));
                }
                return $.$$.System.String.Format$7(resourceFormat, p1, p2, p3);
            }
            static /*string */ Format$7(/*string*/ resourceFormat, /*params object?[]?*/ args)
            {
                if (args !== null)
                {
                    if ($.$ssc.System.SR.UsingResourceKeys())
                    {
                        return resourceFormat + ", " + $.$$.System.String.Join$6(", ", args);
                    }
                    return $.$$.System.String.Format$10(resourceFormat, args);
                }
                return resourceFormat;
            }
            static /*string */ Format$2(/*IFormatProvider?*/ provider, /*string*/ resourceFormat, /*object?*/ p1)
            {
                if ($.$ssc.System.SR.UsingResourceKeys())
                {
                    return $.$$.System.String.Join$7(", ", $.$$.System.ReadOnlySpan$$($.$$.System.Object).op_Implicit$1([ resourceFormat, p1 ]));
                }
                return $.$$.System.String.Format$2(provider, resourceFormat, p1);
            }
            static /*string */ Format$1(/*IFormatProvider?*/ provider, /*string*/ resourceFormat, /*object?*/ p1, /*object?*/ p2)
            {
                if ($.$ssc.System.SR.UsingResourceKeys())
                {
                    return $.$$.System.String.Join$7(", ", $.$$.System.ReadOnlySpan$$($.$$.System.Object).op_Implicit$1([ resourceFormat, p1, p2 ]));
                }
                return $.$$.System.String.Format$1(provider, resourceFormat, p1, p2);
            }
            static /*string */ Format(/*IFormatProvider?*/ provider, /*string*/ resourceFormat, /*object?*/ p1, /*object?*/ p2, /*object?*/ p3)
            {
                if ($.$ssc.System.SR.UsingResourceKeys())
                {
                    return $.$$.System.String.Join$7(", ", $.$$.System.ReadOnlySpan$$($.$$.System.Object).op_Implicit$1([ resourceFormat, p1, p2, p3 ]));
                }
                return $.$$.System.String.Format(provider, resourceFormat, p1, p2, p3);
            }
            static /*string */ Format$3(/*IFormatProvider?*/ provider, /*string*/ resourceFormat, /*params object?[]?*/ args)
            {
                if (args !== null)
                {
                    if ($.$ssc.System.SR.UsingResourceKeys())
                    {
                        return resourceFormat + ", " + $.$$.System.String.Join$6(", ", args);
                    }
                    return $.$$.System.String.Format$3(provider, resourceFormat, args);
                }
                return resourceFormat;
            }
            //Static Initializer
            static $sinit()
            {
                {
                    this.s_usingResourceKeys = $.$ssc.System.SR.GetUsingResourceKeysSwitchValue();
                }
            }
            static $h = 819678;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"h":819678}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `System.SR`; }
        });
        
        $asm.$cls("$ssc.System.Security.Claims.Claim", ($self) => class Claim extends $.$$.System.Object
        {
            static $_SerializationMask;
            static get SerializationMask()
            {
                let $cls = $.$ssc.System.Security.Claims.Claim;
                return $cls.$_SerializationMask ??= $asm.$nstr("$ssc.System.Security.Claims.Claim.SerializationMask", ($self) => class SerializationMask extends $.$$.System.Enum
                {
                    static None = 0;
                    static NameClaimType = 1;
                    static RoleClaimType = 2;
                    static StringType = 4;
                    static Issuer = 8;
                    static OriginalIssuerEqualsIssuer = 16;
                    static OriginalIssuer = 32;
                    static HasProperties = 64;
                    static UserData = 128;
                    static $map;
                    static get Map()
                    {
                        return this.$map ??= 
                        {
                            "None": 0n,
                            "NameClaimType": 1n,
                            "RoleClaimType": 2n,
                            "StringType": 4n,
                            "Issuer": 8n,
                            "OriginalIssuerEqualsIssuer": 16n,
                            "OriginalIssuer": 32n,
                            "HasProperties": 64n,
                            "UserData": 128n
                        };
                    }
                    static $h = 229854;
                    static $z = 4;
                    static $f = 0b110000011010001000;
                    static $k = 4;
                    static get $eut() { return $.$$.System.Int32; }
                    static $$md;
                    static get $md() { return this.$$md ??= {"b":1048577,"u":655361,"l":[{"t":229854,"n":"None","d":229854,"h":4295197150,"f":4194337},{"t":229854,"n":"NameClaimType","d":229854,"h":8590164446,"f":4194337},{"t":229854,"n":"RoleClaimType","d":229854,"h":12885131742,"f":4194337},{"t":229854,"n":"StringType","d":229854,"h":17180099038,"f":4194337},{"t":229854,"n":"Issuer","d":229854,"h":21475066334,"f":4194337},{"t":229854,"n":"OriginalIssuerEqualsIssuer","d":229854,"h":25770033630,"f":4194337},{"t":229854,"n":"OriginalIssuer","d":229854,"h":30065000926,"f":4194337},{"t":229854,"n":"HasProperties","d":229854,"h":34359968222,"f":4194337},{"t":229854,"n":"UserData","d":229854,"h":38654935518,"f":4194337}],"c":[{"n":".ctor","o":"$ctor$3","d":229854,"h":42949902814,"f":16777217}],"i":[57278465,63832065,57737217,57409537],"d":164318,"h":229854}; }
                    static get $b() { return $.$$.System.Enum; }
                    static $$i;
                    static get $i() { return this.$$i ??= [ $.$$.System.IComparable, $.$$.System.ISpanFormattable, $.$$.System.IFormattable, $.$$.System.IConvertible ]; }
                    static get $fullName() { return `System.Security.Claims.Claim.SerializationMask`; }
                }, $cls, ($v) => $cls.$_SerializationMask = $v);
            }
            /*byte[]?*/ _userSerializationData = null;
            /*string*/ _issuer = null;
            /*string*/ _originalIssuer = null;
            /*Dictionary<string, string>?*/ _properties = null;
            /*ClaimsIdentity?*/ _subject = null;
            /*string*/ _type = null;
            /*string*/ _value = null;
            /*string*/ _valueType = null;
            $ctor$2(/*BinaryReader*/ reader)
            {
                this.$ctor$1(reader, null);
                {
                }
                return this;
            }
            $ctor$1(/*BinaryReader*/ reader, /*ClaimsIdentity?*/ subject)
            {
                super.$ctor();
                {
                    $.$$.System.ArgumentNullException.ThrowIfNull$2(reader, "reader");
                    this._subject = subject;
                    /*SerializationMask*/ let mask = $.$cast(reader.ReadInt32(), $.$ssc.System.Security.Claims.Claim.SerializationMask);
                    /*int*/ let numPropertiesRead = 1;
                    /*int*/ let numPropertiesToRead = reader.ReadInt32();
                    this._value = reader.ReadString();
                    if ((mask & 1/*SerializationMask.NameClaimType*/) === 1/*SerializationMask.NameClaimType*/)
                    {
                        this._type = "http://schemas.xmlsoap.org/ws/2005/05/identity/claims/name"/*ClaimsIdentity.DefaultNameClaimType*/;
                    }
                    else if ((mask & 2/*SerializationMask.RoleClaimType*/) === 2/*SerializationMask.RoleClaimType*/)
                    {
                        this._type = "http://schemas.microsoft.com/ws/2008/06/identity/claims/role"/*ClaimsIdentity.DefaultRoleClaimType*/;
                    }
                    else 
                    {
                        this._type = reader.ReadString();
                        numPropertiesRead++;
                    }
                    if ((mask & 4/*SerializationMask.StringType*/) === 4/*SerializationMask.StringType*/)
                    {
                        this._valueType = reader.ReadString();
                        numPropertiesRead++;
                    }
                    else 
                    {
                        this._valueType = "http://www.w3.org/2001/XMLSchema#string"/*ClaimValueTypes.String*/;
                    }
                    if ((mask & 8/*SerializationMask.Issuer*/) === 8/*SerializationMask.Issuer*/)
                    {
                        this._issuer = reader.ReadString();
                        numPropertiesRead++;
                    }
                    else 
                    {
                        this._issuer = "LOCAL AUTHORITY"/*ClaimsIdentity.DefaultIssuer*/;
                    }
                    if ((mask & 16/*SerializationMask.OriginalIssuerEqualsIssuer*/) === 16/*SerializationMask.OriginalIssuerEqualsIssuer*/)
                    {
                        this._originalIssuer = this._issuer;
                    }
                    else if ((mask & 32/*SerializationMask.OriginalIssuer*/) === 32/*SerializationMask.OriginalIssuer*/)
                    {
                        this._originalIssuer = reader.ReadString();
                        numPropertiesRead++;
                    }
                    else 
                    {
                        this._originalIssuer = "LOCAL AUTHORITY"/*ClaimsIdentity.DefaultIssuer*/;
                    }
                    if ((mask & 64/*SerializationMask.HasProperties*/) === 64/*SerializationMask.HasProperties*/)
                    {
                        /*int*/ let numProperties = reader.ReadInt32();
                        numPropertiesRead++;
                        for(/*int*/ let i = 0; i < numProperties; i++)
                        {
                            this.Properties.System$Collections$Generic$IDictionary$$$$Add(reader.ReadString(), reader.ReadString(), [$.$$.System.String, $.$$.System.String]);
                        }
                    }
                    if ((mask & 128/*SerializationMask.UserData*/) === 128/*SerializationMask.UserData*/)
                    {
                        /*int*/ let cb = reader.ReadInt32();
                        this._userSerializationData = reader.ReadBytes(cb);
                        numPropertiesRead++;
                    }
                    for(/*int*/ let i = numPropertiesRead; i < numPropertiesToRead; i++)
                    {
                        reader.ReadString();
                    }
                }
                return this;
            }
            $ctor$8(/*string*/ type, /*string*/ value)
            {
                this.$ctor$4(type, value, "http://www.w3.org/2001/XMLSchema#string"/*ClaimValueTypes.String*/, "LOCAL AUTHORITY"/*ClaimsIdentity.DefaultIssuer*/, "LOCAL AUTHORITY"/*ClaimsIdentity.DefaultIssuer*/, null);
                {
                }
                return this;
            }
            $ctor$7(/*string*/ type, /*string*/ value, /*string?*/ valueType)
            {
                this.$ctor$4(type, value, valueType, "LOCAL AUTHORITY"/*ClaimsIdentity.DefaultIssuer*/, "LOCAL AUTHORITY"/*ClaimsIdentity.DefaultIssuer*/, null);
                {
                }
                return this;
            }
            $ctor$6(/*string*/ type, /*string*/ value, /*string?*/ valueType, /*string?*/ issuer)
            {
                this.$ctor$4(type, value, valueType, issuer, issuer, null);
                {
                }
                return this;
            }
            $ctor$5(/*string*/ type, /*string*/ value, /*string?*/ valueType, /*string?*/ issuer, /*string?*/ originalIssuer)
            {
                this.$ctor$4(type, value, valueType, issuer, originalIssuer, null);
                {
                }
                return this;
            }
            $ctor$4(/*string*/ type, /*string*/ value, /*string?*/ valueType, /*string?*/ issuer, /*string?*/ originalIssuer, /*ClaimsIdentity?*/ subject)
            {
                this.$ctor$3(type, value, valueType, issuer, originalIssuer, subject, null, null);
                {
                }
                return this;
            }
            $ctor$3(/*string*/ type, /*string*/ value, /*string?*/ valueType, /*string?*/ issuer, /*string?*/ originalIssuer, /*ClaimsIdentity?*/ subject, /*string?*/ propertyKey, /*string?*/ propertyValue)
            {
                super.$ctor();
                {
                    $.$$.System.ArgumentNullException.ThrowIfNull$2(type, "type");
                    $.$$.System.ArgumentNullException.ThrowIfNull$2(value, "value");
                    this._type = type;
                    this._value = value;
                    this._valueType = $.$$.System.String.IsNullOrEmpty(valueType) ? "http://www.w3.org/2001/XMLSchema#string"/*ClaimValueTypes.String*/ : valueType;
                    this._issuer = $.$$.System.String.IsNullOrEmpty(issuer) ? "LOCAL AUTHORITY"/*ClaimsIdentity.DefaultIssuer*/ : issuer;
                    this._originalIssuer = $.$$.System.String.IsNullOrEmpty(originalIssuer) ? this._issuer : originalIssuer;
                    this._subject = subject;
                    if ($.$$.System.String.op_Inequality(propertyKey, null))
                    {
                        this._properties = new ($.$$.System.Collections.Generic.Dictionary$$$($.$$.System.String, $.$$.System.String))().$ctor$1();
                        this._properties.set_Item(propertyKey, propertyValue);
                    }
                }
                return this;
            }
            $ctor$10(/*Claim*/ other)
            {
                this.$ctor$9(other, (other === null ? null : other._subject));
                {
                }
                return this;
            }
            $ctor$9(/*Claim*/ other, /*ClaimsIdentity?*/ subject)
            {
                super.$ctor();
                {
                    $.$$.System.ArgumentNullException.ThrowIfNull$2(other, "other");
                    this._issuer = other._issuer;
                    this._originalIssuer = other._originalIssuer;
                    this._subject = subject;
                    this._type = other._type;
                    this._value = other._value;
                    this._valueType = other._valueType;
                    if (other._properties !== null)
                    {
                        this._properties = new ($.$$.System.Collections.Generic.Dictionary$$$($.$$.System.String, $.$$.System.String))().$ctor$3(other._properties);
                    }
                    if (other._userSerializationData !== null)
                    {
                        this._userSerializationData = $.$as(other._userSerializationData.Clone(), $.$typeArray($.$$.System.Byte));
                    }
                }
                return this;
            }
            /*byte[]? */ get CustomSerializationData()
            {
                return this._userSerializationData;
            }
            /*string */ get Issuer()
            {
                return this._issuer;
            }
            /*string */ get OriginalIssuer()
            {
                return this._originalIssuer;
            }
            /*IDictionary<string, string> */ get Properties()
            {
                return this._properties ??= new ($.$$.System.Collections.Generic.Dictionary$$$($.$$.System.String, $.$$.System.String))().$ctor$1();
            }
            /*ClaimsIdentity? */ get Subject()
            {
                return this._subject;
            }
            /*string */ get Type()
            {
                return this._type;
            }
            /*string */ get Value()
            {
                return this._value;
            }
            /*string */ get ValueType()
            {
                return this._valueType;
            }
            /*Claim */ Clone()
            {
                return this.Clone$1(null);
            }
            /*Claim */ Clone$1(/*ClaimsIdentity?*/ identity)
            {
                return new $.$ssc.System.Security.Claims.Claim().$ctor$9(this, identity);
            }
            /*void */ WriteTo$1(/*BinaryWriter*/ writer)
            {
                this.WriteTo(writer, null);
            }
            /*void */ WriteTo(/*BinaryWriter*/ writer, /*byte[]?*/ userData)
            {
                $.$$.System.ArgumentNullException.ThrowIfNull$2(writer, "writer");
                /*int*/ let numberOfPropertiesWritten = 1;
                /*SerializationMask*/ let mask = 0/*SerializationMask.None*/;
                if ($.$$.System.String.Equals$3(this._type, "http://schemas.xmlsoap.org/ws/2005/05/identity/claims/name"/*ClaimsIdentity.DefaultNameClaimType*/))
                {
                    mask |= 1/*SerializationMask.NameClaimType*/;
                }
                else if ($.$$.System.String.Equals$3(this._type, "http://schemas.microsoft.com/ws/2008/06/identity/claims/role"/*ClaimsIdentity.DefaultRoleClaimType*/))
                {
                    mask |= 2/*SerializationMask.RoleClaimType*/;
                }
                else 
                {
                    numberOfPropertiesWritten++;
                }
                if (!$.$$.System.String.Equals$2(this._valueType, "http://www.w3.org/2001/XMLSchema#string"/*ClaimValueTypes.String*/, 4/*StringComparison.Ordinal*/))
                {
                    numberOfPropertiesWritten++;
                    mask |= 4/*SerializationMask.StringType*/;
                }
                if (!$.$$.System.String.Equals$2(this._issuer, "LOCAL AUTHORITY"/*ClaimsIdentity.DefaultIssuer*/, 4/*StringComparison.Ordinal*/))
                {
                    numberOfPropertiesWritten++;
                    mask |= 8/*SerializationMask.Issuer*/;
                }
                if ($.$$.System.String.Equals$2(this._originalIssuer, this._issuer, 4/*StringComparison.Ordinal*/))
                {
                    mask |= 16/*SerializationMask.OriginalIssuerEqualsIssuer*/;
                }
                else if (!$.$$.System.String.Equals$3(this._originalIssuer, "LOCAL AUTHORITY"/*ClaimsIdentity.DefaultIssuer*/))
                {
                    numberOfPropertiesWritten++;
                    mask |= 32/*SerializationMask.OriginalIssuer*/;
                }
                if (this._properties !== null && this._properties.Count > 0)
                {
                    numberOfPropertiesWritten++;
                    mask |= 64/*SerializationMask.HasProperties*/;
                }
                if (userData !== null && userData.length > 0)
                {
                    numberOfPropertiesWritten++;
                    mask |= 128/*SerializationMask.UserData*/;
                }
                writer.Write$11(mask);
                writer.Write$11(numberOfPropertiesWritten);
                writer.Write$17(this._value);
                if (((mask & 1/*SerializationMask.NameClaimType*/) !== 1/*SerializationMask.NameClaimType*/) && ((mask & 2/*SerializationMask.RoleClaimType*/) !== 2/*SerializationMask.RoleClaimType*/))
                {
                    writer.Write$17(this._type);
                }
                if ((mask & 4/*SerializationMask.StringType*/) === 4/*SerializationMask.StringType*/)
                {
                    writer.Write$17(this._valueType);
                }
                if ((mask & 8/*SerializationMask.Issuer*/) === 8/*SerializationMask.Issuer*/)
                {
                    writer.Write$17(this._issuer);
                }
                if ((mask & 32/*SerializationMask.OriginalIssuer*/) === 32/*SerializationMask.OriginalIssuer*/)
                {
                    writer.Write$17(this._originalIssuer);
                }
                if ((mask & 64/*SerializationMask.HasProperties*/) === 64/*SerializationMask.HasProperties*/)
                {
                    writer.Write$11(this._properties.Count);
                    var $en3 = this._properties.GetEnumerator();
                    while ($en3.MoveNext())
                    {
                        var kvp = $en3.Current;
                        {
                            writer.Write$17(kvp.Key);
                            writer.Write$17(kvp.Value);
                        }
                    }
                }
                if ((mask & 128/*SerializationMask.UserData*/) === 128/*SerializationMask.UserData*/)
                {
                    writer.Write$11(userData.length);
                    writer.Write$3(userData);
                }
                writer.Flush();
            }
            static/*conventional*/ /*string */ ToString()
            {
                return this._type + ": " + this._value;
            }
            //Static convention instance redirect
            /*string */ ToString() { return $.$ssc.System.Security.Claims.Claim.ToString.apply(this, arguments); }
            static $h = 164318;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":$.$typeArray($.$$.System.Byte).$h,"g":{"r":0,"d":0,"h":90194477534,"f":50331780},"n":"CustomSerializationData","d":164318,"h":85899510238,"f":2097284},{"p":1310721,"g":{"r":0,"d":0,"h":98784412126,"f":50331649},"n":"Issuer","d":164318,"h":94489444830,"f":2097153},{"p":1310721,"g":{"r":0,"d":0,"h":107374346718,"f":50331649},"n":"OriginalIssuer","d":164318,"h":103079379422,"f":2097153},{"p":$.$$.System.Collections.Generic.IDictionary$$$($.$$.System.String, $.$$.System.String).$h,"g":{"r":0,"d":0,"h":115964281310,"f":50331649},"n":"Properties","d":164318,"h":111669314014,"f":2097153},{"p":295390,"g":{"r":0,"d":0,"h":124554215902,"f":50331649},"n":"Subject","d":164318,"h":120259248606,"f":2097153},{"p":1310721,"g":{"r":0,"d":0,"h":133144150494,"f":50331649},"n":"Type","d":164318,"h":128849183198,"f":2097153},{"p":1310721,"g":{"r":0,"d":0,"h":141734085086,"f":50331649},"n":"Value","d":164318,"h":137439117790,"f":2097153},{"p":1310721,"g":{"r":0,"d":0,"h":150324019678,"f":50331649},"n":"ValueType","d":164318,"h":146029052382,"f":2097153}],"m":[{"r":164318,"n":"Clone","d":164318,"h":154618986974,"f":16777345},{"r":164318,"p":[{"n":"identity","p":295390}],"n":"Clone","o":"@$1","d":164318,"h":158913954270,"f":16777345},{"r":65537,"p":[{"n":"writer","p":58523649}],"n":"WriteTo","o":"@$1","d":164318,"h":163208921566,"f":16777345},{"r":65537,"p":[{"n":"writer","p":58523649},{"n":"userData","p":$.$typeArray($.$$.System.Byte).$h}],"n":"WriteTo","d":164318,"h":167503888862,"f":16777348},{"r":1310721,"n":"ToString","d":164318,"h":171798856158,"f":16809985}],"l":[{"t":$.$typeArray($.$$.System.Byte).$h,"n":"_userSerializationData","d":164318,"h":8590098910,"f":4194306},{"t":1310721,"n":"_issuer","d":164318,"h":12885066206,"f":4194306},{"t":1310721,"n":"_originalIssuer","d":164318,"h":17180033502,"f":4194306},{"t":$.$$.System.Collections.Generic.Dictionary$$$($.$$.System.String, $.$$.System.String).$h,"n":"_properties","d":164318,"h":21475000798,"f":4194306},{"t":295390,"n":"_subject","d":164318,"h":25769968094,"f":4194306},{"t":1310721,"n":"_type","d":164318,"h":30064935390,"f":4194306},{"t":1310721,"n":"_value","d":164318,"h":34359902686,"f":4194306},{"t":1310721,"n":"_valueType","d":164318,"h":38654869982,"f":4194306}],"c":[{"p":[{"n":"reader","p":58458113}],"n":".ctor","o":"$ctor$2","d":164318,"h":42949837278,"f":16777217},{"p":[{"n":"reader","p":58458113},{"n":"subject","p":295390}],"n":".ctor","o":"$ctor$1","d":164318,"h":47244804574,"f":16777217},{"p":[{"n":"type","p":1310721},{"n":"value","p":1310721}],"n":".ctor","o":"$ctor$8","d":164318,"h":51539771870,"f":16777217},{"p":[{"n":"type","p":1310721},{"n":"value","p":1310721},{"n":"valueType","p":1310721}],"n":".ctor","o":"$ctor$7","d":164318,"h":55834739166,"f":16777217},{"p":[{"n":"type","p":1310721},{"n":"value","p":1310721},{"n":"valueType","p":1310721},{"n":"issuer","p":1310721}],"n":".ctor","o":"$ctor$6","d":164318,"h":60129706462,"f":16777217},{"p":[{"n":"type","p":1310721},{"n":"value","p":1310721},{"n":"valueType","p":1310721},{"n":"issuer","p":1310721},{"n":"originalIssuer","p":1310721}],"n":".ctor","o":"$ctor$5","d":164318,"h":64424673758,"f":16777217},{"p":[{"n":"type","p":1310721},{"n":"value","p":1310721},{"n":"valueType","p":1310721},{"n":"issuer","p":1310721},{"n":"originalIssuer","p":1310721},{"n":"subject","p":295390}],"n":".ctor","o":"$ctor$4","d":164318,"h":68719641054,"f":16777217},{"p":[{"n":"type","p":1310721},{"n":"value","p":1310721},{"n":"valueType","p":1310721},{"n":"issuer","p":1310721},{"n":"originalIssuer","p":1310721},{"n":"subject","p":295390},{"n":"propertyKey","p":1310721},{"n":"propertyValue","p":1310721}],"n":".ctor","o":"$ctor$3","d":164318,"h":73014608350,"f":16777224},{"p":[{"n":"other","p":164318}],"n":".ctor","o":"$ctor$10","d":164318,"h":77309575646,"f":16777220},{"p":[{"n":"other","p":164318},{"n":"subject","p":295390}],"n":".ctor","o":"$ctor$9","d":164318,"h":81604542942,"f":16777220}],"j":[229854],"h":164318}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `System.Security.Claims.Claim`; }
        });
        
        $asm.$cls("$ssc.System.Security.Claims.ClaimValueTypes", ($self) => class ClaimValueTypes
        {
            /*string*/ static XmlSchemaNamespace = null;
            /*string*/ static Base64Binary = null;
            /*string*/ static Base64Octet = null;
            /*string*/ static Boolean = null;
            /*string*/ static Date = null;
            /*string*/ static DateTime = null;
            /*string*/ static Double = null;
            /*string*/ static Fqbn = null;
            /*string*/ static HexBinary = null;
            /*string*/ static Integer = null;
            /*string*/ static Integer32 = null;
            /*string*/ static Integer64 = null;
            /*string*/ static Sid = null;
            /*string*/ static String = null;
            /*string*/ static Time = null;
            /*string*/ static UInteger32 = null;
            /*string*/ static UInteger64 = null;
            /*string*/ static SoapSchemaNamespace = null;
            /*string*/ static DnsName = null;
            /*string*/ static Email = null;
            /*string*/ static Rsa = null;
            /*string*/ static UpnName = null;
            /*string*/ static XmlSignatureConstantsNamespace = null;
            /*string*/ static DsaKeyValue = null;
            /*string*/ static KeyInfo = null;
            /*string*/ static RsaKeyValue = null;
            /*string*/ static XQueryOperatorsNameSpace = null;
            /*string*/ static DaytimeDuration = null;
            /*string*/ static YearMonthDuration = null;
            /*string*/ static Xacml10Namespace = null;
            /*string*/ static Rfc822Name = null;
            /*string*/ static X500Name = null;
            //Static Initializer
            static $sinit()
            {
                {
                    this.XmlSchemaNamespace = "http://www.w3.org/2001/XMLSchema";
                }
                {
                    this.Base64Binary = "http://www.w3.org/2001/XMLSchema#base64Binary";
                }
                {
                    this.Base64Octet = "http://www.w3.org/2001/XMLSchema#base64Octet";
                }
                {
                    this.Boolean = "http://www.w3.org/2001/XMLSchema#boolean";
                }
                {
                    this.Date = "http://www.w3.org/2001/XMLSchema#date";
                }
                {
                    this.DateTime = "http://www.w3.org/2001/XMLSchema#dateTime";
                }
                {
                    this.Double = "http://www.w3.org/2001/XMLSchema#double";
                }
                {
                    this.Fqbn = "http://www.w3.org/2001/XMLSchema#fqbn";
                }
                {
                    this.HexBinary = "http://www.w3.org/2001/XMLSchema#hexBinary";
                }
                {
                    this.Integer = "http://www.w3.org/2001/XMLSchema#integer";
                }
                {
                    this.Integer32 = "http://www.w3.org/2001/XMLSchema#integer32";
                }
                {
                    this.Integer64 = "http://www.w3.org/2001/XMLSchema#integer64";
                }
                {
                    this.Sid = "http://www.w3.org/2001/XMLSchema#sid";
                }
                {
                    this.String = "http://www.w3.org/2001/XMLSchema#string";
                }
                {
                    this.Time = "http://www.w3.org/2001/XMLSchema#time";
                }
                {
                    this.UInteger32 = "http://www.w3.org/2001/XMLSchema#uinteger32";
                }
                {
                    this.UInteger64 = "http://www.w3.org/2001/XMLSchema#uinteger64";
                }
                {
                    this.SoapSchemaNamespace = "http://schemas.xmlsoap.org/";
                }
                {
                    this.DnsName = "http://schemas.xmlsoap.org/claims/dns";
                }
                {
                    this.Email = "http://schemas.xmlsoap.org/ws/2005/05/identity/claims/emailaddress";
                }
                {
                    this.Rsa = "http://schemas.xmlsoap.org/ws/2005/05/identity/claims/rsa";
                }
                {
                    this.UpnName = "http://schemas.xmlsoap.org/claims/UPN";
                }
                {
                    this.XmlSignatureConstantsNamespace = "http://www.w3.org/2000/09/xmldsig#";
                }
                {
                    this.DsaKeyValue = "http://www.w3.org/2000/09/xmldsig#DSAKeyValue";
                }
                {
                    this.KeyInfo = "http://www.w3.org/2000/09/xmldsig#KeyInfo";
                }
                {
                    this.RsaKeyValue = "http://www.w3.org/2000/09/xmldsig#RSAKeyValue";
                }
                {
                    this.XQueryOperatorsNameSpace = "http://www.w3.org/TR/2002/WD-xquery-operators-20020816";
                }
                {
                    this.DaytimeDuration = "http://www.w3.org/TR/2002/WD-xquery-operators-20020816#dayTimeDuration";
                }
                {
                    this.YearMonthDuration = "http://www.w3.org/TR/2002/WD-xquery-operators-20020816#yearMonthDuration";
                }
                {
                    this.Xacml10Namespace = "urn:oasis:names:tc:xacml:1.0";
                }
                {
                    this.Rfc822Name = "urn:oasis:names:tc:xacml:1.0:data-type:rfc822Name";
                }
                {
                    this.X500Name = "urn:oasis:names:tc:xacml:1.0:data-type:x500Name";
                }
            }
            static $h = 623070;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"l":[{"t":1310721,"n":"XmlSchemaNamespace","d":623070,"h":4295590366,"f":4194338},{"t":1310721,"n":"Base64Binary","d":623070,"h":8590557662,"f":4194337},{"t":1310721,"n":"Base64Octet","d":623070,"h":12885524958,"f":4194337},{"t":1310721,"n":"Boolean","d":623070,"h":17180492254,"f":4194337},{"t":1310721,"n":"Date","d":623070,"h":21475459550,"f":4194337},{"t":1310721,"n":"DateTime","d":623070,"h":25770426846,"f":4194337},{"t":1310721,"n":"Double","d":623070,"h":30065394142,"f":4194337},{"t":1310721,"n":"Fqbn","d":623070,"h":34360361438,"f":4194337},{"t":1310721,"n":"HexBinary","d":623070,"h":38655328734,"f":4194337},{"t":1310721,"n":"Integer","d":623070,"h":42950296030,"f":4194337},{"t":1310721,"n":"Integer32","d":623070,"h":47245263326,"f":4194337},{"t":1310721,"n":"Integer64","d":623070,"h":51540230622,"f":4194337},{"t":1310721,"n":"Sid","d":623070,"h":55835197918,"f":4194337},{"t":1310721,"n":"String","d":623070,"h":60130165214,"f":4194337},{"t":1310721,"n":"Time","d":623070,"h":64425132510,"f":4194337},{"t":1310721,"n":"UInteger32","d":623070,"h":68720099806,"f":4194337},{"t":1310721,"n":"UInteger64","d":623070,"h":73015067102,"f":4194337},{"t":1310721,"n":"SoapSchemaNamespace","d":623070,"h":77310034398,"f":4194338},{"t":1310721,"n":"DnsName","d":623070,"h":81605001694,"f":4194337},{"t":1310721,"n":"Email","d":623070,"h":85899968990,"f":4194337},{"t":1310721,"n":"Rsa","d":623070,"h":90194936286,"f":4194337},{"t":1310721,"n":"UpnName","d":623070,"h":94489903582,"f":4194337},{"t":1310721,"n":"XmlSignatureConstantsNamespace","d":623070,"h":98784870878,"f":4194338},{"t":1310721,"n":"DsaKeyValue","d":623070,"h":103079838174,"f":4194337},{"t":1310721,"n":"KeyInfo","d":623070,"h":107374805470,"f":4194337},{"t":1310721,"n":"RsaKeyValue","d":623070,"h":111669772766,"f":4194337},{"t":1310721,"n":"XQueryOperatorsNameSpace","d":623070,"h":115964740062,"f":4194338},{"t":1310721,"n":"DaytimeDuration","d":623070,"h":120259707358,"f":4194337},{"t":1310721,"n":"YearMonthDuration","d":623070,"h":124554674654,"f":4194337},{"t":1310721,"n":"Xacml10Namespace","d":623070,"h":128849641950,"f":4194338},{"t":1310721,"n":"Rfc822Name","d":623070,"h":133144609246,"f":4194337},{"t":1310721,"n":"X500Name","d":623070,"h":137439576542,"f":4194337}],"h":623070}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `System.Security.Claims.ClaimValueTypes`; }
        });
        
        $asm.$cls("$ssc.System.Obsoletions", ($self) => class Obsoletions
        {
            /*string*/ static SharedUrlFormat = null;
            /*string*/ static SystemTextEncodingUTF7Message = null;
            /*string*/ static SystemTextEncodingUTF7DiagId = null;
            /*string*/ static PrincipalPermissionAttributeMessage = null;
            /*string*/ static PrincipalPermissionAttributeDiagId = null;
            /*string*/ static CodeAccessSecurityMessage = null;
            /*string*/ static CodeAccessSecurityDiagId = null;
            /*string*/ static ConstrainedExecutionRegionMessage = null;
            /*string*/ static ConstrainedExecutionRegionDiagId = null;
            /*string*/ static GlobalAssemblyCacheMessage = null;
            /*string*/ static GlobalAssemblyCacheDiagId = null;
            /*string*/ static ThreadAbortMessage = null;
            /*string*/ static ThreadResetAbortMessage = null;
            /*string*/ static ThreadAbortDiagId = null;
            /*string*/ static DefaultCryptoAlgorithmsMessage = null;
            /*string*/ static DefaultCryptoAlgorithmsDiagId = null;
            /*string*/ static CreatePdbGeneratorMessage = null;
            /*string*/ static CreatePdbGeneratorDiagId = null;
            /*string*/ static AuthenticationManagerMessage = null;
            /*string*/ static AuthenticationManagerDiagId = null;
            /*string*/ static RemotingApisMessage = null;
            /*string*/ static RemotingApisDiagId = null;
            /*string*/ static BinaryFormatterMessage = null;
            /*string*/ static BinaryFormatterDiagId = null;
            /*string*/ static CodeBaseMessage = null;
            /*string*/ static CodeBaseDiagId = null;
            /*string*/ static EscapeUriStringMessage = null;
            /*string*/ static EscapeUriStringDiagId = null;
            /*string*/ static WebRequestMessage = null;
            /*string*/ static WebRequestDiagId = null;
            /*string*/ static DisablePrivateReflectionAttributeMessage = null;
            /*string*/ static DisablePrivateReflectionAttributeDiagId = null;
            /*string*/ static GetContextInfoMessage = null;
            /*string*/ static GetContextInfoDiagId = null;
            /*string*/ static StrongNameKeyPairMessage = null;
            /*string*/ static StrongNameKeyPairDiagId = null;
            /*string*/ static ReflectionOnlyLoadingMessage = null;
            /*string*/ static ReflectionOnlyLoadingDiagId = null;
            /*string*/ static RuntimeEnvironmentMessage = null;
            /*string*/ static RuntimeEnvironmentDiagId = null;
            /*string*/ static JsonSerializerOptionsIgnoreNullValuesMessage = null;
            /*string*/ static JsonSerializerOptionsIgnoreNullValuesDiagId = null;
            /*string*/ static DerivedCryptographicTypesMessage = null;
            /*string*/ static DerivedCryptographicTypesDiagId = null;
            /*string*/ static RijndaelMessage = null;
            /*string*/ static RijndaelDiagId = null;
            /*string*/ static RNGCryptoServiceProviderMessage = null;
            /*string*/ static RNGCryptoServiceProviderDiagId = null;
            /*string*/ static AppDomainCreateUnloadMessage = null;
            /*string*/ static AppDomainCreateUnloadDiagId = null;
            /*string*/ static SuppressIldasmAttributeMessage = null;
            /*string*/ static SuppressIldasmAttributeDiagId = null;
            /*string*/ static X509CertificateImmutableMessage = null;
            /*string*/ static X509CertificateImmutableDiagId = null;
            /*string*/ static PublicKeyPropertyMessage = null;
            /*string*/ static PublicKeyPropertyDiagId = null;
            /*string*/ static X509CertificatePrivateKeyMessage = null;
            /*string*/ static X509CertificatePrivateKeyDiagId = null;
            /*string*/ static ProduceLegacyHmacValuesMessage = null;
            /*string*/ static ProduceLegacyHmacValuesDiagId = null;
            /*string*/ static UseManagedSha1Message = null;
            /*string*/ static UseManagedSha1DiagId = null;
            /*string*/ static CryptoConfigEncodeOIDMessage = null;
            /*string*/ static CryptoConfigEncodeOIDDiagId = null;
            /*string*/ static CorruptedStateRecoveryMessage = null;
            /*string*/ static CorruptedStateRecoveryDiagId = null;
            /*string*/ static Rfc2898CryptDeriveKeyMessage = null;
            /*string*/ static Rfc2898CryptDeriveKeyDiagId = null;
            /*string*/ static CmsSignerCspParamsCtorMessage = null;
            /*string*/ static CmsSignerCspParamsCtorDiagId = null;
            /*string*/ static SignerInfoCounterSigMessage = null;
            /*string*/ static SignerInfoCounterSigDiagId = null;
            /*string*/ static RegexCompileToAssemblyMessage = null;
            /*string*/ static RegexCompileToAssemblyDiagId = null;
            /*string*/ static AssemblyNameMembersMessage = null;
            /*string*/ static AssemblyNameMembersDiagId = null;
            /*string*/ static SystemDataSerializationFormatBinaryMessage = null;
            /*string*/ static SystemDataSerializationFormatBinaryDiagId = null;
            /*string*/ static TlsVersion10and11Message = null;
            /*string*/ static TlsVersion10and11DiagId = null;
            /*string*/ static EncryptionPolicyMessage = null;
            /*string*/ static EncryptionPolicyDiagId = null;
            /*string*/ static EccXmlExportImportMessage = null;
            /*string*/ static EccXmlExportImportDiagId = null;
            /*string*/ static EcDhPublicKeyBlobMessage = null;
            /*string*/ static EcDhPublicKeyBlobDiagId = null;
            /*string*/ static AssemblyNameCodeBaseMessage = null;
            /*string*/ static AssemblyNameCodeBaseDiagId = null;
            /*string*/ static CryptoStringFactoryMessage = null;
            /*string*/ static CryptoStringFactoryDiagId = null;
            /*string*/ static ControlledExecutionRunMessage = null;
            /*string*/ static ControlledExecutionRunDiagId = null;
            /*string*/ static XmlSecureResolverMessage = null;
            /*string*/ static XmlSecureResolverDiagId = null;
            /*string*/ static RsaEncryptDecryptValueMessage = null;
            /*string*/ static RsaEncryptDecryptDiagId = null;
            /*string*/ static JsonSerializerOptionsAddContextMessage = null;
            /*string*/ static JsonSerializerOptionsAddContextDiagId = null;
            /*string*/ static LegacyFormatterMessage = null;
            /*string*/ static LegacyFormatterDiagId = null;
            /*string*/ static LegacyFormatterImplMessage = null;
            /*string*/ static LegacyFormatterImplDiagId = null;
            /*string*/ static RegexExtensibilityImplMessage = null;
            /*string*/ static RegexExtensibilityDiagId = null;
            /*string*/ static AesGcmTagConstructorMessage = null;
            /*string*/ static AesGcmTagConstructorDiagId = null;
            /*string*/ static ThreadVolatileReadWriteMessage = null;
            /*string*/ static ThreadVolatileReadWriteDiagId = null;
            /*string*/ static ArmIntrinsicPerformsUnsignedOperationMessage = null;
            /*string*/ static ArmIntrinsicPerformsUnsignedOperationDiagId = null;
            /*string*/ static LoadFromHashAlgorithmMessage = null;
            /*string*/ static LoadFromHashAlgorithmDiagId = null;
            /*string*/ static X509CtorCertDataObsoleteMessage = null;
            /*string*/ static X509CtorCertDataObsoleteDiagId = null;
            /*string*/ static TlsCipherAlgorithmEnumsMessage = null;
            /*string*/ static TlsCipherAlgorithmEnumsDiagId = null;
            /*string*/ static SystemEventsEventsThreadShutdownMessage = null;
            /*string*/ static SystemEventsEventsThreadShutdownDiagId = null;
            /*string*/ static Rfc2898DeriveBytesCtorMessage = null;
            /*string*/ static Rfc2898DeriveBytesCtorDiagId = null;
            /*string*/ static QueryableMinByMaxByTSourceObsoleteMessage = null;
            /*string*/ static QueryableMinByMaxByTSourceObsoleteDiagId = null;
            /*string*/ static XsltSettingsEnableScriptMessage = null;
            /*string*/ static XsltSettingsEnableScriptDiagId = null;
            //Static Initializer
            static $sinit()
            {
                {
                    this.SharedUrlFormat = "https://aka.ms/dotnet-warnings/{0}";
                }
                {
                    this.SystemTextEncodingUTF7Message = "The UTF-7 encoding is insecure and should not be used. Consider using UTF-8 instead.";
                }
                {
                    this.SystemTextEncodingUTF7DiagId = "SYSLIB0001";
                }
                {
                    this.PrincipalPermissionAttributeMessage = "PrincipalPermissionAttribute is not honored by the runtime and must not be used.";
                }
                {
                    this.PrincipalPermissionAttributeDiagId = "SYSLIB0002";
                }
                {
                    this.CodeAccessSecurityMessage = "Code Access Security is not supported or honored by the runtime.";
                }
                {
                    this.CodeAccessSecurityDiagId = "SYSLIB0003";
                }
                {
                    this.ConstrainedExecutionRegionMessage = "The Constrained Execution Region (CER) feature is not supported.";
                }
                {
                    this.ConstrainedExecutionRegionDiagId = "SYSLIB0004";
                }
                {
                    this.GlobalAssemblyCacheMessage = "The Global Assembly Cache is not supported.";
                }
                {
                    this.GlobalAssemblyCacheDiagId = "SYSLIB0005";
                }
                {
                    this.ThreadAbortMessage = "Thread.Abort is not supported and throws PlatformNotSupportedException.";
                }
                {
                    this.ThreadResetAbortMessage = "Thread.ResetAbort is not supported and throws PlatformNotSupportedException.";
                }
                {
                    this.ThreadAbortDiagId = "SYSLIB0006";
                }
                {
                    this.DefaultCryptoAlgorithmsMessage = "The default implementation of this cryptography algorithm is not supported.";
                }
                {
                    this.DefaultCryptoAlgorithmsDiagId = "SYSLIB0007";
                }
                {
                    this.CreatePdbGeneratorMessage = "The CreatePdbGenerator API is not supported and throws PlatformNotSupportedException.";
                }
                {
                    this.CreatePdbGeneratorDiagId = "SYSLIB0008";
                }
                {
                    this.AuthenticationManagerMessage = "AuthenticationManager is not supported. Methods will no-op or throw PlatformNotSupportedException.";
                }
                {
                    this.AuthenticationManagerDiagId = "SYSLIB0009";
                }
                {
                    this.RemotingApisMessage = "This Remoting API is not supported and throws PlatformNotSupportedException.";
                }
                {
                    this.RemotingApisDiagId = "SYSLIB0010";
                }
                {
                    this.BinaryFormatterMessage = "BinaryFormatter serialization is obsolete and should not be used. See https://aka.ms/binaryformatter for more information.";
                }
                {
                    this.BinaryFormatterDiagId = "SYSLIB0011";
                }
                {
                    this.CodeBaseMessage = "Assembly.CodeBase and Assembly.EscapedCodeBase are only included for .NET Framework compatibility. Use Assembly.Location instead.";
                }
                {
                    this.CodeBaseDiagId = "SYSLIB0012";
                }
                {
                    this.EscapeUriStringMessage = "Uri.EscapeUriString can corrupt the Uri string in some cases. Consider using Uri.EscapeDataString for query string components instead.";
                }
                {
                    this.EscapeUriStringDiagId = "SYSLIB0013";
                }
                {
                    this.WebRequestMessage = "WebRequest, HttpWebRequest, ServicePoint, and WebClient are obsolete. Use HttpClient instead.";
                }
                {
                    this.WebRequestDiagId = "SYSLIB0014";
                }
                {
                    this.DisablePrivateReflectionAttributeMessage = "DisablePrivateReflectionAttribute has no effect in .NET 6.0+.";
                }
                {
                    this.DisablePrivateReflectionAttributeDiagId = "SYSLIB0015";
                }
                {
                    this.GetContextInfoMessage = "Use the Graphics.GetContextInfo overloads that accept arguments for better performance and fewer allocations.";
                }
                {
                    this.GetContextInfoDiagId = "SYSLIB0016";
                }
                {
                    this.StrongNameKeyPairMessage = "Strong name signing is not supported and throws PlatformNotSupportedException.";
                }
                {
                    this.StrongNameKeyPairDiagId = "SYSLIB0017";
                }
                {
                    this.ReflectionOnlyLoadingMessage = "ReflectionOnly loading is not supported and throws PlatformNotSupportedException.";
                }
                {
                    this.ReflectionOnlyLoadingDiagId = "SYSLIB0018";
                }
                {
                    this.RuntimeEnvironmentMessage = "RuntimeEnvironment members SystemConfigurationFile, GetRuntimeInterfaceAsIntPtr, and GetRuntimeInterfaceAsObject are not supported and throw PlatformNotSupportedException.";
                }
                {
                    this.RuntimeEnvironmentDiagId = "SYSLIB0019";
                }
                {
                    this.JsonSerializerOptionsIgnoreNullValuesMessage = "JsonSerializerOptions.IgnoreNullValues is obsolete. To ignore null values when serializing, set DefaultIgnoreCondition to JsonIgnoreCondition.WhenWritingNull.";
                }
                {
                    this.JsonSerializerOptionsIgnoreNullValuesDiagId = "SYSLIB0020";
                }
                {
                    this.DerivedCryptographicTypesMessage = "Derived cryptographic types are obsolete. Use the Create method on the base type instead.";
                }
                {
                    this.DerivedCryptographicTypesDiagId = "SYSLIB0021";
                }
                {
                    this.RijndaelMessage = "The Rijndael and RijndaelManaged types are obsolete. Use Aes instead.";
                }
                {
                    this.RijndaelDiagId = "SYSLIB0022";
                }
                {
                    this.RNGCryptoServiceProviderMessage = "RNGCryptoServiceProvider is obsolete. To generate a random number, use one of the RandomNumberGenerator static methods instead.";
                }
                {
                    this.RNGCryptoServiceProviderDiagId = "SYSLIB0023";
                }
                {
                    this.AppDomainCreateUnloadMessage = "Creating and unloading AppDomains is not supported and throws an exception.";
                }
                {
                    this.AppDomainCreateUnloadDiagId = "SYSLIB0024";
                }
                {
                    this.SuppressIldasmAttributeMessage = "SuppressIldasmAttribute has no effect in .NET 6.0+.";
                }
                {
                    this.SuppressIldasmAttributeDiagId = "SYSLIB0025";
                }
                {
                    this.X509CertificateImmutableMessage = "X509Certificate and X509Certificate2 are immutable. Use X509CertificateLoader to create a new certificate.";
                }
                {
                    this.X509CertificateImmutableDiagId = "SYSLIB0026";
                }
                {
                    this.PublicKeyPropertyMessage = "PublicKey.Key is obsolete. Use the appropriate method to get the public key, such as GetRSAPublicKey.";
                }
                {
                    this.PublicKeyPropertyDiagId = "SYSLIB0027";
                }
                {
                    this.X509CertificatePrivateKeyMessage = "X509Certificate2.PrivateKey is obsolete. Use the appropriate method to get the private key, such as GetRSAPrivateKey, or use the CopyWithPrivateKey method to create a new instance with a private key.";
                }
                {
                    this.X509CertificatePrivateKeyDiagId = "SYSLIB0028";
                }
                {
                    this.ProduceLegacyHmacValuesMessage = "ProduceLegacyHmacValues is obsolete. Producing legacy HMAC values is not supported.";
                }
                {
                    this.ProduceLegacyHmacValuesDiagId = "SYSLIB0029";
                }
                {
                    this.UseManagedSha1Message = "HMACSHA1 always uses the algorithm implementation provided by the platform. Use a constructor without the useManagedSha1 parameter.";
                }
                {
                    this.UseManagedSha1DiagId = "SYSLIB0030";
                }
                {
                    this.CryptoConfigEncodeOIDMessage = "EncodeOID is obsolete. Use the ASN.1 functionality provided in System.Formats.Asn1.";
                }
                {
                    this.CryptoConfigEncodeOIDDiagId = "SYSLIB0031";
                }
                {
                    this.CorruptedStateRecoveryMessage = "Recovery from corrupted process state exceptions is not supported; HandleProcessCorruptedStateExceptionsAttribute is ignored.";
                }
                {
                    this.CorruptedStateRecoveryDiagId = "SYSLIB0032";
                }
                {
                    this.Rfc2898CryptDeriveKeyMessage = "Rfc2898DeriveBytes.CryptDeriveKey is obsolete and is not supported. Use PasswordDeriveBytes.CryptDeriveKey instead.";
                }
                {
                    this.Rfc2898CryptDeriveKeyDiagId = "SYSLIB0033";
                }
                {
                    this.CmsSignerCspParamsCtorMessage = "CmsSigner(CspParameters) is obsolete and is not supported. Use an alternative constructor instead.";
                }
                {
                    this.CmsSignerCspParamsCtorDiagId = "SYSLIB0034";
                }
                {
                    this.SignerInfoCounterSigMessage = "ComputeCounterSignature without specifying a CmsSigner is obsolete and is not supported. Use the overload that accepts a CmsSigner.";
                }
                {
                    this.SignerInfoCounterSigDiagId = "SYSLIB0035";
                }
                {
                    this.RegexCompileToAssemblyMessage = "Regex.CompileToAssembly is obsolete and not supported. Use the GeneratedRegexAttribute with the regular expression source generator instead.";
                }
                {
                    this.RegexCompileToAssemblyDiagId = "SYSLIB0036";
                }
                {
                    this.AssemblyNameMembersMessage = "AssemblyName members HashAlgorithm, ProcessorArchitecture, and VersionCompatibility are obsolete and not supported.";
                }
                {
                    this.AssemblyNameMembersDiagId = "SYSLIB0037";
                }
                {
                    this.SystemDataSerializationFormatBinaryMessage = "SerializationFormat.Binary is obsolete and should not be used. See https://aka.ms/serializationformat-binary-obsolete for more information.";
                }
                {
                    this.SystemDataSerializationFormatBinaryDiagId = "SYSLIB0038";
                }
                {
                    this.TlsVersion10and11Message = "TLS versions 1.0 and 1.1 have known vulnerabilities and are not recommended. Use a newer TLS version instead, or use SslProtocols.None to defer to OS defaults.";
                }
                {
                    this.TlsVersion10and11DiagId = "SYSLIB0039";
                }
                {
                    this.EncryptionPolicyMessage = "EncryptionPolicy.NoEncryption and AllowEncryption significantly reduce security and should not be used in production code.";
                }
                {
                    this.EncryptionPolicyDiagId = "SYSLIB0040";
                }
                {
                    this.EccXmlExportImportMessage = "ToXmlString and FromXmlString have no implementation for ECC types, and are obsolete. Use a standard import and export format such as ExportSubjectPublicKeyInfo or ImportSubjectPublicKeyInfo for public keys and ExportPkcs8PrivateKey or ImportPkcs8PrivateKey for private keys.";
                }
                {
                    this.EccXmlExportImportDiagId = "SYSLIB0042";
                }
                {
                    this.EcDhPublicKeyBlobMessage = "ECDiffieHellmanPublicKey.ToByteArray() and the associated constructor do not have a consistent and interoperable implementation on all platforms. Use ECDiffieHellmanPublicKey.ExportSubjectPublicKeyInfo() instead.";
                }
                {
                    this.EcDhPublicKeyBlobDiagId = "SYSLIB0043";
                }
                {
                    this.AssemblyNameCodeBaseMessage = "AssemblyName.CodeBase and AssemblyName.EscapedCodeBase are obsolete. Using them for loading an assembly is not supported.";
                }
                {
                    this.AssemblyNameCodeBaseDiagId = "SYSLIB0044";
                }
                {
                    this.CryptoStringFactoryMessage = "Cryptographic factory methods accepting an algorithm name are obsolete. Use the parameterless Create factory method on the algorithm type instead.";
                }
                {
                    this.CryptoStringFactoryDiagId = "SYSLIB0045";
                }
                {
                    this.ControlledExecutionRunMessage = "ControlledExecution.Run method may corrupt the process and should not be used in production code.";
                }
                {
                    this.ControlledExecutionRunDiagId = "SYSLIB0046";
                }
                {
                    this.XmlSecureResolverMessage = "XmlSecureResolver is obsolete. Use XmlResolver.ThrowingResolver instead when attempting to forbid XML external entity resolution.";
                }
                {
                    this.XmlSecureResolverDiagId = "SYSLIB0047";
                }
                {
                    this.RsaEncryptDecryptValueMessage = "RSA.EncryptValue and DecryptValue are not supported and throw NotSupportedException. Use RSA.Encrypt and RSA.Decrypt instead.";
                }
                {
                    this.RsaEncryptDecryptDiagId = "SYSLIB0048";
                }
                {
                    this.JsonSerializerOptionsAddContextMessage = "JsonSerializerOptions.AddContext is obsolete. To register a JsonSerializerContext, use either the TypeInfoResolver or TypeInfoResolverChain properties.";
                }
                {
                    this.JsonSerializerOptionsAddContextDiagId = "SYSLIB0049";
                }
                {
                    this.LegacyFormatterMessage = "Formatter-based serialization is obsolete and should not be used.";
                }
                {
                    this.LegacyFormatterDiagId = "SYSLIB0050";
                }
                {
                    this.LegacyFormatterImplMessage = "This API supports obsolete formatter-based serialization. It should not be called or extended by application code.";
                }
                {
                    this.LegacyFormatterImplDiagId = "SYSLIB0051";
                }
                {
                    this.RegexExtensibilityImplMessage = "This API supports obsolete mechanisms for Regex extensibility. It is not supported.";
                }
                {
                    this.RegexExtensibilityDiagId = "SYSLIB0052";
                }
                {
                    this.AesGcmTagConstructorMessage = "AesGcm should indicate the required tag size for encryption and decryption. Use a constructor that accepts the tag size.";
                }
                {
                    this.AesGcmTagConstructorDiagId = "SYSLIB0053";
                }
                {
                    this.ThreadVolatileReadWriteMessage = "Thread.VolatileRead and Thread.VolatileWrite are obsolete. Use Volatile.Read or Volatile.Write respectively instead.";
                }
                {
                    this.ThreadVolatileReadWriteDiagId = "SYSLIB0054";
                }
                {
                    this.ArmIntrinsicPerformsUnsignedOperationMessage = "The underlying hardware instruction does not perform a signed saturate narrowing operation, and it always returns an unsigned result. Use the unsigned overload instead.";
                }
                {
                    this.ArmIntrinsicPerformsUnsignedOperationDiagId = "SYSLIB0055";
                }
                {
                    this.LoadFromHashAlgorithmMessage = "LoadFrom with a custom AssemblyHashAlgorithm is obsolete. Use overloads without an AssemblyHashAlgorithm.";
                }
                {
                    this.LoadFromHashAlgorithmDiagId = "SYSLIB0056";
                }
                {
                    this.X509CtorCertDataObsoleteMessage = "Loading certificate data through the constructor or Import is obsolete. Use X509CertificateLoader instead to load certificates.";
                }
                {
                    this.X509CtorCertDataObsoleteDiagId = "SYSLIB0057";
                }
                {
                    this.TlsCipherAlgorithmEnumsMessage = "KeyExchangeAlgorithm, KeyExchangeStrength, CipherAlgorithm, CipherStrength, HashAlgorithm and HashStrength properties of SslStream are obsolete. Use NegotiatedCipherSuite instead.";
                }
                {
                    this.TlsCipherAlgorithmEnumsDiagId = "SYSLIB0058";
                }
                {
                    this.SystemEventsEventsThreadShutdownMessage = "SystemEvents.EventsThreadShutdown callbacks are not run before the process exits. Use AppDomain.ProcessExit instead.";
                }
                {
                    this.SystemEventsEventsThreadShutdownDiagId = "SYSLIB0059";
                }
                {
                    this.Rfc2898DeriveBytesCtorMessage = "The constructors on Rfc2898DeriveBytes are obsolete. Use the static Pbkdf2 method instead.";
                }
                {
                    this.Rfc2898DeriveBytesCtorDiagId = "SYSLIB0060";
                }
                {
                    this.QueryableMinByMaxByTSourceObsoleteMessage = "The Queryable MinBy and MaxBy taking an IComparer<TSource> are obsolete. Use the new ones that take an IComparer<TKey>.";
                }
                {
                    this.QueryableMinByMaxByTSourceObsoleteDiagId = "SYSLIB0061";
                }
                {
                    this.XsltSettingsEnableScriptMessage = "XSLT Script blocks are not supported.";
                }
                {
                    this.XsltSettingsEnableScriptDiagId = "SYSLIB0062";
                }
            }
            static $h = 98782;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"l":[{"t":1310721,"n":"SharedUrlFormat","d":98782,"h":4295066078,"f":4194344},{"t":1310721,"n":"SystemTextEncodingUTF7Message","d":98782,"h":8590033374,"f":4194344},{"t":1310721,"n":"SystemTextEncodingUTF7DiagId","d":98782,"h":12885000670,"f":4194344},{"t":1310721,"n":"PrincipalPermissionAttributeMessage","d":98782,"h":17179967966,"f":4194344},{"t":1310721,"n":"PrincipalPermissionAttributeDiagId","d":98782,"h":21474935262,"f":4194344},{"t":1310721,"n":"CodeAccessSecurityMessage","d":98782,"h":25769902558,"f":4194344},{"t":1310721,"n":"CodeAccessSecurityDiagId","d":98782,"h":30064869854,"f":4194344},{"t":1310721,"n":"ConstrainedExecutionRegionMessage","d":98782,"h":34359837150,"f":4194344},{"t":1310721,"n":"ConstrainedExecutionRegionDiagId","d":98782,"h":38654804446,"f":4194344},{"t":1310721,"n":"GlobalAssemblyCacheMessage","d":98782,"h":42949771742,"f":4194344},{"t":1310721,"n":"GlobalAssemblyCacheDiagId","d":98782,"h":47244739038,"f":4194344},{"t":1310721,"n":"ThreadAbortMessage","d":98782,"h":51539706334,"f":4194344},{"t":1310721,"n":"ThreadResetAbortMessage","d":98782,"h":55834673630,"f":4194344},{"t":1310721,"n":"ThreadAbortDiagId","d":98782,"h":60129640926,"f":4194344},{"t":1310721,"n":"DefaultCryptoAlgorithmsMessage","d":98782,"h":64424608222,"f":4194344},{"t":1310721,"n":"DefaultCryptoAlgorithmsDiagId","d":98782,"h":68719575518,"f":4194344},{"t":1310721,"n":"CreatePdbGeneratorMessage","d":98782,"h":73014542814,"f":4194344},{"t":1310721,"n":"CreatePdbGeneratorDiagId","d":98782,"h":77309510110,"f":4194344},{"t":1310721,"n":"AuthenticationManagerMessage","d":98782,"h":81604477406,"f":4194344},{"t":1310721,"n":"AuthenticationManagerDiagId","d":98782,"h":85899444702,"f":4194344},{"t":1310721,"n":"RemotingApisMessage","d":98782,"h":90194411998,"f":4194344},{"t":1310721,"n":"RemotingApisDiagId","d":98782,"h":94489379294,"f":4194344},{"t":1310721,"n":"BinaryFormatterMessage","d":98782,"h":98784346590,"f":4194344},{"t":1310721,"n":"BinaryFormatterDiagId","d":98782,"h":103079313886,"f":4194344},{"t":1310721,"n":"CodeBaseMessage","d":98782,"h":107374281182,"f":4194344},{"t":1310721,"n":"CodeBaseDiagId","d":98782,"h":111669248478,"f":4194344},{"t":1310721,"n":"EscapeUriStringMessage","d":98782,"h":115964215774,"f":4194344},{"t":1310721,"n":"EscapeUriStringDiagId","d":98782,"h":120259183070,"f":4194344},{"t":1310721,"n":"WebRequestMessage","d":98782,"h":124554150366,"f":4194344},{"t":1310721,"n":"WebRequestDiagId","d":98782,"h":128849117662,"f":4194344},{"t":1310721,"n":"DisablePrivateReflectionAttributeMessage","d":98782,"h":133144084958,"f":4194344},{"t":1310721,"n":"DisablePrivateReflectionAttributeDiagId","d":98782,"h":137439052254,"f":4194344},{"t":1310721,"n":"GetContextInfoMessage","d":98782,"h":141734019550,"f":4194344},{"t":1310721,"n":"GetContextInfoDiagId","d":98782,"h":146028986846,"f":4194344},{"t":1310721,"n":"StrongNameKeyPairMessage","d":98782,"h":150323954142,"f":4194344},{"t":1310721,"n":"StrongNameKeyPairDiagId","d":98782,"h":154618921438,"f":4194344},{"t":1310721,"n":"ReflectionOnlyLoadingMessage","d":98782,"h":158913888734,"f":4194344},{"t":1310721,"n":"ReflectionOnlyLoadingDiagId","d":98782,"h":163208856030,"f":4194344},{"t":1310721,"n":"RuntimeEnvironmentMessage","d":98782,"h":167503823326,"f":4194344},{"t":1310721,"n":"RuntimeEnvironmentDiagId","d":98782,"h":171798790622,"f":4194344},{"t":1310721,"n":"JsonSerializerOptionsIgnoreNullValuesMessage","d":98782,"h":176093757918,"f":4194344},{"t":1310721,"n":"JsonSerializerOptionsIgnoreNullValuesDiagId","d":98782,"h":180388725214,"f":4194344},{"t":1310721,"n":"DerivedCryptographicTypesMessage","d":98782,"h":184683692510,"f":4194344},{"t":1310721,"n":"DerivedCryptographicTypesDiagId","d":98782,"h":188978659806,"f":4194344},{"t":1310721,"n":"RijndaelMessage","d":98782,"h":193273627102,"f":4194344},{"t":1310721,"n":"RijndaelDiagId","d":98782,"h":197568594398,"f":4194344},{"t":1310721,"n":"RNGCryptoServiceProviderMessage","d":98782,"h":201863561694,"f":4194344},{"t":1310721,"n":"RNGCryptoServiceProviderDiagId","d":98782,"h":206158528990,"f":4194344},{"t":1310721,"n":"AppDomainCreateUnloadMessage","d":98782,"h":210453496286,"f":4194344},{"t":1310721,"n":"AppDomainCreateUnloadDiagId","d":98782,"h":214748463582,"f":4194344},{"t":1310721,"n":"SuppressIldasmAttributeMessage","d":98782,"h":219043430878,"f":4194344},{"t":1310721,"n":"SuppressIldasmAttributeDiagId","d":98782,"h":223338398174,"f":4194344},{"t":1310721,"n":"X509CertificateImmutableMessage","d":98782,"h":227633365470,"f":4194344},{"t":1310721,"n":"X509CertificateImmutableDiagId","d":98782,"h":231928332766,"f":4194344},{"t":1310721,"n":"PublicKeyPropertyMessage","d":98782,"h":236223300062,"f":4194344},{"t":1310721,"n":"PublicKeyPropertyDiagId","d":98782,"h":240518267358,"f":4194344},{"t":1310721,"n":"X509CertificatePrivateKeyMessage","d":98782,"h":244813234654,"f":4194344},{"t":1310721,"n":"X509CertificatePrivateKeyDiagId","d":98782,"h":249108201950,"f":4194344},{"t":1310721,"n":"ProduceLegacyHmacValuesMessage","d":98782,"h":253403169246,"f":4194344},{"t":1310721,"n":"ProduceLegacyHmacValuesDiagId","d":98782,"h":257698136542,"f":4194344},{"t":1310721,"n":"UseManagedSha1Message","d":98782,"h":261993103838,"f":4194344},{"t":1310721,"n":"UseManagedSha1DiagId","d":98782,"h":266288071134,"f":4194344},{"t":1310721,"n":"CryptoConfigEncodeOIDMessage","d":98782,"h":270583038430,"f":4194344},{"t":1310721,"n":"CryptoConfigEncodeOIDDiagId","d":98782,"h":274878005726,"f":4194344},{"t":1310721,"n":"CorruptedStateRecoveryMessage","d":98782,"h":279172973022,"f":4194344},{"t":1310721,"n":"CorruptedStateRecoveryDiagId","d":98782,"h":283467940318,"f":4194344},{"t":1310721,"n":"Rfc2898CryptDeriveKeyMessage","d":98782,"h":287762907614,"f":4194344},{"t":1310721,"n":"Rfc2898CryptDeriveKeyDiagId","d":98782,"h":292057874910,"f":4194344},{"t":1310721,"n":"CmsSignerCspParamsCtorMessage","d":98782,"h":296352842206,"f":4194344},{"t":1310721,"n":"CmsSignerCspParamsCtorDiagId","d":98782,"h":300647809502,"f":4194344},{"t":1310721,"n":"SignerInfoCounterSigMessage","d":98782,"h":304942776798,"f":4194344},{"t":1310721,"n":"SignerInfoCounterSigDiagId","d":98782,"h":309237744094,"f":4194344},{"t":1310721,"n":"RegexCompileToAssemblyMessage","d":98782,"h":313532711390,"f":4194344},{"t":1310721,"n":"RegexCompileToAssemblyDiagId","d":98782,"h":317827678686,"f":4194344},{"t":1310721,"n":"AssemblyNameMembersMessage","d":98782,"h":322122645982,"f":4194344},{"t":1310721,"n":"AssemblyNameMembersDiagId","d":98782,"h":326417613278,"f":4194344},{"t":1310721,"n":"SystemDataSerializationFormatBinaryMessage","d":98782,"h":330712580574,"f":4194344},{"t":1310721,"n":"SystemDataSerializationFormatBinaryDiagId","d":98782,"h":335007547870,"f":4194344},{"t":1310721,"n":"TlsVersion10and11Message","d":98782,"h":339302515166,"f":4194344},{"t":1310721,"n":"TlsVersion10and11DiagId","d":98782,"h":343597482462,"f":4194344},{"t":1310721,"n":"EncryptionPolicyMessage","d":98782,"h":347892449758,"f":4194344},{"t":1310721,"n":"EncryptionPolicyDiagId","d":98782,"h":352187417054,"f":4194344},{"t":1310721,"n":"EccXmlExportImportMessage","d":98782,"h":356482384350,"f":4194344},{"t":1310721,"n":"EccXmlExportImportDiagId","d":98782,"h":360777351646,"f":4194344},{"t":1310721,"n":"EcDhPublicKeyBlobMessage","d":98782,"h":365072318942,"f":4194344},{"t":1310721,"n":"EcDhPublicKeyBlobDiagId","d":98782,"h":369367286238,"f":4194344},{"t":1310721,"n":"AssemblyNameCodeBaseMessage","d":98782,"h":373662253534,"f":4194344},{"t":1310721,"n":"AssemblyNameCodeBaseDiagId","d":98782,"h":377957220830,"f":4194344},{"t":1310721,"n":"CryptoStringFactoryMessage","d":98782,"h":382252188126,"f":4194344},{"t":1310721,"n":"CryptoStringFactoryDiagId","d":98782,"h":386547155422,"f":4194344},{"t":1310721,"n":"ControlledExecutionRunMessage","d":98782,"h":390842122718,"f":4194344},{"t":1310721,"n":"ControlledExecutionRunDiagId","d":98782,"h":395137090014,"f":4194344},{"t":1310721,"n":"XmlSecureResolverMessage","d":98782,"h":399432057310,"f":4194344},{"t":1310721,"n":"XmlSecureResolverDiagId","d":98782,"h":403727024606,"f":4194344},{"t":1310721,"n":"RsaEncryptDecryptValueMessage","d":98782,"h":408021991902,"f":4194344},{"t":1310721,"n":"RsaEncryptDecryptDiagId","d":98782,"h":412316959198,"f":4194344},{"t":1310721,"n":"JsonSerializerOptionsAddContextMessage","d":98782,"h":416611926494,"f":4194344},{"t":1310721,"n":"JsonSerializerOptionsAddContextDiagId","d":98782,"h":420906893790,"f":4194344},{"t":1310721,"n":"LegacyFormatterMessage","d":98782,"h":425201861086,"f":4194344},{"t":1310721,"n":"LegacyFormatterDiagId","d":98782,"h":429496828382,"f":4194344},{"t":1310721,"n":"LegacyFormatterImplMessage","d":98782,"h":433791795678,"f":4194344},{"t":1310721,"n":"LegacyFormatterImplDiagId","d":98782,"h":438086762974,"f":4194344},{"t":1310721,"n":"RegexExtensibilityImplMessage","d":98782,"h":442381730270,"f":4194344},{"t":1310721,"n":"RegexExtensibilityDiagId","d":98782,"h":446676697566,"f":4194344},{"t":1310721,"n":"AesGcmTagConstructorMessage","d":98782,"h":450971664862,"f":4194344},{"t":1310721,"n":"AesGcmTagConstructorDiagId","d":98782,"h":455266632158,"f":4194344},{"t":1310721,"n":"ThreadVolatileReadWriteMessage","d":98782,"h":459561599454,"f":4194344},{"t":1310721,"n":"ThreadVolatileReadWriteDiagId","d":98782,"h":463856566750,"f":4194344},{"t":1310721,"n":"ArmIntrinsicPerformsUnsignedOperationMessage","d":98782,"h":468151534046,"f":4194344},{"t":1310721,"n":"ArmIntrinsicPerformsUnsignedOperationDiagId","d":98782,"h":472446501342,"f":4194344},{"t":1310721,"n":"LoadFromHashAlgorithmMessage","d":98782,"h":476741468638,"f":4194344},{"t":1310721,"n":"LoadFromHashAlgorithmDiagId","d":98782,"h":481036435934,"f":4194344},{"t":1310721,"n":"X509CtorCertDataObsoleteMessage","d":98782,"h":485331403230,"f":4194344},{"t":1310721,"n":"X509CtorCertDataObsoleteDiagId","d":98782,"h":489626370526,"f":4194344},{"t":1310721,"n":"TlsCipherAlgorithmEnumsMessage","d":98782,"h":493921337822,"f":4194344},{"t":1310721,"n":"TlsCipherAlgorithmEnumsDiagId","d":98782,"h":498216305118,"f":4194344},{"t":1310721,"n":"SystemEventsEventsThreadShutdownMessage","d":98782,"h":502511272414,"f":4194344},{"t":1310721,"n":"SystemEventsEventsThreadShutdownDiagId","d":98782,"h":506806239710,"f":4194344},{"t":1310721,"n":"Rfc2898DeriveBytesCtorMessage","d":98782,"h":511101207006,"f":4194344},{"t":1310721,"n":"Rfc2898DeriveBytesCtorDiagId","d":98782,"h":515396174302,"f":4194344},{"t":1310721,"n":"QueryableMinByMaxByTSourceObsoleteMessage","d":98782,"h":519691141598,"f":4194344},{"t":1310721,"n":"QueryableMinByMaxByTSourceObsoleteDiagId","d":98782,"h":523986108894,"f":4194344},{"t":1310721,"n":"XsltSettingsEnableScriptMessage","d":98782,"h":528281076190,"f":4194344},{"t":1310721,"n":"XsltSettingsEnableScriptDiagId","d":98782,"h":532576043486,"f":4194344}],"h":98782}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `System.Obsoletions`; }
        });
        
        $asm.$cls("$ssc.System.Security.Claims.ClaimsPrincipal", ($self) => class ClaimsPrincipal extends $.$$.System.Object
        {
            static $_SerializationMask;
            static get SerializationMask()
            {
                let $cls = $.$ssc.System.Security.Claims.ClaimsPrincipal;
                return $cls.$_SerializationMask ??= $asm.$nstr("$ssc.System.Security.Claims.ClaimsPrincipal.SerializationMask", ($self) => class SerializationMask extends $.$$.System.Enum
                {
                    static None = 0;
                    static HasIdentities = 1;
                    static UserData = 2;
                    static $map;
                    static get Map()
                    {
                        return this.$map ??= 
                        {
                            "None": 0n,
                            "HasIdentities": 1n,
                            "UserData": 2n
                        };
                    }
                    static $h = 491998;
                    static $z = 4;
                    static $f = 0b110000011010001000;
                    static $k = 4;
                    static get $eut() { return $.$$.System.Int32; }
                    static $$md;
                    static get $md() { return this.$$md ??= {"b":1048577,"u":655361,"l":[{"t":491998,"n":"None","d":491998,"h":4295459294,"f":4194337},{"t":491998,"n":"HasIdentities","d":491998,"h":8590426590,"f":4194337},{"t":491998,"n":"UserData","d":491998,"h":12885393886,"f":4194337}],"c":[{"n":".ctor","o":"$ctor$3","d":491998,"h":17180361182,"f":16777217}],"i":[57278465,63832065,57737217,57409537],"d":426462,"h":491998}; }
                    static get $b() { return $.$$.System.Enum; }
                    static $$i;
                    static get $i() { return this.$$i ??= [ $.$$.System.IComparable, $.$$.System.ISpanFormattable, $.$$.System.IFormattable, $.$$.System.IConvertible ]; }
                    static get $fullName() { return `System.Security.Claims.ClaimsPrincipal.SerializationMask`; }
                }, $cls, ($v) => $cls.$_SerializationMask = $v);
            }
            /*List<ClaimsIdentity>*/ _identities = null;
            /*byte[]?*/ _userSerializationData = null;
            /*Func<IEnumerable<ClaimsIdentity>, ClaimsIdentity?>*/ static s_identitySelector = null;
            /*Func<ClaimsPrincipal?>?*/ static s_principalSelector = null;
            static /*ClaimsPrincipal? */ SelectClaimsPrincipal()
            {
                /*IPrincipal?*/ let threadPrincipal = $.$$.System.Threading.Thread.CurrentPrincipal;
                return (() =>
                {
                    {
                        let claimsPrincipal;
                        if ((claimsPrincipal = threadPrincipal, $.$is(claimsPrincipal, $.$ssc.System.Security.Claims.ClaimsPrincipal)))
                        {
                            return claimsPrincipal;
                        }
                    }
                    if (threadPrincipal === null)
                    {
                        return new $.$ssc.System.Security.Claims.ClaimsPrincipal().$ctor$6(threadPrincipal);
                    }
                    if (threadPrincipal === null)
                    {
                        return null;
                    }
                })();
            }
            $ctor$4(/*SerializationInfo*/ info, /*StreamingContext*/ context)
            {
                super.$ctor();
                {
                    throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
                }
                return this;
            }
            static /*ClaimsIdentity? */ SelectPrimaryIdentity(/*IEnumerable<ClaimsIdentity>*/ identities)
            {
                $.$$.System.ArgumentNullException.ThrowIfNull$2(identities, "identities");
                var $en2 = identities.System$Collections$Generic$IEnumerable$$$GetEnumerator();
                while ($en2.System$Collections$IEnumerator$MoveNext())
                {
                    var identity = $en2.System$Collections$Generic$IEnumerator$$$Current;
                    {
                        if (identity !== null)
                        {
                            return identity;
                        }
                    }
                }
                return null;
            }
            static /*Func<IEnumerable<ClaimsIdentity>, ClaimsIdentity?> */ get PrimaryIdentitySelector()
            {
                return $.$ssc.System.Security.Claims.ClaimsPrincipal.s_identitySelector;
            }
            static /*Func<IEnumerable<ClaimsIdentity>, ClaimsIdentity?> */ set PrimaryIdentitySelector(value)
            {
                $.$ssc.System.Security.Claims.ClaimsPrincipal.s_identitySelector = value;
            }
            static /*Func<ClaimsPrincipal?>? */ get ClaimsPrincipalSelector()
            {
                return $.$ssc.System.Security.Claims.ClaimsPrincipal.s_principalSelector;
            }
            static /*Func<ClaimsPrincipal?>? */ set ClaimsPrincipalSelector(value)
            {
                $.$ssc.System.Security.Claims.ClaimsPrincipal.s_principalSelector = value;
            }
            $ctor$1()
            {
                super.$ctor();
                {
                }
                return this;
            }
            $ctor$2(/*IEnumerable<ClaimsIdentity>*/ identities)
            {
                super.$ctor();
                {
                    $.$$.System.ArgumentNullException.ThrowIfNull$2(identities, "identities");
                    this._identities.AddRange(identities);
                }
                return this;
            }
            $ctor$5(/*IIdentity*/ identity)
            {
                super.$ctor();
                {
                    $.$$.System.ArgumentNullException.ThrowIfNull$2(identity, "identity");
                    let ci;
                    if ($.$is(identity, $.$ssc.System.Security.Claims.ClaimsIdentity, { set $v(v){ ci = v; } }))
                    {
                        this._identities.Add(ci);
                    }
                    else 
                    {
                        this._identities.Add(new $.$ssc.System.Security.Claims.ClaimsIdentity().$ctor$12(identity));
                    }
                }
                return this;
            }
            $ctor$6(/*IPrincipal*/ principal)
            {
                super.$ctor();
                {
                    $.$$.System.ArgumentNullException.ThrowIfNull$2(principal, "principal");
                    /*ClaimsPrincipal?*/ let cp = $.$as(principal, $.$ssc.System.Security.Claims.ClaimsPrincipal);
                    if (null === cp)
                    {
                        this._identities.Add(new $.$ssc.System.Security.Claims.ClaimsIdentity().$ctor$12(principal.System$Security$Principal$IPrincipal$Identity));
                    }
                    else 
                    {
                        if (null !== cp.Identities)
                        {
                            this._identities.AddRange(cp.Identities);
                        }
                    }
                }
                return this;
            }
            $ctor$3(/*BinaryReader*/ reader)
            {
                super.$ctor();
                {
                    $.$$.System.ArgumentNullException.ThrowIfNull$2(reader, "reader");
                    /*SerializationMask*/ let mask = $.$cast(reader.ReadInt32(), $.$ssc.System.Security.Claims.ClaimsPrincipal.SerializationMask);
                    /*int*/ let numPropertiesToRead = reader.ReadInt32();
                    /*int*/ let numPropertiesRead = 0;
                    if ((mask & 1/*SerializationMask.HasIdentities*/) === 1/*SerializationMask.HasIdentities*/)
                    {
                        numPropertiesRead++;
                        /*int*/ let numberOfIdentities = reader.ReadInt32();
                        for(/*int*/ let index = 0; index < numberOfIdentities; ++index)
                        {
                            this._identities.Add(this.CreateClaimsIdentity(reader));
                        }
                    }
                    if ((mask & 2/*SerializationMask.UserData*/) === 2/*SerializationMask.UserData*/)
                    {
                        /*int*/ let cb = reader.ReadInt32();
                        this._userSerializationData = reader.ReadBytes(cb);
                        numPropertiesRead++;
                    }
                    for(/*int*/ let i = numPropertiesRead; i < numPropertiesToRead; i++)
                    {
                        reader.ReadString();
                    }
                }
                return this;
            }
            /*void */ AddIdentity(/*ClaimsIdentity*/ identity)
            {
                $.$$.System.ArgumentNullException.ThrowIfNull$2(identity, "identity");
                this._identities.Add(identity);
            }
            /*void */ AddIdentities(/*IEnumerable<ClaimsIdentity>*/ identities)
            {
                $.$$.System.ArgumentNullException.ThrowIfNull$2(identities, "identities");
                this._identities.AddRange(identities);
            }
            /*IEnumerable<Claim> */ get Claims()
            {
                return new ($.$$.NetJs.YieldToIterator$$($.$ssc.System.Security.Claims.Claim))().$ctor$1(function*()
                {
                    var $en3 = this.Identities.System$Collections$Generic$IEnumerable$$$GetEnumerator();
                    while ($en3.System$Collections$IEnumerator$MoveNext())
                    {
                        var identity = $en3.System$Collections$Generic$IEnumerator$$$Current;
                        {
                            var $en5 = identity.Claims.System$Collections$Generic$IEnumerable$$$GetEnumerator();
                            while ($en5.System$Collections$IEnumerator$MoveNext())
                            {
                                var claim = $en5.System$Collections$Generic$IEnumerator$$$Current;
                                {
                                    yield claim;
                                }
                            }
                        }
                    }
                }.bind(this));
            }
            /*byte[]? */ get CustomSerializationData()
            {
                return this._userSerializationData;
            }
            /*ClaimsPrincipal */ Clone()
            {
                return new $.$ssc.System.Security.Claims.ClaimsPrincipal().$ctor$6(this);
            }
            /*ClaimsIdentity */ CreateClaimsIdentity(/*BinaryReader*/ reader)
            {
                $.$$.System.ArgumentNullException.ThrowIfNull$2(reader, "reader");
                return new $.$ssc.System.Security.Claims.ClaimsIdentity().$ctor$6(reader);
            }
            static /*ClaimsPrincipal? */ get Current()
            {
                return !($.$ssc.System.Security.Claims.ClaimsPrincipal.s_principalSelector === null) ? $.$ssc.System.Security.Claims.ClaimsPrincipal.s_principalSelector.Invoke() : $.$ssc.System.Security.Claims.ClaimsPrincipal.SelectClaimsPrincipal();
            }
            /*IEnumerable<Claim> */ FindAll(/*Predicate<Claim>*/ match)
            {
                $.$$.System.ArgumentNullException.ThrowIfNull$2(match, "match");
                return Core.call(this, match);
                /*IEnumerable<Claim>*/  function Core(/*Predicate<Claim>*/ match)
                {
                    return new ($.$$.NetJs.YieldToIterator$$($.$$.System.Object))().$ctor$1(function*()
                    {
                        var $en4 = this.Identities.System$Collections$Generic$IEnumerable$$$GetEnumerator();
                        while ($en4.System$Collections$IEnumerator$MoveNext())
                        {
                            var identity = $en4.System$Collections$Generic$IEnumerator$$$Current;
                            {
                                if (identity !== null)
                                {
                                    var $en7 = identity.FindAll(match).System$Collections$Generic$IEnumerable$$$GetEnumerator();
                                    while ($en7.System$Collections$IEnumerator$MoveNext())
                                    {
                                        var claim = $en7.System$Collections$Generic$IEnumerator$$$Current;
                                        {
                                            yield claim;
                                        }
                                    }
                                }
                            }
                        }
                    }.bind(this));
                }
            }
            /*IEnumerable<Claim> */ FindAll$1(/*string*/ type)
            {
                $.$$.System.ArgumentNullException.ThrowIfNull$2(type, "type");
                return Core.call(this, type);
                /*IEnumerable<Claim>*/  function Core(/*string*/ type)
                {
                    return new ($.$$.NetJs.YieldToIterator$$($.$$.System.Object))().$ctor$1(function*()
                    {
                        var $en4 = this.Identities.System$Collections$Generic$IEnumerable$$$GetEnumerator();
                        while ($en4.System$Collections$IEnumerator$MoveNext())
                        {
                            var identity = $en4.System$Collections$Generic$IEnumerator$$$Current;
                            {
                                if (identity !== null)
                                {
                                    var $en7 = identity.FindAll$1(type).System$Collections$Generic$IEnumerable$$$GetEnumerator();
                                    while ($en7.System$Collections$IEnumerator$MoveNext())
                                    {
                                        var claim = $en7.System$Collections$Generic$IEnumerator$$$Current;
                                        {
                                            yield claim;
                                        }
                                    }
                                }
                            }
                        }
                    }.bind(this));
                }
            }
            /*Claim? */ FindFirst(/*Predicate<Claim>*/ match)
            {
                $.$$.System.ArgumentNullException.ThrowIfNull$2(match, "match");
                /*Claim?*/ let claim = null;
                var $en2 = this.Identities.System$Collections$Generic$IEnumerable$$$GetEnumerator();
                while ($en2.System$Collections$IEnumerator$MoveNext())
                {
                    var identity = $en2.System$Collections$Generic$IEnumerator$$$Current;
                    {
                        if (identity !== null)
                        {
                            claim = identity.FindFirst(match);
                            if (claim !== null)
                            {
                                return claim;
                            }
                        }
                    }
                }
                return claim;
            }
            /*Claim? */ FindFirst$1(/*string*/ type)
            {
                $.$$.System.ArgumentNullException.ThrowIfNull$2(type, "type");
                /*Claim?*/ let claim = null;
                for(/*int*/ let i = 0; i < this._identities.Count; i++)
                {
                    if (this._identities.get_Item(i) !== null)
                    {
                        claim = this._identities.get_Item(i).FindFirst$1(type);
                        if (claim !== null)
                        {
                            return claim;
                        }
                    }
                }
                return claim;
            }
            /*bool */ HasClaim(/*Predicate<Claim>*/ match)
            {
                $.$$.System.ArgumentNullException.ThrowIfNull$2(match, "match");
                for(/*int*/ let i = 0; i < this._identities.Count; i++)
                {
                    if (this._identities.get_Item(i) !== null)
                    {
                        if (this._identities.get_Item(i).HasClaim(match))
                        {
                            return true;
                        }
                    }
                }
                return false;
            }
            /*bool */ HasClaim$1(/*string*/ type, /*string*/ value)
            {
                $.$$.System.ArgumentNullException.ThrowIfNull$2(type, "type");
                $.$$.System.ArgumentNullException.ThrowIfNull$2(value, "value");
                for(/*int*/ let i = 0; i < this._identities.Count; i++)
                {
                    if (this._identities.get_Item(i) !== null)
                    {
                        if (this._identities.get_Item(i).HasClaim$1(type, value))
                        {
                            return true;
                        }
                    }
                }
                return false;
            }
            /*IEnumerable<ClaimsIdentity> */ get Identities()
            {
                return this._identities;
            }
            /*System.Security.Principal.IIdentity? */ get Identity()
            {
                if ($.$ssc.System.Security.Claims.ClaimsPrincipal.s_identitySelector !== null)
                {
                    return $.$ssc.System.Security.Claims.ClaimsPrincipal.s_identitySelector.Invoke(this._identities);
                }
                else 
                {
                    return $.$ssc.System.Security.Claims.ClaimsPrincipal.SelectPrimaryIdentity(this._identities);
                }
            }
            /*bool */ IsInRole(/*string*/ role)
            {
                for(/*int*/ let i = 0; i < this._identities.Count; i++)
                {
                    if (this._identities.get_Item(i) !== null)
                    {
                        if (this._identities.get_Item(i).HasClaim$1(this._identities.get_Item(i).RoleClaimType, role))
                        {
                            return true;
                        }
                    }
                }
                return false;
            }
            /*void */ WriteTo$1(/*BinaryWriter*/ writer)
            {
                this.WriteTo(writer, null);
            }
            /*void */ WriteTo(/*BinaryWriter*/ writer, /*byte[]?*/ userData)
            {
                $.$$.System.ArgumentNullException.ThrowIfNull$2(writer, "writer");
                /*int*/ let numberOfPropertiesWritten = 0;
                /*var*/ let mask = 0/*SerializationMask.None*/;
                if (this._identities.Count > 0)
                {
                    mask |= 1/*SerializationMask.HasIdentities*/;
                    numberOfPropertiesWritten++;
                }
                if (userData !== null && userData.length > 0)
                {
                    numberOfPropertiesWritten++;
                    mask |= 2/*SerializationMask.UserData*/;
                }
                writer.Write$11(mask);
                writer.Write$11(numberOfPropertiesWritten);
                if ((mask & 1/*SerializationMask.HasIdentities*/) === 1/*SerializationMask.HasIdentities*/)
                {
                    writer.Write$11(this._identities.Count);
                    var $en3 = this._identities.GetEnumerator();
                    while ($en3.MoveNext())
                    {
                        var identity = $en3.Current;
                        {
                            identity.WriteTo$1(writer);
                        }
                    }
                }
                if ((mask & 2/*SerializationMask.UserData*/) === 2/*SerializationMask.UserData*/)
                {
                    writer.Write$11(userData.length);
                    writer.Write$3(userData);
                }
                writer.Flush();
            }
            /*void */ OnSerializingMethod(/*StreamingContext*/ context)
            {
                if ($.$is(this, $.$$.System.Runtime.Serialization.ISerializable))
                {
                    return;
                }
                if (this._identities.Count > 0)
                {
                    throw new $.$$.System.PlatformNotSupportedException().$ctor$16($.$ssc.System.SR.PlatformNotSupported_Serialization);
                }
            }
            /*void */ GetObjectData(/*SerializationInfo*/ info, /*StreamingContext*/ context)
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*string */ DebuggerToString()
            {
                /*int*/ let identitiesCount = 0;
                var $en2 = this.Identities.System$Collections$Generic$IEnumerable$$$GetEnumerator();
                while ($en2.System$Collections$IEnumerator$MoveNext())
                {
                    var items = $en2.System$Collections$Generic$IEnumerator$$$Current;
                    {
                        identitiesCount++;
                    }
                }
                let claimsIdentity;
                if (identitiesCount === 1 && $.$is(this.Identity, $.$ssc.System.Security.Claims.ClaimsIdentity, { set $v(v){ claimsIdentity = v; } }))
                {
                    return claimsIdentity.DebuggerToString();
                }
                /*int*/ let claimsCount = 0;
                var $en2 = this.Claims.System$Collections$Generic$IEnumerable$$$GetEnumerator();
                while ($en2.System$Collections$IEnumerator$MoveNext())
                {
                    var item = $en2.System$Collections$Generic$IEnumerator$$$Current;
                    {
                        claimsCount++;
                    }
                }
                return `Identities = ${identitiesCount}, Claims = ${claimsCount}`;
            }
            //Generated interface implemetation for System.Security.Principal.IPrincipal.Identity.get
            get System$Security$Principal$IPrincipal$Identity()
            {
                return this.Identity;
            }
            //Generated interface implemetation for System.Security.Principal.IPrincipal.IsInRole(string)
            System$Security$Principal$IPrincipal$IsInRole()
            {
                return this.IsInRole(...arguments);
            }
            //default member initializer
            constructor()
            {
                super();
                this._identities = new ($.$$.System.Collections.Generic.List$$($.$ssc.System.Security.Claims.ClaimsIdentity))().$ctor$1();
            }
            //Static Initializer
            static $sinit()
            {
                {
                    this.s_identitySelector = new ($.$$.System.Func$$$($.$$.System.Collections.Generic.IEnumerable$$($.$ssc.System.Security.Claims.ClaimsIdentity), $.$ssc.System.Security.Claims.ClaimsIdentity))().$ctor($.$ssc.System.Security.Claims.ClaimsPrincipal, $.$ssc.System.Security.Claims.ClaimsPrincipal.SelectPrimaryIdentity);
                }
            }
            static $h = 426462;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":$.$$.System.Func$$$($.$$.System.Collections.Generic.IEnumerable$$($.$ssc.System.Security.Claims.ClaimsIdentity), $.$ssc.System.Security.Claims.ClaimsIdentity).$h,"g":{"r":0,"d":0,"h":42950099422,"f":50331681},"s":{"r":0,"d":0,"h":47245066718,"f":83886113},"n":"PrimaryIdentitySelector","d":426462,"h":38655132126,"f":2097185},{"p":$.$$.System.Func$$($.$ssc.System.Security.Claims.ClaimsPrincipal).$h,"g":{"r":0,"d":0,"h":55835001310,"f":50331681},"s":{"r":0,"d":0,"h":60129968606,"f":83886113},"n":"ClaimsPrincipalSelector","d":426462,"h":51540034014,"f":2097185},{"p":$.$$.System.Collections.Generic.IEnumerable$$($.$ssc.System.Security.Claims.Claim).$h,"g":{"r":0,"d":0,"h":98784674270,"f":50331777},"n":"Claims","d":426462,"h":94489706974,"f":2097281},{"p":$.$typeArray($.$$.System.Byte).$h,"g":{"r":0,"d":0,"h":107374608862,"f":50331780},"n":"CustomSerializationData","d":426462,"h":103079641566,"f":2097284},{"p":426462,"g":{"r":0,"d":0,"h":124554478046,"f":50331681},"n":"Current","d":426462,"h":120259510750,"f":2097185},{"p":$.$$.System.Collections.Generic.IEnumerable$$($.$ssc.System.Security.Claims.ClaimsIdentity).$h,"g":{"r":0,"d":0,"h":158914216414,"f":50331777},"n":"Identities","d":426462,"h":154619249118,"f":2097281},{"p":116916225,"g":{"r":0,"d":0,"h":167504151006,"f":50331777},"n":"Identity","d":426462,"h":163209183710,"f":2097281}],"m":[{"r":426462,"n":"SelectClaimsPrincipal","d":426462,"h":25770230238,"f":16777250},{"r":295390,"p":[{"n":"identities","p":$.$$.System.Collections.Generic.IEnumerable$$($.$ssc.System.Security.Claims.ClaimsIdentity).$h}],"n":"SelectPrimaryIdentity","d":426462,"h":34360164830,"f":16777250},{"r":65537,"p":[{"n":"identity","p":295390}],"n":"AddIdentity","d":426462,"h":85899772382,"f":16777345},{"r":65537,"p":[{"n":"identities","p":$.$$.System.Collections.Generic.IEnumerable$$($.$ssc.System.Security.Claims.ClaimsIdentity).$h}],"n":"AddIdentities","d":426462,"h":90194739678,"f":16777345},{"r":426462,"n":"Clone","d":426462,"h":111669576158,"f":16777345},{"r":295390,"p":[{"n":"reader","p":58458113}],"n":"CreateClaimsIdentity","d":426462,"h":115964543454,"f":16777348},{"r":$.$$.System.Collections.Generic.IEnumerable$$($.$ssc.System.Security.Claims.Claim).$h,"p":[{"n":"match","p":$.$$.System.Predicate$$($.$ssc.System.Security.Claims.Claim).$h}],"n":"FindAll","d":426462,"h":128849445342,"f":16777345},{"r":$.$$.System.Collections.Generic.IEnumerable$$($.$ssc.System.Security.Claims.Claim).$h,"p":[{"n":"type","p":1310721}],"n":"FindAll","o":"@$1","d":426462,"h":133144412638,"f":16777345},{"r":164318,"p":[{"n":"match","p":$.$$.System.Predicate$$($.$ssc.System.Security.Claims.Claim).$h}],"n":"FindFirst","d":426462,"h":137439379934,"f":16777345},{"r":164318,"p":[{"n":"type","p":1310721}],"n":"FindFirst","o":"@$1","d":426462,"h":141734347230,"f":16777345},{"r":262145,"p":[{"n":"match","p":$.$$.System.Predicate$$($.$ssc.System.Security.Claims.Claim).$h}],"n":"HasClaim","d":426462,"h":146029314526,"f":16777345},{"r":262145,"p":[{"n":"type","p":1310721},{"n":"value","p":1310721}],"n":"HasClaim","o":"@$1","d":426462,"h":150324281822,"f":16777345},{"r":262145,"p":[{"n":"role","p":1310721}],"n":"IsInRole","d":426462,"h":171799118302,"f":16777345},{"r":65537,"p":[{"n":"writer","p":58523649}],"n":"WriteTo","o":"@$1","d":426462,"h":176094085598,"f":16777345},{"r":65537,"p":[{"n":"writer","p":58523649},{"n":"userData","p":$.$typeArray($.$$.System.Byte).$h}],"n":"WriteTo","d":426462,"h":180389052894,"f":16777348},{"r":65537,"p":[{"n":"context","p":113967105}],"n":"OnSerializingMethod","d":426462,"h":184684020190,"f":16777218,"a":[{"t":113508353,"c":4408475649}]},{"r":65537,"p":[{"n":"info","p":113836033},{"n":"context","p":113967105}],"n":"GetObjectData","d":426462,"h":188978987486,"f":16777348},{"r":1310721,"n":"DebuggerToString","d":426462,"h":193273954782,"f":16777218}],"l":[{"t":$.$$.System.Collections.Generic.List$$($.$ssc.System.Security.Claims.ClaimsIdentity).$h,"n":"_identities","d":426462,"h":8590361054,"f":4194306},{"t":$.$typeArray($.$$.System.Byte).$h,"n":"_userSerializationData","d":426462,"h":12885328350,"f":4194306},{"t":$.$$.System.Func$$$($.$$.System.Collections.Generic.IEnumerable$$($.$ssc.System.Security.Claims.ClaimsIdentity), $.$ssc.System.Security.Claims.ClaimsIdentity).$h,"n":"s_identitySelector","d":426462,"h":17180295646,"f":4194338},{"t":$.$$.System.Func$$($.$ssc.System.Security.Claims.ClaimsPrincipal).$h,"n":"s_principalSelector","d":426462,"h":21475262942,"f":4194338}],"c":[{"p":[{"n":"info","p":113836033},{"n":"context","p":113967105}],"n":".ctor","o":"$ctor$4","d":426462,"h":30065197534,"f":16777220,"a":[{"t":70909953,"c":8660844545,"a":[{"v":"This API supports obsolete formatter-based serialization. It should not be called or extended by application code.","t":1310721}],"n":[{"n":"DiagnosticId","v":"SYSLIB0051","t":1310721},{"n":"UrlFormat","v":"https://aka.ms/dotnet-warnings/{0}","t":1310721}]},{"t":33292289,"c":4328259585,"a":[{"v":1,"t":33357825}]}]},{"n":".ctor","o":"$ctor$1","d":426462,"h":64424935902,"f":16777217},{"p":[{"n":"identities","p":$.$$.System.Collections.Generic.IEnumerable$$($.$ssc.System.Security.Claims.ClaimsIdentity).$h}],"n":".ctor","o":"$ctor$2","d":426462,"h":68719903198,"f":16777217},{"p":[{"n":"identity","p":116916225}],"n":".ctor","o":"$ctor$5","d":426462,"h":73014870494,"f":16777217},{"p":[{"n":"principal","p":116981761}],"n":".ctor","o":"$ctor$6","d":426462,"h":77309837790,"f":16777217},{"p":[{"n":"reader","p":58458113}],"n":".ctor","o":"$ctor$3","d":426462,"h":81604805086,"f":16777217}],"i":[116981761],"j":[491998],"h":426462,"a":[{"t":37617665,"c":8627552257,"a":[{"v":"{DebuggerToString(),nq}","t":1310721}]}]}; }
            static get $b() { return $.$$.System.Object; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.System.Security.Principal.IPrincipal ]; }
            static get $fullName() { return `System.Security.Claims.ClaimsPrincipal`; }
        });
        
        $asm.$cls("$ssc.System.Security.Claims.ClaimsIdentity", ($self) => class ClaimsIdentity extends $.$$.System.Object
        {
            static $_SerializationMask;
            static get SerializationMask()
            {
                let $cls = $.$ssc.System.Security.Claims.ClaimsIdentity;
                return $cls.$_SerializationMask ??= $asm.$nstr("$ssc.System.Security.Claims.ClaimsIdentity.SerializationMask", ($self) => class SerializationMask extends $.$$.System.Enum
                {
                    static None = 0;
                    static AuthenticationType = 1;
                    static BootstrapConext = 2;
                    static NameClaimType = 4;
                    static RoleClaimType = 8;
                    static HasClaims = 16;
                    static HasLabel = 32;
                    static Actor = 64;
                    static UserData = 128;
                    static $map;
                    static get Map()
                    {
                        return this.$map ??= 
                        {
                            "None": 0n,
                            "AuthenticationType": 1n,
                            "BootstrapConext": 2n,
                            "NameClaimType": 4n,
                            "RoleClaimType": 8n,
                            "HasClaims": 16n,
                            "HasLabel": 32n,
                            "Actor": 64n,
                            "UserData": 128n
                        };
                    }
                    static $h = 360926;
                    static $z = 4;
                    static $f = 0b110000011010001000;
                    static $k = 4;
                    static get $eut() { return $.$$.System.Int32; }
                    static $$md;
                    static get $md() { return this.$$md ??= {"b":1048577,"u":655361,"l":[{"t":360926,"n":"None","d":360926,"h":4295328222,"f":4194337},{"t":360926,"n":"AuthenticationType","d":360926,"h":8590295518,"f":4194337},{"t":360926,"n":"BootstrapConext","d":360926,"h":12885262814,"f":4194337},{"t":360926,"n":"NameClaimType","d":360926,"h":17180230110,"f":4194337},{"t":360926,"n":"RoleClaimType","d":360926,"h":21475197406,"f":4194337},{"t":360926,"n":"HasClaims","d":360926,"h":25770164702,"f":4194337},{"t":360926,"n":"HasLabel","d":360926,"h":30065131998,"f":4194337},{"t":360926,"n":"Actor","d":360926,"h":34360099294,"f":4194337},{"t":360926,"n":"UserData","d":360926,"h":38655066590,"f":4194337}],"c":[{"n":".ctor","o":"$ctor$3","d":360926,"h":42950033886,"f":16777217}],"i":[57278465,63832065,57737217,57409537],"d":295390,"h":360926}; }
                    static get $b() { return $.$$.System.Enum; }
                    static $$i;
                    static get $i() { return this.$$i ??= [ $.$$.System.IComparable, $.$$.System.ISpanFormattable, $.$$.System.IFormattable, $.$$.System.IConvertible ]; }
                    static get $fullName() { return `System.Security.Claims.ClaimsIdentity.SerializationMask`; }
                }, $cls, ($v) => $cls.$_SerializationMask = $v);
            }
            /*byte[]?*/ _userSerializationData = null;
            /*ClaimsIdentity?*/ _actor = null;
            /*string?*/ _authenticationType = null;
            /*object?*/ _bootstrapContext = null;
            /*List<List<Claim>>?*/ _externalClaims = null;
            /*string?*/ _label = null;
            /*List<Claim>*/ _instanceClaims = null;
            /*string*/ _nameClaimType = null;
            /*string*/ _roleClaimType = null;
            /*StringComparison*/ _stringComparison = 5;
            /*string*/ static DefaultIssuer = null;
            /*string*/ static DefaultNameClaimType = null;
            /*string*/ static DefaultRoleClaimType = null;
            $ctor$1()
            {
                this.$ctor$10(null, null, null, null, null);
                {
                }
                return this;
            }
            $ctor$12(/*IIdentity?*/ identity)
            {
                this.$ctor$10(identity, null, null, null, null);
                {
                }
                return this;
            }
            $ctor$4(/*IEnumerable<Claim>?*/ claims)
            {
                this.$ctor$10(null, claims, null, null, null);
                {
                }
                return this;
            }
            $ctor$14(/*string?*/ authenticationType)
            {
                this.$ctor$10(null, null, authenticationType, null, null);
                {
                }
                return this;
            }
            $ctor$3(/*IEnumerable<Claim>?*/ claims, /*string?*/ authenticationType)
            {
                this.$ctor$10(null, claims, authenticationType, null, null);
                {
                }
                return this;
            }
            $ctor$11(/*IIdentity?*/ identity, /*IEnumerable<Claim>?*/ claims)
            {
                this.$ctor$10(identity, claims, null, null, null);
                {
                }
                return this;
            }
            $ctor$13(/*string?*/ authenticationType, /*string?*/ nameType, /*string?*/ roleType)
            {
                this.$ctor$10(null, null, authenticationType, nameType, roleType);
                {
                }
                return this;
            }
            $ctor$2(/*IEnumerable<Claim>?*/ claims, /*string?*/ authenticationType, /*string?*/ nameType, /*string?*/ roleType)
            {
                this.$ctor$10(null, claims, authenticationType, nameType, roleType);
                {
                }
                return this;
            }
            $ctor$10(/*IIdentity?*/ identity, /*IEnumerable<Claim>?*/ claims, /*string?*/ authenticationType, /*string?*/ nameType, /*string?*/ roleType)
            {
                super.$ctor();
                {
                    /*ClaimsIdentity?*/ let claimsIdentity = $.$as(identity, $.$ssc.System.Security.Claims.ClaimsIdentity);
                    this._authenticationType = (identity !== null && $.$$.System.String.IsNullOrEmpty(authenticationType)) ? identity.System$Security$Principal$IIdentity$AuthenticationType : authenticationType;
                    this._nameClaimType = !$.$$.System.String.IsNullOrEmpty(nameType) ? nameType : (claimsIdentity !== null ? claimsIdentity._nameClaimType : "http://schemas.xmlsoap.org/ws/2005/05/identity/claims/name"/*DefaultNameClaimType*/);
                    this._roleClaimType = !$.$$.System.String.IsNullOrEmpty(roleType) ? roleType : (claimsIdentity !== null ? claimsIdentity._roleClaimType : "http://schemas.microsoft.com/ws/2008/06/identity/claims/role"/*DefaultRoleClaimType*/);
                    if (claimsIdentity !== null)
                    {
                        this._label = claimsIdentity._label;
                        this._bootstrapContext = claimsIdentity._bootstrapContext;
                        if (claimsIdentity.Actor !== null)
                        {
                            if (!this.IsCircular(claimsIdentity.Actor))
                            {
                                this._actor = claimsIdentity.Actor;
                            }
                            else 
                            {
                                throw new $.$$.System.InvalidOperationException().$ctor$12($.$ssc.System.SR.InvalidOperationException_ActorGraphCircular);
                            }
                        }
                        this.SafeAddClaims(claimsIdentity._instanceClaims);
                    }
                    else 
                    {
                        if (identity !== null && !$.$$.System.String.IsNullOrEmpty(identity.System$Security$Principal$IIdentity$Name))
                        {
                            this.SafeAddClaim(new $.$ssc.System.Security.Claims.Claim().$ctor$4(this._nameClaimType, identity.System$Security$Principal$IIdentity$Name, "http://www.w3.org/2001/XMLSchema#string"/*ClaimValueTypes.String*/, "LOCAL AUTHORITY"/*DefaultIssuer*/, "LOCAL AUTHORITY"/*DefaultIssuer*/, this));
                        }
                    }
                    if (claims !== null)
                    {
                        this.SafeAddClaims(claims);
                    }
                }
                return this;
            }
            $ctor$6(/*BinaryReader*/ reader)
            {
                super.$ctor();
                {
                    $.$$.System.ArgumentNullException.ThrowIfNull$2(reader, "reader");
                    this.Initialize(reader);
                }
                return this;
            }
            $ctor$5(/*BinaryReader*/ reader, /*StringComparison*/ stringComparison)
            {
                super.$ctor();
                {
                    $.$$.System.ArgumentNullException.ThrowIfNull$2(reader, "reader");
                    $.$ssc.System.Security.Claims.ClaimsIdentity.ValidateStringComparison(stringComparison);
                    this._stringComparison = stringComparison;
                    this.Initialize(reader);
                }
                return this;
            }
            $ctor$16(/*ClaimsIdentity*/ other)
            {
                super.$ctor();
                {
                    $.$$.System.ArgumentNullException.ThrowIfNull$2(other, "other");
                    this.Initialize$1(other);
                }
                return this;
            }
            $ctor$15(/*ClaimsIdentity*/ other, /*StringComparison*/ stringComparison)
            {
                super.$ctor();
                {
                    $.$$.System.ArgumentNullException.ThrowIfNull$2(other, "other");
                    $.$ssc.System.Security.Claims.ClaimsIdentity.ValidateStringComparison(stringComparison);
                    this._stringComparison = stringComparison;
                    this.Initialize$1(other);
                }
                return this;
            }
            $ctor$9(/*IIdentity?*/ identity, /*IEnumerable<Claim>?*/ claims, /*string?*/ authenticationType, /*string?*/ nameType, /*string?*/ roleType, /*StringComparison*/ stringComparison)
            {
                this.$ctor$10(identity, claims, authenticationType, nameType, roleType);
                {
                    $.$ssc.System.Security.Claims.ClaimsIdentity.ValidateStringComparison(stringComparison);
                    this._stringComparison = stringComparison;
                }
                return this;
            }
            $ctor$7(/*SerializationInfo*/ info, /*StreamingContext*/ context)
            {
                super.$ctor();
                {
                    throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
                }
                return this;
            }
            $ctor$8(/*SerializationInfo*/ info)
            {
                super.$ctor();
                {
                    throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
                }
                return this;
            }
            /*string? */ get AuthenticationType()
            {
                return this._authenticationType;
            }
            /*bool */ get IsAuthenticated()
            {
                return !$.$$.System.String.IsNullOrEmpty(this._authenticationType);
            }
            /*ClaimsIdentity? */ get Actor()
            {
                return this._actor;
            }
            /*ClaimsIdentity? */ set Actor(value)
            {
                if (value !== null)
                {
                    if (this.IsCircular(value))
                    {
                        throw new $.$$.System.InvalidOperationException().$ctor$12($.$ssc.System.SR.InvalidOperationException_ActorGraphCircular);
                    }
                }
                this._actor = value;
            }
            /*object? */ get BootstrapContext()
            {
                return this._bootstrapContext;
            }
            /*object? */ set BootstrapContext(value)
            {
                this._bootstrapContext = value;
            }
            /*IEnumerable<Claim> */ get Claims()
            {
                if (this._externalClaims === null)
                {
                    return this._instanceClaims;
                }
                return this.CombinedClaimsIterator();
            }
            /*IEnumerable<Claim> */ CombinedClaimsIterator()
            {
                return new ($.$$.NetJs.YieldToIterator$$($.$$.System.Object))().$ctor$1(function*()
                {
                    for(/*int*/ let i = 0; i < this._instanceClaims.Count; i++)
                    {
                        yield this._instanceClaims.get_Item(i);
                    }
                    for(/*int*/ let j = 0; j < this._externalClaims.Count; j++)
                    {
                        if (this._externalClaims.get_Item(j) !== null)
                        {
                            var $en5 = this._externalClaims.get_Item(j).GetEnumerator();
                            while ($en5.MoveNext())
                            {
                                var claim = $en5.Current;
                                {
                                    yield claim;
                                }
                            }
                        }
                    }
                }.bind(this));
            }
            /*byte[]? */ get CustomSerializationData()
            {
                return this._userSerializationData;
            }
            /*List<List<Claim>> */ get ExternalClaims()
            {
                return this._externalClaims ??= new ($.$$.System.Collections.Generic.List$$($.$$.System.Collections.Generic.List$$($.$ssc.System.Security.Claims.Claim)))().$ctor$1();
            }
            /*string? */ get Label()
            {
                return this._label;
            }
            /*string? */ set Label(value)
            {
                this._label = value;
            }
            /*string? */ get Name()
            {
                /*Claim?*/ let claim = this.FindFirst$1(this._nameClaimType);
                if (claim !== null)
                {
                    return claim.Value;
                }
                return null;
            }
            /*string */ get NameClaimType()
            {
                return this._nameClaimType;
            }
            /*string */ get RoleClaimType()
            {
                return this._roleClaimType;
            }
            /*ClaimsIdentity */ Clone()
            {
                return new $.$ssc.System.Security.Claims.ClaimsIdentity().$ctor$15(this, this._stringComparison);
            }
            /*void */ AddClaim(/*Claim*/ claim)
            {
                $.$$.System.ArgumentNullException.ThrowIfNull$2(claim, "claim");
                if ($.$$.System.Object.ReferenceEquals(claim.Subject, this))
                {
                    this._instanceClaims.Add(claim);
                }
                else 
                {
                    this._instanceClaims.Add(claim.Clone$1(this));
                }
            }
            /*void */ AddClaims(/*IEnumerable<Claim?>*/ claims)
            {
                $.$$.System.ArgumentNullException.ThrowIfNull$2(claims, "claims");
                var $en2 = claims.System$Collections$Generic$IEnumerable$$$GetEnumerator();
                while ($en2.System$Collections$IEnumerator$MoveNext())
                {
                    var claim = $en2.System$Collections$Generic$IEnumerator$$$Current;
                    {
                        if (claim === null)
                        {
                            continue;
                        }
                        if ($.$$.System.Object.ReferenceEquals(claim.Subject, this))
                        {
                            this._instanceClaims.Add(claim);
                        }
                        else 
                        {
                            this._instanceClaims.Add(claim.Clone$1(this));
                        }
                    }
                }
            }
            /*bool */ TryRemoveClaim(/*Claim?*/ claim)
            {
                if (claim === null)
                {
                    return false;
                }
                /*bool*/ let removed = false;
                for(/*int*/ let i = 0; i < this._instanceClaims.Count; i++)
                {
                    if ($.$$.System.Object.ReferenceEquals(this._instanceClaims.get_Item(i), claim))
                    {
                        this._instanceClaims.RemoveAt(i);
                        removed = true;
                        break;
                    }
                }
                return removed;
            }
            /*void */ RemoveClaim(/*Claim?*/ claim)
            {
                if (!this.TryRemoveClaim(claim))
                {
                    throw new $.$$.System.InvalidOperationException().$ctor$12($.$ssc.System.SR.Format$6($.$ssc.System.SR.InvalidOperation_ClaimCannotBeRemoved, claim));
                }
            }
            /*void */ SafeAddClaims(/*IEnumerable<Claim?>*/ claims)
            {
                var $en2 = claims.System$Collections$Generic$IEnumerable$$$GetEnumerator();
                while ($en2.System$Collections$IEnumerator$MoveNext())
                {
                    var claim = $en2.System$Collections$Generic$IEnumerator$$$Current;
                    {
                        if (claim === null)
                        {
                            continue;
                        }
                        if ($.$$.System.Object.ReferenceEquals(claim.Subject, this))
                        {
                            this._instanceClaims.Add(claim);
                        }
                        else 
                        {
                            this._instanceClaims.Add(claim.Clone$1(this));
                        }
                    }
                }
            }
            /*void */ SafeAddClaim(/*Claim?*/ claim)
            {
                if (claim === null)
                {
                    return;
                }
                if ($.$$.System.Object.ReferenceEquals(claim.Subject, this))
                {
                    this._instanceClaims.Add(claim);
                }
                else 
                {
                    this._instanceClaims.Add(claim.Clone$1(this));
                }
            }
            /*IEnumerable<Claim> */ FindAll(/*Predicate<Claim>*/ match)
            {
                $.$$.System.ArgumentNullException.ThrowIfNull$2(match, "match");
                return Core.call(this, match);
                /*IEnumerable<Claim>*/  function Core(/*Predicate<Claim>*/ match)
                {
                    return new ($.$$.NetJs.YieldToIterator$$($.$$.System.Object))().$ctor$1(function*()
                    {
                        var $en4 = this.Claims.System$Collections$Generic$IEnumerable$$$GetEnumerator();
                        while ($en4.System$Collections$IEnumerator$MoveNext())
                        {
                            var claim = $en4.System$Collections$Generic$IEnumerator$$$Current;
                            {
                                if (match.Invoke(claim))
                                {
                                    yield claim;
                                }
                            }
                        }
                    }.bind(this));
                }
            }
            /*IEnumerable<Claim> */ FindAll$1(/*string*/ type)
            {
                $.$$.System.ArgumentNullException.ThrowIfNull$2(type, "type");
                return Core.call(this, type);
                /*IEnumerable<Claim>*/  function Core(/*string*/ type)
                {
                    return new ($.$$.NetJs.YieldToIterator$$($.$$.System.Object))().$ctor$1(function*()
                    {
                        var $en4 = this.Claims.System$Collections$Generic$IEnumerable$$$GetEnumerator();
                        while ($en4.System$Collections$IEnumerator$MoveNext())
                        {
                            var claim = $en4.System$Collections$Generic$IEnumerator$$$Current;
                            {
                                if (claim !== null)
                                {
                                    if ($.$$.System.String.Equals$2(claim.Type, type, this._stringComparison))
                                    {
                                        yield claim;
                                    }
                                }
                            }
                        }
                    }.bind(this));
                }
            }
            /*Claim? */ FindFirst(/*Predicate<Claim>*/ match)
            {
                $.$$.System.ArgumentNullException.ThrowIfNull$2(match, "match");
                var $en2 = this.Claims.System$Collections$Generic$IEnumerable$$$GetEnumerator();
                while ($en2.System$Collections$IEnumerator$MoveNext())
                {
                    var claim = $en2.System$Collections$Generic$IEnumerator$$$Current;
                    {
                        if (match.Invoke(claim))
                        {
                            return claim;
                        }
                    }
                }
                return null;
            }
            /*Claim? */ FindFirst$1(/*string*/ type)
            {
                $.$$.System.ArgumentNullException.ThrowIfNull$2(type, "type");
                var $en2 = this.Claims.System$Collections$Generic$IEnumerable$$$GetEnumerator();
                while ($en2.System$Collections$IEnumerator$MoveNext())
                {
                    var claim = $en2.System$Collections$Generic$IEnumerator$$$Current;
                    {
                        if (claim !== null)
                        {
                            if ($.$$.System.String.Equals$2(claim.Type, type, this._stringComparison))
                            {
                                return claim;
                            }
                        }
                    }
                }
                return null;
            }
            /*bool */ HasClaim(/*Predicate<Claim>*/ match)
            {
                $.$$.System.ArgumentNullException.ThrowIfNull$2(match, "match");
                var $en2 = this.Claims.System$Collections$Generic$IEnumerable$$$GetEnumerator();
                while ($en2.System$Collections$IEnumerator$MoveNext())
                {
                    var claim = $en2.System$Collections$Generic$IEnumerator$$$Current;
                    {
                        if (match.Invoke(claim))
                        {
                            return true;
                        }
                    }
                }
                return false;
            }
            /*bool */ HasClaim$1(/*string*/ type, /*string*/ value)
            {
                $.$$.System.ArgumentNullException.ThrowIfNull$2(type, "type");
                $.$$.System.ArgumentNullException.ThrowIfNull$2(value, "value");
                var $en2 = this.Claims.System$Collections$Generic$IEnumerable$$$GetEnumerator();
                while ($en2.System$Collections$IEnumerator$MoveNext())
                {
                    var claim = $en2.System$Collections$Generic$IEnumerator$$$Current;
                    {
                        if (claim !== null && $.$$.System.String.Equals$2(claim.Type, type, this._stringComparison) && $.$$.System.String.Equals$2(claim.Value, value, 4/*StringComparison.Ordinal*/))
                        {
                            return true;
                        }
                    }
                }
                return false;
            }
            /*void */ Initialize$1(/*ClaimsIdentity*/ other)
            {
                if (other._actor !== null)
                {
                    this._actor = other._actor.Clone();
                }
                this._authenticationType = other._authenticationType;
                this._bootstrapContext = other._bootstrapContext;
                this._label = other._label;
                this._nameClaimType = other._nameClaimType;
                this._roleClaimType = other._roleClaimType;
                if (other._userSerializationData !== null)
                {
                    this._userSerializationData = $.$as(other._userSerializationData.Clone(), $.$typeArray($.$$.System.Byte));
                }
                this.SafeAddClaims(other._instanceClaims);
            }
            /*void */ Initialize(/*BinaryReader*/ reader)
            {
                $.$$.System.ArgumentNullException.ThrowIfNull$2(reader, "reader");
                /*SerializationMask*/ let mask = $.$cast(reader.ReadInt32(), $.$ssc.System.Security.Claims.ClaimsIdentity.SerializationMask);
                /*int*/ let numPropertiesRead = 0;
                /*int*/ let numPropertiesToRead = reader.ReadInt32();
                if ((mask & 1/*SerializationMask.AuthenticationType*/) === 1/*SerializationMask.AuthenticationType*/)
                {
                    this._authenticationType = reader.ReadString();
                    numPropertiesRead++;
                }
                if ((mask & 2/*SerializationMask.BootstrapConext*/) === 2/*SerializationMask.BootstrapConext*/)
                {
                    this._bootstrapContext = reader.ReadString();
                    numPropertiesRead++;
                }
                if ((mask & 4/*SerializationMask.NameClaimType*/) === 4/*SerializationMask.NameClaimType*/)
                {
                    this._nameClaimType = reader.ReadString();
                    numPropertiesRead++;
                }
                else 
                {
                    this._nameClaimType = "http://schemas.xmlsoap.org/ws/2005/05/identity/claims/name"/*ClaimsIdentity.DefaultNameClaimType*/;
                }
                if ((mask & 8/*SerializationMask.RoleClaimType*/) === 8/*SerializationMask.RoleClaimType*/)
                {
                    this._roleClaimType = reader.ReadString();
                    numPropertiesRead++;
                }
                else 
                {
                    this._roleClaimType = "http://schemas.microsoft.com/ws/2008/06/identity/claims/role"/*ClaimsIdentity.DefaultRoleClaimType*/;
                }
                if ((mask & 32/*SerializationMask.HasLabel*/) === 32/*SerializationMask.HasLabel*/)
                {
                    this._label = reader.ReadString();
                    numPropertiesRead++;
                }
                if ((mask & 16/*SerializationMask.HasClaims*/) === 16/*SerializationMask.HasClaims*/)
                {
                    /*int*/ let numberOfClaims = reader.ReadInt32();
                    for(/*int*/ let index = 0; index < numberOfClaims; index++)
                    {
                        this._instanceClaims.Add(this.CreateClaim(reader));
                    }
                    numPropertiesRead++;
                }
                if ((mask & 64/*SerializationMask.Actor*/) === 64/*SerializationMask.Actor*/)
                {
                    this._actor = new $.$ssc.System.Security.Claims.ClaimsIdentity().$ctor$6(reader);
                    numPropertiesRead++;
                }
                if ((mask & 128/*SerializationMask.UserData*/) === 128/*SerializationMask.UserData*/)
                {
                    /*int*/ let cb = reader.ReadInt32();
                    this._userSerializationData = reader.ReadBytes(cb);
                    numPropertiesRead++;
                }
                for(/*int*/ let i = numPropertiesRead; i < numPropertiesToRead; i++)
                {
                    reader.ReadString();
                }
            }
            /*Claim */ CreateClaim(/*BinaryReader*/ reader)
            {
                $.$$.System.ArgumentNullException.ThrowIfNull$2(reader, "reader");
                return new $.$ssc.System.Security.Claims.Claim().$ctor$1(reader, this);
            }
            /*void */ WriteTo$1(/*BinaryWriter*/ writer)
            {
                this.WriteTo(writer, null);
            }
            /*void */ WriteTo(/*BinaryWriter*/ writer, /*byte[]?*/ userData)
            {
                $.$$.System.ArgumentNullException.ThrowIfNull$2(writer, "writer");
                /*int*/ let numberOfPropertiesWritten = 0;
                /*var*/ let mask = 0/*SerializationMask.None*/;
                if ($.$$.System.String.op_Inequality(this._authenticationType, null))
                {
                    mask |= 1/*SerializationMask.AuthenticationType*/;
                    numberOfPropertiesWritten++;
                }
                if (this._bootstrapContext !== null)
                {
                    if ($.$is(this._bootstrapContext, $.$$.System.String))
                    {
                        mask |= 2/*SerializationMask.BootstrapConext*/;
                        numberOfPropertiesWritten++;
                    }
                }
                if (!$.$$.System.String.Equals$2(this._nameClaimType, "http://schemas.xmlsoap.org/ws/2005/05/identity/claims/name"/*ClaimsIdentity.DefaultNameClaimType*/, 4/*StringComparison.Ordinal*/))
                {
                    mask |= 4/*SerializationMask.NameClaimType*/;
                    numberOfPropertiesWritten++;
                }
                if (!$.$$.System.String.Equals$2(this._roleClaimType, "http://schemas.microsoft.com/ws/2008/06/identity/claims/role"/*ClaimsIdentity.DefaultRoleClaimType*/, 4/*StringComparison.Ordinal*/))
                {
                    mask |= 8/*SerializationMask.RoleClaimType*/;
                    numberOfPropertiesWritten++;
                }
                if (!$.$$.System.String.IsNullOrWhiteSpace(this._label))
                {
                    mask |= 32/*SerializationMask.HasLabel*/;
                    numberOfPropertiesWritten++;
                }
                if (this._instanceClaims.Count > 0)
                {
                    mask |= 16/*SerializationMask.HasClaims*/;
                    numberOfPropertiesWritten++;
                }
                if (this._actor !== null)
                {
                    mask |= 64/*SerializationMask.Actor*/;
                    numberOfPropertiesWritten++;
                }
                if (userData !== null && userData.length > 0)
                {
                    numberOfPropertiesWritten++;
                    mask |= 128/*SerializationMask.UserData*/;
                }
                writer.Write$11(mask);
                writer.Write$11(numberOfPropertiesWritten);
                if ((mask & 1/*SerializationMask.AuthenticationType*/) === 1/*SerializationMask.AuthenticationType*/)
                {
                    writer.Write$17(this._authenticationType);
                }
                if ((mask & 2/*SerializationMask.BootstrapConext*/) === 2/*SerializationMask.BootstrapConext*/)
                {
                    writer.Write$17($.$cast(this._bootstrapContext, $.$$.System.String));
                }
                if ((mask & 4/*SerializationMask.NameClaimType*/) === 4/*SerializationMask.NameClaimType*/)
                {
                    writer.Write$17(this._nameClaimType);
                }
                if ((mask & 8/*SerializationMask.RoleClaimType*/) === 8/*SerializationMask.RoleClaimType*/)
                {
                    writer.Write$17(this._roleClaimType);
                }
                if ((mask & 32/*SerializationMask.HasLabel*/) === 32/*SerializationMask.HasLabel*/)
                {
                    writer.Write$17(this._label);
                }
                if ((mask & 16/*SerializationMask.HasClaims*/) === 16/*SerializationMask.HasClaims*/)
                {
                    writer.Write$11(this._instanceClaims.Count);
                    var $en3 = this._instanceClaims.GetEnumerator();
                    while ($en3.MoveNext())
                    {
                        var claim = $en3.Current;
                        {
                            claim.WriteTo$1(writer);
                        }
                    }
                }
                if ((mask & 64/*SerializationMask.Actor*/) === 64/*SerializationMask.Actor*/)
                {
                    this._actor.WriteTo$1(writer);
                }
                if ((mask & 128/*SerializationMask.UserData*/) === 128/*SerializationMask.UserData*/)
                {
                    writer.Write$11(userData.length);
                    writer.Write$3(userData);
                }
                writer.Flush();
            }
            /*bool */ IsCircular(/*ClaimsIdentity*/ subject)
            {
                if ($.$$.System.Object.ReferenceEquals(this, subject))
                {
                    return true;
                }
                /*ClaimsIdentity*/ let currSubject = subject;
                while(currSubject.Actor !== null)
                {
                    if ($.$$.System.Object.ReferenceEquals(this, currSubject.Actor))
                    {
                        return true;
                    }
                    currSubject = currSubject.Actor;
                }
                return false;
            }
            /*void */ GetObjectData(/*SerializationInfo*/ info, /*StreamingContext*/ context)
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*string */ DebuggerToString()
            {
                /*int*/ let claimsCount = 0;
                var $en2 = this.Claims.System$Collections$Generic$IEnumerable$$$GetEnumerator();
                while ($en2.System$Collections$IEnumerator$MoveNext())
                {
                    var item = $en2.System$Collections$Generic$IEnumerator$$$Current;
                    {
                        claimsCount++;
                    }
                }
                /*string*/ let debugText = `IsAuthenticated = ${(this.IsAuthenticated ? "true" : "false")}`;
                if ($.$$.System.String.op_Inequality(this.Name, null))
                {
                    debugText += `, Name = ${this.Name}`;
                }
                if (claimsCount > 0)
                {
                    debugText += `, Claims = ${claimsCount}`;
                }
                return debugText;
            }
            static /*void */ ValidateStringComparison(/*StringComparison*/ stringComparison)
            {
                switch(stringComparison)
                {
                    case 4/*StringComparison.Ordinal*/:
                    case 5/*StringComparison.OrdinalIgnoreCase*/:
                    case 2/*StringComparison.InvariantCulture*/:
                    case 3/*StringComparison.InvariantCultureIgnoreCase*/:
                    break;
                    default:
                    throw new $.$$.System.ArgumentException().$ctor$13($.$ssc.System.SR.ArgumentException_StringComparisonCultureAware, "stringComparison");
                }
            }
            //Generated interface implemetation for System.Security.Principal.IIdentity.Name.get
            get System$Security$Principal$IIdentity$Name()
            {
                return this.Name;
            }
            //Generated interface implemetation for System.Security.Principal.IIdentity.AuthenticationType.get
            get System$Security$Principal$IIdentity$AuthenticationType()
            {
                return this.AuthenticationType;
            }
            //Generated interface implemetation for System.Security.Principal.IIdentity.IsAuthenticated.get
            get System$Security$Principal$IIdentity$IsAuthenticated()
            {
                return this.IsAuthenticated;
            }
            //default member initializer
            constructor()
            {
                super();
                this._instanceClaims = new ($.$$.System.Collections.Generic.List$$($.$ssc.System.Security.Claims.Claim))().$ctor$1();
                this._nameClaimType = "http://schemas.xmlsoap.org/ws/2005/05/identity/claims/name";
                this._roleClaimType = "http://schemas.microsoft.com/ws/2008/06/identity/claims/role";
            }
            //Static Initializer
            static $sinit()
            {
                {
                    this.DefaultIssuer = "LOCAL AUTHORITY";
                }
                {
                    this.DefaultNameClaimType = "http://schemas.xmlsoap.org/ws/2005/05/identity/claims/name";
                }
                {
                    this.DefaultRoleClaimType = "http://schemas.microsoft.com/ws/2008/06/identity/claims/role";
                }
            }
            static $h = 295390;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":1310721,"g":{"r":0,"d":0,"h":137439248862,"f":50331777},"n":"AuthenticationType","d":295390,"h":133144281566,"f":2097281},{"p":262145,"g":{"r":0,"d":0,"h":146029183454,"f":50331777},"n":"IsAuthenticated","d":295390,"h":141734216158,"f":2097281},{"p":295390,"g":{"r":0,"d":0,"h":154619118046,"f":50331649},"s":{"r":0,"d":0,"h":158914085342,"f":83886081},"n":"Actor","d":295390,"h":150324150750,"f":2097153},{"p":131073,"g":{"r":0,"d":0,"h":167504019934,"f":50331649},"s":{"r":0,"d":0,"h":171798987230,"f":83886081},"n":"BootstrapContext","d":295390,"h":163209052638,"f":2097153},{"p":$.$$.System.Collections.Generic.IEnumerable$$($.$ssc.System.Security.Claims.Claim).$h,"g":{"r":0,"d":0,"h":180388921822,"f":50331777},"n":"Claims","d":295390,"h":176093954526,"f":2097281},{"p":$.$typeArray($.$$.System.Byte).$h,"g":{"r":0,"d":0,"h":193273823710,"f":50331780},"n":"CustomSerializationData","d":295390,"h":188978856414,"f":2097284},{"p":$.$$.System.Collections.Generic.List$$($.$$.System.Collections.Generic.List$$($.$ssc.System.Security.Claims.Claim)).$h,"g":{"r":0,"d":0,"h":201863758302,"f":50331656},"n":"ExternalClaims","d":295390,"h":197568791006,"f":2097160},{"p":1310721,"g":{"r":0,"d":0,"h":210453692894,"f":50331649},"s":{"r":0,"d":0,"h":214748660190,"f":83886081},"n":"Label","d":295390,"h":206158725598,"f":2097153},{"p":1310721,"g":{"r":0,"d":0,"h":223338594782,"f":50331777},"n":"Name","d":295390,"h":219043627486,"f":2097281},{"p":1310721,"g":{"r":0,"d":0,"h":231928529374,"f":50331649},"n":"NameClaimType","d":295390,"h":227633562078,"f":2097153},{"p":1310721,"g":{"r":0,"d":0,"h":240518463966,"f":50331649},"n":"RoleClaimType","d":295390,"h":236223496670,"f":2097153}],"m":[{"r":$.$$.System.Collections.Generic.IEnumerable$$($.$ssc.System.Security.Claims.Claim).$h,"n":"CombinedClaimsIterator","d":295390,"h":184683889118,"f":16777218},{"r":295390,"n":"Clone","d":295390,"h":244813431262,"f":16777345},{"r":65537,"p":[{"n":"claim","p":164318}],"n":"AddClaim","d":295390,"h":249108398558,"f":16777345},{"r":65537,"p":[{"n":"claims","p":$.$$.System.Collections.Generic.IEnumerable$$($.$ssc.System.Security.Claims.Claim).$h}],"n":"AddClaims","d":295390,"h":253403365854,"f":16777345},{"r":262145,"p":[{"n":"claim","p":164318}],"n":"TryRemoveClaim","d":295390,"h":257698333150,"f":16777345},{"r":65537,"p":[{"n":"claim","p":164318}],"n":"RemoveClaim","d":295390,"h":261993300446,"f":16777345},{"r":65537,"p":[{"n":"claims","p":$.$$.System.Collections.Generic.IEnumerable$$($.$ssc.System.Security.Claims.Claim).$h}],"n":"SafeAddClaims","d":295390,"h":266288267742,"f":16777218},{"r":65537,"p":[{"n":"claim","p":164318}],"n":"SafeAddClaim","d":295390,"h":270583235038,"f":16777218},{"r":$.$$.System.Collections.Generic.IEnumerable$$($.$ssc.System.Security.Claims.Claim).$h,"p":[{"n":"match","p":$.$$.System.Predicate$$($.$ssc.System.Security.Claims.Claim).$h}],"n":"FindAll","d":295390,"h":274878202334,"f":16777345},{"r":$.$$.System.Collections.Generic.IEnumerable$$($.$ssc.System.Security.Claims.Claim).$h,"p":[{"n":"type","p":1310721}],"n":"FindAll","o":"@$1","d":295390,"h":279173169630,"f":16777345},{"r":164318,"p":[{"n":"match","p":$.$$.System.Predicate$$($.$ssc.System.Security.Claims.Claim).$h}],"n":"FindFirst","d":295390,"h":283468136926,"f":16777345},{"r":164318,"p":[{"n":"type","p":1310721}],"n":"FindFirst","o":"@$1","d":295390,"h":287763104222,"f":16777345},{"r":262145,"p":[{"n":"match","p":$.$$.System.Predicate$$($.$ssc.System.Security.Claims.Claim).$h}],"n":"HasClaim","d":295390,"h":292058071518,"f":16777345},{"r":262145,"p":[{"n":"type","p":1310721},{"n":"value","p":1310721}],"n":"HasClaim","o":"@$1","d":295390,"h":296353038814,"f":16777345},{"r":65537,"p":[{"n":"other","p":295390}],"n":"Initialize","o":"@$1","d":295390,"h":300648006110,"f":16777218},{"r":65537,"p":[{"n":"reader","p":58458113}],"n":"Initialize","d":295390,"h":304942973406,"f":16777218},{"r":164318,"p":[{"n":"reader","p":58458113}],"n":"CreateClaim","d":295390,"h":309237940702,"f":16777348},{"r":65537,"p":[{"n":"writer","p":58523649}],"n":"WriteTo","o":"@$1","d":295390,"h":313532907998,"f":16777345},{"r":65537,"p":[{"n":"writer","p":58523649},{"n":"userData","p":$.$typeArray($.$$.System.Byte).$h}],"n":"WriteTo","d":295390,"h":317827875294,"f":16777348},{"r":262145,"p":[{"n":"subject","p":295390}],"n":"IsCircular","d":295390,"h":322122842590,"f":16777218},{"r":65537,"p":[{"n":"info","p":113836033},{"n":"context","p":113967105}],"n":"GetObjectData","d":295390,"h":326417809886,"f":16777348},{"r":1310721,"n":"DebuggerToString","d":295390,"h":330712777182,"f":16777224},{"r":65537,"p":[{"n":"stringComparison","p":119341057}],"n":"ValidateStringComparison","d":295390,"h":335007744478,"f":16777250}],"l":[{"t":$.$typeArray($.$$.System.Byte).$h,"n":"_userSerializationData","d":295390,"h":8590229982,"f":4194306},{"t":295390,"n":"_actor","d":295390,"h":12885197278,"f":4194306},{"t":1310721,"n":"_authenticationType","d":295390,"h":17180164574,"f":4194306},{"t":131073,"n":"_bootstrapContext","d":295390,"h":21475131870,"f":4194306},{"t":$.$$.System.Collections.Generic.List$$($.$$.System.Collections.Generic.List$$($.$ssc.System.Security.Claims.Claim)).$h,"n":"_externalClaims","d":295390,"h":25770099166,"f":4194306},{"t":1310721,"n":"_label","d":295390,"h":30065066462,"f":4194306},{"t":$.$$.System.Collections.Generic.List$$($.$ssc.System.Security.Claims.Claim).$h,"n":"_instanceClaims","d":295390,"h":34360033758,"f":4194306},{"t":1310721,"n":"_nameClaimType","d":295390,"h":38655001054,"f":4194306},{"t":1310721,"n":"_roleClaimType","d":295390,"h":42949968350,"f":4194306},{"t":119341057,"n":"_stringComparison","d":295390,"h":47244935646,"f":4194306},{"t":1310721,"n":"DefaultIssuer","d":295390,"h":51539902942,"f":4194337},{"t":1310721,"n":"DefaultNameClaimType","d":295390,"h":55834870238,"f":4194337},{"t":1310721,"n":"DefaultRoleClaimType","d":295390,"h":60129837534,"f":4194337}],"c":[{"n":".ctor","o":"$ctor$1","d":295390,"h":64424804830,"f":16777217},{"p":[{"n":"identity","p":116916225}],"n":".ctor","o":"$ctor$12","d":295390,"h":68719772126,"f":16777217},{"p":[{"n":"claims","p":$.$$.System.Collections.Generic.IEnumerable$$($.$ssc.System.Security.Claims.Claim).$h}],"n":".ctor","o":"$ctor$4","d":295390,"h":73014739422,"f":16777217},{"p":[{"n":"authenticationType","p":1310721}],"n":".ctor","o":"$ctor$14","d":295390,"h":77309706718,"f":16777217},{"p":[{"n":"claims","p":$.$$.System.Collections.Generic.IEnumerable$$($.$ssc.System.Security.Claims.Claim).$h},{"n":"authenticationType","p":1310721}],"n":".ctor","o":"$ctor$3","d":295390,"h":81604674014,"f":16777217},{"p":[{"n":"identity","p":116916225},{"n":"claims","p":$.$$.System.Collections.Generic.IEnumerable$$($.$ssc.System.Security.Claims.Claim).$h}],"n":".ctor","o":"$ctor$11","d":295390,"h":85899641310,"f":16777217},{"p":[{"n":"authenticationType","p":1310721},{"n":"nameType","p":1310721},{"n":"roleType","p":1310721}],"n":".ctor","o":"$ctor$13","d":295390,"h":90194608606,"f":16777217},{"p":[{"n":"claims","p":$.$$.System.Collections.Generic.IEnumerable$$($.$ssc.System.Security.Claims.Claim).$h},{"n":"authenticationType","p":1310721},{"n":"nameType","p":1310721},{"n":"roleType","p":1310721}],"n":".ctor","o":"$ctor$2","d":295390,"h":94489575902,"f":16777217},{"p":[{"n":"identity","p":116916225},{"n":"claims","p":$.$$.System.Collections.Generic.IEnumerable$$($.$ssc.System.Security.Claims.Claim).$h},{"n":"authenticationType","p":1310721},{"n":"nameType","p":1310721},{"n":"roleType","p":1310721}],"n":".ctor","o":"$ctor$10","d":295390,"h":98784543198,"f":16777217},{"p":[{"n":"reader","p":58458113}],"n":".ctor","o":"$ctor$6","d":295390,"h":103079510494,"f":16777217},{"p":[{"n":"reader","p":58458113},{"n":"stringComparison","p":119341057}],"n":".ctor","o":"$ctor$5","d":295390,"h":107374477790,"f":16777217},{"p":[{"n":"other","p":295390}],"n":".ctor","o":"$ctor$16","d":295390,"h":111669445086,"f":16777220},{"p":[{"n":"other","p":295390},{"n":"stringComparison","p":119341057}],"n":".ctor","o":"$ctor$15","d":295390,"h":115964412382,"f":16777220},{"p":[{"n":"identity","p":116916225,"f":65},{"n":"claims","p":$.$$.System.Collections.Generic.IEnumerable$$($.$ssc.System.Security.Claims.Claim).$h,"f":65},{"n":"authenticationType","p":1310721,"f":65},{"n":"nameType","p":1310721,"f":65},{"n":"roleType","p":1310721,"f":65},{"n":"stringComparison","p":119341057,"f":65,"v":5}],"n":".ctor","o":"$ctor$9","d":295390,"h":120259379678,"f":16777217},{"p":[{"n":"info","p":113836033},{"n":"context","p":113967105}],"n":".ctor","o":"$ctor$7","d":295390,"h":124554346974,"f":16777220,"a":[{"t":70909953,"c":8660844545,"a":[{"v":"This API supports obsolete formatter-based serialization. It should not be called or extended by application code.","t":1310721}],"n":[{"n":"DiagnosticId","v":"SYSLIB0051","t":1310721},{"n":"UrlFormat","v":"https://aka.ms/dotnet-warnings/{0}","t":1310721}]},{"t":33292289,"c":4328259585,"a":[{"v":1,"t":33357825}]}]},{"p":[{"n":"info","p":113836033}],"n":".ctor","o":"$ctor$8","d":295390,"h":128849314270,"f":16777220,"a":[{"t":70909953,"c":8660844545,"a":[{"v":"This API supports obsolete formatter-based serialization. It should not be called or extended by application code.","t":1310721}],"n":[{"n":"DiagnosticId","v":"SYSLIB0051","t":1310721},{"n":"UrlFormat","v":"https://aka.ms/dotnet-warnings/{0}","t":1310721}]},{"t":33292289,"c":4328259585,"a":[{"v":1,"t":33357825}]}]}],"i":[116916225],"j":[360926],"h":295390,"a":[{"t":37617665,"c":8627552257,"a":[{"v":"{DebuggerToString(),nq}","t":1310721}]}]}; }
            static get $b() { return $.$$.System.Object; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.System.Security.Principal.IIdentity ]; }
            static get $fullName() { return `System.Security.Claims.ClaimsIdentity`; }
        });
        
        $asm.$cls("$ssc.System.Security.Principal.GenericPrincipal", ($self) => class GenericPrincipal extends $.$ssc.System.Security.Claims.ClaimsPrincipal
        {
            /*IIdentity*/ m_identity = null;
            /*string[]?*/ m_roles = null;
            $ctor$7(/*IIdentity*/ identity, /*string[]?*/ roles)
            {
                super.$ctor$1();
                {
                    $.$$.System.ArgumentNullException.ThrowIfNull$2(identity, "identity");
                    this.m_identity = identity;
                    if (roles !== null)
                    {
                        this.m_roles = $.$cast(roles.Clone(), $.$typeArray($.$$.System.String));
                    }
                    else 
                    {
                        this.m_roles = null;
                    }
                    this.AddIdentityWithRoles(this.m_identity, this.m_roles);
                }
                return this;
            }
            /*void */ AddIdentityWithRoles(/*IIdentity*/ identity, /*string[]?*/ roles)
            {
                let claimsIdentity;
                if ($.$is(identity, $.$ssc.System.Security.Claims.ClaimsIdentity, { set $v(v){ claimsIdentity = v; } }))
                {
                    claimsIdentity = claimsIdentity.Clone();
                }
                else 
                {
                    claimsIdentity = new $.$ssc.System.Security.Claims.ClaimsIdentity().$ctor$12(identity);
                }
                if (roles !== null && roles.length > 0)
                {
                    /*List<Claim>*/ let roleClaims = new ($.$$.System.Collections.Generic.List$$($.$ssc.System.Security.Claims.Claim))().$ctor$3(roles.length);
                    let $i1 = 0;
                    let $arr1 = roles;
                    while ($i1 < $arr1.length)
                    {
                        let role = $arr1[$i1++];
                        if (!$.$$.System.String.IsNullOrWhiteSpace(role))
                        {
                            roleClaims.Add(new $.$ssc.System.Security.Claims.Claim().$ctor$4(claimsIdentity.RoleClaimType, role, "http://www.w3.org/2001/XMLSchema#string"/*ClaimValueTypes.String*/, "LOCAL AUTHORITY"/*ClaimsIdentity.DefaultIssuer*/, "LOCAL AUTHORITY"/*ClaimsIdentity.DefaultIssuer*/, claimsIdentity));
                        }
                    }
                    claimsIdentity.ExternalClaims.Add(roleClaims);
                }
                super.AddIdentity(claimsIdentity);
            }
            /*IIdentity */ get Identity()
            {
                return this.m_identity;
            }
            /*bool */ IsInRole(/*string?*/ role)
            {
                if ($.$$.System.String.op_Equality(role, null) || this.m_roles === null)
                {
                    return false;
                }
                for(/*int*/ let i = 0; i < this.m_roles.length; ++i)
                {
                    if ($.$$.System.String.Equals$2($.$$.System.Array.$ReadT1.call(this.m_roles, i), role, 5/*StringComparison.OrdinalIgnoreCase*/))
                    {
                        return true;
                    }
                }
                return super.IsInRole(role);
            }
            static /*GenericPrincipal */ GetDefaultInstance()
            {
                return new $.$ssc.System.Security.Principal.GenericPrincipal().$ctor$7(new $.$ssc.System.Security.Principal.GenericIdentity().$ctor$18($.$$.System.String.Empty), $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$$.System.String), [$.$$.System.String.Empty], [-1], null));
            }
            static $h = 754142;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":426462,"p":[{"p":116916225,"g":{"r":0,"d":0,"h":25770557918,"f":50364417},"n":"Identity","d":754142,"h":21475590622,"f":2129921}],"m":[{"r":65537,"p":[{"n":"identity","p":116916225},{"n":"roles","p":$.$typeArray($.$$.System.String).$h}],"n":"AddIdentityWithRoles","d":754142,"h":17180623326,"f":16777218},{"r":262145,"p":[{"n":"role","p":1310721}],"n":"IsInRole","d":754142,"h":30065525214,"f":16809985},{"r":754142,"n":"GetDefaultInstance","d":754142,"h":34360492510,"f":16777250}],"l":[{"t":116916225,"n":"m_identity","d":754142,"h":4295721438,"f":4194306},{"t":$.$typeArray($.$$.System.String).$h,"n":"m_roles","d":754142,"h":8590688734,"f":4194306}],"c":[{"p":[{"n":"identity","p":116916225},{"n":"roles","p":$.$typeArray($.$$.System.String).$h}],"n":".ctor","o":"$ctor$7","d":754142,"h":12885656030,"f":16777217}],"i":[116981761],"h":754142}; }
            static get $b() { return $.$ssc.System.Security.Claims.ClaimsPrincipal; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.System.Security.Principal.IPrincipal ]; }
            static get $fullName() { return `System.Security.Principal.GenericPrincipal`; }
        });
        
        $asm.$cls("$ssc.System.Security.Principal.GenericIdentity", ($self) => class GenericIdentity extends $.$ssc.System.Security.Claims.ClaimsIdentity
        {
            /*string*/ m_name = null;
            /*string*/ m_type = null;
            $ctor$18(/*string*/ name)
            {
                super.$ctor$9(null, null, null, null, null, 5);
                {
                    $.$$.System.ArgumentNullException.ThrowIfNull$2(name, "name");
                    this.m_name = name;
                    this.m_type = "";
                    this.AddNameClaim();
                }
                return this;
            }
            $ctor$17(/*string*/ name, /*string*/ type)
            {
                super.$ctor$9(null, null, null, null, null, 5);
                {
                    $.$$.System.ArgumentNullException.ThrowIfNull$2(name, "name");
                    $.$$.System.ArgumentNullException.ThrowIfNull$2(type, "type");
                    this.m_name = name;
                    this.m_type = type;
                    this.AddNameClaim();
                }
                return this;
            }
            $ctor$19(/*GenericIdentity*/ identity)
            {
                super.$ctor$16(identity);
                {
                    this.m_name = identity.m_name;
                    this.m_type = identity.m_type;
                }
                return this;
            }
            /*ClaimsIdentity */ Clone()
            {
                return new $.$ssc.System.Security.Principal.GenericIdentity().$ctor$19(this);
            }
            /*IEnumerable<Claim> */ get Claims()
            {
                return super.Claims;
            }
            /*string */ get Name()
            {
                return this.m_name;
            }
            /*string */ get AuthenticationType()
            {
                return this.m_type;
            }
            /*bool */ get IsAuthenticated()
            {
                return !$.$$.System.String.Equals$5.call(this.m_name, "");
            }
            /*void */ AddNameClaim()
            {
                if ($.$$.System.String.op_Inequality(this.m_name, null))
                {
                    super.AddClaim(new $.$ssc.System.Security.Claims.Claim().$ctor$4(super.NameClaimType, this.m_name, "http://www.w3.org/2001/XMLSchema#string"/*ClaimValueTypes.String*/, "LOCAL AUTHORITY"/*ClaimsIdentity.DefaultIssuer*/, "LOCAL AUTHORITY"/*ClaimsIdentity.DefaultIssuer*/, this));
                }
            }
            static $h = 688606;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":295390,"p":[{"p":$.$$.System.Collections.Generic.IEnumerable$$($.$ssc.System.Security.Claims.Claim).$h,"g":{"r":0,"d":0,"h":34360426974,"f":50364417},"n":"Claims","d":688606,"h":30065459678,"f":2129921},{"p":1310721,"g":{"r":0,"d":0,"h":42950361566,"f":50364417},"n":"Name","d":688606,"h":38655394270,"f":2129921},{"p":1310721,"g":{"r":0,"d":0,"h":51540296158,"f":50364417},"n":"AuthenticationType","d":688606,"h":47245328862,"f":2129921},{"p":262145,"g":{"r":0,"d":0,"h":60130230750,"f":50364417},"n":"IsAuthenticated","d":688606,"h":55835263454,"f":2129921}],"m":[{"r":295390,"n":"Clone","d":688606,"h":25770492382,"f":16809985},{"r":65537,"n":"AddNameClaim","d":688606,"h":64425198046,"f":16777218}],"l":[{"t":1310721,"n":"m_name","d":688606,"h":4295655902,"f":4194306},{"t":1310721,"n":"m_type","d":688606,"h":8590623198,"f":4194306}],"c":[{"p":[{"n":"name","p":1310721}],"n":".ctor","o":"$ctor$18","d":688606,"h":12885590494,"f":16777217},{"p":[{"n":"name","p":1310721},{"n":"type","p":1310721}],"n":".ctor","o":"$ctor$17","d":688606,"h":17180557790,"f":16777217},{"p":[{"n":"identity","p":688606}],"n":".ctor","o":"$ctor$19","d":688606,"h":21475525086,"f":16777220}],"i":[116916225],"h":688606}; }
            static get $b() { return $.$ssc.System.Security.Claims.ClaimsIdentity; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.System.Security.Principal.IIdentity ]; }
            static get $fullName() { return `System.Security.Principal.GenericIdentity`; }
        });
	});
})(window, window.NetJs.$boot(), ...window.NetJs.$require("NetJs.System.Private.CoreLib", "NetJs.System.Collections", "NetJs.System.Memory", "NetJs.System.Private.Uri", "NetJs.System.Runtime", "NetJs.System.Threading.Thread"))