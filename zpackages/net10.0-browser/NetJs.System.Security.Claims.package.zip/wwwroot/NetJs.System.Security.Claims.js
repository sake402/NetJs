
//--TRIMMABLE-BOUNDARY-START(69)
(function ($global, $, $$, $sc, $sm, $spu, $sr, $stt) {
    "use strict";
    let _;
    
    
    
	$.$asm(
    "NetJs.System.Security.Claims", 
    {
  "h": 69,
  "f": "System.Security.Claims",
  "v": "1.0.35.0",
  "a": [
    {
      "t": 159252481,
      "c": 13044154369,
      "a": [
        {
          "v": ".NETCoreApp,Version=v10.0",
          "t": 1310721
        }
      ],
      "n": [
        {
          "n": "FrameworkDisplayName",
          "v": ".NET 10.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 106430465,
      "c": 8696365057,
      "a": [
        {
          "v": "SIT",
          "t": 1310721
        }
      ]
    },
    {
      "t": 106496001,
      "c": 8696430593,
      "a": [
        {
          "v": "Debug",
          "t": 1310721
        }
      ]
    },
    {
      "t": 106954753,
      "c": 8696889345,
      "a": [
        {
          "v": "1.0.35.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107085825,
      "c": 8697020417,
      "a": [
        {
          "v": "1.0.35\u002Bdf6f45b09d58f65c84d384efc8772929a0c6464b",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107937793,
      "c": 8697872385,
      "a": [
        {
          "v": "NetJs.System.Security.Claims",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108068865,
      "c": 8698003457,
      "a": [
        {
          "v": "NetJs.System.Security.Claims",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108199937,
      "c": 8698134529,
      "a": [
        {
          "v": "1.0.35.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 159318017,
      "c": 4454285313,
      "a": [
        {
          "v": "browser1.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 159055873,
      "c": 4454023169,
      "a": [
        {
          "v": "browser1.0",
          "t": 1310721
        }
      ]
    }
  ],
  "m": []
},
    function($asm)
	{
        
        
        //--TRIMMABLE-BOUNDARY-START(65605)
        $asm.$cls("$ssc.System.Obsoletions", ($self) => class Obsoletions
        {
            //--TRIMMABLE-BOUNDARY-START(382252154949)
            /*string*/ static SharedUrlFormat = null;
            //--TRIMMABLE-BOUNDARY-END(382252154949)
            
            //--TRIMMABLE-BOUNDARY-START(433791762501)
            /*string*/ static SystemTextEncodingUTF7Message = null;
            //--TRIMMABLE-BOUNDARY-END(433791762501)
            
            //--TRIMMABLE-BOUNDARY-START(429496795205)
            /*string*/ static SystemTextEncodingUTF7DiagId = null;
            //--TRIMMABLE-BOUNDARY-END(429496795205)
            
            //--TRIMMABLE-BOUNDARY-START(266288037957)
            /*string*/ static PrincipalPermissionAttributeMessage = null;
            //--TRIMMABLE-BOUNDARY-END(266288037957)
            
            //--TRIMMABLE-BOUNDARY-START(261993070661)
            /*string*/ static PrincipalPermissionAttributeDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(261993070661)
            
            //--TRIMMABLE-BOUNDARY-START(77309476933)
            /*string*/ static CodeAccessSecurityMessage = null;
            //--TRIMMABLE-BOUNDARY-END(77309476933)
            
            //--TRIMMABLE-BOUNDARY-START(73014509637)
            /*string*/ static CodeAccessSecurityDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(73014509637)
            
            //--TRIMMABLE-BOUNDARY-START(94489346117)
            /*string*/ static ConstrainedExecutionRegionMessage = null;
            //--TRIMMABLE-BOUNDARY-END(94489346117)
            
            //--TRIMMABLE-BOUNDARY-START(90194378821)
            /*string*/ static ConstrainedExecutionRegionDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(90194378821)
            
            //--TRIMMABLE-BOUNDARY-START(214748430405)
            /*string*/ static GlobalAssemblyCacheMessage = null;
            //--TRIMMABLE-BOUNDARY-END(214748430405)
            
            //--TRIMMABLE-BOUNDARY-START(210453463109)
            /*string*/ static GlobalAssemblyCacheDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(210453463109)
            
            //--TRIMMABLE-BOUNDARY-START(442381697093)
            /*string*/ static ThreadAbortMessage = null;
            //--TRIMMABLE-BOUNDARY-END(442381697093)
            
            //--TRIMMABLE-BOUNDARY-START(446676664389)
            /*string*/ static ThreadResetAbortMessage = null;
            //--TRIMMABLE-BOUNDARY-END(446676664389)
            
            //--TRIMMABLE-BOUNDARY-START(438086729797)
            /*string*/ static ThreadAbortDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(438086729797)
            
            //--TRIMMABLE-BOUNDARY-START(146028953669)
            /*string*/ static DefaultCryptoAlgorithmsMessage = null;
            //--TRIMMABLE-BOUNDARY-END(146028953669)
            
            //--TRIMMABLE-BOUNDARY-START(141733986373)
            /*string*/ static DefaultCryptoAlgorithmsDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(141733986373)
            
            //--TRIMMABLE-BOUNDARY-START(120259149893)
            /*string*/ static CreatePdbGeneratorMessage = null;
            //--TRIMMABLE-BOUNDARY-END(120259149893)
            
            //--TRIMMABLE-BOUNDARY-START(115964182597)
            /*string*/ static CreatePdbGeneratorDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(115964182597)
            
            //--TRIMMABLE-BOUNDARY-START(51539673157)
            /*string*/ static AuthenticationManagerMessage = null;
            //--TRIMMABLE-BOUNDARY-END(51539673157)
            
            //--TRIMMABLE-BOUNDARY-START(47244705861)
            /*string*/ static AuthenticationManagerDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(47244705861)
            
            //--TRIMMABLE-BOUNDARY-START(326417580101)
            /*string*/ static RemotingApisMessage = null;
            //--TRIMMABLE-BOUNDARY-END(326417580101)
            
            //--TRIMMABLE-BOUNDARY-START(322122612805)
            /*string*/ static RemotingApisDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(322122612805)
            
            //--TRIMMABLE-BOUNDARY-START(60129607749)
            /*string*/ static BinaryFormatterMessage = null;
            //--TRIMMABLE-BOUNDARY-END(60129607749)
            
            //--TRIMMABLE-BOUNDARY-START(55834640453)
            /*string*/ static BinaryFormatterDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(55834640453)
            
            //--TRIMMABLE-BOUNDARY-START(85899411525)
            /*string*/ static CodeBaseMessage = null;
            //--TRIMMABLE-BOUNDARY-END(85899411525)
            
            //--TRIMMABLE-BOUNDARY-START(81604444229)
            /*string*/ static CodeBaseDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(81604444229)
            
            //--TRIMMABLE-BOUNDARY-START(197568561221)
            /*string*/ static EscapeUriStringMessage = null;
            //--TRIMMABLE-BOUNDARY-END(197568561221)
            
            //--TRIMMABLE-BOUNDARY-START(193273593925)
            /*string*/ static EscapeUriStringDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(193273593925)
            
            //--TRIMMABLE-BOUNDARY-START(489626337349)
            /*string*/ static WebRequestMessage = null;
            //--TRIMMABLE-BOUNDARY-END(489626337349)
            
            //--TRIMMABLE-BOUNDARY-START(485331370053)
            /*string*/ static WebRequestDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(485331370053)
            
            //--TRIMMABLE-BOUNDARY-START(163208822853)
            /*string*/ static DisablePrivateReflectionAttributeMessage = null;
            //--TRIMMABLE-BOUNDARY-END(163208822853)
            
            //--TRIMMABLE-BOUNDARY-START(158913855557)
            /*string*/ static DisablePrivateReflectionAttributeDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(158913855557)
            
            //--TRIMMABLE-BOUNDARY-START(206158495813)
            /*string*/ static GetContextInfoMessage = null;
            //--TRIMMABLE-BOUNDARY-END(206158495813)
            
            //--TRIMMABLE-BOUNDARY-START(201863528517)
            /*string*/ static GetContextInfoDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(201863528517)
            
            //--TRIMMABLE-BOUNDARY-START(399432024133)
            /*string*/ static StrongNameKeyPairMessage = null;
            //--TRIMMABLE-BOUNDARY-END(399432024133)
            
            //--TRIMMABLE-BOUNDARY-START(395137056837)
            /*string*/ static StrongNameKeyPairDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(395137056837)
            
            //--TRIMMABLE-BOUNDARY-START(300647776325)
            /*string*/ static ReflectionOnlyLoadingMessage = null;
            //--TRIMMABLE-BOUNDARY-END(300647776325)
            
            //--TRIMMABLE-BOUNDARY-START(296352809029)
            /*string*/ static ReflectionOnlyLoadingDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(296352809029)
            
            //--TRIMMABLE-BOUNDARY-START(377957187653)
            /*string*/ static RuntimeEnvironmentMessage = null;
            //--TRIMMABLE-BOUNDARY-END(377957187653)
            
            //--TRIMMABLE-BOUNDARY-START(373662220357)
            /*string*/ static RuntimeEnvironmentDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(373662220357)
            
            //--TRIMMABLE-BOUNDARY-START(231928299589)
            /*string*/ static JsonSerializerOptionsIgnoreNullValuesMessage = null;
            //--TRIMMABLE-BOUNDARY-END(231928299589)
            
            //--TRIMMABLE-BOUNDARY-START(227633332293)
            /*string*/ static JsonSerializerOptionsIgnoreNullValuesDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(227633332293)
            
            //--TRIMMABLE-BOUNDARY-START(154618888261)
            /*string*/ static DerivedCryptographicTypesMessage = null;
            //--TRIMMABLE-BOUNDARY-END(154618888261)
            
            //--TRIMMABLE-BOUNDARY-START(150323920965)
            /*string*/ static DerivedCryptographicTypesDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(150323920965)
            
            //--TRIMMABLE-BOUNDARY-START(352187383877)
            /*string*/ static RijndaelMessage = null;
            //--TRIMMABLE-BOUNDARY-END(352187383877)
            
            //--TRIMMABLE-BOUNDARY-START(347892416581)
            /*string*/ static RijndaelDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(347892416581)
            
            //--TRIMMABLE-BOUNDARY-START(360777318469)
            /*string*/ static RNGCryptoServiceProviderMessage = null;
            //--TRIMMABLE-BOUNDARY-END(360777318469)
            
            //--TRIMMABLE-BOUNDARY-START(356482351173)
            /*string*/ static RNGCryptoServiceProviderDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(356482351173)
            
            //--TRIMMABLE-BOUNDARY-START(17179934789)
            /*string*/ static AppDomainCreateUnloadMessage = null;
            //--TRIMMABLE-BOUNDARY-END(17179934789)
            
            //--TRIMMABLE-BOUNDARY-START(12884967493)
            /*string*/ static AppDomainCreateUnloadDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(12884967493)
            
            //--TRIMMABLE-BOUNDARY-START(408021958725)
            /*string*/ static SuppressIldasmAttributeMessage = null;
            //--TRIMMABLE-BOUNDARY-END(408021958725)
            
            //--TRIMMABLE-BOUNDARY-START(403726991429)
            /*string*/ static SuppressIldasmAttributeDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(403726991429)
            
            //--TRIMMABLE-BOUNDARY-START(498216271941)
            /*string*/ static X509CertificateImmutableMessage = null;
            //--TRIMMABLE-BOUNDARY-END(498216271941)
            
            //--TRIMMABLE-BOUNDARY-START(493921304645)
            /*string*/ static X509CertificateImmutableDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(493921304645)
            
            //--TRIMMABLE-BOUNDARY-START(283467907141)
            /*string*/ static PublicKeyPropertyMessage = null;
            //--TRIMMABLE-BOUNDARY-END(283467907141)
            
            //--TRIMMABLE-BOUNDARY-START(279172939845)
            /*string*/ static PublicKeyPropertyDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(279172939845)
            
            //--TRIMMABLE-BOUNDARY-START(506806206533)
            /*string*/ static X509CertificatePrivateKeyMessage = null;
            //--TRIMMABLE-BOUNDARY-END(506806206533)
            
            //--TRIMMABLE-BOUNDARY-START(502511239237)
            /*string*/ static X509CertificatePrivateKeyDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(502511239237)
            
            //--TRIMMABLE-BOUNDARY-START(274877972549)
            /*string*/ static ProduceLegacyHmacValuesMessage = null;
            //--TRIMMABLE-BOUNDARY-END(274877972549)
            
            //--TRIMMABLE-BOUNDARY-START(270583005253)
            /*string*/ static ProduceLegacyHmacValuesDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(270583005253)
            
            //--TRIMMABLE-BOUNDARY-START(481036402757)
            /*string*/ static UseManagedSha1Message = null;
            //--TRIMMABLE-BOUNDARY-END(481036402757)
            
            //--TRIMMABLE-BOUNDARY-START(476741435461)
            /*string*/ static UseManagedSha1DiagId = null;
            //--TRIMMABLE-BOUNDARY-END(476741435461)
            
            //--TRIMMABLE-BOUNDARY-START(128849084485)
            /*string*/ static CryptoConfigEncodeOIDMessage = null;
            //--TRIMMABLE-BOUNDARY-END(128849084485)
            
            //--TRIMMABLE-BOUNDARY-START(124554117189)
            /*string*/ static CryptoConfigEncodeOIDDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(124554117189)
            
            //--TRIMMABLE-BOUNDARY-START(111669215301)
            /*string*/ static CorruptedStateRecoveryMessage = null;
            //--TRIMMABLE-BOUNDARY-END(111669215301)
            
            //--TRIMMABLE-BOUNDARY-START(107374248005)
            /*string*/ static CorruptedStateRecoveryDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(107374248005)
            
            //--TRIMMABLE-BOUNDARY-START(335007514693)
            /*string*/ static Rfc2898CryptDeriveKeyMessage = null;
            //--TRIMMABLE-BOUNDARY-END(335007514693)
            
            //--TRIMMABLE-BOUNDARY-START(330712547397)
            /*string*/ static Rfc2898CryptDeriveKeyDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(330712547397)
            
            //--TRIMMABLE-BOUNDARY-START(68719542341)
            /*string*/ static CmsSignerCspParamsCtorMessage = null;
            //--TRIMMABLE-BOUNDARY-END(68719542341)
            
            //--TRIMMABLE-BOUNDARY-START(64424575045)
            /*string*/ static CmsSignerCspParamsCtorDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(64424575045)
            
            //--TRIMMABLE-BOUNDARY-START(390842089541)
            /*string*/ static SignerInfoCounterSigMessage = null;
            //--TRIMMABLE-BOUNDARY-END(390842089541)
            
            //--TRIMMABLE-BOUNDARY-START(386547122245)
            /*string*/ static SignerInfoCounterSigDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(386547122245)
            
            //--TRIMMABLE-BOUNDARY-START(309237710917)
            /*string*/ static RegexCompileToAssemblyMessage = null;
            //--TRIMMABLE-BOUNDARY-END(309237710917)
            
            //--TRIMMABLE-BOUNDARY-START(304942743621)
            /*string*/ static RegexCompileToAssemblyDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(304942743621)
            
            //--TRIMMABLE-BOUNDARY-START(42949738565)
            /*string*/ static AssemblyNameMembersMessage = null;
            //--TRIMMABLE-BOUNDARY-END(42949738565)
            
            //--TRIMMABLE-BOUNDARY-START(38654771269)
            /*string*/ static AssemblyNameMembersDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(38654771269)
            
            //--TRIMMABLE-BOUNDARY-START(416611893317)
            /*string*/ static SystemDataSerializationFormatBinaryMessage = null;
            //--TRIMMABLE-BOUNDARY-END(416611893317)
            
            //--TRIMMABLE-BOUNDARY-START(412316926021)
            /*string*/ static SystemDataSerializationFormatBinaryDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(412316926021)
            
            //--TRIMMABLE-BOUNDARY-START(472446468165)
            /*string*/ static TlsVersion10and11Message = null;
            //--TRIMMABLE-BOUNDARY-END(472446468165)
            
            //--TRIMMABLE-BOUNDARY-START(468151500869)
            /*string*/ static TlsVersion10and11DiagId = null;
            //--TRIMMABLE-BOUNDARY-END(468151500869)
            
            //--TRIMMABLE-BOUNDARY-START(188978626629)
            /*string*/ static EncryptionPolicyMessage = null;
            //--TRIMMABLE-BOUNDARY-END(188978626629)
            
            //--TRIMMABLE-BOUNDARY-START(184683659333)
            /*string*/ static EncryptionPolicyDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(184683659333)
            
            //--TRIMMABLE-BOUNDARY-START(171798757445)
            /*string*/ static EccXmlExportImportMessage = null;
            //--TRIMMABLE-BOUNDARY-END(171798757445)
            
            //--TRIMMABLE-BOUNDARY-START(167503790149)
            /*string*/ static EccXmlExportImportDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(167503790149)
            
            //--TRIMMABLE-BOUNDARY-START(180388692037)
            /*string*/ static EcDhPublicKeyBlobMessage = null;
            //--TRIMMABLE-BOUNDARY-END(180388692037)
            
            //--TRIMMABLE-BOUNDARY-START(176093724741)
            /*string*/ static EcDhPublicKeyBlobDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(176093724741)
            
            //--TRIMMABLE-BOUNDARY-START(34359803973)
            /*string*/ static AssemblyNameCodeBaseMessage = null;
            //--TRIMMABLE-BOUNDARY-END(34359803973)
            
            //--TRIMMABLE-BOUNDARY-START(30064836677)
            /*string*/ static AssemblyNameCodeBaseDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(30064836677)
            
            //--TRIMMABLE-BOUNDARY-START(137439019077)
            /*string*/ static CryptoStringFactoryMessage = null;
            //--TRIMMABLE-BOUNDARY-END(137439019077)
            
            //--TRIMMABLE-BOUNDARY-START(133144051781)
            /*string*/ static CryptoStringFactoryDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(133144051781)
            
            //--TRIMMABLE-BOUNDARY-START(103079280709)
            /*string*/ static ControlledExecutionRunMessage = null;
            //--TRIMMABLE-BOUNDARY-END(103079280709)
            
            //--TRIMMABLE-BOUNDARY-START(98784313413)
            /*string*/ static ControlledExecutionRunDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(98784313413)
            
            //--TRIMMABLE-BOUNDARY-START(523986075717)
            /*string*/ static XmlSecureResolverMessage = null;
            //--TRIMMABLE-BOUNDARY-END(523986075717)
            
            //--TRIMMABLE-BOUNDARY-START(519691108421)
            /*string*/ static XmlSecureResolverDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(519691108421)
            
            //--TRIMMABLE-BOUNDARY-START(369367253061)
            /*string*/ static RsaEncryptDecryptValueMessage = null;
            //--TRIMMABLE-BOUNDARY-END(369367253061)
            
            //--TRIMMABLE-BOUNDARY-START(365072285765)
            /*string*/ static RsaEncryptDecryptDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(365072285765)
            
            //--TRIMMABLE-BOUNDARY-START(223338364997)
            /*string*/ static JsonSerializerOptionsAddContextMessage = null;
            //--TRIMMABLE-BOUNDARY-END(223338364997)
            
            //--TRIMMABLE-BOUNDARY-START(219043397701)
            /*string*/ static JsonSerializerOptionsAddContextDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(219043397701)
            
            //--TRIMMABLE-BOUNDARY-START(249108168773)
            /*string*/ static LegacyFormatterMessage = null;
            //--TRIMMABLE-BOUNDARY-END(249108168773)
            
            //--TRIMMABLE-BOUNDARY-START(236223266885)
            /*string*/ static LegacyFormatterDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(236223266885)
            
            //--TRIMMABLE-BOUNDARY-START(244813201477)
            /*string*/ static LegacyFormatterImplMessage = null;
            //--TRIMMABLE-BOUNDARY-END(244813201477)
            
            //--TRIMMABLE-BOUNDARY-START(240518234181)
            /*string*/ static LegacyFormatterImplDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(240518234181)
            
            //--TRIMMABLE-BOUNDARY-START(317827645509)
            /*string*/ static RegexExtensibilityImplMessage = null;
            //--TRIMMABLE-BOUNDARY-END(317827645509)
            
            //--TRIMMABLE-BOUNDARY-START(313532678213)
            /*string*/ static RegexExtensibilityDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(313532678213)
            
            //--TRIMMABLE-BOUNDARY-START(8590000197)
            /*string*/ static AesGcmTagConstructorMessage = null;
            //--TRIMMABLE-BOUNDARY-END(8590000197)
            
            //--TRIMMABLE-BOUNDARY-START(4295032901)
            /*string*/ static AesGcmTagConstructorDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(4295032901)
            
            //--TRIMMABLE-BOUNDARY-START(455266598981)
            /*string*/ static ThreadVolatileReadWriteMessage = null;
            //--TRIMMABLE-BOUNDARY-END(455266598981)
            
            //--TRIMMABLE-BOUNDARY-START(450971631685)
            /*string*/ static ThreadVolatileReadWriteDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(450971631685)
            
            //--TRIMMABLE-BOUNDARY-START(25769869381)
            /*string*/ static ArmIntrinsicPerformsUnsignedOperationMessage = null;
            //--TRIMMABLE-BOUNDARY-END(25769869381)
            
            //--TRIMMABLE-BOUNDARY-START(21474902085)
            /*string*/ static ArmIntrinsicPerformsUnsignedOperationDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(21474902085)
            
            //--TRIMMABLE-BOUNDARY-START(257698103365)
            /*string*/ static LoadFromHashAlgorithmMessage = null;
            //--TRIMMABLE-BOUNDARY-END(257698103365)
            
            //--TRIMMABLE-BOUNDARY-START(253403136069)
            /*string*/ static LoadFromHashAlgorithmDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(253403136069)
            
            //--TRIMMABLE-BOUNDARY-START(515396141125)
            /*string*/ static X509CtorCertDataObsoleteMessage = null;
            //--TRIMMABLE-BOUNDARY-END(515396141125)
            
            //--TRIMMABLE-BOUNDARY-START(511101173829)
            /*string*/ static X509CtorCertDataObsoleteDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(511101173829)
            
            //--TRIMMABLE-BOUNDARY-START(463856533573)
            /*string*/ static TlsCipherAlgorithmEnumsMessage = null;
            //--TRIMMABLE-BOUNDARY-END(463856533573)
            
            //--TRIMMABLE-BOUNDARY-START(459561566277)
            /*string*/ static TlsCipherAlgorithmEnumsDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(459561566277)
            
            //--TRIMMABLE-BOUNDARY-START(425201827909)
            /*string*/ static SystemEventsEventsThreadShutdownMessage = null;
            //--TRIMMABLE-BOUNDARY-END(425201827909)
            
            //--TRIMMABLE-BOUNDARY-START(420906860613)
            /*string*/ static SystemEventsEventsThreadShutdownDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(420906860613)
            
            //--TRIMMABLE-BOUNDARY-START(343597449285)
            /*string*/ static Rfc2898DeriveBytesCtorMessage = null;
            //--TRIMMABLE-BOUNDARY-END(343597449285)
            
            //--TRIMMABLE-BOUNDARY-START(339302481989)
            /*string*/ static Rfc2898DeriveBytesCtorDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(339302481989)
            
            //--TRIMMABLE-BOUNDARY-START(292057841733)
            /*string*/ static QueryableMinByMaxByTSourceObsoleteMessage = null;
            //--TRIMMABLE-BOUNDARY-END(292057841733)
            
            //--TRIMMABLE-BOUNDARY-START(287762874437)
            /*string*/ static QueryableMinByMaxByTSourceObsoleteDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(287762874437)
            
            //--TRIMMABLE-BOUNDARY-START(532576010309)
            /*string*/ static XsltSettingsEnableScriptMessage = null;
            //--TRIMMABLE-BOUNDARY-END(532576010309)
            
            //--TRIMMABLE-BOUNDARY-START(528281043013)
            /*string*/ static XsltSettingsEnableScriptDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(528281043013)
            
            //--TRIMMABLE-BOUNDARY-START(SINIT)
            //Static Initializer
            static $sinit()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(382252154949)
                    this.SharedUrlFormat = "https://aka.ms/dotnet-warnings/{0}";
                    //--TRIMMABLE-BOUNDARY-END(382252154949)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(433791762501)
                    this.SystemTextEncodingUTF7Message = "The UTF-7 encoding is insecure and should not be used. Consider using UTF-8 instead.";
                    //--TRIMMABLE-BOUNDARY-END(433791762501)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(429496795205)
                    this.SystemTextEncodingUTF7DiagId = "SYSLIB0001";
                    //--TRIMMABLE-BOUNDARY-END(429496795205)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(266288037957)
                    this.PrincipalPermissionAttributeMessage = "PrincipalPermissionAttribute is not honored by the runtime and must not be used.";
                    //--TRIMMABLE-BOUNDARY-END(266288037957)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(261993070661)
                    this.PrincipalPermissionAttributeDiagId = "SYSLIB0002";
                    //--TRIMMABLE-BOUNDARY-END(261993070661)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(77309476933)
                    this.CodeAccessSecurityMessage = "Code Access Security is not supported or honored by the runtime.";
                    //--TRIMMABLE-BOUNDARY-END(77309476933)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(73014509637)
                    this.CodeAccessSecurityDiagId = "SYSLIB0003";
                    //--TRIMMABLE-BOUNDARY-END(73014509637)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(94489346117)
                    this.ConstrainedExecutionRegionMessage = "The Constrained Execution Region (CER) feature is not supported.";
                    //--TRIMMABLE-BOUNDARY-END(94489346117)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(90194378821)
                    this.ConstrainedExecutionRegionDiagId = "SYSLIB0004";
                    //--TRIMMABLE-BOUNDARY-END(90194378821)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(214748430405)
                    this.GlobalAssemblyCacheMessage = "The Global Assembly Cache is not supported.";
                    //--TRIMMABLE-BOUNDARY-END(214748430405)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(210453463109)
                    this.GlobalAssemblyCacheDiagId = "SYSLIB0005";
                    //--TRIMMABLE-BOUNDARY-END(210453463109)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(442381697093)
                    this.ThreadAbortMessage = "Thread.Abort is not supported and throws PlatformNotSupportedException.";
                    //--TRIMMABLE-BOUNDARY-END(442381697093)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(446676664389)
                    this.ThreadResetAbortMessage = "Thread.ResetAbort is not supported and throws PlatformNotSupportedException.";
                    //--TRIMMABLE-BOUNDARY-END(446676664389)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(438086729797)
                    this.ThreadAbortDiagId = "SYSLIB0006";
                    //--TRIMMABLE-BOUNDARY-END(438086729797)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(146028953669)
                    this.DefaultCryptoAlgorithmsMessage = "The default implementation of this cryptography algorithm is not supported.";
                    //--TRIMMABLE-BOUNDARY-END(146028953669)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(141733986373)
                    this.DefaultCryptoAlgorithmsDiagId = "SYSLIB0007";
                    //--TRIMMABLE-BOUNDARY-END(141733986373)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(120259149893)
                    this.CreatePdbGeneratorMessage = "The CreatePdbGenerator API is not supported and throws PlatformNotSupportedException.";
                    //--TRIMMABLE-BOUNDARY-END(120259149893)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(115964182597)
                    this.CreatePdbGeneratorDiagId = "SYSLIB0008";
                    //--TRIMMABLE-BOUNDARY-END(115964182597)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(51539673157)
                    this.AuthenticationManagerMessage = "AuthenticationManager is not supported. Methods will no-op or throw PlatformNotSupportedException.";
                    //--TRIMMABLE-BOUNDARY-END(51539673157)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(47244705861)
                    this.AuthenticationManagerDiagId = "SYSLIB0009";
                    //--TRIMMABLE-BOUNDARY-END(47244705861)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(326417580101)
                    this.RemotingApisMessage = "This Remoting API is not supported and throws PlatformNotSupportedException.";
                    //--TRIMMABLE-BOUNDARY-END(326417580101)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(322122612805)
                    this.RemotingApisDiagId = "SYSLIB0010";
                    //--TRIMMABLE-BOUNDARY-END(322122612805)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(60129607749)
                    this.BinaryFormatterMessage = "BinaryFormatter serialization is obsolete and should not be used. See https://aka.ms/binaryformatter for more information.";
                    //--TRIMMABLE-BOUNDARY-END(60129607749)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(55834640453)
                    this.BinaryFormatterDiagId = "SYSLIB0011";
                    //--TRIMMABLE-BOUNDARY-END(55834640453)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(85899411525)
                    this.CodeBaseMessage = "Assembly.CodeBase and Assembly.EscapedCodeBase are only included for .NET Framework compatibility. Use Assembly.Location instead.";
                    //--TRIMMABLE-BOUNDARY-END(85899411525)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(81604444229)
                    this.CodeBaseDiagId = "SYSLIB0012";
                    //--TRIMMABLE-BOUNDARY-END(81604444229)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(197568561221)
                    this.EscapeUriStringMessage = "Uri.EscapeUriString can corrupt the Uri string in some cases. Consider using Uri.EscapeDataString for query string components instead.";
                    //--TRIMMABLE-BOUNDARY-END(197568561221)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(193273593925)
                    this.EscapeUriStringDiagId = "SYSLIB0013";
                    //--TRIMMABLE-BOUNDARY-END(193273593925)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(489626337349)
                    this.WebRequestMessage = "WebRequest, HttpWebRequest, ServicePoint, and WebClient are obsolete. Use HttpClient instead.";
                    //--TRIMMABLE-BOUNDARY-END(489626337349)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(485331370053)
                    this.WebRequestDiagId = "SYSLIB0014";
                    //--TRIMMABLE-BOUNDARY-END(485331370053)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(163208822853)
                    this.DisablePrivateReflectionAttributeMessage = "DisablePrivateReflectionAttribute has no effect in .NET 6.0+.";
                    //--TRIMMABLE-BOUNDARY-END(163208822853)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(158913855557)
                    this.DisablePrivateReflectionAttributeDiagId = "SYSLIB0015";
                    //--TRIMMABLE-BOUNDARY-END(158913855557)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(206158495813)
                    this.GetContextInfoMessage = "Use the Graphics.GetContextInfo overloads that accept arguments for better performance and fewer allocations.";
                    //--TRIMMABLE-BOUNDARY-END(206158495813)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(201863528517)
                    this.GetContextInfoDiagId = "SYSLIB0016";
                    //--TRIMMABLE-BOUNDARY-END(201863528517)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(399432024133)
                    this.StrongNameKeyPairMessage = "Strong name signing is not supported and throws PlatformNotSupportedException.";
                    //--TRIMMABLE-BOUNDARY-END(399432024133)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(395137056837)
                    this.StrongNameKeyPairDiagId = "SYSLIB0017";
                    //--TRIMMABLE-BOUNDARY-END(395137056837)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(300647776325)
                    this.ReflectionOnlyLoadingMessage = "ReflectionOnly loading is not supported and throws PlatformNotSupportedException.";
                    //--TRIMMABLE-BOUNDARY-END(300647776325)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(296352809029)
                    this.ReflectionOnlyLoadingDiagId = "SYSLIB0018";
                    //--TRIMMABLE-BOUNDARY-END(296352809029)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(377957187653)
                    this.RuntimeEnvironmentMessage = "RuntimeEnvironment members SystemConfigurationFile, GetRuntimeInterfaceAsIntPtr, and GetRuntimeInterfaceAsObject are not supported and throw PlatformNotSupportedException.";
                    //--TRIMMABLE-BOUNDARY-END(377957187653)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(373662220357)
                    this.RuntimeEnvironmentDiagId = "SYSLIB0019";
                    //--TRIMMABLE-BOUNDARY-END(373662220357)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(231928299589)
                    this.JsonSerializerOptionsIgnoreNullValuesMessage = "JsonSerializerOptions.IgnoreNullValues is obsolete. To ignore null values when serializing, set DefaultIgnoreCondition to JsonIgnoreCondition.WhenWritingNull.";
                    //--TRIMMABLE-BOUNDARY-END(231928299589)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(227633332293)
                    this.JsonSerializerOptionsIgnoreNullValuesDiagId = "SYSLIB0020";
                    //--TRIMMABLE-BOUNDARY-END(227633332293)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(154618888261)
                    this.DerivedCryptographicTypesMessage = "Derived cryptographic types are obsolete. Use the Create method on the base type instead.";
                    //--TRIMMABLE-BOUNDARY-END(154618888261)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(150323920965)
                    this.DerivedCryptographicTypesDiagId = "SYSLIB0021";
                    //--TRIMMABLE-BOUNDARY-END(150323920965)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(352187383877)
                    this.RijndaelMessage = "The Rijndael and RijndaelManaged types are obsolete. Use Aes instead.";
                    //--TRIMMABLE-BOUNDARY-END(352187383877)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(347892416581)
                    this.RijndaelDiagId = "SYSLIB0022";
                    //--TRIMMABLE-BOUNDARY-END(347892416581)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(360777318469)
                    this.RNGCryptoServiceProviderMessage = "RNGCryptoServiceProvider is obsolete. To generate a random number, use one of the RandomNumberGenerator static methods instead.";
                    //--TRIMMABLE-BOUNDARY-END(360777318469)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(356482351173)
                    this.RNGCryptoServiceProviderDiagId = "SYSLIB0023";
                    //--TRIMMABLE-BOUNDARY-END(356482351173)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(17179934789)
                    this.AppDomainCreateUnloadMessage = "Creating and unloading AppDomains is not supported and throws an exception.";
                    //--TRIMMABLE-BOUNDARY-END(17179934789)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(12884967493)
                    this.AppDomainCreateUnloadDiagId = "SYSLIB0024";
                    //--TRIMMABLE-BOUNDARY-END(12884967493)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(408021958725)
                    this.SuppressIldasmAttributeMessage = "SuppressIldasmAttribute has no effect in .NET 6.0+.";
                    //--TRIMMABLE-BOUNDARY-END(408021958725)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(403726991429)
                    this.SuppressIldasmAttributeDiagId = "SYSLIB0025";
                    //--TRIMMABLE-BOUNDARY-END(403726991429)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(498216271941)
                    this.X509CertificateImmutableMessage = "X509Certificate and X509Certificate2 are immutable. Use X509CertificateLoader to create a new certificate.";
                    //--TRIMMABLE-BOUNDARY-END(498216271941)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(493921304645)
                    this.X509CertificateImmutableDiagId = "SYSLIB0026";
                    //--TRIMMABLE-BOUNDARY-END(493921304645)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(283467907141)
                    this.PublicKeyPropertyMessage = "PublicKey.Key is obsolete. Use the appropriate method to get the public key, such as GetRSAPublicKey.";
                    //--TRIMMABLE-BOUNDARY-END(283467907141)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(279172939845)
                    this.PublicKeyPropertyDiagId = "SYSLIB0027";
                    //--TRIMMABLE-BOUNDARY-END(279172939845)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(506806206533)
                    this.X509CertificatePrivateKeyMessage = "X509Certificate2.PrivateKey is obsolete. Use the appropriate method to get the private key, such as GetRSAPrivateKey, or use the CopyWithPrivateKey method to create a new instance with a private key.";
                    //--TRIMMABLE-BOUNDARY-END(506806206533)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(502511239237)
                    this.X509CertificatePrivateKeyDiagId = "SYSLIB0028";
                    //--TRIMMABLE-BOUNDARY-END(502511239237)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(274877972549)
                    this.ProduceLegacyHmacValuesMessage = "ProduceLegacyHmacValues is obsolete. Producing legacy HMAC values is not supported.";
                    //--TRIMMABLE-BOUNDARY-END(274877972549)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(270583005253)
                    this.ProduceLegacyHmacValuesDiagId = "SYSLIB0029";
                    //--TRIMMABLE-BOUNDARY-END(270583005253)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(481036402757)
                    this.UseManagedSha1Message = "HMACSHA1 always uses the algorithm implementation provided by the platform. Use a constructor without the useManagedSha1 parameter.";
                    //--TRIMMABLE-BOUNDARY-END(481036402757)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(476741435461)
                    this.UseManagedSha1DiagId = "SYSLIB0030";
                    //--TRIMMABLE-BOUNDARY-END(476741435461)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(128849084485)
                    this.CryptoConfigEncodeOIDMessage = "EncodeOID is obsolete. Use the ASN.1 functionality provided in System.Formats.Asn1.";
                    //--TRIMMABLE-BOUNDARY-END(128849084485)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(124554117189)
                    this.CryptoConfigEncodeOIDDiagId = "SYSLIB0031";
                    //--TRIMMABLE-BOUNDARY-END(124554117189)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(111669215301)
                    this.CorruptedStateRecoveryMessage = "Recovery from corrupted process state exceptions is not supported; HandleProcessCorruptedStateExceptionsAttribute is ignored.";
                    //--TRIMMABLE-BOUNDARY-END(111669215301)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(107374248005)
                    this.CorruptedStateRecoveryDiagId = "SYSLIB0032";
                    //--TRIMMABLE-BOUNDARY-END(107374248005)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(335007514693)
                    this.Rfc2898CryptDeriveKeyMessage = "Rfc2898DeriveBytes.CryptDeriveKey is obsolete and is not supported. Use PasswordDeriveBytes.CryptDeriveKey instead.";
                    //--TRIMMABLE-BOUNDARY-END(335007514693)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(330712547397)
                    this.Rfc2898CryptDeriveKeyDiagId = "SYSLIB0033";
                    //--TRIMMABLE-BOUNDARY-END(330712547397)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(68719542341)
                    this.CmsSignerCspParamsCtorMessage = "CmsSigner(CspParameters) is obsolete and is not supported. Use an alternative constructor instead.";
                    //--TRIMMABLE-BOUNDARY-END(68719542341)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(64424575045)
                    this.CmsSignerCspParamsCtorDiagId = "SYSLIB0034";
                    //--TRIMMABLE-BOUNDARY-END(64424575045)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(390842089541)
                    this.SignerInfoCounterSigMessage = "ComputeCounterSignature without specifying a CmsSigner is obsolete and is not supported. Use the overload that accepts a CmsSigner.";
                    //--TRIMMABLE-BOUNDARY-END(390842089541)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(386547122245)
                    this.SignerInfoCounterSigDiagId = "SYSLIB0035";
                    //--TRIMMABLE-BOUNDARY-END(386547122245)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(309237710917)
                    this.RegexCompileToAssemblyMessage = "Regex.CompileToAssembly is obsolete and not supported. Use the GeneratedRegexAttribute with the regular expression source generator instead.";
                    //--TRIMMABLE-BOUNDARY-END(309237710917)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(304942743621)
                    this.RegexCompileToAssemblyDiagId = "SYSLIB0036";
                    //--TRIMMABLE-BOUNDARY-END(304942743621)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(42949738565)
                    this.AssemblyNameMembersMessage = "AssemblyName members HashAlgorithm, ProcessorArchitecture, and VersionCompatibility are obsolete and not supported.";
                    //--TRIMMABLE-BOUNDARY-END(42949738565)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(38654771269)
                    this.AssemblyNameMembersDiagId = "SYSLIB0037";
                    //--TRIMMABLE-BOUNDARY-END(38654771269)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(416611893317)
                    this.SystemDataSerializationFormatBinaryMessage = "SerializationFormat.Binary is obsolete and should not be used. See https://aka.ms/serializationformat-binary-obsolete for more information.";
                    //--TRIMMABLE-BOUNDARY-END(416611893317)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(412316926021)
                    this.SystemDataSerializationFormatBinaryDiagId = "SYSLIB0038";
                    //--TRIMMABLE-BOUNDARY-END(412316926021)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(472446468165)
                    this.TlsVersion10and11Message = "TLS versions 1.0 and 1.1 have known vulnerabilities and are not recommended. Use a newer TLS version instead, or use SslProtocols.None to defer to OS defaults.";
                    //--TRIMMABLE-BOUNDARY-END(472446468165)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(468151500869)
                    this.TlsVersion10and11DiagId = "SYSLIB0039";
                    //--TRIMMABLE-BOUNDARY-END(468151500869)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(188978626629)
                    this.EncryptionPolicyMessage = "EncryptionPolicy.NoEncryption and AllowEncryption significantly reduce security and should not be used in production code.";
                    //--TRIMMABLE-BOUNDARY-END(188978626629)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(184683659333)
                    this.EncryptionPolicyDiagId = "SYSLIB0040";
                    //--TRIMMABLE-BOUNDARY-END(184683659333)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(171798757445)
                    this.EccXmlExportImportMessage = "ToXmlString and FromXmlString have no implementation for ECC types, and are obsolete. Use a standard import and export format such as ExportSubjectPublicKeyInfo or ImportSubjectPublicKeyInfo for public keys and ExportPkcs8PrivateKey or ImportPkcs8PrivateKey for private keys.";
                    //--TRIMMABLE-BOUNDARY-END(171798757445)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(167503790149)
                    this.EccXmlExportImportDiagId = "SYSLIB0042";
                    //--TRIMMABLE-BOUNDARY-END(167503790149)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(180388692037)
                    this.EcDhPublicKeyBlobMessage = "ECDiffieHellmanPublicKey.ToByteArray() and the associated constructor do not have a consistent and interoperable implementation on all platforms. Use ECDiffieHellmanPublicKey.ExportSubjectPublicKeyInfo() instead.";
                    //--TRIMMABLE-BOUNDARY-END(180388692037)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(176093724741)
                    this.EcDhPublicKeyBlobDiagId = "SYSLIB0043";
                    //--TRIMMABLE-BOUNDARY-END(176093724741)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(34359803973)
                    this.AssemblyNameCodeBaseMessage = "AssemblyName.CodeBase and AssemblyName.EscapedCodeBase are obsolete. Using them for loading an assembly is not supported.";
                    //--TRIMMABLE-BOUNDARY-END(34359803973)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(30064836677)
                    this.AssemblyNameCodeBaseDiagId = "SYSLIB0044";
                    //--TRIMMABLE-BOUNDARY-END(30064836677)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(137439019077)
                    this.CryptoStringFactoryMessage = "Cryptographic factory methods accepting an algorithm name are obsolete. Use the parameterless Create factory method on the algorithm type instead.";
                    //--TRIMMABLE-BOUNDARY-END(137439019077)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(133144051781)
                    this.CryptoStringFactoryDiagId = "SYSLIB0045";
                    //--TRIMMABLE-BOUNDARY-END(133144051781)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(103079280709)
                    this.ControlledExecutionRunMessage = "ControlledExecution.Run method may corrupt the process and should not be used in production code.";
                    //--TRIMMABLE-BOUNDARY-END(103079280709)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(98784313413)
                    this.ControlledExecutionRunDiagId = "SYSLIB0046";
                    //--TRIMMABLE-BOUNDARY-END(98784313413)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(523986075717)
                    this.XmlSecureResolverMessage = "XmlSecureResolver is obsolete. Use XmlResolver.ThrowingResolver instead when attempting to forbid XML external entity resolution.";
                    //--TRIMMABLE-BOUNDARY-END(523986075717)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(519691108421)
                    this.XmlSecureResolverDiagId = "SYSLIB0047";
                    //--TRIMMABLE-BOUNDARY-END(519691108421)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(369367253061)
                    this.RsaEncryptDecryptValueMessage = "RSA.EncryptValue and DecryptValue are not supported and throw NotSupportedException. Use RSA.Encrypt and RSA.Decrypt instead.";
                    //--TRIMMABLE-BOUNDARY-END(369367253061)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(365072285765)
                    this.RsaEncryptDecryptDiagId = "SYSLIB0048";
                    //--TRIMMABLE-BOUNDARY-END(365072285765)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(223338364997)
                    this.JsonSerializerOptionsAddContextMessage = "JsonSerializerOptions.AddContext is obsolete. To register a JsonSerializerContext, use either the TypeInfoResolver or TypeInfoResolverChain properties.";
                    //--TRIMMABLE-BOUNDARY-END(223338364997)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(219043397701)
                    this.JsonSerializerOptionsAddContextDiagId = "SYSLIB0049";
                    //--TRIMMABLE-BOUNDARY-END(219043397701)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(249108168773)
                    this.LegacyFormatterMessage = "Formatter-based serialization is obsolete and should not be used.";
                    //--TRIMMABLE-BOUNDARY-END(249108168773)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(236223266885)
                    this.LegacyFormatterDiagId = "SYSLIB0050";
                    //--TRIMMABLE-BOUNDARY-END(236223266885)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(244813201477)
                    this.LegacyFormatterImplMessage = "This API supports obsolete formatter-based serialization. It should not be called or extended by application code.";
                    //--TRIMMABLE-BOUNDARY-END(244813201477)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(240518234181)
                    this.LegacyFormatterImplDiagId = "SYSLIB0051";
                    //--TRIMMABLE-BOUNDARY-END(240518234181)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(317827645509)
                    this.RegexExtensibilityImplMessage = "This API supports obsolete mechanisms for Regex extensibility. It is not supported.";
                    //--TRIMMABLE-BOUNDARY-END(317827645509)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(313532678213)
                    this.RegexExtensibilityDiagId = "SYSLIB0052";
                    //--TRIMMABLE-BOUNDARY-END(313532678213)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(8590000197)
                    this.AesGcmTagConstructorMessage = "AesGcm should indicate the required tag size for encryption and decryption. Use a constructor that accepts the tag size.";
                    //--TRIMMABLE-BOUNDARY-END(8590000197)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(4295032901)
                    this.AesGcmTagConstructorDiagId = "SYSLIB0053";
                    //--TRIMMABLE-BOUNDARY-END(4295032901)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(455266598981)
                    this.ThreadVolatileReadWriteMessage = "Thread.VolatileRead and Thread.VolatileWrite are obsolete. Use Volatile.Read or Volatile.Write respectively instead.";
                    //--TRIMMABLE-BOUNDARY-END(455266598981)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(450971631685)
                    this.ThreadVolatileReadWriteDiagId = "SYSLIB0054";
                    //--TRIMMABLE-BOUNDARY-END(450971631685)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(25769869381)
                    this.ArmIntrinsicPerformsUnsignedOperationMessage = "The underlying hardware instruction does not perform a signed saturate narrowing operation, and it always returns an unsigned result. Use the unsigned overload instead.";
                    //--TRIMMABLE-BOUNDARY-END(25769869381)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(21474902085)
                    this.ArmIntrinsicPerformsUnsignedOperationDiagId = "SYSLIB0055";
                    //--TRIMMABLE-BOUNDARY-END(21474902085)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(257698103365)
                    this.LoadFromHashAlgorithmMessage = "LoadFrom with a custom AssemblyHashAlgorithm is obsolete. Use overloads without an AssemblyHashAlgorithm.";
                    //--TRIMMABLE-BOUNDARY-END(257698103365)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(253403136069)
                    this.LoadFromHashAlgorithmDiagId = "SYSLIB0056";
                    //--TRIMMABLE-BOUNDARY-END(253403136069)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(515396141125)
                    this.X509CtorCertDataObsoleteMessage = "Loading certificate data through the constructor or Import is obsolete. Use X509CertificateLoader instead to load certificates.";
                    //--TRIMMABLE-BOUNDARY-END(515396141125)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(511101173829)
                    this.X509CtorCertDataObsoleteDiagId = "SYSLIB0057";
                    //--TRIMMABLE-BOUNDARY-END(511101173829)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(463856533573)
                    this.TlsCipherAlgorithmEnumsMessage = "KeyExchangeAlgorithm, KeyExchangeStrength, CipherAlgorithm, CipherStrength, HashAlgorithm and HashStrength properties of SslStream are obsolete. Use NegotiatedCipherSuite instead.";
                    //--TRIMMABLE-BOUNDARY-END(463856533573)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(459561566277)
                    this.TlsCipherAlgorithmEnumsDiagId = "SYSLIB0058";
                    //--TRIMMABLE-BOUNDARY-END(459561566277)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(425201827909)
                    this.SystemEventsEventsThreadShutdownMessage = "SystemEvents.EventsThreadShutdown callbacks are not run before the process exits. Use AppDomain.ProcessExit instead.";
                    //--TRIMMABLE-BOUNDARY-END(425201827909)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(420906860613)
                    this.SystemEventsEventsThreadShutdownDiagId = "SYSLIB0059";
                    //--TRIMMABLE-BOUNDARY-END(420906860613)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(343597449285)
                    this.Rfc2898DeriveBytesCtorMessage = "The constructors on Rfc2898DeriveBytes are obsolete. Use the static Pbkdf2 method instead.";
                    //--TRIMMABLE-BOUNDARY-END(343597449285)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(339302481989)
                    this.Rfc2898DeriveBytesCtorDiagId = "SYSLIB0060";
                    //--TRIMMABLE-BOUNDARY-END(339302481989)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(292057841733)
                    this.QueryableMinByMaxByTSourceObsoleteMessage = "The Queryable MinBy and MaxBy taking an IComparer<TSource> are obsolete. Use the new ones that take an IComparer<TKey>.";
                    //--TRIMMABLE-BOUNDARY-END(292057841733)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(287762874437)
                    this.QueryableMinByMaxByTSourceObsoleteDiagId = "SYSLIB0061";
                    //--TRIMMABLE-BOUNDARY-END(287762874437)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(532576010309)
                    this.XsltSettingsEnableScriptMessage = "XSLT Script blocks are not supported.";
                    //--TRIMMABLE-BOUNDARY-END(532576010309)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(528281043013)
                    this.XsltSettingsEnableScriptDiagId = "SYSLIB0062";
                    //--TRIMMABLE-BOUNDARY-END(528281043013)
                    
                }
            }
            //--TRIMMABLE-BOUNDARY-END(SINIT)
            
            static $h = 65605;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 131073,
  "l": [
//--TRIMMABLE-BOUNDARY-START(382252154949),
    {
      "t": 1310721,
      "n": "SharedUrlFormat",
      "d": 65605,
      "h": 382252154949,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(382252154949),
//--TRIMMABLE-BOUNDARY-START(433791762501),
    {
      "t": 1310721,
      "n": "SystemTextEncodingUTF7Message",
      "d": 65605,
      "h": 433791762501,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(433791762501),
//--TRIMMABLE-BOUNDARY-START(429496795205),
    {
      "t": 1310721,
      "n": "SystemTextEncodingUTF7DiagId",
      "d": 65605,
      "h": 429496795205,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(429496795205),
//--TRIMMABLE-BOUNDARY-START(266288037957),
    {
      "t": 1310721,
      "n": "PrincipalPermissionAttributeMessage",
      "d": 65605,
      "h": 266288037957,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(266288037957),
//--TRIMMABLE-BOUNDARY-START(261993070661),
    {
      "t": 1310721,
      "n": "PrincipalPermissionAttributeDiagId",
      "d": 65605,
      "h": 261993070661,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(261993070661),
//--TRIMMABLE-BOUNDARY-START(77309476933),
    {
      "t": 1310721,
      "n": "CodeAccessSecurityMessage",
      "d": 65605,
      "h": 77309476933,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(77309476933),
//--TRIMMABLE-BOUNDARY-START(73014509637),
    {
      "t": 1310721,
      "n": "CodeAccessSecurityDiagId",
      "d": 65605,
      "h": 73014509637,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(73014509637),
//--TRIMMABLE-BOUNDARY-START(94489346117),
    {
      "t": 1310721,
      "n": "ConstrainedExecutionRegionMessage",
      "d": 65605,
      "h": 94489346117,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(94489346117),
//--TRIMMABLE-BOUNDARY-START(90194378821),
    {
      "t": 1310721,
      "n": "ConstrainedExecutionRegionDiagId",
      "d": 65605,
      "h": 90194378821,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(90194378821),
//--TRIMMABLE-BOUNDARY-START(214748430405),
    {
      "t": 1310721,
      "n": "GlobalAssemblyCacheMessage",
      "d": 65605,
      "h": 214748430405,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(214748430405),
//--TRIMMABLE-BOUNDARY-START(210453463109),
    {
      "t": 1310721,
      "n": "GlobalAssemblyCacheDiagId",
      "d": 65605,
      "h": 210453463109,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(210453463109),
//--TRIMMABLE-BOUNDARY-START(442381697093),
    {
      "t": 1310721,
      "n": "ThreadAbortMessage",
      "d": 65605,
      "h": 442381697093,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(442381697093),
//--TRIMMABLE-BOUNDARY-START(446676664389),
    {
      "t": 1310721,
      "n": "ThreadResetAbortMessage",
      "d": 65605,
      "h": 446676664389,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(446676664389),
//--TRIMMABLE-BOUNDARY-START(438086729797),
    {
      "t": 1310721,
      "n": "ThreadAbortDiagId",
      "d": 65605,
      "h": 438086729797,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(438086729797),
//--TRIMMABLE-BOUNDARY-START(146028953669),
    {
      "t": 1310721,
      "n": "DefaultCryptoAlgorithmsMessage",
      "d": 65605,
      "h": 146028953669,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(146028953669),
//--TRIMMABLE-BOUNDARY-START(141733986373),
    {
      "t": 1310721,
      "n": "DefaultCryptoAlgorithmsDiagId",
      "d": 65605,
      "h": 141733986373,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(141733986373),
//--TRIMMABLE-BOUNDARY-START(120259149893),
    {
      "t": 1310721,
      "n": "CreatePdbGeneratorMessage",
      "d": 65605,
      "h": 120259149893,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(120259149893),
//--TRIMMABLE-BOUNDARY-START(115964182597),
    {
      "t": 1310721,
      "n": "CreatePdbGeneratorDiagId",
      "d": 65605,
      "h": 115964182597,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(115964182597),
//--TRIMMABLE-BOUNDARY-START(51539673157),
    {
      "t": 1310721,
      "n": "AuthenticationManagerMessage",
      "d": 65605,
      "h": 51539673157,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(51539673157),
//--TRIMMABLE-BOUNDARY-START(47244705861),
    {
      "t": 1310721,
      "n": "AuthenticationManagerDiagId",
      "d": 65605,
      "h": 47244705861,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(47244705861),
//--TRIMMABLE-BOUNDARY-START(326417580101),
    {
      "t": 1310721,
      "n": "RemotingApisMessage",
      "d": 65605,
      "h": 326417580101,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(326417580101),
//--TRIMMABLE-BOUNDARY-START(322122612805),
    {
      "t": 1310721,
      "n": "RemotingApisDiagId",
      "d": 65605,
      "h": 322122612805,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(322122612805),
//--TRIMMABLE-BOUNDARY-START(60129607749),
    {
      "t": 1310721,
      "n": "BinaryFormatterMessage",
      "d": 65605,
      "h": 60129607749,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(60129607749),
//--TRIMMABLE-BOUNDARY-START(55834640453),
    {
      "t": 1310721,
      "n": "BinaryFormatterDiagId",
      "d": 65605,
      "h": 55834640453,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(55834640453),
//--TRIMMABLE-BOUNDARY-START(85899411525),
    {
      "t": 1310721,
      "n": "CodeBaseMessage",
      "d": 65605,
      "h": 85899411525,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(85899411525),
//--TRIMMABLE-BOUNDARY-START(81604444229),
    {
      "t": 1310721,
      "n": "CodeBaseDiagId",
      "d": 65605,
      "h": 81604444229,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(81604444229),
//--TRIMMABLE-BOUNDARY-START(197568561221),
    {
      "t": 1310721,
      "n": "EscapeUriStringMessage",
      "d": 65605,
      "h": 197568561221,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(197568561221),
//--TRIMMABLE-BOUNDARY-START(193273593925),
    {
      "t": 1310721,
      "n": "EscapeUriStringDiagId",
      "d": 65605,
      "h": 193273593925,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(193273593925),
//--TRIMMABLE-BOUNDARY-START(489626337349),
    {
      "t": 1310721,
      "n": "WebRequestMessage",
      "d": 65605,
      "h": 489626337349,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(489626337349),
//--TRIMMABLE-BOUNDARY-START(485331370053),
    {
      "t": 1310721,
      "n": "WebRequestDiagId",
      "d": 65605,
      "h": 485331370053,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(485331370053),
//--TRIMMABLE-BOUNDARY-START(163208822853),
    {
      "t": 1310721,
      "n": "DisablePrivateReflectionAttributeMessage",
      "d": 65605,
      "h": 163208822853,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(163208822853),
//--TRIMMABLE-BOUNDARY-START(158913855557),
    {
      "t": 1310721,
      "n": "DisablePrivateReflectionAttributeDiagId",
      "d": 65605,
      "h": 158913855557,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(158913855557),
//--TRIMMABLE-BOUNDARY-START(206158495813),
    {
      "t": 1310721,
      "n": "GetContextInfoMessage",
      "d": 65605,
      "h": 206158495813,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(206158495813),
//--TRIMMABLE-BOUNDARY-START(201863528517),
    {
      "t": 1310721,
      "n": "GetContextInfoDiagId",
      "d": 65605,
      "h": 201863528517,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(201863528517),
//--TRIMMABLE-BOUNDARY-START(399432024133),
    {
      "t": 1310721,
      "n": "StrongNameKeyPairMessage",
      "d": 65605,
      "h": 399432024133,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(399432024133),
//--TRIMMABLE-BOUNDARY-START(395137056837),
    {
      "t": 1310721,
      "n": "StrongNameKeyPairDiagId",
      "d": 65605,
      "h": 395137056837,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(395137056837),
//--TRIMMABLE-BOUNDARY-START(300647776325),
    {
      "t": 1310721,
      "n": "ReflectionOnlyLoadingMessage",
      "d": 65605,
      "h": 300647776325,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(300647776325),
//--TRIMMABLE-BOUNDARY-START(296352809029),
    {
      "t": 1310721,
      "n": "ReflectionOnlyLoadingDiagId",
      "d": 65605,
      "h": 296352809029,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(296352809029),
//--TRIMMABLE-BOUNDARY-START(377957187653),
    {
      "t": 1310721,
      "n": "RuntimeEnvironmentMessage",
      "d": 65605,
      "h": 377957187653,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(377957187653),
//--TRIMMABLE-BOUNDARY-START(373662220357),
    {
      "t": 1310721,
      "n": "RuntimeEnvironmentDiagId",
      "d": 65605,
      "h": 373662220357,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(373662220357),
//--TRIMMABLE-BOUNDARY-START(231928299589),
    {
      "t": 1310721,
      "n": "JsonSerializerOptionsIgnoreNullValuesMessage",
      "d": 65605,
      "h": 231928299589,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(231928299589),
//--TRIMMABLE-BOUNDARY-START(227633332293),
    {
      "t": 1310721,
      "n": "JsonSerializerOptionsIgnoreNullValuesDiagId",
      "d": 65605,
      "h": 227633332293,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(227633332293),
//--TRIMMABLE-BOUNDARY-START(154618888261),
    {
      "t": 1310721,
      "n": "DerivedCryptographicTypesMessage",
      "d": 65605,
      "h": 154618888261,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(154618888261),
//--TRIMMABLE-BOUNDARY-START(150323920965),
    {
      "t": 1310721,
      "n": "DerivedCryptographicTypesDiagId",
      "d": 65605,
      "h": 150323920965,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(150323920965),
//--TRIMMABLE-BOUNDARY-START(352187383877),
    {
      "t": 1310721,
      "n": "RijndaelMessage",
      "d": 65605,
      "h": 352187383877,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(352187383877),
//--TRIMMABLE-BOUNDARY-START(347892416581),
    {
      "t": 1310721,
      "n": "RijndaelDiagId",
      "d": 65605,
      "h": 347892416581,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(347892416581),
//--TRIMMABLE-BOUNDARY-START(360777318469),
    {
      "t": 1310721,
      "n": "RNGCryptoServiceProviderMessage",
      "d": 65605,
      "h": 360777318469,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(360777318469),
//--TRIMMABLE-BOUNDARY-START(356482351173),
    {
      "t": 1310721,
      "n": "RNGCryptoServiceProviderDiagId",
      "d": 65605,
      "h": 356482351173,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(356482351173),
//--TRIMMABLE-BOUNDARY-START(17179934789),
    {
      "t": 1310721,
      "n": "AppDomainCreateUnloadMessage",
      "d": 65605,
      "h": 17179934789,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(17179934789),
//--TRIMMABLE-BOUNDARY-START(12884967493),
    {
      "t": 1310721,
      "n": "AppDomainCreateUnloadDiagId",
      "d": 65605,
      "h": 12884967493,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(12884967493),
//--TRIMMABLE-BOUNDARY-START(408021958725),
    {
      "t": 1310721,
      "n": "SuppressIldasmAttributeMessage",
      "d": 65605,
      "h": 408021958725,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(408021958725),
//--TRIMMABLE-BOUNDARY-START(403726991429),
    {
      "t": 1310721,
      "n": "SuppressIldasmAttributeDiagId",
      "d": 65605,
      "h": 403726991429,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(403726991429),
//--TRIMMABLE-BOUNDARY-START(498216271941),
    {
      "t": 1310721,
      "n": "X509CertificateImmutableMessage",
      "d": 65605,
      "h": 498216271941,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(498216271941),
//--TRIMMABLE-BOUNDARY-START(493921304645),
    {
      "t": 1310721,
      "n": "X509CertificateImmutableDiagId",
      "d": 65605,
      "h": 493921304645,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(493921304645),
//--TRIMMABLE-BOUNDARY-START(283467907141),
    {
      "t": 1310721,
      "n": "PublicKeyPropertyMessage",
      "d": 65605,
      "h": 283467907141,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(283467907141),
//--TRIMMABLE-BOUNDARY-START(279172939845),
    {
      "t": 1310721,
      "n": "PublicKeyPropertyDiagId",
      "d": 65605,
      "h": 279172939845,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(279172939845),
//--TRIMMABLE-BOUNDARY-START(506806206533),
    {
      "t": 1310721,
      "n": "X509CertificatePrivateKeyMessage",
      "d": 65605,
      "h": 506806206533,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(506806206533),
//--TRIMMABLE-BOUNDARY-START(502511239237),
    {
      "t": 1310721,
      "n": "X509CertificatePrivateKeyDiagId",
      "d": 65605,
      "h": 502511239237,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(502511239237),
//--TRIMMABLE-BOUNDARY-START(274877972549),
    {
      "t": 1310721,
      "n": "ProduceLegacyHmacValuesMessage",
      "d": 65605,
      "h": 274877972549,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(274877972549),
//--TRIMMABLE-BOUNDARY-START(270583005253),
    {
      "t": 1310721,
      "n": "ProduceLegacyHmacValuesDiagId",
      "d": 65605,
      "h": 270583005253,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(270583005253),
//--TRIMMABLE-BOUNDARY-START(481036402757),
    {
      "t": 1310721,
      "n": "UseManagedSha1Message",
      "d": 65605,
      "h": 481036402757,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(481036402757),
//--TRIMMABLE-BOUNDARY-START(476741435461),
    {
      "t": 1310721,
      "n": "UseManagedSha1DiagId",
      "d": 65605,
      "h": 476741435461,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(476741435461),
//--TRIMMABLE-BOUNDARY-START(128849084485),
    {
      "t": 1310721,
      "n": "CryptoConfigEncodeOIDMessage",
      "d": 65605,
      "h": 128849084485,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(128849084485),
//--TRIMMABLE-BOUNDARY-START(124554117189),
    {
      "t": 1310721,
      "n": "CryptoConfigEncodeOIDDiagId",
      "d": 65605,
      "h": 124554117189,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(124554117189),
//--TRIMMABLE-BOUNDARY-START(111669215301),
    {
      "t": 1310721,
      "n": "CorruptedStateRecoveryMessage",
      "d": 65605,
      "h": 111669215301,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(111669215301),
//--TRIMMABLE-BOUNDARY-START(107374248005),
    {
      "t": 1310721,
      "n": "CorruptedStateRecoveryDiagId",
      "d": 65605,
      "h": 107374248005,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(107374248005),
//--TRIMMABLE-BOUNDARY-START(335007514693),
    {
      "t": 1310721,
      "n": "Rfc2898CryptDeriveKeyMessage",
      "d": 65605,
      "h": 335007514693,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(335007514693),
//--TRIMMABLE-BOUNDARY-START(330712547397),
    {
      "t": 1310721,
      "n": "Rfc2898CryptDeriveKeyDiagId",
      "d": 65605,
      "h": 330712547397,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(330712547397),
//--TRIMMABLE-BOUNDARY-START(68719542341),
    {
      "t": 1310721,
      "n": "CmsSignerCspParamsCtorMessage",
      "d": 65605,
      "h": 68719542341,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(68719542341),
//--TRIMMABLE-BOUNDARY-START(64424575045),
    {
      "t": 1310721,
      "n": "CmsSignerCspParamsCtorDiagId",
      "d": 65605,
      "h": 64424575045,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(64424575045),
//--TRIMMABLE-BOUNDARY-START(390842089541),
    {
      "t": 1310721,
      "n": "SignerInfoCounterSigMessage",
      "d": 65605,
      "h": 390842089541,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(390842089541),
//--TRIMMABLE-BOUNDARY-START(386547122245),
    {
      "t": 1310721,
      "n": "SignerInfoCounterSigDiagId",
      "d": 65605,
      "h": 386547122245,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(386547122245),
//--TRIMMABLE-BOUNDARY-START(309237710917),
    {
      "t": 1310721,
      "n": "RegexCompileToAssemblyMessage",
      "d": 65605,
      "h": 309237710917,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(309237710917),
//--TRIMMABLE-BOUNDARY-START(304942743621),
    {
      "t": 1310721,
      "n": "RegexCompileToAssemblyDiagId",
      "d": 65605,
      "h": 304942743621,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(304942743621),
//--TRIMMABLE-BOUNDARY-START(42949738565),
    {
      "t": 1310721,
      "n": "AssemblyNameMembersMessage",
      "d": 65605,
      "h": 42949738565,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(42949738565),
//--TRIMMABLE-BOUNDARY-START(38654771269),
    {
      "t": 1310721,
      "n": "AssemblyNameMembersDiagId",
      "d": 65605,
      "h": 38654771269,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(38654771269),
//--TRIMMABLE-BOUNDARY-START(416611893317),
    {
      "t": 1310721,
      "n": "SystemDataSerializationFormatBinaryMessage",
      "d": 65605,
      "h": 416611893317,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(416611893317),
//--TRIMMABLE-BOUNDARY-START(412316926021),
    {
      "t": 1310721,
      "n": "SystemDataSerializationFormatBinaryDiagId",
      "d": 65605,
      "h": 412316926021,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(412316926021),
//--TRIMMABLE-BOUNDARY-START(472446468165),
    {
      "t": 1310721,
      "n": "TlsVersion10and11Message",
      "d": 65605,
      "h": 472446468165,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(472446468165),
//--TRIMMABLE-BOUNDARY-START(468151500869),
    {
      "t": 1310721,
      "n": "TlsVersion10and11DiagId",
      "d": 65605,
      "h": 468151500869,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(468151500869),
//--TRIMMABLE-BOUNDARY-START(188978626629),
    {
      "t": 1310721,
      "n": "EncryptionPolicyMessage",
      "d": 65605,
      "h": 188978626629,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(188978626629),
//--TRIMMABLE-BOUNDARY-START(184683659333),
    {
      "t": 1310721,
      "n": "EncryptionPolicyDiagId",
      "d": 65605,
      "h": 184683659333,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(184683659333),
//--TRIMMABLE-BOUNDARY-START(171798757445),
    {
      "t": 1310721,
      "n": "EccXmlExportImportMessage",
      "d": 65605,
      "h": 171798757445,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(171798757445),
//--TRIMMABLE-BOUNDARY-START(167503790149),
    {
      "t": 1310721,
      "n": "EccXmlExportImportDiagId",
      "d": 65605,
      "h": 167503790149,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(167503790149),
//--TRIMMABLE-BOUNDARY-START(180388692037),
    {
      "t": 1310721,
      "n": "EcDhPublicKeyBlobMessage",
      "d": 65605,
      "h": 180388692037,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(180388692037),
//--TRIMMABLE-BOUNDARY-START(176093724741),
    {
      "t": 1310721,
      "n": "EcDhPublicKeyBlobDiagId",
      "d": 65605,
      "h": 176093724741,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(176093724741),
//--TRIMMABLE-BOUNDARY-START(34359803973),
    {
      "t": 1310721,
      "n": "AssemblyNameCodeBaseMessage",
      "d": 65605,
      "h": 34359803973,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(34359803973),
//--TRIMMABLE-BOUNDARY-START(30064836677),
    {
      "t": 1310721,
      "n": "AssemblyNameCodeBaseDiagId",
      "d": 65605,
      "h": 30064836677,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(30064836677),
//--TRIMMABLE-BOUNDARY-START(137439019077),
    {
      "t": 1310721,
      "n": "CryptoStringFactoryMessage",
      "d": 65605,
      "h": 137439019077,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(137439019077),
//--TRIMMABLE-BOUNDARY-START(133144051781),
    {
      "t": 1310721,
      "n": "CryptoStringFactoryDiagId",
      "d": 65605,
      "h": 133144051781,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(133144051781),
//--TRIMMABLE-BOUNDARY-START(103079280709),
    {
      "t": 1310721,
      "n": "ControlledExecutionRunMessage",
      "d": 65605,
      "h": 103079280709,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(103079280709),
//--TRIMMABLE-BOUNDARY-START(98784313413),
    {
      "t": 1310721,
      "n": "ControlledExecutionRunDiagId",
      "d": 65605,
      "h": 98784313413,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(98784313413),
//--TRIMMABLE-BOUNDARY-START(523986075717),
    {
      "t": 1310721,
      "n": "XmlSecureResolverMessage",
      "d": 65605,
      "h": 523986075717,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(523986075717),
//--TRIMMABLE-BOUNDARY-START(519691108421),
    {
      "t": 1310721,
      "n": "XmlSecureResolverDiagId",
      "d": 65605,
      "h": 519691108421,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(519691108421),
//--TRIMMABLE-BOUNDARY-START(369367253061),
    {
      "t": 1310721,
      "n": "RsaEncryptDecryptValueMessage",
      "d": 65605,
      "h": 369367253061,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(369367253061),
//--TRIMMABLE-BOUNDARY-START(365072285765),
    {
      "t": 1310721,
      "n": "RsaEncryptDecryptDiagId",
      "d": 65605,
      "h": 365072285765,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(365072285765),
//--TRIMMABLE-BOUNDARY-START(223338364997),
    {
      "t": 1310721,
      "n": "JsonSerializerOptionsAddContextMessage",
      "d": 65605,
      "h": 223338364997,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(223338364997),
//--TRIMMABLE-BOUNDARY-START(219043397701),
    {
      "t": 1310721,
      "n": "JsonSerializerOptionsAddContextDiagId",
      "d": 65605,
      "h": 219043397701,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(219043397701),
//--TRIMMABLE-BOUNDARY-START(249108168773),
    {
      "t": 1310721,
      "n": "LegacyFormatterMessage",
      "d": 65605,
      "h": 249108168773,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(249108168773),
//--TRIMMABLE-BOUNDARY-START(236223266885),
    {
      "t": 1310721,
      "n": "LegacyFormatterDiagId",
      "d": 65605,
      "h": 236223266885,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(236223266885),
//--TRIMMABLE-BOUNDARY-START(244813201477),
    {
      "t": 1310721,
      "n": "LegacyFormatterImplMessage",
      "d": 65605,
      "h": 244813201477,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(244813201477),
//--TRIMMABLE-BOUNDARY-START(240518234181),
    {
      "t": 1310721,
      "n": "LegacyFormatterImplDiagId",
      "d": 65605,
      "h": 240518234181,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(240518234181),
//--TRIMMABLE-BOUNDARY-START(317827645509),
    {
      "t": 1310721,
      "n": "RegexExtensibilityImplMessage",
      "d": 65605,
      "h": 317827645509,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(317827645509),
//--TRIMMABLE-BOUNDARY-START(313532678213),
    {
      "t": 1310721,
      "n": "RegexExtensibilityDiagId",
      "d": 65605,
      "h": 313532678213,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(313532678213),
//--TRIMMABLE-BOUNDARY-START(8590000197),
    {
      "t": 1310721,
      "n": "AesGcmTagConstructorMessage",
      "d": 65605,
      "h": 8590000197,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(8590000197),
//--TRIMMABLE-BOUNDARY-START(4295032901),
    {
      "t": 1310721,
      "n": "AesGcmTagConstructorDiagId",
      "d": 65605,
      "h": 4295032901,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(4295032901),
//--TRIMMABLE-BOUNDARY-START(455266598981),
    {
      "t": 1310721,
      "n": "ThreadVolatileReadWriteMessage",
      "d": 65605,
      "h": 455266598981,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(455266598981),
//--TRIMMABLE-BOUNDARY-START(450971631685),
    {
      "t": 1310721,
      "n": "ThreadVolatileReadWriteDiagId",
      "d": 65605,
      "h": 450971631685,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(450971631685),
//--TRIMMABLE-BOUNDARY-START(25769869381),
    {
      "t": 1310721,
      "n": "ArmIntrinsicPerformsUnsignedOperationMessage",
      "d": 65605,
      "h": 25769869381,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(25769869381),
//--TRIMMABLE-BOUNDARY-START(21474902085),
    {
      "t": 1310721,
      "n": "ArmIntrinsicPerformsUnsignedOperationDiagId",
      "d": 65605,
      "h": 21474902085,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(21474902085),
//--TRIMMABLE-BOUNDARY-START(257698103365),
    {
      "t": 1310721,
      "n": "LoadFromHashAlgorithmMessage",
      "d": 65605,
      "h": 257698103365,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(257698103365),
//--TRIMMABLE-BOUNDARY-START(253403136069),
    {
      "t": 1310721,
      "n": "LoadFromHashAlgorithmDiagId",
      "d": 65605,
      "h": 253403136069,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(253403136069),
//--TRIMMABLE-BOUNDARY-START(515396141125),
    {
      "t": 1310721,
      "n": "X509CtorCertDataObsoleteMessage",
      "d": 65605,
      "h": 515396141125,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(515396141125),
//--TRIMMABLE-BOUNDARY-START(511101173829),
    {
      "t": 1310721,
      "n": "X509CtorCertDataObsoleteDiagId",
      "d": 65605,
      "h": 511101173829,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(511101173829),
//--TRIMMABLE-BOUNDARY-START(463856533573),
    {
      "t": 1310721,
      "n": "TlsCipherAlgorithmEnumsMessage",
      "d": 65605,
      "h": 463856533573,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(463856533573),
//--TRIMMABLE-BOUNDARY-START(459561566277),
    {
      "t": 1310721,
      "n": "TlsCipherAlgorithmEnumsDiagId",
      "d": 65605,
      "h": 459561566277,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(459561566277),
//--TRIMMABLE-BOUNDARY-START(425201827909),
    {
      "t": 1310721,
      "n": "SystemEventsEventsThreadShutdownMessage",
      "d": 65605,
      "h": 425201827909,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(425201827909),
//--TRIMMABLE-BOUNDARY-START(420906860613),
    {
      "t": 1310721,
      "n": "SystemEventsEventsThreadShutdownDiagId",
      "d": 65605,
      "h": 420906860613,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(420906860613),
//--TRIMMABLE-BOUNDARY-START(343597449285),
    {
      "t": 1310721,
      "n": "Rfc2898DeriveBytesCtorMessage",
      "d": 65605,
      "h": 343597449285,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(343597449285),
//--TRIMMABLE-BOUNDARY-START(339302481989),
    {
      "t": 1310721,
      "n": "Rfc2898DeriveBytesCtorDiagId",
      "d": 65605,
      "h": 339302481989,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(339302481989),
//--TRIMMABLE-BOUNDARY-START(292057841733),
    {
      "t": 1310721,
      "n": "QueryableMinByMaxByTSourceObsoleteMessage",
      "d": 65605,
      "h": 292057841733,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(292057841733),
//--TRIMMABLE-BOUNDARY-START(287762874437),
    {
      "t": 1310721,
      "n": "QueryableMinByMaxByTSourceObsoleteDiagId",
      "d": 65605,
      "h": 287762874437,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(287762874437),
//--TRIMMABLE-BOUNDARY-START(532576010309),
    {
      "t": 1310721,
      "n": "XsltSettingsEnableScriptMessage",
      "d": 65605,
      "h": 532576010309,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(532576010309),
//--TRIMMABLE-BOUNDARY-START(528281043013),
    {
      "t": 1310721,
      "n": "XsltSettingsEnableScriptDiagId",
      "d": 65605,
      "h": 528281043013,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(528281043013)
  ],
  "h": 65605
}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `System.Obsoletions`; }
        });
        //--TRIMMABLE-BOUNDARY-END(65605)
        
        
        //--TRIMMABLE-BOUNDARY-START(589893)
        $asm.$cls("$ssc.System.Security.Claims.ClaimValueTypes", ($self) => class ClaimValueTypes
        {
            //--TRIMMABLE-BOUNDARY-START(124554641477)
            /*string*/ static XmlSchemaNamespace = null;
            //--TRIMMABLE-BOUNDARY-END(124554641477)
            
            //--TRIMMABLE-BOUNDARY-START(4295557189)
            /*string*/ static Base64Binary = null;
            //--TRIMMABLE-BOUNDARY-END(4295557189)
            
            //--TRIMMABLE-BOUNDARY-START(8590524485)
            /*string*/ static Base64Octet = null;
            //--TRIMMABLE-BOUNDARY-END(8590524485)
            
            //--TRIMMABLE-BOUNDARY-START(12885491781)
            /*string*/ static Boolean = null;
            //--TRIMMABLE-BOUNDARY-END(12885491781)
            
            //--TRIMMABLE-BOUNDARY-START(17180459077)
            /*string*/ static Date = null;
            //--TRIMMABLE-BOUNDARY-END(17180459077)
            
            //--TRIMMABLE-BOUNDARY-START(21475426373)
            /*string*/ static DateTime = null;
            //--TRIMMABLE-BOUNDARY-END(21475426373)
            
            //--TRIMMABLE-BOUNDARY-START(34360328261)
            /*string*/ static Double = null;
            //--TRIMMABLE-BOUNDARY-END(34360328261)
            
            //--TRIMMABLE-BOUNDARY-START(47245230149)
            /*string*/ static Fqbn = null;
            //--TRIMMABLE-BOUNDARY-END(47245230149)
            
            //--TRIMMABLE-BOUNDARY-START(51540197445)
            /*string*/ static HexBinary = null;
            //--TRIMMABLE-BOUNDARY-END(51540197445)
            
            //--TRIMMABLE-BOUNDARY-START(55835164741)
            /*string*/ static Integer = null;
            //--TRIMMABLE-BOUNDARY-END(55835164741)
            
            //--TRIMMABLE-BOUNDARY-START(60130132037)
            /*string*/ static Integer32 = null;
            //--TRIMMABLE-BOUNDARY-END(60130132037)
            
            //--TRIMMABLE-BOUNDARY-START(64425099333)
            /*string*/ static Integer64 = null;
            //--TRIMMABLE-BOUNDARY-END(64425099333)
            
            //--TRIMMABLE-BOUNDARY-START(85899935813)
            /*string*/ static Sid = null;
            //--TRIMMABLE-BOUNDARY-END(85899935813)
            
            //--TRIMMABLE-BOUNDARY-START(94489870405)
            /*string*/ static String = null;
            //--TRIMMABLE-BOUNDARY-END(94489870405)
            
            //--TRIMMABLE-BOUNDARY-START(98784837701)
            /*string*/ static Time = null;
            //--TRIMMABLE-BOUNDARY-END(98784837701)
            
            //--TRIMMABLE-BOUNDARY-START(103079804997)
            /*string*/ static UInteger32 = null;
            //--TRIMMABLE-BOUNDARY-END(103079804997)
            
            //--TRIMMABLE-BOUNDARY-START(107374772293)
            /*string*/ static UInteger64 = null;
            //--TRIMMABLE-BOUNDARY-END(107374772293)
            
            //--TRIMMABLE-BOUNDARY-START(90194903109)
            /*string*/ static SoapSchemaNamespace = null;
            //--TRIMMABLE-BOUNDARY-END(90194903109)
            
            //--TRIMMABLE-BOUNDARY-START(30065360965)
            /*string*/ static DnsName = null;
            //--TRIMMABLE-BOUNDARY-END(30065360965)
            
            //--TRIMMABLE-BOUNDARY-START(42950262853)
            /*string*/ static Email = null;
            //--TRIMMABLE-BOUNDARY-END(42950262853)
            
            //--TRIMMABLE-BOUNDARY-START(77310001221)
            /*string*/ static Rsa = null;
            //--TRIMMABLE-BOUNDARY-END(77310001221)
            
            //--TRIMMABLE-BOUNDARY-START(111669739589)
            /*string*/ static UpnName = null;
            //--TRIMMABLE-BOUNDARY-END(111669739589)
            
            //--TRIMMABLE-BOUNDARY-START(128849608773)
            /*string*/ static XmlSignatureConstantsNamespace = null;
            //--TRIMMABLE-BOUNDARY-END(128849608773)
            
            //--TRIMMABLE-BOUNDARY-START(38655295557)
            /*string*/ static DsaKeyValue = null;
            //--TRIMMABLE-BOUNDARY-END(38655295557)
            
            //--TRIMMABLE-BOUNDARY-START(68720066629)
            /*string*/ static KeyInfo = null;
            //--TRIMMABLE-BOUNDARY-END(68720066629)
            
            //--TRIMMABLE-BOUNDARY-START(81604968517)
            /*string*/ static RsaKeyValue = null;
            //--TRIMMABLE-BOUNDARY-END(81604968517)
            
            //--TRIMMABLE-BOUNDARY-START(133144576069)
            /*string*/ static XQueryOperatorsNameSpace = null;
            //--TRIMMABLE-BOUNDARY-END(133144576069)
            
            //--TRIMMABLE-BOUNDARY-START(25770393669)
            /*string*/ static DaytimeDuration = null;
            //--TRIMMABLE-BOUNDARY-END(25770393669)
            
            //--TRIMMABLE-BOUNDARY-START(137439543365)
            /*string*/ static YearMonthDuration = null;
            //--TRIMMABLE-BOUNDARY-END(137439543365)
            
            //--TRIMMABLE-BOUNDARY-START(120259674181)
            /*string*/ static Xacml10Namespace = null;
            //--TRIMMABLE-BOUNDARY-END(120259674181)
            
            //--TRIMMABLE-BOUNDARY-START(73015033925)
            /*string*/ static Rfc822Name = null;
            //--TRIMMABLE-BOUNDARY-END(73015033925)
            
            //--TRIMMABLE-BOUNDARY-START(115964706885)
            /*string*/ static X500Name = null;
            //--TRIMMABLE-BOUNDARY-END(115964706885)
            
            //--TRIMMABLE-BOUNDARY-START(SINIT)
            //Static Initializer
            static $sinit()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(124554641477)
                    this.XmlSchemaNamespace = "http://www.w3.org/2001/XMLSchema";
                    //--TRIMMABLE-BOUNDARY-END(124554641477)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(4295557189)
                    this.Base64Binary = "http://www.w3.org/2001/XMLSchema#base64Binary";
                    //--TRIMMABLE-BOUNDARY-END(4295557189)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(8590524485)
                    this.Base64Octet = "http://www.w3.org/2001/XMLSchema#base64Octet";
                    //--TRIMMABLE-BOUNDARY-END(8590524485)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(12885491781)
                    this.Boolean = "http://www.w3.org/2001/XMLSchema#boolean";
                    //--TRIMMABLE-BOUNDARY-END(12885491781)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(17180459077)
                    this.Date = "http://www.w3.org/2001/XMLSchema#date";
                    //--TRIMMABLE-BOUNDARY-END(17180459077)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(21475426373)
                    this.DateTime = "http://www.w3.org/2001/XMLSchema#dateTime";
                    //--TRIMMABLE-BOUNDARY-END(21475426373)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(34360328261)
                    this.Double = "http://www.w3.org/2001/XMLSchema#double";
                    //--TRIMMABLE-BOUNDARY-END(34360328261)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(47245230149)
                    this.Fqbn = "http://www.w3.org/2001/XMLSchema#fqbn";
                    //--TRIMMABLE-BOUNDARY-END(47245230149)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(51540197445)
                    this.HexBinary = "http://www.w3.org/2001/XMLSchema#hexBinary";
                    //--TRIMMABLE-BOUNDARY-END(51540197445)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(55835164741)
                    this.Integer = "http://www.w3.org/2001/XMLSchema#integer";
                    //--TRIMMABLE-BOUNDARY-END(55835164741)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(60130132037)
                    this.Integer32 = "http://www.w3.org/2001/XMLSchema#integer32";
                    //--TRIMMABLE-BOUNDARY-END(60130132037)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(64425099333)
                    this.Integer64 = "http://www.w3.org/2001/XMLSchema#integer64";
                    //--TRIMMABLE-BOUNDARY-END(64425099333)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(85899935813)
                    this.Sid = "http://www.w3.org/2001/XMLSchema#sid";
                    //--TRIMMABLE-BOUNDARY-END(85899935813)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(94489870405)
                    this.String = "http://www.w3.org/2001/XMLSchema#string";
                    //--TRIMMABLE-BOUNDARY-END(94489870405)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(98784837701)
                    this.Time = "http://www.w3.org/2001/XMLSchema#time";
                    //--TRIMMABLE-BOUNDARY-END(98784837701)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(103079804997)
                    this.UInteger32 = "http://www.w3.org/2001/XMLSchema#uinteger32";
                    //--TRIMMABLE-BOUNDARY-END(103079804997)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(107374772293)
                    this.UInteger64 = "http://www.w3.org/2001/XMLSchema#uinteger64";
                    //--TRIMMABLE-BOUNDARY-END(107374772293)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(90194903109)
                    this.SoapSchemaNamespace = "http://schemas.xmlsoap.org/";
                    //--TRIMMABLE-BOUNDARY-END(90194903109)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(30065360965)
                    this.DnsName = "http://schemas.xmlsoap.org/claims/dns";
                    //--TRIMMABLE-BOUNDARY-END(30065360965)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(42950262853)
                    this.Email = "http://schemas.xmlsoap.org/ws/2005/05/identity/claims/emailaddress";
                    //--TRIMMABLE-BOUNDARY-END(42950262853)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(77310001221)
                    this.Rsa = "http://schemas.xmlsoap.org/ws/2005/05/identity/claims/rsa";
                    //--TRIMMABLE-BOUNDARY-END(77310001221)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(111669739589)
                    this.UpnName = "http://schemas.xmlsoap.org/claims/UPN";
                    //--TRIMMABLE-BOUNDARY-END(111669739589)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(128849608773)
                    this.XmlSignatureConstantsNamespace = "http://www.w3.org/2000/09/xmldsig#";
                    //--TRIMMABLE-BOUNDARY-END(128849608773)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(38655295557)
                    this.DsaKeyValue = "http://www.w3.org/2000/09/xmldsig#DSAKeyValue";
                    //--TRIMMABLE-BOUNDARY-END(38655295557)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(68720066629)
                    this.KeyInfo = "http://www.w3.org/2000/09/xmldsig#KeyInfo";
                    //--TRIMMABLE-BOUNDARY-END(68720066629)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(81604968517)
                    this.RsaKeyValue = "http://www.w3.org/2000/09/xmldsig#RSAKeyValue";
                    //--TRIMMABLE-BOUNDARY-END(81604968517)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(133144576069)
                    this.XQueryOperatorsNameSpace = "http://www.w3.org/TR/2002/WD-xquery-operators-20020816";
                    //--TRIMMABLE-BOUNDARY-END(133144576069)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(25770393669)
                    this.DaytimeDuration = "http://www.w3.org/TR/2002/WD-xquery-operators-20020816#dayTimeDuration";
                    //--TRIMMABLE-BOUNDARY-END(25770393669)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(137439543365)
                    this.YearMonthDuration = "http://www.w3.org/TR/2002/WD-xquery-operators-20020816#yearMonthDuration";
                    //--TRIMMABLE-BOUNDARY-END(137439543365)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(120259674181)
                    this.Xacml10Namespace = "urn:oasis:names:tc:xacml:1.0";
                    //--TRIMMABLE-BOUNDARY-END(120259674181)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(73015033925)
                    this.Rfc822Name = "urn:oasis:names:tc:xacml:1.0:data-type:rfc822Name";
                    //--TRIMMABLE-BOUNDARY-END(73015033925)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(115964706885)
                    this.X500Name = "urn:oasis:names:tc:xacml:1.0:data-type:x500Name";
                    //--TRIMMABLE-BOUNDARY-END(115964706885)
                    
                }
            }
            //--TRIMMABLE-BOUNDARY-END(SINIT)
            
            static $h = 589893;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 131073,
  "l": [
//--TRIMMABLE-BOUNDARY-START(124554641477),
    {
      "t": 1310721,
      "n": "XmlSchemaNamespace",
      "d": 589893,
      "h": 124554641477,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(124554641477),
//--TRIMMABLE-BOUNDARY-START(4295557189),
    {
      "t": 1310721,
      "n": "Base64Binary",
      "d": 589893,
      "h": 4295557189,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(4295557189),
//--TRIMMABLE-BOUNDARY-START(8590524485),
    {
      "t": 1310721,
      "n": "Base64Octet",
      "d": 589893,
      "h": 8590524485,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(8590524485),
//--TRIMMABLE-BOUNDARY-START(12885491781),
    {
      "t": 1310721,
      "n": "Boolean",
      "d": 589893,
      "h": 12885491781,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(12885491781),
//--TRIMMABLE-BOUNDARY-START(17180459077),
    {
      "t": 1310721,
      "n": "Date",
      "d": 589893,
      "h": 17180459077,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(17180459077),
//--TRIMMABLE-BOUNDARY-START(21475426373),
    {
      "t": 1310721,
      "n": "DateTime",
      "d": 589893,
      "h": 21475426373,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(21475426373),
//--TRIMMABLE-BOUNDARY-START(34360328261),
    {
      "t": 1310721,
      "n": "Double",
      "d": 589893,
      "h": 34360328261,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(34360328261),
//--TRIMMABLE-BOUNDARY-START(47245230149),
    {
      "t": 1310721,
      "n": "Fqbn",
      "d": 589893,
      "h": 47245230149,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(47245230149),
//--TRIMMABLE-BOUNDARY-START(51540197445),
    {
      "t": 1310721,
      "n": "HexBinary",
      "d": 589893,
      "h": 51540197445,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(51540197445),
//--TRIMMABLE-BOUNDARY-START(55835164741),
    {
      "t": 1310721,
      "n": "Integer",
      "d": 589893,
      "h": 55835164741,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(55835164741),
//--TRIMMABLE-BOUNDARY-START(60130132037),
    {
      "t": 1310721,
      "n": "Integer32",
      "d": 589893,
      "h": 60130132037,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(60130132037),
//--TRIMMABLE-BOUNDARY-START(64425099333),
    {
      "t": 1310721,
      "n": "Integer64",
      "d": 589893,
      "h": 64425099333,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(64425099333),
//--TRIMMABLE-BOUNDARY-START(85899935813),
    {
      "t": 1310721,
      "n": "Sid",
      "d": 589893,
      "h": 85899935813,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(85899935813),
//--TRIMMABLE-BOUNDARY-START(94489870405),
    {
      "t": 1310721,
      "n": "String",
      "d": 589893,
      "h": 94489870405,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(94489870405),
//--TRIMMABLE-BOUNDARY-START(98784837701),
    {
      "t": 1310721,
      "n": "Time",
      "d": 589893,
      "h": 98784837701,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(98784837701),
//--TRIMMABLE-BOUNDARY-START(103079804997),
    {
      "t": 1310721,
      "n": "UInteger32",
      "d": 589893,
      "h": 103079804997,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(103079804997),
//--TRIMMABLE-BOUNDARY-START(107374772293),
    {
      "t": 1310721,
      "n": "UInteger64",
      "d": 589893,
      "h": 107374772293,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(107374772293),
//--TRIMMABLE-BOUNDARY-START(90194903109),
    {
      "t": 1310721,
      "n": "SoapSchemaNamespace",
      "d": 589893,
      "h": 90194903109,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(90194903109),
//--TRIMMABLE-BOUNDARY-START(30065360965),
    {
      "t": 1310721,
      "n": "DnsName",
      "d": 589893,
      "h": 30065360965,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(30065360965),
//--TRIMMABLE-BOUNDARY-START(42950262853),
    {
      "t": 1310721,
      "n": "Email",
      "d": 589893,
      "h": 42950262853,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(42950262853),
//--TRIMMABLE-BOUNDARY-START(77310001221),
    {
      "t": 1310721,
      "n": "Rsa",
      "d": 589893,
      "h": 77310001221,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(77310001221),
//--TRIMMABLE-BOUNDARY-START(111669739589),
    {
      "t": 1310721,
      "n": "UpnName",
      "d": 589893,
      "h": 111669739589,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(111669739589),
//--TRIMMABLE-BOUNDARY-START(128849608773),
    {
      "t": 1310721,
      "n": "XmlSignatureConstantsNamespace",
      "d": 589893,
      "h": 128849608773,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(128849608773),
//--TRIMMABLE-BOUNDARY-START(38655295557),
    {
      "t": 1310721,
      "n": "DsaKeyValue",
      "d": 589893,
      "h": 38655295557,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(38655295557),
//--TRIMMABLE-BOUNDARY-START(68720066629),
    {
      "t": 1310721,
      "n": "KeyInfo",
      "d": 589893,
      "h": 68720066629,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(68720066629),
//--TRIMMABLE-BOUNDARY-START(81604968517),
    {
      "t": 1310721,
      "n": "RsaKeyValue",
      "d": 589893,
      "h": 81604968517,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(81604968517),
//--TRIMMABLE-BOUNDARY-START(133144576069),
    {
      "t": 1310721,
      "n": "XQueryOperatorsNameSpace",
      "d": 589893,
      "h": 133144576069,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(133144576069),
//--TRIMMABLE-BOUNDARY-START(25770393669),
    {
      "t": 1310721,
      "n": "DaytimeDuration",
      "d": 589893,
      "h": 25770393669,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(25770393669),
//--TRIMMABLE-BOUNDARY-START(137439543365),
    {
      "t": 1310721,
      "n": "YearMonthDuration",
      "d": 589893,
      "h": 137439543365,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(137439543365),
//--TRIMMABLE-BOUNDARY-START(120259674181),
    {
      "t": 1310721,
      "n": "Xacml10Namespace",
      "d": 589893,
      "h": 120259674181,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(120259674181),
//--TRIMMABLE-BOUNDARY-START(73015033925),
    {
      "t": 1310721,
      "n": "Rfc822Name",
      "d": 589893,
      "h": 73015033925,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(73015033925),
//--TRIMMABLE-BOUNDARY-START(115964706885),
    {
      "t": 1310721,
      "n": "X500Name",
      "d": 589893,
      "h": 115964706885,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(115964706885)
  ],
  "h": 589893
}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `System.Security.Claims.ClaimValueTypes`; }
        });
        //--TRIMMABLE-BOUNDARY-END(589893)
        
        
        //--TRIMMABLE-BOUNDARY-START(786501)
        $asm.$cls("$ssc.System.SR", ($self) => class SR
        {
            //--TRIMMABLE-BOUNDARY-START(141734707269)
            /*global::System.Resources.ResourceManager*/ static s_resourceManager = null;
            //--TRIMMABLE-BOUNDARY-END(141734707269)
            
            //--TRIMMABLE-BOUNDARY-START(133144772677)
            /*global::System.Globalization.CultureInfo*/ static resourceCulture = null;
            //--TRIMMABLE-BOUNDARY-END(133144772677)
            
            //--TRIMMABLE-BOUNDARY-START(137439739973)
            static /*global::System.Resources.ResourceManager */ get ResourceManager()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(103080001605);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$$.System.Object.ReferenceEquals($.$ssc.System.SR.s_resourceManager, null))
                {
                    /*global::System.Resources.ResourceManager*/ let temp = new $.$$.System.Resources.ResourceManager().$ctor$3("System.Security.Claims", $.$ssc.System.SR.$type.Assembly);
                    $.$ssc.System.SR.s_resourceManager = temp;
                }
                return $.$ssc.System.SR.s_resourceManager;
            }
            //--TRIMMABLE-BOUNDARY-END(137439739973)
            
            //--TRIMMABLE-BOUNDARY-START(12885688389)
            static /*global::System.Globalization.CultureInfo */ get Culture()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(68720263237);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$ssc.System.SR.resourceCulture;
            }
            static /*global::System.Globalization.CultureInfo */ set Culture(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(154619609157);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$ssc.System.SR.resourceCulture = value;
            }
            //--TRIMMABLE-BOUNDARY-END(12885688389)
            
            //--TRIMMABLE-BOUNDARY-START(8590721093)
            static /*string */ get ArgumentException_StringComparisonCultureAware()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(60130328645);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "The StringComparison must be one of Ordinal, OrdinalIgnoreCase, InvariantCulture, InvariantCultureIgnoreCase.";
            }
            //--TRIMMABLE-BOUNDARY-END(8590721093)
            
            //--TRIMMABLE-BOUNDARY-START(120259870789)
            static /*string */ get InvalidOperation_ClaimCannotBeRemoved()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(77310197829);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "The Claim '{0}' was not able to be removed.  It is either not part of this Identity or it is a Claim that is owned by the Principal that contains this Identity. For example, the Principal will own the Claim when creating a GenericPrincipal with roles. The roles will be exposed through the Identity that is passed in the constructor, but not actually owned by the Identity.  Similar logic exists for a RolePrincipal.";
            }
            //--TRIMMABLE-BOUNDARY-END(120259870789)
            
            //--TRIMMABLE-BOUNDARY-START(51540394053)
            static /*string */ FormatInvalidOperation_ClaimCannotBeRemoved(/*object*/ arg1)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(51540394053);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$$.System.String.Format$9("The Claim '{0}' was not able to be removed.  It is either not part of this Identity or it is a Claim that is owned by the Principal that contains this Identity. For example, the Principal will own the Claim when creating a GenericPrincipal with roles. The roles will be exposed through the Identity that is passed in the constructor, but not actually owned by the Identity.  Similar logic exists for a RolePrincipal.", arg1);
            }
            //--TRIMMABLE-BOUNDARY-END(51540394053)
            
            //--TRIMMABLE-BOUNDARY-START(124554838085)
            static /*string */ get InvalidOperationException_ActorGraphCircular()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(85900132421);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "An Actor must not create a circular reference between itself (or one of its child Actors) and one of its parents.";
            }
            //--TRIMMABLE-BOUNDARY-END(124554838085)
            
            //--TRIMMABLE-BOUNDARY-START(128849805381)
            static /*string */ get PlatformNotSupported_Serialization()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(94490067013);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "This instance contains state that cannot be serialized and deserialized on this platform.";
            }
            //--TRIMMABLE-BOUNDARY-END(128849805381)
            
            //--TRIMMABLE-BOUNDARY-START(146029674565)
            /*bool*/ static s_usingResourceKeys = false;
            //--TRIMMABLE-BOUNDARY-END(146029674565)
            
            //--TRIMMABLE-BOUNDARY-START(115964903493)
            static /*bool */ GetUsingResourceKeysSwitchValue()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(115964903493);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    /*bool*/ let usingResourceKeys;
                    return $.$$.System.AppContext.TryGetSwitch("System.Resources.UseSystemResourceKeys", $.$ref(() => usingResourceKeys, ($v) => usingResourceKeys = $v, $.$$.System.Boolean)) ? usingResourceKeys : false;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(115964903493)
            
            //--TRIMMABLE-BOUNDARY-START(158914576453)
            static /*bool */ UsingResourceKeys()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(158914576453);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return $.$ssc.System.SR.s_usingResourceKeys;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(158914576453)
            
            //--TRIMMABLE-BOUNDARY-START(111669936197)
            static /*string */ GetResourceString$1(/*string*/ resourceKey)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(111669936197);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$ssc.System.SR.UsingResourceKeys())
                {
                    return resourceKey;
                }
                /*string?*/ let resourceString = null;
                try
                {
                    resourceString = $.$ssc.System.SR.ResourceManager.GetString$1(resourceKey);
                }
                catch($e)
                {
                }
                return resourceString;
            }
            //--TRIMMABLE-BOUNDARY-END(111669936197)
            
            //--TRIMMABLE-BOUNDARY-START(107374968901)
            static /*string */ GetResourceString(/*string*/ resourceKey, /*string*/ defaultString)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(107374968901);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*string*/ let resourceString = $.$ssc.System.SR.GetResourceString$1(resourceKey);
                return $.$$.System.String.op_Equality(resourceKey, resourceString) || $.$$.System.String.op_Equality(resourceString, null) ? defaultString : resourceString;
            }
            //--TRIMMABLE-BOUNDARY-END(107374968901)
            
            //--TRIMMABLE-BOUNDARY-START(42950459461)
            static /*string */ Format$6(/*string*/ resourceFormat, /*object?*/ p1)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(42950459461);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$ssc.System.SR.UsingResourceKeys())
                {
                    return $.$$.System.String.Join$7(", ", $.$$.System.ReadOnlySpan$$($.$$.System.Object).op_Implicit$1([ resourceFormat, p1 ]));
                }
                return $.$$.System.String.Format$9(resourceFormat, p1);
            }
            //--TRIMMABLE-BOUNDARY-END(42950459461)
            
            //--TRIMMABLE-BOUNDARY-START(38655492165)
            static /*string */ Format$5(/*string*/ resourceFormat, /*object?*/ p1, /*object?*/ p2)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(38655492165);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$ssc.System.SR.UsingResourceKeys())
                {
                    return $.$$.System.String.Join$7(", ", $.$$.System.ReadOnlySpan$$($.$$.System.Object).op_Implicit$1([ resourceFormat, p1, p2 ]));
                }
                return $.$$.System.String.Format$8(resourceFormat, p1, p2);
            }
            //--TRIMMABLE-BOUNDARY-END(38655492165)
            
            //--TRIMMABLE-BOUNDARY-START(34360524869)
            static /*string */ Format$4(/*string*/ resourceFormat, /*object?*/ p1, /*object?*/ p2, /*object?*/ p3)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(34360524869);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$ssc.System.SR.UsingResourceKeys())
                {
                    return $.$$.System.String.Join$7(", ", $.$$.System.ReadOnlySpan$$($.$$.System.Object).op_Implicit$1([ resourceFormat, p1, p2, p3 ]));
                }
                return $.$$.System.String.Format$7(resourceFormat, p1, p2, p3);
            }
            //--TRIMMABLE-BOUNDARY-END(34360524869)
            
            //--TRIMMABLE-BOUNDARY-START(47245426757)
            static /*string */ Format$7(/*string*/ resourceFormat, /*params object?[]?*/ args)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(47245426757);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (args !== null)
                {
                    if ($.$ssc.System.SR.UsingResourceKeys())
                    {
                        return resourceFormat + ", " + $.$$.System.String.Join$6(", ", args);
                    }
                    return $.$$.System.String.Format$10(resourceFormat, args);
                }
                return resourceFormat;
            }
            //--TRIMMABLE-BOUNDARY-END(47245426757)
            
            //--TRIMMABLE-BOUNDARY-START(25770590277)
            static /*string */ Format$2(/*IFormatProvider?*/ provider, /*string*/ resourceFormat, /*object?*/ p1)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25770590277);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$ssc.System.SR.UsingResourceKeys())
                {
                    return $.$$.System.String.Join$7(", ", $.$$.System.ReadOnlySpan$$($.$$.System.Object).op_Implicit$1([ resourceFormat, p1 ]));
                }
                return $.$$.System.String.Format$2(provider, resourceFormat, p1);
            }
            //--TRIMMABLE-BOUNDARY-END(25770590277)
            
            //--TRIMMABLE-BOUNDARY-START(21475622981)
            static /*string */ Format$1(/*IFormatProvider?*/ provider, /*string*/ resourceFormat, /*object?*/ p1, /*object?*/ p2)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21475622981);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$ssc.System.SR.UsingResourceKeys())
                {
                    return $.$$.System.String.Join$7(", ", $.$$.System.ReadOnlySpan$$($.$$.System.Object).op_Implicit$1([ resourceFormat, p1, p2 ]));
                }
                return $.$$.System.String.Format$1(provider, resourceFormat, p1, p2);
            }
            //--TRIMMABLE-BOUNDARY-END(21475622981)
            
            //--TRIMMABLE-BOUNDARY-START(17180655685)
            static /*string */ Format(/*IFormatProvider?*/ provider, /*string*/ resourceFormat, /*object?*/ p1, /*object?*/ p2, /*object?*/ p3)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17180655685);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$ssc.System.SR.UsingResourceKeys())
                {
                    return $.$$.System.String.Join$7(", ", $.$$.System.ReadOnlySpan$$($.$$.System.Object).op_Implicit$1([ resourceFormat, p1, p2, p3 ]));
                }
                return $.$$.System.String.Format(provider, resourceFormat, p1, p2, p3);
            }
            //--TRIMMABLE-BOUNDARY-END(17180655685)
            
            //--TRIMMABLE-BOUNDARY-START(30065557573)
            static /*string */ Format$3(/*IFormatProvider?*/ provider, /*string*/ resourceFormat, /*params object?[]?*/ args)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(30065557573);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (args !== null)
                {
                    if ($.$ssc.System.SR.UsingResourceKeys())
                    {
                        return resourceFormat + ", " + $.$$.System.String.Join$6(", ", args);
                    }
                    return $.$$.System.String.Format$3(provider, resourceFormat, args);
                }
                return resourceFormat;
            }
            //--TRIMMABLE-BOUNDARY-END(30065557573)
            
            //--TRIMMABLE-BOUNDARY-START(4295753797)
            //Static Initializer
            static $sinit()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(146029674565)
                    this.s_usingResourceKeys = $.$ssc.System.SR.GetUsingResourceKeysSwitchValue();
                    //--TRIMMABLE-BOUNDARY-END(146029674565)
                    
                }
            }
            //--TRIMMABLE-BOUNDARY-END(4295753797)
            
            static $h = 786501;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 131073,
  "h": 786501
}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `System.SR`; }
        });
        //--TRIMMABLE-BOUNDARY-END(786501)
        
        
        //--TRIMMABLE-BOUNDARY-START(524357)
        $asm.$cls("$ssc.System.Security.Claims.ClaimTypes", ($self) => class ClaimTypes
        {
            //--TRIMMABLE-BOUNDARY-START(38655230021)
            /*string*/ static ClaimTypeNamespace = null;
            //--TRIMMABLE-BOUNDARY-END(38655230021)
            
            //--TRIMMABLE-BOUNDARY-START(17180393541)
            /*string*/ static AuthenticationInstant = null;
            //--TRIMMABLE-BOUNDARY-END(17180393541)
            
            //--TRIMMABLE-BOUNDARY-START(21475360837)
            /*string*/ static AuthenticationMethod = null;
            //--TRIMMABLE-BOUNDARY-END(21475360837)
            
            //--TRIMMABLE-BOUNDARY-START(42950197317)
            /*string*/ static CookiePath = null;
            //--TRIMMABLE-BOUNDARY-END(42950197317)
            
            //--TRIMMABLE-BOUNDARY-START(60130066501)
            /*string*/ static DenyOnlyPrimarySid = null;
            //--TRIMMABLE-BOUNDARY-END(60130066501)
            
            //--TRIMMABLE-BOUNDARY-START(55835099205)
            /*string*/ static DenyOnlyPrimaryGroupSid = null;
            //--TRIMMABLE-BOUNDARY-END(55835099205)
            
            //--TRIMMABLE-BOUNDARY-START(68720001093)
            /*string*/ static DenyOnlyWindowsDeviceGroup = null;
            //--TRIMMABLE-BOUNDARY-END(68720001093)
            
            //--TRIMMABLE-BOUNDARY-START(77309935685)
            /*string*/ static Dsa = null;
            //--TRIMMABLE-BOUNDARY-END(77309935685)
            
            //--TRIMMABLE-BOUNDARY-START(85899870277)
            /*string*/ static Expiration = null;
            //--TRIMMABLE-BOUNDARY-END(85899870277)
            
            //--TRIMMABLE-BOUNDARY-START(90194837573)
            /*string*/ static Expired = null;
            //--TRIMMABLE-BOUNDARY-END(90194837573)
            
            //--TRIMMABLE-BOUNDARY-START(103079739461)
            /*string*/ static GroupSid = null;
            //--TRIMMABLE-BOUNDARY-END(103079739461)
            
            //--TRIMMABLE-BOUNDARY-START(115964641349)
            /*string*/ static IsPersistent = null;
            //--TRIMMABLE-BOUNDARY-END(115964641349)
            
            //--TRIMMABLE-BOUNDARY-START(146029412421)
            /*string*/ static PrimaryGroupSid = null;
            //--TRIMMABLE-BOUNDARY-END(146029412421)
            
            //--TRIMMABLE-BOUNDARY-START(150324379717)
            /*string*/ static PrimarySid = null;
            //--TRIMMABLE-BOUNDARY-END(150324379717)
            
            //--TRIMMABLE-BOUNDARY-START(154619347013)
            /*string*/ static Role = null;
            //--TRIMMABLE-BOUNDARY-END(154619347013)
            
            //--TRIMMABLE-BOUNDARY-START(163209281605)
            /*string*/ static SerialNumber = null;
            //--TRIMMABLE-BOUNDARY-END(163209281605)
            
            //--TRIMMABLE-BOUNDARY-START(206158954565)
            /*string*/ static UserData = null;
            //--TRIMMABLE-BOUNDARY-END(206158954565)
            
            //--TRIMMABLE-BOUNDARY-START(210453921861)
            /*string*/ static Version = null;
            //--TRIMMABLE-BOUNDARY-END(210453921861)
            
            //--TRIMMABLE-BOUNDARY-START(219043856453)
            /*string*/ static WindowsAccountName = null;
            //--TRIMMABLE-BOUNDARY-END(219043856453)
            
            //--TRIMMABLE-BOUNDARY-START(223338823749)
            /*string*/ static WindowsDeviceClaim = null;
            //--TRIMMABLE-BOUNDARY-END(223338823749)
            
            //--TRIMMABLE-BOUNDARY-START(227633791045)
            /*string*/ static WindowsDeviceGroup = null;
            //--TRIMMABLE-BOUNDARY-END(227633791045)
            
            //--TRIMMABLE-BOUNDARY-START(240518692933)
            /*string*/ static WindowsUserClaim = null;
            //--TRIMMABLE-BOUNDARY-END(240518692933)
            
            //--TRIMMABLE-BOUNDARY-START(231928758341)
            /*string*/ static WindowsFqbnVersion = null;
            //--TRIMMABLE-BOUNDARY-END(231928758341)
            
            //--TRIMMABLE-BOUNDARY-START(236223725637)
            /*string*/ static WindowsSubAuthority = null;
            //--TRIMMABLE-BOUNDARY-END(236223725637)
            
            //--TRIMMABLE-BOUNDARY-START(30065295429)
            /*string*/ static ClaimType2005Namespace = null;
            //--TRIMMABLE-BOUNDARY-END(30065295429)
            
            //--TRIMMABLE-BOUNDARY-START(8590458949)
            /*string*/ static Anonymous = null;
            //--TRIMMABLE-BOUNDARY-END(8590458949)
            
            //--TRIMMABLE-BOUNDARY-START(12885426245)
            /*string*/ static Authentication = null;
            //--TRIMMABLE-BOUNDARY-END(12885426245)
            
            //--TRIMMABLE-BOUNDARY-START(25770328133)
            /*string*/ static AuthorizationDecision = null;
            //--TRIMMABLE-BOUNDARY-END(25770328133)
            
            //--TRIMMABLE-BOUNDARY-START(47245164613)
            /*string*/ static Country = null;
            //--TRIMMABLE-BOUNDARY-END(47245164613)
            
            //--TRIMMABLE-BOUNDARY-START(51540131909)
            /*string*/ static DateOfBirth = null;
            //--TRIMMABLE-BOUNDARY-END(51540131909)
            
            //--TRIMMABLE-BOUNDARY-START(73014968389)
            /*string*/ static Dns = null;
            //--TRIMMABLE-BOUNDARY-END(73014968389)
            
            //--TRIMMABLE-BOUNDARY-START(64425033797)
            /*string*/ static DenyOnlySid = null;
            //--TRIMMABLE-BOUNDARY-END(64425033797)
            
            //--TRIMMABLE-BOUNDARY-START(81604902981)
            /*string*/ static Email = null;
            //--TRIMMABLE-BOUNDARY-END(81604902981)
            
            //--TRIMMABLE-BOUNDARY-START(94489804869)
            /*string*/ static Gender = null;
            //--TRIMMABLE-BOUNDARY-END(94489804869)
            
            //--TRIMMABLE-BOUNDARY-START(98784772165)
            /*string*/ static GivenName = null;
            //--TRIMMABLE-BOUNDARY-END(98784772165)
            
            //--TRIMMABLE-BOUNDARY-START(107374706757)
            /*string*/ static Hash = null;
            //--TRIMMABLE-BOUNDARY-END(107374706757)
            
            //--TRIMMABLE-BOUNDARY-START(111669674053)
            /*string*/ static HomePhone = null;
            //--TRIMMABLE-BOUNDARY-END(111669674053)
            
            //--TRIMMABLE-BOUNDARY-START(120259608645)
            /*string*/ static Locality = null;
            //--TRIMMABLE-BOUNDARY-END(120259608645)
            
            //--TRIMMABLE-BOUNDARY-START(124554575941)
            /*string*/ static MobilePhone = null;
            //--TRIMMABLE-BOUNDARY-END(124554575941)
            
            //--TRIMMABLE-BOUNDARY-START(128849543237)
            /*string*/ static Name = null;
            //--TRIMMABLE-BOUNDARY-END(128849543237)
            
            //--TRIMMABLE-BOUNDARY-START(133144510533)
            /*string*/ static NameIdentifier = null;
            //--TRIMMABLE-BOUNDARY-END(133144510533)
            
            //--TRIMMABLE-BOUNDARY-START(137439477829)
            /*string*/ static OtherPhone = null;
            //--TRIMMABLE-BOUNDARY-END(137439477829)
            
            //--TRIMMABLE-BOUNDARY-START(141734445125)
            /*string*/ static PostalCode = null;
            //--TRIMMABLE-BOUNDARY-END(141734445125)
            
            //--TRIMMABLE-BOUNDARY-START(158914314309)
            /*string*/ static Rsa = null;
            //--TRIMMABLE-BOUNDARY-END(158914314309)
            
            //--TRIMMABLE-BOUNDARY-START(167504248901)
            /*string*/ static Sid = null;
            //--TRIMMABLE-BOUNDARY-END(167504248901)
            
            //--TRIMMABLE-BOUNDARY-START(171799216197)
            /*string*/ static Spn = null;
            //--TRIMMABLE-BOUNDARY-END(171799216197)
            
            //--TRIMMABLE-BOUNDARY-START(176094183493)
            /*string*/ static StateOrProvince = null;
            //--TRIMMABLE-BOUNDARY-END(176094183493)
            
            //--TRIMMABLE-BOUNDARY-START(180389150789)
            /*string*/ static StreetAddress = null;
            //--TRIMMABLE-BOUNDARY-END(180389150789)
            
            //--TRIMMABLE-BOUNDARY-START(184684118085)
            /*string*/ static Surname = null;
            //--TRIMMABLE-BOUNDARY-END(184684118085)
            
            //--TRIMMABLE-BOUNDARY-START(188979085381)
            /*string*/ static System = null;
            //--TRIMMABLE-BOUNDARY-END(188979085381)
            
            //--TRIMMABLE-BOUNDARY-START(193274052677)
            /*string*/ static Thumbprint = null;
            //--TRIMMABLE-BOUNDARY-END(193274052677)
            
            //--TRIMMABLE-BOUNDARY-START(197569019973)
            /*string*/ static Upn = null;
            //--TRIMMABLE-BOUNDARY-END(197569019973)
            
            //--TRIMMABLE-BOUNDARY-START(201863987269)
            /*string*/ static Uri = null;
            //--TRIMMABLE-BOUNDARY-END(201863987269)
            
            //--TRIMMABLE-BOUNDARY-START(214748889157)
            /*string*/ static Webpage = null;
            //--TRIMMABLE-BOUNDARY-END(214748889157)
            
            //--TRIMMABLE-BOUNDARY-START(244813660229)
            /*string*/ static X500DistinguishedName = null;
            //--TRIMMABLE-BOUNDARY-END(244813660229)
            
            //--TRIMMABLE-BOUNDARY-START(34360262725)
            /*string*/ static ClaimType2009Namespace = null;
            //--TRIMMABLE-BOUNDARY-END(34360262725)
            
            //--TRIMMABLE-BOUNDARY-START(4295491653)
            /*string*/ static Actor = null;
            //--TRIMMABLE-BOUNDARY-END(4295491653)
            
            //--TRIMMABLE-BOUNDARY-START(SINIT)
            //Static Initializer
            static $sinit()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(38655230021)
                    this.ClaimTypeNamespace = "http://schemas.microsoft.com/ws/2008/06/identity/claims";
                    //--TRIMMABLE-BOUNDARY-END(38655230021)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(17180393541)
                    this.AuthenticationInstant = "http://schemas.microsoft.com/ws/2008/06/identity/claims/authenticationinstant";
                    //--TRIMMABLE-BOUNDARY-END(17180393541)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(21475360837)
                    this.AuthenticationMethod = "http://schemas.microsoft.com/ws/2008/06/identity/claims/authenticationmethod";
                    //--TRIMMABLE-BOUNDARY-END(21475360837)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(42950197317)
                    this.CookiePath = "http://schemas.microsoft.com/ws/2008/06/identity/claims/cookiepath";
                    //--TRIMMABLE-BOUNDARY-END(42950197317)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(60130066501)
                    this.DenyOnlyPrimarySid = "http://schemas.microsoft.com/ws/2008/06/identity/claims/denyonlyprimarysid";
                    //--TRIMMABLE-BOUNDARY-END(60130066501)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(55835099205)
                    this.DenyOnlyPrimaryGroupSid = "http://schemas.microsoft.com/ws/2008/06/identity/claims/denyonlyprimarygroupsid";
                    //--TRIMMABLE-BOUNDARY-END(55835099205)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(68720001093)
                    this.DenyOnlyWindowsDeviceGroup = "http://schemas.microsoft.com/ws/2008/06/identity/claims/denyonlywindowsdevicegroup";
                    //--TRIMMABLE-BOUNDARY-END(68720001093)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(77309935685)
                    this.Dsa = "http://schemas.microsoft.com/ws/2008/06/identity/claims/dsa";
                    //--TRIMMABLE-BOUNDARY-END(77309935685)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(85899870277)
                    this.Expiration = "http://schemas.microsoft.com/ws/2008/06/identity/claims/expiration";
                    //--TRIMMABLE-BOUNDARY-END(85899870277)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(90194837573)
                    this.Expired = "http://schemas.microsoft.com/ws/2008/06/identity/claims/expired";
                    //--TRIMMABLE-BOUNDARY-END(90194837573)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(103079739461)
                    this.GroupSid = "http://schemas.microsoft.com/ws/2008/06/identity/claims/groupsid";
                    //--TRIMMABLE-BOUNDARY-END(103079739461)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(115964641349)
                    this.IsPersistent = "http://schemas.microsoft.com/ws/2008/06/identity/claims/ispersistent";
                    //--TRIMMABLE-BOUNDARY-END(115964641349)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(146029412421)
                    this.PrimaryGroupSid = "http://schemas.microsoft.com/ws/2008/06/identity/claims/primarygroupsid";
                    //--TRIMMABLE-BOUNDARY-END(146029412421)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(150324379717)
                    this.PrimarySid = "http://schemas.microsoft.com/ws/2008/06/identity/claims/primarysid";
                    //--TRIMMABLE-BOUNDARY-END(150324379717)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(154619347013)
                    this.Role = "http://schemas.microsoft.com/ws/2008/06/identity/claims/role";
                    //--TRIMMABLE-BOUNDARY-END(154619347013)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(163209281605)
                    this.SerialNumber = "http://schemas.microsoft.com/ws/2008/06/identity/claims/serialnumber";
                    //--TRIMMABLE-BOUNDARY-END(163209281605)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(206158954565)
                    this.UserData = "http://schemas.microsoft.com/ws/2008/06/identity/claims/userdata";
                    //--TRIMMABLE-BOUNDARY-END(206158954565)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(210453921861)
                    this.Version = "http://schemas.microsoft.com/ws/2008/06/identity/claims/version";
                    //--TRIMMABLE-BOUNDARY-END(210453921861)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(219043856453)
                    this.WindowsAccountName = "http://schemas.microsoft.com/ws/2008/06/identity/claims/windowsaccountname";
                    //--TRIMMABLE-BOUNDARY-END(219043856453)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(223338823749)
                    this.WindowsDeviceClaim = "http://schemas.microsoft.com/ws/2008/06/identity/claims/windowsdeviceclaim";
                    //--TRIMMABLE-BOUNDARY-END(223338823749)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(227633791045)
                    this.WindowsDeviceGroup = "http://schemas.microsoft.com/ws/2008/06/identity/claims/windowsdevicegroup";
                    //--TRIMMABLE-BOUNDARY-END(227633791045)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(240518692933)
                    this.WindowsUserClaim = "http://schemas.microsoft.com/ws/2008/06/identity/claims/windowsuserclaim";
                    //--TRIMMABLE-BOUNDARY-END(240518692933)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(231928758341)
                    this.WindowsFqbnVersion = "http://schemas.microsoft.com/ws/2008/06/identity/claims/windowsfqbnversion";
                    //--TRIMMABLE-BOUNDARY-END(231928758341)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(236223725637)
                    this.WindowsSubAuthority = "http://schemas.microsoft.com/ws/2008/06/identity/claims/windowssubauthority";
                    //--TRIMMABLE-BOUNDARY-END(236223725637)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(30065295429)
                    this.ClaimType2005Namespace = "http://schemas.xmlsoap.org/ws/2005/05/identity/claims";
                    //--TRIMMABLE-BOUNDARY-END(30065295429)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(8590458949)
                    this.Anonymous = "http://schemas.xmlsoap.org/ws/2005/05/identity/claims/anonymous";
                    //--TRIMMABLE-BOUNDARY-END(8590458949)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(12885426245)
                    this.Authentication = "http://schemas.xmlsoap.org/ws/2005/05/identity/claims/authentication";
                    //--TRIMMABLE-BOUNDARY-END(12885426245)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(25770328133)
                    this.AuthorizationDecision = "http://schemas.xmlsoap.org/ws/2005/05/identity/claims/authorizationdecision";
                    //--TRIMMABLE-BOUNDARY-END(25770328133)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(47245164613)
                    this.Country = "http://schemas.xmlsoap.org/ws/2005/05/identity/claims/country";
                    //--TRIMMABLE-BOUNDARY-END(47245164613)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(51540131909)
                    this.DateOfBirth = "http://schemas.xmlsoap.org/ws/2005/05/identity/claims/dateofbirth";
                    //--TRIMMABLE-BOUNDARY-END(51540131909)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(73014968389)
                    this.Dns = "http://schemas.xmlsoap.org/ws/2005/05/identity/claims/dns";
                    //--TRIMMABLE-BOUNDARY-END(73014968389)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(64425033797)
                    this.DenyOnlySid = "http://schemas.xmlsoap.org/ws/2005/05/identity/claims/denyonlysid";
                    //--TRIMMABLE-BOUNDARY-END(64425033797)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(81604902981)
                    this.Email = "http://schemas.xmlsoap.org/ws/2005/05/identity/claims/emailaddress";
                    //--TRIMMABLE-BOUNDARY-END(81604902981)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(94489804869)
                    this.Gender = "http://schemas.xmlsoap.org/ws/2005/05/identity/claims/gender";
                    //--TRIMMABLE-BOUNDARY-END(94489804869)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(98784772165)
                    this.GivenName = "http://schemas.xmlsoap.org/ws/2005/05/identity/claims/givenname";
                    //--TRIMMABLE-BOUNDARY-END(98784772165)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(107374706757)
                    this.Hash = "http://schemas.xmlsoap.org/ws/2005/05/identity/claims/hash";
                    //--TRIMMABLE-BOUNDARY-END(107374706757)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(111669674053)
                    this.HomePhone = "http://schemas.xmlsoap.org/ws/2005/05/identity/claims/homephone";
                    //--TRIMMABLE-BOUNDARY-END(111669674053)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(120259608645)
                    this.Locality = "http://schemas.xmlsoap.org/ws/2005/05/identity/claims/locality";
                    //--TRIMMABLE-BOUNDARY-END(120259608645)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(124554575941)
                    this.MobilePhone = "http://schemas.xmlsoap.org/ws/2005/05/identity/claims/mobilephone";
                    //--TRIMMABLE-BOUNDARY-END(124554575941)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(128849543237)
                    this.Name = "http://schemas.xmlsoap.org/ws/2005/05/identity/claims/name";
                    //--TRIMMABLE-BOUNDARY-END(128849543237)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(133144510533)
                    this.NameIdentifier = "http://schemas.xmlsoap.org/ws/2005/05/identity/claims/nameidentifier";
                    //--TRIMMABLE-BOUNDARY-END(133144510533)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(137439477829)
                    this.OtherPhone = "http://schemas.xmlsoap.org/ws/2005/05/identity/claims/otherphone";
                    //--TRIMMABLE-BOUNDARY-END(137439477829)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(141734445125)
                    this.PostalCode = "http://schemas.xmlsoap.org/ws/2005/05/identity/claims/postalcode";
                    //--TRIMMABLE-BOUNDARY-END(141734445125)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(158914314309)
                    this.Rsa = "http://schemas.xmlsoap.org/ws/2005/05/identity/claims/rsa";
                    //--TRIMMABLE-BOUNDARY-END(158914314309)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(167504248901)
                    this.Sid = "http://schemas.xmlsoap.org/ws/2005/05/identity/claims/sid";
                    //--TRIMMABLE-BOUNDARY-END(167504248901)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(171799216197)
                    this.Spn = "http://schemas.xmlsoap.org/ws/2005/05/identity/claims/spn";
                    //--TRIMMABLE-BOUNDARY-END(171799216197)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(176094183493)
                    this.StateOrProvince = "http://schemas.xmlsoap.org/ws/2005/05/identity/claims/stateorprovince";
                    //--TRIMMABLE-BOUNDARY-END(176094183493)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(180389150789)
                    this.StreetAddress = "http://schemas.xmlsoap.org/ws/2005/05/identity/claims/streetaddress";
                    //--TRIMMABLE-BOUNDARY-END(180389150789)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(184684118085)
                    this.Surname = "http://schemas.xmlsoap.org/ws/2005/05/identity/claims/surname";
                    //--TRIMMABLE-BOUNDARY-END(184684118085)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(188979085381)
                    this.System = "http://schemas.xmlsoap.org/ws/2005/05/identity/claims/system";
                    //--TRIMMABLE-BOUNDARY-END(188979085381)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(193274052677)
                    this.Thumbprint = "http://schemas.xmlsoap.org/ws/2005/05/identity/claims/thumbprint";
                    //--TRIMMABLE-BOUNDARY-END(193274052677)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(197569019973)
                    this.Upn = "http://schemas.xmlsoap.org/ws/2005/05/identity/claims/upn";
                    //--TRIMMABLE-BOUNDARY-END(197569019973)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(201863987269)
                    this.Uri = "http://schemas.xmlsoap.org/ws/2005/05/identity/claims/uri";
                    //--TRIMMABLE-BOUNDARY-END(201863987269)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(214748889157)
                    this.Webpage = "http://schemas.xmlsoap.org/ws/2005/05/identity/claims/webpage";
                    //--TRIMMABLE-BOUNDARY-END(214748889157)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(244813660229)
                    this.X500DistinguishedName = "http://schemas.xmlsoap.org/ws/2005/05/identity/claims/x500distinguishedname";
                    //--TRIMMABLE-BOUNDARY-END(244813660229)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(34360262725)
                    this.ClaimType2009Namespace = "http://schemas.xmlsoap.org/ws/2009/09/identity/claims";
                    //--TRIMMABLE-BOUNDARY-END(34360262725)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(4295491653)
                    this.Actor = "http://schemas.xmlsoap.org/ws/2009/09/identity/claims/actor";
                    //--TRIMMABLE-BOUNDARY-END(4295491653)
                    
                }
            }
            //--TRIMMABLE-BOUNDARY-END(SINIT)
            
            static $h = 524357;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 131073,
  "l": [
//--TRIMMABLE-BOUNDARY-START(38655230021),
    {
      "t": 1310721,
      "n": "ClaimTypeNamespace",
      "d": 524357,
      "h": 38655230021,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(38655230021),
//--TRIMMABLE-BOUNDARY-START(17180393541),
    {
      "t": 1310721,
      "n": "AuthenticationInstant",
      "d": 524357,
      "h": 17180393541,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(17180393541),
//--TRIMMABLE-BOUNDARY-START(21475360837),
    {
      "t": 1310721,
      "n": "AuthenticationMethod",
      "d": 524357,
      "h": 21475360837,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(21475360837),
//--TRIMMABLE-BOUNDARY-START(42950197317),
    {
      "t": 1310721,
      "n": "CookiePath",
      "d": 524357,
      "h": 42950197317,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(42950197317),
//--TRIMMABLE-BOUNDARY-START(60130066501),
    {
      "t": 1310721,
      "n": "DenyOnlyPrimarySid",
      "d": 524357,
      "h": 60130066501,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(60130066501),
//--TRIMMABLE-BOUNDARY-START(55835099205),
    {
      "t": 1310721,
      "n": "DenyOnlyPrimaryGroupSid",
      "d": 524357,
      "h": 55835099205,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(55835099205),
//--TRIMMABLE-BOUNDARY-START(68720001093),
    {
      "t": 1310721,
      "n": "DenyOnlyWindowsDeviceGroup",
      "d": 524357,
      "h": 68720001093,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(68720001093),
//--TRIMMABLE-BOUNDARY-START(77309935685),
    {
      "t": 1310721,
      "n": "Dsa",
      "d": 524357,
      "h": 77309935685,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(77309935685),
//--TRIMMABLE-BOUNDARY-START(85899870277),
    {
      "t": 1310721,
      "n": "Expiration",
      "d": 524357,
      "h": 85899870277,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(85899870277),
//--TRIMMABLE-BOUNDARY-START(90194837573),
    {
      "t": 1310721,
      "n": "Expired",
      "d": 524357,
      "h": 90194837573,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(90194837573),
//--TRIMMABLE-BOUNDARY-START(103079739461),
    {
      "t": 1310721,
      "n": "GroupSid",
      "d": 524357,
      "h": 103079739461,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(103079739461),
//--TRIMMABLE-BOUNDARY-START(115964641349),
    {
      "t": 1310721,
      "n": "IsPersistent",
      "d": 524357,
      "h": 115964641349,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(115964641349),
//--TRIMMABLE-BOUNDARY-START(146029412421),
    {
      "t": 1310721,
      "n": "PrimaryGroupSid",
      "d": 524357,
      "h": 146029412421,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(146029412421),
//--TRIMMABLE-BOUNDARY-START(150324379717),
    {
      "t": 1310721,
      "n": "PrimarySid",
      "d": 524357,
      "h": 150324379717,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(150324379717),
//--TRIMMABLE-BOUNDARY-START(154619347013),
    {
      "t": 1310721,
      "n": "Role",
      "d": 524357,
      "h": 154619347013,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(154619347013),
//--TRIMMABLE-BOUNDARY-START(163209281605),
    {
      "t": 1310721,
      "n": "SerialNumber",
      "d": 524357,
      "h": 163209281605,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(163209281605),
//--TRIMMABLE-BOUNDARY-START(206158954565),
    {
      "t": 1310721,
      "n": "UserData",
      "d": 524357,
      "h": 206158954565,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(206158954565),
//--TRIMMABLE-BOUNDARY-START(210453921861),
    {
      "t": 1310721,
      "n": "Version",
      "d": 524357,
      "h": 210453921861,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(210453921861),
//--TRIMMABLE-BOUNDARY-START(219043856453),
    {
      "t": 1310721,
      "n": "WindowsAccountName",
      "d": 524357,
      "h": 219043856453,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(219043856453),
//--TRIMMABLE-BOUNDARY-START(223338823749),
    {
      "t": 1310721,
      "n": "WindowsDeviceClaim",
      "d": 524357,
      "h": 223338823749,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(223338823749),
//--TRIMMABLE-BOUNDARY-START(227633791045),
    {
      "t": 1310721,
      "n": "WindowsDeviceGroup",
      "d": 524357,
      "h": 227633791045,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(227633791045),
//--TRIMMABLE-BOUNDARY-START(240518692933),
    {
      "t": 1310721,
      "n": "WindowsUserClaim",
      "d": 524357,
      "h": 240518692933,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(240518692933),
//--TRIMMABLE-BOUNDARY-START(231928758341),
    {
      "t": 1310721,
      "n": "WindowsFqbnVersion",
      "d": 524357,
      "h": 231928758341,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(231928758341),
//--TRIMMABLE-BOUNDARY-START(236223725637),
    {
      "t": 1310721,
      "n": "WindowsSubAuthority",
      "d": 524357,
      "h": 236223725637,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(236223725637),
//--TRIMMABLE-BOUNDARY-START(30065295429),
    {
      "t": 1310721,
      "n": "ClaimType2005Namespace",
      "d": 524357,
      "h": 30065295429,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(30065295429),
//--TRIMMABLE-BOUNDARY-START(8590458949),
    {
      "t": 1310721,
      "n": "Anonymous",
      "d": 524357,
      "h": 8590458949,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(8590458949),
//--TRIMMABLE-BOUNDARY-START(12885426245),
    {
      "t": 1310721,
      "n": "Authentication",
      "d": 524357,
      "h": 12885426245,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(12885426245),
//--TRIMMABLE-BOUNDARY-START(25770328133),
    {
      "t": 1310721,
      "n": "AuthorizationDecision",
      "d": 524357,
      "h": 25770328133,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(25770328133),
//--TRIMMABLE-BOUNDARY-START(47245164613),
    {
      "t": 1310721,
      "n": "Country",
      "d": 524357,
      "h": 47245164613,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(47245164613),
//--TRIMMABLE-BOUNDARY-START(51540131909),
    {
      "t": 1310721,
      "n": "DateOfBirth",
      "d": 524357,
      "h": 51540131909,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(51540131909),
//--TRIMMABLE-BOUNDARY-START(73014968389),
    {
      "t": 1310721,
      "n": "Dns",
      "d": 524357,
      "h": 73014968389,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(73014968389),
//--TRIMMABLE-BOUNDARY-START(64425033797),
    {
      "t": 1310721,
      "n": "DenyOnlySid",
      "d": 524357,
      "h": 64425033797,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(64425033797),
//--TRIMMABLE-BOUNDARY-START(81604902981),
    {
      "t": 1310721,
      "n": "Email",
      "d": 524357,
      "h": 81604902981,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(81604902981),
//--TRIMMABLE-BOUNDARY-START(94489804869),
    {
      "t": 1310721,
      "n": "Gender",
      "d": 524357,
      "h": 94489804869,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(94489804869),
//--TRIMMABLE-BOUNDARY-START(98784772165),
    {
      "t": 1310721,
      "n": "GivenName",
      "d": 524357,
      "h": 98784772165,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(98784772165),
//--TRIMMABLE-BOUNDARY-START(107374706757),
    {
      "t": 1310721,
      "n": "Hash",
      "d": 524357,
      "h": 107374706757,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(107374706757),
//--TRIMMABLE-BOUNDARY-START(111669674053),
    {
      "t": 1310721,
      "n": "HomePhone",
      "d": 524357,
      "h": 111669674053,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(111669674053),
//--TRIMMABLE-BOUNDARY-START(120259608645),
    {
      "t": 1310721,
      "n": "Locality",
      "d": 524357,
      "h": 120259608645,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(120259608645),
//--TRIMMABLE-BOUNDARY-START(124554575941),
    {
      "t": 1310721,
      "n": "MobilePhone",
      "d": 524357,
      "h": 124554575941,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(124554575941),
//--TRIMMABLE-BOUNDARY-START(128849543237),
    {
      "t": 1310721,
      "n": "Name",
      "d": 524357,
      "h": 128849543237,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(128849543237),
//--TRIMMABLE-BOUNDARY-START(133144510533),
    {
      "t": 1310721,
      "n": "NameIdentifier",
      "d": 524357,
      "h": 133144510533,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(133144510533),
//--TRIMMABLE-BOUNDARY-START(137439477829),
    {
      "t": 1310721,
      "n": "OtherPhone",
      "d": 524357,
      "h": 137439477829,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(137439477829),
//--TRIMMABLE-BOUNDARY-START(141734445125),
    {
      "t": 1310721,
      "n": "PostalCode",
      "d": 524357,
      "h": 141734445125,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(141734445125),
//--TRIMMABLE-BOUNDARY-START(158914314309),
    {
      "t": 1310721,
      "n": "Rsa",
      "d": 524357,
      "h": 158914314309,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(158914314309),
//--TRIMMABLE-BOUNDARY-START(167504248901),
    {
      "t": 1310721,
      "n": "Sid",
      "d": 524357,
      "h": 167504248901,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(167504248901),
//--TRIMMABLE-BOUNDARY-START(171799216197),
    {
      "t": 1310721,
      "n": "Spn",
      "d": 524357,
      "h": 171799216197,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(171799216197),
//--TRIMMABLE-BOUNDARY-START(176094183493),
    {
      "t": 1310721,
      "n": "StateOrProvince",
      "d": 524357,
      "h": 176094183493,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(176094183493),
//--TRIMMABLE-BOUNDARY-START(180389150789),
    {
      "t": 1310721,
      "n": "StreetAddress",
      "d": 524357,
      "h": 180389150789,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(180389150789),
//--TRIMMABLE-BOUNDARY-START(184684118085),
    {
      "t": 1310721,
      "n": "Surname",
      "d": 524357,
      "h": 184684118085,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(184684118085),
//--TRIMMABLE-BOUNDARY-START(188979085381),
    {
      "t": 1310721,
      "n": "System",
      "d": 524357,
      "h": 188979085381,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(188979085381),
//--TRIMMABLE-BOUNDARY-START(193274052677),
    {
      "t": 1310721,
      "n": "Thumbprint",
      "d": 524357,
      "h": 193274052677,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(193274052677),
//--TRIMMABLE-BOUNDARY-START(197569019973),
    {
      "t": 1310721,
      "n": "Upn",
      "d": 524357,
      "h": 197569019973,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(197569019973),
//--TRIMMABLE-BOUNDARY-START(201863987269),
    {
      "t": 1310721,
      "n": "Uri",
      "d": 524357,
      "h": 201863987269,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(201863987269),
//--TRIMMABLE-BOUNDARY-START(214748889157),
    {
      "t": 1310721,
      "n": "Webpage",
      "d": 524357,
      "h": 214748889157,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(214748889157),
//--TRIMMABLE-BOUNDARY-START(244813660229),
    {
      "t": 1310721,
      "n": "X500DistinguishedName",
      "d": 524357,
      "h": 244813660229,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(244813660229),
//--TRIMMABLE-BOUNDARY-START(34360262725),
    {
      "t": 1310721,
      "n": "ClaimType2009Namespace",
      "d": 524357,
      "h": 34360262725,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(34360262725),
//--TRIMMABLE-BOUNDARY-START(4295491653),
    {
      "t": 1310721,
      "n": "Actor",
      "d": 524357,
      "h": 4295491653,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(4295491653)
  ],
  "h": 524357
}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `System.Security.Claims.ClaimTypes`; }
        });
        //--TRIMMABLE-BOUNDARY-END(524357)
        
        
        //--TRIMMABLE-BOUNDARY-START(131141)
        $asm.$cls("$ssc.System.Security.Claims.Claim", ($self) => class Claim extends $.$$.System.Object
        {
            //--TRIMMABLE-BOUNDARY-START(196677)
            static $_SerializationMask;
            static get SerializationMask()
            {
                let $cls = $.$ssc.System.Security.Claims.Claim;
                return $cls.$_SerializationMask ??= $asm.$nstr("$ssc.System.Security.Claims.Claim.SerializationMask", ($self) => class SerializationMask extends $.$$.System.Enum
                {
                    static None = 0;
                    static NameClaimType = 1;
                    static RoleClaimType = 2;
                    static StringType = 4;
                    static Issuer = 8;
                    static OriginalIssuerEqualsIssuer = 16;
                    static OriginalIssuer = 32;
                    static HasProperties = 64;
                    static UserData = 128;
                    static $map;
                    static get Map()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(196677);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return this.$map ??= 
                        {
                            "None": 0n,
                            "NameClaimType": 1n,
                            "RoleClaimType": 2n,
                            "StringType": 4n,
                            "Issuer": 8n,
                            "OriginalIssuerEqualsIssuer": 16n,
                            "OriginalIssuer": 32n,
                            "HasProperties": 64n,
                            "UserData": 128n
                        };
                    }
                    static $h = 196677;
                    static $z = 4;
                    static $f = 0b110000011010001000;
                    static $k = 4;
                    static get $eut() { return $.$$.System.Int32; }
                    static $$md;
                    static get $md() { return this.$$md ??= {
  "b": 1048577,
  "u": 655361,
  "l": [
//--TRIMMABLE-BOUNDARY-START(21475033157),
    {
      "t": 196677,
      "n": "None",
      "d": 196677,
      "h": 21475033157,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(21475033157),
//--TRIMMABLE-BOUNDARY-START(17180065861),
    {
      "t": 196677,
      "n": "NameClaimType",
      "d": 196677,
      "h": 17180065861,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(17180065861),
//--TRIMMABLE-BOUNDARY-START(34359935045),
    {
      "t": 196677,
      "n": "RoleClaimType",
      "d": 196677,
      "h": 34359935045,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(34359935045),
//--TRIMMABLE-BOUNDARY-START(38654902341),
    {
      "t": 196677,
      "n": "StringType",
      "d": 196677,
      "h": 38654902341,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(38654902341),
//--TRIMMABLE-BOUNDARY-START(12885098565),
    {
      "t": 196677,
      "n": "Issuer",
      "d": 196677,
      "h": 12885098565,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(12885098565),
//--TRIMMABLE-BOUNDARY-START(30064967749),
    {
      "t": 196677,
      "n": "OriginalIssuerEqualsIssuer",
      "d": 196677,
      "h": 30064967749,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(30064967749),
//--TRIMMABLE-BOUNDARY-START(25770000453),
    {
      "t": 196677,
      "n": "OriginalIssuer",
      "d": 196677,
      "h": 25770000453,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(25770000453),
//--TRIMMABLE-BOUNDARY-START(8590131269),
    {
      "t": 196677,
      "n": "HasProperties",
      "d": 196677,
      "h": 8590131269,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(8590131269),
//--TRIMMABLE-BOUNDARY-START(42949869637),
    {
      "t": 196677,
      "n": "UserData",
      "d": 196677,
      "h": 42949869637,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(42949869637)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295163973),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 196677,
      "h": 4295163973,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295163973)
  ],
  "i": [90046465,96600065,90505217,90177537
  ],
  "d": 131141,
  "h": 196677
}; }
                    static get $b() { return $.$$.System.Enum; }
                    static $$i;
                    static get $i() { return this.$$i ??= [ $.$$.System.IComparable, $.$$.System.ISpanFormattable, $.$$.System.IFormattable, $.$$.System.IConvertible ]; }
                    static get $fullName() { return `System.Security.Claims.Claim.SerializationMask`; }
                }, $cls, ($v) => $cls.$_SerializationMask = $v);
            }
            //--TRIMMABLE-BOUNDARY-END(196677)
            
            //--TRIMMABLE-BOUNDARY-START(25769934917)
            /*byte[]?*/ _userSerializationData = null;
            //--TRIMMABLE-BOUNDARY-END(25769934917)
            
            //--TRIMMABLE-BOUNDARY-START(4295098437)
            /*string*/ _issuer = null;
            //--TRIMMABLE-BOUNDARY-END(4295098437)
            
            //--TRIMMABLE-BOUNDARY-START(8590065733)
            /*string*/ _originalIssuer = null;
            //--TRIMMABLE-BOUNDARY-END(8590065733)
            
            //--TRIMMABLE-BOUNDARY-START(12885033029)
            /*Dictionary<string, string>?*/ _properties = null;
            //--TRIMMABLE-BOUNDARY-END(12885033029)
            
            //--TRIMMABLE-BOUNDARY-START(17180000325)
            /*ClaimsIdentity?*/ _subject = null;
            //--TRIMMABLE-BOUNDARY-END(17180000325)
            
            //--TRIMMABLE-BOUNDARY-START(21474967621)
            /*string*/ _type = null;
            //--TRIMMABLE-BOUNDARY-END(21474967621)
            
            //--TRIMMABLE-BOUNDARY-START(30064902213)
            /*string*/ _value = null;
            //--TRIMMABLE-BOUNDARY-END(30064902213)
            
            //--TRIMMABLE-BOUNDARY-START(34359869509)
            /*string*/ _valueType = null;
            //--TRIMMABLE-BOUNDARY-END(34359869509)
            
            //--TRIMMABLE-BOUNDARY-START(47244771397)
            $ctor$2(/*BinaryReader*/ reader)
            {
                this.$ctor$1(reader, null);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(47244771397);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(47244771397)
            
            //--TRIMMABLE-BOUNDARY-START(42949804101)
            $ctor$1(/*BinaryReader*/ reader, /*ClaimsIdentity?*/ subject)
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(42949804101);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$$.System.ArgumentNullException.ThrowIfNull$2(reader, "reader");
                    this._subject = subject;
                    /*SerializationMask*/ let mask = $.$cast(reader.ReadInt32(), $.$ssc.System.Security.Claims.Claim.SerializationMask);
                    /*int*/ let numPropertiesRead = 1;
                    /*int*/ let numPropertiesToRead = reader.ReadInt32();
                    this._value = reader.ReadString();
                    if ((mask & 1/*SerializationMask.NameClaimType*/) === 1/*SerializationMask.NameClaimType*/)
                    {
                        this._type = "http://schemas.xmlsoap.org/ws/2005/05/identity/claims/name"/*ClaimsIdentity.DefaultNameClaimType*/;
                    }
                    else if ((mask & 2/*SerializationMask.RoleClaimType*/) === 2/*SerializationMask.RoleClaimType*/)
                    {
                        this._type = "http://schemas.microsoft.com/ws/2008/06/identity/claims/role"/*ClaimsIdentity.DefaultRoleClaimType*/;
                    }
                    else 
                    {
                        this._type = reader.ReadString();
                        numPropertiesRead++;
                    }
                    if ((mask & 4/*SerializationMask.StringType*/) === 4/*SerializationMask.StringType*/)
                    {
                        this._valueType = reader.ReadString();
                        numPropertiesRead++;
                    }
                    else 
                    {
                        this._valueType = "http://www.w3.org/2001/XMLSchema#string"/*ClaimValueTypes.String*/;
                    }
                    if ((mask & 8/*SerializationMask.Issuer*/) === 8/*SerializationMask.Issuer*/)
                    {
                        this._issuer = reader.ReadString();
                        numPropertiesRead++;
                    }
                    else 
                    {
                        this._issuer = "LOCAL AUTHORITY"/*ClaimsIdentity.DefaultIssuer*/;
                    }
                    if ((mask & 16/*SerializationMask.OriginalIssuerEqualsIssuer*/) === 16/*SerializationMask.OriginalIssuerEqualsIssuer*/)
                    {
                        this._originalIssuer = this._issuer;
                    }
                    else if ((mask & 32/*SerializationMask.OriginalIssuer*/) === 32/*SerializationMask.OriginalIssuer*/)
                    {
                        this._originalIssuer = reader.ReadString();
                        numPropertiesRead++;
                    }
                    else 
                    {
                        this._originalIssuer = "LOCAL AUTHORITY"/*ClaimsIdentity.DefaultIssuer*/;
                    }
                    if ((mask & 64/*SerializationMask.HasProperties*/) === 64/*SerializationMask.HasProperties*/)
                    {
                        /*int*/ let numProperties = reader.ReadInt32();
                        numPropertiesRead++;
                        for(/*int*/ let i = 0; i < numProperties; i++)
                        {
                            this.Properties.System$Collections$Generic$IDictionary$$$$Add(reader.ReadString(), reader.ReadString(), [$.$$.System.String, $.$$.System.String]);
                        }
                    }
                    if ((mask & 128/*SerializationMask.UserData*/) === 128/*SerializationMask.UserData*/)
                    {
                        /*int*/ let cb = reader.ReadInt32();
                        this._userSerializationData = reader.ReadBytes(cb);
                        numPropertiesRead++;
                    }
                    for(/*int*/ let i = numPropertiesRead; i < numPropertiesToRead; i++)
                    {
                        reader.ReadString();
                    }
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(42949804101)
            
            //--TRIMMABLE-BOUNDARY-START(73014575173)
            $ctor$8(/*string*/ type, /*string*/ value)
            {
                this.$ctor$4(type, value, "http://www.w3.org/2001/XMLSchema#string"/*ClaimValueTypes.String*/, "LOCAL AUTHORITY"/*ClaimsIdentity.DefaultIssuer*/, "LOCAL AUTHORITY"/*ClaimsIdentity.DefaultIssuer*/, null);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(73014575173);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(73014575173)
            
            //--TRIMMABLE-BOUNDARY-START(68719607877)
            $ctor$7(/*string*/ type, /*string*/ value, /*string?*/ valueType)
            {
                this.$ctor$4(type, value, valueType, "LOCAL AUTHORITY"/*ClaimsIdentity.DefaultIssuer*/, "LOCAL AUTHORITY"/*ClaimsIdentity.DefaultIssuer*/, null);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(68719607877);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(68719607877)
            
            //--TRIMMABLE-BOUNDARY-START(64424640581)
            $ctor$6(/*string*/ type, /*string*/ value, /*string?*/ valueType, /*string?*/ issuer)
            {
                this.$ctor$4(type, value, valueType, issuer, issuer, null);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(64424640581);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(64424640581)
            
            //--TRIMMABLE-BOUNDARY-START(60129673285)
            $ctor$5(/*string*/ type, /*string*/ value, /*string?*/ valueType, /*string?*/ issuer, /*string?*/ originalIssuer)
            {
                this.$ctor$4(type, value, valueType, issuer, originalIssuer, null);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(60129673285);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(60129673285)
            
            //--TRIMMABLE-BOUNDARY-START(55834705989)
            $ctor$4(/*string*/ type, /*string*/ value, /*string?*/ valueType, /*string?*/ issuer, /*string?*/ originalIssuer, /*ClaimsIdentity?*/ subject)
            {
                this.$ctor$3(type, value, valueType, issuer, originalIssuer, subject, null, null);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(55834705989);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(55834705989)
            
            //--TRIMMABLE-BOUNDARY-START(51539738693)
            $ctor$3(/*string*/ type, /*string*/ value, /*string?*/ valueType, /*string?*/ issuer, /*string?*/ originalIssuer, /*ClaimsIdentity?*/ subject, /*string?*/ propertyKey, /*string?*/ propertyValue)
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(51539738693);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$$.System.ArgumentNullException.ThrowIfNull$2(type, "type");
                    $.$$.System.ArgumentNullException.ThrowIfNull$2(value, "value");
                    this._type = type;
                    this._value = value;
                    this._valueType = $.$$.System.String.IsNullOrEmpty(valueType) ? "http://www.w3.org/2001/XMLSchema#string"/*ClaimValueTypes.String*/ : valueType;
                    this._issuer = $.$$.System.String.IsNullOrEmpty(issuer) ? "LOCAL AUTHORITY"/*ClaimsIdentity.DefaultIssuer*/ : issuer;
                    this._originalIssuer = $.$$.System.String.IsNullOrEmpty(originalIssuer) ? this._issuer : originalIssuer;
                    this._subject = subject;
                    if ($.$$.System.String.op_Inequality(propertyKey, null))
                    {
                        this._properties = new ($.$$.System.Collections.Generic.Dictionary$$$($.$$.System.String, $.$$.System.String))().$ctor$1();
                        this._properties.set_Item(propertyKey, propertyValue);
                    }
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(51539738693)
            
            //--TRIMMABLE-BOUNDARY-START(81604509765)
            $ctor$10(/*Claim*/ other)
            {
                this.$ctor$9(other, (other === null ? null : other._subject));
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(81604509765);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(81604509765)
            
            //--TRIMMABLE-BOUNDARY-START(77309542469)
            $ctor$9(/*Claim*/ other, /*ClaimsIdentity?*/ subject)
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(77309542469);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$$.System.ArgumentNullException.ThrowIfNull$2(other, "other");
                    this._issuer = other._issuer;
                    this._originalIssuer = other._originalIssuer;
                    this._subject = subject;
                    this._type = other._type;
                    this._value = other._value;
                    this._valueType = other._valueType;
                    if (other._properties !== null)
                    {
                        this._properties = new ($.$$.System.Collections.Generic.Dictionary$$$($.$$.System.String, $.$$.System.String))().$ctor$3(other._properties);
                    }
                    if (other._userSerializationData !== null)
                    {
                        this._userSerializationData = $.$as(other._userSerializationData.Clone(), $.$typeArray($.$$.System.Byte));
                    }
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(77309542469)
            
            //--TRIMMABLE-BOUNDARY-START(94489411653)
            /*byte[]? */ get CustomSerializationData()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(103079346245);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this._userSerializationData;
            }
            //--TRIMMABLE-BOUNDARY-END(94489411653)
            
            //--TRIMMABLE-BOUNDARY-START(167503855685)
            /*string */ get Issuer()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(111669280837);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this._issuer;
            }
            //--TRIMMABLE-BOUNDARY-END(167503855685)
            
            //--TRIMMABLE-BOUNDARY-START(171798822981)
            /*string */ get OriginalIssuer()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(120259215429);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this._originalIssuer;
            }
            //--TRIMMABLE-BOUNDARY-END(171798822981)
            
            //--TRIMMABLE-BOUNDARY-START(176093790277)
            /*IDictionary<string, string> */ get Properties()
            {
                return this._properties ??= new ($.$$.System.Collections.Generic.Dictionary$$$($.$$.System.String, $.$$.System.String))().$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(176093790277)
            
            //--TRIMMABLE-BOUNDARY-START(180388757573)
            /*ClaimsIdentity? */ get Subject()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(137439084613);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this._subject;
            }
            //--TRIMMABLE-BOUNDARY-END(180388757573)
            
            //--TRIMMABLE-BOUNDARY-START(188978692165)
            /*string */ get Type()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(146029019205);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this._type;
            }
            //--TRIMMABLE-BOUNDARY-END(188978692165)
            
            //--TRIMMABLE-BOUNDARY-START(193273659461)
            /*string */ get Value()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(154618953797);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this._value;
            }
            //--TRIMMABLE-BOUNDARY-END(193273659461)
            
            //--TRIMMABLE-BOUNDARY-START(197568626757)
            /*string */ get ValueType()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(163208888389);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this._valueType;
            }
            //--TRIMMABLE-BOUNDARY-END(197568626757)
            
            //--TRIMMABLE-BOUNDARY-START(85899477061)
            /*Claim */ Clone()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(85899477061);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Clone$1(null);
            }
            //--TRIMMABLE-BOUNDARY-END(85899477061)
            
            //--TRIMMABLE-BOUNDARY-START(90194444357)
            /*Claim */ Clone$1(/*ClaimsIdentity?*/ identity)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(90194444357);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return new $.$ssc.System.Security.Claims.Claim().$ctor$9(this, identity);
            }
            //--TRIMMABLE-BOUNDARY-END(90194444357)
            
            //--TRIMMABLE-BOUNDARY-START(206158561349)
            /*void */ WriteTo$1(/*BinaryWriter*/ writer)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(206158561349);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.WriteTo(writer, null);
            }
            //--TRIMMABLE-BOUNDARY-END(206158561349)
            
            //--TRIMMABLE-BOUNDARY-START(201863594053)
            /*void */ WriteTo(/*BinaryWriter*/ writer, /*byte[]?*/ userData)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(201863594053);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.ArgumentNullException.ThrowIfNull$2(writer, "writer");
                /*int*/ let numberOfPropertiesWritten = 1;
                /*SerializationMask*/ let mask = 0/*SerializationMask.None*/;
                if ($.$$.System.String.Equals$3(this._type, "http://schemas.xmlsoap.org/ws/2005/05/identity/claims/name"/*ClaimsIdentity.DefaultNameClaimType*/))
                {
                    mask |= 1/*SerializationMask.NameClaimType*/;
                }
                else if ($.$$.System.String.Equals$3(this._type, "http://schemas.microsoft.com/ws/2008/06/identity/claims/role"/*ClaimsIdentity.DefaultRoleClaimType*/))
                {
                    mask |= 2/*SerializationMask.RoleClaimType*/;
                }
                else 
                {
                    numberOfPropertiesWritten++;
                }
                if (!$.$$.System.String.Equals$2(this._valueType, "http://www.w3.org/2001/XMLSchema#string"/*ClaimValueTypes.String*/, 4/*StringComparison.Ordinal*/))
                {
                    numberOfPropertiesWritten++;
                    mask |= 4/*SerializationMask.StringType*/;
                }
                if (!$.$$.System.String.Equals$2(this._issuer, "LOCAL AUTHORITY"/*ClaimsIdentity.DefaultIssuer*/, 4/*StringComparison.Ordinal*/))
                {
                    numberOfPropertiesWritten++;
                    mask |= 8/*SerializationMask.Issuer*/;
                }
                if ($.$$.System.String.Equals$2(this._originalIssuer, this._issuer, 4/*StringComparison.Ordinal*/))
                {
                    mask |= 16/*SerializationMask.OriginalIssuerEqualsIssuer*/;
                }
                else if (!$.$$.System.String.Equals$3(this._originalIssuer, "LOCAL AUTHORITY"/*ClaimsIdentity.DefaultIssuer*/))
                {
                    numberOfPropertiesWritten++;
                    mask |= 32/*SerializationMask.OriginalIssuer*/;
                }
                if (this._properties !== null && this._properties.Count > 0)
                {
                    numberOfPropertiesWritten++;
                    mask |= 64/*SerializationMask.HasProperties*/;
                }
                if (userData !== null && userData.length > 0)
                {
                    numberOfPropertiesWritten++;
                    mask |= 128/*SerializationMask.UserData*/;
                }
                writer.Write$11(mask);
                writer.Write$11(numberOfPropertiesWritten);
                writer.Write$17(this._value);
                if (((mask & 1/*SerializationMask.NameClaimType*/) !== 1/*SerializationMask.NameClaimType*/) && ((mask & 2/*SerializationMask.RoleClaimType*/) !== 2/*SerializationMask.RoleClaimType*/))
                {
                    writer.Write$17(this._type);
                }
                if ((mask & 4/*SerializationMask.StringType*/) === 4/*SerializationMask.StringType*/)
                {
                    writer.Write$17(this._valueType);
                }
                if ((mask & 8/*SerializationMask.Issuer*/) === 8/*SerializationMask.Issuer*/)
                {
                    writer.Write$17(this._issuer);
                }
                if ((mask & 32/*SerializationMask.OriginalIssuer*/) === 32/*SerializationMask.OriginalIssuer*/)
                {
                    writer.Write$17(this._originalIssuer);
                }
                if ((mask & 64/*SerializationMask.HasProperties*/) === 64/*SerializationMask.HasProperties*/)
                {
                    writer.Write$11(this._properties.Count);
                    var $en3 = this._properties.GetEnumerator();
                    while ($en3.MoveNext())
                    {
                        var kvp = $en3.Current;
                        {
                            writer.Write$17(kvp.Key);
                            writer.Write$17(kvp.Value);
                        }
                    }
                }
                if ((mask & 128/*SerializationMask.UserData*/) === 128/*SerializationMask.UserData*/)
                {
                    writer.Write$11(userData.length);
                    writer.Write$3(userData);
                }
                writer.Flush();
            }
            //--TRIMMABLE-BOUNDARY-END(201863594053)
            
            //--TRIMMABLE-BOUNDARY-START(184683724869)
            static/*conventional*/ /*string */ ToString()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(184683724869);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this._type + ": " + this._value;
            }
            //Static convention instance redirect
            /*string */ ToString() { return $.$ssc.System.Security.Claims.Claim.ToString.apply(this, arguments); }
            //--TRIMMABLE-BOUNDARY-END(184683724869)
            
            static $h = 131141;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 131073,
  "p": [
//--TRIMMABLE-BOUNDARY-START(94489411653),
    {
      "p": $.$typeArray($.$$.System.Byte).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 103079346245,
        "f": 50331780
      },
      "n": "CustomSerializationData",
      "d": 131141,
      "h": 94489411653,
      "f": 2097284
    },
//--TRIMMABLE-BOUNDARY-END(94489411653),
//--TRIMMABLE-BOUNDARY-START(167503855685),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 111669280837,
        "f": 50331649
      },
      "n": "Issuer",
      "d": 131141,
      "h": 167503855685,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(167503855685),
//--TRIMMABLE-BOUNDARY-START(171798822981),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 120259215429,
        "f": 50331649
      },
      "n": "OriginalIssuer",
      "d": 131141,
      "h": 171798822981,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(171798822981),
//--TRIMMABLE-BOUNDARY-START(176093790277),
    {
      "p": $.$$.System.Collections.Generic.IDictionary$$$($.$$.System.String, $.$$.System.String).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 128849150021,
        "f": 50331649
      },
      "n": "Properties",
      "d": 131141,
      "h": 176093790277,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(176093790277),
//--TRIMMABLE-BOUNDARY-START(180388757573),
    {
      "p": 262213,
      "g": {
        "r": 0,
        "d": 0,
        "h": 137439084613,
        "f": 50331649
      },
      "n": "Subject",
      "d": 131141,
      "h": 180388757573,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(180388757573),
//--TRIMMABLE-BOUNDARY-START(188978692165),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 146029019205,
        "f": 50331649
      },
      "n": "Type",
      "d": 131141,
      "h": 188978692165,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(188978692165),
//--TRIMMABLE-BOUNDARY-START(193273659461),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 154618953797,
        "f": 50331649
      },
      "n": "Value",
      "d": 131141,
      "h": 193273659461,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(193273659461),
//--TRIMMABLE-BOUNDARY-START(197568626757),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 163208888389,
        "f": 50331649
      },
      "n": "ValueType",
      "d": 131141,
      "h": 197568626757,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(197568626757)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(85899477061),
    {
      "r": 131141,
      "n": "Clone",
      "d": 131141,
      "h": 85899477061,
      "f": 16777345
    },
//--TRIMMABLE-BOUNDARY-END(85899477061),
//--TRIMMABLE-BOUNDARY-START(90194444357),
    {
      "r": 131141,
      "p": [
        {
          "n": "identity",
          "p": 262213
        }
      ],
      "n": "Clone",
      "o": "@$1",
      "d": 131141,
      "h": 90194444357,
      "f": 16777345
    },
//--TRIMMABLE-BOUNDARY-END(90194444357),
//--TRIMMABLE-BOUNDARY-START(206158561349),
    {
      "r": 65537,
      "p": [
        {
          "n": "writer",
          "p": 91291649
        }
      ],
      "n": "WriteTo",
      "o": "@$1",
      "d": 131141,
      "h": 206158561349,
      "f": 16777345
    },
//--TRIMMABLE-BOUNDARY-END(206158561349),
//--TRIMMABLE-BOUNDARY-START(201863594053),
    {
      "r": 65537,
      "p": [
        {
          "n": "writer",
          "p": 91291649
        },
        {
          "n": "userData",
          "p": $.$typeArray($.$$.System.Byte).$h
        }
      ],
      "n": "WriteTo",
      "d": 131141,
      "h": 201863594053,
      "f": 16777348
    },
//--TRIMMABLE-BOUNDARY-END(201863594053),
//--TRIMMABLE-BOUNDARY-START(184683724869),
    {
      "r": 1310721,
      "n": "ToString",
      "d": 131141,
      "h": 184683724869,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(184683724869)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(25769934917),
    {
      "t": $.$typeArray($.$$.System.Byte).$h,
      "n": "_userSerializationData",
      "d": 131141,
      "h": 25769934917,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(25769934917),
//--TRIMMABLE-BOUNDARY-START(4295098437),
    {
      "t": 1310721,
      "n": "_issuer",
      "d": 131141,
      "h": 4295098437,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(4295098437),
//--TRIMMABLE-BOUNDARY-START(8590065733),
    {
      "t": 1310721,
      "n": "_originalIssuer",
      "d": 131141,
      "h": 8590065733,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(8590065733),
//--TRIMMABLE-BOUNDARY-START(12885033029),
    {
      "t": $.$$.System.Collections.Generic.Dictionary$$$($.$$.System.String, $.$$.System.String).$h,
      "n": "_properties",
      "d": 131141,
      "h": 12885033029,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(12885033029),
//--TRIMMABLE-BOUNDARY-START(17180000325),
    {
      "t": 262213,
      "n": "_subject",
      "d": 131141,
      "h": 17180000325,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(17180000325),
//--TRIMMABLE-BOUNDARY-START(21474967621),
    {
      "t": 1310721,
      "n": "_type",
      "d": 131141,
      "h": 21474967621,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(21474967621),
//--TRIMMABLE-BOUNDARY-START(30064902213),
    {
      "t": 1310721,
      "n": "_value",
      "d": 131141,
      "h": 30064902213,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(30064902213),
//--TRIMMABLE-BOUNDARY-START(34359869509),
    {
      "t": 1310721,
      "n": "_valueType",
      "d": 131141,
      "h": 34359869509,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(34359869509)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(47244771397),
    {
      "p": [
        {
          "n": "reader",
          "p": 91226113
        }
      ],
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 131141,
      "h": 47244771397,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(47244771397),
//--TRIMMABLE-BOUNDARY-START(42949804101),
    {
      "p": [
        {
          "n": "reader",
          "p": 91226113
        },
        {
          "n": "subject",
          "p": 262213
        }
      ],
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 131141,
      "h": 42949804101,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(42949804101),
//--TRIMMABLE-BOUNDARY-START(73014575173),
    {
      "p": [
        {
          "n": "type",
          "p": 1310721
        },
        {
          "n": "value",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$8",
      "d": 131141,
      "h": 73014575173,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(73014575173),
//--TRIMMABLE-BOUNDARY-START(68719607877),
    {
      "p": [
        {
          "n": "type",
          "p": 1310721
        },
        {
          "n": "value",
          "p": 1310721
        },
        {
          "n": "valueType",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$7",
      "d": 131141,
      "h": 68719607877,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(68719607877),
//--TRIMMABLE-BOUNDARY-START(64424640581),
    {
      "p": [
        {
          "n": "type",
          "p": 1310721
        },
        {
          "n": "value",
          "p": 1310721
        },
        {
          "n": "valueType",
          "p": 1310721
        },
        {
          "n": "issuer",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$6",
      "d": 131141,
      "h": 64424640581,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(64424640581),
//--TRIMMABLE-BOUNDARY-START(60129673285),
    {
      "p": [
        {
          "n": "type",
          "p": 1310721
        },
        {
          "n": "value",
          "p": 1310721
        },
        {
          "n": "valueType",
          "p": 1310721
        },
        {
          "n": "issuer",
          "p": 1310721
        },
        {
          "n": "originalIssuer",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 131141,
      "h": 60129673285,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(60129673285),
//--TRIMMABLE-BOUNDARY-START(55834705989),
    {
      "p": [
        {
          "n": "type",
          "p": 1310721
        },
        {
          "n": "value",
          "p": 1310721
        },
        {
          "n": "valueType",
          "p": 1310721
        },
        {
          "n": "issuer",
          "p": 1310721
        },
        {
          "n": "originalIssuer",
          "p": 1310721
        },
        {
          "n": "subject",
          "p": 262213
        }
      ],
      "n": ".ctor",
      "o": "$ctor$4",
      "d": 131141,
      "h": 55834705989,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(55834705989),
//--TRIMMABLE-BOUNDARY-START(51539738693),
    {
      "p": [
        {
          "n": "type",
          "p": 1310721
        },
        {
          "n": "value",
          "p": 1310721
        },
        {
          "n": "valueType",
          "p": 1310721
        },
        {
          "n": "issuer",
          "p": 1310721
        },
        {
          "n": "originalIssuer",
          "p": 1310721
        },
        {
          "n": "subject",
          "p": 262213
        },
        {
          "n": "propertyKey",
          "p": 1310721
        },
        {
          "n": "propertyValue",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 131141,
      "h": 51539738693,
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(51539738693),
//--TRIMMABLE-BOUNDARY-START(81604509765),
    {
      "p": [
        {
          "n": "other",
          "p": 131141
        }
      ],
      "n": ".ctor",
      "o": "$ctor$10",
      "d": 131141,
      "h": 81604509765,
      "f": 16777220
    },
//--TRIMMABLE-BOUNDARY-END(81604509765),
//--TRIMMABLE-BOUNDARY-START(77309542469),
    {
      "p": [
        {
          "n": "other",
          "p": 131141
        },
        {
          "n": "subject",
          "p": 262213
        }
      ],
      "n": ".ctor",
      "o": "$ctor$9",
      "d": 131141,
      "h": 77309542469,
      "f": 16777220
    },
//--TRIMMABLE-BOUNDARY-END(77309542469)
  ],
  "j": [196677
  ],
  "h": 131141
}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `System.Security.Claims.Claim`; }
        });
        //--TRIMMABLE-BOUNDARY-END(131141)
        
        
        //--TRIMMABLE-BOUNDARY-START(262213)
        $asm.$cls("$ssc.System.Security.Claims.ClaimsIdentity", ($self) => class ClaimsIdentity extends $.$$.System.Object
        {
            //--TRIMMABLE-BOUNDARY-START(327749)
            static $_SerializationMask;
            static get SerializationMask()
            {
                let $cls = $.$ssc.System.Security.Claims.ClaimsIdentity;
                return $cls.$_SerializationMask ??= $asm.$nstr("$ssc.System.Security.Claims.ClaimsIdentity.SerializationMask", ($self) => class SerializationMask extends $.$$.System.Enum
                {
                    static None = 0;
                    static AuthenticationType = 1;
                    static BootstrapConext = 2;
                    static NameClaimType = 4;
                    static RoleClaimType = 8;
                    static HasClaims = 16;
                    static HasLabel = 32;
                    static Actor = 64;
                    static UserData = 128;
                    static $map;
                    static get Map()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(327749);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return this.$map ??= 
                        {
                            "None": 0n,
                            "AuthenticationType": 1n,
                            "BootstrapConext": 2n,
                            "NameClaimType": 4n,
                            "RoleClaimType": 8n,
                            "HasClaims": 16n,
                            "HasLabel": 32n,
                            "Actor": 64n,
                            "UserData": 128n
                        };
                    }
                    static $h = 327749;
                    static $z = 4;
                    static $f = 0b110000011010001000;
                    static $k = 4;
                    static get $eut() { return $.$$.System.Int32; }
                    static $$md;
                    static get $md() { return this.$$md ??= {
  "b": 1048577,
  "u": 655361,
  "l": [
//--TRIMMABLE-BOUNDARY-START(34360066117),
    {
      "t": 327749,
      "n": "None",
      "d": 327749,
      "h": 34360066117,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(34360066117),
//--TRIMMABLE-BOUNDARY-START(12885229637),
    {
      "t": 327749,
      "n": "AuthenticationType",
      "d": 327749,
      "h": 12885229637,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(12885229637),
//--TRIMMABLE-BOUNDARY-START(17180196933),
    {
      "t": 327749,
      "n": "BootstrapConext",
      "d": 327749,
      "h": 17180196933,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(17180196933),
//--TRIMMABLE-BOUNDARY-START(30065098821),
    {
      "t": 327749,
      "n": "NameClaimType",
      "d": 327749,
      "h": 30065098821,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(30065098821),
//--TRIMMABLE-BOUNDARY-START(38655033413),
    {
      "t": 327749,
      "n": "RoleClaimType",
      "d": 327749,
      "h": 38655033413,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(38655033413),
//--TRIMMABLE-BOUNDARY-START(21475164229),
    {
      "t": 327749,
      "n": "HasClaims",
      "d": 327749,
      "h": 21475164229,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(21475164229),
//--TRIMMABLE-BOUNDARY-START(25770131525),
    {
      "t": 327749,
      "n": "HasLabel",
      "d": 327749,
      "h": 25770131525,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(25770131525),
//--TRIMMABLE-BOUNDARY-START(8590262341),
    {
      "t": 327749,
      "n": "Actor",
      "d": 327749,
      "h": 8590262341,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(8590262341),
//--TRIMMABLE-BOUNDARY-START(42950000709),
    {
      "t": 327749,
      "n": "UserData",
      "d": 327749,
      "h": 42950000709,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(42950000709)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295295045),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 327749,
      "h": 4295295045,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295295045)
  ],
  "i": [90046465,96600065,90505217,90177537
  ],
  "d": 262213,
  "h": 327749
}; }
                    static get $b() { return $.$$.System.Enum; }
                    static $$i;
                    static get $i() { return this.$$i ??= [ $.$$.System.IComparable, $.$$.System.ISpanFormattable, $.$$.System.IFormattable, $.$$.System.IConvertible ]; }
                    static get $fullName() { return `System.Security.Claims.ClaimsIdentity.SerializationMask`; }
                }, $cls, ($v) => $cls.$_SerializationMask = $v);
            }
            //--TRIMMABLE-BOUNDARY-END(327749)
            
            //--TRIMMABLE-BOUNDARY-START(42949935173)
            /*byte[]?*/ _userSerializationData = null;
            //--TRIMMABLE-BOUNDARY-END(42949935173)
            
            //--TRIMMABLE-BOUNDARY-START(4295229509)
            /*ClaimsIdentity?*/ _actor = null;
            //--TRIMMABLE-BOUNDARY-END(4295229509)
            
            //--TRIMMABLE-BOUNDARY-START(8590196805)
            /*string?*/ _authenticationType = null;
            //--TRIMMABLE-BOUNDARY-END(8590196805)
            
            //--TRIMMABLE-BOUNDARY-START(12885164101)
            /*object?*/ _bootstrapContext = null;
            //--TRIMMABLE-BOUNDARY-END(12885164101)
            
            //--TRIMMABLE-BOUNDARY-START(17180131397)
            /*List<List<Claim>>?*/ _externalClaims = null;
            //--TRIMMABLE-BOUNDARY-END(17180131397)
            
            //--TRIMMABLE-BOUNDARY-START(25770065989)
            /*string?*/ _label = null;
            //--TRIMMABLE-BOUNDARY-END(25770065989)
            
            //--TRIMMABLE-BOUNDARY-START(21475098693)
            /*List<Claim>*/ _instanceClaims = null;
            //--TRIMMABLE-BOUNDARY-END(21475098693)
            
            //--TRIMMABLE-BOUNDARY-START(30065033285)
            /*string*/ _nameClaimType = null;
            //--TRIMMABLE-BOUNDARY-END(30065033285)
            
            //--TRIMMABLE-BOUNDARY-START(34360000581)
            /*string*/ _roleClaimType = null;
            //--TRIMMABLE-BOUNDARY-END(34360000581)
            
            //--TRIMMABLE-BOUNDARY-START(38654967877)
            /*StringComparison*/ _stringComparison = 5;
            //--TRIMMABLE-BOUNDARY-END(38654967877)
            
            //--TRIMMABLE-BOUNDARY-START(167503986757)
            /*string*/ static DefaultIssuer = null;
            //--TRIMMABLE-BOUNDARY-END(167503986757)
            
            //--TRIMMABLE-BOUNDARY-START(171798954053)
            /*string*/ static DefaultNameClaimType = null;
            //--TRIMMABLE-BOUNDARY-END(171798954053)
            
            //--TRIMMABLE-BOUNDARY-START(176093921349)
            /*string*/ static DefaultRoleClaimType = null;
            //--TRIMMABLE-BOUNDARY-END(176093921349)
            
            //--TRIMMABLE-BOUNDARY-START(51539869765)
            $ctor$1()
            {
                this.$ctor$10(null, null, null, null, null);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(51539869765);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(51539869765)
            
            //--TRIMMABLE-BOUNDARY-START(98784510021)
            $ctor$12(/*IIdentity?*/ identity)
            {
                this.$ctor$10(identity, null, null, null, null);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(98784510021);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(98784510021)
            
            //--TRIMMABLE-BOUNDARY-START(64424771653)
            $ctor$4(/*IEnumerable<Claim>?*/ claims)
            {
                this.$ctor$10(null, claims, null, null, null);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(64424771653);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(64424771653)
            
            //--TRIMMABLE-BOUNDARY-START(107374444613)
            $ctor$14(/*string?*/ authenticationType)
            {
                this.$ctor$10(null, null, authenticationType, null, null);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(107374444613);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(107374444613)
            
            //--TRIMMABLE-BOUNDARY-START(60129804357)
            $ctor$3(/*IEnumerable<Claim>?*/ claims, /*string?*/ authenticationType)
            {
                this.$ctor$10(null, claims, authenticationType, null, null);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(60129804357);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(60129804357)
            
            //--TRIMMABLE-BOUNDARY-START(94489542725)
            $ctor$11(/*IIdentity?*/ identity, /*IEnumerable<Claim>?*/ claims)
            {
                this.$ctor$10(identity, claims, null, null, null);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(94489542725);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(94489542725)
            
            //--TRIMMABLE-BOUNDARY-START(103079477317)
            $ctor$13(/*string?*/ authenticationType, /*string?*/ nameType, /*string?*/ roleType)
            {
                this.$ctor$10(null, null, authenticationType, nameType, roleType);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(103079477317);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(103079477317)
            
            //--TRIMMABLE-BOUNDARY-START(55834837061)
            $ctor$2(/*IEnumerable<Claim>?*/ claims, /*string?*/ authenticationType, /*string?*/ nameType, /*string?*/ roleType)
            {
                this.$ctor$10(null, claims, authenticationType, nameType, roleType);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(55834837061);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(55834837061)
            
            //--TRIMMABLE-BOUNDARY-START(90194575429)
            $ctor$10(/*IIdentity?*/ identity, /*IEnumerable<Claim>?*/ claims, /*string?*/ authenticationType, /*string?*/ nameType, /*string?*/ roleType)
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(90194575429);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    /*ClaimsIdentity?*/ let claimsIdentity = $.$as(identity, $.$ssc.System.Security.Claims.ClaimsIdentity);
                    this._authenticationType = (identity !== null && $.$$.System.String.IsNullOrEmpty(authenticationType)) ? identity.System$Security$Principal$IIdentity$AuthenticationType : authenticationType;
                    this._nameClaimType = !$.$$.System.String.IsNullOrEmpty(nameType) ? nameType : (claimsIdentity !== null ? claimsIdentity._nameClaimType : "http://schemas.xmlsoap.org/ws/2005/05/identity/claims/name"/*DefaultNameClaimType*/);
                    this._roleClaimType = !$.$$.System.String.IsNullOrEmpty(roleType) ? roleType : (claimsIdentity !== null ? claimsIdentity._roleClaimType : "http://schemas.microsoft.com/ws/2008/06/identity/claims/role"/*DefaultRoleClaimType*/);
                    if (claimsIdentity !== null)
                    {
                        this._label = claimsIdentity._label;
                        this._bootstrapContext = claimsIdentity._bootstrapContext;
                        if (claimsIdentity.Actor !== null)
                        {
                            if (!this.IsCircular(claimsIdentity.Actor))
                            {
                                this._actor = claimsIdentity.Actor;
                            }
                            else 
                            {
                                throw new $.$$.System.InvalidOperationException().$ctor$12($.$ssc.System.SR.InvalidOperationException_ActorGraphCircular);
                            }
                        }
                        this.SafeAddClaims(claimsIdentity._instanceClaims);
                    }
                    else 
                    {
                        if (identity !== null && !$.$$.System.String.IsNullOrEmpty(identity.System$Security$Principal$IIdentity$Name))
                        {
                            this.SafeAddClaim(new $.$ssc.System.Security.Claims.Claim().$ctor$4(this._nameClaimType, identity.System$Security$Principal$IIdentity$Name, "http://www.w3.org/2001/XMLSchema#string"/*ClaimValueTypes.String*/, "LOCAL AUTHORITY"/*DefaultIssuer*/, "LOCAL AUTHORITY"/*DefaultIssuer*/, this));
                        }
                    }
                    if (claims !== null)
                    {
                        this.SafeAddClaims(claims);
                    }
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(90194575429)
            
            //--TRIMMABLE-BOUNDARY-START(73014706245)
            $ctor$6(/*BinaryReader*/ reader)
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(73014706245);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$$.System.ArgumentNullException.ThrowIfNull$2(reader, "reader");
                    this.Initialize(reader);
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(73014706245)
            
            //--TRIMMABLE-BOUNDARY-START(68719738949)
            $ctor$5(/*BinaryReader*/ reader, /*StringComparison*/ stringComparison)
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(68719738949);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$$.System.ArgumentNullException.ThrowIfNull$2(reader, "reader");
                    $.$ssc.System.Security.Claims.ClaimsIdentity.ValidateStringComparison(stringComparison);
                    this._stringComparison = stringComparison;
                    this.Initialize(reader);
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(68719738949)
            
            //--TRIMMABLE-BOUNDARY-START(115964379205)
            $ctor$16(/*ClaimsIdentity*/ other)
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(115964379205);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$$.System.ArgumentNullException.ThrowIfNull$2(other, "other");
                    this.Initialize$1(other);
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(115964379205)
            
            //--TRIMMABLE-BOUNDARY-START(111669411909)
            $ctor$15(/*ClaimsIdentity*/ other, /*StringComparison*/ stringComparison)
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(111669411909);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$$.System.ArgumentNullException.ThrowIfNull$2(other, "other");
                    $.$ssc.System.Security.Claims.ClaimsIdentity.ValidateStringComparison(stringComparison);
                    this._stringComparison = stringComparison;
                    this.Initialize$1(other);
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(111669411909)
            
            //--TRIMMABLE-BOUNDARY-START(85899608133)
            $ctor$9(/*IIdentity?*/ identity, /*IEnumerable<Claim>?*/ claims, /*string?*/ authenticationType, /*string?*/ nameType, /*string?*/ roleType, /*StringComparison*/ stringComparison)
            {
                this.$ctor$10(identity, claims, authenticationType, nameType, roleType);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(85899608133);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$ssc.System.Security.Claims.ClaimsIdentity.ValidateStringComparison(stringComparison);
                    this._stringComparison = stringComparison;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(85899608133)
            
            //--TRIMMABLE-BOUNDARY-START(77309673541)
            $ctor$7(/*SerializationInfo*/ info, /*StreamingContext*/ context)
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(77309673541);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(77309673541)
            
            //--TRIMMABLE-BOUNDARY-START(81604640837)
            $ctor$8(/*SerializationInfo*/ info)
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(81604640837);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(81604640837)
            
            //--TRIMMABLE-BOUNDARY-START(133144248389)
            /*string? */ get AuthenticationType()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(214748627013);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this._authenticationType;
            }
            //--TRIMMABLE-BOUNDARY-END(133144248389)
            
            //--TRIMMABLE-BOUNDARY-START(317827842117)
            /*bool */ get IsAuthenticated()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(257698299973);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return !$.$$.System.String.IsNullOrEmpty(this._authenticationType);
            }
            //--TRIMMABLE-BOUNDARY-END(317827842117)
            
            //--TRIMMABLE-BOUNDARY-START(120259346501)
            /*ClaimsIdentity? */ get Actor()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(206158692421);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this._actor;
            }
            /*ClaimsIdentity? */ set Actor(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(360777515077);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (value !== null)
                {
                    if (this.IsCircular(value))
                    {
                        throw new $.$$.System.InvalidOperationException().$ctor$12($.$ssc.System.SR.InvalidOperationException_ActorGraphCircular);
                    }
                }
                this._actor = value;
            }
            //--TRIMMABLE-BOUNDARY-END(120259346501)
            
            //--TRIMMABLE-BOUNDARY-START(137439215685)
            /*object? */ get BootstrapContext()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(223338561605);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this._bootstrapContext;
            }
            /*object? */ set BootstrapContext(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(369367449669);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this._bootstrapContext = value;
            }
            //--TRIMMABLE-BOUNDARY-END(137439215685)
            
            //--TRIMMABLE-BOUNDARY-START(141734182981)
            /*IEnumerable<Claim> */ get Claims()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(231928496197);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (this._externalClaims === null)
                {
                    return this._instanceClaims;
                }
                return this.CombinedClaimsIterator();
            }
            //--TRIMMABLE-BOUNDARY-END(141734182981)
            
            //--TRIMMABLE-BOUNDARY-START(150324117573)
            /*IEnumerable<Claim> */ CombinedClaimsIterator()
            {
                return new ($.$$.NetJs.YieldToIterator$$($.$$.System.Object))().$ctor$1(function*()
                {
                    for(/*int*/ let i = 0; i < this._instanceClaims.Count; i++)
                    {
                        yield this._instanceClaims.get_Item(i);
                    }
                    for(/*int*/ let j = 0; j < this._externalClaims.Count; j++)
                    {
                        if (this._externalClaims.get_Item(j) !== null)
                        {
                            var $en5 = this._externalClaims.get_Item(j).GetEnumerator();
                            while ($en5.MoveNext())
                            {
                                var claim = $en5.Current;
                                {
                                    yield claim;
                                }
                            }
                        }
                    }
                }.bind(this));
            }
            //--TRIMMABLE-BOUNDARY-END(150324117573)
            
            //--TRIMMABLE-BOUNDARY-START(158914052165)
            /*byte[]? */ get CustomSerializationData()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(240518430789);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this._userSerializationData;
            }
            //--TRIMMABLE-BOUNDARY-END(158914052165)
            
            //--TRIMMABLE-BOUNDARY-START(180388888645)
            /*List<List<Claim>> */ get ExternalClaims()
            {
                return this._externalClaims ??= new ($.$$.System.Collections.Generic.List$$($.$$.System.Collections.Generic.List$$($.$ssc.System.Security.Claims.Claim)))().$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(180388888645)
            
            //--TRIMMABLE-BOUNDARY-START(326417776709)
            /*string? */ get Label()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(266288234565);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this._label;
            }
            /*string? */ set Label(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(377957384261);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this._label = value;
            }
            //--TRIMMABLE-BOUNDARY-END(326417776709)
            
            //--TRIMMABLE-BOUNDARY-START(330712744005)
            /*string? */ get Name()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(274878169157);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*Claim?*/ let claim = this.FindFirst$1(this._nameClaimType);
                if (claim !== null)
                {
                    return claim.Value;
                }
                return null;
            }
            //--TRIMMABLE-BOUNDARY-END(330712744005)
            
            //--TRIMMABLE-BOUNDARY-START(335007711301)
            /*string */ get NameClaimType()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(283468103749);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this._nameClaimType;
            }
            //--TRIMMABLE-BOUNDARY-END(335007711301)
            
            //--TRIMMABLE-BOUNDARY-START(343597645893)
            /*string */ get RoleClaimType()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(292058038341);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this._roleClaimType;
            }
            //--TRIMMABLE-BOUNDARY-END(343597645893)
            
            //--TRIMMABLE-BOUNDARY-START(146029150277)
            /*ClaimsIdentity */ Clone()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(146029150277);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return new $.$ssc.System.Security.Claims.ClaimsIdentity().$ctor$15(this, this._stringComparison);
            }
            //--TRIMMABLE-BOUNDARY-END(146029150277)
            
            //--TRIMMABLE-BOUNDARY-START(124554313797)
            /*void */ AddClaim(/*Claim*/ claim)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(124554313797);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.ArgumentNullException.ThrowIfNull$2(claim, "claim");
                if ($.$$.System.Object.ReferenceEquals(claim.Subject, this))
                {
                    this._instanceClaims.Add(claim);
                }
                else 
                {
                    this._instanceClaims.Add(claim.Clone$1(this));
                }
            }
            //--TRIMMABLE-BOUNDARY-END(124554313797)
            
            //--TRIMMABLE-BOUNDARY-START(128849281093)
            /*void */ AddClaims(/*IEnumerable<Claim?>*/ claims)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(128849281093);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.ArgumentNullException.ThrowIfNull$2(claims, "claims");
                var $en2 = claims.System$Collections$Generic$IEnumerable$$$GetEnumerator();
                while ($en2.System$Collections$IEnumerator$MoveNext())
                {
                    var claim = $en2.System$Collections$Generic$IEnumerator$$$Current;
                    {
                        if (claim === null)
                        {
                            continue;
                        }
                        if ($.$$.System.Object.ReferenceEquals(claim.Subject, this))
                        {
                            this._instanceClaims.Add(claim);
                        }
                        else 
                        {
                            this._instanceClaims.Add(claim.Clone$1(this));
                        }
                    }
                }
            }
            //--TRIMMABLE-BOUNDARY-END(128849281093)
            
            //--TRIMMABLE-BOUNDARY-START(382252351557)
            /*bool */ TryRemoveClaim(/*Claim?*/ claim)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(382252351557);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (claim === null)
                {
                    return false;
                }
                /*bool*/ let removed = false;
                for(/*int*/ let i = 0; i < this._instanceClaims.Count; i++)
                {
                    if ($.$$.System.Object.ReferenceEquals(this._instanceClaims.get_Item(i), claim))
                    {
                        this._instanceClaims.RemoveAt(i);
                        removed = true;
                        break;
                    }
                }
                return removed;
            }
            //--TRIMMABLE-BOUNDARY-END(382252351557)
            
            //--TRIMMABLE-BOUNDARY-START(339302678597)
            /*void */ RemoveClaim(/*Claim?*/ claim)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(339302678597);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (!this.TryRemoveClaim(claim))
                {
                    throw new $.$$.System.InvalidOperationException().$ctor$12($.$ssc.System.SR.Format$6($.$ssc.System.SR.InvalidOperation_ClaimCannotBeRemoved, claim));
                }
            }
            //--TRIMMABLE-BOUNDARY-END(339302678597)
            
            //--TRIMMABLE-BOUNDARY-START(352187580485)
            /*void */ SafeAddClaims(/*IEnumerable<Claim?>*/ claims)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(352187580485);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                var $en2 = claims.System$Collections$Generic$IEnumerable$$$GetEnumerator();
                while ($en2.System$Collections$IEnumerator$MoveNext())
                {
                    var claim = $en2.System$Collections$Generic$IEnumerator$$$Current;
                    {
                        if (claim === null)
                        {
                            continue;
                        }
                        if ($.$$.System.Object.ReferenceEquals(claim.Subject, this))
                        {
                            this._instanceClaims.Add(claim);
                        }
                        else 
                        {
                            this._instanceClaims.Add(claim.Clone$1(this));
                        }
                    }
                }
            }
            //--TRIMMABLE-BOUNDARY-END(352187580485)
            
            //--TRIMMABLE-BOUNDARY-START(347892613189)
            /*void */ SafeAddClaim(/*Claim?*/ claim)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(347892613189);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (claim === null)
                {
                    return;
                }
                if ($.$$.System.Object.ReferenceEquals(claim.Subject, this))
                {
                    this._instanceClaims.Add(claim);
                }
                else 
                {
                    this._instanceClaims.Add(claim.Clone$1(this));
                }
            }
            //--TRIMMABLE-BOUNDARY-END(347892613189)
            
            //--TRIMMABLE-BOUNDARY-START(184683855941)
            /*IEnumerable<Claim> */ FindAll(/*Predicate<Claim>*/ match)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(184683855941);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.ArgumentNullException.ThrowIfNull$2(match, "match");
                return Core.call(this, match);
                /*IEnumerable<Claim>*/  function Core(/*Predicate<Claim>*/ match)
                {
                    return new ($.$$.NetJs.YieldToIterator$$($.$$.System.Object))().$ctor$1(function*()
                    {
                        var $en4 = this.Claims.System$Collections$Generic$IEnumerable$$$GetEnumerator();
                        while ($en4.System$Collections$IEnumerator$MoveNext())
                        {
                            var claim = $en4.System$Collections$Generic$IEnumerator$$$Current;
                            {
                                if (match.Invoke(claim))
                                {
                                    yield claim;
                                }
                            }
                        }
                    }.bind(this));
                }
            }
            //--TRIMMABLE-BOUNDARY-END(184683855941)
            
            //--TRIMMABLE-BOUNDARY-START(188978823237)
            /*IEnumerable<Claim> */ FindAll$1(/*string*/ type)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(188978823237);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.ArgumentNullException.ThrowIfNull$2(type, "type");
                return Core.call(this, type);
                /*IEnumerable<Claim>*/  function Core(/*string*/ type)
                {
                    return new ($.$$.NetJs.YieldToIterator$$($.$$.System.Object))().$ctor$1(function*()
                    {
                        var $en4 = this.Claims.System$Collections$Generic$IEnumerable$$$GetEnumerator();
                        while ($en4.System$Collections$IEnumerator$MoveNext())
                        {
                            var claim = $en4.System$Collections$Generic$IEnumerator$$$Current;
                            {
                                if (claim !== null)
                                {
                                    if ($.$$.System.String.Equals$2(claim.Type, type, this._stringComparison))
                                    {
                                        yield claim;
                                    }
                                }
                            }
                        }
                    }.bind(this));
                }
            }
            //--TRIMMABLE-BOUNDARY-END(188978823237)
            
            //--TRIMMABLE-BOUNDARY-START(193273790533)
            /*Claim? */ FindFirst(/*Predicate<Claim>*/ match)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(193273790533);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.ArgumentNullException.ThrowIfNull$2(match, "match");
                var $en2 = this.Claims.System$Collections$Generic$IEnumerable$$$GetEnumerator();
                while ($en2.System$Collections$IEnumerator$MoveNext())
                {
                    var claim = $en2.System$Collections$Generic$IEnumerator$$$Current;
                    {
                        if (match.Invoke(claim))
                        {
                            return claim;
                        }
                    }
                }
                return null;
            }
            //--TRIMMABLE-BOUNDARY-END(193273790533)
            
            //--TRIMMABLE-BOUNDARY-START(197568757829)
            /*Claim? */ FindFirst$1(/*string*/ type)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(197568757829);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.ArgumentNullException.ThrowIfNull$2(type, "type");
                var $en2 = this.Claims.System$Collections$Generic$IEnumerable$$$GetEnumerator();
                while ($en2.System$Collections$IEnumerator$MoveNext())
                {
                    var claim = $en2.System$Collections$Generic$IEnumerator$$$Current;
                    {
                        if (claim !== null)
                        {
                            if ($.$$.System.String.Equals$2(claim.Type, type, this._stringComparison))
                            {
                                return claim;
                            }
                        }
                    }
                }
                return null;
            }
            //--TRIMMABLE-BOUNDARY-END(197568757829)
            
            //--TRIMMABLE-BOUNDARY-START(300647972933)
            /*bool */ HasClaim(/*Predicate<Claim>*/ match)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(300647972933);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.ArgumentNullException.ThrowIfNull$2(match, "match");
                var $en2 = this.Claims.System$Collections$Generic$IEnumerable$$$GetEnumerator();
                while ($en2.System$Collections$IEnumerator$MoveNext())
                {
                    var claim = $en2.System$Collections$Generic$IEnumerator$$$Current;
                    {
                        if (match.Invoke(claim))
                        {
                            return true;
                        }
                    }
                }
                return false;
            }
            //--TRIMMABLE-BOUNDARY-END(300647972933)
            
            //--TRIMMABLE-BOUNDARY-START(304942940229)
            /*bool */ HasClaim$1(/*string*/ type, /*string*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(304942940229);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.ArgumentNullException.ThrowIfNull$2(type, "type");
                $.$$.System.ArgumentNullException.ThrowIfNull$2(value, "value");
                var $en2 = this.Claims.System$Collections$Generic$IEnumerable$$$GetEnumerator();
                while ($en2.System$Collections$IEnumerator$MoveNext())
                {
                    var claim = $en2.System$Collections$Generic$IEnumerator$$$Current;
                    {
                        if (claim !== null && $.$$.System.String.Equals$2(claim.Type, type, this._stringComparison) && $.$$.System.String.Equals$2(claim.Value, value, 4/*StringComparison.Ordinal*/))
                        {
                            return true;
                        }
                    }
                }
                return false;
            }
            //--TRIMMABLE-BOUNDARY-END(304942940229)
            
            //--TRIMMABLE-BOUNDARY-START(313532874821)
            /*void */ Initialize$1(/*ClaimsIdentity*/ other)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(313532874821);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (other._actor !== null)
                {
                    this._actor = other._actor.Clone();
                }
                this._authenticationType = other._authenticationType;
                this._bootstrapContext = other._bootstrapContext;
                this._label = other._label;
                this._nameClaimType = other._nameClaimType;
                this._roleClaimType = other._roleClaimType;
                if (other._userSerializationData !== null)
                {
                    this._userSerializationData = $.$as(other._userSerializationData.Clone(), $.$typeArray($.$$.System.Byte));
                }
                this.SafeAddClaims(other._instanceClaims);
            }
            //--TRIMMABLE-BOUNDARY-END(313532874821)
            
            //--TRIMMABLE-BOUNDARY-START(309237907525)
            /*void */ Initialize(/*BinaryReader*/ reader)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(309237907525);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.ArgumentNullException.ThrowIfNull$2(reader, "reader");
                /*SerializationMask*/ let mask = $.$cast(reader.ReadInt32(), $.$ssc.System.Security.Claims.ClaimsIdentity.SerializationMask);
                /*int*/ let numPropertiesRead = 0;
                /*int*/ let numPropertiesToRead = reader.ReadInt32();
                if ((mask & 1/*SerializationMask.AuthenticationType*/) === 1/*SerializationMask.AuthenticationType*/)
                {
                    this._authenticationType = reader.ReadString();
                    numPropertiesRead++;
                }
                if ((mask & 2/*SerializationMask.BootstrapConext*/) === 2/*SerializationMask.BootstrapConext*/)
                {
                    this._bootstrapContext = reader.ReadString();
                    numPropertiesRead++;
                }
                if ((mask & 4/*SerializationMask.NameClaimType*/) === 4/*SerializationMask.NameClaimType*/)
                {
                    this._nameClaimType = reader.ReadString();
                    numPropertiesRead++;
                }
                else 
                {
                    this._nameClaimType = "http://schemas.xmlsoap.org/ws/2005/05/identity/claims/name"/*ClaimsIdentity.DefaultNameClaimType*/;
                }
                if ((mask & 8/*SerializationMask.RoleClaimType*/) === 8/*SerializationMask.RoleClaimType*/)
                {
                    this._roleClaimType = reader.ReadString();
                    numPropertiesRead++;
                }
                else 
                {
                    this._roleClaimType = "http://schemas.microsoft.com/ws/2008/06/identity/claims/role"/*ClaimsIdentity.DefaultRoleClaimType*/;
                }
                if ((mask & 32/*SerializationMask.HasLabel*/) === 32/*SerializationMask.HasLabel*/)
                {
                    this._label = reader.ReadString();
                    numPropertiesRead++;
                }
                if ((mask & 16/*SerializationMask.HasClaims*/) === 16/*SerializationMask.HasClaims*/)
                {
                    /*int*/ let numberOfClaims = reader.ReadInt32();
                    for(/*int*/ let index = 0; index < numberOfClaims; index++)
                    {
                        this._instanceClaims.Add(this.CreateClaim(reader));
                    }
                    numPropertiesRead++;
                }
                if ((mask & 64/*SerializationMask.Actor*/) === 64/*SerializationMask.Actor*/)
                {
                    this._actor = new $.$ssc.System.Security.Claims.ClaimsIdentity().$ctor$6(reader);
                    numPropertiesRead++;
                }
                if ((mask & 128/*SerializationMask.UserData*/) === 128/*SerializationMask.UserData*/)
                {
                    /*int*/ let cb = reader.ReadInt32();
                    this._userSerializationData = reader.ReadBytes(cb);
                    numPropertiesRead++;
                }
                for(/*int*/ let i = numPropertiesRead; i < numPropertiesToRead; i++)
                {
                    reader.ReadString();
                }
            }
            //--TRIMMABLE-BOUNDARY-END(309237907525)
            
            //--TRIMMABLE-BOUNDARY-START(154619084869)
            /*Claim */ CreateClaim(/*BinaryReader*/ reader)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(154619084869);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.ArgumentNullException.ThrowIfNull$2(reader, "reader");
                return new $.$ssc.System.Security.Claims.Claim().$ctor$1(reader, this);
            }
            //--TRIMMABLE-BOUNDARY-END(154619084869)
            
            //--TRIMMABLE-BOUNDARY-START(395137253445)
            /*void */ WriteTo$1(/*BinaryWriter*/ writer)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(395137253445);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.WriteTo(writer, null);
            }
            //--TRIMMABLE-BOUNDARY-END(395137253445)
            
            //--TRIMMABLE-BOUNDARY-START(390842286149)
            /*void */ WriteTo(/*BinaryWriter*/ writer, /*byte[]?*/ userData)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(390842286149);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.ArgumentNullException.ThrowIfNull$2(writer, "writer");
                /*int*/ let numberOfPropertiesWritten = 0;
                /*var*/ let mask = 0/*SerializationMask.None*/;
                if ($.$$.System.String.op_Inequality(this._authenticationType, null))
                {
                    mask |= 1/*SerializationMask.AuthenticationType*/;
                    numberOfPropertiesWritten++;
                }
                if (this._bootstrapContext !== null)
                {
                    if ($.$is(this._bootstrapContext, $.$$.System.String))
                    {
                        mask |= 2/*SerializationMask.BootstrapConext*/;
                        numberOfPropertiesWritten++;
                    }
                }
                if (!$.$$.System.String.Equals$2(this._nameClaimType, "http://schemas.xmlsoap.org/ws/2005/05/identity/claims/name"/*ClaimsIdentity.DefaultNameClaimType*/, 4/*StringComparison.Ordinal*/))
                {
                    mask |= 4/*SerializationMask.NameClaimType*/;
                    numberOfPropertiesWritten++;
                }
                if (!$.$$.System.String.Equals$2(this._roleClaimType, "http://schemas.microsoft.com/ws/2008/06/identity/claims/role"/*ClaimsIdentity.DefaultRoleClaimType*/, 4/*StringComparison.Ordinal*/))
                {
                    mask |= 8/*SerializationMask.RoleClaimType*/;
                    numberOfPropertiesWritten++;
                }
                if (!$.$$.System.String.IsNullOrWhiteSpace(this._label))
                {
                    mask |= 32/*SerializationMask.HasLabel*/;
                    numberOfPropertiesWritten++;
                }
                if (this._instanceClaims.Count > 0)
                {
                    mask |= 16/*SerializationMask.HasClaims*/;
                    numberOfPropertiesWritten++;
                }
                if (this._actor !== null)
                {
                    mask |= 64/*SerializationMask.Actor*/;
                    numberOfPropertiesWritten++;
                }
                if (userData !== null && userData.length > 0)
                {
                    numberOfPropertiesWritten++;
                    mask |= 128/*SerializationMask.UserData*/;
                }
                writer.Write$11(mask);
                writer.Write$11(numberOfPropertiesWritten);
                if ((mask & 1/*SerializationMask.AuthenticationType*/) === 1/*SerializationMask.AuthenticationType*/)
                {
                    writer.Write$17(this._authenticationType);
                }
                if ((mask & 2/*SerializationMask.BootstrapConext*/) === 2/*SerializationMask.BootstrapConext*/)
                {
                    writer.Write$17($.$cast(this._bootstrapContext, $.$$.System.String));
                }
                if ((mask & 4/*SerializationMask.NameClaimType*/) === 4/*SerializationMask.NameClaimType*/)
                {
                    writer.Write$17(this._nameClaimType);
                }
                if ((mask & 8/*SerializationMask.RoleClaimType*/) === 8/*SerializationMask.RoleClaimType*/)
                {
                    writer.Write$17(this._roleClaimType);
                }
                if ((mask & 32/*SerializationMask.HasLabel*/) === 32/*SerializationMask.HasLabel*/)
                {
                    writer.Write$17(this._label);
                }
                if ((mask & 16/*SerializationMask.HasClaims*/) === 16/*SerializationMask.HasClaims*/)
                {
                    writer.Write$11(this._instanceClaims.Count);
                    var $en3 = this._instanceClaims.GetEnumerator();
                    while ($en3.MoveNext())
                    {
                        var claim = $en3.Current;
                        {
                            claim.WriteTo$1(writer);
                        }
                    }
                }
                if ((mask & 64/*SerializationMask.Actor*/) === 64/*SerializationMask.Actor*/)
                {
                    this._actor.WriteTo$1(writer);
                }
                if ((mask & 128/*SerializationMask.UserData*/) === 128/*SerializationMask.UserData*/)
                {
                    writer.Write$11(userData.length);
                    writer.Write$3(userData);
                }
                writer.Flush();
            }
            //--TRIMMABLE-BOUNDARY-END(390842286149)
            
            //--TRIMMABLE-BOUNDARY-START(322122809413)
            /*bool */ IsCircular(/*ClaimsIdentity*/ subject)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(322122809413);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$$.System.Object.ReferenceEquals(this, subject))
                {
                    return true;
                }
                /*ClaimsIdentity*/ let currSubject = subject;
                while(currSubject.Actor !== null)
                {
                    if ($.$$.System.Object.ReferenceEquals(this, currSubject.Actor))
                    {
                        return true;
                    }
                    currSubject = currSubject.Actor;
                }
                return false;
            }
            //--TRIMMABLE-BOUNDARY-END(322122809413)
            
            //--TRIMMABLE-BOUNDARY-START(296353005637)
            /*void */ GetObjectData(/*SerializationInfo*/ info, /*StreamingContext*/ context)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(296353005637);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(296353005637)
            
            //--TRIMMABLE-BOUNDARY-START(163209019461)
            /*string */ DebuggerToString()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(163209019461);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*int*/ let claimsCount = 0;
                var $en2 = this.Claims.System$Collections$Generic$IEnumerable$$$GetEnumerator();
                while ($en2.System$Collections$IEnumerator$MoveNext())
                {
                    var item = $en2.System$Collections$Generic$IEnumerator$$$Current;
                    {
                        claimsCount++;
                    }
                }
                /*string*/ let debugText = `IsAuthenticated = ${(this.IsAuthenticated ? "true" : "false")}`;
                if ($.$$.System.String.op_Inequality(this.Name, null))
                {
                    debugText += `, Name = ${this.Name}`;
                }
                if (claimsCount > 0)
                {
                    debugText += `, Claims = ${claimsCount}`;
                }
                return debugText;
            }
            //--TRIMMABLE-BOUNDARY-END(163209019461)
            
            //--TRIMMABLE-BOUNDARY-START(386547318853)
            static /*void */ ValidateStringComparison(/*StringComparison*/ stringComparison)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(386547318853);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                switch(stringComparison)
                {
                    case 4/*StringComparison.Ordinal*/:
                    case 5/*StringComparison.OrdinalIgnoreCase*/:
                    case 2/*StringComparison.InvariantCulture*/:
                    case 3/*StringComparison.InvariantCultureIgnoreCase*/:
                    break;
                    default:
                    throw new $.$$.System.ArgumentException().$ctor$13($.$ssc.System.SR.ArgumentException_StringComparisonCultureAware, "stringComparison");
                }
            }
            //--TRIMMABLE-BOUNDARY-END(386547318853)
            
            //--TRIMMABLE-BOUNDARY-START(30225924097)
            //Generated interface implemetation for System.Security.Principal.IIdentity.Name.get
            get System$Security$Principal$IIdentity$Name()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(38815858689);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Name;
            }
            //--TRIMMABLE-BOUNDARY-END(30225924097)
            
            //--TRIMMABLE-BOUNDARY-START(13046054913)
            //Generated interface implemetation for System.Security.Principal.IIdentity.AuthenticationType.get
            get System$Security$Principal$IIdentity$AuthenticationType()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4456120321);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.AuthenticationType;
            }
            //--TRIMMABLE-BOUNDARY-END(13046054913)
            
            //--TRIMMABLE-BOUNDARY-START(21635989505)
            //Generated interface implemetation for System.Security.Principal.IIdentity.IsAuthenticated.get
            get System$Security$Principal$IIdentity$IsAuthenticated()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(34520891393);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.IsAuthenticated;
            }
            //--TRIMMABLE-BOUNDARY-END(21635989505)
            
            //default member initializer
            constructor()
            {
                super();
                //--TRIMMABLE-BOUNDARY-START(21475098693)
                this._instanceClaims = new ($.$$.System.Collections.Generic.List$$($.$ssc.System.Security.Claims.Claim))().$ctor$1();
                //--TRIMMABLE-BOUNDARY-END(21475098693)
                
                //--TRIMMABLE-BOUNDARY-START(30065033285)
                this._nameClaimType = "http://schemas.xmlsoap.org/ws/2005/05/identity/claims/name";
                //--TRIMMABLE-BOUNDARY-END(30065033285)
                
                //--TRIMMABLE-BOUNDARY-START(34360000581)
                this._roleClaimType = "http://schemas.microsoft.com/ws/2008/06/identity/claims/role";
                //--TRIMMABLE-BOUNDARY-END(34360000581)
                
            }
            //--TRIMMABLE-BOUNDARY-START(SINIT)
            //Static Initializer
            static $sinit()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(167503986757)
                    this.DefaultIssuer = "LOCAL AUTHORITY";
                    //--TRIMMABLE-BOUNDARY-END(167503986757)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(171798954053)
                    this.DefaultNameClaimType = "http://schemas.xmlsoap.org/ws/2005/05/identity/claims/name";
                    //--TRIMMABLE-BOUNDARY-END(171798954053)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(176093921349)
                    this.DefaultRoleClaimType = "http://schemas.microsoft.com/ws/2008/06/identity/claims/role";
                    //--TRIMMABLE-BOUNDARY-END(176093921349)
                    
                }
            }
            //--TRIMMABLE-BOUNDARY-END(SINIT)
            
            static $h = 262213;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 131073,
  "p": [
//--TRIMMABLE-BOUNDARY-START(133144248389),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 214748627013,
        "f": 50331777
      },
      "n": "AuthenticationType",
      "d": 262213,
      "h": 133144248389,
      "f": 2097281
    },
//--TRIMMABLE-BOUNDARY-END(133144248389),
//--TRIMMABLE-BOUNDARY-START(317827842117),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 257698299973,
        "f": 50331777
      },
      "n": "IsAuthenticated",
      "d": 262213,
      "h": 317827842117,
      "f": 2097281
    },
//--TRIMMABLE-BOUNDARY-END(317827842117),
//--TRIMMABLE-BOUNDARY-START(120259346501),
    {
      "p": 262213,
      "g": {
        "r": 0,
        "d": 0,
        "h": 206158692421,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 360777515077,
        "f": 83886081
      },
      "n": "Actor",
      "d": 262213,
      "h": 120259346501,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(120259346501),
//--TRIMMABLE-BOUNDARY-START(137439215685),
    {
      "p": 131073,
      "g": {
        "r": 0,
        "d": 0,
        "h": 223338561605,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 369367449669,
        "f": 83886081
      },
      "n": "BootstrapContext",
      "d": 262213,
      "h": 137439215685,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(137439215685),
//--TRIMMABLE-BOUNDARY-START(141734182981),
    {
      "p": $.$$.System.Collections.Generic.IEnumerable$$($.$ssc.System.Security.Claims.Claim).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 231928496197,
        "f": 50331777
      },
      "n": "Claims",
      "d": 262213,
      "h": 141734182981,
      "f": 2097281
    },
//--TRIMMABLE-BOUNDARY-END(141734182981),
//--TRIMMABLE-BOUNDARY-START(158914052165),
    {
      "p": $.$typeArray($.$$.System.Byte).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 240518430789,
        "f": 50331780
      },
      "n": "CustomSerializationData",
      "d": 262213,
      "h": 158914052165,
      "f": 2097284
    },
//--TRIMMABLE-BOUNDARY-END(158914052165),
//--TRIMMABLE-BOUNDARY-START(180388888645),
    {
      "p": $.$$.System.Collections.Generic.List$$($.$$.System.Collections.Generic.List$$($.$ssc.System.Security.Claims.Claim)).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 249108365381,
        "f": 50331656
      },
      "n": "ExternalClaims",
      "d": 262213,
      "h": 180388888645,
      "f": 2097160
    },
//--TRIMMABLE-BOUNDARY-END(180388888645),
//--TRIMMABLE-BOUNDARY-START(326417776709),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 266288234565,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 377957384261,
        "f": 83886081
      },
      "n": "Label",
      "d": 262213,
      "h": 326417776709,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(326417776709),
//--TRIMMABLE-BOUNDARY-START(330712744005),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 274878169157,
        "f": 50331777
      },
      "n": "Name",
      "d": 262213,
      "h": 330712744005,
      "f": 2097281
    },
//--TRIMMABLE-BOUNDARY-END(330712744005),
//--TRIMMABLE-BOUNDARY-START(335007711301),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 283468103749,
        "f": 50331649
      },
      "n": "NameClaimType",
      "d": 262213,
      "h": 335007711301,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(335007711301),
//--TRIMMABLE-BOUNDARY-START(343597645893),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 292058038341,
        "f": 50331649
      },
      "n": "RoleClaimType",
      "d": 262213,
      "h": 343597645893,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(343597645893)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(150324117573),
    {
      "r": $.$$.System.Collections.Generic.IEnumerable$$($.$ssc.System.Security.Claims.Claim).$h,
      "n": "CombinedClaimsIterator",
      "d": 262213,
      "h": 150324117573,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(150324117573),
//--TRIMMABLE-BOUNDARY-START(146029150277),
    {
      "r": 262213,
      "n": "Clone",
      "d": 262213,
      "h": 146029150277,
      "f": 16777345
    },
//--TRIMMABLE-BOUNDARY-END(146029150277),
//--TRIMMABLE-BOUNDARY-START(124554313797),
    {
      "r": 65537,
      "p": [
        {
          "n": "claim",
          "p": 131141
        }
      ],
      "n": "AddClaim",
      "d": 262213,
      "h": 124554313797,
      "f": 16777345
    },
//--TRIMMABLE-BOUNDARY-END(124554313797),
//--TRIMMABLE-BOUNDARY-START(128849281093),
    {
      "r": 65537,
      "p": [
        {
          "n": "claims",
          "p": $.$$.System.Collections.Generic.IEnumerable$$($.$ssc.System.Security.Claims.Claim).$h
        }
      ],
      "n": "AddClaims",
      "d": 262213,
      "h": 128849281093,
      "f": 16777345
    },
//--TRIMMABLE-BOUNDARY-END(128849281093),
//--TRIMMABLE-BOUNDARY-START(382252351557),
    {
      "r": 262145,
      "p": [
        {
          "n": "claim",
          "p": 131141
        }
      ],
      "n": "TryRemoveClaim",
      "d": 262213,
      "h": 382252351557,
      "f": 16777345
    },
//--TRIMMABLE-BOUNDARY-END(382252351557),
//--TRIMMABLE-BOUNDARY-START(339302678597),
    {
      "r": 65537,
      "p": [
        {
          "n": "claim",
          "p": 131141
        }
      ],
      "n": "RemoveClaim",
      "d": 262213,
      "h": 339302678597,
      "f": 16777345
    },
//--TRIMMABLE-BOUNDARY-END(339302678597),
//--TRIMMABLE-BOUNDARY-START(352187580485),
    {
      "r": 65537,
      "p": [
        {
          "n": "claims",
          "p": $.$$.System.Collections.Generic.IEnumerable$$($.$ssc.System.Security.Claims.Claim).$h
        }
      ],
      "n": "SafeAddClaims",
      "d": 262213,
      "h": 352187580485,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(352187580485),
//--TRIMMABLE-BOUNDARY-START(347892613189),
    {
      "r": 65537,
      "p": [
        {
          "n": "claim",
          "p": 131141
        }
      ],
      "n": "SafeAddClaim",
      "d": 262213,
      "h": 347892613189,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(347892613189),
//--TRIMMABLE-BOUNDARY-START(184683855941),
    {
      "r": $.$$.System.Collections.Generic.IEnumerable$$($.$ssc.System.Security.Claims.Claim).$h,
      "p": [
        {
          "n": "match",
          "p": $.$$.System.Predicate$$($.$ssc.System.Security.Claims.Claim).$h
        }
      ],
      "n": "FindAll",
      "d": 262213,
      "h": 184683855941,
      "f": 16777345
    },
//--TRIMMABLE-BOUNDARY-END(184683855941),
//--TRIMMABLE-BOUNDARY-START(188978823237),
    {
      "r": $.$$.System.Collections.Generic.IEnumerable$$($.$ssc.System.Security.Claims.Claim).$h,
      "p": [
        {
          "n": "type",
          "p": 1310721
        }
      ],
      "n": "FindAll",
      "o": "@$1",
      "d": 262213,
      "h": 188978823237,
      "f": 16777345
    },
//--TRIMMABLE-BOUNDARY-END(188978823237),
//--TRIMMABLE-BOUNDARY-START(193273790533),
    {
      "r": 131141,
      "p": [
        {
          "n": "match",
          "p": $.$$.System.Predicate$$($.$ssc.System.Security.Claims.Claim).$h
        }
      ],
      "n": "FindFirst",
      "d": 262213,
      "h": 193273790533,
      "f": 16777345
    },
//--TRIMMABLE-BOUNDARY-END(193273790533),
//--TRIMMABLE-BOUNDARY-START(197568757829),
    {
      "r": 131141,
      "p": [
        {
          "n": "type",
          "p": 1310721
        }
      ],
      "n": "FindFirst",
      "o": "@$1",
      "d": 262213,
      "h": 197568757829,
      "f": 16777345
    },
//--TRIMMABLE-BOUNDARY-END(197568757829),
//--TRIMMABLE-BOUNDARY-START(300647972933),
    {
      "r": 262145,
      "p": [
        {
          "n": "match",
          "p": $.$$.System.Predicate$$($.$ssc.System.Security.Claims.Claim).$h
        }
      ],
      "n": "HasClaim",
      "d": 262213,
      "h": 300647972933,
      "f": 16777345
    },
//--TRIMMABLE-BOUNDARY-END(300647972933),
//--TRIMMABLE-BOUNDARY-START(304942940229),
    {
      "r": 262145,
      "p": [
        {
          "n": "type",
          "p": 1310721
        },
        {
          "n": "value",
          "p": 1310721
        }
      ],
      "n": "HasClaim",
      "o": "@$1",
      "d": 262213,
      "h": 304942940229,
      "f": 16777345
    },
//--TRIMMABLE-BOUNDARY-END(304942940229),
//--TRIMMABLE-BOUNDARY-START(313532874821),
    {
      "r": 65537,
      "p": [
        {
          "n": "other",
          "p": 262213
        }
      ],
      "n": "Initialize",
      "o": "@$1",
      "d": 262213,
      "h": 313532874821,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(313532874821),
//--TRIMMABLE-BOUNDARY-START(309237907525),
    {
      "r": 65537,
      "p": [
        {
          "n": "reader",
          "p": 91226113
        }
      ],
      "n": "Initialize",
      "d": 262213,
      "h": 309237907525,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(309237907525),
//--TRIMMABLE-BOUNDARY-START(154619084869),
    {
      "r": 131141,
      "p": [
        {
          "n": "reader",
          "p": 91226113
        }
      ],
      "n": "CreateClaim",
      "d": 262213,
      "h": 154619084869,
      "f": 16777348
    },
//--TRIMMABLE-BOUNDARY-END(154619084869),
//--TRIMMABLE-BOUNDARY-START(395137253445),
    {
      "r": 65537,
      "p": [
        {
          "n": "writer",
          "p": 91291649
        }
      ],
      "n": "WriteTo",
      "o": "@$1",
      "d": 262213,
      "h": 395137253445,
      "f": 16777345
    },
//--TRIMMABLE-BOUNDARY-END(395137253445),
//--TRIMMABLE-BOUNDARY-START(390842286149),
    {
      "r": 65537,
      "p": [
        {
          "n": "writer",
          "p": 91291649
        },
        {
          "n": "userData",
          "p": $.$typeArray($.$$.System.Byte).$h
        }
      ],
      "n": "WriteTo",
      "d": 262213,
      "h": 390842286149,
      "f": 16777348
    },
//--TRIMMABLE-BOUNDARY-END(390842286149),
//--TRIMMABLE-BOUNDARY-START(322122809413),
    {
      "r": 262145,
      "p": [
        {
          "n": "subject",
          "p": 262213
        }
      ],
      "n": "IsCircular",
      "d": 262213,
      "h": 322122809413,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(322122809413),
//--TRIMMABLE-BOUNDARY-START(296353005637),
    {
      "r": 65537,
      "p": [
        {
          "n": "info",
          "p": 158072833
        },
        {
          "n": "context",
          "p": 158203905
        }
      ],
      "n": "GetObjectData",
      "d": 262213,
      "h": 296353005637,
      "f": 16777348
    },
//--TRIMMABLE-BOUNDARY-END(296353005637),
//--TRIMMABLE-BOUNDARY-START(163209019461),
    {
      "r": 1310721,
      "n": "DebuggerToString",
      "d": 262213,
      "h": 163209019461,
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(163209019461),
//--TRIMMABLE-BOUNDARY-START(386547318853),
    {
      "r": 65537,
      "p": [
        {
          "n": "stringComparison",
          "p": 163577857
        }
      ],
      "n": "ValidateStringComparison",
      "d": 262213,
      "h": 386547318853,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(386547318853)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(42949935173),
    {
      "t": $.$typeArray($.$$.System.Byte).$h,
      "n": "_userSerializationData",
      "d": 262213,
      "h": 42949935173,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(42949935173),
//--TRIMMABLE-BOUNDARY-START(4295229509),
    {
      "t": 262213,
      "n": "_actor",
      "d": 262213,
      "h": 4295229509,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(4295229509),
//--TRIMMABLE-BOUNDARY-START(8590196805),
    {
      "t": 1310721,
      "n": "_authenticationType",
      "d": 262213,
      "h": 8590196805,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(8590196805),
//--TRIMMABLE-BOUNDARY-START(12885164101),
    {
      "t": 131073,
      "n": "_bootstrapContext",
      "d": 262213,
      "h": 12885164101,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(12885164101),
//--TRIMMABLE-BOUNDARY-START(17180131397),
    {
      "t": $.$$.System.Collections.Generic.List$$($.$$.System.Collections.Generic.List$$($.$ssc.System.Security.Claims.Claim)).$h,
      "n": "_externalClaims",
      "d": 262213,
      "h": 17180131397,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(17180131397),
//--TRIMMABLE-BOUNDARY-START(25770065989),
    {
      "t": 1310721,
      "n": "_label",
      "d": 262213,
      "h": 25770065989,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(25770065989),
//--TRIMMABLE-BOUNDARY-START(21475098693),
    {
      "t": $.$$.System.Collections.Generic.List$$($.$ssc.System.Security.Claims.Claim).$h,
      "n": "_instanceClaims",
      "d": 262213,
      "h": 21475098693,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(21475098693),
//--TRIMMABLE-BOUNDARY-START(30065033285),
    {
      "t": 1310721,
      "n": "_nameClaimType",
      "d": 262213,
      "h": 30065033285,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(30065033285),
//--TRIMMABLE-BOUNDARY-START(34360000581),
    {
      "t": 1310721,
      "n": "_roleClaimType",
      "d": 262213,
      "h": 34360000581,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(34360000581),
//--TRIMMABLE-BOUNDARY-START(38654967877),
    {
      "t": 163577857,
      "n": "_stringComparison",
      "d": 262213,
      "h": 38654967877,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(38654967877),
//--TRIMMABLE-BOUNDARY-START(167503986757),
    {
      "t": 1310721,
      "n": "DefaultIssuer",
      "d": 262213,
      "h": 167503986757,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(167503986757),
//--TRIMMABLE-BOUNDARY-START(171798954053),
    {
      "t": 1310721,
      "n": "DefaultNameClaimType",
      "d": 262213,
      "h": 171798954053,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(171798954053),
//--TRIMMABLE-BOUNDARY-START(176093921349),
    {
      "t": 1310721,
      "n": "DefaultRoleClaimType",
      "d": 262213,
      "h": 176093921349,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(176093921349)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(51539869765),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 262213,
      "h": 51539869765,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(51539869765),
//--TRIMMABLE-BOUNDARY-START(98784510021),
    {
      "p": [
        {
          "n": "identity",
          "p": 161153025
        }
      ],
      "n": ".ctor",
      "o": "$ctor$12",
      "d": 262213,
      "h": 98784510021,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(98784510021),
//--TRIMMABLE-BOUNDARY-START(64424771653),
    {
      "p": [
        {
          "n": "claims",
          "p": $.$$.System.Collections.Generic.IEnumerable$$($.$ssc.System.Security.Claims.Claim).$h
        }
      ],
      "n": ".ctor",
      "o": "$ctor$4",
      "d": 262213,
      "h": 64424771653,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(64424771653),
//--TRIMMABLE-BOUNDARY-START(107374444613),
    {
      "p": [
        {
          "n": "authenticationType",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$14",
      "d": 262213,
      "h": 107374444613,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(107374444613),
//--TRIMMABLE-BOUNDARY-START(60129804357),
    {
      "p": [
        {
          "n": "claims",
          "p": $.$$.System.Collections.Generic.IEnumerable$$($.$ssc.System.Security.Claims.Claim).$h
        },
        {
          "n": "authenticationType",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 262213,
      "h": 60129804357,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(60129804357),
//--TRIMMABLE-BOUNDARY-START(94489542725),
    {
      "p": [
        {
          "n": "identity",
          "p": 161153025
        },
        {
          "n": "claims",
          "p": $.$$.System.Collections.Generic.IEnumerable$$($.$ssc.System.Security.Claims.Claim).$h
        }
      ],
      "n": ".ctor",
      "o": "$ctor$11",
      "d": 262213,
      "h": 94489542725,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(94489542725),
//--TRIMMABLE-BOUNDARY-START(103079477317),
    {
      "p": [
        {
          "n": "authenticationType",
          "p": 1310721
        },
        {
          "n": "nameType",
          "p": 1310721
        },
        {
          "n": "roleType",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$13",
      "d": 262213,
      "h": 103079477317,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(103079477317),
//--TRIMMABLE-BOUNDARY-START(55834837061),
    {
      "p": [
        {
          "n": "claims",
          "p": $.$$.System.Collections.Generic.IEnumerable$$($.$ssc.System.Security.Claims.Claim).$h
        },
        {
          "n": "authenticationType",
          "p": 1310721
        },
        {
          "n": "nameType",
          "p": 1310721
        },
        {
          "n": "roleType",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 262213,
      "h": 55834837061,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(55834837061),
//--TRIMMABLE-BOUNDARY-START(90194575429),
    {
      "p": [
        {
          "n": "identity",
          "p": 161153025
        },
        {
          "n": "claims",
          "p": $.$$.System.Collections.Generic.IEnumerable$$($.$ssc.System.Security.Claims.Claim).$h
        },
        {
          "n": "authenticationType",
          "p": 1310721
        },
        {
          "n": "nameType",
          "p": 1310721
        },
        {
          "n": "roleType",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$10",
      "d": 262213,
      "h": 90194575429,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(90194575429),
//--TRIMMABLE-BOUNDARY-START(73014706245),
    {
      "p": [
        {
          "n": "reader",
          "p": 91226113
        }
      ],
      "n": ".ctor",
      "o": "$ctor$6",
      "d": 262213,
      "h": 73014706245,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(73014706245),
//--TRIMMABLE-BOUNDARY-START(68719738949),
    {
      "p": [
        {
          "n": "reader",
          "p": 91226113
        },
        {
          "n": "stringComparison",
          "p": 163577857
        }
      ],
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 262213,
      "h": 68719738949,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(68719738949),
//--TRIMMABLE-BOUNDARY-START(115964379205),
    {
      "p": [
        {
          "n": "other",
          "p": 262213
        }
      ],
      "n": ".ctor",
      "o": "$ctor$16",
      "d": 262213,
      "h": 115964379205,
      "f": 16777220
    },
//--TRIMMABLE-BOUNDARY-END(115964379205),
//--TRIMMABLE-BOUNDARY-START(111669411909),
    {
      "p": [
        {
          "n": "other",
          "p": 262213
        },
        {
          "n": "stringComparison",
          "p": 163577857
        }
      ],
      "n": ".ctor",
      "o": "$ctor$15",
      "d": 262213,
      "h": 111669411909,
      "f": 16777220
    },
//--TRIMMABLE-BOUNDARY-END(111669411909),
//--TRIMMABLE-BOUNDARY-START(85899608133),
    {
      "p": [
        {
          "n": "identity",
          "p": 161153025,
          "f": 65
        },
        {
          "n": "claims",
          "p": $.$$.System.Collections.Generic.IEnumerable$$($.$ssc.System.Security.Claims.Claim).$h,
          "f": 65
        },
        {
          "n": "authenticationType",
          "p": 1310721,
          "f": 65
        },
        {
          "n": "nameType",
          "p": 1310721,
          "f": 65
        },
        {
          "n": "roleType",
          "p": 1310721,
          "f": 65
        },
        {
          "n": "stringComparison",
          "p": 163577857,
          "f": 65,
          "v": 5
        }
      ],
      "n": ".ctor",
      "o": "$ctor$9",
      "d": 262213,
      "h": 85899608133,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(85899608133),
//--TRIMMABLE-BOUNDARY-START(77309673541),
    {
      "p": [
        {
          "n": "info",
          "p": 158072833
        },
        {
          "n": "context",
          "p": 158203905
        }
      ],
      "n": ".ctor",
      "o": "$ctor$7",
      "d": 262213,
      "h": 77309673541,
      "f": 16777220,
      "a": [
        {
          "t": 103743489,
          "c": 30168514561,
          "a": [
            {
              "v": "This API supports obsolete formatter-based serialization. It should not be called or extended by application code.",
              "t": 1310721
            }
          ],
          "n": [
            {
              "n": "DiagnosticId",
              "v": "SYSLIB0051",
              "t": 1310721
            },
            {
              "n": "UrlFormat",
              "v": "https://aka.ms/dotnet-warnings/{0}",
              "t": 1310721
            }
          ]
        },
        {
          "t": 64290817,
          "c": 12949192705,
          "a": [
            {
              "v": 1,
              "t": 64356353
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(77309673541),
//--TRIMMABLE-BOUNDARY-START(81604640837),
    {
      "p": [
        {
          "n": "info",
          "p": 158072833
        }
      ],
      "n": ".ctor",
      "o": "$ctor$8",
      "d": 262213,
      "h": 81604640837,
      "f": 16777220,
      "a": [
        {
          "t": 103743489,
          "c": 30168514561,
          "a": [
            {
              "v": "This API supports obsolete formatter-based serialization. It should not be called or extended by application code.",
              "t": 1310721
            }
          ],
          "n": [
            {
              "n": "DiagnosticId",
              "v": "SYSLIB0051",
              "t": 1310721
            },
            {
              "n": "UrlFormat",
              "v": "https://aka.ms/dotnet-warnings/{0}",
              "t": 1310721
            }
          ]
        },
        {
          "t": 64290817,
          "c": 12949192705,
          "a": [
            {
              "v": 1,
              "t": 64356353
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(81604640837)
  ],
  "i": [161153025
  ],
  "j": [327749
  ],
  "h": 262213,
  "a": [
    {
      "t": 70385665,
      "c": 25840189441,
      "a": [
        {
          "v": "{DebuggerToString(),nq}",
          "t": 1310721
        }
      ]
    }
  ]
}; }
            static get $b() { return $.$$.System.Object; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.System.Security.Principal.IIdentity ]; }
            static get $fullName() { return `System.Security.Claims.ClaimsIdentity`; }
        });
        //--TRIMMABLE-BOUNDARY-END(262213)
        
        
        //--TRIMMABLE-BOUNDARY-START(393285)
        $asm.$cls("$ssc.System.Security.Claims.ClaimsPrincipal", ($self) => class ClaimsPrincipal extends $.$$.System.Object
        {
            //--TRIMMABLE-BOUNDARY-START(458821)
            static $_SerializationMask;
            static get SerializationMask()
            {
                let $cls = $.$ssc.System.Security.Claims.ClaimsPrincipal;
                return $cls.$_SerializationMask ??= $asm.$nstr("$ssc.System.Security.Claims.ClaimsPrincipal.SerializationMask", ($self) => class SerializationMask extends $.$$.System.Enum
                {
                    static None = 0;
                    static HasIdentities = 1;
                    static UserData = 2;
                    static $map;
                    static get Map()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(458821);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return this.$map ??= 
                        {
                            "None": 0n,
                            "HasIdentities": 1n,
                            "UserData": 2n
                        };
                    }
                    static $h = 458821;
                    static $z = 4;
                    static $f = 0b110000011010001000;
                    static $k = 4;
                    static get $eut() { return $.$$.System.Int32; }
                    static $$md;
                    static get $md() { return this.$$md ??= {
  "b": 1048577,
  "u": 655361,
  "l": [
//--TRIMMABLE-BOUNDARY-START(12885360709),
    {
      "t": 458821,
      "n": "None",
      "d": 458821,
      "h": 12885360709,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(12885360709),
//--TRIMMABLE-BOUNDARY-START(8590393413),
    {
      "t": 458821,
      "n": "HasIdentities",
      "d": 458821,
      "h": 8590393413,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(8590393413),
//--TRIMMABLE-BOUNDARY-START(17180328005),
    {
      "t": 458821,
      "n": "UserData",
      "d": 458821,
      "h": 17180328005,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(17180328005)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295426117),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 458821,
      "h": 4295426117,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295426117)
  ],
  "i": [90046465,96600065,90505217,90177537
  ],
  "d": 393285,
  "h": 458821
}; }
                    static get $b() { return $.$$.System.Enum; }
                    static $$i;
                    static get $i() { return this.$$i ??= [ $.$$.System.IComparable, $.$$.System.ISpanFormattable, $.$$.System.IFormattable, $.$$.System.IConvertible ]; }
                    static get $fullName() { return `System.Security.Claims.ClaimsPrincipal.SerializationMask`; }
                }, $cls, ($v) => $cls.$_SerializationMask = $v);
            }
            //--TRIMMABLE-BOUNDARY-END(458821)
            
            //--TRIMMABLE-BOUNDARY-START(4295360581)
            /*List<ClaimsIdentity>*/ _identities = null;
            //--TRIMMABLE-BOUNDARY-END(4295360581)
            
            //--TRIMMABLE-BOUNDARY-START(8590327877)
            /*byte[]?*/ _userSerializationData = null;
            //--TRIMMABLE-BOUNDARY-END(8590327877)
            
            //--TRIMMABLE-BOUNDARY-START(197568888901)
            /*Func<IEnumerable<ClaimsIdentity>, ClaimsIdentity?>*/ static s_identitySelector = null;
            //--TRIMMABLE-BOUNDARY-END(197568888901)
            
            //--TRIMMABLE-BOUNDARY-START(201863856197)
            /*Func<ClaimsPrincipal?>?*/ static s_principalSelector = null;
            //--TRIMMABLE-BOUNDARY-END(201863856197)
            
            //--TRIMMABLE-BOUNDARY-START(206158823493)
            static /*ClaimsPrincipal? */ SelectClaimsPrincipal()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(206158823493);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*IPrincipal?*/ let threadPrincipal = $.$$.System.Threading.Thread.CurrentPrincipal;
                return (() =>
                {
                    {
                        let claimsPrincipal;
                        if ((claimsPrincipal = threadPrincipal, $.$is(claimsPrincipal, $.$ssc.System.Security.Claims.ClaimsPrincipal)))
                        {
                            return claimsPrincipal;
                        }
                    }
                    if (threadPrincipal === null)
                    {
                        return new $.$ssc.System.Security.Claims.ClaimsPrincipal().$ctor$6(threadPrincipal);
                    }
                    if (threadPrincipal === null)
                    {
                        return null;
                    }
                })();
            }
            //--TRIMMABLE-BOUNDARY-END(206158823493)
            
            //--TRIMMABLE-BOUNDARY-START(34360131653)
            $ctor$4(/*SerializationInfo*/ info, /*StreamingContext*/ context)
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(34360131653);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(34360131653)
            
            //--TRIMMABLE-BOUNDARY-START(210453790789)
            static /*ClaimsIdentity? */ SelectPrimaryIdentity(/*IEnumerable<ClaimsIdentity>*/ identities)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(210453790789);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.ArgumentNullException.ThrowIfNull$2(identities, "identities");
                var $en2 = identities.System$Collections$Generic$IEnumerable$$$GetEnumerator();
                while ($en2.System$Collections$IEnumerator$MoveNext())
                {
                    var identity = $en2.System$Collections$Generic$IEnumerator$$$Current;
                    {
                        if (identity !== null)
                        {
                            return identity;
                        }
                    }
                }
                return null;
            }
            //--TRIMMABLE-BOUNDARY-END(210453790789)
            
            //--TRIMMABLE-BOUNDARY-START(193273921605)
            static /*Func<IEnumerable<ClaimsIdentity>, ClaimsIdentity?> */ get PrimaryIdentitySelector()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(158914183237);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$ssc.System.Security.Claims.ClaimsPrincipal.s_identitySelector;
            }
            static /*Func<IEnumerable<ClaimsIdentity>, ClaimsIdentity?> */ set PrimaryIdentitySelector(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(227633659973);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$ssc.System.Security.Claims.ClaimsPrincipal.s_identitySelector = value;
            }
            //--TRIMMABLE-BOUNDARY-END(193273921605)
            
            //--TRIMMABLE-BOUNDARY-START(60129935429)
            static /*Func<ClaimsPrincipal?>? */ get ClaimsPrincipalSelector()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(115964510277);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$ssc.System.Security.Claims.ClaimsPrincipal.s_principalSelector;
            }
            static /*Func<ClaimsPrincipal?>? */ set ClaimsPrincipalSelector(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(219043725381);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$ssc.System.Security.Claims.ClaimsPrincipal.s_principalSelector = value;
            }
            //--TRIMMABLE-BOUNDARY-END(60129935429)
            
            //--TRIMMABLE-BOUNDARY-START(21475229765)
            $ctor$1()
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(21475229765);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(21475229765)
            
            //--TRIMMABLE-BOUNDARY-START(25770197061)
            $ctor$2(/*IEnumerable<ClaimsIdentity>*/ identities)
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(25770197061);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$$.System.ArgumentNullException.ThrowIfNull$2(identities, "identities");
                    this._identities.AddRange(identities);
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(25770197061)
            
            //--TRIMMABLE-BOUNDARY-START(38655098949)
            $ctor$5(/*IIdentity*/ identity)
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(38655098949);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$$.System.ArgumentNullException.ThrowIfNull$2(identity, "identity");
                    let ci;
                    if ($.$is(identity, $.$ssc.System.Security.Claims.ClaimsIdentity, { set $v(v){ ci = v; } }))
                    {
                        this._identities.Add(ci);
                    }
                    else 
                    {
                        this._identities.Add(new $.$ssc.System.Security.Claims.ClaimsIdentity().$ctor$12(identity));
                    }
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(38655098949)
            
            //--TRIMMABLE-BOUNDARY-START(42950066245)
            $ctor$6(/*IPrincipal*/ principal)
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(42950066245);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$$.System.ArgumentNullException.ThrowIfNull$2(principal, "principal");
                    /*ClaimsPrincipal?*/ let cp = $.$as(principal, $.$ssc.System.Security.Claims.ClaimsPrincipal);
                    if (null === cp)
                    {
                        this._identities.Add(new $.$ssc.System.Security.Claims.ClaimsIdentity().$ctor$12(principal.System$Security$Principal$IPrincipal$Identity));
                    }
                    else 
                    {
                        if (null !== cp.Identities)
                        {
                            this._identities.AddRange(cp.Identities);
                        }
                    }
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(42950066245)
            
            //--TRIMMABLE-BOUNDARY-START(30065164357)
            $ctor$3(/*BinaryReader*/ reader)
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(30065164357);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$$.System.ArgumentNullException.ThrowIfNull$2(reader, "reader");
                    /*SerializationMask*/ let mask = $.$cast(reader.ReadInt32(), $.$ssc.System.Security.Claims.ClaimsPrincipal.SerializationMask);
                    /*int*/ let numPropertiesToRead = reader.ReadInt32();
                    /*int*/ let numPropertiesRead = 0;
                    if ((mask & 1/*SerializationMask.HasIdentities*/) === 1/*SerializationMask.HasIdentities*/)
                    {
                        numPropertiesRead++;
                        /*int*/ let numberOfIdentities = reader.ReadInt32();
                        for(/*int*/ let index = 0; index < numberOfIdentities; ++index)
                        {
                            this._identities.Add(this.CreateClaimsIdentity(reader));
                        }
                    }
                    if ((mask & 2/*SerializationMask.UserData*/) === 2/*SerializationMask.UserData*/)
                    {
                        /*int*/ let cb = reader.ReadInt32();
                        this._userSerializationData = reader.ReadBytes(cb);
                        numPropertiesRead++;
                    }
                    for(/*int*/ let i = numPropertiesRead; i < numPropertiesToRead; i++)
                    {
                        reader.ReadString();
                    }
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(30065164357)
            
            //--TRIMMABLE-BOUNDARY-START(51540000837)
            /*void */ AddIdentity(/*ClaimsIdentity*/ identity)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(51540000837);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.ArgumentNullException.ThrowIfNull$2(identity, "identity");
                this._identities.Add(identity);
            }
            //--TRIMMABLE-BOUNDARY-END(51540000837)
            
            //--TRIMMABLE-BOUNDARY-START(47245033541)
            /*void */ AddIdentities(/*IEnumerable<ClaimsIdentity>*/ identities)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(47245033541);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.ArgumentNullException.ThrowIfNull$2(identities, "identities");
                this._identities.AddRange(identities);
            }
            //--TRIMMABLE-BOUNDARY-END(47245033541)
            
            //--TRIMMABLE-BOUNDARY-START(55834968133)
            /*IEnumerable<Claim> */ get Claims()
            {
                return new ($.$$.NetJs.YieldToIterator$$($.$ssc.System.Security.Claims.Claim))().$ctor$1(function*()
                {
                    var $en3 = this.Identities.System$Collections$Generic$IEnumerable$$$GetEnumerator();
                    while ($en3.System$Collections$IEnumerator$MoveNext())
                    {
                        var identity = $en3.System$Collections$Generic$IEnumerator$$$Current;
                        {
                            var $en5 = identity.Claims.System$Collections$Generic$IEnumerable$$$GetEnumerator();
                            while ($en5.System$Collections$IEnumerator$MoveNext())
                            {
                                var claim = $en5.System$Collections$Generic$IEnumerator$$$Current;
                                {
                                    yield claim;
                                }
                            }
                        }
                    }
                }.bind(this));
            }
            //--TRIMMABLE-BOUNDARY-END(55834968133)
            
            //--TRIMMABLE-BOUNDARY-START(77309804613)
            /*byte[]? */ get CustomSerializationData()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(133144379461);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this._userSerializationData;
            }
            //--TRIMMABLE-BOUNDARY-END(77309804613)
            
            //--TRIMMABLE-BOUNDARY-START(64424902725)
            /*ClaimsPrincipal */ Clone()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(64424902725);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return new $.$ssc.System.Security.Claims.ClaimsPrincipal().$ctor$6(this);
            }
            //--TRIMMABLE-BOUNDARY-END(64424902725)
            
            //--TRIMMABLE-BOUNDARY-START(68719870021)
            /*ClaimsIdentity */ CreateClaimsIdentity(/*BinaryReader*/ reader)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(68719870021);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.ArgumentNullException.ThrowIfNull$2(reader, "reader");
                return new $.$ssc.System.Security.Claims.ClaimsIdentity().$ctor$6(reader);
            }
            //--TRIMMABLE-BOUNDARY-END(68719870021)
            
            //--TRIMMABLE-BOUNDARY-START(73014837317)
            static /*ClaimsPrincipal? */ get Current()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(124554444869);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return !($.$ssc.System.Security.Claims.ClaimsPrincipal.s_principalSelector === null) ? $.$ssc.System.Security.Claims.ClaimsPrincipal.s_principalSelector.Invoke() : $.$ssc.System.Security.Claims.ClaimsPrincipal.SelectClaimsPrincipal();
            }
            //--TRIMMABLE-BOUNDARY-END(73014837317)
            
            //--TRIMMABLE-BOUNDARY-START(85899739205)
            /*IEnumerable<Claim> */ FindAll(/*Predicate<Claim>*/ match)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(85899739205);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.ArgumentNullException.ThrowIfNull$2(match, "match");
                return Core.call(this, match);
                /*IEnumerable<Claim>*/  function Core(/*Predicate<Claim>*/ match)
                {
                    return new ($.$$.NetJs.YieldToIterator$$($.$$.System.Object))().$ctor$1(function*()
                    {
                        var $en4 = this.Identities.System$Collections$Generic$IEnumerable$$$GetEnumerator();
                        while ($en4.System$Collections$IEnumerator$MoveNext())
                        {
                            var identity = $en4.System$Collections$Generic$IEnumerator$$$Current;
                            {
                                if (identity !== null)
                                {
                                    var $en7 = identity.FindAll(match).System$Collections$Generic$IEnumerable$$$GetEnumerator();
                                    while ($en7.System$Collections$IEnumerator$MoveNext())
                                    {
                                        var claim = $en7.System$Collections$Generic$IEnumerator$$$Current;
                                        {
                                            yield claim;
                                        }
                                    }
                                }
                            }
                        }
                    }.bind(this));
                }
            }
            //--TRIMMABLE-BOUNDARY-END(85899739205)
            
            //--TRIMMABLE-BOUNDARY-START(90194706501)
            /*IEnumerable<Claim> */ FindAll$1(/*string*/ type)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(90194706501);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.ArgumentNullException.ThrowIfNull$2(type, "type");
                return Core.call(this, type);
                /*IEnumerable<Claim>*/  function Core(/*string*/ type)
                {
                    return new ($.$$.NetJs.YieldToIterator$$($.$$.System.Object))().$ctor$1(function*()
                    {
                        var $en4 = this.Identities.System$Collections$Generic$IEnumerable$$$GetEnumerator();
                        while ($en4.System$Collections$IEnumerator$MoveNext())
                        {
                            var identity = $en4.System$Collections$Generic$IEnumerator$$$Current;
                            {
                                if (identity !== null)
                                {
                                    var $en7 = identity.FindAll$1(type).System$Collections$Generic$IEnumerable$$$GetEnumerator();
                                    while ($en7.System$Collections$IEnumerator$MoveNext())
                                    {
                                        var claim = $en7.System$Collections$Generic$IEnumerator$$$Current;
                                        {
                                            yield claim;
                                        }
                                    }
                                }
                            }
                        }
                    }.bind(this));
                }
            }
            //--TRIMMABLE-BOUNDARY-END(90194706501)
            
            //--TRIMMABLE-BOUNDARY-START(94489673797)
            /*Claim? */ FindFirst(/*Predicate<Claim>*/ match)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(94489673797);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.ArgumentNullException.ThrowIfNull$2(match, "match");
                /*Claim?*/ let claim = null;
                var $en2 = this.Identities.System$Collections$Generic$IEnumerable$$$GetEnumerator();
                while ($en2.System$Collections$IEnumerator$MoveNext())
                {
                    var identity = $en2.System$Collections$Generic$IEnumerator$$$Current;
                    {
                        if (identity !== null)
                        {
                            claim = identity.FindFirst(match);
                            if (claim !== null)
                            {
                                return claim;
                            }
                        }
                    }
                }
                return claim;
            }
            //--TRIMMABLE-BOUNDARY-END(94489673797)
            
            //--TRIMMABLE-BOUNDARY-START(98784641093)
            /*Claim? */ FindFirst$1(/*string*/ type)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(98784641093);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.ArgumentNullException.ThrowIfNull$2(type, "type");
                /*Claim?*/ let claim = null;
                for(/*int*/ let i = 0; i < this._identities.Count; i++)
                {
                    if (this._identities.get_Item(i) !== null)
                    {
                        claim = this._identities.get_Item(i).FindFirst$1(type);
                        if (claim !== null)
                        {
                            return claim;
                        }
                    }
                }
                return claim;
            }
            //--TRIMMABLE-BOUNDARY-END(98784641093)
            
            //--TRIMMABLE-BOUNDARY-START(167504117829)
            /*bool */ HasClaim(/*Predicate<Claim>*/ match)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(167504117829);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.ArgumentNullException.ThrowIfNull$2(match, "match");
                for(/*int*/ let i = 0; i < this._identities.Count; i++)
                {
                    if (this._identities.get_Item(i) !== null)
                    {
                        if (this._identities.get_Item(i).HasClaim(match))
                        {
                            return true;
                        }
                    }
                }
                return false;
            }
            //--TRIMMABLE-BOUNDARY-END(167504117829)
            
            //--TRIMMABLE-BOUNDARY-START(171799085125)
            /*bool */ HasClaim$1(/*string*/ type, /*string*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(171799085125);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.ArgumentNullException.ThrowIfNull$2(type, "type");
                $.$$.System.ArgumentNullException.ThrowIfNull$2(value, "value");
                for(/*int*/ let i = 0; i < this._identities.Count; i++)
                {
                    if (this._identities.get_Item(i) !== null)
                    {
                        if (this._identities.get_Item(i).HasClaim$1(type, value))
                        {
                            return true;
                        }
                    }
                }
                return false;
            }
            //--TRIMMABLE-BOUNDARY-END(171799085125)
            
            //--TRIMMABLE-BOUNDARY-START(176094052421)
            /*IEnumerable<ClaimsIdentity> */ get Identities()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(141734314053);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this._identities;
            }
            //--TRIMMABLE-BOUNDARY-END(176094052421)
            
            //--TRIMMABLE-BOUNDARY-START(180389019717)
            /*System.Security.Principal.IIdentity? */ get Identity()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(150324248645);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$ssc.System.Security.Claims.ClaimsPrincipal.s_identitySelector !== null)
                {
                    return $.$ssc.System.Security.Claims.ClaimsPrincipal.s_identitySelector.Invoke(this._identities);
                }
                else 
                {
                    return $.$ssc.System.Security.Claims.ClaimsPrincipal.SelectPrimaryIdentity(this._identities);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(180389019717)
            
            //--TRIMMABLE-BOUNDARY-START(184683987013)
            /*bool */ IsInRole(/*string*/ role)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(184683987013);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                for(/*int*/ let i = 0; i < this._identities.Count; i++)
                {
                    if (this._identities.get_Item(i) !== null)
                    {
                        if (this._identities.get_Item(i).HasClaim$1(this._identities.get_Item(i).RoleClaimType, role))
                        {
                            return true;
                        }
                    }
                }
                return false;
            }
            //--TRIMMABLE-BOUNDARY-END(184683987013)
            
            //--TRIMMABLE-BOUNDARY-START(236223594565)
            /*void */ WriteTo$1(/*BinaryWriter*/ writer)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(236223594565);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.WriteTo(writer, null);
            }
            //--TRIMMABLE-BOUNDARY-END(236223594565)
            
            //--TRIMMABLE-BOUNDARY-START(231928627269)
            /*void */ WriteTo(/*BinaryWriter*/ writer, /*byte[]?*/ userData)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(231928627269);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.ArgumentNullException.ThrowIfNull$2(writer, "writer");
                /*int*/ let numberOfPropertiesWritten = 0;
                /*var*/ let mask = 0/*SerializationMask.None*/;
                if (this._identities.Count > 0)
                {
                    mask |= 1/*SerializationMask.HasIdentities*/;
                    numberOfPropertiesWritten++;
                }
                if (userData !== null && userData.length > 0)
                {
                    numberOfPropertiesWritten++;
                    mask |= 2/*SerializationMask.UserData*/;
                }
                writer.Write$11(mask);
                writer.Write$11(numberOfPropertiesWritten);
                if ((mask & 1/*SerializationMask.HasIdentities*/) === 1/*SerializationMask.HasIdentities*/)
                {
                    writer.Write$11(this._identities.Count);
                    var $en3 = this._identities.GetEnumerator();
                    while ($en3.MoveNext())
                    {
                        var identity = $en3.Current;
                        {
                            identity.WriteTo$1(writer);
                        }
                    }
                }
                if ((mask & 2/*SerializationMask.UserData*/) === 2/*SerializationMask.UserData*/)
                {
                    writer.Write$11(userData.length);
                    writer.Write$3(userData);
                }
                writer.Flush();
            }
            //--TRIMMABLE-BOUNDARY-END(231928627269)
            
            //--TRIMMABLE-BOUNDARY-START(188978954309)
            /*void */ OnSerializingMethod(/*StreamingContext*/ context)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(188978954309);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$is(this, $.$$.System.Runtime.Serialization.ISerializable))
                {
                    return;
                }
                if (this._identities.Count > 0)
                {
                    throw new $.$$.System.PlatformNotSupportedException().$ctor$16($.$ssc.System.SR.PlatformNotSupported_Serialization);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(188978954309)
            
            //--TRIMMABLE-BOUNDARY-START(163209150533)
            /*void */ GetObjectData(/*SerializationInfo*/ info, /*StreamingContext*/ context)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(163209150533);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(163209150533)
            
            //--TRIMMABLE-BOUNDARY-START(81604771909)
            /*string */ DebuggerToString()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(81604771909);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*int*/ let identitiesCount = 0;
                var $en2 = this.Identities.System$Collections$Generic$IEnumerable$$$GetEnumerator();
                while ($en2.System$Collections$IEnumerator$MoveNext())
                {
                    var items = $en2.System$Collections$Generic$IEnumerator$$$Current;
                    {
                        identitiesCount++;
                    }
                }
                let claimsIdentity;
                if (identitiesCount === 1 && $.$is(this.Identity, $.$ssc.System.Security.Claims.ClaimsIdentity, { set $v(v){ claimsIdentity = v; } }))
                {
                    return claimsIdentity.DebuggerToString();
                }
                /*int*/ let claimsCount = 0;
                var $en2 = this.Claims.System$Collections$Generic$IEnumerable$$$GetEnumerator();
                while ($en2.System$Collections$IEnumerator$MoveNext())
                {
                    var item = $en2.System$Collections$Generic$IEnumerator$$$Current;
                    {
                        claimsCount++;
                    }
                }
                return `Identities = ${identitiesCount}, Claims = ${claimsCount}`;
            }
            //--TRIMMABLE-BOUNDARY-END(81604771909)
            
            //--TRIMMABLE-BOUNDARY-START(8751153153)
            //Generated interface implemetation for System.Security.Principal.IPrincipal.Identity.get
            get System$Security$Principal$IPrincipal$Identity()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(13046120449);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Identity;
            }
            //--TRIMMABLE-BOUNDARY-END(8751153153)
            
            //--TRIMMABLE-BOUNDARY-START(17341087745)
            //Generated interface implemetation for System.Security.Principal.IPrincipal.IsInRole(string)
            System$Security$Principal$IPrincipal$IsInRole()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17341087745);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.IsInRole(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(17341087745)
            
            //default member initializer
            constructor()
            {
                super();
                //--TRIMMABLE-BOUNDARY-START(4295360581)
                this._identities = new ($.$$.System.Collections.Generic.List$$($.$ssc.System.Security.Claims.ClaimsIdentity))().$ctor$1();
                //--TRIMMABLE-BOUNDARY-END(4295360581)
                
            }
            //--TRIMMABLE-BOUNDARY-START(17180262469)
            //Static Initializer
            static $sinit()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(197568888901)
                    this.s_identitySelector = new ($.$$.System.Func$$$($.$$.System.Collections.Generic.IEnumerable$$($.$ssc.System.Security.Claims.ClaimsIdentity), $.$ssc.System.Security.Claims.ClaimsIdentity))().$ctor($.$ssc.System.Security.Claims.ClaimsPrincipal, $.$ssc.System.Security.Claims.ClaimsPrincipal.SelectPrimaryIdentity);
                    //--TRIMMABLE-BOUNDARY-END(197568888901)
                    
                }
            }
            //--TRIMMABLE-BOUNDARY-END(17180262469)
            
            static $h = 393285;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 131073,
  "p": [
//--TRIMMABLE-BOUNDARY-START(193273921605),
    {
      "p": $.$$.System.Func$$$($.$$.System.Collections.Generic.IEnumerable$$($.$ssc.System.Security.Claims.ClaimsIdentity), $.$ssc.System.Security.Claims.ClaimsIdentity).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 158914183237,
        "f": 50331681
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 227633659973,
        "f": 83886113
      },
      "n": "PrimaryIdentitySelector",
      "d": 393285,
      "h": 193273921605,
      "f": 2097185
    },
//--TRIMMABLE-BOUNDARY-END(193273921605),
//--TRIMMABLE-BOUNDARY-START(60129935429),
    {
      "p": $.$$.System.Func$$($.$ssc.System.Security.Claims.ClaimsPrincipal).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 115964510277,
        "f": 50331681
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 219043725381,
        "f": 83886113
      },
      "n": "ClaimsPrincipalSelector",
      "d": 393285,
      "h": 60129935429,
      "f": 2097185
    },
//--TRIMMABLE-BOUNDARY-END(60129935429),
//--TRIMMABLE-BOUNDARY-START(55834968133),
    {
      "p": $.$$.System.Collections.Generic.IEnumerable$$($.$ssc.System.Security.Claims.Claim).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 107374575685,
        "f": 50331777
      },
      "n": "Claims",
      "d": 393285,
      "h": 55834968133,
      "f": 2097281
    },
//--TRIMMABLE-BOUNDARY-END(55834968133),
//--TRIMMABLE-BOUNDARY-START(77309804613),
    {
      "p": $.$typeArray($.$$.System.Byte).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 133144379461,
        "f": 50331780
      },
      "n": "CustomSerializationData",
      "d": 393285,
      "h": 77309804613,
      "f": 2097284
    },
//--TRIMMABLE-BOUNDARY-END(77309804613),
//--TRIMMABLE-BOUNDARY-START(73014837317),
    {
      "p": 393285,
      "g": {
        "r": 0,
        "d": 0,
        "h": 124554444869,
        "f": 50331681
      },
      "n": "Current",
      "d": 393285,
      "h": 73014837317,
      "f": 2097185
    },
//--TRIMMABLE-BOUNDARY-END(73014837317),
//--TRIMMABLE-BOUNDARY-START(176094052421),
    {
      "p": $.$$.System.Collections.Generic.IEnumerable$$($.$ssc.System.Security.Claims.ClaimsIdentity).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 141734314053,
        "f": 50331777
      },
      "n": "Identities",
      "d": 393285,
      "h": 176094052421,
      "f": 2097281
    },
//--TRIMMABLE-BOUNDARY-END(176094052421),
//--TRIMMABLE-BOUNDARY-START(180389019717),
    {
      "p": 161153025,
      "g": {
        "r": 0,
        "d": 0,
        "h": 150324248645,
        "f": 50331777
      },
      "n": "Identity",
      "d": 393285,
      "h": 180389019717,
      "f": 2097281
    },
//--TRIMMABLE-BOUNDARY-END(180389019717)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(206158823493),
    {
      "r": 393285,
      "n": "SelectClaimsPrincipal",
      "d": 393285,
      "h": 206158823493,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(206158823493),
//--TRIMMABLE-BOUNDARY-START(210453790789),
    {
      "r": 262213,
      "p": [
        {
          "n": "identities",
          "p": $.$$.System.Collections.Generic.IEnumerable$$($.$ssc.System.Security.Claims.ClaimsIdentity).$h
        }
      ],
      "n": "SelectPrimaryIdentity",
      "d": 393285,
      "h": 210453790789,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(210453790789),
//--TRIMMABLE-BOUNDARY-START(51540000837),
    {
      "r": 65537,
      "p": [
        {
          "n": "identity",
          "p": 262213
        }
      ],
      "n": "AddIdentity",
      "d": 393285,
      "h": 51540000837,
      "f": 16777345
    },
//--TRIMMABLE-BOUNDARY-END(51540000837),
//--TRIMMABLE-BOUNDARY-START(47245033541),
    {
      "r": 65537,
      "p": [
        {
          "n": "identities",
          "p": $.$$.System.Collections.Generic.IEnumerable$$($.$ssc.System.Security.Claims.ClaimsIdentity).$h
        }
      ],
      "n": "AddIdentities",
      "d": 393285,
      "h": 47245033541,
      "f": 16777345
    },
//--TRIMMABLE-BOUNDARY-END(47245033541),
//--TRIMMABLE-BOUNDARY-START(64424902725),
    {
      "r": 393285,
      "n": "Clone",
      "d": 393285,
      "h": 64424902725,
      "f": 16777345
    },
//--TRIMMABLE-BOUNDARY-END(64424902725),
//--TRIMMABLE-BOUNDARY-START(68719870021),
    {
      "r": 262213,
      "p": [
        {
          "n": "reader",
          "p": 91226113
        }
      ],
      "n": "CreateClaimsIdentity",
      "d": 393285,
      "h": 68719870021,
      "f": 16777348
    },
//--TRIMMABLE-BOUNDARY-END(68719870021),
//--TRIMMABLE-BOUNDARY-START(85899739205),
    {
      "r": $.$$.System.Collections.Generic.IEnumerable$$($.$ssc.System.Security.Claims.Claim).$h,
      "p": [
        {
          "n": "match",
          "p": $.$$.System.Predicate$$($.$ssc.System.Security.Claims.Claim).$h
        }
      ],
      "n": "FindAll",
      "d": 393285,
      "h": 85899739205,
      "f": 16777345
    },
//--TRIMMABLE-BOUNDARY-END(85899739205),
//--TRIMMABLE-BOUNDARY-START(90194706501),
    {
      "r": $.$$.System.Collections.Generic.IEnumerable$$($.$ssc.System.Security.Claims.Claim).$h,
      "p": [
        {
          "n": "type",
          "p": 1310721
        }
      ],
      "n": "FindAll",
      "o": "@$1",
      "d": 393285,
      "h": 90194706501,
      "f": 16777345
    },
//--TRIMMABLE-BOUNDARY-END(90194706501),
//--TRIMMABLE-BOUNDARY-START(94489673797),
    {
      "r": 131141,
      "p": [
        {
          "n": "match",
          "p": $.$$.System.Predicate$$($.$ssc.System.Security.Claims.Claim).$h
        }
      ],
      "n": "FindFirst",
      "d": 393285,
      "h": 94489673797,
      "f": 16777345
    },
//--TRIMMABLE-BOUNDARY-END(94489673797),
//--TRIMMABLE-BOUNDARY-START(98784641093),
    {
      "r": 131141,
      "p": [
        {
          "n": "type",
          "p": 1310721
        }
      ],
      "n": "FindFirst",
      "o": "@$1",
      "d": 393285,
      "h": 98784641093,
      "f": 16777345
    },
//--TRIMMABLE-BOUNDARY-END(98784641093),
//--TRIMMABLE-BOUNDARY-START(167504117829),
    {
      "r": 262145,
      "p": [
        {
          "n": "match",
          "p": $.$$.System.Predicate$$($.$ssc.System.Security.Claims.Claim).$h
        }
      ],
      "n": "HasClaim",
      "d": 393285,
      "h": 167504117829,
      "f": 16777345
    },
//--TRIMMABLE-BOUNDARY-END(167504117829),
//--TRIMMABLE-BOUNDARY-START(171799085125),
    {
      "r": 262145,
      "p": [
        {
          "n": "type",
          "p": 1310721
        },
        {
          "n": "value",
          "p": 1310721
        }
      ],
      "n": "HasClaim",
      "o": "@$1",
      "d": 393285,
      "h": 171799085125,
      "f": 16777345
    },
//--TRIMMABLE-BOUNDARY-END(171799085125),
//--TRIMMABLE-BOUNDARY-START(184683987013),
    {
      "r": 262145,
      "p": [
        {
          "n": "role",
          "p": 1310721
        }
      ],
      "n": "IsInRole",
      "d": 393285,
      "h": 184683987013,
      "f": 16777345
    },
//--TRIMMABLE-BOUNDARY-END(184683987013),
//--TRIMMABLE-BOUNDARY-START(236223594565),
    {
      "r": 65537,
      "p": [
        {
          "n": "writer",
          "p": 91291649
        }
      ],
      "n": "WriteTo",
      "o": "@$1",
      "d": 393285,
      "h": 236223594565,
      "f": 16777345
    },
//--TRIMMABLE-BOUNDARY-END(236223594565),
//--TRIMMABLE-BOUNDARY-START(231928627269),
    {
      "r": 65537,
      "p": [
        {
          "n": "writer",
          "p": 91291649
        },
        {
          "n": "userData",
          "p": $.$typeArray($.$$.System.Byte).$h
        }
      ],
      "n": "WriteTo",
      "d": 393285,
      "h": 231928627269,
      "f": 16777348
    },
//--TRIMMABLE-BOUNDARY-END(231928627269),
//--TRIMMABLE-BOUNDARY-START(188978954309),
    {
      "r": 65537,
      "p": [
        {
          "n": "context",
          "p": 158203905
        }
      ],
      "n": "OnSerializingMethod",
      "d": 393285,
      "h": 188978954309,
      "f": 16777218,
      "a": [
        {
          "t": 157745153,
          "c": 4452712449
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(188978954309),
//--TRIMMABLE-BOUNDARY-START(163209150533),
    {
      "r": 65537,
      "p": [
        {
          "n": "info",
          "p": 158072833
        },
        {
          "n": "context",
          "p": 158203905
        }
      ],
      "n": "GetObjectData",
      "d": 393285,
      "h": 163209150533,
      "f": 16777348
    },
//--TRIMMABLE-BOUNDARY-END(163209150533),
//--TRIMMABLE-BOUNDARY-START(81604771909),
    {
      "r": 1310721,
      "n": "DebuggerToString",
      "d": 393285,
      "h": 81604771909,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(81604771909)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(4295360581),
    {
      "t": $.$$.System.Collections.Generic.List$$($.$ssc.System.Security.Claims.ClaimsIdentity).$h,
      "n": "_identities",
      "d": 393285,
      "h": 4295360581,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(4295360581),
//--TRIMMABLE-BOUNDARY-START(8590327877),
    {
      "t": $.$typeArray($.$$.System.Byte).$h,
      "n": "_userSerializationData",
      "d": 393285,
      "h": 8590327877,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(8590327877),
//--TRIMMABLE-BOUNDARY-START(197568888901),
    {
      "t": $.$$.System.Func$$$($.$$.System.Collections.Generic.IEnumerable$$($.$ssc.System.Security.Claims.ClaimsIdentity), $.$ssc.System.Security.Claims.ClaimsIdentity).$h,
      "n": "s_identitySelector",
      "d": 393285,
      "h": 197568888901,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(197568888901),
//--TRIMMABLE-BOUNDARY-START(201863856197),
    {
      "t": $.$$.System.Func$$($.$ssc.System.Security.Claims.ClaimsPrincipal).$h,
      "n": "s_principalSelector",
      "d": 393285,
      "h": 201863856197,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(201863856197)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(34360131653),
    {
      "p": [
        {
          "n": "info",
          "p": 158072833
        },
        {
          "n": "context",
          "p": 158203905
        }
      ],
      "n": ".ctor",
      "o": "$ctor$4",
      "d": 393285,
      "h": 34360131653,
      "f": 16777220,
      "a": [
        {
          "t": 103743489,
          "c": 30168514561,
          "a": [
            {
              "v": "This API supports obsolete formatter-based serialization. It should not be called or extended by application code.",
              "t": 1310721
            }
          ],
          "n": [
            {
              "n": "DiagnosticId",
              "v": "SYSLIB0051",
              "t": 1310721
            },
            {
              "n": "UrlFormat",
              "v": "https://aka.ms/dotnet-warnings/{0}",
              "t": 1310721
            }
          ]
        },
        {
          "t": 64290817,
          "c": 12949192705,
          "a": [
            {
              "v": 1,
              "t": 64356353
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(34360131653),
//--TRIMMABLE-BOUNDARY-START(21475229765),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 393285,
      "h": 21475229765,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(21475229765),
//--TRIMMABLE-BOUNDARY-START(25770197061),
    {
      "p": [
        {
          "n": "identities",
          "p": $.$$.System.Collections.Generic.IEnumerable$$($.$ssc.System.Security.Claims.ClaimsIdentity).$h
        }
      ],
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 393285,
      "h": 25770197061,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(25770197061),
//--TRIMMABLE-BOUNDARY-START(38655098949),
    {
      "p": [
        {
          "n": "identity",
          "p": 161153025
        }
      ],
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 393285,
      "h": 38655098949,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(38655098949),
//--TRIMMABLE-BOUNDARY-START(42950066245),
    {
      "p": [
        {
          "n": "principal",
          "p": 161218561
        }
      ],
      "n": ".ctor",
      "o": "$ctor$6",
      "d": 393285,
      "h": 42950066245,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(42950066245),
//--TRIMMABLE-BOUNDARY-START(30065164357),
    {
      "p": [
        {
          "n": "reader",
          "p": 91226113
        }
      ],
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 393285,
      "h": 30065164357,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(30065164357)
  ],
  "i": [161218561
  ],
  "j": [458821
  ],
  "h": 393285,
  "a": [
    {
      "t": 70385665,
      "c": 25840189441,
      "a": [
        {
          "v": "{DebuggerToString(),nq}",
          "t": 1310721
        }
      ]
    }
  ]
}; }
            static get $b() { return $.$$.System.Object; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.System.Security.Principal.IPrincipal ]; }
            static get $fullName() { return `System.Security.Claims.ClaimsPrincipal`; }
        });
        //--TRIMMABLE-BOUNDARY-END(393285)
        
        
        //--TRIMMABLE-BOUNDARY-START(655429)
        $asm.$cls("$ssc.System.Security.Principal.GenericIdentity", ($self) => class GenericIdentity extends $.$ssc.System.Security.Claims.ClaimsIdentity
        {
            //--TRIMMABLE-BOUNDARY-START(73015099461)
            /*string*/ m_name = null;
            //--TRIMMABLE-BOUNDARY-END(73015099461)
            
            //--TRIMMABLE-BOUNDARY-START(77310066757)
            /*string*/ m_type = null;
            //--TRIMMABLE-BOUNDARY-END(77310066757)
            
            //--TRIMMABLE-BOUNDARY-START(8590590021)
            $ctor$18(/*string*/ name)
            {
                super.$ctor$9(null, null, null, null, null, 5);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(8590590021);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$$.System.ArgumentNullException.ThrowIfNull$2(name, "name");
                    this.m_name = name;
                    this.m_type = "";
                    this.AddNameClaim();
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(8590590021)
            
            //--TRIMMABLE-BOUNDARY-START(4295622725)
            $ctor$17(/*string*/ name, /*string*/ type)
            {
                super.$ctor$9(null, null, null, null, null, 5);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4295622725);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$$.System.ArgumentNullException.ThrowIfNull$2(name, "name");
                    $.$$.System.ArgumentNullException.ThrowIfNull$2(type, "type");
                    this.m_name = name;
                    this.m_type = type;
                    this.AddNameClaim();
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295622725)
            
            //--TRIMMABLE-BOUNDARY-START(12885557317)
            $ctor$19(/*GenericIdentity*/ identity)
            {
                super.$ctor$16(identity);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(12885557317);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this.m_name = identity.m_name;
                    this.m_type = identity.m_type;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(12885557317)
            
            //--TRIMMABLE-BOUNDARY-START(30065426501)
            /*ClaimsIdentity */ Clone()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(30065426501);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return new $.$ssc.System.Security.Principal.GenericIdentity().$ctor$19(this);
            }
            //--TRIMMABLE-BOUNDARY-END(30065426501)
            
            //--TRIMMABLE-BOUNDARY-START(25770459205)
            /*IEnumerable<Claim> */ get Claims()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(47245295685);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return super.Claims;
            }
            //--TRIMMABLE-BOUNDARY-END(25770459205)
            
            //--TRIMMABLE-BOUNDARY-START(81605034053)
            /*string */ get Name()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(64425164869);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.m_name;
            }
            //--TRIMMABLE-BOUNDARY-END(81605034053)
            
            //--TRIMMABLE-BOUNDARY-START(21475491909)
            /*string */ get AuthenticationType()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(38655361093);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.m_type;
            }
            //--TRIMMABLE-BOUNDARY-END(21475491909)
            
            //--TRIMMABLE-BOUNDARY-START(68720132165)
            /*bool */ get IsAuthenticated()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(55835230277);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return !$.$$.System.String.Equals$5.call(this.m_name, "");
            }
            //--TRIMMABLE-BOUNDARY-END(68720132165)
            
            //--TRIMMABLE-BOUNDARY-START(17180524613)
            /*void */ AddNameClaim()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17180524613);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$$.System.String.op_Inequality(this.m_name, null))
                {
                    super.AddClaim(new $.$ssc.System.Security.Claims.Claim().$ctor$4(super.NameClaimType, this.m_name, "http://www.w3.org/2001/XMLSchema#string"/*ClaimValueTypes.String*/, "LOCAL AUTHORITY"/*ClaimsIdentity.DefaultIssuer*/, "LOCAL AUTHORITY"/*ClaimsIdentity.DefaultIssuer*/, this));
                }
            }
            //--TRIMMABLE-BOUNDARY-END(17180524613)
            
            static $h = 655429;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 262213,
  "p": [
//--TRIMMABLE-BOUNDARY-START(25770459205),
    {
      "p": $.$$.System.Collections.Generic.IEnumerable$$($.$ssc.System.Security.Claims.Claim).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 47245295685,
        "f": 50364417
      },
      "n": "Claims",
      "d": 655429,
      "h": 25770459205,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(25770459205),
//--TRIMMABLE-BOUNDARY-START(81605034053),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 64425164869,
        "f": 50364417
      },
      "n": "Name",
      "d": 655429,
      "h": 81605034053,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(81605034053),
//--TRIMMABLE-BOUNDARY-START(21475491909),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 38655361093,
        "f": 50364417
      },
      "n": "AuthenticationType",
      "d": 655429,
      "h": 21475491909,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(21475491909),
//--TRIMMABLE-BOUNDARY-START(68720132165),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 55835230277,
        "f": 50364417
      },
      "n": "IsAuthenticated",
      "d": 655429,
      "h": 68720132165,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(68720132165)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(30065426501),
    {
      "r": 262213,
      "n": "Clone",
      "d": 655429,
      "h": 30065426501,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(30065426501),
//--TRIMMABLE-BOUNDARY-START(17180524613),
    {
      "r": 65537,
      "n": "AddNameClaim",
      "d": 655429,
      "h": 17180524613,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(17180524613)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(73015099461),
    {
      "t": 1310721,
      "n": "m_name",
      "d": 655429,
      "h": 73015099461,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(73015099461),
//--TRIMMABLE-BOUNDARY-START(77310066757),
    {
      "t": 1310721,
      "n": "m_type",
      "d": 655429,
      "h": 77310066757,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(77310066757)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(8590590021),
    {
      "p": [
        {
          "n": "name",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$18",
      "d": 655429,
      "h": 8590590021,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8590590021),
//--TRIMMABLE-BOUNDARY-START(4295622725),
    {
      "p": [
        {
          "n": "name",
          "p": 1310721
        },
        {
          "n": "type",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$17",
      "d": 655429,
      "h": 4295622725,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295622725),
//--TRIMMABLE-BOUNDARY-START(12885557317),
    {
      "p": [
        {
          "n": "identity",
          "p": 655429
        }
      ],
      "n": ".ctor",
      "o": "$ctor$19",
      "d": 655429,
      "h": 12885557317,
      "f": 16777220
    },
//--TRIMMABLE-BOUNDARY-END(12885557317)
  ],
  "i": [161153025
  ],
  "h": 655429
}; }
            static get $b() { return $.$ssc.System.Security.Claims.ClaimsIdentity; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.System.Security.Principal.IIdentity ]; }
            static get $fullName() { return `System.Security.Principal.GenericIdentity`; }
        });
        //--TRIMMABLE-BOUNDARY-END(655429)
        
        
        //--TRIMMABLE-BOUNDARY-START(720965)
        $asm.$cls("$ssc.System.Security.Principal.GenericPrincipal", ($self) => class GenericPrincipal extends $.$ssc.System.Security.Claims.ClaimsPrincipal
        {
            //--TRIMMABLE-BOUNDARY-START(34360459333)
            /*IIdentity*/ m_identity = null;
            //--TRIMMABLE-BOUNDARY-END(34360459333)
            
            //--TRIMMABLE-BOUNDARY-START(38655426629)
            /*string[]?*/ m_roles = null;
            //--TRIMMABLE-BOUNDARY-END(38655426629)
            
            //--TRIMMABLE-BOUNDARY-START(4295688261)
            $ctor$7(/*IIdentity*/ identity, /*string[]?*/ roles)
            {
                super.$ctor$1();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4295688261);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$$.System.ArgumentNullException.ThrowIfNull$2(identity, "identity");
                    this.m_identity = identity;
                    if (roles !== null)
                    {
                        this.m_roles = $.$cast(roles.Clone(), $.$typeArray($.$$.System.String));
                    }
                    else 
                    {
                        this.m_roles = null;
                    }
                    this.AddIdentityWithRoles(this.m_identity, this.m_roles);
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295688261)
            
            //--TRIMMABLE-BOUNDARY-START(8590655557)
            /*void */ AddIdentityWithRoles(/*IIdentity*/ identity, /*string[]?*/ roles)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590655557);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                let claimsIdentity;
                if ($.$is(identity, $.$ssc.System.Security.Claims.ClaimsIdentity, { set $v(v){ claimsIdentity = v; } }))
                {
                    claimsIdentity = claimsIdentity.Clone();
                }
                else 
                {
                    claimsIdentity = new $.$ssc.System.Security.Claims.ClaimsIdentity().$ctor$12(identity);
                }
                if (roles !== null && roles.length > 0)
                {
                    /*List<Claim>*/ let roleClaims = new ($.$$.System.Collections.Generic.List$$($.$ssc.System.Security.Claims.Claim))().$ctor$3(roles.length);
                    let $i1 = 0;
                    let $arr1 = roles;
                    while ($i1 < $arr1.length)
                    {
                        let role = $arr1[$i1++];
                        if (!$.$$.System.String.IsNullOrWhiteSpace(role))
                        {
                            roleClaims.Add(new $.$ssc.System.Security.Claims.Claim().$ctor$4(claimsIdentity.RoleClaimType, role, "http://www.w3.org/2001/XMLSchema#string"/*ClaimValueTypes.String*/, "LOCAL AUTHORITY"/*ClaimsIdentity.DefaultIssuer*/, "LOCAL AUTHORITY"/*ClaimsIdentity.DefaultIssuer*/, claimsIdentity));
                        }
                    }
                    claimsIdentity.ExternalClaims.Add(roleClaims);
                }
                super.AddIdentity(claimsIdentity);
            }
            //--TRIMMABLE-BOUNDARY-END(8590655557)
            
            //--TRIMMABLE-BOUNDARY-START(25770524741)
            /*IIdentity */ get Identity()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17180590149);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.m_identity;
            }
            //--TRIMMABLE-BOUNDARY-END(25770524741)
            
            //--TRIMMABLE-BOUNDARY-START(30065492037)
            /*bool */ IsInRole(/*string?*/ role)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(30065492037);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$$.System.String.op_Equality(role, null) || this.m_roles === null)
                {
                    return false;
                }
                for(/*int*/ let i = 0; i < this.m_roles.length; ++i)
                {
                    if ($.$$.System.String.Equals$2($.$$.System.Array.$ReadT1.call(this.m_roles, i), role, 5/*StringComparison.OrdinalIgnoreCase*/))
                    {
                        return true;
                    }
                }
                return super.IsInRole(role);
            }
            //--TRIMMABLE-BOUNDARY-END(30065492037)
            
            //--TRIMMABLE-BOUNDARY-START(21475557445)
            static /*GenericPrincipal */ GetDefaultInstance()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(21475557445);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return new $.$ssc.System.Security.Principal.GenericPrincipal().$ctor$7(new $.$ssc.System.Security.Principal.GenericIdentity().$ctor$18($.$$.System.String.Empty), $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$$.System.String), [$.$$.System.String.Empty], [-1], null));
                }
            }
            //--TRIMMABLE-BOUNDARY-END(21475557445)
            
            static $h = 720965;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 393285,
  "p": [
//--TRIMMABLE-BOUNDARY-START(25770524741),
    {
      "p": 161153025,
      "g": {
        "r": 0,
        "d": 0,
        "h": 17180590149,
        "f": 50364417
      },
      "n": "Identity",
      "d": 720965,
      "h": 25770524741,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(25770524741)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(8590655557),
    {
      "r": 65537,
      "p": [
        {
          "n": "identity",
          "p": 161153025
        },
        {
          "n": "roles",
          "p": $.$typeArray($.$$.System.String).$h
        }
      ],
      "n": "AddIdentityWithRoles",
      "d": 720965,
      "h": 8590655557,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(8590655557),
//--TRIMMABLE-BOUNDARY-START(30065492037),
    {
      "r": 262145,
      "p": [
        {
          "n": "role",
          "p": 1310721
        }
      ],
      "n": "IsInRole",
      "d": 720965,
      "h": 30065492037,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(30065492037),
//--TRIMMABLE-BOUNDARY-START(21475557445),
    {
      "r": 720965,
      "n": "GetDefaultInstance",
      "d": 720965,
      "h": 21475557445,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(21475557445)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(34360459333),
    {
      "t": 161153025,
      "n": "m_identity",
      "d": 720965,
      "h": 34360459333,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(34360459333),
//--TRIMMABLE-BOUNDARY-START(38655426629),
    {
      "t": $.$typeArray($.$$.System.String).$h,
      "n": "m_roles",
      "d": 720965,
      "h": 38655426629,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(38655426629)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295688261),
    {
      "p": [
        {
          "n": "identity",
          "p": 161153025
        },
        {
          "n": "roles",
          "p": $.$typeArray($.$$.System.String).$h
        }
      ],
      "n": ".ctor",
      "o": "$ctor$7",
      "d": 720965,
      "h": 4295688261,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295688261)
  ],
  "i": [161218561
  ],
  "h": 720965
}; }
            static get $b() { return $.$ssc.System.Security.Claims.ClaimsPrincipal; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.System.Security.Principal.IPrincipal ]; }
            static get $fullName() { return `System.Security.Principal.GenericPrincipal`; }
        });
        //--TRIMMABLE-BOUNDARY-END(720965)
	});
})(window, window.NetJs.$boot(), ...window.NetJs.$require("NetJs.System.Private.CoreLib", "NetJs.System.Collections", "NetJs.System.Memory", "NetJs.System.Private.Uri", "NetJs.System.Runtime", "NetJs.System.Threading.Thread"))
//--TRIMMABLE-BOUNDARY-END(69)
