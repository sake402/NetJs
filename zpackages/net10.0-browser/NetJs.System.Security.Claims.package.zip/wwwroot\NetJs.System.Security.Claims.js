
(function ($global, $, $spc, $sc, $sm, $spu, $stt, $sr) {
    "use strict";
    let _;
    
    
    
	$.$asm(
    "NetJs.System.Security.Claims", 
    {"h":43932,"f":"System.Security.Claims","v":"1.0.35.0","a":[{"t":115146753,"c":13000048641,"a":[{"v":".NETCoreApp,Version=v10.0","t":1310721}],"n":[{"n":"FrameworkDisplayName","v":".NET 10.0","t":1310721}]},{"t":73596929,"c":4368564225,"a":[{"v":"SIT","t":1310721}]},{"t":73662465,"c":4368629761,"a":[{"v":"Debug","t":1310721}]},{"t":74121217,"c":4369088513,"a":[{"v":"1.0.35.0","t":1310721}]},{"t":74252289,"c":4369219585,"a":[{"v":"1.0.35\u002Bbeaaf5d41a0179d1ed930cf3efa03ea73d37a2ca","t":1310721}]},{"t":75104257,"c":4370071553,"a":[{"v":"NetJs.System.Security.Claims","t":1310721}]},{"t":75235329,"c":4370202625,"a":[{"v":"NetJs.System.Security.Claims","t":1310721}]},{"t":75366401,"c":4370333697,"a":[{"v":"1.0.35.0","t":1310721}]},{"t":115212289,"c":4410179585,"a":[{"v":"browser1.0","t":1310721}]},{"t":114950145,"c":4409917441,"a":[{"v":"browser1.0","t":1310721}]}],"m":[]},
    function($asm)
	{
        
        
        $asm.$cls("$ssc.System.SR", ($self) => class SR
        {
            /*global::System.Resources.ResourceManager*/ static s_resourceManager = null;
            /*global::System.Globalization.CultureInfo*/ static resourceCulture = null;
            static /*global::System.Resources.ResourceManager */ get ResourceManager()
            {
                if ($.$spc.System.Object.ReferenceEquals($.$ssc.System.SR.s_resourceManager, null))
                {
                    /*global::System.Resources.ResourceManager*/ let temp = new $.$spc.System.Resources.ResourceManager().$ctor$3("System.Security.Claims", $.$ssc.System.SR.$type.Assembly);
                    $.$ssc.System.SR.s_resourceManager = temp;
                }
                return $.$ssc.System.SR.s_resourceManager;
            }
            static /*global::System.Globalization.CultureInfo */ get Culture()
            {
                return $.$ssc.System.SR.resourceCulture;
            }
            static /*global::System.Globalization.CultureInfo */ set Culture(value)
            {
                $.$ssc.System.SR.resourceCulture = value;
            }
            static /*string */ get ArgumentException_StringComparisonCultureAware()
            {
                return "The StringComparison must be one of Ordinal, OrdinalIgnoreCase, InvariantCulture, InvariantCultureIgnoreCase.";
            }
            static /*string */ get InvalidOperation_ClaimCannotBeRemoved()
            {
                return "The Claim '{0}' was not able to be removed.  It is either not part of this Identity or it is a Claim that is owned by the Principal that contains this Identity. For example, the Principal will own the Claim when creating a GenericPrincipal with roles. The roles will be exposed through the Identity that is passed in the constructor, but not actually owned by the Identity.  Similar logic exists for a RolePrincipal.";
            }
            static /*string */ FormatInvalidOperation_ClaimCannotBeRemoved(/*object*/ arg1)
            {
                return $.$spc.System.String.Format("The Claim '{0}' was not able to be removed.  It is either not part of this Identity or it is a Claim that is owned by the Principal that contains this Identity. For example, the Principal will own the Claim when creating a GenericPrincipal with roles. The roles will be exposed through the Identity that is passed in the constructor, but not actually owned by the Identity.  Similar logic exists for a RolePrincipal.", arg1);
            }
            static /*string */ get InvalidOperationException_ActorGraphCircular()
            {
                return "An Actor must not create a circular reference between itself (or one of its child Actors) and one of its parents.";
            }
            static /*string */ get PlatformNotSupported_Serialization()
            {
                return "This instance contains state that cannot be serialized and deserialized on this platform.";
            }
            /*bool*/ static s_usingResourceKeys = false;
            static /*bool */ GetUsingResourceKeysSwitchValue()
            {
                /*bool*/ let usingResourceKeys;
                return $.$spc.System.AppContext.TryGetSwitch("System.Resources.UseSystemResourceKeys", $.$ref(() => usingResourceKeys, ($v) => usingResourceKeys = $v, $.$spc.System.Boolean)) ? usingResourceKeys : false;
            }
            static /*bool */ UsingResourceKeys()
            {
                return $.$ssc.System.SR.s_usingResourceKeys;
            }
            static /*string */ GetResourceString(/*string*/ resourceKey)
            {
                if ($.$ssc.System.SR.UsingResourceKeys())
                {
                    return resourceKey;
                }
                /*string?*/ let resourceString = null;
                try
                {
                    resourceString = $.$ssc.System.SR.ResourceManager.GetString(resourceKey);
                }
                catch($e)
                {
                }
                return resourceString;
            }
            static /*string */ GetResourceString$1(/*string*/ resourceKey, /*string*/ defaultString)
            {
                /*string*/ let resourceString = $.$ssc.System.SR.GetResourceString(resourceKey);
                return $.$spc.System.String.op_Equality(resourceKey, resourceString) || $.$spc.System.String.op_Equality(resourceString, null) ? defaultString : resourceString;
            }
            static /*string */ Format(/*string*/ resourceFormat, /*object?*/ p1)
            {
                if ($.$ssc.System.SR.UsingResourceKeys())
                {
                    return $.$spc.System.String.Join$10(", ", $.$spc.System.ReadOnlySpan$$($.$spc.System.Object).op_Implicit([ resourceFormat, p1 ]));
                }
                return $.$spc.System.String.Format(resourceFormat, p1);
            }
            static /*string */ Format$1(/*string*/ resourceFormat, /*object?*/ p1, /*object?*/ p2)
            {
                if ($.$ssc.System.SR.UsingResourceKeys())
                {
                    return $.$spc.System.String.Join$10(", ", $.$spc.System.ReadOnlySpan$$($.$spc.System.Object).op_Implicit([ resourceFormat, p1, p2 ]));
                }
                return $.$spc.System.String.Format$1(resourceFormat, p1, p2);
            }
            static /*string */ Format$2(/*string*/ resourceFormat, /*object?*/ p1, /*object?*/ p2, /*object?*/ p3)
            {
                if ($.$ssc.System.SR.UsingResourceKeys())
                {
                    return $.$spc.System.String.Join$10(", ", $.$spc.System.ReadOnlySpan$$($.$spc.System.Object).op_Implicit([ resourceFormat, p1, p2, p3 ]));
                }
                return $.$spc.System.String.Format$2(resourceFormat, p1, p2, p3);
            }
            static /*string */ Format$3(/*string*/ resourceFormat, /*params object?[]?*/ args)
            {
                if (args !== null)
                {
                    if ($.$ssc.System.SR.UsingResourceKeys())
                    {
                        return resourceFormat + ", " + $.$spc.System.String.Join$9(", ", args);
                    }
                    return $.$spc.System.String.Format$3(resourceFormat, args);
                }
                return resourceFormat;
            }
            static /*string */ Format$4(/*IFormatProvider?*/ provider, /*string*/ resourceFormat, /*object?*/ p1)
            {
                if ($.$ssc.System.SR.UsingResourceKeys())
                {
                    return $.$spc.System.String.Join$10(", ", $.$spc.System.ReadOnlySpan$$($.$spc.System.Object).op_Implicit([ resourceFormat, p1 ]));
                }
                return $.$spc.System.String.Format$5(provider, resourceFormat, p1);
            }
            static /*string */ Format$5(/*IFormatProvider?*/ provider, /*string*/ resourceFormat, /*object?*/ p1, /*object?*/ p2)
            {
                if ($.$ssc.System.SR.UsingResourceKeys())
                {
                    return $.$spc.System.String.Join$10(", ", $.$spc.System.ReadOnlySpan$$($.$spc.System.Object).op_Implicit([ resourceFormat, p1, p2 ]));
                }
                return $.$spc.System.String.Format$6(provider, resourceFormat, p1, p2);
            }
            static /*string */ Format$6(/*IFormatProvider?*/ provider, /*string*/ resourceFormat, /*object?*/ p1, /*object?*/ p2, /*object?*/ p3)
            {
                if ($.$ssc.System.SR.UsingResourceKeys())
                {
                    return $.$spc.System.String.Join$10(", ", $.$spc.System.ReadOnlySpan$$($.$spc.System.Object).op_Implicit([ resourceFormat, p1, p2, p3 ]));
                }
                return $.$spc.System.String.Format$7(provider, resourceFormat, p1, p2, p3);
            }
            static /*string */ Format$7(/*IFormatProvider?*/ provider, /*string*/ resourceFormat, /*params object?[]?*/ args)
            {
                if (args !== null)
                {
                    if ($.$ssc.System.SR.UsingResourceKeys())
                    {
                        return resourceFormat + ", " + $.$spc.System.String.Join$9(", ", args);
                    }
                    return $.$spc.System.String.Format$8(provider, resourceFormat, args);
                }
                return resourceFormat;
            }
            //Static Initializer
            static $sinit()
            {
                {
                    this.s_usingResourceKeys = $.$ssc.System.SR.GetUsingResourceKeysSwitchValue();
                }
            }
            static $h = 830364;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"h":830364}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.SR`; }
        });
        
        $asm.$cls("$ssc.System.Security.Claims.Claim", ($self) => class Claim extends $.$spc.System.Object
        {
            static $_SerializationMask;
            static get SerializationMask()
            {
                let $cls = $.$ssc.System.Security.Claims.Claim;
                return $cls.$_SerializationMask ??= $asm.$nstr("$ssc.System.Security.Claims.Claim.SerializationMask", ($self) => class SerializationMask extends $.$spc.System.Enum
                {
                    static None = 0;
                    static NameClaimType = 1;
                    static RoleClaimType = 2;
                    static StringType = 4;
                    static Issuer = 8;
                    static OriginalIssuerEqualsIssuer = 16;
                    static OriginalIssuer = 32;
                    static HasProperties = 64;
                    static UserData = 128;
                    static $map;
                    static get Map()
                    {
                        return this.$map ??= 
                        {
                            "None": 0n,
                            "NameClaimType": 1n,
                            "RoleClaimType": 2n,
                            "StringType": 4n,
                            "Issuer": 8n,
                            "OriginalIssuerEqualsIssuer": 16n,
                            "OriginalIssuer": 32n,
                            "HasProperties": 64n,
                            "UserData": 128n
                        };
                    }
                    static $h = 240540;
                    static $z = 4;
                    static $f = 0b110000011010001000;
                    static $k = 4;
                    static get $eut() { return $.$spc.System.Int32; }
                    static $$md;
                    static get $md() { return this.$$md ??= {"b":1048577,"u":655361,"l":[{"t":240540,"n":"None","d":240540,"h":4295207836,"f":33},{"t":240540,"n":"NameClaimType","d":240540,"h":8590175132,"f":33},{"t":240540,"n":"RoleClaimType","d":240540,"h":12885142428,"f":33},{"t":240540,"n":"StringType","d":240540,"h":17180109724,"f":33},{"t":240540,"n":"Issuer","d":240540,"h":21475077020,"f":33},{"t":240540,"n":"OriginalIssuerEqualsIssuer","d":240540,"h":25770044316,"f":33},{"t":240540,"n":"OriginalIssuer","d":240540,"h":30065011612,"f":33},{"t":240540,"n":"HasProperties","d":240540,"h":34359978908,"f":33},{"t":240540,"n":"UserData","d":240540,"h":38654946204,"f":33}],"c":[{"n":".ctor","o":"$ctor$3","d":240540,"h":42949913500,"f":1}],"i":[57212929,63766529,57671681,57344001],"d":175004,"h":240540}; }
                    static get $b() { return $.$spc.System.Enum; }
                    static $$i;
                    static get $i() { return this.$$i ??= [ $.$spc.System.IComparable, $.$spc.System.ISpanFormattable, $.$spc.System.IFormattable, $.$spc.System.IConvertible ]; }
                    static get $fullName() { return `System.Security.Claims.Claim.SerializationMask`; }
                }, $cls, ($v) => $cls.$_SerializationMask = $v);
            }
            /*byte[]?*/ _userSerializationData = null;
            /*string*/ _issuer = null;
            /*string*/ _originalIssuer = null;
            /*Dictionary<string, string>?*/ _properties = null;
            /*ClaimsIdentity?*/ _subject = null;
            /*string*/ _type = null;
            /*string*/ _value = null;
            /*string*/ _valueType = null;
            $ctor$1(/*BinaryReader*/ reader)
            {
                this.$ctor$2(reader, null);
                {
                }
                return this;
            }
            $ctor$2(/*BinaryReader*/ reader, /*ClaimsIdentity?*/ subject)
            {
                super.$ctor();
                {
                    $.$spc.System.ArgumentNullException.ThrowIfNull(reader, "reader");
                    this._subject = subject;
                    /*SerializationMask*/ let mask = $.$cast(reader.ReadInt32(), $.$ssc.System.Security.Claims.Claim.SerializationMask);
                    /*int*/ let numPropertiesRead = 1;
                    /*int*/ let numPropertiesToRead = reader.ReadInt32();
                    this._value = reader.ReadString();
                    if ((mask & 1/*SerializationMask.NameClaimType*/) === 1/*SerializationMask.NameClaimType*/)
                    {
                        this._type = "http://schemas.xmlsoap.org/ws/2005/05/identity/claims/name"/*ClaimsIdentity.DefaultNameClaimType*/;
                    }
                    else if ((mask & 2/*SerializationMask.RoleClaimType*/) === 2/*SerializationMask.RoleClaimType*/)
                    {
                        this._type = "http://schemas.microsoft.com/ws/2008/06/identity/claims/role"/*ClaimsIdentity.DefaultRoleClaimType*/;
                    }
                    else 
                    {
                        this._type = reader.ReadString();
                        numPropertiesRead++;
                    }
                    if ((mask & 4/*SerializationMask.StringType*/) === 4/*SerializationMask.StringType*/)
                    {
                        this._valueType = reader.ReadString();
                        numPropertiesRead++;
                    }
                    else 
                    {
                        this._valueType = "http://www.w3.org/2001/XMLSchema#string"/*ClaimValueTypes.String*/;
                    }
                    if ((mask & 8/*SerializationMask.Issuer*/) === 8/*SerializationMask.Issuer*/)
                    {
                        this._issuer = reader.ReadString();
                        numPropertiesRead++;
                    }
                    else 
                    {
                        this._issuer = "LOCAL AUTHORITY"/*ClaimsIdentity.DefaultIssuer*/;
                    }
                    if ((mask & 16/*SerializationMask.OriginalIssuerEqualsIssuer*/) === 16/*SerializationMask.OriginalIssuerEqualsIssuer*/)
                    {
                        this._originalIssuer = this._issuer;
                    }
                    else if ((mask & 32/*SerializationMask.OriginalIssuer*/) === 32/*SerializationMask.OriginalIssuer*/)
                    {
                        this._originalIssuer = reader.ReadString();
                        numPropertiesRead++;
                    }
                    else 
                    {
                        this._originalIssuer = "LOCAL AUTHORITY"/*ClaimsIdentity.DefaultIssuer*/;
                    }
                    if ((mask & 64/*SerializationMask.HasProperties*/) === 64/*SerializationMask.HasProperties*/)
                    {
                        /*int*/ let numProperties = reader.ReadInt32();
                        numPropertiesRead++;
                        for(/*int*/ let i = 0; i < numProperties; i++)
                        {
                            this.Properties.System$Collections$Generic$IDictionary$$$$Add(reader.ReadString(), reader.ReadString(), [$.$spc.System.String, $.$spc.System.String]);
                        }
                    }
                    if ((mask & 128/*SerializationMask.UserData*/) === 128/*SerializationMask.UserData*/)
                    {
                        /*int*/ let cb = reader.ReadInt32();
                        this._userSerializationData = reader.ReadBytes(cb);
                        numPropertiesRead++;
                    }
                    for(/*int*/ let i = numPropertiesRead; i < numPropertiesToRead; i++)
                    {
                        reader.ReadString();
                    }
                }
                return this;
            }
            $ctor$3(/*string*/ type, /*string*/ value)
            {
                this.$ctor$7(type, value, "http://www.w3.org/2001/XMLSchema#string"/*ClaimValueTypes.String*/, "LOCAL AUTHORITY"/*ClaimsIdentity.DefaultIssuer*/, "LOCAL AUTHORITY"/*ClaimsIdentity.DefaultIssuer*/, null);
                {
                }
                return this;
            }
            $ctor$4(/*string*/ type, /*string*/ value, /*string?*/ valueType)
            {
                this.$ctor$7(type, value, valueType, "LOCAL AUTHORITY"/*ClaimsIdentity.DefaultIssuer*/, "LOCAL AUTHORITY"/*ClaimsIdentity.DefaultIssuer*/, null);
                {
                }
                return this;
            }
            $ctor$5(/*string*/ type, /*string*/ value, /*string?*/ valueType, /*string?*/ issuer)
            {
                this.$ctor$7(type, value, valueType, issuer, issuer, null);
                {
                }
                return this;
            }
            $ctor$6(/*string*/ type, /*string*/ value, /*string?*/ valueType, /*string?*/ issuer, /*string?*/ originalIssuer)
            {
                this.$ctor$7(type, value, valueType, issuer, originalIssuer, null);
                {
                }
                return this;
            }
            $ctor$7(/*string*/ type, /*string*/ value, /*string?*/ valueType, /*string?*/ issuer, /*string?*/ originalIssuer, /*ClaimsIdentity?*/ subject)
            {
                this.$ctor$8(type, value, valueType, issuer, originalIssuer, subject, null, null);
                {
                }
                return this;
            }
            $ctor$8(/*string*/ type, /*string*/ value, /*string?*/ valueType, /*string?*/ issuer, /*string?*/ originalIssuer, /*ClaimsIdentity?*/ subject, /*string?*/ propertyKey, /*string?*/ propertyValue)
            {
                super.$ctor();
                {
                    $.$spc.System.ArgumentNullException.ThrowIfNull(type, "type");
                    $.$spc.System.ArgumentNullException.ThrowIfNull(value, "value");
                    this._type = type;
                    this._value = value;
                    this._valueType = $.$spc.System.String.IsNullOrEmpty(valueType) ? "http://www.w3.org/2001/XMLSchema#string"/*ClaimValueTypes.String*/ : valueType;
                    this._issuer = $.$spc.System.String.IsNullOrEmpty(issuer) ? "LOCAL AUTHORITY"/*ClaimsIdentity.DefaultIssuer*/ : issuer;
                    this._originalIssuer = $.$spc.System.String.IsNullOrEmpty(originalIssuer) ? this._issuer : originalIssuer;
                    this._subject = subject;
                    if ($.$spc.System.String.op_Inequality(propertyKey, null))
                    {
                        this._properties = new ($.$spc.System.Collections.Generic.Dictionary$$$($.$spc.System.String, $.$spc.System.String))().$ctor$1();
                        this._properties.set_Item(propertyKey, propertyValue);
                    }
                }
                return this;
            }
            $ctor$9(/*Claim*/ other)
            {
                this.$ctor$10(other, (other === null ? null : other._subject));
                {
                }
                return this;
            }
            $ctor$10(/*Claim*/ other, /*ClaimsIdentity?*/ subject)
            {
                super.$ctor();
                {
                    $.$spc.System.ArgumentNullException.ThrowIfNull(other, "other");
                    this._issuer = other._issuer;
                    this._originalIssuer = other._originalIssuer;
                    this._subject = subject;
                    this._type = other._type;
                    this._value = other._value;
                    this._valueType = other._valueType;
                    if (other._properties !== null)
                    {
                        this._properties = new ($.$spc.System.Collections.Generic.Dictionary$$$($.$spc.System.String, $.$spc.System.String))().$ctor$5(other._properties);
                    }
                    if (other._userSerializationData !== null)
                    {
                        this._userSerializationData = $.$as(other._userSerializationData.Clone(), $.$typeArray($.$spc.System.Byte));
                    }
                }
                return this;
            }
            /*byte[]? */ get CustomSerializationData()
            {
                return this._userSerializationData;
            }
            /*string */ get Issuer()
            {
                return this._issuer;
            }
            /*string */ get OriginalIssuer()
            {
                return this._originalIssuer;
            }
            /*IDictionary<string, string> */ get Properties()
            {
                return this._properties ??= new ($.$spc.System.Collections.Generic.Dictionary$$$($.$spc.System.String, $.$spc.System.String))().$ctor$1();
            }
            /*ClaimsIdentity? */ get Subject()
            {
                return this._subject;
            }
            /*string */ get Type()
            {
                return this._type;
            }
            /*string */ get Value()
            {
                return this._value;
            }
            /*string */ get ValueType()
            {
                return this._valueType;
            }
            /*Claim */ Clone()
            {
                return this.Clone$1(null);
            }
            /*Claim */ Clone$1(/*ClaimsIdentity?*/ identity)
            {
                return new $.$ssc.System.Security.Claims.Claim().$ctor$10(this, identity);
            }
            /*void */ WriteTo(/*BinaryWriter*/ writer)
            {
                this.WriteTo$1(writer, null);
            }
            /*void */ WriteTo$1(/*BinaryWriter*/ writer, /*byte[]?*/ userData)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(writer, "writer");
                /*int*/ let numberOfPropertiesWritten = 1;
                /*SerializationMask*/ let mask = 0/*SerializationMask.None*/;
                if ($.$spc.System.String.Equals$4(this._type, "http://schemas.xmlsoap.org/ws/2005/05/identity/claims/name"/*ClaimsIdentity.DefaultNameClaimType*/))
                {
                    mask |= 1/*SerializationMask.NameClaimType*/;
                }
                else if ($.$spc.System.String.Equals$4(this._type, "http://schemas.microsoft.com/ws/2008/06/identity/claims/role"/*ClaimsIdentity.DefaultRoleClaimType*/))
                {
                    mask |= 2/*SerializationMask.RoleClaimType*/;
                }
                else 
                {
                    numberOfPropertiesWritten++;
                }
                if (!$.$spc.System.String.Equals$5(this._valueType, "http://www.w3.org/2001/XMLSchema#string"/*ClaimValueTypes.String*/, 4/*StringComparison.Ordinal*/))
                {
                    numberOfPropertiesWritten++;
                    mask |= 4/*SerializationMask.StringType*/;
                }
                if (!$.$spc.System.String.Equals$5(this._issuer, "LOCAL AUTHORITY"/*ClaimsIdentity.DefaultIssuer*/, 4/*StringComparison.Ordinal*/))
                {
                    numberOfPropertiesWritten++;
                    mask |= 8/*SerializationMask.Issuer*/;
                }
                if ($.$spc.System.String.Equals$5(this._originalIssuer, this._issuer, 4/*StringComparison.Ordinal*/))
                {
                    mask |= 16/*SerializationMask.OriginalIssuerEqualsIssuer*/;
                }
                else if (!$.$spc.System.String.Equals$4(this._originalIssuer, "LOCAL AUTHORITY"/*ClaimsIdentity.DefaultIssuer*/))
                {
                    numberOfPropertiesWritten++;
                    mask |= 32/*SerializationMask.OriginalIssuer*/;
                }
                if (this._properties !== null && this._properties.Count > 0)
                {
                    numberOfPropertiesWritten++;
                    mask |= 64/*SerializationMask.HasProperties*/;
                }
                if (userData !== null && userData.length > 0)
                {
                    numberOfPropertiesWritten++;
                    mask |= 128/*SerializationMask.UserData*/;
                }
                writer.Write$12(mask);
                writer.Write$12(numberOfPropertiesWritten);
                writer.Write$18(this._value);
                if (((mask & 1/*SerializationMask.NameClaimType*/) !== 1/*SerializationMask.NameClaimType*/) && ((mask & 2/*SerializationMask.RoleClaimType*/) !== 2/*SerializationMask.RoleClaimType*/))
                {
                    writer.Write$18(this._type);
                }
                if ((mask & 4/*SerializationMask.StringType*/) === 4/*SerializationMask.StringType*/)
                {
                    writer.Write$18(this._valueType);
                }
                if ((mask & 8/*SerializationMask.Issuer*/) === 8/*SerializationMask.Issuer*/)
                {
                    writer.Write$18(this._issuer);
                }
                if ((mask & 32/*SerializationMask.OriginalIssuer*/) === 32/*SerializationMask.OriginalIssuer*/)
                {
                    writer.Write$18(this._originalIssuer);
                }
                if ((mask & 64/*SerializationMask.HasProperties*/) === 64/*SerializationMask.HasProperties*/)
                {
                    writer.Write$12(this._properties.Count);
                    var $en3 = this._properties.GetEnumerator();
                    while ($en3.MoveNext())
                    {
                        var kvp = $en3.Current;
                        {
                            writer.Write$18(kvp.Key);
                            writer.Write$18(kvp.Value);
                        }
                    }
                }
                if ((mask & 128/*SerializationMask.UserData*/) === 128/*SerializationMask.UserData*/)
                {
                    writer.Write$12(userData.length);
                    writer.Write$3(userData);
                }
                writer.Flush();
            }
            static/*conventional*/ /*string */ ToString()
            {
                return this._type + ": " + this._value;
            }
            //Static convention instance redirect
            /*string */ ToString() { return $.$ssc.System.Security.Claims.Claim.ToString.apply(this, arguments); }
            static $h = 175004;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":0,"g":{"r":0,"d":0,"h":90194488220,"f":132},"n":"CustomSerializationData","d":175004,"h":85899520924,"f":132},{"p":1310721,"g":{"r":0,"d":0,"h":98784422812,"f":1},"n":"Issuer","d":175004,"h":94489455516,"f":1},{"p":1310721,"g":{"r":0,"d":0,"h":107374357404,"f":1},"n":"OriginalIssuer","d":175004,"h":103079390108,"f":1},{"p":$.$spc.System.Collections.Generic.IDictionary$$$($.$spc.System.String, $.$spc.System.String).$h,"g":{"r":0,"d":0,"h":115964291996,"f":1},"n":"Properties","d":175004,"h":111669324700,"f":1},{"p":306076,"g":{"r":0,"d":0,"h":124554226588,"f":1},"n":"Subject","d":175004,"h":120259259292,"f":1},{"p":1310721,"g":{"r":0,"d":0,"h":133144161180,"f":1},"n":"Type","d":175004,"h":128849193884,"f":1},{"p":1310721,"g":{"r":0,"d":0,"h":141734095772,"f":1},"n":"Value","d":175004,"h":137439128476,"f":1},{"p":1310721,"g":{"r":0,"d":0,"h":150324030364,"f":1},"n":"ValueType","d":175004,"h":146029063068,"f":1}],"m":[{"r":175004,"n":"Clone","d":175004,"h":154618997660,"f":129},{"r":175004,"p":[{"n":"identity","p":306076}],"n":"Clone","o":"@$1","d":175004,"h":158913964956,"f":129},{"r":65537,"p":[{"n":"writer","p":58458113}],"n":"WriteTo","d":175004,"h":163208932252,"f":129},{"r":65537,"p":[{"n":"writer","p":58458113},{"n":"userData","p":0}],"n":"WriteTo","o":"@$1","d":175004,"h":167503899548,"f":132},{"r":1310721,"n":"ToString","d":175004,"h":171798866844,"f":32769}],"l":[{"t":0,"n":"_userSerializationData","d":175004,"h":8590109596,"f":2},{"t":1310721,"n":"_issuer","d":175004,"h":12885076892,"f":2},{"t":1310721,"n":"_originalIssuer","d":175004,"h":17180044188,"f":2},{"t":$.$spc.System.Collections.Generic.Dictionary$$$($.$spc.System.String, $.$spc.System.String).$h,"n":"_properties","d":175004,"h":21475011484,"f":2},{"t":306076,"n":"_subject","d":175004,"h":25769978780,"f":2},{"t":1310721,"n":"_type","d":175004,"h":30064946076,"f":2},{"t":1310721,"n":"_value","d":175004,"h":34359913372,"f":2},{"t":1310721,"n":"_valueType","d":175004,"h":38654880668,"f":2}],"c":[{"p":[{"n":"reader","p":58392577}],"n":".ctor","o":"$ctor$1","d":175004,"h":42949847964,"f":1},{"p":[{"n":"reader","p":58392577},{"n":"subject","p":306076}],"n":".ctor","o":"$ctor$2","d":175004,"h":47244815260,"f":1},{"p":[{"n":"type","p":1310721},{"n":"value","p":1310721}],"n":".ctor","o":"$ctor$3","d":175004,"h":51539782556,"f":1},{"p":[{"n":"type","p":1310721},{"n":"value","p":1310721},{"n":"valueType","p":1310721}],"n":".ctor","o":"$ctor$4","d":175004,"h":55834749852,"f":1},{"p":[{"n":"type","p":1310721},{"n":"value","p":1310721},{"n":"valueType","p":1310721},{"n":"issuer","p":1310721}],"n":".ctor","o":"$ctor$5","d":175004,"h":60129717148,"f":1},{"p":[{"n":"type","p":1310721},{"n":"value","p":1310721},{"n":"valueType","p":1310721},{"n":"issuer","p":1310721},{"n":"originalIssuer","p":1310721}],"n":".ctor","o":"$ctor$6","d":175004,"h":64424684444,"f":1},{"p":[{"n":"type","p":1310721},{"n":"value","p":1310721},{"n":"valueType","p":1310721},{"n":"issuer","p":1310721},{"n":"originalIssuer","p":1310721},{"n":"subject","p":306076}],"n":".ctor","o":"$ctor$7","d":175004,"h":68719651740,"f":1},{"p":[{"n":"type","p":1310721},{"n":"value","p":1310721},{"n":"valueType","p":1310721},{"n":"issuer","p":1310721},{"n":"originalIssuer","p":1310721},{"n":"subject","p":306076},{"n":"propertyKey","p":1310721},{"n":"propertyValue","p":1310721}],"n":".ctor","o":"$ctor$8","d":175004,"h":73014619036,"f":8},{"p":[{"n":"other","p":175004}],"n":".ctor","o":"$ctor$9","d":175004,"h":77309586332,"f":4},{"p":[{"n":"other","p":175004},{"n":"subject","p":306076}],"n":".ctor","o":"$ctor$10","d":175004,"h":81604553628,"f":4}],"j":[240540],"h":175004}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.Security.Claims.Claim`; }
        });
        
        $asm.$cls("$ssc.System.Obsoletions", ($self) => class Obsoletions
        {
            /*string*/ static SharedUrlFormat = null;
            /*string*/ static SystemTextEncodingUTF7Message = null;
            /*string*/ static SystemTextEncodingUTF7DiagId = null;
            /*string*/ static PrincipalPermissionAttributeMessage = null;
            /*string*/ static PrincipalPermissionAttributeDiagId = null;
            /*string*/ static CodeAccessSecurityMessage = null;
            /*string*/ static CodeAccessSecurityDiagId = null;
            /*string*/ static ConstrainedExecutionRegionMessage = null;
            /*string*/ static ConstrainedExecutionRegionDiagId = null;
            /*string*/ static GlobalAssemblyCacheMessage = null;
            /*string*/ static GlobalAssemblyCacheDiagId = null;
            /*string*/ static ThreadAbortMessage = null;
            /*string*/ static ThreadResetAbortMessage = null;
            /*string*/ static ThreadAbortDiagId = null;
            /*string*/ static DefaultCryptoAlgorithmsMessage = null;
            /*string*/ static DefaultCryptoAlgorithmsDiagId = null;
            /*string*/ static CreatePdbGeneratorMessage = null;
            /*string*/ static CreatePdbGeneratorDiagId = null;
            /*string*/ static AuthenticationManagerMessage = null;
            /*string*/ static AuthenticationManagerDiagId = null;
            /*string*/ static RemotingApisMessage = null;
            /*string*/ static RemotingApisDiagId = null;
            /*string*/ static BinaryFormatterMessage = null;
            /*string*/ static BinaryFormatterDiagId = null;
            /*string*/ static CodeBaseMessage = null;
            /*string*/ static CodeBaseDiagId = null;
            /*string*/ static EscapeUriStringMessage = null;
            /*string*/ static EscapeUriStringDiagId = null;
            /*string*/ static WebRequestMessage = null;
            /*string*/ static WebRequestDiagId = null;
            /*string*/ static DisablePrivateReflectionAttributeMessage = null;
            /*string*/ static DisablePrivateReflectionAttributeDiagId = null;
            /*string*/ static GetContextInfoMessage = null;
            /*string*/ static GetContextInfoDiagId = null;
            /*string*/ static StrongNameKeyPairMessage = null;
            /*string*/ static StrongNameKeyPairDiagId = null;
            /*string*/ static ReflectionOnlyLoadingMessage = null;
            /*string*/ static ReflectionOnlyLoadingDiagId = null;
            /*string*/ static RuntimeEnvironmentMessage = null;
            /*string*/ static RuntimeEnvironmentDiagId = null;
            /*string*/ static JsonSerializerOptionsIgnoreNullValuesMessage = null;
            /*string*/ static JsonSerializerOptionsIgnoreNullValuesDiagId = null;
            /*string*/ static DerivedCryptographicTypesMessage = null;
            /*string*/ static DerivedCryptographicTypesDiagId = null;
            /*string*/ static RijndaelMessage = null;
            /*string*/ static RijndaelDiagId = null;
            /*string*/ static RNGCryptoServiceProviderMessage = null;
            /*string*/ static RNGCryptoServiceProviderDiagId = null;
            /*string*/ static AppDomainCreateUnloadMessage = null;
            /*string*/ static AppDomainCreateUnloadDiagId = null;
            /*string*/ static SuppressIldasmAttributeMessage = null;
            /*string*/ static SuppressIldasmAttributeDiagId = null;
            /*string*/ static X509CertificateImmutableMessage = null;
            /*string*/ static X509CertificateImmutableDiagId = null;
            /*string*/ static PublicKeyPropertyMessage = null;
            /*string*/ static PublicKeyPropertyDiagId = null;
            /*string*/ static X509CertificatePrivateKeyMessage = null;
            /*string*/ static X509CertificatePrivateKeyDiagId = null;
            /*string*/ static ProduceLegacyHmacValuesMessage = null;
            /*string*/ static ProduceLegacyHmacValuesDiagId = null;
            /*string*/ static UseManagedSha1Message = null;
            /*string*/ static UseManagedSha1DiagId = null;
            /*string*/ static CryptoConfigEncodeOIDMessage = null;
            /*string*/ static CryptoConfigEncodeOIDDiagId = null;
            /*string*/ static CorruptedStateRecoveryMessage = null;
            /*string*/ static CorruptedStateRecoveryDiagId = null;
            /*string*/ static Rfc2898CryptDeriveKeyMessage = null;
            /*string*/ static Rfc2898CryptDeriveKeyDiagId = null;
            /*string*/ static CmsSignerCspParamsCtorMessage = null;
            /*string*/ static CmsSignerCspParamsCtorDiagId = null;
            /*string*/ static SignerInfoCounterSigMessage = null;
            /*string*/ static SignerInfoCounterSigDiagId = null;
            /*string*/ static RegexCompileToAssemblyMessage = null;
            /*string*/ static RegexCompileToAssemblyDiagId = null;
            /*string*/ static AssemblyNameMembersMessage = null;
            /*string*/ static AssemblyNameMembersDiagId = null;
            /*string*/ static SystemDataSerializationFormatBinaryMessage = null;
            /*string*/ static SystemDataSerializationFormatBinaryDiagId = null;
            /*string*/ static TlsVersion10and11Message = null;
            /*string*/ static TlsVersion10and11DiagId = null;
            /*string*/ static EncryptionPolicyMessage = null;
            /*string*/ static EncryptionPolicyDiagId = null;
            /*string*/ static EccXmlExportImportMessage = null;
            /*string*/ static EccXmlExportImportDiagId = null;
            /*string*/ static EcDhPublicKeyBlobMessage = null;
            /*string*/ static EcDhPublicKeyBlobDiagId = null;
            /*string*/ static AssemblyNameCodeBaseMessage = null;
            /*string*/ static AssemblyNameCodeBaseDiagId = null;
            /*string*/ static CryptoStringFactoryMessage = null;
            /*string*/ static CryptoStringFactoryDiagId = null;
            /*string*/ static ControlledExecutionRunMessage = null;
            /*string*/ static ControlledExecutionRunDiagId = null;
            /*string*/ static XmlSecureResolverMessage = null;
            /*string*/ static XmlSecureResolverDiagId = null;
            /*string*/ static RsaEncryptDecryptValueMessage = null;
            /*string*/ static RsaEncryptDecryptDiagId = null;
            /*string*/ static JsonSerializerOptionsAddContextMessage = null;
            /*string*/ static JsonSerializerOptionsAddContextDiagId = null;
            /*string*/ static LegacyFormatterMessage = null;
            /*string*/ static LegacyFormatterDiagId = null;
            /*string*/ static LegacyFormatterImplMessage = null;
            /*string*/ static LegacyFormatterImplDiagId = null;
            /*string*/ static RegexExtensibilityImplMessage = null;
            /*string*/ static RegexExtensibilityDiagId = null;
            /*string*/ static AesGcmTagConstructorMessage = null;
            /*string*/ static AesGcmTagConstructorDiagId = null;
            /*string*/ static ThreadVolatileReadWriteMessage = null;
            /*string*/ static ThreadVolatileReadWriteDiagId = null;
            /*string*/ static ArmIntrinsicPerformsUnsignedOperationMessage = null;
            /*string*/ static ArmIntrinsicPerformsUnsignedOperationDiagId = null;
            /*string*/ static LoadFromHashAlgorithmMessage = null;
            /*string*/ static LoadFromHashAlgorithmDiagId = null;
            /*string*/ static X509CtorCertDataObsoleteMessage = null;
            /*string*/ static X509CtorCertDataObsoleteDiagId = null;
            /*string*/ static TlsCipherAlgorithmEnumsMessage = null;
            /*string*/ static TlsCipherAlgorithmEnumsDiagId = null;
            /*string*/ static SystemEventsEventsThreadShutdownMessage = null;
            /*string*/ static SystemEventsEventsThreadShutdownDiagId = null;
            /*string*/ static Rfc2898DeriveBytesCtorMessage = null;
            /*string*/ static Rfc2898DeriveBytesCtorDiagId = null;
            /*string*/ static QueryableMinByMaxByTSourceObsoleteMessage = null;
            /*string*/ static QueryableMinByMaxByTSourceObsoleteDiagId = null;
            /*string*/ static XsltSettingsEnableScriptMessage = null;
            /*string*/ static XsltSettingsEnableScriptDiagId = null;
            //Static Initializer
            static $sinit()
            {
                {
                    this.SharedUrlFormat = "https://aka.ms/dotnet-warnings/{0}";
                }
                {
                    this.SystemTextEncodingUTF7Message = "The UTF-7 encoding is insecure and should not be used. Consider using UTF-8 instead.";
                }
                {
                    this.SystemTextEncodingUTF7DiagId = "SYSLIB0001";
                }
                {
                    this.PrincipalPermissionAttributeMessage = "PrincipalPermissionAttribute is not honored by the runtime and must not be used.";
                }
                {
                    this.PrincipalPermissionAttributeDiagId = "SYSLIB0002";
                }
                {
                    this.CodeAccessSecurityMessage = "Code Access Security is not supported or honored by the runtime.";
                }
                {
                    this.CodeAccessSecurityDiagId = "SYSLIB0003";
                }
                {
                    this.ConstrainedExecutionRegionMessage = "The Constrained Execution Region (CER) feature is not supported.";
                }
                {
                    this.ConstrainedExecutionRegionDiagId = "SYSLIB0004";
                }
                {
                    this.GlobalAssemblyCacheMessage = "The Global Assembly Cache is not supported.";
                }
                {
                    this.GlobalAssemblyCacheDiagId = "SYSLIB0005";
                }
                {
                    this.ThreadAbortMessage = "Thread.Abort is not supported and throws PlatformNotSupportedException.";
                }
                {
                    this.ThreadResetAbortMessage = "Thread.ResetAbort is not supported and throws PlatformNotSupportedException.";
                }
                {
                    this.ThreadAbortDiagId = "SYSLIB0006";
                }
                {
                    this.DefaultCryptoAlgorithmsMessage = "The default implementation of this cryptography algorithm is not supported.";
                }
                {
                    this.DefaultCryptoAlgorithmsDiagId = "SYSLIB0007";
                }
                {
                    this.CreatePdbGeneratorMessage = "The CreatePdbGenerator API is not supported and throws PlatformNotSupportedException.";
                }
                {
                    this.CreatePdbGeneratorDiagId = "SYSLIB0008";
                }
                {
                    this.AuthenticationManagerMessage = "AuthenticationManager is not supported. Methods will no-op or throw PlatformNotSupportedException.";
                }
                {
                    this.AuthenticationManagerDiagId = "SYSLIB0009";
                }
                {
                    this.RemotingApisMessage = "This Remoting API is not supported and throws PlatformNotSupportedException.";
                }
                {
                    this.RemotingApisDiagId = "SYSLIB0010";
                }
                {
                    this.BinaryFormatterMessage = "BinaryFormatter serialization is obsolete and should not be used. See https://aka.ms/binaryformatter for more information.";
                }
                {
                    this.BinaryFormatterDiagId = "SYSLIB0011";
                }
                {
                    this.CodeBaseMessage = "Assembly.CodeBase and Assembly.EscapedCodeBase are only included for .NET Framework compatibility. Use Assembly.Location instead.";
                }
                {
                    this.CodeBaseDiagId = "SYSLIB0012";
                }
                {
                    this.EscapeUriStringMessage = "Uri.EscapeUriString can corrupt the Uri string in some cases. Consider using Uri.EscapeDataString for query string components instead.";
                }
                {
                    this.EscapeUriStringDiagId = "SYSLIB0013";
                }
                {
                    this.WebRequestMessage = "WebRequest, HttpWebRequest, ServicePoint, and WebClient are obsolete. Use HttpClient instead.";
                }
                {
                    this.WebRequestDiagId = "SYSLIB0014";
                }
                {
                    this.DisablePrivateReflectionAttributeMessage = "DisablePrivateReflectionAttribute has no effect in .NET 6.0+.";
                }
                {
                    this.DisablePrivateReflectionAttributeDiagId = "SYSLIB0015";
                }
                {
                    this.GetContextInfoMessage = "Use the Graphics.GetContextInfo overloads that accept arguments for better performance and fewer allocations.";
                }
                {
                    this.GetContextInfoDiagId = "SYSLIB0016";
                }
                {
                    this.StrongNameKeyPairMessage = "Strong name signing is not supported and throws PlatformNotSupportedException.";
                }
                {
                    this.StrongNameKeyPairDiagId = "SYSLIB0017";
                }
                {
                    this.ReflectionOnlyLoadingMessage = "ReflectionOnly loading is not supported and throws PlatformNotSupportedException.";
                }
                {
                    this.ReflectionOnlyLoadingDiagId = "SYSLIB0018";
                }
                {
                    this.RuntimeEnvironmentMessage = "RuntimeEnvironment members SystemConfigurationFile, GetRuntimeInterfaceAsIntPtr, and GetRuntimeInterfaceAsObject are not supported and throw PlatformNotSupportedException.";
                }
                {
                    this.RuntimeEnvironmentDiagId = "SYSLIB0019";
                }
                {
                    this.JsonSerializerOptionsIgnoreNullValuesMessage = "JsonSerializerOptions.IgnoreNullValues is obsolete. To ignore null values when serializing, set DefaultIgnoreCondition to JsonIgnoreCondition.WhenWritingNull.";
                }
                {
                    this.JsonSerializerOptionsIgnoreNullValuesDiagId = "SYSLIB0020";
                }
                {
                    this.DerivedCryptographicTypesMessage = "Derived cryptographic types are obsolete. Use the Create method on the base type instead.";
                }
                {
                    this.DerivedCryptographicTypesDiagId = "SYSLIB0021";
                }
                {
                    this.RijndaelMessage = "The Rijndael and RijndaelManaged types are obsolete. Use Aes instead.";
                }
                {
                    this.RijndaelDiagId = "SYSLIB0022";
                }
                {
                    this.RNGCryptoServiceProviderMessage = "RNGCryptoServiceProvider is obsolete. To generate a random number, use one of the RandomNumberGenerator static methods instead.";
                }
                {
                    this.RNGCryptoServiceProviderDiagId = "SYSLIB0023";
                }
                {
                    this.AppDomainCreateUnloadMessage = "Creating and unloading AppDomains is not supported and throws an exception.";
                }
                {
                    this.AppDomainCreateUnloadDiagId = "SYSLIB0024";
                }
                {
                    this.SuppressIldasmAttributeMessage = "SuppressIldasmAttribute has no effect in .NET 6.0+.";
                }
                {
                    this.SuppressIldasmAttributeDiagId = "SYSLIB0025";
                }
                {
                    this.X509CertificateImmutableMessage = "X509Certificate and X509Certificate2 are immutable. Use X509CertificateLoader to create a new certificate.";
                }
                {
                    this.X509CertificateImmutableDiagId = "SYSLIB0026";
                }
                {
                    this.PublicKeyPropertyMessage = "PublicKey.Key is obsolete. Use the appropriate method to get the public key, such as GetRSAPublicKey.";
                }
                {
                    this.PublicKeyPropertyDiagId = "SYSLIB0027";
                }
                {
                    this.X509CertificatePrivateKeyMessage = "X509Certificate2.PrivateKey is obsolete. Use the appropriate method to get the private key, such as GetRSAPrivateKey, or use the CopyWithPrivateKey method to create a new instance with a private key.";
                }
                {
                    this.X509CertificatePrivateKeyDiagId = "SYSLIB0028";
                }
                {
                    this.ProduceLegacyHmacValuesMessage = "ProduceLegacyHmacValues is obsolete. Producing legacy HMAC values is not supported.";
                }
                {
                    this.ProduceLegacyHmacValuesDiagId = "SYSLIB0029";
                }
                {
                    this.UseManagedSha1Message = "HMACSHA1 always uses the algorithm implementation provided by the platform. Use a constructor without the useManagedSha1 parameter.";
                }
                {
                    this.UseManagedSha1DiagId = "SYSLIB0030";
                }
                {
                    this.CryptoConfigEncodeOIDMessage = "EncodeOID is obsolete. Use the ASN.1 functionality provided in System.Formats.Asn1.";
                }
                {
                    this.CryptoConfigEncodeOIDDiagId = "SYSLIB0031";
                }
                {
                    this.CorruptedStateRecoveryMessage = "Recovery from corrupted process state exceptions is not supported; HandleProcessCorruptedStateExceptionsAttribute is ignored.";
                }
                {
                    this.CorruptedStateRecoveryDiagId = "SYSLIB0032";
                }
                {
                    this.Rfc2898CryptDeriveKeyMessage = "Rfc2898DeriveBytes.CryptDeriveKey is obsolete and is not supported. Use PasswordDeriveBytes.CryptDeriveKey instead.";
                }
                {
                    this.Rfc2898CryptDeriveKeyDiagId = "SYSLIB0033";
                }
                {
                    this.CmsSignerCspParamsCtorMessage = "CmsSigner(CspParameters) is obsolete and is not supported. Use an alternative constructor instead.";
                }
                {
                    this.CmsSignerCspParamsCtorDiagId = "SYSLIB0034";
                }
                {
                    this.SignerInfoCounterSigMessage = "ComputeCounterSignature without specifying a CmsSigner is obsolete and is not supported. Use the overload that accepts a CmsSigner.";
                }
                {
                    this.SignerInfoCounterSigDiagId = "SYSLIB0035";
                }
                {
                    this.RegexCompileToAssemblyMessage = "Regex.CompileToAssembly is obsolete and not supported. Use the GeneratedRegexAttribute with the regular expression source generator instead.";
                }
                {
                    this.RegexCompileToAssemblyDiagId = "SYSLIB0036";
                }
                {
                    this.AssemblyNameMembersMessage = "AssemblyName members HashAlgorithm, ProcessorArchitecture, and VersionCompatibility are obsolete and not supported.";
                }
                {
                    this.AssemblyNameMembersDiagId = "SYSLIB0037";
                }
                {
                    this.SystemDataSerializationFormatBinaryMessage = "SerializationFormat.Binary is obsolete and should not be used. See https://aka.ms/serializationformat-binary-obsolete for more information.";
                }
                {
                    this.SystemDataSerializationFormatBinaryDiagId = "SYSLIB0038";
                }
                {
                    this.TlsVersion10and11Message = "TLS versions 1.0 and 1.1 have known vulnerabilities and are not recommended. Use a newer TLS version instead, or use SslProtocols.None to defer to OS defaults.";
                }
                {
                    this.TlsVersion10and11DiagId = "SYSLIB0039";
                }
                {
                    this.EncryptionPolicyMessage = "EncryptionPolicy.NoEncryption and AllowEncryption significantly reduce security and should not be used in production code.";
                }
                {
                    this.EncryptionPolicyDiagId = "SYSLIB0040";
                }
                {
                    this.EccXmlExportImportMessage = "ToXmlString and FromXmlString have no implementation for ECC types, and are obsolete. Use a standard import and export format such as ExportSubjectPublicKeyInfo or ImportSubjectPublicKeyInfo for public keys and ExportPkcs8PrivateKey or ImportPkcs8PrivateKey for private keys.";
                }
                {
                    this.EccXmlExportImportDiagId = "SYSLIB0042";
                }
                {
                    this.EcDhPublicKeyBlobMessage = "ECDiffieHellmanPublicKey.ToByteArray() and the associated constructor do not have a consistent and interoperable implementation on all platforms. Use ECDiffieHellmanPublicKey.ExportSubjectPublicKeyInfo() instead.";
                }
                {
                    this.EcDhPublicKeyBlobDiagId = "SYSLIB0043";
                }
                {
                    this.AssemblyNameCodeBaseMessage = "AssemblyName.CodeBase and AssemblyName.EscapedCodeBase are obsolete. Using them for loading an assembly is not supported.";
                }
                {
                    this.AssemblyNameCodeBaseDiagId = "SYSLIB0044";
                }
                {
                    this.CryptoStringFactoryMessage = "Cryptographic factory methods accepting an algorithm name are obsolete. Use the parameterless Create factory method on the algorithm type instead.";
                }
                {
                    this.CryptoStringFactoryDiagId = "SYSLIB0045";
                }
                {
                    this.ControlledExecutionRunMessage = "ControlledExecution.Run method may corrupt the process and should not be used in production code.";
                }
                {
                    this.ControlledExecutionRunDiagId = "SYSLIB0046";
                }
                {
                    this.XmlSecureResolverMessage = "XmlSecureResolver is obsolete. Use XmlResolver.ThrowingResolver instead when attempting to forbid XML external entity resolution.";
                }
                {
                    this.XmlSecureResolverDiagId = "SYSLIB0047";
                }
                {
                    this.RsaEncryptDecryptValueMessage = "RSA.EncryptValue and DecryptValue are not supported and throw NotSupportedException. Use RSA.Encrypt and RSA.Decrypt instead.";
                }
                {
                    this.RsaEncryptDecryptDiagId = "SYSLIB0048";
                }
                {
                    this.JsonSerializerOptionsAddContextMessage = "JsonSerializerOptions.AddContext is obsolete. To register a JsonSerializerContext, use either the TypeInfoResolver or TypeInfoResolverChain properties.";
                }
                {
                    this.JsonSerializerOptionsAddContextDiagId = "SYSLIB0049";
                }
                {
                    this.LegacyFormatterMessage = "Formatter-based serialization is obsolete and should not be used.";
                }
                {
                    this.LegacyFormatterDiagId = "SYSLIB0050";
                }
                {
                    this.LegacyFormatterImplMessage = "This API supports obsolete formatter-based serialization. It should not be called or extended by application code.";
                }
                {
                    this.LegacyFormatterImplDiagId = "SYSLIB0051";
                }
                {
                    this.RegexExtensibilityImplMessage = "This API supports obsolete mechanisms for Regex extensibility. It is not supported.";
                }
                {
                    this.RegexExtensibilityDiagId = "SYSLIB0052";
                }
                {
                    this.AesGcmTagConstructorMessage = "AesGcm should indicate the required tag size for encryption and decryption. Use a constructor that accepts the tag size.";
                }
                {
                    this.AesGcmTagConstructorDiagId = "SYSLIB0053";
                }
                {
                    this.ThreadVolatileReadWriteMessage = "Thread.VolatileRead and Thread.VolatileWrite are obsolete. Use Volatile.Read or Volatile.Write respectively instead.";
                }
                {
                    this.ThreadVolatileReadWriteDiagId = "SYSLIB0054";
                }
                {
                    this.ArmIntrinsicPerformsUnsignedOperationMessage = "The underlying hardware instruction does not perform a signed saturate narrowing operation, and it always returns an unsigned result. Use the unsigned overload instead.";
                }
                {
                    this.ArmIntrinsicPerformsUnsignedOperationDiagId = "SYSLIB0055";
                }
                {
                    this.LoadFromHashAlgorithmMessage = "LoadFrom with a custom AssemblyHashAlgorithm is obsolete. Use overloads without an AssemblyHashAlgorithm.";
                }
                {
                    this.LoadFromHashAlgorithmDiagId = "SYSLIB0056";
                }
                {
                    this.X509CtorCertDataObsoleteMessage = "Loading certificate data through the constructor or Import is obsolete. Use X509CertificateLoader instead to load certificates.";
                }
                {
                    this.X509CtorCertDataObsoleteDiagId = "SYSLIB0057";
                }
                {
                    this.TlsCipherAlgorithmEnumsMessage = "KeyExchangeAlgorithm, KeyExchangeStrength, CipherAlgorithm, CipherStrength, HashAlgorithm and HashStrength properties of SslStream are obsolete. Use NegotiatedCipherSuite instead.";
                }
                {
                    this.TlsCipherAlgorithmEnumsDiagId = "SYSLIB0058";
                }
                {
                    this.SystemEventsEventsThreadShutdownMessage = "SystemEvents.EventsThreadShutdown callbacks are not run before the process exits. Use AppDomain.ProcessExit instead.";
                }
                {
                    this.SystemEventsEventsThreadShutdownDiagId = "SYSLIB0059";
                }
                {
                    this.Rfc2898DeriveBytesCtorMessage = "The constructors on Rfc2898DeriveBytes are obsolete. Use the static Pbkdf2 method instead.";
                }
                {
                    this.Rfc2898DeriveBytesCtorDiagId = "SYSLIB0060";
                }
                {
                    this.QueryableMinByMaxByTSourceObsoleteMessage = "The Queryable MinBy and MaxBy taking an IComparer<TSource> are obsolete. Use the new ones that take an IComparer<TKey>.";
                }
                {
                    this.QueryableMinByMaxByTSourceObsoleteDiagId = "SYSLIB0061";
                }
                {
                    this.XsltSettingsEnableScriptMessage = "XSLT Script blocks are not supported.";
                }
                {
                    this.XsltSettingsEnableScriptDiagId = "SYSLIB0062";
                }
            }
            static $h = 109468;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"l":[{"t":1310721,"n":"SharedUrlFormat","d":109468,"h":4295076764,"f":40},{"t":1310721,"n":"SystemTextEncodingUTF7Message","d":109468,"h":8590044060,"f":40},{"t":1310721,"n":"SystemTextEncodingUTF7DiagId","d":109468,"h":12885011356,"f":40},{"t":1310721,"n":"PrincipalPermissionAttributeMessage","d":109468,"h":17179978652,"f":40},{"t":1310721,"n":"PrincipalPermissionAttributeDiagId","d":109468,"h":21474945948,"f":40},{"t":1310721,"n":"CodeAccessSecurityMessage","d":109468,"h":25769913244,"f":40},{"t":1310721,"n":"CodeAccessSecurityDiagId","d":109468,"h":30064880540,"f":40},{"t":1310721,"n":"ConstrainedExecutionRegionMessage","d":109468,"h":34359847836,"f":40},{"t":1310721,"n":"ConstrainedExecutionRegionDiagId","d":109468,"h":38654815132,"f":40},{"t":1310721,"n":"GlobalAssemblyCacheMessage","d":109468,"h":42949782428,"f":40},{"t":1310721,"n":"GlobalAssemblyCacheDiagId","d":109468,"h":47244749724,"f":40},{"t":1310721,"n":"ThreadAbortMessage","d":109468,"h":51539717020,"f":40},{"t":1310721,"n":"ThreadResetAbortMessage","d":109468,"h":55834684316,"f":40},{"t":1310721,"n":"ThreadAbortDiagId","d":109468,"h":60129651612,"f":40},{"t":1310721,"n":"DefaultCryptoAlgorithmsMessage","d":109468,"h":64424618908,"f":40},{"t":1310721,"n":"DefaultCryptoAlgorithmsDiagId","d":109468,"h":68719586204,"f":40},{"t":1310721,"n":"CreatePdbGeneratorMessage","d":109468,"h":73014553500,"f":40},{"t":1310721,"n":"CreatePdbGeneratorDiagId","d":109468,"h":77309520796,"f":40},{"t":1310721,"n":"AuthenticationManagerMessage","d":109468,"h":81604488092,"f":40},{"t":1310721,"n":"AuthenticationManagerDiagId","d":109468,"h":85899455388,"f":40},{"t":1310721,"n":"RemotingApisMessage","d":109468,"h":90194422684,"f":40},{"t":1310721,"n":"RemotingApisDiagId","d":109468,"h":94489389980,"f":40},{"t":1310721,"n":"BinaryFormatterMessage","d":109468,"h":98784357276,"f":40},{"t":1310721,"n":"BinaryFormatterDiagId","d":109468,"h":103079324572,"f":40},{"t":1310721,"n":"CodeBaseMessage","d":109468,"h":107374291868,"f":40},{"t":1310721,"n":"CodeBaseDiagId","d":109468,"h":111669259164,"f":40},{"t":1310721,"n":"EscapeUriStringMessage","d":109468,"h":115964226460,"f":40},{"t":1310721,"n":"EscapeUriStringDiagId","d":109468,"h":120259193756,"f":40},{"t":1310721,"n":"WebRequestMessage","d":109468,"h":124554161052,"f":40},{"t":1310721,"n":"WebRequestDiagId","d":109468,"h":128849128348,"f":40},{"t":1310721,"n":"DisablePrivateReflectionAttributeMessage","d":109468,"h":133144095644,"f":40},{"t":1310721,"n":"DisablePrivateReflectionAttributeDiagId","d":109468,"h":137439062940,"f":40},{"t":1310721,"n":"GetContextInfoMessage","d":109468,"h":141734030236,"f":40},{"t":1310721,"n":"GetContextInfoDiagId","d":109468,"h":146028997532,"f":40},{"t":1310721,"n":"StrongNameKeyPairMessage","d":109468,"h":150323964828,"f":40},{"t":1310721,"n":"StrongNameKeyPairDiagId","d":109468,"h":154618932124,"f":40},{"t":1310721,"n":"ReflectionOnlyLoadingMessage","d":109468,"h":158913899420,"f":40},{"t":1310721,"n":"ReflectionOnlyLoadingDiagId","d":109468,"h":163208866716,"f":40},{"t":1310721,"n":"RuntimeEnvironmentMessage","d":109468,"h":167503834012,"f":40},{"t":1310721,"n":"RuntimeEnvironmentDiagId","d":109468,"h":171798801308,"f":40},{"t":1310721,"n":"JsonSerializerOptionsIgnoreNullValuesMessage","d":109468,"h":176093768604,"f":40},{"t":1310721,"n":"JsonSerializerOptionsIgnoreNullValuesDiagId","d":109468,"h":180388735900,"f":40},{"t":1310721,"n":"DerivedCryptographicTypesMessage","d":109468,"h":184683703196,"f":40},{"t":1310721,"n":"DerivedCryptographicTypesDiagId","d":109468,"h":188978670492,"f":40},{"t":1310721,"n":"RijndaelMessage","d":109468,"h":193273637788,"f":40},{"t":1310721,"n":"RijndaelDiagId","d":109468,"h":197568605084,"f":40},{"t":1310721,"n":"RNGCryptoServiceProviderMessage","d":109468,"h":201863572380,"f":40},{"t":1310721,"n":"RNGCryptoServiceProviderDiagId","d":109468,"h":206158539676,"f":40},{"t":1310721,"n":"AppDomainCreateUnloadMessage","d":109468,"h":210453506972,"f":40},{"t":1310721,"n":"AppDomainCreateUnloadDiagId","d":109468,"h":214748474268,"f":40},{"t":1310721,"n":"SuppressIldasmAttributeMessage","d":109468,"h":219043441564,"f":40},{"t":1310721,"n":"SuppressIldasmAttributeDiagId","d":109468,"h":223338408860,"f":40},{"t":1310721,"n":"X509CertificateImmutableMessage","d":109468,"h":227633376156,"f":40},{"t":1310721,"n":"X509CertificateImmutableDiagId","d":109468,"h":231928343452,"f":40},{"t":1310721,"n":"PublicKeyPropertyMessage","d":109468,"h":236223310748,"f":40},{"t":1310721,"n":"PublicKeyPropertyDiagId","d":109468,"h":240518278044,"f":40},{"t":1310721,"n":"X509CertificatePrivateKeyMessage","d":109468,"h":244813245340,"f":40},{"t":1310721,"n":"X509CertificatePrivateKeyDiagId","d":109468,"h":249108212636,"f":40},{"t":1310721,"n":"ProduceLegacyHmacValuesMessage","d":109468,"h":253403179932,"f":40},{"t":1310721,"n":"ProduceLegacyHmacValuesDiagId","d":109468,"h":257698147228,"f":40},{"t":1310721,"n":"UseManagedSha1Message","d":109468,"h":261993114524,"f":40},{"t":1310721,"n":"UseManagedSha1DiagId","d":109468,"h":266288081820,"f":40},{"t":1310721,"n":"CryptoConfigEncodeOIDMessage","d":109468,"h":270583049116,"f":40},{"t":1310721,"n":"CryptoConfigEncodeOIDDiagId","d":109468,"h":274878016412,"f":40},{"t":1310721,"n":"CorruptedStateRecoveryMessage","d":109468,"h":279172983708,"f":40},{"t":1310721,"n":"CorruptedStateRecoveryDiagId","d":109468,"h":283467951004,"f":40},{"t":1310721,"n":"Rfc2898CryptDeriveKeyMessage","d":109468,"h":287762918300,"f":40},{"t":1310721,"n":"Rfc2898CryptDeriveKeyDiagId","d":109468,"h":292057885596,"f":40},{"t":1310721,"n":"CmsSignerCspParamsCtorMessage","d":109468,"h":296352852892,"f":40},{"t":1310721,"n":"CmsSignerCspParamsCtorDiagId","d":109468,"h":300647820188,"f":40},{"t":1310721,"n":"SignerInfoCounterSigMessage","d":109468,"h":304942787484,"f":40},{"t":1310721,"n":"SignerInfoCounterSigDiagId","d":109468,"h":309237754780,"f":40},{"t":1310721,"n":"RegexCompileToAssemblyMessage","d":109468,"h":313532722076,"f":40},{"t":1310721,"n":"RegexCompileToAssemblyDiagId","d":109468,"h":317827689372,"f":40},{"t":1310721,"n":"AssemblyNameMembersMessage","d":109468,"h":322122656668,"f":40},{"t":1310721,"n":"AssemblyNameMembersDiagId","d":109468,"h":326417623964,"f":40},{"t":1310721,"n":"SystemDataSerializationFormatBinaryMessage","d":109468,"h":330712591260,"f":40},{"t":1310721,"n":"SystemDataSerializationFormatBinaryDiagId","d":109468,"h":335007558556,"f":40},{"t":1310721,"n":"TlsVersion10and11Message","d":109468,"h":339302525852,"f":40},{"t":1310721,"n":"TlsVersion10and11DiagId","d":109468,"h":343597493148,"f":40},{"t":1310721,"n":"EncryptionPolicyMessage","d":109468,"h":347892460444,"f":40},{"t":1310721,"n":"EncryptionPolicyDiagId","d":109468,"h":352187427740,"f":40},{"t":1310721,"n":"EccXmlExportImportMessage","d":109468,"h":356482395036,"f":40},{"t":1310721,"n":"EccXmlExportImportDiagId","d":109468,"h":360777362332,"f":40},{"t":1310721,"n":"EcDhPublicKeyBlobMessage","d":109468,"h":365072329628,"f":40},{"t":1310721,"n":"EcDhPublicKeyBlobDiagId","d":109468,"h":369367296924,"f":40},{"t":1310721,"n":"AssemblyNameCodeBaseMessage","d":109468,"h":373662264220,"f":40},{"t":1310721,"n":"AssemblyNameCodeBaseDiagId","d":109468,"h":377957231516,"f":40},{"t":1310721,"n":"CryptoStringFactoryMessage","d":109468,"h":382252198812,"f":40},{"t":1310721,"n":"CryptoStringFactoryDiagId","d":109468,"h":386547166108,"f":40},{"t":1310721,"n":"ControlledExecutionRunMessage","d":109468,"h":390842133404,"f":40},{"t":1310721,"n":"ControlledExecutionRunDiagId","d":109468,"h":395137100700,"f":40},{"t":1310721,"n":"XmlSecureResolverMessage","d":109468,"h":399432067996,"f":40},{"t":1310721,"n":"XmlSecureResolverDiagId","d":109468,"h":403727035292,"f":40},{"t":1310721,"n":"RsaEncryptDecryptValueMessage","d":109468,"h":408022002588,"f":40},{"t":1310721,"n":"RsaEncryptDecryptDiagId","d":109468,"h":412316969884,"f":40},{"t":1310721,"n":"JsonSerializerOptionsAddContextMessage","d":109468,"h":416611937180,"f":40},{"t":1310721,"n":"JsonSerializerOptionsAddContextDiagId","d":109468,"h":420906904476,"f":40},{"t":1310721,"n":"LegacyFormatterMessage","d":109468,"h":425201871772,"f":40},{"t":1310721,"n":"LegacyFormatterDiagId","d":109468,"h":429496839068,"f":40},{"t":1310721,"n":"LegacyFormatterImplMessage","d":109468,"h":433791806364,"f":40},{"t":1310721,"n":"LegacyFormatterImplDiagId","d":109468,"h":438086773660,"f":40},{"t":1310721,"n":"RegexExtensibilityImplMessage","d":109468,"h":442381740956,"f":40},{"t":1310721,"n":"RegexExtensibilityDiagId","d":109468,"h":446676708252,"f":40},{"t":1310721,"n":"AesGcmTagConstructorMessage","d":109468,"h":450971675548,"f":40},{"t":1310721,"n":"AesGcmTagConstructorDiagId","d":109468,"h":455266642844,"f":40},{"t":1310721,"n":"ThreadVolatileReadWriteMessage","d":109468,"h":459561610140,"f":40},{"t":1310721,"n":"ThreadVolatileReadWriteDiagId","d":109468,"h":463856577436,"f":40},{"t":1310721,"n":"ArmIntrinsicPerformsUnsignedOperationMessage","d":109468,"h":468151544732,"f":40},{"t":1310721,"n":"ArmIntrinsicPerformsUnsignedOperationDiagId","d":109468,"h":472446512028,"f":40},{"t":1310721,"n":"LoadFromHashAlgorithmMessage","d":109468,"h":476741479324,"f":40},{"t":1310721,"n":"LoadFromHashAlgorithmDiagId","d":109468,"h":481036446620,"f":40},{"t":1310721,"n":"X509CtorCertDataObsoleteMessage","d":109468,"h":485331413916,"f":40},{"t":1310721,"n":"X509CtorCertDataObsoleteDiagId","d":109468,"h":489626381212,"f":40},{"t":1310721,"n":"TlsCipherAlgorithmEnumsMessage","d":109468,"h":493921348508,"f":40},{"t":1310721,"n":"TlsCipherAlgorithmEnumsDiagId","d":109468,"h":498216315804,"f":40},{"t":1310721,"n":"SystemEventsEventsThreadShutdownMessage","d":109468,"h":502511283100,"f":40},{"t":1310721,"n":"SystemEventsEventsThreadShutdownDiagId","d":109468,"h":506806250396,"f":40},{"t":1310721,"n":"Rfc2898DeriveBytesCtorMessage","d":109468,"h":511101217692,"f":40},{"t":1310721,"n":"Rfc2898DeriveBytesCtorDiagId","d":109468,"h":515396184988,"f":40},{"t":1310721,"n":"QueryableMinByMaxByTSourceObsoleteMessage","d":109468,"h":519691152284,"f":40},{"t":1310721,"n":"QueryableMinByMaxByTSourceObsoleteDiagId","d":109468,"h":523986119580,"f":40},{"t":1310721,"n":"XsltSettingsEnableScriptMessage","d":109468,"h":528281086876,"f":40},{"t":1310721,"n":"XsltSettingsEnableScriptDiagId","d":109468,"h":532576054172,"f":40}],"h":109468}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.Obsoletions`; }
        });
        
        $asm.$cls("$ssc.System.Security.Claims.ClaimValueTypes", ($self) => class ClaimValueTypes
        {
            /*string*/ static XmlSchemaNamespace = null;
            /*string*/ static Base64Binary = null;
            /*string*/ static Base64Octet = null;
            /*string*/ static Boolean = null;
            /*string*/ static Date = null;
            /*string*/ static DateTime = null;
            /*string*/ static Double = null;
            /*string*/ static Fqbn = null;
            /*string*/ static HexBinary = null;
            /*string*/ static Integer = null;
            /*string*/ static Integer32 = null;
            /*string*/ static Integer64 = null;
            /*string*/ static Sid = null;
            /*string*/ static String = null;
            /*string*/ static Time = null;
            /*string*/ static UInteger32 = null;
            /*string*/ static UInteger64 = null;
            /*string*/ static SoapSchemaNamespace = null;
            /*string*/ static DnsName = null;
            /*string*/ static Email = null;
            /*string*/ static Rsa = null;
            /*string*/ static UpnName = null;
            /*string*/ static XmlSignatureConstantsNamespace = null;
            /*string*/ static DsaKeyValue = null;
            /*string*/ static KeyInfo = null;
            /*string*/ static RsaKeyValue = null;
            /*string*/ static XQueryOperatorsNameSpace = null;
            /*string*/ static DaytimeDuration = null;
            /*string*/ static YearMonthDuration = null;
            /*string*/ static Xacml10Namespace = null;
            /*string*/ static Rfc822Name = null;
            /*string*/ static X500Name = null;
            //Static Initializer
            static $sinit()
            {
                {
                    this.XmlSchemaNamespace = "http://www.w3.org/2001/XMLSchema";
                }
                {
                    this.Base64Binary = "http://www.w3.org/2001/XMLSchema#base64Binary";
                }
                {
                    this.Base64Octet = "http://www.w3.org/2001/XMLSchema#base64Octet";
                }
                {
                    this.Boolean = "http://www.w3.org/2001/XMLSchema#boolean";
                }
                {
                    this.Date = "http://www.w3.org/2001/XMLSchema#date";
                }
                {
                    this.DateTime = "http://www.w3.org/2001/XMLSchema#dateTime";
                }
                {
                    this.Double = "http://www.w3.org/2001/XMLSchema#double";
                }
                {
                    this.Fqbn = "http://www.w3.org/2001/XMLSchema#fqbn";
                }
                {
                    this.HexBinary = "http://www.w3.org/2001/XMLSchema#hexBinary";
                }
                {
                    this.Integer = "http://www.w3.org/2001/XMLSchema#integer";
                }
                {
                    this.Integer32 = "http://www.w3.org/2001/XMLSchema#integer32";
                }
                {
                    this.Integer64 = "http://www.w3.org/2001/XMLSchema#integer64";
                }
                {
                    this.Sid = "http://www.w3.org/2001/XMLSchema#sid";
                }
                {
                    this.String = "http://www.w3.org/2001/XMLSchema#string";
                }
                {
                    this.Time = "http://www.w3.org/2001/XMLSchema#time";
                }
                {
                    this.UInteger32 = "http://www.w3.org/2001/XMLSchema#uinteger32";
                }
                {
                    this.UInteger64 = "http://www.w3.org/2001/XMLSchema#uinteger64";
                }
                {
                    this.SoapSchemaNamespace = "http://schemas.xmlsoap.org/";
                }
                {
                    this.DnsName = "http://schemas.xmlsoap.org/claims/dns";
                }
                {
                    this.Email = "http://schemas.xmlsoap.org/ws/2005/05/identity/claims/emailaddress";
                }
                {
                    this.Rsa = "http://schemas.xmlsoap.org/ws/2005/05/identity/claims/rsa";
                }
                {
                    this.UpnName = "http://schemas.xmlsoap.org/claims/UPN";
                }
                {
                    this.XmlSignatureConstantsNamespace = "http://www.w3.org/2000/09/xmldsig#";
                }
                {
                    this.DsaKeyValue = "http://www.w3.org/2000/09/xmldsig#DSAKeyValue";
                }
                {
                    this.KeyInfo = "http://www.w3.org/2000/09/xmldsig#KeyInfo";
                }
                {
                    this.RsaKeyValue = "http://www.w3.org/2000/09/xmldsig#RSAKeyValue";
                }
                {
                    this.XQueryOperatorsNameSpace = "http://www.w3.org/TR/2002/WD-xquery-operators-20020816";
                }
                {
                    this.DaytimeDuration = "http://www.w3.org/TR/2002/WD-xquery-operators-20020816#dayTimeDuration";
                }
                {
                    this.YearMonthDuration = "http://www.w3.org/TR/2002/WD-xquery-operators-20020816#yearMonthDuration";
                }
                {
                    this.Xacml10Namespace = "urn:oasis:names:tc:xacml:1.0";
                }
                {
                    this.Rfc822Name = "urn:oasis:names:tc:xacml:1.0:data-type:rfc822Name";
                }
                {
                    this.X500Name = "urn:oasis:names:tc:xacml:1.0:data-type:x500Name";
                }
            }
            static $h = 633756;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"l":[{"t":1310721,"n":"XmlSchemaNamespace","d":633756,"h":4295601052,"f":34},{"t":1310721,"n":"Base64Binary","d":633756,"h":8590568348,"f":33},{"t":1310721,"n":"Base64Octet","d":633756,"h":12885535644,"f":33},{"t":1310721,"n":"Boolean","d":633756,"h":17180502940,"f":33},{"t":1310721,"n":"Date","d":633756,"h":21475470236,"f":33},{"t":1310721,"n":"DateTime","d":633756,"h":25770437532,"f":33},{"t":1310721,"n":"Double","d":633756,"h":30065404828,"f":33},{"t":1310721,"n":"Fqbn","d":633756,"h":34360372124,"f":33},{"t":1310721,"n":"HexBinary","d":633756,"h":38655339420,"f":33},{"t":1310721,"n":"Integer","d":633756,"h":42950306716,"f":33},{"t":1310721,"n":"Integer32","d":633756,"h":47245274012,"f":33},{"t":1310721,"n":"Integer64","d":633756,"h":51540241308,"f":33},{"t":1310721,"n":"Sid","d":633756,"h":55835208604,"f":33},{"t":1310721,"n":"String","d":633756,"h":60130175900,"f":33},{"t":1310721,"n":"Time","d":633756,"h":64425143196,"f":33},{"t":1310721,"n":"UInteger32","d":633756,"h":68720110492,"f":33},{"t":1310721,"n":"UInteger64","d":633756,"h":73015077788,"f":33},{"t":1310721,"n":"SoapSchemaNamespace","d":633756,"h":77310045084,"f":34},{"t":1310721,"n":"DnsName","d":633756,"h":81605012380,"f":33},{"t":1310721,"n":"Email","d":633756,"h":85899979676,"f":33},{"t":1310721,"n":"Rsa","d":633756,"h":90194946972,"f":33},{"t":1310721,"n":"UpnName","d":633756,"h":94489914268,"f":33},{"t":1310721,"n":"XmlSignatureConstantsNamespace","d":633756,"h":98784881564,"f":34},{"t":1310721,"n":"DsaKeyValue","d":633756,"h":103079848860,"f":33},{"t":1310721,"n":"KeyInfo","d":633756,"h":107374816156,"f":33},{"t":1310721,"n":"RsaKeyValue","d":633756,"h":111669783452,"f":33},{"t":1310721,"n":"XQueryOperatorsNameSpace","d":633756,"h":115964750748,"f":34},{"t":1310721,"n":"DaytimeDuration","d":633756,"h":120259718044,"f":33},{"t":1310721,"n":"YearMonthDuration","d":633756,"h":124554685340,"f":33},{"t":1310721,"n":"Xacml10Namespace","d":633756,"h":128849652636,"f":34},{"t":1310721,"n":"Rfc822Name","d":633756,"h":133144619932,"f":33},{"t":1310721,"n":"X500Name","d":633756,"h":137439587228,"f":33}],"h":633756}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.Security.Claims.ClaimValueTypes`; }
        });
        
        $asm.$cls("$ssc.System.Security.Claims.ClaimTypes", ($self) => class ClaimTypes
        {
            /*string*/ static ClaimTypeNamespace = null;
            /*string*/ static AuthenticationInstant = null;
            /*string*/ static AuthenticationMethod = null;
            /*string*/ static CookiePath = null;
            /*string*/ static DenyOnlyPrimarySid = null;
            /*string*/ static DenyOnlyPrimaryGroupSid = null;
            /*string*/ static DenyOnlyWindowsDeviceGroup = null;
            /*string*/ static Dsa = null;
            /*string*/ static Expiration = null;
            /*string*/ static Expired = null;
            /*string*/ static GroupSid = null;
            /*string*/ static IsPersistent = null;
            /*string*/ static PrimaryGroupSid = null;
            /*string*/ static PrimarySid = null;
            /*string*/ static Role = null;
            /*string*/ static SerialNumber = null;
            /*string*/ static UserData = null;
            /*string*/ static Version = null;
            /*string*/ static WindowsAccountName = null;
            /*string*/ static WindowsDeviceClaim = null;
            /*string*/ static WindowsDeviceGroup = null;
            /*string*/ static WindowsUserClaim = null;
            /*string*/ static WindowsFqbnVersion = null;
            /*string*/ static WindowsSubAuthority = null;
            /*string*/ static ClaimType2005Namespace = null;
            /*string*/ static Anonymous = null;
            /*string*/ static Authentication = null;
            /*string*/ static AuthorizationDecision = null;
            /*string*/ static Country = null;
            /*string*/ static DateOfBirth = null;
            /*string*/ static Dns = null;
            /*string*/ static DenyOnlySid = null;
            /*string*/ static Email = null;
            /*string*/ static Gender = null;
            /*string*/ static GivenName = null;
            /*string*/ static Hash = null;
            /*string*/ static HomePhone = null;
            /*string*/ static Locality = null;
            /*string*/ static MobilePhone = null;
            /*string*/ static Name = null;
            /*string*/ static NameIdentifier = null;
            /*string*/ static OtherPhone = null;
            /*string*/ static PostalCode = null;
            /*string*/ static Rsa = null;
            /*string*/ static Sid = null;
            /*string*/ static Spn = null;
            /*string*/ static StateOrProvince = null;
            /*string*/ static StreetAddress = null;
            /*string*/ static Surname = null;
            /*string*/ static System = null;
            /*string*/ static Thumbprint = null;
            /*string*/ static Upn = null;
            /*string*/ static Uri = null;
            /*string*/ static Webpage = null;
            /*string*/ static X500DistinguishedName = null;
            /*string*/ static ClaimType2009Namespace = null;
            /*string*/ static Actor = null;
            //Static Initializer
            static $sinit()
            {
                {
                    this.ClaimTypeNamespace = "http://schemas.microsoft.com/ws/2008/06/identity/claims";
                }
                {
                    this.AuthenticationInstant = "http://schemas.microsoft.com/ws/2008/06/identity/claims/authenticationinstant";
                }
                {
                    this.AuthenticationMethod = "http://schemas.microsoft.com/ws/2008/06/identity/claims/authenticationmethod";
                }
                {
                    this.CookiePath = "http://schemas.microsoft.com/ws/2008/06/identity/claims/cookiepath";
                }
                {
                    this.DenyOnlyPrimarySid = "http://schemas.microsoft.com/ws/2008/06/identity/claims/denyonlyprimarysid";
                }
                {
                    this.DenyOnlyPrimaryGroupSid = "http://schemas.microsoft.com/ws/2008/06/identity/claims/denyonlyprimarygroupsid";
                }
                {
                    this.DenyOnlyWindowsDeviceGroup = "http://schemas.microsoft.com/ws/2008/06/identity/claims/denyonlywindowsdevicegroup";
                }
                {
                    this.Dsa = "http://schemas.microsoft.com/ws/2008/06/identity/claims/dsa";
                }
                {
                    this.Expiration = "http://schemas.microsoft.com/ws/2008/06/identity/claims/expiration";
                }
                {
                    this.Expired = "http://schemas.microsoft.com/ws/2008/06/identity/claims/expired";
                }
                {
                    this.GroupSid = "http://schemas.microsoft.com/ws/2008/06/identity/claims/groupsid";
                }
                {
                    this.IsPersistent = "http://schemas.microsoft.com/ws/2008/06/identity/claims/ispersistent";
                }
                {
                    this.PrimaryGroupSid = "http://schemas.microsoft.com/ws/2008/06/identity/claims/primarygroupsid";
                }
                {
                    this.PrimarySid = "http://schemas.microsoft.com/ws/2008/06/identity/claims/primarysid";
                }
                {
                    this.Role = "http://schemas.microsoft.com/ws/2008/06/identity/claims/role";
                }
                {
                    this.SerialNumber = "http://schemas.microsoft.com/ws/2008/06/identity/claims/serialnumber";
                }
                {
                    this.UserData = "http://schemas.microsoft.com/ws/2008/06/identity/claims/userdata";
                }
                {
                    this.Version = "http://schemas.microsoft.com/ws/2008/06/identity/claims/version";
                }
                {
                    this.WindowsAccountName = "http://schemas.microsoft.com/ws/2008/06/identity/claims/windowsaccountname";
                }
                {
                    this.WindowsDeviceClaim = "http://schemas.microsoft.com/ws/2008/06/identity/claims/windowsdeviceclaim";
                }
                {
                    this.WindowsDeviceGroup = "http://schemas.microsoft.com/ws/2008/06/identity/claims/windowsdevicegroup";
                }
                {
                    this.WindowsUserClaim = "http://schemas.microsoft.com/ws/2008/06/identity/claims/windowsuserclaim";
                }
                {
                    this.WindowsFqbnVersion = "http://schemas.microsoft.com/ws/2008/06/identity/claims/windowsfqbnversion";
                }
                {
                    this.WindowsSubAuthority = "http://schemas.microsoft.com/ws/2008/06/identity/claims/windowssubauthority";
                }
                {
                    this.ClaimType2005Namespace = "http://schemas.xmlsoap.org/ws/2005/05/identity/claims";
                }
                {
                    this.Anonymous = "http://schemas.xmlsoap.org/ws/2005/05/identity/claims/anonymous";
                }
                {
                    this.Authentication = "http://schemas.xmlsoap.org/ws/2005/05/identity/claims/authentication";
                }
                {
                    this.AuthorizationDecision = "http://schemas.xmlsoap.org/ws/2005/05/identity/claims/authorizationdecision";
                }
                {
                    this.Country = "http://schemas.xmlsoap.org/ws/2005/05/identity/claims/country";
                }
                {
                    this.DateOfBirth = "http://schemas.xmlsoap.org/ws/2005/05/identity/claims/dateofbirth";
                }
                {
                    this.Dns = "http://schemas.xmlsoap.org/ws/2005/05/identity/claims/dns";
                }
                {
                    this.DenyOnlySid = "http://schemas.xmlsoap.org/ws/2005/05/identity/claims/denyonlysid";
                }
                {
                    this.Email = "http://schemas.xmlsoap.org/ws/2005/05/identity/claims/emailaddress";
                }
                {
                    this.Gender = "http://schemas.xmlsoap.org/ws/2005/05/identity/claims/gender";
                }
                {
                    this.GivenName = "http://schemas.xmlsoap.org/ws/2005/05/identity/claims/givenname";
                }
                {
                    this.Hash = "http://schemas.xmlsoap.org/ws/2005/05/identity/claims/hash";
                }
                {
                    this.HomePhone = "http://schemas.xmlsoap.org/ws/2005/05/identity/claims/homephone";
                }
                {
                    this.Locality = "http://schemas.xmlsoap.org/ws/2005/05/identity/claims/locality";
                }
                {
                    this.MobilePhone = "http://schemas.xmlsoap.org/ws/2005/05/identity/claims/mobilephone";
                }
                {
                    this.Name = "http://schemas.xmlsoap.org/ws/2005/05/identity/claims/name";
                }
                {
                    this.NameIdentifier = "http://schemas.xmlsoap.org/ws/2005/05/identity/claims/nameidentifier";
                }
                {
                    this.OtherPhone = "http://schemas.xmlsoap.org/ws/2005/05/identity/claims/otherphone";
                }
                {
                    this.PostalCode = "http://schemas.xmlsoap.org/ws/2005/05/identity/claims/postalcode";
                }
                {
                    this.Rsa = "http://schemas.xmlsoap.org/ws/2005/05/identity/claims/rsa";
                }
                {
                    this.Sid = "http://schemas.xmlsoap.org/ws/2005/05/identity/claims/sid";
                }
                {
                    this.Spn = "http://schemas.xmlsoap.org/ws/2005/05/identity/claims/spn";
                }
                {
                    this.StateOrProvince = "http://schemas.xmlsoap.org/ws/2005/05/identity/claims/stateorprovince";
                }
                {
                    this.StreetAddress = "http://schemas.xmlsoap.org/ws/2005/05/identity/claims/streetaddress";
                }
                {
                    this.Surname = "http://schemas.xmlsoap.org/ws/2005/05/identity/claims/surname";
                }
                {
                    this.System = "http://schemas.xmlsoap.org/ws/2005/05/identity/claims/system";
                }
                {
                    this.Thumbprint = "http://schemas.xmlsoap.org/ws/2005/05/identity/claims/thumbprint";
                }
                {
                    this.Upn = "http://schemas.xmlsoap.org/ws/2005/05/identity/claims/upn";
                }
                {
                    this.Uri = "http://schemas.xmlsoap.org/ws/2005/05/identity/claims/uri";
                }
                {
                    this.Webpage = "http://schemas.xmlsoap.org/ws/2005/05/identity/claims/webpage";
                }
                {
                    this.X500DistinguishedName = "http://schemas.xmlsoap.org/ws/2005/05/identity/claims/x500distinguishedname";
                }
                {
                    this.ClaimType2009Namespace = "http://schemas.xmlsoap.org/ws/2009/09/identity/claims";
                }
                {
                    this.Actor = "http://schemas.xmlsoap.org/ws/2009/09/identity/claims/actor";
                }
            }
            static $h = 568220;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"l":[{"t":1310721,"n":"ClaimTypeNamespace","d":568220,"h":4295535516,"f":40},{"t":1310721,"n":"AuthenticationInstant","d":568220,"h":8590502812,"f":33},{"t":1310721,"n":"AuthenticationMethod","d":568220,"h":12885470108,"f":33},{"t":1310721,"n":"CookiePath","d":568220,"h":17180437404,"f":33},{"t":1310721,"n":"DenyOnlyPrimarySid","d":568220,"h":21475404700,"f":33},{"t":1310721,"n":"DenyOnlyPrimaryGroupSid","d":568220,"h":25770371996,"f":33},{"t":1310721,"n":"DenyOnlyWindowsDeviceGroup","d":568220,"h":30065339292,"f":33},{"t":1310721,"n":"Dsa","d":568220,"h":34360306588,"f":33},{"t":1310721,"n":"Expiration","d":568220,"h":38655273884,"f":33},{"t":1310721,"n":"Expired","d":568220,"h":42950241180,"f":33},{"t":1310721,"n":"GroupSid","d":568220,"h":47245208476,"f":33},{"t":1310721,"n":"IsPersistent","d":568220,"h":51540175772,"f":33},{"t":1310721,"n":"PrimaryGroupSid","d":568220,"h":55835143068,"f":33},{"t":1310721,"n":"PrimarySid","d":568220,"h":60130110364,"f":33},{"t":1310721,"n":"Role","d":568220,"h":64425077660,"f":33},{"t":1310721,"n":"SerialNumber","d":568220,"h":68720044956,"f":33},{"t":1310721,"n":"UserData","d":568220,"h":73015012252,"f":33},{"t":1310721,"n":"Version","d":568220,"h":77309979548,"f":33},{"t":1310721,"n":"WindowsAccountName","d":568220,"h":81604946844,"f":33},{"t":1310721,"n":"WindowsDeviceClaim","d":568220,"h":85899914140,"f":33},{"t":1310721,"n":"WindowsDeviceGroup","d":568220,"h":90194881436,"f":33},{"t":1310721,"n":"WindowsUserClaim","d":568220,"h":94489848732,"f":33},{"t":1310721,"n":"WindowsFqbnVersion","d":568220,"h":98784816028,"f":33},{"t":1310721,"n":"WindowsSubAuthority","d":568220,"h":103079783324,"f":33},{"t":1310721,"n":"ClaimType2005Namespace","d":568220,"h":107374750620,"f":40},{"t":1310721,"n":"Anonymous","d":568220,"h":111669717916,"f":33},{"t":1310721,"n":"Authentication","d":568220,"h":115964685212,"f":33},{"t":1310721,"n":"AuthorizationDecision","d":568220,"h":120259652508,"f":33},{"t":1310721,"n":"Country","d":568220,"h":124554619804,"f":33},{"t":1310721,"n":"DateOfBirth","d":568220,"h":128849587100,"f":33},{"t":1310721,"n":"Dns","d":568220,"h":133144554396,"f":33},{"t":1310721,"n":"DenyOnlySid","d":568220,"h":137439521692,"f":33},{"t":1310721,"n":"Email","d":568220,"h":141734488988,"f":33},{"t":1310721,"n":"Gender","d":568220,"h":146029456284,"f":33},{"t":1310721,"n":"GivenName","d":568220,"h":150324423580,"f":33},{"t":1310721,"n":"Hash","d":568220,"h":154619390876,"f":33},{"t":1310721,"n":"HomePhone","d":568220,"h":158914358172,"f":33},{"t":1310721,"n":"Locality","d":568220,"h":163209325468,"f":33},{"t":1310721,"n":"MobilePhone","d":568220,"h":167504292764,"f":33},{"t":1310721,"n":"Name","d":568220,"h":171799260060,"f":33},{"t":1310721,"n":"NameIdentifier","d":568220,"h":176094227356,"f":33},{"t":1310721,"n":"OtherPhone","d":568220,"h":180389194652,"f":33},{"t":1310721,"n":"PostalCode","d":568220,"h":184684161948,"f":33},{"t":1310721,"n":"Rsa","d":568220,"h":188979129244,"f":33},{"t":1310721,"n":"Sid","d":568220,"h":193274096540,"f":33},{"t":1310721,"n":"Spn","d":568220,"h":197569063836,"f":33},{"t":1310721,"n":"StateOrProvince","d":568220,"h":201864031132,"f":33},{"t":1310721,"n":"StreetAddress","d":568220,"h":206158998428,"f":33},{"t":1310721,"n":"Surname","d":568220,"h":210453965724,"f":33},{"t":1310721,"n":"System","d":568220,"h":214748933020,"f":33},{"t":1310721,"n":"Thumbprint","d":568220,"h":219043900316,"f":33},{"t":1310721,"n":"Upn","d":568220,"h":223338867612,"f":33},{"t":1310721,"n":"Uri","d":568220,"h":227633834908,"f":33},{"t":1310721,"n":"Webpage","d":568220,"h":231928802204,"f":33},{"t":1310721,"n":"X500DistinguishedName","d":568220,"h":236223769500,"f":33},{"t":1310721,"n":"ClaimType2009Namespace","d":568220,"h":240518736796,"f":40},{"t":1310721,"n":"Actor","d":568220,"h":244813704092,"f":33}],"h":568220}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.Security.Claims.ClaimTypes`; }
        });
        
        $asm.$cls("$ssc.System.Security.Claims.ClaimsPrincipal", ($self) => class ClaimsPrincipal extends $.$spc.System.Object
        {
            static $_SerializationMask;
            static get SerializationMask()
            {
                let $cls = $.$ssc.System.Security.Claims.ClaimsPrincipal;
                return $cls.$_SerializationMask ??= $asm.$nstr("$ssc.System.Security.Claims.ClaimsPrincipal.SerializationMask", ($self) => class SerializationMask extends $.$spc.System.Enum
                {
                    static None = 0;
                    static HasIdentities = 1;
                    static UserData = 2;
                    static $map;
                    static get Map()
                    {
                        return this.$map ??= 
                        {
                            "None": 0n,
                            "HasIdentities": 1n,
                            "UserData": 2n
                        };
                    }
                    static $h = 502684;
                    static $z = 4;
                    static $f = 0b110000011010001000;
                    static $k = 4;
                    static get $eut() { return $.$spc.System.Int32; }
                    static $$md;
                    static get $md() { return this.$$md ??= {"b":1048577,"u":655361,"l":[{"t":502684,"n":"None","d":502684,"h":4295469980,"f":33},{"t":502684,"n":"HasIdentities","d":502684,"h":8590437276,"f":33},{"t":502684,"n":"UserData","d":502684,"h":12885404572,"f":33}],"c":[{"n":".ctor","o":"$ctor$3","d":502684,"h":17180371868,"f":1}],"i":[57212929,63766529,57671681,57344001],"d":437148,"h":502684}; }
                    static get $b() { return $.$spc.System.Enum; }
                    static $$i;
                    static get $i() { return this.$$i ??= [ $.$spc.System.IComparable, $.$spc.System.ISpanFormattable, $.$spc.System.IFormattable, $.$spc.System.IConvertible ]; }
                    static get $fullName() { return `System.Security.Claims.ClaimsPrincipal.SerializationMask`; }
                }, $cls, ($v) => $cls.$_SerializationMask = $v);
            }
            /*List<ClaimsIdentity>*/ _identities = null;
            /*byte[]?*/ _userSerializationData = null;
            /*Func<IEnumerable<ClaimsIdentity>, ClaimsIdentity?>*/ static s_identitySelector = null;
            /*Func<ClaimsPrincipal?>?*/ static s_principalSelector = null;
            static /*ClaimsPrincipal? */ SelectClaimsPrincipal()
            {
                /*IPrincipal?*/ let threadPrincipal = $.$spc.System.Threading.Thread.CurrentPrincipal;
                return (() =>
                {
                    {
                        let claimsPrincipal;
                        if ((claimsPrincipal = threadPrincipal, $.$is(claimsPrincipal, $.$ssc.System.Security.Claims.ClaimsPrincipal)))
                        {
                            return claimsPrincipal;
                        }
                    }
                    if (threadPrincipal === null)
                    {
                        return new $.$ssc.System.Security.Claims.ClaimsPrincipal().$ctor$5(threadPrincipal);
                    }
                    if (threadPrincipal === null)
                    {
                        return null;
                    }
                })();
            }
            $ctor$1(/*SerializationInfo*/ info, /*StreamingContext*/ context)
            {
                super.$ctor();
                {
                    throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
                }
                return this;
            }
            static /*ClaimsIdentity? */ SelectPrimaryIdentity(/*IEnumerable<ClaimsIdentity>*/ identities)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(identities, "identities");
                var $en2 = identities.System$Collections$Generic$IEnumerable$$$GetEnumerator();
                while ($en2.System$Collections$IEnumerator$MoveNext())
                {
                    var identity = $en2.System$Collections$Generic$IEnumerator$$$Current;
                    {
                        if (identity !== null)
                        {
                            return identity;
                        }
                    }
                }
                return null;
            }
            static /*Func<IEnumerable<ClaimsIdentity>, ClaimsIdentity?> */ get PrimaryIdentitySelector()
            {
                return $.$ssc.System.Security.Claims.ClaimsPrincipal.s_identitySelector;
            }
            static /*Func<IEnumerable<ClaimsIdentity>, ClaimsIdentity?> */ set PrimaryIdentitySelector(value)
            {
                $.$ssc.System.Security.Claims.ClaimsPrincipal.s_identitySelector = value;
            }
            static /*Func<ClaimsPrincipal?>? */ get ClaimsPrincipalSelector()
            {
                return $.$ssc.System.Security.Claims.ClaimsPrincipal.s_principalSelector;
            }
            static /*Func<ClaimsPrincipal?>? */ set ClaimsPrincipalSelector(value)
            {
                $.$ssc.System.Security.Claims.ClaimsPrincipal.s_principalSelector = value;
            }
            $ctor$2()
            {
                super.$ctor();
                {
                }
                return this;
            }
            $ctor$3(/*IEnumerable<ClaimsIdentity>*/ identities)
            {
                super.$ctor();
                {
                    $.$spc.System.ArgumentNullException.ThrowIfNull(identities, "identities");
                    this._identities.AddRange(identities);
                }
                return this;
            }
            $ctor$4(/*IIdentity*/ identity)
            {
                super.$ctor();
                {
                    $.$spc.System.ArgumentNullException.ThrowIfNull(identity, "identity");
                    let ci;
                    if ($.$is(identity, $.$ssc.System.Security.Claims.ClaimsIdentity, { set $v(v){ ci = v; } }))
                    {
                        this._identities.Add(ci);
                    }
                    else 
                    {
                        this._identities.Add(new $.$ssc.System.Security.Claims.ClaimsIdentity().$ctor$2(identity));
                    }
                }
                return this;
            }
            $ctor$5(/*IPrincipal*/ principal)
            {
                super.$ctor();
                {
                    $.$spc.System.ArgumentNullException.ThrowIfNull(principal, "principal");
                    /*ClaimsPrincipal?*/ let cp = $.$as(principal, $.$ssc.System.Security.Claims.ClaimsPrincipal);
                    if (null === cp)
                    {
                        this._identities.Add(new $.$ssc.System.Security.Claims.ClaimsIdentity().$ctor$2(principal.System$Security$Principal$IPrincipal$Identity));
                    }
                    else 
                    {
                        if (null !== cp.Identities)
                        {
                            this._identities.AddRange(cp.Identities);
                        }
                    }
                }
                return this;
            }
            $ctor$6(/*BinaryReader*/ reader)
            {
                super.$ctor();
                {
                    $.$spc.System.ArgumentNullException.ThrowIfNull(reader, "reader");
                    /*SerializationMask*/ let mask = $.$cast(reader.ReadInt32(), $.$ssc.System.Security.Claims.ClaimsPrincipal.SerializationMask);
                    /*int*/ let numPropertiesToRead = reader.ReadInt32();
                    /*int*/ let numPropertiesRead = 0;
                    if ((mask & 1/*SerializationMask.HasIdentities*/) === 1/*SerializationMask.HasIdentities*/)
                    {
                        numPropertiesRead++;
                        /*int*/ let numberOfIdentities = reader.ReadInt32();
                        for(/*int*/ let index = 0; index < numberOfIdentities; ++index)
                        {
                            this._identities.Add(this.CreateClaimsIdentity(reader));
                        }
                    }
                    if ((mask & 2/*SerializationMask.UserData*/) === 2/*SerializationMask.UserData*/)
                    {
                        /*int*/ let cb = reader.ReadInt32();
                        this._userSerializationData = reader.ReadBytes(cb);
                        numPropertiesRead++;
                    }
                    for(/*int*/ let i = numPropertiesRead; i < numPropertiesToRead; i++)
                    {
                        reader.ReadString();
                    }
                }
                return this;
            }
            /*void */ AddIdentity(/*ClaimsIdentity*/ identity)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(identity, "identity");
                this._identities.Add(identity);
            }
            /*void */ AddIdentities(/*IEnumerable<ClaimsIdentity>*/ identities)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(identities, "identities");
                this._identities.AddRange(identities);
            }
            /*IEnumerable<Claim> */ get Claims()
            {
                return new ($.$spc.NetJs.YieldToIterator$$($.$ssc.System.Security.Claims.Claim))().$ctor$1(function*()
                {
                    var $en3 = this.Identities.System$Collections$Generic$IEnumerable$$$GetEnumerator();
                    while ($en3.System$Collections$IEnumerator$MoveNext())
                    {
                        var identity = $en3.System$Collections$Generic$IEnumerator$$$Current;
                        {
                            var $en5 = identity.Claims.System$Collections$Generic$IEnumerable$$$GetEnumerator();
                            while ($en5.System$Collections$IEnumerator$MoveNext())
                            {
                                var claim = $en5.System$Collections$Generic$IEnumerator$$$Current;
                                {
                                    yield claim;
                                }
                            }
                        }
                    }
                }.bind(this));
            }
            /*byte[]? */ get CustomSerializationData()
            {
                return this._userSerializationData;
            }
            /*ClaimsPrincipal */ Clone()
            {
                return new $.$ssc.System.Security.Claims.ClaimsPrincipal().$ctor$5(this);
            }
            /*ClaimsIdentity */ CreateClaimsIdentity(/*BinaryReader*/ reader)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(reader, "reader");
                return new $.$ssc.System.Security.Claims.ClaimsIdentity().$ctor$10(reader);
            }
            static /*ClaimsPrincipal? */ get Current()
            {
                return !($.$ssc.System.Security.Claims.ClaimsPrincipal.s_principalSelector === null) ? $.$ssc.System.Security.Claims.ClaimsPrincipal.s_principalSelector.Invoke() : $.$ssc.System.Security.Claims.ClaimsPrincipal.SelectClaimsPrincipal();
            }
            /*IEnumerable<Claim> */ FindAll(/*Predicate<Claim>*/ match)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(match, "match");
                return Core.call(this, match);
                /*IEnumerable<Claim>*/  function Core(/*Predicate<Claim>*/ match)
                {
                    return new ($.$spc.NetJs.YieldToIterator$$($.$spc.System.Object))().$ctor$1(function*()
                    {
                        var $en4 = this.Identities.System$Collections$Generic$IEnumerable$$$GetEnumerator();
                        while ($en4.System$Collections$IEnumerator$MoveNext())
                        {
                            var identity = $en4.System$Collections$Generic$IEnumerator$$$Current;
                            {
                                if (identity !== null)
                                {
                                    var $en7 = identity.FindAll(match).System$Collections$Generic$IEnumerable$$$GetEnumerator();
                                    while ($en7.System$Collections$IEnumerator$MoveNext())
                                    {
                                        var claim = $en7.System$Collections$Generic$IEnumerator$$$Current;
                                        {
                                            yield claim;
                                        }
                                    }
                                }
                            }
                        }
                    }.bind(this));
                }
            }
            /*IEnumerable<Claim> */ FindAll$1(/*string*/ type)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(type, "type");
                return Core.call(this, type);
                /*IEnumerable<Claim>*/  function Core(/*string*/ type)
                {
                    return new ($.$spc.NetJs.YieldToIterator$$($.$spc.System.Object))().$ctor$1(function*()
                    {
                        var $en4 = this.Identities.System$Collections$Generic$IEnumerable$$$GetEnumerator();
                        while ($en4.System$Collections$IEnumerator$MoveNext())
                        {
                            var identity = $en4.System$Collections$Generic$IEnumerator$$$Current;
                            {
                                if (identity !== null)
                                {
                                    var $en7 = identity.FindAll$1(type).System$Collections$Generic$IEnumerable$$$GetEnumerator();
                                    while ($en7.System$Collections$IEnumerator$MoveNext())
                                    {
                                        var claim = $en7.System$Collections$Generic$IEnumerator$$$Current;
                                        {
                                            yield claim;
                                        }
                                    }
                                }
                            }
                        }
                    }.bind(this));
                }
            }
            /*Claim? */ FindFirst(/*Predicate<Claim>*/ match)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(match, "match");
                /*Claim?*/ let claim = null;
                var $en2 = this.Identities.System$Collections$Generic$IEnumerable$$$GetEnumerator();
                while ($en2.System$Collections$IEnumerator$MoveNext())
                {
                    var identity = $en2.System$Collections$Generic$IEnumerator$$$Current;
                    {
                        if (identity !== null)
                        {
                            claim = identity.FindFirst(match);
                            if (claim !== null)
                            {
                                return claim;
                            }
                        }
                    }
                }
                return claim;
            }
            /*Claim? */ FindFirst$1(/*string*/ type)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(type, "type");
                /*Claim?*/ let claim = null;
                for(/*int*/ let i = 0; i < this._identities.Count; i++)
                {
                    if (this._identities.get_Item(i) !== null)
                    {
                        claim = this._identities.get_Item(i).FindFirst$1(type);
                        if (claim !== null)
                        {
                            return claim;
                        }
                    }
                }
                return claim;
            }
            /*bool */ HasClaim(/*Predicate<Claim>*/ match)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(match, "match");
                for(/*int*/ let i = 0; i < this._identities.Count; i++)
                {
                    if (this._identities.get_Item(i) !== null)
                    {
                        if (this._identities.get_Item(i).HasClaim(match))
                        {
                            return true;
                        }
                    }
                }
                return false;
            }
            /*bool */ HasClaim$1(/*string*/ type, /*string*/ value)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(type, "type");
                $.$spc.System.ArgumentNullException.ThrowIfNull(value, "value");
                for(/*int*/ let i = 0; i < this._identities.Count; i++)
                {
                    if (this._identities.get_Item(i) !== null)
                    {
                        if (this._identities.get_Item(i).HasClaim$1(type, value))
                        {
                            return true;
                        }
                    }
                }
                return false;
            }
            /*IEnumerable<ClaimsIdentity> */ get Identities()
            {
                return this._identities;
            }
            /*System.Security.Principal.IIdentity? */ get Identity()
            {
                if ($.$ssc.System.Security.Claims.ClaimsPrincipal.s_identitySelector !== null)
                {
                    return $.$ssc.System.Security.Claims.ClaimsPrincipal.s_identitySelector.Invoke(this._identities);
                }
                else 
                {
                    return $.$ssc.System.Security.Claims.ClaimsPrincipal.SelectPrimaryIdentity(this._identities);
                }
            }
            /*bool */ IsInRole(/*string*/ role)
            {
                for(/*int*/ let i = 0; i < this._identities.Count; i++)
                {
                    if (this._identities.get_Item(i) !== null)
                    {
                        if (this._identities.get_Item(i).HasClaim$1(this._identities.get_Item(i).RoleClaimType, role))
                        {
                            return true;
                        }
                    }
                }
                return false;
            }
            /*void */ WriteTo(/*BinaryWriter*/ writer)
            {
                this.WriteTo$1(writer, null);
            }
            /*void */ WriteTo$1(/*BinaryWriter*/ writer, /*byte[]?*/ userData)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(writer, "writer");
                /*int*/ let numberOfPropertiesWritten = 0;
                /*var*/ let mask = 0/*SerializationMask.None*/;
                if (this._identities.Count > 0)
                {
                    mask |= 1/*SerializationMask.HasIdentities*/;
                    numberOfPropertiesWritten++;
                }
                if (userData !== null && userData.length > 0)
                {
                    numberOfPropertiesWritten++;
                    mask |= 2/*SerializationMask.UserData*/;
                }
                writer.Write$12(mask);
                writer.Write$12(numberOfPropertiesWritten);
                if ((mask & 1/*SerializationMask.HasIdentities*/) === 1/*SerializationMask.HasIdentities*/)
                {
                    writer.Write$12(this._identities.Count);
                    var $en3 = this._identities.GetEnumerator();
                    while ($en3.MoveNext())
                    {
                        var identity = $en3.Current;
                        {
                            identity.WriteTo(writer);
                        }
                    }
                }
                if ((mask & 2/*SerializationMask.UserData*/) === 2/*SerializationMask.UserData*/)
                {
                    writer.Write$12(userData.length);
                    writer.Write$3(userData);
                }
                writer.Flush();
            }
            /*void */ OnSerializingMethod(/*StreamingContext*/ context)
            {
                if ($.$is(this, $.$spc.System.Runtime.Serialization.ISerializable))
                {
                    return;
                }
                if (this._identities.Count > 0)
                {
                    throw new $.$spc.System.PlatformNotSupportedException().$ctor$14($.$ssc.System.SR.PlatformNotSupported_Serialization);
                }
            }
            /*void */ GetObjectData(/*SerializationInfo*/ info, /*StreamingContext*/ context)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*string */ DebuggerToString()
            {
                /*int*/ let identitiesCount = 0;
                var $en2 = this.Identities.System$Collections$Generic$IEnumerable$$$GetEnumerator();
                while ($en2.System$Collections$IEnumerator$MoveNext())
                {
                    var items = $en2.System$Collections$Generic$IEnumerator$$$Current;
                    {
                        identitiesCount++;
                    }
                }
                let claimsIdentity;
                if (identitiesCount === 1 && $.$is(this.Identity, $.$ssc.System.Security.Claims.ClaimsIdentity, { set $v(v){ claimsIdentity = v; } }))
                {
                    return claimsIdentity.DebuggerToString();
                }
                /*int*/ let claimsCount = 0;
                var $en2 = this.Claims.System$Collections$Generic$IEnumerable$$$GetEnumerator();
                while ($en2.System$Collections$IEnumerator$MoveNext())
                {
                    var item = $en2.System$Collections$Generic$IEnumerator$$$Current;
                    {
                        claimsCount++;
                    }
                }
                return `Identities = ${identitiesCount}, Claims = ${claimsCount}`;
            }
            //Generated interface implemetation for System.Security.Principal.IPrincipal.Identity.get
            get System$Security$Principal$IPrincipal$Identity()
            {
                return this.Identity;
            }
            //Generated interface implemetation for System.Security.Principal.IPrincipal.IsInRole(string)
            System$Security$Principal$IPrincipal$IsInRole()
            {
                return this.IsInRole(...arguments);
            }
            //default member initializer
            constructor()
            {
                super();
                this._identities = new ($.$spc.System.Collections.Generic.List$$($.$ssc.System.Security.Claims.ClaimsIdentity))().$ctor$1();
            }
            //Static Initializer
            static $sinit()
            {
                {
                    this.s_identitySelector = new ($.$spc.System.Func$$$($.$spc.System.Collections.Generic.IEnumerable$$($.$ssc.System.Security.Claims.ClaimsIdentity), $.$ssc.System.Security.Claims.ClaimsIdentity))().$ctor(null, $.$ssc.System.Security.Claims.ClaimsPrincipal.SelectPrimaryIdentity);
                }
            }
            static $h = 437148;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":$.$spc.System.Func$$$($.$spc.System.Collections.Generic.IEnumerable$$($.$ssc.System.Security.Claims.ClaimsIdentity), $.$ssc.System.Security.Claims.ClaimsIdentity).$h,"g":{"r":0,"d":0,"h":42950110108,"f":33},"s":{"r":0,"d":0,"h":47245077404,"f":33},"n":"PrimaryIdentitySelector","d":437148,"h":38655142812,"f":33},{"p":$.$spc.System.Func$$($.$ssc.System.Security.Claims.ClaimsPrincipal).$h,"g":{"r":0,"d":0,"h":55835011996,"f":33},"s":{"r":0,"d":0,"h":60129979292,"f":33},"n":"ClaimsPrincipalSelector","d":437148,"h":51540044700,"f":33},{"p":$.$spc.System.Collections.Generic.IEnumerable$$($.$ssc.System.Security.Claims.Claim).$h,"g":{"r":0,"d":0,"h":98784684956,"f":129},"n":"Claims","d":437148,"h":94489717660,"f":129},{"p":0,"g":{"r":0,"d":0,"h":107374619548,"f":132},"n":"CustomSerializationData","d":437148,"h":103079652252,"f":132},{"p":437148,"g":{"r":0,"d":0,"h":124554488732,"f":33},"n":"Current","d":437148,"h":120259521436,"f":33},{"p":$.$spc.System.Collections.Generic.IEnumerable$$($.$ssc.System.Security.Claims.ClaimsIdentity).$h,"g":{"r":0,"d":0,"h":158914227100,"f":129},"n":"Identities","d":437148,"h":154619259804,"f":129},{"p":117047297,"g":{"r":0,"d":0,"h":167504161692,"f":129},"n":"Identity","d":437148,"h":163209194396,"f":129}],"m":[{"r":437148,"n":"SelectClaimsPrincipal","d":437148,"h":25770240924,"f":34},{"r":306076,"p":[{"n":"identities","p":$.$spc.System.Collections.Generic.IEnumerable$$($.$ssc.System.Security.Claims.ClaimsIdentity).$h}],"n":"SelectPrimaryIdentity","d":437148,"h":34360175516,"f":34},{"r":65537,"p":[{"n":"identity","p":306076}],"n":"AddIdentity","d":437148,"h":85899783068,"f":129},{"r":65537,"p":[{"n":"identities","p":$.$spc.System.Collections.Generic.IEnumerable$$($.$ssc.System.Security.Claims.ClaimsIdentity).$h}],"n":"AddIdentities","d":437148,"h":90194750364,"f":129},{"r":437148,"n":"Clone","d":437148,"h":111669586844,"f":129},{"r":306076,"p":[{"n":"reader","p":58392577}],"n":"CreateClaimsIdentity","d":437148,"h":115964554140,"f":132},{"r":$.$spc.System.Collections.Generic.IEnumerable$$($.$ssc.System.Security.Claims.Claim).$h,"p":[{"n":"match","p":$.$spc.System.Predicate$$($.$ssc.System.Security.Claims.Claim).$h}],"n":"FindAll","d":437148,"h":128849456028,"f":129},{"r":$.$spc.System.Collections.Generic.IEnumerable$$($.$ssc.System.Security.Claims.Claim).$h,"p":[{"n":"type","p":1310721}],"n":"FindAll","o":"@$1","d":437148,"h":133144423324,"f":129},{"r":175004,"p":[{"n":"match","p":$.$spc.System.Predicate$$($.$ssc.System.Security.Claims.Claim).$h}],"n":"FindFirst","d":437148,"h":137439390620,"f":129},{"r":175004,"p":[{"n":"type","p":1310721}],"n":"FindFirst","o":"@$1","d":437148,"h":141734357916,"f":129},{"r":262145,"p":[{"n":"match","p":$.$spc.System.Predicate$$($.$ssc.System.Security.Claims.Claim).$h}],"n":"HasClaim","d":437148,"h":146029325212,"f":129},{"r":262145,"p":[{"n":"type","p":1310721},{"n":"value","p":1310721}],"n":"HasClaim","o":"@$1","d":437148,"h":150324292508,"f":129},{"r":262145,"p":[{"n":"role","p":1310721}],"n":"IsInRole","d":437148,"h":171799128988,"f":129},{"r":65537,"p":[{"n":"writer","p":58458113}],"n":"WriteTo","d":437148,"h":176094096284,"f":129},{"r":65537,"p":[{"n":"writer","p":58458113},{"n":"userData","p":0}],"n":"WriteTo","o":"@$1","d":437148,"h":180389063580,"f":132},{"r":65537,"p":[{"n":"context","p":114098177}],"n":"OnSerializingMethod","d":437148,"h":184684030876,"f":2,"a":[{"t":113639425,"c":4408606721}]},{"r":65537,"p":[{"n":"info","p":113967105},{"n":"context","p":114098177}],"n":"GetObjectData","d":437148,"h":188978998172,"f":132},{"r":1310721,"n":"DebuggerToString","d":437148,"h":193273965468,"f":2}],"l":[{"t":$.$spc.System.Collections.Generic.List$$($.$ssc.System.Security.Claims.ClaimsIdentity).$h,"n":"_identities","d":437148,"h":8590371740,"f":2},{"t":0,"n":"_userSerializationData","d":437148,"h":12885339036,"f":2},{"t":$.$spc.System.Func$$$($.$spc.System.Collections.Generic.IEnumerable$$($.$ssc.System.Security.Claims.ClaimsIdentity), $.$ssc.System.Security.Claims.ClaimsIdentity).$h,"n":"s_identitySelector","d":437148,"h":17180306332,"f":34},{"t":$.$spc.System.Func$$($.$ssc.System.Security.Claims.ClaimsPrincipal).$h,"n":"s_principalSelector","d":437148,"h":21475273628,"f":34}],"c":[{"p":[{"n":"info","p":113967105},{"n":"context","p":114098177}],"n":".ctor","o":"$ctor$1","d":437148,"h":30065208220,"f":4,"a":[{"t":70909953,"c":8660844545,"a":[{"v":"This API supports obsolete formatter-based serialization. It should not be called or extended by application code.","t":1310721}],"n":[{"n":"DiagnosticId","v":"SYSLIB0051","t":1310721},{"n":"UrlFormat","v":"https://aka.ms/dotnet-warnings/{0}","t":1310721}]},{"t":33161217,"c":4328128513,"a":[{"v":1,"t":33226753}]}]},{"n":".ctor","o":"$ctor$2","d":437148,"h":64424946588,"f":1},{"p":[{"n":"identities","p":$.$spc.System.Collections.Generic.IEnumerable$$($.$ssc.System.Security.Claims.ClaimsIdentity).$h}],"n":".ctor","o":"$ctor$3","d":437148,"h":68719913884,"f":1},{"p":[{"n":"identity","p":117047297}],"n":".ctor","o":"$ctor$4","d":437148,"h":73014881180,"f":1},{"p":[{"n":"principal","p":117112833}],"n":".ctor","o":"$ctor$5","d":437148,"h":77309848476,"f":1},{"p":[{"n":"reader","p":58392577}],"n":".ctor","o":"$ctor$6","d":437148,"h":81604815772,"f":1}],"i":[117112833],"j":[502684],"h":437148,"a":[{"t":37552129,"c":8627486721,"a":[{"v":"{DebuggerToString(),nq}","t":1310721}]}]}; }
            static get $b() { return $.$spc.System.Object; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.Security.Principal.IPrincipal ]; }
            static get $fullName() { return `System.Security.Claims.ClaimsPrincipal`; }
        });
        
        $asm.$cls("$ssc.System.Security.Claims.ClaimsIdentity", ($self) => class ClaimsIdentity extends $.$spc.System.Object
        {
            static $_SerializationMask;
            static get SerializationMask()
            {
                let $cls = $.$ssc.System.Security.Claims.ClaimsIdentity;
                return $cls.$_SerializationMask ??= $asm.$nstr("$ssc.System.Security.Claims.ClaimsIdentity.SerializationMask", ($self) => class SerializationMask extends $.$spc.System.Enum
                {
                    static None = 0;
                    static AuthenticationType = 1;
                    static BootstrapConext = 2;
                    static NameClaimType = 4;
                    static RoleClaimType = 8;
                    static HasClaims = 16;
                    static HasLabel = 32;
                    static Actor = 64;
                    static UserData = 128;
                    static $map;
                    static get Map()
                    {
                        return this.$map ??= 
                        {
                            "None": 0n,
                            "AuthenticationType": 1n,
                            "BootstrapConext": 2n,
                            "NameClaimType": 4n,
                            "RoleClaimType": 8n,
                            "HasClaims": 16n,
                            "HasLabel": 32n,
                            "Actor": 64n,
                            "UserData": 128n
                        };
                    }
                    static $h = 371612;
                    static $z = 4;
                    static $f = 0b110000011010001000;
                    static $k = 4;
                    static get $eut() { return $.$spc.System.Int32; }
                    static $$md;
                    static get $md() { return this.$$md ??= {"b":1048577,"u":655361,"l":[{"t":371612,"n":"None","d":371612,"h":4295338908,"f":33},{"t":371612,"n":"AuthenticationType","d":371612,"h":8590306204,"f":33},{"t":371612,"n":"BootstrapConext","d":371612,"h":12885273500,"f":33},{"t":371612,"n":"NameClaimType","d":371612,"h":17180240796,"f":33},{"t":371612,"n":"RoleClaimType","d":371612,"h":21475208092,"f":33},{"t":371612,"n":"HasClaims","d":371612,"h":25770175388,"f":33},{"t":371612,"n":"HasLabel","d":371612,"h":30065142684,"f":33},{"t":371612,"n":"Actor","d":371612,"h":34360109980,"f":33},{"t":371612,"n":"UserData","d":371612,"h":38655077276,"f":33}],"c":[{"n":".ctor","o":"$ctor$3","d":371612,"h":42950044572,"f":1}],"i":[57212929,63766529,57671681,57344001],"d":306076,"h":371612}; }
                    static get $b() { return $.$spc.System.Enum; }
                    static $$i;
                    static get $i() { return this.$$i ??= [ $.$spc.System.IComparable, $.$spc.System.ISpanFormattable, $.$spc.System.IFormattable, $.$spc.System.IConvertible ]; }
                    static get $fullName() { return `System.Security.Claims.ClaimsIdentity.SerializationMask`; }
                }, $cls, ($v) => $cls.$_SerializationMask = $v);
            }
            /*byte[]?*/ _userSerializationData = null;
            /*ClaimsIdentity?*/ _actor = null;
            /*string?*/ _authenticationType = null;
            /*object?*/ _bootstrapContext = null;
            /*List<List<Claim>>?*/ _externalClaims = null;
            /*string?*/ _label = null;
            /*List<Claim>*/ _instanceClaims = null;
            /*string*/ _nameClaimType = null;
            /*string*/ _roleClaimType = null;
            /*StringComparison*/ _stringComparison = 5;
            /*string*/ static DefaultIssuer = null;
            /*string*/ static DefaultNameClaimType = null;
            /*string*/ static DefaultRoleClaimType = null;
            $ctor$1()
            {
                this.$ctor$9(null, null, null, null, null);
                {
                }
                return this;
            }
            $ctor$2(/*IIdentity?*/ identity)
            {
                this.$ctor$9(identity, null, null, null, null);
                {
                }
                return this;
            }
            $ctor$3(/*IEnumerable<Claim>?*/ claims)
            {
                this.$ctor$9(null, claims, null, null, null);
                {
                }
                return this;
            }
            $ctor$4(/*string?*/ authenticationType)
            {
                this.$ctor$9(null, null, authenticationType, null, null);
                {
                }
                return this;
            }
            $ctor$5(/*IEnumerable<Claim>?*/ claims, /*string?*/ authenticationType)
            {
                this.$ctor$9(null, claims, authenticationType, null, null);
                {
                }
                return this;
            }
            $ctor$6(/*IIdentity?*/ identity, /*IEnumerable<Claim>?*/ claims)
            {
                this.$ctor$9(identity, claims, null, null, null);
                {
                }
                return this;
            }
            $ctor$7(/*string?*/ authenticationType, /*string?*/ nameType, /*string?*/ roleType)
            {
                this.$ctor$9(null, null, authenticationType, nameType, roleType);
                {
                }
                return this;
            }
            $ctor$8(/*IEnumerable<Claim>?*/ claims, /*string?*/ authenticationType, /*string?*/ nameType, /*string?*/ roleType)
            {
                this.$ctor$9(null, claims, authenticationType, nameType, roleType);
                {
                }
                return this;
            }
            $ctor$9(/*IIdentity?*/ identity, /*IEnumerable<Claim>?*/ claims, /*string?*/ authenticationType, /*string?*/ nameType, /*string?*/ roleType)
            {
                super.$ctor();
                {
                    /*ClaimsIdentity?*/ let claimsIdentity = $.$as(identity, $.$ssc.System.Security.Claims.ClaimsIdentity);
                    this._authenticationType = (identity !== null && $.$spc.System.String.IsNullOrEmpty(authenticationType)) ? identity.System$Security$Principal$IIdentity$AuthenticationType : authenticationType;
                    this._nameClaimType = !$.$spc.System.String.IsNullOrEmpty(nameType) ? nameType : (claimsIdentity !== null ? claimsIdentity._nameClaimType : "http://schemas.xmlsoap.org/ws/2005/05/identity/claims/name"/*DefaultNameClaimType*/);
                    this._roleClaimType = !$.$spc.System.String.IsNullOrEmpty(roleType) ? roleType : (claimsIdentity !== null ? claimsIdentity._roleClaimType : "http://schemas.microsoft.com/ws/2008/06/identity/claims/role"/*DefaultRoleClaimType*/);
                    if (claimsIdentity !== null)
                    {
                        this._label = claimsIdentity._label;
                        this._bootstrapContext = claimsIdentity._bootstrapContext;
                        if (claimsIdentity.Actor !== null)
                        {
                            if (!this.IsCircular(claimsIdentity.Actor))
                            {
                                this._actor = claimsIdentity.Actor;
                            }
                            else 
                            {
                                throw new $.$spc.System.InvalidOperationException().$ctor$10($.$ssc.System.SR.InvalidOperationException_ActorGraphCircular);
                            }
                        }
                        this.SafeAddClaims(claimsIdentity._instanceClaims);
                    }
                    else 
                    {
                        if (identity !== null && !$.$spc.System.String.IsNullOrEmpty(identity.System$Security$Principal$IIdentity$Name))
                        {
                            this.SafeAddClaim(new $.$ssc.System.Security.Claims.Claim().$ctor$7(this._nameClaimType, identity.System$Security$Principal$IIdentity$Name, "http://www.w3.org/2001/XMLSchema#string"/*ClaimValueTypes.String*/, "LOCAL AUTHORITY"/*DefaultIssuer*/, "LOCAL AUTHORITY"/*DefaultIssuer*/, this));
                        }
                    }
                    if (claims !== null)
                    {
                        this.SafeAddClaims(claims);
                    }
                }
                return this;
            }
            $ctor$10(/*BinaryReader*/ reader)
            {
                super.$ctor();
                {
                    $.$spc.System.ArgumentNullException.ThrowIfNull(reader, "reader");
                    this.Initialize$1(reader);
                }
                return this;
            }
            $ctor$11(/*BinaryReader*/ reader, /*StringComparison*/ stringComparison)
            {
                super.$ctor();
                {
                    $.$spc.System.ArgumentNullException.ThrowIfNull(reader, "reader");
                    $.$ssc.System.Security.Claims.ClaimsIdentity.ValidateStringComparison(stringComparison);
                    this._stringComparison = stringComparison;
                    this.Initialize$1(reader);
                }
                return this;
            }
            $ctor$12(/*ClaimsIdentity*/ other)
            {
                super.$ctor();
                {
                    $.$spc.System.ArgumentNullException.ThrowIfNull(other, "other");
                    this.Initialize(other);
                }
                return this;
            }
            $ctor$13(/*ClaimsIdentity*/ other, /*StringComparison*/ stringComparison)
            {
                super.$ctor();
                {
                    $.$spc.System.ArgumentNullException.ThrowIfNull(other, "other");
                    $.$ssc.System.Security.Claims.ClaimsIdentity.ValidateStringComparison(stringComparison);
                    this._stringComparison = stringComparison;
                    this.Initialize(other);
                }
                return this;
            }
            $ctor$14(/*IIdentity?*/ identity, /*IEnumerable<Claim>?*/ claims, /*string?*/ authenticationType, /*string?*/ nameType, /*string?*/ roleType, /*StringComparison*/ stringComparison)
            {
                this.$ctor$9(identity, claims, authenticationType, nameType, roleType);
                {
                    $.$ssc.System.Security.Claims.ClaimsIdentity.ValidateStringComparison(stringComparison);
                    this._stringComparison = stringComparison;
                }
                return this;
            }
            $ctor$15(/*SerializationInfo*/ info, /*StreamingContext*/ context)
            {
                super.$ctor();
                {
                    throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
                }
                return this;
            }
            $ctor$16(/*SerializationInfo*/ info)
            {
                super.$ctor();
                {
                    throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
                }
                return this;
            }
            /*string? */ get AuthenticationType()
            {
                return this._authenticationType;
            }
            /*bool */ get IsAuthenticated()
            {
                return !$.$spc.System.String.IsNullOrEmpty(this._authenticationType);
            }
            /*ClaimsIdentity? */ get Actor()
            {
                return this._actor;
            }
            /*ClaimsIdentity? */ set Actor(value)
            {
                if (value !== null)
                {
                    if (this.IsCircular(value))
                    {
                        throw new $.$spc.System.InvalidOperationException().$ctor$10($.$ssc.System.SR.InvalidOperationException_ActorGraphCircular);
                    }
                }
                this._actor = value;
            }
            /*object? */ get BootstrapContext()
            {
                return this._bootstrapContext;
            }
            /*object? */ set BootstrapContext(value)
            {
                this._bootstrapContext = value;
            }
            /*IEnumerable<Claim> */ get Claims()
            {
                if (this._externalClaims === null)
                {
                    return this._instanceClaims;
                }
                return this.CombinedClaimsIterator();
            }
            /*IEnumerable<Claim> */ CombinedClaimsIterator()
            {
                return new ($.$spc.NetJs.YieldToIterator$$($.$spc.System.Object))().$ctor$1(function*()
                {
                    for(/*int*/ let i = 0; i < this._instanceClaims.Count; i++)
                    {
                        yield this._instanceClaims.get_Item(i);
                    }
                    for(/*int*/ let j = 0; j < this._externalClaims.Count; j++)
                    {
                        if (this._externalClaims.get_Item(j) !== null)
                        {
                            var $en5 = this._externalClaims.get_Item(j).GetEnumerator();
                            while ($en5.MoveNext())
                            {
                                var claim = $en5.Current;
                                {
                                    yield claim;
                                }
                            }
                        }
                    }
                }.bind(this));
            }
            /*byte[]? */ get CustomSerializationData()
            {
                return this._userSerializationData;
            }
            /*List<List<Claim>> */ get ExternalClaims()
            {
                return this._externalClaims ??= new ($.$spc.System.Collections.Generic.List$$($.$spc.System.Collections.Generic.List$$($.$ssc.System.Security.Claims.Claim)))().$ctor$1();
            }
            /*string? */ get Label()
            {
                return this._label;
            }
            /*string? */ set Label(value)
            {
                this._label = value;
            }
            /*string? */ get Name()
            {
                /*Claim?*/ let claim = this.FindFirst$1(this._nameClaimType);
                if (claim !== null)
                {
                    return claim.Value;
                }
                return null;
            }
            /*string */ get NameClaimType()
            {
                return this._nameClaimType;
            }
            /*string */ get RoleClaimType()
            {
                return this._roleClaimType;
            }
            /*ClaimsIdentity */ Clone()
            {
                return new $.$ssc.System.Security.Claims.ClaimsIdentity().$ctor$13(this, this._stringComparison);
            }
            /*void */ AddClaim(/*Claim*/ claim)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(claim, "claim");
                if ($.$spc.System.Object.ReferenceEquals(claim.Subject, this))
                {
                    this._instanceClaims.Add(claim);
                }
                else 
                {
                    this._instanceClaims.Add(claim.Clone$1(this));
                }
            }
            /*void */ AddClaims(/*IEnumerable<Claim?>*/ claims)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(claims, "claims");
                var $en2 = claims.System$Collections$Generic$IEnumerable$$$GetEnumerator();
                while ($en2.System$Collections$IEnumerator$MoveNext())
                {
                    var claim = $en2.System$Collections$Generic$IEnumerator$$$Current;
                    {
                        if (claim === null)
                        {
                            continue;
                        }
                        if ($.$spc.System.Object.ReferenceEquals(claim.Subject, this))
                        {
                            this._instanceClaims.Add(claim);
                        }
                        else 
                        {
                            this._instanceClaims.Add(claim.Clone$1(this));
                        }
                    }
                }
            }
            /*bool */ TryRemoveClaim(/*Claim?*/ claim)
            {
                if (claim === null)
                {
                    return false;
                }
                /*bool*/ let removed = false;
                for(/*int*/ let i = 0; i < this._instanceClaims.Count; i++)
                {
                    if ($.$spc.System.Object.ReferenceEquals(this._instanceClaims.get_Item(i), claim))
                    {
                        this._instanceClaims.RemoveAt(i);
                        removed = true;
                        break;
                    }
                }
                return removed;
            }
            /*void */ RemoveClaim(/*Claim?*/ claim)
            {
                if (!this.TryRemoveClaim(claim))
                {
                    throw new $.$spc.System.InvalidOperationException().$ctor$10($.$ssc.System.SR.Format($.$ssc.System.SR.InvalidOperation_ClaimCannotBeRemoved, claim));
                }
            }
            /*void */ SafeAddClaims(/*IEnumerable<Claim?>*/ claims)
            {
                var $en2 = claims.System$Collections$Generic$IEnumerable$$$GetEnumerator();
                while ($en2.System$Collections$IEnumerator$MoveNext())
                {
                    var claim = $en2.System$Collections$Generic$IEnumerator$$$Current;
                    {
                        if (claim === null)
                        {
                            continue;
                        }
                        if ($.$spc.System.Object.ReferenceEquals(claim.Subject, this))
                        {
                            this._instanceClaims.Add(claim);
                        }
                        else 
                        {
                            this._instanceClaims.Add(claim.Clone$1(this));
                        }
                    }
                }
            }
            /*void */ SafeAddClaim(/*Claim?*/ claim)
            {
                if (claim === null)
                {
                    return;
                }
                if ($.$spc.System.Object.ReferenceEquals(claim.Subject, this))
                {
                    this._instanceClaims.Add(claim);
                }
                else 
                {
                    this._instanceClaims.Add(claim.Clone$1(this));
                }
            }
            /*IEnumerable<Claim> */ FindAll(/*Predicate<Claim>*/ match)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(match, "match");
                return Core.call(this, match);
                /*IEnumerable<Claim>*/  function Core(/*Predicate<Claim>*/ match)
                {
                    return new ($.$spc.NetJs.YieldToIterator$$($.$spc.System.Object))().$ctor$1(function*()
                    {
                        var $en4 = this.Claims.System$Collections$Generic$IEnumerable$$$GetEnumerator();
                        while ($en4.System$Collections$IEnumerator$MoveNext())
                        {
                            var claim = $en4.System$Collections$Generic$IEnumerator$$$Current;
                            {
                                if (match.Invoke(claim))
                                {
                                    yield claim;
                                }
                            }
                        }
                    }.bind(this));
                }
            }
            /*IEnumerable<Claim> */ FindAll$1(/*string*/ type)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(type, "type");
                return Core.call(this, type);
                /*IEnumerable<Claim>*/  function Core(/*string*/ type)
                {
                    return new ($.$spc.NetJs.YieldToIterator$$($.$spc.System.Object))().$ctor$1(function*()
                    {
                        var $en4 = this.Claims.System$Collections$Generic$IEnumerable$$$GetEnumerator();
                        while ($en4.System$Collections$IEnumerator$MoveNext())
                        {
                            var claim = $en4.System$Collections$Generic$IEnumerator$$$Current;
                            {
                                if (claim !== null)
                                {
                                    if ($.$spc.System.String.Equals$5(claim.Type, type, this._stringComparison))
                                    {
                                        yield claim;
                                    }
                                }
                            }
                        }
                    }.bind(this));
                }
            }
            /*Claim? */ FindFirst(/*Predicate<Claim>*/ match)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(match, "match");
                var $en2 = this.Claims.System$Collections$Generic$IEnumerable$$$GetEnumerator();
                while ($en2.System$Collections$IEnumerator$MoveNext())
                {
                    var claim = $en2.System$Collections$Generic$IEnumerator$$$Current;
                    {
                        if (match.Invoke(claim))
                        {
                            return claim;
                        }
                    }
                }
                return null;
            }
            /*Claim? */ FindFirst$1(/*string*/ type)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(type, "type");
                var $en2 = this.Claims.System$Collections$Generic$IEnumerable$$$GetEnumerator();
                while ($en2.System$Collections$IEnumerator$MoveNext())
                {
                    var claim = $en2.System$Collections$Generic$IEnumerator$$$Current;
                    {
                        if (claim !== null)
                        {
                            if ($.$spc.System.String.Equals$5(claim.Type, type, this._stringComparison))
                            {
                                return claim;
                            }
                        }
                    }
                }
                return null;
            }
            /*bool */ HasClaim(/*Predicate<Claim>*/ match)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(match, "match");
                var $en2 = this.Claims.System$Collections$Generic$IEnumerable$$$GetEnumerator();
                while ($en2.System$Collections$IEnumerator$MoveNext())
                {
                    var claim = $en2.System$Collections$Generic$IEnumerator$$$Current;
                    {
                        if (match.Invoke(claim))
                        {
                            return true;
                        }
                    }
                }
                return false;
            }
            /*bool */ HasClaim$1(/*string*/ type, /*string*/ value)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(type, "type");
                $.$spc.System.ArgumentNullException.ThrowIfNull(value, "value");
                var $en2 = this.Claims.System$Collections$Generic$IEnumerable$$$GetEnumerator();
                while ($en2.System$Collections$IEnumerator$MoveNext())
                {
                    var claim = $en2.System$Collections$Generic$IEnumerator$$$Current;
                    {
                        if (claim !== null && $.$spc.System.String.Equals$5(claim.Type, type, this._stringComparison) && $.$spc.System.String.Equals$5(claim.Value, value, 4/*StringComparison.Ordinal*/))
                        {
                            return true;
                        }
                    }
                }
                return false;
            }
            /*void */ Initialize(/*ClaimsIdentity*/ other)
            {
                if (other._actor !== null)
                {
                    this._actor = other._actor.Clone();
                }
                this._authenticationType = other._authenticationType;
                this._bootstrapContext = other._bootstrapContext;
                this._label = other._label;
                this._nameClaimType = other._nameClaimType;
                this._roleClaimType = other._roleClaimType;
                if (other._userSerializationData !== null)
                {
                    this._userSerializationData = $.$as(other._userSerializationData.Clone(), $.$typeArray($.$spc.System.Byte));
                }
                this.SafeAddClaims(other._instanceClaims);
            }
            /*void */ Initialize$1(/*BinaryReader*/ reader)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(reader, "reader");
                /*SerializationMask*/ let mask = $.$cast(reader.ReadInt32(), $.$ssc.System.Security.Claims.ClaimsIdentity.SerializationMask);
                /*int*/ let numPropertiesRead = 0;
                /*int*/ let numPropertiesToRead = reader.ReadInt32();
                if ((mask & 1/*SerializationMask.AuthenticationType*/) === 1/*SerializationMask.AuthenticationType*/)
                {
                    this._authenticationType = reader.ReadString();
                    numPropertiesRead++;
                }
                if ((mask & 2/*SerializationMask.BootstrapConext*/) === 2/*SerializationMask.BootstrapConext*/)
                {
                    this._bootstrapContext = reader.ReadString();
                    numPropertiesRead++;
                }
                if ((mask & 4/*SerializationMask.NameClaimType*/) === 4/*SerializationMask.NameClaimType*/)
                {
                    this._nameClaimType = reader.ReadString();
                    numPropertiesRead++;
                }
                else 
                {
                    this._nameClaimType = "http://schemas.xmlsoap.org/ws/2005/05/identity/claims/name"/*ClaimsIdentity.DefaultNameClaimType*/;
                }
                if ((mask & 8/*SerializationMask.RoleClaimType*/) === 8/*SerializationMask.RoleClaimType*/)
                {
                    this._roleClaimType = reader.ReadString();
                    numPropertiesRead++;
                }
                else 
                {
                    this._roleClaimType = "http://schemas.microsoft.com/ws/2008/06/identity/claims/role"/*ClaimsIdentity.DefaultRoleClaimType*/;
                }
                if ((mask & 32/*SerializationMask.HasLabel*/) === 32/*SerializationMask.HasLabel*/)
                {
                    this._label = reader.ReadString();
                    numPropertiesRead++;
                }
                if ((mask & 16/*SerializationMask.HasClaims*/) === 16/*SerializationMask.HasClaims*/)
                {
                    /*int*/ let numberOfClaims = reader.ReadInt32();
                    for(/*int*/ let index = 0; index < numberOfClaims; index++)
                    {
                        this._instanceClaims.Add(this.CreateClaim(reader));
                    }
                    numPropertiesRead++;
                }
                if ((mask & 64/*SerializationMask.Actor*/) === 64/*SerializationMask.Actor*/)
                {
                    this._actor = new $.$ssc.System.Security.Claims.ClaimsIdentity().$ctor$10(reader);
                    numPropertiesRead++;
                }
                if ((mask & 128/*SerializationMask.UserData*/) === 128/*SerializationMask.UserData*/)
                {
                    /*int*/ let cb = reader.ReadInt32();
                    this._userSerializationData = reader.ReadBytes(cb);
                    numPropertiesRead++;
                }
                for(/*int*/ let i = numPropertiesRead; i < numPropertiesToRead; i++)
                {
                    reader.ReadString();
                }
            }
            /*Claim */ CreateClaim(/*BinaryReader*/ reader)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(reader, "reader");
                return new $.$ssc.System.Security.Claims.Claim().$ctor$2(reader, this);
            }
            /*void */ WriteTo(/*BinaryWriter*/ writer)
            {
                this.WriteTo$1(writer, null);
            }
            /*void */ WriteTo$1(/*BinaryWriter*/ writer, /*byte[]?*/ userData)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(writer, "writer");
                /*int*/ let numberOfPropertiesWritten = 0;
                /*var*/ let mask = 0/*SerializationMask.None*/;
                if ($.$spc.System.String.op_Inequality(this._authenticationType, null))
                {
                    mask |= 1/*SerializationMask.AuthenticationType*/;
                    numberOfPropertiesWritten++;
                }
                if (this._bootstrapContext !== null)
                {
                    if ($.$is(this._bootstrapContext, $.$spc.System.String))
                    {
                        mask |= 2/*SerializationMask.BootstrapConext*/;
                        numberOfPropertiesWritten++;
                    }
                }
                if (!$.$spc.System.String.Equals$5(this._nameClaimType, "http://schemas.xmlsoap.org/ws/2005/05/identity/claims/name"/*ClaimsIdentity.DefaultNameClaimType*/, 4/*StringComparison.Ordinal*/))
                {
                    mask |= 4/*SerializationMask.NameClaimType*/;
                    numberOfPropertiesWritten++;
                }
                if (!$.$spc.System.String.Equals$5(this._roleClaimType, "http://schemas.microsoft.com/ws/2008/06/identity/claims/role"/*ClaimsIdentity.DefaultRoleClaimType*/, 4/*StringComparison.Ordinal*/))
                {
                    mask |= 8/*SerializationMask.RoleClaimType*/;
                    numberOfPropertiesWritten++;
                }
                if (!$.$spc.System.String.IsNullOrWhiteSpace(this._label))
                {
                    mask |= 32/*SerializationMask.HasLabel*/;
                    numberOfPropertiesWritten++;
                }
                if (this._instanceClaims.Count > 0)
                {
                    mask |= 16/*SerializationMask.HasClaims*/;
                    numberOfPropertiesWritten++;
                }
                if (this._actor !== null)
                {
                    mask |= 64/*SerializationMask.Actor*/;
                    numberOfPropertiesWritten++;
                }
                if (userData !== null && userData.length > 0)
                {
                    numberOfPropertiesWritten++;
                    mask |= 128/*SerializationMask.UserData*/;
                }
                writer.Write$12(mask);
                writer.Write$12(numberOfPropertiesWritten);
                if ((mask & 1/*SerializationMask.AuthenticationType*/) === 1/*SerializationMask.AuthenticationType*/)
                {
                    writer.Write$18(this._authenticationType);
                }
                if ((mask & 2/*SerializationMask.BootstrapConext*/) === 2/*SerializationMask.BootstrapConext*/)
                {
                    writer.Write$18($.$cast(this._bootstrapContext, $.$spc.System.String));
                }
                if ((mask & 4/*SerializationMask.NameClaimType*/) === 4/*SerializationMask.NameClaimType*/)
                {
                    writer.Write$18(this._nameClaimType);
                }
                if ((mask & 8/*SerializationMask.RoleClaimType*/) === 8/*SerializationMask.RoleClaimType*/)
                {
                    writer.Write$18(this._roleClaimType);
                }
                if ((mask & 32/*SerializationMask.HasLabel*/) === 32/*SerializationMask.HasLabel*/)
                {
                    writer.Write$18(this._label);
                }
                if ((mask & 16/*SerializationMask.HasClaims*/) === 16/*SerializationMask.HasClaims*/)
                {
                    writer.Write$12(this._instanceClaims.Count);
                    var $en3 = this._instanceClaims.GetEnumerator();
                    while ($en3.MoveNext())
                    {
                        var claim = $en3.Current;
                        {
                            claim.WriteTo(writer);
                        }
                    }
                }
                if ((mask & 64/*SerializationMask.Actor*/) === 64/*SerializationMask.Actor*/)
                {
                    this._actor.WriteTo(writer);
                }
                if ((mask & 128/*SerializationMask.UserData*/) === 128/*SerializationMask.UserData*/)
                {
                    writer.Write$12(userData.length);
                    writer.Write$3(userData);
                }
                writer.Flush();
            }
            /*bool */ IsCircular(/*ClaimsIdentity*/ subject)
            {
                if ($.$spc.System.Object.ReferenceEquals(this, subject))
                {
                    return true;
                }
                /*ClaimsIdentity*/ let currSubject = subject;
                while(currSubject.Actor !== null)
                {
                    if ($.$spc.System.Object.ReferenceEquals(this, currSubject.Actor))
                    {
                        return true;
                    }
                    currSubject = currSubject.Actor;
                }
                return false;
            }
            /*void */ GetObjectData(/*SerializationInfo*/ info, /*StreamingContext*/ context)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*string */ DebuggerToString()
            {
                /*int*/ let claimsCount = 0;
                var $en2 = this.Claims.System$Collections$Generic$IEnumerable$$$GetEnumerator();
                while ($en2.System$Collections$IEnumerator$MoveNext())
                {
                    var item = $en2.System$Collections$Generic$IEnumerator$$$Current;
                    {
                        claimsCount++;
                    }
                }
                /*string*/ let debugText = `IsAuthenticated = ${(this.IsAuthenticated ? "true" : "false")}`;
                if ($.$spc.System.String.op_Inequality(this.Name, null))
                {
                    debugText += `, Name = ${this.Name}`;
                }
                if (claimsCount > 0)
                {
                    debugText += `, Claims = ${claimsCount}`;
                }
                return debugText;
            }
            static /*void */ ValidateStringComparison(/*StringComparison*/ stringComparison)
            {
                switch(stringComparison)
                {
                    case 4/*StringComparison.Ordinal*/:
                    case 5/*StringComparison.OrdinalIgnoreCase*/:
                    case 2/*StringComparison.InvariantCulture*/:
                    case 3/*StringComparison.InvariantCultureIgnoreCase*/:
                    break;
                    default:
                    throw new $.$spc.System.ArgumentException().$ctor$13($.$ssc.System.SR.ArgumentException_StringComparisonCultureAware, "stringComparison");
                }
            }
            //Generated interface implemetation for System.Security.Principal.IIdentity.Name.get
            get System$Security$Principal$IIdentity$Name()
            {
                return this.Name;
            }
            //Generated interface implemetation for System.Security.Principal.IIdentity.AuthenticationType.get
            get System$Security$Principal$IIdentity$AuthenticationType()
            {
                return this.AuthenticationType;
            }
            //Generated interface implemetation for System.Security.Principal.IIdentity.IsAuthenticated.get
            get System$Security$Principal$IIdentity$IsAuthenticated()
            {
                return this.IsAuthenticated;
            }
            //default member initializer
            constructor()
            {
                super();
                this._instanceClaims = new ($.$spc.System.Collections.Generic.List$$($.$ssc.System.Security.Claims.Claim))().$ctor$1();
                this._nameClaimType = "http://schemas.xmlsoap.org/ws/2005/05/identity/claims/name";
                this._roleClaimType = "http://schemas.microsoft.com/ws/2008/06/identity/claims/role";
            }
            //Static Initializer
            static $sinit()
            {
                {
                    this.DefaultIssuer = "LOCAL AUTHORITY";
                }
                {
                    this.DefaultNameClaimType = "http://schemas.xmlsoap.org/ws/2005/05/identity/claims/name";
                }
                {
                    this.DefaultRoleClaimType = "http://schemas.microsoft.com/ws/2008/06/identity/claims/role";
                }
            }
            static $h = 306076;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":1310721,"g":{"r":0,"d":0,"h":137439259548,"f":129},"n":"AuthenticationType","d":306076,"h":133144292252,"f":129},{"p":262145,"g":{"r":0,"d":0,"h":146029194140,"f":129},"n":"IsAuthenticated","d":306076,"h":141734226844,"f":129},{"p":306076,"g":{"r":0,"d":0,"h":154619128732,"f":1},"s":{"r":0,"d":0,"h":158914096028,"f":1},"n":"Actor","d":306076,"h":150324161436,"f":1},{"p":131073,"g":{"r":0,"d":0,"h":167504030620,"f":1},"s":{"r":0,"d":0,"h":171798997916,"f":1},"n":"BootstrapContext","d":306076,"h":163209063324,"f":1},{"p":$.$spc.System.Collections.Generic.IEnumerable$$($.$ssc.System.Security.Claims.Claim).$h,"g":{"r":0,"d":0,"h":180388932508,"f":129},"n":"Claims","d":306076,"h":176093965212,"f":129},{"p":0,"g":{"r":0,"d":0,"h":193273834396,"f":132},"n":"CustomSerializationData","d":306076,"h":188978867100,"f":132},{"p":$.$spc.System.Collections.Generic.List$$($.$spc.System.Collections.Generic.List$$($.$ssc.System.Security.Claims.Claim)).$h,"g":{"r":0,"d":0,"h":201863768988,"f":8},"n":"ExternalClaims","d":306076,"h":197568801692,"f":8},{"p":1310721,"g":{"r":0,"d":0,"h":210453703580,"f":1},"s":{"r":0,"d":0,"h":214748670876,"f":1},"n":"Label","d":306076,"h":206158736284,"f":1},{"p":1310721,"g":{"r":0,"d":0,"h":223338605468,"f":129},"n":"Name","d":306076,"h":219043638172,"f":129},{"p":1310721,"g":{"r":0,"d":0,"h":231928540060,"f":1},"n":"NameClaimType","d":306076,"h":227633572764,"f":1},{"p":1310721,"g":{"r":0,"d":0,"h":240518474652,"f":1},"n":"RoleClaimType","d":306076,"h":236223507356,"f":1}],"m":[{"r":$.$spc.System.Collections.Generic.IEnumerable$$($.$ssc.System.Security.Claims.Claim).$h,"n":"CombinedClaimsIterator","d":306076,"h":184683899804,"f":2},{"r":306076,"n":"Clone","d":306076,"h":244813441948,"f":129},{"r":65537,"p":[{"n":"claim","p":175004}],"n":"AddClaim","d":306076,"h":249108409244,"f":129},{"r":65537,"p":[{"n":"claims","p":$.$spc.System.Collections.Generic.IEnumerable$$($.$ssc.System.Security.Claims.Claim).$h}],"n":"AddClaims","d":306076,"h":253403376540,"f":129},{"r":262145,"p":[{"n":"claim","p":175004}],"n":"TryRemoveClaim","d":306076,"h":257698343836,"f":129},{"r":65537,"p":[{"n":"claim","p":175004}],"n":"RemoveClaim","d":306076,"h":261993311132,"f":129},{"r":65537,"p":[{"n":"claims","p":$.$spc.System.Collections.Generic.IEnumerable$$($.$ssc.System.Security.Claims.Claim).$h}],"n":"SafeAddClaims","d":306076,"h":266288278428,"f":2},{"r":65537,"p":[{"n":"claim","p":175004}],"n":"SafeAddClaim","d":306076,"h":270583245724,"f":2},{"r":$.$spc.System.Collections.Generic.IEnumerable$$($.$ssc.System.Security.Claims.Claim).$h,"p":[{"n":"match","p":$.$spc.System.Predicate$$($.$ssc.System.Security.Claims.Claim).$h}],"n":"FindAll","d":306076,"h":274878213020,"f":129},{"r":$.$spc.System.Collections.Generic.IEnumerable$$($.$ssc.System.Security.Claims.Claim).$h,"p":[{"n":"type","p":1310721}],"n":"FindAll","o":"@$1","d":306076,"h":279173180316,"f":129},{"r":175004,"p":[{"n":"match","p":$.$spc.System.Predicate$$($.$ssc.System.Security.Claims.Claim).$h}],"n":"FindFirst","d":306076,"h":283468147612,"f":129},{"r":175004,"p":[{"n":"type","p":1310721}],"n":"FindFirst","o":"@$1","d":306076,"h":287763114908,"f":129},{"r":262145,"p":[{"n":"match","p":$.$spc.System.Predicate$$($.$ssc.System.Security.Claims.Claim).$h}],"n":"HasClaim","d":306076,"h":292058082204,"f":129},{"r":262145,"p":[{"n":"type","p":1310721},{"n":"value","p":1310721}],"n":"HasClaim","o":"@$1","d":306076,"h":296353049500,"f":129},{"r":65537,"p":[{"n":"other","p":306076}],"n":"Initialize","d":306076,"h":300648016796,"f":2},{"r":65537,"p":[{"n":"reader","p":58392577}],"n":"Initialize","o":"@$1","d":306076,"h":304942984092,"f":2},{"r":175004,"p":[{"n":"reader","p":58392577}],"n":"CreateClaim","d":306076,"h":309237951388,"f":132},{"r":65537,"p":[{"n":"writer","p":58458113}],"n":"WriteTo","d":306076,"h":313532918684,"f":129},{"r":65537,"p":[{"n":"writer","p":58458113},{"n":"userData","p":0}],"n":"WriteTo","o":"@$1","d":306076,"h":317827885980,"f":132},{"r":262145,"p":[{"n":"subject","p":306076}],"n":"IsCircular","d":306076,"h":322122853276,"f":2},{"r":65537,"p":[{"n":"info","p":113967105},{"n":"context","p":114098177}],"n":"GetObjectData","d":306076,"h":326417820572,"f":132},{"r":1310721,"n":"DebuggerToString","d":306076,"h":330712787868,"f":8},{"r":65537,"p":[{"n":"stringComparison","p":119472129}],"n":"ValidateStringComparison","d":306076,"h":335007755164,"f":34}],"l":[{"t":0,"n":"_userSerializationData","d":306076,"h":8590240668,"f":2},{"t":306076,"n":"_actor","d":306076,"h":12885207964,"f":2},{"t":1310721,"n":"_authenticationType","d":306076,"h":17180175260,"f":2},{"t":131073,"n":"_bootstrapContext","d":306076,"h":21475142556,"f":2},{"t":$.$spc.System.Collections.Generic.List$$($.$spc.System.Collections.Generic.List$$($.$ssc.System.Security.Claims.Claim)).$h,"n":"_externalClaims","d":306076,"h":25770109852,"f":2},{"t":1310721,"n":"_label","d":306076,"h":30065077148,"f":2},{"t":$.$spc.System.Collections.Generic.List$$($.$ssc.System.Security.Claims.Claim).$h,"n":"_instanceClaims","d":306076,"h":34360044444,"f":2},{"t":1310721,"n":"_nameClaimType","d":306076,"h":38655011740,"f":2},{"t":1310721,"n":"_roleClaimType","d":306076,"h":42949979036,"f":2},{"t":119472129,"n":"_stringComparison","d":306076,"h":47244946332,"f":2},{"t":1310721,"n":"DefaultIssuer","d":306076,"h":51539913628,"f":33},{"t":1310721,"n":"DefaultNameClaimType","d":306076,"h":55834880924,"f":33},{"t":1310721,"n":"DefaultRoleClaimType","d":306076,"h":60129848220,"f":33}],"c":[{"n":".ctor","o":"$ctor$1","d":306076,"h":64424815516,"f":1},{"p":[{"n":"identity","p":117047297}],"n":".ctor","o":"$ctor$2","d":306076,"h":68719782812,"f":1},{"p":[{"n":"claims","p":$.$spc.System.Collections.Generic.IEnumerable$$($.$ssc.System.Security.Claims.Claim).$h}],"n":".ctor","o":"$ctor$3","d":306076,"h":73014750108,"f":1},{"p":[{"n":"authenticationType","p":1310721}],"n":".ctor","o":"$ctor$4","d":306076,"h":77309717404,"f":1},{"p":[{"n":"claims","p":$.$spc.System.Collections.Generic.IEnumerable$$($.$ssc.System.Security.Claims.Claim).$h},{"n":"authenticationType","p":1310721}],"n":".ctor","o":"$ctor$5","d":306076,"h":81604684700,"f":1},{"p":[{"n":"identity","p":117047297},{"n":"claims","p":$.$spc.System.Collections.Generic.IEnumerable$$($.$ssc.System.Security.Claims.Claim).$h}],"n":".ctor","o":"$ctor$6","d":306076,"h":85899651996,"f":1},{"p":[{"n":"authenticationType","p":1310721},{"n":"nameType","p":1310721},{"n":"roleType","p":1310721}],"n":".ctor","o":"$ctor$7","d":306076,"h":90194619292,"f":1},{"p":[{"n":"claims","p":$.$spc.System.Collections.Generic.IEnumerable$$($.$ssc.System.Security.Claims.Claim).$h},{"n":"authenticationType","p":1310721},{"n":"nameType","p":1310721},{"n":"roleType","p":1310721}],"n":".ctor","o":"$ctor$8","d":306076,"h":94489586588,"f":1},{"p":[{"n":"identity","p":117047297},{"n":"claims","p":$.$spc.System.Collections.Generic.IEnumerable$$($.$ssc.System.Security.Claims.Claim).$h},{"n":"authenticationType","p":1310721},{"n":"nameType","p":1310721},{"n":"roleType","p":1310721}],"n":".ctor","o":"$ctor$9","d":306076,"h":98784553884,"f":1},{"p":[{"n":"reader","p":58392577}],"n":".ctor","o":"$ctor$10","d":306076,"h":103079521180,"f":1},{"p":[{"n":"reader","p":58392577},{"n":"stringComparison","p":119472129}],"n":".ctor","o":"$ctor$11","d":306076,"h":107374488476,"f":1},{"p":[{"n":"other","p":306076}],"n":".ctor","o":"$ctor$12","d":306076,"h":111669455772,"f":4},{"p":[{"n":"other","p":306076},{"n":"stringComparison","p":119472129}],"n":".ctor","o":"$ctor$13","d":306076,"h":115964423068,"f":4},{"p":[{"n":"identity","p":117047297,"f":65},{"n":"claims","p":$.$spc.System.Collections.Generic.IEnumerable$$($.$ssc.System.Security.Claims.Claim).$h,"f":65},{"n":"authenticationType","p":1310721,"f":65},{"n":"nameType","p":1310721,"f":65},{"n":"roleType","p":1310721,"f":65},{"n":"stringComparison","p":119472129,"f":65,"v":5}],"n":".ctor","o":"$ctor$14","d":306076,"h":120259390364,"f":1},{"p":[{"n":"info","p":113967105},{"n":"context","p":114098177}],"n":".ctor","o":"$ctor$15","d":306076,"h":124554357660,"f":4,"a":[{"t":70909953,"c":8660844545,"a":[{"v":"This API supports obsolete formatter-based serialization. It should not be called or extended by application code.","t":1310721}],"n":[{"n":"DiagnosticId","v":"SYSLIB0051","t":1310721},{"n":"UrlFormat","v":"https://aka.ms/dotnet-warnings/{0}","t":1310721}]},{"t":33161217,"c":4328128513,"a":[{"v":1,"t":33226753}]}]},{"p":[{"n":"info","p":113967105}],"n":".ctor","o":"$ctor$16","d":306076,"h":128849324956,"f":4,"a":[{"t":70909953,"c":8660844545,"a":[{"v":"This API supports obsolete formatter-based serialization. It should not be called or extended by application code.","t":1310721}],"n":[{"n":"DiagnosticId","v":"SYSLIB0051","t":1310721},{"n":"UrlFormat","v":"https://aka.ms/dotnet-warnings/{0}","t":1310721}]},{"t":33161217,"c":4328128513,"a":[{"v":1,"t":33226753}]}]}],"i":[117047297],"j":[371612],"h":306076,"a":[{"t":37552129,"c":8627486721,"a":[{"v":"{DebuggerToString(),nq}","t":1310721}]}]}; }
            static get $b() { return $.$spc.System.Object; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.Security.Principal.IIdentity ]; }
            static get $fullName() { return `System.Security.Claims.ClaimsIdentity`; }
        });
        
        $asm.$cls("$ssc.System.Security.Principal.GenericPrincipal", ($self) => class GenericPrincipal extends $.$ssc.System.Security.Claims.ClaimsPrincipal
        {
            /*IIdentity*/ m_identity = null;
            /*string[]?*/ m_roles = null;
            $ctor$7(/*IIdentity*/ identity, /*string[]?*/ roles)
            {
                super.$ctor$2();
                {
                    $.$spc.System.ArgumentNullException.ThrowIfNull(identity, "identity");
                    this.m_identity = identity;
                    if (roles !== null)
                    {
                        this.m_roles = $.$cast(roles.Clone(), $.$typeArray($.$spc.System.String));
                    }
                    else 
                    {
                        this.m_roles = null;
                    }
                    this.AddIdentityWithRoles(this.m_identity, this.m_roles);
                }
                return this;
            }
            /*void */ AddIdentityWithRoles(/*IIdentity*/ identity, /*string[]?*/ roles)
            {
                let claimsIdentity;
                if ($.$is(identity, $.$ssc.System.Security.Claims.ClaimsIdentity, { set $v(v){ claimsIdentity = v; } }))
                {
                    claimsIdentity = claimsIdentity.Clone();
                }
                else 
                {
                    claimsIdentity = new $.$ssc.System.Security.Claims.ClaimsIdentity().$ctor$2(identity);
                }
                if (roles !== null && roles.length > 0)
                {
                    /*List<Claim>*/ let roleClaims = new ($.$spc.System.Collections.Generic.List$$($.$ssc.System.Security.Claims.Claim))().$ctor$2(roles.length);
                    let $i1 = 0;
                    let $arr1 = roles;
                    while ($i1 < $arr1.length)
                    {
                        let role = $arr1[$i1++];
                        if (!$.$spc.System.String.IsNullOrWhiteSpace(role))
                        {
                            roleClaims.Add(new $.$ssc.System.Security.Claims.Claim().$ctor$7(claimsIdentity.RoleClaimType, role, "http://www.w3.org/2001/XMLSchema#string"/*ClaimValueTypes.String*/, "LOCAL AUTHORITY"/*ClaimsIdentity.DefaultIssuer*/, "LOCAL AUTHORITY"/*ClaimsIdentity.DefaultIssuer*/, claimsIdentity));
                        }
                    }
                    claimsIdentity.ExternalClaims.Add(roleClaims);
                }
                super.AddIdentity(claimsIdentity);
            }
            /*IIdentity */ get Identity()
            {
                return this.m_identity;
            }
            /*bool */ IsInRole(/*string?*/ role)
            {
                if ($.$spc.System.String.op_Equality(role, null) || this.m_roles === null)
                {
                    return false;
                }
                for(/*int*/ let i = 0; i < this.m_roles.length; ++i)
                {
                    if ($.$spc.System.String.Equals$5($.$spc.System.Array.$ReadT1.call(this.m_roles, i), role, 5/*StringComparison.OrdinalIgnoreCase*/))
                    {
                        return true;
                    }
                }
                return super.IsInRole(role);
            }
            static /*GenericPrincipal */ GetDefaultInstance()
            {
                return new $.$ssc.System.Security.Principal.GenericPrincipal().$ctor$7(new $.$ssc.System.Security.Principal.GenericIdentity().$ctor$17($.$spc.System.String.Empty), $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$spc.System.String), [$.$spc.System.String.Empty], [-1], null));
            }
            static $h = 764828;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":437148,"p":[{"p":117047297,"g":{"r":0,"d":0,"h":25770568604,"f":32769},"n":"Identity","d":764828,"h":21475601308,"f":32769}],"m":[{"r":65537,"p":[{"n":"identity","p":117047297},{"n":"roles","p":0}],"n":"AddIdentityWithRoles","d":764828,"h":17180634012,"f":2},{"r":262145,"p":[{"n":"role","p":1310721}],"n":"IsInRole","d":764828,"h":30065535900,"f":32769},{"r":764828,"n":"GetDefaultInstance","d":764828,"h":34360503196,"f":34}],"l":[{"t":117047297,"n":"m_identity","d":764828,"h":4295732124,"f":2},{"t":0,"n":"m_roles","d":764828,"h":8590699420,"f":2}],"c":[{"p":[{"n":"identity","p":117047297},{"n":"roles","p":0}],"n":".ctor","o":"$ctor$7","d":764828,"h":12885666716,"f":1}],"i":[117112833],"h":764828}; }
            static get $b() { return $.$ssc.System.Security.Claims.ClaimsPrincipal; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.Security.Principal.IPrincipal ]; }
            static get $fullName() { return `System.Security.Principal.GenericPrincipal`; }
        });
        
        $asm.$cls("$ssc.System.Security.Principal.GenericIdentity", ($self) => class GenericIdentity extends $.$ssc.System.Security.Claims.ClaimsIdentity
        {
            /*string*/ m_name = null;
            /*string*/ m_type = null;
            $ctor$17(/*string*/ name)
            {
                super.$ctor$14(null, null, null, null, null, 5);
                {
                    $.$spc.System.ArgumentNullException.ThrowIfNull(name, "name");
                    this.m_name = name;
                    this.m_type = "";
                    this.AddNameClaim();
                }
                return this;
            }
            $ctor$18(/*string*/ name, /*string*/ type)
            {
                super.$ctor$14(null, null, null, null, null, 5);
                {
                    $.$spc.System.ArgumentNullException.ThrowIfNull(name, "name");
                    $.$spc.System.ArgumentNullException.ThrowIfNull(type, "type");
                    this.m_name = name;
                    this.m_type = type;
                    this.AddNameClaim();
                }
                return this;
            }
            $ctor$19(/*GenericIdentity*/ identity)
            {
                super.$ctor$12(identity);
                {
                    this.m_name = identity.m_name;
                    this.m_type = identity.m_type;
                }
                return this;
            }
            /*ClaimsIdentity */ Clone()
            {
                return new $.$ssc.System.Security.Principal.GenericIdentity().$ctor$19(this);
            }
            /*IEnumerable<Claim> */ get Claims()
            {
                return super.Claims;
            }
            /*string */ get Name()
            {
                return this.m_name;
            }
            /*string */ get AuthenticationType()
            {
                return this.m_type;
            }
            /*bool */ get IsAuthenticated()
            {
                return !$.$spc.System.String.Equals$2.call(this.m_name, "");
            }
            /*void */ AddNameClaim()
            {
                if ($.$spc.System.String.op_Inequality(this.m_name, null))
                {
                    super.AddClaim(new $.$ssc.System.Security.Claims.Claim().$ctor$7(super.NameClaimType, this.m_name, "http://www.w3.org/2001/XMLSchema#string"/*ClaimValueTypes.String*/, "LOCAL AUTHORITY"/*ClaimsIdentity.DefaultIssuer*/, "LOCAL AUTHORITY"/*ClaimsIdentity.DefaultIssuer*/, this));
                }
            }
            static $h = 699292;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":306076,"p":[{"p":$.$spc.System.Collections.Generic.IEnumerable$$($.$ssc.System.Security.Claims.Claim).$h,"g":{"r":0,"d":0,"h":34360437660,"f":32769},"n":"Claims","d":699292,"h":30065470364,"f":32769},{"p":1310721,"g":{"r":0,"d":0,"h":42950372252,"f":32769},"n":"Name","d":699292,"h":38655404956,"f":32769},{"p":1310721,"g":{"r":0,"d":0,"h":51540306844,"f":32769},"n":"AuthenticationType","d":699292,"h":47245339548,"f":32769},{"p":262145,"g":{"r":0,"d":0,"h":60130241436,"f":32769},"n":"IsAuthenticated","d":699292,"h":55835274140,"f":32769}],"m":[{"r":306076,"n":"Clone","d":699292,"h":25770503068,"f":32769},{"r":65537,"n":"AddNameClaim","d":699292,"h":64425208732,"f":2}],"l":[{"t":1310721,"n":"m_name","d":699292,"h":4295666588,"f":2},{"t":1310721,"n":"m_type","d":699292,"h":8590633884,"f":2}],"c":[{"p":[{"n":"name","p":1310721}],"n":".ctor","o":"$ctor$17","d":699292,"h":12885601180,"f":1},{"p":[{"n":"name","p":1310721},{"n":"type","p":1310721}],"n":".ctor","o":"$ctor$18","d":699292,"h":17180568476,"f":1},{"p":[{"n":"identity","p":699292}],"n":".ctor","o":"$ctor$19","d":699292,"h":21475535772,"f":4}],"i":[117047297],"h":699292}; }
            static get $b() { return $.$ssc.System.Security.Claims.ClaimsIdentity; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.Security.Principal.IIdentity ]; }
            static get $fullName() { return `System.Security.Principal.GenericIdentity`; }
        });
	});
})(window, window.NetJs.$boot(), ...window.NetJs.$require("NetJs.System.Private.CoreLib", "NetJs.System.Collections", "NetJs.System.Memory", "NetJs.System.Private.Uri", "NetJs.System.Threading.Thread", "NetJs.System.Runtime"))