
(function ($global, $, $spc, $sc, $sm, $spu, $sr, $stt) {
    "use strict";
    let _;
    
    
    
	$.$asm(
    "NetJs.System.Security.Claims", 
    {"h":53947,"f":"System.Security.Claims","v":"1.0.35.0","a":[{"t":115146753,"c":13000048641,"a":[{"v":".NETCoreApp,Version=v10.0","t":1310721}],"n":[{"n":"FrameworkDisplayName","v":".NET 10.0","t":1310721}]},{"t":73596929,"c":4368564225,"a":[{"v":"SIT","t":1310721}]},{"t":73662465,"c":4368629761,"a":[{"v":"Debug","t":1310721}]},{"t":74121217,"c":4369088513,"a":[{"v":"1.0.35.0","t":1310721}]},{"t":74252289,"c":4369219585,"a":[{"v":"1.0.35\u002Bf7a34a6f78fee11131301a9f55ca16a968616013","t":1310721}]},{"t":75104257,"c":4370071553,"a":[{"v":"NetJs.System.Security.Claims","t":1310721}]},{"t":75235329,"c":4370202625,"a":[{"v":"NetJs.System.Security.Claims","t":1310721}]},{"t":75366401,"c":4370333697,"a":[{"v":"1.0.35.0","t":1310721}]},{"t":115212289,"c":4410179585,"a":[{"v":"browser1.0","t":1310721}]},{"t":114950145,"c":4409917441,"a":[{"v":"browser1.0","t":1310721}]}],"m":[]},
    function($asm)
	{
        
        
        $asm.$cls("$ssc.System.Obsoletions", ($self) => class Obsoletions
        {
            /*string*/ static SharedUrlFormat = null;
            /*string*/ static SystemTextEncodingUTF7Message = null;
            /*string*/ static SystemTextEncodingUTF7DiagId = null;
            /*string*/ static PrincipalPermissionAttributeMessage = null;
            /*string*/ static PrincipalPermissionAttributeDiagId = null;
            /*string*/ static CodeAccessSecurityMessage = null;
            /*string*/ static CodeAccessSecurityDiagId = null;
            /*string*/ static ConstrainedExecutionRegionMessage = null;
            /*string*/ static ConstrainedExecutionRegionDiagId = null;
            /*string*/ static GlobalAssemblyCacheMessage = null;
            /*string*/ static GlobalAssemblyCacheDiagId = null;
            /*string*/ static ThreadAbortMessage = null;
            /*string*/ static ThreadResetAbortMessage = null;
            /*string*/ static ThreadAbortDiagId = null;
            /*string*/ static DefaultCryptoAlgorithmsMessage = null;
            /*string*/ static DefaultCryptoAlgorithmsDiagId = null;
            /*string*/ static CreatePdbGeneratorMessage = null;
            /*string*/ static CreatePdbGeneratorDiagId = null;
            /*string*/ static AuthenticationManagerMessage = null;
            /*string*/ static AuthenticationManagerDiagId = null;
            /*string*/ static RemotingApisMessage = null;
            /*string*/ static RemotingApisDiagId = null;
            /*string*/ static BinaryFormatterMessage = null;
            /*string*/ static BinaryFormatterDiagId = null;
            /*string*/ static CodeBaseMessage = null;
            /*string*/ static CodeBaseDiagId = null;
            /*string*/ static EscapeUriStringMessage = null;
            /*string*/ static EscapeUriStringDiagId = null;
            /*string*/ static WebRequestMessage = null;
            /*string*/ static WebRequestDiagId = null;
            /*string*/ static DisablePrivateReflectionAttributeMessage = null;
            /*string*/ static DisablePrivateReflectionAttributeDiagId = null;
            /*string*/ static GetContextInfoMessage = null;
            /*string*/ static GetContextInfoDiagId = null;
            /*string*/ static StrongNameKeyPairMessage = null;
            /*string*/ static StrongNameKeyPairDiagId = null;
            /*string*/ static ReflectionOnlyLoadingMessage = null;
            /*string*/ static ReflectionOnlyLoadingDiagId = null;
            /*string*/ static RuntimeEnvironmentMessage = null;
            /*string*/ static RuntimeEnvironmentDiagId = null;
            /*string*/ static JsonSerializerOptionsIgnoreNullValuesMessage = null;
            /*string*/ static JsonSerializerOptionsIgnoreNullValuesDiagId = null;
            /*string*/ static DerivedCryptographicTypesMessage = null;
            /*string*/ static DerivedCryptographicTypesDiagId = null;
            /*string*/ static RijndaelMessage = null;
            /*string*/ static RijndaelDiagId = null;
            /*string*/ static RNGCryptoServiceProviderMessage = null;
            /*string*/ static RNGCryptoServiceProviderDiagId = null;
            /*string*/ static AppDomainCreateUnloadMessage = null;
            /*string*/ static AppDomainCreateUnloadDiagId = null;
            /*string*/ static SuppressIldasmAttributeMessage = null;
            /*string*/ static SuppressIldasmAttributeDiagId = null;
            /*string*/ static X509CertificateImmutableMessage = null;
            /*string*/ static X509CertificateImmutableDiagId = null;
            /*string*/ static PublicKeyPropertyMessage = null;
            /*string*/ static PublicKeyPropertyDiagId = null;
            /*string*/ static X509CertificatePrivateKeyMessage = null;
            /*string*/ static X509CertificatePrivateKeyDiagId = null;
            /*string*/ static ProduceLegacyHmacValuesMessage = null;
            /*string*/ static ProduceLegacyHmacValuesDiagId = null;
            /*string*/ static UseManagedSha1Message = null;
            /*string*/ static UseManagedSha1DiagId = null;
            /*string*/ static CryptoConfigEncodeOIDMessage = null;
            /*string*/ static CryptoConfigEncodeOIDDiagId = null;
            /*string*/ static CorruptedStateRecoveryMessage = null;
            /*string*/ static CorruptedStateRecoveryDiagId = null;
            /*string*/ static Rfc2898CryptDeriveKeyMessage = null;
            /*string*/ static Rfc2898CryptDeriveKeyDiagId = null;
            /*string*/ static CmsSignerCspParamsCtorMessage = null;
            /*string*/ static CmsSignerCspParamsCtorDiagId = null;
            /*string*/ static SignerInfoCounterSigMessage = null;
            /*string*/ static SignerInfoCounterSigDiagId = null;
            /*string*/ static RegexCompileToAssemblyMessage = null;
            /*string*/ static RegexCompileToAssemblyDiagId = null;
            /*string*/ static AssemblyNameMembersMessage = null;
            /*string*/ static AssemblyNameMembersDiagId = null;
            /*string*/ static SystemDataSerializationFormatBinaryMessage = null;
            /*string*/ static SystemDataSerializationFormatBinaryDiagId = null;
            /*string*/ static TlsVersion10and11Message = null;
            /*string*/ static TlsVersion10and11DiagId = null;
            /*string*/ static EncryptionPolicyMessage = null;
            /*string*/ static EncryptionPolicyDiagId = null;
            /*string*/ static EccXmlExportImportMessage = null;
            /*string*/ static EccXmlExportImportDiagId = null;
            /*string*/ static EcDhPublicKeyBlobMessage = null;
            /*string*/ static EcDhPublicKeyBlobDiagId = null;
            /*string*/ static AssemblyNameCodeBaseMessage = null;
            /*string*/ static AssemblyNameCodeBaseDiagId = null;
            /*string*/ static CryptoStringFactoryMessage = null;
            /*string*/ static CryptoStringFactoryDiagId = null;
            /*string*/ static ControlledExecutionRunMessage = null;
            /*string*/ static ControlledExecutionRunDiagId = null;
            /*string*/ static XmlSecureResolverMessage = null;
            /*string*/ static XmlSecureResolverDiagId = null;
            /*string*/ static RsaEncryptDecryptValueMessage = null;
            /*string*/ static RsaEncryptDecryptDiagId = null;
            /*string*/ static JsonSerializerOptionsAddContextMessage = null;
            /*string*/ static JsonSerializerOptionsAddContextDiagId = null;
            /*string*/ static LegacyFormatterMessage = null;
            /*string*/ static LegacyFormatterDiagId = null;
            /*string*/ static LegacyFormatterImplMessage = null;
            /*string*/ static LegacyFormatterImplDiagId = null;
            /*string*/ static RegexExtensibilityImplMessage = null;
            /*string*/ static RegexExtensibilityDiagId = null;
            /*string*/ static AesGcmTagConstructorMessage = null;
            /*string*/ static AesGcmTagConstructorDiagId = null;
            /*string*/ static ThreadVolatileReadWriteMessage = null;
            /*string*/ static ThreadVolatileReadWriteDiagId = null;
            /*string*/ static ArmIntrinsicPerformsUnsignedOperationMessage = null;
            /*string*/ static ArmIntrinsicPerformsUnsignedOperationDiagId = null;
            /*string*/ static LoadFromHashAlgorithmMessage = null;
            /*string*/ static LoadFromHashAlgorithmDiagId = null;
            /*string*/ static X509CtorCertDataObsoleteMessage = null;
            /*string*/ static X509CtorCertDataObsoleteDiagId = null;
            /*string*/ static TlsCipherAlgorithmEnumsMessage = null;
            /*string*/ static TlsCipherAlgorithmEnumsDiagId = null;
            /*string*/ static SystemEventsEventsThreadShutdownMessage = null;
            /*string*/ static SystemEventsEventsThreadShutdownDiagId = null;
            /*string*/ static Rfc2898DeriveBytesCtorMessage = null;
            /*string*/ static Rfc2898DeriveBytesCtorDiagId = null;
            /*string*/ static QueryableMinByMaxByTSourceObsoleteMessage = null;
            /*string*/ static QueryableMinByMaxByTSourceObsoleteDiagId = null;
            /*string*/ static XsltSettingsEnableScriptMessage = null;
            /*string*/ static XsltSettingsEnableScriptDiagId = null;
            //Static Initializer
            static $sinit()
            {
                {
                    this.SharedUrlFormat = "https://aka.ms/dotnet-warnings/{0}";
                }
                {
                    this.SystemTextEncodingUTF7Message = "The UTF-7 encoding is insecure and should not be used. Consider using UTF-8 instead.";
                }
                {
                    this.SystemTextEncodingUTF7DiagId = "SYSLIB0001";
                }
                {
                    this.PrincipalPermissionAttributeMessage = "PrincipalPermissionAttribute is not honored by the runtime and must not be used.";
                }
                {
                    this.PrincipalPermissionAttributeDiagId = "SYSLIB0002";
                }
                {
                    this.CodeAccessSecurityMessage = "Code Access Security is not supported or honored by the runtime.";
                }
                {
                    this.CodeAccessSecurityDiagId = "SYSLIB0003";
                }
                {
                    this.ConstrainedExecutionRegionMessage = "The Constrained Execution Region (CER) feature is not supported.";
                }
                {
                    this.ConstrainedExecutionRegionDiagId = "SYSLIB0004";
                }
                {
                    this.GlobalAssemblyCacheMessage = "The Global Assembly Cache is not supported.";
                }
                {
                    this.GlobalAssemblyCacheDiagId = "SYSLIB0005";
                }
                {
                    this.ThreadAbortMessage = "Thread.Abort is not supported and throws PlatformNotSupportedException.";
                }
                {
                    this.ThreadResetAbortMessage = "Thread.ResetAbort is not supported and throws PlatformNotSupportedException.";
                }
                {
                    this.ThreadAbortDiagId = "SYSLIB0006";
                }
                {
                    this.DefaultCryptoAlgorithmsMessage = "The default implementation of this cryptography algorithm is not supported.";
                }
                {
                    this.DefaultCryptoAlgorithmsDiagId = "SYSLIB0007";
                }
                {
                    this.CreatePdbGeneratorMessage = "The CreatePdbGenerator API is not supported and throws PlatformNotSupportedException.";
                }
                {
                    this.CreatePdbGeneratorDiagId = "SYSLIB0008";
                }
                {
                    this.AuthenticationManagerMessage = "AuthenticationManager is not supported. Methods will no-op or throw PlatformNotSupportedException.";
                }
                {
                    this.AuthenticationManagerDiagId = "SYSLIB0009";
                }
                {
                    this.RemotingApisMessage = "This Remoting API is not supported and throws PlatformNotSupportedException.";
                }
                {
                    this.RemotingApisDiagId = "SYSLIB0010";
                }
                {
                    this.BinaryFormatterMessage = "BinaryFormatter serialization is obsolete and should not be used. See https://aka.ms/binaryformatter for more information.";
                }
                {
                    this.BinaryFormatterDiagId = "SYSLIB0011";
                }
                {
                    this.CodeBaseMessage = "Assembly.CodeBase and Assembly.EscapedCodeBase are only included for .NET Framework compatibility. Use Assembly.Location instead.";
                }
                {
                    this.CodeBaseDiagId = "SYSLIB0012";
                }
                {
                    this.EscapeUriStringMessage = "Uri.EscapeUriString can corrupt the Uri string in some cases. Consider using Uri.EscapeDataString for query string components instead.";
                }
                {
                    this.EscapeUriStringDiagId = "SYSLIB0013";
                }
                {
                    this.WebRequestMessage = "WebRequest, HttpWebRequest, ServicePoint, and WebClient are obsolete. Use HttpClient instead.";
                }
                {
                    this.WebRequestDiagId = "SYSLIB0014";
                }
                {
                    this.DisablePrivateReflectionAttributeMessage = "DisablePrivateReflectionAttribute has no effect in .NET 6.0+.";
                }
                {
                    this.DisablePrivateReflectionAttributeDiagId = "SYSLIB0015";
                }
                {
                    this.GetContextInfoMessage = "Use the Graphics.GetContextInfo overloads that accept arguments for better performance and fewer allocations.";
                }
                {
                    this.GetContextInfoDiagId = "SYSLIB0016";
                }
                {
                    this.StrongNameKeyPairMessage = "Strong name signing is not supported and throws PlatformNotSupportedException.";
                }
                {
                    this.StrongNameKeyPairDiagId = "SYSLIB0017";
                }
                {
                    this.ReflectionOnlyLoadingMessage = "ReflectionOnly loading is not supported and throws PlatformNotSupportedException.";
                }
                {
                    this.ReflectionOnlyLoadingDiagId = "SYSLIB0018";
                }
                {
                    this.RuntimeEnvironmentMessage = "RuntimeEnvironment members SystemConfigurationFile, GetRuntimeInterfaceAsIntPtr, and GetRuntimeInterfaceAsObject are not supported and throw PlatformNotSupportedException.";
                }
                {
                    this.RuntimeEnvironmentDiagId = "SYSLIB0019";
                }
                {
                    this.JsonSerializerOptionsIgnoreNullValuesMessage = "JsonSerializerOptions.IgnoreNullValues is obsolete. To ignore null values when serializing, set DefaultIgnoreCondition to JsonIgnoreCondition.WhenWritingNull.";
                }
                {
                    this.JsonSerializerOptionsIgnoreNullValuesDiagId = "SYSLIB0020";
                }
                {
                    this.DerivedCryptographicTypesMessage = "Derived cryptographic types are obsolete. Use the Create method on the base type instead.";
                }
                {
                    this.DerivedCryptographicTypesDiagId = "SYSLIB0021";
                }
                {
                    this.RijndaelMessage = "The Rijndael and RijndaelManaged types are obsolete. Use Aes instead.";
                }
                {
                    this.RijndaelDiagId = "SYSLIB0022";
                }
                {
                    this.RNGCryptoServiceProviderMessage = "RNGCryptoServiceProvider is obsolete. To generate a random number, use one of the RandomNumberGenerator static methods instead.";
                }
                {
                    this.RNGCryptoServiceProviderDiagId = "SYSLIB0023";
                }
                {
                    this.AppDomainCreateUnloadMessage = "Creating and unloading AppDomains is not supported and throws an exception.";
                }
                {
                    this.AppDomainCreateUnloadDiagId = "SYSLIB0024";
                }
                {
                    this.SuppressIldasmAttributeMessage = "SuppressIldasmAttribute has no effect in .NET 6.0+.";
                }
                {
                    this.SuppressIldasmAttributeDiagId = "SYSLIB0025";
                }
                {
                    this.X509CertificateImmutableMessage = "X509Certificate and X509Certificate2 are immutable. Use X509CertificateLoader to create a new certificate.";
                }
                {
                    this.X509CertificateImmutableDiagId = "SYSLIB0026";
                }
                {
                    this.PublicKeyPropertyMessage = "PublicKey.Key is obsolete. Use the appropriate method to get the public key, such as GetRSAPublicKey.";
                }
                {
                    this.PublicKeyPropertyDiagId = "SYSLIB0027";
                }
                {
                    this.X509CertificatePrivateKeyMessage = "X509Certificate2.PrivateKey is obsolete. Use the appropriate method to get the private key, such as GetRSAPrivateKey, or use the CopyWithPrivateKey method to create a new instance with a private key.";
                }
                {
                    this.X509CertificatePrivateKeyDiagId = "SYSLIB0028";
                }
                {
                    this.ProduceLegacyHmacValuesMessage = "ProduceLegacyHmacValues is obsolete. Producing legacy HMAC values is not supported.";
                }
                {
                    this.ProduceLegacyHmacValuesDiagId = "SYSLIB0029";
                }
                {
                    this.UseManagedSha1Message = "HMACSHA1 always uses the algorithm implementation provided by the platform. Use a constructor without the useManagedSha1 parameter.";
                }
                {
                    this.UseManagedSha1DiagId = "SYSLIB0030";
                }
                {
                    this.CryptoConfigEncodeOIDMessage = "EncodeOID is obsolete. Use the ASN.1 functionality provided in System.Formats.Asn1.";
                }
                {
                    this.CryptoConfigEncodeOIDDiagId = "SYSLIB0031";
                }
                {
                    this.CorruptedStateRecoveryMessage = "Recovery from corrupted process state exceptions is not supported; HandleProcessCorruptedStateExceptionsAttribute is ignored.";
                }
                {
                    this.CorruptedStateRecoveryDiagId = "SYSLIB0032";
                }
                {
                    this.Rfc2898CryptDeriveKeyMessage = "Rfc2898DeriveBytes.CryptDeriveKey is obsolete and is not supported. Use PasswordDeriveBytes.CryptDeriveKey instead.";
                }
                {
                    this.Rfc2898CryptDeriveKeyDiagId = "SYSLIB0033";
                }
                {
                    this.CmsSignerCspParamsCtorMessage = "CmsSigner(CspParameters) is obsolete and is not supported. Use an alternative constructor instead.";
                }
                {
                    this.CmsSignerCspParamsCtorDiagId = "SYSLIB0034";
                }
                {
                    this.SignerInfoCounterSigMessage = "ComputeCounterSignature without specifying a CmsSigner is obsolete and is not supported. Use the overload that accepts a CmsSigner.";
                }
                {
                    this.SignerInfoCounterSigDiagId = "SYSLIB0035";
                }
                {
                    this.RegexCompileToAssemblyMessage = "Regex.CompileToAssembly is obsolete and not supported. Use the GeneratedRegexAttribute with the regular expression source generator instead.";
                }
                {
                    this.RegexCompileToAssemblyDiagId = "SYSLIB0036";
                }
                {
                    this.AssemblyNameMembersMessage = "AssemblyName members HashAlgorithm, ProcessorArchitecture, and VersionCompatibility are obsolete and not supported.";
                }
                {
                    this.AssemblyNameMembersDiagId = "SYSLIB0037";
                }
                {
                    this.SystemDataSerializationFormatBinaryMessage = "SerializationFormat.Binary is obsolete and should not be used. See https://aka.ms/serializationformat-binary-obsolete for more information.";
                }
                {
                    this.SystemDataSerializationFormatBinaryDiagId = "SYSLIB0038";
                }
                {
                    this.TlsVersion10and11Message = "TLS versions 1.0 and 1.1 have known vulnerabilities and are not recommended. Use a newer TLS version instead, or use SslProtocols.None to defer to OS defaults.";
                }
                {
                    this.TlsVersion10and11DiagId = "SYSLIB0039";
                }
                {
                    this.EncryptionPolicyMessage = "EncryptionPolicy.NoEncryption and AllowEncryption significantly reduce security and should not be used in production code.";
                }
                {
                    this.EncryptionPolicyDiagId = "SYSLIB0040";
                }
                {
                    this.EccXmlExportImportMessage = "ToXmlString and FromXmlString have no implementation for ECC types, and are obsolete. Use a standard import and export format such as ExportSubjectPublicKeyInfo or ImportSubjectPublicKeyInfo for public keys and ExportPkcs8PrivateKey or ImportPkcs8PrivateKey for private keys.";
                }
                {
                    this.EccXmlExportImportDiagId = "SYSLIB0042";
                }
                {
                    this.EcDhPublicKeyBlobMessage = "ECDiffieHellmanPublicKey.ToByteArray() and the associated constructor do not have a consistent and interoperable implementation on all platforms. Use ECDiffieHellmanPublicKey.ExportSubjectPublicKeyInfo() instead.";
                }
                {
                    this.EcDhPublicKeyBlobDiagId = "SYSLIB0043";
                }
                {
                    this.AssemblyNameCodeBaseMessage = "AssemblyName.CodeBase and AssemblyName.EscapedCodeBase are obsolete. Using them for loading an assembly is not supported.";
                }
                {
                    this.AssemblyNameCodeBaseDiagId = "SYSLIB0044";
                }
                {
                    this.CryptoStringFactoryMessage = "Cryptographic factory methods accepting an algorithm name are obsolete. Use the parameterless Create factory method on the algorithm type instead.";
                }
                {
                    this.CryptoStringFactoryDiagId = "SYSLIB0045";
                }
                {
                    this.ControlledExecutionRunMessage = "ControlledExecution.Run method may corrupt the process and should not be used in production code.";
                }
                {
                    this.ControlledExecutionRunDiagId = "SYSLIB0046";
                }
                {
                    this.XmlSecureResolverMessage = "XmlSecureResolver is obsolete. Use XmlResolver.ThrowingResolver instead when attempting to forbid XML external entity resolution.";
                }
                {
                    this.XmlSecureResolverDiagId = "SYSLIB0047";
                }
                {
                    this.RsaEncryptDecryptValueMessage = "RSA.EncryptValue and DecryptValue are not supported and throw NotSupportedException. Use RSA.Encrypt and RSA.Decrypt instead.";
                }
                {
                    this.RsaEncryptDecryptDiagId = "SYSLIB0048";
                }
                {
                    this.JsonSerializerOptionsAddContextMessage = "JsonSerializerOptions.AddContext is obsolete. To register a JsonSerializerContext, use either the TypeInfoResolver or TypeInfoResolverChain properties.";
                }
                {
                    this.JsonSerializerOptionsAddContextDiagId = "SYSLIB0049";
                }
                {
                    this.LegacyFormatterMessage = "Formatter-based serialization is obsolete and should not be used.";
                }
                {
                    this.LegacyFormatterDiagId = "SYSLIB0050";
                }
                {
                    this.LegacyFormatterImplMessage = "This API supports obsolete formatter-based serialization. It should not be called or extended by application code.";
                }
                {
                    this.LegacyFormatterImplDiagId = "SYSLIB0051";
                }
                {
                    this.RegexExtensibilityImplMessage = "This API supports obsolete mechanisms for Regex extensibility. It is not supported.";
                }
                {
                    this.RegexExtensibilityDiagId = "SYSLIB0052";
                }
                {
                    this.AesGcmTagConstructorMessage = "AesGcm should indicate the required tag size for encryption and decryption. Use a constructor that accepts the tag size.";
                }
                {
                    this.AesGcmTagConstructorDiagId = "SYSLIB0053";
                }
                {
                    this.ThreadVolatileReadWriteMessage = "Thread.VolatileRead and Thread.VolatileWrite are obsolete. Use Volatile.Read or Volatile.Write respectively instead.";
                }
                {
                    this.ThreadVolatileReadWriteDiagId = "SYSLIB0054";
                }
                {
                    this.ArmIntrinsicPerformsUnsignedOperationMessage = "The underlying hardware instruction does not perform a signed saturate narrowing operation, and it always returns an unsigned result. Use the unsigned overload instead.";
                }
                {
                    this.ArmIntrinsicPerformsUnsignedOperationDiagId = "SYSLIB0055";
                }
                {
                    this.LoadFromHashAlgorithmMessage = "LoadFrom with a custom AssemblyHashAlgorithm is obsolete. Use overloads without an AssemblyHashAlgorithm.";
                }
                {
                    this.LoadFromHashAlgorithmDiagId = "SYSLIB0056";
                }
                {
                    this.X509CtorCertDataObsoleteMessage = "Loading certificate data through the constructor or Import is obsolete. Use X509CertificateLoader instead to load certificates.";
                }
                {
                    this.X509CtorCertDataObsoleteDiagId = "SYSLIB0057";
                }
                {
                    this.TlsCipherAlgorithmEnumsMessage = "KeyExchangeAlgorithm, KeyExchangeStrength, CipherAlgorithm, CipherStrength, HashAlgorithm and HashStrength properties of SslStream are obsolete. Use NegotiatedCipherSuite instead.";
                }
                {
                    this.TlsCipherAlgorithmEnumsDiagId = "SYSLIB0058";
                }
                {
                    this.SystemEventsEventsThreadShutdownMessage = "SystemEvents.EventsThreadShutdown callbacks are not run before the process exits. Use AppDomain.ProcessExit instead.";
                }
                {
                    this.SystemEventsEventsThreadShutdownDiagId = "SYSLIB0059";
                }
                {
                    this.Rfc2898DeriveBytesCtorMessage = "The constructors on Rfc2898DeriveBytes are obsolete. Use the static Pbkdf2 method instead.";
                }
                {
                    this.Rfc2898DeriveBytesCtorDiagId = "SYSLIB0060";
                }
                {
                    this.QueryableMinByMaxByTSourceObsoleteMessage = "The Queryable MinBy and MaxBy taking an IComparer<TSource> are obsolete. Use the new ones that take an IComparer<TKey>.";
                }
                {
                    this.QueryableMinByMaxByTSourceObsoleteDiagId = "SYSLIB0061";
                }
                {
                    this.XsltSettingsEnableScriptMessage = "XSLT Script blocks are not supported.";
                }
                {
                    this.XsltSettingsEnableScriptDiagId = "SYSLIB0062";
                }
            }
            static $h = 119483;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"l":[{"t":1310721,"n":"SharedUrlFormat","d":119483,"h":4295086779,"f":40},{"t":1310721,"n":"SystemTextEncodingUTF7Message","d":119483,"h":8590054075,"f":40},{"t":1310721,"n":"SystemTextEncodingUTF7DiagId","d":119483,"h":12885021371,"f":40},{"t":1310721,"n":"PrincipalPermissionAttributeMessage","d":119483,"h":17179988667,"f":40},{"t":1310721,"n":"PrincipalPermissionAttributeDiagId","d":119483,"h":21474955963,"f":40},{"t":1310721,"n":"CodeAccessSecurityMessage","d":119483,"h":25769923259,"f":40},{"t":1310721,"n":"CodeAccessSecurityDiagId","d":119483,"h":30064890555,"f":40},{"t":1310721,"n":"ConstrainedExecutionRegionMessage","d":119483,"h":34359857851,"f":40},{"t":1310721,"n":"ConstrainedExecutionRegionDiagId","d":119483,"h":38654825147,"f":40},{"t":1310721,"n":"GlobalAssemblyCacheMessage","d":119483,"h":42949792443,"f":40},{"t":1310721,"n":"GlobalAssemblyCacheDiagId","d":119483,"h":47244759739,"f":40},{"t":1310721,"n":"ThreadAbortMessage","d":119483,"h":51539727035,"f":40},{"t":1310721,"n":"ThreadResetAbortMessage","d":119483,"h":55834694331,"f":40},{"t":1310721,"n":"ThreadAbortDiagId","d":119483,"h":60129661627,"f":40},{"t":1310721,"n":"DefaultCryptoAlgorithmsMessage","d":119483,"h":64424628923,"f":40},{"t":1310721,"n":"DefaultCryptoAlgorithmsDiagId","d":119483,"h":68719596219,"f":40},{"t":1310721,"n":"CreatePdbGeneratorMessage","d":119483,"h":73014563515,"f":40},{"t":1310721,"n":"CreatePdbGeneratorDiagId","d":119483,"h":77309530811,"f":40},{"t":1310721,"n":"AuthenticationManagerMessage","d":119483,"h":81604498107,"f":40},{"t":1310721,"n":"AuthenticationManagerDiagId","d":119483,"h":85899465403,"f":40},{"t":1310721,"n":"RemotingApisMessage","d":119483,"h":90194432699,"f":40},{"t":1310721,"n":"RemotingApisDiagId","d":119483,"h":94489399995,"f":40},{"t":1310721,"n":"BinaryFormatterMessage","d":119483,"h":98784367291,"f":40},{"t":1310721,"n":"BinaryFormatterDiagId","d":119483,"h":103079334587,"f":40},{"t":1310721,"n":"CodeBaseMessage","d":119483,"h":107374301883,"f":40},{"t":1310721,"n":"CodeBaseDiagId","d":119483,"h":111669269179,"f":40},{"t":1310721,"n":"EscapeUriStringMessage","d":119483,"h":115964236475,"f":40},{"t":1310721,"n":"EscapeUriStringDiagId","d":119483,"h":120259203771,"f":40},{"t":1310721,"n":"WebRequestMessage","d":119483,"h":124554171067,"f":40},{"t":1310721,"n":"WebRequestDiagId","d":119483,"h":128849138363,"f":40},{"t":1310721,"n":"DisablePrivateReflectionAttributeMessage","d":119483,"h":133144105659,"f":40},{"t":1310721,"n":"DisablePrivateReflectionAttributeDiagId","d":119483,"h":137439072955,"f":40},{"t":1310721,"n":"GetContextInfoMessage","d":119483,"h":141734040251,"f":40},{"t":1310721,"n":"GetContextInfoDiagId","d":119483,"h":146029007547,"f":40},{"t":1310721,"n":"StrongNameKeyPairMessage","d":119483,"h":150323974843,"f":40},{"t":1310721,"n":"StrongNameKeyPairDiagId","d":119483,"h":154618942139,"f":40},{"t":1310721,"n":"ReflectionOnlyLoadingMessage","d":119483,"h":158913909435,"f":40},{"t":1310721,"n":"ReflectionOnlyLoadingDiagId","d":119483,"h":163208876731,"f":40},{"t":1310721,"n":"RuntimeEnvironmentMessage","d":119483,"h":167503844027,"f":40},{"t":1310721,"n":"RuntimeEnvironmentDiagId","d":119483,"h":171798811323,"f":40},{"t":1310721,"n":"JsonSerializerOptionsIgnoreNullValuesMessage","d":119483,"h":176093778619,"f":40},{"t":1310721,"n":"JsonSerializerOptionsIgnoreNullValuesDiagId","d":119483,"h":180388745915,"f":40},{"t":1310721,"n":"DerivedCryptographicTypesMessage","d":119483,"h":184683713211,"f":40},{"t":1310721,"n":"DerivedCryptographicTypesDiagId","d":119483,"h":188978680507,"f":40},{"t":1310721,"n":"RijndaelMessage","d":119483,"h":193273647803,"f":40},{"t":1310721,"n":"RijndaelDiagId","d":119483,"h":197568615099,"f":40},{"t":1310721,"n":"RNGCryptoServiceProviderMessage","d":119483,"h":201863582395,"f":40},{"t":1310721,"n":"RNGCryptoServiceProviderDiagId","d":119483,"h":206158549691,"f":40},{"t":1310721,"n":"AppDomainCreateUnloadMessage","d":119483,"h":210453516987,"f":40},{"t":1310721,"n":"AppDomainCreateUnloadDiagId","d":119483,"h":214748484283,"f":40},{"t":1310721,"n":"SuppressIldasmAttributeMessage","d":119483,"h":219043451579,"f":40},{"t":1310721,"n":"SuppressIldasmAttributeDiagId","d":119483,"h":223338418875,"f":40},{"t":1310721,"n":"X509CertificateImmutableMessage","d":119483,"h":227633386171,"f":40},{"t":1310721,"n":"X509CertificateImmutableDiagId","d":119483,"h":231928353467,"f":40},{"t":1310721,"n":"PublicKeyPropertyMessage","d":119483,"h":236223320763,"f":40},{"t":1310721,"n":"PublicKeyPropertyDiagId","d":119483,"h":240518288059,"f":40},{"t":1310721,"n":"X509CertificatePrivateKeyMessage","d":119483,"h":244813255355,"f":40},{"t":1310721,"n":"X509CertificatePrivateKeyDiagId","d":119483,"h":249108222651,"f":40},{"t":1310721,"n":"ProduceLegacyHmacValuesMessage","d":119483,"h":253403189947,"f":40},{"t":1310721,"n":"ProduceLegacyHmacValuesDiagId","d":119483,"h":257698157243,"f":40},{"t":1310721,"n":"UseManagedSha1Message","d":119483,"h":261993124539,"f":40},{"t":1310721,"n":"UseManagedSha1DiagId","d":119483,"h":266288091835,"f":40},{"t":1310721,"n":"CryptoConfigEncodeOIDMessage","d":119483,"h":270583059131,"f":40},{"t":1310721,"n":"CryptoConfigEncodeOIDDiagId","d":119483,"h":274878026427,"f":40},{"t":1310721,"n":"CorruptedStateRecoveryMessage","d":119483,"h":279172993723,"f":40},{"t":1310721,"n":"CorruptedStateRecoveryDiagId","d":119483,"h":283467961019,"f":40},{"t":1310721,"n":"Rfc2898CryptDeriveKeyMessage","d":119483,"h":287762928315,"f":40},{"t":1310721,"n":"Rfc2898CryptDeriveKeyDiagId","d":119483,"h":292057895611,"f":40},{"t":1310721,"n":"CmsSignerCspParamsCtorMessage","d":119483,"h":296352862907,"f":40},{"t":1310721,"n":"CmsSignerCspParamsCtorDiagId","d":119483,"h":300647830203,"f":40},{"t":1310721,"n":"SignerInfoCounterSigMessage","d":119483,"h":304942797499,"f":40},{"t":1310721,"n":"SignerInfoCounterSigDiagId","d":119483,"h":309237764795,"f":40},{"t":1310721,"n":"RegexCompileToAssemblyMessage","d":119483,"h":313532732091,"f":40},{"t":1310721,"n":"RegexCompileToAssemblyDiagId","d":119483,"h":317827699387,"f":40},{"t":1310721,"n":"AssemblyNameMembersMessage","d":119483,"h":322122666683,"f":40},{"t":1310721,"n":"AssemblyNameMembersDiagId","d":119483,"h":326417633979,"f":40},{"t":1310721,"n":"SystemDataSerializationFormatBinaryMessage","d":119483,"h":330712601275,"f":40},{"t":1310721,"n":"SystemDataSerializationFormatBinaryDiagId","d":119483,"h":335007568571,"f":40},{"t":1310721,"n":"TlsVersion10and11Message","d":119483,"h":339302535867,"f":40},{"t":1310721,"n":"TlsVersion10and11DiagId","d":119483,"h":343597503163,"f":40},{"t":1310721,"n":"EncryptionPolicyMessage","d":119483,"h":347892470459,"f":40},{"t":1310721,"n":"EncryptionPolicyDiagId","d":119483,"h":352187437755,"f":40},{"t":1310721,"n":"EccXmlExportImportMessage","d":119483,"h":356482405051,"f":40},{"t":1310721,"n":"EccXmlExportImportDiagId","d":119483,"h":360777372347,"f":40},{"t":1310721,"n":"EcDhPublicKeyBlobMessage","d":119483,"h":365072339643,"f":40},{"t":1310721,"n":"EcDhPublicKeyBlobDiagId","d":119483,"h":369367306939,"f":40},{"t":1310721,"n":"AssemblyNameCodeBaseMessage","d":119483,"h":373662274235,"f":40},{"t":1310721,"n":"AssemblyNameCodeBaseDiagId","d":119483,"h":377957241531,"f":40},{"t":1310721,"n":"CryptoStringFactoryMessage","d":119483,"h":382252208827,"f":40},{"t":1310721,"n":"CryptoStringFactoryDiagId","d":119483,"h":386547176123,"f":40},{"t":1310721,"n":"ControlledExecutionRunMessage","d":119483,"h":390842143419,"f":40},{"t":1310721,"n":"ControlledExecutionRunDiagId","d":119483,"h":395137110715,"f":40},{"t":1310721,"n":"XmlSecureResolverMessage","d":119483,"h":399432078011,"f":40},{"t":1310721,"n":"XmlSecureResolverDiagId","d":119483,"h":403727045307,"f":40},{"t":1310721,"n":"RsaEncryptDecryptValueMessage","d":119483,"h":408022012603,"f":40},{"t":1310721,"n":"RsaEncryptDecryptDiagId","d":119483,"h":412316979899,"f":40},{"t":1310721,"n":"JsonSerializerOptionsAddContextMessage","d":119483,"h":416611947195,"f":40},{"t":1310721,"n":"JsonSerializerOptionsAddContextDiagId","d":119483,"h":420906914491,"f":40},{"t":1310721,"n":"LegacyFormatterMessage","d":119483,"h":425201881787,"f":40},{"t":1310721,"n":"LegacyFormatterDiagId","d":119483,"h":429496849083,"f":40},{"t":1310721,"n":"LegacyFormatterImplMessage","d":119483,"h":433791816379,"f":40},{"t":1310721,"n":"LegacyFormatterImplDiagId","d":119483,"h":438086783675,"f":40},{"t":1310721,"n":"RegexExtensibilityImplMessage","d":119483,"h":442381750971,"f":40},{"t":1310721,"n":"RegexExtensibilityDiagId","d":119483,"h":446676718267,"f":40},{"t":1310721,"n":"AesGcmTagConstructorMessage","d":119483,"h":450971685563,"f":40},{"t":1310721,"n":"AesGcmTagConstructorDiagId","d":119483,"h":455266652859,"f":40},{"t":1310721,"n":"ThreadVolatileReadWriteMessage","d":119483,"h":459561620155,"f":40},{"t":1310721,"n":"ThreadVolatileReadWriteDiagId","d":119483,"h":463856587451,"f":40},{"t":1310721,"n":"ArmIntrinsicPerformsUnsignedOperationMessage","d":119483,"h":468151554747,"f":40},{"t":1310721,"n":"ArmIntrinsicPerformsUnsignedOperationDiagId","d":119483,"h":472446522043,"f":40},{"t":1310721,"n":"LoadFromHashAlgorithmMessage","d":119483,"h":476741489339,"f":40},{"t":1310721,"n":"LoadFromHashAlgorithmDiagId","d":119483,"h":481036456635,"f":40},{"t":1310721,"n":"X509CtorCertDataObsoleteMessage","d":119483,"h":485331423931,"f":40},{"t":1310721,"n":"X509CtorCertDataObsoleteDiagId","d":119483,"h":489626391227,"f":40},{"t":1310721,"n":"TlsCipherAlgorithmEnumsMessage","d":119483,"h":493921358523,"f":40},{"t":1310721,"n":"TlsCipherAlgorithmEnumsDiagId","d":119483,"h":498216325819,"f":40},{"t":1310721,"n":"SystemEventsEventsThreadShutdownMessage","d":119483,"h":502511293115,"f":40},{"t":1310721,"n":"SystemEventsEventsThreadShutdownDiagId","d":119483,"h":506806260411,"f":40},{"t":1310721,"n":"Rfc2898DeriveBytesCtorMessage","d":119483,"h":511101227707,"f":40},{"t":1310721,"n":"Rfc2898DeriveBytesCtorDiagId","d":119483,"h":515396195003,"f":40},{"t":1310721,"n":"QueryableMinByMaxByTSourceObsoleteMessage","d":119483,"h":519691162299,"f":40},{"t":1310721,"n":"QueryableMinByMaxByTSourceObsoleteDiagId","d":119483,"h":523986129595,"f":40},{"t":1310721,"n":"XsltSettingsEnableScriptMessage","d":119483,"h":528281096891,"f":40},{"t":1310721,"n":"XsltSettingsEnableScriptDiagId","d":119483,"h":532576064187,"f":40}],"h":119483}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.Obsoletions`; }
        });
        
        $asm.$cls("$ssc.System.SR", ($self) => class SR
        {
            /*global::System.Resources.ResourceManager*/ static s_resourceManager = null;
            /*global::System.Globalization.CultureInfo*/ static resourceCulture = null;
            static /*global::System.Resources.ResourceManager */ get ResourceManager()
            {
                if ($.$spc.System.Object.ReferenceEquals($.$ssc.System.SR.s_resourceManager, null))
                {
                    /*global::System.Resources.ResourceManager*/ let temp = new $.$spc.System.Resources.ResourceManager().$ctor$3("System.Security.Claims", $.$ssc.System.SR.$type.Assembly);
                    $.$ssc.System.SR.s_resourceManager = temp;
                }
                return $.$ssc.System.SR.s_resourceManager;
            }
            static /*global::System.Globalization.CultureInfo */ get Culture()
            {
                return $.$ssc.System.SR.resourceCulture;
            }
            static /*global::System.Globalization.CultureInfo */ set Culture(value)
            {
                $.$ssc.System.SR.resourceCulture = value;
            }
            static /*string */ get ArgumentException_StringComparisonCultureAware()
            {
                return "The StringComparison must be one of Ordinal, OrdinalIgnoreCase, InvariantCulture, InvariantCultureIgnoreCase.";
            }
            static /*string */ get InvalidOperation_ClaimCannotBeRemoved()
            {
                return "The Claim '{0}' was not able to be removed.  It is either not part of this Identity or it is a Claim that is owned by the Principal that contains this Identity. For example, the Principal will own the Claim when creating a GenericPrincipal with roles. The roles will be exposed through the Identity that is passed in the constructor, but not actually owned by the Identity.  Similar logic exists for a RolePrincipal.";
            }
            static /*string */ FormatInvalidOperation_ClaimCannotBeRemoved(/*object*/ arg1)
            {
                return $.$spc.System.String.Format("The Claim '{0}' was not able to be removed.  It is either not part of this Identity or it is a Claim that is owned by the Principal that contains this Identity. For example, the Principal will own the Claim when creating a GenericPrincipal with roles. The roles will be exposed through the Identity that is passed in the constructor, but not actually owned by the Identity.  Similar logic exists for a RolePrincipal.", arg1);
            }
            static /*string */ get InvalidOperationException_ActorGraphCircular()
            {
                return "An Actor must not create a circular reference between itself (or one of its child Actors) and one of its parents.";
            }
            static /*string */ get PlatformNotSupported_Serialization()
            {
                return "This instance contains state that cannot be serialized and deserialized on this platform.";
            }
            /*bool*/ static s_usingResourceKeys = false;
            static /*bool */ GetUsingResourceKeysSwitchValue()
            {
                /*bool*/ let usingResourceKeys;
                return $.$spc.System.AppContext.TryGetSwitch("System.Resources.UseSystemResourceKeys", $.$ref(() => usingResourceKeys, ($v) => usingResourceKeys = $v, $.$spc.System.Boolean)) ? usingResourceKeys : false;
            }
            static /*bool */ UsingResourceKeys()
            {
                return $.$ssc.System.SR.s_usingResourceKeys;
            }
            static /*string */ GetResourceString(/*string*/ resourceKey)
            {
                if ($.$ssc.System.SR.UsingResourceKeys())
                {
                    return resourceKey;
                }
                /*string?*/ let resourceString = null;
                try
                {
                    resourceString = $.$ssc.System.SR.ResourceManager.GetString(resourceKey);
                }
                catch($e)
                {
                }
                return resourceString;
            }
            static /*string */ GetResourceString$1(/*string*/ resourceKey, /*string*/ defaultString)
            {
                /*string*/ let resourceString = $.$ssc.System.SR.GetResourceString(resourceKey);
                return $.$spc.System.String.op_Equality(resourceKey, resourceString) || $.$spc.System.String.op_Equality(resourceString, null) ? defaultString : resourceString;
            }
            static /*string */ Format(/*string*/ resourceFormat, /*object?*/ p1)
            {
                if ($.$ssc.System.SR.UsingResourceKeys())
                {
                    return $.$spc.System.String.Join$10(", ", $.$spc.System.ReadOnlySpan$$($.$spc.System.Object).op_Implicit([ resourceFormat, p1 ]));
                }
                return $.$spc.System.String.Format(resourceFormat, p1);
            }
            static /*string */ Format$1(/*string*/ resourceFormat, /*object?*/ p1, /*object?*/ p2)
            {
                if ($.$ssc.System.SR.UsingResourceKeys())
                {
                    return $.$spc.System.String.Join$10(", ", $.$spc.System.ReadOnlySpan$$($.$spc.System.Object).op_Implicit([ resourceFormat, p1, p2 ]));
                }
                return $.$spc.System.String.Format$1(resourceFormat, p1, p2);
            }
            static /*string */ Format$2(/*string*/ resourceFormat, /*object?*/ p1, /*object?*/ p2, /*object?*/ p3)
            {
                if ($.$ssc.System.SR.UsingResourceKeys())
                {
                    return $.$spc.System.String.Join$10(", ", $.$spc.System.ReadOnlySpan$$($.$spc.System.Object).op_Implicit([ resourceFormat, p1, p2, p3 ]));
                }
                return $.$spc.System.String.Format$2(resourceFormat, p1, p2, p3);
            }
            static /*string */ Format$3(/*string*/ resourceFormat, /*params object?[]?*/ args)
            {
                if (args !== null)
                {
                    if ($.$ssc.System.SR.UsingResourceKeys())
                    {
                        return resourceFormat + ", " + $.$spc.System.String.Join$9(", ", args);
                    }
                    return $.$spc.System.String.Format$3(resourceFormat, args);
                }
                return resourceFormat;
            }
            static /*string */ Format$4(/*IFormatProvider?*/ provider, /*string*/ resourceFormat, /*object?*/ p1)
            {
                if ($.$ssc.System.SR.UsingResourceKeys())
                {
                    return $.$spc.System.String.Join$10(", ", $.$spc.System.ReadOnlySpan$$($.$spc.System.Object).op_Implicit([ resourceFormat, p1 ]));
                }
                return $.$spc.System.String.Format$5(provider, resourceFormat, p1);
            }
            static /*string */ Format$5(/*IFormatProvider?*/ provider, /*string*/ resourceFormat, /*object?*/ p1, /*object?*/ p2)
            {
                if ($.$ssc.System.SR.UsingResourceKeys())
                {
                    return $.$spc.System.String.Join$10(", ", $.$spc.System.ReadOnlySpan$$($.$spc.System.Object).op_Implicit([ resourceFormat, p1, p2 ]));
                }
                return $.$spc.System.String.Format$6(provider, resourceFormat, p1, p2);
            }
            static /*string */ Format$6(/*IFormatProvider?*/ provider, /*string*/ resourceFormat, /*object?*/ p1, /*object?*/ p2, /*object?*/ p3)
            {
                if ($.$ssc.System.SR.UsingResourceKeys())
                {
                    return $.$spc.System.String.Join$10(", ", $.$spc.System.ReadOnlySpan$$($.$spc.System.Object).op_Implicit([ resourceFormat, p1, p2, p3 ]));
                }
                return $.$spc.System.String.Format$7(provider, resourceFormat, p1, p2, p3);
            }
            static /*string */ Format$7(/*IFormatProvider?*/ provider, /*string*/ resourceFormat, /*params object?[]?*/ args)
            {
                if (args !== null)
                {
                    if ($.$ssc.System.SR.UsingResourceKeys())
                    {
                        return resourceFormat + ", " + $.$spc.System.String.Join$9(", ", args);
                    }
                    return $.$spc.System.String.Format$8(provider, resourceFormat, args);
                }
                return resourceFormat;
            }
            //Static Initializer
            static $sinit()
            {
                {
                    this.s_usingResourceKeys = $.$ssc.System.SR.GetUsingResourceKeysSwitchValue();
                }
            }
            static $h = 840379;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"h":840379}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.SR`; }
        });
        
        $asm.$cls("$ssc.System.Security.Claims.ClaimValueTypes", ($self) => class ClaimValueTypes
        {
            /*string*/ static XmlSchemaNamespace = null;
            /*string*/ static Base64Binary = null;
            /*string*/ static Base64Octet = null;
            /*string*/ static Boolean = null;
            /*string*/ static Date = null;
            /*string*/ static DateTime = null;
            /*string*/ static Double = null;
            /*string*/ static Fqbn = null;
            /*string*/ static HexBinary = null;
            /*string*/ static Integer = null;
            /*string*/ static Integer32 = null;
            /*string*/ static Integer64 = null;
            /*string*/ static Sid = null;
            /*string*/ static String = null;
            /*string*/ static Time = null;
            /*string*/ static UInteger32 = null;
            /*string*/ static UInteger64 = null;
            /*string*/ static SoapSchemaNamespace = null;
            /*string*/ static DnsName = null;
            /*string*/ static Email = null;
            /*string*/ static Rsa = null;
            /*string*/ static UpnName = null;
            /*string*/ static XmlSignatureConstantsNamespace = null;
            /*string*/ static DsaKeyValue = null;
            /*string*/ static KeyInfo = null;
            /*string*/ static RsaKeyValue = null;
            /*string*/ static XQueryOperatorsNameSpace = null;
            /*string*/ static DaytimeDuration = null;
            /*string*/ static YearMonthDuration = null;
            /*string*/ static Xacml10Namespace = null;
            /*string*/ static Rfc822Name = null;
            /*string*/ static X500Name = null;
            //Static Initializer
            static $sinit()
            {
                {
                    this.XmlSchemaNamespace = "http://www.w3.org/2001/XMLSchema";
                }
                {
                    this.Base64Binary = "http://www.w3.org/2001/XMLSchema#base64Binary";
                }
                {
                    this.Base64Octet = "http://www.w3.org/2001/XMLSchema#base64Octet";
                }
                {
                    this.Boolean = "http://www.w3.org/2001/XMLSchema#boolean";
                }
                {
                    this.Date = "http://www.w3.org/2001/XMLSchema#date";
                }
                {
                    this.DateTime = "http://www.w3.org/2001/XMLSchema#dateTime";
                }
                {
                    this.Double = "http://www.w3.org/2001/XMLSchema#double";
                }
                {
                    this.Fqbn = "http://www.w3.org/2001/XMLSchema#fqbn";
                }
                {
                    this.HexBinary = "http://www.w3.org/2001/XMLSchema#hexBinary";
                }
                {
                    this.Integer = "http://www.w3.org/2001/XMLSchema#integer";
                }
                {
                    this.Integer32 = "http://www.w3.org/2001/XMLSchema#integer32";
                }
                {
                    this.Integer64 = "http://www.w3.org/2001/XMLSchema#integer64";
                }
                {
                    this.Sid = "http://www.w3.org/2001/XMLSchema#sid";
                }
                {
                    this.String = "http://www.w3.org/2001/XMLSchema#string";
                }
                {
                    this.Time = "http://www.w3.org/2001/XMLSchema#time";
                }
                {
                    this.UInteger32 = "http://www.w3.org/2001/XMLSchema#uinteger32";
                }
                {
                    this.UInteger64 = "http://www.w3.org/2001/XMLSchema#uinteger64";
                }
                {
                    this.SoapSchemaNamespace = "http://schemas.xmlsoap.org/";
                }
                {
                    this.DnsName = "http://schemas.xmlsoap.org/claims/dns";
                }
                {
                    this.Email = "http://schemas.xmlsoap.org/ws/2005/05/identity/claims/emailaddress";
                }
                {
                    this.Rsa = "http://schemas.xmlsoap.org/ws/2005/05/identity/claims/rsa";
                }
                {
                    this.UpnName = "http://schemas.xmlsoap.org/claims/UPN";
                }
                {
                    this.XmlSignatureConstantsNamespace = "http://www.w3.org/2000/09/xmldsig#";
                }
                {
                    this.DsaKeyValue = "http://www.w3.org/2000/09/xmldsig#DSAKeyValue";
                }
                {
                    this.KeyInfo = "http://www.w3.org/2000/09/xmldsig#KeyInfo";
                }
                {
                    this.RsaKeyValue = "http://www.w3.org/2000/09/xmldsig#RSAKeyValue";
                }
                {
                    this.XQueryOperatorsNameSpace = "http://www.w3.org/TR/2002/WD-xquery-operators-20020816";
                }
                {
                    this.DaytimeDuration = "http://www.w3.org/TR/2002/WD-xquery-operators-20020816#dayTimeDuration";
                }
                {
                    this.YearMonthDuration = "http://www.w3.org/TR/2002/WD-xquery-operators-20020816#yearMonthDuration";
                }
                {
                    this.Xacml10Namespace = "urn:oasis:names:tc:xacml:1.0";
                }
                {
                    this.Rfc822Name = "urn:oasis:names:tc:xacml:1.0:data-type:rfc822Name";
                }
                {
                    this.X500Name = "urn:oasis:names:tc:xacml:1.0:data-type:x500Name";
                }
            }
            static $h = 643771;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"l":[{"t":1310721,"n":"XmlSchemaNamespace","d":643771,"h":4295611067,"f":34},{"t":1310721,"n":"Base64Binary","d":643771,"h":8590578363,"f":33},{"t":1310721,"n":"Base64Octet","d":643771,"h":12885545659,"f":33},{"t":1310721,"n":"Boolean","d":643771,"h":17180512955,"f":33},{"t":1310721,"n":"Date","d":643771,"h":21475480251,"f":33},{"t":1310721,"n":"DateTime","d":643771,"h":25770447547,"f":33},{"t":1310721,"n":"Double","d":643771,"h":30065414843,"f":33},{"t":1310721,"n":"Fqbn","d":643771,"h":34360382139,"f":33},{"t":1310721,"n":"HexBinary","d":643771,"h":38655349435,"f":33},{"t":1310721,"n":"Integer","d":643771,"h":42950316731,"f":33},{"t":1310721,"n":"Integer32","d":643771,"h":47245284027,"f":33},{"t":1310721,"n":"Integer64","d":643771,"h":51540251323,"f":33},{"t":1310721,"n":"Sid","d":643771,"h":55835218619,"f":33},{"t":1310721,"n":"String","d":643771,"h":60130185915,"f":33},{"t":1310721,"n":"Time","d":643771,"h":64425153211,"f":33},{"t":1310721,"n":"UInteger32","d":643771,"h":68720120507,"f":33},{"t":1310721,"n":"UInteger64","d":643771,"h":73015087803,"f":33},{"t":1310721,"n":"SoapSchemaNamespace","d":643771,"h":77310055099,"f":34},{"t":1310721,"n":"DnsName","d":643771,"h":81605022395,"f":33},{"t":1310721,"n":"Email","d":643771,"h":85899989691,"f":33},{"t":1310721,"n":"Rsa","d":643771,"h":90194956987,"f":33},{"t":1310721,"n":"UpnName","d":643771,"h":94489924283,"f":33},{"t":1310721,"n":"XmlSignatureConstantsNamespace","d":643771,"h":98784891579,"f":34},{"t":1310721,"n":"DsaKeyValue","d":643771,"h":103079858875,"f":33},{"t":1310721,"n":"KeyInfo","d":643771,"h":107374826171,"f":33},{"t":1310721,"n":"RsaKeyValue","d":643771,"h":111669793467,"f":33},{"t":1310721,"n":"XQueryOperatorsNameSpace","d":643771,"h":115964760763,"f":34},{"t":1310721,"n":"DaytimeDuration","d":643771,"h":120259728059,"f":33},{"t":1310721,"n":"YearMonthDuration","d":643771,"h":124554695355,"f":33},{"t":1310721,"n":"Xacml10Namespace","d":643771,"h":128849662651,"f":34},{"t":1310721,"n":"Rfc822Name","d":643771,"h":133144629947,"f":33},{"t":1310721,"n":"X500Name","d":643771,"h":137439597243,"f":33}],"h":643771}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.Security.Claims.ClaimValueTypes`; }
        });
        
        $asm.$cls("$ssc.System.Security.Claims.ClaimTypes", ($self) => class ClaimTypes
        {
            /*string*/ static ClaimTypeNamespace = null;
            /*string*/ static AuthenticationInstant = null;
            /*string*/ static AuthenticationMethod = null;
            /*string*/ static CookiePath = null;
            /*string*/ static DenyOnlyPrimarySid = null;
            /*string*/ static DenyOnlyPrimaryGroupSid = null;
            /*string*/ static DenyOnlyWindowsDeviceGroup = null;
            /*string*/ static Dsa = null;
            /*string*/ static Expiration = null;
            /*string*/ static Expired = null;
            /*string*/ static GroupSid = null;
            /*string*/ static IsPersistent = null;
            /*string*/ static PrimaryGroupSid = null;
            /*string*/ static PrimarySid = null;
            /*string*/ static Role = null;
            /*string*/ static SerialNumber = null;
            /*string*/ static UserData = null;
            /*string*/ static Version = null;
            /*string*/ static WindowsAccountName = null;
            /*string*/ static WindowsDeviceClaim = null;
            /*string*/ static WindowsDeviceGroup = null;
            /*string*/ static WindowsUserClaim = null;
            /*string*/ static WindowsFqbnVersion = null;
            /*string*/ static WindowsSubAuthority = null;
            /*string*/ static ClaimType2005Namespace = null;
            /*string*/ static Anonymous = null;
            /*string*/ static Authentication = null;
            /*string*/ static AuthorizationDecision = null;
            /*string*/ static Country = null;
            /*string*/ static DateOfBirth = null;
            /*string*/ static Dns = null;
            /*string*/ static DenyOnlySid = null;
            /*string*/ static Email = null;
            /*string*/ static Gender = null;
            /*string*/ static GivenName = null;
            /*string*/ static Hash = null;
            /*string*/ static HomePhone = null;
            /*string*/ static Locality = null;
            /*string*/ static MobilePhone = null;
            /*string*/ static Name = null;
            /*string*/ static NameIdentifier = null;
            /*string*/ static OtherPhone = null;
            /*string*/ static PostalCode = null;
            /*string*/ static Rsa = null;
            /*string*/ static Sid = null;
            /*string*/ static Spn = null;
            /*string*/ static StateOrProvince = null;
            /*string*/ static StreetAddress = null;
            /*string*/ static Surname = null;
            /*string*/ static System = null;
            /*string*/ static Thumbprint = null;
            /*string*/ static Upn = null;
            /*string*/ static Uri = null;
            /*string*/ static Webpage = null;
            /*string*/ static X500DistinguishedName = null;
            /*string*/ static ClaimType2009Namespace = null;
            /*string*/ static Actor = null;
            //Static Initializer
            static $sinit()
            {
                {
                    this.ClaimTypeNamespace = "http://schemas.microsoft.com/ws/2008/06/identity/claims";
                }
                {
                    this.AuthenticationInstant = "http://schemas.microsoft.com/ws/2008/06/identity/claims/authenticationinstant";
                }
                {
                    this.AuthenticationMethod = "http://schemas.microsoft.com/ws/2008/06/identity/claims/authenticationmethod";
                }
                {
                    this.CookiePath = "http://schemas.microsoft.com/ws/2008/06/identity/claims/cookiepath";
                }
                {
                    this.DenyOnlyPrimarySid = "http://schemas.microsoft.com/ws/2008/06/identity/claims/denyonlyprimarysid";
                }
                {
                    this.DenyOnlyPrimaryGroupSid = "http://schemas.microsoft.com/ws/2008/06/identity/claims/denyonlyprimarygroupsid";
                }
                {
                    this.DenyOnlyWindowsDeviceGroup = "http://schemas.microsoft.com/ws/2008/06/identity/claims/denyonlywindowsdevicegroup";
                }
                {
                    this.Dsa = "http://schemas.microsoft.com/ws/2008/06/identity/claims/dsa";
                }
                {
                    this.Expiration = "http://schemas.microsoft.com/ws/2008/06/identity/claims/expiration";
                }
                {
                    this.Expired = "http://schemas.microsoft.com/ws/2008/06/identity/claims/expired";
                }
                {
                    this.GroupSid = "http://schemas.microsoft.com/ws/2008/06/identity/claims/groupsid";
                }
                {
                    this.IsPersistent = "http://schemas.microsoft.com/ws/2008/06/identity/claims/ispersistent";
                }
                {
                    this.PrimaryGroupSid = "http://schemas.microsoft.com/ws/2008/06/identity/claims/primarygroupsid";
                }
                {
                    this.PrimarySid = "http://schemas.microsoft.com/ws/2008/06/identity/claims/primarysid";
                }
                {
                    this.Role = "http://schemas.microsoft.com/ws/2008/06/identity/claims/role";
                }
                {
                    this.SerialNumber = "http://schemas.microsoft.com/ws/2008/06/identity/claims/serialnumber";
                }
                {
                    this.UserData = "http://schemas.microsoft.com/ws/2008/06/identity/claims/userdata";
                }
                {
                    this.Version = "http://schemas.microsoft.com/ws/2008/06/identity/claims/version";
                }
                {
                    this.WindowsAccountName = "http://schemas.microsoft.com/ws/2008/06/identity/claims/windowsaccountname";
                }
                {
                    this.WindowsDeviceClaim = "http://schemas.microsoft.com/ws/2008/06/identity/claims/windowsdeviceclaim";
                }
                {
                    this.WindowsDeviceGroup = "http://schemas.microsoft.com/ws/2008/06/identity/claims/windowsdevicegroup";
                }
                {
                    this.WindowsUserClaim = "http://schemas.microsoft.com/ws/2008/06/identity/claims/windowsuserclaim";
                }
                {
                    this.WindowsFqbnVersion = "http://schemas.microsoft.com/ws/2008/06/identity/claims/windowsfqbnversion";
                }
                {
                    this.WindowsSubAuthority = "http://schemas.microsoft.com/ws/2008/06/identity/claims/windowssubauthority";
                }
                {
                    this.ClaimType2005Namespace = "http://schemas.xmlsoap.org/ws/2005/05/identity/claims";
                }
                {
                    this.Anonymous = "http://schemas.xmlsoap.org/ws/2005/05/identity/claims/anonymous";
                }
                {
                    this.Authentication = "http://schemas.xmlsoap.org/ws/2005/05/identity/claims/authentication";
                }
                {
                    this.AuthorizationDecision = "http://schemas.xmlsoap.org/ws/2005/05/identity/claims/authorizationdecision";
                }
                {
                    this.Country = "http://schemas.xmlsoap.org/ws/2005/05/identity/claims/country";
                }
                {
                    this.DateOfBirth = "http://schemas.xmlsoap.org/ws/2005/05/identity/claims/dateofbirth";
                }
                {
                    this.Dns = "http://schemas.xmlsoap.org/ws/2005/05/identity/claims/dns";
                }
                {
                    this.DenyOnlySid = "http://schemas.xmlsoap.org/ws/2005/05/identity/claims/denyonlysid";
                }
                {
                    this.Email = "http://schemas.xmlsoap.org/ws/2005/05/identity/claims/emailaddress";
                }
                {
                    this.Gender = "http://schemas.xmlsoap.org/ws/2005/05/identity/claims/gender";
                }
                {
                    this.GivenName = "http://schemas.xmlsoap.org/ws/2005/05/identity/claims/givenname";
                }
                {
                    this.Hash = "http://schemas.xmlsoap.org/ws/2005/05/identity/claims/hash";
                }
                {
                    this.HomePhone = "http://schemas.xmlsoap.org/ws/2005/05/identity/claims/homephone";
                }
                {
                    this.Locality = "http://schemas.xmlsoap.org/ws/2005/05/identity/claims/locality";
                }
                {
                    this.MobilePhone = "http://schemas.xmlsoap.org/ws/2005/05/identity/claims/mobilephone";
                }
                {
                    this.Name = "http://schemas.xmlsoap.org/ws/2005/05/identity/claims/name";
                }
                {
                    this.NameIdentifier = "http://schemas.xmlsoap.org/ws/2005/05/identity/claims/nameidentifier";
                }
                {
                    this.OtherPhone = "http://schemas.xmlsoap.org/ws/2005/05/identity/claims/otherphone";
                }
                {
                    this.PostalCode = "http://schemas.xmlsoap.org/ws/2005/05/identity/claims/postalcode";
                }
                {
                    this.Rsa = "http://schemas.xmlsoap.org/ws/2005/05/identity/claims/rsa";
                }
                {
                    this.Sid = "http://schemas.xmlsoap.org/ws/2005/05/identity/claims/sid";
                }
                {
                    this.Spn = "http://schemas.xmlsoap.org/ws/2005/05/identity/claims/spn";
                }
                {
                    this.StateOrProvince = "http://schemas.xmlsoap.org/ws/2005/05/identity/claims/stateorprovince";
                }
                {
                    this.StreetAddress = "http://schemas.xmlsoap.org/ws/2005/05/identity/claims/streetaddress";
                }
                {
                    this.Surname = "http://schemas.xmlsoap.org/ws/2005/05/identity/claims/surname";
                }
                {
                    this.System = "http://schemas.xmlsoap.org/ws/2005/05/identity/claims/system";
                }
                {
                    this.Thumbprint = "http://schemas.xmlsoap.org/ws/2005/05/identity/claims/thumbprint";
                }
                {
                    this.Upn = "http://schemas.xmlsoap.org/ws/2005/05/identity/claims/upn";
                }
                {
                    this.Uri = "http://schemas.xmlsoap.org/ws/2005/05/identity/claims/uri";
                }
                {
                    this.Webpage = "http://schemas.xmlsoap.org/ws/2005/05/identity/claims/webpage";
                }
                {
                    this.X500DistinguishedName = "http://schemas.xmlsoap.org/ws/2005/05/identity/claims/x500distinguishedname";
                }
                {
                    this.ClaimType2009Namespace = "http://schemas.xmlsoap.org/ws/2009/09/identity/claims";
                }
                {
                    this.Actor = "http://schemas.xmlsoap.org/ws/2009/09/identity/claims/actor";
                }
            }
            static $h = 578235;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"l":[{"t":1310721,"n":"ClaimTypeNamespace","d":578235,"h":4295545531,"f":40},{"t":1310721,"n":"AuthenticationInstant","d":578235,"h":8590512827,"f":33},{"t":1310721,"n":"AuthenticationMethod","d":578235,"h":12885480123,"f":33},{"t":1310721,"n":"CookiePath","d":578235,"h":17180447419,"f":33},{"t":1310721,"n":"DenyOnlyPrimarySid","d":578235,"h":21475414715,"f":33},{"t":1310721,"n":"DenyOnlyPrimaryGroupSid","d":578235,"h":25770382011,"f":33},{"t":1310721,"n":"DenyOnlyWindowsDeviceGroup","d":578235,"h":30065349307,"f":33},{"t":1310721,"n":"Dsa","d":578235,"h":34360316603,"f":33},{"t":1310721,"n":"Expiration","d":578235,"h":38655283899,"f":33},{"t":1310721,"n":"Expired","d":578235,"h":42950251195,"f":33},{"t":1310721,"n":"GroupSid","d":578235,"h":47245218491,"f":33},{"t":1310721,"n":"IsPersistent","d":578235,"h":51540185787,"f":33},{"t":1310721,"n":"PrimaryGroupSid","d":578235,"h":55835153083,"f":33},{"t":1310721,"n":"PrimarySid","d":578235,"h":60130120379,"f":33},{"t":1310721,"n":"Role","d":578235,"h":64425087675,"f":33},{"t":1310721,"n":"SerialNumber","d":578235,"h":68720054971,"f":33},{"t":1310721,"n":"UserData","d":578235,"h":73015022267,"f":33},{"t":1310721,"n":"Version","d":578235,"h":77309989563,"f":33},{"t":1310721,"n":"WindowsAccountName","d":578235,"h":81604956859,"f":33},{"t":1310721,"n":"WindowsDeviceClaim","d":578235,"h":85899924155,"f":33},{"t":1310721,"n":"WindowsDeviceGroup","d":578235,"h":90194891451,"f":33},{"t":1310721,"n":"WindowsUserClaim","d":578235,"h":94489858747,"f":33},{"t":1310721,"n":"WindowsFqbnVersion","d":578235,"h":98784826043,"f":33},{"t":1310721,"n":"WindowsSubAuthority","d":578235,"h":103079793339,"f":33},{"t":1310721,"n":"ClaimType2005Namespace","d":578235,"h":107374760635,"f":40},{"t":1310721,"n":"Anonymous","d":578235,"h":111669727931,"f":33},{"t":1310721,"n":"Authentication","d":578235,"h":115964695227,"f":33},{"t":1310721,"n":"AuthorizationDecision","d":578235,"h":120259662523,"f":33},{"t":1310721,"n":"Country","d":578235,"h":124554629819,"f":33},{"t":1310721,"n":"DateOfBirth","d":578235,"h":128849597115,"f":33},{"t":1310721,"n":"Dns","d":578235,"h":133144564411,"f":33},{"t":1310721,"n":"DenyOnlySid","d":578235,"h":137439531707,"f":33},{"t":1310721,"n":"Email","d":578235,"h":141734499003,"f":33},{"t":1310721,"n":"Gender","d":578235,"h":146029466299,"f":33},{"t":1310721,"n":"GivenName","d":578235,"h":150324433595,"f":33},{"t":1310721,"n":"Hash","d":578235,"h":154619400891,"f":33},{"t":1310721,"n":"HomePhone","d":578235,"h":158914368187,"f":33},{"t":1310721,"n":"Locality","d":578235,"h":163209335483,"f":33},{"t":1310721,"n":"MobilePhone","d":578235,"h":167504302779,"f":33},{"t":1310721,"n":"Name","d":578235,"h":171799270075,"f":33},{"t":1310721,"n":"NameIdentifier","d":578235,"h":176094237371,"f":33},{"t":1310721,"n":"OtherPhone","d":578235,"h":180389204667,"f":33},{"t":1310721,"n":"PostalCode","d":578235,"h":184684171963,"f":33},{"t":1310721,"n":"Rsa","d":578235,"h":188979139259,"f":33},{"t":1310721,"n":"Sid","d":578235,"h":193274106555,"f":33},{"t":1310721,"n":"Spn","d":578235,"h":197569073851,"f":33},{"t":1310721,"n":"StateOrProvince","d":578235,"h":201864041147,"f":33},{"t":1310721,"n":"StreetAddress","d":578235,"h":206159008443,"f":33},{"t":1310721,"n":"Surname","d":578235,"h":210453975739,"f":33},{"t":1310721,"n":"System","d":578235,"h":214748943035,"f":33},{"t":1310721,"n":"Thumbprint","d":578235,"h":219043910331,"f":33},{"t":1310721,"n":"Upn","d":578235,"h":223338877627,"f":33},{"t":1310721,"n":"Uri","d":578235,"h":227633844923,"f":33},{"t":1310721,"n":"Webpage","d":578235,"h":231928812219,"f":33},{"t":1310721,"n":"X500DistinguishedName","d":578235,"h":236223779515,"f":33},{"t":1310721,"n":"ClaimType2009Namespace","d":578235,"h":240518746811,"f":40},{"t":1310721,"n":"Actor","d":578235,"h":244813714107,"f":33}],"h":578235}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.Security.Claims.ClaimTypes`; }
        });
        
        $asm.$cls("$ssc.System.Security.Claims.Claim", ($self) => class Claim extends $.$spc.System.Object
        {
            static $_SerializationMask;
            static get SerializationMask()
            {
                let $cls = $.$ssc.System.Security.Claims.Claim;
                return $cls.$_SerializationMask ??= $asm.$nstr("$ssc.System.Security.Claims.Claim.SerializationMask", ($self) => class SerializationMask extends $.$spc.System.Enum
                {
                    static None = 0;
                    static NameClaimType = 1;
                    static RoleClaimType = 2;
                    static StringType = 4;
                    static Issuer = 8;
                    static OriginalIssuerEqualsIssuer = 16;
                    static OriginalIssuer = 32;
                    static HasProperties = 64;
                    static UserData = 128;
                    static $map;
                    static get Map()
                    {
                        return this.$map ??= 
                        {
                            "None": 0n,
                            "NameClaimType": 1n,
                            "RoleClaimType": 2n,
                            "StringType": 4n,
                            "Issuer": 8n,
                            "OriginalIssuerEqualsIssuer": 16n,
                            "OriginalIssuer": 32n,
                            "HasProperties": 64n,
                            "UserData": 128n
                        };
                    }
                    static $h = 250555;
                    static $z = 4;
                    static $f = 0b110000011010001000;
                    static $k = 4;
                    static get $eut() { return $.$spc.System.Int32; }
                    static $$md;
                    static get $md() { return this.$$md ??= {"b":1048577,"u":655361,"l":[{"t":250555,"n":"None","d":250555,"h":4295217851,"f":33},{"t":250555,"n":"NameClaimType","d":250555,"h":8590185147,"f":33},{"t":250555,"n":"RoleClaimType","d":250555,"h":12885152443,"f":33},{"t":250555,"n":"StringType","d":250555,"h":17180119739,"f":33},{"t":250555,"n":"Issuer","d":250555,"h":21475087035,"f":33},{"t":250555,"n":"OriginalIssuerEqualsIssuer","d":250555,"h":25770054331,"f":33},{"t":250555,"n":"OriginalIssuer","d":250555,"h":30065021627,"f":33},{"t":250555,"n":"HasProperties","d":250555,"h":34359988923,"f":33},{"t":250555,"n":"UserData","d":250555,"h":38654956219,"f":33}],"c":[{"n":".ctor","o":"$ctor$3","d":250555,"h":42949923515,"f":1}],"i":[57278465,63832065,57737217,57409537],"d":185019,"h":250555}; }
                    static get $b() { return $.$spc.System.Enum; }
                    static $$i;
                    static get $i() { return this.$$i ??= [ $.$spc.System.IComparable, $.$spc.System.ISpanFormattable, $.$spc.System.IFormattable, $.$spc.System.IConvertible ]; }
                    static get $fullName() { return `System.Security.Claims.Claim.SerializationMask`; }
                }, $cls, ($v) => $cls.$_SerializationMask = $v);
            }
            /*byte[]?*/ _userSerializationData = null;
            /*string*/ _issuer = null;
            /*string*/ _originalIssuer = null;
            /*Dictionary<string, string>?*/ _properties = null;
            /*ClaimsIdentity?*/ _subject = null;
            /*string*/ _type = null;
            /*string*/ _value = null;
            /*string*/ _valueType = null;
            $ctor$1(/*BinaryReader*/ reader)
            {
                this.$ctor$2(reader, null);
                {
                }
                return this;
            }
            $ctor$2(/*BinaryReader*/ reader, /*ClaimsIdentity?*/ subject)
            {
                super.$ctor();
                {
                    $.$spc.System.ArgumentNullException.ThrowIfNull(reader, "reader");
                    this._subject = subject;
                    /*SerializationMask*/ let mask = $.$cast(reader.ReadInt32(), $.$ssc.System.Security.Claims.Claim.SerializationMask);
                    /*int*/ let numPropertiesRead = 1;
                    /*int*/ let numPropertiesToRead = reader.ReadInt32();
                    this._value = reader.ReadString();
                    if ((mask & 1/*SerializationMask.NameClaimType*/) === 1/*SerializationMask.NameClaimType*/)
                    {
                        this._type = "http://schemas.xmlsoap.org/ws/2005/05/identity/claims/name"/*ClaimsIdentity.DefaultNameClaimType*/;
                    }
                    else if ((mask & 2/*SerializationMask.RoleClaimType*/) === 2/*SerializationMask.RoleClaimType*/)
                    {
                        this._type = "http://schemas.microsoft.com/ws/2008/06/identity/claims/role"/*ClaimsIdentity.DefaultRoleClaimType*/;
                    }
                    else 
                    {
                        this._type = reader.ReadString();
                        numPropertiesRead++;
                    }
                    if ((mask & 4/*SerializationMask.StringType*/) === 4/*SerializationMask.StringType*/)
                    {
                        this._valueType = reader.ReadString();
                        numPropertiesRead++;
                    }
                    else 
                    {
                        this._valueType = "http://www.w3.org/2001/XMLSchema#string"/*ClaimValueTypes.String*/;
                    }
                    if ((mask & 8/*SerializationMask.Issuer*/) === 8/*SerializationMask.Issuer*/)
                    {
                        this._issuer = reader.ReadString();
                        numPropertiesRead++;
                    }
                    else 
                    {
                        this._issuer = "LOCAL AUTHORITY"/*ClaimsIdentity.DefaultIssuer*/;
                    }
                    if ((mask & 16/*SerializationMask.OriginalIssuerEqualsIssuer*/) === 16/*SerializationMask.OriginalIssuerEqualsIssuer*/)
                    {
                        this._originalIssuer = this._issuer;
                    }
                    else if ((mask & 32/*SerializationMask.OriginalIssuer*/) === 32/*SerializationMask.OriginalIssuer*/)
                    {
                        this._originalIssuer = reader.ReadString();
                        numPropertiesRead++;
                    }
                    else 
                    {
                        this._originalIssuer = "LOCAL AUTHORITY"/*ClaimsIdentity.DefaultIssuer*/;
                    }
                    if ((mask & 64/*SerializationMask.HasProperties*/) === 64/*SerializationMask.HasProperties*/)
                    {
                        /*int*/ let numProperties = reader.ReadInt32();
                        numPropertiesRead++;
                        for(/*int*/ let i = 0; i < numProperties; i++)
                        {
                            this.Properties.System$Collections$Generic$IDictionary$$$$Add(reader.ReadString(), reader.ReadString(), [$.$spc.System.String, $.$spc.System.String]);
                        }
                    }
                    if ((mask & 128/*SerializationMask.UserData*/) === 128/*SerializationMask.UserData*/)
                    {
                        /*int*/ let cb = reader.ReadInt32();
                        this._userSerializationData = reader.ReadBytes(cb);
                        numPropertiesRead++;
                    }
                    for(/*int*/ let i = numPropertiesRead; i < numPropertiesToRead; i++)
                    {
                        reader.ReadString();
                    }
                }
                return this;
            }
            $ctor$3(/*string*/ type, /*string*/ value)
            {
                this.$ctor$7(type, value, "http://www.w3.org/2001/XMLSchema#string"/*ClaimValueTypes.String*/, "LOCAL AUTHORITY"/*ClaimsIdentity.DefaultIssuer*/, "LOCAL AUTHORITY"/*ClaimsIdentity.DefaultIssuer*/, null);
                {
                }
                return this;
            }
            $ctor$4(/*string*/ type, /*string*/ value, /*string?*/ valueType)
            {
                this.$ctor$7(type, value, valueType, "LOCAL AUTHORITY"/*ClaimsIdentity.DefaultIssuer*/, "LOCAL AUTHORITY"/*ClaimsIdentity.DefaultIssuer*/, null);
                {
                }
                return this;
            }
            $ctor$5(/*string*/ type, /*string*/ value, /*string?*/ valueType, /*string?*/ issuer)
            {
                this.$ctor$7(type, value, valueType, issuer, issuer, null);
                {
                }
                return this;
            }
            $ctor$6(/*string*/ type, /*string*/ value, /*string?*/ valueType, /*string?*/ issuer, /*string?*/ originalIssuer)
            {
                this.$ctor$7(type, value, valueType, issuer, originalIssuer, null);
                {
                }
                return this;
            }
            $ctor$7(/*string*/ type, /*string*/ value, /*string?*/ valueType, /*string?*/ issuer, /*string?*/ originalIssuer, /*ClaimsIdentity?*/ subject)
            {
                this.$ctor$8(type, value, valueType, issuer, originalIssuer, subject, null, null);
                {
                }
                return this;
            }
            $ctor$8(/*string*/ type, /*string*/ value, /*string?*/ valueType, /*string?*/ issuer, /*string?*/ originalIssuer, /*ClaimsIdentity?*/ subject, /*string?*/ propertyKey, /*string?*/ propertyValue)
            {
                super.$ctor();
                {
                    $.$spc.System.ArgumentNullException.ThrowIfNull(type, "type");
                    $.$spc.System.ArgumentNullException.ThrowIfNull(value, "value");
                    this._type = type;
                    this._value = value;
                    this._valueType = $.$spc.System.String.IsNullOrEmpty(valueType) ? "http://www.w3.org/2001/XMLSchema#string"/*ClaimValueTypes.String*/ : valueType;
                    this._issuer = $.$spc.System.String.IsNullOrEmpty(issuer) ? "LOCAL AUTHORITY"/*ClaimsIdentity.DefaultIssuer*/ : issuer;
                    this._originalIssuer = $.$spc.System.String.IsNullOrEmpty(originalIssuer) ? this._issuer : originalIssuer;
                    this._subject = subject;
                    if ($.$spc.System.String.op_Inequality(propertyKey, null))
                    {
                        this._properties = new ($.$spc.System.Collections.Generic.Dictionary$$$($.$spc.System.String, $.$spc.System.String))().$ctor$1();
                        this._properties.set_Item(propertyKey, propertyValue);
                    }
                }
                return this;
            }
            $ctor$9(/*Claim*/ other)
            {
                this.$ctor$10(other, (other === null ? null : other._subject));
                {
                }
                return this;
            }
            $ctor$10(/*Claim*/ other, /*ClaimsIdentity?*/ subject)
            {
                super.$ctor();
                {
                    $.$spc.System.ArgumentNullException.ThrowIfNull(other, "other");
                    this._issuer = other._issuer;
                    this._originalIssuer = other._originalIssuer;
                    this._subject = subject;
                    this._type = other._type;
                    this._value = other._value;
                    this._valueType = other._valueType;
                    if (other._properties !== null)
                    {
                        this._properties = new ($.$spc.System.Collections.Generic.Dictionary$$$($.$spc.System.String, $.$spc.System.String))().$ctor$5(other._properties);
                    }
                    if (other._userSerializationData !== null)
                    {
                        this._userSerializationData = $.$as(other._userSerializationData.Clone(), $.$typeArray($.$spc.System.Byte));
                    }
                }
                return this;
            }
            /*byte[]? */ get CustomSerializationData()
            {
                return this._userSerializationData;
            }
            /*string */ get Issuer()
            {
                return this._issuer;
            }
            /*string */ get OriginalIssuer()
            {
                return this._originalIssuer;
            }
            /*IDictionary<string, string> */ get Properties()
            {
                return this._properties ??= new ($.$spc.System.Collections.Generic.Dictionary$$$($.$spc.System.String, $.$spc.System.String))().$ctor$1();
            }
            /*ClaimsIdentity? */ get Subject()
            {
                return this._subject;
            }
            /*string */ get Type()
            {
                return this._type;
            }
            /*string */ get Value()
            {
                return this._value;
            }
            /*string */ get ValueType()
            {
                return this._valueType;
            }
            /*Claim */ Clone()
            {
                return this.Clone$1(null);
            }
            /*Claim */ Clone$1(/*ClaimsIdentity?*/ identity)
            {
                return new $.$ssc.System.Security.Claims.Claim().$ctor$10(this, identity);
            }
            /*void */ WriteTo(/*BinaryWriter*/ writer)
            {
                this.WriteTo$1(writer, null);
            }
            /*void */ WriteTo$1(/*BinaryWriter*/ writer, /*byte[]?*/ userData)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(writer, "writer");
                /*int*/ let numberOfPropertiesWritten = 1;
                /*SerializationMask*/ let mask = 0/*SerializationMask.None*/;
                if ($.$spc.System.String.Equals$4(this._type, "http://schemas.xmlsoap.org/ws/2005/05/identity/claims/name"/*ClaimsIdentity.DefaultNameClaimType*/))
                {
                    mask |= 1/*SerializationMask.NameClaimType*/;
                }
                else if ($.$spc.System.String.Equals$4(this._type, "http://schemas.microsoft.com/ws/2008/06/identity/claims/role"/*ClaimsIdentity.DefaultRoleClaimType*/))
                {
                    mask |= 2/*SerializationMask.RoleClaimType*/;
                }
                else 
                {
                    numberOfPropertiesWritten++;
                }
                if (!$.$spc.System.String.Equals$5(this._valueType, "http://www.w3.org/2001/XMLSchema#string"/*ClaimValueTypes.String*/, 4/*StringComparison.Ordinal*/))
                {
                    numberOfPropertiesWritten++;
                    mask |= 4/*SerializationMask.StringType*/;
                }
                if (!$.$spc.System.String.Equals$5(this._issuer, "LOCAL AUTHORITY"/*ClaimsIdentity.DefaultIssuer*/, 4/*StringComparison.Ordinal*/))
                {
                    numberOfPropertiesWritten++;
                    mask |= 8/*SerializationMask.Issuer*/;
                }
                if ($.$spc.System.String.Equals$5(this._originalIssuer, this._issuer, 4/*StringComparison.Ordinal*/))
                {
                    mask |= 16/*SerializationMask.OriginalIssuerEqualsIssuer*/;
                }
                else if (!$.$spc.System.String.Equals$4(this._originalIssuer, "LOCAL AUTHORITY"/*ClaimsIdentity.DefaultIssuer*/))
                {
                    numberOfPropertiesWritten++;
                    mask |= 32/*SerializationMask.OriginalIssuer*/;
                }
                if (this._properties !== null && this._properties.Count > 0)
                {
                    numberOfPropertiesWritten++;
                    mask |= 64/*SerializationMask.HasProperties*/;
                }
                if (userData !== null && userData.length > 0)
                {
                    numberOfPropertiesWritten++;
                    mask |= 128/*SerializationMask.UserData*/;
                }
                writer.Write$12(mask);
                writer.Write$12(numberOfPropertiesWritten);
                writer.Write$18(this._value);
                if (((mask & 1/*SerializationMask.NameClaimType*/) !== 1/*SerializationMask.NameClaimType*/) && ((mask & 2/*SerializationMask.RoleClaimType*/) !== 2/*SerializationMask.RoleClaimType*/))
                {
                    writer.Write$18(this._type);
                }
                if ((mask & 4/*SerializationMask.StringType*/) === 4/*SerializationMask.StringType*/)
                {
                    writer.Write$18(this._valueType);
                }
                if ((mask & 8/*SerializationMask.Issuer*/) === 8/*SerializationMask.Issuer*/)
                {
                    writer.Write$18(this._issuer);
                }
                if ((mask & 32/*SerializationMask.OriginalIssuer*/) === 32/*SerializationMask.OriginalIssuer*/)
                {
                    writer.Write$18(this._originalIssuer);
                }
                if ((mask & 64/*SerializationMask.HasProperties*/) === 64/*SerializationMask.HasProperties*/)
                {
                    writer.Write$12(this._properties.Count);
                    var $en3 = this._properties.GetEnumerator();
                    while ($en3.MoveNext())
                    {
                        var kvp = $en3.Current;
                        {
                            writer.Write$18(kvp.Key);
                            writer.Write$18(kvp.Value);
                        }
                    }
                }
                if ((mask & 128/*SerializationMask.UserData*/) === 128/*SerializationMask.UserData*/)
                {
                    writer.Write$12(userData.length);
                    writer.Write$3(userData);
                }
                writer.Flush();
            }
            static/*conventional*/ /*string */ ToString()
            {
                return this._type + ": " + this._value;
            }
            //Static convention instance redirect
            /*string */ ToString() { return $.$ssc.System.Security.Claims.Claim.ToString.apply(this, arguments); }
            static $h = 185019;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":0,"g":{"r":0,"d":0,"h":90194498235,"f":132},"n":"CustomSerializationData","d":185019,"h":85899530939,"f":132},{"p":1310721,"g":{"r":0,"d":0,"h":98784432827,"f":1},"n":"Issuer","d":185019,"h":94489465531,"f":1},{"p":1310721,"g":{"r":0,"d":0,"h":107374367419,"f":1},"n":"OriginalIssuer","d":185019,"h":103079400123,"f":1},{"p":$.$spc.System.Collections.Generic.IDictionary$$$($.$spc.System.String, $.$spc.System.String).$h,"g":{"r":0,"d":0,"h":115964302011,"f":1},"n":"Properties","d":185019,"h":111669334715,"f":1},{"p":316091,"g":{"r":0,"d":0,"h":124554236603,"f":1},"n":"Subject","d":185019,"h":120259269307,"f":1},{"p":1310721,"g":{"r":0,"d":0,"h":133144171195,"f":1},"n":"Type","d":185019,"h":128849203899,"f":1},{"p":1310721,"g":{"r":0,"d":0,"h":141734105787,"f":1},"n":"Value","d":185019,"h":137439138491,"f":1},{"p":1310721,"g":{"r":0,"d":0,"h":150324040379,"f":1},"n":"ValueType","d":185019,"h":146029073083,"f":1}],"m":[{"r":185019,"n":"Clone","d":185019,"h":154619007675,"f":129},{"r":185019,"p":[{"n":"identity","p":316091}],"n":"Clone","o":"@$1","d":185019,"h":158913974971,"f":129},{"r":65537,"p":[{"n":"writer","p":58523649}],"n":"WriteTo","d":185019,"h":163208942267,"f":129},{"r":65537,"p":[{"n":"writer","p":58523649},{"n":"userData","p":0}],"n":"WriteTo","o":"@$1","d":185019,"h":167503909563,"f":132},{"r":1310721,"n":"ToString","d":185019,"h":171798876859,"f":32769}],"l":[{"t":0,"n":"_userSerializationData","d":185019,"h":8590119611,"f":2},{"t":1310721,"n":"_issuer","d":185019,"h":12885086907,"f":2},{"t":1310721,"n":"_originalIssuer","d":185019,"h":17180054203,"f":2},{"t":$.$spc.System.Collections.Generic.Dictionary$$$($.$spc.System.String, $.$spc.System.String).$h,"n":"_properties","d":185019,"h":21475021499,"f":2},{"t":316091,"n":"_subject","d":185019,"h":25769988795,"f":2},{"t":1310721,"n":"_type","d":185019,"h":30064956091,"f":2},{"t":1310721,"n":"_value","d":185019,"h":34359923387,"f":2},{"t":1310721,"n":"_valueType","d":185019,"h":38654890683,"f":2}],"c":[{"p":[{"n":"reader","p":58458113}],"n":".ctor","o":"$ctor$1","d":185019,"h":42949857979,"f":1},{"p":[{"n":"reader","p":58458113},{"n":"subject","p":316091}],"n":".ctor","o":"$ctor$2","d":185019,"h":47244825275,"f":1},{"p":[{"n":"type","p":1310721},{"n":"value","p":1310721}],"n":".ctor","o":"$ctor$3","d":185019,"h":51539792571,"f":1},{"p":[{"n":"type","p":1310721},{"n":"value","p":1310721},{"n":"valueType","p":1310721}],"n":".ctor","o":"$ctor$4","d":185019,"h":55834759867,"f":1},{"p":[{"n":"type","p":1310721},{"n":"value","p":1310721},{"n":"valueType","p":1310721},{"n":"issuer","p":1310721}],"n":".ctor","o":"$ctor$5","d":185019,"h":60129727163,"f":1},{"p":[{"n":"type","p":1310721},{"n":"value","p":1310721},{"n":"valueType","p":1310721},{"n":"issuer","p":1310721},{"n":"originalIssuer","p":1310721}],"n":".ctor","o":"$ctor$6","d":185019,"h":64424694459,"f":1},{"p":[{"n":"type","p":1310721},{"n":"value","p":1310721},{"n":"valueType","p":1310721},{"n":"issuer","p":1310721},{"n":"originalIssuer","p":1310721},{"n":"subject","p":316091}],"n":".ctor","o":"$ctor$7","d":185019,"h":68719661755,"f":1},{"p":[{"n":"type","p":1310721},{"n":"value","p":1310721},{"n":"valueType","p":1310721},{"n":"issuer","p":1310721},{"n":"originalIssuer","p":1310721},{"n":"subject","p":316091},{"n":"propertyKey","p":1310721},{"n":"propertyValue","p":1310721}],"n":".ctor","o":"$ctor$8","d":185019,"h":73014629051,"f":8},{"p":[{"n":"other","p":185019}],"n":".ctor","o":"$ctor$9","d":185019,"h":77309596347,"f":4},{"p":[{"n":"other","p":185019},{"n":"subject","p":316091}],"n":".ctor","o":"$ctor$10","d":185019,"h":81604563643,"f":4}],"j":[250555],"h":185019}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.Security.Claims.Claim`; }
        });
        
        $asm.$cls("$ssc.System.Security.Claims.ClaimsPrincipal", ($self) => class ClaimsPrincipal extends $.$spc.System.Object
        {
            static $_SerializationMask;
            static get SerializationMask()
            {
                let $cls = $.$ssc.System.Security.Claims.ClaimsPrincipal;
                return $cls.$_SerializationMask ??= $asm.$nstr("$ssc.System.Security.Claims.ClaimsPrincipal.SerializationMask", ($self) => class SerializationMask extends $.$spc.System.Enum
                {
                    static None = 0;
                    static HasIdentities = 1;
                    static UserData = 2;
                    static $map;
                    static get Map()
                    {
                        return this.$map ??= 
                        {
                            "None": 0n,
                            "HasIdentities": 1n,
                            "UserData": 2n
                        };
                    }
                    static $h = 512699;
                    static $z = 4;
                    static $f = 0b110000011010001000;
                    static $k = 4;
                    static get $eut() { return $.$spc.System.Int32; }
                    static $$md;
                    static get $md() { return this.$$md ??= {"b":1048577,"u":655361,"l":[{"t":512699,"n":"None","d":512699,"h":4295479995,"f":33},{"t":512699,"n":"HasIdentities","d":512699,"h":8590447291,"f":33},{"t":512699,"n":"UserData","d":512699,"h":12885414587,"f":33}],"c":[{"n":".ctor","o":"$ctor$3","d":512699,"h":17180381883,"f":1}],"i":[57278465,63832065,57737217,57409537],"d":447163,"h":512699}; }
                    static get $b() { return $.$spc.System.Enum; }
                    static $$i;
                    static get $i() { return this.$$i ??= [ $.$spc.System.IComparable, $.$spc.System.ISpanFormattable, $.$spc.System.IFormattable, $.$spc.System.IConvertible ]; }
                    static get $fullName() { return `System.Security.Claims.ClaimsPrincipal.SerializationMask`; }
                }, $cls, ($v) => $cls.$_SerializationMask = $v);
            }
            /*List<ClaimsIdentity>*/ _identities = null;
            /*byte[]?*/ _userSerializationData = null;
            /*Func<IEnumerable<ClaimsIdentity>, ClaimsIdentity?>*/ static s_identitySelector = null;
            /*Func<ClaimsPrincipal?>?*/ static s_principalSelector = null;
            static /*ClaimsPrincipal? */ SelectClaimsPrincipal()
            {
                /*IPrincipal?*/ let threadPrincipal = $.$spc.System.Threading.Thread.CurrentPrincipal;
                return (() =>
                {
                    {
                        let claimsPrincipal;
                        if ((claimsPrincipal = threadPrincipal, $.$is(claimsPrincipal, $.$ssc.System.Security.Claims.ClaimsPrincipal)))
                        {
                            return claimsPrincipal;
                        }
                    }
                    if (threadPrincipal === null)
                    {
                        return new $.$ssc.System.Security.Claims.ClaimsPrincipal().$ctor$5(threadPrincipal);
                    }
                    if (threadPrincipal === null)
                    {
                        return null;
                    }
                })();
            }
            $ctor$1(/*SerializationInfo*/ info, /*StreamingContext*/ context)
            {
                super.$ctor();
                {
                    throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
                }
                return this;
            }
            static /*ClaimsIdentity? */ SelectPrimaryIdentity(/*IEnumerable<ClaimsIdentity>*/ identities)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(identities, "identities");
                var $en2 = identities.System$Collections$Generic$IEnumerable$$$GetEnumerator();
                while ($en2.System$Collections$IEnumerator$MoveNext())
                {
                    var identity = $en2.System$Collections$Generic$IEnumerator$$$Current;
                    {
                        if (identity !== null)
                        {
                            return identity;
                        }
                    }
                }
                return null;
            }
            static /*Func<IEnumerable<ClaimsIdentity>, ClaimsIdentity?> */ get PrimaryIdentitySelector()
            {
                return $.$ssc.System.Security.Claims.ClaimsPrincipal.s_identitySelector;
            }
            static /*Func<IEnumerable<ClaimsIdentity>, ClaimsIdentity?> */ set PrimaryIdentitySelector(value)
            {
                $.$ssc.System.Security.Claims.ClaimsPrincipal.s_identitySelector = value;
            }
            static /*Func<ClaimsPrincipal?>? */ get ClaimsPrincipalSelector()
            {
                return $.$ssc.System.Security.Claims.ClaimsPrincipal.s_principalSelector;
            }
            static /*Func<ClaimsPrincipal?>? */ set ClaimsPrincipalSelector(value)
            {
                $.$ssc.System.Security.Claims.ClaimsPrincipal.s_principalSelector = value;
            }
            $ctor$2()
            {
                super.$ctor();
                {
                }
                return this;
            }
            $ctor$3(/*IEnumerable<ClaimsIdentity>*/ identities)
            {
                super.$ctor();
                {
                    $.$spc.System.ArgumentNullException.ThrowIfNull(identities, "identities");
                    this._identities.AddRange(identities);
                }
                return this;
            }
            $ctor$4(/*IIdentity*/ identity)
            {
                super.$ctor();
                {
                    $.$spc.System.ArgumentNullException.ThrowIfNull(identity, "identity");
                    let ci;
                    if ($.$is(identity, $.$ssc.System.Security.Claims.ClaimsIdentity, { set $v(v){ ci = v; } }))
                    {
                        this._identities.Add(ci);
                    }
                    else 
                    {
                        this._identities.Add(new $.$ssc.System.Security.Claims.ClaimsIdentity().$ctor$2(identity));
                    }
                }
                return this;
            }
            $ctor$5(/*IPrincipal*/ principal)
            {
                super.$ctor();
                {
                    $.$spc.System.ArgumentNullException.ThrowIfNull(principal, "principal");
                    /*ClaimsPrincipal?*/ let cp = $.$as(principal, $.$ssc.System.Security.Claims.ClaimsPrincipal);
                    if (null === cp)
                    {
                        this._identities.Add(new $.$ssc.System.Security.Claims.ClaimsIdentity().$ctor$2(principal.System$Security$Principal$IPrincipal$Identity));
                    }
                    else 
                    {
                        if (null !== cp.Identities)
                        {
                            this._identities.AddRange(cp.Identities);
                        }
                    }
                }
                return this;
            }
            $ctor$6(/*BinaryReader*/ reader)
            {
                super.$ctor();
                {
                    $.$spc.System.ArgumentNullException.ThrowIfNull(reader, "reader");
                    /*SerializationMask*/ let mask = $.$cast(reader.ReadInt32(), $.$ssc.System.Security.Claims.ClaimsPrincipal.SerializationMask);
                    /*int*/ let numPropertiesToRead = reader.ReadInt32();
                    /*int*/ let numPropertiesRead = 0;
                    if ((mask & 1/*SerializationMask.HasIdentities*/) === 1/*SerializationMask.HasIdentities*/)
                    {
                        numPropertiesRead++;
                        /*int*/ let numberOfIdentities = reader.ReadInt32();
                        for(/*int*/ let index = 0; index < numberOfIdentities; ++index)
                        {
                            this._identities.Add(this.CreateClaimsIdentity(reader));
                        }
                    }
                    if ((mask & 2/*SerializationMask.UserData*/) === 2/*SerializationMask.UserData*/)
                    {
                        /*int*/ let cb = reader.ReadInt32();
                        this._userSerializationData = reader.ReadBytes(cb);
                        numPropertiesRead++;
                    }
                    for(/*int*/ let i = numPropertiesRead; i < numPropertiesToRead; i++)
                    {
                        reader.ReadString();
                    }
                }
                return this;
            }
            /*void */ AddIdentity(/*ClaimsIdentity*/ identity)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(identity, "identity");
                this._identities.Add(identity);
            }
            /*void */ AddIdentities(/*IEnumerable<ClaimsIdentity>*/ identities)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(identities, "identities");
                this._identities.AddRange(identities);
            }
            /*IEnumerable<Claim> */ get Claims()
            {
                return new ($.$spc.NetJs.YieldToIterator$$($.$ssc.System.Security.Claims.Claim))().$ctor$1(function*()
                {
                    var $en3 = this.Identities.System$Collections$Generic$IEnumerable$$$GetEnumerator();
                    while ($en3.System$Collections$IEnumerator$MoveNext())
                    {
                        var identity = $en3.System$Collections$Generic$IEnumerator$$$Current;
                        {
                            var $en5 = identity.Claims.System$Collections$Generic$IEnumerable$$$GetEnumerator();
                            while ($en5.System$Collections$IEnumerator$MoveNext())
                            {
                                var claim = $en5.System$Collections$Generic$IEnumerator$$$Current;
                                {
                                    yield claim;
                                }
                            }
                        }
                    }
                }.bind(this));
            }
            /*byte[]? */ get CustomSerializationData()
            {
                return this._userSerializationData;
            }
            /*ClaimsPrincipal */ Clone()
            {
                return new $.$ssc.System.Security.Claims.ClaimsPrincipal().$ctor$5(this);
            }
            /*ClaimsIdentity */ CreateClaimsIdentity(/*BinaryReader*/ reader)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(reader, "reader");
                return new $.$ssc.System.Security.Claims.ClaimsIdentity().$ctor$10(reader);
            }
            static /*ClaimsPrincipal? */ get Current()
            {
                return !($.$ssc.System.Security.Claims.ClaimsPrincipal.s_principalSelector === null) ? $.$ssc.System.Security.Claims.ClaimsPrincipal.s_principalSelector.Invoke() : $.$ssc.System.Security.Claims.ClaimsPrincipal.SelectClaimsPrincipal();
            }
            /*IEnumerable<Claim> */ FindAll(/*Predicate<Claim>*/ match)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(match, "match");
                return Core.call(this, match);
                /*IEnumerable<Claim>*/  function Core(/*Predicate<Claim>*/ match)
                {
                    return new ($.$spc.NetJs.YieldToIterator$$($.$spc.System.Object))().$ctor$1(function*()
                    {
                        var $en4 = this.Identities.System$Collections$Generic$IEnumerable$$$GetEnumerator();
                        while ($en4.System$Collections$IEnumerator$MoveNext())
                        {
                            var identity = $en4.System$Collections$Generic$IEnumerator$$$Current;
                            {
                                if (identity !== null)
                                {
                                    var $en7 = identity.FindAll(match).System$Collections$Generic$IEnumerable$$$GetEnumerator();
                                    while ($en7.System$Collections$IEnumerator$MoveNext())
                                    {
                                        var claim = $en7.System$Collections$Generic$IEnumerator$$$Current;
                                        {
                                            yield claim;
                                        }
                                    }
                                }
                            }
                        }
                    }.bind(this));
                }
            }
            /*IEnumerable<Claim> */ FindAll$1(/*string*/ type)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(type, "type");
                return Core.call(this, type);
                /*IEnumerable<Claim>*/  function Core(/*string*/ type)
                {
                    return new ($.$spc.NetJs.YieldToIterator$$($.$spc.System.Object))().$ctor$1(function*()
                    {
                        var $en4 = this.Identities.System$Collections$Generic$IEnumerable$$$GetEnumerator();
                        while ($en4.System$Collections$IEnumerator$MoveNext())
                        {
                            var identity = $en4.System$Collections$Generic$IEnumerator$$$Current;
                            {
                                if (identity !== null)
                                {
                                    var $en7 = identity.FindAll$1(type).System$Collections$Generic$IEnumerable$$$GetEnumerator();
                                    while ($en7.System$Collections$IEnumerator$MoveNext())
                                    {
                                        var claim = $en7.System$Collections$Generic$IEnumerator$$$Current;
                                        {
                                            yield claim;
                                        }
                                    }
                                }
                            }
                        }
                    }.bind(this));
                }
            }
            /*Claim? */ FindFirst(/*Predicate<Claim>*/ match)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(match, "match");
                /*Claim?*/ let claim = null;
                var $en2 = this.Identities.System$Collections$Generic$IEnumerable$$$GetEnumerator();
                while ($en2.System$Collections$IEnumerator$MoveNext())
                {
                    var identity = $en2.System$Collections$Generic$IEnumerator$$$Current;
                    {
                        if (identity !== null)
                        {
                            claim = identity.FindFirst(match);
                            if (claim !== null)
                            {
                                return claim;
                            }
                        }
                    }
                }
                return claim;
            }
            /*Claim? */ FindFirst$1(/*string*/ type)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(type, "type");
                /*Claim?*/ let claim = null;
                for(/*int*/ let i = 0; i < this._identities.Count; i++)
                {
                    if (this._identities.get_Item(i) !== null)
                    {
                        claim = this._identities.get_Item(i).FindFirst$1(type);
                        if (claim !== null)
                        {
                            return claim;
                        }
                    }
                }
                return claim;
            }
            /*bool */ HasClaim(/*Predicate<Claim>*/ match)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(match, "match");
                for(/*int*/ let i = 0; i < this._identities.Count; i++)
                {
                    if (this._identities.get_Item(i) !== null)
                    {
                        if (this._identities.get_Item(i).HasClaim(match))
                        {
                            return true;
                        }
                    }
                }
                return false;
            }
            /*bool */ HasClaim$1(/*string*/ type, /*string*/ value)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(type, "type");
                $.$spc.System.ArgumentNullException.ThrowIfNull(value, "value");
                for(/*int*/ let i = 0; i < this._identities.Count; i++)
                {
                    if (this._identities.get_Item(i) !== null)
                    {
                        if (this._identities.get_Item(i).HasClaim$1(type, value))
                        {
                            return true;
                        }
                    }
                }
                return false;
            }
            /*IEnumerable<ClaimsIdentity> */ get Identities()
            {
                return this._identities;
            }
            /*System.Security.Principal.IIdentity? */ get Identity()
            {
                if ($.$ssc.System.Security.Claims.ClaimsPrincipal.s_identitySelector !== null)
                {
                    return $.$ssc.System.Security.Claims.ClaimsPrincipal.s_identitySelector.Invoke(this._identities);
                }
                else 
                {
                    return $.$ssc.System.Security.Claims.ClaimsPrincipal.SelectPrimaryIdentity(this._identities);
                }
            }
            /*bool */ IsInRole(/*string*/ role)
            {
                for(/*int*/ let i = 0; i < this._identities.Count; i++)
                {
                    if (this._identities.get_Item(i) !== null)
                    {
                        if (this._identities.get_Item(i).HasClaim$1(this._identities.get_Item(i).RoleClaimType, role))
                        {
                            return true;
                        }
                    }
                }
                return false;
            }
            /*void */ WriteTo(/*BinaryWriter*/ writer)
            {
                this.WriteTo$1(writer, null);
            }
            /*void */ WriteTo$1(/*BinaryWriter*/ writer, /*byte[]?*/ userData)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(writer, "writer");
                /*int*/ let numberOfPropertiesWritten = 0;
                /*var*/ let mask = 0/*SerializationMask.None*/;
                if (this._identities.Count > 0)
                {
                    mask |= 1/*SerializationMask.HasIdentities*/;
                    numberOfPropertiesWritten++;
                }
                if (userData !== null && userData.length > 0)
                {
                    numberOfPropertiesWritten++;
                    mask |= 2/*SerializationMask.UserData*/;
                }
                writer.Write$12(mask);
                writer.Write$12(numberOfPropertiesWritten);
                if ((mask & 1/*SerializationMask.HasIdentities*/) === 1/*SerializationMask.HasIdentities*/)
                {
                    writer.Write$12(this._identities.Count);
                    var $en3 = this._identities.GetEnumerator();
                    while ($en3.MoveNext())
                    {
                        var identity = $en3.Current;
                        {
                            identity.WriteTo(writer);
                        }
                    }
                }
                if ((mask & 2/*SerializationMask.UserData*/) === 2/*SerializationMask.UserData*/)
                {
                    writer.Write$12(userData.length);
                    writer.Write$3(userData);
                }
                writer.Flush();
            }
            /*void */ OnSerializingMethod(/*StreamingContext*/ context)
            {
                if ($.$is(this, $.$spc.System.Runtime.Serialization.ISerializable))
                {
                    return;
                }
                if (this._identities.Count > 0)
                {
                    throw new $.$spc.System.PlatformNotSupportedException().$ctor$14($.$ssc.System.SR.PlatformNotSupported_Serialization);
                }
            }
            /*void */ GetObjectData(/*SerializationInfo*/ info, /*StreamingContext*/ context)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*string */ DebuggerToString()
            {
                /*int*/ let identitiesCount = 0;
                var $en2 = this.Identities.System$Collections$Generic$IEnumerable$$$GetEnumerator();
                while ($en2.System$Collections$IEnumerator$MoveNext())
                {
                    var items = $en2.System$Collections$Generic$IEnumerator$$$Current;
                    {
                        identitiesCount++;
                    }
                }
                let claimsIdentity;
                if (identitiesCount === 1 && $.$is(this.Identity, $.$ssc.System.Security.Claims.ClaimsIdentity, { set $v(v){ claimsIdentity = v; } }))
                {
                    return claimsIdentity.DebuggerToString();
                }
                /*int*/ let claimsCount = 0;
                var $en2 = this.Claims.System$Collections$Generic$IEnumerable$$$GetEnumerator();
                while ($en2.System$Collections$IEnumerator$MoveNext())
                {
                    var item = $en2.System$Collections$Generic$IEnumerator$$$Current;
                    {
                        claimsCount++;
                    }
                }
                return `Identities = ${identitiesCount}, Claims = ${claimsCount}`;
            }
            //Generated interface implemetation for System.Security.Principal.IPrincipal.Identity.get
            get System$Security$Principal$IPrincipal$Identity()
            {
                return this.Identity;
            }
            //Generated interface implemetation for System.Security.Principal.IPrincipal.IsInRole(string)
            System$Security$Principal$IPrincipal$IsInRole()
            {
                return this.IsInRole(...arguments);
            }
            //default member initializer
            constructor()
            {
                super();
                this._identities = new ($.$spc.System.Collections.Generic.List$$($.$ssc.System.Security.Claims.ClaimsIdentity))().$ctor$1();
            }
            //Static Initializer
            static $sinit()
            {
                {
                    this.s_identitySelector = new ($.$spc.System.Func$$$($.$spc.System.Collections.Generic.IEnumerable$$($.$ssc.System.Security.Claims.ClaimsIdentity), $.$ssc.System.Security.Claims.ClaimsIdentity))().$ctor($.$ssc.System.Security.Claims.ClaimsPrincipal, $.$ssc.System.Security.Claims.ClaimsPrincipal.SelectPrimaryIdentity);
                }
            }
            static $h = 447163;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":$.$spc.System.Func$$$($.$spc.System.Collections.Generic.IEnumerable$$($.$ssc.System.Security.Claims.ClaimsIdentity), $.$ssc.System.Security.Claims.ClaimsIdentity).$h,"g":{"r":0,"d":0,"h":42950120123,"f":33},"s":{"r":0,"d":0,"h":47245087419,"f":33},"n":"PrimaryIdentitySelector","d":447163,"h":38655152827,"f":33},{"p":$.$spc.System.Func$$($.$ssc.System.Security.Claims.ClaimsPrincipal).$h,"g":{"r":0,"d":0,"h":55835022011,"f":33},"s":{"r":0,"d":0,"h":60129989307,"f":33},"n":"ClaimsPrincipalSelector","d":447163,"h":51540054715,"f":33},{"p":$.$spc.System.Collections.Generic.IEnumerable$$($.$ssc.System.Security.Claims.Claim).$h,"g":{"r":0,"d":0,"h":98784694971,"f":129},"n":"Claims","d":447163,"h":94489727675,"f":129},{"p":0,"g":{"r":0,"d":0,"h":107374629563,"f":132},"n":"CustomSerializationData","d":447163,"h":103079662267,"f":132},{"p":447163,"g":{"r":0,"d":0,"h":124554498747,"f":33},"n":"Current","d":447163,"h":120259531451,"f":33},{"p":$.$spc.System.Collections.Generic.IEnumerable$$($.$ssc.System.Security.Claims.ClaimsIdentity).$h,"g":{"r":0,"d":0,"h":158914237115,"f":129},"n":"Identities","d":447163,"h":154619269819,"f":129},{"p":117047297,"g":{"r":0,"d":0,"h":167504171707,"f":129},"n":"Identity","d":447163,"h":163209204411,"f":129}],"m":[{"r":447163,"n":"SelectClaimsPrincipal","d":447163,"h":25770250939,"f":34},{"r":316091,"p":[{"n":"identities","p":$.$spc.System.Collections.Generic.IEnumerable$$($.$ssc.System.Security.Claims.ClaimsIdentity).$h}],"n":"SelectPrimaryIdentity","d":447163,"h":34360185531,"f":34},{"r":65537,"p":[{"n":"identity","p":316091}],"n":"AddIdentity","d":447163,"h":85899793083,"f":129},{"r":65537,"p":[{"n":"identities","p":$.$spc.System.Collections.Generic.IEnumerable$$($.$ssc.System.Security.Claims.ClaimsIdentity).$h}],"n":"AddIdentities","d":447163,"h":90194760379,"f":129},{"r":447163,"n":"Clone","d":447163,"h":111669596859,"f":129},{"r":316091,"p":[{"n":"reader","p":58458113}],"n":"CreateClaimsIdentity","d":447163,"h":115964564155,"f":132},{"r":$.$spc.System.Collections.Generic.IEnumerable$$($.$ssc.System.Security.Claims.Claim).$h,"p":[{"n":"match","p":$.$spc.System.Predicate$$($.$ssc.System.Security.Claims.Claim).$h}],"n":"FindAll","d":447163,"h":128849466043,"f":129},{"r":$.$spc.System.Collections.Generic.IEnumerable$$($.$ssc.System.Security.Claims.Claim).$h,"p":[{"n":"type","p":1310721}],"n":"FindAll","o":"@$1","d":447163,"h":133144433339,"f":129},{"r":185019,"p":[{"n":"match","p":$.$spc.System.Predicate$$($.$ssc.System.Security.Claims.Claim).$h}],"n":"FindFirst","d":447163,"h":137439400635,"f":129},{"r":185019,"p":[{"n":"type","p":1310721}],"n":"FindFirst","o":"@$1","d":447163,"h":141734367931,"f":129},{"r":262145,"p":[{"n":"match","p":$.$spc.System.Predicate$$($.$ssc.System.Security.Claims.Claim).$h}],"n":"HasClaim","d":447163,"h":146029335227,"f":129},{"r":262145,"p":[{"n":"type","p":1310721},{"n":"value","p":1310721}],"n":"HasClaim","o":"@$1","d":447163,"h":150324302523,"f":129},{"r":262145,"p":[{"n":"role","p":1310721}],"n":"IsInRole","d":447163,"h":171799139003,"f":129},{"r":65537,"p":[{"n":"writer","p":58523649}],"n":"WriteTo","d":447163,"h":176094106299,"f":129},{"r":65537,"p":[{"n":"writer","p":58523649},{"n":"userData","p":0}],"n":"WriteTo","o":"@$1","d":447163,"h":180389073595,"f":132},{"r":65537,"p":[{"n":"context","p":114098177}],"n":"OnSerializingMethod","d":447163,"h":184684040891,"f":2,"a":[{"t":113639425,"c":4408606721}]},{"r":65537,"p":[{"n":"info","p":113967105},{"n":"context","p":114098177}],"n":"GetObjectData","d":447163,"h":188979008187,"f":132},{"r":1310721,"n":"DebuggerToString","d":447163,"h":193273975483,"f":2}],"l":[{"t":$.$spc.System.Collections.Generic.List$$($.$ssc.System.Security.Claims.ClaimsIdentity).$h,"n":"_identities","d":447163,"h":8590381755,"f":2},{"t":0,"n":"_userSerializationData","d":447163,"h":12885349051,"f":2},{"t":$.$spc.System.Func$$$($.$spc.System.Collections.Generic.IEnumerable$$($.$ssc.System.Security.Claims.ClaimsIdentity), $.$ssc.System.Security.Claims.ClaimsIdentity).$h,"n":"s_identitySelector","d":447163,"h":17180316347,"f":34},{"t":$.$spc.System.Func$$($.$ssc.System.Security.Claims.ClaimsPrincipal).$h,"n":"s_principalSelector","d":447163,"h":21475283643,"f":34}],"c":[{"p":[{"n":"info","p":113967105},{"n":"context","p":114098177}],"n":".ctor","o":"$ctor$1","d":447163,"h":30065218235,"f":4,"a":[{"t":70909953,"c":8660844545,"a":[{"v":"This API supports obsolete formatter-based serialization. It should not be called or extended by application code.","t":1310721}],"n":[{"n":"DiagnosticId","v":"SYSLIB0051","t":1310721},{"n":"UrlFormat","v":"https://aka.ms/dotnet-warnings/{0}","t":1310721}]},{"t":33226753,"c":4328194049,"a":[{"v":1,"t":33292289}]}]},{"n":".ctor","o":"$ctor$2","d":447163,"h":64424956603,"f":1},{"p":[{"n":"identities","p":$.$spc.System.Collections.Generic.IEnumerable$$($.$ssc.System.Security.Claims.ClaimsIdentity).$h}],"n":".ctor","o":"$ctor$3","d":447163,"h":68719923899,"f":1},{"p":[{"n":"identity","p":117047297}],"n":".ctor","o":"$ctor$4","d":447163,"h":73014891195,"f":1},{"p":[{"n":"principal","p":117112833}],"n":".ctor","o":"$ctor$5","d":447163,"h":77309858491,"f":1},{"p":[{"n":"reader","p":58458113}],"n":".ctor","o":"$ctor$6","d":447163,"h":81604825787,"f":1}],"i":[117112833],"j":[512699],"h":447163,"a":[{"t":37617665,"c":8627552257,"a":[{"v":"{DebuggerToString(),nq}","t":1310721}]}]}; }
            static get $b() { return $.$spc.System.Object; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.Security.Principal.IPrincipal ]; }
            static get $fullName() { return `System.Security.Claims.ClaimsPrincipal`; }
        });
        
        $asm.$cls("$ssc.System.Security.Claims.ClaimsIdentity", ($self) => class ClaimsIdentity extends $.$spc.System.Object
        {
            static $_SerializationMask;
            static get SerializationMask()
            {
                let $cls = $.$ssc.System.Security.Claims.ClaimsIdentity;
                return $cls.$_SerializationMask ??= $asm.$nstr("$ssc.System.Security.Claims.ClaimsIdentity.SerializationMask", ($self) => class SerializationMask extends $.$spc.System.Enum
                {
                    static None = 0;
                    static AuthenticationType = 1;
                    static BootstrapConext = 2;
                    static NameClaimType = 4;
                    static RoleClaimType = 8;
                    static HasClaims = 16;
                    static HasLabel = 32;
                    static Actor = 64;
                    static UserData = 128;
                    static $map;
                    static get Map()
                    {
                        return this.$map ??= 
                        {
                            "None": 0n,
                            "AuthenticationType": 1n,
                            "BootstrapConext": 2n,
                            "NameClaimType": 4n,
                            "RoleClaimType": 8n,
                            "HasClaims": 16n,
                            "HasLabel": 32n,
                            "Actor": 64n,
                            "UserData": 128n
                        };
                    }
                    static $h = 381627;
                    static $z = 4;
                    static $f = 0b110000011010001000;
                    static $k = 4;
                    static get $eut() { return $.$spc.System.Int32; }
                    static $$md;
                    static get $md() { return this.$$md ??= {"b":1048577,"u":655361,"l":[{"t":381627,"n":"None","d":381627,"h":4295348923,"f":33},{"t":381627,"n":"AuthenticationType","d":381627,"h":8590316219,"f":33},{"t":381627,"n":"BootstrapConext","d":381627,"h":12885283515,"f":33},{"t":381627,"n":"NameClaimType","d":381627,"h":17180250811,"f":33},{"t":381627,"n":"RoleClaimType","d":381627,"h":21475218107,"f":33},{"t":381627,"n":"HasClaims","d":381627,"h":25770185403,"f":33},{"t":381627,"n":"HasLabel","d":381627,"h":30065152699,"f":33},{"t":381627,"n":"Actor","d":381627,"h":34360119995,"f":33},{"t":381627,"n":"UserData","d":381627,"h":38655087291,"f":33}],"c":[{"n":".ctor","o":"$ctor$3","d":381627,"h":42950054587,"f":1}],"i":[57278465,63832065,57737217,57409537],"d":316091,"h":381627}; }
                    static get $b() { return $.$spc.System.Enum; }
                    static $$i;
                    static get $i() { return this.$$i ??= [ $.$spc.System.IComparable, $.$spc.System.ISpanFormattable, $.$spc.System.IFormattable, $.$spc.System.IConvertible ]; }
                    static get $fullName() { return `System.Security.Claims.ClaimsIdentity.SerializationMask`; }
                }, $cls, ($v) => $cls.$_SerializationMask = $v);
            }
            /*byte[]?*/ _userSerializationData = null;
            /*ClaimsIdentity?*/ _actor = null;
            /*string?*/ _authenticationType = null;
            /*object?*/ _bootstrapContext = null;
            /*List<List<Claim>>?*/ _externalClaims = null;
            /*string?*/ _label = null;
            /*List<Claim>*/ _instanceClaims = null;
            /*string*/ _nameClaimType = null;
            /*string*/ _roleClaimType = null;
            /*StringComparison*/ _stringComparison = 5;
            /*string*/ static DefaultIssuer = null;
            /*string*/ static DefaultNameClaimType = null;
            /*string*/ static DefaultRoleClaimType = null;
            $ctor$1()
            {
                this.$ctor$9(null, null, null, null, null);
                {
                }
                return this;
            }
            $ctor$2(/*IIdentity?*/ identity)
            {
                this.$ctor$9(identity, null, null, null, null);
                {
                }
                return this;
            }
            $ctor$3(/*IEnumerable<Claim>?*/ claims)
            {
                this.$ctor$9(null, claims, null, null, null);
                {
                }
                return this;
            }
            $ctor$4(/*string?*/ authenticationType)
            {
                this.$ctor$9(null, null, authenticationType, null, null);
                {
                }
                return this;
            }
            $ctor$5(/*IEnumerable<Claim>?*/ claims, /*string?*/ authenticationType)
            {
                this.$ctor$9(null, claims, authenticationType, null, null);
                {
                }
                return this;
            }
            $ctor$6(/*IIdentity?*/ identity, /*IEnumerable<Claim>?*/ claims)
            {
                this.$ctor$9(identity, claims, null, null, null);
                {
                }
                return this;
            }
            $ctor$7(/*string?*/ authenticationType, /*string?*/ nameType, /*string?*/ roleType)
            {
                this.$ctor$9(null, null, authenticationType, nameType, roleType);
                {
                }
                return this;
            }
            $ctor$8(/*IEnumerable<Claim>?*/ claims, /*string?*/ authenticationType, /*string?*/ nameType, /*string?*/ roleType)
            {
                this.$ctor$9(null, claims, authenticationType, nameType, roleType);
                {
                }
                return this;
            }
            $ctor$9(/*IIdentity?*/ identity, /*IEnumerable<Claim>?*/ claims, /*string?*/ authenticationType, /*string?*/ nameType, /*string?*/ roleType)
            {
                super.$ctor();
                {
                    /*ClaimsIdentity?*/ let claimsIdentity = $.$as(identity, $.$ssc.System.Security.Claims.ClaimsIdentity);
                    this._authenticationType = (identity !== null && $.$spc.System.String.IsNullOrEmpty(authenticationType)) ? identity.System$Security$Principal$IIdentity$AuthenticationType : authenticationType;
                    this._nameClaimType = !$.$spc.System.String.IsNullOrEmpty(nameType) ? nameType : (claimsIdentity !== null ? claimsIdentity._nameClaimType : "http://schemas.xmlsoap.org/ws/2005/05/identity/claims/name"/*DefaultNameClaimType*/);
                    this._roleClaimType = !$.$spc.System.String.IsNullOrEmpty(roleType) ? roleType : (claimsIdentity !== null ? claimsIdentity._roleClaimType : "http://schemas.microsoft.com/ws/2008/06/identity/claims/role"/*DefaultRoleClaimType*/);
                    if (claimsIdentity !== null)
                    {
                        this._label = claimsIdentity._label;
                        this._bootstrapContext = claimsIdentity._bootstrapContext;
                        if (claimsIdentity.Actor !== null)
                        {
                            if (!this.IsCircular(claimsIdentity.Actor))
                            {
                                this._actor = claimsIdentity.Actor;
                            }
                            else 
                            {
                                throw new $.$spc.System.InvalidOperationException().$ctor$10($.$ssc.System.SR.InvalidOperationException_ActorGraphCircular);
                            }
                        }
                        this.SafeAddClaims(claimsIdentity._instanceClaims);
                    }
                    else 
                    {
                        if (identity !== null && !$.$spc.System.String.IsNullOrEmpty(identity.System$Security$Principal$IIdentity$Name))
                        {
                            this.SafeAddClaim(new $.$ssc.System.Security.Claims.Claim().$ctor$7(this._nameClaimType, identity.System$Security$Principal$IIdentity$Name, "http://www.w3.org/2001/XMLSchema#string"/*ClaimValueTypes.String*/, "LOCAL AUTHORITY"/*DefaultIssuer*/, "LOCAL AUTHORITY"/*DefaultIssuer*/, this));
                        }
                    }
                    if (claims !== null)
                    {
                        this.SafeAddClaims(claims);
                    }
                }
                return this;
            }
            $ctor$10(/*BinaryReader*/ reader)
            {
                super.$ctor();
                {
                    $.$spc.System.ArgumentNullException.ThrowIfNull(reader, "reader");
                    this.Initialize$1(reader);
                }
                return this;
            }
            $ctor$11(/*BinaryReader*/ reader, /*StringComparison*/ stringComparison)
            {
                super.$ctor();
                {
                    $.$spc.System.ArgumentNullException.ThrowIfNull(reader, "reader");
                    $.$ssc.System.Security.Claims.ClaimsIdentity.ValidateStringComparison(stringComparison);
                    this._stringComparison = stringComparison;
                    this.Initialize$1(reader);
                }
                return this;
            }
            $ctor$12(/*ClaimsIdentity*/ other)
            {
                super.$ctor();
                {
                    $.$spc.System.ArgumentNullException.ThrowIfNull(other, "other");
                    this.Initialize(other);
                }
                return this;
            }
            $ctor$13(/*ClaimsIdentity*/ other, /*StringComparison*/ stringComparison)
            {
                super.$ctor();
                {
                    $.$spc.System.ArgumentNullException.ThrowIfNull(other, "other");
                    $.$ssc.System.Security.Claims.ClaimsIdentity.ValidateStringComparison(stringComparison);
                    this._stringComparison = stringComparison;
                    this.Initialize(other);
                }
                return this;
            }
            $ctor$14(/*IIdentity?*/ identity, /*IEnumerable<Claim>?*/ claims, /*string?*/ authenticationType, /*string?*/ nameType, /*string?*/ roleType, /*StringComparison*/ stringComparison)
            {
                this.$ctor$9(identity, claims, authenticationType, nameType, roleType);
                {
                    $.$ssc.System.Security.Claims.ClaimsIdentity.ValidateStringComparison(stringComparison);
                    this._stringComparison = stringComparison;
                }
                return this;
            }
            $ctor$15(/*SerializationInfo*/ info, /*StreamingContext*/ context)
            {
                super.$ctor();
                {
                    throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
                }
                return this;
            }
            $ctor$16(/*SerializationInfo*/ info)
            {
                super.$ctor();
                {
                    throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
                }
                return this;
            }
            /*string? */ get AuthenticationType()
            {
                return this._authenticationType;
            }
            /*bool */ get IsAuthenticated()
            {
                return !$.$spc.System.String.IsNullOrEmpty(this._authenticationType);
            }
            /*ClaimsIdentity? */ get Actor()
            {
                return this._actor;
            }
            /*ClaimsIdentity? */ set Actor(value)
            {
                if (value !== null)
                {
                    if (this.IsCircular(value))
                    {
                        throw new $.$spc.System.InvalidOperationException().$ctor$10($.$ssc.System.SR.InvalidOperationException_ActorGraphCircular);
                    }
                }
                this._actor = value;
            }
            /*object? */ get BootstrapContext()
            {
                return this._bootstrapContext;
            }
            /*object? */ set BootstrapContext(value)
            {
                this._bootstrapContext = value;
            }
            /*IEnumerable<Claim> */ get Claims()
            {
                if (this._externalClaims === null)
                {
                    return this._instanceClaims;
                }
                return this.CombinedClaimsIterator();
            }
            /*IEnumerable<Claim> */ CombinedClaimsIterator()
            {
                return new ($.$spc.NetJs.YieldToIterator$$($.$spc.System.Object))().$ctor$1(function*()
                {
                    for(/*int*/ let i = 0; i < this._instanceClaims.Count; i++)
                    {
                        yield this._instanceClaims.get_Item(i);
                    }
                    for(/*int*/ let j = 0; j < this._externalClaims.Count; j++)
                    {
                        if (this._externalClaims.get_Item(j) !== null)
                        {
                            var $en5 = this._externalClaims.get_Item(j).GetEnumerator();
                            while ($en5.MoveNext())
                            {
                                var claim = $en5.Current;
                                {
                                    yield claim;
                                }
                            }
                        }
                    }
                }.bind(this));
            }
            /*byte[]? */ get CustomSerializationData()
            {
                return this._userSerializationData;
            }
            /*List<List<Claim>> */ get ExternalClaims()
            {
                return this._externalClaims ??= new ($.$spc.System.Collections.Generic.List$$($.$spc.System.Collections.Generic.List$$($.$ssc.System.Security.Claims.Claim)))().$ctor$1();
            }
            /*string? */ get Label()
            {
                return this._label;
            }
            /*string? */ set Label(value)
            {
                this._label = value;
            }
            /*string? */ get Name()
            {
                /*Claim?*/ let claim = this.FindFirst$1(this._nameClaimType);
                if (claim !== null)
                {
                    return claim.Value;
                }
                return null;
            }
            /*string */ get NameClaimType()
            {
                return this._nameClaimType;
            }
            /*string */ get RoleClaimType()
            {
                return this._roleClaimType;
            }
            /*ClaimsIdentity */ Clone()
            {
                return new $.$ssc.System.Security.Claims.ClaimsIdentity().$ctor$13(this, this._stringComparison);
            }
            /*void */ AddClaim(/*Claim*/ claim)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(claim, "claim");
                if ($.$spc.System.Object.ReferenceEquals(claim.Subject, this))
                {
                    this._instanceClaims.Add(claim);
                }
                else 
                {
                    this._instanceClaims.Add(claim.Clone$1(this));
                }
            }
            /*void */ AddClaims(/*IEnumerable<Claim?>*/ claims)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(claims, "claims");
                var $en2 = claims.System$Collections$Generic$IEnumerable$$$GetEnumerator();
                while ($en2.System$Collections$IEnumerator$MoveNext())
                {
                    var claim = $en2.System$Collections$Generic$IEnumerator$$$Current;
                    {
                        if (claim === null)
                        {
                            continue;
                        }
                        if ($.$spc.System.Object.ReferenceEquals(claim.Subject, this))
                        {
                            this._instanceClaims.Add(claim);
                        }
                        else 
                        {
                            this._instanceClaims.Add(claim.Clone$1(this));
                        }
                    }
                }
            }
            /*bool */ TryRemoveClaim(/*Claim?*/ claim)
            {
                if (claim === null)
                {
                    return false;
                }
                /*bool*/ let removed = false;
                for(/*int*/ let i = 0; i < this._instanceClaims.Count; i++)
                {
                    if ($.$spc.System.Object.ReferenceEquals(this._instanceClaims.get_Item(i), claim))
                    {
                        this._instanceClaims.RemoveAt(i);
                        removed = true;
                        break;
                    }
                }
                return removed;
            }
            /*void */ RemoveClaim(/*Claim?*/ claim)
            {
                if (!this.TryRemoveClaim(claim))
                {
                    throw new $.$spc.System.InvalidOperationException().$ctor$10($.$ssc.System.SR.Format($.$ssc.System.SR.InvalidOperation_ClaimCannotBeRemoved, claim));
                }
            }
            /*void */ SafeAddClaims(/*IEnumerable<Claim?>*/ claims)
            {
                var $en2 = claims.System$Collections$Generic$IEnumerable$$$GetEnumerator();
                while ($en2.System$Collections$IEnumerator$MoveNext())
                {
                    var claim = $en2.System$Collections$Generic$IEnumerator$$$Current;
                    {
                        if (claim === null)
                        {
                            continue;
                        }
                        if ($.$spc.System.Object.ReferenceEquals(claim.Subject, this))
                        {
                            this._instanceClaims.Add(claim);
                        }
                        else 
                        {
                            this._instanceClaims.Add(claim.Clone$1(this));
                        }
                    }
                }
            }
            /*void */ SafeAddClaim(/*Claim?*/ claim)
            {
                if (claim === null)
                {
                    return;
                }
                if ($.$spc.System.Object.ReferenceEquals(claim.Subject, this))
                {
                    this._instanceClaims.Add(claim);
                }
                else 
                {
                    this._instanceClaims.Add(claim.Clone$1(this));
                }
            }
            /*IEnumerable<Claim> */ FindAll(/*Predicate<Claim>*/ match)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(match, "match");
                return Core.call(this, match);
                /*IEnumerable<Claim>*/  function Core(/*Predicate<Claim>*/ match)
                {
                    return new ($.$spc.NetJs.YieldToIterator$$($.$spc.System.Object))().$ctor$1(function*()
                    {
                        var $en4 = this.Claims.System$Collections$Generic$IEnumerable$$$GetEnumerator();
                        while ($en4.System$Collections$IEnumerator$MoveNext())
                        {
                            var claim = $en4.System$Collections$Generic$IEnumerator$$$Current;
                            {
                                if (match.Invoke(claim))
                                {
                                    yield claim;
                                }
                            }
                        }
                    }.bind(this));
                }
            }
            /*IEnumerable<Claim> */ FindAll$1(/*string*/ type)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(type, "type");
                return Core.call(this, type);
                /*IEnumerable<Claim>*/  function Core(/*string*/ type)
                {
                    return new ($.$spc.NetJs.YieldToIterator$$($.$spc.System.Object))().$ctor$1(function*()
                    {
                        var $en4 = this.Claims.System$Collections$Generic$IEnumerable$$$GetEnumerator();
                        while ($en4.System$Collections$IEnumerator$MoveNext())
                        {
                            var claim = $en4.System$Collections$Generic$IEnumerator$$$Current;
                            {
                                if (claim !== null)
                                {
                                    if ($.$spc.System.String.Equals$5(claim.Type, type, this._stringComparison))
                                    {
                                        yield claim;
                                    }
                                }
                            }
                        }
                    }.bind(this));
                }
            }
            /*Claim? */ FindFirst(/*Predicate<Claim>*/ match)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(match, "match");
                var $en2 = this.Claims.System$Collections$Generic$IEnumerable$$$GetEnumerator();
                while ($en2.System$Collections$IEnumerator$MoveNext())
                {
                    var claim = $en2.System$Collections$Generic$IEnumerator$$$Current;
                    {
                        if (match.Invoke(claim))
                        {
                            return claim;
                        }
                    }
                }
                return null;
            }
            /*Claim? */ FindFirst$1(/*string*/ type)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(type, "type");
                var $en2 = this.Claims.System$Collections$Generic$IEnumerable$$$GetEnumerator();
                while ($en2.System$Collections$IEnumerator$MoveNext())
                {
                    var claim = $en2.System$Collections$Generic$IEnumerator$$$Current;
                    {
                        if (claim !== null)
                        {
                            if ($.$spc.System.String.Equals$5(claim.Type, type, this._stringComparison))
                            {
                                return claim;
                            }
                        }
                    }
                }
                return null;
            }
            /*bool */ HasClaim(/*Predicate<Claim>*/ match)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(match, "match");
                var $en2 = this.Claims.System$Collections$Generic$IEnumerable$$$GetEnumerator();
                while ($en2.System$Collections$IEnumerator$MoveNext())
                {
                    var claim = $en2.System$Collections$Generic$IEnumerator$$$Current;
                    {
                        if (match.Invoke(claim))
                        {
                            return true;
                        }
                    }
                }
                return false;
            }
            /*bool */ HasClaim$1(/*string*/ type, /*string*/ value)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(type, "type");
                $.$spc.System.ArgumentNullException.ThrowIfNull(value, "value");
                var $en2 = this.Claims.System$Collections$Generic$IEnumerable$$$GetEnumerator();
                while ($en2.System$Collections$IEnumerator$MoveNext())
                {
                    var claim = $en2.System$Collections$Generic$IEnumerator$$$Current;
                    {
                        if (claim !== null && $.$spc.System.String.Equals$5(claim.Type, type, this._stringComparison) && $.$spc.System.String.Equals$5(claim.Value, value, 4/*StringComparison.Ordinal*/))
                        {
                            return true;
                        }
                    }
                }
                return false;
            }
            /*void */ Initialize(/*ClaimsIdentity*/ other)
            {
                if (other._actor !== null)
                {
                    this._actor = other._actor.Clone();
                }
                this._authenticationType = other._authenticationType;
                this._bootstrapContext = other._bootstrapContext;
                this._label = other._label;
                this._nameClaimType = other._nameClaimType;
                this._roleClaimType = other._roleClaimType;
                if (other._userSerializationData !== null)
                {
                    this._userSerializationData = $.$as(other._userSerializationData.Clone(), $.$typeArray($.$spc.System.Byte));
                }
                this.SafeAddClaims(other._instanceClaims);
            }
            /*void */ Initialize$1(/*BinaryReader*/ reader)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(reader, "reader");
                /*SerializationMask*/ let mask = $.$cast(reader.ReadInt32(), $.$ssc.System.Security.Claims.ClaimsIdentity.SerializationMask);
                /*int*/ let numPropertiesRead = 0;
                /*int*/ let numPropertiesToRead = reader.ReadInt32();
                if ((mask & 1/*SerializationMask.AuthenticationType*/) === 1/*SerializationMask.AuthenticationType*/)
                {
                    this._authenticationType = reader.ReadString();
                    numPropertiesRead++;
                }
                if ((mask & 2/*SerializationMask.BootstrapConext*/) === 2/*SerializationMask.BootstrapConext*/)
                {
                    this._bootstrapContext = reader.ReadString();
                    numPropertiesRead++;
                }
                if ((mask & 4/*SerializationMask.NameClaimType*/) === 4/*SerializationMask.NameClaimType*/)
                {
                    this._nameClaimType = reader.ReadString();
                    numPropertiesRead++;
                }
                else 
                {
                    this._nameClaimType = "http://schemas.xmlsoap.org/ws/2005/05/identity/claims/name"/*ClaimsIdentity.DefaultNameClaimType*/;
                }
                if ((mask & 8/*SerializationMask.RoleClaimType*/) === 8/*SerializationMask.RoleClaimType*/)
                {
                    this._roleClaimType = reader.ReadString();
                    numPropertiesRead++;
                }
                else 
                {
                    this._roleClaimType = "http://schemas.microsoft.com/ws/2008/06/identity/claims/role"/*ClaimsIdentity.DefaultRoleClaimType*/;
                }
                if ((mask & 32/*SerializationMask.HasLabel*/) === 32/*SerializationMask.HasLabel*/)
                {
                    this._label = reader.ReadString();
                    numPropertiesRead++;
                }
                if ((mask & 16/*SerializationMask.HasClaims*/) === 16/*SerializationMask.HasClaims*/)
                {
                    /*int*/ let numberOfClaims = reader.ReadInt32();
                    for(/*int*/ let index = 0; index < numberOfClaims; index++)
                    {
                        this._instanceClaims.Add(this.CreateClaim(reader));
                    }
                    numPropertiesRead++;
                }
                if ((mask & 64/*SerializationMask.Actor*/) === 64/*SerializationMask.Actor*/)
                {
                    this._actor = new $.$ssc.System.Security.Claims.ClaimsIdentity().$ctor$10(reader);
                    numPropertiesRead++;
                }
                if ((mask & 128/*SerializationMask.UserData*/) === 128/*SerializationMask.UserData*/)
                {
                    /*int*/ let cb = reader.ReadInt32();
                    this._userSerializationData = reader.ReadBytes(cb);
                    numPropertiesRead++;
                }
                for(/*int*/ let i = numPropertiesRead; i < numPropertiesToRead; i++)
                {
                    reader.ReadString();
                }
            }
            /*Claim */ CreateClaim(/*BinaryReader*/ reader)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(reader, "reader");
                return new $.$ssc.System.Security.Claims.Claim().$ctor$2(reader, this);
            }
            /*void */ WriteTo(/*BinaryWriter*/ writer)
            {
                this.WriteTo$1(writer, null);
            }
            /*void */ WriteTo$1(/*BinaryWriter*/ writer, /*byte[]?*/ userData)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(writer, "writer");
                /*int*/ let numberOfPropertiesWritten = 0;
                /*var*/ let mask = 0/*SerializationMask.None*/;
                if ($.$spc.System.String.op_Inequality(this._authenticationType, null))
                {
                    mask |= 1/*SerializationMask.AuthenticationType*/;
                    numberOfPropertiesWritten++;
                }
                if (this._bootstrapContext !== null)
                {
                    if ($.$is(this._bootstrapContext, $.$spc.System.String))
                    {
                        mask |= 2/*SerializationMask.BootstrapConext*/;
                        numberOfPropertiesWritten++;
                    }
                }
                if (!$.$spc.System.String.Equals$5(this._nameClaimType, "http://schemas.xmlsoap.org/ws/2005/05/identity/claims/name"/*ClaimsIdentity.DefaultNameClaimType*/, 4/*StringComparison.Ordinal*/))
                {
                    mask |= 4/*SerializationMask.NameClaimType*/;
                    numberOfPropertiesWritten++;
                }
                if (!$.$spc.System.String.Equals$5(this._roleClaimType, "http://schemas.microsoft.com/ws/2008/06/identity/claims/role"/*ClaimsIdentity.DefaultRoleClaimType*/, 4/*StringComparison.Ordinal*/))
                {
                    mask |= 8/*SerializationMask.RoleClaimType*/;
                    numberOfPropertiesWritten++;
                }
                if (!$.$spc.System.String.IsNullOrWhiteSpace(this._label))
                {
                    mask |= 32/*SerializationMask.HasLabel*/;
                    numberOfPropertiesWritten++;
                }
                if (this._instanceClaims.Count > 0)
                {
                    mask |= 16/*SerializationMask.HasClaims*/;
                    numberOfPropertiesWritten++;
                }
                if (this._actor !== null)
                {
                    mask |= 64/*SerializationMask.Actor*/;
                    numberOfPropertiesWritten++;
                }
                if (userData !== null && userData.length > 0)
                {
                    numberOfPropertiesWritten++;
                    mask |= 128/*SerializationMask.UserData*/;
                }
                writer.Write$12(mask);
                writer.Write$12(numberOfPropertiesWritten);
                if ((mask & 1/*SerializationMask.AuthenticationType*/) === 1/*SerializationMask.AuthenticationType*/)
                {
                    writer.Write$18(this._authenticationType);
                }
                if ((mask & 2/*SerializationMask.BootstrapConext*/) === 2/*SerializationMask.BootstrapConext*/)
                {
                    writer.Write$18($.$cast(this._bootstrapContext, $.$spc.System.String));
                }
                if ((mask & 4/*SerializationMask.NameClaimType*/) === 4/*SerializationMask.NameClaimType*/)
                {
                    writer.Write$18(this._nameClaimType);
                }
                if ((mask & 8/*SerializationMask.RoleClaimType*/) === 8/*SerializationMask.RoleClaimType*/)
                {
                    writer.Write$18(this._roleClaimType);
                }
                if ((mask & 32/*SerializationMask.HasLabel*/) === 32/*SerializationMask.HasLabel*/)
                {
                    writer.Write$18(this._label);
                }
                if ((mask & 16/*SerializationMask.HasClaims*/) === 16/*SerializationMask.HasClaims*/)
                {
                    writer.Write$12(this._instanceClaims.Count);
                    var $en3 = this._instanceClaims.GetEnumerator();
                    while ($en3.MoveNext())
                    {
                        var claim = $en3.Current;
                        {
                            claim.WriteTo(writer);
                        }
                    }
                }
                if ((mask & 64/*SerializationMask.Actor*/) === 64/*SerializationMask.Actor*/)
                {
                    this._actor.WriteTo(writer);
                }
                if ((mask & 128/*SerializationMask.UserData*/) === 128/*SerializationMask.UserData*/)
                {
                    writer.Write$12(userData.length);
                    writer.Write$3(userData);
                }
                writer.Flush();
            }
            /*bool */ IsCircular(/*ClaimsIdentity*/ subject)
            {
                if ($.$spc.System.Object.ReferenceEquals(this, subject))
                {
                    return true;
                }
                /*ClaimsIdentity*/ let currSubject = subject;
                while(currSubject.Actor !== null)
                {
                    if ($.$spc.System.Object.ReferenceEquals(this, currSubject.Actor))
                    {
                        return true;
                    }
                    currSubject = currSubject.Actor;
                }
                return false;
            }
            /*void */ GetObjectData(/*SerializationInfo*/ info, /*StreamingContext*/ context)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*string */ DebuggerToString()
            {
                /*int*/ let claimsCount = 0;
                var $en2 = this.Claims.System$Collections$Generic$IEnumerable$$$GetEnumerator();
                while ($en2.System$Collections$IEnumerator$MoveNext())
                {
                    var item = $en2.System$Collections$Generic$IEnumerator$$$Current;
                    {
                        claimsCount++;
                    }
                }
                /*string*/ let debugText = `IsAuthenticated = ${(this.IsAuthenticated ? "true" : "false")}`;
                if ($.$spc.System.String.op_Inequality(this.Name, null))
                {
                    debugText += `, Name = ${this.Name}`;
                }
                if (claimsCount > 0)
                {
                    debugText += `, Claims = ${claimsCount}`;
                }
                return debugText;
            }
            static /*void */ ValidateStringComparison(/*StringComparison*/ stringComparison)
            {
                switch(stringComparison)
                {
                    case 4/*StringComparison.Ordinal*/:
                    case 5/*StringComparison.OrdinalIgnoreCase*/:
                    case 2/*StringComparison.InvariantCulture*/:
                    case 3/*StringComparison.InvariantCultureIgnoreCase*/:
                    break;
                    default:
                    throw new $.$spc.System.ArgumentException().$ctor$13($.$ssc.System.SR.ArgumentException_StringComparisonCultureAware, "stringComparison");
                }
            }
            //Generated interface implemetation for System.Security.Principal.IIdentity.Name.get
            get System$Security$Principal$IIdentity$Name()
            {
                return this.Name;
            }
            //Generated interface implemetation for System.Security.Principal.IIdentity.AuthenticationType.get
            get System$Security$Principal$IIdentity$AuthenticationType()
            {
                return this.AuthenticationType;
            }
            //Generated interface implemetation for System.Security.Principal.IIdentity.IsAuthenticated.get
            get System$Security$Principal$IIdentity$IsAuthenticated()
            {
                return this.IsAuthenticated;
            }
            //default member initializer
            constructor()
            {
                super();
                this._instanceClaims = new ($.$spc.System.Collections.Generic.List$$($.$ssc.System.Security.Claims.Claim))().$ctor$1();
                this._nameClaimType = "http://schemas.xmlsoap.org/ws/2005/05/identity/claims/name";
                this._roleClaimType = "http://schemas.microsoft.com/ws/2008/06/identity/claims/role";
            }
            //Static Initializer
            static $sinit()
            {
                {
                    this.DefaultIssuer = "LOCAL AUTHORITY";
                }
                {
                    this.DefaultNameClaimType = "http://schemas.xmlsoap.org/ws/2005/05/identity/claims/name";
                }
                {
                    this.DefaultRoleClaimType = "http://schemas.microsoft.com/ws/2008/06/identity/claims/role";
                }
            }
            static $h = 316091;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":1310721,"g":{"r":0,"d":0,"h":137439269563,"f":129},"n":"AuthenticationType","d":316091,"h":133144302267,"f":129},{"p":262145,"g":{"r":0,"d":0,"h":146029204155,"f":129},"n":"IsAuthenticated","d":316091,"h":141734236859,"f":129},{"p":316091,"g":{"r":0,"d":0,"h":154619138747,"f":1},"s":{"r":0,"d":0,"h":158914106043,"f":1},"n":"Actor","d":316091,"h":150324171451,"f":1},{"p":131073,"g":{"r":0,"d":0,"h":167504040635,"f":1},"s":{"r":0,"d":0,"h":171799007931,"f":1},"n":"BootstrapContext","d":316091,"h":163209073339,"f":1},{"p":$.$spc.System.Collections.Generic.IEnumerable$$($.$ssc.System.Security.Claims.Claim).$h,"g":{"r":0,"d":0,"h":180388942523,"f":129},"n":"Claims","d":316091,"h":176093975227,"f":129},{"p":0,"g":{"r":0,"d":0,"h":193273844411,"f":132},"n":"CustomSerializationData","d":316091,"h":188978877115,"f":132},{"p":$.$spc.System.Collections.Generic.List$$($.$spc.System.Collections.Generic.List$$($.$ssc.System.Security.Claims.Claim)).$h,"g":{"r":0,"d":0,"h":201863779003,"f":8},"n":"ExternalClaims","d":316091,"h":197568811707,"f":8},{"p":1310721,"g":{"r":0,"d":0,"h":210453713595,"f":1},"s":{"r":0,"d":0,"h":214748680891,"f":1},"n":"Label","d":316091,"h":206158746299,"f":1},{"p":1310721,"g":{"r":0,"d":0,"h":223338615483,"f":129},"n":"Name","d":316091,"h":219043648187,"f":129},{"p":1310721,"g":{"r":0,"d":0,"h":231928550075,"f":1},"n":"NameClaimType","d":316091,"h":227633582779,"f":1},{"p":1310721,"g":{"r":0,"d":0,"h":240518484667,"f":1},"n":"RoleClaimType","d":316091,"h":236223517371,"f":1}],"m":[{"r":$.$spc.System.Collections.Generic.IEnumerable$$($.$ssc.System.Security.Claims.Claim).$h,"n":"CombinedClaimsIterator","d":316091,"h":184683909819,"f":2},{"r":316091,"n":"Clone","d":316091,"h":244813451963,"f":129},{"r":65537,"p":[{"n":"claim","p":185019}],"n":"AddClaim","d":316091,"h":249108419259,"f":129},{"r":65537,"p":[{"n":"claims","p":$.$spc.System.Collections.Generic.IEnumerable$$($.$ssc.System.Security.Claims.Claim).$h}],"n":"AddClaims","d":316091,"h":253403386555,"f":129},{"r":262145,"p":[{"n":"claim","p":185019}],"n":"TryRemoveClaim","d":316091,"h":257698353851,"f":129},{"r":65537,"p":[{"n":"claim","p":185019}],"n":"RemoveClaim","d":316091,"h":261993321147,"f":129},{"r":65537,"p":[{"n":"claims","p":$.$spc.System.Collections.Generic.IEnumerable$$($.$ssc.System.Security.Claims.Claim).$h}],"n":"SafeAddClaims","d":316091,"h":266288288443,"f":2},{"r":65537,"p":[{"n":"claim","p":185019}],"n":"SafeAddClaim","d":316091,"h":270583255739,"f":2},{"r":$.$spc.System.Collections.Generic.IEnumerable$$($.$ssc.System.Security.Claims.Claim).$h,"p":[{"n":"match","p":$.$spc.System.Predicate$$($.$ssc.System.Security.Claims.Claim).$h}],"n":"FindAll","d":316091,"h":274878223035,"f":129},{"r":$.$spc.System.Collections.Generic.IEnumerable$$($.$ssc.System.Security.Claims.Claim).$h,"p":[{"n":"type","p":1310721}],"n":"FindAll","o":"@$1","d":316091,"h":279173190331,"f":129},{"r":185019,"p":[{"n":"match","p":$.$spc.System.Predicate$$($.$ssc.System.Security.Claims.Claim).$h}],"n":"FindFirst","d":316091,"h":283468157627,"f":129},{"r":185019,"p":[{"n":"type","p":1310721}],"n":"FindFirst","o":"@$1","d":316091,"h":287763124923,"f":129},{"r":262145,"p":[{"n":"match","p":$.$spc.System.Predicate$$($.$ssc.System.Security.Claims.Claim).$h}],"n":"HasClaim","d":316091,"h":292058092219,"f":129},{"r":262145,"p":[{"n":"type","p":1310721},{"n":"value","p":1310721}],"n":"HasClaim","o":"@$1","d":316091,"h":296353059515,"f":129},{"r":65537,"p":[{"n":"other","p":316091}],"n":"Initialize","d":316091,"h":300648026811,"f":2},{"r":65537,"p":[{"n":"reader","p":58458113}],"n":"Initialize","o":"@$1","d":316091,"h":304942994107,"f":2},{"r":185019,"p":[{"n":"reader","p":58458113}],"n":"CreateClaim","d":316091,"h":309237961403,"f":132},{"r":65537,"p":[{"n":"writer","p":58523649}],"n":"WriteTo","d":316091,"h":313532928699,"f":129},{"r":65537,"p":[{"n":"writer","p":58523649},{"n":"userData","p":0}],"n":"WriteTo","o":"@$1","d":316091,"h":317827895995,"f":132},{"r":262145,"p":[{"n":"subject","p":316091}],"n":"IsCircular","d":316091,"h":322122863291,"f":2},{"r":65537,"p":[{"n":"info","p":113967105},{"n":"context","p":114098177}],"n":"GetObjectData","d":316091,"h":326417830587,"f":132},{"r":1310721,"n":"DebuggerToString","d":316091,"h":330712797883,"f":8},{"r":65537,"p":[{"n":"stringComparison","p":119472129}],"n":"ValidateStringComparison","d":316091,"h":335007765179,"f":34}],"l":[{"t":0,"n":"_userSerializationData","d":316091,"h":8590250683,"f":2},{"t":316091,"n":"_actor","d":316091,"h":12885217979,"f":2},{"t":1310721,"n":"_authenticationType","d":316091,"h":17180185275,"f":2},{"t":131073,"n":"_bootstrapContext","d":316091,"h":21475152571,"f":2},{"t":$.$spc.System.Collections.Generic.List$$($.$spc.System.Collections.Generic.List$$($.$ssc.System.Security.Claims.Claim)).$h,"n":"_externalClaims","d":316091,"h":25770119867,"f":2},{"t":1310721,"n":"_label","d":316091,"h":30065087163,"f":2},{"t":$.$spc.System.Collections.Generic.List$$($.$ssc.System.Security.Claims.Claim).$h,"n":"_instanceClaims","d":316091,"h":34360054459,"f":2},{"t":1310721,"n":"_nameClaimType","d":316091,"h":38655021755,"f":2},{"t":1310721,"n":"_roleClaimType","d":316091,"h":42949989051,"f":2},{"t":119472129,"n":"_stringComparison","d":316091,"h":47244956347,"f":2},{"t":1310721,"n":"DefaultIssuer","d":316091,"h":51539923643,"f":33},{"t":1310721,"n":"DefaultNameClaimType","d":316091,"h":55834890939,"f":33},{"t":1310721,"n":"DefaultRoleClaimType","d":316091,"h":60129858235,"f":33}],"c":[{"n":".ctor","o":"$ctor$1","d":316091,"h":64424825531,"f":1},{"p":[{"n":"identity","p":117047297}],"n":".ctor","o":"$ctor$2","d":316091,"h":68719792827,"f":1},{"p":[{"n":"claims","p":$.$spc.System.Collections.Generic.IEnumerable$$($.$ssc.System.Security.Claims.Claim).$h}],"n":".ctor","o":"$ctor$3","d":316091,"h":73014760123,"f":1},{"p":[{"n":"authenticationType","p":1310721}],"n":".ctor","o":"$ctor$4","d":316091,"h":77309727419,"f":1},{"p":[{"n":"claims","p":$.$spc.System.Collections.Generic.IEnumerable$$($.$ssc.System.Security.Claims.Claim).$h},{"n":"authenticationType","p":1310721}],"n":".ctor","o":"$ctor$5","d":316091,"h":81604694715,"f":1},{"p":[{"n":"identity","p":117047297},{"n":"claims","p":$.$spc.System.Collections.Generic.IEnumerable$$($.$ssc.System.Security.Claims.Claim).$h}],"n":".ctor","o":"$ctor$6","d":316091,"h":85899662011,"f":1},{"p":[{"n":"authenticationType","p":1310721},{"n":"nameType","p":1310721},{"n":"roleType","p":1310721}],"n":".ctor","o":"$ctor$7","d":316091,"h":90194629307,"f":1},{"p":[{"n":"claims","p":$.$spc.System.Collections.Generic.IEnumerable$$($.$ssc.System.Security.Claims.Claim).$h},{"n":"authenticationType","p":1310721},{"n":"nameType","p":1310721},{"n":"roleType","p":1310721}],"n":".ctor","o":"$ctor$8","d":316091,"h":94489596603,"f":1},{"p":[{"n":"identity","p":117047297},{"n":"claims","p":$.$spc.System.Collections.Generic.IEnumerable$$($.$ssc.System.Security.Claims.Claim).$h},{"n":"authenticationType","p":1310721},{"n":"nameType","p":1310721},{"n":"roleType","p":1310721}],"n":".ctor","o":"$ctor$9","d":316091,"h":98784563899,"f":1},{"p":[{"n":"reader","p":58458113}],"n":".ctor","o":"$ctor$10","d":316091,"h":103079531195,"f":1},{"p":[{"n":"reader","p":58458113},{"n":"stringComparison","p":119472129}],"n":".ctor","o":"$ctor$11","d":316091,"h":107374498491,"f":1},{"p":[{"n":"other","p":316091}],"n":".ctor","o":"$ctor$12","d":316091,"h":111669465787,"f":4},{"p":[{"n":"other","p":316091},{"n":"stringComparison","p":119472129}],"n":".ctor","o":"$ctor$13","d":316091,"h":115964433083,"f":4},{"p":[{"n":"identity","p":117047297,"f":65},{"n":"claims","p":$.$spc.System.Collections.Generic.IEnumerable$$($.$ssc.System.Security.Claims.Claim).$h,"f":65},{"n":"authenticationType","p":1310721,"f":65},{"n":"nameType","p":1310721,"f":65},{"n":"roleType","p":1310721,"f":65},{"n":"stringComparison","p":119472129,"f":65,"v":5}],"n":".ctor","o":"$ctor$14","d":316091,"h":120259400379,"f":1},{"p":[{"n":"info","p":113967105},{"n":"context","p":114098177}],"n":".ctor","o":"$ctor$15","d":316091,"h":124554367675,"f":4,"a":[{"t":70909953,"c":8660844545,"a":[{"v":"This API supports obsolete formatter-based serialization. It should not be called or extended by application code.","t":1310721}],"n":[{"n":"DiagnosticId","v":"SYSLIB0051","t":1310721},{"n":"UrlFormat","v":"https://aka.ms/dotnet-warnings/{0}","t":1310721}]},{"t":33226753,"c":4328194049,"a":[{"v":1,"t":33292289}]}]},{"p":[{"n":"info","p":113967105}],"n":".ctor","o":"$ctor$16","d":316091,"h":128849334971,"f":4,"a":[{"t":70909953,"c":8660844545,"a":[{"v":"This API supports obsolete formatter-based serialization. It should not be called or extended by application code.","t":1310721}],"n":[{"n":"DiagnosticId","v":"SYSLIB0051","t":1310721},{"n":"UrlFormat","v":"https://aka.ms/dotnet-warnings/{0}","t":1310721}]},{"t":33226753,"c":4328194049,"a":[{"v":1,"t":33292289}]}]}],"i":[117047297],"j":[381627],"h":316091,"a":[{"t":37617665,"c":8627552257,"a":[{"v":"{DebuggerToString(),nq}","t":1310721}]}]}; }
            static get $b() { return $.$spc.System.Object; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.Security.Principal.IIdentity ]; }
            static get $fullName() { return `System.Security.Claims.ClaimsIdentity`; }
        });
        
        $asm.$cls("$ssc.System.Security.Principal.GenericPrincipal", ($self) => class GenericPrincipal extends $.$ssc.System.Security.Claims.ClaimsPrincipal
        {
            /*IIdentity*/ m_identity = null;
            /*string[]?*/ m_roles = null;
            $ctor$7(/*IIdentity*/ identity, /*string[]?*/ roles)
            {
                super.$ctor$2();
                {
                    $.$spc.System.ArgumentNullException.ThrowIfNull(identity, "identity");
                    this.m_identity = identity;
                    if (roles !== null)
                    {
                        this.m_roles = $.$cast(roles.Clone(), $.$typeArray($.$spc.System.String));
                    }
                    else 
                    {
                        this.m_roles = null;
                    }
                    this.AddIdentityWithRoles(this.m_identity, this.m_roles);
                }
                return this;
            }
            /*void */ AddIdentityWithRoles(/*IIdentity*/ identity, /*string[]?*/ roles)
            {
                let claimsIdentity;
                if ($.$is(identity, $.$ssc.System.Security.Claims.ClaimsIdentity, { set $v(v){ claimsIdentity = v; } }))
                {
                    claimsIdentity = claimsIdentity.Clone();
                }
                else 
                {
                    claimsIdentity = new $.$ssc.System.Security.Claims.ClaimsIdentity().$ctor$2(identity);
                }
                if (roles !== null && roles.length > 0)
                {
                    /*List<Claim>*/ let roleClaims = new ($.$spc.System.Collections.Generic.List$$($.$ssc.System.Security.Claims.Claim))().$ctor$2(roles.length);
                    let $i1 = 0;
                    let $arr1 = roles;
                    while ($i1 < $arr1.length)
                    {
                        let role = $arr1[$i1++];
                        if (!$.$spc.System.String.IsNullOrWhiteSpace(role))
                        {
                            roleClaims.Add(new $.$ssc.System.Security.Claims.Claim().$ctor$7(claimsIdentity.RoleClaimType, role, "http://www.w3.org/2001/XMLSchema#string"/*ClaimValueTypes.String*/, "LOCAL AUTHORITY"/*ClaimsIdentity.DefaultIssuer*/, "LOCAL AUTHORITY"/*ClaimsIdentity.DefaultIssuer*/, claimsIdentity));
                        }
                    }
                    claimsIdentity.ExternalClaims.Add(roleClaims);
                }
                super.AddIdentity(claimsIdentity);
            }
            /*IIdentity */ get Identity()
            {
                return this.m_identity;
            }
            /*bool */ IsInRole(/*string?*/ role)
            {
                if ($.$spc.System.String.op_Equality(role, null) || this.m_roles === null)
                {
                    return false;
                }
                for(/*int*/ let i = 0; i < this.m_roles.length; ++i)
                {
                    if ($.$spc.System.String.Equals$5($.$spc.System.Array.$ReadT1.call(this.m_roles, i), role, 5/*StringComparison.OrdinalIgnoreCase*/))
                    {
                        return true;
                    }
                }
                return super.IsInRole(role);
            }
            static /*GenericPrincipal */ GetDefaultInstance()
            {
                return new $.$ssc.System.Security.Principal.GenericPrincipal().$ctor$7(new $.$ssc.System.Security.Principal.GenericIdentity().$ctor$17($.$spc.System.String.Empty), $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$spc.System.String), [$.$spc.System.String.Empty], [-1], null));
            }
            static $h = 774843;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":447163,"p":[{"p":117047297,"g":{"r":0,"d":0,"h":25770578619,"f":32769},"n":"Identity","d":774843,"h":21475611323,"f":32769}],"m":[{"r":65537,"p":[{"n":"identity","p":117047297},{"n":"roles","p":0}],"n":"AddIdentityWithRoles","d":774843,"h":17180644027,"f":2},{"r":262145,"p":[{"n":"role","p":1310721}],"n":"IsInRole","d":774843,"h":30065545915,"f":32769},{"r":774843,"n":"GetDefaultInstance","d":774843,"h":34360513211,"f":34}],"l":[{"t":117047297,"n":"m_identity","d":774843,"h":4295742139,"f":2},{"t":0,"n":"m_roles","d":774843,"h":8590709435,"f":2}],"c":[{"p":[{"n":"identity","p":117047297},{"n":"roles","p":0}],"n":".ctor","o":"$ctor$7","d":774843,"h":12885676731,"f":1}],"i":[117112833],"h":774843}; }
            static get $b() { return $.$ssc.System.Security.Claims.ClaimsPrincipal; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.Security.Principal.IPrincipal ]; }
            static get $fullName() { return `System.Security.Principal.GenericPrincipal`; }
        });
        
        $asm.$cls("$ssc.System.Security.Principal.GenericIdentity", ($self) => class GenericIdentity extends $.$ssc.System.Security.Claims.ClaimsIdentity
        {
            /*string*/ m_name = null;
            /*string*/ m_type = null;
            $ctor$17(/*string*/ name)
            {
                super.$ctor$14(null, null, null, null, null, 5);
                {
                    $.$spc.System.ArgumentNullException.ThrowIfNull(name, "name");
                    this.m_name = name;
                    this.m_type = "";
                    this.AddNameClaim();
                }
                return this;
            }
            $ctor$18(/*string*/ name, /*string*/ type)
            {
                super.$ctor$14(null, null, null, null, null, 5);
                {
                    $.$spc.System.ArgumentNullException.ThrowIfNull(name, "name");
                    $.$spc.System.ArgumentNullException.ThrowIfNull(type, "type");
                    this.m_name = name;
                    this.m_type = type;
                    this.AddNameClaim();
                }
                return this;
            }
            $ctor$19(/*GenericIdentity*/ identity)
            {
                super.$ctor$12(identity);
                {
                    this.m_name = identity.m_name;
                    this.m_type = identity.m_type;
                }
                return this;
            }
            /*ClaimsIdentity */ Clone()
            {
                return new $.$ssc.System.Security.Principal.GenericIdentity().$ctor$19(this);
            }
            /*IEnumerable<Claim> */ get Claims()
            {
                return super.Claims;
            }
            /*string */ get Name()
            {
                return this.m_name;
            }
            /*string */ get AuthenticationType()
            {
                return this.m_type;
            }
            /*bool */ get IsAuthenticated()
            {
                return !$.$spc.System.String.Equals$2.call(this.m_name, "");
            }
            /*void */ AddNameClaim()
            {
                if ($.$spc.System.String.op_Inequality(this.m_name, null))
                {
                    super.AddClaim(new $.$ssc.System.Security.Claims.Claim().$ctor$7(super.NameClaimType, this.m_name, "http://www.w3.org/2001/XMLSchema#string"/*ClaimValueTypes.String*/, "LOCAL AUTHORITY"/*ClaimsIdentity.DefaultIssuer*/, "LOCAL AUTHORITY"/*ClaimsIdentity.DefaultIssuer*/, this));
                }
            }
            static $h = 709307;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":316091,"p":[{"p":$.$spc.System.Collections.Generic.IEnumerable$$($.$ssc.System.Security.Claims.Claim).$h,"g":{"r":0,"d":0,"h":34360447675,"f":32769},"n":"Claims","d":709307,"h":30065480379,"f":32769},{"p":1310721,"g":{"r":0,"d":0,"h":42950382267,"f":32769},"n":"Name","d":709307,"h":38655414971,"f":32769},{"p":1310721,"g":{"r":0,"d":0,"h":51540316859,"f":32769},"n":"AuthenticationType","d":709307,"h":47245349563,"f":32769},{"p":262145,"g":{"r":0,"d":0,"h":60130251451,"f":32769},"n":"IsAuthenticated","d":709307,"h":55835284155,"f":32769}],"m":[{"r":316091,"n":"Clone","d":709307,"h":25770513083,"f":32769},{"r":65537,"n":"AddNameClaim","d":709307,"h":64425218747,"f":2}],"l":[{"t":1310721,"n":"m_name","d":709307,"h":4295676603,"f":2},{"t":1310721,"n":"m_type","d":709307,"h":8590643899,"f":2}],"c":[{"p":[{"n":"name","p":1310721}],"n":".ctor","o":"$ctor$17","d":709307,"h":12885611195,"f":1},{"p":[{"n":"name","p":1310721},{"n":"type","p":1310721}],"n":".ctor","o":"$ctor$18","d":709307,"h":17180578491,"f":1},{"p":[{"n":"identity","p":709307}],"n":".ctor","o":"$ctor$19","d":709307,"h":21475545787,"f":4}],"i":[117047297],"h":709307}; }
            static get $b() { return $.$ssc.System.Security.Claims.ClaimsIdentity; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.Security.Principal.IIdentity ]; }
            static get $fullName() { return `System.Security.Principal.GenericIdentity`; }
        });
	});
})(window, window.NetJs.$boot(), ...window.NetJs.$require("NetJs.System.Private.CoreLib", "NetJs.System.Collections", "NetJs.System.Memory", "NetJs.System.Private.Uri", "NetJs.System.Runtime", "NetJs.System.Threading.Thread"))