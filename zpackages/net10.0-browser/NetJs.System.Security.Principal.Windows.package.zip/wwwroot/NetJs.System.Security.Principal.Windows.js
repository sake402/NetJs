
(function ($global, $, $$, $mwp, $sc, $sdt, $st, $scc, $sm, $spu, $sr, $sris, $stt, $ssc) {
    "use strict";
    let _;
    
    
    
	$.$asm(
    "NetJs.System.Security.Principal.Windows", 
    {"h":51918,"f":"System.Security.Principal.Windows","v":"1.0.35.0","a":[{"t":115015681,"c":12999917569,"a":[{"v":".NETCoreApp,Version=v10.0","t":1310721}],"n":[{"n":"FrameworkDisplayName","v":".NET 10.0","t":1310721}]},{"t":73596929,"c":4368564225,"a":[{"v":"SIT","t":1310721}]},{"t":73662465,"c":4368629761,"a":[{"v":"Debug","t":1310721}]},{"t":74121217,"c":4369088513,"a":[{"v":"1.0.35.0","t":1310721}]},{"t":74252289,"c":4369219585,"a":[{"v":"1.0.35\u002Beff628fa5ab8bd29ec37e9c13a50148694bea088","t":1310721}]},{"t":75104257,"c":4370071553,"a":[{"v":"NetJs.System.Security.Principal.Windows","t":1310721}]},{"t":75235329,"c":4370202625,"a":[{"v":"NetJs.System.Security.Principal.Windows","t":1310721}]},{"t":75366401,"c":4370333697,"a":[{"v":"1.0.35.0","t":1310721}]},{"t":115081217,"c":4410048513,"a":[{"v":"browser1.0","t":1310721}]},{"t":114819073,"c":4409786369,"a":[{"v":"browser1.0","t":1310721}]}],"m":[]},
    function($asm)
	{
        
        
        $asm.$cls("$sspw.System.Security.Principal.IdentityReference", ($self) => class IdentityReference extends $.$$.System.Object
        {
            $ctor$1()
            {
                super.$ctor();
                {
                }
                return this;
            }
            static /*bool */ op_Equality(/*System.Security.Principal.IdentityReference?*/ left, /*System.Security.Principal.IdentityReference?*/ right)
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            static /*bool */ op_Inequality(/*System.Security.Principal.IdentityReference?*/ left, /*System.Security.Principal.IdentityReference?*/ right)
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            static $h = 248526;
            static $f = 0b110001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":1310721,"g":{"r":0,"d":0,"h":12885150414,"f":50331905},"n":"Value","d":248526,"h":8590183118,"f":2097409}],"m":[{"r":262145,"p":[{"n":"o","p":131073}],"n":"Equals","o":"@$1","d":248526,"h":17180117710,"f":16810241},{"r":655361,"n":"GetHashCode","d":248526,"h":21475085006,"f":16810241},{"r":262145,"p":[{"n":"targetType","p":142475265}],"n":"IsValidTargetType","d":248526,"h":25770052302,"f":16777473},{"r":1310721,"n":"ToString","d":248526,"h":38654954190,"f":16810241},{"r":248526,"p":[{"n":"targetType","p":142475265}],"n":"Translate","d":248526,"h":42949921486,"f":16777473}],"c":[{"n":".ctor","o":"$ctor$1","d":248526,"h":4295215822,"f":16777224}],"h":248526}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `System.Security.Principal.IdentityReference`; }
        });
        
        $asm.$cls("$sspw.System.Security.Principal.IdentityReferenceCollection", ($self) => class IdentityReferenceCollection extends $.$$.System.Object
        {
            $ctor$1()
            {
                super.$ctor();
                {
                }
                return this;
            }
            $ctor$2(/*int*/ capacity)
            {
                super.$ctor();
                {
                }
                return this;
            }
            /*int */ get Count()
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Security.Principal.IdentityReference*/ get_Item(/*int*/ index)
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*void*/ set_Item(/*int*/ index, /*System.Security.Principal.IdentityReference*/ value)
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get System$Collections$Generic$ICollection$$$IsReadOnly()
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*void */ Add(/*System.Security.Principal.IdentityReference*/ identity)
            {
            }
            /*void */ Clear()
            {
            }
            /*bool */ Contains(/*System.Security.Principal.IdentityReference*/ identity)
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*void */ CopyTo(/*System.Security.Principal.IdentityReference[]*/ array, /*int*/ offset)
            {
            }
            /*System.Collections.Generic.IEnumerator<System.Security.Principal.IdentityReference> */ GetEnumerator()
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ Remove(/*System.Security.Principal.IdentityReference*/ identity)
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Collections.IEnumerator */ System$Collections$IEnumerable$GetEnumerator()
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Security.Principal.IdentityReferenceCollection */ Translate$1(/*System.Type*/ targetType)
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Security.Principal.IdentityReferenceCollection */ Translate(/*System.Type*/ targetType, /*bool*/ forceSuccess)
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            //Generated interface implemetation for System.Collections.Generic.ICollection<System.Security.Principal.IdentityReference>.Count.get
            get System$Collections$Generic$ICollection$$$Count()
            {
                return this.Count;
            }
            //Generated interface implemetation for System.Collections.Generic.ICollection<System.Security.Principal.IdentityReference>.Add(System.Security.Principal.IdentityReference)
            System$Collections$Generic$ICollection$$$Add()
            {
                return this.Add(...arguments);
            }
            //Generated interface implemetation for System.Collections.Generic.ICollection<System.Security.Principal.IdentityReference>.Clear()
            System$Collections$Generic$ICollection$$$Clear()
            {
                return this.Clear(...arguments);
            }
            //Generated interface implemetation for System.Collections.Generic.ICollection<System.Security.Principal.IdentityReference>.Contains(System.Security.Principal.IdentityReference)
            System$Collections$Generic$ICollection$$$Contains()
            {
                return this.Contains(...arguments);
            }
            //Generated interface implemetation for System.Collections.Generic.ICollection<System.Security.Principal.IdentityReference>.CopyTo(System.Security.Principal.IdentityReference[], int)
            System$Collections$Generic$ICollection$$$CopyTo()
            {
                return this.CopyTo(...arguments);
            }
            //Generated interface implemetation for System.Collections.Generic.ICollection<System.Security.Principal.IdentityReference>.Remove(System.Security.Principal.IdentityReference)
            System$Collections$Generic$ICollection$$$Remove()
            {
                return this.Remove(...arguments);
            }
            //Generated interface implemetation for System.Collections.Generic.IEnumerable<System.Security.Principal.IdentityReference>.GetEnumerator()
            System$Collections$Generic$IEnumerable$$$GetEnumerator()
            {
                return this.GetEnumerator(...arguments);
            }
            static $h = 314062;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":655361,"g":{"r":0,"d":0,"h":17180183246,"f":50331649},"n":"Count","d":314062,"h":12885215950,"f":2097153},{"p":248526,"i":[{"n":"index","p":655361}],"g":{"r":0,"d":0,"h":25770117838,"f":50331649},"s":{"r":0,"d":0,"h":30065085134,"f":83886081},"n":"Item","o":"@$2","d":314062,"h":21475150542,"f":2097153},{"p":262145,"g":{"r":0,"d":0,"h":38655019726,"f":50331650},"n":"{$.$$.System.Collections.Generic.ICollection$$($.$sspw.System.Security.Principal.IdentityReference).$h}.IsReadOnly","o":"System$Collections$Generic$ICollection$$$IsReadOnly","d":314062,"h":34360052430,"f":2097154}],"m":[{"r":65537,"p":[{"n":"identity","p":248526}],"n":"Add","d":314062,"h":42949987022,"f":16777217},{"r":65537,"n":"Clear","d":314062,"h":47244954318,"f":16777217},{"r":262145,"p":[{"n":"identity","p":248526}],"n":"Contains","d":314062,"h":51539921614,"f":16777217},{"r":65537,"p":[{"n":"array","p":$.$typeArray($.$sspw.System.Security.Principal.IdentityReference).$h},{"n":"offset","p":655361}],"n":"CopyTo","d":314062,"h":55834888910,"f":16777217},{"r":$.$$.System.Collections.Generic.IEnumerator$$($.$sspw.System.Security.Principal.IdentityReference).$h,"n":"GetEnumerator","d":314062,"h":60129856206,"f":16777217},{"r":262145,"p":[{"n":"identity","p":248526}],"n":"Remove","d":314062,"h":64424823502,"f":16777217},{"r":314062,"p":[{"n":"targetType","p":142475265}],"n":"Translate","o":"@$1","d":314062,"h":73014758094,"f":16777217},{"r":314062,"p":[{"n":"targetType","p":142475265},{"n":"forceSuccess","p":262145}],"n":"Translate","d":314062,"h":77309725390,"f":16777217}],"c":[{"n":".ctor","o":"$ctor$1","d":314062,"h":4295281358,"f":16777217},{"p":[{"n":"capacity","p":655361}],"n":".ctor","o":"$ctor$2","d":314062,"h":8590248654,"f":16777217}],"i":[$.$$.System.Collections.Generic.ICollection$$($.$sspw.System.Security.Principal.IdentityReference).$h,$.$$.System.Collections.Generic.IEnumerable$$($.$sspw.System.Security.Principal.IdentityReference).$h,31719425],"h":314062}; }
            static get $b() { return $.$$.System.Object; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.System.Collections.Generic.ICollection$$($.$sspw.System.Security.Principal.IdentityReference), $.$$.System.Collections.Generic.IEnumerable$$($.$sspw.System.Security.Principal.IdentityReference), $.$$.System.Collections.IEnumerable ]; }
            static get $fullName() { return `System.Security.Principal.IdentityReferenceCollection`; }
        });
        
        $asm.$cls("$sspw.System.Security.Principal.NTAccount", ($self) => class NTAccount extends $.$sspw.System.Security.Principal.IdentityReference
        {
            $ctor$3(/*string*/ name)
            {
                super.$ctor$1();
                {
                }
                return this;
            }
            $ctor$2(/*string*/ domainName, /*string*/ accountName)
            {
                super.$ctor$1();
                {
                }
                return this;
            }
            /*string */ get Value()
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            static/*conventional*/ /*bool */ Equals$1(/*object?*/ o)
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            //Static convention instance redirect
            /*bool */ Equals$1() { return $.$sspw.System.Security.Principal.NTAccount.Equals$1.apply(this, arguments); }
            static/*conventional*/ /*int */ GetHashCode()
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            //Static convention instance redirect
            /*int */ GetHashCode() { return $.$sspw.System.Security.Principal.NTAccount.GetHashCode.apply(this, arguments); }
            /*bool */ IsValidTargetType(/*System.Type*/ targetType)
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            static /*bool */ op_Equality$1(/*System.Security.Principal.NTAccount?*/ left, /*System.Security.Principal.NTAccount?*/ right)
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            static /*bool */ op_Inequality$1(/*System.Security.Principal.NTAccount?*/ left, /*System.Security.Principal.NTAccount?*/ right)
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            static/*conventional*/ /*string */ ToString()
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            //Static convention instance redirect
            /*string */ ToString() { return $.$sspw.System.Security.Principal.NTAccount.ToString.apply(this, arguments); }
            /*System.Security.Principal.IdentityReference */ Translate(/*System.Type*/ targetType)
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            static $h = 379598;
            static $f = 0b10010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":248526,"p":[{"p":1310721,"g":{"r":0,"d":0,"h":17180248782,"f":50364417},"n":"Value","d":379598,"h":12885281486,"f":2129921}],"m":[{"r":262145,"p":[{"n":"o","p":131073}],"n":"Equals","o":"@$1","d":379598,"h":21475216078,"f":16809985},{"r":655361,"n":"GetHashCode","d":379598,"h":25770183374,"f":16809985},{"r":262145,"p":[{"n":"targetType","p":142475265}],"n":"IsValidTargetType","d":379598,"h":30065150670,"f":16809985},{"r":1310721,"n":"ToString","d":379598,"h":42950052558,"f":16809985},{"r":248526,"p":[{"n":"targetType","p":142475265}],"n":"Translate","d":379598,"h":47245019854,"f":16809985}],"c":[{"p":[{"n":"name","p":1310721}],"n":".ctor","o":"$ctor$3","d":379598,"h":4295346894,"f":16777217},{"p":[{"n":"domainName","p":1310721},{"n":"accountName","p":1310721}],"n":".ctor","o":"$ctor$2","d":379598,"h":8590314190,"f":16777217}],"h":379598}; }
            static get $b() { return $.$sspw.System.Security.Principal.IdentityReference; }
            static get $fullName() { return `System.Security.Principal.NTAccount`; }
        });
        
        $asm.$cls("$sspw.System.Security.Principal.SecurityIdentifier", ($self) => class SecurityIdentifier extends $.$sspw.System.Security.Principal.IdentityReference
        {
            /*int*/ static MaxBinaryLength = 0;
            /*int*/ static MinBinaryLength = 0;
            $ctor$2(/*byte[]*/ binaryForm, /*int*/ offset)
            {
                super.$ctor$1();
                {
                }
                return this;
            }
            $ctor$3(/*System.IntPtr*/ binaryForm)
            {
                super.$ctor$1();
                {
                }
                return this;
            }
            $ctor$5(/*System.Security.Principal.WellKnownSidType*/ sidType, /*System.Security.Principal.SecurityIdentifier?*/ domainSid)
            {
                super.$ctor$1();
                {
                }
                return this;
            }
            $ctor$4(/*string*/ sddlForm)
            {
                super.$ctor$1();
                {
                }
                return this;
            }
            /*System.Security.Principal.SecurityIdentifier? */ get AccountDomainSid()
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ get BinaryLength()
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*string */ get Value()
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ CompareTo(/*System.Security.Principal.SecurityIdentifier?*/ sid)
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            static/*conventional*/ /*bool */ Equals$1(/*object?*/ o)
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            //Static convention instance redirect
            /*bool */ Equals$1() { return $.$sspw.System.Security.Principal.SecurityIdentifier.Equals$1.apply(this, arguments); }
            /*bool */ Equals$2(/*System.Security.Principal.SecurityIdentifier*/ sid)
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*void */ GetBinaryForm(/*byte[]*/ binaryForm, /*int*/ offset)
            {
            }
            static/*conventional*/ /*int */ GetHashCode()
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            //Static convention instance redirect
            /*int */ GetHashCode() { return $.$sspw.System.Security.Principal.SecurityIdentifier.GetHashCode.apply(this, arguments); }
            /*bool */ IsAccountSid()
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ IsEqualDomainSid(/*System.Security.Principal.SecurityIdentifier*/ sid)
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ IsValidTargetType(/*System.Type*/ targetType)
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ IsWellKnown(/*System.Security.Principal.WellKnownSidType*/ type)
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            static /*bool */ op_Equality$1(/*System.Security.Principal.SecurityIdentifier?*/ left, /*System.Security.Principal.SecurityIdentifier?*/ right)
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            static /*bool */ op_Inequality$1(/*System.Security.Principal.SecurityIdentifier?*/ left, /*System.Security.Principal.SecurityIdentifier?*/ right)
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            static/*conventional*/ /*string */ ToString()
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            //Static convention instance redirect
            /*string */ ToString() { return $.$sspw.System.Security.Principal.SecurityIdentifier.ToString.apply(this, arguments); }
            /*System.Security.Principal.IdentityReference */ Translate(/*System.Type*/ targetType)
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            //Generated interface implemetation for System.IComparable<System.Security.Principal.SecurityIdentifier>.CompareTo(System.Security.Principal.SecurityIdentifier?)
            System$IComparable$$$CompareTo()
            {
                return this.CompareTo(...arguments);
            }
            static $h = 445134;
            static $f = 0b10010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":248526,"p":[{"p":445134,"g":{"r":0,"d":0,"h":34360183502,"f":50331649},"n":"AccountDomainSid","d":445134,"h":30065216206,"f":2097153},{"p":655361,"g":{"r":0,"d":0,"h":42950118094,"f":50331649},"n":"BinaryLength","d":445134,"h":38655150798,"f":2097153},{"p":1310721,"g":{"r":0,"d":0,"h":51540052686,"f":50364417},"n":"Value","d":445134,"h":47245085390,"f":2129921}],"m":[{"r":655361,"p":[{"n":"sid","p":445134}],"n":"CompareTo","d":445134,"h":55835019982,"f":16777217},{"r":262145,"p":[{"n":"o","p":131073}],"n":"Equals","o":"@$1","d":445134,"h":60129987278,"f":16809985},{"r":262145,"p":[{"n":"sid","p":445134}],"n":"Equals","o":"@$2","d":445134,"h":64424954574,"f":16777217},{"r":65537,"p":[{"n":"binaryForm","p":$.$typeArray($.$$.System.Byte).$h},{"n":"offset","p":655361}],"n":"GetBinaryForm","d":445134,"h":68719921870,"f":16777217},{"r":655361,"n":"GetHashCode","d":445134,"h":73014889166,"f":16809985},{"r":262145,"n":"IsAccountSid","d":445134,"h":77309856462,"f":16777217},{"r":262145,"p":[{"n":"sid","p":445134}],"n":"IsEqualDomainSid","d":445134,"h":81604823758,"f":16777217},{"r":262145,"p":[{"n":"targetType","p":142475265}],"n":"IsValidTargetType","d":445134,"h":85899791054,"f":16809985},{"r":262145,"p":[{"n":"type","p":576206}],"n":"IsWellKnown","d":445134,"h":90194758350,"f":16777217},{"r":1310721,"n":"ToString","d":445134,"h":103079660238,"f":16809985},{"r":248526,"p":[{"n":"targetType","p":142475265}],"n":"Translate","d":445134,"h":107374627534,"f":16809985}],"l":[{"t":655361,"n":"MaxBinaryLength","d":445134,"h":4295412430,"f":4194337},{"t":655361,"n":"MinBinaryLength","d":445134,"h":8590379726,"f":4194337}],"c":[{"p":[{"n":"binaryForm","p":$.$typeArray($.$$.System.Byte).$h},{"n":"offset","p":655361}],"n":".ctor","o":"$ctor$2","d":445134,"h":12885347022,"f":16777217},{"p":[{"n":"binaryForm","p":786433}],"n":".ctor","o":"$ctor$3","d":445134,"h":17180314318,"f":16777217},{"p":[{"n":"sidType","p":576206},{"n":"domainSid","p":445134}],"n":".ctor","o":"$ctor$5","d":445134,"h":21475281614,"f":16777217},{"p":[{"n":"sddlForm","p":1310721}],"n":".ctor","o":"$ctor$4","d":445134,"h":25770248910,"f":16777217}],"i":[$.$$.System.IComparable$$($.$sspw.System.Security.Principal.SecurityIdentifier).$h],"h":445134}; }
            static get $b() { return $.$sspw.System.Security.Principal.IdentityReference; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.System.IComparable$$($.$sspw.System.Security.Principal.SecurityIdentifier) ]; }
            static get $fullName() { return `System.Security.Principal.SecurityIdentifier`; }
        });
        
        $asm.$cls("$sspw.Microsoft.Win32.SafeHandles.SafeAccessTokenHandle", ($self) => class SafeAccessTokenHandle extends $.$$.System.Runtime.InteropServices.SafeHandle
        {
            $ctor$3()
            {
                super.$ctor$2(0, false);
                {
                }
                return this;
            }
            $ctor$4(/*System.IntPtr*/ handle)
            {
                super.$ctor$2(0, false);
                {
                }
                return this;
            }
            static /*Microsoft.Win32.SafeHandles.SafeAccessTokenHandle */ get InvalidHandle()
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get IsInvalid()
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ ReleaseHandle()
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            static $h = 117454;
            static $f = 0b10010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":109445121,"p":[{"p":117454,"g":{"r":0,"d":0,"h":17179986638,"f":50331681},"n":"InvalidHandle","d":117454,"h":12885019342,"f":2097185},{"p":262145,"g":{"r":0,"d":0,"h":25769921230,"f":50364417},"n":"IsInvalid","d":117454,"h":21474953934,"f":2129921}],"m":[{"r":262145,"n":"ReleaseHandle","d":117454,"h":30064888526,"f":16809988}],"c":[{"n":".ctor","o":"$ctor$3","d":117454,"h":4295084750,"f":16777217},{"p":[{"n":"handle","p":786433}],"n":".ctor","o":"$ctor$4","d":117454,"h":8590052046,"f":16777217}],"i":[57540609],"h":117454}; }
            static get $b() { return $.$$.System.Runtime.InteropServices.SafeHandle; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.System.IDisposable ]; }
            static get $fullName() { return `Microsoft.Win32.SafeHandles.SafeAccessTokenHandle`; }
        });
        
        $asm.$str("$sspw.System.Security.Principal.TokenAccessLevels", ($self) => class TokenAccessLevels extends $.$$.System.Enum
        {
            static AssignPrimary = 1;
            static Duplicate = 2;
            static Impersonate = 4;
            static Query = 8;
            static QuerySource = 16;
            static AdjustPrivileges = 32;
            static AdjustGroups = 64;
            static AdjustDefault = 128;
            static AdjustSessionId = 256;
            static Read = 131080;
            static Write = 131296;
            static AllAccess = 983551;
            static MaximumAllowed = 33554432;
            static $map;
            static get Map()
            {
                return this.$map ??= 
                {
                    "AssignPrimary": 1n,
                    "Duplicate": 2n,
                    "Impersonate": 4n,
                    "Query": 8n,
                    "QuerySource": 16n,
                    "AdjustPrivileges": 32n,
                    "AdjustGroups": 64n,
                    "AdjustDefault": 128n,
                    "AdjustSessionId": 256n,
                    "Read": 131080n,
                    "Write": 131296n,
                    "AllAccess": 983551n,
                    "MaximumAllowed": 33554432n
                };
            }
            static $h = 510670;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static get $eut() { return $.$$.System.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {"b":1048577,"u":655361,"l":[{"t":510670,"n":"AssignPrimary","d":510670,"h":4295477966,"f":4194337},{"t":510670,"n":"Duplicate","d":510670,"h":8590445262,"f":4194337},{"t":510670,"n":"Impersonate","d":510670,"h":12885412558,"f":4194337},{"t":510670,"n":"Query","d":510670,"h":17180379854,"f":4194337},{"t":510670,"n":"QuerySource","d":510670,"h":21475347150,"f":4194337},{"t":510670,"n":"AdjustPrivileges","d":510670,"h":25770314446,"f":4194337},{"t":510670,"n":"AdjustGroups","d":510670,"h":30065281742,"f":4194337},{"t":510670,"n":"AdjustDefault","d":510670,"h":34360249038,"f":4194337},{"t":510670,"n":"AdjustSessionId","d":510670,"h":38655216334,"f":4194337},{"t":510670,"n":"Read","d":510670,"h":42950183630,"f":4194337},{"t":510670,"n":"Write","d":510670,"h":47245150926,"f":4194337},{"t":510670,"n":"AllAccess","d":510670,"h":51540118222,"f":4194337},{"t":510670,"n":"MaximumAllowed","d":510670,"h":55835085518,"f":4194337}],"c":[{"n":".ctor","o":"$ctor$3","d":510670,"h":60130052814,"f":16777217}],"i":[57278465,63832065,57737217,57409537],"h":510670,"a":[{"t":47710209,"c":4342677505}]}; }
            static get $b() { return $.$$.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.System.IComparable, $.$$.System.ISpanFormattable, $.$$.System.IFormattable, $.$$.System.IConvertible ]; }
            static get $fullName() { return `System.Security.Principal.TokenAccessLevels`; }
        });
        
        $asm.$str("$sspw.System.Security.Principal.WellKnownSidType", ($self) => class WellKnownSidType extends $.$$.System.Enum
        {
            static NullSid = 0;
            static WorldSid = 1;
            static LocalSid = 2;
            static CreatorOwnerSid = 3;
            static CreatorGroupSid = 4;
            static CreatorOwnerServerSid = 5;
            static CreatorGroupServerSid = 6;
            static NTAuthoritySid = 7;
            static DialupSid = 8;
            static NetworkSid = 9;
            static BatchSid = 10;
            static InteractiveSid = 11;
            static ServiceSid = 12;
            static AnonymousSid = 13;
            static ProxySid = 14;
            static EnterpriseControllersSid = 15;
            static SelfSid = 16;
            static AuthenticatedUserSid = 17;
            static RestrictedCodeSid = 18;
            static TerminalServerSid = 19;
            static RemoteLogonIdSid = 20;
            static LogonIdsSid = 21;
            static LocalSystemSid = 22;
            static LocalServiceSid = 23;
            static NetworkServiceSid = 24;
            static BuiltinDomainSid = 25;
            static BuiltinAdministratorsSid = 26;
            static BuiltinUsersSid = 27;
            static BuiltinGuestsSid = 28;
            static BuiltinPowerUsersSid = 29;
            static BuiltinAccountOperatorsSid = 30;
            static BuiltinSystemOperatorsSid = 31;
            static BuiltinPrintOperatorsSid = 32;
            static BuiltinBackupOperatorsSid = 33;
            static BuiltinReplicatorSid = 34;
            static BuiltinPreWindows2000CompatibleAccessSid = 35;
            static BuiltinRemoteDesktopUsersSid = 36;
            static BuiltinNetworkConfigurationOperatorsSid = 37;
            static AccountAdministratorSid = 38;
            static AccountGuestSid = 39;
            static AccountKrbtgtSid = 40;
            static AccountDomainAdminsSid = 41;
            static AccountDomainUsersSid = 42;
            static AccountDomainGuestsSid = 43;
            static AccountComputersSid = 44;
            static AccountControllersSid = 45;
            static AccountCertAdminsSid = 46;
            static AccountSchemaAdminsSid = 47;
            static AccountEnterpriseAdminsSid = 48;
            static AccountPolicyAdminsSid = 49;
            static AccountRasAndIasServersSid = 50;
            static NtlmAuthenticationSid = 51;
            static DigestAuthenticationSid = 52;
            static SChannelAuthenticationSid = 53;
            static ThisOrganizationSid = 54;
            static OtherOrganizationSid = 55;
            static BuiltinIncomingForestTrustBuildersSid = 56;
            static BuiltinPerformanceMonitoringUsersSid = 57;
            static BuiltinPerformanceLoggingUsersSid = 58;
            static BuiltinAuthorizationAccessSid = 59;
            static MaxDefined = 60;
            static WinBuiltinTerminalServerLicenseServersSid = 60;
            static WinBuiltinDCOMUsersSid = 61;
            static WinBuiltinIUsersSid = 62;
            static WinIUserSid = 63;
            static WinBuiltinCryptoOperatorsSid = 64;
            static WinUntrustedLabelSid = 65;
            static WinLowLabelSid = 66;
            static WinMediumLabelSid = 67;
            static WinHighLabelSid = 68;
            static WinSystemLabelSid = 69;
            static WinWriteRestrictedCodeSid = 70;
            static WinCreatorOwnerRightsSid = 71;
            static WinCacheablePrincipalsGroupSid = 72;
            static WinNonCacheablePrincipalsGroupSid = 73;
            static WinEnterpriseReadonlyControllersSid = 74;
            static WinAccountReadonlyControllersSid = 75;
            static WinBuiltinEventLogReadersGroup = 76;
            static WinNewEnterpriseReadonlyControllersSid = 77;
            static WinBuiltinCertSvcDComAccessGroup = 78;
            static WinMediumPlusLabelSid = 79;
            static WinLocalLogonSid = 80;
            static WinConsoleLogonSid = 81;
            static WinThisOrganizationCertificateSid = 82;
            static WinApplicationPackageAuthoritySid = 83;
            static WinBuiltinAnyPackageSid = 84;
            static WinCapabilityInternetClientSid = 85;
            static WinCapabilityInternetClientServerSid = 86;
            static WinCapabilityPrivateNetworkClientServerSid = 87;
            static WinCapabilityPicturesLibrarySid = 88;
            static WinCapabilityVideosLibrarySid = 89;
            static WinCapabilityMusicLibrarySid = 90;
            static WinCapabilityDocumentsLibrarySid = 91;
            static WinCapabilitySharedUserCertificatesSid = 92;
            static WinCapabilityEnterpriseAuthenticationSid = 93;
            static WinCapabilityRemovableStorageSid = 94;
            static $map;
            static get Map()
            {
                return this.$map ??= 
                {
                    "NullSid": 0n,
                    "WorldSid": 1n,
                    "LocalSid": 2n,
                    "CreatorOwnerSid": 3n,
                    "CreatorGroupSid": 4n,
                    "CreatorOwnerServerSid": 5n,
                    "CreatorGroupServerSid": 6n,
                    "NTAuthoritySid": 7n,
                    "DialupSid": 8n,
                    "NetworkSid": 9n,
                    "BatchSid": 10n,
                    "InteractiveSid": 11n,
                    "ServiceSid": 12n,
                    "AnonymousSid": 13n,
                    "ProxySid": 14n,
                    "EnterpriseControllersSid": 15n,
                    "SelfSid": 16n,
                    "AuthenticatedUserSid": 17n,
                    "RestrictedCodeSid": 18n,
                    "TerminalServerSid": 19n,
                    "RemoteLogonIdSid": 20n,
                    "LogonIdsSid": 21n,
                    "LocalSystemSid": 22n,
                    "LocalServiceSid": 23n,
                    "NetworkServiceSid": 24n,
                    "BuiltinDomainSid": 25n,
                    "BuiltinAdministratorsSid": 26n,
                    "BuiltinUsersSid": 27n,
                    "BuiltinGuestsSid": 28n,
                    "BuiltinPowerUsersSid": 29n,
                    "BuiltinAccountOperatorsSid": 30n,
                    "BuiltinSystemOperatorsSid": 31n,
                    "BuiltinPrintOperatorsSid": 32n,
                    "BuiltinBackupOperatorsSid": 33n,
                    "BuiltinReplicatorSid": 34n,
                    "BuiltinPreWindows2000CompatibleAccessSid": 35n,
                    "BuiltinRemoteDesktopUsersSid": 36n,
                    "BuiltinNetworkConfigurationOperatorsSid": 37n,
                    "AccountAdministratorSid": 38n,
                    "AccountGuestSid": 39n,
                    "AccountKrbtgtSid": 40n,
                    "AccountDomainAdminsSid": 41n,
                    "AccountDomainUsersSid": 42n,
                    "AccountDomainGuestsSid": 43n,
                    "AccountComputersSid": 44n,
                    "AccountControllersSid": 45n,
                    "AccountCertAdminsSid": 46n,
                    "AccountSchemaAdminsSid": 47n,
                    "AccountEnterpriseAdminsSid": 48n,
                    "AccountPolicyAdminsSid": 49n,
                    "AccountRasAndIasServersSid": 50n,
                    "NtlmAuthenticationSid": 51n,
                    "DigestAuthenticationSid": 52n,
                    "SChannelAuthenticationSid": 53n,
                    "ThisOrganizationSid": 54n,
                    "OtherOrganizationSid": 55n,
                    "BuiltinIncomingForestTrustBuildersSid": 56n,
                    "BuiltinPerformanceMonitoringUsersSid": 57n,
                    "BuiltinPerformanceLoggingUsersSid": 58n,
                    "BuiltinAuthorizationAccessSid": 59n,
                    "MaxDefined": 60n,
                    "WinBuiltinTerminalServerLicenseServersSid": 60n,
                    "WinBuiltinDCOMUsersSid": 61n,
                    "WinBuiltinIUsersSid": 62n,
                    "WinIUserSid": 63n,
                    "WinBuiltinCryptoOperatorsSid": 64n,
                    "WinUntrustedLabelSid": 65n,
                    "WinLowLabelSid": 66n,
                    "WinMediumLabelSid": 67n,
                    "WinHighLabelSid": 68n,
                    "WinSystemLabelSid": 69n,
                    "WinWriteRestrictedCodeSid": 70n,
                    "WinCreatorOwnerRightsSid": 71n,
                    "WinCacheablePrincipalsGroupSid": 72n,
                    "WinNonCacheablePrincipalsGroupSid": 73n,
                    "WinEnterpriseReadonlyControllersSid": 74n,
                    "WinAccountReadonlyControllersSid": 75n,
                    "WinBuiltinEventLogReadersGroup": 76n,
                    "WinNewEnterpriseReadonlyControllersSid": 77n,
                    "WinBuiltinCertSvcDComAccessGroup": 78n,
                    "WinMediumPlusLabelSid": 79n,
                    "WinLocalLogonSid": 80n,
                    "WinConsoleLogonSid": 81n,
                    "WinThisOrganizationCertificateSid": 82n,
                    "WinApplicationPackageAuthoritySid": 83n,
                    "WinBuiltinAnyPackageSid": 84n,
                    "WinCapabilityInternetClientSid": 85n,
                    "WinCapabilityInternetClientServerSid": 86n,
                    "WinCapabilityPrivateNetworkClientServerSid": 87n,
                    "WinCapabilityPicturesLibrarySid": 88n,
                    "WinCapabilityVideosLibrarySid": 89n,
                    "WinCapabilityMusicLibrarySid": 90n,
                    "WinCapabilityDocumentsLibrarySid": 91n,
                    "WinCapabilitySharedUserCertificatesSid": 92n,
                    "WinCapabilityEnterpriseAuthenticationSid": 93n,
                    "WinCapabilityRemovableStorageSid": 94n
                };
            }
            static $h = 576206;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static get $eut() { return $.$$.System.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {"b":1048577,"u":655361,"l":[{"t":576206,"n":"NullSid","d":576206,"h":4295543502,"f":4194337},{"t":576206,"n":"WorldSid","d":576206,"h":8590510798,"f":4194337},{"t":576206,"n":"LocalSid","d":576206,"h":12885478094,"f":4194337},{"t":576206,"n":"CreatorOwnerSid","d":576206,"h":17180445390,"f":4194337},{"t":576206,"n":"CreatorGroupSid","d":576206,"h":21475412686,"f":4194337},{"t":576206,"n":"CreatorOwnerServerSid","d":576206,"h":25770379982,"f":4194337},{"t":576206,"n":"CreatorGroupServerSid","d":576206,"h":30065347278,"f":4194337},{"t":576206,"n":"NTAuthoritySid","d":576206,"h":34360314574,"f":4194337},{"t":576206,"n":"DialupSid","d":576206,"h":38655281870,"f":4194337},{"t":576206,"n":"NetworkSid","d":576206,"h":42950249166,"f":4194337},{"t":576206,"n":"BatchSid","d":576206,"h":47245216462,"f":4194337},{"t":576206,"n":"InteractiveSid","d":576206,"h":51540183758,"f":4194337},{"t":576206,"n":"ServiceSid","d":576206,"h":55835151054,"f":4194337},{"t":576206,"n":"AnonymousSid","d":576206,"h":60130118350,"f":4194337},{"t":576206,"n":"ProxySid","d":576206,"h":64425085646,"f":4194337},{"t":576206,"n":"EnterpriseControllersSid","d":576206,"h":68720052942,"f":4194337},{"t":576206,"n":"SelfSid","d":576206,"h":73015020238,"f":4194337},{"t":576206,"n":"AuthenticatedUserSid","d":576206,"h":77309987534,"f":4194337},{"t":576206,"n":"RestrictedCodeSid","d":576206,"h":81604954830,"f":4194337},{"t":576206,"n":"TerminalServerSid","d":576206,"h":85899922126,"f":4194337},{"t":576206,"n":"RemoteLogonIdSid","d":576206,"h":90194889422,"f":4194337},{"t":576206,"n":"LogonIdsSid","d":576206,"h":94489856718,"f":4194337},{"t":576206,"n":"LocalSystemSid","d":576206,"h":98784824014,"f":4194337},{"t":576206,"n":"LocalServiceSid","d":576206,"h":103079791310,"f":4194337},{"t":576206,"n":"NetworkServiceSid","d":576206,"h":107374758606,"f":4194337},{"t":576206,"n":"BuiltinDomainSid","d":576206,"h":111669725902,"f":4194337},{"t":576206,"n":"BuiltinAdministratorsSid","d":576206,"h":115964693198,"f":4194337},{"t":576206,"n":"BuiltinUsersSid","d":576206,"h":120259660494,"f":4194337},{"t":576206,"n":"BuiltinGuestsSid","d":576206,"h":124554627790,"f":4194337},{"t":576206,"n":"BuiltinPowerUsersSid","d":576206,"h":128849595086,"f":4194337},{"t":576206,"n":"BuiltinAccountOperatorsSid","d":576206,"h":133144562382,"f":4194337},{"t":576206,"n":"BuiltinSystemOperatorsSid","d":576206,"h":137439529678,"f":4194337},{"t":576206,"n":"BuiltinPrintOperatorsSid","d":576206,"h":141734496974,"f":4194337},{"t":576206,"n":"BuiltinBackupOperatorsSid","d":576206,"h":146029464270,"f":4194337},{"t":576206,"n":"BuiltinReplicatorSid","d":576206,"h":150324431566,"f":4194337},{"t":576206,"n":"BuiltinPreWindows2000CompatibleAccessSid","d":576206,"h":154619398862,"f":4194337},{"t":576206,"n":"BuiltinRemoteDesktopUsersSid","d":576206,"h":158914366158,"f":4194337},{"t":576206,"n":"BuiltinNetworkConfigurationOperatorsSid","d":576206,"h":163209333454,"f":4194337},{"t":576206,"n":"AccountAdministratorSid","d":576206,"h":167504300750,"f":4194337},{"t":576206,"n":"AccountGuestSid","d":576206,"h":171799268046,"f":4194337},{"t":576206,"n":"AccountKrbtgtSid","d":576206,"h":176094235342,"f":4194337},{"t":576206,"n":"AccountDomainAdminsSid","d":576206,"h":180389202638,"f":4194337},{"t":576206,"n":"AccountDomainUsersSid","d":576206,"h":184684169934,"f":4194337},{"t":576206,"n":"AccountDomainGuestsSid","d":576206,"h":188979137230,"f":4194337},{"t":576206,"n":"AccountComputersSid","d":576206,"h":193274104526,"f":4194337},{"t":576206,"n":"AccountControllersSid","d":576206,"h":197569071822,"f":4194337},{"t":576206,"n":"AccountCertAdminsSid","d":576206,"h":201864039118,"f":4194337},{"t":576206,"n":"AccountSchemaAdminsSid","d":576206,"h":206159006414,"f":4194337},{"t":576206,"n":"AccountEnterpriseAdminsSid","d":576206,"h":210453973710,"f":4194337},{"t":576206,"n":"AccountPolicyAdminsSid","d":576206,"h":214748941006,"f":4194337},{"t":576206,"n":"AccountRasAndIasServersSid","d":576206,"h":219043908302,"f":4194337},{"t":576206,"n":"NtlmAuthenticationSid","d":576206,"h":223338875598,"f":4194337},{"t":576206,"n":"DigestAuthenticationSid","d":576206,"h":227633842894,"f":4194337},{"t":576206,"n":"SChannelAuthenticationSid","d":576206,"h":231928810190,"f":4194337},{"t":576206,"n":"ThisOrganizationSid","d":576206,"h":236223777486,"f":4194337},{"t":576206,"n":"OtherOrganizationSid","d":576206,"h":240518744782,"f":4194337},{"t":576206,"n":"BuiltinIncomingForestTrustBuildersSid","d":576206,"h":244813712078,"f":4194337},{"t":576206,"n":"BuiltinPerformanceMonitoringUsersSid","d":576206,"h":249108679374,"f":4194337},{"t":576206,"n":"BuiltinPerformanceLoggingUsersSid","d":576206,"h":253403646670,"f":4194337},{"t":576206,"n":"BuiltinAuthorizationAccessSid","d":576206,"h":257698613966,"f":4194337},{"t":576206,"n":"MaxDefined","d":576206,"h":261993581262,"f":4194337,"a":[{"t":33292289,"c":4328259585,"a":[{"v":1,"t":33357825}]},{"t":70909953,"c":8660844545,"a":[{"v":"This member has been deprecated and is only maintained for backwards compatability. WellKnownSidType values greater than MaxDefined may be defined in future releases.","t":1310721}]}]},{"t":576206,"n":"WinBuiltinTerminalServerLicenseServersSid","d":576206,"h":266288548558,"f":4194337},{"t":576206,"n":"WinBuiltinDCOMUsersSid","d":576206,"h":270583515854,"f":4194337},{"t":576206,"n":"WinBuiltinIUsersSid","d":576206,"h":274878483150,"f":4194337},{"t":576206,"n":"WinIUserSid","d":576206,"h":279173450446,"f":4194337},{"t":576206,"n":"WinBuiltinCryptoOperatorsSid","d":576206,"h":283468417742,"f":4194337},{"t":576206,"n":"WinUntrustedLabelSid","d":576206,"h":287763385038,"f":4194337},{"t":576206,"n":"WinLowLabelSid","d":576206,"h":292058352334,"f":4194337},{"t":576206,"n":"WinMediumLabelSid","d":576206,"h":296353319630,"f":4194337},{"t":576206,"n":"WinHighLabelSid","d":576206,"h":300648286926,"f":4194337},{"t":576206,"n":"WinSystemLabelSid","d":576206,"h":304943254222,"f":4194337},{"t":576206,"n":"WinWriteRestrictedCodeSid","d":576206,"h":309238221518,"f":4194337},{"t":576206,"n":"WinCreatorOwnerRightsSid","d":576206,"h":313533188814,"f":4194337},{"t":576206,"n":"WinCacheablePrincipalsGroupSid","d":576206,"h":317828156110,"f":4194337},{"t":576206,"n":"WinNonCacheablePrincipalsGroupSid","d":576206,"h":322123123406,"f":4194337},{"t":576206,"n":"WinEnterpriseReadonlyControllersSid","d":576206,"h":326418090702,"f":4194337},{"t":576206,"n":"WinAccountReadonlyControllersSid","d":576206,"h":330713057998,"f":4194337},{"t":576206,"n":"WinBuiltinEventLogReadersGroup","d":576206,"h":335008025294,"f":4194337},{"t":576206,"n":"WinNewEnterpriseReadonlyControllersSid","d":576206,"h":339302992590,"f":4194337},{"t":576206,"n":"WinBuiltinCertSvcDComAccessGroup","d":576206,"h":343597959886,"f":4194337},{"t":576206,"n":"WinMediumPlusLabelSid","d":576206,"h":347892927182,"f":4194337},{"t":576206,"n":"WinLocalLogonSid","d":576206,"h":352187894478,"f":4194337},{"t":576206,"n":"WinConsoleLogonSid","d":576206,"h":356482861774,"f":4194337},{"t":576206,"n":"WinThisOrganizationCertificateSid","d":576206,"h":360777829070,"f":4194337},{"t":576206,"n":"WinApplicationPackageAuthoritySid","d":576206,"h":365072796366,"f":4194337},{"t":576206,"n":"WinBuiltinAnyPackageSid","d":576206,"h":369367763662,"f":4194337},{"t":576206,"n":"WinCapabilityInternetClientSid","d":576206,"h":373662730958,"f":4194337},{"t":576206,"n":"WinCapabilityInternetClientServerSid","d":576206,"h":377957698254,"f":4194337},{"t":576206,"n":"WinCapabilityPrivateNetworkClientServerSid","d":576206,"h":382252665550,"f":4194337},{"t":576206,"n":"WinCapabilityPicturesLibrarySid","d":576206,"h":386547632846,"f":4194337},{"t":576206,"n":"WinCapabilityVideosLibrarySid","d":576206,"h":390842600142,"f":4194337},{"t":576206,"n":"WinCapabilityMusicLibrarySid","d":576206,"h":395137567438,"f":4194337},{"t":576206,"n":"WinCapabilityDocumentsLibrarySid","d":576206,"h":399432534734,"f":4194337},{"t":576206,"n":"WinCapabilitySharedUserCertificatesSid","d":576206,"h":403727502030,"f":4194337},{"t":576206,"n":"WinCapabilityEnterpriseAuthenticationSid","d":576206,"h":408022469326,"f":4194337},{"t":576206,"n":"WinCapabilityRemovableStorageSid","d":576206,"h":412317436622,"f":4194337}],"c":[{"n":".ctor","o":"$ctor$3","d":576206,"h":416612403918,"f":16777217}],"i":[57278465,63832065,57737217,57409537],"h":576206}; }
            static get $b() { return $.$$.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.System.IComparable, $.$$.System.ISpanFormattable, $.$$.System.IFormattable, $.$$.System.IConvertible ]; }
            static get $fullName() { return `System.Security.Principal.WellKnownSidType`; }
        });
        
        $asm.$str("$sspw.System.Security.Principal.WindowsAccountType", ($self) => class WindowsAccountType extends $.$$.System.Enum
        {
            static Normal = 0;
            static Guest = 1;
            static System = 2;
            static Anonymous = 3;
            static $map;
            static get Map()
            {
                return this.$map ??= 
                {
                    "Normal": 0n,
                    "Guest": 1n,
                    "System": 2n,
                    "Anonymous": 3n
                };
            }
            static $h = 641742;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static get $eut() { return $.$$.System.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {"b":1048577,"u":655361,"l":[{"t":641742,"n":"Normal","d":641742,"h":4295609038,"f":4194337},{"t":641742,"n":"Guest","d":641742,"h":8590576334,"f":4194337},{"t":641742,"n":"System","d":641742,"h":12885543630,"f":4194337},{"t":641742,"n":"Anonymous","d":641742,"h":17180510926,"f":4194337}],"c":[{"n":".ctor","o":"$ctor$3","d":641742,"h":21475478222,"f":16777217}],"i":[57278465,63832065,57737217,57409537],"h":641742}; }
            static get $b() { return $.$$.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.System.IComparable, $.$$.System.ISpanFormattable, $.$$.System.IFormattable, $.$$.System.IConvertible ]; }
            static get $fullName() { return `System.Security.Principal.WindowsAccountType`; }
        });
        
        $asm.$str("$sspw.System.Security.Principal.WindowsBuiltInRole", ($self) => class WindowsBuiltInRole extends $.$$.System.Enum
        {
            static Administrator = 544;
            static User = 545;
            static Guest = 546;
            static PowerUser = 547;
            static AccountOperator = 548;
            static SystemOperator = 549;
            static PrintOperator = 550;
            static BackupOperator = 551;
            static Replicator = 552;
            static $map;
            static get Map()
            {
                return this.$map ??= 
                {
                    "Administrator": 544n,
                    "User": 545n,
                    "Guest": 546n,
                    "PowerUser": 547n,
                    "AccountOperator": 548n,
                    "SystemOperator": 549n,
                    "PrintOperator": 550n,
                    "BackupOperator": 551n,
                    "Replicator": 552n
                };
            }
            static $h = 707278;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static get $eut() { return $.$$.System.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {"b":1048577,"u":655361,"l":[{"t":707278,"n":"Administrator","d":707278,"h":4295674574,"f":4194337},{"t":707278,"n":"User","d":707278,"h":8590641870,"f":4194337},{"t":707278,"n":"Guest","d":707278,"h":12885609166,"f":4194337},{"t":707278,"n":"PowerUser","d":707278,"h":17180576462,"f":4194337},{"t":707278,"n":"AccountOperator","d":707278,"h":21475543758,"f":4194337},{"t":707278,"n":"SystemOperator","d":707278,"h":25770511054,"f":4194337},{"t":707278,"n":"PrintOperator","d":707278,"h":30065478350,"f":4194337},{"t":707278,"n":"BackupOperator","d":707278,"h":34360445646,"f":4194337},{"t":707278,"n":"Replicator","d":707278,"h":38655412942,"f":4194337}],"c":[{"n":".ctor","o":"$ctor$3","d":707278,"h":42950380238,"f":16777217}],"i":[57278465,63832065,57737217,57409537],"h":707278}; }
            static get $b() { return $.$$.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.System.IComparable, $.$$.System.ISpanFormattable, $.$$.System.IFormattable, $.$$.System.IConvertible ]; }
            static get $fullName() { return `System.Security.Principal.WindowsBuiltInRole`; }
        });
        
        $asm.$cls("$sspw.System.Security.Principal.WindowsPrincipal", ($self) => class WindowsPrincipal extends $.$ssc.System.Security.Claims.ClaimsPrincipal
        {
            $ctor$7(/*System.Security.Principal.WindowsIdentity*/ ntIdentity)
            {
                super.$ctor$1();
                {
                }
                return this;
            }
            /*System.Collections.Generic.IEnumerable<System.Security.Claims.Claim> */ get DeviceClaims()
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Security.Principal.IIdentity */ get Identity()
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Collections.Generic.IEnumerable<System.Security.Claims.Claim> */ get UserClaims()
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ IsInRole$1(/*int*/ rid)
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ IsInRole$2(/*System.Security.Principal.SecurityIdentifier*/ sid)
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ IsInRole$3(/*System.Security.Principal.WindowsBuiltInRole*/ role)
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ IsInRole(/*string*/ role)
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            static $h = 838350;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":426462,"p":[{"p":$.$$.System.Collections.Generic.IEnumerable$$($.$ssc.System.Security.Claims.Claim).$h,"g":{"r":0,"d":0,"h":12885740238,"f":50331777},"n":"DeviceClaims","d":838350,"h":8590772942,"f":2097281},{"p":116916225,"g":{"r":0,"d":0,"h":21475674830,"f":50364417},"n":"Identity","d":838350,"h":17180707534,"f":2129921},{"p":$.$$.System.Collections.Generic.IEnumerable$$($.$ssc.System.Security.Claims.Claim).$h,"g":{"r":0,"d":0,"h":30065609422,"f":50331777},"n":"UserClaims","d":838350,"h":25770642126,"f":2097281}],"m":[{"r":262145,"p":[{"n":"rid","p":655361}],"n":"IsInRole","o":"@$1","d":838350,"h":34360576718,"f":16777345},{"r":262145,"p":[{"n":"sid","p":445134}],"n":"IsInRole","o":"@$2","d":838350,"h":38655544014,"f":16777345},{"r":262145,"p":[{"n":"role","p":707278}],"n":"IsInRole","o":"@$3","d":838350,"h":42950511310,"f":16777345},{"r":262145,"p":[{"n":"role","p":1310721}],"n":"IsInRole","d":838350,"h":47245478606,"f":16809985}],"c":[{"p":[{"n":"ntIdentity","p":772814}],"n":".ctor","o":"$ctor$7","d":838350,"h":4295805646,"f":16777217}],"i":[116981761],"h":838350}; }
            static get $b() { return $.$ssc.System.Security.Claims.ClaimsPrincipal; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.System.Security.Principal.IPrincipal ]; }
            static get $fullName() { return `System.Security.Principal.WindowsPrincipal`; }
        });
        
        $asm.$cls("$sspw.System.Security.Principal.WindowsIdentity", ($self) => class WindowsIdentity extends $.$ssc.System.Security.Claims.ClaimsIdentity
        {
            /*string*/ static DefaultIssuer$1 = null;
            $ctor$20(/*System.IntPtr*/ userToken)
            {
                super.$ctor$9(null, null, null, null, null, 5);
                {
                }
                return this;
            }
            $ctor$19(/*System.IntPtr*/ userToken, /*string*/ type)
            {
                super.$ctor$9(null, null, null, null, null, 5);
                {
                }
                return this;
            }
            $ctor$18(/*System.IntPtr*/ userToken, /*string*/ type, /*System.Security.Principal.WindowsAccountType*/ acctType)
            {
                super.$ctor$9(null, null, null, null, null, 5);
                {
                }
                return this;
            }
            $ctor$17(/*System.IntPtr*/ userToken, /*string*/ type, /*System.Security.Principal.WindowsAccountType*/ acctType, /*bool*/ isAuthenticated)
            {
                super.$ctor$9(null, null, null, null, null, 5);
                {
                }
                return this;
            }
            $ctor$21(/*System.Runtime.Serialization.SerializationInfo*/ info, /*System.Runtime.Serialization.StreamingContext*/ context)
            {
                super.$ctor$9(null, null, null, null, null, 5);
                {
                }
                return this;
            }
            $ctor$23(/*System.Security.Principal.WindowsIdentity*/ identity)
            {
                super.$ctor$9(null, null, null, null, null, 5);
                {
                }
                return this;
            }
            $ctor$22(/*string*/ sUserPrincipalName)
            {
                super.$ctor$9(null, null, null, null, null, 5);
                {
                }
                return this;
            }
            /*Microsoft.Win32.SafeHandles.SafeAccessTokenHandle */ get AccessToken()
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*string? */ get AuthenticationType()
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Collections.Generic.IEnumerable<System.Security.Claims.Claim> */ get Claims()
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Collections.Generic.IEnumerable<System.Security.Claims.Claim> */ get DeviceClaims()
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Security.Principal.IdentityReferenceCollection? */ get Groups()
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Security.Principal.TokenImpersonationLevel */ get ImpersonationLevel()
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get IsAnonymous()
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get IsAuthenticated()
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get IsGuest()
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get IsSystem()
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*string */ get Name()
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Security.Principal.SecurityIdentifier? */ get Owner()
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.IntPtr */ get Token()
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Security.Principal.SecurityIdentifier? */ get User()
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Collections.Generic.IEnumerable<System.Security.Claims.Claim> */ get UserClaims()
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Security.Claims.ClaimsIdentity */ Clone()
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*void */ Dispose()
            {
            }
            /*void */ Dispose$1(/*bool*/ disposing)
            {
            }
            static /*System.Security.Principal.WindowsIdentity */ GetAnonymous()
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            static /*System.Security.Principal.WindowsIdentity */ GetCurrent()
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            static /*System.Security.Principal.WindowsIdentity? */ GetCurrent$1(/*bool*/ ifImpersonating)
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            static /*System.Security.Principal.WindowsIdentity */ GetCurrent$2(/*System.Security.Principal.TokenAccessLevels*/ desiredAccess)
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            static /*void */ RunImpersonated(/*Microsoft.Win32.SafeHandles.SafeAccessTokenHandle*/ safeAccessTokenHandle, /*System.Action*/ action)
            {
            }
            static /*System.Threading.Tasks.Task */ RunImpersonatedAsync(/*Microsoft.Win32.SafeHandles.SafeAccessTokenHandle*/ safeAccessTokenHandle, /*System.Func<System.Threading.Tasks.Task>*/ func)
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            static /*System.Threading.Tasks.Task<T> */ RunImpersonatedAsync$1(T, /*Microsoft.Win32.SafeHandles.SafeAccessTokenHandle*/ safeAccessTokenHandle, /*System.Func<System.Threading.Tasks.Task<T>>*/ func)
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            static /*T */ RunImpersonated$1(T, /*Microsoft.Win32.SafeHandles.SafeAccessTokenHandle*/ safeAccessTokenHandle, /*System.Func<T>*/ func)
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*void */ System$Runtime$Serialization$IDeserializationCallback$OnDeserialization(/*object?*/ sender)
            {
            }
            /*void */ System$Runtime$Serialization$ISerializable$GetObjectData(/*System.Runtime.Serialization.SerializationInfo*/ info, /*System.Runtime.Serialization.StreamingContext*/ context)
            {
            }
            //Generated interface implemetation for System.IDisposable.Dispose()
            System$IDisposable$Dispose()
            {
                return this.Dispose(...arguments);
            }
            //Static Initializer
            static $sinit()
            {
                {
                    this.DefaultIssuer$1 = "AD AUTHORITY";
                }
            }
            static $h = 772814;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":295390,"p":[{"p":117454,"g":{"r":0,"d":0,"h":42950445774,"f":50331649},"n":"AccessToken","d":772814,"h":38655478478,"f":2097153},{"p":1310721,"g":{"r":0,"d":0,"h":51540380366,"f":50429953},"n":"AuthenticationType","d":772814,"h":47245413070,"f":2195457},{"p":$.$$.System.Collections.Generic.IEnumerable$$($.$ssc.System.Security.Claims.Claim).$h,"g":{"r":0,"d":0,"h":60130314958,"f":50364417},"n":"Claims","d":772814,"h":55835347662,"f":2129921},{"p":$.$$.System.Collections.Generic.IEnumerable$$($.$ssc.System.Security.Claims.Claim).$h,"g":{"r":0,"d":0,"h":68720249550,"f":50331777},"n":"DeviceClaims","d":772814,"h":64425282254,"f":2097281},{"p":314062,"g":{"r":0,"d":0,"h":77310184142,"f":50331649},"n":"Groups","d":772814,"h":73015216846,"f":2097153},{"p":117112833,"g":{"r":0,"d":0,"h":85900118734,"f":50331649},"n":"ImpersonationLevel","d":772814,"h":81605151438,"f":2097153},{"p":262145,"g":{"r":0,"d":0,"h":94490053326,"f":50331777},"n":"IsAnonymous","d":772814,"h":90195086030,"f":2097281},{"p":262145,"g":{"r":0,"d":0,"h":103079987918,"f":50364417},"n":"IsAuthenticated","d":772814,"h":98785020622,"f":2129921},{"p":262145,"g":{"r":0,"d":0,"h":111669922510,"f":50331777},"n":"IsGuest","d":772814,"h":107374955214,"f":2097281},{"p":262145,"g":{"r":0,"d":0,"h":120259857102,"f":50331777},"n":"IsSystem","d":772814,"h":115964889806,"f":2097281},{"p":1310721,"g":{"r":0,"d":0,"h":128849791694,"f":50364417},"n":"Name","d":772814,"h":124554824398,"f":2129921},{"p":445134,"g":{"r":0,"d":0,"h":137439726286,"f":50331649},"n":"Owner","d":772814,"h":133144758990,"f":2097153},{"p":786433,"g":{"r":0,"d":0,"h":146029660878,"f":50331777},"n":"Token","d":772814,"h":141734693582,"f":2097281},{"p":445134,"g":{"r":0,"d":0,"h":154619595470,"f":50331649},"n":"User","d":772814,"h":150324628174,"f":2097153},{"p":$.$$.System.Collections.Generic.IEnumerable$$($.$ssc.System.Security.Claims.Claim).$h,"g":{"r":0,"d":0,"h":163209530062,"f":50331777},"n":"UserClaims","d":772814,"h":158914562766,"f":2097281}],"m":[{"r":295390,"n":"Clone","d":772814,"h":167504497358,"f":16809985},{"r":65537,"n":"Dispose","d":772814,"h":171799464654,"f":16777217},{"r":65537,"p":[{"n":"disposing","p":262145}],"n":"Dispose","o":"@$1","d":772814,"h":176094431950,"f":16777348},{"r":772814,"n":"GetAnonymous","d":772814,"h":180389399246,"f":16777249},{"r":772814,"n":"GetCurrent","d":772814,"h":184684366542,"f":16777249},{"r":772814,"p":[{"n":"ifImpersonating","p":262145}],"n":"GetCurrent","o":"@$1","d":772814,"h":188979333838,"f":16777249},{"r":772814,"p":[{"n":"desiredAccess","p":510670}],"n":"GetCurrent","o":"@$2","d":772814,"h":193274301134,"f":16777249},{"r":65537,"p":[{"n":"safeAccessTokenHandle","p":117454},{"n":"action","p":11730945}],"n":"RunImpersonated","d":772814,"h":197569268430,"f":16777249},{"r":133169153,"p":[{"n":"safeAccessTokenHandle","p":117454},{"n":"func","p":$.$$.System.Func$$($.$$.System.Threading.Tasks.Task).$h}],"n":"RunImpersonatedAsync","d":772814,"h":201864235726,"f":16777249},{"r":(T) => $.$$.System.Threading.Tasks.Task$$(T).$h,"p":[{"n":"safeAccessTokenHandle","p":117454},{"n":"func","p":(T) => $.$$.System.Func$$($.$$.System.Threading.Tasks.Task$$(T)).$h}],"g":["T"],"n":"RunImpersonatedAsync","o":"@$1","d":772814,"h":206159203022,"f":16908321},{"r":(T) => T.$h,"p":[{"n":"safeAccessTokenHandle","p":117454},{"n":"func","p":(T) => $.$$.System.Func$$(T).$h}],"g":["T"],"n":"RunImpersonated","o":"@$1","d":772814,"h":210454170318,"f":16908321}],"l":[{"t":1310721,"n":"DefaultIssuer","o":"@$1","d":772814,"h":4295740110,"f":4194337}],"c":[{"p":[{"n":"userToken","p":786433}],"n":".ctor","o":"$ctor$20","d":772814,"h":8590707406,"f":16777217},{"p":[{"n":"userToken","p":786433},{"n":"type","p":1310721}],"n":".ctor","o":"$ctor$19","d":772814,"h":12885674702,"f":16777217},{"p":[{"n":"userToken","p":786433},{"n":"type","p":1310721},{"n":"acctType","p":641742}],"n":".ctor","o":"$ctor$18","d":772814,"h":17180641998,"f":16777217},{"p":[{"n":"userToken","p":786433},{"n":"type","p":1310721},{"n":"acctType","p":641742},{"n":"isAuthenticated","p":262145}],"n":".ctor","o":"$ctor$17","d":772814,"h":21475609294,"f":16777217},{"p":[{"n":"info","p":113836033},{"n":"context","p":113967105}],"n":".ctor","o":"$ctor$21","d":772814,"h":25770576590,"f":16777217,"a":[{"t":70909953,"c":8660844545,"a":[{"v":"This API supports obsolete formatter-based serialization. It should not be called or extended by application code.","t":1310721}],"n":[{"n":"DiagnosticId","v":"SYSLIB0051","t":1310721},{"n":"UrlFormat","v":"https://aka.ms/dotnet-warnings/{0}","t":1310721}]},{"t":33292289,"c":4328259585,"a":[{"v":1,"t":33357825}]}]},{"p":[{"n":"identity","p":772814}],"n":".ctor","o":"$ctor$23","d":772814,"h":30065543886,"f":16777220},{"p":[{"n":"sUserPrincipalName","p":1310721}],"n":".ctor","o":"$ctor$22","d":772814,"h":34360511182,"f":16777217}],"i":[116916225,57540609,112984065,113246209],"h":772814}; }
            static get $b() { return $.$ssc.System.Security.Claims.ClaimsIdentity; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.System.Security.Principal.IIdentity, $.$$.System.IDisposable, $.$$.System.Runtime.Serialization.IDeserializationCallback, $.$$.System.Runtime.Serialization.ISerializable ]; }
            static get $fullName() { return `System.Security.Principal.WindowsIdentity`; }
        });
        
        $asm.$cls("$sspw.System.Security.Principal.IdentityNotMappedException", ($self) => class IdentityNotMappedException extends $.$$.System.SystemException
        {
            $ctor$9()
            {
                super.$ctor$5();
                {
                }
                return this;
            }
            $ctor$11(/*string?*/ message)
            {
                super.$ctor$5();
                {
                }
                return this;
            }
            $ctor$10(/*string?*/ message, /*System.Exception?*/ inner)
            {
                super.$ctor$5();
                {
                }
                return this;
            }
            /*System.Security.Principal.IdentityReferenceCollection */ get UnmappedIdentities()
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*void */ GetObjectData(/*System.Runtime.Serialization.SerializationInfo*/ serializationInfo, /*System.Runtime.Serialization.StreamingContext*/ streamingContext)
            {
            }
            static $h = 182990;
            static $f = 0b10010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":119537665,"h":182990}; }
            static get $b() { return $.$$.System.SystemException; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.System.Runtime.Serialization.ISerializable ]; }
            static get $fullName() { return `System.Security.Principal.IdentityNotMappedException`; }
        });
	});
})(window, window.NetJs.$boot(), ...window.NetJs.$require("NetJs.System.Private.CoreLib", "NetJs.Microsoft.Win32.Primitives", "NetJs.System.Collections", "NetJs.System.Diagnostics.Tracing", "NetJs.System.Threading", "NetJs.System.Collections.Concurrent", "NetJs.System.Memory", "NetJs.System.Private.Uri", "NetJs.System.Runtime", "NetJs.System.Runtime.InteropServices", "NetJs.System.Threading.Thread", "NetJs.System.Security.Claims"))